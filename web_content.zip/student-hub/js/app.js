(() => {
'use strict';

/* ───────── أدوات مساعدة ───────── */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const KEY = 'student-hub-v1';
const COLORS = ['#23318C', '#D6455D', '#2E9E6B', '#E08A00', '#7A4FD1', '#0F8FA8', '#B5446E', '#5A7D2A'];
const DAYS = [{ d: 6, n: 'السبت' }, { d: 0, n: 'الأحد' }, { d: 1, n: 'الاثنين' }, { d: 2, n: 'الثلاثاء' }, { d: 3, n: 'الأربعاء' }, { d: 4, n: 'الخميس' }];
const TYPES = { cours: 'محاضرة', td: 'TD', tp: 'TP' };
const KINDS = ['واجب', 'بحث', 'مشروع', 'عرض'];
const DOC_KINDS = ['محاضرة', 'سلسلة TD', 'TP', 'امتحان سابق', 'ملخص', 'أخرى'];
const REMINDS = [[-1, 'بدون تذكير'], [0, 'عند الموعد'], [60, 'قبل ساعة'], [360, 'قبل 6 ساعات'], [1440, 'قبل يوم'], [2880, 'قبل يومين'], [4320, 'قبل 3 أيام'], [10080, 'قبل أسبوع']];

const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  calendar: '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
  tasks: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="m8 12 3 3 5-6"/>',
  calc: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h.01M12 19h.01M16 19h.01"/>',
  folder: '<path d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 21.5V4.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  download: '<path d="M12 3v12m0 0-4-4m4 4 4-4M4 21h16"/>',
  bell: '<path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4zM10 21h4"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
  eye: '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
  upload: '<path d="M12 16V4m0 0-4 4m4-4 4 4M4 20h16"/>'
};
const ic = (n, s = 20) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;

const NAV = [['home', 'الرئيسية', 'home'], ['schedule', 'الجدول', 'calendar'], ['tasks', 'الواجبات', 'tasks'], ['grades', 'المعدل', 'calc'], ['library', 'المكتبة', 'folder'], ['subjects', 'المقاييس', 'book']];

/* ───────── الحالة والتخزين ───────── */
const blank = () => ({ subjects: [], sessions: [], exams: [], tasks: [], docs: [], notified: {}, dark: false });
let S = load();
function load() {
  try { const d = JSON.parse(localStorage.getItem(KEY)); if (d) return Object.assign(blank(), d); } catch (e) { /* ignore */ }
  return blank();
}
function save() {
  try { localStorage.setItem(KEY, JSON.stringify(S)); }
  catch (e) { toast('تعذّر الحفظ: مساحة التخزين ممتلئة'); }
}

const sub = id => S.subjects.find(s => s.id === id);
const chip = id => { const s = sub(id); return s ? `<span class="chip" style="--c:${s.color}">${esc(s.name)}</span>` : ''; };
const toMin = t => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const byStart = (a, b) => toMin(a.start) - toMin(b.start);
const localISO = d => new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
const fmtD = (d, o = { weekday: 'long', day: 'numeric', month: 'long' }) => new Date(d).toLocaleDateString('ar-DZ-u-nu-latn', o);
const fmtDT = d => new Date(d).toLocaleString('ar-DZ-u-nu-latn', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
const examTs = e => new Date(e.date + 'T' + (e.time || '08:00')).getTime();
const size = b => b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB';

function rel(ts) {
  const diff = ts - Date.now(), day = 86400000;
  if (diff < 0) return { t: 'انتهى الموعد', cls: 'late' };
  if (diff < day) return { t: 'بعد ' + Math.max(1, Math.round(diff / 3600000)) + ' ساعة', cls: 'soon' };
  const d = Math.ceil(diff / day);
  const t = d === 1 ? 'غدًا' : d === 2 ? 'بعد يومين' : d <= 10 ? 'بعد ' + d + ' أيام' : 'بعد ' + d + ' يومًا';
  return { t, cls: d <= 3 ? 'soon' : '' };
}

/* ───────── حساب المعدل ───────── */
const num = v => (v === '' || v == null || isNaN(v)) ? null : +v;
function ccOf(s) {
  const g = s.g || {}, vals = [];
  let need = 0;
  if (s.hasTD) { need++; const v = num(g.td); if (v !== null) vals.push(v); }
  if (s.hasTP) { need++; const v = num(g.tp); if (v !== null) vals.push(v); }
  if (!need) return { need: 0, cc: null, ok: true };
  return { need, ok: vals.length === need, cc: vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null };
}
function avgOf(s) {
  const ex = num((s.g || {}).exam), c = ccOf(s);
  if (ex === null || !c.ok) return null;
  if (!c.need) return ex;
  return (c.cc * s.wCC + ex * (100 - s.wCC)) / 100;
}
function overall() {
  let sum = 0, co = 0;
  S.subjects.forEach(s => { const a = avgOf(s); if (a !== null) { sum += a * s.coef; co += s.coef; } });
  return co ? { avg: sum / co, co, total: S.subjects.reduce((a, s) => a + s.coef, 0) } : null;
}

/* ───────── واجهة: عناصر عامة ───────── */
let onClose = null;
function toast(msg, sticky = false) {
  const t = document.createElement('div');
  t.className = 'toast'; t.textContent = msg;
  $('#toasts').appendChild(t);
  setTimeout(() => t.remove(), sticky ? 9000 : 3200);
}
function closeModal() { $('#modal').innerHTML = ''; if (onClose) { const f = onClose; onClose = null; f(); } }
function modal(title, body, onSave, opts = {}) {
  const ok = opts.ok === undefined ? 'حفظ' : opts.ok;
  $('#modal').innerHTML = `<div class="scrim"><form class="sheet" role="dialog" aria-label="${esc(title)}">
    <header><h3>${title}</h3><button type="button" class="icon" data-close aria-label="إغلاق">${ic('x')}</button></header>
    <div class="body">${body}</div>
    <footer><button type="button" class="btn ghost" data-close>${ok ? 'إلغاء' : 'إغلاق'}</button>${ok ? `<button class="btn ${opts.danger ? 'danger' : 'primary'}">${ok}</button>` : ''}</footer>
  </form></div>`;
  const f = $('#modal form');
  f.addEventListener('submit', e => { e.preventDefault(); if (onSave && onSave(new FormData(f)) === false) return; closeModal(); });
  const first = $('input:not([type=radio]):not([type=checkbox]),select', f); if (first && !opts.noFocus) first.focus();
}
const ask = (msg, fn) => modal('تأكيد', `<p>${msg}</p>`, () => { fn(); }, { ok: 'حذف', danger: true });
const fld = (label, html, cls = '') => `<label class="fld ${cls}"><span>${label}</span>${html}</label>`;
const sel = (name, opts, val) => `<select name="${name}">${opts.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(val) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
const subSel = val => sel('sid', S.subjects.map(s => [s.id, s.name]), val);
const head = (title, subtitle, actions = '') => `<header class="head"><div><h1>${title}</h1>${subtitle ? `<p>${subtitle}</p>` : ''}</div><div class="acts">${actions}<button class="icon" data-act="settings" title="الإعدادات" aria-label="الإعدادات">${ic('gear')}</button></div></header>`;
const empty = (t, d, btn = '') => `<div class="empty"><b>${t}</b><p>${d}</p>${btn}</div>`;
function needSubject() {
  if (S.subjects.length) return true;
  toast('أضف مقياسًا واحدًا على الأقل أولًا');
  location.hash = '#subjects';
  return false;
}

/* ───────── الصفحة الرئيسية ───────── */
function vHome() {
  const now = new Date(), nowMin = now.getHours() * 60 + now.getMinutes();
  const today = S.sessions.filter(x => x.day === now.getDay()).sort(byStart);
  const ov = overall();
  const openTasks = S.tasks.filter(t => !t.done).sort((a, b) => new Date(a.due) - new Date(b.due)).slice(0, 4);
  const exams = S.exams.filter(e => examTs(e) > Date.now()).sort((a, b) => examTs(a) - examTs(b)).slice(0, 3);

  if (!S.subjects.length) {
    return head('أهلًا بك في دفتري', fmtD(now)) + `<section class="paper start">
      <h2>ابدأ من هنا</h2>
      <p>أضف مقاييس هذا السداسي أولًا، ثم اربط بها حصصك وامتحاناتك وواجباتك ودروسك.</p>
      <a class="btn primary" href="#subjects">${ic('plus', 18)} أضف أول مقياس</a>
    </section>`;
  }

  const timeline = today.length ? `<ol class="timeline">${today.map(x => {
    const s = sub(x.sid), st = nowMin >= toMin(x.end) ? 'past' : nowMin >= toMin(x.start) ? 'now' : '';
    return `<li class="slot ${st}" style="--c:${s ? s.color : '#999'}"><time>${x.start}<small>${x.end}</small></time>
      <div><b>${esc(s ? s.name : '—')}</b><span class="meta"><span>${TYPES[x.type]}</span>${x.room ? `<span>${esc(x.room)}</span>` : ''}${x.teacher ? `<span>${esc(x.teacher)}</span>` : ''}</span></div>${st === 'now' ? '<em>الآن</em>' : ''}</li>`;
  }).join('')}</ol>` : empty('لا حصص اليوم', 'يوم مناسب لمراجعة دروسك من المكتبة.');

  const notifBanner = ('Notification' in window && Notification.permission === 'default')
    ? `<div class="banner">${ic('bell', 18)}<span>فعّل الإشعارات لتصلك تذكيرات الواجبات والامتحانات.</span><button class="btn small" data-act="askNotif">تفعيل</button></div>` : '';

  return head('ورقة اليوم', fmtD(now)) + notifBanner + `<div class="home-grid">
    <section class="paper"><h2>حصص اليوم</h2>${timeline}</section>
    <div class="stack">
      <a class="avg-chip" href="#grades"><span>المعدل الحالي</span><b>${ov ? ov.avg.toFixed(2) : '—'}</b><small>${ov ? 'من 20' : 'أدخل علاماتك لحسابه'}</small></a>
      <section class="card"><h2>الواجبات القادمة</h2>
        ${openTasks.length ? openTasks.map(t => { const r = rel(new Date(t.due).getTime()); return `<div class="mini"><div><b>${esc(t.title)}</b>${chip(t.sid)}</div><span class="due ${r.cls}">${r.t}</span></div>`; }).join('') : '<p class="muted">لا واجبات معلّقة.</p>'}
      </section>
      <section class="card"><h2>الامتحانات القادمة</h2>
        ${exams.length ? exams.map(e => { const r = rel(examTs(e)); return `<div class="mini"><div><b>${esc((sub(e.sid) || {}).name || '—')}</b><small>${fmtD(e.date)} ${e.time || ''}</small></div><span class="due ${r.cls}">${r.t}</span></div>`; }).join('') : '<p class="muted">لا امتحانات مسجّلة.</p>'}
      </section>
    </div>
  </div>`;
}

/* ───────── الجدول والامتحانات ───────── */
let schedTab = 'sessions';
function sessionRow(x) {
  const s = sub(x.sid);
  return `<div class="slot" style="--c:${s ? s.color : '#999'}"><time>${x.start}<small>${x.end}</small></time>
    <div><b>${esc(s ? s.name : '—')}</b><span class="meta"><span>${TYPES[x.type]}</span>${x.room ? `<span>${esc(x.room)}</span>` : ''}${x.teacher ? `<span>${esc(x.teacher)}</span>` : ''}</span></div>
    <div class="row-acts"><button class="icon" data-act="editSession" data-id="${x.id}" aria-label="تعديل">${ic('edit', 17)}</button><button class="icon" data-act="delSession" data-id="${x.id}" aria-label="حذف">${ic('trash', 17)}</button></div></div>`;
}
function examRow(e) {
  const ts = examTs(e), r = rel(ts), s = sub(e.sid), d = new Date(e.date + 'T00:00');
  return `<div class="exam ${ts < Date.now() ? 'past' : ''}" style="--c:${s ? s.color : '#999'}">
    <div class="date"><b>${d.getDate()}</b><span>${fmtD(d, { month: 'short' })}</span></div>
    <div class="grow"><b>${esc(s ? s.name : '—')}</b><span class="meta"><span>${fmtD(d, { weekday: 'long' })}</span>${e.time ? `<span>${e.time}</span>` : ''}${e.room ? `<span>${esc(e.room)}</span>` : ''}</span>${e.note ? `<small>${esc(e.note)}</small>` : ''}</div>
    <span class="due ${r.cls}">${r.t}</span>
    <div class="row-acts"><button class="icon" data-act="editExam" data-id="${e.id}" aria-label="تعديل">${ic('edit', 17)}</button><button class="icon" data-act="delExam" data-id="${e.id}" aria-label="حذف">${ic('trash', 17)}</button></div></div>`;
}
function vSchedule() {
  const add = schedTab === 'sessions'
    ? `<button class="btn primary" data-act="addSession">${ic('plus', 18)} حصة</button>`
    : `<button class="btn primary" data-act="addExam">${ic('plus', 18)} امتحان</button>`;
  const tabs = `<div class="tabs"><button data-act="tab" data-v="sessions" class="${schedTab === 'sessions' ? 'on' : ''}">الحصص الأسبوعية</button><button data-act="tab" data-v="exams" class="${schedTab === 'exams' ? 'on' : ''}">الامتحانات</button></div>`;
  let body;
  if (schedTab === 'sessions') {
    const td = new Date().getDay();
    body = `<div class="week">${DAYS.map(D => {
      const list = S.sessions.filter(x => x.day === D.d).sort(byStart);
      return `<section class="day ${D.d === td ? 'today' : ''}"><h3>${D.n}</h3>${list.length ? list.map(sessionRow).join('') : '<p class="muted">لا حصص</p>'}</section>`;
    }).join('')}</div>`;
  } else {
    const list = [...S.exams].sort((a, b) => examTs(a) - examTs(b));
    body = list.length ? `<div class="exams">${list.map(examRow).join('')}</div>` : empty('لا امتحانات بعد', 'سجّل تواريخ امتحاناتك لتصلك تذكيرات قبلها بيوم.');
  }
  return head('الجدول', 'محاضراتك وامتحاناتك في صفحة واحدة', add) + tabs + body;
}
function sessionForm(x) {
  if (!needSubject()) return;
  const edit = !!x; const v = x || { day: 6, type: 'cours', start: '08:00', end: '09:30', sid: S.subjects[0].id };
  modal(edit ? 'تعديل الحصة' : 'حصة جديدة', `<div class="grid2">
    ${fld('المقياس', subSel(v.sid), 'span2')}
    ${fld('النوع', sel('type', Object.entries(TYPES), v.type))}
    ${fld('اليوم', sel('day', DAYS.map(d => [d.d, d.n]), v.day))}
    ${fld('من', `<input type="time" name="start" value="${v.start}" required>`)}
    ${fld('إلى', `<input type="time" name="end" value="${v.end}" required>`)}
    ${fld('القاعة', `<input name="room" value="${esc(v.room || '')}" placeholder="مثال: مدرج 3">`)}
    ${fld('الأستاذ', `<input name="teacher" value="${esc(v.teacher || '')}">`)}
  </div>`, f => {
    const o = { sid: f.get('sid'), type: f.get('type'), day: +f.get('day'), start: f.get('start'), end: f.get('end'), room: f.get('room').trim(), teacher: f.get('teacher').trim() };
    if (o.end <= o.start) { toast('وقت النهاية يجب أن يكون بعد وقت البداية'); return false; }
    if (edit) Object.assign(x, o); else S.sessions.push({ id: uid(), ...o });
    save(); render();
  });
}
function examForm(x) {
  if (!needSubject()) return;
  const edit = !!x; const v = x || { sid: S.subjects[0].id, date: localISO(new Date(Date.now() + 14 * 864e5)).slice(0, 10), time: '09:00' };
  modal(edit ? 'تعديل الامتحان' : 'امتحان جديد', `<div class="grid2">
    ${fld('المقياس', subSel(v.sid), 'span2')}
    ${fld('التاريخ', `<input type="date" name="date" value="${v.date}" required>`)}
    ${fld('الساعة', `<input type="time" name="time" value="${v.time || ''}">`)}
    ${fld('القاعة', `<input name="room" value="${esc(v.room || '')}">`, 'span2')}
    ${fld('ملاحظة', `<input name="note" value="${esc(v.note || '')}" placeholder="مثال: الوثائق ممنوعة">`, 'span2')}
  </div>`, f => {
    const o = { sid: f.get('sid'), date: f.get('date'), time: f.get('time'), room: f.get('room').trim(), note: f.get('note').trim() };
    if (edit) { Object.assign(x, o); delete S.notified['e' + x.id]; } else S.exams.push({ id: uid(), ...o });
    save(); render();
  });
}

/* ───────── الواجبات والبحوث ───────── */
let taskFilter = 'open';
function vTasks() {
  let list = [...S.tasks];
  if (taskFilter === 'open') list = list.filter(t => !t.done);
  if (taskFilter === 'done') list = list.filter(t => t.done);
  list.sort((a, b) => new Date(a.due) - new Date(b.due));
  const f = (k, l) => `<button data-act="tfilter" data-v="${k}" class="${taskFilter === k ? 'on' : ''}">${l}</button>`;
  const rows = list.map(t => {
    const r = rel(new Date(t.due).getTime());
    const remind = REMINDS.find(x => x[0] === t.remind);
    return `<article class="task ${t.done ? 'done' : ''}">
      <button class="check" data-act="toggleTask" data-id="${t.id}" aria-label="${t.done ? 'إلغاء الإنجاز' : 'تم الإنجاز'}">${t.done ? ic('tasks', 18) : ''}</button>
      <div class="grow"><b>${esc(t.title)}</b>
        <span class="meta"><span class="kind">${esc(t.kind)}</span>${chip(t.sid)}<span>${fmtDT(t.due)}</span>${remind && remind[0] >= 0 ? `<span class="bell">${ic('bell', 14)} ${remind[1]}</span>` : ''}</span>
        ${t.notes ? `<small>${esc(t.notes)}</small>` : ''}</div>
      ${t.done ? '' : `<span class="due ${r.cls}">${r.t}</span>`}
      <div class="row-acts"><button class="icon" data-act="editTask" data-id="${t.id}" aria-label="تعديل">${ic('edit', 17)}</button><button class="icon" data-act="delTask" data-id="${t.id}" aria-label="حذف">${ic('trash', 17)}</button></div></article>`;
  }).join('');
  return head('الواجبات والبحوث', 'لا يفوتك موعد تسليم', `<button class="btn primary" data-act="addTask">${ic('plus', 18)} إضافة</button>`)
    + `<div class="tabs">${f('open', 'قيد الإنجاز')}${f('done', 'منجزة')}${f('all', 'الكل')}</div>`
    + (rows ? `<div class="tasks">${rows}</div>` : empty('لا شيء هنا', taskFilter === 'done' ? 'لم تُنجز أي مهمة بعد.' : 'أضف واجبًا أو بحثًا وحدّد وقت التذكير.'));
}
function taskForm(x) {
  if (!needSubject()) return;
  const edit = !!x; const v = x || { kind: 'واجب', sid: S.subjects[0].id, due: localISO(new Date(Date.now() + 3 * 864e5)).slice(0, 11) + '12:00', remind: 1440 };
  modal(edit ? 'تعديل المهمة' : 'مهمة جديدة', `<div class="grid2">
    ${fld('العنوان', `<input name="title" value="${esc(v.title || '')}" required placeholder="مثال: سلسلة التمارين رقم 3">`, 'span2')}
    ${fld('النوع', sel('kind', KINDS.map(k => [k, k]), v.kind))}
    ${fld('المقياس', subSel(v.sid))}
    ${fld('موعد التسليم', `<input type="datetime-local" name="due" value="${v.due}" required>`)}
    ${fld('التذكير', sel('remind', REMINDS, v.remind))}
    ${fld('ملاحظات', `<textarea name="notes" rows="2">${esc(v.notes || '')}</textarea>`, 'span2')}
  </div>`, f => {
    const o = { title: f.get('title').trim(), kind: f.get('kind'), sid: f.get('sid'), due: f.get('due'), remind: +f.get('remind'), notes: f.get('notes').trim() };
    if (edit) { Object.assign(x, o); delete S.notified['t' + x.id]; } else S.tasks.push({ id: uid(), done: false, ...o });
    save(); render(); checkReminders();
  });
}

/* ───────── المعدل ───────── */
const ring = (avg) => { const C = 2 * Math.PI * 52, p = Math.max(0, Math.min(1, avg / 20)); return `<svg viewBox="0 0 120 120" class="ring"><circle cx="60" cy="60" r="52" class="trk"/><circle id="ringArc" cx="60" cy="60" r="52" class="arc ${avg >= 10 ? 'ok' : 'no'}" stroke-dasharray="${(C * p).toFixed(1)} ${C.toFixed(1)}" transform="rotate(-90 60 60)"/></svg>`; };
function vGrades() {
  if (!S.subjects.length) return head('المعدل', 'يُحسب تلقائيًا') + empty('لا مقاييس بعد', 'أضف مقاييسك مع معاملاتها لتبدأ حساب المعدل.', '<a class="btn primary" href="#subjects">إضافة مقياس</a>');
  const ov = overall();
  const hero = `<section class="gradehero">
    <div class="ringbox">${ring(ov ? ov.avg : 0)}<div class="ringtxt"><b id="ovAvg">${ov ? ov.avg.toFixed(2) : '—'}</b><small>/ 20</small></div></div>
    <div><h2>معدل السداسي</h2><p id="ovInfo"></p></div></section>`;
  const cards = S.subjects.map(s => {
    const g = s.g || {};
    const inp = (k, l) => `<label class="gin"><span>${l}</span><input type="number" inputmode="decimal" min="0" max="20" step="0.01" data-in="grade" data-sid="${s.id}" data-k="${k}" value="${g[k] ?? ''}" placeholder="—"></label>`;
    return `<article class="gsub" style="--c:${s.color}" id="g-${s.id}">
      <header><b>${esc(s.name)}</b><span class="coef">المعامل ${s.coef}</span><strong class="av" id="av-${s.id}">—</strong></header>
      <div class="ins">${s.hasTD ? inp('td', 'TD') : ''}${s.hasTP ? inp('tp', 'TP') : ''}${inp('exam', 'الامتحان')}</div>
      <p class="hint" id="hint-${s.id}"></p></article>`;
  }).join('');
  return head('المعدل', 'أدخل علاماتك وسيُحسب كل شيء تلقائيًا') + hero + `<div class="gsubs">${cards}</div>`;
}
function refreshGrades() {
  S.subjects.forEach(s => {
    const a = avgOf(s), av = $('#av-' + s.id), hint = $('#hint-' + s.id); if (!av) return;
    av.textContent = a === null ? '—' : a.toFixed(2);
    av.className = 'av ' + (a === null ? '' : a >= 10 ? 'ok' : 'no');
    const c = ccOf(s), ex = num((s.g || {}).exam), w = s.wCC;
    const formula = c.need ? `المعدل = (${s.hasTD && s.hasTP ? 'متوسط TD وTP' : s.hasTD ? 'TD' : 'TP'} × ${w}٪) + (الامتحان × ${100 - w}٪)` : 'المعدل = علامة الامتحان';
    if (a !== null) hint.textContent = a >= 10 ? 'مقياس مُحقَّق' : 'دون المعدل المطلوب (10)';
    else if (ex === null && c.ok && c.need) { const need = (10 - c.cc * w / 100) / ((100 - w) / 100); hint.textContent = need <= 0 ? 'ضمنت 10/20 مهما كانت علامة الامتحان' : need > 20 ? 'لا يمكن بلوغ 10 حتى بعلامة 20 في الامتحان' : `تحتاج ${need.toFixed(2)} في الامتحان لبلوغ 10`; }
    else hint.textContent = formula;
  });
  const ov = overall(), el = $('#ovAvg'); if (!el) return;
  el.textContent = ov ? ov.avg.toFixed(2) : '—';
  const arc = $('#ringArc'); if (arc) { const C = 2 * Math.PI * 52, p = ov ? Math.min(1, ov.avg / 20) : 0; arc.setAttribute('stroke-dasharray', `${(C * p).toFixed(1)} ${C.toFixed(1)}`); arc.setAttribute('class', 'arc ' + (ov && ov.avg >= 10 ? 'ok' : 'no')); }
  $('#ovInfo').textContent = ov ? `محسوب على ${ov.co} من ${ov.total} معامل. ${ov.avg >= 10 ? 'أنت فوق المعدل المطلوب.' : 'أنت دون المعدل المطلوب حاليًا.'}` : 'أدخل علامات مقياس واحد كاملة (TD وTP والامتحان) ليظهر المعدل.';
}

/* ───────── المكتبة ───────── */
let libSub = '', libFilter = '', libQ = '';
function vLibrary() {
  if (!S.subjects.length) return head('المكتبة', 'دروسك بصيغة PDF') + empty('أضف مقياسًا أولًا', 'تُحفظ الملفات داخل مجلد كل مقياس.', '<a class="btn primary" href="#subjects">إضافة مقياس</a>');
  if (!sub(libSub)) libSub = S.subjects[0].id;
  return head('المكتبة', 'دروسك ووثائقك مرتبة حسب المقياس') + `
    <section class="upload" id="drop">
      <div class="up-fields">
        ${fld('المقياس', sel('', S.subjects.map(s => [s.id, s.name]), libSub).replace('<select name=""', '<select id="upSub" data-in="libSub"'))}
        ${fld('النوع', `<select id="upKind">${DOC_KINDS.map(k => `<option>${k}</option>`).join('')}</select>`)}
      </div>
      <label class="drop">${ic('upload', 26)}<b>اختر ملفات PDF أو اسحبها إلى هنا</b><small>تُحفظ على جهازك داخل المتصفح</small>
        <input type="file" id="pdfs" accept="application/pdf,.pdf" multiple hidden></label>
    </section>
    <div class="filters">
      <input type="search" placeholder="ابحث في الملفات" value="${esc(libQ)}" data-in="libQ" aria-label="بحث">
      <select data-in="libFilter" aria-label="تصفية حسب المقياس"><option value="">كل المقاييس</option>${S.subjects.map(s => `<option value="${s.id}" ${s.id === libFilter ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>
    </div>
    <div id="libList">${libList()}</div>`;
}
function libList() {
  const q = libQ.trim().toLowerCase();
  const docs = S.docs.filter(d => (!libFilter || d.sid === libFilter) && (!q || d.name.toLowerCase().includes(q)));
  if (!docs.length) return empty('لا ملفات', S.docs.length ? 'لا نتائج مطابقة للبحث.' : 'ارفع أول ملف PDF ليظهر هنا داخل مجلد مقياسه.');
  return S.subjects.map(s => {
    const list = docs.filter(d => d.sid === s.id).sort((a, b) => b.date - a.date); if (!list.length) return '';
    return `<section class="folder" style="--c:${s.color}"><h3>${ic('folder', 18)} ${esc(s.name)} <small>${list.length}</small></h3>
      ${list.map(d => `<div class="doc">${ic('file', 22)}<div class="grow"><b>${esc(d.name)}</b><span class="meta"><span class="kind">${esc(d.kind)}</span><span>${size(d.size)}</span><span>${fmtD(d.date, { day: 'numeric', month: 'short', year: 'numeric' })}</span></span></div>
        <div class="row-acts"><button class="icon" data-act="openDoc" data-id="${d.id}" aria-label="فتح">${ic('eye', 17)}</button><button class="icon" data-act="dlDoc" data-id="${d.id}" aria-label="تنزيل">${ic('download', 17)}</button><button class="icon" data-act="editDoc" data-id="${d.id}" aria-label="تعديل">${ic('edit', 17)}</button><button class="icon" data-act="delDoc" data-id="${d.id}" aria-label="حذف">${ic('trash', 17)}</button></div></div>`).join('')}</section>`;
  }).join('');
}
async function addFiles(files) {
  const sid = ($('#upSub') || {}).value, kind = ($('#upKind') || {}).value || 'أخرى';
  if (!sid) { toast('اختر المقياس أولًا'); return; }
  let n = 0;
  for (const f of files) {
    if (!(f.type === 'application/pdf' || /\.pdf$/i.test(f.name))) { toast('PDF فقط: ' + f.name); continue; }
    try {
      const id = uid(); await FileDB.put({ id, blob: f });
      S.docs.push({ id, sid, kind, name: f.name.replace(/\.pdf$/i, ''), size: f.size, date: Date.now() }); n++;
    } catch (e) { toast('تعذّر حفظ ' + f.name); }
  }
  save(); if (n) { toast('تم حفظ ' + n + (n === 1 ? ' ملف' : ' ملفات')); libFilter = ''; render(); }
}
async function getDocBlob(id) { const rec = await FileDB.get(id); return rec && rec.blob; }
async function openDoc(id) {
  const d = S.docs.find(x => x.id === id), blob = await getDocBlob(id);
  if (!d || !blob) { toast('الملف غير موجود'); return; }
  const url = URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }));
  $('#modal').innerHTML = `<div class="scrim viewer"><div class="vbar"><b>${esc(d.name)}</b><a class="btn ghost small" href="${url}" download="${esc(d.name)}.pdf">${ic('download', 16)} تنزيل</a><button class="icon" data-close aria-label="إغلاق">${ic('x')}</button></div><iframe src="${url}" title="${esc(d.name)}"></iframe></div>`;
  onClose = () => URL.revokeObjectURL(url);
}
async function dlDoc(id) {
  const d = S.docs.find(x => x.id === id), blob = await getDocBlob(id); if (!d || !blob) return;
  const url = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = url; a.download = d.name + '.pdf'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 2000);
}

/* ───────── المقاييس ───────── */
function vSubjects() {
  const cards = S.subjects.map(s => {
    const n = { se: S.sessions.filter(x => x.sid === s.id).length, d: S.docs.filter(x => x.sid === s.id).length, t: S.tasks.filter(x => x.sid === s.id && !x.done).length };
    return `<article class="subj" style="--c:${s.color}"><div class="grow"><b>${esc(s.name)}</b>
      <span class="meta"><span>المعامل ${s.coef}</span>${s.hasTD ? '<span>TD</span>' : ''}${s.hasTP ? '<span>TP</span>' : ''}<span>${s.hasTD || s.hasTP ? 'المراقبة ' + s.wCC + '٪ / الامتحان ' + (100 - s.wCC) + '٪' : 'امتحان فقط'}</span></span>
      <small>${n.se} حصة، ${n.d} ملف، ${n.t} مهمة قيد الإنجاز</small></div>
      <div class="row-acts"><button class="icon" data-act="editSubject" data-id="${s.id}" aria-label="تعديل">${ic('edit', 17)}</button><button class="icon" data-act="delSubject" data-id="${s.id}" aria-label="حذف">${ic('trash', 17)}</button></div></article>`;
  }).join('');
  return head('المقاييس', 'أساس كل شيء: الجدول والواجبات والمعدل والمكتبة', `<button class="btn primary" data-act="addSubject">${ic('plus', 18)} مقياس</button>`)
    + (cards ? `<div class="subjs">${cards}</div>` : empty('لا مقاييس بعد', 'أضف مقياسًا مع معامله وطريقة حساب معدله.'));
}
function subjectForm(x) {
  const edit = !!x; const v = x || { coef: 1, hasTD: true, hasTP: false, wCC: 40, color: COLORS[S.subjects.length % COLORS.length] };
  modal(edit ? 'تعديل المقياس' : 'مقياس جديد', `<div class="grid2">
    ${fld('اسم المقياس', `<input name="name" value="${esc(v.name || '')}" required placeholder="مثال: الإحصاء">`, 'span2')}
    ${fld('المعامل', `<input type="number" name="coef" min="0.5" max="10" step="0.5" value="${v.coef}" required>`)}
    ${fld('نسبة المراقبة المستمرة ٪', `<input type="number" name="wCC" min="0" max="100" step="5" value="${v.wCC}">`)}
    <div class="fld span2"><span>مكوّنات المراقبة المستمرة</span><div class="checks"><label><input type="checkbox" name="hasTD" ${v.hasTD ? 'checked' : ''}> TD</label><label><input type="checkbox" name="hasTP" ${v.hasTP ? 'checked' : ''}> TP</label></div><small class="muted">الافتراضي: 40٪ مراقبة و60٪ امتحان. عدّلها حسب نظام كليتك.</small></div>
    <div class="fld span2"><span>اللون</span><div class="swatches">${COLORS.map(c => `<label><input type="radio" name="color" value="${c}" ${c === v.color ? 'checked' : ''}><i style="background:${c}"></i></label>`).join('')}</div></div>
  </div>`, f => {
    const o = { name: f.get('name').trim(), coef: +f.get('coef') || 1, wCC: Math.min(100, Math.max(0, +f.get('wCC') || 0)), hasTD: f.has('hasTD'), hasTP: f.has('hasTP'), color: f.get('color') || COLORS[0] };
    if (edit) Object.assign(x, o); else S.subjects.push({ id: uid(), g: {}, ...o });
    save(); render();
  });
}

/* ───────── الإعدادات ───────── */
function settings() {
  const perm = 'Notification' in window ? Notification.permission : 'unsupported';
  modal('الإعدادات', `<div class="set">
    <label class="row"><span>الوضع الداكن</span><input type="checkbox" id="darkT" ${S.dark ? 'checked' : ''}></label>
    <div class="row"><span>إشعارات التذكير <small class="muted">(${perm === 'granted' ? 'مفعّلة' : perm === 'denied' ? 'محظورة من المتصفح' : perm === 'unsupported' ? 'غير مدعومة' : 'غير مفعّلة'})</small></span>${perm === 'default' ? '<button type="button" class="btn small" data-act="askNotif">تفعيل</button>' : ''}</div>
    <div class="row"><span>نسخة احتياطية للبيانات <small class="muted">(بدون ملفات PDF)</small></span><span><button type="button" class="btn small" data-act="exportData">تصدير</button> <label class="btn small">استيراد<input type="file" id="imp" accept=".json" hidden></label></span></div>
    <div class="row"><span>مسح كل البيانات والملفات</span><button type="button" class="btn small danger" data-act="resetAll">مسح</button></div>
    <p class="muted">التذكيرات تعمل عندما يكون التطبيق مفتوحًا في المتصفح.</p></div>`, null, { ok: null, noFocus: true });
}
function exportData() {
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(S)], { type: 'application/json' }));
  a.download = 'dafatri-backup.json'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

/* ───────── التذكيرات ───────── */
function notify(title, body) {
  toast(title + (body ? ': ' + body : ''), true);
  if ('Notification' in window && Notification.permission === 'granted') { try { new Notification(title, { body, icon: 'icons/icon-192.png' }); } catch (e) { /* ignore */ } }
}
function checkReminders() {
  const now = Date.now(); let changed = false;
  S.tasks.forEach(t => {
    const k = 't' + t.id; if (t.done || S.notified[k] || t.remind < 0 || !t.due) return;
    const due = new Date(t.due).getTime(), at = due - t.remind * 60000;
    if (now >= at) { S.notified[k] = 1; changed = true; if (now < due + 864e5) notify('تذكير: ' + t.title, 'موعد التسليم ' + fmtDT(t.due)); }
  });
  S.exams.forEach(e => {
    const k = 'e' + e.id; if (S.notified[k]) return;
    const ts = examTs(e), at = ts - 864e5;
    if (now >= at) { S.notified[k] = 1; changed = true; if (now < ts) notify('امتحان قريب: ' + ((sub(e.sid) || {}).name || ''), fmtD(e.date) + (e.time ? ' الساعة ' + e.time : '')); }
  });
  if (changed) save();
}

/* ───────── التوجيه والعرض ───────── */
const VIEWS = { home: vHome, schedule: vSchedule, tasks: vTasks, grades: vGrades, library: vLibrary, subjects: vSubjects };
function render() {
  const v = (location.hash || '#home').slice(1); const name = VIEWS[v] ? v : 'home';
  $('#view').innerHTML = VIEWS[name]();
  $$('#nav a').forEach(a => a.classList.toggle('on', a.dataset.v === name));
  if (name === 'grades') refreshGrades();
  document.documentElement.dataset.theme = S.dark ? 'dark' : 'light';
}
$('#nav').innerHTML = NAV.map(([k, l, i]) => `<a href="#${k}" data-v="${k}">${ic(i, 22)}<span>${l}</span></a>`).join('');
window.addEventListener('hashchange', () => { render(); window.scrollTo(0, 0); });

/* ───────── الأحداث ───────── */
const find = (arr, el) => arr.find(x => x.id === el.dataset.id);
const A = {
  tab: el => { schedTab = el.dataset.v; render(); },
  tfilter: el => { taskFilter = el.dataset.v; render(); },
  settings,
  askNotif: async () => { if ('Notification' in window) { await Notification.requestPermission(); closeModal(); render(); } },
  exportData,
  resetAll: () => ask('سيتم حذف كل المقاييس والجداول والواجبات والملفات نهائيًا. هل أنت متأكد؟', async () => { localStorage.removeItem(KEY); try { await FileDB.clear(); } catch (e) { /* ignore */ } S = blank(); location.hash = '#home'; render(); }),
  addSession: () => sessionForm(), editSession: el => sessionForm(find(S.sessions, el)),
  delSession: el => ask('حذف هذه الحصة؟', () => { S.sessions = S.sessions.filter(x => x.id !== el.dataset.id); save(); render(); }),
  addExam: () => examForm(), editExam: el => examForm(find(S.exams, el)),
  delExam: el => ask('حذف هذا الامتحان؟', () => { S.exams = S.exams.filter(x => x.id !== el.dataset.id); save(); render(); }),
  addTask: () => taskForm(), editTask: el => taskForm(find(S.tasks, el)),
  delTask: el => ask('حذف هذه المهمة؟', () => { S.tasks = S.tasks.filter(x => x.id !== el.dataset.id); save(); render(); }),
  toggleTask: el => { const t = find(S.tasks, el); t.done = !t.done; save(); render(); },
  addSubject: () => subjectForm(), editSubject: el => subjectForm(find(S.subjects, el)),
  delSubject: el => ask('حذف المقياس سيحذف أيضًا حصصه وامتحاناته ومهامه وملفاته. متابعة؟', async () => {
    const id = el.dataset.id;
    for (const d of S.docs.filter(d => d.sid === id)) { try { await FileDB.del(d.id); } catch (e) { /* ignore */ } }
    ['sessions', 'exams', 'tasks', 'docs'].forEach(k => { S[k] = S[k].filter(x => x.sid !== id); });
    S.subjects = S.subjects.filter(s => s.id !== id); save(); render();
  }),
  openDoc: el => openDoc(el.dataset.id), dlDoc: el => dlDoc(el.dataset.id),
  editDoc: el => {
    const d = find(S.docs, el);
    modal('تعديل الملف', `<div class="grid2">${fld('الاسم', `<input name="name" value="${esc(d.name)}" required>`, 'span2')}${fld('المقياس', subSel(d.sid))}${fld('النوع', sel('kind', DOC_KINDS.map(k => [k, k]), d.kind))}</div>`,
      f => { d.name = f.get('name').trim(); d.sid = f.get('sid'); d.kind = f.get('kind'); save(); render(); });
  },
  delDoc: el => ask('حذف هذا الملف من جهازك؟', async () => { try { await FileDB.del(el.dataset.id); } catch (e) { /* ignore */ } S.docs = S.docs.filter(x => x.id !== el.dataset.id); save(); render(); })
};

document.addEventListener('click', e => {
  if (e.target.closest('[data-close]')) { closeModal(); return; }
  if (e.target.classList.contains('scrim') && !e.target.classList.contains('viewer')) { closeModal(); return; }
  const el = e.target.closest('[data-act]'); if (el && A[el.dataset.act]) A[el.dataset.act](el);
});
document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#modal').innerHTML) closeModal(); });
document.addEventListener('input', e => {
  const t = e.target, k = t.dataset && t.dataset.in;
  if (k === 'grade') {
    const s = sub(t.dataset.sid); if (!s) return;
    s.g = s.g || {}; let v = t.value;
    if (v !== '' && (+v < 0 || +v > 20)) { v = String(Math.min(20, Math.max(0, +v))); t.value = v; }
    s.g[t.dataset.k] = v; save(); refreshGrades();
  } else if (k === 'libQ') { libQ = t.value; $('#libList').innerHTML = libList(); }
});
document.addEventListener('change', e => {
  const t = e.target, k = t.dataset && t.dataset.in;
  if (k === 'libSub') libSub = t.value;
  else if (k === 'libFilter') { libFilter = t.value; $('#libList').innerHTML = libList(); }
  else if (t.id === 'pdfs') { addFiles([...t.files]); t.value = ''; }
  else if (t.id === 'darkT') { S.dark = t.checked; save(); render(); }
  else if (t.id === 'imp') {
    const f = t.files[0]; if (!f) return;
    const r = new FileReader();
    r.onload = () => { try { const d = JSON.parse(r.result); if (!Array.isArray(d.subjects)) throw 0; S = Object.assign(blank(), d); save(); closeModal(); render(); toast('تم استيراد البيانات'); } catch (err) { toast('ملف غير صالح'); } };
    r.readAsText(f);
  }
});
document.addEventListener('dragover', e => { if (e.target.closest('#drop')) { e.preventDefault(); $('#drop').classList.add('over'); } });
document.addEventListener('dragleave', e => { if (e.target.closest('#drop')) $('#drop').classList.remove('over'); });
document.addEventListener('drop', e => { if (e.target.closest('#drop')) { e.preventDefault(); $('#drop').classList.remove('over'); addFiles([...e.dataTransfer.files]); } });

/* ───────── تشغيل ───────── */
render();
checkReminders();
setInterval(() => { checkReminders(); if (!$('#modal').innerHTML && (location.hash || '#home') === '#home') render(); }, 60000);
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
