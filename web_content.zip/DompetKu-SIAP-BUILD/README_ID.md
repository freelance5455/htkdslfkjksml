# DompetKu — ZIP Siap Build di HP

Ini adalah project Android DompetKu yang siap diekstrak lalu dibuka di aplikasi Android builder/IDE di HP.

## Cara pakai
1. Ekstrak ZIP ini.
2. Buka folder `DompetKu-SIAP-BUILD` sebagai **Gradle/Android Project** di aplikasi builder Android di HP.
3. Tunggu Gradle/komponen Android selesai disiapkan jika aplikasi builder memintanya.
4. Pilih module `app`.
5. Build APK (debug/release sesuai kebutuhan).
6. Instal APK hasil build.

## Isi aplikasi
- DompetKu offline/local.
- Akun/sumber dana.
- Pemasukan, pengeluaran, transfer antar akun.
- Kategori pengeluaran.
- Target Pengeluaran.
- Target Dana dengan pilihan radio tujuan seperti versi lama.
- Target Dana: Menikah, Rumah, Dana Darurat, Dana Cadangan, Restorasi Motor, Touring, Kendaraan, Pendidikan, Liburan, Gadget, Renovasi, Modal Usaha, Sedekah, Keinginan, Investasi, Kebutuhan Keluarga, Lainnya.
- Tanggal mulai/selesai manual.
- Lokasi penyimpanan target: Cash/Tunai, Bank, E-Wallet, Lainnya.
- Progress target dan kebutuhan per bulan/minggu/hari.
- Riwayat transaksi dan penambahan dana target.
- Grafik keuangan.
- Backup/restore lokal.

Tidak membutuhkan login, server, sinkronisasi bank, atau cloud untuk penggunaan inti.
