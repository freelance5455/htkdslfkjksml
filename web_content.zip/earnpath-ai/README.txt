EARNPATH AI — WEBSITE STARTER

Files:
- index.html: website structure and content
- style.css: responsive styling for mobile and desktop
- script.js: navigation, earning-path cards, and free starter-plan generator

CURRENT STATUS
This is a working front-end prototype. The planner runs in the visitor's browser. It does not yet use a live AI model, store accounts, collect payments, or publish the website to the internet. Do not advertise it as a live AI service until a backend is connected and tested.

FREE DEPLOYMENT OPTION
1. Keep all three website files in the same folder.
2. Upload the folder to a static hosting service such as GitHub Pages, Cloudflare Pages, or Netlify's manual deploy.
3. Publish the site and test it on a phone.
4. For a real AI assistant later, connect a secure backend. Never place a private API key in script.js or any browser-visible file.

EARNING MODEL TO ADD AFTER VALIDATION
- Free starter planner to attract visitors.
- Optional paid downloadable guides or practical mini-courses.
- Carefully selected affiliate links, clearly disclosed.
- Later, a paid advanced planning service only after useful features are proven.

IMPORTANT
No income is guaranteed. Do not promise visitors earnings, and do not ask them to pay for jobs or guaranteed opportunities.
