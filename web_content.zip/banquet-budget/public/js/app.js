import { html, render, useState, useEffect, api, store, loadCatalog, loadSettings, setUnauthorizedHandler, Toaster, useStore, toastErr } from './lib.js';
import { Dashboard } from './pages/dashboard.js';
import { EventsList, EventPage } from './pages/events.js';
import { MealEditor } from './pages/meal.js';
import { RecipesList, RecipeEditor } from './pages/recipes.js';
import { IngredientsPage, SuppliersPage } from './pages/ingredients.js';
import { MenuImport } from './pages/import.js';
import { SettingsPage } from './pages/settings.js';
import { QuotePrint } from './pages/quote.js';

function parseRoute() {
  const h = location.hash.replace(/^#\/?/, '');
  return h.split('?')[0].split('/').filter(Boolean);
}

function Login({ onDone }) {
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true); setErr('');
    try { const r = await api('/auth/login', { method: 'POST', body: { email, password: pw } }); onDone(r.user); }
    catch (x) { setErr(x.message); }
    setBusy(false);
  };
  return html`<div class="login"><form onSubmit=${submit}>
    <div><div class="eyebrow">The Palayana Hua Hin</div><h1>Banquet Budget</h1></div>
    <label class="f">Email<input class="in" type="email" autocomplete="username" required value=${email} onInput=${(e) => setEmail(e.target.value)} /></label>
    <label class="f">Password<input class="in" type="password" autocomplete="current-password" required value=${pw} onInput=${(e) => setPw(e.target.value)} /></label>
    ${err && html`<div class="err" role="alert">${err}</div>`}
    <button class="btn primary" disabled=${busy} style="justify-content:center">${busy ? 'Signing in…' : 'Sign in'}</button>
  </form></div>`;
}

const NAV = [
  ['', 'Dashboard'], ['events', 'Events & budgets'], ['import', 'Import a menu'],
  ['grp', 'Kitchen'], ['recipes', 'Recipe library'], ['ingredients', 'Ingredients & prices'], ['suppliers', 'Suppliers'],
  ['grp', 'Admin'], ['settings', 'Settings & users'],
];

function Shell({ route }) {
  const s = useStore();
  const [open, setOpen] = useState(false);
  useEffect(() => setOpen(false), [route.join('/')]);
  const top = route[0] || '';
  let page;
  if (top === '') page = html`<${Dashboard} />`;
  else if (top === 'events' && route[1] && route[2] === 'meals' && route[3]) page = html`<${MealEditor} key=${route[3]} eventId=${+route[1]} mealId=${+route[3]} />`;
  else if (top === 'events' && route[1]) page = html`<${EventPage} key=${route[1]} id=${+route[1]} tab=${route[2] || ''} />`;
  else if (top === 'events') page = html`<${EventsList} />`;
  else if (top === 'recipes' && route[1]) page = html`<${RecipeEditor} key=${route[1]} id=${route[1] === 'new' ? null : +route[1]} />`;
  else if (top === 'recipes') page = html`<${RecipesList} />`;
  else if (top === 'ingredients') page = html`<${IngredientsPage} focus=${route[1] ? +route[1] : null} />`;
  else if (top === 'suppliers') page = html`<${SuppliersPage} />`;
  else if (top === 'import') page = html`<${MenuImport} eventId=${route[1] ? +route[1] : null} />`;
  else if (top === 'settings') page = html`<${SettingsPage} tab=${route[1] || ''} />`;
  else page = html`<div class="empty"><h2>Page not found</h2><p><a href="#/">Back to the dashboard</a></p></div>`;
  const logout = async () => { try { await api('/auth/logout', { method: 'POST', body: {} }); } catch {} location.reload(); };
  return html`<div class="shell">
    <aside class=${'side' + (open ? ' open' : '')}>
      <div class="brand"><b>Banquet Budget</b><span>The Palayana Hua Hin</span></div>
      <nav class="nav" aria-label="Main">
        ${NAV.map(([k, label]) => k === 'grp' ? html`<div class="grp">${label}</div>` : html`<a href=${'#/' + k} aria-current=${top === k ? 'page' : 'false'}>${label}</a>`)}
      </nav>
      <div class="me"><b>${s.user?.name}</b>${s.user?.role} · <a href="#/settings/account" style="color:inherit">My account</a><br/><button onClick=${logout}>Sign out</button></div>
    </aside>
    <div style="min-width:0">
      <div class="topbar"><button aria-label="Open menu" onClick=${() => setOpen(!open)}>☰</button><b style="font-family:var(--f-display);font-weight:400">Banquet Budget</b></div>
      <main class="main">${page}</main>
    </div>
  </div>`;
}

function App() {
  const [route, setRoute] = useState(parseRoute());
  const [phase, setPhase] = useState('boot');
  useEffect(() => {
    let skip = false;
    const h = () => {
      if (skip) { skip = false; return; }
      if (window.__dirty && !confirm('You have unsaved changes. Leave this page without saving?')) { skip = true; history.back(); return; }
      setRoute(parseRoute());
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', h);
    setUnauthorizedHandler(() => { store.user = null; setPhase('login'); });
    (async () => {
      try { const r = await api('/auth/me'); store.user = r.user; await Promise.all([loadSettings(), loadCatalog()]); setPhase('ready'); }
      catch { setPhase('login'); }
    })();
    return () => window.removeEventListener('hashchange', h);
  }, []);
  if (phase === 'boot') return html`<div class="boot">Loading…</div>`;
  if (phase === 'login') return html`<${Login} onDone=${async (u) => { store.user = u; try { await Promise.all([loadSettings(), loadCatalog()]); } catch (e) { toastErr(e); } setPhase('ready'); }} /><${Toaster} />`;
  if (route[0] === 'print' && route[1] === 'quote') return html`<${QuotePrint} id=${+route[2]} /><${Toaster} />`;
  return html`<${Shell} route=${route} /><${Toaster} />`;
}

render(html`<${App} />`, document.getElementById('app'));
