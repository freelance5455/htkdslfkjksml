import { html, useState, useEffect, useRef } from './lib.js';
import { STATUS } from './costing.js';

export const Chip = ({ c = 'ok', children, title }) => html`<span class=${'chip ' + c} title=${title || ''}>${children}</span>`;
export const PriceChip = ({ status, title }) => {
  const s = STATUS[status] || { t: status, c: 'ok' };
  return html`<${Chip} c=${s.c} title=${title}>${s.t}<//>`;
};
const DIET = { veg: 'Vegetarian', nonveg: 'Non-vegetarian', both: 'Veg & non-veg versions', egg: 'Contains egg' };
export const Diet = ({ d }) => (d ? html`<span class=${'diet ' + d} title=${DIET[d] || d} aria-label=${DIET[d] || d}></span>` : null);
export const EVENT_STATUS = { enquiry: ['Enquiry', 'ok'], quoted: ['Quoted', 'acc'], confirmed: ['Confirmed', 'good'], completed: ['Completed', 'est'], lost: ['Lost', 'bad'] };
export const EventStatus = ({ s }) => { const x = EVENT_STATUS[s] || [s, 'ok']; return html`<${Chip} c=${x[1]}>${x[0]}<//>`; };

export function Loading({ label = 'Loading…' }) {
  return html`<div class="muted" style="padding:30px 4px">${label}</div>`;
}
export function ErrorBox({ error, retry }) {
  return html`<div class="panel" style="border-color:var(--bad)"><b>Could not load this page.</b><p class="muted">${error?.message}</p>${retry && html`<button class="btn" onClick=${retry}>Try again</button>`}</div>`;
}
export function Empty({ title, children, action }) {
  return html`<div class="empty"><h2>${title}</h2><p>${children}</p>${action}</div>`;
}

export function Modal({ title, onClose, children, footer, wide }) {
  useEffect(() => {
    const h = (e) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
  return html`<div class="modal-bg" onMouseDown=${(e) => e.target === e.currentTarget && onClose()}>
    <div class=${'modal' + (wide ? ' wide' : '')} role="dialog" aria-modal="true" aria-label=${title}>
      <header><h2 style="flex:1">${title}</h2><button class="icon-btn" aria-label="Close" onClick=${onClose}>×</button></header>
      <div class="mb">${children}</div>
      ${footer && html`<footer>${footer}</footer>`}
    </div></div>`;
}

/** Two-step button: first click arms, second click confirms. */
export function ConfirmButton({ onConfirm, children, confirmText = 'Click again to confirm', cls = 'btn danger', disabled, title }) {
  const [armed, setArmed] = useState(false);
  useEffect(() => { if (!armed) return; const h = setTimeout(() => setArmed(false), 3500); return () => clearTimeout(h); }, [armed]);
  return html`<button type="button" class=${cls + (armed ? ' armed' : '')} disabled=${disabled} title=${title}
    onClick=${(e) => { e.stopPropagation(); if (armed) { setArmed(false); onConfirm(); } else setArmed(true); }}>${armed ? confirmText : children}</button>`;
}

export function Field({ label, children, cls = '' }) {
  return html`<label class=${'f ' + cls}>${label}${children}</label>`;
}

/** Numeric input that keeps the raw text while typing. */
export function NumIn({ value, onInput, cls = 'in', placeholder, step = 'any', min, disabled, ariaLabel, style }) {
  return html`<input type="number" class=${cls} step=${step} min=${min} value=${value ?? ''} placeholder=${placeholder} disabled=${disabled}
    aria-label=${ariaLabel} style=${style} onInput=${(e) => onInput(e.target.value === '' ? null : e.target.value)} />`;
}

/**
 * Search-as-you-type picker.
 * search(q) → [{key, label, sub, right, value}] ; onPick(value) ; extra(q) → optional extra option
 */
export function Combo({ value, placeholder, search, onPick, extra, disabled, ariaLabel, autoFocus }) {
  const [q, setQ] = useState(null);
  const [open, setOpen] = useState(false);
  const [i, setI] = useState(0);
  const [pos, setPos] = useState(null);
  const ref = useRef();
  const place = () => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const w = Math.min(Math.max(r.width, 420), window.innerWidth - 24);
    const left = Math.max(12, Math.min(r.left, window.innerWidth - w - 12));
    const below = window.innerHeight - r.bottom;
    setPos(below > 260 || below > r.top ? { left, width: w, top: r.bottom + 4, maxHeight: Math.min(330, below - 12) } : { left, width: w, bottom: window.innerHeight - r.top + 4, maxHeight: Math.min(330, r.top - 12) });
  };
  useEffect(() => {
    if (!open) return;
    place();
    const h = () => place();
    window.addEventListener('scroll', h, true);
    window.addEventListener('resize', h);
    return () => { window.removeEventListener('scroll', h, true); window.removeEventListener('resize', h); };
  }, [open]);
  const opts = open ? [...search(q ?? ''), ...(extra && q ? [extra(q)].filter(Boolean) : [])] : [];
  useEffect(() => { setI(0); }, [q]);
  useEffect(() => { if (autoFocus && ref.current) ref.current.focus(); }, []);
  const pick = (o) => { setOpen(false); setQ(null); onPick(o.value); };
  const key = (e) => {
    if (!open) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); setI(Math.min(opts.length - 1, i + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setI(Math.max(0, i - 1)); }
    else if (e.key === 'Enter') { e.preventDefault(); if (opts[i]) pick(opts[i]); }
    else if (e.key === 'Escape') { setOpen(false); setQ(null); }
  };
  return html`<div class="combo">
    <input ref=${ref} class="in bare" style="font-weight:500" value=${q ?? value ?? ''} placeholder=${placeholder} disabled=${disabled} aria-label=${ariaLabel}
      autocomplete="off" role="combobox" aria-expanded=${open}
      onFocus=${(e) => { setOpen(true); setQ(''); }} onBlur=${() => setTimeout(() => { setOpen(false); setQ(null); }, 150)}
      onInput=${(e) => { setQ(e.target.value); setOpen(true); }} onKeyDown=${key} />
    ${open && pos && html`<div class="combo-list" role="listbox" style=${{ position: 'fixed', left: pos.left + 'px', width: pos.width + 'px', top: pos.top != null ? pos.top + 'px' : 'auto', bottom: pos.bottom != null ? pos.bottom + 'px' : 'auto', maxHeight: pos.maxHeight + 'px' }}>
      ${!(q ?? '').trim() && html`<div class="hint">Type to search…</div>`}
      ${opts.map((o, j) => html`<div key=${o.key} class=${'o' + (j === i ? ' on' : '')} role="option" aria-selected=${j === i}
        onMouseDown=${(e) => { e.preventDefault(); pick(o); }} onMouseEnter=${() => setI(j)}>
        <div style="min-width:0"><b>${o.label}</b>${o.sub && html`<br/><small>${o.sub}</small>`}</div><div class="p">${o.right}</div></div>`)}
      ${(q ?? '').trim() && !opts.length && html`<div class="hint">No matches.</div>`}
    </div>`}
  </div>`;
}

export function Tabs({ tabs, current, base }) {
  return html`<nav class="tabs" aria-label="Sections">${tabs.map(([k, label]) => html`<a href=${base + (k ? '/' + k : '')} aria-current=${current === k ? 'page' : 'false'}>${label}</a>`)}</nav>`;
}

export function CostBar({ value, target, max = 60 }) {
  const w = Math.min(100, ((value || 0) / max) * 100);
  const c = value == null ? 'var(--line)' : value <= target ? 'var(--good)' : value <= target + 5 ? 'var(--warn)' : 'var(--bad)';
  return html`<div class="bar" aria-hidden="true"><i style=${`width:${w}%;background:${c}`}></i><b style=${`left:${Math.min(100, (target / max) * 100)}%`}></b></div>`;
}
