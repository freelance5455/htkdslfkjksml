// Core helpers: API client, formatting, global store, small hooks.
import { html, useState, useEffect, useRef, useCallback, render } from '/vendor/preact-htm.js';
export { html, useState, useEffect, useRef, useCallback, render };

// ---------- API ----------
export class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
let onUnauthorized = () => {};
export const setUnauthorizedHandler = (fn) => (onUnauthorized = fn);

export async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'X-Requested-With': 'banquet-budget', ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
    body: body !== undefined ? JSON.stringify(body) : undefined,
    credentials: 'same-origin',
  });
  let data = null;
  try { data = await res.json(); } catch { /* empty */ }
  if (res.status === 401 && path !== '/auth/login') onUnauthorized();
  if (!res.ok) throw new ApiError(res.status, data?.error || `Request failed (${res.status}).`);
  return data;
}
export const fileToBase64 = (file) => new Promise((resolve, reject) => {
  const r = new FileReader();
  r.onload = () => resolve(String(r.result).split(',')[1]);
  r.onerror = () => reject(new Error('Could not read the file.'));
  r.readAsDataURL(file);
});

// ---------- formatting ----------
export const n = (v) => { const x = Number(v); return isFinite(x) ? x : 0; };
export function fmt(v, d = 2) {
  if (v === null || v === undefined || !isFinite(v)) return '–';
  return Number(v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
}
export const baht = (v, d = 2) => (v === null || v === undefined || !isFinite(v) ? '–' : '฿' + fmt(v, d));
export const pct = (v, d = 1) => (v === null || v === undefined || !isFinite(v) ? '–' : fmt(v, d) + '%');
export function fmtRate(p) { if (p === null || p === undefined) return '–'; return p < 1 ? fmt(p, 3) : fmt(p, 2); }
export function fmtDate(s, opts = { day: 'numeric', month: 'short', year: 'numeric' }) {
  if (!s) return '';
  const d = new Date(String(s).slice(0, 10) + 'T00:00:00');
  return isNaN(d) ? s : d.toLocaleDateString('en-GB', opts);
}
export const fmtDay = (s) => fmtDate(s, { weekday: 'short', day: 'numeric', month: 'short' });
export const baseLabel = (b) => ({ Kg: 'kg', Gms: 'g', Lit: 'L', Ml: 'ml', No: 'pc', portion: 'portion' }[b] || String(b || '').toLowerCase());
export function costClass(p, target) {
  if (p === null || p === undefined) return 'ok';
  if (p <= target) return 'good';
  if (p <= target + 5) return 'warn';
  return 'bad';
}
export const uid = () => 'k' + Math.random().toString(36).slice(2, 10);

// ---------- store (catalogue, settings, user) ----------
const listeners = new Set();
export const store = { user: null, settings: null, catalog: null, catVersion: 0 };
export function emit() { store.catVersion++; listeners.forEach((f) => f()); }
export function useStore() {
  const [, set] = useState(0);
  useEffect(() => { const f = () => set((x) => x + 1); listeners.add(f); return () => listeners.delete(f); }, []);
  return store;
}
export async function loadCatalog() {
  const c = await api('/catalog');
  c.ingById = new Map(c.ingredients.map((i) => [i.id, i]));
  c.recById = new Map(c.recipes.map((r) => [r.id, r]));
  c.ingSearch = c.ingredients.map((i) => ({ i, s: (i.code + ' ' + i.name + ' ' + (i.aliases || '')).toLowerCase() }));
  c.recSearch = c.recipes.map((r) => ({ r, s: (r.name + ' ' + (r.aliases || '') + ' ' + r.section).toLowerCase() }));
  store.catalog = c;
  emit();
  return c;
}
export async function loadSettings() { store.settings = await api('/settings'); emit(); }

export const CAN = {
  recipes: ['admin', 'manager', 'chef'],
  ingredients: ['admin', 'manager', 'purchasing'],
  events: ['admin', 'manager', 'sales', 'chef'],
  deleteEvents: ['admin', 'manager'],
  settings: ['admin'],
  users: ['admin'],
};
export const can = (what) => !!store.user && CAN[what].includes(store.user.role);

// ---------- toast ----------
let toastSet = null;
export function Toaster() {
  const [t, setT] = useState(null);
  toastSet = setT;
  useEffect(() => { if (!t) return; const h = setTimeout(() => setT(null), t.err ? 5000 : 2600); return () => clearTimeout(h); }, [t]);
  return t ? html`<div class=${'toast' + (t.err ? ' err' : '')} role="status">${t.msg}</div>` : null;
}
export const toast = (msg, err = false) => toastSet && toastSet({ msg, err, at: Date.now() });
export const toastErr = (e) => toast(e?.message || String(e), true);

// ---------- hooks ----------
export function useFetch(path, deps = []) {
  const [state, setState] = useState({ data: null, error: null, loading: true });
  const reload = useCallback(async () => {
    try {
      const data = await api(path);
      setState({ data, error: null, loading: false });
      return data;
    } catch (e) {
      setState({ data: null, error: e, loading: false });
    }
  }, [path]);
  useEffect(() => { setState((s) => ({ ...s, loading: true })); reload(); }, [path, ...deps]);
  return { ...state, reload, setData: (d) => setState((s) => ({ ...s, data: typeof d === 'function' ? d(s.data) : d })) };
}

/** Warn before leaving the page with unsaved changes. */
export function useDirtyGuard(dirty) {
  useEffect(() => {
    const h = (e) => { if (dirty) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', h);
    window.__dirty = dirty;
    return () => { window.removeEventListener('beforeunload', h); window.__dirty = false; };
  }, [dirty]);
}

export const go = (hash) => { location.hash = hash; };
