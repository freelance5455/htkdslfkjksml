// Shared costing engine — used by the server (reports, exports) and the browser (live editing).
// All money in THB. Ingredient prices are per ingredient base unit (Kg, Gms, Lit, Ml, No, Pack, ...).

const LINE_UNITS = { g: ['m', 1], kg: ['m', 1000], ml: ['v', 1], L: ['v', 1000] };

export function baseDim(base) {
  if (base === 'Kg') return ['m', 1000];
  if (base === 'Gms') return ['m', 1];
  if (base === 'Lit') return ['v', 1000];
  if (base === 'Ml') return ['v', 1];
  return ['c:' + base, 1];
}

/** Units a line may use for an item whose base unit is `base`. */
export function unitsFor(base) {
  const [d] = baseDim(base);
  if (d === 'm') return base === 'Gms' ? ['g', 'kg'] : ['g', 'kg'];
  if (d === 'v') return ['ml', 'L'];
  return [base];
}

/** Convert qty in line unit to the item's base unit. Returns null if incompatible. */
export function toBase(qty, unit, base) {
  const q = Number(qty);
  if (!isFinite(q)) return null;
  const lu = LINE_UNITS[unit];
  const [bd, bf] = baseDim(base);
  if (lu) {
    if (lu[0] !== bd) return null;
    return (q * lu[1]) / bf;
  }
  return unit === base ? q : null;
}

/** Base unit implied by a custom line unit. */
export const customBase = (u) => (u === 'g' || u === 'kg' ? 'Kg' : u === 'ml' || u === 'L' ? 'Lit' : u || 'No');

/** Base unit of a sub-recipe from its yield unit (kg, L, portion). */
export const subBase = (r) => (r.yield_unit === 'kg' ? 'Kg' : r.yield_unit === 'L' ? 'Lit' : 'portion');

export const STATUS = {
  list: { t: 'List price', c: 'ok' },
  direct: { t: 'Direct price', c: 'good' },
  updated: { t: 'Updated', c: 'good' },
  confirm: { t: 'To confirm', c: 'warn' },
  estimate: { t: 'Estimate', c: 'est' },
  none: { t: 'No price', c: 'bad' },
  line: { t: 'Line rate', c: 'acc' },
  custom: { t: 'Custom', c: 'acc' },
};

const n = (v) => {
  const x = Number(v);
  return isFinite(x) ? x : 0;
};

/**
 * Build a costing context.
 * ingredients: [{id, unit, price, price_status}]
 * recipes: [{id, yield_pax, is_sub, yield_qty, yield_unit, lines:[...]}]
 */
export function makeCtx(ingredients, recipes) {
  const ing = new Map(ingredients.map((i) => [i.id, i]));
  const rec = new Map(recipes.map((r) => [r.id, r]));
  return { ing, rec, memo: new Map() };
}

/** Cost one recipe line. Returns {cost, base, qtyBase, status, unitOk} */
export function lineCost(line, ctx, stack) {
  const qty = n(line.qty);
  const hasRate = line.rate_override !== null && line.rate_override !== undefined && line.rate_override !== '';
  if (line.ingredient_id) {
    const it = ctx.ing.get(line.ingredient_id);
    if (!it) return { cost: 0, status: 'none', unitOk: false };
    const qb = toBase(qty, line.unit, it.unit);
    const price = hasRate ? n(line.rate_override) : it.price;
    const status = hasRate ? 'line' : price == null ? 'none' : it.price_status || 'list';
    if (qb == null) return { cost: 0, status, unitOk: false, base: it.unit };
    return { cost: price == null ? 0 : qb * price, qtyBase: qb, base: it.unit, price, status, unitOk: true };
  }
  if (line.sub_recipe_id) {
    const sub = ctx.rec.get(line.sub_recipe_id);
    if (!sub) return { cost: 0, status: 'none', unitOk: false };
    const sb = subBase(sub);
    const qb = sb === 'portion' ? (line.unit === 'portion' ? qty : null) : toBase(qty, line.unit, sb);
    const rc = recipeCost(sub, ctx, stack);
    const yq = sb === 'portion' ? n(sub.yield_pax) || 1 : n(sub.yield_qty) || 1;
    const per = rc.total / yq;
    if (qb == null) return { cost: 0, status: rc.cycle ? 'none' : 'list', unitOk: false, base: sb };
    return { cost: qb * per, qtyBase: qb, base: sb, price: per, status: rc.issues.none ? 'none' : rc.issues.confirm ? 'confirm' : rc.issues.estimate ? 'estimate' : 'list', unitOk: true, sub: true };
  }
  if (line.custom_name) {
    const b = customBase(line.unit);
    const qb = toBase(qty, line.unit, b);
    const price = hasRate ? n(line.rate_override) : null;
    return { cost: price == null || qb == null ? 0 : qb * price, qtyBase: qb, base: b, price, status: price == null ? 'none' : 'custom', unitOk: qb != null };
  }
  return { cost: 0, status: 'empty', unitOk: true };
}

/** Cost a recipe (memoised in ctx). Returns {total, perPortion, perBase, issues, cycle} */
export function recipeCost(recipe, ctx, stack = new Set()) {
  if (ctx.memo.has(recipe.id)) return ctx.memo.get(recipe.id);
  if (stack.has(recipe.id)) return { total: 0, perPortion: 0, perBase: 0, issues: { none: 1, confirm: 0, estimate: 0 }, cycle: true };
  stack.add(recipe.id);
  let total = 0;
  const issues = { none: 0, confirm: 0, estimate: 0 };
  for (const l of recipe.lines || []) {
    const c = lineCost(l, ctx, stack);
    total += c.cost;
    if (n(l.qty) > 0 && issues[c.status] !== undefined) issues[c.status]++;
    if (!c.unitOk) issues.none++;
  }
  stack.delete(recipe.id);
  const yp = n(recipe.yield_pax) || 1;
  const res = {
    total,
    perPortion: total / yp,
    perBase: recipe.is_sub ? total / (subBase(recipe) === 'portion' ? yp : n(recipe.yield_qty) || 1) : null,
    issues,
  };
  ctx.memo.set(recipe.id, res);
  return res;
}

/** Item cost for a meal item, given recipe cost-per-portion lookup. */
export function itemCost(item, meal, perPortionOf) {
  const pax = n(meal.pax);
  const portions = item.portions != null && item.portions !== '' ? n(item.portions) : pax;
  const f = (item.factor == null || item.factor === '' ? 100 : n(item.factor)) / 100;
  let pp = 0;
  if (item.recipe_id) pp = perPortionOf(item.recipe_id) ?? 0;
  else pp = n(item.cost_per_portion);
  const total = pp * portions * f;
  return { perPortion: pp, portions, factor: f, total, perPax: pax ? total / pax : 0 };
}

export function taxFactor(settings) {
  return (1 + n(settings.service_pct) / 100) * (1 + n(settings.vat_pct) / 100);
}

/** Revenue excluding service charge & VAT for an amount quoted on the event's price basis. */
export function netRevenue(amount, event, settings) {
  return event.price_basis === 'net' ? amount / taxFactor(settings) : amount;
}

/** Full meal summary. */
export function mealSummary(meal, event, settings, perPortionOf, extras = { labour: 0, costs: 0 }) {
  const pax = n(meal.pax);
  const items = (meal.items || []).map((it) => ({ ...itemCost(it, meal, perPortionOf), section: it.section, id: it.id }));
  const food = items.reduce((a, b) => a + b.total, 0);
  const w = meal.wastage_pct != null && meal.wastage_pct !== '' ? n(meal.wastage_pct) : n(event.wastage_pct);
  const waste = (food * w) / 100;
  const sections = {};
  for (const it of items) sections[it.section || 'Other'] = (sections[it.section || 'Other'] || 0) + it.total;
  const quoted = meal.chargeable === 0 || meal.chargeable === false ? 0 : (n(meal.price_per_pax) + n(meal.bev_price_per_pax)) * pax;
  const revenue = netRevenue(quoted, event, settings);
  const foodCost = food + waste;
  const totalCost = foodCost + n(extras.labour) + n(extras.costs);
  return {
    pax, items, food, waste, wastagePct: w, foodCost, sections,
    labour: n(extras.labour), costs: n(extras.costs), totalCost,
    foodPerPax: pax ? foodCost / pax : 0, costPerPax: pax ? totalCost / pax : 0,
    quoted, revenue, foodPct: revenue ? (foodCost / revenue) * 100 : null, costPct: revenue ? (totalCost / revenue) * 100 : null,
    gp: revenue - totalCost,
  };
}

export const labourAmount = (l) => n(l.headcount) * n(l.rate);
export const costAmount = (c) => n(c.qty) * n(c.rate);

/** Event summary. event: {..., meals:[{items}], labour:[], costs:[], revenue_items:[]} */
export function eventSummary(event, settings, perPortionOf) {
  const labourBy = {}, costBy = {};
  let labourEvent = 0, costEvent = 0;
  for (const l of event.labour || []) {
    const a = labourAmount(l);
    if (l.meal_id) labourBy[l.meal_id] = (labourBy[l.meal_id] || 0) + a; else labourEvent += a;
  }
  for (const c of event.costs || []) {
    const a = costAmount(c);
    if (c.meal_id) costBy[c.meal_id] = (costBy[c.meal_id] || 0) + a; else costEvent += a;
  }
  const meals = (event.meals || []).map((m) => ({ id: m.id, name: m.name, date: m.date, ...mealSummary(m, event, settings, perPortionOf, { labour: labourBy[m.id] || 0, costs: costBy[m.id] || 0 }) }));
  const extraQuoted = (event.revenue_items || []).reduce((a, r) => a + n(r.qty) * n(r.unit_price), 0);
  const extraRevenue = netRevenue(extraQuoted, event, settings);
  const sum = (k) => meals.reduce((a, m) => a + m[k], 0);
  const food = sum('foodCost');
  const labour = sum('labour') + labourEvent;
  const costs = sum('costs') + costEvent;
  const totalCost = food + labour + costs;
  const quoted = sum('quoted') + extraQuoted;
  const revenue = sum('revenue') + extraRevenue;
  const tf = taxFactor(settings);
  const clientTotal = event.price_basis === 'net' ? quoted : quoted * tf;
  const costCats = {};
  for (const c of event.costs || []) costCats[c.category || 'Other'] = (costCats[c.category || 'Other'] || 0) + costAmount(c);
  return {
    meals, food, labour, costs, labourEvent, costEvent, totalCost, quoted, revenue, extraRevenue, clientTotal,
    serviceCharge: event.price_basis === 'net' ? 0 : quoted * (n(settings.service_pct) / 100),
    vat: event.price_basis === 'net' ? 0 : quoted * (1 + n(settings.service_pct) / 100) * (n(settings.vat_pct) / 100),
    gp: revenue - totalCost, costPct: revenue ? (totalCost / revenue) * 100 : null, foodPct: revenue ? (food / revenue) * 100 : null,
    costCats,
  };
}

/** Purchase list for an event. Returns rows keyed by ingredient / custom name. */
export function purchaseList(event, ctx, opts = {}) {
  const rows = new Map();
  const add = (key, init, qty, cost, mealDate, dish) => {
    const r = rows.get(key) || { ...init, qty: 0, cost: 0, dates: new Set(), dishes: new Set() };
    r.qty += qty; r.cost += cost;
    if (mealDate) r.dates.add(mealDate);
    if (dish) r.dishes.add(dish);
    rows.set(key, r);
  };
  const expand = (recipe, scale, mealDate, dish, depth = 0) => {
    if (depth > 8) return;
    for (const l of recipe.lines || []) {
      const c = lineCost(l, ctx, new Set());
      if (!c.unitOk || c.qtyBase == null) continue;
      if (l.ingredient_id) {
        const it = ctx.ing.get(l.ingredient_id);
        add('i' + it.id, { ingredient_id: it.id, code: it.code, name: it.name, category: it.category, supplier: it.supplier_name || '', base: it.unit, price: c.price, status: c.status },
          c.qtyBase * scale, c.cost * scale, mealDate, dish);
      } else if (l.sub_recipe_id) {
        const sub = ctx.rec.get(l.sub_recipe_id);
        const yq = subBase(sub) === 'portion' ? n(sub.yield_pax) || 1 : n(sub.yield_qty) || 1;
        expand(sub, (c.qtyBase / yq) * scale, mealDate, dish, depth + 1);
      } else if (l.custom_name) {
        add('c' + l.custom_name.toLowerCase(), { ingredient_id: null, code: '', name: l.custom_name, category: 'Custom (not in price list)', supplier: '', base: c.base, price: c.price, status: c.status },
          c.qtyBase * scale, c.cost * scale, mealDate, dish);
      }
    }
  };
  for (const m of event.meals || []) {
    if (opts.mealId && m.id !== opts.mealId) continue;
    const w = 1 + (m.wastage_pct != null && m.wastage_pct !== '' ? n(m.wastage_pct) : n(event.wastage_pct)) / 100;
    for (const it of m.items || []) {
      if (!it.recipe_id) continue;
      const r = ctx.rec.get(it.recipe_id);
      if (!r) continue;
      const ic = itemCost(it, m, () => 0);
      const scale = (ic.portions * ic.factor * w) / (n(r.yield_pax) || 1);
      expand(r, scale, m.date, it.name || r.name);
    }
  }
  return [...rows.values()].map((r) => ({ ...r, dates: [...r.dates].sort(), dishes: [...r.dishes] }))
    .sort((a, b) => (a.category || '').localeCompare(b.category || '') || a.name.localeCompare(b.name));
}

export function fmtQty(q, base) {
  const f = (v, d) => v.toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
  if (base === 'Kg' && q < 1) return f(q * 1000, 0) + ' g';
  if (base === 'Lit' && q < 1) return f(q * 1000, 0) + ' ml';
  if (base === 'Gms' && q >= 1000) return f(q / 1000, 2) + ' kg';
  if (base === 'Ml' && q >= 1000) return f(q / 1000, 2) + ' L';
  const lbl = { Kg: 'kg', Gms: 'g', Lit: 'L', Ml: 'ml', No: 'pcs', portion: 'portions' }[base] || base;
  return f(q, q < 10 ? 2 : 1) + ' ' + lbl;
}
