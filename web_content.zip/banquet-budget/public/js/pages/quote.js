import { html, useFetch, baht, fmt, fmtDate, fmtDay } from '../lib.js';
import { Loading, ErrorBox } from '../ui.js';

export function QuotePrint({ id }) {
  const { data: q, error, loading } = useFetch('/quotations/' + id);
  if (loading && !q) return html`<${Loading} />`;
  if (error) return html`<div style="padding:20px"><${ErrorBox} error=${error} /></div>`;
  const d = q.data;
  const pp = d.price_basis === 'net';
  return html`<div style="background:#e9ecea;min-height:100vh;padding:1px 0 40px">
    <div class="print-tools"><button class="btn primary" onClick=${() => window.print()}>Print / save as PDF</button><a class="btn" href=${'#/events/' + q.event_id + '/quotes'}>Back to event</a>
      <span class="muted small" style="align-self:center">Status: ${q.status}</span></div>
    <article class="print-page">
      <div class="qhead">
        <div><h1>${d.hotel.name}</h1><div class="small" style="color:#555">${d.hotel.address}${d.hotel.phone ? ' · ' + d.hotel.phone : ''}${d.hotel.email ? ' · ' + d.hotel.email : ''}</div>
          ${d.hotel.tax_id && html`<div class="small" style="color:#555">Tax ID ${d.hotel.tax_id}</div>`}</div>
        <div style="text-align:right"><div style="font-size:20px;letter-spacing:.08em;text-transform:uppercase;color:#1d3f37">Quotation</div>
          <div class="mono">${q.number}</div><div class="small">Date ${fmtDate(q.created_at)}<br/>Valid until ${fmtDate(q.valid_until)}</div></div>
      </div>
      <div class="grid g2" style="margin-bottom:18px">
        <div><div class="eyebrow">Prepared for</div><b>${d.client.name || '—'}</b>${d.client.contact && html`<div>${d.client.contact}</div>`}<div class="small">${[d.client.phone, d.client.email].filter(Boolean).join(' · ')}</div></div>
        <div><div class="eyebrow">Event</div><b>${d.event.name}</b><div class="small">${d.event.type} · ${fmtDate(d.event.start_date)}${d.event.end_date && d.event.end_date !== d.event.start_date ? ' – ' + fmtDate(d.event.end_date) : ''}</div><div class="small">${d.event.venue}</div></div>
      </div>
      ${d.note && html`<p style="white-space:pre-wrap">${d.note}</p>`}
      <table style="margin-bottom:6px"><thead><tr><th>Date</th><th>Description</th><th class="r">Guests / qty</th><th class="r">Food / pax</th><th class="r">Beverage / pax</th><th class="r">Amount (THB)</th></tr></thead>
        <tbody>${d.lines.map((l) => html`<tr><td style="white-space:nowrap">${fmtDay(l.date)}</td><td>${l.description}</td><td class="r num">${fmt(l.pax, 0)}</td><td class="r num">${fmt(l.rate)}</td><td class="r num">${l.bev ? fmt(l.bev) : '–'}</td><td class="r num">${fmt(l.amount)}</td></tr>`)}
          ${d.extra.map((l) => html`<tr><td></td><td>${l.description}</td><td class="r num">${fmt(l.pax, 0)} ${l.unit || ''}</td><td class="r num">${fmt(l.rate)}</td><td></td><td class="r num">${fmt(l.amount)}</td></tr>`)}
          <tr class="total"><td colspan="5">Subtotal${pp ? ' (net, service charge and VAT included)' : ''}</td><td class="r num">${fmt(d.subtotal)}</td></tr>
          ${!pp && html`<tr><td colspan="5">Service charge ${fmt(d.service_pct, 0)}%</td><td class="r num">${fmt(d.service)}</td></tr>
            <tr><td colspan="5">VAT ${fmt(d.vat_pct, 0)}%</td><td class="r num">${fmt(d.vat)}</td></tr>`}
          <tr class="total"><td colspan="5" style="font-size:15px">Total (THB)</td><td class="r num" style="font-size:15px">${fmt(d.total)}</td></tr>
        </tbody></table>
      <p class="small" style="color:#555">Prices in Thai Baht. ${pp ? 'All prices are net.' : `Prices are subject to ${fmt(d.service_pct, 0)}% service charge and ${fmt(d.vat_pct, 0)}% VAT.`}</p>
      <h3 style="margin-top:20px">Terms & conditions</h3><p style="white-space:pre-wrap" class="small">${d.terms}</p>
      <div class="grid g2" style="margin-top:36px"><div style="border-top:1px solid #999;padding-top:6px" class="small">Prepared by ${d.prepared_by}<br/>${d.hotel.name}</div>
        <div style="border-top:1px solid #999;padding-top:6px" class="small">Accepted by (client signature & date)</div></div>
      ${d.include_menu && d.menus.length ? html`<div class="pb" style="margin-top:30px"><h2 style="margin-bottom:12px">Menus</h2>
        ${d.menus.map((m) => html`<div style="margin-bottom:22px;break-inside:avoid-page"><h3 style="border-bottom:1px solid #ccc;padding-bottom:4px">${fmtDay(m.date)} · ${m.name}${m.venue ? ' · ' + m.venue : ''}${!m.chargeable ? ' (included)' : ''}</h3>
          <div class="menu-cols" style="margin-top:8px">${m.sections.map((s) => html`<div class="ms"><div class="eyebrow" style="color:#1d3f37">${s.section}</div>${s.dishes.map((x) => html`<div class="small">${x}</div>`)}</div>`)}</div></div>`)}
      </div>` : ''}
    </article></div>`;
}
