import { html, useState, useEffect, useFetch, api, baht, fmt, fmtDay, n, store, useStore, can, toast, toastErr, go, uid, fileToBase64 } from '../lib.js';
import { Loading, Chip, Diet, Empty, Field, Combo } from '../ui.js';

const KINDS = ['breakfast', 'brunch', 'lunch', 'hi-tea', 'dinner', 'cocktail', 'station', 'other'];

export function MenuImport({ eventId }) {
  const s = useStore();
  const evs = useFetch('/events');
  const [target, setTarget] = useState(eventId ? String(eventId) : '');
  const [newEv, setNewEv] = useState({ name: '', client_name: '' });
  const [text, setText] = useState('');
  const [file, setFile] = useState(null);
  const [year, setYear] = useState(new Date().getFullYear());
  const [parsed, setParsed] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (eventId) setTarget(String(eventId)); }, [eventId]);
  if (!can('events')) return html`<${Empty} title="Not available">Your role cannot import menus.<//>`;

  const read = async () => {
    if (!text.trim() && !file) return toast('Paste the menu text or choose a PDF.', true);
    setBusy(true);
    try {
      const body = { year };
      if (file) body.pdfBase64 = await fileToBase64(file); else body.text = text;
      const r = await api('/menu/parse', { method: 'POST', body });
      if (!r.meals.length) { toast('No meals or dishes were recognised. Check that each meal has a heading with its date (e.g. "30 October 2026 – Lunch") and numbered dishes under section headings.', true); setBusy(false); return; }
      setParsed(r.meals.map((m) => ({ ...m, _k: uid(), include: true, chargeable: m.kind !== 'breakfast' && m.price != null, pax: m.pax ?? '', price: m.price ?? '', bev: m.bev ?? '',
        items: m.items.map((it) => ({ ...it, _k: uid(), skip: false, choice: it.recipe_id ? String(it.recipe_id) : 'new' })) })));
    } catch (e) { toastErr(e); }
    setBusy(false);
  };
  const doImport = async () => {
    setBusy(true);
    try {
      let eid = target;
      if (target === 'new') {
        if (!newEv.name.trim()) { toast('Name the new event.', true); setBusy(false); return; }
        const dates = parsed.map((m) => m.date).filter(Boolean).sort();
        const r = await api('/events', { method: 'POST', body: { ...newEv, start_date: dates[0] || null, end_date: dates[dates.length - 1] || null, venue: s.settings.hotel_name } });
        eid = r.id;
      }
      if (!eid) { toast('Choose the event to import into.', true); setBusy(false); return; }
      const meals = parsed.filter((m) => m.include).map((m) => ({ ...m, items: m.items.map((it) => ({
        ...it, recipe_id: /^\d+$/.test(it.choice) ? +it.choice : null, create_recipe: it.choice === 'new', skip: it.skip })) }));
      const r = await api(`/events/${eid}/import-menu`, { method: 'POST', body: { meals } });
      toast(`Imported ${r.meals} meals and ${r.items} dishes${r.recipes ? `; ${r.recipes} new draft recipes need ingredients` : ''}.`);
      const { loadCatalog } = await import('../lib.js');
      await loadCatalog();
      go(`#/events/${eid}/meals`);
    } catch (e) { toastErr(e); }
    setBusy(false);
  };
  const setMeal = (k, patch) => setParsed(parsed.map((m) => (m._k === k ? { ...m, ...patch } : m)));
  const setItem = (mk, ik, patch) => setParsed(parsed.map((m) => (m._k === mk ? { ...m, items: m.items.map((i) => (i._k === ik ? { ...i, ...patch } : i)) } : m)));

  const stats = parsed ? parsed.filter((m) => m.include).reduce((a, m) => { for (const i of m.items) if (!i.skip) { a.items++; if (/^\d+$/.test(i.choice)) a.matched++; else if (i.choice === 'new') a.created++; } return a; }, { items: 0, matched: 0, created: 0 }) : null;

  return html`<div>
    <div class="page-head"><div class="grow"><div class="eyebrow">Menu → budget</div><h1>Import a menu</h1></div></div>
    <section class="panel" style="margin-bottom:18px"><div class="fields">
      <${Field} label="Import into" cls="span2"><select class="in" value=${target} onChange=${(e) => setTarget(e.target.value)}>
        <option value="">Choose an event…</option><option value="new">+ Create a new event</option>
        ${(evs.data || []).map((e) => html`<option value=${e.id}>${e.name}${e.start_date ? ' · ' + fmtDay(e.start_date) : ''}</option>`)}</select><//>
      ${target === 'new' && html`<${Field} label="New event name"><input class="in" value=${newEv.name} onInput=${(e) => setNewEv({ ...newEv, name: e.target.value })} /><//>
        <${Field} label="Client"><input class="in" value=${newEv.client_name} onInput=${(e) => setNewEv({ ...newEv, client_name: e.target.value })} /><//>`}
      <${Field} label="Year for dates without a year"><input class="in num" type="number" value=${year} onInput=${(e) => setYear(+e.target.value)} /><//>
    </div></section>
    ${!parsed ? html`<section class="grid g2">
      <div class="panel"><h3>Upload the menu PDF</h3><p class="note">Works best with menus that have a heading per meal with its date, section headings in capitals (STARTERS, MAIN COURSE…) and numbered dishes.</p>
        <input type="file" accept="application/pdf" onChange=${(e) => { setFile(e.target.files[0] || null); }} aria-label="Menu PDF" />
        ${file && html`<p class="small">${file.name} <button class="btn ghost sm" onClick=${() => setFile(null)}>Remove</button></p>`}</div>
      <div class="panel"><h3>…or paste the menu text</h3><textarea class="in" rows="10" value=${text} disabled=${!!file} onInput=${(e) => setText(e.target.value)} placeholder=${'30 October 2026 - Lunch\nTHB 1,450 per pax + THB 200 soft drinks | 130 pax\nSTARTERS\n1  Paneer Tikka [VEG]\n2  Chicken 65 [NON-VEG]\nMAIN COURSE\n1  Dal Makhani [VEG]'}></textarea></div>
      <div class="row" style="grid-column:1/-1"><span class="spacer"></span><button class="btn primary" disabled=${busy} onClick=${read}>${busy ? 'Reading menu…' : 'Read menu'}</button></div>
    </section>` : html`<div>
      <div class="callout" style="margin-bottom:14px">Check each meal and dish. Dishes matched to a recipe are costed straight away; “Create draft recipe” adds an empty recipe to the library for the chef to complete. Untick anything you don't want.</div>
      ${parsed.map((m) => html`<section key=${m._k} class="panel" style="margin-bottom:16px;padding:0;opacity:${m.include ? 1 : 0.55}">
        <div style="padding:12px 14px;border-bottom:1px solid var(--line)"><div class="row">
          <label class="check"><input type="checkbox" checked=${m.include} onChange=${(e) => setMeal(m._k, { include: e.target.checked })} /> Import</label>
          <input class="in" style="max-width:220px;font-weight:600" value=${m.name} onInput=${(e) => setMeal(m._k, { name: e.target.value })} aria-label="Meal name" />
          <select class="in" style="width:auto" value=${m.kind} onChange=${(e) => setMeal(m._k, { kind: e.target.value })} aria-label="Meal type">${KINDS.map((k) => html`<option value=${k}>${k}</option>`)}</select>
          <input class="in" type="date" style="width:auto" value=${m.date || ''} onInput=${(e) => setMeal(m._k, { date: e.target.value })} aria-label="Date" />
          <label class="small muted">Pax <input class="in num" style="width:70px" type="number" value=${m.pax} onInput=${(e) => setMeal(m._k, { pax: e.target.value })} /></label>
          <label class="small muted">Food ฿ <input class="in num" style="width:90px" type="number" value=${m.price} onInput=${(e) => setMeal(m._k, { price: e.target.value })} /></label>
          <label class="small muted">Drinks ฿ <input class="in num" style="width:80px" type="number" value=${m.bev} onInput=${(e) => setMeal(m._k, { bev: e.target.value })} /></label>
          <input class="in" style="max-width:140px" placeholder="Venue" value=${m.venue} onInput=${(e) => setMeal(m._k, { venue: e.target.value })} aria-label="Venue" />
          <label class="check"><input type="checkbox" checked=${m.chargeable} onChange=${(e) => setMeal(m._k, { chargeable: e.target.checked })} /> Charged</label>
        </div></div>
        <div style="overflow-x:auto"><table class="edit"><thead><tr><th class="tight"></th><th>Section</th><th>Dish (as on menu)</th><th>Recipe</th><th>Match</th></tr></thead>
          <tbody>${m.items.map((it) => html`<tr key=${it._k} style=${it.skip ? 'opacity:.45' : ''}>
            <td><input type="checkbox" checked=${!it.skip} onChange=${(e) => setItem(m._k, it._k, { skip: !e.target.checked })} aria-label="Include dish" /></td>
            <td><select class="in" style="width:150px" value=${it.section} onChange=${(e) => setItem(m._k, it._k, { section: e.target.value })} aria-label="Section">
              ${[...new Set([...s.settings.sections, it.section])].map((x) => html`<option value=${x}>${x}</option>`)}</select></td>
            <td style="min-width:240px"><div class="row" style="gap:6px;flex-wrap:nowrap"><${Diet} d=${it.diet} /><input class="in bare" value=${it.name} onInput=${(e) => setItem(m._k, it._k, { name: e.target.value })} aria-label="Dish name" /></div>
              ${it.note && html`<div class="sub">${it.note}</div>`}</td>
            <td style="min-width:260px"><select class="in" value=${it.choice} onChange=${(e) => setItem(m._k, it._k, { choice: e.target.value })} aria-label="Recipe">
              ${it.candidates.map((c) => html`<option value=${String(c.id)}>${c.name} (${Math.round(c.score * 100)}%)</option>`)}
              ${it.extra && html`<option value=${String(it.extra.id)}>${it.extra.name}</option>`}
              <option value="new">+ Create draft recipe “${it.name.slice(0, 40)}”</option><option value="none">No recipe (cost ฿0 for now)</option></select>
              <div style="border:1px dashed var(--line);border-radius:7px;margin-top:3px"><${Combo} placeholder="Search another recipe…" ariaLabel="Search another recipe"
                search=${(q) => searchRec(s.catalog, q)} onPick=${(r) => setItem(m._k, it._k, { extra: { id: r.id, name: r.name }, choice: String(r.id) })} /></div></td>
            <td>${/^\d+$/.test(it.choice) ? html`<${Chip} c=${(it.candidates.find((c) => String(c.id) === it.choice)?.score ?? 1) >= 0.8 ? 'good' : 'warn'}>linked<//>` : it.choice === 'new' ? html`<${Chip} c="acc">new draft<//>` : html`<${Chip} c="bad">none<//>`}</td>
          </tr>`)}</tbody></table></div>
      </section>`)}
      <div class="savebar"><span>${stats.items} dishes · ${stats.matched} linked to recipes · ${stats.created} new drafts</span><span class="spacer"></span>
        <button class="btn ghost" onClick=${() => setParsed(null)}>Start over</button>
        <button class="btn primary" disabled=${busy} onClick=${doImport}>${busy ? 'Importing…' : 'Import into event'}</button></div>
    </div>`}
  </div>`;
}

function searchRec(cat, q) {
  const t = q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (!t.length) return [];
  return cat.recSearch.filter((x) => x.r.active && !x.r.is_sub && t.every((w) => x.s.includes(w))).slice(0, 20)
    .map(({ r }) => ({ key: r.id, value: r, label: r.name, sub: r.section, right: baht(r.per_portion) }));
}
