import { html, useState, useEffect, useRef, useFetch, api, baht, pct, fmt, fmtDay, costClass, n, store, useStore, can, toast, toastErr, go, uid, useDirtyGuard } from '../lib.js';
import { Loading, ErrorBox, Chip, Diet, Empty, Combo, ConfirmButton, Field, CostBar, NumIn } from '../ui.js';
import { mealSummary, itemCost, labourAmount, costAmount } from '../costing.js';
import { MealModal } from './events.js';

export function MealEditor({ eventId, mealId }) {
  const { data: ev, error, loading, reload } = useFetch('/events/' + eventId);
  if (loading && !ev) return html`<${Loading} />`;
  if (error) return html`<${ErrorBox} error=${error} retry=${reload} />`;
  const meal = ev.meals.find((m) => m.id === mealId);
  if (!meal) return html`<${Empty} title="Meal not found">It may have been deleted. <a href=${'#/events/' + eventId + '/meals'}>Back to the meals</a><//>`;
  return html`<${Editor} ev=${ev} initial=${meal} reload=${reload} />`;
}

function Editor({ ev, initial, reload }) {
  const s = useStore();
  const cat = s.catalog;
  const st = s.settings;
  const [m, setM] = useState(() => ({ ...initial, items: initial.items.map((i) => ({ ...i, _k: uid() })) }));
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [editHead, setEditHead] = useState(false);
  const [adding, setAdding] = useState(null);
  const lastQ = useRef('');
  useDirtyGuard(dirty);
  const ro = !can('events');
  const change = (next) => { setM(next); setDirty(true); };
  const setItem = (k, patch) => change({ ...m, items: m.items.map((i) => (i._k === k ? { ...i, ...patch } : i)) });
  const per = (rid) => cat.recById.get(rid)?.per_portion ?? 0;
  const labour = ev.labour.filter((l) => l.meal_id === m.id).reduce((a, l) => a + labourAmount(l), 0);
  const costs = ev.costs.filter((c) => c.meal_id === m.id).reduce((a, c) => a + costAmount(c), 0);
  const sum = mealSummary(m, ev, st, per, { labour, costs });
  const target = n(ev.target_pct);
  const suggested = sum.costPerPax && target ? sum.costPerPax / (target / 100) : null;
  const order = [...st.sections, ...new Set(m.items.map((i) => i.section).filter((x) => !st.sections.includes(x)))];
  const issues = { none: 0, confirm: 0, estimate: 0, norecipe: 0, empty: 0 };
  for (const it of m.items) {
    const r = it.recipe_id && cat.recById.get(it.recipe_id);
    if (!it.recipe_id && !n(it.cost_per_portion)) issues.norecipe++;
    else if (r) { if (!r.lines) issues.empty++; issues.none += r.issues.none ? 1 : 0; issues.confirm += r.issues.confirm ? 1 : 0; issues.estimate += r.issues.estimate ? 1 : 0; }
  }

  const save = async () => {
    setBusy(true);
    try {
      const r = await api('/meals/' + m.id, { method: 'PUT', body: { ...m, items: m.items } });
      setDirty(false);
      toast('Meal saved');
      const d = await reload();
      const fresh = d?.meals.find((x) => x.id === m.id);
      if (fresh) setM({ ...fresh, items: fresh.items.map((i) => ({ ...i, _k: uid() })) });
    } catch (e) { toastErr(e); }
    setBusy(false);
  };
  const addDish = (section, recipe, name = '') => {
    const it = { _k: uid(), section, name: recipe ? recipe.name : name, diet: recipe?.diet || null, recipe_id: recipe?.id || null, factor: st.uptake_defaults?.[section] ?? 100, portions: null, cost_per_portion: null, note: '' };
    change({ ...m, items: [...m.items, it] });
  };
  const move = (k, dir) => {
    const items = [...m.items];
    const i = items.findIndex((x) => x._k === k);
    const sec = items[i].section;
    let j = i + dir;
    while (j >= 0 && j < items.length && items[j].section !== sec) j += dir;
    if (j < 0 || j >= items.length) return;
    [items[i], items[j]] = [items[j], items[i]];
    change({ ...m, items });
  };
  const setSectionFactor = (sec) => {
    const v = prompt(`Uptake % for every dish in ${sec}:`, String(st.uptake_defaults?.[sec] ?? 100));
    if (v === null || !isFinite(+v)) return;
    change({ ...m, items: m.items.map((i) => (i.section === sec ? { ...i, factor: +v } : i)) });
  };

  return html`<div>
    <div class="crumbs"><a href="#/events">Events</a> / <a href=${'#/events/' + ev.id}>${ev.name}</a> / <a href=${'#/events/' + ev.id + '/meals'}>Meals</a> /</div>
    <div class="page-head"><div class="grow"><h1>${m.name}</h1>
      <div class="row small muted" style="margin-top:4px"><span>${fmtDay(m.date)}${m.time ? ' · ' + m.time : ''}</span><span>${m.venue}</span><span class="num">${fmt(m.pax, 0)} pax</span>
        ${m.chargeable ? html`<span class="num">${baht(n(m.price_per_pax), 0)} food + ${baht(n(m.bev_price_per_pax), 0)} drinks / pax</span>` : html`<${Chip}>included, not charged<//>`}</div></div>
      ${!ro && html`<button class="btn" onClick=${() => setEditHead(true)}>Edit meal details</button>`}
    </div>
    <div class="two-col">
      <div>
        ${!m.items.length && html`<${Empty} title="No dishes yet">Add dishes section by section. Pick each one from the recipe library so its cost comes from the ingredient prices.<//>`}
        ${order.map((sec) => {
          const items = m.items.filter((i) => i.section === sec);
          if (!items.length) return null;
          return html`<section key=${sec}>
            <div class="section-h"><h3>${sec}</h3><span class="small muted">${items.length} dish${items.length > 1 ? 'es' : ''}</span>
              ${!ro && html`<button class="btn ghost sm" onClick=${() => setSectionFactor(sec)} title="Set the uptake % for every dish in this section">Set uptake</button>`}
              <span class="r">${baht(sum.sections[sec] / (sum.pax || 1))} / pax</span></div>
            <div class="tw"><table class="edit" style="table-layout:fixed;min-width:640px">
              <colgroup><col /><col style="width:86px" /><col style="width:96px" /><col style="width:90px" /><col style="width:92px" /><col style="width:96px" /></colgroup>
              <thead><tr><th>Dish & recipe</th><th class="r" title="Share of guests taking a full portion">Uptake %</th><th class="r">Per portion</th><th class="r">Per pax</th><th class="r">Total</th><th></th></tr></thead>
              <tbody>${items.map((it) => html`<${ItemRow} key=${it._k} it=${it} meal=${m} per=${per} ro=${ro} setItem=${setItem} move=${move}
                remove=${() => change({ ...m, items: m.items.filter((x) => x._k !== it._k) })} />`)}</tbody></table></div>
          </section>`;
        })}
        ${!ro && html`<div class="panel" style="margin-top:18px"><div class="row"><b>Add a dish</b>
          <select class="in" style="width:auto" value=${adding || ''} onChange=${(e) => setAdding(e.target.value || null)} aria-label="Section"><option value="">In the recipe's own section</option>${st.sections.filter((x) => x !== 'Sub-recipes').map((x) => html`<option value=${x}>${x}</option>`)}</select>
          <div style="flex:1;min-width:240px;border:1px solid var(--line);border-radius:7px"><${Combo} placeholder="Search the recipe library…" ariaLabel="Recipe"
            search=${(q) => searchRecipes(cat, q, adding)} onPick=${(r) => (r === '__new' ? addDish(adding || 'Other', null, lastQ.current) : addDish(adding || r.section, r))}
            extra=${(q) => (lastQ.current = q, { key: '__new', label: `Add “${q}” without a recipe`, sub: 'Enter a cost per portion by hand, or link a recipe later', value: '__new' })} /></div></div>
          <p class="note" style="margin-bottom:0">Uptake % is the share of guests who take a full portion. At a big buffet guests sample many dishes, so it is usually 40–70%.</p></div>`}
      </div>
      <aside class="sticky">
        <div class="costcard"><div class="top"><div class="eyebrow">Cost per pax</div><div class="big">${baht(sum.costPerPax)}</div>
          <div class="small" style="color:var(--band-muted)">${fmt(sum.pax, 0)} pax · meal cost ${baht(sum.totalCost, 0)}</div></div>
          <div class="body">
            <div class="kv"><span>Food / pax</span><span class="num">${baht(sum.food / (sum.pax || 1))}</span></div>
            <div class="kv"><span>Wastage (${fmt(sum.wastagePct, 0)}%)</span><span class="num">${baht(sum.waste / (sum.pax || 1))}</span></div>
            <div class="kv"><span>Casual labour</span><span class="num">${baht(labour, 0)}</span></div>
            <div class="kv"><span>Other costs</span><span class="num">${baht(costs, 0)}</span></div>
            <div class="kv tot"><span>Total cost</span><span class="num">${baht(sum.totalCost, 0)}</span></div>
            ${m.chargeable ? html`<div class="kv"><span>Revenue (ex tax)</span><span class="num">${baht(sum.revenue, 0)}</span></div>
              <div class="kv"><span>Cost %</span><span>${sum.costPct == null ? '–' : html`<${Chip} c=${costClass(sum.costPct, target)}>${pct(sum.costPct)}<//>`}</span></div>
              <div style="margin:6px 0"><${CostBar} value=${sum.costPct} target=${target} /></div>
              <div class="kv"><span>Food cost %</span><span class="num">${pct(sum.foodPct)}</span></div>
              <div class="kv"><span>Gross profit</span><span class="num">${baht(sum.gp, 0)}</span></div>` : ''}
            <div class="kv"><span>Price per pax for ${fmt(target, 0)}% cost</span><span class="num">${baht(suggested, 0)}</span></div>
          </div></div>
        <div class="panel"><div class="eyebrow" style="margin-bottom:10px">Cost per pax by section</div><div class="bars">
          ${Object.entries(sum.sections).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]).map(([k, v], i, arr) => html`<div><div class="lbl"><span>${k}</span><span class="num">${baht(v / (sum.pax || 1))}</span></div>
            <div class="bar"><i style=${`width:${(v / arr[0][1]) * 100}%`}></i></div></div>`)}
        </div></div>
        <div class="panel"><div class="eyebrow" style="margin-bottom:8px">Check before quoting</div>
          ${issues.norecipe + issues.empty + issues.none + issues.confirm + issues.estimate === 0 ? html`<${Chip} c="good">All dishes costed from confirmed prices<//>` : html`<div class="stack" style="gap:6px;font-size:12.5px">
            ${issues.norecipe ? html`<div><${Chip} c="bad">${issues.norecipe} without recipe<//> cost ฿0 until linked or priced</div>` : ''}
            ${issues.empty ? html`<div><${Chip} c="bad">${issues.empty} empty recipe${issues.empty > 1 ? 's' : ''}<//> no ingredients yet</div>` : ''}
            ${issues.none ? html`<div><${Chip} c="bad">${issues.none} use unpriced items<//></div>` : ''}
            ${issues.confirm ? html`<div><${Chip} c="warn">${issues.confirm} use prices to confirm<//></div>` : ''}
            ${issues.estimate ? html`<div><${Chip} c="est">${issues.estimate} use estimated prices<//></div>` : ''}</div>`}
        </div>
        ${m.notes && html`<div class="panel note" style="white-space:pre-wrap">${m.notes}</div>`}
      </aside>
    </div>
    ${dirty && html`<div class="savebar"><span class="dirty-dot"></span><span>Unsaved changes</span><span class="spacer"></span>
      <button class="btn ghost" onClick=${() => { setM({ ...initial, items: initial.items.map((i) => ({ ...i, _k: uid() })) }); setDirty(false); }}>Discard</button>
      <button class="btn primary" disabled=${busy} onClick=${save}>${busy ? 'Saving…' : 'Save meal'}</button></div>`}
    ${editHead && html`<${MealModal} ev=${ev} meal=${m} onClose=${() => setEditHead(false)} onSaved=${(x) => { change({ ...m, ...x, items: m.items }); setEditHead(false); }} />`}
  </div>`;
}

function searchRecipes(cat, q, section) {
  const t = q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (!t.length) return [];
  return cat.recSearch.filter((x) => x.r.active && !x.r.is_sub && t.every((w) => x.s.includes(w)))
    .sort((a, b) => (b.r.section === section) - (a.r.section === section) || a.r.name.length - b.r.name.length)
    .slice(0, 30)
    .map(({ r }) => ({ key: r.id, value: r, label: r.name, sub: `${r.section} · ${r.diet} · yield ${fmt(r.yield_pax, 0)} pax${r.lines ? '' : ' · no ingredients yet'}`, right: baht(r.per_portion) + ' / portion' }));
}

function ItemRow({ it, meal, per, ro, setItem, move, remove }) {
  const s = useStore();
  const r = it.recipe_id ? s.catalog.recById.get(it.recipe_id) : null;
  const c = itemCost(it, meal, per);
  const flag = !it.recipe_id ? (n(it.cost_per_portion) ? '' : 'st-none') : !r?.lines ? 'st-none' : r.issues.none ? 'st-none' : r.issues.confirm ? 'st-confirm' : r.issues.estimate ? 'st-estimate' : '';
  return html`<tr class=${flag}>
    <td style="min-width:0"><div class="row" style="gap:6px;flex-wrap:nowrap"><${Diet} d=${it.diet || r?.diet} />
      <input class="in bare" value=${it.name} disabled=${ro} onInput=${(e) => setItem(it._k, { name: e.target.value })} aria-label="Dish name as shown on the menu" /></div>
      ${r ? html`<div class="sub" style="padding-left:18px;flex-wrap:nowrap"><span>Recipe:</span><a href=${'#/recipes/' + r.id} style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title=${r.name}>${r.name}</a>
          <span style="white-space:nowrap">· ${fmt(r.yield_pax, 0)} pax</span>${!r.lines ? html`<${Chip} c="bad">no ingredients<//>` : ''}
          ${!ro && html`<button class="btn ghost sm" style="padding:0 5px" title="Unlink recipe" onClick=${() => setItem(it._k, { recipe_id: null })}>unlink</button>`}</div>`
      : html`<div class="row" style="gap:6px;padding-left:18px;margin-top:2px;flex-wrap:nowrap">
          <div style="flex:1;min-width:0;border:1px dashed var(--line);border-radius:7px"><${Combo} placeholder="Link a recipe…" disabled=${ro} ariaLabel="Link a recipe"
            search=${(q) => searchRecipes(s.catalog, q, it.section)} onPick=${(rec) => setItem(it._k, { recipe_id: rec.id, diet: it.diet || rec.diet })} /></div>
          <span class="small muted" style="white-space:nowrap">or ฿</span><${NumIn} cls="in num" style="width:80px;padding:3px 5px" value=${it.cost_per_portion} disabled=${ro} ariaLabel="Cost per portion" onInput=${(v) => setItem(it._k, { cost_per_portion: v })} /></div>`}
      ${it.note && html`<div class="sub" style="padding-left:18px">${it.note}</div>`}</td>
    <td class="r"><${NumIn} cls="in num" style="width:68px" value=${it.factor} min="0" disabled=${ro} ariaLabel="Uptake %" onInput=${(v) => setItem(it._k, { factor: v })} /></td>
    <td class="r num">${baht(c.perPortion)}</td>
    <td class="r num">${baht(c.perPax)}</td>
    <td class="r num">${baht(c.total, 0)}</td>
    <td style="white-space:nowrap">${!ro && html`<button class="icon-btn" aria-label="Move up" onClick=${() => move(it._k, -1)}>↑</button><button class="icon-btn" aria-label="Move down" onClick=${() => move(it._k, 1)}>↓</button><button class="icon-btn del" aria-label="Remove dish" onClick=${remove}>×</button>`}</td>
  </tr>`;
}
