import { html, useFetch, baht, pct, fmtDate, costClass, store, can } from '../lib.js';
import { Loading, ErrorBox, EventStatus, Chip, PriceChip } from '../ui.js';

export function Dashboard() {
  const { data, error, loading, reload } = useFetch('/dashboard');
  if (loading && !data) return html`<${Loading} />`;
  if (error) return html`<${ErrorBox} error=${error} retry=${reload} />`;
  const p = data.pipeline;
  const conf = p.confirmed || { revenue: 0, gp: 0, count: 0 };
  const quoted = p.quoted || { revenue: 0, gp: 0, count: 0 };
  const enq = p.enquiry || { revenue: 0, gp: 0, count: 0 };
  const issues = Object.fromEntries(data.priceIssues.map((r) => [r.price_status, r.c]));
  const toCheck = (issues.none || 0) + (issues.confirm || 0);
  return html`<div>
    <div class="page-head"><div class="grow"><div class="eyebrow">${fmtDate(new Date().toISOString())}</div><h1>Good ${greet()}, ${store.user.name.split(' ')[0]}</h1></div>
      ${can('events') && html`<a class="btn" href="#/import">Import a menu</a><a class="btn primary" href="#/events?new=1">+ New event</a>`}</div>
    <div class="grid g4" style="margin-bottom:18px">
      <div class="kpi dark"><div class="eyebrow">Confirmed revenue</div><div class="v">${baht(conf.revenue, 0)}</div><div class="s">${conf.count} event${conf.count === 1 ? '' : 's'} · GP ${baht(conf.gp, 0)}</div></div>
      <div class="kpi"><div class="eyebrow">Quoted, awaiting reply</div><div class="v">${baht(quoted.revenue, 0)}</div><div class="s">${quoted.count} event${quoted.count === 1 ? '' : 's'} · GP ${baht(quoted.gp, 0)}</div></div>
      <div class="kpi"><div class="eyebrow">Enquiries</div><div class="v">${enq.count}</div><div class="s">${baht(enq.revenue, 0)} if all confirm</div></div>
      <div class="kpi"><div class="eyebrow">Recipe library</div><div class="v">${data.recipeCount}</div><div class="s">${data.emptyRecipes ? html`<a href="#/recipes?empty=1">${data.emptyRecipes} without ingredients</a>` : 'All recipes have ingredients'}</div></div>
    </div>
    <div class="grid" style="grid-template-columns:minmax(0,2fr) minmax(0,1fr)">
      <section class="panel" style="padding:0">
        <div class="row" style="padding:14px 16px 6px"><h2>Upcoming events</h2><span class="spacer"></span><a class="btn ghost sm" href="#/events">All events</a></div>
        ${data.upcoming.length ? html`<div style="overflow-x:auto"><table>
          <thead><tr><th>Event</th><th>Dates</th><th>Status</th><th class="r">Revenue</th><th class="r">Cost %</th><th class="r">GP</th></tr></thead>
          <tbody>${data.upcoming.map((e) => html`<tr class="click" onClick=${() => (location.hash = '#/events/' + e.id)}>
            <td><b>${e.name}</b><div class="small muted">${e.client_name}</div></td>
            <td class="small" style="white-space:nowrap">${fmtDate(e.start_date)}${e.end_date && e.end_date !== e.start_date ? ' – ' + fmtDate(e.end_date) : ''}</td>
            <td><${EventStatus} s=${e.status} /></td><td class="r num">${baht(e.revenue, 0)}</td>
            <td class="r">${e.costPct == null ? '–' : html`<${Chip} c=${costClass(e.costPct, e.target_pct)}>${pct(e.costPct)}<//>`}</td>
            <td class="r num">${baht(e.gp, 0)}</td></tr>`)}</tbody></table></div>`
          : html`<p class="muted" style="padding:0 16px 16px">No upcoming events. <a href="#/events?new=1">Create one</a> or <a href="#/import">import a menu</a>.</p>`}
      </section>
      <div class="stack">
        <section class="panel"><h3>Price list health</h3>
          <div class="stack" style="gap:8px;margin-top:6px">
            ${['none', 'confirm', 'estimate', 'updated', 'direct', 'list'].filter((k) => issues[k]).map((k) => html`<div class="row"><${PriceChip} status=${k} /><span class="spacer"></span><a class="num" href=${'#/ingredients?status=' + k}>${issues[k]}</a></div>`)}
          </div>
          ${toCheck ? html`<p class="note">${toCheck} ingredients have no price or a price to confirm. Costs using them are flagged.</p>` : ''}
        </section>
        <section class="panel"><h3>Recent price changes</h3>
          ${data.recentPrices.length ? data.recentPrices.map((r) => html`<div class="kv"><span><a href=${'#/ingredients/' + r.id}>${r.name}</a></span>
            <span class="num small">${baht(r.old_price)} → <b>${baht(r.new_price)}</b></span></div>`) : html`<p class="note">No price changes yet.</p>`}
        </section>
      </div>
    </div>
  </div>`;
}
function greet() { const h = new Date().getHours(); return h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening'; }
