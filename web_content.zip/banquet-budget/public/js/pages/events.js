import { html, useState, useEffect, useFetch, api, baht, pct, fmt, fmtDate, fmtDay, costClass, n, store, can, toast, toastErr, go, uid, useDirtyGuard, baseLabel } from '../lib.js';
import { Loading, ErrorBox, EventStatus, EVENT_STATUS, Chip, Empty, Modal, ConfirmButton, Field, Tabs, CostBar, PriceChip, NumIn } from '../ui.js';
import { fmtQty, labourAmount, costAmount } from '../costing.js';

const q = () => new URLSearchParams(location.hash.split('?')[1] || '');

// ===================== list =====================
export function EventsList() {
  const { data, error, loading, reload } = useFetch('/events');
  const [filter, setFilter] = useState('active');
  const [search, setSearch] = useState('');
  const [creating, setCreating] = useState(q().get('new') === '1');
  if (loading && !data) return html`<${Loading} />`;
  if (error) return html`<${ErrorBox} error=${error} retry=${reload} />`;
  const s = search.trim().toLowerCase();
  const rows = data.filter((e) => (filter === 'all' || (filter === 'active' ? !['lost', 'completed'].includes(e.status) : e.status === filter))
    && (!s || (e.name + ' ' + e.client_name + ' ' + e.venue).toLowerCase().includes(s)));
  return html`<div>
    <div class="page-head"><div class="grow"><div class="eyebrow">Events & budgets</div><h1>Events</h1></div>
      ${can('events') && html`<a class="btn" href="#/import">Import a menu</a><button class="btn primary" onClick=${() => setCreating(true)}>+ New event</button>`}</div>
    <div class="row" style="margin-bottom:12px">
      <input class="in" style="max-width:280px" type="search" placeholder="Search event, client or venue" value=${search} onInput=${(e) => setSearch(e.target.value)} aria-label="Search events" />
      <select class="in" style="width:auto" value=${filter} onChange=${(e) => setFilter(e.target.value)} aria-label="Filter by status">
        <option value="active">Open events</option><option value="all">All events</option>
        ${Object.entries(EVENT_STATUS).map(([k, [t]]) => html`<option value=${k}>${t}</option>`)}
      </select>
    </div>
    ${rows.length ? html`<div class="tw"><table>
      <thead><tr><th>Event</th><th>Dates</th><th class="r">Meals</th><th class="r">Pax</th><th>Status</th><th class="r">Revenue</th><th class="r">Total cost</th><th class="r">Cost %</th><th class="r">GP</th></tr></thead>
      <tbody>${rows.map((e) => html`<tr class="click" onClick=${() => go('#/events/' + e.id)}>
        <td><b>${e.name}</b><div class="small muted">${[e.client_name, e.venue].filter(Boolean).join(' · ')}</div></td>
        <td class="small" style="white-space:nowrap">${fmtDate(e.start_date)}${e.end_date && e.end_date !== e.start_date ? ' – ' + fmtDate(e.end_date) : ''}</td>
        <td class="r num">${e.meals}</td><td class="r num">${fmt(e.pax, 0)}</td><td><${EventStatus} s=${e.status} /></td>
        <td class="r num">${baht(e.revenue, 0)}</td><td class="r num">${baht(e.totalCost, 0)}</td>
        <td class="r">${e.costPct == null ? '–' : html`<${Chip} c=${costClass(e.costPct, e.target_pct)}>${pct(e.costPct)}<//>`}</td>
        <td class="r num">${baht(e.gp, 0)}</td></tr>`)}</tbody></table></div>`
    : html`<${Empty} title=${data.length ? 'No events match' : 'No events yet'}>${data.length ? 'Try another search or status.' : 'Create an event, add its meals and menus, and the budget is worked out from the recipe library and price list.'}<//>`}
    ${creating && html`<${NewEventModal} onClose=${() => { setCreating(false); history.replaceState(null, '', '#/events'); }} />`}
  </div>`;
}

export function NewEventModal({ onClose }) {
  const st = store.settings;
  const [ev, setEv] = useState({ name: '', client_name: '', venue: st.hotel_name, start_date: '', end_date: '', event_type: 'Wedding', status: 'enquiry', price_basis: 'plus_plus' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setEv({ ...ev, [k]: e.target.value });
  const save = async () => {
    if (!ev.name.trim()) return toast('Give the event a name.', true);
    setBusy(true);
    try { const r = await api('/events', { method: 'POST', body: ev }); go('#/events/' + r.id + '/meals'); }
    catch (e) { toastErr(e); setBusy(false); }
  };
  return html`<${Modal} title="New event" onClose=${onClose} footer=${html`<button class="btn" onClick=${onClose}>Cancel</button><button class="btn primary" disabled=${busy} onClick=${save}>Create event</button>`}>
    <div class="fields">
      <${Field} label="Event name" cls="full"><input class="in" value=${ev.name} onInput=${set('name')} placeholder="e.g. Sharma & Kapoor Wedding" autofocus /><//>
      <${Field} label="Client" cls="span2"><input class="in" value=${ev.client_name} onInput=${set('client_name')} /><//>
      <${Field} label="Type"><input class="in" value=${ev.event_type} onInput=${set('event_type')} list="evtypes" /><datalist id="evtypes">${['Wedding', 'Corporate', 'Conference', 'Birthday', 'Gala dinner', 'Group stay'].map((t) => html`<option value=${t} />`)}</datalist><//>
      <${Field} label="Venue"><input class="in" value=${ev.venue} onInput=${set('venue')} /><//>
      <${Field} label="Start date"><input class="in" type="date" value=${ev.start_date} onInput=${set('start_date')} /><//>
      <${Field} label="End date"><input class="in" type="date" value=${ev.end_date} onInput=${set('end_date')} /><//>
      <${Field} label="Prices quoted as" cls="span2"><select class="in" value=${ev.price_basis} onChange=${set('price_basis')}>
        <option value="plus_plus">++ (service ${st.service_pct}% and VAT ${st.vat_pct}% added on top)</option><option value="net">Net (service and VAT included)</option></select><//>
    </div>
    <p class="note">Next you'll add the meals. You can also import them from a menu PDF.</p>
  <//>`;
}

// ===================== event page =====================
export function EventPage({ id, tab }) {
  const { data: ev, error, loading, reload } = useFetch('/events/' + id);
  if (loading && !ev) return html`<${Loading} />`;
  if (error) return html`<${ErrorBox} error=${error} retry=${reload} />`;
  const base = '#/events/' + id;
  const tabs = [['', 'Overview'], ['meals', `Meals (${ev.meals.length})`], ['labour', 'Casual labour'], ['costs', 'Other costs & extras'], ['purchase', 'Purchase list'], ['quotes', 'Quotations'], ['details', 'Event details']];
  let body;
  if (tab === 'meals') body = html`<${MealsTab} ev=${ev} reload=${reload} />`;
  else if (tab === 'labour') body = html`<${LabourTab} ev=${ev} reload=${reload} />`;
  else if (tab === 'costs') body = html`<${CostsTab} ev=${ev} reload=${reload} />`;
  else if (tab === 'purchase') body = html`<${PurchaseTab} ev=${ev} />`;
  else if (tab === 'quotes') body = html`<${QuotesTab} ev=${ev} reload=${reload} />`;
  else if (tab === 'details') body = html`<${DetailsTab} ev=${ev} reload=${reload} />`;
  else body = html`<${Overview} ev=${ev} />`;
  const s = ev.summary;
  return html`<div>
    <div class="crumbs"><a href="#/events">Events</a> /</div>
    <div class="page-head"><div class="grow"><h1>${ev.name}</h1>
      <div class="row small muted" style="margin-top:4px"><${EventStatus} s=${ev.status} /><span>${[ev.client_name, ev.venue].filter(Boolean).join(' · ')}</span>
      <span>${fmtDate(ev.start_date)}${ev.end_date && ev.end_date !== ev.start_date ? ' – ' + fmtDate(ev.end_date) : ''}</span></div></div>
      <div class="row"><div class="kpi" style="padding:8px 14px"><div class="eyebrow">Cost %</div><div class="v" style="font-size:18px">${s.costPct == null ? '–' : html`<${Chip} c=${costClass(s.costPct, ev.target_pct)}>${pct(s.costPct)}<//>`}</div></div>
      <div class="kpi" style="padding:8px 14px"><div class="eyebrow">Gross profit</div><div class="v" style="font-size:18px">${baht(s.gp, 0)}</div></div></div>
    </div>
    <${Tabs} tabs=${tabs} current=${tab} base=${base} />
    ${body}
  </div>`;
}

function Overview({ ev }) {
  const s = ev.summary;
  const st = store.settings;
  const maxCost = Math.max(1, s.food, s.labour, s.costs);
  return html`<div class="stack">
    <div class="grid g4">
      <div class="kpi dark"><div class="eyebrow">Revenue (ex service & VAT)</div><div class="v">${baht(s.revenue, 0)}</div><div class="s">Client pays ${baht(s.clientTotal, 0)} incl. tax</div></div>
      <div class="kpi"><div class="eyebrow">Total cost</div><div class="v">${baht(s.totalCost, 0)}</div><div class="s">Food ${baht(s.food, 0)} · Labour ${baht(s.labour, 0)}</div></div>
      <div class="kpi"><div class="eyebrow">Gross profit</div><div class="v">${baht(s.gp, 0)}</div><div class="s">${s.revenue ? pct((s.gp / s.revenue) * 100) + ' margin' : 'No revenue yet'}</div></div>
      <div class="kpi"><div class="eyebrow">Cost % (target ${fmt(ev.target_pct, 0)}%)</div><div class="v">${pct(s.costPct)}</div><div style="margin-top:8px"><${CostBar} value=${s.costPct} target=${ev.target_pct} /></div></div>
    </div>
    <section><div class="row" style="margin-bottom:8px"><h2>Meals</h2><span class="spacer"></span>
      <a class="btn sm" href=${'/api/events/' + ev.id + '/export.xlsx'}>Export budget (Excel)</a>
      ${can('events') && html`<a class="btn sm" href=${'#/events/' + ev.id + '/quotes'}>Create quotation</a>`}</div>
    ${s.meals.length ? html`<div class="tw"><table>
      <thead><tr><th>Date</th><th>Meal</th><th class="r">Pax</th><th class="r">Rate / pax</th><th class="r">Revenue</th><th class="r">Food / pax</th><th class="r">Labour</th><th class="r">Other</th><th class="r">Total cost</th><th class="r">Cost %</th></tr></thead>
      <tbody>${s.meals.map((m) => { const meal = ev.meals.find((x) => x.id === m.id); return html`<tr class="click" onClick=${() => go(`#/events/${ev.id}/meals/${m.id}`)}>
        <td class="small" style="white-space:nowrap">${fmtDay(m.date)}</td><td><b>${m.name}</b>${meal.venue && html`<span class="small muted"> · ${meal.venue}</span>`}${!meal.chargeable && html` <${Chip}>included<//>`}</td>
        <td class="r num">${fmt(m.pax, 0)}</td><td class="r num">${meal.chargeable ? baht(meal.price_per_pax + meal.bev_price_per_pax, 0) : '–'}</td>
        <td class="r num">${baht(m.revenue, 0)}</td><td class="r num">${baht(m.foodPerPax)}</td><td class="r num">${baht(m.labour, 0)}</td><td class="r num">${baht(m.costs, 0)}</td>
        <td class="r num">${baht(m.totalCost, 0)}</td><td class="r">${m.costPct == null ? '–' : html`<${Chip} c=${costClass(m.costPct, ev.target_pct)}>${pct(m.costPct)}<//>`}</td></tr>`; })}
        ${(s.labourEvent || s.costEvent || s.extraRevenue) ? html`<tr><td></td><td class="muted">Event-level (not tied to a meal)</td><td></td><td></td><td class="r num">${baht(s.extraRevenue, 0)}</td><td></td>
          <td class="r num">${baht(s.labourEvent, 0)}</td><td class="r num">${baht(s.costEvent, 0)}</td><td class="r num">${baht(s.labourEvent + s.costEvent, 0)}</td><td></td></tr>` : ''}
        <tr class="total"><td></td><td>Total</td><td></td><td></td><td class="r num">${baht(s.revenue, 0)}</td><td></td><td class="r num">${baht(s.labour, 0)}</td><td class="r num">${baht(s.costs, 0)}</td>
          <td class="r num">${baht(s.totalCost, 0)}</td><td class="r">${pct(s.costPct)}</td></tr>
      </tbody></table></div>` : html`<${Empty} title="No meals yet">Add the meals for this event to start the budget.<//>`}
    </section>
    <div class="grid g2">
      <section class="panel"><h3>Where the money goes</h3><div class="bars">
        ${[['Food (incl. wastage)', s.food], ['Casual labour', s.labour], ['Other costs', s.costs]].map(([l, v]) => html`<div><div class="lbl"><span>${l}</span><span class="num">${baht(v, 0)}</span></div><div class="bar"><i style=${`width:${(v / maxCost) * 100}%`}></i></div></div>`)}
        ${Object.entries(s.costCats).map(([k, v]) => html`<div class="kv small"><span>· ${k}</span><span class="num">${baht(v, 0)}</span></div>`)}
      </div></section>
      <section class="panel"><h3>Pricing</h3>
        <div class="kv"><span>Prices quoted as</span><span>${ev.price_basis === 'net' ? 'Net (incl. service & VAT)' : `++ (service ${st.service_pct}% + VAT ${st.vat_pct}%)`}</span></div>
        <div class="kv"><span>Quoted amount</span><span class="num">${baht(s.quoted, 0)}</span></div>
        ${ev.price_basis !== 'net' && html`<div class="kv"><span>Service charge</span><span class="num">${baht(s.serviceCharge, 0)}</span></div><div class="kv"><span>VAT</span><span class="num">${baht(s.vat, 0)}</span></div>`}
        <div class="kv tot"><span>Client total</span><span class="num">${baht(s.clientTotal, 0)}</span></div>
        ${ev.notes && html`<p class="note" style="white-space:pre-wrap;margin-top:12px">${ev.notes}</p>`}
      </section>
    </div>
  </div>`;
}

// ---------- meals tab ----------
const KINDS = ['breakfast', 'brunch', 'lunch', 'hi-tea', 'dinner', 'cocktail', 'station', 'other'];
function MealsTab({ ev, reload }) {
  const [adding, setAdding] = useState(false);
  const s = ev.summary;
  const dup = async (m) => { try { const r = await api(`/meals/${m.id}/duplicate`, { method: 'POST', body: {} }); toast('Meal duplicated'); await reload(); } catch (e) { toastErr(e); } };
  const del = async (m) => { try { await api(`/meals/${m.id}`, { method: 'DELETE' }); toast('Meal deleted'); reload(); } catch (e) { toastErr(e); } };
  return html`<div>
    <div class="row" style="margin-bottom:12px"><p class="note" style="margin:0">Each meal has its own pax, price and menu. Open a meal to add dishes from the recipe library.</p><span class="spacer"></span>
      ${can('events') && html`<a class="btn" href=${'#/import/' + ev.id}>Import menu</a><button class="btn primary" onClick=${() => setAdding(true)}>+ Add meal</button>`}</div>
    ${ev.meals.length ? html`<div class="tw"><table>
      <thead><tr><th>Date</th><th>Meal</th><th>Venue</th><th class="r">Pax</th><th class="r">Dishes</th><th class="r">Food / pax</th><th class="r">Cost %</th><th></th></tr></thead>
      <tbody>${ev.meals.map((m) => { const ms = s.meals.find((x) => x.id === m.id); return html`<tr class="click" onClick=${() => go(`#/events/${ev.id}/meals/${m.id}`)}>
        <td class="small" style="white-space:nowrap">${fmtDay(m.date)}${m.time && html`<div class="muted">${m.time}</div>`}</td>
        <td><b>${m.name}</b> <span class="small muted">${m.kind}</span>${!m.chargeable && html` <${Chip}>included<//>`}</td><td>${m.venue}</td>
        <td class="r num">${fmt(m.pax, 0)}</td><td class="r num">${m.items.length}</td><td class="r num">${baht(ms.foodPerPax)}</td>
        <td class="r">${ms.costPct == null ? '–' : html`<${Chip} c=${costClass(ms.costPct, ev.target_pct)}>${pct(ms.costPct)}<//>`}</td>
        <td class="r" style="white-space:nowrap">${can('events') && html`<button class="btn ghost sm" onClick=${(e) => { e.stopPropagation(); dup(m); }}>Duplicate</button>
          <${ConfirmButton} cls="btn ghost sm danger" onConfirm=${() => del(m)}>Delete<//>`}</td></tr>`; })}</tbody></table></div>`
    : html`<${Empty} title="No meals yet" action=${can('events') && html`<div class="row" style="justify-content:center"><a class="btn" href=${'#/import/' + ev.id}>Import from a menu</a><button class="btn primary" onClick=${() => setAdding(true)}>+ Add meal</button></div>`}>Add each meal (breakfast, lunch, dinner, stations…) with its pax and price per person.<//>`}
    ${adding && html`<${MealModal} ev=${ev} onClose=${() => setAdding(false)} onSaved=${(id) => go(`#/events/${ev.id}/meals/${id}`)} />`}
  </div>`;
}

export function MealModal({ ev, meal, onClose, onSaved }) {
  const [m, setM] = useState(meal || { name: 'Lunch', kind: 'lunch', date: ev.start_date || '', time: '', venue: ev.venue, pax: ev.meals?.[0]?.pax || 100, price_per_pax: '', bev_price_per_pax: '', chargeable: 1 });
  const set = (k) => (e) => setM({ ...m, [k]: e.target.type === 'checkbox' ? (e.target.checked ? 1 : 0) : e.target.value });
  const save = async () => {
    try {
      if (meal) { onSaved(m); return; }
      const r = await api(`/events/${ev.id}/meals`, { method: 'POST', body: m });
      onSaved(r.id);
    } catch (e) { toastErr(e); }
  };
  return html`<${Modal} title=${meal ? 'Meal details' : 'Add meal'} onClose=${onClose} footer=${html`<button class="btn" onClick=${onClose}>Cancel</button><button class="btn primary" onClick=${save}>${meal ? 'Apply' : 'Add meal'}</button>`}>
    <div class="fields">
      <${Field} label="Meal name" cls="span2"><input class="in" value=${m.name} onInput=${set('name')} /><//>
      <${Field} label="Type"><select class="in" value=${m.kind} onChange=${set('kind')}>${KINDS.map((k) => html`<option value=${k}>${k}</option>`)}</select><//>
      <${Field} label="Date"><input class="in" type="date" value=${m.date || ''} onInput=${set('date')} /><//>
      <${Field} label="Time"><input class="in" value=${m.time} onInput=${set('time')} placeholder="12:00-15:00" /><//>
      <${Field} label="Venue"><input class="in" value=${m.venue} onInput=${set('venue')} /><//>
      <${Field} label="Guests (pax)"><input class="in num" type="number" min="0" value=${m.pax} onInput=${set('pax')} /><//>
      <${Field} label="Food price / pax (฿)"><input class="in num" type="number" min="0" step="any" value=${m.price_per_pax} onInput=${set('price_per_pax')} /><//>
      <${Field} label="Beverage package / pax (฿)"><input class="in num" type="number" min="0" step="any" value=${m.bev_price_per_pax} onInput=${set('bev_price_per_pax')} /><//>
      <${Field} label="Wastage % (blank = event default)"><input class="in num" type="number" min="0" step="any" value=${m.wastage_pct ?? ''} onInput=${set('wastage_pct')} /><//>
      <label class="check full"><input type="checkbox" checked=${!!m.chargeable} onChange=${set('chargeable')} /> Charged to the client (untick for included items like breakfast or a chai station)</label>
      <${Field} label="Notes" cls="full"><textarea class="in" rows="2" value=${m.notes || ''} onInput=${set('notes')}></textarea><//>
    </div><//>`;
}

// ---------- editable table helper ----------
function EditTable({ cols, rows, setRows, empty, newRow, totalFn, disabled, totalAfter }) {
  const ta = totalAfter ? cols.findIndex((c) => c.k === totalAfter) : cols.length - 1;
  const upd = (i, k, v) => setRows(rows.map((r, j) => (j === i ? { ...r, [k]: v } : r)));
  return html`<div class="tw"><table class="edit">
    <thead><tr>${cols.map((c, j) => html`<th class=${c.r ? 'r' : ''} style=${c.w ? `width:${c.w}` : ''}>${c.label}</th>${totalFn && j === ta && html`<th class="r">Total</th>`}`)}<th class="tight"></th></tr></thead>
    <tbody>
      ${rows.map((r, i) => html`<tr key=${r._k || r.id || i}>${cols.map((c, j) => html`<td>${cell(c, r, (v) => upd(i, c.k, v), disabled)}</td>${totalFn && j === ta && html`<td class="r num" style="white-space:nowrap">${baht(totalFn(r))}</td>`}`)}
        <td><button class="icon-btn del" aria-label="Remove row" disabled=${disabled} onClick=${() => setRows(rows.filter((_, j) => j !== i))}>×</button></td></tr>`)}
      ${!rows.length && html`<tr><td colspan=${cols.length + 2} class="muted">${empty}</td></tr>`}
      ${totalFn && rows.length ? html`<tr class="total"><td colspan=${ta + 1}>Total</td><td class="r num" style="white-space:nowrap">${baht(rows.reduce((a, r) => a + totalFn(r), 0))}</td><td colspan=${cols.length - ta}></td></tr>` : ''}
    </tbody></table></div>
    ${!disabled && html`<button class="btn ghost" style="margin-top:6px" onClick=${() => setRows([...rows, { _k: uid(), ...newRow() }])}>+ Add row</button>`}`;
}
function cell(c, r, set, disabled) {
  const v = r[c.k] ?? '';
  if (c.type === 'select') return html`<select class="in" value=${v ?? ''} disabled=${disabled} onChange=${(e) => set(e.target.value === '' ? null : c.num ? +e.target.value : e.target.value)} aria-label=${c.label}>
    ${c.blank && html`<option value="">${c.blank}</option>`}${c.options.map(([val, l]) => html`<option value=${val}>${l}</option>`)}</select>`;
  if (c.type === 'number') return html`<input class="in num" type="number" step="any" value=${v} disabled=${disabled} onInput=${(e) => set(e.target.value)} aria-label=${c.label} style=${`width:${c.width || '80px'}`} />`;
  return html`<input class="in" type=${c.type || 'text'} value=${v} disabled=${disabled} list=${c.list} onInput=${(e) => set(e.target.value)} aria-label=${c.label} style=${c.minw ? `min-width:${c.minw}` : ''} />`;
}

function useListEditor(initial) {
  const [rows, setRowsRaw] = useState(initial);
  const [dirty, setDirty] = useState(false);
  useDirtyGuard(dirty);
  return { rows, dirty, setRows: (r) => { setRowsRaw(r); setDirty(true); }, reset: (r) => { setRowsRaw(r); setDirty(false); } };
}

function SaveBar({ dirty, onSave, busy, label = 'Save changes' }) {
  if (!dirty) return null;
  return html`<div class="savebar"><span class="dirty-dot"></span><span>Unsaved changes</span><span class="spacer"></span><button class="btn primary" disabled=${busy} onClick=${onSave}>${busy ? 'Saving…' : label}</button></div>`;
}

// ---------- labour ----------
function LabourTab({ ev, reload }) {
  const st = store.settings;
  const L = useListEditor(ev.labour);
  const [busy, setBusy] = useState(false);
  const mealOpts = ev.meals.map((m) => [m.id, `${fmtDay(m.date)} · ${m.name}`]);
  const cols = [
    { k: 'date', label: 'Date', type: 'date' },
    { k: 'department', label: 'Department', list: 'depts', minw: '110px' },
    { k: 'role', label: 'Position', minw: '90px' },
    { k: 'headcount', label: 'People', type: 'number', r: 1, width: '64px' },
    { k: 'time_from', label: 'From', minw: '64px' },
    { k: 'time_to', label: 'To', minw: '64px' },
    { k: 'hours', label: 'Hours', type: 'number', r: 1, width: '60px' },
    { k: 'rate', label: 'Rate / day ฿', type: 'number', r: 1, width: '80px' },
    { k: 'meal_id', label: 'Charge to meal', type: 'select', options: mealOpts, blank: 'Whole event', num: 1 },
    { k: 'form_ref', label: 'Form ref', minw: '90px' },
  ];
  const save = async () => {
    setBusy(true);
    try { await api(`/events/${ev.id}/labour`, { method: 'PUT', body: { rows: L.rows } }); toast('Labour saved'); const d = await reload(); L.reset(d.labour); }
    catch (e) { toastErr(e); }
    setBusy(false);
  };
  const byDept = {};
  for (const l of L.rows) byDept[l.department || 'Other'] = (byDept[l.department || 'Other'] || 0) + labourAmount(l);
  return html`<div class="stack">
    <div class="callout">Enter rows the way they appear on the Casual Labour Requisition Form: one row per position, date and shift. Total = people × rate per day.</div>
    <datalist id="depts">${st.labour_departments.map((d) => html`<option value=${d} />`)}</datalist>
    <${EditTable} cols=${cols} rows=${L.rows} setRows=${L.setRows} totalFn=${labourAmount} totalAfter="rate" disabled=${!can('events')} empty="No casual labour added."
      newRow=${() => ({ date: ev.start_date, department: 'Kitchen', role: '', headcount: 1, time_from: '09:00', time_to: '18:00', hours: 9, rate: 400, meal_id: null, form_ref: '' })} />
    <div class="row">${Object.entries(byDept).map(([k, v]) => html`<${Chip}>${k}: ${baht(v, 0)}<//>`)}</div>
    <${SaveBar} dirty=${L.dirty} busy=${busy} onSave=${save} />
  </div>`;
}

// ---------- other costs & revenue extras ----------
function CostsTab({ ev, reload }) {
  const st = store.settings;
  const C = useListEditor(ev.costs);
  const R = useListEditor(ev.revenue_items);
  const [busy, setBusy] = useState(false);
  const mealOpts = ev.meals.map((m) => [m.id, `${fmtDay(m.date)} · ${m.name}`]);
  const save = async () => {
    setBusy(true);
    try {
      if (C.dirty) await api(`/events/${ev.id}/costs`, { method: 'PUT', body: { rows: C.rows } });
      if (R.dirty) await api(`/events/${ev.id}/revenue-items`, { method: 'PUT', body: { rows: R.rows } });
      toast('Saved'); const d = await reload(); C.reset(d.costs); R.reset(d.revenue_items);
    } catch (e) { toastErr(e); }
    setBusy(false);
  };
  return html`<div class="stack">
    <section><h2 style="margin-bottom:4px">Other costs</h2><p class="note" style="margin-top:0">Costs to the hotel that are not food or casual labour: décor, rentals, transport, gas, printing…</p>
      <datalist id="costcats">${st.cost_categories.map((d) => html`<option value=${d} />`)}</datalist>
      <${EditTable} rows=${C.rows} setRows=${C.setRows} totalFn=${costAmount} disabled=${!can('events')} empty="No other costs added."
        totalAfter="rate" cols=${[{ k: 'category', label: 'Category', list: 'costcats', minw: '130px' }, { k: 'description', label: 'Description', minw: '200px' }, { k: 'qty', label: 'Qty', type: 'number', r: 1 },
          { k: 'unit', label: 'Unit' }, { k: 'rate', label: 'Rate ฿', type: 'number', r: 1 }, { k: 'supplier', label: 'Supplier' },
          { k: 'meal_id', label: 'Charge to meal', type: 'select', options: mealOpts, blank: 'Whole event', num: 1 }]}
        newRow=${() => ({ category: 'Other', description: '', qty: 1, unit: 'lot', rate: 0, supplier: '', meal_id: null })} /></section>
    <section><h2 style="margin-bottom:4px">Extra charges to the client</h2><p class="note" style="margin-top:0">Revenue on top of the meal packages, e.g. venue hire, extra bar, décor package. Uses the event's price basis (${ev.price_basis === 'net' ? 'net' : '++'}).</p>
      <${EditTable} rows=${R.rows} setRows=${R.setRows} totalFn=${(r) => n(r.qty) * n(r.unit_price)} disabled=${!can('events')} empty="No extra charges."
        cols=${[{ k: 'description', label: 'Description', minw: '240px' }, { k: 'qty', label: 'Qty', type: 'number', r: 1 }, { k: 'unit', label: 'Unit' }, { k: 'unit_price', label: 'Price ฿', type: 'number', r: 1 }, { k: 'note', label: 'Note' }]}
        newRow=${() => ({ description: '', qty: 1, unit: 'lot', unit_price: 0, note: '' })} /></section>
    <${SaveBar} dirty=${C.dirty || R.dirty} busy=${busy} onSave=${save} />
  </div>`;
}

// ---------- purchase list ----------
function PurchaseTab({ ev }) {
  const [meal, setMeal] = useState('');
  const [group, setGroup] = useState('category');
  const { data, error, loading } = useFetch(`/events/${ev.id}/purchase${meal ? '?meal=' + meal : ''}`);
  if (error) return html`<${ErrorBox} error=${error} />`;
  const rows = data || [];
  const key = (r) => (group === 'supplier' ? r.supplier || 'No supplier set' : group === 'date' ? (r.dates[0] ? fmtDay(r.dates[0]) : 'No date') : r.category);
  const groups = new Map();
  for (const r of rows) { const k = key(r); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(r); }
  const keys = [...groups.keys()].sort();
  const total = rows.reduce((a, r) => a + r.cost, 0);
  return html`<div>
    <div class="row" style="margin-bottom:12px">
      <select class="in" style="width:auto" value=${meal} onChange=${(e) => setMeal(e.target.value)} aria-label="Meal"><option value="">All meals</option>${ev.meals.map((m) => html`<option value=${m.id}>${fmtDay(m.date)} · ${m.name}</option>`)}</select>
      <select class="in" style="width:auto" value=${group} onChange=${(e) => setGroup(e.target.value)} aria-label="Group by"><option value="category">Group by category</option><option value="supplier">Group by supplier</option><option value="date">Group by first date needed</option></select>
      <span class="spacer"></span><span class="muted small">${rows.length} items · ${baht(total, 0)}</span>
      <a class="btn" href=${`/api/events/${ev.id}/purchase.xlsx${meal ? '?meal=' + meal : ''}`}>Export to Excel</a>
    </div>
    <p class="note" style="margin-top:0">Quantities are every recipe scaled to the meal's pax and uptake %, plus wastage, with sub-recipes broken down into ingredients.</p>
    ${loading && !data ? html`<${Loading} />` : rows.length ? html`<div class="tw"><table>
      <thead><tr><th>Ingredient</th><th class="r">Quantity</th><th class="r">Rate</th><th class="r">Est. cost</th><th>Price</th><th>Needed</th><th>Used in</th></tr></thead>
      <tbody>${keys.map((k) => html`<tr class="sec"><td colspan="7">${k}</td></tr>${groups.get(k).map((r) => html`<tr>
        <td><b>${r.name}</b> <span class="mono small muted">${r.code}</span></td><td class="r num" style="white-space:nowrap">${fmtQty(r.qty, r.base)}</td>
        <td class="r num small" style="white-space:nowrap">${r.price == null ? '–' : baht(r.price) + ' / ' + baseLabel(r.base)}</td><td class="r num">${baht(r.cost, 0)}</td>
        <td><${PriceChip} status=${r.status} /></td><td class="small" style="white-space:nowrap">${r.dates.map((d) => fmtDate(d, { day: 'numeric', month: 'short' })).join(', ')}</td>
        <td class="small muted" style="max-width:340px">${r.dishes.slice(0, 4).join(', ')}${r.dishes.length > 4 ? ` +${r.dishes.length - 4} more` : ''}</td></tr>`)}`)}
        <tr class="total"><td colspan="3">Total</td><td class="r num">${baht(total, 0)}</td><td colspan="3"></td></tr></tbody></table></div>`
    : html`<${Empty} title="Nothing to buy yet">Add dishes with recipes to the meals and the shopping list appears here.<//>`}
  </div>`;
}

// ---------- quotations ----------
function QuotesTab({ ev, reload }) {
  const [making, setMaking] = useState(false);
  const [terms, setTerms] = useState(store.settings.quote_terms);
  const [note, setNote] = useState('');
  const [menu, setMenu] = useState(true);
  const create = async () => {
    try { const r = await api(`/events/${ev.id}/quotations`, { method: 'POST', body: { terms, note, include_menu: menu } }); toast('Quotation ' + r.number + ' created'); setMaking(false); await reload(); window.open('#/print/quote/' + r.id, '_blank'); }
    catch (e) { toastErr(e); }
  };
  const setStatus = async (qq, status) => { try { await api('/quotations/' + qq.id, { method: 'PUT', body: { status } }); reload(); } catch (e) { toastErr(e); } };
  const QS = { draft: 'ok', sent: 'acc', accepted: 'good', declined: 'bad', expired: 'warn' };
  return html`<div class="stack">
    <div class="row"><p class="note" style="margin:0">A quotation is a fixed snapshot of the meals, prices and menu at the time you create it. Change the event, then create a new version.</p><span class="spacer"></span>
      ${can('events') && html`<button class="btn primary" onClick=${() => setMaking(true)}>+ New quotation</button>`}</div>
    ${ev.quotations.length ? html`<div class="tw"><table><thead><tr><th>Number</th><th>Created</th><th>Valid until</th><th>Status</th><th></th></tr></thead>
      <tbody>${ev.quotations.map((qq) => html`<tr><td class="mono"><b>${qq.number}</b></td><td>${fmtDate(qq.created_at)}</td><td>${fmtDate(qq.valid_until)}</td>
        <td><select class="in" style="width:auto" value=${qq.status} disabled=${!can('events')} onChange=${(e) => setStatus(qq, e.target.value)} aria-label="Status">${Object.keys(QS).map((k) => html`<option value=${k}>${k}</option>`)}</select></td>
        <td class="r"><a class="btn sm" href=${'#/print/quote/' + qq.id} target="_blank" rel="noopener">Open / print</a></td></tr>`)}</tbody></table></div>`
    : html`<${Empty} title="No quotations yet">Create a quotation to send the client: meals, prices, service charge, VAT, menus and terms on one printable page.<//>`}
    ${making && html`<${Modal} title="New quotation" onClose=${() => setMaking(false)} footer=${html`<button class="btn" onClick=${() => setMaking(false)}>Cancel</button><button class="btn primary" onClick=${create}>Create & open</button>`}>
      <div class="stack" style="gap:12px">
        <div class="kv"><span>Client total</span><b class="num">${baht(ev.summary.clientTotal, 0)}</b></div>
        <${Field} label="Note to client (optional)"><textarea class="in" rows="2" value=${note} onInput=${(e) => setNote(e.target.value)}></textarea><//>
        <${Field} label="Terms & conditions"><textarea class="in" rows="5" value=${terms} onInput=${(e) => setTerms(e.target.value)}></textarea><//>
        <label class="check"><input type="checkbox" checked=${menu} onChange=${(e) => setMenu(e.target.checked)} /> Include the menus</label>
      </div><//>`}
  </div>`;
}

// ---------- details ----------
function DetailsTab({ ev, reload }) {
  const st = store.settings;
  const [f, setF] = useState(ev);
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  useDirtyGuard(dirty);
  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); setDirty(true); };
  const save = async () => {
    setBusy(true);
    try { await api('/events/' + ev.id, { method: 'PUT', body: f }); toast('Event saved'); setDirty(false); const d = await reload(); setF(d); }
    catch (e) { toastErr(e); }
    setBusy(false);
  };
  const dup = async () => {
    try { const r = await api(`/events/${ev.id}/duplicate`, { method: 'POST', body: {} }); toast('Event duplicated'); go('#/events/' + r.id + '/details'); } catch (e) { toastErr(e); }
  };
  const del = async () => { try { await api('/events/' + ev.id, { method: 'DELETE' }); toast('Event deleted'); go('#/events'); } catch (e) { toastErr(e); } };
  const dis = !can('events');
  return html`<div class="stack">
    <section class="panel"><fieldset disabled=${dis} style="border:0;padding:0;margin:0;min-width:0"><div class="fields">
      <${Field} label="Event name" cls="span2"><input class="in" value=${f.name} onInput=${set('name')} /><//>
      <${Field} label="Type"><input class="in" value=${f.event_type} onInput=${set('event_type')} /><//>
      <${Field} label="Status"><select class="in" value=${f.status} onChange=${set('status')}>${Object.entries(EVENT_STATUS).map(([k, [t]]) => html`<option value=${k}>${t}</option>`)}</select><//>
      <${Field} label="Client" cls="span2"><input class="in" value=${f.client_name} onInput=${set('client_name')} /><//>
      <${Field} label="Contact person"><input class="in" value=${f.client_contact} onInput=${set('client_contact')} /><//>
      <${Field} label="Phone"><input class="in" value=${f.client_phone} onInput=${set('client_phone')} /><//>
      <${Field} label="Email" cls="span2"><input class="in" type="email" value=${f.client_email} onInput=${set('client_email')} /><//>
      <${Field} label="Venue"><input class="in" value=${f.venue} onInput=${set('venue')} /><//>
      <${Field} label="Start date"><input class="in" type="date" value=${f.start_date || ''} onInput=${set('start_date')} /><//>
      <${Field} label="End date"><input class="in" type="date" value=${f.end_date || ''} onInput=${set('end_date')} /><//>
      <${Field} label="Prices quoted as" cls="span2"><select class="in" value=${f.price_basis} onChange=${set('price_basis')}>
        <option value="plus_plus">++ (service ${st.service_pct}% + VAT ${st.vat_pct}% added)</option><option value="net">Net (service & VAT included)</option></select><//>
      <${Field} label="Target cost %"><input class="in num" type="number" step="any" value=${f.target_pct} onInput=${set('target_pct')} /><//>
      <${Field} label="Default wastage %"><input class="in num" type="number" step="any" value=${f.wastage_pct} onInput=${set('wastage_pct')} /><//>
      <${Field} label="Notes, client requests, things to confirm" cls="full"><textarea class="in" rows="6" value=${f.notes} onInput=${set('notes')}></textarea><//>
    </div></fieldset></section>
    <div class="row">${can('events') && html`<button class="btn" onClick=${dup}>Duplicate event</button>`}
      ${can('deleteEvents') && html`<${ConfirmButton} onConfirm=${del} confirmText="Delete event and all its meals?">Delete event<//>`}</div>
    <${SaveBar} dirty=${dirty} busy=${busy} onSave=${save} />
  </div>`;
}
