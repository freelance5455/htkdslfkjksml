import { html, useState, useEffect, useFetch, api, baht, fmt, fmtRate, fmtDate, n, store, useStore, can, toast, toastErr, go, uid, useDirtyGuard, loadCatalog, baseLabel } from '../lib.js';
import { Loading, ErrorBox, Chip, Diet, Empty, Combo, ConfirmButton, Field, PriceChip, NumIn } from '../ui.js';
import { lineCost, unitsFor, subBase, STATUS } from '../costing.js';

const q = () => new URLSearchParams(location.hash.split('?')[1] || '');
const DIETS = [['veg', 'Vegetarian'], ['nonveg', 'Non-veg'], ['both', 'Veg & non-veg'], ['egg', 'Contains egg']];

/** Costing context built from the catalogue (recipe costs pre-computed by the server). */
export function clientCtx(cat) {
  if (cat._ctx) return cat._ctx;
  const memo = new Map(cat.recipes.map((r) => [r.id, { total: r.total, perPortion: r.per_portion, perBase: r.per_base, issues: r.issues }]));
  cat._ctx = { ing: cat.ingById, rec: cat.recById, memo };
  return cat._ctx;
}

// ===================== list =====================
export function RecipesList() {
  const s = useStore();
  const cat = s.catalog;
  const [search, setSearch] = useState('');
  const [section, setSection] = useState('');
  const [diet, setDiet] = useState('');
  const [status, setStatus] = useState(q().get('empty') ? 'empty' : '');
  const [sort, setSort] = useState('name');
  const t = search.trim().toLowerCase().split(/\s+/).filter(Boolean);
  let rows = cat.recSearch.filter(({ r, s: hay }) => r.active && (!section || r.section === section) && (!diet || r.diet === diet)
    && (!status || (status === 'empty' ? !r.lines : status === 'issues' ? r.issues.none + r.issues.confirm > 0 : r.status === status)) && t.every((w) => hay.includes(w))).map((x) => x.r);
  rows = rows.sort(sort === 'cost' ? (a, b) => b.per_portion - a.per_portion : sort === 'section' ? (a, b) => a.section.localeCompare(b.section) || a.name.localeCompare(b.name) : (a, b) => a.name.localeCompare(b.name));
  const sections = [...new Set(cat.recipes.map((r) => r.section))].sort();
  return html`<div>
    <div class="page-head"><div class="grow"><div class="eyebrow">Kitchen</div><h1>Recipe library</h1></div>
      <a class="btn" href="/api/recipes/export.xlsx">Export cost cards (Excel)</a>
      ${can('recipes') && html`<a class="btn primary" href="#/recipes/new">+ New recipe</a>`}</div>
    <div class="row" style="margin-bottom:12px">
      <input class="in" style="max-width:280px" type="search" placeholder="Search recipes" value=${search} onInput=${(e) => setSearch(e.target.value)} aria-label="Search recipes" />
      <select class="in" style="width:auto" value=${section} onChange=${(e) => setSection(e.target.value)} aria-label="Section"><option value="">All sections</option>${sections.map((x) => html`<option value=${x}>${x}</option>`)}</select>
      <select class="in" style="width:auto" value=${diet} onChange=${(e) => setDiet(e.target.value)} aria-label="Diet"><option value="">Any diet</option>${DIETS.map(([k, l]) => html`<option value=${k}>${l}</option>`)}</select>
      <select class="in" style="width:auto" value=${status} onChange=${(e) => setStatus(e.target.value)} aria-label="Status"><option value="">Any status</option><option value="standard">Standard</option><option value="draft">Draft</option><option value="empty">No ingredients yet</option><option value="issues">Price issues</option></select>
      <select class="in" style="width:auto" value=${sort} onChange=${(e) => setSort(e.target.value)} aria-label="Sort"><option value="name">Sort by name</option><option value="section">Sort by section</option><option value="cost">Highest cost first</option></select>
      <span class="spacer"></span><span class="muted small">${rows.length} recipes</span>
    </div>
    ${rows.length ? html`<div class="tw"><table>
      <thead><tr><th>Recipe</th><th>Section</th><th class="r">Yield</th><th class="r">Batch cost</th><th class="r">Cost / portion</th><th>Status</th><th>Prices</th></tr></thead>
      <tbody>${rows.slice(0, 400).map((r) => html`<tr class="click" onClick=${() => go('#/recipes/' + r.id)}>
        <td><div class="row" style="gap:6px;flex-wrap:nowrap"><${Diet} d=${r.diet} /><b>${r.name}</b></div></td><td class="small">${r.section}</td>
        <td class="r num small">${r.is_sub ? `${fmt(r.yield_qty, 2)} ${r.yield_unit}` : `${fmt(r.yield_pax, 0)} pax`}</td>
        <td class="r num">${baht(r.total)}</td><td class="r num">${r.is_sub ? baht(r.per_base) + ' / ' + (r.yield_unit || 'kg') : baht(r.per_portion)}</td>
        <td>${!r.lines ? html`<${Chip} c="bad">No ingredients<//>` : r.status === 'draft' ? html`<${Chip} c="warn">Draft<//>` : html`<${Chip} c="good">Standard<//>`}</td>
        <td class="small">${r.issues.none ? html`<${Chip} c="bad">${r.issues.none} missing<//> ` : ''}${r.issues.confirm ? html`<${Chip} c="warn">${r.issues.confirm} to confirm<//> ` : ''}${r.issues.estimate ? html`<${Chip} c="est">${r.issues.estimate} est.<//>` : ''}</td>
      </tr>`)}</tbody></table></div>` : html`<${Empty} title="No recipes match">Try a shorter search or clear the filters.<//>`}
  </div>`;
}

// ===================== editor =====================
export function RecipeEditor({ id }) {
  const { data, error, loading, reload } = useFetch(id ? '/recipes/' + id : '/settings');
  if (loading && !data) return html`<${Loading} />`;
  if (error) return html`<${ErrorBox} error=${error} retry=${reload} />`;
  const initial = id ? data : { name: '', section: 'Veg Mains', diet: 'veg', yield_pax: 10, is_sub: 0, yield_qty: null, yield_unit: 'kg', aliases: '', method: '', notes: '', status: 'draft', lines: [], used_in: [], used_as_sub: [] };
  return html`<${Editor} key=${id || 'new'} id=${id} initial=${initial} reload=${reload} />`;
}

function Editor({ id, initial, reload }) {
  const s = useStore();
  const cat = s.catalog;
  const ctx = clientCtx(cat);
  const [r, setR] = useState(() => ({ ...initial, lines: initial.lines.map((l) => ({ ...l, _k: uid() })) }));
  const [dirty, setDirty] = useState(!id);
  const [busy, setBusy] = useState(false);
  useDirtyGuard(dirty && !!id);
  const ro = !can('recipes');
  const change = (next) => { setR(next); setDirty(true); };
  const set = (k) => (e) => change({ ...r, [k]: e.target.type === 'checkbox' ? (e.target.checked ? 1 : 0) : e.target.value });
  const setLine = (k, patch) => change({ ...r, lines: r.lines.map((l) => (l._k === k ? { ...l, ...patch } : l)) });
  const costs = r.lines.map((l) => lineCost(l, ctx, new Set([id])));
  const total = costs.reduce((a, c) => a + c.cost, 0);
  const yp = n(r.yield_pax) || 1;
  const issues = { none: 0, confirm: 0, estimate: 0 };
  costs.forEach((c, i) => { if (n(r.lines[i].qty) > 0 && issues[c.status] !== undefined) issues[c.status]++; if (!c.unitOk) issues.none++; });

  const save = async () => {
    if (!r.name.trim()) return toast('Give the recipe a name.', true);
    const lines = r.lines.filter((l) => l.ingredient_id || l.sub_recipe_id || (l.custom_name || '').trim());
    setBusy(true);
    try {
      if (id) {
        await api('/recipes/' + id, { method: 'PUT', body: { ...r, lines } });
        setDirty(false);
        toast('Recipe saved');
        await loadCatalog();
        const d = await reload();
        setR({ ...d, lines: d.lines.map((l) => ({ ...l, _k: uid() })) });
      } else {
        const x = await api('/recipes', { method: 'POST', body: { ...r, lines } });
        setDirty(false);
        await loadCatalog();
        toast('Recipe created');
        go('#/recipes/' + x.id);
      }
    } catch (e) { toastErr(e); }
    setBusy(false);
  };
  const dup = async () => { try { const x = await api(`/recipes/${id}/duplicate`, { method: 'POST', body: {} }); await loadCatalog(); go('#/recipes/' + x.id); } catch (e) { toastErr(e); } };
  const del = async () => { try { const x = await api('/recipes/' + id, { method: 'DELETE' }); await loadCatalog(); toast(x.archived ? 'Recipe archived (it is used in events)' : 'Recipe deleted'); go('#/recipes'); } catch (e) { toastErr(e); } };
  const addLine = (item) => {
    let l = { _k: uid(), ingredient_id: null, sub_recipe_id: null, custom_name: null, qty: '', unit: 'g', rate_override: null, note: '' };
    if (item.kind === 'ing') l = { ...l, ingredient_id: item.i.id, unit: unitsFor(item.i.unit)[0] };
    else if (item.kind === 'sub') { const sb = subBase(item.r); l = { ...l, sub_recipe_id: item.r.id, unit: sb === 'portion' ? 'portion' : unitsFor(sb)[0] }; }
    else l = { ...l, custom_name: item.name, unit: 'g' };
    change({ ...r, lines: [...r.lines, l] });
    setTimeout(() => { const el = document.querySelector(`[data-qty="${l._k}"]`); el && el.focus(); }, 30);
  };
  const move = (k, d) => { const ls = [...r.lines]; const i = ls.findIndex((x) => x._k === k); const j = i + d; if (j < 0 || j >= ls.length) return; [ls[i], ls[j]] = [ls[j], ls[i]]; change({ ...r, lines: ls }); };

  return html`<div>
    <div class="crumbs"><a href="#/recipes">Recipe library</a> /</div>
    <div class="page-head"><div class="grow"><h1>${r.name || 'New recipe'}</h1>
      ${id && html`<div class="small muted" style="margin-top:4px">Last saved ${fmtDate(initial.updated_at)}${initial.creator ? ' · created by ' + initial.creator : ''}</div>`}</div>
      ${id && can('recipes') && html`<button class="btn" onClick=${dup}>Duplicate</button><${ConfirmButton} onConfirm=${del}>${initial.used_in?.length || initial.used_as_sub?.length ? 'Archive' : 'Delete'}<//>`}</div>
    <div class="two-col">
      <div class="stack">
        <section class="panel"><fieldset disabled=${ro} style="border:0;padding:0;margin:0;min-width:0"><div class="fields">
          <${Field} label="Recipe name" cls="full"><input class="in" value=${r.name} onInput=${set('name')} placeholder="e.g. Paneer Makhani" /><//>
          <${Field} label="Menu section"><select class="in" value=${r.section} onChange=${set('section')}>${s.settings.sections.map((x) => html`<option value=${x}>${x}</option>`)}</select><//>
          <${Field} label="Diet"><select class="in" value=${r.diet} onChange=${set('diet')}>${DIETS.map(([k, l]) => html`<option value=${k}>${l}</option>`)}</select><//>
          <${Field} label="Recipe makes (portions)"><input class="in num" type="number" min="1" step="any" value=${r.yield_pax} onInput=${set('yield_pax')} /><//>
          <${Field} label="Status"><select class="in" value=${r.status} onChange=${set('status')}><option value="draft">Draft</option><option value="standard">Standard (approved)</option></select><//>
          <label class="check full"><input type="checkbox" checked=${!!r.is_sub} onChange=${set('is_sub')} /> This is a base or sub-recipe (gravy, chutney, dough…) that other recipes use as an ingredient</label>
          ${!!r.is_sub && html`<${Field} label="Batch yield"><input class="in num" type="number" step="any" min="0" value=${r.yield_qty ?? ''} onInput=${set('yield_qty')} /><//>
            <${Field} label="Yield unit"><select class="in" value=${r.yield_unit || 'kg'} onChange=${set('yield_unit')}><option value="kg">kg</option><option value="L">litres</option><option value="portion">portions</option></select><//>`}
          <${Field} label="Other names (menu spellings, separated by |)" cls="full"><input class="in" value=${r.aliases} onInput=${set('aliases')} placeholder="e.g. Paneer Butter Masala | Shahi Paneer" /><//>
        </div></fieldset></section>

        <section>
          <div class="row" style="margin-bottom:8px"><h2>Ingredients</h2><span class="muted small">quantities for the whole batch (${fmt(yp, 0)} portions)</span></div>
          <div class="tw"><table class="edit">
            <thead><tr><th>Item</th><th class="r">Qty</th><th>Unit</th><th class="r">Rate ฿</th><th class="r">Cost</th><th class="tight"></th></tr></thead>
            <tbody>
              ${r.lines.map((l, i) => html`<${LineRow} key=${l._k} l=${l} c=${costs[i]} ro=${ro} setLine=${setLine} move=${move} remove=${() => change({ ...r, lines: r.lines.filter((x) => x._k !== l._k) })} />`)}
              ${!r.lines.length && html`<tr><td colspan="6" class="muted">No ingredients yet. Search below to add the first one.</td></tr>`}
              ${r.lines.length ? html`<tr class="total"><td colspan="4">Batch total</td><td class="r num">${baht(total)}</td><td></td></tr>` : ''}
            </tbody></table></div>
          ${!ro && html`<div style="margin-top:8px;border:1px solid var(--line);border-radius:8px;background:var(--surface)"><${Combo} placeholder="+ Add ingredient or sub-recipe — search by name, code or kitchen spelling" ariaLabel="Add ingredient"
            search=${(qq) => searchItems(cat, qq, id)} onPick=${addLine}
            extra=${(qq) => ({ key: '__c', label: `Add “${qq}” as a custom item`, sub: 'Not in the price list — you enter the rate. Better: add it to Ingredients & prices.', value: { kind: 'custom', name: qq } })} /></div>`}
        </section>
        <section class="panel"><fieldset disabled=${ro} style="border:0;padding:0;margin:0;min-width:0" class="stack">
          <${Field} label="Method / preparation notes"><textarea class="in" rows="6" value=${r.method} onInput=${set('method')} placeholder="Steps, plating, holding temperature…"></textarea><//>
          <${Field} label="Costing notes"><textarea class="in" rows="2" value=${r.notes} onInput=${set('notes')}></textarea><//>
        </fieldset></section>
      </div>
      <aside class="sticky">
        <div class="costcard"><div class="top"><div class="eyebrow">${r.is_sub ? 'Cost per ' + (r.yield_unit || 'kg') : 'Cost per portion'}</div>
          <div class="big">${r.is_sub ? baht(total / (r.yield_unit === 'portion' ? yp : n(r.yield_qty) || 1)) : baht(total / yp)}</div>
          <div class="small" style="color:var(--band-muted)">Batch ${baht(total)} · ${r.lines.length} lines</div></div>
          <div class="body">
            ${issues.none + issues.confirm + issues.estimate === 0 ? html`<${Chip} c="good">All prices confirmed<//>` : html`<div class="stack" style="gap:6px;font-size:12.5px">
              ${issues.none ? html`<div><${Chip} c="bad">${issues.none} no price / unit mismatch<//></div>` : ''}
              ${issues.confirm ? html`<div><${Chip} c="warn">${issues.confirm} price to confirm<//></div>` : ''}
              ${issues.estimate ? html`<div><${Chip} c="est">${issues.estimate} estimated price<//></div>` : ''}</div>`}
          </div></div>
        ${id && html`<div class="panel"><div class="eyebrow" style="margin-bottom:8px">Used in</div>
          ${initial.used_in.length ? initial.used_in.map((u) => html`<div class="small" style="padding:3px 0"><a href=${`#/events/${u.event_id}/meals/${u.meal_id}`}>${u.event_name}</a> · ${u.meal_name} <span class="muted">${fmtDate(u.date)}</span></div>`) : html`<p class="note" style="margin:0">Not used in any event yet.</p>`}
          ${initial.used_as_sub.length ? html`<div class="eyebrow" style="margin:10px 0 4px">Sub-recipe of</div>${initial.used_as_sub.map((u) => html`<div class="small"><a href=${'#/recipes/' + u.id}>${u.name}</a></div>`)}` : ''}
        </div>`}
        <p class="note">Changing a recipe updates every event that uses it. Quotations already created keep their numbers.</p>
      </aside>
    </div>
    ${dirty && !ro && html`<div class="savebar"><span class="dirty-dot"></span><span>${id ? 'Unsaved changes' : 'New recipe – not saved yet'}</span><span class="spacer"></span>
      <button class="btn primary" disabled=${busy} onClick=${save}>${busy ? 'Saving…' : id ? 'Save recipe' : 'Create recipe'}</button></div>`}
  </div>`;
}

function searchItems(cat, qq, selfId) {
  const t = qq.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (!t.length) return [];
  const ql = qq.trim().toLowerCase();
  const ings = cat.ingSearch.filter((x) => x.i.active && t.every((w) => x.s.includes(w))).map((x) => x.i)
    .sort((a, b) => (b.name.toLowerCase().startsWith(ql) - a.name.toLowerCase().startsWith(ql)) || a.name.length - b.name.length).slice(0, 25)
    .map((i) => ({ key: 'i' + i.id, value: { kind: 'ing', i }, label: i.name, sub: `${i.code} · ${i.category}`,
      right: html`${i.price == null ? 'no price' : '฿' + fmtRate(i.price) + ' / ' + baseLabel(i.unit)}<br/><${PriceChip} status=${i.price_status} />` }));
  const subs = cat.recSearch.filter((x) => x.r.is_sub && x.r.active && x.r.id !== selfId && t.every((w) => x.s.includes(w))).slice(0, 8)
    .map(({ r }) => ({ key: 'r' + r.id, value: { kind: 'sub', r }, label: r.name, sub: 'Sub-recipe', right: baht(r.per_base) + ' / ' + (r.yield_unit || 'kg') }));
  return [...subs, ...ings];
}

function LineRow({ l, c, ro, setLine, move, remove }) {
  const s = useStore();
  const cat = s.catalog;
  const it = l.ingredient_id ? cat.ingById.get(l.ingredient_id) : null;
  const sub = l.sub_recipe_id ? cat.recById.get(l.sub_recipe_id) : null;
  const units = it ? unitsFor(it.unit) : sub ? (subBase(sub) === 'portion' ? ['portion'] : unitsFor(subBase(sub))) : ['g', 'kg', 'ml', 'L', 'No', 'Pack', 'Box', 'Bottle', 'Can'];
  const listRate = it ? it.price : sub ? sub.per_base : null;
  const hasRate = l.rate_override !== null && l.rate_override !== undefined && l.rate_override !== '';
  return html`<tr class=${'st-' + (c.unitOk ? c.status : 'none')}>
    <td style="min-width:240px">
      ${it ? html`<a href=${'#/ingredients/' + it.id} style="font-weight:500">${it.name}</a>` : sub ? html`<a href=${'#/recipes/' + sub.id} style="font-weight:500">${sub.name}</a>`
        : html`<input class="in bare" value=${l.custom_name} disabled=${ro} onInput=${(e) => setLine(l._k, { custom_name: e.target.value })} aria-label="Custom item name" />`}
      <div class="sub">${it ? html`<span class="mono">${it.code}</span>` : sub ? 'Sub-recipe' : 'Custom item'}
        <${PriceChip} status=${c.unitOk ? c.status : 'none'} title=${it?.note || ''} />${!c.unitOk ? html`<span style="color:var(--bad)">unit doesn't match ${it ? it.unit : ''}</span>` : ''}</div></td>
    <td class="r"><input class="in num" type="number" step="any" min="0" style="width:90px" data-qty=${l._k} value=${l.qty} disabled=${ro} aria-label="Quantity" onInput=${(e) => setLine(l._k, { qty: e.target.value })} /></td>
    <td><select class="in" style="width:78px" value=${l.unit} disabled=${ro} aria-label="Unit" onChange=${(e) => setLine(l._k, { unit: e.target.value })}>${units.map((u) => html`<option value=${u}>${u}</option>`)}${!units.includes(l.unit) && html`<option value=${l.unit}>${l.unit}</option>`}</select></td>
    <td class="r"><input class="in num" type="number" step="any" min="0" style="width:96px" value=${l.rate_override ?? ''} disabled=${ro || !!sub} aria-label="Rate override"
        placeholder=${listRate != null ? fmtRate(listRate) : 'rate'} onInput=${(e) => setLine(l._k, { rate_override: e.target.value === '' ? null : e.target.value })} />
      <div class="sub" style="justify-content:flex-end">per ${baseLabel(c.base || (it && it.unit) || 'Kg')}${hasRate && it ? ' · line rate' : ''}</div></td>
    <td class="r num">${baht(c.cost)}</td>
    <td style="white-space:nowrap">${!ro && html`<button class="icon-btn" aria-label="Move up" onClick=${() => move(l._k, -1)}>↑</button><button class="icon-btn" aria-label="Move down" onClick=${() => move(l._k, 1)}>↓</button><button class="icon-btn del" aria-label="Remove" onClick=${remove}>×</button>`}</td>
  </tr>`;
}
