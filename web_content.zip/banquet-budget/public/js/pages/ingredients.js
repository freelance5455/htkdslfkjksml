import { html, useState, useEffect, useFetch, api, baht, fmt, fmtRate, fmtDate, n, store, useStore, can, toast, toastErr, go, loadCatalog, fileToBase64, baseLabel } from '../lib.js';
import { Loading, ErrorBox, Chip, Empty, Modal, ConfirmButton, Field, PriceChip } from '../ui.js';
import { STATUS } from '../costing.js';

const UNITS = ['Kg', 'Gms', 'Lit', 'Ml', 'No', 'Pack', 'Pkt', 'Box', 'Can', 'Bottle'];
const q = () => new URLSearchParams(location.hash.split('?')[1] || '');

export function IngredientsPage({ focus }) {
  const s = useStore();
  const cat = s.catalog;
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [status, setStatus] = useState(q().get('status') || '');
  const [open, setOpen] = useState(focus || null);
  const [importing, setImporting] = useState(false);
  useEffect(() => setOpen(focus || null), [focus]);
  const t = search.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const rows = cat.ingSearch.filter(({ i, s: hay }) => i.active && (!category || i.category === category) && (!status || i.price_status === status) && t.every((w) => hay.includes(w))).map((x) => x.i);
  const cats = [...new Set(cat.ingredients.map((i) => i.category))].sort();
  const counts = {};
  for (const i of cat.ingredients) if (i.active) counts[i.price_status] = (counts[i.price_status] || 0) + 1;
  const close = () => { setOpen(null); if (focus) history.replaceState(null, '', '#/ingredients'); };
  return html`<div>
    <div class="page-head"><div class="grow"><div class="eyebrow">Kitchen</div><h1>Ingredients & prices</h1></div>
      <a class="btn" href="/api/ingredients/export.xlsx">Export price list</a>
      ${can('ingredients') && html`<button class="btn" onClick=${() => setImporting(true)}>Import prices from Excel</button><button class="btn primary" onClick=${() => setOpen('new')}>+ New ingredient</button>`}</div>
    <div class="row" style="margin-bottom:10px">
      <input class="in" style="max-width:300px" type="search" placeholder="Search name, code or Thai/kitchen spelling" value=${search} onInput=${(e) => setSearch(e.target.value)} aria-label="Search ingredients" />
      <select class="in" style="width:auto" value=${category} onChange=${(e) => setCategory(e.target.value)} aria-label="Category"><option value="">All categories</option>${cats.map((c) => html`<option value=${c}>${c}</option>`)}</select>
      <span class="spacer"></span><span class="muted small">${rows.length} of ${cat.ingredients.filter((i) => i.active).length}</span>
    </div>
    <div class="row" style="margin-bottom:12px;gap:6px">
      ${[['', 'All'], ...Object.entries(STATUS).filter(([k]) => counts[k]).map(([k, v]) => [k, v.t])].map(([k, label]) => html`<button class=${'chip ' + (k ? STATUS[k].c : 'ok')} style=${`border:0;cursor:pointer;${status === k ? 'outline:2px solid currentColor;outline-offset:1px' : ''}`}
        onClick=${() => setStatus(k)}>${label}${k ? ' · ' + counts[k] : ''}</button>`)}
    </div>
    ${rows.length ? html`<div class="tw"><table>
      <thead><tr><th>Code</th><th>Ingredient</th><th>Category</th><th>Unit</th><th class="r">Price ฿</th><th>Status</th><th>Supplier</th></tr></thead>
      <tbody>${rows.slice(0, 500).map((i) => html`<tr class="click" onClick=${() => setOpen(i.id)}>
        <td class="mono small">${i.code}</td><td><b>${i.name}</b>${i.aliases && html`<div class="small muted" style="max-width:360px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title=${i.aliases}>${i.aliases}</div>`}</td>
        <td class="small muted">${i.category}</td><td>${i.unit}</td><td class="r num">${i.price == null ? '–' : fmtRate(i.price)}</td>
        <td><${PriceChip} status=${i.price_status} title=${i.note} /></td><td class="small">${i.supplier_name || ''}</td></tr>`)}</tbody></table></div>
      ${rows.length > 500 && html`<p class="note">Showing the first 500. Search or filter to narrow down.</p>`}`
    : html`<${Empty} title="No ingredients match">Try a shorter search.<//>`}
    ${open && html`<${IngredientModal} id=${open === 'new' ? null : open} onClose=${close} />`}
    ${importing && html`<${ImportModal} onClose=${() => setImporting(false)} />`}
  </div>`;
}

function IngredientModal({ id, onClose }) {
  const { data, error, loading } = useFetch(id ? '/ingredients/' + id : '/suppliers');
  const sup = useFetch('/suppliers');
  const [f, setF] = useState(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (data && !f) setF(id ? { ...data } : { name: '', category: 'Vegetables & Fresh Produce', unit: 'Kg', price: '', aliases: '', note: '', supplier_id: null }); }, [data]);
  const ro = !can('ingredients');
  const cats = [...new Set(store.catalog.ingredients.map((i) => i.category))].sort();
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    setBusy(true);
    try {
      const body = { ...f, price: f.price === '' ? null : f.price, supplier_id: f.supplier_id || null };
      if (id) await api('/ingredients/' + id, { method: 'PUT', body }); else await api('/ingredients', { method: 'POST', body });
      await loadCatalog();
      toast(id ? 'Ingredient saved – recipe costs updated' : 'Ingredient added');
      onClose();
    } catch (e) { toastErr(e); }
    setBusy(false);
  };
  const archive = async () => { try { await api('/ingredients/' + id, { method: 'PUT', body: { active: 0 } }); await loadCatalog(); toast('Ingredient archived'); onClose(); } catch (e) { toastErr(e); } };
  return html`<${Modal} title=${id ? (data?.name || 'Ingredient') : 'New ingredient'} onClose=${onClose} wide
    footer=${!ro && f && html`${id && html`<${ConfirmButton} onConfirm=${archive} cls="btn ghost danger">Archive<//>`}<span class="spacer"></span><button class="btn" onClick=${onClose}>Cancel</button><button class="btn primary" disabled=${busy} onClick=${save}>Save</button>`}>
    ${error ? html`<p class="err">${error.message}</p>` : !f ? html`<${Loading} />` : html`<div class="grid" style="grid-template-columns:minmax(0,1.3fr) minmax(0,1fr)">
      <fieldset disabled=${ro} style="border:0;padding:0;margin:0;min-width:0"><div class="fields">
        <${Field} label="Name" cls="span2"><input class="in" value=${f.name} onInput=${set('name')} /><//>
        <${Field} label="Code"><input class="in mono" value=${f.code || ''} disabled=${!!id} onInput=${set('code')} placeholder="auto" /><//>
        <${Field} label="Category" cls="span2"><input class="in" list="ingcats" value=${f.category} onInput=${set('category')} /><datalist id="ingcats">${cats.map((c) => html`<option value=${c} />`)}</datalist><//>
        <${Field} label="Base unit"><select class="in" value=${f.unit} onChange=${set('unit')}>${UNITS.map((u) => html`<option value=${u}>${u}</option>`)}</select><//>
        <${Field} label=${'Price per ' + baseLabel(f.unit) + ' (฿)'}><input class="in num" type="number" step="any" min="0" value=${f.price ?? ''} onInput=${set('price')} /><//>
        <${Field} label="Price status"><select class="in" value=${f.price_status || 'direct'} onChange=${set('price_status')}>${Object.entries(STATUS).filter(([k]) => !['line', 'custom'].includes(k)).map(([k, v]) => html`<option value=${k}>${v.t}</option>`)}</select><//>
        <${Field} label="Supplier"><select class="in" value=${f.supplier_id || ''} onChange=${set('supplier_id')}><option value="">—</option>${(sup.data || []).map((x) => html`<option value=${x.id}>${x.name}</option>`)}</select><//>
        ${id && html`<${Field} label="Reason for price change (optional)" cls="span2"><input class="in" value=${f.price_note || ''} onInput=${set('price_note')} placeholder="e.g. Makro quote 25 Oct" /><//>`}
        <${Field} label="Other names: kitchen, supplier and Thai spellings (separate with |)" cls="full"><textarea class="in" rows="2" value=${f.aliases} onInput=${set('aliases')}></textarea><//>
        <${Field} label="Note" cls="full"><textarea class="in" rows="2" value=${f.note} onInput=${set('note')}></textarea><//>
      </div></fieldset>
      ${id ? html`<div class="stack" style="gap:12px">
        <div><div class="eyebrow" style="margin-bottom:6px">Price history</div>
          ${data.history.length ? html`<div class="tw"><table><tbody>${data.history.map((h) => html`<tr><td class="small">${fmtDate(h.at)}</td><td class="r num small">${h.old_price == null ? '' : fmtRate(h.old_price) + ' → '}<b>${h.new_price == null ? '–' : fmtRate(h.new_price)}</b></td><td class="small muted">${h.user_name || ''} ${h.note || ''}</td></tr>`)}</tbody></table></div>` : html`<p class="note">No changes yet.</p>`}</div>
        <div><div class="eyebrow" style="margin-bottom:6px">Used in ${data.used_in.length} recipe${data.used_in.length === 1 ? '' : 's'}</div>
          <div class="small" style="max-height:200px;overflow:auto">${data.used_in.map((r) => html`<div><a href=${'#/recipes/' + r.id} onClick=${onClose}>${r.name}</a></div>`)}</div></div>
      </div>` : html`<p class="note">The code is created from the category (e.g. VEG-112) unless you type one.</p>`}
    </div>`}
  <//>`;
}

function ImportModal({ onClose }) {
  const [file, setFile] = useState(null);
  const [addNew, setAddNew] = useState(false);
  const [res, setRes] = useState(null);
  const [busy, setBusy] = useState(false);
  const run = async () => {
    if (!file) return toast('Choose an .xlsx file first.', true);
    setBusy(true);
    try { const r = await api('/ingredients/import', { method: 'POST', body: { fileBase64: await fileToBase64(file), addNew } }); setRes(r); await loadCatalog(); }
    catch (e) { toastErr(e); }
    setBusy(false);
  };
  return html`<${Modal} title="Import prices from Excel" onClose=${onClose} footer=${html`<button class="btn" onClick=${onClose}>${res ? 'Done' : 'Cancel'}</button>${!res && html`<button class="btn primary" disabled=${busy} onClick=${run}>${busy ? 'Importing…' : 'Import'}</button>`}`}>
    ${res ? html`<div class="stack" style="gap:6px"><div class="kv"><span>Prices updated</span><b>${res.updated}</b></div><div class="kv"><span>Unchanged</span><b>${res.unchanged}</b></div>
      <div class="kv"><span>New ingredients added</span><b>${res.added}</b></div><div class="kv"><span>Rows skipped</span><b>${res.skipped}</b></div>
      ${res.notFound.length ? html`<p class="note">Codes not found: ${res.notFound.join(', ')}${res.skipped > res.notFound.length ? '…' : ''}. Tick "add new" to create them.</p>` : ''}</div>`
    : html`<div class="stack" style="gap:12px">
      <p class="note" style="margin:0">Use the exported price list or the Aviyana price list layout: a header row with <b>Item Code</b> and <b>Price per Unit</b>. Prices are matched by code; every change is kept in the price history.</p>
      <input type="file" accept=".xlsx" onChange=${(e) => setFile(e.target.files[0])} aria-label="Excel file" />
      <label class="check"><input type="checkbox" checked=${addNew} onChange=${(e) => setAddNew(e.target.checked)} /> Add codes that are not in the list yet as new ingredients</label>
    </div>`}
  <//>`;
}

// ===================== suppliers =====================
export function SuppliersPage() {
  const { data, error, loading, reload } = useFetch('/suppliers');
  const [edit, setEdit] = useState(null);
  if (loading && !data) return html`<${Loading} />`;
  if (error) return html`<${ErrorBox} error=${error} retry=${reload} />`;
  const save = async () => {
    try {
      if (edit.id) await api('/suppliers/' + edit.id, { method: 'PUT', body: edit }); else await api('/suppliers', { method: 'POST', body: edit });
      setEdit(null); reload(); toast('Supplier saved');
    } catch (e) { toastErr(e); }
  };
  const del = async (x) => { try { await api('/suppliers/' + x.id, { method: 'DELETE' }); reload(); await loadCatalog(); } catch (e) { toastErr(e); } };
  const set = (k) => (e) => setEdit({ ...edit, [k]: e.target.value });
  return html`<div>
    <div class="page-head"><div class="grow"><div class="eyebrow">Kitchen</div><h1>Suppliers</h1></div>${can('ingredients') && html`<button class="btn primary" onClick=${() => setEdit({ name: '', contact: '', phone: '', email: '', notes: '' })}>+ New supplier</button>`}</div>
    <p class="note" style="margin-top:-8px">Link ingredients to suppliers on the ingredient page; the purchase list can then be grouped by supplier.</p>
    ${data.length ? html`<div class="tw"><table><thead><tr><th>Supplier</th><th>Contact</th><th>Phone</th><th>Email</th><th class="r">Ingredients</th><th></th></tr></thead>
      <tbody>${data.map((x) => html`<tr><td><b>${x.name}</b>${x.notes && html`<div class="small muted">${x.notes}</div>`}</td><td>${x.contact}</td><td>${x.phone}</td><td>${x.email}</td><td class="r num">${x.items}</td>
        <td class="r" style="white-space:nowrap">${can('ingredients') && html`<button class="btn ghost sm" onClick=${() => setEdit({ ...x })}>Edit</button><${ConfirmButton} cls="btn ghost sm danger" onConfirm=${() => del(x)}>Delete<//>`}</td></tr>`)}</tbody></table></div>`
    : html`<${Empty} title="No suppliers yet">Add the hotel's suppliers (Makro, the fish market, the dairy…) and link ingredients to them.<//>`}
    ${edit && html`<${Modal} title=${edit.id ? 'Edit supplier' : 'New supplier'} onClose=${() => setEdit(null)} footer=${html`<button class="btn" onClick=${() => setEdit(null)}>Cancel</button><button class="btn primary" onClick=${save}>Save</button>`}>
      <div class="fields"><${Field} label="Name" cls="span2"><input class="in" value=${edit.name} onInput=${set('name')} /><//><${Field} label="Contact person"><input class="in" value=${edit.contact} onInput=${set('contact')} /><//>
        <${Field} label="Phone"><input class="in" value=${edit.phone} onInput=${set('phone')} /><//><${Field} label="Email" cls="span2"><input class="in" value=${edit.email} onInput=${set('email')} /><//>
        <${Field} label="Notes" cls="full"><textarea class="in" rows="2" value=${edit.notes} onInput=${set('notes')}></textarea><//></div><//>`}
  </div>`;
}
