import { html, useState, useEffect, useFetch, api, fmtDate, store, useStore, can, toast, toastErr, loadSettings, useDirtyGuard } from '../lib.js';
import { Loading, ErrorBox, Chip, Modal, Field, Tabs } from '../ui.js';

export function SettingsPage({ tab }) {
  const tabs = [['', 'Hotel & pricing'], ['menu', 'Sections & uptake'], ...(can('users') ? [['users', 'Users'], ['activity', 'Activity log']] : []), ['account', 'My account']];
  let body;
  if (tab === 'menu') body = html`<${MenuSettings} />`;
  else if (tab === 'users') body = html`<${Users} />`;
  else if (tab === 'activity') body = html`<${Activity} />`;
  else if (tab === 'account') body = html`<${Account} />`;
  else body = html`<${General} />`;
  return html`<div><div class="page-head"><div class="grow"><div class="eyebrow">Admin</div><h1>Settings</h1></div></div>
    <${Tabs} tabs=${tabs} current=${tab} base="#/settings" />${body}</div>`;
}

function useSettingsForm() {
  const s = useStore();
  const [f, setF] = useState(() => JSON.parse(JSON.stringify(s.settings)));
  const [dirty, setDirty] = useState(false);
  useDirtyGuard(dirty);
  const save = async () => {
    try { await api('/settings', { method: 'PUT', body: f }); await loadSettings(); setDirty(false); toast('Settings saved'); } catch (e) { toastErr(e); }
  };
  return { f, setF: (x) => { setF(x); setDirty(true); }, dirty, save, ro: !can('settings') };
}

function General() {
  const { f, setF, dirty, save, ro } = useSettingsForm();
  const set = (k, numeric) => (e) => setF({ ...f, [k]: numeric ? +e.target.value : e.target.value });
  return html`<div class="stack">
    <section class="panel"><fieldset disabled=${ro} style="border:0;padding:0;margin:0;min-width:0"><div class="fields">
      <${Field} label="Hotel name" cls="span2"><input class="in" value=${f.hotel_name} onInput=${set('hotel_name')} /><//>
      <${Field} label="Tax ID"><input class="in" value=${f.hotel_tax_id} onInput=${set('hotel_tax_id')} /><//>
      <${Field} label="Address" cls="full"><input class="in" value=${f.hotel_address} onInput=${set('hotel_address')} /><//>
      <${Field} label="Phone"><input class="in" value=${f.hotel_phone} onInput=${set('hotel_phone')} /><//>
      <${Field} label="Email" cls="span2"><input class="in" value=${f.hotel_email} onInput=${set('hotel_email')} /><//>
      <${Field} label="Service charge %"><input class="in num" type="number" step="any" value=${f.service_pct} onInput=${set('service_pct', 1)} /><//>
      <${Field} label="VAT %"><input class="in num" type="number" step="any" value=${f.vat_pct} onInput=${set('vat_pct', 1)} /><//>
      <${Field} label="Default target cost %"><input class="in num" type="number" step="any" value=${f.target_pct} onInput=${set('target_pct', 1)} /><//>
      <${Field} label="Default wastage %"><input class="in num" type="number" step="any" value=${f.wastage_pct} onInput=${set('wastage_pct', 1)} /><//>
      <${Field} label="Quotation valid for (days)"><input class="in num" type="number" value=${f.quote_validity_days} onInput=${set('quote_validity_days', 1)} /><//>
      <${Field} label="Default quotation terms" cls="full"><textarea class="in" rows="5" value=${f.quote_terms} onInput=${set('quote_terms')}></textarea><//>
      <${Field} label="Labour departments (one per line)" cls="span2"><textarea class="in" rows="6" value=${f.labour_departments.join('\n')} onInput=${(e) => setF({ ...f, labour_departments: e.target.value.split('\n').map((x) => x.trim()).filter(Boolean) })}></textarea><//>
      <${Field} label="Other cost categories (one per line)" cls="span2"><textarea class="in" rows="6" value=${f.cost_categories.join('\n')} onInput=${(e) => setF({ ...f, cost_categories: e.target.value.split('\n').map((x) => x.trim()).filter(Boolean) })}></textarea><//>
    </div></fieldset></section>
    ${dirty && html`<div class="savebar"><span class="dirty-dot"></span>Unsaved changes<span class="spacer"></span><button class="btn primary" onClick=${save}>Save settings</button></div>`}
  </div>`;
}

function MenuSettings() {
  const { f, setF, dirty, save, ro } = useSettingsForm();
  const [newSec, setNewSec] = useState('');
  const upd = (i, v) => { const sections = [...f.sections]; const old = sections[i]; sections[i] = v; const u = { ...f.uptake_defaults }; if (old in u) { u[v] = u[old]; delete u[old]; } setF({ ...f, sections, uptake_defaults: u }); };
  const move = (i, d) => { const s = [...f.sections]; const j = i + d; if (j < 0 || j >= s.length) return; [s[i], s[j]] = [s[j], s[i]]; setF({ ...f, sections: s }); };
  return html`<div class="stack">
    <p class="note" style="margin:0">Sections set the order dishes appear in meals and quotations. The uptake % is the default share of guests taking a full portion when a dish is added to a meal in that section.</p>
    <div class="tw" style="max-width:640px"><table class="edit"><thead><tr><th>Section</th><th class="r">Default uptake %</th><th class="tight"></th></tr></thead><tbody>
      ${f.sections.map((sec, i) => html`<tr key=${i}><td><input class="in" value=${sec} disabled=${ro} onChange=${(e) => upd(i, e.target.value)} aria-label="Section name" /></td>
        <td class="r"><input class="in num" type="number" style="width:90px" disabled=${ro} value=${f.uptake_defaults[sec] ?? 100} onInput=${(e) => setF({ ...f, uptake_defaults: { ...f.uptake_defaults, [sec]: +e.target.value } })} aria-label="Uptake %" /></td>
        <td style="white-space:nowrap">${!ro && html`<button class="icon-btn" aria-label="Move up" onClick=${() => move(i, -1)}>↑</button><button class="icon-btn" aria-label="Move down" onClick=${() => move(i, 1)}>↓</button>
          <button class="icon-btn del" aria-label="Remove section" onClick=${() => setF({ ...f, sections: f.sections.filter((_, j) => j !== i) })}>×</button>`}</td></tr>`)}
    </tbody></table></div>
    ${!ro && html`<div class="row"><input class="in" style="max-width:260px" placeholder="New section name" value=${newSec} onInput=${(e) => setNewSec(e.target.value)} />
      <button class="btn" onClick=${() => { if (newSec.trim()) { setF({ ...f, sections: [...f.sections, newSec.trim()] }); setNewSec(''); } }}>+ Add section</button></div>`}
    ${dirty && html`<div class="savebar"><span class="dirty-dot"></span>Unsaved changes<span class="spacer"></span><button class="btn primary" onClick=${save}>Save settings</button></div>`}
  </div>`;
}

const ROLES = [['admin', 'Admin – everything, incl. users & settings'], ['manager', 'Manager – events, recipes, prices'], ['chef', 'Chef – recipes and event menus'],
  ['sales', 'Sales – events, quotations'], ['purchasing', 'Purchasing – ingredient prices & suppliers'], ['viewer', 'Viewer – read only']];

function Users() {
  const { data, error, loading, reload } = useFetch('/users');
  const [edit, setEdit] = useState(null);
  if (loading && !data) return html`<${Loading} />`;
  if (error) return html`<${ErrorBox} error=${error} retry=${reload} />`;
  const save = async () => {
    try {
      if (edit.id) await api('/users/' + edit.id, { method: 'PUT', body: edit }); else await api('/users', { method: 'POST', body: edit });
      setEdit(null); reload(); toast('User saved');
    } catch (e) { toastErr(e); }
  };
  const set = (k) => (e) => setEdit({ ...edit, [k]: e.target.type === 'checkbox' ? (e.target.checked ? 1 : 0) : e.target.value });
  return html`<div class="stack">
    <div class="row"><span class="spacer"></span><button class="btn primary" onClick=${() => setEdit({ name: '', email: '', role: 'chef', password: '', active: 1 })}>+ Add user</button></div>
    <div class="tw"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Added</th><th></th></tr></thead><tbody>
      ${data.map((u) => html`<tr><td><b>${u.name}</b></td><td>${u.email}</td><td>${u.role}</td><td>${u.active ? html`<${Chip} c="good">Active<//>` : html`<${Chip} c="bad">Disabled<//>`}</td>
        <td class="small">${fmtDate(u.created_at)}</td><td class="r"><button class="btn ghost sm" onClick=${() => setEdit({ ...u, password: '' })}>Edit</button></td></tr>`)}
    </tbody></table></div>
    ${edit && html`<${Modal} title=${edit.id ? 'Edit user' : 'Add user'} onClose=${() => setEdit(null)} footer=${html`<button class="btn" onClick=${() => setEdit(null)}>Cancel</button><button class="btn primary" onClick=${save}>Save</button>`}>
      <div class="fields">
        <${Field} label="Name" cls="span2"><input class="in" value=${edit.name} onInput=${set('name')} /><//>
        <${Field} label="Email" cls="span2"><input class="in" type="email" value=${edit.email} disabled=${!!edit.id} onInput=${set('email')} /><//>
        <${Field} label="Role" cls="full"><select class="in" value=${edit.role} onChange=${set('role')}>${ROLES.map(([k, l]) => html`<option value=${k}>${l}</option>`)}</select><//>
        <${Field} label=${edit.id ? 'New password (leave blank to keep)' : 'Password (min. 8 characters)'} cls="span2"><input class="in" type="text" autocomplete="new-password" value=${edit.password} onInput=${set('password')} /><//>
        ${edit.id && html`<label class="check"><input type="checkbox" checked=${!!edit.active} onChange=${set('active')} /> Active</label>`}
      </div><p class="note">Share the password with the person directly; they can change it under My account.</p><//>`}
  </div>`;
}

function Activity() {
  const { data, error, loading } = useFetch('/audit');
  if (loading && !data) return html`<${Loading} />`;
  if (error) return html`<${ErrorBox} error=${error} />`;
  return html`<div class="tw"><table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>What</th><th>Detail</th></tr></thead><tbody>
    ${data.map((a) => html`<tr><td class="small" style="white-space:nowrap">${a.at}</td><td>${a.user_name || ''}</td><td>${a.action}</td><td>${a.entity}${a.entity_id ? ' #' + a.entity_id : ''}</td><td class="small muted">${a.detail || ''}</td></tr>`)}
  </tbody></table></div>`;
}

function Account() {
  const [cur, setCur] = useState('');
  const [next, setNext] = useState('');
  const change = async (e) => {
    e.preventDefault();
    try { await api('/auth/password', { method: 'POST', body: { current: cur, next } }); toast('Password changed'); setCur(''); setNext(''); } catch (x) { toastErr(x); }
  };
  return html`<form class="panel" style="max-width:420px" onSubmit=${change}><h3>Change password</h3>
    <div class="stack" style="gap:12px;margin-top:10px">
      <p class="note" style="margin:0">Signed in as <b>${store.user.email}</b> (${store.user.role}).</p>
      <${Field} label="Current password"><input class="in" type="password" autocomplete="current-password" value=${cur} onInput=${(e) => setCur(e.target.value)} required /><//>
      <${Field} label="New password (min. 8 characters)"><input class="in" type="password" autocomplete="new-password" value=${next} onInput=${(e) => setNext(e.target.value)} required minlength="8" /><//>
      <button class="btn primary" style="align-self:flex-start">Change password</button></div></form>`;
}
