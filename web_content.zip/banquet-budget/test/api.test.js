import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bb-test-'));
process.env.DATA_DIR = dir;
process.env.ADMIN_EMAIL = 'admin@test.local';
process.env.ADMIN_PASSWORD = 'password123';
let server, base, cookie = '';
const H = { 'X-Requested-With': 'banquet-budget', 'Content-Type': 'application/json' };
async function call(method, p, body) {
  const r = await fetch(base + p, { method, headers: { ...H, Cookie: cookie }, body: body ? JSON.stringify(body) : undefined });
  const sc = r.headers.get('set-cookie'); if (sc) cookie = sc.split(';')[0];
  return { status: r.status, body: r.headers.get('content-type')?.includes('json') ? await r.json() : await r.arrayBuffer() };
}
before(async () => {
  const { app } = await import('../src/server.js');
  const { ensureAdmin, seedData } = await import('../src/seed.js');
  ensureAdmin(); seedData();
  await new Promise((res) => { server = app.listen(0, res); });
  base = `http://127.0.0.1:${server.address().port}/api`;
});
after(() => { server.close(); fs.rmSync(dir, { recursive: true, force: true }); });

test('auth is required and login works', async () => {
  assert.equal((await call('GET', '/events')).status, 401);
  assert.equal((await call('POST', '/auth/login', { email: 'admin@test.local', password: 'nope' })).status, 401);
  assert.equal((await call('POST', '/auth/login', { email: 'admin@test.local', password: 'password123' })).status, 200);
});
test('mutations need the custom header', async () => {
  const r = await fetch(base + '/events', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie }, body: '{"name":"x"}' });
  assert.equal(r.status, 403);
});
test('seeded wedding costs and exports', async () => {
  const ev = (await call('GET', '/events/1')).body;
  assert.equal(ev.meals.length, 9);
  assert.equal(ev.summary.labour, 24400);
  assert.ok(ev.summary.costPct > 15 && ev.summary.costPct < 40, 'cost % plausible: ' + ev.summary.costPct);
  const x = await call('GET', '/events/1/export.xlsx');
  assert.equal(x.status, 200);
  assert.ok(x.body.byteLength > 10000);
});
test('event → meal → items → quotation flow', async () => {
  const e = (await call('POST', '/events', { name: 'Test Gala', start_date: '2026-12-01' })).body;
  const m = (await call('POST', `/events/${e.id}/meals`, { name: 'Dinner', kind: 'dinner', date: '2026-12-01', pax: 50, price_per_pax: 1500 })).body;
  const cat = (await call('GET', '/catalog')).body;
  const r = cat.recipes.find((x) => x.name === 'Dal Makhani');
  assert.equal((await call('PUT', '/meals/' + m.id, { name: 'Dinner', kind: 'dinner', date: '2026-12-01', pax: 50, price_per_pax: 1500, items: [{ section: 'Veg Mains', name: 'Dal Makhani', recipe_id: r.id, factor: 60 }], version: 1 })).status, 200);
  assert.equal((await call('PUT', '/meals/' + m.id, { name: 'Dinner', pax: 50, items: [], version: 1 })).status, 409, 'stale version rejected');
  const ev = (await call('GET', '/events/' + e.id)).body;
  assert.ok(Math.abs(ev.summary.food - r.per_portion * 50 * 0.6 * 1.05) < 0.01);
  const q = (await call('POST', `/events/${e.id}/quotations`, {})).body;
  assert.match(q.number, /^Q\d{4}-\d{4}$/);
  const qd = (await call('GET', '/quotations/' + q.id)).body;
  assert.equal(qd.data.subtotal, 75000);
});
test('price change updates history and recipe costs', async () => {
  const before = (await call('GET', '/catalog')).body.recipes.find((x) => x.name === 'Paneer Makhani').per_portion;
  const paneer = (await call('GET', '/catalog')).body.ingredients.find((i) => i.code === 'DAI-036');
  await call('PUT', '/ingredients/' + paneer.id, { price: 350, price_note: 'test' });
  const it = (await call('GET', '/ingredients/' + paneer.id)).body;
  assert.equal(it.price_status, 'updated');
  assert.equal(it.history[0].new_price, 350);
  const after = (await call('GET', '/catalog')).body.recipes.find((x) => x.name === 'Paneer Makhani').per_portion;
  assert.ok(after > before);
});
test('menu text parsing matches recipes', async () => {
  const text = '30 October 2026 - Lunch\nTHB 1,450 per pax + THB 200 soft drinks | 130 pax\nMAIN COURSE\n1  Dal Makhani [VEG]\n2  Butter Chicken [NON-VEG]\nRICE\n1  Basmati Steam Rice';
  const r = (await call('POST', '/menu/parse', { text, year: 2026 })).body;
  assert.equal(r.meals.length, 1);
  assert.equal(r.meals[0].price, 1450);
  assert.equal(r.meals[0].pax, 130);
  assert.equal(r.meals[0].items.length, 3);
  assert.ok(r.meals[0].items[0].recipe_id);
  assert.equal(r.meals[0].items[1].section, 'Non-Veg Mains');
});
test('sub-recipe loops are refused', async () => {
  const a = (await call('POST', '/recipes', { name: 'Base A', is_sub: 1, yield_qty: 1, yield_unit: 'kg', lines: [] })).body;
  const b = (await call('POST', '/recipes', { name: 'Base B', is_sub: 1, yield_qty: 1, yield_unit: 'kg', lines: [{ sub_recipe_id: a.id, qty: 1, unit: 'kg' }] })).body;
  const r = await call('PUT', '/recipes/' + a.id, { name: 'Base A', is_sub: 1, yield_qty: 1, yield_unit: 'kg', lines: [{ sub_recipe_id: b.id, qty: 1, unit: 'kg' }] });
  assert.equal(r.status, 400);
});
test('viewer role cannot edit', async () => {
  await call('POST', '/users', { email: 'v@test.local', name: 'V', role: 'viewer', password: 'password123' });
  await call('POST', '/auth/logout', {});
  cookie = '';
  await call('POST', '/auth/login', { email: 'v@test.local', password: 'password123' });
  assert.equal((await call('POST', '/events', { name: 'Nope' })).status, 403);
  assert.equal((await call('GET', '/events')).status, 200);
});
