import { test } from 'node:test';
import assert from 'node:assert/strict';
import { toBase, makeCtx, recipeCost, itemCost, mealSummary, eventSummary, purchaseList, netRevenue } from '../public/js/costing.js';

const ings = [
  { id: 1, code: 'MEAT-006', name: 'Chicken Thighs', unit: 'Kg', price: 65, price_status: 'list' },
  { id: 2, code: 'DAI-006', name: 'Butter', unit: 'Kg', price: 300, price_status: 'direct' },
  { id: 3, code: 'DAI-018', name: 'Egg', unit: 'No', price: 6, price_status: 'list' },
  { id: 4, code: 'SPC-082', name: 'Chilli powder', unit: 'Gms', price: 0.5, price_status: 'estimate' },
  { id: 5, code: 'X', name: 'Unpriced', unit: 'Kg', price: null, price_status: 'none' },
];
const gravy = { id: 10, name: 'Gravy', is_sub: 1, yield_qty: 2, yield_unit: 'kg', yield_pax: 1, lines: [{ ingredient_id: 2, qty: 1, unit: 'kg' }] }; // 300 for 2 kg = 150/kg
const curry = { id: 11, name: 'Curry', yield_pax: 10, lines: [
  { ingredient_id: 1, qty: 1500, unit: 'g' },   // 97.5
  { sub_recipe_id: 10, qty: 500, unit: 'g' },   // 75
  { ingredient_id: 3, qty: 2, unit: 'No' },     // 12
  { ingredient_id: 4, qty: 20, unit: 'g' },     // 10
  { custom_name: 'Sea bass', qty: 200, unit: 'g', rate_override: 400 }, // 80
] };

test('unit conversion', () => {
  assert.equal(toBase(1500, 'g', 'Kg'), 1.5);
  assert.equal(toBase(2, 'kg', 'Gms'), 2000);
  assert.equal(toBase(250, 'ml', 'Lit'), 0.25);
  assert.equal(toBase(3, 'No', 'No'), 3);
  assert.equal(toBase(3, 'g', 'Lit'), null);
});

test('recipe cost with sub-recipe, count and custom lines', () => {
  const ctx = makeCtx(ings, [gravy, curry]);
  const c = recipeCost(curry, ctx);
  assert.equal(Math.round(c.total * 100) / 100, 274.5);
  assert.equal(Math.round(c.perPortion * 100) / 100, 27.45);
  assert.equal(c.issues.estimate, 1);
  assert.equal(recipeCost(gravy, ctx).perBase, 150);
});

test('sub-recipe cycles do not hang', () => {
  const a = { id: 1, yield_pax: 1, is_sub: 1, yield_qty: 1, yield_unit: 'kg', lines: [{ sub_recipe_id: 2, qty: 1, unit: 'kg' }] };
  const b = { id: 2, yield_pax: 1, is_sub: 1, yield_qty: 1, yield_unit: 'kg', lines: [{ sub_recipe_id: 1, qty: 1, unit: 'kg' }] };
  const ctx = makeCtx([], [a, b]);
  assert.equal(recipeCost(a, ctx).total, 0);
});

test('meal and event summary', () => {
  const ctx = makeCtx(ings, [gravy, curry]);
  const per = (id) => recipeCost(ctx.rec.get(id), ctx).perPortion;
  const meal = { id: 1, pax: 100, price_per_pax: 1000, bev_price_per_pax: 200, chargeable: 1, items: [{ recipe_id: 11, factor: 50, section: 'Mains' }] };
  const ev = { price_basis: 'plus_plus', wastage_pct: 10, meals: [meal], labour: [{ meal_id: 1, headcount: 5, rate: 400 }], costs: [{ qty: 2, rate: 500 }], revenue_items: [{ qty: 1, unit_price: 5000 }] };
  const st = { service_pct: 10, vat_pct: 7 };
  assert.equal(Math.round(itemCost(meal.items[0], meal, per).total * 100) / 100, 1372.5);
  const ms = mealSummary(meal, ev, st, per, { labour: 2000, costs: 0 });
  assert.equal(Math.round(ms.foodCost * 100) / 100, 1509.75);
  assert.equal(ms.revenue, 120000);
  const es = eventSummary(ev, st, per);
  assert.equal(es.labour, 2000);
  assert.equal(es.costs, 1000);
  assert.equal(es.revenue, 125000);
  assert.equal(Math.round(es.clientTotal), Math.round(125000 * 1.1 * 1.07));
  assert.equal(Math.round(netRevenue(1177, { price_basis: 'net' }, st)), 1000);
});

test('purchase list scales by pax, uptake and wastage and expands sub-recipes', () => {
  const ctx = makeCtx(ings, [gravy, curry]);
  const ev = { wastage_pct: 0, meals: [{ id: 1, pax: 20, date: '2026-10-30', items: [{ recipe_id: 11, factor: 100, name: 'Curry' }] }] };
  const rows = purchaseList(ev, ctx);
  const chicken = rows.find((r) => r.code === 'MEAT-006');
  const butter = rows.find((r) => r.code === 'DAI-006');
  assert.equal(chicken.qty, 3);          // 1.5 kg × 2 batches
  assert.equal(butter.qty, 0.5);         // 0.5 kg gravy × 2 batches = 1 kg gravy → 0.5 kg butter
  assert.ok(rows.find((r) => r.name === 'Sea bass'));
});
