# Palayana Banquet Budget

Web software for costing banquets and events at The Palayana Hua Hin. It holds the ingredient price list and a recipe library, turns a menu into a costed event budget, adds casual labour and other costs, and produces quotations, purchase lists and Excel reports.

It runs on one small server (or a PC on the hotel network). Staff use it in a browser; there is nothing to install on their computers.

## What it does

| Area | What you can do |
|---|---|
| **Ingredients & prices** | 789 ingredients from the Aviyana price list, with kitchen/Thai spellings. Edit prices (every change kept in a price history with who and why), flag prices as *to confirm / estimate / direct*, link suppliers, import updated prices from Excel, export the list. |
| **Recipe library** | Standard recipes with batch yield, ingredient quantities in g/kg/ml/L/pcs, live cost per portion, sub-recipes (gravies, chutneys, doughs) usable as ingredients, method notes, draft/standard status, "used in" list. 184 recipes are pre-loaded from the Natasha & Mandeep costing. |
| **Events & meals** | An event has several meals (breakfast, lunch, dinner, stations…), each with pax, food price, beverage package, venue and its menu. Dishes are picked from the recipe library; **uptake %** sets how many guests take a full portion at a large buffet. Wastage % per event or meal. |
| **Menu → budget** | Upload the client's menu PDF (or paste text). Meals, prices, pax, sections and dishes are read out and matched to recipes; unmatched dishes can become draft recipes for the chef. |
| **Casual labour & other costs** | Enter rows the way they appear on the Casual Labour Requisition Form (department, position, date, people, shift, rate) and charge them to a meal. Other costs (décor, rentals, transport, gas…) and extra charges to the client. |
| **Reports** | Event P&L (revenue ex service & VAT, food, labour, other, GP, cost %) per meal and in total; purchase list by category, supplier or date (sub-recipes broken down); Excel export of the full budget; recipe cost cards. |
| **Quotations** | Numbered quotations (Q2026-0001…) with meals, service charge and VAT (or net pricing), menus and terms. Opens as a printable page — print or save as PDF. Status: draft / sent / accepted / declined. |
| **Users & roles** | Admin, Manager, Chef, Sales, Purchasing, Viewer. Activity log of who changed what. Two people editing the same recipe or meal can't overwrite each other silently. |

## Quick start (any computer with Node.js 22.5 or newer)

```bash
npm install
ADMIN_EMAIL=karan@aviyanahuahin.com ADMIN_NAME=Karan npm start
```

Open http://localhost:3000. On the very first start the app:

1. creates the admin account and prints its password (also saved in `data/initial-admin.txt` — delete that file after you sign in and change the password under **My account**);
2. loads the price list, the recipe library and the Natasha & Mandeep wedding.

Set `ADMIN_PASSWORD` to choose the first password yourself. Set `SEED_EVENT=0` to skip the sample wedding, or `SEED=0` to start completely empty.

## Running it on the hotel server (Docker)

```bash
docker compose up -d --build
docker compose logs banquet-budget     # shows the first admin password
```

Data lives in the `banquet-data` volume (`/data/banquet.db`). Put it behind the hotel's HTTPS reverse proxy (nginx, Caddy, IIS…) and set `TRUST_PROXY=1`.

## Settings (environment variables)

| Variable | Default | Meaning |
|---|---|---|
| `PORT` | 3000 | Web port |
| `HOST` | 0.0.0.0 | Listen address |
| `DATA_DIR` | `./data` | Where the database is stored |
| `ADMIN_EMAIL`, `ADMIN_NAME`, `ADMIN_PASSWORD` | – | First admin account (only used when there are no users) |
| `SEED`, `SEED_EVENT` | 1 | Load sample data on first start |
| `TRUST_PROXY` | 0 | Set to 1 behind an HTTPS proxy |

Hotel name, address, tax ID, service charge %, VAT %, default target cost %, wastage %, quotation terms, menu sections and default uptake % are edited in the app under **Settings**.

## Backups

```bash
npm run backup        # writes data/backups/banquet-YYYYMMDD-HHMM.db
```

Schedule it daily (cron / Task Scheduler) and copy the `backups` folder off the server. To restore, stop the app and replace `data/banquet.db` with a backup file.

## How the numbers are worked out

- **Recipe cost** = Σ ingredient quantity (converted to the price-list unit) × price. Sub-recipes cost per kg / L / portion of their batch.
- **Dish cost in a meal** = recipe cost per portion × meal pax × uptake %.
- **Food cost** = Σ dishes × (1 + wastage %).
- **Revenue** = (food price + beverage package) × pax for charged meals, plus extra charges. For **++** pricing this is the revenue; for **net** pricing the service charge and VAT are taken out first.
- **Cost %** = (food + casual labour + other costs) ÷ revenue.
- **Client total** on the quotation adds service charge and VAT on ++ prices.

## Notes on the loaded data

- Prices come from *Aviyana_Ingredient_Price_List.xlsx*. 159 prices are marked **Estimate** (median fallback in the master list) and 86 are **To confirm**, including working prices Claude set where the list was clearly wrong (milk 215/L, coffee per gram, etc.) and 26 items added for the wedding (sea bass, turkey bacon, Edam…). Fix them under **Ingredients & prices → To confirm**.
- The 184 wedding recipes are Claude's estimates from the menu; the chef should check quantities and mark each one **Standard** once approved.

## Development

```bash
npm test              # costing engine + API tests
```

- `src/` — Express server, SQLite (built into Node, no native modules), menu reader, Excel import/export
- `public/js/costing.js` — the costing engine, shared by the server and the browser
- `public/js/pages/` — the screens (Preact + htm, no build step)
- `seed/` — price list, recipes and the sample wedding
