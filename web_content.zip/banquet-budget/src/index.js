import { app } from './server.js';
import { ensureAdmin, seedData } from './seed.js';

ensureAdmin();
if (process.env.SEED !== '0') {
  if (seedData({ withEvent: process.env.SEED_EVENT !== '0' })) console.log('Loaded price list, recipe library and the Natasha & Mandeep wedding.');
}

const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '0.0.0.0';
app.listen(port, host, () => console.log(`Banquet Budget running on http://${host === '0.0.0.0' ? 'localhost' : host}:${port}`));
