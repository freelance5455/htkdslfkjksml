import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { db, migrate, get, run, tx, saveSettings, DEFAULT_SETTINGS, DB_PATH } from './db.js';
import { hashPassword } from './auth.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const load = (f) => JSON.parse(fs.readFileSync(path.join(ROOT, 'seed', f), 'utf8'));

export function ensureAdmin() {
  if (get('SELECT 1 FROM users LIMIT 1')) return null;
  const email = process.env.ADMIN_EMAIL || 'admin@palayana.local';
  const password = process.env.ADMIN_PASSWORD || crypto.randomBytes(9).toString('base64url');
  run('INSERT INTO users (email, name, role, pass_hash) VALUES (?,?,?,?)', email, process.env.ADMIN_NAME || 'Administrator', 'admin', hashPassword(password));
  const msg = `\n  First admin account created\n    email:    ${email}\n    password: ${password}\n  Sign in and change the password under My account.\n`;
  console.log(msg);
  if (!process.env.ADMIN_PASSWORD) fs.writeFileSync(path.join(path.dirname(DB_PATH), 'initial-admin.txt'), msg);
  return { email, password };
}

export function seedData({ withEvent = true } = {}) {
  if (get('SELECT 1 FROM ingredients LIMIT 1')) return false;
  const ings = load('ingredients.json');
  const recipes = load('recipes.json');
  tx(() => {
    saveSettings(DEFAULT_SETTINGS);
    const insI = db.prepare('INSERT INTO ingredients (code, name, category, unit, price, price_status, aliases, note) VALUES (?,?,?,?,?,?,?,?)');
    const insH = db.prepare("INSERT INTO price_history (ingredient_id, old_price, new_price, note) VALUES (?,?,?,?)");
    const codeId = new Map();
    for (const i of ings) {
      const r = insI.run(i.code, i.name, i.category, i.unit, i.price, i.price_status, i.aliases || '', i.note || '');
      codeId.set(i.code, Number(r.lastInsertRowid));
      if (i.price != null) insH.run(r.lastInsertRowid, null, i.price, 'Imported from Aviyana price list');
    }
    const insR = db.prepare('INSERT INTO recipes (name, section, diet, yield_pax, is_sub, yield_qty, yield_unit, notes, status) VALUES (?,?,?,?,?,?,?,?,?)');
    const insL = db.prepare('INSERT INTO recipe_lines (recipe_id, position, ingredient_id, sub_recipe_id, qty, unit) VALUES (?,?,?,?,?,?)');
    const recId = new Map();
    for (const r of recipes) {
      const x = insR.run(r.name, r.section, r.diet, r.yield_pax, 0, null, null, r.notes || '', r.status || 'standard');
      const rid = Number(x.lastInsertRowid);
      recId.set(r.name, rid);
      r.lines.forEach((l, i) => insL.run(rid, i, codeId.get(l.code), null, l.qty, l.unit));
    }
    // Two example sub-recipes (bases) to show how they work
    const subs = [
      ['Makhani Gravy (base)', 5, 'kg', [['VEG-058', 4, 'kg'], ['DAI-006', 400, 'g'], ['DAI-013', 800, 'g'], ['NUT-003', 250, 'g'], ['HRB-024', 150, 'g'], ['HRB-029', 40, 'g'], ['SPC-035', 15, 'g'], ['SPC-031', 20, 'g'], ['DRY-069', 80, 'g'], ['SPC-051', 50, 'g']]],
      ['Green Chutney (base)', 1, 'kg', [['HRB-031', 400, 'g'], ['HRB-009', 400, 'g'], ['HRB-026', 60, 'g'], ['FRT-024', 6, 'No'], ['SPC-014', 15, 'g'], ['SPC-051', 15, 'g']]],
    ];
    for (const [name, yq, yu, lines] of subs) {
      const x = insR.run(name, 'Sub-recipes', 'veg', 1, 1, yq, yu, 'Base preparation – use it as an ingredient in other recipes.', 'standard');
      lines.forEach(([c, q, u], i) => insL.run(Number(x.lastInsertRowid), i, codeId.get(c), null, q, u));
    }
    if (withEvent) seedWedding(recId);
  });
  return true;
}

function seedWedding(recId) {
  const w = load('wedding.json');
  const e = run(`INSERT INTO events (name, client_name, venue, start_date, end_date, status, event_type, price_basis, target_pct, wastage_pct, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    w.name, w.client_name, w.venue, w.start_date, w.end_date, w.status, w.event_type, w.price_basis, w.target_pct, w.wastage_pct, w.notes);
  const eid = Number(e.lastInsertRowid);
  const mealId = new Map();
  w.meals.forEach((m, pos) => {
    const r = run(`INSERT INTO meals (event_id, position, name, kind, date, venue, pax, price_per_pax, bev_price_per_pax, chargeable, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      eid, pos, m.name, m.kind, m.date, m.venue, m.pax, m.price_per_pax, m.bev_price_per_pax, m.chargeable, m.notes);
    const mid = Number(r.lastInsertRowid);
    mealId.set(m.name + '|' + m.date, mid);
    const st = db.prepare('INSERT INTO meal_items (meal_id, position, section, name, recipe_id, factor) VALUES (?,?,?,?,?,?)');
    m.items.forEach((it, i) => st.run(mid, i, it.section, it.name, recId.get(it.recipe), it.factor));
  });
  w.labour.forEach((l, i) => run(`INSERT INTO labour (event_id, meal_id, position, department, role, date, headcount, time_from, time_to, hours, rate, form_ref) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    eid, mealId.get(l.meal[0] + '|' + l.meal[1]) ?? null, i, l.department, l.role, l.date, l.headcount, l.time_from, l.time_to, l.hours, l.rate, l.form_ref));
}

// CLI: node src/seed.js [--no-event]
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  migrate();
  ensureAdmin();
  const done = seedData({ withEvent: !process.argv.includes('--no-event') });
  console.log(done ? 'Seed data loaded.' : 'Database already has ingredients – seed skipped.');
}
