// Usage: npm run backup  → writes a consistent copy of the database to data/backups/
import fs from 'node:fs';
import path from 'node:path';
import { db, DB_PATH } from './db.js';

const dir = path.join(path.dirname(DB_PATH), 'backups');
fs.mkdirSync(dir, { recursive: true });
const stamp = new Date().toISOString().replace(/[-:]/g, '').replace('T', '-').slice(0, 13);
const file = path.join(dir, `banquet-${stamp}.db`);
db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
console.log('Backup written to', file);
