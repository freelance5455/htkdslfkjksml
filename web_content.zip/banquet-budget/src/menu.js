// Menu import: extract text from PDF, split into meals → sections → dishes, and match dishes to the recipe library.

export async function pdfToText(buf) {
  const pdfjs = await import('pdfjs-dist/legacy/build/pdf.mjs');
  const doc = await pdfjs.getDocument({ data: new Uint8Array(buf), useSystemFonts: true, isEvalSupported: false }).promise;
  const out = [];
  for (let p = 1; p <= doc.numPages; p++) {
    const page = await doc.getPage(p);
    const tc = await page.getTextContent();
    const rows = new Map();
    for (const it of tc.items) {
      if (!it.str || !it.str.trim()) continue;
      const y = Math.round(it.transform[5] / 3) * 3;
      const x = it.transform[4];
      if (!rows.has(y)) rows.set(y, []);
      rows.get(y).push({ x, s: it.str, w: it.width || 0 });
    }
    const ys = [...rows.keys()].sort((a, b) => b - a);
    for (const y of ys) {
      const parts = rows.get(y).sort((a, b) => a.x - b.x);
      let line = '';
      let lastEnd = null;
      for (const pt of parts) {
        if (lastEnd != null) line += pt.x - lastEnd > 18 ? '    ' : pt.x - lastEnd > 1.5 ? ' ' : '';
        line += pt.s;
        lastEnd = pt.x + pt.w;
      }
      out.push(line);
    }
    out.push('');
  }
  return out.join('\n');
}

const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
const MEAL_WORDS = /\b(breakfast|brunch|lunch|dinner|hi-?tea|high tea|cocktails?|gala dinner|supper|sangeet|mehendi|haldi)\b/i;

function findDate(s, fallbackYear) {
  let m = s.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s*(\d{4})?/i);
  if (m) return iso(+m[3] || fallbackYear, MONTHS[m[2].toLowerCase()], +m[1]);
  m = s.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s*(\d{4})?/i);
  if (m) return iso(+m[3] || fallbackYear, MONTHS[m[1].toLowerCase()], +m[2]);
  m = s.match(/\b(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})\b/);
  if (m) {
    let y = +m[3];
    if (y < 100) y += 2000;
    if (y > 2400) y -= 543; // Thai Buddhist year
    return iso(y, +m[2], +m[1]);
  }
  return null;
}
const iso = (y, mo, d) => (y && mo && d ? `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}` : null);

const SECTION_RULES = [
  [/salad bar/i, 'Salads'],
  [/live.*dessert|dessert.*live/i, 'Dessert Live Stn'],
  [/live|station/i, 'LIVE'],
  [/starter|appeti[sz]er|canap|snack/i, 'STARTER'],
  [/soup/i, 'Soups'],
  [/salad/i, 'Salads'],
  [/main/i, 'MAIN'],
  [/bread|roti|naan/i, 'Breads'],
  [/rice|biryani|pulao/i, 'Rice'],
  [/dessert|sweet/i, 'Desserts'],
  [/fruit/i, 'Desserts'],
  [/bbq|barbecue|grill/i, 'BBQ'],
  [/hot dish|breakfast|egg|griddle/i, 'Breakfast'],
  [/drink|beverage|mocktail|juice/i, 'Beverages'],
];

function sectionFor(header) {
  for (const [re, s] of SECTION_RULES) if (re.test(header)) return s;
  return 'Other';
}

function resolveSection(generic, diet) {
  const nv = diet === 'nonveg' || diet === 'both';
  if (generic === 'LIVE') return nv ? 'Non-Veg Live Stn' : 'Veg Live Stn';
  if (generic === 'STARTER') return nv ? 'Non-Veg Starters' : 'Veg Starters';
  if (generic === 'MAIN') return nv ? 'Non-Veg Mains' : 'Veg Mains';
  return generic;
}

function isHeader(line) {
  const t = line.trim();
  if (t.length < 3 || t.length > 45 || /^\d/.test(t)) return false;
  const letters = t.replace(/[^A-Za-z]/g, '');
  if (letters.length < 3) return false;
  const upper = letters.replace(/[^A-Z]/g, '').length / letters.length;
  return upper > 0.85 && !/^NOTE/i.test(t);
}

/** Parse menu text into {meals:[{name,date,kind,price,bev,pax,venue,items:[{section,name,diet,note}]}]} */
export function parseMenu(text, { year } = {}) {
  const yr = year || new Date().getFullYear();
  const lines = String(text).replace(/\r/g, '').split('\n').map((l) => l.replace(/\s+$/, ''));
  const meals = [];
  let meal = null, section = null, last = null;
  const newMeal = (name, date) => {
    meal = { name, date, kind: (name.match(MEAL_WORDS)?.[1] || 'other').toLowerCase().replace(/s$/, ''), price: null, bev: null, pax: null, venue: '', notes: [], items: [] };
    meals.push(meal);
    section = null;
  };
  for (let raw of lines) {
    const line = raw.trim();
    if (!line || /\|\s*Menu\s*\|\s*Page/i.test(line) || /^page \d+/i.test(line)) continue;
    const date = findDate(line, yr);
    // Meal header: has date + meal word, short line, not a numbered item
    if (MEAL_WORDS.test(line) && line.length < 90 && !/^\d{1,2}[.)]\s|^\d{1,2}\s{2,}/.test(line) && !/rate per pax|restriction|^note/i.test(line) &&
        (date || (/\bmenu\b/i.test(line) && line.length < 40))) {
      const m = line.match(MEAL_WORDS);
      const extra = line.replace(/^.*?(breakfast|brunch|lunch|dinner|hi-?tea|high tea|cocktails?|gala dinner|supper)/i, '').replace(/^[\s/–-]+/, '').trim();
      const label = m[1].replace(/^\w/, (c) => c.toUpperCase()) + (extra && extra.length < 40 ? ' ' + extra : '');
      newMeal(label.trim(), date);
      continue;
    }
    if (!meal) continue;
    // Price / pax line
    if (/THB|฿|per pax|pax\b/i.test(line) && !/^\d+[.)]?\s{2,}/.test(line) && meal.items.length === 0) {
      const prices = [...line.matchAll(/(?:THB|฿)\s*([\d,]+(?:\.\d+)?)/gi)].map((x) => +x[1].replace(/,/g, ''));
      if (prices[0] != null && meal.price == null) meal.price = prices[0];
      if (/soft drink|beverage/i.test(line) && prices[1] != null) meal.bev = prices[1];
      const px = line.match(/(\d{1,5})\s*pax/i);
      if (px) meal.pax = +px[1];
      const v = line.match(/venue:\s*([^|]+)/i);
      if (v) meal.venue = v[1].trim();
      continue;
    }
    if (isHeader(line)) {
      if (/ALL VEG/i.test(line)) { meal.allVeg = true; continue; }
      section = sectionFor(line);
      last = null;
      continue;
    }
    if (/^note:/i.test(line)) {
      if (last) last.note = (last.note ? last.note + ' ' : '') + line.replace(/^note:\s*/i, '');
      else meal.notes.push(line);
      continue;
    }
    const m = line.match(/^(?:\d{1,2}[.)]?|[-•*])\s+(.+)$/);
    if (m && section) {
      let name = m[1].trim();
      let diet = null;
      const d = name.match(/\[(VEG\/NON-VEG|NON-VEG|VEG)\]/i);
      if (d) {
        diet = /\//.test(d[1]) ? 'both' : /NON/i.test(d[1]) ? 'nonveg' : 'veg';
        name = name.replace(d[0], '').trim();
      }
      if (meal.allVeg && !diet) diet = 'veg';
      last = { section: section, name: name.replace(/\s{2,}/g, ' '), diet, note: '' };
      meal.items.push(last);
    } else if (last && section && /^[a-z(]/.test(line) && line.length < 120) {
      last.name += ' ' + line; // wrapped continuation
    }
  }
  for (const ml of meals) for (const it of ml.items) it.generic = it.section;
  return { meals: meals.filter((m) => m.items.length) };
}

const STOP = new Set(['with', 'and', 'the', 'in', 'on', 'of', 'a', 'an', 'served', 'style', 'topped', 'station', 'sauce', 'classic', 'mini', 'fresh', 'assorted', 'veg', 'non']);
export function tokens(s) {
  return String(s).toLowerCase().replace(/\[[^\]]*\]/g, ' ').replace(/\([^)]*\)/g, ' ').replace(/[^a-z0-9 ]+/g, ' ')
    .split(/\s+/).filter((t) => t.length > 1 && !STOP.has(t)).map((t) => t.replace(/(es|s)$/, ''));
}

function score(a, b) {
  const A = new Set(tokens(a)), B = new Set(tokens(b));
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const t of A) if (B.has(t)) inter++;
  const jac = inter / (A.size + B.size - inter);
  const cover = inter / Math.min(A.size, B.size);
  return Math.max(jac, cover * 0.85);
}

/** Suggest recipe matches for every parsed dish. */
export function matchRecipes(parsed, recipes) {
  const cands = recipes.filter((r) => r.active && !r.is_sub);
  for (const meal of parsed.meals) {
    for (const it of meal.items) {
      const scored = cands.map((r) => {
        let s = score(it.name, r.name);
        for (const a of String(r.aliases || '').split('|')) if (a.trim()) s = Math.max(s, score(it.name, a));
        if (String(r.name).toLowerCase() === it.name.toLowerCase()) s = 1;
        return { id: r.id, name: r.name, section: r.section, score: Math.round(s * 100) / 100 };
      }).filter((x) => x.score >= 0.3).sort((a, b) => b.score - a.score).slice(0, 5);
      it.candidates = scored;
      it.recipe_id = scored[0] && scored[0].score >= 0.6 ? scored[0].id : null;
      const matched = it.recipe_id ? cands.find((r) => r.id === it.recipe_id) : null;
      if (!it.diet && matched) it.diet = matched.diet;
      it.section = ['LIVE', 'STARTER', 'MAIN'].includes(it.generic) ? (matched && !it.diet ? matched.section : resolveSection(it.generic, it.diet)) : it.generic;
    }
  }
  return parsed;
}
