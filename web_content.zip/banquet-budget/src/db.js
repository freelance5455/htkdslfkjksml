import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = process.env.DATA_DIR || path.resolve('data');
fs.mkdirSync(DATA_DIR, { recursive: true });
export const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'banquet.db');

export const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');

const MIGRATIONS = [
  `
  CREATE TABLE users (
    id INTEGER PRIMARY KEY, email TEXT UNIQUE NOT NULL COLLATE NOCASE, name TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin','manager','chef','sales','purchasing','viewer')),
    pass_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE sessions (token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at TEXT NOT NULL);
  CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE suppliers (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, contact TEXT, phone TEXT, email TEXT, notes TEXT, active INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE ingredients (
    id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'Other',
    unit TEXT NOT NULL, price REAL, price_status TEXT NOT NULL DEFAULT 'list',
    supplier_id INTEGER REFERENCES suppliers(id) ON DELETE SET NULL, aliases TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
    active INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE price_history (
    id INTEGER PRIMARY KEY, ingredient_id INTEGER NOT NULL REFERENCES ingredients(id) ON DELETE CASCADE,
    old_price REAL, new_price REAL, note TEXT, user_id INTEGER REFERENCES users(id), at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE recipes (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, section TEXT NOT NULL DEFAULT 'Other', diet TEXT NOT NULL DEFAULT 'veg',
    yield_pax REAL NOT NULL DEFAULT 10, is_sub INTEGER NOT NULL DEFAULT 0, yield_qty REAL, yield_unit TEXT,
    aliases TEXT NOT NULL DEFAULT '', method TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'draft', active INTEGER NOT NULL DEFAULT 1, version INTEGER NOT NULL DEFAULT 1,
    created_by INTEGER REFERENCES users(id), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE recipe_lines (
    id INTEGER PRIMARY KEY, recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE, position INTEGER NOT NULL,
    ingredient_id INTEGER REFERENCES ingredients(id), sub_recipe_id INTEGER REFERENCES recipes(id),
    custom_name TEXT, qty REAL NOT NULL DEFAULT 0, unit TEXT NOT NULL, rate_override REAL, note TEXT
  );
  CREATE INDEX idx_rl_recipe ON recipe_lines(recipe_id);
  CREATE TABLE events (
    id INTEGER PRIMARY KEY, name TEXT NOT NULL, client_name TEXT NOT NULL DEFAULT '', client_contact TEXT NOT NULL DEFAULT '',
    client_email TEXT NOT NULL DEFAULT '', client_phone TEXT NOT NULL DEFAULT '', venue TEXT NOT NULL DEFAULT '',
    start_date TEXT, end_date TEXT, status TEXT NOT NULL DEFAULT 'enquiry', event_type TEXT NOT NULL DEFAULT 'Wedding',
    price_basis TEXT NOT NULL DEFAULT 'plus_plus', target_pct REAL NOT NULL DEFAULT 30, wastage_pct REAL NOT NULL DEFAULT 5,
    notes TEXT NOT NULL DEFAULT '', version INTEGER NOT NULL DEFAULT 1, created_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE meals (
    id INTEGER PRIMARY KEY, event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE, position INTEGER NOT NULL DEFAULT 0,
    name TEXT NOT NULL, kind TEXT NOT NULL DEFAULT 'lunch', date TEXT, time TEXT NOT NULL DEFAULT '', venue TEXT NOT NULL DEFAULT '',
    pax REAL NOT NULL DEFAULT 0, price_per_pax REAL NOT NULL DEFAULT 0, bev_price_per_pax REAL NOT NULL DEFAULT 0,
    chargeable INTEGER NOT NULL DEFAULT 1, wastage_pct REAL, notes TEXT NOT NULL DEFAULT '', version INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE meal_items (
    id INTEGER PRIMARY KEY, meal_id INTEGER NOT NULL REFERENCES meals(id) ON DELETE CASCADE, position INTEGER NOT NULL,
    section TEXT NOT NULL DEFAULT 'Other', name TEXT NOT NULL, diet TEXT, recipe_id INTEGER REFERENCES recipes(id),
    factor REAL NOT NULL DEFAULT 100, portions REAL, cost_per_portion REAL, note TEXT NOT NULL DEFAULT ''
  );
  CREATE INDEX idx_mi_meal ON meal_items(meal_id);
  CREATE TABLE labour (
    id INTEGER PRIMARY KEY, event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE, meal_id INTEGER REFERENCES meals(id) ON DELETE SET NULL,
    position INTEGER NOT NULL DEFAULT 0, department TEXT NOT NULL DEFAULT 'Kitchen', role TEXT NOT NULL DEFAULT '', date TEXT,
    headcount REAL NOT NULL DEFAULT 1, time_from TEXT NOT NULL DEFAULT '', time_to TEXT NOT NULL DEFAULT '', hours REAL,
    rate REAL NOT NULL DEFAULT 0, form_ref TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE costs (
    id INTEGER PRIMARY KEY, event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE, meal_id INTEGER REFERENCES meals(id) ON DELETE SET NULL,
    position INTEGER NOT NULL DEFAULT 0, category TEXT NOT NULL DEFAULT 'Other', description TEXT NOT NULL DEFAULT '',
    qty REAL NOT NULL DEFAULT 1, unit TEXT NOT NULL DEFAULT 'lot', rate REAL NOT NULL DEFAULT 0, supplier TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE revenue_items (
    id INTEGER PRIMARY KEY, event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE, position INTEGER NOT NULL DEFAULT 0,
    description TEXT NOT NULL DEFAULT '', qty REAL NOT NULL DEFAULT 1, unit TEXT NOT NULL DEFAULT 'lot', unit_price REAL NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT ''
  );
  CREATE TABLE quotations (
    id INTEGER PRIMARY KEY, event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE, number TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft', valid_until TEXT, data TEXT NOT NULL, created_by INTEGER REFERENCES users(id),
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  CREATE TABLE audit (
    id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT NOT NULL, entity TEXT NOT NULL, entity_id INTEGER, detail TEXT,
    at TEXT NOT NULL DEFAULT (datetime('now'))
  );
  `,
];

export function migrate() {
  db.exec('CREATE TABLE IF NOT EXISTS schema_version (v INTEGER NOT NULL)');
  const row = db.prepare('SELECT v FROM schema_version').get();
  let v = row ? row.v : 0;
  if (!row) db.prepare('INSERT INTO schema_version (v) VALUES (0)').run();
  while (v < MIGRATIONS.length) {
    tx(() => {
      db.exec(MIGRATIONS[v]);
      db.prepare('UPDATE schema_version SET v = ?').run(v + 1);
    });
    v++;
  }
}

let depth = 0;
export function tx(fn) {
  const sp = `sp${depth}`;
  db.exec(depth === 0 ? 'BEGIN IMMEDIATE' : `SAVEPOINT ${sp}`);
  depth++;
  try {
    const r = fn();
    depth--;
    db.exec(depth === 0 ? 'COMMIT' : `RELEASE ${sp}`);
    return r;
  } catch (e) {
    depth--;
    db.exec(depth === 0 ? 'ROLLBACK' : `ROLLBACK TO ${sp}; RELEASE ${sp}`);
    throw e;
  }
}

export const all = (sql, ...p) => db.prepare(sql).all(...p);
export const get = (sql, ...p) => db.prepare(sql).get(...p);
export const run = (sql, ...p) => db.prepare(sql).run(...p);

export const DEFAULT_SETTINGS = {
  hotel_name: 'The Palayana Hua Hin',
  hotel_address: 'Hua Hin, Prachuap Khiri Khan, Thailand',
  hotel_phone: '',
  hotel_email: '',
  hotel_tax_id: '',
  currency: 'THB',
  service_pct: 10,
  vat_pct: 7,
  target_pct: 30,
  wastage_pct: 5,
  quote_validity_days: 14,
  quote_terms:
    'Prices are per person unless stated. A 50% deposit confirms the booking; the balance is due 7 days before the event. Final guest numbers are required 72 hours before each meal and will be charged as the minimum. Menu items are subject to seasonal availability.',
  sections: [
    'Welcome Drinks', 'Salads', 'Veg Live Stn', 'Non-Veg Live Stn', 'BBQ', 'Veg Starters', 'Non-Veg Starters', 'Soups',
    'Veg Mains', 'Non-Veg Mains', 'Breads', 'Rice', 'Dessert Live Stn', 'Desserts', 'Breakfast', 'Beverages', 'Sub-recipes', 'Other',
  ],
  uptake_defaults: {
    Salads: 50, 'Veg Live Stn': 60, 'Non-Veg Live Stn': 60, BBQ: 60, 'Veg Starters': 50, 'Non-Veg Starters': 50, Soups: 70,
    'Veg Mains': 55, 'Non-Veg Mains': 55, Breads: 70, Rice: 75, 'Dessert Live Stn': 55, Desserts: 45, Breakfast: 55,
  },
  labour_departments: ['Kitchen', 'Bakery', 'Stewarding', 'F&B Service', 'Bar', 'Banquet Setup'],
  cost_categories: ['Décor & Flowers', 'Equipment Rental', 'Transport', 'Entertainment', 'Printing', 'Disposables', 'Gas & Fuel', 'Other'],
};

export function getSettings() {
  const rows = all('SELECT key, value FROM settings');
  const s = { ...DEFAULT_SETTINGS };
  for (const r of rows) {
    try { s[r.key] = JSON.parse(r.value); } catch { s[r.key] = r.value; }
  }
  return s;
}

export function saveSettings(obj) {
  const st = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  tx(() => {
    for (const [k, v] of Object.entries(obj)) if (k in DEFAULT_SETTINGS) st.run(k, JSON.stringify(v));
  });
}

export function audit(userId, action, entity, entityId, detail) {
  run('INSERT INTO audit (user_id, action, entity, entity_id, detail) VALUES (?,?,?,?,?)', userId ?? null, action, entity, entityId ?? null, detail ? String(detail).slice(0, 500) : null);
}
