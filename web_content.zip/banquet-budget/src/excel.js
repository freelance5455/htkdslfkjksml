import ExcelJS from 'exceljs';
import { all, get, run, tx, getSettings } from './db.js';
import { buildCtx, summarize, loadIngredients } from './data.js';
import { recipeCost, lineCost, purchaseList, itemCost, labourAmount, costAmount, STATUS } from '../public/js/costing.js';

const MONEY = '#,##0.00';
const HEAD = { font: { bold: true, color: { argb: 'FFFFFFFF' } }, fill: { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1D3F37' } } };

function sheet(wb, name, columns) {
  const ws = wb.addWorksheet(name.slice(0, 31), { views: [{ state: 'frozen', ySplit: 1 }] });
  ws.columns = columns.map((c) => ({ header: c.h, key: c.k, width: c.w || 14, style: c.money ? { numFmt: MONEY } : c.fmt ? { numFmt: c.fmt } : {} }));
  ws.getRow(1).eachCell((cell) => { cell.font = HEAD.font; cell.fill = HEAD.fill; });
  return ws;
}

export async function exportIngredients() {
  const wb = new ExcelJS.Workbook();
  const ws = sheet(wb, 'Price List', [
    { h: 'Item Code', k: 'code', w: 12 }, { h: 'Category', k: 'category', w: 28 }, { h: 'Ingredient', k: 'name', w: 32 }, { h: 'Unit', k: 'unit', w: 8 },
    { h: 'Price per Unit (THB)', k: 'price', w: 18, money: true }, { h: 'Price Status', k: 'status', w: 14 }, { h: 'Supplier', k: 'supplier', w: 20 },
    { h: 'Also Known As', k: 'aliases', w: 40 }, { h: 'Note', k: 'note', w: 40 }, { h: 'Updated', k: 'updated', w: 18 },
  ]);
  for (const i of loadIngredients(true)) ws.addRow({ code: i.code, category: i.category, name: i.name, unit: i.unit, price: i.price, status: STATUS[i.price_status]?.t || i.price_status,
    supplier: i.supplier_name || '', aliases: i.aliases, note: i.note, updated: i.updated_at });
  ws.autoFilter = { from: 'A1', to: 'J1' };
  return wb.xlsx.writeBuffer();
}

export async function exportRecipes() {
  const { ctx, recs } = buildCtx();
  const wb = new ExcelJS.Workbook();
  const ws = sheet(wb, 'Recipe Summary', [
    { h: 'Recipe', k: 'name', w: 44 }, { h: 'Section', k: 'section', w: 18 }, { h: 'Diet', k: 'diet', w: 8 }, { h: 'Yield (pax)', k: 'yield', w: 10 },
    { h: 'Batch cost', k: 'total', money: true }, { h: 'Cost / portion', k: 'pp', money: true }, { h: 'Lines', k: 'lines', w: 8 }, { h: 'Status', k: 'status', w: 10 },
  ]);
  const det = sheet(wb, 'Recipe Lines', [
    { h: 'Recipe', k: 'recipe', w: 40 }, { h: 'Item', k: 'item', w: 34 }, { h: 'Code', k: 'code', w: 10 }, { h: 'Qty', k: 'qty', w: 10 }, { h: 'Unit', k: 'unit', w: 8 },
    { h: 'Rate (per base)', k: 'rate', money: true }, { h: 'Base', k: 'base', w: 8 }, { h: 'Cost', k: 'cost', money: true }, { h: 'Price status', k: 'st', w: 14 },
  ]);
  for (const r of recs.filter((x) => x.active)) {
    const c = recipeCost(r, ctx);
    ws.addRow({ name: r.name, section: r.section, diet: r.diet, yield: r.yield_pax, total: c.total, pp: c.perPortion, lines: r.lines.length, status: r.status });
    for (const l of r.lines) {
      const lc = lineCost(l, ctx, new Set());
      const it = l.ingredient_id ? ctx.ing.get(l.ingredient_id) : null;
      const sub = l.sub_recipe_id ? ctx.rec.get(l.sub_recipe_id) : null;
      det.addRow({ recipe: r.name, item: it?.name || (sub ? 'Sub-recipe: ' + sub.name : l.custom_name), code: it?.code || '', qty: l.qty, unit: l.unit,
        rate: lc.price ?? null, base: lc.base, cost: lc.cost, st: STATUS[lc.status]?.t || lc.status });
    }
  }
  return wb.xlsx.writeBuffer();
}

function purchaseSheet(wb, rows, title = 'Purchase List') {
  const ws = sheet(wb, title, [
    { h: 'Category', k: 'category', w: 26 }, { h: 'Code', k: 'code', w: 10 }, { h: 'Ingredient', k: 'name', w: 32 }, { h: 'Total qty', k: 'qty', w: 12, fmt: '#,##0.000' },
    { h: 'Unit', k: 'base', w: 8 }, { h: 'Rate (THB)', k: 'price', money: true }, { h: 'Est. cost (THB)', k: 'cost', money: true }, { h: 'Price status', k: 'st', w: 14 },
    { h: 'Supplier', k: 'supplier', w: 18 }, { h: 'Needed for (dates)', k: 'dates', w: 22 }, { h: 'Used in', k: 'dishes', w: 60 },
  ]);
  let tot = 0;
  for (const r of rows) {
    tot += r.cost;
    ws.addRow({ ...r, st: STATUS[r.status]?.t || r.status, dates: r.dates.join(', '), dishes: r.dishes.join('; ') });
  }
  const t = ws.addRow({ name: 'TOTAL', cost: tot });
  t.font = { bold: true };
  ws.autoFilter = { from: 'A1', to: 'K1' };
  return ws;
}

export async function exportPurchase(ev, mealId) {
  const { ctx } = buildCtx();
  const wb = new ExcelJS.Workbook();
  purchaseSheet(wb, purchaseList(ev, ctx, { mealId }));
  return wb.xlsx.writeBuffer();
}

export async function exportEvent(ev) {
  const settings = getSettings();
  const bundle = buildCtx();
  const { ctx } = bundle;
  const s = summarize(ev, settings, bundle);
  const wb = new ExcelJS.Workbook();
  const sumWs = wb.addWorksheet('Summary');
  sumWs.columns = [{ width: 34 }, { width: 18 }, { width: 18 }, { width: 18 }, { width: 18 }, { width: 18 }, { width: 14 }, { width: 14 }];
  sumWs.addRow([ev.name]).font = { bold: true, size: 14 };
  sumWs.addRow([`${ev.client_name} · ${ev.venue} · ${ev.start_date || ''} – ${ev.end_date || ''}`]);
  sumWs.addRow([`Price basis: ${ev.price_basis === 'net' ? 'Net (incl. service & VAT)' : '++ (service ' + settings.service_pct + '% + VAT ' + settings.vat_pct + '% added)'}`]);
  sumWs.addRow([]);
  const h = sumWs.addRow(['Meal', 'Date', 'Pax', 'Revenue (ex tax)', 'Food cost', 'Labour', 'Other costs', 'Cost %']);
  h.eachCell((c) => { c.font = HEAD.font; c.fill = HEAD.fill; });
  for (const m of s.meals) {
    const r = sumWs.addRow([m.name, m.date, m.pax, m.revenue, m.foodCost, m.labour, m.costs, m.costPct == null ? null : m.costPct / 100]);
    [4, 5, 6, 7].forEach((i) => (r.getCell(i).numFmt = MONEY));
    r.getCell(8).numFmt = '0.0%';
  }
  if (s.labourEvent || s.costEvent || s.extraRevenue) {
    const r = sumWs.addRow(['Event-level items (not tied to a meal)', '', '', s.extraRevenue, 0, s.labourEvent, s.costEvent, null]);
    [4, 5, 6, 7].forEach((i) => (r.getCell(i).numFmt = MONEY));
  }
  const tr = sumWs.addRow(['TOTAL', '', '', s.revenue, s.food, s.labour, s.costs, s.costPct == null ? null : s.costPct / 100]);
  tr.font = { bold: true };
  [4, 5, 6, 7].forEach((i) => (tr.getCell(i).numFmt = MONEY));
  tr.getCell(8).numFmt = '0.0%';
  sumWs.addRow([]);
  for (const [k, v] of [['Total cost', s.totalCost], ['Revenue (ex service & VAT)', s.revenue], ['Gross profit', s.gp], ['Client total (incl. service & VAT)', s.clientTotal]]) {
    const r = sumWs.addRow([k, v]);
    r.getCell(2).numFmt = MONEY;
  }

  const mi = sheet(wb, 'Menu Costing', [
    { h: 'Date', k: 'date', w: 11 }, { h: 'Meal', k: 'meal', w: 26 }, { h: 'Section', k: 'section', w: 18 }, { h: 'Dish', k: 'dish', w: 46 },
    { h: 'Recipe', k: 'recipe', w: 36 }, { h: 'Cost / portion', k: 'pp', money: true }, { h: 'Uptake %', k: 'factor', w: 10 }, { h: 'Portions', k: 'portions', w: 10 },
    { h: 'Dish cost', k: 'total', money: true }, { h: 'Cost / pax', k: 'perPax', money: true },
  ]);
  const per = (rid) => (ctx.rec.get(rid) ? recipeCost(ctx.rec.get(rid), ctx).perPortion : 0);
  for (const m of ev.meals) for (const it of m.items) {
    const c = itemCost(it, m, per);
    mi.addRow({ date: m.date, meal: m.name, section: it.section, dish: it.name, recipe: it.recipe_id ? ctx.rec.get(it.recipe_id)?.name : '(no recipe)', pp: c.perPortion,
      factor: c.factor * 100, portions: c.portions, total: c.total, perPax: c.perPax });
  }
  purchaseSheet(wb, purchaseList(ev, ctx));
  const lw = sheet(wb, 'Casual Labour', [
    { h: 'Date', k: 'date', w: 11 }, { h: 'Department', k: 'department', w: 16 }, { h: 'Position', k: 'role', w: 16 }, { h: 'Headcount', k: 'headcount', w: 10 },
    { h: 'From', k: 'time_from', w: 8 }, { h: 'To', k: 'time_to', w: 8 }, { h: 'Hours', k: 'hours', w: 8 }, { h: 'Rate / day', k: 'rate', money: true },
    { h: 'Total', k: 'total', money: true }, { h: 'Charged to meal', k: 'meal', w: 24 }, { h: 'Form ref', k: 'form_ref', w: 14 },
  ]);
  const mealName = new Map(ev.meals.map((m) => [m.id, m.name]));
  for (const l of ev.labour) lw.addRow({ ...l, total: labourAmount(l), meal: mealName.get(l.meal_id) || 'Event' });
  const cw = sheet(wb, 'Other Costs', [
    { h: 'Category', k: 'category', w: 18 }, { h: 'Description', k: 'description', w: 36 }, { h: 'Qty', k: 'qty', w: 8 }, { h: 'Unit', k: 'unit', w: 8 },
    { h: 'Rate', k: 'rate', money: true }, { h: 'Total', k: 'total', money: true }, { h: 'Supplier', k: 'supplier', w: 18 }, { h: 'Charged to meal', k: 'meal', w: 24 },
  ]);
  for (const c of ev.costs) cw.addRow({ ...c, total: costAmount(c), meal: mealName.get(c.meal_id) || 'Event' });
  return wb.xlsx.writeBuffer();
}

/** Import / update prices from an xlsx shaped like the Aviyana price list or this app's export. */
export async function importIngredients(buf, userId, { addNew = false } = {}) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buf);
  const ws = wb.worksheets[0];
  let headerRow = null, cols = {};
  ws.eachRow((row, rn) => {
    if (headerRow) return;
    const vals = row.values.map((v) => String(v ?? '').toLowerCase());
    const ci = (re) => vals.findIndex((v) => re.test(v));
    if (ci(/item code|^code$/) > 0 && ci(/price/) > 0) {
      headerRow = rn;
      cols = { code: ci(/item code|^code$/), name: ci(/ingredient|^name$/), cat: ci(/category/), unit: ci(/unit$|base unit|^unit/), price: ci(/price per|^price/), aliases: ci(/also known/) };
    }
  });
  if (!headerRow) throw Object.assign(new Error('Could not find a header row with "Item Code" and "Price" columns.'), { status: 400 });
  const res = { updated: 0, unchanged: 0, added: 0, skipped: 0, notFound: [] };
  const cell = (row, i) => { if (i <= 0) return null; const v = row.getCell(i).value; return v && typeof v === 'object' && 'result' in v ? v.result : v; };
  tx(() => {
    ws.eachRow((row, rn) => {
      if (rn <= headerRow) return;
      const code = String(cell(row, cols.code) ?? '').trim();
      if (!code) return;
      const pv = cell(row, cols.price);
      const price = pv === null || pv === '' || pv === undefined || !isFinite(+pv) ? null : +pv;
      const cur = get('SELECT * FROM ingredients WHERE code = ?', code);
      if (cur) {
        if (price == null || price === cur.price) { res.unchanged++; return; }
        run("UPDATE ingredients SET price = ?, price_status = 'updated', updated_at = datetime('now') WHERE id = ?", price, cur.id);
        run('INSERT INTO price_history (ingredient_id, old_price, new_price, note, user_id) VALUES (?,?,?,?,?)', cur.id, cur.price, price, 'Excel import', userId);
        res.updated++;
      } else if (addNew && cols.name > 0) {
        const name = String(cell(row, cols.name) ?? '').trim();
        const unit = String(cell(row, cols.unit) ?? 'Kg').trim() || 'Kg';
        if (!name) { res.skipped++; return; }
        run('INSERT INTO ingredients (code, name, category, unit, price, price_status, aliases) VALUES (?,?,?,?,?,?,?)', code, name, String(cell(row, cols.cat) ?? 'Other'), unit, price,
          price == null ? 'none' : 'list', String(cell(row, cols.aliases) ?? ''));
        res.added++;
      } else { res.skipped++; if (res.notFound.length < 20) res.notFound.push(code); }
    });
  });
  return res;
}
