import crypto from 'node:crypto';
import { get, run } from './db.js';

const SESSION_DAYS = 14;
export const COOKIE = 'bb_session';

export function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const hash = crypto.scryptSync(String(pw), salt, 64);
  return `scrypt$${salt.toString('hex')}$${hash.toString('hex')}`;
}

export function verifyPassword(pw, stored) {
  const [alg, saltHex, hashHex] = String(stored).split('$');
  if (alg !== 'scrypt' || !saltHex || !hashHex) return false;
  const hash = crypto.scryptSync(String(pw), Buffer.from(saltHex, 'hex'), 64);
  const exp = Buffer.from(hashHex, 'hex');
  return exp.length === hash.length && crypto.timingSafeEqual(exp, hash);
}

export function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const exp = new Date(Date.now() + SESSION_DAYS * 864e5).toISOString();
  run('INSERT INTO sessions (token, user_id, expires_at) VALUES (?,?,?)', token, userId, exp);
  run("DELETE FROM sessions WHERE expires_at < ?", new Date().toISOString());
  return { token, exp };
}

export function parseCookies(header) {
  const out = {};
  for (const part of String(header || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function sessionUser(req) {
  const tok = parseCookies(req.headers.cookie)[COOKIE];
  if (!tok) return null;
  const row = get(
    `SELECT u.id, u.email, u.name, u.role, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id
     WHERE s.token = ? AND u.active = 1`, tok);
  if (!row || row.expires_at < new Date().toISOString()) return null;
  return { id: row.id, email: row.email, name: row.name, role: row.role, token: tok };
}

export function cookieHeader(token, exp, secure) {
  const parts = [`${COOKIE}=${token}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Expires=${new Date(exp).toUTCString()}`];
  if (secure) parts.push('Secure');
  return parts.join('; ');
}

// Role permissions
export const CAN = {
  recipes: ['admin', 'manager', 'chef'],
  ingredients: ['admin', 'manager', 'purchasing'],
  events: ['admin', 'manager', 'sales', 'chef'],
  deleteEvents: ['admin', 'manager'],
  settings: ['admin'],
  users: ['admin'],
};

export const can = (user, what) => !!user && CAN[what].includes(user.role);

// Simple in-memory login throttle
const attempts = new Map();
export function throttled(key) {
  const now = Date.now();
  const a = (attempts.get(key) || []).filter((t) => now - t < 15 * 60e3);
  attempts.set(key, a);
  return a.length >= 10;
}
export function noteFailure(key) {
  const a = attempts.get(key) || [];
  a.push(Date.now());
  attempts.set(key, a);
}
