import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db, migrate, all, get, run, tx, getSettings, saveSettings, audit } from './db.js';
import { hashPassword, verifyPassword, createSession, sessionUser, cookieHeader, COOKIE, can, throttled, noteFailure } from './auth.js';
import { catalog, loadEvent, summarize, eventPurchaseList, buildCtx, loadRecipes } from './data.js';
import { parseMenu, matchRecipes, pdfToText } from './menu.js';
import { exportEvent, exportIngredients, exportRecipes, exportPurchase, importIngredients } from './excel.js';
import { recipeCost } from '../public/js/costing.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
migrate();

export const app = express();
app.disable('x-powered-by');
app.set('trust proxy', process.env.TRUST_PROXY === '1');
app.use(express.json({ limit: '25mb' }));

// ---------- helpers ----------
class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (msg) => { throw new HttpError(400, msg); };
const notFound = (what = 'Not found') => { throw new HttpError(404, what); };
const num = (v, d = null) => (v === '' || v === null || v === undefined ? d : isFinite(+v) ? +v : d);
const str = (v, d = '') => (v === null || v === undefined ? d : String(v).slice(0, 5000));
const id = (v) => { const x = parseInt(v, 10); if (!x) bad('Invalid id'); return x; };
const today = () => new Date().toISOString().slice(0, 10);
const now = () => new Date().toISOString().replace('T', ' ').slice(0, 19);

function need(req, what) {
  if (!can(req.user, what)) throw new HttpError(403, 'Your role does not allow this change.');
}

// ---------- security headers & CSRF ----------
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Content-Security-Policy', "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; font-src 'self' data:");
  next();
});
app.use('/api', (req, res, next) => {
  if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'banquet-budget') return res.status(403).json({ error: 'Missing request header.' });
  next();
});

// ---------- auth ----------
app.post('/api/auth/login', (req, res) => {
  const email = str(req.body?.email).trim().toLowerCase();
  const key = email + '|' + req.ip;
  if (throttled(key)) return res.status(429).json({ error: 'Too many attempts. Try again in 15 minutes.' });
  const u = get('SELECT * FROM users WHERE email = ? AND active = 1', email);
  if (!u || !verifyPassword(str(req.body?.password), u.pass_hash)) {
    noteFailure(key);
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }
  const s = createSession(u.id);
  res.setHeader('Set-Cookie', cookieHeader(s.token, s.exp, req.secure));
  audit(u.id, 'login', 'user', u.id);
  res.json({ user: { id: u.id, email: u.email, name: u.name, role: u.role } });
});

app.use('/api', (req, res, next) => {
  req.user = sessionUser(req);
  if (!req.user) return res.status(401).json({ error: 'Please sign in.' });
  next();
});

app.post('/api/auth/logout', (req, res) => {
  run('DELETE FROM sessions WHERE token = ?', req.user.token);
  res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
  res.json({ ok: true });
});
app.get('/api/auth/me', (req, res) => res.json({ user: { id: req.user.id, email: req.user.email, name: req.user.name, role: req.user.role } }));
app.post('/api/auth/password', (req, res) => {
  const u = get('SELECT * FROM users WHERE id = ?', req.user.id);
  if (!verifyPassword(str(req.body.current), u.pass_hash)) bad('Current password is incorrect.');
  if (str(req.body.next).length < 8) bad('New password must be at least 8 characters.');
  run('UPDATE users SET pass_hash = ? WHERE id = ?', hashPassword(req.body.next), u.id);
  run('DELETE FROM sessions WHERE user_id = ? AND token != ?', u.id, req.user.token);
  res.json({ ok: true });
});

// ---------- users ----------
app.get('/api/users', (req, res) => {
  need(req, 'users');
  res.json(all('SELECT id, email, name, role, active, created_at FROM users ORDER BY name'));
});
app.post('/api/users', (req, res) => {
  need(req, 'users');
  const b = req.body;
  if (!str(b.email).includes('@')) bad('Enter a valid email.');
  if (str(b.password).length < 8) bad('Password must be at least 8 characters.');
  if (get('SELECT 1 FROM users WHERE email = ?', b.email)) bad('A user with this email already exists.');
  const r = run('INSERT INTO users (email, name, role, pass_hash) VALUES (?,?,?,?)', str(b.email).trim(), str(b.name) || b.email, b.role || 'viewer', hashPassword(b.password));
  audit(req.user.id, 'create', 'user', r.lastInsertRowid, b.email);
  res.json({ id: Number(r.lastInsertRowid) });
});
app.put('/api/users/:id', (req, res) => {
  need(req, 'users');
  const uid = id(req.params.id), b = req.body;
  const u = get('SELECT * FROM users WHERE id = ?', uid) || notFound();
  if (uid === req.user.id && (b.role && b.role !== 'admin' || b.active === 0)) bad('You cannot remove your own admin access.');
  run('UPDATE users SET name = ?, role = ?, active = ? WHERE id = ?', str(b.name ?? u.name), b.role ?? u.role, num(b.active, u.active), uid);
  if (b.password) {
    if (str(b.password).length < 8) bad('Password must be at least 8 characters.');
    run('UPDATE users SET pass_hash = ? WHERE id = ?', hashPassword(b.password), uid);
    run('DELETE FROM sessions WHERE user_id = ?', uid);
  }
  if (b.active === 0) run('DELETE FROM sessions WHERE user_id = ?', uid);
  audit(req.user.id, 'update', 'user', uid);
  res.json({ ok: true });
});

// ---------- settings ----------
app.get('/api/settings', (req, res) => res.json(getSettings()));
app.put('/api/settings', (req, res) => {
  need(req, 'settings');
  saveSettings(req.body || {});
  audit(req.user.id, 'update', 'settings', null);
  res.json(getSettings());
});

// ---------- catalog ----------
app.get('/api/catalog', (req, res) => res.json(catalog()));

// ---------- suppliers ----------
app.get('/api/suppliers', (req, res) => res.json(all(`SELECT s.*, (SELECT COUNT(*) FROM ingredients i WHERE i.supplier_id = s.id) AS items FROM suppliers s ORDER BY name`)));
app.post('/api/suppliers', (req, res) => {
  need(req, 'ingredients');
  const b = req.body;
  if (!str(b.name).trim()) bad('Supplier name is required.');
  const r = run('INSERT INTO suppliers (name, contact, phone, email, notes) VALUES (?,?,?,?,?)', str(b.name), str(b.contact), str(b.phone), str(b.email), str(b.notes));
  res.json({ id: Number(r.lastInsertRowid) });
});
app.put('/api/suppliers/:id', (req, res) => {
  need(req, 'ingredients');
  const b = req.body;
  run('UPDATE suppliers SET name=?, contact=?, phone=?, email=?, notes=?, active=? WHERE id=?', str(b.name), str(b.contact), str(b.phone), str(b.email), str(b.notes), num(b.active, 1), id(req.params.id));
  res.json({ ok: true });
});
app.delete('/api/suppliers/:id', (req, res) => {
  need(req, 'ingredients');
  run('DELETE FROM suppliers WHERE id = ?', id(req.params.id));
  res.json({ ok: true });
});

// ---------- ingredients ----------
const UNITS = ['Kg', 'Gms', 'Lit', 'Ml', 'No', 'Pack', 'Pkt', 'Box', 'Can', 'Bottle'];
app.get('/api/ingredients/export.xlsx', async (req, res) => {
  const buf = await exportIngredients();
  sendXlsx(res, buf, `ingredient-prices-${today()}.xlsx`);
});
app.get('/api/ingredients/:id', (req, res) => {
  const iid = id(req.params.id);
  const it = get('SELECT i.*, s.name AS supplier_name FROM ingredients i LEFT JOIN suppliers s ON s.id = i.supplier_id WHERE i.id = ?', iid) || notFound();
  it.history = all('SELECT h.*, u.name AS user_name FROM price_history h LEFT JOIN users u ON u.id = h.user_id WHERE ingredient_id = ? ORDER BY h.id DESC LIMIT 50', iid);
  it.used_in = all('SELECT DISTINCT r.id, r.name FROM recipe_lines l JOIN recipes r ON r.id = l.recipe_id WHERE l.ingredient_id = ? AND r.active = 1 ORDER BY r.name', iid);
  res.json(it);
});
function nextCode(category) {
  const prefix = (category || 'OTH').replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'OTH';
  const rows = all("SELECT code FROM ingredients WHERE code LIKE ?", prefix + '-%');
  const max = rows.reduce((m, r) => Math.max(m, parseInt(r.code.split('-')[1], 10) || 0), 0);
  return `${prefix}-${String(max + 1).padStart(3, '0')}`;
}
app.post('/api/ingredients', (req, res) => {
  need(req, 'ingredients');
  const b = req.body;
  if (!str(b.name).trim()) bad('Ingredient name is required.');
  if (!UNITS.includes(b.unit)) bad('Choose a valid unit.');
  const code = str(b.code).trim() || nextCode(b.category);
  if (get('SELECT 1 FROM ingredients WHERE code = ?', code)) bad('That item code is already used.');
  const price = num(b.price);
  const r = run('INSERT INTO ingredients (code, name, category, unit, price, price_status, supplier_id, aliases, note) VALUES (?,?,?,?,?,?,?,?,?)',
    code, str(b.name).trim(), str(b.category) || 'Other', b.unit, price, price == null ? 'none' : 'direct', num(b.supplier_id), str(b.aliases), str(b.note));
  if (price != null) run('INSERT INTO price_history (ingredient_id, old_price, new_price, note, user_id) VALUES (?,?,?,?,?)', r.lastInsertRowid, null, price, 'Created', req.user.id);
  audit(req.user.id, 'create', 'ingredient', r.lastInsertRowid, code);
  res.json({ id: Number(r.lastInsertRowid), code });
});
app.put('/api/ingredients/:id', (req, res) => {
  need(req, 'ingredients');
  const iid = id(req.params.id), b = req.body;
  const cur = get('SELECT * FROM ingredients WHERE id = ?', iid) || notFound();
  if (b.unit && !UNITS.includes(b.unit)) bad('Choose a valid unit.');
  const price = 'price' in b ? num(b.price) : cur.price;
  let status = b.price_status || cur.price_status;
  if ('price' in b && price !== cur.price) status = price == null ? 'none' : b.price_status && b.price_status !== cur.price_status ? b.price_status : 'updated';
  tx(() => {
    run(`UPDATE ingredients SET name=?, category=?, unit=?, price=?, price_status=?, supplier_id=?, aliases=?, note=?, active=?, updated_at=datetime('now') WHERE id=?`,
      str(b.name ?? cur.name), str(b.category ?? cur.category), b.unit ?? cur.unit, price, status, 'supplier_id' in b ? num(b.supplier_id) : cur.supplier_id,
      str(b.aliases ?? cur.aliases), str(b.note ?? cur.note), num(b.active, cur.active), iid);
    if (price !== cur.price) run('INSERT INTO price_history (ingredient_id, old_price, new_price, note, user_id) VALUES (?,?,?,?,?)', iid, cur.price, price, str(b.price_note), req.user.id);
  });
  audit(req.user.id, 'update', 'ingredient', iid, price !== cur.price ? `price ${cur.price} → ${price}` : '');
  res.json({ ok: true });
});
app.post('/api/ingredients/import', async (req, res) => {
  need(req, 'ingredients');
  if (!req.body.fileBase64) bad('Attach an .xlsx file.');
  const result = await importIngredients(Buffer.from(req.body.fileBase64, 'base64'), req.user.id, { addNew: !!req.body.addNew });
  audit(req.user.id, 'import', 'ingredients', null, JSON.stringify(result).slice(0, 300));
  res.json(result);
});

// ---------- recipes ----------
app.get('/api/recipes/export.xlsx', async (req, res) => sendXlsx(res, await exportRecipes(), `recipe-cost-cards-${today()}.xlsx`));
app.get('/api/recipes/:id', (req, res) => {
  const rid = id(req.params.id);
  const r = get('SELECT * FROM recipes WHERE id = ?', rid) || notFound();
  r.lines = all('SELECT * FROM recipe_lines WHERE recipe_id = ? ORDER BY position', rid);
  r.used_in = all(`SELECT DISTINCT e.id AS event_id, e.name AS event_name, m.id AS meal_id, m.name AS meal_name, m.date FROM meal_items mi
    JOIN meals m ON m.id = mi.meal_id JOIN events e ON e.id = m.event_id WHERE mi.recipe_id = ? ORDER BY m.date DESC LIMIT 30`, rid);
  r.used_as_sub = all('SELECT DISTINCT r.id, r.name FROM recipe_lines l JOIN recipes r ON r.id = l.recipe_id WHERE l.sub_recipe_id = ?', rid);
  r.creator = get('SELECT name FROM users WHERE id = ?', r.created_by)?.name || '';
  res.json(r);
});
function validateLines(lines, rid) {
  if (!Array.isArray(lines)) bad('Lines must be a list.');
  return lines.map((l, i) => {
    const kinds = [l.ingredient_id, l.sub_recipe_id, str(l.custom_name).trim()].filter(Boolean).length;
    if (kinds !== 1) bad(`Line ${i + 1}: pick one ingredient, sub-recipe or custom item.`);
    if (l.sub_recipe_id && rid && +l.sub_recipe_id === rid) bad('A recipe cannot use itself as a sub-recipe.');
    return {
      ingredient_id: num(l.ingredient_id), sub_recipe_id: num(l.sub_recipe_id), custom_name: str(l.custom_name).trim() || null,
      qty: num(l.qty, 0), unit: str(l.unit) || 'g', rate_override: num(l.rate_override), note: str(l.note),
    };
  });
}
function insertLines(rid, lines) {
  const st = db.prepare('INSERT INTO recipe_lines (recipe_id, position, ingredient_id, sub_recipe_id, custom_name, qty, unit, rate_override, note) VALUES (?,?,?,?,?,?,?,?,?)');
  lines.forEach((l, i) => st.run(rid, i, l.ingredient_id, l.sub_recipe_id, l.custom_name, l.qty, l.unit, l.rate_override, l.note));
}
function checkCycle(rid) {
  const recs = loadRecipes();
  const map = new Map(recs.map((r) => [r.id, r]));
  const seen = new Set();
  const visit = (x, path) => {
    if (path.has(x)) bad('This would create a loop of sub-recipes using each other.');
    if (seen.has(x)) return;
    seen.add(x);
    path.add(x);
    for (const l of map.get(x)?.lines || []) if (l.sub_recipe_id) visit(l.sub_recipe_id, path);
    path.delete(x);
  };
  visit(rid, new Set());
}
const recipeFields = (b) => [str(b.name).trim(), str(b.section) || 'Other', str(b.diet) || 'veg', num(b.yield_pax, 10) || 10, b.is_sub ? 1 : 0,
  num(b.yield_qty), b.is_sub ? str(b.yield_unit) || 'kg' : null, str(b.aliases), str(b.method), str(b.notes), str(b.status) || 'draft'];
app.post('/api/recipes', (req, res) => {
  need(req, 'recipes');
  const b = req.body;
  if (!str(b.name).trim()) bad('Recipe name is required.');
  const lines = validateLines(b.lines || []);
  const rid = tx(() => {
    const r = run(`INSERT INTO recipes (name, section, diet, yield_pax, is_sub, yield_qty, yield_unit, aliases, method, notes, status, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      ...recipeFields(b), req.user.id);
    insertLines(Number(r.lastInsertRowid), lines);
    return Number(r.lastInsertRowid);
  });
  audit(req.user.id, 'create', 'recipe', rid, b.name);
  res.json({ id: rid });
});
app.put('/api/recipes/:id', (req, res) => {
  need(req, 'recipes');
  const rid = id(req.params.id), b = req.body;
  const cur = get('SELECT * FROM recipes WHERE id = ?', rid) || notFound();
  if (b.version != null && +b.version !== cur.version) throw new HttpError(409, 'Someone else saved this recipe while you were editing. Reload to see their changes.');
  if (!str(b.name).trim()) bad('Recipe name is required.');
  const lines = validateLines(b.lines || [], rid);
  tx(() => {
    run(`UPDATE recipes SET name=?, section=?, diet=?, yield_pax=?, is_sub=?, yield_qty=?, yield_unit=?, aliases=?, method=?, notes=?, status=?,
         active=?, version=version+1, updated_at=datetime('now') WHERE id=?`, ...recipeFields(b), num(b.active, 1), rid);
    run('DELETE FROM recipe_lines WHERE recipe_id = ?', rid);
    insertLines(rid, lines);
    checkCycle(rid);
  });
  audit(req.user.id, 'update', 'recipe', rid, b.name);
  res.json({ ok: true, version: cur.version + 1 });
});
app.post('/api/recipes/:id/duplicate', (req, res) => {
  need(req, 'recipes');
  const rid = id(req.params.id);
  const r = get('SELECT * FROM recipes WHERE id = ?', rid) || notFound();
  const lines = all('SELECT * FROM recipe_lines WHERE recipe_id = ? ORDER BY position', rid);
  const nid = tx(() => {
    const x = run(`INSERT INTO recipes (name, section, diet, yield_pax, is_sub, yield_qty, yield_unit, aliases, method, notes, status, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      r.name + ' (copy)', r.section, r.diet, r.yield_pax, r.is_sub, r.yield_qty, r.yield_unit, '', r.method, r.notes, 'draft', req.user.id);
    insertLines(Number(x.lastInsertRowid), lines);
    return Number(x.lastInsertRowid);
  });
  res.json({ id: nid });
});
app.delete('/api/recipes/:id', (req, res) => {
  need(req, 'recipes');
  const rid = id(req.params.id);
  const used = get('SELECT COUNT(*) c FROM meal_items WHERE recipe_id = ?', rid).c + get('SELECT COUNT(*) c FROM recipe_lines WHERE sub_recipe_id = ?', rid).c;
  if (used) run('UPDATE recipes SET active = 0 WHERE id = ?', rid);
  else run('DELETE FROM recipes WHERE id = ?', rid);
  audit(req.user.id, used ? 'archive' : 'delete', 'recipe', rid);
  res.json({ ok: true, archived: !!used });
});

// ---------- events ----------
app.get('/api/events', (req, res) => {
  const settings = getSettings();
  const bundle = buildCtx();
  const evs = all('SELECT id FROM events ORDER BY start_date DESC, id DESC').map((r) => {
    const ev = loadEvent(r.id);
    const s = summarize(ev, settings, bundle);
    return {
      id: ev.id, name: ev.name, client_name: ev.client_name, venue: ev.venue, start_date: ev.start_date, end_date: ev.end_date, status: ev.status,
      event_type: ev.event_type, meals: ev.meals.length, pax: Math.max(0, ...ev.meals.map((m) => m.pax)), totalCost: s.totalCost, revenue: s.revenue,
      costPct: s.costPct, gp: s.gp, updated_at: ev.updated_at, target_pct: ev.target_pct,
    };
  });
  res.json(evs);
});
const EVENT_STATUSES = ['enquiry', 'quoted', 'confirmed', 'completed', 'lost'];
const eventFields = (b, s) => [str(b.name).trim(), str(b.client_name), str(b.client_contact), str(b.client_email), str(b.client_phone), str(b.venue),
  str(b.start_date) || null, str(b.end_date) || null, EVENT_STATUSES.includes(b.status) ? b.status : 'enquiry', str(b.event_type) || 'Wedding',
  b.price_basis === 'net' ? 'net' : 'plus_plus', num(b.target_pct, s.target_pct), num(b.wastage_pct, s.wastage_pct), str(b.notes)];
app.post('/api/events', (req, res) => {
  need(req, 'events');
  const b = req.body;
  if (!str(b.name).trim()) bad('Event name is required.');
  const r = run(`INSERT INTO events (name, client_name, client_contact, client_email, client_phone, venue, start_date, end_date, status, event_type, price_basis,
    target_pct, wastage_pct, notes, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, ...eventFields(b, getSettings()), req.user.id);
  audit(req.user.id, 'create', 'event', r.lastInsertRowid, b.name);
  res.json({ id: Number(r.lastInsertRowid) });
});
app.get('/api/events/:id', (req, res) => {
  const ev = loadEvent(id(req.params.id)) || notFound('Event not found');
  ev.summary = summarize(ev, getSettings());
  res.json(ev);
});
const touchEvent = (eid) => run("UPDATE events SET updated_at = datetime('now') WHERE id = ?", eid);
app.put('/api/events/:id', (req, res) => {
  need(req, 'events');
  const eid = id(req.params.id), b = req.body;
  const cur = get('SELECT * FROM events WHERE id = ?', eid) || notFound();
  if (b.version != null && +b.version !== cur.version) throw new HttpError(409, 'Someone else saved this event while you were editing. Reload to see their changes.');
  if (!str(b.name).trim()) bad('Event name is required.');
  run(`UPDATE events SET name=?, client_name=?, client_contact=?, client_email=?, client_phone=?, venue=?, start_date=?, end_date=?, status=?, event_type=?,
    price_basis=?, target_pct=?, wastage_pct=?, notes=?, version=version+1, updated_at=datetime('now') WHERE id=?`, ...eventFields(b, getSettings()), eid);
  audit(req.user.id, 'update', 'event', eid);
  res.json({ ok: true, version: cur.version + 1 });
});
app.delete('/api/events/:id', (req, res) => {
  need(req, 'deleteEvents');
  const eid = id(req.params.id);
  run('DELETE FROM events WHERE id = ?', eid);
  audit(req.user.id, 'delete', 'event', eid);
  res.json({ ok: true });
});
app.post('/api/events/:id/duplicate', (req, res) => {
  need(req, 'events');
  const src = loadEvent(id(req.params.id)) || notFound();
  const shiftDays = num(req.body.shift_days, 0);
  const shift = (d) => (d ? new Date(Date.parse(d) + shiftDays * 864e5).toISOString().slice(0, 10) : d);
  const nid = tx(() => {
    const r = run(`INSERT INTO events (name, client_name, client_contact, client_email, client_phone, venue, start_date, end_date, status, event_type, price_basis,
      target_pct, wastage_pct, notes, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`, str(req.body.name) || src.name + ' (copy)', src.client_name, src.client_contact,
      src.client_email, src.client_phone, src.venue, shift(src.start_date), shift(src.end_date), 'enquiry', src.event_type, src.price_basis, src.target_pct, src.wastage_pct, src.notes, req.user.id);
    const nid = Number(r.lastInsertRowid);
    const mealMap = new Map();
    for (const m of src.meals) mealMap.set(m.id, copyMeal(m, nid, shift(m.date)));
    if (req.body.with_labour !== false) {
      for (const l of src.labour) run(`INSERT INTO labour (event_id, meal_id, position, department, role, date, headcount, time_from, time_to, hours, rate, form_ref, note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        nid, mealMap.get(l.meal_id) ?? null, l.position, l.department, l.role, shift(l.date), l.headcount, l.time_from, l.time_to, l.hours, l.rate, '', l.note);
      for (const c of src.costs) run(`INSERT INTO costs (event_id, meal_id, position, category, description, qty, unit, rate, supplier, note) VALUES (?,?,?,?,?,?,?,?,?,?)`,
        nid, mealMap.get(c.meal_id) ?? null, c.position, c.category, c.description, c.qty, c.unit, c.rate, c.supplier, c.note);
    }
    for (const r2 of src.revenue_items) run('INSERT INTO revenue_items (event_id, position, description, qty, unit, unit_price, note) VALUES (?,?,?,?,?,?,?)', nid, r2.position, r2.description, r2.qty, r2.unit, r2.unit_price, r2.note);
    return nid;
  });
  audit(req.user.id, 'duplicate', 'event', nid, 'from ' + src.id);
  res.json({ id: nid });
});

// ---------- meals ----------
const MEAL_KINDS = ['breakfast', 'lunch', 'dinner', 'brunch', 'hi-tea', 'cocktail', 'station', 'other'];
function insertItems(mid, items) {
  const st = db.prepare('INSERT INTO meal_items (meal_id, position, section, name, diet, recipe_id, factor, portions, cost_per_portion, note) VALUES (?,?,?,?,?,?,?,?,?,?)');
  items.forEach((it, i) => st.run(mid, i, str(it.section) || 'Other', str(it.name).trim() || 'Untitled dish', str(it.diet) || null, num(it.recipe_id),
    num(it.factor, 100), num(it.portions), num(it.cost_per_portion), str(it.note)));
}
function copyMeal(m, eventId, date) {
  const r = run(`INSERT INTO meals (event_id, position, name, kind, date, time, venue, pax, price_per_pax, bev_price_per_pax, chargeable, wastage_pct, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    eventId, m.position, m.name, m.kind, date, m.time, m.venue, m.pax, m.price_per_pax, m.bev_price_per_pax, m.chargeable, m.wastage_pct, m.notes);
  const mid = Number(r.lastInsertRowid);
  insertItems(mid, m.items || []);
  return mid;
}
const mealFields = (b) => [str(b.name).trim() || 'Meal', MEAL_KINDS.includes(b.kind) ? b.kind : 'other', str(b.date) || null, str(b.time), str(b.venue),
  num(b.pax, 0), num(b.price_per_pax, 0), num(b.bev_price_per_pax, 0), b.chargeable === 0 || b.chargeable === false ? 0 : 1, num(b.wastage_pct), str(b.notes)];
app.post('/api/events/:id/meals', (req, res) => {
  need(req, 'events');
  const eid = id(req.params.id);
  get('SELECT 1 FROM events WHERE id = ?', eid) || notFound();
  const pos = get('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM meals WHERE event_id = ?', eid).p;
  const r = run(`INSERT INTO meals (event_id, position, name, kind, date, time, venue, pax, price_per_pax, bev_price_per_pax, chargeable, wastage_pct, notes)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`, eid, pos, ...mealFields(req.body));
  touchEvent(eid);
  res.json({ id: Number(r.lastInsertRowid) });
});
app.put('/api/meals/:id', (req, res) => {
  need(req, 'events');
  const mid = id(req.params.id), b = req.body;
  const cur = get('SELECT * FROM meals WHERE id = ?', mid) || notFound();
  if (b.version != null && +b.version !== cur.version) throw new HttpError(409, 'Someone else saved this meal while you were editing. Reload to see their changes.');
  tx(() => {
    run(`UPDATE meals SET name=?, kind=?, date=?, time=?, venue=?, pax=?, price_per_pax=?, bev_price_per_pax=?, chargeable=?, wastage_pct=?, notes=?, version=version+1 WHERE id=?`, ...mealFields(b), mid);
    if (Array.isArray(b.items)) {
      run('DELETE FROM meal_items WHERE meal_id = ?', mid);
      insertItems(mid, b.items);
    }
  });
  touchEvent(cur.event_id);
  audit(req.user.id, 'update', 'meal', mid, b.name);
  res.json({ ok: true, version: cur.version + 1 });
});
app.delete('/api/meals/:id', (req, res) => {
  need(req, 'events');
  const mid = id(req.params.id);
  const cur = get('SELECT * FROM meals WHERE id = ?', mid) || notFound();
  run('DELETE FROM meals WHERE id = ?', mid);
  touchEvent(cur.event_id);
  audit(req.user.id, 'delete', 'meal', mid, cur.name);
  res.json({ ok: true });
});
app.post('/api/meals/:id/duplicate', (req, res) => {
  need(req, 'events');
  const mid = id(req.params.id);
  const m = get('SELECT * FROM meals WHERE id = ?', mid) || notFound();
  m.items = all('SELECT * FROM meal_items WHERE meal_id = ? ORDER BY position', mid);
  m.name = str(req.body.name) || m.name + ' (copy)';
  const nid = tx(() => copyMeal(m, num(req.body.event_id, m.event_id), str(req.body.date) || m.date));
  touchEvent(m.event_id);
  res.json({ id: nid });
});

// ---------- labour, other costs, revenue items (whole-list saves) ----------
app.put('/api/events/:id/labour', (req, res) => {
  need(req, 'events');
  const eid = id(req.params.id);
  const rows = Array.isArray(req.body.rows) ? req.body.rows : bad('Rows must be a list.');
  tx(() => {
    run('DELETE FROM labour WHERE event_id = ?', eid);
    const st = db.prepare(`INSERT INTO labour (event_id, meal_id, position, department, role, date, headcount, time_from, time_to, hours, rate, form_ref, note) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    rows.forEach((l, i) => st.run(eid, num(l.meal_id), i, str(l.department) || 'Kitchen', str(l.role), str(l.date) || null, num(l.headcount, 0), str(l.time_from), str(l.time_to),
      num(l.hours), num(l.rate, 0), str(l.form_ref), str(l.note)));
    touchEvent(eid);
  });
  audit(req.user.id, 'update', 'labour', eid, rows.length + ' rows');
  res.json({ ok: true });
});
app.put('/api/events/:id/costs', (req, res) => {
  need(req, 'events');
  const eid = id(req.params.id);
  const rows = Array.isArray(req.body.rows) ? req.body.rows : bad('Rows must be a list.');
  tx(() => {
    run('DELETE FROM costs WHERE event_id = ?', eid);
    const st = db.prepare(`INSERT INTO costs (event_id, meal_id, position, category, description, qty, unit, rate, supplier, note) VALUES (?,?,?,?,?,?,?,?,?,?)`);
    rows.forEach((c, i) => st.run(eid, num(c.meal_id), i, str(c.category) || 'Other', str(c.description), num(c.qty, 0), str(c.unit) || 'lot', num(c.rate, 0), str(c.supplier), str(c.note)));
    touchEvent(eid);
  });
  audit(req.user.id, 'update', 'costs', eid, rows.length + ' rows');
  res.json({ ok: true });
});
app.put('/api/events/:id/revenue-items', (req, res) => {
  need(req, 'events');
  const eid = id(req.params.id);
  const rows = Array.isArray(req.body.rows) ? req.body.rows : bad('Rows must be a list.');
  tx(() => {
    run('DELETE FROM revenue_items WHERE event_id = ?', eid);
    const st = db.prepare('INSERT INTO revenue_items (event_id, position, description, qty, unit, unit_price, note) VALUES (?,?,?,?,?,?,?)');
    rows.forEach((r, i) => st.run(eid, i, str(r.description), num(r.qty, 0), str(r.unit) || 'lot', num(r.unit_price, 0), str(r.note)));
    touchEvent(eid);
  });
  res.json({ ok: true });
});

// ---------- reports ----------
app.get('/api/events/:id/purchase', (req, res) => {
  const ev = loadEvent(id(req.params.id)) || notFound();
  res.json(eventPurchaseList(ev, { mealId: num(req.query.meal) }));
});
app.get('/api/events/:id/purchase.xlsx', async (req, res) => {
  const ev = loadEvent(id(req.params.id)) || notFound();
  sendXlsx(res, await exportPurchase(ev, num(req.query.meal)), `${slug(ev.name)}-purchase-list.xlsx`);
});
app.get('/api/events/:id/export.xlsx', async (req, res) => {
  const ev = loadEvent(id(req.params.id)) || notFound();
  sendXlsx(res, await exportEvent(ev), `${slug(ev.name)}-budget.xlsx`);
});

// ---------- quotations ----------
function nextQuoteNumber() {
  const y = new Date().getFullYear();
  const row = get("SELECT number FROM quotations WHERE number LIKE ? ORDER BY id DESC LIMIT 1", `Q${y}-%`);
  const n = row ? parseInt(row.number.split('-')[1], 10) + 1 : 1;
  return `Q${y}-${String(n).padStart(4, '0')}`;
}
app.post('/api/events/:id/quotations', (req, res) => {
  need(req, 'events');
  const ev = loadEvent(id(req.params.id)) || notFound();
  const s = getSettings();
  const sum = summarize(ev, s);
  const lines = ev.meals.filter((m) => m.chargeable).map((m) => ({
    date: m.date, description: m.name + (m.venue ? ` (${m.venue})` : ''), pax: m.pax, rate: m.price_per_pax, bev: m.bev_price_per_pax,
    amount: (m.price_per_pax + m.bev_price_per_pax) * m.pax,
  }));
  const extra = ev.revenue_items.map((r) => ({ date: '', description: r.description, pax: r.qty, unit: r.unit, rate: r.unit_price, bev: 0, amount: r.qty * r.unit_price }));
  // The beverage package is already a priced line, so charged meals don't repeat it in the menu.
  const menus = ev.meals.map((m) => ({ name: m.name, date: m.date, venue: m.venue, chargeable: m.chargeable,
    sections: groupItems(m.items.filter((it) => !(m.chargeable && it.section === 'Beverages')), s.sections) }));
  const subtotal = [...lines, ...extra].reduce((a, l) => a + l.amount, 0);
  const valid = new Date(Date.now() + num(s.quote_validity_days, 14) * 864e5).toISOString().slice(0, 10);
  const data = {
    hotel: { name: s.hotel_name, address: s.hotel_address, phone: s.hotel_phone, email: s.hotel_email, tax_id: s.hotel_tax_id },
    event: { name: ev.name, type: ev.event_type, start_date: ev.start_date, end_date: ev.end_date, venue: ev.venue },
    client: { name: ev.client_name, contact: ev.client_contact, email: ev.client_email, phone: ev.client_phone },
    lines, extra, menus, price_basis: ev.price_basis, service_pct: s.service_pct, vat_pct: s.vat_pct,
    subtotal, service: sum.serviceCharge, vat: sum.vat, total: sum.clientTotal,
    terms: str(req.body.terms) || s.quote_terms, note: str(req.body.note), prepared_by: req.user.name, include_menu: req.body.include_menu !== false,
  };
  const number = nextQuoteNumber();
  const r = run('INSERT INTO quotations (event_id, number, status, valid_until, data, created_by) VALUES (?,?,?,?,?,?)', ev.id, number, 'draft', valid, JSON.stringify(data), req.user.id);
  if (ev.status === 'enquiry') run("UPDATE events SET status = 'quoted', version = version + 1 WHERE id = ?", ev.id);
  audit(req.user.id, 'create', 'quotation', r.lastInsertRowid, number);
  res.json({ id: Number(r.lastInsertRowid), number });
});
function groupItems(items, order) {
  const g = new Map();
  for (const it of items) { if (!g.has(it.section)) g.set(it.section, []); g.get(it.section).push(it.name); }
  return [...g.entries()].sort((a, b) => order.indexOf(a[0]) - order.indexOf(b[0])).map(([section, dishes]) => ({ section, dishes }));
}
app.get('/api/quotations/:id', (req, res) => {
  const q = get('SELECT q.*, e.name AS event_name FROM quotations q JOIN events e ON e.id = q.event_id WHERE q.id = ?', id(req.params.id)) || notFound();
  q.data = JSON.parse(q.data);
  res.json(q);
});
app.put('/api/quotations/:id', (req, res) => {
  need(req, 'events');
  const st = ['draft', 'sent', 'accepted', 'declined', 'expired'];
  if (!st.includes(req.body.status)) bad('Unknown status.');
  const qid = id(req.params.id);
  const q = get('SELECT * FROM quotations WHERE id = ?', qid) || notFound();
  run('UPDATE quotations SET status = ? WHERE id = ?', req.body.status, qid);
  if (req.body.status === 'accepted') run("UPDATE events SET status = 'confirmed', version = version + 1 WHERE id = ? AND status IN ('enquiry','quoted')", q.event_id);
  res.json({ ok: true });
});
app.delete('/api/quotations/:id', (req, res) => {
  need(req, 'events');
  run('DELETE FROM quotations WHERE id = ?', id(req.params.id));
  res.json({ ok: true });
});

// ---------- menu import ----------
app.post('/api/menu/parse', async (req, res) => {
  let text = str(req.body.text);
  if (req.body.pdfBase64) {
    try { text = await pdfToText(Buffer.from(req.body.pdfBase64, 'base64')); }
    catch { bad('That PDF could not be read. Try copying the menu text instead.'); }
  }
  if (!text.trim()) bad('Paste the menu text or attach a PDF.');
  const parsed = matchRecipes(parseMenu(text, { year: num(req.body.year) }), loadRecipes({ withLines: false }));
  res.json({ ...parsed, text: text.slice(0, 20000) });
});
app.post('/api/events/:id/import-menu', (req, res) => {
  need(req, 'events');
  const eid = id(req.params.id);
  get('SELECT 1 FROM events WHERE id = ?', eid) || notFound();
  const s = getSettings();
  const meals = Array.isArray(req.body.meals) ? req.body.meals : bad('Nothing to import.');
  const created = { meals: 0, items: 0, recipes: 0 };
  tx(() => {
    let pos = get('SELECT COALESCE(MAX(position), -1) + 1 AS p FROM meals WHERE event_id = ?', eid).p;
    for (const m of meals) {
      const items = [];
      for (const it of m.items || []) {
        if (it.skip) continue;
        let rid = num(it.recipe_id);
        if (!rid && can(req.user, 'recipes') && it.create_recipe !== false) {
          const r = run(`INSERT INTO recipes (name, section, diet, yield_pax, status, notes, created_by) VALUES (?,?,?,?,?,?,?)`,
            str(it.name), str(it.section) || 'Other', it.diet === 'nonveg' || it.diet === 'both' ? it.diet : 'veg', 10, 'draft', 'Created from menu import – add ingredients.', req.user.id);
          rid = Number(r.lastInsertRowid);
          created.recipes++;
        }
        items.push({ section: it.section, name: it.name, diet: it.diet, recipe_id: rid, factor: num(it.factor, s.uptake_defaults?.[it.section] ?? 100), note: it.note });
      }
      const mid = Number(run(`INSERT INTO meals (event_id, position, name, kind, date, time, venue, pax, price_per_pax, bev_price_per_pax, chargeable, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        eid, pos++, str(m.name) || 'Meal', MEAL_KINDS.includes(m.kind) ? m.kind : 'other', str(m.date) || null, '', str(m.venue), num(m.pax, 0), num(m.price, 0), num(m.bev, 0),
        m.chargeable === false ? 0 : 1, (m.notes || []).join(' ')).lastInsertRowid);
      insertItems(mid, items);
      created.meals++;
      created.items += items.length;
    }
    touchEvent(eid);
  });
  audit(req.user.id, 'import-menu', 'event', eid, JSON.stringify(created));
  res.json(created);
});

// ---------- dashboard & audit ----------
app.get('/api/dashboard', (req, res) => {
  const settings = getSettings();
  const bundle = buildCtx();
  const events = all('SELECT id FROM events').map((r) => {
    const ev = loadEvent(r.id);
    const s = summarize(ev, settings, bundle);
    return { id: ev.id, name: ev.name, status: ev.status, start_date: ev.start_date, end_date: ev.end_date, client_name: ev.client_name,
      revenue: s.revenue, totalCost: s.totalCost, costPct: s.costPct, gp: s.gp, target_pct: ev.target_pct, meals: ev.meals.length };
  });
  const t = today();
  const upcoming = events.filter((e) => (e.end_date || e.start_date || '') >= t && e.status !== 'lost').sort((a, b) => (a.start_date || '').localeCompare(b.start_date || ''));
  const pipeline = {};
  for (const e of events) { pipeline[e.status] = pipeline[e.status] || { count: 0, revenue: 0, gp: 0 }; pipeline[e.status].count++; pipeline[e.status].revenue += e.revenue; pipeline[e.status].gp += e.gp; }
  const priceIssues = all("SELECT price_status, COUNT(*) c FROM ingredients WHERE active = 1 GROUP BY price_status");
  const emptyRecipes = get('SELECT COUNT(*) c FROM recipes r WHERE active = 1 AND NOT EXISTS (SELECT 1 FROM recipe_lines l WHERE l.recipe_id = r.id)').c;
  const recipeCount = get('SELECT COUNT(*) c FROM recipes WHERE active = 1').c;
  const recentPrices = all(`SELECT h.at, h.old_price, h.new_price, i.name, i.unit, i.id FROM price_history h JOIN ingredients i ON i.id = h.ingredient_id
    WHERE h.old_price IS NOT NULL ORDER BY h.id DESC LIMIT 8`);
  res.json({ upcoming: upcoming.slice(0, 10), pipeline, priceIssues, emptyRecipes, recipeCount, recentPrices });
});
app.get('/api/audit', (req, res) => {
  need(req, 'users');
  res.json(all('SELECT a.*, u.name AS user_name FROM audit a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT 300'));
});

// ---------- errors ----------
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'File is too large (max 25 MB).' });
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'Something went wrong on the server. The error has been logged.' : err.message });
});

// ---------- static ----------
function sendXlsx(res, buf, name) {
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${name.replace(/"/g, '')}"`);
  res.send(Buffer.from(buf));
}
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'event';

app.get('/vendor/preact-htm.js', (req, res) => res.sendFile(path.join(ROOT, 'node_modules/htm/preact/standalone.module.js')));
app.use(express.static(path.join(ROOT, 'public'), { index: 'index.html', maxAge: '1h' }));
app.get(/^\/(?!api\/).*/, (req, res) => res.sendFile(path.join(ROOT, 'public/index.html')));

export { recipeCost };
