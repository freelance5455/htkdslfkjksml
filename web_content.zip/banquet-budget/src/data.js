import { all, get } from './db.js';
import { makeCtx, recipeCost, eventSummary, purchaseList } from '../public/js/costing.js';

export function loadIngredients(activeOnly = false) {
  return all(`SELECT i.*, s.name AS supplier_name FROM ingredients i LEFT JOIN suppliers s ON s.id = i.supplier_id
              ${activeOnly ? 'WHERE i.active = 1' : ''} ORDER BY i.name COLLATE NOCASE`);
}

export function loadRecipes({ withLines = true, activeOnly = false } = {}) {
  const recs = all(`SELECT * FROM recipes ${activeOnly ? 'WHERE active = 1' : ''} ORDER BY name COLLATE NOCASE`);
  if (withLines) {
    const byId = new Map(recs.map((r) => [r.id, Object.assign(r, { lines: [] })]));
    for (const l of all('SELECT * FROM recipe_lines ORDER BY recipe_id, position')) byId.get(l.recipe_id)?.lines.push(l);
  }
  return recs;
}

export function buildCtx() {
  const ings = loadIngredients();
  const recs = loadRecipes();
  const ctx = makeCtx(ings, recs);
  return { ctx, ings, recs };
}

/** Compact catalogue for the browser: all ingredients and recipe cost summaries. */
export function catalog() {
  const { ctx, ings, recs } = buildCtx();
  return {
    ingredients: ings.map((i) => ({
      id: i.id, code: i.code, name: i.name, category: i.category, unit: i.unit, price: i.price, price_status: i.price_status,
      aliases: i.aliases, supplier_name: i.supplier_name, active: i.active, note: i.note,
    })),
    recipes: recs.map((r) => {
      const c = recipeCost(r, ctx);
      return {
        id: r.id, name: r.name, section: r.section, diet: r.diet, yield_pax: r.yield_pax, is_sub: r.is_sub,
        yield_qty: r.yield_qty, yield_unit: r.yield_unit, aliases: r.aliases, status: r.status, active: r.active,
        total: c.total, per_portion: c.perPortion, per_base: c.perBase, issues: c.issues, lines: r.lines.length,
      };
    }),
  };
}

export function loadEvent(id) {
  const ev = get('SELECT * FROM events WHERE id = ?', id);
  if (!ev) return null;
  ev.meals = all('SELECT * FROM meals WHERE event_id = ? ORDER BY date, position, id', id);
  const items = all('SELECT mi.* FROM meal_items mi JOIN meals m ON m.id = mi.meal_id WHERE m.event_id = ? ORDER BY mi.meal_id, mi.position', id);
  const byMeal = new Map(ev.meals.map((m) => [m.id, Object.assign(m, { items: [] })]));
  for (const it of items) byMeal.get(it.meal_id)?.items.push(it);
  ev.labour = all('SELECT * FROM labour WHERE event_id = ? ORDER BY date, position, id', id);
  ev.costs = all('SELECT * FROM costs WHERE event_id = ? ORDER BY position, id', id);
  ev.revenue_items = all('SELECT * FROM revenue_items WHERE event_id = ? ORDER BY position, id', id);
  ev.quotations = all('SELECT id, number, status, valid_until, created_at FROM quotations WHERE event_id = ? ORDER BY id DESC', id);
  return ev;
}

export function summarize(ev, settings, ctxBundle) {
  const { ctx } = ctxBundle || buildCtx();
  const per = (rid) => {
    const r = ctx.rec.get(rid);
    return r ? recipeCost(r, ctx).perPortion : 0;
  };
  return eventSummary(ev, settings, per);
}

export function eventPurchaseList(ev, opts) {
  const { ctx } = buildCtx();
  return purchaseList(ev, ctx, opts);
}
