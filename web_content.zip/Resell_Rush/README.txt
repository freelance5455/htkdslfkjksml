RESELL RUSH — ZERO-START EDITION

- Starts with $0.
- Story: age 16, working a part-time job to build reselling capital.
- Job shifts earn in-game money.
- Market, suppliers, buying, selling, inventory, XP and day cycle remain.

PLAY ON ANDROID: Extract this ZIP and open Resell_Rush/index.html in Chrome.
Progress is saved in browser storage; clearing browser data may erase saves.
Fictional simulator only; no real money is involved.
