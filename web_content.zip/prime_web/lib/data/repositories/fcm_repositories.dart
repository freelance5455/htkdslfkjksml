import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:prime_web/utils/api.dart';

class SetFcm {
  Future<String> getFcmToken() async {
    try {
      return (await FirebaseMessaging.instance.getToken()) ?? "";
    } catch (e) {
      return "";
    }
  }

  Future SetFcmRepo() async {
    try {
      await ApiCall.postapi(
        url: ApiCall.setFcm,
        useAuthtoken: false,
        body: {
          "fcm": await getFcmToken(),
        },
      );
    } catch (e) {}
  }
}
