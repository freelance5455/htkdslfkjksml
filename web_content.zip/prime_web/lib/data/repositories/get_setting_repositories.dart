import 'package:prime_web/data/model/get_setting_model.dart';
import 'package:prime_web/utils/api.dart';

class Getsetting {
  static Future<GetSettingModel> Getsettingrepo() async {
    try {
      final result = await ApiCall.getapi(
        url: ApiCall.getSystemSettings,
        useAuthToken: false,
      );

      final data = await result['data'];

      if (result['error'] == false) {
        return GetSettingModel.fromJson(data);
      }
    } catch (e) {}
    return GetSettingModel.fromJson({});
  }
}
