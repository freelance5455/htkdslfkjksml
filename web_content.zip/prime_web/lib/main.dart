import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const Royalx99App());
}

class Royalx99App extends StatelessWidget {
  const Royalx99App({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Royalx99',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFFD4AF37)),
        home: const Royalx99Page(),
      );
}

class Royalx99Page extends StatefulWidget {
  const Royalx99Page({super.key});

  @override
  State<Royalx99Page> createState() => _Royalx99PageState();
}

class _Royalx99PageState extends State<Royalx99Page> {
  InAppWebViewController? _web;
  bool _loading = true;

  Future<bool> _back() async {
    final web = _web;
    if (web != null && await web.canGoBack()) {
      await web.goBack();
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) => WillPopScope(
        onWillPop: _back,
        child: Scaffold(
          body: SafeArea(
            child: Stack(children: [
              InAppWebView(
                initialUrlRequest: URLRequest(url: WebUri('https://royalx99.com')),
                initialSettings: InAppWebViewSettings(
                  javaScriptEnabled: true,
                  domStorageEnabled: true,
                  thirdPartyCookiesEnabled: true,
                  allowsBackForwardNavigationGestures: true,
                  useShouldOverrideUrlLoading: true,
                ),
                onWebViewCreated: (controller) => _web = controller,
                onLoadStart: (_, __) { if (mounted) setState(() => _loading = true); },
                onLoadStop: (_, __) { if (mounted) setState(() => _loading = false); },
                onReceivedError: (_, __, ___) { if (mounted) setState(() => _loading = false); },
                shouldOverrideUrlLoading: (_, action) async {
                  final url = action.request.url;
                  if (url == null) return NavigationActionPolicy.CANCEL;
                  if (url.scheme == 'https' || url.scheme == 'http') {
                    return NavigationActionPolicy.ALLOW;
                  }
                  return NavigationActionPolicy.CANCEL;
                },
              ),
              if (_loading)
                const Center(child: CircularProgressIndicator()),
            ]),
          ),
        ),
      );
}
