import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:lottie/lottie.dart';
import 'package:prime_web/cubit/get_setting_cubit.dart';
import 'package:prime_web/main.dart';
import 'package:prime_web/provider/navigation_bar_provider.dart';
import 'package:prime_web/ui/widgets/admob_service.dart';
import 'package:prime_web/ui/widgets/load_web_view.dart';
import 'package:prime_web/utils/constants.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen(this.url,
      {super.key, this.mainPage = true, this.loadWebViewKey});

  final String url;
  final bool mainPage;
  final GlobalKey<LoadWebViewState>? loadWebViewKey;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with AutomaticKeepAliveClientMixin<HomeScreen>, TickerProviderStateMixin {
  @override
  bool get wantKeepAlive => true;
  BannerAd? _bannerAd;
  late AnimationController navigationContainerAnimationController =
      AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 500),
  );

  // Must be a field, not created inside build(), so the key stays stable
  // across rebuilds (e.g. when the keyboard opens and MediaQuery changes).
  // A new key every build causes LoadWebView to be disposed & recreated,
  // which reloads the page and triggers the PullToRefreshController error.
  late final GlobalKey<LoadWebViewState> _webViewKey;

  @override
  void initState() {
    super.initState();
    _bannerAd = AdMobService.createBannerAd()..load();
    _webViewKey = GlobalKey<LoadWebViewState>();
    if (!showBottomNavigationBar) {
      Future.delayed(Duration.zero, () {
        context
            .read<NavigationBarProvider>()
            .setAnimationController(navigationContainerAnimationController);
      });
    }
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    navigationContainerAnimationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final child = Scaffold(
      extendBody: false,
      bottomNavigationBar: displayAd(),
      body: LoadWebView(
          key: widget.loadWebViewKey ?? _webViewKey, url: widget.url),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: !showBottomNavigationBar
          ? FadeTransition(
              opacity: Tween<double>(begin: 1, end: 0).animate(
                CurvedAnimation(
                  parent: navigationContainerAnimationController,
                  curve: Curves.easeInOut,
                ),
              ),
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: Offset.zero,
                  end: const Offset(0, 1),
                ).animate(
                  CurvedAnimation(
                    parent: navigationContainerAnimationController,
                    curve: Curves.easeInOut,
                  ),
                ),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  child: FloatingActionButton(
                    child: Lottie.asset(
                      CustomIcons.settingsIcon(Theme.of(context).brightness),
                      height: 30,
                      repeat: true,
                    ),
                    onPressed: () =>
                        navigatorKey.currentState!.pushNamed('settings'),
                  ),
                ),
              ),
            )
          : !widget.mainPage
              ? Container(
                  padding: const EdgeInsets.all(10),
                  margin: const EdgeInsets.only(bottom: 60),
                  child: FloatingActionButton(
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 30,
                    ),
                    onPressed: () async {
                      if (mounted) {
                        context
                            .read<NavigationBarProvider>()
                            .animationController
                            .reverse();
                      }
                      await webPagePopNavigation(context);
                    },
                  ),
                )
              : null,
    );

    if (!widget.mainPage) {
      return PopScope(
        canPop: false,
        onPopInvokedWithResult: (didPop, result) async {
          if (didPop) return;
          await webPagePopNavigation(context);
        },
        child: child,
      );
    }
    return child;
  }

  Widget displayAd() {
    if (!context.read<GetSettingCubit>().showBannerAds()) {
      return const SizedBox.shrink();
    }

    if (_bannerAd == null) {
      return const SizedBox.shrink();
    }

    return SizedBox(
      height: 50,
      child: AdWidget(ad: _bannerAd!),
    );
  }

  webPagePopNavigation(BuildContext context) async {
    final state = (widget.loadWebViewKey ?? _webViewKey).currentState;
    if (state != null) {
      final shouldExit = await state.handleBack(context);
      if (shouldExit) {
        if (context.mounted) {
          Navigator.of(context).pop();
        }
      }
    } else {
      if (context.mounted) {
        Navigator.of(context).pop();
      }
    }
  }
}
