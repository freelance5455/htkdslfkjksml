import 'package:flutter/material.dart';

class AppScaffold extends StatefulWidget {
  final Widget body;
  final Widget? bottomNavigationBar;
  final PreferredSizeWidget? appBar;
  final Color? backgroundColor;

  const AppScaffold({
    super.key,
    required this.body,
    this.bottomNavigationBar,
    this.appBar,
    this.backgroundColor,
  });

  @override
  State<AppScaffold> createState() => _AppScaffoldState();
}

class _AppScaffoldState extends State<AppScaffold> {
  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.viewPaddingOf(context).bottom;
    final hasBottomNav = widget.bottomNavigationBar != null;
    return Scaffold(
      extendBody: true, // allow nav to float correctly
      extendBodyBehindAppBar: false,
      appBar: widget.appBar,
      body: Padding(
        padding: EdgeInsets.only(
          bottom: hasBottomNav
              ? kBottomNavigationBarHeight + bottomInset
              : bottomInset,
        ),
        child: widget.body,
      ),
      bottomNavigationBar: widget.bottomNavigationBar != null
          ? Padding(
              padding: EdgeInsets.only(bottom: bottomInset),
              child: widget.bottomNavigationBar,
            )
          : null,
    );
  }
}
