import 'dart:ui';

import 'package:flutter/material.dart';

class GlassmorphismContainer extends StatelessWidget {
  const GlassmorphismContainer({required this.child, super.key});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/icons/onboarding_bg.png'),
                fit: BoxFit.cover,
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              clipBehavior: Clip.none,
              children: [
                Positioned(
                  right: -120,
                  top: 40,
                  child: Image.asset('assets/icons/big_round.png'),
                ),
                Positioned(
                  left: -80,
                  bottom: 50,
                  child: Image.asset('assets/icons/small_round.png'),
                ),
              ],
            ),
          ),
          Align(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
              child: Container(
                width: double.maxFinite,
                height: double.maxFinite,
                decoration: BoxDecoration(
                  color: Theme.of(context).canvasColor,
                ),
                child: child,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
