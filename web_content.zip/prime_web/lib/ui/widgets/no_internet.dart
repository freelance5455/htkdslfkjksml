import 'dart:async';
import 'dart:developer';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/services.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

class NoInternet {
  static final Connectivity _connectivity = Connectivity();

  static StreamSubscription? connectivityStreamSubscription;
  static String _connectionStatus = 'Unknown';
  static Future<String> initConnectivity() async {
    var result = ConnectivityResult.none;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      result = (await _connectivity.checkConnectivity()).last;
    } on PlatformException {
      log('Exception : Failed to get connectivity.');
    }

    // If the widget was removed from the tree while the asynchronous platform
    // message was in flight, we want to discard the reply rather than calling
    // setState to update our non-existent appearance.

    // return Future.value(null);

    return updateConnectionStatus(result);
  }

  static Future<String> updateConnectionStatus(
    ConnectivityResult result,
  ) async {
    switch (result) {
      case ConnectivityResult.wifi:
      case ConnectivityResult.mobile:
      case ConnectivityResult.none:
        _connectionStatus = result.toString();
        return _connectionStatus;
      // ignore: no_default_cases
      default:
        _connectionStatus = 'Failed to get connectivity.';
        return _connectionStatus;
    }
  }

  static Future<bool> isUserOffline() async {
    final connectivityResult = await Connectivity().checkConnectivity();
    if (connectivityResult.contains(ConnectivityResult.none)) {
      return true;
    } else {
      final hasConnection = await InternetConnectionChecker().hasConnection;
      return !hasConnection;
    }
  }
}
