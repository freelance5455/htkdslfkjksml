@echo off
call gradlew.bat assembleDebug
echo ----------------------------------------------------
echo Build complete! Your APK is located at:
echo app\build\outputs\apk\debug\app-debug.apk
echo ----------------------------------------------------
pause
