@echo off
echo Abriendo proyecto Android de KuroDeck...
if not exist android\build.gradle (
  echo [ERROR] Extrae todo el archivo ZIP antes de ejecutar este script.
  pause
  exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle no esta en el PATH. Abre la carpeta "android" directamente en Android Studio
  echo y selecciona: Build ^> Build Bundle(s) / APK(s) ^> Build APK(s).
  pause
  exit /b 0
)
cd android
call gradle assembleDebug
if errorlevel 1 (
  echo [ERROR] Revisa que tengas el Android SDK configurado o compila desde Android Studio.
  pause
  exit /b 1
)
echo APK generado en android\app\build\outputs\apk\debug\app-debug.apk
pause
