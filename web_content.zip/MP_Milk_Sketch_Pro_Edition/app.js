// MP Milk - Sketch Pro Edition Logic

const REC_KEY = 'mp_milk_records_v3';
const SET_KEY = 'mp_milk_settings_v3';

let records = [];
let settings = {
    cowFatRate: 82, cowSnfRate: 42, cowFixRate: 45,
    bufFatRate: 85, bufSnfRate: 44, bufFixRate: 55.18,
    geminiKey: '', sheetUrl: '', appPin: '', reminder: '19:00'
};

let ocrBase64 = null;

window.addEventListener('DOMContentLoaded', () => {
    loadDatabase();

    // Default Dates
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('entryDate').value = today;
    document.getElementById('filterDate').value = today;
    document.getElementById('billingMonth').value = today.slice(0, 7);

    // Initial State Check
    if (settings.appPin && settings.appPin.length === 4) {
        document.getElementById('loginScreen').classList.remove('hidden');
    } else {
        document.getElementById('loginScreen').classList.add('hidden');
    }

    // Auto set animal based on time
    const hr = new Date().getHours();
    document.getElementById('animalType').value = hr >= 14 ? 'Buffalo' : 'Cow';

    updateUI();
    initReminder();
});

// Navigation & Sidebar
function navigate(viewId) {
    document.querySelectorAll('.view-section').forEach(v => v.classList.remove('active'));
    document.getElementById(viewId).classList.add('active');

    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    const nb = document.getElementById('nav-' + viewId);
    if (nb) nb.classList.add('active');

    if(viewId === 'viewHome') updateUI();
    if(viewId === 'viewReport') renderBillingCycles();
}

function openSidebar() {
    document.getElementById('sidebarOverlay').classList.add('active');
    document.getElementById('sidebarMenu').classList.add('active');
}
function closeSidebar() {
    document.getElementById('sidebarOverlay').classList.remove('active');
    document.getElementById('sidebarMenu').classList.remove('active');
}

function openModal(id) { document.getElementById(id).classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

// Login & Auth
function doLogin() {
    const p = document.getElementById('loginPass').value;
    if (p === settings.appPin || !settings.appPin) {
        document.getElementById('loginScreen').classList.add('hidden');
        document.getElementById('loginError').textContent = '';
    } else {
        document.getElementById('loginError').textContent = '❌ गलत पासवर्ड या PIN';
    }
}
function biometricAuth() {
    document.getElementById('loginScreen').classList.add('hidden');
}
function doLogout() {
    closeSidebar();
    document.getElementById('loginScreen').classList.remove('hidden');
    document.getElementById('loginPass').value = '';
}

// Data Handling & UI
function toggleHolidayMode() {
    const isHol = document.getElementById('isHoliday').checked;
    document.getElementById('entryFieldsBox').classList.toggle('hidden', isHol);
    if (isHol) document.getElementById('entryNote').value = 'आज नागा / छुट्टी';
}

function calcPreview(manualRat = false) {
    const litar = parseFloat(document.getElementById('inpLitar').value) || 0;
    const type = document.getElementById('animalType').value;
    const fat = parseFloat(document.getElementById('inpFat').value) || 0;
    const snf = parseFloat(document.getElementById('inpSnf').value) || 0;
    const mode = document.getElementById('rateMode').value;
    const ratEl = document.getElementById('inpRat');

    let rat = parseFloat(ratEl.value) || 0;

    if (!manualRat) {
        if (mode === 'manual') {
            rat = type === 'Cow' ? settings.cowFixRate : settings.bufFixRate;
        } else {
            const fRate = type === 'Cow' ? settings.cowFatRate : settings.bufFatRate;
            const sRate = type === 'Cow' ? settings.cowSnfRate : settings.bufSnfRate;
            if (fat > 0 || snf > 0) {
                rat = ((fat * (fRate / 10)) + (snf * (sRate / 10))) / 2;
            } else {
                rat = type === 'Cow' ? settings.cowFixRate : settings.bufFixRate;
            }
        }
        ratEl.value = rat.toFixed(2);
    }

    const prec = document.querySelector('input[name="prec"]:checked').value;
    const effLitar = prec === 'one' ? Math.floor(litar * 10) / 10 : litar;
    const total = effLitar * rat;

    document.getElementById('inpTotalAmt').textContent = '₹' + total.toFixed(2);
    return { litar: effLitar, fat, snf, rat, total };
}

function saveEntry() {
    const date = document.getElementById('entryDate').value;
    const type = document.getElementById('animalType').value;
    const isHol = document.getElementById('isHoliday').checked;
    const note = document.getElementById('entryNote').value.trim();
    const editId = document.getElementById('editEntryId').value;

    if (!date) return alert('तारीख चुनें!');

    let rec;
    if (isHol) {
        rec = { id: editId ? Number(editId) : Date.now(), date, type, isHoliday: true, litar: 0, fat: 0, snf: 0, rat: 0, total: 0, note: note || 'नागा' };
    } else {
        const c = calcPreview(true);
        if (c.litar <= 0) return alert('लिटर दर्ज करें!');
        rec = {
            id: editId ? Number(editId) : Date.now(),
            date, type, isHoliday: false,
            litar: Number(c.litar.toFixed(2)), fat: Number(c.fat.toFixed(1)),
            snf: Number(c.snf.toFixed(1)), rat: Number(c.rat.toFixed(2)),
            total: Number(c.total.toFixed(2)), note
        };
    }

    if (editId) {
        const idx = records.findIndex(r => r.id === Number(editId));
        if (idx > -1) records[idx] = rec;
    } else {
        records.unshift(rec);
    }

    records.sort((a, b) => b.date.localeCompare(a.date));
    localStorage.setItem(REC_KEY, JSON.stringify(records));

    if (settings.sheetUrl) {
        fetch(settings.sheetUrl, { method: 'POST', mode: 'no-cors', body: JSON.stringify(rec) }).catch(()=>{});
    }

    // Reset
    document.getElementById('inpLitar').value = '';
    document.getElementById('inpFat').value = '';
    document.getElementById('inpSnf').value = '';
    document.getElementById('entryNote').value = '';
    document.getElementById('editEntryId').value = '';
    document.getElementById('isHoliday').checked = false;
    document.getElementById('btnAddUpdate').textContent = 'Add +';
    toggleHolidayMode();
    calcPreview();
    updateUI();
}

function updateUI() {
    const today = document.getElementById('filterDate').value || new Date().toISOString().split('T')[0];
    const month = today.slice(0, 7);

    let dayL = 0, monthL = 0;
    
    // Calculate Stats
    records.forEach(r => {
        if (!r.isHoliday) {
            if (r.date === today) dayL += r.litar;
            if (r.date.startsWith(month)) monthL += r.litar;
        }
    });

    document.getElementById('statTodayMilk').textContent = dayL.toFixed(2) + ' L';
    document.getElementById('statTotalMilk').textContent = monthL.toFixed(2) + ' L';

    // Render Day View List
    const dayRecs = records.filter(r => r.date === today);
    const listEl = document.getElementById('hisabList');

    if (dayRecs.length === 0) {
        listEl.innerHTML = `<div style="padding:16px; text-align:center; color:#94a3b8;">कोई रिकॉर्ड नहीं</div>`;
        return;
    }

    listEl.innerHTML = dayRecs.map(r => {
        const animalName = r.type === 'Cow' ? 'Cow' : 'Bhaus';
        const badge = r.type === 'Cow' ? 'badge-cow' : 'badge-buf';
        
        if (r.isHoliday) {
            return `
            <div class="history-item">
                <div class="hi-left">
                    <span class="${badge}">${animalName}</span>
                    <strong style="margin-left:6px; color:#f59e0b;">🚩 छुट्टी</strong>
                    <div style="font-size:0.8rem; color:#94a3b8; margin-top:4px;">${r.note}</div>
                </div>
                <div class="hi-right hi-actions">
                    <button class="ico-btn" onclick="editRec(${r.id})">✏️</button>
                    <button class="ico-btn" onclick="delRec(${r.id})">🗑️</button>
                </div>
            </div>`;
        }

        return `
        <div class="history-item">
            <div class="hi-left">
                <div>
                    <span class="${badge}">${animalName}</span>
                    <strong style="margin-left:6px; font-size:1.05rem;">${r.litar.toFixed(2)} L</strong>
                </div>
                <div style="font-size:0.8rem; color:#94a3b8; margin-top:4px;">
                    Fat:${r.fat} | SNF:${r.snf} | Rat:₹${r.rat}
                    ${r.note ? `<br><span style="color:#38bdf8;">📌 ${r.note}</span>` : ''}
                </div>
            </div>
            <div class="hi-right">
                <strong style="color:#10b981; font-size:1.1rem;">₹${r.total.toFixed(2)}</strong>
                <div class="hi-actions">
                    <button class="ico-btn" onclick="shareSlip(${r.id})">🟢</button>
                    <button class="ico-btn" onclick="editRec(${r.id})">✏️</button>
                    <button class="ico-btn" onclick="delRec(${r.id})">🗑️</button>
                </div>
            </div>
        </div>`;
    }).join('');
}

function editRec(id) {
    const r = records.find(x => x.id === id);
    if (!r) return;
    document.getElementById('entryDate').value = r.date;
    document.getElementById('animalType').value = r.type;
    document.getElementById('isHoliday').checked = !!r.isHoliday;
    toggleHolidayMode();
    if (!r.isHoliday) {
        document.getElementById('inpLitar').value = r.litar;
        document.getElementById('inpFat').value = r.fat;
        document.getElementById('inpSnf').value = r.snf;
        document.getElementById('inpRat').value = r.rat;
    }
    document.getElementById('entryNote').value = r.note || '';
    document.getElementById('editEntryId').value = r.id;
    document.getElementById('btnAddUpdate').textContent = 'Update 🔄';
    window.scrollTo({top:0, behavior:'smooth'});
    calcPreview(true);
}

function delRec(id) {
    if (!confirm('क्या आप इसे हटाना चाहते हैं?')) return;
    records = records.filter(x => x.id !== id);
    localStorage.setItem(REC_KEY, JSON.stringify(records));
    updateUI();
}

// CLR Calc
function runClrMath() {
    const f = parseFloat(document.getElementById('calcFat').value) || 0;
    const c = parseFloat(document.getElementById('calcClr').value) || 0;
    const snf = (c / 4) + (0.21 * f) + 0.36;
    document.getElementById('calcSnfOut').textContent = snf.toFixed(2) + ' %';
    return { f, snf };
}
function applyClrSnf() {
    const r = runClrMath();
    closeModal('calcModal');
    document.getElementById('inpFat').value = r.f.toFixed(1);
    document.getElementById('inpSnf').value = r.snf.toFixed(1);
    calcPreview();
}

// AI Scanner
function previewOcrImg(e) {
    const f = e.target.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = ev => {
        ocrBase64 = ev.target.result;
        const im = document.getElementById('ocrPrevImg');
        im.src = ocrBase64;
        im.classList.remove('hidden');
        document.getElementById('ocrPrompt').textContent = '✅ फोटो तैयार है';
    };
    rd.readAsDataURL(f);
}

async function processOcrInput() {
    const txt = document.getElementById('ocrText').value.trim();
    if (txt) {
        const getNum = reg => { const m = txt.match(reg); return m ? parseFloat(m[1]) : 0; };
        const litar = getNum(/(?:milk|qty|ltr|दूध)[:\s-]*([0-9]+(?:\.[0-9]+)?)/i) || getNum(/([0-9]+(?:\.[0-9]+)?)\s*(?:l|ltr)/i);
        const fat = getNum(/fat[:\s-]*([0-9]+(?:\.[0-9]+)?)/i);
        const snf = getNum(/snf[:\s-]*([0-9]+(?:\.[0-9]+)?)/i);
        const rat = getNum(/rate[:\s-]*₹?([0-9]+(?:\.[0-9]+)?)/i);
        applyOcrData({ litar, fat, snf, rat });
        return;
    }
    
    if (ocrBase64 && settings.geminiKey) {
        document.getElementById('ocrStat').textContent = '🤖 Gemini AI पर्ची पढ़ रहा है...';
        try {
            const b64 = ocrBase64.split(',')[1];
            const mime = ocrBase64.substring(ocrBase64.indexOf(':') + 1, ocrBase64.indexOf(';'));
            const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${settings.geminiKey}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ contents: [{ parts: [{ text: 'Extract JSON: {"litar":num,"fat":num,"snf":num,"rat":num}' }, { inline_data: { mime_type: mime, data: b64 } }] }] })
            });
            const data = await res.json();
            const jsonText = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
            const match = jsonText.match(/\{[\s\S]*\}/);
            if (match) {
                applyOcrData(JSON.parse(match[0]));
                return;
            }
        } catch(e) { document.getElementById('ocrStat').textContent = '⚠️ API Error!'; return; }
    }
    document.getElementById('ocrStat').textContent = '⚠️ कृपया टेक्स्ट पेस्ट करें या API Key डालें!';
}
function applyOcrData(d) {
    closeModal('scannerModal');
    if (d.litar) document.getElementById('inpLitar').value = d.litar;
    if (d.fat) document.getElementById('inpFat').value = d.fat;
    if (d.snf) document.getElementById('inpSnf').value = d.snf;
    if (d.rat) document.getElementById('inpRat').value = d.rat;
    calcPreview(!!d.rat);
}

// Report & Cycle
function renderBillingCycles() {
    const m = document.getElementById('billingMonth').value;
    if (!m) return;
    const mRecs = records.filter(r => r.date.startsWith(m) && !r.isHoliday);
    const cycles = [
        { name: 'साइकिल 1 (1-10)', min: 1, max: 10, l: 0, rs: 0 },
        { name: 'साइकिल 2 (11-20)', min: 11, max: 20, l: 0, rs: 0 },
        { name: 'साइकिल 3 (21-End)', min: 21, max: 31, l: 0, rs: 0 }
    ];

    mRecs.forEach(r => {
        const d = parseInt(r.date.split('-')[2], 10);
        const c = cycles.find(x => d >= x.min && d <= x.max);
        if (c) { c.l += r.litar; c.rs += r.total; }
    });

    document.getElementById('cycleCardsContainer').innerHTML = cycles.map(c => `
        <div style="background:#0f172a; border:1px solid #334155; padding:12px; border-radius:10px;">
            <h4 style="color:#38bdf8; font-size:0.92rem; margin-bottom:6px;">${c.name}</h4>
            <div style="display:flex; justify-content:space-between; font-size:0.85rem; color:#f8fafc;">
                <span>दूध: <b>${c.l.toFixed(2)} L</b></span>
                <span style="color:#10b981;">रकम: <b>₹${c.rs.toFixed(2)}</b></span>
            </div>
        </div>
    `).join('');
}

// Exports
function shareSlip(id) {
    const r = records.find(x => x.id === id);
    if(!r) return;
    const msg = `*🥛 MP Milk पर्ची*%0A📅 Date: ${r.date}%0A🐄 Type: ${r.type}%0A💧 Litar: ${r.litar} L%0A🧈 Fat: ${r.fat}% | SNF: ${r.snf}%%0A💰 *Total: ₹${r.total.toFixed(2)}*`;
    window.open(`https://wa.me/?text=${msg}`, '_blank');
}
function shareWhatsAppReport() {
    const m = document.getElementById('billingMonth').value;
    window.open(`https://wa.me/?text=*📊 MP Milk Report (${m})*`, '_blank');
}
function exportCsvData() {
    const rows = ['Date,Type,Litar,Fat,SNF,Rat,Total,Note', ...records.map(r => `${r.date},${r.type},${r.litar},${r.fat},${r.snf},${r.rat},${r.total},${r.note}`)];
    const a = document.createElement('a');
    a.href = 'data:text/csv;charset=utf-8,' + encodeURI(rows.join('\n'));
    a.download = 'MP_Milk_Export.csv';
    a.click();
}
async function syncToGoogleSheet() {
    if(!settings.sheetUrl) return alert('Sheet URL डालें!');
    await fetch(settings.sheetUrl, { method:'POST', mode:'no-cors', body:JSON.stringify({bulkSync:true, records}) }).catch(()=>{});
    alert('सिंक पूरा हुआ!');
}
function downloadJsonBackup() {
    const blob = new Blob([JSON.stringify({ records, settings }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'MP_Milk_Backup.json'; a.click();
}
function restoreJsonBackup(e) {
    const rd = new FileReader();
    rd.onload = ev => {
        const d = JSON.parse(ev.target.result);
        if (d.records) { records = d.records; localStorage.setItem(REC_KEY, JSON.stringify(records)); }
        if (d.settings) { settings = { ...settings, ...d.settings }; localStorage.setItem(SET_KEY, JSON.stringify(settings)); }
        alert('रीस्टोर सफल!'); location.reload();
    };
    rd.readAsText(e.target.files[0]);
}

// Settings
function saveRateConfig() {
    settings.cowFatRate = parseFloat(document.getElementById('cfgCowFat').value)||82;
    settings.cowSnfRate = parseFloat(document.getElementById('cfgCowSnf').value)||42;
    settings.cowFixRate = parseFloat(document.getElementById('cfgCowFix').value)||45;
    settings.bufFatRate = parseFloat(document.getElementById('cfgBufFat').value)||85;
    settings.bufSnfRate = parseFloat(document.getElementById('cfgBufSnf').value)||44;
    settings.bufFixRate = parseFloat(document.getElementById('cfgBufFix').value)||55.18;
    localStorage.setItem(SET_KEY, JSON.stringify(settings));
    closeModal('rateModal'); calcPreview(); alert('रेट सेव हो गए!');
}
function saveGeneralSettings() {
    settings.sheetUrl = document.getElementById('cfgSheet').value.trim();
    settings.geminiKey = document.getElementById('cfgGeminiKey').value.trim();
    settings.appPin = document.getElementById('cfgAppPin').value.trim();
    settings.reminder = document.getElementById('cfgReminder').value;
    localStorage.setItem(SET_KEY, JSON.stringify(settings));
    closeModal('settingsModal'); alert('सेटिंग्स सेव हो गईं!');
}
function loadDatabase() {
    const s = localStorage.getItem(SET_KEY); if (s) { try { settings = { ...settings, ...JSON.parse(s) }; } catch(e){} }
    const r = localStorage.getItem(REC_KEY); if (r) { try { records = JSON.parse(r); } catch(e){} }

    document.getElementById('cfgCowFat').value = settings.cowFatRate; document.getElementById('cfgCowSnf').value = settings.cowSnfRate; document.getElementById('cfgCowFix').value = settings.cowFixRate;
    document.getElementById('cfgBufFat').value = settings.bufFatRate; document.getElementById('cfgBufSnf').value = settings.bufSnfRate; document.getElementById('cfgBufFix').value = settings.bufFixRate;
    
    document.getElementById('cfgSheet').value = settings.sheetUrl;
    document.getElementById('cfgGeminiKey').value = settings.geminiKey;
    document.getElementById('cfgAppPin').value = settings.appPin;
    document.getElementById('cfgReminder').value = settings.reminder;
}
function initReminder() {
    if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
    setInterval(() => {
        const now = new Date();
        if (now.toTimeString().slice(0, 5) === settings.reminder) {
            if ('Notification' in window && Notification.permission === 'granted') new Notification('MP Milk', { body: 'आज के दूध का हिसाब दर्ज करें!' });
        }
    }, 60000);
}
