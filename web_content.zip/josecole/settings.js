// Module 11 : Paramètres et espace personnel (dépend de window.JE, JO_STORES, appliquerPrefs, JOsha définis dans index.html)
(()=>{
const JE=window.JE,E=JE.esc;
const reg=async id=>(await JE.lire("reglages",id))||{id};
const maj=async(id,patch)=>JE.sauver("reglages",{...(await reg(id)),...patch,id});
const b2d=b=>new Promise((ok,ko)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=()=>ko(r.error);r.readAsDataURL(b);});
const NOMS={lecons:"Préparations de leçons",ressources:"Documents de la bibliothèque",evaluations:"Évaluations",classes:"Classes",eleves:"Élèves",epreuves:"Épreuves",notes:"Notes",presences:"Présences",horaires:"Créneaux d’horaire",activites:"Activités"};
const flag=v=>{try{v?localStorage.setItem("jo_verrou","1"):localStorage.removeItem("jo_verrou");}catch(e){}};
const alea=()=>[...crypto.getRandomValues(new Uint8Array(16))].map(x=>x.toString(16).padStart(2,"0")).join("");
const sel=(id,t,l,v)=>`<label for="${id}">${t}</label><select id="${id}">${l.map(x=>`<option value="${x[0]}"${x[0]===v?" selected":""}>${x[1]}</option>`).join("")}</select>`;

window.MOD=window.MOD||{};
window.MOD[11]=function(box){
  const{lc,go}=JE.ecran(box);
  const retour=`<button class="btn neutre" id="rt">Paramètres</button>`,fin=()=>{lc.querySelector("#rt").onclick=()=>go(menu);};
  const v=k=>lc.querySelector("#f_"+k).value.trim();

  async function menu(){
    const p2=await reg(2),p3=await reg(3);
    lc.innerHTML=`<div class="bloc2" style="white-space:normal"><b>${E(p2.enseignant||"Enseignant")}</b>${E([p2.etablissement,p3.pays,p2.annee].filter(Boolean).join(" · ")||"Profil à compléter")}<br>Profil : Enseignant · espace personnel sur cet appareil</div>
    ${[["profil","Profil et établissement","Nom, établissement, pays, système éducatif, disciplines"],["notifs","Notifications","Rappels avant les cours"],["prefs","Préférences d’affichage","Thème clair ou sombre, taille du texte"],
    ["sauve","Sauvegarde et restauration","Exporter ou restaurer toutes vos données"],["secu","Mot de passe de l’appareil","Verrouiller JosEcole"],["donnees","Mes données","Contenu stocké et suppression"]].map(x=>`<button class="item" data-s="${x[0]}"><b>${x[1]}</b><small>${x[2]}</small></button>`).join("")}
    <button class="item" data-m="5"><b>Mes classes</b><small>Se gèrent dans « Classes et élèves »</small></button>
    <div class="bloc2" style="white-space:normal"><b>Comptes en ligne</b>La création de compte, la synchronisation entre appareils et les profils Administrateur et Invité demandent le serveur sécurisé. Ils ne sont pas disponibles dans cette version : vos données restent sur ce téléphone.</div>`;
    const S={profil,notifs,prefs,sauve,secu,donnees};
    lc.querySelectorAll("[data-s]").forEach(b=>b.onclick=()=>go(S[b.dataset.s]));
  }

  async function profil(){
    const p2=await reg(2),p3=await reg(3);
    lc.innerHTML=retour+`<h3>Profil et établissement</h3>${JE.champ("enseignant","Nom de l’enseignant",p2.enseignant||"")}${JE.champ("etablissement","Établissement",p2.etablissement||"")}${JE.champ("annee","Année scolaire",p2.annee||JE.annee())}
    ${JE.champ("pays","Pays",p3.pays||"RD Congo","text",'list="lp"')}<datalist id="lp">${["RD Congo","République du Congo","Burundi","Rwanda","Cameroun","Côte d’Ivoire","Sénégal","France","Belgique"].map(x=>`<option value="${x}">`).join("")}</datalist>
    ${JE.champ("systeme","Système éducatif",p3.systeme||"Système éducatif congolais","text",'list="ls"')}<datalist id="ls"><option value="Système éducatif congolais"></datalist>
    ${JE.champ("disciplines","Disciplines enseignées (séparées par des virgules)",p3.disciplines||"")}
    <div class="rangee"><button class="btn or" id="ok">Enregistrer</button></div>`;fin();
    lc.querySelector("#ok").onclick=async()=>{await maj(2,{enseignant:v("enseignant"),etablissement:v("etablissement"),annee:v("annee")});
      await maj(3,{pays:v("pays"),systeme:v("systeme"),disciplines:v("disciplines")});go(menu);};
  }

  async function notifs(){
    const r=await reg(1);
    lc.innerHTML=retour+`<h3>Notifications</h3>${sel("rp","Rappel avant chaque cours",[[0,"Désactivé"],[5,"5 minutes avant"],[10,"10 minutes avant"],[15,"15 minutes avant"],[30,"30 minutes avant"]].map(o=>[String(o[0]),o[1]]),String(r.rappel||0))}
    <p style="color:var(--doux);font-size:14px">Les rappels ne sonnent que lorsque JosEcole est ouverte sur le téléphone.</p>`;fin();
    lc.querySelector("#rp").onchange=async e=>{const m=+e.target.value;await maj(1,{rappel:m});if(m&&"Notification"in window&&Notification.permission==="default")Notification.requestPermission();};
  }

  async function prefs(){
    const p=(await reg(3)).prefs||{};
    lc.innerHTML=retour+`<h3>Préférences d’affichage</h3>${sel("th","Thème",[["auto","Automatique (selon le téléphone)"],["light","Clair"],["dark","Sombre"]],p.theme||"auto")}${sel("tx","Taille du texte",[["normal","Normale"],["grand","Grande"]],p.texte||"normal")}`;fin();
    const sv=async()=>{await maj(3,{prefs:{theme:lc.querySelector("#th").value,texte:lc.querySelector("#tx").value}});window.appliquerPrefs();};
    lc.querySelector("#th").onchange=lc.querySelector("#tx").onchange=sv;
  }

  function sauve(){
    lc.innerHTML=retour+`<h3>Sauvegarde et restauration</h3><p>La sauvegarde est un fichier à conserver hors du téléphone (Drive, courriel, ordinateur). Faites-en une régulièrement.</p>
    <label style="display:flex;gap:10px;align-items:center"><input type="checkbox" id="dc" style="width:auto"> Inclure les fichiers de la bibliothèque (fichier plus volumineux)</label>
    <div class="rangee"><button class="btn or" id="ex">Exporter mes données</button></div>
    <h3>Restaurer</h3><p>Choisissez un fichier de sauvegarde JosEcole. Les données actuelles seront remplacées.</p><input type="file" id="rs" accept=".json,application/json">`;fin();
    lc.querySelector("#ex").onclick=async()=>{try{
      const out={app:"JosEcole",version:1,date:new Date().toISOString(),stores:{}},docs=lc.querySelector("#dc").checked;
      for(const s of window.JO_STORES){let l=await JE.tous(s);
        if(s==="ressources")l=await Promise.all(l.map(async r=>{const{fichier,...x}=r;return fichier&&docs?{...x,fichier:{data:await b2d(fichier),type:fichier.type}}:{...x,sansFichier:!!fichier};}));
        if(s==="reglages")l=l.map(x=>{const{mdp,...y}=x;return y;});
        out.stores[s]=l;}
      const u=URL.createObjectURL(new Blob([JSON.stringify(out)],{type:"application/json"})),a=document.createElement("a");
      a.href=u;a.download="josecole-sauvegarde-"+JE.today()+".json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),8000);
    }catch(e){alert("Exportation impossible : "+e.message);}};
    lc.querySelector("#rs").onchange=async e=>{const fi=e.target.files[0];if(!fi)return;let d;
      try{d=JSON.parse(await fi.text());}catch(x){return alert("Fichier illisible.");}
      if(!d||d.app!=="JosEcole"||!d.stores)return alert("Ce fichier n’est pas une sauvegarde JosEcole.");
      if(!confirm("Remplacer toutes les données actuelles par cette sauvegarde du "+new Date(d.date).toLocaleDateString("fr-FR")+" ? Cette action est définitive."))return;
      try{const r3=await reg(3),data={};
        for(const s of window.JO_STORES){let l=d.stores[s]||[];
          if(s==="ressources")l=await Promise.all(l.map(async r=>{if(r.fichier&&r.fichier.data){const b=await(await fetch(r.fichier.data)).blob();return{...r,fichier:new Blob([b],{type:r.fichier.type||b.type})};}return r;}));
          if(s==="reglages"){const n3={...(l.find(x=>x.id===3)||{id:3})};delete n3.mdp;if(r3.mdp)n3.mdp=r3.mdp;l=l.filter(x=>x.id!==3).concat([n3]);}
          data[s]=l;}
        await JE.tx(window.JO_STORES,"readwrite",t=>{window.JO_STORES.forEach(s=>{const o=t.objectStore(s);o.clear();data[s].forEach(x=>o.put(x));});});
        window.appliquerPrefs();alert("Restauration terminée.");go(menu);
      }catch(x){alert("Restauration impossible : "+x.message);}};
  }

  async function secu(){
    const r3=await reg(3),a=!!r3.mdp,pw=(k,t)=>`<label for="f_${k}">${t}</label><input id="f_${k}" type="password" autocomplete="${k==="ancien"?"current-password":"new-password"}">`;
    lc.innerHTML=retour+`<h3>Mot de passe de l’appareil</h3><p>Ce mot de passe bloque l’ouverture de JosEcole sur ce téléphone. Il ne chiffre pas les données et ne remplace pas un compte en ligne.</p>
    ${a?pw("ancien","Mot de passe actuel"):""}${pw("nouveau",a?"Nouveau mot de passe":"Mot de passe (4 caractères minimum)")}${pw("conf","Confirmer le mot de passe")}
    <div class="rangee"><button class="btn or" id="ok">${a?"Changer":"Activer"}</button>${a?'<button class="btn danger" id="sp">Retirer le mot de passe</button><button class="btn" id="vr">Verrouiller maintenant</button>':""}</div>`;fin();
    const verifie=async()=>a&&await window.JOsha(r3.mdp.sel+lc.querySelector("#f_ancien").value)!==r3.mdp.hash?(alert("Mot de passe actuel incorrect."),false):true;
    lc.querySelector("#ok").onclick=async()=>{if(!await verifie())return;const n=lc.querySelector("#f_nouveau").value;
      if(n.length<4)return alert("Le mot de passe doit contenir au moins 4 caractères.");if(n!==lc.querySelector("#f_conf").value)return alert("Les deux mots de passe ne sont pas identiques.");
      const sel=alea();await maj(3,{mdp:{sel,hash:await window.JOsha(sel+n)}});flag(true);alert("Mot de passe enregistré.");go(secu);};
    if(a){lc.querySelector("#sp").onclick=async()=>{if(!await verifie())return;const c=await reg(3);delete c.mdp;await JE.sauver("reglages",c);flag(false);go(secu);};
      lc.querySelector("#vr").onclick=()=>window.verrouiller();}
  }

  async function donnees(){
    const cnt={};for(const s of Object.keys(NOMS))cnt[s]=(await JE.tous(s)).length;
    let est="";try{const e=await navigator.storage.estimate();est=`Espace utilisé : ${(e.usage/1048576).toFixed(1).replace(".",",")} Mo`;}catch(x){}
    lc.innerHTML=retour+`<h3>Mes données</h3><div class="bloc2" style="white-space:normal">${Object.keys(NOMS).map(s=>`${NOMS[s]} : <b>${cnt[s]}</b>`).join("<br>")}${est?"<br>"+est:""}</div>
    <p>Toutes ces données sont stockées uniquement sur ce téléphone. Exportez une sauvegarde avant toute suppression.</p>
    <div class="rangee"><button class="btn" id="sv">Aller à la sauvegarde</button><button class="btn danger" id="del">Supprimer toutes mes données</button></div>
    <div class="bloc2" style="white-space:normal"><b>Suppression d’un compte en ligne</b>Aucun compte en ligne n’existe dans cette version. Quand le serveur sera ajouté, la demande de suppression du compte et des données associées sera proposée ici.</div>`;fin();
    lc.querySelector("#sv").onclick=()=>go(sauve);
    lc.querySelector("#del").onclick=async()=>{if(!confirm("Supprimer définitivement TOUTES les données de JosEcole sur ce téléphone ?"))return;
      if(!confirm("Dernière confirmation : cette action est irréversible."))return;
      await window.effacerTout();flag(false);window.appliquerPrefs();alert("Toutes les données ont été supprimées.");go(menu);};
  }
  menu();
};
})();
