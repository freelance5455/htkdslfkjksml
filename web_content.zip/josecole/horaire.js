// Module 6 : Horaire des cours (dépend de window.JE défini dans classes.js)
(()=>{
const JE=window.JE,E=JE.esc,PERSO="Horaire personnel";
const JOURS=["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"],TYPES=["Cours","Pause","Heure libre"];
const toMin=t=>{const[h,m]=(t||"0:0").split(":");return +h*60+ +m;};
const jourJS=d=>d.getDay()||7;

JE.toast=msg=>{const d=document.createElement("div");d.textContent=msg;
  d.style.cssText="position:fixed;left:12px;right:12px;bottom:calc(env(safe-area-inset-bottom,0px) + 14px);z-index:99;background:#0B2545;color:#fff;border:2px solid #C9A227;border-radius:12px;padding:14px 16px";
  d.onclick=()=>d.remove();document.body.appendChild(d);setTimeout(()=>d.remove(),15000);};

// Prochains cours de l'horaire personnel (utilisé par le tableau de bord)
JE.prochains=async n=>{
  const hs=(await JE.tous("horaires")).filter(h=>h.horaire===PERSO&&h.type==="Cours"),now=new Date(),out=[];
  for(let d=0;d<8;d++){const j=jourJS(new Date(now.getFullYear(),now.getMonth(),now.getDate()+d));
    hs.filter(h=>h.jour===j).sort((a,b)=>toMin(a.debut)-toMin(b.debut)).forEach(h=>{
      if(d===0&&toMin(h.fin)<=now.getHours()*60+now.getMinutes())return;out.push({d,j,h});});}
  return out.slice(0,n).map(({d,j,h})=>(d===0?"Aujourd’hui":d===1?"Demain":JOURS[j-1])+" · "+h.debut+"–"+h.fin+" · "+[h.discipline,h.classe].filter(Boolean).join(" · "));
};

// Horaire d'aujourd'hui (tableau de bord)
JE.horaireJour=async()=>{
  const tout=(await JE.tous("horaires")).filter(h=>h.horaire===PERSO),now=new Date(),mins=now.getHours()*60+now.getMinutes(),j=jourJS(now);
  return{total:tout.length,items:tout.filter(h=>h.jour===j).sort((a,b)=>toMin(a.debut)-toMin(b.debut)).map(h=>({...h,etat:toMin(h.fin)<=mins?"passe":toMin(h.debut)<=mins?"encours":"venir"}))};
};

// Rappels : actifs seulement lorsque l'application est ouverte
const vus=new Set();
function annonce(txt){
  if("Notification"in window&&Notification.permission==="granted"&&navigator.serviceWorker)
    navigator.serviceWorker.ready.then(r=>r.showNotification("JosEcole",{body:txt,icon:"icon.svg"})).catch(()=>JE.toast(txt));
  else JE.toast(txt);
}
async function verifier(){
  try{const r=await JE.lire("reglages",1),m=r?+r.rappel:0;if(!m)return;
    const now=new Date(),mins=now.getHours()*60+now.getMinutes(),j=jourJS(now);
    (await JE.tous("horaires")).filter(h=>h.horaire===PERSO&&h.type==="Cours"&&h.jour===j).forEach(h=>{
      const d=toMin(h.debut)-mins,k=JE.today()+"_"+h.id;
      if(d>=0&&d<=m&&!vus.has(k)){vus.add(k);annonce("Cours à "+h.debut+" : "+[h.discipline,h.classe,h.salle&&"salle "+h.salle].filter(Boolean).join(" · "));}});
  }catch(e){}
}
setInterval(verifier,30000);

window.MOD=window.MOD||{};
window.MOD[6]=function(box){
  const{lc,go}=JE.ecran(box);

  async function liste(){
    const hs=await JE.tous("horaires"),noms=[PERSO,...new Set(hs.map(h=>h.horaire).filter(n=>n!==PERSO))];
    const r=(await JE.lire("reglages",1))||{id:1,rappel:0};
    lc.innerHTML=`<h3>Mes horaires</h3>${noms.map(n=>`<button class="item" data-n="${E(n)}"><b>${E(n)}</b><small>${hs.filter(h=>h.horaire===n).length} créneau(x)</small></button>`).join("")}
    <button class="btn" id="nv" style="width:100%;margin-top:12px">Nouvel horaire (par exemple d’une classe)</button>
    <h3>Rappels</h3><label for="rp">Rappel avant chaque cours de l’horaire personnel</label>
    <select id="rp">${[[0,"Désactivé"],[5,"5 minutes avant"],[10,"10 minutes avant"],[15,"15 minutes avant"],[30,"30 minutes avant"]].map(o=>`<option value="${o[0]}"${+r.rappel===o[0]?" selected":""}>${o[1]}</option>`).join("")}</select>
    <p style="color:var(--doux);font-size:14px">Les rappels ne sonnent que lorsque JosEcole est ouverte sur le téléphone.</p>`;
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(horaire,b.dataset.n));
    lc.querySelector("#nv").onclick=()=>{const n=(prompt("Nom du nouvel horaire (ex. 3e Biochimie) :")||"").trim();if(n)go(horaire,n);};
    lc.querySelector("#rp").onchange=async e=>{const m=+e.target.value;await JE.sauver("reglages",{...r,id:1,rappel:m});
      if(m&&"Notification"in window&&Notification.permission==="default")Notification.requestPermission();};
  }

  async function horaire(nom,vue="Semaine",filtre=""){
    const hs=(await JE.tous("horaires")).filter(h=>h.horaire===nom);
    const chev=h=>hs.some(o=>o.id!==h.id&&o.jour===h.jour&&toMin(o.debut)<toMin(h.fin)&&toMin(o.fin)>toMin(h.debut));
    const ligne=h=>`<button class="item" data-id="${h.id}"><b>${h.debut}–${h.fin} · ${h.type==="Cours"?E(h.discipline||"Cours"):h.type}${chev(h)?'<span class="tag">Chevauchement</span>':""}</b><small>${E([h.classe,h.salle&&"Salle "+h.salle].filter(Boolean).join(" · "))}</small></button>`;
    const uniq=k=>[...new Set(hs.map(h=>h[k]).filter(Boolean))].sort();
    let data=hs,sel="";
    if(vue==="Jour"){filtre=filtre||String(jourJS(new Date()));data=hs.filter(h=>h.jour===+filtre);
      sel=`<select id="ft">${JOURS.map((j,i)=>`<option value="${i+1}"${+filtre===i+1?" selected":""}>${j}</option>`).join("")}</select>`;}
    if(vue==="Par classe"||vue==="Par discipline"){const k=vue==="Par classe"?"classe":"discipline",l=uniq(k);filtre=filtre||l[0]||"";data=hs.filter(h=>h[k]===filtre);
      sel=l.length?`<select id="ft">${l.map(x=>`<option${x===filtre?" selected":""}>${E(x)}</option>`).join("")}</select>`:"";}
    const corps=JOURS.map((j,i)=>{const it=data.filter(h=>h.jour===i+1).sort((a,b)=>toMin(a.debut)-toMin(b.debut));return it.length?`<h3>${j}</h3>`+it.map(ligne).join(""):"";}).join("");
    lc.innerHTML=`<button class="btn neutre" id="rt">Mes horaires</button><h3>${E(nom)}</h3>
    <label for="vu">Affichage</label><select id="vu">${["Semaine","Jour","Par classe","Par discipline"].map(v=>`<option${v===vue?" selected":""}>${v}</option>`).join("")}</select>${sel?`<label for="ft">Filtre</label>${sel}`:""}
    <div class="rangee"><button class="btn or" id="ad">Ajouter un créneau</button>${hs.length?'<button class="btn danger" id="vd">Supprimer cet horaire</button>':""}</div>
    ${corps||'<div class="vide"><p>Aucun créneau à afficher.</p></div>'}`;
    const $=s=>lc.querySelector(s);
    $("#rt").onclick=()=>go(liste);
    $("#vu").onchange=e=>go(horaire,nom,e.target.value);
    if($("#ft"))$("#ft").onchange=e=>go(horaire,nom,vue,e.target.value);
    $("#ad").onclick=()=>go(formulaire,nom,{horaire:nom,jour:jourJS(new Date()),type:"Cours",debut:"08:00",fin:"08:45",discipline:"",classe:"",salle:""});
    if($("#vd"))$("#vd").onclick=async()=>{if(confirm("Supprimer tous les créneaux de « "+nom+" » ?")){await JE.supprPlus("horaires",hs.map(h=>h.id));go(liste);}};
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(formulaire,nom,hs.find(h=>h.id===+b.dataset.id)));
  }

  async function formulaire(nom,h){
    const cl=await JE.tous("classes");
    const sel=(k,l)=>`<select id="f_${k}">${l.map(x=>{const v=Array.isArray(x)?x[0]:x,t=Array.isArray(x)?x[1]:x;return `<option value="${v}"${String(h[k])===String(v)?" selected":""}>${t}</option>`}).join("")}</select>`;
    lc.innerHTML=`<h3>${h.id?"Modifier le créneau":"Nouveau créneau"} · ${E(nom)}</h3>
    <label>Jour</label>${sel("jour",JOURS.map((j,i)=>[i+1,j]))}<label>Type</label>${sel("type",TYPES)}
    ${JE.champ("debut","Heure de début",h.debut,"time")}${JE.champ("fin","Heure de fin",h.fin,"time")}
    ${JE.champ("discipline","Discipline",h.discipline)}${JE.champ("classe","Classe",h.classe,"text",'list="dlc"')}<datalist id="dlc">${cl.map(c=>`<option value="${E(c.nom)}">`).join("")}</datalist>
    ${JE.champ("salle","Salle de cours (facultatif)",h.salle)}
    <div class="rangee"><button class="btn or" id="ok">Enregistrer</button><button class="btn neutre" id="an">Annuler</button>${h.id?'<button class="btn danger" id="su">Supprimer</button>':""}</div>`;
    const v=k=>lc.querySelector("#f_"+k).value.trim();
    lc.querySelector("#an").onclick=()=>go(horaire,nom);
    if(h.id)lc.querySelector("#su").onclick=async()=>{if(confirm("Supprimer ce créneau ?")){await JE.suppr("horaires",h.id);go(horaire,nom);}};
    lc.querySelector("#ok").onclick=async()=>{
      const o={...h,jour:+v("jour"),type:v("type"),debut:v("debut"),fin:v("fin"),discipline:v("discipline"),classe:v("classe"),salle:v("salle")};
      if(!o.debut||!o.fin||toMin(o.fin)<=toMin(o.debut))return alert("L’heure de fin doit être après l’heure de début.");
      const ch=(await JE.tous("horaires")).filter(x=>x.horaire===nom&&x.id!==o.id&&x.jour===o.jour&&toMin(x.debut)<toMin(o.fin)&&toMin(x.fin)>toMin(o.debut));
      if(ch.length&&!confirm("Ce créneau chevauche : "+ch.map(x=>x.debut+"–"+x.fin).join(", ")+". Enregistrer quand même ?"))return;
      await JE.sauver("horaires",o);go(horaire,nom);
    };
  }
  liste();
};
})();
