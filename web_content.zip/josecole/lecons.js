(()=>{
const INFOS=[["etablissement","Établissement"],["enseignant","Nom de l’enseignant"],["annee","Année scolaire"],["classe","Classe"],["discipline","Discipline"],["chapitre","Chapitre"],["sujet","Sujet de la leçon"],["date","Date","date"],["duree","Durée (ex. 45 min)"]];
const PLUS=[["prerequis","Prérequis"],["methodes","Méthodes pédagogiques"],["procedes","Procédés pédagogiques"],["materiel","Matériel didactique"],["references","Références bibliographiques"]];
const ETAPES=[["revision","1. Révision"],["motivation","2. Motivation"],["annonce","3. Annonce du sujet"],["objectif","4. Objectif opérationnel"],["analyse","5. Analyse"],["synthese","6. Synthèse"],["controle","7. Contrôle"],["devoir","8. Devoir"]];
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const tx=(mode,fn)=>window.bdP.then(db=>new Promise((ok,ko)=>{const t=db.transaction("lecons",mode);const r=fn(t.objectStore("lecons"));t.oncomplete=()=>ok(r&&r.result);t.onerror=()=>ko(t.error);}));
const tous=()=>tx("readonly",s=>s.getAll()),lire=id=>tx("readonly",s=>s.get(id)),sauver=o=>tx("readwrite",s=>s.put(o)),suppr=id=>tx("readwrite",s=>s.delete(id));
const aujourdhui=()=>new Date().toISOString().slice(0,10);
const annee=()=>{const d=new Date(),y=d.getFullYear();return d.getMonth()>=8?y+"-"+(y+1):(y-1)+"-"+y;};

const st=document.createElement("style");
st.textContent=`.lc{padding-bottom:30px}.lc h3{font:700 18px Georgia,serif;margin:18px 0 8px}
.lc label{display:block;font-size:14px;color:var(--doux);margin:10px 0 4px}
.lc input,.lc textarea{width:100%;padding:11px 12px;font:inherit;color:var(--texte);background:var(--surface);border:1px solid var(--bord);border-radius:10px}
.lc textarea{min-height:90px;resize:vertical}
.lc .btn{padding:12px 16px;border-radius:10px;border:0;font:inherit;font-weight:600;cursor:pointer;background:var(--marine);color:#fff;min-height:44px}
.lc .btn.or{background:var(--or);color:var(--marine)}.lc .btn.neutre{background:var(--gris);color:var(--texte)}.lc .btn.danger{background:transparent;color:#b3261e;border:1px solid #b3261e}
.lc .rangee{display:flex;gap:8px;flex-wrap:wrap;margin:14px 0}.lc .rangee .btn{flex:1 1 140px}
.lc .item{display:block;width:100%;text-align:left;padding:13px 14px;margin-top:8px;background:var(--surface);color:var(--texte);border:1px solid var(--bord);border-left:4px solid var(--or);border-radius:10px;font:inherit;cursor:pointer}
.lc .item small{display:block;color:var(--doux)}
.lc .bloc2{margin-top:12px;padding:12px 14px;background:var(--gris);border-radius:10px;white-space:pre-wrap}
.lc .bloc2 b{display:block;margin-bottom:4px;font-family:Georgia,serif}
#impr{display:none}
@media print{body.imprime>*:not(#impr){display:none!important}body.imprime #impr{display:block;color:#000;font:12pt/1.4 Georgia,serif;padding:0}
#impr h1{font-size:18pt;text-align:center;border-bottom:2px solid #0B2545;padding-bottom:6px}#impr table{width:100%;border-collapse:collapse;margin:10px 0}
#impr td,#impr th{border:1px solid #888;padding:5px 7px;vertical-align:top;text-align:left}#impr th{background:#e8edf5;width:28%}#impr td{white-space:pre-wrap}}`;
document.head.appendChild(st);
const imp=document.createElement("div");imp.id="impr";document.body.appendChild(imp);

function pdf(p){
  const ligne=(t,v)=>v?`<tr><th>${t}</th><td>${esc(v)}</td></tr>`:"";
  imp.innerHTML=`<h1>Préparation de leçon</h1><table>${INFOS.map(c=>ligne(c[1],p[c[0]])).join("")}${PLUS.map(c=>ligne(c[1],p[c[0]])).join("")}</table>
  <table>${ETAPES.map(c=>`<tr><th>${c[1]}</th><td>${esc(p[c[0]])||" "}</td></tr>`).join("")}</table>`;
  document.body.classList.add("imprime");
  const fin=()=>{document.body.classList.remove("imprime");removeEventListener("afterprint",fin);};
  addEventListener("afterprint",fin);print();
}

window.MOD=window.MOD||{};
window.MOD[1]=function(box){
  const lc=document.createElement("div");lc.className="lc";box.innerHTML="";box.appendChild(lc);
  const go=(f,...a)=>{scrollTo(0,0);f(...a);};

  async function liste(q=""){
    const tout=(await tous()).sort((a,b)=>(b.date||"").localeCompare(a.date||"")||b.id-a.id);
    const rech=q.trim().toLowerCase();
    const res=tout.filter(p=>!rech||[p.sujet,p.classe,p.discipline,p.chapitre].join(" ").toLowerCase().includes(rech));
    lc.innerHTML=`<button class="btn or" id="nv" style="width:100%">Nouvelle préparation</button>
    <label for="q">Rechercher</label><input id="q" type="search" placeholder="Sujet, classe, discipline…" value="${esc(q)}">
    <div id="res">${res.length?res.map(p=>`<button class="item" data-id="${p.id}"><b>${esc(p.sujet||"Sans titre")}</b><small>${esc([p.classe,p.discipline,p.date].filter(Boolean).join(" · "))}</small></button>`).join(""):
    `<div class="vide"><p>${tout.length?"Aucun résultat.":"Aucune préparation. Créez la première."}</p></div>`}</div>`;
    lc.querySelector("#nv").onclick=()=>go(formulaire);
    const qi=lc.querySelector("#q");qi.oninput=()=>{const pos=qi.value;liste(pos).then(()=>{const n=lc.querySelector("#q");n.focus();n.setSelectionRange(pos.length,pos.length);});};
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(voir,+b.dataset.id));
  }

  async function formulaire(p){
    if(!p){
      const der=(await tous()).sort((a,b)=>b.id-a.id)[0]||{};
      p={etablissement:der.etablissement||"",enseignant:der.enseignant||"",annee:der.annee||annee(),classe:der.classe||"",discipline:der.discipline||"",date:aujourdhui()};
    }
    const champ=c=>`<label for="f_${c[0]}">${c[1]}</label><input id="f_${c[0]}" type="${c[2]||"text"}" value="${esc(p[c[0]])}">`;
    const zone=c=>`<label for="f_${c[0]}">${c[1]}</label><textarea id="f_${c[0]}">${esc(p[c[0]])}</textarea>`;
    lc.innerHTML=`<h3>${p.id?"Modifier la préparation":"Nouvelle préparation"}</h3>${INFOS.map(champ).join("")}
    <h3>Démarche pédagogique</h3>${ETAPES.map(zone).join("")}
    <h3>Compléments</h3>${PLUS.map(zone).join("")}
    <div class="rangee"><button class="btn or" id="ok">Enregistrer</button><button class="btn neutre" id="ann">Annuler</button></div>`;
    lc.querySelector("#ann").onclick=()=>go(p.id?voir:liste,p.id);
    lc.querySelector("#ok").onclick=async()=>{
      const o={...p};[...INFOS,...ETAPES,...PLUS].forEach(c=>o[c[0]]=lc.querySelector("#f_"+c[0]).value.trim());
      if(!o.sujet){alert("Indiquez le sujet de la leçon.");lc.querySelector("#f_sujet").focus();return;}
      const id=await sauver(o);go(voir,p.id||id);
    };
  }

  async function voir(id){
    const p=await lire(id);if(!p)return liste();
    const bl=c=>p[c[0]]?`<div class="bloc2"><b>${c[1]}</b>${esc(p[c[0]])}</div>`:"";
    lc.innerHTML=`<button class="btn neutre" id="rt">Toutes les préparations</button>
    <h3>${esc(p.sujet)}</h3><div class="bloc2">${INFOS.filter(c=>c[0]!=="sujet"&&p[c[0]]).map(c=>`<b style="display:inline">${c[1]} :</b> ${esc(p[c[0]])}`).join("\n")}</div>
    ${ETAPES.map(bl).join("")}${PLUS.map(bl).join("")}
    <div class="rangee"><button class="btn" id="ed">Modifier</button><button class="btn" id="re">Réutiliser</button><button class="btn or" id="ex">Exporter en PDF</button><button class="btn danger" id="su">Supprimer</button></div>`;
    lc.querySelector("#rt").onclick=()=>go(liste);
    lc.querySelector("#ed").onclick=()=>go(formulaire,p);
    lc.querySelector("#re").onclick=()=>{const c={...p,date:aujourdhui()};delete c.id;go(formulaire,c);};
    lc.querySelector("#ex").onclick=()=>pdf(p);
    lc.querySelector("#su").onclick=async()=>{if(confirm("Supprimer cette préparation ? Cette action est définitive.")){await suppr(id);go(liste);}};
  }
  liste();
};
})();
