// Module 4 : Notes et résultats (dépend de window.JE défini dans classes.js)
(()=>{
const JE=window.JE,E=JE.esc,num=s=>parseFloat(String(s).replace(",","."));
window.MOD=window.MOD||{};
window.MOD[4]=function(box){
  const{lc,go}=JE.ecran(box);
  const eleves=async cid=>(await JE.tous("eleves")).filter(e=>e.classeId===cid).sort(JE.tri);

  async function classes(){
    const cl=(await JE.tous("classes")).sort((a,b)=>a.nom.localeCompare(b.nom,"fr"));
    lc.innerHTML=cl.length?`<h3>Choisir une classe</h3>${cl.map(c=>`<button class="item" data-id="${c.id}"><b>${E(c.nom)}</b><small>Notes sur ${c.base} · réussite dès ${c.seuil} %</small></button>`).join("")}`:
      '<div class="vide"><p>Aucune classe. Créez d’abord une classe et ses élèves dans « Classes et élèves ».</p></div>';
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(classe,+b.dataset.id));
  }

  async function classe(cid){
    const c=await JE.lire("classes",cid);if(!c)return classes();
    const ep=(await JE.tous("epreuves")).filter(e=>e.classeId===cid).sort((a,b)=>(b.date||"").localeCompare(a.date||"")||b.id-a.id);
    const nb=(await eleves(cid)).length,nt=(await JE.tous("notes")).filter(n=>n.classeId===cid);
    lc.innerHTML=`<button class="btn neutre" id="rt">Toutes les classes</button><h3>${E(c.nom)}</h3>
    <div class="rangee"><button class="btn or" id="ne">Nouvelle épreuve</button><button class="btn" id="rs">Résultats et classement</button></div>
    ${nb?"":'<div class="bloc2">Cette classe n’a pas encore d’élèves. Ajoutez-les dans « Classes et élèves ».</div>'}
    ${ep.map(e=>`<button class="item" data-id="${e.id}"><b>${E(e.intitule)}</b><small>${E([e.discipline,e.periode,e.date].filter(Boolean).join(" · "))}</small><small>Sur ${e.max} · coefficient ${e.coef} · ${nt.filter(n=>n.epreuveId===e.id).length}/${nb} note(s)</small></button>`).join("")||'<div class="vide"><p>Aucune épreuve. Créez-en une pour saisir des notes.</p></div>'}`;
    lc.querySelector("#rt").onclick=()=>go(classes);
    lc.querySelector("#ne").onclick=()=>go(formEpreuve,cid,{classeId:cid,intitule:"",discipline:(ep[0]||{}).discipline||"",periode:(ep[0]||{}).periode||"",date:JE.today(),max:c.base,coef:1});
    lc.querySelector("#rs").onclick=()=>go(resultats,cid);
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(saisie,+b.dataset.id));
  }

  function formEpreuve(cid,e){
    lc.innerHTML=`<h3>${e.id?"Modifier l’épreuve":"Nouvelle épreuve"}</h3>${JE.champ("intitule","Intitulé",e.intitule,"text",'placeholder="ex. Interrogation 1"')}${JE.champ("discipline","Discipline",e.discipline)}${JE.champ("periode","Période",e.periode,"text",'placeholder="ex. 1re période"')}${JE.champ("date","Date",e.date,"date")}${JE.champ("max","Note maximale",e.max,"number",'inputmode="decimal"')}${JE.champ("coef","Coefficient",e.coef,"number",'inputmode="decimal"')}
    <div class="rangee"><button class="btn or" id="ok">Enregistrer</button><button class="btn neutre" id="an">Annuler</button></div>`;
    const v=k=>lc.querySelector("#f_"+k).value.trim();
    lc.querySelector("#an").onclick=()=>go(e.id?saisie:classe,e.id||cid);
    lc.querySelector("#ok").onclick=async()=>{
      const max=num(v("max")),coef=num(v("coef"));
      if(!v("intitule"))return alert("Indiquez l’intitulé de l’épreuve.");
      if(!(max>0))return alert("La note maximale doit être supérieure à 0.");
      if(!(coef>0))return alert("Le coefficient doit être supérieur à 0.");
      const id=await JE.sauver("epreuves",{...e,intitule:v("intitule"),discipline:v("discipline"),periode:v("periode"),date:v("date"),max,coef});go(saisie,e.id||id);
    };
  }

  async function saisie(eid){
    const ep=await JE.lire("epreuves",eid);if(!ep)return classes();
    const els=await eleves(ep.classeId),m={};
    (await JE.tous("notes")).filter(n=>n.epreuveId===eid).forEach(n=>m[n.eleveId]=n);
    lc.innerHTML=`<button class="btn neutre" id="rt">Épreuves</button><h3>${E(ep.intitule)}</h3>
    <div class="bloc2">${E([ep.discipline,ep.periode,ep.date].filter(Boolean).join(" · "))}\nSur ${ep.max} · coefficient ${ep.coef}</div>
    ${els.map(e=>`<div class="ligne"><label for="n${e.id}" style="margin:0;color:inherit">${E(JE.nom(e))}</label><input id="n${e.id}" data-e="${e.id}" inputmode="decimal" value="${m[e.id]?String(m[e.id].valeur).replace(".",","):""}" placeholder="/${ep.max}"></div>`).join("")||'<div class="vide"><p>Aucun élève dans cette classe.</p></div>'}
    <div class="rangee"><button class="btn" id="ed">Modifier l’épreuve</button><button class="btn danger" id="su">Supprimer l’épreuve</button></div>`;
    lc.querySelector("#rt").onclick=()=>go(classe,ep.classeId);
    lc.querySelector("#ed").onclick=()=>go(formEpreuve,ep.classeId,ep);
    lc.querySelector("#su").onclick=async()=>{if(!confirm("Supprimer cette épreuve et toutes ses notes ?"))return;
      await JE.supprPlus("notes",Object.values(m).map(n=>n.id));await JE.suppr("epreuves",eid);go(classe,ep.classeId);};
    lc.onchange=async ev=>{const i=ev.target.closest("input[data-e]");if(!i)return;const k=+i.dataset.e,t=i.value.trim();
      if(!t){if(m[k]){await JE.suppr("notes",m[k].id);delete m[k];}return;}
      const x=num(t);if(isNaN(x)||x<0||x>ep.max){alert("Note invalide : entrez un nombre entre 0 et "+ep.max+".");i.value=m[k]?String(m[k].valeur).replace(".",","):"";return;}
      const n={...(m[k]||{classeId:ep.classeId,eleveId:k,epreuveId:eid}),valeur:x};n.id=await JE.sauver("notes",n);m[k]=n;};
  }

  async function resultats(cid,disc="",per=""){
    const c=await JE.lire("classes",cid),els=await eleves(cid);
    const tout=(await JE.tous("epreuves")).filter(e=>e.classeId===cid);
    const eps=tout.filter(e=>(!disc||e.discipline===disc)&&(!per||e.periode===per));
    const notes={};(await JE.tous("notes")).filter(n=>n.classeId===cid).forEach(n=>notes[n.eleveId+"_"+n.epreuveId]=n.valeur);
    const lignes=els.map(el=>{let s=0,w=0,tot=0,tm=0;
      eps.forEach(ep=>{const v=notes[el.id+"_"+ep.id];if(v!=null){s+=ep.coef*v/ep.max;w+=ep.coef;tot+=ep.coef*v;tm+=ep.coef*ep.max;}});
      const pct=w?s/w*100:null;return{el,pct,moy:pct==null?null:pct*c.base/100,tot,tm};});
    const ev=lignes.filter(l=>l.pct!=null).sort((a,b)=>b.pct-a.pct||JE.tri(a.el,b.el));
    ev.forEach((l,i)=>l.rang=i&&ev[i-1].pct===l.pct?ev[i-1].rang:i+1);
    const rang=ev.concat(lignes.filter(l=>l.pct==null));
    const n=ev.length,reus=ev.filter(l=>l.pct>=c.seuil).length;
    const stats=n?{moy:ev.reduce((s,l)=>s+l.moy,0)/n,max:ev[0].moy,min:ev[n-1].moy,reus:reus/n*100,echec:(n-reus)/n*100}:null;
    const uniq=k=>[...new Set(tout.map(e=>e[k]).filter(Boolean))].sort();
    const sel=(id,l,v,t)=>`<label for="${id}">${t}</label><select id="${id}"><option value="">Toutes</option>${l.map(x=>`<option${x===v?" selected":""}>${E(x)}</option>`).join("")}</select>`;
    const res=l=>l.pct==null?"Non évalué":l.pct>=c.seuil?"Réussite":"Échec";
    lc.innerHTML=`<button class="btn neutre" id="rt">${E(c.nom)}</button><h3>Résultats et classement</h3>
    ${sel("fd",uniq("discipline"),disc,"Discipline")}${sel("fp",uniq("periode"),per,"Période")}
    <div class="bloc2">${eps.length} épreuve(s) prise(s) en compte · moyenne sur ${c.base} · réussite dès ${c.seuil} %</div>
    ${stats?`<div class="bloc2"><b>Statistiques de la classe</b>Moyenne : ${JE.fmt(stats.moy)}/${c.base}\nMeilleure : ${JE.fmt(stats.max)} · Plus faible : ${JE.fmt(stats.min)}\nTaux de réussite : ${JE.fmt(stats.reus)} % (${reus}/${n})\nTaux d’échec : ${JE.fmt(stats.echec)} % (${n-reus}/${n})</div>
    <div class="rangee"><button class="btn or" id="pd">Exporter en PDF</button></div>`:'<div class="vide"><p>Aucune note saisie pour ce choix.</p></div>'}
    ${rang.map(l=>`<div class="ligne"><span><b>${l.rang?l.rang+".":"—"}</b> ${E(JE.nom(l.el))}${l.pct!=null&&l.pct<c.seuil?'<span class="tag">En difficulté</span>':""}</span><span>${l.pct==null?"—":JE.fmt(l.moy)+"/"+c.base+" · "+JE.fmt(l.pct,0)+" %"}</span></div>`).join("")}`;
    lc.querySelector("#rt").onclick=()=>go(classe,cid);
    lc.querySelector("#fd").onchange=e=>go(resultats,cid,e.target.value,per);
    lc.querySelector("#fp").onchange=e=>go(resultats,cid,disc,e.target.value);
    const pd=lc.querySelector("#pd");
    if(pd)pd.onclick=()=>JE.pdf(`<h1>Résultats et classement</h1><p class="meta" style="text-align:center">${E([c.nom,c.annee,disc,per].filter(Boolean).join(" · "))}</p>
      <table class="cl"><tr><th>Rang</th><th>Élève</th><th>Total pondéré</th><th>Pourcentage</th><th>Moyenne /${c.base}</th><th>Résultat</th></tr>
      ${rang.map(l=>`<tr><td>${l.rang||"—"}</td><td>${E(JE.nom(l.el))}</td><td>${l.pct==null?"—":JE.fmt(l.tot,2)+"/"+JE.fmt(l.tm,2)}</td><td>${l.pct==null?"—":JE.fmt(l.pct)+" %"}</td><td>${JE.fmt(l.moy)}</td><td>${res(l)}</td></tr>`).join("")}</table>
      <p>Moyenne de la classe : ${JE.fmt(stats.moy)}/${c.base} · Taux de réussite : ${JE.fmt(stats.reus)} % · Taux d’échec : ${JE.fmt(stats.echec)} %</p>`);
  }
  classes();
};
})();
