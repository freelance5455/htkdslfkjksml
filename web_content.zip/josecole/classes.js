// Module 5 : Classes, élèves, présences. Définit aussi les outils partagés window.JE (utilisés par notes.js)
(()=>{
const JE=window.JE=window.JE||{};
JE.esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
JE.tx=(st,mode,fn)=>window.bdP.then(db=>new Promise((ok,ko)=>{const t=db.transaction(st,mode);const r=fn(t);t.oncomplete=()=>ok(r&&r.result);t.onerror=()=>ko(t.error);}));
JE.tous=s=>JE.tx(s,"readonly",t=>t.objectStore(s).getAll());
JE.lire=(s,id)=>JE.tx(s,"readonly",t=>t.objectStore(s).get(id));
JE.sauver=(s,o)=>JE.tx(s,"readwrite",t=>t.objectStore(s).put(o));
JE.suppr=(s,id)=>JE.tx(s,"readwrite",t=>t.objectStore(s).delete(id));
JE.supprPlus=(s,ids)=>JE.tx(s,"readwrite",t=>{ids.forEach(i=>t.objectStore(s).delete(i));});
JE.purge=async cid=>{const p={};for(const s of["eleves","epreuves","notes","presences"])p[s]=(await JE.tous(s)).filter(x=>x.classeId===cid).map(x=>x.id);
  await JE.tx(["eleves","epreuves","notes","presences","classes"],"readwrite",t=>{for(const s in p)p[s].forEach(i=>t.objectStore(s).delete(i));t.objectStore("classes").delete(cid);});};
JE.nom=e=>[e.nom,e.postnom,e.prenom].filter(Boolean).join(" ");
JE.tri=(a,b)=>JE.nom(a).localeCompare(JE.nom(b),"fr");
JE.fmt=(n,d=1)=>n==null?"—":String(Math.round(n*10**d)/10**d).replace(".",",");
JE.today=()=>new Date().toISOString().slice(0,10);
JE.annee=()=>{const d=new Date(),y=d.getFullYear();return d.getMonth()>=8?y+"-"+(y+1):(y-1)+"-"+y;};
JE.ecran=box=>{const lc=document.createElement("div");lc.className="lc";box.innerHTML="";box.appendChild(lc);
  return{lc,go:(f,...a)=>{lc.oninput=lc.onchange=lc.onclick=null;scrollTo(0,0);f(...a);}};};
JE.pdf=html=>{const imp=document.getElementById("impr");imp.innerHTML=html;document.body.classList.add("imprime");
  const fin=()=>{document.body.classList.remove("imprime");removeEventListener("afterprint",fin);};addEventListener("afterprint",fin);print();};
JE.champ=(id,t,v,type="text",extra="")=>`<label for="f_${id}">${t}</label><input id="f_${id}" type="${type}" value="${JE.esc(v)}" ${extra}>`;
const st=document.createElement("style");
st.textContent=`.lc select{width:100%;padding:11px 12px;font:inherit;color:var(--texte);background:var(--surface);border:1px solid var(--bord);border-radius:10px}
.lc .ligne{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--bord)}
.lc .ligne select{width:auto;max-width:55%}.lc .ligne input{width:90px;text-align:right}
.lc .tag{font-size:12px;padding:2px 8px;border-radius:99px;background:#b3261e;color:#fff;margin-left:6px}
@media print{#impr table.cl th{width:auto}}`;
document.head.appendChild(st);

const E=JE.esc,STAT=["Présent","Absent","En retard","Absence justifiée","Absence non justifiée"];
window.MOD=window.MOD||{};
window.MOD[5]=function(box){
  const{lc,go}=JE.ecran(box);
  const eleves=async cid=>(await JE.tous("eleves")).filter(e=>e.classeId===cid).sort(JE.tri);

  async function liste(){
    const cl=(await JE.tous("classes")).sort((a,b)=>a.nom.localeCompare(b.nom,"fr")),el=await JE.tous("eleves");
    lc.innerHTML=`<button class="btn or" id="nv" style="width:100%">Nouvelle classe</button>
    ${cl.length?cl.map(c=>`<button class="item" data-id="${c.id}"><b>${E(c.nom)}</b><small>${el.filter(e=>e.classeId===c.id).length} élève(s)${c.annee?" · "+E(c.annee):""}</small></button>`).join(""):'<div class="vide"><p>Aucune classe. Créez votre première classe.</p></div>'}`;
    lc.querySelector("#nv").onclick=()=>go(formClasse);
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(classe,+b.dataset.id));
  }

  function formClasse(c){
    c=c||{nom:"",annee:JE.annee(),base:20,seuil:50};
    lc.innerHTML=`<h3>${c.id?"Modifier la classe":"Nouvelle classe"}</h3>${JE.champ("nom","Nom de la classe",c.nom,"text",'placeholder="ex. 3e Biochimie"')}${JE.champ("annee","Année scolaire",c.annee)}
    <h3>Règles de calcul</h3>${JE.champ("base","Notes sur (base de notation)",c.base,"number",'inputmode="decimal" min="1"')}${JE.champ("seuil","Seuil de réussite (%)",c.seuil,"number",'min="0" max="100"')}
    <div class="rangee"><button class="btn or" id="ok">Enregistrer</button><button class="btn neutre" id="an">Annuler</button></div>`;
    const v=k=>lc.querySelector("#f_"+k).value.trim();
    lc.querySelector("#an").onclick=()=>go(c.id?classe:liste,c.id);
    lc.querySelector("#ok").onclick=async()=>{
      const base=parseFloat(v("base").replace(",",".")),seuil=parseFloat(v("seuil").replace(",","."));
      if(!v("nom"))return alert("Indiquez le nom de la classe.");
      if(!(base>0))return alert("La base de notation doit être supérieure à 0.");
      if(!(seuil>=0&&seuil<=100))return alert("Le seuil doit être compris entre 0 et 100.");
      const id=await JE.sauver("classes",{...c,nom:v("nom"),annee:v("annee"),base,seuil});go(classe,c.id||id);
    };
  }

  async function classe(id,q=""){
    const c=await JE.lire("classes",id);if(!c)return liste();
    const els=await eleves(id),r=q.trim().toLowerCase();
    const res=els.filter(e=>!r||(JE.nom(e)+" "+(e.matricule||"")).toLowerCase().includes(r));
    lc.innerHTML=`<button class="btn neutre" id="rt">Toutes les classes</button><h3>${E(c.nom)}</h3>
    <div class="bloc2">${els.length} élève(s) · notes sur ${c.base} · réussite dès ${c.seuil} %</div>
    <div class="rangee"><button class="btn or" id="pr">Présences</button><button class="btn" id="rp">Rapport de présences</button></div>
    <div class="rangee"><button class="btn" id="ae">Ajouter un élève</button><button class="btn" id="im">Importer une liste</button><button class="btn neutre" id="mc">Modifier la classe</button><button class="btn danger" id="sc">Supprimer la classe</button></div>
    <label for="q">Rechercher un élève</label><input id="q" type="search" value="${E(q)}">
    ${res.map(e=>`<button class="item" data-e="${e.id}"><b>${els.indexOf(e)+1}. ${E(JE.nom(e))}</b><small>${E([e.matricule&&"Matricule "+e.matricule,e.info].filter(Boolean).join(" · "))}</small></button>`).join("")}`;
    const $=s=>lc.querySelector(s);
    $("#rt").onclick=()=>go(liste);$("#pr").onclick=()=>go(presences,id);$("#rp").onclick=()=>go(rapport,id);
    $("#ae").onclick=()=>go(formEleve,id);$("#im").onclick=()=>go(importer,id);$("#mc").onclick=()=>go(formClasse,c);
    $("#sc").onclick=async()=>{if(confirm("Supprimer cette classe avec ses élèves, notes et présences ? Cette action est définitive.")){await JE.purge(id);go(liste);}};
    $("#q").oninput=e=>{const v=e.target.value;classe(id,v).then(()=>{const n=$("#q");n.focus();n.setSelectionRange(v.length,v.length);});};
    lc.querySelectorAll(".item").forEach(b=>b.onclick=async()=>go(formEleve,id,await JE.lire("eleves",+b.dataset.e)));
  }

  function formEleve(cid,e){
    e=e||{classeId:cid,nom:"",postnom:"",prenom:"",matricule:"",info:""};
    lc.innerHTML=`<h3>${e.id?"Modifier l’élève":"Nouvel élève"}</h3>${JE.champ("nom","Nom",e.nom)}${JE.champ("postnom","Postnom",e.postnom)}${JE.champ("prenom","Prénom",e.prenom)}${JE.champ("matricule","Matricule",e.matricule)}${JE.champ("info","Autres informations",e.info)}
    <div class="rangee"><button class="btn or" id="ok">Enregistrer</button><button class="btn neutre" id="an">Annuler</button>${e.id?'<button class="btn danger" id="su">Supprimer</button>':""}</div>`;
    const v=k=>lc.querySelector("#f_"+k).value.trim();
    lc.querySelector("#an").onclick=()=>go(classe,cid);
    lc.querySelector("#ok").onclick=async()=>{if(!v("nom")&&!v("prenom"))return alert("Indiquez au moins le nom ou le prénom.");
      await JE.sauver("eleves",{...e,nom:v("nom"),postnom:v("postnom"),prenom:v("prenom"),matricule:v("matricule"),info:v("info")});go(classe,cid);};
    if(e.id)lc.querySelector("#su").onclick=async()=>{if(!confirm("Supprimer cet élève, ses notes et ses présences ?"))return;
      const ns=(await JE.tous("notes")).filter(n=>n.eleveId===e.id).map(n=>n.id),ps=(await JE.tous("presences")).filter(p=>p.eleveId===e.id).map(p=>p.id);
      await JE.supprPlus("notes",ns);await JE.supprPlus("presences",ps);await JE.suppr("eleves",e.id);go(classe,cid);};
  }

  function importer(cid){
    lc.innerHTML=`<h3>Importer une liste</h3><p>Un élève par ligne : Nom Postnom Prénom (avec deux mots : Nom Prénom).</p>
    <textarea id="t" style="min-height:200px" placeholder="KABONGO MUKENDI Joseph"></textarea>
    <div class="rangee"><button class="btn or" id="ok">Importer</button><button class="btn neutre" id="an">Annuler</button></div>`;
    lc.querySelector("#an").onclick=()=>go(classe,cid);
    lc.querySelector("#ok").onclick=async()=>{
      const l=lc.querySelector("#t").value.split("\n").map(s=>s.trim().split(/\s+/).filter(Boolean)).filter(a=>a.length);
      if(!l.length)return alert("Collez d’abord la liste.");
      for(const a of l){const[n,p,q]=a.length>=3?[a[0],a[1],a.slice(2).join(" ")]:[a[0],"",a[1]||""];
        await JE.sauver("eleves",{classeId:cid,nom:n,postnom:p,prenom:q,matricule:"",info:""});}
      go(classe,cid);};
  }

  async function presences(cid,date=JE.today()){
    const c=await JE.lire("classes",cid),els=await eleves(cid),m={};
    (await JE.tous("presences")).filter(p=>p.classeId===cid&&p.date===date).forEach(p=>m[p.eleveId]=p);
    const enreg=async(eid,s)=>{let p=m[eid];if(!s){if(p){await JE.suppr("presences",p.id);delete m[eid];}return;}
      p={...(p||{classeId:cid,eleveId:eid,date}),statut:s};p.id=await JE.sauver("presences",p);m[eid]=p;};
    lc.innerHTML=`<button class="btn neutre" id="rt">${E(c.nom)}</button><h3>Présences</h3>${JE.champ("d","Date",date,"date")}
    <div class="rangee"><button class="btn" id="tp">Marquer tout le monde présent</button></div>
    ${els.length?els.map(e=>`<div class="ligne"><span>${E(JE.nom(e))}</span><select data-e="${e.id}"><option value="">Non renseigné</option>${STAT.map(s=>`<option${m[e.id]&&m[e.id].statut===s?" selected":""}>${s}</option>`).join("")}</select></div>`).join(""):'<div class="vide"><p>Ajoutez d’abord des élèves.</p></div>'}`;
    lc.querySelector("#rt").onclick=()=>go(classe,cid);
    lc.querySelector("#f_d").onchange=e=>{if(e.target.value)go(presences,cid,e.target.value);};
    lc.querySelector("#tp").onclick=async()=>{for(const e of els)if(!m[e.id])await enreg(e.id,"Présent");go(presences,cid,date);};
    lc.onchange=ev=>{const s=ev.target.closest("select[data-e]");if(s)enreg(+s.dataset.e,s.value);};
  }

  async function rapport(cid){
    const c=await JE.lire("classes",cid),els=await eleves(cid),ps=(await JE.tous("presences")).filter(p=>p.classeId===cid);
    const dates=[...new Set(ps.map(p=>p.date))].sort().reverse();
    const cpt=e=>STAT.map(s=>ps.filter(p=>p.eleveId===e.id&&p.statut===s).length);
    lc.innerHTML=`<button class="btn neutre" id="rt">${E(c.nom)}</button><h3>Rapport de présences</h3><div class="bloc2">${dates.length} jour(s) enregistré(s)</div>
    <div class="rangee"><button class="btn or" id="pd">Exporter en PDF</button></div>
    ${els.map(e=>{const n=cpt(e);return `<div class="bloc2" style="white-space:normal"><b>${E(JE.nom(e))}</b>${STAT.map((s,i)=>s+" : "+n[i]).join(" · ")}</div>`}).join("")}
    <h3>Historique</h3>${dates.map(d=>`<button class="item" data-d="${d}">${d} <small>${ps.filter(p=>p.date===d).length} élève(s) renseigné(s)</small></button>`).join("")||"<p>Aucune présence enregistrée.</p>"}`;
    lc.querySelector("#rt").onclick=()=>go(classe,cid);
    lc.querySelector("#pd").onclick=()=>JE.pdf(`<h1>Rapport de présences</h1><p class="meta" style="text-align:center">${E(c.nom)} · ${E(c.annee||"")} · ${dates.length} jour(s)</p>
      <table class="cl"><tr><th>N°</th><th>Élève</th>${STAT.map(s=>`<th>${s}</th>`).join("")}</tr>${els.map((e,i)=>`<tr><td>${i+1}</td><td>${E(JE.nom(e))}</td>${cpt(e).map(n=>`<td>${n}</td>`).join("")}</tr>`).join("")}</table>`);
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(presences,cid,b.dataset.d));
  }
  liste();
};
})();
