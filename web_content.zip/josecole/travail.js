// Module 7 : Organisation du travail (dépend de window.JE défini dans classes.js)
(()=>{
const JE=window.JE,E=JE.esc;
const TYPES=["Leçon programmée","Évaluation planifiée","Devoir","Journal de classe","Rappel","Événement scolaire"];
const VUES=["À venir","Journal de classe","Calendrier","Progression","Historique"];
const mois=d=>new Date(d+"T00:00").toLocaleDateString("fr-FR",{month:"long",year:"numeric"});
window.MOD=window.MOD||{};
window.MOD[7]=function(box){
  const{lc,go}=JE.ecran(box);
  async function accueil(vue="À venir"){
    const tout=await JE.tous("activites"),aj=JE.today(),par=(a,b)=>(a.date||"9999").localeCompare(b.date||"9999");
    const ligne=a=>`<button class="item" data-id="${a.id}"><b>${a.statut==="Fait"?"✔ ":""}${E(a.titre)}</b><small>${E([a.type,a.date,a.classe,a.discipline].filter(Boolean).join(" · "))}</small>${a.details?`<small>${E(a.details.slice(0,90))}</small>`:""}</button>`;
    const vide=t=>`<div class="vide"><p>${t}</p></div>`;
    let corps="";
    if(vue==="À venir"){
      const nf=tout.filter(a=>a.statut!=="Fait"&&a.type!=="Journal de classe"),re=nf.filter(a=>a.date&&a.date<aj).sort(par),av=nf.filter(a=>!a.date||a.date>=aj).sort(par);
      corps=(re.length?"<h3>En retard</h3>"+re.map(ligne).join(""):"")+"<h3>À venir</h3>"+(av.map(ligne).join("")||vide("Rien de prévu."));
    }else if(vue==="Journal de classe"){
      const j=tout.filter(a=>a.type==="Journal de classe").sort((a,b)=>par(b,a));corps=j.map(ligne).join("")||vide("Le journal de classe est vide.");
    }else if(vue==="Calendrier"){
      const c=tout.filter(a=>a.date&&a.date>=aj).sort(par);let m="";
      corps=c.map(a=>{const h=mois(a.date)!==m?(m=mois(a.date),`<h3>${E(m)}</h3>`):"";return h+ligne(a);}).join("")||vide("Aucune date à venir.");
    }else if(vue==="Progression"){
      const g={};tout.filter(a=>a.type==="Leçon programmée").forEach(a=>{const k=[a.classe||"Sans classe",a.discipline].filter(Boolean).join(" · ");(g[k]=g[k]||[]).push(a);});
      corps=Object.keys(g).sort().map(k=>{const f=g[k].filter(a=>a.statut==="Fait").length,t=g[k].length,p=Math.round(f/t*100);
        return `<div class="bloc2" style="white-space:normal"><b>${E(k)}</b>${f} leçon(s) donnée(s) sur ${t} programmée(s) · ${p} %<div style="height:8px;margin-top:8px;background:var(--bord);border-radius:6px"><div style="width:${p}%;height:8px;background:var(--or);border-radius:6px"></div></div></div>`;}).join("")||vide("Programmez des leçons (type « Leçon programmée ») pour suivre la progression.");
    }else{
      corps=tout.filter(a=>a.statut==="Fait").sort((a,b)=>par(b,a)).map(ligne).join("")||vide("Aucune activité réalisée pour le moment.");
    }
    lc.innerHTML=`<button class="btn or" id="nv" style="width:100%">Nouvelle activité</button>
    <label for="vu">Afficher</label><select id="vu">${VUES.map(v=>`<option${v===vue?" selected":""}>${v}</option>`).join("")}</select>${corps}`;
    lc.querySelector("#vu").onchange=e=>go(accueil,e.target.value);
    lc.querySelector("#nv").onclick=()=>go(formulaire,vue,{type:vue==="Journal de classe"?"Journal de classe":vue==="Progression"?"Leçon programmée":"Devoir",titre:"",date:aj,classe:"",discipline:"",details:"",statut:vue==="Journal de classe"?"Fait":"À faire"});
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(formulaire,vue,tout.find(a=>a.id===+b.dataset.id)));
  }
  async function formulaire(vue,a){
    const cl=await JE.tous("classes");
    const sel=(k,l)=>`<select id="f_${k}">${l.map(x=>`<option${x===a[k]?" selected":""}>${x}</option>`).join("")}</select>`;
    lc.innerHTML=`<h3>${a.id?"Modifier l’activité":"Nouvelle activité"}</h3><label>Type</label>${sel("type",TYPES)}
    ${JE.champ("titre","Titre (leçon, devoir, rappel…)",a.titre)}${JE.champ("date","Date",a.date,"date")}
    ${JE.champ("classe","Classe",a.classe,"text",'list="dlc"')}<datalist id="dlc">${cl.map(c=>`<option value="${E(c.nom)}">`).join("")}</datalist>${JE.champ("discipline","Discipline",a.discipline)}
    <label for="f_details">Détails, remarques</label><textarea id="f_details">${E(a.details)}</textarea><label>Statut</label>${sel("statut",["À faire","Fait"])}
    <div class="rangee"><button class="btn or" id="ok">Enregistrer</button>${a.id&&a.statut!=="Fait"?'<button class="btn" id="fa">Marquer comme fait</button>':""}<button class="btn neutre" id="an">Annuler</button>${a.id?'<button class="btn danger" id="su">Supprimer</button>':""}</div>`;
    const v=k=>lc.querySelector("#f_"+k).value.trim(),lire=()=>({...a,type:v("type"),titre:v("titre"),date:v("date"),classe:v("classe"),discipline:v("discipline"),details:v("details"),statut:v("statut")});
    lc.querySelector("#an").onclick=()=>go(accueil,vue);
    lc.querySelector("#ok").onclick=async()=>{const o=lire();if(!o.titre)return alert("Indiquez un titre.");await JE.sauver("activites",o);go(accueil,vue);};
    if(a.id&&a.statut!=="Fait")lc.querySelector("#fa").onclick=async()=>{const o=lire();if(!o.titre)return alert("Indiquez un titre.");o.statut="Fait";await JE.sauver("activites",o);go(accueil,vue);};
    if(a.id)lc.querySelector("#su").onclick=async()=>{if(confirm("Supprimer cette activité ?")){await JE.suppr("activites",a.id);go(accueil,vue);}};
  }
  accueil();
};
})();
