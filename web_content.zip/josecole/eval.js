// Module 3 : Évaluations et examens (réutilise les styles .lc et #impr de lecons.js)
(()=>{
const TQ=[["ouverte","Question ouverte"],["qcm","QCM"],["vf","Vrai ou faux"],["courte","Réponse courte"],["dictee","Dictée"],["tp","Travail pratique"]];
const TE=["Interrogation écrite","Exercices","Examen","Dictée","Travail pratique"];
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const L=s=>esc(s).replace(/\n/g,"<br>");
const tx=(mode,fn)=>window.bdP.then(db=>new Promise((ok,ko)=>{const t=db.transaction("evaluations",mode);const r=fn(t.objectStore("evaluations"));t.oncomplete=()=>ok(r&&r.result);t.onerror=()=>ko(t.error);}));
const tous=()=>tx("readonly",s=>s.getAll()),lire=id=>tx("readonly",s=>s.get(id)),sauver=o=>tx("readwrite",s=>s.put(o)),suppr=id=>tx("readwrite",s=>s.delete(id));
const pts=q=>parseFloat(String(q.points).replace(",","."))||0;
const total=e=>e.questions.reduce((s,q)=>s+pts(q),0);
const fmt=n=>String(Math.round(n*100)/100).replace(".",",");
const aujourdhui=()=>(()=>{const d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");})();
const choix=q=>(q.options||"").split("\n").map(s=>s.trim()).filter(Boolean);

const st=document.createElement("style");
st.textContent=`.lc select{width:100%;padding:11px 12px;font:inherit;color:var(--texte);background:var(--surface);border:1px solid var(--bord);border-radius:10px}
.lc .qc{margin-top:14px;padding:12px;border:1px solid var(--bord);border-left:4px solid var(--ciel);border-radius:10px;background:var(--surface)}
.lc .qh{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}.lc .qh button{width:40px;height:40px;margin-left:4px;border:1px solid var(--bord);border-radius:8px;background:var(--gris);color:var(--texte);font-size:16px;cursor:pointer}
.lc .tot{position:sticky;bottom:0;padding:10px 14px;background:var(--marine);color:#fff;border-radius:10px;margin-top:14px;font-weight:600}
@media print{#impr .q{margin:12px 0;break-inside:avoid}#impr .opt{margin:3px 0 0 18px}#impr .ln{border-bottom:1px solid #777;height:24px}#impr .cor{margin-top:6px;padding:5px 8px;background:#eef3fa;border-left:3px solid #C9A227}#impr .meta{text-align:center}#impr .cs{border:1px solid #888;padding:6px 8px;margin:8px 0}}`;
document.head.appendChild(st);

function pdf(e,corrige){
  const imp=document.getElementById("impr");
  const lignes={ouverte:4,courte:1,dictee:6,tp:4,qcm:0,vf:0};
  const qs=e.questions.map((q,i)=>{
    let h=`<div class="q"><b>Question ${i+1} (${fmt(pts(q))} point${pts(q)>1?"s":""})</b><br>${L(q.enonce)}`;
    if(q.type==="qcm")h+=choix(q).map((o,j)=>`<div class="opt">${corrige&&String(q.bonne)===String(j)?"☑":"☐"} ${String.fromCharCode(65+j)}. ${esc(o)}</div>`).join("");
    else if(q.type==="vf")h+=`<div class="opt">${corrige&&q.bonne==="Vrai"?"☑":"☐"} Vrai &nbsp;&nbsp; ${corrige&&q.bonne==="Faux"?"☑":"☐"} Faux</div>`;
    else if(!corrige)h+='<div class="ln"></div>'.repeat(lignes[q.type]||3);
    if(corrige&&q.corrige)h+=`<div class="cor"><i>Corrigé :</i> ${L(q.corrige)}</div>`;
    return h+"</div>";
  }).join("");
  imp.innerHTML=`<h1>${esc(e.titre)}${corrige?" — Corrigé":""}</h1>
  <p class="meta">${esc([e.type,e.discipline,e.classe,e.date,e.duree&&"Durée : "+e.duree].filter(Boolean).join(" · "))}</p>
  <p>Nom : ______________________ &nbsp; Classe : ________ &nbsp; Note : ______ / ${fmt(total(e))}</p>
  ${e.consignes?`<div class="cs"><b>Consignes</b><br>${L(e.consignes)}</div>`:""}${qs}<p><b>Total : ${fmt(total(e))} points</b></p>`;
  document.body.classList.add("imprime");
  const fin=()=>{document.body.classList.remove("imprime");removeEventListener("afterprint",fin);};
  addEventListener("afterprint",fin);print();
}

window.MOD=window.MOD||{};
window.MOD[3]=function(box){
  const lc=document.createElement("div");lc.className="lc";box.innerHTML="";box.appendChild(lc);
  const go=(f,...a)=>{lc.oninput=lc.onchange=lc.onclick=null;scrollTo(0,0);f(...a);};

  async function liste(q=""){
    const tout=(await tous()).sort((a,b)=>b.id-a.id),r=q.trim().toLowerCase();
    const res=tout.filter(e=>!r||[e.titre,e.type,e.classe,e.discipline].join(" ").toLowerCase().includes(r));
    lc.innerHTML=`<button class="btn or" id="nv" style="width:100%">Nouvelle évaluation</button>
    <label for="q">Rechercher</label><input id="q" type="search" placeholder="Titre, classe, discipline…" value="${esc(q)}">
    ${res.length?res.map(e=>`<button class="item" data-id="${e.id}"><b>${esc(e.titre)}</b><small>${esc([e.type,e.classe,e.discipline].filter(Boolean).join(" · "))}</small><small>${e.questions.length} question${e.questions.length>1?"s":""} · ${fmt(total(e))} points</small></button>`).join(""):
    `<div class="vide"><p>${tout.length?"Aucun résultat.":"Aucune évaluation. Créez la première."}</p></div>`}`;
    lc.querySelector("#nv").onclick=()=>go(formulaire);
    const qi=lc.querySelector("#q");qi.oninput=()=>{const v=qi.value;liste(v).then(()=>{const n=lc.querySelector("#q");n.focus();n.setSelectionRange(v.length,v.length);});};
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(voir,+b.dataset.id));
  }

  function formulaire(e){
    e=e||{titre:"",type:TE[0],discipline:"",classe:"",date:aujourdhui(),duree:"",consignes:"",questions:[]};
    const sel=(k,l,v)=>`<select data-k="${k}">${l.map(x=>{const val=Array.isArray(x)?x[0]:x,nom=Array.isArray(x)?x[1]:x;return `<option value="${esc(val)}"${val===v?" selected":""}>${esc(nom)}</option>`}).join("")}</select>`;
    const inp=(k,t,type="text")=>`<label>${t}</label><input data-k="${k}" type="${type}" value="${esc(e[k])}">`;
    function rendu(){
      const y=scrollY;
      lc.innerHTML=`<h3>${e.id?"Modifier l’évaluation":"Nouvelle évaluation"}</h3>
      <label>Type d’évaluation</label>${sel("type",TE,e.type)}${inp("titre","Titre")}${inp("discipline","Discipline")}${inp("classe","Classe")}${inp("date","Date","date")}${inp("duree","Durée (ex. 1 h)")}
      <label>Consignes</label><textarea data-k="consignes">${esc(e.consignes)}</textarea>
      <h3>Questions</h3>
      ${e.questions.map((q,i)=>`<div class="qc" data-i="${i}"><div class="qh"><b>Question ${i+1}</b><span><button data-a="up" aria-label="Monter">↑</button><button data-a="dn" aria-label="Descendre">↓</button><button data-a="rm" aria-label="Supprimer">✕</button></span></div>
        ${sel("type",TQ,q.type)}
        <label>Énoncé</label><textarea data-k="enonce">${esc(q.enonce)}</textarea>
        <label>Points</label><input data-k="points" inputmode="decimal" value="${esc(q.points)}">
        ${q.type==="qcm"?`<label>Choix (un par ligne)</label><textarea data-k="options">${esc(q.options)}</textarea><label>Bonne réponse</label><select data-k="bonne"><option value="">—</option>${choix(q).map((o,j)=>`<option value="${j}"${String(q.bonne)===String(j)?" selected":""}>${String.fromCharCode(65+j)}. ${esc(o)}</option>`).join("")}</select>`:""}
        ${q.type==="vf"?`<label>Bonne réponse</label>${sel("bonne",[["","—"],"Vrai","Faux"],q.bonne)}`:""}
        <label>Corrigé</label><textarea data-k="corrige">${esc(q.corrige)}</textarea></div>`).join("")}
      <div class="rangee">${TQ.map(t=>`<button class="btn neutre" data-a="add" data-t="${t[0]}">+ ${t[1]}</button>`).join("")}</div>
      <div class="tot" id="tot">Total : ${fmt(total(e))} points</div>
      <div class="rangee"><button class="btn or" data-a="ok">Enregistrer</button><button class="btn neutre" data-a="ann">Annuler</button></div>`;
      scrollTo(0,y);
    }
    lc.oninput=ev=>{const t=ev.target,k=t.dataset.k;if(!k)return;const c=t.closest(".qc");(c?e.questions[c.dataset.i]:e)[k]=t.value;
      if(k==="points")lc.querySelector("#tot").textContent="Total : "+fmt(total(e))+" points";};
    lc.onchange=ev=>{const t=ev.target,k=t.dataset.k;if(k==="type"&&t.closest(".qc")||k==="options")rendu();};
    lc.onclick=ev=>{
      const b=ev.target.closest("[data-a]");if(!b)return;
      const c=b.closest(".qc"),i=c?+c.dataset.i:-1,a=b.dataset.a,q=e.questions;
      if(a==="add"){q.push({type:b.dataset.t,enonce:"",points:"1",options:"",bonne:"",corrige:""});rendu();scrollTo(0,document.body.scrollHeight);}
      else if(a==="rm"){if(confirm("Supprimer cette question ?")){q.splice(i,1);rendu();}}
      else if(a==="up"&&i>0){[q[i-1],q[i]]=[q[i],q[i-1]];rendu();}
      else if(a==="dn"&&i<q.length-1){[q[i+1],q[i]]=[q[i],q[i+1]];rendu();}
      else if(a==="ann")go(e.id?voir:liste,e.id);
      else if(a==="ok"){
        if(!e.titre.trim()){alert("Indiquez le titre de l’évaluation.");return;}
        sauver(e).then(id=>go(voir,e.id||id));
      }
    };
    rendu();
  }

  async function voir(id){
    const e=await lire(id);if(!e)return liste();
    lc.innerHTML=`<button class="btn neutre" id="rt">Toutes les évaluations</button><h3>${esc(e.titre)}</h3>
    <div class="bloc2">${esc([e.type,e.discipline,e.classe,e.date,e.duree&&"Durée : "+e.duree].filter(Boolean).join(" · "))}\n<b style="display:inline">Total :</b> ${fmt(total(e))} points · ${e.questions.length} question${e.questions.length>1?"s":""}</div>
    ${e.consignes?`<div class="bloc2"><b>Consignes</b>${esc(e.consignes)}</div>`:""}
    ${e.questions.map((q,i)=>`<div class="bloc2"><b>Question ${i+1} · ${esc(TQ.find(t=>t[0]===q.type)[1])} · ${fmt(pts(q))} pt</b>${esc(q.enonce)}${q.type==="qcm"?"\n"+choix(q).map((o,j)=>String.fromCharCode(65+j)+". "+o).join("\n"):""}</div>`).join("")}
    <div class="rangee"><button class="btn or" id="s">Sujet (PDF)</button><button class="btn or" id="c">Corrigé (PDF)</button><button class="btn" id="ed">Modifier</button><button class="btn" id="re">Réutiliser</button><button class="btn danger" id="su">Supprimer</button></div>`;
    lc.querySelector("#rt").onclick=()=>go(liste);
    lc.querySelector("#s").onclick=()=>pdf(e,false);
    lc.querySelector("#c").onclick=()=>pdf(e,true);
    lc.querySelector("#ed").onclick=()=>go(formulaire,e);
    lc.querySelector("#re").onclick=()=>{const c=JSON.parse(JSON.stringify(e));delete c.id;c.date=aujourdhui();go(formulaire,c);};
    lc.querySelector("#su").onclick=async()=>{if(confirm("Supprimer cette évaluation ? Cette action est définitive.")){await suppr(id);go(liste);}};
  }
  liste();
};
})();
