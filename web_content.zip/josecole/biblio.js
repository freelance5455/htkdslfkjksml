// Module 2 : Bibliothèque pédagogique (réutilise les styles .lc injectés par lecons.js)
(()=>{
const TYPES=["Cours complet","Manuel scolaire","Programme national","Document pédagogique","Exercices","Interrogation","Examen","Corrigé","Référence bibliographique","Autre"];
const NIVEAUX=["Secondaire"];
const esc=s=>String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const tx=(mode,fn)=>window.bdP.then(db=>new Promise((ok,ko)=>{const t=db.transaction("ressources",mode);const r=fn(t.objectStore("ressources"));t.oncomplete=()=>ok(r&&r.result);t.onerror=()=>ko(t.error);}));
const tous=()=>tx("readonly",s=>s.getAll()),lire=id=>tx("readonly",s=>s.get(id)),sauver=o=>tx("readwrite",s=>s.put(o)),suppr=id=>tx("readwrite",s=>s.delete(id));
const taille=n=>n>1048576?(n/1048576).toFixed(1)+" Mo":Math.max(1,Math.round(n/1024))+" Ko";
const st=document.createElement("style");
st.textContent=`.lc select{width:100%;padding:11px 12px;font:inherit;color:var(--texte);background:var(--surface);border:1px solid var(--bord);border-radius:10px}.lc .deux{display:grid;grid-template-columns:1fr 1fr;gap:8px}`;
document.head.appendChild(st);

window.MOD=window.MOD||{};
window.MOD[2]=function(box){
  const lc=document.createElement("div");lc.className="lc";box.innerHTML="";box.appendChild(lc);
  const go=(f,...a)=>{scrollTo(0,0);f(...a);};
  if(navigator.storage&&navigator.storage.persist)navigator.storage.persist();
  const opts=(l,v,vide)=>(vide?`<option value="">${vide}</option>`:"")+l.map(x=>`<option${x===v?" selected":""}>${esc(x)}</option>`).join("");

  async function liste(q="",type=""){
    const tout=(await tous()).sort((a,b)=>b.id-a.id);
    const r=q.trim().toLowerCase();
    const res=tout.filter(p=>(!type||p.type===type)&&(!r||[p.titre,p.classe,p.discipline,p.chapitre,p.sujet,p.pays].join(" ").toLowerCase().includes(r)));
    lc.innerHTML=`<button class="btn or" id="nv" style="width:100%">Ajouter un document</button>
    <label for="q">Rechercher</label><input id="q" type="search" placeholder="Titre, classe, discipline, chapitre…" value="${esc(q)}">
    <label for="t">Type de ressource</label><select id="t">${opts(TYPES,type,"Tous les types")}</select>
    <div>${res.length?res.map(p=>`<button class="item" data-id="${p.id}"><b>${esc(p.titre)}</b><small>${esc([p.type,p.classe,p.discipline].filter(Boolean).join(" · "))}</small><small>${p.fichier?esc(p.nom||"Fichier")+" · "+taille(p.fichier.size)+" · disponible hors connexion":"Référence sans fichier"}</small></button>`).join(""):
    `<div class="vide"><p>${tout.length?"Aucun résultat.":"La bibliothèque est vide. Ajoutez un PDF ou un document depuis votre téléphone."}</p></div>`}</div>`;
    lc.querySelector("#nv").onclick=()=>go(formulaire);
    lc.querySelector("#t").onchange=e=>liste(lc.querySelector("#q").value,e.target.value);
    const qi=lc.querySelector("#q");qi.oninput=()=>{const v=qi.value;liste(v,lc.querySelector("#t").value).then(()=>{const n=lc.querySelector("#q");n.focus();n.setSelectionRange(v.length,v.length);});};
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(voir,+b.dataset.id));
  }

  function formulaire(p){
    p=p||{pays:"RD Congo",niveau:"Secondaire",type:TYPES[0]};
    const c=(id,t,ph="")=>`<label for="f_${id}">${t}</label><input id="f_${id}" value="${esc(p[id])}" placeholder="${ph}">`;
    lc.innerHTML=`<h3>${p.id?"Modifier le document":"Ajouter un document"}</h3>
    <label for="f_fichier">${p.fichier?"Remplacer le fichier (facultatif)":"Fichier (PDF, image, document)"}</label>
    <input id="f_fichier" type="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,image/*">
    ${p.fichier?`<small style="color:var(--doux)">Actuel : ${esc(p.nom)} (${taille(p.fichier.size)})</small>`:""}
    ${c("titre","Titre")}
    <label for="f_type">Type</label><select id="f_type">${opts(TYPES,p.type)}</select>
    ${c("pays","Pays ou système éducatif")}
    <label for="f_niveau">Niveau d’enseignement</label><select id="f_niveau">${opts(NIVEAUX,p.niveau)}</select>
    ${c("classe","Classe","ex. 3e, 4e Biochimie")}${c("discipline","Discipline")}${c("chapitre","Chapitre")}${c("sujet","Sujet")}
    <div class="rangee"><button class="btn or" id="ok">Enregistrer</button><button class="btn neutre" id="ann">Annuler</button></div>`;
    lc.querySelector("#ann").onclick=()=>go(p.id?voir:liste,p.id);
    lc.querySelector("#ok").onclick=async()=>{
      const o={...p},v=id=>lc.querySelector("#f_"+id).value.trim();
      ["titre","type","pays","niveau","classe","discipline","chapitre","sujet"].forEach(k=>o[k]=v(k));
      const f=lc.querySelector("#f_fichier").files[0];
      if(f){o.fichier=f;o.nom=f.name;o.mime=f.type;if(!o.titre)o.titre=f.name.replace(/\.[^.]+$/,"");}
      if(!o.titre){alert("Indiquez un titre ou choisissez un fichier.");return;}
      try{const id=await sauver(o);go(voir,p.id||id);}
      catch(e){alert("Enregistrement impossible : l’espace de stockage du téléphone est peut-être plein.");}
    };
  }

  async function voir(id){
    const p=await lire(id);if(!p)return liste();
    const lignes=[["Type",p.type],["Pays / système",p.pays],["Niveau",p.niveau],["Classe",p.classe],["Discipline",p.discipline],["Chapitre",p.chapitre],["Sujet",p.sujet]].filter(l=>l[1]);
    lc.innerHTML=`<button class="btn neutre" id="rt">Toute la bibliothèque</button><h3>${esc(p.titre)}</h3>
    <div class="bloc2">${lignes.map(l=>`<b style="display:inline">${l[0]} :</b> ${esc(l[1])}`).join("\n")}${p.fichier?`\n<b style="display:inline">Fichier :</b> ${esc(p.nom)} (${taille(p.fichier.size)})`:""}</div>
    <div class="rangee">${p.fichier?`<button class="btn or" id="op">Ouvrir</button><button class="btn" id="dl">Enregistrer sur le téléphone</button>`:""}<button class="btn" id="ed">Modifier</button><button class="btn danger" id="su">Supprimer</button></div>`;
    lc.querySelector("#rt").onclick=()=>go(liste);
    lc.querySelector("#ed").onclick=()=>go(formulaire,p);
    if(p.fichier){
      const blob=p.fichier,url=URL.createObjectURL(blob);
      lc.querySelector("#op").onclick=()=>{window.open(url,"_blank")||(location.href=url);};
      lc.querySelector("#dl").onclick=()=>{const a=document.createElement("a");a.href=url;a.download=p.nom||"document";document.body.appendChild(a);a.click();a.remove();};
    }
    lc.querySelector("#su").onclick=async()=>{if(confirm("Supprimer ce document de la bibliothèque ?")){await suppr(id);go(liste);}};
  }
  liste();
};
})();
