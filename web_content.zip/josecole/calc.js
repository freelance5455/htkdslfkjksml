// Module 10 : Outils de calcul pédagogique (dépend de window.JE défini dans classes.js)
(()=>{
const JE=window.JE,E=JE.esc;
const f=(n,d=2)=>n==null||!isFinite(n)?"—":String(+n.toFixed(d)).replace(".",",");
const nums=t=>t.split(/[\s;]+/).filter(Boolean).map(x=>parseFloat(x.replace(",","."))).filter(x=>!isNaN(x));
const num=s=>parseFloat(String(s).replace(",","."));
const stat=l=>{const n=l.length,sum=l.reduce((a,b)=>a+b,0),m=sum/n,t=[...l].sort((a,b)=>a-b);
  return{n,sum,m,med:n%2?t[(n-1)/2]:(t[n/2-1]+t[n/2])/2,min:t[0],max:t[n-1],sd:Math.sqrt(l.reduce((a,b)=>a+(b-m)**2,0)/n)};};

// Évaluateur arithmétique sûr (sans eval) : + − × ÷ ( ) et %
function evaluer(src){
  const s=src.replace(/×/g,"*").replace(/÷/g,"/").replace(/−/g,"-").replace(/,/g,".").replace(/\s+/g,"");let i=0;
  const expr=()=>{let v=terme();while(s[i]==="+"||s[i]==="-"){const o=s[i++],w=terme();v=o==="+"?v+w:v-w;}return v;};
  const terme=()=>{let v=facteur();while(s[i]==="*"||s[i]==="/"){const o=s[i++],w=facteur();v=o==="*"?v*w:v/w;}return v;};
  const facteur=()=>{if(s[i]==="-"){i++;return -facteur();}if(s[i]==="+"){i++;return facteur();}let v=primaire();while(s[i]==="%"){i++;v/=100;}return v;};
  const primaire=()=>{if(s[i]==="("){i++;const v=expr();if(s[i]!==")")throw 0;i++;return v;}
    const m=/^(\d+\.?\d*|\.\d+)/.exec(s.slice(i));if(!m)throw 0;i+=m[0].length;return parseFloat(m[0]);};
  const v=expr();if(i<s.length||!isFinite(v))throw 0;return v;
}

const st=document.createElement("style");
st.textContent=`.calc .aff{min-height:84px;padding:10px 14px;margin:10px 0;border-radius:12px;background:var(--marine);color:#fff;text-align:right;word-break:break-all}
.calc .aff small{display:block;color:var(--ciel);min-height:22px}.calc .aff b{font-size:30px;font-weight:600}
.calc .grille{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}
.calc .k{min-height:56px;font:600 20px system-ui;border:1px solid var(--bord);border-radius:12px;background:var(--surface);color:var(--texte);cursor:pointer}
.calc .k.op{background:var(--gris)}.calc .k.eg{background:var(--or);color:var(--marine);border:0}
.calc .tr{display:grid;grid-template-columns:1.2fr 1fr 1fr;gap:6px;margin-top:6px}.calc .tr input{text-align:right}`;
document.head.appendChild(st);

window.MOD=window.MOD||{};
window.MOD[10]=function(box){
  const{lc,go}=JE.ecran(box);lc.classList.add("calc");
  const OUTILS=[["Calculatrice","Opérations, parenthèses et pourcentages",calculatrice],["Moyennes et statistiques","Moyenne, médiane, minimum, maximum, écart-type",stats],
    ["Pourcentages","Part, proportion et variation",pourc],["Points pondérés et coefficients","Total pondéré et moyenne avec coefficients",pond],
    ["Classement automatique","Rang des élèves, ex æquo compris",classement],["Taux de réussite et d’échec","À partir d’une liste de notes",taux]];
  const retour=`<button class="btn neutre" id="rt">Outils de calcul</button>`;
  const res=h=>lc.querySelector("#out").innerHTML=h;
  const bloc=h=>`<div class="bloc2" style="white-space:normal">${h}</div>`;
  function menu(){
    lc.innerHTML=OUTILS.map((o,i)=>`<button class="item" data-i="${i}"><b>${o[0]}</b><small>${o[1]}</small></button>`).join("");
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(OUTILS[+b.dataset.i][2]));
  }
  const entete=t=>{lc.innerHTML=retour+`<h3>${t}</h3>`;};
  const fin=()=>{lc.querySelector("#rt").onclick=()=>go(menu);};

  function calculatrice(){
    let ex="",r=false;
    const touches=["C","⌫","(",")","7","8","9","÷","4","5","6","×","1","2","3","−","0",",","%","+"];
    lc.innerHTML=retour+`<div class="aff"><small id="ex"></small><b id="re">0</b></div><div class="grille">${touches.map(k=>`<button class="k${"÷×−+".includes(k)||"C⌫()%".includes(k)?" op":""}" data-k="${k}">${k}</button>`).join("")}<button class="k eg" data-k="=" style="grid-column:1/-1">=</button></div>`;
    fin();
    const maj=()=>{lc.querySelector("#ex").textContent=ex;let v="";try{if(ex)v=f(evaluer(ex),10);}catch(e){v="";}lc.querySelector("#re").textContent=v||(ex?"…":"0");};
    lc.onclick=e=>{const b=e.target.closest("[data-k]");if(!b)return;const k=b.dataset.k;
      if(k==="C")ex="";else if(k==="⌫")ex=ex.slice(0,-1);
      else if(k==="="){try{ex=f(evaluer(ex),10).replace(/\s/g,"");r=true;}catch(x){lc.querySelector("#re").textContent="Erreur";return;}}
      else{if(r&&/[\d,(]/.test(k))ex="";r=false;ex+=k;}
      if(k!=="=")r=false;maj();};
    maj();
  }
  function stats(){
    entete("Moyennes et statistiques");
    lc.insertAdjacentHTML("beforeend",`<label for="t">Valeurs (séparées par des espaces, des retours à la ligne ou des points-virgules)</label><textarea id="t" inputmode="decimal" style="min-height:120px" placeholder="12 14,5 9 17"></textarea><div id="out"></div>`);fin();
    lc.querySelector("#t").oninput=e=>{const l=nums(e.target.value);if(!l.length)return res("");const s=stat(l);
      res(bloc(`<b>${s.n} valeur(s)</b>Somme : ${f(s.sum)}\nMoyenne : ${f(s.m)}\nMédiane : ${f(s.med)}\nMinimum : ${f(s.min)} · Maximum : ${f(s.max)}\nÉcart-type : ${f(s.sd)}`.replace(/\n/g,"<br>")));};
  }
  function pourc(){
    let mode=0;const M=[["Calculer x % de y","x (%)","y"],["x représente quel pourcentage de y ?","x","y"],["Variation en % de x à y","x (départ)","y (arrivée)"]];
    entete("Pourcentages");
    lc.insertAdjacentHTML("beforeend",`<label for="m">Calcul</label><select id="m">${M.map((m,i)=>`<option value="${i}">${m[0]}</option>`).join("")}</select><label for="a" id="la"></label><input id="a" inputmode="decimal"><label for="b" id="lb"></label><input id="b" inputmode="decimal"><div id="out"></div>`);fin();
    const q=s=>lc.querySelector(s),calc=()=>{q("#la").textContent=M[mode][1];q("#lb").textContent=M[mode][2];const a=num(q("#a").value),b=num(q("#b").value);
      if(isNaN(a)||isNaN(b))return res("");
      res(bloc(mode===0?`${f(a)} % de ${f(b)} = <b>${f(a*b/100)}</b>`:mode===1?(b?`${f(a)} sur ${f(b)} = <b>${f(a/b*100)} %</b>`:"Le total ne peut pas être 0."):(a?`De ${f(a)} à ${f(b)} : <b>${(b>=a?"+":"")+f((b-a)/a*100)} %</b>`:"La valeur de départ ne peut pas être 0.")));};
    q("#m").onchange=e=>{mode=+e.target.value;calc();};q("#a").oninput=q("#b").oninput=calc;calc();
  }
  function pond(){
    let rows=[["","20","1"],["","20","1"],["","20","1"]],base="20";
    const dessiner=()=>{entete("Points pondérés et coefficients");
      lc.insertAdjacentHTML("beforeend",`<div class="tr"><b>Note</b><b>Maximum</b><b>Coef.</b></div>${rows.map((r,i)=>`<div class="tr">${["note","max","coef"].map((k,j)=>`<input data-i="${i}" data-j="${j}" inputmode="decimal" value="${E(r[j])}" aria-label="${k} ${i+1}">`).join("")}</div>`).join("")}
      <div class="rangee"><button class="btn neutre" id="ad">Ajouter une ligne</button>${rows.length>1?'<button class="btn neutre" id="rm">Retirer la dernière</button>':""}</div>
      <label for="bs">Moyenne ramenée sur</label><input id="bs" inputmode="decimal" value="${E(base)}"><div id="out"></div>`);fin();
      lc.querySelector("#ad").onclick=()=>{rows.push(["","20","1"]);dessiner();};
      const rm=lc.querySelector("#rm");if(rm)rm.onclick=()=>{rows.pop();dessiner();};
      lc.querySelector("#bs").oninput=e=>{base=e.target.value;calc();};
      lc.oninput=e=>{const i=e.target.dataset.i;if(i==null)return;rows[+i][+e.target.dataset.j]=e.target.value;calc();};calc();};
    const calc=()=>{let s=0,w=0,tot=0,tm=0;
      rows.forEach(r=>{const n=num(r[0]),m=num(r[1]),c=num(r[2]);if(!isNaN(n)&&m>0&&c>0){s+=c*n/m;w+=c;tot+=c*n;tm+=c*m;}});
      const b=num(base)||20;if(!w)return res("");
      res(bloc(`<b>Total pondéré : ${f(tot)} / ${f(tm)}</b><br>Pourcentage : ${f(s/w*100)} %<br>Moyenne pondérée : <b>${f(s/w*b)} / ${f(b)}</b>`));};
    dessiner();
  }
  function classement(){
    entete("Classement automatique");
    lc.insertAdjacentHTML("beforeend",`<label for="t">Un élève par ligne : nom puis note</label><textarea id="t" style="min-height:140px" placeholder="Kabongo 14,5&#10;Mbuyi 12&#10;Ilunga 14,5"></textarea><div id="out"></div>`);fin();
    lc.querySelector("#t").oninput=e=>{
      const l=e.target.value.split("\n").map(x=>x.trim()).filter(Boolean).map(x=>{const p=x.split(/\s+/),n=num(p.pop());return{nom:p.join(" ")||"Sans nom",n};}).filter(x=>!isNaN(x.n));
      if(!l.length)return res("");l.sort((a,b)=>b.n-a.n||a.nom.localeCompare(b.nom,"fr"));l.forEach((x,i)=>x.r=i&&l[i-1].n===x.n?l[i-1].r:i+1);
      res(l.map(x=>`<div class="ligne"><span><b>${x.r}.</b> ${E(x.nom)}</span><span>${f(x.n)}</span></div>`).join(""));};
  }
  function taux(){
    entete("Taux de réussite et d’échec");
    lc.insertAdjacentHTML("beforeend",`<label for="t">Notes (séparées par des espaces ou des retours à la ligne)</label><textarea id="t" inputmode="decimal" style="min-height:110px"></textarea>
    <label for="mx">Note maximale</label><input id="mx" inputmode="decimal" value="20"><label for="sg">Seuil de réussite (%)</label><input id="sg" inputmode="decimal" value="50"><div id="out"></div>`);fin();
    const calc=()=>{const l=nums(lc.querySelector("#t").value),mx=num(lc.querySelector("#mx").value),sg=num(lc.querySelector("#sg").value);
      if(!l.length||!(mx>0)||isNaN(sg))return res("");const r=l.filter(x=>x/mx*100>=sg).length,n=l.length,s=stat(l);
      res(bloc(`<b>${n} note(s)</b><br>Réussites : ${r} · Échecs : ${n-r}<br>Taux de réussite : <b>${f(r/n*100)} %</b><br>Taux d’échec : <b>${f((n-r)/n*100)} %</b><br>Moyenne : ${f(s.m)} / ${f(mx)} (${f(s.m/mx*100)} %)<br>Minimum : ${f(s.min)} · Maximum : ${f(s.max)}`));};
    lc.oninput=calc;
  }
  menu();
};
})();
