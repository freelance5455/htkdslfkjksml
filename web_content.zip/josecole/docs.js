// Module 9 : Documents professionnels (dépend de window.JE défini dans classes.js)
(()=>{
const JE=window.JE,E=JE.esc,L=s=>E(s).replace(/\n/g,"<br>");
const D={};
const charger=async()=>{for(const s of["lecons","classes","eleves","epreuves","notes","presences","activites","reglages"])D[s]=await JE.tous(s);};
const P=()=>D.reglages.find(r=>r.id===2)||{};
const dfr=d=>d?new Date(d+"T00:00").toLocaleDateString("fr-FR"):"";
const mois=m=>new Date(m+"-01T00:00").toLocaleDateString("fr-FR",{month:"long",year:"numeric"});
const uniq=(a,k)=>[...new Set(a.map(x=>x[k]).filter(Boolean))].sort();
const CODE={"Présent":"P","Absent":"A","En retard":"R","Absence justifiée":"AJ","Absence non justifiée":"ANJ"};

const st=document.createElement("style");
st.textContent=`.apercu{background:#fff;color:#000;padding:14px;border-radius:8px;font:13px/1.4 Georgia,serif;overflow-x:auto;margin-top:12px}
.apercu h1,#impr h1{font:700 18px Georgia,serif;text-align:center;margin:10px 0;border-bottom:2px solid #0B2545;padding-bottom:6px}
.apercu h2,#impr h2{font:700 15px Georgia,serif;margin:12px 0 6px}
.apercu table.cl,#impr table.cl{width:100%;border-collapse:collapse;margin:8px 0;font-size:11px}
.apercu .cl td,.apercu .cl th,#impr .cl td,#impr .cl th{border:1px solid #888;padding:4px 6px;text-align:left;vertical-align:top;color:#000}
.apercu .cl th,#impr .cl th{background:#e8edf5}
.apercu table.l th,#impr table.l th{width:28%}
.ent{display:flex;justify-content:space-between;gap:10px;font-weight:700;color:#0B2545}
.dmeta{text-align:center;margin:4px 0 10px}
.sigs{display:flex;justify-content:space-between;gap:12px;margin-top:26px;text-align:center}
.pb{margin-top:22px;padding-top:12px;border-top:2px dashed #999}
@media print{#impr .pb{break-before:page;margin:0;padding:0;border:0}#impr table.cl{font-size:10pt}#impr .sigs{break-inside:avoid}}`;
document.head.appendChild(st);

const entete=(t,s)=>`<div class="ent"><span>${E(P().etablissement||"Établissement : ____________")}</span><span>Année scolaire ${E(P().annee||JE.annee())}</span></div><h1>${E(t)}</h1>${s?`<p class="dmeta">${E(s)}</p>`:""}`;
const pied=()=>{const l=(P().sigs||"L’enseignant, Le directeur").split(",").map(s=>s.trim()).filter(Boolean);
  return `<p style="margin-top:18px">Fait à ______________, le ${new Date().toLocaleDateString("fr-FR",{day:"numeric",month:"long",year:"numeric"})}</p>
  <div class="sigs">${l.map((x,i)=>`<div><b>${E(x)}</b><br>${i===0&&P().enseignant?E(P().enseignant):"&nbsp;"}<br><br><br>______________</div>`).join("")}</div>`;};
const tab=(h,rows)=>`<table class="cl"><tr>${h.map(x=>`<th>${x}</th>`).join("")}</tr>${rows.map(r=>`<tr>${r.map(x=>`<td>${x}</td>`).join("")}</tr>`).join("")}</table>`;
const pb=(h,i)=>`<div class="${i?"pb":""}">${h}</div>`;

function calc(cid,disc,per){
  const c=D.classes.find(x=>x.id===cid),els=D.eleves.filter(e=>e.classeId===cid).sort(JE.tri);
  const eps=D.epreuves.filter(e=>e.classeId===cid&&(!disc||e.discipline===disc)&&(!per||e.periode===per)).sort((a,b)=>(a.date||"").localeCompare(b.date||"")||a.id-b.id);
  const nv={};D.notes.filter(n=>n.classeId===cid).forEach(n=>nv[n.eleveId+"_"+n.epreuveId]=n.valeur);
  const lignes=els.map(el=>{let s=0,w=0,tot=0,tm=0;eps.forEach(ep=>{const v=nv[el.id+"_"+ep.id];if(v!=null){s+=ep.coef*v/ep.max;w+=ep.coef;tot+=ep.coef*v;tm+=ep.coef*ep.max;}});
    const pct=w?s/w*100:null;return{el,pct,moy:pct==null?null:pct*c.base/100,tot,tm};});
  const ev=lignes.filter(l=>l.pct!=null).sort((a,b)=>b.pct-a.pct||JE.tri(a.el,b.el));
  ev.forEach((l,i)=>l.rang=i&&ev[i-1].pct===l.pct?ev[i-1].rang:i+1);
  const n=ev.length,reus=ev.filter(l=>l.pct>=c.seuil).length;
  const stats=n?{n,moy:ev.reduce((s,l)=>s+l.moy,0)/n,max:ev[0].moy,min:ev[n-1].moy,reus:reus/n*100,echec:(n-reus)/n*100}:null;
  return{c,els,eps,nv,lignes,ev,n,stats};
}
const res=(l,c)=>l.pct==null?"Non évalué":l.pct>=c.seuil?"Réussite":"Échec";

const INF=[["classe","Classe"],["discipline","Discipline"],["chapitre","Chapitre"],["date","Date"],["duree","Durée"],["enseignant","Enseignant"]];
const ETA=[["revision","Révision"],["motivation","Motivation"],["annonce","Annonce du sujet"],["objectif","Objectif opérationnel"],["analyse","Analyse"],["synthese","Synthèse"],["controle","Contrôle"],["devoir","Devoir"]];
const PLU=[["prerequis","Prérequis"],["methodes","Méthodes pédagogiques"],["procedes","Procédés pédagogiques"],["materiel","Matériel didactique"],["references","Références bibliographiques"]];
const lecon=p=>`<h2>${E(p.sujet)}</h2><table class="cl l">${INF.concat(PLU).map(c=>p[c[0]]?`<tr><th>${c[1]}</th><td>${L(p[c[0]])}</td></tr>`:"").join("")}</table>
  <table class="cl l">${ETA.map(c=>`<tr><th>${c[1]}</th><td>${L(p[c[0]])||"&nbsp;"}</td></tr>`).join("")}</table>`;

// Générateurs : chacun renvoie du HTML, ou null s'il n'y a rien à présenter
const GEN={
prep:o=>{const l=D.lecons.filter(p=>!o.lclasse||p.classe===o.lclasse).sort((a,b)=>(a.date||"").localeCompare(b.date||""));
  return l.length?entete("Cahier de préparation",o.lclasse)+l.map((p,i)=>pb(lecon(p),i)).join("")+pied():null;},
journal:o=>{const a=D.activites.filter(x=>x.type==="Journal de classe"&&(!o.jclasse||x.classe===o.jclasse)).sort((x,y)=>(x.date||"").localeCompare(y.date||""));
  return a.length?entete("Journal de classe",o.jclasse)+tab(["Date","Classe","Discipline","Leçon / activité","Remarques"],a.map(x=>[dfr(x.date),E(x.classe),E(x.discipline),E(x.titre),L(x.details)]))+pied():null;},
notes:o=>{const r=calc(+o.classe,o.discipline,o.periode);if(!r.eps.length)return null;
  return entete("Cahier de notes",[r.c.nom,o.discipline,o.periode].filter(Boolean).join(" · "))+tab(["N°","Élève",...r.eps.map(e=>`${E(e.intitule)}<br>/${e.max} (coef ${e.coef})`),`Moy. /${r.c.base}`],
    r.lignes.map((l,i)=>[i+1,E(JE.nom(l.el)),...r.eps.map(e=>{const v=r.nv[l.el.id+"_"+e.id];return v==null?"":JE.fmt(v,2);}),JE.fmt(l.moy)]))+pied();},
pres:o=>{const cid=+o.classe,c=D.classes.find(x=>x.id===cid),els=D.eleves.filter(e=>e.classeId===cid).sort(JE.tri);
  const ps=D.presences.filter(p=>p.classeId===cid&&p.date.startsWith(o.mois)),ds=[...new Set(ps.map(p=>p.date))].sort();
  if(!ds.length)return null;const m={};ps.forEach(p=>m[p.eleveId+"_"+p.date]=CODE[p.statut]);
  return entete("Cahier de présences",c.nom+" · "+mois(o.mois))+tab(["N°","Élève",...ds.map(d=>d.slice(8)),"Abs."],
    els.map((e,i)=>[i+1,E(JE.nom(e)),...ds.map(d=>m[e.id+"_"+d]||""),ds.filter(d=>["A","AJ","ANJ"].includes(m[e.id+"_"+d])).length]))+
    "<p>P : présent · A : absent · R : en retard · AJ : absence justifiée · ANJ : absence non justifiée</p>"+pied();},
liste:o=>{const c=D.classes.find(x=>x.id===+o.classe),els=D.eleves.filter(e=>e.classeId===c.id).sort(JE.tri);
  return els.length?entete("Liste des élèves",c.nom+" · "+els.length+" élève(s)")+tab(["N°","Nom","Postnom","Prénom","Matricule","Observations"],els.map((e,i)=>[i+1,E(e.nom),E(e.postnom),E(e.prenom),E(e.matricule),E(e.info)]))+pied():null;},
lecon:o=>{const p=D.lecons.find(x=>x.id===+o.lecon);return p?entete("Préparation pédagogique",p.classe)+lecon(p)+pied():null;},
rapport:o=>{if(!o.titre||!o.contenu)return"Renseignez le titre et le contenu.";
  return entete(o.titre,[o.classe,o.periode].filter(Boolean).join(" · "))+`<p style="margin-top:14px">${L(o.contenu)}</p>`+pied();},
periode:o=>{const r=calc(+o.classe,o.discipline,o.periode),c=r.c,ps=D.presences.filter(p=>p.classeId===c.id);
  const ac=D.activites.filter(a=>a.type==="Leçon programmée"&&a.classe===c.nom),rows=[["Effectif",r.els.length],["Épreuves prises en compte",r.eps.length],["Élèves évalués",r.n]];
  if(r.stats)rows.push([`Moyenne de la classe (/${c.base})`,JE.fmt(r.stats.moy)],["Meilleure · plus faible moyenne",JE.fmt(r.stats.max)+" · "+JE.fmt(r.stats.min)],["Taux de réussite",JE.fmt(r.stats.reus)+" %"],["Taux d’échec",JE.fmt(r.stats.echec)+" %"],["Élèves en difficulté",r.ev.filter(l=>l.pct<c.seuil).map(l=>E(JE.nom(l.el))).join(", ")||"Aucun"]);
  rows.push(["Présences enregistrées",Object.keys(CODE).map(k=>k+" : "+ps.filter(p=>p.statut===k).length).join(" · ")]);
  if(ac.length)rows.push(["Leçons données / programmées",ac.filter(a=>a.statut==="Fait").length+" / "+ac.length]);
  return entete("Rapport de fin de période",[c.nom,o.discipline,o.periode].filter(Boolean).join(" · "))+tab(["Indicateur","Valeur"],rows)+
    (o.contenu?`<h2>Observations et recommandations</h2><p>${L(o.contenu)}</p>`:"")+pied();},
pv:o=>{const ep=D.epreuves.find(e=>e.id===+o.epreuve);if(!ep)return null;const c=D.classes.find(x=>x.id===ep.classeId),els=D.eleves.filter(e=>e.classeId===c.id).sort(JE.tri);
  const nv={};D.notes.filter(n=>n.epreuveId===ep.id).forEach(n=>nv[n.eleveId]=n.valeur);const vs=els.filter(e=>nv[e.id]!=null).map(e=>nv[e.id]);
  const reus=vs.filter(v=>v/ep.max*100>=c.seuil).length;
  return entete("Procès-verbal d’évaluation",[c.nom,ep.discipline,ep.intitule,dfr(ep.date)].filter(Boolean).join(" · "))+tab(["N°","Élève","Note","Pourcentage","Résultat"],
    els.map((e,i)=>{const v=nv[e.id];return[i+1,E(JE.nom(e)),v==null?"Non noté":JE.fmt(v,2)+" / "+ep.max,v==null?"":JE.fmt(v/ep.max*100,0)+" %",v==null?"":v/ep.max*100>=c.seuil?"Réussite":"Échec"];}))+
    (vs.length?`<p><b>Moyenne :</b> ${JE.fmt(vs.reduce((a,b)=>a+b,0)/vs.length,2)} / ${ep.max} · <b>Réussite :</b> ${reus}/${vs.length} (${JE.fmt(reus/vs.length*100)} %) · <b>Échec :</b> ${vs.length-reus}/${vs.length}</p>`:"")+pied();},
releve:o=>{const r=calc(+o.classe,o.discipline,o.periode),c=r.c,s=o.eleve?r.lignes.filter(l=>l.el.id===+o.eleve):r.lignes;if(!s.length||!r.eps.length)return null;
  return s.map((l,i)=>pb(entete("Relevé de notes",[c.nom,o.discipline,o.periode].filter(Boolean).join(" · "))+`<p><b>Élève :</b> ${E(JE.nom(l.el))}${l.el.matricule?" · <b>Matricule :</b> "+E(l.el.matricule):""}</p>`+
    tab(["Discipline","Épreuve","Date","Note","Maximum","Coef."],r.eps.map(e=>{const v=r.nv[l.el.id+"_"+e.id];return[E(e.discipline),E(e.intitule),dfr(e.date),v==null?"—":JE.fmt(v,2),e.max,e.coef];}))+
    `<p><b>Total pondéré :</b> ${l.pct==null?"—":JE.fmt(l.tot,2)+" / "+JE.fmt(l.tm,2)} · <b>Moyenne :</b> ${JE.fmt(l.moy)} / ${c.base} (${JE.fmt(l.pct,0)} %) · <b>Rang :</b> ${l.rang?l.rang+" / "+r.n:"—"} · <b>Résultat :</b> ${res(l,c)}</p>`+pied(),i)).join("");},
bulletin:o=>{const r=calc(+o.classe,"",o.periode),c=r.c,s=o.eleve?r.lignes.filter(l=>l.el.id===+o.eleve):r.lignes;if(!s.length||!r.eps.length)return null;
  const ds=uniq(r.eps,"discipline");if(r.eps.some(e=>!e.discipline))ds.push("");
  return s.map((l,i)=>{const pr=D.presences.filter(p=>p.eleveId===l.el.id),ab=pr.filter(p=>p.statut.startsWith("Abs")).length,aj=pr.filter(p=>p.statut==="Absence justifiée").length;
    const rows=ds.map(d=>{let s2=0,w=0,t=0,tm=0;r.eps.filter(e=>(e.discipline||"")===d).forEach(e=>{const v=r.nv[l.el.id+"_"+e.id];if(v!=null){s2+=e.coef*v/e.max;w+=e.coef;t+=e.coef*v;tm+=e.coef*e.max;}});
      return[E(d||"Sans discipline"),w?JE.fmt(t,2)+" / "+JE.fmt(tm,2):"—",w?JE.fmt(s2/w*100,0)+" %":"—",w?JE.fmt(s2/w*c.base):"—"];});
    return pb(entete("Bulletin de résultats",[c.nom,o.periode].filter(Boolean).join(" · "))+`<p><b>Élève :</b> ${E(JE.nom(l.el))}${l.el.matricule?" · <b>Matricule :</b> "+E(l.el.matricule):""}</p>`+
      tab(["Discipline","Total pondéré","Pourcentage",`Moyenne /${c.base}`],rows)+
      `<p><b>Moyenne générale :</b> ${JE.fmt(l.moy)} / ${c.base} (${JE.fmt(l.pct,0)} %) · <b>Rang :</b> ${l.rang?l.rang+" / "+r.n:"—"} · <b>Résultat :</b> ${res(l,c)}</p>
      <p><b>Absences :</b> ${ab} (dont ${aj} justifiée(s))</p><p><b>Appréciation :</b> ____________________________________________</p>`+pied(),i);}).join("");}
};
const DOCS=[
["prep","Cahier de préparation","Toutes vos préparations réunies",["lclasse"]],
["journal","Journal de classe","Leçons données et remarques",["jclasse"]],
["notes","Cahier de notes","Notes par élève et par épreuve",["classe","discipline","periode"]],
["pres","Cahier de présences","Grille des présences d’un mois",["classe","mois"]],
["liste","Liste des élèves","Liste d’une classe",["classe"]],
["lecon","Préparation pédagogique","Une préparation mise en forme",["lecon"]],
["rapport","Rapport pédagogique","Rapport rédigé par vous",["titre","classe_txt","periode_txt","contenu"]],
["periode","Rapport de fin de période","Statistiques automatiques et observations",["classe","discipline","periode","contenu"]],
["pv","Procès-verbal d’évaluation","Résultats d’une épreuve",["classe","epreuve"]],
["releve","Relevé de notes","Par élève ou pour toute la classe",["classe","eleve","discipline","periode"]],
["bulletin","Bulletin de résultats","Par élève ou pour toute la classe",["classe","eleve","periode"]]];

window.MOD=window.MOD||{};
window.MOD[9]=function(box){
  const{lc,go}=JE.ecran(box);
  async function accueil(){
    await charger();
    lc.innerHTML=`<div class="rangee"><button class="btn or" id="pe">Personnaliser (établissement, signatures)</button></div>
    ${DOCS.map(d=>`<button class="item" data-d="${d[0]}"><b>${d[1]}</b><small>${d[2]}</small></button>`).join("")}`;
    lc.querySelector("#pe").onclick=()=>go(perso);
    lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(options,b.dataset.d));
  }
  function perso(){
    const l=D.lecons.slice().sort((a,b)=>b.id-a.id)[0]||{},p=P();
    const v={etablissement:p.etablissement??l.etablissement??"",enseignant:p.enseignant??l.enseignant??"",annee:p.annee??l.annee??JE.annee(),sigs:p.sigs??"L’enseignant, Le directeur des études"};
    lc.innerHTML=`<h3>Personnalisation des documents</h3>${JE.champ("etablissement","Nom de l’établissement",v.etablissement)}${JE.champ("enseignant","Nom de l’enseignant",v.enseignant)}${JE.champ("annee","Année scolaire",v.annee)}
    ${JE.champ("sigs","Signatures (séparées par des virgules)",v.sigs)}<div class="rangee"><button class="btn or" id="ok">Enregistrer</button><button class="btn neutre" id="an">Annuler</button></div>`;
    lc.querySelector("#an").onclick=()=>go(accueil);
    lc.querySelector("#ok").onclick=async()=>{const g=k=>lc.querySelector("#f_"+k).value.trim();
      await JE.sauver("reglages",{...p,id:2,etablissement:g("etablissement"),enseignant:g("enseignant"),annee:g("annee"),sigs:g("sigs")});go(accueil);};
  }
  function options(id,o={}){
    const doc=DOCS.find(d=>d[0]===id),cl=D.classes.slice().sort((a,b)=>a.nom.localeCompare(b.nom,"fr"));
    const needClass=doc[3].includes("classe");
    if(needClass&&!cl.length){lc.innerHTML='<button class="btn neutre" id="rt">Documents</button><div class="vide"><p>Aucune classe. Créez d’abord une classe dans « Classes et élèves ».</p></div>';lc.querySelector("#rt").onclick=()=>go(accueil);return;}
    const sel=(k,t,l)=>{if(!l.some(x=>String(x[0])===String(o[k])))o[k]=String(l[0]?l[0][0]:"");
      return `<label for="o_${k}">${t}</label><select id="o_${k}" data-k="${k}">${l.map(x=>`<option value="${E(x[0])}"${String(x[0])===String(o[k])?" selected":""}>${E(x[1])}</option>`).join("")}</select>`;};
    const txt=(k,t)=>`<label for="o_${k}">${t}</label><input id="o_${k}" data-k="${k}" value="${E(o[k]||"")}">`;
    const cid=needClass?+(o.classe||cl[0].id):0,epc=D.epreuves.filter(e=>e.classeId===cid),els=D.eleves.filter(e=>e.classeId===cid).sort(JE.tri);
    const tous=[["","Toutes"]],ms=[...new Set(D.presences.filter(p=>p.classeId===cid).map(p=>p.date.slice(0,7)))].sort().reverse();
    const F={
      classe:()=>sel("classe","Classe",cl.map(c=>[c.id,c.nom])),
      discipline:()=>sel("discipline","Discipline",tous.concat(uniq(epc,"discipline").map(x=>[x,x]))),
      periode:()=>sel("periode","Période",tous.concat(uniq(epc,"periode").map(x=>[x,x]))),
      eleve:()=>sel("eleve","Élève",[["","Tous les élèves"]].concat(els.map(e=>[e.id,JE.nom(e)]))),
      epreuve:()=>sel("epreuve","Épreuve",epc.map(e=>[e.id,e.intitule+(e.discipline?" · "+e.discipline:"")])),
      mois:()=>sel("mois","Mois",ms.length?ms.map(m=>[m,mois(m)]):[["","Aucune présence enregistrée"]]),
      lclasse:()=>sel("lclasse","Classe",tous.concat(uniq(D.lecons,"classe").map(x=>[x,x]))),
      jclasse:()=>sel("jclasse","Classe",tous.concat(uniq(D.activites.filter(a=>a.type==="Journal de classe"),"classe").map(x=>[x,x]))),
      lecon:()=>sel("lecon","Préparation",D.lecons.slice().sort((a,b)=>b.id-a.id).map(p=>[p.id,p.sujet+(p.classe?" · "+p.classe:"")])),
      titre:()=>txt("titre","Titre du rapport"),classe_txt:()=>txt("classe","Classe (facultatif)"),periode_txt:()=>txt("periode","Période (facultatif)"),
      contenu:()=>`<label for="o_contenu">${id==="rapport"?"Contenu du rapport":"Observations et recommandations (facultatif)"}</label><textarea id="o_contenu" data-k="contenu" style="min-height:140px">${E(o.contenu||"")}</textarea>`
    };
    lc.innerHTML=`<button class="btn neutre" id="rt">Documents</button><h3>${doc[1]}</h3>${doc[3].map(k=>F[k]()).join("")}
    <div class="rangee"><button class="btn or" id="ap">Aperçu</button></div>`;
    lc.querySelector("#rt").onclick=()=>go(accueil);
    lc.oninput=lc.onchange=ev=>{const t=ev.target,k=t.dataset.k;if(!k)return;o[k]=t.value;if(k==="classe"&&ev.type==="change"){["discipline","periode","eleve","epreuve","mois"].forEach(x=>delete o[x]);const y=scrollY;options(id,o);scrollTo(0,y);}};
    lc.querySelector("#ap").onclick=()=>{
      const o2={...o};if(id==="rapport"){o2.classe=o.classe_txt??o.classe;}
      let h;try{h=GEN[id](o2);}catch(e){h=null;}
      go(apercu,id,o,h);};
  }
  function apercu(id,o,h){
    const doc=DOCS.find(d=>d[0]===id),ok=h&&h.startsWith("<");
    lc.innerHTML=`<button class="btn neutre" id="rt">Modifier les options</button><h3>${doc[1]}</h3>
    ${ok?`<div class="rangee"><button class="btn or" id="pd">Exporter en PDF</button></div><div class="apercu">${h}</div>`:`<div class="vide"><p>${h||"Aucune donnée pour ce choix : saisissez d’abord les informations nécessaires dans les autres modules."}</p></div>`}`;
    lc.querySelector("#rt").onclick=()=>go(options,id,o);
    if(ok)lc.querySelector("#pd").onclick=()=>JE.pdf(h);
  }
  accueil();
};
})();
