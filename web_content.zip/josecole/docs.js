// Module 9 : Documents professionnels (dépend de window.JE défini dans classes.js)
(()=>{
const JE=window.JE,E=JE.esc,L=s=>E(s).replace(/\n/g,"<br>");
const D={};
const charger=async()=>{for(const s of["lecons","classes","eleves","epreuves","notes","presences","activites","reglages"])D[s]=await JE.tous(s);};
const P=()=>D.reglages.find(r=>r.id===2)||{};
const dfr=d=>d?new Date(d+"T00:00").toLocaleDateString("fr-FR"):"";
const mois=m=>new Date(m+"-01T00:00").toLocaleDateString("fr-FR",{month:"long",year:"numeric"});
const uniq=(a,k)=>[...new Set(a.map(x=>x[k]).filter(Boolean))].sort();
const CODE={"Présent":"P","Absent":"A","En retard":"R","Absence justifiée":"AJ","Absence non justifiée":"ANJ"};
const classe=o=>D.classes.find(x=>x.id===+o.classe);
const elevesDe=c=>D.eleves.filter(e=>e.classeId===c.id).sort(JE.tri);

const st=document.createElement("style");
st.textContent=`.apercu{background:#fff;color:#000;padding:14px;border-radius:8px;font:13px/1.4 Georgia,serif;overflow-x:auto;margin-top:12px;border:1px solid var(--bord)}
.apercu h1,#impr h1{font:700 18px Georgia,serif;text-align:center;margin:10px 0;border-bottom:2px solid #0B2545;padding-bottom:6px}
.apercu h2,#impr h2{font:700 15px Georgia,serif;margin:12px 0 6px}
.apercu table.cl,#impr table.cl{width:100%;border-collapse:collapse;margin:8px 0;font-size:11px}
.apercu .cl td,.apercu .cl th,#impr .cl td,#impr .cl th{border:1px solid #888;padding:4px 6px;text-align:left;vertical-align:top;color:#000}
.apercu .cl th,#impr .cl th{background:#e8edf5}
.apercu table.l th,#impr table.l th{width:28%}
.apercu table.vd td,#impr table.vd td{height:26px}
.apercu .ln,#impr .ln{border-bottom:1px solid #777;height:26px}
.apercu .dmeta,#impr .dmeta{text-align:center;margin:4px 0 10px}
.apercu .dch,#impr .dch{display:flex;flex-wrap:wrap;gap:6px 24px;margin:10px 0}
.apercu .pb{margin-top:22px;padding-top:12px;border-top:2px dashed #999}
@media print{#impr .pb{break-before:page;margin:0;padding:0;border:0}#impr table.cl{font-size:10pt}#impr .sg{break-inside:avoid}}
.lc .dr{display:flex;align-items:center;gap:12px;width:100%;margin-top:8px;padding:12px;text-align:left;background:var(--surface);color:var(--texte);border:1px solid var(--bord);border-radius:14px;font:inherit;cursor:pointer;min-height:64px}
.lc .dr:active{background:var(--gris)}
.lc .dr .di{flex:none;width:42px;height:42px;border-radius:12px;background:var(--marine);color:#fff;display:grid;place-items:center}
.lc .dr .di svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.lc .dr b{display:block}.lc .dr small{color:var(--doux)}.lc .dr small.ok{color:#1d7a46;font-weight:600}
.lc .dr .fl{margin-left:auto;color:var(--doux);font-size:22px}
.lc .perso{padding:12px 14px;border-radius:14px;background:var(--gris);border-left:4px solid var(--or)}
.lc .perso.alerte{background:#fff4d6;color:#4a3b00}
.lc .info{margin:10px 0;padding:10px 12px;border-radius:10px;background:#fff4d6;color:#4a3b00;font-size:14px}
.lc .chk{display:flex;gap:10px;align-items:center;margin-top:14px;color:var(--texte);font-size:15px}.lc .chk input{width:22px;height:22px}`;
document.head.appendChild(st);

const entete=(t,s)=>`<table style="width:100%;border:0"><tr><td style="border:0;padding:0;font-weight:700;color:#0B2545">${E(P().etablissement||"Établissement : ____________")}</td><td style="border:0;padding:0;text-align:right;font-weight:700;color:#0B2545">Année scolaire ${E(P().annee||JE.annee())}</td></tr></table><h1>${E(t)}</h1>${s?`<p class="dmeta">${E(s)}</p>`:""}`;
const pied=()=>{const l=(P().sigs||"L’enseignant, Le directeur").split(",").map(s=>s.trim()).filter(Boolean);
  return `<p style="margin-top:18px">Fait à ______________, le ${new Date().toLocaleDateString("fr-FR",{day:"numeric",month:"long",year:"numeric"})}</p>
  <table class="sg" style="width:100%;border:0;margin-top:20px"><tr>${l.map((x,i)=>`<td style="border:0;text-align:center;padding:0 6px"><b>${E(x)}</b><br>${i===0&&P().enseignant?E(P().enseignant):"&nbsp;"}<br><br><br>______________</td>`).join("")}</tr></table>`;};
const tab=(h,rows,c="")=>`<table class="cl ${c}"><tr>${h.map(x=>`<th>${x}</th>`).join("")}</tr>${rows.map(r=>`<tr>${r.map(x=>`<td>${x}</td>`).join("")}</tr>`).join("")}</table>`;
const pb=(h,i)=>`<div class="${i?"pb":""}">${h}</div>`;
const vl=(n,k,num)=>Array.from({length:n},(_,i)=>Array.from({length:k},(_,j)=>num&&j===0?i+1:"&nbsp;"));
const champs=(...l)=>`<div class="dch">${l.map(x=>`<span>${x} : ______________</span>`).join("")}</div>`;
const lignes=n=>'<div class="ln"></div>'.repeat(n);

function calc(cid,disc,per){
  const c=D.classes.find(x=>x.id===cid),els=D.eleves.filter(e=>e.classeId===cid).sort(JE.tri);
  const eps=D.epreuves.filter(e=>e.classeId===cid&&(!disc||e.discipline===disc)&&(!per||e.periode===per)).sort((a,b)=>(a.date||"").localeCompare(b.date||"")||a.id-b.id);
  const nv={};D.notes.filter(n=>n.classeId===cid).forEach(n=>nv[n.eleveId+"_"+n.epreuveId]=n.valeur);
  const lg=els.map(el=>{let s=0,w=0,tot=0,tm=0;eps.forEach(ep=>{const v=nv[el.id+"_"+ep.id];if(v!=null){s+=ep.coef*v/ep.max;w+=ep.coef;tot+=ep.coef*v;tm+=ep.coef*ep.max;}});
    const pct=w?s/w*100:null;return{el,pct,moy:pct==null?null:pct*c.base/100,tot,tm};});
  const ev=lg.filter(l=>l.pct!=null).sort((a,b)=>b.pct-a.pct||JE.tri(a.el,b.el));
  ev.forEach((l,i)=>l.rang=i&&ev[i-1].pct===l.pct?ev[i-1].rang:i+1);
  const n=ev.length,reus=ev.filter(l=>l.pct>=c.seuil).length;
  const stats=n?{n,moy:ev.reduce((s,l)=>s+l.moy,0)/n,max:ev[0].moy,min:ev[n-1].moy,reus:reus/n*100,echec:(n-reus)/n*100}:null;
  return{c,els,eps,nv,lignes:lg,ev,n,stats};
}
const res=(l,c)=>l.pct==null?"Non évalué":l.pct>=c.seuil?"Réussite":"Échec";

const INF=[["classe","Classe"],["discipline","Discipline"],["chapitre","Chapitre"],["date","Date"],["duree","Durée"],["enseignant","Enseignant"]];
const ETA=[["revision","Révision"],["motivation","Motivation"],["annonce","Annonce du sujet"],["objectif","Objectif opérationnel"],["analyse","Analyse"],["synthese","Synthèse"],["controle","Contrôle"],["devoir","Devoir"]];
const PLU=[["prerequis","Prérequis"],["methodes","Méthodes pédagogiques"],["procedes","Procédés pédagogiques"],["materiel","Matériel didactique"],["references","Références bibliographiques"]];
const lecon=(p,vide)=>`<h2>${E(p.sujet||"Sujet de la leçon : ____________________")}</h2><table class="cl l">${INF.concat(PLU).map(c=>p[c[0]]||vide?`<tr><th>${c[1]}</th><td>${L(p[c[0]])||"&nbsp;"}</td></tr>`:"").join("")}</table>
  <table class="cl l">${ETA.map(c=>`<tr><th>${c[1]}</th><td${vide?' style="height:64px"':""}>${L(p[c[0]])||"&nbsp;"}</td></tr>`).join("")}</table>`;

// Versions avec données (renvoient null s'il n'y a rien à présenter)
const GEN={
prep:o=>{const l=D.lecons.filter(p=>!o.lclasse||p.classe===o.lclasse).sort((a,b)=>(a.date||"").localeCompare(b.date||""));
  return l.length?entete("Cahier de préparation",o.lclasse)+l.map((p,i)=>pb(lecon(p),i)).join("")+pied():null;},
journal:o=>{const a=D.activites.filter(x=>x.type==="Journal de classe"&&(!o.jclasse||x.classe===o.jclasse)).sort((x,y)=>(x.date||"").localeCompare(y.date||""));
  return a.length?entete("Journal de classe",o.jclasse)+tab(["Date","Classe","Discipline","Leçon / activité","Remarques"],a.map(x=>[dfr(x.date),E(x.classe),E(x.discipline),E(x.titre),L(x.details)]))+pied():null;},
notes:o=>{const c=classe(o);if(!c)return null;const r=calc(c.id,o.discipline,o.periode);if(!r.eps.length||!r.els.length)return null;
  return entete("Cahier de notes",[c.nom,o.discipline,o.periode].filter(Boolean).join(" · "))+tab(["N°","Élève",...r.eps.map(e=>`${E(e.intitule)}<br>/${e.max} (coef ${e.coef})`),`Moy. /${c.base}`],
    r.lignes.map((l,i)=>[i+1,E(JE.nom(l.el)),...r.eps.map(e=>{const v=r.nv[l.el.id+"_"+e.id];return v==null?"":JE.fmt(v,2);}),JE.fmt(l.moy)]))+pied();},
pres:o=>{const c=classe(o);if(!c||!o.mois)return null;const els=elevesDe(c);
  const ps=D.presences.filter(p=>p.classeId===c.id&&p.date.startsWith(o.mois)),ds=[...new Set(ps.map(p=>p.date))].sort();
  if(!ds.length||!els.length)return null;const m={};ps.forEach(p=>m[p.eleveId+"_"+p.date]=CODE[p.statut]);
  return entete("Cahier de présences",c.nom+" · "+mois(o.mois))+tab(["N°","Élève",...ds.map(d=>d.slice(8)),"Abs."],
    els.map((e,i)=>[i+1,E(JE.nom(e)),...ds.map(d=>m[e.id+"_"+d]||""),ds.filter(d=>["A","AJ","ANJ"].includes(m[e.id+"_"+d])).length]))+
    "<p>P : présent · A : absent · R : en retard · AJ : absence justifiée · ANJ : absence non justifiée</p>"+pied();},
liste:o=>{const c=classe(o);if(!c)return null;const els=elevesDe(c);
  return els.length?entete("Liste des élèves",c.nom+" · "+els.length+" élève(s)")+tab(["N°","Nom","Postnom","Prénom","Matricule","Observations"],els.map((e,i)=>[i+1,E(e.nom),E(e.postnom),E(e.prenom),E(e.matricule),E(e.info)]))+pied():null;},
lecon:o=>{const p=D.lecons.find(x=>x.id===+o.lecon);return p?entete("Préparation pédagogique",p.classe)+lecon(p)+pied():null;},
rapport:o=>{if(!(o.contenu||"").trim())return null;
  return entete(o.titre||"Rapport pédagogique",[o.classe,o.periode].filter(Boolean).join(" · "))+`<p style="margin-top:14px">${L(o.contenu)}</p>`+pied();},
periode:o=>{const c=classe(o);if(!c)return null;const r=calc(c.id,o.discipline,o.periode);if(!r.eps.length)return null;
  const ps=D.presences.filter(p=>p.classeId===c.id),ac=D.activites.filter(a=>a.type==="Leçon programmée"&&a.classe===c.nom),rows=[["Effectif",r.els.length],["Épreuves prises en compte",r.eps.length],["Élèves évalués",r.n]];
  if(r.stats)rows.push([`Moyenne de la classe (/${c.base})`,JE.fmt(r.stats.moy)],["Meilleure · plus faible moyenne",JE.fmt(r.stats.max)+" · "+JE.fmt(r.stats.min)],["Taux de réussite",JE.fmt(r.stats.reus)+" %"],["Taux d’échec",JE.fmt(r.stats.echec)+" %"],["Élèves en difficulté",r.ev.filter(l=>l.pct<c.seuil).map(l=>E(JE.nom(l.el))).join(", ")||"Aucun"]);
  rows.push(["Présences enregistrées",Object.keys(CODE).map(k=>k+" : "+ps.filter(p=>p.statut===k).length).join(" · ")]);
  if(ac.length)rows.push(["Leçons données / programmées",ac.filter(a=>a.statut==="Fait").length+" / "+ac.length]);
  return entete("Rapport de fin de période",[c.nom,o.discipline,o.periode].filter(Boolean).join(" · "))+tab(["Indicateur","Valeur"],rows)+
    (o.contenu?`<h2>Observations et recommandations</h2><p>${L(o.contenu)}</p>`:`<h2>Observations et recommandations</h2>${lignes(6)}`)+pied();},
pv:o=>{const ep=D.epreuves.find(e=>e.id===+o.epreuve);if(!ep)return null;const c=D.classes.find(x=>x.id===ep.classeId),els=elevesDe(c);if(!els.length)return null;
  const nv={};D.notes.filter(n=>n.epreuveId===ep.id).forEach(n=>nv[n.eleveId]=n.valeur);const vs=els.filter(e=>nv[e.id]!=null).map(e=>nv[e.id]);
  const reus=vs.filter(v=>v/ep.max*100>=c.seuil).length;
  return entete("Procès-verbal d’évaluation",[c.nom,ep.discipline,ep.intitule,dfr(ep.date)].filter(Boolean).join(" · "))+tab(["N°","Élève","Note","Pourcentage","Résultat"],
    els.map((e,i)=>{const v=nv[e.id];return[i+1,E(JE.nom(e)),v==null?"Non noté":JE.fmt(v,2)+" / "+ep.max,v==null?"":JE.fmt(v/ep.max*100,0)+" %",v==null?"":v/ep.max*100>=c.seuil?"Réussite":"Échec"];}))+
    (vs.length?`<p><b>Moyenne :</b> ${JE.fmt(vs.reduce((a,b)=>a+b,0)/vs.length,2)} / ${ep.max} · <b>Réussite :</b> ${reus}/${vs.length} (${JE.fmt(reus/vs.length*100)} %) · <b>Échec :</b> ${vs.length-reus}/${vs.length}</p>`:"")+pied();},
releve:o=>{const c=classe(o);if(!c)return null;const r=calc(c.id,o.discipline,o.periode),s=o.eleve?r.lignes.filter(l=>l.el.id===+o.eleve):r.lignes;if(!s.length||!r.eps.length)return null;
  return s.map((l,i)=>pb(entete("Relevé de notes",[c.nom,o.discipline,o.periode].filter(Boolean).join(" · "))+`<p><b>Élève :</b> ${E(JE.nom(l.el))}${l.el.matricule?" · <b>Matricule :</b> "+E(l.el.matricule):""}</p>`+
    tab(["Discipline","Épreuve","Date","Note","Maximum","Coef."],r.eps.map(e=>{const v=r.nv[l.el.id+"_"+e.id];return[E(e.discipline),E(e.intitule),dfr(e.date),v==null?"—":JE.fmt(v,2),e.max,e.coef];}))+
    `<p><b>Total pondéré :</b> ${l.pct==null?"—":JE.fmt(l.tot,2)+" / "+JE.fmt(l.tm,2)} · <b>Moyenne :</b> ${JE.fmt(l.moy)} / ${c.base} (${JE.fmt(l.pct,0)} %) · <b>Rang :</b> ${l.rang?l.rang+" / "+r.n:"—"} · <b>Résultat :</b> ${res(l,c)}</p>`+pied(),i)).join("");},
bulletin:o=>{const c=classe(o);if(!c)return null;const r=calc(c.id,"",o.periode),s=o.eleve?r.lignes.filter(l=>l.el.id===+o.eleve):r.lignes;if(!s.length||!r.eps.length)return null;
  const ds=uniq(r.eps,"discipline");if(r.eps.some(e=>!e.discipline))ds.push("");
  return s.map((l,i)=>{const pr=D.presences.filter(p=>p.eleveId===l.el.id),ab=pr.filter(p=>p.statut.startsWith("Abs")).length,aj=pr.filter(p=>p.statut==="Absence justifiée").length;
    const rows=ds.map(d=>{let s2=0,w=0,t=0,tm=0;r.eps.filter(e=>(e.discipline||"")===d).forEach(e=>{const v=r.nv[l.el.id+"_"+e.id];if(v!=null){s2+=e.coef*v/e.max;w+=e.coef;t+=e.coef*v;tm+=e.coef*e.max;}});
      return[E(d||"Sans discipline"),w?JE.fmt(t,2)+" / "+JE.fmt(tm,2):"—",w?JE.fmt(s2/w*100,0)+" %":"—",w?JE.fmt(s2/w*c.base):"—"];});
    return pb(entete("Bulletin de résultats",[c.nom,o.periode].filter(Boolean).join(" · "))+`<p><b>Élève :</b> ${E(JE.nom(l.el))}${l.el.matricule?" · <b>Matricule :</b> "+E(l.el.matricule):""}</p>`+
      tab(["Discipline","Total pondéré","Pourcentage",`Moyenne /${c.base}`],rows)+
      `<p><b>Moyenne générale :</b> ${JE.fmt(l.moy)} / ${c.base} (${JE.fmt(l.pct,0)} %) · <b>Rang :</b> ${l.rang?l.rang+" / "+r.n:"—"} · <b>Résultat :</b> ${res(l,c)}</p>
      <p><b>Absences :</b> ${ab} (dont ${aj} justifiée(s))</p><p><b>Appréciation :</b></p>${lignes(2)}`+pied(),i);}).join("");}
};

// Modèles vierges : toujours disponibles, à imprimer et à remplir à la main
const VIDE={
prep:o=>entete("Cahier de préparation")+champs("Classe","Discipline","Date")+lecon({},true)+pied(),
lecon:o=>entete("Préparation pédagogique")+champs("Classe","Discipline","Date")+lecon({},true)+pied(),
journal:o=>entete("Journal de classe")+tab(["Date","Classe","Discipline","Leçon / activité","Remarques"],vl(18,5),"vd")+pied(),
notes:o=>{const c=classe(o),els=c?elevesDe(c):[],h=["N°","Élève",...Array.from({length:8},()=>"Épreuve<br>/ ___"),"Moy."];
  return entete("Cahier de notes",c?c.nom:"")+champs(...(c?[]:["Classe"]),"Discipline","Période")+tab(h,els.length?els.map((e,i)=>[i+1,E(JE.nom(e)),...Array(9).fill("&nbsp;")]):vl(30,h.length,true),"vd")+pied();},
pres:o=>{const c=classe(o),els=c?elevesDe(c):[],h=["N°","Élève",...Array(20).fill("&nbsp;"),"Abs."];
  return entete("Cahier de présences",c?c.nom:"")+champs(...(c?[]:["Classe"]),"Mois")+tab(h,els.length?els.map((e,i)=>[i+1,E(JE.nom(e)),...Array(21).fill("&nbsp;")]):vl(30,h.length,true),"vd")+
    "<p>P : présent · A : absent · R : en retard · AJ : absence justifiée · ANJ : absence non justifiée</p>"+pied();},
liste:o=>{const c=classe(o);return entete("Liste des élèves",c?c.nom:"")+(c?"":champs("Classe"))+tab(["N°","Nom","Postnom","Prénom","Matricule","Observations"],vl(35,6,true),"vd")+pied();},
rapport:o=>entete(o.titre||"Rapport pédagogique")+champs("Classe","Période","Date")+lignes(24)+pied(),
periode:o=>{const c=classe(o);return entete("Rapport de fin de période",c?c.nom:"")+(c?"":champs("Classe"))+champs("Discipline","Période")+
  tab(["Indicateur","Valeur"],["Effectif","Épreuves prises en compte","Moyenne de la classe","Meilleure · plus faible moyenne","Taux de réussite","Taux d’échec","Élèves en difficulté","Présences et absences","Leçons données / programmées"].map(x=>[x,"&nbsp;"]),"vd")+
  `<h2>Observations et recommandations</h2>${lignes(6)}`+pied();},
pv:o=>entete("Procès-verbal d’évaluation")+champs("Classe","Discipline","Épreuve","Date","Note maximale")+tab(["N°","Élève","Note","Pourcentage","Résultat"],vl(35,5,true),"vd")+pied(),
releve:o=>entete("Relevé de notes")+champs("Élève","Matricule","Classe","Période")+tab(["Discipline","Épreuve","Date","Note","Maximum","Coef."],vl(10,6),"vd")+
  "<p><b>Total pondéré :</b> ________ · <b>Moyenne :</b> ________ · <b>Rang :</b> ________ · <b>Résultat :</b> ________</p>"+pied(),
bulletin:o=>entete("Bulletin de résultats")+champs("Élève","Matricule","Classe","Période")+tab(["Discipline","Total pondéré","Pourcentage","Moyenne"],vl(10,4),"vd")+
  "<p><b>Moyenne générale :</b> ________ · <b>Rang :</b> ________ · <b>Résultat :</b> ________ · <b>Absences :</b> ________</p><p><b>Appréciation :</b></p>"+lignes(2)+pied()
};

const N={prep:()=>D.lecons.length,lecon:()=>D.lecons.length,journal:()=>D.activites.filter(a=>a.type==="Journal de classe").length,liste:()=>D.eleves.length,pres:()=>D.presences.length,notes:()=>D.notes.length,pv:()=>D.epreuves.length,releve:()=>D.notes.length,bulletin:()=>D.notes.length,periode:()=>D.notes.length,rapport:()=>0};
const U={prep:"préparation(s)",lecon:"préparation(s)",journal:"entrée(s)",liste:"élève(s)",pres:"présence(s) saisie(s)",notes:"note(s)",pv:"épreuve(s)",releve:"note(s)",bulletin:"note(s)",periode:"note(s)",rapport:"rédaction libre"};
const DOCS=[
["Préparer",[["prep","Cahier de préparation","Toutes vos préparations réunies",["lclasse"]],["lecon","Préparation pédagogique","Une préparation mise en forme",["lecon"]],["journal","Journal de classe","Leçons données et remarques",["jclasse"]]]],
["Suivre ma classe",[["liste","Liste des élèves","Liste d’une classe",["classe"]],["pres","Cahier de présences","Grille des présences d’un mois",["classe","mois"]],["notes","Cahier de notes","Notes par élève et par épreuve",["classe","discipline","periode"]]]],
["Résultats",[["pv","Procès-verbal d’évaluation","Résultats d’une épreuve",["classe","epreuve"]],["releve","Relevé de notes","Par élève ou pour toute la classe",["classe","eleve","discipline","periode"]],["bulletin","Bulletin de résultats","Par élève ou pour toute la classe",["classe","eleve","periode"]]]],
["Rapports",[["rapport","Rapport pédagogique","Rapport rédigé par vous",["titre","classe_txt","periode_txt","contenu"]],["periode","Rapport de fin de période","Statistiques automatiques et observations",["classe","discipline","periode","contenu"]]]]];
const DOC=id=>{for(const g of DOCS){const d=g[1].find(x=>x[0]===id);if(d)return d;}};
const ICONE='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h6"/></svg>';

function telecharger(h,nom){
  const css="body{font-family:Georgia,serif;font-size:12pt}h1{font-size:18pt;text-align:center;border-bottom:2px solid #0B2545}h2{font-size:14pt}table{width:100%;border-collapse:collapse;margin:8px 0}table.cl td,table.cl th{border:1px solid #888;padding:4px 6px;vertical-align:top}table.cl th{background:#e8edf5}.ln{border-bottom:1px solid #777;height:24px}.pb{page-break-before:always}";
  const html=`<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>${E(nom)}</title><style>${css}</style></head><body>${h}</body></html>`;
  const u=URL.createObjectURL(new Blob(["\ufeff"+html],{type:"application/msword"})),a=document.createElement("a");
  a.href=u;a.download=nom.replace(/[^\w\-]+/g,"-")+"-"+JE.today()+".doc";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),8000);
}

window.MOD=window.MOD||{};
window.MOD[9]=function(box){
  const{lc,go}=JE.ecran(box);
  async function accueil(){
    await charger();const p=P(),ok=p.etablissement&&p.enseignant;
    lc.innerHTML=`<div class="perso${ok?"":" alerte"}"><b>${ok?E(p.etablissement):"En-tête des documents à renseigner"}</b><br><small>${ok?E(p.enseignant)+" · "+E(p.annee||JE.annee()):"Indiquez votre établissement et votre nom : ils apparaîtront en tête de chaque document."}</small>
      <div style="margin-top:8px"><button class="btn ${ok?"neutre":"or"}" id="pe">${ok?"Modifier":"Renseigner maintenant"}</button></div></div>
    ${DOCS.map(g=>`<div class="sec">${g[0]}</div>${g[1].map(d=>{const n=N[d[0]]();
      return `<button class="dr" data-d="${d[0]}"><span class="di">${ICONE}</span><span><b>${d[1]}</b><small${n?' class="ok"':""}>${d[0]==="rapport"?"Rédaction libre ou modèle vierge":n?"● "+n+" "+U[d[0]]:"Modèle vierge à imprimer"}</small></span><span class="fl">›</span></button>`;}).join("")}`).join("")}`;
    lc.querySelector("#pe").onclick=()=>go(perso);
    lc.querySelectorAll(".dr").forEach(b=>b.onclick=()=>go(ecran,b.dataset.d));
  }
  function perso(){
    const l=D.lecons.slice().sort((a,b)=>b.id-a.id)[0]||{},p=P();
    const v={etablissement:p.etablissement??l.etablissement??"",enseignant:p.enseignant??l.enseignant??"",annee:p.annee??l.annee??JE.annee(),sigs:p.sigs??"L’enseignant, Le directeur des études"};
    lc.innerHTML=`<button class="btn neutre" id="an">Documents</button><h3>En-tête et signatures</h3>${JE.champ("etablissement","Nom de l’établissement",v.etablissement)}${JE.champ("enseignant","Nom de l’enseignant",v.enseignant)}${JE.champ("annee","Année scolaire",v.annee)}
    ${JE.champ("sigs","Signatures (séparées par des virgules)",v.sigs)}<div class="rangee"><button class="btn or" id="ok">Enregistrer</button></div>`;
    lc.querySelector("#an").onclick=()=>go(accueil);
    lc.querySelector("#ok").onclick=async()=>{const g=k=>lc.querySelector("#f_"+k).value.trim();
      await JE.sauver("reglages",{...p,id:2,etablissement:g("etablissement"),enseignant:g("enseignant"),annee:g("annee"),sigs:g("sigs")});go(accueil);};
  }

  // Un seul écran : choix + aperçu en direct + export
  function ecran(id,o={}){
    const doc=DOC(id),cl=D.classes.slice().sort((a,b)=>a.nom.localeCompare(b.nom,"fr")),aClasse=cl.length>0;
    const besoinClasse=["classe","discipline","periode","eleve","epreuve","mois"];
    const champsDoc=doc[3].filter(k=>!(besoinClasse.includes(k)&&!aClasse)&&!(k==="lecon"&&!D.lecons.length)&&!(k==="lclasse"&&!D.lecons.length)&&!(k==="jclasse"&&!uniq(D.activites.filter(a=>a.type==="Journal de classe"),"classe").length));
    let cur="",tm;
    const sel=(k,t,l)=>{if(!l.some(x=>String(x[0])===String(o[k])))o[k]=String(l[0]?l[0][0]:"");
      return `<label for="o_${k}">${t}</label><select id="o_${k}" data-k="${k}">${l.map(x=>`<option value="${E(x[0])}"${String(x[0])===String(o[k])?" selected":""}>${E(x[1])}</option>`).join("")}</select>`;};
    const txt=(k,t)=>`<label for="o_${k}">${t}</label><input id="o_${k}" data-k="${k}" value="${E(o[k]||"")}">`;
    function rendu(){
      const y=scrollY,cid=aClasse?+(o.classe||cl[0].id):0,epc=D.epreuves.filter(e=>e.classeId===cid),els=D.eleves.filter(e=>e.classeId===cid).sort(JE.tri);
      const tous=[["","Toutes"]],ms=[...new Set(D.presences.filter(p=>p.classeId===cid).map(p=>p.date.slice(0,7)))].sort().reverse();
      const F={
        classe:()=>sel("classe","Classe",cl.map(c=>[c.id,c.nom])),
        discipline:()=>sel("discipline","Discipline",tous.concat(uniq(epc,"discipline").map(x=>[x,x]))),
        periode:()=>sel("periode","Période",tous.concat(uniq(epc,"periode").map(x=>[x,x]))),
        eleve:()=>sel("eleve","Élève",[["","Tous les élèves"]].concat(els.map(e=>[e.id,JE.nom(e)]))),
        epreuve:()=>sel("epreuve","Épreuve",epc.length?epc.map(e=>[e.id,e.intitule+(e.discipline?" · "+e.discipline:"")]):[["","Aucune épreuve dans cette classe"]]),
        mois:()=>sel("mois","Mois",ms.length?ms.map(m=>[m,mois(m)]):[["","Aucune présence enregistrée"]]),
        lclasse:()=>sel("lclasse","Classe",tous.concat(uniq(D.lecons,"classe").map(x=>[x,x]))),
        jclasse:()=>sel("jclasse","Classe",tous.concat(uniq(D.activites.filter(a=>a.type==="Journal de classe"),"classe").map(x=>[x,x]))),
        lecon:()=>sel("lecon","Préparation",D.lecons.slice().sort((a,b)=>b.id-a.id).map(p=>[p.id,p.sujet+(p.classe?" · "+p.classe:"")])),
        titre:()=>txt("titre","Titre du rapport (facultatif)"),classe_txt:()=>txt("classe","Classe (facultatif)"),periode_txt:()=>txt("periode","Période (facultatif)"),
        contenu:()=>`<label for="o_contenu">${id==="rapport"?"Contenu du rapport (laissez vide pour un modèle à remplir à la main)":"Observations et recommandations (facultatif)"}</label><textarea id="o_contenu" data-k="contenu" style="min-height:120px">${E(o.contenu||"")}</textarea>`
      };
      lc.innerHTML=`<button class="btn neutre" id="rt">Documents</button><h3>${doc[1]}</h3>
      ${champsDoc.map(k=>F[k]()).join("")}
      <label class="chk"><input type="checkbox" id="o_vierge" data-k="vierge"${o.vierge?" checked":""}> Modèle vierge (à remplir à la main)</label>
      <div id="info"></div>
      <div class="rangee"><button class="btn or" id="pd">Exporter en PDF</button><button class="btn" id="wd">Télécharger (Word)</button></div>
      <div class="apercu" id="ap"></div>`;
      lc.querySelector("#rt").onclick=()=>{clearTimeout(tm);go(accueil);};
      lc.querySelector("#pd").onclick=()=>JE.pdf(cur);
      lc.querySelector("#wd").onclick=()=>telecharger(cur,doc[1]);
      maj();scrollTo(0,y);
    }
    function maj(){
      let h=null;
      if(!o.vierge){try{h=GEN[id](o);}catch(e){console.error(e);h=null;}}
      lc.querySelector("#info").innerHTML=!h&&!o.vierge?'<div class="info">Aucune donnée enregistrée pour ce choix : voici le modèle vierge à imprimer et remplir à la main.</div>':"";
      if(!h)h=VIDE[id](o);cur=h;lc.querySelector("#ap").innerHTML=h;
    }
    lc.oninput=lc.onchange=ev=>{const t=ev.target,k=t.dataset.k;if(!k)return;o[k]=t.type==="checkbox"?t.checked:t.value;
      if(k==="classe"&&ev.type==="change"){["discipline","periode","eleve","epreuve","mois"].forEach(x=>delete o[x]);rendu();return;}
      clearTimeout(tm);tm=setTimeout(maj,t.tagName==="INPUT"&&t.type==="text"||t.tagName==="TEXTAREA"?300:0);};
    rendu();
  }
  accueil();
};
})();
