// Module 8 : Modèles et aides pédagogiques (100 % hors connexion, dépend de window.JE)
(()=>{
const JE=window.JE,E=JE.esc,L=s=>E(s).replace(/\n/g,"<br>");
const ETAPES=[["revision","Révision"],["motivation","Motivation"],["annonce","Annonce du sujet"],["objectif","Objectif opérationnel"],["analyse","Analyse"],["synthese","Synthèse"],["controle","Contrôle"],["devoir","Devoir"]];
const BASE={annonce:"Écrire le titre de la leçon au tableau et le lire avec les élèves.",
  objectif:"Formuler 1 à 3 objectifs opérationnels avec des verbes d’action observables (voir « Objectifs opérationnels »)."};
const CANEVAS=[
["Canevas général","",{revision:"Poser 2 ou 3 questions orales sur la leçon précédente (prérequis). Corriger brièvement le devoir si nécessaire.",motivation:"Partir d’une situation concrète, d’une question ou d’un fait du quotidien en lien avec le sujet.",
 analyse:"Présenter les notions étape par étape : définitions, explications, exemples. Alterner les questions et les réponses des élèves.",synthese:"Faire dégager par les élèves les idées essentielles ; écrire le résumé au tableau et dans les cahiers.",
 controle:"Poser des questions ou donner un court exercice pour vérifier chaque objectif ; corriger collectivement.",devoir:"Donner un exercice d’application ou de recherche, adapté au niveau, à rendre à la prochaine séance."}],
["Mathématiques","Mathématiques",{revision:"Rappeler la propriété ou la technique de calcul vue précédemment par un court exercice au tableau.",motivation:"Proposer un problème concret (partage, mesure, argent, distance) qui conduit à la notion nouvelle.",
 analyse:"Traiter un exemple guidé au tableau, puis un deuxième avec les élèves : énoncé, méthode, calcul, vérification, conclusion.",synthese:"Écrire la règle ou la propriété et la méthode de résolution en étapes numérotées.",
 controle:"Donner 2 ou 3 exercices de difficulté croissante ; les faire résoudre au tableau et en classe ; repérer les erreurs fréquentes.",devoir:"Exercices d’entraînement semblables à ceux de la classe, plus un problème d’application."}],
["Sciences (physique, chimie, biologie)","Sciences",{revision:"Interroger sur les notions et le vocabulaire scientifique de la leçon précédente.",motivation:"Présenter un phénomène observable ou une expérience simple du quotidien et poser la question « pourquoi ? ».",
 analyse:"Observation (matériel, schéma ou expérience), hypothèses, vérification, interprétation, conclusion.",synthese:"Dégager la définition ou la loi, avec un schéma légendé.",
 controle:"Questions de compréhension, légende d’un schéma, petit calcul ou application.",devoir:"Compléter un schéma, résoudre un exercice ou chercher un exemple dans l’environnement."}],
["Français (grammaire, lecture, expression)","Français",{revision:"Rappeler la notion précédente par quelques phrases à analyser ou à corriger.",motivation:"Lire ou écouter une courte phrase ou un court texte qui met la notion en évidence.",
 analyse:"Observation d’un corpus de phrases ou d’un texte, repérage, manipulation (remplacer, transformer), puis formulation de la règle.",synthese:"Écrire la règle avec des exemples (« Je retiens »).",
 controle:"Exercice d’application : phrases à compléter, à transformer ou à analyser.",devoir:"Exercices d’application et rédaction de quelques phrases ou d’un court paragraphe employant la notion."}],
["Histoire et géographie","Histoire et géographie",{revision:"Questions sur les repères (dates, lieux, personnages, notions) de la leçon précédente.",motivation:"Présenter un document (carte, image, extrait, photographie) ou une question d’actualité liée au sujet.",
 analyse:"Étude de documents : lire, situer, décrire, puis expliquer les causes et les conséquences.",synthese:"Résumé structuré (frise, plan ou schéma) des faits et des notions essentielles.",
 controle:"Questions sur les documents, repérage sur la carte, mise en relation des causes et des conséquences.",devoir:"Rédiger une courte réponse, compléter une carte ou une frise."}]];
const VERBES=[["Connaître (mémoriser)","définir, citer, nommer, énumérer, identifier, reconnaître, rappeler, énoncer"],["Comprendre","expliquer, décrire, reformuler, illustrer, classer, comparer, résumer, interpréter"],
["Appliquer","calculer, résoudre, utiliser, appliquer, construire, mesurer, représenter, effectuer"],["Analyser","distinguer, différencier, relier, déduire, organiser, décomposer"],
["Évaluer","justifier, critiquer, juger, argumenter, vérifier, apprécier"],["Créer","concevoir, élaborer, produire, rédiger, proposer, planifier"]];
const QUESTIONS=[
["QCM","Parmi les propositions suivantes, laquelle … ?\nA. …  B. …  C. …  D. …","Quel organe produit l’insuline ?\nA. Le foie  B. Le pancréas  C. Le rein  D. L’estomac","Une seule bonne réponse, 3 ou 4 choix. Des mauvais choix plausibles et de longueur comparable. Éviter « toutes les réponses ci-dessus » et les négations."],
["Vrai ou faux","Dites si l’affirmation est vraie ou fausse. Si elle est fausse, corrigez-la.\n« … »","« Un triangle équilatéral a trois côtés égaux. »  Vrai / Faux","Une seule idée par affirmation. Éviter « toujours » et « jamais ». Demander la correction des affirmations fausses pour limiter le hasard."],
["Réponse courte","Citez / Définissez / Calculez … (en un mot ou en une phrase).","Définissez le mot « photosynthèse » en une phrase.","Réponse attendue précise et brève. Prévoir dans le corrigé les formulations acceptées."],
["Question ouverte","Expliquez / Justifiez / Comparez … en utilisant au moins deux arguments.","Expliquez pourquoi la déforestation menace la biodiversité (deux arguments).","Préciser ce qui est attendu (nombre d’arguments, longueur) et détailler le barème par idée."],
["Dictée","Texte de 5 à 8 lignes lu trois fois : lecture complète, dictée par groupes de mots, relecture.","Texte court contenant les difficultés étudiées en classe.","Choisir un texte adapté au niveau. Fixer à l’avance la façon de compter les fautes, selon les règles de votre établissement."],
["Travail pratique","Matériel : …\nConsignes : …\nTravail demandé : …\nProduction attendue : …","Réaliser et légender le schéma d’un montage, puis conclure en deux phrases.","Prévoir des critères observables (exactitude, soin, respect des consignes) et les points correspondants."]];
const BAREMES=[
["Interrogation sur 10","Q1 connaissance : 2 points\nQ2 compréhension : 3 points\nQ3 application : 5 points\nTotal : 10 points"],
["Interrogation ou devoir sur 20","Connaissances : 6 points\nCompréhension : 6 points\nApplication : 6 points\nPrésentation et langue : 2 points\nTotal : 20 points"],
["Examen : répartition par niveau","Connaissances : environ 30 %\nApplication : environ 50 %\nRaisonnement et justification : environ 20 %"],
["QCM","1 point par bonne réponse, 0 pour une mauvaise réponse ou une absence de réponse.\nNote = bonnes réponses × note maximale ÷ nombre de questions."],
["Conseils de notation","Le total des points doit être égal à la note maximale.\nIndiquer les points à côté de chaque question.\nDétailler dans le corrigé les points par étape (méthode, calcul, résultat).\nAccorder une partie des points aux réponses partiellement correctes."]];

const bip=m=>{const d=document.createElement("div");d.textContent=m;d.style.cssText="position:fixed;left:50%;transform:translateX(-50%);bottom:calc(env(safe-area-inset-bottom,0px) + 18px);z-index:99;background:#0B2545;color:#fff;border-radius:99px;padding:10px 18px";document.body.appendChild(d);setTimeout(()=>d.remove(),1800);};
async function copier(t){try{await navigator.clipboard.writeText(t);bip("Copié");}catch(e){const a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();try{document.execCommand("copy");bip("Copié");}catch(x){alert("Copie impossible sur cet appareil.");}a.remove();}}

window.MOD=window.MOD||{};
window.MOD[8]=function(box){
  const{lc,go}=JE.ecran(box);let T=[];
  const retour=`<button class="btn neutre" id="rt">Modèles et aides</button>`;
  const carte=(t,corps,copie)=>{const i=copie?T.push(copie)-1:-1;return `<div class="bloc2" style="white-space:normal"><b>${E(t)}</b>${corps}${i>=0?`<div style="margin-top:8px"><button class="btn neutre" data-c="${i}">Copier</button></div>`:""}</div>`;};
  const lier=()=>{lc.querySelector("#rt").onclick=()=>go(menu);lc.onclick=e=>{const b=e.target.closest("[data-c]");if(b)copier(T[+b.dataset.c]);};};
  const note=t=>`<p style="color:var(--doux);font-size:14px">${t}</p>`;

  function menu(){
    lc.innerHTML=`<p>Des modèles à adapter, utilisables sans connexion Internet.</p>${[["obj","Objectifs opérationnels","Modèle de formulation et verbes d’action"],["can","Canevas de leçon","Démarche en 8 étapes, par discipline"],["que","Modèles de questions","QCM, vrai ou faux, réponse courte, dictée…"],["bar","Modèles de barèmes","Répartition des points et conseils"]].map(x=>`<button class="item" data-s="${x[0]}"><b>${x[1]}</b><small>${x[2]}</small></button>`).join("")}`;
    const S={obj,can,que,bar};lc.querySelectorAll("[data-s]").forEach(b=>b.onclick=()=>go(S[b.dataset.s]));
  }
  function obj(){
    T=[];const m="À la fin de la leçon, l’élève sera capable de [verbe d’action] [contenu] [condition] [critère de réussite].";
    lc.innerHTML=retour+`<h3>Objectifs opérationnels</h3>${carte("Modèle de formulation",L(m),m)}
    ${carte("Exemples",L("• À la fin de la leçon, l’élève sera capable de définir la photosynthèse, sans document, en une phrase correcte.\n• … de résoudre une équation du premier degré à une inconnue, en 5 minutes, avec au moins 4 réponses justes sur 5.\n• … de rédiger un paragraphe de cinq lignes décrivant un paysage, en employant au moins trois adjectifs qualificatifs."))}
    <h3>Verbes d’action observables</h3>${VERBES.map(v=>carte(v[0],E(v[1]),v[1])).join("")}
    ${note("Un seul verbe observable par objectif. Évitez « savoir », « comprendre », « connaître » ou « apprécier », qu’on ne peut pas constater. Chaque objectif doit pouvoir être vérifié à l’étape Contrôle.")}`;lier();
  }
  function can(){
    lc.innerHTML=retour+`<h3>Canevas de leçon</h3>${note("Ce sont des suggestions à adapter à votre programme, à votre classe et à la leçon.")}${CANEVAS.map((c,i)=>`<button class="item" data-i="${i}"><b>${E(c[0])}</b><small>Révision, motivation, annonce, objectif, analyse, synthèse, contrôle, devoir</small></button>`).join("")}`;
    lc.querySelector("#rt").onclick=()=>go(menu);lc.querySelectorAll(".item").forEach(b=>b.onclick=()=>go(canevas,+b.dataset.i));
  }
  function canevas(i){
    T=[];const c=CANEVAS[i],st={...BASE,...c[2]},txt=c[0]+"\n\n"+ETAPES.map(e=>e[1]+" : "+st[e[0]]).join("\n\n");
    lc.innerHTML=`<button class="btn neutre" id="rt">Canevas</button><h3>${E(c[0])}</h3>${ETAPES.map((e,k)=>`<div class="bloc2" style="white-space:normal"><b>${k+1}. ${e[1]}</b>${E(st[e[0]])}</div>`).join("")}
    <div class="rangee"><button class="btn or" id="cr">Créer une préparation avec ce canevas</button><button class="btn neutre" data-c="0">Copier</button></div>`;T.push(txt);
    lc.querySelector("#rt").onclick=()=>go(can);lc.onclick=e=>{const b=e.target.closest("[data-c]");if(b)copier(T[0]);};
    lc.querySelector("#cr").onclick=async()=>{const p2=(await JE.lire("reglages",2))||{};
      await JE.sauver("lecons",{etablissement:p2.etablissement||"",enseignant:p2.enseignant||"",annee:p2.annee||JE.annee(),classe:"",discipline:c[1],chapitre:"",sujet:"À compléter · "+c[0],date:JE.today(),duree:"",...st});
      alert("Préparation créée. Retrouvez-la dans « Préparation des leçons » pour la compléter (sujet, classe, contenu).");};
  }
  function que(){
    T=[];lc.innerHTML=retour+`<h3>Modèles de questions</h3>${QUESTIONS.map(q=>carte(q[0],`<i>Modèle</i><br>${L(q[1])}<br><br><i>Exemple</i><br>${L(q[2])}<br><br><i>Conseils</i><br>${E(q[3])}`,q[1])).join("")}`;lier();
  }
  function bar(){
    T=[];lc.innerHTML=retour+`<h3>Modèles de barèmes</h3>${note("Propositions à adapter aux règles de votre établissement et du programme.")}${BAREMES.map(b=>carte(b[0],L(b[1]),b[1])).join("")}`;lier();
  }
  menu();
};
})();
