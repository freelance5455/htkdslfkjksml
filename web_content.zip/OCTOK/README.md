# OCTOK — Sosyal Medya Uygulaması

Gerçek backend + SQLite veritabanı + JWT kimlik doğrulama + medya yükleme + sosyal akış.

## Özellikler
- Kayıt / giriş / çıkış
- Profil ve kullanıcı adı
- Fotoğraf/video gönderisi yükleme
- Ana akış
- Beğeni
- Yorum
- Takip / takipten çıkma
- Kullanıcı arama
- Profil sayfası
- Bildirim altyapısı
- Basit DM altyapısı
- Admin uç noktaları
- Mobil uyumlu PWA arayüzü

## Çalıştırma
Node.js 20+ gerekir.

```bash
cd server
npm install
npm start
```

Sonra `http://localhost:3000` adresini aç.

Varsayılan admin hesabı `.env` ile belirlenir. İlk çalıştırmada otomatik oluşturulur.

## Android
Bu sürüm PWA olarak telefona kurulabilir. APK üretmek için Android Studio/SDK ile Capacitor veya WebView wrapper kullanılabilir. Bu ZIP hazır kaynak projedir; burada sahte APK iddiasında bulunulmamıştır.
