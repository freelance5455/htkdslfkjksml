/**
 * ترید یار — Worker همگام‌سازی نسخهٔ ۲ (Cloudflare KV + ادغام سمت سرور)
 *
 * جایگزین کدِ قدیمی که داده را در سرویس عمومی textdb.dev نگه می‌داشت (حجم محدود، بدون ادغام، گم‌شدن تیکت/کاربر).
 * - ذخیره در Cloudflare KV (دائمی)
 * - ادغام: تیکت/کاربر/پرداخت چند گوشی هم‌زمان گم نمی‌شود
 * - بکاپ ساعتی (۷ روز) + روزانه و ماهانه (برای همیشه)
 * - آدرس Worker عوض نمی‌شود؛ نیازی به ساخت دوبارهٔ APK نیست
 *
 * نصب (برای هر Worker):
 *  1) Cloudflare ← Storage & Databases ← KV ← Create namespace (نام: TRADYAR_KV)
 *  2) Worker ← Settings ← Bindings ← Add ← KV namespace ← Variable name: TRADYAR_KV ← همان namespace
 *  3) Worker ← Edit code ← این فایل را کامل جایگزین کن ← Deploy
 *  4) تست: باز کردن  https://آدرس-worker/health  باید {"ok":true,...} بدهد
 */
const KEY = 'tradyar_sync_data';
const MAX_BYTES = 8 * 1024 * 1024;
const VERSION = 'worker-2.0';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, x-tradyar-token',
  'Access-Control-Max-Age': '86400',
};
const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { ...CORS, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } });

/* ---- ادغام (همان منطق سرور Node) ---- */
const MERGE_ARRAYS = ['users', 'payments', 'tickets', 'discounts', 'notifications', 'settingsLog', 'vipPosts', 'tournaments', 'customPages', 'payouts', 'adminSalaries', 'ads', 'analysisLog'];
const MERGE_CAP = { notifications: 2000, settingsLog: 500, analysisLog: 2000 };
const MERGE_OBJECTS = ['settings', 'catalog', 'costs', 'referralProgram', 'vpnMsg', 'exchangesState'];
const SECRET_KEYS = ['aiKeysShared', 'aiKeysAdmin', 'aiKeys', 'irApiKey', 'apiKey', 'apiKeys', 'adminToken', 'vaultSecret'];

const msgKey = (m) => ((m && m.by) || '') + '|' + ((m && m.at) || 0) + '|' + String((m && m.text) || '').slice(0, 60) + '|' + (m && m.img ? 'i' : '');
function mergeTicket(a, b) {
  const newer = (b.updatedAt || 0) >= (a.updatedAt || 0) ? b : a, older = newer === b ? a : b;
  const del = new Set([].concat(a.delKeys || [], b.delKeys || []));
  const seen = new Set(), msgs = [];
  for (const m of [].concat(older.messages || [], newer.messages || [])) {
    if (!m) continue;
    const k = msgKey(m);
    if (seen.has(k) || del.has(k)) continue;
    seen.add(k); msgs.push(m);
  }
  msgs.sort((x, y) => (x.at || 0) - (y.at || 0));
  const out = { ...newer, messages: msgs, updatedAt: Math.max(a.updatedAt || 0, b.updatedAt || 0) };
  if (del.size) out.delKeys = Array.from(del).slice(-200);
  return out;
}
function scrub(o) {
  const strip = (x) => { if (x && typeof x === 'object') for (const k of SECRET_KEYS) if (k in x) delete x[k]; };
  strip(o); strip(o.data); strip(o.settings);
  if (o.data && typeof o.data === 'object') strip(o.data.settings);
  return o;
}
function validDoc(o) {
  if (!o || typeof o !== 'object' || Array.isArray(o)) return false;
  if (o.encrypted && (o.ct || o.enc)) return true;
  return o.v !== undefined;
}
function mergeDocs(a, b) {
  if (!a || !b || a.encrypted || b.encrypted) return b;
  const out = { ...a, ...b };
  for (const k of MERGE_ARRAYS) {
    const x = Array.isArray(a[k]) ? a[k] : [], y = Array.isArray(b[k]) ? b[k] : [];
    if (!x.length && !y.length) continue;
    const map = new Map();
    let loose = 0;
    for (const r of [...x, ...y]) {
      if (!r || typeof r !== 'object') continue;
      const id = r.id !== undefined && r.id !== null ? String(r.id) : '__n' + (loose++);
      const cur = map.get(id);
      if (!cur) { map.set(id, r); continue; }
      if (k === 'tickets') { map.set(id, mergeTicket(cur, r)); continue; }
      if ((r.updatedAt || 0) >= (cur.updatedAt || 0)) map.set(id, r);
    }
    let arr = [...map.values()];
    const cap = MERGE_CAP[k];
    if (cap && arr.length > cap) arr = arr.sort((m, n) => (n.updatedAt || n.at || n.createdAt || 0) - (m.updatedAt || m.at || m.createdAt || 0)).slice(0, cap);
    out[k] = arr;
  }
  for (const k of MERGE_OBJECTS) {
    if (a[k] && typeof a[k] === 'object' && b[k] && typeof b[k] === 'object') out[k] = (b[k].updatedAt || 0) >= (a[k].updatedAt || 0) ? b[k] : a[k];
    else if (a[k] && !b[k]) out[k] = a[k];
  }
  out.syncedAt = Math.max(a.syncedAt || 0, b.syncedAt || 0, Date.now());
  return out;
}
const stable = (o) => { const c = { ...o }; delete c.syncedAt; return JSON.stringify(c); };

export default {
  async fetch(request, env) {
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, '') || '/';
    if (path === '/health') return json({ ok: true, service: 'tradyar-worker', version: VERSION, kv: !!(env && env.TRADYAR_KV) });
    if (!env || !env.TRADYAR_KV) return json({ ok: false, error: 'kv_not_bound', hint: 'KV با نام TRADYAR_KV به Worker وصل نشده' }, 500);

    try {
      if (request.method === 'GET') {
        const text = await env.TRADYAR_KV.get(KEY);
        if (!text) return json({ ok: false, reason: 'no_data' });
        let doc = null;
        try { doc = JSON.parse(text); } catch { /* خراب */ }
        if (!validDoc(doc)) return json({ ok: false, reason: 'no_data' });
        return json({ ok: true, doc });
      }

      if (request.method === 'POST') {
        const len = parseInt(request.headers.get('content-length') || '0', 10);
        if (len > MAX_BYTES) return json({ ok: false, error: 'too_large' }, 413);
        const body = await request.text();
        if (body.length > MAX_BYTES) return json({ ok: false, error: 'too_large' }, 413);
        let incoming;
        try { incoming = JSON.parse(body); } catch { return json({ ok: false, error: 'bad_json' }, 400); }
        if (!validDoc(incoming)) return json({ ok: false, error: 'invalid_doc' }, 400);
        scrub(incoming);

        let prev = null, prevText = await env.TRADYAR_KV.get(KEY);
        if (prevText) { try { prev = JSON.parse(prevText); } catch { prev = null; } }
        const merged = prev && validDoc(prev) ? mergeDocs(prev, incoming) : incoming;

        // اگر چیزی تغییر نکرده، دوباره ننویس (سقف نوشتن KV صرفه‌جویی شود)
        if (prev && stable(prev) === stable(merged)) return json({ ok: true, size: prevText.length, unchanged: true });

        const out = JSON.stringify(merged);
        // بکاپ: ساعتی (۷ روز) + روزانه و ماهانه (برای همیشه، بدون انقضا)
        try {
          const iso = new Date().toISOString();
          const plan = [['backup_' + iso.slice(0, 13), 7 * 86400], ['daily_' + iso.slice(0, 10), 0], ['monthly_' + iso.slice(0, 7), 0]];
          if (prevText) for (const [k, ttl] of plan) {
            if (!(await env.TRADYAR_KV.get(k))) await env.TRADYAR_KV.put(k, prevText, ttl ? { expirationTtl: ttl } : undefined);
          }
        } catch { /* بکاپ اختیاری است */ }
        await env.TRADYAR_KV.put(KEY, out);
        return json({ ok: true, size: out.length });
      }
      return json({ ok: false, error: 'method_not_allowed' }, 405);
    } catch (e) {
      return json({ ok: false, error: String((e && e.message) || e) }, 500);
    }
  },
};
