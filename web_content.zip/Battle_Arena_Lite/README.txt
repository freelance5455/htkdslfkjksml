BATTLE ARENA LITE — Redmi 10A için HTML oyun prototipi

Başlatma:
1. ZIP dosyasını çıkar.
2. index.html dosyasını Chrome ile aç.
3. İlk ekranda BOTLARA KARŞI OYNA düğmesine bas.
4. Telefonda sol joystick hareket, sağ tarafta sürükleme bakış, ATEŞ düğmesi ateş içindir.
5. Bilgisayarda WASD + fare + sol tık; R şarjör doldurur, Shift hızlı koşar.

Çevrimiçi:
- ODA KUR ile oda kodu oluştur.
- Arkadaşın kendi cihazında aynı index.html dosyasını açıp kodu girerek katılmayı denesin.
- Çevrimiçi bağlantı PeerJS'nin herkese açık sinyal hizmetine ve ağ/WebRTC desteğine bağlıdır. Bu prototipte oyuncu konumları paylaşılır; tam PUBG ölçeğinde bir sunucu veya eşleştirme sistemi yoktur.
- Three.js ve PeerJS CDN üzerinden yüklendiği için ilk açılışta internet gerekir.

Telefon için performans:
- Gereksiz uygulamaları kapat.
- Chrome'da başka sekmeleri kapat.
- Bu hafif prototip; gerçek PUBG kadar büyük harita, animasyon veya içerik içermez.
