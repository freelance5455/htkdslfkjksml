# ساخت APK در Termux

پروژه WebView آماده است. مسیر پیشنهادی:

1. وارد Ubuntu با proot-distro شوید.
2. Java 17 و Android SDK را تنظیم کنید.
3. در پوشه `android` اجرا کنید:

```bash
gradle --version
gradle assembleDebug
```

APK خروجی:

`android/app/build/outputs/apk/debug/app-debug.apk`

برای Release، بعد از تنظیم keystore:

```bash
gradle assembleRelease
```

نکته: این پروژه برای WebView محلی ساخته شده و داده‌های اصلی را با IndexedDB داخل WebView نگه می‌دارد.
