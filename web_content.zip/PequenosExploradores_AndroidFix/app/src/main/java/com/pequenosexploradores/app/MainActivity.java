package com.pequenosexploradores.app;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingText = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Speaker(), "AndroidSpeaker");
        setContentView(webView);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("es", "ES"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
                if (!ttsReady) {
                    int fallback = tts.setLanguage(new Locale("es", "MX"));
                    ttsReady = fallback != TextToSpeech.LANG_MISSING_DATA && fallback != TextToSpeech.LANG_NOT_SUPPORTED;
                }
                if (ttsReady && pendingText != null) speak(pendingText);
            }
        });
        webView.loadUrl("file:///android_asset/web/index.html");
    }

    private void speak(String text) {
        if (text == null || text.trim().isEmpty()) return;
        if (!ttsReady) {
            pendingText = text;
            runOnUiThread(() -> Toast.makeText(this, "Activa o instala una voz en español en Ajustes > Texto a voz", Toast.LENGTH_LONG).show());
            return;
        }
        pendingText = null;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pequenos-exploradores");
    }

    private class Speaker {
        @JavascriptInterface public void say(String text) { runOnUiThread(() -> speak(text)); }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
