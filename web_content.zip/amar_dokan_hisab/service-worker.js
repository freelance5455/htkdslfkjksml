const CACHE='momin-store-v9';
const ASSETS=['./','./index.html','./manifest.webmanifest'];
self.addEventListener('install',event=>event.waitUntil((async()=>{const cache=await caches.open(CACHE);await cache.addAll(ASSETS);await self.skipWaiting();})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim();})()));
self.addEventListener('fetch',event=>{
  if(event.request.method!=='GET')return;
  const url=new URL(event.request.url);
  // Always check the network first for the app shell so a deployed fix is not hidden by an old cache.
  if(event.request.mode==='navigate'||url.pathname.endsWith('/index.html')){
    event.respondWith((async()=>{try{const fresh=await fetch(event.request);const cache=await caches.open(CACHE);cache.put(event.request,fresh.clone());return fresh;}catch(error){return (await caches.match(event.request))||caches.match('./index.html');}})());
    return;
  }
  event.respondWith((async()=>{const cached=await caches.match(event.request);if(cached)return cached;try{return await fetch(event.request);}catch(error){return caches.match('./index.html');}})());
});
