# Admin Delete User setup

The Admin → Users → Delete button removes the selected user's Supabase Auth account. Because the app must never contain the Supabase service-role key, deletion is performed by the `admin-delete-user` Edge Function.

## 1. Deploy the Edge Function

In Supabase Dashboard:

1. Open **Edge Functions**.
2. Create a function named exactly **`admin-delete-user`**.
3. Replace the generated code with:

`supabase/functions/admin-delete-user/index.ts`

4. Deploy it.

Supabase supplies `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to hosted Edge Functions. Do not copy either service-role secret into the APK or HTML.

## 2. Test the function from the app

Log in as an administrator, open **Users**, choose another user, then press **Delete**.

The app shows an in-app confirmation. After confirmation it calls:

`POST /functions/v1/admin-delete-user`

The function checks that the caller is an enabled administrator, prevents self-deletion, then deletes the selected Auth user.

The database schema has:

- `profiles.id -> auth.users.id ON DELETE CASCADE`
- `items.owner_id -> profiles.id ON DELETE CASCADE`

So the user's profile, items, and stored item history are removed when the Auth user is deleted.
