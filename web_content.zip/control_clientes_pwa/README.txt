# Control Clientes — PWA inicial

Esta es una aplicación web progresiva (PWA) inicial en español para registrar personas y controlar valeras/sesiones prepagadas. Puede servir para barbería, clases, lavados, terapias, paquetes de visitas u otros servicios.

## Incluye
- Registro de clientes, teléfono y notas.
- Saldo de sesiones disponibles y usadas.
- Descontar una sesión, registrar una visita sin descontar y recargar saldo.
- Historial de movimientos.
- Exportar movimientos a CSV y respaldar/restaurar todos los datos en JSON.
- Diseño adaptable a celular y escritorio.

## Importante
Los datos se guardan en el almacenamiento local del navegador del dispositivo. No hay cuenta, base de datos en la nube ni sincronización entre dispositivos. Exporta respaldos con frecuencia y evita guardar información sensible innecesaria.

## Cómo instalar en Android
Para que Chrome ofrezca “Instalar aplicación”, esta carpeta debe publicarse en un servidor HTTPS. Después:
1. Abre el enlace HTTPS en Chrome.
2. Abre el menú de tres puntos.
3. Toca “Instalar aplicación” o “Añadir a pantalla principal”.

El ZIP no es un APK y no se instala tocándolo como una app normal. Para crear un APK nativo firmado o añadir sincronización multiusuario se requiere un paso de desarrollo y publicación adicional.
