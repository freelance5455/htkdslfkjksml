# Class 10 Super Study App + AI Tutor

## What changed
- Added an AI Tutor tab to the existing study app.
- AI modes: solve a doubt, explain a topic, make short notes, generate 5 MCQs.
- Supports Mathematics, Science, Social Science, English, Hindi, and General.
- Gemini API calls run through `server.js`; the API key is not embedded in the HTML.
- Existing timetable, chapter practice, progress tracker, and built-in question bank remain in the HTML.

## Requirements
- Node.js 18 or newer
- A Gemini API key from Google AI Studio

## Run on Windows (PowerShell)
1. Put `class10_super_study_app_ai.html` and `server.js` in the same folder.
2. Open PowerShell in that folder.
3. Set your key for this PowerShell window:
   ```powershell
   $env:GEMINI_API_KEY="PASTE_YOUR_GEMINI_API_KEY_HERE"
   ```
4. Optional: choose a different supported Gemini model:
   ```powershell
   $env:GEMINI_MODEL="gemini-2.5-flash"
   ```
5. Start the server:
   ```powershell
   node server.js
   ```
6. Open `http://localhost:3000` in your browser. Do not open the HTML by double-clicking it, because the AI endpoint needs the local server.

## Security
- Never paste the API key into the HTML file, a screenshot, or a public repository.
- This sample backend is intended for local use. Before publishing it online, add authentication, rate limiting, quotas, and stronger request validation.
- API usage may cost money or be subject to your provider's limits.
