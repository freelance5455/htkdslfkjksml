Maple AI — Restored UI Package

This package restores the previously built ChatGPT-style mobile interface from the Sticky Header build rather than using the replacement interface from the latest package.

Preserved UI details:
- Chat-first layout
- Slide-out sidebar with New Chat and conversation history
- Pinned top header
- Rounded chat messages
- Icon-based copy and read-aloud controls
- System light/dark theme support
- No bottom navigation bar

Open index.html in a browser or use it as the web layer in an Android WebView project.

Model note: maple_tiny_lm_weights.pt is an experimental checkpoint and is not wired into chat inference. This package does not claim to include a finished large general-purpose AI model. The HTML app uses its existing local JavaScript dialogue engine.
