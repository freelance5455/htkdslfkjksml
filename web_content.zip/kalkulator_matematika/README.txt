PINO — KALKULATOR MATEMATIKA OFFLINE
================================

CARA MEMAKAI
1. Ekstrak file ZIP.
2. Buka folder public.
3. Buka index.html menggunakan browser.
4. Aplikasi dapat digunakan tanpa Python, Node.js, npm, server, atau internet.

FITUR
- Menu Aritmetika: penjumlahan, pengurangan, perkalian, pembagian, pangkat, dan modulus.
- Menu Geometri: luas persegi, persegi panjang, segitiga, lingkaran, jajar genjang, trapesium, belah ketupat, dan layang-layang.
- Pilihan satuan panjang untuk setiap ukuran geometri (km, hm, dam, m, dm, cm, mm).
- Pilihan satuan hasil luas secara terpisah (km², hm², dam², m², dm², cm², mm²).
- Konversi satuan luas otomatis, termasuk saat ukuran input menggunakan satuan yang berbeda.
- Trigonometri sin, cos, dan tan.
- Pilihan satuan sudut derajat dan radian melalui panel pilihan khusus PINO.
- Semua pemilih satuan menggunakan panel PINO yang menyesuaikan tema gelap/terang, bukan dialog pilihan bawaan browser/Android.
- Konfirmasi penghapusan seluruh riwayat menggunakan dialog khusus PINO.
- Validasi input angka dan penanganan pembagian/modulus dengan nol.
- Hasil perhitungan ditampilkan dengan jelas.
- Menu Riwayat menyimpan hasil aritmetika, geometri, dan trigonometri otomatis di localStorage browser.
- Hapus satu riwayat atau hapus seluruh riwayat.
- Tema gelap dan terang.
- Tampilan responsif untuk ponsel dan komputer.
- Tombol keluar dengan konfirmasi dan halaman penutup Pino.
- Browser tidak ditutup otomatis; tutup tab/jendela secara manual untuk keluar sepenuhnya.

CATATAN TRIGONOMETRI
- Mode derajat mengubah sudut ke radian sebelum dihitung oleh JavaScript.
- tan tidak terdefinisi ketika cos sudut bernilai 0.
- Untuk desimal, pengguna dapat menggunakan koma atau titik.

TENTANG RIWAYAT
Riwayat tersimpan pada browser dan perangkat yang sama. Riwayat dapat hilang
jika data situs/browser dihapus atau aplikasi dijalankan dalam mode privat.
