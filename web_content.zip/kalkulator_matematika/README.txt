PINO — KALKULATOR MATEMATIKA OFFLINE
================================

CARA MEMAKAI
1. Ekstrak file ZIP.
2. Buka folder public.
3. Buka index.html menggunakan browser.
4. Aplikasi dapat digunakan tanpa Python, Node.js, npm, server, atau internet.

FITUR
- Penjumlahan, pengurangan, perkalian, pembagian, pangkat, dan modulus.
- Trigonometri sin, cos, dan tan.
- Pilihan satuan sudut derajat dan radian.
- Validasi input angka dan penanganan pembagian/modulus dengan nol.
- Hasil perhitungan ditampilkan dengan jelas.
- Riwayat hitungan tersimpan otomatis di localStorage browser.
- Hapus satu riwayat atau hapus seluruh riwayat.
- Tema gelap dan terang.
- Tampilan responsif untuk ponsel dan komputer.
- Tombol keluar dengan konfirmasi dan halaman penutup Pino.
- Tombol untuk kembali dari halaman penutup ke kalkulator.
- Browser tidak ditutup otomatis; tutup tab/jendela secara manual untuk keluar sepenuhnya.

CATATAN TRIGONOMETRI
- Mode derajat mengubah sudut ke radian sebelum dihitung oleh JavaScript.
- tan tidak terdefinisi ketika cos sudut bernilai 0.
- Untuk desimal, pengguna dapat menggunakan koma atau titik.

TENTANG RIWAYAT
Riwayat tersimpan pada browser dan perangkat yang sama. Riwayat dapat hilang
jika data situs/browser dihapus atau aplikasi dijalankan dalam mode privat.
