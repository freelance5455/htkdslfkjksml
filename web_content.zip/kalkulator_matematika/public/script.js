const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const HISTORY_KEY = "pino-history-v1";
let toastTimer;

async function copyText(text) {
  const value = String(text ?? "").trim();
  if (!value) return showToast("Tidak ada hasil untuk disalin.");
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(value);
    } else {
      const temporary = document.createElement("textarea");
      temporary.value = value;
      temporary.setAttribute("readonly", "");
      temporary.style.position = "fixed";
      temporary.style.opacity = "0";
      document.body.appendChild(temporary);
      temporary.select();
      const copied = document.execCommand("copy");
      temporary.remove();
      if (!copied) throw new Error("Clipboard tidak tersedia");
    }
    showToast("✓ Hasil berhasil disalin.");
  } catch {
    showToast("Gagal menyalin. Coba lagi melalui browser.");
  }
}

document.addEventListener("click", event => {
  const copyButton = event.target.closest("[data-copy-value]");
  if (copyButton) { copyText(copyButton.dataset.copyValue); return; }
});

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2300);
}
function parseNumber(raw) {
  if (typeof raw !== "string" || !raw.trim()) return NaN;
  return Number(raw.trim().replace(",", "."));
}
function formatNumber(value) {
  if (!Number.isFinite(value)) return "Tidak terdefinisi";
  if (Object.is(value, -0) || Math.abs(value) < 1e-14) value = 0;
  return new Intl.NumberFormat("id-ID", { maximumFractionDigits: 10 }).format(value);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function readHistory() {
  try {
    const data = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}
function saveHistory(expression, result, category) {
  const items = readHistory();
  items.unshift({id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, expression, result, category, createdAt: new Date().toISOString()});
  localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 250)));
}
function switchTab(name) {
  $$(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  $("#arithmeticPanel").classList.toggle("hidden", name !== "arithmetic");
  $("#geometryPanel").classList.toggle("hidden", name !== "geometry");
  $("#trigPanel").classList.toggle("hidden", name !== "trig");
  $("#historyPanel").classList.toggle("hidden", name !== "history");
  if (name === "history") loadHistory();
}
$$(".tab").forEach(b => b.addEventListener("click", () => switchTab(b.dataset.tab)));

const operations = {
  add: {label:"Penjumlahan", symbol:"+", calc:(a,b)=>a+b},
  subtract: {label:"Pengurangan", symbol:"−", calc:(a,b)=>a-b},
  multiply: {label:"Perkalian", symbol:"×", calc:(a,b)=>a*b},
  divide: {label:"Pembagian", symbol:"÷", calc:(a,b)=>a/b},
  power: {label:"Pangkat", symbol:"^", calc:(a,b)=>Math.pow(a,b)},
  modulus: {label:"Modulus", symbol:"mod", calc:(a,b)=>a%b}
};
let activeOperation = "add";
function selectOperation(key) {
  if (!operations[key]) return;
  activeOperation = key;
  $("#arithmeticTitle").textContent = operations[key].label;
  $("#arithmeticResult").classList.add("hidden");
  $("#arithmeticForm").reset();
  $("#arithmeticScene").classList.add("hidden");
  $("#arithmeticCalculatorScene").classList.remove("hidden");
  $("#numberA").focus();
}
$$(".operation-card").forEach(button => button.addEventListener("click", () => selectOperation(button.dataset.operation)));
$("#backToOperations").addEventListener("click", () => {
  $("#arithmeticCalculatorScene").classList.add("hidden");
  $("#arithmeticScene").classList.remove("hidden");
});
$("#arithmeticForm").addEventListener("submit", event => {
  event.preventDefault();
  const a = parseNumber($("#numberA").value);
  const b = parseNumber($("#numberB").value);
  const key = activeOperation;
  const op = operations[key];
  if (!Number.isFinite(a) || !Number.isFinite(b)) return showToast("Masukkan kedua bilangan dengan benar.");
  if ((key === "divide" || key === "modulus") && b === 0) return showToast(key === "divide" ? "Error: Tidak dapat membagi dengan nol." : "Error: Modulus dengan nol tidak dapat dihitung.");
  const result = op.calc(a,b);
  if (!Number.isFinite(result)) return showToast("Error: Operasi menghasilkan nilai yang tidak valid.");
  const expression = `${formatNumber(a)} ${op.symbol} ${formatNumber(b)}`;
  const arithmeticCopy = `${expression} = ${formatNumber(result)}`;
  $("#arithmeticResult").innerHTML = `<div class="result-label">HASIL PERHITUNGAN</div><div class="result-value">${formatNumber(result)}</div><div class="result-detail">${escapeHtml(expression)} = ${formatNumber(result)}<br>${op.label}</div><div class="result-actions"><button class="copy-button" type="button" data-copy-value="${escapeHtml(arithmeticCopy)}">⧉ Salin</button></div>`;
  $("#arithmeticResult").classList.remove("hidden");
  try { saveHistory(expression, formatNumber(result), "Aritmetika"); showToast("✓ Hasil tersimpan di riwayat."); }
  catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
});

const shapes = {
  square: {title:"Persegi", formula:"s × s", fields:[{id:"s",label:"Panjang sisi"}], calc:v=>v.s*v.s},
  rectangle: {title:"Persegi panjang", formula:"p × l", fields:[{id:"p",label:"Panjang"},{id:"l",label:"Lebar"}], calc:v=>v.p*v.l},
  triangle: {title:"Segitiga", formula:"½ × a × t", fields:[{id:"a",label:"Alas"},{id:"t",label:"Tinggi"}], calc:v=>0.5*v.a*v.t},
  circle: {title:"Lingkaran", formula:"π × r²", fields:[{id:"r",label:"Jari-jari"}], calc:v=>Math.PI*v.r*v.r},
  parallelogram: {title:"Jajar genjang", formula:"a × t", fields:[{id:"a",label:"Alas"},{id:"t",label:"Tinggi"}], calc:v=>v.a*v.t},
  trapezoid: {title:"Trapesium", formula:"½ × (a + b) × t", fields:[{id:"a",label:"Sisi sejajar a"},{id:"b",label:"Sisi sejajar b"},{id:"t",label:"Tinggi"}], calc:v=>0.5*(v.a+v.b)*v.t},
  rhombus: {title:"Belah ketupat", formula:"½ × d₁ × d₂", fields:[{id:"d1",label:"Diagonal 1"},{id:"d2",label:"Diagonal 2"}], calc:v=>0.5*v.d1*v.d2},
  kite: {title:"Layang-layang", formula:"½ × d₁ × d₂", fields:[{id:"d1",label:"Diagonal 1"},{id:"d2",label:"Diagonal 2"}], calc:v=>0.5*v.d1*v.d2}
};
const lengthUnits = [
  {value:"km", label:"km", meters:1000},
  {value:"hm", label:"hm", meters:100},
  {value:"dam", label:"dam", meters:10},
  {value:"m", label:"m", meters:1},
  {value:"dm", label:"dm", meters:0.1},
  {value:"cm", label:"cm", meters:0.01},
  {value:"mm", label:"mm", meters:0.001}
];
const unitInfo = Object.fromEntries(lengthUnits.map(unit => [unit.value, unit]));
function formatArea(value) {
  if (!Number.isFinite(value)) return "Tidak terdefinisi";
  if (Object.is(value, -0) || Math.abs(value) < 1e-25) value = 0;
  return new Intl.NumberFormat("id-ID", {maximumFractionDigits:20}).format(value);
}
function unitOptions(selected = "cm") {
  return lengthUnits.map(unit => `<option value="${unit.value}" ${unit.value === selected ? "selected" : ""}>${unit.label}</option>`).join("");
}
const unitNames = {km:"Kilometer",hm:"Hektometer",dam:"Dekameter",m:"Meter",dm:"Desimeter",cm:"Sentimeter",mm:"Milimeter"};
let activeUnitSelect = null;
const angleUnits = [
  {value:"deg", symbol:"°", name:"Derajat", detail:"Satuan sudut dalam derajat"},
  {value:"rad", symbol:"rad", name:"Radian", detail:"Satuan sudut dalam radian"}
];
function updateUnitTrigger(select) {
  const trigger = document.querySelector(`[data-unit-select="${select.id}"]`);
  if (!trigger) return;
  if (select.id === "angleUnit") {
    const chosen = angleUnits.find(unit => unit.value === select.value);
    trigger.querySelector("strong").textContent = `${chosen.name} (${chosen.symbol})`;
    return;
  }
  const suffix = select.id === "geometryOutputUnit" ? "²" : "";
  trigger.querySelector("strong").textContent = `${select.value}${suffix}`;
}
function openUnitPicker(selectId) {
  const select = document.getElementById(selectId);
  if (!select) return;
  activeUnitSelect = select;
  const isArea = selectId === "geometryOutputUnit";
  const isAngle = selectId === "angleUnit";
  const options = isAngle ? angleUnits : lengthUnits.map(unit => ({value:unit.value,symbol:unit.value,name:unitNames[unit.value],detail:`Satuan ${isArea ? "luas" : "panjang"} (${unit.value}${isArea ? "²" : ""})`}));
  $("#unitPickerTitle").textContent = isAngle ? "Satuan sudut" : isArea ? "Satuan hasil luas" : "Satuan ukuran";
  $("#unitPickerDescription").textContent = isAngle ? "Pilih satuan sudut yang ingin digunakan." : isArea ? "Pilih satuan untuk menampilkan hasil perhitungan." : "Pilih satuan untuk ukuran yang dimasukkan.";
  $("#unitPicker").querySelector(".eyebrow").textContent = isAngle ? "PILIH SATUAN SUDUT" : "PILIH SATUAN";
  $("#unitPickerOptions").innerHTML = options.map(unit => {
    const selected = unit.value === select.value;
    return `<button class="unit-option ${selected ? "selected" : ""}" type="button" data-unit-value="${unit.value}" aria-pressed="${selected}"><span class="unit-option-symbol">${unit.symbol}${isArea ? "²" : ""}</span><span class="unit-option-copy"><strong>${unit.name}${isArea ? " persegi" : ""}</strong><small>${unit.detail}</small></span><span class="unit-option-check">${selected ? "✓" : ""}</span></button>`;
  }).join("");
  $("#unitPicker").classList.remove("hidden");
  document.body.classList.add("unit-picker-open");
}
function closeUnitPicker() {
  $("#unitPicker").classList.add("hidden");
  document.body.classList.remove("unit-picker-open");
  activeUnitSelect = null;
}
document.addEventListener("click", event => {
  const trigger = event.target.closest("[data-unit-select]");
  if (trigger) { openUnitPicker(trigger.dataset.unitSelect); return; }
  const option = event.target.closest("[data-unit-value]");
  if (option && activeUnitSelect) {
    activeUnitSelect.value = option.dataset.unitValue;
    updateUnitTrigger(activeUnitSelect);
    activeUnitSelect.dispatchEvent(new Event("change", {bubbles:true}));
    closeUnitPicker();
    return;
  }
});
$("#closeUnitPicker").addEventListener("click", closeUnitPicker);
$("#unitPicker").addEventListener("click", event => { if (event.target === $("#unitPicker")) closeUnitPicker(); });
document.addEventListener("keydown", event => { if (event.key === "Escape" && !$("#unitPicker").classList.contains("hidden")) closeUnitPicker(); });
let activeShape = null;
function selectShape(key) {
  activeShape = key;
  const shape = shapes[key];
  if (!shape) return;
  activeShape = key;
  $("#shapeTitle").textContent = shape.title;
  $("#shapeFormula").textContent = shape.formula;
  $("#geometryResult").classList.add("hidden");
  $("#geometryOutputUnit").value = "cm";
  updateUnitTrigger($("#geometryOutputUnit"));
  $("#geometryFields").innerHTML = shape.fields.map(field => `
    <label class="field">${field.label}
      <div class="measurement-input">
        <input id="field-${field.id}" name="${field.id}" type="text" inputmode="decimal" placeholder="Masukkan ${field.label.toLowerCase()}" autocomplete="off" required>
        <select id="unit-${field.id}" class="native-unit-select" aria-hidden="true" tabindex="-1">${unitOptions("cm")}</select>
        <button class="unit-picker-trigger compact-unit-trigger" type="button" data-unit-select="unit-${field.id}" aria-haspopup="dialog"><strong>cm</strong><span class="picker-chevron">⌄</span></button>
      </div>
    </label>`).join("");
  $("#shapeScene").classList.add("hidden");
  $("#calculatorScene").classList.remove("hidden");
}
$$(".shape-card").forEach(card => card.addEventListener("click", () => selectShape(card.dataset.shape)));
$("#backToShapes").addEventListener("click", () => {
  $("#calculatorScene").classList.add("hidden");
  $("#shapeScene").classList.remove("hidden");
});
$("#geometryForm").addEventListener("submit", event => {
  event.preventDefault();
  if (!activeShape) return;
  const shape = shapes[activeShape], values = {}, rawValues = {}, selectedUnits = {};
  for (const field of shape.fields) {
    const input = $(`#field-${field.id}`);
    const value = parseNumber(input.value);
    const unit = $(`#unit-${field.id}`).value;
    if (!Number.isFinite(value) || value <= 0) {
      showToast("Masukkan ukuran yang valid dan lebih dari 0.");
      input.focus();
      return;
    }
    rawValues[field.id] = value;
    selectedUnits[field.id] = unit;
    values[field.id] = value * unitInfo[unit].meters;
  }
  // Semua ukuran dikonversi ke meter terlebih dahulu agar satuan input boleh berbeda.
  const resultM2 = shape.calc(values);
  if (!Number.isFinite(resultM2)) return showToast("Hasil perhitungan tidak valid.");

  const outputUnit = $("#geometryOutputUnit").value;
  const outputFactor = unitInfo[outputUnit].meters ** 2;
  const convertedResult = resultM2 / outputFactor;
  const allSameUnit = Object.values(selectedUnits).every(unit => unit === Object.values(selectedUnits)[0]);
  let sourceResult, sourceUnit;
  if (allSameUnit) {
    const commonUnit = Object.values(selectedUnits)[0];
    sourceResult = shape.calc(rawValues);
    sourceUnit = `${commonUnit}²`;
  } else {
    sourceResult = resultM2;
    sourceUnit = "m²";
  }
  const inputSummary = shape.fields.map(field => `${field.label} ${formatNumber(rawValues[field.id])} ${selectedUnits[field.id]}`).join(", ");
  const expression = `${shape.title}: ${inputSummary}`;
  const equation = `${formatArea(sourceResult)} ${sourceUnit} = ${formatArea(convertedResult)} ${outputUnit}²`;
  const geometryCopy = `${formatArea(convertedResult)} ${outputUnit}²\n${equation}`;
  $("#geometryResult").innerHTML = `
    <div class="result-label">HASIL LUAS</div>
    <div class="result-value">${formatArea(convertedResult)} ${outputUnit}²</div>
    <div class="result-detail">${escapeHtml(shape.formula)}<br><strong class="conversion-equation">${escapeHtml(equation)}</strong></div>
    <div class="result-actions"><button class="copy-button" type="button" data-copy-value="${escapeHtml(geometryCopy)}">⧉ Salin</button></div>`;
  $("#geometryResult").classList.remove("hidden");
  try {
    saveHistory(expression, `${formatArea(convertedResult)} ${outputUnit}² (${equation})`, "Geometri");
    showToast("✓ Hasil geometri tersimpan di riwayat.");
  } catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
});

const trigHints = {sin:"sin(θ) = depan / miring",cos:"cos(θ) = samping / miring",tan:"tan(θ) = depan / samping"};
const trigTitles = {sin:"Sinus (sin)",cos:"Cosinus (cos)",tan:"Tangen (tan)"};
let activeTrigFunction = "sin";
function selectTrigFunction(fn) {
  if (!trigHints[fn]) return;
  activeTrigFunction = fn;
  $("#trigTitle").textContent = trigTitles[fn];
  $("#trigHint").textContent = trigHints[fn];
  $("#trigResult").classList.add("hidden");
  $("#trigForm").reset();
  $("#trigCalculatorScene").classList.remove("hidden");
  $("#trigScene").classList.add("hidden");
  $("#angleInput").focus();
}
$$(".trig-choice").forEach(button => button.addEventListener("click", () => selectTrigFunction(button.dataset.trig)));
$("#backToTrigFunctions").addEventListener("click", () => {
  $("#trigCalculatorScene").classList.add("hidden");
  $("#trigScene").classList.remove("hidden");
});
$("#trigForm").addEventListener("submit", event => {
  event.preventDefault();
  const angle = parseNumber($("#angleInput").value);
  if (!Number.isFinite(angle)) return showToast("Masukkan besar sudut yang valid.");
  const fn = activeTrigFunction;
  const unit = $("#angleUnit").value;
  const radians = unit === "deg" ? angle * Math.PI / 180 : angle;
  const cosine = Math.cos(radians);
  if (fn === "tan" && Math.abs(cosine) < 1e-12) {
    $("#trigResult").innerHTML = `<div class="result-label">HASIL TRIGONOMETRI</div><div class="result-value">Tidak terdefinisi</div><div class="result-detail">tan tidak terdefinisi ketika cos sudut bernilai 0.</div>`;
    $("#trigResult").classList.remove("hidden");
    showToast("Nilai tan pada sudut ini tidak terdefinisi.");
    return;
  }
  let result = Math[fn](radians);
  if (Math.abs(result) < 1e-14) result = 0;
  const unitLabel = unit === "deg" ? "°" : " rad";
  const expression = `${fn}(${formatNumber(angle)}${unitLabel})`;
  const trigCopy = `${expression} = ${formatNumber(result)}`;
  $("#trigResult").innerHTML = `<div class="result-label">HASIL TRIGONOMETRI</div><div class="result-value">${formatNumber(result)}</div><div class="result-detail">${escapeHtml(expression)} = ${formatNumber(result)}<br>Fungsi: ${fn.toUpperCase()}</div><div class="result-actions"><button class="copy-button" type="button" data-copy-value="${escapeHtml(trigCopy)}">⧉ Salin</button></div>`;
  $("#trigResult").classList.remove("hidden");
  try { saveHistory(expression, formatNumber(result), "Trigonometri"); showToast("✓ Hasil tersimpan di riwayat."); }
  catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
});

function parseIndonesianNumber(raw) {
  const normalized = String(raw).replace(/\./g, "").replace(",", ".");
  const value = Number(normalized);
  return Number.isFinite(value) ? value : NaN;
}
function compactIndonesianNumber(value) {
  const tiers = [
    {limit:1e3, name:"ribu"},
    {limit:1e6, name:"juta"},
    {limit:1e9, name:"miliar"},
    {limit:1e12, name:"triliun"},
    {limit:1e15, name:"kuadriliun"},
    {limit:1e18, name:"kuintiliun"},
    {limit:1e21, name:"sekstiliun"}
  ];
  const abs = Math.abs(value);
  if (abs < 1e3) return formatNumber(value);
  // Angka yang sangat besar tetap ditulis lengkap; jangan paksa pengguna membaca notasi ilmiah.
  if (abs >= 1e24) return formatArea(value);
  let tier = tiers[0];
  for (const candidate of tiers) {
    if (abs >= candidate.limit) tier = candidate;
    else break;
  }
  const scaled = value / tier.limit;
  return `${new Intl.NumberFormat("id-ID", {maximumFractionDigits:2}).format(scaled)} ${tier.name}`;
}
function historyResultView(rawResult) {
  const raw = String(rawResult ?? "");
  const match = raw.match(/^\s*(-?\d[\d.]*(?:,\d+)?)(?:\s*)(.*)$/);
  if (!match) return {headline:raw, exact:"", detail:"", compact:false};
  const value = parseIndonesianNumber(match[1]);
  if (!Number.isFinite(value)) return {headline:raw, exact:"", detail:"", compact:false};
  const remainder = match[2].trim();
  const equationMatch = remainder.match(/\(([^()]*)\)\s*$/);
  const suffix = (equationMatch ? remainder.slice(0, equationMatch.index) : remainder).trim();
  const equation = equationMatch ? equationMatch[1].trim() : "";
  const isLarge = Math.abs(value) >= 1e3;
  const exactValue = `${match[1]}${suffix ? ` ${suffix}` : ""}`;
  return {
    headline: `${compactIndonesianNumber(value)}${suffix ? ` ${suffix}` : ""}`,
    exact: isLarge ? exactValue : "",
    detail: equation && equation !== `${exactValue} = ${exactValue}` ? equation : "",
    compact: isLarge
  };
}
function loadHistory() {
  const items = readHistory();
  $("#historyStatus").textContent = `${items.length} catatan tersimpan di browser/perangkat ini.`;
  $("#emptyHistory").classList.toggle("hidden", items.length !== 0);
  $("#historyList").innerHTML = items.map(item => {
    const result = historyResultView(item.result);
    return `
    <article class="history-item">
      <div class="history-topline">
        <div class="history-main"><strong>${escapeHtml(item.expression)}</strong><small>${escapeHtml(item.category)} · ${new Date(item.createdAt).toLocaleString("id-ID")}</small></div>
        <button class="delete-button" type="button" data-delete="${escapeHtml(item.id)}" aria-label="Hapus riwayat ini">Hapus</button>
      </div>
      <div class="history-answer"><span class="history-answer-label">HASIL PERHITUNGAN</span><strong class="history-result">${escapeHtml(result.headline)}</strong>${result.exact ? `<small class="history-exact">Nilai lengkap: ${escapeHtml(result.exact)}</small>` : ""}${result.detail ? `<small class="history-exact">Konversi: ${escapeHtml(result.detail)}</small>` : ""}<div class="result-actions"><button class="copy-button" type="button" data-copy-value="${escapeHtml(`${item.expression}\n${item.result}`)}">⧉ Salin</button></div></div>
    </article>`;
  }).join("");
  $$("[data-delete]").forEach(button => button.addEventListener("click", () => {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(readHistory().filter(x => x.id !== button.dataset.delete)));
    loadHistory(); showToast("Riwayat dihapus.");
  }));
}
const historyConfirmDialog = $("#historyConfirmDialog");
$("#clearHistory").addEventListener("click", () => {
  if (readHistory().length === 0) { showToast("Belum ada riwayat untuk dihapus."); return; }
  historyConfirmDialog.classList.remove("hidden");
  $("#cancelClearHistory").focus();
});
$("#cancelClearHistory").addEventListener("click", () => historyConfirmDialog.classList.add("hidden"));
$("#confirmClearHistory").addEventListener("click", () => {
  localStorage.setItem(HISTORY_KEY, "[]");
  historyConfirmDialog.classList.add("hidden");
  loadHistory(); showToast("Semua riwayat dihapus.");
});
historyConfirmDialog.addEventListener("click", event => { if (event.target === historyConfirmDialog) historyConfirmDialog.classList.add("hidden"); });

try {
  if (localStorage.getItem("pino-theme") === "light") document.documentElement.classList.add("light");
} catch {}
$("#themeToggle").addEventListener("click", () => {
  document.documentElement.classList.toggle("light");
  try { localStorage.setItem("pino-theme", document.documentElement.classList.contains("light") ? "light" : "dark"); } catch {}
});
const exitDialog = $("#exitDialog");
$("#exitButton").addEventListener("click", () => {
  exitDialog.classList.remove("hidden");
  $("#cancelExit").focus();
});
$("#cancelExit").addEventListener("click", () => exitDialog.classList.add("hidden"));
$("#confirmExit").addEventListener("click", () => {
  exitDialog.classList.add("hidden");
  $(".app-shell").classList.add("hidden");
  $("#exitScreen").classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
});
exitDialog.addEventListener("click", e => { if (e.target === exitDialog) exitDialog.classList.add("hidden"); });
updateUnitTrigger($("#angleUnit"));

// Pilihan gambar Ryuko: satu gambar dipilih acak setiap easter egg dibuka.
// Gambar bawaan PNG tetap disertakan bersama enam gambar kiriman pengguna.
const ryukoImages = [
  "assets/ryuko-easter-egg.png",
  "assets/ryuko/ryuko-01.jpg",
  "assets/ryuko/ryuko-02.jpg",
  "assets/ryuko/ryuko-03.jpg",
  "assets/ryuko/ryuko-04.jpg",
  "assets/ryuko/ryuko-05.jpg",
  "assets/ryuko/ryuko-06.jpg"
];
let lastRyukoImageIndex = -1;
function showRandomRyukoImage() {
  const image = $("#ryukoEasterImage");
  if (!image || !ryukoImages.length) return;
  let nextIndex = Math.floor(Math.random() * ryukoImages.length);
  if (ryukoImages.length > 1) {
    while (nextIndex === lastRyukoImageIndex) {
      nextIndex = Math.floor(Math.random() * ryukoImages.length);
    }
  }
  lastRyukoImageIndex = nextIndex;
  image.src = ryukoImages[nextIndex];
}

// Easter egg: ketuk logo/nama PINO 3 kali dalam 2,5 detik.
// Delegasi pada document (capture) membuat ketukan tetap terdeteksi meski
// pengguna menyentuh ikon, teks, atau area kosong di dalam brand.
let logoTapCount = 0;
let logoTapTimer = null;
document.addEventListener("click", event => {
  const brandTapTarget = event.target.closest(".brand");
  if (!brandTapTarget) return;
  event.preventDefault();
  event.stopPropagation();
  logoTapCount += 1;
  clearTimeout(logoTapTimer);
  logoTapTimer = setTimeout(() => { logoTapCount = 0; }, 2500);
  if (logoTapCount >= 3) {
    logoTapCount = 0;
    clearTimeout(logoTapTimer);
    const easterEgg = $("#ryukoEasterEgg");
    if (easterEgg) {
      showRandomRyukoImage();
      easterEgg.classList.remove("hidden");
      document.body.classList.add("unit-picker-open");
    }
  }
}, true);
function closeRyukoEasterEgg() {
  $("#ryukoEasterEgg").classList.add("hidden");
  document.body.classList.remove("unit-picker-open");
}
$("#closeRyukoEgg").addEventListener("click", closeRyukoEasterEgg);
$("#ryukoEasterEgg").addEventListener("click", event => { if (event.target === $("#ryukoEasterEgg")) closeRyukoEasterEgg(); });
document.addEventListener("keydown", event => { if (event.key === "Escape" && !$("#ryukoEasterEgg").classList.contains("hidden")) closeRyukoEasterEgg(); });

loadHistory();
