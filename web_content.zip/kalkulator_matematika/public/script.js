const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const HISTORY_KEY = "pino-history-v1";
let toastTimer;

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2300);
}
function parseNumber(raw) {
  if (typeof raw !== "string" || !raw.trim()) return NaN;
  return Number(raw.trim().replace(",", "."));
}
function formatNumber(value) {
  if (!Number.isFinite(value)) return "Tidak terdefinisi";
  if (Object.is(value, -0) || Math.abs(value) < 1e-14) value = 0;
  return new Intl.NumberFormat("id-ID", { maximumFractionDigits: 10 }).format(value);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function readHistory() {
  try {
    const data = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}
function saveHistory(expression, result, category) {
  const items = readHistory();
  items.unshift({id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, expression, result, category, createdAt: new Date().toISOString()});
  localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 250)));
}
function switchTab(name) {
  $$(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  $("#arithmeticPanel").classList.toggle("hidden", name !== "arithmetic");
  $("#trigPanel").classList.toggle("hidden", name !== "trig");
  $("#historyPanel").classList.toggle("hidden", name !== "history");
  if (name === "history") loadHistory();
}
$$(".tab").forEach(b => b.addEventListener("click", () => switchTab(b.dataset.tab)));

const operations = {
  add: {label:"Penjumlahan", symbol:"+", calc:(a,b)=>a+b},
  subtract: {label:"Pengurangan", symbol:"−", calc:(a,b)=>a-b},
  multiply: {label:"Perkalian", symbol:"×", calc:(a,b)=>a*b},
  divide: {label:"Pembagian", symbol:"÷", calc:(a,b)=>a/b},
  power: {label:"Pangkat", symbol:"^", calc:(a,b)=>Math.pow(a,b)},
  modulus: {label:"Modulus", symbol:"mod", calc:(a,b)=>a%b}
};
$("#arithmeticForm").addEventListener("submit", event => {
  event.preventDefault();
  const a = parseNumber($("#numberA").value);
  const b = parseNumber($("#numberB").value);
  const key = $('input[name="operation"]:checked').value;
  const op = operations[key];
  if (!Number.isFinite(a) || !Number.isFinite(b)) return showToast("Masukkan kedua bilangan dengan benar.");
  if ((key === "divide" || key === "modulus") && b === 0) return showToast(key === "divide" ? "Error: Tidak dapat membagi dengan nol." : "Error: Modulus dengan nol tidak dapat dihitung.");
  const result = op.calc(a,b);
  if (!Number.isFinite(result)) return showToast("Error: Operasi menghasilkan nilai yang tidak valid.");
  const expression = `${formatNumber(a)} ${op.symbol} ${formatNumber(b)}`;
  $("#arithmeticResult").innerHTML = `<div class="result-label">HASIL PERHITUNGAN</div><div class="result-value">${formatNumber(result)}</div><div class="result-detail">${escapeHtml(expression)} = ${formatNumber(result)}<br>${op.label}</div>`;
  $("#arithmeticResult").classList.remove("hidden");
  try { saveHistory(expression, formatNumber(result), "Aritmetika"); showToast("✓ Hasil tersimpan di riwayat."); }
  catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
});

const trigHints = {sin:"sin(θ) = depan / miring",cos:"cos(θ) = samping / miring",tan:"tan(θ) = depan / samping"};
$$('input[name="trigFunction"]').forEach(input => input.addEventListener("change", () => {
  $("#trigHint").textContent = trigHints[$('input[name="trigFunction"]:checked').value];
}));
$("#trigForm").addEventListener("submit", event => {
  event.preventDefault();
  const angle = parseNumber($("#angleInput").value);
  if (!Number.isFinite(angle)) return showToast("Masukkan besar sudut yang valid.");
  const fn = $('input[name="trigFunction"]:checked').value;
  const unit = $("#angleUnit").value;
  const radians = unit === "deg" ? angle * Math.PI / 180 : angle;
  const cosine = Math.cos(radians);
  if (fn === "tan" && Math.abs(cosine) < 1e-12) {
    $("#trigResult").innerHTML = `<div class="result-label">HASIL TRIGONOMETRI</div><div class="result-value">Tidak terdefinisi</div><div class="result-detail">tan tidak terdefinisi ketika cos sudut bernilai 0.</div>`;
    $("#trigResult").classList.remove("hidden");
    showToast("Nilai tan pada sudut ini tidak terdefinisi.");
    return;
  }
  let result = Math[fn](radians);
  if (Math.abs(result) < 1e-14) result = 0;
  const unitLabel = unit === "deg" ? "°" : " rad";
  const expression = `${fn}(${formatNumber(angle)}${unitLabel})`;
  $("#trigResult").innerHTML = `<div class="result-label">HASIL TRIGONOMETRI</div><div class="result-value">${formatNumber(result)}</div><div class="result-detail">${escapeHtml(expression)} = ${formatNumber(result)}<br>Fungsi: ${fn.toUpperCase()}</div>`;
  $("#trigResult").classList.remove("hidden");
  try { saveHistory(expression, formatNumber(result), "Trigonometri"); showToast("✓ Hasil tersimpan di riwayat."); }
  catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
});

function loadHistory() {
  const items = readHistory();
  $("#historyStatus").textContent = `${items.length} catatan tersimpan di browser/perangkat ini.`;
  $("#emptyHistory").classList.toggle("hidden", items.length !== 0);
  $("#historyList").innerHTML = items.map(item => `
    <article class="history-item">
      <div class="history-main"><strong>${escapeHtml(item.expression)}</strong><small>${escapeHtml(item.category)} · ${new Date(item.createdAt).toLocaleString("id-ID")}</small></div>
      <div class="history-result">${escapeHtml(item.result)}</div>
      <button class="delete-button" type="button" data-delete="${escapeHtml(item.id)}">Hapus</button>
    </article>`).join("");
  $$("[data-delete]").forEach(button => button.addEventListener("click", () => {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(readHistory().filter(x => x.id !== button.dataset.delete)));
    loadHistory(); showToast("Riwayat dihapus.");
  }));
}
$("#clearHistory").addEventListener("click", () => {
  if (!confirm("Hapus semua riwayat hitungan di browser ini?")) return;
  localStorage.setItem(HISTORY_KEY, "[]"); loadHistory(); showToast("Semua riwayat dihapus.");
});

try {
  if (localStorage.getItem("pino-theme") === "light") document.documentElement.classList.add("light");
} catch {}
$("#themeToggle").addEventListener("click", () => {
  document.documentElement.classList.toggle("light");
  try { localStorage.setItem("pino-theme", document.documentElement.classList.contains("light") ? "light" : "dark"); } catch {}
});
const exitDialog = $("#exitDialog");
$("#exitButton").addEventListener("click", () => {
  exitDialog.classList.remove("hidden");
  $("#cancelExit").focus();
});
$("#cancelExit").addEventListener("click", () => exitDialog.classList.add("hidden"));
$("#confirmExit").addEventListener("click", () => {
  exitDialog.classList.add("hidden");
  $(".app-shell").classList.add("hidden");
  $("#exitScreen").classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
});
exitDialog.addEventListener("click", e => { if (e.target === exitDialog) exitDialog.classList.add("hidden"); });
loadHistory();
