
// Layar pembuka: animasi kroket 3D, lalu kroket melesat keluar saat disentuh.
const startupScreen = document.querySelector("#startupScreen");
const startupLoading = document.querySelector("#startupLoading");
const startupEnter = document.querySelector("#startupEnter");
if (startupScreen && startupLoading && startupEnter) {
  let startupReady = false;
  let startupLaunching = false;
  window.setTimeout(() => {
    // Ganti kedua tahap dalam satu task; prompt sudah siap tampil tanpa animasi fade-in.
    startupEnter.classList.remove("hidden");
    startupLoading.classList.add("hidden");
    startupReady = true;
    startupScreen.classList.add("is-ready");
    startupEnter.focus({ preventScroll: true });
  }, 3000);

  const launchPino = event => {
    if (!startupReady || startupLaunching) return;
    startupLaunching = true;
    startupScreen.classList.add("is-launching");
    startupEnter.disabled = true;
    window.setTimeout(() => {
      startupScreen.classList.add("is-leaving");
      window.setTimeout(() => startupScreen.remove(), 500);
    }, 850);
  };
  startupEnter.addEventListener("click", launchPino);
}

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const HISTORY_KEY = "pino-history-v1";
let toastTimer;

async function copyText(text) {
  const value = String(text ?? "").trim();
  if (!value) return showToast("Tidak ada hasil untuk disalin.");
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(value);
    } else {
      const temporary = document.createElement("textarea");
      temporary.value = value;
      temporary.setAttribute("readonly", "");
      temporary.style.position = "fixed";
      temporary.style.opacity = "0";
      document.body.appendChild(temporary);
      temporary.select();
      const copied = document.execCommand("copy");
      temporary.remove();
      if (!copied) throw new Error("Clipboard tidak tersedia");
    }
    showToast("✓ Hasil berhasil disalin.");
  } catch {
    showToast("Gagal menyalin. Coba lagi melalui browser.");
  }
}

document.addEventListener("click", event => {
  const copyButton = event.target.closest("[data-copy-value]");
  if (copyButton) { copyText(copyButton.dataset.copyValue); return; }
});

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2300);
}
function parseNumber(raw) {
  if (typeof raw !== "string" || !raw.trim()) return NaN;
  let value = raw.trim().replace(/\s/g, "");
  // Format Indonesia: titik untuk ribuan dan koma untuk desimal.
  if (value.includes(",") && value.includes(".")) {
    value = value.replace(/\./g, "").replace(",", ".");
  } else if (value.includes(",")) {
    value = value.replace(",", ".");
  } else if (/^[+-]?\d{1,3}(\.\d{3})+$/.test(value)) {
    value = value.replace(/\./g, "");
  }
  return Number(value);
}
function formatNumber(value) {
  if (!Number.isFinite(value)) return "Tidak terdefinisi";
  if (Object.is(value, -0) || Math.abs(value) < 1e-14) value = 0;
  return new Intl.NumberFormat("id-ID", { maximumFractionDigits: 10 }).format(value);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function readHistory() {
  try {
    const data = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    return Array.isArray(data) ? data : [];
  } catch { return []; }
}
function saveHistory(expression, result, category) {
  const items = readHistory();
  items.unshift({id: `${Date.now()}-${Math.random().toString(36).slice(2)}`, expression, result, category, createdAt: new Date().toISOString()});
  localStorage.setItem(HISTORY_KEY, JSON.stringify(items.slice(0, 250)));
}
function switchTab(name) {
  $$(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  $("#arithmeticPanel").classList.toggle("hidden", name !== "arithmetic");
  $("#geometryPanel").classList.toggle("hidden", name !== "geometry");
  $("#trigPanel").classList.toggle("hidden", name !== "trig");
  $("#historyPanel").classList.toggle("hidden", name !== "history");
  if (name === "history") loadHistory();
}
$$(".tab").forEach(b => b.addEventListener("click", () => switchTab(b.dataset.tab)));

const operations = {
  add: {label:"Penjumlahan", symbol:"+", calc:(a,b)=>a+b},
  subtract: {label:"Pengurangan", symbol:"−", calc:(a,b)=>a-b},
  multiply: {label:"Perkalian", symbol:"×", calc:(a,b)=>a*b},
  divide: {label:"Pembagian", symbol:"÷", calc:(a,b)=>a/b},
  power: {label:"Pangkat", symbol:"^", calc:(a,b)=>Math.pow(a,b)},
  percent: {label:"Persentase", symbol:"%", calc:(a,b)=>(a*b)/100}
};
let activeOperation = "add";
function selectOperation(key) {
  if (key === "calculator") {
    $("#arithmeticScene").classList.add("hidden");
    $("#arithmeticCalculatorScene").classList.add("hidden");
    $("#standaloneCalculatorScene").classList.remove("hidden");
    document.body.classList.add("standalone-calculator-open");
    resetPhoneCalculator();
    return;
  }
  if (!operations[key]) return;
  activeOperation = key;
  $("#arithmeticTitle").textContent = operations[key].label;
  $("#arithmeticResult").classList.add("hidden");
  $("#arithmeticForm").reset();
  $("#arithmeticScene").classList.add("hidden");
  $("#arithmeticCalculatorScene").classList.remove("hidden");
  $("#numberA").focus();
}
$$(".operation-card").forEach(button => button.addEventListener("click", () => selectOperation(button.dataset.operation)));
$("#backToOperations").addEventListener("click", () => {
  $("#arithmeticCalculatorScene").classList.add("hidden");
  $("#arithmeticScene").classList.remove("hidden");
});
$("#backFromStandaloneCalculator").addEventListener("click", () => {
  $("#standaloneCalculatorScene").classList.add("hidden");
  document.body.classList.remove("standalone-calculator-open");
  $("#arithmeticScene").classList.remove("hidden");
});
$("#arithmeticForm").addEventListener("submit", event => {
  event.preventDefault();
  const a = parseNumber($("#numberA").value);
  const b = parseNumber($("#numberB").value);
  const key = activeOperation;
  const op = operations[key];
  if (!Number.isFinite(a) || !Number.isFinite(b)) return showToast("Masukkan kedua bilangan dengan benar.");
  if ((key === "divide") && b === 0) return showToast("Error: Tidak dapat membagi dengan nol.");
  const result = op.calc(a,b);
  if (!Number.isFinite(result)) return showToast("Error: Operasi menghasilkan nilai yang tidak valid.");
  const expression = `${formatNumber(a)} ${op.symbol} ${formatNumber(b)}`;
  const arithmeticCopy = String(result);
  $("#arithmeticResult").innerHTML = `<div class="result-label">HASIL PERHITUNGAN</div><div class="result-value">${formatNumber(result)}</div><div class="result-detail">${escapeHtml(expression)} = ${formatNumber(result)}<br>${op.label}</div><div class="result-actions"><button class="copy-button" type="button" data-copy-value="${escapeHtml(arithmeticCopy)}">⧉ Salin</button></div>`;
  $("#arithmeticResult").classList.remove("hidden");
  try { saveHistory(expression, formatNumber(result), "Aritmetika"); showToast("✓ Hasil tersimpan di riwayat."); }
  catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
});


// Kalkulator mandiri: parser aritmetika tanpa eval(), dengan pratinjau langsung.
let phoneExpression = "";
let phoneHasResult = false;
let phoneLastResult = null;
function phonePretty(expr) {
  return expr.replace(/\*/g, "×").replace(/\//g, "÷").replace(/-/g, "−");
}
function renderPhoneCalculator(resultText, state = "valid") {
  $("#phoneExpression").textContent = phoneExpression ? phonePretty(phoneExpression) : "0";
  const result = $("#phoneResult");
  result.classList.toggle("phone-result-missing", state === "missing");
  result.classList.toggle("phone-result-idle", state === "idle");
  result.classList.toggle("phone-result-pending", state === "pending");
  if (state === "missing") {
    result.innerHTML = '<span class="phone-result-undefined">undefined</span><small class="phone-result-not-found">Tidak ditemukan</small>';
  } else {
    result.textContent = resultText;
  }
}
function resetPhoneCalculator() {
  phoneExpression = "";
  phoneHasResult = false;
  phoneLastResult = null;
  renderPhoneCalculator("0", "idle");
}
function evaluatePhoneExpression(source) {
  const compact = source.replace(/\s+/g, "");
  const tokens = compact.match(/(?:\d+(?:\.\d*)?|\.\d+)|[()+\-*/^%]/g) || [];
  if (!compact || tokens.join("") !== compact) throw new Error("Ekspresi tidak valid");
  let index = 0;
  const startsPrimary = token => token === "(" || (token !== undefined && /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(token));
  function primary() {
    const token = tokens[index++];
    if (token === "(") {
      const value = addSub();
      if (tokens[index++] !== ")") throw new Error("Kurung belum lengkap");
      return value;
    }
    if (!token || !/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(token)) throw new Error("Ekspresi belum lengkap");
    const value = Number(token);
    if (!Number.isFinite(value)) throw new Error("Angka tidak valid");
    return value;
  }
  function postfix() {
    let value = primary();
    let isPercent = false;
    while (tokens[index] === "%") {
      index++;
      value /= 100;
      isPercent = true;
    }
    return {value, isPercent};
  }
  // Pangkat bersifat right-associative dan didahulukan dari tanda minus.
  function power() {
    const left = postfix();
    if (tokens[index] === "^") {
      index++;
      const right = unary();
      const value = Math.pow(left.value, right.value);
      if (!Number.isFinite(value)) throw new Error("Hasil pangkat tidak terdefinisi");
      return {value, isPercent:false};
    }
    return left;
  }
  function unary() {
    if (tokens[index] === "+") { index++; return unary(); }
    if (tokens[index] === "-") { index++; const value = unary(); return {value:-value.value, isPercent:false}; }
    return power();
  }
  function multiplyDivide() {
    let first = unary();
    let value = first.value;
    let isStandalonePercent = first.isPercent;
    while (true) {
      const op = tokens[index];
      if (op === "*" || op === "/") {
        index++;
        const right = unary();
        if (op === "/" && right.value === 0) throw new Error("Pembagian dengan nol tidak terdefinisi");
        value = op === "*" ? value * right.value : value / right.value;
        isStandalonePercent = false;
      } else if (startsPrimary(op)) {
        // Perkalian implisit: 8(−9), 2(3+4), (2+3)(4), dan 2 3.
        const right = unary();
        value *= right.value;
        isStandalonePercent = false;
      } else break;
      if (!Number.isFinite(value)) throw new Error("Hasil tidak terdefinisi");
    }
    return {value, isStandalonePercent};
  }
  function addSub() {
    let value = multiplyDivide().value;
    while (tokens[index] === "+" || tokens[index] === "-") {
      const op = tokens[index++];
      const right = multiplyDivide();
      // Persen pada +/− dihitung terhadap nilai di sebelah kiri.
      const amount = right.isStandalonePercent ? value * right.value : right.value;
      value = op === "+" ? value + amount : value - amount;
      if (!Number.isFinite(value)) throw new Error("Hasil tidak terdefinisi");
    }
    return value;
  }
  const value = addSub();
  if (index !== tokens.length || !Number.isFinite(value)) throw new Error("Ekspresi tidak valid");
  return value;
}
function previewPhoneExpression() {
  if (!phoneExpression) {
    phoneLastResult = null;
    renderPhoneCalculator("0", "idle");
    return;
  }
  try {
    const value = evaluatePhoneExpression(phoneExpression);
    phoneLastResult = value;
    renderPhoneCalculator(formatNumber(value));
  } catch (error) {
    phoneLastResult = null;
    const reason = String(error?.message || "");
    const trulyUndefined = /tidak terdefinisi|dengan nol/i.test(reason);
    renderPhoneCalculator(trulyUndefined ? "" : "Periksa ekspresi", trulyUndefined ? "missing" : "pending");
  }
}
function phoneCalculate() {
  try {
    const value = evaluatePhoneExpression(phoneExpression);
    const formatted = formatNumber(value);
    phoneLastResult = value;
    renderPhoneCalculator(formatted);
    phoneHasResult = true;
    try { saveHistory(phonePretty(phoneExpression), formatted, "Kalkulator"); }
    catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
  } catch (error) {
    phoneLastResult = null;
    const reason = String(error?.message || "");
    const trulyUndefined = /tidak terdefinisi|dengan nol/i.test(reason);
    renderPhoneCalculator(trulyUndefined ? "" : "Periksa ekspresi", trulyUndefined ? "missing" : "pending");
    showToast(trulyUndefined ? "Hasil tidak terdefinisi." : "Ekspresi belum lengkap atau tidak valid. Periksa kembali.");
  }
}
function pressPhoneKey(key) {
  if (key === "AC") {
    phoneExpression = "";
    phoneHasResult = false;
    phoneLastResult = null;
    renderPhoneCalculator("0", "idle");
    return;
  }
  if (key === "BACK") {
    phoneExpression = phoneExpression.slice(0, -1);
    phoneHasResult = false;
    previewPhoneExpression();
    return;
  }
  if (key === "=") return phoneCalculate();
  if (phoneHasResult && /[0-9.(]/.test(key)) phoneExpression = "";
  phoneHasResult = false;
  if (key === ".") {
    const current = phoneExpression.split(/[+\-*/^()%]/).pop();
    if (current.includes(".")) return;
    if (!current || /[+\-*/^(]$/.test(phoneExpression)) key = "0.";
  }
  phoneExpression += key;
  previewPhoneExpression();
}
$$(".phone-key").forEach(button => button.addEventListener("click", () => pressPhoneKey(button.dataset.key)));
$("#copyPhoneResult").addEventListener("click", () => {
  if (phoneLastResult === null || !Number.isFinite(phoneLastResult)) return showToast("Tidak ada hasil untuk disalin.");
  copyText(String(phoneLastResult));
});
document.addEventListener("keydown", event => {
  if ($("#standaloneCalculatorScene").classList.contains("hidden")) return;
  if (/^[0-9.]$/.test(event.key)) { pressPhoneKey(event.key); event.preventDefault(); }
  else if (["+", "-", "*", "/", "^", "(", ")", "%"].includes(event.key)) { pressPhoneKey(event.key); event.preventDefault(); }
  else if (event.key === "Enter" || event.key === "=") { pressPhoneKey("="); event.preventDefault(); }
  else if (event.key === "Backspace") { pressPhoneKey("BACK"); event.preventDefault(); }
  else if (event.key === "Escape") { pressPhoneKey("AC"); event.preventDefault(); }
});

const shapes = {
  square: {title:"Persegi", areaFormula:"s × s", areaFields:[{id:"s",label:"Panjang sisi"}], area:v=>v.s*v.s, perimeterFormula:"4 × s", perimeterFields:[{id:"s",label:"Panjang sisi"}], perimeter:v=>4*v.s},
  rectangle: {title:"Persegi panjang", areaFormula:"p × l", areaFields:[{id:"p",label:"Panjang"},{id:"l",label:"Lebar"}], area:v=>v.p*v.l, perimeterFormula:"2 × (p + l)", perimeterFields:[{id:"p",label:"Panjang"},{id:"l",label:"Lebar"}], perimeter:v=>2*(v.p+v.l)},
  triangle: {title:"Segitiga", areaFormula:"½ × a × t", areaFields:[{id:"a",label:"Alas"},{id:"t",label:"Tinggi"}], area:v=>0.5*v.a*v.t, perimeterFormula:"a + b + c", perimeterFields:[{id:"a",label:"Sisi a"},{id:"b",label:"Sisi b"},{id:"c",label:"Sisi c"}], perimeter:v=>v.a+v.b+v.c},
  circle: {title:"Lingkaran", areaFormula:"π × r²", areaFields:[{id:"r",label:"Jari-jari"}], area:v=>Math.PI*v.r*v.r, perimeterFormula:"2 × π × r", perimeterFields:[{id:"r",label:"Jari-jari"}], perimeter:v=>2*Math.PI*v.r},
  parallelogram: {title:"Jajar genjang", areaFormula:"a × t", areaFields:[{id:"a",label:"Alas"},{id:"t",label:"Tinggi"}], area:v=>v.a*v.t, perimeterFormula:"2 × (a + b)", perimeterFields:[{id:"a",label:"Panjang alas"},{id:"b",label:"Panjang sisi miring"}], perimeter:v=>2*(v.a+v.b)},
  trapezoid: {title:"Trapesium", areaFormula:"½ × (a + b) × t", areaFields:[{id:"a",label:"Sisi sejajar a"},{id:"b",label:"Sisi sejajar b"},{id:"t",label:"Tinggi"}], area:v=>0.5*(v.a+v.b)*v.t, perimeterFormula:"a + b + c + d", perimeterFields:[{id:"a",label:"Sisi a"},{id:"b",label:"Sisi b"},{id:"c",label:"Sisi c"},{id:"d",label:"Sisi d"}], perimeter:v=>v.a+v.b+v.c+v.d},
  rhombus: {title:"Belah ketupat", areaFormula:"½ × d₁ × d₂", areaFields:[{id:"d1",label:"Diagonal 1"},{id:"d2",label:"Diagonal 2"}], area:v=>0.5*v.d1*v.d2, perimeterFormula:"4 × s", perimeterFields:[{id:"s",label:"Panjang sisi"}], perimeter:v=>4*v.s},
  kite: {title:"Layang-layang", areaFormula:"½ × d₁ × d₂", areaFields:[{id:"d1",label:"Diagonal 1"},{id:"d2",label:"Diagonal 2"}], area:v=>0.5*v.d1*v.d2, perimeterFormula:"2 × (a + b)", perimeterFields:[{id:"a",label:"Sisi pendek"},{id:"b",label:"Sisi panjang"}], perimeter:v=>2*(v.a+v.b)}
};
const lengthUnits = [
  {value:"km", label:"km", meters:1000},
  {value:"hm", label:"hm", meters:100},
  {value:"dam", label:"dam", meters:10},
  {value:"m", label:"m", meters:1},
  {value:"dm", label:"dm", meters:0.1},
  {value:"cm", label:"cm", meters:0.01},
  {value:"mm", label:"mm", meters:0.001}
];
const unitInfo = Object.fromEntries(lengthUnits.map(unit => [unit.value, unit]));
function formatArea(value) {
  if (!Number.isFinite(value)) return "Tidak terdefinisi";
  if (Object.is(value, -0) || Math.abs(value) < 1e-25) value = 0;
  return new Intl.NumberFormat("id-ID", {maximumFractionDigits:20}).format(value);
}
function unitOptions(selected = "cm") {
  return lengthUnits.map(unit => `<option value="${unit.value}" ${unit.value === selected ? "selected" : ""}>${unit.label}</option>`).join("");
}
const unitNames = {km:"Kilometer",hm:"Hektometer",dam:"Dekameter",m:"Meter",dm:"Desimeter",cm:"Sentimeter",mm:"Milimeter"};
let activeUnitSelect = null;
let geometryMode = "area";
const angleUnits = [
  {value:"deg", symbol:"°", name:"Derajat", detail:"Satuan sudut dalam derajat"},
  {value:"rad", symbol:"rad", name:"Radian", detail:"Satuan sudut dalam radian"}
];
function updateUnitTrigger(select) {
  const trigger = document.querySelector(`[data-unit-select="${select.id}"]`);
  if (!trigger) return;
  if (select.id === "angleUnit") {
    const chosen = angleUnits.find(unit => unit.value === select.value);
    trigger.querySelector("strong").textContent = `${chosen.name} (${chosen.symbol})`;
    return;
  }
  const suffix = select.id === "geometryOutputUnit" && geometryMode === "area" ? "²" : "";
  trigger.querySelector("strong").textContent = `${select.value}${suffix}`;
}
function openUnitPicker(selectId) {
  const select = document.getElementById(selectId);
  if (!select) return;
  activeUnitSelect = select;
  const isArea = selectId === "geometryOutputUnit" && geometryMode === "area";
  const isAngle = selectId === "angleUnit";
  const options = isAngle ? angleUnits : lengthUnits.map(unit => ({value:unit.value,symbol:unit.value,name:unitNames[unit.value],detail:`Satuan ${isArea ? "luas" : "panjang"} (${unit.value}${isArea ? "²" : ""})`}));
  $("#unitPickerTitle").textContent = isAngle ? "Satuan sudut" : isArea ? "Satuan hasil luas" : "Satuan ukuran";
  $("#unitPickerDescription").textContent = isAngle ? "Pilih satuan sudut yang ingin digunakan." : isArea ? "Pilih satuan untuk menampilkan hasil perhitungan." : "Pilih satuan untuk ukuran yang dimasukkan.";
  $("#unitPicker").querySelector(".eyebrow").textContent = isAngle ? "PILIH SATUAN SUDUT" : "PILIH SATUAN";
  $("#unitPickerOptions").innerHTML = options.map(unit => {
    const selected = unit.value === select.value;
    return `<button class="unit-option ${selected ? "selected" : ""}" type="button" data-unit-value="${unit.value}" aria-pressed="${selected}"><span class="unit-option-symbol">${unit.symbol}${isArea ? "²" : ""}</span><span class="unit-option-copy"><strong>${unit.name}${isArea ? " persegi" : ""}</strong><small>${unit.detail}</small></span><span class="unit-option-check">${selected ? "✓" : ""}</span></button>`;
  }).join("");
  $("#unitPicker").classList.remove("hidden");
  document.body.classList.add("unit-picker-open");
}
function closeUnitPicker() {
  $("#unitPicker").classList.add("hidden");
  document.body.classList.remove("unit-picker-open");
  activeUnitSelect = null;
}
document.addEventListener("click", event => {
  const trigger = event.target.closest("[data-unit-select]");
  if (trigger) { openUnitPicker(trigger.dataset.unitSelect); return; }
  const option = event.target.closest("[data-unit-value]");
  if (option && activeUnitSelect) {
    activeUnitSelect.value = option.dataset.unitValue;
    updateUnitTrigger(activeUnitSelect);
    activeUnitSelect.dispatchEvent(new Event("change", {bubbles:true}));
    closeUnitPicker();
    return;
  }
});
$("#closeUnitPicker").addEventListener("click", closeUnitPicker);
$("#unitPicker").addEventListener("click", event => { if (event.target === $("#unitPicker")) closeUnitPicker(); });
document.addEventListener("keydown", event => { if (event.key === "Escape" && !$("#unitPicker").classList.contains("hidden")) closeUnitPicker(); });
let activeShape = null;
function currentShapeFields(shape) {
  return geometryMode === "area" ? shape.areaFields : shape.perimeterFields;
}
function renderGeometryFields(shape) {
  const fields = currentShapeFields(shape);
  $("#geometryFields").innerHTML = fields.map(field => `
    <label class="field">${field.label}
      <div class="measurement-input">
        <input id="field-${field.id}" name="${field.id}" type="text" inputmode="decimal" placeholder="Masukkan ${field.label.toLowerCase()}" autocomplete="off" required>
        <select id="unit-${field.id}" class="native-unit-select" aria-hidden="true" tabindex="-1">${unitOptions("cm")}</select>
        <button class="unit-picker-trigger compact-unit-trigger" type="button" data-unit-select="unit-${field.id}" aria-haspopup="dialog"><strong>cm</strong><span class="picker-chevron">⌄</span></button>
      </div>
    </label>`).join("");
}
function setGeometryMode(mode) {
  if (!["area", "perimeter"].includes(mode)) return;
  geometryMode = mode;
  $$(".geometry-mode-button").forEach(button => {
    const selected = button.dataset.geometryMode === mode;
    button.classList.toggle("active", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
  const isArea = mode === "area";
  $("#shapeFormulaLabel").textContent = isArea ? "RUMUS LUAS" : "RUMUS KELILING";
  $("#geometryOutputLabel").textContent = isArea ? "Satuan hasil luas" : "Satuan hasil keliling";
  $("#geometryOutputHint").textContent = isArea ? "HASIL AKAN DITAMPILKAN DALAM" : "HASIL AKAN DITAMPILKAN DALAM";
  $("#geometrySubmitButton").innerHTML = `Hitung ${isArea ? "luas" : "keliling"} <span>→</span>`;
  $("#geometryResult").classList.add("hidden");
  updateUnitTrigger($("#geometryOutputUnit"));
  if (activeShape) {
    const shape = shapes[activeShape];
    $("#shapeFormula").textContent = isArea ? shape.areaFormula : shape.perimeterFormula;
    renderGeometryFields(shape);
  }
}
$$(".geometry-mode-button").forEach(button => button.addEventListener("click", () => setGeometryMode(button.dataset.geometryMode)));
function selectShape(key) {
  activeShape = key;
  const shape = shapes[key];
  if (!shape) return;
  $("#shapeTitle").textContent = shape.title;
  $("#shapeFormula").textContent = geometryMode === "area" ? shape.areaFormula : shape.perimeterFormula;
  $("#geometryResult").classList.add("hidden");
  $("#geometryOutputUnit").value = "cm";
  updateUnitTrigger($("#geometryOutputUnit"));
  renderGeometryFields(shape);
  $("#shapeScene").classList.add("hidden");
  $("#calculatorScene").classList.remove("hidden");
}
$$(".shape-card").forEach(card => card.addEventListener("click", () => selectShape(card.dataset.shape)));
$("#backToShapes").addEventListener("click", () => {
  $("#calculatorScene").classList.add("hidden");
  $("#shapeScene").classList.remove("hidden");
});
$("#geometryForm").addEventListener("submit", event => {
  event.preventDefault();
  if (!activeShape) return;
  const shape = shapes[activeShape], values = {}, rawValues = {}, selectedUnits = {};
  const fields = currentShapeFields(shape);
  for (const field of fields) {
    const input = $(`#field-${field.id}`);
    const value = parseNumber(input.value);
    const unit = $(`#unit-${field.id}`).value;
    if (!Number.isFinite(value) || value <= 0) {
      showToast("Masukkan ukuran yang valid dan lebih dari 0.");
      input.focus();
      return;
    }
    rawValues[field.id] = value;
    selectedUnits[field.id] = unit;
    values[field.id] = value * unitInfo[unit].meters;
  }
  const isArea = geometryMode === "area";
  const calculation = isArea ? shape.area : shape.perimeter;
  const formula = isArea ? shape.areaFormula : shape.perimeterFormula;
  // Konversi semua ukuran ke meter terlebih dahulu, termasuk input dengan satuan berbeda.
  const resultMeters = calculation(values);
  if (!Number.isFinite(resultMeters) || resultMeters < 0) return showToast("Hasil perhitungan tidak valid.");

  const outputUnit = $("#geometryOutputUnit").value;
  const outputFactor = isArea ? unitInfo[outputUnit].meters ** 2 : unitInfo[outputUnit].meters;
  const convertedResult = resultMeters / outputFactor;
  const allSameUnit = Object.values(selectedUnits).every(unit => unit === Object.values(selectedUnits)[0]);
  let sourceResult, sourceUnit;
  if (allSameUnit) {
    sourceResult = calculation(rawValues);
    sourceUnit = isArea ? `${Object.values(selectedUnits)[0]}²` : Object.values(selectedUnits)[0];
  } else {
    sourceResult = resultMeters;
    sourceUnit = isArea ? "m²" : "m";
  }
  const unitSuffix = isArea ? "²" : "";
  const inputSummary = fields.map(field => `${field.label} ${formatNumber(rawValues[field.id])} ${selectedUnits[field.id]}`).join(", ");
  const expression = `${shape.title} (${isArea ? "Luas" : "Keliling"}): ${inputSummary}`;
  const equation = `${formatArea(sourceResult)} ${sourceUnit} = ${formatArea(convertedResult)} ${outputUnit}${unitSuffix}`;
  const geometryCopy = `${formatArea(convertedResult)} ${outputUnit}${unitSuffix}`;
  $("#geometryResult").innerHTML = `
    <div class="result-label">HASIL ${isArea ? "LUAS" : "KELILING"}</div>
    <div class="result-value">${formatArea(convertedResult)} ${outputUnit}${unitSuffix}</div>
    <div class="result-detail">${escapeHtml(formula)}<br><strong class="conversion-equation">${escapeHtml(equation)}</strong></div>
    <div class="result-actions"><button class="copy-button" type="button" data-copy-value="${escapeHtml(geometryCopy)}">⧉ Salin</button></div>`;
  $("#geometryResult").classList.remove("hidden");
  try {
    saveHistory(expression, `${formatArea(convertedResult)} ${outputUnit}${unitSuffix} (${equation})`, "Geometri");
    showToast(`✓ Hasil ${isArea ? "luas" : "keliling"} tersimpan di riwayat.`);
  } catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
});

const trigHints = {
  sin:"sin(θ) = depan / miring", cos:"cos(θ) = samping / miring", tan:"tan(θ) = depan / samping",
  cosec:"cosec(θ) = 1 / sin(θ)", sec:"sec(θ) = 1 / cos(θ)", cot:"cot(θ) = 1 / tan(θ)"
};
const trigTitles = {
  sin:"Sinus (sin)", cos:"Cosinus (cos)", tan:"Tangen (tan)",
  cosec:"Kosekan (cosec)", sec:"Sekan (sec)", cot:"Kotangen (cot)"
};
let activeTrigFunction = "sin";
function selectTrigFunction(fn) {
  if (!trigHints[fn]) return;
  activeTrigFunction = fn;
  $("#trigTitle").textContent = trigTitles[fn];
  $("#trigHint").textContent = trigHints[fn];
  $("#trigResult").classList.add("hidden");
  $("#trigForm").reset();
  $("#trigCalculatorScene").classList.remove("hidden");
  $("#trigScene").classList.add("hidden");
  $("#angleInput").focus();
}
$$(".trig-choice").forEach(button => button.addEventListener("click", () => selectTrigFunction(button.dataset.trig)));
$("#backToTrigFunctions").addEventListener("click", () => {
  $("#trigCalculatorScene").classList.add("hidden");
  $("#trigScene").classList.remove("hidden");
});
$$(".quick-angle").forEach(button => button.addEventListener("click", () => {
  $("#angleInput").value = button.dataset.angle;
  $("#angleUnit").value = "deg";
  updateUnitTrigger($("#angleUnit"));
  $("#trigForm").requestSubmit();
}));
$("#trigForm").addEventListener("submit", event => {
  event.preventDefault();
  const angle = parseNumber($("#angleInput").value);
  if (!Number.isFinite(angle)) return showToast("Masukkan besar sudut yang valid.");
  const fn = activeTrigFunction;
  const unit = $("#angleUnit").value;
  const radians = unit === "deg" ? angle * Math.PI / 180 : angle;
  const sine = Math.sin(radians), cosine = Math.cos(radians);
  const nearZero = value => Math.abs(value) < 1e-12;
  let result, undefinedReason = "";
  if (fn === "sin") result = sine;
  else if (fn === "cos") result = cosine;
  else if (fn === "tan") {
    if (nearZero(cosine)) undefinedReason = "tan tidak terdefinisi ketika cos sudut bernilai 0.";
    else result = sine / cosine;
  } else if (fn === "cosec") {
    if (nearZero(sine)) undefinedReason = "cosec tidak terdefinisi ketika sin sudut bernilai 0.";
    else result = 1 / sine;
  } else if (fn === "sec") {
    if (nearZero(cosine)) undefinedReason = "sec tidak terdefinisi ketika cos sudut bernilai 0.";
    else result = 1 / cosine;
  } else if (fn === "cot") {
    if (nearZero(sine)) undefinedReason = "cot tidak terdefinisi ketika sin sudut bernilai 0.";
    else result = cosine / sine;
  }
  const unitLabel = unit === "deg" ? "°" : " rad";
  const expression = `${fn}(${formatNumber(angle)}${unitLabel})`;
  if (undefinedReason) {
    $("#trigResult").innerHTML = `<div class="result-label">HASIL TRIGONOMETRI</div><div class="result-value">Tidak terdefinisi</div><div class="result-detail">${escapeHtml(undefinedReason)}</div>`;
    $("#trigResult").classList.remove("hidden");
    showToast(`Nilai ${fn} pada sudut ini tidak terdefinisi.`);
    return;
  }
  if (Math.abs(result) < 1e-14) result = 0;
  const trigCopy = String(result);
  $("#trigResult").innerHTML = `<div class="result-label">HASIL TRIGONOMETRI</div><div class="result-value">${formatNumber(result)}</div><div class="result-detail">${escapeHtml(expression)} = ${formatNumber(result)}<br>Fungsi: ${fn.toUpperCase()}</div><div class="result-actions"><button class="copy-button" type="button" data-copy-value="${escapeHtml(trigCopy)}">⧉ Salin</button></div>`;
  $("#trigResult").classList.remove("hidden");
  try { saveHistory(expression, formatNumber(result), "Trigonometri"); showToast("✓ Hasil tersimpan di riwayat."); }
  catch { showToast("Hasil dihitung, tetapi riwayat gagal disimpan."); }
});

function parseIndonesianNumber(raw) {
  const normalized = String(raw).replace(/\./g, "").replace(",", ".");
  const value = Number(normalized);
  return Number.isFinite(value) ? value : NaN;
}
function compactIndonesianNumber(value) {
  const tiers = [
    {limit:1e3, name:"ribu"},
    {limit:1e6, name:"juta"},
    {limit:1e9, name:"miliar"},
    {limit:1e12, name:"triliun"},
    {limit:1e15, name:"kuadriliun"},
    {limit:1e18, name:"kuintiliun"},
    {limit:1e21, name:"sekstiliun"}
  ];
  const abs = Math.abs(value);
  if (abs < 1e3) return formatNumber(value);
  // Angka yang sangat besar tetap ditulis lengkap; jangan paksa pengguna membaca notasi ilmiah.
  if (abs >= 1e24) return formatArea(value);
  let tier = tiers[0];
  for (const candidate of tiers) {
    if (abs >= candidate.limit) tier = candidate;
    else break;
  }
  const scaled = value / tier.limit;
  return `${new Intl.NumberFormat("id-ID", {maximumFractionDigits:2}).format(scaled)} ${tier.name}`;
}
function historyResultView(rawResult) {
  const raw = String(rawResult ?? "");
  const match = raw.match(/^\s*(-?\d[\d.]*(?:,\d+)?)(?:\s*)(.*)$/);
  if (!match) return {headline:raw, exact:"", detail:"", compact:false};
  const value = parseIndonesianNumber(match[1]);
  if (!Number.isFinite(value)) return {headline:raw, exact:"", detail:"", compact:false};
  const remainder = match[2].trim();
  const equationMatch = remainder.match(/\(([^()]*)\)\s*$/);
  const suffix = (equationMatch ? remainder.slice(0, equationMatch.index) : remainder).trim();
  const equation = equationMatch ? equationMatch[1].trim() : "";
  const isLarge = Math.abs(value) >= 1e3;
  const exactValue = `${match[1]}${suffix ? ` ${suffix}` : ""}`;
  return {
    headline: `${compactIndonesianNumber(value)}${suffix ? ` ${suffix}` : ""}`,
    exact: isLarge ? exactValue : "",
    detail: equation && equation !== `${exactValue} = ${exactValue}` ? equation : "",
    compact: isLarge
  };
}
function loadHistory() {
  const items = readHistory();
  $("#historyStatus").textContent = `${items.length} catatan tersimpan di browser/perangkat ini.`;
  $("#emptyHistory").classList.toggle("hidden", items.length !== 0);
  $("#historyList").innerHTML = items.map(item => {
    const result = historyResultView(item.result);
    return `
    <article class="history-item">
      <div class="history-topline">
        <div class="history-main"><strong>${escapeHtml(item.expression)}</strong><small>${escapeHtml(item.category)} · ${new Date(item.createdAt).toLocaleString("id-ID")}</small></div>
        <button class="delete-button" type="button" data-delete="${escapeHtml(item.id)}" aria-label="Hapus riwayat ini">Hapus</button>
      </div>
      <div class="history-answer"><span class="history-answer-label">HASIL PERHITUNGAN</span><strong class="history-result">${escapeHtml(result.headline)}</strong>${result.exact ? `<small class="history-exact">Nilai lengkap: ${escapeHtml(result.exact)}</small>` : ""}${result.detail ? `<small class="history-exact">Konversi: ${escapeHtml(result.detail)}</small>` : ""}<div class="result-actions"><button class="copy-button" type="button" data-copy-value="${escapeHtml(result.headline)}">⧉ Salin</button></div></div>
    </article>`;
  }).join("");
  $$("[data-delete]").forEach(button => button.addEventListener("click", () => {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(readHistory().filter(x => x.id !== button.dataset.delete)));
    loadHistory(); showToast("Riwayat dihapus.");
  }));
}
const historyConfirmDialog = $("#historyConfirmDialog");
$("#clearHistory").addEventListener("click", () => {
  if (readHistory().length === 0) { showToast("Belum ada riwayat untuk dihapus."); return; }
  historyConfirmDialog.classList.remove("hidden");
  $("#cancelClearHistory").focus();
});
$("#cancelClearHistory").addEventListener("click", () => historyConfirmDialog.classList.add("hidden"));
$("#confirmClearHistory").addEventListener("click", () => {
  localStorage.setItem(HISTORY_KEY, "[]");
  historyConfirmDialog.classList.add("hidden");
  loadHistory(); showToast("Semua riwayat dihapus.");
});
historyConfirmDialog.addEventListener("click", event => { if (event.target === historyConfirmDialog) historyConfirmDialog.classList.add("hidden"); });

const themeButton = $("#themeToggle");
const themeModes = [
  { value: "dark", label: "Gelap", icon: "◐" },
  { value: "light", label: "Cerah", icon: "☼" },
  { value: "custom", label: "Custom", icon: "▣" }
];
function applyTheme(mode) {
  const safeMode = themeModes.some(item => item.value === mode) ? mode : "dark";
  document.documentElement.classList.remove("light", "custom");
  if (safeMode !== "dark") document.documentElement.classList.add(safeMode);
  const current = themeModes.find(item => item.value === safeMode);
  themeButton.textContent = current.icon;
  themeButton.title = `Tema: ${current.label} (ketuk untuk mengganti)`;
  themeButton.setAttribute("aria-label", `Tema: ${current.label}. Ketuk untuk mengganti tema`);
  try { localStorage.setItem("pino-theme", safeMode); } catch {}
}
let savedTheme = "dark";
try { savedTheme = localStorage.getItem("pino-theme") || "dark"; } catch {}
applyTheme(savedTheme);
themeButton.addEventListener("click", () => {
  const currentMode = themeModes.findIndex(item => document.documentElement.classList.contains(item.value) || (item.value === "dark" && !document.documentElement.classList.contains("light") && !document.documentElement.classList.contains("custom")));
  applyTheme(themeModes[(currentMode + 1) % themeModes.length].value);
});
const exitDialog = $("#exitDialog");
$("#exitButton").addEventListener("click", () => {
  exitDialog.classList.remove("hidden");
  $("#cancelExit").focus();
});
$("#cancelExit").addEventListener("click", () => exitDialog.classList.add("hidden"));
$("#confirmExit").addEventListener("click", () => {
  exitDialog.classList.add("hidden");
  $(".app-shell").classList.add("hidden");
  $("#exitScreen").classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
});
exitDialog.addEventListener("click", e => { if (e.target === exitDialog) exitDialog.classList.add("hidden"); });
updateUnitTrigger($("#angleUnit"));

// Pilihan gambar Ryuko: satu gambar dipilih acak setiap easter egg dibuka.
// Gambar bawaan PNG tetap disertakan bersama enam gambar kiriman pengguna.
const ryukoImages = [
  "assets/ryuko-easter-egg.png",
  "assets/ryuko/ryuko-01.jpg",
  "assets/ryuko/ryuko-02.jpg",
  "assets/ryuko/ryuko-03.jpg",
  "assets/ryuko/ryuko-04.jpg",
  "assets/ryuko/ryuko-05.jpg",
  "assets/ryuko/ryuko-06.jpg"
];
let lastRyukoImageIndex = -1;
function showRandomRyukoImage() {
  const image = $("#ryukoEasterImage");
  if (!image || !ryukoImages.length) return;
  let nextIndex = Math.floor(Math.random() * ryukoImages.length);
  if (ryukoImages.length > 1) {
    while (nextIndex === lastRyukoImageIndex) {
      nextIndex = Math.floor(Math.random() * ryukoImages.length);
    }
  }
  lastRyukoImageIndex = nextIndex;
  image.src = ryukoImages[nextIndex];
}

// Easter egg: ketuk logo/nama PINO 3 kali dalam 2,5 detik.
// Delegasi pada document (capture) membuat ketukan tetap terdeteksi meski
// pengguna menyentuh ikon, teks, atau area kosong di dalam brand.
let logoTapCount = 0;
let logoTapTimer = null;
document.addEventListener("click", event => {
  const brandTapTarget = event.target.closest(".brand");
  if (!brandTapTarget) return;
  event.preventDefault();
  event.stopPropagation();
  logoTapCount += 1;
  clearTimeout(logoTapTimer);
  logoTapTimer = setTimeout(() => { logoTapCount = 0; }, 2500);
  if (logoTapCount >= 3) {
    logoTapCount = 0;
    clearTimeout(logoTapTimer);
    const easterEgg = $("#ryukoEasterEgg");
    if (easterEgg) {
      showRandomRyukoImage();
      easterEgg.classList.remove("hidden");
      document.body.classList.add("unit-picker-open");
    }
  }
}, true);
function closeRyukoEasterEgg() {
  $("#ryukoEasterEgg").classList.add("hidden");
  document.body.classList.remove("unit-picker-open");
}
$("#closeRyukoEgg").addEventListener("click", closeRyukoEasterEgg);
$("#ryukoEasterEgg").addEventListener("click", event => { if (event.target === $("#ryukoEasterEgg")) closeRyukoEasterEgg(); });
document.addEventListener("keydown", event => { if (event.key === "Escape" && !$("#ryukoEasterEgg").classList.contains("hidden")) closeRyukoEasterEgg(); });

loadHistory();
