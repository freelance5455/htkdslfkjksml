package com.blockbreaker2000.game;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebSettings;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  getWindow().setFlags(1024,1024);
  WebView web = new WebView(this);
  web.setBackgroundColor(0xff080b20);
  WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
  web.setOverScrollMode(View.OVER_SCROLL_NEVER);
  web.setWebChromeClient(new WebChromeClient());
  setContentView(web); web.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){ super.onBackPressed(); }
}
