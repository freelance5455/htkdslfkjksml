PAGE PRO V4.1 — PostgreSQL

Projet serveur réel: Node.js + Express + PostgreSQL.
Fonctions: compte, connexion, création de Page, Page publique, publications, recherche.

Pour Render: le fichier render.yaml prépare un Web Service et une base PostgreSQL.
Ce ZIP n'est pas encore un APK. Il faut d'abord le déployer sur un serveur public, puis connecter l'APK à son URL.
