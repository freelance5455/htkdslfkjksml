# ROTA GAYRİMENKUL – Portföy Yönetimi (PWA)

Bu proje Android telefonda Chrome üzerinden kurulabilen, çevrimdışı yerel portföy kayıtları tutan bir web uygulamasıdır.

## Özellikler
- İlan ekleme, düzenleme, silme ve arama
- Satılık/kiralık, fiyat, oda, m², mahalle, bina yaşı, kat
- Ev sahibi ve çalışan iletişim alanları
- Fotoğraf ve video dosyalarını cihazdaki IndexedDB veritabanında saklama
- Van merkezli Esri uydu haritasında haritaya dokunarak koordinat seçme (harita döşemeleri internet ister)
- İlan metni ve destekleyen cihazlarda medya dosyalarıyla paylaşım
- JSON yedek dışa/içe aktarma
- PWA önbelleği: uygulama arayüzü internet olmadan açılır

## Çalıştırma
Tarayıcı güvenlik kısıtlamaları nedeniyle dosyaya çift tıklayarak açmak yerine bir web sunucusunda yayınlayın. En kolay yöntem, klasörü HTTPS destekleyen statik hosting'e yüklemektir. Yerel bilgisayarda Python kuruluysa klasörde `python -m http.server 8000` çalıştırıp `http://localhost:8000` adresini açabilirsiniz.

Android: HTTPS adresini Chrome'da açın → menü → “Uygulamayı yükle” veya “Ana ekrana ekle”.

## ÖNEMLİ SINIRLAR
1. Bu sürüm kayıtları her telefonda ayrı tutar. Bir çalışanın eklediği ilan diğer çalışanların telefonuna kendiliğinden gitmez. Ortak ekip portföyü için Firebase/Supabase gibi bir sunucu, kullanıcı girişi, dosya depolama ve çevrimdışı senkronizasyon ayrıca yapılandırılmalıdır. Sunucu anahtarları/hesap bilgileri verilmediği için bu ZIP'e gerçek bulut hesabı gömülmemiştir.
2. Fotoğraf/video cihazın tarayıcı uygulama depolamasında tutulur; Android dosya yöneticisinde normal klasör olarak görünmez. Tarayıcı verileri temizlenirse yerel kayıtlar kaybolabilir. Düzenli olarak “Yedekle” düğmesiyle JSON yedeği alın ve güvenli bir yere kopyalayın.
3. Uydu haritası internet gerektirir. Seçilen enlem-boylam çevrimdışı da kayıtlı kalır.
4. WhatsApp paylaşımında medya dosyası paylaşımı telefon/tarayıcı desteğine ve dosya boyutuna bağlıdır.
5. Bu bir ilk çalışan prototiptir; canlı kullanım öncesi yedekleme, erişim yetkileri ve bulut senkronizasyonu kurulmalıdır.

## Güvenlik
Ev sahibi telefonları ve portföy bilgileri kişisel veridir. Cihaz kilidi kullanın, yedekleri herkese açık alanlarda tutmayın ve çalışan erişimlerini ayrıca yönetin.
