COCINA CON KHATY — PROYECTO PARA GENERAR APK

Este ZIP incluye:
- Juego web mejorado en app/src/main/assets/index.html
- Configuración Android Studio para envolverlo como aplicación Android (WebView)
- manifest.json y sw.js del juego web

CÓMO GENERAR EL APK
1. En una computadora, instala Android Studio desde el sitio oficial de Android Developers.
2. Descomprime este ZIP.
3. Abre Android Studio > Open y selecciona la carpeta Cocina_con_Khaty_APK_Proyecto.
4. Espera a que termine la sincronización de Gradle.
5. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Al terminar, pulsa Locate. El APK de prueba suele quedar en app/build/outputs/apk/debug/app-debug.apk.
7. Pasa el APK a tu teléfono e instálalo. Android puede pedirte que permitas instalar apps desde esa fuente; hazlo solo si confías en el archivo que generaste.

IMPORTANTE
- Este ZIP es el código fuente del proyecto Android, no un APK ya compilado.
- Para compilarlo necesitas Android Studio en una computadora y conexión a internet para descargar componentes de Gradle.
- Para añadir tu logo, copia logo-khaty.png a app/src/main/assets/ y en index.html busca:
  // setLogo("logo-khaty.png");
  quita los // para activar setLogo("logo-khaty.png");
- Si quieres publicarlo en Google Play, es otro proceso; este proyecto no está publicado allí.
