ROUND ZERO — Android build checklist

1. Open this folder in current Android Studio.
2. Let Gradle Sync finish. If Android Studio asks for a compatible JDK, use the JDK bundled with Android Studio.
3. Install Android SDK Platform 35 in SDK Manager if it is missing.
4. The game HTML currently loads Three.js 0.160.0 from jsDelivr, so the first launch needs Internet. For a fully offline APK, put three.module.js into app/src/main/assets and change the import in index.html to ./three.module.js.
5. Build > Make Project. Fix any Gradle/SDK issue before proceeding.
6. Test on a real Android phone in landscape.
7. Debug APK: Build > Build Bundle(s) / APK(s) > Build APK(s).
8. Release APK: Build > Generate Signed App Bundle / APK > APK, create/select a keystore, then build release.

Important: the supplied project is a Three.js WebView prototype, not yet a finished multiplayer shooter. Network multiplayer, full weapon physics, recoil, bots, matchmaking and production assets still need implementation.
