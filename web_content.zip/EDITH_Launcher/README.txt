EDITH LAUNCHER

Base PWA interface bleu futuriste pour EDITH.
Fichiers: index.html, style.css, app.js, manifest.json, sw.js.

Pour en faire un vrai launcher Android par défaut, cette base doit être emballée dans une application Android native qui déclare l'intent HOME.
