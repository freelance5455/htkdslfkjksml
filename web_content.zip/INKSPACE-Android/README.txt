INKSPACE Android project

This wraps the supplied offline INKSPACE HTML file in an Android WebView.
The original HTML is included at app/src/main/assets/index.html.

Build in Android Studio:
1. Open this folder as an existing Android Studio project.
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

Cloud build without installing Android Studio:
1. Create a GitHub repository and upload all files in this folder.
2. Open Actions and run "Build INKSPACE APK" (or push to main).
3. Download the INKSPACE-debug-apk artifact from the completed workflow.

Notes:
- No internet permission is requested; the app content is bundled locally.
- Writing is stored in WebView local storage. Export backups regularly before clearing app data or uninstalling.
- The build workflow creates a debug APK, not a Play Store release-signed APK.
