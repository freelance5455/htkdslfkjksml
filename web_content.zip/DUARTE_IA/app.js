const $=s=>document.querySelector(s), messages=$("#messages"), promptBox=$("#prompt");
let mode="chat";
function add(text,who){const d=document.createElement("div");d.className="msg "+who;d.textContent=text;messages.appendChild(d);d.scrollIntoView({behavior:"smooth",block:"end"});}
function send(text){text=(text||promptBox.value).trim();if(!text)return;$("#welcome").style.display="none";add(text,"user");promptBox.value="";
 const replies={chat:"Sou a DUARTE IA. Esta é a estrutura inicial do seu assistente. Para responder de verdade, preciso conectar um provedor de inteligência artificial com segurança.",code:"Modo projetos ativado. Posso ajudar a planejar código, arquivos e etapas. A execução e geração real de projetos será habilitada na próxima integração com IA.",files:"A área de arquivos está preparada para receber projetos e documentos. A conexão para criar e baixar arquivos será adicionada na próxima etapa."};
 setTimeout(()=>add(replies[mode],"assistant"),350);
}
$("#composer").addEventListener("submit",e=>{e.preventDefault();send()});
$("#newChat").onclick=()=>{messages.innerHTML="";$("#welcome").style.display="block";};
document.querySelectorAll("[data-mode]").forEach(b=>b.onclick=()=>{mode=b.dataset.mode;document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n===b));$("#pageTitle").textContent=b.innerText.trim();$("#modeHint").textContent="✦ DUARTE IA • "+b.innerText.trim();$("#sidebar").classList.remove("open");promptBox.placeholder=mode==="code"?"Descreva o projeto ou código que deseja criar...":"Pergunte qualquer coisa...";});
document.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>{promptBox.value=b.dataset.prompt;send();});
$("#menu").onclick=()=>$("#sidebar").classList.toggle("open");
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));