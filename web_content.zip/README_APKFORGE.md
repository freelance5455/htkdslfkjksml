# CGD V117 — import APKForge

Ce paquet conserve le projet HTML5 complet du socle V5.12 et place `index.html` à la racine pour l'import ZIP d'APKForge. Une feuille de règles complémentaires améliore l'adaptation en paysage sur petits écrans mobiles, notamment la disposition du damier et de son panneau de commandes.

Dans APKForge, sélectionner l'orientation **Landscape / Paysage** dans les options natives si elle est proposée. Activer JavaScript et le stockage local afin que les données de carrière puissent être conservées dans le conteneur WebView.

Le verrouillage natif et l'affichage immersif sont configurés par APKForge ; la déclaration `orientation: landscape` du manifeste web constitue une indication complémentaire et ne remplace pas ce réglage.

Ce ZIP n'est pas un APK compilé. Il doit être importé dans APKForge puis généré.
