# گزارش آزمون — Spatial Notebook v0.4

## آزمون‌های خودکار

نتیجه اجرای `node --test tests/*.test.mjs`:

- ۸ آزمون موفق
- ۰ آزمون ناموفق
- ۰ آزمون ردشده

سناریوها:

1. SpatialStreamer: بارگذاری Chunk فعال قبل از Chunk پیش‌بارگذاری و تخلیه خارج شعاع.
2. SpatialStreamer: کنار گذاشتن کار صف‌شده پس از خروج دوربین از محدوده.
3. AIProviderRegistry: استفاده فقط از Provider فعال‌شده.
4. UICommandRegistry: رد فرمان ناشناخته و الزام تأیید فرمان حساس.
5. GLBInspector: اعتبارسنجی GLB 2.0 و گزارش ساختار پایه.
6. GLBInspector: رد امضای نامعتبر و Header ناقص.
7. GLBInspector: رد JSON Chunk خراب.
8. formatBytes و برآورد بودجه Runtime: مرزبندی و خروجی قابل پیش‌بینی.

## بررسی ایستا

- `node --check` روی main.js و ماژول‌های تغییرکرده اجرا شد.
- مسیرهای Import محلی بررسی شدند.
- شناسه‌های UI جدید و محل اتصال Event Handlerها بررسی شدند.

## قابلیت‌هایی که در این محیط آزمون سخت‌افزاری نشدند

- بارگذاری GLB واقعی ۱۰۰، ۲۰۰ و ۴۰۰ مگابایتی.
- اثبات جلوگیری از OOM در Android WebView؛ Eviction فقط منابع Assetهای قابل‌بازیابی را آزاد می‌کند و تضمین حافظه کامل نیست.
- اندازه‌گیری واقعی RAM و VRAM.
- FPS واقعی دستگاه.
- صحت Culling و بازیابی منابع GPU در WebGL واقعی.
- آزمون Lazy Restore با تعداد زیاد Asset روی گوشی.

## محدودیت‌های شناخته‌شده

- Parse همچنان از GLTFLoader.parse با ArrayBuffer کامل استفاده می‌کند.
- Parse در Worker انجام نمی‌شود.
- Chunk Splitter برای GLB واحد وجود ندارد.
- LOD خودکار تولید نمی‌شود.
- Occlusion Culling پیاده‌سازی نشده است.
- Asset Optimizer و Exporter بهینه‌سازی پیاده‌سازی نشده‌اند.

این گزارش ادعای موفقیت در آزمون‌های انجام‌نشده ندارد.
