# معماری نسخه ۰.۴ — یادداشت فنی

## ۱. مسیر ورود GLB

`ModelManager.addLocalFile()` اکنون ابتدا `inspectGLB()` را اجرا می‌کند. این مرحله Header بیست‌بایتی، JSON Chunk و در صورت وجود Headerهای کوچک تصاویر تعبیه‌شده را می‌خواند؛ کل فایل را برای گزارش اولیه به ArrayBuffer تبدیل نمی‌کند.

پس از Preflight، تخمین مصرف حافظه با مقایسه حجم منبع، داده‌های Accessor/BufferView، Textureهای Decode‌شده و سربار موقت ساخته می‌شود. بودجه بر اساس `navigator.deviceMemory` و در صورت دسترس بودن `performance.memory.jsHeapSizeLimit` به‌صورت محافظه‌کارانه تخمین زده می‌شود.

اگر نسبت تخمین اوج حافظه به بودجه زیاد باشد، کاربر هشدار و خلاصه ساختاری می‌بیند. در صورت تأیید، تخصیص‌های Renderer-side مدل‌های فعلی Dispose و ریشه‌های آن‌ها موقتاً مخفی می‌شوند. پس از پایان یا شکست Import، وضعیت Visible قبلی بازگردانده می‌شود.

**محدودیت مهم:** `GLTFLoader.parse()` همچنان به یک ArrayBuffer کامل نیاز دارد. در نتیجه این تغییرات ورودی ۴۰۰ مگابایتی را به Streaming واقعی تبدیل نمی‌کند و نمی‌تواند محدودیت حافظه WebView را حذف کند.

## ۲. GLBInspector

ماژول مستقل `www/js/core/GLBInspector.js`:

- اعتبارسنجی GLB magic، نسخه ۲، طول Header و Chunk JSON.
- خواندن JSON بدون Parse هندسه.
- شمارش Node، Mesh، Primitive، Material، Texture، Image و Animation.
- تخمین اندازه Accessor/BufferView.
- خواندن ابعاد برخی تصاویر PNG/JPEG/WebP/KTX2 از بخش‌های ابتدایی داده‌های تعبیه‌شده.
- محاسبه برآورد محافظه‌کارانه اوج حافظه.

این اعداد تخمینی‌اند و جایگزین اندازه‌گیری Runtime نیستند. در فایل‌های دارای تصاویر URI خارجی، Headerهای غیرمعمول یا افزونه‌های خاص، تخمین ممکن است ناقص باشد.

## ۳. ذخیره‌سازی و Lazy Restore

هنگام Import، فایل اصلی پس از Parse موفق و در صورت وجود سهمیه کافی در IndexedDB ذخیره می‌شود. Metadata شامل موقعیت، Quaternion، Scale، Scale Factor و خلاصه Asset نیز ذخیره می‌شود.

هنگام شروع برنامه، `restoreSaved()` فقط Placeholderهای Metadata را ایجاد می‌کند. `ensureLoaded()` هنگام انتخاب فایل، Blob را از IndexedDB می‌گیرد، آن را Parse می‌کند و Placeholder را با مدل فعال جایگزین می‌کند.

مدل‌های ذخیره‌شده دیگر همگی در Startup وارد GPU نمی‌شوند. با این حال، مدل‌هایی که کاربر در همان نشست وارد کرده و فعال نگه داشته است همچنان می‌توانند حافظه مصرف کنند؛ مدیریت کامل LRU/eviction برای Assetهای فعال هنوز تکمیل نشده است.

## ۴. مدیریت منابع GPU

`ModelManager.evictLoadedModels()` برای GLBهای قابل بازیابی، Transform را ذخیره می‌کند، Root را از Scene خارج می‌کند، Mixer و منابع Geometry/Material/Texture را Dispose می‌کند و رکورد را به حالت Dormant می‌برد. فایل اصلی در IndexedDB یا Blob نشست باقی می‌ماند تا هنگام انتخاب دوباره Parse شود. یادداشت‌های شناور برای جلوگیری از قطع نمایش محتوای دفترچه از این Eviction خودکار مستثنا هستند. این روش منابع هندسی Decode‌شده و تخصیص‌های GPU را آزاد می‌کند، اما Blob منبع و بعضی Metadataها باقی می‌مانند؛ بنابراین آزادسازی کامل RAM تضمین نمی‌شود.

## ۵. Frustum و Distance Culling

Frustum Culling برای Meshهای واردشده صریحاً فعال است. Three.js آن را در سطح Object3D/Mesh بر اساس Bounds انجام می‌دهد.

Distance Culling در `ModelManager.updateCulling(camera)` روی Root هر مدل عمل می‌کند. Bounding Sphere در Register و پس از Transform به‌روزرسانی می‌شود. شعاع نمایش از تنظیمات کاربر می‌آید. این سیستم صرفاً Render را از صحنه حذف می‌کند و فایل یا CPU Geometry را آزاد نمی‌کند.

## ۶. Spatial Streaming

`SpatialStreamer` نسخه قبلی حفظ شده است و می‌تواند Chunkهای مستقلی را که از قبل ثبت شده‌اند با Load/Unload callback مدیریت کند. نسخه ۰.۴ هنوز GLB واحد را به Chunk تبدیل نمی‌کند و Manifest importer ندارد. اسلایدرهای load/preload radius فقط برای Chunkهای ثبت‌شده در SpatialStreamer معتبرند.

## ۷. کیفیت و آزمون

آزمون‌های Node برای GLBInspector و زیرسیستم‌های قبلی اجرا می‌شوند. بررسی نحوی همه فایل‌های JS انجام می‌شود. WebGL واقعی، Android WebView، مصرف حافظه دستگاه و بارگذاری فایل‌های ۱۰۰ تا ۴۰۰ مگابایتی در این محیط قابل تأیید سخت‌افزاری نیست.
