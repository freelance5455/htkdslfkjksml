# الگوی بسته تم

برای ساخت تم سفارشی، این پوشه را کپی کن، فایل‌های خودت را در مسیرهای اعلام‌شده بگذار و تمام محتویات آن را با ساختار پوشه‌ها در یک ZIP قرار بده.

- `manifest.json` شناسه‌ها، رنگ‌ها و مسیر دارایی‌ها را مشخص می‌کند.
- آیکون‌ها باید SVG، PNG یا WebP باشند.
- انیمیشن‌های رابط باید JSON سازگار با Lottie باشند.
- پس‌زمینه محیط می‌تواند PNG، WebP یا JPEG باشد؛ پسوند و مسیر در manifest ثبت شود.
- مسیرها باید نسبی باشند و نباید شامل `..` یا مسیر ریشه شوند.
- ZIP نهایی باید در ریشه خود `manifest.json` داشته باشد.

شناسه‌های اصلی آیکون در نسخه ۰.۳:
`brand`, `design`, `settings`, `places`, `notebook`, `models`, `camera_up`, `camera_down`, `camera_left`, `camera_right`, `explore`, `environment`, `reset_view`.

شناسه‌های انیمیشن رویدادی نمونه:
`animations.model_added`, `animations.model_selected`, `animations.note_added`, `animations.note_opened`.

این الگو شامل یک آیکون نمونهٔ واقعی در `assets/icons/settings.svg` است. مسیر انیمیشن و پس‌زمینه را فقط پس از افزودن فایل واقعی و سازگار با فرمت مربوط، به `assets` در Manifest اضافه کن. نام شناسه‌های انیمیشن به رویدادهای برنامه متصل می‌شوند؛ برای مثال `animations.note_opened`.
