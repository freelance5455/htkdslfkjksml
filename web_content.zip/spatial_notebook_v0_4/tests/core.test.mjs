import test from 'node:test';
import assert from 'node:assert/strict';
import { SpatialStreamer } from '../www/js/core/SpatialStreamer.js';
import { AIProviderRegistry, UICommandRegistry } from '../www/js/core/AIProviderRegistry.js';

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

test('SpatialStreamer loads active chunks before prefetch chunks and unloads outside radius', async () => {
  const loaded = [];
  const unloaded = [];
  const transitions = [];
  const streamer = new SpatialStreamer({ loadRadius: 10, preloadRadius: 20, maxConcurrent: 1 });
  streamer.register({
    id: 'active', position: [0, 0, 0],
    load: async ({ tier }) => { loaded.push(['active', tier]); return { id: 'active' }; },
    unload: value => unloaded.push(value.id),
    setTier: (_value, tier) => transitions.push(['active', tier])
  });
  streamer.register({
    id: 'prefetch', position: [18, 0, 0],
    load: async ({ tier }) => { loaded.push(['prefetch', tier]); return { id: 'prefetch' }; },
    unload: value => unloaded.push(value.id)
  });

  streamer.update({ x: 0, y: 0, z: 0 });
  await delay(15);
  assert.deepEqual(loaded, [['active', 'active'], ['prefetch', 'prefetch']]);

  streamer.update({ x: 15, y: 0, z: 0 });
  await delay(5);
  assert.deepEqual(transitions, [['active', 'prefetch']]);

  streamer.update({ x: 100, y: 0, z: 0 });
  assert.deepEqual(unloaded.sort(), ['active', 'prefetch']);
  streamer.dispose();
});

test('SpatialStreamer drops stale queued work after camera leaves the prefetch radius', async () => {
  let releaseFirst;
  const loaded = [];
  const streamer = new SpatialStreamer({ loadRadius: 10, preloadRadius: 20, maxConcurrent: 1 });
  streamer.register({
    id: 'blocking', position: [0, 0, 0],
    load: () => new Promise(resolve => { releaseFirst = () => { loaded.push('blocking'); resolve({ id: 'blocking' }); }; }),
    unload: () => {}
  });
  streamer.register({
    id: 'stale', position: [5, 0, 0],
    load: async () => { loaded.push('stale'); return { id: 'stale' }; },
    unload: () => {}
  });
  streamer.update({ x: 0, y: 0, z: 0 });
  await delay(0);
  streamer.update({ x: 100, y: 0, z: 0 });
  releaseFirst();
  await delay(15);
  assert.deepEqual(loaded, ['blocking']);
  streamer.dispose();
});

test('AIProviderRegistry delegates messages only to an explicitly activated provider', async () => {
  const registry = new AIProviderRegistry();
  await assert.rejects(() => registry.sendMessage('hello'));
  const unregister = registry.register('local-test', {
    sendMessage: async messages => ({ received: messages }),
    getCapabilities: () => ({ text: true, image: false })
  });
  registry.setActive('local-test');
  assert.deepEqual(await registry.sendMessage('hello'), { received: 'hello' });
  assert.deepEqual(registry.list(), [{ id: 'local-test', capabilities: { text: true, image: false } }]);
  unregister();
  assert.equal(registry.active, null);
});

test('UICommandRegistry blocks unregistered commands and enforces confirmation flags', async () => {
  const registry = new UICommandRegistry();
  registry.register('REMOVE_THING', async ({ id }) => id, { confirm: true });
  await assert.rejects(() => registry.execute('UNKNOWN_COMMAND', {}));
  await assert.rejects(() => registry.execute('REMOVE_THING', { id: 'x' }), /confirmation/i);
  assert.equal(await registry.execute('REMOVE_THING', { id: 'x' }, { confirmed: true }), 'x');
});
