import test from 'node:test';
import assert from 'node:assert/strict';
import { inspectGLB, formatBytes, estimateRuntimeBudget } from '../www/js/core/GLBInspector.js';

function makeGlb(jsonObject, binary = new Uint8Array(36)) {
  const encoder = new TextEncoder();
  const rawJson = encoder.encode(JSON.stringify(jsonObject));
  const jsonLength = Math.ceil(rawJson.length / 4) * 4;
  const binLength = Math.ceil(binary.length / 4) * 4;
  const total = 12 + 8 + jsonLength + 8 + binLength;
  const out = new Uint8Array(total);
  const view = new DataView(out.buffer);
  view.setUint32(0, 0x46546c67, true);
  view.setUint32(4, 2, true);
  view.setUint32(8, total, true);
  view.setUint32(12, jsonLength, true);
  view.setUint32(16, 0x4e4f534a, true);
  out.fill(0x20, 20, 20 + jsonLength);
  out.set(rawJson, 20);
  const binHeader = 20 + jsonLength;
  view.setUint32(binHeader, binLength, true);
  view.setUint32(binHeader + 4, 0x004e4942, true);
  out.set(binary, binHeader + 8);
  return new Blob([out], { type: 'model/gltf-binary' });
}

const minimal = {
  asset: { version: '2.0' },
  scene: 0,
  scenes: [{ nodes: [0] }],
  nodes: [{ mesh: 0 }],
  meshes: [{ primitives: [{ attributes: { POSITION: 0 } }] }],
  buffers: [{ byteLength: 36 }],
  bufferViews: [{ buffer: 0, byteOffset: 0, byteLength: 36 }],
  accessors: [{ bufferView: 0, componentType: 5126, count: 3, type: 'VEC3' }],
  materials: [],
  textures: [],
  images: [],
  animations: []
};

test('GLB inspector validates GLB 2.0 and reports scene structure', async () => {
  const info = await inspectGLB(makeGlb(minimal));
  assert.equal(info.valid, true);
  assert.equal(info.version, 2);
  assert.equal(info.meshCount, 1);
  assert.equal(info.primitiveCount, 1);
  assert.equal(info.nodeCount, 1);
  assert.equal(info.accessorCount, 1);
  assert.ok(info.estimatedPeakBytes > info.fileBytes);
});

test('GLB inspector rejects invalid magic and truncated headers', async () => {
  await assert.rejects(() => inspectGLB(new Blob([new Uint8Array(32)])), /امضای فایل/);
  await assert.rejects(() => inspectGLB(new Blob([new Uint8Array(8)])), /کوچک/);
});

test('GLB inspector rejects malformed JSON chunk', async () => {
  const blob = makeGlb(minimal);
  const bytes = new Uint8Array(await blob.arrayBuffer());
  bytes.fill(0x7b, 20, 40);
  await assert.rejects(() => inspectGLB(new Blob([bytes])), /JSON داخلی/);
});

test('formatBytes and runtime budget are bounded and deterministic', () => {
  assert.equal(formatBytes(1024), '1 KB');
  assert.equal(estimateRuntimeBudget({ deviceMemory: 4, jsHeapLimit: 128 * 1024 * 1024 }), 96 * 1024 * 1024);
  assert.ok(estimateRuntimeBudget({ deviceMemory: 128 }) <= 512 * 1024 * 1024);
});
