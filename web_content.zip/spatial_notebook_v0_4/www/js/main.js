import * as THREE from 'three';
import { WorldEngine } from './core/WorldEngine.js';
import { TouchFreeCamera } from './core/TouchFreeCamera.js';
import { Storage } from './core/Storage.js';
import { ModelManager } from './core/ModelManager.js';
import { LocationManager } from './core/LocationManager.js';
import { TransformGizmo } from './core/TransformGizmo.js';
import { FloatingNoteManager } from './core/FloatingNoteManager.js';
import { ThemeManager } from './core/ThemeManager.js';
import { AnimationEventEngine } from './core/AnimationEventEngine.js';
import { SpatialStreamer } from './core/SpatialStreamer.js';
import { AIProviderRegistry, UICommandRegistry } from './core/AIProviderRegistry.js';
import { formatBytes } from './core/GLBInspector.js';

const $ = id => document.getElementById(id);
const SETTINGS_KEY = 'spatial-notebook-v02-camera-settings';
const DEFAULT_SETTINGS = { moveSlider: 54, lookSlider: 42, dpadSpeed: 35, targetFps: 60, loadRadius: 35, preloadRadius: 55, distanceCullEnabled: true, distanceCullRadius: 250 };
let settings = loadSettings();
let engine, cameraController, storage, modelManager, locationManager;
let transformGizmo, floatingNotes, themeManager, animationEvents, spatialStreamer;
let aiProviders, uiCommands;
let currentMode = 'explore';
let worldVisible = true;
let toastTimer = 0;
let animationFrameId = 0;
let previousAnimationTime = 0;
let lastAnimationRender = 0;
let activeAxisDrag = null;
let activeDpad = null;
let dpadFrameId = 0;
let dpadLastTime = 0;

function loadSettings() {
  try { return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') }; }
  catch (_) { return { ...DEFAULT_SETTINGS }; }
}
function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch (_) {}
}
function metersPer100px(sliderValue) {
  const t = THREE.MathUtils.clamp(Number(sliderValue) / 100, 0, 1);
  return 0.002 * Math.pow(25000, t);
}
function lookRadiansPerPx(sliderValue) {
  const t = THREE.MathUtils.clamp(Number(sliderValue) / 100, 0, 1);
  return 0.0006 + 0.0144 * t * t;
}
function dpadMetersPerSecond(sliderValue) {
  const t = THREE.MathUtils.clamp(Number(sliderValue) / 100, 0, 1);
  return 0.15 * Math.pow(80, t);
}
function faNumber(value, digits = 2) {
  return Number(value).toLocaleString('fa-IR', { maximumFractionDigits: digits, minimumFractionDigits: digits });
}
function showToast(message, duration = 2600) {
  const el = $('toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), duration);
}
function setStatus(message) { $('status').textContent = message; }
function render() { engine?.requestRender(); }

function refreshTransformGizmo() {
  if (!transformGizmo) return;
  if (currentMode !== 'arrange' || !modelManager?.selected) transformGizmo.update(null);
  else transformGizmo.update(modelManager.selected?.root || null);
}

function ensureAnimationLoop() {
  if (animationFrameId || !worldVisible || !modelManager?.hasAnimations()) return;
  previousAnimationTime = 0;
  lastAnimationRender = 0;
  const tick = now => {
    if (!worldVisible || !modelManager?.hasAnimations()) {
      animationFrameId = 0;
      return;
    }
    const cap = Number(settings.targetFps);
    const minInterval = cap > 0 ? 1000 / cap : 0;
    if (!lastAnimationRender || now - lastAnimationRender >= minInterval - 1) {
      const delta = previousAnimationTime ? Math.min((now - previousAnimationTime) / 1000, 0.05) : 0;
      previousAnimationTime = now;
      lastAnimationRender = now;
      modelManager.updateAnimations(delta);
      engine.requestRender();
    }
    animationFrameId = requestAnimationFrame(tick);
  };
  animationFrameId = requestAnimationFrame(tick);
}

function stopAnimationLoop() {
  if (animationFrameId) cancelAnimationFrame(animationFrameId);
  animationFrameId = 0;
  previousAnimationTime = 0;
  lastAnimationRender = 0;
}

function setMode(mode) {
  currentMode = mode === 'arrange' ? 'arrange' : 'explore';
  // Camera gestures remain available in BOTH modes. Object movement is performed
  // only by grabbing one of the six translation-axis segments.
  cameraController?.setEnabled(worldVisible);
  $('exploreModeBtn').classList.toggle('active', currentMode === 'explore');
  $('modeLabel').textContent = currentMode === 'explore' ? 'حالت مشاهده' : 'حالت چیدمان اشیا';
  $('gestureHint').textContent = currentMode === 'explore'
    ? 'یک انگشت: چرخش نگاه　 دو انگشت: جلو/عقب　 چهار فلش: حرکت جانبی و عمودی'
    : 'دوربین: ژست‌های عادی و چهار فلش　 جسم: کشیدن یکی از شش نیم‌محور';
  $('toggleArrangeBtn').textContent = currentMode === 'arrange' ? 'پایان حالت چیدمان' : 'ورود به حالت چیدمان';
  if (currentMode === 'arrange') closeAllDrawers();
  updateSelectedModelPanel();
  refreshTransformGizmo();
  render();
}

function closeAllDrawers() {
  document.querySelectorAll('.drawer.open').forEach(drawer => drawer.classList.remove('open'));
}
function openDrawer(id) {
  closeAllDrawers();
  $(id).classList.add('open');
}
function bindDrawerButtons() {
  document.querySelectorAll('[data-close]').forEach(button => {
    button.addEventListener('click', () => $(button.dataset.close).classList.remove('open'));
  });
  $('settingsBtn').addEventListener('click', () => openDrawer('settingsDrawer'));
  $('designBtn').addEventListener('click', () => openDrawer('designDrawer'));
  $('placesBtn').addEventListener('click', () => { renderPlaces(); openDrawer('placesDrawer'); });
  $('modelsBtn').addEventListener('click', () => { renderModels(); openDrawer('modelsDrawer'); });
  $('modelsDrawer').addEventListener('click', event => event.stopPropagation());
}

function bindSettings() {
  const moveInput = $('moveSensitivity');
  const lookInput = $('lookSensitivity');
  const dpadInput = $('dpadSpeed');
  const fpsInput = $('targetFps');
  const loadInput = $('loadRadius');
  const preloadInput = $('preloadRadius');
  const distanceCullEnabledInput = $('distanceCullEnabled');
  const distanceCullInput = $('distanceCullRadius');
  moveInput.value = String(settings.moveSlider);
  lookInput.value = String(settings.lookSlider);
  dpadInput.value = String(settings.dpadSpeed);
  fpsInput.value = String(settings.targetFps);
  loadInput.value = String(settings.loadRadius);
  preloadInput.value = String(settings.preloadRadius);
  distanceCullEnabledInput.checked = settings.distanceCullEnabled;
  distanceCullInput.value = String(settings.distanceCullRadius);

  const update = () => {
    settings.moveSlider = Number(moveInput.value);
    settings.lookSlider = Number(lookInput.value);
    settings.dpadSpeed = Number(dpadInput.value);
    settings.targetFps = Number(fpsInput.value);
    engine?.setTargetFps(settings.targetFps);
    settings.loadRadius = Number(loadInput.value);
    settings.preloadRadius = Math.max(settings.loadRadius, Number(preloadInput.value));
    settings.distanceCullEnabled = distanceCullEnabledInput.checked;
    settings.distanceCullRadius = Number(distanceCullInput.value);
    preloadInput.value = String(settings.preloadRadius);
    const movement = metersPer100px(settings.moveSlider);
    $('moveSensitivityValue').textContent = `${faNumber(movement, movement < 0.1 ? 3 : 2)} متر / ۱۰۰ پیکسل`;
    $('lookSensitivityValue').textContent = `${faNumber(lookRadiansPerPx(settings.lookSlider) * 180 / Math.PI, 2)}° / پیکسل`;
    $('dpadSpeedValue').textContent = `${faNumber(dpadMetersPerSecond(settings.dpadSpeed), 2)} متر / ثانیه`;
    $('loadRadiusValue').textContent = `${faNumber(settings.loadRadius, 0)} متر`;
    $('preloadRadiusValue').textContent = `${faNumber(settings.preloadRadius, 0)} متر`;
    $('distanceCullRadiusValue').textContent = `${faNumber(settings.distanceCullRadius, 0)} متر`;
    spatialStreamer?.setRadii(settings.loadRadius, settings.preloadRadius);
    modelManager?.setDistanceCulling(settings.distanceCullEnabled, settings.distanceCullRadius);
    saveSettings();
    ensureAnimationLoop();
  };
  [moveInput, lookInput, dpadInput, fpsInput, loadInput, preloadInput, distanceCullInput].forEach(input => input.addEventListener('input', update));
  distanceCullEnabledInput.addEventListener('change', update);
  document.querySelectorAll('[data-move-preset]').forEach(button => {
    button.addEventListener('click', () => { moveInput.value = button.dataset.movePreset; update(); });
  });
  $('resetSettingsBtn').addEventListener('click', () => {
    settings = { ...DEFAULT_SETTINGS };
    moveInput.value = String(settings.moveSlider); lookInput.value = String(settings.lookSlider);
    dpadInput.value = String(settings.dpadSpeed); fpsInput.value = String(settings.targetFps);
    loadInput.value = String(settings.loadRadius); preloadInput.value = String(settings.preloadRadius);
    distanceCullEnabledInput.checked = settings.distanceCullEnabled; distanceCullInput.value = String(settings.distanceCullRadius);
    update(); showToast('تنظیمات کنترل و عملکرد بازنشانی شدند.');
  });
  update();
}

function renderPlaces() {
  const list = $('placesList');
  const query = $('placeSearch').value || '';
  const places = locationManager.search(query);
  list.replaceChildren();
  $('placesEmpty').classList.toggle('show', places.length === 0);
  for (const place of places) {
    const row = document.createElement('div'); row.className = 'listRow';
    const main = document.createElement('div'); main.className = 'rowMain';
    const name = document.createElement('b'); name.textContent = place.name;
    const detail = document.createElement('small');
    detail.textContent = `X ${faNumber(place.position[0], 1)} · Y ${faNumber(place.position[1], 1)} · Z ${faNumber(place.position[2], 1)}`;
    main.append(name, detail);
    const go = document.createElement('button'); go.textContent = 'تلپورت'; go.addEventListener('click', () => teleportTo(place));
    const del = document.createElement('button'); del.className = 'delete'; del.textContent = 'حذف';
    del.addEventListener('click', () => { locationManager.remove(place.id); renderPlaces(); showToast('مکان حذف شد.'); });
    row.append(main, go, del); list.append(row);
  }
}

function saveCurrentPlace() {
  const name = $('placeName').value.trim();
  try {
    const place = locationManager.save(name);
    $('placeName').value = ''; renderPlaces(); showToast(`مکان «${place.name}» ذخیره شد.`);
  } catch (error) { showToast(error.message); }
}

function teleportTo(place) {
  const start = cameraController.getPose();
  const end = { position: place.position, yaw: place.yaw, pitch: place.pitch };
  const startPosition = new THREE.Vector3(...start.position);
  const endPosition = new THREE.Vector3(...end.position);
  let yawDelta = end.yaw - start.yaw;
  while (yawDelta > Math.PI) yawDelta -= Math.PI * 2;
  while (yawDelta < -Math.PI) yawDelta += Math.PI * 2;
  const startTime = performance.now(); const duration = 420;
  closeAllDrawers(); cameraController.setEnabled(false);
  const step = now => {
    if (!worldVisible) return;
    const raw = Math.min(1, (now - startTime) / duration); const t = raw * raw * (3 - 2 * raw);
    const position = startPosition.clone().lerp(endPosition, t);
    cameraController.setPose({ position: position.toArray(), yaw: start.yaw + yawDelta * t, pitch: start.pitch + (end.pitch - start.pitch) * t });
    refreshTransformGizmo(); spatialStreamer?.update(engine.camera.position); render();
    if (raw < 1) requestAnimationFrame(step);
    else { cameraController.setEnabled(worldVisible); showToast(`به «${place.name}» منتقل شدی.`); }
  };
  requestAnimationFrame(step);
}

function renderModels() {
  if (!modelManager) return;
  const list = $('modelsList'); list.replaceChildren();
  $('modelsEmpty').classList.toggle('show', modelManager.entries.length === 0);
  for (const entry of modelManager.entries) {
    const row = document.createElement('div'); row.className = 'listRow';
    const main = document.createElement('div'); main.className = 'rowMain';
    const name = document.createElement('b'); name.textContent = entry.name;
    const type = document.createElement('small');
    const stateLabel = entry.state === 'dormant' ? ' · بارگذاری تنبل' : entry.state === 'loading' ? ' · در حال بارگذاری' : entry.state === 'error' ? ' · خطای بارگذاری' : '';
    type.textContent = (entry.kind === 'sample' ? 'مدل نمونه · قابل حذف' : entry.kind === 'floating-note' ? 'یادداشت دوبعدی در فضای سه‌بعدی' : 'فایل GLB واردشده') + stateLabel;
    main.append(name, type);
    const select = document.createElement('button'); select.textContent = entry.id === modelManager.selectedId ? 'انتخاب‌شده' : 'انتخاب';
    select.addEventListener('click', async () => { modelManager.select(entry.id); setMode('arrange'); updateSelectedModelPanel(); renderModels(); });
    row.append(main, select);
    if (entry.kind === 'floating-note') {
      const edit = document.createElement('button'); edit.textContent = 'ویرایش';
      edit.addEventListener('click', async () => {
        try { await floatingNotes.openForEditing(entry.noteId, openNotebookScreen); animationEvents?.dispatch('NOTE_OPENED', { noteId: entry.noteId }); }
        catch (error) { showToast(error.message); }
      });
      row.append(edit);
    }
    const del = document.createElement('button'); del.className = 'delete'; del.textContent = 'حذف';
    del.addEventListener('click', async () => {
      await modelManager.remove(entry.id); updateSelectedModelPanel(); renderModels(); showToast('جسم از صحنه و ذخیرهٔ محلی حذف شد.');
    });
    row.append(del); list.append(row);
  }
  updateSelectedModelPanel();
}

function angleDegrees(rad) {
  const value = THREE.MathUtils.radToDeg(rad);
  return (Math.round(value) % 360 + 360) % 360;
}

function updateSelectedModelPanel() {
  const entry = modelManager?.selected;
  const hasSelection = Boolean(entry);
  const panel = $('transformPanel');
  panel.classList.toggle('visible', currentMode === 'arrange' && hasSelection && worldVisible);
  $('selectedModelName').textContent = entry?.name || 'جسم انتخاب نشده';
  $('selectedModelType').textContent = entry?.kind === 'sample' ? 'نمونه' : entry?.kind === 'floating-note' ? 'یادداشت' : entry ? 'مدل GLB' : '—';
  const loaded = Boolean(entry?.root);
  for (const id of ['modelScale', 'modelRotationX', 'modelRotationY', 'modelRotationZ']) $(id).disabled = !loaded;
  $('focusModelBtn').disabled = !hasSelection;
  $('deleteModelBtn').disabled = !hasSelection;
  const clips = entry?.actions ? [...entry.actions.keys()] : [];
  const animSelect = $('modelAnimation');
  const previousClip = animSelect.value;
  animSelect.replaceChildren();
  if (!clips.length) {
    const option = document.createElement('option'); option.value = ''; option.textContent = 'این مدل انیمیشن داخلی ندارد'; animSelect.append(option);
  } else {
    clips.forEach(name => { const option = document.createElement('option'); option.value = name; option.textContent = name; animSelect.append(option); });
    if (clips.includes(previousClip)) animSelect.value = previousClip;
  }
  $('animationControl').hidden = clips.length === 0;
  animSelect.disabled = clips.length === 0;
  $('playAnimationBtn').disabled = clips.length === 0;
  if (entry) {
    $('modelScale').value = String(entry.scaleFactor || 1);
    const euler = entry.root ? entry.root.rotation : new THREE.Euler().setFromQuaternion(new THREE.Quaternion(...(entry.transform?.quaternion || [0,0,0,1])), 'XYZ');
    $('modelRotationX').value = String(angleDegrees(euler.x));
    $('modelRotationY').value = String(angleDegrees(euler.y));
    $('modelRotationZ').value = String(angleDegrees(euler.z));
  }
  $('modelScaleValue').textContent = `${faNumber(Number($('modelScale').value || 1), 2)}×`;
  for (const axis of ['X', 'Y', 'Z']) $(`modelRotation${axis}Value`).textContent = `${faNumber(Number($(`modelRotation${axis}`).value || 0), 0)}°`;
  refreshTransformGizmo();
}

async function focusSpatialEntry(entry) {
  if (!entry) return;
  if (!entry.root) entry = await modelManager.ensureLoaded(entry);
  const bounds = new THREE.Box3().setFromObject(entry.root);
  const center = bounds.getCenter(new THREE.Vector3());
  const forward = new THREE.Vector3(); engine.camera.getWorldDirection(forward);
  const distance = Math.max(1.8, bounds.getSize(new THREE.Vector3()).length() * 1.4);
  const position = center.clone().addScaledVector(forward, -distance);
  cameraController.setPose({ ...cameraController.getPose(), position: position.toArray() });
  refreshTransformGizmo(); spatialStreamer?.update(engine.camera.position); render();
}

function bindModelControls() {
  $('addGlbBtn').addEventListener('click', () => $('glbFileInput').click());
  $('glbFileInput').addEventListener('change', async event => {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file) return;
    try {
      const entry = await modelManager.addLocalFile(file);
      setMode('arrange'); renderModels(); closeAllDrawers();
      animationEvents?.dispatch('MODEL_ADDED', { entryId: entry.id });
      ensureAnimationLoop();
      showToast('مدل اضافه شد؛ برای جابه‌جایی یکی از شش نیم‌محور را بکش.');
    } catch (error) { showToast(`بارگذاری مدل ناموفق بود: ${error.message}`, 4200); }
  });

  $('inspectGlbBtn').addEventListener('click', () => $('inspectGlbInput').click());
  $('inspectGlbInput').addEventListener('change', async event => {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file) return;
    try {
      const info = await modelManager.inspectLocalFile(file);
      const lines = [
        `فایل: ${file.name}`, `حجم: ${formatBytes(info.fileBytes)}`,
        `Mesh: ${info.meshCount} · Primitive: ${info.primitiveCount} · Node: ${info.nodeCount}`,
        `Material: ${info.materialCount} · Texture: ${info.textureCount} · Animation: ${info.animationCount}`,
        `هندسه تخمینی: ${formatBytes(info.estimatedGeometryBytes)}`,
        `بافت Decode‌شده تخمینی: ${formatBytes(info.estimatedDecodedTextureBytes)}`,
        `اوج حافظه تخمینی: ${formatBytes(info.estimatedPeakBytes)}`,
        ...(info.warnings.length ? ['هشدارها:', ...info.warnings] : [])
      ];
      $('assetReportText').textContent = lines.join('\n');
      $('assetReportPanel').hidden = false;
      showToast('تحلیل ساختار GLB انجام شد.');
    } catch (error) { showToast(`تحلیل فایل ناموفق بود: ${error.message}`, 4500); }
  });
  $('sampleModelsBtn').addEventListener('click', () => openDrawer('samplesDrawer'));
  $('loadChairSample').addEventListener('click', async () => {
    try { const entry = await modelManager.addSample('chair'); closeAllDrawers(); setMode('arrange'); renderModels(); animationEvents?.dispatch('MODEL_ADDED', { entryId: entry.id }); ensureAnimationLoop(); showToast('صندلی نمونه اضافه شد.'); }
    catch (error) { showToast(`دریافت صندلی ناموفق بود: ${error.message}`, 4500); }
  });
  $('loadCupSample').addEventListener('click', async () => {
    try { const entry = await modelManager.addSample('cup'); closeAllDrawers(); setMode('arrange'); renderModels(); animationEvents?.dispatch('MODEL_ADDED', { entryId: entry.id }); ensureAnimationLoop(); showToast('فنجان نمونه اضافه شد.'); }
    catch (error) { showToast(`دریافت فنجان ناموفق بود: ${error.message}`, 4500); }
  });
  $('toggleArrangeBtn').addEventListener('click', () => {
    if (currentMode === 'arrange') setMode('explore');
    else if (!modelManager.entries.length) showToast('ابتدا یک مدل یا یادداشت شناور اضافه کن.');
    else setMode('arrange');
  });
  $('addFloatingNoteBtn').addEventListener('click', async () => {
    try {
      const entry = await floatingNotes.addActiveNote();
      setMode('arrange'); closeAllDrawers(); renderModels();
      animationEvents?.dispatch('NOTE_ADDED', { entryId: entry.id, noteId: entry.noteId });
    } catch (error) { showToast(error.message, 3800); }
  });

  $('modelScale').addEventListener('input', () => {
    const entry = modelManager.selected; if (!entry) return;
    modelManager.setScaleFactor(entry, Number($('modelScale').value));
    $('modelScaleValue').textContent = `${faNumber(Number($('modelScale').value), 2)}×`;
    refreshTransformGizmo();
  });
  const updateRotation = () => {
    const entry = modelManager.selected; if (!entry) return;
    const x = Number($('modelRotationX').value), y = Number($('modelRotationY').value), z = Number($('modelRotationZ').value);
    modelManager.setRotationDegrees(entry, x, y, z);
    $('modelRotationXValue').textContent = `${faNumber(x, 0)}°`;
    $('modelRotationYValue').textContent = `${faNumber(y, 0)}°`;
    $('modelRotationZValue').textContent = `${faNumber(z, 0)}°`;
    refreshTransformGizmo();
  };
  ['modelRotationX', 'modelRotationY', 'modelRotationZ'].forEach(id => $(id).addEventListener('input', updateRotation));
  $('playAnimationBtn').addEventListener('click', () => {
    const entry = modelManager.selected; const clip = $('modelAnimation').value;
    if (entry && clip) {
      const played = animationEvents.playModel(entry.id, clip, { loop: 'repeat', fade: 0.22 });
      if (played) { ensureAnimationLoop(); showToast(`انیمیشن «${clip}» اجرا شد.`); }
    }
  });
  $('deleteModelBtn').addEventListener('click', async () => {
    const entry = modelManager.selected; if (!entry) return;
    await modelManager.remove(entry.id); renderModels();
  });
  $('focusModelBtn').addEventListener('click', async () => { try { await focusSpatialEntry(modelManager.selected); } catch (error) { showToast(error.message); } });
}

function beginAxisDrag(event, hit) {
  const entry = modelManager.selected;
  if (!entry?.root || !hit) return false;
  const axisWorld = transformGizmo.worldAxis(entry.root, hit.axis, hit.sign);
  const origin = transformGizmo.group.position.clone();
  const startParameter = transformGizmo.axisParameter(event, origin, axisWorld);
  if (startParameter == null) {
    showToast('این محور از زاویه فعلی دوربین برای کشیدن مناسب نیست؛ دوربین را کمی بچرخان.');
    return true;
  }
  try { $('worldCanvas').setPointerCapture(event.pointerId); } catch (_) {}
  cameraController.setEnabled(false);
  transformGizmo.setActive(hit.axis, hit.sign);
  activeAxisDrag = {
    pointerId: event.pointerId,
    entry,
    startBoundsCenter: entry.boundsSphere?.center?.clone() || null,
    axis: hit.axis,
    sign: hit.sign,
    origin,
    axisWorld,
    startParameter,
    startPosition: entry.root.position.clone()
  };
  event.preventDefault();
  return true;
}

function bindArrangeGestures() {
  const canvas = $('worldCanvas');
  canvas.addEventListener('pointerdown', event => {
    if (currentMode !== 'arrange' || !worldVisible || event.pointerType === 'mouse' && event.button !== 0) return;
    const axisHit = transformGizmo.hit(event);
    if (axisHit) { beginAxisDrag(event, axisHit); return; }
    const hitId = engine.hitModel(event, modelManager.entries);
    if (hitId) {
      modelManager.select(hitId);
      updateSelectedModelPanel();
      renderModels();
      animationEvents?.dispatch('MODEL_SELECTED', { entryId: hitId });
    }
  }, { passive: false });

  canvas.addEventListener('pointermove', event => {
    const drag = activeAxisDrag;
    if (!drag || event.pointerId !== drag.pointerId) return;
    event.preventDefault();
    const current = transformGizmo.axisParameter(event, drag.origin, drag.axisWorld);
    if (current == null) return;
    const delta = current - drag.startParameter;
    drag.entry.root.position.copy(drag.startPosition).addScaledVector(drag.axisWorld, delta);
    drag.entry.root.updateMatrixWorld(true);
    if (drag.startBoundsCenter && drag.entry.boundsSphere) drag.entry.boundsSphere.center.copy(drag.startBoundsCenter).addScaledVector(drag.axisWorld, delta);
    drag.entry.transform = { position: drag.entry.root.position.toArray(), quaternion: drag.entry.root.quaternion.toArray(), scale: drag.entry.root.scale.toArray() };
    refreshTransformGizmo();
    render();
  }, { passive: false });

  const endDrag = event => {
    if (!activeAxisDrag || event.pointerId !== activeAxisDrag.pointerId) return;
    const drag = activeAxisDrag;
    activeAxisDrag = null;
    transformGizmo.setActive(null, null);
    modelManager.updateBounds(drag.entry);
    modelManager.persist(drag.entry).catch(() => showToast('ذخیرهٔ موقعیت جسم ناموفق بود.'));
    cameraController.setEnabled(worldVisible);
    refreshTransformGizmo(); render();
  };
  canvas.addEventListener('pointerup', endDrag);
  canvas.addEventListener('pointercancel', endDrag);
  canvas.addEventListener('lostpointercapture', endDrag);
}

function moveCameraDirection(direction, deltaSeconds) {
  if (!worldVisible || !cameraController) return;
  const camera = engine.camera;
  const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion).normalize();
  // Screen-independent vertical translation uses world Y, never camera-forward.
  // This guarantees the D-pad's up/down buttons cannot move the camera forward/back.
  const up = new THREE.Vector3(0, 1, 0);
  const speed = dpadMetersPerSecond(settings.dpadSpeed) * Math.min(deltaSeconds, 0.05);
  if (direction === 'right') camera.position.addScaledVector(right, speed);
  if (direction === 'left') camera.position.addScaledVector(right, -speed);
  if (direction === 'up') camera.position.addScaledVector(up, speed);
  if (direction === 'down') camera.position.addScaledVector(up, -speed);
  camera.updateMatrixWorld(true);
  refreshTransformGizmo();
  spatialStreamer?.update(camera.position);
  engine.requestRender();
}

function bindCameraDpad() {
  document.querySelectorAll('[data-camera-dir]').forEach(button => {
    button.addEventListener('pointerdown', event => {
      event.preventDefault();
      activeDpad = button.dataset.cameraDir;
      try { button.setPointerCapture(event.pointerId); } catch (_) {}
      dpadLastTime = 0;
      const tick = now => {
        if (!activeDpad || !worldVisible) { dpadFrameId = 0; return; }
        const dt = dpadLastTime ? (now - dpadLastTime) / 1000 : 1 / 60;
        dpadLastTime = now;
        moveCameraDirection(activeDpad, dt);
        dpadFrameId = requestAnimationFrame(tick);
      };
      if (!dpadFrameId) dpadFrameId = requestAnimationFrame(tick);
    });
    const stop = () => { activeDpad = null; if (dpadFrameId) cancelAnimationFrame(dpadFrameId); dpadFrameId = 0; dpadLastTime = 0; };
    ['pointerup', 'pointercancel', 'lostpointercapture', 'pointerleave'].forEach(type => button.addEventListener(type, stop));
    button.addEventListener('contextmenu', event => event.preventDefault());
  });
}

function bindWorldToolbar() {
  $('exploreModeBtn').addEventListener('click', () => setMode('explore'));
  $('environmentBtn').addEventListener('click', () => {
    engine.environment.visible = !engine.environment.visible;
    $('environmentBtn').classList.toggle('active', engine.environment.visible);
    showToast(engine.environment.visible ? 'محیط آزمایشی نمایش داده شد.' : 'محیط آزمایشی پنهان شد.'); render();
  });
  $('resetViewBtn').addEventListener('click', () => {
    cameraController.setPose({ position: [0, 1.62, 5.8], yaw: 0, pitch: -0.035 });
    spatialStreamer?.update(engine.camera.position);
    refreshTransformGizmo(); render(); showToast('دوربین به نمای آغازین برگشت.');
  });
  $('savePlaceBtn').addEventListener('click', saveCurrentPlace);
  $('placeSearch').addEventListener('input', renderPlaces);
}

function openNotebookScreen() {
  closeAllDrawers();
  worldVisible = false;
  cameraController.setEnabled(false);
  modelManager.persistAll();
  stopAnimationLoop();
  $('notebookScreen').hidden = false;
  $('worldApp').style.visibility = 'hidden';
  refreshTransformGizmo();
}


function bindNotebookMode() {
  const screen = $('notebookScreen');
  const frame = $('notebookFrame');
  $('notesBtn').addEventListener('click', openNotebookScreen);
  $('backToWorldBtn').addEventListener('click', async () => {
    try { await frame.contentWindow?.BN?.flushSave?.(); } catch (_) {}
    screen.hidden = true;
    $('worldApp').style.visibility = 'visible';
    worldVisible = true;
    cameraController.setEnabled(true);
    refreshTransformGizmo(); render(); ensureAnimationLoop();
    try {
      const note = frame.contentWindow?.BN?.app?.note;
      if (note?.id) floatingNotes?.notifyChanged(note.id);
    } catch (_) {}
  });
  window.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !screen.hidden) $('backToWorldBtn').click();
  });
  frame.addEventListener('load', () => {
    setTimeout(() => floatingNotes?.restore().catch(console.warn), 250);
  });
  window.addEventListener('message', event => {
    if (event.origin !== location.origin || event.source !== frame.contentWindow) return;
    if (event.data?.type === 'boomnote:changed') floatingNotes?.notifyChanged(event.data.noteId);
  });
  if (frame.contentDocument?.readyState === 'complete') setTimeout(() => floatingNotes?.restore().catch(console.warn), 500);
}

function renderThemeGrid() {
  const grid = $('themeGrid');
  grid.replaceChildren();
  const swatches = { default: 'defaultSwatch', scifi: 'scifiSwatch', fantasy: 'fantasySwatch', rpg: 'rpgSwatch' };
  for (const theme of themeManager.list()) {
    const button = document.createElement('button');
    button.className = 'themeCard';
    button.dataset.theme = theme.id;
    const swatch = document.createElement('span');
    swatch.className = `themeSwatch ${swatches[theme.id] || ''}`;
    if (!swatches[theme.id]) swatch.style.background = 'linear-gradient(135deg,#182b38,#6b8e91)';
    const label = document.createElement('b'); label.textContent = theme.name;
    button.append(swatch, label);
    button.classList.toggle('active', theme.id === themeManager.activeId);
    button.addEventListener('click', async () => {
      try { await themeManager.apply(theme.id); renderThemeGrid(); ['themeAccent','themeBackground','themePanel','themeText'].forEach((id, index) => { const keys=['--accent','--bg','--panel','--text']; const color=themeManager.active.colors?.[keys[index]]; if (/^#[0-9a-f]{6}$/i.test(color || '')) $(id).value=color; }); showToast(`تم «${themeManager.active.name}» فعال شد.`); }
      catch (error) { showToast(error.message); }
    });
    grid.append(button);
  }
}

function bindDesignStudio() {
  renderThemeGrid();
  $('replaceIconBtn').addEventListener('click', () => $('iconAssetInput').click());
  $('iconAssetInput').addEventListener('change', async event => {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file) return;
    try { await themeManager.setIconAsset($('iconTarget').value, file); renderThemeGrid(); showToast('آیکون جایگزین شد و در تم شخصی ذخیره شد.'); }
    catch (error) { showToast(`جایگزینی آیکون ناموفق بود: ${error.message}`); }
  });
  $('importThemeBtn').addEventListener('click', () => $('themeZipInput').click());
  $('themeZipInput').addEventListener('change', async event => {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file) return;
    try { await themeManager.importZip(file); renderThemeGrid(); showToast('بسته تم با موفقیت وارد شد.'); }
    catch (error) { showToast(`ورود تم ناموفق بود: ${error.message}`, 4200); }
  });
  $('replaceBackgroundBtn').addEventListener('click', () => $('workspaceBackgroundInput').click());
  $('workspaceBackgroundInput').addEventListener('change', async event => {
    const file = event.target.files?.[0]; event.target.value = '';
    if (!file) return;
    try { await themeManager.setBackgroundAsset(file); renderThemeGrid(); showToast('پس‌زمینه به تم شخصی اضافه شد.'); }
    catch (error) { showToast(`تغییر پس‌زمینه ناموفق بود: ${error.message}`); }
  });
  const colorInputs = [
    ['themeAccent', '--accent'], ['themeBackground', '--bg'],
    ['themePanel', '--panel'], ['themeText', '--text']
  ];
  const syncColorInputs = () => {
    const colors = themeManager.active.colors || {};
    for (const [id, token] of colorInputs) $(id).value = /^#[0-9a-f]{6}$/i.test(colors[token] || '') ? colors[token] : '#808080';
  };
  colorInputs.forEach(([id, token]) => $(id).addEventListener('change', async () => {
    try { await themeManager.setColor(token, $(id).value); renderThemeGrid(); syncColorInputs(); }
    catch (error) { showToast(error.message); }
  }));
  $('exportThemeBtn').addEventListener('click', async () => {
    try { await themeManager.exportActive(); showToast('بسته تم آماده و ذخیره شد.'); }
    catch (error) { showToast(`خروجی تم ناموفق بود: ${error.message}`); }
  });
  syncColorInputs();
}

function installIntegrationAPI() {
  uiCommands.register('SET_THEME', async args => {
    const id = String(args.id || '');
    if (!themeManager.list().some(theme => theme.id === id)) throw new Error('تم ناشناخته است.');
    await themeManager.apply(id); renderThemeGrid();
    return { activeTheme: id };
  });
  uiCommands.register('SELECT_OBJECT', args => {
    const id = String(args.id || '');
    if (!modelManager.entries.some(entry => entry.id === id)) throw new Error('جسم موردنظر پیدا نشد.');
    modelManager.select(id); setMode('arrange');
    return { selectedId: id };
  });
  uiCommands.register('FOCUS_OBJECT', async args => {
    let entry = modelManager.entries.find(item => item.id === String(args.id || ''));
    if (!entry) throw new Error('جسم موردنظر پیدا نشد.');
    entry = await modelManager.ensureLoaded(entry);
    modelManager.select(entry.id); setMode('arrange'); await focusSpatialEntry(entry);
    return { focusedId: entry.id };
  });
  uiCommands.register('SET_OBJECT_TRANSFORM', async args => {
    let entry = modelManager.entries.find(item => item.id === String(args.id || ''));
    if (!entry) throw new Error('جسم موردنظر پیدا نشد.');
    entry = await modelManager.ensureLoaded(entry);
    const finite = (value, fallback) => Number.isFinite(Number(value)) ? Number(value) : fallback;
    const scale = THREE.MathUtils.clamp(finite(args.scale, entry.scaleFactor || 1), 0.05, 8);
    const x = finite(args.rotationX, angleDegrees(entry.root.rotation.x));
    const y = finite(args.rotationY, angleDegrees(entry.root.rotation.y));
    const z = finite(args.rotationZ, angleDegrees(entry.root.rotation.z));
    modelManager.setScaleFactor(entry, scale);
    modelManager.setRotationDegrees(entry, x, y, z);
    modelManager.select(entry.id); setMode('arrange');
    return { id: entry.id, scale, rotation: { x, y, z } };
  });
  uiCommands.register('MOVE_CAMERA', args => {
    const direction = String(args.direction || '');
    const distance = THREE.MathUtils.clamp(Number(args.distance) || 0, 0, 25);
    const camera = engine.camera;
    const vectors = {
      right: new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion),
      up: new THREE.Vector3(0, 1, 0),
      forward: new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion)
    };
    const key = direction === 'left' ? 'right' : direction === 'down' ? 'up' : direction === 'back' ? 'forward' : direction;
    const vector = vectors[key];
    if (!vector || !['right', 'left', 'up', 'down', 'forward', 'back'].includes(direction)) throw new Error('جهت دوربین نامعتبر است.');
    const sign = ['left', 'down', 'back'].includes(direction) ? -1 : 1;
    camera.position.addScaledVector(vector, distance * sign);
    camera.updateMatrixWorld(true); refreshTransformGizmo(); spatialStreamer?.update(camera.position); render();
    return { position: camera.position.toArray() };
  });
  uiCommands.register('ADD_ACTIVE_NOTE_AS_FLOATING', async () => {
    const entry = await floatingNotes.addActiveNote();
    setMode('arrange'); renderModels();
    return { id: entry.id, noteId: entry.noteId };
  });
  uiCommands.register('OPEN_NOTEBOOK', () => { openNotebookScreen(); return { opened: true }; });
  uiCommands.register('REMOVE_OBJECT', async args => {
    const id = String(args.id || '');
    if (!modelManager.entries.some(entry => entry.id === id)) throw new Error('جسم موردنظر پیدا نشد.');
    await modelManager.remove(id); renderModels();
    return { removed: id };
  }, { confirm: true });

  // This public, provider-neutral bridge is a foundation only: no AI provider
  // is configured or contacted until the user installs/registers one.
  window.SpatialNotebookAPI = Object.freeze({
    version: '0.4.0',
    ai: Object.freeze({
      registerProvider: (id, provider) => aiProviders.register(id, provider),
      setActiveProvider: id => aiProviders.setActive(id),
      listProviders: () => aiProviders.list(),
      sendMessage: (messages, options) => aiProviders.sendMessage(messages, options)
    }),
    commands: Object.freeze({
      execute: (name, args, options) => uiCommands.execute(name, args, options),
      list: () => uiCommands.list()
    }),
    world: Object.freeze({
      registerChunk: options => { const unregister = spatialStreamer.register(options); spatialStreamer.update(engine.camera.position); return unregister; },
      unregisterChunk: id => spatialStreamer.unregister(id),
      setStreamingRadii: (load, preload) => { spatialStreamer.setRadii(load, preload); spatialStreamer.update(engine.camera.position); },
      getCameraPose: () => cameraController.getPose()
    }),
    animation: Object.freeze({
      on: (eventName, handler) => animationEvents.on(eventName, handler),
      dispatch: (eventName, payload) => animationEvents.dispatch(eventName, payload),
      playModel: (entryId, clipName, options) => animationEvents.playModel(entryId, clipName, options),
      bindModelAnimation: (eventName, clipName, options) => animationEvents.bindModelAnimation(eventName, clipName, options)
    })
  });
}

function bindGlobalEvents() {
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { stopAnimationLoop(); activeDpad = null; }
    else if (worldVisible) { render(); ensureAnimationLoop(); }
  });
  $('worldCanvas').addEventListener('webglcontextlost', event => {
    event.preventDefault(); setStatus('ارتباط گرافیکی قطع شد؛ صفحه را دوباره بارگذاری کن.');
  }, false);
  window.addEventListener('beforeunload', () => {
    try { modelManager?.persistAll(); } catch (_) {}
    animationEvents?.dispose(); transformGizmo?.dispose(); spatialStreamer?.dispose();
  });
}

async function init() {
  $('loadingVeil').hidden = false;
  try {
    engine = new WorldEngine($('worldCanvas'));
    engine.init();
    engine.setTargetFps(settings.targetFps);
    storage = new Storage();
    const persistent = await storage.init();
    themeManager = new ThemeManager({
      storage, onStatus: setStatus,
      onChange: theme => {
        const path = theme.assets?.['backgrounds.workspace'];
        engine?.setBackgroundBlob(path ? theme.files?.[path] || null : null);
      }
    });
    await themeManager.init();
    spatialStreamer = new SpatialStreamer({
      loadRadius: settings.loadRadius,
      preloadRadius: settings.preloadRadius,
      onStatus: setStatus
    });
    aiProviders = new AIProviderRegistry();
    uiCommands = new UICommandRegistry();

    transformGizmo = new TransformGizmo(engine);
    cameraController = new TouchFreeCamera({
      camera: engine.camera,
      element: engine.canvas,
      getMoveMetersPer100Px: () => metersPer100px(settings.moveSlider),
      getLookRadiansPerPx: () => lookRadiansPerPx(settings.lookSlider),
      shouldIgnorePointer: event => currentMode === 'arrange' && Boolean(transformGizmo?.hit(event)),
      onChange: () => { refreshTransformGizmo(); spatialStreamer?.update(engine.camera.position); engine.requestRender(); }
    });
    cameraController.setPose({ position: [0, 1.62, 5.8], yaw: 0, pitch: -0.035 });
    locationManager = new LocationManager(cameraController);
    modelManager = new ModelManager({
      engine, storage,
      onChange: () => { renderModels(); updateSelectedModelPanel(); ensureAnimationLoop(); },
      onStatus: setStatus,
      onConfirmHeavyFile: async ({ summary }) => window.confirm(`این GLB سنگین است و ممکن است محدودیت حافظه WebView را رد کند.\n\n${summary}\n\nآیا با وجود ریسک ریست، ادامه بدهم؟`)
    });
    engine.beforeRender = () => modelManager?.updateCulling(engine.camera);
    floatingNotes = new FloatingNoteManager({
      engine, storage, modelManager,
      getNotebookWindow: () => $('notebookFrame').contentWindow,
      onStatus: setStatus
    });
    animationEvents = new AnimationEventEngine({
      modelManager, themeManager, effectLayer: $('effectsLayer'), onStatus: setStatus,
      onModelAnimation: ensureAnimationLoop
    });
    installIntegrationAPI();

    bindDrawerButtons(); bindSettings(); bindModelControls(); bindArrangeGestures();
    bindCameraDpad(); bindWorldToolbar(); bindNotebookMode(); bindDesignStudio(); bindGlobalEvents();
    renderPlaces();
    await modelManager.restoreSaved();
    modelManager.setDistanceCulling(settings.distanceCullEnabled, settings.distanceCullRadius);
    ensureAnimationLoop();

    $('loadingVeil').hidden = true;
    setStatus(persistent ? 'سه‌بعدی آماده · ذخیرهٔ مدل‌ها، یادداشت‌های فضایی و تم‌ها فعال است' : 'سه‌بعدی آماده · ذخیرهٔ پایدار در دسترس نیست');
    showToast('یک انگشت: چرخش نگاه · دو انگشت: جلو/عقب · چهار فلش: حرکت جانبی/عمودی.');
    refreshTransformGizmo(); engine.requestRender();
  } catch (error) {
    console.error(error); $('loadingVeil').hidden = true;
    setStatus(`راه‌اندازی ناموفق: ${error.message}`);
    showToast(`راه‌اندازی WebGL ناموفق بود: ${error.message}`, 5000);
  }
}

init();
