const STORAGE_KEY = 'spatial-notebook-v02-locations';

export class LocationManager {
  constructor(cameraController) {
    this.cameraController = cameraController;
    this.places = this._read();
  }

  _read() {
    try {
      const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(value) ? value : [];
    } catch (_) { return []; }
  }

  _write() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.places));
  }

  save(name) {
    const cleanName = String(name || '').trim();
    if (!cleanName) throw new Error('نام مکان خالی است.');
    const pose = this.cameraController.getPose();
    const record = {
      id: crypto.randomUUID?.() || `place_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      name: cleanName,
      position: pose.position,
      yaw: pose.yaw,
      pitch: pose.pitch,
      createdAt: new Date().toISOString()
    };
    this.places.unshift(record);
    this._write();
    return record;
  }

  remove(id) {
    this.places = this.places.filter(place => place.id !== id);
    this._write();
  }

  search(query = '') {
    const q = String(query).trim().toLocaleLowerCase('fa');
    if (!q) return [...this.places];
    return this.places.filter(place => place.name.toLocaleLowerCase('fa').includes(q));
  }
}
