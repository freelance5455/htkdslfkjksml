import JSZip from 'jszip';

const ACTIVE_THEME_KEY = 'spatial-notebook-active-theme';
const THEME_COLOR_KEYS = ['--bg','--panel','--panel2','--panel3','--line','--text','--muted','--accent','--accent2','--danger','--topbar-bg','--stage-a','--stage-b'];
const BUILTIN = {
  default: { id: 'default', name: 'پایه', colors: { '--bg':'#101820','--panel':'#17232d','--panel2':'#202f3b','--panel3':'#253744','--line':'#344754','--text':'#edf4f7','--muted':'#9fb2bc','--accent':'#70d4c0','--accent2':'#d6b47a','--danger':'#ed8585','--topbar-bg':'#111c25','--stage-a':'#9db7c2','--stage-b':'#263b48' } },
  scifi: { id: 'scifi', name: 'تکنولوژیک', colors: { '--bg':'#071421','--panel':'#0b2030','--panel2':'#102b3d','--panel3':'#173d51','--line':'#23516a','--text':'#e6f8ff','--muted':'#8bb5c8','--accent':'#42d7f5','--accent2':'#8c9cff','--danger':'#ff7a91','--topbar-bg':'#06121f','--stage-a':'#174b65','--stage-b':'#071421' } },
  fantasy: { id: 'fantasy', name: 'فانتزی', colors: { '--bg':'#171326','--panel':'#241b36','--panel2':'#302344','--panel3':'#403052','--line':'#58446d','--text':'#f5efff','--muted':'#c0accf','--accent':'#c6a4ff','--accent2':'#f0c58d','--danger':'#f18aa8','--topbar-bg':'#171126','--stage-a':'#51436c','--stage-b':'#171326' } },
  rpg: { id: 'rpg', name: 'گیمینگ', colors: { '--bg':'#101a20','--panel':'#19272b','--panel2':'#263a3b','--panel3':'#304847','--line':'#46615b','--text':'#f0f7ed','--muted':'#a8baaa','--accent':'#a8d87d','--accent2':'#e3bd6a','--danger':'#e58470','--topbar-bg':'#101b1e','--stage-a':'#4e6759','--stage-b':'#121b20' } }
};

function safeSvg(source) {
  const doc = new DOMParser().parseFromString(String(source), 'image/svg+xml');
  if (doc.querySelector('parsererror')) throw new Error('فایل SVG معتبر نیست.');
  const svg = doc.documentElement;
  if (svg.nodeName.toLowerCase() !== 'svg') throw new Error('ریشه فایل SVG باید عنصر svg باشد.');
  svg.querySelectorAll('script,foreignObject,iframe,object,embed,style').forEach(node => node.remove());
  const elements = [svg, ...svg.querySelectorAll('*')];
  for (const element of elements) {
    for (const attribute of [...element.attributes]) {
      const name = attribute.name.toLowerCase();
      const value = attribute.value.trim().toLowerCase();
      const externalUrl = /url\(\s*['\"]?(?:https?:|\/\/|data:|javascript:)/i.test(value);
      if (name.startsWith('on') || name === 'style' && (value.includes('url(') || value.includes('@import') || value.includes('expression(')) || externalUrl || (name === 'href' || name.endsWith(':href')) && (value.startsWith('javascript:') || value.startsWith('http:') || value.startsWith('https:') || value.startsWith('//') || value.startsWith('data:'))) {
        element.removeAttribute(attribute.name);
      }
    }
  }
  if (!svg.getAttribute('viewBox')) svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', '24');
  svg.setAttribute('height', '24');
  svg.setAttribute('aria-hidden', 'true');
  return new XMLSerializer().serializeToString(svg);
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export class ThemeManager {
  constructor({ storage, onChange = () => {}, onStatus = () => {} }) {
    this.storage = storage;
    this.onChange = onChange;
    this.onStatus = onStatus;
    this.activeId = localStorage.getItem(ACTIVE_THEME_KEY) || 'default';
    this.customThemes = new Map();
    this.originalIcons = new Map();
    this.objectUrls = new Set();
    document.querySelectorAll('[data-icon-id]').forEach(element => this.originalIcons.set(element, element.innerHTML));
  }

  async init() {
    if (this.storage?.persistent) {
      const stored = await this.storage.getAllThemes().catch(() => []);
      for (const theme of stored) this.customThemes.set(theme.id, theme);
    }
    if (!BUILTIN[this.activeId] && !this.customThemes.has(this.activeId)) this.activeId = 'default';
    await this.apply(this.activeId);
  }

  list() {
    return [...Object.values(BUILTIN).map(({ id, name }) => ({ id, name, builtin: true })),
      ...[...this.customThemes.values()].map(theme => ({ id: theme.id, name: theme.name, builtin: false }))];
  }

  get active() { return this.customThemes.get(this.activeId) || BUILTIN[this.activeId] || BUILTIN.default; }

  async apply(id) {
    const theme = this.customThemes.get(id) || BUILTIN[id];
    if (!theme) throw new Error('تم موردنظر پیدا نشد.');
    this.activeId = id;
    localStorage.setItem(ACTIVE_THEME_KEY, id);
    const colors = theme.colors || {};
    for (const key of THEME_COLOR_KEYS) {
      if (!(key in colors)) document.documentElement.style.removeProperty(key);
    }
    for (const [key, value] of Object.entries(colors)) {
      if (/^--[a-z0-9-]+$/i.test(key) && typeof value === 'string' && /^#[0-9a-f]{3,8}$/i.test(value)) {
        document.documentElement.style.setProperty(key, value);
      }
    }
    await this._applyIcons(theme);
    await this._applyBackground(theme);
    document.querySelectorAll('[data-theme]').forEach(button => button.classList.toggle('active', button.dataset.theme === id));
    this.onChange(theme);
  }

  async _applyIcons(theme) {
    for (const url of this.objectUrls) URL.revokeObjectURL(url);
    this.objectUrls.clear();
    for (const [element, original] of this.originalIcons) {
      const iconId = element.dataset.iconId;
      const assetPath = theme.assets?.[`icons.${iconId}`];
      if (!assetPath || !theme.files?.[assetPath]) {
        element.innerHTML = original;
        continue;
      }
      const blob = theme.files[assetPath];
      if (/\.svg$/i.test(assetPath)) {
        const markup = safeSvg(await blob.text());
        element.innerHTML = markup;
      } else if (/\.(png|webp)$/i.test(assetPath)) {
        const url = URL.createObjectURL(blob);
        this.objectUrls.add(url);
        const image = document.createElement('img');
        image.src = url;
        image.alt = '';
        image.className = 'themeIconImage';
        element.replaceChildren(image);
      }
    }
  }

  async _applyBackground(theme) {
    const path = theme.assets?.['backgrounds.workspace'];
    const blob = path ? theme.files?.[path] : null;
    if (!blob) {
      document.documentElement.style.removeProperty('--workspace-bg-image');
      return;
    }
    const url = URL.createObjectURL(blob);
    this.objectUrls.add(url);
    document.documentElement.style.setProperty('--workspace-bg-image', `url("${url}")`);
  }

  async setColor(token, value) {
    if (!THEME_COLOR_KEYS.includes(token) || !/^#[0-9a-f]{6}$/i.test(String(value))) {
      throw new Error('رنگ یا شناسهٔ رنگ معتبر نیست.');
    }
    let theme = this.customThemes.get(this.activeId);
    if (!theme) theme = await this._createCustomFromActive();
    theme.colors ||= {};
    theme.colors[token] = value;
    await this._save(theme);
    await this.apply(theme.id);
    return theme;
  }

  async setBackgroundAsset(file) {
    if (!file || !/^image\/(png|webp|jpeg)$/.test(file.type) || file.size > 24 * 1024 * 1024) {
      throw new Error('پس‌زمینه باید تصویر PNG، WebP یا JPEG تا ۲۴ مگابایت باشد.');
    }
    let theme = this.customThemes.get(this.activeId);
    if (!theme) theme = await this._createCustomFromActive();
    const ext = file.type === 'image/jpeg' ? 'jpg' : file.type.split('/')[1];
    const path = `backgrounds/workspace.${ext}`;
    theme.assets ||= {};
    theme.files ||= {};
    theme.assets['backgrounds.workspace'] = path;
    theme.files[path] = file;
    await this._save(theme);
    await this.apply(theme.id);
    return theme;
  }

  async _createCustomFromActive() {
    const base = this.active;
    const id = `custom-${crypto.randomUUID?.() || Date.now().toString(36)}`;
    // Clone the current theme's assets as well as its colors. Replacing one
    // icon must not silently discard icons/animations customized earlier.
    const theme = { id, name: `${base.name || 'تم'} · شخصی`, colors: { ...(base.colors || {}) }, assets: { ...(base.assets || {}) }, files: { ...(base.files || {}) } };
    this.customThemes.set(id, theme);
    this.activeId = id;
    await this._save(theme);
    return theme;
  }

  async _save(theme) {
    this.customThemes.set(theme.id, theme);
    if (this.storage?.persistent) await this.storage.putTheme(theme);
  }

  async setIconAsset(iconId, file) {
    if (!/^[a-z0-9_-]+$/i.test(iconId)) throw new Error('شناسه آیکون نامعتبر است.');
    if (!file || file.size > 2 * 1024 * 1024) throw new Error('فایل آیکون باید حداکثر ۲ مگابایت باشد.');
    const ext = file.name.split('.').pop().toLowerCase();
    if (!['svg', 'png', 'webp'].includes(ext)) throw new Error('فرمت آیکون باید SVG، PNG یا WebP باشد.');
    if (ext === 'svg') safeSvg(await file.text());
    let theme = this.customThemes.get(this.activeId);
    if (!theme) theme = await this._createCustomFromActive();
    const path = `icons/${iconId}.${ext}`;
    theme.assets ||= {};
    theme.files ||= {};
    theme.assets[`icons.${iconId}`] = path;
    theme.files[path] = file;
    await this._save(theme);
    await this.apply(theme.id);
    return theme;
  }

  async importZip(file) {
    if (!file || file.size > 80 * 1024 * 1024) throw new Error('بسته تم باید حداکثر ۸۰ مگابایت باشد.');
    const zip = await JSZip.loadAsync(file);
    const manifestFile = zip.file('manifest.json');
    if (!manifestFile) throw new Error('فایل manifest.json در بسته تم وجود ندارد.');
    const manifest = JSON.parse(await manifestFile.async('text'));
    if (manifest.format !== 'spatial-theme' || Number(manifest.version) !== 1 || !manifest.id) throw new Error('ساختار Manifest با نسخه فعلی سازگار نیست.');
    const files = {};
    let totalUncompressed = 0;
    for (const [logicalId, path] of Object.entries(manifest.assets || {})) {
      if (typeof path !== 'string' || path.startsWith('/') || path.includes('..')) throw new Error('مسیر دارایی نامعتبر است.');
      const zipEntry = zip.file(path);
      if (!zipEntry) continue;
      const ext = path.split('.').pop().toLowerCase();
      if (!['svg', 'png', 'webp', 'jpg', 'jpeg', 'json'].includes(ext)) continue;
      const blob = await zipEntry.async('blob');
      const assetLimit = ext === 'json' ? 12 * 1024 * 1024 : 24 * 1024 * 1024;
      if (blob.size > assetLimit) throw new Error(`دارایی ${path} از حد مجاز این نوع فایل بزرگ‌تر است.`);
      totalUncompressed += blob.size;
      if (totalUncompressed > 100 * 1024 * 1024) throw new Error('حجم بازشدهٔ کل دارایی‌های تم از ۱۰۰ مگابایت بیشتر است.');
      if (ext === 'svg') safeSvg(await blob.text());
      if (ext === 'json') JSON.parse(await blob.text());
      files[path] = blob;
    }
    const id = `imported-${manifest.id}-${Date.now().toString(36)}`;
    const theme = { id, name: String(manifest.name || 'تم واردشده').slice(0, 64), colors: manifest.colors || {}, assets: manifest.assets || {}, files };
    await this._save(theme);
    await this.apply(id);
    this.onStatus(`تم «${theme.name}» وارد و فعال شد.`);
    return theme;
  }

  async exportActive() {
    const theme = this.active;
    const zip = new JSZip();
    const assets = {};
    for (const [key, path] of Object.entries(theme.assets || {})) {
      const blob = theme.files?.[path];
      if (!blob) continue;
      assets[key] = path;
      zip.file(path, blob);
    }
    zip.file('manifest.json', JSON.stringify({ format: 'spatial-theme', version: 1, id: theme.id, name: theme.name, colors: theme.colors || {}, assets }, null, 2));
    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 6 } });
    downloadBlob(blob, `${(theme.name || 'theme').replace(/[^\p{L}\p{N}-]+/gu, '-')}.zip`);
    return blob;
  }

  async getAssetBlob(logicalId) {
    const theme = this.active;
    const path = theme.assets?.[logicalId];
    return path ? theme.files?.[path] || null : null;
  }

  async getAssetJson(logicalId) {
    const blob = await this.getAssetBlob(logicalId);
    if (!blob) return null;
    return JSON.parse(await blob.text());
  }

  async remove(id) {
    if (!this.customThemes.has(id)) return false;
    this.customThemes.delete(id);
    await this.storage?.deleteTheme(id).catch(() => {});
    if (this.activeId === id) await this.apply('default');
    return true;
  }
}
