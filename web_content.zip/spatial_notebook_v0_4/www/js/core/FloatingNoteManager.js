import * as THREE from 'three';

/** Bridges the existing BoomNote renderer into transformable 3D note surfaces. */
export class FloatingNoteManager {
  constructor({ engine, storage, modelManager, getNotebookWindow, onStatus = () => {} }) {
    this.engine = engine;
    this.storage = storage;
    this.modelManager = modelManager;
    this.getNotebookWindow = getNotebookWindow;
    this.onStatus = onStatus;
    this.refreshTimers = new Map();
  }

  get bridge() {
    const win = this.getNotebookWindow?.();
    return win?.BN?.ready ? win.BN : null;
  }

  async _renderNote(note) {
    const bridge = this.bridge;
    if (!bridge || !note) throw new Error('دفترچهٔ دوبعدی هنوز آماده نیست.');
    await bridge.flushSave?.();
    return bridge.renderNoteCanvas(note, { maxW: 1400, maxH: 1400, margin: 32 });
  }

  _createEntry(note, canvas, record = {}) {
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.anisotropy = Math.min(8, this.engine.renderer?.capabilities?.getMaxAnisotropy?.() || 1);
    const aspect = Math.max(0.35, Math.min(3.5, canvas.width / Math.max(1, canvas.height)));
    const height = 1.25;
    const root = new THREE.Group();
    root.name = `Floating note: ${note.title || 'یادداشت'}`;
    const geometry = new THREE.PlaneGeometry(height * aspect, height);
    const material = new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide, toneMapped: false });
    const surface = new THREE.Mesh(geometry, material);
    surface.name = 'FloatingNoteSurface';
    root.add(surface);

    if (record.position) root.position.fromArray(record.position);
    else {
      const forward = this.engine.camera.getWorldDirection(new THREE.Vector3()).normalize();
      root.position.copy(this.engine.camera.position).addScaledVector(forward, 2.35);
    }
    if (record.quaternion) root.quaternion.fromArray(record.quaternion);
    else {
      const towardCamera = this.engine.camera.position.clone().sub(root.position).normalize();
      root.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), towardCamera);
    }
    if (record.scale) root.scale.fromArray(record.scale);

    const id = record.id || `floating-note-${note.id}`;
    root.userData.entryId = id;
    surface.userData.entryId = id;
    const entry = {
      id,
      name: note.title || 'یادداشت شناور',
      kind: 'floating-note',
      noteId: note.id,
      root,
      scaleFactor: record.scaleFactor || 1,
      baseScale: new THREE.Vector3(1, 1, 1),
      mixer: null,
      lastNoteUpdated: note.updated || 0
    };
    return entry;
  }

  async addActiveNote() {
    const bridge = this.bridge;
    if (!bridge?.app?.note) throw new Error('ابتدا دفترچهٔ دوبعدی را باز کن تا یک یادداشت فعال داشته باشی.');
    await bridge.flushSave?.();
    const note = bridge.app.note;
    const existing = this.modelManager.entries.find(entry => entry.kind === 'floating-note' && entry.noteId === note.id);
    if (existing) {
      this.modelManager.select(existing.id);
      this.onStatus('این یادداشت از قبل در فضای سه‌بعدی قرار دارد.');
      return existing;
    }
    const canvas = await this._renderNote(note);
    const entry = this._createEntry(note, canvas);
    this.modelManager.registerExternal(entry, true);
    this.onStatus(`یادداشت «${entry.name}» به فضای سه‌بعدی اضافه شد.`);
    return entry;
  }

  async waitForBridge(timeoutMs = 10000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      if (this.bridge) return this.bridge;
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    return null;
  }

  async restore() {
    if (!this.storage.persistent) return;
    const bridge = await this.waitForBridge(10000);
    if (!bridge) return;
    const records = await this.storage.getAllFloatingNotes().catch(() => []);
    for (const record of records) {
      try {
        const note = await bridge.Store.noteGet(record.noteId);
        if (!note) continue;
        const canvas = await this._renderNote(note);
        const entry = this._createEntry(note, canvas, record);
        this.modelManager.registerExternal(entry, false);
      } catch (error) {
        console.warn('Could not restore floating note:', record.noteId, error);
      }
    }
  }

  notifyChanged(noteId) {
    if (!noteId) return;
    if (this.refreshTimers.has(noteId)) clearTimeout(this.refreshTimers.get(noteId));
    const timer = setTimeout(() => {
      this.refreshTimers.delete(noteId);
      this.refresh(noteId).catch(error => console.warn('Floating note refresh failed:', error));
    }, 450);
    this.refreshTimers.set(noteId, timer);
  }

  async refresh(noteId) {
    const entries = this.modelManager.entries.filter(entry => entry.kind === 'floating-note' && entry.noteId === noteId);
    if (!entries.length) return;
    const bridge = this.bridge;
    if (!bridge) return;
    await bridge.flushSave?.();
    const note = bridge.app?.note?.id === noteId ? bridge.app.note : await bridge.Store.noteGet(noteId);
    if (!note) return;
    const canvas = await this._renderNote(note);
    for (const entry of entries) {
      const surface = entry.root.getObjectByName('FloatingNoteSurface');
      if (!surface) continue;
      const oldTexture = surface.material.map;
      const texture = new THREE.CanvasTexture(canvas);
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.anisotropy = Math.min(8, this.engine.renderer?.capabilities?.getMaxAnisotropy?.() || 1);
      surface.material.map = texture;
      surface.material.needsUpdate = true;
      oldTexture?.dispose();
      const aspect = Math.max(0.35, Math.min(3.5, canvas.width / Math.max(1, canvas.height)));
      surface.geometry.dispose();
      surface.geometry = new THREE.PlaneGeometry(1.25 * aspect, 1.25);
      entry.name = note.title || 'یادداشت شناور';
      entry.lastNoteUpdated = note.updated || Date.now();
      this.modelManager.updateBounds?.(entry);
      await this.modelManager.persist(entry);
    }
    this.engine.requestRender();
  }

  async openForEditing(noteId, showNotebook) {
    const bridge = this.bridge;
    if (!bridge) throw new Error('دفترچه هنوز آماده نیست.');
    await showNotebook();
    await bridge.openNote(noteId);
  }
}
