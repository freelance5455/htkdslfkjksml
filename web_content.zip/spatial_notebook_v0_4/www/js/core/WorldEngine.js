import * as THREE from 'three';

function standard(color, roughness = 0.78, metalness = 0) {
  return new THREE.MeshStandardMaterial({ color, roughness, metalness });
}

export class WorldEngine {
  constructor(canvas) {
    this.canvas = canvas;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x9eafb1);
    this.camera = new THREE.PerspectiveCamera(66, 1, 0.01, 3000);
    this.camera.position.set(0, 1.62, 5.8);
    this.renderer = null;
    this.environment = new THREE.Group();
    this.modelsGroup = new THREE.Group();
    this.scene.add(this.environment, this.modelsGroup);
    this.raycaster = new THREE.Raycaster();
    this.ndc = new THREE.Vector2();
    this._renderQueued = false;
    this._lastRenderTime = 0;
    this._targetFps = 60;
    this._backgroundTexture = null;
    this._backgroundRequest = 0;
    this.resizeObserver = null;
    this.beforeRender = null;
  }

  init() {
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      alpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: false
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.shadowMap.enabled = false;

    this.scene.add(new THREE.HemisphereLight(0xe9f5ff, 0x6c594c, 1.55));
    const key = new THREE.DirectionalLight(0xffe4c3, 2.15);
    key.position.set(-5, 9, 5);
    this.scene.add(key);
    const fill = new THREE.DirectionalLight(0xb8d8ff, 0.65);
    fill.position.set(5, 4, -5);
    this.scene.add(fill);

    this.buildTestRoom();
    this.resize();
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(this.canvas.parentElement);
    this.render();
  }

  addBox(parent, name, size, position, material, { bevel = false } = {}) {
    const geometry = bevel
      ? new THREE.BoxGeometry(size[0], size[1], size[2], 1, 1, 1)
      : new THREE.BoxGeometry(...size);
    const mesh = new THREE.Mesh(geometry, material);
    mesh.name = name;
    mesh.position.set(...position);
    mesh.castShadow = false;
    mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  }

  buildTestRoom() {
    const floorMat = standard(0x887763, 0.88);
    const wallMat = standard(0xd9d0bd, 0.92);
    const trimMat = standard(0x725a46, 0.75);
    const tableMat = standard(0x76513a, 0.48);
    const rugMat = new THREE.MeshStandardMaterial({ color: 0x516e72, roughness: 0.98, metalness: 0 });

    // The room is intentionally a lightweight blockout, not a fabricated GLB.
    this.addBox(this.environment, 'Test floor', [24, 0.16, 24], [0, -0.08, 0], floorMat);
    this.addBox(this.environment, 'Back wall', [24, 4.4, 0.18], [0, 2.2, -8], wallMat);
    this.addBox(this.environment, 'Left wall', [0.18, 4.4, 16], [-8, 2.2, 0], wallMat);
    this.addBox(this.environment, 'Right wall', [0.18, 4.4, 16], [8, 2.2, 0], wallMat);
    this.addBox(this.environment, 'Back skirting', [24, 0.13, 0.24], [0, 0.08, -7.88], trimMat);
    this.addBox(this.environment, 'Left skirting', [0.24, 0.13, 16], [-7.88, 0.08, 0], trimMat);
    this.addBox(this.environment, 'Right skirting', [0.24, 0.13, 16], [7.88, 0.08, 0], trimMat);

    const rug = new THREE.Mesh(new THREE.BoxGeometry(6.2, 0.025, 4.1), rugMat);
    rug.position.set(0, 0.012, -1.5);
    this.environment.add(rug);

    // Decorative dining table; object placement is free-space and never snaps to it.
    this.addBox(this.environment, 'Dining table top', [2.35, 0.14, 1.25], [0.2, 0.78, -1.05], tableMat);
    const legPositions = [
      [-0.82, 0.36, -1.48], [1.22, 0.36, -1.48],
      [-0.82, 0.36, -0.62], [1.22, 0.36, -0.62]
    ];
    legPositions.forEach((p, i) => this.addBox(this.environment, `Table leg ${i + 1}`, [0.12, 0.72, 0.12], p, trimMat));

    // A low shelf and a wall panel provide scale cues when the user flies around.
    this.addBox(this.environment, 'Side cabinet', [1.35, 0.92, 0.48], [-5.75, 0.46, -3.7], standard(0x88705a, 0.72));
    this.addBox(this.environment, 'Cabinet top', [1.44, 0.08, 0.55], [-5.75, 0.96, -3.7], trimMat);

    const frameMat = standard(0x4f5e60, 0.58, 0.08);
    this.addBox(this.environment, 'Window frame horizontal', [2.8, 0.09, 0.12], [0, 2.45, -7.88], frameMat);
    this.addBox(this.environment, 'Window frame vertical left', [0.09, 1.55, 0.12], [-1.35, 2.45, -7.88], frameMat);
    this.addBox(this.environment, 'Window frame vertical right', [0.09, 1.55, 0.12], [1.35, 2.45, -7.88], frameMat);
    this.addBox(this.environment, 'Window sill', [2.9, 0.12, 0.25], [0, 1.67, -7.83], frameMat);
  }

  resize() {
    if (!this.renderer || !this.canvas.parentElement) return;
    const rect = this.canvas.parentElement.getBoundingClientRect();
    const width = Math.max(1, Math.floor(rect.width));
    const height = Math.max(1, Math.floor(rect.height));
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height, false);
    this.render();
  }

  setPointerFromEvent(event) {
    const rect = this.canvas.getBoundingClientRect();
    this.ndc.set(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -((event.clientY - rect.top) / rect.height) * 2 + 1
    );
    this.raycaster.setFromCamera(this.ndc, this.camera);
  }

  hitModel(event, entries) {
    this.setPointerFromEvent(event);
    const roots = entries.map(entry => entry.root).filter(root => root?.visible);
    const hits = this.raycaster.intersectObjects(roots, true);
    if (!hits.length) return null;
    let node = hits[0].object;
    while (node && !node.userData.entryId) node = node.parent;
    return node?.userData.entryId || null;
  }

  render() {
    if (!this.renderer) return;
    try { this.beforeRender?.(); } catch (error) { console.warn('Before-render hook failed:', error); }
    this.renderer.render(this.scene, this.camera);
  }

  setBackgroundBlob(blob) {
    const requestId = ++this._backgroundRequest;
    if (this._backgroundTexture) {
      this._backgroundTexture.dispose();
      this._backgroundTexture = null;
    }
    this.scene.background = new THREE.Color(0x9eafb1);
    if (!blob || !this.renderer) { this.requestRender(); return; }
    const url = URL.createObjectURL(blob);
    new THREE.TextureLoader().load(url, texture => {
      URL.revokeObjectURL(url);
      if (requestId !== this._backgroundRequest) { texture.dispose(); return; }
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.mapping = THREE.UVMapping;
      this._backgroundTexture = texture;
      this.scene.background = texture;
      this.requestRender();
    }, undefined, error => {
      URL.revokeObjectURL(url);
      if (requestId === this._backgroundRequest) console.warn('Theme background could not be loaded:', error);
    });
  }

  setTargetFps(value) {
    const fps = Number(value);
    this._targetFps = Number.isFinite(fps) && fps > 0 ? Math.min(240, Math.max(1, fps)) : 0;
    this.requestRender();
  }

  requestRender() {
    if (this._renderQueued) return;
    this._renderQueued = true;
    const schedule = () => requestAnimationFrame(now => {
      const interval = this._targetFps > 0 ? 1000 / this._targetFps : 0;
      const elapsed = now - this._lastRenderTime;
      if (interval && this._lastRenderTime && elapsed < interval) {
        setTimeout(schedule, Math.max(0, interval - elapsed));
        return;
      }
      this._renderQueued = false;
      this._lastRenderTime = now;
      this.render();
    });
    schedule();
  }

  dispose() {
    this._backgroundRequest++;
    this._backgroundTexture?.dispose();
    this._backgroundTexture = null;
    this.resizeObserver?.disconnect();
    if (this.renderer) {
      this.renderer.dispose();
      this.renderer.forceContextLoss();
    }
  }
}
