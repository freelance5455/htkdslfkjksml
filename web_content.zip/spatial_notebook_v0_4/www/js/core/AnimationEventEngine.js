import lottie from 'lottie-web';

/** Event-to-animation bridge for GLB clips and replaceable Lottie UI effects. */
export class AnimationEventEngine {
  constructor({ modelManager, themeManager, effectLayer, onStatus = () => {}, onModelAnimation = () => {} }) {
    this.modelManager = modelManager;
    this.themeManager = themeManager;
    this.effectLayer = effectLayer;
    this.onStatus = onStatus;
    this.onModelAnimation = onModelAnimation;
    this.handlers = new Map();
    this.modelBindings = new Map();
    this.sequence = 0;
    this.activeLottie = new Set();
  }

  on(eventName, handler) {
    if (!this.handlers.has(eventName)) this.handlers.set(eventName, new Set());
    this.handlers.get(eventName).add(handler);
    return () => this.handlers.get(eventName)?.delete(handler);
  }

  dispatch(eventName, payload = {}) {
    const event = { type: eventName, payload, sequence: ++this.sequence, time: performance.now() };
    for (const handler of this.handlers.get(eventName) || []) {
      try { handler(event); } catch (error) { console.error(`Animation event ${eventName} failed`, error); }
    }
    for (const binding of this.modelBindings.get(eventName) || []) {
      const entryId = binding.entryId || (binding.entryIdFromPayload ? payload.entryId : null);
      if (entryId) this.playModel(entryId, binding.clipName, binding.options);
    }
    this.playUIAnimation(`animations.${eventName.toLowerCase()}`).catch(() => {});
    return event;
  }

  bindModelAnimation(eventName, clipName, { entryId = null, entryIdFromPayload = true, ...options } = {}) {
    if (!eventName || !clipName) throw new TypeError('Event name and GLB clip name are required');
    if (!this.modelBindings.has(eventName)) this.modelBindings.set(eventName, new Set());
    const binding = { entryId, entryIdFromPayload, clipName, options };
    this.modelBindings.get(eventName).add(binding);
    return () => this.modelBindings.get(eventName)?.delete(binding);
  }

  playModel(entryId, clipName, options = {}) {
    const entry = this.modelManager?.entries.find(item => item.id === entryId);
    if (!entry) return false;
    const played = this.modelManager.playAnimation(entry, clipName, options);
    if (!played) this.onStatus(`انیمیشن «${clipName}» در این مدل موجود نیست.`);
    else this.onModelAnimation();
    return played;
  }

  async playUIAnimation(logicalId) {
    if (!this.effectLayer || !this.themeManager) return false;
    const data = await this.themeManager.getAssetJson(logicalId);
    if (!data) return false;
    const container = document.createElement('div');
    container.className = 'lottieEffect';
    this.effectLayer.append(container);
    const animation = lottie.loadAnimation({ container, renderer: 'svg', loop: false, autoplay: true, animationData: data });
    this.activeLottie.add(animation);
    const cleanup = () => {
      animation.destroy();
      this.activeLottie.delete(animation);
      container.remove();
    };
    animation.addEventListener('complete', cleanup, { once: true });
    animation.addEventListener('data_failed', cleanup, { once: true });
    return true;
  }

  dispose() {
    for (const animation of this.activeLottie) animation.destroy();
    this.activeLottie.clear();
    this.modelBindings.clear();
    this.handlers.clear();
    this.effectLayer?.replaceChildren();
  }
}
