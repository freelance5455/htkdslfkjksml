/**
 * Chunk-based spatial asset streaming coordinator.
 * GLB is an asset container, not a world-streaming protocol. Register independent
 * world chunks with load/unload callbacks; load() receives { tier, distance }.
 * The application decides how a chunk's active/prefetch tier maps to LOD/assets.
 */
export class SpatialStreamer {
  constructor({ loadRadius = 35, preloadRadius = 55, maxConcurrent = 2, onStatus = () => {} } = {}) {
    this.loadRadius = Math.max(1, Number(loadRadius) || 1);
    this.preloadRadius = Math.max(this.loadRadius, Number(preloadRadius) || this.loadRadius);
    this.maxConcurrent = Math.max(1, Math.floor(Number(maxConcurrent) || 1));
    this.onStatus = onStatus;
    this.chunks = new Map();
    this.pending = [];
    this.activeLoads = 0;
    this.disposed = false;
  }

  register({ id, position, load, unload, setTier, radius = 0 }) {
    if (!id || !Array.isArray(position) || position.length !== 3 || !position.every(Number.isFinite) || typeof load !== 'function') {
      throw new TypeError('Chunk requires id, a finite [x,y,z] position and load()');
    }
    if (this.chunks.has(id)) this.unregister(id);
    this.chunks.set(id, {
      id, position: [...position], radius: Math.max(0, Number(radius) || 0), load, unload, setTier,
      state: 'unloaded', tier: null, targetTier: null, value: null, lastDistance: Infinity, generation: 0, abortController: null
    });
    return () => this.unregister(id);
  }

  unregister(id) {
    const chunk = this.chunks.get(id);
    if (!chunk) return;
    chunk.generation++;
    chunk.abortController?.abort();
    chunk.abortController = null;
    this.pending = this.pending.filter(item => item !== chunk);
    if (chunk.state === 'loaded' || chunk.state === 'transitioning') {
      try { chunk.unload?.(chunk.value); } catch (error) { this.onStatus(`آزادسازی بخش ${id} ناموفق بود: ${error.message}`); }
    }
    chunk.state = 'unloaded';
    chunk.value = null;
    this.chunks.delete(id);
  }

  setRadii(loadRadius, preloadRadius = loadRadius * 1.5) {
    this.loadRadius = Math.max(1, Number(loadRadius) || 1);
    this.preloadRadius = Math.max(this.loadRadius, Number(preloadRadius) || this.loadRadius);
  }

  update(cameraPosition) {
    if (this.disposed) return;
    const candidates = [];
    for (const chunk of this.chunks.values()) {
      const dx = cameraPosition.x - chunk.position[0];
      const dy = cameraPosition.y - chunk.position[1];
      const dz = cameraPosition.z - chunk.position[2];
      const distance = Math.max(0, Math.hypot(dx, dy, dz) - chunk.radius);
      chunk.lastDistance = distance;
      const wantedTier = distance <= this.loadRadius ? 'active' : distance <= this.preloadRadius ? 'prefetch' : null;
      chunk.targetTier = wantedTier;

      if (!wantedTier) {
        if (chunk.state === 'loaded' || chunk.state === 'transitioning' || chunk.state === 'loading') this._unload(chunk);
        this.pending = this.pending.filter(item => item !== chunk);
        continue;
      }

      if (chunk.state === 'unloaded') candidates.push(chunk);
      else if (chunk.state === 'loaded' && chunk.tier !== wantedTier) this._transitionTier(chunk, wantedTier);
    }
    candidates.sort((a, b) => (a.targetTier === 'active' ? 0 : 1) - (b.targetTier === 'active' ? 0 : 1) || a.lastDistance - b.lastDistance);
    for (const chunk of candidates) if (!this.pending.includes(chunk)) this.pending.push(chunk);
    this._pump();
  }

  _pump() {
    if (this.disposed) return;
    this.pending.sort((a, b) => (a.targetTier === 'active' ? 0 : 1) - (b.targetTier === 'active' ? 0 : 1) || a.lastDistance - b.lastDistance);
    while (this.activeLoads < this.maxConcurrent && this.pending.length) {
      const chunk = this.pending.shift();
      if (!this.chunks.has(chunk.id) || chunk.state !== 'unloaded' || !chunk.targetTier) continue;
      if (chunk.lastDistance > this.preloadRadius) continue;
      this._queueLoad(chunk);
    }
  }

  _queueLoad(chunk) {
    chunk.state = 'loading';
    const generation = ++chunk.generation;
    const requestedTier = chunk.targetTier;
    const controller = new AbortController();
    chunk.abortController = controller;
    this.activeLoads++;
    Promise.resolve().then(() => chunk.load({ tier: requestedTier, distance: chunk.lastDistance, signal: controller.signal })).then(value => {
      if (this.disposed || generation !== chunk.generation || chunk.state !== 'loading' || !this.chunks.has(chunk.id)) {
        chunk.unload?.(value);
        return;
      }
      chunk.value = value;
      chunk.tier = requestedTier;
      chunk.state = 'loaded';
      this.onStatus(`بخش فضایی ${chunk.id} بارگذاری شد (${requestedTier === 'active' ? 'کیفیت فعال' : 'پیش‌بارگذاری'}).`);
      if (!chunk.targetTier) this._unload(chunk);
      else if (chunk.targetTier !== chunk.tier) this._transitionTier(chunk, chunk.targetTier);
    }).catch(error => {
      if (generation === chunk.generation && chunk.state === 'loading') {
        chunk.state = 'unloaded';
        this.onStatus(`بارگذاری بخش ${chunk.id} ناموفق بود: ${error.message}`);
      }
    }).finally(() => {
      if (chunk.abortController === controller) chunk.abortController = null;
      this.activeLoads = Math.max(0, this.activeLoads - 1);
      this._pump();
    });
  }

  _transitionTier(chunk, tier) {
    if (chunk.state !== 'loaded' || chunk.tier === tier) return;
    if (typeof chunk.setTier !== 'function') {
      // Without an explicit LOD switch callback, retain loaded data rather than
      // destroying/reloading a chunk during every radius boundary crossing.
      chunk.tier = tier;
      return;
    }
    chunk.state = 'transitioning';
    const generation = ++chunk.generation;
    Promise.resolve().then(() => chunk.setTier(chunk.value, tier, { distance: chunk.lastDistance })).then(() => {
      if (generation !== chunk.generation || this.disposed || !this.chunks.has(chunk.id)) return;
      chunk.tier = tier;
      chunk.state = 'loaded';
      if (!chunk.targetTier) this._unload(chunk);
      else if (chunk.targetTier !== chunk.tier) this._transitionTier(chunk, chunk.targetTier);
    }).catch(error => {
      if (generation === chunk.generation) {
        chunk.state = 'loaded';
        this.onStatus(`تغییر سطح جزئیات بخش ${chunk.id} ناموفق بود: ${error.message}`);
      }
    });
  }

  _unload(chunk) {
    if (chunk.state === 'loading') {
      chunk.abortController?.abort();
      chunk.abortController = null;
      chunk.generation++;
      chunk.state = 'unloaded';
      chunk.tier = null;
      chunk.value = null;
      return;
    }
    if (chunk.state !== 'loaded' && chunk.state !== 'transitioning') return;
    try { chunk.unload?.(chunk.value); } finally {
      chunk.value = null;
      chunk.tier = null;
      chunk.state = 'unloaded';
      chunk.generation++;
    }
  }

  dispose() {
    this.disposed = true;
    this.pending.length = 0;
    for (const chunk of this.chunks.values()) {
      if (chunk.state === 'loaded' || chunk.state === 'transitioning') {
        try { chunk.unload?.(chunk.value); } catch (_) {}
      }
      chunk.abortController?.abort();
      chunk.abortController = null;
      chunk.generation++;
      chunk.state = 'unloaded';
      chunk.value = null;
    }
    this.chunks.clear();
  }
}
