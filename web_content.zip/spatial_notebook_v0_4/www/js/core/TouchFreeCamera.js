import * as THREE from 'three';

/**
 * Camera controller for a touch-first 3D viewer.
 * - One pointer: yaw/pitch around the camera's own position (never an orbit target).
 * - Two pointers: pinch-distance change moves the camera along its current view direction.
 * - No avatar, physics contacts, gravity or floor constraint.
 */
export class TouchFreeCamera {
  constructor({ camera, element, getMoveMetersPer100Px, getLookRadiansPerPx, onChange = () => {}, shouldIgnorePointer = () => false }) {
    this.camera = camera;
    this.element = element;
    this.getMoveMetersPer100Px = getMoveMetersPer100Px;
    this.getLookRadiansPerPx = getLookRadiansPerPx;
    this.onChange = onChange;
    this.shouldIgnorePointer = shouldIgnorePointer;
    this.enabled = true;
    this.pointers = new Map();
    this.gesture = 'idle';
    this.lastPoint = null;
    this.lastPinchDistance = 0;
    this.yaw = 0;
    this.pitch = 0;
    this._forward = new THREE.Vector3();
    this._wheelHandler = (event) => this.handleWheel(event);
    this._down = (event) => this.handlePointerDown(event);
    this._move = (event) => this.handlePointerMove(event);
    this._up = (event) => this.handlePointerEnd(event);

    this.element.addEventListener('pointerdown', this._down, { passive: false });
    this.element.addEventListener('pointermove', this._move, { passive: false });
    this.element.addEventListener('pointerup', this._up, { passive: false });
    this.element.addEventListener('pointercancel', this._up, { passive: false });
    this.element.addEventListener('lostpointercapture', this._up, { passive: false });
    this.element.addEventListener('wheel', this._wheelHandler, { passive: false });
    this.element.style.touchAction = 'none';
  }

  setEnabled(enabled) {
    this.enabled = Boolean(enabled);
    this.cancelGesture();
  }

  setPose({ position, yaw, pitch }) {
    if (position) this.camera.position.fromArray(position);
    if (Number.isFinite(yaw)) this.yaw = yaw;
    if (Number.isFinite(pitch)) this.pitch = pitch;
    this.applyRotation();
  }

  getPose() {
    return {
      position: this.camera.position.toArray(),
      yaw: this.yaw,
      pitch: this.pitch
    };
  }

  applyRotation() {
    // YXZ: yaw about world-up, then pitch about the camera's local right axis.
    // The camera position is intentionally untouched by this method.
    this.camera.rotation.order = 'YXZ';
    this.camera.rotation.set(this.pitch, this.yaw, 0, 'YXZ');
    this.camera.updateMatrixWorld(true);
  }

  handlePointerDown(event) {
    if (!this.enabled || event.pointerType === 'mouse' && event.button !== 0) return;
    if (this.shouldIgnorePointer(event)) return;
    event.preventDefault();
    try { this.element.setPointerCapture(event.pointerId); } catch (_) {}
    this.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });

    if (this.pointers.size === 1) {
      this.gesture = 'look';
      this.lastPoint = { x: event.clientX, y: event.clientY };
    } else if (this.pointers.size === 2) {
      this.gesture = 'pinch';
      this.lastPoint = null;
      this.lastPinchDistance = this.currentPinchDistance();
    } else {
      this.gesture = 'ignore';
    }
  }

  handlePointerMove(event) {
    if (!this.enabled || !this.pointers.has(event.pointerId)) return;
    event.preventDefault();
    this.pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });

    if (this.gesture === 'look' && this.pointers.size === 1 && this.lastPoint) {
      const dx = event.clientX - this.lastPoint.x;
      const dy = event.clientY - this.lastPoint.y;
      this.lastPoint = { x: event.clientX, y: event.clientY };
      const sensitivity = this.getLookRadiansPerPx();
      this.yaw -= dx * sensitivity;
      this.pitch = THREE.MathUtils.clamp(
        this.pitch - dy * sensitivity,
        -Math.PI / 2 + 0.015,
        Math.PI / 2 - 0.015
      );
      this.applyRotation();
      this.onChange('look');
      return;
    }

    if (this.gesture === 'pinch' && this.pointers.size === 2) {
      const distance = this.currentPinchDistance();
      const deltaPixels = distance - this.lastPinchDistance;
      this.lastPinchDistance = distance;
      if (Math.abs(deltaPixels) < 0.01) return;

      const metersPer100Px = this.getMoveMetersPer100Px();
      const distanceMeters = THREE.MathUtils.clamp((deltaPixels / 100) * metersPer100Px, -50, 50);
      this.camera.getWorldDirection(this._forward).normalize();
      this.camera.position.addScaledVector(this._forward, distanceMeters);
      this.camera.updateMatrixWorld(true);
      this.onChange('move');
    }
  }

  handlePointerEnd(event) {
    if (!this.pointers.has(event.pointerId)) return;
    this.pointers.delete(event.pointerId);
    // Do not turn a remaining pinch finger into a look gesture. This avoids a sudden jump.
    this.gesture = 'idle';
    this.lastPoint = null;
    this.lastPinchDistance = 0;
    if (this.pointers.size === 0) this.gesture = 'idle';
  }

  currentPinchDistance() {
    const points = [...this.pointers.values()];
    if (points.length < 2) return 0;
    return Math.hypot(points[0].x - points[1].x, points[0].y - points[1].y);
  }

  handleWheel(event) {
    if (!this.enabled) return;
    event.preventDefault();
    const gain = this.getMoveMetersPer100Px();
    const meters = THREE.MathUtils.clamp((-event.deltaY / 100) * gain, -50, 50);
    this.camera.getWorldDirection(this._forward).normalize();
    this.camera.position.addScaledVector(this._forward, meters);
    this.camera.updateMatrixWorld(true);
    this.onChange('move');
  }

  cancelGesture() {
    this.pointers.clear();
    this.gesture = 'idle';
    this.lastPoint = null;
    this.lastPinchDistance = 0;
  }

  dispose() {
    this.cancelGesture();
    this.element.removeEventListener('pointerdown', this._down);
    this.element.removeEventListener('pointermove', this._move);
    this.element.removeEventListener('pointerup', this._up);
    this.element.removeEventListener('pointercancel', this._up);
    this.element.removeEventListener('lostpointercapture', this._up);
    this.element.removeEventListener('wheel', this._wheelHandler);
  }
}
