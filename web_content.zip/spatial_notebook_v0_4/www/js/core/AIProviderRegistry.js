/** Provider-neutral contract for future cloud and local inference backends. */
export class AIProviderRegistry {
  constructor() { this.providers = new Map(); this.activeId = null; }

  register(id, provider) {
    if (!id || !provider || typeof provider.sendMessage !== 'function') {
      throw new TypeError('Provider must expose a stable id and sendMessage()');
    }
    this.providers.set(id, provider);
    return () => { this.providers.delete(id); if (this.activeId === id) this.activeId = null; };
  }

  setActive(id) {
    if (!this.providers.has(id)) throw new Error(`Unknown AI provider: ${id}`);
    this.activeId = id;
  }

  get active() { return this.activeId ? this.providers.get(this.activeId) || null : null; }

  async sendMessage(messages, options = {}) {
    if (!this.active) throw new Error('هیچ ارائه‌دهندهٔ هوش مصنوعی متصل نشده است.');
    return this.active.sendMessage(messages, options);
  }

  list() { return [...this.providers.entries()].map(([id, provider]) => ({ id, capabilities: provider.getCapabilities?.() || {} })); }
}

/** Allowlisted command surface for a future UI agent. */
export class UICommandRegistry {
  constructor() { this.commands = new Map(); }
  register(name, handler, { confirm = false } = {}) {
    if (!/^[A-Z][A-Z0-9_]{1,63}$/.test(name) || typeof handler !== 'function') throw new TypeError('Invalid UI command');
    this.commands.set(name, { handler, confirm });
  }
  async execute(name, args, { confirmed = false } = {}) {
    const command = this.commands.get(name);
    if (!command) throw new Error(`Command not allowed: ${name}`);
    if (command.confirm && !confirmed) throw new Error(`User confirmation required for ${name}`);
    return command.handler(args || {});
  }
  list() { return [...this.commands.entries()].map(([name, command]) => ({ name, confirm: command.confirm })); }
}
