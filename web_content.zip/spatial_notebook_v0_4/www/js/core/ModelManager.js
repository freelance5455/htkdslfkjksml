import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { inspectGLB, estimateRuntimeBudget, formatBytes } from './GLBInspector.js';

const SAMPLE_ASSETS = {
  chair: {
    id: 'sample-sheen-chair',
    name: 'Sheen Chair — نمونهٔ صندلی',
    url: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/SheenChair/glTF-Binary/SheenChair.glb',
    license: 'CC0-1.0'
  },
  cup: {
    id: 'sample-diffuse-teacup',
    name: 'Diffuse Transmission Teacup — نمونهٔ فنجان',
    url: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Assets/main/Models/DiffuseTransmissionTeacup/glTF-Binary/DiffuseTransmissionTeacup.glb',
    license: 'CC0-1.0'
  }
};

function disposeObject(root) {
  const geometries = new Set();
  const materials = new Set();
  const textures = new Set();
  root.traverse(object => {
    if (object.geometry) geometries.add(object.geometry);
    const mats = Array.isArray(object.material) ? object.material : object.material ? [object.material] : [];
    for (const material of mats) {
      materials.add(material);
      for (const value of Object.values(material)) {
        if (value?.isTexture) textures.add(value);
      }
    }
  });
  for (const texture of textures) texture.dispose();
  for (const material of materials) material.dispose();
  for (const geometry of geometries) geometry.dispose();
}

export class ModelManager {
  constructor({ engine, storage, onChange = () => {}, onStatus = () => {}, onConfirmHeavyFile = async () => true }) {
    this.engine = engine;
    this.storage = storage;
    this.onChange = onChange;
    this.onStatus = onStatus;
    this.onConfirmHeavyFile = onConfirmHeavyFile;
    this.maxFileBytes = 1024 * 1024 * 1024;
    this.distanceCullingEnabled = true;
    this.distanceCullRadius = 250;
    this.loader = new GLTFLoader();
    this.entries = [];
    this.selectedId = null;
    this.persistTimers = new Map();
  }

  get selected() {
    return this.entries.find(entry => entry.id === this.selectedId) || null;
  }

  _normalize(wrapper, contentRoot) {
    // Normalize the GLB content inside a parent Group. The wrapper keeps the
    // user's world transform separate, so scaling/rotating the model remains stable.
    wrapper.updateMatrixWorld(true);
    const bounds = new THREE.Box3().setFromObject(wrapper);
    if (bounds.isEmpty()) return;
    const center = bounds.getCenter(new THREE.Vector3());
    contentRoot.position.x -= center.x;
    contentRoot.position.z -= center.z;
    contentRoot.position.y -= bounds.min.y;
    wrapper.updateMatrixWorld(true);
  }

  _initialPosition() {
    const forward = this.engine.camera.getWorldDirection(new THREE.Vector3()).normalize();
    const point = this.engine.camera.position.clone().addScaledVector(forward, 2.2);
    return point;
  }

  _register(gltf, record, { normalize = true, persist = false } = {}) {
    const contentRoot = gltf.scene || gltf.scenes?.[0];
    if (!contentRoot) throw new Error('فایل GLB صحنهٔ قابل‌نمایش ندارد.');
    const root = new THREE.Group();
    root.add(contentRoot);
    if (normalize) this._normalize(root, contentRoot);

    const id = record.id || (crypto.randomUUID?.() || `model_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`);
    const importedBaseScale = root.scale.clone();
    root.userData.entryId = id;
    root.traverse(child => {
      child.userData.entryId = id;
      if (child.isMesh) {
        child.castShadow = false;
        child.receiveShadow = true;
        child.frustumCulled = true;
        if (child.geometry && !child.geometry.boundingSphere) child.geometry.computeBoundingSphere();
      }
    });

    const entry = {
      id,
      name: record.name || 'مدل سه‌بعدی',
      kind: record.kind || 'local',
      url: record.url || null,
      blob: record.blob || null,
      hasPersistentAsset: record.hasPersistentAsset ?? (record.kind !== 'local'),
      license: record.license || null,
      root,
      scaleFactor: record.scaleFactor || 1,
      baseScale: importedBaseScale,
      mixer: null,
      clips: gltf.animations || [],
      actions: new Map(),
      state: 'active',
      assetInfo: record.assetInfo || null,
      userVisible: true,
      transform: null,
      _loadPromise: null
    };

    if (record.position) root.position.fromArray(record.position);
    else root.position.copy(this._initialPosition());
    if (record.quaternion) root.quaternion.fromArray(record.quaternion);
    if (record.scale) root.scale.fromArray(record.scale);
    else if (entry.scaleFactor !== 1) root.scale.copy(entry.baseScale).multiplyScalar(entry.scaleFactor);

    entry.transform = { position: root.position.toArray(), quaternion: root.quaternion.toArray(), scale: root.scale.toArray() };
    const initialBounds = new THREE.Box3().setFromObject(root);
    entry.boundsSphere = initialBounds.isEmpty() ? new THREE.Sphere(root.position.clone(), 0.5) : initialBounds.getBoundingSphere(new THREE.Sphere());

    if (gltf.animations?.length) {
      entry.mixer = new THREE.AnimationMixer(contentRoot);
      entry.clips.forEach((clip, index) => {
        const baseName = clip.name?.trim() || `Animation ${index + 1}`;
        let name = baseName;
        let suffix = 2;
        while (entry.actions.has(name)) name = `${baseName} (${suffix++})`;
        entry.actions.set(name, entry.mixer.clipAction(clip));
      });
      // Only auto-play an explicitly recognizable idle/rest clip. GLB clip
      // order is not semantic; clip zero could be an attack or an opening.
      const idleEntry = [...entry.actions.entries()].find(([name]) => /(^|[^a-z])(idle|rest|stand|breath|wait)([^a-z]|$)/i.test(name));
      if (idleEntry) idleEntry[1].play();
    }

    this.engine.modelsGroup.add(root);
    this.entries.push(entry);
    this.selectedId = id;
    if (persist) this.persist(entry).catch(error => this.onStatus(`ذخیرهٔ مدل انجام نشد: ${error.message}`));
    this.onChange();
    this.engine.requestRender();
    return entry;
  }

  _parseArrayBuffer(buffer) {
    return new Promise((resolve, reject) => this.loader.parse(buffer, '', resolve, reject));
  }

  async inspectLocalFile(file, { signal } = {}) {
    if (!file || !/\.glb$/i.test(file.name)) throw new Error('فعلاً فقط فایل GLB پشتیبانی می‌شود.');
    return inspectGLB(file, { signal });
  }

  async addLocalFile(file, { signal } = {}) {
    if (!file || !/\.glb$/i.test(file.name)) throw new Error('فعلاً فقط فایل GLB پشتیبانی می‌شود.');
    if (file.size > this.maxFileBytes) throw new Error(`فایل از سقف ایمنی ${formatBytes(this.maxFileBytes)} بیشتر است.`);
    if (this.importing) throw new Error('یک عملیات ورود مدل در حال اجراست.');
    this.importing = true;
    let buffer = null;
    let savedAssetId = null;
    let evictedCount = 0;
    try {
      this.onStatus(`در حال تحلیل ساختار ${file.name}…`);
      const assetInfo = await this.inspectLocalFile(file, { signal });
      if (signal?.aborted) throw new DOMException('عملیات لغو شد.', 'AbortError');
      const budget = estimateRuntimeBudget();
      const pressureRatio = assetInfo.estimatedPeakBytes / budget;
      const summary = [
        `فایل: ${file.name}`,
        `حجم: ${formatBytes(file.size)}`,
        `Mesh: ${assetInfo.meshCount} · Primitive: ${assetInfo.primitiveCount}`,
        `Texture: ${assetInfo.textureCount} · Animation: ${assetInfo.animationCount}`,
        `هندسه تخمینی: ${formatBytes(assetInfo.estimatedGeometryBytes)}`,
        `بافت Decode‌شده تخمینی: ${formatBytes(assetInfo.estimatedDecodedTextureBytes)}`,
        `اوج حافظه تخمینی: ${formatBytes(assetInfo.estimatedPeakBytes)}`,
        `بودجه محافظه‌کارانه این WebView: ${formatBytes(budget)}`
      ].join('\n');
      if (pressureRatio > 0.8) {
        const accepted = await this.onConfirmHeavyFile({ file, assetInfo, budget, summary });
        if (!accepted) throw new DOMException('بارگذاری به درخواست کاربر لغو شد.', 'AbortError');
        this.onStatus('فایل سنگین است؛ مدل‌های قبلی به حالت Dormant منتقل و منابع رندرشان آزاد می‌شوند…');
        evictedCount = await this.evictLoadedModels();
      }
      if (signal?.aborted) throw new DOMException('عملیات لغو شد.', 'AbortError');
      this.onStatus(`در حال خواندن ${file.name} (${formatBytes(file.size)})…`);
      buffer = await file.arrayBuffer();
      if (signal?.aborted) throw new DOMException('عملیات لغو شد.', 'AbortError');
      this.onStatus(`در حال تجزیه GLB؛ تعداد Mesh: ${assetInfo.meshCount}…`);
      const gltf = await this._parseArrayBuffer(buffer);
      buffer = null; // Drop the caller's reference as soon as parsing completes.
      if (signal?.aborted) { disposeObject(gltf.scene || gltf.scenes?.[0]); throw new DOMException('عملیات لغو شد.', 'AbortError'); }
      const id = crypto.randomUUID?.() || `model_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      let hasPersistentAsset = false;
      if (this.storage.persistent) {
        try {
          const estimate = await navigator.storage?.estimate?.();
          const free = Number.isFinite(estimate?.quota) && Number.isFinite(estimate?.usage) ? estimate.quota - estimate.usage : Infinity;
          if (free >= file.size * 1.05) { await this.storage.putAsset(id, file); hasPersistentAsset = true; savedAssetId = id; }
          else this.onStatus('فضای ذخیره‌سازی کافی برای نگهداری دائمی فایل نیست؛ مدل فقط در نشست فعلی باقی می‌ماند.');
        } catch (error) { this.onStatus(`ذخیرهٔ پایدار فایل ممکن نشد: ${error.message}`); }
      }
      const entry = this._register(gltf, {
        id, name: file.name, kind: 'local', blob: hasPersistentAsset ? null : file,
        hasPersistentAsset, scaleFactor: 1, assetInfo
      }, { persist: hasPersistentAsset });
      this.onStatus(`${hasPersistentAsset ? 'مدل ذخیره و اضافه شد' : 'مدل برای این نشست اضافه شد'}؛ ${evictedCount} مدل قبلی برای کاهش فشار حافظه به حالت Dormant منتقل شدند. تخمین اوج حافظه: ${formatBytes(assetInfo.estimatedPeakBytes)}.`);
      return entry;
    } catch (error) {
      if (savedAssetId) await this.storage.deleteAsset(savedAssetId).catch(() => {});
      throw error;
    } finally {
      buffer = null;
      this.importing = false;
      this.engine.requestRender();
    }
  }

  async evictLoadedModels({ preserveFloatingNotes = true } = {}) {
    let evicted = 0;
    for (const entry of this.entries) {
      if (!entry.root) continue;
      if (preserveFloatingNotes && entry.kind === 'floating-note') continue;
      const reloadable = entry.kind === 'sample' && Boolean(entry.url)
        || entry.kind === 'local' && (entry.hasPersistentAsset || Boolean(entry.blob));
      if (!reloadable) continue;
      entry.transform = {
        position: entry.root.position.toArray(),
        quaternion: entry.root.quaternion.toArray(),
        scale: entry.root.scale.toArray()
      };
      await this.persist(entry).catch(error => this.onStatus(`ذخیره موقعیت ${entry.name} پیش از آزادسازی ناموفق بود: ${error.message}`));
      this.engine.modelsGroup.remove(entry.root);
      entry.mixer?.stopAllAction();
      disposeObject(entry.root);
      entry.root = null;
      entry.mixer = null;
      entry.clips = [];
      entry.actions = new Map();
      entry.boundsSphere = null;
      entry.state = 'dormant';
      if (this.selectedId === entry.id) this.selectedId = null;
      evicted++;
    }
    if (evicted) {
      this.onChange();
      this.engine.requestRender();
    }
    return evicted;
  }

  async addSample(key) {
    const sample = SAMPLE_ASSETS[key];
    if (!sample) throw new Error('مدل نمونه ناشناخته است.');
    const existing = this.entries.find(entry => entry.id === sample.id);
    if (existing) {
      this.selectedId = existing.id;
      this.onChange();
      return existing.root ? existing : this.ensureLoaded(existing);
    }
    this.onStatus(`در حال دریافت مدل واقعی ${sample.name}…`);
    const gltf = await new Promise((resolve, reject) => {
      this.loader.load(sample.url, resolve, event => {
        if (event.total) this.onStatus(`دریافت ${sample.name}: ${Math.round(event.loaded / event.total * 100)}٪`);
      }, reject);
    });
    const entry = this._register(gltf, {
      id: sample.id,
      name: sample.name,
      kind: 'sample',
      url: sample.url,
      license: sample.license,
      scaleFactor: 1
    }, { persist: true });
    this.onStatus(`مدل ${sample.name} بارگذاری شد.`);
    return entry;
  }

  async restoreSaved() {
    if (!this.storage.persistent) return;
    const records = await this.storage.getAllModels();
    for (const record of records) {
      if (this.entries.some(entry => entry.id === record.id)) continue;
      this.entries.push({
        id: record.id, name: record.name || 'مدل سه‌بعدی', kind: record.kind || 'local',
        url: record.url || null, blob: null, hasPersistentAsset: record.hasPersistentAsset ?? true,
        license: record.license || null, root: null, scaleFactor: record.scaleFactor || 1,
        baseScale: new THREE.Vector3(1, 1, 1), mixer: null, clips: [], actions: new Map(),
        state: 'dormant', assetInfo: record.assetInfo || null,
        transform: { position: record.position || [0, 0, 0], quaternion: record.quaternion || [0, 0, 0, 1], scale: record.scale || [1, 1, 1] },
        storageRecord: record, userVisible: true, boundsSphere: null, _loadPromise: null
      });
    }
    this.selectedId = null;
    this.onChange();
    this.onStatus(`${records.length} مدل ذخیره‌شده شناسایی شد؛ منابع سنگین فقط هنگام انتخاب بارگذاری می‌شوند.`);
  }

  async ensureLoaded(entryOrId) {
    const entry = typeof entryOrId === 'string' ? this.entries.find(item => item.id === entryOrId) : entryOrId;
    if (!entry) throw new Error('مدل موردنظر پیدا نشد.');
    if (entry.root) return entry;
    if (entry._loadPromise) return entry._loadPromise;
    const stored = entry.storageRecord || entry;
    const transform = entry.transform || {};
    const record = {
      ...stored,
      position: transform.position || stored.position,
      quaternion: transform.quaternion || stored.quaternion,
      scale: transform.scale || stored.scale
    };
    entry.state = 'loading';
    this.onChange();
    const originalIndex = this.entries.indexOf(entry);
    entry._loadPromise = (async () => {
      try {
        this.onStatus(`بارگذاری تنبل ${entry.name}…`);
        let gltf;
        let blob = null;
        if (entry.kind === 'local') {
          blob = entry.blob || await this.storage.getAsset(entry.id);
          if (!blob) throw new Error('فایل اصلی در حافظه پایدار پیدا نشد.');
          let buffer = await blob.arrayBuffer();
          try { gltf = await this._parseArrayBuffer(buffer); } finally { buffer = null; }
        } else if (entry.url) {
          gltf = await new Promise((resolve, reject) => this.loader.load(entry.url, resolve, undefined, reject));
        } else throw new Error('منبع اصلی این مدل در دسترس نیست.');
        const index = this.entries.indexOf(entry);
        if (index >= 0) this.entries.splice(index, 1);
        const loaded = this._register(gltf, { ...record, blob: entry.hasPersistentAsset ? null : blob, hasPersistentAsset: entry.hasPersistentAsset, assetInfo: entry.assetInfo }, { normalize: false, persist: false });
        const loadedIndex = this.entries.indexOf(loaded);
        if (index >= 0 && loadedIndex >= 0 && index !== loadedIndex) {
          this.entries.splice(loadedIndex, 1);
          this.entries.splice(index, 0, loaded);
        }
        loaded.state = 'active';
        loaded.storageRecord = record;
        this.onStatus(`مدل ${entry.name} بارگذاری شد.`);
        return loaded;
      } catch (error) {
        entry.state = 'error';
        if (!this.entries.includes(entry)) this.entries.splice(Math.max(0, Math.min(originalIndex, this.entries.length)), 0, entry);
        this.onStatus(`بارگذاری ${entry.name} ناموفق بود: ${error.message}`);
        throw error;
      } finally {
        entry._loadPromise = null;
        this.onChange();
      }
    })();
    return entry._loadPromise;
  }

  registerExternal(entry, persist = true) {
    if (!entry?.id || !entry.root) throw new TypeError('External spatial entry requires id and root');
    if (this.entries.some(item => item.id === entry.id)) return this.entries.find(item => item.id === entry.id);
    entry.state = 'active';
    entry.transform = { position: entry.root.position.toArray(), quaternion: entry.root.quaternion.toArray(), scale: entry.root.scale.toArray() };
    this.updateBounds(entry);
    entry.root.userData.entryId = entry.id;
    entry.root.traverse(child => { child.userData.entryId = entry.id; });
    this.engine.modelsGroup.add(entry.root);
    this.entries.push(entry);
    this.selectedId = entry.id;
    if (persist) this.persist(entry).catch(error => this.onStatus(`ذخیرهٔ ${entry.name} ناموفق بود: ${error.message}`));
    this.onChange();
    this.engine.requestRender();
    return entry;
  }

  async persist(entry) {
    if (!this.storage.persistent || entry.kind === 'local' && !entry.hasPersistentAsset) return;
    const root = entry.root;
    const transform = root ? { position: root.position.toArray(), quaternion: root.quaternion.toArray(), scale: root.scale.toArray() } : (entry.transform || {});
    const record = {
      id: entry.id,
      name: entry.name,
      kind: entry.kind,
      hasPersistentAsset: entry.kind === 'local' ? entry.hasPersistentAsset : true,
      url: entry.url,
      license: entry.license,
      position: transform.position || [0, 0, 0],
      quaternion: transform.quaternion || [0, 0, 0, 1],
      scale: transform.scale || [1, 1, 1],
      assetInfo: entry.assetInfo || null,
      scaleFactor: entry.scaleFactor,
      noteId: entry.noteId || null
    };
    if (entry.kind === 'floating-note') await this.storage.putFloatingNote(record);
    else await this.storage.putModel(record);
  }

  async persistAll() {
    for (const timer of this.persistTimers.values()) clearTimeout(timer);
    this.persistTimers.clear();
    await Promise.all(this.entries.map(entry => this.persist(entry).catch(error => this.onStatus(`ذخیرهٔ ${entry.name} ناموفق بود.`))));
  }

  schedulePersist(entry) {
    if (this.persistTimers.has(entry.id)) clearTimeout(this.persistTimers.get(entry.id));
    const timer = setTimeout(() => {
      this.persistTimers.delete(entry.id);
      this.persist(entry).catch(error => this.onStatus(`ذخیرهٔ ${entry.name} ناموفق بود: ${error.message}`));
    }, 280);
    this.persistTimers.set(entry.id, timer);
  }

  setScaleFactor(entry, factor) {
    if (!entry?.root) return false;
    entry.scaleFactor = THREE.MathUtils.clamp(Number(factor) || 1, 0.05, 8);
    // Scale relative to the model's imported base scale. The first scale is retained.
    if (!entry.baseScale) entry.baseScale = entry.root.scale.clone();
    entry.root.scale.copy(entry.baseScale).multiplyScalar(entry.scaleFactor);
    this.updateBounds(entry);
    entry.transform = { position: entry.root.position.toArray(), quaternion: entry.root.quaternion.toArray(), scale: entry.root.scale.toArray() };
    this.engine.requestRender();
    this.schedulePersist(entry);
    return true;
  }

  setRotationDegrees(entry, xDegrees, yDegrees, zDegrees) {
    if (!entry?.root) return false;
    // User-facing Euler controls are converted immediately to the object's
    // quaternion; persistence stores the quaternion, not an ambiguous matrix.
    entry.root.rotation.order = 'XYZ';
    entry.root.rotation.set(
      THREE.MathUtils.degToRad(xDegrees),
      THREE.MathUtils.degToRad(yDegrees),
      THREE.MathUtils.degToRad(zDegrees),
      'XYZ'
    );
    entry.root.updateMatrixWorld(true);
    this.updateBounds(entry);
    entry.transform = { position: entry.root.position.toArray(), quaternion: entry.root.quaternion.toArray(), scale: entry.root.scale.toArray() };
    this.engine.requestRender();
    this.schedulePersist(entry);
    return true;
  }

  playAnimation(entry, clipName, { loop = 'repeat', timeScale = 1, fade = 0.2 } = {}) {
    if (!entry?.mixer || !entry.actions?.size) return false;
    const action = entry.actions.get(clipName);
    if (!action) return false;
    for (const candidate of entry.actions.values()) {
      if (candidate === action) continue;
      candidate.fadeOut(Math.max(0, fade));
    }
    action.reset();
    action.enabled = true;
    action.timeScale = THREE.MathUtils.clamp(Number(timeScale) || 1, 0.05, 4);
    action.setLoop(loop === 'once' ? THREE.LoopOnce : THREE.LoopRepeat, loop === 'once' ? 1 : Infinity);
    if (loop === 'once') action.clampWhenFinished = true;
    action.fadeIn(Math.max(0, fade)).play();
    this.engine.requestRender();
    return true;
  }

  select(id) {
    this.selectedId = id;
    this.onChange();
    this.engine.requestRender();
    const entry = this.entries.find(item => item.id === id);
    if (entry && !entry.root) return this.ensureLoaded(entry).catch(error => { this.onStatus(error.message); return null; });
    return Promise.resolve(entry || null);
  }

  selectByHit(id) {
    if (this.entries.some(entry => entry.id === id)) this.select(id);
    return this.selected;
  }


  async remove(id) {
    const index = this.entries.findIndex(entry => entry.id === id);
    if (index < 0) return;
    const [entry] = this.entries.splice(index, 1);
    if (this.persistTimers.has(id)) { clearTimeout(this.persistTimers.get(id)); this.persistTimers.delete(id); }
    if (entry.root) {
      this.engine.modelsGroup.remove(entry.root);
      if (entry.mixer) entry.mixer.stopAllAction();
      disposeObject(entry.root);
    }
    if (this.storage.persistent) {
      if (entry.kind === 'floating-note') await this.storage.deleteFloatingNote(id).catch(console.warn);
      else await this.storage.deleteModel(id).catch(console.warn);
      if (entry.kind === 'local' && entry.hasPersistentAsset) await this.storage.deleteAsset(id).catch(console.warn);
    }
    if (this.selectedId === id) this.selectedId = this.entries.at(-1)?.id || null;
    this.onChange();
    this.engine.requestRender();
  }


  updateBounds(entry) {
    if (!entry?.root) return;
    entry.root.updateMatrixWorld(true);
    const bounds = new THREE.Box3().setFromObject(entry.root);
    entry.boundsSphere = bounds.isEmpty() ? new THREE.Sphere(entry.root.position.clone(), 0.5) : bounds.getBoundingSphere(new THREE.Sphere());
    entry.transform = { position: entry.root.position.toArray(), quaternion: entry.root.quaternion.toArray(), scale: entry.root.scale.toArray() };
  }

  setDistanceCulling(enabled, radius = this.distanceCullRadius) {
    this.distanceCullingEnabled = Boolean(enabled);
    this.distanceCullRadius = THREE.MathUtils.clamp(Number(radius) || 1, 1, 100000);
    this.engine.requestRender();
  }

  updateCulling(camera) {
    if (!camera) return;
    for (const entry of this.entries) {
      if (!entry.root) continue;
      if (!this.distanceCullingEnabled) {
        if (entry.root.visible !== entry.userVisible) entry.root.visible = entry.userVisible !== false;
        continue;
      }
      const sphere = entry.boundsSphere;
      if (!sphere) continue;
      const distance = Math.max(0, camera.position.distanceTo(sphere.center) - sphere.radius);
      const shouldShow = entry.userVisible !== false && distance <= this.distanceCullRadius;
      if (entry.root.visible !== shouldShow) entry.root.visible = shouldShow;
    }
  }

  updateAnimations(deltaSeconds) {
    for (const entry of this.entries) entry.mixer?.update(deltaSeconds);
  }

  hasAnimations() {
    return this.entries.some(entry => entry.mixer && [...(entry.actions?.values() || [])].some(action => action.isRunning()));
  }

  async dispose() {
    for (const entry of [...this.entries]) await this.remove(entry.id);
  }
}

export { SAMPLE_ASSETS };
