import * as THREE from 'three';

const AXES = {
  x: new THREE.Vector3(1, 0, 0),
  y: new THREE.Vector3(0, 1, 0),
  z: new THREE.Vector3(0, 0, 1)
};

/** Six-direction, local-space translation gizmo. No arrowheads or icon geometry. */
export class TransformGizmo {
  constructor(engine) {
    this.engine = engine;
    this.group = new THREE.Group();
    this.group.name = 'ObjectTranslationGizmo';
    this.group.visible = false;
    this.handles = [];
    this.visualHandles = [];
    this.activeHandle = null;
    this._worldQuaternion = new THREE.Quaternion();
    this._worldPosition = new THREE.Vector3();
    this._box = new THREE.Box3();
    this._size = new THREE.Vector3();
    this._center = new THREE.Vector3();
    this._rayOffset = new THREE.Vector3();
    this._axis = new THREE.Vector3();
    this._ray = new THREE.Ray();
    this._build();
    engine.scene.add(this.group);
  }

  _build() {
    const visualMaterial = new THREE.MeshBasicMaterial({
      color: 0x9aa5ad,
      transparent: true,
      opacity: 0.66,
      depthTest: false,
      depthWrite: false
    });
    const hitMaterial = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0,
      colorWrite: false,
      depthWrite: false,
      depthTest: false
    });
    const yAxis = new THREE.Vector3(0, 1, 0);

    for (const axis of ['x', 'y', 'z']) {
      for (const sign of [1, -1]) {
        const direction = AXES[axis].clone().multiplyScalar(sign);
        const orientation = new THREE.Quaternion().setFromUnitVectors(yAxis, direction);
        const visual = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, 1, 8, 1, true), visualMaterial.clone());
        visual.position.copy(direction).multiplyScalar(0.5);
        visual.quaternion.copy(orientation);
        visual.renderOrder = 1001;
        visual.userData.axis = axis;
        visual.userData.sign = sign;
        this.visualHandles.push(visual);

        // A larger invisible cylinder gives fingers a forgiving hit target while
        // keeping the visible axis hairline-thin.
        const hit = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.075, 1, 8, 1, true), hitMaterial.clone());
        hit.position.copy(visual.position);
        hit.quaternion.copy(orientation);
        hit.renderOrder = 1002;
        hit.userData.axis = axis;
        hit.userData.sign = sign;
        hit.userData.isTransformHandle = true;
        this.group.add(visual, hit);
        this.handles.push(hit);
      }
    }
  }

  update(root) {
    if (!root) {
      this.group.visible = false;
      return;
    }
    root.updateMatrixWorld(true);
    this._box.setFromObject(root);
    if (this._box.isEmpty()) {
      this.group.visible = false;
      return;
    }
    this._box.getCenter(this._center);
    this._box.getSize(this._size);
    root.getWorldQuaternion(this._worldQuaternion);
    this.group.position.copy(this._center);
    this.group.quaternion.copy(this._worldQuaternion);

    const largestDimension = Math.max(this._size.x, this._size.y, this._size.z, 0.01);
    const distance = this.engine.camera.position.distanceTo(this._center);
    const fovHeight = 2 * Math.tan(THREE.MathUtils.degToRad(this.engine.camera.fov * 0.5)) * distance;
    const screenStableLength = fovHeight * 0.095;
    const objectAwareLength = largestDimension * 0.62;
    const length = THREE.MathUtils.clamp(Math.max(screenStableLength, objectAwareLength, 0.32), 0.32, 8);
    this.group.scale.setScalar(length);
    this.group.visible = true;
  }

  hit(event) {
    if (!this.group.visible) return null;
    this.engine.setPointerFromEvent(event);
    const hits = this.engine.raycaster.intersectObjects(this.handles, false);
    if (!hits.length) return null;
    const data = hits[0].object.userData;
    return { axis: data.axis, sign: data.sign };
  }

  setActive(axis = null, sign = null) {
    this.activeHandle = axis ? { axis, sign } : null;
    for (const visual of this.visualHandles) {
      const active = this.activeHandle && visual.userData.axis === axis && visual.userData.sign === sign;
      visual.material.color.setHex(active ? 0xffffff : 0x9aa5ad);
      visual.material.opacity = active ? 1 : 0.58;
    }
    this.engine.requestRender();
  }

  worldAxis(root, axis, sign = 1) {
    const direction = AXES[axis].clone().multiplyScalar(sign);
    root.getWorldQuaternion(this._worldQuaternion);
    return direction.applyQuaternion(this._worldQuaternion).normalize();
  }

  axisParameter(event, origin, direction) {
    this.engine.setPointerFromEvent(event);
    const ray = this.engine.raycaster.ray;
    const axis = this._axis.copy(direction).normalize();
    this._rayOffset.copy(origin).sub(ray.origin);
    const b = axis.dot(ray.direction);
    const d = axis.dot(this._rayOffset);
    const e = ray.direction.dot(this._rayOffset);
    const denominator = 1 - b * b;
    if (Math.abs(denominator) < 1e-5) return null;
    const t = (b * e - d) / denominator;
    const s = (e - b * d) / denominator;
    if (!Number.isFinite(t) || s < -0.05) return null;
    return t;
  }

  dispose() {
    this.group.traverse(object => {
      if (object.geometry) object.geometry.dispose();
      if (object.material) {
        const materials = Array.isArray(object.material) ? object.material : [object.material];
        materials.forEach(material => material.dispose());
      }
    });
    this.engine.scene.remove(this.group);
  }
}
