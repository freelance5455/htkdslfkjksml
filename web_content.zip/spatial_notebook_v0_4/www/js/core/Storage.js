const DB_NAME = 'spatial-notebook-v02';
const DB_VERSION = 2;

export class Storage {
  constructor() {
    this.db = null;
    this.persistent = false;
  }

  async init() {
    if (!('indexedDB' in window)) return false;
    try {
      this.db = await new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains('models')) db.createObjectStore('models', { keyPath: 'id' });
          if (!db.objectStoreNames.contains('assets')) db.createObjectStore('assets', { keyPath: 'id' });
          if (!db.objectStoreNames.contains('floatingNotes')) db.createObjectStore('floatingNotes', { keyPath: 'id' });
          if (!db.objectStoreNames.contains('themes')) db.createObjectStore('themes', { keyPath: 'id' });
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error || new Error('IndexedDB open failed'));
        request.onblocked = () => reject(new Error('IndexedDB is blocked'));
      });
      this.persistent = true;
      try { await navigator.storage?.persist?.(); } catch (_) {}
    } catch (error) {
      console.warn('Spatial storage unavailable; session-only mode:', error);
      this.db = null;
      this.persistent = false;
    }
    return this.persistent;
  }

  _request(storeName, mode, action) {
    if (!this.db) return Promise.reject(new Error('Persistent storage is unavailable'));
    return new Promise((resolve, reject) => {
      const tx = this.db.transaction(storeName, mode);
      const store = tx.objectStore(storeName);
      let request;
      let result;
      try { request = action(store); } catch (error) { reject(error); return; }
      request.onsuccess = () => { result = request.result; };
      request.onerror = () => reject(request.error || tx.error || new Error('IndexedDB request failed'));
      tx.oncomplete = () => resolve(result);
      tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction failed'));
      tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted'));
    });
  }

  putModel(record) { return this._request('models', 'readwrite', store => store.put(record)); }
  getAllModels() { return this._request('models', 'readonly', store => store.getAll()); }
  deleteModel(id) { return this._request('models', 'readwrite', store => store.delete(id)); }
  putAsset(id, blob) { return this._request('assets', 'readwrite', store => store.put({ id, blob })); }
  async getAsset(id) { const record = await this._request('assets', 'readonly', store => store.get(id)); return record?.blob || null; }
  deleteAsset(id) { return this._request('assets', 'readwrite', store => store.delete(id)); }

  putFloatingNote(record) { return this._request('floatingNotes', 'readwrite', store => store.put(record)); }
  getAllFloatingNotes() { return this._request('floatingNotes', 'readonly', store => store.getAll()); }
  deleteFloatingNote(id) { return this._request('floatingNotes', 'readwrite', store => store.delete(id)); }

  putTheme(record) { return this._request('themes', 'readwrite', store => store.put(record)); }
  getAllThemes() { return this._request('themes', 'readonly', store => store.getAll()); }
  deleteTheme(id) { return this._request('themes', 'readwrite', store => store.delete(id)); }
}
