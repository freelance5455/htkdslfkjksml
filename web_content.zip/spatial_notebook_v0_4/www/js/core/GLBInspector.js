const GLB_MAGIC = 0x46546c67;
const JSON_CHUNK = 0x4e4f534a;
const BIN_CHUNK = 0x004e4942;
const COMPONENT_BYTES = { 5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4 };
const TYPE_COMPONENTS = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 };
const MiB = 1024 * 1024;

function throwIfAborted(signal) {
  if (signal?.aborted) throw new DOMException('عملیات لغو شد.', 'AbortError');
}

function readU32(view, offset) { return view.getUint32(offset, true); }

function imageDimensions(bytes, mimeType = '') {
  if (bytes.length >= 24 && bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    return { width: readU32(view, 16), height: readU32(view, 20), format: 'PNG' };
  }
  if (bytes.length >= 30 && bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) {
    const kind = String.fromCharCode(...bytes.subarray(12, 16));
    if (kind === 'VP8X' && bytes.length >= 30) {
      const width = 1 + bytes[24] + (bytes[25] << 8) + (bytes[26] << 16);
      const height = 1 + bytes[27] + (bytes[28] << 8) + (bytes[29] << 16);
      return { width, height, format: 'WebP' };
    }
  }
  if (bytes.length >= 4 && bytes[0] === 0xff && bytes[1] === 0xd8) {
    let offset = 2;
    while (offset + 9 < bytes.length) {
      if (bytes[offset] !== 0xff) { offset++; continue; }
      const marker = bytes[offset + 1];
      const length = (bytes[offset + 2] << 8) | bytes[offset + 3];
      if (length < 2) break;
      if ([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf].includes(marker)) {
        return { height: (bytes[offset + 5] << 8) | bytes[offset + 6], width: (bytes[offset + 7] << 8) | bytes[offset + 8], format: 'JPEG' };
      }
      offset += 2 + length;
    }
  }
  if (mimeType.includes('ktx2') && bytes.length >= 28) {
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    return { width: readU32(view, 20), height: readU32(view, 24), format: 'KTX2' };
  }
  return null;
}

async function readImageInfo(blob, image, bufferViews, binOffset, signal) {
  throwIfAborted(signal);
  if (typeof image.bufferView !== 'number' || !binOffset || !bufferViews[image.bufferView]) return null;
  const view = bufferViews[image.bufferView];
  const start = binOffset + (view.byteOffset || 0);
  const end = Math.min(blob.size, start + Math.min(view.byteLength || 0, 512 * 1024));
  if (end <= start) return null;
  const bytes = new Uint8Array(await blob.slice(start, end).arrayBuffer());
  return imageDimensions(bytes, image.mimeType || '');
}

/**
 * Read only the GLB header, JSON chunk and small image-header ranges.
 * This preflight does NOT decode the model or guarantee the eventual runtime memory.
 */
export async function inspectGLB(blob, { signal } = {}) {
  if (!blob || typeof blob.slice !== 'function' || !Number.isFinite(blob.size)) throw new TypeError('ورودی باید یک فایل یا Blob معتبر باشد.');
  if (blob.size < 20) throw new Error('فایل برای یک GLB معتبر بیش از حد کوچک است.');
  throwIfAborted(signal);
  const headerBytes = new Uint8Array(await blob.slice(0, 20).arrayBuffer());
  const header = new DataView(headerBytes.buffer, headerBytes.byteOffset, headerBytes.byteLength);
  if (readU32(header, 0) !== GLB_MAGIC) throw new Error('امضای فایل GLB معتبر نیست.');
  const version = readU32(header, 4);
  const declaredLength = readU32(header, 8);
  const jsonLength = readU32(header, 12);
  const jsonType = readU32(header, 16);
  if (version !== 2) throw new Error(`نسخه GLB پشتیبانی‌شده ۲ است؛ نسخه فایل ${version} است.`);
  if (declaredLength > blob.size || declaredLength < 20 || jsonType !== JSON_CHUNK || jsonLength < 2 || 20 + jsonLength > declaredLength) {
    throw new Error('ساختار Header یا JSON Chunk فایل GLB ناسازگار است.');
  }
  throwIfAborted(signal);
  const jsonText = await blob.slice(20, 20 + jsonLength).text();
  let json;
  try { json = JSON.parse(jsonText.replace(/[\u0000\u0020]+$/g, '')); }
  catch { throw new Error('JSON داخلی فایل GLB قابل خواندن نیست.'); }
  if (json.asset?.version && !String(json.asset.version).startsWith('2')) throw new Error('این فایل با نسخه glTF 2.x سازگار نیست.');

  const binHeaderOffset = 20 + jsonLength;
  let binOffset = 0;
  if (binHeaderOffset + 8 <= declaredLength) {
    const binHeaderBytes = new Uint8Array(await blob.slice(binHeaderOffset, binHeaderOffset + 8).arrayBuffer());
    const binHeader = new DataView(binHeaderBytes.buffer, binHeaderBytes.byteOffset, binHeaderBytes.byteLength);
    if (readU32(binHeader, 4) === BIN_CHUNK) binOffset = binHeaderOffset + 8;
  }

  const accessors = json.accessors || [];
  let estimatedGeometryBytes = 0;
  for (const accessor of accessors) {
    const componentBytes = COMPONENT_BYTES[accessor.componentType] || 0;
    const components = TYPE_COMPONENTS[accessor.type] || 0;
    if (componentBytes && components && Number.isFinite(accessor.count)) {
      estimatedGeometryBytes += accessor.count * componentBytes * components;
      if (accessor.sparse?.count) estimatedGeometryBytes += accessor.sparse.count * componentBytes * components;
    }
  }
  const meshes = json.meshes || [];
  let primitiveCount = 0;
  let morphTargetCount = 0;
  for (const mesh of meshes) for (const primitive of mesh.primitives || []) {
    primitiveCount++;
    morphTargetCount += primitive.targets?.length || 0;
  }

  const bufferViews = json.bufferViews || [];
  const images = json.images || [];
  const imageInfos = [];
  let decodedTextureBytes = 0;
  for (const image of images) {
    const info = await readImageInfo(blob, image, bufferViews, binOffset, signal);
    if (info && info.width > 0 && info.height > 0) {
      const rgba = info.width * info.height * 4;
      const withMipmaps = Math.ceil(rgba * 4 / 3);
      decodedTextureBytes += withMipmaps;
      imageInfos.push({ ...info, estimatedDecodedBytes: withMipmaps });
    } else imageInfos.push({ format: image.mimeType || 'نامشخص', width: null, height: null, estimatedDecodedBytes: null });
  }
  const bufferViewBytes = bufferViews.reduce((sum, item) => sum + (Number(item.byteLength) || 0), 0);
  const animationCount = json.animations?.length || 0;
  const nodeCount = json.nodes?.length || 0;
  const materialCount = json.materials?.length || 0;
  const accessorBytes = Math.max(estimatedGeometryBytes, bufferViewBytes * 0.45);
  const workingOverhead = Math.max(blob.size * 0.25, 24 * MiB);
  // Conservative estimate: source ArrayBuffer + decoded CPU textures + GPU copies + parse overhead.
  const estimatedPeakBytes = Math.ceil(blob.size + accessorBytes * 1.25 + decodedTextureBytes * 2 + workingOverhead);

  return {
    valid: true,
    fileName: blob.name || 'model.glb',
    fileBytes: blob.size,
    declaredBytes: declaredLength,
    version,
    jsonBytes: jsonLength,
    binaryBytes: Math.max(0, declaredLength - (binOffset || declaredLength)),
    meshCount: meshes.length,
    primitiveCount,
    nodeCount,
    materialCount,
    textureCount: (json.textures || []).length,
    imageCount: images.length,
    animationCount,
    accessorCount: accessors.length,
    bufferViewCount: bufferViews.length,
    estimatedGeometryBytes: Math.ceil(accessorBytes),
    estimatedDecodedTextureBytes: Math.ceil(decodedTextureBytes),
    estimatedPeakBytes,
    images: imageInfos,
    warnings: [
      !binOffset ? 'BIN Chunk استاندارد شناسایی نشد؛ فایل ممکن است از منابع خارجی یا ساختار غیرمعمول استفاده کند.' : null,
      imageInfos.some(item => item.width == null) ? 'ابعاد بعضی تصاویر از Header قابل استخراج نبود؛ تخمین حافظه بافت ناقص است.' : null,
      estimatedGeometryBytes === 0 && meshes.length ? 'اطلاعات Accessor برای تخمین دقیق هندسه کافی نیست.' : null
    ].filter(Boolean)
  };
}

export function formatBytes(bytes) {
  if (!Number.isFinite(bytes) || bytes < 0) return 'نامشخص';
  if (bytes < MiB) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / MiB).toFixed(bytes >= 10 * MiB ? 0 : 1)} MB`;
}

export function estimateRuntimeBudget({ deviceMemory = globalThis.navigator?.deviceMemory, jsHeapLimit = globalThis.performance?.memory?.jsHeapSizeLimit } = {}) {
  let estimate = 256 * MiB;
  if (Number.isFinite(deviceMemory) && deviceMemory > 0) estimate = deviceMemory * 1024 * MiB * 0.08;
  if (Number.isFinite(jsHeapLimit) && jsHeapLimit > 0) estimate = Math.min(estimate, jsHeapLimit * 0.35);
  return Math.floor(Math.min(512 * MiB, Math.max(96 * MiB, estimate)));
}
