# تغییرات نسخه ۰.۴ نسبت به ۰.۳

- افزودن ماژول GLBInspector برای بررسی Header/JSON و برآورد ساختار و حافظه پیش از Parse.
- افزودن دکمه «تحلیل فایل GLB» به مدیریت مدل‌ها.
- افزایش سقف نرم‌افزاری فایل ورودی از ۲۵۰ مگابایت به ۱ گیگابایت؛ پذیرش فایل به معنی تضمین Parse روی هر دستگاه نیست.
- هشدار برای فایل‌هایی که برآورد حافظه آن‌ها از بودجه محافظه‌کارانه WebView بالاتر می‌رود.
- انتقال مدل‌های قبلی قابل‌بازیابی به Dormant و آزادسازی Root/Mixer/Geometry/Material/Texture در Import سنگین؛ یادداشت شناور حفظ می‌شود.
- Lazy Restore: در شروع فقط Metadata مدل‌های ذخیره‌شده بازیابی می‌شود و GLB هنگام انتخاب Parse می‌شود.
- افزودن Distance Culling واقعی در سطح کل مدل و تنظیم شعاع نمایش مستقل.
- صریح‌سازی Frustum Culling برای Meshهای واردشده و ساخت Bounding Sphere.
- به‌روزرسانی Bounds پس از حرکت، چرخش و تغییر مقیاس.
- ثبت اطلاعات Asset Inspector در Metadata ذخیره‌شده.
- افزایش نسخه برنامه و API به ۰.۴.۰.

## هنوز انجام نشده

Parse کامل GLB به ArrayBuffer نیاز دارد و در Main Thread انجام می‌شود. تقسیم خودکار یک GLB واحد به Spatial Chunk، GLB Package Importer، LOD generation، Occlusion Culling، Asset Optimizer و آزمون Android WebView هنوز پیاده‌سازی نشده‌اند.
