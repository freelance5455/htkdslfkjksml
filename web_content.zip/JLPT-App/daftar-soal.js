/* Daftar soal. Dibuat/diperbarui otomatis oleh UPDATE-DAFTAR.bat.
   Anda boleh mengubah judul (title) secara manual; judul lama akan dipertahankan. */
window.DAFTAR_SOAL = [
  {file:"soal/jlptn4_2010_2011_bytio_index.html", title:"2010–2011", level:"N4"},
  {file:"soal/jlptn4_2012_bytio_index.html", title:"2012", level:"N4"},
  {file:"soal/jlptn4_2013_juli_bytio_index.html", title:"Juli 2013", level:"N4"},
  {file:"soal/jlptn4_2013desember_bytio_index.html", title:"Desember 2013", level:"N4"},
  {file:"soal/jlptn4_2014_juli_bytio_index.html", title:"Juli 2014", level:"N4"},
  {file:"soal/jlptn4_2016_desember_bytio_index.html", title:"Desember 2016", level:"N4"},
  {file:"soal/jlptn4_2017_juli_bytio_index.html", title:"Juli 2017", level:"N4"},
  {file:"soal/jlptn4_2018_bytio_index.html", title:"2018", level:"N4"},
  {file:"soal/jlptn4_2021_juli_bytio_index.html", title:"Juli 2021", level:"N4"},
  {file:"soal/jlpt_n4_2021_revisi.html", title:"Juli 2021 (revisi)", level:"N4"},
  {file:"soal/jlptn4_2023_juli_bytio_index.html", title:"Juli 2023", level:"N4"},
  {file:"soal/jlptn4_2024_juli_bytio_index.html", title:"Juli 2024", level:"N4"},
  {file:"soal/jlptn4_2024dsmbr_bytio_index.html", title:"Desember 2024", level:"N4"},
  {file:"soal/jlptn4_2025_juli_bytio_index.html", title:"Juli 2025", level:"N4"},
];
