# Memindai folder "soal" dan memperbarui daftar-soal.js
$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $dir
$out = Join-Path $dir 'daftar-soal.js'
$soalDir = Join-Path $dir 'soal'

if (-not (Test-Path $soalDir)) { New-Item -ItemType Directory -Path $soalDir | Out-Null }

# Baca daftar lama supaya judul yang sudah Anda ubah tetap dipakai
$old = @{}
$order = New-Object System.Collections.Generic.List[string]
if (Test-Path $out) {
  foreach ($line in (Get-Content $out -Encoding UTF8)) {
    if ($line -match 'file:"([^"]+)",\s*title:"([^"]*)",\s*level:"([^"]*)"') {
      $old[$matches[1]] = @{ title = $matches[2]; level = $matches[3] }
      $order.Add($matches[1])
    }
  }
}

function Guess($name) {
  $base = [IO.Path]::GetFileNameWithoutExtension($name)
  $level = 'N4'
  if ($base -match '(?i)n([1-5])(?!\d)') { $level = 'N' + $matches[1] }
  $year = ''
  if ($base -match '(20\d\d)') { $year = $matches[1] }
  $month = ''
  if ($base -match '(?i)juli|july') { $month = 'Juli' }
  elseif ($base -match '(?i)des|dec|dsm') { $month = 'Desember' }
  $title = ("$month $year").Trim()
  if (-not $title) { $title = $base }
  return @{ title = $title; level = $level; year = $year }
}

$files = Get-ChildItem -Path $soalDir -File | Where-Object { $_.Extension -match '^\.(html|htm)$' }
$existing = @{}
foreach ($f in $files) { $existing['soal/' + $f.Name] = $true }

$final = New-Object System.Collections.Generic.List[object]
foreach ($k in $order) {
  if ($existing.ContainsKey($k)) { $final.Add(@{ file = $k; title = $old[$k].title; level = $old[$k].level }) }
}
$known = @{}
foreach ($k in $order) { $known[$k] = $true }
$new = @()
foreach ($f in $files) {
  $k = 'soal/' + $f.Name
  if (-not $known.ContainsKey($k)) {
    $g = Guess $f.Name
    $new += [pscustomobject]@{ file = $k; title = $g.title; level = $g.level; year = $g.year }
  }
}
foreach ($n in ($new | Sort-Object level, year, file)) {
  $final.Add(@{ file = $n.file; title = $n.title; level = $n.level })
}

$sb = New-Object System.Text.StringBuilder
[void]$sb.AppendLine('/* Daftar soal. Dibuat/diperbarui otomatis oleh UPDATE-DAFTAR.bat.')
[void]$sb.AppendLine('   Anda boleh mengubah judul (title) secara manual; judul lama akan dipertahankan. */')
[void]$sb.AppendLine('window.DAFTAR_SOAL = [')
foreach ($e in $final) {
  $t = ([string]$e.title).Replace('\','\\').Replace('"','\"')
  $f = ([string]$e.file).Replace('\','\\').Replace('"','\"')
  [void]$sb.AppendLine('  {file:"' + $f + '", title:"' + $t + '", level:"' + $e.level + '"},')
}
[void]$sb.AppendLine('];')
[IO.File]::WriteAllText($out, $sb.ToString(), (New-Object System.Text.UTF8Encoding($false)))

Write-Host ''
Write-Host ("Selesai. Total soal di daftar: " + $final.Count)
Write-Host ("File baru yang ditambahkan: " + @($new).Count)
foreach ($n in $new) { Write-Host ("  + " + $n.file + "  ->  " + $n.level + " " + $n.title) }
