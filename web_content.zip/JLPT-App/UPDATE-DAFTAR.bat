@echo off
title Perbarui daftar soal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update-daftar.ps1"
echo.
echo Muat ulang halaman aplikasi di browser (tekan F5) untuk melihat perubahan.
pause
