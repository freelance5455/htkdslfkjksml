@echo off
set "APP=%~dp0index.html"
set "C1=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
set "C2=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
set "C3=%LocalAppData%\Google\Chrome\Application\chrome.exe"
set "E1=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
set "E2=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%C1%" start "" "%C1%" "%APP%" & exit /b
if exist "%C2%" start "" "%C2%" "%APP%" & exit /b
if exist "%C3%" start "" "%C3%" "%APP%" & exit /b
echo Chrome tidak ditemukan. Membuka dengan Microsoft Edge...
if exist "%E1%" start "" "%E1%" "%APP%" & exit /b
if exist "%E2%" start "" "%E2%" "%APP%" & exit /b
echo Edge juga tidak ditemukan. Membuka dengan browser bawaan...
start "" "%APP%"
