# Prateek Jha Advocate — Android build guide

The app is the original `Prateek Jha v0.2.html`, bundled offline inside an Android app with Capacitor.

- App name: **Prateek Jha Advocate**
- Package ID: **com.prateekjha.advocatecalendar**
- App files: `public/app/index.html` (v0.2) and `public/app/android-bridge.js` (Android-only helpers)
- Data: saved on the phone in the app's private storage under the same key as v0.2 (`advocateCalendarV2`)
- Permissions: only `INTERNET`, which Capacitor adds by default. The app needs it only for the eCourts and WhatsApp buttons. Nothing else is requested.

## Changes made to the v0.2 file

1. One line added in `<head>`: `<script src="android-bridge.js"></script>`. It does nothing in a normal browser.
2. `formTask()` now starts with `tab('tasks');` and `formUnav()` now starts with `tab('unavailability');`.
   In v0.2, pressing **+ Task** or **+ Unavailability** on the Calendar opened the form inside a hidden tab, so nothing appeared on screen. **+ Case** already worked this way.

## What android-bridge.js does (inside the Android app only)

| v0.2 feature | Problem on Android | What happens in the app |
| --- | --- | --- |
| Export All Master Data / Export Ledger | Browser downloads do nothing | The JSON file is saved and the Android share sheet opens (Drive, Files, WhatsApp, Gmail…) |
| Share selected entries as image | Web Share is not available | The PNG is saved and the share sheet opens (choose WhatsApp) |
| Ledger "Export PDF" | Pop-up and print are not available | The same ledger page is saved as an `.html` file and shared. Open it in Chrome, then use ⋮ → Share → Print → Save as PDF |
| Back button | Not handled | Closes an open form or dialog. Otherwise it goes to Calendar. Otherwise it exits the app. It does nothing while the "Record professional fees" dialog is open, so fees are not skipped by accident. |

## Build the APK

Requirements on your computer: Node.js 22 or newer, Android Studio (latest), and JDK 21. Android Studio includes JDK 21.

```bash
# 1. Get the source (GitHub export from Lovable, or unzip the source ZIP), then in that folder:
npm install

# 2. Create the Android project (first time only)
npx cap add android

# 3. Copy the app files into the Android project (run again after every change to public/app)
npx cap sync android

# 4. Open in Android Studio
npx cap open android
```

In Android Studio:

1. Wait for "Gradle sync" to finish (bottom status bar).
2. Menu **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
3. When it finishes, click **locate** in the pop-up. The file is `android/app/build/outputs/apk/debug/app-debug.apk`.
4. Copy it to the phone and open it to install. Allow "Install unknown apps" for your file manager if Android asks.

For a signed release APK, use **Build → Generate Signed App Bundle / APK → APK**, create a keystore, and keep that keystore safe. You need the same keystore for every future update.

## Moving your existing records into the app

Records saved in your current browser are not copied into the app automatically.

1. Open v0.2 in the browser → **Import / Export** → **Export All Master Data**.
2. Send that `.json` file to your phone.
3. In the app → **Import / Export** → **Import All Master Data** → pick the file.

## Phone checklist (could not be tested without a real phone)

- [ ] App installs and opens with Wi-Fi and mobile data off (airplane mode)
- [ ] Add a case, close the app fully, restart the phone, reopen: the case is still there
- [ ] Export All Master Data opens the share sheet; save to Drive or Files
- [ ] Import All Master Data from that file restores everything
- [ ] Share selected entries as image opens the share sheet; sending on WhatsApp shows the image
- [ ] Open WhatsApp (text) opens WhatsApp with the message
- [ ] Ledger Export PDF shares an .html file that opens and prints from Chrome
- [ ] Back button closes forms, returns to Calendar, then exits
- [ ] Open eCourts opens the browser (needs internet)
