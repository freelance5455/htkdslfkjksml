/*
 * Android-only compatibility shims for Prateek Jha Advocate v0.2.
 *
 * In a normal browser this file does nothing. Inside the Capacitor Android app it
 * replaces browser features that Android WebView does not provide, without
 * changing the app's own code, UI or data:
 *   1. File downloads (<a download> of a blob: URL) -> save to app cache + Android share sheet
 *      (used by "Export All Master Data" and "Export Ledger (All Clients)").
 *   2. navigator.share({files}) -> same save + share sheet (payment reminder image).
 *   3. window.open('') + print() (ledger "Export PDF") -> the same ledger page is saved
 *      as an .html file and shared; open it in Chrome to print / save as PDF.
 *   4. Android back button -> close open dialog/form, else go to Calendar, else exit.
 * It talks to the native plugins through the bridge Capacitor injects into the page
 * (Capacitor.nativePromise / nativeCallback), so no bundler is needed.
 */
(function () {
  "use strict";
  var cap = window.Capacitor;
  var isNative =
    !!cap && typeof cap.isNativePlatform === "function" && cap.isNativePlatform() &&
    typeof cap.nativePromise === "function";
  if (!isNative) return;

  function call(plugin, method, options) {
    return cap.nativePromise(plugin, method, options || {});
  }

  function blobToBase64(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () {
        var s = String(r.result || "");
        resolve(s.slice(s.indexOf(",") + 1));
      };
      r.onerror = function () { reject(r.error); };
      r.readAsDataURL(blob);
    });
  }

  function safeName(name) {
    return String(name || "file").replace(/[\\/:*?"<>|]+/g, "-");
  }

  function isCancel(err) {
    var m = String((err && (err.message || err.errorMessage)) || err || "").toLowerCase();
    return m.indexOf("cancel") !== -1;
  }

  // Writes the file to the app's private cache folder and opens the Android share sheet.
  function saveAndShare(blob, filename, title) {
    var name = safeName(filename);
    return blobToBase64(blob)
      .then(function (b64) {
        return call("Filesystem", "writeFile", { path: name, data: b64, directory: "CACHE", recursive: true });
      })
      .then(function (res) {
        return call("Share", "share", { title: title || name, files: [res.uri], dialogTitle: title || name });
      })
      .catch(function (err) {
        if (isCancel(err)) return;
        alert("Could not save or share " + name + ": " + ((err && err.message) || err));
      });
  }
  window.__androidSaveAndShare = saveAndShare;

  // 1. Remember blobs behind blob: URLs so a download can still read them after revokeObjectURL.
  var blobs = new Map();
  var origCreate = URL.createObjectURL.bind(URL);
  URL.createObjectURL = function (obj) {
    var url = origCreate(obj);
    if (obj instanceof Blob) blobs.set(url, obj);
    return url;
  };
  var origAnchorClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    var href = this.getAttribute("href") || this.href || "";
    var name = this.getAttribute("download");
    if (name !== null && href.indexOf("blob:") === 0 && blobs.has(href)) {
      var blob = blobs.get(href);
      blobs.delete(href);
      saveAndShare(blob, name || "download", name || "Export");
      return;
    }
    return origAnchorClick.apply(this, arguments);
  };

  // 2. Web Share with files (payment reminder image).
  try {
    Object.defineProperty(navigator, "canShare", {
      configurable: true,
      value: function (data) { return !!(data && data.files && data.files.length); },
    });
    Object.defineProperty(navigator, "share", {
      configurable: true,
      value: function (data) {
        var files = (data && data.files) || [];
        if (!files.length) return Promise.reject(new Error("Nothing to share"));
        return files.reduce(function (p, f) {
          return p.then(function () { return saveAndShare(f, f.name, data.title); });
        }, Promise.resolve());
      },
    });
  } catch (e) { /* leave original behaviour */ }

  // 3. window.open('') used for the ledger PDF print page.
  var origOpen = window.open;
  window.open = function (url) {
    if (!url || url === "about:blank") {
      var html = "";
      var fake = {
        closed: false,
        focus: function () {},
        close: function () { fake.closed = true; },
        print: function () {
          var m = /<h2>([^<]*)<\/h2>/.exec(html);
          var party = m ? m[1].replace(/&amp;/g, "&").trim() : "client";
          var d = new Date();
          var iso = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
          saveAndShare(new Blob([html], { type: "text/html" }), "ledger-" + party + "-" + iso + ".html", "Client Ledger");
        },
        document: {
          write: function (s) { html += String(s); },
          writeln: function (s) { html += String(s) + "\n"; },
          open: function () { html = ""; },
          close: function () {},
        },
      };
      return fake;
    }
    return origOpen.apply(window, arguments);
  };

  // 4. Android back button.
  function isShown(el) {
    return !!el && !el.classList.contains("hidden");
  }
  function onBack() {
    var dp = document.getElementById("datePickOverlay");
    if (dp) { dp.click(); return; } // backdrop click = cancel in the original code
    var hs = document.getElementById("hearingStatusDialog");
    if (hs) { var c = hs.querySelector("#cancelHearingStatus"); if (c) c.click(); else hs.remove(); return; }
    // The fee dialog's only exit records a choice ("Save selected fees" / "No fee now"),
    // so back does nothing while it is open to avoid skipping fees by accident.
    if (document.querySelector(".fee-overlay")) return;
    var forms = [["caseForm", "cancelCase"], ["taskForm", "cancelTask"], ["unavForm", "cancelUnav"]];
    for (var i = 0; i < forms.length; i++) {
      var f = document.getElementById(forms[i][0]);
      if (isShown(f) && f.innerHTML.trim()) {
        var btn = document.getElementById(forms[i][1]);
        if (btn) btn.click(); else f.classList.add("hidden");
        return;
      }
    }
    var rp = document.getElementById("reminderPanel");
    if (isShown(rp)) { rp.classList.add("hidden"); return; }
    var active = document.querySelector(".tabs button.active");
    if (active && active.dataset.tab !== "calendar" && typeof window.tab === "function") {
      window.tab("calendar");
      window.scrollTo(0, 0);
      return;
    }
    call("App", "exitApp");
  }
  window.__androidOnBack = onBack;
  cap.nativeCallback("App", "addListener", { eventName: "backButton" }, function () { onBack(); });
})();
