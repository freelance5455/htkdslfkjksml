# Test report — 9 Nov 2026

These tests ran automatically in a Chromium browser (desktop 1280px, and phone 390px for the Android checks).
Android features were checked with a simulated Android bridge, not on a real phone.

## Browser — all features

- PASS — 9 tabs present as in v0.2
- PASS — No separate Payment/Hearing Reminders tabs
- PASS — Android bridge inactive in browser
- PASS — +Case opens Add Case form
- PASS — Case saved locally (Sharma v. State)
- PASS — Case shows on 31-01-2027 with court (31Sharma v. State [HC • Delhi] W.P.(C) 1234 — Arguments)
- PASS — Outstation Matters lists the case
- PASS — Fee services in specified order
- PASS — History: 31-01 appeared, 03-02 scheduled
- PASS — Calendar moved case from 31 Jan to 3 Feb
- PASS — Fee entries recorded for 31-01
- PASS — Next Date/Status updated to 02-03-2027 with purpose
- PASS — Ledger oldest first, then service order within a date
- PASS — 'Add to Payment Reminder' absent
- PASS — Reminder image is a real PNG (481639 bytes, payment-reminder.png)
- PASS — Ledger print page opens with client
- PASS — +Task saves normal and non-postponable tasks
- PASS — Non-postponable overdue date is black (rgb(23, 23, 23))
- PASS — Normal overdue task date not black (day weekend)
- PASS — Normal overdue task listed as OVERDUE in My Tasks
- PASS — INFO normal overdue task stays on its original date (v0.2 behaviour)
- PASS — Postponing fixed task is refused
- PASS — Fixed task has no Postpone button; normal task has
- PASS — Normal task postponed with history kept
- PASS — Black mark cleared after completing fixed task
- PASS — Completed task in Disposed Tasks
- PASS — Unavailable dates marked purple with reason
- PASS — Unavailability edit saved
- PASS — Data persists across reload
- PASS — Export All Master Data downloads full JSON (advocate-calendar-backup-2026-11-09.json)
- PASS — Export Ledger downloads ledger-only JSON
- PASS — Import restores every record
- PASS — Ledger-only import keeps cases/tasks
- PASS — Disposed case moves to Disposed / Left Cases
- PASS — Records not deleted after dispose
- PASS — Works with network off (add task)
- PASS — No requests to the internet
- PASS — No script errors

## Simulated Android (share sheet, back button) and phone-size layout

- PASS — Bridge active in simulated Android
- PASS — Android: Export All saves JSON file + opens share sheet  -- advocate-calendar-backup-2026-11-09.json
- PASS — Android: Ledger export saves + shares
- PASS — Android: reminder image saved as PNG + shared  -- 508510 bytes payment-reminder.png
- PASS — Android: ledger print page saved as HTML + shared  -- ledger-Ramesh Sharma-2026-11-09.html
- PASS — No browser downloads attempted on Android
- PASS — Back closes task form
- PASS — Back closes case form
- PASS — Back closes unavailability form
- PASS — Back cancels status dialog
- PASS — Back cancels date picker without changes
- PASS — Back from another tab returns to Calendar
- PASS — Back on Calendar exits app
- PASS — Mobile 390px: no sideways scrolling on calendar  -- 390
- PASS — Mobile 390px: no sideways scrolling on cases  -- 390
- PASS — Mobile 390px: no sideways scrolling on ledger  -- 390
- PASS — Mobile 390px: no sideways scrolling on tasks  -- 390
- PASS — Mobile 390px: no sideways scrolling on backup  -- 390
- PASS — No script errors (simulated Android)

## Not tested (requires a real phone / Android Studio)

- Building the APK. There is no Android SDK in the build environment, so no APK has been built.
- Real airplane mode on a phone. The app files are inside the APK, so they should load offline. Offline use was tested in the browser by cutting the network after the app loaded.
- Data surviving an app restart and a phone restart in Android WebView. Survival across page reloads was tested in the browser.
- The real Android share sheet, sending the image on WhatsApp, and opening wa.me / eCourts links from the app.
- The real Android back button. The same handler was tested with a simulated back event.
- Opening the shared ledger .html in Chrome and printing it to PDF.

## Findings in v0.2

- **+ Task / + Unavailability on the Calendar did nothing visible.** The form opened inside a hidden tab. Fixed with one call each (`tab('tasks')` / `tab('unavailability')`), the same pattern **+ Case** already uses.
- **Normal tasks are not moved forward automatically in v0.2.** An overdue normal task stays on its original date, is listed as "OVERDUE by N days" in My Tasks, and can be postponed (old date kept in history). This behaviour was kept unchanged.
