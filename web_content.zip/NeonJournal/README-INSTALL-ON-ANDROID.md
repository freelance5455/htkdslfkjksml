# Neon Journal — Android project (local-only)

Native Android WebView wrapper around the supplied Neon Journal files. HTML/JS assets are bundled inside the APK; there is no website and no INTERNET permission. Journal data is stored in app-private WebView local storage. PDF and JSON exports are written to `Downloads/Neon Journal`.

## Build on your Android phone
1. Install an Android IDE that supports Android Gradle projects and SDK 35 (for example AndroidIDE, if available for your device). You may need internet briefly to install the IDE's build tools and Gradle dependencies; that is only for building, not for using the journal.
2. Download and extract `NeonJournal-Android-Project.zip` to a folder on your phone.
3. Open the extracted `NeonJournal` folder as a project in the IDE.
4. Allow SDK/build components to install if prompted.
5. Run Gradle sync, then build the debug APK (`assembleDebug` / Build APK).
6. Install the generated APK. If prompted, allow that IDE to install unknown apps.
7. Test a sample entry, JSON backup and PDF export before using it for important entries.

## Privacy and limitations
- No INTERNET permission; app assets are bundled locally.
- Entries stay in app-private browser storage. Uninstalling or clearing app storage can erase entries; export a JSON backup regularly.
- The existing PIN is a convenience lock using a weak hash, not encryption. This wrapper does not add encryption or biometric authentication. Do not rely on it to protect highly sensitive entries.
- A debug APK is not Play Store signed.
