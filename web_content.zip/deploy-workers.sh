#!/usr/bin/env bash
# دیپلوی Worker یکپارچه (همگام‌سازی + ریلی + معامله) روی هر سه Worker برنامه
# پیش‌نیاز: npm i -g wrangler && wrangler login
set -e
cd "$(dirname "$0")"
for NAME in square-wind-j49bc shy-cherry-bfe3 blue-water-294c; do
  echo "== deploy $NAME"
  wrangler deploy cloudflare-worker-relay.js --name "$NAME" --compatibility-date 2024-09-01
done
for NAME in square-wind-j49bc shy-cherry-bfe3 blue-water-294c; do
  curl -s "https://$NAME.lyakbrrytpyshh.workers.dev/trade/v1/health"; echo
done
