VINYL VAULT V8.3 - CLEAN ANDROID BUILD

This is the repaired V8.3 Android wrapper.

Includes:
- Complete MainActivity WebView wrapper
- Complete native CameraX + ML Kit barcode scanner
- Camera permission requested only when scanning; clear denied-permission message
- Discogs opens in the external browser and returns to Vinyl Vault; API import may depend on Discogs network/CORS access
- LocalStorage collection
- JSON backup/restore and CSV export
- Web app in web/index.html and android/app/src/main/assets/index.html

Build:
Open the android folder in Android Studio or an online Android Gradle builder.
Application ID: com.vinylvault.v81
Version: 8.3

Repair notes: removed the competing camera-permission request on app startup; ScannerActivity now owns camera permission prompts. External WebView links are opened in the browser.


V8.3 WEBVIEW FAILURE FIX:
- WebViewAssetLoader now serves both /assets/ and /web/ paths.
- Launcher URL uses https://appassets.androidplatform.net/web/index.html to match the failing URL seen on the phone.
