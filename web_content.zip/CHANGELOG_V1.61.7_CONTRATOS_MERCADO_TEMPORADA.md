# v1.61.7 — Mercado de fim de temporada e contratos

- Ao concluir uma temporada profissional, o jogador recebe três propostas de clubes selecionados entre as equipes cadastradas nas ligas do save, com adequação baseada em overall, reputação, forma e produção da temporada.
- A tela permite escolher uma proposta ou permanecer no clube atual enquanto o contrato ainda estiver vigente.
- Se o contrato estiver encerrado, a opção de permanência é removida e as propostas são apresentadas como oportunidades para atleta livre.
- O contrato passa a contar dias restantes e gera alertas/notificações aos 90, 60 e 30 dias do vencimento, além do aviso de encerramento.
- Renovação e transferência reiniciam o prazo contratual e os alertas.
- As decisões de transferência continuam dependendo da confirmação do usuário.
