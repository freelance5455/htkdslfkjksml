-- Smart Student LK: Supabase SQL Editor-ல் முழுவதையும் இயக்கவும்.
-- பாதுகாப்பு: மாணவர்கள் தங்களை teacher ஆக மாற்றிக்கொள்ள முடியாத வகையில் role மாற்றம் தடைசெய்யப்பட்டுள்ளது.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  grade text not null default 'O/L',
  role text not null default 'student' check (role in ('student','teacher','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  grade text not null,
  content text not null,
  teacher_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  grade text not null,
  questions jsonb not null,
  teacher_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.papers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subject text not null,
  grade text not null,
  year text not null,
  file_path text not null,
  teacher_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.scores (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  quiz_id uuid references public.quizzes(id) on delete set null,
  quiz_title text not null,
  score integer not null check (score >= 0),
  total integer not null check (total > 0 and score <= total),
  created_at timestamptz not null default now()
);

create index if not exists lessons_grade_idx on public.lessons(grade);
create index if not exists quizzes_grade_idx on public.quizzes(grade);
create index if not exists papers_grade_idx on public.papers(grade);
create index if not exists scores_student_idx on public.scores(student_id);

-- New user profile: student role only; grade/name are read from signup metadata.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name, grade, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'grade', 'O/L'),
    'student'
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.lessons enable row level security;
alter table public.quizzes enable row level security;
alter table public.papers enable row level security;
alter table public.scores enable row level security;

-- role helper; SECURITY DEFINER avoids recursive RLS profile lookup.
create or replace function public.current_app_role()
returns text language sql stable security definer set search_path = '' as $$
  select role from public.profiles where id = auth.uid()
$$;
revoke all on function public.current_app_role() from public;
grant execute on function public.current_app_role() to authenticated;

create policy "profiles read self or teacher" on public.profiles
for select to authenticated
using (id = auth.uid() or public.current_app_role() in ('teacher','admin'));
create policy "profiles update self name and grade" on public.profiles
for update to authenticated
using (id = auth.uid())
with check (id = auth.uid() and role = (select p.role from public.profiles p where p.id = auth.uid()));

create policy "lessons read authenticated" on public.lessons
for select to authenticated using (true);
create policy "teachers insert lessons" on public.lessons
for insert to authenticated with check (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());
create policy "teachers update own lessons" on public.lessons
for update to authenticated using (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid())
with check (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());
create policy "teachers delete own lessons" on public.lessons
for delete to authenticated using (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());

create policy "quizzes read authenticated" on public.quizzes
for select to authenticated using (true);
create policy "teachers insert quizzes" on public.quizzes
for insert to authenticated with check (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());
create policy "teachers update own quizzes" on public.quizzes
for update to authenticated using (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid())
with check (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());
create policy "teachers delete own quizzes" on public.quizzes
for delete to authenticated using (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());

create policy "papers read authenticated" on public.papers
for select to authenticated using (true);
create policy "teachers insert papers" on public.papers
for insert to authenticated with check (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());
create policy "teachers update own papers" on public.papers
for update to authenticated using (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid())
with check (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());
create policy "teachers delete own papers" on public.papers
for delete to authenticated using (public.current_app_role() in ('teacher','admin') and teacher_id = auth.uid());

create policy "students read own scores; teachers read all" on public.scores
for select to authenticated using (student_id = auth.uid() or public.current_app_role() in ('teacher','admin'));
create policy "students insert own scores" on public.scores
for insert to authenticated with check (student_id = auth.uid());

-- Private PDF storage bucket. Create bucket named 'papers' in Storage dashboard,
-- then apply these policies. Paths must begin with the uploader's auth UUID.
create policy "signed-in users read papers" on storage.objects
for select to authenticated using (bucket_id = 'papers');
create policy "teachers upload own paper path" on storage.objects
for insert to authenticated with check (
  bucket_id = 'papers'
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.current_app_role() in ('teacher','admin')
);
create policy "teachers update own paper path" on storage.objects
for update to authenticated using (
  bucket_id = 'papers'
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.current_app_role() in ('teacher','admin')
) with check (
  bucket_id = 'papers'
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.current_app_role() in ('teacher','admin')
);
create policy "teachers delete own paper path" on storage.objects
for delete to authenticated using (
  bucket_id = 'papers'
  and (storage.foldername(name))[1] = auth.uid()::text
  and public.current_app_role() in ('teacher','admin')
);
