# Smart Student LK — தமிழில் நிறுவும் வழிகாட்டி

இந்த project-ல் Website + Android wrapper, Student Login, பாடக்குறிப்புகள், Quiz, மதிப்பெண்கள், PDF வினாத்தாள்கள் மற்றும் Teacher Dashboard ஆகியவற்றுக்கான அடிப்படை code உள்ளது.

## 1. இலவசமாகத் தொடங்கத் தேவையானவை

- Supabase account: https://supabase.com
- Node.js (Vite/Capacitor இயங்க): https://nodejs.org
- GitHub account (விருப்பத்தேர்வு; code-ஐ வைத்திருக்க)
- Android app உருவாக்க கணினியில் Android Studio + Android SDK தேவை: https://developer.android.com/studio

> Android Studio மூலம் APK உருவாக்க லேப்டாப்/கணினி தேவை. மொபைலில் மட்டும் ஆரம்பிக்க விரும்பினால் முதலில் StackBlitz போன்ற browser-based coding environment-ல் web app-ஐ சோதிக்கலாம். Android build-க்கு பின்னர் கணினியைப் பயன்படுத்தலாம்.

## 2. Supabase திட்டம் உருவாக்குதல்

1. https://supabase.com சென்று account உருவாக்கவும்.
2. **New project** அழுத்தி project name-ஐ `smart-student-lk` என்று வைக்கவும்.
3. Database password-ஐ பாதுகாப்பாக வைத்துக்கொள்ளவும்.
4. Project தயாரானதும் **SQL Editor → New query** திறக்கவும்.
5. இந்த project-இல் உள்ள `supabase/schema.sql` கோப்பின் முழு SQL-ஐ paste செய்து **Run** அழுத்தவும்.
6. **Storage → New bucket** சென்று bucket name-ஐ `papers` என வைக்கவும். **Public bucket** தேர்வு செய்ய வேண்டாம்; private-ஆகவே வைக்கவும்.
7. **Project Settings → API** அல்லது Connect பகுதியில் Project URL மற்றும் publishable key (பழைய project-களில் anon key) எடுக்கவும். `service_role` / secret key-ஐ browser code-ல் ஒருபோதும் சேர்க்க வேண்டாம்.

## 3. ஆசிரியர் கணக்கு அமைத்தல் — முக்கிய பாதுகாப்பு படி

1. App-ல் புதிய கணக்கு உருவாக்கி அந்த ஆசிரியரின் email-ஐப் பயன்படுத்தவும்.
2. Supabase Dashboard → **Authentication → Users** பகுதியில் அந்த user-ஐத் தேர்ந்தெடுத்து UUID-ஐ copy செய்யவும்.
3. SQL Editor-ல் கீழே உள்ள SQL-ஐ இயக்கவும்; UUID இடத்தில் உண்மையான UUID-ஐ இடவும்:

```sql
update public.profiles
set role = 'teacher'
where id = 'PASTE-TEACHER-USER-UUID-HERE';
```

4. ஆசிரியர் sign out செய்து மீண்டும் login செய்ய வேண்டும். அப்போது Teacher Dashboard தோன்றும்.
5. மாணவர் கணக்குகளை `student` ஆகவே விடவும். யாரையும் teacher ஆக்குவது project owner-ன் பொறுப்பு.

## 4. உங்கள் Supabase keys சேர்த்தல்

1. Project folder-ல் `.env.example`-ஐ copy செய்து `.env` என்ற பெயரில் சேமிக்கவும்.
2. `.env` கோப்பில் values நிரப்பவும்:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
```

3. `.env`-ஐ GitHub-ல் commit செய்ய வேண்டாம். `.gitignore`-ல் அது சேர்க்கப்பட்டுள்ளது.

## 5. Website இயக்குதல்

கணினியில் project folder-ஐ திறந்து Terminal / Command Prompt-ல்:

```bash
npm install
npm run dev
```

Terminal காட்டும் local URL-ஐ browser-ல் திறக்கவும் (பொதுவாக `http://localhost:5173`).

Production build சோதிக்க:

```bash
npm run build
npm run preview
```

`dist` folder உருவானதும் அதை Netlify அல்லது Vercel போன்ற static hosting சேவையில் deploy செய்யலாம். Deploy settings-ல் கீழ்கண்ட environment variables சேர்க்க வேண்டும்:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

## 6. Android App உருவாக்குதல்

கணினியில் Node.js மற்றும் Android Studio/SDK நிறுவிய பிறகு project folder-ல்:

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Android Studio திறந்ததும் SDK packages நிறுவப்பட்டிருக்க வேண்டும். Emulator அல்லது USB debugging இயக்கிய Android phone தேர்ந்தெடுத்து **Run ▶** அழுத்தவும்.

ஒவ்வொரு முறையும் web code மாற்றிய பின்:

```bash
npm run build
npx cap sync android
```

Android Studio-ல் Build menu மூலம் APK உருவாக்கலாம். Google Play-ல் வெளியிடுவதற்கு developer account/கட்டண விதிகள் பொருந்தலாம்; APK-ஐ நேரடியாகச் சோதிப்பது வேறு.

## 7. Teacher Dashboard பயன்படுத்துவது

Teacher role-ல் login செய்த பின்:
- **பாடக்குறிப்பு சேர்க்கவும்:** தலைப்பு, பாடம், வகுப்பு, குறிப்புகள் நிரப்பவும்.
- **Quiz உருவாக்கவும்:** கேள்விகள் JSON array வடிவில் இருக்க வேண்டும்.
- **வினாத்தாள் PDF:** PDF மட்டும், அதிகபட்சம் 20 MB என்ற client-side வரம்புடன் பதிவேற்றவும்.
- மாணவர்கள் Quiz சமர்ப்பித்த பிறகு அவர்களின் மதிப்பெண்கள் Dashboard-ல் தோன்றும்.

Quiz JSON உதாரணம்:

```json
[
  {
    "question": "12 × 8 = ?",
    "options": ["84", "96", "108", "88"],
    "answer": 1
  },
  {
    "question": "நீரின் வேதியியல் குறியீடு என்ன?",
    "options": ["CO₂", "O₂", "H₂O", "NaCl"],
    "answer": 2
  }
]
```

`answer` என்பது options array-இல் 0-ல் தொடங்கும் index: முதல் விடை `0`, இரண்டாவது `1`, மூன்றாவது `2`.

## 8. இலவச திட்ட வரம்புகள் மற்றும் முக்கிய குறிப்புகள்

- Supabase Free திட்டத்தில் பயன்பாட்டு/சேமிப்பு வரம்புகள் உள்ளன; நீண்ட நேரம் பயன்படுத்தப்படாத project pause ஆகலாம். தற்போதைய விவரங்கள்: https://supabase.com/pricing
- Static hosting-க்கும் இலவச வரம்புகள் இருக்கலாம்.
- மாணவர்களின் உண்மையான பெயர், மின்னஞ்சல் போன்ற தரவைச் சேமிப்பதற்கு முன் தனியுரிமைக் கொள்கை மற்றும் பெற்றோர்/பள்ளி அனுமதி தேவைகளைப் பரிசீலிக்கவும்.
- இது தொடக்க MVP. வெளியிடுவதற்கு முன் security, privacy, backup, accessibility மற்றும் அதிகமான பயனர்களுடன் சோதனை அவசியம்.
- இப்போதைய quiz வடிவமைப்பு பதில்களின் சரியான index-ஐ browser-க்கு அனுப்புகிறது; இது பயிற்சி MVP-க்கு ஏற்றது, ஆனால் உயர் பாதுகாப்பு மதிப்பீடு/தேர்வுகளுக்கு சரியான விடைகளை server-side-ல் வைத்துக் கணக்கிடும் அமைப்பாக மாற்ற வேண்டும்.
- RLS policy-கள் தரவுக்கான அடிப்படை பாதுகாப்பை வழங்குகின்றன; production-க்கு முன் அவற்றை நிபுணர் பரிசீலிக்க வேண்டும்.
