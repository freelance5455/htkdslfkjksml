import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { isConfigured, supabase } from './supabase';
import './style.css';

const sampleQuiz = [
  { question: '12 × 8 = ?', options: ['84', '96', '108', '88'], answer: 1 },
  { question: 'ஒரு முக்கோணத்தின் உள் கோணங்களின் மொத்தம்?', options: ['90°', '180°', '270°', '360°'], answer: 1 },
  { question: 'நீரின் வேதியியல் குறியீடு என்ன?', options: ['CO₂', 'O₂', 'H₂O', 'NaCl'], answer: 2 }
];

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [authMode, setAuthMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [grade, setGrade] = useState('O/L');
  const [page, setPage] = useState('home');
  const [notice, setNotice] = useState('');
  const [loading, setLoading] = useState(false);
  const [lessons, setLessons] = useState([]);
  const [papers, setPapers] = useState([]);
  const [scores, setScores] = useState([]);
  const [quizzes, setQuizzes] = useState([]);
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [lessonForm, setLessonForm] = useState({ title: '', subject: 'கணிதம்', grade: 'O/L', content: '' });
  const [quizForm, setQuizForm] = useState({ title: '', subject: 'கணிதம்', grade: 'O/L', questionsText: JSON.stringify(sampleQuiz, null, 2) });
  const [paperForm, setPaperForm] = useState({ title: '', subject: 'கணிதம்', grade: 'O/L', year: String(new Date().getFullYear()) });
  const [paperFile, setPaperFile] = useState(null);

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, current) => setSession(current));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (session?.user) loadProfileAndData();
    else { setProfile(null); setLessons([]); setPapers([]); setScores([]); setQuizzes([]); }
  }, [session?.user?.id]);

  async function loadProfileAndData() {
    if (!supabase || !session?.user) return;
    const uid = session.user.id;
    const { data: p, error: profileError } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
    if (profileError) setNotice(profileError.message);
    setProfile(p);
    const [l, pa, sc, q] = await Promise.all([
      supabase.from('lessons').select('*').order('created_at', { ascending: false }),
      supabase.from('papers').select('*').order('created_at', { ascending: false }),
      supabase.from('scores').select('*').eq('student_id', uid).order('created_at', { ascending: false }),
      supabase.from('quizzes').select('*').order('created_at', { ascending: false })
    ]);
    if (l.error || pa.error || sc.error || q.error) setNotice([l.error, pa.error, sc.error, q.error].filter(Boolean).map(e => e.message).join(' | '));
    setLessons(l.data || []); setPapers(pa.data || []); setScores(sc.data || []); setQuizzes(q.data || []);
  }

  async function handleAuth(e) {
    e.preventDefault(); setLoading(true); setNotice('');
    try {
      if (!supabase) throw new Error('முதலில் .env கோப்பில் Supabase URL மற்றும் key சேர்க்கவும்.');
      if (authMode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email, password,
          options: { data: { full_name: fullName, grade } }
        });
        if (error) throw error;
        if (data.session) setNotice('கணக்கு உருவாக்கப்பட்டது!');
        else setNotice('கணக்கு உருவாக்கப்பட்டது. Email-ஐ சரிபார்த்து பின்னர் Login செய்யவும்.');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (e2) { setNotice(e2.message || 'செயல்பாடு தோல்வியடைந்தது.'); }
    finally { setLoading(false); }
  }

  async function signOut() { await supabase?.auth.signOut(); setPage('home'); setNotice(''); }
  const isTeacher = profile?.role === 'teacher' || profile?.role === 'admin';

  async function saveLesson(e) {
    e.preventDefault(); setNotice('');
    const { error } = await supabase.from('lessons').insert({ ...lessonForm, teacher_id: session.user.id });
    if (error) setNotice(error.message);
    else { setNotice('பாடக்குறிப்பு சேர்க்கப்பட்டது.'); setLessonForm({ title: '', subject: 'கணிதம்', grade: 'O/L', content: '' }); loadProfileAndData(); }
  }

  async function saveQuiz(e) {
    e.preventDefault(); setNotice('');
    try {
      const questions = JSON.parse(quizForm.questionsText);
      if (!Array.isArray(questions) || !questions.length) throw new Error('கேள்விகளை JSON array வடிவில் கொடுக்கவும்.');
      for (const q of questions) {
        if (!q.question || !Array.isArray(q.options) || !Number.isInteger(q.answer)) throw new Error('ஒவ்வொரு கேள்வியிலும் question, options, answer இருக்க வேண்டும்.');
      }
      const { error } = await supabase.from('quizzes').insert({
        title: quizForm.title, subject: quizForm.subject, grade: quizForm.grade,
        questions, teacher_id: session.user.id
      });
      if (error) throw error;
      setNotice('Quiz உருவாக்கப்பட்டது.'); loadProfileAndData();
    } catch (err) { setNotice(err.message); }
  }

  async function uploadPaper(e) {
    e.preventDefault(); setNotice('');
    if (!paperFile) { setNotice('PDF கோப்பைத் தேர்ந்தெடுக்கவும்.'); return; }
    if (paperFile.type !== 'application/pdf') { setNotice('PDF கோப்புகள் மட்டும் அனுமதிக்கப்படும்.'); return; }
    if (paperFile.size > 20 * 1024 * 1024) { setNotice('கோப்பு 20 MB-ஐ விடச் சிறியதாக இருக்க வேண்டும்.'); return; }
    const path = `${session.user.id}/${Date.now()}-${paperFile.name.replace(/[^a-zA-Z0-9._-]/g, '_')}`;
    const { error: uploadError } = await supabase.storage.from('papers').upload(path, paperFile, { contentType: 'application/pdf', upsert: false });
    if (uploadError) { setNotice(uploadError.message); return; }
    const { error } = await supabase.from('papers').insert({ ...paperForm, file_path: path, teacher_id: session.user.id });
    if (error) setNotice(error.message);
    else { setNotice('வினாத்தாள் பதிவேற்றப்பட்டது.'); setPaperFile(null); loadProfileAndData(); }
  }

  async function openPaper(path) {
    const { data, error } = await supabase.storage.from('papers').createSignedUrl(path, 60 * 5);
    if (error) setNotice(error.message); else window.open(data.signedUrl, '_blank', 'noopener,noreferrer');
  }

  function startQuiz(q) { setQuiz(q); setAnswers({}); setPage('quiz'); }
  async function submitQuiz() {
    const questions = quiz.questions;
    let correct = 0;
    questions.forEach((q, i) => { if (Number(answers[i]) === Number(q.answer)) correct += 1; });
    const { error } = await supabase.from('scores').insert({
      student_id: session.user.id, quiz_id: quiz.id, score: correct,
      total: questions.length, quiz_title: quiz.title
    });
    if (error) setNotice(error.message);
    else { setNotice(`Quiz முடிந்தது! ${questions.length} இல் ${correct} சரியான பதில்கள்.`); await loadProfileAndData(); setPage('scores'); }
  }

  const filteredLessons = useMemo(() => lessons.filter(x => !profile?.grade || x.grade === profile.grade || x.grade === 'அனைத்து வகுப்புகள்'), [lessons, profile]);
  const filteredPapers = useMemo(() => papers.filter(x => !profile?.grade || x.grade === profile.grade || x.grade === 'அனைத்து வகுப்புகள்'), [papers, profile]);

  if (!isConfigured) return <SetupScreen />;
  if (!session) return <AuthScreen {...{authMode,setAuthMode,email,setEmail,password,setPassword,fullName,setFullName,grade,setGrade,handleAuth,loading,notice}} />;

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="logo">📚</div><div><h1>Smart Student LK</h1><p>கற்றுக்கொள் • பயிற்சி செய் • முன்னேறு</p></div></div>
      <div className="userbox"><span>{profile?.full_name || session.user.email}</span><button className="btn btn-outline" onClick={signOut}>வெளியேறு</button></div>
    </header>
    <div className="layout">
      <aside className="sidebar">
        {[['home','🏠','முகப்பு'],['lessons','📘','பாடக்குறிப்புகள்'],['papers','📄','வினாத்தாள்கள்'],['quizzes','🧠','Quiz'],['scores','🏆','என் மதிப்பெண்கள்'],...(isTeacher ? [['teacher','🧑‍🏫','Teacher Dashboard']] : [])].map(([id,icon,label]) =>
          <button key={id} className={`navitem ${page===id?'active':''}`} onClick={()=>setPage(id)}><span>{icon}</span>{label}</button>)}
        <div className="sidebar-note">உங்கள் வகுப்பு: <b>{profile?.grade || 'அமைக்கப்படவில்லை'}</b></div>
      </aside>
      <main className="content">
        {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={()=>setNotice('')} aria-label="மூடு">×</button></div>}
        {page==='home' && <Home {...{profile,lessons:filteredLessons,papers:filteredPapers,quizzes,scores,setPage,startQuiz}} />}
        {page==='lessons' && <Lessons lessons={filteredLessons} />}
        {page==='papers' && <Papers papers={filteredPapers} openPaper={openPaper} />}
        {page==='quizzes' && <QuizList quizzes={quizzes.filter(q=>!profile?.grade || q.grade===profile.grade || q.grade==='அனைத்து வகுப்புகள்')} startQuiz={startQuiz} />}
        {page==='quiz' && quiz && <QuizRunner quiz={quiz} answers={answers} setAnswers={setAnswers} submitQuiz={submitQuiz} back={()=>setPage('quizzes')} />}
        {page==='scores' && <Scores scores={scores} />}
        {page==='teacher' && isTeacher && <TeacherDashboard {...{lessonForm,setLessonForm,saveLesson,quizForm,setQuizForm,saveQuiz,paperForm,setPaperForm,paperFile,setPaperFile,uploadPaper,scores,lessons,papers}} />}
      </main>
    </div>
    <footer>Smart Student LK • மாணவர்களின் முன்னேற்றத்திற்காக</footer>
  </div>;
}

function SetupScreen() {
  return <div className="auth-wrap"><div className="auth-card"><div className="logo big">📚</div><h1>Smart Student LK</h1><p>உங்கள் Supabase திட்டத்தை இணைத்ததும் App இயங்கத் தொடங்கும்.</p><ol className="setup-list"><li>Supabase-ல் இலவச project உருவாக்கவும்.</li><li>SQL Editor-ல் <code>supabase/schema.sql</code> உள்ள SQL-ஐ இயக்கவும்.</li><li>Storage-ல் <b>papers</b> என்ற private bucket உருவாக்கவும்.</li><li><code>.env.example</code> கோப்பை <code>.env</code> என நகலெடுத்து URL மற்றும் publishable/anon key நிரப்பவும்.</li><li><code>npm install</code> மற்றும் <code>npm run dev</code> இயக்கவும்.</li></ol><p className="small muted">விரிவான தமிழ்வழி வழிமுறைகள் README_TA.md கோப்பில் உள்ளன.</p></div></div>;
}

function AuthScreen(p) {
  return <div className="auth-wrap"><form className="auth-card" onSubmit={p.handleAuth}>
    <div className="logo big">📚</div><h1>Smart Student LK</h1><p>அனைத்து வகுப்பு மாணவர்களுக்கான கற்றல் தளம்</p>
    <div className="tabs"><button type="button" className={p.authMode==='login'?'selected':''} onClick={()=>p.setAuthMode('login')}>Login</button><button type="button" className={p.authMode==='signup'?'selected':''} onClick={()=>p.setAuthMode('signup')}>புதிய கணக்கு</button></div>
    {p.authMode==='signup' && <><label>முழுப் பெயர்<input value={p.fullName} onChange={e=>p.setFullName(e.target.value)} required maxLength="100" placeholder="உங்கள் பெயர்"/></label><label>வகுப்பு<select value={p.grade} onChange={e=>p.setGrade(e.target.value)}>{grades.map(g=><option key={g}>{g}</option>)}</select></label></>}
    <label>Email<input type="email" value={p.email} onChange={e=>p.setEmail(e.target.value)} required autoComplete="email" placeholder="you@example.com"/></label>
    <label>கடவுச்சொல்<input type="password" value={p.password} onChange={e=>p.setPassword(e.target.value)} required minLength="8" autoComplete={p.authMode==='login'?'current-password':'new-password'} placeholder="குறைந்தது 8 எழுத்துகள்"/></label>
    {p.notice && <div className="notice">{p.notice}</div>}
    <button className="btn btn-primary full" disabled={p.loading}>{p.loading?'செயல்படுகிறது...':p.authMode==='login'?'Login செய்யவும்':'கணக்கு உருவாக்கவும்'}</button>
    <p className="small muted">உங்கள் கடவுச்சொல்லை யாருடனும் பகிர வேண்டாம்.</p>
  </form></div>;
}
const grades = ['தரம் 1','தரம் 2','தரம் 3','தரம் 4','தரம் 5','தரம் 6','தரம் 7','தரம் 8','தரம் 9','தரம் 10','தரம் 11','O/L','தரம் 12','தரம் 13','A/L','அனைத்து வகுப்புகள்'];
const subjects = ['கணிதம்','விஞ்ஞானம்','தமிழ்','ஆங்கிலம்','வரலாறு','ICT','புவியியல்','வணிகம்','மற்றவை'];

function Home({profile,lessons,papers,quizzes,scores,setPage,startQuiz}) {
  return <><div className="hero"><div><span className="eyebrow">உங்கள் கற்றல் பயணம்</span><h2>வணக்கம், {profile?.full_name || 'மாணவரே'}! 👋</h2><p>இன்று ஒரு புதிய விஷயத்தைக் கற்றுக்கொள்வோம்.</p></div><div className="hero-icon">🎓</div></div>
    <div className="stats"><Stat icon="📘" label="பாடக்குறிப்புகள்" value={lessons.length}/><Stat icon="📄" label="வினாத்தாள்கள்" value={papers.length}/><Stat icon="🏆" label="Quiz முயற்சிகள்" value={scores.length}/></div>
    <div className="section-head"><h2>விரைவு அணுகல்</h2></div><div className="quick-grid">
      <Quick icon="📚" title="பாடக்குறிப்புகள்" desc="பாடங்களைப் படிக்கவும்" onClick={()=>setPage('lessons')}/>
      <Quick icon="📝" title="கடந்தகால வினாத்தாள்கள்" desc="பயிற்சி செய்யவும்" onClick={()=>setPage('papers')}/>
      <Quick icon="🧠" title="Quiz பயிற்சி" desc="உங்கள் அறிவைச் சோதிக்கவும்" onClick={()=>setPage('quizzes')}/>
      <Quick icon="📈" title="என் மதிப்பெண்கள்" desc="முன்னேற்றத்தைப் பார்க்கவும்" onClick={()=>setPage('scores')}/>
    </div>
    <div className="section-head"><h2>புதிய Quiz-கள்</h2><button className="text-btn" onClick={()=>setPage('quizzes')}>அனைத்தையும் பார் →</button></div>
    {quizzes.length ? <div className="item-grid">{quizzes.slice(0,3).map(q=><article className="item-card" key={q.id}><span className="pill">{q.grade}</span><h3>{q.title}</h3><p>{q.subject} · {q.questions?.length || 0} கேள்விகள்</p><button className="btn btn-primary" onClick={()=>startQuiz(q)}>Quiz தொடங்கு</button></article>)}</div> : <Empty text="இன்னும் Quiz சேர்க்கப்படவில்லை. ஆசிரியர் விரைவில் சேர்க்கலாம்."/>}
  </>;
}
function Stat({icon,label,value}){return <div className="stat-card"><span>{icon}</span><div><strong>{value}</strong><small>{label}</small></div></div>}
function Quick({icon,title,desc,onClick}){return <button className="quick-card" onClick={onClick}><span className="quick-icon">{icon}</span><span><b>{title}</b><small>{desc}</small></span><span className="arrow">→</span></button>}
function Empty({text}){return <div className="empty"><span>📭</span><p>{text}</p></div>}
function Lessons({lessons}){return <><PageTitle title="பாடக்குறிப்புகள்" sub="உங்கள் வகுப்பிற்கான குறிப்புகளைப் படிக்கவும்."/><div className="item-grid">{lessons.map(l=><article className="item-card" key={l.id}><span className="pill">{l.grade}</span><h3>{l.title}</h3><p className="muted">{l.subject}</p><div className="lesson-content">{l.content}</div></article>)}</div>{!lessons.length&&<Empty text="இன்னும் பாடக்குறிப்புகள் இல்லை."/>}</>}
function Papers({papers,openPaper}){return <><PageTitle title="கடந்தகால வினாத்தாள்கள்" sub="PDF வினாத்தாள்களைத் திறந்து பயிற்சி செய்யவும்."/><div className="table-wrap"><table><thead><tr><th>வினாத்தாள்</th><th>வகுப்பு</th><th>பாடம்</th><th>ஆண்டு</th><th></th></tr></thead><tbody>{papers.map(p=><tr key={p.id}><td>{p.title}</td><td>{p.grade}</td><td>{p.subject}</td><td>{p.year}</td><td><button className="btn btn-primary btn-sm" onClick={()=>openPaper(p.file_path)}>PDF திற</button></td></tr>)}</tbody></table></div>{!papers.length&&<Empty text="வினாத்தாள்கள் இன்னும் பதிவேற்றப்படவில்லை."/>}</>}
function QuizList({quizzes,startQuiz}){return <><PageTitle title="Quiz பயிற்சி" sub="கேள்விகளுக்குப் பதிலளித்து உங்கள் மதிப்பெண்களைப் பெறுங்கள்."/><div className="item-grid">{quizzes.map(q=><article className="item-card" key={q.id}><span className="pill">{q.grade}</span><h3>{q.title}</h3><p>{q.subject} · {q.questions?.length || 0} கேள்விகள்</p><button className="btn btn-primary" onClick={()=>startQuiz(q)}>தொடங்கு</button></article>)}</div>{!quizzes.length&&<Empty text="Quiz இன்னும் உருவாக்கப்படவில்லை."/>}</>}
function QuizRunner({quiz,answers,setAnswers,submitQuiz,back}){const [submitted,setSubmitted]=useState(false);return <><PageTitle title={quiz.title} sub={`${quiz.subject} · ${quiz.grade}`}/><div className="quiz-paper">{quiz.questions.map((q,i)=><fieldset className="question" key={i}><legend>{i+1}. {q.question}</legend>{q.options.map((op,j)=><label className="radio-option" key={j}><input type="radio" name={`q-${i}`} disabled={submitted} checked={Number(answers[i])===j} onChange={()=>setAnswers(old=>({...old,[i]:j}))}/><span>{op}</span></label>)}</fieldset>)}{!submitted?<button className="btn btn-primary" onClick={()=>{setSubmitted(true);submitQuiz()}}>பதில்களைச் சமர்ப்பிக்கவும்</button>:<p>உங்கள் பதில்கள் சமர்ப்பிக்கப்பட்டன.</p>} <button className="btn btn-outline" onClick={back}>Quiz பட்டியலுக்குத் திரும்பு</button></div></>}
function Scores({scores}){return <><PageTitle title="என் மதிப்பெண்கள்" sub="நீங்கள் முடித்த Quiz-களின் முடிவுகள்."/><div className="table-wrap"><table><thead><tr><th>Quiz</th><th>மதிப்பெண்</th><th>சதவீதம்</th><th>தேதி</th></tr></thead><tbody>{scores.map(s=><tr key={s.id}><td>{s.quiz_title || 'Quiz'}</td><td>{s.score}/{s.total}</td><td>{s.total?Math.round(s.score/s.total*100):0}%</td><td>{new Date(s.created_at).toLocaleDateString('ta-LK')}</td></tr>)}</tbody></table></div>{!scores.length&&<Empty text="Quiz முடித்த பிறகு உங்கள் மதிப்பெண்கள் இங்கு தெரியும்."/>}</>}
function PageTitle({title,sub}){return <div className="page-title"><h2>{title}</h2><p>{sub}</p></div>}
function TeacherDashboard(p){return <><PageTitle title="Teacher Dashboard" sub="பாடக்குறிப்புகள், Quiz மற்றும் வினாத்தாள்களை நிர்வகிக்கவும்."/><div className="teacher-grid">
  <form className="panel" onSubmit={p.saveLesson}><h3>📘 பாடக்குறிப்பு சேர்க்கவும்</h3><label>தலைப்பு<input required value={p.lessonForm.title} onChange={e=>p.setLessonForm({...p.lessonForm,title:e.target.value})}/></label><div className="form-row"><label>பாடம்<select value={p.lessonForm.subject} onChange={e=>p.setLessonForm({...p.lessonForm,subject:e.target.value})}>{subjects.map(s=><option key={s}>{s}</option>)}</select></label><label>வகுப்பு<select value={p.lessonForm.grade} onChange={e=>p.setLessonForm({...p.lessonForm,grade:e.target.value})}>{grades.map(g=><option key={g}>{g}</option>)}</select></label></div><label>குறிப்புகள்<textarea required rows="5" value={p.lessonForm.content} onChange={e=>p.setLessonForm({...p.lessonForm,content:e.target.value})}/></label><button className="btn btn-primary">சேமிக்கவும்</button></form>
  <form className="panel" onSubmit={p.saveQuiz}><h3>🧠 Quiz உருவாக்கவும்</h3><label>Quiz தலைப்பு<input required value={p.quizForm.title} onChange={e=>p.setQuizForm({...p.quizForm,title:e.target.value})}/></label><div className="form-row"><label>பாடம்<select value={p.quizForm.subject} onChange={e=>p.setQuizForm({...p.quizForm,subject:e.target.value})}>{subjects.map(s=><option key={s}>{s}</option>)}</select></label><label>வகுப்பு<select value={p.quizForm.grade} onChange={e=>p.setQuizForm({...p.quizForm,grade:e.target.value})}>{grades.map(g=><option key={g}>{g}</option>)}</select></label></div><label>கேள்விகள் (JSON)<textarea required rows="9" value={p.quizForm.questionsText} onChange={e=>p.setQuizForm({...p.quizForm,questionsText:e.target.value})}/></label><p className="small muted">answer என்பது சரியான விடையின் 0-ல் தொடங்கும் index. உதாரணம் README-ல் உள்ளது.</p><button className="btn btn-primary">Quiz சேமி</button></form>
  <form className="panel" onSubmit={p.uploadPaper}><h3>📄 வினாத்தாள் PDF பதிவேற்றம்</h3><label>தலைப்பு<input required value={p.paperForm.title} onChange={e=>p.setPaperForm({...p.paperForm,title:e.target.value})}/></label><div className="form-row"><label>பாடம்<select value={p.paperForm.subject} onChange={e=>p.setPaperForm({...p.paperForm,subject:e.target.value})}>{subjects.map(s=><option key={s}>{s}</option>)}</select></label><label>வகுப்பு<select value={p.paperForm.grade} onChange={e=>p.setPaperForm({...p.paperForm,grade:e.target.value})}>{grades.map(g=><option key={g}>{g}</option>)}</select></label></div><label>ஆண்டு<input required value={p.paperForm.year} onChange={e=>p.setPaperForm({...p.paperForm,year:e.target.value})}/></label><label>PDF கோப்பு<input type="file" accept="application/pdf,.pdf" required onChange={e=>p.setPaperFile(e.target.files?.[0]||null)}/></label><button className="btn btn-primary">பதிவேற்றவும்</button></form>
  <div className="panel"><h3>📊 மாணவர் மதிப்பெண்கள்</h3>{p.scores.length?<div className="table-wrap"><table><thead><tr><th>Quiz</th><th>மதிப்பெண்</th></tr></thead><tbody>{p.scores.map(s=><tr key={s.id}><td>{s.quiz_title}</td><td>{s.score}/{s.total}</td></tr>)}</tbody></table></div>:<p className="muted">மாணவர்கள் Quiz முடித்த பிறகு மதிப்பெண்கள் தோன்றும்.</p>}</div>
  </div></>}
createRoot(document.getElementById('root')).render(<App/>);
