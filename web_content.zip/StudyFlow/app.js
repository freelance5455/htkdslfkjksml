const STORAGE_KEY = "studyflow_topics_v1";
const form = document.getElementById("topicForm");
const subjectInput = document.getElementById("subject");
const topicInput = document.getElementById("topic");
const dueDateInput = document.getElementById("dueDate");
const topicList = document.getElementById("topicList");
const emptyState = document.getElementById("emptyState");
const filter = document.getElementById("filter");

let topics = loadTopics();

function loadTopics() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}
function saveTopics() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(topics));
  render();
}
function updateStats() {
  const done = topics.filter(t => t.done).length;
  document.getElementById("totalCount").textContent = topics.length;
  document.getElementById("doneCount").textContent = done;
  document.getElementById("leftCount").textContent = topics.length - done;
}
function render() {
  topicList.replaceChildren();
  const mode = filter.value;
  const visible = topics.filter(t => mode === "all" || (mode === "done" ? t.done : !t.done));
  emptyState.style.display = visible.length ? "none" : "block";
  visible.forEach(item => {
    const row = document.createElement("article");
    row.className = "topic" + (item.done ? " done" : "");
    const check = document.createElement("input");
    check.type = "checkbox"; check.checked = item.done;
    check.setAttribute("aria-label", `${item.topic} पूरा हुआ`);
    check.addEventListener("change", () => {
      const found = topics.find(t => t.id === item.id);
      if (found) found.done = check.checked;
      saveTopics();
    });
    const info = document.createElement("div"); info.className = "topic-info";
    const title = document.createElement("div"); title.className = "topic-title"; title.textContent = item.topic;
    const meta = document.createElement("div"); meta.className = "topic-meta";
    meta.textContent = item.subject + (item.dueDate ? " • लक्ष्य: " + item.dueDate : "");
    info.append(title, meta);
    const del = document.createElement("button"); del.className = "delete"; del.type = "button"; del.textContent = "हटाएँ";
    del.addEventListener("click", () => {
      topics = topics.filter(t => t.id !== item.id); saveTopics();
    });
    row.append(check, info, del); topicList.append(row);
  });
  updateStats();
}
form.addEventListener("submit", event => {
  event.preventDefault();
  const subject = subjectInput.value.trim();
  const topic = topicInput.value.trim();
  if (!subject || !topic) return;
  topics.unshift({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7), subject, topic, dueDate: dueDateInput.value, done: false, createdAt: new Date().toISOString() });
  form.reset(); saveTopics(); subjectInput.focus();
});
filter.addEventListener("change", render);
document.getElementById("clearDoneBtn").addEventListener("click", () => {
  if (!topics.some(t => t.done)) { alert("अभी कोई पूरा हुआ टॉपिक नहीं है।"); return; }
  if (confirm("क्या सभी पूरे हुए टॉपिक हटाने हैं?")) { topics = topics.filter(t => !t.done); saveTopics(); }
});
document.getElementById("exportBtn").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(topics, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a"); a.href = url; a.download = "studyflow-backup.json"; a.click();
  URL.revokeObjectURL(url);
});
document.getElementById("todayDate").textContent = new Intl.DateTimeFormat("hi-IN", { dateStyle: "medium" }).format(new Date());
render();
