UPI QR Generator Android Project

यह Android Studio प्रोजेक्ट है, तैयार APK नहीं।

APK बनाने के लिए:
1. कंप्यूटर पर Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Extract किया हुआ UPIQRGenerator फ़ोल्डर खोलें।
4. Gradle Sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK आमतौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगी।

ज़रूरी:
- QR लाइब्रेरी CDN से लोड होती है, इसलिए QR बनाने के लिए इंटरनेट चाहिए।
- ऐप में UPI ID पहले से सेट है: 6376885145@ptyes
- UPI ID की वैधता की पुष्टि इस प्रोजेक्ट से नहीं होती। पहले अपने UPI ऐप में जाँचें।
- यह ऐप पेमेंट की पुष्टि नहीं करता; यह केवल UPI intent/QR बनाता है।
- वास्तविक भुगतान के लिए अपने UPI ऐप में प्राप्तकर्ता का नाम और रकम जाँचें।
