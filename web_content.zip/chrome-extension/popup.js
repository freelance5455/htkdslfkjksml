const $=id=>document.getElementById(id);
async function settings(){const x=await chrome.storage.local.get(['api','token']);if(x.api)$('api').value=x.api;return x;}
function status(s){$('status').textContent=s;}
$('pair').addEventListener('click',async()=>{
 try{
  const api=$('api').value.replace(/\/+$/,'');const code=$('code').value.trim();
  const r=await fetch(api+'/api/chrome/pair',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({code})});
  const d=await r.json();if(!r.ok)throw new Error(d.error||'Falha no pareamento');
  await chrome.storage.local.set({api,token:d.token});$('code').value='';status('Conectado! Esta extensão agora pode salvar páginas que você selecionar.');
 }catch(e){status('Erro: '+e.message);}
});
$('clip').addEventListener('click',async()=>{
 try{
  const s=await settings();if(!s.token)throw new Error('Faça o pareamento primeiro.');
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tab?.id||!/^https?:/.test(tab.url||''))throw new Error('Abra uma página HTTP/HTTPS.');
  const [result]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>{
   const title=document.title||location.hostname;
   const main=document.querySelector('main,article,[role="main"]')||document.body;
   const content=(main.innerText||'').slice(0,120000);
   return {title,url:location.href,content};
  }});
  const page=result.result;if(!page.content.trim())throw new Error('Não encontrei texto legível nesta página.');
  const r=await fetch(s.api.replace(/\/+$/,'')+'/api/chrome/clip',{method:'POST',headers:{'Content-Type':'application/json','X-Chrome-Bridge-Token':s.token},body:JSON.stringify(page)});
  const d=await r.json();if(!r.ok)throw new Error(d.error||'Falha ao salvar');
  status('✓ '+d.message);
 }catch(e){status('Erro: '+e.message);}
});
$('disconnect').addEventListener('click',async()=>{await chrome.storage.local.remove(['token']);status('Token removido deste navegador. Para revogar no servidor, use a opção de revogação na conta.');});
settings();
