DRONE FLIGHT: ISLAND CHECKPOINT
===============================

HOW TO PLAY
1. Extract the ZIP file.
2. Open index.html in a modern browser (Chrome recommended).
3. Tap START FLIGHT.
4. Best played in landscape orientation.

CONTROLS
- On-screen arrows: steer left/right and forward/back
- + / -: climb / descend
- ⚡: hold for boost
- ●: hold for brake
- Keyboard: WASD or arrow keys; E/Q to climb/descend; Shift to boost; Space to brake; R to restart
- Pause button: pause/resume

This is a self-contained HTML5 Canvas game prototype. No external libraries or internet connection required.
