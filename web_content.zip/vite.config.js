import { defineConfig } from 'vite'

export default defineConfig({
  build: { cssMinify: false },
  server: {
    host: '0.0.0.0',
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:3001',
        changeOrigin: true
      }
    }
  }
})
