import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { createHash } from 'node:crypto';
import { existsSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join, relative, sep } from 'node:path';
import { defineConfig } from 'vite';

/**
 * Web/PWA build: after the build, list every file in dist/ and prepend the list
 * (plus a build hash) to dist/service-worker.js so the SW can precache the whole
 * game for offline play, including Vite's hashed JS/CSS bundles.
 */
function injectPrecacheManifest() {
  let outDir = 'dist';
  return {
    name: 'flapora-inject-precache-manifest',
    apply: 'build',
    configResolved(config) {
      outDir = config.build.outDir;
    },
    closeBundle() {
      const swPath = join(outDir, 'service-worker.js');
      if (!existsSync(swPath)) {
        console.warn('[pwa] dist/service-worker.js not found — is it in /public?');
        return;
      }
      const files = [];
      const walk = (dir) => {
        for (const name of readdirSync(dir)) {
          const full = join(dir, name);
          if (statSync(full).isDirectory()) walk(full);
          else files.push(full);
        }
      };
      walk(outDir);

      const urls = files
        .filter((f) => f !== swPath && !f.endsWith('.map'))
        .map((f) => '/' + relative(outDir, f).split(sep).join('/'))
        .sort();

      const hash = createHash('sha1');
      for (const f of files.filter((f) => f !== swPath).sort()) {
        hash.update(f);
        hash.update(readFileSync(f));
      }
      const version = hash.digest('hex').slice(0, 10);

      const precache = ['/', ...urls];
      const banner =
        `self.__CACHE_VERSION__ = ${JSON.stringify(version)};\n` +
        `self.__PRECACHE_URLS__ = ${JSON.stringify(precache)};\n`;
      writeFileSync(swPath, banner + readFileSync(swPath, 'utf8'));
      console.log(`[pwa] precaching ${precache.length} files, version ${version}`);
    },
  };
}

/**
 * APK build (`npm run build:apk`): the app is bundled inside the APK and opened from
 * local files, where ES-module scripts and `crossorigin` attributes are blocked and a
 * service worker can't run. So we output one classic script and clean up index.html.
 */
function apkHtmlFixes() {
  let outDir = 'dist-apk';
  return {
    name: 'flapora-apk-html-fixes',
    apply: 'build',
    configResolved(config) {
      outDir = config.build.outDir;
    },
    closeBundle() {
      const htmlPath = join(outDir, 'index.html');
      if (!existsSync(htmlPath)) return;
      let html = readFileSync(htmlPath, 'utf8');
      html = html
        .replace(/<link[^>]*rel="modulepreload"[^>]*>\s*/g, '')
        .replace(/<script\s+type="module"([^>]*)><\/script>/g, '<script defer$1></script>')
        .replace(/\s+crossorigin(="[^"]*")?/g, '');
      writeFileSync(htmlPath, html);
      rmSync(join(outDir, 'service-worker.js'), { force: true });
      console.log('[apk] index.html is ready for local files — zip the CONTENTS of', outDir);
    },
  };
}

export default defineConfig(({ mode }) => {
  const isApk = mode === 'apk';
  return {
    base: './',
    plugins: [react(), tailwindcss(), isApk ? apkHtmlFixes() : injectPrecacheManifest()],
    build: isApk
      ? {
          outDir: 'dist-apk',
          rollupOptions: { output: { format: 'iife', inlineDynamicImports: true } },
        }
      : {},
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
    },
  };
});
