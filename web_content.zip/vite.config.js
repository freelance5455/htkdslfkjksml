import { defineConfig } from 'vite';
export default defineConfig({
  base: './',
  build: { outDir: 'www', emptyOutDir: true, assetsDir: 'assets-built' },
  server: { host: '0.0.0.0', port: 5173 }
});
