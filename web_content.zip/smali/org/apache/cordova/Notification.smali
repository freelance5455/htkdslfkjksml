###### Class org.apache.cordova.Notification (org.apache.cordova.Notification)
.class public Lorg/apache/cordova/Notification;
.super Lorg/apache/cordova/api/Plugin;
.source "Notification.java"


# instance fields
.field public confirmResult:I

.field public progressDialog:Landroid/app/ProgressDialog;

.field public spinnerDialog:Landroid/app/ProgressDialog;


# direct methods
.method public constructor <init>()V
    .registers 3

    .prologue
    const/4 v1, 0x0

    .line 47
    invoke-direct {p0}, Lorg/apache/cordova/api/Plugin;-><init>()V

    .line 40
    const/4 v0, -0x1

    iput v0, p0, Lorg/apache/cordova/Notification;->confirmResult:I

    .line 41
    iput-object v1, p0, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;

    .line 42
    iput-object v1, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    .line 48
    return-void
.end method


# virtual methods
.method public declared-synchronized activityStart(Ljava/lang/String;Ljava/lang/String;)V
    .registers 9
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "message"    # Ljava/lang/String;

    .prologue
    .line 282
    monitor-enter p0

    :try_start_1
    iget-object v1, p0, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;

    if-eqz v1, :cond_d

    .line 283
    iget-object v1, p0, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v1}, Landroid/app/ProgressDialog;->dismiss()V

    .line 284
    const/4 v1, 0x0

    iput-object v1, p0, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;

    .line 286
    :cond_d
    move-object v2, p0

    .line 287
    .local v2, "notification":Lorg/apache/cordova/Notification;
    iget-object v3, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    .line 288
    .local v3, "cordova":Lorg/apache/cordova/api/CordovaInterface;
    new-instance v0, Lorg/apache/cordova/Notification$3;

    move-object v1, p0

    move-object v4, p1

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Lorg/apache/cordova/Notification$3;-><init>(Lorg/apache/cordova/Notification;Lorg/apache/cordova/Notification;Lorg/apache/cordova/api/CordovaInterface;Ljava/lang/String;Ljava/lang/String;)V

    .line 298
    .local v0, "runnable":Ljava/lang/Runnable;
    iget-object v1, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v1}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_21
    .catchall {:try_start_1 .. :try_end_21} :catchall_23

    .line 299
    monitor-exit p0

    return-void

    .line 282
    .end local v0    # "runnable":Ljava/lang/Runnable;
    .end local v2    # "notification":Lorg/apache/cordova/Notification;
    .end local v3    # "cordova":Lorg/apache/cordova/api/CordovaInterface;
    :catchall_23
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method public declared-synchronized activityStop()V
    .registers 2

    .prologue
    .line 305
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_d

    .line 306
    iget-object v0, p0, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->dismiss()V

    .line 307
    const/4 v0, 0x0

    iput-object v0, p0, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;
    :try_end_d
    .catchall {:try_start_1 .. :try_end_d} :catchall_f

    .line 309
    :cond_d
    monitor-exit p0

    return-void

    .line 305
    :catchall_f
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized alert(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 13
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "title"    # Ljava/lang/String;
    .param p3, "buttonLabel"    # Ljava/lang/String;
    .param p4, "callbackId"    # Ljava/lang/String;

    .prologue
    .line 187
    monitor-enter p0

    :try_start_1
    iget-object v2, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    .line 188
    .local v2, "cordova":Lorg/apache/cordova/api/CordovaInterface;
    move-object v6, p0

    .line 190
    .local v6, "notification":Lorg/apache/cordova/Notification;
    new-instance v0, Lorg/apache/cordova/Notification$1;

    move-object v1, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v7, p4

    invoke-direct/range {v0 .. v7}, Lorg/apache/cordova/Notification$1;-><init>(Lorg/apache/cordova/Notification;Lorg/apache/cordova/api/CordovaInterface;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/apache/cordova/Notification;Ljava/lang/String;)V

    .line 208
    .local v0, "runnable":Ljava/lang/Runnable;
    iget-object v1, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v1}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_17
    .catchall {:try_start_1 .. :try_end_17} :catchall_19

    .line 209
    monitor-exit p0

    return-void

    .line 187
    .end local v0    # "runnable":Ljava/lang/Runnable;
    .end local v2    # "cordova":Lorg/apache/cordova/api/CordovaInterface;
    .end local v6    # "notification":Lorg/apache/cordova/Notification;
    :catchall_19
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method public beep(J)V
    .registers 13
    .param p1, "count"    # J

    .prologue
    const-wide/16 v8, 0x64

    .line 145
    const/4 v6, 0x2

    invoke-static {v6}, Landroid/media/RingtoneManager;->getDefaultUri(I)Landroid/net/Uri;

    move-result-object v3

    .line 146
    .local v3, "ringtone":Landroid/net/Uri;
    iget-object v6, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v6}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v6

    invoke-virtual {v6}, Landroid/app/Activity;->getBaseContext()Landroid/content/Context;

    move-result-object v6

    invoke-static {v6, v3}, Landroid/media/RingtoneManager;->getRingtone(Landroid/content/Context;Landroid/net/Uri;)Landroid/media/Ringtone;

    move-result-object v2

    .line 149
    .local v2, "notification":Landroid/media/Ringtone;
    if-eqz v2, :cond_3b

    .line 150
    const-wide/16 v0, 0x0

    .local v0, "i":J
    :goto_19
    cmp-long v6, v0, p1

    if-gez v6, :cond_3b

    .line 151
    invoke-virtual {v2}, Landroid/media/Ringtone;->play()V

    .line 152
    const-wide/16 v4, 0x1388

    .line 153
    .local v4, "timeout":J
    :goto_22
    invoke-virtual {v2}, Landroid/media/Ringtone;->isPlaying()Z

    move-result v6

    if-eqz v6, :cond_37

    const-wide/16 v6, 0x0

    cmp-long v6, v4, v6

    if-lez v6, :cond_37

    .line 154
    sub-long/2addr v4, v8

    .line 156
    const-wide/16 v6, 0x64

    :try_start_31
    invoke-static {v6, v7}, Ljava/lang/Thread;->sleep(J)V
    :try_end_34
    .catch Ljava/lang/InterruptedException; {:try_start_31 .. :try_end_34} :catch_35

    goto :goto_22

    .line 157
    :catch_35
    move-exception v6

    goto :goto_22

    .line 150
    :cond_37
    const-wide/16 v6, 0x1

    add-long/2addr v0, v6

    goto :goto_19

    .line 162
    .end local v0    # "i":J
    .end local v4    # "timeout":J
    :cond_3b
    return-void
.end method

.method public declared-synchronized confirm(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 13
    .param p1, "message"    # Ljava/lang/String;
    .param p2, "title"    # Ljava/lang/String;
    .param p3, "buttonLabels"    # Ljava/lang/String;
    .param p4, "callbackId"    # Ljava/lang/String;

    .prologue
    .line 223
    monitor-enter p0

    :try_start_1
    iget-object v2, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    .line 224
    .local v2, "cordova":Lorg/apache/cordova/api/CordovaInterface;
    move-object v6, p0

    .line 225
    .local v6, "notification":Lorg/apache/cordova/Notification;
    const-string v1, ","

    invoke-virtual {p3, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    .line 227
    .local v5, "fButtons":[Ljava/lang/String;
    new-instance v0, Lorg/apache/cordova/Notification$2;

    move-object v1, p0

    move-object v3, p1

    move-object v4, p2

    move-object v7, p4

    invoke-direct/range {v0 .. v7}, Lorg/apache/cordova/Notification$2;-><init>(Lorg/apache/cordova/Notification;Lorg/apache/cordova/api/CordovaInterface;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lorg/apache/cordova/Notification;Ljava/lang/String;)V

    .line 272
    .local v0, "runnable":Ljava/lang/Runnable;
    iget-object v1, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v1}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_1c
    .catchall {:try_start_1 .. :try_end_1c} :catchall_1e

    .line 273
    monitor-exit p0

    return-void

    .line 223
    .end local v0    # "runnable":Ljava/lang/Runnable;
    .end local v2    # "cordova":Lorg/apache/cordova/api/CordovaInterface;
    .end local v5    # "fButtons":[Ljava/lang/String;
    .end local v6    # "notification":Lorg/apache/cordova/Notification;
    :catchall_1e
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method public execute(Ljava/lang/String;Lorg/json/JSONArray;Ljava/lang/String;)Lorg/apache/cordova/api/PluginResult;
    .registers 11
    .param p1, "action"    # Ljava/lang/String;
    .param p2, "args"    # Lorg/json/JSONArray;
    .param p3, "callbackId"    # Ljava/lang/String;

    .prologue
    .line 59
    sget-object v3, Lorg/apache/cordova/api/PluginResult$Status;->OK:Lorg/apache/cordova/api/PluginResult$Status;

    .line 60
    .local v3, "status":Lorg/apache/cordova/api/PluginResult$Status;
    const-string v2, ""

    .line 63
    .local v2, "result":Ljava/lang/String;
    :try_start_4
    const-string v4, "beep"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1a

    .line 64
    const/4 v4, 0x0

    invoke-virtual {p2, v4}, Lorg/json/JSONArray;->getLong(I)J

    move-result-wide v4

    invoke-virtual {p0, v4, v5}, Lorg/apache/cordova/Notification;->beep(J)V

    .line 96
    :cond_14
    :goto_14
    new-instance v1, Lorg/apache/cordova/api/PluginResult;

    invoke-direct {v1, v3, v2}, Lorg/apache/cordova/api/PluginResult;-><init>(Lorg/apache/cordova/api/PluginResult$Status;Ljava/lang/String;)V

    .line 98
    :goto_19
    return-object v1

    .line 66
    :cond_1a
    const-string v4, "vibrate"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_34

    .line 67
    const/4 v4, 0x0

    invoke-virtual {p2, v4}, Lorg/json/JSONArray;->getLong(I)J

    move-result-wide v4

    invoke-virtual {p0, v4, v5}, Lorg/apache/cordova/Notification;->vibrate(J)V
    :try_end_2a
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_2a} :catch_2b

    goto :goto_14

    .line 97
    :catch_2b
    move-exception v0

    .line 98
    .local v0, "e":Lorg/json/JSONException;
    new-instance v1, Lorg/apache/cordova/api/PluginResult;

    sget-object v4, Lorg/apache/cordova/api/PluginResult$Status;->JSON_EXCEPTION:Lorg/apache/cordova/api/PluginResult$Status;

    invoke-direct {v1, v4}, Lorg/apache/cordova/api/PluginResult;-><init>(Lorg/apache/cordova/api/PluginResult$Status;)V

    goto :goto_19

    .line 69
    .end local v0    # "e":Lorg/json/JSONException;
    :cond_34
    :try_start_34
    const-string v4, "alert"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_5a

    .line 70
    const/4 v4, 0x0

    invoke-virtual {p2, v4}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    invoke-virtual {p2, v5}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x2

    invoke-virtual {p2, v6}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p0, v4, v5, v6, p3}, Lorg/apache/cordova/Notification;->alert(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 71
    new-instance v1, Lorg/apache/cordova/api/PluginResult;

    sget-object v4, Lorg/apache/cordova/api/PluginResult$Status;->NO_RESULT:Lorg/apache/cordova/api/PluginResult$Status;

    invoke-direct {v1, v4}, Lorg/apache/cordova/api/PluginResult;-><init>(Lorg/apache/cordova/api/PluginResult$Status;)V

    .line 72
    .local v1, "r":Lorg/apache/cordova/api/PluginResult;
    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Lorg/apache/cordova/api/PluginResult;->setKeepCallback(Z)V

    goto :goto_19

    .line 75
    .end local v1    # "r":Lorg/apache/cordova/api/PluginResult;
    :cond_5a
    const-string v4, "confirm"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_80

    .line 76
    const/4 v4, 0x0

    invoke-virtual {p2, v4}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    invoke-virtual {p2, v5}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x2

    invoke-virtual {p2, v6}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {p0, v4, v5, v6, p3}, Lorg/apache/cordova/Notification;->confirm(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    .line 77
    new-instance v1, Lorg/apache/cordova/api/PluginResult;

    sget-object v4, Lorg/apache/cordova/api/PluginResult$Status;->NO_RESULT:Lorg/apache/cordova/api/PluginResult$Status;

    invoke-direct {v1, v4}, Lorg/apache/cordova/api/PluginResult;-><init>(Lorg/apache/cordova/api/PluginResult$Status;)V

    .line 78
    .restart local v1    # "r":Lorg/apache/cordova/api/PluginResult;
    const/4 v4, 0x1

    invoke-virtual {v1, v4}, Lorg/apache/cordova/api/PluginResult;->setKeepCallback(Z)V

    goto :goto_19

    .line 81
    .end local v1    # "r":Lorg/apache/cordova/api/PluginResult;
    :cond_80
    const-string v4, "activityStart"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_97

    .line 82
    const/4 v4, 0x0

    invoke-virtual {p2, v4}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    invoke-virtual {p2, v5}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v4, v5}, Lorg/apache/cordova/Notification;->activityStart(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_14

    .line 84
    :cond_97
    const-string v4, "activityStop"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_a4

    .line 85
    invoke-virtual {p0}, Lorg/apache/cordova/Notification;->activityStop()V

    goto/16 :goto_14

    .line 87
    :cond_a4
    const-string v4, "progressStart"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_bb

    .line 88
    const/4 v4, 0x0

    invoke-virtual {p2, v4}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v5, 0x1

    invoke-virtual {p2, v5}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {p0, v4, v5}, Lorg/apache/cordova/Notification;->progressStart(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_14

    .line 90
    :cond_bb
    const-string v4, "progressValue"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_cd

    .line 91
    const/4 v4, 0x0

    invoke-virtual {p2, v4}, Lorg/json/JSONArray;->getInt(I)I

    move-result v4

    invoke-virtual {p0, v4}, Lorg/apache/cordova/Notification;->progressValue(I)V

    goto/16 :goto_14

    .line 93
    :cond_cd
    const-string v4, "progressStop"

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_14

    .line 94
    invoke-virtual {p0}, Lorg/apache/cordova/Notification;->progressStop()V
    :try_end_d8
    .catch Lorg/json/JSONException; {:try_start_34 .. :try_end_d8} :catch_2b

    goto/16 :goto_14
.end method

.method public isSynch(Ljava/lang/String;)Z
    .registers 4
    .param p1, "action"    # Ljava/lang/String;

    .prologue
    const/4 v0, 0x1

    .line 109
    const-string v1, "alert"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_a

    .line 131
    :cond_9
    :goto_9
    return v0

    .line 112
    :cond_a
    const-string v1, "confirm"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    .line 115
    const-string v1, "activityStart"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    .line 118
    const-string v1, "activityStop"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    .line 121
    const-string v1, "progressStart"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    .line 124
    const-string v1, "progressValue"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    .line 127
    const-string v1, "progressStop"

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_9

    .line 131
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public declared-synchronized progressStart(Ljava/lang/String;Ljava/lang/String;)V
    .registers 9
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "message"    # Ljava/lang/String;

    .prologue
    .line 318
    monitor-enter p0

    :try_start_1
    iget-object v1, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    if-eqz v1, :cond_d

    .line 319
    iget-object v1, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v1}, Landroid/app/ProgressDialog;->dismiss()V

    .line 320
    const/4 v1, 0x0

    iput-object v1, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    .line 322
    :cond_d
    move-object v2, p0

    .line 323
    .local v2, "notification":Lorg/apache/cordova/Notification;
    iget-object v3, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    .line 324
    .local v3, "cordova":Lorg/apache/cordova/api/CordovaInterface;
    new-instance v0, Lorg/apache/cordova/Notification$4;

    move-object v1, p0

    move-object v4, p1

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Lorg/apache/cordova/Notification$4;-><init>(Lorg/apache/cordova/Notification;Lorg/apache/cordova/Notification;Lorg/apache/cordova/api/CordovaInterface;Ljava/lang/String;Ljava/lang/String;)V

    .line 342
    .local v0, "runnable":Ljava/lang/Runnable;
    iget-object v1, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v1}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    :try_end_21
    .catchall {:try_start_1 .. :try_end_21} :catchall_23

    .line 343
    monitor-exit p0

    return-void

    .line 318
    .end local v0    # "runnable":Ljava/lang/Runnable;
    .end local v2    # "notification":Lorg/apache/cordova/Notification;
    .end local v3    # "cordova":Lorg/apache/cordova/api/CordovaInterface;
    :catchall_23
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method public declared-synchronized progressStop()V
    .registers 2

    .prologue
    .line 360
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_d

    .line 361
    iget-object v0, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->dismiss()V

    .line 362
    const/4 v0, 0x0

    iput-object v0, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;
    :try_end_d
    .catchall {:try_start_1 .. :try_end_d} :catchall_f

    .line 364
    :cond_d
    monitor-exit p0

    return-void

    .line 360
    :catchall_f
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public declared-synchronized progressValue(I)V
    .registers 3
    .param p1, "value"    # I

    .prologue
    .line 351
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    if-eqz v0, :cond_a

    .line 352
    iget-object v0, p0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0, p1}, Landroid/app/ProgressDialog;->setProgress(I)V
    :try_end_a
    .catchall {:try_start_1 .. :try_end_a} :catchall_c

    .line 354
    :cond_a
    monitor-exit p0

    return-void

    .line 351
    :catchall_c
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public vibrate(J)V
    .registers 6
    .param p1, "time"    # J

    .prologue
    .line 171
    const-wide/16 v1, 0x0

    cmp-long v1, p1, v1

    if-nez v1, :cond_8

    .line 172
    const-wide/16 p1, 0x1f4

    .line 174
    :cond_8
    iget-object v1, p0, Lorg/apache/cordova/Notification;->cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v1}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v1

    const-string v2, "vibrator"

    invoke-virtual {v1, v2}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/os/Vibrator;

    .line 175
    .local v0, "vibrator":Landroid/os/Vibrator;
    invoke-virtual {v0, p1, p2}, Landroid/os/Vibrator;->vibrate(J)V

    .line 176
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass1 (org.apache.cordova.Notification$1)
.class Lorg/apache/cordova/Notification$1;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification;->alert(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/apache/cordova/Notification;

.field final synthetic val$buttonLabel:Ljava/lang/String;

.field final synthetic val$callbackId:Ljava/lang/String;

.field final synthetic val$cordova:Lorg/apache/cordova/api/CordovaInterface;

.field final synthetic val$message:Ljava/lang/String;

.field final synthetic val$notification:Lorg/apache/cordova/Notification;

.field final synthetic val$title:Ljava/lang/String;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification;Lorg/apache/cordova/api/CordovaInterface;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lorg/apache/cordova/Notification;Ljava/lang/String;)V
    .registers 8

    .prologue
    .line 190
    iput-object p1, p0, Lorg/apache/cordova/Notification$1;->this$0:Lorg/apache/cordova/Notification;

    iput-object p2, p0, Lorg/apache/cordova/Notification$1;->val$cordova:Lorg/apache/cordova/api/CordovaInterface;

    iput-object p3, p0, Lorg/apache/cordova/Notification$1;->val$message:Ljava/lang/String;

    iput-object p4, p0, Lorg/apache/cordova/Notification$1;->val$title:Ljava/lang/String;

    iput-object p5, p0, Lorg/apache/cordova/Notification$1;->val$buttonLabel:Ljava/lang/String;

    iput-object p6, p0, Lorg/apache/cordova/Notification$1;->val$notification:Lorg/apache/cordova/Notification;

    iput-object p7, p0, Lorg/apache/cordova/Notification$1;->val$callbackId:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .prologue
    .line 193
    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lorg/apache/cordova/Notification$1;->val$cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v1}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 194
    .local v0, "dlg":Landroid/app/AlertDialog$Builder;
    iget-object v1, p0, Lorg/apache/cordova/Notification$1;->val$message:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 195
    iget-object v1, p0, Lorg/apache/cordova/Notification$1;->val$title:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 196
    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 197
    iget-object v1, p0, Lorg/apache/cordova/Notification$1;->val$buttonLabel:Ljava/lang/String;

    new-instance v2, Lorg/apache/cordova/Notification$1$1;

    invoke-direct {v2, p0}, Lorg/apache/cordova/Notification$1$1;-><init>(Lorg/apache/cordova/Notification$1;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 204
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    .line 205
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 206
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass1.DialogInterfaceOnClickListenerC00011 (org.apache.cordova.Notification$1$1)
.class Lorg/apache/cordova/Notification$1$1;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification$1;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lorg/apache/cordova/Notification$1;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification$1;)V
    .registers 2

    .prologue
    .line 198
    iput-object p1, p0, Lorg/apache/cordova/Notification$1$1;->this$1:Lorg/apache/cordova/Notification$1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 7
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .prologue
    .line 200
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 201
    iget-object v0, p0, Lorg/apache/cordova/Notification$1$1;->this$1:Lorg/apache/cordova/Notification$1;

    iget-object v0, v0, Lorg/apache/cordova/Notification$1;->val$notification:Lorg/apache/cordova/Notification;

    new-instance v1, Lorg/apache/cordova/api/PluginResult;

    sget-object v2, Lorg/apache/cordova/api/PluginResult$Status;->OK:Lorg/apache/cordova/api/PluginResult$Status;

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3}, Lorg/apache/cordova/api/PluginResult;-><init>(Lorg/apache/cordova/api/PluginResult$Status;I)V

    iget-object v2, p0, Lorg/apache/cordova/Notification$1$1;->this$1:Lorg/apache/cordova/Notification$1;

    iget-object v2, v2, Lorg/apache/cordova/Notification$1;->val$callbackId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/apache/cordova/Notification;->success(Lorg/apache/cordova/api/PluginResult;Ljava/lang/String;)V

    .line 202
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass2 (org.apache.cordova.Notification$2)
.class Lorg/apache/cordova/Notification$2;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification;->confirm(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/apache/cordova/Notification;

.field final synthetic val$callbackId:Ljava/lang/String;

.field final synthetic val$cordova:Lorg/apache/cordova/api/CordovaInterface;

.field final synthetic val$fButtons:[Ljava/lang/String;

.field final synthetic val$message:Ljava/lang/String;

.field final synthetic val$notification:Lorg/apache/cordova/Notification;

.field final synthetic val$title:Ljava/lang/String;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification;Lorg/apache/cordova/api/CordovaInterface;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Lorg/apache/cordova/Notification;Ljava/lang/String;)V
    .registers 8

    .prologue
    .line 227
    iput-object p1, p0, Lorg/apache/cordova/Notification$2;->this$0:Lorg/apache/cordova/Notification;

    iput-object p2, p0, Lorg/apache/cordova/Notification$2;->val$cordova:Lorg/apache/cordova/api/CordovaInterface;

    iput-object p3, p0, Lorg/apache/cordova/Notification$2;->val$message:Ljava/lang/String;

    iput-object p4, p0, Lorg/apache/cordova/Notification$2;->val$title:Ljava/lang/String;

    iput-object p5, p0, Lorg/apache/cordova/Notification$2;->val$fButtons:[Ljava/lang/String;

    iput-object p6, p0, Lorg/apache/cordova/Notification$2;->val$notification:Lorg/apache/cordova/Notification;

    iput-object p7, p0, Lorg/apache/cordova/Notification$2;->val$callbackId:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 6

    .prologue
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 229
    new-instance v0, Landroid/app/AlertDialog$Builder;

    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v1}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 230
    .local v0, "dlg":Landroid/app/AlertDialog$Builder;
    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$message:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 231
    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$title:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    .line 232
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    .line 235
    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$fButtons:[Ljava/lang/String;

    array-length v1, v1

    if-lez v1, :cond_2c

    .line 236
    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$fButtons:[Ljava/lang/String;

    aget-object v1, v1, v2

    new-instance v2, Lorg/apache/cordova/Notification$2$1;

    invoke-direct {v2, p0}, Lorg/apache/cordova/Notification$2$1;-><init>(Lorg/apache/cordova/Notification$2;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 246
    :cond_2c
    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$fButtons:[Ljava/lang/String;

    array-length v1, v1

    if-le v1, v3, :cond_3d

    .line 247
    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$fButtons:[Ljava/lang/String;

    aget-object v1, v1, v3

    new-instance v2, Lorg/apache/cordova/Notification$2$2;

    invoke-direct {v2, p0}, Lorg/apache/cordova/Notification$2$2;-><init>(Lorg/apache/cordova/Notification$2;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 257
    :cond_3d
    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$fButtons:[Ljava/lang/String;

    array-length v1, v1

    if-le v1, v4, :cond_4e

    .line 258
    iget-object v1, p0, Lorg/apache/cordova/Notification$2;->val$fButtons:[Ljava/lang/String;

    aget-object v1, v1, v4

    new-instance v2, Lorg/apache/cordova/Notification$2$3;

    invoke-direct {v2, p0}, Lorg/apache/cordova/Notification$2$3;-><init>(Lorg/apache/cordova/Notification$2;)V

    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    .line 268
    :cond_4e
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    .line 269
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    .line 270
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass2.AnonymousClass1 (org.apache.cordova.Notification$2$1)
.class Lorg/apache/cordova/Notification$2$1;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification$2;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lorg/apache/cordova/Notification$2;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification$2;)V
    .registers 2

    .prologue
    .line 237
    iput-object p1, p0, Lorg/apache/cordova/Notification$2$1;->this$1:Lorg/apache/cordova/Notification$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 7
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .prologue
    .line 239
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 240
    iget-object v0, p0, Lorg/apache/cordova/Notification$2$1;->this$1:Lorg/apache/cordova/Notification$2;

    iget-object v0, v0, Lorg/apache/cordova/Notification$2;->val$notification:Lorg/apache/cordova/Notification;

    new-instance v1, Lorg/apache/cordova/api/PluginResult;

    sget-object v2, Lorg/apache/cordova/api/PluginResult$Status;->OK:Lorg/apache/cordova/api/PluginResult$Status;

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Lorg/apache/cordova/api/PluginResult;-><init>(Lorg/apache/cordova/api/PluginResult$Status;I)V

    iget-object v2, p0, Lorg/apache/cordova/Notification$2$1;->this$1:Lorg/apache/cordova/Notification$2;

    iget-object v2, v2, Lorg/apache/cordova/Notification$2;->val$callbackId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/apache/cordova/Notification;->success(Lorg/apache/cordova/api/PluginResult;Ljava/lang/String;)V

    .line 241
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass2.DialogInterfaceOnClickListenerC00022 (org.apache.cordova.Notification$2$2)
.class Lorg/apache/cordova/Notification$2$2;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification$2;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lorg/apache/cordova/Notification$2;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification$2;)V
    .registers 2

    .prologue
    .line 248
    iput-object p1, p0, Lorg/apache/cordova/Notification$2$2;->this$1:Lorg/apache/cordova/Notification$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 7
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .prologue
    .line 250
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 251
    iget-object v0, p0, Lorg/apache/cordova/Notification$2$2;->this$1:Lorg/apache/cordova/Notification$2;

    iget-object v0, v0, Lorg/apache/cordova/Notification$2;->val$notification:Lorg/apache/cordova/Notification;

    new-instance v1, Lorg/apache/cordova/api/PluginResult;

    sget-object v2, Lorg/apache/cordova/api/PluginResult$Status;->OK:Lorg/apache/cordova/api/PluginResult$Status;

    const/4 v3, 0x2

    invoke-direct {v1, v2, v3}, Lorg/apache/cordova/api/PluginResult;-><init>(Lorg/apache/cordova/api/PluginResult$Status;I)V

    iget-object v2, p0, Lorg/apache/cordova/Notification$2$2;->this$1:Lorg/apache/cordova/Notification$2;

    iget-object v2, v2, Lorg/apache/cordova/Notification$2;->val$callbackId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/apache/cordova/Notification;->success(Lorg/apache/cordova/api/PluginResult;Ljava/lang/String;)V

    .line 252
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass2.AnonymousClass3 (org.apache.cordova.Notification$2$3)
.class Lorg/apache/cordova/Notification$2$3;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification$2;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lorg/apache/cordova/Notification$2;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification$2;)V
    .registers 2

    .prologue
    .line 259
    iput-object p1, p0, Lorg/apache/cordova/Notification$2$3;->this$1:Lorg/apache/cordova/Notification$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 7
    .param p1, "dialog"    # Landroid/content/DialogInterface;
    .param p2, "which"    # I

    .prologue
    .line 261
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    .line 262
    iget-object v0, p0, Lorg/apache/cordova/Notification$2$3;->this$1:Lorg/apache/cordova/Notification$2;

    iget-object v0, v0, Lorg/apache/cordova/Notification$2;->val$notification:Lorg/apache/cordova/Notification;

    new-instance v1, Lorg/apache/cordova/api/PluginResult;

    sget-object v2, Lorg/apache/cordova/api/PluginResult$Status;->OK:Lorg/apache/cordova/api/PluginResult$Status;

    const/4 v3, 0x3

    invoke-direct {v1, v2, v3}, Lorg/apache/cordova/api/PluginResult;-><init>(Lorg/apache/cordova/api/PluginResult$Status;I)V

    iget-object v2, p0, Lorg/apache/cordova/Notification$2$3;->this$1:Lorg/apache/cordova/Notification$2;

    iget-object v2, v2, Lorg/apache/cordova/Notification$2;->val$callbackId:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/apache/cordova/Notification;->success(Lorg/apache/cordova/api/PluginResult;Ljava/lang/String;)V

    .line 263
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass3 (org.apache.cordova.Notification$3)
.class Lorg/apache/cordova/Notification$3;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification;->activityStart(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/apache/cordova/Notification;

.field final synthetic val$cordova:Lorg/apache/cordova/api/CordovaInterface;

.field final synthetic val$message:Ljava/lang/String;

.field final synthetic val$notification:Lorg/apache/cordova/Notification;

.field final synthetic val$title:Ljava/lang/String;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification;Lorg/apache/cordova/Notification;Lorg/apache/cordova/api/CordovaInterface;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .prologue
    .line 288
    iput-object p1, p0, Lorg/apache/cordova/Notification$3;->this$0:Lorg/apache/cordova/Notification;

    iput-object p2, p0, Lorg/apache/cordova/Notification$3;->val$notification:Lorg/apache/cordova/Notification;

    iput-object p3, p0, Lorg/apache/cordova/Notification$3;->val$cordova:Lorg/apache/cordova/api/CordovaInterface;

    iput-object p4, p0, Lorg/apache/cordova/Notification$3;->val$title:Ljava/lang/String;

    iput-object p5, p0, Lorg/apache/cordova/Notification$3;->val$message:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 8

    .prologue
    const/4 v3, 0x1

    .line 290
    iget-object v6, p0, Lorg/apache/cordova/Notification$3;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, p0, Lorg/apache/cordova/Notification$3;->val$cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v0}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v0

    iget-object v1, p0, Lorg/apache/cordova/Notification$3;->val$title:Ljava/lang/String;

    iget-object v2, p0, Lorg/apache/cordova/Notification$3;->val$message:Ljava/lang/String;

    new-instance v5, Lorg/apache/cordova/Notification$3$1;

    invoke-direct {v5, p0}, Lorg/apache/cordova/Notification$3$1;-><init>(Lorg/apache/cordova/Notification$3;)V

    move v4, v3

    invoke-static/range {v0 .. v5}, Landroid/app/ProgressDialog;->show(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;ZZLandroid/content/DialogInterface$OnCancelListener;)Landroid/app/ProgressDialog;

    move-result-object v0

    iput-object v0, v6, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;

    .line 296
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass3.AnonymousClass1 (org.apache.cordova.Notification$3$1)
.class Lorg/apache/cordova/Notification$3$1;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification$3;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lorg/apache/cordova/Notification$3;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification$3;)V
    .registers 2

    .prologue
    .line 291
    iput-object p1, p0, Lorg/apache/cordova/Notification$3$1;->this$1:Lorg/apache/cordova/Notification$3;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCancel(Landroid/content/DialogInterface;)V
    .registers 4
    .param p1, "dialog"    # Landroid/content/DialogInterface;

    .prologue
    .line 293
    iget-object v0, p0, Lorg/apache/cordova/Notification$3$1;->this$1:Lorg/apache/cordova/Notification$3;

    iget-object v0, v0, Lorg/apache/cordova/Notification$3;->val$notification:Lorg/apache/cordova/Notification;

    const/4 v1, 0x0

    iput-object v1, v0, Lorg/apache/cordova/Notification;->spinnerDialog:Landroid/app/ProgressDialog;

    .line 294
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass4 (org.apache.cordova.Notification$4)
.class Lorg/apache/cordova/Notification$4;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification;->progressStart(Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lorg/apache/cordova/Notification;

.field final synthetic val$cordova:Lorg/apache/cordova/api/CordovaInterface;

.field final synthetic val$message:Ljava/lang/String;

.field final synthetic val$notification:Lorg/apache/cordova/Notification;

.field final synthetic val$title:Ljava/lang/String;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification;Lorg/apache/cordova/Notification;Lorg/apache/cordova/api/CordovaInterface;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .prologue
    .line 324
    iput-object p1, p0, Lorg/apache/cordova/Notification$4;->this$0:Lorg/apache/cordova/Notification;

    iput-object p2, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iput-object p3, p0, Lorg/apache/cordova/Notification$4;->val$cordova:Lorg/apache/cordova/api/CordovaInterface;

    iput-object p4, p0, Lorg/apache/cordova/Notification$4;->val$title:Ljava/lang/String;

    iput-object p5, p0, Lorg/apache/cordova/Notification$4;->val$message:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 5

    .prologue
    const/4 v3, 0x1

    .line 326
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    new-instance v1, Landroid/app/ProgressDialog;

    iget-object v2, p0, Lorg/apache/cordova/Notification$4;->val$cordova:Lorg/apache/cordova/api/CordovaInterface;

    invoke-interface {v2}, Lorg/apache/cordova/api/CordovaInterface;->getActivity()Landroid/app/Activity;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/app/ProgressDialog;-><init>(Landroid/content/Context;)V

    iput-object v1, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    .line 327
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0, v3}, Landroid/app/ProgressDialog;->setProgressStyle(I)V

    .line 328
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    iget-object v1, p0, Lorg/apache/cordova/Notification$4;->val$title:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setTitle(Ljava/lang/CharSequence;)V

    .line 329
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    iget-object v1, p0, Lorg/apache/cordova/Notification$4;->val$message:Ljava/lang/String;

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setMessage(Ljava/lang/CharSequence;)V

    .line 330
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0, v3}, Landroid/app/ProgressDialog;->setCancelable(Z)V

    .line 331
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    const/16 v1, 0x64

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setMax(I)V

    .line 332
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setProgress(I)V

    .line 333
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    new-instance v1, Lorg/apache/cordova/Notification$4$1;

    invoke-direct {v1, p0}, Lorg/apache/cordova/Notification$4$1;-><init>(Lorg/apache/cordova/Notification$4;)V

    invoke-virtual {v0, v1}, Landroid/app/ProgressDialog;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V

    .line 339
    iget-object v0, p0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    iget-object v0, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    invoke-virtual {v0}, Landroid/app/ProgressDialog;->show()V

    .line 340
    return-void
.end method

###### Class org.apache.cordova.Notification.AnonymousClass4.AnonymousClass1 (org.apache.cordova.Notification$4$1)
.class Lorg/apache/cordova/Notification$4$1;
.super Ljava/lang/Object;
.source "Notification.java"

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lorg/apache/cordova/Notification$4;->run()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lorg/apache/cordova/Notification$4;


# direct methods
.method constructor <init>(Lorg/apache/cordova/Notification$4;)V
    .registers 2

    .prologue
    .line 334
    iput-object p1, p0, Lorg/apache/cordova/Notification$4$1;->this$1:Lorg/apache/cordova/Notification$4;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCancel(Landroid/content/DialogInterface;)V
    .registers 4
    .param p1, "dialog"    # Landroid/content/DialogInterface;

    .prologue
    .line 336
    iget-object v0, p0, Lorg/apache/cordova/Notification$4$1;->this$1:Lorg/apache/cordova/Notification$4;

    iget-object v0, v0, Lorg/apache/cordova/Notification$4;->val$notification:Lorg/apache/cordova/Notification;

    const/4 v1, 0x0

    iput-object v1, v0, Lorg/apache/cordova/Notification;->progressDialog:Landroid/app/ProgressDialog;

    .line 337
    return-void
.end method
