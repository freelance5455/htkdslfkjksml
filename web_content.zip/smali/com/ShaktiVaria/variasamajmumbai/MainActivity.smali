###### Class com.ShaktiVaria.variasamajmumbai.MainActivity (com.ShaktiVaria.variasamajmumbai.MainActivity)
.class public Lcom/ShaktiVaria/variasamajmumbai/MainActivity;
.super Lorg/apache/cordova/DroidGap;
.source "MainActivity.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 7
    invoke-direct {p0}, Lorg/apache/cordova/DroidGap;-><init>()V

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/os/Bundle;)V
    .registers 5
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    .line 10
    invoke-super {p0, p1}, Lorg/apache/cordova/DroidGap;->onCreate(Landroid/os/Bundle;)V

    .line 11
    invoke-virtual {p0}, Lcom/ShaktiVaria/variasamajmumbai/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x400

    .line 12
    const/16 v2, 0xc00

    .line 11
    invoke-virtual {v0, v1, v2}, Landroid/view/Window;->setFlags(II)V

    .line 14
    const-string v0, "splashscreen"

    const v1, 0x7f020001

    invoke-super {p0, v0, v1}, Lorg/apache/cordova/DroidGap;->setIntegerProperty(Ljava/lang/String;I)V

    .line 15
    const-string v0, "file:///android_asset/www/index.html"

    const/16 v1, 0xbb8

    invoke-super {p0, v0, v1}, Lorg/apache/cordova/DroidGap;->loadUrl(Ljava/lang/String;I)V

    .line 16
    return-void
.end method
