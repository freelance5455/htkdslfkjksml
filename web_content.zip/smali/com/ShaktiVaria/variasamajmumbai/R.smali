###### Class com.ShaktiVaria.variasamajmumbai.R (com.ShaktiVaria.variasamajmumbai.R)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/ShaktiVaria/variasamajmumbai/R$attr;,
        Lcom/ShaktiVaria/variasamajmumbai/R$dimen;,
        Lcom/ShaktiVaria/variasamajmumbai/R$drawable;,
        Lcom/ShaktiVaria/variasamajmumbai/R$id;,
        Lcom/ShaktiVaria/variasamajmumbai/R$layout;,
        Lcom/ShaktiVaria/variasamajmumbai/R$menu;,
        Lcom/ShaktiVaria/variasamajmumbai/R$string;,
        Lcom/ShaktiVaria/variasamajmumbai/R$style;,
        Lcom/ShaktiVaria/variasamajmumbai/R$xml;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.attr (com.ShaktiVaria.variasamajmumbai.R$attr)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.dimen (com.ShaktiVaria.variasamajmumbai.R$dimen)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$dimen;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static final activity_horizontal_margin:I = 0x7f050000

.field public static final activity_vertical_margin:I = 0x7f050001


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.drawable (com.ShaktiVaria.variasamajmumbai.R$drawable)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final ic_launcher:I = 0x7f020000

.field public static final splash:I = 0x7f020001


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 23
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.id (com.ShaktiVaria.variasamajmumbai.R$id)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final action_settings:I = 0x7f090000


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 27
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.layout (com.ShaktiVaria.variasamajmumbai.R$layout)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$layout;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final activity_main:I = 0x7f030000


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.menu (com.ShaktiVaria.variasamajmumbai.R$menu)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$menu;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "menu"
.end annotation


# static fields
.field public static final main:I = 0x7f080000


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.string (com.ShaktiVaria.variasamajmumbai.R$string)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$string;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final action_settings:I = 0x7f060001

.field public static final app_name:I = 0x7f060000

.field public static final hello_world:I = 0x7f060002


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.style (com.ShaktiVaria.variasamajmumbai.R$style)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$style;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final AppBaseTheme:I = 0x7f070000

.field public static final AppTheme:I = 0x7f070001


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 41
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

###### Class com.ShaktiVaria.variasamajmumbai.R.xml (com.ShaktiVaria.variasamajmumbai.R$xml)
.class public final Lcom/ShaktiVaria/variasamajmumbai/R$xml;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ShaktiVaria/variasamajmumbai/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static final config:I = 0x7f040000


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 69
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
