###### Class com.phonegap.api.LOG (com.phonegap.api.LOG)
.class public Lcom/phonegap/api/LOG;
.super Lorg/apache/cordova/api/LOG;
.source "LOG.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 27
    invoke-direct {p0}, Lorg/apache/cordova/api/LOG;-><init>()V

    return-void
.end method
