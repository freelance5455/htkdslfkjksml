###### Class com.phonegap.api.Plugin (com.phonegap.api.Plugin)
.class public abstract Lcom/phonegap/api/Plugin;
.super Lorg/apache/cordova/api/Plugin;
.source "Plugin.java"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 26
    invoke-direct {p0}, Lorg/apache/cordova/api/Plugin;-><init>()V

    return-void
.end method
