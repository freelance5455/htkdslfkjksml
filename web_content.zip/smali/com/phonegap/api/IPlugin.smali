###### Class com.phonegap.api.IPlugin (com.phonegap.api.IPlugin)
.class public interface abstract Lcom/phonegap/api/IPlugin;
.super Ljava/lang/Object;
.source "IPlugin.java"

# interfaces
.implements Lorg/apache/cordova/api/IPlugin;
