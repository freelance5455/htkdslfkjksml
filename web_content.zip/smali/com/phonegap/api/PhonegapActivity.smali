###### Class com.phonegap.api.PhonegapActivity (com.phonegap.api.PhonegapActivity)
.class public abstract Lcom/phonegap/api/PhonegapActivity;
.super Landroid/app/Activity;
.source "PhonegapActivity.java"

# interfaces
.implements Lorg/apache/cordova/api/CordovaInterface;


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 27
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method
