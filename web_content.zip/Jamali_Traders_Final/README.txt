JAMALI TRADERS - BILL PHOTO UPLOAD VERSION

ANDROID / CHROME USE
1. Extract the ZIP.
2. Open index.html using Google Chrome (not the old installed APK/WebView).
3. Open New Bill.
4. Tap Camera to take a new bill photo, or Gallery to choose an existing photo.
5. Wait for “تصویر کامیابی سے لگ گئی ✓” and check the preview.
6. Enter bill details and tap Save Bill.
7. In Party Khata, tap “تصویر دیکھیں” to open the saved bill image.

IMPORTANT
- This is an offline browser web app package, not an APK installer.
- Android WebView APKs need native WebChromeClient.onShowFileChooser support and camera/media permissions. This HTML ZIP cannot repair an already-installed APK by itself.
- If camera does not open, open this page directly in Google Chrome and allow camera/files permission. The Gallery button should still let you select an image.
- Data is stored in this browser on this device. Use Dashboard > Backup Download regularly.
- Bill text is not OCR-read automatically; enter weights and amounts manually.
