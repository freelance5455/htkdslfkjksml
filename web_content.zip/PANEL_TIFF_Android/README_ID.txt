PANEL TIFF - PROYEK ANDROID (WebView + Floating Bubble)

ISI
- app/src/main/assets/index.html : tampilan PANEL TIFF V6
- app/src/main/assets/panel_tiff_profile.png : gambar profil/logo
- MainActivity.java : membuka HTML di Android WebView
- BubbleService.java : ikon lingkaran mengambang di atas layar Android

CARA BUILD DARI HP VIVO
1. Pasang aplikasi AndroidIDE dari sumber resminya jika tersedia untuk perangkat Anda.
   Jika AndroidIDE tidak tersedia/kompatibel, proyek ini bisa dibuka di Android Studio pada komputer.
2. Ekstrak PANEL_TIFF_Android_Project.zip ke folder penyimpanan HP.
3. Di AndroidIDE pilih Open Project, lalu pilih folder PANEL_TIFF_Android (folder yang berisi settings.gradle).
4. Tunggu Gradle Sync. Jika diminta, pasang JDK 17 dan Android SDK Platform 35 / Build Tools yang diminta IDE.
5. Pilih Build > Assemble Debug (nama menu bisa sedikit berbeda menurut versi IDE).
6. APK debug biasanya dibuat di:
   app/build/outputs/apk/debug/app-debug.apk
7. Buka file APK tersebut dan izinkan pemasangan dari sumber ini jika Android meminta.

CARA PAKAI
1. Buka PANEL TIFF.
2. Login: username 1, password 1234.
3. Tekan CLOSE pada panel.
4. Saat Android meminta izin "Tampil di atas aplikasi lain", buka pengaturan dan izinkan PANEL TIFF.
5. Kembali ke aplikasi. Lingkaran profil PANEL TIFF akan muncul di atas layar.
6. Seret lingkaran untuk memindahkan. Ketuk lingkaran untuk membuka panel.
7. Tekan X kecil pada lingkaran untuk menghapusnya.

CATATAN PENTING
- Ini adalah proyek sumber, bukan APK yang sudah dikompilasi. Build Android membutuhkan Android SDK/JDK melalui AndroidIDE atau Android Studio.
- Fitur toggle AIM/PRESET/ANTIBAN di HTML hanya mengubah tampilan. Proyek ini tidak memodifikasi Free Fire, tidak memberi aim lock/cheat, tidak melewati anti-cheat, dan tidak menyediakan VPN atau bypass.
- Tulisan ONLINE adalah indikator visual lokal, bukan status server.
- Masa 7 hari pada HTML dihitung dari pembukaan pertama di penyimpanan browser/WebView. Ini bukan lisensi server yang aman; menghapus data aplikasi dapat mengatur ulang penghitung.
- Floating bubble membutuhkan izin khusus Android "Tampil di atas aplikasi lain". Pengguna dapat mencabut izin kapan saja.
- Jika proses dihentikan oleh penghemat baterai Vivo, buka kembali aplikasi. Jangan menonaktifkan perlindungan sistem secara luas.
