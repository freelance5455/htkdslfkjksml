package com.paneltiff.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean pendingOpenPanel = false;
    private static final int OVERLAY_REQUEST = 721;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF08060B);
        getWindow().setNavigationBarColor(0xFF08060B);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF050408);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (pendingOpenPanel) {
                    pendingOpenPanel = false;
                    view.evaluateJavascript("window.reopenPanelFromNative && window.reopenPanelFromNative()", null);
                }
            }
        });
        webView.addJavascriptInterface(new PanelBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        if (getIntent() != null && getIntent().getBooleanExtra("open_panel", false)) {
            pendingOpenPanel = true;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra("open_panel", false)) {
            pendingOpenPanel = true;
            if (webView != null) {
                webView.evaluateJavascript("window.reopenPanelFromNative && window.reopenPanelFromNative()", null);
                pendingOpenPanel = false;
            }
        }
    }

    private class PanelBridge {
        @JavascriptInterface
        public void showBubble() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "Izinkan PANEL TIFF tampil di atas aplikasi lain.", Toast.LENGTH_LONG).show();
                    Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivityForResult(permission, OVERLAY_REQUEST);
                    return;
                }
                Intent service = new Intent(MainActivity.this, BubbleService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundServiceCompat(service);
                else startService(service);
                moveTaskToBack(true);
            });
        }

        @JavascriptInterface
        public void hideBubble() {
            stopService(new Intent(MainActivity.this, BubbleService.class));
        }
    }

    private void startForegroundServiceCompat(Intent service) {
        // This app's overlay service is intentionally a normal, short-lived service.
        // Starting it while the activity is visible is supported on Android versions
        // targeted by this project; it does not run a background game-modification task.
        startService(service);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQUEST) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                startService(new Intent(this, BubbleService.class));
                moveTaskToBack(true);
            } else {
                Toast.makeText(this, "Izin overlay belum diberikan. Panel tetap bisa dipakai di aplikasi.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
