package com.paneltiff.app;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class BubbleService extends Service {
    private WindowManager windowManager;
    private View bubbleView;
    private WindowManager.LayoutParams params;
    private float downX, downY;
    private int startX, startY;
    private boolean moved;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildBubble();
    }

    private void buildBubble() {
        FrameLayout wrap = new FrameLayout(this);
        int size = dp(66);
        wrap.setLayoutParams(new FrameLayout.LayoutParams(size, size));

        ImageView avatar = new ImageView(this);
        avatar.setImageResource(R.drawable.panel_tiff_icon);
        avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(0xFF17101E);
        circle.setStroke(dp(2), 0xFFE45BFF);
        avatar.setBackground(circle);
        avatar.setClipToOutline(true);
        FrameLayout.LayoutParams imageParams = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.CENTER);
        wrap.addView(avatar, imageParams);

        TextView close = new TextView(this);
        close.setText("×");
        close.setTextColor(0xFFFFFFFF);
        close.setTextSize(13);
        close.setGravity(Gravity.CENTER);
        GradientDrawable closeBg = new GradientDrawable();
        closeBg.setShape(GradientDrawable.OVAL);
        closeBg.setColor(0xFF2B2330);
        closeBg.setStroke(dp(1), 0xFFFFFFFF);
        close.setBackground(closeBg);
        FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP | Gravity.RIGHT);
        wrap.addView(close, closeParams);
        close.setOnClickListener(v -> stopSelf());

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
                size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(18);
        params.y = dp(260);

        wrap.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    startX = params.x;
                    startY = params.y;
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int dx = (int) (event.getRawX() - downX);
                    int dy = (int) (event.getRawY() - downY);
                    if (Math.abs(dx) + Math.abs(dy) > dp(5)) moved = true;
                    if (moved) {
                        params.x = Math.max(0, startX + dx);
                        params.y = Math.max(0, startY + dy);
                        windowManager.updateViewLayout(wrap, params);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) openPanel();
                    return true;
            }
            return false;
        });

        bubbleView = wrap;
        try { windowManager.addView(bubbleView, params); }
        catch (Exception e) { stopSelf(); }
    }

    private void openPanel() {
        Intent launch = new Intent(this, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        launch.putExtra("open_panel", true);
        startActivity(launch);
        stopSelf();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override public void onDestroy() {
        if (bubbleView != null && windowManager != null) {
            try { windowManager.removeView(bubbleView); } catch (Exception ignored) {}
            bubbleView = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
