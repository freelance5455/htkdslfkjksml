# MDCAT/NUMS Prep deployment checklist

## Backend
1. Deploy the `backend` folder on an HTTPS Node.js host.
2. Configure the variables in `.env.example`.
3. Run `npm install` and `npm start`.
4. Confirm `/health` works.
5. Use a managed database before significant production traffic.
6. Set up backups and monitoring.

## Google Play
1. Create the app in Play Console using package `com.mdcatnums.prep`.
2. Create the three subscriptions:
   - `premium_monthly`
   - `premium_3months`
   - `premium_yearly`
3. Configure base plans and prices.
4. Add test accounts.
5. Upload a signed AAB to an internal/closed testing track.
6. Test purchase, restore, cancellation, renewal and expiry.
7. Configure Google Cloud Pub/Sub for Real-time Developer Notifications (RTDN) and connect it to `/api/play/rtdn`.
8. Complete the Play Console store listing, privacy policy, app-content and data-safety requirements.
9. Publish only after the complete purchase lifecycle is tested.

## Android
1. Copy `config.example.js` to `config.js`.
2. Put your HTTPS backend URL into `config.js`.
3. Build a signed AAB.
4. Test login, progress sync and Premium on a Play test track.
5. Never put Google Cloud service-account credentials in the APK.

## Important
The backend must be the source of truth for Premium entitlement. Do not rely on localStorage alone for paid access.
