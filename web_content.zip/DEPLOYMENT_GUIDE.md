# ANONYMOUX STUDIO 2.3.1 — deployment guide

## Important release note

This is a candidate remediation package. The source audit report was not supplied and database/provider/browser integration tests are blocked in the build environment. Deploy to staging first; do not treat this package as production-certified until the blocked checks are completed.

## Requirements

- PHP 8.1+ recommended.
- Enable `PDO` and one database driver: `pdo_sqlite` or `pdo_mysql`.
- Enable `curl`, `fileinfo`, `openssl`; `mbstring` recommended.
- HTTPS certificate and an HTTPS-aware hosting proxy.
- Existing Decart and Fish Audio credentials configured privately as required by the existing application.
- PHP write access to `storage/`.

## Upgrade procedure

1. Back up the complete current application directory, `storage/` (including SQLite database and private media), and `config.local.php`.
2. Upload and extract the complete `ANONYMOUX_STUDIO_2.3.1_PRODUCTION.zip` into a staging directory first.
3. Preserve the existing production `config.local.php`; do not replace it with the example file and do not copy provider secrets into public web files.
4. Compare the existing configuration with `config.local.example.php`. Add optional settings only if desired:
   - `force_https` (default `true`)
   - `max_storage_per_user_bytes` (default 1 GiB)
   - `video_job_timeout_seconds` (default 7200 seconds)
5. Ensure the `storage/` directory and its subdirectories are writable by PHP (typically `750` or `770`; do not use `777` unless the host explicitly requires it).
6. Ensure `storage/.htaccess` remains present and that Nginx deployments have equivalent deny rules for storage and `config.local.php`.
7. Keep `force_https` enabled in production. For local development, localhost is automatically exempt from the HTTPS redirect.
8. Run the application smoke tests with real staging accounts and provider credentials. Confirm the Decart scoped-token endpoint, realtime session start/stop, image generation, video job submission/polling and Fish Audio TTS before promoting.
9. Verify account A cannot access account B's assets, jobs, references, prompts, or sessions using altered IDs and the same browser.
10. Verify voice debit/refund and retry behavior against a disposable staging wallet before production use.

## Database and migration notes

- The application retains its existing PDO/SQLite-or-MySQL initialization and schema ownership.
- No production database reset is included or required by this package.
- The first successful login binds legacy browser-owner records held by that session to the authenticated account. Back up database and storage before first login after upgrade.
- No destructive migration is included in this package.
- Validate the existing schema on a copy of production data before promotion.

## Storage permissions and limits

- Keep storage outside direct public access where possible; the bundled `storage/.htaccess` denies HTTP access.
- PHP must write to `storage/`, `storage/platform/`, `storage/references/`, and `storage/voice-audio/` as required by the existing features.
- Default platform per-account quota: 1 GiB.
- Default maximum image upload: 15 MiB; video: 100 MiB; reference: 5 MiB. Hosting `upload_max_filesize` and `post_max_size` must be configured high enough to permit the intended uploads.
- The quota is applied to platform image/video uploads; complete retention/cleanup for every historic media class remains a documented limitation.

## Rollback

1. Put the site into maintenance mode or restrict access.
2. Restore the complete pre-upgrade application backup.
3. Restore the matching `storage/` backup and the original private `config.local.php`.
4. Restore the database backup only if the new version has already changed data and the pre-upgrade database must be reinstated. Do not restore an old database over newer production transactions without an explicit recovery decision.
5. Re-test login and provider integrations before reopening access.

## Production security checklist

- [ ] HTTPS works at the origin and through the hosting proxy.
- [ ] `config.local.php` and storage paths are inaccessible over HTTP.
- [ ] Existing API keys are present only in private server configuration/admin key storage.
- [ ] PHP `pdo_sqlite` or `pdo_mysql`, `curl`, `fileinfo`, and `openssl` are enabled.
- [ ] Database and storage backups completed.
- [ ] Two-account ownership and account-switching tests passed.
- [ ] CSRF and login throttling tests passed.
- [ ] Wallet duplicate-charge, refund and concurrent-spend tests passed.
- [ ] Real Decart and Fish Audio staging integrations passed.
- [ ] Video timeout and failure-state tests passed.
- [ ] Mobile layout and browser console checks passed.
- [ ] Retention policy for all storage classes is configured and verified.
