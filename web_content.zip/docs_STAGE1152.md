# CPLS V2 — Stage 1152
## LBank Capability Detection
- Native market payload now reports source and candle capability metadata.
- WebView exposes `window.__cpFuturesCapabilities` for diagnostics.
- No undocumented Futures WebSocket subscription is invented.
