"use strict";

/* =========================================================
   MUEEN — NOTIFICATION MANAGER
   تذكير بموعد الحصة القادمة

   القواعد:
   - إشعار واحد فقط لكل حصة.
   - الافتراضي: 15 دقيقة قبل الحصة.
   - الخيارات:
     5 / 10 / 15 / 20 / 30 / 45 / 60 دقيقة.
   - لا إشعار للحصص الفارغة.
   - يجب أن تكون المادة والصف/الفصل محددين.
   - لا توجد إشعارات للطابور.
   - لا توجد إشعارات عند بداية الحصة.
   - لا توجد إشعارات عند انتهاء الحصة.
   - يستخدم أوقات الحصص المحفوظة فعليًا في الجدول.
   - متوافق مع بنية schedule.js الحالية.
========================================================= */

(function () {

    /* =====================================================
       STORAGE KEYS
    ===================================================== */

    const STORAGE = {
        notifications:
            "mueen_notification_settings",

        schedule:
            "mueen_schedule_current",

        scheduleSettings:
            "mueen_schedule_settings"
    };


    /* =====================================================
       DEFAULT SETTINGS
    ===================================================== */

    const DEFAULT_SETTINGS = {
        enabled: false,
        reminderMinutes: 15
    };


    /* =====================================================
       DAYS
    ===================================================== */

    const DAYS = [
        {
            id: "sunday",
            name: "الأحد"
        },
        {
            id: "monday",
            name: "الإثنين"
        },
        {
            id: "tuesday",
            name: "الثلاثاء"
        },
        {
            id: "wednesday",
            name: "الأربعاء"
        },
        {
            id: "thursday",
            name: "الخميس"
        }
    ];


    /* =====================================================
       SAFE JSON
    ===================================================== */

    function readJSON(
        key,
        fallback
    ) {

        try {

            const raw =
                localStorage.getItem(
                    key
                );

            if (!raw) {
                return fallback;
            }

            const parsed =
                JSON.parse(raw);

            return parsed ?? fallback;

        } catch (error) {

            console.warn(
                "MUEEN notification manager:",
                error
            );

            return fallback;
        }
    }


    /* =====================================================
       GET NOTIFICATION SETTINGS
    ===================================================== */

    function getNotificationSettings() {

        const saved =
            readJSON(
                STORAGE.notifications,
                DEFAULT_SETTINGS
            );

        return {

            enabled:
                saved &&
                saved.enabled === true,

            reminderMinutes:
                normalizeReminderMinutes(
                    saved
                        ? saved.reminderMinutes
                        : DEFAULT_SETTINGS.reminderMinutes
                )
        };
    }


    /* =====================================================
       SAVE NOTIFICATION SETTINGS
    ===================================================== */

    function saveNotificationSettings(
        settings
    ) {

        settings =
            settings || {};

        const safeSettings = {

            enabled:
                settings.enabled === true,

            reminderMinutes:
                normalizeReminderMinutes(
                    settings.reminderMinutes
                )
        };

        try {

            localStorage.setItem(
                STORAGE.notifications,
                JSON.stringify(
                    safeSettings
                )
            );

        } catch (error) {

            console.warn(
                "Unable to save MUEEN notification settings:",
                error
            );
        }
    }


    /* =====================================================
       NORMALIZE REMINDER MINUTES
    ===================================================== */

    function normalizeReminderMinutes(
        value
    ) {

        const allowed = [
            5,
            10,
            15,
            20,
            30,
            45,
            60
        ];

        const number =
            Number(value);

        if (
            allowed.includes(
                number
            )
        ) {

            return number;
        }

        return 15;
    }


    /* =====================================================
       GET SCHEDULE
    ===================================================== */

    function getSchedule() {

        const schedule =
            readJSON(
                STORAGE.schedule,
                null
            );

        if (
            !schedule ||
            typeof schedule !== "object"
        ) {

            return null;
        }

        if (
            !Array.isArray(
                schedule.columns
            )
        ) {

            return null;
        }

        if (
            !schedule.assignments ||
            typeof schedule.assignments !== "object"
        ) {

            schedule.assignments = {};
        }

        return schedule;
    }


    /* =====================================================
       GET SCHEDULE SETTINGS
    ===================================================== */

    function getScheduleSettings() {

        const settings =
            readJSON(
                STORAGE.scheduleSettings,
                null
            );

        if (
            !settings ||
            typeof settings !== "object"
        ) {

            return null;
        }

        return settings;
    }


    /* =====================================================
       GET TODAY
    ===================================================== */

    function getTodayDay() {

        const dayNumber =
            new Date().getDay();

        /*
            JavaScript:
            0 = Sunday
            1 = Monday
            2 = Tuesday
            3 = Wednesday
            4 = Thursday
            5 = Friday
            6 = Saturday
        */

        if (
            dayNumber < 0 ||
            dayNumber > 4
        ) {

            return null;
        }

        return DAYS[
            dayNumber
        ];
    }


    /* =====================================================
       GET DATE KEY
    ===================================================== */

    function getTodayKey() {

        const now =
            new Date();

        const year =
            now.getFullYear();

        const month =
            String(
                now.getMonth() + 1
            ).padStart(
                2,
                "0"
            );

        const day =
            String(
                now.getDate()
            ).padStart(
                2,
                "0"
            );

        return (
            `${year}-${month}-${day}`
        );
    }


    /* =====================================================
       TIME TO MINUTES
    ===================================================== */

    function timeToMinutes(
        time
    ) {

        if (
            typeof time !== "string" ||
            !time.includes(":")
        ) {

            return null;
        }

        const parts =
            time.split(":");

        if (
            parts.length < 2
        ) {

            return null;
        }

        const hours =
            Number(
                parts[0]
            );

        const minutes =
            Number(
                parts[1]
            );

        if (
            !Number.isFinite(hours) ||
            !Number.isFinite(minutes)
        ) {

            return null;
        }

        if (
            hours < 0 ||
            hours > 23 ||
            minutes < 0 ||
            minutes > 59
        ) {

            return null;
        }

        return (
            hours * 60 +
            minutes
        );
    }


    /* =====================================================
       BUILD TODAY DATETIME
    ===================================================== */

    function buildTodayDate(
        time
    ) {

        const minutes =
            timeToMinutes(
                time
            );

        if (
            minutes === null
        ) {

            return null;
        }

        const now =
            new Date();

        const date =
            new Date(
                now.getFullYear(),
                now.getMonth(),
                now.getDate(),
                0,
                0,
                0,
                0
            );

        date.setMinutes(
            minutes
        );

        return date;
    }


    /* =====================================================
       FORMAT 12-HOUR TIME
    ===================================================== */

    function formatArabicTime(
        time
    ) {

        const minutes =
            timeToMinutes(
                time
            );

        if (
            minutes === null
        ) {

            return "";
        }

        let hours =
            Math.floor(
                minutes / 60
            );

        const mins =
            minutes % 60;

        const suffix =
            hours >= 12
                ? "م"
                : "ص";

        hours =
            hours % 12;

        if (
            hours === 0
        ) {

            hours = 12;
        }

        return (
            `${hours}:` +
            `${String(mins).padStart(2, "0")} ` +
            suffix
        );
    }


    /* =====================================================
       GET LESSON COLUMNS
    ===================================================== */

    function getLessonColumns(
        schedule
    ) {

        if (
            !schedule ||
            !Array.isArray(
                schedule.columns
            )
        ) {

            return [];
        }

        return schedule.columns

            .filter(
                function (column) {

                    return (
                        column &&
                        column.type === "lesson"
                    );
                }
            )

            .filter(
                function (column) {

                    return (
                        typeof column.start === "string" &&
                        timeToMinutes(
                            column.start
                        ) !== null
                    );
                }
            )

            .filter(
                function (column) {

                    return (
                        typeof column.end === "string" &&
                        timeToMinutes(
                            column.end
                        ) !== null
                    );
                }
            );
    }


    /* =====================================================
       GET ASSIGNMENT
    ===================================================== */

    function getLessonAssignment(
        schedule,
        dayId,
        columnId
    ) {

        if (
            !schedule ||
            !schedule.assignments ||
            typeof schedule.assignments !== "object" ||
            !dayId ||
            !columnId
        ) {

            return {
                subject: "",
                className: ""
            };
        }

        const key =
            `${dayId}__${columnId}`;

        const assignment =
            schedule.assignments[
                key
            ];

        if (
            !assignment ||
            typeof assignment !== "object"
        ) {

            return {
                subject: "",
                className: ""
            };
        }

        return {

            subject:
                typeof assignment.subject === "string"
                    ? assignment.subject.trim()
                    : "",

            className:
                typeof assignment.className === "string"
                    ? assignment.className.trim()
                    : ""
        };
    }


    /* =====================================================
       IS LESSON READY FOR NOTIFICATION
    ===================================================== */

    function isLessonReadyForNotification(
        lesson
    ) {

        if (!lesson) {
            return false;
        }

        const subject =
            typeof lesson.subject === "string"
                ? lesson.subject.trim()
                : "";

        const className =
            typeof lesson.className === "string"
                ? lesson.className.trim()
                : "";

        /*
            لا نرسل أي إشعار للحصة الفارغة.

            يجب وجود:
            1. المادة
            2. الصف / الفصل
        */

        return (
            subject.length > 0 &&
            className.length > 0
        );
    }


    /* =====================================================
       GET TODAY LESSONS
    ===================================================== */

    function getTodayLessons() {

        const today =
            getTodayDay();

        if (!today) {
            return [];
        }

        const schedule =
            getSchedule();

        if (!schedule) {
            return [];
        }

        /*
            نحافظ على جميع الحصص
            الموجودة في الجدول.

            لا نحذف الحصص الفارغة
            من حساب التوقيت.

            لكن الحصة الفارغة لا تدخل
            في قائمة الحصص القابلة
            لإرسال إشعار.
        */

        const columns =
            getLessonColumns(
                schedule
            );

        return columns.map(
            function (column) {

                const assignment =
                    getLessonAssignment(
                        schedule,
                        today.id,
                        column.id
                    );

                return {

                    id:
                        column.id,

                    name:
                        typeof column.name === "string"
                            ? column.name.trim()
                            : "",

                    start:
                        column.start,

                    end:
                        column.end,

                    subject:
                        assignment.subject,

                    className:
                        assignment.className,

                    notificationReady:
                        (
                            assignment.subject.length > 0 &&
                            assignment.className.length > 0
                        )
                };
            }
        );
    }


    /* =====================================================
       GET NOTIFIABLE LESSONS
    ===================================================== */

    function getNotifiableLessons() {

        return getTodayLessons()
            .filter(
                function (lesson) {

                    return isLessonReadyForNotification(
                        lesson
                    );
                }
            );
    }


    /* =====================================================
       GET CURRENT LESSON
    ===================================================== */

    function getCurrentLesson() {

        const lessons =
            getTodayLessons();

        if (
            !lessons.length
        ) {

            return null;
        }

        const now =
            new Date();

        const currentMinutes =
            now.getHours() * 60 +
            now.getMinutes();

        for (
            let i = 0;
            i < lessons.length;
            i++
        ) {

            const lesson =
                lessons[i];

            const start =
                timeToMinutes(
                    lesson.start
                );

            const end =
                timeToMinutes(
                    lesson.end
                );

            if (
                start === null ||
                end === null
            ) {

                continue;
            }

            if (
                currentMinutes >= start &&
                currentMinutes < end
            ) {

                return lesson;
            }
        }

        return null;
    }


    /* =====================================================
       GET NEXT LESSON
    ===================================================== */

    function getNextLesson() {

        const lessons =
            getTodayLessons();

        if (
            !lessons.length
        ) {

            return null;
        }

        const now =
            new Date();

        const currentMinutes =
            now.getHours() * 60 +
            now.getMinutes();

        for (
            let i = 0;
            i < lessons.length;
            i++
        ) {

            const lesson =
                lessons[i];

            const start =
                timeToMinutes(
                    lesson.start
                );

            if (
                start === null
            ) {

                continue;
            }

            /*
                أول حصة لم تبدأ بعد.

                مهم:
                الحصة الفارغة لا تُحذف من
                ترتيب اليوم، وبالتالي لا تؤثر
                على التوقيت أو ترتيب الحصص.
            */

            if (
                start > currentMinutes
            ) {

                return lesson;
            }
        }

        return null;
    }


    /* =====================================================
       GET NEXT NOTIFIABLE LESSON
    ===================================================== */

    function getNextNotifiableLesson() {

        const lessons =
            getNotifiableLessons();

        if (
            !lessons.length
        ) {

            return null;
        }

        const now =
            new Date();

        const currentMinutes =
            now.getHours() * 60 +
            now.getMinutes();

        for (
            let i = 0;
            i < lessons.length;
            i++
        ) {

            const lesson =
                lessons[i];

            const start =
                timeToMinutes(
                    lesson.start
                );

            if (
                start === null
            ) {

                continue;
            }

            if (
                start > currentMinutes
            ) {

                return lesson;
            }
        }

        return null;
    }


    /* =====================================================
       GET LESSON START DATE
    ===================================================== */

    function getLessonStartDate(
        lesson
    ) {

        if (
            !lesson ||
            !lesson.start
        ) {

            return null;
        }

        return buildTodayDate(
            lesson.start
        );
    }


    /* =====================================================
       GET LESSON END DATE
    ===================================================== */

    function getLessonEndDate(
        lesson
    ) {

        if (
            !lesson ||
            !lesson.end
        ) {

            return null;
        }

        return buildTodayDate(
            lesson.end
        );
    }


    /* =====================================================
       GET REMINDER DATE
    ===================================================== */

    function getReminderDate(
        lesson,
        reminderMinutes
    ) {

        if (
            !isLessonReadyForNotification(
                lesson
            )
        ) {

            return null;
        }

        const lessonStart =
            getLessonStartDate(
                lesson
            );

        if (!lessonStart) {
            return null;
        }

        const date =
            new Date(
                lessonStart.getTime()
            );

        date.setMinutes(
            date.getMinutes() -
            normalizeReminderMinutes(
                reminderMinutes
            )
        );

        return date;
    }


    /* =====================================================
       MINUTES UNTIL LESSON
    ===================================================== */

    function getMinutesUntilLesson(
        lesson
    ) {

        const lessonStart =
            getLessonStartDate(
                lesson
            );

        if (!lessonStart) {
            return null;
        }

        const difference =
            lessonStart.getTime() -
            Date.now();

        return Math.max(
            0,
            Math.ceil(
                difference / 60000
            )
        );
    }


    /* =====================================================
       BUILD FRIENDLY NOTIFICATION MESSAGE
    ===================================================== */

    function buildNotificationMessage(
        lesson,
        minutes
    ) {

        if (
            !isLessonReadyForNotification(
                lesson
            )
        ) {

            return {
                title: "",
                body: ""
            };
        }

        const lessonName =
            lesson.name ||
            "الحصة القادمة";

        const safeMinutes =
            Math.max(
                0,
                Number(minutes) || 0
            );

        let timingText = "";


        if (
            safeMinutes <= 0
        ) {

            timingText =
                `تبدأ الآن ${lessonName}`;

        } else if (
            safeMinutes === 1
        ) {

            timingText =
                `بعد دقيقة تبدأ ${lessonName}`;

        } else if (
            safeMinutes === 2
        ) {

            timingText =
                `بعد دقيقتين تبدأ ${lessonName}`;

        } else if (
            safeMinutes >= 3 &&
            safeMinutes <= 10
        ) {

            timingText =
                `بعد ${safeMinutes} دقائق تبدأ ${lessonName}`;

        } else {

            timingText =
                `بعد ${safeMinutes} دقيقة تبدأ ${lessonName}`;
        }


        const lessonDetails =
            `${lesson.subject} — ${lesson.className}`;


        return {

            title:
                "مُعين • تذكير الحصة",

            body:
                `${timingText} — ${lessonDetails}\n` +
                `لنستعد لحصتنا معًا 📚`
        };
    }


    /* =====================================================
       NOTIFICATION SUPPORT
    ===================================================== */

    function isNotificationSupported() {

        return (
            typeof window !== "undefined" &&
            (
                (window.MueenNative && window.MueenNative.available) ||
                "Notification" in window ||
                true
            )
        );
    }


    function getNotificationPermission() {

        if (
            window.MueenNative &&
            window.MueenNative.available &&
            typeof window.MueenNative.notificationPermission === "function"
        ) {
            return window.MueenNative.notificationPermission();
        }

        if (
            typeof window !== "undefined" &&
            "Notification" in window
        ) {
            return Notification.permission;
        }

        // في WebView المحلي (مثل ToApp) قد لا تكون Notification API متاحة.
        // نستخدم تنبيه مُعين داخل التطبيق بدل تعطيل نظام التذكير بالكامل.
        return "granted";
    }


    /* =====================================================
       REQUEST PERMISSION
    ===================================================== */

    async function requestMueenNotificationPermission() {

        if (!isNotificationSupported()) {
            return "unsupported";
        }

        try {
            if (
                window.MueenNative &&
                window.MueenNative.available &&
                typeof window.MueenNative.requestNotificationPermission === "function"
            ) {
                return await window.MueenNative.requestNotificationPermission();
            }

            if ("Notification" in window) {
                return await Notification.requestPermission();
            }

            return "unsupported";

        } catch (error) {

            console.warn(
                "MUEEN notification permission error:",
                error
            );

            return "denied";
        }
    }


    /* =====================================================
       SHOW BROWSER NOTIFICATION
    ===================================================== */

    function showMueenNotification(
        lesson,
        minutes
    ) {

        const notification =
            buildNotificationMessage(
                lesson,
                minutes
            );

        if (
            window.MueenNative &&
            window.MueenNative.available &&
            typeof window.MueenNative.notify === "function" &&
            notification.title &&
            notification.body
        ) {
            const when = Date.now();
            try {
                window.MueenNative.notify(
                    notification.title,
                    notification.body,
                    `mueen-lesson-${getTodayKey()}-${lesson.id}`,
                    when
                );
                return true;
            } catch (_) {}
        }

        // ToApp يلف الصفحة داخل WebView وقد لا يوفر Notification API.
        // في هذه الحالة نعرض تنبيهًا داخليًا احترافيًا داخل مُعين،
        // ويعمل طالما أن التطبيق مفتوح. الإشعار الأصلي خارج التطبيق
        // يحتاج إلى الجسر الأصلي الموجود في نسخة Android المخصصة.
        if (
            !(window.MueenNative && window.MueenNative.available) &&
            !(typeof window !== "undefined" && "Notification" in window)
        ) {
            try {
                if (window.MueenUI?.toast) {
                    window.MueenUI.toast(
                        `${notification.title}: ${notification.body}`,
                        "success"
                    );
                } else if (typeof alert === "function") {
                    alert(`${notification.title}\n${notification.body}`);
                }

                if (navigator.vibrate) {
                    navigator.vibrate([120, 70, 120]);
                }

                return true;
            } catch (_) {
                return false;
            }
        }

        if (
            !isNotificationSupported()
        ) {

            return false;
        }

        if (
            getNotificationPermission() !== "granted"
        ) {

            return false;
        }

        if (
            !isLessonReadyForNotification(
                lesson
            )
        ) {

            return false;
        }

        if (
            !notification.title ||
            !notification.body
        ) {

            return false;
        }

        try {

            const n =
                new Notification(
                    notification.title,
                    {
                        body:
                            notification.body,

                        icon:
                            "Mueen.png",

                        badge:
                            "Mueen.png",

                        tag:
                            `mueen-lesson-${getTodayKey()}-${lesson.id}`,

                        renotify:
                            false
                    }
                );

            n.onclick =
                function () {

                    try {

                        window.focus();

                    } catch (error) {
                        // Ignore.
                    }
                };

            return true;

        } catch (error) {

            console.warn(
                "MUEEN notification error:",
                error
            );

            return false;
        }
    }


    /* =====================================================
       SENT REMINDER KEY
    ===================================================== */

    function getSentReminderKey(
        lesson
    ) {

        if (
            !lesson ||
            !lesson.id
        ) {

            return null;
        }

        return (
            `mueen_sent_lesson_reminder_` +
            `${getTodayKey()}_${lesson.id}`
        );
    }


    /* =====================================================
       HAS SENT REMINDER
    ===================================================== */

    function hasSentReminder(
        lesson
    ) {

        const key =
            getSentReminderKey(
                lesson
            );

        if (!key) {
            return false;
        }

        try {

            return (
                localStorage.getItem(
                    key
                ) === "1"
            );

        } catch (error) {

            return false;
        }
    }


    /* =====================================================
       MARK REMINDER AS SENT
    ===================================================== */

    function markReminderAsSent(
        lesson
    ) {

        const key =
            getSentReminderKey(
                lesson
            );

        if (!key) {
            return;
        }

        try {

            localStorage.setItem(
                key,
                "1"
            );

        } catch (error) {

            console.warn(
                "Unable to save MUEEN reminder state:",
                error
            );
        }
    }


    /* =====================================================
       CLEAN OLD REMINDER KEYS
    ===================================================== */

    function cleanOldReminderKeys() {

        const today =
            getTodayKey();

        const prefix =
            "mueen_sent_lesson_reminder_";

        try {

            const keys = [];

            for (
                let i = 0;
                i < localStorage.length;
                i++
            ) {

                const key =
                    localStorage.key(i);

                if (
                    key &&
                    key.startsWith(
                        prefix
                    )
                ) {

                    keys.push(
                        key
                    );
                }
            }


            keys.forEach(
                function (key) {

                    if (
                        !key.includes(
                            today
                        )
                    ) {

                        localStorage.removeItem(
                            key
                        );
                    }
                }
            );

        } catch (error) {

            console.warn(
                "Unable to clean MUEEN reminder keys:",
                error
            );
        }
    }


    /* =====================================================
       CHECK IF REMINDER IS DUE
    ===================================================== */

    function isReminderDue(
        lesson,
        reminderMinutes
    ) {

        if (
            !isLessonReadyForNotification(
                lesson
            )
        ) {

            return false;
        }

        const reminderDate =
            getReminderDate(
                lesson,
                reminderMinutes
            );

        const lessonStart =
            getLessonStartDate(
                lesson
            );

        if (
            !reminderDate ||
            !lessonStart
        ) {

            return false;
        }

        const now =
            Date.now();

        const reminderTime =
            reminderDate.getTime();

        const lessonStartTime =
            lessonStart.getTime();


        /*
            يصبح التذكير مستحقًا من:
            موعد التذكير
            وحتى بداية الحصة.

            إذا فتح المستخدم التطبيق بعد
            موعد التذكير ولكنه قبل بداية
            الحصة، يظهر له إشعار واحد فقط.
        */

        return (
            now >= reminderTime &&
            now < lessonStartTime
        );
    }


    /* =====================================================
       CHECK AND SEND LESSON REMINDER
    ===================================================== */

    function checkAndSendLessonReminder() {

        const settings =
            getNotificationSettings();

        if (
            !settings.enabled
        ) {

            return;
        }

        if (
            !isNotificationSupported()
        ) {

            return;
        }

        if (
            Notification.permission !== "granted"
        ) {

            return;
        }

        const today =
            getTodayDay();

        if (!today) {
            return;
        }

        const lessons =
            getTodayLessons();

        if (
            !lessons.length
        ) {

            return;
        }

        cleanOldReminderKeys();


        /*
            نفحص جميع الحصص.

            الحصص الفارغة:
            - لا ترسل إشعارًا.
            - لكنها تبقى في الجدول.
            - وتبقى مؤثرة في ترتيب وتوقيت اليوم.

            الحصة المكتملة:
            - مادة موجودة.
            - صف/فصل موجود.
            - تحصل على إشعار واحد فقط.
        */

        for (
            let i = 0;
            i < lessons.length;
            i++
        ) {

            const lesson =
                lessons[i];

            if (
                !isLessonReadyForNotification(
                    lesson
                )
            ) {

                continue;
            }

            if (
                hasSentReminder(
                    lesson
                )
            ) {

                continue;
            }

            if (
                isReminderDue(
                    lesson,
                    settings.reminderMinutes
                )
            ) {

                /*
                    نستخدم الوقت الحقيقي المتبقي
                    عند ظهور الإشعار.

                    مثال:
                    الإعداد = 60 دقيقة
                    فتح التطبيق قبل الحصة بـ28 دقيقة

                    الرسالة:
                    بعد 28 دقيقة تبدأ الحصة...
                */

                const minutesUntil =
                    getMinutesUntilLesson(
                        lesson
                    );

                const sent =
                    showMueenNotification(
                        lesson,
                        minutesUntil
                    );

                /*
                    نسجل الإشعار كمُرسل
                    فقط إذا نجح إنشاء الإشعار.
                */

                if (sent) {

                    markReminderAsSent(
                        lesson
                    );
                }
            }
        }
    }


    /* =====================================================
       GET NEXT LESSON INFO
    ===================================================== */

    function getNextLessonInfo() {

        const nextLesson =
            getNextNotifiableLesson();

        if (!nextLesson) {

            return null;
        }

        const settings =
            getNotificationSettings();

        const minutes =
            getMinutesUntilLesson(
                nextLesson
            );

        const reminderDate =
            getReminderDate(
                nextLesson,
                settings.reminderMinutes
            );

        return {

            lesson:
                nextLesson,

            minutesUntilLesson:
                minutes,

            reminderMinutes:
                settings.reminderMinutes,

            reminderDate:
                reminderDate,

            formattedStart:
                formatArabicTime(
                    nextLesson.start
                ),

            formattedEnd:
                formatArabicTime(
                    nextLesson.end
                )
        };
    }


    /* =====================================================
       START MANAGER
    ===================================================== */

    let reminderInterval =
        null;

    function scheduleNativeTodayNotifications() {
        if (!window.MueenNative?.available || typeof window.MueenNative.notify !== "function") {
            return;
        }

        const settings = getNotificationSettings();

        // إعادة بناء جدول تنبيهات اليوم تمنع بقاء أوقات قديمة بعد تعديل الجدول أو مدة التذكير.
        if (typeof window.MueenNative.cancelAllNotifications === "function") {
            try {
                window.MueenNative.cancelAllNotifications();
            } catch (_) {}
        }

        if (!settings.enabled || getNotificationPermission() !== "granted") {
            return;
        }

        const lessons = getNotifiableLessons();

        lessons.forEach(lesson => {
            const start = getLessonStartDate(lesson);
            if (!start) return;

            const reminderAt = start.getTime() - (Number(settings.reminderMinutes) || 15) * 60000;
            if (reminderAt <= Date.now()) return;

            const message = buildNotificationMessage(lesson, settings.reminderMinutes);
            try {
                window.MueenNative.notify(
                    message.title,
                    message.body,
                    `mueen-scheduled-${getTodayKey()}-${lesson.id}`,
                    reminderAt
                );
                markReminderAsSent(lesson);
            } catch (error) {
                console.warn("MUEEN native scheduling:", error);
            }
        });
    }


    function startMueenNotificationManager() {

        stopMueenNotificationManager();

        scheduleNativeTodayNotifications();

        /*
            فحص فوري عند التشغيل.
        */

        checkAndSendLessonReminder();


        /*
            الفحص كل 15 ثانية
            حتى يكون الإشعار قريبًا
            من الوقت المحدد.
        */

        if (
            typeof window !== "undefined"
        ) {

            reminderInterval =
                window.setInterval(
                    function () {

                        checkAndSendLessonReminder();

                    },
                    15000
                );
        }
    }


    /* =====================================================
       STOP MANAGER
    ===================================================== */

    function stopMueenNotificationManager() {

        if (
            reminderInterval !== null &&
            typeof window !== "undefined"
        ) {

            window.clearInterval(
                reminderInterval
            );

            reminderInterval =
                null;
        }
    }


    /* =====================================================
       UPDATE ENABLED STATE
    ===================================================== */

    function setMueenNotificationsEnabled(
        enabled
    ) {

        const settings =
            getNotificationSettings();

        settings.enabled =
            enabled === true;

        saveNotificationSettings(
            settings
        );

        if (
            settings.enabled
        ) {

            startMueenNotificationManager();

        } else {

            stopMueenNotificationManager();

            if (window.MueenNative?.available && typeof window.MueenNative.cancelAllNotifications === "function") {
                try {
                    window.MueenNative.cancelAllNotifications();
                } catch (_) {}
            }
        }
    }


    /* =====================================================
       SET REMINDER MINUTES
    ===================================================== */

    function setMueenReminderMinutes(
        minutes
    ) {

        const settings =
            getNotificationSettings();

        settings.reminderMinutes =
            normalizeReminderMinutes(
                minutes
            );

        saveNotificationSettings(
            settings
        );


        /*
            إذا كانت الإشعارات مفعلة،
            نعيد جدولة التنبيهات الأصلية مباشرة.
        */

        if (
            settings.enabled
        ) {

            scheduleNativeTodayNotifications();
            checkAndSendLessonReminder();
        }
    }


    /* =====================================================
       GET STATUS
    ===================================================== */

    function getMueenNotificationStatus() {

        const settings =
            getNotificationSettings();

        const nextLesson =
            getNextLessonInfo();

        let permission =
            "unsupported";

        if (
            isNotificationSupported()
        ) {

            permission =
                getNotificationPermission();
        }

        return {

            enabled:
                settings.enabled,

            reminderMinutes:
                settings.reminderMinutes,

            permission:
                permission,

            supported:
                isNotificationSupported(),

            nextLesson:
                nextLesson
        };
    }


    /* =====================================================
       GLOBAL API
    ===================================================== */

    window.MueenNotifications = {

        getSettings:
            getNotificationSettings,

        saveSettings:
            saveNotificationSettings,

        getSchedule:
            getSchedule,

        getScheduleSettings:
            getScheduleSettings,

        getTodayLessons:
            getTodayLessons,

        getNotifiableLessons:
            getNotifiableLessons,

        getCurrentLesson:
            getCurrentLesson,

        getNextLesson:
            getNextLesson,

        getNextNotifiableLesson:
            getNextNotifiableLesson,

        getNextLessonInfo:
            getNextLessonInfo,

        getMinutesUntilLesson:
            getMinutesUntilLesson,

        formatArabicTime:
            formatArabicTime,

        requestPermission:
            requestMueenNotificationPermission,

        showNotification:
            showMueenNotification,

        check:
            checkAndSendLessonReminder,

        start:
            startMueenNotificationManager,

        stop:
            stopMueenNotificationManager,

        enable:
            function () {

                setMueenNotificationsEnabled(
                    true
                );
            },

        disable:
            function () {

                setMueenNotificationsEnabled(
                    false
                );
            },

        setReminderMinutes:
            setMueenReminderMinutes,

        getStatus:
            getMueenNotificationStatus
    };


    /* =====================================================
       AUTO START
    ===================================================== */

    function autoStart() {

        const settings =
            getNotificationSettings();

        if (
            settings.enabled
        ) {

            startMueenNotificationManager();
        }
    }


    /* =====================================================
       INITIALIZE
    ===================================================== */

    if (
        typeof document !== "undefined"
    ) {

        if (
            document.readyState ===
            "loading"
        ) {

            document.addEventListener(
                "DOMContentLoaded",
                autoStart
            );

        } else {

            autoStart();
        }

    } else {

        autoStart();
    }


})();