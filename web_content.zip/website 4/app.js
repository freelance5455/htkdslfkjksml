/* ==========================================================================
   KONFIGURASI DATABASE REALTIME PUBLIK (OPSIONAL HARDCODE URL FIREBASE)
   Jika Anda ingin setiap pengunjung publik otomatis terhubung ke Firebase
   tanpa perlu mengisi di menu Pengaturan, masukkan URL Firebase Anda di bawah:
   Contoh: "https://project-anda-default-rtdb.firebaseio.com"
   ========================================================================== */
const DEFAULT_FIREBASE_DB_URL = "https://syam-workspace-default-rtdb.asia-southeast1.firebasedatabase.app/";

/* ==========================================================================
   20 TEMA UI/UX (10 LIGHT + 10 DARK)
   ========================================================================== */
const THEMES_CATALOG = [
  // 10 LIGHT THEMES
  { id: "light-minimal", name: "Pure Minimalist", mode: "light", colors: ["#f4f6fb", "#2563eb", "#0ea5e9"] },
  { id: "light-ocean", name: "Ocean Breeze", mode: "light", colors: ["#eef7fa", "#0284c7", "#06b6d4"] },
  { id: "light-emerald", name: "Emerald Mint", mode: "light", colors: ["#eff8f4", "#059669", "#10b981"] },
  { id: "light-sunset", name: "Warm Sunset", mode: "light", colors: ["#fdf4ef", "#ea580c", "#f97316"] },
  { id: "light-lavender", name: "Soft Lavender", mode: "light", colors: ["#f5f3ff", "#7c3aed", "#a855f7"] },
  { id: "light-rose", name: "Sakura Rose", mode: "light", colors: ["#fff1f5", "#e11d48", "#f43f5e"] },
  { id: "light-amber", name: "Golden Amber", mode: "light", colors: ["#fef9ec", "#d97706", "#f59e0b"] },
  { id: "light-nordic", name: "Nordic Frost", mode: "light", colors: ["#eceff4", "#5e81ac", "#81a1c1"] },
  { id: "light-matcha", name: "Kyoto Matcha", mode: "light", colors: ["#f4f7ee", "#4d7c0f", "#65a30d"] },
  { id: "light-paper", name: "Warm Editorial", mode: "light", colors: ["#f6f1e9", "#8b3a2b", "#b45309"] },
  // 10 DARK THEMES
  { id: "dark-midnight", name: "Midnight Slate", mode: "dark", colors: ["#0b1120", "#3b82f6", "#38bdf8"] },
  { id: "dark-obsidian", name: "Obsidian Gold", mode: "dark", colors: ["#09090b", "#eab308", "#facc15"] },
  { id: "dark-cyber", name: "Cyber Neon", mode: "dark", colors: ["#070815", "#06b6d4", "#ec4899"] },
  { id: "dark-forest", name: "Deep Forest", mode: "dark", colors: ["#08120e", "#10b981", "#34d399"] },
  { id: "dark-crimson", name: "Crimson Velvet", mode: "dark", colors: ["#13090c", "#f43f5e", "#fb7185"] },
  { id: "dark-amethyst", name: "Royal Amethyst", mode: "dark", colors: ["#100a1c", "#a855f7", "#c084fc"] },
  { id: "dark-dracula", name: "Dracula Dusk", mode: "dark", colors: ["#1e1f29", "#bd93f9", "#ff79c6"] },
  { id: "dark-nord", name: "Arctic Night", mode: "dark", colors: ["#242933", "#88c0d0", "#81a1c1"] },
  { id: "dark-espresso", name: "Mocha Espresso", mode: "dark", colors: ["#140f0c", "#f97316", "#fb923c"] },
  { id: "dark-oceanic", name: "Abyssal Ocean", mode: "dark", colors: ["#06131d", "#14b8a6", "#38bdf8"] }
];

/* ==========================================================================
   STATE MANAGEMENT & DEFAULT DATA
   ========================================================================== */
const STORAGE_KEY = "syam_workspace_db_v1";
const SESSION_KEY = "syam_workspace_session_v1";

function getTodayISO() {
  const now = new Date();
  const offset = now.getTimezoneOffset() * 60000;
  return new Date(now.getTime() - offset).toISOString().split("T")[0];
}

function getDefaultState() {
  const today = getTodayISO();
  return {
    settings: {
      appName: "SyamWorkspace",
      headerTitle: "SyamWorkspace — Jadwal Harian & Cash Flow",
      headerSubtitle: "Pantau aktivitas prioritas dan arus kas secara terpadu & realtime",
      theme: "light-minimal",
      currency: "Rp",
      firebaseUrl: DEFAULT_FIREBASE_DB_URL,
      scheduleWidgets: {
        progress: true,
        list: true,
        combo: true,
        eval: true
      }
    },
    users: [
      {
        username: "syamramdani",
        password: "syamramdani1712",
        fullName: "Syam Ramdani",
        role: "Administrator",
        active: true
      }
    ],
    scheduleCategories: ["Pekerjaan", "Bisnis", "Ibadah", "Olahraga", "Belajar", "Keluarga"],
    schedules: [
      {
        id: "sch-1",
        title: "Review Target Harian & Cek Saldo Cash Flow",
        category: "Bisnis",
        date: today,
        startTime: "07:30",
        endTime: "08:15",
        repeat: "daily",
        priority: true,
        notes: "Pastikan laporan kas masuk dan anggaran harian terkendali",
        completedDates: { [today]: true }
      },
      {
        id: "sch-2",
        title: "Operasional & Follow Up Klien",
        category: "Pekerjaan",
        date: today,
        startTime: "09:00",
        endTime: "12:00",
        repeat: "weekdays",
        priority: true,
        notes: "Koordinasi tim dan pengecekan pesanan",
        completedDates: {}
      },
      {
        id: "sch-3",
        title: "Olahraga Sore & Evaluasi Aktivitas",
        category: "Olahraga",
        date: today,
        startTime: "16:30",
        endTime: "17:30",
        repeat: "daily",
        priority: false,
        notes: "Jogging ringan 30 menit",
        completedDates: {}
      }
    ],
    incomeCategories: ["Penjualan", "Gaji", "Pendapatan usaha", "Investasi", "Piutang dibayar", "Pendapatan lainnya"],
    expenseCategories: ["Belanja", "Operasional", "Transportasi", "Listrik dan air", "Gaji karyawan", "Pembelian barang", "Pengeluaran lainnya"],
    accounts: [
      { id: "acc-tunai", name: "Kas Tunai", type: "Tunai", initialBalance: 2500000, number: "-" },
      { id: "acc-bri", name: "BRI", type: "Bank", initialBalance: 8500000, number: "0123-01-004567-50-1" },
      { id: "acc-bca", name: "BCA", type: "Bank", initialBalance: 12000000, number: "7750-8899-12" },
      { id: "acc-mandiri", name: "Mandiri", type: "Bank", initialBalance: 5000000, number: "130-00-1122334-5" },
      { id: "acc-dana", name: "DANA", type: "E-Wallet", initialBalance: 1200000, number: "0812-xxxx-xxxx" },
      { id: "acc-ovo", name: "OVO", type: "E-Wallet", initialBalance: 750000, number: "0812-xxxx-xxxx" },
      { id: "acc-gopay", name: "GoPay", type: "E-Wallet", initialBalance: 850000, number: "0812-xxxx-xxxx" }
    ],
    transactions: [
      {
        id: "tx-1",
        type: "income",
        date: today,
        category: "Penjualan",
        accountId: "acc-bca",
        amount: 4500000,
        note: "Penjualan paket layanan & produk utama",
        receipt: ""
      },
      {
        id: "tx-2",
        type: "expense",
        date: today,
        category: "Belanja",
        accountId: "acc-bri",
        amount: 1650000,
        note: "Belanja stok kebutuhan bulanan",
        receipt: ""
      },
      {
        id: "tx-3",
        type: "expense",
        date: today,
        category: "Operasional",
        accountId: "acc-tunai",
        amount: 450000,
        note: "Biaya operasional harian & konsumsi",
        receipt: ""
      },
      {
        id: "tx-4",
        type: "expense",
        date: today,
        category: "Transportasi",
        accountId: "acc-gopay",
        amount: 250000,
        note: "BBM & ongkos kirim kurir",
        receipt: ""
      }
    ],
    transfers: [
      {
        id: "trf-1",
        date: today,
        fromAccountId: "acc-bca",
        toAccountId: "acc-dana",
        amount: 500000,
        fee: 0,
        note: "Top up saldo DANA operasional"
      }
    ],
    budgets: [
      { category: "Belanja", limit: 2000000 },
      { category: "Operasional", limit: 1000000 },
      { category: "Transportasi", limit: 500000 }
    ],
    debts: [
      {
        id: "dbt-1",
        kind: "payable",
        person: "CV Mitra Supplier",
        amount: 3000000,
        date: today,
        dueDate: today,
        status: "UNPAID",
        note: "Pembelian bahan baku tahap 2",
        payments: [
          { id: "pay-1", date: today, amount: 1000000, accountId: "acc-bri", note: "DP 1 juta" }
        ]
      },
      {
        id: "dbt-2",
        kind: "receivable",
        person: "Toko Berkah Abadi",
        amount: 2500000,
        date: today,
        dueDate: today,
        status: "UNPAID",
        note: "Invoice penjualan #INV-104",
        payments: []
      }
    ],
    lastUpdated: Date.now()
  };
}

let appState = loadLocalState();
let currentUser = null;
let charts = {};
let calendarViewDate = new Date();
let selectedCalendarDay = getTodayISO();
let tempReceiptBase64 = "";
let firebaseEventSource = null;
let remindedThisMinute = {};

function loadLocalState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return getDefaultState();
    const parsed = JSON.parse(raw);
    const def = getDefaultState();
    return {
      ...def,
      ...parsed,
      settings: { ...def.settings, ...(parsed.settings || {}) }
    };
  } catch (e) {
    return getDefaultState();
  }
}

function saveState(skipCloudPush = false) {
  appState.lastUpdated = Date.now();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
  if (!skipCloudPush && appState.settings.firebaseUrl) {
    pushStateToFirebase();
  }
}

/* ==========================================================================
   FIREBASE REALTIME DATABASE SYNC (PUBLIC HOSTING)
   ========================================================================== */
function normalizeFirebaseUrl(url) {
  if (!url) return "";
  return url.trim().replace(/\/+$/, "");
}

async function pushStateToFirebase() {
  const baseUrl = normalizeFirebaseUrl(appState.settings.firebaseUrl);
  if (!baseUrl) return;
  try {
    setSyncUI("syncing", "Menyinkronkan...");
    await fetch(`${baseUrl}/syam_workspace_data.json`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(appState)
    });
    setSyncUI("online", "Realtime Cloud Aktif");
  } catch (err) {
    setSyncUI("offline", "Gagal Sync Cloud");
  }
}

function connectFirebaseRealtime() {
  if (firebaseEventSource) {
    firebaseEventSource.close();
    firebaseEventSource = null;
  }
  const baseUrl = normalizeFirebaseUrl(appState.settings.firebaseUrl);
  if (!baseUrl) {
    setSyncUI("offline", "Lokal Aktif");
    return;
  }

  setSyncUI("syncing", "Menghubungkan Cloud...");
  try {
    firebaseEventSource = new EventSource(`${baseUrl}/syam_workspace_data.json`);
    const handleIncoming = (event) => {
      try {
        const payload = JSON.parse(event.data);
        const incoming = payload && payload.data ? payload.data : payload;
        if (incoming && incoming.lastUpdated && incoming.lastUpdated > (appState.lastUpdated || 0)) {
          const keepUrl = appState.settings.firebaseUrl;
          appState = { ...getDefaultState(), ...incoming };
          appState.settings.firebaseUrl = keepUrl;
          localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
          applyTheme(appState.settings.theme);
          applyBrandingUI();
          refreshAllViews();
          showToast("Data diperbarui secara realtime dari server!");
        }
        setSyncUI("online", "Realtime Cloud Aktif");
      } catch (_) {
        setSyncUI("online", "Realtime Cloud Aktif");
      }
    };
    firebaseEventSource.addEventListener("put", handleIncoming);
    firebaseEventSource.addEventListener("patch", handleIncoming);
    firebaseEventSource.onerror = () => {
      setSyncUI("offline", "Cloud Terputus (Mode Lokal)");
    };
  } catch (e) {
    setSyncUI("offline", "URL Cloud Tidak Valid");
  }
}

function setSyncUI(status, text) {
  const ind = document.getElementById("sync-status-indicator");
  const txt = document.getElementById("sync-status-text");
  const loginBadge = document.getElementById("login-sync-badge");
  if (ind && txt) {
    ind.className = `sync-indicator ${status === "online" ? "online" : ""}`;
    txt.textContent = text;
  }
  if (loginBadge) {
    loginBadge.innerHTML = `<i class="fa-solid fa-database"></i> ${text}`;
  }
}

/* ==========================================================================
   INITIALIZATION & REALTIME CLOCK
   ========================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  applyTheme(appState.settings.theme);
  applyBrandingUI();
  startRealtimeClock();
  connectFirebaseRealtime();

  // Check saved session
  const savedUser = sessionStorage.getItem(SESSION_KEY);
  if (savedUser) {
    const found = appState.users.find((u) => u.username === savedUser && u.active);
    if (found) {
      loginSuccess(found);
    }
  }

  document.getElementById("login-form").addEventListener("submit", handleLogin);
});

function startRealtimeClock() {
  const daysID = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const monthsID = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];

  const tick = () => {
    const now = new Date();
    const dayName = daysID[now.getDay()];
    const dateNum = now.getDate();
    const monthName = monthsID[now.getMonth()];
    const yearNum = now.getFullYear();

    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const ss = String(now.getSeconds()).padStart(2, "0");

    const dateEl = document.getElementById("rt-date-display");
    const timeEl = document.getElementById("rt-time-display");
    if (dateEl) dateEl.textContent = `${dayName}, ${dateNum} ${monthName} ${yearNum}`;
    if (timeEl) timeEl.textContent = `${hh}:${mm}:${ss}`;

    // Check priority schedule reminder every minute
    if (currentUser && ss === "00") {
      checkPriorityReminders(`${hh}:${mm}`);
    }
  };
  tick();
  setInterval(tick, 1000);
}

/* ==========================================================================
   AUTHENTICATION & USER MANAGEMENT
   ========================================================================== */
function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById("login-username").value.trim();
  const password = document.getElementById("login-password").value;
  const errBox = document.getElementById("login-error");

  const user = appState.users.find(
    (u) => u.username.toLowerCase() === username.toLowerCase() && u.password === password
  );

  if (!user) {
    errBox.textContent = "Username atau password salah!";
    errBox.classList.remove("hidden");
    return;
  }
  if (!user.active) {
    errBox.textContent = "Akun ini sedang dinonaktifkan oleh Administrator.";
    errBox.classList.remove("hidden");
    return;
  }

  errBox.classList.add("hidden");
  loginSuccess(user);
}

function loginSuccess(user) {
  currentUser = user;
  sessionStorage.setItem(SESSION_KEY, user.username);
  document.getElementById("login-screen").classList.add("hidden");
  document.getElementById("app-shell").classList.remove("hidden");

  document.getElementById("sched-filter-date").value = getTodayISO();
  applyBrandingUI();
  refreshAllViews();
  showToast(`Selamat datang kembali, ${user.fullName}!`);
}

function logout() {
  currentUser = null;
  sessionStorage.removeItem(SESSION_KEY);
  document.getElementById("app-shell").classList.add("hidden");
  document.getElementById("login-screen").classList.remove("hidden");
  document.getElementById("login-password").value = "";
}

function togglePasswordVisibility(inputId, btn) {
  const inp = document.getElementById(inputId);
  const icon = btn.querySelector("i");
  if (inp.type === "password") {
    inp.type = "text";
    icon.className = "fa-solid fa-eye-slash";
  } else {
    inp.type = "password";
    icon.className = "fa-solid fa-eye";
  }
}

/* ==========================================================================
   NAVIGATION & BRANDING UI
   ========================================================================== */
function switchView(viewId) {
  document.querySelectorAll(".view-section").forEach((el) => el.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach((el) => el.classList.remove("active"));

  const target = document.getElementById(`view-${viewId}`);
  if (target) target.classList.add("active");

  const navBtn = document.querySelector(`.nav-item[data-view="${viewId}"]`);
  if (navBtn) navBtn.classList.add("active");

  toggleSidebar(false);
  refreshAllViews();
}

function toggleSidebar(open) {
  const sidebar = document.getElementById("sidebar");
  if (open) sidebar.classList.add("open");
  else sidebar.classList.remove("open");
}

function applyBrandingUI() {
  const s = appState.settings;
  document.title = s.headerTitle;
  document.getElementById("login-app-title").textContent = s.appName;
  document.getElementById("sidebar-title").textContent = s.appName;
  document.getElementById("header-main-title").textContent = s.headerTitle;
  document.getElementById("header-sub-title").textContent = s.headerSubtitle;

  if (currentUser) {
    document.getElementById("sidebar-user-name").textContent = currentUser.fullName;
    document.getElementById("sidebar-user-role").textContent = currentUser.role;
    const initials = currentUser.fullName
      .split(" ")
      .map((n) => n[0])
      .join("")
      .substring(0, 2)
      .toUpperCase();
    document.getElementById("sidebar-user-avatar").textContent = initials || "US";
  }
}

function refreshAllViews() {
  populateAllDropdowns();
  renderScheduleDashboard();
  renderScheduleEvaluationPage();
  renderCashFlowDashboard();
  renderTransactionTable("income");
  renderTransactionTable("expense");
  renderTransferTable();
  renderAccountsGrid();
  renderFinancialReport();
  renderBudgetView();
  renderDebtsTable();
  renderFinancialCalendar();
  renderSettingsPage();
}

/* ==========================================================================
   HELPERS: CURRENCY, DATES, MODALS, TOAST
   ========================================================================== */
function formatMoney(amount) {
  const num = Number(amount) || 0;
  const sym = appState.settings.currency || "Rp";
  const sign = num < 0 ? "-" : "";
  return `${sign}${sym}${Math.abs(num).toLocaleString("id-ID")}`;
}

function formatDateID(isoDate) {
  if (!isoDate) return "-";
  const [y, m, d] = isoDate.split("-");
  const months = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
  return `${Number(d)} ${months[Number(m) - 1]} ${y}`;
}

function openModal(id) {
  document.getElementById(id).classList.remove("hidden");
}

function closeModal(id) {
  document.getElementById(id).classList.add("hidden");
}

function showToast(message) {
  const container = document.getElementById("toast-container");
  const toast = document.createElement("div");
  toast.className = "toast-msg";
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4200);
}

function populateAllDropdowns() {
  // Schedule Categories
  const schedCatFilter = document.getElementById("sched-filter-category");
  const curFilterVal = schedCatFilter.value;
  schedCatFilter.innerHTML = `<option value="ALL">Semua Kategori</option>` +
    appState.scheduleCategories.map((c) => `<option value="${c}">${c}</option>`).join("");
  if ([...schedCatFilter.options].some((o) => o.value === curFilterVal)) {
    schedCatFilter.value = curFilterVal;
  }

  const schedModalCat = document.getElementById("sched-category");
  schedModalCat.innerHTML = appState.scheduleCategories.map((c) => `<option value="${c}">${c}</option>`).join("");

  // Income & Expense Category Filters
  const incFilter = document.getElementById("income-cat-filter");
  const incVal = incFilter.value;
  incFilter.innerHTML = `<option value="ALL">Semua Kategori</option>` +
    appState.incomeCategories.map((c) => `<option value="${c}">${c}</option>`).join("");
  if ([...incFilter.options].some((o) => o.value === incVal)) incFilter.value = incVal;

  const expFilter = document.getElementById("expense-cat-filter");
  const expVal = expFilter.value;
  expFilter.innerHTML = `<option value="ALL">Semua Kategori</option>` +
    appState.expenseCategories.map((c) => `<option value="${c}">${c}</option>`).join("");
  if ([...expFilter.options].some((o) => o.value === expVal)) expFilter.value = expVal;

  // Report Category Filter
  const repCat = document.getElementById("report-category-filter");
  const repVal = repCat.value;
  const allCats = [...new Set([...appState.incomeCategories, ...appState.expenseCategories])];
  repCat.innerHTML = `<option value="ALL">Semua Kategori</option>` +
    allCats.map((c) => `<option value="${c}">${c}</option>`).join("");
  if ([...repCat.options].some((o) => o.value === repVal)) repCat.value = repVal;

  // Budget Categories
  const budCat = document.getElementById("bud-category");
  budCat.innerHTML = appState.expenseCategories.map((c) => `<option value="${c}">${c}</option>`).join("");
}

/* ==========================================================================
   MODULE 1: JADWAL HARIAN (RECURRING, PROGRESS, PRIORITY, CHARTS, EXCEL)
   ========================================================================== */
function isScheduleActiveOnDate(item, targetISO) {
  if (targetISO < item.date) return false;
  if (item.repeat === "none") return item.date === targetISO;
  if (item.repeat === "daily") return true;

  const targetObj = new Date(targetISO + "T00:00:00");
  const startObj = new Date(item.date + "T00:00:00");
  const dayOfWeek = targetObj.getDay(); // 0 = Sun, 6 = Sat

  if (item.repeat === "weekdays") return dayOfWeek >= 1 && dayOfWeek <= 5;
  if (item.repeat === "weekends") return dayOfWeek === 0 || dayOfWeek === 6;
  if (item.repeat === "weekly") return dayOfWeek === startObj.getDay();
  if (item.repeat === "monthly") return targetObj.getDate() === startObj.getDate();
  return false;
}

function getSchedulesForDate(targetISO) {
  return appState.schedules
    .filter((item) => isScheduleActiveOnDate(item, targetISO))
    .sort((a, b) => a.startTime.localeCompare(b.startTime));
}

function shiftScheduleDate(days) {
  const inp = document.getElementById("sched-filter-date");
  const base = new Date((inp.value || getTodayISO()) + "T00:00:00");
  base.setDate(base.getDate() + days);
  const offset = base.getTimezoneOffset() * 60000;
  inp.value = new Date(base.getTime() - offset).toISOString().split("T")[0];
  renderScheduleDashboard();
}

function resetScheduleDateToday() {
  document.getElementById("sched-filter-date").value = getTodayISO();
  renderScheduleDashboard();
}

function toggleScheduleWidgetEditor() {
  document.getElementById("schedule-widget-editor").classList.toggle("hidden");
}

function updateScheduleWidgets() {
  const w = {
    progress: document.getElementById("w-sched-progress").checked,
    list: document.getElementById("w-sched-list").checked,
    combo: document.getElementById("w-sched-combo").checked,
    eval: document.getElementById("w-sched-eval").checked
  };
  appState.settings.scheduleWidgets = w;
  saveState();
  applyScheduleWidgetVisibility();
}

function applyScheduleWidgetVisibility() {
  const w = appState.settings.scheduleWidgets;
  document.getElementById("w-sched-progress").checked = w.progress;
  document.getElementById("w-sched-list").checked = w.list;
  document.getElementById("w-sched-combo").checked = w.combo;
  document.getElementById("w-sched-eval").checked = w.eval;

  document.getElementById("widget-sched-progress").classList.toggle("hidden", !w.progress);
  document.getElementById("widget-sched-list").classList.toggle("hidden", !w.list);
  document.getElementById("widget-sched-combo").classList.toggle("hidden", !w.combo);
  document.getElementById("widget-sched-eval").classList.toggle("hidden", !w.eval);
}

function renderScheduleDashboard() {
  applyScheduleWidgetVisibility();
  const selectedDate = document.getElementById("sched-filter-date").value || getTodayISO();
  const catFilter = document.getElementById("sched-filter-category").value;
  const statusFilter = document.getElementById("sched-filter-status").value;

  const daySchedules = getSchedulesForDate(selectedDate);
  const doneCount = daySchedules.filter((s) => s.completedDates && s.completedDates[selectedDate]).length;
  const totalCount = daySchedules.length;
  const pct = totalCount > 0 ? Math.round((doneCount / totalCount) * 100) : 0;

  document.getElementById("sched-selected-date-label").textContent =
    selectedDate === getTodayISO() ? `Hari Ini (${formatDateID(selectedDate)})` : formatDateID(selectedDate);
  document.getElementById("sched-progress-percent").textContent = `${pct}%`;
  document.getElementById("sched-progress-fraction").textContent = `${doneCount} dari ${totalCount} kegiatan selesai`;
  document.getElementById("sched-progress-bar").style.width = `${pct}%`;

  // Priority strip & topbar bell count
  const prioritiesToday = getSchedulesForDate(getTodayISO()).filter((s) => s.priority);
  document.getElementById("priority-badge-count").textContent = prioritiesToday.length;

  const priorityStrip = document.getElementById("priority-strip");
  const selectedPriorities = daySchedules.filter((s) => s.priority);
  priorityStrip.innerHTML = selectedPriorities.length
    ? selectedPriorities
        .map((p) => `<span class="priority-chip"><i class="fa-solid fa-bell"></i> Prioritas ${p.startTime}: ${p.title}</span>`)
        .join("")
    : `<span class="muted-text">Tidak ada jadwal prioritas khusus pada tanggal ini.</span>`;

  // Filtered list
  const filtered = daySchedules.filter((item) => {
    const isDone = Boolean(item.completedDates && item.completedDates[selectedDate]);
    if (catFilter !== "ALL" && item.category !== catFilter) return false;
    if (statusFilter === "DONE" && !isDone) return false;
    if (statusFilter === "PENDING" && isDone) return false;
    if (statusFilter === "PRIORITY" && !item.priority) return false;
    return true;
  });

  const repeatLabels = {
    none: "Sekali",
    daily: "Setiap Hari",
    weekdays: "Senin - Jumat",
    weekends: "Akhir Pekan",
    weekly: "Mingguan",
    monthly: "Bulanan"
  };

  const container = document.getElementById("schedule-list-container");
  if (!filtered.length) {
    container.innerHTML = `<p class="muted-text" style="padding:1rem 0;">Belum ada jadwal kegiatan untuk filter tanggal ini. Klik <strong>+ Tambah Jadwal</strong> untuk membuat baru.</p>`;
  } else {
    container.innerHTML = filtered
      .map((item) => {
        const isDone = Boolean(item.completedDates && item.completedDates[selectedDate]);
        return `
          <div class="schedule-item ${isDone ? "done" : ""}">
            <div class="sched-left">
              <input type="checkbox" class="sched-check" ${isDone ? "checked" : ""}
                onchange="toggleScheduleComplete('${item.id}', '${selectedDate}')" />
              <span class="sched-time-badge">${item.startTime} - ${item.endTime}</span>
              <div class="sched-info">
                <div class="sched-item-title">
                  <span>${item.title}</span>
                  ${item.priority ? `<span class="status-badge warn"><i class="fa-solid fa-bell"></i> Prioritas</span>` : ""}
                </div>
                <div class="sched-meta">
                  <span><i class="fa-solid fa-tag"></i> ${item.category}</span>
                  <span><i class="fa-solid fa-repeat"></i> ${repeatLabels[item.repeat] || item.repeat}</span>
                  ${item.notes ? `<span><i class="fa-solid fa-note-sticky"></i> ${item.notes}</span>` : ""}
                </div>
              </div>
            </div>
            <div class="sched-actions">
              <button class="icon-btn" title="Edit" onclick="openScheduleModal('${item.id}')">
                <i class="fa-solid fa-pen"></i>
              </button>
              <button class="icon-btn danger" title="Hapus" onclick="deleteScheduleItem('${item.id}')">
                <i class="fa-solid fa-trash"></i>
              </button>
            </div>
          </div>
        `;
      })
      .join("");
  }

  renderScheduleCharts();
}

function toggleScheduleComplete(id, dateISO) {
  const item = appState.schedules.find((s) => s.id === id);
  if (!item) return;
  if (!item.completedDates) item.completedDates = {};
  item.completedDates[dateISO] = !item.completedDates[dateISO];
  saveState();
  renderScheduleDashboard();
  renderScheduleEvaluationPage();
}

function openScheduleModal(editId = null) {
  const form = document.getElementById("schedule-form");
  form.reset();
  document.getElementById("sched-id").value = "";

  if (editId) {
    const item = appState.schedules.find((s) => s.id === editId);
    if (!item) return;
    document.getElementById("modal-schedule-title").textContent = "Edit Jadwal Kegiatan";
    document.getElementById("sched-id").value = item.id;
    document.getElementById("sched-title").value = item.title;
    document.getElementById("sched-category").value = item.category;
    document.getElementById("sched-date").value = item.date;
    document.getElementById("sched-start-time").value = item.startTime;
    document.getElementById("sched-end-time").value = item.endTime;
    document.getElementById("sched-repeat").value = item.repeat;
    document.getElementById("sched-priority").checked = Boolean(item.priority);
    document.getElementById("sched-notes").value = item.notes || "";
  } else {
    document.getElementById("modal-schedule-title").textContent = "Tambah Jadwal Kegiatan";
    document.getElementById("sched-date").value = document.getElementById("sched-filter-date").value || getTodayISO();
    document.getElementById("sched-start-time").value = "08:00";
    document.getElementById("sched-end-time").value = "09:00";
  }
  openModal("modal-schedule");
}

function saveScheduleItem(e) {
  e.preventDefault();
  const id = document.getElementById("sched-id").value;
  const payload = {
    title: document.getElementById("sched-title").value.trim(),
    category: document.getElementById("sched-category").value,
    date: document.getElementById("sched-date").value,
    startTime: document.getElementById("sched-start-time").value,
    endTime: document.getElementById("sched-end-time").value,
    repeat: document.getElementById("sched-repeat").value,
    priority: document.getElementById("sched-priority").checked,
    notes: document.getElementById("sched-notes").value.trim()
  };

  if (id) {
    const idx = appState.schedules.findIndex((s) => s.id === id);
    if (idx !== -1) {
      appState.schedules[idx] = { ...appState.schedules[idx], ...payload };
    }
    showToast("Jadwal berhasil diperbarui!");
  } else {
    appState.schedules.push({
      id: "sch-" + Date.now(),
      ...payload,
      completedDates: {}
    });
    showToast("Jadwal baru berhasil ditambahkan!");
  }

  saveState();
  closeModal("modal-schedule");
  renderScheduleDashboard();
  renderScheduleEvaluationPage();
}

function deleteScheduleItem(id) {
  if (!confirm("Hapus jadwal kegiatan ini?")) return;
  appState.schedules = appState.schedules.filter((s) => s.id !== id);
  saveState();
  renderScheduleDashboard();
  renderScheduleEvaluationPage();
  showToast("Jadwal dihapus.");
}

function openPriorityModal() {
  const today = getTodayISO();
  const priorities = appState.schedules.filter((s) => s.priority);
  const box = document.getElementById("priority-modal-list");
  if (!priorities.length) {
    box.innerHTML = `<p class="muted-text">Belum ada jadwal yang ditandai sebagai Prioritas.</p>`;
  } else {
    box.innerHTML = priorities
      .map(
        (p) => `
        <div class="tx-row-item">
          <div>
            <strong><i class="fa-solid fa-bell text-warning"></i> ${p.title}</strong>
            <small>${p.startTime} - ${p.endTime} • Kategori: ${p.category} • Mulai: ${formatDateID(p.date)}</small>
          </div>
          <span class="status-badge ${p.completedDates && p.completedDates[today] ? "paid" : "warn"}">
            ${p.completedDates && p.completedDates[today] ? "Selesai Hari Ini" : "Aktif"}
          </span>
        </div>
      `
      )
      .join("");
  }
  openModal("modal-priority");
}

function checkPriorityReminders(currentHHMM) {
  const today = getTodayISO();
  const key = `${today}_${currentHHMM}`;
  if (remindedThisMinute[key]) return;
  remindedThisMinute[key] = true;

  const duePriorities = getSchedulesForDate(today).filter(
    (s) => s.priority && s.startTime === currentHHMM && !(s.completedDates && s.completedDates[today])
  );
  duePriorities.forEach((item) => {
    showToast(`PENGINGAT PRIORITAS (${item.startTime}): ${item.title}`);
  });
}

function getThemeChartColors() {
  const cs = getComputedStyle(document.documentElement);
  return {
    primary: cs.getPropertyValue("--primary").trim() || "#2563eb",
    secondary: cs.getPropertyValue("--secondary").trim() || "#0ea5e9",
    success: cs.getPropertyValue("--success").trim() || "#10b981",
    danger: cs.getPropertyValue("--danger").trim() || "#ef4444",
    text: cs.getPropertyValue("--text-muted").trim() || "#64748b",
    grid: cs.getPropertyValue("--border-color").trim() || "#e2e8f0"
  };
}

function renderScheduleCharts() {
  const c = getThemeChartColors();

  // 1. Combo Bar & Line Chart (Last 7 days)
  const labels7 = [];
  const total7 = [];
  const done7 = [];

  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const offset = d.getTimezoneOffset() * 60000;
    const iso = new Date(d.getTime() - offset).toISOString().split("T")[0];
    const items = getSchedulesForDate(iso);
    const done = items.filter((s) => s.completedDates && s.completedDates[iso]).length;
    labels7.push(formatDateID(iso));
    total7.push(items.length);
    done7.push(done);
  }

  if (charts.schedCombo) charts.schedCombo.destroy();
  const ctxCombo = document.getElementById("chart-sched-combo");
  if (ctxCombo) {
    charts.schedCombo = new Chart(ctxCombo, {
      data: {
        labels: labels7,
        datasets: [
          {
            type: "bar",
            label: "Total Jadwal",
            data: total7,
            backgroundColor: c.primary + "55",
            borderColor: c.primary,
            borderWidth: 1,
            borderRadius: 6
          },
          {
            type: "line",
            label: "Jadwal Selesai",
            data: done7,
            borderColor: c.success,
            backgroundColor: c.success,
            tension: 0.35,
            fill: false,
            pointRadius: 4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: c.text } } },
        scales: {
          x: { ticks: { color: c.text }, grid: { color: c.grid } },
          y: { beginAtZero: true, ticks: { stepSize: 1, color: c.text }, grid: { color: c.grid } }
        }
      }
    });
  }

  // 2. Evaluation Line Chart (Weekly or Monthly)
  const mode = document.getElementById("sched-eval-chart-mode").value;
  let evalLabels = [];
  let evalRates = [];

  if (mode === "weekly") {
    evalLabels = ["Minggu 1", "Minggu 2", "Minggu 3", "Minggu 4"];
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    for (let w = 0; w < 4; w++) {
      let tot = 0;
      let dn = 0;
      for (let day = w * 7 + 1; day <= (w + 1) * 7 && day <= 28; day++) {
        const iso = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
        const list = getSchedulesForDate(iso);
        tot += list.length;
        dn += list.filter((s) => s.completedDates && s.completedDates[iso]).length;
      }
      evalRates.push(tot > 0 ? Math.round((dn / tot) * 100) : 0);
    }
  } else {
    const monthsShort = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
    evalLabels = monthsShort;
    const year = new Date().getFullYear();
    for (let m = 0; m < 12; m++) {
      let tot = 0;
      let dn = 0;
      const daysInMonth = new Date(year, m + 1, 0).getDate();
      for (let d = 1; d <= daysInMonth; d++) {
        const iso = `${year}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
        const list = getSchedulesForDate(iso);
        tot += list.length;
        dn += list.filter((s) => s.completedDates && s.completedDates[iso]).length;
      }
      evalRates.push(tot > 0 ? Math.round((dn / tot) * 100) : 0);
    }
  }

  if (charts.schedEval) charts.schedEval.destroy();
  const ctxEval = document.getElementById("chart-sched-eval");
  if (ctxEval) {
    charts.schedEval = new Chart(ctxEval, {
      type: "line",
      data: {
        labels: evalLabels,
        datasets: [
          {
            label: "Persentase Capaian (%)",
            data: evalRates,
            borderColor: c.secondary,
            backgroundColor: c.secondary + "25",
            fill: true,
            tension: 0.35,
            pointRadius: 4
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: c.text } } },
        scales: {
          x: { ticks: { color: c.text }, grid: { color: c.grid } },
          y: { beginAtZero: true, max: 100, ticks: { color: c.text }, grid: { color: c.grid } }
        }
      }
    });
  }
}

function renderScheduleEvaluationPage() {
  // Weekly breakdown (current 7-day window)
  const weeklyBody = document.getElementById("eval-weekly-table");
  let wTotal = 0;
  let wDone = 0;
  let wRows = "";

  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const offset = d.getTimezoneOffset() * 60000;
    const iso = new Date(d.getTime() - offset).toISOString().split("T")[0];
    const list = getSchedulesForDate(iso);
    const dn = list.filter((s) => s.completedDates && s.completedDates[iso]).length;
    const pct = list.length ? Math.round((dn / list.length) * 100) : 0;

    wTotal += list.length;
    wDone += dn;

    wRows += `
      <tr>
        <td>${formatDateID(iso)}</td>
        <td>${list.length}</td>
        <td class="text-success">${dn}</td>
        <td class="text-danger">${list.length - dn}</td>
        <td><strong>${pct}%</strong></td>
      </tr>
    `;
  }
  weeklyBody.innerHTML = wRows;
  document.getElementById("eval-week-total").textContent = wTotal;
  document.getElementById("eval-week-sub").textContent = `${wDone} selesai minggu ini`;
  document.getElementById("eval-week-rate").textContent = `${wTotal ? Math.round((wDone / wTotal) * 100) : 0}%`;

  // Monthly breakdown
  const monthsFull = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  const now = new Date();
  const year = now.getFullYear();
  const curMonth = now.getMonth();
  let mRows = "";

  for (let m = 0; m < 12; m++) {
    let tot = 0;
    let dn = 0;
    const daysInMonth = new Date(year, m + 1, 0).getDate();
    for (let d = 1; d <= daysInMonth; d++) {
      const iso = `${year}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      const list = getSchedulesForDate(iso);
      tot += list.length;
      dn += list.filter((s) => s.completedDates && s.completedDates[iso]).length;
    }
    const pct = tot ? Math.round((dn / tot) * 100) : 0;
    if (m === curMonth) {
      document.getElementById("eval-month-total").textContent = tot;
      document.getElementById("eval-month-sub").textContent = `${dn} selesai bulan ini`;
      document.getElementById("eval-month-rate").textContent = `${pct}%`;
    }
    mRows += `
      <tr>
        <td>${monthsFull[m]} ${year}</td>
        <td>${tot}</td>
        <td class="text-success">${dn}</td>
        <td><strong>${pct}%</strong></td>
      </tr>
    `;
  }
  document.getElementById("eval-monthly-table").innerHTML = mRows;

  // Category chips
  const chipsEl = document.getElementById("sched-category-chips");
  chipsEl.innerHTML = appState.scheduleCategories
    .map(
      (cat, idx) => `
      <span class="cat-chip">
        ${cat}
        <button type="button" title="Hapus Kategori" onclick="deleteScheduleCategory(${idx})">
          <i class="fa-solid fa-xmark"></i>
        </button>
      </span>
    `
    )
    .join("");
}

function addScheduleCategory(e) {
  e.preventDefault();
  const inp = document.getElementById("new-sched-cat-input");
  const val = inp.value.trim();
  if (!val) return;
  if (!appState.scheduleCategories.includes(val)) {
    appState.scheduleCategories.push(val);
    saveState();
    populateAllDropdowns();
    renderScheduleEvaluationPage();
    showToast(`Kategori "${val}" ditambahkan!`);
  }
  inp.value = "";
}

function deleteScheduleCategory(index) {
  if (appState.scheduleCategories.length <= 1) {
    showToast("Minimal harus tersisa 1 kategori kegiatan.");
    return;
  }
  appState.scheduleCategories.splice(index, 1);
  saveState();
  populateAllDropdowns();
  renderScheduleEvaluationPage();
}

function exportSchedulesToExcel() {
  if (typeof XLSX === "undefined") {
    showToast("Library Excel sedang dimuat, coba sesaat lagi.");
    return;
  }
  const today = getTodayISO();
  const rows = appState.schedules.map((s, idx) => ({
    No: idx + 1,
    Kegiatan: s.title,
    Kategori: s.category,
    Tanggal_Mulai: s.date,
    Waktu_Mulai: s.startTime,
    Waktu_Selesai: s.endTime,
    Pengulangan: s.repeat,
    Prioritas: s.priority ? "Ya" : "Tidak",
    Status_Hari_Ini: s.completedDates && s.completedDates[today] ? "Selesai" : "Belum Selesai",
    Catatan: s.notes || ""
  }));

  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Jadwal_Harian");
  XLSX.writeFile(wb, `Jadwal_Harian_${today}.xlsx`);
  showToast("File Excel Jadwal Harian otomatis terdownload!");
}

function importSchedulesFromExcel(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array" });
      const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
      const jsonRows = XLSX.utils.sheet_to_json(firstSheet);

      let importedCount = 0;
      jsonRows.forEach((row) => {
        const title = row.Kegiatan || row.Title || row.Nama_Kegiatan;
        if (title) {
          appState.schedules.push({
            id: "sch-" + Date.now() + "-" + importedCount,
            title: String(title),
            category: row.Kategori || appState.scheduleCategories[0],
            date: row.Tanggal_Mulai || getTodayISO(),
            startTime: row.Waktu_Mulai || "08:00",
            endTime: row.Waktu_Selesai || "09:00",
            repeat: row.Pengulangan || "none",
            priority: String(row.Prioritas || "").toLowerCase() === "ya",
            notes: row.Catatan || "",
            completedDates: {}
          });
          importedCount++;
        }
      });

      saveState();
      renderScheduleDashboard();
      renderScheduleEvaluationPage();
      showToast(`Berhasil mengimpor ${importedCount} jadwal dari Excel!`);
    } catch (err) {
      showToast("Format file Excel tidak sesuai.");
    }
    event.target.value = "";
  };
  reader.readAsArrayBuffer(file);
}

/* ==========================================================================
   MODULE 2: CASH FLOW (ACCOUNTS, TRANSACTIONS, TRANSFERS, BUDGET, DEBTS)
   ========================================================================== */
function calculateAccountBalance(accountId) {
  const acc = appState.accounts.find((a) => a.id === accountId);
  if (!acc) return 0;
  let bal = Number(acc.initialBalance) || 0;

  appState.transactions.forEach((tx) => {
    if (tx.accountId === accountId) {
      if (tx.type === "income") bal += Number(tx.amount);
      else if (tx.type === "expense") bal -= Number(tx.amount);
    }
  });

  appState.transfers.forEach((trf) => {
    if (trf.fromAccountId === accountId) {
      bal -= Number(trf.amount) + (Number(trf.fee) || 0);
    }
    if (trf.toAccountId === accountId) {
      bal += Number(trf.amount);
    }
  });

  return bal;
}

function getAccountName(accountId) {
  const acc = appState.accounts.find((a) => a.id === accountId);
  return acc ? acc.name : "Akun Dihapus";
}

function renderCashFlowDashboard() {
  const totalBalance = appState.accounts.reduce((sum, a) => sum + calculateAccountBalance(a.id), 0);
  const totalIncome = appState.transactions
    .filter((t) => t.type === "income")
    .reduce((sum, t) => sum + Number(t.amount), 0);
  const totalExpense = appState.transactions
    .filter((t) => t.type === "expense")
    .reduce((sum, t) => sum + Number(t.amount), 0);
  const netProfit = totalIncome - totalExpense;

  document.getElementById("cf-total-balance").textContent = formatMoney(totalBalance);
  document.getElementById("cf-total-income").textContent = formatMoney(totalIncome);
  document.getElementById("cf-total-expense").textContent = formatMoney(totalExpense);
  document.getElementById("cf-net-profit").textContent = formatMoney(netProfit);

  // Daily, Weekly, Monthly summaries
  const today = getTodayISO();
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoISO = weekAgo.toISOString().split("T")[0];
  const monthPrefix = today.substring(0, 7);

  const calcRange = (predicate) => {
    let inc = 0;
    let exp = 0;
    appState.transactions.filter(predicate).forEach((t) => {
      if (t.type === "income") inc += Number(t.amount);
      else exp += Number(t.amount);
    });
    return { inc, exp, net: inc - exp };
  };

  const daySum = calcRange((t) => t.date === today);
  const weekSum = calcRange((t) => t.date >= weekAgoISO && t.date <= today);
  const monthSum = calcRange((t) => t.date.startsWith(monthPrefix));

  document.getElementById("cf-sum-day-in").textContent = formatMoney(daySum.inc);
  document.getElementById("cf-sum-day-out").textContent = formatMoney(daySum.exp);
  document.getElementById("cf-sum-day-net").textContent = formatMoney(daySum.net);

  document.getElementById("cf-sum-week-in").textContent = formatMoney(weekSum.inc);
  document.getElementById("cf-sum-week-out").textContent = formatMoney(weekSum.exp);
  document.getElementById("cf-sum-week-net").textContent = formatMoney(weekSum.net);

  document.getElementById("cf-sum-month-in").textContent = formatMoney(monthSum.inc);
  document.getElementById("cf-sum-month-out").textContent = formatMoney(monthSum.exp);
  document.getElementById("cf-sum-month-net").textContent = formatMoney(monthSum.net);

  // Recent Transactions
  const recentBox = document.getElementById("cf-recent-transactions");
  const sortedTx = [...appState.transactions].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 8);
  recentBox.innerHTML = sortedTx.length
    ? sortedTx
        .map(
          (t) => `
        <div class="tx-row-item">
          <div>
            <strong>${t.note}</strong>
            <small>${formatDateID(t.date)} • ${t.category} • ${getAccountName(t.accountId)}</small>
          </div>
          <strong class="${t.type === "income" ? "text-success" : "text-danger"}">
            ${t.type === "income" ? "+" : "-"}${formatMoney(t.amount)}
          </strong>
        </div>
      `
        )
        .join("")
    : `<p class="muted-text">Belum ada transaksi tercatat.</p>`;

  // Cash Flow Chart (Last 6 Months)
  const c = getThemeChartColors();
  const monthsShort = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
  const mLabels = [];
  const mInData = [];
  const mOutData = [];

  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
    mLabels.push(`${monthsShort[d.getMonth()]} ${d.getFullYear()}`);
    const inSum = appState.transactions
      .filter((t) => t.type === "income" && t.date.startsWith(ym))
      .reduce((s, t) => s + Number(t.amount), 0);
    const outSum = appState.transactions
      .filter((t) => t.type === "expense" && t.date.startsWith(ym))
      .reduce((s, t) => s + Number(t.amount), 0);
    mInData.push(inSum);
    mOutData.push(outSum);
  }

  if (charts.cfMain) charts.cfMain.destroy();
  const ctxCf = document.getElementById("chart-cf-main");
  if (ctxCf) {
    charts.cfMain = new Chart(ctxCf, {
      type: "bar",
      data: {
        labels: mLabels,
        datasets: [
          { label: "Pemasukan", data: mInData, backgroundColor: c.success, borderRadius: 6 },
          { label: "Pengeluaran", data: mOutData, backgroundColor: c.danger, borderRadius: 6 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { labels: { color: c.text } } },
        scales: {
          x: { ticks: { color: c.text }, grid: { color: c.grid } },
          y: { beginAtZero: true, ticks: { color: c.text }, grid: { color: c.grid } }
        }
      }
    });
  }
}

/* ---------- INCOME & EXPENSE CRUD + RECEIPT UPLOAD ---------- */
function openTransactionModal(type, editId = null) {
  document.getElementById("transaction-form").reset();
  document.getElementById("tx-id").value = "";
  document.getElementById("tx-type").value = type;
  tempReceiptBase64 = "";
  document.getElementById("tx-receipt-preview-box").classList.add("hidden");

  const catSelect = document.getElementById("tx-category");
  const cats = type === "income" ? appState.incomeCategories : appState.expenseCategories;
  catSelect.innerHTML = cats.map((c) => `<option value="${c}">${c}</option>`).join("");

  const accSelect = document.getElementById("tx-account");
  accSelect.innerHTML = appState.accounts
    .map((a) => `<option value="${a.id}">${a.name} (${formatMoney(calculateAccountBalance(a.id))})</option>`)
    .join("");

  if (editId) {
    const tx = appState.transactions.find((t) => t.id === editId);
    if (!tx) return;
    document.getElementById("modal-tx-title").textContent =
      type === "income" ? "Edit Pemasukan" : "Edit Pengeluaran";
    document.getElementById("tx-id").value = tx.id;
    document.getElementById("tx-date").value = tx.date;
    document.getElementById("tx-category").value = tx.category;
    document.getElementById("tx-account").value = tx.accountId;
    document.getElementById("tx-amount").value = tx.amount;
    document.getElementById("tx-note").value = tx.note;
    if (tx.receipt) {
      tempReceiptBase64 = tx.receipt;
      document.getElementById("tx-receipt-preview-img").src = tx.receipt;
      document.getElementById("tx-receipt-preview-box").classList.remove("hidden");
    }
  } else {
    document.getElementById("modal-tx-title").textContent =
      type === "income" ? "Tambah Pemasukan" : "Tambah Pengeluaran";
    document.getElementById("tx-date").value = getTodayISO();
  }
  openModal("modal-transaction");
}

function previewReceiptUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      const maxW = 750;
      const scale = Math.min(1, maxW / img.width);
      canvas.width = img.width * scale;
      canvas.height = img.height * scale;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      tempReceiptBase64 = canvas.toDataURL("image/jpeg", 0.72);
      document.getElementById("tx-receipt-preview-img").src = tempReceiptBase64;
      document.getElementById("tx-receipt-preview-box").classList.remove("hidden");
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

function clearReceiptUpload() {
  tempReceiptBase64 = "";
  document.getElementById("tx-receipt-file").value = "";
  document.getElementById("tx-receipt-preview-box").classList.add("hidden");
}

function viewReceiptFull(base64) {
  document.getElementById("receipt-full-image").src = base64;
  openModal("modal-receipt-view");
}

function saveTransactionItem(e) {
  e.preventDefault();
  const id = document.getElementById("tx-id").value;
  const type = document.getElementById("tx-type").value;
  const payload = {
    type,
    date: document.getElementById("tx-date").value,
    category: document.getElementById("tx-category").value,
    accountId: document.getElementById("tx-account").value,
    amount: Number(document.getElementById("tx-amount").value),
    note: document.getElementById("tx-note").value.trim(),
    receipt: tempReceiptBase64
  };

  if (id) {
    const idx = appState.transactions.findIndex((t) => t.id === id);
    if (idx !== -1) appState.transactions[idx] = { ...appState.transactions[idx], ...payload };
    showToast("Transaksi berhasil diperbarui!");
  } else {
    appState.transactions.push({ id: "tx-" + Date.now(), ...payload });
    showToast(type === "income" ? "Pemasukan berhasil dicatat!" : "Pengeluaran berhasil dicatat!");
  }

  saveState();
  closeModal("modal-transaction");
  refreshAllViews();

  if (type === "expense") {
    checkBudgetAlertForCategory(payload.category);
  }
}

function deleteTransactionItem(id) {
  if (!confirm("Hapus transaksi ini? Saldo akun akan otomatis disesuaikan.")) return;
  appState.transactions = appState.transactions.filter((t) => t.id !== id);
  saveState();
  refreshAllViews();
  showToast("Transaksi dihapus.");
}

function renderTransactionTable(type) {
  const searchVal = document.getElementById(`${type}-search`).value.toLowerCase();
  const catVal = document.getElementById(`${type}-cat-filter`).value;
  const tbody = document.getElementById(`${type}-table-body`);

  const list = appState.transactions
    .filter((t) => t.type === type)
    .filter((t) => (catVal === "ALL" ? true : t.category === catVal))
    .filter((t) => t.note.toLowerCase().includes(searchVal) || t.category.toLowerCase().includes(searchVal))
    .sort((a, b) => b.date.localeCompare(a.date));

  if (!list.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="muted-text">Belum ada data transaksi ${type === "income" ? "pemasukan" : "pengeluaran"}.</td></tr>`;
    return;
  }

  tbody.innerHTML = list
    .map(
      (t) => `
      <tr>
        <td>${formatDateID(t.date)}</td>
        <td><span class="pill-tag">${t.category}</span></td>
        <td>${getAccountName(t.accountId)}</td>
        <td>${t.note}</td>
        <td><strong class="${type === "income" ? "text-success" : "text-danger"}">${formatMoney(t.amount)}</strong></td>
        <td>
          ${
            t.receipt
              ? `<button class="btn btn-sm btn-outline" onclick="viewReceiptFull('${t.receipt}')"><i class="fa-solid fa-image"></i> Lihat</button>`
              : `<span class="muted-text">-</span>`
          }
        </td>
        <td>
          <button class="icon-btn" onclick="openTransactionModal('${type}', '${t.id}')"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn danger" onclick="deleteTransactionItem('${t.id}')"><i class="fa-solid fa-trash"></i></button>
        </td>
      </tr>
    `
    )
    .join("");
}

/* ---------- TRANSFER DANA ---------- */
function openTransferModal(editId = null) {
  document.getElementById("transfer-form").reset();
  document.getElementById("trf-id").value = "";
  const opts = appState.accounts
    .map((a) => `<option value="${a.id}">${a.name} (${formatMoney(calculateAccountBalance(a.id))})</option>`)
    .join("");
  document.getElementById("trf-from").innerHTML = opts;
  document.getElementById("trf-to").innerHTML = opts;

  if (editId) {
    const trf = appState.transfers.find((x) => x.id === editId);
    if (!trf) return;
    document.getElementById("modal-transfer-title").textContent = "Edit Transfer Dana";
    document.getElementById("trf-id").value = trf.id;
    document.getElementById("trf-from").value = trf.fromAccountId;
    document.getElementById("trf-to").value = trf.toAccountId;
    document.getElementById("trf-amount").value = trf.amount;
    document.getElementById("trf-fee").value = trf.fee || 0;
    document.getElementById("trf-date").value = trf.date;
    document.getElementById("trf-note").value = trf.note || "";
  } else {
    document.getElementById("modal-transfer-title").textContent = "Transfer Dana Antar Akun";
    document.getElementById("trf-date").value = getTodayISO();
    if (appState.accounts.length > 1) {
      document.getElementById("trf-to").selectedIndex = 1;
    }
  }
  openModal("modal-transfer");
}

function saveTransferItem(e) {
  e.preventDefault();
  const id = document.getElementById("trf-id").value;
  const fromAccountId = document.getElementById("trf-from").value;
  const toAccountId = document.getElementById("trf-to").value;

  if (fromAccountId === toAccountId) {
    showToast("Akun sumber dan akun tujuan tidak boleh sama!");
    return;
  }

  const payload = {
    fromAccountId,
    toAccountId,
    amount: Number(document.getElementById("trf-amount").value),
    fee: Number(document.getElementById("trf-fee").value) || 0,
    date: document.getElementById("trf-date").value,
    note: document.getElementById("trf-note").value.trim() || "Transfer saldo antar akun"
  };

  if (id) {
    const idx = appState.transfers.findIndex((x) => x.id === id);
    if (idx !== -1) appState.transfers[idx] = { ...appState.transfers[idx], ...payload };
    showToast("Data transfer diperbarui!");
  } else {
    appState.transfers.push({ id: "trf-" + Date.now(), ...payload });
    showToast("Transfer dana berhasil dicatat!");
  }

  saveState();
  closeModal("modal-transfer");
  refreshAllViews();
}

function deleteTransferItem(id) {
  if (!confirm("Hapus riwayat transfer ini?")) return;
  appState.transfers = appState.transfers.filter((x) => x.id !== id);
  saveState();
  refreshAllViews();
  showToast("Riwayat transfer dihapus.");
}

function renderTransferTable() {
  const tbody = document.getElementById("transfer-table-body");
  const list = [...appState.transfers].sort((a, b) => b.date.localeCompare(a.date));
  if (!list.length) {
    tbody.innerHTML = `<tr><td colspan="7" class="muted-text">Belum ada riwayat transfer dana.</td></tr>`;
    return;
  }
  tbody.innerHTML = list
    .map(
      (t) => `
      <tr>
        <td>${formatDateID(t.date)}</td>
        <td><strong>${getAccountName(t.fromAccountId)}</strong></td>
        <td><strong>${getAccountName(t.toAccountId)}</strong></td>
        <td class="text-primary"><strong>${formatMoney(t.amount)}</strong></td>
        <td>${formatMoney(t.fee || 0)}</td>
        <td>${t.note}</td>
        <td>
          <button class="icon-btn" onclick="openTransferModal('${t.id}')"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn danger" onclick="deleteTransferItem('${t.id}')"><i class="fa-solid fa-trash"></i></button>
        </td>
      </tr>
    `
    )
    .join("");
}

/* ---------- AKUN / DOMPET ---------- */
function openAccountModal(editId = null) {
  document.getElementById("account-form").reset();
  document.getElementById("acc-id").value = "";

  if (editId) {
    const acc = appState.accounts.find((a) => a.id === editId);
    if (!acc) return;
    document.getElementById("modal-account-title").textContent = "Edit Akun / Dompet";
    document.getElementById("acc-id").value = acc.id;
    document.getElementById("acc-name").value = acc.name;
    document.getElementById("acc-type").value = acc.type;
    document.getElementById("acc-initial").value = acc.initialBalance;
    document.getElementById("acc-number").value = acc.number || "";
  } else {
    document.getElementById("modal-account-title").textContent = "Tambah Akun / Dompet";
  }
  openModal("modal-account");
}

function saveAccountItem(e) {
  e.preventDefault();
  const id = document.getElementById("acc-id").value;
  const payload = {
    name: document.getElementById("acc-name").value.trim(),
    type: document.getElementById("acc-type").value,
    initialBalance: Number(document.getElementById("acc-initial").value) || 0,
    number: document.getElementById("acc-number").value.trim() || "-"
  };

  if (id) {
    const idx = appState.accounts.findIndex((a) => a.id === id);
    if (idx !== -1) appState.accounts[idx] = { ...appState.accounts[idx], ...payload };
    showToast("Akun berhasil diperbarui!");
  } else {
    appState.accounts.push({ id: "acc-" + Date.now(), ...payload });
    showToast("Akun baru ditambahkan!");
  }

  saveState();
  closeModal("modal-account");
  refreshAllViews();
}

function deleteAccountItem(id) {
  if (appState.accounts.length <= 1) {
    showToast("Minimal harus ada 1 akun penyimpanan.");
    return;
  }
  if (!confirm("Hapus akun / dompet ini?")) return;
  appState.accounts = appState.accounts.filter((a) => a.id !== id);
  saveState();
  refreshAllViews();
  showToast("Akun dihapus.");
}

function renderAccountsGrid() {
  const grid = document.getElementById("accounts-card-grid");
  grid.innerHTML = appState.accounts
    .map((acc) => {
      const bal = calculateAccountBalance(acc.id);
      const iconClass =
        acc.type === "Bank" ? "fa-building-columns" : acc.type === "E-Wallet" ? "fa-mobile-screen-button" : "fa-money-bill-wave";
      return `
        <div class="account-card">
          <div class="account-card-top">
            <div>
              <span class="pill-tag"><i class="fa-solid ${iconClass}"></i> ${acc.type}</span>
              <h3 style="margin-top:0.25rem;">${acc.name}</h3>
            </div>
            <div>
              <button class="icon-btn" onclick="openAccountModal('${acc.id}')"><i class="fa-solid fa-pen"></i></button>
              <button class="icon-btn danger" onclick="deleteAccountItem('${acc.id}')"><i class="fa-solid fa-trash"></i></button>
            </div>
          </div>
          <div class="account-balance">${formatMoney(bal)}</div>
          <small class="muted-text">No/ID: ${acc.number || "-"} • Saldo Awal: ${formatMoney(acc.initialBalance)}</small>
        </div>
      `;
    })
    .join("");
}

/* ---------- LAPORAN KEUANGAN (8 JENIS, FILTER, PDF & EXCEL) ---------- */
function getFilteredReportTransactions() {
  const type = document.getElementById("report-type").value;
  const start = document.getElementById("report-date-start").value;
  const end = document.getElementById("report-date-end").value;
  const cat = document.getElementById("report-category-filter").value;

  const today = getTodayISO();
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);
  const weekAgoISO = weekAgo.toISOString().split("T")[0];
  const monthPrefix = today.substring(0, 7);
  const yearPrefix = today.substring(0, 4);

  return appState.transactions
    .filter((t) => {
      if (type === "income" && t.type !== "income") return false;
      if (type === "expense" && t.type !== "expense") return false;
      if (type === "daily" && t.date !== today) return false;
      if (type === "weekly" && !(t.date >= weekAgoISO && t.date <= today)) return false;
      if (type === "monthly" && !t.date.startsWith(monthPrefix)) return false;
      if (type === "yearly" && !t.date.startsWith(yearPrefix)) return false;

      if (start && t.date < start) return false;
      if (end && t.date > end) return false;
      if (cat !== "ALL" && t.category !== cat) return false;
      return true;
    })
    .sort((a, b) => b.date.localeCompare(a.date));
}

function renderFinancialReport() {
  const selectEl = document.getElementById("report-type");
  const reportLabel = selectEl.options[selectEl.selectedIndex].text;
  const start = document.getElementById("report-date-start").value;
  const end = document.getElementById("report-date-end").value;

  document.getElementById("report-display-title").textContent = reportLabel;
  document.getElementById("report-display-period").textContent =
    start || end ? `Periode: ${start || "Awal"} s/d ${end || "Sekarang"}` : "Periode: Sesuai Filter Laporan";

  const rows = getFilteredReportTransactions();
  const sumIn = rows.filter((r) => r.type === "income").reduce((s, r) => s + Number(r.amount), 0);
  const sumOut = rows.filter((r) => r.type === "expense").reduce((s, r) => s + Number(r.amount), 0);
  const net = sumIn - sumOut;

  document.getElementById("rep-sum-in").textContent = formatMoney(sumIn);
  document.getElementById("rep-sum-out").textContent = formatMoney(sumOut);
  document.getElementById("rep-sum-net").textContent = formatMoney(net);

  // Profit & Loss special breakdown
  const pnlBox = document.getElementById("pnl-breakdown-box");
  if (selectEl.value === "pnl") {
    pnlBox.classList.remove("hidden");
    pnlBox.innerHTML = `
      <h4 style="margin-bottom:0.5rem;">Ringkasan Laba & Rugi</h4>
      <div class="period-row"><span>Total Pendapatan Kotor:</span><strong class="text-success">${formatMoney(sumIn)}</strong></div>
      <div class="period-row"><span>Total Beban & Pengeluaran:</span><strong class="text-danger">${formatMoney(sumOut)}</strong></div>
      <div class="period-row total"><span>${net >= 0 ? "LABA BERSIH:" : "RUGI BERSIH:"}</span>
        <strong class="${net >= 0 ? "text-success" : "text-danger"}">${formatMoney(net)}</strong>
      </div>
    `;
  } else {
    pnlBox.classList.add("hidden");
  }

  const tbody = document.getElementById("report-table-body");
  if (!rows.length) {
    tbody.innerHTML = `<tr><td colspan="6" class="muted-text">Tidak ada transaksi yang cocok dengan filter laporan.</td></tr>`;
    return;
  }

  tbody.innerHTML = rows
    .map(
      (r) => `
      <tr>
        <td>${formatDateID(r.date)}</td>
        <td><span class="status-badge ${r.type === "income" ? "paid" : "unpaid"}">${r.type === "income" ? "Pemasukan" : "Pengeluaran"}</span></td>
        <td>${r.category}</td>
        <td>${getAccountName(r.accountId)}</td>
        <td>${r.note}</td>
        <td><strong class="${r.type === "income" ? "text-success" : "text-danger"}">${formatMoney(r.amount)}</strong></td>
      </tr>
    `
    )
    .join("");
}

function printFinancialReport() {
  window.print();
}

function exportFinancialReportExcel() {
  if (typeof XLSX === "undefined") {
    showToast("Library Excel sedang dimuat, silakan coba lagi.");
    return;
  }
  const rows = getFilteredReportTransactions().map((r, i) => ({
    No: i + 1,
    Tanggal: r.date,
    Jenis: r.type === "income" ? "Pemasukan" : "Pengeluaran",
    Kategori: r.category,
    Akun: getAccountName(r.accountId),
    Keterangan: r.note,
    Nominal: Number(r.amount)
  }));

  const ws = XLSX.utils.json_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Laporan_Keuangan");
  XLSX.writeFile(wb, `Laporan_Keuangan_${getTodayISO()}.xlsx`);
  showToast("Laporan Keuangan Excel berhasil di-download!");
}

/* ---------- ANGGARAN (BUDGET) + NOTIFIKASI BATAS ---------- */
function openBudgetModal() {
  document.getElementById("budget-form").reset();
  openModal("modal-budget");
}

function saveBudgetItem(e) {
  e.preventDefault();
  const category = document.getElementById("bud-category").value;
  const limit = Number(document.getElementById("bud-limit").value);

  const idx = appState.budgets.findIndex((b) => b.category === category);
  if (idx !== -1) appState.budgets[idx].limit = limit;
  else appState.budgets.push({ category, limit });

  saveState();
  closeModal("modal-budget");
  renderBudgetView();
  checkBudgetAlertForCategory(category);
  showToast(`Anggaran ${category} berhasil disimpan!`);
}

function deleteBudgetItem(category) {
  appState.budgets = appState.budgets.filter((b) => b.category !== category);
  saveState();
  renderBudgetView();
}

function getMonthlySpentForCategory(category) {
  const monthPrefix = getTodayISO().substring(0, 7);
  return appState.transactions
    .filter((t) => t.type === "expense" && t.category === category && t.date.startsWith(monthPrefix))
    .reduce((sum, t) => sum + Number(t.amount), 0);
}

function checkBudgetAlertForCategory(category) {
  const b = appState.budgets.find((x) => x.category === category);
  if (!b) return;
  const spent = getMonthlySpentForCategory(category);
  const ratio = (spent / b.limit) * 100;
  if (ratio >= 100) {
    showToast(`PERINGATAN ANGGARAN: Pengeluaran "${category}" telah MELEWATI batas (${Math.round(ratio)}%)!`);
  } else if (ratio >= 80) {
    showToast(`NOTIFIKASI ANGGARAN: Pengeluaran "${category}" mendekati batas (${Math.round(ratio)}%)!`);
  }
}

function renderBudgetView() {
  const alertsBox = document.getElementById("budget-alerts-container");
  const grid = document.getElementById("budget-cards-grid");

  let alertHTML = "";
  let cardsHTML = "";

  appState.budgets.forEach((b) => {
    const spent = getMonthlySpentForCategory(b.category);
    const pct = b.limit > 0 ? Math.round((spent / b.limit) * 100) : 0;
    const clamped = Math.min(100, pct);
    const rem = b.limit - spent;

    if (pct >= 100) {
      alertHTML += `<div class="budget-alert-banner danger"><i class="fa-solid fa-triangle-exclamation"></i> Anggaran <strong>${b.category}</strong> telah melewati batas! Terpakai ${formatMoney(spent)} dari ${formatMoney(b.limit)} (${pct}%).</div>`;
    } else if (pct >= 80) {
      alertHTML += `<div class="budget-alert-banner warning"><i class="fa-solid fa-circle-exclamation"></i> Anggaran <strong>${b.category}</strong> mendekati batas (${pct}%). Sisa anggaran: ${formatMoney(rem)}.</div>`;
    }

    cardsHTML += `
      <div class="budget-card">
        <div class="card-header">
          <h3>${b.category}</h3>
          <button class="icon-btn danger" onclick="deleteBudgetItem('${b.category}')"><i class="fa-solid fa-trash"></i></button>
        </div>
        <div class="period-row"><span>Batas Bulanan:</span><strong>${formatMoney(b.limit)}</strong></div>
        <div class="period-row"><span>Terpakai Bulan Ini:</span><strong class="${pct >= 100 ? "text-danger" : ""}">${formatMoney(spent)} (${pct}%)</strong></div>
        <div class="period-row"><span>Sisa Anggaran:</span><strong class="${rem < 0 ? "text-danger" : "text-success"}">${formatMoney(rem)}</strong></div>
        <div class="progress-track" style="margin-top:0.65rem;">
          <div class="progress-fill" style="width:${clamped}%; background:${pct >= 100 ? "var(--danger)" : pct >= 80 ? "var(--warning)" : "var(--primary)"};"></div>
        </div>
      </div>
    `;
  });

  alertsBox.innerHTML = alertHTML;
  grid.innerHTML = cardsHTML || `<p class="muted-text">Belum ada anggaran bulanan diatur.</p>`;
}

/* ---------- HUTANG DAN PIUTANG + RIWAYAT PEMBAYARAN ---------- */
function openDebtModal(kind, editId = null) {
  document.getElementById("debt-form").reset();
  document.getElementById("debt-id").value = "";
  document.getElementById("debt-kind").value = kind;

  if (editId) {
    const d = appState.debts.find((x) => x.id === editId);
    if (!d) return;
    document.getElementById("modal-debt-title").textContent = d.kind === "payable" ? "Edit Hutang" : "Edit Piutang";
    document.getElementById("debt-id").value = d.id;
    document.getElementById("debt-kind").value = d.kind;
    document.getElementById("debt-person").value = d.person;
    document.getElementById("debt-amount").value = d.amount;
    document.getElementById("debt-status").value = d.status;
    document.getElementById("debt-date").value = d.date;
    document.getElementById("debt-due").value = d.dueDate;
    document.getElementById("debt-note").value = d.note || "";
  } else {
    document.getElementById("modal-debt-title").textContent = kind === "payable" ? "Tambah Data Hutang" : "Tambah Data Piutang";
    document.getElementById("debt-date").value = getTodayISO();
    document.getElementById("debt-due").value = getTodayISO();
  }
  openModal("modal-debt");
}

function saveDebtItem(e) {
  e.preventDefault();
  const id = document.getElementById("debt-id").value;
  const payload = {
    kind: document.getElementById("debt-kind").value,
    person: document.getElementById("debt-person").value.trim(),
    amount: Number(document.getElementById("debt-amount").value),
    status: document.getElementById("debt-status").value,
    date: document.getElementById("debt-date").value,
    dueDate: document.getElementById("debt-due").value,
    note: document.getElementById("debt-note").value.trim()
  };

  if (id) {
    const idx = appState.debts.findIndex((x) => x.id === id);
    if (idx !== -1) appState.debts[idx] = { ...appState.debts[idx], ...payload };
    showToast("Data hutang/piutang diperbarui!");
  } else {
    appState.debts.push({ id: "dbt-" + Date.now(), ...payload, payments: [] });
    showToast("Data berhasil disimpan!");
  }

  saveState();
  closeModal("modal-debt");
  renderDebtsTable();
}

function deleteDebtItem(id) {
  if (!confirm("Hapus catatan hutang/piutang ini?")) return;
  appState.debts = appState.debts.filter((x) => x.id !== id);
  saveState();
  renderDebtsTable();
  showToast("Catatan dihapus.");
}

function openDebtPaymentModal(debtId) {
  const d = appState.debts.find((x) => x.id === debtId);
  if (!d) return;

  document.getElementById("debt-pay-target-id").value = d.id;
  document.getElementById("debt-pay-date").value = getTodayISO();
  document.getElementById("debt-pay-amount").value = "";
  document.getElementById("debt-pay-note").value = "";
  document.getElementById("debt-pay-account").innerHTML = appState.accounts
    .map((a) => `<option value="${a.id}">${a.name}</option>`)
    .join("");

  const paidSum = (d.payments || []).reduce((s, p) => s + Number(p.amount), 0);
  const rem = Math.max(0, Number(d.amount) - paidSum);

  document.getElementById("debt-pay-modal-title").textContent =
    `${d.kind === "payable" ? "Pembayaran Hutang" : "Penerimaan Piutang"} — ${d.person}`;
  document.getElementById("debt-pay-summary").innerHTML = `
    <div class="period-row"><span>Total Nominal:</span><strong>${formatMoney(d.amount)}</strong></div>
    <div class="period-row"><span>Sudah Dibayar:</span><strong class="text-success">${formatMoney(paidSum)}</strong></div>
    <div class="period-row total"><span>Sisa Tagihan:</span><strong class="text-danger">${formatMoney(rem)}</strong></div>
  `;

  const histBox = document.getElementById("debt-payment-history-list");
  histBox.innerHTML = (d.payments || []).length
    ? d.payments
        .map(
          (p) => `
        <div class="tx-row-item">
          <div>
            <strong>${formatMoney(p.amount)}</strong>
            <small>${formatDateID(p.date)} • ${getAccountName(p.accountId)} • ${p.note || "Pembayaran"}</small>
          </div>
          <span class="status-badge paid">Tercatat</span>
        </div>
      `
        )
        .join("")
    : `<p class="muted-text">Belum ada riwayat cicilan / pembayaran.</p>`;

  openModal("modal-debt-payment");
}

function recordDebtPayment(e) {
  e.preventDefault();
  const debtId = document.getElementById("debt-pay-target-id").value;
  const d = appState.debts.find((x) => x.id === debtId);
  if (!d) return;

  const amount = Number(document.getElementById("debt-pay-amount").value);
  const date = document.getElementById("debt-pay-date").value;
  const accountId = document.getElementById("debt-pay-account").value;
  const note = document.getElementById("debt-pay-note").value.trim() || "Pembayaran cicilan";

  if (!d.payments) d.payments = [];
  d.payments.push({ id: "pay-" + Date.now(), date, amount, accountId, note });

  // Also record into cash flow transactions automatically
  appState.transactions.push({
    id: "tx-" + Date.now(),
    type: d.kind === "payable" ? "expense" : "income",
    date,
    category: d.kind === "payable" ? "Operasional" : "Piutang dibayar",
    accountId,
    amount,
    note: `${d.kind === "payable" ? "Bayar hutang ke" : "Terima piutang dari"} ${d.person} (${note})`,
    receipt: ""
  });

  const paidSum = d.payments.reduce((s, p) => s + Number(p.amount), 0);
  if (paidSum >= Number(d.amount)) {
    d.status = "PAID";
  }

  saveState();
  openDebtPaymentModal(debtId);
  refreshAllViews();
  showToast("Pembayaran dicatat & saldo kas diperbarui!");
}

function renderDebtsTable() {
  const typeF = document.getElementById("debt-type-filter").value;
  const statusF = document.getElementById("debt-status-filter").value;

  let remPayable = 0;
  let remReceivable = 0;
  let cntPayable = 0;
  let cntReceivable = 0;

  appState.debts.forEach((d) => {
    const paid = (d.payments || []).reduce((s, p) => s + Number(p.amount), 0);
    const rem = d.status === "PAID" ? 0 : Math.max(0, Number(d.amount) - paid);
    if (d.kind === "payable") {
      remPayable += rem;
      if (d.status !== "PAID") cntPayable++;
    } else {
      remReceivable += rem;
      if (d.status !== "PAID") cntReceivable++;
    }
  });

  document.getElementById("debt-total-payable").textContent = formatMoney(remPayable);
  document.getElementById("debt-total-receivable").textContent = formatMoney(remReceivable);
  document.getElementById("debt-count-payable").textContent = cntPayable;
  document.getElementById("debt-count-receivable").textContent = cntReceivable;

  const list = appState.debts
    .filter((d) => (typeF === "ALL" ? true : d.kind === typeF))
    .filter((d) => (statusF === "ALL" ? true : d.status === statusF));

  const tbody = document.getElementById("debts-table-body");
  if (!list.length) {
    tbody.innerHTML = `<tr><td colspan="8" class="muted-text">Belum ada catatan hutang atau piutang.</td></tr>`;
    return;
  }

  tbody.innerHTML = list
    .map((d) => {
      const paid = (d.payments || []).reduce((s, p) => s + Number(p.amount), 0);
      const rem = d.status === "PAID" ? 0 : Math.max(0, Number(d.amount) - paid);
      return `
        <tr>
          <td><span class="pill-tag">${d.kind === "payable" ? "Hutang" : "Piutang"}</span></td>
          <td><strong>${d.person}</strong><br/><small class="muted-text">${d.note || ""}</small></td>
          <td>${formatDateID(d.date)}</td>
          <td>${formatDateID(d.dueDate)}</td>
          <td><strong>${formatMoney(d.amount)}</strong></td>
          <td>
            <small class="text-success">Bayar: ${formatMoney(paid)}</small><br/>
            <small class="text-danger">Sisa: ${formatMoney(rem)}</small>
          </td>
          <td>
            <span class="status-badge ${d.status === "PAID" ? "paid" : "unpaid"}">
              ${d.status === "PAID" ? "Lunas" : "Belum Lunas"}
            </span>
          </td>
          <td>
            <button class="btn btn-sm btn-outline" onclick="openDebtPaymentModal('${d.id}')" title="Riwayat & Bayar">
              <i class="fa-solid fa-receipt"></i> Riwayat
            </button>
            <button class="icon-btn" onclick="openDebtModal('${d.kind}', '${d.id}')"><i class="fa-solid fa-pen"></i></button>
            <button class="icon-btn danger" onclick="deleteDebtItem('${d.id}')"><i class="fa-solid fa-trash"></i></button>
          </td>
        </tr>
      `;
    })
    .join("");
}

/* ---------- KALENDER KEUANGAN ---------- */
function shiftCalendarMonth(delta) {
  calendarViewDate.setMonth(calendarViewDate.getMonth() + delta);
  renderFinancialCalendar();
}

function renderFinancialCalendar() {
  const monthsFull = [
    "Januari", "Februari", "Maret", "April", "Mei", "Juni",
    "Juli", "Agustus", "September", "Oktober", "November", "Desember"
  ];
  const year = calendarViewDate.getFullYear();
  const month = calendarViewDate.getMonth();
  document.getElementById("cal-month-label").textContent = `${monthsFull[month]} ${year}`;

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const grid = document.getElementById("financial-calendar-grid");

  let html = "";
  for (let i = 0; i < firstDay; i++) {
    html += `<div class="cal-day-cell empty"></div>`;
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const iso = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const dayTx = appState.transactions.filter((t) => t.date === iso);
    const inSum = dayTx.filter((t) => t.type === "income").reduce((s, t) => s + Number(t.amount), 0);
    const outSum = dayTx.filter((t) => t.type === "expense").reduce((s, t) => s + Number(t.amount), 0);

    html += `
      <div class="cal-day-cell ${selectedCalendarDay === iso ? "selected" : ""}" onclick="selectCalendarDay('${iso}')">
        <span class="cal-day-num">${day}</span>
        <div>
          ${inSum > 0 ? `<div class="cal-day-in">+${formatMoney(inSum)}</div>` : ""}
          ${outSum > 0 ? `<div class="cal-day-out">-${formatMoney(outSum)}</div>` : ""}
        </div>
      </div>
    `;
  }
  grid.innerHTML = html;
  renderSelectedCalendarDayDetails();
}

function selectCalendarDay(iso) {
  selectedCalendarDay = iso;
  renderFinancialCalendar();
}

function renderSelectedCalendarDayDetails() {
  document.getElementById("cal-selected-day-title").textContent = `Aktivitas ${formatDateID(selectedCalendarDay)}`;
  const list = appState.transactions.filter((t) => t.date === selectedCalendarDay);
  const box = document.getElementById("cal-selected-day-list");

  if (!list.length) {
    box.innerHTML = `<p class="muted-text">Tidak ada pemasukan maupun pengeluaran pada tanggal ini.</p>`;
    return;
  }
  box.innerHTML = list
    .map(
      (t) => `
      <div class="tx-row-item">
        <div>
          <strong>${t.note}</strong>
          <small>${t.category} • ${getAccountName(t.accountId)}</small>
        </div>
        <strong class="${t.type === "income" ? "text-success" : "text-danger"}">
          ${t.type === "income" ? "+" : "-"}${formatMoney(t.amount)}
        </strong>
      </div>
    `
    )
    .join("");
}

/* ==========================================================================
   MODULE 3: PENGATURAN WEBSITE (20 THEMES, BRANDING, USERS, PASSWORD, CLOUD)
   ========================================================================== */
function applyTheme(themeId) {
  document.documentElement.setAttribute("data-theme", themeId);
  appState.settings.theme = themeId;
  const found = THEMES_CATALOG.find((t) => t.id === themeId);
  const badge = document.getElementById("active-theme-label");
  if (badge && found) {
    badge.textContent = `Tema Aktif: ${found.name} (${found.mode === "light" ? "Light" : "Dark"})`;
  }
}

function selectTheme(themeId) {
  applyTheme(themeId);
  saveState();
  renderSettingsPage();
  renderScheduleCharts();
  renderCashFlowDashboard();
  showToast("Tema tampilan berhasil diubah!");
}

function renderSettingsPage() {
  // 1. Render 10 Light & 10 Dark Themes inside Settings ONLY
  const lightGrid = document.getElementById("light-themes-grid");
  const darkGrid = document.getElementById("dark-themes-grid");

  const buildCard = (t) => `
    <div class="theme-swatch-card ${appState.settings.theme === t.id ? "active" : ""}" onclick="selectTheme('${t.id}')">
      <div class="swatch-circles">
        <span class="swatch-dot" style="background:${t.colors[0]}"></span>
        <span class="swatch-dot" style="background:${t.colors[1]}"></span>
        <span class="swatch-dot" style="background:${t.colors[2]}"></span>
      </div>
      <span class="swatch-name">${t.name}</span>
    </div>
  `;

  lightGrid.innerHTML = THEMES_CATALOG.filter((t) => t.mode === "light").map(buildCard).join("");
  darkGrid.innerHTML = THEMES_CATALOG.filter((t) => t.mode === "dark").map(buildCard).join("");

  // 2. Branding & Profile inputs
  document.getElementById("set-app-name").value = appState.settings.appName;
  document.getElementById("set-header-title").value = appState.settings.headerTitle;
  document.getElementById("set-header-subtitle").value = appState.settings.headerSubtitle;
  document.getElementById("set-currency-symbol").value = appState.settings.currency;
  if (currentUser) {
    document.getElementById("set-user-fullname").value = currentUser.fullName;
    document.getElementById("cp-username").value = currentUser.username;
  }

  // 3. Users Management Table
  const usersTbody = document.getElementById("users-management-table");
  usersTbody.innerHTML = appState.users
    .map(
      (u, idx) => `
      <tr>
        <td><strong>${u.fullName}</strong></td>
        <td><code>${u.username}</code></td>
        <td><span class="pill-tag">${u.role}</span></td>
        <td><span class="status-badge ${u.active ? "paid" : "unpaid"}">${u.active ? "Aktif" : "Nonaktif"}</span></td>
        <td>
          <button class="icon-btn" title="Edit Pengguna" onclick="openUserModal(${idx})"><i class="fa-solid fa-pen"></i></button>
          ${
            u.username !== "syamramdani"
              ? `<button class="icon-btn danger" title="Hapus Pengguna" onclick="deleteUserAccount(${idx})"><i class="fa-solid fa-trash"></i></button>`
              : `<small class="muted-text">Utama</small>`
          }
        </td>
      </tr>
    `
    )
    .join("");

  // 4. Finance Categories Chips
  document.getElementById("settings-income-cats").innerHTML = appState.incomeCategories
    .map(
      (c, i) =>
        `<span class="cat-chip">${c} <button type="button" onclick="deleteFinanceCategory('income', ${i})"><i class="fa-solid fa-xmark"></i></button></span>`
    )
    .join("");

  document.getElementById("settings-expense-cats").innerHTML = appState.expenseCategories
    .map(
      (c, i) =>
        `<span class="cat-chip">${c} <button type="button" onclick="deleteFinanceCategory('expense', ${i})"><i class="fa-solid fa-xmark"></i></button></span>`
    )
    .join("");

  // 5. Firebase URL
  document.getElementById("firebase-url-input").value = appState.settings.firebaseUrl || "";
}

function saveBrandingSettings(e) {
  e.preventDefault();
  appState.settings.appName = document.getElementById("set-app-name").value.trim();
  appState.settings.headerTitle = document.getElementById("set-header-title").value.trim();
  appState.settings.headerSubtitle = document.getElementById("set-header-subtitle").value.trim();
  appState.settings.currency = document.getElementById("set-currency-symbol").value;

  const newFullName = document.getElementById("set-user-fullname").value.trim();
  if (currentUser && newFullName) {
    currentUser.fullName = newFullName;
    const idx = appState.users.findIndex((u) => u.username === currentUser.username);
    if (idx !== -1) appState.users[idx].fullName = newFullName;
  }

  saveState();
  applyBrandingUI();
  refreshAllViews();
  showToast("Identitas header, nama pengguna, dan pengaturan disimpan!");
}

function handleChangePassword(e) {
  e.preventDefault();
  if (!currentUser) return;
  const oldPass = document.getElementById("cp-old-pass").value;
  const newPass = document.getElementById("cp-new-pass").value;
  const confirmPass = document.getElementById("cp-confirm-pass").value;

  if (oldPass !== currentUser.password) {
    showToast("Password lama tidak sesuai!");
    return;
  }
  if (newPass !== confirmPass) {
    showToast("Konfirmasi password baru tidak cocok!");
    return;
  }

  currentUser.password = newPass;
  const idx = appState.users.findIndex((u) => u.username === currentUser.username);
  if (idx !== -1) appState.users[idx].password = newPass;

  saveState();
  document.getElementById("change-password-form").reset();
  document.getElementById("cp-username").value = currentUser.username;
  showToast("Password berhasil diperbarui!");
}

function openUserModal(editIdx = -1) {
  document.getElementById("user-form").reset();
  document.getElementById("usr-edit-index").value = editIdx;

  if (editIdx >= 0 && appState.users[editIdx]) {
    const u = appState.users[editIdx];
    document.getElementById("modal-user-title").textContent = "Edit Login Pengguna";
    document.getElementById("usr-fullname").value = u.fullName;
    document.getElementById("usr-username").value = u.username;
    document.getElementById("usr-password").value = u.password;
    document.getElementById("usr-role").value = u.role;
    document.getElementById("usr-active").value = String(u.active);
  } else {
    document.getElementById("modal-user-title").textContent = "Tambah Login Pengguna Lain";
  }
  openModal("modal-user");
}

function saveUserAccount(e) {
  e.preventDefault();
  const idx = Number(document.getElementById("usr-edit-index").value);
  const fullName = document.getElementById("usr-fullname").value.trim();
  const username = document.getElementById("usr-username").value.trim();
  const password = document.getElementById("usr-password").value;
  const role = document.getElementById("usr-role").value;
  const active = document.getElementById("usr-active").value === "true";

  const duplicate = appState.users.some((u, i) => i !== idx && u.username.toLowerCase() === username.toLowerCase());
  if (duplicate) {
    showToast("Username sudah digunakan oleh pengguna lain!");
    return;
  }

  if (idx >= 0) {
    appState.users[idx] = { fullName, username, password, role, active };
    if (currentUser && currentUser.username === username) {
      currentUser = appState.users[idx];
      applyBrandingUI();
    }
    showToast("Data pengguna diperbarui!");
  } else {
    appState.users.push({ fullName, username, password, role, active });
    showToast(`Login baru untuk "${username}" berhasil ditambahkan!`);
  }

  saveState();
  closeModal("modal-user");
  renderSettingsPage();
}

function deleteUserAccount(idx) {
  if (!confirm("Hapus akun pengguna ini?")) return;
  appState.users.splice(idx, 1);
  saveState();
  renderSettingsPage();
  showToast("Pengguna dihapus.");
}

function addFinanceCategory(e, kind) {
  e.preventDefault();
  const inp = document.getElementById(kind === "income" ? "new-income-cat" : "new-expense-cat");
  const val = inp.value.trim();
  if (!val) return;
  const arr = kind === "income" ? appState.incomeCategories : appState.expenseCategories;
  if (!arr.includes(val)) {
    arr.push(val);
    saveState();
    refreshAllViews();
    showToast(`Kategori "${val}" ditambahkan!`);
  }
  inp.value = "";
}

function deleteFinanceCategory(kind, idx) {
  const arr = kind === "income" ? appState.incomeCategories : appState.expenseCategories;
  if (arr.length <= 1) return;
  arr.splice(idx, 1);
  saveState();
  refreshAllViews();
}

function saveFirebaseConfig() {
  const url = document.getElementById("firebase-url-input").value.trim();
  appState.settings.firebaseUrl = url;
  saveState(true);
  if (url) {
    pushStateToFirebase();
    connectFirebaseRealtime();
    showToast("Terhubung ke Firebase Realtime Database!");
  } else {
    connectFirebaseRealtime();
    showToast("Koneksi Cloud dinonaktifkan (kembali ke mode lokal).");
  }
}

function forceCloudSync() {
  if (!appState.settings.firebaseUrl) {
    showToast("Masukkan URL Firebase Realtime Database terlebih dahulu.");
    return;
  }
  pushStateToFirebase();
}

function backupAllDataJSON() {
  const blob = new Blob([JSON.stringify(appState, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Backup_SyamWorkspace_${getTodayISO()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast("Backup JSON berhasil di-download!");
}

function restoreAllDataJSON(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const imported = JSON.parse(e.target.result);
      appState = { ...getDefaultState(), ...imported };
      saveState();
      applyTheme(appState.settings.theme);
      applyBrandingUI();
      refreshAllViews();
      showToast("Database berhasil di-restore!");
    } catch (err) {
      showToast("File backup JSON tidak valid!");
    }
    event.target.value = "";
  };
  reader.readAsText(file);
}

function resetDemoDatabase() {
  if (!confirm("Reset semua data ke pengaturan awal? Data saat ini akan diganti.")) return;
  const keepUrl = appState.settings.firebaseUrl;
  appState = getDefaultState();
  appState.settings.firebaseUrl = keepUrl;
  saveState();
  applyTheme(appState.settings.theme);
  applyBrandingUI();
  refreshAllViews();
  showToast("Database di-reset ke data awal.");
}