# Apna AI Pro — setup guide

**Note:** Pehle upload ki gayi CSV API usage report hai, API key nahi. Project mein key pre-filled nahi hai.

## PC/laptop par run karein
1. Node.js 20+ install karein.
2. Project folder mein terminal khol kar `npm install` chalayein.
3. `.env.example` ki copy banakar `.env` naam dein.
4. `.env` mein `OPENAI_API_KEY=` ke baad apni secret API key rakhein.
5. `npm start` chalayein aur `http://localhost:3000` kholein.

## Hosting / Android
Static-only hosting par backend nahi chalega. Node.js hosting par deploy karein aur `OPENAI_API_KEY` ko hosting ke environment secrets mein set karein. HTTPS URL use karein.

Yeh responsive web app + backend starter hai, compiled APK nahi. Backend deploy karne ke baad ise Android WebView/Capacitor wrapper mein package karke APK banaya ja sakta hai.

## Security
- API key ko public HTML, GitHub, ZIP, screenshots ya APK mein na rakhein.
- Public ho chuki key ko provider dashboard se revoke/rotate karein.
- API charges ho sakte hain; usage budget/limits set karein.
- Production launch se pehle authentication, rate limits aur privacy policy add karein.
