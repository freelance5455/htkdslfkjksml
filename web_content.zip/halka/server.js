const express=require('express'),http=require('http'),fs=require('fs'),bcrypt=require('bcryptjs'),crypto=require('crypto');
const {Server}=require('socket.io');
const app=express(),srv=http.createServer(app),io=new Server(srv);
app.use(express.json());app.use(express.static('public'));
const F='data.json';
const db=fs.existsSync(F)?JSON.parse(fs.readFileSync(F)):{users:{},servers:{},tokens:{},msgs:{}};
const save=()=>fs.writeFileSync(F,JSON.stringify(db));
const rid=()=>crypto.randomBytes(4).toString('hex');

// --- Giriş sistemi ---
const issue=u=>{const t=crypto.randomBytes(24).toString('hex');db.tokens[t]=u;save();return t};
app.post('/api/register',(req,res)=>{
  const {user,pass}=req.body||{};
  if(!/^[\w-]{3,20}$/.test(user||'')||(pass||'').length<6)return res.status(400).json({err:'Kullanıcı adı 3-20 karakter, şifre en az 6 karakter olmalı.'});
  if(db.users[user.toLowerCase()])return res.status(409).json({err:'Bu kullanıcı adı alınmış.'});
  db.users[user.toLowerCase()]={name:user,hash:bcrypt.hashSync(pass,10)};
  res.json({token:issue(user.toLowerCase()),name:user});
});
app.post('/api/login',(req,res)=>{
  const {user,pass}=req.body||{},u=db.users[(user||'').toLowerCase()];
  if(!u||!bcrypt.compareSync(pass||'',u.hash))return res.status(401).json({err:'Kullanıcı adı veya şifre yanlış.'});
  res.json({token:issue(user.toLowerCase()),name:u.name});
});

// --- Gerçek zamanlı ---
io.use((s,next)=>{const u=db.tokens[s.handshake.auth.token];if(!u)return next(new Error('auth'));s.uid=u;s.name=db.users[u].name;next()});
const mine=uid=>Object.values(db.servers).filter(s=>s.members.includes(uid));
const voiceRoom=c=>'v:'+c;
io.on('connection',s=>{
  const sendList=()=>s.emit('servers',mine(s.uid));
  sendList();
  s.on('server:create',name=>{
    const sv={id:rid(),name:String(name).slice(0,30),code:rid(),owner:s.uid,members:[s.uid],
      channels:[{id:rid(),name:'genel',type:'text'},{id:rid(),name:'Sohbet Odası',type:'voice'},{id:rid(),name:'Yayın Odası',type:'voice'}]};
    db.servers[sv.id]=sv;save();sendList();
  });
  s.on('server:join',(code,cb)=>{
    const sv=Object.values(db.servers).find(x=>x.code===String(code).trim());
    if(!sv)return cb&&cb('Davet kodu geçersiz.');
    if(!sv.members.includes(s.uid)){sv.members.push(s.uid);save()}
    sendList();cb&&cb(null);
  });
  s.on('channel:add',({sid,name,type})=>{
    const sv=db.servers[sid];if(!sv||sv.owner!==s.uid)return;
    sv.channels.push({id:rid(),name:String(name).slice(0,30),type:type==='voice'?'voice':'text'});save();
    mine(s.uid);io.emit('servers:changed');
  });
  s.on('chat:open',({sid,cid},cb)=>{
    const sv=db.servers[sid];if(!sv||!sv.members.includes(s.uid))return;
    [...s.rooms].filter(r=>r.startsWith('t:')).forEach(r=>s.leave(r));
    s.join('t:'+cid);cb((db.msgs[cid]||[]).slice(-60));
  });
  s.on('chat:send',({sid,cid,text})=>{
    const sv=db.servers[sid];if(!sv||!sv.members.includes(s.uid)||!String(text).trim())return;
    const m={who:s.name,text:String(text).slice(0,2000),t:Date.now()};
    (db.msgs[cid]=db.msgs[cid]||[]).push(m);save();io.to('t:'+cid).emit('chat:msg',{cid,m});
  });
  // Sesli oda + yayın: WebRTC sinyalleşmesi (mesh)
  s.on('voice:join',({sid,cid},cb)=>{
    const sv=db.servers[sid];if(!sv||!sv.members.includes(s.uid))return;
    leave();s.vc=cid;
    const others=[...(io.sockets.adapter.rooms.get(voiceRoom(cid))||[])].map(id=>({id,name:io.sockets.sockets.get(id).name}));
    s.join(voiceRoom(cid));s.to(voiceRoom(cid)).emit('voice:peer',{id:s.id,name:s.name});cb(others);
  });
  const leave=()=>{if(s.vc){s.leave(voiceRoom(s.vc));s.to(voiceRoom(s.vc)).emit('voice:gone',s.id);s.vc=null}};
  s.on('voice:leave',leave);s.on('disconnect',leave);
  s.on('rtc',({to,d})=>io.to(to).emit('rtc',{from:s.id,d}));
  s.on('stream:live',live=>s.vc&&s.to(voiceRoom(s.vc)).emit('stream:live',{id:s.id,live}));
});
io.engine.on('connection_error',()=>{});
srv.listen(process.env.PORT||3000,()=>console.log('Halka çalışıyor: http://localhost:'+(process.env.PORT||3000)));
