# Baking Hub By Zainab

A responsive cake-ordering website starter built with HTML, CSS and JavaScript.

## Included
- Four cake flavours with the prices supplied (for 1 pound)
- Six selectable cake design styles
- 1–5 pound size selector
- Live estimated price summary
- Customer details and WhatsApp order message
- Optional Firebase Google sign-in integration
- Mobile-friendly layout

## Price calculation
The listed prices are the 1-pound base prices. This starter estimates larger sizes proportionally:
`1-pound price × selected pounds`.
For example, Vanilla 2 lb = Rs. 1,600. Confirm your actual pricing before accepting orders; larger cakes may need different pricing.

## Run on Android
1. Extract the ZIP using your file manager.
2. Upload the folder to a static hosting service such as GitHub Pages, Netlify, or Firebase Hosting. ES modules and Firebase sign-in work best on HTTPS.
3. Open the published website in Chrome.

Opening `index.html` directly from local file storage may not work because browsers restrict JavaScript modules on `file://`.

## Enable Google sign-in (Firebase)
1. Create a project at https://console.firebase.google.com/
2. Add a Web App to the project and copy its Firebase config.
3. Paste the config values into `firebase-config.js`.
4. In Firebase Console, open Authentication → Sign-in method and enable Google.
5. In Authentication settings, add your website domain to Authorized domains.
6. Deploy the site over HTTPS and test the Google sign-in button.

Google login is optional. The cake builder can be previewed without it.

## Enable WhatsApp orders
1. Open `settings.js` and set `window.BAKERY_WHATSAPP_NUMBER` to the bakery's WhatsApp number in international format, digits only (Pakistan example: `923001234567`).
2. In `index.html`, add this line immediately before the `app.js` module script:
   `<script src="settings.js"></script>`
3. Deploy again. The order button will open WhatsApp with the customer's order details filled in.

Until configured, the app stays in demo mode and tries to copy the order text instead of sending it.

## Important
- This is a front-end starter, not a published app or payment system.
- No customer orders are stored in a database.
- Do not collect or publish customer details until you have appropriate privacy and security arrangements.
- Final availability, delivery charges and prices should be confirmed by the bakery.
