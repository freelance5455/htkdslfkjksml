import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";

const flavours = [
  {id:"vanilla", name:"Vanilla", price:800, icon:"🍦", note:"Soft, classic & creamy"},
  {id:"chocolate", name:"Chocolate", price:1000, icon:"🍫", note:"Rich chocolate flavour"},
  {id:"chocolate-fudge", name:"Chocolate Fudge", price:1200, icon:"🤎", note:"Extra rich & fudgy"},
  {id:"caramel", name:"Caramel", price:1400, icon:"🍮", note:"Sweet caramel delight"}
];
const designs = [
  {id:"classic",name:"Classic Celebration",note:"Simple and elegant",art:"🎂"},
  {id:"birthday",name:"Birthday Special",note:"Fun party styling",art:"🎉"},
  {id:"floral",name:"Floral Beauty",note:"Delicate flower details",art:"🌸"},
  {id:"chocolate-drip",name:"Chocolate Drip",note:"A chocolate-lover look",art:"🍫"},
  {id:"minimal",name:"Minimal Chic",note:"Clean and modern",art:"🤍"},
  {id:"custom",name:"Custom Design",note:"Discuss your own idea",art:"✨"}
];

let selectedFlavour = flavours[0];
let selectedDesign = designs[0];
let auth = null;
let currentUser = null;

const $ = id => document.getElementById(id);
const money = value => "Rs. " + value.toLocaleString("en-PK");

function renderFlavours(){
  $("flavourGrid").innerHTML = flavours.map(f => `
    <button class="flavour-card ${f.id===selectedFlavour.id?"selected":""}" data-flavour="${f.id}" type="button">
      <span class="flavour-icon">${f.icon}</span><b>${f.name}</b><small>${f.note}</small><strong>${money(f.price)} / lb</strong>
    </button>`).join("");
  document.querySelectorAll("[data-flavour]").forEach(btn => btn.addEventListener("click",()=>{
    selectedFlavour=flavours.find(f=>f.id===btn.dataset.flavour); renderFlavours(); updateSummary();
  }));
}
function renderDesigns(){
  $("designGrid").innerHTML = designs.map(d => `
    <button class="design-card ${d.id===selectedDesign.id?"selected":""}" data-design="${d.id}" type="button">
      <span class="design-art">${d.art}</span><b>${d.name}</b><small>${d.note}</small>
    </button>`).join("");
  document.querySelectorAll("[data-design]").forEach(btn => btn.addEventListener("click",()=>{
    selectedDesign=designs.find(d=>d.id===btn.dataset.design); renderDesigns(); updateSummary();
  }));
}
function updateSummary(){
  const pounds=Number($("weight").value);
  $("summaryFlavour").textContent=selectedFlavour.name;
  $("summaryDesign").textContent=selectedDesign.name;
  $("sumFlavourPrice").textContent=money(selectedFlavour.price);
  $("sumWeight").textContent=pounds===1?"1 Pound":`${pounds} Pounds`;
  $("sumDesign").textContent=selectedDesign.name;
  $("total").textContent=money(selectedFlavour.price*pounds);
}
$("weight").addEventListener("change",updateSummary);

$("orderBtn").addEventListener("click",()=>{
  $("formError").textContent="";
  const name=$("customerName").value.trim(), phone=$("phone").value.trim(), address=$("address").value.trim();
  if(!name||!phone||!address){$("formError").textContent="Please enter your name, WhatsApp number and delivery address.";return;}
  const pounds=Number($("weight").value), total=selectedFlavour.price*pounds;
  const message=[
    "Hello Baking Hub By Zainab! I'd like to place a cake order.",
    `Name: ${name}`,`WhatsApp: ${phone}`,`Flavour: ${selectedFlavour.name}`,
    `Design: ${selectedDesign.name}`,`Weight: ${pounds} pound(s)`,
    `Cake message: ${$("message").value.trim()||"None"}`,
    `Delivery address: ${address}`,`Extra details: ${$("notes").value.trim()||"None"}`,
    `Estimated total: ${money(total)}`,
    "Please confirm availability and final price."
  ].join("\n");
  // Add the bakery's WhatsApp number in settings.js before using live orders.
  const number=window.BAKERY_WHATSAPP_NUMBER || "";
  if(!number){$("formError").textContent="Demo mode: add the bakery WhatsApp number in settings.js to enable order sending. Your order details are ready to copy."; navigator.clipboard?.writeText(message).catch(()=>{}); return;}
  window.open(`https://wa.me/${number}?text=${encodeURIComponent(message)}`,"_blank","noopener");
});

const loginBtn=$("loginBtn");
if(firebaseConfig.apiKey && firebaseConfig.apiKey!=="YOUR_API_KEY"){
  try{
    const app=initializeApp(firebaseConfig); auth=getAuth(app);
    onAuthStateChanged(auth,user=>{
      currentUser=user;
      loginBtn.textContent=user ? `Hi, ${user.displayName?.split(" ")[0]||"Customer"} · Sign out` : "Sign in with Google";
      if(user && user.displayName && !$("customerName").value) $("customerName").value=user.displayName;
    });
    loginBtn.addEventListener("click",async()=>{
      try{if(currentUser) await signOut(auth); else await signInWithPopup(auth,new GoogleAuthProvider());}
      catch(error){alert("Google sign-in could not complete: "+error.message);}
    });
  }catch(e){console.error(e);loginBtn.title="Check Firebase setup";}
}else{
  loginBtn.addEventListener("click",()=>alert("Google sign-in setup needed. Follow README.md to connect your Firebase project."));
}
renderFlavours();renderDesigns();updateSummary();$("year").textContent=new Date().getFullYear();
