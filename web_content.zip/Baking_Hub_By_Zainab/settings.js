// Optional: put your bakery WhatsApp number here in international format,
// digits only, including country code. Example for Pakistan: 923001234567
// Then add this line near the top of index.html before app.js:
// <script src="settings.js"></script>
window.BAKERY_WHATSAPP_NUMBER = "";
