import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView meuWebView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        meuWebView = findViewById(R.id.webview);
        WebSettings config = meuWebView.getSettings();
        
        config.setJavaScriptEnabled(true);
        config.setAllowFileAccess(true);
        config.setDomStorageEnabled(true);

        meuWebView.addJavascriptInterface(new PonteComAndroid(), "Android");
        meuWebView.loadUrl("file:///android_asset/painel.html");
        meuWebView.setWebViewClient(new WebViewClient());
    }

    public class PonteComAndroid {
        
        @JavascriptInterface
        public void abrirFreeFire() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "Abrindo Free Fire...", Toast.LENGTH_SHORT).show();
                    Intent intent = getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Free Fire não encontrado", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void conectarADB() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "Função ADB — em desenvolvimento", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
