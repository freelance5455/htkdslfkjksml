import android.os.Build;
import androidx.annotation.NonNull;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x509.*;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;

public class AdbConnectionManager extends AbsAdbConnectionManager {
    private static AbsAdbConnectionManager INSTANCE;
    private static final String KEYS_DIR = "adb_keys";
    private static final String PRIVATE_KEY_FILE = "adb_private.key";
    private static final String CERT_FILE = "adb_cert.crt";

    public static AbsAdbConnectionManager getInstance() throws Exception {
        if (INSTANCE == null) {
            INSTANCE = new AdbConnectionManager();
        }
        return INSTANCE;
    }

    private PrivateKey mPrivateKey;
    private X509Certificate mCertificate;
    private final File mKeysDir;

    private AdbConnectionManager() throws Exception {
        setApi(Build.VERSION.SDK_INT);
        
        mKeysDir = new File(MyApplication.getContext().getFilesDir(), KEYS_DIR);
        if (!mKeysDir.exists()) mKeysDir.mkdirs();

        if (!loadKeys()) {
            generateNewKeyPair();
        }
    }

    private boolean loadKeys() {
        try {
            File privKeyFile = new File(mKeysDir, PRIVATE_KEY_FILE);
            File certFile = new File(mKeysDir, CERT_FILE);
            
            if (!privKeyFile.exists() || !certFile.exists()) return false;

            byte[] privKeyBytes = new byte[(int) privKeyFile.length()];
            try (FileInputStream fis = new FileInputStream(privKeyFile)) {
                fis.read(privKeyBytes);
            }
            mPrivateKey = KeyFactory.getInstance("RSA")
                    .generatePrivate(new PKCS8EncodedKeySpec(privKeyBytes));

            try (FileInputStream fis = new FileInputStream(certFile)) {
                mCertificate = (X509Certificate) java.security.cert.CertificateFactory.getInstance("X.509")
                        .generateCertificate(fis);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void generateNewKeyPair() throws Exception {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048, new SecureRandom());
        KeyPair keyPair = keyPairGenerator.generateKeyPair();
        PublicKey publicKey = keyPair.getPublic();
        mPrivateKey = keyPair.getPrivate();

        String subject = "CN=FLX MODZ Device";
        String signatureAlg = "SHA512withRSA";
        long now = System.currentTimeMillis();
        Date notBefore = new Date(now);
        Date notAfter = new Date(now + 365L * 24 * 60 * 60 * 1000);
        BigInteger serial = new BigInteger(64, new SecureRandom());

        X500Name issuer = new X500Name("CN=FLX MODZ");
        X500Name subjectDN = new X500Name(subject);
        
        ContentSigner signer = new JcaContentSignerBuilder(signatureAlg)
                .build(mPrivateKey);
        
        X509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(
                issuer, serial, notBefore, notAfter, subjectDN, publicKey)
                .addExtension(Extension.subjectKeyIdentifier, false, 
                        new SubjectKeyIdentifier(publicKey).getEncoded())
                .addExtension(Extension.basicConstraints, true, 
                        new BasicConstraints(true));

        org.bouncycastle.cert.X509CertificateHolder certHolder = certBuilder.build(signer);
        mCertificate = new JcaX509CertificateConverter()
                .getCertificate(certHolder);

        saveKeys(keyPair);
    }

    private void saveKeys(KeyPair keyPair) throws Exception {
        try (FileOutputStream fos = new FileOutputStream(new File(mKeysDir, PRIVATE_KEY_FILE))) {
            fos.write(keyPair.getPrivate().getEncoded());
        }
        try (FileOutputStream fos = new FileOutputStream(new File(mKeysDir, CERT_FILE))) {
            fos.write(mCertificate.getEncoded());
        }
    }

    @NonNull
    @Override
    protected PrivateKey getPrivateKey() {
        return mPrivateKey;
    }

    @NonNull
    @Override
    protected Certificate getCertificate() {
        return mCertificate;
    }

    @NonNull
    @Override
    protected String getDeviceName() {
        return "FLX_MODZ_Device";
    }
}
