-- URE family app: Supabase database setup
-- Run the whole script in Supabase Dashboard > SQL Editor > New query.

create table if not exists public.ure_posts (
  id uuid primary key default gen_random_uuid(),
  author text not null,
  title text not null,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.ure_requests (
  id uuid primary key default gen_random_uuid(),
  author text not null,
  kind text not null check (kind in ('شكوى', 'مقترح')),
  title text not null,
  body text not null,
  status text not null default 'جديد',
  created_at timestamptz not null default now()
);

alter table public.ure_posts enable row level security;
alter table public.ure_requests enable row level security;

-- Public family wall: everyone can read and submit a post.
drop policy if exists "URE posts readable by family" on public.ure_posts;
create policy "URE posts readable by family"
  on public.ure_posts for select to anon, authenticated using (true);

drop policy if exists "URE posts submit by family" on public.ure_posts;
create policy "URE posts submit by family"
  on public.ure_posts for insert to anon, authenticated with check (true);

-- Only signed-in administrator can remove public posts.
drop policy if exists "URE posts delete by admin" on public.ure_posts;
create policy "URE posts delete by admin"
  on public.ure_posts for delete to authenticated using (true);

-- Complaints/suggestions: visitors can submit, but anonymous users cannot read them.
drop policy if exists "URE requests submit by family" on public.ure_requests;
create policy "URE requests submit by family"
  on public.ure_requests for insert to anon, authenticated with check (true);

-- Only authenticated account(s) can read and update the private inbox.
drop policy if exists "URE requests read by admin" on public.ure_requests;
create policy "URE requests read by admin"
  on public.ure_requests for select to authenticated using (true);

drop policy if exists "URE requests update by admin" on public.ure_requests;
create policy "URE requests update by admin"
  on public.ure_requests for update to authenticated using (true) with check (true);

-- Grant the minimum table operations needed by the app.
grant select, insert, delete on public.ure_posts to anon, authenticated;
grant insert on public.ure_requests to anon, authenticated;
grant select, update on public.ure_requests to authenticated;


-- Secure administrator allow-list for the shared DODO wallet ledger.
-- Add the UUID of the trusted admin Supabase Auth account manually.
create table if not exists public.ure_admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);
alter table public.ure_admins enable row level security;
drop policy if exists "URE admins self lookup" on public.ure_admins;
create policy "URE admins self lookup" on public.ure_admins
  for select to authenticated using (user_id = auth.uid());
grant select on public.ure_admins to authenticated;

create table if not exists public.ure_wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  citizen_id text not null,
  citizen_name text not null,
  amount bigint not null check (amount > 0),
  reason text not null,
  created_at timestamptz not null default now(),
  created_by uuid not null default auth.uid()
);
alter table public.ure_wallet_ledger enable row level security;
drop policy if exists "URE wallet admin read" on public.ure_wallet_ledger;
create policy "URE wallet admin read" on public.ure_wallet_ledger
  for select to authenticated using (exists (select 1 from public.ure_admins a where a.user_id=auth.uid()));
drop policy if exists "URE wallet admin insert" on public.ure_wallet_ledger;
create policy "URE wallet admin insert" on public.ure_wallet_ledger
  for insert to authenticated with check (exists (select 1 from public.ure_admins a where a.user_id=auth.uid()) and created_by=auth.uid());
grant select, insert on public.ure_wallet_ledger to authenticated;
