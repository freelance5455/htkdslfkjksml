# Handoflogical Project — Safe Simulator

This is a local HTML/CSS/JavaScript prototype with a blue terminal-style interface.

## Included
- Developer dashboard label
- Seven visual-only mock chat states: Blank, Delay, Delay Hard, Force Close notice, Lock Chat, Lock Chat DE3AH, Freeze
- Local demo admin console for creating Member/VIP demo records and deleting non-owner demo records
- Protected demo owner row: `Handoflogical_Developer`

## Important limitations
- Simulation effects happen only inside this page. No WhatsApp connection, payloads, app crashes, chat locking, freezing of external apps, or device interference.
- The Member/VIP directory is stored in browser localStorage. It is a prototype, not secure authentication, not a server database, and does not create real accounts.
- The Developer label is a display label, not verified identity or a secure privilege boundary.
- Do not publish this prototype as an admin service without server-side authentication, authorization, database storage, audit logging, and security review.

## Run
Open `www/index.html` in a browser.

## Package as Android APK
For a real APK build, install Node.js and Android Studio, then in the project folder:
1. `npm init -y`
2. `npm install @capacitor/core @capacitor/cli @capacitor/android`
3. `npx cap init "Handoflogical Project" "com.handoflogical.project"`
4. Set `webDir` to `www` in the Capacitor config.
5. `npx cap add android`
6. `npx cap sync android`
7. `npx cap open android`, then build from Android Studio.

The current deliverable is source code, not a compiled APK.
