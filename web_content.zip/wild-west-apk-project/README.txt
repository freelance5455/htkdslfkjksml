Wild West Gang - Android APK project

This project wraps wild-west-gang-game.html in an Android WebView so it runs offline as an app.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. The APK will be in app/build/outputs/apk/debug/.

Application ID: com.wildwest.gang
Version: 1.0
