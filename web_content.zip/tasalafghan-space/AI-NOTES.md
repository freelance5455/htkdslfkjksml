# Tasalafghan Space AI
The chat assistant (floating button, bottom-right, on every page) is a self-contained,
rule-based assistant: it matches your question against an 80+ entry bilingual (EN/PS)
knowledge base covering planets, moons, black holes, galaxies, rockets, satellites,
space agencies, missions, cosmology and more — and answers instantly with no server
and no API key.
It is NOT connected to a live generative AI (e.g. Claude or GPT). A real backend with
a secret key can't be created or hosted inside this delivery — a static site has
nowhere safe to keep a key. To upgrade to a live LLM, deploy a small backend (e.g. a
Cloudflare Worker) that holds the API key, accepts { message, lang }, returns { reply },
and have the chat panel's aiSend() call it instead of aiMatch().
Voice input uses the Web Speech API; text-to-speech uses the browser's speechSynthesis
(off by default, toggle with the speaker icon). Chat history is saved only in the
visitor's own browser (localStorage).
