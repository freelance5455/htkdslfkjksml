# Tasalafghan Space

Fully offline-capable PWA: interactive solar system, rocket launch simulator, universe explorer, bilingual (EN/PS) space education, and a built-in rule-based AI assistant.

## Run online
Host this folder on any static host (Netlify, Vercel, GitHub Pages, Cloudflare Pages). The service worker enables offline use after the first visit.

## Run offline (no internet)
1. Open `index.html` in a modern browser (Chrome, Edge, Firefox, Safari), **or**
2. Serve the folder with any local static server, e.g.:
   ```bash
   python3 -m http.server 8080
   ```
   then open http://localhost:8080

Three.js and the 3D loaders are bundled under `js/`. 3D models (ISS, Apollo–Soyuz) are embedded in the page as base64, so no network is required for the solar system, universe explorer, or ISS model.

## PWA / install
After loading once over HTTP(S), the site can be installed as a standalone app and works offline.

## Notes
- AI chat is rule-based (no API key, no server).
- Optional next steps: Supabase admin, Capacitor (`npx cap add android`) with this folder as `webDir`.
