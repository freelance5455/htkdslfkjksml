# Tasalafghan Space
Open index.html via any static host (Netlify, Vercel, GitHub Pages, Cloudflare Pages) to enable PWA/offline.
Double-clicking index.html also works, but the 3D solar system needs internet (Three.js loads from cdnjs).
Next steps: Supabase admin, remaining pages, Capacitor (npx cap add android) — wrap this folder as webDir.
