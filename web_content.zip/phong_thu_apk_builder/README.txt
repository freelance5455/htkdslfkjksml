PHONG THU APK BUILDER - PWA SOURCE

Files:
- index.html: user interface and client-side validation
- manifest.webmanifest: installable PWA metadata
- sw.js: basic offline cache

IMPORTANT LIMITATION
This is a front-end PWA project. It does NOT compile APKs itself and does not upload files to a provider automatically. A real online build requires a documented provider API or a backend/build service. The current UI opens HTMLtoApp for manual upload. No unlimited file-size or build guarantee is made.

PUBLISH ON GITHUB PAGES (Android phone)
1. Create a public GitHub repository named phong-thu-apk-builder.
2. Upload index.html, manifest.webmanifest and sw.js to the repository root.
3. In repository Settings > Pages, select Deploy from a branch, branch main, folder /(root), Save.
4. Open the published HTTPS Pages URL in Chrome on Android.
5. Chrome menu > Add to Home screen / Install app.

USE
1. Select a ZIP or HTML file. ZIP should contain index.html at its root.
2. Enter app name, package ID and version.
3. Tap Continue. This validates the fields only.
4. Tap Open HTMLtoApp and upload the file manually there. Review provider limits, privacy policy and terms before upload.
5. Download the signed APK from the provider if its build completes, then install it on Android 11.

SECURITY
Do not upload confidential projects to public repositories. The repository being public exposes these source files to everyone. Do not put Supabase service_role keys, passwords, signing keys or tokens in this frontend.
