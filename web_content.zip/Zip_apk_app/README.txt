ZIP > APK — starter app

WHAT THIS DOES
- Mobile-friendly dark UI in black, charcoal grey, white and red.
- Lets you choose a ZIP and inspect its contents.
- If an APK is already inside the ZIP, it can extract the APK.
- Detects common Android project files and explains that source must be compiled.

IMPORTANT LIMITATION
A generic ZIP cannot be automatically converted into a working APK by renaming it.
Android source projects must be built using Android build tools (typically Gradle + Android SDK).
This starter app runs as a web app/PWA and does not compile Android projects inside the browser.

HOW TO TRY IT
1. Extract this ZIP.
2. Host the folder on an HTTPS static host, or open index.html in a browser (some browsers may restrict features when opened directly).
3. On Android Chrome, open the hosted page, tap the browser menu, then “Add to Home screen” / “Install app” if offered.

NOTE
The ZIP reader library is loaded from jsDelivr, so inspecting ZIPs requires an internet connection.
The selected archive itself is processed locally in the browser; the page does not upload it.
