-- Unser Vorrat: Produktbild aus Open Food Facts speichern
-- Einmal im Supabase SQL Editor ausführen.
ALTER TABLE public.inventory_items
ADD COLUMN IF NOT EXISTS product_image_url text;
