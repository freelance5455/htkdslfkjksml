package com.anuai.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) tts?.language = Locale.getDefault()
        }
        setContent { AnuApp() }
    }

    @Composable
    private fun AnuApp() {
        val prefs = remember { getSharedPreferences("anu_settings", MODE_PRIVATE) }
        var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
        var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions") ?: "") }
        var model by remember { mutableStateOf(prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini") }
        var draft by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var listening by remember { mutableStateOf(false) }
        var keepAwake by remember { mutableStateOf(false) }
        var showSettings by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Ready when you are") }
        val messages = remember { mutableStateListOf(ChatLine("assistant", "Hello! I'm ANU AI. How can I help you today?")) }
        val scope = rememberCoroutineScope()

        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening { recognized -> draft = recognized; listening = false }
            else status = "Microphone permission was not granted"
        }

        SideEffect {
            if (keepAwake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        fun speak(text: String) { if (ttsReady) tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "anu_reply") }
        fun submit(text: String) {
            val clean = text.trim()
            if (clean.isEmpty() || busy) return
            draft = ""
            messages.add(ChatLine("user", clean))
            // Device lock is a local, explicit command; the language model cannot trigger it.
            if (clean.lowercase(Locale.ROOT).matches(Regex("(anu[, ]+)?(lock|turn off|switch off) (my )?(phone )?screen[.! ]*"))) {
                val ok = ScreenLockAccessibilityService.lockScreen()
                val reply = if (ok) "Locking the screen." else "To allow this, enable ANU AI screen lock in Android Settings → Accessibility."
                messages.add(ChatLine("assistant", reply)); speak(reply); status = if (ok) "Screen locked" else "Accessibility permission needed"
                return
            }
            if (apiKey.isBlank()) {
                val reply = "Add your AI API key in Settings to connect my brain. You can still use the voice input and local screen-awake setting."
                messages.add(ChatLine("assistant", reply)); speak(reply); return
            }
            busy = true; status = "Thinking…"
            scope.launch {
                val result = withContext(Dispatchers.IO) { askModel(endpoint, model, apiKey, messages.toList()) }
                busy = false
                val answer = result.getOrElse { "I couldn't connect: ${it.message ?: "unknown error"}. Check your endpoint, model and API key." }
                messages.add(ChatLine("assistant", answer)); status = if (result.isSuccess) "Ready" else "Connection issue"
                speak(answer)
            }
        }

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Color(0xFFFF303B), secondary = Color(0xFFFF6A43), background = Color(0xFF090709), surface = Color(0xFF171116),
            onBackground = Color(0xFFF7EFF2), onSurface = Color(0xFFF7EFF2)
        )) {
            Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF17090D), Color(0xFF080709), Color(0xFF10080C)))).padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("ANU AI", fontSize = 25.sp, fontWeight = FontWeight.Black, color = Color.White, letterSpacing = 2.sp)
                        Text("YOUR PERSONAL AI ASSISTANT", fontSize = 9.sp, color = Color(0xFFFF5962), letterSpacing = 1.8.sp)
                    }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Color(0xFFFF5962)) }
                }
                Box(Modifier.fillMaxWidth().height(245.dp), contentAlignment = Alignment.Center) {
                    EnergyOrb(listening || busy)
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.offset(y = 94.dp)) {
                        Text(if (busy) "THINKING" else if (listening) "LISTENING" else "ANU IS ONLINE", color = Color(0xFFFF727A), fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        Text(status, color = Color(0xFFB7A8AD), fontSize = 11.sp)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                    Text("CONVERSATION", color = Color(0xFFFF6871), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { messages.clear(); messages.add(ChatLine("assistant", "Chat cleared. What shall we do next?")) }) { Text("Clear", color = Color(0xFFBBAAB0), fontSize = 11.sp) }
                }
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                    items(messages) { line ->
                        val isUser = line.role == "user"
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start) {
                            Column(Modifier.widthIn(max = 310.dp).clip(RoundedCornerShape(16.dp)).background(if (isUser) Color(0xFF42151D) else Color(0xFF1C171B)).border(1.dp, if (isUser) Color(0x66FF4654) else Color(0xFF34252B), RoundedCornerShape(16.dp)).padding(12.dp)) {
                                Text(if (isUser) "YOU" else "ANU", color = Color(0xFFFF737C), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp)); Text(line.text, color = Color(0xFFF4ECEF), fontSize = 14.sp, lineHeight = 20.sp)
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lightbulb, null, tint = Color(0xFFFF5962), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp)); Text("Try: ‘Explain this’, ‘Help me plan’, or ‘Lock my screen’", color = Color(0xFF9E8F95), fontSize = 10.sp)
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(Color(0xFF21181D)).border(1.dp, Color(0xFF503039), RoundedCornerShape(24.dp)).padding(horizontal = 15.dp, vertical = 13.dp)) {
                        if (draft.isEmpty()) Text("Message ANU…", color = Color(0xFF9D8C92), fontSize = 14.sp)
                        BasicTextField(value = draft, onValueChange = { draft = it }, modifier = Modifier.fillMaxWidth(), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), maxLines = 4)
                    }
                    Spacer(Modifier.width(7.dp))
                    IconButton(onClick = {
                        if (listening) { speechRecognizer?.cancel(); listening = false; status = "Voice input stopped" }
                        else if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            listening = true; status = "Listening…"; startListening { recognized -> draft = recognized; listening = false; status = "Voice captured" }
                        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }, modifier = Modifier.size(48.dp).background(if (listening) Color(0xFF8E1D2A) else Color(0xFF35141C), CircleShape)) {
                        Icon(if (listening) Icons.Default.Stop else Icons.Default.Mic, "Voice input", tint = Color(0xFFFF737C))
                    }
                    IconButton(onClick = { submit(draft) }, enabled = !busy, modifier = Modifier.size(48.dp).background(Color(0xFFDA2637), CircleShape)) {
                        Icon(Icons.Default.Send, "Send", tint = Color.White)
                    }
                }
            }
        }

        if (showSettings) {
            AlertDialog(onDismissRequest = { showSettings = false }, containerColor = Color(0xFF1B1116), title = { Text("ANU AI settings", color = Color.White) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                        Text("OpenAI-compatible API", color = Color(0xFFFF737C), fontSize = 12.sp)
                        SettingsField("API endpoint", endpoint) { endpoint = it }
                        SettingsField("Model", model) { model = it }
                        SettingsField("API key", apiKey, secret = true) { apiKey = it }
                        HorizontalDivider(color = Color(0xFF51303A))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("Keep screen awake", color = Color.White); Text("Prevent sleep while ANU is open", color = Color.LightGray, fontSize = 11.sp) }
                            Switch(keepAwake, { keepAwake = it })
                        }
                        Text("Screen lock", color = Color(0xFFFF737C), fontSize = 12.sp)
                        Text("To enable ‘lock my screen’, open Android Accessibility settings and turn on ANU AI screen lock. Android requires you to approve this manually.", color = Color(0xFFD4C5CA), fontSize = 12.sp)
                        OutlinedButton(onClick = { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Open Accessibility settings") }
                        Text("Privacy: your API key is stored in this app's private preferences. For a public release, use a secure backend proxy instead of embedding a provider key in an APK.", color = Color(0xFFB7A8AD), fontSize = 10.sp)
                    }
                }, confirmButton = { TextButton(onClick = {
                    prefs.edit().putString("api_key", apiKey.trim()).putString("endpoint", endpoint.trim()).putString("model", model.trim()).apply()
                    showSettings = false; status = "Settings saved"
                }) { Text("Save", color = Color(0xFFFF737C)) } }, dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel", color = Color.LightGray) } })
        }
    }

    private fun startListening(onResult: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { runOnUiThread { onResult("") } }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    runOnUiThread { onResult(words) }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            recognizer.startListening(intent)
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy(); speechRecognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
}

private data class ChatLine(val role: String, val text: String)

@Composable
private fun EnergyOrb(active: Boolean) {
    val infinite = rememberInfiniteTransition(label = "orb")
    val rotation by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(if (active) 2600 else 6500, easing = LinearEasing), RepeatMode.Restart), label = "rotation")
    val pulse by infinite.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(if (active) 650 else 1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    Canvas(Modifier.size(218.dp).scale(pulse)) {
        val c = center; val radius = size.minDimension * .30f
        drawCircle(Brush.radialGradient(listOf(Color(0x88FF172B), Color(0x33C20B27), Color.Transparent), c, radius * 1.9f), radius * 1.9f)
        drawCircle(Brush.radialGradient(listOf(Color(0xFFFFB0B2), Color(0xFFE51D35), Color(0xFF4A0715), Color(0xFF10070B)), c, radius), radius)
        drawCircle(Color(0xAAFF6A75), radius * 1.25f, style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
        rotate(rotation) {
            drawOval(Color(0xCCFF4656), topLeft = Offset(c.x - radius * 1.55f, c.y - radius * .55f), size = androidx.compose.ui.geometry.Size(radius * 3.1f, radius * 1.1f), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
            drawCircle(Color(0xFFFFB2B7), radius * .035f, Offset(c.x + radius * 1.53f, c.y))
        }
        drawCircle(Color(0xFFFFE2E4), radius * .045f, Offset(c.x - radius * .24f, c.y - radius * .2f))
    }
}

@Composable
private fun SettingsField(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
    Column {
        Text(label, color = Color(0xFFBDAAB1), fontSize = 11.sp)
        var visible by remember { mutableStateOf(false) }
        OutlinedTextField(value, onChange, singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (secret && !visible) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
            trailingIcon = if (secret) ({ IconButton(onClick = { visible = !visible }) { Icon(if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Toggle key visibility") } }) else null,
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Color(0xFFFF5962), unfocusedBorderColor = Color(0xFF57333D)))
    }
}

private fun askModel(endpoint: String, model: String, key: String, history: List<ChatLine>): Result<String> = runCatching {
    require(endpoint.startsWith("https://")) { "Use an HTTPS endpoint" }
    require(model.isNotBlank()) { "Model name is empty" }
    val url = URL(endpoint)
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
        setRequestProperty("Content-Type", "application/json")
        setRequestProperty("Authorization", "Bearer $key")
    }
    val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", "You are ANU AI, a helpful, honest Android voice assistant. Keep answers clear and concise. Never claim to have performed device actions unless the Android app explicitly confirms them. You cannot directly inspect the phone screen or control arbitrary apps."))
    history.takeLast(20).forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
    val body = JSONObject().put("model", model).put("messages", msgs).put("temperature", 0.7)
    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
    val code = connection.responseCode
    val stream = if (code in 200..299) connection.inputStream else connection.errorStream
    val response = stream.bufferedReader().use { it.readText() }
    connection.disconnect()
    if (code !in 200..299) error("HTTP $code: ${response.take(500)}")
    JSONObject(response).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
}
