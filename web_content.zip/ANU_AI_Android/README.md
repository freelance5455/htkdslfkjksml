# ANU AI — Android starter rebuild

A native Android Studio project that adapts the reusable assistant concepts from ZORIN-M4 into an Android-first ANU AI app.

## What is implemented

- Native Android app (Kotlin + Jetpack Compose), dark red interface and animated energy orb.
- Text chat UI and OpenAI-compatible HTTPS chat-completions client.
- Configurable API endpoint, model and API key in app-private preferences.
- Android speech recognition input and Android Text-to-Speech replies.
- Local, explicit screen-lock command using an AccessibilityService (`lock my screen`). The user must manually enable the service in Android Accessibility settings.
- Optional keep-screen-awake toggle.
- Bounded conversation context (last 20 turns sent to the model).
- Network errors shown to the user; no fake success messages.

## What was adapted from ZORIN-M4

ZORIN-M4 is a Windows desktop assistant. Its intent/planning/orchestration, provider abstraction, conversation memory, confirmation/risk model, voice interaction design and honest execution reporting informed this Android rebuild. The Windows executor, UI Automation, Windows audio device stack, desktop window/screenshot controls, and Python desktop runtime are **not** copied because they are not Android-compatible. Android-native equivalents must respect runtime permissions and OS restrictions.

## Build

1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`ANU_AI_Android`) in Android Studio.
3. Let Gradle sync and install any requested SDK/build tools.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**. For an APK use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The project uses JDK 17 and Android Gradle Plugin 8.7.3. A Gradle wrapper is not included; Android Studio can import and sync the project with its Gradle installation.

## First launch

1. Open Settings (gear).
2. Add an API endpoint, model name and API key for an OpenAI-compatible chat-completions service. Default endpoint/model are `https://api.openai.com/v1/chat/completions` and `gpt-4o-mini`.
3. Save, then send a message. An API account/key and network connection are required for AI answers.
4. Tap the microphone and grant microphone permission for speech input.
5. For screen lock, open **Settings → Open Accessibility settings** and manually enable **ANU AI screen lock**. Then say/type “lock my screen”. Android will only permit the global lock action after the user enables the accessibility service.

## Important limitations and next milestones

- This is a working starter project, not a signed/release APK. It has not been built on an Android SDK in this environment; import and compile in Android Studio first.
- Speech recognition uses Android's installed recognition service and may require internet depending on the device/language pack. It is push-to-talk, not always-listening wake-word mode.
- Screen lock is implemented with explicit user opt-in. A normal app cannot silently turn the display off or bypass the lock screen. Wake/turn-on behavior is controlled by Android and varies by OEM; this project does not claim to override it.
- Screen understanding, screenshot sharing, app launching, background wake-word service, persistent memory database, provider-specific Gemini Live streaming, and verified multi-step Android actions are not yet implemented. They need separate Android-native modules and additional permissions/consent.
- The current API key is stored in app-private SharedPreferences. This is suitable only for a personal prototype; app-private storage is not a secure secret vault against rooted devices or APK/runtime extraction. For distribution, move provider credentials to a backend proxy and add authentication/rate limits.
- The AI response is text-generated and then spoken by Android TTS. Device actions are not delegated to model-generated code. Only the app's fixed screen-lock phrase can trigger the lock action.

## Project structure

```
app/src/main/
  AndroidManifest.xml
  java/com/anuai/assistant/
    MainActivity.kt
    ScreenLockAccessibilityService.kt
  res/xml/accessibility_service_config.xml
  res/values/styles.xml
```

## Source reference

Original source archive: `ZORIN-M4-source.zip`. This Android project is a clean-room adaptation; the original archive is not modified.


## Included HTML interface

The standalone ANU AI interface is included in both locations:

- `index.html` — convenient root-level copy to open and edit in a browser.
- `app/src/main/assets/index.html` — packaged Android app asset.

The Android app's current home screen is still the native Jetpack Compose interface. The HTML file is bundled as a project asset for preview/custom WebView integration; it is not automatically displayed by the native home screen.
