CAPA PRO — projeto Android

Este é um projeto Android Studio que empacota o painel CAPA PRO em um aplicativo Android (WebView local). Ele não se conecta ao Free Fire, não modifica o jogo e não automatiza disparos.

COMO GERAR O APK
1. Em um computador, instale o Android Studio pelo site oficial: https://developer.android.com/studio
2. Extraia o ZIP.
3. No Android Studio, escolha Open e selecione a pasta CapaProAndroid extraída.
4. Aguarde a sincronização do Gradle e instale o Android SDK Platform 35 se o Android Studio pedir.
5. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
6. Ao concluir, clique em Locate. O APK de teste normalmente fica em app/build/outputs/apk/debug/app-debug.apk.
7. Envie o APK ao celular e instale. O Android pode pedir autorização para instalar apps dessa origem.

OBSERVAÇÃO
Este ambiente não tem Android SDK/Gradle instalados, então foi possível preparar o projeto, mas não compilar e validar o APK aqui. O APK deve ser gerado pelo Android Studio seguindo os passos acima.
