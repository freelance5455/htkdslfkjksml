# Obra Asfalto — controle de apontamentos

Aplicativo em português para Android e navegador, com interface azul e branca. A versão entregue começa vazia: não há máquinas, caçambas nem registros fictícios.

## Funções implementadas

- Cadastro, edição e exclusão de máquinas e caçambas, com validação de identificadores duplicados.
- Apontamentos de horímetro para máquinas, com cálculo automático e validação de leituras.
- Relatórios semanais por caçamba cadastrada, com leituras separadas de horímetro e quilometragem, sete campos diários de cargas e total automático.
- Histórico com filtros por tipo, equipamento e intervalo de datas; edição, exclusão com confirmação e reexportação.
- PDF verdadeiro gerado localmente (estrutura PDF 1.4) e PNG verdadeiro renderizado em canvas, ambos com download.
- Compartilhamento de arquivos via Web Share API quando suportado; caso contrário, baixa o arquivo para compartilhamento manual.
- Armazenamento persistente local via IndexedDB; cache de arquivos da interface via Service Worker para uso offline depois da primeira abertura.
- Sem bibliotecas de terceiros carregadas por CDN.

## Abrir para testar no computador

Por segurança, IndexedDB e Service Worker têm suporte mais previsível em `localhost` ou HTTPS do que ao abrir o arquivo HTML diretamente.

1. Instale Node.js LTS.
2. Na pasta do projeto, execute um servidor estático simples, por exemplo:

   ```bash
   npx --yes http-server app -p 8080
   ```
3. Abra `http://localhost:8080` no navegador.

No Android, pode testar usando um servidor HTTPS local/rede ou instalar o APK gerado pelos passos abaixo.

## Converter o projeto em APK Android

O ZIP contém o projeto web e a configuração Capacitor. Para compilar um APK é necessário um computador com Node.js LTS, Android Studio e Android SDK instalados. O APK não é compilado dentro deste ZIP.

1. Extraia o ZIP.
2. Abra um terminal na pasta `obra-asfalto` (a pasta que contém `package.json`).
3. Execute:

   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

   Se `android/` já existir, não execute `npx cap add android` novamente; use `npx cap sync android`.
4. No Android Studio, aguarde a sincronização do Gradle. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração costuma ficar em `android/app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira o APK ao celular e abra-o para instalar. Talvez seja necessário autorizar temporariamente a instalação de apps dessa origem nas configurações do Android. Instale apenas APKs que você mesmo compilou ou cuja origem confia.

A compilação exige internet para baixar dependências do npm/Gradle na primeira vez. Depois de instalado, os recursos de cadastro, cálculo, histórico e exportação funcionam localmente; compartilhar usa os aplicativos disponíveis no aparelho. A primeira abertura da versão web precisa carregar os arquivos para que o cache offline seja preparado.

## Armazenamento e cópias de segurança

Os dados são guardados no armazenamento do aplicativo/navegador, não em um servidor. Limpar os dados do aplicativo ou desinstalar pode apagá-los. Faça cópias de segurança do dispositivo; a exportação de relatórios não é uma cópia completa do banco de dados.

## Validações importantes

- Leituras negativas são recusadas; leitura atual precisa ser maior ou igual à anterior.
- Cargas aceitam inteiros a partir de zero.
- Identificações de máquina/caçamba e placa são verificadas para evitar duplicações.
- Excluir um cadastro pede confirmação e não apaga apontamentos antigos. Relatórios antigos mantêm o retrato dos dados registrados.

## Observação de compatibilidade

O botão de compartilhamento de arquivo depende do suporte do navegador/WebView e do Android. Se não estiver disponível, o aplicativo baixa um arquivo real para que possa ser anexado manualmente no WhatsApp ou em outro app.
