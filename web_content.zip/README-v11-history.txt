LOONIE ACADEMY v11 — CAREER PATHWAYS & PORTFOLIOS (PHASE 5)
2026-11-15 | Complete offline-first HTML/PWA package

BUILD SOURCE & PRESERVATION
---------------------------
Built DIRECTLY from the user-supplied v10 Knowledge Kingdom ZIP:
Loonie_Academy_v10_Knowledge_Kingdom(1).zip
The original uploaded ZIP is unchanged. This v11 is a complete installable
website/PWA package, not a patch. All original v8, v9 and v10 modules and the
384-lesson/37-subject/2,022-question curriculum are preserved. The earlier
README and QA reports are included as history.

NEW IN v11 / PHASE 5
-------------------
1. CAREER PATHWAYS
   - Eight career tracks: Accounting & Bookkeeping; Carpentry & Estimating;
     Electrical Fundamentals; Automotive Diagnostics; Software & Data;
     Small Business & Operations; HVAC & Facilities; Digital Design & UX.
   - Each pathway links to four real existing Academy lessons and two new
     practical projects. Completing the original lessons and their quizzes
     unlocks the first project; all four lessons and the first passed
     project are required for the second project.
   - Search/filter career tracks, select active track, see learning milestones,
     saved progress, next study actions and honest work-related guidance.
   - Career study plan with local saved goal and weekly study target.
   - No artificial claim of apprenticeship status, formal credits, employment
     readiness, employer endorsement, licences or professional credentials.

2. SIXTEEN SUBSTANTIVE PRACTICE PROJECTS
   - 2 unique fictional cases per track (16 in total), ranging from bank
     reconciliations, profit reporting, material takeoffs and job quotes to
     ideal circuit calculations, service estimates, data cleaning, QA reports,
     cost modelling, energy usage and usability measurements.
   - 64 objective checked questions in total: numeric answers with defined
     numeric tolerance and multiple-choice decisions with explanations.
   - Three typed original-work evidence prompts per case, saved immediately
     while typing. All three must have at least 25 characters. The text is
     collected, NOT semantically graded or independently verified.
   - Passing requirement >=3/4 objective checks plus written evidence.
   - A first pass awards 60 XP + 40 coins ONE TIME. All replays are practice
     only. Grade feedback shows worked calculations and decision reasons.
   - Passed work can be revised in the learner's portfolio without removing
     the original score or earning duplicate completion rewards.

3. PRIVATE PORTFOLIO STUDIO
   - Graduated practice-case evidence appears automatically after a pass.
   - Learners can include/exclude individual portfolio entries from exports.
   - Up to 30 independent personal work samples can be added, edited, removed,
     and linked to an optional HTTP(S) work URL. Personal samples are clearly
     labelled self-reported and not formally graded by the Academy.
   - Optional display name, headline, personal overview and contact field;
     these are NOT filled in with personal contact data automatically.
   - Three offline exports: portfolio HTML (open and print/save to PDF),
     Markdown text and a JSON portfolio bundle. Exports include ONLY selected
     portfolio entries and optional portfolio profile text, not the rest of
     the app's backups or Kingdom field notes.
   - The pre-existing Me -> Backup & Restore saves complete careerV11 state
     alongside legacy progress, and remains backward compatible.
   - Five new career achievements; old achievements are unchanged.

4. APP NAVIGATION
   - Career Pathways entry on Learn and inside the old Career Centre.
   - My Career Portfolio entry on Me. Old resume builder, interview practice,
     trade comparison, and study planner are still present and usable.
   - These new screens are offline-first; they require no cloud account,
     external AI service, or server-backed evaluation.

PRESERVED SYSTEMS
-----------------
- Loonie Academy v1-v7 lessons, trade content, rewards, subjects, study and
  review tools, original campus, certificates, and pre-v11 saved progress.
- v8 Personal University: four semesters, exams, assignments, capstones,
  unofficial transcripts, gradebooks and older backup compatibility.
- v9 Interactive Inquiry: nine labs, six evidence investigations, all three
  Teach Lou Plus modes and the research notebook.
- v10 Knowledge Kingdom: six regions, 12 learning quests, six guardians,
  18 building upgrades, six relics, daily dispatch, and expedition journal.
- Original 2026 tax figures and simplified educational models are preserved;
  verify current real-world regulations separately before applying them.

UPGRADE SAFELY FROM v10
-----------------------
1. BEFORE changing any files, open your EXISTING v10 app at its current
   hosting address. Choose Me -> Backup & Restore -> Download backup and
   keep that backup in a separate folder. Keep your v10 ZIP too.
2. Extract the ENTIRE v11 ZIP, preserving all files in the same directory
   (index.html, .js, .css, icons, webmanifest, sw.js). This package contains
   the complete app and shouldn't be installed by replacing only index.html.
3. For HTTPS-hosted or already installed PWAs, upload the new files to the
   EXACT SAME origin and path as the old v10 assets. Do NOT uninstall the
   installed app, clear site data or switch domain: localStorage is scoped
   to the existing origin and may otherwise appear empty.
4. Reopen/refresh while online once so the updated service worker can cache
   new JS/CSS files; if necessary, close and reopen the installed PWA.
5. On Learn, tap Career Pathways v11; on Me, tap My Career Portfolio. Confirm
   your old lessons, notes, Kingdom journal and University progress survived.
6. Try a lesson-linked case (complete the prerequisite quizzes if needed),
   add a private project note, then use Me -> Backup & Restore again to save
   an updated v11 backup.
7. Physically verify installation and airplane-mode reopening on your own
   Android device. Hardware offline installation was not available for QA.

RUNNING LOCALLY
---------------
- Open index.html as a standard webpage for desktop inspection; file://
  browser storage and download behavior vary by browser.
- For install/offline service workers, host using HTTPS or localhost.
- Visual Google Fonts and the optional legacy Python browser playground may
  require network access on first use. Core Career Pathways, Kingdom, Inquiry
  and University JavaScript modules do not need external internet resources.
- All portfolio and learner progress remains in THIS BROWSER's local storage.
  Browser data clearing or storage eviction can erase it: export backups.

DEVELOPER QA
------------
See QA-v11.txt. From the extracted directory with Python 3, Playwright,
Chromium and Node.js installed, run:
   python qa-phase5.py
   python qa-phase4-v11.py
   python qa-phase3-v11.py
   python qa-phase2-v11.py
   node qa-sw-v11.js
Tests inline all six core scripts in isolated Chromium with fake localStorage
because local HTTP navigation is blocked in the test environment. No test
mutates your real personal progress. The source modules remain separate in the
shipped app. Tests for older versions are retained for reference.

IMPORTANT LIMITATIONS
---------------------
- Automated written-note evaluation is NOT implemented. A 25-character
  length check is not evidence that the explanation is accurate.
- Project numeric checks are training exercises with invented data, not live
  client cases, diagnostic services or safe physical work instructions.
- Career and university completion does NOT confer professional, educational,
  regulatory or employment credentials.
- User-entered portfolio text, external URLs and optional contact information
  may be exposed if the user exports/shares the portfolio themselves. No
  automatic uploads or public sharing are performed by the app.
- Android hardware, real HTTPS hosting upgrades, actual offline reopening,
  browser storage eviction and every historic lesson/minigame were not tested.
- Original PWA files and user backups should be retained for rollback.

NEXT STEP
---------
Phase 5 is implemented and tested; the sixth major roadmap phase is NEXT and
is not included in this ZIP. Continue after validating v11 on your device.
