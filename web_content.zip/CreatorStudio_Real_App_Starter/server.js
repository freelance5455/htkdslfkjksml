require("dotenv").config();
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const maxMb = Number(process.env.MAX_UPLOAD_MB || 40);
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).slice(0, 10))
});
const upload = multer({
  storage,
  limits: { fileSize: maxMb * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /^(image|video|audio)\//.test(file.mimetype);
    cb(ok ? null : new Error("Only image, video or audio files are accepted."), ok);
  }
});

// Demo job store. Replace with a persistent database/queue before public deployment.
const jobs = new Map();

app.get("/api/health", (_req, res) => res.json({
  ok: true,
  app: "Creator Studio AI",
  providerMode: process.env.VIDEO_PROVIDER || "demo",
  configured: Boolean(process.env.VIDEO_API_URL && process.env.VIDEO_API_KEY && process.env.VIDEO_MODEL)
}));

app.post("/api/jobs", upload.single("media"), async (req, res) => {
  try {
    const prompt = String(req.body.prompt || "").trim();
    const mode = String(req.body.mode || "text-to-video");
    if (!prompt) return res.status(400).json({ error: "Please enter a prompt." });
    const allowed = ["text-to-video","image-to-video","video-to-video","audio-to-video","script","voice","subtitles","image","thumbnail","music","seo"];
    if (!allowed.includes(mode)) return res.status(400).json({ error: "Unsupported generation mode." });
    if (mode !== "text-to-video" && mode !== "script" && mode !== "seo" && !req.file) {
      return res.status(400).json({ error: "This mode needs an uploaded media file." });
    }

    const job = {
      id: crypto.randomUUID(),
      mode, prompt,
      options: {
        format: req.body.format || "9:16",
        duration: req.body.duration || "30 seconds",
        language: req.body.language || "Bengali",
        style: req.body.style || "Cinematic",
        voice: req.body.voice || "Default"
      },
      uploadName: req.file ? req.file.originalname : null,
      status: "queued",
      createdAt: new Date().toISOString(),
      message: "Job accepted. Configure a generation provider to process it."
    };
    jobs.set(job.id, job);

    // Safe starter behavior: no fake output and no secret key in the client.
    // Provider-specific API adapters belong here because each provider/model
    // uses a different request schema and may return an asynchronous job ID.
    if (process.env.VIDEO_PROVIDER === "demo") {
      job.status = "needs-provider";
      job.message = "Backend received your request. Add a supported provider adapter and server-side credentials to generate media.";
    } else if (!process.env.VIDEO_API_URL || !process.env.VIDEO_API_KEY || !process.env.VIDEO_MODEL) {
      job.status = "needs-configuration";
      job.message = "Provider configuration is incomplete. Set VIDEO_API_URL, VIDEO_API_KEY and VIDEO_MODEL on the server.";
    } else {
      job.status = "provider-adapter-required";
      job.message = "Credentials are present, but a provider-specific adapter must be implemented for the selected model before real generation.";
    }
    res.status(202).json({ job });
  } catch (e) {
    res.status(500).json({ error: "Could not create job.", detail: e.message });
  }
});

app.get("/api/jobs/:id", (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: "Job not found." });
  res.json({ job });
});

app.use((err, _req, res, _next) => {
  const status = err instanceof multer.MulterError ? 400 : 400;
  res.status(status).json({ error: err.message || "Request failed." });
});

app.listen(PORT, () => console.log(`Creator Studio AI running at http://localhost:${PORT}`));
