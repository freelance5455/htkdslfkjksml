CREATOR STUDIO AI — REAL APP STARTER SOURCE

এই ZIP-এ আগের শুধু-static HTML-এর বদলে একটি Node.js backend ও mobile-friendly frontend আছে।

যা এখন কাজ করে:
- Android-friendly UI
- Text-to-video, image-to-video, video-to-video, audio-to-video সহ tool selection
- Image/video/audio upload গ্রহণ
- Backend health check
- Job তৈরি ও status endpoint
- Server-side .env configuration structure
- API key client/APK-তে না রেখে backend-এ রাখার কাঠামো

যা এখনো স্বয়ংক্রিয়ভাবে কাজ করে না:
- AI provider-এর সঙ্গে বাস্তব generation
- AI voice/music/subtitle output
- MP4 rendering/export
কারণ প্রতিটি AI provider ও model-এর API input/output আলাদা। নির্দিষ্ট provider/model বেছে adapter লিখতে হবে এবং সার্ভারে credentials বসাতে হবে। কোনো ভুয়া MP4 তৈরি করে দেখানো হয় না।

চালানোর জন্য:
1) Node.js ইনস্টল করা কম্পিউটার বা hosting/server লাগবে।
2) ZIP extract করো।
3) Terminal-এ project folder খুলে `npm install` চালাও।
4) `.env.example` কপি করে `.env` বানাও।
5) `npm start` চালাও।
6) browser-এ `http://localhost:3000` খোলো।

Android-only:
শুধু ফোন ও Chrome দিয়ে Node backend সবসময় চালানো কঠিন। Backend deploy করার জন্য hosting/server লাগবে। APK WebView শুধু frontend দেখাবে; AI processing server-এ হবে।

API setup:
- .env-এ VIDEO_PROVIDER, VIDEO_API_URL, VIDEO_API_KEY, VIDEO_MODEL আছে।
- এগুলো placeholder মাত্র; কোনো provider key দেওয়া নেই।
- API key কখনো public/index.html বা APK-তে লিখবে না।
- API account/payment-এ অভিভাবকের সাহায্য নাও। কোনো secret key chat-এ পাঠিও না।

পরবর্তী developer step:
একটি নির্দিষ্ট video-generation provider/model নির্বাচন করে server.js-এ provider-specific adapter implement করতে হবে; তারপর image/video/audio inputs, polling/webhook, asset download, voice/subtitle/music, FFmpeg composition, storage ও export যোগ করতে হবে।
