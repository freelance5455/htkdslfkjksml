# SmartTask AI — Working responsive prototype

## Included
- Responsive manager dashboard for desktop, tablet and mobile browsers.
- Demo organisation seeded with 120 fictional employees across eight departments.
- Employee directory: search, filter, add and edit staff, skills, capacity and availability.
- Daily task register: create, edit, filter and update task statuses.
- Explainable AI-style recommendation engine: ranks eligible employees using skill match, availability, remaining capacity and task priority.
- Manager approval: recommendations never assign work until the manager clicks Approve.
- Dashboard, operational insights, CSV export and JSON backup/import.
- PWA manifest and service worker for install/offline shell caching.

## Run on a computer
1. Extract the ZIP.
2. Open a terminal in the extracted `SmartTask_AI` folder.
3. Run `python -m http.server 8000`
4. Open `http://localhost:8000` in Chrome, Edge or Firefox.

## Run on Android / iPhone
For installation, host the folder on an HTTPS web host (or use localhost for local testing).
1. Open the HTTPS address in Chrome on Android or Safari on iPhone.
2. Use the browser menu: **Install app** / **Add to Home Screen**.
3. The app opens in an app-like full-screen window. It is also responsive when used directly in a browser.

## Demo login
No login is configured in this local prototype. It opens in a manager workspace with sample data. Do not enter real employee personal information into a shared/public device.

## Important implementation notes
- This is a functional front-end prototype. Its recommendation engine is a transparent, deterministic scoring algorithm, not a connected large language model.
- Data is stored in browser `localStorage` on the device. Different devices/users do not share data.
- Before organisational production use, add a secure backend API, central PostgreSQL database, user authentication, role-based permissions, audit logs, encrypted transport/storage, backups, notifications and deployment monitoring.
- Validate local labour rules, working-hour limits, employee consent and organisational HR policies before using performance scoring.
- The manager remains accountable for reviewing and approving assignments.
