import 'dotenv/config';
import express from 'express';
import rateLimit from 'express-rate-limit';

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '10kb' }));
app.use(express.static('public'));

const P = process.env.IMAGE_PROVIDER || (process.env.TOGETHER_API_KEY ? 'together' : 'openai');
const KEY = P === 'together' ? process.env.TOGETHER_API_KEY : process.env.OPENAI_API_KEY;

const TYPES = {
  ebook: 'professional ebook cover design',
  product_design: 'clean modern digital product design mockup',
  logo: 'minimalist vector logo on a plain background',
  ad: 'professional advertising visual, commercial quality',
  instagram: 'eye-catching instagram post graphic',
  course: 'online course cover, modern educational design',
  product_photo: 'professional studio product photography, soft lighting',
  three_d: '3D render, high detail, octane render'
};
const STYLES = {
  cinematic: 'cinematic lighting, dramatic', digital: 'digital illustration, vibrant',
  minimal: 'minimalist, clean, lots of space', realistic: 'photorealistic, sharp focus',
  watercolor: 'soft watercolor painting', neon: 'neon glow, cyberpunk colors'
};
const SIZES = { sq: [1024, 1024, '1024x1024'], tall: [832, 1216, '1024x1536'], wide: [1216, 832, '1536x1024'] };

app.get('/api/status', (_q, r) => r.json({ ready: !!KEY, provider: P }));

// تحويل الفكرة (دارجة/عربية) لوصف بالإنجليزية باش الموديل يفهمها مزيان
async function toEnglish(idea) {
  if (P !== 'together') return idea;
  try {
    const r = await fetch('https://api.together.xyz/v1/chat/completions', {
      method: 'POST', signal: AbortSignal.timeout(15000),
      headers: { Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'meta-llama/Llama-3.3-70B-Instruct-Turbo-Free', max_tokens: 150,
        messages: [
          { role: 'system', content: 'Turn the user\'s image idea (Moroccan Arabic, Arabic, French or English) into one concise, vivid English image prompt. Output only the prompt.' },
          { role: 'user', content: idea }]
      })
    });
    const j = await r.json();
    return j.choices?.[0]?.message?.content?.trim() || idea;
  } catch { return idea; }
}

app.post('/api/generate', rateLimit({ windowMs: 60_000, limit: 6, standardHeaders: true, legacyHeaders: false,
  message: { error: 'بزاف د الطلبات. تسنى شوية وعاود.' } }), async (req, res) => {
  if (!KEY) return res.status(503).json({ error: 'خدمة توليد الصور ما مربوطاش دابا. خاص صاحب التطبيق يزيد API Key.' });
  const { idea, type, style, size } = req.body || {};
  if (typeof idea !== 'string' || idea.trim().length < 3 || idea.length > 500)
    return res.status(400).json({ error: 'كتب فكرة ديال الصورة (من 3 حتى 500 حرف).' });
  const [w, h, oaSize] = SIZES[size] || SIZES.sq;
  try {
    const en = await toEnglish(idea.trim());
    const prompt = `${en}. ${TYPES[type] || ''}. ${STYLES[style] || ''}. High quality, avoid distorted text.`;
    let r;
    if (P === 'together') {
      r = await fetch('https://api.together.xyz/v1/images/generations', {
        method: 'POST', headers: { Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: process.env.TOGETHER_IMAGE_MODEL || 'black-forest-labs/FLUX.1-schnell-Free',
          prompt, width: w, height: h, steps: 4, n: 1, response_format: 'b64_json' })
      });
    } else {
      r = await fetch('https://api.openai.com/v1/images/generations', {
        method: 'POST', headers: { Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'gpt-image-1', prompt, size: oaSize, n: 1 })
      });
    }
    const j = await r.json();
    const b64 = j.data?.[0]?.b64_json;
    if (!r.ok || !b64) {
      console.error('Provider error:', JSON.stringify(j).slice(0, 400));
      return res.status(502).json({ error: 'وقع مشكل فتوليد الصورة. عاود جرّب شوية من بعد.' });
    }
    res.json({ image: b64 });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'وقع مشكل فالسيرفر. عاود جرّب.' });
  }
});

app.listen(process.env.PORT || 3000, () => console.log('جاهز على المنفذ', process.env.PORT || 3000));
