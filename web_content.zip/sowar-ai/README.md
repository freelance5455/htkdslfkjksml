# مولّد الصور بالذكاء الاصطناعي

1. `npm install`
2. `cp .env.example .env` وزيد API Key ديالك (Together ولا OpenAI).
3. `npm start` ثم دخل لـ http://localhost:3000

الـ API Key كيبقى غير فـ `.env` فالسيرفر، عمرو كيوصل للمتصفح.
للنشر: Render / Railway / Fly.io (Node 18+)، وزيد المتغيرات فالإعدادات.
