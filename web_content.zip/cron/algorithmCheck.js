const User = require('../models/User');

// This is an upload-activity reminder only; it does not claim to predict or control an algorithm.
async function checkChannelActivity(logger = console) {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 14);
  const users = await User.find({
    $or: [{ lastUploadDate: null }, { lastUploadDate: { $lt: cutoff } }]
  }).select('username lastUploadDate');

  for (const user of users) {
    logger.log(`[HATIRLATMA] ${user.username}: Son yüklemeniz 14 günden eski. İsterseniz yeni bir video planlayabilirsiniz.`);
  }
  return users.length;
}

module.exports = { checkChannelActivity };
