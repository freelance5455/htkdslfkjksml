# Jungle Rush: Endless Adventure

A playable 2D endless runner built with plain HTML, CSS, and JavaScript. No frameworks or external assets are required.

## Run on a computer
1. Download and unzip `jungle_rush.zip`, or save `index.html`.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, or Safari).
3. Press **PLAY**. Use Space / Up Arrow to jump, Down Arrow to slide, and Escape to pause.

## Run on Android
1. Download `index.html` to your phone.
2. Open it with Chrome or another modern browser. If your file manager cannot open local HTML, use a simple local web server app or upload the file to a static website host and open that URL.
3. Tap the screen to jump. Tap near the bottom of the play area to slide while grounded. A quick double-tap can trigger a stronger jump.
4. Use the on-screen buttons for pause and sound.

## Features
- Cartoon jungle backdrop, custom animated runner, and endless obstacle generation
- Coins, increasing speed/difficulty, collision detection, and distance score
- Shield and coin-magnet power-ups
- Eight patterned character skins, purchased with coins
- High score, coins, unlocked skins, and selected skin saved in browser local storage
- Missions, menu, pause, game-over screen, loading screen, and simple synthesized sound effects
- Responsive layout for mobile and desktop

## Notes
- Progress is stored locally in the browser on that device. Clearing browser data can erase it.
- Sound starts after interacting with the page and can be muted with the sound button.
- This is a self-contained starter game. It does not include online leaderboards, cloud saves, or a native Android APK.
