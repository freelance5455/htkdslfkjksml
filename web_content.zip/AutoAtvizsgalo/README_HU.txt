AUTOATNEZO – ANDROID PROJEKT

Mit tartalmaz?
- Univerzális, bármilyen márkájú és típusú autóhoz használható ellenőrzőlista.
- Járműadatok: márka, modell, évjárat, kilométeróra, üzemanyag, váltó, irányár, műszaki.
- Ellenőrzési fejezetek: telefonos egyeztetés, papírok, hidegindítás, motor és folyadékok,
  karosszéria és korrózió, menetpróba, elektronika és utastér.
- Minden pontnál OK / HIBA / NEM NÉZTEM állapot és saját megjegyzés.
- Készültségi százalék, hibaösszesítés és kritikus hibák kiemelése.
- Automatikus helyi mentés a telefonon (localStorage), internet nélkül is működik.
- JSON export/import, nyomtatás/PDF.

APK készítése Windows gépen:
1. Telepítsd az Android Studio-t: https://developer.android.com/studio
2. Csomagold ki az AutoAtnezo_AndroidProjekt.zip fájlt.
3. Android Studio > Open > válaszd ki az AutoAtvizsgalo mappát.
4. Várd meg a Gradle Sync befejezését. Első alkalommal internetkapcsolat kellhet a fejlesztői
   függőségek letöltéséhez.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. A debug APK itt található: app/build/outputs/apk/debug/app-debug.apk
7. Másold a telefonra és telepítsd. Ha kéri, engedélyezd az adott fájlkezelőnek az ismeretlen
   alkalmazások telepítését.

MEGJEGYZÉS
A fejlesztői környezetben nem volt telepítve Android SDK/Gradle, ezért itt nem tudtam kész APK-t
fordítani. A teljes Android Studio projekt és a webes alkalmazás forrása benne van a ZIP-ben.
A checklist általános helyszíni segédlet, nem helyettesít szakszervizes átvizsgálást.
