package com.nexuslab.ffpanel

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class FloatingPanelService : Service() {
    companion object {
        const val ACTION_SHOW = "com.nexuslab.ffpanel.SHOW"
        const val ACTION_STOP = "com.nexuslab.ffpanel.STOP"
        private const val CHANNEL_ID = "lost_dreams_overlay"
        private const val NOTIFICATION_ID = 4107
        @Volatile var isRunning: Boolean = false
    }

    private lateinit var windowManager: WindowManager
    private var overlayWebView: WebView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopPanel()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        getSharedPreferences("lost_dreams", MODE_PRIVATE)
            .edit().putBoolean("auto_launch", true).apply()
        isRunning = true
        if (overlayWebView == null) {
            createOverlay()
        } else {
            expandPanel()
        }
        return START_STICKY
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createOverlay() {
        val web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.setSupportZoom(false)
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(OverlayBridge(), "NexusOverlay")
            loadUrl("file:///android_asset/overlay.html")
        }

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            dp(316),
            dp(500),
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(78)
        }

        try {
            windowManager.addView(web, params)
            overlayWebView = web
            layoutParams = params
        } catch (_: Exception) {
            web.destroy()
            stopPanel()
        }
    }

    private fun expandPanel() {
        val web = overlayWebView ?: return
        val params = layoutParams ?: return
        params.width = dp(316)
        params.height = dp(500)
        try {
            windowManager.updateViewLayout(web, params)
            web.evaluateJavascript("window.showExpanded && window.showExpanded();", null)
        } catch (_: Exception) {
            stopPanel()
        }
    }

    private fun minimizePanel() {
        val web = overlayWebView ?: return
        val params = layoutParams ?: return
        params.width = dp(66)
        params.height = dp(66)
        try {
            windowManager.updateViewLayout(web, params)
            web.evaluateJavascript("window.showMini && window.showMini();", null)
        } catch (_: Exception) {
            stopPanel()
        }
    }

    private fun moveOverlayBy(dx: Float, dy: Float) {
        val web = overlayWebView ?: return
        val params = layoutParams ?: return
        val deltaX = dx.toInt()
        val deltaY = dy.toInt()
        val screen = resources.displayMetrics
        val maxX = (screen.widthPixels - web.width).coerceAtLeast(0)
        val maxY = (screen.heightPixels - web.height).coerceAtLeast(0)
        // END gravity uses an offset measured from the right edge.
        params.x = (params.x - deltaX).coerceIn(0, maxX)
        params.y = (params.y + deltaY).coerceIn(0, maxY)
        try {
            windowManager.updateViewLayout(web, params)
        } catch (_: Exception) {
            // The overlay may be disappearing while a drag event is being delivered.
        }
    }

    private fun stopPanel() {
        removeOverlay()
        getSharedPreferences("lost_dreams", MODE_PRIVATE)
            .edit().putBoolean("auto_launch", false).apply()
        isRunning = false
        try {
            stopForeground(true)
        } catch (_: Exception) {
        }
        stopSelf()
    }

    private fun removeOverlay() {
        val web = overlayWebView
        overlayWebView = null
        layoutParams = null
        if (web != null) {
            try {
                windowManager.removeView(web)
            } catch (_: Exception) {
            }
            web.stopLoading()
            web.removeJavascriptInterface("NexusOverlay")
            web.destroy()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Lost Dreams overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Aviso persistente enquanto o painel demonstrativo está ativo"
                setShowBadge(false)
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, FloatingPanelService::class.java).apply { action = ACTION_STOP }
        val stopAction = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Lost Dreams está ativo")
            .setContentText("Painel visual flutuante · sem integração com o jogo")
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Encerrar", stopAction)
            .build()
    }

    inner class OverlayBridge {
        @JavascriptInterface
        fun minimize() {
            mainHandler.post { minimizePanel() }
        }

        @JavascriptInterface
        fun expand() {
            mainHandler.post { expandPanel() }
        }

        @JavascriptInterface
        fun close() {
            mainHandler.post { stopPanel() }
        }

        @JavascriptInterface
        fun moveBy(dx: Float, dy: Float) {
            mainHandler.post { moveOverlayBy(dx, dy) }
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Intentionally keep the foreground overlay running when the launcher task is removed.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        removeOverlay()
        isRunning = false
        super.onDestroy()
    }
}
