package com.nexuslab.ffpanel

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var sawThreeFingers = false
    private var completedGestureCount = 0
    private var lastGestureAt = 0L

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        }
        window.statusBarColor = Color.rgb(8, 10, 18)
        window.navigationBarColor = Color.rgb(8, 10, 18)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(8, 10, 18))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.setSupportZoom(false)
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(webView)
    }

    /**
     * Counts three-finger tap gestures only while this demo app is on screen.
     * A gesture is one press/release cycle in which at least three pointers
     * were simultaneously down. Three cycles unlock the visual demo panel.
     */
    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                sawThreeFingers = false
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= 3) sawThreeFingers = true
            }
            MotionEvent.ACTION_UP -> {
                if (sawThreeFingers) {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastGestureAt > 2600L) completedGestureCount = 0
                    completedGestureCount += 1
                    lastGestureAt = now
                    webView.evaluateJavascript(
                        "window.onGestureProgress && window.onGestureProgress($completedGestureCount);",
                        null
                    )
                    if (completedGestureCount >= 3) {
                        completedGestureCount = 0
                        webView.evaluateJavascript(
                            "window.unlockDemoPanel && window.unlockDemoPanel();",
                            null
                        )
                    }
                }
                sawThreeFingers = false
            }
            MotionEvent.ACTION_CANCEL -> {
                sawThreeFingers = false
            }
        }
        return super.dispatchTouchEvent(event)
    }


    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.destroy()
        }
        super.onDestroy()
    }
}
