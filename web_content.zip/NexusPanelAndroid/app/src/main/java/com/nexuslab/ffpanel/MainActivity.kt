package com.nexuslab.ffpanel

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("lost_dreams", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 6, 14)
        window.navigationBarColor = Color.rgb(10, 6, 14)
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(true)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this).apply {
            setBackgroundColor(Color.rgb(10, 6, 14))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = false
            settings.setSupportZoom(false)
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(LauncherBridge(), "AppBridge")
            loadUrl("file:///android_asset/launcher.html")
        }
        setContentView(webView)
    }

    override fun onResume() {
        super.onResume()
        if (!::webView.isInitialized) return

        // Complete the first-run permission flow after Android returns from Settings.
        val overlayAllowed = Settings.canDrawOverlays(this)
        if (overlayAllowed && prefs.getBoolean("pending_start", false)) {
            prefs.edit().putBoolean("pending_start", false).apply()
            launchOverlayService()
        } else if (overlayAllowed && prefs.getBoolean("auto_launch", false) && !FloatingPanelService.isRunning) {
            // Restore the selected always-on overlay when the user returns to the app.
            launchOverlayService()
        }
        webView.postDelayed({ pushStatus() }, 180)
    }

    private fun pushStatus() {
        if (!::webView.isInitialized) return
        val permitted = Settings.canDrawOverlays(this)
        val running = FloatingPanelService.isRunning
        webView.evaluateJavascript("window.setAppStatus && window.setAppStatus($permitted, $running);", null)
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            launchOverlayService()
            return
        }
        prefs.edit().putBoolean("pending_start", true).apply()
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        try {
            startActivity(intent)
        } catch (_: Exception) {
            prefs.edit().putBoolean("pending_start", false).apply()
            webView.evaluateJavascript("window.showMessage && window.showMessage('Não foi possível abrir as permissões do Android');", null)
        }
    }

    private fun launchOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            requestOverlayPermission()
            return
        }
        val intent = Intent(this, FloatingPanelService::class.java).apply {
            action = FloatingPanelService.ACTION_SHOW
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        webView.postDelayed({ pushStatus() }, 350)
        webView.evaluateJavascript("window.showMessage && window.showMessage('Painel flutuante iniciado');", null)
    }

    private fun stopOverlayService() {
        prefs.edit().putBoolean("auto_launch", false).apply()
        stopService(Intent(this, FloatingPanelService::class.java))
        webView.postDelayed({ pushStatus() }, 200)
        webView.evaluateJavascript("window.showMessage && window.showMessage('Painel encerrado');", null)
    }

    inner class LauncherBridge {
        @JavascriptInterface
        fun startOverlay() {
            runOnUiThread { requestOverlayPermission() }
        }

        @JavascriptInterface
        fun stopOverlay() {
            runOnUiThread { stopOverlayService() }
        }

        @JavascriptInterface
        fun openOverlaySettings() {
            runOnUiThread {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    webView.evaluateJavascript("window.showMessage && window.showMessage('Permissão já concedida');", null)
                } else {
                    requestOverlayPermission()
                }
            }
        }
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
