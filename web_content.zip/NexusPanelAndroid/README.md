# LOST DREAMS — Floating Overlay Demo

Projeto Android nativo de demonstração. O painel visual pode ficar por cima de outros aplicativos, inclusive do Free Fire, usando a permissão especial do Android **Exibir sobre outros apps**.

## O que está incluído

- Painel flutuante com aparência inspirada na referência enviada: paleta violeta escura, visual CRT/scanlines, estrelas, tipografia pixelada e clima analógico/glitch.
- Janela flutuante arrastável pela barra superior.
- Botão para minimizar em um pequeno ícone e tocar nele para reabrir.
- Botão para encerrar, além de ação para encerrar pela notificação persistente.
- Módulos cenográficos AIMLOCK, ESP VISION, NO RECOIL e SPEED BOOST.
- Radar decorativo, controles deslizantes e presets que alteram somente o painel.
- Serviço em primeiro plano para manter a sobreposição ativa quando o app principal sair da tela.

## Limites importantes

Este projeto é **100% demonstrativo**. Os módulos não fazem cheat real, não leem a tela, não identificam jogadores, não enviam toques ao Free Fire, não alteram memória/arquivos e não modificam a partida. O painel apenas desenha uma janela por cima de outros apps.

O Android exige que a pessoa conceda manualmente a permissão **Exibir sobre outros apps** nas configurações do sistema. O app não usa root nem serviço de acessibilidade.

## Como usar

1. Abra o app no Android.
2. Toque em **START OVERLAY**.
3. Na tela do Android, habilite **Permitir exibição sobre outros apps** para Lost Dreams Overlay e volte ao app.
4. O painel aparecerá sobre outros aplicativos. Abra o Free Fire normalmente.
5. Arraste o painel pela barra superior. Use `—` para minimizar e toque no ícone `✧` para reabrir. Use `×` ou a ação **Encerrar** na notificação para fechar.

A sobreposição fica ativa enquanto o serviço em primeiro plano estiver em execução. O Android ou o fabricante do aparelho ainda pode encerrar serviços por economia de bateria; nesses casos, abra novamente o app e toque em START OVERLAY.

## Gerar o APK

O ambiente em que este projeto foi preparado não possui Android SDK/Gradle instalados, portanto não foi possível entregar um APK compilado nesta sessão.

1. Instale o Android Studio e o Android SDK Platform 35.
2. Abra a pasta `NexusPanelAndroid` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Escolha **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Dados técnicos

- Application ID: `com.nexuslab.ffpanel`
- Min SDK: 23 (Android 6.0)
- Compile SDK: 35
- Target SDK: 32
- Permissões: `SYSTEM_ALERT_WINDOW` e `FOREGROUND_SERVICE`
- Sem internet, sem armazenamento, sem leitura de tela e sem acessibilidade.
