# NEXUS Panel — Android demo

Projeto Android nativo com interface WebView local. O app simula um painel de "cheat" com aparência premium, mas é estritamente cenográfico: não se conecta ao Free Fire, não modifica o jogo e não oferece funções de vantagem competitiva.

## Gesto de ativação

Com o app aberto, encoste **três dedos ao mesmo tempo**, solte e repita o gesto **três vezes**. O painel demonstrativo será aberto. O gesto é reconhecido somente dentro deste aplicativo; ele não intercepta os toques do Free Fire.

## Como gerar o APK

Este ambiente de criação não tem Android SDK/Gradle instalados, então não foi possível compilar um APK instalável aqui. Para gerar o APK:

1. Instale o Android Studio e o Android SDK Platform 35.
2. Abra a pasta `NexusPanelAndroid` no Android Studio.
3. Aguarde o Gradle sincronizar e aceite a instalação dos componentes solicitados.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug será criado em `app/build/outputs/apk/debug/app-debug.apk`.

## Detalhes técnicos

- Package: `com.nexuslab.ffpanel`
- Min SDK: 23 (Android 6.0)
- Target SDK: 35
- Sem permissões de overlay, acessibilidade, rede ou armazenamento.
- Todos os botões e controles alteram somente a interface local.
