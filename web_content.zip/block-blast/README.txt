Block Blast - Capacitor project

1) Quick test: open www/index.html in a mobile browser.

2) Build Android APK:
   npm install
   npx cap add android
   npx cap sync
   npx cap open android     (then Build > Build APK in Android Studio)
   Tip: in android/app/src/main/AndroidManifest.xml add
   android:screenOrientation="portrait" to the <activity> tag.

3) iPhone (needs a Mac + Xcode):
   npx cap add ios
   npx cap sync
   npx cap open ios

Change appId in capacitor.config.json before publishing.
