// SNAPTRIP public browser configuration.
// Replace these placeholders with your Supabase project URL and anon/publishable key.
// NEVER put a Supabase service_role key here.
export const SUPABASE_URL = "https://ezeuxlvukjapyogbpkru.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_PgGY_2UnZdIh_mXRcxmO5w_P36BS5PA";
