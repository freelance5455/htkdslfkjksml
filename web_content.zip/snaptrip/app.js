import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './config.js';

const $ = (id) => document.getElementById(id);
const ui = {
  configNotice: $('configNotice'), authView: $('authView'), appView: $('appView'), headerUser: $('headerUser'), headerAvatar: $('headerAvatar'),
  authForm: $('authForm'), authTitle: $('authTitle'), authSubtitle: $('authSubtitle'), authSubmit: $('authSubmit'), authMessage: $('authMessage'),
  displayNameWrap: $('displayNameWrap'), displayName: $('displayName'), email: $('email'), password: $('password'),
  tripList: $('tripList'), welcomePanel: $('welcomePanel'), tripContent: $('tripContent'), activeTripName: $('activeTripName'),
  memberCount: $('memberCount'), photoCount: $('photoCount'), tripCreated: $('tripCreated'), galleryNumber: $('galleryNumber'), gallery: $('gallery'), membersList: $('membersList'),
  autoUploadConsent: $('autoUploadConsent'), openCameraBtn: $('openCameraBtn'), choosePhotosBtn: $('choosePhotosBtn'), photoPicker: $('photoPicker'), uploadQueue: $('uploadQueue'),
  tripModal: $('tripModal'), tripForm: $('tripForm'), tripNameInput: $('tripNameInput'), tripSubmit: $('tripSubmit'), tripFormMessage: $('tripFormMessage'),
  joinModal: $('joinModal'), joinForm: $('joinForm'), inviteInput: $('inviteInput'), joinSubmit: $('joinSubmit'), joinMessage: $('joinMessage'),
  inviteModal: $('inviteModal'), inviteQr: $('inviteQr'), inviteLinkInput: $('inviteLinkInput'), inviteCodeText: $('inviteCodeText'), inviteMessage: $('inviteMessage'),
  cameraModal: $('cameraModal'), cameraVideo: $('cameraVideo'), cameraPlaceholder: $('cameraPlaceholder'), cameraTripName: $('cameraTripName'), capturePhotoBtn: $('capturePhotoBtn'), cameraMessage: $('cameraMessage'),
  photoModal: $('photoModal'), viewerImage: $('viewerImage'), viewerUploader: $('viewerUploader'), viewerDate: $('viewerDate'), deletePhotoBtn: $('deletePhotoBtn'),
  privacyModal: $('privacyModal'), toast: $('toast')
};

let supabase = null;
let authMode = 'signin';
let currentSession = null;
let currentUser = null;
let profile = null;
let trips = [];
let activeTripId = null;
let members = [];
let photos = [];
let realtimeChannel = null;
let cameraStream = null;
let cameraFacing = 'environment';
let currentViewerPhoto = null;
let toastTimer = null;
let pendingInviteHandled = false;
let refreshingGallery = false;

const configured = typeof SUPABASE_URL === 'string' && /^https:\/\/[a-zA-Z0-9-]+\.supabase\.co\/?$/.test(SUPABASE_URL) &&
  typeof SUPABASE_ANON_KEY === 'string' && SUPABASE_ANON_KEY.length > 30 && !SUPABASE_ANON_KEY.includes('YOUR_');

function setMessage(el, message = '', type = '') {
  el.textContent = message;
  el.classList.toggle('hidden', !message);
  el.classList.toggle('error', type === 'error');
}
function toast(message, type = '') {
  clearTimeout(toastTimer);
  ui.toast.textContent = message;
  ui.toast.classList.remove('hidden', 'error');
  if (type === 'error') ui.toast.classList.add('error');
  toastTimer = setTimeout(() => ui.toast.classList.add('hidden'), 4200);
}
function showModal(el) { el.classList.remove('hidden'); }
function hideModal(el) { el.classList.add('hidden'); }
function initials(name) { return (name || 'Traveler').trim().split(/\s+/).slice(0, 2).map(part => part[0] || '').join('').toUpperCase() || 'T'; }
function humanDate(value, withTime = false) {
  if (!value) return 'Just now';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Just now';
  return new Intl.DateTimeFormat(undefined, withTime ? { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' } : { day: 'numeric', month: 'short', year: 'numeric' }).format(date);
}
function fileBytes(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}
function clearSensitiveView() {
  stopCamera();
  if (realtimeChannel && supabase) supabase.removeChannel(realtimeChannel).catch(() => {});
  realtimeChannel = null;
  activeTripId = null; trips = []; members = []; photos = []; profile = null;
  ui.tripList.replaceChildren(); ui.gallery.replaceChildren(); ui.membersList.replaceChildren();
}
function setAuthMode(mode) {
  authMode = mode;
  document.querySelectorAll('.auth-tab').forEach(button => button.classList.toggle('active', button.dataset.mode === mode));
  const signup = mode === 'signup';
  ui.authTitle.textContent = signup ? 'Make your account' : 'Welcome back';
  ui.authSubtitle.textContent = signup ? 'Create an account to join the memories.' : 'Sign in to your trip memories.';
  ui.displayNameWrap.classList.toggle('hidden', !signup);
  ui.displayName.required = signup;
  ui.password.autocomplete = signup ? 'new-password' : 'current-password';
  ui.authSubmit.innerHTML = signup ? 'Create account <span>→</span>' : 'Sign in <span>→</span>';
  setMessage(ui.authMessage, '');
}
function ensureConfiguration() {
  if (!configured) {
    ui.configNotice.classList.remove('hidden');
    ui.authSubmit.disabled = true;
    ui.authSubmit.title = 'Complete Supabase setup first';
    return false;
  }
  ui.configNotice.classList.add('hidden');
  return true;
}

if (configured) {
  supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
  });
} else {
  ensureConfiguration();
}

function toggleMainView(isSignedIn) {
  ui.authView.classList.toggle('hidden', isSignedIn);
  ui.appView.classList.toggle('hidden', !isSignedIn);
  ui.headerUser.classList.toggle('hidden', !isSignedIn);
}

async function handleSession(session) {
  currentSession = session;
  if (!session?.user) {
    if (currentUser) clearSensitiveView();
    currentUser = null;
    toggleMainView(false);
    ui.headerAvatar.textContent = 'S';
    return;
  }
  const isSameUser = currentUser?.id === session.user.id;
  currentUser = session.user;
  toggleMainView(true);
  if (isSameUser) return;
  await loadProfile();
  ui.headerAvatar.textContent = initials(profile?.display_name || currentUser.email);
  await loadTrips();
  await maybeJoinPendingInvite();
}

async function loadProfile() {
  if (!currentUser) return;
  const { data, error } = await supabase.from('profiles').select('id,display_name').eq('id', currentUser.id).maybeSingle();
  if (error) console.warn('Could not load profile', error.message);
  profile = data || { id: currentUser.id, display_name: currentUser.user_metadata?.display_name || currentUser.email?.split('@')[0] || 'Traveler' };
  // Trigger usually creates this row. This fallback only creates the signed-in user's own profile.
  if (!data) {
    const { data: inserted, error: insertError } = await supabase.from('profiles').upsert({ id: currentUser.id, display_name: profile.display_name }, { onConflict: 'id' }).select('id,display_name').maybeSingle();
    if (!insertError && inserted) profile = inserted;
  }
}

async function loadTrips(preferredId = null) {
  if (!currentUser) return;
  const { data, error } = await supabase.from('trips').select('id,name,created_by,invite_token,created_at').order('created_at', { ascending: false });
  if (error) { toast(`Couldn't load trips: ${error.message}`, 'error'); return; }
  trips = data || [];
  renderTripList();
  if (trips.length === 0) {
    activeTripId = null;
    ui.welcomePanel.classList.remove('hidden');
    ui.tripContent.classList.add('hidden');
    if (realtimeChannel) { await supabase.removeChannel(realtimeChannel); realtimeChannel = null; }
    return;
  }
  ui.welcomePanel.classList.add('hidden');
  const nextId = preferredId && trips.some(t => t.id === preferredId) ? preferredId : (activeTripId && trips.some(t => t.id === activeTripId) ? activeTripId : trips[0].id);
  if (nextId !== activeTripId || ui.tripContent.classList.contains('hidden')) await activateTrip(nextId);
  else {
    renderTripList();
    ui.activeTripName.textContent = trips.find(t => t.id === activeTripId)?.name || 'Your Trip';
  }
}

function renderTripList() {
  ui.tripList.replaceChildren();
  if (!trips.length) {
    const empty = document.createElement('div'); empty.className = 'empty-side'; empty.textContent = 'Your next adventure starts here.'; ui.tripList.append(empty); return;
  }
  trips.forEach((trip, index) => {
    const button = document.createElement('button'); button.type = 'button'; button.className = `trip-item${trip.id === activeTripId ? ' active' : ''}`;
    const swatch = document.createElement('span'); swatch.className = 'trip-swatch'; swatch.textContent = ['✦', '⌁', '◈', '✧'][index % 4];
    const name = document.createElement('span'); name.textContent = trip.name; name.title = trip.name;
    button.append(swatch, name); button.addEventListener('click', () => activateTrip(trip.id)); ui.tripList.append(button);
  });
}

async function activateTrip(tripId) {
  if (!tripId || !currentUser) return;
  if (cameraStream) stopCamera();
  if (realtimeChannel) { await supabase.removeChannel(realtimeChannel); realtimeChannel = null; }
  activeTripId = tripId;
  const trip = trips.find(item => item.id === tripId);
  if (!trip) return;
  ui.welcomePanel.classList.add('hidden'); ui.tripContent.classList.remove('hidden');
  ui.activeTripName.textContent = trip.name;
  ui.tripCreated.textContent = `Created ${humanDate(trip.created_at)}`;
  ui.autoUploadConsent.checked = false;
  updateUploadButtons(); renderTripList();
  await loadMembers();
  await loadPhotos();
  listenForTripChanges(tripId);
}

function listenForTripChanges(tripId) {
  if (!supabase || !tripId) return;
  realtimeChannel = supabase.channel(`snaptrip-${tripId}-${currentUser.id}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'photos', filter: `trip_id=eq.${tripId}` }, () => {
      loadPhotos().catch(error => console.warn('Realtime photo refresh failed', error));
    })
    .subscribe(status => {
      if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') console.warn('Realtime channel status:', status);
    });
}

async function loadMembers() {
  if (!activeTripId) return;
  const expectedTrip = activeTripId;
  const { data, error } = await supabase.rpc('get_trip_members', { p_trip_id: expectedTrip });
  if (expectedTrip !== activeTripId) return;
  if (error) { console.warn('Could not load members', error.message); return; }
  members = data || [];
  const trip = trips.find(item => item.id === activeTripId);
  ui.memberCount.textContent = `${members.length} ${members.length === 1 ? 'member' : 'members'}`;
  renderMembers(trip);
}

function renderMembers(trip) {
  ui.membersList.replaceChildren();
  const names = new Map();
  members.forEach(member => names.set(member.user_id, member.display_name || 'Traveler'));
  members.forEach(member => {
    const chip = document.createElement('div'); chip.className = 'member-chip';
    const av = document.createElement('span'); av.className = 'avatar'; av.textContent = initials(member.display_name);
    const label = document.createElement('span'); label.textContent = member.display_name || 'Traveler';
    chip.append(av, label);
    if (trip && member.user_id === trip.created_by) { const owner = document.createElement('span'); owner.className = 'owner-pill'; owner.textContent = 'OWNER'; chip.append(owner); }
    ui.membersList.append(chip);
  });
}

async function loadPhotos() {
  if (!activeTripId || refreshingGallery) return;
  refreshingGallery = true;
  const expectedTrip = activeTripId;
  try {
    const { data, error } = await supabase.from('photos').select('id,trip_id,uploader_id,storage_path,original_name,mime_type,size_bytes,created_at').eq('trip_id', expectedTrip).order('created_at', { ascending: false });
    if (expectedTrip !== activeTripId) return;
    if (error) { toast(`Couldn't load photos: ${error.message}`, 'error'); return; }
    photos = data || [];
    const memberNames = new Map(members.map(member => [member.user_id, member.display_name || 'Traveler']));
    const resolved = await Promise.all(photos.map(async photo => {
      const { data: signed, error: signError } = await supabase.storage.from('snaptrip').createSignedUrl(photo.storage_path, 60 * 60);
      return { ...photo, signedUrl: signError ? null : signed?.signedUrl || null, uploaderName: memberNames.get(photo.uploader_id) || 'Trip member' };
    }));
    if (expectedTrip !== activeTripId) return;
    renderPhotos(resolved);
    ui.photoCount.textContent = `${photos.length} ${photos.length === 1 ? 'photo' : 'photos'}`;
    ui.galleryNumber.textContent = String(photos.length);
  } finally {
    refreshingGallery = false;
  }
}

function renderPhotos(resolvedPhotos) {
  ui.gallery.replaceChildren();
  if (!resolvedPhotos.length) {
    const empty = document.createElement('div'); empty.className = 'gallery-empty panel';
    const icon = document.createElement('div'); icon.className = 'empty-icon'; icon.textContent = '✧';
    const title = document.createElement('h3'); title.textContent = 'Your story starts with one photo';
    const p = document.createElement('p'); p.textContent = 'Be the first to add a moment to this trip.';
    empty.append(icon, title, p); ui.gallery.append(empty); return;
  }
  resolvedPhotos.forEach(photo => {
    const tile = document.createElement('button'); tile.type = 'button'; tile.className = 'photo-tile'; tile.setAttribute('aria-label', `View photo uploaded by ${photo.uploaderName}`);
    const wrap = document.createElement('div'); wrap.className = 'photo-thumb-wrap';
    if (photo.signedUrl) {
      const img = document.createElement('img'); img.className = 'photo-thumb'; img.src = photo.signedUrl; img.alt = `Photo uploaded by ${photo.uploaderName}`; img.loading = 'lazy'; wrap.append(img);
    } else {
      const placeholder = document.createElement('div'); placeholder.className = 'gallery-empty'; placeholder.style.minHeight = '100%'; placeholder.textContent = 'Preview unavailable'; wrap.append(placeholder);
    }
    const info = document.createElement('div'); info.className = 'photo-tile-info';
    const uploader = document.createElement('div'); uploader.className = 'photo-uploader'; uploader.textContent = photo.uploaderName;
    const time = document.createElement('div'); time.className = 'photo-time'; time.textContent = humanDate(photo.created_at, true);
    info.append(uploader, time); tile.append(wrap, info);
    tile.addEventListener('click', () => openPhoto(photo)); ui.gallery.append(tile);
  });
}

function renderUploadTask(fileName, totalBytes) {
  ui.uploadQueue.classList.remove('hidden');
  const task = document.createElement('div'); task.className = 'upload-task';
  const icon = document.createElement('div'); icon.className = 'upload-file-icon'; icon.textContent = '↑';
  const content = document.createElement('div'); content.style.minWidth = '0';
  const name = document.createElement('div'); name.className = 'upload-task-name'; name.textContent = fileName;
  const status = document.createElement('div'); status.className = 'upload-task-status'; status.textContent = `Preparing · ${fileBytes(totalBytes)}`;
  const track = document.createElement('div'); track.className = 'progress-track'; const fill = document.createElement('span'); track.append(fill);
  content.append(name, status, track);
  const percent = document.createElement('div'); percent.className = 'upload-task-percent'; percent.textContent = '0%';
  task.append(icon, content, percent); ui.uploadQueue.prepend(task);
  while (ui.uploadQueue.children.length > 5) ui.uploadQueue.lastElementChild.remove();
  return {
    progress(value) { const safe = Math.max(0, Math.min(100, Math.round(value))); fill.style.width = `${safe}%`; percent.textContent = `${safe}%`; status.textContent = safe === 100 ? 'Saving photo details…' : `Uploading · ${fileBytes(totalBytes)}`; },
    done() { fill.style.width = '100%'; percent.textContent = '✓'; status.textContent = 'Uploaded to the trip'; icon.textContent = '✓'; },
    fail(message) { percent.textContent = '!'; status.textContent = message || 'Upload failed'; task.style.borderColor = '#f3d6d2'; icon.textContent = '!'; icon.style.color = '#ae3e39'; }
  };
}

async function uploadFile(file) {
  if (!currentUser || !activeTripId) { toast('Sign in and open a trip before uploading.', 'error'); return false; }
  if (!ui.autoUploadConsent.checked) { toast('Tick the upload consent box first.', 'error'); return false; }
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
  if (!allowedTypes.includes(file.type)) { toast(`${file.name}: choose a JPG, PNG, or WEBP image.`, 'error'); return false; }
  if (file.size > 12 * 1024 * 1024) { toast(`${file.name}: maximum size is 12 MB.`, 'error'); return false; }
  if (!file.size) { toast(`${file.name}: the selected file is empty.`, 'error'); return false; }
  const tripId = activeTripId;
  const task = renderUploadTask(file.name || 'Trip photo', file.size);
  let uploadedPath = null;
  try {
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
    if (sessionError || !sessionData?.session) throw new Error('Your session expired. Sign in again.');
    currentSession = sessionData.session;
    const photoId = crypto.randomUUID();
    const ext = file.type === 'image/png' ? 'png' : file.type === 'image/webp' ? 'webp' : 'jpg';
    uploadedPath = `${tripId}/${currentUser.id}/${photoId}.${ext}`;
    const uploaded = await uploadWithProgress(uploadedPath, file, currentSession.access_token, task.progress);
    if (!uploaded) throw new Error('Cloud upload did not finish.');
    task.progress(100);
    const { error: rowError } = await supabase.from('photos').insert({
      id: photoId, trip_id: tripId, uploader_id: currentUser.id, storage_path: uploadedPath,
      original_name: (file.name || `snaptrip-${photoId}.${ext}`).slice(0, 250), mime_type: file.type, size_bytes: file.size
    });
    if (rowError) {
      await supabase.storage.from('snaptrip').remove([uploadedPath]).catch(() => {});
      uploadedPath = null;
      throw new Error(`Photo uploaded but couldn't save its album record: ${rowError.message}`);
    }
    task.done();
    if (tripId === activeTripId) await loadPhotos();
    toast('Photo uploaded to your shared trip album.');
    return true;
  } catch (error) {
    task.fail(error?.message || 'Upload failed. Check your connection and try again.');
    toast(error?.message || 'Upload failed.', 'error');
    return false;
  }
}

function uploadWithProgress(path, file, accessToken, onProgress) {
  return new Promise((resolve, reject) => {
    const encodedPath = path.split('/').map(segment => encodeURIComponent(segment)).join('/');
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${SUPABASE_URL.replace(/\/$/, '')}/storage/v1/object/snaptrip/${encodedPath}`);
    xhr.setRequestHeader('apikey', SUPABASE_ANON_KEY);
    xhr.setRequestHeader('Authorization', `Bearer ${accessToken}`);
    xhr.setRequestHeader('Content-Type', file.type);
    xhr.setRequestHeader('x-upsert', 'false');
    xhr.upload.onprogress = event => { if (event.lengthComputable && typeof onProgress === 'function') onProgress(event.loaded / event.total * 94); };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve(true);
      else {
        let reason = `Cloud storage returned ${xhr.status}.`;
        try { const parsed = JSON.parse(xhr.responseText); reason = parsed.message || parsed.error || parsed.error_description || reason; } catch (_) {}
        reject(new Error(reason));
      }
    };
    xhr.onerror = () => reject(new Error('Network error while uploading. Check internet and retry.'));
    xhr.onabort = () => reject(new Error('Upload cancelled.'));
    xhr.send(file);
  });
}

function updateUploadButtons() {
  const canUpload = Boolean(currentUser && activeTripId && ui.autoUploadConsent.checked);
  ui.openCameraBtn.disabled = !canUpload;
  ui.choosePhotosBtn.disabled = !canUpload;
}

async function startCamera() {
  if (!ui.autoUploadConsent.checked) { toast('Please confirm the upload notice first.', 'error'); return; }
  if (!activeTripId) { toast('Open a trip first.', 'error'); return; }
  if (!navigator.mediaDevices?.getUserMedia) { toast('This browser does not support in-page camera access. Open SnapTrip over HTTPS in a current browser.', 'error'); return; }
  setMessage(ui.cameraMessage, 'Requesting camera permission…');
  showModal(ui.cameraModal);
  ui.cameraTripName.textContent = trips.find(t => t.id === activeTripId)?.name || 'this trip';
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: cameraFacing }, width: { ideal: 1920 }, height: { ideal: 1440 } }, audio: false });
    ui.cameraVideo.srcObject = cameraStream;
    ui.cameraVideo.classList.remove('hidden');
    ui.cameraPlaceholder.classList.add('hidden');
    await ui.cameraVideo.play();
    ui.capturePhotoBtn.disabled = false;
    setMessage(ui.cameraMessage, 'Camera ready. Capture a photo to upload it to the shared album.');
  } catch (error) {
    stopCamera();
    ui.cameraVideo.classList.add('hidden'); ui.cameraPlaceholder.classList.remove('hidden');
    setMessage(ui.cameraMessage, error?.name === 'NotAllowedError' ? 'Camera permission was denied. Allow camera access in your browser settings and try again.' : `Couldn't start the camera: ${error?.message || 'unknown error'}. Make sure this site is opened over HTTPS.`, 'error');
  }
}

function stopCamera() {
  if (cameraStream) cameraStream.getTracks().forEach(track => track.stop());
  cameraStream = null;
  ui.cameraVideo.pause(); ui.cameraVideo.srcObject = null;
  ui.capturePhotoBtn.disabled = true;
}

async function capturePhoto() {
  if (!cameraStream || !ui.cameraVideo.videoWidth) { setMessage(ui.cameraMessage, 'Camera is not ready yet.', 'error'); return; }
  ui.capturePhotoBtn.disabled = true;
  setMessage(ui.cameraMessage, 'Capturing photo…');
  try {
    const video = ui.cameraVideo;
    const canvas = document.createElement('canvas');
    const maxDimension = 2400;
    const scale = Math.min(1, maxDimension / Math.max(video.videoWidth, video.videoHeight));
    canvas.width = Math.round(video.videoWidth * scale); canvas.height = Math.round(video.videoHeight * scale);
    canvas.getContext('2d', { alpha: false }).drawImage(video, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve, reject) => canvas.toBlob(result => result ? resolve(result) : reject(new Error('Could not capture this photo.')), 'image/jpeg', 0.9));
    const file = new File([blob], `snaptrip-${new Date().toISOString().replace(/[:.]/g, '-')}.jpg`, { type: 'image/jpeg', lastModified: Date.now() });
    stopCamera(); hideModal(ui.cameraModal);
    await uploadFile(file);
  } catch (error) {
    ui.capturePhotoBtn.disabled = false;
    setMessage(ui.cameraMessage, error?.message || 'Could not capture photo.', 'error');
  }
}

function openPhoto(photo) {
  currentViewerPhoto = photo;
  ui.viewerImage.src = photo.signedUrl || '';
  ui.viewerImage.alt = `Photo uploaded by ${photo.uploaderName || 'a trip member'}`;
  ui.viewerUploader.textContent = photo.uploaderName || 'Trip member';
  ui.viewerDate.textContent = humanDate(photo.created_at, true);
  ui.deletePhotoBtn.classList.toggle('hidden', photo.uploader_id !== currentUser?.id);
  showModal(ui.photoModal);
}

async function deleteCurrentPhoto() {
  const photo = currentViewerPhoto;
  if (!photo || photo.uploader_id !== currentUser?.id) return;
  if (!window.confirm('Delete this photo from the shared trip album? This cannot be undone.')) return;
  ui.deletePhotoBtn.disabled = true;
  try {
    const { error: storageError } = await supabase.storage.from('snaptrip').remove([photo.storage_path]);
    if (storageError) throw storageError;
    const { error: rowError } = await supabase.from('photos').delete().eq('id', photo.id);
    if (rowError) throw rowError;
    hideModal(ui.photoModal); currentViewerPhoto = null;
    await loadPhotos(); toast('Photo deleted from the trip.');
  } catch (error) { toast(`Could not delete photo: ${error.message}`, 'error'); }
  finally { ui.deletePhotoBtn.disabled = false; }
}

async function createTrip(event) {
  event.preventDefault();
  const name = ui.tripNameInput.value.trim();
  if (!name) { setMessage(ui.tripFormMessage, 'Enter a trip name.', 'error'); return; }
  ui.tripSubmit.disabled = true; setMessage(ui.tripFormMessage, 'Creating your private trip…');
  try {
    const { data, error } = await supabase.rpc('create_trip', { p_name: name });
    if (error) throw error;
    const id = typeof data === 'string' ? data : data?.id;
    await loadTrips(id);
    hideModal(ui.tripModal); ui.tripForm.reset(); setMessage(ui.tripFormMessage, '');
    if (id) { showInvite(); toast('Trip created. Invite your friends to join.'); }
  } catch (error) { setMessage(ui.tripFormMessage, error?.message || 'Could not create trip.', 'error'); }
  finally { ui.tripSubmit.disabled = false; }
}

function extractInviteToken(value) {
  const input = (value || '').trim();
  if (!input) return '';
  try {
    const url = new URL(input);
    return url.searchParams.get('invite') || url.searchParams.get('token') || '';
  } catch (_) {
    return input.replace(/^invite\s*[:=]\s*/i, '').trim();
  }
}

async function joinTripFromInput(event) {
  event.preventDefault();
  const token = extractInviteToken(ui.inviteInput.value);
  await joinByToken(token, ui.joinMessage);
}

async function joinByToken(token, messageEl = null) {
  if (!currentUser) {
    if (messageEl) setMessage(messageEl, 'Sign in first, then join the trip.', 'error');
    else toast('Sign in first to join a trip.', 'error');
    return;
  }
  if (!token || token.length > 180) {
    const msg = 'That invite link or code does not look valid.';
    if (messageEl) setMessage(messageEl, msg, 'error'); else toast(msg, 'error');
    return;
  }
  if (messageEl) setMessage(messageEl, 'Joining the shared trip…');
  if (ui.joinSubmit) ui.joinSubmit.disabled = true;
  try {
    const { data, error } = await supabase.rpc('join_trip', { p_invite_token: token });
    if (error) throw error;
    const joinedId = typeof data === 'string' ? data : data?.id;
    await loadTrips(joinedId);
    if (messageEl) setMessage(messageEl, '');
    hideModal(ui.joinModal); ui.joinForm.reset();
    toast('You joined the trip. The shared album is ready.');
  } catch (error) {
    if (messageEl) setMessage(messageEl, error?.message || 'Could not join the trip.', 'error');
    else toast(error?.message || 'Could not join the trip.', 'error');
  } finally { if (ui.joinSubmit) ui.joinSubmit.disabled = false; }
}

async function maybeJoinPendingInvite() {
  if (pendingInviteHandled || !currentUser) return;
  const params = new URLSearchParams(window.location.search);
  const token = params.get('invite');
  if (!token) return;
  pendingInviteHandled = true;
  await joinByToken(token);
  params.delete('invite');
  const cleanUrl = `${window.location.pathname}${params.toString() ? `?${params}` : ''}${window.location.hash}`;
  window.history.replaceState({}, document.title, cleanUrl);
}

async function showInvite() {
  const trip = trips.find(t => t.id === activeTripId);
  if (!trip) { toast('Open a trip to invite friends.', 'error'); return; }
  const inviteUrl = new URL(window.location.pathname, window.location.origin);
  inviteUrl.searchParams.set('invite', trip.invite_token);
  ui.inviteLinkInput.value = inviteUrl.toString();
  ui.inviteCodeText.textContent = trip.invite_token;
  setMessage(ui.inviteMessage, '');
  showModal(ui.inviteModal);
  if (window.QRCode?.toCanvas) {
    try { await window.QRCode.toCanvas(ui.inviteQr, inviteUrl.toString(), { width: 210, margin: 1, errorCorrectionLevel: 'M', color: { dark: '#082b2a', light: '#ffffff' } }); }
    catch (error) { console.warn('QR code generation failed', error); }
  } else {
    const ctx = ui.inviteQr.getContext('2d'); ctx.clearRect(0, 0, ui.inviteQr.width, ui.inviteQr.height);
    ctx.fillStyle = '#f0f5f2'; ctx.fillRect(0, 0, ui.inviteQr.width, ui.inviteQr.height);
    ctx.fillStyle = '#52645d'; ctx.font = '12px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('QR library unavailable', 105, 104); ctx.fillText('Use the invite link below', 105, 124);
  }
}

async function copyText(value, feedbackEl = null) {
  try {
    await navigator.clipboard.writeText(value);
  } catch (_) {
    const helper = document.createElement('textarea'); helper.value = value; helper.setAttribute('readonly', ''); helper.style.position = 'fixed'; helper.style.opacity = '0'; document.body.append(helper); helper.select();
    const copied = document.execCommand('copy'); helper.remove();
    if (!copied) { if (feedbackEl) setMessage(feedbackEl, 'Copy was blocked by this browser. Select the text and copy it manually.', 'error'); else toast('Copy was blocked. Select the text and copy it manually.', 'error'); return; }
  }
  if (feedbackEl) setMessage(feedbackEl, 'Copied to clipboard.'); else toast('Copied to clipboard.');
}

async function signOut() {
  stopCamera();
  const { error } = await supabase.auth.signOut();
  if (error) toast(`Could not sign out: ${error.message}`, 'error');
  else toast('Signed out.');
}

ui.authForm.addEventListener('submit', async event => {
  event.preventDefault();
  if (!supabase) return;
  const email = ui.email.value.trim(); const password = ui.password.value;
  setMessage(ui.authMessage, authMode === 'signup' ? 'Creating your account…' : 'Signing you in…');
  ui.authSubmit.disabled = true;
  try {
    if (authMode === 'signup') {
      const displayName = ui.displayName.value.trim();
      if (!displayName) throw new Error('Please enter your name.');
      const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: displayName } } });
      if (error) throw error;
      if (!data.session) setMessage(ui.authMessage, 'Account created. Check your email to confirm your account, then sign in.');
      else setMessage(ui.authMessage, 'Account created. Opening your trips…');
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      setMessage(ui.authMessage, 'Signed in. Loading your trips…');
    }
  } catch (error) { setMessage(ui.authMessage, error?.message || 'Authentication failed.', 'error'); }
  finally { ui.authSubmit.disabled = false; }
});

document.querySelectorAll('.auth-tab').forEach(button => button.addEventListener('click', () => setAuthMode(button.dataset.mode)));
$('signOutBtn').addEventListener('click', signOut);
$('newTripBtn').addEventListener('click', () => { $('tripModalTitle').textContent = 'Create your trip'; $('tripModalDesc').textContent = 'Give your trip a name your friends will recognize.'; ui.tripForm.reset(); setMessage(ui.tripFormMessage, ''); showModal(ui.tripModal); setTimeout(() => ui.tripNameInput.focus(), 50); });
$('welcomeCreateBtn').addEventListener('click', () => $('newTripBtn').click());
$('tripForm').addEventListener('submit', createTrip);
$('joinTripOpenBtn').addEventListener('click', () => { setMessage(ui.joinMessage, ''); showModal(ui.joinModal); });
$('welcomeJoinBtn').addEventListener('click', () => $('joinTripOpenBtn').click());
$('joinForm').addEventListener('submit', joinTripFromInput);
$('inviteBtn').addEventListener('click', showInvite);
$('inviteSmallBtn').addEventListener('click', showInvite);
$('copyInviteBtn').addEventListener('click', () => copyText(ui.inviteLinkInput.value, ui.inviteMessage));
$('copyCodeBtn').addEventListener('click', () => copyText(ui.inviteCodeText.textContent, ui.inviteMessage));
ui.autoUploadConsent.addEventListener('change', updateUploadButtons);
ui.openCameraBtn.addEventListener('click', startCamera);
ui.choosePhotosBtn.addEventListener('click', () => { if (ui.autoUploadConsent.checked) ui.photoPicker.click(); });
ui.photoPicker.addEventListener('change', async event => {
  const selectedFiles = Array.from(event.target.files || []); event.target.value = '';
  for (const file of selectedFiles) await uploadFile(file);
});
ui.capturePhotoBtn.addEventListener('click', capturePhoto);
$('switchCameraBtn').addEventListener('click', async () => {
  cameraFacing = cameraFacing === 'environment' ? 'user' : 'environment';
  stopCamera(); await startCamera();
});
ui.deletePhotoBtn.addEventListener('click', deleteCurrentPhoto);
$('refreshGalleryBtn').addEventListener('click', async () => { await loadMembers(); await loadPhotos(); toast('Gallery refreshed.'); });
$('privacyLink').addEventListener('click', event => { event.preventDefault(); showModal(ui.privacyModal); });

document.querySelectorAll('[data-close]').forEach(el => el.addEventListener('click', () => {
  const modal = $(el.dataset.close); if (!modal) return;
  if (modal === ui.cameraModal) stopCamera();
  if (modal === ui.photoModal) { ui.viewerImage.src = ''; currentViewerPhoto = null; }
  hideModal(modal);
}));
document.addEventListener('keydown', event => { if (event.key === 'Escape') document.querySelectorAll('.modal:not(.hidden)').forEach(modal => { if (modal === ui.cameraModal) stopCamera(); if (modal === ui.photoModal) ui.viewerImage.src = ''; hideModal(modal); }); });

$('year').textContent = String(new Date().getFullYear());
setAuthMode('signin');
ensureConfiguration();
if (supabase) {
  supabase.auth.onAuthStateChange((_event, session) => { setTimeout(() => { handleSession(session).catch(error => { console.error(error); toast('Could not load your account. Refresh and try again.', 'error'); }); }, 0); });
  supabase.auth.getSession().then(({ data, error }) => {
    if (error) { console.error(error); return; }
    handleSession(data.session).catch(error => { console.error(error); toast('Could not load your account. Refresh and try again.', 'error'); });
  });
}
