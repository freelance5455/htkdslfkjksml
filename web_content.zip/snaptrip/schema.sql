-- SNAPTRIP database setup for Supabase.
-- Paste this entire file into Supabase Dashboard -> SQL Editor -> New query and run it.
-- Run as the project owner. This script is designed to be re-runnable.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Traveler' check (char_length(display_name) between 1 and 50),
  created_at timestamptz not null default now()
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 80),
  created_by uuid not null references auth.users(id) on delete cascade,
  invite_token uuid not null unique default gen_random_uuid(),
  created_at timestamptz not null default now()
);

create table if not exists public.trip_members (
  trip_id uuid not null references public.trips(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (trip_id, user_id)
);

create table if not exists public.photos (
  id uuid primary key default gen_random_uuid(),
  trip_id uuid not null references public.trips(id) on delete cascade,
  uploader_id uuid not null references auth.users(id) on delete cascade,
  storage_path text not null unique,
  original_name text not null check (char_length(original_name) between 1 and 250),
  mime_type text not null check (mime_type in ('image/jpeg', 'image/png', 'image/webp')),
  size_bytes bigint not null check (size_bytes between 1 and 12582912),
  created_at timestamptz not null default now()
);

create index if not exists trips_created_by_idx on public.trips(created_by);
create index if not exists trip_members_user_id_idx on public.trip_members(user_id);
create index if not exists photos_trip_created_idx on public.photos(trip_id, created_at desc);
create index if not exists photos_uploader_idx on public.photos(uploader_id);

alter table public.profiles enable row level security;
alter table public.trips enable row level security;
alter table public.trip_members enable row level security;
alter table public.photos enable row level security;

-- Profiles are private by default. Trip member names are returned through a checked RPC below.
drop policy if exists "profiles_select_self" on public.profiles;
create policy "profiles_select_self" on public.profiles
  for select to authenticated using (id = auth.uid());

drop policy if exists "profiles_insert_self" on public.profiles;
create policy "profiles_insert_self" on public.profiles
  for insert to authenticated with check (id = auth.uid());

drop policy if exists "profiles_update_self" on public.profiles;
create policy "profiles_update_self" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- A user can see only trips where they are a member. The membership subquery is limited
-- by trip_members' own-row policy, so it does not create a recursive policy.
drop policy if exists "trips_select_member" on public.trips;
create policy "trips_select_member" on public.trips
  for select to authenticated using (
    exists (
      select 1 from public.trip_members tm
      where tm.trip_id = trips.id and tm.user_id = auth.uid()
    )
  );

drop policy if exists "trips_delete_owner" on public.trips;
create policy "trips_delete_owner" on public.trips
  for delete to authenticated using (created_by = auth.uid());

-- Members can see their own membership row. Other members are listed only through get_trip_members().
drop policy if exists "trip_members_select_self" on public.trip_members;
create policy "trip_members_select_self" on public.trip_members
  for select to authenticated using (user_id = auth.uid());

-- Every album record is visible only to a current member of that trip.
drop policy if exists "photos_select_trip_member" on public.photos;
create policy "photos_select_trip_member" on public.photos
  for select to authenticated using (
    exists (
      select 1 from public.trip_members tm
      where tm.trip_id = photos.trip_id and tm.user_id = auth.uid()
    )
  );

drop policy if exists "photos_insert_own_trip_member" on public.photos;
create policy "photos_insert_own_trip_member" on public.photos
  for insert to authenticated with check (
    uploader_id = auth.uid()
    and exists (
      select 1 from public.trip_members tm
      where tm.trip_id = photos.trip_id and tm.user_id = auth.uid()
    )
  );

drop policy if exists "photos_delete_uploader" on public.photos;
create policy "photos_delete_uploader" on public.photos
  for delete to authenticated using (
    uploader_id = auth.uid()
    and exists (
      select 1 from public.trip_members tm
      where tm.trip_id = photos.trip_id and tm.user_id = auth.uid()
    )
  );

-- Create the user's profile after signup. display_name is supplied from signup metadata.
create or replace function public.handle_new_snaptrip_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    left(coalesce(nullif(trim(new.raw_user_meta_data ->> 'display_name'), ''), nullif(split_part(coalesce(new.email, 'traveler'), '@', 1), ''), 'Traveler'), 50)
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_snaptrip on auth.users;
create trigger on_auth_user_created_snaptrip
after insert on auth.users
for each row execute procedure public.handle_new_snaptrip_user();

-- Create a trip and make its creator the first member in one transaction.
create or replace function public.create_trip(p_name text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_trip_id uuid;
  v_name text;
begin
  if auth.uid() is null then
    raise exception 'You must be signed in to create a trip.' using errcode = '28000';
  end if;
  v_name := trim(coalesce(p_name, ''));
  if char_length(v_name) < 1 or char_length(v_name) > 80 then
    raise exception 'Trip name must be between 1 and 80 characters.' using errcode = '22023';
  end if;
  insert into public.trips (name, created_by) values (v_name, auth.uid()) returning id into v_trip_id;
  insert into public.trip_members (trip_id, user_id) values (v_trip_id, auth.uid());
  return v_trip_id;
end;
$$;

-- Join by unguessable UUID invite token. Only the invited user is added; no trip data is returned here.
create or replace function public.join_trip(p_invite_token uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_trip_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Sign in before joining a trip.' using errcode = '28000';
  end if;
  select t.id into v_trip_id
  from public.trips t
  where t.invite_token = p_invite_token;
  if v_trip_id is null then
    raise exception 'Invite link or code is invalid.' using errcode = '22023';
  end if;
  insert into public.trip_members (trip_id, user_id)
  values (v_trip_id, auth.uid())
  on conflict (trip_id, user_id) do nothing;
  return v_trip_id;
end;
$$;

-- Reveal member names only to someone who already belongs to this trip.
create or replace function public.get_trip_members(p_trip_id uuid)
returns table (user_id uuid, display_name text, joined_at timestamptz, is_owner boolean)
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null or not exists (
    select 1 from public.trip_members tm
    where tm.trip_id = p_trip_id and tm.user_id = auth.uid()
  ) then
    raise exception 'You are not a member of this trip.' using errcode = '42501';
  end if;
  return query
    select tm.user_id, coalesce(p.display_name, 'Traveler')::text, tm.created_at, (t.created_by = tm.user_id)
    from public.trip_members tm
    join public.trips t on t.id = tm.trip_id
    left join public.profiles p on p.id = tm.user_id
    where tm.trip_id = p_trip_id
    order by (t.created_by = tm.user_id) desc, tm.created_at asc;
end;
$$;

revoke all on function public.create_trip(text) from public;
revoke all on function public.join_trip(uuid) from public;
revoke all on function public.get_trip_members(uuid) from public;
grant execute on function public.create_trip(text) to authenticated;
grant execute on function public.join_trip(uuid) to authenticated;
grant execute on function public.get_trip_members(uuid) to authenticated;

-- Private photo bucket. Each object path is trip_uuid/user_uuid/photo_uuid.ext.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('snaptrip', 'snaptrip', false, 12582912, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do update set
  name = excluded.name,
  public = false,
  file_size_limit = 12582912,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "snaptrip_members_read_trip_photos" on storage.objects;
create policy "snaptrip_members_read_trip_photos" on storage.objects
  for select to authenticated using (
    bucket_id = 'snaptrip'
    and (storage.foldername(name))[1] in (
      select tm.trip_id::text from public.trip_members tm where tm.user_id = auth.uid()
    )
  );

drop policy if exists "snaptrip_members_upload_own_folder" on storage.objects;
create policy "snaptrip_members_upload_own_folder" on storage.objects
  for insert to authenticated with check (
    bucket_id = 'snaptrip'
    and (storage.foldername(name))[1] in (
      select tm.trip_id::text from public.trip_members tm where tm.user_id = auth.uid()
    )
    and (storage.foldername(name))[2] = auth.uid()::text
  );

drop policy if exists "snaptrip_uploaders_delete_own_photos" on storage.objects;
create policy "snaptrip_uploaders_delete_own_photos" on storage.objects
  for delete to authenticated using (
    bucket_id = 'snaptrip'
    and (storage.foldername(name))[1] in (
      select tm.trip_id::text from public.trip_members tm where tm.user_id = auth.uid()
    )
    and (storage.foldername(name))[2] = auth.uid()::text
  );

-- Realtime gallery refresh. Supabase projects normally have this publication already.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (
       select 1 from pg_publication_tables
       where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'photos'
     ) then
    alter publication supabase_realtime add table public.photos;
  end if;
end;
$$;

-- Helpful grants (RLS still determines which individual rows can be accessed).
grant select on public.profiles, public.trips, public.trip_members, public.photos to authenticated;
grant insert, update on public.profiles to authenticated;
grant insert, delete on public.photos to authenticated;
