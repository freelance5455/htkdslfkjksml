# SNAPTRIP — shared trip photo app

Mobile-first web app for private, multi-user trip albums. A user creates a room, shares an invite link or QR code, and each signed-in member can capture a photo inside the app or choose images. After the upload-consent checkbox is checked, capture/selection triggers an upload to a private Supabase Storage bucket. Other trip members see newly saved photos through Supabase Realtime.

## What is included

- `index.html` — app markup and mobile-first UI.
- `styles.css` — responsive visual design.
- `app.js` — Supabase Auth, trips, invite links/QR, in-app camera capture, progress-tracked image uploads, private signed photo URLs, album refresh/realtime, and deletion of your own photos.
- `config.js` — browser-safe Supabase project URL + anon/publishable key placeholders.
- `schema.sql` — database tables, RLS policies, signup profile trigger, trip RPC functions, private bucket, Storage policies, and Realtime publication setup.

## Required one-time setup

1. Create a project at [Supabase](https://supabase.com/). This is required for accounts, cloud photo storage, and cross-device sync. The app will not sync with no backend.
2. Open **SQL Editor** in the Supabase dashboard, create a new query, paste the whole `schema.sql`, and run it. The query creates the required tables, functions, security policies, private storage bucket, and Realtime entry.
3. Find your **Project URL** and **anon/publishable key** in the Supabase project API settings. Put them in `config.js`:
   - `SUPABASE_URL = "https://YOUR_PROJECT_REF.supabase.co"`
   - `SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY"`
   Use only the anon/publishable key. **Never paste a `service_role` or secret key into front-end code.** The anon key is intended to be public; the Row Level Security policies are the protection.
4. In Supabase Auth settings, configure the site's allowed redirect URLs for the host you will use. For easy testing, add your local development URL and the final HTTPS URL. Email confirmation can remain enabled; new users will need to confirm their email before signing in if that is how the project is configured.
5. Host this folder over HTTPS. Suitable choices include a static hosting service or your own HTTPS server. Camera APIs do not generally work when opening `index.html` directly as a `file://` URL. For local development, a local HTTP development server is typically treated as a secure context; on a phone, use an HTTPS host.
6. Open the deployed URL, create an account, create a trip, and share the invite link/QR with friends. Each friend must create an account/sign in and open the link. The link is a bearer invite: anyone possessing it can join, so share privately.

## Camera and upload behavior

- SnapTrip does **not** monitor the regular camera roll or upload in the background.
- The user must sign in, open a trip, check the upload-consent box, tap **Open camera**, grant camera permission, and then tap **Capture & upload**. Captures are uploaded immediately after the shutter is pressed.
- The **Choose photos** button uploads only files explicitly selected by the user, also after consent.
- Uploads require an internet connection. The progress bar tracks the actual browser upload request. If upload metadata fails after the object was uploaded, the app attempts to remove that orphan object.
- Only JPEG, PNG, and WEBP images are accepted, with a 12 MB per-photo limit. Photos are stored in a **private** bucket and served to authorized members using signed URLs.

## Security notes and limitations

- Row Level Security limits trip records, photo metadata, and storage object access to trip members. The trip member listing is exposed through a `security definer` RPC that checks membership before returning names.
- Invite tokens are UUIDs. The included UI does not yet provide invite-token rotation/revocation or a remove-member function. If a link leaks, treat it as compromised; revoke/rotation is a sensible next feature before using this for sensitive albums.
- Current implementation allows each uploader to delete their own photo; trip owners do not automatically get power to delete other people's images.
- This is a functional starter, not a formal security audit. Before public production use, add automated tests, abuse/rate limits, monitoring, backups, privacy/legal disclosures, a user account deletion flow, and invite revocation/expiration.
- The app uses Supabase's public browser SDK via CDN and a QR code library via CDN, so loading the UI requires internet. The live photo data/storage and cross-device sync use Supabase.
- No production backend credentials are included. Every tester should use their own project or a project you control. Never commit secret/service-role keys.

## Quick checks after setup

1. Create account A, sign in, create a trip.
2. Copy the invite link and open it in a private browser window or on a second phone.
3. Create/sign in to account B; the invite should add account B to that trip.
4. On both devices open the trip; capture and upload a photo on device A. It should appear on device B after the realtime event (or after tapping refresh).
5. Try opening the raw private Storage object URL in a signed-out browser; it should not be publicly readable.
6. Try to access another trip with an unrelated account; the RLS policies should prevent it.

## Local testing tip

Use a local static server rather than opening the HTML file directly. For example, in a development environment with Node installed, install/run any lightweight static server, then open its local address. When testing camera capture from a different physical phone, deploy to an HTTPS URL.
