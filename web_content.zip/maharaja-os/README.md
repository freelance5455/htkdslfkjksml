# MAHARAJA OS — local-first business command center

**Version:** 0.1.0 · **Status:** foundational MVP, not the complete product brief.

A local-first application scaffold with a React/TypeScript interface, Express API, SQLite persistence, validated project/task/finance/website records, dashboard aggregates, audit events, and real HTTP website checks. It deliberately labels unavailable modules as not implemented rather than inventing business results.

## Requirements
- Node.js 22 or newer
- npm 10 or newer

## Install and run
From this directory:

```bash
cp .env.example .env
npm install
npm run dev
```

Open `http://127.0.0.1:5173`. API health check: `http://127.0.0.1:4310/api/v1/health`.

For a production frontend build and backend compile:

```bash
npm run build
npm test
```

Run API alone: `npm run dev:server`. Run frontend alone: `npm run dev:client`.

## Local data and backup
SQLite data defaults to `server/data/maharaja.sqlite` (created on first API start). The API binds to `127.0.0.1` by default. The `/api/v1/backup` route downloads a SQLite database file; for a consistent backup while the app is running, use SQLite's online backup API or stop the API first and copy the database plus any `-wal`/`-shm` files. Restore only while the API is stopped, keep a copy of the current database, then restart and verify `/api/v1/health` and record counts.

Set `HOST`, `PORT`, and `DATABASE_PATH` in `.env` if needed. Do not bind to a LAN/public interface without adding authentication, authorization, TLS, and deployment hardening first.

## Implemented API routes
- `GET /api/v1/health`
- `GET /api/v1/dashboard`
- `GET, POST, PATCH /api/v1/projects`
- `GET, POST /api/v1/tasks`; `PATCH /api/v1/tasks/:id/status`
- `GET, POST /api/v1/transactions`; `POST /api/v1/transactions/:id/reverse`
- `GET, POST /api/v1/websites`; `POST /api/v1/websites/:id/check`; `GET /api/v1/websites/:id/checks`
- `GET /api/v1/audit`
- `GET /api/v1/backup`

Amounts are stored as integer minor units (paise for INR). Posted transaction totals exclude voided records. Transaction submission accepts `Idempotency-Key`; reusing a key returns conflict rather than double-posting. Reversal voids the original and creates an opposite-kind correction record inside a database transaction.

## Current limits / security notes
This is a local development MVP, not safe for public or multi-user production use yet. Authentication and server-enforced RBAC are **not implemented**; the UI currently represents a single local operator. File uploads, migrations framework, complete backup verification/restore UI, approval flows, dependency graph, full workflow engine, AI integration, CRM, inventory, marketing, HR, PDF reporting, and advanced BI are **not implemented**. Do not put confidential production data into an exposed deployment. Website checks make outbound HTTP requests to configured domains; only use domains you are authorized to check. The check is an HTTP reachability signal, not a full functional/security audit.

Google Fonts are referenced remotely by the UI stylesheet; remove that import for a fully offline environment. Core business records and API operation do not require a cloud service.

## Testing
A small Node test suite covers financial arithmetic edge cases. The test suite is not a substitute for full integration/end-to-end tests. See `docs/ROADMAP.md` for the next development sequence.
