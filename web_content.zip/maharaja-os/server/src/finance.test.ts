import test from 'node:test';
import assert from 'node:assert/strict';
function contributionProfit(revenueMinor:number, variableCostMinor:number){return revenueMinor-variableCostMinor}
function marginPercent(revenueMinor:number,costMinor:number){return revenueMinor===0?null:(revenueMinor-costMinor)/revenueMinor*100}
function breakEvenUnits(fixedCostMinor:number, contributionPerUnitMinor:number){return contributionPerUnitMinor<=0?null:Math.ceil(fixedCostMinor/contributionPerUnitMinor)}
test('contribution profit uses integer minor units',()=>assert.equal(contributionProfit(10000,3500),6500));
test('margin returns null for zero revenue',()=>assert.equal(marginPercent(0,500),null));
test('margin percentage is correct',()=>assert.equal(marginPercent(10000,4000),60));
test('break-even rounds up to whole units',()=>assert.equal(breakEvenUnits(10000,3000),4));
test('break-even is undefined for non-positive contribution',()=>assert.equal(breakEvenUnits(10000,0),null));
