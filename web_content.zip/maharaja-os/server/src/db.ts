import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import dotenv from 'dotenv';
dotenv.config({ path: path.resolve(process.cwd(), '../.env') });
const dbPath = process.env.DATABASE_PATH || './data/maharaja.sqlite';
const resolved = path.resolve(process.cwd(), dbPath);
fs.mkdirSync(path.dirname(resolved), { recursive: true });
export const db = new Database(resolved);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS projects (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', owner TEXT NOT NULL DEFAULT 'Unassigned', status TEXT NOT NULL DEFAULT 'planned' CHECK(status IN ('planned','active','at_risk','blocked','completed','archived')), priority TEXT NOT NULL DEFAULT 'medium' CHECK(priority IN ('low','medium','high','critical')), budget_cents INTEGER NOT NULL DEFAULT 0 CHECK(budget_cents>=0), spent_cents INTEGER NOT NULL DEFAULT 0 CHECK(spent_cents>=0), start_date TEXT, due_date TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS tasks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '', assignee TEXT NOT NULL DEFAULT 'Unassigned', status TEXT NOT NULL DEFAULT 'todo' CHECK(status IN ('todo','in_progress','blocked','done')), priority TEXT NOT NULL DEFAULT 'medium' CHECK(priority IN ('low','medium','high','critical')), project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL, due_date TEXT, estimated_hours REAL NOT NULL DEFAULT 0 CHECK(estimated_hours>=0), completed_at TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS transactions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL CHECK(kind IN ('income','expense')), amount_minor INTEGER NOT NULL CHECK(amount_minor>0), currency TEXT NOT NULL DEFAULT 'INR', category TEXT NOT NULL, counterparty TEXT NOT NULL DEFAULT '', transaction_date TEXT NOT NULL, project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL, notes TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'posted' CHECK(status IN ('posted','voided')), idempotency_key TEXT UNIQUE, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS websites (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, domain TEXT NOT NULL DEFAULT '', purpose TEXT NOT NULL DEFAULT '', owner TEXT NOT NULL DEFAULT 'Unassigned', status TEXT NOT NULL DEFAULT 'planning' CHECK(status IN ('planning','development','staging','live','maintenance','retired')), monthly_cost_minor INTEGER NOT NULL DEFAULT 0 CHECK(monthly_cost_minor>=0), created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS website_checks (
 id INTEGER PRIMARY KEY AUTOINCREMENT, website_id INTEGER NOT NULL REFERENCES websites(id) ON DELETE CASCADE, checked_at TEXT NOT NULL DEFAULT (datetime('now')), ok INTEGER NOT NULL CHECK(ok IN (0,1)), status_code INTEGER, response_ms INTEGER, detail TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS audit_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL DEFAULT 'local-user', action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id INTEGER, detail TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_tasks_status_due ON tasks(status,due_date);
CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_transactions_date_kind ON transactions(transaction_date,kind,status);
CREATE INDEX IF NOT EXISTS idx_website_checks_site_date ON website_checks(website_id,checked_at);
`);
