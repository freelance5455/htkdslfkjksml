# Implementation status and roadmap

## Implemented in v0.1.0
- React + TypeScript + Vite responsive dashboard with dark/light themes.
- Express + TypeScript API and SQLite persistent database.
- Project creation/list/update; task creation/list/status update.
- Income/expense ledger with integer minor-unit amounts, idempotency key, and reversal records.
- Website registry and timestamped real HTTP reachability checks.
- Dashboard aggregates derived from stored records, audit events, and downloadable SQLite file route.
- Zod input validation, basic security headers, localhost binding, database foreign keys/indexes.
- Unit tests for financial formula edge cases.

## Not yet implemented
Authentication, session security, roles/permissions, department/team records, milestones and dependency validation, workflow definitions/execution, budget allocation/variance engine, receivables/payables/invoices, complete unit economics, explainable health score, scenario simulator, CRM, marketing, inventory, documents/attachments, notifications/calendar, automation scheduler, AI copilot, analytics integrations, deployment integrations, PDF reports, robust migrations, verified backup/restore UI, and end-to-end/security tests.

## Recommended next phases
1. Authentication, per-user sessions, backend RBAC, CSRF protections as needed, and security test suite.
2. Schema migration framework; project milestones, task dependency graph with cycle detection, budgets and approval history.
3. Financial period reports and formula-tested unit economics.
4. Website roadmap, issues, release records, monitoring history and safe outbound request policy.
5. Business goals, briefing generator, score thresholds, scenario simulation isolated from live records.
6. CRM, marketing, inventory, knowledge and document access controls.
7. Idempotent local automation scheduler, notifications, AI provider adapter with permission-aware retrieval and explicit confirmation for writes.
8. Backup/restore verification, full tests, offline asset strategy, accessibility and production hardening.
