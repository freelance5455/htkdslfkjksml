# Build the MAHARAJA OS Android APK

## Important architecture note
This is an Android WebView wrapper for the existing MAHARAJA OS web client. The Node.js API and SQLite database still run on your computer/server; this wrapper does not bundle Node.js or the database inside the APK. The phone and server must be on a network that can reach the server. Do not expose the app to the public internet without authentication and a security review.

## Configure the URL
Open `app/build.gradle` and edit `START_URL`:
- Android emulator: `http://10.0.2.2:5173`
- Physical Android phone: `http://YOUR_COMPUTER_LAN_IP:5173` (both devices on the same Wi-Fi)

The web client must use the same hostname for its API. The project currently defaults its API to 127.0.0.1, so before using from a physical phone change `const API` in `../client/src/App.tsx` to `const API = `${window.location.protocol}//${window.location.hostname}:4310/api/v1`;` and configure the API CORS allowlist for the client origin. Configure the server host to the LAN interface only when needed.

## Build
1. Install Android Studio and Android SDK Platform 35.
2. Open the `android-wrapper` folder in Android Studio and allow Gradle sync.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.
5. For distribution, create a signed release build and protect the signing key.

This source package has not been compiled in this environment because the Android SDK/Gradle build environment is not installed here. Therefore no compiled APK is included yet.
