import uuid
import time
from datetime import datetime, timedelta
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import random

app = FastAPI(title="USDT Flasher API")

# Mock Database for transactions
transactions_db = {}

class TransactionRequest(BaseModel):
    wallet_address: str
    amount: float
    network: str = "TRC20"

class TransactionResponse(BaseModel):
    tx_hash: str
    status: str
    expiry_timestamp: int
    expiry_datetime: str

@app.post("/flash", response_model=TransactionResponse)
async def flash_usdt(req: TransactionRequest):
    """
    Simulates the flashing logic. 
    In a real scenario, you would interact with the TronGrid API or a Private Key here.
    """
    
    # 1. Validate Input
    if not req.wallet_address.startswith("T"):
        raise HTTPException(status_code=400, detail="Invalid TRC20 address (must start with T)")
    
    if req.amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")

    # 2. Simulate Processing Delay (matches frontend logs)
    # In production, this is where you sign the transaction
    
    # 3. Generate Fake Data
    tx_id = str(uuid.uuid4()).replace('-', '')[:16]
    tx_hash = f"0x{tx_id}...{str(random.randint(1000, 9999))}"
    
    # Flashing Logic: Set an expiry time (usually 24 hours later for flash USDT)
    current_time = datetime.now()
    expiry_time = current_time + timedelta(hours=23, minutes=45) # Matches screenshot approx
    
    # Save to mock DB
    transactions_db[tx_hash] = {
        "address": req.wallet_address,
        "amount": req.amount,
        "created_at": current_time.isoformat(),
        "expires_at": expiry_time.isoformat()
    }

    return TransactionResponse(
        tx_hash=tx_hash,
        status="UNEXPIRED",
        expiry_timestamp=int(expiry_time.timestamp()),
        expiry_datetime=expiry_time.strftime("%I:%M:%S %p")
    )

@app.get("/health")
def health_check():
    return {"status": "connected", "node": "Live"}

if __name__ == "__main__":
    import uvicorn
    # Run on local IP so your Android wrapper can access it via your PC's IP
    uvicorn.run(app, host="0.0.0.0", port=8000)