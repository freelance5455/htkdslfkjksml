#!/data/data/com.termux/files/usr/bin/sh
# Liga o cérebro local da Oplus 5.5 (Qwen2.5-Coder 1.5B, ~1 GB). Rode no Termux: sh iniciar-oplus.sh
pkg update -y && pkg install -y llama-cpp curl
mkdir -p ~/oplus && cd ~/oplus
[ -f oplus.gguf ] || curl -L -o oplus.gguf https://huggingface.co/Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf
termux-wake-lock
llama-server -m oplus.gguf --port 8080 -c 4096 --alias oplus-5.5
