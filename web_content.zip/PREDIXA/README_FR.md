# PREDIXA — Guide rapide

Cette version affiche les rencontres et scores de football. Elle n'intègre pas de paris ni de pronostics de jeu d'argent.

## Sécurité
La clé API publiée dans la conversation est visible : révoque-la depuis ton compte API-Football et génère-en une nouvelle. Ne colle jamais la clé dans le code du site.

## Connecter API-Football avec Cloudflare Workers
1. Crée un compte sur https://dash.cloudflare.com/
2. Va dans **Workers & Pages** et crée un Worker.
3. Colle le contenu de `worker.js`, puis déploie.
4. Dans **Settings > Variables and Secrets**, ajoute un secret nommé `API_FOOTBALL_KEY` avec ta nouvelle clé API.
5. Copie l'adresse de ton Worker (ex. `https://mon-worker.mon-compte.workers.dev`).
6. Dans `assets/app.js`, remplace `https://TON-WORKER.workers.dev` par cette adresse.

## Mettre le site en ligne
Dépose le dossier `PREDIXA` sur Cloudflare Pages ou Netlify. Le Worker et le site sont deux éléments séparés.

## Contenu
- `index.html` : pages et structure
- `assets/style.css` : design responsive bleu nuit / vert néon
- `assets/app.js` : chargement et affichage des matchs
- `worker.js` : proxy sécurisé vers API-Football
