// Cloudflare Worker : la clé reste dans le secret API_FOOTBALL_KEY.
export default { async fetch(request, env) {
 const url=new URL(request.url), cors={"Access-Control-Allow-Origin":"*","Access-Control-Allow-Methods":"GET,OPTIONS","Access-Control-Allow-Headers":"Content-Type","Content-Type":"application/json"};
 if(request.method==="OPTIONS") return new Response(null,{headers:cors});
 if(request.method!=="GET") return new Response(JSON.stringify({error:"Méthode non autorisée"}),{status:405,headers:cors});
 if(!env.API_FOOTBALL_KEY) return new Response(JSON.stringify({error:"Secret API_FOOTBALL_KEY manquant"}),{status:500,headers:cors});
 if(url.pathname!=="/fixtures") return new Response(JSON.stringify({error:"Route inconnue"}),{status:404,headers:cors});
 const p=new URLSearchParams(); for(const k of ["date","league","season","team","live"]){const v=url.searchParams.get(k);if(v)p.set(k,v)}
 if(![...p.keys()].length)return new Response(JSON.stringify({error:"Paramètre requis : date, league, team ou live"}),{status:400,headers:cors});
 const upstream=await fetch("https://v3.football.api-sports.io/fixtures?"+p.toString(),{headers:{"x-apisports-key":env.API_FOOTBALL_KEY}});
 return new Response(await upstream.text(),{status:upstream.status,headers:{...cors,"Cache-Control":"public, max-age=30"}});
}};
