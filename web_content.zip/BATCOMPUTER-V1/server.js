import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const MODEL = process.env.AI_MODEL || "gpt-5";
const MIME = {".html":"text/html; charset=utf-8",".css":"text/css; charset=utf-8",".js":"text/javascript; charset=utf-8",".json":"application/json; charset=utf-8",".svg":"image/svg+xml"};

const systemPrompt = `You are BATCOMPUTER, a thoughtful, careful multilingual detective-assistant inspired by grounded noir fiction.
Detect the user's language automatically and reply in that language unless they ask otherwise. Support Hindi, English, Hinglish, and other languages you can handle.
Use deep, deliberate reasoning internally, but provide a concise answer with clear conclusions, evidence, assumptions, and uncertainty. Never claim certainty when clues are ambiguous.
For cipher requests, identify likely encoding/cipher, explain the method, try plausible decodings, and show the decoded text. Support classical and recreational codes such as Caesar/ROT, Atbash, Morse, binary, hexadecimal, Base64, reversed text, Vigenere when a key is provided, and pattern-based puzzle messages. Ask for a key or context if needed. Do not pretend modern encryption can be cracked without its key.
For case files, separate OBSERVATIONS from HYPOTHESES and NEXT STEPS. Treat uploaded/entered material as unverified evidence. Help with lawful, consent-based research and fictional puzzles; do not facilitate stalking, breaking into accounts/devices, evading law enforcement, or identifying private people from images.
Do not reveal hidden chain-of-thought. Give a brief explanation or summary of reasoning instead.`;

function send(res, status, body, type="application/json; charset=utf-8") {
  res.writeHead(status, {"Content-Type":type, "X-Content-Type-Options":"nosniff", "Referrer-Policy":"no-referrer"});
  res.end(typeof body === "string" ? body : JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve,reject)=>{let data=""; req.on("data",c=>{data+=c; if(data.length>1_500_000) reject(new Error("Request too large"));}); req.on("end",()=>{try{resolve(JSON.parse(data||"{}"));}catch{reject(new Error("Invalid JSON"));}}); req.on("error",reject);});
}
const server = http.createServer(async (req,res)=>{
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  if (req.method==="GET" && url.pathname==="/api/status") return send(res,200,{ok:true,aiConfigured:Boolean(process.env.OPENAI_API_KEY),model:MODEL});
  if (req.method==="POST" && url.pathname==="/api/chat") {
    if (!process.env.OPENAI_API_KEY) return send(res,503,{error:"AI is not connected yet. Add OPENAI_API_KEY to the deployment environment to enable the deep-thinking assistant."});
    try {
      const body=await readBody(req);
      const message=String(body.message||"").slice(0,12000);
      if(!message.trim()) return send(res,400,{error:"Enter a message first."});
      const context=String(body.context||"").slice(0,10000);
      const response=await fetch("https://api.openai.com/v1/responses",{
        method:"POST",
        headers:{"Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
        body:JSON.stringify({
          model:MODEL,
          reasoning:{effort:process.env.AI_REASONING_EFFORT||"high"},
          instructions:systemPrompt,
          input: context ? `Case context (unverified):\n${context}\n\nUser message:\n${message}` : message
        })
      });
      const data=await response.json();
      if(!response.ok) return send(res,response.status,{error:data.error?.message||"AI provider request failed."});
      const output=(data.output||[]).flatMap(item=>item.content||[]).filter(c=>c.type==="output_text").map(c=>c.text).join("\n");
      return send(res,200,{reply:output||"I couldn't produce a text response. Try again.",model:MODEL});
    } catch(e) { return send(res,500,{error:e.message||"Unexpected server error."}); }
  }
  if(req.method==="GET") {
    let requested=decodeURIComponent(url.pathname==="/" ? "/index.html" : url.pathname);
    const full=path.resolve(__dirname, "."+requested);
    if(!full.startsWith(path.resolve(__dirname)+path.sep)) return send(res,403,"Forbidden","text/plain");
    fs.readFile(full,(err,content)=>{if(err)return send(res,404,"Not found","text/plain");send(res,200,content,MIME[path.extname(full)]||"application/octet-stream");});
    return;
  }
  send(res,405,{error:"Method not allowed"});
});
server.listen(PORT,()=>console.log(`BATCOMPUTER listening on ${PORT}`));