# BATCOMPUTER — V1

A Batman-inspired noir detective workstation for Android and desktop browsers.

## Included
- Responsive dark UI inspired by grounded detective technology.
- Multilingual AI chat with server-side API calls.
- AI cipher/puzzle analysis and case-review prompts.
- Local cipher helpers: Caesar shifts, ROT13, Atbash, Morse, binary, hex, Base64, reverse.
- Case files and timestamped notes stored in browser localStorage.
- Optional contrast toggle.

## Run locally
Requires Node.js 20+.

```bash
npm start
```
Open `http://localhost:3000`.

## Enable AI
Set environment variables on the server/deployment platform:
- `OPENAI_API_KEY` — your API key (keep secret; never put it in browser code).
- `AI_MODEL` — a model available to your account that supports the Responses API and reasoning.
- `AI_REASONING_EFFORT` — optional, default `high` (only use a value supported by the selected model).

The default model name is `gpt-5`; change `AI_MODEL` if your account uses another supported model. Model availability and API billing depend on your provider account. The UI works in offline/demo mode without an API key; AI chat will show a setup message.

## Deploy
Deploy as a Node.js web service on a platform that supports Node 20 and environment variables. Use `npm start` as the start command and set the variables above in the platform's secret/environment settings. Never commit API keys.

## Important notes
- Case files and notes are stored in the browser on that device, not in a shared database.
- AI analysis can be wrong; treat outputs as hypotheses and verify important claims.
- Cipher lab handles common encodings/classical ciphers locally. It cannot break modern encryption without the necessary key.
- This is a fictional, consent-based research assistant; do not use it to invade privacy or access systems without permission.
