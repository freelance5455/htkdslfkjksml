CLASSIFICADOS DO ALEX — PROJETO ANDROID OFFLINE (BASE INICIAL)

O que este pacote contém:
- Projeto Android Studio com WebView local.
- Catálogo em HTML/CSS/JavaScript incluído no aplicativo.
- Dados salvos localmente no tablet.
- Cadastro/edição/exclusão de categorias, bairros e anunciantes.
- Backup e restauração dos cadastros.
- Geração local de QR Code via biblioteca ZXing.
- Não requer internet durante o uso normal do catálogo. A internet será necessária para o WhatsApp funcionar no telefone do passageiro.

IMPORTANTE:
Este ZIP contém o PROJETO-FONTE, não um APK já compilado. O ambiente onde este pacote foi criado não tem Android SDK/Gradle configurado para gerar e testar um APK assinado. Para gerar o APK:
1. Instale o Android Studio em um computador.
2. Abra a pasta Classificados_do_Alex_Android como projeto.
3. Permita que o Android Studio baixe os componentes e a dependência ZXing quando estiver conectado à internet.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste normalmente fica em app/build/outputs/apk/debug/app-debug.apk.

PRIMEIRO ACESSO:
- Senha inicial do painel: 1234.
- Entre em “Área administrativa” e altere a senha no painel > Backup.
- Faça backup dos cadastros regularmente. Os dados ficam no armazenamento local deste app e não são sincronizados automaticamente com outro aparelho.

OBSERVAÇÕES:
- Esta é uma primeira base funcional para avaliação; precisa ser compilada e testada no modelo específico do tablet antes de uso no carro.
- As imagens são armazenadas localmente no navegador do aplicativo; fotos muito grandes podem ocupar bastante espaço.
- A senha protege o acesso dentro da interface, mas não substitui criptografia avançada nem proteção física do dispositivo.
- A lista inicial de categorias e bairros é apenas exemplo e pode ser alterada no painel.
