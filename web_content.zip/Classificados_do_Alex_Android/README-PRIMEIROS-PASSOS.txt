CLASSIFICADOS DO ALEX — PROJETO ANDROID (FONTE INICIAL)

O que está neste pacote
- Projeto-fonte para abrir no Android Studio.
- Interface original do protótipo incluída como conteúdo local do app.
- Ponte entre a interface e Android para iniciar transferência Bluetooth.
- Estrutura de envio/recebimento por Bluetooth clássico entre aparelhos previamente pareados.

IMPORTANTE
- Este é um projeto-fonte inicial, não um APK pronto para instalar.
- Não foi compilado/testado em aparelhos reais neste ambiente.
- O primeiro protótipo HTML usa armazenamento local do navegador. Ao empacotá-lo no Android, os dados ficam no armazenamento do WebView desse aparelho.
- A transferência exige que os dois Android estejam pareados no Bluetooth. No recebimento, abra primeiro “Receber”; no celular administrador, escolha “Enviar”.
- Android 12 ou superior pode pedir permissões Bluetooth. Conceda-as para a transferência funcionar.
- Faça cópias de segurança antes de testar. A transferência recebida substitui o catálogo local.
- A senha administrativa 1234 do protótipo é apenas uma proteção básica; troque-a no primeiro uso.

Como abrir
1. Instale o Android Studio em um computador.
2. Descompacte este arquivo.
3. No Android Studio, escolha “Open” e selecione a pasta Classificados_do_Alex_Android.
4. Aguarde a sincronização do Gradle.
5. Conecte um Android por USB com depuração USB ativada e use Run.

Uso do Bluetooth
1. Ative o Bluetooth nos dois aparelhos e pareie-os nas configurações do Android.
2. No tablet, abra Administração e toque em “Atualizar catálogo via Bluetooth” > “Receber”.
3. No celular, abra Administração e toque em “Atualizar catálogo via Bluetooth” > “Enviar”.
4. Selecione o tablet na lista de aparelhos pareados no celular.
5. O catálogo recebido substitui o catálogo existente no tablet.

Limitações desta versão
- É uma base técnica inicial; não é uma versão comercial final.
- Fotos grandes podem tornar o JSON pesado para Bluetooth.
- A interface do protótipo ainda precisa de testes de navegação, tela e permissões em cada modelo.
- QR Code visual gerado localmente no Android foi incluído no código-fonte; precisa ser validado após compilação. Bloqueio de modo quiosque e sincronização mais robusta são etapas futuras.


ATUALIZAÇÃO DE FOTOS E QR CODE (versão fonte v3)
- O formulário de anunciante agora aceita uma foto do estabelecimento/profissional e, separadamente, o logo.
- A foto aparece na lista de anunciantes e na tela de detalhes; o logo aparece abaixo da foto, se cadastrado.
- O QR Code é gerado localmente pelo código Android usando ZXing. Se a interface mostrar “QR Code indisponível”, confirme que o APK foi recompilado com a dependência ZXing e instalado a partir desta versão atualizada.
- Como os dados antigos podem não conter o campo photo, a imagem continua opcional para registros existentes. Edite o anunciante e selecione uma foto para adicioná-la.

CORREÇÃO DE CAMPOS DE IMAGEM (versão fonte v4)
- Campos separados e rotulados: logo da empresa e foto da fachada/loja/profissional.
- O salvamento associa o campo de logo a b.logo e a foto da fachada a b.photo.
- Foi adicionada uma migração única para trocar os valores de registros que tenham sido gravados invertidos pela versão anterior. A migração é executada uma única vez por instalação e salva a marca local cda_image_fields_fixed_v1.
- Faça backup antes de instalar/validar a atualização.


VERSÃO V5 - CORREÇÕES:
- Imagens redimensionadas/comprimidas antes de salvar para reduzir erros de armazenamento.
- Aviso explícito quando o armazenamento local está cheio.
- Removida a troca automática entre logo e foto, que poderia inverter imagens já corretas.
- QR Code do WhatsApp gerado pela ponte Android e exibido sem serviço externo.

Compile novamente e instale a nova versão. Faça backup/exportação do catálogo antes de atualizar.
