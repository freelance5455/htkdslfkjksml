plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "br.com.classificadosdoalex"
    compileSdk = 35
    defaultConfig {
        applicationId = "br.com.classificadosdoalex"
        minSdk = 21
        targetSdk = 35
        versionCode = 5
        versionName = "0.5.0"
    }
}

dependencies {
    implementation("com.google.zxing:core:3.5.3")
}
