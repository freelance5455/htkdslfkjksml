package br.com.classificadosdoalex;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setSystemUiVisibility(
            4 | 1024 | 4096 | 512 | 2
        );
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(10,10,10));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new QrBridge(), "AndroidQR");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class QrBridge {
        @JavascriptInterface
        public String makeQr(String value) {
            try {
                BitMatrix matrix = new MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, 420, 420);
                Bitmap bitmap = Bitmap.createBitmap(420, 420, Bitmap.Config.ARGB_8888);
                for (int x=0; x<420; x++) {
                    for (int y=0; y<420; y++) {
                        bitmap.setPixel(x, y, matrix.get(x,y) ? Color.BLACK : Color.WHITE);
                    }
                }
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }
    }

    @Override public void onBackPressed() {
        webView.evaluateJavascript("goBack()", null);
    }
}
