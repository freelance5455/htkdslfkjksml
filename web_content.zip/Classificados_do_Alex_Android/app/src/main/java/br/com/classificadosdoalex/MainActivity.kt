package br.com.classificadosdoalex

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.Toast
import android.app.AlertDialog
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.qrcode.QRCodeWriter
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.io.PrintWriter
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val executor = Executors.newSingleThreadExecutor()
    private val serviceName = "ClassificadosDoAlex"
    private val serviceUuid: UUID = UUID.fromString("ad4a1e20-2d5b-4c8f-9a10-1d7d4a1e2026")
    private val requestBluetoothPermissions = 704
    private val requestFileChooser = 705
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = object : WebChromeClient() {
            // WebView does not open <input type="file"> unless the host app implements this callback.
            override fun onShowFileChooser(
                view: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                return try {
                    val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "image/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                    }
                    val chooser = Intent.createChooser(intent, "Escolha uma foto")
                    startActivityForResult(chooser, requestFileChooser)
                    true
                } catch (e: Exception) {
                    this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                    this@MainActivity.fileChooserCallback = null
                    toast("Não foi possível abrir a galeria. Verifique se há um aplicativo de fotos instalado.")
                    false
                }
            }
        }
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(), "Android")
        webView.loadUrl("file:///android_asset/index.html")
        ensureBluetoothPermissions()
    }

    private fun ensureBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val needed = arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_ADVERTISE
            ).filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
            if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), requestBluetoothPermissions)
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun syncCatalog(json: String) {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("Atualizar catálogo")
                    .setItems(arrayOf("Enviar este catálogo", "Receber catálogo neste aparelho")) { _, which ->
                        if (which == 0) chooseDeviceAndSend(json) else receiveCatalog()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }


        @JavascriptInterface
        fun generateQrDataUrl(content: String): String {
            return try {
                val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, 360, 360)
                val bitmap = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888)
                for (x in 0 until matrix.width) {
                    for (y in 0 until matrix.height) {
                        bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
                    }
                }
                val stream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                "data:image/png;base64," + Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
            } catch (e: Exception) {
                ""
            }
        }

        @JavascriptInterface
        fun showMessage(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show() }
        }
    }

    private fun adapter(): BluetoothAdapter? {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        return manager?.adapter
    }

    private fun hasConnectPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun chooseDeviceAndSend(json: String) {
        if (!hasConnectPermission()) {
            ensureBluetoothPermissions()
            toast("Conceda as permissões Bluetooth e tente novamente.")
            return
        }
        val bt = adapter()
        if (bt == null || !bt.isEnabled) {
            toast("Ative o Bluetooth nos dois aparelhos e pareie-os nas configurações.")
            return
        }
        val devices = try { bt.bondedDevices.toList() } catch (_: SecurityException) { emptyList() }
        if (devices.isEmpty()) {
            toast("Nenhum aparelho pareado. Pareie o tablet nas configurações do Android.")
            return
        }
        val labels = devices.map { device ->
            val name = try { device.name ?: "Android sem nome" } catch (_: SecurityException) { "Android" }
            "$name\n${device.address}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Escolha o tablet pareado")
            .setItems(labels) { _, index ->
                executor.execute { sendToDevice(devices[index], json) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun sendToDevice(device: BluetoothDevice, json: String) {
        var socket: BluetoothSocket? = null
        try {
            if (!hasConnectPermission()) throw SecurityException("Permissão Bluetooth ausente")
            socket = device.createRfcommSocketToServiceRecord(serviceUuid)
            socket.connect()
            val writer = PrintWriter(OutputStreamWriter(socket.outputStream, Charsets.UTF_8), true)
            writer.println(json)
            writer.flush()
            runOnUiThread { toast("Catálogo enviado. Confira o tablet.") }
        } catch (e: Exception) {
            runOnUiThread { toast("Não foi possível enviar. No tablet, escolha Receber primeiro. ${e.message ?: ""}") }
        } finally {
            try { socket?.close() } catch (_: Exception) {}
        }
    }

    private fun receiveCatalog() {
        if (!hasConnectPermission()) {
            ensureBluetoothPermissions()
            toast("Conceda as permissões Bluetooth e tente novamente.")
            return
        }
        val bt = adapter()
        if (bt == null || !bt.isEnabled) {
            toast("Ative o Bluetooth e pareie o celular antes de receber.")
            return
        }
        toast("Aguardando conexão. Agora escolha Enviar no celular.")
        executor.execute {
            var server: BluetoothServerSocket? = null
            var socket: BluetoothSocket? = null
            try {
                server = bt.listenUsingRfcommWithServiceRecord(serviceName, serviceUuid)
                socket = server.accept()
                val reader = BufferedReader(InputStreamReader(socket.inputStream, Charsets.UTF_8))
                val payload = StringBuilder()
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    if (payload.isNotEmpty()) payload.append('\n')
                    payload.append(line)
                }
                val json = payload.toString()
                val parsed = JSONObject(json)
                if (!parsed.has("categories") || !parsed.has("businesses") || !parsed.has("neighborhoods")) {
                    throw IllegalArgumentException("O arquivo recebido não parece ser um catálogo válido.")
                }
                val safeJson = JSONObject.quote(json)
                runOnUiThread {
                    AlertDialog.Builder(this)
                        .setTitle("Substituir catálogo?")
                        .setMessage("O catálogo recebido substituirá os dados deste aparelho.")
                        .setPositiveButton("Substituir") { _, _ ->
                            webView.evaluateJavascript("window.importFromNative($safeJson)", null)
                            toast("Catálogo atualizado.")
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Falha ao receber catálogo: ${e.message ?: "erro Bluetooth"}") }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
                try { server?.close() } catch (_: Exception) {}
            }
        }
    }


    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestFileChooser) {
            val callback = fileChooserCallback ?: return
            fileChooserCallback = null
            val result: Array<Uri>? = if (resultCode == RESULT_OK) {
                val clipData = data?.clipData
                when {
                    clipData != null && clipData.itemCount > 0 -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    data?.data != null -> arrayOf(data.data!!)
                    else -> null
                }
            } else null
            callback.onReceiveValue(result)
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        webView.removeJavascriptInterface("Android")
        webView.destroy()
        executor.shutdownNow()
        super.onDestroy()
    }
}
