# Study Folder

Mobile-first, offline-capable study notes organizer built with HTML, CSS and vanilla JavaScript.

## Features
- Create, rename and delete folders (folder deletion confirms and deletes its notes).
- Create, edit, delete and complete study notes.
- Instant search across folder names, note titles, and note body text.
- Overview stats and completion progress.
- Local browser storage using `localStorage`, stable key `study-folder:v1`; editor drafts are written as you type and restored when reopening the editor.
- JSON backup export and additive import (conflicting IDs skipped; no replacement of existing notes).
- Service worker app-shell caching for offline launches after initial successful online load.
- No login, backend, or third-party dependencies.

## Run locally on a computer
Service workers require HTTPS or localhost (not `file://`).
1. Extract the ZIP.
2. In the project folder run `python -m http.server 8000`
3. Open `http://localhost:8000` in a browser.

## Android Chrome
For dependable installation and offline cache, host this folder on an HTTPS static host (for example a static web host you control).
1. Visit the HTTPS URL in Chrome while online.
2. Wait for the page to load once so the service worker can cache the app shell.
3. Chrome menu ⋮ → **Install app** or **Add to Home screen**.
4. Open the installed app. Create/export notes as desired.

Opening `index.html` directly as a local file can work for basic use, but service worker/PWA install will not work from `file://`.

## Package as an Android APK
**Simple route (recommended):** use a trusted PWA-to-APK packaging workflow such as Bubblewrap/TWA after deploying to HTTPS. Set up the Android package ID, app signing and Digital Asset Links (`/.well-known/assetlinks.json`) as required by that workflow. An installed Trusted Web Activity opens the hosted PWA; a verified origin and network are part of the deployment design.

**Self-contained offline APK:** create an Android Studio project with an Android `WebView` and bundle the five web files under `app/src/main/assets/`. Load `file:///android_asset/index.html`. Keep JavaScript enabled and DOM storage enabled (`webView.settings.javaScriptEnabled = true`, `webView.settings.domStorageEnabled = true`). The service worker won't be used from this file URL; the app still uses localStorage for notes. For stronger storage guarantees, use a local HTTPS origin or native storage bridge/IndexedDB design. Add WebView navigation restrictions and configure backup/export/import file interactions if building a production wrapper. Build/sign the APK from Android Studio.

## Data safety notes
- Browser storage belongs to that browser profile on that device. Clearing browser/site data, uninstalling a wrapper, or storage eviction may remove notes.
- Export JSON backups frequently and keep a copy outside the app.
- Import merges rather than replacing: existing matching IDs are skipped. Folder name collisions are disambiguated.
- Note body allows long text (up to 1,000,000 characters). Storage quota varies by device/browser.
- Avoid storing confidential or sensitive personal data in a shared device profile.

## Verification performed
The app project includes client-side guards for empty fields, duplicate folder names, missing folder references, and import format checks. Review/testing should be completed on target Android devices and browsers before relying on it for irreplaceable materials. Automated browser/device testing was not available in this build environment.
