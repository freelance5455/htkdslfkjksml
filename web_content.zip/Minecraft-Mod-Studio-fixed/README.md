# Minecraft Mod Studio 0.2.1

Proyecto Android corregido con estructura Gradle estándar.

## Compilar
Requiere JDK 17 y Android SDK Platform 35.

```bash
gradle --version
gradle :app:assembleDebug
```

El APK de depuración se genera en `app/build/outputs/apk/debug/app-debug.apk`.

También se puede ejecutar el workflow **Build Android APK** desde GitHub Actions. El artefacto se publica como `Minecraft-Mod-Studio-0.2.1-debug-apk`.

Este proyecto fuente no es un APK. La compilación debe completarse correctamente en GitHub Actions o Android Studio antes de instalarlo.
