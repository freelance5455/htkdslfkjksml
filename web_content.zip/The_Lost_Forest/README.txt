# The Lost Forest — High Graphics 3D mobile prototype

Open `index.html` in a modern browser with internet access. It loads Three.js from a CDN, so the first launch needs internet.

High-graphics improvements in this build:
- Sharper rendering (up to device pixel ratio 2)
- ACES cinematic tone mapping
- Higher-resolution directional shadows
- Denser forest trees and ground foliage
- Softer atmospheric fog

Controls:
- Mobile: left joystick to move; drag the right side of the screen to look around.
- FIRE attacks/shoots; SWITCH/WEAPON cycles weapons.
- SPRINT toggles sprint; CROUCH toggles crouching.
- Pause button opens pause menu; Dinosaur Log opens the kill/encounter database.
- Desktop: WASD/arrows to move, mouse to look, click to fire, Shift sprint, C crouch, Q switch weapon, Esc pause.

This remains an early playable prototype, not a finished app or APK. It uses procedural 3D models and placeholder weapon behavior. High graphics can reduce performance on older phones. Progress resets on reload.
