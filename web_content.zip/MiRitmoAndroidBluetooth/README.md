# Mi Ritmo — Android + Bluetooth LE

Este proyecto conserva la página HTML de Mi Ritmo y la abre dentro de una app Android.
Incluye una implementación inicial para:
- pedir permisos Bluetooth;
- buscar anuncios Bluetooth Low Energy (BLE) durante 12 segundos;
- mostrar los dispositivos encontrados en la página;
- intentar conectarse al dispositivo seleccionado por GATT;
- desconectarse.

## Abrir y ejecutar
1. Descomprime `MiRitmoAndroidBluetooth.zip`.
2. Abre la carpeta `MiRitmoAndroidBluetooth` en Android Studio (recomendado) o en VS Code con un JDK 17 y Gradle/Android SDK configurados.
3. Permite que Gradle sincronice el proyecto.
4. Ejecuta la app en un teléfono Android real con Bluetooth. Los emuladores normalmente no detectan relojes físicos.
5. Pulsa **Buscar reloj por Bluetooth**, acepta los permisos y selecciona un dispositivo.

## Limitaciones importantes
- Esta versión usa Bluetooth Low Energy (BLE), no escaneo Bluetooth clásico.
- Que aparezca un reloj no significa que permita conectarse desde una app de terceros.
- La conexión GATT solo confirma el enlace Bluetooth; **no obtiene automáticamente pasos, sueño, pulso ni otros datos de salud**.
- Para leer datos de salud hay que implementar el protocolo/API específico del fabricante (por ejemplo, Health Connect, Garmin, Huawei u otro SDK permitido) y solicitar los permisos correspondientes.
- Algunos relojes requieren estar en modo emparejamiento o usar la aplicación oficial del fabricante.
- El proyecto se entrega como código fuente; no se ha compilado en este entorno y necesitarás Android SDK/JDK para probarlo.
