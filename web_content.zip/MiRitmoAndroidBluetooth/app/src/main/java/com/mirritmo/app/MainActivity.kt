package com.mirritmo.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val mainHandler = Handler(Looper.getMainLooper())
    private val foundDevices = linkedMapOf<String, BluetoothDevice>()
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var isScanning = false

    private val bluetoothManager by lazy {
        getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    }
    private val bluetoothAdapter: BluetoothAdapter?
        get() = bluetoothManager.adapter

    private val permissionRequestCode = 401
    private var pendingAction: (() -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(MiRitmoBridge(), "MiRitmoBridge")
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun requiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    private fun hasBluetoothPermissions(): Boolean =
        requiredPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun withBluetoothPermissions(action: () -> Unit) {
        if (hasBluetoothPermissions()) {
            action()
        } else {
            pendingAction = action
            requestPermissions(requiredPermissions(), permissionRequestCode)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequestCode) {
            if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                pendingAction?.invoke()
            } else {
                reportState("error", "Se necesitan permisos Bluetooth para buscar y conectar dispositivos.")
            }
            pendingAction = null
        }
    }

    private fun reportState(state: String, message: String) {
        val stateJs = JSONObject.quote(state)
        val messageJs = JSONObject.quote(message)
        runOnUiThread {
            if (::webView.isInitialized) {
                webView.evaluateJavascript(
                    "window.onBluetoothConnectionState && window.onBluetoothConnectionState($stateJs, $messageJs);",
                    null
                )
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBleScan() {
        withBluetoothPermissions {
            val adapter = bluetoothAdapter
            if (adapter == null) {
                reportState("error", "Este dispositivo no tiene Bluetooth.")
                return@withBluetoothPermissions
            }
            if (!adapter.isEnabled) {
                reportState("error", "Activa Bluetooth en los ajustes del teléfono y vuelve a intentarlo.")
                return@withBluetoothPermissions
            }
            stopBleScan()
            val bleScanner = adapter.bluetoothLeScanner
            if (bleScanner == null) {
                reportState("error", "No está disponible el escáner Bluetooth LE.")
                return@withBluetoothPermissions
            }
            scanner = bleScanner
            foundDevices.clear()
            isScanning = true
            reportState("scanning", "Buscando dispositivos Bluetooth LE durante 12 segundos…")
            try {
                bleScanner.startScan(scanCallback)
                mainHandler.postDelayed({
                    stopBleScan()
                    sendFoundDevices()
                }, 12_000)
            } catch (e: Exception) {
                isScanning = false
                reportState("error", "No se pudo iniciar el escaneo Bluetooth.")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopBleScan() {
        if (isScanning) {
            try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
            isScanning = false
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            val address = try { device.address } catch (_: SecurityException) { return }
            synchronized(foundDevices) { foundDevices[address] = device }
            sendFoundDevices()
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            results.forEach { result ->
                val device = result.device ?: return@forEach
                try { synchronized(foundDevices) { foundDevices[device.address] = device } }
                catch (_: SecurityException) {}
            }
            sendFoundDevices()
        }

        override fun onScanFailed(errorCode: Int) {
            isScanning = false
            reportState("error", "Falló la búsqueda Bluetooth (código $errorCode).")
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendFoundDevices() {
        val array = JSONArray()
        synchronized(foundDevices) {
            foundDevices.values.forEach { device ->
                val item = JSONObject()
                try {
                    item.put("name", device.name ?: "")
                    item.put("address", device.address)
                    array.put(item)
                } catch (_: SecurityException) {}
            }
        }
        val json = array.toString()
        runOnUiThread {
            webView.evaluateJavascript(
                "window.onBluetoothDevicesFound && window.onBluetoothDevicesFound($json);",
                null
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectToDevice(address: String) {
        withBluetoothPermissions {
            stopBleScan()
            val adapter = bluetoothAdapter
            if (adapter == null || !adapter.isEnabled) {
                reportState("error", "Activa Bluetooth antes de conectar.")
                return@withBluetoothPermissions
            }
            val device = try { adapter.getRemoteDevice(address) } catch (_: IllegalArgumentException) {
                reportState("error", "La dirección del dispositivo no es válida.")
                return@withBluetoothPermissions
            }
            try {
                gatt?.close()
                reportState("connecting", "Conectando por Bluetooth LE a ${device.name ?: address}…")
                gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
                } else {
                    device.connectGatt(this, false, gattCallback)
                }
            } catch (e: Exception) {
                reportState("error", "No se pudo iniciar la conexión Bluetooth LE.")
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status == android.bluetooth.BluetoothGatt.GATT_SUCCESS &&
                newState == BluetoothProfile.STATE_CONNECTED) {
                this@MainActivity.gatt = gatt
                reportState("connected", "Conectado por Bluetooth LE. Esto no garantiza acceso a datos de salud.")
                // We intentionally do not read arbitrary services/characteristics without a
                // device-specific protocol and the user's consent.
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                try { gatt.close() } catch (_: Exception) {}
                if (this@MainActivity.gatt === gatt) this@MainActivity.gatt = null
                reportState("disconnected", "El dispositivo Bluetooth se desconectó.")
            } else if (status != android.bluetooth.BluetoothGatt.GATT_SUCCESS) {
                reportState("error", "No se pudo completar la conexión (código $status).")
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun disconnectDevice() {
        stopBleScan()
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        gatt = null
        reportState("disconnected", "Desconectado. Los datos guardados no se han borrado.")
    }

    inner class MiRitmoBridge {
        @JavascriptInterface
        fun scanBluetooth() {
            runOnUiThread { startBleScan() }
        }

        @JavascriptInterface
        fun connectDevice(address: String) {
            runOnUiThread { connectToDevice(address) }
        }

        @JavascriptInterface
        fun connect(brand: String) {
            // The brand selection is a hint only; BLE scanning itself is generic.
            runOnUiThread { startBleScan() }
        }

        @JavascriptInterface
        fun disconnect() {
            runOnUiThread { disconnectDevice() }
        }
    }

    override fun onDestroy() {
        stopBleScan()
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        webView.removeJavascriptInterface("MiRitmoBridge")
        webView.destroy()
        super.onDestroy()
    }
}
