COMMISSION CALCULATOR — ANDROID STUDIO SOURCE PROJECT (v2.0)

Features
- Overview: combined weekly and monthly transaction volume and commission estimates.
- Withdrawal calculator: average transaction amount, transactions per day, cardholder platform fee %, your commission %, weekly/monthly volume and income.
- Bill-payment calculator: average bill amount, transactions per day, commission %, operating days/month, weekly/monthly volume and income.
- Percentage calculator: subtract deduction % and commission % from the original amount.
- Decimal percentage support (for example 1.4, 0.25, 0.05).
- Reset all fields to default assumptions.
- Runs offline in a WebView; no internet permission is requested.

Default assumptions are editable:
- Withdrawal platform fee charged to cardholder: 1.4%.
- Withdrawal commission earned by you: 0.2% (₹200 per ₹1,00,000 transaction).
- Bill-payment commission earned by you: 2% (use the actual rate confirmed by your platform).
- Weekly estimate: 7 days. Withdrawal monthly estimate: 30 days. Bill payment uses the editable operating-days/month field.

BUILD APK
1. Extract this ZIP.
2. Open the extracted AmountCommissionCalculator folder in Android Studio.
3. Allow Android Studio to sync/download the Android Gradle Plugin and SDK components if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When the build completes, use the notification's Locate link. The APK is usually under app/build/outputs/apk/debug/app-debug.apk.

This ZIP is Android Studio source code, not a precompiled APK. The current workspace did not have Android SDK/Gradle installed, so an APK could not be compiled here.
