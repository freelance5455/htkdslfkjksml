Motociklų apskaita — Android Studio project

To build APK:
1. Install Android Studio (with Android SDK Platform 35).
2. Open this folder in Android Studio.
3. Wait for Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK is created at app/build/outputs/apk/debug/app-debug.apk.

The app stores data in WebView local storage on the device. Back up data using the in-app backup feature.
