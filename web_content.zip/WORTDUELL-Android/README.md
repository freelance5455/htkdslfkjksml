# WORTDUELL Android – APK-Bauprojekt

Dies ist ein **Android-Studio-Projekt**, keine APK. Es umhüllt die vorhandene Multiplayer-Web-App in einer Android WebView und fragt beim Start nach der Adresse des laufenden WORTDUELL-Servers. Ein Server wird **nicht auf dem Handy gestartet**.

## APK bauen
1. Projekt in Android Studio (mit Android SDK 35 und JDK 17) öffnen.
2. Gradle synchronisieren.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Datei unter `app/build/outputs/apk/debug/app-debug.apk` installieren.

## Multiplayer-Server
Im Projektordner mit Node.js 20+ `node server.js` starten. Alle Spieler benötigen die Serveradresse, z.B. `http://192.168.1.10:3000`. Das Hauptgerät ist **Spielcontroller**, nicht automatisch der Server. Im Offline-WLAN muss ein Gerät den Server ausführen.

## Noch nicht enthalten
- Keine native Bluetooth-Verbindung
- Kein eigenständiger lokaler Server auf Android
- Kein bereitgestellter Internetserver
- WebRTC-Video benötigt HTTPS und Tests auf Geräten
- 20 CSS-Themes, keine originalgetreuen 4K-Reproduktionen
- Aufgaben sind Rohfassung und benötigen redaktionelle Prüfung

Die App verlangt Kamera/Mikrofonberechtigungen. HTTP ist nur für den lokalen Test freigeschaltet und für den produktiven Einsatz nicht geeignet.
