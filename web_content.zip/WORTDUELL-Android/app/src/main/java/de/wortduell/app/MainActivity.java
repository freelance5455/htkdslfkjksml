package de.wortduell.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Button;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    private WebView web;
    private SharedPreferences prefs;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("wortduell", MODE_PRIVATE);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, 7);
        }
        showConnection();
    }
    private void showConnection() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 60, 36, 20);
        layout.setBackgroundColor(0xff140b2b);
        TextView title = new TextView(this);
        title.setText("WORTDUELL\nDark Neon · Verbindung zum Spielserver");
        title.setTextColor(0xffd7bbff); title.setTextSize(24);
        layout.addView(title);
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(0xffffffff); input.setHintTextColor(0xffa69bbd);
        input.setHint("http://192.168.1.10:3000");
        input.setText(prefs.getString("url", "http://192.168.1.10:3000"));
        layout.addView(input);
        Button connect = new Button(this); connect.setText("Mit Spiel verbinden");
        layout.addView(connect);
        TextView info = new TextView(this);
        info.setText("Alle Geräte benötigen Zugriff auf denselben laufenden WORTDUELL-Server. Für Kamera und Mikrofon ist HTTPS erforderlich. Bluetooth ist noch nicht implementiert.");
        info.setTextColor(0xffd7bbff);
        layout.addView(info);
        connect.setOnClickListener(v -> {
            String url = input.getText().toString().trim();
            if (!url.startsWith("https://") && !url.startsWith("http://")) url = "http://" + url;
            prefs.edit().putString("url",url).apply(); openGame(url);
        });
        setContentView(layout);
    }
    private void openGame(String url) {
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && request.getOrigin().toString().startsWith("https://")) {
                        request.grant(request.getResources());
                    } else request.deny();
                });
            }
        });
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        setContentView(web, new ViewGroup.LayoutParams(-1,-1));
        web.loadUrl(url);
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else showConnection();
    }
    @Override protected void onDestroy() { if(web!=null) web.destroy(); super.onDestroy(); }
}
