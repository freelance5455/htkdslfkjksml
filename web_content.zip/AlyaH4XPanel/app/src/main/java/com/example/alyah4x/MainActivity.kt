package com.example.alyah4x
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
class MainActivity: AppCompatActivity(){
 private lateinit var web:WebView
 override fun onCreate(b:Bundle?){super.onCreate(b);web=WebView(this).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=true;webViewClient=WebViewClient();addJavascriptInterface(Bridge(),"Android");loadUrl("file:///android_asset/index.html")};setContentView(web)}
 inner class Bridge{
  @JavascriptInterface fun openOverlaySettings(){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}
  @JavascriptInterface fun overlayAllowed()=Settings.canDrawOverlays(this@MainActivity)
  @JavascriptInterface fun startOverlay(fov:Float,color:String,glow:Boolean){if(!Settings.canDrawOverlays(this@MainActivity))return;startService(Intent(this@MainActivity,OverlayService::class.java).apply{putExtra("fov",fov);putExtra("color",color);putExtra("glow",glow)})}
  @JavascriptInterface fun stopOverlay(){stopService(Intent(this@MainActivity,OverlayService::class.java))}
  @JavascriptInterface fun openFreeFire():Boolean{for(p in listOf("com.dts.freefireth","com.dts.freefiremax")){packageManager.getLaunchIntentForPackage(p)?.let{startActivity(it);return true}};return false}
 }
 override fun onResume(){super.onResume();if(::web.isInitialized)web.evaluateJavascript("window.updateOverlayPermission&&window.updateOverlayPermission();",null)}
}
