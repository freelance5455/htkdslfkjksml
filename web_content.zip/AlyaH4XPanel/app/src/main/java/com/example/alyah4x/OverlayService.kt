package com.example.alyah4x
import android.app.Service
import android.content.Intent
import android.graphics.*
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.content.Context
class OverlayService:Service(){private lateinit var wm:WindowManager;private lateinit var ring:FovRingView;private lateinit var lp:WindowManager.LayoutParams
 override fun onCreate(){super.onCreate();if(!Settings.canDrawOverlays(this)){stopSelf();return};wm=getSystemService(WINDOW_SERVICE) as WindowManager;ring=FovRingView(this);lp=WindowManager.LayoutParams(420,420,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT).apply{gravity=Gravity.CENTER};ring.setOnTouchListener(object:View.OnTouchListener{var dx=0f;var dy=0f;var sx=0;var sy=0;override fun onTouch(v:View,e:MotionEvent):Boolean{when(e.actionMasked){MotionEvent.ACTION_DOWN->{dx=e.rawX;dy=e.rawY;sx=lp.x;sy=lp.y};MotionEvent.ACTION_MOVE->{lp.x=sx+(e.rawX-dx).toInt();lp.y=sy+(e.rawY-dy).toInt();wm.updateViewLayout(ring,lp)}};return true}});wm.addView(ring,lp)}
 override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int{ring.configure(i?.getFloatExtra("fov",25f)?:25f,i?.getStringExtra("color")?:"#FF4DFF",i?.getBooleanExtra("glow",true)?:true);return START_STICKY}
 override fun onDestroy(){if(::ring.isInitialized)wm.removeView(ring);super.onDestroy()};override fun onBind(i:Intent?):IBinder?=null}
class FovRingView(c:Context):View(c){private val p=Paint(Paint.ANTI_ALIAS_FLAG);private var fov=25f;private var col=Color.MAGENTA;private var glow=true;init{setLayerType(View.LAYER_TYPE_SOFTWARE,null);p.style=Paint.Style.STROKE}fun configure(f:Float,color:String,g:Boolean){fov=f.coerceIn(5f,120f);glow=g;try{col=Color.parseColor(color)}catch(_:Exception){};invalidate()}override fun onDraw(c:Canvas){val r=55f+(fov/120f)*145f;p.color=col;p.alpha=230;p.strokeWidth=4.5f;p.setShadowLayer(if(glow)18f else 0f,0f,0f,col);c.drawCircle(width/2f,height/2f,r,p);p.clearShadowLayer()}}
