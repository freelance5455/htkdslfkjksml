# Zombie Night

Top-down zombie survival shooter. Pure HTML/JS, no install, no dependencies.

## Features
200 levels, 15 guns, 6 unlockable powers, coin upgrades, daily reward, stars, combo kills,
5 map themes, boss waves, 5 enemy types (walker, runner, tank, exploder, spitter), tutorial,
settings, auto-rotate to landscape, saved progress, music and sound effects.

## Run
Open index.html in Chrome, or upload this folder to GitHub Pages / Netlify and open the link on a phone.
It is also an installable PWA (Add to Home Screen) - needs https hosting.

## Turn it into an Android app (Capacitor)
1. Install Node.js, then: npm init -y && npm i @capacitor/core @capacitor/cli @capacitor/android
2. npx cap init "Zombie Night" com.yourname.zombienight --web-dir=www
3. mkdir www && copy index.html, manifest.json, sw.js and icons into www
4. npx cap add android && npx cap sync && npx cap open android
5. In Android Studio set orientation to landscape, build a signed AAB, upload to Google Play.
Add AdMob via @capacitor-community/admob if you want ads.

## Before you publish or sell
- Check that the name Zombie Night and the logo do not clash with an existing trademark.
- Replace the code-drawn graphics with your own or licensed art for a more professional look.
- Test on real phones and fix any lag or bugs you find.
