SHIT FOCUS — App ZIP

1. Extract this ZIP on your Android phone.
2. Open index.html in your browser or an editor such as Acode.
3. Your habits are saved in this browser on this device. Use Settings > Export backup to keep a copy.

Note: This ZIP contains the web app files, not a signed Android APK. To make an APK, package index.html inside an Android WebView app or use a compatible builder. A simple website wrapper may require hosting and may not work offline.
