plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dolastrap.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.dolastrap.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "3.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
}

// Salin halaman web dari folder induk (index.html, css, js, assets) ke assets APK setiap build.
val webOut = layout.buildDirectory.dir("web")
val copyWeb by tasks.registering(Copy::class) {
    from(rootProject.projectDir.parentFile) { include("index.html", "css/**", "js/**", "assets/**") }
    into(webOut)
}
android.sourceSets.getByName("main").assets.srcDir(webOut)
tasks.named("preBuild") { dependsOn(copyWeb) }
