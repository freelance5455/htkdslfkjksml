package com.dolastrap.app

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * DolaStrap v3 - WebView + jembatan "Android".
 * Halaman web disalin otomatis dari folder induk ke assets oleh app/build.gradle.kts.
 *
 * Yang benar-benar dilakukan:
 *  - isInstalled / findPackage / listApps / diag: melihat dan memeriksa aplikasi terpasang
 *  - launchGame: membuka Mamoball (dicoba beberapa cara) dan melapor ok / alasan gagal
 *  - boost SISTEM yang ikut berlaku untuk game (butuh izin dari pengguna): refresh rate,
 *    kecerahan, mode fokus (DND). Dipulihkan saat pengguna kembali ke DolaStrap.
 * Tidak bisa: mengubah FPS internal, grafis, hitbox, atau fisika bola di dalam game orang lain.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var wifiLock: WifiManager.WifiLock? = null
    private val prefs by lazy { getSharedPreferences("dolastrap", Context.MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = object : WebViewClient() {
            // Tangani intent:, market:, https:// dari halaman (cadangan jika jembatan tidak dipakai).
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                if (url.startsWith("file:")) return false
                try {
                    val i = if (url.startsWith("intent:")) Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                    else Intent(Intent.ACTION_VIEW, request.url)
                    i.addCategory(Intent.CATEGORY_BROWSABLE)
                    i.component = null
                    i.selector = null
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                } catch (e: Exception) { }
                return true
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.DolaBack && DolaBack()") { handled ->
                    if (handled != "true") finish()
                }
            }
        })
    }

    override fun onResume() {
        super.onResume()
        restoreSystem() // kembalikan refresh rate / kecerahan / DND setelah selesai main
    }

    override fun onDestroy() {
        wifiLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    // ================= jembatan ke JavaScript =================
    inner class Bridge {
        @JavascriptInterface
        fun isInstalled(pkg: String): Boolean = buildLaunchIntent(pkg) != null

        @JavascriptInterface
        fun findPackage(keyword: String): String {
            val k = keyword.lowercase()
            return launchables().firstOrNull {
                it.activityInfo.packageName.lowercase().contains(k) ||
                    it.loadLabel(packageManager).toString().lowercase().contains(k)
            }?.activityInfo?.packageName ?: ""
        }

        /** Semua aplikasi peluncur yang terlihat: [{"l":"label","p":"package"}] */
        @JavascriptInterface
        fun listApps(): String {
            val arr = JSONArray()
            launchables().sortedBy { it.loadLabel(packageManager).toString().lowercase() }.forEach {
                arr.put(JSONObject().put("l", it.loadLabel(packageManager).toString()).put("p", it.activityInfo.packageName))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun diag(pkg: String): String = JSONObject()
            .put("sdk", Build.VERSION.SDK_INT)
            .put("model", Build.MANUFACTURER + " " + Build.MODEL)
            .put("visibleApps", launchables().size)
            .put("installed", buildLaunchIntent(pkg) != null)
            .put("known", isPackageKnown(pkg))
            .put("writeSettings", Settings.System.canWrite(this@MainActivity))
            .put("dnd", (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).isNotificationPolicyAccessGranted)
            .toString()

        /** Dipanggil dari JS. Mengembalikan {"ok":true,"applied":[...],"skipped":[...]} atau {"ok":false,"reason":"..."} */
        @JavascriptInterface
        fun launchGame(json: String, pkg: String): String {
            var result = fail("bridge_error")
            val latch = CountDownLatch(1)
            runOnUiThread { try { result = applyAndLaunch(json, pkg) } finally { latch.countDown() } }
            latch.await(4, TimeUnit.SECONDS)
            return result
        }

        @JavascriptInterface
        fun openStore(pkg: String) {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
        }

        @JavascriptInterface
        fun askWriteSettings() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        @JavascriptInterface
        fun askDnd() {
            runOnUiThread {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }

        @JavascriptInterface
        fun restoreSystem() { runOnUiThread { this@MainActivity.restoreSystem() } }
    }

    // ================= peluncuran =================
    private fun fail(reason: String): String = JSONObject().put("ok", false).put("reason", reason).toString()

    @Suppress("DEPRECATION")
    private fun queryActivities(i: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) packageManager.queryIntentActivities(i, PackageManager.ResolveInfoFlags.of(0))
        else packageManager.queryIntentActivities(i, 0)

    private fun launchables(): List<ResolveInfo> =
        queryActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER))

    /** Dua cara: getLaunchIntentForPackage, lalu cari activity MAIN/LAUNCHER milik package itu. */
    private fun buildLaunchIntent(pkg: String): Intent? {
        packageManager.getLaunchIntentForPackage(pkg)?.let { return it }
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pkg)
        val ri = queryActivities(q).firstOrNull() ?: return null
        return Intent(q).setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
    }

    @Suppress("DEPRECATION")
    private fun isPackageKnown(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0); true
    } catch (e: PackageManager.NameNotFoundException) { false }

    private fun applyAndLaunch(json: String, pkg: String): String {
        if (!Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$").matches(pkg)) return fail("invalid_package")
        val cfg = try { JSONObject(json) } catch (e: Exception) { JSONObject() }
        val intent = buildLaunchIntent(pkg) ?: return fail(if (isPackageKnown(pkg)) "no_launch_intent" else "not_installed")

        // pengaturan jendela DolaStrap sendiri
        if (cfg.optBoolean("fpsOn", false) || cfg.optBoolean("fpsBoost", false)) {
            requestRefreshRate(if (cfg.optBoolean("fpsBoost", false)) 120f else cfg.optInt("fps", 60).toFloat())
        }
        if (cfg.optBoolean("wakeLock", false) || cfg.optBoolean("antilag", false)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        if (cfg.optBoolean("antilag", false)) acquireLowLatencyWifi()

        // boost sistem yang berlaku juga untuk game
        restoreSystem()
        val applied = JSONArray()
        val skipped = JSONArray()
        applySystem(cfg, applied, skipped)

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        intent.putExtra("dolastrap_config", json)
        return try {
            startActivity(intent)
            JSONObject().put("ok", true).put("applied", applied).put("skipped", skipped).toString()
        } catch (e: Exception) {
            restoreSystem()
            fail("start_failed")
        }
    }

    // ================= boost sistem (berlaku untuk semua aplikasi, termasuk game) =================
    private fun applySystem(cfg: JSONObject, applied: JSONArray, skipped: JSONArray) {
        val cr = contentResolver
        val ed = prefs.edit()
        var any = false
        val canW = Settings.System.canWrite(this)

        if (cfg.optBoolean("sysRefresh", false)) {
            if (!canW) skipped.put("refresh: butuh izin") else try {
                ed.putFloat("p_peak", Settings.System.getFloat(cr, "peak_refresh_rate", 0f))
                ed.putFloat("p_min", Settings.System.getFloat(cr, "min_refresh_rate", 0f))
                val a = Settings.System.putFloat(cr, "peak_refresh_rate", 120f)
                val b = Settings.System.putFloat(cr, "min_refresh_rate", 120f)
                if (a || b) { applied.put("refresh"); ed.putBoolean("a_ref", true); any = true }
                else skipped.put("refresh: ditolak sistem")
            } catch (e: Exception) { skipped.put("refresh: tidak didukung HP ini") }
        }
        if (cfg.optBoolean("sysBright", false)) {
            if (!canW) skipped.put("kecerahan: butuh izin") else try {
                ed.putInt("p_bri", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128))
                ed.putInt("p_mode", Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, 1))
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, cfg.optInt("bright", 100).coerceIn(10, 100) * 255 / 100)
                applied.put("kecerahan"); ed.putBoolean("a_bri", true); any = true
            } catch (e: Exception) { skipped.put("kecerahan: ditolak") }
        }
        if (cfg.optBoolean("sysDnd", false)) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!nm.isNotificationPolicyAccessGranted) skipped.put("fokus: butuh izin") else try {
                ed.putInt("p_dnd", nm.currentInterruptionFilter)
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
                applied.put("fokus"); ed.putBoolean("a_dnd", true); any = true
            } catch (e: Exception) { skipped.put("fokus: ditolak") }
        }
        ed.putBoolean("applied", any).apply()
    }

    private fun restoreSystem() {
        if (!prefs.getBoolean("applied", false)) return
        val cr = contentResolver
        try {
            if (prefs.getBoolean("a_ref", false)) {
                Settings.System.putFloat(cr, "peak_refresh_rate", prefs.getFloat("p_peak", 0f))
                Settings.System.putFloat(cr, "min_refresh_rate", prefs.getFloat("p_min", 0f))
            }
            if (prefs.getBoolean("a_bri", false)) {
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, prefs.getInt("p_mode", 1))
                Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, prefs.getInt("p_bri", 128))
            }
            if (prefs.getBoolean("a_dnd", false)) {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.setInterruptionFilter(prefs.getInt("p_dnd", NotificationManager.INTERRUPTION_FILTER_ALL))
            }
        } catch (e: Exception) { }
        prefs.edit().clear().apply()
    }

    /** Hanya untuk jendela DolaStrap, bukan game. */
    @Suppress("DEPRECATION")
    private fun requestRefreshRate(target: Float) {
        val display = windowManager.defaultDisplay
        val best = display.supportedModes.filter { it.refreshRate >= target - 1f }.minByOrNull { it.refreshRate }
            ?: display.supportedModes.maxByOrNull { it.refreshRate } ?: return
        val lp = window.attributes
        lp.preferredDisplayModeId = best.modeId
        window.attributes = lp
    }

    private fun acquireLowLatencyWifi() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock?.takeIf { it.isHeld }?.release()
            wifiLock = wm.createWifiLock(mode, "dolastrap").also { it.acquire() }
        } catch (e: Exception) { }
    }
}
