package com.dolastrap.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

/**
 * Contoh WebView untuk DolaStrap.
 * Salin isi folder DolaStrap (index.html, css, js, assets) ke app/src/main/assets/
 * lalu ganti MAMOBALL_PACKAGE dengan package name asli (dari link Play Store: ?id=...).
 *
 * Yang benar-benar dilakukan kode ini:
 *  - membuka Mamoball lewat package name
 *  - meminta refresh rate tinggi untuk jendela DolaStrap sendiri
 *  - menjaga layar tetap menyala dan meminta Wi-Fi mode latensi rendah selagi DolaStrap aktif
 *  - mengirim konfigurasi sebagai extra "dolastrap_config" (Mamoball tidak membacanya)
 *
 * Yang TIDAK bisa dilakukan: mengubah FPS, grafis, hitbox, atau fisika bola di dalam game orang lain.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val MAMOBALL_PACKAGE = "com.GANTI.mamoball"
    }

    private lateinit var web: WebView
    private var wifiLock: WifiManager.WifiLock? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        // tombol back: biarkan HTML menutup layar Setting/Preset dulu
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.DolaBack && DolaBack()") { handled ->
                    if (handled != "true") finish()
                }
            }
        })
    }

    inner class Bridge {
        @JavascriptInterface
        fun launchGame(json: String) {
            runOnUiThread { applyAndLaunch(json) }
        }
    }

    private fun applyAndLaunch(json: String) {
        val cfg = try { JSONObject(json) } catch (e: Exception) { JSONObject() }

        if (cfg.optBoolean("fpsOn", false) || cfg.optBoolean("fpsBoost", false)) {
            val target = if (cfg.optBoolean("fpsBoost", false)) 120 else cfg.optInt("fps", 60)
            requestRefreshRate(target.toFloat())
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (cfg.optBoolean("antilag", false)) acquireLowLatencyWifi()

        val intent = packageManager.getLaunchIntentForPackage(MAMOBALL_PACKAGE)
        if (intent == null) {
            Toast.makeText(this, "Mamoball belum terpasang", Toast.LENGTH_LONG).show()
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$MAMOBALL_PACKAGE")))
            return
        }
        intent.putExtra("dolastrap_config", json)
        startActivity(intent)
    }

    /** Hanya berlaku untuk jendela DolaStrap, bukan untuk game. */
    @Suppress("DEPRECATION")
    private fun requestRefreshRate(target: Float) {
        val display = windowManager.defaultDisplay
        val best = display.supportedModes
            .filter { it.refreshRate >= target - 1f }
            .minByOrNull { it.refreshRate }
            ?: display.supportedModes.maxByOrNull { it.refreshRate }
            ?: return
        val lp = window.attributes
        lp.preferredDisplayModeId = best.modeId
        window.attributes = lp
    }

    /** Butuh izin ACCESS_WIFI_STATE dan WAKE_LOCK di manifest. */
    private fun acquireLowLatencyWifi() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val mode = if (Build.VERSION.SDK_INT >= 29)
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock?.takeIf { it.isHeld }?.release()
            wifiLock = wm.createWifiLock(mode, "dolastrap").also { it.acquire() }
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        wifiLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }
}
