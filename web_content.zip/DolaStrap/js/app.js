/* DolaStrap v3 - logika launcher */
(() => {
  'use strict';

  // Package default. Bisa diubah dari menu PROFIL tanpa build ulang (atau tekan DETEKSI di APK).
  const PKG_DEFAULT = 'com.GANTI.mamoball';

  const K = { cfg: 'dolastrap.v3', hist: 'dolastrap.hist', slots: 'dolastrap.slots' };
  const THEMES = {
    cyan:    { a: '#00f0ff', ar: '0,240,255',  a2: '#ff2bd6', ar2: '255,43,214' },
    magenta: { a: '#ff2bd6', ar: '255,43,214', a2: '#8a2bff', ar2: '138,43,255' },
    lime:    { a: '#39ff14', ar: '57,255,20',  a2: '#00f0ff', ar2: '0,240,255' },
    orange:  { a: '#ff8a00', ar: '255,138,0',  a2: '#ff2b64', ar2: '255,43,100' }
  };
  const DEF = {
    theme: 'cyan', pkg: '',
    fpsBoost: false, fpsOn: true, fps: 60, antilag: true,
    qualOn: true, quality: 'Sedang', gfxOn: true, graphic: 'Balanced',
    wakeLock: false, batterySaver: false, fpsMeter: false,
    kickAnim: true, blackhole: true, bgFx: true,
    sound: true, vol: 70, haptic: true, confirmLaunch: false,
    sysRefresh: false, sysBright: false, bright: 100, sysDnd: false,
    fastshoot: false, smoothball: false
  };
  const PERF = {
    hemat:    { fpsBoost: true,  fpsOn: true, fps: 30,  qualOn: true, quality: 'Rendah', gfxOn: true, graphic: 'Smooth',   bgFx: false, blackhole: false },
    seimbang: { fpsBoost: false, fpsOn: true, fps: 60,  qualOn: true, quality: 'Sedang', gfxOn: true, graphic: 'Balanced', bgFx: true,  blackhole: true },
    maks:     { fpsBoost: false, fpsOn: true, fps: 120, qualOn: true, quality: 'Tinggi', gfxOn: true, graphic: 'Ultra',    bgFx: true,  blackhole: true }
  };
  const TIPS = [
    'Pastikan koneksi stabil sebelum masuk lapangan.',
    'Cek ping di menu Tools sebelum bertanding.',
    'Atur sudut dulu, baru tendang.',
    'Tutup aplikasi lain supaya RAM lega.',
    'Latihan dulu sebelum main ranking.'
  ];
  const REASONS = {
    not_installed: 'Mamoball belum terpasang di perangkat ini.',
    invalid_package: 'Package name tidak valid. Periksa di menu PROFIL.',
    no_response: 'Tidak ada respons dari sistem. Package mungkin salah, atau Android memblokir intent dari browser.',
    bridge_error: 'Jembatan Android gagal dijalankan.',
    no_launch_intent: 'Mamoball terpasang tetapi tidak punya activity peluncur.',
    start_failed: 'Android menolak membuka aplikasi.'
  };

  // ---------- util ----------
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const ld = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
  const sv = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  const droid = () => (window.Android && window.Android.launchGame ? window.Android : null);
  const fmt = t => new Date(t).toLocaleString('id-ID', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

  let cfg = Object.assign({}, DEF, ld(K.cfg, {}));
  if (!THEMES[cfg.theme]) cfg.theme = 'cyan';
  let bat = null, busy = false, finished = false, lastLeave = 0, rec = null;
  const th = () => THEMES[cfg.theme];
  const save = () => { sv(K.cfg, cfg); render(); };

  // ---------- paket Mamoball ----------
  const getPkg = () => (cfg.pkg || PKG_DEFAULT).trim();
  const valid = p => /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z0-9_]+)+$/.test(p) && p.indexOf('GANTI') === -1;

  // ---------- level efek (benar-benar mengubah beban animasi launcher) ----------
  const saver = () => cfg.batterySaver && bat && bat.level <= 0.2 && !bat.charging;
  function fxEff() {
    if (cfg.fpsBoost || saver()) return 0;
    if (!cfg.gfxOn) return 1;
    return { Smooth: 1, Balanced: 2, Ultra: 3 }[cfg.graphic] || 2;
  }
  function dprFor() {
    if (fxEff() === 0) return 0.6;
    if (!cfg.qualOn) return 1;
    return { Rendah: 0.6, Sedang: 1, Tinggi: Math.min(window.devicePixelRatio || 1, 2) }[cfg.quality] || 1;
  }
  const fxo = () => ({ fx: fxEff(), dpr: dprFor(), ar: th().ar, a: th().a, ar2: th().ar2, a2: th().a2 });

  // ---------- suara & getar ----------
  let ac;
  const AC = () => { try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume(); return ac; } catch (e) { return null; } };
  const vol = () => cfg.vol / 100;
  function noise(c, dur) {
    const n = Math.floor(c.sampleRate * dur), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    const s = c.createBufferSource(); s.buffer = b; return s;
  }
  function tone(type, f0, f1, dur, g0) {
    if (!cfg.sound) return; const c = AC(); if (!c) return;
    const t = c.currentTime, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(g0 * vol(), t); g.gain.exponentialRampToValueAtTime(0.001, t + dur + 0.04);
    o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + dur + 0.05);
  }
  const Sfx = {
    click() { tone('square', 520, 480, 0.05, 0.06); },
    kick() {
      tone('sine', 190, 38, 0.28, 0.9);
      if (!cfg.sound) return; const c = AC(); if (!c) return; const t = c.currentTime;
      const n = noise(c, 0.1), f = c.createBiquadFilter(), g = c.createGain();
      f.type = 'lowpass'; f.frequency.value = 1400; g.gain.setValueAtTime(0.5 * vol(), t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      n.connect(f); f.connect(g); g.connect(c.destination); n.start(t);
    },
    whoosh() {
      if (!cfg.sound) return; const c = AC(); if (!c) return; const t = c.currentTime;
      const n = noise(c, 1.5), f = c.createBiquadFilter(), g = c.createGain();
      f.type = 'bandpass'; f.Q.value = 1.2; f.frequency.setValueAtTime(300, t); f.frequency.exponentialRampToValueAtTime(3500, t + 1.2);
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.35 * vol(), t + 0.3); g.gain.linearRampToValueAtTime(0, t + 1.4);
      n.connect(f); f.connect(g); g.connect(c.destination); n.start(t);
    },
    hole() { tone('sawtooth', 140, 30, 1.7, 0.22); tone('sine', 60, 25, 1.9, 0.5); }
  };
  const buzz = p => { if (cfg.haptic && navigator.vibrate) { try { navigator.vibrate(p); } catch (e) {} } };

  // ---------- toast & dialog ----------
  let tt;
  function toast(m) { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2800); }
  function dlg(title, msg, btns) {
    $('#dTitle').textContent = title; $('#dMsg').textContent = msg;
    const box = $('#dBtns'); box.innerHTML = '';
    btns.forEach(([label, fn, hot]) => {
      const b = document.createElement('button');
      b.textContent = label; b.className = 'act' + (hot ? ' hot' : '');
      b.onclick = () => { $('#dlg').classList.remove('on'); if (fn) fn(); };
      box.appendChild(b);
    });
    $('#dlg').classList.add('on');
  }

  // ---------- blackhole saat sesuatu dinyalakan ----------
  function bh(el) {
    if (!cfg.blackhole || !window.BlackHole) return;
    const r = el.getBoundingClientRect();
    window.BlackHole.play(r.left + r.width / 2, r.top + r.height / 2, fxo());
    Sfx.hole(); buzz([20, 40, 80, 40, 20]);
  }

  // ---------- FPS meter, wake lock, baterai ----------
  let mRaf = 0, lastMeter = null, lastWake = null, wl = null;
  function meter() {
    const el = $('#fps'); cancelAnimationFrame(mRaf);
    el.hidden = !cfg.fpsMeter; if (!cfg.fpsMeter) return;
    let f = 0, t = performance.now();
    (function loop(n) {
      f++; if (n - t >= 500) { el.textContent = Math.round(f * 1000 / (n - t)) + ' FPS'; f = 0; t = n; }
      mRaf = requestAnimationFrame(loop);
    })(t);
  }
  async function wake() {
    try {
      if (cfg.wakeLock && 'wakeLock' in navigator && !document.hidden && !wl) {
        wl = await navigator.wakeLock.request('screen'); wl.addEventListener('release', () => { wl = null; });
      } else if (!cfg.wakeLock && wl) { await wl.release(); wl = null; }
    } catch (e) {}
  }
  document.addEventListener('visibilitychange', () => { if (document.hidden) lastLeave = Date.now(); else wake(); });
  addEventListener('pagehide', () => { lastLeave = Date.now(); });
  addEventListener('blur', () => { lastLeave = Date.now(); });
  if (navigator.getBattery) navigator.getBattery().then(b => { bat = b; ['levelchange', 'chargingchange'].forEach(e => b.addEventListener(e, render)); render(); }).catch(() => {});

  // ---------- skema UI ----------
  const SET = [
    ['h', 'PERFORMA'],
    ['t', 'fpsBoost', 'FPS BOOST', 'Mode ringan: efek launcher dikurangi, resolusi render turun, dan refresh rate tinggi diminta ke aplikasi native.'],
    ['s', 'fpsOn', 'fps', 'TARGET FPS', 'Batas frame rate animasi launcher; dikirim juga ke native.', [[30, '30'], [60, '60'], [90, '90'], [120, '120']]],
    ['t', 'antilag', 'ANTILAG', 'Minta Wi-Fi latensi rendah (APK). Ukur hasilnya di menu Tools > Uji Koneksi.'],
    ['s', 'qualOn', 'quality', 'KUALITAS', 'Resolusi render animasi launcher.', [['Rendah', 'RENDAH'], ['Sedang', 'SEDANG'], ['Tinggi', 'TINGGI']]],
    ['s', 'gfxOn', 'graphic', 'GRAPHIC', 'Jumlah bintang, planet, dan partikel.', [['Smooth', 'SMOOTH'], ['Balanced', 'BALANCED'], ['Ultra', 'ULTRA']]],
    ['t', 'wakeLock', 'LAYAR TETAP MENYALA', 'Cegah layar mati selama DolaStrap terbuka.'],
    ['t', 'batterySaver', 'HEMAT BATERAI OTOMATIS', 'Efek dimatikan saat baterai 20% ke bawah dan tidak mengisi daya.'],
    ['t', 'fpsMeter', 'FPS METER', 'Tampilkan FPS launcher di pojok layar.'],
    ['h', 'EFEK & SUARA'],
    ['t', 'kickAnim', 'ANIMASI TENDANGAN', 'Matikan untuk langsung ke loading.'],
    ['t', 'blackhole', 'EFEK BLACKHOLE', 'Blackhole 2 detik tiap kali kamu menyalakan sesuatu.'],
    ['t', 'bgFx', 'LATAR NEON ANIMASI', 'Grid, orb, dan sinar di latar belakang.'],
    ['t', 'sound', 'SUARA', 'Efek klik, tendangan, whoosh, dan blackhole.'],
    ['r', 'vol', 'VOLUME', 0, 100, 5],
    ['t', 'haptic', 'GETAR', 'Getar saat tendangan dan blackhole.'],
    ['h', 'SISTEM (APK + IZIN) - IKUT BERLAKU DI MAMOBALL'],
    ['t', 'sysRefresh', 'REFRESH RATE TINGGI SISTEM', 'Paksa refresh rate tinggi di seluruh sistem selama main. Butuh izin (Tools > Izin Setelan); hasil tergantung merk HP.'],
    ['t', 'sysBright', 'KECERAHAN SAAT MAIN', 'Atur kecerahan layar saat Mamoball dibuka, dipulihkan saat kembali ke DolaStrap.'],
    ['r', 'bright', 'KECERAHAN', 10, 100, 5],
    ['t', 'sysDnd', 'MODE FOKUS (DND)', 'Bungkam notifikasi selama main (hanya alarm). Butuh izin Jangan Ganggu (Tools > Izin Fokus).'],
    ['h', 'LAINNYA'],
    ['t', 'confirmLaunch', 'KONFIRMASI MASUK', 'Tanya dulu sebelum membuka Mamoball.']
  ];
  const PRE = [
    ['t', 'fastshoot', 'FASTSHOOT', 'Profil tendangan kencang + fix hitbox. Disimpan sebagai konfigurasi dan dikirim saat launch.', 'BETA'],
    ['t', 'smoothball', 'SMOOTHBALL', 'Profil bola ringan dan mudah dikontrol. Disimpan sebagai konfigurasi dan dikirim saat launch.', 'BETA']
  ];
  function build(host, list) {
    let h = '';
    list.forEach(r => {
      const T = r[0];
      if (T === 'h') h += '<h4 class="sec">' + r[1] + '</h4>';
      else if (T === 't') h += '<div class="card" data-tg="' + r[1] + '"><div class="row"><div><h3>' + r[2] + (r[4] ? ' <em>' + r[4] + '</em>' : '') + '</h3><p>' + r[3] + '</p></div><button class="sw" role="switch" data-k="' + r[1] + '"></button></div></div>';
      else if (T === 's') h += '<div class="card" data-tg="' + r[1] + '"><div class="row"><div><h3>' + r[3] + '</h3><p>' + r[4] + '</p></div><button class="sw" role="switch" data-k="' + r[1] + '"></button></div><div class="seg" data-seg="' + r[2] + '">' + r[5].map(o => '<button data-v="' + o[0] + '">' + o[1] + '</button>').join('') + '</div></div>';
      else if (T === 'r') h += '<div class="card"><div class="row"><h3>' + r[2] + '</h3><span class="val" data-val="' + r[1] + '"></span></div><input type="range" data-r="' + r[1] + '" min="' + r[3] + '" max="' + r[4] + '" step="' + r[5] + '"></div>';
    });
    host.innerHTML = h;
  }
  build($('#p-settings'), SET);
  build($('#p-preset'), PRE);

  // ---------- render ----------
  function chipsHTML() {
    const a = [];
    if (cfg.fpsBoost) a.push('FPS BOOST');
    if (saver()) a.push('HEMAT BATERAI');
    if (cfg.fpsOn) a.push('FPS ' + cfg.fps);
    if (cfg.antilag) a.push('ANTILAG');
    if (cfg.qualOn) a.push(cfg.quality.toUpperCase());
    if (cfg.gfxOn) a.push(cfg.graphic.toUpperCase());
    if (cfg.fastshoot) a.push('FASTSHOOT');
    if (cfg.smoothball) a.push('SMOOTHBALL');
    return a.length ? a.map(x => '<b>' + x + '</b>').join('') : '<b>SEMUA OFF</b>';
  }
  function histText() {
    const h = ld(K.hist, []), ok = h.filter(x => x.ok).length;
    if (!h.length) return '';
    return 'Total: ' + h.length + ' (berhasil ' + ok + ', gagal ' + (h.length - ok) + ')\n' +
      h.slice(-6).reverse().map(x => fmt(x.t) + (x.ok ? ' OK  ' : ' GAGAL ') + x.pkg + (x.note ? ' [' + x.note + ']' : '')).join('\n');
  }
  function render() {
    $$('.sw').forEach(e => { const on = !!cfg[e.dataset.k]; e.classList.toggle('on', on); e.setAttribute('aria-checked', on); });
    $$('[data-seg]').forEach(g => [...g.children].forEach(b => b.classList.toggle('on', String(cfg[g.dataset.seg]) === b.dataset.v)));
    $$('.card[data-tg]').forEach(c => c.classList.toggle('off', !cfg[c.dataset.tg]));
    $$('input[data-r]').forEach(i => { i.value = cfg[i.dataset.r]; $('[data-val="' + i.dataset.r + '"]').textContent = cfg[i.dataset.r] + '%'; });
    $('#chips').innerHTML = chipsHTML();
    document.body.className = 'fx' + fxEff() + ' th-' + cfg.theme + (cfg.bgFx ? '' : ' nobg');
    if (document.activeElement !== $('#pkgIn')) $('#pkgIn').value = cfg.pkg || '';
    const sl = ld(K.slots, {});
    [1, 2, 3].forEach(n => { $('#sl' + n).textContent = 'SLOT ' + n + ' - ' + (sl[n] ? fmt(sl[n].t) : 'kosong'); });
    $('#out-hist').textContent = histText();
    if (lastMeter !== cfg.fpsMeter) { lastMeter = cfg.fpsMeter; meter(); }
    if (lastWake !== cfg.wakeLock) { lastWake = cfg.wakeLock; wake(); }
  }

  // ---------- navigasi & event ----------
  let cur = 'home';
  function go(id) { $$('[data-screen]').forEach(s => s.classList.toggle('on', s.id === id)); cur = id; Sfx.click(); }
  window.DolaBack = () => {
    if ($('#dlg').classList.contains('on')) { $('#dlg').classList.remove('on'); return true; }
    if (cur !== 'home') { go('home'); return true; }
    return false;
  };

  document.addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const g = b.parentNode && b.parentNode.dataset && b.parentNode.dataset.seg;
    if (b.dataset.k) {
      cfg[b.dataset.k] = !cfg[b.dataset.k]; Sfx.click(); save(); if (cfg[b.dataset.k]) bh(b);
    } else if (g) {
      cfg[g] = g === 'fps' ? +b.dataset.v : b.dataset.v; Sfx.click(); save();
    } else if (b.dataset.go) go(b.dataset.go);
    else if (b.dataset.act && ACT[b.dataset.act]) { Sfx.click(); ACT[b.dataset.act](b); }
  });
  document.addEventListener('input', e => {
    const r = e.target.dataset && e.target.dataset.r;
    if (r) { cfg[r] = +e.target.value; sv(K.cfg, cfg); $('[data-val="' + r + '"]').textContent = cfg[r] + '%'; }
  });
  document.addEventListener('change', e => { if (e.target.dataset && e.target.dataset.r) Sfx.click(); });

  // ---------- aksi (Preset, Tools, Profil) ----------
  const out = (id, t) => { $('#out-' + id).textContent = t; };
  function copy(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text).then(() => true, () => false);
    const t = document.createElement('textarea'); t.value = text; document.body.appendChild(t); t.select();
    let ok = false; try { ok = document.execCommand('copy'); } catch (e) {} t.remove(); return Promise.resolve(ok);
  }
  function exportable() { const c = Object.assign({}, cfg); delete c.pkg; return c; }
  function mergeKnown(src) {
    let n = 0;
    Object.keys(DEF).forEach(k => { if (k !== 'pkg' && k in src && typeof src[k] === typeof DEF[k]) { cfg[k] = src[k]; n++; } });
    if (!THEMES[cfg.theme]) cfg.theme = 'cyan'; return n;
  }

  const ACT = {
    preset(b) { Object.assign(cfg, PERF[b.dataset.v]); save(); bh(b); toast('Preset ' + b.textContent + ' diterapkan'); },

    async ping(b) {
      b.disabled = true; out('ping', 'Mengukur...'); const r = [];
      for (let i = 0; i < 5; i++) {
        const t = performance.now();
        try { await fetch('https://www.gstatic.com/generate_204?' + Math.random(), { mode: 'no-cors', cache: 'no-store' }); r.push(performance.now() - t); } catch (e) {}
        await sleep(150);
      }
      b.disabled = false;
      if (!r.length) return out('ping', 'Gagal: tidak ada koneksi atau akses diblokir.');
      const avg = Math.round(r.reduce((a, c) => a + c, 0) / r.length), mn = Math.round(Math.min(...r)), mx = Math.round(Math.max(...r));
      const nilai = avg < 50 ? 'SANGAT BAGUS' : avg < 100 ? 'BAGUS' : avg < 180 ? 'CUKUP - aktifkan Antilag' : 'BURUK - pindah ke Wi-Fi yang lebih stabil';
      out('ping', 'Rata-rata : ' + avg + ' ms\nMin / Max : ' + mn + ' / ' + mx + ' ms\nJitter    : ' + (mx - mn) + ' ms\nSukses    : ' + r.length + '/5\nNilai     : ' + nilai);
    },

    async bench(b) {
      b.disabled = true; $('#applyRec').classList.add('hide'); out('bench', 'Menguji 3 detik...');
      const res = await new Promise(done => {
        const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d');
        let f = 0, worst = 0; const t0 = performance.now(); let last = t0;
        (function l(n) {
          f++; worst = Math.max(worst, n - last); last = n;
          for (let i = 0; i < 300; i++) { x.fillStyle = 'hsl(' + ((i * 7 + f * 5) % 360) + ',100%,50%)'; x.beginPath(); x.arc(Math.random() * 256, Math.random() * 256, 10 + Math.random() * 20, 0, 6.28); x.fill(); }
          if (n - t0 < 3000) requestAnimationFrame(l); else done({ fps: Math.round(f * 1000 / (n - t0)), worst: Math.round(worst) });
        })(t0);
      });
      b.disabled = false;
      rec = res.fps < 25 ? { n: 'HEMAT', p: PERF.hemat } : res.fps < 45 ? { n: 'SEIMBANG RINGAN', p: Object.assign({}, PERF.seimbang, { quality: 'Sedang', graphic: 'Smooth', fps: 60 }) } : res.fps < 58 ? { n: 'SEIMBANG', p: PERF.seimbang } : { n: 'MAKSIMAL', p: PERF.maks };
      out('bench', 'FPS rata-rata : ' + res.fps + '\nFrame terlama : ' + res.worst + ' ms\nSaran preset  : ' + rec.n);
      $('#applyRec').classList.remove('hide');
    },
    applyrec(b) { if (!rec) return; Object.assign(cfg, rec.p); save(); bh(b); toast('Saran diterapkan: ' + rec.n); },

    async info() {
      const n = navigator, c = n.connection || {}; let bt = 'tidak didukung';
      try { if (n.getBattery) { const b = await n.getBattery(); bt = Math.round(b.level * 100) + '% (' + (b.charging ? 'mengisi' : 'tidak mengisi') + ')'; } } catch (e) {}
      out('info', 'Layar     : ' + screen.width + 'x' + screen.height + ' @' + (devicePixelRatio || 1) + 'x\nViewport  : ' + innerWidth + 'x' + innerHeight +
        '\nCPU core  : ' + (n.hardwareConcurrency || '?') + '\nRAM       : ' + (n.deviceMemory ? '~' + n.deviceMemory + ' GB' : '?') +
        '\nJaringan  : ' + (c.effectiveType || '?') + (c.downlink ? ', ' + c.downlink + ' Mbps' : '') + (c.saveData ? ', hemat data' : '') +
        '\nBaterai   : ' + bt + '\nBahasa    : ' + n.language + '\nWake Lock : ' + ('wakeLock' in n ? 'ya' : 'tidak') +
        '\nGetar     : ' + ('vibrate' in n ? 'ya' : 'tidak') + '\nAPK bridge: ' + (droid() ? 'ada' : 'tidak (mode browser)'));
    },

    check() {
      const p = getPkg(), a = droid(); let t = 'Package : ' + p + '\nFormat  : ' + (valid(p) ? 'valid' : 'TIDAK valid');
      if (valid(p)) t += a && a.isInstalled ? '\nTerpasang: ' + (a.isInstalled(p) ? 'YA' : 'TIDAK') : '\nTerpasang: tidak bisa dicek di browser (butuh APK)';
      out('check', t); checkStatus();
    },

    pick() {
      const a = droid(); if (!a || !a.listApps) return toast('Butuh aplikasi native (APK)');
      let all = []; try { all = JSON.parse(a.listApps()); } catch (e) {}
      const m = all.filter(x => /mamo|ball|bola|soccer|football|sepak/i.test(x.l + ' ' + x.p)).slice(0, 5);
      if (!m.length) return dlg('TIDAK DITEMUKAN', 'Tidak ada aplikasi bola/mamo yang terlihat (' + all.length + ' aplikasi terlihat). Jika angkanya sangat kecil, blok <queries> di manifest belum benar. Atau ketik package manual.', [['TUTUP']]);
      dlg('PILIH APLIKASI', 'Ketuk aplikasi yang benar:', m.map(x => [x.l + ' (' + x.p + ')', () => { cfg.pkg = x.p; save(); checkStatus(); toast('Dipilih: ' + x.p); }, true]).concat([['BATAL']]));
    },
    diag() {
      const a = droid();
      if (!a || !a.diag) return out('diag', 'Jembatan Android: TIDAK ADA\nDibuka dari browser atau wrapper tanpa jembatan.\nDeteksi otomatis dan boost sistem tidak aktif.\nMembuka Mamoball memakai intent (kurang andal). Pakai proyek di folder android/ untuk hasil terbaik.');
      let d; try { d = JSON.parse(a.diag(getPkg())); } catch (e) { return out('diag', 'Diagnosa gagal dibaca'); }
      out('diag', 'Jembatan    : ADA\nHP          : ' + d.model + ' (SDK ' + d.sdk + ')\nApp terlihat: ' + d.visibleApps + (d.visibleApps < 5 ? '  <- terlalu sedikit, cek <queries>' : '') +
        '\nPackage     : ' + getPkg() + '\nTerpasang   : ' + (d.installed ? 'YA' : d.known ? 'ada, tanpa activity peluncur' : 'TIDAK') +
        '\nIzin setelan: ' + (d.writeSettings ? 'ya' : 'belum') + '\nIzin fokus  : ' + (d.dnd ? 'ya' : 'belum'));
    },
    permw() { const a = droid(); if (a && a.askWriteSettings) a.askWriteSettings(); else toast('Butuh aplikasi native (APK)'); },
    permd() { const a = droid(); if (a && a.askDnd) a.askDnd(); else toast('Butuh aplikasi native (APK)'); },
    restore() { const a = droid(); if (a && a.restoreSystem) { a.restoreSystem(); toast('Setelan sistem dipulihkan'); } else toast('Butuh aplikasi native (APK)'); },

    savepkg() {
      const v = $('#pkgIn').value.trim();
      if (!valid(v)) return toast('Format package tidak valid');
      cfg.pkg = v; save(); checkStatus(); toast('Package disimpan');
    },
    detect() {
      const a = droid();
      if (!a || !a.findPackage) return toast('Deteksi butuh aplikasi native (APK)');
      const r = a.findPackage('mamo');
      if (!r) return toast('Mamoball tidak ditemukan di perangkat');
      cfg.pkg = r; save(); checkStatus(); toast('Terdeteksi: ' + r);
    },

    slotsave(b) { const s = ld(K.slots, {}); s[b.dataset.v] = { t: Date.now(), c: exportable() }; sv(K.slots, s); render(); toast('Disimpan ke slot ' + b.dataset.v); },
    slotload(b) {
      const s = ld(K.slots, {})[b.dataset.v]; if (!s) return toast('Slot ' + b.dataset.v + ' masih kosong');
      mergeKnown(s.c); save(); bh(b); toast('Slot ' + b.dataset.v + ' dimuat');
    },
    async export() { const t = JSON.stringify(exportable()); $('#cfgTxt').value = t; toast((await copy(t)) ? 'Setting disalin' : 'Salin manual dari kotak teks'); },
    import() {
      try { const n = mergeKnown(JSON.parse($('#cfgTxt').value)); if (!n) return toast('Tidak ada setting yang cocok'); save(); toast(n + ' setting diimpor'); }
      catch (e) { toast('JSON tidak valid'); }
    },
    clearhist() { sv(K.hist, []); render(); toast('Riwayat dihapus'); },
    reset() {
      dlg('RESET SEMUA?', 'Semua setting kembali ke awal. Package Mamoball tetap disimpan.', [
        ['RESET', () => { const p = cfg.pkg; cfg = Object.assign({}, DEF, { pkg: p }); save(); toast('Setting direset'); }, true], ['BATAL']]);
    }
  };

  // ---------- status Mamoball di home ----------
  function checkStatus() {
    const el = $('#status'), p = getPkg(), a = droid();
    if (!valid(p)) { el.className = 'status bad'; el.textContent = 'PACKAGE BELUM DIISI - BUKA PROFIL'; return; }
    if (a && a.isInstalled) { const ok = a.isInstalled(p); el.className = 'status ' + (ok ? 'ok' : 'bad'); el.textContent = ok ? 'MAMOBALL TERPASANG' : 'MAMOBALL BELUM TERPASANG'; }
    else { el.className = 'status'; el.textContent = 'MODE BROWSER - ' + p; }
  }

  // ---------- tendang -> loading -> launch ----------
  function begin() {
    if (busy) return; Sfx.click();
    if (!valid(getPkg())) {
      dlg('PACKAGE BELUM DIISI', 'Isi package name Mamoball di menu PROFIL, atau tekan DETEKSI jika memakai APK.', [['ATUR PACKAGE', () => go('profil'), true], ['BATAL']]); return;
    }
    const a = droid();
    if (a && a.isInstalled && !a.isInstalled(getPkg())) {
      dlg('MAMOBALL BELUM TERPASANG', 'Aplikasi dengan package ' + getPkg() + ' tidak ditemukan di perangkat ini.', [['BUKA PLAY STORE', openStore, true], ['ATUR PACKAGE', () => go('profil')], ['BATAL']]); return;
    }
    if (cfg.confirmLaunch) dlg('MASUK MAMOBALL?', 'Setting aktif akan dikirim saat membuka game.', [['MASUK', run, true], ['BATAL']]);
    else run();
  }
  function run() {
    busy = true;
    if (!cfg.kickAnim) return loading();
    const r = $('#ballBtn .ballsvg').getBoundingClientRect();
    window.Kick.play(Object.assign(fxo(), {
      fps: cfg.fpsOn ? cfg.fps : 0, from: { x: r.left + r.width / 2, y: r.top + r.height / 2, s: r.width },
      onHit() { Sfx.kick(); buzz([40, 30, 90]); }, onFly() { Sfx.whoosh(); }
    }), loading);
  }
  $('#ballBtn').addEventListener('click', begin);

  function loading() {
    const L = $('#load'); L.classList.add('on');
    $('#lChips').innerHTML = chipsHTML(); $('#lTip').textContent = TIPS[Math.floor(Math.random() * TIPS.length)];
    const fill = $('#lbFill'), bi = $('#lbBall'), step = $('#lStep'); let p = 0;
    fill.style.width = '0%'; bi.style.left = '0%';
    const steps = [[0, 'MENYIAPKAN KONFIGURASI'], [25, 'MENERAPKAN SETTING'], [55, 'MEMUAT PRESET'], [85, 'MEMBUKA MAMOBALL']];
    const iv = setInterval(() => {
      p = Math.min(100, p + Math.random() * 13 + 5); fill.style.width = p + '%'; bi.style.left = p + '%';
      step.textContent = steps.slice().reverse().filter(x => p >= x[0])[0][1] + '...';
      if (p >= 100) { clearInterval(iv); setTimeout(launch, 450); }
    }, fxEff() === 0 ? 200 : 260);
  }

  function backHome() { $('#load').classList.remove('on'); busy = false; go('home'); checkStatus(); }
  function openStore() {
    const a = droid(), p = getPkg();
    if (a && a.openStore) a.openStore(p); else location.href = 'https://play.google.com/store/apps/details?id=' + p;
  }
  function parseRes(r) {
    if (r === undefined || r === null || r === '') return { ok: true, unknown: true };
    if (typeof r === 'object') return r;
    try { return JSON.parse(r); } catch (e) { return { ok: r === 'ok' || r === 'true', reason: r }; }
  }
  function finish(res) {
    if (finished) return; finished = true;
    const h = ld(K.hist, []); h.push({ t: Date.now(), ok: !!res.ok, pkg: getPkg(), note: res.ok ? (res.applied || []).join('+') : (res.reason || '') });
    sv(K.hist, h.slice(-20)); render();
    if (res.ok) {
      $('#lStep').textContent = 'MAMOBALL TERBUKA' + (res.applied && res.applied.length ? ' - AKTIF: ' + res.applied.join(', ').toUpperCase() : '');
      if (res.skipped && res.skipped.length) toast('Dilewati: ' + res.skipped.join('; '));
      setTimeout(backHome, 2200); return;
    }
    $('#lStep').textContent = 'GAGAL MEMBUKA MAMOBALL';
    dlg('GAGAL MASUK', REASONS[res.reason] || ('Penyebab: ' + (res.reason || 'tidak diketahui')), [
      ['ULANGI', () => { $('#lStep').textContent = 'MEMBUKA MAMOBALL...'; launch(); }, true],
      ['BUKA PLAY STORE', () => { openStore(); backHome(); }],
      ['SALIN PACKAGE', () => { copy(getPkg()); backHome(); toast('Package disalin'); }],
      ['ATUR PACKAGE', () => { backHome(); go('profil'); }],
      ['TUTUP', backHome]
    ]);
  }
  window.onDolaLaunch = j => finish(parseRes(j)); // callback async dari native

  const wv = /; wv\)/.test(navigator.userAgent);
  const intentUrl = p => 'intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=' + p +
    ';S.browser_fallback_url=' + encodeURIComponent('https://play.google.com/store/apps/details?id=' + p) + ';end';
  // Di WebView tanpa jembatan, intent lewat iframe tersembunyi agar halaman utama tidak tertimpa halaman error.
  function openIntent(url) {
    if (wv) { const f = document.createElement('iframe'); f.style.display = 'none'; f.src = url; document.body.appendChild(f); setTimeout(() => f.remove(), 4000); }
    else location.href = url;
  }

  function launch() {
    finished = false; const p = getPkg(), a = droid();
    const payload = JSON.stringify(Object.assign({ app: 'DolaStrap', v: 3 }, cfg, { pkg: p }));
    if (!valid(p)) return finish({ ok: false, reason: 'invalid_package' });
    if (a) {
      let r; try { r = parseRes(a.launchGame(payload, p)); } catch (e) { r = { ok: false, reason: 'bridge_error' }; }
      return finish(r);
    }
    // Tanpa jembatan: Android hanya mengizinkan intent dari ketukan langsung, jadi minta ketukan baru.
    $('#lStep').textContent = 'TEKAN MASUK UNTUK MEMBUKA MAMOBALL';
    dlg('SIAP MASUK', 'Android hanya mengizinkan membuka aplikasi dari ketukan langsung. Tekan tombol di bawah.', [
      ['MASUK MAMOBALL', () => {
        const t0 = Date.now(); lastLeave = 0; openIntent(intentUrl(p));
        setTimeout(() => finish(lastLeave >= t0 ? { ok: true } : { ok: false, reason: 'no_response' }), 3200);
      }, true],
      ['BATAL', backHome]
    ]);
  }

  // ---------- mulai ----------
  render(); checkStatus();
  const a0 = droid();
  if (a0 && a0.findPackage && !valid(getPkg())) {
    const r = a0.findPackage('mamo');
    if (r) { cfg.pkg = r; save(); checkStatus(); setTimeout(() => toast('Mamoball terdeteksi: ' + r), 600); }
  }
})();
