/* DolaStrap - logika launcher */
(function () {
  'use strict';

  // ====== GANTI dengan package name Mamoball (dari link Play Store: ...?id=PACKAGE) ======
  var PACKAGE = 'com.GANTI.mamoball';
  // ======================================================================================

  var KEY = 'dolastrap.v2';
  var DEF = {
    fpsBoost: false, fpsOn: true, fps: 60, antilag: true,
    qualOn: true, quality: 'Sedang', gfxOn: true, graphic: 'Balanced',
    fpsMeter: false, sound: true, haptic: true,
    fastshoot: false, smoothball: false
  };
  var TIPS = [
    'Pastikan koneksi stabil sebelum masuk lapangan.',
    'Kurangi efek grafis kalau game terasa berat.',
    'Atur sudut dulu, baru tendang.',
    'Tutup aplikasi lain supaya RAM lega.',
    'Latihan dulu sebelum main ranking.'
  ];

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var cfg;
  try { cfg = Object.assign({}, DEF, JSON.parse(localStorage.getItem(KEY) || '{}')); } catch (e) { cfg = Object.assign({}, DEF); }

  function save() { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (e) {} render(); }

  // ---------- suara & getar ----------
  var ac;
  function AC() {
    try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); if (ac.state === 'suspended') ac.resume(); return ac; }
    catch (e) { return null; }
  }
  function noise(c, dur) {
    var n = Math.floor(c.sampleRate * dur), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0), i;
    for (i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    var s = c.createBufferSource(); s.buffer = b; return s;
  }
  var Sfx = {
    click: function () {
      if (!cfg.sound) return; var c = AC(); if (!c) return;
      var o = c.createOscillator(), g = c.createGain(), t = c.currentTime;
      o.type = 'square'; o.frequency.value = 520;
      g.gain.setValueAtTime(0.05, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.06);
      o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + 0.07);
    },
    kick: function () {
      if (!cfg.sound) return; var c = AC(); if (!c) return;
      var t = c.currentTime, o = c.createOscillator(), g = c.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(190, t); o.frequency.exponentialRampToValueAtTime(38, t + 0.28);
      g.gain.setValueAtTime(0.9, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.34);
      o.connect(g); g.connect(c.destination); o.start(t); o.stop(t + 0.36);
      var n = noise(c, 0.1), f = c.createBiquadFilter(), ng = c.createGain();
      f.type = 'lowpass'; f.frequency.value = 1400;
      ng.gain.setValueAtTime(0.5, t); ng.gain.exponentialRampToValueAtTime(0.001, t + 0.1);
      n.connect(f); f.connect(ng); ng.connect(c.destination); n.start(t);
    },
    whoosh: function () {
      if (!cfg.sound) return; var c = AC(); if (!c) return;
      var t = c.currentTime, n = noise(c, 1.5), f = c.createBiquadFilter(), g = c.createGain();
      f.type = 'bandpass'; f.Q.value = 1.2;
      f.frequency.setValueAtTime(300, t); f.frequency.exponentialRampToValueAtTime(3500, t + 1.2);
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.35, t + 0.3); g.gain.linearRampToValueAtTime(0, t + 1.4);
      n.connect(f); f.connect(g); g.connect(c.destination); n.start(t);
    }
  };
  function buzz(p) { if (cfg.haptic && navigator.vibrate) { try { navigator.vibrate(p); } catch (e) {} } }

  // ---------- toast ----------
  var tt;
  function toast(m) { var t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(function () { t.classList.remove('on'); }, 2800); }

  // ---------- efek launcher (ini benar-benar berefek ke animasi launcher) ----------
  function fxLevel() {
    if (cfg.fpsBoost) return 0;
    if (!cfg.gfxOn) return 1;
    return { Smooth: 1, Balanced: 2, Ultra: 3 }[cfg.graphic] || 2;
  }
  function dprFor() {
    if (cfg.fpsBoost) return 0.6;
    if (!cfg.qualOn) return 1;
    return { Rendah: 0.6, Sedang: 1, Tinggi: Math.min(window.devicePixelRatio || 1, 2) }[cfg.quality] || 1;
  }

  // ---------- FPS meter ----------
  var mRaf = 0;
  function meter() {
    var el = $('#fps'); cancelAnimationFrame(mRaf);
    el.hidden = !cfg.fpsMeter; if (!cfg.fpsMeter) return;
    var frames = 0, t = performance.now();
    (function loop(n) {
      frames++;
      if (n - t >= 500) { el.textContent = Math.round(frames * 1000 / (n - t)) + ' FPS'; frames = 0; t = n; }
      mRaf = requestAnimationFrame(loop);
    })(t);
  }

  // ---------- render UI ----------
  function activeList() {
    var a = [];
    if (cfg.fpsBoost) a.push('FPS BOOST');
    if (cfg.fpsOn) a.push('FPS ' + cfg.fps);
    if (cfg.antilag) a.push('ANTILAG');
    if (cfg.qualOn) a.push(cfg.quality.toUpperCase());
    if (cfg.gfxOn) a.push(cfg.graphic.toUpperCase());
    if (cfg.fastshoot) a.push('FASTSHOOT');
    if (cfg.smoothball) a.push('SMOOTHBALL');
    return a;
  }
  function chipsHTML() {
    var l = activeList();
    return l.length ? l.map(function (x) { return '<b>' + x + '</b>'; }).join('') : '<b>SEMUA OFF</b>';
  }
  var lastMeter = null;
  function render() {
    $$('.sw').forEach(function (e) { var on = !!cfg[e.dataset.k]; e.classList.toggle('on', on); e.setAttribute('aria-checked', on); });
    $$('[data-seg]').forEach(function (g) {
      var k = g.dataset.seg;
      Array.prototype.forEach.call(g.children, function (b) { b.classList.toggle('on', String(cfg[k]) === b.dataset.v); });
    });
    $$('.card[data-tg]').forEach(function (c) { c.classList.toggle('off', !cfg[c.dataset.tg]); });
    $('#chips').innerHTML = chipsHTML();
    document.body.className = 'fx' + fxLevel();
    if (lastMeter !== cfg.fpsMeter) { lastMeter = cfg.fpsMeter; meter(); }
  }

  // ---------- navigasi ----------
  var cur = 'home';
  function go(id) {
    $$('[data-screen]').forEach(function (s) { s.classList.toggle('on', s.id === id); });
    cur = id; Sfx.click();
  }
  window.DolaBack = function () { if (cur !== 'home') { go('home'); return true; } return false; };

  $$('[data-go]').forEach(function (b) { b.addEventListener('click', function () { go(b.dataset.go); }); });
  $$('.sw').forEach(function (e) { e.addEventListener('click', function () { cfg[e.dataset.k] = !cfg[e.dataset.k]; Sfx.click(); save(); }); });
  $$('[data-seg]').forEach(function (g) {
    Array.prototype.forEach.call(g.children, function (b) {
      b.addEventListener('click', function () {
        var k = g.dataset.seg; cfg[k] = k === 'fps' ? +b.dataset.v : b.dataset.v; Sfx.click(); save();
      });
    });
  });
  $('#resetBtn').addEventListener('click', function () { cfg = Object.assign({}, DEF); save(); toast('Setting dikembalikan ke awal'); });

  // ---------- tendang -> loading -> launch ----------
  var busy = false;
  $('#ballBtn').addEventListener('click', function () {
    if (busy) return; busy = true; Sfx.click();
    var r = $('#ballBtn .ballsvg').getBoundingClientRect();
    window.Kick.play({
      fx: fxLevel(), dpr: dprFor(), fps: cfg.fpsOn ? cfg.fps : 0,
      from: { x: r.left + r.width / 2, y: r.top + r.height / 2, s: r.width },
      onHit: function () { Sfx.kick(); buzz([40, 30, 90]); },
      onFly: function () { Sfx.whoosh(); }
    }, loading);
  });

  function loading() {
    var L = $('#load'); L.classList.add('on');
    $('#lChips').innerHTML = chipsHTML();
    $('#lTip').textContent = TIPS[Math.floor(Math.random() * TIPS.length)];
    var fill = $('#lbFill'), bi = $('#lbBall'), step = $('#lStep'), p = 0;
    var steps = [[0, 'MENYIAPKAN KONFIGURASI'], [25, 'MENERAPKAN SETTING'], [55, 'MEMUAT PRESET'], [85, 'MEMBUKA MAMOBALL']];
    var iv = setInterval(function () {
      p = Math.min(100, p + Math.random() * 13 + 5);
      fill.style.width = p + '%'; bi.style.left = p + '%';
      var s = steps.slice().reverse().filter(function (x) { return p >= x[0]; })[0];
      step.textContent = s[1] + '...';
      if (p >= 100) { clearInterval(iv); setTimeout(launch, 450); }
    }, cfg.fpsBoost ? 200 : 260);
  }

  function backHome() { $('#load').classList.remove('on'); go('home'); busy = false; }

  function launch() {
    var payload = JSON.stringify(Object.assign({ app: 'DolaStrap', v: 2 }, cfg));
    try {
      if (window.Android && window.Android.launchGame) { window.Android.launchGame(payload); }
      else if (window.DolaBridge && window.DolaBridge.launch) { window.DolaBridge.launch(payload); }
      else if (PACKAGE.indexOf('GANTI') !== -1) {
        $('#lStep').textContent = 'PACKAGE BELUM DIISI';
        toast('Isi PACKAGE di js/app.js (atau pakai jembatan Android)');
        setTimeout(backHome, 2200); return;
      } else { location.href = 'intent://#Intent;package=' + PACKAGE + ';end'; }
    } catch (e) {
      $('#lStep').textContent = 'GAGAL MEMBUKA GAME';
      setTimeout(backHome, 2200); return;
    }
    setTimeout(backHome, 3800);
  }

  render();
})();
