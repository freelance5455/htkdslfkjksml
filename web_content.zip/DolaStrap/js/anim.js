/* DolaStrap - adegan bola ditendang ke luar angkasa (gaya manga orisinal) */
(function () {
  'use strict';
  var $ = function (s) { return document.querySelector(s); };
  var clamp = function (v, a, b) { return Math.min(b === undefined ? 1 : b, Math.max(a === undefined ? 0 : a, v)); };
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };
  var easeIn = function (t) { return t * t; };
  var rnd = function (n) { var x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

  // waktu (ms): tarik kaki -> benturan -> meluncur -> whiteout
  var T = { wind: 600, hit: 820, fly: 2550, end: 3050 };

  var root, cv, ctx, ball, sfx, flash;
  var W, H, dpr, S, bx0, by0;
  var raf = 0, t0 = 0, last = 0, cb = null, o = null, running = false, fired = {};
  var stars = [], planets = [], lines = [], trail = [];
  var COLS = ['#1747ff', '#2fd0ff', '#7b5cff', '#0a3cff'];

  function init() {
    root = $('#kick'); cv = $('#cv'); ctx = cv.getContext('2d');
    ball = $('#flyball'); sfx = $('#sfx'); flash = $('#flash');
  }

  function newPlanet(i, first) {
    var r = 28 + Math.random() * 70;
    return {
      x: first ? Math.random() * W : W * (0.5 + Math.random() * 0.7),
      y: first ? Math.random() * H * 0.7 : -r * 2 - Math.random() * H * 0.4,
      r: r, z: 0.5 + Math.random(), c: COLS[i % COLS.length], ring: i === 0
    };
  }

  function seed() {
    var nS = [28, 60, 110, 170][o.fx], nP = [0, 1, 2, 3][o.fx], i;
    stars = []; planets = []; lines = []; trail = [];
    for (i = 0; i < nS; i++) stars.push({ x: Math.random() * W, y: Math.random() * H, z: Math.random() * 1.6 + 0.4, s: Math.random() * 1.6 + 0.6 });
    for (i = 0; i < nP; i++) planets.push(newPlanet(i, true));
  }

  function showSfx(text, sub, cls) {
    sfx.className = 'sfx';
    sfx.innerHTML = '<b>' + text + '</b>' + (sub ? '<i>' + sub + '</i>' : '');
    void sfx.offsetWidth;
    sfx.className = 'sfx show ' + (cls || '');
  }

  // posisi bola per waktu
  function ballState(t) {
    var p;
    if (t < T.wind) { // tarik kaki: bola tergencet ke belakang
      p = easeOut(t / T.wind);
      return { x: bx0 - 22 * p, y: by0 + 14 * p, sx: 1 + 0.08 * p, sy: 1 - 0.18 * p, r: -14 * p, a: 1 };
    }
    var ix = bx0 + 8, iy = by0 - 40;
    if (t < T.hit) { // benturan: bola melar searah tendangan
      p = (t - T.wind) / (T.hit - T.wind);
      return { x: bx0 - 22 + 30 * p, y: by0 + 14 - 54 * p, sx: 1.35, sy: 0.8, r: 42, a: 1 };
    }
    var f = clamp((t - T.hit) / (T.fly - T.hit)), e = Math.pow(f, 1.5);
    var x0 = ix, y0 = iy, x1 = W * 0.28, y1 = H * 0.3, x2 = W * 0.9, y2 = H * 0.05, m = 1 - e;
    var x = m * m * x0 + 2 * m * e * x1 + e * e * x2;
    var y = m * m * y0 + 2 * m * e * y1 + e * e * y2;
    var sc = 1.05 - 1.02 * easeIn(f);
    return { x: x, y: y, sx: sc, sy: sc, r: 42 + 1800 * e, a: t > T.fly ? 0 : 1 };
  }

  // sinar manga (segitiga tipis memancar dari titik)
  function burst(cx, cy, color, n, seedN, wScale, r0) {
    var i, a, w, rr0, r1 = Math.max(W, H) * 1.3;
    ctx.fillStyle = color;
    for (i = 0; i < n; i++) {
      a = (i + rnd(i + seedN)) / n * Math.PI * 2;
      w = (0.012 + rnd(i * 7 + seedN) * 0.03) * wScale;
      rr0 = r0 * (0.6 + rnd(i * 3 + seedN) * 0.8);
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a - w) * r1, cy + Math.sin(a - w) * r1);
      ctx.lineTo(cx + Math.cos(a + w) * r1, cy + Math.sin(a + w) * r1);
      ctx.lineTo(cx + Math.cos(a) * rr0, cy + Math.sin(a) * rr0);
      ctx.closePath(); ctx.fill();
    }
  }

  function nebula() {
    var g = ctx.createRadialGradient(W * 0.85, H * 0.1, 10, W * 0.5, H * 0.5, H);
    g.addColorStop(0, 'rgba(47,208,255,.22)'); g.addColorStop(0.5, 'rgba(23,71,255,.10)'); g.addColorStop(1, 'rgba(2,3,12,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }

  function drawPlanet(p) {
    var g = ctx.createRadialGradient(p.x - p.r * 0.35, p.y - p.r * 0.35, p.r * 0.1, p.x, p.y, p.r);
    g.addColorStop(0, '#d8f3ff'); g.addColorStop(0.35, p.c); g.addColorStop(1, '#02030c');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.2832); ctx.fill();
    if (p.ring) {
      ctx.strokeStyle = 'rgba(159,232,255,.7)'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.ellipse(p.x, p.y, p.r * 1.7, p.r * 0.42, -0.5, 0, 6.2832); ctx.stroke();
    }
  }

  function draw(t, dt) {
    var k = dt / 16.67, inv = t - T.wind, ft = t - T.hit, i, bs = ballState(t);
    var inFly = t >= T.hit, sp = inFly ? easeOut(clamp(ft / 500)) : 0;
    var white = inv >= 0 && inv < 110, black = inv >= 110 && inv < 240;

    // latar
    ctx.fillStyle = white ? '#fff' : (black ? '#000' : '#02030c');
    ctx.fillRect(0, 0, W, H);
    if (!white && !black) nebula();

    // tarik kaki: garis fokus menyempit
    if (t < T.wind) {
      var pw = easeOut(t / T.wind);
      burst(bs.x, bs.y, 'rgba(159,232,255,' + (0.12 + 0.45 * pw) + ')', [14, 26, 40, 56][o.fx], 1, 0.35, 210 - 100 * pw);
    }
    // frame benturan ala manga: putih-hitam terbalik
    if (white) burst(bx0 + 8, by0 - 40, '#000', 48, 3, 1, 30);
    else if (black) burst(bx0 + 8, by0 - 40, '#fff', 48, 5, 1, 30);

    if (!white && !black) {
      // bintang
      ctx.strokeStyle = '#fff';
      var v, len, s;
      for (i = 0; i < stars.length; i++) {
        s = stars[i]; v = (2 + sp * 52) * s.z * k; len = v * 1.3;
        ctx.globalAlpha = 0.35 + s.s / 3; ctx.lineWidth = s.s;
        ctx.beginPath(); ctx.moveTo(s.x, s.y); ctx.lineTo(s.x + len * 0.6, s.y - len * 0.8 + 0.01); ctx.stroke();
        s.x -= v * 0.6; s.y += v * 0.8;
        if (s.x < -60 || s.y > H + 60) {
          if (Math.random() < 0.5) { s.x = Math.random() * W * 1.4; s.y = -20; } else { s.x = W + 20; s.y = Math.random() * H; }
        }
      }
      ctx.globalAlpha = 1;

      // planet lewat (paralaks)
      for (i = 0; i < planets.length; i++) {
        var p = planets[i], pv = (1 + sp * 26) * p.z * k;
        p.x -= pv * 0.6; p.y += pv * 0.8;
        if (p.x < -p.r * 3 || p.y > H + p.r * 2) planets[i] = newPlanet(i, false);
        drawPlanet(p);
      }
    }

    // gelombang kejut
    if (inv >= 0 && inv < 700) {
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 7 * (1 - inv / 700) + 1; ctx.globalAlpha = 1 - inv / 700;
      ctx.beginPath(); ctx.arc(bx0 + 8, by0 - 40, inv * 1.3, 0, 6.2832); ctx.stroke(); ctx.globalAlpha = 1;
    }

    if (inFly) {
      // garis kecepatan memancar dari bola
      var nl = [0, 2, 4, 7][o.fx] * k, c = Math.floor(nl) + (Math.random() < nl % 1 ? 1 : 0);
      for (i = 0; i < c; i++) lines.push({ a: Math.random() * 6.2832, r: 60 + Math.random() * 110, l: 70 + Math.random() * 200, life: 1, w: 1 + Math.random() * 2 });
      ctx.strokeStyle = '#d9f6ff';
      for (i = lines.length - 1; i >= 0; i--) {
        var L = lines[i], off = (1 - L.life) * H * 0.6, ca = Math.cos(L.a), sa = Math.sin(L.a);
        ctx.globalAlpha = L.life * 0.8; ctx.lineWidth = L.w;
        ctx.beginPath(); ctx.moveTo(bs.x + ca * (L.r + off), bs.y + sa * (L.r + off)); ctx.lineTo(bs.x + ca * (L.r + L.l + off), bs.y + sa * (L.r + L.l + off)); ctx.stroke();
        L.life -= 0.07 * k; if (L.life <= 0) lines.splice(i, 1);
      }
      ctx.globalAlpha = 1;

      // ekor komet
      var rate = [0, 1, 2, 3][o.fx];
      if (rate && bs.a) for (i = 0; i < rate; i++) trail.push({ x: bs.x + (Math.random() - 0.5) * 14, y: bs.y + (Math.random() - 0.5) * 14, r: 4 + Math.random() * 8 * Math.max(bs.sx, 0.3), life: 1 });
      if (trail.length > 140) trail.splice(0, trail.length - 140);
      ctx.globalCompositeOperation = 'lighter';
      for (i = trail.length - 1; i >= 0; i--) {
        var q = trail[i];
        ctx.fillStyle = 'rgba(47,208,255,' + (q.life * 0.45) + ')';
        ctx.beginPath(); ctx.arc(q.x, q.y, q.r * q.life, 0, 6.2832); ctx.fill();
        q.life -= 0.04 * k; if (q.life <= 0) trail.splice(i, 1);
      }
      ctx.globalCompositeOperation = 'source-over';

      // sayatan panel diagonal
      if (ft > 300 && ft < 520) {
        var sp2 = (ft - 300) / 220;
        ctx.save(); ctx.globalAlpha = 1 - sp2; ctx.strokeStyle = '#fff';
        if (o.fx >= 2) { ctx.shadowColor = '#2fd0ff'; ctx.shadowBlur = 24; }
        ctx.lineWidth = 18 * (1 - sp2) + 2;
        ctx.beginPath(); ctx.moveTo(-40, H * 0.1); ctx.lineTo(W + 40, H * 0.8); ctx.stroke();
        ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-40, H * 0.1 + 26); ctx.lineTo(W + 40, H * 0.8 + 26); ctx.stroke();
        ctx.restore();
      }
    }

    // bola (DOM)
    ball.style.opacity = bs.a;
    ball.style.transform = 'translate(' + (bs.x - S / 2) + 'px,' + (bs.y - S / 2) + 'px) rotate(' + bs.r + 'deg) scale(' + bs.sx + ',' + bs.sy + ')';

    // kilatan
    var fo = 0;
    if (inv >= 240 && inv < 330) fo = 0.5 * (1 - (inv - 240) / 90);
    if (t > T.fly) fo = clamp((t - T.fly) / 380);
    flash.style.opacity = fo;

    // getar layar
    if (inv >= 0 && inv < 420) {
      var amp = (o.fx === 0 ? 8 : 16) * (1 - inv / 420);
      root.style.transform = 'translate(' + ((Math.random() - 0.5) * 2 * amp) + 'px,' + ((Math.random() - 0.5) * 2 * amp) + 'px)';
    } else if (root.style.transform) root.style.transform = '';

    // kejadian sekali jalan
    if (!fired.hit && t >= T.wind) { fired.hit = 1; if (o.onHit) o.onHit(); showSfx('ドンッ!!', 'D O N !', 'hit'); }
    if (!fired.fly && t >= T.hit + 120) { fired.fly = 1; if (o.onFly) o.onFly(); showSfx('ビューン!!', 'B Y U U U N !', 'fly'); }
    if (!fired.end && t >= T.fly + 30) { fired.end = 1; showSfx('KICK OFF!!', '', 'dark hold'); }
  }

  function frame(now) {
    raf = requestAnimationFrame(frame);
    var minDt = o.fps ? 1000 / o.fps - 3 : 0;
    if (now - last < minDt) return;
    var dt = Math.min(50, now - last); last = now;
    var t = now - t0;
    draw(t, dt);
    if (t >= T.end) finish();
  }

  function finish() {
    cancelAnimationFrame(raf);
    root.classList.remove('on');
    root.style.transform = '';
    flash.style.opacity = 0;
    sfx.className = 'sfx';
    running = false;
    var f = cb; cb = null;
    if (f) f();
  }

  function play(opts, done) {
    if (running) return;
    if (!root) init();
    o = opts || {}; o.fx = o.fx === undefined ? 2 : o.fx;
    cb = done; running = true; fired = {};
    root.classList.add('on');

    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) {
      flash.style.opacity = 1; setTimeout(finish, 450); return;
    }

    dpr = o.dpr || 1; W = innerWidth; H = innerHeight;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    var from = o.from || { x: W / 2, y: H * 0.45, s: 140 };
    bx0 = from.x; by0 = from.y; S = from.s;
    ball.style.width = ball.style.height = S + 'px';
    seed();
    t0 = performance.now(); last = t0;
    raf = requestAnimationFrame(frame);
  }

  window.Kick = { play: play };
})();
