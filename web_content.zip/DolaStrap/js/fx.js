/* DolaStrap - efek blackhole 2 detik (dipicu saat sesuatu dinyalakan) */
(function () {
  'use strict';
  var D = 2000, cv, ctx, raf = 0, st = null, tgt = null;
  var cl = function (v) { return Math.min(1, Math.max(0, v)); };
  var eo = function (t) { return 1 - Math.pow(1 - t, 3); };
  var ei = function (t) { return t * t; };

  function clearUI() { if (tgt) { tgt.style.transform = ''; tgt.style.transformOrigin = ''; tgt = null; } }
  function stop() { cancelAnimationFrame(raf); st = null; if (cv) cv.style.display = 'none'; clearUI(); }

  // radius lubang hitam: tumbuh -> bertahan berdenyut -> runtuh
  function holeR(t, R) {
    if (t < 350) return R * eo(t / 350);
    if (t < 1550) return R * (1 + 0.05 * Math.sin(t / 90));
    if (t < 1800) return R * (1 - ei((t - 1550) / 250));
    return 0;
  }

  function play(x, y, o) {
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (!cv) { cv = document.getElementById('bh'); ctx = cv.getContext('2d'); }
    stop();
    var dpr = o.dpr || 1, W = innerWidth, H = innerHeight, fx = o.fx, i;
    cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0); cv.style.display = 'block';
    var R = Math.min(W, H) * 0.17, n = [26, 60, 120, 200][fx], far = Math.max(W, H) * 0.9, ps = [];
    for (i = 0; i < n; i++) ps.push({ a: Math.random() * 6.2832, r: R * 1.6 + Math.random() * far, s: 0.6 + Math.random() * 0.9, c: i % 3, d: Math.random() * 0.6, w: 1 + Math.random() * 1.6 });
    tgt = fx > 0 ? document.querySelector('.screen.on') : null;
    if (tgt) tgt.style.transformOrigin = x + 'px ' + y + 'px';
    var now = performance.now();
    st = { x: x, y: y, W: W, H: H, R: R, ps: ps, o: o, t0: now, last: now };
    raf = requestAnimationFrame(frame);
  }

  function pos(p, tp, Rh, x, y) {
    var r = Rh * 0.9 + p.r * Math.pow(1 - tp, 1.8), a = p.a + 9 * Math.pow(tp, 1.6);
    return [x + Math.cos(a) * r, y + Math.sin(a) * r];
  }

  function ringHalf(x, y, rr, lw, col, back, t, blur) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(-0.35); ctx.scale(1, 0.3);
    ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.setLineDash([46, 16, 8, 16]); ctx.lineDashOffset = -t * 0.12;
    if (blur) { ctx.shadowColor = col; ctx.shadowBlur = 18; }
    ctx.beginPath(); ctx.arc(0, 0, rr, back ? Math.PI : 0, back ? Math.PI * 2 : Math.PI); ctx.stroke();
    ctx.restore();
  }

  function frame(now) {
    if (!st) return;
    raf = requestAnimationFrame(frame);
    var t = now - st.t0, o = st.o, x = st.x, y = st.y, R = st.R, fx = o.fx, i, p;
    if (t >= D) { stop(); return; }
    var Rh = holeR(t, R), A = 'rgb(' + o.ar + ')', B = 'rgb(' + o.ar2 + ')';
    ctx.clearRect(0, 0, st.W, st.H);

    // redupkan layar
    var e = t < 300 ? t / 300 : (t < 1550 ? 1 : (t < 1800 ? 1 - (t - 1550) / 250 : 0));
    if (e > 0) { ctx.fillStyle = 'rgba(0,0,0,' + (0.58 * e) + ')'; ctx.fillRect(0, 0, st.W, st.H); }

    // partikel tersedot spiral
    ctx.lineCap = 'round';
    for (i = 0; i < st.ps.length; i++) {
      p = st.ps[i];
      var tp = (t - p.d * 600) / (1100 * p.s);
      if (tp < 0) continue;
      if (tp >= 1) { if (t < 1400) { p.r = R * 1.6 + Math.random() * st.W * 0.6; p.a = Math.random() * 6.2832; p.d = t / 600; } continue; }
      var c = pos(p, tp, Rh, x, y), c0 = pos(p, Math.max(0, tp - 0.05), Rh, x, y);
      ctx.strokeStyle = p.c === 0 ? A : (p.c === 1 ? B : '#fff');
      ctx.globalAlpha = 0.2 + 0.8 * tp; ctx.lineWidth = p.w;
      ctx.beginPath(); ctx.moveTo(c0[0], c0[1]); ctx.lineTo(c[0], c[1]); ctx.stroke();
    }
    ctx.globalAlpha = 1;

    if (Rh > 0.5) {
      var blur = fx >= 2;
      // cincin akresi sisi belakang
      for (i = 0; i < 3; i++) ringHalf(x, y, Rh * (1.55 + i * 0.5), (4 - i) * 1.6, i === 1 ? B : A, true, t, blur);
      // halo gelap + horizon peristiwa
      var g = ctx.createRadialGradient(x, y, Rh * 0.9, x, y, Rh * 1.9);
      g.addColorStop(0, 'rgba(0,0,0,.95)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, Rh * 1.9, 0, 6.2832); ctx.fill();
      ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(x, y, Rh, 0, 6.2832); ctx.fill();
      // cincin lensa gravitasi
      ctx.save(); ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
      if (blur) { ctx.shadowColor = A; ctx.shadowBlur = 22; }
      ctx.beginPath(); ctx.arc(x, y, Rh * 1.04, 0, 6.2832); ctx.stroke(); ctx.restore();
      // sisi depan cakram
      for (i = 0; i < 3; i++) ringHalf(x, y, Rh * (1.55 + i * 0.5), (4 - i) * 1.6, i === 1 ? B : A, false, t, blur);
    }

    // gelombang kejut saat runtuh
    if (t > 1750) {
      var k = (t - 1750) / 250;
      ctx.strokeStyle = A; ctx.lineWidth = 8 * (1 - k) + 1; ctx.globalAlpha = 1 - k;
      ctx.beginPath(); ctx.arc(x, y, k * R * 4.5, 0, 6.2832); ctx.stroke(); ctx.globalAlpha = 1;
    }

    // UI ikut tersedot lalu memantul
    if (tgt) {
      var env = Math.pow(Math.sin(cl(t / D) * Math.PI), 0.8);
      tgt.style.transform = 'scale(' + (1 - 0.07 * env) + ') rotate(' + (-1.4 * env) + 'deg)';
    }
  }

  window.BlackHole = { play: play, stop: stop };
})();
