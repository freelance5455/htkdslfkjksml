# DolaStrap

Launcher HTML untuk membuka aplikasi Mamoball. Siap dibungkus jadi APK lewat WebView.

## Isi

```
index.html            halaman utama (di akar)
css/style.css         tampilan
js/app.js             logika, setting, loading, launch
js/anim.js            animasi bola ditendang ke luar angkasa
assets/icon.svg       ikon aplikasi (orisinal)
assets/logo.svg       logo teks
android/              contoh WebView + jembatan + snippet manifest
```

Bisa dibuka langsung di browser (klik dua kali index.html) untuk melihat tampilan dan animasi.

## Langkah wajib

1. Buka `js/app.js`, ganti `PACKAGE` dengan package name Mamoball (dari link Play Store, bagian `id=...`).
2. Di Android Studio, salin index.html, css, js, assets ke `app/src/main/assets/`.
3. Pakai `android/MainActivity.kt` dan `android/AndroidManifest.snippet.xml`, ganti package name di keduanya.
4. Ikon APK: ubah `assets/icon.svg` jadi PNG (Android Studio: New > Image Asset > pilih SVG).

## Apa yang benar-benar bekerja

| Fitur | Efek nyata |
|---|---|
| Tombol bola | Membuka Mamoball lewat package name (WebView + jembatan Android) |
| FPS Meter | Menampilkan FPS launcher |
| Target FPS | Membatasi frame rate animasi launcher, dan meminta refresh rate ke jendela DolaStrap |
| FPS Boost | Mengurangi efek dan resolusi render launcher, loading lebih cepat |
| Kualitas / Graphic | Mengatur resolusi canvas dan jumlah bintang, planet, partikel pada animasi launcher |
| Antilag | Meminta Wi-Fi mode latensi rendah dan layar tetap menyala (selama DolaStrap aktif) |
| Suara / Getar | Efek tendangan dan getar |
| Tombol Setting dan Preset | Disimpan di localStorage dan dikirim ke aplikasi native saat launch |

## Apa yang TIDAK bekerja (jujur)

- **FASTSHOOT dan SMOOTHBALL** hanya menyimpan konfigurasi dan mengirimnya sebagai extra intent. Mamoball tidak membaca extra itu, jadi tidak ada efek di dalam game. Aplikasi lain tidak bisa diubah hitbox, power tendangan, atau fisika bolanya dari luar. Label BETA di UI menjelaskan ini ke pengguna.
- **FPS dan grafis di dalam Mamoball** tidak berubah. FPS/Graphic/Kualitas hanya memengaruhi launcher. Untuk game, pengaturan grafis ada di dalam game itu sendiri.
- Fitur yang mengubah game pihak lain (hitbox, shoot power) tidak dibuatkan: itu termasuk cheat, melanggar aturan game online, dan bisa membuat akun kena ban. Jangan menjanjikan fitur itu ke pengguna kalau memang tidak ada efeknya.

## Tema

Gaya manga biru orisinal: halftone, garis kecepatan, frame benturan hitam-putih, teks onomatopoeia. Tidak memakai gambar, karakter, atau animasi asli Blue Lock (berhak cipta). Kalau mau tema Blue Lock resmi, perlu izin dari pemegang haknya.
