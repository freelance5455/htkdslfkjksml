# DolaStrap v3

Launcher neon hitam untuk membuka Mamoball yang SUDAH TERPASANG di HP. Dibungkus jadi APK lewat WebView.

## Isi

```
index.html, css/, js/, assets/     halaman web (index.html di akar)
android/                           proyek Android Studio siap build (Gradle + Kotlin)
```

`index.html` bisa dibuka di browser untuk melihat tampilan. Membuka Mamoball hanya andal dari APK buatan `android/`.

## Cara build APK (paling andal)

1. Buka Android Studio > Open > pilih folder `DolaStrap/android` (bukan folder induknya).
2. Tunggu Gradle sync (butuh internet; Android Studio mengunduh Gradle 8.7 sendiri).
3. Build > Build APK(s), atau tekan Run ke HP. Halaman web disalin otomatis dari folder induk ke assets setiap build.
4. Install, buka DolaStrap. Home harus menampilkan MAMOBALL TERPASANG. Jika belum: PROFIL > DETEKSI atau PILIH.
5. Tekan bola.

Belum bisa kuuji kompilasi (sandbox tanpa Android SDK). Jika Gradle error, kirim pesan errornya.

## Kalau tidak masuk Mamoball

Buka TOOLS > DIAGNOSA:
- `Jembatan: TIDAK ADA`: DolaStrap dibuka dari browser atau converter online. Pakai proyek `android/`.
- `App terlihat` kecil (di bawah 5): blok `<queries>` di manifest tidak terpasang. Jangan hapus.
- `Terpasang: TIDAK`: package salah. Pakai PROFIL > DETEKSI / PILIH, atau ketik package dari link Play Store (`id=...`).
- Dialog GAGAL MASUK menampilkan alasan + tombol Ulangi, Play Store, Salin Package, Atur Package.

Tanpa jembatan (browser/WebView biasa), Android hanya mengizinkan membuka aplikasi dari ketukan langsung, jadi muncul dialog SIAP MASUK; tekan MASUK MAMOBALL.

## Menu

| Menu | Isi |
|---|---|
| SETTING | FPS Boost, Target FPS, Antilag, Kualitas, Graphic, Layar menyala, Hemat baterai, FPS Meter, Animasi tendangan, Blackhole, Latar neon, Suara + volume, Getar, Konfirmasi, **Sistem: refresh rate, kecerahan, mode fokus** |
| PRESET | Performa 1 klik (Hemat/Seimbang/Maksimal), Fastshoot, Smoothball (BETA), tips |
| TOOLS | Uji koneksi, Uji FPS + saran, Info perangkat, Cek Mamoball, Diagnosa + Izin |
| PROFIL | Tema (4), Package + Deteksi/Pilih, 3 slot profil, Ekspor/Impor, Riwayat, Reset |

Efek blackhole 2 detik muncul tiap kali kamu MENYALAKAN toggle atau menerapkan preset.

## Yang benar-benar ikut berlaku di Mamoball

Boost SISTEM (hanya APK, butuh izin yang kamu setujui sendiri di TOOLS > IZIN SETELAN / IZIN FOKUS):
- Refresh rate tinggi seluruh sistem (key `peak_refresh_rate` / `min_refresh_rate`; tergantung merk HP, tidak semua HP mengikuti).
- Kecerahan layar sesuai pilihan.
- Mode fokus: notifikasi dibungkam (hanya alarm).
Semuanya dipulihkan otomatis saat kembali ke DolaStrap (atau tombol PULIHKAN). Setelah launch, layar loading menulis boost apa yang benar-benar aktif.

## Yang tidak bisa

- FPS internal, grafis, hitbox, atau fisika bola di dalam Mamoball tidak bisa diubah dari aplikasi lain. FPS/Graphic/Kualitas di DolaStrap hanya mengatur launcher.
- FASTSHOOT dan SMOOTHBALL hanya konfigurasi (label BETA); Mamoball tidak membacanya. Cheat game online tidak dibuat: melanggar aturan game dan berisiko ban akun.
- Wi-Fi latensi rendah (Antilag) hanya efektif saat DolaStrap di layar depan; tidak menjamin ping lebih baik di dalam game.
- Tema manga biru orisinal, bukan aset Blue Lock (berhak cipta).
