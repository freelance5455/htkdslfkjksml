const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const scoreElement = document.getElementById("score");
const startBtn = document.getElementById("startBtn");

const grid = 20;

let snake;
let food;
let direction;
let nextDirection;
let score;
let gameLoop;

function startGame() {
  snake = [
    { x: 160, y: 160 },
    { x: 140, y: 160 },
    { x: 120, y: 160 }
  ];
  
  food = createFood();
  
  direction = "right";
  nextDirection = "right";
  score = 0;
  
  scoreElement.textContent = score;
  
  clearInterval(gameLoop);
  gameLoop = setInterval(updateGame, 120);
  
  draw();
}

function updateGame() {
  direction = nextDirection;
  
  const head = { ...snake[0] };
  
  if (direction === "up") head.y -= grid;
  if (direction === "down") head.y += grid;
  if (direction === "left") head.x -= grid;
  if (direction === "right") head.x += grid;
  
  if (
    head.x < 0 ||
    head.x >= canvas.width ||
    head.y < 0 ||
    head.y >= canvas.height ||
    snake.some(part => part.x === head.x && part.y === head.y)
  ) {
    gameOver();
    return;
  }
  
  snake.unshift(head);
  
  if (head.x === food.x && head.y === food.y) {
    score++;
    scoreElement.textContent = score;
    food = createFood();
  } else {
    snake.pop();
  }
  
  draw();
}

function draw() {
  ctx.fillStyle = "#111827";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // الطعام
  ctx.fillStyle = "#ef4444";
  ctx.beginPath();
  ctx.arc(
    food.x + grid / 2,
    food.y + grid / 2,
    grid / 2 - 2,
    0,
    Math.PI * 2
  );
  ctx.fill();
  
  // الثعبان
  snake.forEach((part, index) => {
    ctx.fillStyle = index === 0 ? "#22c55e" : "#16a34a";
    
    ctx.fillRect(
      part.x + 1,
      part.y + 1,
      grid - 2,
      grid - 2
    );
  });
}

function createFood() {
  let newFood;
  
  do {
    newFood = {
      x: Math.floor(Math.random() * (canvas.width / grid)) * grid,
      y: Math.floor(Math.random() * (canvas.height / grid)) * grid
    };
  } while (
    snake &&
    snake.some(part => part.x === newFood.x && part.y === newFood.y)
  );
  
  return newFood;
}

function changeDirection(newDirection) {
  if (newDirection === "up" && direction !== "down") {
    nextDirection = "up";
  }
  
  if (newDirection === "down" && direction !== "up") {
    nextDirection = "down";
  }
  
  if (newDirection === "left" && direction !== "right") {
    nextDirection = "left";
  }
  
  if (newDirection === "right" && direction !== "left") {
    nextDirection = "right";
  }
}

function gameOver() {
  clearInterval(gameLoop);
  
  setTimeout(() => {
    alert("انتهت اللعبة! 🐍\nالنقاط: " + score);
  }, 100);
}

document.addEventListener("keydown", event => {
  if (event.key === "ArrowUp") changeDirection("up");
  if (event.key === "ArrowDown") changeDirection("down");
  if (event.key === "ArrowLeft") changeDirection("left");
  if (event.key === "ArrowRight") changeDirection("right");
});

startBtn.addEventListener("click", startGame);

// دعم السحب على شاشة الهاتف
let touchStartX = 0;
let touchStartY = 0;

canvas.addEventListener("touchstart", event => {
  const t = event.changedTouches[0];
  touchStartX = t.clientX;
  touchStartY = t.clientY;
}, { passive: true });

canvas.addEventListener("touchend", event => {
  const t = event.changedTouches[0];
  const dx = t.clientX - touchStartX;
  const dy = t.clientY - touchStartY;

  if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) return;

  if (Math.abs(dx) > Math.abs(dy)) {
    changeDirection(dx > 0 ? "right" : "left");
  } else {
    changeDirection(dy > 0 ? "down" : "up");
  }
}, { passive: true });

// رسم أولي
snake = [
  { x: 160, y: 160 },
  { x: 140, y: 160 },
  { x: 120, y: 160 }
];

food = createFood();
draw();