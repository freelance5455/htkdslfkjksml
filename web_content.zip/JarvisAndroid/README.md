# JARVIS Android (wake word "Jarvis" + home screen overlay)

1. Picovoice AccessKey (free): https://console.picovoice.ai -> app/src/main/res/values/keys.xml me paste karein.
2. Android Studio me "Open" -> JarvisAndroid folder. Sync hone dein. Phone USB debugging se connect karke Run.
3. App kholein -> Mic, Notification aur "Display over other apps" allow karein.
4. App ke Settings (gear) me Gemini/OpenAI API key daalein. Save.
5. Home screen par jaake bolo: "Jarvis" -> transparent JARVIS orb khul jayega. Phir apna sawal bolo.

Xiaomi/HyperOS/MIUI: App info -> Autostart ON, Battery saver -> "No restrictions",
Other permissions -> "Display pop-up windows while running in background" ON, Recent apps me app ko lock karein.
Reboot ke baad ek baar app kholna padega (Android 14 background mic service boot par start nahi hone deta).
Wake service band karne ke liye notification ka "Band karo" dabayein.
