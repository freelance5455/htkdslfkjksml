package com.jarvis.assistant;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.ArrayList;

/** WebView (index.html) <-> Android: native mic (SpeechRecognizer), close, toast. */
public class JarvisBridge {
    private static final String LANG = "hi-IN";   // English ke liye "en-IN" kar dein
    private final Context ctx;
    private final WebView web;
    private final boolean overlay;
    private final Handler main = new Handler(Looper.getMainLooper());
    private SpeechRecognizer rec;

    JarvisBridge(Context ctx, WebView web, boolean overlay) {
        this.ctx = ctx; this.web = web; this.overlay = overlay;
    }

    @JavascriptInterface public void startListening() { main.post(this::listen); }
    @JavascriptInterface public void stopListening() { main.post(this::finish); }
    @JavascriptInterface public void close() { if (overlay) main.post(WakeService::closeOverlay); }
    @JavascriptInterface public void toast(String m) { main.post(() -> Toast.makeText(ctx, m, Toast.LENGTH_LONG).show()); }

    void destroy() { release(); }

    private void js(String code) { web.post(() -> web.evaluateJavascript(code, null)); }

    private void release() {
        if (rec != null) { try { rec.cancel(); rec.destroy(); } catch (Exception ignored) {} rec = null; }
    }
    private void finish() {
        release();
        if (!overlay) WakeService.resume();
    }

    private void listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            js("window.onNativeError && window.onNativeError('Is phone me speech recognition available nahi hai')");
            return;
        }
        release();
        WakeService.pause();                        // wake-word mic chhod de
        rec = SpeechRecognizer.createSpeechRecognizer(ctx);
        rec.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle b) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float v) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle b) {}
            public void onError(int e) {
                if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                    js("window.onNativeListenEnd && window.onNativeListenEnd()");
                else
                    js("window.onNativeError && window.onNativeError(" + JSONObject.quote("Mic error code " + e) + ")");
                finish();
            }
            public void onResults(Bundle b) {
                ArrayList<String> r = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (r != null && !r.isEmpty())
                    js("window.onNativeSpeech && window.onNativeSpeech(" + JSONObject.quote(r.get(0)) + ")");
                else
                    js("window.onNativeListenEnd && window.onNativeListenEnd()");
                finish();
            }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANG);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        main.postDelayed(() -> { if (rec != null) rec.startListening(i); }, 250);
    }
}
