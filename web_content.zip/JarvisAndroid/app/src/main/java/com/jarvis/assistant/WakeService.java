package com.jarvis.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.Toast;
import ai.picovoice.porcupine.Porcupine;
import ai.picovoice.porcupine.PorcupineException;
import ai.picovoice.porcupine.PorcupineManager;

/** Hamesha "Jarvis" sunta hai; sunte hi home screen ke upar transparent JARVIS overlay dikhata hai. */
public class WakeService extends Service {
    private static final String CHANNEL = "jarvis_wake";
    private static WakeService inst;
    private final Handler main = new Handler(Looper.getMainLooper());
    private PorcupineManager pm;
    private boolean pmRunning = false;
    private WindowManager wm;
    private FrameLayout overlay;
    private WebView web;
    private JarvisBridge bridge;

    static void pause() { if (inst != null) inst.stopPm(); }
    static void resume() { if (inst != null && inst.overlay == null) inst.startPm(); }
    static void closeOverlay() { if (inst != null) inst.hideOverlay(); }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        inst = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        getSystemService(NotificationManager.class).createNotificationChannel(
            new NotificationChannel(CHANNEL, "JARVIS wake word", NotificationManager.IMPORTANCE_LOW));
        PendingIntent openPi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stopPi = PendingIntent.getService(this, 1, new Intent(this, WakeService.class).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS sun raha hai")
            .setContentText("Bolo \"Jarvis\"")
            .setContentIntent(openPi)
            .addAction(new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Band karo", stopPi).build())
            .build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        else startForeground(1, n);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (pm == null) initPm();
        return START_STICKY;
    }

    @Override public void onDestroy() {
        hideOverlay();
        stopPm();
        if (pm != null) { pm.delete(); pm = null; }
        inst = null;
        super.onDestroy();
    }

    private void toast(String m) { main.post(() -> Toast.makeText(this, m, Toast.LENGTH_LONG).show()); }

    private void initPm() {
        String key = getString(R.string.picovoice_access_key);
        if (key.startsWith("PASTE")) { toast("res/values/keys.xml me Picovoice AccessKey daalein"); return; }
        try {
            pm = new PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(getApplicationContext(), idx -> main.post(this::onWake));
            startPm();
        } catch (PorcupineException e) { toast("Wake word error: " + e.getMessage()); }
    }
    private void startPm() {
        if (pm == null || pmRunning) return;
        try { pm.start(); pmRunning = true; } catch (PorcupineException e) { toast("Wake word start error: " + e.getMessage()); }
    }
    private void stopPm() {
        if (pm == null || !pmRunning) return;
        try { pm.stop(); } catch (PorcupineException ignored) {}
        pmRunning = false;
    }

    private void onWake() {
        if (overlay != null) return;
        stopPm();
        showOverlay();
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("'Display over other apps' permission allow karein");
            startPm();
            return;
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        bridge = new JarvisBridge(this, web, true);
        web.addJavascriptInterface(bridge, "AndroidBridge");
        web.setWebChromeClient(new WebChromeClient());
        web.loadUrl("file:///android_asset/index.html?overlay=1");

        overlay = new FrameLayout(this);
        overlay.addView(web, new FrameLayout.LayoutParams(-1, -1));
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(-1, -1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT);
        wm.addView(overlay, lp);
    }

    private void hideOverlay() {
        if (overlay == null) return;
        try { wm.removeView(overlay); } catch (Exception ignored) {}
        if (bridge != null) bridge.destroy();
        overlay.removeAllViews();
        if (web != null) web.destroy();
        overlay = null; web = null; bridge = null;
        main.postDelayed(this::startPm, 500);       // wapas "Jarvis" sunna shuru
    }
}
