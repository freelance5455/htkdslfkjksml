SULTAN - CYBER ARENA
Versi: 1.0

CARA MEMBUKA:
1. Ekstrak ZIP ini.
2. Buka folder SULTAN di Acode.
3. Buka index.html lalu pilih Preview/Open in Browser.
4. Untuk membuat APK, impor folder/proyek HTML ini ke ApkForge sesuai menu yang tersedia.

KONTROL:
- Sentuh dan geser layar untuk menggerakkan pesawat.
- Pesawat menembak otomatis.
- Hindari musuh dan kumpulkan orb energi.
- Tekan PAUSE untuk berhenti sementara.

CATATAN:
- Game berjalan offline setelah dimuat.
- Skor dan statistik disimpan di penyimpanan lokal browser/WebView.
- Versi ini merupakan game HTML5 yang perlu dikemas menggunakan ApkForge agar menjadi APK.
