const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
app.use(express.static(path.join(__dirname, 'public')));
const server = http.createServer(app);
const io = new Server(server);
const players = {};
const num = (v, d = 0) => (Number.isFinite(+v) ? +v : d);

io.on('connection', socket => {
  socket.on('join', name => {
    players[socket.id] = { id: socket.id, name: String(name || 'Soldier').slice(0, 14), x: 0, y: 0, z: 0, ry: 0, hp: 100, alive: true, kills: 0 };
    io.emit('feed', `${players[socket.id].name} dropped in`);
  });

  socket.on('move', d => {
    const p = players[socket.id];
    if (!p || !p.alive) return;
    p.x = num(d.x); p.y = num(d.y); p.z = num(d.z); p.ry = num(d.ry);
    p.hp = Math.max(0, Math.min(100, num(d.hp, 100)));
    if (d.alive === false) p.alive = false;
  });

  socket.on('hit', ({ target, dmg }) => {
    const t = players[target], s = players[socket.id];
    if (!t || !s || !t.alive || target === socket.id) return;
    t.hp = Math.max(0, t.hp - Math.min(40, Math.max(1, num(dmg, 10))));
    io.to(target).emit('hurt', { hp: t.hp });
    if (t.hp <= 0) {
      t.alive = false; s.kills++;
      io.emit('feed', `${s.name} eliminated ${t.name}`);
      io.to(target).emit('eliminated', { by: s.name });
    }
  });

  socket.on('died', ({ reason }) => {
    const p = players[socket.id];
    if (!p || !p.alive) return;
    p.alive = false;
    io.emit('feed', `${p.name} ${String(reason).slice(0, 60)}`);
  });

  socket.on('disconnect', () => {
    const p = players[socket.id];
    delete players[socket.id];
    if (p) io.emit('feed', `${p.name} left the match`);
  });
});

setInterval(() => io.emit('players', players), 100);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Squad Royale 3D running on http://localhost:${PORT}`));
