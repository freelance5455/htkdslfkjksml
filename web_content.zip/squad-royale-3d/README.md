# Squad Royale 3D

A mobile-browser battle royale prototype: island, plane drop, parachute, squad of four, energy blasters, walls, loot boxes, deep-water elimination, and Socket.IO multiplayer.

## Requirements
- Node.js 18 or newer (https://nodejs.org)
- An Android phone with Chrome, on the same Wi-Fi as your computer
- Internet access on the phone (Three.js loads from the jsDelivr CDN)

## Setup and run
1. Unzip the project and open a terminal in the `squad-royale-3d` folder.
2. Install dependencies: `npm install`
3. Start the server: `npm start`
4. On the computer, open http://localhost:3000 to test.
5. To play on Android, find your computer's local IP (`ipconfig` on Windows, `ifconfig` or `ip addr` on macOS/Linux). Open `http://<that-IP>:3000` in Chrome on the phone, then rotate to landscape.
6. Each player on the same server joins the same match. For internet play, host the folder on any Node.js host (Render, Railway, Fly.io) with `npm start`.

## Controls (touch)
- Left side drag: move (floating joystick)
- Right side drag: look around
- RUN: hold to sprint
- JUMP: drop from the plane, or hop on the ground
- CHUTE: open the parachute while falling, then steer with the joystick
- PICKUP: search a house or open a loot box. With no loot nearby, it uses a health kit.
- SHOOT: hold to fire the energy blaster (needs a blaster and charges)
- BUILD WALL: place a protective wall in front of you

## Notes
- Houses have walkable rooms. Walk through the front doorway and the inner doorway. Loot is searched from inside or next to the house.
- Houses hold the loot: 6 energy blasters, 140 charges in 14 packs, and health kits. Enemy loot boxes add 60 more charges.
- Walking into deep water eliminates you and posts the event to the feed.
- Enemy raiders are computer-controlled. Remote players appear as red-name enemies.

## Troubleshooting
- Run `npm install` once before `npm start`. Without it, the server stops with "Cannot find module 'express'".
- Always open the game through the server (http://localhost:3000). Opening index.html by double-clicking will not work.
- If a red message appears at the bottom of the screen, it describes the problem.
- The phone needs internet access, because Three.js loads from a CDN.
