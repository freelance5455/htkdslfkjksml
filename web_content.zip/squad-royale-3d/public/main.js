import * as THREE from 'three';

const $ = id => document.getElementById(id);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const rand = (a, b) => a + Math.random() * (b - a);
const V = (x, y, z) => new THREE.Vector3(x, y, z);
const UP = V(0, 1, 0);
const R = 380, SKY = 0x9fd3f0;
const mat = c => new THREE.MeshLambertMaterial({ color: c });

// ---------- Renderer and scene
const renderer = new THREE.WebGLRenderer({ canvas: $('c'), antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
const scene = new THREE.Scene();
scene.background = new THREE.Color(SKY);
scene.fog = new THREE.Fog(SKY, 200, 800);
const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 1500);
scene.add(new THREE.HemisphereLight(0xffffff, 0x4a6b3a, 1.0));
const sun = new THREE.DirectionalLight(0xfff1d0, 1.1);
sun.position.set(200, 300, 120);
scene.add(sun);
function resize() { renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize);
resize();

// ---------- Terrain: island, hills, shallow ring, deep sea
function hills(x, z) { return 0.5 + 0.5 * Math.sin(x * 0.021 + 1.3) * Math.cos(z * 0.017 - 0.7) + 0.25 * Math.sin(x * 0.07 + z * 0.05) + 0.1 * Math.cos(x * 0.13 - z * 0.11); }
function height(x, z) {
  const mask = 1 - smooth(0.7, 1.0, Math.hypot(x, z) / R);
  const land = 2 + 14 * Math.max(0, hills(x, z));
  return -9 + (land + 9) * mask;
}
const C = { sand: new THREE.Color(0xd8c48a), grass: new THREE.Color(0x5f9a45), rock: new THREE.Color(0x7a7468) };
const gGeo = new THREE.PlaneGeometry(1200, 1200, 170, 170).rotateX(-Math.PI / 2);
{
  const p = gGeo.attributes.position, cols = [];
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), z = p.getZ(i), h = height(x, z);
    p.setY(i, h);
    const c = h < 1.2 ? C.sand : h > 14 ? C.rock : C.grass;
    cols.push(c.r, c.g, c.b);
  }
  gGeo.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3));
  gGeo.computeVertexNormals();
}
scene.add(new THREE.Mesh(gGeo, new THREE.MeshLambertMaterial({ vertexColors: true })));
const water = new THREE.Mesh(new THREE.PlaneGeometry(4000, 4000).rotateX(-Math.PI / 2), new THREE.MeshLambertMaterial({ color: 0x1d6fa8, transparent: true, opacity: 0.85 }));
scene.add(water);

function road(x0, z0, x1, z1) {
  const len = Math.hypot(x1 - x0, z1 - z0);
  const g = new THREE.PlaneGeometry(len, 8, Math.ceil(len / 5), 1).rotateX(-Math.PI / 2);
  g.rotateY(-Math.atan2(z1 - z0, x1 - x0));
  g.translate((x0 + x1) / 2, 0, (z0 + z1) / 2);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) p.setY(i, height(p.getX(i), p.getZ(i)) + 0.2);
  g.computeVertexNormals();
  scene.add(new THREE.Mesh(g, mat(0x3c3c40)));
}
road(-260, 0, 260, 0); road(0, -260, 0, 260); road(-150, -150, 150, 120);

// ---------- Houses (solid exteriors, searchable loot), trees
const obstacles = [];
const houses = [];
const crates = [];
const walls = [];
const inObstacle = (x, z, m = 3) => obstacles.some(o => x > o.x0 - m && x < o.x1 + m && z > o.z0 - m && z < o.z1 + m);
const WALLS = [0xe9dcc3, 0xd8c3a5, 0xb9d3dd, 0xf2efe6, 0xc9b79c];
const glassMat = new THREE.MeshLambertMaterial({ color: 0x8fd3ff, emissive: 0x1a3345 });
function buildHouse(x, z) {
  const w = rand(7, 10), d = rand(6, 9), H = 4.5, base = height(x, z), T = 0.4;
  const hw = w / 2, hd = d / 2, gap = 1.1;     // doorway half-width on the front wall
  const px = 1.5, pg = 0.8;                     // interior partition door at x = px
  const g = new THREE.Group();
  const wallMat = mat(WALLS[(Math.random() * WALLS.length) | 0]);
  const pieces = [];
  // wall segment given in house-local coords: centre (cx, cz), size (sx, sz)
  const piece = (cx, cz, sx, sz) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(sx, H, sz), wallMat);
    m.position.set(cx, H / 2, cz); g.add(m);
    pieces.push({ kind: 'wall', x0: x + cx - sx / 2, x1: x + cx + sx / 2, z0: z + cz - sz / 2, z1: z + cz + sz / 2, y0: base - 1, y1: base + H });
  };
  // front wall with a doorway in the middle
  piece((-hw - gap) / 2, hd, hw - gap, T);
  piece((gap + hw) / 2, hd, hw - gap, T);
  // back, left and right outer walls
  piece(0, -hd, w, T);
  piece(-hw, 0, T, d);
  piece(hw, 0, T, d);
  // interior partition with a doorway: splits the house into two rooms
  piece(((-hw) + (px - pg)) / 2, 0, (px - pg) + hw, T);
  piece(((px + pg) + hw) / 2, 0, hw - (px + pg), T);
  // floor
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(w - T, d - T).rotateX(-Math.PI / 2), mat(0x8a6a48));
  floor.position.y = 0.05; g.add(floor);
  // roof and windows
  const roof = new THREE.Mesh(new THREE.ConeGeometry(0.75 * Math.max(w, d), 3, 4), mat(0x7b2e20));
  roof.rotation.y = Math.PI / 4; roof.position.y = H + 1.5;
  const win1 = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.2, 0.2), glassMat);
  win1.position.set(w / 3.5, 2.6, hd + 0.05);
  const win2 = win1.clone(); win2.position.x = -w / 3.5;
  g.add(roof, win1, win2);
  g.position.set(x, base, z);
  scene.add(g);
  const h = { kind: 'house', g, loot: [], x0: x - hw, x1: x + hw, z0: z - hd, z1: z + hd, y0: base - 1, y1: base + H + 4 };
  houses.push(h);
  for (const pc of pieces) obstacles.push(pc);
}
for (let tries = 0, placed = 0; tries < 3000 && placed < 56; tries++) {
  const a = rand(0, Math.PI * 2), r = rand(20, R * 0.68);
  const x = Math.cos(a) * r, z = Math.sin(a) * r;
  if (height(x, z) < 2.5 || Math.abs(x) < 8 || Math.abs(z) < 8 || inObstacle(x, z, 8)) continue;
  buildHouse(x, z); placed++;
}
{
  const order = [...houses].sort(() => Math.random() - 0.5);
  order.slice(0, 6).forEach(h => h.loot.push('blaster'));
  order.slice(6, 20).forEach(h => h.loot.push('ammo'));   // 14 packs x 10 = 140 charges
  order.slice(20, 40).forEach(h => h.loot.push('med'));
}
let ammoPool = 60;  // remaining 60 charges come from enemy loot boxes, total 200 on the map

const trunkMesh = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.4, 0.6, 4, 6).translate(0, 2, 0), mat(0x6b4a2b), 420);
const crownMesh = new THREE.InstancedMesh(new THREE.ConeGeometry(2.8, 7, 7).translate(0, 6.5, 0), mat(0x2f7a3a), 420);
{
  const dm = new THREE.Object3D(); let n = 0;
  for (let i = 0; i < 3000 && n < 420; i++) {
    const x = rand(-R * 0.8, R * 0.8), z = rand(-R * 0.8, R * 0.8);
    if (Math.hypot(x, z) > R * 0.7 || height(x, z) < 2.5 || inObstacle(x, z, 4)) continue;
    dm.position.set(x, height(x, z), z); dm.scale.setScalar(rand(0.8, 1.4)); dm.rotation.y = Math.random() * 6;
    dm.updateMatrix();
    trunkMesh.setMatrixAt(n, dm.matrix); crownMesh.setMatrixAt(n, dm.matrix); n++;
  }
  trunkMesh.count = n; crownMesh.count = n;
}
scene.add(trunkMesh, crownMesh);

// ---------- Helpers: collision, shots, particles, bolts
function collide(p, r = 0.45) {
  for (const o of obstacles) {
    if (p.x > o.x0 - r && p.x < o.x1 + r && p.z > o.z0 - r && p.z < o.z1 + r) {
      const dl = p.x - (o.x0 - r), dr = (o.x1 + r) - p.x, dd = p.z - (o.z0 - r), du = (o.z1 + r) - p.z;
      const m = Math.min(dl, dr, dd, du);
      if (m === dl) p.x = o.x0 - r; else if (m === dr) p.x = o.x1 + r;
      else if (m === dd) p.z = o.z0 - r; else p.z = o.z1 + r;
    }
  }
}
function segBox(a, b, o) {
  let t0 = 0, t1 = 1;
  const d = [b.x - a.x, b.y - a.y, b.z - a.z], p = [a.x, a.y, a.z];
  const mn = [o.x0, o.y0, o.z0], mx = [o.x1, o.y1, o.z1];
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) { if (p[i] < mn[i] || p[i] > mx[i]) return false; }
    else {
      let ta = (mn[i] - p[i]) / d[i], tb = (mx[i] - p[i]) / d[i];
      if (ta > tb) [ta, tb] = [tb, ta];
      t0 = Math.max(t0, ta); t1 = Math.min(t1, tb);
      if (t0 > t1) return false;
    }
  }
  return true;
}
const clear = (a, b) => !obstacles.some(o => segBox(a, b, o));

const parts = [];
const partGeo = new THREE.SphereGeometry(0.14, 4, 3);
function burst(p, color, n = 12, up = 4) {
  for (let i = 0; i < n; i++) {
    const m = new THREE.Mesh(partGeo, new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.9 }));
    m.position.copy(p); scene.add(m);
    parts.push({ m, v: V(rand(-3, 3), rand(up * 0.5, up), rand(-3, 3)), life: 0.9 });
  }
}
function updateParts(dt) {
  for (let i = parts.length - 1; i >= 0; i--) {
    const q = parts[i];
    q.life -= dt; q.v.y -= 9 * dt; q.m.position.addScaledVector(q.v, dt);
    q.m.material.opacity = Math.max(0, q.life);
    if (q.life <= 0) { scene.remove(q.m); parts.splice(i, 1); }
  }
}
const bolts = [];
const boltGeo = new THREE.SphereGeometry(0.22, 8, 6);
function bolt(a, b, color) {
  const m = new THREE.Mesh(boltGeo, new THREE.MeshBasicMaterial({ color }));
  m.position.copy(a); scene.add(m);
  bolts.push({ m, a: a.clone(), b: b.clone(), t: 0, dur: Math.max(0.05, a.distanceTo(b) / 140), color });
}
function updateBolts(dt) {
  for (let i = bolts.length - 1; i >= 0; i--) {
    const b = bolts[i];
    b.t += dt;
    const k = Math.min(1, b.t / b.dur);
    b.m.position.lerpVectors(b.a, b.b, k);
    if (k >= 1) { burst(b.b, b.color, 8, 3); scene.remove(b.m); bolts.splice(i, 1); }
  }
}

// ---------- Audio (synthesized, unlocked on first tap)
let actx = null;
function ensureAudio() {
  if (!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
  if (actx.state === 'suspended') actx.resume();
}
function beep(f, dur, type = 'square', vol = 0.05, slide = 0) {
  if (!actx || actx.state !== 'running') return;
  const t = actx.currentTime, o = actx.createOscillator(), g = actx.createGain();
  o.type = type; o.frequency.setValueAtTime(f, t);
  if (slide) o.frequency.linearRampToValueAtTime(f + slide, t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g); g.connect(actx.destination); o.start(t); o.stop(t + dur);
}
const CHORD = [110, 130.8, 164.8, 196, 164.8, 130.8];
let musicStep = 0;
setInterval(() => { if (gameOn) beep(CHORD[musicStep++ % CHORD.length], 0.6, 'triangle', 0.025); }, 600);

// ---------- Characters and labels
function makeLabel(text, color) {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64;
  const tex = new THREE.CanvasTexture(c);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true }));
  s.scale.set(2.6, 0.65, 1); s.position.y = 2.95;
  s.userData = { c, tex, text, color, last: '' };
  return s;
}
function drawLabel(s, frac) {
  const u = s.userData, key = u.text + frac.toFixed(2);
  if (u.last === key) return;
  u.last = key;
  const x = u.c.getContext('2d');
  x.clearRect(0, 0, 256, 64); x.fillStyle = 'rgba(0,0,0,.55)'; x.fillRect(0, 0, 256, 64);
  x.fillStyle = u.color; x.font = 'bold 26px sans-serif'; x.textAlign = 'center'; x.fillText(u.text, 128, 28);
  x.fillStyle = '#333'; x.fillRect(38, 40, 180, 14);
  x.fillStyle = frac > 0.5 ? '#5be05b' : frac > 0.25 ? '#ffd23f' : '#ff4d4d';
  x.fillRect(38, 40, 180 * clamp(frac, 0, 1), 14);
  u.tex.needsUpdate = true;
}
function makeChar(shirt, name, color) {
  const g = new THREE.Group();
  const cloth = mat(shirt), skin = mat(0xe0b08c), dark = mat(0x2a2f38);
  const leg = x => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.18, 1, 8).translate(0, -0.5, 0), dark); m.position.set(x, 1.0, 0); return m; };
  const arm = x => { const m = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.11, 0.9, 8).translate(0, -0.45, 0), cloth); m.position.set(x, 1.95, 0); return m; };
  const legL = leg(-0.22), legR = leg(0.22), armL = arm(-0.6), armR = arm(0.6);
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1, 0.5), cloth); torso.position.y = 1.5;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 10), skin); head.position.y = 2.25;
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.31, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), dark); helmet.position.y = 2.3;
  const gun = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.22, 0.8), new THREE.MeshLambertMaterial({ color: 0x3a4a5a, emissive: 0x0a6a7a }));
  gun.position.set(0.6, 1.15, 0.45);
  const label = makeLabel(name, color);
  g.add(legL, legR, torso, head, helmet, armL, armR, gun, label);
  g.userData = { legL, legR, armL, armR, gun, label, phase: 0 };
  return g;
}
function animateChar(g, speed, dt, airborne) {
  const u = g.userData;
  u.phase += dt * speed * 2.4;
  const s = Math.sin(u.phase) * Math.min(1, speed / 5) * 0.8;
  u.legL.rotation.x = airborne ? 0.3 : s;
  u.legR.rotation.x = airborne ? -0.3 : -s;
  u.armL.rotation.x = airborne ? -2.6 : -s;
  u.armR.rotation.x = airborne ? -2.6 : s;
}
function makeEnt(kind, team, name, shirt, id) {
  const g = makeChar(shirt, name, team === 'A' ? '#5cb8ff' : '#ff6a6a');
  g.visible = false; scene.add(g);
  return { kind, team, id, name, g, hp: 100, alive: true, cd: 0, goal: null, offset: null };
}
function randomLand() {
  for (let i = 0; i < 500; i++) {
    const a = rand(0, Math.PI * 2), r = rand(30, R * 0.7);
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (height(x, z) > 2.5 && !inObstacle(x, z, 1)) return V(x, height(x, z), z);
  }
  return V(0, height(0, 0), 0);
}

// ---------- Entities
const player = makeEnt('player', 'A', 'You', 0x2f6b3a, 'me');
Object.assign(player, { vel: V(0, 0, 0), yaw: 0, pitch: 0.35, run: false, med: 0, ammo: 0, blaster: false, kills: 0, state: 'plane', chute: false, fell: false });
player.g.userData.gun.visible = false;
const chute = new THREE.Mesh(new THREE.SphereGeometry(3.2, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), mat(0xff7a2e));
chute.position.y = 4.6; chute.visible = false; player.g.add(chute);
const ripple = new THREE.Mesh(new THREE.RingGeometry(0.7, 1.1, 24).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, depthWrite: false }));
ripple.visible = false; scene.add(ripple);

const bots = [], mates = [], remotes = new Map();
for (let i = 0; i < 14; i++) {
  const b = makeEnt('bot', 'B', `Raider ${i + 1}`, 0x8a3b3b, 'b' + i);
  b.g.position.copy(randomLand()); b.g.visible = true; bots.push(b);
}
const OFF = [[-3, 3], [3, 3], [-6, 6], [6, 6]];
for (let i = 0; i < 4; i++) {
  const m = makeEnt('mate', 'A', `Squad ${i + 1}`, 0x2e7fd1, 'm' + i);
  m.offset = V(OFF[i][0], 0, OFF[i][1]); mates.push(m);
}
const everyone = () => [player, ...mates, ...bots, ...remotes.values()];
function nearestFoe(e, maxD) {
  let best = null, bd = maxD;
  for (const o of everyone()) {
    if (o === e || !o.alive || o.team === e.team || !o.g.visible) continue;
    const d = e.g.position.distanceTo(o.g.position);
    if (d < bd) { bd = d; best = o; }
  }
  return best;
}

// ---------- Plane
const PLANE = { start: V(-R - 180, 230, -40), dir: V(1, 0, 0.22).normalize(), speed: 55 };
PLANE.dur = (2 * R + 420) / PLANE.speed;
const planeMesh = new THREE.Group();
planeMesh.add(new THREE.Mesh(new THREE.CylinderGeometry(1.2, 1.2, 12, 10).rotateZ(Math.PI / 2), mat(0xe8e8ee)));
planeMesh.add(new THREE.Mesh(new THREE.BoxGeometry(3, 0.2, 14), mat(0xc9ccd6)));
const tail = new THREE.Mesh(new THREE.BoxGeometry(0.2, 3, 3), mat(0x2d5fa8)); tail.position.set(-5.5, 1.2, 0);
planeMesh.add(tail);
planeMesh.rotation.y = -Math.atan2(PLANE.dir.z, PLANE.dir.x);
planeMesh.position.copy(PLANE.start);
scene.add(planeMesh);
player.yaw = Math.atan2(-PLANE.dir.x, -PLANE.dir.z);

// ---------- State
let planeT = 0, fireCd = 0, wallCd = 0, shootHeld = false, gameOn = false, time = 0;
let squadReady = false, over = false, msgTimer = 0, sendT = 0;
const feedLines = [];
const joy = { x: 0, y: 0, on: false, id: -1, c: { x: 0, y: 0 } }, look = { id: -1, x: 0, y: 0 };
const aliveCount = () => 1 + bots.filter(b => b.alive).length + [...remotes.values()].filter(r => r.alive).length;
const score = () => player.kills * 100 + Math.floor(time);
const last = {};
function setTxt(id, s) { if (last[id] !== s) { last[id] = s; $(id).textContent = s; } }
function pushMsg(t) { setTxt('msg', t); msgTimer = 2.5; }
function pushFeed(t) { feedLines.push(t); if (feedLines.length > 4) feedLines.shift(); setTxt('feed', feedLines.join('\n')); }
function showOver(title, detail) {
  if (over) return;
  over = true; gameOn = false;
  $('overT').textContent = title;
  $('overS').textContent = `${detail} · Kills ${player.kills} · Score ${score()} · Survived ${Math.floor(time)}s`;
  $('over').classList.remove('hidden');
}
function killPlayer(reason, notify = true) {
  if (!player.alive) return;
  player.alive = false; player.hp = 0; player.g.visible = false;
  burst(player.g.position.clone().setY(0.3), 0x9fe3ff, 26, 8);
  beep(150, 0.5, 'sine', 0.1, -120);
  if (notify) socket.emit('died', { reason });
  showOver('ELIMINATED', reason);
}
function applyDamage(t, dmg, by) {
  if (!t.alive) return;
  if (t.kind === 'remote') { socket.emit('hit', { target: t.id, dmg }); return; }
  t.hp = Math.max(0, t.hp - dmg);
  burst(t.g.position.clone().add(V(0, 1.5, 0)), 0x7ff7ff, 6, 3);
  if (t.hp > 0) return;
  if (t.kind === 'player') killPlayer(`was eliminated by ${by.name}`);
  else killNPC(t, by);
}
function dropCrate(p) {
  const item = ammoPool >= 10 && Math.random() < 0.5 ? (ammoPool -= 10, 'ammo') : 'med';
  const m = new THREE.Mesh(crateGeo, crateMat);
  m.position.set(p.x, height(p.x, p.z), p.z); scene.add(m);
  crates.push({ kind: 'crate', g: m, loot: [item] });
}
const crateGeo = new THREE.BoxGeometry(1.2, 0.9, 1.2).translate(0, 0.45, 0);
const crateMat = mat(0xd9a93d);
function killNPC(e, by) {
  e.alive = false; e.g.visible = false;
  burst(e.g.position.clone().add(V(0, 1, 0)), 0x7ff7ff, 18, 5);
  if (e.team === 'B' && e.g.position.y > -1) dropCrate(e.g.position);
  if (by === player) player.kills++;
  pushFeed(by ? `${by.name} eliminated ${e.name}` : `${e.name} drowned`);
}

// ---------- NPC AI (squad mates and enemy raiders)
function npcShoot(e, t) {
  const a = e.g.position.clone().add(V(0, 1.5, 0)), b = t.g.position.clone().add(V(0, 1.5, 0));
  if (!clear(a, b)) return;
  bolt(a, b, e.team === 'A' ? 0x5ff2ff : 0xff5f7a);
  beep(e.team === 'A' ? 900 : 300, 0.1, 'sawtooth', 0.025, -300);
  if (Math.random() < 0.4) applyDamage(t, e.team === 'A' ? 12 : 6, e);
}
function npcThink(e, dt) {
  if (!e.alive) return;
  if (e.team === 'A' && !squadReady) return;
  e.cd = Math.max(0, e.cd - dt);
  const pos = e.g.position, dir = V(0, 0, 0);
  let speed = 0;
  const foe = nearestFoe(e, e.team === 'A' ? 70 : 60);
  if (e.team === 'A') {
    if (player.alive) {
      const want = e.offset.clone().applyAxisAngle(UP, player.yaw).add(player.g.position);
      const d = pos.distanceTo(want);
      if (d > 3) { dir.subVectors(want, pos); speed = d > 12 ? 9 : 5.5; }
    }
  } else if (foe) {
    if (pos.distanceTo(foe.g.position) > 22) { dir.subVectors(foe.g.position, pos); speed = 4.5; }
  } else {
    if (!e.goal || pos.distanceTo(e.goal) < 3) e.goal = randomLand();
    dir.subVectors(e.goal, pos); speed = 3;
  }
  dir.y = 0;
  if (speed && dir.lengthSq() > 0.01) {
    dir.normalize(); pos.addScaledVector(dir, speed * dt); collide(pos);
    e.g.rotation.y = Math.atan2(dir.x, dir.z);
  } else speed = 0;
  pos.y = height(pos.x, pos.z);
  if (pos.y < -2) { e.hp = 0; killNPC(e, null); return; }
  if (foe && e.cd === 0) { npcShoot(e, foe); e.cd = e.team === 'A' ? 1.1 : 1.6; }
  animateChar(e.g, speed, dt, false);
  drawLabel(e.g.userData.label, e.hp / 100);
  e.g.visible = e.team === 'B' || squadReady;
}

// ---------- Player actions
function desiredMove() {
  const m = V(0, 0, 0);
  if (joy.on) {
    const fx = -Math.sin(player.yaw), fz = -Math.cos(player.yaw);
    const rx = Math.cos(player.yaw), rz = -Math.sin(player.yaw);
    m.x = rx * joy.x - fx * joy.y; m.z = rz * joy.x - fz * joy.y;
    if (m.length() > 1) m.normalize();
  }
  return m;
}
function drop() {
  const p = player;
  p.state = 'free'; p.fell = true; p.g.visible = true;
  p.g.position.copy(planeMesh.position);
  p.vel.copy(PLANE.dir).multiplyScalar(12); p.vel.y = -6;
  planeMesh.visible = false;
  pushMsg('Free fall: tap CHUTE when ready');
}
function jump() {
  if (!gameOn) return;
  if (player.state === 'plane') return drop();
  if (player.state === 'ground') {
    player.state = 'free'; player.vel.y = 7.5; player.fell = false;
    beep(440, 0.12, 'triangle', 0.05, 200);
  }
}
function deployChute() {
  if (!gameOn || player.state !== 'free' || player.chute) return;
  player.chute = true; chute.visible = true; chute.scale.setScalar(0.05);
  pushMsg('Chute open: steer with the joystick');
}
function landed(h) {
  const p = player;
  p.state = 'ground'; p.fell = false; p.chute = false; p.vel.set(0, 0, 0);
  p.g.position.y = h; chute.visible = false;
  burst(p.g.position.clone().setY(h + 0.2), 0xd8c39a, 14, 3);
  if (!squadReady) {
    squadReady = true;
    for (const m of mates) {
      m.alive = true; m.hp = 100; m.g.visible = true;
      m.g.position.copy(p.g.position).add(m.offset.clone().applyAxisAngle(UP, p.yaw));
    }
  }
  pushMsg('Landed: squad regrouping');
}
function updatePlayer(dt) {
  const p = player, pos = p.g.position;
  if (!p.alive) return;
  if (p.state === 'plane') {
    planeT += dt;
    planeMesh.position.copy(PLANE.start).addScaledVector(PLANE.dir, PLANE.speed * planeT);
    if (planeT >= PLANE.dur) drop();
    return;
  }
  const move = desiredMove();
  let h = height(pos.x, pos.z);
  if (p.state === 'ground' && pos.y <= h + 0.3) {
    const sp = (p.run ? 9 : 5) * (h < 0 ? 0.55 : 1);
    pos.x += move.x * sp * dt; pos.z += move.z * sp * dt;
    collide(pos);
    h = height(pos.x, pos.z); pos.y = h;
    if (move.lengthSq() > 0) p.g.rotation.y = Math.atan2(move.x, move.z);
    if (h < -2) return killPlayer('drowned in deep water');
    animateChar(p.g, move.lengthSq() > 0 ? sp : 0, dt, false);
    ripple.visible = h < 0;
    ripple.position.set(pos.x, 0.12, pos.z);
    ripple.scale.setScalar(1 + 0.25 * Math.sin(time * 6));
    scene.fog.color.setHex(pos.y < -0.2 ? 0x2d7fae : SKY);
    return;
  }
  if (p.state === 'ground') p.state = 'free';
  if (!p.chute) {
    p.vel.y = Math.max(p.vel.y - 22 * dt, -50);
    const drag = Math.exp(-0.3 * dt); p.vel.x *= drag; p.vel.z *= drag;
    if (p.fell && pos.y < 60) deployChute();
  } else {
    p.vel.y = -7;
    p.vel.x += (move.x * 14 - p.vel.x) * Math.min(1, 3 * dt);
    p.vel.z += (move.z * 14 - p.vel.z) * Math.min(1, 3 * dt);
  }
  pos.addScaledVector(p.vel, dt);
  if (chute.visible && chute.scale.x < 1) chute.scale.setScalar(Math.min(1, chute.scale.x + dt * 2));
  if (p.vel.y <= 0) {
    h = height(pos.x, pos.z);
    if (pos.y <= h) {
      if (h < -2) return killPlayer('drowned in deep water');
      return landed(h);
    }
  }
  animateChar(p.g, 0, dt, !p.chute);
}
function pickup() {
  if (!gameOn || !player.alive) return;
  const o = nearestLoot();
  if (o) {
    const item = o.loot.shift();
    if (item === 'blaster') { player.blaster = true; player.g.userData.gun.visible = true; pushMsg('Found an ENERGY BLASTER'); }
    if (item === 'ammo') { player.ammo = Math.min(200, player.ammo + 10); pushMsg('+10 energy charges'); }
    if (item === 'med') { player.med++; pushMsg('Health kit collected'); }
    beep(660, 0.1, 'sine', 0.08); setTimeout(() => beep(990, 0.12, 'sine', 0.07), 90);
    if (o.kind === 'crate' && !o.loot.length) { scene.remove(o.g); crates.splice(crates.indexOf(o), 1); }
    return;
  }
  if (player.med > 0 && player.hp < 100) {
    player.med--; player.hp = Math.min(100, player.hp + 40);
    pushMsg('Used a health kit'); beep(520, 0.2, 'sine', 0.08);
  } else pushMsg('Nothing to pick up here');
}
function nearestLoot() {
  let best = null, bd = 99;
  const p = player.g.position;
  for (const o of [...houses, ...crates]) {
    if (!o.loot.length) continue;
    const d = o.kind === 'house'
      ? Math.hypot(Math.max(o.x0 - p.x, 0, p.x - o.x1), Math.max(o.z0 - p.z, 0, p.z - o.z1))
      : p.distanceTo(o.g.position);
    if (d < (o.kind === 'house' ? 3 : 2.5) && d < bd) { bd = d; best = o; }
  }
  return best;
}
function fire() {
  const p = player;
  if (!p.alive || p.state === 'plane' || !p.blaster || p.ammo <= 0 || fireCd > 0) return;
  fireCd = 0.22; p.ammo--;
  beep(900, 0.12, 'sawtooth', 0.04, -600);
  const from = p.g.position.clone().add(V(0, 1.5, 0));
  const fwd = V(-Math.sin(p.yaw), 0, -Math.cos(p.yaw));
  let target = null, best = 0.95;
  for (const e of everyone()) {
    if (e === p || !e.alive || e.team === p.team || !e.g.visible) continue;
    const aim = e.g.position.clone().add(V(0, 1.2, 0));
    const to = aim.clone().sub(from);
    if (to.length() > 110) continue;
    const c = V(to.x, 0, to.z).normalize().dot(fwd);
    if (c > best && clear(from, aim)) { best = c; target = e; }
  }
  const end = target ? target.g.position.clone().add(V(0, 1.2, 0)) : from.clone().addScaledVector(fwd, 120);
  bolt(from, end, 0x5ff2ff);
  if (target) applyDamage(target, 25, p);
}
function buildWall() {
  const p = player;
  if (!gameOn || !p.alive || p.state !== 'ground') return pushMsg('Stand on the ground to build');
  if (wallCd > 0) return;
  wallCd = 1.2;
  const fx = -Math.sin(p.yaw), fz = -Math.cos(p.yaw);
  const c = p.g.position.clone().add(V(fx * 4.5, 0, fz * 4.5));
  const y = height(c.x, c.z), W = 4.2, T = 0.6, H = 3.2;
  const along = Math.abs(fz) > Math.abs(fx);
  const hx = along ? W / 2 : T / 2, hz = along ? T / 2 : W / 2;
  const m = new THREE.Mesh(new THREE.BoxGeometry(hx * 2, H, hz * 2).translate(0, H / 2, 0), mat(0x9aa7b0));
  m.position.set(c.x, y, c.z); m.scale.y = 0.01; scene.add(m);
  const w = { kind: 'wall', g: m, x0: c.x - hx, x1: c.x + hx, z0: c.z - hz, z1: c.z + hz, y0: y - 1, y1: y + H, anim: 0 };
  obstacles.push(w); walls.push(w);
  if (walls.length > 10) { const old = walls.shift(); scene.remove(old.g); obstacles.splice(obstacles.indexOf(old), 1); }
  burst(V(c.x, y + 0.5, c.z), 0xd8c39a, 16, 4);
  beep(180, 0.3, 'square', 0.05, 80);
  pushMsg('Protective wall built');
}
function updateWalls(dt) {
  for (const w of walls) {
    if (w.anim < 1) {
      w.anim = Math.min(1, w.anim + dt / 0.6);
      w.g.scale.y = Math.max(0.01, 1 - Math.pow(1 - w.anim, 3));
    }
  }
}
function updateCamera() {
  if (player.state === 'plane') {
    const pp = planeMesh.position;
    camera.position.set(pp.x - PLANE.dir.x * 26, pp.y + 8, pp.z - PLANE.dir.z * 26);
    camera.lookAt(pp);
    return;
  }
  const target = player.g.position.clone().add(V(0, 2.2, 0));
  const dist = player.state === 'free' ? 13 : 7.5;
  const cp = Math.cos(player.pitch), sp = Math.sin(player.pitch);
  camera.position.set(
    target.x + Math.sin(player.yaw) * cp * dist,
    target.y + sp * dist,
    target.z + Math.cos(player.yaw) * cp * dist
  );
  camera.position.y = Math.max(camera.position.y, height(camera.position.x, camera.position.z) + 1);
  camera.lookAt(target);
}
function syncRemotes(list) {
  for (const id in list) {
    if (id === socket.id) continue;
    const d = list[id];
    let r = remotes.get(id);
    if (!r) {
      r = makeEnt('remote', 'B', d.name, 0x8a3b3b, id);
      r.g.position.set(d.x, d.y, d.z); remotes.set(id, r);
    }
    r.hp = d.hp; r.alive = d.alive; r.ry = d.ry; r.target = V(d.x, d.y, d.z);
    r.g.userData.label.userData.text = d.name;
  }
  for (const [id, r] of remotes) if (!list[id]) { scene.remove(r.g); remotes.delete(id); }
}
function checkEnd() {
  if (!player.alive || player.state !== 'ground' || !squadReady) return;
  if (!bots.some(b => b.alive) && ![...remotes.values()].some(r => r.alive)) showOver('VICTORY ROYALE', 'Last squad standing');
}
function hud(dt) {
  $('hpBar').style.width = player.hp + '%';
  setTxt('hpTxt', Math.ceil(player.hp) + ' HP');
  setTxt('inv', `${player.blaster ? 'Energy Blaster' : 'No weapon'} · Charges ${player.ammo} · Kits ${player.med}`);
  setTxt('squad', mates.map(m => `${m.name} ${m.alive ? Math.ceil(m.hp) + '%' : 'down'}`).join('  ·  '));
  setTxt('stats', `Alive ${aliveCount()} · Kills ${player.kills} · Score ${score()}`);
  const hh = height(player.g.position.x, player.g.position.z);
  const near = nearestLoot();
  let p = '';
  if (player.state === 'plane') p = 'JUMP to drop from the plane';
  else if (player.state === 'ground' && hh < -1) p = 'DEEP WATER AHEAD';
  else if (near) p = near.kind === 'house' ? 'Search house: PICKUP' : 'Open loot box: PICKUP';
  else if (player.state === 'free' && !player.chute && player.fell) p = 'Tap CHUTE to glide';
  setTxt('prompt', p);
  msgTimer -= dt;
  if (msgTimer <= 0) setTxt('msg', '');
  const q = player.g.position;
  setTxt('dbg', `state:${player.state} alive:${player.alive} pos:${q.x.toFixed(0)},${q.y.toFixed(1)},${q.z.toFixed(0)}\njoy:${joy.on ? 'ON' : 'off'} ${joy.x.toFixed(2)},${joy.y.toFixed(2)} blaster:${player.blaster} ammo:${player.ammo} bots:${bots.filter(b => b.alive).length} socket:${socket.id ? 'ok' : 'none'}`);
}
function update(dt) {
  time += dt; fireCd = Math.max(0, fireCd - dt); wallCd = Math.max(0, wallCd - dt);
  updatePlayer(dt);
  if (shootHeld) fire();
  for (const m of mates) npcThink(m, dt);
  for (const b of bots) npcThink(b, dt);
  for (const r of remotes.values()) {
    r.g.position.lerp(r.target, Math.min(1, dt * 10));
    r.g.rotation.y = r.ry;
    r.g.visible = r.alive;
    drawLabel(r.g.userData.label, r.hp / 100);
  }
  drawLabel(player.g.userData.label, player.hp / 100);
  updateBolts(dt); updateParts(dt); updateWalls(dt);
  updateCamera();
  checkEnd();
  hud(dt);
}

// ---------- Input: joystick, camera drag, buttons
const jBase = $('joyBase'), jKnob = $('joyKnob');
function jMove(e) {
  const M = 65;
  let dx = e.clientX - joy.c.x, dy = e.clientY - joy.c.y;
  const L = Math.hypot(dx, dy);
  if (L > M) { dx *= M / L; dy *= M / L; }
  joy.x = dx / M; joy.y = dy / M;
  jKnob.style.transform = `translate(${dx}px,${dy}px)`;
}
addEventListener('pointerdown', e => {
  if (!gameOn || e.target.closest('.btn')) return;
  if (e.clientX < innerWidth * 0.45 && joy.id < 0) {
    joy.id = e.pointerId; joy.on = true; joy.c = { x: e.clientX, y: e.clientY };
    jBase.style.display = 'block'; jBase.style.left = e.clientX + 'px'; jBase.style.top = e.clientY + 'px';
    jMove(e);
  } else if (look.id < 0) {
    look.id = e.pointerId; look.x = e.clientX; look.y = e.clientY;
  }
});
addEventListener('pointermove', e => {
  if (e.pointerId === joy.id) jMove(e);
  if (e.pointerId === look.id) {
    player.yaw -= (e.clientX - look.x) * 0.006;
    player.pitch = clamp(player.pitch + (e.clientY - look.y) * 0.004, -0.1, 1.1);
    look.x = e.clientX; look.y = e.clientY;
  }
});
const endPtr = e => {
  if (e.pointerId === joy.id) { joy.id = -1; joy.on = false; joy.x = joy.y = 0; jBase.style.display = 'none'; }
  if (e.pointerId === look.id) look.id = -1;
};
addEventListener('pointerup', endPtr);
addEventListener('pointercancel', endPtr);
const tap = (id, fn) => $(id).addEventListener('pointerdown', e => { e.preventDefault(); fn(); });
const hold = (id, on, off) => {
  const el = $(id);
  el.addEventListener('pointerdown', e => { e.preventDefault(); on(); });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(t => el.addEventListener(t, off));
};
tap('bJump', jump);
tap('bPick', pickup);
tap('bWall', buildWall);
tap('bChute', deployChute);
hold('bRun', () => { player.run = true; }, () => { player.run = false; });
hold('bShoot', () => { shootHeld = true; }, () => { shootHeld = false; });

// ---------- Networking
const socket = typeof io === 'function' ? io() : { id: null, emit() {}, on() {} };
socket.on('players', list => syncRemotes(list));
socket.on('feed', t => pushFeed(t));
socket.on('hurt', d => {
  player.hp = d.hp;
  burst(player.g.position.clone().setY(player.g.position.y + 1.5), 0x7ff7ff, 6, 3);
});
socket.on('eliminated', d => killPlayer(`was eliminated by ${d.by}`, false));
function send() {
  const p = player.g.position;
  socket.emit('move', { x: p.x, y: p.y, z: p.z, ry: player.yaw, hp: player.hp, alive: player.alive });
}

// ---------- Menu and loop
$('play').onclick = () => {
  ensureAudio();
  player.name = ($('name').value.trim() || 'Soldier').slice(0, 14);
  player.g.userData.label.userData.text = player.name;
  socket.emit('join', player.name);
  $('menu').classList.add('hidden');
  $('hud').classList.remove('hidden');
  gameOn = true;
  pushMsg('Board the plane: tap JUMP to drop');
};
$('restart').onclick = () => location.reload();

let lastT = performance.now();
function frame(now) {
  requestAnimationFrame(frame);
  const dt = Math.min(0.05, (now - lastT) / 1000);
  lastT = now;
  if (gameOn) {
    update(dt);
    sendT += dt;
    if (sendT > 0.1) { sendT = 0; send(); }
  }
  renderer.render(scene, camera);
}
requestAnimationFrame(frame);
window.__gameReady = true;
