import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.nps.tradingjournal',
  appName: 'NPS Journal',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  android: {
    allowMixedContent: true,
    backgroundColor: '#f7f6f3',
  },
  plugins: {
    StatusBar: {
      style: 'LIGHT',
      backgroundColor: '#f7f6f3',
    },
  },
};

export default config;
