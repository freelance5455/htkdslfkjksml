# NPS Trading Journal — Android APK

**Trade with precision. Review with data.**

Build a native Android app (.apk) for phone and tablet.

---

## Build the APK (on your computer)

### Requirements
1. **Node.js 18+** → https://nodejs.org
2. **Android Studio** → https://developer.android.com/studio  
   (install Android SDK + accept licenses)

### Steps

```bash
# 1. Unzip and enter the folder
cd nps-trading-journal

# 2. Install dependencies
npm install

# 3. Add Android platform (first time only)
npx cap add android

# 4. Build web app and sync to Android
npm run android:sync

# 5. Open in Android Studio
npx cap open android
```

### In Android Studio

1. Wait for **Gradle sync** to finish
2. Select a phone or tablet emulator (or connect a real device)
3. Click **Run ▶** to install and launch

### Generate the .apk file

**Option A — Android Studio**
- Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
- When done, click **locate** — the file is:
  `android/app/build/outputs/apk/debug/app-debug.apk`

**Option B — Command line**
```bash
cd android
./gradlew assembleDebug
```
APK path:
`android/app/build/outputs/apk/debug/app-debug.apk`

Copy `app-debug.apk` to your phone and open it to install  
(enable “Install from unknown sources” if asked).

---

## Phone + Tablet

- **Phone** — bottom navigation, stacked cards
- **Tablet** — wider layout, top navigation
- Works offline (local storage)
- Screenshots from camera / gallery
- Backup JSON → share to Google Drive

---

## Other commands

| Command | Description |
|---------|-------------|
| `npm run dev` | Test in browser |
| `npm run android:sync` | Rebuild + sync Android |
| `npx cap open android` | Open Android Studio |
| `npx cap run android` | Build & run on device |

---

## Notes

- First build can take 5–15 minutes (Gradle downloads)
- Debug APK is fine for personal use
- For Play Store you would create a signed release APK/AAB later
