export type Direction = 'LONG' | 'SHORT';
export type Outcome = 'TP1' | 'TP2' | 'TP3' | 'SL' | 'BE' | 'EXPIRED' | 'CUSTOM';
export type NPSGrade = 'A+' | 'A' | 'A-' | 'B+' | 'B' | 'B-' | 'C+' | 'C' | 'C-' | 'D' | 'F';
export type Session = 'Asia' | 'London' | 'New York' | 'Sydney' | 'Custom';
export type MarketRegime = 'TREND_DAY' | 'RANGE_DAY' | 'VOLATILE' | 'LOW_VOL' | 'NEWS_DAY' | 'OTHER';
export type EmotionalState = 'Calm' | 'Focused' | 'FOMO' | 'Fear' | 'Greed' | 'Revenge' | 'Impatient' | 'Confident' | 'Other';
export type FollowStatus = 'YES' | 'NO' | 'PARTIAL';
export type MistakeType =
  | 'Early Entry'
  | 'Late Entry'
  | 'Moved SL'
  | 'Moved TP'
  | 'Overtraded'
  | 'Revenge'
  | 'FOMO'
  | 'Ignored NPS'
  | 'Ignored HTF Bias'
  | 'Other'
  | '';

export interface Trade {
  id: string;
  createdAt: string;
  updatedAt: string;

  // Timing
  date: string; // YYYY-MM-DD
  signalTime?: string;
  entryTime?: string;
  exitTime?: string;

  // Core
  instrument: string;
  direction: Direction;

  // Price levels
  entry: number;
  stopLoss: number;
  tp1: number;
  tp2?: number;
  tp3?: number;
  exitPrice?: number;

  // Calculated
  plannedRr1?: number;
  plannedRr2?: number;
  plannedRr3?: number;
  realizedPnl?: number;
  realizedR?: number;
  durationMinutes?: number;

  // Outcome
  outcome?: Outcome;

  // NPS Signal Data
  npsConfidence?: number; // 0-100
  npsGrade?: NPSGrade;
  setup?: string;
  path?: string;
  htfBias?: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  mtfAlignment?: 'ALIGNED' | 'MIXED' | 'OPPOSED';
  liquidity?: string;
  sweep?: boolean;
  bos?: boolean;
  mss?: boolean;
  displacement?: boolean;
  fvg?: boolean;
  orderBlock?: boolean;
  ote?: 'VALID' | 'INVALID' | 'NONE';
  oteRelevance?: string;
  session?: Session;
  killzone?: string;
  marketRegime?: MarketRegime;

  // Risk
  riskPercent?: number;
  riskAmount?: number;

  // Screenshots (base64 or blob URLs stored as strings)
  signalScreenshot?: string;
  entryScreenshot?: string;
  managementScreenshot?: string;
  outcomeScreenshot?: string;

  // Comments & Psychology
  entryComment?: string;
  exitComment?: string;
  lesson?: string;
  emotionalState?: EmotionalState;
  npsFollowed?: FollowStatus;
  planFollowed?: FollowStatus;
  mistakeType?: MistakeType;

  // Flags
  isMissedSignal?: boolean;
  isDemo?: boolean;
}

export interface Settings {
  accountSize: number;
  defaultRiskPercent: number;
  currency: string;
  timezone: string;
  displayMode: 'Minimal' | 'Standard' | 'Detailed';
  excludeBeFromWinRate: boolean;
}

export interface MissedSignal {
  id: string;
  createdAt: string;
  date: string;
  instrument: string;
  direction: Direction;
  entry: number;
  stopLoss: number;
  tp1: number;
  tp2?: number;
  tp3?: number;
  npsConfidence?: number;
  npsGrade?: NPSGrade;
  setup?: string;
  session?: Session;
  marketRegime?: MarketRegime;
  signalScreenshot?: string;
  hypotheticalOutcome?: Outcome;
  notes?: string;
}

export const INSTRUMENTS = [
  'BTCUSD',
  'ETHUSD',
  'XAUUSD',
  'EURUSD',
  'GBPUSD',
  'USDJPY',
  'US30',
  'NAS100',
  'SPX500',
] as const;

export const SETUPS = [
  'CORE_DISP',
  'OTE_SWEEP',
  'FVG_RETEST',
  'LIQ_SWEEP',
  'MEAN_REVERSION',
  'BOS_CONTINUATION',
  'MSS_REVERSAL',
  'OB_MITIGATION',
  'OTHER',
] as const;

export const DEFAULT_SETTINGS: Settings = {
  accountSize: 10000,
  defaultRiskPercent: 1,
  currency: 'USD',
  timezone: 'Africa/Addis_Ababa',
  displayMode: 'Standard',
  excludeBeFromWinRate: true,
};
