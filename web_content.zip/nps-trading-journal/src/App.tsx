import { useEffect, useState, useMemo } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { db, ensureDemoData, getSettings, saveSettings, exportAllData, importAllData, createLocalBackup } from './lib/db';
import type { Trade, Settings } from './types/trade';
import { DEFAULT_SETTINGS, INSTRUMENTS, SETUPS } from './types/trade';
import {
  calcSummary,
  periodTrades,
  pairPerformance,
  equityCurve,
  setupPerformance,
  sessionPerformance,
  confidenceBands,
  npsVsExecution,
  calcRiskReward,
} from './lib/analytics';
import { formatR, formatPnl, formatPct, rColor } from './lib/utils';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { v4 as uuidv4 } from 'uuid';
import { format, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';

type Page = 'dashboard' | 'trades' | 'analytics' | 'calendar' | 'new-trade' | 'settings' | 'trade-detail';

function App() {
  const [page, setPage] = useState<Page>('dashboard');
  const [selectedTradeId, setSelectedTradeId] = useState<string | null>(null);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [ready, setReady] = useState(false);

  const trades = useLiveQuery(() => db.trades.orderBy('date').reverse().toArray(), []) || [];

  useEffect(() => {
    (async () => {
      await ensureDemoData();
      const s = await getSettings();
      setSettings(s);
      setReady(true);
    })();
  }, []);

  const completed = useMemo(() => trades.filter((t) => t.outcome && !t.isMissedSignal), [trades]);
  const overall = useMemo(() => calcSummary(trades, settings), [trades, settings]);
  const today = useMemo(() => calcSummary(periodTrades(trades, 'today'), settings), [trades, settings]);
  const week = useMemo(() => calcSummary(periodTrades(trades, 'week'), settings), [trades, settings]);
  const month = useMemo(() => calcSummary(periodTrades(trades, 'month'), settings), [trades, settings]);
  const pairs = useMemo(() => pairPerformance(trades), [trades]);
  const equity = useMemo(() => equityCurve(trades, settings.accountSize), [trades, settings.accountSize]);
  const setups = useMemo(() => setupPerformance(trades), [trades]);
  const sessions = useMemo(() => sessionPerformance(trades), [trades]);
  const confBands = useMemo(() => confidenceBands(trades), [trades]);
  const execCompare = useMemo(() => npsVsExecution(trades), [trades]);

  const openTrade = (id: string) => {
    setSelectedTradeId(id);
    setPage('trade-detail');
  };

  if (!ready) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', color: 'var(--text-muted)' }}>
        Loading NPS Journal…
      </div>
    );
  }

  return (
    <div className="app-shell">
      <nav className="top-nav">
        <div className="nav-brand">
          NPS <span>JOURNAL</span>
        </div>
        <div className="nav-links">
          {(['dashboard', 'trades', 'analytics', 'calendar'] as const).map((p) => (
            <button
              key={p}
              className={`nav-link ${page === p ? 'active' : ''}`}
              onClick={() => setPage(p)}
            >
              {p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>
        <div className="nav-actions">
          <button className="btn-ghost" onClick={() => setPage('settings')} title="Settings">
            ⚙️
          </button>
          <button className="btn btn-primary" onClick={() => setPage('new-trade')}>
            + New Trade
          </button>
        </div>
      </nav>

      <main className="main-content">
        {page === 'dashboard' && (
          <Dashboard
            today={today}
            week={week}
            month={month}
            overall={overall}
            pairs={pairs}
            equity={equity}
            trades={completed.slice(0, 5)}
            onNewTrade={() => setPage('new-trade')}
            onViewTrade={openTrade}
            onViewAnalytics={() => setPage('analytics')}
          />
        )}
        {page === 'trades' && (
          <TradesPage trades={completed} onSelect={openTrade} />
        )}
        {page === 'analytics' && (
          <AnalyticsPage
            overall={overall}
            pairs={pairs}
            setups={setups}
            sessions={sessions}
            confBands={confBands}
            execCompare={execCompare}
            equity={equity}
          />
        )}
        {page === 'calendar' && (
          <CalendarPage trades={completed} />
        )}
        {page === 'new-trade' && (
          <NewTradePage
            settings={settings}
            onSaved={() => setPage('trades')}
            onCancel={() => setPage('dashboard')}
          />
        )}
        {page === 'settings' && (
          <SettingsPage
            settings={settings}
            onSave={async (s) => {
              await saveSettings(s);
              setSettings(s);
            }}
            onBack={() => setPage('dashboard')}
          />
        )}
        {page === 'trade-detail' && selectedTradeId && (
          <TradeDetailPage
            trade={trades.find((t) => t.id === selectedTradeId)!}
            onBack={() => setPage('trades')}
          />
        )}
      </main>

      <div className="mobile-nav">
        {(['dashboard', 'trades', 'analytics', 'calendar'] as const).map((p) => (
          <button key={p} className={page === p ? 'active' : ''} onClick={() => setPage(p)}>
            {p === 'dashboard' ? '🏠' : p === 'trades' ? '📋' : p === 'analytics' ? '📊' : '📅'}
            <span>{p.charAt(0).toUpperCase() + p.slice(1)}</span>
          </button>
        ))}
        <button onClick={() => setPage('new-trade')}>
          ➕
          <span>New</span>
        </button>
      </div>
    </div>
  );
}

function Dashboard({
  today, week, month, overall, pairs, equity, trades, onNewTrade, onViewTrade, onViewAnalytics,
}: any) {
  const [range, setRange] = useState('1M');

  return (
    <>
      <div className="hero">
        <div className="eyebrow">NPS TRADING JOURNAL</div>
        <h1>
          Trade with precision.
          <br />
          Review with data.
        </h1>
        <p>
          Your complete NPS trading record — from signal and entry screenshots to outcome, P/L,
          execution quality, and long-term performance.
        </p>
        <div className="hero-actions">
          <button className="btn btn-primary" onClick={onNewTrade}>
            + New Trade
          </button>
          <button className="btn btn-secondary" onClick={onViewAnalytics}>
            View Analytics
          </button>
        </div>
      </div>

      <div className="summary-row">
        <div className="summary-card">
          <div className="label">Today</div>
          <div className={`value ${today.netR >= 0 ? 'positive' : 'negative'}`}>
            {formatR(today.netR)}
          </div>
          <div className="meta">
            {formatPnl(today.netPnl)} · {today.total} trades
          </div>
        </div>
        <div className="summary-card">
          <div className="label">This Week</div>
          <div className={`value ${week.netR >= 0 ? 'positive' : 'negative'}`}>
            {formatR(week.netR)}
          </div>
          <div className="meta">
            {formatPnl(week.netPnl)} · {week.total} trades
          </div>
        </div>
        <div className="summary-card">
          <div className="label">This Month</div>
          <div className={`value ${month.netR >= 0 ? 'positive' : 'negative'}`}>
            {formatR(month.netR)}
          </div>
          <div className="meta">
            {formatPnl(month.netPnl)} · {month.total} trades
          </div>
        </div>
        <div className="summary-card">
          <div className="label">Win Rate</div>
          <div className="value">{overall.wins}/{overall.losses}/{overall.be}</div>
          <div className="meta">{formatPct(overall.winRate)} Win / Loss / BE</div>
        </div>
      </div>

      <div className="perf-grid">
        <div className="card">
          <h2 style={{ fontSize: 20, fontWeight: 700, marginBottom: 8 }}>
            Your Trading Performance,
            <br />
            Fully Documented.
          </h2>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 20 }}>
            From entry to exit — every trade, every decision, all in one place. Build better habits,
            find your edge, and grow consistently.
          </p>
          <div className="feature-list">
            <div className="feature-item">
              <div className="icon">📸</div>
              <div className="text">
                <strong>Full Trade Screenshots</strong>
                <span>Entry & Exit Evidence</span>
              </div>
            </div>
            <div className="feature-item">
              <div className="icon">∑</div>
              <div className="text">
                <strong>Auto P/L Calculation</strong>
                <span>R, $ and %</span>
              </div>
            </div>
            <div className="feature-item">
              <div className="icon">💾</div>
              <div className="text">
                <strong>Local Storage</strong>
                <span>Your Data. Always Yours.</span>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div className="card-title">Equity Curve</div>
            <div className="chart-tabs">
              {['7D', '30D', '1M', '1Y', 'ALL'].map((r) => (
                <button
                  key={r}
                  className={`chart-tab ${range === r ? 'active' : ''}`}
                  onClick={() => setRange(r)}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
          <div style={{ height: 220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={equity.points}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={(d) => d.slice(5)} />
                <YAxis tick={{ fontSize: 11 }} domain={['auto', 'auto']} />
                <Tooltip
                  contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e8e6e1' }}
                  formatter={(v: number) => [`$${v.toFixed(0)}`, 'Equity']}
                />
                <Line
                  type="monotone"
                  dataKey="equity"
                  stroke="#1a7f4b"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <div className="card-title">Top Performing Pair</div>
          <div className="pair-list">
            {pairs.slice(0, 5).map((p: any) => (
              <div className="pair-row" key={p.pair}>
                <div className="name">
                  <span className={`dot ${p.netR > 0 ? 'pos' : p.netR < 0 ? 'neg' : 'neu'}`} />
                  {p.pair}
                </div>
                <span className={p.netR > 0 ? 'positive' : p.netR < 0 ? 'negative' : 'neutral'}>
                  {formatR(p.netR)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {trades[0] && (
        <div className="dna-bar">
          <div style={{ fontSize: 12, fontWeight: 600, marginRight: 12, whiteSpace: 'nowrap' }}>
            NPS TRADE DNA
            <div style={{ fontWeight: 400, color: 'var(--text-muted)', fontSize: 11 }}>
              The full context of every trade, at a glance.
            </div>
          </div>
          {[
            { label: 'Pair', value: trades[0].instrument },
            { label: 'Direction', value: trades[0].direction },
            { label: 'NPS Grade', value: trades[0].npsGrade },
            { label: 'Confidence', value: trades[0].npsConfidence ? `${trades[0].npsConfidence}%` : '—' },
            { label: 'Setup', value: trades[0].setup },
            { label: 'Session', value: trades[0].session },
            { label: 'Outcome', value: trades[0].outcome },
            { label: 'R Multiple', value: formatR(trades[0].realizedR) },
          ].map((item) => (
            <div className="dna-item" key={item.label}>
              <span className="dna-label">{item.label}</span>
              <span className="dna-value">{item.value || '—'}</span>
            </div>
          ))}
        </div>
      )}

      <div className="section">
        <div className="section-header">
          <h2 style={{ fontSize: 18 }}>Recent Trades</h2>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Date & Time</th>
                <th>Pair</th>
                <th>Direction</th>
                <th>Setup</th>
                <th>Outcome</th>
                <th>P/L (R)</th>
                <th>Grade</th>
              </tr>
            </thead>
            <tbody>
              {trades.map((t: Trade) => (
                <tr key={t.id} style={{ cursor: 'pointer' }} onClick={() => onViewTrade(t.id)}>
                  <td>
                    {t.date.slice(5)} {t.entryTime || ''}
                  </td>
                  <td style={{ fontWeight: 600 }}>{t.instrument}</td>
                  <td>
                    <span className={`badge ${t.direction === 'LONG' ? 'badge-long' : 'badge-short'}`}>
                      {t.direction === 'LONG' ? '↑' : '↓'} {t.direction}
                    </span>
                  </td>
                  <td>{t.setup || '—'}</td>
                  <td>
                    <span
                      className={`badge ${
                        t.outcome === 'SL' ? 'badge-sl' : t.outcome === 'BE' ? 'badge-be' : 'badge-tp'
                      }`}
                    >
                      {t.outcome}
                    </span>
                  </td>
                  <td style={{ color: rColor(t.realizedR), fontWeight: 600 }}>
                    {formatR(t.realizedR)}
                  </td>
                  <td>{t.npsGrade || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

function TradesPage({ trades, onSelect }: { trades: Trade[]; onSelect: (id: string) => void }) {
  const [filterPair, setFilterPair] = useState('');
  const [filterOutcome, setFilterOutcome] = useState('');
  const [search, setSearch] = useState('');

  const filtered = trades.filter((t) => {
    if (filterPair && t.instrument !== filterPair) return false;
    if (filterOutcome && t.outcome !== filterOutcome) return false;
    if (search && !t.instrument.toLowerCase().includes(search.toLowerCase()) && !(t.setup || '').toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: 28, fontWeight: 700 }}>Trades</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <input
            placeholder="Search…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ padding: '8px 12px', border: '1px solid var(--border)', borderRadius: 6, fontSize: 13 }}
          />
          <select
            value={filterPair}
            onChange={(e) => setFilterPair(e.target.value)}
            style={{ padding: '8px 12px', border: '1px solid var(--border)', borderRadius: 6, fontSize: 13 }}
          >
            <option value="">All Pairs</option>
            {INSTRUMENTS.map((i) => (
              <option key={i} value={i}>{i}</option>
            ))}
          </select>
          <select
            value={filterOutcome}
            onChange={(e) => setFilterOutcome(e.target.value)}
            style={{ padding: '8px 12px', border: '1px solid var(--border)', borderRadius: 6, fontSize: 13 }}
          >
            <option value="">All Outcomes</option>
            {['TP1', 'TP2', 'TP3', 'SL', 'BE', 'EXPIRED'].map((o) => (
              <option key={o} value={o}>{o}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Pair</th>
              <th>Dir</th>
              <th>Setup</th>
              <th>Entry</th>
              <th>SL</th>
              <th>TP1</th>
              <th>Outcome</th>
              <th>R</th>
              <th>Grade</th>
              <th>Session</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((t) => (
              <tr key={t.id} style={{ cursor: 'pointer' }} onClick={() => onSelect(t.id)}>
                <td>{t.date}</td>
                <td style={{ fontWeight: 600 }}>{t.instrument}</td>
                <td>
                  <span className={`badge ${t.direction === 'LONG' ? 'badge-long' : 'badge-short'}`}>
                    {t.direction}
                  </span>
                </td>
                <td>{t.setup || '—'}</td>
                <td>{t.entry}</td>
                <td>{t.stopLoss}</td>
                <td>{t.tp1}</td>
                <td>
                  <span
                    className={`badge ${
                      t.outcome === 'SL' ? 'badge-sl' : t.outcome === 'BE' ? 'badge-be' : 'badge-tp'
                    }`}
                  >
                    {t.outcome}
                  </span>
                </td>
                <td style={{ color: rColor(t.realizedR), fontWeight: 600 }}>{formatR(t.realizedR)}</td>
                <td>{t.npsGrade || '—'}</td>
                <td>{t.session || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {filtered.length === 0 && (
        <div className="empty-state">
          <h3>No trades match</h3>
          <p>Adjust filters or add a new trade.</p>
        </div>
      )}
    </div>
  );
}

function AnalyticsPage({ overall, pairs, setups, sessions, confBands, execCompare, equity }: any) {
  return (
    <div>
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 24 }}>Analytics</h1>

      <div className="metrics-grid">
        {[
          { label: 'Total Trades', value: overall.total },
          { label: 'Win Rate', value: formatPct(overall.winRate) },
          { label: 'Net R', value: formatR(overall.netR) },
          { label: 'Net P/L', value: formatPnl(overall.netPnl) },
          { label: 'Avg R', value: formatR(overall.avgR) },
          { label: 'Profit Factor', value: overall.profitFactor === Infinity ? '∞' : overall.profitFactor.toFixed(2) },
          { label: 'Expectancy', value: formatR(overall.expectancy) },
          { label: 'Max Drawdown', value: `$${equity.maxDrawdown.toFixed(0)}` },
        ].map((m) => (
          <div className="metric-card" key={m.label}>
            <div className="m-label">{m.label}</div>
            <div className="m-value">{m.value}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 32 }}>
        <div className="card">
          <div className="card-title">Pair Performance</div>
          <div className="table-wrap" style={{ border: 'none' }}>
            <table>
              <thead>
                <tr>
                  <th>Pair</th>
                  <th>Trades</th>
                  <th>Win%</th>
                  <th>Net R</th>
                </tr>
              </thead>
              <tbody>
                {pairs.map((p: any) => (
                  <tr key={p.pair}>
                    <td style={{ fontWeight: 600 }}>{p.pair}</td>
                    <td>{p.trades}</td>
                    <td>{formatPct(p.winRate)}</td>
                    <td style={{ color: rColor(p.netR) }}>{formatR(p.netR)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div className="card-title">Setup Performance</div>
          <div className="table-wrap" style={{ border: 'none' }}>
            <table>
              <thead>
                <tr>
                  <th>Setup</th>
                  <th>Trades</th>
                  <th>Win%</th>
                  <th>Net R</th>
                </tr>
              </thead>
              <tbody>
                {setups.map((s: any) => (
                  <tr key={s.setup}>
                    <td style={{ fontWeight: 600 }}>{s.setup}</td>
                    <td>{s.total}</td>
                    <td>{formatPct(s.winRate)}</td>
                    <td style={{ color: rColor(s.netR) }}>{formatR(s.netR)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 32 }}>
        <div className="card">
          <div className="card-title">Session Performance</div>
          <div className="table-wrap" style={{ border: 'none' }}>
            <table>
              <thead>
                <tr>
                  <th>Session</th>
                  <th>Trades</th>
                  <th>Win%</th>
                  <th>Net R</th>
                </tr>
              </thead>
              <tbody>
                {sessions.map((s: any) => (
                  <tr key={s.session}>
                    <td style={{ fontWeight: 600 }}>{s.session}</td>
                    <td>{s.total}</td>
                    <td>{formatPct(s.winRate)}</td>
                    <td style={{ color: rColor(s.netR) }}>{formatR(s.netR)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div className="card-title">Confidence Calibration</div>
          <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 12 }}>
            NPS Confidence vs Observed Outcome Rate
          </p>
          <div className="table-wrap" style={{ border: 'none' }}>
            <table>
              <thead>
                <tr>
                  <th>Band</th>
                  <th>Trades</th>
                  <th>Win%</th>
                  <th>Avg R</th>
                </tr>
              </thead>
              <tbody>
                {confBands.map((b: any) => (
                  <tr key={b.label}>
                    <td>{b.label}</td>
                    <td>{b.trades}</td>
                    <td>{formatPct(b.winRate)}</td>
                    <td style={{ color: rColor(b.avgR) }}>{formatR(b.avgR)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">NPS vs Execution</div>
        <p style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 16 }}>
          Compare system-compliant trades against non-compliant execution.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          <div>
            <h4 style={{ fontSize: 13, marginBottom: 8 }}>NPS Compliant (YES)</h4>
            <div className="metrics-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
              <div className="metric-card">
                <div className="m-label">Trades</div>
                <div className="m-value">{execCompare.compliant.total}</div>
              </div>
              <div className="metric-card">
                <div className="m-label">Win Rate</div>
                <div className="m-value">{formatPct(execCompare.compliant.winRate)}</div>
              </div>
              <div className="metric-card">
                <div className="m-label">Net R</div>
                <div className="m-value" style={{ color: rColor(execCompare.compliant.netR) }}>
                  {formatR(execCompare.compliant.netR)}
                </div>
              </div>
              <div className="metric-card">
                <div className="m-label">Avg R</div>
                <div className="m-value">{formatR(execCompare.compliant.avgR)}</div>
              </div>
            </div>
          </div>
          <div>
            <h4 style={{ fontSize: 13, marginBottom: 8 }}>Non-Compliant (NO / PARTIAL)</h4>
            <div className="metrics-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
              <div className="metric-card">
                <div className="m-label">Trades</div>
                <div className="m-value">{execCompare.nonCompliant.total}</div>
              </div>
              <div className="metric-card">
                <div className="m-label">Win Rate</div>
                <div className="m-value">{formatPct(execCompare.nonCompliant.winRate)}</div>
              </div>
              <div className="metric-card">
                <div className="m-label">Net R</div>
                <div className="m-value" style={{ color: rColor(execCompare.nonCompliant.netR) }}>
                  {formatR(execCompare.nonCompliant.netR)}
                </div>
              </div>
              <div className="metric-card">
                <div className="m-label">Avg R</div>
                <div className="m-value">{formatR(execCompare.nonCompliant.avgR)}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CalendarPage({ trades }: { trades: Trade[] }) {
  const now = new Date();
  const days = eachDayOfInterval({ start: startOfMonth(now), end: endOfMonth(now) });

  const byDay = useMemo(() => {
    const map = new Map<string, Trade[]>();
    trades.forEach((t) => {
      const arr = map.get(t.date) || [];
      arr.push(t);
      map.set(t.date, arr);
    });
    return map;
  }, [trades]);

  return (
    <div>
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 8 }}>
        {format(now, 'MMMM yyyy')}
      </h1>
      <p style={{ color: 'var(--text-secondary)', marginBottom: 24 }}>Trading calendar</p>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(7, 1fr)',
          gap: 8,
        }}
      >
        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => (
          <div key={d} style={{ textAlign: 'center', fontSize: 12, color: 'var(--text-muted)', padding: 8 }}>
            {d}
          </div>
        ))}
        {Array.from({ length: (days[0].getDay() + 6) % 7 }).map((_, i) => (
          <div key={`empty-${i}`} />
        ))}
        {days.map((day) => {
          const key = format(day, 'yyyy-MM-dd');
          const dayTrades = byDay.get(key) || [];
          const netR = dayTrades.reduce((s, t) => s + (t.realizedR || 0), 0);
          const color =
            dayTrades.length === 0
              ? 'transparent'
              : netR > 0
              ? 'var(--positive-bg)'
              : netR < 0
              ? 'var(--negative-bg)'
              : 'var(--neutral-bg)';
          return (
            <div
              key={key}
              style={{
                background: color,
                border: '1px solid var(--border)',
                borderRadius: 8,
                padding: 10,
                minHeight: 72,
                cursor: dayTrades.length ? 'pointer' : 'default',
              }}
            >
              <div style={{ fontSize: 13, fontWeight: 600 }}>{format(day, 'd')}</div>
              {dayTrades.length > 0 && (
                <>
                  <div style={{ fontSize: 11, marginTop: 4 }}>{dayTrades.length} trade{dayTrades.length > 1 ? 's' : ''}</div>
                  <div
                    style={{
                      fontSize: 12,
                      fontWeight: 600,
                      color: netR > 0 ? 'var(--positive)' : netR < 0 ? 'var(--negative)' : 'var(--neutral)',
                    }}
                  >
                    {formatR(netR)}
                  </div>
                </>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function NewTradePage({
  settings,
  onSaved,
  onCancel,
}: {
  settings: Settings;
  onSaved: () => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState<Partial<Trade>>({
    date: format(new Date(), 'yyyy-MM-dd'),
    direction: 'LONG',
    instrument: 'BTCUSD',
    riskPercent: settings.defaultRiskPercent,
    riskAmount: (settings.accountSize * settings.defaultRiskPercent) / 100,
    npsFollowed: 'YES',
    planFollowed: 'YES',
  });
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [saving, setSaving] = useState(false);

  const update = (key: keyof Trade, value: any) => {
    setForm((f) => {
      const next = { ...f, [key]: value };
      if (['entry', 'stopLoss', 'tp1', 'tp2', 'tp3', 'direction'].includes(key)) {
        const entry = Number(next.entry) || 0;
        const sl = Number(next.stopLoss) || 0;
        const dir = next.direction || 'LONG';
        if (entry && sl) {
          if (next.tp1) next.plannedRr1 = calcRiskReward(entry, sl, Number(next.tp1), dir as any);
          if (next.tp2) next.plannedRr2 = calcRiskReward(entry, sl, Number(next.tp2), dir as any);
          if (next.tp3) next.plannedRr3 = calcRiskReward(entry, sl, Number(next.tp3), dir as any);
        }
      }
      if (key === 'outcome' || key === 'exitPrice' || key === 'realizedR') {
        const entry = Number(next.entry) || 0;
        const sl = Number(next.stopLoss) || 0;
        const risk = Math.abs(entry - sl);
        if (next.outcome === 'BE') {
          next.realizedR = 0;
          next.realizedPnl = 0;
        } else if (next.outcome === 'SL') {
          next.realizedR = -1;
          next.realizedPnl = -(next.riskAmount || 0);
        } else if (next.realizedR != null && next.riskAmount) {
          next.realizedPnl = next.realizedR * next.riskAmount;
        } else if (next.exitPrice && risk > 0) {
          const dir = next.direction || 'LONG';
          const reward = dir === 'LONG' ? Number(next.exitPrice) - entry : entry - Number(next.exitPrice);
          next.realizedR = reward / risk;
          next.realizedPnl = (next.realizedR || 0) * (next.riskAmount || 0);
        }
      }
      return next;
    });
  };

  const handleScreenshot = (field: 'signalScreenshot' | 'entryScreenshot' | 'outcomeScreenshot', file: File) => {
    const reader = new FileReader();
    reader.onload = () => update(field, reader.result as string);
    reader.readAsDataURL(file);
  };

  const save = async () => {
    if (!form.instrument || !form.entry || !form.stopLoss || !form.tp1) {
      alert('Please fill required fields: Instrument, Entry, SL, TP1');
      return;
    }
    setSaving(true);
    const trade: Trade = {
      id: uuidv4(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      date: form.date || format(new Date(), 'yyyy-MM-dd'),
      instrument: form.instrument!,
      direction: form.direction || 'LONG',
      entry: Number(form.entry),
      stopLoss: Number(form.stopLoss),
      tp1: Number(form.tp1),
      tp2: form.tp2 ? Number(form.tp2) : undefined,
      tp3: form.tp3 ? Number(form.tp3) : undefined,
      exitPrice: form.exitPrice ? Number(form.exitPrice) : undefined,
      outcome: form.outcome,
      realizedR: form.realizedR,
      realizedPnl: form.realizedPnl,
      plannedRr1: form.plannedRr1,
      plannedRr2: form.plannedRr2,
      plannedRr3: form.plannedRr3,
      npsConfidence: form.npsConfidence,
      npsGrade: form.npsGrade,
      setup: form.setup,
      path: form.path,
      htfBias: form.htfBias,
      mtfAlignment: form.mtfAlignment,
      sweep: form.sweep,
      bos: form.bos,
      mss: form.mss,
      displacement: form.displacement,
      fvg: form.fvg,
      orderBlock: form.orderBlock,
      ote: form.ote,
      session: form.session,
      marketRegime: form.marketRegime,
      riskPercent: form.riskPercent,
      riskAmount: form.riskAmount,
      signalScreenshot: form.signalScreenshot,
      entryScreenshot: form.entryScreenshot,
      outcomeScreenshot: form.outcomeScreenshot,
      entryComment: form.entryComment,
      exitComment: form.exitComment,
      lesson: form.lesson,
      emotionalState: form.emotionalState,
      npsFollowed: form.npsFollowed,
      planFollowed: form.planFollowed,
      mistakeType: form.mistakeType,
      signalTime: form.signalTime,
      entryTime: form.entryTime,
      exitTime: form.exitTime,
    };
    await db.trades.add(trade);
    await createLocalBackup();
    setSaving(false);
    onSaved();
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: 28, fontWeight: 700 }}>New Trade</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? 'Saving…' : 'Save Trade'}
          </button>
        </div>
      </div>

      <div className="form-section">
        <h3>Basic Information</h3>
        <div className="form-grid">
          <div className="form-group">
            <label>Date</label>
            <input type="date" value={form.date || ''} onChange={(e) => update('date', e.target.value)} />
          </div>
          <div className="form-group">
            <label>Instrument</label>
            <select value={form.instrument || ''} onChange={(e) => update('instrument', e.target.value)}>
              {INSTRUMENTS.map((i) => (
                <option key={i} value={i}>{i}</option>
              ))}
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div className="form-group">
            <label>Direction</label>
            <div className="chip-group">
              <button
                type="button"
                className={`chip ${form.direction === 'LONG' ? 'active pos' : ''}`}
                onClick={() => update('direction', 'LONG')}
              >
                LONG
              </button>
              <button
                type="button"
                className={`chip ${form.direction === 'SHORT' ? 'active neg' : ''}`}
                onClick={() => update('direction', 'SHORT')}
              >
                SHORT
              </button>
            </div>
          </div>
          <div className="form-group">
            <label>Session</label>
            <select value={form.session || ''} onChange={(e) => update('session', e.target.value)}>
              <option value="">—</option>
              {['Asia', 'London', 'New York', 'Sydney'].map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      <div className="form-section">
        <h3>Price Levels</h3>
        <div className="form-grid">
          <div className="form-group">
            <label>Entry</label>
            <input type="number" step="any" value={form.entry ?? ''} onChange={(e) => update('entry', e.target.value)} />
          </div>
          <div className="form-group">
            <label>Stop Loss</label>
            <input type="number" step="any" value={form.stopLoss ?? ''} onChange={(e) => update('stopLoss', e.target.value)} />
          </div>
          <div className="form-group">
            <label>TP1</label>
            <input type="number" step="any" value={form.tp1 ?? ''} onChange={(e) => update('tp1', e.target.value)} />
          </div>
          <div className="form-group">
            <label>TP2</label>
            <input type="number" step="any" value={form.tp2 ?? ''} onChange={(e) => update('tp2', e.target.value)} />
          </div>
          <div className="form-group">
            <label>TP3</label>
            <input type="number" step="any" value={form.tp3 ?? ''} onChange={(e) => update('tp3', e.target.value)} />
          </div>
        </div>
        {(form.plannedRr1 || form.plannedRr2) && (
          <div style={{ marginTop: 12, fontSize: 13, color: 'var(--text-secondary)' }}>
            Planned RR — TP1: {form.plannedRr1?.toFixed(2)}R
            {form.plannedRr2 ? ` · TP2: ${form.plannedRr2.toFixed(2)}R` : ''}
            {form.plannedRr3 ? ` · TP3: ${form.plannedRr3.toFixed(2)}R` : ''}
          </div>
        )}
      </div>

      <div className="form-section">
        <h3>NPS Signal Data</h3>
        <div className="form-grid">
          <div className="form-group">
            <label>NPS Confidence %</label>
            <input
              type="number"
              min={0}
              max={100}
              value={form.npsConfidence ?? ''}
              onChange={(e) => update('npsConfidence', Number(e.target.value))}
            />
          </div>
          <div className="form-group">
            <label>NPS Grade</label>
            <select value={form.npsGrade || ''} onChange={(e) => update('npsGrade', e.target.value)}>
              <option value="">—</option>
              {['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-'].map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Setup</label>
            <select value={form.setup || ''} onChange={(e) => update('setup', e.target.value)}>
              <option value="">—</option>
              {SETUPS.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>OTE</label>
            <select value={form.ote || ''} onChange={(e) => update('ote', e.target.value)}>
              <option value="">—</option>
              <option value="VALID">VALID</option>
              <option value="INVALID">INVALID</option>
              <option value="NONE">NONE</option>
            </select>
          </div>
          <div className="form-group">
            <label>HTF Bias</label>
            <select value={form.htfBias || ''} onChange={(e) => update('htfBias', e.target.value)}>
              <option value="">—</option>
              <option value="BULLISH">BULLISH</option>
              <option value="BEARISH">BEARISH</option>
              <option value="NEUTRAL">NEUTRAL</option>
            </select>
          </div>
          <div className="form-group">
            <label>Market Regime</label>
            <select value={form.marketRegime || ''} onChange={(e) => update('marketRegime', e.target.value)}>
              <option value="">—</option>
              {['TREND_DAY', 'RANGE_DAY', 'VOLATILE', 'LOW_VOL', 'NEWS_DAY'].map((r) => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>
        </div>

        <button
          type="button"
          className="btn-ghost"
          style={{ marginTop: 12 }}
          onClick={() => setShowAdvanced(!showAdvanced)}
        >
          {showAdvanced ? 'Hide' : 'Show'} Advanced NPS Fields
        </button>

        {showAdvanced && (
          <div className="form-grid" style={{ marginTop: 16 }}>
            {[
              { key: 'sweep', label: 'Liquidity Sweep' },
              { key: 'bos', label: 'BOS' },
              { key: 'mss', label: 'MSS / CHoCH' },
              { key: 'displacement', label: 'Displacement' },
              { key: 'fvg', label: 'FVG' },
              { key: 'orderBlock', label: 'Order Block' },
            ].map(({ key, label }) => (
              <div className="form-group" key={key}>
                <label>{label}</label>
                <div className="chip-group">
                  <button
                    type="button"
                    className={`chip ${(form as any)[key] === true ? 'active' : ''}`}
                    onClick={() => update(key as any, true)}
                  >
                    YES
                  </button>
                  <button
                    type="button"
                    className={`chip ${(form as any)[key] === false ? 'active' : ''}`}
                    onClick={() => update(key as any, false)}
                  >
                    NO
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="form-section">
        <h3>Outcome</h3>
        <div className="form-grid">
          <div className="form-group">
            <label>Outcome</label>
            <div className="chip-group">
              {['TP1', 'TP2', 'TP3', 'SL', 'BE', 'EXPIRED'].map((o) => (
                <button
                  key={o}
                  type="button"
                  className={`chip ${form.outcome === o ? 'active' : ''} ${
                    o === 'SL' ? 'neg' : o === 'BE' ? '' : 'pos'
                  }`}
                  onClick={() => update('outcome', o)}
                >
                  {o}
                </button>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label>Exit Price</label>
            <input
              type="number"
              step="any"
              value={form.exitPrice ?? ''}
              onChange={(e) => update('exitPrice', e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Realized R</label>
            <input
              type="number"
              step="0.1"
              value={form.realizedR ?? ''}
              onChange={(e) => update('realizedR', Number(e.target.value))}
            />
          </div>
          <div className="form-group">
            <label>Realized P/L ($)</label>
            <input
              type="number"
              step="0.01"
              value={form.realizedPnl ?? ''}
              onChange={(e) => update('realizedPnl', Number(e.target.value))}
            />
          </div>
        </div>
      </div>

      <div className="form-section">
        <h3>Screenshots</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
          {([
            ['signalScreenshot', 'Signal'],
            ['entryScreenshot', 'Entry'],
            ['outcomeScreenshot', 'Outcome'],
          ] as const).map(([field, label]) => (
            <div key={field}>
              <label style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-secondary)' }}>{label}</label>
              <div
                className="upload-zone"
                onClick={() => document.getElementById(`file-${field}`)?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  const f = e.dataTransfer.files[0];
                  if (f) handleScreenshot(field, f);
                }}
              >
                {(form as any)[field] ? (
                  <img src={(form as any)[field]} className="upload-preview" alt={label} />
                ) : (
                  <p>Click or drop image</p>
                )}
              </div>
              <input
                id={`file-${field}`}
                type="file"
                accept="image/*"
                style={{ display: 'none' }}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleScreenshot(field, f);
                }}
              />
            </div>
          ))}
        </div>
      </div>

      <div className="form-section">
        <h3>Execution & Psychology</h3>
        <div className="form-grid">
          <div className="form-group">
            <label>Followed NPS?</label>
            <div className="chip-group">
              {['YES', 'NO', 'PARTIAL'].map((v) => (
                <button
                  key={v}
                  type="button"
                  className={`chip ${form.npsFollowed === v ? 'active' : ''}`}
                  onClick={() => update('npsFollowed', v)}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label>Followed Plan?</label>
            <div className="chip-group">
              {['YES', 'NO', 'PARTIAL'].map((v) => (
                <button
                  key={v}
                  type="button"
                  className={`chip ${form.planFollowed === v ? 'active' : ''}`}
                  onClick={() => update('planFollowed', v)}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label>Emotional State</label>
            <select value={form.emotionalState || ''} onChange={(e) => update('emotionalState', e.target.value)}>
              <option value="">—</option>
              {['Calm', 'Focused', 'FOMO', 'Fear', 'Greed', 'Revenge', 'Impatient', 'Confident'].map((e) => (
                <option key={e} value={e}>{e}</option>
              ))}
            </select>
          </div>
          <div className="form-group">
            <label>Mistake</label>
            <select value={form.mistakeType || ''} onChange={(e) => update('mistakeType', e.target.value)}>
              <option value="">None</option>
              {['Early Entry', 'Late Entry', 'Moved SL', 'Moved TP', 'Overtraded', 'Revenge', 'FOMO', 'Ignored NPS', 'Ignored HTF Bias', 'Other'].map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="form-grid" style={{ marginTop: 16 }}>
          <div className="form-group" style={{ gridColumn: '1 / -1' }}>
            <label>Lesson Learned</label>
            <textarea value={form.lesson || ''} onChange={(e) => update('lesson', e.target.value)} />
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 12, marginTop: 8 }}>
        <button className="btn btn-secondary" onClick={onCancel}>
          Cancel
        </button>
        <button className="btn btn-primary" onClick={save} disabled={saving}>
          {saving ? 'Saving…' : 'Save Trade'}
        </button>
      </div>
    </div>
  );
}

function TradeDetailPage({ trade, onBack }: { trade: Trade; onBack: () => void }) {
  if (!trade) return null;
  return (
    <div>
      <button className="btn-ghost" onClick={onBack} style={{ marginBottom: 16 }}>
        ← Back to Trades
      </button>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: 28, fontWeight: 700 }}>{trade.instrument}</h1>
        <span className={`badge ${trade.direction === 'LONG' ? 'badge-long' : 'badge-short'}`}>
          {trade.direction}
        </span>
        {trade.npsGrade && <span className="badge" style={{ background: 'var(--bg-soft)' }}>{trade.npsGrade}</span>}
        {trade.npsConfidence && <span style={{ color: 'var(--text-secondary)' }}>{trade.npsConfidence}% conf</span>}
      </div>

      <div className="dna-bar">
        {[
          { label: 'Pair', value: trade.instrument },
          { label: 'Direction', value: trade.direction },
          { label: 'Grade', value: trade.npsGrade },
          { label: 'Confidence', value: trade.npsConfidence ? `${trade.npsConfidence}%` : '—' },
          { label: 'Setup', value: trade.setup },
          { label: 'Session', value: trade.session },
          { label: 'Outcome', value: trade.outcome },
          { label: 'R', value: formatR(trade.realizedR) },
        ].map((item) => (
          <div className="dna-item" key={item.label}>
            <span className="dna-label">{item.label}</span>
            <span className="dna-value">{item.value || '—'}</span>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, marginBottom: 24 }}>
        <div className="card">
          <div className="card-title">Price Levels</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 14 }}>
            <div><span style={{ color: 'var(--text-muted)' }}>Entry</span><br /><strong>{trade.entry}</strong></div>
            <div><span style={{ color: 'var(--text-muted)' }}>Stop Loss</span><br /><strong>{trade.stopLoss}</strong></div>
            <div><span style={{ color: 'var(--text-muted)' }}>TP1</span><br /><strong>{trade.tp1}</strong></div>
            <div><span style={{ color: 'var(--text-muted)' }}>TP2</span><br /><strong>{trade.tp2 || '—'}</strong></div>
            <div><span style={{ color: 'var(--text-muted)' }}>TP3</span><br /><strong>{trade.tp3 || '—'}</strong></div>
            <div><span style={{ color: 'var(--text-muted)' }}>Exit</span><br /><strong>{trade.exitPrice || '—'}</strong></div>
          </div>
        </div>
        <div className="card">
          <div className="card-title">Result</div>
          <div style={{ fontSize: 28, fontWeight: 700, color: rColor(trade.realizedR), marginBottom: 8 }}>
            {formatR(trade.realizedR)}
          </div>
          <div style={{ fontSize: 16, color: 'var(--text-secondary)' }}>{formatPnl(trade.realizedPnl)}</div>
          <div style={{ marginTop: 12 }}>
            <span
              className={`badge ${
                trade.outcome === 'SL' ? 'badge-sl' : trade.outcome === 'BE' ? 'badge-be' : 'badge-tp'
              }`}
            >
              {trade.outcome}
            </span>
          </div>
        </div>
      </div>

      {(trade.signalScreenshot || trade.entryScreenshot || trade.outcomeScreenshot) && (
        <div className="card" style={{ marginBottom: 24 }}>
          <div className="card-title">Screenshots</div>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            {trade.signalScreenshot && (
              <div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 4 }}>Signal</div>
                <img src={trade.signalScreenshot} alt="Signal" style={{ maxWidth: 280, borderRadius: 8 }} />
              </div>
            )}
            {trade.entryScreenshot && (
              <div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 4 }}>Entry</div>
                <img src={trade.entryScreenshot} alt="Entry" style={{ maxWidth: 280, borderRadius: 8 }} />
              </div>
            )}
            {trade.outcomeScreenshot && (
              <div>
                <div style={{ fontSize: 12, color: 'var(--text-muted)', marginBottom: 4 }}>Outcome</div>
                <img src={trade.outcomeScreenshot} alt="Outcome" style={{ maxWidth: 280, borderRadius: 8 }} />
              </div>
            )}
          </div>
        </div>
      )}

      <div className="card">
        <div className="card-title">Notes & Review</div>
        {trade.entryComment && <p style={{ marginBottom: 8 }}><strong>Entry:</strong> {trade.entryComment}</p>}
        {trade.exitComment && <p style={{ marginBottom: 8 }}><strong>Exit:</strong> {trade.exitComment}</p>}
        {trade.lesson && <p style={{ marginBottom: 8 }}><strong>Lesson:</strong> {trade.lesson}</p>}
        <div style={{ display: 'flex', gap: 16, marginTop: 12, fontSize: 13 }}>
          <span>NPS followed: <strong>{trade.npsFollowed || '—'}</strong></span>
          <span>Plan followed: <strong>{trade.planFollowed || '—'}</strong></span>
          {trade.mistakeType && <span>Mistake: <strong>{trade.mistakeType}</strong></span>}
        </div>
      </div>
    </div>
  );
}

function SettingsPage({
  settings,
  onSave,
  onBack,
}: {
  settings: Settings;
  onSave: (s: Settings) => Promise<void>;
  onBack: () => void;
}) {
  const [local, setLocal] = useState(settings);
  const [msg, setMsg] = useState('');

  const handleExport = async () => {
    const json = await exportAllData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `nps-journal-backup-${format(new Date(), 'yyyy-MM-dd-HHmm')}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setMsg('Backup downloaded. Upload this file to Google Drive for cloud backup.');
  };

  const handleImport = async (file: File) => {
    const text = await file.text();
    try {
      const result = await importAllData(text);
      setMsg(`Imported ${result.trades} trades successfully.`);
      window.location.reload();
    } catch {
      setMsg('Import failed: invalid file.');
    }
  };

  const handleManualBackup = async () => {
    await createLocalBackup();
    setMsg('Local backup created.');
  };

  return (
    <div>
      <button className="btn-ghost" onClick={onBack} style={{ marginBottom: 16 }}>
        ← Back
      </button>
      <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 24 }}>Settings</h1>

      <div className="settings-grid">
        <div className="form-section">
          <h3>Account</h3>
          <div className="form-grid">
            <div className="form-group">
              <label>Account Size ($)</label>
              <input
                type="number"
                value={local.accountSize}
                onChange={(e) => setLocal({ ...local, accountSize: Number(e.target.value) })}
              />
            </div>
            <div className="form-group">
              <label>Default Risk %</label>
              <input
                type="number"
                step="0.1"
                value={local.defaultRiskPercent}
                onChange={(e) => setLocal({ ...local, defaultRiskPercent: Number(e.target.value) })}
              />
            </div>
            <div className="form-group">
              <label>Currency</label>
              <input
                value={local.currency}
                onChange={(e) => setLocal({ ...local, currency: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label>Timezone</label>
              <input
                value={local.timezone}
                onChange={(e) => setLocal({ ...local, timezone: e.target.value })}
              />
            </div>
          </div>
          <button
            className="btn btn-primary"
            style={{ marginTop: 16 }}
            onClick={async () => {
              await onSave(local);
              setMsg('Settings saved.');
            }}
          >
            Save Settings
          </button>
        </div>

        <div className="form-section">
          <h3>Backup & Data</h3>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 16 }}>
            Your data is stored locally in this browser (IndexedDB). For Google Drive backup, download
            the JSON file and upload it to your Drive. You can also import a previous backup.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <button className="btn btn-primary" onClick={handleExport}>
              Download Backup (JSON)
            </button>
            <button className="btn btn-secondary" onClick={handleManualBackup}>
              Create Local Backup
            </button>
            <label className="btn btn-secondary" style={{ textAlign: 'center', cursor: 'pointer' }}>
              Import Backup
              <input
                type="file"
                accept=".json"
                style={{ display: 'none' }}
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleImport(f);
                }}
              />
            </label>
          </div>
          {msg && (
            <p style={{ marginTop: 16, fontSize: 13, color: 'var(--positive)' }}>{msg}</p>
          )}
          <div style={{ marginTop: 24, padding: 16, background: 'var(--bg-soft)', borderRadius: 8, fontSize: 13 }}>
            <strong>Google Drive tip</strong>
            <p style={{ marginTop: 6, color: 'var(--text-secondary)' }}>
              After downloading the backup JSON, open Google Drive → New → File upload and select the
              file. To restore later, download it from Drive and use Import Backup here.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
