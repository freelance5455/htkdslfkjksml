import type { Trade, Settings } from '../types/trade';
import { startOfDay, startOfWeek, startOfMonth, isWithinInterval, parseISO, format } from 'date-fns';

export function isWin(t: Trade): boolean {
  return t.outcome === 'TP1' || t.outcome === 'TP2' || t.outcome === 'TP3' || (t.realizedR != null && t.realizedR > 0);
}

export function isLoss(t: Trade): boolean {
  return t.outcome === 'SL' || (t.realizedR != null && t.realizedR < 0);
}

export function isBE(t: Trade): boolean {
  return t.outcome === 'BE' || t.realizedR === 0;
}

export function completedTrades(trades: Trade[]): Trade[] {
  return trades.filter((t) => !t.isMissedSignal && t.outcome && t.outcome !== 'EXPIRED');
}

export function calcSummary(trades: Trade[], settings: Settings) {
  const completed = completedTrades(trades);
  const wins = completed.filter(isWin);
  const losses = completed.filter(isLoss);
  const bes = completed.filter(isBE);

  const netR = completed.reduce((s, t) => s + (t.realizedR || 0), 0);
  const netPnl = completed.reduce((s, t) => s + (t.realizedPnl || 0), 0);

  const denom = settings.excludeBeFromWinRate ? wins.length + losses.length : completed.length;
  const winRate = denom > 0 ? (wins.length / denom) * 100 : 0;

  const avgR = completed.length > 0 ? netR / completed.length : 0;
  const grossWin = wins.reduce((s, t) => s + Math.max(t.realizedPnl || 0, 0), 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + Math.min(t.realizedPnl || 0, 0), 0));
  const profitFactor = grossLoss > 0 ? grossWin / grossLoss : grossWin > 0 ? Infinity : 0;

  return {
    total: completed.length,
    wins: wins.length,
    losses: losses.length,
    be: bes.length,
    winRate,
    netR,
    netPnl,
    avgR,
    profitFactor,
    expectancy: avgR,
  };
}

export function periodTrades(trades: Trade[], period: 'today' | 'week' | 'month'): Trade[] {
  const now = new Date();
  let start: Date;
  if (period === 'today') start = startOfDay(now);
  else if (period === 'week') start = startOfWeek(now, { weekStartsOn: 1 });
  else start = startOfMonth(now);

  return trades.filter((t) => {
    if (!t.date) return false;
    const d = parseISO(t.date);
    return isWithinInterval(d, { start, end: now });
  });
}

export function pairPerformance(trades: Trade[]) {
  const map = new Map<string, Trade[]>();
  completedTrades(trades).forEach((t) => {
    const arr = map.get(t.instrument) || [];
    arr.push(t);
    map.set(t.instrument, arr);
  });

  return Array.from(map.entries())
    .map(([pair, ts]) => {
      const s = calcSummary(ts, { excludeBeFromWinRate: true } as Settings);
      return {
        pair,
        trades: s.total,
        wins: s.wins,
        losses: s.losses,
        be: s.be,
        winRate: s.winRate,
        netR: s.netR,
        netPnl: s.netPnl,
        avgR: s.avgR,
      };
    })
    .sort((a, b) => b.netR - a.netR);
}

export function setupPerformance(trades: Trade[]) {
  const map = new Map<string, Trade[]>();
  completedTrades(trades).forEach((t) => {
    const key = t.setup || 'UNKNOWN';
    const arr = map.get(key) || [];
    arr.push(t);
    map.set(key, arr);
  });

  return Array.from(map.entries())
    .map(([setup, ts]) => {
      const s = calcSummary(ts, { excludeBeFromWinRate: true } as Settings);
      return { setup, ...s };
    })
    .sort((a, b) => b.netR - a.netR);
}

export function sessionPerformance(trades: Trade[]) {
  const map = new Map<string, Trade[]>();
  completedTrades(trades).forEach((t) => {
    const key = t.session || 'Unknown';
    const arr = map.get(key) || [];
    arr.push(t);
    map.set(key, arr);
  });

  return Array.from(map.entries())
    .map(([session, ts]) => {
      const s = calcSummary(ts, { excludeBeFromWinRate: true } as Settings);
      return { session, ...s };
    })
    .sort((a, b) => b.netR - a.netR);
}

export function equityCurve(trades: Trade[], initialBalance = 10000) {
  const sorted = completedTrades(trades)
    .filter((t) => t.date)
    .sort((a, b) => a.date.localeCompare(b.date) || (a.exitTime || '').localeCompare(b.exitTime || ''));

  let equity = initialBalance;
  let peak = initialBalance;
  let maxDd = 0;
  const points: { date: string; equity: number; r: number; pnl: number; drawdown: number }[] = [
    { date: sorted[0]?.date || format(new Date(), 'yyyy-MM-dd'), equity: initialBalance, r: 0, pnl: 0, drawdown: 0 },
  ];

  let cumulativeR = 0;
  for (const t of sorted) {
    equity += t.realizedPnl || 0;
    cumulativeR += t.realizedR || 0;
    peak = Math.max(peak, equity);
    const dd = peak - equity;
    maxDd = Math.max(maxDd, dd);
    points.push({
      date: t.date,
      equity,
      r: cumulativeR,
      pnl: t.realizedPnl || 0,
      drawdown: dd,
    });
  }

  return { points, maxDrawdown: maxDd, finalEquity: equity };
}

export function confidenceBands(trades: Trade[]) {
  const bands = [
    { label: '90–100%', min: 90, max: 100 },
    { label: '80–89%', min: 80, max: 89 },
    { label: '70–79%', min: 70, max: 79 },
    { label: '60–69%', min: 60, max: 69 },
    { label: '<60%', min: 0, max: 59 },
  ];

  return bands.map((b) => {
    const ts = completedTrades(trades).filter(
      (t) => t.npsConfidence != null && t.npsConfidence >= b.min && t.npsConfidence <= b.max
    );
    const s = calcSummary(ts, { excludeBeFromWinRate: true } as Settings);
    const tp1Hit = ts.filter((t) => t.outcome === 'TP1' || t.outcome === 'TP2' || t.outcome === 'TP3').length;
    return {
      ...b,
      trades: s.total,
      winRate: s.winRate,
      avgR: s.avgR,
      netR: s.netR,
      tp1HitRate: s.total > 0 ? (tp1Hit / s.total) * 100 : 0,
    };
  });
}

export function npsVsExecution(trades: Trade[]) {
  const compliant = completedTrades(trades).filter((t) => t.npsFollowed === 'YES');
  const nonCompliant = completedTrades(trades).filter((t) => t.npsFollowed === 'NO' || t.npsFollowed === 'PARTIAL');
  return {
    compliant: calcSummary(compliant, { excludeBeFromWinRate: true } as Settings),
    nonCompliant: calcSummary(nonCompliant, { excludeBeFromWinRate: true } as Settings),
  };
}

export function calcRiskReward(entry: number, sl: number, tp: number, direction: 'LONG' | 'SHORT') {
  const risk = Math.abs(entry - sl);
  if (risk === 0) return 0;
  const reward = direction === 'LONG' ? tp - entry : entry - tp;
  return reward / risk;
}
