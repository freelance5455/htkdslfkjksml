import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatR(r: number | undefined | null): string {
  if (r == null) return '—';
  const sign = r > 0 ? '+' : '';
  return `${sign}${r.toFixed(2)}R`;
}

export function formatPnl(pnl: number | undefined | null, currency = 'USD'): string {
  if (pnl == null) return '—';
  const sign = pnl > 0 ? '+' : '';
  return `${sign}$${Math.abs(pnl).toFixed(2)}`;
}

export function formatPct(v: number): string {
  return `${v.toFixed(1)}%`;
}

export function outcomeColor(outcome?: string): string {
  if (!outcome) return 'var(--color-neutral)';
  if (['TP1', 'TP2', 'TP3'].includes(outcome)) return 'var(--color-positive)';
  if (outcome === 'SL') return 'var(--color-negative)';
  return 'var(--color-neutral)';
}

export function rColor(r?: number | null): string {
  if (r == null) return 'var(--color-neutral)';
  if (r > 0) return 'var(--color-positive)';
  if (r < 0) return 'var(--color-negative)';
  return 'var(--color-neutral)';
}
