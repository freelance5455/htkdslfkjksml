const CLASSES=["প্রাক-প্রাথমিক","১ম শ্রেণি","২য় শ্রেণি","৩য় শ্রেণি","৪র্থ শ্রেণি","৫ম শ্রেণি"];
const SUBJECTS={
 junior:["বাংলা","ইংরেজি","গণিত","সমন্বিত বিজ্ঞান","ধর্ম","শিল্পকলা","শারীরিক ও মানসিক স্বাস্থ্য শিক্ষা"],
 senior:["বাংলা","ইংরেজি","গণিত","বিজ্ঞান","ধর্ম","বাংলাদেশ ও বিশ্বপরিচয়","শিল্পকলা"]
};
const TERMS=["১ম প্রান্তিক","২য় প্রান্তিক","৩য় প্রান্তিক"];
const DBKEY="west_rifaitpur_school_v1";
let db=load(),page="home",installPrompt=null;
function blank(){return {students:[],attendance:{},results:{}}}
function load(){try{return JSON.parse(localStorage.getItem(DBKEY))||blank()}catch{return blank()}}
function save(){localStorage.setItem(DBKEY,JSON.stringify(db));}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function today(){return new Date().toISOString().slice(0,10)}
function fmtDate(d){return d?new Date(d+"T00:00:00").toLocaleDateString("bn-BD"): ""}
function isSenior(c){return ["৩য় শ্রেণি","৪র্থ শ্রেণি","৫ম শ্রেণি"].includes(c)}
function subjects(c){return isSenior(c)?SUBJECTS.senior:SUBJECTS.junior}
function id(){return "s"+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
function age(d){if(!d)return "—";let b=new Date(d),n=new Date();let a=n.getFullYear()-b.getFullYear();if(n.getMonth()<b.getMonth()||(n.getMonth()===b.getMonth()&&n.getDate()<b.getDate()))a--;return a+" বছর"}
function nav(p){page=p;document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.page===p));render()}
document.querySelectorAll(".nav").forEach(x=>x.addEventListener("click",()=>nav(x.dataset.page)));
function render(){let el=document.getElementById("app");({home:home,attendance:attendance,students:students,results:results,reports:reports,backup:backup}[page]||home)(el)}
function title(t,sub=""){return `<div class="page-title"><div><h2>${t}</h2>${sub?`<div class="muted">${sub}</div>`:""}</div></div>`}
function stat(e,n,l){return `<div class="card stat"><div class="emoji">${e}</div><div class="num">${n}</div><small>${l}</small></div>`}
function home(el){
 let total=db.students.length,boys=db.students.filter(s=>s.gender==="ছেলে").length,girls=db.students.filter(s=>s.gender==="মেয়ে").length;
 let rec=db.attendance[today()]||{},all=Object.values(rec).flatMap(x=>Object.values(x)),p=all.filter(x=>x==="P").length,a=all.filter(x=>x==="A").length;
 el.innerHTML=title("স্বাগতম! 🌈","বিদ্যালয়ের দৈনন্দিন কার্যক্রম এক জায়গায়")+
 `<div class="grid">${stat("🧒",total,"মোট শিক্ষার্থী")}${stat("👦",boys,"ছাত্র")}${stat("👧",girls,"ছাত্রী")}${stat("✅",p,"আজ উপস্থিত")}</div>
 <div class="grid panel">${stat("❌",a,"আজ অনুপস্থিত")}${stat("🏫",CLASSES.length,"শ্রেণি")}${stat("📅",Object.keys(db.attendance).length,"হাজিরার দিন")}${stat("📚",Object.keys(db.results).length,"ফলাফল এন্ট্রি")}</div>
 <div class="card panel"><h3>🚀 দ্রুত কাজ</h3><div class="row"><button class="btn" onclick="nav('attendance')">আজকের হাজিরা নিন</button><button class="btn secondary" onclick="nav('students')">শিক্ষার্থী যোগ করুন</button><button class="btn secondary" onclick="nav('results')">নম্বর এন্ট্রি</button></div></div>
 <div class="callout">💡 প্রথমে “শিক্ষার্থী” থেকে প্রতিটি শ্রেণির শিক্ষার্থীর নাম, রোল ও লিঙ্গ যোগ করুন। এরপর হাজিরা ও ফলাফল তৈরি করতে পারবেন।</div>`;
}
function attendance(el){
 let date=today(),cls=CLASSES[0];
 el.innerHTML=title("দৈনিক হাজিরা 📅","তারিখ ও শ্রেণি নির্বাচন করে উপস্থিতি সংরক্ষণ করুন")+
 `<div class="card"><div class="row"><label>তারিখ<input type="date" id="attDate" value="${date}"></label><label>শ্রেণি<select id="attClass">${CLASSES.map(c=>`<option>${c}</option>`).join("")}</select></label><button class="btn" id="loadAtt">তালিকা দেখুন</button></div><div id="attArea" class="panel"></div></div>`;
 document.getElementById("loadAtt").onclick=()=>drawAttendance();
 drawAttendance();
}
function drawAttendance(){
 let d=document.getElementById("attDate").value,c=document.getElementById("attClass").value;
 let list=db.students.filter(s=>s.cls===c).sort((a,b)=>(+a.roll||0)-(+b.roll||0)),rec=db.attendance[d]?.[c]||{};
 let area=document.getElementById("attArea");
 if(!list.length){area.innerHTML='<div class="empty">এই শ্রেণিতে শিক্ষার্থী নেই। আগে শিক্ষার্থী যোগ করুন।</div>';return}
 area.innerHTML=`<div class="row" style="justify-content:space-between"><div class="kpis" id="attStats"></div><button class="btn success no-print" id="saveAtt">✓ হাজিরা সংরক্ষণ</button></div><div class="tablewrap panel"><table><thead><tr><th>রোল</th><th>শিক্ষার্থীর নাম</th><th>লিঙ্গ</th><th>উপস্থিত</th><th>অনুপস্থিত</th></tr></thead><tbody>${list.map(s=>`<tr><td>${esc(s.roll)}</td><td>${esc(s.name)}</td><td>${esc(s.gender)}</td><td><input type="radio" name="a_${s.id}" value="P" ${rec[s.id]!=="A"?"checked":""} aria-label="উপস্থিত"></td><td><input type="radio" name="a_${s.id}" value="A" ${rec[s.id]==="A"?"checked":""} aria-label="অনুপস্থিত"></td></tr>`).join("")}</tbody></table></div>`;
 const update=()=>{let vals=list.map(s=>document.querySelector(`input[name="a_${s.id}"]:checked`)?.value||"P"),p=vals.filter(v=>v==="P").length,a=vals.length-p,bp=list.filter((s,i)=>s.gender==="ছেলে"&&vals[i]==="P").length,gp=list.filter((s,i)=>s.gender==="মেয়ে"&&vals[i]==="P").length,pc=vals.length?Math.round(p/vals.length*100):0;document.getElementById("attStats").innerHTML=`<span class="kpi">উপস্থিত ${p}</span><span class="kpi">অনুপস্থিত ${a}</span><span class="kpi">ছেলে ${bp}</span><span class="kpi">মেয়ে ${gp}</span><span class="kpi">উপস্থিতি ${pc}%</span>`};
 area.querySelectorAll("input[type=radio]").forEach(x=>x.addEventListener("change",update));update();
 document.getElementById("saveAtt").onclick=()=>{db.attendance[d]??={};db.attendance[d][c]={};list.forEach(s=>db.attendance[d][c][s.id]=document.querySelector(`input[name="a_${s.id}"]:checked`)?.value||"P");save();alert("হাজিরা সংরক্ষণ হয়েছে");};
}
function students(el){
 el.innerHTML=title("শিক্ষার্থী পরিচিতি 🧒","শিক্ষার্থী যোগ, খোঁজ ও তথ্য সম্পাদনা")+
 `<div class="card"><div class="row"><input class="search" id="studentSearch" placeholder="নাম, রোল বা অভিভাবকের নাম দিয়ে খুঁজুন"><select id="classFilter"><option value="">সব শ্রেণি</option>${CLASSES.map(c=>`<option>${c}</option>`).join("")}</select><button class="btn" id="addStudent">＋ শিক্ষার্থী যোগ</button></div><div id="studentTable" class="panel"></div></div>`;
 document.getElementById("addStudent").onclick=()=>studentForm();
 ["studentSearch","classFilter"].forEach(id=>document.getElementById(id).addEventListener("input",drawStudents));drawStudents();
}
function drawStudents(){
 let q=document.getElementById("studentSearch").value.toLowerCase(),c=document.getElementById("classFilter").value;
 let list=db.students.filter(s=>(!c||s.cls===c)&&[s.name,s.short,s.guardian,s.roll,s.father,s.mother].join(" ").toLowerCase().includes(q)).sort((a,b)=>CLASSES.indexOf(a.cls)-CLASSES.indexOf(b.cls)||(+a.roll||0)-(+b.roll||0));
 document.getElementById("studentTable").innerHTML=list.length?`<div class="tablewrap"><table><thead><tr><th>রোল</th><th>নাম</th><th>শ্রেণি</th><th>লিঙ্গ</th><th>বয়স</th><th>অভিভাবক</th><th>মোবাইল</th><th>কাজ</th></tr></thead><tbody>${list.map(s=>`<tr><td>${esc(s.roll)}</td><td>${esc(s.name)}</td><td>${esc(s.cls)}</td><td>${esc(s.gender)}</td><td>${age(s.dob)}</td><td>${esc(s.guardian)}</td><td>${esc(s.mobile)}</td><td><div class="actions"><button class="btn secondary small" onclick="studentForm('${s.id}')">দেখুন/সম্পাদনা</button><button class="btn danger small" onclick="delStudent('${s.id}')">মুছুন</button></div></td></tr>`).join("")}</tbody></table></div>`:'<div class="empty">কোনো শিক্ষার্থী পাওয়া যায়নি।</div>';
}
function studentForm(sid){
 let s=db.students.find(x=>x.id===sid)||{id:"",cls:CLASSES[0],gender:"ছেলে"};
 let fields=[["name","পূর্ণ নাম"],["short","সংক্ষিপ্ত নাম"],["roll","রোল"],["dob","জন্মতারিখ","date"],["birth","জন্মনিবন্ধন নম্বর"],["father","পিতার নাম"],["fatherNid","পিতার NID"],["mother","মাতার নাম"],["motherNid","মাতার NID"],["guardian","অভিভাবকের নাম"],["mobile","মোবাইল নম্বর"],["address","ঠিকানা"]];
 let modal=document.createElement("div");modal.className="modal";modal.innerHTML=`<div class="modalbox"><div class="modalhead"><h3>${sid?"শিক্ষার্থী তথ্য":"নতুন শিক্ষার্থী"}</h3><button class="btn secondary" id="closeModal">✕</button></div><form id="studentForm" class="formgrid"><label>শ্রেণি<select name="cls">${CLASSES.map(c=>`<option ${s.cls===c?"selected":""}>${c}</option>`).join("")}</select></label><label>লিঙ্গ<select name="gender"><option ${s.gender==="ছেলে"?"selected":""}>ছেলে</option><option ${s.gender==="মেয়ে"?"selected":""}>মেয়ে</option></select></label>${fields.map(([k,l,t])=>`<label class="${k==="address"?"wide":""}">${l}<input name="${k}" type="${t||"text"}" value="${esc(s[k]||"")}" ${k==="name"?"required":""}></label>`).join("")}<label class="wide">ছবির লিংক (ঐচ্ছিক)<input name="photo" value="${esc(s.photo||"")}" placeholder="https://..."></label><div class="wide row"><button class="btn" type="submit">সংরক্ষণ</button><button class="btn secondary" type="button" id="cancelModal">বাতিল</button></div></form></div>`;
 document.body.append(modal);modal.querySelector("#closeModal").onclick=modal.querySelector("#cancelModal").onclick=()=>modal.remove();
 modal.querySelector("form").onsubmit=e=>{e.preventDefault();let o=Object.fromEntries(new FormData(e.target));o.id=s.id||id();let i=db.students.findIndex(x=>x.id===o.id);if(i>=0)db.students[i]=o;else db.students.push(o);save();modal.remove();drawStudents();};
}
function delStudent(sid){if(!confirm("এই শিক্ষার্থীর তথ্য মুছে ফেলবেন?"))return;db.students=db.students.filter(s=>s.id!==sid);Object.values(db.attendance).forEach(day=>Object.values(day).forEach(c=>delete c[sid]));save();drawStudents()}
function results(el){
 el.innerHTML=title("পরীক্ষার ফলাফল 📚","১ম, ২য় ও ৩য় প্রান্তিকের নম্বর এন্ট্রি")+
 `<div class="card"><div class="row"><label>শ্রেণি<select id="resClass">${CLASSES.filter(c=>!["প্রাক-প্রাথমিক"].includes(c)).map(c=>`<option>${c}</option>`).join("")}</select></label><label>প্রান্তিক<select id="resTerm">${TERMS.map(t=>`<option>${t}</option>`).join("")}</select></label><label>শিক্ষার্থী<select id="resStudent"></select></label><button class="btn" id="loadResult">নম্বরের ছক</button></div><div id="resultArea" class="panel"></div></div>`;
 document.getElementById("resClass").onchange=fillResultStudents;fillResultStudents();document.getElementById("loadResult").onclick=drawResult;
}
function fillResultStudents(){let c=document.getElementById("resClass").value,l=db.students.filter(s=>s.cls===c);document.getElementById("resStudent").innerHTML=l.map(s=>`<option value="${s.id}">${esc(s.roll)} - ${esc(s.name)}</option>`).join("")}
function drawResult(){
 let c=document.getElementById("resClass").value,t=document.getElementById("resTerm").value,sid=document.getElementById("resStudent").value,s=db.students.find(x=>x.id===sid),area=document.getElementById("resultArea");if(!s){area.innerHTML='<div class="empty">এই শ্রেণিতে শিক্ষার্থী যোগ করা হয়নি।</div>';return}
 let key=[sid,t].join("|"),old=db.results[key]||{},subs=subjects(c),sen=isSenior(c);
 area.innerHTML=`<h3>${esc(s.name)} · ${t}</h3><div class="tablewrap"><table><thead><tr><th>বিষয়</th>${sen?'<th>বইয়ের কাজ /১০</th><th>সক্রিয়তা /৫</th><th>ভাষা /৫</th><th>ক্লাস টেস্ট /১০</th><th>প্রান্তিক /৭০</th>':'<th>বইয়ের কাজ /২০</th><th>সক্রিয়তা /৫</th><th>ভাষা /৫</th><th>ক্লাস টেস্ট /২০</th><th>প্রান্তিক</th>'}<th>মোট</th></tr></thead><tbody>${subs.map((sub,i)=>{let noCont=sen&&sub==="শিল্পকলা"||!sen&&i>2;let max=sen?70:50;return `<tr><td>${sub}</td>${noCont?`<td colspan="4" class="muted">ধারাবাহিক মূল্যায়ন নেই</td>`:`<td><input type="number" min="0" max="${sen?10:20}" data-k="${i}-0" value="${old[sub]?.[0]??0}" style="width:75px"></td><td><input type="number" min="0" max="5" data-k="${i}-1" value="${old[sub]?.[1]??0}" style="width:65px"></td><td><input type="number" min="0" max="5" data-k="${i}-2" value="${old[sub]?.[2]??0}" style="width:65px"></td><td><input type="number" min="0" max="${sen?10:20}" data-k="${i}-3" value="${old[sub]?.[3]??0}" style="width:70px"></td>`}<td><input type="number" min="0" max="${noCont?(sen?100:50):max}" data-k="${i}-4" value="${old[sub]?.[4]??0}" style="width:75px"></td><td id="total-${i}">—</td></tr>`}).join("")}</tbody></table></div><div class="row panel"><button class="btn success" id="saveResult">ফলাফল সংরক্ষণ</button><button class="btn secondary" onclick="window.print()">প্রিন্ট</button></div>`;
 area.querySelectorAll("input").forEach(x=>x.addEventListener("input",()=>calcRow(x.dataset.k.split("-")[0])));
 subs.forEach((_,i)=>calcRow(i));
 function calcRow(i){let vals=[0,1,2,3,4].map(j=>+(area.querySelector(`[data-k="${i}-${j}"]`)?.value||0));let noCont=sen&&subs[i]==="শিল্পকলা"||!sen&&i>2;let total=noCont?vals[4]:vals.reduce((a,b)=>a+b,0);document.getElementById("total-"+i).textContent=total}
 document.getElementById("saveResult").onclick=()=>{let data={};subs.forEach((sub,i)=>{data[sub]=[0,1,2,3,4].map(j=>+(area.querySelector(`[data-k="${i}-${j}"]`)?.value||0));});db.results[key]=data;save();alert("নম্বর সংরক্ষণ হয়েছে");};
}
function reports(el){
 let date=today();el.innerHTML=title("রিপোর্ট ও প্রিন্ট 🖨️","হাজিরা ও শিক্ষার্থীর তালিকা প্রিন্ট করুন")+
 `<div class="grid"><div class="card"><h3>📅 হাজিরা রিপোর্ট</h3><label>তারিখ<input type="date" id="repDate" value="${date}"></label><label>শ্রেণি<select id="repClass">${CLASSES.map(c=>`<option>${c}</option>`).join("")}</select></label><button class="btn panel" id="printAtt">রিপোর্ট দেখুন / প্রিন্ট</button></div><div class="card"><h3>🧒 শিক্ষার্থী তালিকা</h3><label>শ্রেণি<select id="listClass"><option value="">সব শ্রেণি</option>${CLASSES.map(c=>`<option>${c}</option>`).join("")}</select></label><button class="btn panel" id="printStudents">তালিকা দেখুন / প্রিন্ট</button></div></div><div id="reportArea" class="panel"></div>`;
 document.getElementById("printAtt").onclick=()=>{let d=document.getElementById("repDate").value,c=document.getElementById("repClass").value,list=db.students.filter(s=>s.cls===c),rec=db.attendance[d]?.[c]||{};let p=list.filter(s=>rec[s.id]!=="A"),a=list.filter(s=>rec[s.id]==="A");showReport(`<h2>${c} · হাজিরা রিপোর্ট</h2><p>তারিখ: ${fmtDate(d)}</p><p>মোট ${list.length} · উপস্থিত ${p.length} · অনুপস্থিত ${a.length} · উপস্থিতি ${list.length?Math.round(p.length/list.length*100):0}%</p>${reportTable(list,s=>rec[s.id]==="A"?"অনুপস্থিত":"উপস্থিত")}`)};
 document.getElementById("printStudents").onclick=()=>{let c=document.getElementById("listClass").value,list=db.students.filter(s=>!c||s.cls===c);showReport(`<h2>শিক্ষার্থী তালিকা ${c||"(সকল শ্রেণি)"}</h2>${reportTable(list,s=>s.gender)}`)};
}
function reportTable(list,extra){return `<div class="tablewrap"><table><tr><th>রোল</th><th>নাম</th><th>শ্রেণি</th><th>অভিভাবক</th><th>মোবাইল</th><th>তথ্য</th></tr>${list.map(s=>`<tr><td>${esc(s.roll)}</td><td>${esc(s.name)}</td><td>${esc(s.cls)}</td><td>${esc(s.guardian)}</td><td>${esc(s.mobile)}</td><td>${extra(s)}</td></tr>`).join("")}</table></div>`}
function showReport(html){document.getElementById("reportArea").innerHTML=`<div class="card">${html}<button class="btn no-print panel" onclick="window.print()">🖨️ প্রিন্ট করুন</button></div>`}
function backup(el){
 el.innerHTML=title("Backup / Restore 💾","তথ্য নিরাপদে সংরক্ষণ ও পুনরুদ্ধার")+
 `<div class="grid"><div class="card"><h3>📥 Backup</h3><p class="muted">শিক্ষার্থী, হাজিরা ও ফলাফলের সব তথ্য JSON ফাইলে ডাউনলোড হবে।</p><button class="btn" id="backupBtn">Backup ডাউনলোড</button></div><div class="card"><h3>📤 Restore</h3><p class="muted">আগে নেওয়া JSON Backup ফাইল থেকে তথ্য ফিরিয়ে আনুন। বর্তমান তথ্য প্রতিস্থাপিত হবে।</p><button class="btn secondary" id="restoreBtn">ফাইল নির্বাচন</button></div></div>
 <div class="callout">🔒 গোপনীয়তা: জন্মনিবন্ধন ও অভিভাবকের NID-এর মতো সংবেদনশীল তথ্য আছে। ডিভাইসে স্ক্রিন লক রাখুন, Backup ফাইল অন্যের সঙ্গে শেয়ার করবেন না।</div>
 <div class="card panel"><h3>☁️ অনলাইন সংরক্ষণ সম্পর্কে</h3><p>এই প্রাথমিক সংস্করণে অ্যাপটি অফলাইনে কাজ করে এবং তথ্য এই ডিভাইসে থাকে। একাধিক ডিভাইসে একই তথ্য পেতে নিরাপদ অনলাইন সার্ভার ও ব্যবহারকারী লগইন যুক্ত করতে হবে।</p></div>`;
 document.getElementById("backupBtn").onclick=()=>{let blob=new Blob([JSON.stringify({...db,exportedAt:new Date().toISOString(),school:"পশ্চিম রিফাইতপুর সরকারি প্রাথমিক বিদ্যালয়"},null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="west-rifaitpur-backup-"+today()+".json";a.click();URL.revokeObjectURL(a.href)};
 document.getElementById("restoreBtn").onclick=()=>document.getElementById("restoreFile").click();
}
document.getElementById("restoreFile").onchange=async e=>{let f=e.target.files[0];if(!f)return;try{let x=JSON.parse(await f.text());if(!Array.isArray(x.students)||!x.attendance||!x.results)throw Error();if(confirm("বর্তমান তথ্য প্রতিস্থাপন করে Backup Restore করবেন?")){db={students:x.students,attendance:x.attendance,results:x.results};save();alert("Restore সম্পন্ন");render()}}catch{alert("ফাইলটি সঠিক Backup JSON নয়")}e.target.value=""};
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();installPrompt=e;document.getElementById("installBtn").hidden=false});
document.getElementById("installBtn").onclick=async()=>{if(installPrompt){installPrompt.prompt();installPrompt=null}};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
render();
