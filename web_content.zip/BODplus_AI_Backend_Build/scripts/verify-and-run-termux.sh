#!/data/data/com.termux/files/usr/bin/bash
# Verify a Groq key against Groq's public models endpoint, without saving it,
# then start the BOD+ AI Java backend with the key in the server environment.
set -euo pipefail
cd "$(dirname "$0")/.."

for cmd in java javac curl; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "Missing required command: $cmd"
    if [[ "$cmd" == "curl" ]]; then
      echo "Install it in Termux with: pkg install curl"
    elif [[ "$cmd" == "java" || "$cmd" == "javac" ]]; then
      echo "Install Java in Termux with: pkg install openjdk-21"
    fi
    exit 1
  fi
done

printf 'Paste your Groq API key (input hidden): '
IFS= read -r -s GROQ_API_KEY
printf '\n'
if [[ -z "${GROQ_API_KEY//[[:space:]]/}" ]]; then
  echo 'No key entered. Nothing was started.'
  exit 1
fi

body_file="$(mktemp)"
trap 'rm -f "$body_file"; unset GROQ_API_KEY' EXIT
printf 'Checking the key with Groq...\n'
set +e
http_code="$(printf 'header = "Authorization: Bearer %s"\n' "$GROQ_API_KEY" | curl --config - --silent --show-error --connect-timeout 10 --max-time 25 --output "$body_file" --write-out '%{http_code}' https://api.groq.com/openai/v1/models 2>/dev/null)"
curl_rc=$?
set -e
if [[ $curl_rc -ne 0 ]]; then
  echo 'Could not reach Groq. Check your internet connection and try again.'
  exit 1
fi
if [[ "$http_code" != "200" ]]; then
  case "$http_code" in
    401) echo 'Groq rejected this key (401 Unauthorized). Create a new active API key.' ;;
    403) echo 'Groq refused this request (403 Forbidden). Check key/account permissions.' ;;
    429) echo 'Groq returned 429 Too Many Requests or quota/rate limit reached. Check your Groq account and limits.' ;;
    *) echo "Groq returned HTTP $http_code. The key may be invalid, restricted, or the service may have a problem." ;;
  esac
  echo 'The server was not started. No key was written to the project files.'
  exit 1
fi

echo 'SUCCESS: Groq accepted the key and returned the model list.'
echo 'Compiling BOD+ AI backend...'
javac --add-modules jdk.httpserver,java.net.http BODplus_Master.java
echo 'Starting BOD+ AI. The key is passed to the backend process, not placed in HTML/JavaScript/source files.'
echo 'Keep this terminal open. Stop the app with Ctrl+C.'
export GROQ_API_KEY
java --add-modules jdk.httpserver,java.net.http BODplus_Master
