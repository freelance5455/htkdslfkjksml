#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."

if ! command -v javac >/dev/null 2>&1 || ! command -v java >/dev/null 2>&1; then
  echo "Java is missing. In Termux, run: pkg update && pkg install openjdk-21"
  exit 1
fi

if [[ -z "${GROQ_API_KEY:-}" ]]; then
  printf 'Enter your NEW Groq API key (input hidden): '
  IFS= read -r -s GROQ_API_KEY
  printf '\n'
  if [[ -z "${GROQ_API_KEY//[[:space:]]/}" ]]; then
    echo "No API key entered. Nothing was started."
    exit 1
  fi
  export GROQ_API_KEY
fi

printf '\nCompiling BOD+ AI backend...\n'
javac --add-modules jdk.httpserver,java.net.http BODplus_Master.java
printf '\nStarting BOD+ AI...\n'
java --add-modules jdk.httpserver,java.net.http BODplus_Master
