$ErrorActionPreference = 'Stop'
Set-Location (Split-Path -Parent $PSScriptRoot)

if (-not (Get-Command javac -ErrorAction SilentlyContinue)) {
    Write-Host 'Java JDK 17 or newer is required. Install a JDK, then open a new PowerShell window.' -ForegroundColor Red
    exit 1
}

if (-not $env:GROQ_API_KEY) {
    $secure = Read-Host 'Enter your NEW Groq API key (input hidden)' -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { $env:GROQ_API_KEY = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
}

try {
    javac --add-modules jdk.httpserver,java.net.http BODplus_Master.java
    if ($LASTEXITCODE -ne 0) { throw 'Java compilation failed.' }
    java --add-modules jdk.httpserver,java.net.http BODplus_Master
}
finally {
    Remove-Item Env:\GROQ_API_KEY -ErrorAction SilentlyContinue
}
