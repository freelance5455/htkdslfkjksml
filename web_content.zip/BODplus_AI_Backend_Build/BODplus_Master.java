import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.*;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * BOD+ AI — Java backend serving the local HTML/CSS/JavaScript frontend.
 * Requires Java 17+. Uses Groq's OpenAI-compatible Chat Completions API.
 *
 * SECURITY: Never put a real API key in this source. The key is read from the
 * GROQ_API_KEY environment variable, or hidden console input at startup. It is
 * kept in server memory only. Do not commit or distribute the key.
 */
public class BODplus_Master {
    private static final String GROQ_BASE = "https://api.groq.com/openai/v1";
    private static final String DEFAULT_MODEL = "openai/gpt-oss-20b";
    private static final int PORT = intEnv("PORT", 8080);
    private static final String HOST = System.getenv().getOrDefault("HOST", "127.0.0.1");
    private static volatile String groqApiKey = trimToNull(System.getenv("GROQ_API_KEY"));
    private static volatile Set<String> cachedModels = Collections.emptySet();
    private static volatile long modelsCachedUntil = 0L;
    private static final Object MODEL_LOCK = new Object();
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(12)).followRedirects(HttpClient.Redirect.NEVER).build();
    private static final ConcurrentHashMap<String, WindowCounter> RATE_LIMIT = new ConcurrentHashMap<>();
    private static final long RATE_WINDOW_MS = 60_000L;
    private static final int RATE_MAX = 12;
    private static final String SYSTEM_PROMPT = "You are BOD+ AI, a capable, friendly and honest AI assistant. Help with learning, writing, planning, reasoning, troubleshooting, and software development. Prefer clear explanations and usable solutions. For code, provide complete examples and clearly state the runtime/setup requirements. Do not claim to have executed code or verified an account when you have not. If a request relies on live/current information that you cannot verify through available tools, say so. Never ask for or expose passwords, API keys, or other secrets in chat. When users ask for secrets in code, explain safe server-side configuration.";

    public static void main(String[] args) throws Exception {
        obtainKeyIfPossible();
        HttpServer server = null;
        int actualPort = PORT;
        IOException bindError = null;
        for (int attempt = 0; attempt < 12; attempt++, actualPort++) {
            try {
                server = HttpServer.create(new InetSocketAddress(HOST, actualPort), 0);
                break;
            } catch (java.net.BindException e) {
                bindError = e; // Try the next local port if the preferred one is busy.
            }
        }
        if (server == null) throw new IOException("Could not open a local port. Change PORT or close the app using it.", bindError);
        final int runningPort = server.getAddress().getPort();
        server.setExecutor(Executors.newFixedThreadPool(Math.max(4, Runtime.getRuntime().availableProcessors())));
        server.createContext("/favicon.svg", BODplus_Master::handleFavicon);
        server.createContext("/", BODplus_Master::handleRoot);
        server.createContext("/api/status", BODplus_Master::handleStatus);
        server.createContext("/api/chat", BODplus_Master::handleChat);
        server.createContext("/api/summary", BODplus_Master::handleSummary);
        server.start();
        System.out.println("\nBOD+ AI is running at http://127.0.0.1:" + runningPort);
        System.out.println("Backend host: " + HOST + " | API key: " + (groqApiKey == null ? "NOT CONFIGURED" : "loaded in server memory"));
        System.out.println("Keep this terminal open while using the app. Press Ctrl+C to stop.\n");
    }

    private static void obtainKeyIfPossible() {
        if (groqApiKey != null) return;
        Console console = System.console();
        if (console != null) {
            char[] secret = console.readPassword("Paste your NEW Groq API key (input hidden): ");
            if (secret != null && secret.length > 0) {
                groqApiKey = new String(secret).trim();
                Arrays.fill(secret, '\0');
            }
        }
    }

    private static void handleRoot(HttpExchange ex) throws IOException {
        if (!"GET".equals(ex.getRequestMethod())) { sendJson(ex, 405, map("error", "Method not allowed.")); return; }
        String path = ex.getRequestURI().getPath();
        if (!"/".equals(path) && !"/index.html".equals(path)) { sendJson(ex, 404, map("error", "Not found.")); return; }
        Headers h = ex.getResponseHeaders();
        setSecurityHeaders(h);
        h.set("Content-Type", "text/html; charset=utf-8");
        h.set("Cache-Control", "no-store, max-age=0");
        Path htmlPath = Path.of("public", "index.html");
        if (!Files.isRegularFile(htmlPath)) {
            sendJson(ex, 500, map("error", "The frontend file public/index.html is missing. Run BOD+ from the extracted project folder."));
            return;
        }
        byte[] out = Files.readAllBytes(htmlPath);
        ex.sendResponseHeaders(200, out.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(out); }
    }

    private static void handleFavicon(HttpExchange ex) throws IOException {
        if (!"GET".equals(ex.getRequestMethod())) { sendJson(ex, 405, map("error", "Method not allowed.")); return; }
        Path iconPath = Path.of("public", "favicon.svg");
        if (!Files.isRegularFile(iconPath)) { sendJson(ex, 404, map("error", "Icon not found.")); return; }
        byte[] bytes = Files.readAllBytes(iconPath);
        setSecurityHeaders(ex.getResponseHeaders());
        ex.getResponseHeaders().set("Content-Type", "image/svg+xml; charset=utf-8");
        ex.getResponseHeaders().set("Cache-Control", "no-store, max-age=0");
        ex.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    private static void handleStatus(HttpExchange ex) throws IOException {
        if (!"GET".equals(ex.getRequestMethod())) { sendJson(ex, 405, map("ok", false, "error", "Use GET.")); return; }
        if (groqApiKey == null || groqApiKey.isBlank()) {
            sendJson(ex, 200, map("ok", false, "configured", false, "error", "No API key is configured on the backend. Restart in a terminal and paste a newly created key when prompted, or set GROQ_API_KEY on the server."));
            return;
        }
        try {
            Set<String> ids = loadModels(true);
            ArrayList<Object> visible = new ArrayList<>();
            for (String id : preferredModelOrder(ids)) visible.add(map("id", id, "name", modelName(id)));
            sendJson(ex, 200, map("ok", true, "configured", true, "message", "Groq API key verified successfully.", "models", visible, "defaultModel", visible.isEmpty() ? DEFAULT_MODEL : ((Map<?, ?>) visible.get(0)).get("id")));
        } catch (ApiFailure f) {
            sendJson(ex, 200, map("ok", false, "configured", true, "error", f.getMessage(), "status", f.status));
        } catch (Exception e) {
            sendJson(ex, 200, map("ok", false, "configured", true, "error", "Could not verify the Groq connection. Check your internet connection and try again."));
        }
    }

    private static void handleChat(HttpExchange ex) throws IOException {
        if (!"POST".equals(ex.getRequestMethod())) { sendJson(ex, 405, map("error", "Use POST.")); return; }
        if (groqApiKey == null || groqApiKey.isBlank()) { sendJson(ex, 503, map("error", "The backend has no Groq API key. Restart the Java server and configure a new key.")); return; }
        String client = clientAddress(ex);
        if (!allowRequest(client)) { sendJson(ex, 429, map("error", "Too many requests from this device. Please wait about one minute and try again.")); return; }
        try {
            Map<String, Object> input = asMap(Json.parse(readBody(ex, 300_000)));
            String model = string(input.get("model"));
            if (model == null || model.isBlank()) model = DEFAULT_MODEL;
            Set<String> models = loadModels(false);
            if (!models.contains(model)) {
                sendJson(ex, 400, map("error", "That model is not currently available for this Groq API key. Open Settings and choose a model from the verified list.")); return;
            }
            List<Object> rawMessages = asList(input.get("messages"));
            if (rawMessages == null || rawMessages.isEmpty() || rawMessages.size() > 36) {
                sendJson(ex, 400, map("error", "Send between 1 and 36 conversation messages.")); return;
            }
            ArrayList<Object> messages = new ArrayList<>();
            messages.add(map("role", "system", "content", SYSTEM_PROMPT));
            int total = 0;
            for (Object raw : rawMessages) {
                Map<String, Object> msg = asMap(raw);
                if (msg == null) continue;
                String role = string(msg.get("role"));
                String content = string(msg.get("content"));
                if (!("user".equals(role) || "assistant".equals(role)) || content == null || content.isBlank()) continue;
                if (content.length() > 15_000) { sendJson(ex, 413, map("error", "A single message is too long. Please keep each message under 15,000 characters.")); return; }
                total += content.length();
                if (total > 60_000) { sendJson(ex, 413, map("error", "This conversation is too long for one request. Start a new chat or ask for a summary first.")); return; }
                messages.add(map("role", role, "content", content));
            }
            if (messages.size() < 2) { sendJson(ex, 400, map("error", "Type a message before sending.")); return; }
            Map<String, Object> groqBody = map("model", model, "messages", messages, "temperature", 0.7, "max_completion_tokens", 4096);
            HttpRequest req = HttpRequest.newBuilder(URI.create(GROQ_BASE + "/chat/completions"))
                    .timeout(Duration.ofSeconds(100)).header("Authorization", "Bearer " + groqApiKey)
                    .header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(Json.stringify(groqBody))).build();
            HttpResponse<String> response = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new ApiFailure(response.statusCode(), explainGroqError(response.statusCode(), response.body()));
            }
            Map<String, Object> body = asMap(Json.parse(response.body()));
            List<Object> choices = asList(body == null ? null : body.get("choices"));
            Map<String, Object> first = choices == null || choices.isEmpty() ? null : asMap(choices.get(0));
            Map<String, Object> message = asMap(first == null ? null : first.get("message"));
            String reply = string(message == null ? null : message.get("content"));
            if (reply == null || reply.isBlank()) throw new ApiFailure(502, "Groq returned an empty response. Try again or select another model.");
            sendJson(ex, 200, map("reply", reply, "model", model));
        } catch (ApiFailure f) {
            sendJson(ex, f.status == 429 ? 429 : 502, map("error", f.getMessage()));
        } catch (IllegalArgumentException e) {
            sendJson(ex, 400, map("error", "The request could not be read. Please try again."));
        } catch (Exception e) {
            sendJson(ex, 502, map("error", "BOD+ could not reach Groq. Check the connection and API key, then try again."));
        }
    }

    private static void handleSummary(HttpExchange ex) throws IOException {
        // The summary feature uses the same chat endpoint and system-side safeguards.
        if (!"POST".equals(ex.getRequestMethod())) { sendJson(ex, 405, map("error", "Use POST.")); return; }
        try {
            Map<String, Object> body = asMap(Json.parse(readBody(ex, 100_000)));
            String text = string(body == null ? null : body.get("conversation"));
            if (text == null || text.isBlank()) { sendJson(ex, 400, map("error", "There is no conversation to summarize.")); return; }
            // Forward internally through the same validated chat handler would be awkward, so call Groq directly with server-side prompt.
            if (groqApiKey == null) { sendJson(ex, 503, map("error", "The backend has no Groq API key.")); return; }
            if (!allowRequest(clientAddress(ex))) { sendJson(ex, 429, map("error", "Too many requests. Please wait a minute.")); return; }
            String model = string(body.get("model")); if (model == null || !loadModels(false).contains(model)) model = DEFAULT_MODEL;
            List<Object> msgs = List.of(map("role", "system", "content", SYSTEM_PROMPT), map("role", "user", "content", "Summarize this conversation clearly, preserving decisions, useful facts, unresolved questions, and next steps.\n\nCONVERSATION:\n" + text.substring(0, Math.min(text.length(), 40_000))));
            HttpRequest req = HttpRequest.newBuilder(URI.create(GROQ_BASE + "/chat/completions")).timeout(Duration.ofSeconds(90))
                    .header("Authorization", "Bearer " + groqApiKey).header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(Json.stringify(map("model", model, "messages", msgs, "temperature", 0.3, "max_completion_tokens", 1800)))).build();
            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (resp.statusCode() < 200 || resp.statusCode() >= 300) throw new ApiFailure(resp.statusCode(), explainGroqError(resp.statusCode(), resp.body()));
            Map<String, Object> parsed = asMap(Json.parse(resp.body()));
            List<Object> choices = asList(parsed.get("choices"));
            Map<String, Object> first = choices == null || choices.isEmpty() ? null : asMap(choices.get(0));
            Map<String, Object> message = asMap(first == null ? null : first.get("message"));
            String reply = string(message == null ? null : message.get("content"));
            if (reply == null || reply.isBlank()) throw new ApiFailure(502, "No summary was returned. Try again.");
            sendJson(ex, 200, map("reply", reply, "model", model));
        } catch (ApiFailure f) { sendJson(ex, f.status == 429 ? 429 : 502, map("error", f.getMessage())); }
        catch (Exception e) { sendJson(ex, 400, map("error", "The summary request failed. Please try again.")); }
    }

    private static Set<String> loadModels(boolean force) throws Exception {
        long now = System.currentTimeMillis();
        if (!force && now < modelsCachedUntil && !cachedModels.isEmpty()) return cachedModels;
        synchronized (MODEL_LOCK) {
            now = System.currentTimeMillis();
            if (!force && now < modelsCachedUntil && !cachedModels.isEmpty()) return cachedModels;
            HttpRequest req = HttpRequest.newBuilder(URI.create(GROQ_BASE + "/models")).timeout(Duration.ofSeconds(18))
                    .header("Authorization", "Bearer " + groqApiKey).header("Content-Type", "application/json").GET().build();
            HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (resp.statusCode() < 200 || resp.statusCode() >= 300) throw new ApiFailure(resp.statusCode(), explainGroqError(resp.statusCode(), resp.body()));
            Map<String, Object> root = asMap(Json.parse(resp.body()));
            List<Object> data = asList(root == null ? null : root.get("data"));
            LinkedHashSet<String> ids = new LinkedHashSet<>();
            if (data != null) for (Object obj : data) {
                Map<String, Object> m = asMap(obj); String id = string(m == null ? null : m.get("id"));
                if (id == null || id.isBlank()) continue;
                String lower = id.toLowerCase(Locale.ROOT);
                if (lower.contains("whisper") || lower.contains("speech") || lower.contains("tts") || lower.contains("guard") || lower.contains("embed") || lower.contains("moderation") || lower.contains("orpheus")) continue;
                ids.add(id);
            }
            if (ids.isEmpty()) throw new ApiFailure(502, "The key was accepted, but Groq did not return any chat models for this account.");
            cachedModels = Collections.unmodifiableSet(ids); modelsCachedUntil = System.currentTimeMillis() + 5 * 60_000L;
            return cachedModels;
        }
    }

    private static List<String> preferredModelOrder(Set<String> ids) {
        ArrayList<String> out = new ArrayList<>();
        String[] preferred = {"openai/gpt-oss-20b", "openai/gpt-oss-120b", "qwen/qwen3.8-27b", "qwen/qwen3.6-27b", "llama-3.3-70b-versatile", "llama-3.1-8b-instant"};
        for (String p : preferred) if (ids.contains(p)) out.add(p);
        for (String id : ids) if (!out.contains(id)) out.add(id);
        if (out.size() > 20) return out.subList(0, 20);
        return out;
    }

    private static String modelName(String id) {
        if ("openai/gpt-oss-20b".equals(id)) return "GPT OSS 20B · balanced and fast";
        if ("openai/gpt-oss-120b".equals(id)) return "GPT OSS 120B · advanced reasoning";
        if (id.toLowerCase(Locale.ROOT).contains("qwen3.8")) return "Qwen 3.8 · capable general model";
        if (id.contains("llama-3.3-70b")) return "Llama 3.3 70B";
        if (id.contains("llama-3.1-8b")) return "Llama 3.1 8B · fast";
        return id;
    }

    private static String explainGroqError(int status, String body) {
        if (status == 401 || status == 403) return "Groq rejected this API key (HTTP " + status + "). Create a fresh key in the Groq Console and restart BOD+ with that key. The key you previously posted should be revoked.";
        if (status == 429) return "Groq rate limit or usage quota reached. Wait a little, check your Groq Console usage, or try again later.";
        if (status == 400) {
            String msg = "Groq rejected the request. The selected model may not be available to this key.";
            try { Map<String, Object> root = asMap(Json.parse(body)); Map<String, Object> err = asMap(root == null ? null : root.get("error")); String detail = string(err == null ? null : err.get("message")); if (detail != null && !detail.isBlank()) msg = "Groq rejected the request: " + detail.substring(0, Math.min(240, detail.length())); } catch (Exception ignored) { }
            return msg;
        }
        return "Groq returned an error (HTTP " + status + "). Check the Groq service and your model access, then retry.";
    }

    private static boolean allowRequest(String addr) {
        long now = System.currentTimeMillis();
        WindowCounter c = RATE_LIMIT.compute(addr, (k, old) -> old == null || now - old.start >= RATE_WINDOW_MS ? new WindowCounter(now, new AtomicInteger(1)) : old);
        int count = c.count.incrementAndGet() - 1;
        if (RATE_LIMIT.size() > 1500) RATE_LIMIT.entrySet().removeIf(e -> now - e.getValue().start > RATE_WINDOW_MS * 2);
        return count <= RATE_MAX;
    }
    private static String clientAddress(HttpExchange ex) { return ex.getRemoteAddress() == null ? "unknown" : ex.getRemoteAddress().getAddress().getHostAddress(); }
    private static String readBody(HttpExchange ex, int limit) throws IOException {
        try (InputStream in = ex.getRequestBody(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192]; int n, total = 0;
            while ((n = in.read(buf)) != -1) { total += n; if (total > limit) throw new IllegalArgumentException("Request too large"); out.write(buf, 0, n); }
            return out.toString(StandardCharsets.UTF_8);
        }
    }
    private static void sendJson(HttpExchange ex, int code, Object value) throws IOException {
        byte[] bytes = Json.stringify(value).getBytes(StandardCharsets.UTF_8);
        setSecurityHeaders(ex.getResponseHeaders()); ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Cache-Control", "no-store, max-age=0"); ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }
    private static void setSecurityHeaders(Headers h) {
        h.set("X-Content-Type-Options", "nosniff"); h.set("X-Frame-Options", "DENY"); h.set("Referrer-Policy", "no-referrer");
        h.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
        h.set("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
    }
    private static int intEnv(String key, int def) { try { return Integer.parseInt(System.getenv().getOrDefault(key, String.valueOf(def))); } catch (Exception e) { return def; } }
    private static String trimToNull(String s) { return s == null || s.trim().isEmpty() ? null : s.trim(); }
    private static String string(Object o) { return o instanceof String ? (String) o : null; }
    @SuppressWarnings("unchecked") private static Map<String, Object> asMap(Object o) { return o instanceof Map ? (Map<String, Object>) o : null; }
    @SuppressWarnings("unchecked") private static List<Object> asList(Object o) { return o instanceof List ? (List<Object>) o : null; }
    private static Map<String, Object> map(Object... kv) { LinkedHashMap<String, Object> m = new LinkedHashMap<>(); for (int i=0;i+1<kv.length;i+=2) m.put(String.valueOf(kv[i]), kv[i+1]); return m; }
    private static final class WindowCounter { final long start; final AtomicInteger count; WindowCounter(long start, AtomicInteger count) { this.start=start; this.count=count; } }
    private static final class ApiFailure extends Exception { final int status; ApiFailure(int status, String message) { super(message); this.status = status; } }

    // Small, self-contained JSON reader/writer: avoids third-party dependencies in this one-file app.
    private static final class Json {
        static Object parse(String text) { return new Parser(text).parse(); }
        static String stringify(Object value) { StringBuilder b = new StringBuilder(); write(value, b); return b.toString(); }
        private static void write(Object v, StringBuilder b) {
            if (v == null) { b.append("null"); return; }
            if (v instanceof String || v instanceof Character) { quote(String.valueOf(v), b); return; }
            if (v instanceof Number || v instanceof Boolean) { b.append(v); return; }
            if (v instanceof Map) { b.append('{'); boolean first=true; for (Object eo: ((Map<?,?>)v).entrySet()) { Map.Entry<?,?> e=(Map.Entry<?,?>)eo; if (!first)b.append(','); first=false; quote(String.valueOf(e.getKey()),b); b.append(':'); write(e.getValue(),b); } b.append('}'); return; }
            if (v instanceof Iterable) { b.append('['); boolean first=true; for (Object item:(Iterable<?>)v) { if(!first)b.append(','); first=false; write(item,b); } b.append(']'); return; }
            quote(String.valueOf(v), b);
        }
        private static void quote(String s, StringBuilder b) { b.append('"'); for (int i=0;i<s.length();i++) { char c=s.charAt(i); switch(c) { case '"': b.append("\\\""); break; case '\\': b.append("\\\\"); break; case '\b': b.append("\\b"); break; case '\f': b.append("\\f"); break; case '\n': b.append("\\n"); break; case '\r': b.append("\\r"); break; case '\t': b.append("\\t"); break; default: if(c<0x20)b.append(String.format("\\u%04x",(int)c)); else b.append(c); } } b.append('"'); }
        private static final class Parser {
            final String s; int i=0; Parser(String s) { this.s=s==null?"":s; }
            Object parse() { skip(); Object v=value(); skip(); if(i!=s.length())throw new IllegalArgumentException("Trailing JSON"); return v; }
            Object value() { skip(); if(i>=s.length())throw new IllegalArgumentException("Empty JSON"); char c=s.charAt(i); if(c=='{')return object(); if(c=='[')return array(); if(c=='"')return str(); if(c=='t'){literal("true");return true;} if(c=='f'){literal("false");return false;} if(c=='n'){literal("null");return null;} return number(); }
            Map<String,Object> object() { i++; skip(); LinkedHashMap<String,Object> m=new LinkedHashMap<>(); if(take('}'))return m; while(true){skip(); if(i>=s.length()||s.charAt(i)!='"')throw new IllegalArgumentException("Object key expected"); String k=str(); skip(); require(':'); Object v=value(); m.put(k,v); skip(); if(take('}'))return m; require(',');} }
            List<Object> array() { i++; skip(); ArrayList<Object>a=new ArrayList<>(); if(take(']'))return a; while(true){a.add(value());skip();if(take(']'))return a;require(',');} }
            String str() { require('"'); StringBuilder b=new StringBuilder(); while(i<s.length()){char c=s.charAt(i++); if(c=='"')return b.toString(); if(c!='\\'){b.append(c);continue;} if(i>=s.length())throw new IllegalArgumentException("Bad escape"); char e=s.charAt(i++); switch(e){case '"':b.append('"');break;case '\\':b.append('\\');break;case '/':b.append('/');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'u':if(i+4>s.length())throw new IllegalArgumentException("Bad unicode");b.append((char)Integer.parseInt(s.substring(i,i+4),16));i+=4;break;default:throw new IllegalArgumentException("Bad escape");}}throw new IllegalArgumentException("Unclosed string"); }
            Number number() { int start=i; if(take('-')){} while(i<s.length()&&Character.isDigit(s.charAt(i)))i++; if(take('.'))while(i<s.length()&&Character.isDigit(s.charAt(i)))i++; if(i<s.length()&&(s.charAt(i)=='e'||s.charAt(i)=='E')){i++;if(i<s.length()&&(s.charAt(i)=='+'||s.charAt(i)=='-'))i++;while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;} if(start==i)throw new IllegalArgumentException("Bad number"); String n=s.substring(start,i); try{return n.contains(".")||n.contains("e")||n.contains("E")?Double.valueOf(n):Long.valueOf(n);}catch(Exception e){throw new IllegalArgumentException("Bad number");} }
            void literal(String x){if(!s.startsWith(x,i))throw new IllegalArgumentException("Bad literal");i+=x.length();} void skip(){while(i<s.length()&&Character.isWhitespace(s.charAt(i)))i++;} boolean take(char c){if(i<s.length()&&s.charAt(i)==c){i++;return true;}return false;} void require(char c){if(!take(c))throw new IllegalArgumentException("Expected "+c);}
        }
    }

}
