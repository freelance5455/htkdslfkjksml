# Security notes

- No API key is stored in project files or frontend storage.
- The launch scripts request a replacement key through hidden terminal input and pass it to the Java process as `GROQ_API_KEY`.
- The Java backend binds to loopback (`127.0.0.1`) by default; keep this setting for local use.
- Rate limiting is included for chat and summary requests, with a modest per-IP limit.
- Chat history is stored in local browser storage and is not synchronized to a server.
- Revoke any secret pasted into chat or committed to a repository. Create a fresh key in the Groq Console.
- For public hosting or a product with customer accounts, this local prototype needs a dedicated production security review and additional authentication/abuse controls before exposure to the internet.
