# BOD+ AI — Backend Build

**Package:** BOD+ AI web app with a Java backend, mobile-first HTML/CSS/JavaScript interface, and a refreshed custom B+ app icon.

This ZIP is the complete editable project source. It is **not an Android APK**. It runs in a browser while the Java backend runs locally in Termux or on a computer.

## Included

- `BODplus_Master.java` — Java backend that calls Groq and serves the app.
- `public/index.html` — responsive BOD+ AI interface (HTML, CSS, and JavaScript in one frontend file).
- `public/favicon.svg` — refreshed B+ logo used by the page and included as an app-icon asset.
- `scripts/run-termux.sh` — Android/Termux launcher that asks for the API key without echoing it, compiles the Java source, and starts the backend.
- `scripts/run-windows.ps1` — Windows PowerShell launcher with hidden key input.
- `SECURITY.md` — important API-key and deployment notes.

## Android phone: run with Termux

1. Extract the ZIP into a folder on your phone.
2. Install Termux from a trusted official distribution, open it, and run:

   ```sh
   pkg update
   pkg install openjdk-21
   ```

3. In Termux, go to the extracted project directory. If you put it in Downloads, you may first need:

   ```sh
   termux-setup-storage
   cd ~/storage/shared/Download/BODplus_AI_Backend_Build
   ```

   Use the actual folder name and path where you extracted the ZIP.

4. Start the project:

   ```sh
   bash scripts/run-termux.sh
   ```

5. Recommended: run `bash scripts/verify-and-run-termux.sh`. It asks for the key with hidden typing, tests it against Groq’s `/models` endpoint, and only starts the app if Groq accepts it. The key is not written to project files. If it says `curl` is missing, run `pkg install curl`.
6. Alternatively, run `bash scripts/run-termux.sh`; it starts the app and accepts a key, then you can verify it inside BOD+.
7. Keep Termux open. Open the exact local address printed in Termux, normally `http://127.0.0.1:8080`.
8. Open **Settings & connection** in BOD+ and press **Verify Groq connection**. It checks the key against Groq and lists models that the account can access. Only start chatting once it reports success.

If Java reports that the port is busy, use the port printed by the server. The server tries the next few ports automatically.

## Computer

Install a JDK 17 or newer. Open PowerShell in the extracted project folder and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run-windows.ps1
```

Enter the new Groq key at the hidden prompt, then open the local address printed in the terminal.

## API key: important

The key previously pasted into the chat is treated as exposed and is **not included** in this package. Revoke it and create a replacement in the Groq Console: https://console.groq.com/keys . Never send the key to another person or put it in HTML, JavaScript, source code, a screenshot, or a public repository.

The browser calls this Java backend, and the Java backend sends requests to Groq. The key is never returned to the browser. Local browser chat history is stored on that device only.

## Important limits before selling or publishing

By default the server binds to `127.0.0.1` so it can only be accessed on the same device. This helps protect the local API endpoint. **Do not change it to `0.0.0.0` or put this server directly on the public internet.** A hosted, multi-user product needs HTTPS, user authentication, account-level authorization, abuse controls, logging/monitoring, secure secret management, privacy terms, and a plan for API usage costs. A backend hides the API key from page source, but does not by itself stop other people from using an open public endpoint.

This project needs internet access and a valid, active Groq API key with available quota. It cannot make Groq return answers if the key is revoked, the account has no quota, the service is unavailable, or the selected model is inaccessible. The connection verifier gives the backend/API error it can detect; it cannot guarantee the user's account is in good standing.
