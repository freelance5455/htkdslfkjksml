package com.sohan.searchitsohan;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.webkit.*;
import android.widget.*;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.content.Intent;
import android.net.Uri;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(8,8,8), PANEL = Color.rgb(17,17,17),
        BORDER = Color.rgb(41,41,41), TEXT = Color.rgb(245,245,245),
        MUTED = Color.rgb(133,133,133), BLUE = Color.rgb(131,191,255);
    private LinearLayout root, top, tabStrip, bottom;
    private FrameLayout webHost;
    private EditText address;
    private TextView tabCount;
    private final ArrayList<Tab> tabs = new ArrayList<>();
    private int active = -1;

    private static class Tab {
        WebView web;
        String title = "New tab";
        String url = "";
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildShell();
        addTab();
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER); return t;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private TextView button(String label, int width, int height) {
        TextView b = text(label, 17, TEXT, false);
        b.setBackground(shape(PANEL, BORDER, 12));
        b.setLayoutParams(lp(width, height)); return b;
    }

    private void buildShell() {
        root = column(); root.setBackgroundColor(BG);
        root.setPadding(dp(0), dp(8), dp(0), dp(0));
        setContentView(root);

        top = column(); top.setPadding(dp(14), dp(8), dp(14), dp(10));
        root.addView(top, lp(-1, -2));
        LinearLayout brandRow = row();
        TextView brand = text("Search it Sohan", 19, TEXT, true);
        brand.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        TextView dot = text(".", 19, BLUE, true);
        LinearLayout brandWrap = row(); brandWrap.addView(brand); brandWrap.addView(dot);
        brandRow.addView(brandWrap, new LinearLayout.LayoutParams(0, dp(36), 1));
        TextView plus = button("＋", 36, 36);
        LinearLayout.LayoutParams actionLp = lp(36,36); actionLp.setMargins(dp(6),0,0,0);
        brandRow.addView(plus, actionLp); plus.setOnClickListener(v -> addTab());
        TextView menu = button("⋮", 36, 36);
        LinearLayout.LayoutParams menuLp = lp(36,36); menuLp.setMargins(dp(8),0,0,0);
        brandRow.addView(menu, menuLp);
        menu.setOnClickListener(v -> showMenu(menu));
        top.addView(brandRow);

        LinearLayout addressRow = row();
        LinearLayout box = row(); box.setPadding(dp(12),0,dp(8),0);
        box.setBackground(shape(PANEL, BORDER, 15));
        TextView searchIcon = text("⌕", 20, BLUE, false);
        box.addView(searchIcon, lp(25,-1));
        address = new EditText(this); address.setSingleLine(true);
        address.setTextColor(TEXT); address.setHintTextColor(MUTED);
        address.setHint("Search Google or enter address");
        address.setTextSize(14); address.setPadding(dp(4),0,0,0);
        address.setBackgroundColor(Color.TRANSPARENT);
        address.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_GO);
        box.addView(address, new LinearLayout.LayoutParams(0, dp(46), 1));
        addressRow.addView(box, new LinearLayout.LayoutParams(0, dp(46), 1));
        TextView go = text("➜", 18, BG, true); go.setBackground(shape(BLUE,0,12));
        LinearLayout.LayoutParams goLp = lp(38,38); goLp.setMargins(dp(8),0,0,0);
        addressRow.addView(go, goLp);
        go.setOnClickListener(v -> submitAddress());
        address.setOnEditorActionListener((v, action, event) -> { submitAddress(); return true; });
        top.addView(addressRow, lp(-1,46));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        tabStrip = row(); tabStrip.setPadding(dp(14),dp(8),dp(14),dp(8));
        hsv.addView(tabStrip);
        root.addView(hsv, lp(-1,52));

        webHost = new FrameLayout(this); webHost.setBackgroundColor(Color.WHITE);
        root.addView(webHost, new LinearLayout.LayoutParams(-1,0,1));

        bottom = row(); bottom.setGravity(Gravity.CENTER);
        bottom.setBackgroundColor(Color.rgb(16,16,16));
        bottom.setPadding(dp(4),dp(4),dp(4),dp(4));
        root.addView(bottom, lp(-1,61));
        addBottom("‹", "Back", () -> goBack());
        addBottom("›", "Forward", () -> goForward());
        addBottom("↻", "Reload", () -> { if (current()!=null) current().web.reload(); });
        addBottom("⌂", "Home", () -> goHome());
        addBottom("▢", "Tabs", () -> Toast.makeText(this, tabs.size()+" open tabs", Toast.LENGTH_SHORT).show());
    }

    private void addBottom(String symbol, String label, Runnable action) {
        LinearLayout item = column(); item.setGravity(Gravity.CENTER);
        TextView a = text(symbol,19,MUTED,false);
        TextView b = text(label,9,MUTED,false);
        item.addView(a); item.addView(b);
        bottom.addView(item, new LinearLayout.LayoutParams(0,dp(50),1));
        item.setOnClickListener(v -> action.run());
    }

    private void showMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("New tab").setOnMenuItemClickListener(i -> { addTab(); return true; });
        popup.getMenu().add("Home").setOnMenuItemClickListener(i -> { goHome(); return true; });
        popup.getMenu().add("Reload page").setOnMenuItemClickListener(i -> { if(current()!=null) current().web.reload(); return true; });
        popup.getMenu().add("Close current tab").setOnMenuItemClickListener(i -> { closeTab(active); return true; });
        popup.getMenu().add("About this browser").setOnMenuItemClickListener(i -> { Toast.makeText(this,"Search it Sohan. · Private local browsing history",Toast.LENGTH_LONG).show(); return true; });
        popup.show();
    }

    private void addTab() {
        Tab tab = new Tab();
        WebView web = new WebView(this); tab.web = web;
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true); s.setSupportZoom(true);
        s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setDatabaseEnabled(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch(Exception ignored) {}
                return true;
            }
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                if (current() == tab) { address.setText(url); }
            }
            @Override public void onPageFinished(WebView view, String url) {
                tab.url = url;
                String t = view.getTitle();
                if (t != null && !t.trim().isEmpty()) tab.title = t.length()>18 ? t.substring(0,18) : t;
                if (current() == tab) { address.setText(url); renderTabs(); }
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        tabs.add(tab); webHost.addView(web, new FrameLayout.LayoutParams(-1,-1));
        switchTab(tabs.size()-1);
        loadHome(tab);
    }

    private void loadHome(Tab tab) {
        String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><style>"
          +"*{box-sizing:border-box}body{margin:0;background:#080808;color:#f5f5f5;font-family:Arial;text-align:center}"
          +".page{min-height:100vh;padding:12vh 22px 30px;background:radial-gradient(ellipse at 50% 12%,rgba(131,191,255,.1),transparent 55%),#080808}"
          +".title{font-size:35px;font-weight:800;letter-spacing:-1.8px}.title span{color:#83bfff}.sub{margin-top:9px;color:#888;font-size:13px}"
          +".search{margin:30px auto 0;max-width:460px;height:52px;border:1px solid #333;background:#151515;border-radius:16px;display:flex;align-items:center;padding:0 12px 0 16px;gap:10px}"
          +".search input{width:100%;background:transparent;border:0;outline:0;color:white;font-size:14px}.search button{background:#83bfff;color:#080808;border:0;border-radius:10px;padding:8px 12px;font-weight:700}"
          +".quick{max-width:460px;margin:38px auto 14px;text-align:left;color:#aaa;font-size:12px}.links{max-width:460px;margin:auto;display:grid;grid-template-columns:repeat(3,1fr);gap:10px}"
          +".link{min-height:85px;text-decoration:none;color:#eee;background:#141414;border:1px solid #292929;border-radius:15px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;font-size:12px}"
          +".link b{font-size:22px;color:#83bfff;font-weight:500}.note{margin:35px auto 0;color:#666;font-size:11px;line-height:1.6}</style></head><body><div class='page'>"
          +"<div class='title'>Search it Sohan<span>.</span></div><div class='sub'>A simple place to start browsing.</div>"
          +"<form class='search' action='https://www.google.com/search' method='get'><input name='q' placeholder='Search Google or enter a URL' autocomplete='off'><button>Go</button></form>"
          +"<div class='quick'>QUICK ACCESS</div><div class='links'>"
          +link("W","Wikipedia","https://www.wikipedia.org")+link("G","Google","https://www.google.com")
          +link("▶","YouTube","https://www.youtube.com")+link("R","Reddit","https://www.reddit.com")
          +link("⌘","GitHub","https://www.github.com")+link("D","DuckDuckGo","https://duckduckgo.com")
          +"</div><div class='note'>Browsing history is not saved by this app.<br>Some websites may restrict embedded or automated access.</div></div></body></html>";
        tab.url = ""; tab.title = "New tab";
        tab.web.loadDataWithBaseURL("https://searchitsohan.local/", html, "text/html", "UTF-8", null);
    }
    private String link(String icon, String name, String url) {
        return "<a class='link' href='"+url+"'><b>"+icon+"</b>"+name+"</a>";
    }

    private Tab current() { return active >= 0 && active < tabs.size() ? tabs.get(active) : null; }
    private void switchTab(int index) {
        if (index < 0 || index >= tabs.size()) return;
        active = index;
        for (int i=0;i<tabs.size();i++) tabs.get(i).web.setVisibility(i==active ? View.VISIBLE : View.GONE);
        address.setText(current().url);
        renderTabs();
    }
    private void renderTabs() {
        tabStrip.removeAllViews();
        for (int i=0;i<tabs.size();i++) {
            final int index=i; Tab t=tabs.get(i);
            TextView chip=text(t.title,12,i==active?BLUE:MUTED,false);
            chip.setSingleLine(true); chip.setEllipsize(android.text.TextUtils.TruncateAt.END);
            chip.setPadding(dp(12),0,dp(12),0);
            chip.setBackground(shape(i==active?Color.rgb(22,39,55):PANEL, i==active?Color.rgb(65,105,145):BORDER,10));
            LinearLayout.LayoutParams p=lp(120,35); p.setMargins(0,0,dp(7),0);
            tabStrip.addView(chip,p); chip.setOnClickListener(v -> switchTab(index));
            chip.setOnLongClickListener(v -> { closeTab(index); return true; });
        }
        TextView add=text("+",20,BLUE,false); add.setBackground(shape(PANEL,BORDER,10));
        tabStrip.addView(add,lp(35,35)); add.setOnClickListener(v -> addTab());
    }
    private void closeTab(int index) {
        if(index<0 || index>=tabs.size()) return;
        Tab t=tabs.remove(index); webHost.removeView(t.web); t.web.destroy();
        if(tabs.isEmpty()){ active=-1; addTab(); return; }
        if(active>=tabs.size()) active=tabs.size()-1;
        else if(index<active) active--;
        switchTab(active);
    }
    private String normalize(String raw) {
        String v=raw.trim(); if(v.isEmpty()) return null;
        if(v.matches("(?i)^https?://.*")) return v;
        if(v.matches("(?i)^(localhost|([a-z0-9-]+\\.)+[a-z]{2,})(:\\d+)?(/.*)?$")) return "https://"+v;
        try { return "https://www.google.com/search?q="+URLEncoder.encode(v,"UTF-8"); }
        catch(Exception e){ return "https://www.google.com"; }
    }
    private void submitAddress() {
        String url=normalize(address.getText().toString()); if(url==null) return;
        current().web.loadUrl(url); current().url=url;
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(address.getWindowToken(),0);
        address.clearFocus();
    }
    private void goBack(){ if(current()!=null && current().web.canGoBack()) current().web.goBack(); }
    private void goForward(){ if(current()!=null && current().web.canGoForward()) current().web.goForward(); }
    private void goHome(){ if(current()!=null) loadHome(current()); }

    @Override public void onBackPressed() {
        if(current()!=null && current().web.canGoBack()) current().web.goBack();
        else if(tabs.size()>1) closeTab(active);
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        for(Tab t:tabs){ t.web.stopLoading(); t.web.clearHistory(); t.web.destroy(); }
        tabs.clear(); super.onDestroy();
    }
}
