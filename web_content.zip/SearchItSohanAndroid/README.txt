SEARCH IT SOHAN. — FULL PROJECT PACKAGE

This ZIP contains:
- index.html at the project root (standalone HTML preview/prototype)
- app/src/main/assets/index.html (same HTML packaged as an Android asset)
- Native Android Studio project files (Java + Gradle + manifest)

IMPORTANT:
The standalone index.html uses iframes for external pages. Sites such as Google may block iframe embedding.
The Android app's native Java WebView browser is the intended in-app browsing implementation. It currently builds its matching home screen in Java and loads external websites in the native WebView.

BUILD:
1. Extract this ZIP.
2. Open the extracted SearchItSohanAndroid folder in Android Studio.
3. Sync Gradle (JDK 17).
4. Build > Build APK(s).

This is not a ready-made APK; build it in Android Studio first.
