# BlockLaunch Android app project

This is a native Android Studio project that wraps the BlockLaunch interface in an Android WebView.

## Build an APK
1. On a Windows/Mac/Linux computer, install Android Studio.
2. Extract this project ZIP.
3. In Android Studio choose **Open** and select the `BlockLaunch_Android_App_Project` folder.
4. Allow Gradle sync to finish.
5. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the generated APK using the Android Studio notification / `app/build/outputs/apk/debug/`.

## Important
- This ZIP is source code, not a prebuilt APK.
- This app cannot install or switch Minecraft versions, access private worlds, bypass purchase, or manage Microsoft sign-in.
- The Play shortcut attempts to open the official Minecraft app via `minecraft://`.
- App icon is currently the Android default; a custom launcher icon can be added later.
