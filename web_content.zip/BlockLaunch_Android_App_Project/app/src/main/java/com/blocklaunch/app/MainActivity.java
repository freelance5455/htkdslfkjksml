package com.blocklaunch.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(3, 9, 20));
        getWindow().setNavigationBarColor(Color.rgb(3, 9, 20));
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(3, 9, 20));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("minecraft://")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this,
                            "Minecraft did not open. Make sure the official app is installed.",
                            Toast.LENGTH_LONG).show();
                    }
                    return true;
                }
                return false;
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        View v = getWindow().getDecorView().findViewById(android.R.id.content);
        if (v instanceof WebView && ((WebView)v).canGoBack()) {
            ((WebView)v).goBack();
        } else {
            super.onBackPressed();
        }
    }
}
