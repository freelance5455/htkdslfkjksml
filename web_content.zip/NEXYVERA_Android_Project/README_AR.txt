NEXYVERA Android Project — الإصدار التجريبي 0.2

المشروع ده بيغلف واجهة NEXYVERA الحالية داخل تطبيق Android باستخدام WebView.
هو مشروع مصدر (Source Project)، وليس ملف APK جاهزًا.

طريقة إخراج APK:
1) نزّل Android Studio من الموقع الرسمي: https://developer.android.com/studio
2) فك ضغط ملف NEXYVERA_Android_Project.zip.
3) افتح Android Studio واختر Open، ثم اختر مجلد NEXYVERA_Android_Project.
4) انتظر Gradle Sync، وثبّت Android SDK Platform 35 إذا طلب منك.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد اكتمال البناء، اضغط Locate لفتح مكان ملف APK.

ملاحظات:
- البيانات الصحية الظاهرة تجريبية فقط وليست قراءات حقيقية.
- المشروع لا يتصل بساعة فعلية حتى الآن.
- يحتاج Android Studio واتصال إنترنت أول مرة لتنزيل أدوات البناء.
