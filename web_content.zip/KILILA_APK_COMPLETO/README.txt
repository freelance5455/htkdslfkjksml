KILILA — DESPACHO DE CERVEZA
Versión PWA lista para conversores HTML → APK.

VERSIÓN 4 — administración dinámica de catálogo y canillas.

CONTENIDO
- index.html
- style.css
- app.js
- manifest.json
- sw.js
- icons/kilila.svg

ACCESO INICIAL
ADMINISTRADOR: PIN 1234
EMPLEADO: PIN 1111

DISPOSITIVOS LÓGICOS
DEV-001 · Tablet despacho · Empleado
DEV-002 · Celular administración · Administrador

INCLUYE
- Login por PIN y roles.
- Dashboard.
- Ventas rápidas.
- 8 estilos de cerveza.
- 4 canillas.
- Barriles individuales de 20/30/50 L con ID.
- Estados de barril y conexión a canilla.
- Stock de cerveza e insumos.
- Recetas y producción con consumo automático de insumos.
- Lotes de producción y costo/L estimado.
- Compras.
- Gastos.
- Caja e ingresos/retiros.
- Reportes mensuales.
- Cierre diario.
- Alertas de barriles bajos.
- Auditoría por usuario/dispositivo.
- Respaldo y restauración JSON.
- Persistencia local.
- PWA/offline mediante service worker.

IMPORTANTE
Esta versión funciona localmente en cada dispositivo. Todavía NO implementa sincronización central entre el teléfono y la tablet. Para eso habrá que conectar una base de datos/backend y agregar cola de sincronización/conflictos.

PARA CONVERTIR A APK
Subir el ZIP con index.html en la raíz a un conversor HTML → APK que acepte proyectos estáticos. No mover index.html dentro de una carpeta adicional.


NUEVO EN ESTA VERSIÓN
- ADMINISTRADOR puede cambiar los nombres visibles de las 8 cervezas desde Más > Configuración.
- ADMINISTRADOR puede cambiar los nombres visibles de todos los insumos desde la misma pantalla.
- Los identificadores internos se mantienen para conservar recetas, stock, compras, historial y estadísticas.


Crédito de marca: la aplicación muestra “App construida y diseñada por Marcapedia”.


NUEVO EN V4
- ADMINISTRADOR puede agregar nuevas cervezas desde Más > Configuración.
- Cada cerveza nueva obtiene un ID interno y puede recibir precio y receta.
- ADMINISTRADOR puede editar la receta por cada 100 L y elegir los insumos existentes.
- ADMINISTRADOR puede agregar nuevos insumos indicando categoría y unidad.
- ADMINISTRADOR puede cambiar nombres y unidades de los insumos.
- ADMINISTRADOR puede agregar canillas cuando el negocio amplíe el despacho.
- ADMINISTRADOR puede eliminar una canilla solamente si está sin barril conectado.
- Las cervezas e insumos agregados quedan guardados localmente y aparecen en ventas, stock, producción, compras y recetas.
