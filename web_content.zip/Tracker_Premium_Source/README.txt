Track — Class 9 Syllabus Tracker

Rebuilt from the supplied project ZIP with a refreshed dark navy/purple dashboard UI.
- Removed the left navigation/sidebar concept; content uses the full available width.
- Added a compact Class 9 Syllabus Tracker header.
- Kept the existing date-wise syllabus, subject/chapter completion, notes, to-do items,
  progress tracking, and Android WebView project structure.
- Root HTML and Android WebView asset are synchronized.

Android build: open android-project in Android Studio, sync Gradle, then Build >
Build Bundle(s) / APK(s) > Build APK(s).

Automated checks performed: ZIP integrity, synchronized HTML copies, and JavaScript
syntax validation when Node.js is available. Please also test on the target Android device.
