"""Edma Forex copy-trading backend (FastAPI + SQLite).
Master EA  -> POST /ea/master/event  -> fan-out to active subscribers
Follower EA -> GET /ea/follower/poll -> executes -> POST /ea/follower/ack
"""
import os, secrets, sqlite3, hashlib
from datetime import datetime, timedelta, timezone
from fastapi import FastAPI, Header, HTTPException, Depends
from fastapi.responses import PlainTextResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

DB = os.environ.get("EDMA_DB", "edma.db")
TTL = int(os.environ.get("SIGNAL_TTL", "30"))          # seconds an "open" signal stays valid
PAY_BYPASS = os.environ.get("PAYMENTS_BYPASS") == "1"  # demo only: skip billing
app = FastAPI(title="Edma Copy Trading")
app.add_middleware(CORSMiddleware, allow_origins=os.environ.get("EDMA_ORIGINS", "*").split(","), allow_methods=["*"], allow_headers=["*"])

def now(): return datetime.now(timezone.utc)
def iso(d): return d.isoformat()

def q(sql, args=(), one=False):
    with sqlite3.connect(DB) as c:
        c.row_factory = sqlite3.Row
        cur = c.execute(sql, args)
        rows = cur.fetchall()
        return (rows[0] if rows else None) if one else rows

def ex(sql, args=()):
    with sqlite3.connect(DB) as c:
        return c.execute(sql, args).lastrowid

with sqlite3.connect(DB) as c:
    c.executescript("""
    CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, email TEXT UNIQUE, salt TEXT, pw TEXT, token TEXT, ea_key TEXT UNIQUE, created TEXT);
    CREATE TABLE IF NOT EXISTS strategies(id INTEGER PRIMARY KEY, master_id INT, name TEXT, fee REAL);
    CREATE TABLE IF NOT EXISTS subs(id INTEGER PRIMARY KEY, follower_id INT, strategy_id INT, mult REAL, active INT, paid_until TEXT);
    CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY, strategy_id INT, action TEXT, ticket INT, symbol TEXT, side TEXT, lots REAL, sl REAL, tp REAL, ts TEXT);
    CREATE TABLE IF NOT EXISTS signals(id INTEGER PRIMARY KEY, sub_id INT, trade_id INT, status TEXT, f_ticket INT, ts TEXT);
    """)

def hpw(pw, salt): return hashlib.scrypt(pw.encode(), salt=bytes.fromhex(salt), n=2**14, r=8, p=1).hex()

def user(authorization: str = Header("")):
    u = q("SELECT * FROM users WHERE token=?", (authorization.replace("Bearer ", ""),), True) if authorization else None
    if not u: raise HTTPException(401, "Not signed in")
    return u

def ea_user(x_ea_key: str = Header("")):
    u = q("SELECT * FROM users WHERE ea_key=?", (x_ea_key,), True) if x_ea_key else None
    if not u: raise HTTPException(401, "Bad EA key")
    return u

class Cred(BaseModel): email: str; password: str = Field(min_length=8)
class Strat(BaseModel): name: str; fee: float = 0
class Sub(BaseModel): strategy_id: int; multiplier: float = Field(1.0, gt=0, le=10)
class Event(BaseModel):
    strategy_id: int; action: str; ticket: int; symbol: str
    side: str = ""; lots: float = Field(0, ge=0); sl: float = 0; tp: float = 0
class Ack(BaseModel): signal_id: int; status: str; follower_ticket: int = 0

@app.get("/health")
def health(): return {"ok": True}

@app.post("/auth/register")
def register(b: Cred):
    if q("SELECT 1 FROM users WHERE email=?", (b.email.lower(),), True): raise HTTPException(409, "Email already registered")
    salt = secrets.token_hex(16); tok = secrets.token_urlsafe(32); key = secrets.token_urlsafe(24)
    ex("INSERT INTO users(email,salt,pw,token,ea_key,created) VALUES(?,?,?,?,?,?)", (b.email.lower(), salt, hpw(b.password, salt), tok, key, iso(now())))
    return {"token": tok, "ea_key": key}

@app.post("/auth/login")
def login(b: Cred):
    u = q("SELECT * FROM users WHERE email=?", (b.email.lower(),), True)
    if not u or not secrets.compare_digest(u["pw"], hpw(b.password, u["salt"])): raise HTTPException(401, "Wrong email or password")
    tok = secrets.token_urlsafe(32); ex("UPDATE users SET token=? WHERE id=?", (tok, u["id"]))
    return {"token": tok, "ea_key": u["ea_key"]}

@app.post("/strategies")
def make_strategy(b: Strat, u=Depends(user)):
    return {"id": ex("INSERT INTO strategies(master_id,name,fee) VALUES(?,?,?)", (u["id"], b.name, b.fee))}

@app.get("/strategies")
def strategies(): return [dict(r) for r in q("SELECT id,name,fee,(SELECT COUNT(*) FROM subs WHERE strategy_id=strategies.id AND active=1) AS subscribers FROM strategies")]

@app.post("/subscribe")
def subscribe(b: Sub, u=Depends(user)):
    s = q("SELECT * FROM strategies WHERE id=?", (b.strategy_id,), True)
    if not s: raise HTTPException(404, "No such strategy")
    if q("SELECT 1 FROM subs WHERE follower_id=? AND strategy_id=? AND active=1", (u["id"], b.strategy_id), True): raise HTTPException(409, "Already subscribed")
    if s["fee"] > 0 and not PAY_BYPASS: raise HTTPException(402, "Payment required: connect your payment provider here")
    sid = ex("INSERT INTO subs(follower_id,strategy_id,mult,active,paid_until) VALUES(?,?,?,1,?)", (u["id"], b.strategy_id, b.multiplier, iso(now() + timedelta(days=30))))
    return {"subscription_id": sid}

@app.delete("/subscribe/{sid}")
def unsubscribe(sid: int, u=Depends(user)):
    ex("UPDATE subs SET active=0 WHERE id=? AND follower_id=?", (sid, u["id"])); return {"ok": True}

@app.post("/ea/master/event")
def master_event(e: Event, u=Depends(ea_user)):
    s = q("SELECT * FROM strategies WHERE id=? AND master_id=?", (e.strategy_id, u["id"]), True)
    if not s: raise HTTPException(403, "Not your strategy")
    if e.action not in ("open", "close", "modify"): raise HTTPException(400, "Bad action")
    tid = ex("INSERT INTO trades(strategy_id,action,ticket,symbol,side,lots,sl,tp,ts) VALUES(?,?,?,?,?,?,?,?,?)",
             (e.strategy_id, e.action, e.ticket, e.symbol, e.side.lower(), e.lots, e.sl, e.tp, iso(now())))
    n = 0
    for sub in q("SELECT id FROM subs WHERE strategy_id=? AND active=1 AND paid_until>?", (e.strategy_id, iso(now()))):
        ex("INSERT INTO signals(sub_id,trade_id,status,f_ticket,ts) VALUES(?,?,'pending',0,?)", (sub["id"], tid, iso(now()))); n += 1
    return {"trade_id": tid, "signals": n}

@app.get("/ea/follower/poll", response_class=PlainTextResponse)
def poll(u=Depends(ea_user)):
    ex("UPDATE signals SET status='expired' WHERE status='pending' AND trade_id IN (SELECT id FROM trades WHERE action='open') AND ts<?", (iso(now() - timedelta(seconds=TTL)),))
    rows = q("""SELECT sg.id, t.action, t.ticket, t.symbol, t.side, t.lots, t.sl, t.tp, s.mult FROM signals sg
                JOIN subs s ON s.id=sg.sub_id JOIN trades t ON t.id=sg.trade_id
                WHERE s.follower_id=? AND sg.status='pending' ORDER BY sg.id LIMIT 20""", (u["id"],))
    out = []
    for r in rows:
        lots = round(max(0.01, r["lots"] * r["mult"]), 2) if r["lots"] > 0 else 0
        out.append(f'{r["id"]}|{r["action"]}|{r["ticket"]}|{r["symbol"]}|{r["side"]}|{lots}|{r["sl"]}|{r["tp"]}')
        ex("UPDATE signals SET status='sent' WHERE id=?", (r["id"],))
    return "\n".join(out)

@app.post("/ea/follower/ack")
def ack(a: Ack, u=Depends(ea_user)):
    ex("UPDATE signals SET status=?, f_ticket=? WHERE id=? AND sub_id IN (SELECT id FROM subs WHERE follower_id=?)", (a.status[:10], a.follower_ticket, a.signal_id, u["id"]))
    return {"ok": True}

@app.get("/me")
def me(u=Depends(user)):
    subs = [dict(r) for r in q("SELECT s.id, s.strategy_id, st.name, s.mult, s.active, s.paid_until FROM subs s JOIN strategies st ON st.id=s.strategy_id WHERE s.follower_id=? ORDER BY s.id DESC", (u["id"],))]
    mine = [dict(r) for r in q("SELECT id,name,fee FROM strategies WHERE master_id=?", (u["id"],))]
    return {"email": u["email"], "ea_key": u["ea_key"], "subs": subs, "strategies": mine}

@app.get("/signals/mine")
def my_signals(u=Depends(user)):
    rows = q("""SELECT sg.id, sg.status, sg.ts, t.action, t.symbol, t.side, t.lots, s.mult FROM signals sg
                JOIN subs s ON s.id=sg.sub_id JOIN trades t ON t.id=sg.trade_id
                WHERE s.follower_id=? ORDER BY sg.id DESC LIMIT 25""", (u["id"],))
    return [{"id": r["id"], "status": r["status"], "ts": r["ts"], "action": r["action"], "symbol": r["symbol"], "side": r["side"],
             "lots": round(max(0.01, r["lots"] * r["mult"]), 2) if r["lots"] > 0 else 0} for r in rows]

# Serve the web app from the same server (keep this last)
WEB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "web")
if os.path.isdir(WEB):
    app.mount("/", StaticFiles(directory=WEB, html=True), name="web")
