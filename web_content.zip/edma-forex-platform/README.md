# Edma Forex Copy Trading

Master EA (MT5) -> backend -> follower EAs (MT5). Works with any MT5 broker; you host the backend.

## 1. Run the backend (it also serves the web app at http://localhost:8000/)
    cd backend
    pip install -r requirements.txt
    uvicorn main:app --host 0.0.0.0 --port 8000
Use HTTPS in production (put it behind Caddy or nginx). Docs at /docs.
Set PAYMENTS_BYPASS=1 only for testing; paid strategies return 402 until you connect a payment provider in `/subscribe`.

## 2. Create accounts (curl or /docs)
    POST /auth/register  {"email","password"}      -> token + ea_key (one per person)
    POST /strategies     {"name","fee"}            (Authorization: Bearer <token>, as the master)
    POST /subscribe      {"strategy_id","multiplier"} (as each client)

## 3. MetaTrader 5 setup
1. Copy `mql5/*.mq5` to `MQL5/Experts`, compile in MetaEditor.
2. Tools > Options > Expert Advisors > tick "Allow WebRequest" and add your server URL.
3. Master account: attach EdmaMaster (ServerUrl, master EaKey, StrategyId).
4. Each client account: attach EdmaFollower (ServerUrl, that client's EaKey). Keep MT5 running (use a VPS).

## How it works
- Master deals become open/close/modify events; the backend fans them out to active, paid subscribers.
- Lots are scaled by each client's multiplier; followers cap lots with MaxLots.
- Follower trades are tagged `EDMA:<master ticket>` so closes and modifies map back; retries never double-open.
- Stale open signals expire after 30 s (SIGNAL_TTL).

## Not included yet (needed before real clients)
Payment provider webhooks, KYC, an admin panel, per-client risk limits (equity stop), email verification, rate limiting, hedging-only support (netting accounts not handled), and the regulatory licensing for managing or copying client money.

## Web app
`web/index.html` talks to the backend for sign-up/login, strategies, subscriptions and the copied-trades feed. If you host it on a different domain, set `window.EDMA_API="https://your-api"` before the script and `EDMA_ORIGINS=https://your-site` on the server.
Prices, candles, the practice terminal, wallet and deposits are still simulated; real ones need a broker or data provider.
