//+------------------------------------------------------------------+
//| EdmaMaster.mq5 - attach to the MASTER account's chart            |
//| Sends every open/close/modify to the Edma backend.               |
//+------------------------------------------------------------------+
#property strict
input string ServerUrl  = "http://127.0.0.1:8000"; // allow in Tools > Options > Expert Advisors
input string EaKey      = "";                      // from /auth/register or /auth/login
input int    StrategyId = 1;

void Post(string path, string body)
{
   char data[], res[]; string rh;
   StringToCharArray(body, data, 0, StringLen(body));
   string h = "Content-Type: application/json\r\nX-EA-Key: " + EaKey + "\r\n";
   int code = WebRequest("POST", ServerUrl + path, h, 5000, data, res, rh);
   if(code != 200) PrintFormat("Edma: %s failed, HTTP %d, error %d", path, code, GetLastError());
}

void Send(string action, ulong ticket, string sym, string side, double lots, double sl, double tp)
{
   int dg = (int)SymbolInfoInteger(sym, SYMBOL_DIGITS);
   string b = StringFormat("{\"strategy_id\":%d,\"action\":\"%s\",\"ticket\":%I64u,\"symbol\":\"%s\",\"side\":\"%s\",\"lots\":%.2f,\"sl\":%s,\"tp\":%s}",
              StrategyId, action, ticket, sym, side, lots, DoubleToString(sl, dg), DoubleToString(tp, dg));
   Post("/ea/master/event", b);
}

void OnTradeTransaction(const MqlTradeTransaction &t, const MqlTradeRequest &rq, const MqlTradeResult &rs)
{
   if(t.type == TRADE_TRANSACTION_DEAL_ADD && HistoryDealSelect(t.deal))
   {
      long type = HistoryDealGetInteger(t.deal, DEAL_TYPE);
      if(type != DEAL_TYPE_BUY && type != DEAL_TYPE_SELL) return;
      long entry = HistoryDealGetInteger(t.deal, DEAL_ENTRY);
      ulong pid  = (ulong)HistoryDealGetInteger(t.deal, DEAL_POSITION_ID);
      string sym = HistoryDealGetString(t.deal, DEAL_SYMBOL);
      double vol = HistoryDealGetDouble(t.deal, DEAL_VOLUME);
      if(entry == DEAL_ENTRY_IN)
      {
         double sl = 0, tp = 0;
         if(PositionSelectByTicket(pid)) { sl = PositionGetDouble(POSITION_SL); tp = PositionGetDouble(POSITION_TP); }
         Send("open", pid, sym, type == DEAL_TYPE_BUY ? "buy" : "sell", vol, sl, tp);
      }
      else if(entry == DEAL_ENTRY_OUT || entry == DEAL_ENTRY_OUT_BY)
         Send("close", pid, sym, "", vol, 0, 0);
   }
   else if(t.type == TRADE_TRANSACTION_POSITION && PositionSelectByTicket(t.position))
      Send("modify", t.position, t.symbol, "", 0, PositionGetDouble(POSITION_SL), PositionGetDouble(POSITION_TP));
}
