//+------------------------------------------------------------------+
//| EdmaFollower.mq5 - attach to each CLIENT account's chart         |
//| Polls the Edma backend and mirrors the master's trades.          |
//+------------------------------------------------------------------+
#property strict
#include <Trade\Trade.mqh>
input string ServerUrl    = "http://127.0.0.1:8000";
input string EaKey        = "";
input string SymbolSuffix = "";      // e.g. "m" if your broker uses EURUSDm
input double MaxLots      = 5.0;     // hard safety cap per trade
input int    Slippage     = 20;      // points
input long   Magic        = 770077;
input int    PollSeconds  = 1;
CTrade trade;

int OnInit(){ trade.SetExpertMagicNumber(Magic); trade.SetDeviationInPoints(Slippage); EventSetTimer(PollSeconds); return INIT_SUCCEEDED; }
void OnDeinit(const int r){ EventKillTimer(); }

string Req(string method, string path, string body)
{
   char d[], r[]; string rh;
   if(body != "") StringToCharArray(body, d, 0, StringLen(body));
   string h = "Content-Type: application/json\r\nX-EA-Key: " + EaKey + "\r\n";
   int code = WebRequest(method, ServerUrl + path, h, 5000, d, r, rh);
   if(code != 200) { PrintFormat("Edma: %s failed, HTTP %d, error %d", path, code, GetLastError()); return ""; }
   return CharArrayToString(r);
}

void Ack(long id, string st, ulong ft)
{ Req("POST", "/ea/follower/ack", StringFormat("{\"signal_id\":%I64d,\"status\":\"%s\",\"follower_ticket\":%I64u}", id, st, ft)); }

ulong FindPos(string tag)
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      ulong t = PositionGetTicket(i);
      if(t > 0 && PositionGetInteger(POSITION_MAGIC) == Magic && PositionGetString(POSITION_COMMENT) == tag) return t;
   }
   return 0;
}

void Handle(string &f[])
{
   long id = StringToInteger(f[0]); string act = f[1];
   string tag = "EDMA:" + f[2], sym = f[3] + SymbolSuffix, side = f[4];
   double lots = StringToDouble(f[5]), sl = StringToDouble(f[6]), tp = StringToDouble(f[7]);
   ulong p = FindPos(tag);

   if(act == "open")
   {
      if(p != 0) { Ack(id, "done", p); return; }                 // already mirrored
      if(!SymbolSelect(sym, true)) { Ack(id, "failed", 0); return; }
      double step = SymbolInfoDouble(sym, SYMBOL_VOLUME_STEP), mn = SymbolInfoDouble(sym, SYMBOL_VOLUME_MIN);
      lots = MathFloor(MathMin(lots, MaxLots) / step) * step;
      if(lots < mn) { Ack(id, "failed", 0); return; }
      bool ok = (side == "buy") ? trade.Buy(lots, sym, 0, sl, tp, tag) : trade.Sell(lots, sym, 0, sl, tp, tag);
      Ack(id, ok && trade.ResultRetcode() == TRADE_RETCODE_DONE ? "done" : "failed", trade.ResultOrder());
   }
   else if(act == "close")
   {
      if(p == 0) { Ack(id, "done", 0); return; }
      PositionSelectByTicket(p);
      double vol = PositionGetDouble(POSITION_VOLUME), step = SymbolInfoDouble(PositionGetString(POSITION_SYMBOL), SYMBOL_VOLUME_STEP);
      bool ok = (lots + step / 2 >= vol) ? trade.PositionClose(p) : trade.PositionClosePartial(p, lots);
      Ack(id, ok ? "done" : "failed", p);
   }
   else if(act == "modify")
   {
      if(p != 0) trade.PositionModify(p, sl, tp);
      Ack(id, "done", p);
   }
}

void OnTimer()
{
   string txt = Req("GET", "/ea/follower/poll", "");
   if(txt == "") return;
   string lines[]; int n = StringSplit(txt, '\n', lines);
   for(int i = 0; i < n; i++)
   {
      string f[];
      if(StringSplit(lines[i], '|', f) >= 8) Handle(f);
   }
}
