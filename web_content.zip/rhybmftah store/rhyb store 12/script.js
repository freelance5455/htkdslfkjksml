'use strict';
/* ==========================================================
   الرهيب برفيوم - Raheeb Perfume  |  واجهة التطبيق (script.js)
   كل البيانات (منتجات، أقسام، بنرات، شعار، مستخدمون، طلبات) تأتي من السيرفر.
   لا توجد أي أسرار (توكن/آيدي/كلمات مرور) في هذا الملف.
   ========================================================== */

/* عنوان السيرفر: فارغ = نفس السيرفر الذي يقدّم الصفحة.
   عند تغليف التطبيق في APK ضع هنا عنوان السيرفر، مثال:  'http://192.168.1.5:8000'  */
const API_BASE = 'http://172.25.1.154:8000';

const STORAGE_KEY = 'raheeb_state_v1', DB_KEY = 'raheeb_db_v1';
const CUR = { SAR: { label: 'ر.س' }, YER: { label: 'ر.ي' } };
const STATUS_AR = { new: 'جديد', confirmed: 'مؤكد', shipped: 'قيد الشحن', delivered: 'تم التسليم', cancelled: 'ملغي' };
const PALETTE = [['#f4a6b8', '#c9577a'], ['#1d3f8f', '#0a1a45'], ['#d4af37', '#5a3d0a'], ['#c0304a', '#5a0a1e'], ['#3a3a44', '#0c0c10'], ['#2f8f6b', '#0b3a2a']];
const DEFAULT_LOGO = 'assets/icons/logo.svg';

const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const money = (n, cur) => `${Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 })} ${CUR[cur].label}`;
const other = c => c === 'SAR' ? 'YER' : 'SAR';
const price = (p, c) => c === 'SAR' ? +p.sar || 0 : +p.yer || 0;
const oldp = (p, c) => c === 'SAR' ? +p.osar || 0 : +p.oyer || 0;
const avg = p => p.rcount ? p.rsum / p.rcount : 0;
const url = p => /^https?:|^data:/.test(p) ? p : API_BASE + p;
const fmtDate = t => new Date(t * 1000).toLocaleDateString('ar', { year: 'numeric', month: 'short', day: 'numeric' });
const ICONS = {
  cart: '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  filter: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
  tag: '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><circle cx="7" cy="7" r="1.5"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  back: '<path d="M5 12h14M12 5l7 7-7 7"/>',
  trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  xc: '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', minus: '<path d="M5 12h14"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M17.9 17.9A10.9 10.9 0 0 1 12 20C5 20 1 12 1 12a18 18 0 0 1 5.1-5.9M9.9 4.2A9.1 9.1 0 0 1 12 4c7 0 11 8 11 8a18 18 0 0 1-2.2 3.2M1 1l22 22"/>',
  gift: '<path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"/>',
  chev: '<path d="m15 18-6-6 6-6"/>', check: '<path d="M20 6 9 17l-5-5"/>',
  doc: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
  truck: '<path d="M1 3h15v13H1zM16 8h4l3 3v5h-7"/><circle cx="5.5" cy="18.5" r="2"/><circle cx="18.5" cy="18.5" r="2"/>',
  wallet: '<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20M16 15h2"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
  caret: '<path d="m6 9 6 6 6-6"/>',
  gem: '<path d="M6 3h12l4 6-10 12L2 9z"/><path d="M2 9h20M12 3l-4 6 4 12 4-12-4-6"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10z"/><path d="M2 21c0-3 1.9-5.4 5.1-6.9"/>',
  flask: '<path d="M9 2h6M10 2v6L4 20a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2L14 8V2"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  bolt: '<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
  edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
  cog: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5h0a1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'
};
const ic = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24">${ICONS[n]}</svg>`;
const STAR = '<svg class="ic fill" viewBox="0 0 24 24"><path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>';
const CROWN = '<svg viewBox="0 0 64 64" fill="none" stroke="#e8c765" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12l6 5 6-9 6 9 6-5-3 9H23z" fill="#d4af37" stroke="none"/><path d="M22 28c-8 6-10 18-6 30M42 28c8 6 10 18 6 30M24 30c-4 8-4 18 0 28M40 30c4 8 4 18 0 28M32 28v30"/></svg>';

function bottle(c) {
  const [a, b] = c || ['#d4af37', '#5a3d0a'];
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 160'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='${a}'/><stop offset='1' stop-color='${b}'/></linearGradient><linearGradient id='k' x1='0' x2='1'><stop offset='0' stop-color='#f7e08f'/><stop offset='1' stop-color='#9a7420'/></linearGradient></defs><rect x='44' y='6' width='32' height='20' rx='3' fill='url(#k)'/><rect x='54' y='26' width='12' height='10' fill='#c9a24a'/><rect x='18' y='36' width='84' height='116' rx='14' fill='url(#g)' stroke='#f7e08f' stroke-opacity='.6' stroke-width='1.5'/><rect x='36' y='72' width='48' height='38' rx='4' fill='rgba(255,255,255,.88)'/><path d='M60 80l5 7 7-3-2 9H50l-2-9 7 3z' fill='#b8891f'/><rect x='26' y='44' width='8' height='100' rx='4' fill='rgba(255,255,255,.18)'/></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg).replace(/'/g, '%27');
}
const BLANK = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';


Object.assign(ICONS, {
  camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
  sound: '<path d="M11 5 6 9H2v6h4l5 4zM19 5a9 9 0 0 1 0 14M15.5 8.5a5 5 0 0 1 0 7"/>',
  mute: '<path d="M11 5 6 9H2v6h4l5 4zM23 9l-6 6M17 9l6 6"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'
});

/* ---------------- الحالة ---------------- */
const DEFAULT_STATE = { token: '', user: null, admin: false, remember: true, favs: [], cart: [], coupon: null, cur: 'SAR', screen: 'home', prev: 'home', pid: null, cat: 'all', q: '', scroll: 0, sound: true, myRatings: {}, orders: [] };
const DEFAULT_DB = { rev: 0, settings: { store_name: 'الرهيب برفيوم', tagline: 'عطور .. تليق بك', logo: '', whatsapp_url: '', wallets: [], ship_sar: 0, ship_yer: 0 }, categories: [], banners: [], products: [] };
let S = loadJson(STORAGE_KEY, DEFAULT_STATE), DB = loadJson(DB_KEY, DEFAULT_DB);
if (S.remember === false) { S.token = ''; S.user = null; S.admin = false; }
const UI = { mode: 'login', showPw: false, err: '', busy: false, slide: 0, gi: 0, pay: 'wallet', receipt: null, edit: null, rateItems: [], rateVals: {}, atab: 'products', aorders: null, coupons: null, areq: 0, last: '' };
function loadJson(k, def) { try { return Object.assign(structuredClone(def), JSON.parse(localStorage.getItem(k) || 'null') || {}); } catch (e) { return structuredClone(def); } }
function save() { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(S)); } catch (e) { } }
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2600); }
const prod = id => DB.products.find(p => p.id === id);
const isFav = id => S.favs.includes(id);
const cartCount = () => S.cart.reduce((a, i) => a + i.qty, 0);
const catName = id => (DB.categories.find(c => c.id === id) || {}).name || '';
function totals(cur = S.cur) {
  const lines = S.cart.map(i => ({ ...i, p: prod(i.id) })).filter(i => i.p);
  const sub = lines.reduce((a, l) => a + price(l.p, cur) * l.qty, 0);
  const pct = S.coupon ? S.coupon.percent : 0, disc = +(sub * pct / 100).toFixed(2);
  const ship = lines.length ? +DB.settings['ship_' + cur.toLowerCase()] || 0 : 0;
  return { lines, sub, pct, disc, ship, total: sub - disc + ship };
}
function filtered() {
  const q = S.q.trim().toLowerCase();
  return DB.products.filter(p => {
    if (S.cat === 'offers' && !(oldp(p, S.cur) > price(p, S.cur))) return false;
    if (S.cat !== 'all' && S.cat !== 'offers' && p.cat !== +S.cat) return false;
    return !q || p.name.toLowerCase().includes(q);
  });
}
const purchased = id => S.orders.some(o => o.status !== 'cancelled' && o.items.some(i => i.id === id));

/* ---------------- الاتصال بالسيرفر ---------------- */
async function api(method, path, body) {
  const h = { 'Content-Type': 'application/json' }; if (S.token) h.Authorization = 'Bearer ' + S.token;
  let r; try { r = await fetch(API_BASE + path, { method, headers: h, body: body ? JSON.stringify(body) : undefined }); } catch (e) { throw new Error('تعذر الاتصال بالسيرفر'); }
  let j = {}; try { j = await r.json(); } catch (e) { }
  if (r.status === 401 && S.token && path !== '/api/login') { logoutLocal(); throw new Error('انتهت الجلسة، سجّل الدخول من جديد'); }
  if (r.status === 403 && path.startsWith('/api/admin')) { S.admin = false; save(); }
  if (!r.ok || j.ok === false) throw new Error(j.error || 'خطأ غير متوقع');
  return j;
}
function logoutLocal() { S.token = ''; S.user = null; S.admin = false; S.screen = 'home'; S.orders = []; save(); render(); }
async function loadBootstrap() {
  const j = await api('GET', '/api/bootstrap');
  DB = { rev: j.rev, settings: j.settings, categories: j.categories, banners: j.banners, products: j.products };
  try { localStorage.setItem(DB_KEY, JSON.stringify(DB)); } catch (e) { }
}
async function checkRev() { try { const j = await api('GET', '/api/rev'); if (j.rev !== DB.rev) { await loadBootstrap(); if (canRerender()) render(); } } catch (e) { } }
const canRerender = () => !$('#modal').classList.contains('show') && !/INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '');
async function loadUser() {
  const me = await api('GET', '/api/me'); S.user = me.user; S.admin = me.admin;
  try { const st = (await api('GET', '/api/me/state')).state || {}; S.favs = [...new Set([...(st.favs || []), ...S.favs])]; if (!S.cart.length) S.cart = st.cart || []; if (st.cur) S.cur = st.cur; } catch (e) { }
  try { S.myRatings = (await api('GET', '/api/my-ratings')).ratings; } catch (e) { }
  try { S.orders = (await api('GET', '/api/orders')).orders; } catch (e) { }
  save();
}
let pushT; function pushState() { save(); if (!S.token) return; clearTimeout(pushT); pushT = setTimeout(() => api('PUT', '/api/me/state', { state: { favs: S.favs, cart: S.cart, cur: S.cur } }).catch(() => { }), 800); }

/* ---------------- الصور والرفع ---------------- */
function imgTag(ref, cls = '', fb = '') {
  const f = fb ? ` data-fb="${fb}"` : '';
  return ref ? `<img class="${cls}" src="${esc(url(ref))}"${f} loading="lazy">` : `<img class="${cls} ph" src="${fb}">`;
}
document.addEventListener('error', e => { const t = e.target; if (t.tagName === 'IMG' && t.dataset.fb && !t.dataset.done) { t.dataset.done = 1; t.classList.add('ph'); t.src = t.dataset.fb; } }, true);
function compress(file, max = 900, png = false) {
  return new Promise((res, rej) => {
    const im = new Image(), u = URL.createObjectURL(file);
    im.onload = () => { const r = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.max(1, im.width * r); c.height = Math.max(1, im.height * r); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u); c.toBlob(b => b ? res(b) : rej(new Error('تعذر معالجة الصورة')), png ? 'image/png' : 'image/jpeg', .86); };
    im.onerror = () => rej(new Error('الملف ليس صورة صالحة')); im.src = u;
  });
}
const blobB64 = b => new Promise(r => { const f = new FileReader(); f.onload = () => r(f.result.split(',')[1]); f.readAsDataURL(b); });
async function uploadBlob(blob, kind) { return (await api('POST', '/api/upload', { kind, data: await blobB64(blob) })).path; }
function pickImage(kind, max = 900) {
  return new Promise(resolve => {
    const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/jpeg,image/png,image/webp,image/gif'; i.style.display = 'none'; document.body.appendChild(i);
    i.onchange = async () => {
      const f = i.files[0]; i.remove(); if (!f) return resolve(null);
      if (!/^image\/(jpeg|png|webp|gif)$/.test(f.type)) { toast('الملف يجب أن يكون صورة JPG أو PNG أو WEBP'); return resolve(null); }
      if (f.size > 12 * 1048576) { toast('حجم الصورة كبير جداً (الحد 12 ميجابايت)'); return resolve(null); }
      try { toast('جاري رفع الصورة...'); const p = await uploadBlob(await compress(f, max, kind === 'logo'), kind); toast('تم رفع الصورة ✅'); resolve(p); }
      catch (e) { toast(e.message); resolve(null); }
    };
    i.click();
  });
}

/* ---------------- المؤثرات الصوتية والحركية ---------------- */
const SFX = {};
function sfx(n) { if (!S.sound) return; try { let a = SFX[n]; if (!a) { a = SFX[n] = new Audio('assets/sounds/' + n + '.wav'); } const c = a.cloneNode(); c.volume = .5; c.play().catch(() => { }); } catch (e) { } }
function wob(el) { if (!el) return; el.classList.remove('wob'); void el.offsetWidth; el.classList.add('wob'); setTimeout(() => el.classList.remove('wob'), 320); }
function flyToCart(el) {
  try {
    const t = $('[data-act="nav"][data-v="cart"]'); if (!el || !t) return; const a = el.getBoundingClientRect(), b = t.getBoundingClientRect(), d = document.createElement('div');
    d.className = 'fly'; d.style.left = a.left + a.width / 2 + 'px'; d.style.top = a.top + a.height / 2 + 'px'; $('#fx').appendChild(d);
    d.animate([{ transform: 'translate(0,0) scale(1)', opacity: 1 }, { transform: `translate(${b.left - a.left}px,${b.top - a.top}px) scale(.3)`, opacity: .2 }], { duration: 520, easing: 'cubic-bezier(.5,0,.8,.4)' }).onfinish = () => { d.remove(); const bd = $('.badge-n'); if (bd) wob(bd); wob(t); };
  } catch (e) { }
}
function celebrate() {
  sfx('success'); const fx = $('#fx');
  for (let i = 0; i < 26; i++) { const p = document.createElement('i'); p.className = 'spark'; p.style.left = '50%'; p.style.top = '45%'; fx.appendChild(p); const ang = Math.random() * Math.PI * 2, dist = 90 + Math.random() * 150; p.animate([{ transform: 'translate(0,0) scale(1)', opacity: 1 }, { transform: `translate(${Math.cos(ang) * dist}px,${Math.sin(ang) * dist + 60}px) scale(.2)`, opacity: 0 }], { duration: 900 + Math.random() * 500, easing: 'ease-out' }).onfinish = () => p.remove(); }
}

/* ---------------- العرض ---------------- */
const logoSrc = () => DB.settings.logo || DEFAULT_LOGO;
const logoHtml = () => `<div class="logo"><img class="lg" src="${esc(url(logoSrc()))}" data-fb="${DEFAULT_LOGO}"><b>${esc(DB.settings.store_name)}</b><i>${esc(DB.settings.tagline)}</i></div>`;
function render() {
  const root = $('#screen'), app = $('#app');
  document.title = DB.settings.store_name;
  app.classList.toggle('pg-product', !!(S.user && S.screen === 'product'));
  if (!S.user) { root.innerHTML = loginView(); return; }
  const pr = S.screen === 'product';
  root.innerHTML = headerView() + `<main id="view">${viewFor()}</main>` + (pr ? productBar() : navView());
  const v = $('#view');
  if (render.restore !== false) { v.scrollTop = S.scroll || 0; render.restore = false; }
  if (UI.last !== S.screen) { v.classList.add('enter'); UI.last = S.screen; }
  v.addEventListener('scroll', () => { S.scroll = v.scrollTop; clearTimeout(render.t); render.t = setTimeout(save, 250); });
  const q = $('#q'); if (q) q.addEventListener('keydown', e => { if (e.key === 'Enter') go('categories', { q: q.value, cat: 'all' }); });
}
function keepScroll() { const v = $('#view'), t = v ? v.scrollTop : 0; render(); const nv = $('#view'); if (nv) nv.scrollTop = t; }
function go(screen, extra = {}) { Object.assign(S, extra, { screen, scroll: 0 }); render.restore = false; save(); render(); const v = $('#view'); if (v) v.scrollTop = 0; }
function openProduct(id) { if (S.screen !== 'product') S.prev = S.screen; UI.gi = 0; go('product', { pid: id }); }

function headerView() {
  const p = S.screen; let r, l;
  if (p === 'product') {
    const pd = prod(S.pid);
    r = `<button class="round" data-act="back">${ic('back')}</button>`;
    l = `<button class="round" data-act="share">${ic('share')}</button><button class="round ${pd && isFav(pd.id) ? 'favon' : ''}" data-act="fav" data-id="${S.pid}">${ic('heart')}</button>`;
  } else if (p === 'cart') {
    r = `<button class="round" data-act="back">${ic('back')}</button>`;
    l = `<button class="plain" data-act="bell">${ic('bell')}</button><button class="round" data-act="clearcart">${ic('trash')}</button>`;
  } else if (p === 'admin') {
    r = `<button class="round" data-act="nav" data-v="account">${ic('back')}</button>`;
    l = `<button class="plain" data-act="nav" data-v="cart">${ic('cart')}${cartCount() ? `<span class="badge-n">${cartCount()}</span>` : ''}</button>`;
  } else {
    r = `<button class="round" data-act="nav" data-v="account">${ic('menu')}</button>`;
    l = `<button class="plain" data-act="bell">${ic('bell')}</button><button class="plain" data-act="nav" data-v="cart">${ic('cart')}${cartCount() ? `<span class="badge-n">${cartCount()}</span>` : ''}</button>`;
  }
  return `<header class="hdr"><div class="side r">${r}</div>${logoHtml()}<div class="side l">${l}</div></header>`;
}
function viewFor() {
  switch (S.screen) {
    case 'categories': return listView(true); case 'offers': return listView(false);
    case 'favorites': return favView(); case 'cart': return cartView();
    case 'account': return accountView(); case 'product': return productView(); case 'admin': return adminView();
    default: return homeView();
  }
}
function navView() {
  const items = [['categories', 'grid', 'الأقسام'], ['offers', 'tag', 'العروض'], ['home', 'home', 'الرئيسية'], ['favorites', 'heart', 'المفضلة'], ['account', 'user', 'حسابي']];
  return `<nav class="nav">${items.map(([k, i, l]) => `<button class="nv ${S.screen === k ? 'on' : ''}" data-act="nav" data-v="${k}">${ic(i)}<span>${l}</span></button>`).join('')}</nav>`;
}
const curPill = () => `<button class="cur-pill" data-act="cur">${CUR[S.cur].label}</button>`;
const searchBar = () => `<div class="search"><span class="flt" data-act="nav" data-v="categories">${ic('filter')}</span><input id="q" placeholder="ابحث عن عطرك المفضل..." value="${esc(S.q)}">${curPill()}${ic('search')}</div>`;
const pal = p => PALETTE[(p.id || 0) % PALETTE.length];

function productCard(p) {
  const cur = S.cur, pr = price(p, cur), od = oldp(p, cur), [a, b] = pal(p);
  const tag = p.badge || (od > pr ? `خصم ${Math.round((1 - pr / od) * 100)}%` : '');
  return `<div class="pcard" data-act="open" data-id="${p.id}">
    <div class="pimg" style="background:radial-gradient(90% 90% at 50% 40%,${a}55,${b}33 55%,#0a0806)">
      ${imgTag(p.imgs[0], 'b', bottle(pal(p)))}
      <button class="fav ${isFav(p.id) ? 'on' : ''}" data-act="fav" data-id="${p.id}">${ic('heart')}</button>
      ${tag ? `<span class="tag">${esc(tag)}</span>` : ''}</div>
    <div class="pinfo"><div class="pname">${esc(p.name)}</div>
      <div class="rate">${STAR}<span>${avg(p).toFixed(1)} (${p.rcount || 0})</span></div>
      <div class="prow"><button class="cartbtn" data-act="add" data-id="${p.id}">${ic('cart')}</button>
      <div class="price">${pr ? money(pr, cur) : 'غير متوفر'}${od > pr ? `<s>${money(od, cur)}</s>` : ''}</div></div></div></div>`;
}
function slideHtml(b, i) {
  const col = [['#d4af37', '#2a1c06'], ['#3a3a44', '#0c0c10'], ['#c0304a', '#5a0a1e']][i % 3];
  const bg = b.image ? `<div class="bgimg"><img src="${esc(url(b.image))}"></div><div class="shade"></div>` : `<div class="bg"></div><div class="rose"></div><img class="bimg" src="${bottle(col)}">`;
  return `<div class="slide ${i === UI.slide ? 'on' : ''}">${bg}<div class="txt"><h3>${esc(b.h3)}</h3><h2>${esc(b.h2)}</h2><p>${esc(b.p)}</p><button class="btn-gold" data-act="cat" data-v="all">${ic('chev')} تسوق الآن</button></div></div>`;
}
function homeView() {
  const cats = DB.categories.map(c => [String(c.id), c.name, c.image, PALETTE[c.id % PALETTE.length]]).concat([['offers', 'عروض خاصة', '', null]]);
  const catHtml = cats.map(([k, l, img, c]) => `<button class="cat" data-act="cat" data-v="${k}"><span class="ci">${k === 'offers' ? ic('tag') : (img ? `<img src="${esc(url(img))}">` : `<img class="ph" src="${bottle(c)}">`)}</span><span class="cn">${esc(l)}</span></button>`).join('');
  if (UI.slide >= DB.banners.length) UI.slide = 0;
  return `${searchBar()}
  ${DB.banners.length ? `<div class="banner">${DB.banners.map(slideHtml).join('')}</div><div class="dots">${DB.banners.map((_, i) => `<span class="${i === UI.slide ? 'on' : ''}"></span>`).join('')}</div>` : ''}
  <div class="sec">الأقسام الرئيسية</div><div class="cats">${catHtml}</div>
  <div class="sec">منتجات مميزة</div>${DB.products.length ? `<div class="grid">${DB.products.slice(0, 6).map(productCard).join('')}</div>` : `<div class="empty">${ic('flask')}<b>لا توجد منتجات بعد</b></div>`}
  <div class="gift">${ic('gift')}<div><b>هدية فاخرة مع كل طلب</b><span>لأنك تستحق الأفضل</span></div></div>`;
}
function listView(withCats) {
  if (!withCats) S.cat = 'offers';
  const chips = [['all', 'الكل'], ...DB.categories.map(c => [String(c.id), c.name]), ['offers', 'عروض خاصة']].map(([k, l]) => `<button class="chip ${String(S.cat) === k ? 'on' : ''}" data-act="cat" data-v="${k}">${esc(l)}</button>`).join('');
  const list = filtered(), title = S.cat === 'all' ? 'كل العطور' : S.cat === 'offers' ? 'عروض خاصة' : catName(+S.cat);
  return `${searchBar()}<div class="chips">${chips}</div><div class="sec">${esc(title)} (${list.length})</div>
  ${list.length ? `<div class="grid">${list.map(productCard).join('')}</div>` : `<div class="empty">${ic('search')}<b>لا توجد نتائج</b>جرّب كلمة بحث أخرى أو قسماً مختلفاً</div>`}`;
}
function favView() {
  const list = S.favs.map(prod).filter(Boolean);
  return `<div class="sec">المفضلة (${list.length})</div>` + (list.length ? `<div class="grid">${list.map(productCard).join('')}</div>`
    : `<div class="empty">${ic('heart')}<b>قائمة المفضلة فارغة</b>اضغط على القلب في أي عطر لحفظه هنا<br><button class="btn-gold" data-act="cat" data-v="all">تصفح العطور</button></div>`);
}

function productView() {
  const p = prod(S.pid);
  if (!p) return `<div class="empty" style="padding-top:120px">${ic('search')}<b>المنتج غير متوفر</b><button class="btn-gold" data-act="back">رجوع</button></div>`;
  const cur = S.cur, pr = price(p, cur), od = oldp(p, cur), alt = price(p, other(cur)), gal = p.imgs || [];
  const gi = Math.min(UI.gi, Math.max(gal.length - 1, 0)), [a] = pal(p);
  const feats = [['flask', 'رائحة فاخرة'], ['leaf', 'مناسب لجميع الأوقات'], ['clock', 'ثبات يدوم طويلاً'], ['gem', 'جودة عالية']];
  return `<section class="phero" style="--a:${a}">
    <div class="pimgbox">${imgTag(gal[gi], 'pmain', bottle(pal(p)))}</div>
    <div class="pinfo2"><h1>${esc(p.name)}</h1><p>${esc(p.desc || '')}</p>
      <div class="rate big">${STAR}<b>${avg(p).toFixed(1)}</b><span>(${p.rcount || 0})</span></div>
      <div class="pprice">${pr ? money(pr, cur) : 'غير متوفر'} ${curPill()}</div>
      ${od > pr ? `<s class="old">${money(od, cur)}</s><span class="save">وفر ${Math.round((1 - pr / od) * 100)}% ${ic('tag')}</span>` : ''}
      ${alt ? `<small class="alt">${money(alt, other(cur))}</small>` : ''}
      ${purchased(p.id) && !S.myRatings[p.id] ? `<button class="mini" data-act="ratebtn" data-id="${p.id}">${STAR} قيّم المنتج</button>` : ''}
    </div></section>
  ${gal.length > 1 ? `<div class="thumbs">${gal.map((g, i) => `<button class="th ${i === gi ? 'on' : ''}" data-act="thumb" data-v="${i}">${imgTag(g, '', bottle(pal(p)))}</button>`).join('')}</div>` : ''}
  <div class="box det"><h4>${ic('doc')} تفاصيل المنتج</h4><p>${esc(p.details || p.desc || '')}</p>
    <div class="feats">${feats.map(([i, t]) => `<div><span>${ic(i)}</span>${t}</div>`).join('')}</div></div>
  <div class="box specs"><h4>${ic('cog')} مواصفات المنتج</h4>
    <div class="spec"><span>النوع</span>: ${esc(catName(p.cat) || '—')}</div><div class="spec"><span>الحجم</span>: ${esc(p.size)}</div><div class="spec"><span>التركيز</span>: ${esc(p.conc || '')}</div></div>
  ${S.admin ? `<button class="btn-line" data-act="editp" data-id="${p.id}">${ic('edit')} تعديل المنتج (المدير)</button>` : ''}`;
}
const productBar = () => `<div class="bar"><button class="btn-big buyb" data-act="buynow" data-id="${S.pid}">${ic('bolt')} اشتري الآن</button><button class="btn-line addb" data-act="add" data-id="${S.pid}">${ic('cart')} أضف إلى السلة</button></div>`;

function cartView() {
  const t = totals(), cur = S.cur;
  const hero = `<div class="cart-hero">${ic('cart')}<h2>سلة المشتريات</h2><p>مراجعة منتجاتك قبل إتمام الطلب</p>${curPill()}</div>`;
  if (!t.lines.length) return hero + `<div class="empty">${ic('cart')}<b>سلتك فارغة</b>أضف عطورك المفضلة لتبدأ<br><button class="btn-gold" data-act="cat" data-v="all">تسوق الآن</button></div>`;
  const items = t.lines.map(l => {
    const pr = price(l.p, cur), od = oldp(l.p, cur), [a, b] = pal(l.p);
    return `<div class="item"><div class="im" data-act="open" data-id="${l.id}" style="background:radial-gradient(circle,${a}66,${b}44 70%,#0a0806)">${imgTag(l.p.imgs[0], '', bottle(pal(l.p)))}</div>
    <div class="in"><b>${esc(l.p.name)}</b><small>${esc(l.p.size || '')}</small>
    <div class="ir"><div class="qty"><button data-act="qty" data-id="${l.id}" data-d="-1">${ic('minus')}</button><span>${l.qty}</span><button data-act="qty" data-id="${l.id}" data-d="1">${ic('plus')}</button></div>
    <div class="price row">${money(pr, cur)}${od > pr ? `<s>${money(od, cur)}</s>` : ''}</div></div></div>
    <button class="x" data-act="rm" data-id="${l.id}">${ic('xc')}</button></div>`;
  }).join('');
  return `${hero}${items}
  <div class="box coupon">${ic('tag', 'tg')}<div class="cf"><b>هل لديك كوبون خصم؟</b><div class="cin"><input id="cp" placeholder="أدخل الكود" value="${esc(S.coupon ? S.coupon.code : '')}"><button data-act="coupon">تطبيق</button></div></div></div>
  <div class="box sum"><h4>${ic('doc')} ملخص الطلب</h4>
    <div class="sr"><span>المجموع الفرعي</span><em>${money(t.sub, cur)}</em></div>
    <div class="sr g"><span>${ic('tag')} خصم الكوبون${t.pct ? ` (${t.pct}%)` : ''}</span><em>${t.disc ? '-' : ''}${money(t.disc, cur)}</em></div>
    <div class="sr g"><span>${ic('truck')} مصاريف الشحن</span><em>${money(t.ship, cur)}</em></div>
    <div class="sr t"><span>${ic('wallet')} الإجمالي الكلي</span><em>${money(t.total, cur)}</em></div></div>
  <button class="btn-big" data-act="checkout">${ic('lock')} إتمام الشراء الآن</button>`;
}

/* ---------- الحساب ---------- */
function accountView() {
  const u = S.user;
  return `<div class="cover">${u.cover ? `<img src="${esc(url(u.cover))}">` : ''}<button class="camb" data-act="upcover" title="تغيير الغلاف">${ic('camera')}</button></div>
  <div class="avrow"><div class="av big">${u.avatar ? `<img src="${esc(url(u.avatar))}">` : esc((u.username || 'م')[0])}<button class="camb sm" data-act="upavatar">${ic('camera')}</button></div>
    <div class="idbox"><b>${esc(u.username)}</b><button class="uid" data-act="copy" data-v="${esc(u.uid)}">ID: <span>${esc(u.uid)}</span> ${ic('copy')}</button><small>انضممت ${fmtDate(u.created)}</small></div></div>
  <div class="stats"><div><b>${S.favs.length}</b><span>المفضلة</span></div><div><b>${cartCount()}</b><span>في السلة</span></div><div><b>${S.orders.length}</b><span>طلباتي</span></div></div>
  <div class="box"><h4>${ic('user')} معلومات الحساب</h4>
    <label class="fld"><span>اسم المستخدم</span><input class="rtl" id="pn" value="${esc(u.username)}" maxlength="40"></label>
    <label class="fld"><span>رقم الجوال</span><input id="pp" value="${esc(u.phone)}" inputmode="tel" maxlength="20"></label>
    <label class="fld"><span>العنوان</span><input class="rtl" id="pa" value="${esc(u.address)}" maxlength="200"></label>
    <button class="btn-gold" style="width:100%" data-act="saveprofile">${ic('check')} حفظ التعديلات</button>
    <button class="btn-line" data-act="chpw">${ic('lock')} تغيير كلمة المرور</button></div>
  <div class="box row2b"><div><b>العملة</b></div><div class="curbox"><button class="chip ${S.cur === 'SAR' ? 'on' : ''}" data-act="setcur" data-v="SAR">ريال سعودي</button><button class="chip ${S.cur === 'YER' ? 'on' : ''}" data-act="setcur" data-v="YER">ريال يمني</button></div></div>
  <div class="box row2b"><div><b>المؤثرات الصوتية</b></div><button class="chip ${S.sound ? 'on' : ''}" data-act="togglesound">${ic(S.sound ? 'sound' : 'mute')} ${S.sound ? 'مفعّلة' : 'معطّلة'}</button></div>
  <div class="sec">طلباتي</div>
  <div class="box">${S.orders.length ? S.orders.slice(0, 8).map(o => `<div class="ord"><span>#${o.id} · ${fmtDate(o.created)}<br><span class="status ${o.status === 'delivered' ? 'ok' : ''}">${STATUS_AR[o.status] || o.status}</span></span><em>${money(o.total, o.currency)}</em></div>`).join('') : '<div class="note" style="margin:0">لا توجد طلبات بعد</div>'}</div>
  <button class="btn-gold" style="width:100%;margin-bottom:10px" data-act="${S.admin ? 'nav' : 'adminreq'}" data-v="admin">${ic('shield')} ${S.admin ? 'فتح لوحة الإدارة' : 'وضع المدير'}</button>
  ${S.admin ? `<button class="btn-line" data-act="adminoff">إنهاء وضع المدير</button>` : ''}
  <button class="btn-line" data-act="logout">تسجيل الخروج</button>`;
}

/* ---------- تسجيل الدخول ---------- */
function loginView() {
  const reg = UI.mode === 'register';
  return `<div class="login"><div class="top">
    <div class="lang">${ic('globe')} العربية ${ic('caret')}</div>
    <img class="big" src="${bottle(['#d4af37', '#2a1c06'])}"><div class="rose"></div>
    <div class="brand">${logoHtml()}</div>
    <div class="welcome"><h2>${reg ? 'أهلاً بك' : 'مرحباً بك مجدداً'}</h2><p>${reg ? 'أنشئ حسابك للمتابعة' : 'تسجيل الدخول للمتابعة'}</p></div></div>
  <form id="lf" autocomplete="off">
    ${reg ? `<div class="inp">${ic('user')}<input id="ln" placeholder="الاسم الكامل" maxlength="40"></div>` : ''}
    <div class="inp">${ic('mail')}<input id="lu" placeholder="البريد الإلكتروني أو رقم الجوال" autocapitalize="off" maxlength="64"></div>
    <div class="inp">${ic('lock')}<input id="lp" type="${UI.showPw ? 'text' : 'password'}" placeholder="كلمة المرور" maxlength="100"><button type="button" class="eye" data-act="togglepw">${ic(UI.showPw ? 'eye' : 'eyeoff')}</button></div>
    <div class="err">${esc(UI.err)}</div>
    <div class="row2"><button type="button" class="chk" data-act="remember"><i class="${S.remember ? '' : 'off'}">${ic('check')}</i>تذكرني</button><button type="button" class="lnk" data-act="forgot">نسيت كلمة المرور؟</button></div>
    <button class="btn-big" type="submit">${reg ? 'إنشاء الحساب' : 'تسجيل الدخول'} ${ic('send')}</button>
    <div class="switch">${reg ? 'لديك حساب بالفعل؟' : 'ليس لديك حساب؟'}<button type="button" data-act="mode">${reg ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}</button></div>
  </form></div>`;
}
function setErr(m) { UI.err = m; const e = $('.err'); if (e) e.textContent = m; }
async function submitLogin() {
  if (UI.busy) return;
  const login = $('#lu').value.trim(), pw = $('#lp').value, nm = $('#ln') ? $('#ln').value.trim() : '', reg = UI.mode === 'register';
  if (!login || !pw) return setErr('أدخل البريد أو الجوال وكلمة المرور');
  if (reg && nm.length < 2) return setErr('أدخل اسمك الكامل');
  if (reg && pw.length < 6) return setErr('كلمة المرور يجب ألا تقل عن 6 أحرف');
  UI.busy = true; const b = $('#lf .btn-big'); b.disabled = true;
  try {
    const j = await api('POST', reg ? '/api/register' : '/api/login', reg ? { login, password: pw, name: nm } : { login, password: pw });
    S.token = j.token; S.user = j.user; UI.err = ''; S.screen = 'home'; save(); await loadUser(); sfx('success'); render();
  } catch (e) { setErr(e.message); b.disabled = false; }
  finally { UI.busy = false; }
}

/* ---------- النوافذ ---------- */
function sheet(html) { const m = $('#modal'); m.classList.remove('closing'); m.innerHTML = `<div class="sheet">${html}</div>`; m.classList.add('show'); sfx('open'); }
function closeModal() { const m = $('#modal'); if (!m.classList.contains('show')) return; m.classList.add('closing'); setTimeout(() => { m.classList.remove('show', 'closing'); m.innerHTML = ''; }, 180); }
const copyText = async t => { try { await navigator.clipboard.writeText(t); } catch (e) { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); } catch (e2) { } a.remove(); } };

function openCheckout() {
  const t = totals(); if (!t.lines.length) return toast('السلة فارغة');
  UI.receipt = null; const u = S.user;
  sheet(`<h3>إتمام الشراء <button data-act="closemodal">${ic('x')}</button></h3>
    <label class="fld"><span>الاسم</span><input class="rtl" id="on" value="${esc(u.username)}"></label>
    <label class="fld"><span>رقم الجوال</span><input id="op" value="${esc(u.phone)}" inputmode="tel"></label>
    <label class="fld"><span>عنوان التوصيل</span><textarea class="rtl" id="oa">${esc(u.address)}</textarea></label>
    <label class="fld"><span>ملاحظات (اختياري)</span><input class="rtl" id="oo"></label>
    <div class="tot"><span>الإجمالي</span><em>${money(t.total, S.cur)}</em></div>
    <div class="paytabs"><button class="chip ${UI.pay === 'wallet' ? 'on' : ''}" data-act="pay" data-v="wallet">${ic('wallet')} المحافظ الإلكترونية</button><button class="chip ${UI.pay === 'wa' ? 'on' : ''}" data-act="pay" data-v="wa">${ic('phone')} الشراء عبر الواتس</button></div>
    <div id="payBody">${payBody()}</div>
    <button class="btn-big" id="cfo" data-act="confirmorder">${ic('check')} تأكيد وإرسال الطلب</button>`);
}
function payBody() {
  if (UI.pay === 'wa') return `<div class="note" style="margin:0 0 12px">سيتم تسجيل طلبك وإرساله لنا، ثم يفتح الواتس مباشرة لإكمال الشراء. تفاصيل الطلب تُنسخ تلقائياً لتلصقها في المحادثة.</div>`;
  const w = DB.settings.wallets || [];
  return `<div class="walletbox"><b>حوّل المبلغ إلى إحدى المحافظ التالية ثم أرفق صورة التحويل:</b>
    ${w.map(x => `<div class="wl"><div><small>${esc(x.name)}</small><strong>${esc(x.number)}</strong></div><button data-act="copy" data-v="${esc(x.number)}">${ic('copy')} نسخ</button></div>`).join('') || '<div class="note">لم تُضبط محفظة بعد، استخدم الشراء عبر الواتس.</div>'}
    <label class="upl" for="rc">${ic('image')} <span id="rcn">${UI.receipt ? esc(UI.receipt.name) : 'إرفاق صورة التحويل (مطلوب)'}</span></label>
    <input type="file" id="rc" accept="image/jpeg,image/png,image/webp" hidden></div>`;
}
async function confirmOrder() {
  const name = $('#on').value.trim(), phone = $('#op').value.trim(), address = $('#oa').value.trim(), note = $('#oo').value.trim();
  if (!name || !phone || !address) return toast('أكمل الاسم والجوال والعنوان');
  if (UI.pay === 'wallet' && !UI.receipt) return toast('أرفق صورة التحويل أولاً');
  const t = totals(); if (!t.lines.length) return;
  const btn = $('#cfo'); btn.disabled = true; btn.textContent = 'جاري الإرسال...';
  try {
    let receipt = ''; if (UI.pay === 'wallet') receipt = await uploadBlob(await compress(UI.receipt, 1400), 'receipt');
    const j = await api('POST', '/api/orders', { items: t.lines.map(l => ({ id: l.id, qty: l.qty })), currency: S.cur, coupon: S.coupon ? S.coupon.code : '', name, phone, address, note, method: UI.pay === 'wa' ? 'whatsapp' : 'wallet', receipt });
    const o = j.order; S.orders.unshift(o); const ids = o.items.map(i => i.id);
    S.cart = []; S.coupon = null; S.user.phone = phone; S.user.address = address; S.screen = 'account'; S.scroll = 0; pushState(); render(); celebrate();
    if (o.method === 'whatsapp') {
      const txt = `طلب جديد #${o.id}\nID: ${o.uid}\nالاسم: ${o.username}\nالجوال: ${o.phone}\nالعنوان: ${o.address}\n` + o.items.map((i, n) => `${n + 1}. ${i.name} × ${i.qty} — ${money(i.line, o.currency)}`).join('\n') + `\nالإجمالي: ${money(o.total, o.currency)}`;
      await copyText(txt); const wa = DB.settings.whatsapp_url; try { if (wa) window.open(wa, '_blank'); } catch (e) { }
      sheet(`<h3>تم تسجيل الطلب #${o.id} <button data-act="closemodal">${ic('x')}</button></h3><div class="note" style="margin:0 0 14px">نسخنا تفاصيل طلبك. إذا لم يفتح الواتس تلقائياً اضغط الزر ثم الصق التفاصيل في المحادثة.</div>${wa ? `<a class="btn-big" style="text-decoration:none" href="${esc(wa)}" target="_blank" rel="noopener">${ic('phone')} فتح الواتس</a>` : ''}<button class="btn-line" data-act="rateafter" data-v="${ids.join(',')}">تقييم المنتجات</button>`);
    } else rateSheet(ids, true);
  } catch (e) { toast(e.message); btn.disabled = false; btn.innerHTML = ic('check') + ' تأكيد وإرسال الطلب'; }
}

/* ---------- التقييم ---------- */
function rateSheet(ids, after) {
  ids = [...new Set(ids)].filter(id => prod(id) && !S.myRatings[id]); if (!ids.length) return closeModal();
  UI.rateItems = ids; UI.rateVals = {}; drawRate(after);
}
function drawRate(after) {
  sheet(`<h3>${after ? 'شكراً لطلبك! قيّم منتجاتك' : 'قيّم المنتج'} <button data-act="closemodal">${ic('x')}</button></h3>
  ${UI.rateItems.map(id => `<div class="rrow"><b>${esc(prod(id).name)}</b><div class="stars">${[1, 2, 3, 4, 5].map(n => `<button class="${(UI.rateVals[id] || 0) >= n ? 'on' : ''}" data-act="star" data-id="${id}" data-v="${n}">${STAR}</button>`).join('')}</div></div>`).join('')}
  <button class="btn-big" data-act="sendrate">إرسال التقييم</button><button class="btn-line" data-act="closemodal">تخطي</button>`);
}
async function sendRate() {
  const vals = Object.entries(UI.rateVals); if (!vals.length) return closeModal();
  for (const [id, v] of vals) { try { await api('POST', '/api/ratings', { product_id: +id, value: +v }); S.myRatings[id] = +v; } catch (e) { toast(e.message); } }
  save(); closeModal(); toast('شكراً لتقييمك ⭐'); try { await loadBootstrap(); } catch (e) { } render();
}

/* ---------- وضع المدير: موافقة تلجرام ---------- */
async function requestAdmin() {
  try {
    const j = await api('POST', '/api/admin/request');
    if (j.status === 'approved') { S.admin = true; save(); return go('admin'); }
    UI.areq = j.id;
    sheet(`<h3>وضع المدير <button data-act="cancelreq">${ic('x')}</button></h3><div class="waiting"><div class="spinner"></div><b>بانتظار موافقة المدير</b><p>تم إرسال طلب الدخول إلى بوت تلجرام. يجب الضغط على «موافقة» هناك ليتم تفعيل لوحة الإدارة.</p></div><button class="btn-line" data-act="cancelreq">إلغاء الطلب</button>`);
    pollAdmin(j.id);
  } catch (e) { toast(e.message); }
}
async function pollAdmin(id) {
  const t0 = Date.now();
  while (UI.areq === id && Date.now() - t0 < 310000) {
    await sleep(2000); if (UI.areq !== id) return;
    try {
      const j = await api('GET', '/api/admin/request/' + id);
      if (j.status === 'approved') { UI.areq = 0; S.admin = true; save(); closeModal(); toast('تمت الموافقة ✅'); sfx('success'); return go('admin'); }
      if (j.status === 'rejected') { UI.areq = 0; closeModal(); return toast('تم رفض طلب الدخول ❌'); }
      if (j.status === 'expired') { UI.areq = 0; closeModal(); return toast('انتهت مهلة الطلب، حاول مجدداً'); }
    } catch (e) { }
  }
}

/* ---------- لوحة الإدارة ---------- */
const TABS = [['products', 'المنتجات'], ['cats', 'الأقسام'], ['banners', 'البنرات'], ['orders', 'الطلبات'], ['settings', 'الإعدادات']];
function adminView() {
  if (!S.admin) return `<div class="empty">${ic('shield')}<b>وضع المدير غير مفعّل</b>يتطلب موافقة من بوت تلجرام<br><button class="btn-gold" data-act="adminreq">طلب الدخول</button></div>`;
  const tabs = `<div class="chips">${TABS.map(([k, l]) => `<button class="chip ${UI.atab === k ? 'on' : ''}" data-act="atab" data-v="${k}">${l}</button>`).join('')}</div>`;
  const row = (img, title, sub, actions) => `<div class="arow"><div class="at">${img}</div><div class="ai"><b>${esc(title)}</b><small>${esc(sub)}</small></div><div class="aa">${actions}</div></div>`;
  let body = '';
  if (UI.atab === 'products') {
    body = `<button class="btn-gold" style="width:100%;margin-bottom:10px" data-act="newp">${ic('plus')} إضافة منتج</button>` + DB.products.map(p => row(imgTag(p.imgs[0], '', bottle(pal(p))), p.name, `${money(p.sar, 'SAR')} · ${money(p.yer, 'YER')}`, `<button data-act="editp" data-id="${p.id}">${ic('edit')}</button>`)).join('');
  } else if (UI.atab === 'cats') {
    body = `<button class="btn-gold" style="width:100%;margin-bottom:10px" data-act="newc">${ic('plus')} إضافة قسم</button>` + DB.categories.map(c => row(c.image ? `<img src="${esc(url(c.image))}">` : `<img class="ph" src="${bottle(PALETTE[c.id % 6])}">`, c.name, DB.products.filter(p => p.cat === c.id).length + ' منتج', `<button data-act="editc" data-id="${c.id}">${ic('edit')}</button>`)).join('');
  } else if (UI.atab === 'banners') {
    body = `<button class="btn-gold" style="width:100%;margin-bottom:10px" data-act="newb">${ic('plus')} إضافة بنر</button>` + DB.banners.map(b => row(b.image ? `<img src="${esc(url(b.image))}">` : `<img class="ph" src="${bottle(['#d4af37', '#2a1c06'])}">`, b.h2 || 'بنر', b.h3 + ' · ' + b.p, `<button data-act="editb" data-id="${b.id}">${ic('edit')}</button>`)).join('');
  } else if (UI.atab === 'orders') {
    if (!UI.aorders) { loadAdminOrders(); body = '<div class="empty"><div class="spinner"></div></div>'; }
    else body = UI.aorders.map(o => `<div class="box ao"><div class="ord" style="border:none;padding:0"><span><b>#${o.id}</b> · ${esc(o.username)}<br><small>ID: ${esc(o.uid)} · ${esc(o.phone)}</small></span><em>${money(o.total, o.currency)}</em></div>
      <small class="mut">${o.items.map(i => esc(i.name) + '×' + i.qty).join('، ')} · ${o.method === 'wallet' ? 'محفظة' : 'واتس'} · ${fmtDate(o.created)}</small>
      <div class="chips" style="margin:8px 0 0">${Object.entries(STATUS_AR).map(([k, l]) => `<button class="chip sm ${o.status === k ? 'on' : ''}" data-act="ostatus" data-id="${o.id}" data-v="${k}">${l}</button>`).join('')}${o.has_receipt ? `<button class="chip sm" data-act="receipt" data-id="${o.id}">${ic('image')} السند</button>` : ''}</div></div>`).join('') || '<div class="empty"><b>لا توجد طلبات</b></div>';
  } else {
    const s = DB.settings;
    if (!UI.coupons) loadCoupons();
    body = `<div class="box"><h4>${ic('cog')} إعدادات المتجر</h4>
      <div class="logoedit"><img src="${esc(url(logoSrc()))}"><div><button class="btn-line" style="margin:0" data-act="uplogo">${ic('image')} تغيير الشعار</button>${s.logo ? `<button class="btn-line danger" data-act="rmlogo">استعادة الشعار الافتراضي</button>` : ''}</div></div>
      <label class="fld"><span>اسم المتجر</span><input class="rtl" id="sn" value="${esc(s.store_name)}" maxlength="40"></label>
      <label class="fld"><span>الشعار النصي</span><input class="rtl" id="st" value="${esc(s.tagline)}" maxlength="60"></label>
      <label class="fld"><span>رابط الواتس</span><input id="sw" value="${esc(s.whatsapp_url)}"></label>
      <label class="fld"><span>المحافظ (سطر لكل محفظة: الاسم | الرقم)</span><textarea class="rtl" id="sl" style="height:90px;direction:ltr;text-align:left">${esc((s.wallets || []).map(w => w.name + ' | ' + w.number).join('\n'))}</textarea></label>
      <div class="two"><label class="fld"><span>الشحن (ر.س)</span><input id="ss" value="${s.ship_sar}" inputmode="decimal"></label><label class="fld"><span>الشحن (ر.ي)</span><input id="sy" value="${s.ship_yer}" inputmode="decimal"></label></div>
      <button class="btn-big" data-act="savesettings">حفظ الإعدادات</button></div>
      <div class="box"><h4>${ic('tag')} كوبونات الخصم</h4>${(UI.coupons || []).map(c => `<div class="ord"><span>${esc(c.code)}</span><span><em>${c.percent}%</em> <button data-act="delcoupon" data-v="${esc(c.code)}" style="color:#ff7d8f">${ic('trash')}</button></span></div>`).join('')}
      <div class="two" style="margin-top:8px"><label class="fld"><span>الكود</span><input id="cc" maxlength="30"></label><label class="fld"><span>النسبة %</span><input id="cpct" inputmode="decimal"></label></div>
      <button class="btn-line" data-act="addcoupon">إضافة كوبون</button></div>`;
  }
  return `<div class="sec">لوحة الإدارة</div>${tabs}${body}`;
}
async function loadAdminOrders() { try { UI.aorders = (await api('GET', '/api/admin/orders')).orders; } catch (e) { UI.aorders = []; toast(e.message); } if (S.screen === 'admin') keepScroll(); }
async function loadCoupons() { try { UI.coupons = (await api('GET', '/api/admin/coupons')).coupons; } catch (e) { UI.coupons = []; } if (S.screen === 'admin') keepScroll(); }
async function refreshAll() { await loadBootstrap(); render(); }
async function adminCall(fn, okMsg) { try { await fn(); await loadBootstrap(); closeModal(); if (S.screen === 'admin') keepScroll(); else render(); toast(okMsg || 'تم الحفظ ✅'); return true; } catch (e) { toast(e.message); if (!S.admin) render(); return false; } }

/* تعديل المنتج */
function editSheet(pid) {
  const p = pid ? prod(pid) : { name: '', desc: '', details: '', sar: '', osar: '', yer: '', oyer: '', cat: null, size: '100 مل', conc: 'Eau de Parfum', badge: '', imgs: [] };
  UI.edit = { kind: 'p', id: pid || null, imgs: [...p.imgs] };
  const f = (id, label, val, extra = '') => `<label class="fld"><span>${label}</span><input id="${id}" value="${esc(val)}" ${extra}></label>`;
  sheet(`<h3>${pid ? 'تعديل المنتج' : 'منتج جديد'} <button data-act="closemodal">${ic('x')}</button></h3>
    ${f('en', 'اسم المنتج', p.name, 'class="rtl" maxlength="80"')}${f('ed', 'وصف قصير', p.desc, 'class="rtl" maxlength="200"')}
    <label class="fld"><span>تفاصيل المنتج</span><textarea class="rtl" id="ex" maxlength="2000">${esc(p.details)}</textarea></label>
    <div class="two">${f('es', 'السعر (ر.س)', p.sar, 'inputmode="decimal"')}${f('eos', 'قبل الخصم (ر.س)', p.osar || '', 'inputmode="decimal"')}</div>
    <div class="two">${f('ey', 'السعر (ر.ي)', p.yer, 'inputmode="decimal"')}${f('eoy', 'قبل الخصم (ر.ي)', p.oyer || '', 'inputmode="decimal"')}</div>
    <label class="fld"><span>القسم</span><select id="ec"><option value="">بدون قسم</option>${DB.categories.map(c => `<option value="${c.id}" ${p.cat === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></label>
    <div class="two">${f('ez', 'الحجم', p.size, 'class="rtl" maxlength="30"')}${f('ek', 'التركيز', p.conc, 'maxlength="40"')}</div>
    ${f('eb', 'شارة (اختياري)', p.badge, 'class="rtl" maxlength="30"')}
    <div class="fld"><span>الصور (الأولى هي الرئيسية)</span><div class="eimgs" id="eimgs">${editImgs()}</div><button class="upl" data-act="eadd">${ic('image')} <span>إضافة صورة من الجهاز</span></button></div>
    <button class="btn-big" data-act="savep">حفظ</button>${pid ? `<button class="btn-line danger" data-act="delp">حذف المنتج</button>` : ''}`);
}
const editImgs = () => UI.edit.imgs.map((r, i) => `<div class="ei"><img src="${esc(url(r))}"><button data-act="eimg-rm" data-v="${i}">${ic('x')}</button>${i ? `<button class="mk" data-act="eimg-main" data-v="${i}">★</button>` : ''}</div>`).join('') || '<small style="color:var(--mut)">لا توجد صور</small>';
function simpleSheet(kind, id, title, fields, img, imgLabel) {
  UI.edit = { kind, id, img: img || '' };
  sheet(`<h3>${title} <button data-act="closemodal">${ic('x')}</button></h3>${fields}
    <div class="fld"><span>${imgLabel}</span><div class="imgprev" id="imgprev">${UI.edit.img ? `<img src="${esc(url(UI.edit.img))}">` : '<small>لا توجد صورة</small>'}</div><button class="upl" data-act="esimg">${ic('image')} <span>اختيار صورة من الجهاز</span></button></div>
    <button class="btn-big" data-act="saveedit">حفظ</button>${id ? `<button class="btn-line danger" data-act="deledit">حذف</button>` : ''}`);
}
const tf = (id, label, val, max) => `<label class="fld"><span>${label}</span><input class="rtl" id="${id}" value="${esc(val)}" maxlength="${max}"></label>`;
function catSheet(id) { const c = id ? DB.categories.find(x => x.id === id) : { name: '', image: '' }; simpleSheet('c', id, id ? 'تعديل القسم' : 'قسم جديد', tf('xn', 'اسم القسم', c.name, 40), c.image, 'صورة القسم'); }
function bannerSheet(id) { const b = id ? DB.banners.find(x => x.id === id) : { h3: '', h2: '', p: '', image: '' }; simpleSheet('b', id, id ? 'تعديل البنر' : 'بنر جديد', tf('x3', 'السطر الأول', b.h3, 40) + tf('x2', 'العنوان الذهبي', b.h2, 40) + tf('xp', 'الوصف', b.p, 80), b.image, 'صورة البنر (تظهر بحجم ثابت)'); }
async function saveProduct() {
  const e = UI.edit, g = id => $('#' + id).value.trim(), name = g('en'); if (!name) return toast('أدخل اسم المنتج');
  const data = { name, desc: g('ed'), details: g('ex'), sar: g('es'), osar: g('eos'), yer: g('ey'), oyer: g('eoy'), cat: $('#ec').value || null, size: g('ez'), conc: g('ek'), badge: g('eb'), imgs: e.imgs };
  await adminCall(() => e.id ? api('PUT', '/api/admin/products/' + e.id, data) : api('POST', '/api/admin/products', data));
}
async function saveSimple() {
  const e = UI.edit, g = id => ($('#' + id) || {}).value || '';
  if (e.kind === 'c') { const d = { name: g('xn').trim(), image: e.img }; await adminCall(() => e.id ? api('PUT', '/api/admin/categories/' + e.id, d) : api('POST', '/api/admin/categories', d)); }
  else { const d = { h3: g('x3').trim(), h2: g('x2').trim(), p: g('xp').trim(), image: e.img }; await adminCall(() => e.id ? api('PUT', '/api/admin/banners/' + e.id, d) : api('POST', '/api/admin/banners', d)); }
}
async function saveSettings() {
  const wallets = $('#sl').value.split('\n').map(l => l.split('|').map(x => x.trim())).filter(a => a[0] && a[1]).map(a => ({ name: a[0], number: a[1] }));
  await adminCall(() => api('PUT', '/api/admin/settings', { store_name: $('#sn').value.trim(), tagline: $('#st').value.trim(), whatsapp_url: $('#sw').value.trim(), wallets, ship_sar: $('#ss').value || 0, ship_yer: $('#sy').value || 0 }));
}
function pwSheet() {
  sheet(`<h3>تغيير كلمة المرور <button data-act="closemodal">${ic('x')}</button></h3>
    <label class="fld"><span>كلمة المرور الحالية</span><input type="password" id="po"></label><label class="fld"><span>كلمة المرور الجديدة (6 أحرف على الأقل)</span><input type="password" id="pnw"></label>
    <button class="btn-big" data-act="savepw">حفظ</button>`);
}

/* ---------------- الأحداث ---------------- */
document.addEventListener('pointerdown', e => { const b = e.target.closest('button,[data-act="open"]'); if (b) wob(b); });
document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const a = el.dataset.act, id = +el.dataset.id, v = el.dataset.v;
  if (!['add', 'confirmorder', 'sendrate'].includes(a)) sfx('click');
  switch (a) {
    case 'open': openProduct(id); break;
    case 'back': go(S.screen === 'product' ? (S.prev || 'home') : 'home'); break;
    case 'nav': if (v === 'categories') go('categories', { cat: 'all', q: '' }); else if (v === 'offers') go('offers', { cat: 'offers' }); else go(v); break;
    case 'cat': go(v === 'offers' ? 'offers' : 'categories', { cat: v, q: ['categories', 'offers'].includes(S.screen) ? S.q : '' }); break;
    case 'cur': S.cur = other(S.cur); pushState(); keepScroll(); break;
    case 'setcur': S.cur = v; pushState(); keepScroll(); break;
    case 'thumb': UI.gi = +v; keepScroll(); break;
    case 'fav': S.favs = isFav(id) ? S.favs.filter(x => x !== id) : [...S.favs, id]; pushState(); keepScroll(); toast(isFav(id) ? 'أضيف إلى المفضلة' : 'أزيل من المفضلة'); break;
    case 'share': { const p = prod(S.pid); try { if (navigator.share) await navigator.share({ title: p.name, text: p.name, url: location.href }); else { await copyText(p.name + ' - ' + location.href); toast('تم نسخ الرابط'); } } catch (er) { } break; }
    case 'add': { sfx('add'); flyToCart(el); const it = S.cart.find(x => x.id === id); it ? it.qty = Math.min(20, it.qty + 1) : S.cart.push({ id, qty: 1 }); pushState(); setTimeout(keepScroll, 540); toast('أضيف إلى السلة'); break; }
    case 'buynow': { if (!S.cart.find(x => x.id === id)) S.cart.push({ id, qty: 1 }); pushState(); render(); openCheckout(); break; }
    case 'qty': { const it = S.cart.find(x => x.id === id); if (it) { it.qty = Math.min(20, it.qty + +el.dataset.d); if (it.qty < 1) S.cart = S.cart.filter(x => x.id !== id); } pushState(); keepScroll(); break; }
    case 'rm': S.cart = S.cart.filter(x => x.id !== id); pushState(); keepScroll(); break;
    case 'clearcart': if (S.cart.length && confirm('تفريغ السلة بالكامل؟')) { S.cart = []; S.coupon = null; pushState(); render(); } break;
    case 'coupon': { const c = ($('#cp').value || '').trim(); if (!c) { S.coupon = null; save(); return keepScroll(); } try { const j = await api('POST', '/api/coupon', { code: c }); S.coupon = { code: j.code, percent: j.percent }; save(); keepScroll(); toast('تم تطبيق الكوبون ' + j.code); } catch (er) { toast(er.message); } break; }
    case 'checkout': openCheckout(); break;
    case 'pay': UI.pay = v; document.querySelectorAll('.paytabs .chip').forEach(b => b.classList.toggle('on', b.dataset.v === v)); $('#payBody').innerHTML = payBody(); break;
    case 'copy': await copyText(v); toast('تم النسخ'); break;
    case 'confirmorder': confirmOrder(); break;
    case 'closemodal': closeModal(); break;
    case 'rateafter': rateSheet(v.split(',').map(Number), true); break;
    case 'ratebtn': rateSheet([id]); break;
    case 'star': UI.rateVals[id] = +v; sfx('click'); drawRate(); break;
    case 'sendrate': sendRate(); break;
    case 'bell': toast('لا توجد إشعارات جديدة'); break;
    case 'togglepw': { const x = { u: $('#lu').value, p: $('#lp').value, n: $('#ln') ? $('#ln').value : '' }; UI.showPw = !UI.showPw; render(); $('#lu').value = x.u; $('#lp').value = x.p; if ($('#ln')) $('#ln').value = x.n; break; }
    case 'remember': { S.remember = !S.remember; save(); const x = { u: $('#lu').value, p: $('#lp').value }; render(); $('#lu').value = x.u; $('#lp').value = x.p; break; }
    case 'mode': UI.mode = UI.mode === 'login' ? 'register' : 'login'; UI.err = ''; render(); break;
    case 'forgot': toast('تواصل مع إدارة المتجر لإعادة تعيين كلمة المرور'); break;
    case 'logout': try { await api('POST', '/api/logout'); } catch (er) { } logoutLocal(); break;
    case 'togglesound': S.sound = !S.sound; save(); keepScroll(); if (S.sound) sfx('click'); break;
    case 'upavatar': case 'upcover': { const p = await pickImage(a === 'upavatar' ? 'avatar' : 'cover', a === 'upavatar' ? 500 : 1200); if (p) { try { const j = await api('PUT', '/api/me', { [a === 'upavatar' ? 'avatar' : 'cover']: p }); S.user = j.user; save(); keepScroll(); } catch (er) { toast(er.message); } } break; }
    case 'saveprofile': try { const j = await api('PUT', '/api/me', { username: $('#pn').value, phone: $('#pp').value, address: $('#pa').value }); S.user = j.user; save(); keepScroll(); toast('تم حفظ معلومات الحساب ✅'); } catch (er) { toast(er.message); } break;
    case 'chpw': pwSheet(); break;
    case 'savepw': try { await api('PUT', '/api/me/password', { old: $('#po').value, new: $('#pnw').value }); closeModal(); toast('تم تغيير كلمة المرور ✅'); } catch (er) { toast(er.message); } break;
    case 'adminreq': requestAdmin(); break;
    case 'cancelreq': UI.areq = 0; closeModal(); break;
    case 'adminoff': try { await api('POST', '/api/admin/logout'); } catch (er) { } S.admin = false; save(); go('account'); break;
    case 'atab': UI.atab = v; if (v === 'orders') UI.aorders = null; if (v === 'settings') UI.coupons = null; keepScroll(); break;
    case 'newp': editSheet(null); break;
    case 'editp': editSheet(id); break;
    case 'savep': saveProduct(); break;
    case 'delp': if (confirm('حذف هذا المنتج نهائياً؟')) { const pid = UI.edit.id; S.cart = S.cart.filter(x => x.id !== pid); S.favs = S.favs.filter(x => x !== pid); if (await adminCall(() => api('DELETE', '/api/admin/products/' + pid), 'تم الحذف')) { if (S.screen === 'product') go(S.prev || 'home'); } } break;
    case 'eadd': { const p = await pickImage('product', 1000); if (p) { UI.edit.imgs.push(p); $('#eimgs').innerHTML = editImgs(); } break; }
    case 'eimg-rm': UI.edit.imgs.splice(+v, 1); $('#eimgs').innerHTML = editImgs(); break;
    case 'eimg-main': { const [x] = UI.edit.imgs.splice(+v, 1); UI.edit.imgs.unshift(x); $('#eimgs').innerHTML = editImgs(); break; }
    case 'newc': catSheet(null); break; case 'editc': catSheet(id); break;
    case 'newb': bannerSheet(null); break; case 'editb': bannerSheet(id); break;
    case 'esimg': { const p = await pickImage(UI.edit.kind === 'c' ? 'category' : 'banner', UI.edit.kind === 'c' ? 400 : 1400); if (p) { UI.edit.img = p; $('#imgprev').innerHTML = `<img src="${esc(url(p))}">`; } break; }
    case 'saveedit': saveSimple(); break;
    case 'deledit': if (confirm('تأكيد الحذف؟')) { const e2 = UI.edit; await adminCall(() => api('DELETE', (e2.kind === 'c' ? '/api/admin/categories/' : '/api/admin/banners/') + e2.id), 'تم الحذف'); } break;
    case 'uplogo': { const p = await pickImage('logo', 512); if (p) await adminCall(() => api('PUT', '/api/admin/settings', { logo: p }), 'تم تغيير الشعار ✅'); break; }
    case 'rmlogo': await adminCall(() => api('PUT', '/api/admin/settings', { logo: '' }), 'تمت استعادة الشعار'); break;
    case 'savesettings': saveSettings(); break;
    case 'addcoupon': try { await api('POST', '/api/admin/coupons', { code: $('#cc').value, percent: $('#cpct').value }); UI.coupons = null; toast('تمت إضافة الكوبون'); keepScroll(); } catch (er) { toast(er.message); } break;
    case 'delcoupon': try { await api('DELETE', '/api/admin/coupons/' + v); UI.coupons = null; keepScroll(); } catch (er) { toast(er.message); } break;
    case 'ostatus': try { await api('PUT', '/api/admin/orders/' + id, { status: v }); UI.aorders = null; toast('تم تحديث حالة الطلب'); keepScroll(); } catch (er) { toast(er.message); } break;
    case 'receipt': try { const r = await fetch(API_BASE + '/api/admin/receipt/' + id, { headers: { Authorization: 'Bearer ' + S.token } }); if (!r.ok) throw 0; window.open(URL.createObjectURL(await r.blob()), '_blank'); } catch (er) { toast('تعذر فتح السند'); } break;
  }
});
document.addEventListener('submit', e => { e.preventDefault(); if (e.target.id === 'lf') submitLogin(); });
document.addEventListener('change', e => { const t = e.target; if (t.id === 'rc' && t.files[0]) { const f = t.files[0]; if (!/^image\/(jpeg|png|webp)$/.test(f.type)) { toast('أرفق صورة JPG أو PNG'); t.value = ''; return; } UI.receipt = f; $('#rcn').textContent = '✓ ' + f.name; } });

/* مؤقت البنر */
setInterval(() => {
  if (!S.user || S.screen !== 'home') return;
  const sl = document.querySelectorAll('.slide'), ds = document.querySelectorAll('.dots span'); if (sl.length < 2) return;
  UI.slide = (UI.slide + 1) % sl.length;
  sl.forEach((s, i) => s.classList.toggle('on', i === UI.slide)); ds.forEach((d, i) => d.classList.toggle('on', i === UI.slide));
}, 4000);
function vh() { document.documentElement.style.setProperty('--vh', innerHeight * 0.01 + 'px'); }
addEventListener('resize', vh); vh();

/* ---------------- بدء التشغيل ---------------- */
(async function boot() {
  render();                                   // عرض فوري من النسخة المخزنة
  try { await loadBootstrap(); } catch (e) { toast('وضع عدم الاتصال: عرض آخر نسخة محفوظة'); }
  if (S.token) { try { await loadUser(); } catch (e) { } }
  render();
  setInterval(() => { if (!document.hidden) checkRev(); }, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) checkRev(); });
})();
