# MM POSAN CALCULATOR (Secondary, Class IX-X) - Android project

This project wraps your existing web app (HTML/CSS/JavaScript, unchanged design,
calculations and features) in a native Android app using a local WebView.

* Web app: `app/src/main/assets/index.html`  (edit this file to change the app)
* Kotlin:  `app/src/main/java/com/mmposan/calculator/MainActivity.kt` and `Exporter.kt`
* Works fully offline - no INTERNET permission is requested.
* Data is stored on the phone (WebView storage plus a backup file in the app's private folder).
* PDF and Excel exports are created natively and saved in the phone's Downloads folder.
* Print uses Android's print dialog (choose "Save as PDF" to make a PDF).

## Build the APK (Android Studio)
1. Install Android Studio (Koala or newer; it includes JDK 17).
2. File > Open > select the `MMPosanCalculator` folder. Let Gradle sync finish (needs internet once).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. When the notification appears, click "locate". The file is
   `app/build/outputs/apk/debug/app-debug.apk`.

Command line (JDK 17 + Android SDK installed): `gradle assembleDebug`
(or `./gradlew assembleDebug` after creating the wrapper with `gradle wrapper --gradle-version 8.7`).

## Install on your phone
1. Copy `app-debug.apk` to the phone (USB, Drive, WhatsApp to yourself).
2. Open it from the Files app. If asked, allow "Install unknown apps" for that app.
3. Tap Install, then open "MM POSAN CALCULATOR".

Or connect the phone with USB debugging on and press Run in Android Studio.

## Notes
* minSdk 26 (Android 8.0), targetSdk 34.
* Records saved in the browser version of the app do not carry over; the APK starts with its own storage.
* Uninstalling the app erases its data.
