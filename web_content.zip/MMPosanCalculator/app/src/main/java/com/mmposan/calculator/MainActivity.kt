package com.mmposan.calculator

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import java.io.File

/**
 * Hosts the existing MM POSAN CALCULATOR web app (assets/index.html) inside a local WebView.
 * Everything is loaded from the APK, so the app works fully offline.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private val homeUrl = "https://appassets.androidplatform.net/assets/index.html"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        // Serves files from /assets over a stable https origin, so localStorage is kept between launches.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                if (request.url.host == "appassets.androidplatform.net") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (e: ActivityNotFoundException) {
                    // ignore
                }
                return true
            }
        }

        // The app uses alert() and confirm(); WebView needs these hooks to show them.
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?, url: String?, message: String?, result: JsResult?
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .show()
                return true
            }

            override fun onJsConfirm(
                view: WebView?, url: String?, message: String?, result: JsResult?
            ): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setCancelable(false)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                    .show()
                return true
            }
        }

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
        }
        // Keep the app's own light/dark design instead of the system forcing a dark filter.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, false)
        }

        web.addJavascriptInterface(Bridge(), "Android")

        if (savedInstanceState == null) web.loadUrl(homeUrl) else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }

    /** Functions the web app can call through `window.Android`. */
    inner class Bridge {

        /** Backup copy of all app data, so records survive even if WebView storage is cleared. */
        @JavascriptInterface
        fun saveData(json: String) {
            try {
                File(filesDir, "data.json").writeText(json)
            } catch (e: Exception) {
                // ignore
            }
        }

        @JavascriptInterface
        fun loadData(): String = try {
            val f = File(filesDir, "data.json")
            if (f.exists()) f.readText() else ""
        } catch (e: Exception) {
            ""
        }

        @JavascriptInterface
        fun printPage() {
            runOnUiThread {
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                val name = "MM POSAN CALCULATOR"
                pm.print(name, web.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
            }
        }

        @JavascriptInterface
        fun exportXlsx(json: String, fileName: String) {
            Thread {
                try {
                    val bytes = Exporter.xlsx(JSONObject(json))
                    saveAndNotify(
                        "$fileName.xlsx",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        bytes
                    )
                } catch (e: Exception) {
                    toast("Could not create the Excel file")
                }
            }.start()
        }

        @JavascriptInterface
        fun exportPdf(json: String, fileName: String) {
            Thread {
                try {
                    val bytes = Exporter.pdf(JSONObject(json))
                    saveAndNotify("$fileName.pdf", "application/pdf", bytes)
                } catch (e: Exception) {
                    toast("Could not create the PDF")
                }
            }.start()
        }
    }

    private fun toast(msg: String) {
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    private fun saveAndNotify(name: String, mime: String, bytes: ByteArray) {
        try {
            val where: String
            var savedUri: Uri? = null
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create file")
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
                savedUri = uri
                where = "Downloads folder"
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
                    ?: throw IllegalStateException("No storage")
                dir.mkdirs()
                File(dir, name).writeBytes(bytes)
                where = dir.absolutePath
            }
            val opened = savedUri
            runOnUiThread {
                Toast.makeText(this, "Saved in $where: $name", Toast.LENGTH_LONG).show()
                if (opened != null) {
                    try {
                        startActivity(
                            Intent(Intent.ACTION_VIEW)
                                .setDataAndType(opened, mime)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        )
                    } catch (e: Exception) {
                        // no viewer installed; the file is still saved
                    }
                }
            }
        } catch (e: Exception) {
            toast("Could not save the file")
        }
    }
}
