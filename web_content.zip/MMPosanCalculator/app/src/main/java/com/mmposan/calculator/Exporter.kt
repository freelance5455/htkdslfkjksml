package com.mmposan.calculator

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Builds PDF and Excel (.xlsx) files fully offline, without any external library. */
object Exporter {

    private fun strs(a: JSONArray): List<String> =
        (0 until a.length()).map { if (a.isNull(it)) "" else a.get(it).toString() }

    private fun matrix(a: JSONArray): List<List<String>> =
        (0 until a.length()).map { strs(a.getJSONArray(it)) }

    // ---------------------------------------------------------------- PDF

    fun pdf(o: JSONObject): ByteArray {
        val land = o.optBoolean("landscape")
        val pw = if (land) 842 else 595
        val ph = if (land) 595 else 842
        val margin = 24f
        val head = strs(o.getJSONArray("head"))
        val body = matrix(o.getJSONArray("disp"))
        val foot = strs(o.getJSONArray("footDisp"))
        val title = o.optString("title")
        val school = o.optString("school")
        val n = head.size
        val avail = pw - 2 * margin

        val normal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
        }
        val bold = Paint(normal).apply { typeface = Typeface.DEFAULT_BOLD }

        var size = 8f
        fun widths(): FloatArray {
            normal.textSize = size
            bold.textSize = size
            return FloatArray(n) { c ->
                var w = head[c].split(" ").maxOf { bold.measureText(it) }
                for (r in body) if (c < r.size) w = maxOf(w, normal.measureText(r[c]))
                if (c < foot.size) w = maxOf(w, bold.measureText(foot[c]))
                w + 8f
            }
        }

        var cw = widths()
        var tries = 0
        while (cw.sum() > avail && tries < 6) {
            size = (size * avail / cw.sum() * 0.97f).coerceAtLeast(4.5f)
            cw = widths()
            tries++
        }
        val extra = (avail - cw.sum()) / n
        if (extra > 0) cw = FloatArray(n) { cw[it] + extra }

        val lh = size * 1.25f
        val rowH = lh + 6f

        fun wrap(text: String, width: Float, p: Paint): List<String> {
            val lines = ArrayList<String>()
            var cur = ""
            for (word in text.split(" ")) {
                val t = if (cur.isEmpty()) word else "$cur $word"
                if (cur.isNotEmpty() && p.measureText(t) > width - 4f) {
                    lines.add(cur)
                    cur = word
                } else {
                    cur = t
                }
            }
            if (cur.isNotEmpty()) lines.add(cur)
            return lines
        }

        val headLines = head.mapIndexed { c, h -> wrap(h, cw[c], bold) }
        val headH = (headLines.maxOfOrNull { it.size } ?: 1) * lh + 6f

        val line = Paint().apply {
            color = Color.rgb(79, 199, 154)
            strokeWidth = 0.6f
            style = Paint.Style.STROKE
        }
        val green = Paint().apply {
            color = Color.rgb(15, 91, 60)
            style = Paint.Style.FILL
        }
        val white = Paint(bold).apply { color = Color.WHITE }
        val titleP = Paint(bold).apply {
            textSize = 13f
            textAlign = Paint.Align.LEFT
        }
        val schoolP = Paint(normal).apply {
            textSize = 9f
            textAlign = Paint.Align.LEFT
        }

        val doc = PdfDocument()
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var y = 0f

        fun drawRow(cells: List<List<String>>, h: Float, fill: Paint?, tp: Paint) {
            val cv = canvas!!
            var x = margin
            for (c in 0 until n) {
                val r = RectF(x, y, x + cw[c], y + h)
                if (fill != null) cv.drawRect(r, fill)
                cv.drawRect(r, line)
                val ls = if (c < cells.size) cells[c] else emptyList()
                var ty = y + 3f + size
                for (l in ls) {
                    cv.drawText(l, x + cw[c] / 2f, ty, tp)
                    ty += lh
                }
                x += cw[c]
            }
            y += h
        }

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
            page = p
            canvas = p.canvas
            y = margin
            if (pageNo == 1) {
                canvas!!.drawText(title, margin, y + 12f, titleP)
                y += 18f
                canvas!!.drawText(school, margin, y + 10f, schoolP)
                y += 20f
            }
            drawRow(headLines, headH, green, white)
        }

        newPage()
        for (r in body) {
            if (y + rowH > ph - margin) newPage()
            drawRow(r.map { listOf(it) }, rowH, null, normal)
        }
        if (y + rowH > ph - margin) newPage()
        drawRow(foot.map { listOf(it) }, rowH, green, white)
        page?.let { doc.finishPage(it) }

        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    // --------------------------------------------------------------- XLSX

    private fun esc(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")

    private fun colName(index: Int): String {
        var n = index
        var s = ""
        do {
            s = ('A' + n % 26) + s
            n = n / 26 - 1
        } while (n >= 0)
        return s
    }

    private fun cellList(a: JSONArray): List<Any?> =
        (0 until a.length()).map { if (a.isNull(it)) null else a.get(it) }

    fun xlsx(o: JSONObject): ByteArray {
        val rows = ArrayList<Pair<List<Any?>, Boolean>>()
        rows.add(Pair(listOf<Any?>(o.optString("title")), true))
        rows.add(Pair(listOf<Any?>(o.optString("school")), false))
        rows.add(Pair(emptyList<Any?>(), false))
        rows.add(Pair(cellList(o.getJSONArray("head")), true))
        val data = o.getJSONArray("rows")
        for (i in 0 until data.length()) rows.add(Pair(cellList(data.getJSONArray(i)), false))
        rows.add(Pair(cellList(o.getJSONArray("foot")), true))

        val colCount = o.getJSONArray("head").length()
        val sb = StringBuilder()
        rows.forEachIndexed { ri, pair ->
            val cells = pair.first
            val isBold = pair.second
            sb.append("<row r=\"${ri + 1}\">")
            cells.forEachIndexed { ci, v ->
                val ref = "${colName(ci)}${ri + 1}"
                val style = if (isBold) " s=\"1\"" else ""
                if (v is Number) {
                    sb.append("<c r=\"$ref\"$style><v>$v</v></c>")
                } else if (v != null) {
                    val t = v.toString()
                    if (t.isNotEmpty()) {
                        sb.append("<c r=\"$ref\"$style t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(t)}</t></is></c>")
                    }
                }
            }
            sb.append("</row>")
        }

        val sheet = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<cols><col min=\"1\" max=\"$colCount\" width=\"16\" customWidth=\"1\"/></cols>" +
            "<sheetData>$sb</sheetData></worksheet>"

        val contentTypes = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
            "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
            "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
            "</Types>"

        val rootRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
            "</Relationships>"

        val workbook = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" " +
            "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
            "<sheets><sheet name=\"Register\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>"

        val workbookRels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
            "</Relationships>"

        val styles = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>" +
            "<font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
            "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
            "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
            "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/></cellXfs>" +
            "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
            "</styleSheet>"

        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            fun put(name: String, text: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(text.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            put("[Content_Types].xml", contentTypes)
            put("_rels/.rels", rootRels)
            put("xl/workbook.xml", workbook)
            put("xl/_rels/workbook.xml.rels", workbookRels)
            put("xl/styles.xml", styles)
            put("xl/worksheets/sheet1.xml", sheet)
        }
        return out.toByteArray()
    }
}
