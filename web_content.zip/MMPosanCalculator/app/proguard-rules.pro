-keepclassmembers class com.mmposan.calculator.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
