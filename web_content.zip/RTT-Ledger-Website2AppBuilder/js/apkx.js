/* APKX v1 - Android WebView safe export layer (no external libraries, works offline) */
(function(){
if(window.APKX)return;
var UA=/Android/i.test(navigator.userAgent);
var FORCE=!!window.__APKX_FORCE||/[?#&]apkx=1/.test(location.href);
var A=window.APKX={active:UA||FORCE,rootId:''};
var origClick=HTMLAnchorElement.prototype.click;

var BASE_CSS=
'.apkx-root{font-family:Arial,Helvetica,sans-serif;color:#222;background:#fff;font-size:11px;padding:28px 30px;width:794px;box-sizing:border-box}'+
'.apkx-root *{box-sizing:border-box}'+
'.apkx-root table{border-collapse:collapse;width:100%;margin:6px 0}'+
'.apkx-root th,.apkx-root td{border:1px solid #bbb;padding:4px 5px;font-size:10px;text-align:left}'+
'.apkx-root th{background:#1f3864;color:#fff}'+
'.apkx-root h1{font-size:16px;margin:0 0 6px;color:#1f3864}'+
'.apkx-root h3{font-size:12px;margin:8px 0 4px;color:#1f3864}';

function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function kb(n){return n>1048576?(n/1048576).toFixed(2)+' MB':(n/1024).toFixed(1)+' KB'}
function toDataURL(blob){return new Promise(function(res,rej){var r=new FileReader();r.onload=function(){res(r.result)};r.onerror=rej;r.readAsDataURL(blob)})}
function safeName(s,ext){return (String(s||'Report').replace(/[^\w\-]+/g,'_').replace(/^_+|_+$/g,'')||'Report')+ext}

/* ---------- busy overlay ---------- */
A.busy=function(msg){
  var d=document.createElement('div');
  d.style.cssText='position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:2147483646;display:flex;align-items:center;justify-content:center;font-family:Arial,sans-serif';
  d.innerHTML='<div style="background:#1f3864;color:#fff;padding:16px 22px;border-radius:10px;font-size:15px">⏳ '+esc(msg)+'</div>';
  document.body.appendChild(d);
  return function(){try{d.remove()}catch(e){}};
};

/* ---------- save / share helpers ---------- */
function htmlText(h){
  var t=String(h).replace(/<style[\s\S]*?<\/style>/gi,'').replace(/<svg[\s\S]*?<\/svg>/gi,'')
   .replace(/<\/(td|th)>/gi,' | ').replace(/<\/(tr|h1|h2|h3|p|div|li)>/gi,'\n').replace(/<br\s*\/?>/gi,'\n').replace(/<[^>]+>/g,'');
  var ta=document.createElement('textarea');ta.innerHTML=t;t=ta.value;
  return t.split('\n').map(function(l){return l.replace(/(\s*\|\s*)+$/,'').replace(/\s+/g,' ').trim()}).filter(Boolean).join('\n');
}
A.htmlText=htmlText;
A.reportText=function(compact){try{var fn=compact?(window.getCompactReport||window.getPrintableReport):(window.getPrintableReport||window.getCompactReport);return htmlText(fn())}catch(e){return ''}};
/* native bridge probe (builder JS APIs) */
function findBridge(){
  try{
    var names=Object.getOwnPropertyNames(window);
    for(var i=0;i<names.length;i++){var n=names[i],o;try{o=window[n]}catch(e){continue}
      if(o&&typeof o==='object'&&typeof o.getBase64FromBlobData==='function')return o;}
  }catch(e){}
  return null;
}
function nativeApi(){try{return window.Website2APK||null}catch(e){return null}}
function bridgeInfo(){
  var out=[];
  try{
    Object.getOwnPropertyNames(window).forEach(function(n){
      var o;try{o=window[n]}catch(e){return}
      if(!o||typeof o!=='object'||n==='APKX')return;
      if(Object.prototype.toString.call(o)!=='[object Object]'&&Object.prototype.toString.call(o)!=='[object JavaObject]')return;
      var f=[];try{for(var k in o){if(typeof o[k]==='function')f.push(k)}}catch(e){}
      if(f.length)out.push(n+': '+f.slice(0,40).join(', '));
    });
  }catch(e){}
  return out;
}
function printHost(){return window.top===window?window:null}
/* build the vector print layout in the TOP document and call the builder's native print */
A.buildPrintRoot=function(p){
  var old=document.getElementById('apkxPrintRoot');if(old)old.remove();
  var os=document.getElementById('apkxPrintCss');if(os)os.remove();
  var css=document.createElement('style');css.id='apkxPrintCss';
  var page=p.fit==='page';
  css.textContent='#apkxPrintRoot{display:none}'+
   '@media print{@page{size:A4;margin:8mm}'+
   'html,body{height:auto!important;overflow:visible!important;background:#fff!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}'+
   'body>*:not(#apkxPrintRoot){display:none!important}'+
   '#apkxPrintRoot{display:block!important;width:734px;color:#000;background:#fff}'+
   '.apkxPg{width:734px;overflow:hidden;background:#fff;color:#000;break-after:page;page-break-after:always}'+
   '.apkxPg:last-child{break-after:auto;page-break-after:auto}}'+
   '.apkxPg.base table{border-collapse:collapse;width:100%;margin:6px 0}.apkxPg.base th,.apkxPg.base td{border:1px solid #bbb;padding:4px 5px;font-size:10px;text-align:left}.apkxPg.base th{background:#1f3864;color:#fff}'+
   '.apkxPg.base h1{font-size:16px;margin:0 0 6px;color:#1f3864}.apkxPg.base h3{font-size:12px;margin:8px 0 4px;color:#1f3864}'+
   p.pages.map(function(x){return x.css||''}).join('\n');
  document.head.appendChild(css);
  var root=document.createElement('div');root.id='apkxPrintRoot';
  root.innerHTML=p.pages.map(function(x){return '<section class="apkxPg'+(page?' base':'')+'"><div class="apkxIn" style="font:11px Arial,Helvetica,sans-serif;color:#000">'+x.html+'</div></section>'}).join('');
  document.body.appendChild(root);
  /* measure + fit */
  root.style.cssText='display:block;position:fixed;left:-10000px;top:0;visibility:hidden;width:734px';
  var secs=root.querySelectorAll('.apkxPg'),H=1030;
  Array.prototype.forEach.call(secs,function(sec){
    var inn=sec.firstChild,h=inn.scrollHeight;
    if(page){var z=Math.min(1,H/h),pw=inn.scrollWidth;if(pw>734)z=Math.min(z,734/pw);if(z<1)inn.style.zoom=Math.max(.3,z).toFixed(3);sec.style.height=H+'px'}
    else{
      var z2=1,w=inn.scrollWidth;
      if(w>734)z2=734/w;
      if(h*z2>H)z2=Math.min(z2,Math.max(.6,H/h));
      if(z2<1)inn.style.zoom=z2.toFixed(3);
    }
  });
  root.style.cssText='';
};
A.print=function(payload){
  A.buildPrintRoot(payload);
  setTimeout(function(){
    var n=nativeApi();
    try{if(n&&typeof n.printPage==='function'){n.printPage();return}}catch(e){}
    try{window.print()}catch(e){}
  },300);
};
var _urls=[];
function blobUrl(blob){var u=URL.createObjectURL(blob);_urls.push(u);return u}
/* method 1: blob anchor click, created in the TOP window and inside the tap handler (builder's blob-download hook) */
function saveBlobAnchor(blob,name){
  var u=blobUrl(blob),a=document.createElement('a');
  a.href=u;a.download=name;a.rel='noopener';a.style.cssText='position:fixed;left:0;top:0;opacity:0;width:1px;height:1px';
  document.body.appendChild(a);origClick.call(a);
  setTimeout(function(){try{a.remove()}catch(e){}},4000);
}
/* method 2: hidden iframe navigates to the blob (WebView hands non-viewable types to the download handler) */
function saveBlobFrame(blob){
  var u=blobUrl(blob),f=document.createElement('iframe');
  f.style.cssText='position:fixed;left:-9999px;width:1px;height:1px;border:0';f.src=u;document.body.appendChild(f);
  setTimeout(function(){try{f.remove()}catch(e){}},15000);
}
/* method 3: data: URI anchor */
function saveDataAnchor(blob,name){
  var r=new FileReader();r.onload=function(){var a=document.createElement('a');a.href=r.result;a.download=name;a.style.display='none';document.body.appendChild(a);origClick.call(a);setTimeout(function(){try{a.remove()}catch(e){}},4000)};r.readAsDataURL(blob);
}
function saveViaBrowser(blob){
  var n=nativeApi();if(!n||typeof n.openExternal!=='function')throw new Error('no openExternal');
  var r=new FileReader();r.onload=function(){try{n.openExternal(r.result)}catch(e){}};r.readAsDataURL(blob);
}
function saveBridge(blob){
  var b=findBridge();if(!b)throw new Error('no bridge');
  var r=new FileReader();r.onload=function(){try{b.getBase64FromBlobData(r.result)}catch(e){}};r.readAsDataURL(blob);
}
async function shareFile(blob,name,text){
  try{
    if(navigator.canShare){var f=new File([blob],name,{type:blob.type||'application/octet-stream'});if(navigator.canShare({files:[f]})){await navigator.share({files:[f],title:name});return 'ok'}}
    if(navigator.share&&text){await navigator.share({title:name,text:text.slice(0,6000)});return 'ok'}
  }catch(e){if(e&&e.name==='AbortError')return 'cancel'}
  return 'unsupported';
}
async function copyText(t){
  try{if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(t);return true}}catch(e){}
  try{var ta=document.createElement('textarea');ta.value=t;ta.style.cssText='position:fixed;left:-9999px';document.body.appendChild(ta);ta.select();var ok=document.execCommand('copy');ta.remove();return ok}catch(e){return false}
}

/* ---------- result dialog ---------- */
A.modal=function(o){
  var old=document.getElementById('apkxModal');if(old)old.remove();
  var ov=document.createElement('div');ov.id='apkxModal';
  ov.style.cssText='position:fixed;inset:0;background:rgba(15,23,42,.62);z-index:2147483647;display:flex;align-items:center;justify-content:center;font-family:Arial,Helvetica,sans-serif;padding:10px';
  var btn='border:0;border-radius:8px;padding:11px 14px;font-size:14px;font-weight:700;color:#fff;cursor:pointer;';
  var isText=!!o.text;var waText=o.text||o.wa||'';
  var h='<div style="background:#fff;color:#1b2333;border-radius:14px;width:100%;max-width:560px;max-height:94%;display:flex;flex-direction:column;overflow:hidden">'+
   '<div style="background:#1f3864;color:#fff;padding:12px 16px;display:flex;justify-content:space-between;gap:10px;align-items:center">'+
   '<div style="min-width:0"><div style="font-weight:700;font-size:15px;word-break:break-all">'+esc(o.title||o.name||'Export')+'</div>'+
   (o.blob?'<div style="font-size:11px;opacity:.85">'+esc(o.name||'')+' · '+kb(o.blob.size)+'</div>':'')+'</div>'+
   '<button id="apkxClose" style="'+btn+'background:#fff;color:#1f3864;flex:none">✕ Close</button></div>';
  if(o.blob){
    h+='<div style="padding:12px 14px;border-bottom:1px solid #e3e6ee">'+
     (o.print?'<button id="apkxPrint" style="'+btn+'background:#c0392b;width:100%;font-size:16px;padding:14px">🖨️ Save as PDF</button>':'<div style="font-size:13px">Only <b>Save as PDF</b> is available in this app.</div>')+
     '</div>'+
     '<div id="apkxMsg" style="padding:8px 14px;font-size:12px;color:#445;background:#f4f6fa">Tap <b>Save as PDF</b> → on the Android print screen choose <b>Save as PDF</b> → tap the PDF button and pick a folder.</div>';
  }
  h+='<div id="apkxBody" style="overflow:auto;padding:10px 12px;flex:1;background:#eef1f6"></div></div>';
  ov.innerHTML=h;document.body.appendChild(ov);
  var $=function(id){return ov.querySelector('#'+id)};
  var msg=function(t){var m=$('apkxMsg');if(m)m.innerHTML=t};
  $('apkxClose').onclick=function(){ov.remove()};
  var body=$('apkxBody');
  if(o.pages&&o.pages.length){
    o.pages.forEach(function(u,i){var im=document.createElement('img');im.src=u;im.style.cssText='width:100%;display:block;margin:0 0 10px;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.25)';im.alt='Page '+(i+1);body.appendChild(im)});
  }else if(o.text){
    var ta=document.createElement('textarea');ta.readOnly=true;ta.value=o.text;ta.style.cssText='width:100%;height:46vh;font:12px monospace;border:1px solid #ccd;border-radius:6px;padding:8px';body.appendChild(ta);
  }else if(o.htmlView){
    body.innerHTML='<style>'+(o.css||'')+'</style><div class="apkx-root" style="width:auto;overflow:auto">'+o.htmlView+'</div><style>'+BASE_CSS+'</style>';
  }else if(o.note){
    body.innerHTML='<div style="padding:10px;font-size:13px">'+o.note+'</div>';
  }else{
    body.style.display='none';
  }
  if(o.blob&&o.print){
    $('apkxPrint').onclick=function(){msg('🖨️ Opening Android print screen… choose <b>Save as PDF</b>.');A.print(o.print)};
  }
  return ov;
};

A.deliver=function(blob,name,extra){
  extra=extra||{};
  if(window.top!==window){
    try{if(!extra.text&&!extra.wa)extra.wa=A.reportText(false);window.parent.postMessage({apkx:'deliver',blob:blob,name:name,text:extra.text||'',wa:extra.wa||'',pages:extra.pages||null,print:extra.print||null},'*');return}catch(e){}
  }
  var o={blob:blob,name:name,title:name};for(var k in extra)o[k]=extra[k];
  return A.modal(o);
};
if(window.top===window){
  window.addEventListener('message',function(ev){
    var d=ev.data;if(!d||d.apkx!=='deliver'||!d.blob)return;
    var o={blob:d.blob,name:d.name,title:d.name};if(d.text)o.text=d.text;if(d.wa)o.wa=d.wa;if(d.pages)o.pages=d.pages;if(d.print)o.print=d.print;
    A.modal(o);
  });
}

/* ---------- HTML -> canvas (SVG foreignObject, fully offline) ---------- */
function renderCanvas(p){
  return new Promise(function(res,rej){
    var W=794,host=document.createElement('div');
    host.style.cssText='all:initial;display:block;position:fixed;left:-10000px;top:0;width:'+W+'px;visibility:hidden;pointer-events:none';
    /* measure inside a Shadow DOM so the page's own CSS (e.g. table{white-space:nowrap}) cannot change the height
       that is measured - the SVG render below only ever sees BASE_CSS + the report css */
    var sr=host.attachShadow?host.attachShadow({mode:'open'}):host;
    sr.innerHTML='<style>'+BASE_CSS+(p.css||'')+'</style><div class="apkx-root">'+p.html+'</div>';
    document.body.appendChild(host);
    var root=sr.querySelector('.apkx-root'),H=Math.ceil(root.scrollHeight)+2,xml;
    try{
      var ser=new XMLSerializer();
      xml='<div xmlns="http://www.w3.org/1999/xhtml">'+Array.prototype.map.call(sr.children,function(c){return ser.serializeToString(c)}).join('')+'</div>';
    }catch(e){host.remove();return rej(e)}
    host.remove();
    var svg='<svg xmlns="http://www.w3.org/2000/svg" width="'+W+'" height="'+H+'"><foreignObject x="0" y="0" width="'+W+'" height="'+H+'">'+xml+'</foreignObject></svg>';
    var img=new Image();
    img.onload=function(){
      try{
        var S=2,c=document.createElement('canvas');c.width=W*S;c.height=H*S;
        var x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(img,0,0,c.width,c.height);
        c.toDataURL('image/jpeg',.5); /* taint test */
        res({canvas:c});
      }catch(e){rej(e)}
    };
    img.onerror=function(){rej(new Error('render failed'))};
    img.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg);
  });
}
function composePages(c,mode){
  var PW=1588,PH=2246,out=[],cw=c.width,ch=c.height,s=Math.min(1,PH/ch);
  var minS=mode==='force'?0.3:0.6;
  function pg(){var p=document.createElement('canvas');p.width=PW;p.height=PH;var x=p.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,PW,PH);return [p,x]}
  if(s>=minS){
    var a=pg(),dw=cw*s;a[1].drawImage(c,(PW-dw)/2,0,dw,ch*s);out.push(a[0]);
  }else{
    var n=Math.ceil(ch/PH);
    for(var i=0;i<n;i++){var b=pg(),sh=Math.min(PH,ch-i*PH);b[1].drawImage(c,0,i*PH,cw,sh,0,0,cw,sh);out.push(b[0])}
  }
  return out;
}
function jpegBytes(canvas){
  var d=canvas.toDataURL('image/jpeg',.85).split(',')[1],b=atob(d),u=new Uint8Array(b.length);
  for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u;
}
function buildPdf(pages){
  var parts=[],offs=[],pos=0,te=new TextEncoder();
  function push(x){var u=typeof x==='string'?te.encode(x):x;parts.push(u);pos+=u.length}
  function obj(n,body){offs[n]=pos;push(n+' 0 obj\n');push(body);push('\nendobj\n')}
  push('%PDF-1.4\n');push(new Uint8Array([37,226,227,207,211,10]));
  var N=pages.length,kids=[];
  for(var k=0;k<N;k++)kids.push((3+3*k)+' 0 R');
  obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
  obj(2,'<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+N+' >>');
  for(var i=0;i<N;i++){
    var pgN=3+3*i,ct=4+3*i,im=5+3*i,jb=pages[i].bytes;
    obj(pgN,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im0 '+im+' 0 R >> >> /Contents '+ct+' 0 R >>');
    var cs='q 595.28 0 0 841.89 0 0 cm /Im0 Do Q';
    obj(ct,'<< /Length '+cs.length+' >>\nstream\n'+cs+'\nendstream');
    offs[im]=pos;push(im+' 0 obj\n<< /Type /XObject /Subtype /Image /Width '+pages[i].w+' /Height '+pages[i].h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+jb.length+' >>\nstream\n');
    push(jb);push('\nendstream\nendobj\n');
  }
  var xr=pos,total=2+3*N;
  var x='xref\n0 '+(total+1)+'\n0000000000 65535 f \n';
  for(var j=1;j<=total;j++)x+=('0000000000'+offs[j]).slice(-10)+' 00000 n \n';
  push(x);push('trailer\n<< /Size '+(total+1)+' /Root 1 0 R >>\nstartxref\n'+xr+'\n%%EOF');
  return new Blob(parts,{type:'application/pdf'});
}
/* pages: [{html,css}] ; opts.fit: 'auto' | 'force' */
A.htmlToPdf=async function(pages,opts){
  opts=opts||{};var all=[];
  for(var i=0;i<pages.length;i++){
    var r=await renderCanvas(pages[i]);
    var cps=composePages(r.canvas,opts.fit||'auto');
    cps.forEach(function(c){all.push(c)});
  }
  var js=all.map(function(c){return {bytes:jpegBytes(c),w:c.width,h:c.height}});
  var prev=all.map(function(c){var t=document.createElement('canvas');t.width=c.width/2;t.height=c.height/2;t.getContext('2d').drawImage(c,0,0,t.width,t.height);return t.toDataURL('image/jpeg',.8)});
  return {blob:buildPdf(js),previews:prev};
};

/* ---------- section helpers ---------- */
A.reportCss=function(){
  var out='';
  function take(r){var s=r.selectorText||'';if(/body|html|:not|:root/.test(s))return;if(/#rep\b|#report\b|#rin\b/.test(s))out+=r.cssText}
  for(var i=0;i<document.styleSheets.length;i++){
    var rules;try{rules=document.styleSheets[i].cssRules}catch(e){continue}
    for(var j=0;j<rules.length;j++){
      var r=rules[j];
      if(r.type===1)take(r);
      else if(r.type===4){var c=(r.conditionText||(r.media&&r.media.mediaText)||'');if(/dark/.test(c))continue;for(var q=0;q<r.cssRules.length;q++)if(r.cssRules[q].type===1)take(r.cssRules[q])}
    }
  }
  return out+'#rep,#report{position:static!important;display:block!important;left:auto!important;height:auto!important;overflow:visible!important;width:734px!important;background:#fff;color:#000}';
};
A.sectionReport=function(compact){
  var fn=compact?(window.getCompactReport||window.getPrintableReport):(window.getPrintableReport||window.getCompactReport);
  var h=fn();
  var inner=(!compact&&A.rootId)?'<div id="'+A.rootId+'">'+h+'</div>':h;
  return {html:inner,css:compact?'':A.reportCss(),title:document.title};
};
A.exportSectionPdf=async function(){
  var done=A.busy('Building PDF…'),rep;
  try{
    rep=A.sectionReport(false);
    var r=await A.htmlToPdf([rep],{fit:'auto'});
    done();done=null;
    A.deliver(r.blob,safeName(document.title,'.pdf'),{pages:r.previews,wa:htmlText(rep.html),print:{fit:'one',pages:[{html:rep.html,css:rep.css}]}});
  }catch(e){
    if(done)done();
    A.modal({title:'Report view',note:'PDF engine not available in this app build ('+esc(e&&e.message||e)+'). The report is shown below – take a screenshot to save it.',htmlView:rep?rep.html:'',css:rep?rep.css:''});
  }
};

/* ---------- install (called at end of every section) ---------- */
A.install=function(cfg){
  cfg=cfg||{};A.rootId=cfg.rootId||'';
  if(!A.active)return;
  try{var st=document.createElement('style');st.textContent='button[onclick*="exportXlsx"],button[onclick*="csv("]{display:none!important}';document.head.appendChild(st)}catch(e){}
  window.saveFile=function(b,n){A.deliver(b,n)};
  window.saveTextFile=function(t,n,m){A.deliver(new Blob([t],{type:m||'text/plain;charset=utf-8'}),n,{text:t})};
  window.showAndroidViewer=function(c,n,mode){A.deliver(new Blob([c],{type:mode==='csv'?'text/csv;charset=utf-8':'text/html;charset=utf-8'}),n,{text:String(c)})};
  ['pdf','pdfOut','exportPdf','exportPdfTable'].forEach(function(k){if(typeof window[k]==='function')window[k]=A.exportSectionPdf});
  var b=document.getElementById('pdfb');if(b)b.onclick=A.exportSectionPdf;
  window.print=function(){A.exportSectionPdf()};
  HTMLAnchorElement.prototype.click=function(){
    if(!A._bypass&&this.hasAttribute('download')&&/^(blob:|data:)/i.test(this.href)){
      var nm=this.getAttribute('download')||'file',self=this;
      fetch(this.href).then(function(r){return r.blob()}).then(function(bl){A.deliver(bl,nm)}).catch(function(){origClick.call(self)});
      return;
    }
    return origClick.apply(this,arguments);
  };
};
})();
