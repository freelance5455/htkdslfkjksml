'use strict';
const $=s=>document.querySelector(s),MON=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],PG=15,
K={db:'rtt_db_v1',us:'rtt_users_v1',se:'rtt_sess_v1',lg:'rtt_log_v1',lk:'rtt_lock_v1'};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
const num=n=>Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2}),inr=n=>'₹'+num(n);
const fmt=d=>{const[y,m,x]=d.split('-');return x+'-'+MON[m-1]+'-'+y},today=()=>new Date().toISOString().slice(0,10);
const sum=(t,a)=>(a||DB[t]).reduce((s,r)=>s+r.amt,0),uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const ld=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},sv=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const party=n=>n.toUpperCase().replace(/\s*-+\s*\d.*$/,'').trim()||n;
let DB,US,ME,UNDO,idle,S={tab:'dash',sel:new Set(),credit:{q:'',from:'',to:'',min:'',max:'',k:'date',d:1,p:1},debit:{q:'',from:'',to:'',min:'',max:'',k:'date',d:1,p:1},pq:''};
const can=()=>ME.role!='viewer',adm=()=>ME.role=='admin';

/* ---------- SHA-256 (offline, no libs) ---------- */
function sha(m){const R=(x,n)=>x>>>n|x<<32-n,s=unescape(encodeURIComponent(m)),P=[];for(let p=2;P.length<64;p++)if(P.every(q=>p%q))P.push(p);
const Kc=P.map(p=>Math.cbrt(p)%1*2**32|0),H=P.slice(0,8).map(p=>Math.sqrt(p)%1*2**32|0),w=[];
for(let i=0;i<s.length;i++)w[i>>2]|=s.charCodeAt(i)<<24-i%4*8;w[s.length>>2]|=0x80<<24-s.length%4*8;w[((s.length+8>>6)+1)*16-1]=s.length*8;
for(let o=0;o<w.length;o+=16){const a=[];for(let i=0;i<64;i++){if(i<16)a[i]=w[o+i]|0;else{const x=a[i-15],y=a[i-2];a[i]=a[i-16]+(R(x,7)^R(x,18)^x>>>3)+a[i-7]+(R(y,17)^R(y,19)^y>>>10)|0}}
let[A,B,C,D,E,F,G,I]=H;for(let i=0;i<64;i++){const t1=I+(R(E,6)^R(E,11)^R(E,25))+(E&F^~E&G)+Kc[i]+a[i]|0,t2=(R(A,2)^R(A,13)^R(A,22))+(A&B^A&C^B&C)|0;I=G;G=F;F=E;E=D+t1|0;D=C;C=B;B=A;A=t1+t2|0}
[A,B,C,D,E,F,G,I].forEach((v,i)=>H[i]=H[i]+v|0)}return H.map(x=>(x>>>0).toString(16).padStart(8,'0')).join('')}

/* ---------- auth ---------- */
const mk=(u,name,role,pw,def)=>{const salt=[...crypto.getRandomValues(new Uint8Array(8))].map(x=>x.toString(16)).join('');return{u,name,role,salt,h:sha(salt+pw),def}};
function boot(){DB=ld(K.db);if(!DB){DB=JSON.parse(JSON.stringify(SEED));sv(K.db,DB)}
US=ld(K.us);if(!US){US=[mk('admin','Administrator','admin','RTT@2026',1)];sv(K.us,US)}
ME=US.find(u=>u.u==sessionStorage.getItem(K.se));if(ME)start()}
function doLogin(e){e.preventDefault();const L=ld(K.lk,{n:0,t:0}),m=$('#lmsg');
if(Date.now()<L.t){m.textContent='Too many attempts. Wait '+Math.ceil((L.t-Date.now())/1e3)+'s.';return}
const u=US.find(x=>x.u==$('#lu').value.trim().toLowerCase());
if(u&&sha(u.salt+$('#lp').value)==u.h){sv(K.lk,{n:0,t:0});sessionStorage.setItem(K.se,u.u);ME=u;log('Signed in');start()}
else{L.n++;if(L.n>=5){L.t=Date.now()+6e4;L.n=0}sv(K.lk,L);m.textContent='Invalid username or password.'}}
function start(){$('#login').hidden=true;$('#app').hidden=false;$('#who').textContent=ME.name+' ('+ME.role+')';
document.querySelectorAll('[data-a]').forEach(b=>b.hidden=!adm());
$('#nav').onclick=e=>e.target.dataset.t&&go(e.target.dataset.t);
['click','keydown'].forEach(v=>addEventListener(v,bump));bump();go('dash')}
const bump=()=>{clearTimeout(idle);if(ME)idle=setTimeout(()=>{alert('Signed out after 15 minutes of inactivity.');logout()},9e5)};
function logout(){sessionStorage.removeItem(K.se);location.reload()}
function log(a){const l=ld(K.lg,[]);l.unshift({t:new Date().toLocaleString('en-IN'),u:ME.u,a});sv(K.lg,l.slice(0,300))}
const save=()=>sv(K.db,DB);

/* ---------- ui helpers ---------- */
function toast(m,undo){const t=$('#toast');t.innerHTML=esc(m)+(undo?'<button onclick="undo()">Undo</button>':'');t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(()=>t.hidden=true,6e3)}
const closeM=()=>$('#modal').hidden=true,showM=h=>{$('#modal').innerHTML=h;$('#modal').hidden=false};
function go(t){S.tab=t;S.sel=new Set();document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));
$('#main').innerHTML=({dash,credit:()=>ledger('credit'),debit:()=>ledger('debit'),parties,users,log:logv})[t]();if(t=='credit'||t=='debit')tbl(t)}
const render=()=>go(S.tab);
function dl(b,n){const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=n;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4e3)}

/* ---------- dashboard ---------- */
function dash(){const C=sum('credit'),D=sum('debit'),mm={};
['credit','debit'].forEach(t=>DB[t].forEach(r=>{const k=r.date.slice(0,7);(mm[k]=mm[k]||{credit:0,debit:0})[t]+=r.amt}));
const ks=Object.keys(mm).sort(),mx=Math.max(1,...ks.map(k=>Math.max(mm[k].credit,mm[k].debit))),gw=620/Math.max(ks.length,1);
const svg=`<svg viewBox="0 0 640 230" width="100%" role="img" aria-label="Monthly credit and debit">${ks.map((k,i)=>{const x=10+i*gw,h1=mm[k].credit/mx*170,h2=mm[k].debit/mx*170,bw=Math.min(26,gw/2-3);
return`<rect x="${x+gw/2-bw-1}" y="${190-h1}" width="${bw}" height="${h1}" fill="#0f7b5f"><title>${MON[+k.slice(5)-1]} credit ${inr(mm[k].credit)}</title></rect><rect x="${x+gw/2+1}" y="${190-h2}" width="${bw}" height="${h2}" fill="#b4412f"><title>${MON[+k.slice(5)-1]} debit ${inr(mm[k].debit)}</title></rect><text x="${x+gw/2}" y="208" font-size="11" text-anchor="middle" fill="#68708a">${MON[+k.slice(5)-1]} ${k.slice(2,4)}</text>`}).join('')}<line x1="0" y1="190" x2="640" y2="190" stroke="#d9dce8"/></svg>`;
const pm={};DB.credit.forEach(r=>{const p=party(r.cust);pm[p]=(pm[p]||0)+r.amt});const top=Object.entries(pm).sort((a,b)=>b[1]-a[1]).slice(0,8),tm=top[0]?top[0][1]:1;
const rec=[...DB.credit.map(r=>({...r,t:'c'})),...DB.debit.map(r=>({...r,t:'d'}))].sort((a,b)=>b.date.localeCompare(a.date)).slice(0,7);
return`${ME.def?'<div class=warn>You are using the default password. Please change it (sidebar &rarr; Change password).</div>':''}
<h2>Dashboard</h2><div class=hero><small>Net balance (Credit &minus; Debit)</small><div class=big>${inr(C-D)}</div>
<div class=split><i style="width:${C/((C+D)||1)*100}%;background:#4cc9a3"></i><i style="width:${D/((C+D)||1)*100}%;background:#ef8a76"></i></div>
<div class=kp><span>Credit ${inr(C)} (${DB.credit.length} entries)</span><span>Debit ${inr(D)} (${DB.debit.length} entries)</span></div></div>
<div class=bar><button class="b p" onclick="openForm('credit')" ${can()?'':'hidden'}>+ Credit entry</button><button class="b p" onclick="openForm('debit')" ${can()?'':'hidden'}>+ Debit entry</button><span class=sp></span><button class=b onclick="pdfAll()">Full report PDF</button>${xlBtn('all')}</div>
<div class=grid><div class=card><h3>Monthly credit vs debit</h3>${svg}</div>
<div class=card><h3>Top customers by credit</h3>${top.map(([p,v])=>`<div class=hb><span title="${esc(p)}">${esc(p)}</span><i style="width:${v/tm*40}%"></i><span class=r>${inr(v)}</span></div>`).join('')}</div>
<div class=card style="grid-column:1/-1"><h3>Recent entries</h3><div class=tw><table>${rec.map(r=>`<tr><td>${fmt(r.date)}</td><td class=w>${esc(r.cust)}</td><td>${r.t=='c'?'Credit':'Debit'}</td><td class="r ${r.t}">${inr(r.amt)}</td></tr>`).join('')}</table></div></div></div>`}

/* ---------- ledgers ---------- */
function flt(t){const f=S[t],q=f.q.toLowerCase();return DB[t].filter(r=>(!q||(r.cust+' '+(r.gst||'')+' '+r.note+' '+r.amt).toLowerCase().includes(q))&&(!f.from||r.date>=f.from)&&(!f.to||r.date<=f.to)&&(f.min===''||r.amt>=+f.min)&&(f.max===''||r.amt<=+f.max))
.sort((a,b)=>(a[f.k]>b[f.k]?1:a[f.k]<b[f.k]?-1:0)*f.d)}
function ledger(t){const f=S[t],cr=t=='credit',I=(k,l,ty)=>`<label>${l}<input type=${ty||'text'} value="${esc(f[k])}" oninput="S.${t}.${k}=this.value;S.${t}.p=1;tbl('${t}')"></label>`;
return`<h2>${cr?'Credit':'Debit'} Ledger</h2><div class=bar>${I('q','Search')}${I('from','From','date')}${I('to','To','date')}${I('min','Min ₹','number')}${I('max','Max ₹','number')}
<button class=b onclick="S.${t}={q:'',from:'',to:'',min:'',max:'',k:'date',d:1,p:1};render()">Clear</button><span class=sp></span>
<button class="b p" onclick="openForm('${t}')" ${can()?'':'hidden'}>+ Add</button><button class="b d" id=bd onclick="delSel('${t}')" hidden>Delete selected</button><button class=b onclick="pdfL('${t}')">PDF</button>${xlBtn(t)}</div><div id=tbl></div>`}
const th=(t,k,l,c)=>`<th class="${c||''}" onclick="sortBy('${t}','${k}')">${l}${S[t].k==k?(S[t].d>0?' ▲':' ▼'):''}</th>`;
function sortBy(t,k){const f=S[t];f.d=f.k==k?-f.d:1;f.k=k;tbl(t)}
function tbl(t){const f=S[t],rows=flt(t),cr=t=='credit',n=Math.max(1,Math.ceil(rows.length/PG));f.p=Math.min(f.p,n);const pr=rows.slice((f.p-1)*PG,f.p*PG),ed=can();
$('#tbl').innerHTML=`<div class=tw><table><thead><tr>${ed?`<th class=ck><input type=checkbox onchange="selAll('${t}',this.checked)"></th>`:''}<th>#</th>${th(t,'date','Date')}${th(t,'cust','Customer')}${cr?th(t,'gst','GST Name'):''}${th(t,'amt','Amount','r')}<th>Note</th>${ed?'<th></th>':''}</tr></thead><tbody>
${pr.map((r,i)=>`<tr>${ed?`<td><input type=checkbox ${S.sel.has(r.id)?'checked':''} onchange="sel('${r.id}',this.checked)"></td>`:''}<td>${(f.p-1)*PG+i+1}</td><td>${fmt(r.date)}</td><td class=w>${esc(r.cust)}</td>${cr?`<td class=w>${esc(r.gst)}</td>`:''}<td class="r ${cr?'c':'d'}">${num(r.amt)}</td><td class=w>${esc(r.note)}</td>${ed?`<td><button class="b s" onclick="openForm('${t}','${r.id}')">Edit</button> <button class="b s d" onclick="delIds('${t}',['${r.id}'])">Delete</button></td>`:''}</tr>`).join('')||'<tr><td colspan=9 class=mut>No entries match.</td></tr>'}</tbody>
<tfoot><tr><td colspan="${(ed?3:2)+(cr?2:1)}">Total (${rows.length} entries)</td><td class=r>${num(sum(t,rows))}</td><td colspan=2></td></tr></tfoot></table></div>
<div class=pg><button class="b s" ${f.p<2?'disabled':''} onclick="S.${t}.p--;tbl('${t}')">Prev</button>Page ${f.p} / ${n}<button class="b s" ${f.p>=n?'disabled':''} onclick="S.${t}.p++;tbl('${t}')">Next</button></div>`;
const b=$('#bd');if(b)b.hidden=!S.sel.size}
const sel=(id,v)=>{v?S.sel.add(id):S.sel.delete(id);$('#bd').hidden=!S.sel.size},selAll=(t,v)=>{const f=S[t];flt(t).slice((f.p-1)*PG,f.p*PG).forEach(r=>v?S.sel.add(r.id):S.sel.delete(r.id));tbl(t)};
const delSel=t=>delIds(t,[...S.sel]);
function delIds(t,ids){if(!can())return;const gone=DB[t].map((r,i)=>({r,i})).filter(x=>ids.includes(x.r.id));DB[t]=DB[t].filter(r=>!ids.includes(r.id));UNDO={t,gone};save();log('Deleted '+gone.length+' '+t+' entr'+(gone.length>1?'ies':'y'));S.sel=new Set();render();toast('Deleted '+gone.length+' entr'+(gone.length>1?'ies':'y'),1)}
function undo(){if(!UNDO)return;UNDO.gone.forEach(x=>DB[UNDO.t].splice(x.i,0,x.r));save();log('Restored deleted entries');UNDO=null;render();toast('Restored')}
function openForm(t,id){if(!can())return;const cr=t=='credit',r=id?DB[t].find(x=>x.id==id):{date:today(),cust:'',gst:'',amt:'',note:''};
showM(`<form class=card onsubmit="saveE(event,'${t}','${id||''}')"><h3>${id?'Edit':'Add'} ${cr?'credit':'debit'} entry</h3>
<label>Date<input type=date id=fd required value="${r.date}"></label><label>Customer<input id=fc list=cl required value="${esc(r.cust)}"></label>
<datalist id=cl>${[...new Set(DB[t].map(x=>x.cust))].map(c=>`<option value="${esc(c)}">`).join('')}</datalist>
${cr?`<label>GST name<input id=fg value="${esc(r.gst)}" placeholder="Same as customer if left blank"></label>`:''}
<label>Amount (₹)<input id=fa type=number step=0.01 min=0.01 required value="${r.amt}"></label><label>Note<input id=fn value="${esc(r.note)}"></label>
<div class=row><button class="b p">Save</button><button type=button class=b onclick=closeM()>Cancel</button></div></form>`)}
function saveE(e,t,id){e.preventDefault();const c=$('#fc').value.trim(),o={date:$('#fd').value,cust:c,amt:Math.round(+$('#fa').value*100)/100,note:$('#fn').value.trim()};if(t=='credit')o.gst=$('#fg').value.trim()||c;
if(id)Object.assign(DB[t].find(x=>x.id==id),o);else DB[t].push({id:uid(),...o});save();log((id?'Edited ':'Added ')+t+' entry: '+c+' '+inr(o.amt));closeM();render();toast(id?'Entry updated':'Entry added')}

/* ---------- party summary ---------- */
function pmap(){const m={};['credit','debit'].forEach(t=>DB[t].forEach(r=>{const p=party(r.cust),x=m[p]=m[p]||{credit:0,debit:0,n:0};x[t]+=r.amt;x.n++}));
return Object.entries(m).filter(([p])=>p.includes(S.pq.toUpperCase())).sort((a,b)=>b[1].credit-a[1].credit)}
function parties(){return`<h2>Party Summary</h2><p class=mut>Entries are grouped by name; the code after the name (e.g. -037) is ignored.</p><div class=bar><label>Search<input value="${esc(S.pq)}" oninput="S.pq=this.value;$('#pt').innerHTML=prow()"></label><span class=sp></span><button class=b onclick="pdfP()">PDF</button>${xlBtn('parties')}</div><div class=tw><table><thead><tr><th>Party</th><th class=r>Entries</th><th class=r>Credit</th><th class=r>Debit</th><th class=r>Net</th></tr></thead><tbody id=pt>${prow()}</tbody></table></div>`}
const prow=()=>pmap().map(([p,x])=>`<tr><td class=w>${esc(p)}</td><td class=r>${x.n}</td><td class="r c">${num(x.credit)}</td><td class="r d">${num(x.debit)}</td><td class=r>${num(x.credit-x.debit)}</td></tr>`).join('');

/* ---------- users & data ---------- */
function users(){return`<h2>Users &amp; Data</h2><div class=tw><table><thead><tr><th>Username</th><th>Name</th><th>Role</th><th></th></tr></thead><tbody>${US.map(u=>`<tr><td>${esc(u.u)}</td><td>${esc(u.name)}</td><td><select onchange="setRole('${u.u}',this.value)" style="width:auto"><option ${u.role=='admin'?'selected':''}>admin</option><option ${u.role=='editor'?'selected':''}>editor</option><option ${u.role=='viewer'?'selected':''}>viewer</option></select></td><td><button class="b s" onclick="pwForm('${u.u}')">Reset password</button> <button class="b s d" onclick="delUser('${u.u}')">Delete</button></td></tr>`).join('')}</tbody></table></div>
<form class=card style="margin:14px 0;max-width:520px" onsubmit="addUser(event)"><h3>Add user</h3><label>Username<input id=nu required></label><label>Full name<input id=nn required></label><label>Password (min 6)<input id=np type=password minlength=6 required></label><label>Role<select id=nr><option>editor</option><option>viewer</option><option>admin</option></select></label><button class="b p">Create user</button><p class=mut>admin: everything &middot; editor: add/edit/delete entries &middot; viewer: read &amp; export only</p></form>
<div class=card style="max-width:520px"><h3>Data tools</h3><div class=row><button class="b d" onclick="resetData()">Reset to original Excel data</button></div></div>`}
function addUser(e){e.preventDefault();const u=$('#nu').value.trim().toLowerCase();if(US.some(x=>x.u==u))return toast('Username already exists');US.push(mk(u,$('#nn').value.trim(),$('#nr').value,$('#np').value));sv(K.us,US);log('Created user '+u);render();toast('User created')}
function setRole(u,r){const x=US.find(y=>y.u==u);if(x.role=='admin'&&r!='admin'&&US.filter(y=>y.role=='admin').length<2){toast('At least one admin is required');return render()}x.role=r;sv(K.us,US);log('Role of '+u+' set to '+r);toast('Role updated')}
function delUser(u){if(u==ME.u||US.find(x=>x.u==u).role=='admin'&&US.filter(x=>x.role=='admin').length<2)return toast('Cannot delete yourself or the last admin');if(!confirm('Delete user '+u+'?'))return;US=US.filter(x=>x.u!=u);sv(K.us,US);log('Deleted user '+u);render()}
function pwForm(u,own){showM(`<form class=card onsubmit="setPw(event,'${u}',${own?1:0})"><h3>${own?'Change':'Reset'} password: ${esc(u)}</h3>${own?'<label>Current password<input id=pc type=password required></label>':''}<label>New password (min 6)<input id=pn type=password minlength=6 required></label><label>Confirm<input id=pf type=password required></label><p id=pm class=err></p><div class=row><button class="b p">Save</button><button type=button class=b onclick=closeM()>Cancel</button></div></form>`)}
function setPw(e,u,own){e.preventDefault();const x=US.find(y=>y.u==u);if(own&&sha(x.salt+$('#pc').value)!=x.h)return $('#pm').textContent='Current password is wrong.';if($('#pn').value!=$('#pf').value)return $('#pm').textContent='Passwords do not match.';
Object.assign(x,mk(u,x.name,x.role,$('#pn').value),{def:0});sv(K.us,US);log('Password changed for '+u);closeM();render();toast('Password updated')}
function resetData(){if(!confirm('Replace ALL entries with the original Excel data?'))return;DB=JSON.parse(JSON.stringify(SEED));save();log('Reset data to original');toast('Data reset');render()}
function logv(){return`<h2>Activity Log</h2><div class=tw><table><thead><tr><th>When</th><th>User</th><th>Action</th></tr></thead><tbody>${ld(K.lg,[]).map(l=>`<tr><td>${esc(l.t)}</td><td>${esc(l.u)}</td><td class=w>${esc(l.a)}</td></tr>`).join('')}</tbody></table></div>`}

/* ---------- PDF (hand-built, no libs) ---------- */
function pdf(secs,sub){const W=842,H=595,M=30,RH=16,P=[];let c='',y=0;
const T=(s,x,yy,f,z,w,r)=>{s=String(s).replace(/₹/g,'Rs.').replace(/[^\x20-\x7e]/g,'?');const mx=Math.floor((w||900)/(z*.52));if(s.length>mx)s=s.slice(0,mx-1)+'.';if(r)x+=w-s.length*z*.55;c+=`BT /F${f} ${z} Tf ${x.toFixed(1)} ${yy.toFixed(1)} Td (${s.replace(/[\\()]/g,'\\$&')}) Tj ET\n`};
const np=()=>{if(c)P.push(c);c='';y=H-M;T('RAAJEESWARI TEXTIE TRADERS',M,y-8,2,13);T(sub+'   |   Generated '+new Date().toLocaleString('en-IN'),M,y-22,1,8);y-=44};
const hd=s=>{c+=`0.11 0.17 0.37 rg ${M} ${y-RH+4} ${W-2*M} ${RH} re f 1 1 1 rg\n`;let x=M;s.cols.forEach(k=>{T(k.h,x+4,y-9,2,8,k.w-8,k.r);x+=k.w});c+='0 0 0 rg\n';y-=RH};
np();secs.forEach(s=>{if(y<M+90)np();T(s.title,M,y-8,2,11);y-=22;hd(s);const row=(a,b)=>{if(y<M+RH+14){np();hd(s)}if(!b&&a._z)c+=`0.96 0.97 0.98 rg ${M} ${y-RH+4} ${W-2*M} ${RH} re f 0 0 0 rg\n`;let x=M;s.cols.forEach((k,i)=>{T(a[i]??'',x+4,y-9,b?2:1,8,k.w-8,k.r);x+=k.w});y-=RH};
s.rows.forEach((r,i)=>{r._z=i%2;row(r)});if(s.tot)row(s.tot,1);y-=16});
P.push(c);P.forEach((p,i)=>{c='';T('Page '+(i+1)+' of '+P.length,W-M-70,14,1,8);P[i]+=c});
const N=P.length,o=['','<</Type/Catalog/Pages 2 0 R>>',`<</Type/Pages/Count ${N}/Kids[${P.map((_,i)=>5+2*i+' 0 R').join(' ')}]>>`,'<</Type/Font/Subtype/Type1/BaseFont/Helvetica/Encoding/WinAnsiEncoding>>','<</Type/Font/Subtype/Type1/BaseFont/Helvetica-Bold/Encoding/WinAnsiEncoding>>'];
P.forEach((p,i)=>{o[5+2*i]=`<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${W} ${H}]/Resources<</Font<</F1 3 0 R/F2 4 0 R>>>>/Contents ${6+2*i} 0 R>>`;o[6+2*i]=`<</Length ${p.length}>>\nstream\n${p}\nendstream`});
let s='%PDF-1.4\n',off=[];for(let i=1;i<o.length;i++){off[i]=s.length;s+=`${i} 0 obj\n${o[i]}\nendobj\n`}const x=s.length;
s+=`xref\n0 ${o.length}\n0000000000 65535 f \n`+off.slice(1).map(v=>String(v).padStart(10,'0')+' 00000 n \n').join('')+`trailer\n<</Size ${o.length}/Root 1 0 R>>\nstartxref\n${x}\n%%EOF`;
return new Blob([s],{type:'application/pdf'})}
function secL(t,rows){const cr=t=='credit';return{title:cr?'CREDIT LEDGER':'DEBIT LEDGER',cols:[{h:'S.NO',w:40},{h:'DATE',w:75},{h:'CUSTOMER',w:cr?300:557},...(cr?[{h:'GST NAME',w:257}]:[]),{h:'AMOUNT (Rs.)',w:110,r:1}],
rows:rows.map((r,i)=>[i+1,fmt(r.date),r.cust,...(cr?[r.gst]:[]),num(r.amt)]),tot:['','','TOTAL ('+rows.length+' entries)',...(cr?['']:[]),num(sum(t,rows))]}}
function pdfL(t){const f=S[t],n=[f.q&&'search "'+f.q+'"',f.from&&'from '+fmt(f.from),f.to&&'to '+fmt(f.to)].filter(Boolean).join(', ');outPdf([secL(t,flt(t))],(t=='credit'?'Credit':'Debit')+' ledger'+(n?' ('+n+')':''),`RTT-${t}-ledger-${today()}.pdf`)}
const secP=()=>({title:'PARTY SUMMARY',cols:[{h:'PARTY',w:400},{h:'ENTRIES',w:60,r:1},{h:'CREDIT',w:107,r:1},{h:'DEBIT',w:107,r:1},{h:'NET',w:108,r:1}],rows:pmap().map(([p,x])=>[p,x.n,num(x.credit),num(x.debit),num(x.credit-x.debit)])});
const pdfP=()=>outPdf([secP()],'Party summary',`RTT-party-summary-${today()}.pdf`);
function pdfAll(){const C=sum('credit'),D=sum('debit');outPdf([{title:'SUMMARY',cols:[{h:'PARTICULARS',w:500},{h:'AMOUNT (Rs.)',w:282,r:1}],rows:[['Total credit ('+DB.credit.length+' entries)',num(C)],['Total debit ('+DB.debit.length+' entries)',num(D)],['Net balance (Credit - Debit)',num(C-D)]]},secL('credit',[...DB.credit].sort((a,b)=>a.date.localeCompare(b.date))),secL('debit',[...DB.debit].sort((a,b)=>a.date.localeCompare(b.date))),secP()],'Full ledger report',`RTT-full-report-${today()}.pdf`)}

/* ---------- Android / app-builder PDF (APKX engine: HTML -> canvas -> JPEG PDF + native "Save as PDF") ---------- */
const RPCSS='.rp{font:10px/1.35 Arial,Helvetica,sans-serif;color:#1c2433}.rp h1{font-size:16px;margin:0 0 3px;color:#1c2b5e}.rp h3{font-size:12px;margin:8px 0 4px;color:#1c2b5e}.rp .sub{font-size:9px;color:#555;margin-bottom:6px}.rp table{border-collapse:collapse;width:100%;table-layout:fixed}.rp th,.rp td{border:1px solid #bbb;padding:3px 5px;font-size:9px;text-align:left;vertical-align:top;color:#000;word-wrap:break-word}.rp th{background:#1c2b5e;color:#fff;font-weight:700}.rp tr:nth-child(even) td{background:#f5f7fb}.rp .n{text-align:right;white-space:nowrap}.rp tr.tot td{font-weight:700;background:#e8edf7}';
function rptPages(secs,sub){const out=[],R=30,E=esc,hd='<h1>RAAJEESWARI TEXTIE TRADERS</h1><div class=sub>'+E(sub)+' &middot; Generated '+E(new Date().toLocaleString('en-IN'))+'</div>';
secs.forEach(s=>{const W=s.cols.reduce((a,c)=>a+c.w,0),tr=(r,c)=>'<tr'+(c?' class=tot':'')+'>'+s.cols.map((k,j)=>`<td class="${k.r?'n':''}">${E(r[j]??'')}</td>`).join('')+'</tr>';
for(let i=0;i<Math.max(s.rows.length,1);i+=R){const last=i+R>=s.rows.length;
out.push({html:'<div class="rp">'+hd+`<h3>${E(s.title)}${i?' (contd.)':''}</h3><table><colgroup>${s.cols.map(c=>`<col style="width:${(c.w/W*100).toFixed(2)}%">`).join('')}</colgroup><thead><tr>${s.cols.map(c=>`<th class="${c.r?'n':''}">${E(c.h)}</th>`).join('')}</tr></thead><tbody>${s.rows.slice(i,i+R).map(r=>tr(r)).join('')}${last&&s.tot?tr(s.tot,1):''}</tbody></table></div>`,css:RPCSS})}});return out}
async function apkPdf(secs,sub,name){const A=APKX,pages=rptPages(secs,sub);let done=A.busy('Building PDF…');
try{const r=await A.htmlToPdf(pages,{fit:'auto'});done();done=null;A.deliver(r.blob,name,{pages:r.previews,print:{fit:'one',pages}})}
catch(e){if(done)done();A.modal({title:'Report view',note:'PDF engine not available ('+esc(e&&e.message||e)+'). The report is shown below - take a screenshot to save it.',htmlView:pages.map(p=>p.html).join(''),css:RPCSS})}}
const outPdf=(secs,sub,name)=>window.APKX&&APKX.active?apkPdf(secs,sub,name):dl(pdf(secs,sub),name);

const xlBtn=()=>'';

boot();if(window.APKX)APKX.install({rootId:''});
