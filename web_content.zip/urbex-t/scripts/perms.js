const fs=require('fs'),f='android/app/src/main/AndroidManifest.xml';let s=fs.readFileSync(f,'utf8');
for(const p of['INTERNET','ACCESS_FINE_LOCATION','ACCESS_COARSE_LOCATION','ACCESS_BACKGROUND_LOCATION','FOREGROUND_SERVICE','FOREGROUND_SERVICE_LOCATION','POST_NOTIFICATIONS','BLUETOOTH_SCAN','BLUETOOTH_CONNECT','WAKE_LOCK','CAMERA'])
if(!s.includes('android.permission.'+p+'"'))s=s.replace('</manifest>',`    <uses-permission android:name="android.permission.${p}" />\n</manifest>`);
fs.writeFileSync(f,s);console.log('permissions ok');
