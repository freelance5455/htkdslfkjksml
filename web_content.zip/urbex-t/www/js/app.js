const $=s=>document.querySelector(s),U=()=>crypto.randomUUID?crypto.randomUUID():'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,c=>(Math.random()*16|0).toString(16)),
E=s=>String(s??'').replace(/[&<>"]/g,c=>'&#'+c.charCodeAt(0)+';'),now=()=>Date.now(),
fd=t=>new Date(t).toLocaleString('ru',{dateStyle:'short',timeStyle:'short'}),f2=n=>String(n|0).padStart(2,0),
dur=s=>f2(s/3600)+':'+f2(s/60%60)+':'+f2(s%60),
idb=(k,v)=>new Promise(r=>{const q=indexedDB.open('urbext',1);q.onupgradeneeded=()=>q.result.createObjectStore('s');q.onsuccess=()=>{const s=q.result.transaction('s',v===undefined?'readonly':'readwrite').objectStore('s'),x=v===undefined?s.get(k):s.put(v,k);x.onsuccess=()=>r(x.result)}}),
enc=t=>new TextEncoder().encode(t),
sha=async t=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',enc(t)))].map(b=>b.toString(16).padStart(2,0)).join(''),
hh=async(p,s)=>{const k=await crypto.subtle.importKey('raw',enc(p),'PBKDF2',0,['deriveBits']);return btoa(String.fromCharCode(...new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:enc(s),iterations:100000},k,256))))},
dist=(a,b)=>{const R=6371e3,r=Math.PI/180;return R*Math.hypot((b[1]-a[1])*r*Math.cos((a[0]+b[0])*r/2),(b[0]-a[0])*r)},
mx=(lo,z)=>(lo+180)/360*256*2**z,my=(la,z)=>{const r=la*Math.PI/180;return(1-Math.log(Math.tan(r)+1/Math.cos(r))/Math.PI)/2*256*2**z},
ilon=(x,z)=>x/(256*2**z)*360-180,ilat=(y,z)=>180/Math.PI*Math.atan(Math.sinh(Math.PI-2*Math.PI*y/(256*2**z)));
let D,M,tab='MAP',pos=null,hd=null,V={lat:57.1522,lon:65.5343,z:14,lay:'SAT',off:0,tr:null},T={},wl=null,sq='',sf='ALL',ob=null;
const TABS=[['MAP','⌖'],['OBJECTS','◧'],['FIELD','●'],['MESH','≋'],['BASE','▤'],['ARCHIVE','☰'],['PROFILE','☻']],
ST=['CONFIRMED','ASSUMPTION','UNCONFIRMED'],RL=['USER','ADMIN','RESEARCHER','EDITOR','OBSERVER','GUEST'],
RF=[['COLLAPSE',3],['HAZMAT',3],['SECURITY',2],['HEIGHT',1],['FLOOD',1]],
TR=[['BLUETOOTH','ble'],['WI-FI','wifi'],['MESHTASTIC','mesh'],['INTERNET','inet']],
rs=o=>RF.reduce((s,[n,w])=>s+(o.rk.includes(n)?w:0),0),
OB=()=>D.obj.filter(o=>!o.del),WP=()=>D.wp.filter(w=>!w.del),
save=()=>idb('db',D),sm=()=>idb('mesh',M),
mk=o=>({id:U(),createdAt:now(),updatedAt:now(),deviceId:D.meta.deviceId,version:1,...o}),
lg=(e,m)=>D.log.push(mk({eid:e.id,by:D.profile.name,m})),
tc=(e,m)=>{e.updatedAt=now();e.version++;e.deviceId=D.meta.deviceId;lg(e,m);save()},
tt=m=>{const e=$('#toast');e.textContent=m;e.style.display='block';clearTimeout(tt.t);tt.t=setTimeout(()=>e.style.display='none',2500)},
can=()=>!['OBSERVER','GUEST'].includes(D.profile.role)||(tt('READ-ONLY: '+D.profile.role),0),
two=(b,f)=>{if(b.dataset.c)return f();b.dataset.c=b.textContent;b.textContent='SURE?';setTimeout(()=>{if(b.dataset.c){b.textContent=b.dataset.c;delete b.dataset.c}},3000)},
pp=()=>pos?[pos.lat,pos.lon]:null,
shut=()=>$('#sheet').style.display='none',
open=h=>{const s=$('#sheet');s.innerHTML=h;s.style.display='block'},
rn=()=>$('#nv').innerHTML=TABS.map(([t,g])=>`<b class="${t==tab?'on':''}" onclick="go('${t}')"><span>${g}</span>${t}</b>`).join(''),
go=t=>{tab=t;sq='';shut();rn();render()},
render=()=>{const m=$('#mn');m.className=tab=='MAP'?'m':'';m.innerHTML=({MAP:vMap,OBJECTS:vObj,FIELD:vFld,MESH:vMesh,BASE:vBase,ARCHIVE:vArc,PROFILE:vProf})[tab]();if(tab=='MAP')initMap()},
hud=()=>{const f=D.fld,ok=pos&&now()-pos.t<30000;$('#hud').innerHTML=`<b>URBEX-T</b><span><i>GPS</i> ${ok?pos.lat.toFixed(5)+','+pos.lon.toFixed(5)+' ±'+(pos.acc|0)+'m':'NO FIX'}</span><span><i>HDG</i> ${hd==null?'--':hd|0}°</span><span><i>NET</i> ${navigator.onLine?'ON':'OFF'}</span>${f?`<span style=color:var(--r)>● REC ${dur((now()-f.start)/1000)}</span>`:''}`},
wake=async()=>{try{wl=await navigator.wakeLock.request('screen')}catch(e){}},
cp=(f,cb)=>{if(!f)return;const r=new FileReader();r.onload=()=>{const m=new Image();m.onload=()=>{const s=Math.min(1,720/Math.max(m.width,m.height)),c=document.createElement('canvas');c.width=m.width*s;c.height=m.height*s;c.getContext('2d').drawImage(m,0,0,c.width,c.height);cb(c.toDataURL('image/jpeg',.6))};m.src=r.result};r.readAsDataURL(f)},
dl=async(n,t)=>{if(window.nativeSave&&await window.nativeSave(n,t).catch(()=>0))return;const b=new Blob([t],{type:'application/json'}),f=new File([b],n);if(navigator.canShare&&navigator.canShare({files:[f]}))navigator.share({files:[f]}).catch(()=>{});else{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=n;a.click()}};

/* ---------- MAP ---------- */
const vMap=()=>`<div style="position:absolute;inset:0"><canvas id=cv style="width:100%;height:100%;touch-action:none;display:block"></canvas><div class=tb><button onclick="zm(1)">+</button><button onclick="zm(-1)">−</button><button onclick="ctr()">◎</button><button onclick="addAt(1)">OBJ+</button><button onclick="addAt(0)">WP+</button><button onclick="lay()">${V.lay}</button><button onclick="off()">${V.off?'OFF':'ON'}</button><button onclick="dla()">DL</button></div><div id=rd></div></div>`,
zm=d=>{V.z=Math.max(2,Math.min(19,V.z+d));draw()},
ctr=()=>{if(pos){V.lat=pos.lat;V.lon=pos.lon;draw()}else tt('NO FIX')},
addAt=o=>{if(o)return eo(null,V.lat,V.lon);if(!can())return;D.wp.push(mk({name:'WP'+(WP().length+1),lat:V.lat,lon:V.lon}));save();draw();tt('WP SET')},
initMap=()=>{const c=$('#cv');let dr=null;new ResizeObserver(()=>{const k=devicePixelRatio||1;c.width=c.clientWidth*k;c.height=c.clientHeight*k;draw()}).observe(c);
c.onpointerdown=e=>{dr={x:e.clientX,y:e.clientY,m:0};c.setPointerCapture(e.pointerId)};
c.onpointermove=e=>{if(!dr)return;const dx=e.clientX-dr.x,dy=e.clientY-dr.y,z=V.z;dr.m+=Math.abs(dx)+Math.abs(dy);dr.x=e.clientX;dr.y=e.clientY;V.lon=ilon(mx(V.lon,z)-dx,z);V.lat=ilat(my(V.lat,z)-dy,z);draw()};
c.onpointerup=e=>{if(dr&&dr.m<8)tap(e.offsetX,e.offsetY);dr=null};
c.onwheel=e=>{e.preventDefault();zm(e.deltaY<0?1:-1)}},
tap=(x,y)=>{const c=$('#cv'),w=c.clientWidth,h=c.clientHeight,z=V.z,cx=mx(V.lon,z),cy=my(V.lat,z),o=OB().find(o=>Math.hypot(w/2+mx(o.lon,z)-cx-x,h/2+my(o.lat,z)-cy-y)<16);if(o)eo(o.id)},
draw=()=>{const c=$('#cv');if(!c||!c.width)return;const g=c.getContext('2d'),w=c.clientWidth,h=c.clientHeight,z=V.z,cx=mx(V.lon,z),cy=my(V.lat,z),PI=Math.PI;
g.setTransform(c.width/w,0,0,c.width/w,0,0);g.shadowBlur=0;g.fillStyle='#0f1412';g.fillRect(0,0,w,h);g.font='11px system-ui';
const S=(la,lo)=>[w/2+mx(lo,z)-cx,h/2+my(la,z)-cy];
if(V.lay!='GRID'){const n=2**z;for(const L of V.lay=='HYB'?['sat','lab']:V.lay=='OSM'?['osm']:['sat'])for(let x=Math.floor((cx-w/2)/256);x<=Math.floor((cx+w/2)/256);x++)for(let y=Math.floor((cy-h/2)/256);y<=Math.floor((cy+h/2)/256);y++){if(y<0||y>=n)continue;const i=tile(L,z,((x%n)+n)%n,y);if(i)g.drawImage(i,w/2+x*256-cx,h/2+y*256-cy)}}
g.strokeStyle=V.lay=='GRID'?'#1a231e':'#0000';g.lineWidth=1;for(let x=(w/2-cx)%64;x<w;x+=64){g.beginPath();g.moveTo(x,0);g.lineTo(x,h);g.stroke()}for(let y=(h/2-cy)%64;y<h;y+=64){g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke()}
const tr=(p,col)=>{if(p.length<2)return;g.strokeStyle=col;g.lineWidth=2;g.beginPath();p.forEach((q,i)=>{const[a,b]=S(q[0],q[1]);i?g.lineTo(a,b):g.moveTo(a,b)});g.stroke()};
D.exp.forEach(e=>tr(e.track,V.tr==e.id?'#ffb84d':'#3b4d43'));if(D.fld)tr(D.fld.track,'#ff6b5a');
g.shadowColor='#000';g.shadowBlur=4;WP().forEach(p=>{const[a,b]=S(p.lat,p.lon);g.fillStyle='#ffb84d';g.beginPath();g.moveTo(a,b-6);g.lineTo(a+5,b+4);g.lineTo(a-5,b+4);g.fill();g.fillText(p.name,a+8,b)});
OB().forEach(o=>{const[a,b]=S(o.lat,o.lon);g.strokeStyle=g.fillStyle=o.st=='CONFIRMED'?'#6ee7a0':o.st=='ASSUMPTION'?'#ffb84d':'#ff6b5a';g.lineWidth=1;g.strokeRect(a-6,b-6,12,12);g.fillRect(a-2,b-2,4,4);g.fillText(o.name,a+9,b+3)});
const mpp=156543.03*Math.cos(V.lat*PI/180)/2**z;
if(pos){const[a,b]=S(pos.lat,pos.lon);g.strokeStyle='#4af';g.fillStyle='#44aaff33';g.lineWidth=1;g.beginPath();g.arc(a,b,Math.max(pos.acc/mpp,6),0,7);g.fill();g.stroke();g.save();g.translate(a,b);g.rotate((hd||0)*PI/180);g.fillStyle='#4af';g.beginPath();g.moveTo(0,-10);g.lineTo(5,4);g.lineTo(-5,4);g.fill();g.restore()}
g.strokeStyle='#ffb84d';g.beginPath();g.moveTo(w/2-8,h/2);g.lineTo(w/2+8,h/2);g.moveTo(w/2,h/2-8);g.lineTo(w/2,h/2+8);g.stroke();
g.save();g.translate(w-28,28);g.strokeStyle='#8a9890';g.beginPath();g.arc(0,0,18,0,7);g.stroke();g.rotate(-(hd||0)*PI/180);g.fillStyle='#ff6b5a';g.beginPath();g.moveTo(0,-15);g.lineTo(4,0);g.lineTo(-4,0);g.fill();g.fillStyle='#ffb84d';g.fillText('N',-3,-21);g.restore();
const n=[1,2,5,10,20,50,100,200,500,1e3,2e3,5e3,1e4,2e4,5e4,1e5,2e5,5e5,1e6,2e6,5e6].find(v=>v/mpp>=60),L=n/mpp;g.strokeStyle=g.fillStyle='#ffb84d';g.beginPath();g.moveTo(w-L-8,h-14);g.lineTo(w-8,h-14);g.stroke();g.fillText(n>=1e3?n/1e3+' km':n+' m',w-L-8,h-18);
$('#rd').textContent=V.lat.toFixed(5)+', '+V.lon.toFixed(5)+'  Z'+z+' '+V.lay+(V.off?' OFFLINE':'')};

let tn=0;const LY=['GRID','SAT','HYB','OSM'],
SRC={sat:(z,x,y)=>`https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`,lab:(z,x,y)=>`https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/${z}/${y}/${x}`,osm:(z,x,y)=>`https://tile.openstreetmap.org/${z}/${x}/${y}.png`},
tdb=new Promise(r=>{const q=indexedDB.open('urbext-tiles',1);q.onupgradeneeded=()=>q.result.createObjectStore('t');q.onsuccess=()=>r(q.result)}),
tkGet=k=>tdb.then(d=>new Promise(r=>{const x=d.transaction('t').objectStore('t').get(k);x.onsuccess=()=>r(x.result);x.onerror=()=>r()})),
tkPut=(k,v)=>tdb.then(d=>new Promise(r=>{const x=d.transaction('t','readwrite').objectStore('t').put(v,k);x.onsuccess=x.onerror=()=>r()})),
tile=(L,z,x,y)=>{const k=L+'/'+z+'/'+x+'/'+y;let e=T[k];if(e)return e.ok?e.i:null;if(++tn>600){T={};tn=0}e=T[k]={i:new Image()};e.i.onload=()=>{e.ok=1;draw()};tkGet(k).then(async b=>{if(b)return void(e.i.src=URL.createObjectURL(b));if(V.off||!navigator.onLine)return void(e.miss=1);try{const r=await fetch(SRC[L](z,x,y));if(!r.ok)throw 0;b=await r.blob();tkPut(k,b);e.i.src=URL.createObjectURL(b)}catch(_){e.i.src=SRC[L](z,x,y)}});return null},
lay=()=>{V.lay=LY[(LY.indexOf(V.lay)+1)%4];render()},
off=()=>{V.off=!V.off;for(const k in T)if(T[k].miss)delete T[k];render()},
dla=async()=>{if(V.off||!navigator.onLine)return tt('GO ONLINE (ON)');const ls=V.lay=='HYB'?['sat','lab']:V.lay=='SAT'?['sat']:[];if(!ls.length)return tt('SWITCH TO SAT / HYB');const c=$('#cv'),w=c.clientWidth,h=c.clientHeight,q=[];for(let z=V.z;z<=Math.min(18,V.z+3);z++){const cx=mx(V.lon,z),cy=my(V.lat,z);for(let x=Math.floor((cx-w/2)/256);x<=Math.floor((cx+w/2)/256);x++)for(let y=Math.floor((cy-h/2)/256);y<=Math.floor((cy+h/2)/256);y++)for(const L of ls)q.push([L,z,x,y])}if(q.length>800)return tt('AREA TOO BIG: ZOOM IN');tt('DOWNLOADING '+q.length);let n=0;for(const[L,z,x,y]of q){const k=L+'/'+z+'/'+x+'/'+y;if(await tkGet(k))continue;try{const r=await fetch(SRC[L](z,x,y));if(r.ok){await tkPut(k,await r.blob());n++}}catch(_){}}tt('CACHED +'+n)};
/* ---------- OBJECTS ---------- */
const vObj=()=>`<div class=row><input id=q placeholder="SEARCH" value="${E(sq)}" oninput="sq=this.value;$('#ls').innerHTML=objL()"><button style="flex:0 0 auto" onclick="eo()">+ NEW</button></div><div id=ls>${objL()}</div>`,
objL=()=>OB().filter(o=>(o.name+o.desc+o.notes+o.src).toLowerCase().includes(sq.toLowerCase())).sort((a,b)=>b.updatedAt-a.updatedAt).map(o=>`<div class=c onclick="eo('${o.id}')"><b>${E(o.name)}</b> <span class="b ${o.st}">${o.st}</span> <span class=b style="color:${rs(o)>5?'var(--r)':'var(--a)'}">RISK ${rs(o)}</span><br><small>${o.lat.toFixed(5)}, ${o.lon.toFixed(5)} · ${E(o.found)} · ${o.ph.length} PH</small></div>`).join('')||'<p class=d>EMPTY</p>',
eo=(id,la,lo)=>{ob=id?D.obj.find(o=>o.id==id):{name:'',lat:la??pos?.lat??V.lat,lon:lo??pos?.lon??V.lon,desc:'',notes:'',src:'',st:'UNCONFIRMED',rk:[],ph:[],found:new Date().toISOString().slice(0,10),by:D.profile.name,_new:1};of_()},
of_=()=>open(`<h3>${ob._new?'NEW OBJECT':'OBJECT '+ob.id.slice(0,8)}</h3><label>NAME</label><input id=on value="${E(ob.name)}">
<div class=row><div><label>LAT</label><input id=oa type=number step=any value=${ob.lat}></div><div><label>LON</label><input id=oo type=number step=any value=${ob.lon}></div></div><button onclick="og()">⌖ GPS</button>
<label>DESCRIPTION</label><textarea id=od rows=3>${E(ob.desc)}</textarea><label>NOTES</label><textarea id=oz rows=3>${E(ob.notes)}</textarea><label>SOURCE</label><input id=os value="${E(ob.src)}">
<div class=row><div><label>STATUS</label><select id=ot>${ST.map(s=>`<option ${s==ob.st?'selected':''}>${s}</option>`).join('')}</select></div><div><label>FOUND</label><input id=ofd type=date value=${ob.found}></div></div>
<label>RISK SCORE ${rs(ob)}/10</label>${RF.map(([n])=>`<label style="display:inline-block;margin-right:8px"><input type=checkbox style=width:auto class=rk value=${n} ${ob.rk.includes(n)?'checked':''}> ${n}</label>`).join('')}
<div>${ob.ph.map((p,i)=>`<img class=ph src="${p}" onclick="dp(${i})">`).join('')}</div>
<input type=file id=pf accept="image/*" capture=environment style=display:none onchange="ap(this)"><button onclick="$('#pf').click()">+ PHOTO</button><br>
<button onclick="sv()">SAVE</button><button onclick="shut()">CLOSE</button>${ob._new?'':`<button style=color:var(--r) onclick="dob(this)">DEL</button><h3>HISTORY · v${ob.version} · ${E(ob.by)}</h3><pre>${D.log.filter(l=>l.eid==ob.id).map(l=>fd(l.createdAt)+' '+E(l.by)+': '+E(l.m)).join('\n')}</pre>`}`),
fv=()=>{const v=i=>$('#'+i).value;ob.name=v('on');ob.lat=+v('oa');ob.lon=+v('oo');ob.desc=v('od');ob.notes=v('oz');ob.src=v('os');ob.st=v('ot');ob.found=v('ofd');ob.rk=[...document.querySelectorAll('.rk:checked')].map(x=>x.value)},
og=()=>{if(!pos)return tt('NO FIX');fv();ob.lat=pos.lat;ob.lon=pos.lon;of_()},
ap=i=>can()&&(fv(),cp(i.files[0],d=>{ob.ph.push(d);if(!ob._new)tc(ob,'photo added');of_()})),
dp=i=>{if(!can())return;if(dp.i!=i){dp.i=i;return tt('TAP AGAIN TO DELETE')}fv();ob.ph.splice(i,1);dp.i=-1;if(!ob._new)tc(ob,'photo removed');of_()},
sv=()=>{if(!can())return;fv();if(!ob.name.trim())return tt('NAME?');if(ob._new){delete ob._new;const o=mk(ob);D.obj.push(o);lg(o,'created');ob=o;save()}else tc(ob,'edited');shut();render()},
dob=b=>two(b,()=>{if(!['ADMIN','EDITOR'].includes(D.profile.role))return tt('ADMIN/EDITOR ONLY');ob.del=1;tc(ob,'deleted');shut();render()});

/* ---------- FIELD ---------- */
const evH=e=>`<div class=c style=cursor:default><small>${fd(e.t)} ${e.k}${e.p?' '+e.p[0].toFixed(4)+','+e.p[1].toFixed(4):''}</small><br>${E(e.x)}${e.ph?`<br><img class=ph src="${e.ph}">`:''}</div>`,
wpL=()=>`<h3>WAYPOINTS</h3>${WP().map(w=>`<div class=c style=cursor:default>▲ ${E(w.name)} <small>${w.lat.toFixed(5)},${w.lon.toFixed(5)}</small><button style="float:right;margin:0" onclick="wd('${w.id}')">×</button></div>`).join('')||'<p class=d>-</p>'}`,
wd=id=>{if(!can())return;const w=D.wp.find(w=>w.id==id);w.del=1;tc(w,'deleted');render()},
vFld=()=>{const f=D.fld;if(!f)return`<h3>FIELD MODE</h3><input id=fn placeholder="EXPEDITION NAME"><button onclick="fs()">▶ START</button><p class=d>GPS TRACK · JOURNAL · FINDS · PHOTO → ARCHIVE</p>`+wpL();
return`<h3>● ${E(f.name)}</h3><div class=c style=cursor:default>T ${dur((now()-f.start)/1000)} · ${(f.dist/1000).toFixed(2)} KM · PTS ${f.track.length} · EV ${f.ev.length}</div><input id=ft placeholder="TEXT"><div class=row><button onclick="fe('NOTE')">NOTE</button><button onclick="fe('FIND')">FIND</button><button onclick="fe('EVENT')">EVENT</button><button onclick="fe('WP')">WP</button></div><input type=file id=fp accept="image/*" capture=environment style=display:none onchange="fph(this)"><button onclick="$('#fp').click()">PHOTO</button><select id=fsel onchange="fvs(this)"><option value=''>VISIT OBJECT…</option>${OB().map(o=>`<option value=${o.id}>${E(o.name)}</option>`).join('')}</select><button style=color:var(--r) onclick="fq(this)">■ STOP</button><h3>JOURNAL</h3>${f.ev.slice().reverse().map(evH).join('')||'<p class=d>-</p>'}`},
fs=()=>{if(!can())return;window.nativeGps?.start();D.fld={id:U(),name:$('#fn').value||'EXP '+fd(now()),start:now(),track:[],ev:[],dist:0};if(pos)D.fld.track.push([pos.lat,pos.lon,now()]);save();wake();render()},
fe=k=>{if(!can())return;const x=$('#ft').value.trim();if(k=='WP'){if(!pos)return tt('NO FIX');D.wp.push(mk({name:x||'WP'+(WP().length+1),lat:pos.lat,lon:pos.lon}))}else if(!x)return tt('TEXT?');D.fld.ev.push({t:now(),k,x,p:pp()});save();render()},
fph=i=>can()&&cp(i.files[0],d=>{D.fld.ev.push({t:now(),k:'PHOTO',x:$('#ft')?.value||'',p:pp(),ph:d});save();render()}),
fvs=s=>{if(!s.value||!can())return;const o=D.obj.find(o=>o.id==s.value);D.fld.ev.push({t:now(),k:'VISIT',x:o.name,p:pp(),oid:o.id});save();render()},
fq=b=>two(b,()=>{const f=D.fld;f.end=now();f.dist=Math.round(f.dist);const e=mk(f);D.exp.push(e);lg(e,'expedition archived');D.fld=null;save();wl?.release();window.nativeGps?.stop();render();tt('ARCHIVED')});

/* ---------- MESH (separate from UrbexDB) ---------- */
const up=k=>!!window.UrbexBridge?.up?.(k),
vMesh=()=>`<h3>COMMUNICATION TRANSPORT</h3>${TR.map(([n,k])=>`<span class=b style="color:${up(k)?'var(--g)':'var(--r)'}">${n} ${up(k)?'UP':'DOWN'}</span> `).join('')}<button onclick="window.UrbexBridge?.connect?.().then(()=>render()).catch(e=>tt('BLE: '+(e.message||e)))">⚡ CONNECT MESHTASTIC (BLE)</button><select id=mt>${TR.map(([n,k])=>`<option value=${k} ${k=='mesh'?'selected':''}>${n}</option>`).join('')}</select><input id=mx placeholder="MESSAGE"><div class=row><button onclick="ms('TEXT')">TEXT</button><button onclick="ms('POS')">POS</button><button onclick="ms('WARN')">WARN</button><button style=color:var(--r) onclick="ms('SOS')">SOS</button></div>
<h3>OUTBOX</h3>${M.out.slice(-12).reverse().map(m=>`<div class=c style=cursor:default><small>${fd(m.t)} ${m.k} → ${m.tr} [${m.st}]</small><br>${E(m.x)}</div>`).join('')||'<p class=d>-</p>'}
<h3>INBOX</h3>${M.inb.slice(-12).reverse().map(m=>`<div class=c style=cursor:default><small>${fd(m.rt)} ${E(m.k)} ← ${E(m.from)}</small><br>${E(m.x)}</div>`).join('')||'<p class=d>-</p>'}
<h3>TEAM</h3>${D.team.map(t=>`<div class=c style=cursor:default><b>${E(t.name)}</b> <small>${t.p?t.p.map(v=>(+v).toFixed(4)):'no pos'}${t.seen?' · '+fd(t.seen):''}</small><button style="float:right;margin:0" onclick="tg('${t.id}')">${t.status}</button></div>`).join('')}<div class=row><input id=tn placeholder="MEMBER"><button style="flex:0 0 auto" onclick="ta()">ADD</button></div>`,
fl=()=>{let c=0;if(window.UrbexBridge?.send)for(const m of M.out)if(m.st=='QUEUED'&&UrbexBridge.send(m.tr,JSON.stringify(m))){m.st='SENT';c=1}c&&sm()},
ms=k=>{if(!can())return;let x=$('#mx').value;if(k=='POS'||k=='SOS'){if(!pos)return tt('NO FIX');x=(x?x+' ':'')+pos.lat.toFixed(5)+','+pos.lon.toFixed(5)}else if(!x)return tt('TEXT?');M.out.push({id:U(),t:now(),k,x,tr:$('#mt').value,from:D.profile.name,p:pp(),st:'QUEUED'});fl();sm();if(k=='SOS'&&navigator.share)navigator.share({text:'SOS '+x}).catch(()=>{});render()},
ta=()=>{const n=$('#tn').value.trim();if(!n||!can())return;D.team.push(mk({name:n,status:'OK',p:null}));save();render()},
tg=id=>{if(!can())return;const t=D.team.find(t=>t.id==id),s=['OK','HELP','LOST','OUT'];t.status=s[(s.indexOf(t.status)+1)%4];tc(t,'status '+t.status);render()};
window.onMeshRx=j=>{const m=typeof j=='string'?JSON.parse(j):j;M.inb.push({...m,rt:now()});if(m.k=='POS'&&m.p){const t=D.team.find(t=>t.name==m.from);if(t){t.p=m.p;t.seen=now();save()}}sm();if(tab=='MESH')render()};

/* ---------- BASE / sync ---------- */
const K=['obj','exp','wp','log','team'],
vBase=()=>`<h3>URBEXDB</h3><div class=c style=cursor:default>DEVICE ${D.meta.deviceId.slice(0,8)}<br>OBJ ${OB().length} · EXP ${D.exp.length} · WP ${WP().length} · LOG ${D.log.length} · CONFLICTS ${D.conf.length}<br>LAST EXPORT ${D.meta.lastExport?fd(D.meta.lastExport):'—'}</div><button onclick="ex(0)">EXPORT .urbexdb</button><button onclick="ex(1)">EXPORT Δ</button><input type=file id=imf accept=".urbexdb,.json" style=display:none onchange="im(this)"><button onclick="$('#imf').click()">IMPORT / MERGE</button><button onclick="ck()">CHECK</button><pre id=ck></pre><p class=d>Δ files = delta sync (USB / SSD / share / LAN transport). Merge never overwrites blindly: on conflict the older copy is kept in CONFLICTS.</p>`,
ex=async d=>{const s=d?D.meta.lastExport:0,data={};K.forEach(k=>data[k]=D[k].filter(e=>e.updatedAt>s));const j=JSON.stringify(data);dl(`Urbex_Main${d?'_delta':''}.urbexdb`,JSON.stringify({fmt:'urbexdb',v:1,dev:D.meta.deviceId,t:now(),since:s,sum:await sha(j),data}));D.meta.lastExport=now();save();render()},
mg=(a,b,r)=>{const ls=D.meta.lastSync||0;for(const x of b){const y=a.find(y=>y.id==x.id);if(!y){a.push(x);r[0]++;continue}if(x.version==y.version&&x.updatedAt==y.updatedAt)continue;const xw=x.updatedAt>y.updatedAt;if(x.updatedAt>ls&&y.updatedAt>ls&&x.deviceId!=y.deviceId){D.conf.push({id:U(),t:now(),eid:x.id,lose:xw?y:x});r[2]++}if(xw){a[a.indexOf(y)]=x;r[1]++}}},
im=async i=>{if(!can())return;try{const o=JSON.parse(await i.files[0].text());if(o.fmt!='urbexdb')throw'BAD FORMAT';if(o.sum!=await sha(JSON.stringify(o.data)))throw'CHECKSUM FAIL';const r=[0,0,0];K.forEach(k=>mg(D[k],o.data[k]||[],r));D.meta.lastSync=now();save();render();tt(`MERGED +${r[0]} ~${r[1]} ⚠${r[2]}`)}catch(e){tt('IMPORT: '+(e.message||e))}},
ck=()=>{const o=[],ids=new Set;K.forEach(k=>D[k].forEach(e=>{['id','createdAt','updatedAt','deviceId','version'].forEach(f=>e[f]==null&&o.push(k+' '+(e.id||'?')+' no '+f));if(ids.has(e.id))o.push('DUP '+e.id);ids.add(e.id)}));D.log.forEach(l=>ids.has(l.eid)||o.push('ORPHAN LOG '+l.id.slice(0,8)));$('#ck').textContent=o.length?o.join('\n'):'INTEGRITY OK · '+ids.size+' ENTITIES'};

/* ---------- ARCHIVE ---------- */
const vArc=()=>`<input id=q placeholder="SEARCH ALL" value="${E(sq)}" oninput="sq=this.value;$('#ls').innerHTML=arL()"><div class=row>${['ALL','OBJ','EXP','FIND','NOTE'].map(f=>`<button style="${f==sf?'background:var(--a);color:#000':''}" onclick="sf='${f}';render()">${f}</button>`).join('')}</div><div id=ls>${arL()}</div>`,
arL=()=>{const q=sq.toLowerCase(),r=[],m=s=>s.toLowerCase().includes(q);
if(['ALL','OBJ'].includes(sf))OB().forEach(o=>m(o.name+o.desc+o.notes+o.src)&&r.push([o.updatedAt,`<div class=c onclick="eo('${o.id}')">◧ <b>${E(o.name)}</b> <span class="b ${o.st}">${o.st}</span><br><small>RISK ${rs(o)} · v${o.version}</small></div>`]));
D.exp.forEach(e=>{if(['ALL','EXP'].includes(sf)&&m(e.name))r.push([e.end,`<div class=c onclick="ve('${e.id}')">● <b>${E(e.name)}</b><br><small>${fd(e.start)} · ${(e.dist/1000).toFixed(2)} KM · ${e.ev.length} EV</small></div>`]);e.ev.forEach(v=>{if((sf==v.k||sf=='ALL'&&['FIND','NOTE'].includes(v.k))&&m(v.x))r.push([v.t,`<div class=c onclick="ve('${e.id}')"><small>${v.k} · ${E(e.name)} · ${fd(v.t)}</small><br>${E(v.x)}</div>`])})});
return r.sort((a,b)=>b[0]-a[0]).map(x=>x[1]).join('')||'<p class=d>EMPTY</p>'},
ve=id=>{const e=D.exp.find(e=>e.id==id);open(`<h3>${E(e.name)}</h3><div class=c style=cursor:default>${fd(e.start)} → ${fd(e.end)}<br>DUR ${dur((e.end-e.start)/1000)} · ${(e.dist/1000).toFixed(2)} KM · PTS ${e.track.length}</div><button onclick="V.tr='${e.id}';const p=${JSON.stringify(e.track[0]||null)};if(p){V.lat=p[0];V.lon=p[1];V.z=15}go('MAP')">SHOW ON MAP</button><button onclick="shut()">CLOSE</button><h3>JOURNAL</h3>${e.ev.map(evH).join('')}`)};

/* ---------- PROFILE ---------- */
const vProf=()=>{const p=D.profile;return`<h3>PROFILE</h3><div class=c style=cursor:default>LOCAL ID ${p.id}</div><label>USERNAME</label><input id=pu value="${E(p.user)}"><label>DISPLAY NAME</label><input id=pn value="${E(p.name)}"><label>ROLE</label><select id=pr>${RL.map(r=>`<option ${r==p.role?'selected':''}>${r}</option>`).join('')}</select><button onclick="ps()">SAVE</button><h3>PIN (PBKDF2)</h3><input id=pw type=password inputmode=numeric placeholder="${p.pin?'NEW PIN / EMPTY = REMOVE':'NEW PIN'}"><button onclick="pk()">${p.pin?'CHANGE / REMOVE':'SET PIN'}</button>${p.pin?'<button onclick="location.reload()">LOCK</button>':''}<p class=d>OBSERVER / GUEST: read-only · delete: ADMIN / EDITOR</p>`},
ps=()=>{const p=D.profile;p.user=$('#pu').value;p.name=$('#pn').value;p.role=$('#pr').value;save();tt('SAVED');hud()},
pk=async()=>{const v=$('#pw').value,p=D.profile;if(!v){p.pin=p.salt='';save();tt('PIN REMOVED');return render()}if(v.length<4)return tt('MIN 4 DIGITS');p.salt=U();p.pin=await hh(v,p.salt);save();tt('PIN SET');render()},
lock=()=>{const d=document.createElement('div');d.id='lk';d.innerHTML='<h3>URBEX-T PDA // AUTH</h3><input id=lp type=password inputmode=numeric placeholder=PIN><button id=lb>UNLOCK</button>';document.body.append(d);$('#lb').onclick=async()=>{if(await hh($('#lp').value,D.profile.salt)==D.profile.pin){d.remove();render()}else{tt('DENIED');$('#lp').value=''}}};

/* ---------- BOOT ---------- */
(async()=>{
D=await idb('db')||{meta:{deviceId:U(),lastExport:0,lastSync:0},profile:{id:U(),user:'stalker',name:'Stalker',role:'ADMIN',pin:'',salt:''},obj:[],exp:[],wp:[],log:[],team:[],conf:[]};
M=await idb('mesh')||{out:[],inb:[]};
if(!D.meta.seeded){for(const[n,la,lo,d,rk]of[['Мост Влюблённых',57.1588,65.5436,'Пешеходный мост через Туру, символ города.',[]],['Знаменский собор',57.1538,65.5329,'Кафедральный собор в историческом центре.',[]],['Свято-Троицкий монастырь',57.1547,65.5268,'Исторический монастырь в центре города.',[]],['Цветной бульвар',57.1548,65.5385,'Пешеходный бульвар в центре.',[]],['ЖД вокзал Тюмень',57.1555,65.5287,'Транспортный узел, пути и платформы.',['SECURITY']],['Набережная Туры',57.155,65.54,'Набережная реки Туры, спуски к воде.',['FLOOD']]]){const o=mk({name:n,lat:la,lon:lo,desc:d,notes:'',src:'SEED · Тюмень, координаты ±300 м, проверить в поле',st:'UNCONFIRMED',rk,ph:[],found:'2026-10-07',by:'SEED'});D.obj.push(o);lg(o,'seed')}D.meta.seeded=1;await save()}
rn();hud();setInterval(()=>{hud();fl()},1000);if(D.fld){wake();window.nativeGps?.start()}D.profile.pin?lock():render();
window.gpsCb=p=>{pos={lat:p.coords.latitude,lon:p.coords.longitude,acc:p.coords.accuracy,t:now()};const f=D.fld;if(f){const l=f.track[f.track.length-1],q=[pos.lat,pos.lon];if(!l||dist(l,q)>4){f.dist+=l?dist(l,q):0;f.track.push([pos.lat,pos.lon,now()]);if(f.track.length%10==0)save()}}if(tab=='MAP')draw()};navigator.geolocation?.watchPosition(window.gpsCb,()=>{},{enableHighAccuracy:true,maximumAge:2000});
const oh=e=>{const h=e.webkitCompassHeading??(e.alpha!=null&&(e.absolute||e.type=='deviceorientationabsolute')?(360-e.alpha)%360:null);if(h!=null&&!isNaN(h))hd=h};
addEventListener('deviceorientationabsolute',oh);addEventListener('deviceorientation',oh);
})();
