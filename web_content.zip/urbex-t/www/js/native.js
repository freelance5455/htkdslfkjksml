(()=>{const C=window.Capacitor;if(!C||!C.isNativePlatform||!C.isNativePlatform())return;const P=C.Plugins;
window.nativeSave=async(n,t)=>{const r=await P.Filesystem.writeFile({path:n,data:t,directory:'DOCUMENTS',encoding:'utf8'});await P.Share.share({title:n,url:r.uri});return 1};
/* background GPS (foreground service) */
let wid=null;const BG=P.BackgroundGeolocation;
window.nativeGps={async start(){if(!BG||wid)return;wid=await BG.addWatcher({backgroundTitle:'URBEX-T REC',backgroundMessage:'GPS track recording',requestPermissions:true,stale:false,distanceFilter:3},l=>{if(l)window.gpsCb({coords:{latitude:l.latitude,longitude:l.longitude,accuracy:l.accuracy}})})},async stop(){if(wid){await BG.removeWatcher({id:wid});wid=null}}};
/* Meshtastic over BLE (minimal protobuf) */
const BL=P.BluetoothLe,SV='6ba1b218-15a8-461f-9fa8-5dcae273eafd',TO='f75c76d2-129e-4dad-a1dd-7866124401e7',FR='2c55e69e-4993-11ed-b878-0242ac120002',FN='ed9da18c-a800-4f66-a670-aa7547e34453';
const hx=u=>[...u].map(b=>b.toString(16).padStart(2,'0')).join(''),ux=h=>Uint8Array.from(h.match(/../g)||[],b=>parseInt(b,16)),
vi=n=>{const o=[];while(n>127){o.push(n&127|128);n>>>=7}o.push(n);return o},ld=(t,b)=>[t,...vi(b.length),...b],
enc=t=>{const p=[...new TextEncoder().encode(t.slice(0,200))],d=[8,1,...ld(18,p)],id=[...crypto.getRandomValues(new Uint8Array(4))];return Uint8Array.from(ld(10,[0x15,255,255,255,255,...ld(0x22,d),0x35,...id,0x50,1]))},
i32=b=>new DataView(b.buffer,b.byteOffset,4).getInt32(0,true),u32=b=>new DataView(b.buffer,b.byteOffset,4).getUint32(0,true),
rd=u=>{const o=[];let i=0;while(i<u.length){const t=u[i++],w=t&7;let v,b,s=0;if(w==0){v=0;do{b=u[i++];v+=(b&127)*2**s;s+=7}while(b&128)}else if(w==2){let n=0;do{b=u[i++];n+=(b&127)<<s;s+=7}while(b&128);v=u.slice(i,i+n);i+=n}else if(w==5){v=u.slice(i,i+4);i+=4}else if(w==1){v=u.slice(i,i+8);i+=8}else break;o.push([t>>3,v])}return o},
pk=u=>{const fr=rd(u).find(x=>x[0]==2);if(!fr)return;const mp=rd(fr[1]),fm=mp.find(x=>x[0]==1),dc=mp.find(x=>x[0]==4);if(!dc)return;const d=rd(dc[1]),pn=d.find(x=>x[0]==1)?.[1],pl=d.find(x=>x[0]==2)?.[1];if(!pl)return;const from='!'+(fm?u32(fm[1]).toString(16):'?');if(pn==1)window.onMeshRx({k:'TEXT',from,x:new TextDecoder().decode(pl)});if(pn==3){const q=rd(pl),a=q.find(x=>x[0]==1),b=q.find(x=>x[0]==2);if(a&&b)window.onMeshRx({k:'POS',from,x:'node position',p:[i32(a[1])/1e7,i32(b[1])/1e7]})}};
let dev=null;
const drain=async()=>{for(let i=0;i<64;i++){const r=await BL.read({deviceId:dev,service:SV,characteristic:FR});if(!r.value)break;pk(ux(r.value))}};
window.UrbexBridge={up:k=>(k=='ble'||k=='mesh')&&!!dev,
async connect(){if(!BL)throw'NO BLE PLUGIN';await BL.initialize();const d=await BL.requestDevice({services:[SV]});await BL.connect({deviceId:d.deviceId});dev=d.deviceId;await BL.addListener('disconnected|'+dev,()=>{dev=null});await BL.startNotifications({deviceId:dev,service:SV,characteristic:FN});await BL.addListener(`notification|${dev}|${SV}|${FN}`,drain);await BL.write({deviceId:dev,service:SV,characteristic:TO,value:hx([0x18,...vi(1+(Math.random()*1e6|0))])});await drain()},
send(k,j){if(!dev)return false;const m=JSON.parse(j);BL.write({deviceId:dev,service:SV,characteristic:TO,value:hx(enc(m.k=='TEXT'?m.from+': '+m.x:'['+m.k+'] '+m.x))}).catch(()=>{});return true}};
})();
