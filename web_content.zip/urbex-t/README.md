# Urbex-T — Capacitor-проект

Нужны: Node.js (актуальный LTS) и Android Studio.

```
npm install @capacitor/core @capacitor/cli @capacitor/android @capacitor/geolocation @capacitor/camera @capacitor/filesystem @capacitor/share @capacitor-community/background-geolocation @capacitor-community/bluetooth-le
npx cap add android
node scripts/perms.js
npx cap sync
npx cap open android
```
Android Studio: Build → Build APK(s), либо `cd android && ./gradlew assembleDebug`.
После правок в `www/`: `npx cap sync`.

## Карта
Кнопки слева: слой (GRID / SAT / HYB / OSM), ON/OFF (онлайн/офлайн), DL (скачать видимую область на 4 уровня зума).
Тайлы кэшируются в IndexedDB автоматически при просмотре онлайн; в режиме OFF берутся только из кэша.
Спутник — Esri World Imagery (+ подписи в HYB). Проверьте условия провайдера на офлайн-кэш; для своего сервера замените SRC в `www/js/app.js`.

## Нативное (`www/js/native.js`)
- фоновый GPS-трек — foreground service при старте Field Mode
- Meshtastic по BLE — MESH → CONNECT; текст/POS/SOS уходят в радио, входящие текст и позиции попадают в INBOX (не проверено на железе)
- экспорт .urbexdb → Documents + Share

Объекты Тюмени (SEED) — ориентиры с приблизительными координатами (±300 м), статус UNCONFIRMED.
