SHIVSHAKTI AUTO — PRIVATE OFFLINE ANDROID PROJECT

PRIVACY / SECURITY SETTINGS INCLUDED
- No INTERNET permission is declared; the app cannot make ordinary network requests.
- The inventory HTML is bundled in app/src/main/assets/index.html; it does not depend on Netlify.
- WebView navigation to websites or other URL schemes is blocked.
- Android app backup/device-transfer backup is disabled.
- WebView remote debugging is disabled.
- Android FLAG_SECURE blocks ordinary screenshots and recent-app previews.
- App data is stored in the Android app's private sandbox via WebView localStorage.
- No GitHub workflow is included; do not upload this private project to a public repository.

IMPORTANT LIMITS
- This project has not yet been compiled or security-audited as an APK. Build and test it before using real shop data.
- LocalStorage data is not separately encrypted by this project. Android sandboxing protects it from ordinary other apps on a non-rooted, up-to-date phone, but it is not protection against a compromised/rooted phone, malicious accessibility/overlay apps, or someone who can unlock your phone. Use a strong screen lock.
- The app blocks screenshots, so screenshots of the inventory screen will be black/blocked on many Android devices.
- Use the app's manual Download Data Backup feature to make a backup. Keep backup files private; they contain your inventory and sales data. Do not uninstall/clear app data unless you have a backup.

PROJECT CONTENTS
- app/src/main/assets/index.html: offline inventory website
- app/src/main/java/.../MainActivity.java: hardened local-only WebView wrapper

BUILD
Open this extracted project in a compatible Android Gradle build environment and build the debug APK. No GitHub upload is required. The build environment may need internet once to download Gradle/Android dependencies; the installed app itself is designed to work offline.
