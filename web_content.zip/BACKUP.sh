#!/usr/bin/env bash
set -euo pipefail
mkdir -p backups
STAMP=$(date +%Y%m%d-%H%M%S)
docker run --rm -v alichat_data:/data -v "$PWD/backups":/backup alpine sh -c "tar czf /backup/alichat-$STAMP.tgz -C /data ."
echo "Backup: backups/alichat-$STAMP.tgz"
