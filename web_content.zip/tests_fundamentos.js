// Pruebas del Bloque 1 (paquetes A, B y C): guardado seguro, exportar/importar, service worker, build, errores y resumen de partida.
// Ejecutar: node tests_fundamentos.js
const fs=require('fs'),vm=require('vm'),cp=require('child_process'),path=require('path');
const h=fs.readFileSync(__dirname+'/index.html','utf8'),sc=[...h.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
let ok=0,bad=0;const T=(n,c)=>{c?ok++:(bad++,console.log('FALLA',n))};
const mk=()=>{const o={style:{},classList:{toggle(){},add(){},remove(){}},children:[],innerHTML:'',textContent:'',value:'',dataset:{},
 appendChild(c){this.children.push(c)},querySelector:()=>mk(),querySelectorAll:()=>[],getContext:()=>new Proxy({},{get:(t,k)=>k==='measureText'?()=>({width:10}):()=>{},set:()=>true}),addEventListener(){},setAttribute(){},select(){},getBoundingClientRect:()=>({left:0,top:0,width:100,height:100})};return o};
let els,store,vp,throwSet;
function boot(init,opt){
  opt=opt||{};els={};store=Object.assign({},init||{});vp={content:'',setAttribute(k,v){if(k==='content')this.content=v}};throwSet=!!opt.throwSet;
  global.document={getElementById:id=>els[id]||(els[id]=mk()),documentElement:mk(),body:mk(),createElement:()=>mk(),addEventListener(){},querySelector:s=>/viewport/.test(s)?vp:mk(),querySelectorAll:()=>[],hidden:false};
  global.getComputedStyle=()=>({paddingTop:'0',paddingBottom:'0'});global.innerWidth=400;global.innerHeight=800;global.devicePixelRatio=1;
  global.localStorage={getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{if(throwSet)throw new Error('cuota');store[k]=String(v)}};
  global.confirm=opt.confirm||undefined;
  global.addEventListener=()=>{};global.requestAnimationFrame=()=>{};global.navigator={};global.Image=function(){};global.Audio=function(){return mk()};global.AudioContext=undefined;global.window=global;global.setInterval=()=>{};global.performance={now:()=>0};
  const code=sc[0]+';'+sc[1]+`
;({BAL,get M(){return M},get S(){return S},set S(v){S=v},SAVE_V,BUILD,save,loadSave,exportCode,parseCode,importObj,sane,cleanRun,fail,EVLOG,evlog,errReport,loop,hurt,hitP,die,menu,applyZoom,get saveBlock(){return saveBlock},get saveSrc(){return saveSrc},
 get RS(){return RS},set RS(v){RS=v},rsNew,rsEnd,summaryHTML,hash32,migrate,
 prep(){p={x:0,y:0,hp:100,max:100,ifr:0,sh:0,fm:0,hap:0,sl:0,bo:0};sk={shell:0};tm={};pt=[];fx=[];ft=[];wv=3;kills=40;bosses=0;t=95;lv=4;bEss=0;S='play'}})`;
  return (0,eval)(code);
}
const old0={ess:50,best:12,spins:12,dmg:3,hp:1,spd:0,set:{sfx:1,mus:1,vib:1,dif:3},own:{musguito:1}};
const enemy=(hp)=>({hp,x:0,y:0,r:5,fl:0,wet:0,fz:0,vu:0,af:null});

// ---------- A: versionado y migración (F6)
let a=boot({pocket2:JSON.stringify(old0)});
T('guardado v0 se migra a la versión actual',a.M.v===a.SAVE_V&&Array.isArray(a.M.log));
T('el progreso del guardado viejo se conserva',a.M.ess===50&&a.M.best===12&&a.M.dmg===3);
T('origen del guardado: principal',a.saveSrc==='principal (sin verificar)'||a.saveSrc==='principal');
a=boot({pocket2:JSON.stringify(Object.assign({},old0,{v:99,zzz:{x:1}}))});a.save();
T('guardado de versión futura: no se borran campos desconocidos',JSON.parse(store.pocket2).zzz.x===1&&JSON.parse(store.pocket2).v===99);
a=boot({pocket2:JSON.stringify(Object.assign({},old0,{v:'basura',ess:'x',log:'no'}))});
T('versión/tipos inválidos se normalizan sin romper',a.M.v===a.SAVE_V&&a.M.ess===0&&Array.isArray(a.M.log));
a=boot({pocket2:JSON.stringify(Object.assign({},old0,{log:Array.from({length:40},(_,i)=>({d:1,t:i,w:i,k:1,l:1,c:'x'.repeat(99),df:0,v:0,ca:'a',tp:'b',h:[1,2,300]}))}))});
T('registro de partidas: máx 20 y textos recortados',a.M.log.length===20&&a.M.log[0].c.length<=24&&a.M.log[0].h[2]===100);

// ---------- A: guardado a prueba de fallos (F7)
a=boot({});a.M.ess=77;T('save() devuelve true',a.save()===true);const GOOD={pocket2:store.pocket2,pocket2_bak:store.pocket2_bak,pocket2_ck:store.pocket2_ck};
T('se escriben principal, copia y suma',!!store.pocket2&&store.pocket2===store.pocket2_bak&&store.pocket2_ck===a.hash32(store.pocket2));
{const good=GOOD.pocket2;const s2=Object.assign({},GOOD,{pocket2:good.slice(0,good.length-9)});a=boot(s2);
 T('JSON truncado: se recupera de la copia',a.M.ess===77&&a.saveSrc==='copia'&&!a.saveBlock)}
{const good=GOOD.pocket2;a=boot({pocket2:good.replace('"ess":77','"ess":78'),pocket2_bak:good,pocket2_ck:GOOD.pocket2_ck});
 T('suma de comprobación distinta: se usa la copia verificada',a.M.ess===77)}
a=boot({pocket2:'{basura',pocket2_bak:'tampoco'});
T('ambos dañados: guardado bloqueado y no se sobrescribe',a.saveBlock&&a.save()===false&&store.pocket2==='{basura'&&store.pocket2_corrupt==='{basura');
a=boot({pocket2:'{basura'},{confirm:()=>true});T('ambos dañados + aceptar: empieza de cero y guarda',!a.saveBlock&&a.save()===true);
a=boot({pocket2:'{basura'},{confirm:()=>false});T('ambos dañados + cancelar: sigue sin guardar',a.saveBlock&&a.save()===false);
a=boot({pocket2:JSON.stringify(old0)},{throwSet:true});a.M.ess=5;let thr=false,r;try{r=a.save()}catch(e){thr=true}
T('setItem lanza (cuota/privado): no revienta y devuelve false',!thr&&r===false&&a.M.ess===5);
a=boot({});T('clave ausente: arranca con valores por defecto',a.M.ess===0&&a.M.own.musguito===1&&a.saveSrc==='nuevo');

// ---------- A: exportar / importar (F9)
a=boot({pocket2:JSON.stringify(Object.assign({},old0,{own:{musguito:1,llamin:1},st:{llamin:2},ess:321,spins:9}))});a.M.log.push(a.cleanRun({t:50,w:5,k:9,l:2,c:'musguito',ca:'Borbito',tp:'fuego',h:[100,50]}));
const code=a.exportCode(),before=JSON.stringify(a.M);
T('código con formato MP1.v.suma.datos',/^MP1\.\d+\.[0-9a-z]+\.[A-Za-z0-9+/=]+$/.test(code));
a=boot({});const pr=a.parseCode(code);T('el código se valida',!!pr.obj&&!pr.err);
a.importObj(pr.obj);T('exportar → borrar → importar deja el estado idéntico',JSON.stringify(a.M)===before);
T('importar guarda y crea copia previa solo si había guardado',store.pocket2.includes('"ess":321'));
a=boot({pocket2:JSON.stringify(old0)});a.importObj(a.parseCode(code).obj);T('importar guarda copia del progreso anterior',JSON.parse(store.pocket2_pre_import).ess===50);
for(const [n,c] of [['basura','hola mundo'],['vacío',''],['null',null],['etiqueta mala','XX.2.abc.AAAA'],['base64 roto','MP1.2.abc.@@@@'],['suma alterada',code.replace(/^(MP1\.\d+\.)[0-9a-z]+/,'$1zzzz')],['sin campos de juego','MP1.2.'+(()=>{const j='{"a":1}';return a.hash32(j)})()+'.'+Buffer.from('{"a":1}').toString('base64')]]){
  let e=false,q;try{q=a.parseCode(c)}catch(x){e=true}T('importar rechaza «'+n+'» sin lanzar',!e&&!!q.err&&!q.obj)}
a=boot({pocket2:'{basura'});a.importObj(a.parseCode(code).obj);T('importar desbloquea un guardado dañado',!a.saveBlock&&a.M.ess===321);
{const big=JSON.parse(Buffer.from(code.split('.').slice(3).join('.'),'base64').toString());big.ess=1e15;big.dmg=999;const j=JSON.stringify(big);
 a=boot({});a.importObj(a.parseCode('MP1.2.'+a.hash32(j)+'.'+Buffer.from(j).toString('base64')).obj);T('importar aplica los topes (sane)',a.M.ess<=1e9&&a.M.dmg<=10)}

// ---------- A: F8 / F20 (estático)
T('guarda al ocultar y en pagehide',/visibilitychange',\(\)=>\{if\(document\.hidden\)\{pause\(\);save\(\)\}/.test(h)&&/addEventListener\('pagehide',\(\)=>\{pause\(\);save\(\)\}\)/.test(h));
T('pide almacenamiento persistente',h.includes('navigator.storage.persist'));
T('iconos con role=img y aria-label',/e\.setAttribute\('role','img'\);e\.setAttribute\('aria-label',k\)/.test(h));
T('tamaño del atlas calculado desde ICN/ICR',/backgroundSize=\(ICN\*100\)\+'% '\+\(ICR\*100\)\+'%'/.test(h));
a=boot({});T('zoom desactivado por defecto: viewport bloquea zoom',a.M.set.zoom===0&&/user-scalable=no/.test(vp.content));
a=boot({pocket2:JSON.stringify(Object.assign({},old0,{set:{sfx:1,mus:1,vib:1,zoom:1}}))});T('opción de zoom activada: viewport permite zoom',a.M.set.zoom===1&&!/user-scalable=no|maximum-scale/.test(vp.content));
T('prefers-reduced-motion presente en CSS y en la lógica',/prefers-reduced-motion/.test(h)&&/const RM=/.test(h));
T('los textos importados no se insertan con innerHTML (esc() disponible)',/const esc=s=>/.test(h));

// ---------- C: errores (F15)
a=boot({});a.prep();a.M.ess=9;a.fail(new Error('boom de prueba'),'test');
T('error en partida: pantalla de error, progreso guardado',a.S==='err'&&JSON.parse(store.pocket2).ess===9);
T('el informe incluye versión, error y acciones',/boom de prueba/.test(els.errrep.value)&&els.errrep.value.includes(a.BUILD.h)&&/Últimas acciones/.test(els.errrep.value)&&/Semilla:/.test(els.errrep.value));
a.S='play';a.fail(new Error('boom de prueba'),'test');T('el mismo error repetido no vuelve a mostrar la pantalla',a.S==='play');
for(let i=0;i<120;i++)a.evlog('x',i);T('registro circular de 50 eventos',a.EVLOG.length===50);
a=boot({});a.S='menu';a.fail('error fuera de partida');T('error fuera de partida: se registra sin bloquear',a.S==='menu'&&a.EVLOG.some(x=>/ERROR/.test(x)));
a=boot({});a.S='play';let thrown=false;try{a.loop(1000)}catch(e){thrown=true}
T('el bucle principal no muere con una excepción (try/catch)',!thrown&&a.S==='err');
T('el informe no contiene datos personales (sin correo ni claves)',!/@|userEmail/.test(els.errrep.value));
a=boot({});a.prep();a.fail(new Error('x'),'t');try{a.die()}catch(e){}T('RECUPERAR EXPEDICIÓN: die() funciona desde la pantalla de error',a.S==='over');
T('captura global registrada (error y unhandledrejection)',/addEventListener\('error',ev=>fail/.test(h)&&/addEventListener\('unhandledrejection',ev=>fail/.test(h));

// ---------- C: resumen de partida (F16)
a=boot({});a.prep();a.RS=a.rsNew();
const e1=enemy(10);a.hurt(e1,30,'fuego',0,0,1);const e2=enemy(100);a.hurt(e2,25,'agua',0,0,1);a.hurt(e2,15,'fuego',0,0,1);
T('daño por tipo: sobredaño recortado a la vida restante (10+15)',Math.abs(a.RS.dm.fuego-25)<1e-9&&Math.abs(a.RS.dm.agua-25)<1e-9);
const tot=Object.values(a.RS.dm).reduce((x,y)=>x+y,0);T('la suma del daño por tipo = daño real aplicado',Math.abs(tot-(10+25+15))<1e-9);
a.hurt(enemy(50),9,'tierra',0,0,1);const tg={hp:50,x:0,y:0,r:5,fl:0,wet:0,fz:0,vu:0,af:null,dummy:1};a.hurt(tg,99,'aire',0,0,1);T('enemigo ficticio no cuenta',a.RS.dm.aire===undefined);
a.hitP(8,0,'Borbito');a.M.set.vib=0;T('daño recibido por fuente y última fuente',a.RS.tk.Borbito>0&&a.RS.last==='Borbito');
a.RS.hp=[100,90,60,20];a.prep();a.hitP(1,0,'Gran jefe');
const prevLog=a.M.log.length;a.die();
const lg=a.M.log[a.M.log.length-1];T('die(): se guarda el registro (máx 20)',a.M.log.length===prevLog+1&&lg.ca==='Gran jefe'&&lg.tp==='fuego'&&lg.w===3);
T('pantalla de resumen: causa, fuente de daño y gráfica',/Te derrotó: <b>Gran jefe/.test(els.res.innerHTML)&&/Mayor fuente de daño: <b>Fuego/.test(els.res.innerHTML)&&/<svg/.test(els.res.innerHTML));
a=boot({});a.prep();a.RS=a.rsNew();a.RS.last='<img src=x onerror=1>';a.die();T('el resumen escapa el texto (sin HTML inyectado)',!/<img/.test(els.res.innerHTML));
a=boot({});a.prep();a.RS=a.rsNew();for(let i=0;i<30;i++)a.M.log.push(a.cleanRun({t:i}));a.die();T('el registro nunca pasa de 20 partidas',a.M.log.length===20);
a=boot({});a.prep();a.RS=a.rsNew();a.RS.hp=Array.from({length:200},(_,i)=>i%101);a.die();T('muestreo de vida comprimido (≤24 puntos)',a.M.log[a.M.log.length-1].h.length<=24);
a=boot({});a.prep();a.RS=null;let t2=false;try{a.die()}catch(e){t2=true}T('die() sin resumen previo no falla',!t2&&a.S==='over');

// ---------- B: service worker, build y versión
const swSrc=fs.readFileSync(__dirname+'/sw.js','utf8');
function runSW(opt){opt=opt||{};const cache={},listeners={};let skipped=0,claimed=0;
  const mkCache=()=>({_m:{},async addAll(l){for(const u of l){if(opt.missing&&opt.missing===u)throw new Error('404');this._m[u]='R:'+u}},async add(u){if(opt.missing===u)throw new Error('404');this._m[u]='R:'+u},async put(r,res){this._m[r.url||r]=res}});
  const caches={async open(n){return cache[n]||(cache[n]=mkCache())},async keys(){return Object.keys(cache)},async delete(n){delete cache[n];return true},async match(r){const k=typeof r==='string'?r:r.url;for(const n in cache){const m=cache[n]._m;const kk=Object.keys(m).find(x=>k.endsWith(x==='./'?'/':x)||x===k);if(kk)return m[kk]}}};
  const ctx={self:{addEventListener:(n,f)=>{listeners[n]=f},skipWaiting:()=>{skipped++},clients:{claim:()=>{claimed++}},location:{origin:'https://x.test'}},caches,URL,Response:class{constructor(b,o){this.body=b;this.status=(o&&o.status)||200;this.ok=this.status<400}clone(){return this}},
    fetch:opt.fetch||(async()=>{throw new Error('offline')}),setTimeout,clearTimeout,Promise};ctx.self.location=ctx.self.location;vm.runInNewContext(swSrc,ctx);
  return{L:listeners,cache,caches,get skipped(){return skipped},get claimed(){return claimed},ctx}}
const swv=(swSrc.match(/const C='([^']+)'/)||[])[1],CORE=JSON.parse((swSrc.match(/CORE=(\[.*?\]),ASSETS/)||[])[1]||'[]'),ASSETS=JSON.parse((swSrc.match(/ASSETS=(\[.*?\]);/)||[])[1]||'[]');
T('sw.js: nombre de caché = mp-<versión de BUILD>',swv==='mp-'+a.BUILD.h&&/^[0-9a-f]{8}$/.test(a.BUILD.h));
const files=(d=>{const w=d=>fs.readdirSync(path.join(__dirname,d),{withFileTypes:true}).flatMap(e=>e.isDirectory()?w(d+'/'+e.name):[d+'/'+e.name]);return w(d)})('assets').filter(f=>/\.(png|jpe?g|webp|gif|svg)$/i.test(f));
T('sw.js: precachea todos los recursos de assets/ ('+files.length+')',files.every(f=>ASSETS.includes(f))&&ASSETS.every(f=>fs.existsSync(path.join(__dirname,f))));
T('sw.js: el atlas de iconos y el núcleo están precacheados',ASSETS.includes('assets/icons/raven.png')&&CORE.includes('index.html')&&CORE.includes('manifest.webmanifest'));
T('sw.js: NO usa skipWaiting automático al instalar (espera al jugador)',!/install',[^;]*skipWaiting/.test(swSrc)&&/e\.data==='skip'/.test(swSrc));
(async()=>{
  let s=runSW();await s.L.install({waitUntil:p=>p.then?p:0}.waitUntil?{waitUntil:p=>{s._p=p}}:0);await s._p;
  T('install: llena la caché con núcleo y recursos',Object.keys(s.cache['mp-'+a.BUILD.h]._m).length===CORE.length+ASSETS.length);
  s=runSW({missing:ASSETS[0]});s.L.install({waitUntil:p=>{s._p=p}});let inst=true;try{await s._p}catch(e){inst=false}
  T('install: un recurso que falta NO impide instalar',inst);
  s.L.message({data:'skip'});T('mensaje skip → skipWaiting',s.skipped===1);s.L.message({data:'otra'});T('otros mensajes se ignoran',s.skipped===1);
  s=runSW();s.cache['mp-viejo']={_m:{}};s.cache['mp-'+a.BUILD.h]={_m:{}};let pa;s.L.activate({waitUntil:p=>{pa=p}});await pa;
  T('activate: borra cachés antiguas y reclama clientes',!s.cache['mp-viejo']&&!!s.cache['mp-'+a.BUILD.h]&&s.claimed===1);
  // fetch sin red
  s=runSW();s.L.install({waitUntil:p=>{s._p=p}});await s._p;
  const ask=async(url,mode)=>{let r;s.L.fetch({request:{url,method:'GET',mode:mode||'cors'},respondWith:p=>{r=p}});return r&&await r};
  let rsp=await ask('https://x.test/','navigate');T('sin red: la navegación responde desde la caché',rsp==='R:index.html'||rsp==='R:./');
  rsp=await ask('https://x.test/assets/icons/raven.png');T('sin red: el recurso precacheado sale de la caché',rsp==='R:assets/icons/raven.png');
  rsp=await ask('https://x.test/assets/no-existe.png');T('sin red y fuera de caché: respuesta 504, sin excepción',rsp&&rsp.status===504);
  let touched=false;s.L.fetch({request:{url:'https://x.test/a',method:'POST'},respondWith:()=>{touched=true}});T('solo se gestionan peticiones GET',!touched);
  s.L.fetch({request:{url:'https://otro.test/a.png',method:'GET'},respondWith:()=>{touched=true}});T('no se interceptan otros orígenes',!touched);
  // red primero para index
  s=runSW({fetch:async u=>({ok:true,status:200,clone(){return this},tag:'RED:'+u})});s.L.install({waitUntil:p=>{s._p=p}});await s._p;
  rsp=await ask('https://x.test/index.html','navigate');T('con red: index.html se sirve desde la red (actualizaciones)',rsp&&/^RED:/.test(rsp.tag));
  // build --check
  const r=cp.spawnSync(process.execPath,['tools/build.js','--check'],{cwd:__dirname,encoding:'utf8'});
  T('tools/build.js --check: sw.js, BUILD y CODEMAP.md al día'+(r.status?' ('+(r.stderr||'').trim().split('\n')[0]+')':''),r.status===0);
  T('CODEMAP.md existe y lista funciones clave',fs.existsSync(__dirname+'/CODEMAP.md')&&/die\(v\)@\d+/.test(fs.readFileSync(__dirname+'/CODEMAP.md','utf8')));
  T('ajustes muestran versión/compilación/guardado',/Versión '\+BUILD\.h\+' · compilado '\+BUILD\.d\+' · guardado v'\+M\.v/.test(h));
  T('aviso de actualización en la interfaz',/Nueva versión disponible/.test(h)&&/postMessage\('skip'\)/.test(h));
  console.log(ok,'ok',bad,'fallos');process.exit(bad?1:0);
})();
