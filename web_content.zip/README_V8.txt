BLOCK PUZZLE V8 — LOKI GAMES

V8 includes:
- 10x10 drag-and-place board
- Multiple block designs including 1x1, 2x1, 2x2, 3x1, 3x3, L/T/E-style shapes
- Large floating block above the finger with matching placement preview
- Faster pointer response
- More placement and line-clear sounds
- Single/double/multi line clear feedback
- Score and Top Score saved locally
- Sound and vibration settings
- Share button
- About section with LOKI GAMES and social links

Open index.html in a browser to play.
This is the V8 web build; it is not yet an Android APK/AAB.
