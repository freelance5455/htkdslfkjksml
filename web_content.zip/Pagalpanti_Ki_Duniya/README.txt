PAGALPANTI KI DUNIYA — ENHANCED DESI CITY BUILD

Included:
- Procedural open-world style town with intersecting paved roads, lane markings and pavements
- Residential houses, apartment blocks, storefronts and named desi businesses
- Player home (MY GHAR) and POLICE STATION landmarks
- 28 animated NPCs with simple idle/walk motion and funny interaction lines
- Driveable cars, bikes and auto-rickshaws
- Third-person character with articulated arms/legs, jump and run
- Day/night cycle (one in-game day is about four real minutes)
- Real-time directional shadows, ambient lighting, glossy puddle patches and glass windows
- Mobile joystick and touch buttons

CONTROLS
Desktop: WASD / arrows move, drag mouse to rotate camera, E interact, F enter/exit nearby vehicle, Shift run, Space jump.
Mobile: joystick move, USE interact, RIDE enter/exit, JUMP.

RUN
Extract ZIP. Use VS Code Live Server or another local HTTP server to serve index.html.
Three.js loads from jsDelivr, so internet is needed.

HONEST LIMITS
This is a bigger procedural browser prototype, not GTA 6. Buildings, traffic density, physics, reflections and animation are simplified. The glossy puddles and windows are material-based visual reflections, not full ray-traced reflections. It is a playable foundation for further upgrades.
