import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

/* PAGALPANTI KI DUNIYA — procedural desi open-world prototype */
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x9bd5f0);
scene.fog = new THREE.Fog(0x9bd5f0, 90, 360);
const camera = new THREE.PerspectiveCamera(67, innerWidth/innerHeight, .1, 700);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth,innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
document.body.appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xd9efff,0x5b4934,1.5); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe0b0,2.6);
sun.position.set(-70,110,60); sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);
sun.shadow.camera.left=-150; sun.shadow.camera.right=150; sun.shadow.camera.top=150; sun.shadow.camera.bottom=-150;
sun.shadow.bias=-0.0002; scene.add(sun);
const ambient = new THREE.AmbientLight(0xffffff,.18);scene.add(ambient);

const mat=(c,r=.82,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
const M={
 asphalt:mat(0x343a40), line:mat(0xf4e6ad), pavement:mat(0xb7aa91), grass:mat(0x6e9952),
 concrete:mat(0xc7bda9), window:mat(0x284b5e,.22,.45), litWindow:mat(0xffd78a,.35),
 skin:mat(0xc9875d), dark:mat(0x262321), white:mat(0xf1eadc)
};
function mesh(geo,material,parent=scene,x=0,y=0,z=0,shadow=true){const o=new THREE.Mesh(geo,material);o.position.set(x,y,z);o.castShadow=shadow;o.receiveShadow=true;parent.add(o);return o}
function cube(parent,x,y,z,sx,sy,sz,material){return mesh(new THREE.BoxGeometry(sx,sy,sz),material,parent,x,y,z)}
function labelTexture(text,bg='#15583b',fg='#fff1b5'){
 const c=document.createElement('canvas');c.width=512;c.height=128;const g=c.getContext('2d');
 g.fillStyle=bg;g.fillRect(0,0,512,128);g.fillStyle=fg;g.font='bold 58px Arial';g.textAlign='center';g.textBaseline='middle';g.fillText(text,256,66);
 const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;
}
function sign(parent,text,x,y,z,w=5,bg='#15583b'){const p=cube(parent,x,y,z,w,.9,.16,new THREE.MeshStandardMaterial({map:labelTexture(text,bg),roughness:.8}));return p}

// ground and a road grid
const ground=mesh(new THREE.PlaneGeometry(700,700),M.grass,scene,0,-.12,0,false);ground.rotation.x=-Math.PI/2;
function road(x,z,w,d){cube(scene,x,.015,z,w,.12,d,M.asphalt)}
road(0,0,24,460);road(0,0,460,24);road(-100,0,16,460);road(100,0,16,460);road(0,-100,460,16);road(0,100,460,16);
function dashLine(x,z,w,d){for(let i=-210;i<=210;i+=14){if(w>d)cube(scene,x+i,.09,z,6,.025,.22,M.line);else cube(scene,x,.09,z+i,.22,.025,6,M.line)}}
dashLine(0,0,460,24);dashLine(0,0,24,460);dashLine(-100,0,16,460);dashLine(100,0,16,460);dashLine(0,-100,460,16);dashLine(0,100,460,16);
for(const [x,z,w,d] of [[14,0,3,460],[-14,0,3,460],[0,14,460,3],[0,-14,460,3],[86,0,3,460],[114,0,3,460],[-86,0,3,460],[-114,0,3,460],[0,86,460,3],[0,114,460,3],[0,-86,460,3],[0,-114,460,3]])cube(scene,x,.1,z,w,.2,d,M.pavement);

// city blocks, storefronts, residential homes and apartments
const buildingMats=[mat(0xd7ad78),mat(0xe1d3b8),mat(0xc68e75),mat(0x9eb8ae),mat(0xe3c76c),mat(0xa7a4c3),mat(0xc6b9a3)];
const shopNames=['DESI CHAI','SAMOSA CORNER','MAMA JI DHABA','PUNJABI CAFE','TANDOORI HOUSE','BIRYANI POINT','GENERAL STORE','MITHAI MAHAL'];
const buildings=[];
function building(x,z,kind='home',name=''){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
 const w=kind==='shop'?13:kind==='home'?11:16, depth=kind==='shop'?10:12, floors=kind==='flat'?4:kind==='shop'?1:2;
 const h=kind==='flat'?floors*5.3:kind==='shop'?5.5:8.5;
 const wall=buildingMats[Math.floor(Math.random()*buildingMats.length)];
 cube(g,0,h/2,0,w,h,depth,wall);
 cube(g,0,h+.15,0,w+.4,.3,depth+.4,mat(0x8b806d));
 // facade windows on front
 const front=depth/2+.08;
 if(kind==='shop'){
   cube(g,0,1.6,front+.02,w*.72,2.7,.12,mat(0x4b3022));
   cube(g,0,1.6,front+.12,w*.66,2.35,.08,mat(0x9ccbd0,.25,.2));
   cube(g,0,3.35,front+.2,w+.2,.8,.25,mat(0xd7472f));
   sign(g,name||'DESI SHOP',0,3.35,front+.36,w*.88,'#a12e1f');
   cube(g,4.5,1.15,front+.55,2,.16,1.3,mat(0x8b512e));
 }else{
   for(let f=0;f<floors;f++)for(let a=-1;a<=1;a++){
     const win=cube(g,a*3.1,2.1+f*4.2,front,w<12?1.35:1.7,1.7,.12,Math.random()>.5?M.window:M.litWindow);
     cube(g,a*3.1,1.22+f*4.2,front+.08,w<12?1.55:1.9,.12,.3,mat(0xe5d4b9));
   }
   // balcony rails
   if(kind==='flat')for(let f=1;f<floors;f++)cube(g,0,1.2+f*5.3,front+.4,w*.8,.12,.8,mat(0x5d5b57));
   cube(g,0,1.2,front+.15,2.1,2.4,.16,mat(0x614b3a));
 }
 buildings.push({g,x,z,w,depth,kind,name});
 return g;
}
// blocks in the neighbourhood with roads kept clear
for(let x=-190;x<=190;x+=38)for(let z=-190;z<=190;z+=38){
 if(Math.abs(x)<28||Math.abs(z)<28||Math.abs(x-100)<28||Math.abs(z-100)<28)continue;
 const r=Math.random();
 building(x,z,r<.22?'flat':r<.62?'home':'shop',shopNames[Math.floor(Math.random()*shopNames.length)]);
}
// intentional landmark shops along central roads
building(30,-22,'shop','DESI CHAI');building(48,-22,'shop','SAMOSA CORNER');
building(-30,22,'shop','PUNJABI CAFE');building(-48,22,'shop','MAMA JI DHABA');
building(30,48,'shop','TANDOORI HOUSE');building(-30,-48,'shop','BIRYANI POINT');
building(145,25,'flat');building(-145,-25,'flat');

// home and police station landmarks
const home=building(25,28,'home','');sign(home,'MY GHAR',0,3.6,6.25,6,'#27623d');
const police=building(-25,-28,'shop','POLICE STATION');sign(police,'POLICE STATION',0,4.4,5.35,10,'#183d70');
cube(police,-3,2.2,5.4,.35,2.3,.2,mat(0xffffff));cube(police,3,2.2,5.4,.35,2.3,.2,mat(0xffffff));

// street lights
for(let x=-200;x<=200;x+=40)for(const z of [-18,18]){
 const pole=cube(scene,x,3,z,.22,6,.22,mat(0x45484b));
 const lamp=mesh(new THREE.SphereGeometry(.38,10,8),mat(0xffe2a0,.3),scene,x,6.2,z);
 const pl=new THREE.PointLight(0xffc978,0,19);pl.position.set(x,5.9,z);scene.add(pl);lamp.userData.light=pl;
}

// trees, planters and benches
function tree(x,z){const trunk=mesh(new THREE.CylinderGeometry(.35,.5,3.8,10),mat(0x76502e),scene,x,1.9,z);
 const crown=mesh(new THREE.SphereGeometry(2.4,12,10),mat(0x347c40),scene,x,4.8,z);crown.scale.y=1.25;}
for(let i=-190;i<=190;i+=22){tree(i,19);tree(i,-19);tree(19,i);tree(-19,i)}
for(let i=0;i<18;i++){const x=(Math.random()-.5)*360,z=(Math.random()-.5)*360;if(Math.abs(x%100)>20&&Math.abs(z%100)>20)tree(x,z)}

// Character rig with visible limbs and simple walk animation
function character(x,z,shirtColor=0x276ca8,isPlayer=false,hat=false){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
 const skin=mat(0xc9875d),shirt=mat(shirtColor),trousers=mat(0x28364a),shoe=mat(0x252525);
 const torso=cube(g,0,1.5,0,.85,1.05,.48,shirt);
 const head=mesh(new THREE.SphereGeometry(.43,16,12),skin,g,0,2.35,0);
 mesh(new THREE.SphereGeometry(.44,16,8,0,Math.PI*2,0,Math.PI/2),mat(0x251c18),g,0,2.48,0);
 for(const s of [-1,1])mesh(new THREE.SphereGeometry(.045,8,8),M.dark,g,s*.16,2.38,.39,false);
 if(hat)mesh(new THREE.CylinderGeometry(.43,.43,.17,14),mat(0xd64c31),g,0,2.78,0);
 const arms=[],legs=[];
 for(const s of [-1,1]){
   const a=cube(g,s*.56,1.52,0,.24,.86,.25,skin);a.userData.side=s;arms.push(a);
   const l=cube(g,s*.23,.55,0,.3,.85,.34,trousers);l.userData.side=s;legs.push(l);
   cube(g,s*.23,.12,.13,.34,.22,.52,shoe);
 }
 return {g,arms,legs,phase:Math.random()*7,isPlayer};
}
const player=character(0,40,0x2670a8,true);
const npcs=[];
for(let i=0;i<28;i++){
 const x=(Math.random()-.5)*300,z=(Math.random()-.5)*300;
 if(Math.abs(x%100)<18||Math.abs(z%100)<18)continue;
 npcs.push(character(x,z,[0xd34b38,0x7c4eaa,0x25846d,0xd29a24,0xeeeeee][i%5],false,i%4===0));
}

// vehicle models: car, bike and auto rickshaw
function vehicle(type,x,z,color=0xd6a52c){
 const g=new THREE.Group();scene.add(g);g.position.set(x,0,z);
 const bodyMat=mat(color,.35,.15),rubber=mat(0x17191b),chrome=mat(0xb8c2c6,.25,.75),glass=mat(0x77b5c5,.18,.2);
 const wheels=[];
 function wheel(xp,zp,r=.42){const w=mesh(new THREE.CylinderGeometry(r,r,.25,16),rubber,g,xp,r,zp);w.rotation.z=Math.PI/2;wheels.push(w)}
 if(type==='car'){
   cube(g,0,.75,0,2.2,.85,4.1,bodyMat);cube(g,0,1.45,-.25,1.8,.85,2.1,glass);
   cube(g,0,1.05,2.06,1.5,.35,.08,chrome);
   for(const xx of [-1,1])for(const zz of [-1.35,1.35])wheel(xx,zz,.48);
   for(const xx of [-.75,.75])cube(g,xx,.72,2.1,.35,.2,.12,mat(0xfff0c2));
 }else if(type==='bike'){
   const frame=mesh(new THREE.CylinderGeometry(.12,.12,2.0,8),bodyMat,g,0,.85,0);frame.rotation.x=Math.PI/2;
   cube(g,0,1.05,-.25,.6,.3,.85,bodyMat);cube(g,0,1.45,-.35,.42,.65,.42,mat(0x262b31));
   for(const zz of [-.95,.95]){const w=mesh(new THREE.TorusGeometry(.48,.1,8,18),rubber,g,0,.48,zz);w.rotation.y=Math.PI/2;wheels.push(w)}
   cube(g,0,1.48,.82,.8,.08,.12,chrome);
 }else{
   cube(g,0,.85,0,2.25,1.1,3.1,bodyMat);cube(g,0,1.65,-.1,2.05,.2,2.65,mat(0x262626));
   cube(g,0,1.35,1.55,1.45,.65,.1,glass);
   for(const xx of [-.9,.9])for(const zz of [-.9,1])wheel(xx,zz,.42);
 }
 return {g,type,speed:0,wheels};
}
const vehicles=[
 vehicle('car',-8,8,0xc83930),vehicle('bike',8,8,0x1765bd),vehicle('auto',-8,-8,0xf0c52c),
 vehicle('car',55,10,0xe9e4d8),vehicle('bike',-55,-10,0x218653),
 vehicle('car',0,-55,0x384eae),vehicle('auto',45,55,0x16a5a0)
];
let activeVehicle=null,vehicleSpeed=0;

// mission marker at chai stall and floating marker
const missionPos=new THREE.Vector3(30,0,-22);
const ring=mesh(new THREE.TorusGeometry(1.7,.16,10,28),mat(0xffdf42),scene,missionPos.x,.5,missionPos.z);ring.rotation.x=Math.PI/2;
const ringLight=new THREE.PointLight(0xffcf42,28,20);ringLight.position.set(missionPos.x,4,missionPos.z);scene.add(ringLight);

// puddle-like reflective patches using glossy dark blue planes
const puddleMat=new THREE.MeshStandardMaterial({color:0x526d78,roughness:.08,metalness:.85,transparent:true,opacity:.72});
for(let i=0;i<22;i++){const x=(Math.random()-.5)*340,z=(Math.random()-.5)*340;if(Math.abs(x%100)>17&&Math.abs(z%100)>17){const p=mesh(new THREE.CircleGeometry(1+Math.random()*2,20),puddleMat,scene,x,.035,z,false);p.rotation.x=-Math.PI/2;p.scale.y=.45;}}

// input
const keys={};addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key.toLowerCase()==='e')interact();if(e.key.toLowerCase()==='f')switchVehicle();if(e.key===' ')jump()});
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
let yaw=0,pitch=.16,drag=false,lastX=0,lastY=0;
renderer.domElement.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'){drag=true;lastX=e.clientX;lastY=e.clientY}});
addEventListener('pointerup',()=>drag=false);
addEventListener('pointermove',e=>{if(drag){yaw-=(e.clientX-lastX)*.004;pitch=THREE.MathUtils.clamp(pitch+(e.clientY-lastY)*.002,-.1,.55);lastX=e.clientX;lastY=e.clientY}});
let stickMove={x:0,y:0},stickOn=false;const stick=document.getElementById('stick'),knob=document.getElementById('knob');
stick.addEventListener('pointerdown',e=>{stickOn=true;stick.setPointerCapture(e.pointerId);moveStick(e)});
stick.addEventListener('pointermove',e=>{if(stickOn)moveStick(e)});
stick.addEventListener('pointerup',()=>{stickOn=false;stickMove={x:0,y:0};knob.style.transform='translate(0,0)'});
function moveStick(e){const r=stick.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,l=Math.hypot(dx,dy),m=36;const x=l>m?dx/l*m:dx,y=l>m?dy/l*m:dy;stickMove={x:x/m,y:-y/m};knob.style.transform=`translate(${x}px,${y}px)`}
document.getElementById('interact').onclick=interact;document.getElementById('switch').onclick=switchVehicle;document.getElementById('jump').onclick=jump;

let jumpY=0,jumpV=0,walkPhase=0,missionDone=false,toastTime=0,clockHours=8,money=2500;
function say(t){document.getElementById('toast').textContent=t;toastTime=3.5}
function nearestVehicle(){let best=null,d=7;for(const v of vehicles){const q=v.g.position.distanceTo(player.g.position);if(q<d){d=q;best=v}}return best}
function switchVehicle(){
 if(activeVehicle){player.g.position.copy(activeVehicle.g.position);player.g.position.z+=3;activeVehicle=null;vehicleSpeed=0;document.getElementById('vehicle').textContent='ON FOOT';say('You got out. Walk around, boss!');return}
 const v=nearestVehicle();if(v){activeVehicle=v;player.g.visible=false;document.getElementById('vehicle').textContent='DRIVING: '+v.type.toUpperCase();say('Vehicle ready! W/S accelerate and brake. A/D steer. Press F to exit.')}
 else say('Kisi car, bike ya auto ke paas jao, phir F dabao.');
}
function interact(){
 if(!missionDone&&player.g.position.distanceTo(missionPos)<10){missionDone=true;money+=500;document.getElementById('money').textContent='₹ '+money.toLocaleString('en-IN');document.getElementById('mission').textContent='MISSION COMPLETE · Chai delivered! Next: explore Desi City';ring.visible=false;ringLight.visible=false;say('CHACHA: Oye hoye! Chai aur samosa dono time par! +₹500');return}
 const near=npcs.find(n=>n.g.position.distanceTo(player.g.position)<5);
 if(near)say(['NPC: Bhai petrol ke paise udhaar milenge?','Aunty: Beta, pehle padhai phir driving!','Chacha: Meri chai mein cheeni kam hai!','Shopkeeper: Samosa garam hai, jaldi lo!'][Math.floor(Math.random()*4)]);
 else if(player.g.position.distanceTo(new THREE.Vector3(25,0,28))<10)say('YEH TUMHARA GHAR HAI! Welcome home, boss.');
 else if(player.g.position.distanceTo(new THREE.Vector3(-25,0,-28))<12)say('POLICE STATION: Inspector saab abhi chai break par hain.');
 else say('Nearby NPC, MY GHAR, police station ya chai shop ke paas jao.');
}
function jump(){if(jumpY<.03)jumpV=7}
function update(dt,t){
 // day-night cycle: 4 real minutes for a full in-game day
 clockHours=(clockHours+dt/240*24)%24;
 const daylight=Math.max(0,Math.sin((clockHours-6)/12*Math.PI));
 const night=1-daylight;
 const sky=new THREE.Color().setHSL(.56,.45,.22+.48*daylight);
 scene.background.copy(sky);scene.fog.color.copy(sky);
 sun.intensity=.12+2.5*daylight;hemi.intensity=.28+1.45*daylight;
 sun.position.set(Math.cos(clockHours/24*Math.PI*2)*100,20+90*daylight,Math.sin(clockHours/24*Math.PI*2)*100);
 for(const b of buildings){/* warm lit windows remain visible at night */}
 document.getElementById('clock').textContent=String(Math.floor(clockHours)).padStart(2,'0')+':'+String(Math.floor((clockHours%1)*60)).padStart(2,'0')+(clockHours<12?' AM':' PM')+' · '+(daylight>.35?'DAY':'NIGHT');
 // controls in camera-relative direction
 let f=(keys.w||keys.arrowup?1:0)-(keys.s||keys.arrowdown?1:0)+stickMove.y;
 let s=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0)+stickMove.x;
 const len=Math.hypot(f,s);if(len>1){f/=len;s/=len}
 if(activeVehicle){
   const v=activeVehicle;vehicleSpeed+=(f>0?18:f<0?-24:0)*dt;vehicleSpeed*=Math.pow(.985,dt*60);vehicleSpeed=THREE.MathUtils.clamp(vehicleSpeed,-8,25);
   v.g.rotation.y-=s*dt*(1.2+Math.abs(vehicleSpeed)*.035);
   v.g.position.x+=Math.sin(v.g.rotation.y)*vehicleSpeed*dt;
   v.g.position.z+=Math.cos(v.g.rotation.y)*vehicleSpeed*dt;
   v.wheels.forEach(w=>{w.rotation.x+=vehicleSpeed*dt*1.8});
   player.g.position.copy(v.g.position);
 }else{
   const speed=(keys.shift?12:7.5),dx=(Math.sin(yaw)*f+Math.cos(yaw)*s)*speed*dt,dz=(Math.cos(yaw)*f-Math.sin(yaw)*s)*speed*dt;
   player.g.position.x+=dx;player.g.position.z+=dz;
   if(Math.abs(f)+Math.abs(s)>.04){player.g.rotation.y=Math.atan2(dx,dz);walkPhase+=dt*10*(keys.shift?1.3:1);player.legs.forEach((l,i)=>l.rotation.x=Math.sin(walkPhase+i*Math.PI)*.65);player.arms.forEach((a,i)=>a.rotation.x=-Math.sin(walkPhase+i*Math.PI)*.5)}
   jumpV-=19*dt;jumpY=Math.max(0,jumpY+jumpV*dt);if(jumpY===0)jumpV=0;player.g.position.y=jumpY;
 }
 // NPCs idle / wander subtly
 npcs.forEach((n,i)=>{n.phase+=dt*2;n.legs.forEach((l,j)=>l.rotation.x=Math.sin(n.phase+j*Math.PI)*.12);n.g.rotation.y=Math.sin(n.phase*.35)*.22});
 ring.rotation.z=t*1.2;ring.position.y=.45+Math.sin(t*3)*.18;
 const pos=activeVehicle?activeVehicle.g.position:player.g.position;
 const look=new THREE.Vector3(pos.x,2.1+pitch*3,pos.z);
 const desired=new THREE.Vector3(pos.x-Math.sin(yaw)*11,5.2+pitch*5,pos.z-Math.cos(yaw)*11);
 camera.position.lerp(desired,1-Math.pow(.001,dt));camera.lookAt(look);
 if(toastTime>0){toastTime-=dt;if(toastTime<=0)document.getElementById('toast').textContent=''}
}
const clock=new THREE.Clock();
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);update(dt,clock.elapsedTime);renderer.render(scene,camera)}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
document.getElementById('boot').style.display='none';
say('Welcome to Desi City! Yellow marker par jao: chai delivery mission. F = enter/exit vehicle.');
