SkyLink B2B Website

HOW TO OPEN
1. Extract the ZIP file.
2. Open the index.html file in Chrome, Firefox, Edge, or another modern browser.
3. An internet connection is needed to load the Font Awesome icons stylesheet.

IMPORTANT
This package contains the responsive frontend/demo only. The flight search, login, booking,
ticketing, and airline inventory are not connected to a live backend or airline API.
To enable real bookings, integrate an authorized GDS/NDC/LCC provider, backend services,
secure authentication, and payment/ticketing workflows.
