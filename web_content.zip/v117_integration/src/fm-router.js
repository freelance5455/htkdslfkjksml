/**
 * Routeur FM 27 — enchaîne les écrans maquettes jusqu'au damier.
 * S'appuie sur les templates fm-screens.js et le state V117 existant.
 */
import { initLandscapeGuidance } from './orientation.js';
import {
  renderLaunchMenuHtml,
  renderCareerConfigHtml,
  renderCompetitionsOverviewHtml,
  renderTakeOfficeHtml,
  renderClubDashboardHtml,
  renderMatchDayShellHtml
} from './fm-screens.js';

const HOST_ID = 'fmFlowHost';

function ensureHost() {
  let host = document.getElementById(HOST_ID);
  if (!host) {
    host = document.createElement('div');
    host.id = HOST_ID;
    host.className = 'fm-flow-host';
    document.body.appendChild(host);
  }
  return host;
}

function hideNativeLaunch() {
  const launch = document.getElementById('launchScreen');
  if (launch) {
    launch.classList.add('launch-screen--hidden');
    launch.hidden = true;
  }
  document.body.classList.add('cgd-fm-theme', 'cgd-fm-layout', 'cgd-landscape-first');
}

function showNativeApp() {
  const host = document.getElementById(HOST_ID);
  if (host) host.hidden = true;
  document.querySelectorAll('.section').forEach(s => { /* laisser app.js gérer */ });
  document.querySelector('.app')?.removeAttribute('hidden');
}

function getConfig(state) {
  state.career ??= {};
  state.career.fmConfig ??= {
    mode: 'club',
    ai: 'moyen',
    reputation: 'inconnu',
    autosave: true
  };
  return state.career.fmConfig;
}

function mount(html, state, api) {
  const host = ensureHost();
  host.hidden = false;
  host.innerHTML = html;
  bind(host, state, api);
  return host;
}

function bind(host, state, api) {
  // Choix config
  host.querySelectorAll('[data-fm-config]').forEach(el => {
    el.addEventListener('click', () => {
      const key = el.dataset.fmConfig;
      const cfg = getConfig(state);
      if (key === 'autosave') {
        cfg.autosave = !cfg.autosave;
        el.classList.toggle('on', cfg.autosave);
        el.setAttribute('aria-checked', String(cfg.autosave));
      } else {
        cfg[key] = el.dataset.value;
        // re-render current config screen
        go('career-config', state, api);
      }
      api.save?.(state);
    });
  });

  // Délégation staff (prise de fonction)
  host.querySelectorAll('[data-fm-delegate]').forEach(el => {
    el.addEventListener('click', () => {
      const on = !el.classList.contains('on');
      el.classList.toggle('on', on);
      el.setAttribute('aria-checked', String(on));
      try {
        api.updateDelegation?.(state, el.dataset.fmDelegate, on);
        api.save?.(state);
      } catch (e) {
        console.warn(e);
      }
    });
  });

  // Actions de parcours
  host.querySelectorAll('[data-fm-action]').forEach(btn => {
    btn.addEventListener('click', () => {
      const action = btn.dataset.fmAction;
      handleAction(action, state, api);
    });
  });

  // Onglets dashboard → écrans natifs
  host.querySelectorAll('[data-fm-tab]').forEach(tab => {
    tab.addEventListener('click', () => {
      const name = tab.dataset.fmTab;
      const map = {
        accueil: 'accueil',
        club: 'club',
        compétitions: 'competitions',
        competitions: 'competitions',
        classement: 'competitions',
        mercato: 'mercato',
        tactique: 'arene',
        calendrier: 'calendrier',
        gestion: 'gestion',
        médias: 'messagerie',
        medias: 'messagerie',
        plus: 'reglages'
      };
      const screen = map[name] || 'accueil';
      leaveFlowToNative(screen, state, api);
    });
  });
}

function handleAction(action, state, api) {
  switch (action) {
    case 'new-career':
      go('career-config', state, api);
      break;
    case 'continue':
      if (state.career?.manager) {
        leaveFlowToNative('accueil', state, api);
      } else {
        go('career-config', state, api);
      }
      break;
    case 'load':
      leaveFlowToNative('reglages', state, api);
      break;
    case 'settings':
      leaveFlowToNative('reglages', state, api);
      break;
    case 'quit':
      window.close?.();
      break;
    case 'back':
      go('launch', state, api);
      break;
    case 'discover-competitions':
      // Applique config IA
      {
        const cfg = getConfig(state);
        state.options ??= {};
        const aiMap = {
          debutant: 'Débutant', amateur: 'Amateur', moyen: 'Moyen',
          superieur: 'Supérieur', professionnel: 'Professionnel'
        };
        state.options.aiDifficulty = aiMap[cfg.ai] || 'Moyen';
        state.career.setupConfig = {
          mode: cfg.mode === 'club-international' ? 'club-international' : cfg.mode,
          reputation: cfg.reputation,
          autosave: cfg.autosave
        };
        api.save?.(state);
      }
      go('competitions-official', state, api);
      break;
    case 'choose-galaxy':
      // Ouvre le setup carrière natif (profil + galaxie + club)
      leaveFlowToNative('accueil', state, api, { openProfile: true });
      break;
    case 'take-office':
      try {
        api.takeOffice?.(state);
        state.career.welcomePending = false;
        api.save?.(state);
      } catch (e) {
        console.warn(e);
      }
      go('club-dashboard', state, api);
      break;
    case 'kickoff':
    case 'simulate-match':
      leaveFlowToNative('arene', state, api, { playMatch: action === 'kickoff' });
      break;
    case 'tactics':
      leaveFlowToNative('arene', state, api);
      break;
    default:
      console.warn('Action FM inconnue', action);
  }
}

function go(screenId, state, api) {
  hideNativeLaunch();
  const cfg = getConfig(state);
  const manager = state.career?.manager || {};
  const club = api.findUserClub?.(state);

  let html = '';
  switch (screenId) {
    case 'launch':
      html = `
        <div class="launch-screen" style="position:relative;min-height:100vh;display:grid;place-items:center;padding:24px">
          <div class="launch-content" style="text-align:center;max-width:480px">
            <p class="launch-kicker" style="letter-spacing:.14em;color:var(--fm-muted);font-size:11px">UNIVERS MANAGER · SAISON GALACTIQUE</p>
            <h1 style="font-size:clamp(28px,5vw,42px);margin:8px 0;color:var(--fm-navy)">CHAMPIONNAT<br><span>GALACTIQUE</span><br>DE DAMES</h1>
            <p class="launch-copy">Bâtis ton héritage. Dirige ton club. Conquiers la galaxie.</p>
            <p class="muted" style="font-size:12px;margin-bottom:18px">24 galaxies · 60 clubs · 8 compétitions</p>
            ${renderLaunchMenuHtml()}
          </div>
        </div>`;
      break;
    case 'career-config':
      html = renderCareerConfigHtml(cfg);
      break;
    case 'competitions-official':
      html = renderCompetitionsOverviewHtml();
      break;
    case 'take-office': {
      const clubName = club?.name || '[Nom du club]';
      html = renderTakeOfficeHtml({
        clubName,
        president: club?.president || 'Le président',
        managerFirst: manager.firstName || '[Prénom]',
        managerLast: manager.lastName || '[Nom]'
      });
      break;
    }
    case 'club-dashboard': {
      const clubName = club?.name || state.career?.manager?.clubName || '[Nom du club]';
      html = renderClubDashboardHtml({
        clubName,
        dayLabel: `Saison ${state.season || 1} · Jour ${state.calendar?.currentDay || state.day || 1}`,
        standings: (api.getStandings?.(state) || []).slice(0, 4).map((r, i) => ({
          pos: i + 1,
          name: r.name || r.clubName || `Club ${i + 1}`,
          pts: r.points ?? r.pts ?? 0
        }))
      });
      break;
    }
    case 'match-day': {
      const clubName = club?.name || 'Domicile';
      html = renderMatchDayShellHtml({
        home: clubName,
        away: '[Adversaire]',
        competition: 'Championnat'
      });
      break;
    }
    default:
      html = renderLaunchMenuHtml();
  }
  mount(html, state, api);
}

function leaveFlowToNative(screen, state, api, opts = {}) {
  const host = document.getElementById(HOST_ID);
  if (host) host.hidden = true;
  showNativeApp();

  // Navigation native
  const link = document.querySelector(`[data-screen-link="${screen}"]`);
  if (link) link.click();
  else if (screen === 'accueil') {
    document.querySelector('[data-screen-link="accueil"]')?.click();
  }

  if (opts.openProfile) {
    setTimeout(() => {
      document.querySelector('#careerProfileSection')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  }
  if (opts.playMatch) {
    setTimeout(() => document.querySelector('#playCalendarMatch')?.click(), 80);
  }

  api.render?.();
}

/**
 * Démarre le parcours FM au boot.
 * api: { save, render, takeOffice, updateDelegation, findUserClub, getStandings }
 */
export function startFmFlow(state, api = {}) {
  try {
    initLandscapeGuidance();
  } catch (e) {
    console.warn('Orientation', e);
  }
  document.body.classList.add('cgd-fm-theme', 'cgd-fm-layout', 'cgd-landscape-first');

  // Si carrière déjà en cours avec manager → dashboard FM puis app native
  if (state?.career?.manager && state?.userClubId && !state?.career?.welcomePending) {
    go('club-dashboard', state, api);
    return;
  }
  // Prise de fonction en attente
  if (state?.career?.welcomePending) {
    go('take-office', state, api);
    return;
  }
  // Sinon menu
  go('launch', state, api);
}

/** Ouvre explicitement la prise de fonction FM (remplace l'overlay natif). */
export function openFmTakeOffice(state, api = {}) {
  go('take-office', state, api);
}

/** Ouvre le jour de match FM puis le damier. */
export function openFmMatchDay(state, api = {}) {
  go('match-day', state, api);
}
