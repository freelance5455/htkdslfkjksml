/**
 * CGD V117 — IA des Managers de Clubs + Branchement des Sélectionneurs
 * Utilise le registre galactique (styles, origines, compétences).
 */

import { MANAGERS_CLUBS, SELECTIONNEURS } from './galactique-registry.js';

const STYLE_MODIFIERS = Object.freeze({
  possession: { homeBonus: 4, awayBonus: 1, captureBias: 0.15, risk: 0.25 },
  contre:     { homeBonus: 1, awayBonus: 5, captureBias: 0.35, risk: 0.45 },
  pression:   { homeBonus: 3, awayBonus: 3, captureBias: 0.55, risk: 0.60 },
  offensif:   { homeBonus: 5, awayBonus: 2, captureBias: 0.70, risk: 0.75 },
  defensif:   { homeBonus: 2, awayBonus: 4, captureBias: 0.10, risk: 0.15 },
  equilibre:  { homeBonus: 3, awayBonus: 3, captureBias: 0.40, risk: 0.40 },
  équilibre: { homeBonus: 3, awayBonus: 3, captureBias: 0.40, risk: 0.40 }
});

/** Retourne le manager AI d'un club (ou null). */
export function getClubManager(state, clubId) {
  const club = (state.divisions || []).flatMap(d => d.clubs || []).find(c => c.id === clubId);
  if (!club) return null;
  if (club.manager?.ai) return club.manager;
  // Fallback registre
  const fromRegistry = MANAGERS_CLUBS.find(m => m.clubId === clubId);
  if (!fromRegistry) return null;
  return {
    id: fromRegistry.id,
    name: fromRegistry.name,
    originGalaxy: fromRegistry.originGalaxy,
    style: fromRegistry.style,
    ai: true
  };
}

/** Modificateur de force selon le style du manager et le contexte (domicile/extérieur). */
export function getManagerStrengthModifier(manager, isHome = true) {
  if (!manager?.style) return 0;
  const mod = STYLE_MODIFIERS[manager.style] || STYLE_MODIFIERS.equilibre;
  return isHome ? mod.homeBonus : mod.awayBonus;
}

/**
 * Influence de l'IA manager sur une simulation de match.
 * Retourne un ajustement de force + biais tactique.
 */
export function applyManagerInfluence(state, fixture) {
  const homeManager = getClubManager(state, fixture.home);
  const awayManager = getClubManager(state, fixture.away);

  const homeMod = getManagerStrengthModifier(homeManager, true);
  const awayMod = getManagerStrengthModifier(awayManager, false);

  return {
    homeManager,
    awayManager,
    homeStrengthBonus: homeMod,
    awayStrengthBonus: awayMod,
    homeStyle: homeManager?.style || 'équilibre',
    awayStyle: awayManager?.style || 'équilibre',
    homeRisk: STYLE_MODIFIERS[homeManager?.style]?.risk ?? 0.4,
    awayRisk: STYLE_MODIFIERS[awayManager?.style]?.risk ?? 0.4
  };
}

/** Décision IA : quel damiste aligner (meilleure forme / niveau selon style). */
export function aiSelectDamiste(club, style = 'équilibre') {
  const damistes = club?.damistes || [];
  if (damistes.length === 0) return null;
  if (damistes.length === 1) return damistes[0];

  const scored = damistes.map(d => {
    const level = Number(d.level) || 50;
    const form = Number(d.form) || 50;
    let score = level * 0.65 + form * 0.35;
    // Style influence
    if (style === 'offensif' || style === 'pression') score += (form > 70 ? 6 : 0);
    if (style === 'defensif') score += (level > form ? 5 : 0);
    if (style === 'contre') score += (form >= 60 ? 4 : -2);
    return { damiste: d, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored[0].damiste;
}

/** Décision IA manager : demander un recrutement si effectif faible. */
export function aiEvaluateRecruitmentNeed(club) {
  const damistes = club?.damistes || [];
  if (damistes.length < 2) return { need: true, urgency: 'critical', reason: 'Effectif incomplet' };
  const avgLevel = damistes.reduce((s, d) => s + (Number(d.level) || 0), 0) / damistes.length;
  const avgForm = damistes.reduce((s, d) => s + (Number(d.form) || 0), 0) / damistes.length;
  if (avgLevel < 45) return { need: true, urgency: 'high', reason: 'Niveau moyen trop faible' };
  if (avgForm < 40) return { need: true, urgency: 'medium', reason: 'Forme collective basse' };
  return { need: false, urgency: 'none', reason: 'Effectif stable' };
}

/** Génère un petit rapport de décision IA pour le journal de carrière. */
export function generateManagerDecisionLog(state, clubId, decisionType, details = {}) {
  const manager = getClubManager(state, clubId);
  if (!manager) return null;
  return {
    type: 'manager-ai-decision',
    day: Number(state.calendar?.currentDay || state.day || 1),
    season: state.season,
    clubId,
    managerId: manager.id,
    managerName: manager.name,
    decisionType,
    style: manager.style,
    details,
    message: details.message || `${manager.name} a pris une décision (${decisionType}).`
  };
}

// ========== SÉLECTIONNEURS ==========

/** Retourne le sélectionneur d'une galaxie. */
export function getSelectionneur(state, galaxyIdOrName) {
  const list = state.world?.selectionneurs || SELECTIONNEURS;
  return list.find(s =>
    s.galaxyId === galaxyIdOrName ||
    s.galaxy === galaxyIdOrName ||
    s.id === galaxyIdOrName
  ) || null;
}

/** Liste complète des sélectionneurs (avec lien galaxie). */
export function getAllSelectionneurs(state) {
  return (state.world?.selectionneurs || SELECTIONNEURS).map(s => ({ ...s }));
}

/**
 * Convocations IA d'un sélectionneur.
 * Choisit jusqu'à 2 damistes parmi les clubs ayant des joueurs de cette origine galactique
 * + les représentants déjà attachés à la galaxie.
 */
export function aiSelectConvocations(state, galaxyIdOrName, maxPlayers = 2) {
  const selectionneur = getSelectionneur(state, galaxyIdOrName);
  if (!selectionneur) return { selectionneur: null, convocations: [], message: 'Sélectionneur introuvable' };

  const galaxyName = selectionneur.galaxy;
  const galaxy = (state.world?.galaxies || []).find(g =>
    g.id === selectionneur.galaxyId || g.name === galaxyName
  );

  // Candidats : représentants galactiques + damistes de clubs ayant la même origine
  const candidates = [];

  // Représentants déjà sur la galaxie
  for (const d of (galaxy?.damistes || [])) {
    candidates.push({
      ...d,
      source: 'galaxy-representative',
      score: (Number(d.level) || 50) * 0.7 + (Number(d.form) || 50) * 0.3 + 8 // bonus représentant
    });
  }

  // Damistes de clubs
  for (const division of state.divisions || []) {
    for (const club of division.clubs || []) {
      if (club.originGalaxy !== galaxyName && club.galaxy !== galaxyName) continue;
      for (const d of (club.damistes || [])) {
        // Éviter les doublons par nom
        if (candidates.some(c => c.name === d.name)) continue;
        candidates.push({
          ...d,
          clubId: club.id,
          clubName: club.name,
          source: 'club',
          score: (Number(d.level) || 50) * 0.65 + (Number(d.form) || 50) * 0.35
        });
      }
    }
  }

  candidates.sort((a, b) => b.score - a.score);
  const selected = candidates.slice(0, maxPlayers);

  return {
    selectionneur,
    galaxyId: selectionneur.galaxyId,
    galaxyName,
    convocations: selected,
    message: selected.length
      ? `${selectionneur.name} a convoqué ${selected.map(p => p.name).join(' et ')}.`
      : `${selectionneur.name} n'a trouvé aucun damiste éligible.`
  };
}

/**
 * Applique les convocations d'un sélectionneur dans l'état
 * (met à jour selection_memberships ou structure équivalente).
 */
export function applyConvocations(state, galaxyIdOrName) {
  const result = aiSelectConvocations(state, galaxyIdOrName, 2);
  if (!result.selectionneur) return result;

  state.world ??= {};
  state.world.selectionMemberships ??= {};
  const key = result.galaxyId || result.galaxyName;
  state.world.selectionMemberships[key] = {
    selectionneurId: result.selectionneur.id,
    selectionneurName: result.selectionneur.name,
    season: state.season,
    day: Number(state.calendar?.currentDay || state.day || 1),
    players: result.convocations.map(p => ({
      id: p.id,
      name: p.name,
      clubId: p.clubId || null,
      source: p.source,
      level: p.level,
      form: p.form
    }))
  };

  // Log
  state.management ??= { careerLog: [] };
  state.management.careerLog ??= [];
  state.management.careerLog.unshift({
    type: 'selection-convocation',
    season: state.season,
    day: Number(state.calendar?.currentDay || state.day || 1),
    galaxy: result.galaxyName,
    selectionneur: result.selectionneur.name,
    players: result.convocations.map(p => p.name),
    message: result.message
  });

  return result;
}

/** Lance les convocations pour toutes les galaxies (début de fenêtre internationale). */
export function runAllSelectionConvocations(state) {
  const results = [];
  for (const s of getAllSelectionneurs(state)) {
    results.push(applyConvocations(state, s.galaxyId || s.galaxy));
  }
  return results;
}

/** Influence du sélectionneur sur la force d'une sélection (matchs internationaux). */
export function getSelectionStrengthBonus(state, galaxyIdOrName) {
  const sel = getSelectionneur(state, galaxyIdOrName);
  if (!sel) return 0;
  // Bonus fixe léger + cohérence d'origine
  return 3;
}

// ========== ÉVOLUTION DES STYLES SELON LES RÉSULTATS ==========

const STYLE_EVOLUTION = {
  offensif:   { onWin: null, onLoss: 'pression', onDraw: null },
  pression:   { onWin: 'offensif', onLoss: 'équilibre', onDraw: null },
  contre:     { onWin: null, onLoss: 'défensif', onDraw: null },
  defensif:   { onWin: 'équilibre', onLoss: null, onDraw: null },
  défensif:   { onWin: 'équilibre', onLoss: null, onDraw: null },
  possession: { onWin: null, onLoss: 'contre', onDraw: null },
  equilibre:  { onWin: null, onLoss: null, onDraw: null },
  équilibre: { onWin: null, onLoss: null, onDraw: null }
};

/**
 * Fait évoluer le style d'un manager AI après un match.
 * - Victoire en offensif/pression peut renforcer le style
 * - Défaite peut pousser vers plus de prudence ou un autre registre
 */
export function evolveManagerStyle(state, clubId, result) {
  // result: 'win' | 'loss' | 'draw'
  const club = (state.divisions || []).flatMap(d => d.clubs || []).find(c => c.id === clubId);
  if (!club?.manager?.ai) return null;

  const current = club.manager.style || 'équilibre';
  const map = STYLE_EVOLUTION[current] || STYLE_EVOLUTION.équilibre;
  let next = null;
  if (result === 'win') next = map.onWin;
  else if (result === 'loss') next = map.onLoss;
  else next = map.onDraw;

  if (!next || next === current) return null;

  const previous = current;
  club.manager.style = next;
  club.manager.styleHistory = club.manager.styleHistory || [];
  club.manager.styleHistory.unshift({
    season: state.season,
    day: Number(state.calendar?.currentDay || state.day || 1),
    from: previous,
    to: next,
    reason: result
  });

  // Log
  state.management ??= { careerLog: [] };
  state.management.careerLog ??= [];
  state.management.careerLog.unshift({
    type: 'manager-style-evolution',
    season: state.season,
    day: Number(state.calendar?.currentDay || state.day || 1),
    clubId,
    managerName: club.manager.name,
    from: previous,
    to: next,
    reason: result,
    message: `${club.manager.name} adapte son style : ${previous} → ${next} (${result}).`
  });

  return { managerId: club.manager.id, from: previous, to: next, reason: result };
}

/**
 * Après un match simulé, fait évoluer les styles des deux managers AI.
 */
export function evolveManagersAfterMatch(state, fixture, matchResult) {
  // matchResult: { winnerSide: 1 | -1 | null }
  if (!fixture || !matchResult) return [];
  const evolutions = [];
  const homeResult = matchResult.winnerSide === 1 ? 'win' : matchResult.winnerSide === -1 ? 'loss' : 'draw';
  const awayResult = matchResult.winnerSide === -1 ? 'win' : matchResult.winnerSide === 1 ? 'loss' : 'draw';

  const e1 = evolveManagerStyle(state, fixture.home, homeResult);
  const e2 = evolveManagerStyle(state, fixture.away, awayResult);
  if (e1) evolutions.push(e1);
  if (e2) evolutions.push(e2);
  return evolutions;
}
