// Simulation IA contre IA utilisant le véritable moteur de dames V117.
// Support des styles de managers (possession, contre, pression, offensif, défensif, équilibre).
import { createInitialBoard, legalMoves, applyMove, gameStatus, countPieces } from './draughts.js';
import { createMatchClock, advanceMatchClock, registerMatchTurn } from './match-clock.js';
import { getArenaRules } from './arena-rules.js';

const STYLE_CAPTURE_BIAS = {
  possession: 0.15, contre: 0.35, pression: 0.55, offensif: 0.70, defensif: 0.10, equilibre: 0.40, équilibre: 0.40
};

function hash(text){let h=2166136261;for(const ch of text){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function unit(seed,index){let x=(seed^Math.imul(index+1,0x9e3779b1))>>>0;x^=x>>>16;x=Math.imul(x,0x7feb352d);x^=x>>>15;x=Math.imul(x,0x846ca68b);x^=x>>>16;return(x>>>0)/4294967296;}
function material(board,side){return board.flat().reduce((s,p)=>s+(Math.sign(p)===side?(Math.abs(p)===2?1.65:1):0),0);}

function chooseMove(board, side, arena, seed, ply, style = 'équilibre') {
  const moves = legalMoves(board, side, { arena });
  if (!moves.length) return null;
  const captureBias = STYLE_CAPTURE_BIAS[style] ?? 0.4;
  let best = -Infinity, choices = [];
  for (const move of moves) {
    const next = applyMove(board, move, { arena });
    const [r, c] = move.path.at(-1).to;
    const piece = next[r][c];
    // Score de base + biais tactique selon le style du manager
    let score = move.captures.length * (80 + captureBias * 40)
      + (Math.abs(piece) === 2 ? 18 : 0)
      + (4.5 - Math.abs(4.5 - r)) * .25
      + (4.5 - Math.abs(4.5 - c)) * .25
      + (material(next, side) - material(next, -side)) * .08;
    // Style défensif privilégie la conservation de matériel
    if (style === 'defensif') score += (material(next, side) - material(board, side)) * 2;
    // Style offensif / pression pousse vers l'avant
    if (style === 'offensif' || style === 'pression') score += (side === 1 ? (7 - r) : r) * 0.4;
    if (score > best + 1e-9) { best = score; choices = [move]; }
    else if (Math.abs(score - best) <= 1e-9) choices.push(move);
  }
  return choices[Math.floor(unit(seed, ply) * choices.length)];
}

/** Deux IA jouent une partie légale complète. Le domicile joue rouge (+1).
 *  Options supplémentaires : homeStyle / awayStyle (styles managers).
 */
export function simulateBoardMatch({
  fixtureId,
  season = 1,
  arena = 'terrestrial',
  homeStrength = 50,
  awayStrength = 50,
  homeStyle = 'équilibre',
  awayStyle = 'équilibre'
}) {
 const rules=getArenaRules(arena),seed=hash(`${fixtureId}|${season}|CGD117-BOARD`);let board=createInitialBoard(),turn=1,elapsedMs=0,plies=0,noProgressPlies=0;const clock=createMatchClock(rules.clock,0);let result=null,reason=null;const maxPlies=600;const performance={home:{moves:0,captures:0,promotions:0,kingMoves:0},away:{moves:0,captures:0,promotions:0,kingMoves:0}};
 while(!result&&plies<maxPlies){
  const status=gameStatus(board,turn,{arena});
  if(status.over){result=status;reason=status.reason;break;}
  const currentStyle = turn === 1 ? homeStyle : awayStyle;
  const move=chooseMove(board,turn,arena,seed,plies,currentStyle);
  if(!move){result={winner:-turn};reason='no-legal-move';break;}
  const strength=turn===1?homeStrength:awayStrength,skill=Math.max(0,Math.min(1,(Number(strength)-30)/70));
  const thinkingMs=900+Math.floor(unit(seed,plies+701)*(4200-skill*1700));
  elapsedMs+=Math.min(20000,thinkingMs);
  const before=countPieces(board);
  const time=advanceMatchClock(clock,elapsedMs,{1:before[1],'-1':before[-1]});
  if(time.expired&&time.result?.reason!=='overtime-started'){result=time.result;reason=time.result.reason;break;}
  const moving=board[move.path[0].from[0]][move.path[0].from[1]];
  const sideStats=turn===1?performance.home:performance.away;
  sideStats.moves++;sideStats.captures+=move.captures.length;
  if(Math.abs(moving)===2)sideStats.kingMoves++;
  board=applyMove(board,move,{arena});
  const[pr,pc]=move.path.at(-1).to;
  if(Math.abs(moving)===1&&Math.abs(board[pr][pc])===2)sideStats.promotions++;
  noProgressPlies=(move.captures.length||Math.abs(moving)===1)?0:noProgressPlies+1;
  plies++;
  const counts=countPieces(board);
  registerMatchTurn(clock,turn,counts);
  if(clock.result){result=clock.result;reason=clock.result.reason;break;}
  if(noProgressPlies>=50){result={winner:null};reason='no-progress-draw';break;}
  const after=gameStatus(board,-turn,{arena});
  if(after.over){result=after;reason=after.reason;break;}
  turn=-turn;
 }
 if(!result){const c=countPieces(board);result={winner:c[1]===c[-1]?null:c[1]>c[-1]?1:-1};reason='simulation-safety-limit';}
 const pieces=countPieces(board);
 return{
   winnerSide:result.winner??null,reason,
   score:result.winner===1?[1,0]:result.winner===-1?[0,1]:[0,0],
   arena,arenaName:rules.name,pieces,plies,elapsedMs,
   turns:{...clock.turns},globalPhase:clock.phase,seed,performance,
   engine:'cgd-draughts-ai-v1',
   styles:{home:homeStyle,away:awayStyle}
 };
}
