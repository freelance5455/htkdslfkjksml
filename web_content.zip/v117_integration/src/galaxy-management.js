/**
 * Vue sportive des 24 galaxies + branchement des sélectionneurs.
 */
import { getSelectionneur, getAllSelectionneurs, aiSelectConvocations, applyConvocations } from './manager-ai.js';

/** Read-only sporting overview for the 24 historical galaxies. */
export function getGalaxyManagementOverview(state) {
  const clubs = (state.divisions || []).flatMap(d => d.clubs || []);
  const galaxies = state.world?.galaxies || [];
  const memberships = state.world?.selectionMemberships || {};

  const rows = galaxies.map((galaxy, index) => {
    const representatives = galaxy.damistes || [];
    const levels = representatives.map(p => Number(p.level) || 0);
    const power = levels.length ? Math.round(levels.reduce((a, b) => a + b, 0) / levels.length) : 0;
    const clubRows = clubs.filter(c =>
      c.galaxyId === galaxy.id ||
      c.galaxy === galaxy.name ||
      c.originGalaxy === galaxy.name
    );
    const clubPower = clubRows.flatMap(c => c.damistes || []).reduce((sum, p) => sum + (Number(p.level) || 0), 0);

    const selectionneur = getSelectionneur(state, galaxy.id || galaxy.name);
    const membership = memberships[galaxy.id] || memberships[galaxy.name] || null;

    return {
      id: galaxy.id || `galaxy-${index + 1}`,
      name: galaxy.name || `Galaxie ${index + 1}`,
      icon: galaxy.icon || '🌌',
      level: galaxy.level || 0,
      representatives: representatives.length,
      representativePower: power,
      clubs: clubRows.length,
      clubPower,
      collectivePower: power + clubPower,
      competitionPoints: Number(galaxy.competitionPoints) || 0,
      selectionneur: selectionneur ? {
        id: selectionneur.id,
        name: selectionneur.name,
        galaxy: selectionneur.galaxy
      } : null,
      currentSquad: membership?.players || [],
      lastConvocationDay: membership?.day || null,
      lastConvocationSeason: membership?.season || null
    };
  });

  rows.sort((a, b) =>
    b.collectivePower - a.collectivePower ||
    b.competitionPoints - a.competitionPoints ||
    a.name.localeCompare(b.name, 'fr')
  );

  return rows.map((row, index) => ({ ...row, rank: index + 1 }));
}

/** Détail d'une galaxie avec sélectionneur et effectif international. */
export function getGalaxyDetail(state, galaxyIdOrName) {
  const overview = getGalaxyManagementOverview(state);
  const row = overview.find(r => r.id === galaxyIdOrName || r.name === galaxyIdOrName);
  if (!row) return null;

  const preview = aiSelectConvocations(state, galaxyIdOrName, 2);
  return {
    ...row,
    selectionneur: row.selectionneur,
    suggestedConvocations: preview.convocations,
    convocationMessage: preview.message
  };
}

/** Force une nouvelle convocation pour une galaxie. */
export function refreshGalaxyConvocations(state, galaxyIdOrName) {
  return applyConvocations(state, galaxyIdOrName);
}

export function validateGalaxyManagement(state) {
  const rows = getGalaxyManagementOverview(state);
  if (rows.length !== 24) throw new Error('Le championnat doit conserver exactement 24 galaxies');
  if (new Set(rows.map(x => x.id)).size !== 24) throw new Error('Identifiants de galaxies dupliqués');

  const missing = rows.filter(r => !r.selectionneur);
  if (missing.length) {
    console.warn(`[GalaxyManagement] ${missing.length} galaxie(s) sans sélectionneur:`, missing.map(m => m.name));
  }
  return true;
}

export { getAllSelectionneurs, getSelectionneur };
