/**
 * Panneau latéral droit type Football Manager.
 * Affiche le contexte de la sélection courante (club, damiste, galaxie, compétition).
 */

function el(tag, attrs = {}, html = '') {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'className') node.className = v;
    else if (k.startsWith('data') || k === 'id' || k === 'role') node.setAttribute(k, v);
    else node[k] = v;
  }
  if (html) node.innerHTML = html;
  return node;
}

export function getSidePanelHost() {
  return document.querySelector('#fmSideContent') || document.querySelector('#fmSidePanel');
}

export function clearSidePanel() {
  const host = getSidePanelHost();
  if (!host) return;
  host.innerHTML = `<p class="muted" style="font-size:12px">Sélectionne un élément pour afficher le détail.</p>`;
}

export function renderClubInSidePanel(club, extra = {}) {
  const host = getSidePanelHost();
  if (!host || !club) return;
  const manager = club.manager;
  const damistes = club.damistes || [];
  host.innerHTML = `
    <h3 style="margin:0 0 8px;color:var(--gold);font-size:13px;text-transform:uppercase">${escape(club.name)}</h3>
    <div class="fm-stat-row"><span>Division</span><span>${escape(extra.divisionName || club.divisionId || '—')}</span></div>
    <div class="fm-stat-row"><span>Origine</span><span>${escape(club.originGalaxy || '—')}</span></div>
    <div class="fm-stat-row"><span>Budget</span><span>${Number(club.budget || 0).toLocaleString('fr-FR')} G</span></div>
    <div class="fm-stat-row"><span>Points</span><span>${Number(club.points || 0)}</span></div>
    <div class="fm-stat-row"><span>Manager</span><span>${escape(manager?.name || 'Vacant')}${manager?.style ? ` · ${escape(manager.style)}` : ''}</span></div>
    <h3 style="margin:14px 0 8px;color:var(--gold);font-size:12px;text-transform:uppercase">Effectif</h3>
    ${damistes.map(d => `
      <div class="fm-stat-row">
        <span>${escape(d.name)} (${d.gender === 'F' || d.gender === 'Féminin' ? 'F' : 'H'})</span>
        <span>Niv. ${Number(d.level) || 0} · Forme ${Number(d.form) || 0}</span>
      </div>`).join('') || '<p class="muted">Aucun damiste</p>'}
  `;
}

export function renderGalaxyInSidePanel(galaxyRow) {
  const host = getSidePanelHost();
  if (!host || !galaxyRow) return;
  const sel = galaxyRow.selectionneur;
  const squad = galaxyRow.currentSquad || [];
  host.innerHTML = `
    <h3 style="margin:0 0 8px;color:var(--gold);font-size:13px;text-transform:uppercase">${escape(galaxyRow.icon || '🌌')} ${escape(galaxyRow.name)}</h3>
    <div class="fm-stat-row"><span>Rang collectif</span><span>#${galaxyRow.rank ?? '—'}</span></div>
    <div class="fm-stat-row"><span>Puissance</span><span>${galaxyRow.collectivePower ?? 0}</span></div>
    <div class="fm-stat-row"><span>Clubs liés</span><span>${galaxyRow.clubs ?? 0}</span></div>
    <div class="fm-stat-row"><span>Sélectionneur</span><span>${escape(sel?.name || '—')}</span></div>
    <h3 style="margin:14px 0 8px;color:var(--gold);font-size:12px;text-transform:uppercase">Effectif international</h3>
    ${squad.length
      ? squad.map(p => `<div class="fm-stat-row"><span>${escape(p.name)}</span><span>Niv. ${p.level ?? '—'}</span></div>`).join('')
      : '<p class="muted" style="font-size:12px">Aucune convocation en cours.</p>'}
  `;
}

export function renderManagerInSidePanel(manager) {
  const host = getSidePanelHost();
  if (!host || !manager) return;
  host.innerHTML = `
    <h3 style="margin:0 0 8px;color:var(--gold);font-size:13px;text-transform:uppercase">${escape(manager.name)}</h3>
    <div class="fm-stat-row"><span>Style</span><span>${escape(manager.style || '—')}</span></div>
    <div class="fm-stat-row"><span>Origine</span><span>${escape(manager.originGalaxy || '—')}</span></div>
    <div class="fm-stat-row"><span>Type</span><span>${manager.ai ? 'IA' : 'Joueur'}</span></div>
  `;
}

function escape(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}
