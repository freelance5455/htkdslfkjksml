// Catalogue historique vérifié dans l'archive V116 fournie par l'utilisateur.
// Ces données sont des bases de migration : elles ne remplacent pas encore les données de carrière.
export const LEGACY_GALAXIES = Object.freeze([
  ['Terra Unie','🌍',90],['Mars Fédérale','🔴',86],['Vénus Impériale','🟡',84],['Mercure Solaire','☀️',80],
  ['Jupiter Majeure','🪐',88],['Saturne des Anneaux','💍',85],['Neptune Abyssale','🌊',82],['Uranus Glaciale','❄️',79],
  ['Pluton Lointaine','🌑',76],['Lune Argentée','🌙',83],['Andromède Unie','🌌',91],['Orion Suprême','🏹',87],
  ['Sirius Doré','⭐',85],['Proxima Libre','🛰️',78],['Kepler Républicaine','🔭',81],['Nébuleuse du Crabe','🦀',75],
  ['Cassiopée Royale','👑',89],['Pégase Céleste','🐎',84],['Centaure Alpha','🏇',82],['Lyra Harmonieuse','🎼',80],
  ['Vega Éternelle','💫',88],['Solarys Impériale','☀️',87],['Éclipse Noire','🌘',83],['Astra Nova','✨',92]
].map(([name,icon,level])=>Object.freeze({name,icon,level})));

const LEGENDARY_PROFILES = [
  ['Driss','block','🧱'],['Oyode','thunder','⚡'],['Ami','freeze','🧊'],["P'tit",'fire','🔥'],['Anliou','cloak','👻'],
  ['Koro','impossible','♾️'],['Adams','stop','✋'],['Diak','hurricane','🌬️'],['Traoré','magma','🌋'],['Ranji','tsunami','🌊'],
  ['Bah','whirl','🌀'],['Kader','fog','🌫️'],['Isaac','sand','🌪️'],
  ['Terrax','stone','🪨'],['Marsa','red-comet','☄️'],['Vénor','solar-flare','🌞'],['Mercurion','speed','💨'],
  ['Jovian','gravity','🪐'],['Saturnis','rings','💍'],['Néptor','abyss','🐋'],['Uranis','ice','🧊'],
  ['Plutark','shadow','🌑'],['Lunaris','moonlight','🌙'],['Andromar','cosmic-wave','🌌']
];
// Une origine distincte par légendaire : l'ordre suit le registre des 24 galaxies.
export const LEGENDARY_DAMISTES = Object.freeze(LEGENDARY_PROFILES.map(([name,power,icon],index)=>Object.freeze({
  id:`legend-${String(index+1).padStart(2,'0')}`,name,power,icon,level:99,price:2500000,immortal:true,
  originGalaxy:LEGACY_GALAXIES[index].name,originGalaxyIndex:index+1
})));

export const SPECIAL_ARENAS = Object.freeze([
  {name:'Terrestre',rule:'Règles classiques.'},
  {name:'Néon',rule:'Blitz néon : chronomètre de 2 minutes.',timeSeconds:120},
  {name:'Cristalline',rule:'Un pion qui termine son coup sur un cristal est couronné dame.',crystals:[[4,3],[4,7],[5,2],[5,6]]},
  {name:'Gravitationnelle',rule:'Hors prise, les dames avancent de 3 cases maximum.',maxKingQuietMove:3},
  {name:'Volcanique',rule:'Tout pion qui termine son coup sur une case de lave est détruit.',lava:[[4,1],[4,5],[5,4],[5,8]]},
  {name:'Océanique',rule:'Les pions ne peuvent prendre qu’en avant ; les dames conservent leurs prises.',menCaptureForwardOnly:true},
  {name:'Temporelle',rule:'Pas de chronomètre ; limite de 40 coups par camp, puis comparaison des pions.',maxTurnsPerSide:40},
  {name:'Dimensionnelle',rule:'Couronnement dès l’avant-dernière rangée.',earlyPromotion:true},
  {name:'Galactique Suprême',rule:'Deux cases de lave, deux cristaux et chronomètre de 2 min 30.',timeSeconds:150,lava:[[4,5],[5,4]],crystals:[[4,1],[5,8]]}
].map(x=>Object.freeze(x)));

export const VISUAL_ARENAS = Object.freeze(['Stellaire','Cyber Nexus','Impériale','Boréale','Désertique','Jungle','Métropole','Solaire','Obsidienne','Céleste','Nébuleuse']);
export const CLUB_ARENA_SLOTS = Object.freeze(Array.from({length:60},(_,i)=>Object.freeze({slot:i+1,id:`club-arena-${String(i+1).padStart(2,'0')}`,assignedClubId:null})));

export const BANKS = Object.freeze(['Global Company','Gold Bank','Venus Gold','Universal Bank','OD Gold','Vitrine Gold','Cursus Gold','Hola Gold','Royal Gold','Fédéral Bank']);
export const SPONSORS = Object.freeze(['Nébula Cola','Stellar Sportswear','Quantum Motors','Hyperion Telecom','Andromeda Premium','Aurora Galactic Energy','Titanium Luxury Group','Orion Financial Holdings','Zenith Tech Industries','Nova Crown International','Eclipse Motorsports','Galaxy One Corporation']);
export const PROMOTERS = Object.freeze(['Cosmic Promotions','Arena Live Productions','HoloTV Sports','StellarCast Network','Imperial Events Group','Cosmos Media Alliance','Galactic Show Company','Champions Live International']);
export const PARTNERS = Object.freeze(['Banque Centrale Galactique','Crédit Stellaire','AstroJet Cargo','Galactic Airways','Institut Médical Orbital','Académie Spatiale','Hôtels Étoilés','Agence Spatiale Mondiale','Quantum Capital Partners','Imperial Health Consortium','Orbital Performance Institute','Stellar Logistics Group','Royal Nebula Resorts','Galactic Assurance Union','Fondation Astro Excellence','Nexus Infrastructure Group']);
export const FIRMS = Object.freeze([
  ['GMC','Aviation et transport'],['SuperNova','Transport et logistique'],['GalaTec','Aviation et ingénierie'],['Vortex','Transport orbital'],['Nova Corp','Aviation et infrastructures'],['Tetra Vortex','Mobilité intergalactique'],['Genesis','Transport premium'],
  ['Android Corp','Équipementier sportif'],['Cloud','Tenues et équipements'],['Bios Seven','Technologies sportives'],['Spark Go','Équipement et accessoires'],['AviaTek','Équipements techniques'],['Space X','Matériel et innovation'],
  ['FoxNew','Médias et actualités'],['Universal Media','Diffusion sportive'],['Music Universal','Musique et événements'],['NewVox','Presse et communication'],['Flash New','Actualités en direct'],
  ['Orion Immobilier','Immobilier et stades'],['Galaxy Marketing','Marketing et publicité'],['Stellar Assurance','Assurance et protection'],['Cosmos Invest','Investissement sportif']
].map(([name,sector])=>Object.freeze({name,sector})));

export const LEGACY_COUNTS = Object.freeze({galaxies:24,clubArenaSlots:60,specialGameplayArenas:9,visualArenaVariants:11,legendaryDamistes:24,banks:10,sponsors:12,promoters:8,partners:16,firms:22});
export function validateLegacyCatalog(){
  const checks=[['galaxies',LEGACY_GALAXIES],['clubArenaSlots',CLUB_ARENA_SLOTS],['specialGameplayArenas',SPECIAL_ARENAS],['visualArenaVariants',VISUAL_ARENAS],['legendaryDamistes',LEGENDARY_DAMISTES],['banks',BANKS],['sponsors',SPONSORS],['promoters',PROMOTERS],['partners',PARTNERS],['firms',FIRMS]];
  for(const [key,list] of checks)if(list.length!==LEGACY_COUNTS[key])throw new Error(`Catalogue historique incohérent : ${key}`);
  if(new Set(LEGENDARY_DAMISTES.map(p=>p.name)).size!==24)throw new Error('Noms de légendaires non uniques');
  if(new Set(LEGENDARY_DAMISTES.map(p=>p.originGalaxy)).size!==24 || LEGENDARY_DAMISTES.some(p=>!LEGACY_GALAXIES.some(g=>g.name===p.originGalaxy)))throw new Error('Origine galactique des légendaires invalide');
  return true;
}
