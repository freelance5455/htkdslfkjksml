import { DIVISIONS, COMPETITIONS } from './config.js';
import { LEGACY_GALAXIES, LEGENDARY_DAMISTES, SPECIAL_ARENAS, VISUAL_ARENAS, CLUB_ARENA_SLOTS, BANKS, SPONSORS, PROMOTERS, PARTNERS, FIRMS, validateLegacyCatalog } from './legacy-catalog.js';
import { populateRosterCatalog, validateRosterCatalog } from './roster-catalog.js';
import { CLUBS_REGISTRY, MANAGERS_CLUBS, SELECTIONNEURS, DAMISTES_REGISTRY, GALAXIES } from './galactique-registry.js';

function createLegacyWorldState() {
  validateLegacyCatalog();
  return {
    catalogVersion: 3,
    galaxies: GALAXIES.map(g => ({ ...g })),
    legendaryDamistes: LEGENDARY_DAMISTES.map(x => ({ ...x })),
    specialArenas: SPECIAL_ARENAS.map(x => ({ ...x })),
    visualArenas: [...VISUAL_ARENAS],
    clubArenaSlots: CLUB_ARENA_SLOTS.map(x => ({ ...x })),
    banks: [...BANKS],
    sponsors: [...SPONSORS],
    promoters: [...PROMOTERS],
    partners: [...PARTNERS],
    firms: FIRMS.map(x => ({ ...x })),
    // Nouveaux registres intégrés
    managersClubs: MANAGERS_CLUBS.map(m => ({ ...m })),
    selectionneurs: SELECTIONNEURS.map(s => ({ ...s }))
  };
}

export function createInitialState() {
  const divisions = DIVISIONS.map(d => {
    const registry = CLUBS_REGISTRY[d.id] || [];
    return {
      ...d,
      status: d.initial ? 'active' : 'announced',
      clubs: registry.map((template, i) => makeClubFromRegistry(d.id, template, i))
    };
  });

  const firstClubId = divisions[0]?.clubs?.[0]?.id || 'club-sl-01';

  const initial = {
    schemaVersion: 1, season: 1, day: 1, phase: 'regular-season',
    career: { mode: null, manager: null, managerDraft: null, started: false, jobOffers: [], applications: [], history: [] },
    options: { aiDifficulty: 'Moyen' },
    divisions,
    competitions: COMPETITIONS.map(c => ({ ...c, season: null, status: 'pending', fixtures: [] })),
    calendar: { fixtures: [], processedFixtureIds: [], lastGeneratedSeason: null, lunarThursdays: [], officialCalendars: {}, currentDate: null, currentDay: 1, competitionEvents: [], scheduleValidation: null },
    expansion: { ligueC: { announced: true, activated: false, activationSeason: 3 }, ligueD: { announced: true, activated: false, activationSeason: 5 } },
    history: { seasons: [], awards: [], notices: [] },
    dameOr: { version: 1, seasons: {}, history: [] },
    management: { inbox: [], relations: { boardConfidence: 50, supporterSatisfaction: 50, mediaReputation: 50, playerMorale: {} }, press: { history: [] }, commercialOffers: [], commercialContracts: [], contractNegotiations: [], transferOffers: [], transferHistory: [], careerLog: [], offerMilestones: [], processedEvents: [] },
    world: createLegacyWorldState(),
    userClubId: firstClubId,
    userGalaxyId: null,
    userNationId: null,
    createdAt: new Date().toISOString()
  };
  populateRosterCatalog(initial);
  return initial;
}

function makeClubFromRegistry(divisionId, template, index) {
  const managerTemplate = MANAGERS_CLUBS.find(m => m.clubId === template.id);
  const damistesTemplates = DAMISTES_REGISTRY[template.id] || [
    { name: 'Damiste 1', gender: 'H' },
    { name: 'Damiste 2', gender: 'F' }
  ];

  const levelBase = divisionId === 'super-league' ? 72 : divisionId === 'ligue-a' ? 64 : divisionId === 'ligue-b' ? 56 : divisionId === 'ligue-c' ? 48 : 40;

  return {
    id: template.id,
    name: template.name,
    divisionId,
    originGalaxy: template.originGalaxy,
    manager: managerTemplate ? {
      id: managerTemplate.id,
      name: managerTemplate.name,
      originGalaxy: managerTemplate.originGalaxy,
      style: managerTemplate.style,
      ai: true
    } : null,
    budget: 800000 + (levelBase * 12000) + (index * 15000),
    played: 0, won: 0, drawn: 0, lost: 0, gf: 0, ga: 0, points: 0,
    damistes: damistesTemplates.map((d, slot) => ({
      id: `${template.id}-d${slot + 1}`,
      name: d.name,
      gender: d.gender === 'H' ? 'M' : 'F',
      level: levelBase + ((index * 3 + slot * 5) % 18),
      form: 55 + ((index * 7 + slot * 11) % 35),
      age: 20 + ((index + slot * 3) % 12),
      potential: Math.min(99, levelBase + 12 + (index % 8)),
      origin: template.originGalaxy
    }))
  };
}

export function validateState(s) {
  if (!s || s.schemaVersion !== 1 || !Array.isArray(s.divisions) || !Array.isArray(s.calendar?.fixtures)) throw new Error('État de carrière invalide');
  if (s.calendar.currentDay !== undefined && (!Number.isInteger(s.calendar.currentDay) || s.calendar.currentDay < 1)) throw new Error('Jour courant du calendrier invalide');
  if (s.calendar.scheduleValidation && !s.calendar.scheduleValidation.valid) throw new Error('Le calendrier contient un chevauchement de compétitions ou de rencontres de club');
  if (s.world && (s.world.galaxies?.length !== 24 || s.world.clubArenaSlots?.length !== 60 || s.world.legendaryDamistes?.length !== 24)) throw new Error('Catalogue galactique historique incomplet');
  const clubIds = s.divisions.flatMap(d => d.clubs.map(c => c.id));
  if (new Set(clubIds).size !== clubIds.length) throw new Error('Identifiant de club dupliqué');
  for (const d of s.divisions) for (const c of d.clubs) if (c.damistes?.length !== 2) throw new Error(`Le club ${c.id} doit posséder exactement deux damistes`);
  if (s.world?.rosterCatalogVersion) validateRosterCatalog(s);
  const ids = s.calendar.fixtures.map(f => f.id);
  if (new Set(ids).size !== ids.length) throw new Error('Identifiant de match dupliqué');
  return true;
}

export function saveState(state, storage = globalThis.localStorage) {
  validateState(state);
  storage?.setItem('cgd-v117-career', JSON.stringify(state));
}
export function loadState(storage = globalThis.localStorage) {
  const raw = storage?.getItem('cgd-v117-career');
  if (!raw) return null;
  const parsed = JSON.parse(raw);
  // Migration douce des sauvegardes du prototype antérieures au catalogue galactique.
  if (!parsed.world) parsed.world = createLegacyWorldState();
  else {
    // Migration des sauvegardes antérieures : compléter les légendaires et leurs galaxies d'origine.
    const current = new Map((parsed.world.legendaryDamistes || []).map(p => [p.name, p]));
    parsed.world.legendaryDamistes = LEGENDARY_DAMISTES.map(template => ({ ...template, ...(current.get(template.name) || {}), originGalaxy: template.originGalaxy, originGalaxyIndex: template.originGalaxyIndex }));
    parsed.world.catalogVersion = 2;
  }
  parsed.career ??= { mode: null, manager: null, started: false, jobOffers: [], applications: [], history: [] };
  parsed.career.managerDraft ??= null; parsed.career.jobOffers ??= []; parsed.career.applications ??= []; parsed.career.history ??= [];
  parsed.options ??= { aiDifficulty: 'Moyen' }; parsed.options.aiDifficulty ??= 'Moyen';
  parsed.dameOr ??= { version: 1, seasons: {}, history: [] };
  parsed.dameOr.version ??= 1; parsed.dameOr.seasons ??= {}; parsed.dameOr.history ??= [];
  parsed.management ??= { inbox: [], relations: { boardConfidence: 50, supporterSatisfaction: 50, mediaReputation: 50, playerMorale: {} }, press: { history: [] }, commercialOffers: [], commercialContracts: [], contractNegotiations: [], transferOffers: [], transferHistory: [], careerLog: [], offerMilestones: [], processedEvents: [] };
  parsed.management.inbox ??= []; parsed.management.relations ??= { boardConfidence: 50, supporterSatisfaction: 50, mediaReputation: 50, playerMorale: {} };
  parsed.management.relations.playerMorale ??= {}; parsed.management.press ??= { history: [] }; parsed.management.press.history ??= [];
  parsed.management.commercialOffers ??= []; parsed.management.commercialContracts ??= []; parsed.management.contractNegotiations ??= []; parsed.management.transferOffers ??= []; parsed.management.transferHistory ??= []; parsed.management.careerLog ??= []; parsed.management.offerMilestones ??= []; parsed.management.processedEvents ??= [];
  for (const division of parsed.divisions) for (const club of division.clubs) club.payrollCommitment ??= 0;
  populateRosterCatalog(parsed);
  parsed.userGalaxyId ??= null;
  parsed.userNationId ??= null;
  parsed.calendar.lunarThursdays ??= [];
  parsed.calendar.officialCalendars ??= {};
  parsed.calendar.currentDate ??= null;
  parsed.calendar.currentDay ??= 1;
  parsed.calendar.competitionEvents ??= [];
  parsed.calendar.scheduleValidation ??= null;
  // Migration rétrocompatible : ajouter la Coupe Fédéral sans remplacer les sept compétitions historiques.
  const existingCompetitions = new Map((parsed.competitions || []).map(c => [c.id, c]));
  parsed.competitions = COMPETITIONS.map(template => ({ ...template, ...(existingCompetitions.get(template.id) || {}), id: template.id, name: template.name, authority: template.authority, calendarEngineReady: template.calendarEngineReady }));
  validateState(parsed); return parsed;
}
