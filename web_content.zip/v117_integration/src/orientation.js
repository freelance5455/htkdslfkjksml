/**
 * CGD V117 — Orientation paysage forcée (esprit Football Manager / tablette).
 * Le jeu est conçu exclusivement pour le paysage horizontal.
 * Le portrait n'est plus une option de confort : il affiche un écran de verrouillage.
 */

export function isPortrait({ width, height } = {}) {
  const w = width ?? globalThis.innerWidth;
  const h = height ?? globalThis.innerHeight;
  return h > w;
}

export function shouldShowLandscapeGuidance({ width, height, coarsePointer = false } = {}) {
  // Toujours bloquer le portrait, tactile ou non (expérience FM desktop/tablette)
  return isPortrait({ width, height });
}

export function initLandscapeGuidance({ doc = globalThis.document, win = globalThis.window } = {}) {
  if (!doc?.body || !win) return null;

  // Marqueur global pour le CSS
  doc.documentElement.classList.add('cgd-landscape-first');
  doc.body.classList.add('cgd-fm-layout');

  const overlay = doc.createElement('aside');
  overlay.className = 'orientation-guidance orientation-lock';
  overlay.id = 'orientationGuidance';
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  overlay.setAttribute('aria-labelledby', 'orientationGuidanceTitle');
  overlay.innerHTML = `
    <div class="orientation-card">
      <div class="orientation-icon" aria-hidden="true">↻</div>
      <h2 id="orientationGuidanceTitle">Affichage paysage requis</h2>
      <p>
        Le <strong>Championnat Galactique de Dames</strong> est conçu comme un jeu de gestion
        en <strong>paysage horizontal</strong> (tablette / bureau), à la manière de Football Manager.
        Tourne ton appareil pour continuer.
      </p>
      <div class="orientation-actions">
        <button type="button" class="primary-action" data-orientation-lock>Activer le paysage</button>
      </div>
      <p class="orientation-note" aria-live="polite"></p>
    </div>`;
  doc.body.append(overlay);

  const note = overlay.querySelector('.orientation-note');

  const lockLandscape = async () => {
    try {
      if (doc.documentElement.requestFullscreen && !doc.fullscreenElement) {
        await doc.documentElement.requestFullscreen().catch(() => {});
      }
      if (win.screen?.orientation?.lock) {
        await win.screen.orientation.lock('landscape');
        note.textContent = 'Paysage activé.';
      } else {
        note.textContent = 'Tourne physiquement ton appareil en mode paysage.';
      }
    } catch {
      note.textContent = 'Tourne physiquement ton appareil en mode paysage.';
    }
  };

  const update = () => {
    const portrait = isPortrait({ width: win.innerWidth, height: win.innerHeight });
    overlay.hidden = !portrait;
    doc.body.classList.toggle('orientation-portrait-blocked', portrait);
    doc.body.classList.toggle('orientation-landscape', !portrait);
  };

  overlay.querySelector('[data-orientation-lock]')?.addEventListener('click', lockLandscape);

  win.addEventListener('resize', update, { passive: true });
  win.addEventListener('orientationchange', update, { passive: true });
  if (win.screen?.orientation) {
    win.screen.orientation.addEventListener?.('change', update);
  }

  // Tentative de verrouillage dès le démarrage (si API disponible)
  lockLandscape().finally(update);
  update();

  return { update, lockLandscape, overlay };
}
