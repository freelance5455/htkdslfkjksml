import { ensureClubOffice, updateBoardDomain } from './manager-office.js';

const clamp=(n,min,max)=>Math.max(min,Math.min(max,Number(n)||0));
const dayOf=s=>Number(s?.calendar?.currentDay||s?.day||1);

export function proposeStaffContract(state, staffId, terms={}) {
  const found=ensureClubOffice(state); if(!found) throw new Error('Aucun club dirigé.');
  const member=found.office.staff.find(x=>x.id===staffId||x.role===staffId); if(!member) throw new Error('Membre du staff introuvable.');
  const wagePerDay=Number(terms.wagePerDay), duration=Number(terms.duration), bonus=Number(terms.bonus||0);
  if(!Number.isFinite(wagePerDay)||wagePerDay<0||wagePerDay>100000) throw new Error('Le salaire journalier doit être compris entre 0 et 100 000 Gold.');
  if(!Number.isInteger(duration)||duration<1||duration>5) throw new Error('La durée doit être comprise entre 1 et 5 saisons.');
  if(!Number.isFinite(bonus)||bonus<0||bonus>10000000) throw new Error('La prime de signature est invalide.');
  member.negotiation={id:`staff-${member.id}-${dayOf(state)}`,status:'proposed',terms:{wagePerDay,duration,bonus},proposedDay:dayOf(state)};
  return structuredClone(member.negotiation);
}

export function respondStaffContract(state, staffId, response, counter={}) {
  const found=ensureClubOffice(state); if(!found) throw new Error('Aucun club dirigé.');
  const member=found.office.staff.find(x=>x.id===staffId||x.role===staffId); const n=member?.negotiation;
  if(!n||!['proposed','countered','accepted'].includes(n.status)) throw new Error('Aucune négociation de contrat active.');
  if(response==='accept') n.status='accepted';
  else if(response==='reject') n.status='rejected';
  else if(response==='counter') {
    const wagePerDay=Number(counter.wagePerDay),duration=Number(counter.duration),bonus=Number(counter.bonus||0);
    if(!Number.isFinite(wagePerDay)||wagePerDay<0||wagePerDay>100000||!Number.isInteger(duration)||duration<1||duration>5||!Number.isFinite(bonus)||bonus<0||bonus>10000000) throw new Error('Contre-proposition invalide.');
    n.counterTerms={wagePerDay,duration,bonus}; n.status='countered';
  } else throw new Error('Réponse de négociation inconnue.');
  n.responseDay=dayOf(state); return structuredClone(n);
}

export function signStaffContract(state, staffId, acceptCounter=false) {
  const found=ensureClubOffice(state); if(!found) throw new Error('Aucun club dirigé.');
  const member=found.office.staff.find(x=>x.id===staffId||x.role===staffId); const n=member?.negotiation;
  if(!n||!['accepted','countered'].includes(n.status)) throw new Error('Le contrat doit être accepté par les deux parties avant signature.');
  if(n.status==='countered'&&!acceptCounter) throw new Error('La contre-proposition doit être acceptée explicitement.');
  const terms=n.status==='countered'?n.counterTerms:n.terms;
  if(found.office.finance.cash<terms.bonus) throw new Error('Trésorerie insuffisante pour payer la prime de signature.');
  found.office.finance.cash-=terms.bonus; found.club.budget=found.office.finance.cash;
  member.contract={status:'active',wagePerDay:terms.wagePerDay,duration:terms.duration,bonus:terms.bonus,startDay:dayOf(state),expiresSeason:Number(state.season||1)+terms.duration-1};
  n.status='signed'; n.signedDay=dayOf(state); member.negotiation=null;
  found.office.finance.ledger??=[]; found.office.finance.ledger.unshift({day:dayOf(state),income:0,costs:terms.bonus,net:-terms.bonus,balance:found.office.finance.cash,reason:`Prime de signature · ${member.label}`});
  return structuredClone(member.contract);
}

export function calculateStaffPerformanceModifiers(state) {
  const found=ensureClubOffice(state); if(!found) return {training:0,youth:0,scouting:0,matchPreparation:0,recovery:0};
  const staff=found.office.staff; const rating=role=>Number(staff.find(x=>x.role===role||x.id===role)?.rating||50);
  const delegated=found.office.delegation;
  return {
    training:Math.round((rating('coach')-50)*0.2),
    youth:Math.round((rating('youth')-50)*0.2),
    scouting:Math.round((rating('scout')-50)*0.2),
    matchPreparation:delegated['match-preparation']?Math.round((rating('assistant')-50)*0.2):0,
    recovery:Math.round((rating('physio')-50)*0.2)
  };
}

/** Applique une seule fois par journée les effets de l'entraîneur et du kiné.
 * La progression reste fractionnaire et plafonnée : aucun gain instantané abusif.
 */
export function processDailyStaffDevelopment(state) {
  const found=ensureClubOffice(state);
  if(!found) return {processed:false,players:[],reason:'no-club'};
  const {club,office}=found;
  const day=dayOf(state);
  if(Number(office.lastStaffDevelopmentDay)===day) return {processed:false,players:[],reason:'already-processed'};
  const modifiers=calculateStaffPerformanceModifiers(state);
  const facilityFactor=0.75+Math.max(1,Math.min(10,Number(office.facilities.training)||1))*0.05;
  const developmentPerDay=Math.max(0.005,Math.min(0.12,(0.02+Math.max(0,modifiers.training)*0.004+(office.delegation['youth-advice']?Math.max(0,modifiers.youth)*0.002:0))*facilityFactor));
  const recoveryPerDay=Math.max(0,Math.min(0.5,0.05+Math.max(0,modifiers.recovery)*0.02));
  const players=[];
  for(const player of club.damistes||[]) {
    const beforeLevel=Number(player.level)||0, beforeForm=Number(player.form)||0;
    player.staffDevelopmentProgress=Math.max(0,Number(player.staffDevelopmentProgress)||0)+developmentPerDay;
    let levelsGained=0;
    while(player.staffDevelopmentProgress>=1&&Number(player.level)<100){player.staffDevelopmentProgress-=1;player.level=Math.min(100,(Number(player.level)||0)+1);levelsGained++;}
    if(Number(player.level)>=100) player.staffDevelopmentProgress=0;
    player.form=Math.min(100,beforeForm+recoveryPerDay);
    players.push({id:player.id,levelsGained,level:Number(player.level)||0,form:Number(player.form)||0,developmentPerDay,recoveryPerDay,levelChanged:(Number(player.level)||0)!==beforeLevel,formChanged:(Number(player.form)||0)!==beforeForm});
  }
  office.lastStaffDevelopmentDay=day;
  office.staffDevelopmentHistory??=[];
  office.staffDevelopmentHistory.unshift({day,developmentPerDay,recoveryPerDay,players:players.map(p=>({id:p.id,levelsGained:p.levelsGained}))});
  office.staffDevelopmentHistory=office.staffDevelopmentHistory.slice(0,30);
  return {processed:true,day,players,developmentPerDay,recoveryPerDay};
}

/** Bonus de préparation borné pour les simulations automatiques du club dirigé. */
export function getStaffMatchPreparationBonus(state) {
  const modifiers=calculateStaffPerformanceModifiers(state);
  return Math.max(-2.5,Math.min(2.5,modifiers.matchPreparation*0.25));
}

export function processStaffPayroll(state) {
  const found=ensureClubOffice(state); if(!found) return {paid:0,shortfall:0,staff:[]};
  const active=found.office.staff.filter(x=>x.contract?.status==='active');
  const due=active.reduce((sum,x)=>sum+Math.max(0,Number(x.contract.wagePerDay)||0),0);
  const paid=Math.min(found.office.finance.cash,due); const shortfall=due-paid;
  found.office.finance.cash-=paid; found.club.budget=found.office.finance.cash;
  if(due>0){found.office.finance.ledger??=[];found.office.finance.ledger.unshift({day:dayOf(state),income:0,costs:paid,net:-paid,balance:found.office.finance.cash,reason:'Masse salariale quotidienne du staff'});found.office.finance.ledger=found.office.finance.ledger.slice(0,60);}
  if(shortfall>0){updateBoardDomain(state,'Finances',-2,'Retard de paiement du staff');for(const member of active)member.contract.paymentStatus='partially-paid';}
  else for(const member of active)member.contract.paymentStatus='paid';
  return {paid,shortfall,staff:active.map(x=>x.id)};
}

export function evaluateManagerSecurity(state) {
  const found=ensureClubOffice(state); if(!found) return {dismissed:false,reason:'no-club'};
  const board=found.office.board; const confidence=Number(board.confidence||0);
  board.lowConfidenceDays=confidence<15?(Number(board.lowConfidenceDays)||0)+1:0;
  if(board.lowConfidenceDays<7) return {dismissed:false,lowConfidenceDays:board.lowConfidenceDays,confidence};
  const manager=state.career?.manager,club=found.club; if(!manager) return {dismissed:false,reason:'no-manager'};
  const day=dayOf(state); const event={type:'dismissal',clubId:club.id,clubName:club.name,season:state.season,day,confidence,reason:'Confiance du conseil inférieure à 15/100 pendant sept jours consécutifs'};
  manager.clubId=null; manager.mode='unemployed'; manager.history??=[]; manager.history.unshift(event);
  state.career.mode='unemployed'; state.career.history??=[]; state.career.history.unshift(event);
  club.manager=null; state.userClubId=null;
  return {dismissed:true,event};
}

export function validateStaffContracts(state) {
  const found=ensureClubOffice(state); if(!found) return true;
  for(const member of found.office.staff){const c=member.contract;if(!c)continue;if(c.status!=='active'||!Number.isFinite(c.wagePerDay)||c.wagePerDay<0||!Number.isInteger(c.duration)||c.duration<1||c.duration>5)throw new Error(`Contrat du staff invalide : ${member.id}`);}
  return true;
}
