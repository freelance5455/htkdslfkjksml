/**
 * CGD V117 — Parcours type Football Manager 27 (maquettes utilisateur)
 *
 * Flux imposé :
 *  1. Menu principal
 *  2. Configurer la carrière (mode, IA, réputation)
 *  3. Compétition officielle (8 compétitions)
 *  4. Galaxie & club
 *  5. Prise de fonction (message présidence, objectifs, staff)
 *  6. Tableau de bord club
 *  7. … modules gestion …
 *  8. Terrain (damier) le jour de match
 */

const COMPETITIONS = [
  { id: 'championnats', name: 'Championnats', org: 'FGD', text: '5 divisions de 12 clubs, 22 journées. Le samedi · promotions et relégations.' },
  { id: 'coupe-des-clubs', name: 'Coupe des Clubs', org: 'FGD', text: '7 tours à élimination directe. Le jeudi lunaire, jusqu’à la finale.' },
  { id: 'intergalactique-clubs', name: 'Intergalactique des Clubs', org: 'AGD', text: '32 clubs, 8 groupes de 4, 63 matchs. Tous les 4 ans, après la saison.' },
  { id: 'coupe-galactique', name: 'Coupe Galactique', org: 'FGD', text: 'Élimination directe à 8. Le mercredi, aux journées 6, 12 et 18.' },
  { id: 'champions-league', name: 'Champions League', org: 'FGD', text: '32 clubs, 8 groupes de 4, puis élimination. Le mardi · 111 matchs jusqu’à la finale.' },
  { id: 'coupe-intergalactique', name: 'Coupe Intergalactique', org: 'AGD', text: '24 sélections de galaxies, 6 groupes. Tous les 3 ans · 51 matchs.' },
  { id: 'coupe-federal', name: 'Coupe Fédéral', org: 'AGD', text: 'Élimination directe. Le dimanche.' },
  { id: 'dame-or', name: 'Dame d’Or', org: 'FGD + AGD', text: 'Classement individuel de la saison. Récompense annuelle, pas une coupe.' },
  { id: 'coupe-lunaire', name: 'Coupe Lunaire', org: 'AGD', text: '8 représentants, 3 tours. 12e mois lunaire · 7 matchs.' }
];

const CONFIDENCE_METERS = [
  { id: 'matchs', label: 'Matchs', value: 55 },
  { id: 'supporters', label: 'Supporters', value: 48 },
  { id: 'finances', label: 'Finances', value: 62 },
  { id: 'transferts', label: 'Transferts', value: 40 },
  { id: 'harmonie', label: 'Harmonie', value: 50 },
  { id: 'jeunes', label: 'Jeunes', value: 45 }
];

const SEASON_OBJECTIVES = [
  { title: 'Championnat', text: 'Terminer dans la première moitié du classement.' },
  { title: 'Coupes', text: 'Atteindre les quarts de finale d’une coupe.' },
  { title: 'Finances', text: 'Garder la trésorerie positive.' },
  { title: 'Jeunes', text: 'Faire jouer un jeune de l’académie.' }
];

const STAFF_DELEGATIONS = [
  { id: 'prep', label: 'Préparation des matchs' },
  { id: 'prets', label: 'Prêts' },
  { id: 'conseils', label: 'Conseils' },
  { id: 'jeunes', label: 'Suivi des jeunes' }
];

function esc(v) {
  return String(v ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

/** Menu principal (maquette) */
export function renderLaunchMenuHtml() {
  return `
  <div class="launch-menu fm-launch-menu" role="navigation" aria-label="Menu principal">
    <button type="button" class="launch-button btn-gold" data-fm-action="new-career">
      <span>✦</span> Nouvelle carrière
      <small style="display:block;font-weight:600;opacity:.85;margin-top:4px">Crée ton manager, puis choisis ton club</small>
    </button>
    <button type="button" class="launch-item" data-fm-action="continue">Continuer<br><small class="muted">Reprendre la dernière carrière</small></button>
    <button type="button" class="launch-item" data-fm-action="load">Charger une sauvegarde<br><small class="muted">Choisir parmi tes carrières</small></button>
    <button type="button" class="launch-item" data-fm-action="settings">Paramètres<br><small class="muted">Niveau de l’IA, affichage</small></button>
    <button type="button" class="launch-item" data-fm-action="quit">Quitter<br><small class="muted">Fermer le jeu</small></button>
  </div>`;
}

/** Configuration de carrière (maquette) */
export function renderCareerConfigHtml(state = {}) {
  const mode = state.mode || 'club';
  const ai = state.ai || 'moyen';
  const rep = state.reputation || 'inconnu';
  const autosave = state.autosave !== false;

  const modes = [
    { id: 'club', title: 'Club', desc: 'Un seul club, saison après saison.' },
    { id: 'club-international', title: 'Club et international', desc: 'Un club, plus les appels en sélection.' },
    { id: 'unemployed', title: 'Sans emploi', desc: 'Tu postules aux postes vacants.' }
  ];
  const ais = [
    { id: 'debutant', title: 'Débutant' },
    { id: 'amateur', title: 'Amateur' },
    { id: 'moyen', title: 'Moyen' },
    { id: 'superieur', title: 'Supérieur' },
    { id: 'professionnel', title: 'Professionnel' }
  ];
  const reps = [
    { id: 'inconnu', title: 'Inconnu' },
    { id: 'locale', title: 'Locale' },
    { id: 'continentale', title: 'Continentale' },
    { id: 'mondiale', title: 'Mondiale' }
  ];

  return `
  <div class="fm-screen" data-fm-screen="career-config">
    <div class="fm-screen-main">
      <header class="panel">
        <h2 style="margin:0;color:var(--fm-navy)">Configure ta carrière</h2>
        <p class="muted" style="margin:6px 0 0">Comme dans Football Manager : mode, niveau d’IA et réputation de départ.</p>
      </header>

      <article class="panel">
        <h3 style="margin:0 0 10px">Mode de carrière</h3>
        <div class="fm-choice-row">
          ${modes.map(m => `
            <button type="button" class="fm-choice ${mode === m.id ? 'selected' : ''}" data-fm-config="mode" data-value="${m.id}">
              <strong>${esc(m.title)}</strong>
              <span>${esc(m.desc)}</span>
            </button>`).join('')}
        </div>
      </article>

      <article class="panel">
        <h3 style="margin:0 0 10px">Niveau de l’IA</h3>
        <div class="fm-choice-row">
          ${ais.map(a => `
            <button type="button" class="fm-choice ${ai === a.id ? 'selected' : ''}" data-fm-config="ai" data-value="${a.id}">
              <strong>${esc(a.title)}</strong>
            </button>`).join('')}
        </div>
      </article>

      <article class="panel">
        <h3 style="margin:0 0 10px">Réputation de départ</h3>
        <div class="fm-choice-row">
          ${reps.map(r => `
            <button type="button" class="fm-choice ${rep === r.id ? 'selected' : ''}" data-fm-config="reputation" data-value="${r.id}">
              <strong>${esc(r.title)}</strong>
            </button>`).join('')}
        </div>
        <p class="muted" style="margin:10px 0 0;font-size:12px">Elle pèse sur la confiance du conseil et sur les offres des clubs.</p>
      </article>

      <article class="panel">
        <div class="fm-toggle-row">
          <span>Sauvegarde automatique<br><small class="muted">Après chaque décision</small></span>
          <div class="fm-switch ${autosave ? 'on' : ''}" data-fm-config="autosave" role="switch" aria-checked="${autosave}"></div>
        </div>
      </article>
    </div>

    <aside class="fm-screen-side">
      <div class="fm-side-note">
        <strong style="color:var(--fm-navy)">Résumé</strong><br>
        Mode <b>${esc(mode)}</b> · IA <b>${esc(ai)}</b> · Réputation <b>${esc(rep)}</b>
      </div>
      <button type="button" class="btn-outline" data-fm-action="back">Retour</button>
      <button type="button" class="btn-gold primary-action" data-fm-action="discover-competitions">Découvrir la compétition</button>
    </aside>
  </div>`;
}

/** Compétition officielle (maquette) */
export function renderCompetitionsOverviewHtml() {
  return `
  <div class="fm-screen" data-fm-screen="competitions-official">
    <div class="fm-screen-main">
      <header class="panel">
        <h2 style="margin:0;color:var(--fm-navy)">La compétition officielle</h2>
        <p class="muted" style="margin:6px 0 0">Huit compétitions · FGD et AGD · même logique qu’un univers Football Manager.</p>
      </header>
      <div class="fm-cards-grid">
        ${COMPETITIONS.map(c => `
          <article class="fm-mini-card">
            <h4>${esc(c.name)}</h4>
            <p>${esc(c.text)}</p>
            <span class="fm-badge">${esc(c.org)}</span>
          </article>`).join('')}
      </div>
    </div>
    <aside class="fm-screen-side">
      <div class="fm-side-note">
        FGD organise les championnats et les coupes de clubs.
        AGD organise la Coupe Fédéral et les compétitions galactiques.
      </div>
      <button type="button" class="btn-outline" data-fm-action="back">Retour</button>
      <button type="button" class="btn-gold primary-action" data-fm-action="choose-galaxy">Choisir ma galaxie</button>
    </aside>
  </div>`;
}

/** Prise de fonction (maquette) */
export function renderTakeOfficeHtml({ clubName = '[Nom du club]', president = '[Nom du président]', managerFirst = '[Prénom]', managerLast = '[Nom du manager]' } = {}) {
  return `
  <div class="fm-screen" data-fm-screen="take-office">
    <div class="fm-screen-main">
      <div style="display:grid;grid-template-columns:1.2fr 1fr;gap:12px">
        <article class="panel">
          <div style="display:flex;gap:10px;align-items:flex-start">
            <div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(145deg,#f0d789,#c9a227);display:grid;place-items:center;font-size:20px">👑</div>
            <div>
              <h3 style="margin:0 0 4px;color:var(--fm-navy)">Message de la présidence</h3>
              <p class="muted" style="margin:0 0 8px;font-size:12px">${esc(president)}, président du ${esc(clubName)}</p>
              <p style="margin:0;font-size:13px;line-height:1.45">
                Bienvenue, ${esc(managerFirst)} ${esc(managerLast)}. Le conseil vous confie le club pour la saison 1.
                Nous attendons des résultats, une gestion saine et des jeunes damistes qui progressent.
                Vous avez notre confiance pour commencer.
              </p>
            </div>
          </div>
        </article>

        <article class="panel">
          <h3 style="margin:0 0 8px;color:var(--fm-navy)">Confiance du conseil</h3>
          ${CONFIDENCE_METERS.map(m => `
            <div class="fm-meter">
              <span>${esc(m.label)}</span>
              <div class="fm-meter-bar"><i style="width:${m.value}%"></i></div>
            </div>`).join('')}
        </article>
      </div>

      <article class="panel">
        <h3 style="margin:0 0 10px;color:var(--fm-navy)">Objectifs de la saison 1</h3>
        <div class="fm-cards-grid">
          ${SEASON_OBJECTIVES.map(o => `
            <div class="fm-mini-card">
              <h4>${esc(o.title)}</h4>
              <p>${esc(o.text)}</p>
            </div>`).join('')}
        </div>
        <p class="muted" style="margin:10px 0 0;font-size:11px">Exemples : les objectifs réels dépendent du club choisi.</p>
      </article>

      <article class="panel">
        <h3 style="margin:0 0 10px;color:var(--fm-navy)">Première réunion avec le staff</h3>
        <p class="muted" style="margin:0 0 10px;font-size:12px">Adjoint, entraîneurs, recruteurs et kiné sont présents. Choisis ce que tu délègues.</p>
        ${STAFF_DELEGATIONS.map(d => `
          <div class="fm-toggle-row">
            <span>${esc(d.label)}</span>
            <div class="fm-switch" data-fm-delegate="${d.id}" role="switch" aria-checked="false"></div>
          </div>`).join('')}
      </article>
    </div>

    <aside class="fm-screen-side">
      <div class="fm-side-note">
        Le tableau de bord s’ouvre ensuite : alertes, prochains matchs et messagerie.
      </div>
      <button type="button" class="btn-outline" data-fm-action="back">Retour</button>
      <button type="button" class="btn-gold primary-action" data-fm-action="take-office">Prendre mes fonctions</button>
    </aside>
  </div>`;
}

/** Tableau de bord club (maquette) */
export function renderClubDashboardHtml(state = {}) {
  const club = state.clubName || '[Nom du club]';
  const day = state.dayLabel || 'Super League · Saison 1 · Jour 1 · Lundi';
  const next = state.nextMatch || { home: club, away: '[Adversaire]', when: 'Samedi · Jour 6', comp: 'Championnat · Journée 1 sur 22 · Arène du club' };
  const standings = state.standings || [
    { pos: 1, name: '[Club A]', pts: 0 },
    { pos: 2, name: '[Club B]', pts: 0 },
    { pos: 3, name: club, pts: 0 },
    { pos: 4, name: '[Club C]', pts: 0 }
  ];

  return `
  <div data-fm-screen="club-dashboard">
    <header class="panel" style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
      <div>
        <div style="display:flex;align-items:center;gap:8px">
          <span style="width:28px;height:28px;border-radius:50%;background:linear-gradient(145deg,#f0d789,#c9a227);display:grid;place-items:center">✦</span>
          <strong style="font-size:16px;color:var(--fm-navy)">${esc(club)}</strong>
        </div>
        <p class="muted" style="margin:4px 0 0;font-size:12px">${esc(day)}</p>
      </div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <span class="fm-alert-cta">RÉPONSE REQUISE</span>
      </div>
    </header>

    <nav class="fm-pills" aria-label="Navigation club">
      ${['Accueil','Club','Compétitions','Classement','Mercato','Tactique','Calendrier','Gestion','Médias','Plus']
        .map((t,i) => `<button type="button" class="fm-pill ${i===0?'active':''}" data-fm-tab="${t.toLowerCase()}">${t}</button>`)
        .join('')}
    </nav>

    <div class="fm-pills" aria-label="Sous-navigation">
      <button type="button" class="fm-pill active" data-fm-subtab="tableau">Tableau de bord</button>
      <button type="button" class="fm-pill" data-fm-subtab="actualites">Actualités</button>
      <button type="button" class="fm-pill" data-fm-subtab="classement">Classement</button>
      <button type="button" class="fm-pill" data-fm-subtab="divisions">Divisions</button>
    </div>

    <div class="fm-dashboard-grid">
      <article class="panel">
        <h3 style="margin:0 0 8px;color:var(--fm-navy)">Messages <small class="muted">3 non lus</small></h3>
        <div class="fm-msg-row"><span class="dot"></span><span>Conseil · Objectifs de la saison</span><span class="fm-badge">Réponse requise</span></div>
        <div class="fm-msg-row"><span class="dot"></span><span>Adjoint · Rapport avant-match</span></div>
        <div class="fm-msg-row"><span class="dot"></span><span>Presse · Demande d’interview</span></div>
      </article>

      <article class="panel">
        <h3 style="margin:0 0 8px;color:var(--fm-navy)">Prochain match</h3>
        <p style="margin:0 0 4px;font-weight:800;color:var(--fm-navy)">${esc(next.home)} – ${esc(next.away)}</p>
        <p class="muted" style="margin:0 0 8px;font-size:12px">${esc(next.when)} · ${esc(next.comp)}</p>
        <div class="fm-choice-row">
          <div class="fm-mini-card" style="min-height:auto"><h4>Style</h4><p>Équilibré</p></div>
          <div class="fm-mini-card" style="min-height:auto"><h4>Titulaire</h4><p>À choisir</p></div>
        </div>
      </article>

      <article class="panel">
        <h3 style="margin:0 0 8px;color:var(--fm-navy)">Calendrier et résultats</h3>
        <p class="muted" style="margin:0;font-size:12px">Sam. Jour 6 · ${esc(next.away)}</p>
        <p class="muted" style="margin:4px 0 0;font-size:12px">Mar. Jour 9 · Coupe Galactique</p>
        <p class="muted" style="margin:4px 0 0;font-size:12px">Sam. Jour 13 · Adversaire</p>
        <p style="margin:10px 0 0;font-size:12px"><b>Derniers résultats</b> — Aucun match</p>
      </article>

      <article class="panel">
        <h3 style="margin:0 0 8px;color:var(--fm-navy)">Effectif et finances</h3>
        <p style="margin:0;font-size:12px">Damiste 1 · niveau 72 · forme bonne</p>
        <p style="margin:4px 0;font-size:12px">Damiste 2 · niveau 68 · forme bonne</p>
        <p class="muted" style="margin:8px 0 0;font-size:12px">Santé financière · Trésorerie · transferts</p>
      </article>

      <article class="panel">
        <h3 style="margin:0 0 8px;color:var(--fm-navy)">Classement <small class="muted">Super League</small></h3>
        ${standings.map(r => `
          <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #e8eef5;font-size:12px">
            <span>${r.pos}. ${esc(r.name)}</span><strong>${r.pts} pt</strong>
          </div>`).join('')}
      </article>

      <article class="panel">
        <h3 style="margin:0 0 8px;color:var(--fm-navy)">Conseil et tâches</h3>
        <div class="fm-meter"><span>Matchs</span><div class="fm-meter-bar"><i style="width:52%"></i></div></div>
        <div class="fm-meter"><span>Finances</span><div class="fm-meter-bar"><i style="width:60%"></i></div></div>
        <div class="fm-meter"><span>Jeunes</span><div class="fm-meter-bar"><i style="width:44%"></i></div></div>
        <p style="margin:10px 0 0;font-size:12px">☐ Répondre au message du conseil<br>☐ Choisir le titulaire du match</p>
      </article>
    </div>
  </div>`;
}

/** Shell match day → damier (transition FM) */
export function renderMatchDayShellHtml({ home = 'Domicile', away = 'Extérieur', competition = 'Championnat' } = {}) {
  return `
  <div class="fm-screen" data-fm-screen="match-day" style="grid-template-columns:220px 1fr 220px">
    <aside class="panel">
      <h3 style="margin:0 0 8px;color:var(--fm-navy)">${esc(home)}</h3>
      <p class="muted" style="font-size:12px">Style · Titulaire · Forme</p>
      <button type="button" class="btn-outline" style="width:100%;margin-top:10px" data-fm-action="tactics">Tactique</button>
    </aside>
    <div>
      <header class="panel" style="text-align:center;margin-bottom:10px">
        <p class="muted" style="margin:0;font-size:12px">${esc(competition)}</p>
        <strong style="font-size:18px;color:var(--fm-navy)">${esc(home)} – ${esc(away)}</strong>
      </header>
      <div id="fmMatchBoardHost" class="panel" style="display:grid;place-items:center">
        <!-- Le damier #matchBoard de l'app est monté ici le jour de match -->
        <p class="muted">Damier de jeu (arène)</p>
      </div>
    </div>
    <aside class="panel">
      <h3 style="margin:0 0 8px;color:var(--fm-navy)">${esc(away)}</h3>
      <p class="muted" style="font-size:12px">IA adverse · Style manager</p>
      <button type="button" class="btn-gold primary-action" style="width:100%;margin-top:10px" data-fm-action="kickoff">Coup d’envoi</button>
      <button type="button" class="btn-outline" style="width:100%;margin-top:8px" data-fm-action="simulate-match">Simuler</button>
    </aside>
  </div>`;
}

/** Ordre du parcours FM */
export const FM_FLOW = Object.freeze([
  'launch',
  'career-config',
  'competitions-official',
  'galaxy-club',
  'take-office',
  'club-dashboard',
  'match-day'
]);

export function getFlowIndex(screenId) {
  return FM_FLOW.indexOf(screenId);
}
