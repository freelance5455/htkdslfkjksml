# Intégration Galactique V117 — Notes

## Ce qui a été fait

### 1. Noms de clubs remplacés
Les noms provisoires (`SUPER-LEAGUE 01`, etc.) ont été remplacés par les **noms galactiques originaux** issus des extractions précédentes.

Exemples :
- Cosmos United, Royal Dames FC, Galactic Titans…
- Titans Stellaires, Éclipse Rouge, Phénix Cosmique…
- Astéroïdes Sauvages, Pionniers du Cosmos…
- Dragons de Véga, Royal Cosmos… (Ligue C)
- Comètes de Terra, Éclairs de Mercure… (Ligue D)

### 2. Registre des managers fictifs
- **60 managers de clubs** (MGR-C001 → MGR-C060)
- **24 sélectionneurs** (MGR-S001 → MGR-S024)
- Chaque manager a une **galaxie d’origine**
- Style de jeu assigné (possession, contre, pression, défensif, offensif, équilibre)

### 3. Damistes première génération
Les 120 damistes (2 par club) issus des notes sont intégrés avec :
- Nom
- Genre (H/F)
- Niveau adapté à la division
- Origine galactique

### 4. Galaxies
Les **24 galaxies restent strictement inchangées**.

## Fichiers modifiés / ajoutés

| Fichier | Action |
|---------|--------|
| `src/galactique-registry.js` | **Nouveau** — Registre officiel complet |
| `src/store.js` | Modifié — utilise le registre pour créer les clubs + managers |
| `src/roster-catalog.js` | Modifié — ne force plus les noms génériques |

## Comment intégrer dans le projet original

1. Copier `galactique-registry.js` dans le dossier `src/`
2. Remplacer `store.js` et `roster-catalog.js` par les versions intégrées
3. Vérifier que les imports dans `store.js` pointent bien vers `./galactique-registry.js`

## Structure des identifiants

- Clubs : `club-sl-01` … `club-ld-12`
- Managers clubs : `MGR-C001` … `MGR-C060`
- Sélectionneurs : `MGR-S001` … `MGR-S024`
- Galaxies : `GAL-001` … `GAL-024`
- Damistes : `{clubId}-d1` / `{clubId}-d2`

## Prochaines étapes possibles

- Brancher les managers IA dans la simulation de matchs
- Utiliser les sélectionneurs pour les convocations internationales
- Activer automatiquement Ligue C (saison 3) et Ligue D (saison 5) avec les bons clubs
- Ajouter portraits / styles tactiques liés aux managers

---

## Phase 2 — IA Managers + Sélectionneurs (ajoutée)

### Nouveau fichier
- `src/manager-ai.js`

### Fonctionnalités IA Managers
- Chaque club a un manager AI avec **style** (possession, contre, pression, offensif, défensif, équilibre)
- Le style influence :
  - Bonus de force domicile / extérieur
  - Biais de choix de coups dans le moteur de dames (captures vs conservation)
- `applyManagerInfluence(state, fixture)` est branché dans `season-engine.js`
- Les détails de match contiennent maintenant les managers et leurs styles

### Fonctionnalités Sélectionneurs
- 24 sélectionneurs liés aux galaxies
- `aiSelectConvocations()` choisit jusqu’à 2 damistes (représentants + clubs d’origine)
- `applyConvocations()` / `runAllSelectionConvocations()` enregistrent les convocations
- `galaxy-management.js` enrichi : affiche sélectionneur + effectif international actuel

### Fichiers touchés
| Fichier | Changement |
|---------|------------|
| `manager-ai.js` | **Nouveau** |
| `board-simulation.js` | Styles managers dans `chooseMove` + `simulateBoardMatch` |
| `season-engine.js` | Appel `applyManagerInfluence` avant simulation |
| `galaxy-management.js` | Sélectionneurs + convocations |

### Utilisation rapide

```js
import { applyManagerInfluence, runAllSelectionConvocations, getSelectionneur } from './manager-ai.js';
import { getGalaxyManagementOverview, refreshGalaxyConvocations } from './galaxy-management.js';

// Influence d'un match
const infl = applyManagerInfluence(state, fixture);

// Convocations de toutes les sélections
const results = runAllSelectionConvocations(state);

// Vue galaxies avec sélectionneurs
const overview = getGalaxyManagementOverview(state);
```

---

## Phase 3 — Automatisation

### Convocations automatiques
Quand le calendrier entre dans une **fenêtre internationale** :
- `reserved-intergalactic-window`
- Coupe Lunaire
- Coupe Intergalactique des galaxies

→ `runAllSelectionConvocations(state)` est appelé automatiquement  
→ Chaque sélectionneur convoque jusqu’à 2 damistes  
→ Résultat disponible dans le retour de `advanceToNextCalendarEvent` (`convocations`)

### Évolution des styles managers
Après chaque match de championnat simulé :
- Victoire / défaite / nul peut faire évoluer le style du manager AI
- Exemples :
  - offensif qui perd → pression
  - pression qui gagne → offensif
  - défensif qui gagne → équilibre
- Historique conservé dans `manager.styleHistory`
- Entrée ajoutée au `careerLog`

### API ajoutée
```js
evolveManagerStyle(state, clubId, 'win'|'loss'|'draw')
evolveManagersAfterMatch(state, fixture, { winnerSide })
runAllSelectionConvocations(state)  // déjà présent, maintenant auto-déclenché
```

---

## Phase 4 — Paysage forcé + interface type Football Manager 27

### Orientation
- `orientation.js` **force le paysage horizontal**
- Plus de bouton « Continuer en portrait »
- Overlay de verrouillage tant que l’appareil est en portrait
- Tentative de `screen.orientation.lock('landscape')` + fullscreen
- `manifest.webmanifest` : `"orientation": "landscape"`, `"display": "fullscreen"`

### Layout FM 27
- CSS `fm-layout.css` injecté dans `index.html`
- Grille : **sidebar gauche (nav)** | **zone principale** | **panneau droit (contexte)**
- Navigation verticale dense (plus de rail horizontal)
- Densité d’information accrue (tableaux, stats, panneaux)
- Panneau latéral droit (`#fmSidePanel`) pour détail club / galaxie / manager
- Module `fm-side-panel.js` pour remplir le panneau contextuel

### Fichiers
| Fichier | Rôle |
|---------|------|
| `orientation.js` | Verrouillage paysage |
| `fm-layout.css` | Shell FM (sidebar + main + side) |
| `fm-side-panel.js` | Contenu du panneau droit |
| `index.html` | CSS + classes body + panneau |
| `manifest.webmanifest` | orientation: landscape |

### Intégration dans le projet
1. Remplacer `src/orientation.js`
2. Copier `fm-layout.css` et `fm-side-panel.js` dans `src/`
3. Remplacer `index.html` et `manifest.webmanifest` à la racine
4. Dans `app.js`, importer et utiliser :
```js
import { initLandscapeGuidance } from './orientation.js';
import { renderClubInSidePanel, renderGalaxyInSidePanel } from './fm-side-panel.js';
// au boot :
initLandscapeGuidance();
```

---

## Phase 5 — Parcours Football Manager 27 (maquettes)

### Objectif
Même configuration qu’un FM : du menu principal jusqu’au **terrain (damier)**.

### Flux imposé
1. **Menu principal** — Nouvelle carrière / Continuer / Charger / Paramètres / Quitter  
2. **Configure ta carrière** — Mode, niveau IA, réputation, sauvegarde auto  
3. **Compétition officielle** — 8 compétitions FGD/AGD  
4. **Galaxie & club** — choix d’origine et de club  
5. **Prise de fonction** — message présidence, barres de confiance, objectifs, délégation staff  
6. **Tableau de bord** — messages, prochain match, effectif, classement, tâches  
7. **Jour de match** — coquilles latérales + **damier** au centre  

### Fichiers
| Fichier | Rôle |
|---------|------|
| `fm-theme.css` | Thème clair maquettes (cartes blanches, or, pills) |
| `fm-screens.js` | Templates HTML de chaque étape du parcours |
| `orientation.js` | Paysage forcé |
| `index.html` | Thème injecté + classes `cgd-fm-theme` |

### Branchement dans `app.js`
```js
import { initLandscapeGuidance } from './orientation.js';
import {
  renderLaunchMenuHtml,
  renderCareerConfigHtml,
  renderCompetitionsOverviewHtml,
  renderTakeOfficeHtml,
  renderClubDashboardHtml,
  renderMatchDayShellHtml,
  FM_FLOW
} from './fm-screens.js';

initLandscapeGuidance();
document.body.classList.add('cgd-fm-theme');
```

Les actions utilisent `data-fm-action`, `data-fm-config`, `data-fm-tab` pour le routage.

---

## Phase 6 — Branchement routeur FM dans app.js

### Fichiers
- `fm-router.js` — enchaîne menu → config → compétitions → prise de fonction → dashboard → match/damier
- `app.js` — import + `startFmFlow` au boot, prise de fonction FM, match day FM

### Comportement
1. Au lancement : écran menu FM (maquette)
2. Nouvelle carrière → Configure ta carrière → Compétition officielle → choix galaxie/club (setup natif)
3. Après validation club : **Prise de fonction** FM (plus l’overlay natif)
4. « Prendre mes fonctions » → Tableau de bord FM
5. Onglets dashboard → écrans natifs V117
6. Gate « ALLER AU MATCH » → coquille match day FM puis damier

### API injectée
`getFmApi()` fournit save, render, takeOffice, updateDelegation, findUserClub, getStandings.
