# BudgetSmart – Guide pour débutant (voie A : application web installable → Android)

Tout se fait depuis un téléphone Android, avec Chrome. Les menus des sites cités peuvent changer un peu : suis les mots-clés.
IMPORTANT : ce guide a été écrit sans pouvoir tester ces sites ni générer d’APK. Rien n’a encore été testé sur un vrai Android.

## Les fichiers (à mettre tous au même niveau, sans dossier)
index.html (l’application) · manifest.webmanifest (carte d’identité) · sw.js (mode hors connexion) · _headers · icon-192.png · icon-512.png · icon-maskable-512.png
Si tu as reçu le .zip : ouvre l’app « Files by Google », touche le zip, puis « Extraire ».

## Étape 1 – Garder ton code chez toi (GitHub, gratuit)
1. Va sur github.com, crée un compte avec TON e-mail.
2. « New repository » → nom : budgetsmart → coche « Private » → Create.
3. « uploading an existing file » (ou Add file → Upload files) → choisis les 7 fichiers → « Commit changes ».
Ton code source t’appartient maintenant dans ton compte. Sauvegarde aussi le zip dans ton Drive.

## Étape 2 – Mettre l’application en ligne (Cloudflare Pages, gratuit)
1. dash.cloudflare.com → crée un compte avec TON e-mail.
2. Workers & Pages → Create → onglet Pages → « Connect to Git » → autorise GitHub → choisis budgetsmart.
3. Framework : None. Commande de build : laisse vide. Dossier de sortie : laisse vide (ou /). → Save and Deploy.
4. Tu obtiens une adresse du type https://budgetsmart.pages.dev (le nom exact peut varier).
(Alternative : Netlify, « Add new site → Import from GitHub », mêmes réglages.)
Ensuite, pour une adresse à toi : achète un nom de domaine (environ 10 à 15 €/an) à ton nom, puis Pages → Custom domains → Add. Fais-le avant de publier sur Google Play.

## Étape 3 – Tester l’application installable
1. Ouvre ton adresse dans Chrome Android.
2. Menu ⋮ → « Installer l’application » (ou « Ajouter à l’écran d’accueil »).
3. Teste : ajouter une dépense et un revenu, créer un budget et un objectif, changer de langue (FR/EN/HA), mode sombre, Réglages.
4. Active le mode avion, rouvre l’application : elle doit s’ouvrir et garder tes données.
5. Ferme complètement l’application, rouvre-la : les données doivent être toujours là.
Note : les données restent dans l’application sur ce téléphone. Si tu effaces les données du navigateur/de l’application, elles sont perdues. Exporte (CSV) de temps en temps depuis Réglages.

## Étape 4 – Obtenir l’application Android avec PWABuilder
1. Va sur pwabuilder.com, colle ton adresse, touche « Start ».
2. Vérifie que le manifeste et le service worker sont détectés.
3. « Package for stores » → Android. Renseigne :
   - Package ID : com.tonnom.budgetsmart (minuscules, unique, DÉFINITIF)
   - Nom : BudgetSmart · Version : 1 / 1.0.0
   - Signing key : « Create new », puis « Generate ».
4. Télécharge le zip. Il doit contenir un fichier .aab (pour Google Play), normalement un .apk de test, ta clé de signature (.keystore) avec ses mots de passe, et un fichier assetlinks.json.
5. SAUVEGARDE la clé et les mots de passe (Drive + e-mail à toi-même). Ne les mets jamais dans un dépôt public. Sans elle, tu ne pourras plus mettre l’app à jour.
6. Pour retirer la barre d’adresse dans l’application : dans ton dépôt GitHub, Add file → Create new file → nom : .well-known/assetlinks.json → colle le contenu fourni → Commit.

## Étape 5 – Tester l’APK avant de penser à Google Play
1. Envoie le .apk sur ton téléphone (Drive, e-mail) et ouvre-le.
2. Autorise l’installation depuis cette source si Android le demande ; si Play Protect avertit (clé de test), choisis « Installer quand même ».
3. Refais la liste de l’étape 3. Vérifie aussi : clavier, mode sombre, très petit écran, montants longs.
4. Note tout problème et envoie-le-moi.
Le .aab ne s’installe pas directement : il sert seulement à Google Play.

## Étape 6 – Ce qui manque encore
Vrai assistant IA (serveur sécurisé), comptes facultatifs et sauvegarde en ligne, import d’une sauvegarde, export PDF, rappels, politique de confidentialité, relecture du haoussa par un locuteur natif, tests sur plusieurs téléphones, avis juridique (RGPD et lois locales), offre Premium.

## Frais
Google Play : 25 $ une fois · Domaine : environ 10–15 €/an · GitHub et hébergement : gratuits au départ · IA : à l’usage plus tard · Serveur de sauvegarde : gratuit puis environ 25 $/mois · Apple (optionnel) : 99 $/an.
Google Play : un compte personnel récent doit faire un test fermé (12 testeurs, 14 jours) avant la production ; vérifie la règle actuelle dans la Play Console.

## Propriété
Code : ton dépôt GitHub. Comptes (Google Play, domaine, hébergement, API) : à ton nom et ton e-mail. Clé de signature : sauvegardée par toi. Nom : dépôt de marque à ton nom. Tout intervenant extérieur : accord écrit.
