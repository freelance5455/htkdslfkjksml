ARENA FPS - PROJETO ANDROID

Este projeto transforma o arquivo Arena FPS (2).html em um aplicativo Android usando WebView.

1. Abra a pasta ArenaFPS-Android no Android Studio.
2. Espere o Gradle sincronizar.
3. Se o Android Studio pedir para instalar SDK/Build Tools, aceite.
4. Vá em Build > Build APK(s).
5. O APK de debug será criado em:
   app/build/outputs/apk/debug/app-debug.apk

O jogo já está dentro de:
   app/src/main/assets/index.html

O save do jogo continua usando localStorage do WebView, então os saves ficam armazenados no aplicativo.
