#!/usr/bin/env python3
"""Convert an R K Consultancy SQLite database to import JSON for the mobile app.
Usage: python convert_python_db.py rkc_data.db [output.json]
The database is read-only; it is never modified.
"""
import sqlite3, json, sys
from pathlib import Path
if len(sys.argv) < 2:
    print('Usage: python convert_python_db.py rkc_data.db [output.json]'); raise SystemExit(2)
src=Path(sys.argv[1]).expanduser().resolve()
if not src.is_file(): raise SystemExit(f'Database not found: {src}')
out=Path(sys.argv[2]).expanduser() if len(sys.argv)>2 else Path('rk_import.json')
con=sqlite3.connect(f'file:{src.as_posix()}?mode=ro', uri=True)
con.row_factory=sqlite3.Row
try:
    tables={r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    payload={'app':'R K Consultancy Python DB Export','formatVersion':1,'sourceFile':src.name,'tables':{}}
    for table in sorted(tables):
        if table.startswith('sqlite_'): continue
        cols=[r[1] for r in con.execute(f'PRAGMA table_info("{table}")')]
        rows=[]
        for row in con.execute(f'SELECT * FROM "{table}"'):
            obj={k:row[k] for k in cols}
            rows.append(obj)
        payload['tables'][table]=rows
    out.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f'Converted {len(payload["tables"])} tables to {out.resolve()}')
    print('Important: output may contain PANs, passwords, and other sensitive client data. Keep it private.')
finally: con.close()
