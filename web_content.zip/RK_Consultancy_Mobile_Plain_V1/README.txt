R K CONSULTANCY MOBILE — PLAIN V1 (NO SYNC)
===========================================

This is a clean-start mobile-friendly offline web app project intended to be wrapped into an Android APK. It does NOT include client sample data and does NOT sync with Windows/cloud.

FEATURES IN THIS STARTER
- Dashboard, client directory, client add/edit and search
- Tasks, due dates and recurring task generation
- Custom pages/fields
- Invoice list, create/edit and print / Save as PDF
- Bank settings and optional QR image upload; invoice uses current bank settings or a saved old-bank snapshot according to the setting
- JSON backup/export and import
- Python SQLite database conversion helper
- CSV client import (simple CSV; use JSON converter for full Python database)
- Local browser storage; no cloud/sync

IMPORT YOUR REAL PYTHON DATA
1. Copy convert_python_db.py to a Windows computer with Python 3 installed.
2. Keep your Python software database file (e.g. rkc_data.db) in the same folder.
3. Run: python convert_python_db.py rkc_data.db rk_import.json
4. Transfer rk_import.json to your phone privately.
5. Open the app > Settings > Import Data > select rk_import.json.
6. Confirm the import after checking the prompt. Export a backup first if the phone already has data.

The converter reads the database in read-only mode. It exports all tables. The mobile app maps ITR clients, GSTR clients, financial-year ITR details and Other Services invoices into its supported views. Some source-only tables/fields are retained as sourceData in the imported app data, but are not all surfaced as editable UI screens yet. Review the import summary and retain your original database backup.

BANK DETAILS / QR
- Set bank name, account holder, account number, IFSC and UPI ID in Settings.
- Upload your genuine QR image (PNG/JPG, max 2 MB) if you want it printed on invoices. This version does not generate a QR from a UPI ID automatically.
- Choose whether bank changes apply to old and new invoices or only new invoices. For “new invoices only”, existing invoices retain the bank snapshot captured when this setting is changed; newly created invoices use the new details.
- PDFs already exported/shared will not change retroactively. Reprint to generate a new PDF.

RUN / TEST
- Basic: open index.html in a modern browser. Local persistence works, but service-worker/PWA install requires HTTPS or localhost.
- For local server: python -m http.server 8080, then visit http://localhost:8080.
- Android APK: wrap this folder with a WebView/Capacitor Android shell. This ZIP is source project, not a compiled APK. Android Studio/SDK is required to build an APK.

LIMITATIONS
- No Windows/mobile sync by design.
- This is a starter and not full feature parity with Python V32.7. In particular, all original Python screens and every table field are not yet exposed as dedicated editable screens.
- SQLite import uses the included Python converter because browser-only JavaScript cannot natively read arbitrary SQLite files without an embedded SQLite engine.
- LocalStorage is suitable for a starter, not ideal for very large databases or highly sensitive production data. Use device lock and secure backups.
- The QR shown is the image you upload; verify it by scanning with your own payment app before issuing invoices.
