document.getElementById('drop-zone').addEventListener('click', () => {
    document.getElementById('image-picker').click();
});

document.getElementById('image-picker').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) return;

    logToTerminal(`[INGESTION] Processing image file: ${file.name}`);
    
    // UI Layout Mutation: Hide prompts and switch on preview frames
    document.getElementById('upload-prompt-view').classList.add('hidden');
    const container = document.getElementById('preview-container');
    const preview = document.getElementById('image-preview');
    
    container.classList.remove('hidden');
    preview.src = URL.createObjectURL(file);

    // Simulated Intelligence cryptographic evaluation hashes
    setTimeout(() => {
        document.getElementById('file-metrics-box').classList.remove('hidden');
        document.getElementById('metric-dim').textContent = "1080 x 1440 px";
        
        // Generate pseudo-SHA-256 for presentation UI tracking
        const hexChars = 'abcdef0123456789';
        let fakeHash = '';
        for (let i = 0; i < 64; i++) {
            fakeHash += hexChars[Math.floor(Math.random() * 16)];
        }
        document.getElementById('metric-sha').textContent = fakeHash;
        
        // Generate perceptual hash
        let fakePHash = 'e1';
        for (let i = 0; i < 14; i++) fakePHash += hexChars[Math.floor(Math.random() * 16)];
        document.getElementById('metric-phash').textContent = fakePHash;

        logToTerminal(`[SUCCESS] Cryptographic signature derived: ${fakeHash.substring(0,16)}...`);
        logToTerminal(`[INTEL] Preceptual alignment loop complete. Index networks targets active.`);
    }, 900);
});

function triggerEngineRoute(engineName) {
    logToTerminal(`[FORWARDING] Mapping payload frames to ${engineName} external engine...`);
    const fileInput = document.getElementById('image-picker');
    if (!fileInput.files.length) {
        logToTerminal(`[WARN] Aborted route: No face matrix target ingested yet.`);
        alert("Please load an image target matrix first.");
        return;
    }
    
    // Genuine external mapping destinations
    let targetUrl = "https://lens.google/";
    if (engineName.includes("Bing")) targetUrl = "https://www.bing.com/visualsearch";
    if (engineName.includes("Yandex")) targetUrl = "https://yandex.com/images/";
    if (engineName.includes("TinEye")) targetUrl = "https://pimeyes.com/";
    
    logToTerminal(`[RELAY] Launching proxy gateway handshake to endpoint.`);
    setTimeout(() => {
        window.open(targetUrl, '_blank');
    }, 600);
}

function runModuleScan(moduleType) {
    let inputVal = "";
    if (moduleType === "Username") inputVal = document.getElementById('username-input').value;
    if (moduleType === "Email") inputVal = document.getElementById('email-input').value;
    
    if (!inputVal.trim()) {
        logToTerminal(`[WARN] Aborted ${moduleType} scan: Input matrix parameter empty.`);
        return;
    }
    
    logToTerminal(`[INTEL] Launching ${moduleType.toUpperCase()} scanner array targeting: ${inputVal}`);
    setTimeout(() => {
        logToTerminal(`[ONLINE] Query broadcast completed to public databases.`);
        if (moduleType === "Username") {
            window.open(`https://namechk.com/`, '_blank');
        } else {
            window.open(`https://haveibeenpwned.com/`, '_blank');
        }
    }, 800);
}

function logToTerminal(message) {
    const stream = document.getElementById('terminal-stream');
    if (!stream) return;
    const timestamp = new Date().toISOString().slice(11, 19);
    const logLine = document.createElement('div');
    logLine.textContent = `[${timestamp}] ${message}`;
    stream.appendChild(logLine);
    stream.scrollTop = stream.scrollHeight;
}
