# Free Fire AI Premium — Android project

A standalone, offline visual training simulator. It does **not** connect to Free Fire,
read the game screen, detect real players, automate input, or modify game behavior.

## Build an APK

1. Install Android Studio (current stable) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

For a signed release APK, use **Build → Generate Signed Bundle / APK** and create your own signing key.

## Device

- Minimum Android: 6.0 (API 23)
- Target SDK: 35
- Offline; no permissions or network access requested.

## Project notes

The interface is a local HTML/CSS/JavaScript page hosted in an Android WebView.
The enemy markers and statistics are randomized training illustrations only.
