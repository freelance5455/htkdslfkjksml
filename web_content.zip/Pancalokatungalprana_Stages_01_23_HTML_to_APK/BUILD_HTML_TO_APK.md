# HTML to APK — Build Guide

1. Instal Android Studio stabil, Android SDK Platform 35, dan JDK 17.
2. Ekstrak ZIP, buka folder `android/` di Android Studio.
3. Sinkronkan Gradle.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug berada di `android/app/build/outputs/apk/debug/app-debug.apk`.

CLI (jika Gradle tersedia):
```bash
cd android
gradle assembleDebug
```

Aplikasi memuat HTML lokal dari assets. Untuk mengaktifkan AI, jalankan backend
pada server yang dapat dijangkau perangkat, lalu atur URL backend pada menu
Pengaturan aplikasi HTML. Gunakan HTTPS untuk deployment nyata.

Jangan menanam API key provider model dalam HTML atau APK. Letakkan rahasia
provider hanya di backend. Untuk produksi, tambahkan autentikasi per pengguna,
TLS, rate limiting, database produksi, backup, logging aman, dan uji penetrasi.
