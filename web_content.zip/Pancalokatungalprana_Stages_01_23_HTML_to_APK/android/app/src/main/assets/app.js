const $=id=>document.getElementById(id);
let apiBase=localStorage.getItem("pancaloka_api")||"";
$("api").value=apiBase;
$("saveApi").onclick=()=>{apiBase=$("api").value.trim().replace(/\/$/,"");localStorage.setItem("pancaloka_api",apiBase);$("status").textContent="Alamat backend disimpan di perangkat.";};
$("check").onclick=async()=>{try{const r=await fetch(apiBase+"/health");const j=await r.json();$("status").textContent=`Backend ${j.status}; DNA ${j.dna.total}+${j.dna.prana}; model ${j.model_ready?"siap":"belum dikonfigurasi"}`;}catch(e){$("status").textContent="Backend tidak terjangkau: "+e.message;}};
function add(text,user=false){const d=document.createElement("div");d.className="chat"+(user?" user":"");d.textContent=(user?"Anda: ":"Pancaloka: ")+text;$("messages").appendChild(d);d.scrollIntoView({behavior:"smooth"});}
$("send").onclick=async()=>{const prompt=$("prompt").value.trim();if(!prompt)return;add(prompt,true);$("prompt").value="";$("send").disabled=true;try{if(!apiBase)throw new Error("Atur URL backend terlebih dahulu.");const r=await fetch(apiBase+"/ask",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({prompt})});const j=await r.json();add(`${j.decision}: ${j.answer}\n${(j.reasons||[]).join(", ")}`);$("lastDecision").textContent=j.decision;$("lastDecision").className="state "+j.decision;}catch(e){add("Belum dapat memproses: "+e.message);}finally{$("send").disabled=false;}};
$("prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("send").click();}});
