plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "id.pancaloka.webapp"
    compileSdk = 35
    defaultConfig { applicationId = "id.pancaloka.webapp"; minSdk = 23; targetSdk = 35; versionCode = 123; versionName = "1.23" }
}
