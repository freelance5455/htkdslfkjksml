import os, re, json, sqlite3, time, uuid, urllib.request
from pathlib import Path
from contextlib import contextmanager
from typing import Optional
from fastapi import FastAPI, Header, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

LOKA = {"asmaul_husna":99, "aksara":20, "hijaiyah":29, "angka":10, "abjad":26}
PRANA = 1
PURPOSE = "Memayu Hayuning Bawana"

def dna184():
    n = sum(LOKA.values())
    return {"loka":LOKA, "total":n, "prana":PRANA,
            "valid":n == 184 and PRANA == 1, "purpose":PURPOSE}

def firewall184(text):
    if not isinstance(text, str) or not text.strip() or len(text) > 12000:
        return "TAHAN", ["INPUT_INVALID"]
    # Minimal demonstrasi aturan; bukan sistem moderasi lengkap.
    risky = [
        r"(cara|langkah|panduan).{0,35}(membuat|merakit).{0,20}(bom|peledak)",
        r"(cara|langkah).{0,30}(mencuri|membobol).{0,25}(password|akun)"
    ]
    if any(re.search(p, text, re.I) for p in risky):
        return "TOLAK", ["POLA_PERMINTAAN_BERBAHAYA"]
    return "LOLOS", []

class Store:
    def __init__(self, path):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self.db() as c:
            c.execute("CREATE TABLE IF NOT EXISTS knowledge(id TEXT PRIMARY KEY, body TEXT, source TEXT, ts REAL)")
            c.execute("CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY, event TEXT, decision TEXT, ts REAL)")
            c.execute("CREATE TABLE IF NOT EXISTS feedback(id TEXT PRIMARY KEY, rating INTEGER, note TEXT, ts REAL)")
    @contextmanager
    def db(self):
        c = sqlite3.connect(self.path)
        try:
            yield c
            c.commit()
        finally:
            c.close()
    def add(self, body, source):
        ident = str(uuid.uuid4())
        with self.db() as c:
            c.execute("INSERT INTO knowledge VALUES(?,?,?,?)", (ident,body,source,time.time()))
        return ident
    def retrieve(self, query, limit=5):
        words = list(dict.fromkeys(re.findall(r"\w{3,}", query.lower())))
        if not words: return []
        with self.db() as c:
            rows = c.execute("SELECT body,source FROM knowledge").fetchall()
        scored = []
        for body, source in rows:
            corpus = (body + " " + source).lower()
            score = sum(corpus.count(w) for w in words)
            if score: scored.append((score, {"text":body,"source":source}))
        return [x[1] for x in sorted(scored, key=lambda x:x[0], reverse=True)[:limit]]
    def audit(self, event, decision):
        with self.db() as c:
            c.execute("INSERT INTO audit VALUES(?,?,?,?)",(str(uuid.uuid4()),event,decision,time.time()))

class Ask(BaseModel):
    prompt: str = Field(min_length=1, max_length=12000)
class Knowledge(BaseModel):
    text: str = Field(min_length=1, max_length=12000)
    source: str = Field(min_length=1, max_length=500)
    consent: bool = False

class Model:
    def __init__(self):
        self.base = os.getenv("PANCALOKA_API_BASE","").rstrip("/")
        self.key = os.getenv("PANCALOKA_API_KEY","")
        self.name = os.getenv("PANCALOKA_MODEL","")
    @property
    def ready(self): return bool(self.base and self.name)
    def answer(self, prompt, docs):
        if not self.ready: raise RuntimeError("LLM not configured")
        context = "\n".join("- "+d["text"]+" [source: "+d["source"]+"]" for d in docs)
        data = {"model":self.name,"temperature":0.25,"messages":[
          {"role":"system","content":"Anda asisten Pancalokatungalprana. Jawab jujur, aman, dan akui ketidakpastian. Tujuan: "+PURPOSE},
          {"role":"user","content":"Konteks RAH/RAG:\n"+(context or "(kosong)")+"\nPertanyaan:\n"+prompt}]}
        req = urllib.request.Request(self.base+"/chat/completions", data=json.dumps(data).encode(),
          headers={"Content-Type":"application/json", **({"Authorization":"Bearer "+self.key} if self.key else {})})
        with urllib.request.urlopen(req, timeout=45) as r:
            return json.loads(r.read())["choices"][0]["message"]["content"]

app = FastAPI(title="Pancalokatungalprana Unified API", version="1.23")
store = Store(os.getenv("PANCALOKA_DB_PATH","data/pancaloka.db"))
model = Model()
allowed = [x.strip() for x in os.getenv("PANCALOKA_ALLOWED_ORIGINS","").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=allowed, allow_methods=["GET","POST"],
                   allow_headers=["Content-Type","Authorization"])

def five_loka_review(answer):
    return [{"loka":name,"status":"PENDING_HUMAN_REVIEW"} for name in LOKA]

@app.get("/")
def home(): return {"name":"Pancalokatungalprana","stage":"1-23","docs":"/docs"}
@app.get("/health")
def health(): return {"status":"ok","dna":dna184(),"model_ready":model.ready}
@app.get("/dashboard")
def dashboard():
    return {"dna":dna184(),"five_loka":list(LOKA.keys()),
            "firewall_states":["TOLAK","TAHAN","LOLOS"],"model_ready":model.ready}
@app.post("/ask")
def ask(req:Ask):
    decision, reasons = firewall184(req.prompt)
    if decision != "LOLOS":
        store.audit("request_blocked",decision)
        return {"decision":decision,"answer":"Permintaan ditolak atau ditahan.","reasons":reasons}
    if not model.ready:
        return {"decision":"TAHAN","answer":"Model AI belum dikonfigurasi.","reasons":["MODEL_NOT_CONFIGURED"]}
    try:
        docs = store.retrieve(req.prompt)
        answer = model.answer(req.prompt,docs)
    except Exception:
        store.audit("model_failure","TAHAN")
        return {"decision":"TAHAN","answer":"Model tidak tersedia; periksa konfigurasi backend.","reasons":["MODEL_FAILURE"]}
    store.audit("generated_pending_review","TAHAN")
    return {"decision":"TAHAN","answer":answer,"reasons":["FIVE_LOKA_AND_HUMAN_REVIEW_REQUIRED"],
            "five_loka":five_loka_review(answer),"sources":[d["source"] for d in docs]}
@app.post("/knowledge")
def add_knowledge(req:Knowledge):
    if not req.consent: raise HTTPException(403,"Persetujuan penyimpanan wajib")
    return {"id":store.add(req.text,req.source),"status":"stored"}
