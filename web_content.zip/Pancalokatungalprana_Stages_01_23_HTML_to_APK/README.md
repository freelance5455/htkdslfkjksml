# PANCALOKATUNGALPRANA — Tahap 1–23 (HTML to APK)

Paket integrasi ini menyatukan filosofi DNA 184 + 1 Prana, lima Loka,
RAH/RAG knowledge engine, AI core, Firewall 184, governance, memory,
multi-agent, API backend, dan antarmuka HTML dalam satu proyek.

## Isi paket
- `web/index.html`: aplikasi HTML responsif (dapat dibuka di browser).
- `web/app.js`, `web/styles.css`: UI dan komunikasi API.
- `backend/`: FastAPI, DNA, RAH keyword retrieval, konektor LLM, Five-Loka,
  Firewall, audit log, knowledge store, endpoint API.
- `android/`: proyek Android Kotlin WebView untuk membungkus HTML menjadi APK.
- `docs/STAGE_MAP.md`: pemetaan Tahap 1–23 ke modul gabungan.
- `BUILD_HTML_TO_APK.md`: petunjuk build APK.

## Menjalankan web
Buka `web/index.html` langsung untuk tampilan demo lokal. Agar pertanyaan
diproses model AI, jalankan backend dan atur URL API pada Pengaturan.

## Menjalankan backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
cp ../.env.example .env
# Isi endpoint model dan rahasia di .env
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Membuat APK
Buka folder `android/` di Android Studio. Proyek ini menggunakan WebView
dan memuat `web/index.html` dari assets. Salin isi folder `web/` ke
`android/app/src/main/assets/` (folder sudah disediakan dan berisi salinan).
Lalu pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
Petunjuk lengkap ada di `BUILD_HTML_TO_APK.md`.

## Batasan jujur
ZIP ini adalah source project HTML + backend + Android wrapper, bukan APK
yang sudah dikompilasi. Kompilasi APK memerlukan Android SDK, JDK, dan Gradle
di Android Studio. Koneksi AI memerlukan endpoint/model dan API key milik
pengguna yang disimpan hanya di backend. Firewall contoh adalah lapisan
heuristik, bukan jaminan keamanan. Lima Loka pada paket ini menjalankan
pemeriksaan aturan/checklist terpisah; bukan lima model AI independen.
