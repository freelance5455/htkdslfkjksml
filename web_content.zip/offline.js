﻿{
	"version": 1788718915,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/tiledbackground.png",
		"images/particles.png",
		"images/particles2.png",
		"images/particles3.png",
		"images/particles4.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}