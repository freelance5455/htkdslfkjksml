async function sendReminder(channel, studentId, feeId) {
  const student = studentFor(studentId);
  const fee = appState.fees.find(item => item.id === feeId);

  if (!student || !fee) return;

  let phone = (student.guardianPhone || '').replace(/\D/g, '');
  phone = phone.replace(/^0/, '880');

  const message = reminderMessage(student, fee);
  const encoded = encodeURIComponent(message);

  if (channel === 'whatsapp') {
    window.open(
      'https://wa.me/',
      '_blank',
      'noopener,noreferrer'
    );
  } else {
    if (!student.guardianPhone) {
      notify('Add a guardian mobile number first.', true);
      return;
    }

    window.location.href =
      `sms:${encodeURIComponent(student.guardianPhone)}?body=${encoded}`;
  }

  if (
    confirm(
      `Did you send the ${channel === 'sms' ? 'SMS' : 'WhatsApp'} reminder to the guardian at ${student.guardianPhone}?`
    )
  ) {
    try {
      await addDoc(docCollection('reminders'), {
        teacherId: appState.user.uid,
        studentId,
        studentName: student.name,
        month: fee.month,
        feeRecordId: fee.id,
        channel,
        status: 'sent-confirmed',
        sentAt: serverTimestamp(),
        createdAt: serverTimestamp()
      });

      notify('Reminder activity recorded.');
      await refreshData();

    } catch (error) {
      notify(
        `Message opened, but reminder tracking failed: ${error.message}`,
        true
      );
    }
  }
}