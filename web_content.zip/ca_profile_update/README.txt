CODE ACADEMY - APACHE/PHP SIN BASE DE DATOS

REQUISITOS
- Hosting Apache con PHP 8.0 o superior.
- Extensiones PHP: fileinfo, json y sesiones.
- HTTPS recomendado y necesario para las notificaciones push del navegador.

INSTALACION
1. Sube el contenido de este ZIP a public_html y extraelo.
2. Copia config.example.php como config.php (no hay datos de base de datos que rellenar).
3. Asegura que PHP pueda escribir en storage/ y uploads/avatars/.
4. Abre tu web por HTTPS y registra tu cuenta.

ALMACENAMIENTO
Las cuentas y su progreso se guardan en archivos JSON dentro de storage/. Las contraseñas se almacenan con password_hash(). La primera cuenta registrada se marca como propietaria. Se registra REMOTE_ADDR como IP de creación y último acceso.

IMPORTANTE
- No borres storage/ ni sus archivos: contienen cuentas y progreso.
- Haz copias de seguridad periódicas de storage/.
- La IP puede cambiar y no es un método de autenticación.
- En hosting compartido, confirma que .htaccess sea respetado y que storage/ no sea accesible por HTTP.
- Este paquete no incorpora chats ni tickets.
