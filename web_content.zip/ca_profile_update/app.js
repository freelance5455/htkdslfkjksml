const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const courses = [
  {id:"html",title:"HTML desde cero",desc:"Construye la estructura de páginas web.",icon:"🌐",tag:"PRINCIPIANTE",lessons:[
    {title:"Tu primera página",time:"5 min",body:"HTML define la estructura de una página. Las etiquetas le dicen al navegador qué mostrar.",code:'<h1>¡Hola, mundo!</h1>\n<p>Estoy aprendiendo HTML.</p>',quiz:"¿Qué etiqueta crea el título principal?",options:["<p>","<h1>","<img>"],answer:1},
    {title:"Textos y enlaces",time:"6 min",body:"Usa <code>&lt;p&gt;</code> para párrafos, <code>&lt;strong&gt;</code> para dar importancia y <code>&lt;a&gt;</code> para crear enlaces.",code:'<h1>Mi sitio</h1>\n<p>Visita mi <strong>página</strong>.</p>\n<a href="https://example.com">Abrir enlace</a>',quiz:"¿Qué etiqueta crea un enlace?",options:["<a>","<h1>","<br>"],answer:0},
    {title:"Imágenes y listas",time:"7 min",body:"Las listas ordenadas usan <code>&lt;ol&gt;</code>, las listas con viñetas usan <code>&lt;ul&gt;</code> y cada elemento va dentro de <code>&lt;li&gt;</code>.",code:'<h2>Mis lenguajes</h2>\n<ul><li>HTML</li><li>CSS</li><li>JavaScript</li></ul>',quiz:"¿Qué etiqueta representa un elemento de lista?",options:["<li>","<title>","<head>"],answer:0}
  ]},
  {id:"css",title:"CSS y diseño web",desc:"Colores, espacios y diseños adaptables.",icon:"🎨",tag:"PRINCIPIANTE",lessons:[
    {title:"Dale estilo a tu página",time:"6 min",body:"CSS cambia la apariencia de HTML. Puedes controlar colores, tamaños, bordes y espaciado.",code:'h1 {\n  color: rebeccapurple;\n  font-size: 32px;\n}\nbody { font-family: sans-serif; }',quiz:"¿Qué propiedad cambia el color del texto?",options:["font-size","color","padding"],answer:1},
    {title:"Espaciado y tarjetas",time:"8 min",body:"<code>padding</code> crea espacio dentro de un elemento y <code>margin</code> crea espacio por fuera.",code:'.card {\n  padding: 20px;\n  margin: 12px;\n  border-radius: 16px;\n  background: #eee;\n}',quiz:"¿Qué propiedad redondea las esquinas?",options:["border-radius","margin","display"],answer:0}
  ]},
  {id:"js",title:"JavaScript interactivo",desc:"Variables, funciones y botones con lógica.",icon:"⚡",tag:"PRINCIPIANTE",lessons:[
    {title:"Variables y mensajes",time:"7 min",body:"JavaScript añade comportamiento a las páginas. Declara variables con <code>const</code> o <code>let</code>.",code:'const nombre = "Alex";\nconsole.log("Hola, " + nombre);',quiz:"¿Qué función muestra un mensaje en la consola?",options:["console.log()","show.text()","print.web()"],answer:0},
    {title:"Funciones",time:"8 min",body:"Una función reúne instrucciones que puedes reutilizar cuando las necesites.",code:'function saludar(nombre) {\n  return "¡Hola, " + nombre + "!";\n}\nconsole.log(saludar("Alex"));',quiz:"¿Qué palabra se usa para declarar una función?",options:["make","function","repeat"],answer:1}
  ]},
  {id:"python",title:"Python práctico",desc:"Aprende la sintaxis y ejecuta tus primeros programas.",icon:"🐍",tag:"PRINCIPIANTE",lessons:[
    {title:"Hola, Python",time:"5 min",body:"<code>print()</code> muestra información. Los textos se escriben entre comillas.",code:'print("¡Hola, mundo!")\nprint("Estoy aprendiendo Python")',quiz:"¿Qué función muestra texto en Python?",options:["console.log()","echo()","print()"],answer:2},
    {title:"Variables y números",time:"7 min",body:"Las variables guardan datos. Python reconoce números, texto y muchos otros tipos de valores.",code:'nombre = "Alex"\nedad = 15\nprint(nombre)\nprint(edad + 1)',quiz:"¿Cómo asignas un valor a una variable?",options:["nombre = valor","nombre == valor","set nombre valor"],answer:0}
  ]}
];


// Más práctica: cinco lecciones adicionales por ruta.
const extraLessons = {"html":[["Estructura completa","Organiza una página con <code>&lt;header&gt;</code>, <code>&lt;main&gt;</code> y <code>&lt;footer&gt;</code>.","<header>Mi sitio</header>\n<main><h1>Bienvenido</h1><p>Mi primera web.</p></main>\n<footer>Creado por mí</footer>","¿Qué etiqueta contiene el contenido principal?",["<main>","<footer>","<head>"],0,"Crea una página con header, un h1 dentro de main y footer.",["<header>","<main>","<h1>","<footer>"]],["Formularios","Los formularios permiten recopilar datos usando <code>&lt;form&gt;</code>, <code>&lt;label&gt;</code> e <code>&lt;input&gt;</code>.","<form>\n <label for=\"nombre\">Tu nombre</label>\n <input id=\"nombre\" placeholder=\"Escribe aquí\">\n <button>Enviar</button>\n</form>","¿Qué etiqueta crea un campo de entrada?",["<input>","<section>","<img>"],0,"Crea un formulario con label, input y botón.",["<form>","<label","<input","<button"]],["Imágenes accesibles","Usa el atributo alt para describir imágenes a quienes no pueden verlas.","<h1>Mi mascota</h1>\n<img src=\"https://placehold.co/240x140\" alt=\"Ilustración de un gato\">","¿Para qué sirve alt?",["Cambiar el color","Describir la imagen","Aumentar el tamaño"],1,"Añade una imagen con atributo alt descriptivo.",["<img","alt="]],["Tablas de datos","Las tablas usan <code>&lt;table&gt;</code>, filas <code>&lt;tr&gt;</code> y celdas <code>&lt;td&gt;</code>.","<table><tr><th>Lenguaje</th><th>Nivel</th></tr><tr><td>HTML</td><td>Inicial</td></tr></table>","¿Qué etiqueta crea una fila?",["<td>","<tr>","<table>"],1,"Crea una tabla con una fila y dos celdas.",["<table","<tr","<td"]],["Semántica web","Las etiquetas semánticas explican qué función cumple cada parte de la página.","<nav><a href=\"#inicio\">Inicio</a></nav>\n<section id=\"inicio\"><h2>Mi proyecto</h2></section>","¿Cuál es una etiqueta semántica?",["<div>","<nav>","<b>"],1,"Crea una navegación nav y una sección section.",["<nav>","<section>"]]],"css":[["Selectores y clases","Las clases empiezan con punto en CSS y se conectan con class en HTML.",".destacado { color: #8b5cf6; font-weight: bold; }","¿Cómo seleccionas una clase?",["#clase",".clase","clase()"],1,"Diseña una clase .tarjeta con color, padding y border-radius.",[".tarjeta","color:","padding:","border-radius:"]],["Diseño con Flexbox","Flexbox alinea elementos de forma flexible con display:flex y gap.",".fila { display: flex; gap: 12px; justify-content: center; }","¿Qué activa Flexbox?",["display: flex","position: fixed","font: flex"],0,"Crea una clase .fila usando display:flex y gap.",[".fila","display: flex","gap:"]],["Fondos y degradados","Puedes combinar colores con linear-gradient para crear fondos atractivos.",".hero { background: linear-gradient(120deg, #7c3aed, #22d3ee); color: white; padding: 24px; }","¿Qué función crea un degradado lineal?",["color-mix()","linear-gradient()","font-gradient()"],1,"Crea una clase .hero con linear-gradient y padding.",[".hero","linear-gradient","padding:"]],["Diseño adaptable","Las media queries permiten adaptar estilos a pantallas pequeñas.","@media (max-width: 600px) { h1 { font-size: 24px; } }","¿Qué regla permite aplicar estilos según el ancho?",["@media","@screening","@mobile"],0,"Escribe una media query max-width:600px que cambie el tamaño de h1.",["@media","max-width","h1","font-size:"]],["Animaciones suaves","Las transiciones suavizan los cambios visuales entre estados.",".boton { transition: transform .2s ease; }\n.boton:hover { transform: translateY(-3px); }","¿Qué propiedad suaviza cambios?",["transition","animation-name-only","smooth"],0,"Crea una clase .boton con transition y un estado :hover.",[".boton","transition:",":hover"]]],"js":[["Condiciones","if y else permiten ejecutar distintas instrucciones según una condición.","const puntos = 80;\nif (puntos >= 60) { console.log(\"Aprobado\"); } else { console.log(\"Sigue practicando\"); }","¿Qué palabra inicia una condición?",["if","loop","choose"],0,"Crea una variable puntos y una condición if que use console.log.",["const","if","console.log"]],["Bucles","Un bucle for repite instrucciones un número de veces.","for (let i = 1; i <= 3; i++) { console.log(i); }","¿Qué estructura repite instrucciones?",["for","const","return"],0,"Escribe un bucle for que muestre números usando console.log.",["for","let","console.log"]],["Arrays","Los arrays guardan varios valores en una sola variable.","const colores = [\"lila\", \"azul\", \"verde\"];\nconsole.log(colores[0]);","¿Qué índice tiene el primer elemento?",["1","0","-1"],1,"Crea un array llamado tareas y muestra uno de sus elementos.",["const tareas","[","console.log"]],["Eventos de botones","Los eventos permiten ejecutar código cuando la persona pulsa un botón.","document.querySelector(\"button\").addEventListener(\"click\", () => alert(\"¡Hola!\"));","¿Qué evento detecta un clic?",["click","hovering","press-now"],0,"Usa addEventListener y el evento click para mostrar un mensaje.",["addEventListener","click","alert"]],["Objetos","Los objetos agrupan datos en propiedades con nombre.","const usuario = { nombre: \"Luz\", nivel: 1 };\nconsole.log(usuario.nombre);","¿Cómo accedes a una propiedad llamada nombre?",["usuario->nombre","usuario.nombre","usuario(nombre)"],1,"Crea un objeto perfil con una propiedad nombre y muéstrala con console.log.",["const perfil","nombre:","console.log",".nombre"]]],"python":[["Condiciones en Python","if y else ejecutan instrucciones distintas según una condición.","puntos = 80\nif puntos >= 60:\n    print(\"Aprobado\")\nelse:\n    print(\"Sigue practicando\")","¿Qué símbolo termina la línea de if?",[":",";","{}"],0,"Crea puntos y una condición if que muestre un mensaje con print.",["puntos =","if ",":","print("]],["Listas","Las listas guardan varios elementos en orden y usan corchetes.","frutas = [\"manzana\", \"pera\", \"uva\"]\nprint(frutas[0])","¿Qué símbolo se usa para una lista?",["{}","[]","()"],1,"Crea una lista llamada juegos y muestra un elemento con print.",["juegos =","[","print("]],["Bucles for","for permite recorrer elementos de una lista o un rango.","for numero in range(1, 4):\n    print(numero)","¿Qué función crea una secuencia de números?",["range()","repeat()","sequence()"],0,"Usa for y range() para mostrar números con print.",["for ","range(","print("]],["Funciones","def crea una función que puedes llamar cuando necesites.","def saludar(nombre):\n    print(\"Hola,\", nombre)\nsaludar(\"Alex\")","¿Qué palabra declara una función?",["func","def","make"],1,"Define una función llamada presentar y ejecútala; usa print dentro.",["def presentar","print(","presentar("]],["Diccionarios","Los diccionarios guardan pares de clave y valor.","perfil = {\"nombre\": \"Alex\", \"nivel\": 2}\nprint(perfil[\"nombre\"])","¿Qué estructura guarda clave y valor?",["Lista","Diccionario","Tupla solamente"],1,"Crea un diccionario alumno con nombre y muestra esa clave usando print.",["alumno =","nombre","print("]]]};
for (const c of courses) {
  const extras = extraLessons[c.id] || [];
  extras.forEach(([title,body,code,quiz,options,answer,task,checks],i)=>c.lessons.push({title,body,code,quiz,options,answer,time:"6 min",task,checks}));
  c.lessons.forEach((l,i)=>{
    if (!l.task) {
      l.task = c.id==="html" ? "Crea un mini documento HTML que tenga un título h1, un párrafo y un enlace." : c.id==="css" ? "Escribe una regla CSS para cambiar el color y el espaciado de un elemento." : c.id==="js" ? "Escribe un mini programa JavaScript con una variable y console.log()." : "Escribe un pequeño programa Python que use una variable y print().";
      l.checks = c.id==="html" ? ["<h1>","<p>"] : c.id==="css" ? ["color:","padding:"] : c.id==="js" ? ["const","console.log"] : ["=","print("];
    }
  });
}


// Banco ampliado: 100 lecciones por lenguaje (400 en total).
const lessonBank = {
 html: [
  ["Encabezados y jerarquía","Usa h1 para el título principal y h2/h3 para organizar secciones.","<h1>Mi proyecto</h1>\n<h2>Sobre mí</h2>\n<p>Estoy aprendiendo.</p>","Crea un título h1, un subtítulo h2 y un párrafo.",["<h1","<h2","<p"]],
  ["Párrafos y saltos","Los párrafos separan ideas; br crea un salto de línea cuando es necesario.","<p>Primera idea.</p>\n<p>Segunda idea.</p>","Escribe dos párrafos dentro de tu página.",["<p>"]],
  ["Texto importante","strong expresa importancia y em marca énfasis.","<p><strong>Importante:</strong> practica cada día.</p>","Crea un párrafo que incluya strong y em.",["<p>","<strong>","<em>"]],
  ["Enlaces seguros","La etiqueta a crea enlaces; el atributo href indica el destino.","<a href=\"https://example.com\">Visitar ejemplo</a>","Crea un enlace con href y un texto descriptivo.",["<a","href="]],
  ["Listas ordenadas","ol muestra una lista numerada y li representa cada elemento.","<ol><li>Planear</li><li>Crear</li><li>Probar</li></ol>","Crea una lista ordenada con al menos dos elementos.",["<ol","<li>"]],
  ["Listas con viñetas","ul crea una lista con viñetas; cada elemento va en li.","<ul><li>HTML</li><li>CSS</li></ul>","Crea una lista ul con dos elementos li.",["<ul","<li>"]],
  ["Imágenes y texto alternativo","img muestra una imagen y alt describe su contenido.","<img src=\"gato.jpg\" alt=\"Gato sentado\">","Añade una imagen con src y una descripción alt.",["<img","src=","alt="]],
  ["Botones y acciones","button crea un botón interactivo que puede conectarse a JavaScript.","<button type=\"button\">Probar</button>","Crea un botón con un texto claro.",["<button"]],
  ["Formularios básicos","form agrupa controles para introducir información.","<form><label for=\"alias\">Alias</label><input id=\"alias\"></form>","Crea un form con label e input.",["<form","<label","<input"]],
  ["Tipos de input","type cambia el control: text, email, number, checkbox y otros.","<input type=\"text\" placeholder=\"Tu nombre\">","Crea un input de texto con placeholder.",["<input","type=","placeholder="]],
  ["Etiquetas semánticas","header, nav, main y footer explican la función de cada zona.","<header>Mi sitio</header><main><h1>Inicio</h1></main><footer>Fin</footer>","Construye una página con header, main y footer.",["<header>","<main>","<footer>"]],
  ["Secciones de contenido","section agrupa contenido relacionado y puede tener un encabezado.","<section><h2>Proyectos</h2><p>Mis trabajos.</p></section>","Crea una section con h2 y p.",["<section>","<h2>","<p>"]],
  ["Tarjetas de contenido","Puedes combinar div, encabezados y párrafos para formar una tarjeta.","<article><h2>Mi tarjeta</h2><p>Descripción breve.</p></article>","Crea una tarjeta con article, título y descripción.",["<article>","<h2>","<p>"]],
  ["Tablas: filas y celdas","table contiene filas tr; th son encabezados y td son datos.","<table><tr><th>Curso</th><th>Nivel</th></tr><tr><td>HTML</td><td>Inicial</td></tr></table>","Crea una tabla con una fila de encabezados y una fila de datos.",["<table>","<tr>","<td>"]],
  ["Audio y video","audio y video pueden incluir controles para reproducir medios.","<video controls width=\"240\"></video>","Añade un elemento video con controls.",["<video","controls"]],
  ["Comentarios HTML","Los comentarios sirven para dejar notas que no se muestran en la página.","<!-- Sección principal -->\n<h1>Mi web</h1>","Incluye un comentario y un título h1.",["<!--","<h1>"]],
  ["Atributos id y class","id identifica un elemento y class permite agrupar elementos con estilos comunes.","<h2 id=\"inicio\" class=\"titulo\">Inicio</h2>","Crea un elemento con id y class.",["id=","class="]],
  ["Rutas relativas","Una ruta relativa apunta a un archivo dentro de tu proyecto.","<img src=\"images/logo.png\" alt=\"Logo\">","Crea una imagen con una ruta relativa y alt.",["src=","alt="]],
  ["Metadatos de página","title nombra la pestaña y meta viewport ayuda a adaptar la página al móvil.","<head><title>Mi web</title><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"></head>","Escribe title y meta viewport dentro de head.",["<title>","viewport"]],
  ["Accesibilidad inicial","Las etiquetas claras y los textos alternativos ayudan a más personas a usar la web.","<label for=\"correo\">Correo</label><input id=\"correo\" type=\"email\">","Crea un campo email con label asociado mediante for e id.",["<label","for=","type=\"email\""]],
  ["Detalles desplegables","details y summary crean un bloque que se puede abrir y cerrar.","<details><summary>Ver más</summary><p>Contenido extra.</p></details>","Crea un details con summary y un párrafo.",["<details>","<summary>","<p>"]],
  ["Contenido destacado","blockquote marca una cita y cite puede indicar su fuente.","<blockquote>Aprender haciendo funciona.</blockquote>","Añade una cita dentro de blockquote.",["<blockquote>"]],
  ["Datos de contacto","address representa información de contacto del autor o de la organización.","<address>Contacto: hola@example.com</address>","Crea un bloque address con un dato de contacto ficticio.",["<address>"]],
  ["Mini página de perfil","Combina encabezados, imagen, párrafo y una lista en una página personal.","<h1>Mi perfil</h1><p>Aprendo a programar.</p><ul><li>Diseño</li></ul>","Crea una mini página con h1, p y una lista ul.",["<h1>","<p>","<ul"]],
  ["Proyecto: página completa","Une secciones semánticas y contenido para construir una página pequeña.","<header>Mi marca</header><main><h1>Hola</h1><p>Mi proyecto web.</p></main><footer>2026</footer>","Crea una página con header, main, h1, p y footer.",["<header>","<main>","<h1>","<footer>"]]
 ],
 css: [
  ["Selectores por etiqueta","Un selector como p aplica estilos a todos los párrafos.","p { color: #c4b5fd; }","Escribe una regla para p que cambie color y tamaño.",["p","color:","font-size:"]],
  ["Clases reutilizables","Las clases se seleccionan con punto y pueden usarse en varios elementos.",".tarjeta { padding: 16px; border-radius: 12px; }","Crea .tarjeta con padding y border-radius.",[".tarjeta","padding:","border-radius:"]],
  ["Colores de texto","color acepta nombres, hexadecimales, rgb y otros formatos.","h1 { color: #8b5cf6; }","Cambia el color de h1 usando una regla CSS.",["h1","color:"]],
  ["Fondos modernos","background-color aplica un color de fondo a un elemento.","body { background-color: #111827; color: white; }","Establece un fondo y un color de texto para body.",["background-color:","color:"]],
  ["Tamaños y unidades","px, rem, % y vw permiten definir dimensiones según distintas necesidades.","h1 { font-size: 2rem; }","Crea una regla con font-size usando rem.",["font-size:","rem"]],
  ["Espaciado interno","padding crea espacio entre el contenido y el borde.",".panel { padding: 20px; }","Define padding para una clase .panel.",[".panel","padding:"]],
  ["Espaciado externo","margin crea espacio alrededor de un elemento.",".panel { margin: 12px auto; }","Crea una regla con margin para centrar una tarjeta.",[".panel","margin:"]],
  ["Bordes redondeados","border-radius suaviza las esquinas de tarjetas y botones.","button { border-radius: 999px; }","Haz un botón con bordes redondeados.",["button","border-radius:"]],
  ["Sombras suaves","box-shadow crea profundidad con sombras alrededor de un elemento.",".card { box-shadow: 0 8px 24px #0003; }","Añade una sombra a .card.",[".card","box-shadow:"]],
  ["Tipografía","font-family permite elegir una familia tipográfica con alternativas.","body { font-family: Arial, sans-serif; }","Define una familia tipográfica para body.",["font-family:"]],
  ["Alinear texto","text-align controla la alineación horizontal del texto.","h1 { text-align: center; }","Centra el texto de h1.",["text-align:","center"]],
  ["Ancho y alto","width y max-width ayudan a controlar el tamaño de los bloques.",".contenedor { width: 100%; max-width: 720px; }","Crea un contenedor con width y max-width.",["width:","max-width:"]],
  ["Flexbox inicial","display:flex organiza elementos en una fila o columna flexible.",".fila { display: flex; gap: 12px; }","Crea una fila con display:flex y gap.",["display: flex","gap:"]],
  ["Alineación con Flexbox","justify-content reparte el espacio principal y align-items alinea el eje cruzado.",".fila { display: flex; justify-content: center; align-items: center; }","Centra elementos con justify-content y align-items.",["justify-content:","align-items:"]],
  ["Diseño en cuadrícula","CSS Grid organiza elementos en columnas y filas.",".grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }","Crea una cuadrícula de dos columnas con gap.",["display: grid","grid-template-columns:","gap:"]],
  ["Estados hover",":hover aplica estilos cuando el cursor está sobre un elemento.","button:hover { transform: translateY(-2px); }","Crea un estado hover para un botón.",[":hover","transform:"]],
  ["Transiciones","transition anima suavemente los cambios de propiedades.","button { transition: transform .2s ease; }","Añade una transición a un botón.",["transition:"]],
  ["Animaciones keyframes","@keyframes define pasos de una animación CSS.","@keyframes flotar { from { transform: translateY(0); } to { transform: translateY(-5px); } }","Define una animación con @keyframes y úsala con animation.",["@keyframes","transform:","animation:"]],
  ["Degradados","linear-gradient mezcla colores en un fondo.",".hero { background: linear-gradient(120deg, #7c3aed, #06b6d4); }","Crea un fondo con linear-gradient.",["linear-gradient"]],
  ["Posición relativa","position:relative permite posicionar hijos absolutos dentro de un contenedor.",".caja { position: relative; }","Define una caja con position relative.",["position: relative"]],
  ["Diseño adaptable","@media aplica reglas según el ancho o las capacidades del dispositivo.","@media (max-width: 600px) { h1 { font-size: 24px; } }","Crea una media query para pantallas menores de 600px.",["@media","max-width:"]],
  ["Variables CSS","--nombre define una variable y var() permite reutilizarla en varias reglas.",":root { --acento: #8b5cf6; }\n.titulo { color: var(--acento); }","Declara una variable CSS y úsala con var().",["--acento:","var("]],
  ["Modo oscuro","Combina fondos oscuros y texto claro manteniendo buen contraste.","body { background: #111827; color: #f9fafb; }","Crea una regla para modo oscuro con background y color.",["background:","color:"]],
  ["Estados focus",":focus ayuda a identificar el control que recibe la entrada del teclado.","input:focus { outline: 2px solid #8b5cf6; }","Añade un estado focus visible a input.",[":focus","outline:"]],
  ["Mini interfaz","Combina tarjetas, espaciado, color y tipografía para formar una interfaz.",".card { padding: 18px; border-radius: 16px; background: #202033; color: white; }","Crea una tarjeta con padding, border-radius y background.",[".card","padding:","border-radius:","background:"]]
 ],
 js: [
  ["Variables const y let","const declara una referencia que no reasignas; let permite reasignar el valor.","const nombre = 'Alex';\nlet puntos = 0;\npuntos = puntos + 10;\nconsole.log(nombre, puntos);","Crea una variable const, una let y muestra ambas con console.log.",["const ","let ","console.log"]],
  ["Tipos de datos","JavaScript maneja strings, números, booleanos, arrays, objetos y más.","const activo = true;\nconst nivel = 3;\nconsole.log(activo, nivel);","Crea una variable booleana y una numérica y muéstralas.",["const ","true","console.log"]],
  ["Operaciones matemáticas","Puedes sumar, restar, multiplicar y dividir valores numéricos.","const total = 12 + 8;\nconsole.log(total);","Calcula una suma y muestra el resultado.",["const ","+","console.log"]],
  ["Plantillas de texto","Los template literals usan backticks y permiten insertar variables con ${}.","const nombre = 'Sam';\nconsole.log(`Hola, ${nombre}`);","Crea un mensaje usando backticks y una variable.",["const ","console.log","${"]],
  ["Condiciones if/else","if ejecuta un bloque cuando una condición es verdadera; else cubre el otro caso.","const edad = 18;\nif (edad >= 18) { console.log('Adulto'); } else { console.log('Menor'); }","Escribe una condición if/else y usa console.log.",["if (","else","console.log"]],
  ["Operadores lógicos","&& significa y, || significa o y ! invierte un booleano.","const tieneCuenta = true;\nconst activo = true;\nconsole.log(tieneCuenta && activo);","Crea dos booleanos y combínalos con &&.",["const ","&&","console.log"]],
  ["Bucles for","for repite instrucciones mientras se cumpla una condición.","for (let i = 1; i <= 3; i++) { console.log(i); }","Escribe un bucle for que muestre números.",["for (","let i","console.log"]],
  ["Bucles while","while repite un bloque mientras su condición siga siendo verdadera.","let cuenta = 1;\nwhile (cuenta <= 3) { console.log(cuenta); cuenta++; }","Crea un while que avance un contador y muestre su valor.",["while (","console.log","++"]],
  ["Arrays","Los arrays guardan listas de valores y acceden a posiciones empezando por cero.","const colores = ['lila', 'azul'];\nconsole.log(colores[0]);","Crea un array y muestra su primer elemento.",["const ","[","console.log"]],
  ["Métodos de arrays","push agrega elementos al final de un array.","const tareas = ['leer'];\ntareas.push('practicar');\nconsole.log(tareas);","Crea un array, usa push y muestra la lista.",["const ",".push(","console.log"]],
  ["Funciones","function declara funciones reutilizables que pueden recibir parámetros.","function saludar(nombre) { return 'Hola ' + nombre; }\nconsole.log(saludar('Lee'));","Define una función y llama a esa función.",["function ","return","console.log"]],
  ["Funciones flecha","Las arrow functions usan => para escribir funciones de forma compacta.","const doble = (n) => n * 2;\nconsole.log(doble(4));","Crea una función flecha y ejecútala.",["const ","=>","console.log"]],
  ["Objetos","Los objetos agrupan propiedades y valores relacionados.","const perfil = { nombre: 'Kai', nivel: 2 };\nconsole.log(perfil.nombre);","Crea un objeto con nombre y muestra esa propiedad.",["const ","nombre:","console.log",".nombre"]],
  ["DOM: seleccionar elementos","querySelector encuentra el primer elemento que coincide con un selector CSS.","const titulo = document.querySelector('h1');\nconsole.log(titulo);","Selecciona un h1 con querySelector y muestra el resultado.",["querySelector(","console.log"]],
  ["Cambiar contenido","textContent cambia el texto que se muestra dentro de un elemento.","document.querySelector('h1').textContent = 'Nuevo título';","Selecciona un h1 y cambia textContent.",["querySelector(","textContent"]],
  ["Eventos de clic","addEventListener permite responder a eventos como click.","document.querySelector('button').addEventListener('click', () => alert('¡Hola!'));","Conecta un botón con addEventListener y click.",["addEventListener(","click","alert("]],
  ["Crear elementos","createElement crea un elemento nuevo que puedes añadir al documento.","const p = document.createElement('p');\np.textContent = 'Nuevo párrafo';\ndocument.body.append(p);","Crea un párrafo, añade texto y agrégalo al body.",["createElement(","textContent","append("]],
  ["Temporizadores","setTimeout ejecuta una función después de un retraso.","setTimeout(() => console.log('Listo'), 500);","Usa setTimeout para mostrar un mensaje en consola.",["setTimeout(","console.log"]],
  ["JSON básico","JSON.stringify convierte datos a texto JSON; JSON.parse hace lo contrario.","const perfil = { nivel: 1 };\nconst texto = JSON.stringify(perfil);\nconsole.log(texto);","Convierte un objeto a JSON y muestra el texto.",["JSON.stringify(","console.log"]],
  ["Manejo de errores","try/catch permite capturar errores y responder sin detener silenciosamente el flujo.","try { JSON.parse('{mal}'); } catch (error) { console.log('JSON inválido'); }","Escribe try/catch y muestra un mensaje en catch.",["try {","catch (","console.log"]],
  ["Módulos y organización","Separar el código en funciones pequeñas facilita mantenerlo y probarlo.","function sumar(a, b) { return a + b; }\nconsole.log(sumar(2, 3));","Crea una función pequeña y prueba su resultado.",["function ","return","console.log"]],
  ["Validar formularios","Puedes revisar el valor de un campo antes de continuar.","const valor = document.querySelector('input').value;\nif (valor.trim()) console.log('Correcto');","Lee un input y comprueba que el valor no esté vacío.",["querySelector(",".value","if (","console.log"]],
  ["Clases CSS desde JS","classList.add añade una clase a un elemento.","document.querySelector('.card').classList.add('activa');","Selecciona una tarjeta y añade una clase con classList.add.",["querySelector(","classList.add("]],
  ["Mini interacción","Combina un evento, una variable y un cambio de texto para crear interacción.","let puntos = 0;\ndocument.querySelector('button').addEventListener('click', () => { puntos++; console.log(puntos); });","Crea un contador que aumente al hacer clic.",["let puntos","addEventListener(","click","puntos++"]]
 ],
 python: [
  ["print y comentarios","print muestra información; los comentarios empiezan con #.","# Mi primer programa\nprint('Hola, mundo')","Escribe un comentario y un print con tu propio mensaje.",["#","print("]],
  ["Variables y asignación","Usa = para asignar un valor a una variable.","nombre = 'Alex'\npuntos = 10\nprint(nombre, puntos)","Crea una variable de texto, una numérica y muéstralas.",["=","print("]],
  ["Números y operaciones","Python permite sumar, restar, multiplicar y dividir números.","total = 12 + 8\nprint(total)","Calcula una suma y muestra el resultado.",["=","+","print("]],
  ["Texto y f-strings","Las f-strings insertan variables en un texto usando llaves.","nombre = 'Sam'\nprint(f'Hola, {nombre}')","Crea un mensaje con f-string y una variable.",["=","f'","print(","{"]],
  ["Entrada del usuario","input solicita texto a la persona que ejecuta el programa.","nombre = input('¿Cómo te llamas? ')\nprint('Hola', nombre)","Usa input para pedir un nombre y print para saludar.",["input(","print("]],
  ["Conversión de tipos","int convierte un texto numérico en entero; float lo convierte en decimal.","edad = int('15')\nprint(edad + 1)","Convierte un número de texto con int y muestra una operación.",["int(","print("]],
  ["Condiciones if","if ejecuta un bloque cuando la condición es verdadera y termina con dos puntos.","puntos = 80\nif puntos >= 60:\n    print('Aprobado')","Crea una condición if que muestre un mensaje.",["if ",":","print("]],
  ["Alternativa else","else define qué hacer cuando la condición if no se cumple.","edad = 14\nif edad >= 18:\n    print('Adulto')\nelse:\n    print('Menor')","Escribe if/else para clasificar un número.",["if ","else:","print("]],
  ["Operadores and/or","and requiere que ambas condiciones sean verdaderas; or requiere al menos una.","tiene_clave = True\nactivo = True\nprint(tiene_clave and activo)","Crea dos booleanos y combínalos con and.",["= True","and","print("]],
  ["Listas","Las listas guardan varios elementos en orden y se escriben con corchetes.","lenguajes = ['HTML', 'CSS']\nprint(lenguajes[0])","Crea una lista y muestra uno de sus elementos.",["= [","print("]],
  ["Añadir a una lista","append añade un nuevo elemento al final de una lista.","tareas = ['leer']\ntareas.append('practicar')\nprint(tareas)","Crea una lista, añade un elemento con append y muéstrala.",["= [",".append(","print("]],
  ["Recorrer listas","for permite recorrer cada elemento de una lista.","for lenguaje in ['HTML', 'Python']:\n    print(lenguaje)","Escribe un for que recorra una lista y use print.",["for ","in [","print("]],
  ["range y contadores","range genera una secuencia útil para repetir acciones un número de veces.","for numero in range(1, 4):\n    print(numero)","Usa for y range para mostrar tres números.",["for ","range(","print("]],
  ["Funciones con def","def declara una función que puedes llamar cuando la necesites.","def saludar(nombre):\n    print('Hola', nombre)\nsaludar('Lee')","Define una función y llámala con un argumento.",["def ","print(","saludar("]],
  ["return","return devuelve un resultado desde una función.","def doble(n):\n    return n * 2\nprint(doble(4))","Crea una función que devuelva un valor y muéstralo.",["def ","return","print("]],
  ["Diccionarios","Los diccionarios guardan pares de clave y valor.","perfil = {'nombre': 'Kai', 'nivel': 2}\nprint(perfil['nombre'])","Crea un diccionario y muestra una clave.",["= {","nombre","print("]],
  ["Tuplas","Las tuplas agrupan valores y suelen escribirse con paréntesis.","coordenadas = (3, 5)\nprint(coordenadas[0])","Crea una tupla de dos valores y muestra el primero.",["= (","print("]],
  ["Conjuntos","set almacena valores únicos y elimina duplicados.","colores = set(['azul', 'azul', 'lila'])\nprint(colores)","Crea un conjunto con set y muéstralo.",["set(","print("]],
  ["Importar módulos","import permite usar funciones de módulos de la biblioteca.","import math\nprint(math.sqrt(81))","Importa math y utiliza una función de ese módulo.",["import ","math.","print("]],
  ["Manejo de errores","try/except permite gestionar errores esperados.","try:\n    numero = int('abc')\nexcept ValueError:\n    print('Escribe un número válido')","Escribe try/except y muestra un mensaje de error.",["try:","except","print("]],
  ["Archivos: idea básica","open permite abrir archivos; el modo w escribe y puede reemplazar contenido.","with open('nota.txt', 'w') as archivo:\n    archivo.write('Hola')","Escribe un ejemplo con open y write.",["open(","with ","write("]],
  ["Comprensiones de listas","Una comprensión crea una lista a partir de una secuencia.","cuadrados = [n * n for n in range(4)]\nprint(cuadrados)","Crea una comprensión de lista y muéstrala.",["= [","for ","print("]],
  ["Clases y objetos","class define una clase que puede crear objetos con atributos.","class Mascota:\n    def __init__(self, nombre):\n        self.nombre = nombre\n\ngato = Mascota('Milo')\nprint(gato.nombre)","Define una clase con __init__, crea un objeto y muestra un atributo.",["class ","def __init__","self.","print("]],
  ["Funciones pequeñas","Separar una tarea en una función facilita reutilizar y probar el código.","def sumar(a, b):\n    return a + b\nprint(sumar(2, 3))","Escribe una función que reciba dos valores y devuelva un resultado.",["def ","return","print("]],
  ["Mini programa de práctica","Combina variables, condiciones y salida para resolver una tarea sencilla.","puntos = 75\nif puntos >= 60:\n    print('¡Nivel superado!')","Crea un mini programa con una variable, una condición y print.",["=","if ","print("]]
 ]
};
const stageNames = ["Fundamentos", "Práctica guiada", "Reto aplicado", "Proyecto final"];
for (const c of courses) {
  const bank = lessonBank[c.id];
  while (c.lessons.length < 100) {
    const n = c.lessons.length;
    const offset = Math.max(0, n - 8);
    const item = bank[offset % bank.length];
    const stage = Math.floor(offset / bank.length);
    const [baseTitle, body, codeExample, task, checks] = item;
    const variant = stageNames[stage % stageNames.length];
    const code = codeExample.replaceAll("Alex", ["Luna","Kai","Sam","Noa"][stage % 4]).replaceAll("Hola, mundo", ["Hola, equipo","Mi primer reto","Código listo","Aprender creando"][stage % 4]);
    const quizzes = {
      html: ["¿Qué describe mejor HTML?", ["Estructura el contenido", "Pinta píxeles", "Guarda contraseñas"], 0],
      css: ["¿Para qué se usa CSS?", ["Diseñar la apariencia", "Crear bases de datos", "Ejecutar Python"], 0],
      js: ["¿Qué aporta JavaScript a una web?", ["Interactividad y lógica", "Solo imágenes", "Solo tipografías"], 0],
      python: ["¿Qué función muestra información en pantalla?", ["print()", "style()", "href()"], 0]
    };
    const q = quizzes[c.id];
    c.lessons.push({title:`${variant}: ${baseTitle}`,body:`${body} En esta etapa practicarás cómo aplicar la idea en un mini ejercicio.`,code,task,checks,starter:"",quiz:q[0],options:q[1],answer:q[2],time:"6 min"});
  }
}

const state = {xp:0, completed:[], courseId:"html", lessonIndex:0, lang:"html", selected:["html","css","js","python"], quizPassed:false, codePassed:false};
const saved = (()=>{try{return JSON.parse(localStorage.getItem("codeAcademyProgress")||"{}")}catch(e){return {}}})();
state.xp = Number(saved.xp)||0;
state.completed = Array.isArray(saved.completed)?saved.completed:[];
state.selected = Array.isArray(saved.selected)?saved.selected:["html","css","js","python"];
state.profileName = typeof saved.profileName === "string" ? saved.profileName : "";
const defaults = {
 html:`<h1>¡Hola, mundo!</h1>
<p>Esta es mi primera página.</p>
<button onclick="alert('¡Funciona!')">Haz clic</button>`,
 css:`body { font-family: Arial, sans-serif; padding: 24px; background: #f4f0ff; }
h1 { color: #6d28d9; }
button { padding: 10px 14px; border: 0; border-radius: 9px; background: #7c3aed; color: white; }`,
 js:`document.body.innerHTML = "<h1>¡JavaScript funciona!</h1><p>Ya puedes crear páginas interactivas.</p>";`
};
let code = {...defaults};

function save(){try{localStorage.setItem("codeAcademyProgress",JSON.stringify({xp:state.xp,completed:state.completed,selected:state.selected,profileName:state.profileName}));}catch(e){} if(window.syncProgress) window.syncProgress();}
function courseProgress(c){return c.lessons.filter((_,i)=>state.completed.includes(`${c.id}:${i}`)).length;}
function totalLessons(){return courses.reduce((n,c)=>n+c.lessons.length,0);}
function renderCourses(target){
  $(target).innerHTML=courses.filter(c=>state.selected.includes(c.id)).map(c=>{const done=courseProgress(c),pct=Math.round(done/c.lessons.length*100);return `<article class="course-card" data-course="${c.id}"><div class="course-icon">${c.icon}</div><div class="course-info"><h3>${c.title}</h3><p>${c.desc}</p><div class="course-meta"><span>${c.lessons.length} lecciones</span><span>·</span><span>${done} completadas</span></div><div class="mini-progress"><span style="width:${pct}%"></span></div></div><span class="course-arrow">›</span></article>`}).join("");
  $$(target+" [data-course]").forEach(el=>el.addEventListener("click",()=>openCourse(el.dataset.course)));
}
function getRank(xp=state.xp){
  if(xp>=4000)return {name:"Diamante",icon:"💎",next:null,min:4000};
  if(xp>=2000)return {name:"Platino",icon:"🏆",next:4000,min:2000};
  if(xp>=1000)return {name:"Oro",icon:"🥇",next:2000,min:1000};
  if(xp>=400)return {name:"Plata",icon:"🥈",next:1000,min:400};
  if(xp>=100)return {name:"Bronce",icon:"🥉",next:400,min:100};
  return {name:"Novato",icon:"🌱",next:100,min:0};
}
function updateRankUI(){
  const rank=getRank();
  ["rankName","profileRank"].forEach(id=>{const el=document.getElementById(id);if(el)el.textContent=rank.icon+" "+rank.name;});
  const span=rank.next?Math.max(0,Math.min(100,(state.xp-rank.min)/(rank.next-rank.min)*100)):100;["rankProgress","profileRankProgress"].forEach(id=>{const bar=document.getElementById(id);if(bar)bar.style.width=span+"%";});
  const next=document.getElementById("rankNext");if(next)next.textContent=rank.next?`${rank.next-state.xp} XP para ${rank.next===100?"Bronce":rank.next===400?"Plata":rank.next===1000?"Oro":rank.next===2000?"Platino":"Diamante"}`:"¡Rango máximo alcanzado!";
  const name=document.getElementById("profileNameLabel");if(name)name.textContent=state.profileName||"Programador en progreso";
}
function updateProgress(){
  $("#xpValue").textContent=state.xp+" XP";$("#profileXp").textContent=state.xp+" XP";
  updateRankUI();
  $("#doneValue").textContent=state.completed.length;$("#profileDone").textContent=state.completed.length;
  $("#profilePercent").textContent=Math.round(state.completed.length/totalLessons()*100)+"%";
  $("#completedList").innerHTML=state.completed.length?state.completed.map(key=>{const [cid,li]=key.split(":");const c=courses.find(x=>x.id===cid);return c?`<div class="completed-item"><span>✓</span><div>${c.title} — ${c.lessons[Number(li)]?.title||"Lección"}</div></div>`:""}).join(""):'<div class="empty-state">Todavía no has terminado lecciones. ¡Elige un curso para comenzar!</div>';
  save();renderCourses("#homeCourses");renderCourses("#allCourses");
}
function go(page){
  $$(".page").forEach(p=>p.classList.toggle("active",p.id===page));
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.go===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove("show"),2300);}
function openCourse(id){
  state.courseId=id;const c=courses.find(x=>x.id===id);if(!c)return;
  $("#lessonContent").innerHTML=`<div class="lesson-hero"><span class="eyebrow">${c.tag} · ${c.lessons.length} LECCIONES</span><h1>${c.icon} ${c.title}</h1><p>${c.desc} Selecciona una lección para comenzar.</p></div>`+
  c.lessons.map((l,i)=>`<article class="course-card" data-lesson="${i}"><div class="course-icon">${state.completed.includes(`${c.id}:${i}`)?"✓":String(i+1).padStart(2,"0")}</div><div class="course-info"><h3>${l.title}</h3><p>${l.time} · ${state.completed.includes(`${c.id}:${i}`)?"Completada":"Lección práctica"}</p></div><span class="course-arrow">›</span></article>`).join("");
  $$("#lessonContent [data-lesson]").forEach(el=>el.addEventListener("click",()=>openLesson(Number(el.dataset.lesson))));
  go("lesson");
}
function openLesson(index){
  state.lessonIndex=index;state.quizPassed=false;state.codePassed=false;
  const c=courses.find(x=>x.id===state.courseId),l=c.lessons[index],key=`${c.id}:${index}`,done=state.completed.includes(key);
  const starter = l.starter !== undefined ? l.starter : "";
  const checks=l.checks||[];
  const checkText=checks.map(x=>`<code>${escapeHTML(x)}</code>`).join(" · ");
  $("#lessonContent").innerHTML=`<button class="back-btn" id="lessonBack">← Todas las lecciones</button><div class="lesson-hero"><span class="eyebrow">${c.title.toUpperCase()} · LECCIÓN ${index+1} DE ${c.lessons.length}</span><h1>${l.title}</h1><p>${l.time} de lectura y práctica · +20 XP</p><div class="lesson-progress"><span style="width:${Math.round((index+1)/c.lessons.length*100)}%"></span></div></div><section class="lesson-block"><h2>📘 Aprende</h2><p>${l.body}</p><p>Observa este ejemplo. Después crea tu propia versión en el reto de abajo.</p><div class="lesson-hint"><strong>💡 Pistas para desarrollar</strong><p>Identifica las palabras clave, observa cómo se relacionan y prueba una pequeña modificación cada vez. Si aparece un error, revisa primero la sintaxis y los nombres.</p><small>Conceptos clave: ${checkText}</small></div><pre class="code-sample">${escapeHTML(l.code)}</pre><button class="primary lesson-action" id="tryCode">Probar ejemplo en el laboratorio →</button></section><section class="lesson-block challenge-block"><div class="challenge-label">⚡ RETO PRÁCTICO</div><h2>Ahora te toca a ti</h2><p>${l.task}</p><p class="muted">Tu código debe incluir: ${checkText}</p><textarea id="challengeEditor" class="challenge-editor" autocapitalize="off" autocorrect="off" spellcheck="false" aria-label="Escribe tu mini código">${escapeHTML(starter)}</textarea><button class="primary lesson-action" id="checkCode">▶ Revisar mi código</button><p id="codeFeedback" class="challenge-feedback" aria-live="polite">Escribe tu mini código y pulsa revisar.</p></section><section class="lesson-block"><h2>🧠 Comprueba lo aprendido</h2><p>${l.quiz}</p><div id="quizOptions">${l.options.map((o,i)=>`<button class="quiz-option" data-answer="${i}">${escapeHTML(o)}</button>`).join("")}</div><p id="quizFeedback" class="muted" aria-live="polite"></p></section><button class="primary lesson-action complete-lesson" id="completeLesson" ${done?"disabled":"disabled"}>${done?"✓ Lección completada":"Completar lección · requiere reto y pregunta"}</button><p class="muted completion-hint">Para terminar: supera el reto práctico y responde correctamente la pregunta.</p>`;
  $("#lessonBack").onclick=()=>openCourse(c.id);
  $("#tryCode").onclick=()=>{go("lab");if(c.id==="python"){$("#pythonEditor").value=l.code;}else{state.lang=c.id==="css"?"css":c.id==="js"?"js":"html";code[state.lang]=l.code;setLang(state.lang);runWeb();}};
  $("#checkCode").onclick=()=>{const value=$("#challengeEditor").value;const missing=checks.filter(x=>!value.toLowerCase().includes(x.toLowerCase()));const feedback=$("#codeFeedback");if(!value.trim()||missing.length){state.codePassed=false;feedback.className="challenge-feedback fail";feedback.textContent="Todavía falta algo. Revisa el reto e incluye: "+missing.join(", ");}else{state.codePassed=true;feedback.className="challenge-feedback success";feedback.textContent="¡Reto superado! Tu mini código contiene lo necesario. Ahora responde la pregunta.";toast("¡Código revisado!");}refreshCompleteButton();};
  $$("#quizOptions [data-answer]").forEach(btn=>btn.onclick=()=>{if(state.quizPassed)return;const correct=Number(btn.dataset.answer)===l.answer;$$("#quizOptions button").forEach(b=>{if(Number(b.dataset.answer)===l.answer)b.classList.add("correct");if(correct)b.disabled=true;});if(!correct){btn.classList.add("wrong");btn.disabled=true;}state.quizPassed=correct;$("#quizFeedback").textContent=correct?"¡Correcto! Ya puedes completar la lección si superaste el reto.":"No pasa nada: revisa el ejemplo y vuelve a intentarlo en la siguiente oportunidad.";if(correct)toast("¡Respuesta correcta!");refreshCompleteButton();});
  $("#completeLesson").onclick=()=>{if(!state.codePassed||!state.quizPassed){toast("Completa el reto y la pregunta primero.");return;}if(!state.completed.includes(key)){state.completed.push(key);state.xp+=20;updateProgress();toast("¡Lección completada! +20 XP");}else toast("Esta lección ya está completada.");openCourse(c.id);};
}
function refreshCompleteButton(){const btn=$("#completeLesson");if(!btn)return;const done=state.completed.includes(`${state.courseId}:${state.lessonIndex}`);btn.disabled=done||!(state.codePassed&&state.quizPassed);if(!done&&state.codePassed&&state.quizPassed)btn.textContent="✓ Completar lección · +20 XP";}
function escapeHTML(s){return s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");}
function setLang(lang){
  state.lang=lang;$$(".tab").forEach(b=>b.classList.toggle("active",b.dataset.lang===lang));$("#codeEditor").value=code[lang];$("#editorStatus").textContent="Editando "+lang.toUpperCase();
}
function runWeb(){
  code[state.lang]=$("#codeEditor").value;
  const html=state.lang==="html"?code.html:state.lang==="css"?"<h1>Vista previa CSS</h1><p>Cambia los estilos y ejecuta otra vez.</p>":"<h1>Vista previa JavaScript</h1><p>Abre la consola del navegador para ver resultados.</p>";
  const css=state.lang==="css"?code.css:code.css;
  const js=state.lang==="js"?code.js:"";
  const safeDoc=`<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>${css}</style></head><body>${html}<script>${js.replace(/<\/script/gi,"<\\/script")}<\/script></body></html>`;
  $("#preview").srcdoc=safeDoc;$("#editorStatus").textContent="Ejecutado · vista previa actualizada";
}
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$$(".tab").forEach(b=>b.addEventListener("click",()=>setLang(b.dataset.lang)));
$("#runWeb").addEventListener("click",runWeb);
$("#resetCode").addEventListener("click",()=>{code={...defaults};setLang(state.lang);$("#editorStatus").textContent="Código restablecido";});
$("#themeBtn").addEventListener("click",()=>{document.body.classList.toggle("light");try{localStorage.setItem("codeAcademyLight",document.body.classList.contains("light")?"1":"0");}catch(e){}});
try{if(localStorage.getItem("codeAcademyLight")==="1")document.body.classList.add("light");}catch(e){}
$("#clearProgress").addEventListener("click",()=>{if(confirm("¿Seguro que quieres borrar todo tu progreso?")){state.xp=0;state.completed=[];updateProgress();toast("Progreso borrado");}});
let pyodidePromise=null;
$("#runPython").addEventListener("click",async()=>{
  const btn=$("#runPython"),out=$("#pythonOutput");btn.disabled=true;out.textContent="Preparando Python…";$("#pythonStatus").textContent="Cargando motor de Python";
  try{
    if(!pyodidePromise){pyodidePromise=(async()=>{const s=document.createElement("script");s.src="https://cdn.jsdelivr.net/pyodide/v0.27.7/full/pyodide.js";document.head.appendChild(s);await new Promise((resolve,reject)=>{s.onload=resolve;s.onerror=()=>reject(new Error("No se pudo descargar Python. Comprueba tu conexión."));});return await loadPyodide();})(); }
    const py=await pyodidePromise;let output="";py.setStdout({batched:(s)=>{output+=s;}});py.setStderr({batched:(s)=>{output+=s;}});await py.runPythonAsync($("#pythonEditor").value);out.textContent=output||"(El programa terminó sin mostrar texto.)";$("#pythonStatus").textContent="Ejecución terminada";
  }catch(e){out.textContent=String(e);$("#pythonStatus").textContent="No se pudo ejecutar";}
  finally{btn.disabled=false;}
});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));

// Selección de rutas: el botón de inicio abre una selección guiada de lenguajes.
const languageNames={html:"HTML",css:"CSS",js:"JavaScript",python:"Python"};
const home=document.querySelector("#home");
const chooser=document.createElement("section");chooser.id="languageChooser";chooser.className="language-chooser";chooser.hidden=true;
chooser.innerHTML=`<div class="section-heading"><div><span class="eyebrow">PERSONALIZA TU RUTA</span><h2>¿Qué quieres aprender?</h2></div></div><p class="muted">Elige uno o varios lenguajes. Puedes cambiarlos después.</p><div class="language-options">${courses.map(c=>`<label class="language-option"><input type="checkbox" value="${c.id}" ${state.selected.includes(c.id)?"checked":""}><span class="language-emoji">${c.icon}</span><span><strong>${languageNames[c.id]}</strong><small>${c.lessons.length} lecciones</small></span><span class="language-check">✓</span></label>`).join("")}</div><button class="primary" id="saveLanguages">Crear mi ruta de aprendizaje →</button>`;
home.insertBefore(chooser,home.querySelector(".stats"));
$("#startLearning").addEventListener("click",()=>{chooser.hidden=false;chooser.classList.add("chooser-open");chooser.scrollIntoView({behavior:"smooth",block:"start"});});
$("#saveLanguages").addEventListener("click",()=>{const selected=$$("#languageChooser input:checked").map(x=>x.value);if(!selected.length){toast("Elige al menos un lenguaje para continuar.");return;}state.selected=selected;save();updateProgress();chooser.hidden=true;chooser.classList.remove("chooser-open");go("courses");toast("¡Tu ruta está lista!");});
updateProgress();setLang("html");runWeb();
window.addEventListener("load",()=>{const loader=$("#appLoader");if(loader){setTimeout(()=>{loader.classList.add("loader-done");setTimeout(()=>loader.remove(),450);},650);}});



// Perfil local sin Discord. El nombre se conserva en este dispositivo; el servidor crea una sesión protegida.
const authGate=document.getElementById('authGate');
const authMessage=document.getElementById('authMessage');
const accountForm=document.getElementById('accountForm');
const accountUser=document.getElementById('accountUser');
const accountPass=document.getElementById('accountPass');
const toggleAuth=document.getElementById('toggleAuth');
const logoutBtn=document.getElementById('logoutBtn');
let authMode='register', currentUser=null;
async function api(action, options={}){
 const response=await fetch('api.php?action='+encodeURIComponent(action),{credentials:'same-origin',...options,headers:{...(options.headers||{})}});
 const data=await response.json().catch(()=>({error:'Respuesta inválida del servidor.'}));
 if(!response.ok)throw new Error(data.error||'No se pudo completar la solicitud.');
 return data;
}
function showAuth(msg){authGate.hidden=false;document.body.classList.add('auth-locked');if(msg)authMessage.textContent=msg;}
function showApp(){authGate.hidden=true;document.body.classList.remove('auth-locked');logoutBtn.style.display='block';}
function setAuthMode(mode){authMode=mode;document.getElementById('authTitle').textContent=mode==='register'?'Crea tu cuenta':'Bienvenido de nuevo';document.getElementById('authSubtitle').textContent=mode==='register'?'Registra tu usuario para guardar tus avances.':'Ingresa con tu usuario y contraseña.';document.getElementById('accountSubmit').textContent=mode==='register'?'Crear cuenta e iniciar →':'Iniciar sesión →';accountPass.autocomplete=mode==='register'?'new-password':'current-password';toggleAuth.textContent=mode==='register'?'Ya tengo una cuenta · Iniciar sesión':'No tengo cuenta · Crear una';accountPass.value='';}
toggleAuth.addEventListener('click',()=>setAuthMode(authMode==='register'?'login':'register'));
let syncTimer=null;
window.syncProgress=()=>{if(!currentUser)return;clearTimeout(syncTimer);syncTimer=setTimeout(()=>api('progress',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({xp:state.xp,completed:state.completed,selected:state.selected})}).catch(()=>{}),700);};
async function applyUser(user){currentUser=user;state.profileName=user.username;try{const remote=await api('progress');if(remote.progress){state.xp=Number(remote.progress.xp)||0;state.completed=Array.isArray(remote.progress.completed)?remote.progress.completed:[];state.selected=Array.isArray(remote.progress.selected)?remote.progress.selected:['html','css','js','python'];}}catch{}const identity=document.getElementById('accountIdentity');if(identity)identity.textContent='@'+user.username+(user.is_owner?' · OWNER / PROGRAMADOR':'');const ownerPanel=document.getElementById('ownerBadgePanel');if(ownerPanel)ownerPanel.hidden=!user.is_owner;renderBadges(user.badges||[]);if(user.is_owner)loadOwnerBadges();const avatar=document.getElementById('profileAvatar');if(avatar){avatar.innerHTML=user.avatar_url?`<img src="${String(user.avatar_url).replace(/"/g,'')}" alt="Foto de perfil">`:'&lt;/&gt;';}const banner=document.getElementById('profileBanner');if(banner){banner.style.backgroundImage=user.banner_url?`linear-gradient(#09091444,#09091444),url("${String(user.banner_url).replace(/"/g,'')}")`:'';banner.classList.toggle('has-banner',!!user.banner_url);}updateProgress();showApp();}
accountForm.addEventListener('submit',async e=>{e.preventDefault();const btn=document.getElementById('accountSubmit');btn.disabled=true;try{const payload={username:accountUser.value.trim(),password:accountPass.value};const data=await api(authMode,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});applyUser(data.user);accountPass.value='';toast(authMode==='register'?'¡Cuenta creada!':'¡Bienvenido de nuevo!');}catch(err){authMessage.textContent=err.message;}finally{btn.disabled=false;}});
function renderBadges(badges){const box=document.getElementById('myBadges');if(!box)return;box.innerHTML='';if(!badges.length){box.textContent='Todavía no tienes insignias.';return;}badges.forEach(b=>{const el=document.createElement('span');el.className='user-badge';el.textContent=(b.icon||'🏅')+' '+b.name;el.title=b.description||'';box.append(el);});}
async function loadOwnerBadges(){const box=document.getElementById('ownerBadgeList');if(!box||!currentUser?.is_owner)return;try{const d=await api('badges');box.innerHTML='';(d.badges||[]).forEach(b=>{const el=document.createElement('div');el.className='badge-admin-row';const label=document.createElement('span');label.textContent=(b.icon||'🏅')+' '+b.name;const del=document.createElement('button');del.className='text-btn';del.textContent='Eliminar';del.onclick=async()=>{try{await jsonPost('badge_delete',{id:b.id});loadOwnerBadges();const me=await api('me');applyUser(me.user);}catch(e){toast(e.message);}};el.append(label,del);box.append(el);});if(!box.children.length)box.textContent='Aún no has creado insignias.';}catch(e){toast(e.message);}}
document.getElementById('badgeCreateForm')?.addEventListener('submit',async e=>{e.preventDefault();try{await jsonPost('badge_create',{icon:document.getElementById('badgeIcon').value.trim()||'🏅',name:document.getElementById('badgeName').value.trim(),description:document.getElementById('badgeDescription').value.trim(),public_id:document.getElementById('badgeTarget').value.trim()});e.target.reset();document.getElementById('badgeIcon').value='🏅';toast('Insignia creada y asignada.');const me=await api('me');applyUser(me.user);}catch(err){toast(err.message);}});
async function initAccount(){try{const data=await api('me');if(data.user){applyUser(data.user);return;}}catch{}showAuth('Crea una cuenta o inicia sesión para continuar.');}
logoutBtn.addEventListener('click',async()=>{if(!confirm('¿Cerrar sesión? Tu cuenta y progreso seguirán guardados.'))return;try{await api('logout',{method:'POST'});}catch{}currentUser=null;showAuth('Sesión cerrada. Puedes volver a entrar con tus datos.');logoutBtn.style.display='none';setAuthMode('login');});
document.getElementById('avatarInput')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>2*1024*1024){toast('La imagen debe pesar menos de 2 MB.');e.target.value='';return;}const form=new FormData();form.append('avatar',file);try{const data=await api('avatar',{method:'POST',body:form});applyUser(data.user);toast('Foto de perfil actualizada.');}catch(err){toast(err.message);}e.target.value='';});
document.getElementById('notificationBtn')?.addEventListener('click',async()=>{if(!('Notification' in window)){toast('Este navegador no admite notificaciones web.');return;}const permission=await Notification.requestPermission();toast(permission==='granted'?'¡Notificaciones activadas!':permission==='denied'?'Permiso denegado. Puedes cambiarlo en ajustes del navegador.':'No se activaron las notificaciones.');});
initAccount();


document.getElementById('bannerInput')?.addEventListener('change',async e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>5*1024*1024){toast('El banner debe pesar menos de 5 MB.');e.target.value='';return;}const form=new FormData();form.append('banner',file);try{const data=await api('banner',{method:'POST',body:form});applyUser(data.user);toast('Banner actualizado.');}catch(err){toast(err.message);}e.target.value='';});

// Comunidad: solicitudes, amistades y chat privado.
let chatUser=null;
document.getElementById('selfChatButton')?.addEventListener('click',()=>openChat({user_id:currentUser.id,username:'Tú',is_self:true}));
const jsonPost=(action,data)=>api(action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
async function loadCommunity(){if(!currentUser)return;try{const [rq,fr]=await Promise.all([api('friend_requests'),api('friends')]);const requests=document.getElementById('friendRequests'),friends=document.getElementById('friendList');const pending=(rq.requests||[]).length;const count=document.getElementById('requestCount');if(count)count.textContent=pending;const dot=document.getElementById('requestDot');if(dot)dot.hidden=pending===0;requests.innerHTML='';(rq.requests||[]).forEach(u=>{const el=document.createElement('div');el.className='social-list-item';const t=document.createElement('div');t.className='social-list-copy';t.innerHTML='<strong></strong><small></small>';t.querySelector('strong').textContent=u.username;t.querySelector('small').textContent=u.public_id;const yes=document.createElement('button');yes.className='primary';yes.textContent='Aceptar';yes.onclick=async()=>{await jsonPost('friend_respond',{user_id:u.user_id,accept:true});loadCommunity();};const no=document.createElement('button');no.className='text-btn';no.textContent='Rechazar';no.onclick=async()=>{await jsonPost('friend_respond',{user_id:u.user_id,accept:false});loadCommunity();};el.append(t,yes,no);requests.append(el);});if(!requests.children.length)requests.textContent='No tienes solicitudes pendientes.';friends.innerHTML='';(fr.friends||[]).forEach(u=>{const b=document.createElement('button');b.className='social-list-item';b.innerHTML='<span>👤</span><span class="social-list-copy"><strong></strong><small></small></span><span class="social-status">Chatear →</span>';b.querySelector('strong').textContent=u.username;b.querySelector('small').textContent=u.public_id;b.onclick=()=>openChat(u);friends.append(b);});if(!friends.children.length)friends.textContent='Aún no tienes amigos.';}catch(e){toast(e.message);}}
document.getElementById('findFriend')?.addEventListener('click',async()=>{const box=document.getElementById('friendSearchResult');box.textContent='Buscando...';try{const u=(await api('user_search&id='+encodeURIComponent(document.getElementById('friendId').value.trim()))).user;box.innerHTML='';const row=document.createElement('div');row.className='social-list-item';const label=document.createElement('strong');label.textContent=u.username+' · '+u.public_id;const btn=document.createElement('button');btn.className='primary';btn.textContent='Enviar solicitud';btn.onclick=async()=>{try{await jsonPost('friend_request',{user_id:u.id});btn.disabled=true;btn.textContent='Solicitud enviada';}catch(e){toast(e.message);}};row.append(label,btn);box.append(row);}catch(e){box.textContent=e.message;}});
async function openChat(u){chatUser=u;document.getElementById('chatPanel').hidden=false;document.getElementById('chatTitle').textContent=u.is_self?'Chat contigo mismo · Notas personales':'Chat con '+u.username;await loadMessages();}
async function loadMessages(){if(!chatUser)return;try{const d=await api('messages&user_id='+encodeURIComponent(chatUser.user_id));const list=document.getElementById('messageList');list.innerHTML='';(d.messages||[]).forEach(m=>{const el=document.createElement('div');el.className='chat-bubble'+(m.mine?' mine':'');if(m.text)el.textContent=m.text;if(m.file){const a=document.createElement('a');a.href=m.file;a.target='_blank';a.rel='noopener';a.textContent='📎 Abrir archivo';el.append(a);}list.append(el);});list.scrollTop=list.scrollHeight;}catch(e){toast(e.message);}}
document.getElementById('messageForm')?.addEventListener('submit',async e=>{e.preventDefault();if(!chatUser)return;const input=document.getElementById('messageText');try{await jsonPost('send_message',{user_id:chatUser.user_id,text:input.value});input.value='';await loadMessages();}catch(err){toast(err.message);}});
document.getElementById('fileForm')?.addEventListener('submit',async e=>{e.preventDefault();if(!chatUser)return;const f=document.getElementById('chatFile').files[0];if(!f)return;const data=new FormData();data.append('user_id',chatUser.user_id);data.append('file',f);try{await api('send_file',{method:'POST',body:data});document.getElementById('chatFile').value='';await loadMessages();}catch(err){toast(err.message);}});
document.getElementById('closeChat')?.addEventListener('click',()=>{chatUser=null;document.getElementById('chatPanel').hidden=true;});
const oldGo=go;go=function(page){oldGo(page);if(page==='requests'||page==='chat')loadCommunity();};
