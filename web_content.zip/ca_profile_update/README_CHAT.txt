ACTUALIZACIÓN COMUNIDAD - CODE ACADEMY

Incluye:
- ID público automático CA-XXXXXXXX en cada cuenta nueva.
- Buscar usuarios por ID y enviar solicitudes de amistad.
- Aceptar o rechazar solicitudes.
- Chat privado entre amigos.
- Adjuntos JPG, PNG, WEBP, PDF y TXT hasta 10 MB.
- Límite básico de mensajes (5 cada 10 segundos) y solicitudes (10 por hora).

INSTALACIÓN
1. Haz una copia de seguridad de tu Code Academy actual.
2. Sube y extrae todos los archivos de este ZIP sobre la carpeta actual, reemplazando index.html, app.js, api.php y style.css.
3. Conserva la carpeta storage y sus archivos users.json/progress.json. No los borres: contienen las cuentas y el progreso.
4. Asegura permisos de escritura PHP en storage/ y uploads/.
5. Comprueba que PHP tenga la extensión fileinfo habilitada.
6. Prueba con dos cuentas distintas: buscar ID, solicitud, aceptar y enviar mensajes.

NOTAS IMPORTANTES
- Esta versión sigue usando almacenamiento JSON, no MySQL.
- Las cuentas existentes conservan su ID público derivado de su identificador interno; las nuevas reciben uno aleatorio.
- Los adjuntos se sirven mediante una comprobación de sesión y amistad/participación en el chat.
- Los límites antispam son básicos; no hay antivirus ni análisis de archivos. No se aceptan ejecutables ni archivos comprimidos.
- El chat no incluye todavía bloqueo, reportes, notificaciones en tiempo real ni moderación avanzada.
- Para una comunidad grande conviene migrar a MySQL y añadir moderación y políticas de retención.
