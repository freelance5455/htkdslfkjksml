ACTUALIZACION: PERFIL Y CHAT PERSONAL

NOVEDADES
- Perfil: ahora puedes subir foto de perfil JPG, PNG o WEBP (maximo 2 MB).
- Perfil: puedes subir un banner JPG, PNG o WEBP (maximo 5 MB).
- Chat: aparece la conversacion "Hablar contigo mismo" para guardar notas y archivos personales.
- El chat contigo mismo permite texto e imagenes/PDF/TXT con el limite existente de 10 MB.
- Se mantiene el chat privado con amigos y las solicitudes.

INSTALACION
1. Haz una copia de seguridad de tu sitio y de la carpeta storage.
2. Sube y extrae este ZIP sobre los archivos actuales, reemplazando index.html, app.js, api.php, style.css y sw.js.
3. Conserva storage/ y los archivos de cuentas/progreso.
4. No elimines uploads/avatars ni uploads/chat. Se añade uploads/banners.
5. Recarga la web. Si ves la version anterior, cierra y vuelve a abrir el sitio para actualizar la cache.

NOTA
El proyecto sigue usando almacenamiento JSON. El chat personal guarda mensajes en el mismo almacenamiento privado del servidor. Las imagenes de perfil y banners se validan en el servidor por tipo MIME y contenido.
