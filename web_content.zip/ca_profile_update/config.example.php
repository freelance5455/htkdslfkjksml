<?php
// No requiere base de datos. El almacenamiento se guarda en /storage.
return ['session_name' => 'codeacademy_session'];
