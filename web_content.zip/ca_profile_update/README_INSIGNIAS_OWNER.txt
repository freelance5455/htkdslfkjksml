PROPIETARIO E INSIGNIAS

La primera cuenta que se registra en una instalación vacía se convierte en OWNER y PROGRAMADOR. El registro se protege con un bloqueo de servidor para evitar que dos altas simultáneas se proclamen propietarias. La IP de ese primer registro queda guardada como dato de auditoría en users.json; los permisos se vinculan a la cuenta propietaria, no solamente a la IP, porque las IP pueden cambiar o ser compartidas.

El panel de insignias aparece dentro de Perfil solo para OWNER. Puedes crear insignias con emoji, nombre y descripción; opcionalmente escribe el ID CA-XXXXXXXX de otro usuario para asignársela. Si dejas el ID vacío, se asigna a tu propia cuenta. También puedes eliminar insignias.

IMPORTANTE: si ya existe una cuenta en storage/users.json, no se reasigna automáticamente el rol de propietario. Para una instalación nueva, sube los archivos y registra primero tu cuenta. Haz copia de seguridad de storage/ antes de actualizar.
