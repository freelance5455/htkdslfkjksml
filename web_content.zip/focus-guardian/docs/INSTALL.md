# Установка зависимостей и создание android-проекта

## Шаг 0. Требования к среде

| Инструмент | Версия | Проверка |
|---|---|---|
| Node.js | 20+ (LTS) | `node -v` |
| JDK | 21 (обязателен для Capacitor 8) | `java -version` |
| Android SDK | Platform 35 (или новее) + Build-Tools + Platform Tools | через Android Studio |
| Android Studio | Hedgehog или новее (для SDK и эмулятора) | — |

Проще всего: поставьте Android Studio — он установит SDK и предложит JDK 21.
Путь к SDK обычно `C:\Users\<имя>\AppData\Local\Android\Sdk` (Windows) или `~/Android/Sdk` (Linux/macOS).

## Шаг 1. Установить зависимости проекта

```bash
cd focus-guardian
npm install
```

Установятся `@capacitor/core`, `@capacitor/android` и `@capacitor/cli`.

## Шаг 2. Создать android-платформу

```bash
npx cap add android
```

Команда создаст папку `android/` с нативным gradle-проектом (это нельзя сделать вручную надёжно — CLI генерирует актуальные версии gradle-обёртки, плагинов и ресурсов).

## Шаг 3. Скопировать нативные модули Focus Guardian

Файлы из `android-native/` нужно перенести в созданный проект:

```bash
# из корня проекта (Linux/macOS)
cp android-native/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
cp -r android-native/java/com/focusguardian/app/. android/app/src/main/java/com/focusguardian/app/
cp android-native/res/xml/accessibility_service_config.xml android/app/src/main/res/xml/
cp android-native/res/values/strings.xml android/app/src/main/res/values/strings.xml
```

Windows (PowerShell):

```powershell
Copy-Item android-native/AndroidManifest.xml android/app/src/main/AndroidManifest.xml -Force
Copy-Item android-native/java/com/focusguardian/app/* android/app/src/main/java/com/focusguardian/app/ -Force
Copy-Item android-native/res/xml/accessibility_service_config.xml android/app/src/main/res/xml/ -Force
Copy-Item android-native/res/values/strings.xml android/app/src/main/res/values/strings.xml -Force
```

Что произойдёт:
- `AndroidManifest.xml` заменится на манифест со всеми нужными разрешениями
  (см. [PERMISSIONS.md](PERMISSIONS.md));
- в `res/values/strings.xml` обновится имя приложения и добавятся строки
  для сервиса специальных возможностей;
- в проект добавятся 11 Kotlin-файлов (плагин, сервисы, блокировщик, ресиверы).

Файл `MainActivity.kt` из `android-native/` заменит шаблонный — он регистрирует
нативный плагин `FocusGuardianNative`.

## Шаг 4. Синхронизировать веб-слой

```bash
npx cap sync android
```

Команда скопирует `www/` внутрь android-проекта и обновит зависимости.

## Шаг 5. Открыть проект в Android Studio

```bash
npx cap open android
```

Первое открытие скачает gradle-зависимости (нужен интернет). Если Studio спросит
про Gradle JDK — выберите **Embedded JDK (21)**.

## Частые проблемы

| Проблема | Решение |
|---|---|
| `Unsupported class file major version` | Запускаете сборку на JDK ниже 21. Укажите JDK 21 в `File → Settings → Build Tools → Gradle` |
| `SDK location not found` | Создайте `android/local.properties` со строкой `sdk.dir=/путь/к/Android/Sdk` |
| Kapt/Kotlin ошибки про `getLong("fromTs")` | Убедитесь, что скопированы все файлы из `android-native/java/...` — они зависят друг от друга |
| Медленное первое открытие | Gradle качает зависимости — подождите, это нормально |
