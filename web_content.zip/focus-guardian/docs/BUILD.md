# Сборка APK

## Отладочный APK (быстрый способ поставить себе)

```bash
cd focus-guardian
npx cap sync android
cd android
./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
```

Готовый файл: `android/app/build/outputs/apk/debug/app-debug.apk`

Установка:

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

…или просто скопируйте APK на телефон и откройте его. Android спросит разрешение
«Установка приложений из неизвестных источников» для вашего файлового менеджера —
разрешите и продолжите установку.

## Релизный APK (для длительного использования и без отладочного флага)

### 1. Создать ключ подписи (один раз)

```bash
keytool -genkey -v -keystore focus-guardian.keystore -alias focusguardian \
  -keyalg RSA -keysize 2048 -validity 10000
```

Ответьте на вопросы (пароль храните надёжно, ключ терять нельзя — без него не
получится обновить приложение).

### 2. Указать подпись в проекте

Создайте/дополните `android/key.properties`:

```properties
storeFile=../../focus-guardian.keystore
storePassword=ВАШ_ПАРОЛЬ
keyAlias=focusguardian
keyPassword=ВАШ_ПАРОЛЬ
```

И добавьте в `android/app/build.gradle` внутрь `android { ... }`:

```groovy
def keyProps = new Properties()
def keyFile = rootProject.file("key.properties")
if (keyFile.exists()) keyProps.load(new FileInputStream(keyFile))

signingConfigs {
    release {
        storeFile keyProps['storeFile'] ? file(keyProps['storeFile']) : null
        storePassword keyProps['storePassword']
        keyAlias keyProps['keyAlias']
        keyPassword keyProps['keyPassword']
    }
}

buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled false
    }
}
```

### 3. Собрать релизный APK

```bash
cd android
./gradlew assembleRelease
```

Готовый файл: `android/app/build/outputs/apk/release/app-release.apk`

> Примечание: `key.properties` и `*.keystore` не публикуйте — добавьте их в `.gitignore`.

## Полезное

- **Переименование версии** — правьте `versionName` в `android/app/build.gradle`.
- **Иконка приложения** — `res/mipmap-*` генерируются шаблоном. Свою иконку удобно
  сделать в Android Studio: правый клик на `res` → New → Image Asset.
- **Сборка AAB для Google Play** — `./gradlew bundleRelease`.
- **Пересборка после изменения веб-части** — всегда сначала `npx cap sync android`.
