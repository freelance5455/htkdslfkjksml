/* Focus Guardian — страница «Разрешения Android» и диагностика */

import { initShell, skeleton } from '../core/shell.js';
import { Native } from '../core/native.js';
import { icon } from '../core/icons.js';
import { toast, badge } from '../core/ui.js';
import { esc, fmtClock } from '../core/util.js';
import { Store } from '../core/storage.js';

const page = document.getElementById('page');
let pollTimer = null;

const PERMS = [
  {
    id: 'usageAccess',
    name: 'Доступ к данным об использовании',
    icon: 'chart',
    why: 'Без него приложение не может узнать экранное время, время в каждом приложении и число запусков. Это основа всей статистики.',
    how: 'Настройки → Приложения → Специальный доступ → Доступ к данным об использовании → Focus Guardian.',
    open: () => Native.openUsageAccess(),
  },
  {
    id: 'accessibility',
    name: 'Специальные возможности',
    icon: 'shield',
    why: 'Нужны для блокировки приложений: сервис видит, какое приложение открыто, и показывает экран блокировки при превышении лимита. Содержимое экрана не читается.',
    how: 'Настройки → Специальные возможности → Focus Guardian → включить.',
    open: () => Native.openAccessibility(),
  },
  {
    id: 'overlay',
    name: 'Поверх других окон',
    icon: 'lock',
    why: 'Экран «Время вышло!» показывается поверх заблокированного приложения как системное окно.',
    how: 'Настройки → Приложения → Focus Guardian → «Поверх других окон».',
    open: () => Native.openOverlay(),
  },
  {
    id: 'batteryIgnored',
    name: 'Отключение оптимизации батареи',
    icon: 'battery',
    why: 'Без этого Android может «усыплять» фоновый сервис, и напоминания придут с опозданием или не придут вовсе.',
    how: 'В диалоге разрешите «Не оптимизировать» для Focus Guardian.',
    open: () => Native.openBattery(),
  },
  {
    id: 'notifications',
    name: 'Уведомления',
    icon: 'bell',
    why: 'Напоминания об отдыхе глаз, итоги дня и предупреждения приходят как системные уведомления.',
    how: 'Разрешите уведомления при первом запросе. Если отклонили — включите в настройках приложения.',
    open: async () => {
      const r = await Native.requestNotifications();
      if (!r.ok || !r.granted) await Native.openNotificationSettings();
    },
  },
  {
    id: 'dnd',
    name: 'Доступ к «Не беспокоить» (необязательно)',
    icon: 'moon',
    why: 'Позволяет режиму фокуса включать режим «Не беспокоить» на время сеанса концентрации.',
    how: 'Настройки → Звук → Не беспокоить → Доступ приложений → Focus Guardian.',
    open: () => Native.openDnd(),
  },
];

function statusBadge(v) {
  return v ? badge('Разрешено', 'ok') : badge('Не выдано', 'warn');
}

async function render() {
  const isNative = Native.isNative() || Native.demoActive();
  const perms = isNative ? await Native.permissions() : { ok: false };

  page.innerHTML = `
    <div class="banner info">
      ${icon('info')}
      <div class="grow"><b>Зачем столько разрешений?</b><br>Focus Guardian работает локально и честно: ни одно разрешение не отправляет данные в сеть. Каждое разрешение отвечает за конкретную функцию — описание ниже.</div>
    </div>

    ${!isNative ? `
    <div class="banner warn">
      ${icon('alert')}
      <div class="grow"><b>Вы в браузере</b><br>Системные разрешения выдаются только в установленном APK. Соберите приложение по docs/BUILD.md и повторите здесь.</div>
    </div>` : ''}

    <div id="permCards">
      ${PERMS.map((p) => `
      <div class="card perm-card" data-id="${p.id}">
        <div class="spread">
          <div class="row" style="align-items:flex-start">
            <div class="icon-tile">${icon(p.icon)}</div>
            <div class="grow">
              <div style="font-weight:700;font-size:14.5px">${esc(p.name)}</div>
              <div class="perm-list">
                <li>${icon('check')}<span>${esc(p.why)}</span></li>
                <li>${icon('info')}<span class="muted">${esc(p.how)}</span></li>
              </div>
            </div>
          </div>
        </div>
        <div class="row spread" style="margin-top:10px">
          <span class="p-status" data-status="${p.id}"></span>
          <button class="btn ghost small" data-open="${p.id}">${icon('settings')}<span>Открыть настройки</span></button>
        </div>
      </div>`).join('')}
    </div>

    <button class="btn block" id="checkAll" style="margin:6px 0 16px">${icon('refresh')}<span>Проверить всё</span></button>

    <div class="card">
      <div class="card-title">${icon('activity')} Диагностика фоновых служб</div>
      <div id="diagBox"></div>
      <button class="btn ghost block small" id="refreshDiag">${icon('refresh')}<span>Обновить</span></button>
    </div>
  `;

  updateStatuses(perms);

  page.querySelectorAll('[data-open]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const p = PERMS.find((x) => x.id === btn.dataset.open);
      if (!p) return;
      const r = await p.open();
      if (!r?.ok) {
        toast('Откройте настройки Android вручную — путь указан в карточке', 'warn', 5000);
        return;
      }
      // перепроверка после возвращения из настроек
      setTimeout(refreshStatuses, 1200);
    });
  });

  page.querySelector('#checkAll').addEventListener('click', refreshStatuses);
  page.querySelector('#refreshDiag').addEventListener('click', renderDiagnostics);
  renderDiagnostics();

  // автопроверка при возврате на страницу
  document.addEventListener('visibilitychange', onVis);
}

function onVis() {
  if (document.visibilityState === 'visible') refreshStatuses();
  else clearInterval(pollTimer);
}

async function refreshStatuses() {
  const perms = await Native.permissions();
  updateStatuses(perms);
  renderDiagnostics();
  if (perms.ok) {
    const missing = PERMS.filter((p) => !perms[p.id]);
    if (!missing.length) toast('Все ключевые разрешения выданы!', 'ok');
  }
}

function updateStatuses(perms) {
  for (const p of PERMS) {
    const el = page.querySelector(`[data-status="${p.id}"]`);
    if (!el) continue;
    el.innerHTML = '';
    if (!perms.ok) el.appendChild(badge('Проверка недоступна', ''));
    else el.appendChild(statusBadge(perms[p.id]));
  }
}

async function renderDiagnostics() {
  const box = page.querySelector('#diagBox');
  if (!box) return;
  if (!Native.isNative() && !Native.demoActive()) {
    box.innerHTML = '<div class="tiny muted">Доступно в APK-сборке.</div>';
    return;
  }
  const d = await Native.diagnostics();
  if (!d.ok) {
    box.innerHTML = '<div class="tiny muted">Сервис пока не отвечал.</div>';
    return;
  }
  box.innerHTML = `
    <div class="stat-line"><span class="s-label">Фоновый сервис мониторинга</span><span class="s-value">${d.running ? 'работает' : 'не запущен'}</span></div>
    <div class="stat-line"><span class="s-label">Последний тик сервиса</span><span class="s-value num">${d.lastTickTs ? fmtClock(d.lastTickTs) : '—'}</span></div>
    <div class="stat-line"><span class="s-label">Синхронизация статистики</span><span class="s-value num">${d.lastStatsSyncTs ? fmtClock(d.lastStatsSyncTs) : '—'}</span></div>
    <div class="stat-line"><span class="s-label">Служба блокировки (Accessibility)</span><span class="s-value">${d.accessibilityConnected ? 'подключена' : 'отключена'}</span></div>
    <div class="stat-line"><span class="s-label">Срабатываний блокировки сегодня</span><span class="s-value num">${d.blocksToday || 0}</span></div>
  `;
}

initShell({ title: 'Разрешения Android', tab: 'permissions' });
skeleton(page, 3);
render().catch((e) => {
  console.warn('[permissions]', e);
  page.innerHTML = `<div class="empty">${icon('alert')}<h3>Ошибка загрузки</h3><p>${esc(String(e.message || e))}</p></div>`;
});
