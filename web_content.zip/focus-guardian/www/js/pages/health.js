/* Focus Guardian — страница «Здоровье глаз»: правило 20-20-20 и перерывы */

import { initShell, skeleton } from '../core/shell.js';
import { Store, dayKey } from '../core/storage.js';
import { Native } from '../core/native.js';
import { icon } from '../core/icons.js';
import { toast, switchEl, seg, emptyState } from '../core/ui.js';
import { fmtClock, esc, fmtDurSec } from '../core/util.js';
import { showEyeRest } from '../core/eyerest.js';
import { getLive, plannedBreaks, appOpenMin } from '../core/engine.js';

const page = document.getElementById('page');

const INTERVALS = [15, 20, 30, 40];
const DURATIONS = [20, 30, 60];

async function render() {
  const s = Store.settings();
  const live = await getLive();
  const today = Store.day(dayKey());
  const activeMin = live.available && live.screenOn ? Math.max(0, (Date.now() - (live.sessionStartTs || Date.now())) / 60000) : appOpenMin();
  const planned = plannedBreaks(activeMin, s.eye.intervalMin);

  const breaksToday = (Store.get('history.breaks', []) || []).filter((b) => new Date(b.ts).toDateString() === new Date().toDateString()).slice(-8).reverse();

  page.innerHTML = `
    <div class="card glow">
      <div class="card-title">${icon('eye')} Правило 20-20-20</div>
      <div class="card-sub">Каждые 20 минут работы за экраном: посмотри на объект примерно в 6 метрах и удерживай взгляд 20 секунд. Это снимает напряжение глазных мышц и помогает не пересыхать глазам.</div>
      <div class="setting-row" style="margin-top:12px">
        <div class="s-text"><div class="s-title">Напоминания об отдыхе глаз</div><div class="s-desc">Работают и когда приложение закрыто — через фоновый сервис</div></div>
        <span id="eyeEnabled"></span>
      </div>
      <div class="field" style="margin-top:10px">
        <label>Интервал напоминаний</label>
        <div class="chips" id="intervalChips">
          ${INTERVALS.map((m) => `<button class="chip ${s.eye.intervalMin === m ? 'active' : ''}" data-v="${m}">${m} мин</button>`).join('')}
          <button class="chip ${!INTERVALS.includes(s.eye.intervalMin) ? 'active' : ''}" data-v="custom">Свой интервал</button>
        </div>
        <div class="row hidden" id="intervalCustom" style="margin-top:10px">
          <input type="number" class="input" id="intervalVal" min="5" max="120" placeholder="Минуты (5–120)" style="flex:1">
          <button class="btn small" id="intervalApply"><span>Ок</span></button>
        </div>
      </div>
      <div class="field">
        <label>Длительность перерыва</label>
        <div class="chips" id="durChips">
          ${DURATIONS.map((d) => `<button class="chip ${s.eye.durationSec === d ? 'active' : ''}" data-v="${d}">${d} сек</button>`).join('')}
        </div>
      </div>
      <div class="setting-row">
        <div class="s-text"><div class="s-title">Автоматически открывать экран отдыха</div><div class="s-desc">Полноэкранный таймер запустится сам, когда приложение открыто</div></div>
        <span id="autoFs"></span>
      </div>
      <button class="btn block" id="restNow" style="margin-top:14px">${icon('eye')}<span>Отдохнуть сейчас (${s.eye.durationSec} сек)</span></button>
    </div>

    <div class="card">
      <div class="card-title">${icon('check')} Перерывы сегодня</div>
      <div class="kpi-grid" style="margin-bottom:6px">
        <div class="kpi"><div class="k-label">${icon('check')} Сделано</div><div class="k-value num">${today.breaks || 0}</div><div class="k-sub">перерывов</div></div>
        <div class="kpi"><div class="k-label">${icon('target')} Запланировано</div><div class="k-value num">${planned}</div><div class="k-sub">по интервалу ${s.eye.intervalMin} мин</div></div>
      </div>
      ${(today.breaks || 0) >= planned && planned > 0
        ? '<div class="banner ok" style="margin-bottom:0">Отлично! Все запланированные перерывы выполнены.</div>'
        : ''}
    </div>

    <div class="card">
      <div class="card-title">${icon('clock')} Последние перерывы</div>
      <div id="breaksList"></div>
    </div>

    <div class="banner info">
      ${icon('info')}
      <div class="grow"><b>Как это работает в фоне?</b><br>После сборки APK фоновый сервис сам следит за непрерывным временем использования и присылает уведомления каждые ${s.eye.intervalMin} минут — даже когда Focus Guardian закрыт.</div>
    </div>
  `;

  page.querySelector('#eyeEnabled').appendChild(switchEl(s.eye.enabled, (v) => {
    Store.updateSettings({ eye: { ...Store.settings().eye, enabled: v } });
  }));
  page.querySelector('#autoFs').appendChild(switchEl(s.eye.autoFullscreen, (v) => {
    Store.updateSettings({ eye: { ...Store.settings().eye, autoFullscreen: v } });
  }));

  page.querySelector('#intervalChips').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    page.querySelectorAll('#intervalChips .chip').forEach((c) => c.classList.toggle('active', c === chip));
    if (chip.dataset.v === 'custom') {
      page.querySelector('#intervalCustom').classList.remove('hidden');
    } else {
      page.querySelector('#intervalCustom').classList.add('hidden');
      Store.updateSettings({ eye: { ...Store.settings().eye, intervalMin: Number(chip.dataset.v) } });
      toast(`Интервал: ${chip.dataset.v} минут`, 'ok');
    }
  });
  page.querySelector('#intervalApply').addEventListener('click', () => {
    const v = Number(page.querySelector('#intervalVal').value);
    if (!v || v < 5 || v > 120) return toast('Укажите интервал от 5 до 120 минут', 'warn');
    Store.updateSettings({ eye: { ...Store.settings().eye, intervalMin: Math.round(v) } });
    toast(`Интервал: ${v} минут`, 'ok');
  });
  page.querySelector('#durChips').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    page.querySelectorAll('#durChips .chip').forEach((c) => c.classList.toggle('active', c === chip));
    Store.updateSettings({ eye: { ...Store.settings().eye, durationSec: Number(chip.dataset.v) } });
  });

  page.querySelector('#restNow').addEventListener('click', () => {
    showEyeRest({ seconds: Store.settings().eye.durationSec });
  });

  const bl = page.querySelector('#breaksList');
  if (breaksToday.length) {
    bl.innerHTML = breaksToday.map((b) => `
      <div class="list-item" style="cursor:default">
        <div class="icon-tile ${b.type === 'eye' ? 'ok' : ''}">${icon(b.type === 'eye' ? 'eye' : 'coffee')}</div>
        <div class="grow">
          <div style="font-weight:600;font-size:13.5px">${fmtClock(b.ts)}</div>
          <div class="tiny muted">${b.type === 'eye' ? 'Отдых для глаз' : 'Автоматический перерыв'} · ${fmtDurSec(b.sec)}</div>
        </div>
      </div>`).join('');
  } else {
    bl.innerHTML = '';
    bl.appendChild(emptyState({ iconName: 'eye', title: 'Перерывов пока нет', text: 'Коснитесь «Отдохнуть сейчас», когда почувствуете усталость глаз.' }));
  }
}

initShell({ title: 'Здоровье глаз', tab: 'health' });
skeleton(page, 2);
render().catch((e) => {
  console.warn('[health]', e);
  page.innerHTML = `<div class="empty">${icon('alert')}<h3>Ошибка загрузки</h3><p>${esc(String(e.message || e))}</p></div>`;
});
