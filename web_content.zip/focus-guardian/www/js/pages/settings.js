/* Focus Guardian — страница «Настройки» */

import { initShell, skeleton } from '../core/shell.js';
import { Store } from '../core/storage.js';
import { Native, syncConfigToNative } from '../core/native.js';
import { icon } from '../core/icons.js';
import { toast, switchEl, seg, confirmDialog, holdButton, modal, sheet, emptyState } from '../core/ui.js';
import { esc, downloadBlob, fmtClock } from '../core/util.js';

const page = document.getElementById('page');

const MODES = [
  { id: 'soft', name: 'Мягкий', desc: 'Только уведомления и мягкие напоминания. Никаких блокировок.' },
  { id: 'standard', name: 'Стандартный', desc: 'Уведомления, дневные лимиты и возможность блокировки выбранных приложений.' },
  { id: 'strict', name: 'Строгий', desc: 'Автоблокировка по лимитам, снятие правил только с удержанием, двойное подтверждение.' },
  { id: 'max', name: 'Максимальная концентрация', desc: 'Временная блокировка в сеансах фокуса, без отвлекающих уведомлений, таймер концентрации.' },
];

function applyMode(mode) {
  const s = Store.settings();
  Store.updateSettings({ mode });
  // режим влияет на поведение блокировок: в мягком режиме нативный сервис не блокирует
  syncConfigToNative();
  import('../core/sessions.js').then(({ refreshNativeRules }) => refreshNativeRules());
}

function row({ iconName, title, desc = '', control = '' }) {
  return `
    <div class="setting-row">
      <div class="icon-tile">${icon(iconName)}</div>
      <div class="s-text"><div class="s-title">${esc(title)}</div>${desc ? `<div class="s-desc">${desc}</div>` : ''}</div>
      ${control}
    </div>`;
}

async function render() {
  const s = Store.settings();

  page.innerHTML = `
    <div class="card">
      <div class="card-title">${icon('sun')} Внешний вид</div>
      <div class="field"><label>Тема</label><div id="themeSeg"></div></div>
      <div class="field"><label>Акцентный цвет</label>
        <div class="swatches">
          <div class="swatch violet ${s.accent === 'violet' ? 'active' : ''}" data-v="violet"></div>
          <div class="swatch cyan ${s.accent === 'cyan' ? 'active' : ''}" data-v="cyan"></div>
          <div class="swatch blue ${s.accent === 'blue' ? 'active' : ''}" data-v="blue"></div>
        </div>
      </div>
      ${row({ iconName: 'heart', title: 'Ваше имя', desc: 'Появляется в приветствии', control: '<input type="text" class="input" id="nameInput" style="max-width:140px" placeholder="Имя">' })}
    </div>

    <div class="card">
      <div class="card-title">${icon('shield')} Мониторинг</div>
      ${row({ iconName: 'activity', title: 'Мониторинг экранного времени', desc: 'Сбор статистики и фоновые напоминания', control: '<span id="swMonitoring"></span>' })}
      ${row({ iconName: 'clock', title: 'Дневной лимит экрана', desc: 'Общее время экрана в день', control: '<input type="number" class="input" id="limitInput" min="30" max="720" style="max-width:110px">' })}
      ${row({ iconName: 'moon', title: 'Время сна', control: '<div class="row"><input type="time" class="input" id="sleepStart" style="max-width:100px"><input type="time" class="input" id="sleepEnd" style="max-width:100px"></div>' })}
      ${row({ iconName: 'alert', title: 'Ночные предупреждения', desc: '«Пора спать», если экран активен во время сна', control: '<span id="swNight"></span>' })}
    </div>

    <div class="card">
      <div class="card-title">${icon('shield')} Режим дисциплины</div>
      <div id="modeList"></div>
      <div class="card-sub">Режимы влияют на блокировки и строгость напоминаний. Изменение строгого режима требует удержания кнопки.</div>
    </div>

    <div class="card">
      <div class="card-title">${icon('bell')} Уведомления</div>
      ${row({ iconName: 'bell', title: 'Уведомления включены', control: '<span id="swNotify"></span>' })}
      <div class="field" style="padding:6px 2px"><label>Строгость напоминаний</label><div id="strictSeg"></div></div>
      ${row({ iconName: 'timer', title: '20 минут непрерывного использования', control: '<span id="swN20"></span>' })}
      ${row({ iconName: 'timer', title: '40 минут', control: '<span id="swN40"></span>' })}
      ${row({ iconName: 'timer', title: '60 минут', control: '<span id="swN60"></span>' })}
      ${row({ iconName: 'shield', title: 'Достижение лимита приложения', control: '<span id="swNLimit"></span>' })}
      ${row({ iconName: 'calendar', title: 'Итоги дня', desc: 'Вечером — сводка экранного времени', control: '<span id="swNEod"></span>' })}
      ${row({ iconName: 'coffee', title: 'Похвала за отдых', desc: 'После долгой паузы без телефона', control: '<span id="swNRest"></span>' })}
      ${row({ iconName: 'zap', title: 'Вибрация', control: '<span id="swVibro"></span>' })}
      <div class="field" style="padding:6px 2px"><label>Звук уведомлений</label><div id="soundSeg"></div></div>
      <button class="btn ghost block small" id="testNotif">${icon('bell')}<span>Проверить уведомление</span></button>
    </div>

    <div class="card">
      <div class="card-title">${icon('eye')} Здоровье глаз</div>
      ${row({ iconName: 'eye', title: 'Напоминания об отдыхе глаз', control: '<span id="swEye"></span>' })}
      <div class="field" style="padding:6px 2px"><label>Интервал</label>
        <div class="chips" id="eyeInterval">
          ${[15, 20, 30, 40].map((m) => `<button class="chip ${s.eye.intervalMin === m ? 'active' : ''}" data-v="${m}">${m} мин</button>`).join('')}
        </div>
      </div>
      <div class="field" style="padding:6px 2px"><label>Длительность перерыва</label>
        <div class="chips" id="eyeDur">
          ${[20, 30, 60].map((d) => `<button class="chip ${s.eye.durationSec === d ? 'active' : ''}" data-v="${d}">${d} сек</button>`).join('')}
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">${icon('moon')} Дополнительно</div>
      ${row({ iconName: 'walk', title: 'Напоминания размяться', desc: 'После долгого непрерывного сеанса', control: '<span id="swWalk"></span>' })}
      ${row({ iconName: 'coffee', title: 'Предлагать отдых после долгого экрана', control: '<span id="swAutoRest"></span>' })}
      ${row({ iconName: 'sparkles', title: 'Умный помощник', desc: 'Рекомендации на главной на основе статистики', control: '<span id="swAssistant"></span>' })}
    </div>

    <div class="card">
      <div class="card-title">${icon('download')} Данные</div>
      <div class="row-wrap">
        <button class="btn ghost" id="expData">${icon('download')}<span>Экспорт и резервная копия</span></button>
        <button class="btn ghost" id="impData">${icon('upload')}<span>Восстановить из копии</span></button>
      </div>
      <input type="file" id="impFile" accept=".json,application/json" class="hidden">
      <div style="margin-top:12px" class="row-wrap">
        <button class="btn danger" id="resetStats">${icon('trash')}<span>Сбросить статистику</span></button>
        <button class="btn danger" id="resetAll">${icon('trash')}<span>Полный сброс</span></button>
      </div>
    </div>

    <div class="card">
      <div class="card-title">${icon('shield')} Разрешения и диагностика</div>
      <button class="btn ghost block small" id="goPerms" style="margin-bottom:10px">${icon('shield')}<span>Открыть страницу разрешений Android</span></button>
      <div id="diagBox"></div>
      <label class="setting-row">
        <div class="s-text"><div class="s-title">Демо-данные для тестирования</div><div class="s-desc">Подстановка примеров статистики. В APK выключите, чтобы видеть реальные данные.</div></div>
        <span id="swDemo"></span>
      </label>
    </div>

    <div class="card">
      <div class="card-title">${icon('info')} О приложении</div>
      <div class="stat-line"><span class="s-label">Название</span><span class="s-value">Focus Guardian</span></div>
      <div class="stat-line"><span class="s-label">Версия</span><span class="s-value">1.0.0</span></div>
      <div class="stat-line"><span class="s-label">Платформа</span><span class="s-value">${Native.isNative() ? 'Android (Capacitor)' : 'Браузер / предпросмотр'}</span></div>
      <div class="stat-line"><span class="s-label">Данные хранятся</span><span class="s-value">локально на устройстве</span></div>
    </div>
  `;

  bindControls(s);
  renderDiagnostics();
}

function bindControls(s) {
  /* внешний вид */
  seg(page.querySelector('#themeSeg'), [
    { value: 'dark', label: 'Тёмная' },
    { value: 'light', label: 'Светлая' },
    { value: 'auto', label: 'Авто' },
  ], s.theme, (v) => {
    Store.updateSettings({ theme: v });
    import('../core/shell.js').then(({ applyTheme }) => applyTheme());
  });
  page.querySelectorAll('.swatch').forEach((sw) => sw.addEventListener('click', () => {
    Store.updateSettings({ accent: sw.dataset.v });
    page.querySelectorAll('.swatch').forEach((x) => x.classList.toggle('active', x === sw));
    import('../core/shell.js').then(({ applyTheme }) => applyTheme());
  }));

  const nameInput = page.querySelector('#nameInput');
  nameInput.value = s.profile.name || '';
  nameInput.addEventListener('change', () => {
    Store.updateSettings({ profile: { name: nameInput.value.trim() } });
    toast('Имя сохранено', 'ok');
  });

  /* мониторинг */
  page.querySelector('#swMonitoring').appendChild(switchEl(s.monitoring, (v) => {
    Store.updateSettings({ monitoring: v });
    syncConfigToNative();
    toast(v ? 'Мониторинг включён' : 'Мониторинг выключен', v ? 'ok' : 'warn');
  }));

  const limitInput = page.querySelector('#limitInput');
  limitInput.value = s.dailyLimitMin;
  limitInput.addEventListener('change', () => {
    const v = Number(limitInput.value);
    if (!v || v < 30 || v > 720) return toast('Лимит от 30 до 720 минут', 'warn');
    Store.updateSettings({ dailyLimitMin: Math.round(v) });
    syncConfigToNative();
    toast(`Лимит дня: ${Math.round(v)} мин`, 'ok');
  });

  const sleepStart = page.querySelector('#sleepStart');
  const sleepEnd = page.querySelector('#sleepEnd');
  sleepStart.value = s.sleep.start;
  sleepEnd.value = s.sleep.end;
  const saveSleep = () => {
    Store.updateSettings({ sleep: { ...Store.settings().sleep, start: sleepStart.value, end: sleepEnd.value } });
    syncConfigToNative();
  };
  sleepStart.addEventListener('change', saveSleep);
  sleepEnd.addEventListener('change', saveSleep);

  page.querySelector('#swNight').appendChild(switchEl(s.sleep.warnings, (v) => {
    Store.updateSettings({ sleep: { ...Store.settings().sleep, warnings: v } });
    syncConfigToNative();
  }));

  /* режимы */
  const modeList = page.querySelector('#modeList');
  modeList.innerHTML = MODES.map((m) => `
    <div class="setting-row" data-mode="${m.id}">
      <div class="icon-tile ${Store.settings().mode === m.id ? 'ok' : ''}">${icon(m.id === 'soft' ? 'leaf' : m.id === 'standard' ? 'shield' : m.id === 'strict' ? 'lock' : 'target')}</div>
      <div class="s-text"><div class="s-title">${m.name}</div><div class="s-desc">${m.desc}</div></div>
    </div>`).join('');
  modeList.querySelectorAll('.setting-row').forEach((r) => {
    r.addEventListener('click', async () => {
      const id = r.dataset.mode;
      if (Store.settings().mode === id) return;
      const mode = MODES.find((m) => m.id === id);
      const needHold = Store.settings().mode === 'strict' || id === 'strict';
      const ok = await confirmDialog({
        title: `Режим «${mode.name}»`,
        text: mode.desc,
        okLabel: 'Включить',
        hold: needHold,
      });
      if (!ok) return;
      applyMode(id);
      render();
      toast(`Режим «${mode.name}» включён`, 'ok');
    });
  });

  /* уведомления */
  const n = s.notify;
  page.querySelector('#swNotify').appendChild(switchEl(n.enabled, (v) => { Store.updateSettings({ notify: { ...n, enabled: v } }); syncConfigToNative(); }));
  seg(page.querySelector('#strictSeg'), [
    { value: 'soft', label: 'Мягкая' },
    { value: 'normal', label: 'Обычная' },
    { value: 'strict', label: 'Строгая' },
  ], n.strictness, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, strictness: v } }); syncConfigToNative(); });
  page.querySelector('#swN20').appendChild(switchEl(n.session20, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, session20: v } }); syncConfigToNative(); }));
  page.querySelector('#swN40').appendChild(switchEl(n.session40, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, session40: v } }); syncConfigToNative(); }));
  page.querySelector('#swN60').appendChild(switchEl(n.session60, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, session60: v } }); syncConfigToNative(); }));
  page.querySelector('#swNLimit').appendChild(switchEl(n.limitReached, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, limitReached: v } }); syncConfigToNative(); }));
  page.querySelector('#swNEod').appendChild(switchEl(n.endOfDay, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, endOfDay: v } }); syncConfigToNative(); }));
  page.querySelector('#swNRest').appendChild(switchEl(n.restCelebration, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, restCelebration: v } }); syncConfigToNative(); }));
  page.querySelector('#swVibro').appendChild(switchEl(n.vibration, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, vibration: v } }); syncConfigToNative(); }));
  seg(page.querySelector('#soundSeg'), [
    { value: 'default', label: 'Обычный' },
    { value: 'gentle', label: 'Тихий' },
    { value: 'none', label: 'Без звука' },
  ], n.sound, (v) => { Store.updateSettings({ notify: { ...Store.settings().notify, sound: v } }); syncConfigToNative(); });

  page.querySelector('#testNotif').addEventListener('click', async () => {
    const r = await Native.testNotification();
    if (r.ok) toast('Тестовое уведомление отправлено', 'ok');
    else toast('Уведомления доступны в APK-сборке', 'warn');
  });

  /* глаза */
  page.querySelector('#swEye').appendChild(switchEl(s.eye.enabled, (v) => { Store.updateSettings({ eye: { ...Store.settings().eye, enabled: v } }); syncConfigToNative(); }));
  page.querySelector('#eyeInterval').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    page.querySelectorAll('#eyeInterval .chip').forEach((c) => c.classList.toggle('active', c === chip));
    Store.updateSettings({ eye: { ...Store.settings().eye, intervalMin: Number(chip.dataset.v) } });
    syncConfigToNative();
  });
  page.querySelector('#eyeDur').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    page.querySelectorAll('#eyeDur .chip').forEach((c) => c.classList.toggle('active', c === chip));
    Store.updateSettings({ eye: { ...Store.settings().eye, durationSec: Number(chip.dataset.v) } });
  });

  /* дополнительно */
  page.querySelector('#swWalk').appendChild(switchEl(s.walk.enabled, (v) => { Store.updateSettings({ walk: { ...Store.settings().walk, enabled: v } }); syncConfigToNative(); }));
  page.querySelector('#swAutoRest').appendChild(switchEl(s.rest.autoSuggest, (v) => { Store.updateSettings({ rest: { ...Store.settings().rest, autoSuggest: v } }); syncConfigToNative(); }));
  page.querySelector('#swAssistant').appendChild(switchEl(s.motivation.dailyQuote, (v) => { Store.updateSettings({ motivation: { ...Store.settings().motivation, dailyQuote: v } }); }));
  page.querySelector('#swDemo').appendChild(switchEl(s.demo, async (v) => {
    Store.updateSettings({ demo: v });
    toast(v ? 'Демо-режим включён — данные будут примерами' : 'Демо-режим выключен', v ? 'warn' : 'ok');
  }));

  /* данные */
  page.querySelector('#expData').addEventListener('click', async () => {
    const json = Store.exportAll();
    const name = `focus-guardian-backup-${new Date().toISOString().slice(0, 10)}.json`;
    const r = await Native.exportFile(name, 'application/json', json);
    if (!r.ok) downloadBlob(name, 'application/json', json);
    else toast(`Резервная копия сохранена: ${r.path || name}`, 'ok', 4500);
  });
  const impFile = page.querySelector('#impFile');
  page.querySelector('#impData').addEventListener('click', () => impFile.click());
  impFile.addEventListener('change', async () => {
    const file = impFile.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      await confirmDialog({ title: 'Восстановить из копии?', text: 'Текущие настройки и статистика будут заменены данными из файла.', okLabel: 'Восстановить' });
      Store.importAll(text);
      toast('Данные восстановлены', 'ok');
      syncConfigToNative();
      setTimeout(() => location.reload(), 800);
    } catch (e) {
      toast(`Не удалось восстановить: ${e.message}`, 'error', 4500);
    }
  });

  const resetStatsBtn = page.querySelector('#resetStats');
  holdButton(resetStatsBtn, async () => {
    Store.resetStats();
    syncConfigToNative();
    toast('Статистика сброшена', 'ok');
  }, { ms: 1800 });

  const resetAllBtn = page.querySelector('#resetAll');
  holdButton(resetAllBtn, async () => {
    const ok = await confirmDialog({ title: 'Полный сброс?', text: 'Будут удалены настройки, история и достижения. Действие необратимо.', okLabel: 'Сбросить всё', danger: true });
    if (!ok) return;
    Store.resetAll();
    location.href = 'onboarding.html';
  }, { ms: 1800 });

  page.querySelector('#goPerms').addEventListener('click', () => { location.href = 'permissions.html'; });
}

async function renderDiagnostics() {
  const box = page.querySelector('#diagBox');
  if (!Native.isNative() && !Native.demoActive()) {
    box.innerHTML = '<div class="banner info" style="margin-bottom:8px">Диагностика доступна после сборки APK. В браузере показывается предпросмотр интерфейса.</div>';
    return;
  }
  const d = await Native.diagnostics();
  if (!d.ok) {
    box.innerHTML = '<div class="banner warn">Нативный сервис ещё не отвечал. Запустите приложение на устройстве.</div>';
    return;
  }
  box.innerHTML = `
    <div class="stat-line"><span class="s-label">Фоновый сервис</span><span class="s-value">${d.running ? 'работает' : 'не запущен'}</span></div>
    <div class="stat-line"><span class="s-label">Последний тик</span><span class="s-value num">${d.lastTickTs ? fmtClock(d.lastTickTs) : '—'}</span></div>
    <div class="stat-line"><span class="s-label">Синхронизация статистики</span><span class="s-value num">${d.lastStatsSyncTs ? fmtClock(d.lastStatsSyncTs) : '—'}</span></div>
    <div class="stat-line"><span class="s-label">Спец. возможности</span><span class="s-value">${d.accessibilityConnected ? 'подключены' : 'отключены'}</span></div>
  `;
}

initShell({ title: 'Настройки', tab: 'settings' });
skeleton(page, 3);
render().catch((e) => {
  console.warn('[settings]', e);
  page.innerHTML = `<div class="empty">${icon('alert')}<h3>Ошибка загрузки</h3><p>${esc(String(e.message || e))}</p></div>`;
});
