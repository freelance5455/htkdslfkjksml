/* Focus Guardian — страница «Мотивация»: библиотека советов и цитат */

import { initShell, skeleton } from '../core/shell.js';
import { Store } from '../core/storage.js';
import { icon } from '../core/icons.js';
import { toast, emptyState } from '../core/ui.js';
import { esc } from '../core/util.js';
import { QUOTES, CATEGORIES, catLabel } from '../core/motivation.js';

const page = document.getElementById('page');

function render() {
  const s = Store.settings();
  const enabled = s.motivation.categories;

  page.innerHTML = `
    <div class="card glow">
      <div class="card-title">${icon('sparkles')} Библиотека мотивации</div>
      <div class="card-sub" style="margin-bottom:12px">Включите темы, которые вам близки: они используются в цитате дня на главной и в уведомлениях.</div>
      <div class="chips" id="catChips">
        ${CATEGORIES.map((c) => `<button class="chip ${enabled[c.id] !== false ? 'active' : ''}" data-v="${c.id}">${c.label}</button>`).join('')}
      </div>
      <div class="setting-row" style="margin-top:14px">
        <div class="s-text"><div class="s-title">Цитата дня на главной</div><div class="s-desc">Случайный совет из включённых тем каждое утро</div></div>
        <span id="dailyQuote"></span>
      </div>
    </div>

    <div class="section-label">Советы · ${CATEGORIES.filter((c) => enabled[c.id] !== false).length} тем включено</div>
    <div id="quotesBox"></div>
  `;

  page.querySelector('#catChips').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    const id = chip.dataset.v;
    const cats = { ...Store.settings().motivation.categories };
    cats[id] = cats[id] === false;
    Store.updateSettings({ motivation: { ...Store.settings().motivation, categories: cats } });
    chip.classList.toggle('active', cats[id] !== false);
    toast(cats[id] !== false ? `Тема «${catLabel(id)}» включена` : `Тема «${catLabel(id)}» выключена`, 'info', 1800);
    renderQuotes();
  });

  page.querySelector('#dailyQuote').insertAdjacentHTML('beforeend', '');
  const dq = document.createElement('label');
  dq.className = 'switch';
  dq.innerHTML = `<input type="checkbox" ${s.motivation.dailyQuote ? 'checked' : ''}><span class="track"></span><span class="thumb"></span>`;
  dq.querySelector('input').addEventListener('change', (e) => {
    Store.updateSettings({ motivation: { ...Store.settings().motivation, dailyQuote: e.target.checked } });
  });
  page.querySelector('#dailyQuote').appendChild(dq);

  renderQuotes();
}

function renderQuotes() {
  const enabled = Store.settings().motivation.categories;
  const box = page.querySelector('#quotesBox');
  const items = [];
  for (const c of CATEGORIES) {
    if (enabled[c.id] === false) continue;
    for (const q of QUOTES[c.id] || []) items.push({ text: q, cat: c.id });
  }
  if (!items.length) {
    box.innerHTML = '';
    box.appendChild(emptyState({ iconName: 'sparkles', title: 'Все темы выключены', text: 'Включите хотя бы одну тему выше.' }));
    return;
  }
  box.innerHTML = items.map((q) => `
    <div class="card tip-card">
      <div class="t-quote">${esc(q.text)}</div>
      <div class="t-tag">${esc(catLabel(q.cat))}</div>
    </div>`).join('');
}

initShell({ title: 'Мотивация', tab: 'tips' });
skeleton(page, 2);
render();
