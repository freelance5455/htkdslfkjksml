/* Focus Guardian — онбординг: первичная настройка и выдача разрешений */

import { icon } from '../core/icons.js';
import { toast } from '../core/ui.js';
import { switchEl, stepper } from '../core/ui.js';
import { Store } from '../core/storage.js';
import { Native } from '../core/native.js';
import { fmtMin } from '../core/util.js';

const page = document.getElementById('page');
let step = 0;
let perm = { ok: false };

const STEPS = [
  { id: 'welcome' },
  { id: 'usage' },
  { id: 'accessibility' },
  { id: 'overlay' },
  { id: 'battery' },
  { id: 'goals' },
  { id: 'mode' },
  { id: 'done' },
];

async function refreshPerm() {
  if (Native.isNative()) {
    perm = await Native.permissions();
  } else {
    perm = { ok: false };
  }
}

function render() {
  const id = STEPS[step].id;
  page.innerHTML = `
    <div class="onb-wrap">
      <div class="onb-dots">${STEPS.map((_, i) => `<i class="${i === step ? 'active' : i < step ? 'done' : ''}" style="${i < step ? 'background:var(--ok)' : ''}"></i>`).join('')}</div>
      <div id="onbBody"></div>
      <div class="onb-actions">
        <button class="btn block" id="nextBtn"></button>
        ${id !== 'welcome' && id !== 'done' ? '<button class="btn ghost block" id="skipBtn">Пока пропустить — настроить позже</button>' : ''}
      </div>
    </div>
  `;

  const body = page.querySelector('#onbBody');
  const next = page.querySelector('#nextBtn');
  const skip = page.querySelector('#skipBtn');

  if (id === 'welcome') {
    body.innerHTML = `
      <div class="onb-icon">${icon('shield')}</div>
      <div class="onb-title">Focus Guardian</div>
      <div class="onb-text">Твой помощник цифровой дисциплины: контроль экранного времени, отдых глаз по правилу 20-20-20, лимиты приложений и режимы фокуса.<br><br>Все данные хранятся только на устройстве.</div>
      <div class="field" style="margin-top:4px">
        <label style="font-size:12.5px;color:var(--text-2);display:block;margin-bottom:6px">Как к тебе обращаться? (необязательно)</label>
        <input type="text" class="input" id="nameInput" placeholder="Имя" value="${Store.settings().profile.name || ''}">
      </div>`;
    next.innerHTML = `${icon('chevron')}<span>Начать настройку</span>`;
    next.addEventListener('click', () => {
      const v = page.querySelector('#nameInput').value.trim();
      if (v) Store.updateSettings({ profile: { name: v } });
      step = 1;
      render();
    });
  } else if (id === 'usage') {
    body.innerHTML = `
      <div class="onb-icon">${icon('chart')}</div>
      <div class="onb-title">Доступ к статистике</div>
      <div class="onb-text">Чтобы видеть реальное экранное время и время в каждом приложении, Android требует разрешение «Usage access».<br><br>На экране настроек найди Focus Guardian в списке и включи переключатель.</div>
      ${perm.ok && perm.usageAccess ? '<div class="banner ok">Разрешение выдано — отлично!</div>' : '<div class="banner info">Коснись кнопки ниже, найди приложение в списке и включи доступ.</div>'}`;
    next.innerHTML = perm.ok && perm.usageAccess ? `${icon('chevron')}<span>Далее</span>` : `${icon('shield')}<span>Открыть настройки доступа</span>`;
    next.addEventListener('click', async () => {
      if (perm.ok && perm.usageAccess) { step = 2; render(); return; }
      const r = await Native.openUsageAccess();
      if (!r.ok) toast('Доступно в APK-сборке. Пока можно пропустить.', 'warn', 4000);
      else { await refreshPerm(); render(); }
    });
  } else if (id === 'accessibility') {
    body.innerHTML = `
      <div class="onb-icon">${icon('lock')}</div>
      <div class="onb-title">Блокировка приложений</div>
      <div class="onb-text">Чтобы закрывать доступ к приложению по достижении лимита, нужен сервис специальных возможностей.<br><br>Focus Guardian не читает содержимое экрана — он видит только, какое приложение открыто.</div>
      ${perm.ok && perm.accessibility ? '<div class="banner ok">Сервис подключён!</div>' : '<div class="banner info">Включи Focus Guardian в списке сервисов.</div>'}`;
    next.innerHTML = perm.ok && perm.accessibility ? `${icon('chevron')}<span>Далее</span>` : `${icon('shield')}<span>Открыть спец. возможности</span>`;
    next.addEventListener('click', async () => {
      if (perm.ok && perm.accessibility) { step = 3; render(); return; }
      const r = await Native.openAccessibility();
      if (!r.ok) toast('Доступно в APK-сборке. Пока можно пропустить.', 'warn', 4000);
      else { await refreshPerm(); render(); }
    });
  } else if (id === 'overlay') {
    body.innerHTML = `
      <div class="onb-icon">${icon('lock')}</div>
      <div class="onb-title">Экран блокировки поверх приложений</div>
      <div class="onb-text">Когда лимит приложения исчерпан, мы покажем экран «Время вышло!» поверх него. Для этого нужно разрешение «Поверх других окон».</div>
      ${perm.ok && perm.overlay ? '<div class="banner ok">Разрешение выдано!</div>' : '<div class="banner info">Разреши отображение поверх других окон.</div>'}`;
    next.innerHTML = perm.ok && perm.overlay ? `${icon('chevron')}<span>Далее</span>` : `${icon('shield')}<span>Открыть настройки</span>`;
    next.addEventListener('click', async () => {
      if (perm.ok && perm.overlay) { step = 4; render(); return; }
      const r = await Native.openOverlay();
      if (!r.ok) toast('Доступно в APK-сборке. Пока можно пропустить.', 'warn', 4000);
      else { await refreshPerm(); render(); }
    });
  } else if (id === 'battery') {
    body.innerHTML = `
      <div class="onb-icon">${icon('battery')}</div>
      <div class="onb-title">Стабильная фоновая работа</div>
      <div class="onb-text">Напоминания об отдыхе и итоги дня считает фоновый сервис. Разреши Android не отключать его для экономии батареи — расход будет минимальным.</div>
      ${perm.ok && perm.batteryIgnored ? '<div class="banner ok">Оптимизация отключена!</div>' : '<div class="banner info">Выбери «Не оптимизировать» в диалоге.</div>'}`;
    next.innerHTML = perm.ok && perm.batteryIgnored ? `${icon('chevron')}<span>Далее</span>` : `${icon('battery')}<span>Открыть настройки батареи</span>`;
    next.addEventListener('click', async () => {
      if (perm.ok && perm.batteryIgnored) { step = 5; render(); return; }
      const r = await Native.openBattery();
      if (!r.ok) toast('Доступно в APK-сборке. Пока можно пропустить.', 'warn', 4000);
      else { await refreshPerm(); render(); }
    });
  } else if (id === 'goals') {
    const s = Store.settings();
    body.innerHTML = `
      <div class="onb-icon">${icon('target')}</div>
      <div class="onb-title">Дневная цель</div>
      <div class="onb-text">Сколько времени в телефоне ты считаешь нормой? Цель можно изменить в любой момент.</div>
      <div class="field" style="margin-top:10px"><div id="goalStepper"></div></div>`;
    body.querySelector('#goalStepper').appendChild(stepper({
      value: s.goals.screenMin, min: 60, max: 720, step: 15, suffix: 'минут в день',
      onChange: (v) => {
        Store.updateSettings({ goals: { ...Store.settings().goals, screenMin: v }, dailyLimitMin: v });
      },
    }));
    next.innerHTML = `${icon('chevron')}<span>Далее</span>`;
    next.addEventListener('click', () => {
      Store.updateSettings({ dailyLimitMin: Store.settings().goals.screenMin });
      step = 6;
      render();
    });
  } else if (id === 'mode') {
    const s = Store.settings();
    body.innerHTML = `
      <div class="onb-icon">${icon('shield')}</div>
      <div class="onb-title">Режим дисциплины</div>
      <div class="onb-text">Начни с мягкого или стандартного — строгие режимы всегда можно включить позже.</div>
      <div class="field">
        <div class="chips" style="flex-direction:column;align-items:stretch">
          ${[
            { id: 'soft', label: 'Мягкий — только напоминания' },
            { id: 'standard', label: 'Стандартный — напоминания и лимиты' },
            { id: 'strict', label: 'Строгий — автоблокировка по лимитам' },
            { id: 'max', label: 'Максимальная концентрация' },
          ].map((m) => `<button class="chip ${s.mode === m.id ? 'active' : ''}" data-v="${m.id}" style="padding:13px 16px">${m.label}</button>`).join('')}
        </div>
      </div>`;
    body.querySelector('.chips').addEventListener('click', (e) => {
      const chip = e.target.closest('.chip');
      if (!chip) return;
      body.querySelectorAll('.chip').forEach((c) => c.classList.toggle('active', c === chip));
      Store.updateSettings({ mode: chip.dataset.v });
    });
    next.innerHTML = `${icon('check')}<span>Завершить настройку</span>`;
    next.addEventListener('click', () => { step = 7; render(); });
  } else {
    body.innerHTML = `
      <div class="onb-icon">${icon('check')}</div>
      <div class="onb-title">Всё готово!</div>
      <div class="onb-text">Focus Guardian настроен. Загляни в «Разрешения Android», если что-то пропустил, и начни с малого: один сеанс фокуса и пара перерывов для глаз в день.<br><br>${Native.isNative() ? '' : 'Совет: сейчас ты в браузерном предпросмотре. Собери APK по инструкции docs/BUILD.md, чтобы включить полную функциональность.'}</div>`;
    next.innerHTML = `${icon('play')}<span>Перейти на главную</span>`;
    next.addEventListener('click', finish);
  }

  if (skip) {
    skip.addEventListener('click', () => {
      if (step < STEPS.length - 1) { step += 1; render(); }
    });
  }
}

function finish() {
  Store.updateSettings({ onboarded: true });
  location.href = 'index.html';
}

(async () => {
  await refreshPerm();
  render();
})();
