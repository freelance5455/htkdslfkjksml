/* Focus Guardian — страница «Ещё»: меню разделов + сводка состояния */

import { initShell } from '../core/shell.js';
import { Native } from '../core/native.js';
import { icon } from '../core/icons.js';
import { badge } from '../core/ui.js';
import { esc } from '../core/util.js';
import { Store, dayKey } from '../core/storage.js';
import { fmtMin } from '../core/util.js';

const page = document.getElementById('page');

const TILES = [
  { href: 'health.html', iconName: 'eye', title: 'Здоровье глаз', sub: 'Правило 20-20-20 и перерывы' },
  { href: 'rest.html', iconName: 'moon', title: 'Время для себя', sub: 'Отдых от телефона с таймером' },
  { href: 'goals.html', iconName: 'target', title: 'Мои цели', sub: 'Дневные цели, достижения, серии' },
  { href: 'tips.html', iconName: 'sparkles', title: 'Мотивация', sub: 'Библиотека советов и цитат' },
  { href: 'settings.html', iconName: 'settings', title: 'Настройки', sub: 'Тема, уведомления, лимиты, данные' },
  { href: 'permissions.html', iconName: 'shield', title: 'Разрешения Android', sub: 'Проверка и объяснение разрешений' },
];

async function render() {
  const perms = Native.isNative() || Native.demoActive() ? await Native.permissions() : { ok: false };
  const today = Store.day(dayKey());
  const rulesCount = Object.keys(Store.rules()).length;

  let statusHtml = '';
  if (perms.ok) {
    const items = [
      perms.usageAccess ? badge('Статистика', 'ok') : badge('Статистика', 'warn'),
      perms.accessibility ? badge('Блокировка', 'ok') : badge('Блокировка', 'warn'),
      perms.overlay ? badge('Оверлей', 'ok') : badge('Оверлей', 'warn'),
      perms.batteryIgnored ? badge('Батарея', 'ok') : badge('Батарея', 'warn'),
    ];
    statusHtml = `<div class="row-wrap">${items.map((b) => b.outerHTML).join('')}</div>
      ${(!perms.usageAccess || !perms.accessibility) ? '<div class="tiny muted" style="margin-top:8px">Не все разрешения выданы — откройте «Разрешения Android».</div>' : ''}`;
  } else {
    statusHtml = '<div class="tiny muted">Полный функционал доступен после сборки APK.</div>';
  }

  page.innerHTML = `
    <div class="card glow">
      <div class="card-title">${icon('activity')} Состояние</div>
      ${statusHtml}
      <div class="stat-line" style="margin-top:6px"><span class="s-label">Экран сегодня</span><span class="s-value num">${fmtMin(today.totalMin)}</span></div>
      <div class="stat-line"><span class="s-label">Правил приложений</span><span class="s-value num">${rulesCount}</span></div>
    </div>

    <div class="section-label">Разделы</div>
    <div class="more-grid">
      ${TILES.map((t) => `
        <a class="more-tile" href="${t.href}">
          ${icon(t.iconName)}
          <div>
            <div class="t-title">${esc(t.title)}</div>
            <div class="t-sub">${esc(t.sub)}</div>
          </div>
        </a>`).join('')}
    </div>

    <div class="tiny muted center" style="margin-top:22px">Focus Guardian 1.0.0 · локальные данные · без аналитики в сети</div>
  `;
}

initShell({ title: 'Ещё', tab: 'more' });
page.innerHTML = '<div class="skeleton" style="height:200px"></div>';
render().catch((e) => console.warn('[more]', e));
