/* Focus Guardian — страница «Фокус»: сеансы концентрации, блокировка отвлекающих, статистика */

import { initShell, skeleton } from '../core/shell.js';
import { Store } from '../core/storage.js';
import { Native } from '../core/native.js';
import { icon } from '../core/icons.js';
import { ringInto, refreshRing, ringSVG } from '../core/charts.js';
import { toast, confirmDialog, seg, switchEl, holdButton } from '../core/ui.js';
import { fmtMin, esc, fmtClock } from '../core/util.js';
import { startSession, stopSession, currentSession, focusStats } from '../core/sessions.js';
import { Bus } from '../core/engine.js';

const page = document.getElementById('page');
let session = null;
let uiTimer = null;

const PRESETS = [15, 25, 30, 45, 60];

async function renderIdle() {
  const s = Store.settings();
  const fs = focusStats();

  // слить нативный журнал сеансов (сеансы, завершённые при закрытом приложении)
  if (Native.isNative()) {
    const log = await Native.sessionsLog();
    if (log.ok && log.sessions) {
      Store.mergeFocusSessions(log.sessions.map((e) => ({
        startedTs: e.startedTs, endedTs: e.endedTs, plannedMin: e.plannedMin,
        actualMin: e.actualMin ?? e.plannedMin, success: e.success !== false, violations: e.violations || 0,
      })));
    }
  }

  page.innerHTML = `
    <div class="card glow">
      <div class="card-title">${icon('target')} Режим фокуса</div>
      <div class="card-sub" style="margin-bottom:14px">Выбери длительность и стартуй. Отвлекающие приложения будут заблокированы, а телефон поможет удержать концентрацию.</div>
      <div class="chips" id="durChips">
        ${PRESETS.map((m) => `<button class="chip ${s.focus.defaultMin === m ? 'active' : ''}" data-v="${m}">${m} мин</button>`).join('')}
        <button class="chip ${!PRESETS.includes(s.focus.defaultMin) ? 'active' : ''}" data-v="custom">Своё</button>
      </div>
      <div class="row hidden" id="customRow" style="margin-top:12px">
        <input type="number" class="input" id="customMin" min="1" max="240" placeholder="Минуты" style="flex:1" value="${!PRESETS.includes(s.focus.defaultMin) ? s.focus.defaultMin : ''}">
        <button class="btn small" id="applyCustom"><span>Ок</span></button>
      </div>
      <div class="setting-row" style="margin-top:8px">
        <div class="s-text"><div class="s-title">Блокировать отвлекающие приложения</div><div class="s-desc">Приложения с лимитами и выбранные ниже будут недоступны во время сеанса</div></div>
        <span id="blockToggle"></span>
      </div>
      <div class="setting-row">
        <div class="s-text"><div class="s-title">Режим «Не беспокоить»</div><div class="s-desc">Заглушает уведомления Android на время сеанса (нужно разрешение «Доступ к уведомлениям»)</div></div>
        <span id="dndToggle"></span>
      </div>
      <button class="btn block" id="startBtn" style="margin-top:16px">${icon('play')}<span>Начать сеанс фокуса</span></button>
    </div>

    <div class="card">
      <div class="card-title">${icon('chart')} Статистика концентрации</div>
      <div class="kpi-grid">
        <div class="kpi"><div class="k-label">${icon('clock')} Всего часов</div><div class="k-value num">${fs.totalHours}</div><div class="k-sub">концентрации суммарно</div></div>
        <div class="kpi"><div class="k-label">${icon('check')} Успешных сеансов</div><div class="k-value num">${fs.success}</div><div class="k-sub">из ${fs.sessions}</div></div>
        <div class="kpi"><div class="k-label">${icon('flame')} Лучшая серия</div><div class="k-value num">${fs.bestStreak}</div><div class="k-sub">дней подряд</div></div>
        <div class="kpi"><div class="k-label">${icon('timer')} Средний сеанс</div><div class="k-value num">${fs.avgMin} мин</div><div class="k-sub">по всем сеансам</div></div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">${icon('calendar')} История сеансов</div>
      <div id="historyBox"></div>
    </div>
  `;

  /* чипы длительности */
  page.querySelector('#durChips').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    page.querySelectorAll('#durChips .chip').forEach((c) => c.classList.toggle('active', c === chip));
    if (chip.dataset.v === 'custom') {
      page.querySelector('#customRow').classList.remove('hidden');
    } else {
      page.querySelector('#customRow').classList.add('hidden');
      Store.updateSettings({ focus: { ...s.focus, defaultMin: Number(chip.dataset.v) } });
      page.querySelector('#customRow').classList.add('hidden');
    }
  });
  page.querySelector('#applyCustom').addEventListener('click', () => {
    const v = Number(page.querySelector('#customMin').value);
    if (!v || v < 1 || v > 240) return toast('Укажите от 1 до 240 минут', 'warn');
    Store.updateSettings({ focus: { ...Store.settings().focus, defaultMin: Math.round(v) } });
    toast(`Стандартная длительность: ${v} мин`, 'ok');
  });

  page.querySelector('#blockToggle').appendChild(switchEl(s.focus.blockApps, (v) => {
    Store.updateSettings({ focus: { ...Store.settings().focus, blockApps: v } });
  }));
  page.querySelector('#dndToggle').appendChild(switchEl(s.focus.dnd, async (v) => {
    Store.updateSettings({ focus: { ...Store.settings().focus, dnd: v } });
    if (v && Native.isNative()) {
      const perm = await Native.permissions();
      if (!perm.ok || !perm.dnd) {
        toast('Выдайте доступ «Не беспокоить» в разрешениях', 'warn', 4000);
      }
    }
  }));

  page.querySelector('#startBtn').addEventListener('click', startFocus);

  /* история */
  const hb = page.querySelector('#historyBox');
  if (fs.list.length) {
    hb.innerHTML = fs.list.map((f) => `
      <div class="list-item" style="cursor:default">
        <div class="icon-tile ${f.success ? 'ok' : 'warn'}">${icon(f.success ? 'check' : 'pause')}</div>
        <div class="grow">
          <div style="font-weight:600;font-size:13.5px">${fmtClock(f.startedTs)} · ${fmtMin(Math.round(f.actualMin))} из ${f.plannedMin} мин</div>
          <div class="tiny muted">${new Date(f.startedTs).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })}${f.violations ? ` · нарушений: ${f.violations}` : ''}</div>
        </div>
        <span class="badge ${f.success ? 'ok' : 'warn'}">${f.success ? 'Успех' : 'Прерван'}</span>
      </div>`).join('');
  } else {
    hb.innerHTML = '<div class="tiny muted center" style="padding:16px">Пока нет завершённых сеансов. Начни первый!</div>';
  }
}

async function renderActive() {
  const s = Store.settings();
  const total = (session.endsTs - session.startedTs) / 1000;
  const blockCount = (session.blockPkgs || []).length;
  const dndOn = s.focus.dnd;

  page.innerHTML = `
    <div class="session-hero card glow">
      <div class="card-title" style="justify-content:center">${icon('target')} Идёт сеанс фокуса</div>
      <div class="session-ring-wrap" id="fRing"></div>
      <div class="muted" id="fState">Держим концентрацию…</div>
      ${blockCount && s.focus.blockApps ? `<div class="tiny muted" style="margin-top:8px">Заблокировано приложений: ${blockCount}${dndOn ? ' · «Не беспокоить» включён' : ''}</div>` : ''}
      <div class="violation-note hidden" id="fViol"></div>
      <button class="btn danger block hold-btn" id="stopBtn" style="margin-top:22px">${icon('pause')}<span>Удерживайте, чтобы прервать</span></button>
      ${!Native.isNative() ? '<div class="tiny muted" style="margin-top:10px">Без APK-сборки сеанс засчитывается только пока приложение открыто.</div>' : ''}
    </div>

    <div class="card">
      <div class="card-title">${icon('sparkles')} Подсказка</div>
      <div class="tiny muted">Положи телефон экраном вниз и займись делом. Focus Guardian проследит за дисциплиной и не даст отвлечься.</div>
    </div>
  `;

  ringInto(page.querySelector('#fRing'), 100, { size: 240, value: '', sub: '' });
  holdButton(page.querySelector('#stopBtn'), async () => {
    clearInterval(uiTimer);
    await stopSession(false);
    session = null;
    renderIdle();
  }, { ms: 1600 });

  const tick = async () => {
    if (!session) return;
    // при нативном сеансе — синхронизация состояния (нарушения, завершение)
    if (Native.isNative() && session.source === 'native') {
      const ns = await Native.nativeSession();
      if (ns.ok && !ns.active) {
        clearInterval(uiTimer);
        session = null;
        toast('Сеанс фокуса завершён. Отличная работа!', 'ok');
        renderIdle();
        return;
      }
      if (ns.ok && ns.violations) {
        const v = page.querySelector('#fViol');
        if (v) {
          v.classList.remove('hidden');
          v.textContent = `Попыток открыть заблокированное приложение: ${ns.violations}`;
        }
      }
    }
    const left = Math.max(0, (session.endsTs - Date.now()) / 1000);
    const pct = Math.max(0, Math.min(100, (left / total) * 100));
    const mins = Math.floor(left / 60);
    const secs = Math.floor(left % 60);
    const svg = page.querySelector('#fRing');
    if (svg) {
      refreshRing(svg.querySelector('.ring-svg'), pct);
      const c = svg.querySelector('.ring-center .r-value, .ring-center');
      const center = svg.querySelector('.ring-center');
      if (center) {
        center.innerHTML = `<div class="r-value" style="font-size:34px">${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}</div><div class="r-sub">осталось</div>`;
      }
    }
    if (left <= 0) {
      clearInterval(uiTimer);
      await stopSession(true);
      session = null;
      renderIdle();
    }
  };
  uiTimer = setInterval(tick, 1000);
  tick();
}

async function startFocus() {
  const s = Store.settings();
  let minutes = s.focus.defaultMin;

  // список блокируемых: приложения с лимитами + (если blockApps) все с правилами
  const blockPkgs = [];
  if (s.focus.blockApps) {
    for (const [pkg, rule] of Object.entries(Store.rules())) {
      if (rule.enabled !== false) blockPkgs.push(pkg);
    }
  }

  if (s.focus.dnd && Native.isNative()) {
    const perm = await Native.permissions();
    if (!perm.ok || !perm.dnd) toast('Разрешение «Не беспокоить» не выдано — уведомления будут как обычно', 'warn', 4500);
  }

  session = await startSession('focus', minutes, blockPkgs);
  renderActive();
}

initShell({ title: 'Фокус', tab: 'focus' });
skeleton(page, 2);

(async () => {
  try {
    session = await currentSession();
    if (session) renderActive();
    else renderIdle();
  } catch (e) {
    console.warn('[focus]', e);
    renderIdle();
  }
})();

Bus.addEventListener('session-end', () => {
  session = null;
  if (uiTimer) clearInterval(uiTimer);
  renderIdle();
});
