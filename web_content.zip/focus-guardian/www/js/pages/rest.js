/* Focus Guardian — страница «Время для себя»: отдых от телефона */

import { initShell, skeleton } from '../core/shell.js';
import { Store, dayKey } from '../core/storage.js';
import { Native } from '../core/native.js';
import { icon } from '../core/icons.js';
import { toast, switchEl, confirmDialog, emptyState } from '../core/ui.js';
import { fmtMin, esc, fmtClock } from '../core/util.js';
import { startSession, stopSession, currentSession } from '../core/sessions.js';
import { getLive } from '../core/engine.js';

const page = document.getElementById('page');
let session = null;
let uiTimer = null;

const PRESETS = [
  { v: 5, label: '5 мин' },
  { v: 10, label: '10 мин' },
  { v: 15, label: '15 мин' },
  { v: 20, label: '20 мин' },
  { v: 30, label: '30 мин' },
  { v: 60, label: '1 час' },
  { v: 120, label: '2 часа' },
];

async function renderIdle() {
  const s = Store.settings();
  const live = await getLive();
  const today = Store.day(dayKey());
  const restHistory = Store.get('history.restSessions', []).slice(-8).reverse();
  const withLimit = Object.keys(Store.rules()).length;

  page.innerHTML = `
    <div class="card glow">
      <div class="card-title">${icon('moon')} Время для себя</div>
      <div class="card-sub" style="margin-bottom:14px">Пауза без телефона: таймер покажет, сколько вы отдыхаете, а выбранные приложения будут недоступны до конца отдыха.</div>
      <div class="chips" id="durChips">
        ${PRESETS.map((p) => `<button class="chip" data-v="${p.v}">${p.label}</button>`).join('')}
        <button class="chip" data-v="custom">Своё время</button>
      </div>
      <div class="row hidden" id="customRow" style="margin-top:12px">
        <input type="number" class="input" id="customMin" min="1" max="480" placeholder="Минуты (1–480)" style="flex:1">
        <button class="btn small" id="applyCustom"><span>Ок</span></button>
      </div>

      ${withLimit ? `
      <div class="setting-row" style="margin-top:12px">
        <div class="s-text"><div class="s-title">Блокировать приложения с лимитами</div><div class="s-desc">Во время отдыха лимитированные приложения будут закрыты</div></div>
        <span id="blockToggle"></span>
      </div>` : ''}

      <button class="btn block" id="startBtn" style="margin-top:16px">${icon('play')}<span>Начать отдых</span></button>
      ${!Native.isNative() ? '<div class="tiny muted" style="margin-top:10px">Уведомление о завершении придёт после сборки APK — фоновый таймер нативного сервиса.</div>' : ''}
    </div>

    <div class="setting-card card">
      <div class="card-title">${icon('zap')} Автоотдых</div>
      <div class="setting-row">
        <div class="s-text"><div class="s-title">Предлагать отдых после долгого экрана</div><div class="s-desc">После непрерывного использования фоновый сервис предложит паузу</div></div>
        <span id="autoToggle"></span>
      </div>
      <div class="field" style="margin-top:8px">
        <label>После какого экранного времени</label>
        <div class="chips" id="afterChips">
          ${[60, 90, 120, 180].map((m) => `<button class="chip ${s.rest.afterMin === m ? 'active' : ''}" data-v="${m}">${fmtMin(m)}</button>`).join('')}
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">${icon('coffee')} Отдых сегодня</div>
      <div class="stat-line"><span class="s-label">Время без телефона</span><span class="s-value num">${fmtMin(live.restMinToday || today.restMin || 0)}</span></div>
      <div class="stat-line"><span class="s-label">Последний отдых</span><span class="s-value num">${live.lastRestTs ? fmtClock(live.lastRestTs) : '—'}</span></div>
      <div class="stat-line"><span class="s-label">Самая длинная пауза</span><span class="s-value num">${fmtMin(Math.max(today.longestOfflineMin || 0, live.longestOfflineMin || 0))}</span></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('calendar')} История сеансов отдыха</div>
      <div id="restList"></div>
    </div>
  `;

  let chosen = 10;
  page.querySelector('#durChips').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    page.querySelectorAll('#durChips .chip').forEach((c) => c.classList.toggle('active', c === chip));
    if (chip.dataset.v === 'custom') {
      page.querySelector('#customRow').classList.remove('hidden');
      chosen = null;
    } else {
      page.querySelector('#customRow').classList.add('hidden');
      chosen = Number(chip.dataset.v);
    }
  });
  page.querySelector('#applyCustom').addEventListener('click', () => {
    const v = Number(page.querySelector('#customMin').value);
    if (!v || v < 1 || v > 480) return toast('Укажите от 1 до 480 минут', 'warn');
    chosen = Math.round(v);
    toast(`Отдых: ${fmtMin(chosen)}`, 'ok');
  });

  const blockToggle = page.querySelector('#blockToggle');
  if (blockToggle) blockToggle.appendChild(switchEl(s.rest.blockApps, (v) => {
    Store.updateSettings({ rest: { ...Store.settings().rest, blockApps: v } });
  }));

  page.querySelector('#autoToggle').appendChild(switchEl(s.rest.autoSuggest, (v) => {
    Store.updateSettings({ rest: { ...Store.settings().rest, autoSuggest: v } });
  }));
  page.querySelector('#afterChips').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    page.querySelectorAll('#afterChips .chip').forEach((c) => c.classList.toggle('active', c === chip));
    Store.updateSettings({ rest: { ...Store.settings().rest, afterMin: Number(chip.dataset.v) } });
  });

  page.querySelector('#startBtn').addEventListener('click', async () => {
    if (!chosen) return toast('Выберите длительность отдыха', 'warn');
    const blockPkgs = s.rest.blockApps
      ? Object.entries(Store.rules()).filter(([, r]) => r.enabled !== false).map(([pkg]) => pkg)
      : [];
    session = await startSession('rest', chosen, blockPkgs);
    renderActive();
  });

  const rl = page.querySelector('#restList');
  if (restHistory.length) {
    rl.innerHTML = restHistory.map((r) => `
      <div class="list-item" style="cursor:default">
        <div class="icon-tile">${icon('moon')}</div>
        <div class="grow">
          <div style="font-weight:600;font-size:13.5px">${fmtClock(r.startedTs)} · отдых ${fmtMin(Math.round(r.actualMin))}</div>
          <div class="tiny muted">${new Date(r.startedTs).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' })} · план ${r.plannedMin} мин</div>
        </div>
      </div>`).join('');
  } else {
    rl.innerHTML = '';
    rl.appendChild(emptyState({ iconName: 'moon', title: 'Сеансов отдыха пока нет', text: 'Запусти первый отдых — хотя бы 5 минут.' }));
  }
}

async function renderActive() {
  const total = (session.endsTs - session.startedTs) / 1000;

  page.innerHTML = `
    <div class="card glow" style="text-align:center;padding-top:30px">
      <div class="breathing-circle">
        <div style="font-size:40px;font-weight:800" id="rCount">--:--</div>
        <div class="tiny muted">отдыха осталось</div>
      </div>
      <div style="font-size:17px;font-weight:700;margin-bottom:6px">Время для себя</div>
      <div class="tiny muted" style="max-width:280px;margin:0 auto">Экран можно погасить. Фоновый сервис завершит отдых вовремя и напомнит, когда время выйдет.</div>
      <button class="btn ghost block hold-btn" id="stopBtn" style="margin-top:24px">${icon('pause')}<span>Удерживайте, чтобы завершить раньше</span></button>
    </div>
    <div class="card">
      <div class="card-title">${icon('sparkles')} Идеи для паузы</div>
      <div class="tiny muted" style="line-height:1.7">— Разомни шею и плечи<br>— Выйди на короткую прогулку<br>— Сделай несколько глубоких вдохов<br>— Посмотри в окно на дальние объекты<br>— Налей себе воды</div>
    </div>
  `;

  let held = false;
  const stopBtn = page.querySelector('#stopBtn');
  // кнопка завершения требует удержания (защита от случайного нажатия)
  let holdStart = 0;
  let holdTimer = null;
  stopBtn.addEventListener('pointerdown', () => {
    holdStart = Date.now();
    stopBtn.querySelector('span').textContent = 'Удерживайте…';
    holdTimer = setTimeout(async () => {
      held = true;
      clearInterval(uiTimer);
      await stopSession(false);
      session = null;
      renderIdle();
    }, 1600);
  });
  for (const ev of ['pointerup', 'pointerleave', 'pointercancel']) {
    stopBtn.addEventListener(ev, () => {
      clearTimeout(holdTimer);
      if (!held) stopBtn.querySelector('span').textContent = 'Удерживайте, чтобы завершить раньше';
    });
  }

  const tick = async () => {
    if (!session) return;
    if (Native.isNative() && session.source === 'native') {
      const ns = await Native.nativeSession();
      if (ns.ok && !ns.active) {
        clearInterval(uiTimer);
        session = null;
        toast('Отдых завершён. Продолжай день с комфортом', 'ok');
        renderIdle();
        return;
      }
    }
    const left = Math.max(0, (session.endsTs - Date.now()) / 1000);
    const c = page.querySelector('#rCount');
    if (c) {
      const mins = Math.floor(left / 60);
      const secs = Math.floor(left % 60);
      c.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    if (left <= 0) {
      clearInterval(uiTimer);
      await stopSession(true);
      session = null;
      renderIdle();
    }
  };
  uiTimer = setInterval(tick, 1000);
  tick();
}

initShell({ title: 'Время для себя', tab: 'rest' });
skeleton(page, 2);

(async () => {
  try {
    session = await currentSession();
    if (session && session.kind === 'rest') renderActive();
    else renderIdle();
  } catch (e) {
    console.warn('[rest]', e);
    renderIdle();
  }
})();
