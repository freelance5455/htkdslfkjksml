/* Focus Guardian — страница «Главная» */

import { initShell, skeleton, applyTheme } from '../core/shell.js';
import { Store, dayKey, addDays, absorbNativeDay } from '../core/storage.js';
import { Native, SELF_PKG } from '../core/native.js';
import { icon } from '../core/icons.js';
import { ringInto, refreshRing, barChart } from '../core/charts.js';
import { toast } from '../core/ui.js';
import { fmtMin, fmtClock, greeting, compareWithYesterday, esc, fmtDateHuman } from '../core/util.js';
import { getLive, Bus } from '../core/engine.js';
import { quoteOfDay, catLabel } from '../core/motivation.js';
import { evaluate, dailyFeed, allAchievements } from '../core/achievements.js';
import { recommendations } from '../core/assistant.js';

const page = document.getElementById('page');

function labelOf(byApp, pkg) {
  return pkg.split('.').pop();
}

async function render() {
  const s = Store.settings();
  const todayKey = dayKey();
  const yesterdayKey = addDays(todayKey, -1);

  const [perm, usage, series, live] = await Promise.all([
    Native.permissions(),
    Native.usageToday(),
    Native.dailySeries(8),
    getLive(),
  ]);

  if (usage.ok) absorbNativeDay(todayKey, usage);

  const today = Store.day(todayKey);
  const yesterday = Store.get(`history.days.${yesterdayKey}`, null);

  evaluate({ today, live });
  const feed = dailyFeed({ today, live });
  const cmp = compareWithYesterday(today.totalMin, yesterday ? yesterday.totalMin : 0);
  const limit = s.dailyLimitMin;
  const left = Math.max(0, limit - today.totalMin);
  const pct = limit > 0 ? (today.totalMin / limit) * 100 : 0;

  const topPkg = Object.entries(today.byApp || {}).sort((a, b) => b[1].timeMin - a[1].timeMin)[0];
  const q = quoteOfDay(s);
  const tips = recommendations({
    today,
    series: series.ok ? series.series : [],
    topApps: topPkg ? [{ label: labelOf(today.byApp, topPkg[0]), timeMin: topPkg[1].timeMin }] : [],
    unlocks: today.unlocks,
    hasRules: Object.keys(Store.rules()).length > 0,
  });

  const needUsage = !perm.ok || !perm.usageAccess;
  const needBattery = perm.ok && perm.usageAccess && !perm.batteryIgnored;

  page.innerHTML = `
    <div class="hero-card card">
      <div class="hero-greeting">${esc(greeting())}${s.profile.name ? `, ${esc(s.profile.name)}` : ''}!</div>
      <div class="hero-date">${new Date().toLocaleDateString('ru-RU', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
      <div class="hero-ring-wrap" id="heroRing"></div>
      <div class="hero-compare ${cmp.cls}" id="heroCompare">${cmp.text}</div>
    </div>

    ${needUsage ? `
    <div class="banner warn">
      ${icon('alert')}
      <div class="grow">
        <b>Доступ к статистике не выдан</b><br>
        Без него приложение не увидит реальное экранное время. Данные появятся после сборки APK и выдачи разрешения.
        <div><button class="btn small" id="goPerm1"><span>Открыть разрешения</span></button></div>
      </div>
    </div>` : ''}
    ${needBattery ? `
    <div class="banner info">
      ${icon('battery')}
      <div class="grow">
        <b>Отключите оптимизацию батареи</b><br>
        Так фоновый мониторинг и напоминания будут работать стабильно.
        <div><button class="btn small" id="goBattery"><span>Настроить</span></button></div>
      </div>
    </div>` : ''}

    <div class="kpi-grid">
      <div class="kpi"><div class="k-label">${icon('phone')} Разблокировки</div><div class="k-value num">${today.unlocks > 0 ? today.unlocks : (live.available && live.unlocksToday) || 0}</div><div class="k-sub">сегодня</div></div>
      <div class="kpi"><div class="k-label">${icon('zap')} Запуски приложений</div><div class="k-value num">${today.launches || 0}</div><div class="k-sub">за сегодня</div></div>
      <div class="kpi"><div class="k-label">${icon('timer')} Текущий сеанс</div><div class="k-value num" id="kpiSession">—</div><div class="k-sub">непрерывно</div></div>
      <div class="kpi"><div class="k-label">${icon('target')} До лимита</div><div class="k-value num">${left > 0 ? fmtMin(left) : 'Лимит достигнут'}</div><div class="k-sub">лимит ${fmtMin(limit)}</div></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('clock')} Самое используемое</div>
      ${topPkg ? `
      <div class="row">
        <div class="icon-tile">${icon('grid')}</div>
        <div class="grow">
          <div style="font-weight:700">${esc(labelOf(today.byApp, topPkg[0]))}</div>
          <div class="tiny muted">${fmtMin(topPkg[1].timeMin)} сегодня · запусков: ${topPkg[1].launches || 0}</div>
        </div>
        <button class="btn ghost small" id="goApps"><span>Все приложения</span></button>
      </div>` : `<div class="tiny muted">Данные появятся, когда соберётся статистика дня.</div>`}
    </div>

    <div class="card">
      <div class="card-title">${icon('coffee')} Отдых</div>
      <div class="stat-line"><span class="s-label">Последний отдых</span><span class="s-value num" id="lastRest">${live.lastRestTs ? fmtClock(live.lastRestTs) : '—'}</span></div>
      <div class="stat-line"><span class="s-label">Время без телефона сегодня</span><span class="s-value num">${fmtMin(live.restMinToday || today.restMin)}</span></div>
      <div class="stat-line"><span class="s-label">Перерывов сделано</span><span class="s-value num">${today.breaks || 0}</span></div>
      <div class="stat-line"><span class="s-label">Самая длинная пауза</span><span class="s-value num">${fmtMin(Math.max(today.longestOfflineMin || 0, live.longestOfflineMin || 0))}</span></div>
    </div>

    <div class="quick-actions">
      <a class="quick-action" href="focus.html">${icon('target')}<span>Фокус</span></a>
      <a class="quick-action" href="rest.html">${icon('moon')}<span>Время для себя</span></a>
      <a class="quick-action" href="health.html">${icon('eye')}<span>Здоровье глаз</span></a>
    </div>

    <div class="card quote-card">
      <div class="card-title" style="color:var(--accent)">${icon('sparkles')} Мысль дня · ${esc(catLabel(q.cat))}</div>
      <div class="q-text" id="quoteText">${esc(q.text)}</div>
      <div class="row" style="margin-top:10px">
        <button class="btn ghost small" id="quoteMore"><span>Ещё советы</span></button>
        <span class="tiny muted grow" style="text-align:right">включается в настройках мотивации</span>
      </div>
    </div>

    <div class="card">
      <div class="card-title">${icon('chart')} Неделя</div>
      <div class="mini-week" id="miniWeek"></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('sparkles')} Умный помощник</div>
      <div id="tipsBox"></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('trophy')} Достижения дня</div>
      <div id="feedBox"></div>
      <div class="row-wrap" id="achStrip" style="margin-top:10px"></div>
    </div>
  `;

  /* кольцо */
  const ringEl = ringInto(page.querySelector('#heroRing'), Math.min(100, pct), {
    value: fmtMin(today.totalMin),
    sub: 'экранного времени сегодня',
    pctLabel: limit > 0 ? `${Math.round(pct)}% от лимита` : '',
  });

  /* мини-график недели */
  const weekBox = page.querySelector('#miniWeek');
  if (series.ok) {
    const last8 = series.series.slice(-8);
    const max = Math.max(...last8.map((d) => d.totalMin), 1);
    weekBox.innerHTML = last8.map((d, i) => `
      <div class="mw-col" title="${fmtDateHuman(d.date)}: ${fmtMin(d.totalMin)}">
        <div class="mw-bar ${i === last8.length - 1 ? 'today' : ''}" style="height:${Math.max(4, (d.totalMin / max) * 100)}%; opacity:${d.hasData ? 1 : .3}"></div>
        <div class="mw-label">${fmtDateHuman(d.date).slice(0, 2)}</div>
      </div>`).join('');
  } else {
    weekBox.innerHTML = '<div class="chart-empty">Нет данных</div>';
  }

  /* умный помощник */
  const tipsBox = page.querySelector('#tipsBox');
  tipsBox.innerHTML = tips.map((t) => `
    <div class="row" style="align-items:flex-start;padding:9px 0;border-bottom:1px dashed var(--border)">
      <div class="icon-tile">${icon(t.icon)}</div>
      <div class="grow">
        <div style="font-weight:700;font-size:13.5px">${esc(t.title)}</div>
        <div class="tiny muted" style="margin-top:3px">${esc(t.text)}</div>
        ${t.action ? `<a href="${t.action.href}" class="tiny" style="display:inline-block;margin-top:6px;font-weight:700">${esc(t.action.label)} →</a>` : ''}
      </div>
    </div>`).join('');

  /* лента дня + достижения */
  page.querySelector('#feedBox').innerHTML = feed.map((f) =>
    `<div class="row" style="padding:7px 0"><div class="icon-tile ok">${icon('check')}</div><div class="tiny">${esc(f)}</div></div>`
  ).join('');
  const strip = page.querySelector('#achStrip');
  strip.innerHTML = allAchievements().map((a) => `
    <div class="ach ${a.unlocked ? 'unlocked' : ''}" style="flex:1;min-width:96px" title="${esc(a.desc)}">
      ${icon(a.icon)}
      <div class="a-title">${esc(a.title)}</div>
    </div>`).join('');

  /* текущий сеанс — обновляем каждые 30 с */
  const kpiSession = page.querySelector('#kpiSession');
  const updateSession = () => {
    if (live.available && live.screenOn && live.sessionStartTs) {
      const m = Math.max(0, Math.round((Date.now() - live.sessionStartTs) / 60000));
      kpiSession.textContent = m >= 1 ? fmtMin(m) : '<1 мин';
    } else {
      kpiSession.textContent = '—';
    }
  };
  updateSession();
  const sessTimer = setInterval(updateSession, 30000);
  page.addEventListener('pagehide', () => clearInterval(sessTimer), { once: true });

  /* действия */
  page.querySelector('#goApps')?.addEventListener('click', () => { location.href = 'apps.html'; });
  page.querySelector('#goPerm1')?.addEventListener('click', () => { location.href = 'permissions.html'; });
  page.querySelector('#goBattery')?.addEventListener('click', async () => {
    const r = await Native.openBattery();
    if (!r.ok) toast('Функция доступна в APK-сборке', 'warn');
  });
  page.querySelector('#quoteMore')?.addEventListener('click', () => { location.href = 'tips.html'; });

  /* живое обновление кольца при возврате на страницу */
  Bus.addEventListener('visibility', (e) => {
    if (e.detail.visible) render();
  });
}

initShell({ title: 'Focus Guardian', tab: 'home' });
skeleton(page, 3);
render().catch((e) => {
  console.warn('[dashboard]', e);
  page.innerHTML = `<div class="empty">${icon('alert')}<h3>Не удалось загрузить данные</h3><p>${esc(String(e.message || e))}</p></div>`;
});
