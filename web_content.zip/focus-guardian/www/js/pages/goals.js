/* Focus Guardian — страница «Мои цели»: дневные цели, прогресс, достижения, серии */

import { initShell, skeleton } from '../core/shell.js';
import { Store, dayKey, addDays } from '../core/storage.js';
import { Native } from '../core/native.js';
import { icon } from '../core/icons.js';
import { toast, stepper, emptyState } from '../core/ui.js';
import { fmtMin, esc } from '../core/util.js';
import { allAchievements, dailyFeed, streakInfo } from '../core/achievements.js';
import { getLive } from '../core/engine.js';
import { Native as N } from '../core/native.js';

const page = document.getElementById('page');
const CATS = { social: 'Соцсети', video: 'Видео', games: 'Игры' };

function catMinutes(today, cat) {
  let sum = 0;
  for (const [pkg, v] of Object.entries(today.byApp || {})) {
    const rule = Store.rule(pkg);
    const label = pkg.split('.').pop().toLowerCase();
    const id = rule?.category || (/telegram|vk|instagram|whatsapp|tiktok|reddit/.test(pkg + label) ? 'social' : /youtube|netflix|video|music/.test(pkg + label) ? 'video' : /game/.test(pkg + label) ? 'games' : 'other');
    if (id === cat) sum += v.timeMin || 0;
  }
  return sum;
}

async function render() {
  const s = Store.settings();
  const live = await getLive();
  const today = Store.day(dayKey());

  const goals = [
    { key: 'screenMin', name: 'Экранное время в день', val: today.totalMin, limit: s.goals.screenMin, unit: 'мин', inv: false },
    { key: 'socialMin', name: 'Время в социальных сетях', val: catMinutes(today, 'social'), limit: s.goals.socialMin, unit: 'мин', inv: false },
    { key: 'videoMin', name: 'Время в видеосервисах', val: catMinutes(today, 'video'), limit: s.goals.videoMin, unit: 'мин', inv: false },
    { key: 'gamesMin', name: 'Время в играх', val: catMinutes(today, 'games'), limit: s.goals.gamesMin, unit: 'мин', inv: false },
    { key: 'breaksMin', name: 'Минимум перерывов', val: today.breaks || 0, limit: s.goals.breaksMin, unit: '', inv: true },
    { key: 'offlineMin', name: 'Минимум времени без телефона', val: Math.max(today.restMin || 0, live.restMinToday || 0), limit: s.goals.offlineMin, unit: 'мин', inv: true },
  ];

  const feed = dailyFeed({ today, live });
  const streak = streakInfo();
  const achs = allAchievements();
  const unlockedCount = achs.filter((a) => a.unlocked).length;

  page.innerHTML = `
    <div class="card glow">
      <div class="card-title">${icon('target')} Сегодня против целей</div>
      <div id="goalList"></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('flame')} Серии дисциплины</div>
      <div class="kpi-grid">
        <div class="kpi"><div class="k-label">${icon('flame')} Текущая серия</div><div class="k-value num">${streak.current}</div><div class="k-sub">дней в пределах цели</div></div>
        <div class="kpi"><div class="k-label">${icon('trophy')} Лучшая серия</div><div class="k-value num">${streak.best}</div><div class="k-sub">за всё время</div></div>
      </div>
    </div>

    <div class="card">
      <div class="card-title">${icon('sparkles')} Достижения дня</div>
      <div id="feedBox"></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('trophy')} Достижения <span class="badge accent">${unlockedCount}/${achs.length}</span></div>
      <div class="ach-grid" id="achGrid"></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('edit')} Редактировать цели</div>
      <div id="goalEditors"></div>
    </div>
  `;

  /* прогресс целей */
  const gl = page.querySelector('#goalList');
  gl.innerHTML = goals.map((g) => {
    const pct = g.limit > 0 ? Math.min(100, (g.val / g.limit) * 100) : 0;
    const ok = g.inv ? g.val >= g.limit : g.val <= g.limit;
    const cls = ok ? 'ok' : pct >= 100 ? 'danger' : pct >= 80 ? 'warn' : '';
    const unit = g.unit ? ' мин' : '';
    return `
    <div class="goal-row">
      <div class="goal-top">
        <span class="g-name">${esc(g.name)}</span>
        <span class="g-nums">${g.val}${unit} <span class="g-limit">/ ${g.limit}${unit}</span></span>
      </div>
      <div class="progress-track"><div class="progress-fill ${cls}" style="width:${pct}%"></div></div>
    </div>`;
  }).join('');

  page.querySelector('#feedBox').innerHTML = feed.map((f) =>
    `<div class="row" style="padding:7px 0;align-items:flex-start"><div class="icon-tile ok">${icon('check')}</div><div class="tiny">${esc(f)}</div></div>`
  ).join('');

  page.querySelector('#achGrid').innerHTML = achs.map((a) => `
    <div class="ach ${a.unlocked ? 'unlocked' : ''}" title="${esc(a.desc)}">
      ${icon(a.icon)}
      <div class="a-title">${esc(a.title)}</div>
      <div class="a-sub">${a.unlocked ? 'открыто' : 'в процессе'}</div>
    </div>`).join('');

  /* редакторы целей */
  const ed = page.querySelector('#goalEditors');
  const editors = [
    { key: 'screenMin', name: 'Экранное время', min: 60, max: 720, step: 15, suffix: 'мин' },
    { key: 'socialMin', name: 'Соцсети', min: 15, max: 300, step: 15, suffix: 'мин' },
    { key: 'videoMin', name: 'Видео', min: 15, max: 300, step: 15, suffix: 'мин' },
    { key: 'gamesMin', name: 'Игры', min: 15, max: 300, step: 15, suffix: 'мин' },
    { key: 'breaksMin', name: 'Перерывы', min: 2, max: 16, step: 1, suffix: 'в день' },
    { key: 'offlineMin', name: 'Без телефона', min: 30, max: 600, step: 30, suffix: 'мин' },
  ];
  for (const e of editors) {
    const row = document.createElement('div');
    row.className = 'setting-row';
    row.innerHTML = `<div class="s-text"><div class="s-title">${e.name}</div><div class="s-desc">шаг ${e.step}${e.unit ? '' : ''}</div></div>`;
    row.appendChild(stepper({
      value: s.goals[e.key],
      min: e.min,
      max: e.max,
      step: e.step,
      suffix: e.suffix,
      onChange: (v) => {
        Store.updateSettings({ goals: { ...Store.settings().goals, [e.key]: v } });
      },
    }));
    ed.appendChild(row);
  }
}

initShell({ title: 'Мои цели', tab: 'goals' });
skeleton(page, 3);
render().catch((e) => {
  console.warn('[goals]', e);
  page.innerHTML = `<div class="empty">${icon('alert')}<h3>Ошибка загрузки</h3><p>${esc(String(e.message || e))}</p></div>`;
});
