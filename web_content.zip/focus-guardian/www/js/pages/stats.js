/* Focus Guardian — страница «Статистика»: периоды, графики, сравнения, экспорт */

import { initShell, skeleton, noNativeState } from '../core/shell.js';
import { Store, dayKey, addDays, absorbNativeDay, localSeries } from '../core/storage.js';
import { Native } from '../core/native.js';
import { icon } from '../core/icons.js';
import { barChart, lineChart, donut, hbars } from '../core/charts.js';
import { toast, seg } from '../core/ui.js';
import { fmtMin, fmtDateHuman, esc, fmtClock, buildCsv, downloadBlob, seriesAvg, compareWithYesterday } from '../core/util.js';
import { weeklyReport } from '../core/assistant.js';

const page = document.getElementById('page');
const PALETTE = ['#8B7CFF', '#38C6FF', '#5DE29A', '#FFC46B', '#FF6B7E', '#7FB0FF', '#C58BFF', '#6EE7B7'];

let period = '7';
let cachedSeries = null;

const PERIODS = [
  { value: 'today', label: 'Сегодня' },
  { value: 'yesterday', label: 'Вчера' },
  { value: '7', label: '7 дней' },
  { value: '30', label: '30 дней' },
  { value: '90', label: '90 дней' },
  { value: 'all', label: 'Всё время' },
];

function daysOfPeriod() {
  if (period === 'today' || period === 'yesterday') return 1;
  if (period === '7') return 7;
  if (period === '30') return 30;
  if (period === '90') return 90;
  return Math.max(7, Math.min(366, Math.round((Date.now() - (Store.get('meta.created', Date.now()))) / 86400000) + 1));
}

async function getSeries(days) {
  const r = await Native.dailySeries(days);
  if (r.ok && r.series) {
    // синхронизировать в локальную историю для офлайн-просмотра
    const today = dayKey();
    for (const s of r.series) {
      if (s.date && s.totalMin > 0) {
        const cur = Store.get(`history.days.${s.date}`, null);
        if (!cur || s.totalMin !== cur.totalMin) {
          Store.updateDay(s.date, { totalMin: Math.round(s.totalMin), launches: s.launches || (cur?.launches || 0), unlocks: Math.max(s.unlocks || 0, cur?.unlocks || 0) });
        }
      }
    }
    if (r.series.length && r.series[r.series.length - 1].date === today) {
      // сегодня — подмешать живые данные
      const u = await Native.usageToday();
      if (u.ok) absorbNativeDay(today, u);
      const t = Store.day(today);
      r.series[r.series.length - 1].totalMin = Math.round(t.totalMin);
      r.series[r.series.length - 1].unlocks = t.unlocks;
      r.series[r.series.length - 1].restMin = t.restMin;
      r.series[r.series.length - 1].breaks = t.breaks;
    }
    return r.series;
  }
  return localSeries(days);
}

async function topAppsInRange(fromTs, toTs) {
  const r = await Native.usageRange(fromTs, toTs);
  if (r.ok && r.byApp) {
    return Object.entries(r.byApp)
      .filter(([pkg]) => pkg !== 'com.focusguardian.app')
      .map(([pkg, v]) => ({ pkg, label: pkg.split('.').pop(), timeMin: v.timeMin || 0, launches: v.launches || 0 }))
      .sort((a, b) => b.timeMin - a.timeMin);
  }
  // локальный фоллбэк: суммируем byApp по дням
  const agg = {};
  const today = dayKey();
  const days = daysOfPeriod();
  for (let i = 0; i < days; i++) {
    const d = Store.get(`history.days.${addDays(today, -i)}`, null);
    if (d?.byApp) for (const [pkg, v] of Object.entries(d.byApp)) agg[pkg] = (agg[pkg] || 0) + (v.timeMin || 0);
  }
  return Object.entries(agg).map(([pkg, timeMin]) => ({ pkg, label: pkg.split('.').pop(), timeMin })).sort((a, b) => b.timeMin - a.timeMin);
}

async function render() {
  const s = Store.settings();
  const days = daysOfPeriod();
  const series = cachedSeries || await getSeries(days);
  cachedSeries = null;

  const today = Store.day(dayKey());
  const withData = series.filter((d) => d.totalMin > 0);
  const avg = withData.length ? seriesAvg(withData) : 0;
  const totalUnlocks = series.reduce((a, d) => a + (d.unlocks > 0 ? d.unlocks : 0), 0);
  const totalRest = series.reduce((a, d) => a + (d.restMin || 0), 0);
  const exceededCount = series.reduce((a, d) => a + ((Store.get(`history.days.${d.date}`, {})?.exceeded || []).length), 0);
  const bestDay = withData.length ? withData.reduce((a, b) => (a.totalMin <= b.totalMin ? a : b)) : null;
  const longestOffline = series.reduce((a, d) => Math.max(a, Store.get(`history.days.${d.date}`, {})?.longestOfflineMin || 0), 0);

  const fromTs = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate()).getTime() - (days - 1) * 86400000;
  const toTs = Date.now();
  const top = await topAppsInRange(fromTs, toTs);

  const labels = series.map((d) => {
    const dt = new Date(d.date.split('-').join('-'));
    const [, m, dd] = d.date.split('-');
    return days <= 10 ? `${Number(dd)}` : `${Number(dd)}.${m}`;
  });

  const report = weeklyReport(series);

  page.innerHTML = `
    <div id="periodSeg" style="margin-bottom:14px"></div>

    <div class="kpi-grid" style="margin-bottom:14px">
      <div class="kpi"><div class="k-label">${icon('clock')} Средний экран</div><div class="k-value num">${avg ? fmtMin(avg) : '—'}</div><div class="k-sub">${withData.length ? `за ${withData.length} дн.` : 'нет данных'}</div></div>
      <div class="kpi"><div class="k-label">${icon('phone')} Разблокировки</div><div class="k-value num">${totalUnlocks || '—'}</div><div class="k-sub">суммарно за период</div></div>
      <div class="kpi"><div class="k-label">${icon('coffee')} Время отдыха</div><div class="k-value num">${totalRest ? fmtMin(totalRest) : '—'}</div><div class="k-sub">без телефона</div></div>
      <div class="kpi"><div class="k-label">${icon('alert')} Превышения лимитов</div><div class="k-value num">${exceededCount || 0}</div><div class="k-sub">за период</div></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('chart')} Динамика экранного времени</div>
      <div class="chart-box"><canvas id="chBar"></canvas></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('grid')} Распределение по приложениям</div>
      <div class="chart-box"><canvas id="chDonut"></canvas></div>
      <div id="topHbars" style="margin-top:12px"></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('phone')} Разблокировки по дням</div>
      <div class="chart-box"><canvas id="chLine"></canvas></div>
    </div>

    <div class="card">
      <div class="card-title">${icon('trophy')} Итоги периода</div>
      <div class="stat-line"><span class="s-label">Самый продуктивный день</span><span class="s-value num">${bestDay ? `${fmtDateHuman(bestDay.date)} · ${fmtMin(bestDay.totalMin)}` : '—'}</span></div>
      <div class="stat-line"><span class="s-label">Самый длинный период без телефона</span><span class="s-value num">${longestOffline ? fmtMin(longestOffline) : '—'}</span></div>
      <div class="stat-line"><span class="s-label">Самое используемое приложение</span><span class="s-value">${top.length ? `${esc(top[0].label)} · ${fmtMin(top[0].timeMin)}` : '—'}</span></div>
    </div>

    ${report ? `
    <div class="card">
      <div class="card-title">${icon('calendar')} Сравнение недель</div>
      <table class="compare-table">
        <tr><th>Показатель</th><th>Эта неделя</th><th>Прошлая</th><th>Δ</th></tr>
        <tr><td>Средний экран</td><td>${fmtMin(report.avg)}</td><td>${report.avgPrev != null ? fmtMin(report.avgPrev) : '—'}</td><td class="${(report.delta || 0) >= 0 ? 'delta-pos' : 'delta-neg'}">${report.delta != null ? (report.delta >= 0 ? `−${fmtMin(report.delta)}` : `+${fmtMin(-report.delta)}`) : '—'}</td></tr>
        <tr><td>Разблокировки (в день)</td><td>${report.unlockAvg}</td><td>—</td><td></td></tr>
        <tr><td>Лучший день</td><td colspan="2">${report.bestDay ? `${fmtDateHuman(report.bestDay.date)} · ${fmtMin(report.bestDay.totalMin)}` : '—'}</td><td></td></tr>
        <tr><td>Самый загруженный</td><td colspan="2">${report.worstDay ? `${fmtDateHuman(report.worstDay.date)} · ${fmtMin(report.worstDay.totalMin)}` : '—'}</td><td></td></tr>
      </table>
    </div>` : ''}

    <div class="card">
      <div class="card-title">${icon('download')} Экспорт</div>
      <div class="row-wrap">
        <button class="btn ghost" id="expCsv">${icon('download')}<span>CSV</span></button>
        <button class="btn ghost" id="expJson">${icon('download')}<span>JSON всей статистики</span></button>
      </div>
      <div class="card-sub">Файл сохраняется в «Загрузки» (на устройстве) или скачивается в браузере.</div>
    </div>
  `;

  /* сегмент периода */
  seg(page.querySelector('#periodSeg'), PERIODS, period, async (v) => {
    period = v;
    cachedSeries = null;
    await rerender();
  });

  /* графики */
  if (withData.length) {
    barChart(page.querySelector('#chBar'), {
      values: series.map((d) => Math.round(d.totalMin)),
      labels,
      goal: days > 1 ? s.goals.screenMin : null,
      markLast: period === 'today' || period === 'yesterday',
      height: 190,
    });
    lineChart(page.querySelector('#chLine'), {
      values: series.map((d) => Math.max(0, d.unlocks || 0)),
      labels,
      height: 160,
    });
  } else {
    page.querySelector('#chBar').parentElement.innerHTML = '<div class="chart-empty">Нет данных за период</div>';
    page.querySelector('#chLine').parentElement.innerHTML = '<div class="chart-empty">Нет данных за период</div>';
  }

  const segs = top.slice(0, 6).map((a, i) => ({ value: a.timeMin, color: PALETTE[i % PALETTE.length], label: a.label }));
  if (segs.length) {
    donut(page.querySelector('#chDonut'), {
      segments: segs,
      centerTitle: fmtMin(top.reduce((a, b) => a + b.timeMin, 0)),
      centerSub: 'суммарно',
    });
    hbars(page.querySelector('#topHbars'), top.slice(0, 6).map((a) => ({
      label: a.label,
      value: a.timeMin,
      max: top[0].timeMin,
      sub: fmtMin(a.timeMin),
    })));
  } else {
    page.querySelector('#chDonut').parentElement.innerHTML = '<div class="chart-empty">Нет данных за период</div>';
    page.querySelector('#topHbars').innerHTML = '';
  }

  /* экспорт */
  page.querySelector('#expCsv').addEventListener('click', async () => {
    const csv = buildCsv(series);
    const name = `focus-guardian-stats-${dayKey()}.csv`;
    const r = await Native.exportFile(name, 'text/csv', csv);
    if (!r.ok) downloadBlob(name, 'text/csv', csv);
    else toast(`Сохранено: ${r.path || name}`, 'ok', 4000);
  });
  page.querySelector('#expJson').addEventListener('click', async () => {
    const json = Store.exportAll();
    const name = `focus-guardian-backup-${dayKey()}.json`;
    const r = await Native.exportFile(name, 'application/json', json);
    if (!r.ok) downloadBlob(name, 'application/json', json);
    else toast(`Сохранено: ${r.path || name}`, 'ok', 4000);
  });
}

async function rerender() {
  skeleton(page, 3);
  await render();
}

initShell({ title: 'Статистика', tab: 'stats' });
skeleton(page, 3);
render().catch((e) => {
  console.warn('[stats]', e);
  page.innerHTML = `<div class="empty">${icon('alert')}<h3>Ошибка загрузки</h3><p>${esc(String(e.message || e))}</p></div>`;
});
