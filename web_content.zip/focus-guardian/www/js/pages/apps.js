/* Focus Guardian — страница «Приложения»: мониторинг, лимиты, блокировки */

import { initShell, skeleton, noNativeState } from '../core/shell.js';
import { Store, dayKey, absorbNativeDay } from '../core/storage.js';
import { Native } from '../core/native.js';
import { icon } from '../core/icons.js';
import { toast, sheet, confirmDialog, seg, switchEl, emptyState } from '../core/ui.js';
import { fmtMin, fmtClock, esc, fmtDurSec } from '../core/util.js';
import { refreshNativeRules } from '../core/sessions.js';

const page = document.getElementById('page');

const CATS = [
  { id: 'social', label: 'Соцсети' },
  { id: 'video', label: 'Видео' },
  { id: 'games', label: 'Игры' },
  { id: 'other', label: 'Прочее' },
];

let apps = [];               // [{pkg,label,system}]
let usageByApp = {};         // pkg -> {timeMin, launches, lastTs}
let iconMap = {};
let sortMode = 'time';
let searchQuery = '';
let permOk = false;

function catOf(pkg) {
  const r = Store.rule(pkg);
  if (r?.category) return r.category;
  const label = (apps.find((a) => a.pkg === pkg)?.label || '').toLowerCase();
  if (/telegram|vk|instagram|whatsapp|tiktok|viber|soc/.test(pkg + label)) return 'social';
  if (/youtube|netflix|video|kinopoisk|music/.test(pkg + label)) return 'video';
  if (/game/.test(pkg + label)) return 'games';
  return 'other';
}

function catLabel(id) {
  return (CATS.find((c) => c.id === id) || {}).label || 'Прочее';
}

function isBlocked(rule) {
  if (!rule) return false;
  const now = Date.now();
  if (rule.blockedAllDay) return true;
  if ((rule.blockUntilTs || 0) > now) return true;
  if (rule.scheduleStart && rule.scheduleEnd) {
    const d = new Date();
    const m = d.getHours() * 60 + d.getMinutes();
    const [sh, sm] = rule.scheduleStart.split(':').map(Number);
    const [eh, em] = rule.scheduleEnd.split(':').map(Number);
    const s = sh * 60 + sm, e = eh * 60 + em;
    const inWin = s < e ? (m >= s && m < e) : (m >= s || m < e);
    if (inWin) return true;
  }
  return false;
}

function limitExceeded(pkg) {
  const rule = Store.rule(pkg);
  if (!rule?.limitMin || !usageByApp[pkg]) return false;
  return usageByApp[pkg].timeMin >= rule.limitMin && Store.settings().mode !== 'soft';
}

async function loadData() {
  const [perm, usage, appsRes] = await Promise.all([
    Native.permissions(),
    Native.usageToday(),
    Native.installedApps(),
  ]);
  permOk = !!perm.ok && !!perm.usageAccess;
  if (usage.ok) {
    absorbNativeDay(dayKey(), usage);
    usageByApp = usage.byApp || {};
  }
  if (appsRes.ok) {
    apps = (appsRes.apps || []).filter((a) => a.pkg !== 'com.focusguardian.app');
    const withUsage = new Set(Object.keys(usageByApp));
    apps.sort((a, b) => {
      const au = usageByApp[a.pkg]?.timeMin || 0;
      const bu = usageByApp[b.pkg]?.timeMin || 0;
      return bu - au;
    });
    // иконки — пакетами по 40
    const want = apps.slice(0, 40).map((a) => a.pkg);
    const ic = await Native.appIcons(want);
    if (ic.ok) iconMap = ic.icons || {};
  }
  return { permOk, usageOk: usage.ok, appsOk: appsRes.ok };
}

function filteredApps() {
  let list = apps.filter((a) => {
    if (searchQuery && !a.label.toLowerCase().includes(searchQuery.toLowerCase()) && !a.pkg.includes(searchQuery.toLowerCase())) return false;
    return true;
  });
  if (sortMode === 'time') {
    list = list.slice().sort((a, b) => (usageByApp[b.pkg]?.timeMin || 0) - (usageByApp[a.pkg]?.timeMin || 0));
  } else if (sortMode === 'launches') {
    list = list.slice().sort((a, b) => (usageByApp[b.pkg]?.launches || 0) - (usageByApp[a.pkg]?.launches || 0));
  } else if (sortMode === 'name') {
    list = list.slice().sort((a, b) => a.label.localeCompare(b.label, 'ru'));
  } else if (sortMode === 'limits') {
    list = list.slice().sort((a, b) => {
      const ax = limitExceeded(a.pkg) ? 2 : (Store.rule(a.pkg)?.limitMin ? 1 : 0);
      const bx = limitExceeded(b.pkg) ? 2 : (Store.rule(b.pkg)?.limitMin ? 1 : 0);
      return bx - ax;
    });
  }
  return list;
}

function appIconEl(pkg, label) {
  if (iconMap[pkg]) {
    return `<img class="app-icon" src="${iconMap[pkg]}" alt="" loading="lazy">`;
  }
  const letter = esc((label || '?')[0].toUpperCase());
  return `<div class="app-icon" style="display:grid;place-items:center;font-weight:800;color:var(--accent)">${letter}</div>`;
}

function renderList() {
  const listBox = page.querySelector('#appList');
  const list = filteredApps();
  if (!list.length) {
    listBox.innerHTML = '';
    listBox.appendChild(emptyState({ iconName: 'search', title: 'Ничего не найдено', text: 'Попробуй изменить запрос или фильтр.' }));
    return;
  }
  listBox.innerHTML = list.slice(0, 300).map((a) => {
    const u = usageByApp[a.pkg];
    const rule = Store.rule(a.pkg);
    const used = u?.timeMin || 0;
    const limit = rule?.limitMin || 0;
    const pct = limit ? Math.min(100, (used / limit) * 100) : 0;
    const blocked = isBlocked(rule);
    const exceeded = limitExceeded(a.pkg);
    const cls = pct >= 100 ? 'danger' : pct >= 75 ? 'warn' : '';
    return `
    <div class="list-item app-row" data-pkg="${esc(a.pkg)}">
      ${appIconEl(a.pkg, a.label)}
      <div class="a-main">
        <div class="a-name">${esc(a.label)} ${blocked ? '<span class="badge danger">Заблокировано</span>' : ''} ${exceeded ? '<span class="badge warn">Лимит превышен</span>' : ''}</div>
        <div class="a-meta">${u ? `${u.launches || 0} запусков · было ${u.lastTs ? fmtClock(u.lastTs) : '—'}` : 'нет данных за сегодня'} · ${catLabel(catOf(a.pkg))}</div>
        ${limit ? `<div class="progress-track a-progress"><div class="progress-fill ${cls}" style="width:${pct}%"></div></div>` : ''}
      </div>
      <div class="a-right">
        <div class="a-time num">${u ? fmtMin(used) : '—'}</div>
        <div class="a-limit">${limit ? `лимит ${fmtMin(limit)}` : 'без лимита'}</div>
      </div>
    </div>`;
  }).join('');

  listBox.querySelectorAll('.app-row').forEach((row) => {
    row.addEventListener('click', () => openAppSheet(row.dataset.pkg));
  });
}

function renderHeaderInfo(usageOk) {
  const info = page.querySelector('#appsInfo');
  const rulesCount = Object.keys(Store.rules()).length;
  const total = Object.entries(usageByApp).reduce((a, [, v]) => a + (v.timeMin || 0), 0);
  info.innerHTML = `
    <div class="kpi-grid" style="margin-bottom:14px">
      <div class="kpi"><div class="k-label">${icon('clock')} Всего сегодня</div><div class="k-value num">${usageOk ? fmtMin(total) : '—'}</div><div class="k-sub">по всем приложениям</div></div>
      <div class="kpi"><div class="k-label">${icon('shield')} Правил настроено</div><div class="k-value num">${rulesCount}</div><div class="k-sub">лимитов и блокировок</div></div>
    </div>`;
}

function renderToolbar() {
  seg(page.querySelector('#sortSeg'), [
    { value: 'time', label: 'По времени' },
    { value: 'launches', label: 'По запускам' },
    { value: 'name', label: 'По названию' },
    { value: 'limits', label: 'По лимитам' },
  ], sortMode, (v) => { sortMode = v; renderList(); });
}

function openAppSheet(pkg) {
  const app = apps.find((a) => a.pkg === pkg);
  const label = app?.label || pkg.split('.').pop();
  const rule = Store.rule(pkg) || {};
  const u = usageByApp[pkg];
  const used = u?.timeMin || 0;
  const limit = rule.limitMin || 0;
  const pct = limit ? Math.min(100, (used / limit) * 100) : 0;

  const sh = sheet({
    title: label,
    body: `
      <div class="row" style="margin-bottom:12px">
        ${appIconEl(pkg, label)}
        <div class="grow">
          <div class="tiny muted">${esc(pkg)}</div>
          <div style="font-weight:700;margin-top:2px">Сегодня: ${u ? fmtMin(used) : 'нет данных'} · ${u ? `${u.launches || 0} запусков` : ''}</div>
        </div>
      </div>
      ${limit ? `<div class="progress-track" style="margin-bottom:14px"><div class="progress-fill" style="width:${pct}%"></div></div>` : ''}

      <div class="field">
        <label>Дневной лимит</label>
        <div class="chips" id="limitChips">
          ${[0, 15, 30, 60, 90, 120].map((v) => `<button class="chip ${limit === v ? 'active' : ''}" data-v="${v}">${v === 0 ? 'Без лимита' : fmtMin(v)}</button>`).join('')}
        </div>
        <div class="row" style="margin-top:10px">
          <input type="number" class="input" id="customLimit" min="1" max="720" placeholder="Свой лимит, мин" style="flex:1" ${limit && ![0, 15, 30, 60, 90, 120].includes(limit) ? `value="${limit}"` : ''}>
          <button class="btn small" id="applyCustom"><span>Задать</span></button>
        </div>
      </div>

      <div class="field">
        <label>Категория (для целей по типам приложений)</label>
        <div class="chips" id="catChips">
          ${CATS.map((c) => `<button class="chip ${catOf(pkg) === c.id ? 'active' : ''}" data-v="${c.id}">${c.label}</button>`).join('')}
        </div>
      </div>

      <div class="field">
        <label>Блокировка</label>
        <div class="chips">
          <button class="chip" id="blockDay">До конца дня</button>
          <button class="chip" id="blockTemp">На заданное время</button>
          ${isBlocked(rule) ? '<button class="chip active" id="unblock">Снять блокировку</button>' : ''}
        </div>
        <div class="row hidden" id="tempRow" style="margin-top:10px">
          <input type="time" class="input" id="tempUntil" style="flex:1">
          <button class="btn small" id="applyTemp"><span>Заблокировать</span></button>
        </div>
      </div>

      <div class="field">
        <label>Расписание блокировки (необязательно)</label>
        <div class="row">
          <input type="time" class="input" id="schedFrom" value="${rule.scheduleStart || ''}" style="flex:1">
          <span class="muted">—</span>
          <input type="time" class="input" id="schedTo" value="${rule.scheduleEnd || ''}" style="flex:1">
        </div>
        <div class="tiny muted" style="margin-top:6px">Например, 22:00 — 07:00. Оставьте пустым, чтобы не использовать.</div>
      </div>

      <div class="setting-row">
        <div class="s-text"><div class="s-title">Правило включено</div><div class="s-desc">Отключите, чтобы временно приостановить лимит и блокировки</div></div>
        <span id="ruleEnabled"></span>
      </div>

      ${rule && Object.keys(rule).length ? '<button class="btn danger block small" id="delRule" style="margin-top:14px">Удалить правило</button>' : ''}`,
    actions: [{ label: 'Готово', class: '', icon: 'check', onClick: (close) => close() }],
  });

  const root = sh.el;

  /* лимиты */
  root.querySelector('#limitChips').addEventListener('click', async (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    const v = Number(chip.dataset.v);
    if (v === 0) Store.removeRule(pkg);
    else Store.setRule(pkg, { limitMin: v, enabled: rule.enabled !== false, category: catOf(pkg) });
    await refreshNativeRules();
    toast(v === 0 ? 'Лимит удалён' : `Лимит: ${fmtMin(v)} в день`, 'ok');
    sh.close();
    renderList();
    renderHeaderInfo(true);
  });

  root.querySelector('#applyCustom').addEventListener('click', async () => {
    const v = Number(root.querySelector('#customLimit').value);
    if (!v || v < 1 || v > 720) return toast('Введите лимит от 1 до 720 минут', 'warn');
    Store.setRule(pkg, { limitMin: Math.round(v), enabled: rule.enabled !== false, category: catOf(pkg) });
    await refreshNativeRules();
    toast(`Лимит: ${fmtMin(v)} в день`, 'ok');
    sh.close();
    renderList();
  });

  /* категории */
  root.querySelector('#catChips').addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    Store.setRule(pkg, { category: chip.dataset.v });
    root.querySelectorAll('#catChips .chip').forEach((c) => c.classList.toggle('active', c === chip));
  });

  /* блокировки */
  const strict = Store.settings().mode === 'strict';
  root.querySelector('#blockDay').addEventListener('click', async () => {
    const ok = await confirmDialog({
      title: 'Заблокировать до конца дня?',
      text: `${label} будет недоступен до полуночи. Снять блокировку можно будет только с дополнительным подтверждением.`,
      okLabel: 'Заблокировать',
      danger: true,
      hold: strict,
    });
    if (!ok) return;
    Store.setRule(pkg, { blockedAllDay: true, enabled: rule.enabled !== false, category: catOf(pkg) });
    await refreshNativeRules();
    toast(`${label} заблокирован до конца дня`, 'ok');
    sh.close();
    renderList();
  });

  root.querySelector('#blockTemp').addEventListener('click', () => {
    root.querySelector('#tempRow').classList.toggle('hidden');
  });
  root.querySelector('#applyTemp').addEventListener('click', async () => {
    const t = root.querySelector('#tempUntil').value;
    if (!t) return toast('Выберите время окончания', 'warn');
    const [h, m] = t.split(':').map(Number);
    const d = new Date();
    const until = new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, m).getTime();
    if (until <= Date.now()) return toast('Укажите время в будущем', 'warn');
    Store.setRule(pkg, { blockUntilTs: until, enabled: rule.enabled !== false, category: catOf(pkg) });
    await refreshNativeRules();
    toast(`${label} заблокирован до ${t}`, 'ok');
    sh.close();
    renderList();
  });

  const unblockBtn = root.querySelector('#unblock');
  if (unblockBtn) {
    unblockBtn.addEventListener('click', async () => {
      const ok = await confirmDialog({
        title: 'Снять блокировку?',
        text: 'Приложение снова станет доступно. Остаток дневного лимита сохранится.',
        okLabel: 'Снять блокировку',
        hold: strict || rule.blockedAllDay,
      });
      if (!ok) return;
      Store.setRule(pkg, { blockedAllDay: false, blockUntilTs: 0 });
      await refreshNativeRules();
      toast('Блокировка снята', 'ok');
      sh.close();
      renderList();
    });
  }

  /* расписание */
  const saveSched = async () => {
    const from = root.querySelector('#schedFrom').value;
    const to = root.querySelector('#schedTo').value;
    if (from && to) {
      Store.setRule(pkg, { scheduleStart: from, scheduleEnd: to, enabled: rule.enabled !== false, category: catOf(pkg) });
      await refreshNativeRules();
      toast(`Расписание блокировки: ${from}–${to}`, 'ok');
      renderList();
    } else if (rule.scheduleStart || rule.scheduleEnd) {
      Store.setRule(pkg, { scheduleStart: null, scheduleEnd: null });
      await refreshNativeRules();
    }
  };
  root.querySelector('#schedFrom').addEventListener('change', saveSched);
  root.querySelector('#schedTo').addEventListener('change', saveSched);

  /* включение правила */
  const enabledBox = root.querySelector('#ruleEnabled');
  enabledBox.appendChild(switchEl(rule.enabled !== false, async (v) => {
    Store.setRule(pkg, { enabled: v });
    await refreshNativeRules();
  }));

  const delBtn = root.querySelector('#delRule');
  if (delBtn) {
    delBtn.addEventListener('click', async () => {
      const ok = await confirmDialog({ title: 'Удалить правило?', text: 'Лимит, расписание и блокировка будут сняты.', okLabel: 'Удалить', danger: true });
      if (!ok) return;
      Store.removeRule(pkg);
      await refreshNativeRules();
      toast('Правило удалено', 'ok');
      sh.close();
      renderList();
    });
  }
}

async function render() {
  const res = await loadData();

  if (!res.appsOk && !Native.demoActive()) {
    noNativeState(page, {
      text: 'Список установленных приложений приходит из нативного модуля Android. Соберите APK (см. docs/BUILD.md) или включите демо-данные в настройках для проверки интерфейса.',
    });
    return;
  }
  if (!res.usageOk && !Native.demoActive()) {
    page.innerHTML = `
      <div class="banner warn">${icon('alert')}<div class="grow"><b>Нет доступа к статистике использования</b><br>Список приложений появится, но времена использования недоступны без разрешения «Доступ к данным об использовании».</div></div>
      <button class="btn block" id="fixPerm">${icon('shield')}<span>Открыть настройки доступа</span></button>
      <div id="appsInfo"></div>
      <div class="apps-toolbar">
        <div class="search-box">${icon('search')}<input id="searchInput" type="search" placeholder="Поиск приложений"></div>
      </div>
      <div id="sortSeg" style="margin-bottom:6px"></div>
      <div id="appList"></div>`;
    page.querySelector('#fixPerm').addEventListener('click', async () => {
      const r = await Native.openUsageAccess();
      if (!r.ok) toast('Откройте: Настройки → Приложения → Special app access → Usage access', 'warn', 5000);
    });
    bindToolbar();
    renderToolbar();
    renderList();
    return;
  }

  page.innerHTML = `
    <div id="appsInfo"></div>
    <div class="apps-toolbar">
      <div class="search-box">${icon('search')}<input id="searchInput" type="search" placeholder="Поиск приложений"></div>
    </div>
    <div id="sortSeg" style="margin-bottom:6px"></div>
    <div id="appList"></div>
    <div class="tiny muted center" style="margin-top:8px">Коснитесь приложения, чтобы настроить лимит, расписание и блокировку</div>
  `;

  bindToolbar();
  renderToolbar();
  renderHeaderInfo(res.usageOk);
  renderList();
}

function bindToolbar() {
  const input = page.querySelector('#searchInput');
  input.addEventListener('input', () => {
    searchQuery = input.value.trim();
    renderList();
  });
}

initShell({ title: 'Приложения', tab: 'apps' });
skeleton(page, 2);
render().catch((e) => {
  console.warn('[apps]', e);
  page.innerHTML = `<div class="empty">${icon('alert')}<h3>Ошибка загрузки</h3><p>${esc(String(e.message || e))}</p></div>`;
});
