/* Focus Guardian — полноэкранный отдых глаз (20-20-20) и плавающий баннер напоминания */

import { icon } from './icons.js';
import { Bus, recordEyeBreak } from './engine.js';
import { QUOTES } from './motivation.js';
import { toast } from './ui.js';
import { Store } from './storage.js';

const INSTRUCTIONS = [
  'Посмотри в окно. Дай глазам отдохнуть от близкого расстояния.',
  'Найди самый дальний объект, который видишь. Смотри на него спокойно.',
  'Моргай медленно и мягко. Пусть глаза отдохнут от экрана.',
  'Расслабь плечи и лицо. Взгляд вдаль снимает напряжение.',
  'Посмотри на что-то зелёное или на линию горизонта — им проще всего.',
];

let overlay = null;
let banner = null;
let bannerTimer = null;

function pickMotivation() {
  const all = [...QUOTES.vision, ...QUOTES.breaks];
  return all[Math.floor(Math.random() * all.length)];
}

/** Полноэкранный отдых глаз */
export function showEyeRest({ seconds = 20, onComplete = null } = {}) {
  if (overlay) return;
  const endTs = Date.now() + seconds * 1000;

  overlay = document.createElement('div');
  overlay.className = 'rest-overlay';
  overlay.innerHTML = `
    <div class="ro-timer">
      <svg viewBox="0 0 250 250" width="250" height="250">
        <circle cx="125" cy="125" r="112" fill="none" stroke="rgba(148,163,204,.15)" stroke-width="13"/>
        <circle class="ro-arc" cx="125" cy="125" r="112" fill="none" stroke="url(#roGrad)" stroke-width="13"
          stroke-linecap="round" stroke-dasharray="${2 * Math.PI * 112}" stroke-dashoffset="0" transform="rotate(-90 125 125)"/>
        <defs>
          <linearGradient id="roGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stop-color="#8B7CFF"/><stop offset="1" stop-color="#38C6FF"/>
          </linearGradient>
        </defs>
      </svg>
      <div class="ring-center">
        <div class="ro-count" style="font-size:56px;font-weight:800;color:#E9EEFA">20</div>
        <div class="ro-sub" style="font-size:12px;color:#9AA7C7">секунд</div>
      </div>
    </div>
    <div class="ro-title">Отдых для глаз</div>
    <div class="ro-instruction"></div>
    <div class="ro-motivation">${pickMotivation()}</div>
    <button class="btn ghost small" style="margin-top:26px">Пропустить перерыв</button>`;

  const arc = overlay.querySelector('.ro-arc');
  const count = overlay.querySelector('.ro-count');
  const instruction = overlay.querySelector('.ro-instruction');
  const skipBtn = overlay.querySelector('button');
  const circ = 2 * Math.PI * 112;
  let insIdx = 0;
  instruction.textContent = INSTRUCTIONS[0];
  const insTimer = setInterval(() => {
    insIdx = (insIdx + 1) % INSTRUCTIONS.length;
    instruction.style.opacity = '0';
    setTimeout(() => {
      instruction.textContent = INSTRUCTIONS[insIdx];
      instruction.style.opacity = '1';
    }, 350);
  }, 4500);

  const finish = (skipped) => {
    clearInterval(insTimer);
    overlay.remove();
    overlay = null;
    if (!skipped) {
      recordEyeBreak(seconds);
      toast('Перерыв завершён. Продолжай день с комфортом', 'ok');
      Bus.dispatchEvent(new CustomEvent('break-done', { detail: { seconds } }));
    }
    if (onComplete) onComplete(!skipped);
  };

  skipBtn.addEventListener('click', () => finish(true));

  const tick = () => {
    if (!overlay) return;
    const left = Math.max(0, (endTs - Date.now()) / 1000);
    count.textContent = String(Math.ceil(left));
    arc.setAttribute('stroke-dashoffset', String(circ * (1 - left / seconds)));
    if (left <= 0) return finish(false);
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
  document.body.appendChild(overlay);
}

/** Плавающий баннер «пора отдохнуть» */
function showBanner() {
  if (banner || overlay) return;
  const s = Store.settings();
  banner = document.createElement('div');
  banner.className = 'eye-banner';
  banner.innerHTML = `
    <div class="eb-title">${icon('eye')} Пора дать глазам отдохнуть</div>
    <div class="eb-text">Ты смотришь в экран уже ${s.eye.intervalMin} минут. Взгляд вдаль на ${s.eye.durationSec} секунд снимет напряжение.</div>
    <div class="eb-actions">
      <button class="btn small" data-a="rest">${icon('eye')}<span>Отдохнуть</span></button>
      <button class="btn ghost small" data-a="snooze"><span>Позже</span></button>
    </div>`;
  banner.querySelector('[data-a="rest"]').addEventListener('click', () => {
    hideBanner();
    showEyeRest({ seconds: s.eye.durationSec });
  });
  banner.querySelector('[data-a="snooze"]').addEventListener('click', () => {
    hideBanner();
    toast('Напомним позже', 'info');
  });
  document.body.appendChild(banner);
  bannerTimer = setTimeout(hideBanner, 60000);
}

function hideBanner() {
  clearTimeout(bannerTimer);
  if (banner) {
    banner.remove();
    banner = null;
  }
}

/** Подписка на события движка — вызывается из shell.js один раз на страницу */
export function initEyeRestListener() {
  Bus.addEventListener('eye-rest-due', () => {
    const s = Store.settings();
    if (s.eye.autoFullscreen) showEyeRest({ seconds: s.eye.durationSec });
    else showBanner();
  });
  Bus.addEventListener('visibility', (e) => {
    if (!e.detail.visible) hideBanner();
  });
}
