/* Focus Guardian — общий каркас страницы: тема, шапка, навигация, запуск движка */

import { Store } from './storage.js';
import { icon } from './icons.js';
import { startEngine, Bus } from './engine.js';
import { initEyeRestListener } from './eyerest.js';
import { syncConfigToNative, Native } from './native.js';
import { toast } from './ui.js';
import { esc } from './util.js';

const NAV = [
  { id: 'home', href: 'index.html', iconName: 'home', label: 'Главная' },
  { id: 'apps', href: 'apps.html', iconName: 'grid', label: 'Приложения' },
  { id: 'focus', href: 'focus.html', iconName: 'target', label: 'Фокус' },
  { id: 'stats', href: 'stats.html', iconName: 'chart', label: 'Статистика' },
  { id: 'more', href: 'more.html', iconName: 'dots', label: 'Ещё' },
];

const MORE_TABS = ['more', 'health', 'rest', 'goals', 'tips', 'settings', 'permissions'];

export function applyTheme() {
  const s = Store.settings();
  const theme = s.theme === 'auto'
    ? (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
    : s.theme;
  document.documentElement.dataset.theme = theme;
  document.documentElement.dataset.accent = s.accent || 'violet';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = theme === 'light' ? '#F2F4FB' : '#0B1020';
  return theme;
}

function injectHeader(title, back) {
  const header = document.getElementById('appHeader');
  if (!header) return;
  const demo = Native.demoActive();
  header.innerHTML = `
    ${back ? `<button class="header-back" id="backBtn" aria-label="Назад">${icon('back')}</button>` : `<span style="width:2px"></span>`}
    <div class="header-title">${esc(title)}</div>
    ${demo ? '<span class="demo-chip">ДЕМО</span>' : ''}`;
  const backBtn = document.getElementById('backBtn');
  if (backBtn) backBtn.addEventListener('click', () => history.back());
}

function injectNav(active) {
  const nav = document.getElementById('bottomNav');
  if (!nav) return;
  const isMore = MORE_TABS.includes(active);
  nav.innerHTML = `<div class="bottom-nav-inner">${NAV.map((n) => {
    const isActive = n.id === active || (n.id === 'more' && isMore);
    return `<a class="nav-item ${isActive ? 'active' : ''}" href="${n.href}">${icon(n.iconName)}<span>${n.label}</span></a>`;
  }).join('')}</div>`;
}

/** Загрузка каркаса страницы — вызывается каждой страницей */
export function initShell({ title = 'Focus Guardian', back = false, tab = null } = {}) {
  applyTheme();
  injectHeader(title, back);
  injectNav(tab);
  startEngine();
  initEyeRestListener();
  syncConfigToNative();

  window.addEventListener('unhandledrejection', (e) => {
    console.warn('[app] ошибка:', e.reason);
    toast('Произошла ошибка. Попробуйте повторить действие', 'error');
  });

  Bus.dispatchEvent(new CustomEvent('shell-ready', { detail: { tab } }));
}

/** Показать загрузочный скелет внутри контейнера */
export function skeleton(container, rows = 3) {
  container.innerHTML = Array.from({ length: rows }, (_, i) =>
    `<div class="skeleton" style="height:${i === 0 ? 220 : 90}px;margin-bottom:14px"></div>`
  ).join('');
}

/** Единая заглушка «нет данных без нативного модуля» */
export function noNativeState(container, { text = 'Реальная статистика появляется после сборки APK и выдачи разрешений Android.' } = {}) {
  container.innerHTML = `
    <div class="empty">
      ${icon('shield')}
      <h3>Нужны нативные данные</h3>
      <p>${esc(text)}</p>
      <button class="btn small" id="goPerms">${icon('shield')}<span>Открыть разрешения</span></button>
    </div>`;
  container.querySelector('#goPerms').addEventListener('click', () => {
    location.href = 'permissions.html';
  });
}
