/* Focus Guardian — достижения и серии дней */

import { Store, dayKey, addDays, localSeries } from './storage.js';
import { fmtMin } from './util.js';
import { focusStats } from './sessions.js';
import { toast } from './ui.js';

export const ACHIEVEMENTS = [
  { id: 'first_day', icon: 'star', title: 'Первый шаг', desc: 'Собраны первые данные об использовании' },
  { id: 'better_yesterday', icon: 'chart', title: 'Меньше вчера', desc: 'Экранное время ниже вчерашнего на 30+ минут' },
  { id: 'under_goal', icon: 'target', title: 'В пределах цели', desc: 'Сегодняшний экран уложился в дневную цель' },
  { id: 'rest_30', icon: 'coffee', title: 'Пауза 30 минут', desc: '30 минут подряд без телефона' },
  { id: 'rest_120', icon: 'leaf', title: 'Два часа тишины', desc: '2 часа подряд без телефона' },
  { id: 'breaks_done', icon: 'check', title: 'Все перерывы', desc: 'Выполнены все запланированные перерывы' },
  { id: 'limits_ok', icon: 'shield', title: 'Лимиты соблюдены', desc: 'Ни одного превышения лимита сегодня' },
  { id: 'focus_first', icon: 'target', title: 'Первый фокус', desc: 'Завершён первый сеанс концентрации' },
  { id: 'focus_10', icon: 'zap', title: 'Мастер фокуса', desc: '10 успешных сеансов концентрации' },
  { id: 'focus_5h', icon: 'clock', title: '5 часов в потоке', desc: 'Суммарно 5 часов концентрации' },
  { id: 'streak_3', icon: 'flame', title: 'Серия 3 дня', desc: 'Цели выполнены 3 дня подряд' },
  { id: 'streak_7', icon: 'trophy', title: 'Серия недели', desc: 'Цели выполнены 7 дней подряд' },
  { id: 'unlocks_low', icon: 'phone', title: 'Спокойный день', desc: 'Меньше 25 разблокировок экрана' },
  { id: 'night_ok', icon: 'moon', title: 'Телефон спит раньше', desc: 'Экранное время после начала сна — меньше 10 минут' },
];

function unlock(id) {
  if (!Store.get('history.achievements')[id]) {
    Store.set(`history.achievements.${id}`, Date.now());
    const a = ACHIEVEMENTS.find((x) => x.id === id);
    if (a) toast(`Достижение: ${a.title}`, 'ok', 4000);
  }
}

/** Обновляет серию «дней с выполненной целью по экрану» */
function updateStreak() {
  const s = Store.settings();
  const today = dayKey();
  const goal = s.goals.screenMin;
  let streak = 0;
  for (let i = 0; i < 400; i++) {
    const key = addDays(today, -i);
    const d = Store.get(`history.days.${key}`, null);
    if (!d || (d.totalMin || 0) <= 0) {
      if (i === 0) { /* сегодня ещё идёт — не прерываем серию */ break; }
      break;
    }
    if ((d.totalMin || 0) <= goal) streak += 1;
    else break;
  }
  const best = Math.max(streak, Store.get('history.streak.best', 0));
  Store.updateDay(today, {});
  Store.set('history.streak', { current: streak, best, updated: Date.now() });
  if (streak >= 3) unlock('streak_3');
  if (streak >= 7) unlock('streak_7');
  return streak;
}

/**
 * Оценивает состояние дня и разблокирует достижения.
 * ctx = { today, yesterday, live }
 */
export function evaluate(ctx = {}) {
  const s = Store.settings();
  const todayKey = dayKey();
  const today = ctx.today || Store.day(todayKey);
  const yesterdayKey = addDays(todayKey, -1);
  const yesterday = Store.get(`history.days.${yesterdayKey}`, null);
  const live = ctx.live || {};
  const focus = focusStats();

  if (today.totalMin > 0 || today.unlocks > 0) unlock('first_day');
  if (yesterday && yesterday.totalMin > 0 && today.totalMin > 0 && yesterday.totalMin - today.totalMin >= 30) unlock('better_yesterday');
  if (today.totalMin > 0 && today.totalMin <= s.goals.screenMin) unlock('under_goal');
  const restMax = Math.max(live.longestOfflineMin || 0, today.longestOfflineMin || 0);
  if (restMax >= 30) unlock('rest_30');
  if (restMax >= 120) unlock('rest_120');
  if (today.breaks >= s.goals.breaksMin) unlock('breaks_done');
  if (today.totalMin > 0 && (today.exceeded || []).length === 0) unlock('limits_ok');
  if (focus.success >= 1) unlock('focus_first');
  if (focus.success >= 10) unlock('focus_10');
  if (focus.totalHours >= 5) unlock('focus_5h');
  if (today.unlocks > 0 && today.unlocks < 25) unlock('unlocks_low');
  if ((today.nightMin || 0) > 0 && today.nightMin < 10) unlock('night_ok');
  updateStreak();
}

/** Полный список достижений с состоянием */
export function allAchievements() {
  const unlocked = Store.get('history.achievements', {});
  return ACHIEVEMENTS.map((a) => ({ ...a, unlocked: !!unlocked[a.id], ts: unlocked[a.id] || null }));
}

/** Лента «достижений дня» для главной и целей */
export function dailyFeed(ctx = {}) {
  const s = Store.settings();
  const todayKey = dayKey();
  const today = ctx.today || Store.day(todayKey);
  const yesterday = Store.get(`history.days.${addDays(todayKey, -1)}`, null);
  const live = ctx.live || {};
  const feed = [];

  if (yesterday && yesterday.totalMin > 0) {
    const diff = Math.round(yesterday.totalMin - today.totalMin);
    if (diff >= 15) feed.push(`Сегодня ты провёл в телефоне на ${fmtMin(diff)} меньше, чем вчера. Так держать!`);
    else if (diff <= -15) feed.push(`Экран на ${fmtMin(-diff)} больше вчерашнего. Попробуй сделать паузу — всё получится.`);
  }
  const restMax = Math.max(live.longestOfflineMin || 0, today.longestOfflineMin || 0);
  if (restMax >= 120) feed.push(`Ты не пользовался телефоном ${fmtMin(restMax)} подряд. Отличная пауза!`);
  else if (restMax >= 30) feed.push(`Самая длинная пауза сегодня — ${fmtMin(restMax)}.`);
  if (today.breaks >= s.goals.breaksMin) feed.push('Ты выполнил все запланированные перерывы для глаз.');
  if ((today.exceeded || []).length) feed.push(`Лимит превышен: ${today.exceeded.length} приложени${today.exceeded.length === 1 ? 'е' : 'я'}. Завтра попробуем уложиться.`);
  if (!feed.length) feed.push('Новый день — новая возможность потренировать цифровую дисциплину.');
  return feed;
}

/** Серия текущая/лучшая для отображения */
export function streakInfo() {
  updateStreak();
  return Store.get('history.streak', { current: 0, best: 0 });
}
