/* Focus Guardian — локальное хранилище (localStorage): настройки, правила приложений, история */

import { dayKey, addDays, SELF_PKG } from './util.js';

/* Реэкспорт утилит времени — многие страницы импортируют их из storage.js */
export { dayKey, addDays };

const KEY = 'fg_v1';

export const DEFAULTS = {
  version: 1,
  settings: {
    profile: { name: '' },
    theme: 'dark',            // dark | light | auto
    accent: 'violet',         // violet | cyan | blue
    monitoring: true,
    mode: 'standard',         // soft | standard | strict | max
    onboarded: false,
    dailyLimitMin: 240,
    summaryTime: '21:30',
    demo: false,
    sleep: { start: '23:00', end: '07:00', warnings: true },
    notify: {
      enabled: true,
      strictness: 'normal',   // soft | normal | strict
      session20: true,
      session40: true,
      session60: true,
      limitReached: true,
      endOfDay: true,
      restCelebration: true,
      nightWarning: true,
      vibration: true,
      sound: 'gentle',        // default | gentle | none
    },
    eye: { enabled: true, intervalMin: 20, durationSec: 20, autoFullscreen: false },
    rest: { autoSuggest: true, afterMin: 120, blockApps: false },
    walk: { enabled: true, everyMin: 90 },
    stretch: { enabled: true, everyMin: 120 },
    motivation: {
      dailyQuote: true,
      categories: { vision: true, breaks: true, mindful: true, focus: true, sleep: true, productivity: true, social: true },
    },
    focus: { defaultMin: 25, blockApps: true, dnd: false },
    goals: {
      screenMin: 240,
      socialMin: 90,
      videoMin: 90,
      gamesMin: 45,
      breaksMin: 6,
      offlineMin: 120,
    },
  },
  appRules: {},               // pkg -> {limitMin, category, enabled, blockUntilTs, blockedAllDay, scheduleStart, scheduleEnd, updatedAt}
  history: {
    days: {},                 // '2026-11-20' -> {totalMin, launches, unlocks, restMin, breaks, longestOfflineMin, nightMin, byApp:{}, exceeded:[], updated}
    breaks: [],               // {ts, sec, type: 'eye'|'auto'}
    blocks: [],               // {ts, pkg, reason}
    focusSessions: [],        // {startedTs, endedTs, plannedMin, actualMin, success, violations}
    restSessions: [],         // {startedTs, endedTs, plannedMin, actualMin}
    achievements: {},         // id -> unlockedTs
    streak: { current: 0, best: 0, updated: null },
    mergedNativeLog: [],      // startedTs строк, уже слитых из нативного журнала
  },
  meta: {
    created: Date.now(),
    session: null,            // локальный сеанс фокуса/отдыха (для режима браузера): {kind, endsTs, blockPkgs, startedTs, minutes}
    lastQuoteDay: null,
  },
};

function isPlain(v) {
  return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function deepMerge(base, over) {
  if (!isPlain(over)) return over;
  const out = isPlain(base) ? { ...base } : {};
  for (const k of Object.keys(over)) {
    out[k] = isPlain(over[k]) && isPlain(base?.[k]) ? deepMerge(base[k], over[k]) : over[k];
  }
  return out;
}

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(DEFAULTS);
    const parsed = JSON.parse(raw);
    return deepMerge(structuredClone(DEFAULTS), parsed);
  } catch (e) {
    console.warn('[storage] не удалось прочитать данные, используем значения по умолчанию', e);
    return structuredClone(DEFAULTS);
  }
}

let data = load();
let saveTimer = null;

function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
    } catch (e) {
      console.warn('[storage] не удалось сохранить данные', e);
    }
  }, 120);
}

function getPath(path) {
  return path.split('.').reduce((acc, k) => (acc == null ? undefined : acc[k]), data);
}

function setPath(path, val) {
  const keys = path.split('.');
  let cur = data;
  for (let i = 0; i < keys.length - 1; i++) {
    if (!isPlain(cur[keys[i]])) cur[keys[i]] = {};
    cur = cur[keys[i]];
  }
  cur[keys[keys.length - 1]] = val;
  save();
}

export function emptyDay() {
  return {
    totalMin: 0,
    launches: 0,
    unlocks: 0,
    restMin: 0,
    breaks: 0,
    longestOfflineMin: 0,
    nightMin: 0,
    byApp: {},
    exceeded: [],
    updated: Date.now(),
  };
}

export const Store = {
  get data() { return data; },
  get(path, def = undefined) {
    const v = getPath(path);
    return v === undefined ? def : v;
  },
  set(path, val) { setPath(path, val); },

  settings() { return data.settings; },

  updateSettings(patch, prefix = 'settings') {
    for (const [k, v] of Object.entries(patch)) setPath(`${prefix}.${k}`, v);
  },

  rules() { return data.appRules; },
  rule(pkg) { return data.appRules[pkg] || null; },
  setRule(pkg, patch) {
    const cur = data.appRules[pkg] || {};
    data.appRules[pkg] = { ...cur, ...patch, updatedAt: Date.now() };
    save();
  },
  removeRule(pkg) {
    delete data.appRules[pkg];
    save();
  },

  /** Гарантированно создаёт запись дня и возвращает её */
  day(key = dayKey()) {
    if (!data.history.days[key]) data.history.days[key] = emptyDay();
    const d = data.history.days[key];
    // миграция недостающих полей
    for (const [k, v] of Object.entries(emptyDay())) if (d[k] === undefined) d[k] = v;
    return d;
  },

  updateDay(key, patch) {
    const d = Store.day(key);
    Object.assign(d, patch, { updated: Date.now() });
    save();
  },

  push(listName, item, cap = 500) {
    data.history[listName].push(item);
    if (data.history[listName].length > cap) {
      data.history[listName] = data.history[listName].slice(-cap);
    }
    save();
  },

  mergeFocusSessions(entries) {
    const seen = new Set(data.history.mergedNativeLog);
    for (const e of entries || []) {
      const id = `${e.startedTs}:${e.plannedMin}`;
      const dup = data.history.focusSessions.some((s) => s.startedTs === e.startedTs);
      if (dup || seen.has(id)) continue;
      data.history.focusSessions.push(e);
      seen.add(id);
    }
    data.history.mergedNativeLog = [...seen].slice(-400);
    save();
  },

  exportAll() {
    return JSON.stringify({ exportedAt: new Date().toISOString(), app: 'Focus Guardian', version: 1, data });
  },

  importAll(jsonString) {
    const parsed = JSON.parse(jsonString);
    const incoming = parsed && parsed.data ? parsed.data : parsed;
    if (!incoming || !incoming.settings) throw new Error('Файл резервной копии повреждён');
    data = deepMerge(structuredClone(DEFAULTS), incoming);
    save();
    return true;
  },

  /** Сброс статистики (настройки остаются) */
  resetStats() {
    data.history = structuredClone(DEFAULTS.history);
    save();
  },

  /** Полный сброс */
  resetAll() {
    data = structuredClone(DEFAULTS);
    save();
  },
};

/** Обновляет запись дня данными из нативного кэша (если сервис собирал статистику) */
export function absorbNativeDay(dateKey, native) {
  if (!native || typeof native !== 'object') return;
  const d = Store.day(dateKey);
  if (Number(native.totalMin) > 0) d.totalMin = Math.round(native.totalMin);
  if (native.byApp && typeof native.byApp === 'object') {
    for (const [pkg, v] of Object.entries(native.byApp)) {
      if (pkg === SELF_PKG) continue;
      d.byApp[pkg] = {
        timeMin: Math.round(v?.timeMin || 0),
        launches: v?.launches || 0,
        lastTs: v?.lastTs || 0,
      };
    }
  }
  if (Number.isFinite(native.launches) && native.launches >= 0) d.launches = Math.max(d.launches, Math.round(native.launches));
  if (Number.isFinite(native.unlocks) && native.unlocks >= 0) d.unlocks = Math.max(d.unlocks, Math.round(native.unlocks));
  if (Number.isFinite(native.restMin) && native.restMin >= 0) d.restMin = Math.max(d.restMin, Math.round(native.restMin));
  if (Number.isFinite(native.breaks) && native.breaks >= 0) d.breaks = Math.max(d.breaks, Math.round(native.breaks));
  if (Number.isFinite(native.nightMin) && native.nightMin >= 0) d.nightMin = Math.max(d.nightMin, Math.round(native.nightMin));
  d.updated = Date.now();
  save();
}

/** Серия последних N дней из локальной истории (с заполнением пустых дней) */
export function localSeries(days) {
  const out = [];
  const today = dayKey();
  for (let i = days - 1; i >= 0; i--) {
    const key = addDays(today, -i);
    const d = data.history.days[key];
    out.push({
      date: key,
      totalMin: d ? Math.round(d.totalMin || 0) : 0,
      unlocks: d ? (d.unlocks || 0) : 0,
      launches: d ? (d.launches || 0) : 0,
      restMin: d ? Math.round(d.restMin || 0) : 0,
      breaks: d ? (d.breaks || 0) : 0,
      hasData: !!d && (d.totalMin > 0 || d.unlocks > 0),
    });
  }
  return out;
}
