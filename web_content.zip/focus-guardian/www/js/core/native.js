/* Focus Guardian — мост между JS и нативными модулями Android (Capacitor).
   В браузере (без нативного слоя) возвращает {ok:false, reason:'no-native'} —
   интерфейс честно показывает, что данных нет, вместо подделки. */

import { demoCall } from './demo.js';
import { Store } from './storage.js';

export const SELF_PKG = 'com.focusguardian.app';

function hasCapacitor() {
  return typeof window !== 'undefined'
    && window.Capacitor
    && typeof window.Capacitor.isNativePlatform === 'function'
    && window.Capacitor.isNativePlatform();
}

export const Native = {
  /** true, если приложение собрано в APK (нативный слой доступен) */
  isNative: () => hasCapacitor(),

  plugin() {
    if (!hasCapacitor()) return null;
    try {
      return window.Capacitor.Plugins.FocusGuardianNative || null;
    } catch (e) {
      console.warn('[native] плагин недоступен', e);
      return null;
    }
  },

  demoActive() {
    if (new URLSearchParams(location.search).has('demo')) return true;
    try { return !!Store.settings().demo; } catch (e) { return false; }
  },

  /** Единая точка вызова нативного метода */
  async call(method, args = {}) {
    const p = Native.plugin();
    if (p) {
      try {
        const res = await p[method](args);
        return { ok: true, ...(res || {}) };
      } catch (e) {
        console.warn(`[native] ${method} ошибка:`, e);
        return { ok: false, reason: 'error', message: String(e?.message || e) };
      }
    }
    if (Native.demoActive()) {
      try {
        return await demoCall(method, args);
      } catch (e) {
        console.warn(`[demo] ${method} ошибка:`, e);
        return { ok: false, reason: 'error', message: String(e?.message || e) };
      }
    }
    return { ok: false, reason: 'no-native' };
  },

  /* ---- данные использования ---- */

  async permissions() {
    return Native.call('getPermissionStatus');
  },

  async installedApps() {
    return Native.call('getInstalledApps');
  },

  async appIcons(packages) {
    if (!packages || !packages.length) return { ok: true, icons: {} };
    return Native.call('getAppIcons', { packages: packages.slice(0, 40) });
  },

  async usageToday() {
    return Native.call('getUsageToday');
  },

  async usageRange(fromTs, toTs) {
    return Native.call('getUsageRange', { fromTs, toTs });
  },

  async dailySeries(days) {
    return Native.call('getDailySeries', { days });
  },

  async liveState() {
    return Native.call('getLiveState');
  },

  async diagnostics() {
    return Native.call('getServiceDiagnostics');
  },

  async nativeSession() {
    return Native.call('getNativeSession');
  },

  async sessionsLog() {
    return Native.call('getSessionsLog');
  },

  /* ---- команды ---- */

  async setConfig(settings) {
    return Native.call('setConfig', { json: JSON.stringify(settings) });
  },

  async setBlockRules(payload) {
    return Native.call('setBlockRules', { json: JSON.stringify(payload) });
  },

  async startFocus(minutes, blockPkgs) {
    return Native.call('startFocus', { minutes, blockPkgs });
  },
  async stopFocus(completed) {
    return Native.call('stopFocus', { completed });
  },
  async startRest(minutes, blockPkgs) {
    return Native.call('startRest', { minutes, blockPkgs });
  },
  async stopRest() {
    return Native.call('stopRest');
  },

  async testNotification() {
    return Native.call('testNotification');
  },
  async notifyNow(title, text, channel = 'reminders') {
    return Native.call('notifyNow', { title, text, channel });
  },

  async requestNotifications() {
    return Native.call('requestNotifications');
  },

  async exportFile(name, mime, content) {
    if (Native.isNative()) {
      // содержимое в base64 без префикса data:
      const b64 = content.split(',').length > 1 && content.startsWith('data:') ? content.split(',')[1] : btoa(unescape(encodeURIComponent(content)));
      return Native.call('exportFile', { name, mime, base64: b64 });
    }
    return { ok: false, reason: 'no-native' };
  },

  /* ---- системные настройки ---- */

  async openUsageAccess() { return Native.call('openUsageAccessSettings'); },
  async openAccessibility() { return Native.call('openAccessibilitySettings'); },
  async openOverlay() { return Native.call('openOverlaySettings'); },
  async openBattery() { return Native.call('openBatterySettings'); },
  async openDnd() { return Native.call('openDndSettings'); },
  async openNotificationSettings() { return Native.call('openAppNotificationSettings'); },
};

/* Кэш живого состояния (чтобы не дёргать нативный слой каждый кадр) */
let liveCache = { ts: 0, value: null };
export async function getLiveCached(forceMs = 30000) {
  const now = Date.now();
  if (!forceMs && liveCache.value && now - liveCache.ts < forceMs) return liveCache.value;
  const r = await Native.liveState();
  if (r.ok) {
    liveCache = { ts: now, value: r };
    return r;
  }
  return r;
}

/** Синхронизация настроек в нативный сервис (вызывается при изменении настроек и при старте) */
let syncT = null;
export function syncConfigToNative() {
  if (!Native.isNative()) return;
  clearTimeout(syncT);
  syncT = setTimeout(async () => {
    await Native.setConfig(Store.settings());
  }, 400);
}
