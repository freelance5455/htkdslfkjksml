/* Focus Guardian — ДЕМО-режим данных.
   Используется ТОЛЬКО для проверки интерфейса в браузере и тестирования сборки.
   Активируется флагом «Демо-данные» в настройках или параметром ?demo=1.
   В реальной работе приложение использует нативные модули Android. */

import { dayKey, addDays, fmtMin, seededRandom, SELF_PKG } from './util.js';

const DEMO_APPS = [
  { pkg: 'com.zhiliaoapp.musically', label: 'TikTok', cat: 'social' },
  { pkg: 'com.google.android.youtube', label: 'YouTube', cat: 'video' },
  { pkg: 'org.telegram.messenger', label: 'Telegram', cat: 'social' },
  { pkg: 'com.instagram.android', label: 'Instagram', cat: 'social' },
  { pkg: 'com.vkontakte.android', label: 'VK', cat: 'social' },
  { pkg: 'com.whatsapp', label: 'WhatsApp', cat: 'social' },
  { pkg: 'com.android.chrome', label: 'Chrome', cat: 'other' },
  { pkg: 'com.spotify.music', label: 'Spotify', cat: 'other' },
  { pkg: 'com.supercell.brawlstars', label: 'Brawl Stars', cat: 'games' },
  { pkg: 'com.netflix.mediaclient', label: 'Netflix', cat: 'video' },
  { pkg: 'com.reddit.frontpage', label: 'Reddit', cat: 'social' },
  { pkg: 'com.android.settings', label: 'Настройки', cat: 'other', system: true },
];

const COLORS = ['#8B7CFF', '#38C6FF', '#5DE29A', '#FFC46B', '#FF6B7E', '#7FB0FF', '#C58BFF'];

function demoIcon(letter, color) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="96" height="96" rx="22" fill="${color}"/><text x="48" y="60" font-family="Arial" font-size="42" font-weight="700" fill="#fff" text-anchor="middle">${letter}</text></svg>`;
  return 'data:image/svg+xml;base64,' + btoa(svg);
}

function appMeta(pkg) {
  return DEMO_APPS.find((a) => a.pkg === pkg) || { pkg, label: pkg.split('.').pop(), cat: 'other' };
}

function dayUsageFor(key) {
  const rnd = seededRandom('usage:' + key);
  const weights = DEMO_APPS.map((a) => {
    if (a.cat === 'social') return 0.6 + rnd() * 0.8;
    if (a.cat === 'video') return 0.5 + rnd() * 0.7;
    if (a.cat === 'games') return 0.15 + rnd() * 0.5;
    return 0.08 + rnd() * 0.35;
  });
  const target = 210 + Math.floor(rnd() * 190); // 3.5–6.5 ч
  const sum = weights.reduce((a, b) => a + b, 0);
  const byApp = {};
  let total = 0;
  DEMO_APPS.forEach((a, i) => {
    const timeMin = Math.round((weights[i] / sum) * target);
    if (timeMin < 2) return;
    total += timeMin;
    byApp[a.pkg] = { timeMin, launches: Math.max(1, Math.round(timeMin / 9 + rnd() * 4)), lastTs: Date.now() - Math.floor(rnd() * 8 * 3600e3) };
  });
  return { totalMin: total, byApp };
}

const seriesCache = new Map();

function buildSeries(days) {
  const key = `${dayKey()}:${days}`;
  if (seriesCache.has(key)) return seriesCache.get(key);
  const today = dayKey();
  const series = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    const u = dayUsageFor(d);
    const rnd = seededRandom('misc:' + d);
    series.push({
      date: d,
      totalMin: u.totalMin,
      launches: 28 + Math.floor(rnd() * 40),
      unlocks: 34 + Math.floor(rnd() * 55),
      restMin: 120 + Math.floor(rnd() * 260),
      breaks: 4 + Math.floor(rnd() * 7),
      hasData: true,
    });
  }
  seriesCache.set(key, series);
  return series;
}

export function demoAvailable() {
  try {
    return true;
  } catch (_) {
    return false;
  }
}

/** Маршрутизатор вызовов нативного моста в демо-режиме */
export async function demoCall(method, args = {}) {
  const today = dayKey();
  switch (method) {
    case 'getPermissionStatus':
      return { ok: true, usageAccess: true, accessibility: true, overlay: true, batteryIgnored: true, dnd: false, notifications: true, serviceRunning: true };
    case 'getInstalledApps':
      return {
        ok: true,
        apps: DEMO_APPS.filter((a) => !a.system).map((a) => ({ pkg: a.pkg, label: a.label, system: false }))
          .concat(DEMO_APPS.filter((a) => a.system).map((a) => ({ pkg: a.pkg, label: a.label, system: true }))),
      };
    case 'getAppIcons': {
      const icons = {};
      for (const pkg of (args.packages || []).slice(0, 40)) {
        const m = appMeta(pkg);
        icons[pkg] = demoIcon((m.label || '?')[0].toUpperCase(), COLORS[(m.label || '').charCodeAt(0) % COLORS.length]);
      }
      return { ok: true, icons };
    }
    case 'getUsageToday':
    case 'getUsageRange': {
      const u = dayUsageFor(today);
      const rnd = seededRandom('misc:' + today);
      return {
        ok: true,
        totalMin: u.totalMin,
        byApp: u.byApp,
        launches: 30 + Math.floor(rnd() * 35),
        unlocks: 40 + Math.floor(rnd() * 50),
        restMin: 130 + Math.floor(rnd() * 200),
        breaks: 5 + Math.floor(rnd() * 5),
        nightMin: 10 + Math.floor(rnd() * 30),
        longestOfflineMin: 90 + Math.floor(rnd() * 160),
      };
    }
    case 'getDailySeries':
      return { ok: true, series: buildSeries(Math.min(args.days || 7, 366)) };
    case 'getLiveState': {
      const rnd = seededRandom('live:' + new Date().getHours());
      return {
        ok: true,
        available: true,
        screenOn: true,
        sessionStartTs: Date.now() - Math.floor(6 + rnd() * 30) * 60000,
        lastRestTs: Date.now() - Math.floor(2 + rnd() * 3) * 3600e3,
        restMinToday: 140 + Math.floor(rnd() * 120),
        breaksToday: 5 + Math.floor(rnd() * 4),
        unlocksToday: 42 + Math.floor(rnd() * 40),
        nightMin: 12,
        longestOfflineMin: 110,
      };
    }
    case 'getServiceDiagnostics':
      return { ok: true, running: true, lastTickTs: Date.now() - 30000, lastStatsSyncTs: Date.now() - 60000, accessibilityConnected: true, blocksToday: 2 };
    case 'getNativeSession':
      return { ok: true, active: false, kind: null, endsTs: 0, violations: 0, blockPkgs: [] };
    case 'getSessionsLog':
      return { ok: true, sessions: [] };
    case 'setBlockRules':
    case 'setConfig':
    case 'startRest':
    case 'stopRest':
    case 'startFocus':
    case 'stopFocus':
    case 'openUsageAccessSettings':
    case 'openAccessibilitySettings':
    case 'openOverlaySettings':
    case 'openBatterySettings':
    case 'openDndSettings':
    case 'openAppNotificationSettings':
      return { ok: true };
    case 'testNotification':
    case 'notifyNow':
      return { ok: true };
    case 'exportFile':
      return { ok: true, path: '/storage/emulated/0/Download/' + (args.name || 'export') };
    default:
      console.warn('[demo] неизвестный метод', method);
      return { ok: false, reason: 'unknown-method' };
  }
}

/** Приложения с категориями по умолчанию (для предзаполнения правил) */
export function demoCategories() {
  const map = {};
  DEMO_APPS.forEach((a) => { map[a.pkg] = a.cat; });
  return map;
}

export { fmtMin };
