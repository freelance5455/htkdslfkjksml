/* Focus Guardian — UI-компоненты: toast, модалки, шторки, hold-кнопки, сегменты, пустые состояния */

import { icon } from './icons.js';
import { esc } from './util.js';

/* ---------- Toast ---------- */

export function toast(msg, type = 'info', ms = 2800) {
  let box = document.getElementById('toasts');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toasts';
    document.body.appendChild(box);
  }
  const iconName = type === 'ok' ? 'check' : type === 'warn' ? 'alert' : type === 'error' ? 'x' : 'info';
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `${icon(iconName)}<span>${esc(msg)}</span>`;
  box.appendChild(el);
  setTimeout(() => {
    el.classList.add('leaving');
    setTimeout(() => el.remove(), 260);
  }, ms);
}

/* ---------- Модальные окна ---------- */

export function modal({ title = '', text = '', body = '', actions = [], onClose = null, wide = false }) {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal" ${wide ? 'style="max-width:460px"' : ''}>
      ${title ? `<div class="modal-title">${esc(title)}</div>` : ''}
      ${text ? `<div class="modal-text">${text}</div>` : ''}
      ${body}
      <div class="modal-actions"></div>
    </div>`;
  const actionsBox = overlay.querySelector('.modal-actions');

  const close = () => {
    overlay.remove();
    if (onClose) onClose();
  };

  if (actions.length) {
    for (const a of actions) {
      const btn = document.createElement('button');
      btn.className = `btn ${a.class || 'ghost'}`;
      btn.innerHTML = `${a.icon ? icon(a.icon) : ''}<span>${esc(a.label)}</span>`;
      btn.addEventListener('click', async () => {
        if (a.onClick) await a.onClick(close, overlay);
        else close();
      });
      actionsBox.appendChild(btn);
    }
  } else {
    actionsBox.remove();
  }

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });
  document.body.appendChild(overlay);
  return { close, overlay, el: overlay.querySelector('.modal') };
}

export function sheet({ title = '', body = '', actions = [], onClose = null }) {
  const overlay = document.createElement('div');
  overlay.className = 'sheet-overlay';
  overlay.innerHTML = `
    <div class="sheet">
      <div class="sheet-grab"></div>
      ${title ? `<div class="modal-title">${esc(title)}</div>` : ''}
      ${body}
      <div class="modal-actions"></div>
    </div>`;
  const actionsBox = overlay.querySelector('.modal-actions');
  const close = () => {
    overlay.remove();
    if (onClose) onClose();
  };
  for (const a of actions) {
    const btn = document.createElement('button');
    btn.className = `btn ${a.class || 'ghost'} block`;
    btn.innerHTML = `${a.icon ? icon(a.icon) : ''}<span>${esc(a.label)}</span>`;
    btn.addEventListener('click', async () => {
      if (a.onClick) await a.onClick(close, overlay);
      else close();
    });
    actionsBox.appendChild(btn);
  }
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });
  document.body.appendChild(overlay);
  return { close, overlay, el: overlay.querySelector('.sheet') };
}

export function confirmDialog({ title = 'Подтверждение', text = '', okLabel = 'Готово', cancelLabel = 'Отмена', danger = false, hold = false } = {}) {
  return new Promise((resolve) => {
    let settled = false;
    const m = modal({
      title,
      text,
      actions: [
        { label: cancelLabel, class: 'ghost', onClick: (close) => { settled = true; close(); resolve(false); } },
        { label: okLabel, class: danger ? 'danger' : '', icon: danger ? 'trash' : 'check', onClick: (close) => { settled = true; close(); resolve(true); } },
      ],
      onClose: () => { if (!settled) resolve(false); },
    });
    if (hold) {
      const ok = m.el.querySelector('.modal-actions .btn:last-child');
      if (ok) holdButton(ok, () => {
        settled = true; m.close(); resolve(true);
      });
    }
  });
}

/* ---------- Кнопка с удержанием (защита от случайного нажатия) ---------- */

export function holdButton(btn, onConfirm, { ms = 1500 } = {}) {
  if (!btn || btn.dataset.holdBound) return;
  btn.dataset.holdBound = '1';
  btn.classList.add('hold-btn');
  const bar = document.createElement('span');
  bar.className = 'hold-bar';
  btn.prepend(bar);
  let raf = null;
  let start = 0;

  const finish = (cancelled) => {
    cancelAnimationFrame(raf);
    raf = null;
    bar.style.width = cancelled ? '0' : '100%';
    if (!cancelled) {
      setTimeout(() => { bar.style.width = '0'; }, 200);
      onConfirm();
    }
  };

  const tick = () => {
    const p = Math.min(1, (Date.now() - start) / ms);
    bar.style.width = `${p * 100}%`;
    if (p >= 1) finish(false);
    else raf = requestAnimationFrame(tick);
  };

  btn.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    start = Date.now();
    raf = requestAnimationFrame(tick);
  });
  for (const ev of ['pointerup', 'pointerleave', 'pointercancel']) {
    btn.addEventListener(ev, () => { if (raf) finish(true); });
  }
  btn.addEventListener('click', (e) => e.preventDefault());
}

/* ---------- Сегментированный переключатель ---------- */

export function seg(container, options, value, onChange) {
  container.classList.add('seg');
  container.innerHTML = '';
  options.forEach((o) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = o.label;
    if (String(o.value) === String(value)) b.classList.add('active');
    b.addEventListener('click', () => {
      container.querySelectorAll('button').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      onChange(o.value, o);
    });
    container.appendChild(b);
  });
  return container;
}

/* ---------- Переключатель (switch) ---------- */

export function switchEl(checked, onChange, ariaLabel = '') {
  const wrap = document.createElement('label');
  wrap.className = 'switch';
  wrap.innerHTML = `<input type="checkbox" ${checked ? 'checked' : ''} ${ariaLabel ? `aria-label="${esc(ariaLabel)}"` : ''}><span class="track"></span><span class="thumb"></span>`;
  wrap.querySelector('input').addEventListener('change', (e) => onChange(e.target.checked, e));
  return wrap;
}

/* ---------- Пустое состояние ---------- */

export function emptyState({ iconName = 'info', title = 'Нет данных', text = '', action = null } = {}) {
  const el = document.createElement('div');
  el.className = 'empty';
  el.innerHTML = `
    ${icon(iconName)}
    <h3>${esc(title)}</h3>
    ${text ? `<p>${text}</p>` : ''}
    ${action ? `<button class="btn small">${icon(action.icon || 'chevron')}<span>${esc(action.label)}</span></button>` : ''}`;
  if (action) el.querySelector('button').addEventListener('click', action.onClick);
  return el;
}

/* ---------- Бейдж ---------- */

export function badge(text, type = '') {
  const el = document.createElement('span');
  el.className = `badge ${type}`;
  el.textContent = text;
  return el;
}

/* ---------- Ступенчатый счётчик ---------- */

export function stepper({ value, min = 0, max = 999, step = 1, suffix = '', onChange }) {
  const wrap = document.createElement('div');
  wrap.className = 'stepper';
  let cur = value;
  const render = () => {
    wrap.innerHTML = `
      <button type="button" data-d="-1" aria-label="Уменьшить">${icon('minus')}</button>
      <div class="value num">${cur}${suffix ? ` <small class="muted">${esc(suffix)}</small>` : ''}</div>
      <button type="button" data-d="1" aria-label="Увеличить">${icon('plus')}</button>`;
    wrap.querySelectorAll('button').forEach((b) => {
      b.addEventListener('click', () => {
        cur = Math.min(max, Math.max(min, cur + Number(b.dataset.d) * step));
        render();
        onChange(cur);
      });
    });
  };
  render();
  return wrap;
}
