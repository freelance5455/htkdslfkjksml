/* Focus Guardian — лёгкие графики на canvas/SVG без внешних зависимостей */

function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim() || '#8B7CFF';
}

function setupCanvas(canvas, desiredHeight = 180) {
  const dpr = Math.min(window.devicePixelRatio || 1, 2.5);
  const width = canvas.parentElement.clientWidth || 320;
  canvas.width = Math.round(width * dpr);
  canvas.height = Math.round(desiredHeight * dpr);
  canvas.style.height = `${desiredHeight}px`;
  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  return { ctx, w: width, h: desiredHeight };
}

function roundRect(ctx, x, y, w, h, r) {
  const rr = Math.min(r, w / 2, Math.abs(h) / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function fmtAxisMin(m) {
  if (m >= 60) return `${Math.round(m / 60)}ч`;
  return `${m}м`;
}

/* ---------- Столбчатый график ---------- */

export function barChart(canvas, { values = [], labels = [], color = null, goal = null, height = 180, markLast = false } = {}) {
  const parent = canvas.parentElement;
  if (!values.length) {
    parent.innerHTML = '<div class="chart-empty">Нет данных за период</div>';
    return;
  }
  const { ctx, w, h } = setupCanvas(canvas, height);
  const c = color || cssVar('--accent');
  const accent2 = cssVar('--accent-2');
  const max = Math.max(...values, 1) * 1.15;
  const pad = { l: 8, r: 8, t: 10, b: 22 };
  const bw = (w - pad.l - pad.r) / values.length;
  const chartH = h - pad.t - pad.b;
  const grid = cssVar('--border');

  ctx.clearRect(0, 0, w, h);

  if (goal && goal <= max) {
    const gy = pad.t + chartH - (goal / max) * chartH;
    ctx.strokeStyle = cssVar('--warn');
    ctx.setLineDash([5, 5]);
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(pad.l, gy);
    ctx.lineTo(w - pad.r, gy);
    ctx.stroke();
    ctx.setLineDash([]);
  }

  values.forEach((v, i) => {
    const bh = Math.max(3, (v / max) * chartH);
    const x = pad.l + i * bw + bw * 0.18;
    const y = pad.t + chartH - bh;
    const bwc = bw * 0.64;
    const grad = ctx.createLinearGradient(0, y, 0, y + bh);
    grad.addColorStop(0, accent2);
    grad.addColorStop(1, c);
    ctx.fillStyle = markLast && i === values.length - 1 ? accent2 : grad;
    if (i === values.length - 1 && !markLast) ctx.fillStyle = grad;
    roundRect(ctx, x, y, bwc, bh, 5);
    ctx.fill();
    if (labels[i]) {
      ctx.fillStyle = cssVar('--text-3');
      ctx.font = '9.5px -apple-system, Roboto, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(labels[i], x + bwc / 2, h - 7);
    }
  });

  void grid;
}

/* ---------- Линия ---------- */

export function lineChart(canvas, { values = [], labels = [], color = null, height = 170, fill = true } = {}) {
  const parent = canvas.parentElement;
  if (!values.length) {
    parent.innerHTML = '<div class="chart-empty">Нет данных за период</div>';
    return;
  }
  const { ctx, w, h } = setupCanvas(canvas, height);
  const c = color || cssVar('--accent-2');
  const max = Math.max(...values, 1) * 1.15;
  const pad = { l: 8, r: 8, t: 12, b: 22 };
  const chartW = w - pad.l - pad.r;
  const chartH = h - pad.t - pad.b;
  const step = values.length > 1 ? chartW / (values.length - 1) : 0;

  ctx.clearRect(0, 0, w, h);

  ctx.beginPath();
  values.forEach((v, i) => {
    const x = pad.l + i * step;
    const y = pad.t + chartH - (v / max) * chartH;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = c;
  ctx.lineWidth = 2.4;
  ctx.lineJoin = 'round';
  ctx.stroke();

  if (fill) {
    ctx.lineTo(pad.l + (values.length - 1) * step, pad.t + chartH);
    ctx.lineTo(pad.l, pad.t + chartH);
    ctx.closePath();
    const grad = ctx.createLinearGradient(0, pad.t, 0, pad.t + chartH);
    grad.addColorStop(0, `${c}44`);
    grad.addColorStop(1, `${c}00`);
    ctx.fillStyle = grad;
    ctx.fill();
  }

  if (labels.length) {
    ctx.fillStyle = cssVar('--text-3');
    ctx.font = '9.5px -apple-system, Roboto, sans-serif';
    ctx.textAlign = 'center';
    const skip = Math.ceil(labels.length / 6);
    labels.forEach((l, i) => {
      if (i % skip === 0 || i === labels.length - 1) ctx.fillText(l, pad.l + i * step, h - 7);
    });
  }
}

/* ---------- Пончик ---------- */

export function donut(canvas, { segments = [], centerTitle = '', centerSub = '', height = 190 } = {}) {
  const parent = canvas.parentElement;
  const total = segments.reduce((a, s) => a + s.value, 0);
  if (!total) {
    parent.innerHTML = '<div class="chart-empty">Нет данных за период</div>';
    return;
  }
  const { ctx, w, h } = setupCanvas(canvas, height);
  ctx.clearRect(0, 0, w, h);
  const cx = w / 2;
  const cy = h / 2;
  const r = Math.min(w, h) / 2 - 12;
  const lineW = 26;
  let angle = -Math.PI / 2;
  for (const s of segments) {
    const frac = s.value / total;
    const a2 = angle + frac * Math.PI * 2;
    ctx.beginPath();
    ctx.strokeStyle = s.color || cssVar('--accent');
    ctx.lineWidth = lineW;
    ctx.lineCap = 'butt';
    ctx.arc(cx, cy, r - lineW / 2, angle + 0.015, Math.max(angle + 0.016, a2 - 0.015));
    ctx.stroke();
    angle = a2;
  }
  ctx.fillStyle = cssVar('--text');
  ctx.font = '700 17px -apple-system, Roboto, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText(centerTitle, cx, cy - 2);
  ctx.fillStyle = cssVar('--text-2');
  ctx.font = '11.5px -apple-system, Roboto, sans-serif';
  ctx.fillText(centerSub, cx, cy + 16);
}

/* ---------- Горизонтальные полосы (DOM) ---------- */

export function hbars(container, items = []) {
  container.innerHTML = '';
  if (!items.length) {
    container.innerHTML = '<div class="chart-empty">Нет данных за период</div>';
    return;
  }
  for (const it of items) {
    const pct = it.max > 0 ? Math.min(100, (it.value / it.max) * 100) : 0;
    const row = document.createElement('div');
    row.className = 'hbar-item';
    row.innerHTML = `
      <div class="hbar-top">
        <span class="h-label">${it.label}</span>
        <span class="h-value num">${it.sub || ''}</span>
      </div>
      <div class="progress-track"><div class="progress-fill ${it.cls || ''}" style="width:${pct}%"></div></div>`;
    container.appendChild(row);
  }
}

/* ---------- Кольцевой индикатор (SVG) ---------- */

export function ringSVG(pct, { size = 216, stroke = 15, showValue = null, sub = '', cls = '' } = {}) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const p = Math.max(0, Math.min(100, pct));
  const gid = `g${Math.random().toString(36).slice(2, 8)}`;
  return `
    <svg class="ring-svg ${cls}" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}">
      <defs>
        <linearGradient id="${gid}" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="var(--accent)"/>
          <stop offset="1" stop-color="var(--accent-2)"/>
        </linearGradient>
      </defs>
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="var(--border)" stroke-width="${stroke}"/>
      <circle class="ring-progress" cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="url(#${gid})" stroke-width="${stroke}"
        stroke-linecap="round" stroke-dasharray="${circ}" stroke-dashoffset="${circ * (1 - p / 100)}"
        transform="rotate(-90 ${size / 2} ${size / 2})" style="transition: stroke-dashoffset .8s cubic-bezier(.4,0,.2,1)"/>
    </svg>`;
}

/** Вставляет кольцо с центровым текстом в контейнер */
export function ringInto(container, pct, { size = 216, value = '', sub = '', pctLabel = '' } = {}) {
  container.classList.add('hero-ring-wrap');
  container.innerHTML = `
    ${ringSVG(pct, { size })}
    <div class="ring-center">
      <div class="r-value">${value}</div>
      ${sub ? `<div class="r-sub">${sub}</div>` : ''}
      ${pctLabel ? `<div class="r-pct">${pctLabel}</div>` : ''}
    </div>`;
  return container.querySelector('.ring-svg');
}

export function refreshRing(svgEl, pct) {
  if (!svgEl) return;
  const r = svgEl.querySelector('.ring-progress');
  const circ = 2 * Math.PI * Number(r.getAttribute('r'));
  const p = Math.max(0, Math.min(100, pct));
  r.setAttribute('stroke-dashoffset', String(circ * (1 - p / 100)));
}
