/* Focus Guardian — утилиты общего назначения */

export const SELF_PKG = 'com.focusguardian.app';

export const pad2 = (n) => String(n).padStart(2, '0');

export const dayKey = (d = new Date()) =>
  `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;

export function addDays(key, delta) {
  const [y, m, d] = key.split('-').map(Number);
  const dt = new Date(y, m - 1, d + delta);
  return dayKey(dt);
}

export const clamp = (v, min, max) => Math.min(max, Math.max(min, v));

export function fmtMin(m) {
  m = Math.max(0, Math.round(Number(m) || 0));
  const h = Math.floor(m / 60);
  const mm = m % 60;
  if (h && mm) return `${h} ч ${mm} мин`;
  if (h) return `${h} ч`;
  return `${mm} мин`;
}

export function fmtDurSec(sec) {
  sec = Math.max(0, Math.round(Number(sec) || 0));
  if (sec < 60) return `${sec} сек`;
  const m = Math.floor(sec / 60);
  if (m < 60) return `${m} мин`;
  return fmtMin(m);
}

export function fmtClock(ts) {
  if (!ts) return '—';
  return new Date(ts).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
}

export function fmtDateHuman(key) {
  const [y, m, d] = key.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  const today = dayKey();
  if (key === today) return 'Сегодня';
  if (key === addDays(today, -1)) return 'Вчера';
  return dt.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' });
}

export const fmtHM = (mins) => `${pad2(Math.floor(mins / 60))}:${pad2(Math.round(mins % 60))}`;

export function parseHM(str) {
  const [h, m] = String(str || '0:0').split(':').map(Number);
  return (h || 0) * 60 + (m || 0);
}

/** Текущее время в минутах от полуночи */
export const nowMinutes = () => {
  const d = new Date();
  return d.getHours() * 60 + d.getMinutes();
};

/** Находится ли момент внутри «ночного окна» (учитывает переход через полночь) */
export function inWindow(mins, startHM, endHM) {
  const s = parseHM(startHM);
  const e = parseHM(endHM);
  if (s === e) return false;
  if (s < e) return mins >= s && mins < e;
  return mins >= s || mins < e;
}

export function greeting() {
  const h = new Date().getHours();
  if (h < 5) return 'Доброй ночи';
  if (h < 12) return 'Доброе утро';
  if (h < 18) return 'Добрый день';
  return 'Добрый вечер';
}

export function esc(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/** Сравнение «сегодня vs вчера» — возвращает объект с текстом и классом */
export function compareWithYesterday(todayMin, yesterdayMin) {
  const diff = Math.round((Number(todayMin) || 0) - (Number(yesterdayMin) || 0));
  if (Math.abs(diff) <= 5) return { diff, text: 'Практически без изменений', cls: 'same' };
  const abs = fmtMin(Math.abs(diff));
  if (diff > 0) return { diff, text: `На ${abs} больше, чем вчера`, cls: 'up' };
  return { diff, text: `На ${abs} меньше, чем вчера`, cls: 'down' };
}

/** Долгота дня по серии данных */
export function seriesAvg(series, field = 'totalMin') {
  const vals = (series || []).map((s) => Number(s[field]) || 0);
  if (!vals.length) return 0;
  return vals.reduce((a, b) => a + b, 0) / vals.length;
}

export function downloadBlob(name, mime, content) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}

/** CSV для экспорта дневной статистики */
export function buildCsv(series) {
  const head = 'date,total_min,unlocks,launches,rest_min,breaks';
  const rows = (series || []).map((s) =>
    [s.date, s.totalMin ?? 0, s.unlocks ?? '', s.launches ?? 0, s.restMin ?? 0, s.breaks ?? 0].join(',')
  );
  return [head, ...rows].join('\n');
}

export function base64Encode(str) {
  const bytes = new TextEncoder().encode(str);
  let bin = '';
  bytes.forEach((b) => { bin += String.fromCharCode(b); });
  return btoa(bin);
}

export function htmlToBase64(str) {
  return base64Encode(str);
}

/** Детерминированный генератор (для демо-режима) */
export function seededRandom(seed) {
  let a = 0;
  const s = String(seed);
  for (let i = 0; i < s.length; i++) a = (a * 31 + s.charCodeAt(i)) >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
