/* Focus Guardian — сеансы фокуса и отдыха, правила блокировки для нативного сервиса */

import { Store, dayKey } from './storage.js';
import { Native } from './native.js';
import { toast } from './ui.js';
import { fmtMin } from './util.js';

export const Bus = new EventTarget();

/* ---------- Правила блокировки ---------- */

/** Собирает полную картину правил для нативного Accessibility-сервиса */
export function buildRulesPayload() {
  const s = Store.settings();
  const byPkg = {};
  for (const [pkg, rule] of Object.entries(Store.rules())) {
    if (rule && rule.enabled === false) continue;
    byPkg[pkg] = {
      limitMin: rule?.limitMin || 0,
      blockedAllDay: !!rule?.blockedAllDay,
      blockUntilTs: rule?.blockUntilTs || 0,
      scheduleStart: rule?.scheduleStart || null,
      scheduleEnd: rule?.scheduleEnd || null,
    };
  }
  const session = Store.get('meta.session', null);
  return {
    byPkg,
    mode: s.mode,
    strict: s.mode === 'strict',
    session: session && session.endsTs > Date.now()
      ? { kind: session.kind, endsTs: session.endsTs, blockPkgs: session.blockPkgs || [] }
      : null,
    selfPkg: 'com.focusguardian.app',
  };
}

export async function pushRules() {
  if (!Native.isNative()) return { ok: false, reason: 'no-native' };
  const r = await Native.setBlockRules(buildRulesPayload());
  return r;
}

/** После изменения правила приложения — обновить нативную картину */
export async function refreshNativeRules() {
  const r = await pushRules();
  if (!r.ok && Native.isNative()) toast('Не удалось обновить правила блокировки', 'error');
  return r;
}

/* ---------- Сеансы ---------- */

export function localSession() {
  const s = Store.get('meta.session', null);
  if (!s) return null;
  if (s.endsTs <= Date.now()) return { ...s, expired: true };
  return { ...s, expired: false };
}

/** Активный сеанс: приоритет у нативного (продолжается даже если приложение закрыто) */
export async function currentSession() {
  if (Native.isNative()) {
    const r = await Native.nativeSession();
    if (r.ok && r.active) {
      return { kind: r.kind, endsTs: r.endsTs, blockPkgs: r.blockPkgs || [], violations: r.violations || 0, startedTs: r.endsTs - (r.minutes || 0) * 60000, source: 'native' };
    }
    if (r.ok && !r.active) {
      // нативный сеанс мог завершиться без нас — проверить журнал
      const log = await Native.sessionsLog();
      if (log.ok && (log.sessions || []).length) Store.mergeFocusSessions(log.sessions.map(normalizeNativeSession));
      Store.set('meta.session', null);
    }
  }
  const loc = localSession();
  if (loc && !loc.expired) {
    return { kind: loc.kind, endsTs: loc.endsTs, blockPkgs: loc.blockPkgs || [], violations: 0, startedTs: loc.startedTs, minutes: loc.minutes, source: 'local' };
  }
  if (loc && loc.expired) {
    await finalizeLocalSession(true);
    return null;
  }
  return null;
}

function normalizeNativeSession(e) {
  return {
    startedTs: e.startedTs,
    endedTs: e.endedTs,
    plannedMin: e.plannedMin,
    actualMin: e.actualMin ?? e.plannedMin,
    success: e.success !== false,
    violations: e.violations || 0,
  };
}

export async function startSession(kind, minutes, blockPkgs = []) {
  const s = {
    kind,
    minutes,
    startedTs: Date.now(),
    endsTs: Date.now() + minutes * 60000,
    blockPkgs,
  };
  Store.set('meta.session', s);
  if (Native.isNative()) {
    const r = kind === 'focus'
      ? await Native.startFocus(minutes, blockPkgs)
      : await Native.startRest(minutes, blockPkgs);
    if (!r.ok) toast('Нативный сервис недоступен — сеанс будет считаться только пока приложение открыто', 'warn', 5000);
  }
  await pushRules();
  Bus.dispatchEvent(new CustomEvent('session-start', { detail: { kind, minutes } }));
  return s;
}

/** Завершение локального сеанса (используется, когда нативный слой не активен или пользователь остановил вручную) */
export async function finalizeLocalSession(natural = false) {
  const s = Store.get('meta.session', null);
  if (!s) return null;
  Store.set('meta.session', null);
  const now = Date.now();
  const actualMin = Math.max(0, (now - s.startedTs) / 60000);
  if (s.kind === 'focus') {
    Store.push('focusSessions', {
      startedTs: s.startedTs,
      endedTs: now,
      plannedMin: s.minutes,
      actualMin: Math.round(actualMin * 10) / 10,
      success: natural && actualMin >= s.minutes * 0.98,
      violations: 0,
    }, 400);
  } else {
    Store.push('restSessions', {
      startedTs: s.startedTs,
      endedTs: now,
      plannedMin: s.minutes,
      actualMin: Math.round(actualMin * 10) / 10,
    }, 400);
  }
  await pushRules();
  Bus.dispatchEvent(new CustomEvent('session-end', { detail: { kind: s.kind, completed: natural } }));
  return s;
}

export async function stopSession(completed = false) {
  const s = Store.get('meta.session', null);
  if (!s) return null;
  Store.set('meta.session', null);
  const now = Date.now();
  const actualMin = Math.max(0, (now - s.startedTs) / 60000);
  if (Native.isNative()) {
    if (s.kind === 'focus') await Native.stopFocus(completed);
    else await Native.stopRest();
  }
  if (s.kind === 'focus') {
    Store.push('focusSessions', {
      startedTs: s.startedTs,
      endedTs: now,
      plannedMin: s.minutes,
      actualMin: Math.round(actualMin * 10) / 10,
      success: completed,
      violations: 0,
    }, 400);
    toast(completed ? 'Сеанс фокуса завершён. Отличная работа!' : 'Сеанс прерван', completed ? 'ok' : 'warn');
  } else {
    Store.push('restSessions', {
      startedTs: s.startedTs,
      endedTs: now,
      plannedMin: s.minutes,
      actualMin: Math.round(actualMin * 10) / 10,
    }, 400);
    toast('Отдых завершён. Продолжай день с комфортом', 'ok');
  }
  await pushRules();
  Bus.dispatchEvent(new CustomEvent('session-end', { detail: { kind: s.kind, completed } }));
  return s;
}

/* ---------- Статистика фокуса ---------- */

export function focusStats() {
  const list = Store.get('history.focusSessions', []);
  const totalMin = list.reduce((a, s) => a + (s.actualMin || 0), 0);
  const success = list.filter((s) => s.success).length;
  // серия дней с сеансами
  const days = new Set(list.map((s) => new Date(s.startedTs).toDateString()));
  let streak = 0;
  let best = 0;
  const sorted = [...days].sort();
  let prev = null;
  for (const dStr of sorted) {
    const d = new Date(dStr);
    if (prev && (d - prev) === 86400000) streak += 1;
    else streak = 1;
    prev = d;
    best = Math.max(best, streak);
  }
  return {
    totalHours: Math.round((totalMin / 60) * 10) / 10,
    sessions: list.length,
    success,
    bestStreak: best,
    currentStreak: streak,
    avgMin: list.length ? Math.round(totalMin / list.length) : 0,
    list: list.slice(-12).reverse(),
  };
}
