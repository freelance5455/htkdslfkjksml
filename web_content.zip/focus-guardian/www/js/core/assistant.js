/* Focus Guardian — умный помощник: анализ статистики и персональные рекомендации */

import { Store } from './storage.js';
import { fmtMin } from './util.js';
import { seriesAvg, SELF_PKG } from './util.js';

/** Правило-ориентированный анализ. Возвращает список карточек с рекомендациями */
export function recommendations({ today, series, topApps = [], unlocks = 0, hasRules = false } = {}) {
  const s = Store.settings();
  const out = [];
  const week = (series || []).slice(-7);
  const avg7 = seriesAvg(week);

  if (topApps.length && today.totalMin > 0) {
    const top = topApps[0];
    const share = Math.round((top.timeMin / today.totalMin) * 100);
    if (share >= 25 && top.timeMin >= 45) {
      out.push({
        icon: 'grid',
        title: `${top.label} занимает ${share}% экранного времени`,
        text: `Сегодня — ${fmtMin(top.timeMin)}. Установи дневной лимит для этого приложения, и он начнёт напоминать о себе вовремя.`,
        action: { label: 'Настроить лимит', href: 'apps.html' },
      });
    }
  }

  if (unlocks >= 60) {
    out.push({
      icon: 'phone',
      title: `${unlocks} разблокировок за день`,
      text: 'Частые разблокировки обычно связаны с уведомлениями. Попробуй отключить несрочные — и проверь, как изменится число.',
      action: null,
    });
  }

  if (avg7 > s.goals.screenMin * 1.1 && week.length >= 3) {
    out.push({
      icon: 'chart',
      title: `Средний экран за неделю — ${fmtMin(avg7)}`,
      text: `Это выше твоей цели (${fmtMin(s.goals.screenMin)}). Снизь цель постепенно или начни с 15 минут фокуса в день.`,
      action: { label: 'Открыть фокус', href: 'focus.html' },
    });
  }

  if (!hasRules && s.mode !== 'soft' && topApps.length >= 3) {
    out.push({
      icon: 'shield',
      title: 'Ни одного лимита ещё не настроено',
      text: 'Выбери 1–2 приложения, которые забирают больше всего времени, и задай им дневной лимит. Остальное сделают уведомления.',
      action: { label: 'Выбрать приложения', href: 'apps.html' },
    });
  }

  const evening = (today.totalMin || 0) > 0 && (today.nightMin || 0) >= 20;
  if (evening) {
    out.push({
      icon: 'moon',
      title: 'Экран после начала сна',
      text: `Сегодня после ${s.sleep.start} ты провёл в телефоне ${fmtMin(today.nightMin)}. Попробуй оставить телефон на зарядке подальше от кровати.`,
      action: null,
    });
  }

  if ((today.restMin || 0) < 60 && (today.totalMin || 0) > 180) {
    out.push({
      icon: 'coffee',
      title: 'Мало пауз при большом экране',
      text: 'Короткие перерывы каждые 20–30 минут помогают меньше уставать и меньше залипать в ленте.',
      action: { label: 'Здоровье глаз', href: 'health.html' },
    });
  }

  if (!out.length) {
    out.push({
      icon: 'sparkles',
      title: 'Дисциплина в порядке',
      text: 'Экранное время в пределах цели, разблокировок немного. Продолжай в том же ритме — и следи за глазами: правило 20-20-20 никто не отменял.',
      action: { label: 'Здоровье глаз', href: 'health.html' },
    });
  }
  return out.slice(0, 4);
}

/** Еженедельный отчёт */
export function weeklyReport(series) {
  const week = (series || []).slice(-7);
  const prev = (series || []).slice(-14, -7);
  if (week.length < 2) return null;
  const avg = seriesAvg(week);
  const avgPrev = prev.length ? seriesAvg(prev) : null;
  const withData = week.filter((d) => d.totalMin > 0);
  const best = withData.length ? withData.reduce((a, b) => (a.totalMin <= b.totalMin ? a : b)) : null;
  const worst = withData.length ? withData.reduce((a, b) => (a.totalMin >= b.totalMin ? a : b)) : null;
  const unlockAvg = week.reduce((a, d) => a + (d.unlocks || 0), 0) / Math.max(1, withData.length);
  return {
    avg,
    avgPrev,
    delta: avgPrev != null ? Math.round(avgPrev - avg) : null,
    bestDay: best,
    worstDay: worst,
    unlockAvg: Math.round(unlockAvg),
  };
}
