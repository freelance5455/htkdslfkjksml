/* Focus Guardian — движок времени: сессии в приложении, напоминания в реальном времени, учёт перерывов */

import { Store, dayKey } from './storage.js';
import { Native, getLiveCached } from './native.js';
import { parseHM, nowMinutes, inWindow, dayKey as _dk, clamp } from './util.js';

export const Bus = new EventTarget();

const st = {
  visibleAt: Date.now(),
  hiddenAt: null,
  lastEyeFired: 0,
  bannerFired: {},
  timer: null,
  lastTick: Date.now(),
};

function isDemoOnly() {
  return !Native.isNative() && Native.demoActive();
}

/* ---- учёт открытого приложения (видимость страницы) ---- */

function onVisible() {
  const now = Date.now();
  if (st.hiddenAt) {
    const gapMin = (now - st.hiddenAt) / 60000;
    if (gapMin >= 1 && !isDemoOnly()) {
      // реальный перерыв: экран/страница были неактивны ≥ 1 минуты
      const d = Store.day();
      d.breaks += 1;
      d.restMin += Math.round(gapMin);
      if (gapMin > (d.longestOfflineMin || 0)) d.longestOfflineMin = Math.round(gapMin);
      Store.updateDay(dayKey(), d);
      Store.push('breaks', { ts: st.hiddenAt, sec: Math.round(gapMin * 60), type: 'auto' }, 500);
    }
  }
  st.hiddenAt = null;
  st.visibleAt = now;
  Bus.dispatchEvent(new CustomEvent('visibility', { detail: { visible: true } }));
}

function onHidden() {
  st.hiddenAt = Date.now();
  Bus.dispatchEvent(new CustomEvent('visibility', { detail: { visible: false } }));
}

/** Минут непрерывного использования Focus Guardian в этом открытии */
export function appOpenMin() {
  if (document.visibilityState !== 'visible') return (st.hiddenAt - st.visibleAt) / 60000;
  return (Date.now() - st.visibleAt) / 60000;
}

/* ---- тик движка (15 секунд) ---- */

async function tick() {
  st.lastTick = Date.now();
  const s = Store.settings();

  // Напоминания об отдыхе глаз, пока приложение открыто
  if (s.monitoring && s.eye.enabled && document.visibilityState === 'visible') {
    let sessionMin = appOpenMin();
    if (Native.isNative()) {
      const live = await getLiveCached(25000);
      if (live.ok && live.available && live.screenOn) {
        sessionMin = Math.max(sessionMin, (Date.now() - (live.sessionStartTs || Date.now())) / 60000);
      }
    }
    if (sessionMin >= s.eye.intervalMin && Date.now() - st.lastEyeFired > 60000) {
      st.lastEyeFired = Date.now();
      Bus.dispatchEvent(new CustomEvent('eye-rest-due', { detail: { sessionMin } }));
    }
  }

  // В браузерном режиме (без нативного слоя) — внутриприложенные банеры 20/40/60
  if (!Native.isNative() && s.monitoring && s.notify.enabled && document.visibilityState === 'visible') {
    const m = appOpenMin();
    const levels = [
      { at: 20, on: s.notify.session20, texts: ['Небольшая пауза! Ты уже 20 минут смотришь в экран. Отведи взгляд вдаль хотя бы на 20 секунд.'] },
      { at: 40, on: s.notify.session40, texts: ['Пора немного отдохнуть. Дай глазам передышку и отложи телефон на несколько минут.'] },
      { at: 60, on: s.notify.session60, texts: ['Час пролетел незаметно! Попробуй сделать перерыв на 10–15 минут.'] },
    ];
    for (const l of levels) {
      if (l.on && m >= l.at && Date.now() - (st.bannerFired[l.at] || 0) > 45 * 60000) {
        st.bannerFired[l.at] = Date.now();
        const { toast } = await import('./ui.js');
        toast(l.texts[0], 'info', 6000);
        Bus.dispatchEvent(new CustomEvent('session-level', { detail: { level: l.at } }));
      }
    }
  }

  // Ночное предупреждение при открытом приложении
  if (s.monitoring && s.sleep.warnings && s.notify.enabled && document.visibilityState === 'visible') {
    if (inWindow(nowMinutes(), s.sleep.start, s.sleep.end) && !isDemoOnly()) {
      const key = `night:${dayKey()}`;
      if (!st.bannerFired[key]) {
        st.bannerFired[key] = Date.now();
        Bus.dispatchEvent(new CustomEvent('night-warning'));
      }
    }
  }
}

/* ---- публичные helpers ---- */

/** Живое состояние: комбинирует нативные данные и локальные */
export async function getLive() {
  if (Native.isNative() || Native.demoActive()) {
    const r = await getLiveCached(0);
    if (r.ok && r.available) return r;
  }
  const d = Store.day();
  return {
    ok: true,
    available: false,
    screenOn: document.visibilityState === 'visible',
    sessionStartTs: st.visibleAt,
    lastRestTs: st.hiddenAt || null,
    restMinToday: d.restMin || 0,
    breaksToday: d.breaks || 0,
    unlocksToday: d.unlocks || 0,
    nightMin: d.nightMin || 0,
    longestOfflineMin: d.longestOfflineMin || 0,
  };
}

export function recordEyeBreak(seconds) {
  const d = Store.day();
  d.breaks += 1;
  Store.updateDay(dayKey(), d);
  Store.push('breaks', { ts: Date.now(), sec: Math.round(seconds), type: 'eye' }, 500);
}

/** Запланированные перерывы на текущее активное время */
export function plannedBreaks(activeMin, intervalMin) {
  return Math.floor(clamp(activeMin, 0, 24 * 60) / Math.max(1, intervalMin));
}

export function isNightNow() {
  const s = Store.settings();
  return inWindow(nowMinutes(), s.sleep.start, s.sleep.end);
}

export function startEngine() {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') onVisible();
    else onHidden();
  });
  if (!st.timer) st.timer = setInterval(tick, 15000);
  tick();
}
