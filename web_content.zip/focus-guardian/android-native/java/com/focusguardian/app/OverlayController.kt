package com.focusguardian.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

/**
 * Полноэкранный оверлей «Время вышло!» поверх заблокированного приложения.
 * Требует разрешение SYSTEM_ALERT_WINDOW («Поверх других окон»).
 */
object OverlayController {

    private var overlay: LinearLayout? = null
    private var countdownView: TextView? = null
    private var hintView: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var untilTs = 0L
    private var ticker: Runnable? = null

    fun show(context: Context, pkg: String, appLabel: String, blockUntil: Long, reason: String) {
        handler.post { showInternal(context.applicationContext, pkg, appLabel, blockUntil, reason) }
    }

    private fun showInternal(context: Context, pkg: String, appLabel: String, blockUntil: Long, reason: String) {
        hide()
        untilTs = if (blockUntil > 0) blockUntil else UsageStatsReader.endOfDay(System.currentTimeMillis())
        val strict = try {
            JSONObject(NativePrefs.getString(context, NativePrefs.KEY_RULES)).optBoolean("strict", false)
        } catch (e: Exception) { false }

        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dp = { v: Int -> Math.round(v * context.resources.displayMetrics.density) }

        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0B1020"))
            setPadding(dp(28), dp(28), dp(28), dp(28))
        }

        val icon = ImageView(context).apply {
            setImageResource(android.R.drawable.ic_lock_lock)
            colorFilter = android.graphics.PorterDuffColorFilter(Color.parseColor("#38C6FF"), android.graphics.PorterDuff.Mode.SRC_IN)
        }
        val iconWrap = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        iconWrap.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
        root.addView(iconWrap, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(26) })

        val title = TextView(context).apply {
            text = "Время вышло!"
            setTextColor(Color.WHITE)
            textSize = 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })

        val subtitle = TextView(context).apply {
            text = "Ты уже использовал установленный лимит\nв приложении «$appLabel».\n\nСделай небольшую паузу. Телефон никуда не убежит."
            setTextColor(Color.parseColor("#9AA7C7"))
            textSize = 15f
            gravity = Gravity.CENTER
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        root.addView(subtitle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(24) })

        val countdown = TextView(context).apply {
            setTextColor(Color.parseColor("#8B7CFF"))
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        countdownView = countdown
        root.addView(countdown, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(30) })

        val btnBg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.parseColor("#1A2440"))
            setStroke(1, Color.parseColor("#38C6FF"))
        }
        val homeBtn = Button(context).apply {
            text = "Вернуться на главный экран"
            setTextColor(Color.WHITE)
            textSize = 14f
            isAllCaps = false
            background = btnBg
            setPadding(dp(20), dp(14), dp(20), dp(14))
        }
        root.addView(homeBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { bottomMargin = dp(10) })

        val hint = TextView(context).apply {
            setTextColor(Color.parseColor("#66739A"))
            textSize = 12f
            gravity = Gravity.CENTER
            text = if (strict) "Строгий режим: удерживайте кнопку 1,5 секунды" else "Экран исчезнет, когда таймер истечёт"
        }
        hintView = hint
        root.addView(hint, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        fun goHome() {
            hide()
            val svc = BlockerAccessibilityService.instance
            if (svc != null) {
                svc.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
            } else {
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { context.startActivity(intent) } catch (e: Exception) { /* нет лаунчера */ }
            }
        }

        if (strict) {
            var holdStart = 0L
            homeBtn.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        holdStart = SystemClock.uptimeMillis()
                        v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
                    }
                    MotionEvent.ACTION_UP -> {
                        v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                        if (SystemClock.uptimeMillis() - holdStart >= 1500) goHome()
                        else hint.text = "Удерживайте кнопку 1,5 секунды, чтобы вернуться"
                    }
                    MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                }
                true
            }
        } else {
            homeBtn.setOnClickListener { goHome() }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        try {
            wm.addView(root, params)
            overlay = root
        } catch (e: Exception) {
            return
        }

        updateCountdown()
        val run = object : Runnable {
            override fun run() {
                if (overlay == null) return
                if (System.currentTimeMillis() >= untilTs) {
                    hide()
                    return
                }
                updateCountdown()
                handler.postDelayed(this, 1000)
            }
        }
        ticker = run
        handler.postDelayed(run, 1000)
    }

    private fun updateCountdown() {
        val cv = countdownView ?: return
        val leftMin = ((untilTs - System.currentTimeMillis()) / 60000L).toInt().coerceAtLeast(0)
        val text = if (leftMin >= 60) {
            val h = leftMin / 60
            val m = leftMin % 60
            if (m == 0) "Разблокировка через $h ч"
            else "Разблокировка через $h ч $m мин"
        } else {
            "Разблокировка через $leftMin мин"
        }
        cv.text = text
    }

    fun hide() {
        ticker?.let { handler.removeCallbacks(it) }
        ticker = null
        countdownView = null
        hintView = null
        overlay?.let {
            try {
                (it.context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it)
            } catch (e: Exception) { /* уже удалён */ }
        }
        overlay = null
    }

    fun isShowing(): Boolean = overlay != null
}
