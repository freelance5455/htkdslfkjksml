package com.focusguardian.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.util.Calendar

/** Разобранная конфигурация (зеркало настроек из JS-части). */
data class FgConfig(
    val monitoring: Boolean = true,
    val mode: String = "standard",
    val notifyEnabled: Boolean = true,
    val strictness: String = "normal",
    val session20: Boolean = true,
    val session40: Boolean = true,
    val session60: Boolean = true,
    val limitReached: Boolean = true,
    val endOfDay: Boolean = true,
    val restCelebration: Boolean = true,
    val nightWarning: Boolean = true,
    val vibration: Boolean = true,
    val sound: String = "gentle",
    val eyeEnabled: Boolean = true,
    val eyeIntervalMin: Int = 20,
    val sleepStart: String = "23:00",
    val sleepEnd: String = "07:00",
    val walkEnabled: Boolean = true,
    val walkEveryMin: Int = 90,
    val stretchEnabled: Boolean = true,
    val stretchEveryMin: Int = 120,
    val autoSuggest: Boolean = true,
    val autoSuggestAfterMin: Int = 120,
    val dailyLimitMin: Int = 240,
    val summaryTime: String = "21:30"
) {
    companion object {
        fun parse(ctx: Context): FgConfig {
            val raw = NativePrefs.getString(ctx, NativePrefs.KEY_CONFIG)
            val j = try { if (raw.isNotBlank()) JSONObject(raw) else JSONObject() } catch (e: Exception) { JSONObject() }
            val n = j.optJSONObject("notify") ?: JSONObject()
            val sleep = j.optJSONObject("sleep") ?: JSONObject()
            val eye = j.optJSONObject("eye") ?: JSONObject()
            val walk = j.optJSONObject("walk") ?: JSONObject()
            val stretch = j.optJSONObject("stretch") ?: JSONObject()
            val rest = j.optJSONObject("rest") ?: JSONObject()
            return FgConfig(
                monitoring = j.optBoolean("monitoring", true),
                mode = j.optString("mode", "standard"),
                notifyEnabled = n.optBoolean("enabled", true),
                strictness = n.optString("strictness", "normal"),
                session20 = n.optBoolean("session20", true),
                session40 = n.optBoolean("session40", true),
                session60 = n.optBoolean("session60", true),
                limitReached = n.optBoolean("limitReached", true),
                endOfDay = n.optBoolean("endOfDay", true),
                restCelebration = n.optBoolean("restCelebration", true),
                nightWarning = n.optBoolean("nightWarning", true),
                vibration = n.optBoolean("vibration", true),
                sound = n.optString("sound", "gentle"),
                eyeEnabled = eye.optBoolean("enabled", true),
                eyeIntervalMin = eye.optInt("intervalMin", 20),
                sleepStart = sleep.optString("start", "23:00"),
                sleepEnd = sleep.optString("end", "07:00"),
                walkEnabled = walk.optBoolean("enabled", true),
                walkEveryMin = walk.optInt("everyMin", 90),
                stretchEnabled = stretch.optBoolean("enabled", true),
                stretchEveryMin = stretch.optInt("everyMin", 120),
                autoSuggest = rest.optBoolean("autoSuggest", true),
                autoSuggestAfterMin = rest.optInt("afterMin", 120),
                dailyLimitMin = j.optInt("dailyLimitMin", 240),
                summaryTime = j.optString("summaryTime", "21:30")
            )
        }
    }

    /** Внутри ночного окна сна? */
    fun isSleepWindow(now: Long = System.currentTimeMillis()): Boolean {
        val c = Calendar.getInstance()
        c.timeInMillis = now
        val cur = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val (sh, sm) = parseHM(sleepStart)
        val (eh, em) = parseHM(sleepEnd)
        val s = sh * 60 + sm
        val e = eh * 60 + em
        if (s == e) return false
        return if (s < e) cur in s until e else cur >= s || cur < e
    }

    private fun parseHM(v: String): Pair<Int, Int> {
        val parts = v.split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return Pair(h, m)
    }
}

/** Каналы уведомлений. */
object NotificationChannels {
    const val CH_REMINDERS = "fg_reminders"
    const val CH_BLOCKING = "fg_blocking"
    const val CH_SUMMARY = "fg_summary"
    const val CH_SERVICE = "fg_service"

    fun ensure(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CH_REMINDERS, "Напоминания об отдыхе", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Паузы для глаз и предложения отдохнуть"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_BLOCKING, "Блокировка приложений", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Достижение лимитов и экраны блокировки"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SUMMARY, "Итоги дня", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Вечерняя сводка экранного времени"
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "Фоновый мониторинг", NotificationManager.IMPORTANCE_MIN).apply {
                description = "Служебное уведомление фонового сервиса"
                setShowBadge(false)
            }
        )
    }
}

/**
 * Умный движок уведомлений: уровни непрерывного использования, дедупликация,
 * тихие ночные часы, похвала за отдых, ночные предупреждения, прогулки/разминка.
 */
object ReminderEngine {

    private val PHRASES_20 = listOf(
        "Небольшая пауза! Ты уже 20 минут смотришь в экран. Отведи взгляд вдаль хотя бы на 20 секунд.",
        "20 минут за экраном. Моргни пару раз и посмотри в окно — глаза скажут спасибо.",
        "Маленький совет: найди взглядом самый дальний предмет и посмотри на него 20 секунд."
    )
    private val PHRASES_40 = listOf(
        "Пора немного отдохнуть. Дай глазам передышку и отложи телефон на несколько минут.",
        "40 минут непрерывно! Встань, потянись и посмотри вдаль — это займёт меньше минуты.",
        "Экран подождёт. Две минуты перерыва вернут тебе свежесть."
    )
    private val PHRASES_60 = listOf(
        "Час пролетел незаметно! Попробуй сделать перерыв на 10–15 минут.",
        "Целый час у экрана. Идеальное время для короткой прогулки или стакана воды.",
        "Час работы за экраном — устроим паузу? Тело и глаза заслужили."
    )
    private val PHRASES_90 = listOf(
        "Полтора часа без паузы — это много. Обязательно сделай перерыв прямо сейчас.",
        "Экран не убежит. 15 минут отдыха вернут тебе концентрацию."
    )
    private val PHRASES_LIMIT = listOf(
        "Ты достиг установленного лимита. Может, пора заняться чем-нибудь другим?",
        "Лимит этого приложения исчерпан. Телефон никуда не убежит — отдохни.",
        "Время в этом приложении закончилось. Как насчёт паузы?"
    )
    private val PHRASES_NIGHT = listOf(
        "Пора спать. Экран крадёт глубокий сон — телефон подождёт до утра.",
        "Ночь за окном, а ты ещё в телефоне. Попробуй отложить его и закрыть глаза.",
        "Лучший подарок себе перед сном — тихий вечер без ленты."
    )
    private val PHRASES_WALK = listOf(
        "Разомнитесь: короткая прогулка или пара наклонов вернут бодрость.",
        "Тело затекало! Встань и походи хотя бы пару минут.",
        "Мини-зарядка для тела: потянись, подыши, пройдись по комнате."
    )
    private val PHRASES_SUGGEST_REST = listOf(
        "Ты в телефоне уже {MIN}. Предлагаю перерыв: режим «Время для себя» на 10–15 минут.",
        "Долгий сеанс! Как насчёт паузы на 15 минут без экрана?"
    )

    /** Дедупликация: тип -> ts последнего показа. */
    private fun state(ctx: Context): JSONObject =
        try { JSONObject(NativePrefs.getString(ctx, NativePrefs.KEY_REMINDER_STATE, "{}")) }
        catch (e: Exception) { JSONObject() }

    private fun saveState(ctx: Context, st: JSONObject) {
        NativePrefs.putJson(ctx, NativePrefs.KEY_REMINDER_STATE, st.toString())
    }

    private fun lastShown(ctx: Context, type: String, now: Long, cooldownMin: Long): Boolean {
        val st = state(ctx)
        val last = st.optLong(type, 0L)
        return last > 0 && (now - last) < cooldownMin * 60000L
    }

    private fun markShown(ctx: Context, type: String, now: Long) {
        val st = state(ctx)
        st.put(type, now)
        saveState(ctx, st)
    }

    fun notify(ctx: Context, channel: String, id: Int, title: String, text: String, cfg: FgConfig = FgConfig.parse(ctx), silent: Boolean = false) {
        NotificationChannels.ensure(ctx)
        val intent = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
        val pi = PendingIntent.getActivity(
            ctx, id, intent ?: Intent(),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val soundUri = when (cfg.sound) {
            "none", "" -> null
            "gentle" -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            else -> RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        }
        val builder = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        if (cfg.vibration) builder.setVibrate(longArrayOf(0, 220, 120, 220))
        if (silent || cfg.sound == "none") builder.setSilent(true) else builder.setSound(soundUri)
        try {
            androidx.core.app.NotificationManagerCompat.from(ctx).notify(id, builder.build())
        } catch (e: SecurityException) {
            // POST_NOTIFICATIONS не выдано — игнорируем
        }
    }

    /** Тик движка: sessionMin — непрерывное активное время за экраном (в минутах). */
    fun tick(ctx: Context, sessionMin: Int, screenOn: Boolean) {
        val cfg = FgConfig.parse(ctx)
        val now = System.currentTimeMillis()
        if (!cfg.monitoring || !cfg.notifyEnabled) return
        if (cfg.isSleepWindow(now)) {
            // Ночью: только одно предупреждение
            if (cfg.nightWarning && screenOn && sessionMin >= 10 && !lastShown(ctx, "night", now, 8 * 60)) {
                markShown(ctx, "night", now)
                NativePrefs.addDateInt(ctx, "night", 1)
                notify(ctx, NotificationChannels.CH_REMINDERS, 2001, "Пора спать", PHRASES_NIGHT.random(), cfg)
            }
            return
        }

        // Уровни непрерывного сеанса
        val levels: List<Int> = when (cfg.strictness) {
            "soft" -> listOf(40, 60)
            "strict" -> listOf(20, 40, 60, 90)
            else -> listOf(20, 40, 60)
        }
        for (level in levels) {
            val enabled = when (level) {
                20 -> cfg.session20
                40 -> cfg.session40
                60 -> cfg.session60
                else -> true
            }
            if (!enabled) continue
            if (sessionMin >= level && !lastShown(ctx, "session_$level", now, 45)) {
                markShown(ctx, "session_$level", now)
                val text = when (level) {
                    20 -> PHRASES_20.random()
                    40 -> PHRASES_40.random()
                    60 -> PHRASES_60.random()
                    else -> PHRASES_90.random()
                }
                notify(ctx, NotificationChannels.CH_REMINDERS, 2000 + level, "Пауза для глаз", text, cfg)
            }
        }

        // Прогулка / разминка
        if (cfg.walkEnabled && sessionMin > 0 && sessionMin % maxOf(15, cfg.walkEveryMin) == 0 && !lastShown(ctx, "walk_${sessionMin}", now, 55)) {
            markShown(ctx, "walk_${sessionMin}", now)
            notify(ctx, NotificationChannels.CH_REMINDERS, 2101, "Разминка", PHRASES_WALK.random(), cfg)
        }

        // Предложение отдыха
        if (cfg.autoSuggest && sessionMin >= cfg.autoSuggestAfterMin && !lastShown(ctx, "suggest", now, 90)) {
            markShown(ctx, "suggest", now)
            notify(ctx, NotificationChannels.CH_REMINDERS, 2102, "Время для себя",
                PHRASES_SUGGEST_REST.random().replace("{MIN}", "${sessionMin} минут"), cfg)
        }
    }

    /** Похвала за длительный отдых (вызывается при включении экрана после долгой паузы). */
    fun restCelebration(ctx: Context, restMin: Int) {
        val cfg = FgConfig.parse(ctx)
        val now = System.currentTimeMillis()
        if (!cfg.monitoring || !cfg.notifyEnabled || !cfg.restCelebration) return
        if (cfg.isSleepWindow(now)) return
        if (restMin < 30) return
        if (lastShown(ctx, "rest_celebration", now, 120)) return
        markShown(ctx, "rest_celebration", now)
        notify(ctx, NotificationChannels.CH_REMINDERS, 2103, "Отлично!",
            "Ты уже ${restMin} минут не пользовался телефоном. Это настоящая пауза!", cfg)
    }

    /** Достижение лимита приложения (мягкий режим: только уведомление). */
    fun limitReached(ctx: Context, appLabel: String) {
        val cfg = FgConfig.parse(ctx)
        val now = System.currentTimeMillis()
        if (!cfg.monitoring || !cfg.notifyEnabled || !cfg.limitReached) return
        if (cfg.mode == "soft") {
            if (lastShown(ctx, "limit_$appLabel", now, 60)) return
            markShown(ctx, "limit_$appLabel", now)
            notify(ctx, NotificationChannels.CH_BLOCKING, 2104, appLabel, PHRASES_LIMIT.random(), cfg)
        } else if (lastShown(ctx, "limit_$appLabel", now, 60).not()) {
            markShown(ctx, "limit_$appLabel", now)
            notify(ctx, NotificationChannels.CH_BLOCKING, 2104, appLabel, PHRASES_LIMIT.random(), cfg)
        }
    }

    /** Итоги дня. */
    fun dailySummary(ctx: Context) {
        val cfg = FgConfig.parse(ctx)
        if (!cfg.monitoring || !cfg.notifyEnabled || !cfg.endOfDay) return
        val byApp = try {
            JSONObject(NativePrefs.getJson(ctx, NativePrefs.KEY_DAILY_CACHE))
        } catch (e: Exception) { JSONObject() }
        val total = UsageStatsReader.totalMin(byApp)
        val h = total / 60
        val m = total % 60
        val text = if (total <= 0) {
            "Сегодня статистика не собиралась. Проверь разрешения в приложении."
        } else {
            "Сегодня ты провёл в телефоне ${h} ч ${m} мин. Завтра попробуем немного сократить это время?"
        }
        notify(ctx, NotificationChannels.CH_SUMMARY, 3001, "Итоги дня", text, cfg)
    }
}
