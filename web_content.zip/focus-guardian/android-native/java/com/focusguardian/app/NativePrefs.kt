package com.focusguardian.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** SharedPreferences-хранилище, общее для всех нативных компонентов. */
object NativePrefs {
    private const val FILE = "focus_guardian_native"

    const val KEY_CONFIG = "config_json"
    const val KEY_RULES = "rules_json"
    const val KEY_SESSION_STATE = "session_state_json"
    const val KEY_REMINDER_STATE = "reminder_state_json"
    const val KEY_DAILY_CACHE = "daily_cache_json"
    const val KEY_SESSIONS_LOG = "sessions_log_json"
    const val KEY_EXCEEDED = "exceeded_json"
    const val KEY_BLOCKS = "blocks_json"
    const val KEY_FGS_RUNNING = "fgs_running"
    const val KEY_FGS_EVER = "fgs_ever_ran"
    const val KEY_SCREEN_ON = "screen_on"
    const val KEY_SESSION_START = "session_start_ts"
    const val KEY_LAST_REST_TS = "last_rest_ts"
    const val KEY_LAST_TICK = "last_tick_ts"
    const val KEY_LAST_SYNC = "last_stats_sync_ts"
    const val KEY_FG_VERSION = "prefs_version"

    fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun todayKey(): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun putString(ctx: Context, key: String, value: String) {
        prefs(ctx).edit().putString(key, value).apply()
    }

    fun getString(ctx: Context, key: String, def: String = ""): String =
        prefs(ctx).getString(key, def) ?: def

    fun putLong(ctx: Context, key: String, value: Long) {
        prefs(ctx).edit().putLong(key, value).apply()
    }

    fun getLong(ctx: Context, key: String, def: Long = 0L): Long =
        prefs(ctx).getLong(key, def)

    fun putInt(ctx: Context, key: String, value: Int) {
        prefs(ctx).edit().putInt(key, value).apply()
    }

    fun getInt(ctx: Context, key: String, def: Int = 0): Int =
        prefs(ctx).getInt(key, def)

    fun putBool(ctx: Context, key: String, value: Boolean) {
        prefs(ctx).edit().putBoolean(key, value).apply()
    }

    fun getBool(ctx: Context, key: String, def: Boolean = false): Boolean =
        prefs(ctx).getBoolean(key, def)

    /** Дата-суффиксные счётчики: unlocks_2026-11-20, rest_..., breaks_..., night_... */
    fun dateInt(ctx: Context, prefix: String, dateKey: String = todayKey()): Int =
        getInt(ctx, "${prefix}_$dateKey")

    fun addDateInt(ctx: Context, prefix: String, delta: Int, dateKey: String = todayKey()): Int {
        val cur = dateInt(ctx, prefix, dateKey) + delta
        putInt(ctx, "${prefix}_$dateKey", cur)
        return cur
    }

    fun setDateInt(ctx: Context, prefix: String, value: Int, dateKey: String = todayKey()) {
        putInt(ctx, "${prefix}_$dateKey", value)
    }

    fun putJson(ctx: Context, key: String, json: String) = putString(ctx, key, json)

    fun getJson(ctx: Context, key: String): String = getString(ctx, key)

    /** Чистка старых date-ключей (хранение ~120 дней). */
    fun pruneOld(ctx: Context, keepDays: Int = 120) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cutoff = sdf.format(Date(System.currentTimeMillis() - keepDays * 86400000L))
        val prefixes = listOf("unlocks", "rest", "breaks", "night", "blocks", "exceeded", "limit_notified")
        val all = prefs(ctx).all
        for ((k, _) in all) {
            val idx = k.lastIndexOf('_')
            if (idx <= 0 || idx == k.length - 1) continue
            val datePart = k.substring(idx + 1)
            val prefix = k.substring(0, idx)
            if (prefix in prefixes && datePart.length == 10 && datePart < cutoff) {
                prefs(ctx).edit().remove(k).apply()
            }
        }
    }
}
