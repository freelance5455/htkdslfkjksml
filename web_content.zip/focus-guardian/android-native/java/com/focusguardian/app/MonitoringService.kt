package com.focusguardian.app

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject

/**
 * Foreground-сервис: считает непрерывные сеансы, разблокировки, отдых,
 * синхронизирует статистику, будит движок уведомлений и журнал блокировок.
 */
class MonitoringService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var tickRunnable: Runnable? = null

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> onScreenOff()
                Intent.ACTION_SCREEN_ON -> NativePrefs.putBool(context, NativePrefs.KEY_SCREEN_ON, true)
                Intent.ACTION_USER_PRESENT -> onUnlock()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.ensure(this)

        val notif = serviceNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            val type = if (Build.VERSION.SDK_INT >= 34) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else 0
            ServiceCompat.startForeground(this, NOTIF_ID, notif, type)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(screenReceiver, filter)

        NativePrefs.putBool(this, NativePrefs.KEY_FGS_RUNNING, true)
        NativePrefs.putBool(this, NativePrefs.KEY_FGS_EVER, true)

        DailySummaryReceiver.schedule(this)
        startTick()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        tickRunnable?.let { handler.removeCallbacks(it) }
        try {
            unregisterReceiver(screenReceiver)
        } catch (e: Exception) { /* не был зарегистрирован */ }
        NativePrefs.putBool(this, NativePrefs.KEY_FGS_RUNNING, false)
        super.onDestroy()
    }

    private fun serviceNotification(): android.app.Notification {
        val pi = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }
        return NotificationCompat.Builder(this, NotificationChannels.CH_SERVICE)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Focus Guardian")
            .setContentText("Мониторинг экранного времени активен")
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun startTick() {
        tickRunnable?.let { handler.removeCallbacks(it) }
        val r = object : Runnable {
            override fun run() {
                doTick()
                handler.postDelayed(this, TICK_MS)
            }
        }
        tickRunnable = r
        handler.post(r)
    }

    private fun onScreenOff() {
        val now = System.currentTimeMillis()
        NativePrefs.putBool(this, NativePrefs.KEY_SCREEN_ON, false)
        val sessionStart = NativePrefs.getLong(this, NativePrefs.KEY_SESSION_START)
        if (sessionStart > 0) {
            NativePrefs.putLong(this, NativePrefs.KEY_SESSION_START, 0)
            NativePrefs.putLong(this, NativePrefs.KEY_LAST_REST_TS, now)
            NativePrefs.putLong(this, "rest_start_ts", now)
        }
    }

    private fun onUnlock() {
        val now = System.currentTimeMillis()
        NativePrefs.putBool(this, NativePrefs.KEY_SCREEN_ON, true)
        NativePrefs.addDateInt(this, "unlocks", 1)
        // засчитываем перерыв, если экран был выключен
        val restStart = NativePrefs.getLong(this, "rest_start_ts")
        if (restStart > 0) {
            val gapMs = now - restStart
            val gapMin = (gapMs / 60000L).toInt()
            if (gapMin >= 1) NativePrefs.addDateInt(this, "rest", gapMin)
            if (gapMs >= 20000) NativePrefs.addDateInt(this, "breaks", 1)
            val longest = NativePrefs.getInt(this, "longest_offline_" + NativePrefs.todayKey())
            if (gapMin > longest) NativePrefs.setInt(this, "longest_offline_" + NativePrefs.todayKey(), gapMin)
            NativePrefs.putLong(this, "rest_start_ts", 0)
            ReminderEngine.restCelebration(this, gapMin)
        }
        NativePrefs.putLong(this, NativePrefs.KEY_SESSION_START, now)
    }

    private fun doTick() {
        val now = System.currentTimeMillis()
        NativePrefs.putLong(this, NativePrefs.KEY_LAST_TICK, now)
        NativePrefs.pruneOld(this)

        val screenOn = NativePrefs.getBool(this, NativePrefs.KEY_SCREEN_ON, false)
        val sessionStart = NativePrefs.getLong(this, NativePrefs.KEY_SESSION_START)
        val sessionMin = if (screenOn && sessionStart > 0) ((now - sessionStart) / 60000L).toInt() else 0

        // Движок напоминаний
        ReminderEngine.tick(this, sessionMin, screenOn)

        // Проверка завершения сеанса фокуса/отдыха
        checkSessionEnd(now)

        // Синхронизация статистики
        if (UsageStatsReader.hasUsageAccess(this)) {
            try {
                val dayStart = UsageStatsReader.startOfDay(now)
                val byApp = UsageStatsReader.queryByApp(this, dayStart, now)
                NativePrefs.putJson(this, NativePrefs.KEY_DAILY_CACHE, byApp.toString())
                NativePrefs.putLong(this, NativePrefs.KEY_LAST_SYNC, now)

                // Достижение лимитов (для мягкого режима — уведомления; жёсткие решает сервис блокировки)
                checkLimits(byApp)
            } catch (e: Exception) {
                // статистика недоступна — не критично
            }
        }
    }

    private fun checkSessionEnd(now: Long) {
        val raw = NativePrefs.getString(this, NativePrefs.KEY_SESSION_STATE)
        if (raw.isBlank()) return
        val st = try { JSONObject(raw) } catch (e: Exception) { return }
        val endsTs = st.optLong("endsTs", 0)
        if (endsTs in 1..now) {
            val kind = st.optString("kind", "focus")
            val startedTs = st.optLong("startedTs", endsTs - (st.optInt("minutes", 0) * 60000L))
            val plannedMin = st.optInt("minutes", 0)
            val violations = st.optInt("violations", 0)
            appendSessionLog(
                this,
                JSONObject()
                    .put("startedTs", startedTs)
                    .put("endedTs", now)
                    .put("plannedMin", plannedMin)
                    .put("actualMin", ((now - startedTs) / 60000L).toInt())
                    .put("success", true)
                    .put("violations", violations)
            )
            NativePrefs.putJson(this, NativePrefs.KEY_SESSION_STATE, "")
            if (kind == "focus") {
                ReminderEngine.notify(this, NotificationChannels.CH_SUMMARY, 3002, "Сеанс фокуса завершён",
                    "Ты удержал концентрацию $plannedMin мин. Отличная работа!")
            } else {
                ReminderEngine.notify(this, NotificationChannels.CH_SUMMARY, 3003, "Отдых завершён",
                    "Продолжай день с комфортом. Пауза была полезной!")
            }
        }
    }

    private fun checkLimits(byApp: JSONObject) {
        val rulesRaw = NativePrefs.getString(this, NativePrefs.KEY_RULES)
        if (rulesRaw.isBlank()) return
        val rules = try { JSONObject(rulesRaw) } catch (e: Exception) { return }
        val byPkg = rules.optJSONObject("byPkg") ?: return
        val mode = rules.optString("mode", "standard")
        val cfg = FgConfig.parse(this)
        if (!cfg.limitReached) return
        val notified = try {
            JSONObject(NativePrefs.getString(this, "limit_notified_" + NativePrefs.todayKey(), "{}"))
        } catch (e: Exception) { JSONObject() }

        for (key in byPkg.keys()) {
            val rule = byPkg.optJSONObject(key) ?: continue
            val limit = rule.optInt("limitMin", 0)
            if (limit <= 0) continue
            val used = byApp.optJSONObject(key)?.optInt("timeMin", 0) ?: 0
            if (used >= limit && !notified.optBoolean(key, false)) {
                notified.put(key, true)
                NativePrefs.putString(this, "limit_notified_" + NativePrefs.todayKey(), notified.toString())
                // журнал превышений
                val arr = try {
                    JSONArrayCompat.parse(NativePrefs.getString(this, NativePrefs.KEY_EXCEEDED))
                } catch (e: Exception) { JSONArrayCompat.empty() }
                arr.put(JSONObject().put("pkg", key).put("ts", System.currentTimeMillis()))
                NativePrefs.putString(this, NativePrefs.KEY_EXCEEDED, arr.toString())
                val label = appLabel(key)
                ReminderEngine.limitReached(this, label)
                if (mode == "soft") {
                    // в мягком режиме блокировок нет — уведомление уже отправлено
                }
            }
        }
    }

    fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg.substringAfterLast('.').ifBlank { pkg }
    }

    companion object {
        const val NOTIF_ID = 100
        const val TICK_MS = 60_000L
        const val ACTION_STOP = "com.focusguardian.app.STOP_SERVICE"
        private const val SESSIONS_LOG_MAX = 300

        fun start(ctx: Context) {
            val cfg = FgConfig.parse(ctx)
            if (!cfg.monitoring) return
            val intent = Intent(ctx, MonitoringService::class.java)
            try {
                ctx.startService(intent)
            } catch (e: Exception) {
                // старт из фона ограничен на некоторых прошивках — сервис поднимется из MainActivity
            }
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, MonitoringService::class.java).setAction(ACTION_STOP))
        }

        fun appendSessionLog(ctx: Context, entry: JSONObject) {
            val arr = try { JSONArrayCompat.parse(NativePrefs.getString(ctx, NativePrefs.KEY_SESSIONS_LOG)) } catch (e: Exception) { JSONArrayCompat.empty() }
            arr.put(entry)
            while (arr.length() > SESSIONS_LOG_MAX) arr.remove(0)
            NativePrefs.putString(ctx, NativePrefs.KEY_SESSIONS_LOG, arr.toString())
        }

        fun appendBlockLog(ctx: Context, pkg: String, reason: String) {
            val key = "blocks_" + NativePrefs.todayKey()
            val arr = try { JSONArrayCompat.parse(NativePrefs.getString(ctx, key)) } catch (e: Exception) { JSONArrayCompat.empty() }
            arr.put(JSONObject().put("pkg", pkg).put("reason", reason).put("ts", System.currentTimeMillis()))
            while (arr.length() > 200) arr.remove(0)
            NativePrefs.putString(ctx, key, arr.toString())
        }
    }
}

/** Мини-обёртка над org.json.JSONArray, чтобы не тащить try/catch в каждом месте. */
object JSONArrayCompat {
    fun parse(raw: String): org.json.JSONArray = if (raw.isBlank()) empty() else org.json.JSONArray(raw)
    fun empty(): org.json.JSONArray = org.json.JSONArray()
}
