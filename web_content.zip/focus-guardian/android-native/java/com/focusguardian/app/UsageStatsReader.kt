package com.focusguardian.app

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStats
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Process
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Чтение реальной статистики использования через UsageStatsManager.
 * Требует разрешения «Доступ к данным об использовании» (PACKAGE_USAGE_STATS).
 */
object UsageStatsReader {

    fun hasUsageAccess(ctx: Context): Boolean {
        val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            appOps.unsafeCheckOpNoThrow("android:get_usage_stats", Process.myUid(), ctx.packageName)
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow("android:get_usage_stats", Process.myUid(), ctx.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun startOfDay(ts: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    fun endOfDay(ts: Long = System.currentTimeMillis()): Long =
        startOfDay(ts) + 86400000L

    fun dateKeyOf(ts: Long): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date(ts))

    /** Агрегированная статистика по приложениям за интервал [from, to]. */
    fun queryByApp(ctx: Context, from: Long, to: Long): JSONObject {
        val out = JSONObject()
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            ?: return out
        if (!hasUsageAccess(ctx)) return out

        // Время на переднем плане
        val stats: List<UsageStats> = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_BEST, from, to
        ) ?: emptyList()

        val lastUsed = HashMap<String, Long>()
        for (s in stats) {
            val pkg = s.packageName ?: continue
            if (pkg == ctx.packageName) continue
            val prev = out.optJSONObject(pkg)
            val addMs = s.totalTimeInForeground
            val obj = prev ?: JSONObject()
            obj.put("timeMin", (obj.optDouble("timeMin", 0.0) + addMs / 60000.0))
            out.put(pkg, obj)
            val lu = s.lastTimeUsed
            if (lu > (lastUsed[pkg] ?: 0L)) lastUsed[pkg] = lu
        }

        // Запуски (ACTIVITY_RESUMED) и последнее использование
        val launches = HashMap<String, Int>()
        val events = usm.queryEvents(from, to)
        val ev = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            val pkg = ev.packageName ?: continue
            if (pkg == ctx.packageName) continue
            val t = ev.eventType
            if (t == UsageEvents.Event.ACTIVITY_RESUMED) {
                launches[pkg] = (launches[pkg] ?: 0) + 1
                val prevLu = lastUsed[pkg] ?: 0L
                if (ev.timeStamp > prevLu) lastUsed[pkg] = ev.timeStamp
            }
        }

        val keys = JSONArray()
        for (key in out.keys()) {
            val obj = out.getJSONObject(key)
            obj.put("timeMin", Math.round(obj.optDouble("timeMin", 0.0)))
            obj.put("launches", launches[key] ?: 0)
            obj.put("lastTs", lastUsed[key] ?: 0L)
            keys.put(key)
        }
        for (key in launches.keys) {
            if (!out.has(key)) {
                out.put(key, JSONObject().put("timeMin", 0).put("launches", launches[key]).put("lastTs", lastUsed[key] ?: 0L))
            }
        }
        return out
    }

    fun totalMin(byApp: JSONObject): Int {
        var sum = 0
        for (key in byApp.keys()) sum += byApp.optJSONObject(key)?.optInt("timeMin", 0) ?: 0
        return sum
    }

    fun launchesTotal(byApp: JSONObject): Int {
        var sum = 0
        for (key in byApp.keys()) sum += byApp.optJSONObject(key)?.optInt("launches", 0) ?: 0
        return sum
    }

    /** Оценка разблокировок за период: число переходов во «включённый» экран (API 30+). */
    fun interactiveTransitions(ctx: Context, from: Long, to: Long): Int {
        if (Build.VERSION.SDK_INT < 30) return -1
        val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager ?: return -1
        if (!hasUsageAccess(ctx)) return -1
        var count = 0
        val events = usm.queryEvents(from, to)
        val ev = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(ev)
            if (ev.eventType == UsageEvents.Event.SCREEN_INTERACTIVE) count++
        }
        return count
    }

    /** Дневная серия за последние days дней: {date,totalMin,launches,unlocks}. */
    fun dailySeries(ctx: Context, days: Int): JSONArray {
        val arr = JSONArray()
        val today = startOfDay()
        for (i in days - 1 downTo 0) {
            val dayStart = today - i * 86400000L
            val dayEnd = if (i == 0) System.currentTimeMillis() else dayStart + 86400000L
            val byApp = queryByApp(ctx, dayStart, dayEnd)
            val unlocks = if (i == 0) {
                // за сегодня предпочесть счётчики сервиса, если они есть
                val svc = NativePrefs.dateInt(ctx, "unlocks")
                if (svc > 0) svc else interactiveTransitions(ctx, dayStart, dayEnd)
            } else {
                interactiveTransitions(ctx, dayStart, dayEnd)
            }
            arr.put(
                JSONObject()
                    .put("date", dateKeyOf(dayStart))
                    .put("totalMin", totalMin(byApp))
                    .put("launches", launchesTotal(byApp))
                    .put("unlocks", unlocks)
            )
        }
        return arr
    }

    /** Запускаемые приложения (с иконками в лаунчере). */
    fun installedApps(ctx: Context): JSONArray {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        val arr = JSONArray()
        val seen = HashSet<String>()
        for (ri in resolveInfos) {
            val pkg = ri.activityInfo?.packageName ?: continue
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val appInfo = try {
                pm.getApplicationInfo(pkg, 0)
            } catch (e: PackageManager.NameNotFoundException) {
                continue
            }
            val label = try {
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                pkg
            }
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            arr.put(
                JSONObject()
                    .put("pkg", pkg)
                    .put("label", label)
                    .put("system", isSystem)
            )
        }
        return arr
    }

    private fun drawableToBitmap(drawable: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, size, size)
        drawable.draw(canvas)
        return bmp
    }

    /** Иконка приложения в base64 PNG (кэшируется в filesDir/icons). */
    fun iconBase64(ctx: Context, pkg: String): String? {
        return try {
            val dir = File(ctx.filesDir, "icons")
            if (!dir.exists()) dir.mkdirs()
            val f = File(dir, pkg.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".png")
            if (f.exists() && f.length() > 0) {
                val bytes = ByteArray(f.length().toInt())
                FileInputStream(f).use { it.read(bytes) }
                Base64.encodeToString(bytes, Base64.NO_WRAP)
            } else {
                val pm = ctx.packageManager
                val drawable = pm.getApplicationIcon(pkg)
                val bmp = drawableToBitmap(drawable, 96)
                val bos = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.PNG, 90, bos)
                val bytes = bos.toByteArray()
                FileOutputStream(f).use { it.write(bytes) }
                Base64.encodeToString(bytes, Base64.NO_WRAP)
            }
        } catch (e: Exception) {
            null
        }
    }
}
