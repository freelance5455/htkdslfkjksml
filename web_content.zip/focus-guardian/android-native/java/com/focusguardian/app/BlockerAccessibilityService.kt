package com.focusguardian.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import org.json.JSONObject

/**
 * Сервис специальных возможностей: определяет активное приложение и
 * блокирует его по правилам (лимит, блокировка дня, расписание, сеанс фокуса/отдыха).
 * Содержимое экрана не читается — используется только имя пакета.
 */
class BlockerAccessibilityService : AccessibilityService() {

    companion object {
        var instance: BlockerAccessibilityService? = null
            private set
        private var lastPkg: String? = null
        private var lastShowTs: Long = 0
        private var launchers: Set<String>? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (isIgnoredPkg(pkg)) return

        // реагируем только на смену приложения
        if (pkg == lastPkg) return
        lastPkg = pkg

        val now = System.currentTimeMillis()
        if (now - lastShowTs < 1200) return

        val decision = evaluate(pkg, now) ?: return

        lastShowTs = now
        MonitoringService.appendBlockLog(this, pkg, decision.reason)

        // увеличить счётчик нарушений активного сеанса
        bumpViolation(now, pkg)

        if (Settings.canDrawOverlays(this)) {
            OverlayController.show(this, pkg, appLabel(pkg), decision.untilTs, decision.reason)
        } else {
            // без оверлея: возвращаем на главный экран и уведомляем
            performGlobalAction(GLOBAL_ACTION_HOME)
            ReminderEngine.limitReached(this, appLabel(pkg))
        }
    }

    override fun onInterrupt() { /* не требуется */ }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }

    private fun bumpViolation(now: Long, pkg: String) {
        val raw = NativePrefs.getString(this, NativePrefs.KEY_SESSION_STATE)
        if (raw.isBlank()) return
        val st = try { JSONObject(raw) } catch (e: Exception) { return }
        val endsTs = st.optLong("endsTs", 0)
        if (now < endsTs) {
            st.put("violations", st.optInt("violations", 0) + 1)
            NativePrefs.putJson(this, NativePrefs.KEY_SESSION_STATE, st.toString())
        }
    }

    private fun isIgnoredPkg(pkg: String): Boolean {
        if (pkg == "com.android.systemui") return true
        if (pkg.startsWith("com.android.inputmethod") || pkg.contains("inputmethod")) return true
        val launchers = getLaunchers()
        return pkg in launchers
    }

    private fun getLaunchers(): Set<String> {
        val cached = launchers
        if (cached != null) return cached
        val set = HashSet<String>()
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val infos = packageManager.queryIntentActivities(intent, 0)
        for (ri in infos) ri.activityInfo?.packageName?.let { set.add(it) }
        launchers = set
        return set
    }

    private fun evaluate(pkg: String, now: Long): BlockDecision? {
        val raw = NativePrefs.getString(this, NativePrefs.KEY_RULES)
        if (raw.isBlank()) return null
        val root = try { JSONObject(raw) } catch (e: Exception) { return null }
        val selfPkg = root.optString("selfPkg", "com.focusguardian.app")
        if (pkg == selfPkg) return null

        // Сеанс фокуса/отдыха
        val session = root.optJSONObject("session")
        if (session != null) {
            val endsTs = session.optLong("endsTs", 0)
            if (endsTs > now) {
                val blockArr = session.optJSONArray("blockPkgs") ?: org.json.JSONArray()
                for (i in 0 until blockArr.length()) {
                    if (blockArr.optString(i) == pkg) {
                        return BlockDecision(untilTs = endsTs, reason = if (session.optString("kind") == "focus") "focus" else "rest")
                    }
                }
            }
        }

        val byPkg = root.optJSONObject("byPkg") ?: return null
        val rule = byPkg.optJSONObject(pkg) ?: return null

        // Полная блокировка дня
        if (rule.optBoolean("blockedAllDay", false)) {
            return BlockDecision(untilTs = UsageStatsReader.endOfDay(now), reason = "day")
        }

        // Временная блокировка
        val until = rule.optLong("blockUntilTs", 0)
        if (until > now) {
            return BlockDecision(untilTs = until, reason = "temp")
        }

        // Расписание
        val schedStart = rule.optString("scheduleStart", "")
        val schedEnd = rule.optString("scheduleEnd", "")
        if (schedStart.isNotBlank() && schedEnd.isNotBlank()) {
            if (inScheduleWindow(now, schedStart, schedEnd)) {
                return BlockDecision(untilTs = scheduleEndTs(now, schedEnd), reason = "schedule")
            }
        }

        // Дневной лимит (не действует в мягком режиме)
        val mode = root.optString("mode", "standard")
        val limit = rule.optInt("limitMin", 0)
        if (limit > 0 && mode != "soft") {
            val cache = try { JSONObject(NativePrefs.getString(this, NativePrefs.KEY_DAILY_CACHE)) } catch (e: Exception) { JSONObject() }
            val used = cache.optJSONObject(pkg)?.optInt("timeMin", 0) ?: 0
            if (used >= limit) {
                return BlockDecision(untilTs = UsageStatsReader.endOfDay(now), reason = "limit")
            }
        }
        return null
    }

    private fun inScheduleWindow(now: Long, start: String, end: String): Boolean {
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = now
        val cur = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
        fun mins(v: String): Int {
            val p = v.split(":")
            return ((p.getOrNull(0)?.toIntOrNull() ?: 0) * 60) + (p.getOrNull(1)?.toIntOrNull() ?: 0)
        }
        val s = mins(start)
        val e = mins(end)
        if (s == e) return false
        return if (s < e) cur in s until e else cur >= s || cur < e
    }

    private fun scheduleEndTs(now: Long, end: String): Long {
        val p = end.split(":")
        val h = p.getOrNull(0)?.toIntOrNull() ?: 0
        val m = p.getOrNull(1)?.toIntOrNull() ?: 0
        val c = java.util.Calendar.getInstance()
        c.timeInMillis = now
        c.set(java.util.Calendar.HOUR_OF_DAY, h)
        c.set(java.util.Calendar.MINUTE, m)
        c.set(java.util.Calendar.SECOND, 0)
        if (c.timeInMillis <= now) c.add(java.util.Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    private data class BlockDecision(val untilTs: Long, val reason: String)
}
