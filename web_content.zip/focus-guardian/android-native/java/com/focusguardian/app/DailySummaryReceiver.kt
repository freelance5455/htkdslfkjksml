package com.focusguardian.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/** Вечерняя сводка экранного времени (AlarmManager, RTC_WAKEUP). */
class DailySummaryReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        ReminderEngine.dailySummary(context)
        schedule(context)
    }

    companion object {
        private const val REQUEST_CODE = 4001

        fun schedule(context: Context) {
            val cfg = FgConfig.parse(context)
            val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val parts = cfg.summaryTime.split(":")
            val h = parts.getOrNull(0)?.toIntOrNull() ?: 21
            val m = parts.getOrNull(1)?.toIntOrNull() ?: 30

            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h)
                set(Calendar.MINUTE, m)
                set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }

            val pi = PendingIntent.getBroadcast(
                context, REQUEST_CODE,
                Intent(context, DailySummaryReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            // Неточное «в течение окна» — не требует разрешения SCHEDULE_EXACT_ALARM
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }
}
