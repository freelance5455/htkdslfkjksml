package com.focusguardian.app

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.PermissionCallback
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback
import org.json.JSONObject
import java.io.File

/**
 * Нативный мост Focus Guardian: статистика использования, разрешения,
 * правила блокировки, сеансы, уведомления, экспорт файлов.
 */
@CapacitorPlugin(name = "FocusGuardianNative", permissionRequestCode = 2001)
class FocusGuardianPlugin : Plugin() {

    /* ============================ РАЗРЕШЕНИЯ ============================ */

    @PluginMethod
    fun getPermissionStatus(call: PluginCall) {
        val ctx = context
        val r = JSObject()
        r.put("ok", true)
        r.put("usageAccess", UsageStatsReader.hasUsageAccess(ctx))
        r.put("accessibility", BlockerAccessibilityService.instance != null)
        r.put("overlay", Settings.canDrawOverlays(ctx))
        r.put("batteryIgnored", isIgnoringBatteryOptimizations(ctx))
        r.put("dnd", dndAccessGranted(ctx))
        r.put("notifications", notificationsEnabled(ctx))
        r.put("serviceRunning", NativePrefs.getBool(ctx, NativePrefs.KEY_FGS_RUNNING, false))
        call.resolve(r)
    }

    private fun isIgnoringBatteryOptimizations(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    private fun dndAccessGranted(ctx: Context): Boolean {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return false
        return nm.isNotificationPolicyAccessGranted
    }

    private fun notificationsEnabled(ctx: Context): Boolean =
        androidx.core.app.NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    private fun startSettingsActivity(ctx: Context, intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    @PluginMethod
    fun openUsageAccessSettings(call: PluginCall) {
        val ok = startSettingsActivity(
            context,
            Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
        )
        call.resolve(JSObject().put("ok", ok))
    }

    @PluginMethod
    fun openAccessibilitySettings(call: PluginCall) {
        val ok = startSettingsActivity(
            context,
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        )
        call.resolve(JSObject().put("ok", ok))
    }

    @PluginMethod
    fun openOverlaySettings(call: PluginCall) {
        val intent = if (Build.VERSION.SDK_INT >= 26) {
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        } else {
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
        }
        call.resolve(JSObject().put("ok", startSettingsActivity(context, intent)))
    }

    @PluginMethod
    fun openBatterySettings(call: PluginCall) {
        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            .setData(Uri.parse("package:${context.packageName}"))
        val ok = startSettingsActivity(context, intent)
        if (!ok) {
            startSettingsActivity(context, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
        call.resolve(JSObject().put("ok", true))
    }

    @PluginMethod
    fun openDndSettings(call: PluginCall) {
        val ok = startSettingsActivity(
            context,
            Intent("android.settings.NOTIFICATION_POLICY_ACCESS_SETTINGS")
        )
        call.resolve(JSObject().put("ok", ok))
    }

    @PluginMethod
    fun openAppNotificationSettings(call: PluginCall) {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        call.resolve(JSObject().put("ok", startSettingsActivity(context, intent)))
    }

    @Permission(strings = [Manifest.permission.POST_NOTIFICATIONS])
    private fun notifPermission() {
        // запрашивается через requestPermission(call, "notifPermission")
    }

    @PluginMethod
    fun requestNotifications(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermission(call, "notifPermission")
        } else {
            call.resolve(JSObject().put("ok", true).put("granted", notificationsEnabled(context)))
        }
    }

    @PermissionCallback
    private fun notifPermissionCallback(call: PluginCall, result: PermissionCallback) {
        val granted = result.areAllGranted()
        call.resolve(JSObject().put("ok", true).put("granted", granted))
    }

    /* ============================ ПРИЛОЖЕНИЯ И СТАТИСТИКА ============================ */

    @PluginMethod
    fun getInstalledApps(call: PluginCall) {
        if (!UsageStatsReader.hasUsageAccess(context)) {
            call.resolve(JSObject().put("ok", false).put("reason", "no-permission"))
            return
        }
        val arr = UsageStatsReader.installedApps(context)
        val apps = JSArray()
        for (i in 0 until arr.length()) apps.put(arr.optJSONObject(i) ?: JSONObject())
        call.resolve(JSObject().put("ok", true).put("apps", apps))
    }

    @PluginMethod
    fun getAppIcons(call: PluginCall) {
        val packages = call.getArray("packages")
        val icons = JSObject()
        if (packages != null) {
            var count = 0
            for (i in 0 until packages.length()) {
                if (count >= 40) break
                val pkg = packages.optString(i) ?: continue
                val b64 = UsageStatsReader.iconBase64(context, pkg)
                if (b64 != null) {
                    icons.put(pkg, b64)
                    count++
                }
            }
        }
        call.resolve(JSObject().put("ok", true).put("icons", icons))
    }

    @PluginMethod
    fun getUsageToday(call: PluginCall) {
        val now = System.currentTimeMillis()
        getUsageRange(call, UsageStatsReader.startOfDay(now), now, today = true)
    }

    @PluginMethod
    fun getUsageRange(call: PluginCall) {
        val from = (call.getLong("fromTs") ?: UsageStatsReader.startOfDay()).toLong()
        val to = (call.getLong("toTs") ?: System.currentTimeMillis()).toLong()
        getUsageRange(call, from, to, today = false)
    }

    private fun getUsageRange(call: PluginCall, from: Long, to: Long, today: Boolean) {
        if (!UsageStatsReader.hasUsageAccess(context)) {
            call.resolve(JSObject().put("ok", false).put("reason", "no-permission"))
            return
        }
        try {
            val byApp = UsageStatsReader.queryByApp(context, from, to)
            val apps = JSObject()
            for (key in byApp.keys()) {
                apps.put(key, byApp.optJSONObject(key) ?: JSONObject())
            }
            val r = JSObject()
                .put("ok", true)
                .put("totalMin", UsageStatsReader.totalMin(byApp))
                .put("byApp", apps)
                .put("launches", UsageStatsReader.launchesTotal(byApp))
            if (today) {
                r.put("unlocks", NativePrefs.dateInt(context, "unlocks"))
                r.put("restMin", NativePrefs.dateInt(context, "rest"))
                r.put("breaks", NativePrefs.dateInt(context, "breaks"))
                r.put("nightMin", NativePrefs.dateInt(context, "night"))
                r.put(
                    "longestOfflineMin",
                    NativePrefs.getInt(context, "longest_offline_" + NativePrefs.todayKey())
                )
            }
            call.resolve(r)
        } catch (e: Exception) {
            call.resolve(JSObject().put("ok", false).put("reason", "error").put("message", e.message ?: "unknown"))
        }
    }

    @PluginMethod
    fun getDailySeries(call: PluginCall) {
        if (!UsageStatsReader.hasUsageAccess(context)) {
            call.resolve(JSObject().put("ok", false).put("reason", "no-permission"))
            return
        }
        val days = ((call.getInt("days") ?: 7)).toInt().coerceIn(1, 366)
        try {
            val series = UsageStatsReader.dailySeries(context, days)
            val out = JSArray()
            for (i in 0 until series.length()) out.put(series.optJSONObject(i) ?: JSONObject())
            call.resolve(JSObject().put("ok", true).put("series", out))
        } catch (e: Exception) {
            call.resolve(JSObject().put("ok", false).put("reason", "error").put("message", e.message ?: "unknown"))
        }
    }

    @PluginMethod
    fun getLiveState(call: PluginCall) {
        val ctx = context
        val available = NativePrefs.getBool(ctx, NativePrefs.KEY_FGS_EVER, false)
        val screenOn = NativePrefs.getBool(ctx, NativePrefs.KEY_SCREEN_ON, false)
        val sessionStart = NativePrefs.getLong(ctx, NativePrefs.KEY_SESSION_START)
        val now = System.currentTimeMillis()
        val r = JSObject()
            .put("ok", true)
            .put("available", available)
            .put("screenOn", screenOn)
            .put("sessionStartTs", if (screenOn && sessionStart > 0) sessionStart else 0)
            .put("lastRestTs", NativePrefs.getLong(ctx, NativePrefs.KEY_LAST_REST_TS))
            .put("restMinToday", NativePrefs.dateInt(ctx, "rest"))
            .put("breaksToday", NativePrefs.dateInt(ctx, "breaks"))
            .put("unlocksToday", NativePrefs.dateInt(ctx, "unlocks"))
            .put("nightMin", NativePrefs.dateInt(ctx, "night"))
            .put(
                "longestOfflineMin",
                NativePrefs.getInt(ctx, "longest_offline_" + NativePrefs.todayKey())
            )
        call.resolve(r)
    }

    @PluginMethod
    fun getServiceDiagnostics(call: PluginCall) {
        val ctx = context
        val blocksKey = "blocks_" + NativePrefs.todayKey()
        val blocksRaw = NativePrefs.getString(ctx, blocksKey)
        val blocksCount = if (blocksRaw.isBlank()) 0 else try {
            org.json.JSONArray(blocksRaw).length()
        } catch (e: Exception) { 0 }
        call.resolve(
            JSObject()
                .put("ok", true)
                .put("running", NativePrefs.getBool(ctx, NativePrefs.KEY_FGS_RUNNING, false))
                .put("lastTickTs", NativePrefs.getLong(ctx, NativePrefs.KEY_LAST_TICK))
                .put("lastStatsSyncTs", NativePrefs.getLong(ctx, NativePrefs.KEY_LAST_SYNC))
                .put("accessibilityConnected", BlockerAccessibilityService.instance != null)
                .put("blocksToday", blocksCount)
        )
    }

    /* ============================ КОНФИГ И ПРАВИЛА ============================ */

    @PluginMethod
    fun setConfig(call: PluginCall) {
        val json = call.getString("json") ?: "{}"
        NativePrefs.putJson(context, NativePrefs.KEY_CONFIG, json)
        val cfg = FgConfig.parse(context)
        if (cfg.monitoring) {
            MonitoringService.start(context)
        } else {
            MonitoringService.stop(context)
        }
        call.resolve(JSObject().put("ok", true))
    }

    @PluginMethod
    fun setBlockRules(call: PluginCall) {
        val json = call.getString("json") ?: "{}"
        NativePrefs.putJson(context, NativePrefs.KEY_RULES, json)
        call.resolve(JSObject().put("ok", true))
    }

    /* ============================ СЕАНСЫ ============================ */

    @PluginMethod
    fun startFocus(call: PluginCall) {
        startSession(call, "focus")
    }

    @PluginMethod
    fun startRest(call: PluginCall) {
        startSession(call, "rest")
    }

    private fun startSession(call: PluginCall, kind: String) {
        val minutes = ((call.getInt("minutes") ?: 25)).toInt().coerceIn(1, 480)
        val blockPkgs = JSArray()
        call.getArray("blockPkgs")?.let { arr ->
            for (i in 0 until arr.length()) blockPkgs.put(arr.optString(i) ?: "")
        }
        val state = JSObject()
            .put("kind", kind)
            .put("startedTs", System.currentTimeMillis())
            .put("endsTs", System.currentTimeMillis() + minutes * 60000L)
            .put("minutes", minutes)
            .put("violations", 0)
            .put("blockPkgs", blockPkgs)
        NativePrefs.putJson(context, NativePrefs.KEY_SESSION_STATE, state.toString())
        MonitoringService.start(context)
        SessionEndReceiver.scheduleEnd(context, System.currentTimeMillis() + minutes * 60000L)
        call.resolve(
            JSObject()
                .put("ok", true)
                .put("endsTs", state.getLong("endsTs"))
        )
    }

    @PluginMethod
    fun stopFocus(call: PluginCall) {
        stopSession(call, completed = call.getBoolean("completed", false) ?: false)
    }

    @PluginMethod
    fun stopRest(call: PluginCall) {
        stopSession(call, completed = false)
    }

    private fun stopSession(call: PluginCall, completed: Boolean) {
        val raw = NativePrefs.getString(context, NativePrefs.KEY_SESSION_STATE)
        if (raw.isNotBlank()) {
            try {
                val st = JSONObject(raw)
                val now = System.currentTimeMillis()
                val startedTs = st.optLong("startedTs", now)
                val plannedMin = st.optInt("minutes", 0)
                MonitoringService.appendSessionLog(
                    context,
                    JSObject()
                        .put("startedTs", startedTs)
                        .put("endedTs", now)
                        .put("plannedMin", plannedMin)
                        .put("actualMin", ((now - startedTs) / 60000L).toInt())
                        .put("success", completed)
                        .put("violations", st.optInt("violations", 0))
                )
            } catch (e: Exception) { /* повреждённый JSON — сбрасываем */ }
        }
        NativePrefs.putJson(context, NativePrefs.KEY_SESSION_STATE, "")
        call.resolve(JSObject().put("ok", true))
    }

    @PluginMethod
    fun getNativeSession(call: PluginCall) {
        val raw = NativePrefs.getString(context, NativePrefs.KEY_SESSION_STATE)
        if (raw.isBlank()) {
            call.resolve(JSObject().put("ok", true).put("active", false))
            return
        }
        try {
            val st = JSONObject(raw)
            val endsTs = st.optLong("endsTs", 0)
            val active = endsTs > System.currentTimeMillis()
            val blockPkgs = JSArray()
            st.optJSONArray("blockPkgs")?.let { arr ->
                for (i in 0 until arr.length()) blockPkgs.put(arr.optString(i) ?: "")
            }
            call.resolve(
                JSObject()
                    .put("ok", true)
                    .put("active", active)
                    .put("kind", st.optString("kind", "focus"))
                    .put("endsTs", endsTs)
                    .put("minutes", st.optInt("minutes", 0))
                    .put("violations", st.optInt("violations", 0))
                    .put("blockPkgs", blockPkgs)
            )
        } catch (e: Exception) {
            call.resolve(JSObject().put("ok", true).put("active", false))
        }
    }

    @PluginMethod
    fun getSessionsLog(call: PluginCall) {
        val raw = NativePrefs.getString(context, NativePrefs.KEY_SESSIONS_LOG)
        val out = JSArray()
        if (raw.isNotBlank()) {
            try {
                val arr = org.json.JSONArray(raw)
                for (i in 0 until arr.length()) out.put(arr.optJSONObject(i) ?: JSONObject())
            } catch (e: Exception) { /* повреждённый журнал */ }
        }
        call.resolve(JSObject().put("ok", true).put("sessions", out))
    }

    /* ============================ УВЕДОМЛЕНИЯ ============================ */

    @PluginMethod
    fun testNotification(call: PluginCall) {
        ReminderEngine.notify(
            context,
            NotificationChannels.CH_SUMMARY,
            9001,
            "Focus Guardian",
            "Уведомления работают! Так будут приходить напоминания об отдыхе и итоги дня."
        )
        call.resolve(JSObject().put("ok", true))
    }

    @PluginMethod
    fun notifyNow(call: PluginCall) {
        val title = call.getString("title") ?: "Focus Guardian"
        val text = call.getString("text") ?: ""
        val channel = call.getString("channel") ?: NotificationChannels.CH_REMINDERS
        val id = (call.getInt("id") ?: 8001).toInt()
        ReminderEngine.notify(context, channel, id, title, text)
        call.resolve(JSObject().put("ok", true))
    }

    /* ============================ ЭКСПОРТ ============================ */

    @PluginMethod
    fun exportFile(call: PluginCall) {
        val name = call.getString("name") ?: "focus-guardian-export.txt"
        val mime = call.getString("mime") ?: "application/octet-stream"
        val base64 = call.getString("base64") ?: ""
        try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val savedPath = saveToDownloads(name, mime, bytes)
            call.resolve(JSObject().put("ok", true).put("path", savedPath))
        } catch (e: Exception) {
            call.resolve(JSObject().put("ok", false).put("reason", "error").put("message", e.message ?: "unknown"))
        }
    }

    private fun saveToDownloads(name: String, mime: String, bytes: ByteArray): String {
        // API 29+: MediaStore позволяет писать в Downloads без дополнительных разрешений
        val values = android.content.ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Не удалось создать файл в Загрузках")
        resolver.openOutputStream(uri)?.use { it.write(bytes) }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return Environment.DIRECTORY_DOWNLOADS + "/" + name
    }
}
