package com.focusguardian.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Восстановление фоновой работы после перезагрузки телефона. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON") {
            val cfg = FgConfig.parse(context)
            if (cfg.monitoring && cfg.notifyEnabled) {
                MonitoringService.start(context)
            }
            DailySummaryReceiver.schedule(context)
        }
    }
}
