package com.focusguardian.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Тревога на конец сеанса фокуса/отдыха (сработает, даже если сервис был убит). */
class SessionEndReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // Сервис проверит состояние при следующем тике; здесь только бустим старт сервиса
        val cfg = FgConfig.parse(context)
        if (cfg.monitoring) MonitoringService.start(context)
    }

    companion object {
        private const val REQUEST_CODE = 4002

        fun scheduleEnd(context: Context, endsTs: Long) {
            val am = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            if (endsTs <= System.currentTimeMillis()) return
            val pi = PendingIntent.getBroadcast(
                context, REQUEST_CODE,
                Intent(context, SessionEndReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endsTs, pi)
        }
    }
}
