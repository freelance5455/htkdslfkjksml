package com.focusguardian.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    public override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(FocusGuardianPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
