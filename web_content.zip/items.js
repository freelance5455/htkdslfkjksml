// 8. إدارة الأصناف
// ========================================
function renderItemsPage(c) {
  c.innerHTML = `<div class="bar">
      <div>
        <h2>إدارة الطلبات والأسعار</h2>
        <p class="muted">أضف الأصناف وأسعارها.</p>
      </div>
      <button class="primary" onclick="itemForm()">＋ إضافة صنف</button>
    </div>

    <div class="items">
      ${db.items.length
        ? db.items.map(p => `
          <div class="card item">
            <div>
              <b>${esc(p.name)}</b>
              <p class="muted">${priceText(p.price)}</p>
            </div>
            <div>
              <button onclick="itemForm(${p.id})">تعديل</button>
              <button class="bad" onclick="delItem(${p.id})">حذف</button>
            </div>
          </div>
        `).join("")
        : `<p class="muted">لا توجد أصناف. اضغط «إضافة صنف» لإضافة أول طلب.</p>`
      }
    </div>`;
}

function itemForm(id) {
  const p = id
    ? db.items.find(x => x.id === id)
    : { name: "", price: "" };

  if (!p) return;

  modal(`<h3>${id ? "تعديل صنف" : "إضافة صنف"}</h3>
    <div class="field">
      <label for="iname">اسم الطلب</label>
      <input id="iname" value="${esc(p.name)}" placeholder="مثلاً: عصير">
    </div>
    <div class="field">
      <label for="iprice">سعر القطعة</label>
      <input id="iprice" type="number" min="0.01" step="any"
        value="${Number(p.price) > 0 ? p.price : ""}" placeholder="أدخل السعر">
    </div>
    <button class="primary" onclick="saveItem(${id || 0})">حفظ الصنف</button>
    <button onclick="closemodal()">إلغاء</button>`);
}

function saveItem(id) {
  const n = document.getElementById("iname").value.trim();
  const raw = document.getElementById("iprice").value;
  const p = Number(raw);

  if (!n || raw === "" || !Number.isFinite(p) || p <= 0) {
    return notify("أدخل اسم الصنف وسعره");
  }

  if (id) {
    const x = db.items.find(x => x.id === id);
    if (!x) return;
    x.name = n;
    x.price = p;
  } else {
    db.items.push({ id: db.id++, name: n, price: p });
  }

  save();
  closemodal();
  render();
  notify("تم حفظ الصنف والسعر");
}

function delItem(id) {
  if (!confirm("هل تريد حذف هذا الصنف؟")) return;

  db.items = db.items.filter(x => x.id !== id);
  save();
  render();
  notify("تم حذف الصنف");
}

// ========================================
// 9. طلبات الجلسات
// ========================================
function orders(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d || !d.s || d.s.end) {
    return notify("ابدأ جلسة مفتوحة لإضافة الطلبات");
  }

  target = id;

  modal(`<h3>طلبات ${esc(d.name)}</h3>
    <div id="rows">${d.s.orders.map(orderRow).join("")}</div>
    <button onclick="addRow()">＋ إضافة صنف</button>
    <div class="summary">
      مجموع الطلبات: <b id="grand">${cash(sum(d.s))}</b>
    </div>
    <button class="primary" onclick="saveOrders()">حفظ الطلبات</button>
    <button onclick="closemodal()">إلغاء</button>`);

  if (!d.s.orders.length) addRow();
}

function orderRow(o = {}) {
  return `<div class="orderrow">
    <select onchange="calc()">
      <option value="">اختر الطلب</option>
      ${db.items.map(p => `
        <option value="${p.id}" ${o.id === p.id ? "selected" : ""}>
          ${esc(p.name)} · ${priceText(p.price)}
        </option>
      `).join("")}
    </select>
    <input type="number" min="1" value="${o.qty || 1}" onchange="calc()">
    <span>${cash((o.price || 0) * (o.qty || 1))}</span>
    <button class="bad" onclick="this.parentElement.remove();calc()">×</button>
  </div>`;
}

function addRow() {
  document.getElementById("rows")
    .insertAdjacentHTML("beforeend", orderRow());
  calc();
}

function calc() {
  let total = 0;

  document.querySelectorAll(".orderrow").forEach(row => {
    const p = db.items.find(
      x => x.id === Number(row.querySelector("select").value)
    );

    const q = Math.max(
      1,
      Number(row.querySelector("input").value) || 1
    );

    const amount = p ? Number(p.price) * q : 0;
    total += amount;
    row.querySelector("span").textContent = cash(amount);
  });

  const grand = document.getElementById("grand");
  if (grand) grand.textContent = cash(total);
}

function saveOrders() {
  const d = db.devices.find(x => x.id === target);
  if (!d || !d.s || d.s.end) return;

  const chosen = [...document.querySelectorAll(".orderrow")]
    .map(row => ({
      p: db.items.find(
        x => x.id === Number(row.querySelector("select").value)
      ),
      q: Math.max(1, Number(row.querySelector("input").value) || 1)
    }))
    .filter(x => x.p);

  if (chosen.some(x => !(Number(x.p.price) > 0))) {
    return notify("أدخل سعر كل صنف من صفحة الطلبات أولاً");
  }

  d.s.orders = chosen.map(x => ({
    id: x.p.id,
    name: x.p.name,
    price: Number(x.p.price),
    qty: x.q
  }));

  save();
  closemodal();
  render();
  notify("تم حفظ الطلبات");
}

// ========================================
