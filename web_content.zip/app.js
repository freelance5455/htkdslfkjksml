import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithRedirect, getRedirectResult, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { firebaseConfig } from "./firebase-config.js";
let currentUser = null;
let auth = null;
try {
 if (firebaseConfig.apiKey && !firebaseConfig.apiKey.includes("YOUR_")) {
  const app = initializeApp(firebaseConfig); auth = getAuth(app); const provider = new GoogleAuthProvider();
  getRedirectResult(auth).catch(e=>{console.error(e);alert("Google login error: "+(e.code||e.message));});
  onAuthStateChanged(auth,user=>{currentUser=user;updateAuthUI();});
  window.cpGoogleLogin=()=>signInWithRedirect(auth,provider);
  window.cpLogout=()=>signOut(auth);
 }
} catch(e){console.error("Firebase setup",e);}
function updateAuthUI(){const b=document.querySelector("#login"),s=document.querySelector("#authStatus");if(!b||!s)return;if(currentUser){s.textContent="Signed in: "+(currentUser.displayName||currentUser.email||"Google user");b.textContent="Sign out";}else{ s.textContent=auth?"Login required to play":"Firebase setup required";b.textContent="Continue with Google";}}
const initialGames=[
{name:"Where Winds Meet",cat:"Adventure",desc:"Open-world action adventure",url:""},
{name:"Neverness to Everness",cat:"RPG",desc:"Urban fantasy adventure",url:""},
{name:"Palworld",cat:"Adventure",desc:"Survival and exploration",url:""}
];
let games=[...initialGames], filter="All";
const $=s=>document.querySelector(s);
function render(){const q=$("#search").value.toLowerCase();$("#games").innerHTML="";games.filter(g=>(filter==="All"||filter==="My Games"?(filter==="All"||g.custom):g.cat===filter)&&g.name.toLowerCase().includes(q)).forEach(g=>{const el=document.createElement("article");el.className="game";if(g.image){const im=document.createElement("img");im.className="cover";im.alt=g.name+" cover";im.src=g.image;im.onerror=()=>im.remove();el.append(im);}const title=document.createElement("h3");title.textContent=g.name;const desc=document.createElement("p");desc.textContent=g.custom?"MY GAME · "+g.cat:g.desc;const btn=document.createElement("button");btn.className="primary";btn.textContent="Play";btn.onclick=()=>playGame(g);el.append(title,desc,btn);$("#games").append(el);});if(!$("#games").children.length)$("#games").innerHTML='<p class="hint">No games found. Add a game to your library.</p>'}
$("#search").addEventListener("input",render);
document.querySelectorAll(".chip").forEach(b=>b.onclick=()=>{document.querySelectorAll(".chip").forEach(x=>x.classList.remove("active"));b.classList.add("active");filter=b.dataset.filter;render()});
$("#addBtn").onclick=()=>$("#addDialog").showModal();
$("#addForm").addEventListener("submit",e=>{if(e.submitter?.id==="saveGame"){const name=$("#gameName").value.trim();if(!name)return;e.preventDefault();games.push({name,cat:$("#gameCategory").value,desc:"Custom game",url:$("#gameUrl").value.trim(),image:$("#gameImage").value.trim(),custom:true});$("#addDialog").close();$("#addForm").reset();filter="My Games";document.querySelectorAll(".chip").forEach(x=>x.classList.toggle("active",x.dataset.filter===filter));render();}});
function updatePerf(){const low=$("#saver").checked;const quality=$("#quality");if(low){quality.value="data";$("#fps").value="30";$("#auto").checked=true;}$("#modeLabel").textContent=low?"Low-device mode":quality.options[quality.selectedIndex].text;$("#perfHint").textContent=low?"Low-device profile selected: lower stream resolution and 30 FPS target to reduce data and decoding load.":"Actual FPS depends on network stability, cloud server capacity and the game."; }
["quality","fps","auto","saver"].forEach(id=>$("#"+id).addEventListener("change",updatePerf));
$("#controller").onclick=()=>$("#toolHint").textContent="Controller preview selected. Live touch controls require a compatible streaming client and input API.";
$("#fullscreen").onclick=()=>{if(document.fullscreenElement)document.exitFullscreen?.();else document.documentElement.requestFullscreen?.();};
$("#reconnect").onclick=()=>$("#toolHint").textContent="No active cloud session. Connect a supported streaming server to use reconnect.";
$("#login").onclick=async()=>{try{if(currentUser){await window.cpLogout?.();}else if(window.cpGoogleLogin){await window.cpGoogleLogin();}else{alert("Google Login setup বাকি। firebase-config.js-এ Firebase config বসাতে হবে।");}}catch(e){alert("Login error: "+(e.code||e.message));}};
render();updatePerf();
// Local demo playtime rewards. These are sample codes, not redeemable provider credits.
const demoCodes={"CPPLAY10":10,"CLOUD5MIN":5,"CPSTART2":2,"PLAYTIME10":10,"GAME5NOW":5,"FASTPLAY2":2,"CPBONUS10":10,"FUN5MIN":5,"TRY2MIN":2,"CLOUDPLAY10":10,"LEVELUP5":5,"QUICK2":2};
let balance=Number(localStorage.getItem("cp_balance")||0);
let claimed=JSON.parse(localStorage.getItem("cp_claimed")||"[]");
function updateBalance(){$("#timeBalance").textContent=balance+" min";$("#codeList").innerHTML=Object.keys(demoCodes).map(c=>`<span class="code-tag">${c}</span>`).join("");}
$("#claimCode").onclick=()=>{const c=$("#redeemCode").value.trim().toUpperCase();if(!demoCodes[c]){$("#rewardHint").textContent="Code not recognized. Use one of the demo codes shown below.";return;}if(claimed.includes(c)){$("#rewardHint").textContent="This code was already claimed in this browser.";return;}balance+=demoCodes[c];claimed.push(c);localStorage.setItem("cp_balance",balance);localStorage.setItem("cp_claimed",JSON.stringify(claimed));$("#redeemCode").value="";$("#rewardHint").textContent="Demo code claimed: +"+demoCodes[c]+" minutes.";updateBalance();};
$("#randomReward").onclick=()=>{const n=[2,5,10][Math.floor(Math.random()*3)];balance+=n;localStorage.setItem("cp_balance",balance);$("#rewardHint").textContent="You received a demo random reward: "+n+" minutes.";updateBalance();};
function playGame(g){if(!currentUser){alert("গেম খেলতে আগে Google Account দিয়ে Login করো। গেম Add করা Login ছাড়াও যাবে।");return;}if($("#sessionReminder").checked&&!confirm("Start a game session? Remember to take breaks and watch your data use."))return;if(!g.url){alert("No stream link is connected for this game yet. Add a supported cloud-stream URL first.");return;}let u;try{u=new URL(g.url);if(!["https:","http:"].includes(u.protocol))throw Error();}catch(e){alert("Please enter a valid http/https game or stream URL.");return;}if($("#safeMode").checked&&!confirm("Open this game link? Only continue if you trust the website and its provider."))return;window.open(u.href,"_blank","noopener");}
$("#safeMode").onchange=()=>$("#safeHint").textContent=$("#safeMode").checked?"Safe play mode is on. Unknown links require confirmation.":"Safe play mode is off.";
$("#askAI").onclick=()=>{const q=$("#aiQuestion").value.trim();if(!q)return;const log=$("#aiLog");const p=document.createElement("p");p.innerHTML="<b>You:</b> ";p.append(document.createTextNode(q));log.append(p);const a=document.createElement("p");a.innerHTML="<b>CP AI:</b> ";let answer="I can help with setup, adding games, FPS settings and safe links. For real-time AI answers, connect a protected AI backend.";const s=q.toLowerCase();if(s.includes("fps")||s.includes("slow"))answer="Try Low-device mode, Data Saver and 30 FPS. Real performance also depends on your internet and cloud server.";else if(s.includes("add")||s.includes("game"))answer="Choose Add a game, enter its name, category, optional cover image URL and a trusted stream URL, then save.";else if(s.includes("code")||s.includes("claim"))answer="Enter one of the demo codes in Playtime Rewards. Demo minutes are stored only in this browser and do not unlock a real cloud session.";else if(s.includes("safe")||s.includes("security"))answer="Keep Safe Play Mode on and open only trusted HTTPS links. Never share passwords or verification codes.";a.append(document.createTextNode(answer));log.append(a);$("#aiQuestion").value="";log.scrollTop=log.scrollHeight;};
const ctrl=document.createElement("div");ctrl.className="controller-preview";ctrl.id="controllerPreview";ctrl.innerHTML='<div class="pad"><button data-key="up">▲</button><button data-key="left">◀</button><button data-key="down">▼</button><button data-key="right">▶</button></div><div class="actions"><button data-key="A">A</button><button data-key="B">B</button></div>';document.body.append(ctrl);
const close=document.createElement("button");close.className="outline controller-close";close.textContent="Hide controls";close.onclick=()=>{ctrl.classList.remove("show");close.classList.remove("show")};document.body.append(close);
$("#controller").onclick=()=>{ctrl.classList.toggle("show");close.classList.toggle("show");$("#toolHint").textContent="Touch control preview. These buttons are visual only until a cloud provider input API is connected.";};
ctrl.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{$("#toolHint").textContent="Control "+b.dataset.key+" pressed (preview only). Live game input needs provider integration."; }));
updateBalance();

updateAuthUI();
