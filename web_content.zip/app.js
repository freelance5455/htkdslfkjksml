
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

function powerFromName(name){
  const n=name.toLowerCase();

  if(/a0[3-6]|a1[0-4]|m1[2-4]|e2|g0[4-5]|g1[0-4]|redmi (9a|9c|10a|10c|12c|13c|14c)|c1[1-9]|c3[0-3]|hot 1|hot 20|spark 8|spark 10|k4|k5/.test(n)) return "baixo";

  if(/s2[0-9]|ultra|pro\+|pro max|rog|f[3456789]|gt |edge|13t|14t|17t|200|v[23][0-9]/.test(n)) return "alto";

  return "medio";
}

function iosPower(name){
  return /8 Plus|X$|XR|XS|11/.test(name)?"medio":"alto";
}

const devices = [
  // SAMSUNG — modelos anteriores preservados
  ...["Galaxy A03","Galaxy A03s","Galaxy A04","Galaxy A04e","Galaxy A04s","Galaxy A05","Galaxy A05s","Galaxy A06","Galaxy A10","Galaxy A10s","Galaxy A11","Galaxy A12","Galaxy A13","Galaxy A14","Galaxy A15","Galaxy A16","Galaxy A20","Galaxy A20s","Galaxy A21s","Galaxy A22","Galaxy A23","Galaxy A24","Galaxy A25","Galaxy A30","Galaxy A30s","Galaxy A31","Galaxy A32","Galaxy A33","Galaxy A34","Galaxy A35","Galaxy A50","Galaxy A51","Galaxy A52","Galaxy A52s","Galaxy A53","Galaxy A54","Galaxy A55","Galaxy A70","Galaxy A71","Galaxy A72","Galaxy A73","Galaxy A80","Galaxy M12","Galaxy M13","Galaxy M14","Galaxy M15","Galaxy M23","Galaxy M32","Galaxy M33","Galaxy M34","Galaxy M35","Galaxy M52","Galaxy M53","Galaxy M54","Galaxy M55","Galaxy S10","Galaxy S10e","Galaxy S10 Lite","Galaxy S20","Galaxy S20 FE","Galaxy S21","Galaxy S21 FE","Galaxy S22","Galaxy S22+","Galaxy S23","Galaxy S23 FE","Galaxy S24","Galaxy S24 FE","Galaxy S25","Galaxy Note 10","Galaxy Note 20"].map(x=>({name:"Samsung "+x,platform:"android",power:powerFromName(x),brand:"Samsung"})),

  // SAMSUNG — novos modelos
  ...["Galaxy A17","Galaxy A17 5G","Galaxy A36","Galaxy A36 5G","Galaxy A56","Galaxy A56 5G","Galaxy S25 FE","Galaxy S26","Galaxy S26+","Galaxy S26 Ultra","Galaxy Z Fold7","Galaxy Z Flip7","Galaxy Z Fold8","Galaxy Z Flip8"].map(x=>({name:"Samsung "+x,platform:"android",power:powerFromName(x),brand:"Samsung"})),

  // MOTOROLA — modelos anteriores preservados
  ...["Moto E20","Moto E22","Moto E22i","Moto E32","Moto E40","Moto G04","Moto G05","Moto G10","Moto G13","Moto G14","Moto G20","Moto G22","Moto G23","Moto G24","Moto G24 Power","Moto G30","Moto G31","Moto G32","Moto G34","Moto G41","Moto G42","Moto G52","Moto G53","Moto G54","Moto G55","Moto G60","Moto G62","Moto G64","Moto G71","Moto G72","Moto G73","Moto G75","Moto G82","Moto G84","Moto G85","Moto G100","Moto G200","Edge 20","Edge 20 Lite","Edge 30","Edge 30 Neo","Edge 30 Fusion","Edge 30 Ultra","Edge 40","Edge 40 Neo","Edge 50 Fusion","Edge 50 Pro","Edge 50 Ultra","Edge 60 Fusion"].map(x=>({name:"Motorola "+x,platform:"android",power:powerFromName(x),brand:"Motorola"})),

  // MOTOROLA — novos modelos
  ...["Edge 70","Edge 70 Fusion"].map(x=>({name:"Motorola "+x,platform:"android",power:"alto",brand:"Motorola"})),

  // XIAOMI / REDMI / POCO — modelos anteriores preservados
  ...["Redmi 9A","Redmi 9C","Redmi 10A","Redmi 10C","Redmi 12C","Redmi 13C","Redmi 14C","Redmi 12","Redmi 13","Redmi 14","Redmi Note 8","Redmi Note 9","Redmi Note 10","Redmi Note 10S","Redmi Note 10 Pro","Redmi Note 11","Redmi Note 11S","Redmi Note 11 Pro","Redmi Note 12","Redmi Note 12 5G","Redmi Note 12 Pro","Redmi Note 13","Redmi Note 13 5G","Redmi Note 13 Pro","Redmi Note 13 Pro+","Redmi Note 14","Redmi Note 14 Pro","Redmi Note 14 Pro+","Xiaomi 11 Lite","Xiaomi 11T","Xiaomi 12","Xiaomi 12 Lite","Xiaomi 12T","Xiaomi 13","Xiaomi 13 Lite","Xiaomi 13T","Xiaomi 14","Xiaomi 14T","POCO C40","POCO C65","POCO M3","POCO M4 Pro","POCO M5","POCO M5s","POCO M6","POCO M6 Pro","POCO X3 NFC","POCO X3 Pro","POCO X4 Pro","POCO X5","POCO X5 Pro","POCO X6","POCO X6 Pro","POCO X7","POCO X7 Pro","POCO F3","POCO F4","POCO F5","POCO F5 Pro","POCO F6","POCO F6 Pro"].map(x=>({name:(x.startsWith("Xiaomi")?"Xiaomi":x.startsWith("POCO")?"Xiaomi "+x:"Xiaomi "+x),platform:"android",power:powerFromName(x),brand:"Xiaomi"})),

  // REALME — modelos anteriores preservados
  ...["C11","C21Y","C25Y","C30","C33","C35","C51","C53","C55","C61","C63","C65","C67","9i","9 Pro+","10","10 Pro","11","11 Pro","12","12+","12 Pro+","13","13+","GT Master Edition","GT Neo 3","GT Neo 5"].map(x=>({name:"realme "+x,platform:"android",power:powerFromName(x),brand:"realme"})),

  // OUTROS ANDROID — modelos anteriores preservados
  ...["Infinix Hot 10","Infinix Hot 11","Infinix Hot 12","Infinix Hot 20","Infinix Hot 30","Infinix Hot 30i","Infinix Hot 40","Infinix Hot 40i","Infinix Hot 50","Infinix Note 10","Infinix Note 12","Infinix Note 30","Infinix Note 40","Infinix Zero 30","Tecno Spark 8","Tecno Spark 10","Tecno Spark 20","Tecno Spark 20 Pro","Tecno Spark 30","Tecno Pova 4","Tecno Pova 5","Tecno Pova 6","Tecno Camon 19","Tecno Camon 20","Tecno Camon 30","ASUS ROG Phone 5","ASUS ROG Phone 6","ASUS ROG Phone 7","ASUS Zenfone 9","ASUS Zenfone 10","OnePlus Nord N10","OnePlus Nord N20","OnePlus Nord CE 2","OnePlus Nord CE 3 Lite","OnePlus Nord 3","OnePlus 9","OnePlus 10 Pro","OnePlus 11","OnePlus 12","OPPO A16","OPPO A17","OPPO A38","OPPO A57","OPPO A58","OPPO A78","OPPO Reno 7","OPPO Reno 8","OPPO Reno 10","OPPO Reno 11","Vivo Y21","Vivo Y22","Vivo Y27","Vivo Y36","Vivo Y100","Vivo V23","Vivo V25","Vivo V27","Vivo V29","Vivo V30","Huawei P30","Huawei P30 Pro","Huawei P40","Huawei Nova 5T","Huawei Nova 9","Honor X7","Honor X8","Honor X9","Honor 90","Honor 200","LG K41s","LG K51s","LG K52","LG K62","Nokia G10","Nokia G21","Nokia G50","Nokia X10"].map(x=>({name:x,platform:"android",power:powerFromName(x),brand:x.split(" ")[0]})),

  // IPHONES — modelos anteriores preservados
  ...["iPhone 8 Plus","iPhone X","iPhone XR","iPhone XS","iPhone XS Max","iPhone 11","iPhone 11 Pro","iPhone 11 Pro Max","iPhone SE (2ª geração)","iPhone 12 mini","iPhone 12","iPhone 12 Pro","iPhone 12 Pro Max","iPhone 13 mini","iPhone 13","iPhone 13 Pro","iPhone 13 Pro Max","iPhone SE (3ª geração)","iPhone 14","iPhone 14 Plus","iPhone 14 Pro","iPhone 14 Pro Max","iPhone 15","iPhone 15 Plus","iPhone 15 Pro","iPhone 15 Pro Max","iPhone 16","iPhone 16 Plus","iPhone 16 Pro","iPhone 16 Pro Max","iPhone 16e","iPhone 17","iPhone 17 Pro","iPhone 17 Pro Max","iPhone Air"].map(x=>({name:x,platform:"ios",power:iosPower(x),brand:"Apple"})),

  // APPLE — novos modelos
  ...["iPhone 17e","iPhone 18 Pro","iPhone 18 Pro Max","iPhone Duo"].map(x=>({name:x,platform:"ios",power:"alto",brand:"Apple"}))
];

let state={
  platform:"android",
  device:devices.find(d=>d.name==="Samsung Galaxy A14"),
  style:"media",
  result:null
};

let saved=JSON.parse(localStorage.getItem("supra_saved")||"[]");
let history=JSON.parse(localStorage.getItem("supra_history")||"[]");
let toastTimer;

function toast(msg){
  const t=$("#toast");
  t.textContent=msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>t.classList.remove("show"),2200);
}

function persist(){
  localStorage.setItem("supra_saved",JSON.stringify(saved));
  localStorage.setItem("supra_history",JSON.stringify(history));
  $("#saved-count").textContent=saved.length;
}

function setPlatform(p){
  state.platform=p;
  state.device=devices.find(d=>d.platform===p)||null;

  $$(".platform").forEach(b=>b.classList.toggle("active",b.dataset.platform===p));

  $("#device-search").value="";
  $("#device-search").placeholder=p==="ios"?"Pesquisar iPhone...":"Pesquisar celular Android...";
  $("#dpi-card").classList.toggle("hidden",p!=="android");

  renderSelected();
  renderSearch();
}

function renderSelected(){
  const d=state.device;

  $("#selected-name").textContent=d?d.name:"Nenhum aparelho selecionado";

  $("#selected-detail").textContent=d?
    (d.platform==="ios"?"iOS · desempenho estimado":"Android · desempenho estimado: "+labelPower(d.power)):
    "Pesquise e selecione seu aparelho";

  $("#selected-device").classList.toggle("empty",!d);
}

function labelPower(p){
  return p==="alto"?"avançado":p==="baixo"?"básico":"intermediário";
}

function renderSearch(){
  const q=$("#device-search").value.trim().toLowerCase();

  const list=devices.filter(d=>
    d.platform===state.platform &&
    (!q || d.name.toLowerCase().includes(q) || d.brand.toLowerCase().includes(q))
  ).slice(0,12);

  const box=$("#device-results");
  box.innerHTML="";

  if(!q){
    box.classList.remove("show");
    return;
  }

  if(!list.length){
    box.innerHTML='<div class="device-option"><span class="mini-device">⌕</span><span>Nenhum modelo encontrado.<small>Você pode adicionar o aparelho manualmente.</small></span></div>';
  }else{
    list.forEach(d=>{
      const b=document.createElement("button");
      b.className="device-option";
      b.innerHTML='<span class="mini-device">▣</span><span>'+escapeHTML(d.name)+'<small>'+(d.platform==="ios"?"iOS":"Android")+" · "+labelPower(d.power)+'</small></span>';

      b.addEventListener("click",()=>{
        state.device=d;
        $("#device-search").value=d.name;
        box.classList.remove("show");
        renderSelected();
      });

      box.appendChild(b);
    });
  }

  box.classList.add("show");
}

function escapeHTML(s){
  return String(s).replace(/[&<>"']/g,c=>({
    "&":"&amp;",
    "<":"&lt;",
    ">":"&gt;",
    '"':"&quot;",
    "'":"&#39;"
  }[c]));
}

function styleBase(){
  return {
    baixa:{g:150,r:135,x2:125,x4:110,awm:45,olho:100},
    media:{g:175,r:160,x2:145,x4:130,awm:55,olho:120},
    alta:{g:195,r:185,x2:170,x4:150,awm:65,olho:140}
  }[state.style];
}

function clamp(v){
  return Math.max(1,Math.min(200,Math.round(v)));
}

function recommendDpi(devicePower,dpiProfile,playStyle,touchStyle){
  const profileBase={
    padrao:480,
    baixo:420,
    medio:480,
    alto:560
  }[dpiProfile]||480;

  const deviceOffset=devicePower==="baixo"?-20:devicePower==="alto"?40:0;
  const playOffset=playStyle==="rush"?20:playStyle==="precisao"?-20:0;
  const touchOffset=touchStyle==="rapida"?20:touchStyle==="suave"?-20:0;

  return Math.max(
    320,
    Math.min(800,Math.round((profileBase+deviceOffset+playOffset+touchOffset)/20)*20)
  );
}

function generate(){
  if(!state.device){
    toast("Selecione um aparelho primeiro.");
    return;
  }

  const base=styleBase();
  const power=state.device.power||"medio";

  let factor=power==="baixo"?0.91:power==="alto"?1.04:1;

  const play=$("#play-style").value;
  const touch=$("#touch").value;
  const dpi=state.platform==="android"?$("#dpi").value:"padrao";

  if(play==="rush")factor+=.035;
  if(play==="precisao")factor-=.035;

  if(touch==="rapida")factor+=.025;
  if(touch==="suave")factor-=.025;

  if(dpi==="baixo")factor-=.02;
  if(dpi==="alto")factor+=.025;

  const variance=(Math.random()*3)-1;

  const values={
    geral:clamp(base.g*factor+variance),
    ponto:clamp(base.r*factor+variance),
    mira2x:clamp(base.x2*factor+variance),
    mira4x:clamp(base.x4*factor+variance),
    awm:clamp(base.awm*factor+variance),
    olhadinha:clamp(base.olho*factor+variance)
  };

  const recommendedDpi=state.platform==="android"?
    recommendDpi(power,dpi,play,touch):null;

  state.result={
    id:Date.now(),
    device:state.device.name,
    platform:state.platform,
    style:state.style,
    values,
    button:Number($("#button-size").value),
    dpi:recommendedDpi,
    play,
    touch,
    date:new Date().toISOString()
  };

  history.unshift(state.result);
  history=history.slice(0,30);

  persist();
  renderResult();
  toast("Sensibilidade gerada.");
}

const valueLabels=[
  ["geral","Geral"],
  ["ponto","Ponto vermelho"],
  ["mira2x","Mira 2x"],
  ["mira4x","Mira 4x"],
  ["awm","Mira AWM"],
  ["olhadinha","Olhadinha"]
];

function renderResult(){
  const r=state.result;
  if(!r)return;

  $("#result").classList.remove("hidden");
  $("#result-title").textContent="Sensi "+r.style;

  $("#result-device").textContent=
    r.device+" · "+(r.platform==="ios"?"iOS":"Android")+" · Free Fire";

  $("#sensi-values").innerHTML=
    valueLabels.map(([k,l])=>
      '<div class="sensi-item"><span>'+l+'</span><strong>'+r.values[k]+'</strong></div>'
    ).join("")+
    (r.dpi?
      '<div class="sensi-item dpi-result"><span>DPI recomendada</span><strong>'+r.dpi+'</strong></div>':
      ''
    );

  $("#result-extras").innerHTML=
    '<span>Botão: '+r.button+'%</span>'+
    '<span>Estilo: '+playLabel(r.play)+'</span>'+
    '<span>Toque: '+touchLabel(r.touch)+'</span>';

  $("#save-btn").textContent=
    saved.some(x=>x.id===r.id)?"★ Salvo":"☆ Salvar";
}

function playLabel(p){
  return {
    equilibrado:"Equilibrado",
    rush:"Avançar / rush",
    precisao:"Precisão"
  }[p];
}

function touchLabel(t){
  return {
    normal:"Normal",
    rapida:"Rápida",
    suave:"Suave"
  }[t];
}

function resultText(r){
  return `SUPRA SENSI — FREE FIRE
Aparelho: ${r.device}
Estilo: ${r.style}
Geral: ${r.values.geral}
Ponto vermelho: ${r.values.ponto}
Mira 2x: ${r.values.mira2x}
Mira 4x: ${r.values.mira4x}
Mira AWM: ${r.values.awm}
Olhadinha: ${r.values.olhadinha}
Botão de disparo: ${r.button}%${r.dpi?"\nDPI sugerido: "+r.dpi:""}

Sugestão inicial; ajuste no jogo conforme sua preferência.`;
}

function saveCurrent(){
  if(!state.result)return;

  const r=state.result;

  if(saved.some(x=>x.id===r.id)){
    toast("Essa configuração já está salva.");
    return;
  }

  saved.unshift(r);
  persist();
  renderResult();
  renderLists();
  toast("Configuração salva nos favoritos.");
}

function renderLists(){
  $("#saved-list").innerHTML=saved.length?
    saved.map(r=>entryHTML(r,true)).join(""):
    '<div class="empty-state"><b>Nenhum favorito ainda</b>Gere uma sensibilidade e toque em “Salvar” para guardá-la.</div>';

  $("#history-list").innerHTML=history.length?
    history.map(r=>entryHTML(r,false)).join(""):
    '<div class="empty-state"><b>Seu histórico está vazio</b>As sensibilidades geradas aparecerão aqui.</div>';

  $$(".entry-actions button").forEach(b=>
    b.addEventListener("click",()=>entryAction(b.dataset.action,Number(b.dataset.id)))
  );
}

function entryHTML(r,isSaved){
  return `<article class="entry">
    <div class="entry-head">
      <div>
        <strong>${escapeHTML(r.device)}</strong>
        <small>${new Date(r.date).toLocaleString("pt-BR")} · Sensi ${r.style}</small>
      </div>
      <span class="result-badge">${r.platform==="ios"?"iOS":"ANDROID"}</span>
    </div>

    <div class="entry-values">
      <span>Geral ${r.values.geral}</span>
      <span>Vermelho ${r.values.ponto}</span>
      <span>2x ${r.values.mira2x}</span>
      <span>4x ${r.values.mira4x}</span>
      ${r.dpi?`<span>DPI ${r.dpi}</span>`:""}
    </div>

    <div class="entry-actions">
      <button data-action="load" data-id="${r.id}">Abrir configuração</button>
      <button data-action="${isSaved?"remove":"copy"}" data-id="${r.id}">
        ${isSaved?"Remover dos salvos":"Copiar"}
      </button>
    </div>
  </article>`;
}

function entryAction(action,id){
  const r=[...saved,...history].find(x=>x.id===id);
  if(!r)return;

  if(action==="remove"){
    saved=saved.filter(x=>x.id!==id);
    persist();
    renderLists();
    toast("Removido dos favoritos.");
  }else if(action==="copy"){
    copyText(resultText(r));
  }else{
    state.result=r;
    const wantedPlatform=r.platform;

    setPlatform(wantedPlatform);

    state.device=devices.find(d=>
      d.name===r.device&&d.platform===r.platform
    )||{
      name:r.device,
      platform:r.platform,
      power:"medio"
    };

    renderSelected();
    renderResult();
    switchTab("gerador");
    window.scrollTo({top:0,behavior:"smooth"});
  }
}

async function copyText(text){
  try{
    await navigator.clipboard.writeText(text);
    toast("Configuração copiada.");
  }catch(e){
    const ta=document.createElement("textarea");
    ta.value=text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
    toast("Configuração copiada.");
  }
}

function switchTab(tab){
  $$(".tab").forEach(b=>
    b.classList.toggle("active",b.dataset.tab===tab)
  );

  $$(".panel").forEach(p=>
    p.classList.toggle("active",p.id==="panel-"+tab)
  );

  if(tab!=="gerador")renderLists();
}

// PLATAFORMAS
$$(".platform").forEach(b=>
  b.addEventListener("click",()=>setPlatform(b.dataset.platform))
);

// PESQUISA
$("#device-search").addEventListener("input",renderSearch);
$("#device-search").addEventListener("focus",renderSearch);

// LIMPAR APARELHO
$("#clear-device").addEventListener("click",()=>{
  state.device=null;
  $("#device-search").value="";
  renderSelected();
  renderSearch();
});

// APARELHO PERSONALIZADO
$("#custom-device-btn").addEventListener("click",()=>
  $("#custom-dialog").showModal()
);

$("#use-custom").addEventListener("click",e=>{
  e.preventDefault();

  const name=$("#custom-name").value.trim();

  if(!name){
    toast("Digite o nome do aparelho.");
    return;
  }

  state.device={
    name,
    platform:state.platform,
    power:$("#custom-power").value,
    brand:"Personalizado"
  };

  $("#device-search").value=name;
  $("#custom-dialog").close();

  renderSelected();
  toast("Aparelho adicionado para esta sessão.");
});

// ESTILOS
$$(".style-card").forEach(b=>
  b.addEventListener("click",()=>{
    state.style=b.dataset.style;

    $$(".style-card").forEach(x=>
      x.classList.toggle("active",x===b)
    );
  })
);

// AJUSTES
$("#button-size").addEventListener("input",e=>
  $("#button-value").textContent=e.target.value+"%"
);

$("#dpi").addEventListener("change",e=>
  $("#dpi-value").textContent=({
    padrao:"Padrão",
    baixo:"Baixo",
    medio:"Médio",
    alto:"Alto"
  })[e.target.value]
);

// GERADOR
$("#generate-btn").addEventListener("click",generate);
$("#regenerate-btn").addEventListener("click",generate);

// SALVAR E COPIAR
$("#save-btn").addEventListener("click",saveCurrent);

$("#copy-btn").addEventListener("click",()=>
  state.result&&copyText(resultText(state.result))
);

// ABAS
$$(".tab").forEach(b=>
  b.addEventListener("click",()=>switchTab(b.dataset.tab))
);

// LIMPAR HISTÓRICO
$("#clear-history").addEventListener("click",()=>{
  if(!history.length)return;

  history=[];
  persist();
  renderLists();
  toast("Histórico apagado.");
});

// INICIALIZAÇÃO
$("#saved-count").textContent=saved.length;

renderSelected();
renderLists();
