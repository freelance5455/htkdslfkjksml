(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const startBtn = $("startBtn");
  const stopBtn = $("stopBtn");
  const statusText = $("statusText");
  const statusShort = $("statusShort");
  const statusDot = $("statusDot");
  const supportText = $("supportText");
  const heardText = $("heardText");
  const responseText = $("responseText");
  const commandForm = $("commandForm");
  const textCommand = $("textCommand");
  const app = document.querySelector(".app-shell");

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let listening = false;
  let manuallyStopped = false;
  let restarting = false;
  let lastWakeAt = 0;

  function setStatus(message, shortLabel = "PRONTO") {
    statusText.textContent = message;
    statusShort.textContent = shortLabel;
  }

  function showSupport() {
    if (!SpeechRecognition) {
      supportText.textContent = "Este navegador não oferece reconhecimento de voz Web Speech. Tente o Google Chrome atualizado.";
      startBtn.disabled = true;
      setStatus("Reconhecimento de voz indisponível neste navegador.", "INDISPONÍVEL");
      $("connectionLabel").textContent = "VOICE API INDISPONÍVEL";
      return;
    }
    supportText.textContent = "Reconhecimento de voz disponível. A permissão do microfone será solicitada ao iniciar.";
    $("connectionLabel").textContent = "WEB SPEECH API";
  }

  function speak(message) {
    if (!("speechSynthesis" in window)) {
      responseText.textContent = message + " (A fala sintetizada não é suportada neste navegador.)";
      return;
    }
    responseText.textContent = message;
    // Pausar reconhecimento durante a fala reduz a chance de o microfone captar a própria voz.
    if (recognition && listening) {
      restarting = true;
      try { recognition.stop(); } catch (_) {}
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = "pt-BR";
    utterance.rate = 1;
    utterance.pitch = 0.92;
    utterance.onend = () => {
      if (listening && !manuallyStopped) {
        window.setTimeout(() => startRecognition(), 450);
      }
    };
    utterance.onerror = () => {
      if (listening && !manuallyStopped) window.setTimeout(() => startRecognition(), 450);
    };
    window.speechSynthesis.speak(utterance);
  }

  function localReply(rawCommand) {
    const command = rawCommand.toLocaleLowerCase("pt-BR").replace(/[.,!?;:]/g, " ").replace(/\s+/g, " ").trim();
    const now = new Date();
    if (!command) return "Não ouvi um comando completo. Pode repetir?";
    if (/\b(que horas|hora agora|horário)\b/.test(command)) {
      return "Agora são " + now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }) + ".";
    }
    if (/\b(data de hoje|que dia|data hoje)\b/.test(command)) {
      return "Hoje é " + now.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) + ".";
    }
    if (/\b(seu nome|quem é você|quem voce e)\b/.test(command)) {
      return "Sou o JARVIS, um protótipo de assistente de voz. Ainda não estou conectado a uma inteligência artificial online.";
    }
    if (/\b(ajuda|comandos|o que você faz|o que voce faz)\b/.test(command)) {
      return "Por enquanto, posso dizer as horas, informar a data e explicar que sou um protótipo. A inteligência artificial será uma próxima etapa.";
    }
    if (/\b(parar de ouvir|desligar escuta|pare de ouvir)\b/.test(command)) {
      stopListening();
      return "Entendido. Vou parar a escuta.";
    }
    if (/\b(olá|ola|oi|bom dia|boa tarde|boa noite)\b/.test(command)) {
      return "Olá! Estou funcionando. Diga ajuda para conhecer os comandos disponíveis.";
    }
    return "Ouvi seu comando, mas ainda não tenho uma inteligência artificial conectada para responder a perguntas abertas. Por enquanto, experimente perguntar as horas, a data ou dizer ajuda.";
  }

  function handleRecognizedText(transcript) {
    const cleaned = transcript.trim();
    if (!cleaned) return;
    heardText.textContent = cleaned;
    const normalized = cleaned.toLocaleLowerCase("pt-BR");
    const wakeMatch = normalized.match(/\bjarvis\b/i);
    if (!wakeMatch) {
      setStatus("Escutando… diga “Jarvis” antes do comando.", "ESCUTANDO");
      return;
    }

    const now = Date.now();
    if (now - lastWakeAt < 1800) return; // evita responder duas vezes ao mesmo resultado
    lastWakeAt = now;

    let command = cleaned.slice(wakeMatch.index + wakeMatch[0].length).trim();
    command = command.replace(/^[,.:;!\-\s]+/, "");
    if (!command) {
      speak("Estou ouvindo. Qual é o seu comando?");
      setStatus("Palavra de ativação detectada.", "JARVIS ATIVO");
      return;
    }
    setStatus("Comando recebido. Processando localmente…", "PROCESSANDO");
    const reply = localReply(command);
    speak(reply);
  }

  function startRecognition() {
    if (!SpeechRecognition || !listening || manuallyStopped || restarting) return;
    try {
      recognition = new SpeechRecognition();
      recognition.lang = "pt-BR";
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        restarting = false;
        app.classList.add("listening");
        setStatus("Escutando… diga “Jarvis” seguido do comando.", "ESCUTANDO");
      };

      recognition.onresult = (event) => {
        let finalTranscript = "";
        let interimTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript || "";
          if (event.results[i].isFinal) finalTranscript += transcript + " ";
          else interimTranscript += transcript;
        }
        if (interimTranscript) {
          heardText.textContent = interimTranscript.trim() + " …";
          if (/\bjarvis\b/i.test(interimTranscript)) {
            setStatus("Detectando palavra de ativação…", "DETECTANDO");
          }
        }
        if (finalTranscript.trim()) handleRecognizedText(finalTranscript.trim());
      };

      recognition.onerror = (event) => {
        const errors = {
          "not-allowed": "Permissão do microfone negada. Libere o microfone nas configurações do navegador.",
          "service-not-allowed": "O serviço de reconhecimento de voz não foi permitido pelo navegador.",
          "no-speech": "Não detectei fala. Continuarei tentando enquanto o navegador permitir.",
          "audio-capture": "Não consegui acessar um microfone.",
          "network": "O serviço de reconhecimento retornou erro de rede. Verifique a conexão."
        };
        if (event.error === "not-allowed" || event.error === "service-not-allowed") {
          listening = false;
          updateControls();
          setStatus(errors[event.error] || "Erro de reconhecimento.", "ERRO");
          supportText.textContent = errors[event.error];
        } else if (event.error !== "aborted") {
          supportText.textContent = errors[event.error] || ("Erro de voz: " + event.error);
        }
      };

      recognition.onend = () => {
        restarting = false;
        if (listening && !manuallyStopped && !window.speechSynthesis.speaking) {
          // O navegador pode encerrar a sessão de reconhecimento sozinho.
          window.setTimeout(startRecognition, 500);
        } else if (!listening) {
          app.classList.remove("listening");
        }
      };

      recognition.start();
    } catch (error) {
      restarting = false;
      supportText.textContent = "Não foi possível iniciar o reconhecimento: " + error.message;
      setStatus("Não foi possível iniciar a escuta.", "ERRO");
    }
  }

  function updateControls() {
    startBtn.disabled = listening || !SpeechRecognition;
    stopBtn.disabled = !listening;
    if (!listening) app.classList.remove("listening");
  }

  function stopListening() {
    manuallyStopped = true;
    listening = false;
    restarting = false;
    if (recognition) {
      try { recognition.onend = null; recognition.stop(); } catch (_) {}
      recognition = null;
    }
    if ("speechSynthesis" in window) window.speechSynthesis.cancel();
    updateControls();
    setStatus("Escuta parada. Toque em “Iniciar escuta” para recomeçar.", "PARADO");
  }

  function startListening() {
    if (!SpeechRecognition) return;
    manuallyStopped = false;
    listening = true;
    updateControls();
    setStatus("Solicitando acesso ao microfone…", "INICIANDO");
    startRecognition();
  }

  startBtn.addEventListener("click", startListening);
  stopBtn.addEventListener("click", stopListening);

  commandForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const value = textCommand.value.trim();
    if (!value) return;
    heardText.textContent = value;
    let command = value.replace(/^\s*jarvis\b[:,.! -]*/i, "");
    if (command === value) {
      speak("Para simular um comando, comece a frase com Jarvis. " + localReply(value));
    } else {
      speak(localReply(command));
    }
    textCommand.value = "";
  });

  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("./sw.js").catch((error) => {
        console.warn("Falha ao registrar service worker:", error);
      });
    });
  }

  showSupport();
})();
