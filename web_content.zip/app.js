const K="vetdb";
let d;
try { d=JSON.parse(localStorage.getItem(K)||'{}'); } catch(e) { d={}; }
d.e=Array.isArray(d.e)?d.e:[]; d.p=Array.isArray(d.p)?d.p:[]; d.r=Array.isArray(d.r)?d.r:[]; d.f=Array.isArray(d.f)?d.f:[]; d.g=Array.isArray(d.g)?d.g:[]; d.l=Array.isArray(d.l)?d.l:[]; d.s=Array.isArray(d.s)?d.s:[]; d.a=Array.isArray(d.a)?d.a:[]; d.v=Array.isArray(d.v)?d.v:[];
let editId=null, editType=null;
const save=()=>localStorage.setItem(K,JSON.stringify(d)), id=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
// Migration douce des anciennes données pour conserver les fiches existantes.
d.e.forEach(x=>{if(!x.createdAt)x.createdAt=Number(x.id,36)||Date.now(); if(x.esp==="Mixte"){x.bovins=x.bovins??"";x.ovins=x.ovins??"";x.caprins=x.caprins??"";} if(x.rendezvousDate===undefined)x.rendezvousDate="";});
d.p.forEach(x=>{if(x.oldStock===undefined)x.oldStock=x.stock||"0";if(x.newStock===undefined)x.newStock="0";if(!x.cat)x.cat=classify(x.nom+" "+(x.actif||""));if(x.stock===undefined)x.stock=String(Number(x.oldStock||0)+Number(x.newStock||0));});
d.r.forEach(x=>{if(!x.createdAt)x.createdAt=Date.now();});
if(!d.settings)d.settings={cabinetModel:"complet"}; save();
function page(x){
 const isDashboard=x==="dashboard";
 fermerApercuImpression(false);
 const names={e:"🐄 Éleveurs / Élevages",p:"💊 Médicaments / Produits",r:"📅 Rendez-vous",c:"🏥 Gestion du cabinet",g:"🤰 Reproduction et échographie",l:"🔬 Laboratoire et analyses",s:"🩺 Dossiers sanitaires",a:"💳 Comptes des éleveurs",v:"🚗 Tournées et déplacements"};
 document.getElementById("dashboard").hidden=!isDashboard;
 document.getElementById("screenbar").hidden=isDashboard;
 document.getElementById("screenTitle").textContent=names[x]||"Rubrique";
 document.querySelector("nav").hidden=true;
 ["e","p","r","c","g","l","s","a","v"].forEach(a=>{document.getElementById(a).hidden=a!==x;});
 document.querySelectorAll("nav button").forEach(b=>b.classList.remove("active"));
 const active=[...document.querySelectorAll("nav button")].find(b=>b.getAttribute("onclick")===`page('${x}')`);
 if(active)active.classList.add("active");
 if(!isDashboard)render();else renderDashboard();
 window.scrollTo({top:0,behavior:"auto"});
}
function closeForm(){document.getElementById("modal").hidden=true;editId=null;editType=null;}
function esc(x){return String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function val(o,k){return esc(o?.[k]??"")}
function field(name,label,type="text",placeholder="",extra=""){return `<label>${label}</label><input name="${name}" type="${type}" ${placeholder?`placeholder="${placeholder}"`:""} ${extra}>`}
function locationField(name="loc",label="Lieu / localité"){return `<label>${label}</label><input name="${name}" list="knownLocations" placeholder="Commune, village ou lieu-dit">`}
function selectField(name,label,opts){return `<label>${label}</label><select name="${name}">${opts.map(o=>`<option value="${esc(o)}">${esc(o)}</option>`).join("")}</select>`}
function openForm(t,which=null){
 editType=t;editId=which;const old=which?(d[t]||[]).find(x=>x.id===which):null;const v=(k)=>old?.[k]??"";let h="";
 if(t==="e")h=`<h2>${old?"Modifier l'éleveur":"Nouvel éleveur"}</h2><form onsubmit="add(event,'e')">
 ${field("nom","Nom de l'éleveur / exploitation","text","Nom", "required")}${field("tel","Téléphone","tel","Téléphone")}${locationField()}
 ${selectField("esp","Type d'élevage",["Bovin","Ovin","Caprin","Mixte"])}
 <div class="species-grid"><div>${field("bovins","Nombre de bovins","number","0",'min="0" step="1"')}</div><div>${field("ovins","Nombre d'ovins","number","0",'min="0" step="1"')}</div><div>${field("caprins","Nombre de caprins","number","0",'min="0" step="1"')}</div></div>
 ${field("tetes","Nombre total de têtes","number","Total",'min="0"')}${field("trait","Traitement / diagnostic")}${field("duree","Durée du traitement (jours)","number","Durée",'min="0"')}${field("start","Date de début du traitement","date")}${field("rappel","Date du rappel","date")}${field("rendezvousDate","Prochain rendez-vous","date")}${field("rendezvousHeure","Heure du rendez-vous","time")}
 <textarea name="notes" placeholder="Observations">${val(old,"notes")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer"}</button></form>`;
 if(t==="p")h=`<h2>${old?"Modifier le produit":"Nouveau produit"}</h2><form onsubmit="add(event,'p')">
 ${field("nom","Nom du produit","text","Nom du médicament","required")}${selectField("cat","Catégorie",["Antibiotique","Antiparasitaire","Vitamine et minéraux","Anti-inflammatoire","Autre"])}${field("actif","Principe actif")}${field("lot","N° de lot")}
 <div class="species-grid"><div>${field("oldStock","Ancien arrivage / stock initial","number","Quantité",'min="0" step=".01"')}</div><div>${field("newStock","Nouvel arrivage","number","Quantité reçue",'min="0" step=".01"')}</div></div>${field("stock","Stock total (calculé)","number","Total",'min="0" step=".01" readonly')}${field("seuil","Seuil d'alerte","number","Seuil",'min="0" step=".01"')}${field("achat","Prix d'achat (DA)","number","DA",'min="0" step=".01"')}${field("vente","Prix de vente (DA)","number","DA",'min="0" step=".01"')}${field("exp","Date de péremption","date")}${field("fourn","Fournisseur")}<textarea name="notes" placeholder="Observations">${val(old,"notes")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer"}</button></form>`;
 if(t==="r")h=`<h2>${old?"Modifier le rendez-vous":"Nouveau rendez-vous"}</h2><form onsubmit="add(event,'r')">${field("date","Date","date","", "required")}${field("heure","Heure","time")}${field("nom","Éleveur / client","text","Nom","required")}${field("tel","Téléphone","tel")}${locationField()}${selectField("motif","Motif",["Consultation","Échographie","Vaccination","Traitement","Visite d'élevage","Laboratoire / analyse","Autre"])}${field("animal","Animal / espèce")}${selectField("urg","Urgence",["Normale","Urgente","Très urgente"])}<textarea name="notes" placeholder="Motif / observations">${val(old,"notes")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer"}</button></form>`;
 if(t==="f")h=`<h2>${old?"Modifier l'opération":"Nouvelle recette / dépense"}</h2><form onsubmit="add(event,'f')">${selectField("type","Type d'opération",["Recette","Dépense"])}${field("date","Date","date","","required")}${field("libelle","Libellé / acte","text","Consultation, visite...","required")}${field("client","Éleveur / fournisseur")}${field("montant","Montant (DA)","number","DA",'min="0" step=".01" required')}${locationField("loc","Lieu (facultatif)")}<textarea name="notes" placeholder="Notes">${val(old,"notes")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer"}</button></form>`;

 if(t==="g")h=`<h2>${old?"Modifier le suivi reproductif":"Nouveau suivi reproductif"}</h2><form onsubmit="add(event,'g')">${field("client","Éleveur / exploitation","text","Nom de l'éleveur","required")}${field("tel","Téléphone","tel")}${locationField()}${selectField("espece","Espèce",["Bovin","Ovin","Caprin"])}${field("animal","Identification de l'animal / lot")}${field("saillie","Date de saillie / insémination","date")}${field("echo","Date de l'échographie","date")}${selectField("resultat","Résultat de l'échographie",["En attente","Gestante","Non gestante","À contrôler"])}${field("controle","Date du prochain contrôle","date")}${field("misebas","Date prévue de mise bas","date")}${field("misebasReelle","Date réelle de mise bas","date")}<textarea name="notes" placeholder="Observations / diagnostic">${val(old,"notes")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer"}</button></form>`;
 if(t==="l")h=`<h2>${old?"Modifier l'analyse":"Nouvelle analyse de laboratoire"}</h2><form onsubmit="add(event,'l')">${field("date","Date du prélèvement / analyse","date","","required")}${field("client","Éleveur / client","text","Nom","required")}${locationField()}${selectField("espece","Espèce",["Bovin","Ovin","Caprin","Chien","Chat","Autre"])}${field("animal","Animal / numéro de prélèvement")}${selectField("typeAnalyse","Type d'analyse",["Coproscopie","Examen microscopique","Recherche parasitaire","Autre"])}${field("echantillon","Nature / référence du prélèvement")}${selectField("resultat","Résultat",["En attente","Négatif","Positif","À confirmer"])}<textarea name="compteRendu" placeholder="Observations et compte rendu">${val(old,"compteRendu")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer l'analyse"}</button></form>`;
 if(t==="s")h=`<h2>${old?"Modifier le dossier sanitaire":"Nouvel événement sanitaire"}</h2><form onsubmit="add(event,'s')">${field("date","Date","date","","required")}${field("client","Éleveur / élevage","text","Nom","required")}${locationField()}${selectField("espece","Espèce",["Bovin","Ovin","Caprin","Mixte","Autre"])}${field("effectif","Nombre d'animaux concernés","number","0",'min="0" step="1"')}${selectField("categorie","Type d'événement",["Maladie","Vaccination","Traitement","Mortalité","Prévention","Autre"])}${field("diagnostic","Maladie / vaccin / traitement")}${field("produit","Produit utilisé (si applicable)")}${field("quantite","Quantité / dose administrée")}${selectField("statut","Statut",["En cours","Terminé","Contrôle nécessaire"])}${field("rappel","Date du prochain contrôle","date")}<textarea name="notes" placeholder="Signes, observations, nombre de morts, conduite à tenir">${val(old,"notes")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer"}</button></form>`;
 if(t==="a")h=`<h2>${old?"Modifier l'opération du compte":"Nouvelle opération de compte"}</h2><form onsubmit="add(event,'a')">${field("date","Date","date","","required")}${field("client","Nom de l'éleveur","text","Nom","required")}${selectField("type","Type d'opération",["Acte facturé","Avance reçue","Règlement reçu","Avoir / correction"])}${field("libelle","Motif / acte","text","Consultation, traitement...","required")}${field("montant","Montant (DA)","number","DA",'min="0" step=".01" required')}${locationField()}<textarea name="notes" placeholder="Notes">${val(old,"notes")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer"}</button></form>`;
 if(t==="v")h=`<h2>${old?"Modifier la visite":"Nouvelle visite / tournée"}</h2><form onsubmit="add(event,'v')">${field("date","Date de la visite","date","","required")}${field("heure","Heure","time")}${field("client","Éleveur / exploitation","text","Nom","required")}${field("tel","Téléphone","tel")}${locationField()}${field("motif","Motif de la visite","text","Vaccination, échographie...")}${selectField("statut","Statut",["Prévue","En cours","Terminée","Annulée"])}${field("km","Distance (km)","number","0",'min="0" step=".1"')}${field("frais","Frais de déplacement (DA)","number","DA",'min="0" step=".01"')}${field("honoraires","Honoraires / actes (DA)","number","DA",'min="0" step=".01"')}<textarea name="notes" placeholder="Compte rendu de visite">${val(old,"notes")}</textarea><button type="submit">${old?"Enregistrer les modifications":"Enregistrer la visite"}</button></form>`;

 document.getElementById("form").innerHTML=h;document.getElementById("modal").hidden=false;
 const form=document.querySelector("#form form");
 if(old){Object.entries(old).forEach(([k,z])=>{const el=form.elements.namedItem(k);if(el&&k!=="id"&&k!=="createdAt")el.value=z??"";});}
 if(t==="e") {const esp=form.elements.namedItem("esp");esp.addEventListener("change",()=>toggleSpecies(form));form.elements.tetes.addEventListener("input",()=>{if(form.elements.esp.value!=="Mixte"){const key={Bovin:"bovins",Ovin:"ovins",Caprin:"caprins"}[form.elements.esp.value];["bovins","ovins","caprins"].forEach(n=>form.elements[n].value=n===key?form.elements.tetes.value:"");}});["bovins","ovins","caprins"].forEach(n=>form.elements.namedItem(n).addEventListener("input",()=>calcHeads(form)));toggleSpecies(form);calcHeads(form);}
 if(t==="p"){if(old)form.elements.cat.dataset.manual="1";const calc=()=>{form.elements.stock.value=(Number(form.elements.oldStock.value)||0)+(Number(form.elements.newStock.value)||0)};form.elements.oldStock.addEventListener("input",calc);form.elements.newStock.addEventListener("input",calc);form.elements.nom.addEventListener("input",()=>{const c=classify(form.elements.nom.value+" "+form.elements.actif.value);if(!form.elements.cat.dataset.manual)form.elements.cat.value=c;});form.elements.actif.addEventListener("input",()=>{const c=classify(form.elements.nom.value+" "+form.elements.actif.value);if(!form.elements.cat.dataset.manual)form.elements.cat.value=c;});form.elements.cat.addEventListener("change",()=>form.elements.cat.dataset.manual="1");calc();}
}
function toggleSpecies(form){const mix=form.elements.esp.value==="Mixte";form.elements.tetes.readOnly=mix;form.elements.tetes.previousElementSibling.textContent=mix?"Total des têtes (calculé)":"Nombre de têtes";["bovins","ovins","caprins"].forEach(n=>{const el=form.elements.namedItem(n);el.closest("div").hidden=!mix;});if(!mix){form.elements.bovins.value=form.elements.esp.value==="Bovin"?form.elements.tetes.value:"";form.elements.ovins.value=form.elements.esp.value==="Ovin"?form.elements.tetes.value:"";form.elements.caprins.value=form.elements.esp.value==="Caprin"?form.elements.tetes.value:"";}calcHeads(form);}
function calcHeads(form){let n=0;["bovins","ovins","caprins"].forEach(k=>n+=Number(form.elements.namedItem(k).value)||0);const esp=form.elements.esp.value;if(esp!=="Mixte"){const v=form.elements.namedItem("tetes").value;n=Number(v)||n;}else form.elements.namedItem("tetes").value=n;}
function add(ev,t){ev.preventDefault();const form=ev.target;let o=editId?(d[t]||[]).find(x=>x.id===editId)||{}:{id:id(),createdAt:Date.now()};new FormData(form).forEach((v,k)=>o[k]=String(v));if(t==="e"){if(o.esp==="Mixte")o.tetes=String((Number(o.bovins)||0)+(Number(o.ovins)||0)+(Number(o.caprins)||0));else{if(o.esp==="Bovin")o.bovins=o.tetes;if(o.esp==="Ovin")o.ovins=o.tetes;if(o.esp==="Caprin")o.caprins=o.tetes;}o.createdAt=o.createdAt||Date.now();}
 if(t==="p"){o.stock=String((Number(o.oldStock)||0)+(Number(o.newStock)||0));o.cat=o.cat||classify(o.nom+" "+o.actif);}
 if(t==="r")o.createdAt=o.createdAt||Date.now();if(editId){const ix=d[t].findIndex(x=>x.id===editId);if(ix>=0)d[t][ix]=o;else d[t].unshift(o);}else d[t].unshift(o);save();closeForm();render();}
function del(t,i){if(confirm("Supprimer définitivement cet élément ?")){d[t]=d[t].filter(x=>x.id!==i);save();render();}}
function addArrival(i){const x=d.p.find(p=>p.id===i);if(!x)return;const raw=prompt("Quantité du nouvel arrivage :","0");if(raw===null)return;const qty=Number(raw);if(!Number.isFinite(qty)||qty<0){alert("Saisis une quantité positive ou nulle.");return;}const current=Number(x.stock??((Number(x.oldStock)||0)+(Number(x.newStock)||0)))||0;x.oldStock=String(current);x.newStock=String(qty);x.stock=String(current+qty);save();render();}
function classify(s){s=String(s||"").toLowerCase();if(/antibiot|amoxic|penicill|oxytetracycl|gentamic|enroflox|sulfamid|tilosin|ceftiofur/.test(s))return "Antibiotique";if(/antiparasit|ivermect|doramect|albendazol|fenbendazol|closantel|moxidect|triclabendazol|dectomax|pour.on|ectoparasit/.test(s))return "Antiparasitaire";if(/vitamin|minéral|mineral|vitamine|vit\s*[a-z0-9]/.test(s))return "Vitamine et minéraux";if(/anti.inflamm|flunixin|meloxicam|dexamethason|ketoprofen|prednisolon/.test(s))return "Anti-inflammatoire";return "Autre";}
function dateObj(s){return s?new Date(s+"T00:00:00"):null}function daysUntil(s){let z=dateObj(s);if(!z)return null;return Math.ceil((z-new Date(new Date().toDateString()))/86400000)}
function treatmentEnd(x){if(!x.start||!x.duree)return "";let z=dateObj(x.start);if(!z)return "";z.setDate(z.getDate()+Number(x.duree));return z.toISOString().slice(0,10)}
function renderDashboard(){
 const el=document.getElementById("dashboardStats");if(!el)return;
 const today=new Date().toISOString().slice(0,10);
 const appointments=d.r.filter(x=>x.date===today).length+d.e.filter(x=>x.rendezvousDate===today).length;
 const lowStock=d.p.filter(x=>x.seuil!==""&&Number(x.stock)<=Number(x.seuil)).length;
 const overdue=d.p.filter(x=>x.exp&&daysUntil(x.exp)<0).length;
 const revenue=d.f.filter(x=>x.type==="Recette").reduce((n,x)=>n+Number(x.montant||0),0);
 el.innerHTML=`<div class="summary-card"><span>Éleveurs enregistrés</span><b>${d.e.length}</b></div><div class="summary-card"><span>Produits en stock</span><b>${d.p.length}</b></div><div class="summary-card"><span>Rendez-vous aujourd'hui</span><b>${appointments}</b></div><div class="summary-card"><span>Alertes de stock</span><b>${lowStock+overdue}</b></div><div class="summary-card"><span>Recettes enregistrées</span><b>${revenue.toLocaleString("fr-FR")} DA</b></div>`;
}
function renderAlerts(){let a=[];const push=(kind,title,text)=>a.push(`<div class="alert ${kind}"><div class="alert-title">${title}</div><div>${text}</div></div>`);d.p.forEach(x=>{if(x.seuil!==""&&Number(x.stock)<=Number(x.seuil))push("red","📦 Stock faible",`${esc(x.nom)} — stock ${esc(x.stock)}, seuil ${esc(x.seuil)}`);if(x.exp){let n=daysUntil(x.exp);if(n<0)push("red","⚠️ Produit périmé",`${esc(x.nom)} — ${esc(x.exp)}`);else if(n<=30)push("","⏳ Péremption proche",`${esc(x.nom)} — dans ${n} jour(s) (${esc(x.exp)})`);}});d.e.forEach(x=>{if(x.trait&&x.start&&x.duree){let end=treatmentEnd(x),n=daysUntil(end);if(n<0)push("red","💊 Traitement dépassé",`${esc(x.nom)} — fin prévue ${end}`);else if(n<=2)push("","💊 Fin de traitement proche",`${esc(x.nom)} — fin prévue ${end}`);}if(x.rappel){let n=daysUntil(x.rappel);if(n<0)push("red","🔔 Rappel en retard",`${esc(x.nom)} — ${esc(x.rappel)}`);else if(n<=3)push("","🔔 Rappel proche",`${esc(x.nom)} — ${esc(x.rappel)}`);}if(x.rendezvousDate){let n=daysUntil(x.rendezvousDate);if(n!==null&&n>=0&&n<=1)push("","📅 Rendez-vous éleveur",`${esc(x.nom)} — ${esc(x.rendezvousDate)} ${esc(x.rendezvousHeure)}`);}});d.r.forEach(x=>{if(x.date){let n=daysUntil(x.date);if(n!==null&&n>=0&&n<=1)push(x.urg==="Très urgente"?"red":"","📅 Rendez-vous proche",`${esc(x.date)} ${esc(x.heure)} — ${esc(x.nom)} — ${esc(x.motif)}`);}});d.g.forEach(x=>{if(x.controle){let n=daysUntil(x.controle);if(n!==null&&n>=0&&n<=3)push("","🤰 Contrôle reproductif",`${esc(x.client)} — contrôle prévu le ${esc(x.controle)}`);}if(x.misebas){let n=daysUntil(x.misebas);if(n!==null&&n>=0&&n<=7)push("","🐄 Mise bas prévue",`${esc(x.client)} — ${esc(x.espece)} — ${esc(x.misebas)}`);}});d.s.forEach(x=>{if(x.rappel){let n=daysUntil(x.rappel);if(n!==null&&n>=0&&n<=3)push("","🩺 Contrôle sanitaire",`${esc(x.client)} — ${esc(x.rappel)} — ${esc(x.diagnostic)}`);}});document.getElementById("alerts").innerHTML=a.length?`<div class="alert-grid">${a.join("")}</div>`:`<div class="alert green">✅ Aucune alerte pour le moment.</div>`;}
function render(){const q=(document.getElementById("eq").value||"").toLowerCase(),sort=document.getElementById("esort").value;let farmers=d.e.filter(x=>([x.nom,x.tel,x.loc,x.esp,x.trait,x.notes].join(" ")).toLowerCase().includes(q));farmers.sort((a,b)=>sort==="name"?String(a.nom).localeCompare(String(b.nom)):sort==="appointment"?(String(a.rendezvousDate||"9999-99-99")+String(a.rendezvousHeure||"99:99")).localeCompare(String(b.rendezvousDate||"9999-99-99")+String(b.rendezvousHeure||"99:99")):Number(b.createdAt||0)-Number(a.createdAt||0));
 document.getElementById("el").innerHTML=farmers.map(x=>`<div class="card"><b>🐄 ${esc(x.nom)}</b><br>${esc(x.esp)} · ${esc(x.tetes||0)} têtes${x.esp==="Mixte"?` (Bovins ${esc(x.bovins||0)} · Ovins ${esc(x.ovins||0)} · Caprins ${esc(x.caprins||0)})`:""}<br>📞 ${esc(x.tel)} · 📍 ${esc(x.loc)}<br>💊 ${esc(x.trait)} ${x.duree?`· ${esc(x.duree)} jours`:""}${x.start?`<br>Début : ${esc(x.start)}${x.duree?` · Fin : ${esc(treatmentEnd(x))}`:""}`:""}${x.rappel?`<br>🔔 Rappel : ${esc(x.rappel)}`:""}${x.rendezvousDate?`<br>📅 Prochain rendez-vous : ${esc(x.rendezvousDate)} ${esc(x.rendezvousHeure)}`:""}<br><button onclick="openForm('e','${x.id}')">✏️ Modifier</button><button class="danger" onclick="del('e','${x.id}')">Supprimer</button></div>`).join("")||"<div class=card>Aucun éleveur.</div>";
 const pq=(document.getElementById("pq").value||"").toLowerCase(),pcat=document.getElementById("pcat").value,psort=document.getElementById("psort")?.value||"name";const products=d.p.filter(x=>(!pcat||x.cat===pcat)&&([x.nom,x.cat,x.actif,x.lot].join(" ")).toLowerCase().includes(pq));products.sort((a,b)=>{if(psort==="stockLow")return (Number(a.stock)||0)-(Number(b.stock)||0);if(psort==="stockHigh")return (Number(b.stock)||0)-(Number(a.stock)||0);if(psort==="expiry")return String(a.exp||"9999-99-99").localeCompare(String(b.exp||"9999-99-99"));return String(a.nom||"").localeCompare(String(b.nom||""),"fr",{sensitivity:"base"});});document.getElementById("pl").innerHTML=products.map(x=>`<div class="card"><b>💊 ${esc(x.nom)}</b><span class="pill">${esc(x.cat||"Autre")}</span><br>Ancien stock : ${esc(x.oldStock||0)} · Nouvel arrivage : ${esc(x.newStock||0)} · <b>Total : ${esc(x.stock||0)}</b><br>Seuil : ${esc(x.seuil)} · Achat : ${esc(x.achat)} DA · Vente : ${esc(x.vente)} DA<br>Lot : ${esc(x.lot)} · Péremption : ${esc(x.exp||"—")}<br>${x.actif?`Actif : ${esc(x.actif)}<br>`:""}<button onclick="openForm('p','${x.id}')">✏️ Modifier</button><button onclick="addArrival('${x.id}')">＋ Nouvel arrivage</button><button class="danger" onclick="del('p','${x.id}')">Supprimer</button></div>`).join("")||"<div class=card>Aucun produit.</div>";
 const rq=(document.getElementById("rq").value||"").toLowerCase();document.getElementById("rl").innerHTML=d.r.filter(x=>([x.nom,x.tel,x.motif,x.animal,x.loc].join(" ")).toLowerCase().includes(rq)).sort((a,b)=>(a.date+a.heure).localeCompare(b.date+b.heure)).map(x=>`<div class="card"><b>📅 ${esc(x.date)} ${esc(x.heure)}</b><br>${esc(x.nom)} · 📞 ${esc(x.tel)}<br>📍 ${esc(x.loc)}<br>Motif : ${esc(x.motif)} · ${esc(x.animal)}<br>Urgence : ${esc(x.urg)}<br><button onclick="openForm('r','${x.id}')">✏️ Modifier</button><button onclick="location.href='tel:${esc(x.tel)}'">📞 Appeler</button><button class="danger" onclick="del('r','${x.id}')">Supprimer</button></div>`).join("")||"<div class=card>Aucun rendez-vous.</div>";
 renderFinance();renderLocations();renderNewModules();renderAlerts();renderDashboard();}
function renderLocations(){const vals=[...d.e,...d.r,...d.f,...d.g,...d.l,...d.s,...d.a,...d.v].map(x=>x.loc).filter(Boolean);document.getElementById("knownLocations").innerHTML=[...new Set(vals)].sort().map(x=>`<option value="${esc(x)}">`).join("");}
function setCabinetModel(v){d.settings.cabinetModel=v;save();}
function renderFinance(){const sum=(type)=>d.f.filter(x=>x.type===type).reduce((n,x)=>n+(Number(x.montant)||0),0),rec=sum("Recette"),dep=sum("Dépense");document.getElementById("cabinetModel").value=d.settings.cabinetModel||"complet";document.getElementById("financeSummary").innerHTML=`<div class="summary-card"><span>Recettes</span><b>${rec.toLocaleString("fr-FR")} DA</b></div><div class="summary-card"><span>Dépenses</span><b>${dep.toLocaleString("fr-FR")} DA</b></div><div class="summary-card"><span>Solde</span><b>${(rec-dep).toLocaleString("fr-FR")} DA</b></div>`;document.getElementById("fl").innerHTML=d.f.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).map(x=>`<div class="card"><b>${esc(x.type)} — ${esc(x.libelle)}</b><br>${esc(x.date)} · ${esc(x.client)} · ${esc(x.loc)}<br><b>${Number(x.montant||0).toLocaleString("fr-FR")} DA</b><br><button onclick="openForm('f','${x.id}')">✏️ Modifier</button><button class="danger" onclick="del('f','${x.id}')">Supprimer</button></div>`).join("")||"<div class=card>Aucune opération enregistrée.</div>";}

function moduleCard(type,x,title,body){return `<div class="card"><b>${title}</b><br>${body}<br><button onclick="openForm('${type}','${x.id}')">✏️ Modifier</button><button class="danger" onclick="del('${type}','${x.id}')">Supprimer</button></div>`;}
function renderNewModules(){
 const gq=(document.getElementById("gq")?.value||"").toLowerCase();document.getElementById("gl").innerHTML=d.g.filter(x=>[x.client,x.animal,x.loc,x.resultat,x.espece].join(" ").toLowerCase().includes(gq)).sort((a,b)=>String(a.misebas||a.controle||"9999").localeCompare(String(b.misebas||b.controle||"9999"))).map(x=>moduleCard("g",x,`🤰 ${esc(x.client)} — ${esc(x.espece)} ${esc(x.animal)}`,`Lieu : ${esc(x.loc)}<br>Saillie/IA : ${esc(x.saillie||"—")} · Échographie : ${esc(x.echo||"—")}<br>Résultat : <b>${esc(x.resultat||"En attente")}</b> · Contrôle : ${esc(x.controle||"—")}<br>Mise bas prévue : ${esc(x.misebas||"—")} · Réelle : ${esc(x.misebasReelle||"—")}<br>${esc(x.notes||"")}`)).join("")||"<div class=card>Aucun suivi reproductif.</div>";
 const lq=(document.getElementById("lq")?.value||"").toLowerCase();document.getElementById("ll").innerHTML=d.l.filter(x=>[x.client,x.animal,x.typeAnalyse,x.resultat,x.echantillon,x.compteRendu].join(" ").toLowerCase().includes(lq)).sort((a,b)=>String(b.date).localeCompare(String(a.date))).map(x=>moduleCard("l",x,`🔬 ${esc(x.typeAnalyse)} — ${esc(x.client)}`,`Date : ${esc(x.date)} · Espèce : ${esc(x.espece)} · Prélèvement : ${esc(x.echantillon||x.animal||"—")}<br>Résultat : <b>${esc(x.resultat)}</b><br>Compte rendu : ${esc(x.compteRendu||"—")}`)).join("")||"<div class=card>Aucune analyse enregistrée.</div>";
 const sq=(document.getElementById("sq")?.value||"").toLowerCase();document.getElementById("sl").innerHTML=d.s.filter(x=>[x.client,x.categorie,x.diagnostic,x.produit,x.loc,x.notes].join(" ").toLowerCase().includes(sq)).sort((a,b)=>String(b.date).localeCompare(String(a.date))).map(x=>moduleCard("s",x,`🩺 ${esc(x.client)} — ${esc(x.categorie)}`,`Date : ${esc(x.date)} · Espèce : ${esc(x.espece)} · Effectif : ${esc(x.effectif||"—")}<br>Diagnostic / acte : ${esc(x.diagnostic||"—")} · Produit : ${esc(x.produit||"—")}<br>Statut : ${esc(x.statut)} · Contrôle : ${esc(x.rappel||"—")}<br>${esc(x.notes||"")}`)).join("")||"<div class=card>Aucun dossier sanitaire.</div>";
 const aq=(document.getElementById("aq")?.value||"").toLowerCase();const accts=d.a.filter(x=>[x.client,x.libelle,x.loc,x.type].join(" ").toLowerCase().includes(aq));const clients=[...new Set(d.a.map(x=>x.client).filter(Boolean))].sort();document.getElementById("accountSummary").innerHTML=`<div class="summary-card"><span>Éleveurs avec compte</span><b>${clients.length}</b></div><div class="summary-card"><span>Actes facturés</span><b>${d.a.filter(x=>x.type==="Acte facturé").reduce((n,x)=>n+Number(x.montant||0),0).toLocaleString("fr-FR")} DA</b></div><div class="summary-card"><span>Règlements et avances</span><b>${d.a.filter(x=>["Avance reçue","Règlement reçu"].includes(x.type)).reduce((n,x)=>n+Number(x.montant||0),0).toLocaleString("fr-FR")} DA</b></div>`;document.getElementById("al").innerHTML=clients.filter(c=>c.toLowerCase().includes(aq)).map(c=>{const rows=d.a.filter(x=>x.client===c);const charges=rows.filter(x=>x.type==="Acte facturé").reduce((n,x)=>n+Number(x.montant||0),0);const paid=rows.filter(x=>["Avance reçue","Règlement reçu"].includes(x.type)).reduce((n,x)=>n+Number(x.montant||0),0);const credits=rows.filter(x=>x.type==="Avoir / correction").reduce((n,x)=>n+Number(x.montant||0),0);const balance=charges-paid-credits;return `<div class="card"><b>💳 ${esc(c)}</b><br>Actes facturés : ${charges.toLocaleString("fr-FR")} DA · Paiements/avances : ${paid.toLocaleString("fr-FR")} DA<br><b>Solde dû : ${balance.toLocaleString("fr-FR")} DA</b><br>${rows.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))).map(x=>`<div>${esc(x.date)} — ${esc(x.type)} : ${esc(x.libelle)} — ${Number(x.montant||0).toLocaleString("fr-FR")} DA <button onclick="openForm('a','${x.id}')">Modifier</button><button class="danger" onclick="del('a','${x.id}')">Supprimer</button></div>`).join("")}</div>`}).join("")||"<div class=card>Aucun compte enregistré.</div>";
 const vq=(document.getElementById("vq")?.value||"").toLowerCase();document.getElementById("vl").innerHTML=d.v.filter(x=>[x.client,x.loc,x.motif,x.statut,x.tel].join(" ").toLowerCase().includes(vq)).sort((a,b)=>(String(a.date)+String(a.heure)).localeCompare(String(b.date)+String(b.heure))).map(x=>moduleCard("v",x,`🚗 ${esc(x.date)} ${esc(x.heure)} — ${esc(x.client)}`,`📍 ${esc(x.loc)} · ${esc(x.motif)}<br>Statut : <b>${esc(x.statut)}</b> · Distance : ${esc(x.km||0)} km<br>Frais : ${Number(x.frais||0).toLocaleString("fr-FR")} DA · Honoraires : ${Number(x.honoraires||0).toLocaleString("fr-FR")} DA<br>${esc(x.notes||"")}`)).join("")||"<div class=card>Aucune tournée enregistrée.</div>";
}

function reportTable(title,rows){return `<h2>${title}</h2><table><thead><tr>${rows[0].map(x=>`<th>${esc(x)}</th>`).join("")}</tr></thead><tbody>${rows.slice(1).map(r=>`<tr>${r.map(x=>`<td>${esc(x)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;}
function showPrintDocument(title,rows,includeTitle=true){
 const view=document.getElementById("printView"),content=document.getElementById("printContent");
 if(!view||!content){alert("L’aperçu d’impression n’est pas disponible.");return;}
 content.innerHTML=`<h1>🐾 Clinique Vétérinaire</h1><h2>${esc(title)}</h2><p class="print-date">Édité le ${new Date().toLocaleDateString("fr-FR")}</p>${reportTable(title,rows)}`;
 document.getElementById("appMain").hidden=true;view.hidden=false;document.body.classList.add("show-print-view");window.scrollTo(0,0);
}
function imprimerDocument(){
 // Ne jamais ouvrir une fenêtre secondaire : certains APK WebView les bloquent
 // ou les affichent sans barre d'impression. L'export principal passe par le PDF.
 exporterDocumentImpression();
}
function pdfAscii(value){
 return String(value??"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/œ/gi,"oe").replace(/æ/gi,"ae").replace(/[^\x20-\x7E]/g," ").replace(/\\/g,"\\\\").replace(/\(/g,"\\(").replace(/\)/g,"\\)");
}
function buildSimplePDF(lines){
 const pageLines=lines.reduce((out,line)=>{const clean=pdfAscii(line);if(!clean){out.push("");return out;}for(let i=0;i<clean.length;i+=92)out.push(clean.slice(i,i+92));return out;},[]);
 const chunks=[];for(let i=0;i<pageLines.length;i+=48)chunks.push(pageLines.slice(i,i+48));if(!chunks.length)chunks.push(["Aucune donnee a imprimer."]);
 const objs=[];const add=o=>{objs.push(o);return objs.length;};
 const catalogId=add("");const pagesId=add("");const fontId=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");const pageIds=[];
 chunks.forEach((lines,index)=>{
  let stream="BT\n/F1 10 Tf\n45 800 Td\n13 TL\n";
  lines.forEach((line,j)=>{if(j===0&&index===0)stream+="/F1 15 Tf\n("+pdfAscii(line)+") Tj\n/F1 10 Tf\nT*\n";else stream+="("+pdfAscii(line)+") Tj\nT*\n";});
  stream+="ET";
  const streamId=add("<< /Length "+stream.length+" >>\nstream\n"+stream+"\nendstream");
  const pageId=add("<< /Type /Page /Parent "+pagesId+" 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 "+fontId+" 0 R >> >> /Contents "+streamId+" 0 R >>");pageIds.push(pageId);
 });
 objs[catalogId-1]="<< /Type /Catalog /Pages "+pagesId+" 0 R >>";
 objs[pagesId-1]="<< /Type /Pages /Kids ["+pageIds.map(id=>id+" 0 R").join(" ")+"] /Count "+pageIds.length+" >>";
 let pdf="%PDF-1.4\n%PDFGEN\n",offsets=[0];
 objs.forEach((obj,i)=>{offsets.push(pdf.length);pdf+=(i+1)+" 0 obj\n"+obj+"\nendobj\n";});
 const xref=pdf.length;pdf+="xref\n0 "+(objs.length+1)+"\n0000000000 65535 f \n";for(let i=1;i<offsets.length;i++)pdf+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";
 pdf+="trailer\n<< /Size "+(objs.length+1)+" /Root "+catalogId+" 0 R >>\nstartxref\n"+xref+"\n%%EOF";
 return new Blob([new Uint8Array(Array.from(pdf,c=>c.charCodeAt(0)))],{type:"application/pdf"});
}
async function exporterDocumentImpression(){
 const content=document.getElementById("printContent");
 if(!content||!content.innerHTML.trim()){showToast("Aucun bilan prêt. Ouvrez d’abord un bilan à exporter.");return;}
 const button=document.querySelector('.print-toolbar button[onclick="exporterDocumentImpression()"]');
 const fallback=document.getElementById("pdfExportFallback");
 if(fallback)fallback.hidden=true;
 if(button){button.disabled=true;button.textContent="⏳ Préparation du PDF…";}
 try{
  const lines=["CLINIQUE VETERINAIRE - BILAN", "Document : "+(content.querySelector("h2")?.textContent||"Bilan"), "Edite le : "+new Date().toLocaleDateString("fr-FR"), ""];
  content.querySelectorAll("h2").forEach((heading,idx)=>{
   if(idx>0)lines.push("");lines.push("SECTION : "+heading.textContent.trim());
   const table=heading.nextElementSibling;
   if(!table||table.tagName!=="TABLE")return;
   const rows=[...table.querySelectorAll("tr")].map(tr=>[...tr.querySelectorAll("th,td")].map(td=>td.innerText.trim()));
   const headers=rows[0]||[];lines.push("Nombre d'enregistrements : "+Math.max(0,rows.length-1));
   rows.slice(1).forEach((row,i)=>{lines.push("- Enregistrement "+(i+1));row.forEach((value,j)=>{if(value)lines.push("  "+(headers[j]||("Champ "+(j+1)))+" : "+value);});lines.push("");});
   if(rows.length<=1)lines.push("Aucune donnee enregistree.");
  });
  const blob=buildSimplePDF(lines),fileName="bilan-veterinaire-"+new Date().toISOString().slice(0,10)+".pdf";
  const file=new File([blob],fileName,{type:"application/pdf"});
  // Sur Android, la feuille de partage est la meilleure voie pour envoyer le PDF à NokoPrint.
  if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){
   try{await navigator.share({title:"Bilan vétérinaire PDF",text:"Bilan de la clinique vétérinaire",files:[file]});showToast("PDF transmis au menu de partage. Choisissez NokoPrint ou Enregistrer.");return;}
   catch(e){if(e&&e.name==="AbortError"){showToast("Partage annulé. Le lien PDF reste disponible ci-dessous.");}}
  }
  // Dans certains APK, le partage de fichiers n'est pas exposé. Afficher alors des liens
  // explicites plutôt que déclencher un téléchargement invisible que l'utilisateur ne voit pas.
  const url=URL.createObjectURL(blob);
  if(fallback){
   if(fallback.dataset.url)URL.revokeObjectURL(fallback.dataset.url);
   fallback.dataset.url=url;
   fallback.innerHTML='<p><strong>PDF prêt.</strong> Si le menu de partage ne s’est pas ouvert, utilisez un des liens ci-dessous.</p><a class="pdf-action-link" href="'+url+'" target="_blank" rel="noopener">📄 Ouvrir le PDF</a> <a class="pdf-action-link" href="'+url+'" download="'+fileName+'">⬇️ Télécharger le PDF</a><p class="mini">Après ouverture ou téléchargement, utilisez le menu Android « Partager / Ouvrir avec » et choisissez NokoPrint si proposé.</p>';
   fallback.hidden=false;
  }
  showToast("PDF préparé. Utilisez les liens affichés sous les boutons.");
 }catch(err){
  console.error(err);
  showToast("Export PDF impossible. Réessayez ou envoyez le ZIP pour une autre méthode.");
 }finally{
  if(button){button.disabled=false;button.textContent="📄 Enregistrer / Imprimer le PDF";}
 }
}
function fermerApercuImpression(scroll=true){const view=document.getElementById("printView");if(!view)return;view.hidden=true;document.getElementById("appMain").hidden=false;document.body.classList.remove("show-print-view");if(scroll)window.scrollTo(0,0);}
function printReport(){
 const farmerRows=[["Nom","Téléphone","Espèce","Bovins","Ovins","Caprins","Total","Lieu"],...d.e.map(x=>[x.nom,x.tel,x.esp,x.bovins,x.ovins,x.caprins,x.tetes,x.loc])];
 const productRows=[["Produit","Catégorie","Ancien stock","Nouvel arrivage","Total","Prix vente (DA)","Péremption"],...d.p.map(x=>[x.nom,x.cat,x.oldStock,x.newStock,x.stock,x.vente,x.exp])];
 const appointmentRows=[["Date","Heure","Client","Lieu","Motif","Animal","Urgence"],...d.r.map(x=>[x.date,x.heure,x.nom,x.loc,x.motif,x.animal,x.urg])];
 showPrintDocument("Bilan général",farmerRows);const content=document.getElementById("printContent");content.innerHTML+=reportTable("Médicaments / Produits",productRows)+reportTable("Rendez-vous",appointmentRows);
}
function printSection(t){let title,rows;if(t==="g"){title="Reproduction et échographie";rows=[["Éleveur","Espèce","Animal","Saillie/IA","Échographie","Résultat","Contrôle","Mise bas prévue"],...d.g.map(x=>[x.client,x.espece,x.animal,x.saillie,x.echo,x.resultat,x.controle,x.misebas])];}else if(t==="l"){title="Laboratoire et analyses";rows=[["Date","Client","Espèce","Analyse","Prélèvement","Résultat","Compte rendu"],...d.l.map(x=>[x.date,x.client,x.espece,x.typeAnalyse,x.echantillon,x.resultat,x.compteRendu])];}else if(t==="s"){title="Dossiers sanitaires";rows=[["Date","Client","Espèce","Type","Diagnostic","Effectif","Statut","Contrôle"],...d.s.map(x=>[x.date,x.client,x.espece,x.categorie,x.diagnostic,x.effectif,x.statut,x.rappel])];}else if(t==="a"){title="Comptes des éleveurs";rows=[["Date","Éleveur","Type","Motif","Montant DA"],...d.a.map(x=>[x.date,x.client,x.type,x.libelle,x.montant])];}else if(t==="v"){title="Tournées et déplacements";rows=[["Date","Heure","Éleveur","Lieu","Motif","Statut","Km","Frais DA","Honoraires DA"],...d.v.map(x=>[x.date,x.heure,x.client,x.loc,x.motif,x.statut,x.km,x.frais,x.honoraires])];}else if(t==="e"){title="Éleveurs / Élevages";rows=[["Nom","Téléphone","Espèce","Bovins","Ovins","Caprins","Total","Lieu","Prochain RDV"],...d.e.map(x=>[x.nom,x.tel,x.esp,x.bovins,x.ovins,x.caprins,x.tetes,x.loc,`${x.rendezvousDate||""} ${x.rendezvousHeure||""}`])];}else if(t==="p"){title="Médicaments / Produits";rows=[["Produit","Catégorie","Ancien stock","Nouvel arrivage","Total","Achat DA","Vente DA","Lot","Péremption"],...d.p.map(x=>[x.nom,x.cat,x.oldStock,x.newStock,x.stock,x.achat,x.vente,x.lot,x.exp])];}else if(t==="r"){title="Rendez-vous";rows=[["Date","Heure","Client","Téléphone","Lieu","Motif","Animal","Urgence"],...d.r.map(x=>[x.date,x.heure,x.nom,x.tel,x.loc,x.motif,x.animal,x.urg])];}else{title="Bilan financier";rows=[["Date","Type","Libellé","Client","Montant (DA)"],...d.f.map(x=>[x.date,x.type,x.libelle,x.client,x.montant])];}showPrintDocument(title,rows);}

let lastBackAt=0;
function showToast(message){const t=document.getElementById("toast");if(!t)return;t.textContent=message;t.hidden=false;clearTimeout(window.__vetToastTimer);window.__vetToastTimer=setTimeout(()=>t.hidden=true,2200);}
function demanderFermeture(){document.getElementById("closeConfirm").hidden=false;}
function annulerFermeture(){document.getElementById("closeConfirm").hidden=true;}
function confirmerFermeture(){document.getElementById("closeConfirm").hidden=true;try{if(window.navigator.app&&typeof window.navigator.app.exitApp==="function"){window.navigator.app.exitApp();return;}}catch(e){}try{window.close();}catch(e){}showToast("Si l’application reste ouverte, utilisez le bouton Retour du téléphone pour la quitter.");}
function handleBackAction(){if(!document.getElementById("closeConfirm").hidden){annulerFermeture();return;}if(!document.getElementById("printView").hidden){fermerApercuImpression();return;}if(!document.getElementById("modal").hidden){closeForm();return;}if(!document.getElementById("dashboard").hidden){const now=Date.now();if(now-lastBackAt<2000){demanderFermeture();lastBackAt=0;}else{lastBackAt=now;showToast("Appuyez encore une fois sur Retour pour quitter.");}return;}page("dashboard");}
document.addEventListener("keydown",e=>{if(e.key==="Escape"||e.key==="BrowserBack"){e.preventDefault();handleBackAction();}});
document.addEventListener("backbutton",e=>{e.preventDefault?.();handleBackAction();},false);
window.addEventListener("afterprint",()=>{showToast("Impression terminée. Vous pouvez revenir à l’application ou enregistrer en PDF dans la fenêtre d’impression.");});
function backup(){
 const packageData={application:"Clinique Vétérinaire",formatVersion:1,createdAt:new Date().toISOString(),database:d};
 const blob=new Blob([JSON.stringify(packageData,null,2)],{type:"application/json;charset=utf-8"});
 const url=URL.createObjectURL(blob);const a=document.createElement("a");
 a.href=url;a.download="sauvegarde_clinique_"+new Date().toISOString().slice(0,10)+".json";
 document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function restoreBackup(event){
 const input=event.target, file=input.files&&input.files[0];if(!file)return;
 const reader=new FileReader();
 reader.onload=()=>{
  try{
   const parsed=JSON.parse(String(reader.result||"{}"));
   const incoming=parsed.database&&typeof parsed.database==="object"?parsed.database:parsed;
   if(!incoming||typeof incoming!=="object"||Array.isArray(incoming))throw new Error("format");
   const required=["e","p","r","f","g","l","s","a","v"];
   if(!required.some(k=>Array.isArray(incoming[k])))throw new Error("database");
   if(!confirm("Restaurer cette sauvegarde ? Les données actuelles de l'application seront remplacées."))return;
   d=incoming;
   required.forEach(k=>{if(!Array.isArray(d[k]))d[k]=[];});
   if(!d.settings)d.settings={cabinetModel:"complet"};
   d.e.forEach(x=>{if(!x.createdAt)x.createdAt=Date.now();if(x.rendezvousDate===undefined)x.rendezvousDate="";});
   d.p.forEach(x=>{if(x.oldStock===undefined)x.oldStock=x.stock||"0";if(x.newStock===undefined)x.newStock="0";if(!x.cat)x.cat=classify(x.nom+" "+(x.actif||""));if(x.stock===undefined)x.stock=String(Number(x.oldStock||0)+Number(x.newStock||0));});
   save();render();renderDashboard();alert("Sauvegarde restaurée avec succès.");page("dashboard");
  }catch(err){alert("Impossible de restaurer ce fichier. Choisis une sauvegarde JSON valide de l'application.");}
  finally{input.value="";}
 };
 reader.onerror=()=>{alert("Lecture du fichier impossible.");input.value="";};reader.readAsText(file);
}
render();
