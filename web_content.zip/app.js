const KEY='balanceTrackerTransactionsV1';
let transactions=JSON.parse(localStorage.getItem(KEY)||'[]');

const money=n=>new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR'}).format(n);
function save(){localStorage.setItem(KEY,JSON.stringify(transactions));render();}
function render(){
  const income=transactions.filter(t=>t.type==='income').reduce((s,t)=>s+t.amount,0);
  const expense=transactions.filter(t=>t.type==='expense').reduce((s,t)=>s+t.amount,0);
  document.getElementById('income').textContent=money(income);
  document.getElementById('expense').textContent=money(expense);
  document.getElementById('balance').textContent=money(income-expense);
  document.getElementById('count').textContent=transactions.length;
  const box=document.getElementById('transactions');
  if(!transactions.length){box.innerHTML='<p class="empty">No transactions yet.</p>';return;}
  box.innerHTML=transactions.map(t=>`
    <div class="transaction">
      <div><div class="desc">${escapeHtml(t.description)}</div><small>${new Date(t.date).toLocaleString('en-IN')}</small></div>
      <div>
        <b class="${t.type==='income'?'income-t':'expense-t'}">${t.type==='income'?'+':'-'}${money(t.amount)}</b>
        <button class="delete" onclick="removeTransaction('${t.id}')" aria-label="Delete">×</button>
      </div>
    </div>`).join('');
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));}
document.getElementById('transactionForm').addEventListener('submit',e=>{
  e.preventDefault();
  const description=document.getElementById('description').value.trim();
  const amount=Number(document.getElementById('amount').value);
  const type=document.getElementById('type').value;
  if(!description||amount<=0)return;
  transactions.unshift({id:crypto.randomUUID(),description,amount,type,date:new Date().toISOString()});
  e.target.reset(); save();
});
window.removeTransaction=id=>{transactions=transactions.filter(t=>t.id!==id);save();};
document.getElementById('clearAll').addEventListener('click',()=>{
  if(transactions.length && confirm('Delete all transactions?')){transactions=[];save();}
});
render();
