/* =========================================================
   ASSOCIAÇÃO TERRA VERMELHA — LÓGICA DA APLICAÇÃO
   ========================================================= */

/* ---------- CONTAS FIXAS (login sem internet) ---------- */
const CONTAS = {
    presidente: {
        usuario: 'Francisco',
        senha: '0655',
        papel: 'presidente',
        rotulo: 'Presidente'
    },
    financeiroSenior: {
        usuario: 'Rosário David',
        senha: '9426',
        papel: 'financeiroSenior',
        rotulo: 'Financeiro Sénior'
    },
    financeiroJunior: {
        usuario: 'Assistente',
        senha: '0987',
        papel: 'financeiroJunior',
        rotulo: 'Financeiro Júnior'
    }
};

/* Papéis que NÃO podem registar contribuições/receitas */
const PAPEIS_SEM_ACESSO_FINANCEIRO = ['financeiroJunior'];

/* ---------- CHAVES DE ARMAZENAMENTO LOCAL ---------- */
const LS = {
    MEMBROS: 'atv_membros',
    LANCAMENTOS: 'atv_lancamentos',
    SESSAO: 'atv_sessao',
    TEMA: 'atv_tema'
};

/* ---------- ESTADO ---------- */
let membros = [];
let lancamentos = []; // contribuições de membros + outras receitas
let usuarioAtual = null;

/* ---------- FIREBASE (camada de sincronização opcional) ---------- */
let db = null;
let modoNuvem = false;
let unsubMembros = null;
let unsubLancamentos = null;

function iniciarFirebase() {
    try {
        if (
            typeof firebaseConfig !== 'undefined' &&
            firebaseConfig.apiKey &&
            firebaseConfig.apiKey !== 'COLOQUE_AQUI' &&
            typeof firebase !== 'undefined'
        ) {
            firebase.initializeApp(firebaseConfig);
            db = firebase.firestore();
            db.enablePersistence({ synchronizeTabs: true }).catch(() => {
                // Persistência offline não disponível neste navegador/aba — a app continua a funcionar online.
            });
            modoNuvem = true;
        }
    } catch (e) {
        console.warn('Firebase não configurado. A usar apenas armazenamento local neste dispositivo.', e);
        modoNuvem = false;
    }
}

function ligarSincronizacao() {
    if (!modoNuvem) return;

    if (unsubMembros) unsubMembros();
    if (unsubLancamentos) unsubLancamentos();

    unsubMembros = db.collection('membros').orderBy('criadoEm', 'asc')
        .onSnapshot(snap => {
            membros = snap.docs.map(d => ({ id: d.id, ...d.data() }));
            renderTudo();
        }, err => console.warn('Erro a sincronizar integrantes:', err));

    unsubLancamentos = db.collection('lancamentos').orderBy('criadoEm', 'asc')
        .onSnapshot(snap => {
            lancamentos = snap.docs.map(d => ({ id: d.id, ...d.data() }));
            renderTudo();
        }, err => console.warn('Erro a sincronizar lançamentos:', err));
}

/* ---------- PERSISTÊNCIA LOCAL (fallback sem Firebase) ---------- */
function carregarLocal() {
    membros = JSON.parse(localStorage.getItem(LS.MEMBROS) || '[]');
    lancamentos = JSON.parse(localStorage.getItem(LS.LANCAMENTOS) || '[]');
}

function guardarLocal() {
    localStorage.setItem(LS.MEMBROS, JSON.stringify(membros));
    localStorage.setItem(LS.LANCAMENTOS, JSON.stringify(lancamentos));
}

/* ---------- HELPERS ---------- */
function $(id) {
    return document.getElementById(id);
}

function formatarKz(valor) {
    return Number(valor || 0).toLocaleString('pt-PT', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }) + ' Kz';
}

function formatarData(iso) {
    if (!iso) return '';
    const [ano, mes, dia] = iso.split('-');
    return `${dia}/${mes}/${ano}`;
}

function gerarId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

/* ---------- TOASTS (caixas de saída personalizadas) ---------- */
function mostrarToast(titulo, mensagem, tipo = 'sucesso') {
    const container = $('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${tipo}`;
    toast.innerHTML = `
        <span class="toast-icone">${tipo === 'sucesso' ? '✓' : tipo === 'erro' ? '✕' : 'ℹ'}</span>
        <div class="toast-texto">
            <strong>${titulo}</strong>
            <span>${mensagem}</span>
        </div>
    `;
    container.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('mostrar'));

    setTimeout(() => {
        toast.classList.remove('mostrar');
        setTimeout(() => toast.remove(), 300);
    }, 4200);
}

/* =========================================================
   LOGIN / SESSÃO
   ========================================================= */
function tentarLogin(event) {
    event.preventDefault();

    const usuarioDigitado = $('loginUsuario').value.trim();
    const senhaDigitada = $('loginSenha').value.trim();

    const conta = Object.values(CONTAS).find(c =>
        c.usuario.toLowerCase() === usuarioDigitado.toLowerCase() &&
        c.senha === senhaDigitada
    );

    if (!conta) {
        mostrarToast('Acesso negado', 'Nome de usuário ou senha incorretos.', 'erro');
        return;
    }

    usuarioAtual = conta;
    localStorage.setItem(LS.SESSAO, JSON.stringify(conta));

    $('loginForm').reset();
    entrarNaApp();

    mostrarToast(
        `Bem-vindo, ${conta.usuario}!`,
        `Sessão iniciada como ${conta.rotulo}.`,
        'sucesso'
    );
}

function restaurarSessao() {
    const guardada = localStorage.getItem(LS.SESSAO);
    if (guardada) {
        usuarioAtual = JSON.parse(guardada);
        entrarNaApp(true);
        return true;
    }
    return false;
}

function entrarNaApp(silencioso) {
    $('telaLogin').classList.remove('ativa');
    $('appPrincipal').style.display = '';

    $('sessaoNomeTopo').textContent = usuarioAtual.usuario;
    $('sessaoPapelTopo').textContent = usuarioAtual.rotulo;

    aplicarPermissoes();
    renderTudo();
}

function sair() {
    if (!confirm('Terminar a sessão atual?')) return;

    localStorage.removeItem(LS.SESSAO);
    usuarioAtual = null;

    $('appPrincipal').style.display = 'none';
    $('telaLogin').classList.add('ativa');
    mostrarTela('dashboard');
}

/* Aplica as restrições de acesso conforme o papel do usuário */
function aplicarPermissoes() {
    const semAcessoFinanceiro = PAPEIS_SEM_ACESSO_FINANCEIRO.includes(usuarioAtual.papel);

    document.querySelectorAll('.somente-financeiro').forEach(el => {
        el.classList.toggle('oculto', semAcessoFinanceiro);
    });
}

function usuarioPodeMovimentar() {
    if (PAPEIS_SEM_ACESSO_FINANCEIRO.includes(usuarioAtual.papel)) {
        mostrarToast(
            'Acesso restrito',
            'A conta Financeiro Júnior não tem permissão para registar contribuições ou receitas.',
            'erro'
        );
        mostrarTela('dashboard');
        return false;
    }
    return true;
}

/* =========================================================
   NAVEGAÇÃO
   ========================================================= */
function mostrarTela(nome) {
    if ((nome === 'novaContribuicao' || nome === 'novaReceita') && !usuarioPodeMovimentar()) {
        return;
    }

    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    $(nome).classList.add('active');

    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const navBtn = document.querySelector(`.nav-item[data-screen="${nome}"]`);
    if (navBtn) navBtn.classList.add('active');

    if (nome === 'membros') mostrarMembros();
    if (nome === 'historico') mostrarHistorico();
    if (nome === 'novaContribuicao') preencherSelectMembros();

    if (nome === 'novoMembro') {
        $('nomeMembro').focus();
    }
}

/* =========================================================
   INTEGRANTES
   ========================================================= */
function proximoRegistro() {
    const ano = new Date().getFullYear();
    const numero = membros.length + 1;
    return `${ano}-${String(numero).padStart(3, '0')}`;
}

function cadastrarMembro(event) {
    event.preventDefault();

    const nome = $('nomeMembro').value.trim();
    const telefone = $('telefoneMembro').value.trim();
    if (!nome || !telefone) return;

    const registro = proximoRegistro();
    const novoMembro = {
        registro,
        nome,
        telefone,
        criadoEm: new Date().toISOString(),
        cadastradoPor: usuarioAtual.rotulo
    };

    if (modoNuvem) {
        db.collection('membros').add(novoMembro).catch(e => {
            mostrarToast('Erro ao sincronizar', 'O registo foi guardado, mas houve um problema a enviar para a nuvem.', 'erro');
            console.warn(e);
        });
    } else {
        membros.push({ id: gerarId(), ...novoMembro });
        guardarLocal();
        renderTudo();
    }

    $('novoMembro').querySelector('form').reset();
    mostrarToast(
        'Integrante cadastrado!',
        `${nome} foi registado com sucesso — Nº ${registro}.`,
        'sucesso'
    );
    mostrarTela('membros');
}

function excluirMembro(id) {
    if (!confirm('Remover este integrante? Esta ação não pode ser desfeita.')) return;

    if (modoNuvem) {
        db.collection('membros').doc(id).delete();
    } else {
        membros = membros.filter(m => m.id !== id);
        guardarLocal();
        renderTudo();
    }
    mostrarToast('Integrante removido', 'O registo foi eliminado da lista.', 'info');
}

function mostrarMembros() {
    const termo = ($('pesquisaMembros')?.value || '').toLowerCase().trim();
    const lista = $('listaMembros');
    const filtrados = membros
        .filter(m => m.nome.toLowerCase().includes(termo))
        .sort((a, b) => a.nome.localeCompare(b.nome, 'pt'));

    $('totalMembrosLista').textContent = membros.length;

    if (filtrados.length === 0) {
        lista.innerHTML = `
            <div class="empty-state">
                <strong>Nenhum integrante encontrado</strong>
                <span>Ajuste a pesquisa ou cadastre um novo integrante.</span>
            </div>`;
        return;
    }

    lista.innerHTML = filtrados.map(m => `
        <div class="member-item">
            <div class="member-top">
                <div>
                    <span class="member-registro">${m.registro}</span>
                    <div class="member-name">${m.nome}</div>
                </div>
                <button class="delete-btn" onclick="excluirMembro('${m.id}')">Remover</button>
            </div>
            <div class="member-meta">
                <span>${m.telefone}</span>
            </div>
            <div class="member-date">Cadastrado em ${new Date(m.criadoEm).toLocaleDateString('pt-PT')}</div>
        </div>
    `).join('');
}

function preencherSelectMembros() {
    const select = $('membroContribuicao');
    const atual = select.value;

    const ordenados = [...membros].sort((a, b) => a.nome.localeCompare(b.nome, 'pt'));
    select.innerHTML = '<option value="">Selecione um integrante</option>' +
        ordenados.map(m => `<option value="${m.id}">${m.nome} — ${m.registro}</option>`).join('');

    select.value = atual;
}

/* =========================================================
   CONTRIBUIÇÕES DE MEMBROS
   ========================================================= */
function cadastrarContribuicao(event) {
    event.preventDefault();
    if (!usuarioPodeMovimentar()) return;

    const membroId = $('membroContribuicao').value;
    const valor = parseFloat($('valorContribuicao').value);
    const data = $('dataContribuicao').value;
    const membro = membros.find(m => m.id === membroId);

    if (!membro || !valor || !data) return;

    const registo = {
        tipo: 'membro',
        membroId,
        membroNome: membro.nome,
        fonte: null,
        valor,
        data,
        criadoEm: new Date().toISOString(),
        registadoPor: usuarioAtual.rotulo
    };

    salvarLancamento(registo);

    $('novaContribuicao').querySelector('form').reset();
    mostrarToast(
        'Contribuição registada!',
        `${formatarKz(valor)} recebidos de ${membro.nome}.`,
        'sucesso'
    );
    mostrarTela('dashboard');
}

/* =========================================================
   OUTRAS RECEITAS (fontes além das contribuições de membros)
   ========================================================= */
function cadastrarReceita(event) {
    event.preventDefault();
    if (!usuarioPodeMovimentar()) return;

    const fonte = $('fonteReceita').value.trim();
    const valor = parseFloat($('valorReceita').value);
    const data = $('dataReceita').value;

    if (!fonte || !valor || !data) return;

    const registo = {
        tipo: 'outra',
        membroId: null,
        membroNome: null,
        fonte,
        valor,
        data,
        criadoEm: new Date().toISOString(),
        registadoPor: usuarioAtual.rotulo
    };

    salvarLancamento(registo);

    $('novaReceita').querySelector('form').reset();
    mostrarToast(
        'Receita registada!',
        `${formatarKz(valor)} — Fonte: ${fonte}.`,
        'sucesso'
    );
    mostrarTela('dashboard');
}

function salvarLancamento(registo) {
    if (modoNuvem) {
        db.collection('lancamentos').add(registo).catch(e => {
            mostrarToast('Erro ao sincronizar', 'O registo foi guardado, mas houve um problema a enviar para a nuvem.', 'erro');
            console.warn(e);
        });
    } else {
        lancamentos.push({ id: gerarId(), ...registo });
        guardarLocal();
        renderTudo();
    }
}

function excluirLancamento(id) {
    if (!confirm('Remover este lançamento? Esta ação não pode ser desfeita.')) return;

    if (modoNuvem) {
        db.collection('lancamentos').doc(id).delete();
    } else {
        lancamentos = lancamentos.filter(l => l.id !== id);
        guardarLocal();
        renderTudo();
    }
    mostrarToast('Lançamento removido', 'O registo foi eliminado do histórico.', 'info');
}

/* =========================================================
   DASHBOARD & HISTÓRICO
   ========================================================= */
function rotuloLancamento(l) {
    return l.tipo === 'membro'
        ? `Mensalidade — ${l.membroNome}`
        : `Outra receita — ${l.fonte}`;
}

function itemLancamentoHTML(l) {
    return `
        <div class="contribution-item">
            <div class="member-top">
                <div>
                    <span class="member-registro">${l.tipo === 'membro' ? 'MEMBRO' : 'RECEITA'}</span>
                    <div class="member-name">${rotuloLancamento(l)}</div>
                </div>
                <button class="delete-btn" onclick="excluirLancamento('${l.id}')">Remover</button>
            </div>
            <div class="member-meta">
                <span>${formatarKz(l.valor)}</span>
                <span>${formatarData(l.data)}</span>
                <span>Registado por ${l.registadoPor || '—'}</span>
            </div>
        </div>`;
}

function mostrarHistorico() {
    const lista = $('listaHistorico');
    const ordenados = [...lancamentos].sort((a, b) => (b.data || '').localeCompare(a.data || ''));

    if (ordenados.length === 0) {
        lista.innerHTML = `
            <div class="empty-state">
                <strong>Nenhum lançamento</strong>
                <span>As contribuições e receitas aparecerão aqui.</span>
            </div>`;
        return;
    }

    lista.innerHTML = ordenados.map(itemLancamentoHTML).join('');
}

function renderDashboard() {
    const total = lancamentos.reduce((soma, l) => soma + Number(l.valor || 0), 0);

    $('totalArrecadado').textContent = formatarKz(total);
    $('totalMembros').textContent = membros.length;
    $('totalContribuicoes').textContent = lancamentos.length;

    const recentes = [...lancamentos]
        .sort((a, b) => (b.criadoEm || '').localeCompare(a.criadoEm || ''))
        .slice(0, 5);

    const container = $('contribuicoesRecentes');
    if (recentes.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <strong>Nenhuma contribuição</strong>
                <span>Os novos registos aparecerão aqui.</span>
            </div>`;
        return;
    }

    container.innerHTML = recentes.map(itemLancamentoHTML).join('');
}

function renderTudo() {
    if (!usuarioAtual) return;
    renderDashboard();
    mostrarMembros();
    mostrarHistorico();
}

/* =========================================================
   TEMA
   ========================================================= */
function alternarTema() {
    document.body.classList.toggle('dark');
    localStorage.setItem(LS.TEMA, document.body.classList.contains('dark') ? 'dark' : 'light');
}

function restaurarTema() {
    if (localStorage.getItem(LS.TEMA) === 'dark') {
        document.body.classList.add('dark');
    }
}

/* =========================================================
   PDF
   ========================================================= */
function gerarPDF() {
    if (typeof window.jspdf === 'undefined') {
        mostrarToast('Erro ao gerar PDF', 'Verifique a ligação à internet e tente novamente.', 'erro');
        return;
    }

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const ordenados = [...membros].sort((a, b) => a.nome.localeCompare(b.nome, 'pt'));

    doc.setFontSize(16);
    doc.text('Associação Terra Vermelha', 14, 18);

    doc.setFontSize(11);
    doc.text('Lista de Integrantes', 14, 26);

    doc.setFontSize(9);
    doc.setTextColor(120);
    doc.text(`Gerado em ${new Date().toLocaleDateString('pt-PT')}`, 14, 32);
    doc.setTextColor(0);

    let y = 44;
    doc.setFontSize(10);
    doc.setFont(undefined, 'bold');
    doc.text('Nº Registro', 14, y);
    doc.text('Nome', 55, y);
    doc.text('Telemóvel', 145, y);
    doc.setFont(undefined, 'normal');

    y += 4;
    doc.setLineWidth(0.2);
    doc.line(14, y, 196, y);
    y += 8;

    if (ordenados.length === 0) {
        doc.text('Nenhum integrante cadastrado.', 14, y);
        y += 8;
    } else {
        ordenados.forEach(m => {
            if (y > 280) {
                doc.addPage();
                y = 20;
            }
            doc.text(String(m.registro || ''), 14, y);
            doc.text(String(m.nome || ''), 55, y);
            doc.text(String(m.telefone || ''), 145, y);
            y += 8;
        });
    }

    y += 6;
    doc.setFont(undefined, 'bold');
    doc.text(`Total de integrantes: ${membros.length}`, 14, y);

    doc.save(`integrantes-terra-vermelha-${new Date().toISOString().slice(0, 10)}.pdf`);
    mostrarToast('PDF gerado!', 'O download deve começar automaticamente.', 'sucesso');
}

/* =========================================================
   INICIALIZAÇÃO
   ========================================================= */
document.addEventListener('DOMContentLoaded', () => {
    restaurarTema();
    iniciarFirebase();

    if (modoNuvem) {
        ligarSincronizacao();
    } else {
        carregarLocal();
    }

    $('loginForm').addEventListener('submit', tentarLogin);

    const jaTinhaSessao = restaurarSessao();
    if (!jaTinhaSessao) {
        mostrarTela('dashboard');
    }
});
