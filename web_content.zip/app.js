const state={
 balance:Number(localStorage.getItem("balance")||"500"),
 name:localStorage.getItem("name")||"Player",
 joined:JSON.parse(localStorage.getItem("joined")||"[]")
};
const tournaments=[
 {id:1,name:"Mega Ludo Cup",entry:20,prize:1000,players:"4 Players",time:"আজ ৯:৩০ PM"},
 {id:2,name:"Daily Battle",entry:10,prize:400,players:"4 Players",time:"আজ ১০:০০ PM"},
 {id:3,name:"Weekend Champion",entry:50,prize:2500,players:"8 Players",time:"শুক্রবার ৮:০০ PM"}
];

function money(){return "৳"+state.balance.toFixed(2)}
function save(){localStorage.setItem("balance",state.balance);localStorage.setItem("name",state.name);localStorage.setItem("joined",JSON.stringify(state.joined))}
function showPage(page){
 document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
 const c=document.getElementById("content");
 if(page==="home"){
    if(!localStorage.getItem("name") || localStorage.getItem("name") === "Player") {
        showLoginPage();
    } else {
        c.innerHTML=home();
    }
}

 if(page==="tournaments") c.innerHTML=tournamentPage();
 if(page==="wallet") c.innerHTML=walletPage();
 if(page==="profile") c.innerHTML=profilePage();
 if(page==="notifications") c.innerHTML=notificationsPage();
 document.getElementById("userName").textContent=state.name;
}
function home(){
 return `<div class="balance"><small>বর্তমান ব্যালেন্স</small><div class="amount">${money()}</div><div class="actions"><button class="btn light" onclick="openDeposit()">➕ Add Money</button><button class="btn light" onclick="openWithdraw()">📤 Withdraw</button></div></div>
 <div class="section-title"><h3>দ্রুত অপশন</h3></div>
 <div class="grid">
 <div class="card" onclick="showPage('tournaments')"><div class="feature">🏆</div><b>টুর্নামেন্ট</b><div class="muted">খেলা খুঁজুন ও Join করুন</div></div>
 <div class="card" onclick="myTournaments()"><div class="feature">🎮</div><b>My Tournaments</b><div class="muted">আপনার ম্যাচগুলো</div></div>
 <div class="card" onclick="openDeposit()"><div class="feature">💳</div><b>Deposit</b><div class="muted">bKash / Nagad / Bank</div></div>
 <div class="card" onclick="transactionHistory()"><div class="feature">🔄</div><b>History</b><div class="muted">লেনদেন দেখুন</div></div>
 </div>
 <div class="section-title"><h3>চলমান টুর্নামেন্ট</h3><button class="btn light" onclick="showPage('tournaments')">সব দেখুন</button></div>
 ${tournaments.slice(0,2).map(tcard).join("")}`;
}
function tcard(t){
 const joined=state.joined.includes(t.id);
 return `<div class="t-card"><div class="t-head"><b>${t.name}</b><span class="badge">${t.time}</span></div>
 <div class="row"><span>Entry Fee</span><b>৳${t.entry}</b></div><div class="row"><span>Prize Pool</span><b>৳${t.prize}</b></div><div class="row"><span>Players</span><span>${t.players}</span></div>
 <button class="btn ${joined?'green':'primary'} full" onclick="${joined?'myTournaments()':'joinTournament('+t.id+')'}">${joined?'✓ Joined':'Join Tournament'}</button></div>`;
}
function tournamentPage(){return `<div class="section-title"><h2>🏆 Tournament List</h2></div><div class="notice">ডেমো মোড: Join করলে Entry Fee আপনার লোকাল ব্যালেন্স থেকে কাটা হবে।</div>${tournaments.map(tcard).join("")}`}
function joinTournament(id){
 const t=tournaments.find(x=>x.id===id); if(state.joined.includes(id)) return;
 if(state.balance<t.entry){openModal(`<h3>পর্যাপ্ত ব্যালেন্স নেই</h3><p>Join করতে ৳${t.entry} দরকার। আপনার ব্যালেন্স ${money()}।</p><button class="btn primary full" onclick="closeModal();openDeposit()">Add Money</button>`);return}
 openModal(`<h3>${t.name}</h3><p>Entry Fee: <b>৳${t.entry}</b></p><p>আপনি কি Join করতে চান?</p><button class="btn primary full" onclick="confirmJoin(${id})">Confirm Join</button>`);
}
function confirmJoin(id){const t=tournaments.find(x=>x.id===id);state.balance-=t.entry;state.joined.push(id);save();closeModal();showPage("tournaments")}
function walletPage(){return `<div class="balance"><small>Wallet Balance</small><div class="amount">${money()}</div><div class="actions"><button class="btn light" onclick="openDeposit()">➕ Deposit</button><button class="btn light" onclick="openWithdraw()">📤 Withdraw</button></div></div><div class="grid"><div class="card" onclick="transactionHistory()">🔄<br><b>Transaction History</b></div><div class="card" onclick="openDeposit()">💳<br><b>Payment Methods</b></div></div>`}
function openDeposit(){openModal(`<h3>💳 Add Money</h3><select class="select" id="method"><option>bKash</option><option>Nagad</option><option>Bank</option></select><input class="input" id="depAmount" type="number" placeholder="Amount (৳)"><input class="input" id="trx" placeholder="Transaction ID"><button class="btn primary full" onclick="deposit()">Submit Deposit</button><div class="notice">এটি ডেমো UI। বাস্তব পেমেন্ট গেটওয়ে এখনো সংযুক্ত নয়।</div>`)}
function deposit(){const a=Number(document.getElementById("depAmount").value);if(!a||a<=0)return alert("সঠিক Amount দিন");state.balance+=a;save();closeModal();showPage("wallet")}
function openWithdraw(){openModal(`<h3>📤 Withdraw</h3><select class="select" id="wmethod"><option>bKash</option><option>Nagad</option><option>Bank</option></select><input class="input" id="wamount" type="number" placeholder="Amount (৳)"><input class="input" id="account" placeholder="Account / Bank Number"><input class="input" id="pin" type="password" placeholder="Transaction PIN"><button class="btn primary full" onclick="withdraw()">Confirm Withdraw</button>`)}
function withdraw(){const a=Number(document.getElementById("wamount").value);if(!a||a<=0)return alert("সঠিক Amount দিন");if(a>state.balance)return alert("ব্যালেন্স কম");state.balance-=a;save();closeModal();showPage("wallet")}
function myTournaments(){openModal(`<h3>🏆 My Tournaments</h3>${state.joined.length?state.joined.map(id=>{let t=tournaments.find(x=>x.id===id);return `<div class="list-item"><div><b>${t.name}</b><div class="muted">${t.time}</div></div><span class="badge">Joined</span></div>`}).join(""):`<div class="empty">এখনও কোনো Tournament Join করেননি।</div>`}`)}
function transactionHistory(){openModal(`<h3>🔄 Transaction History</h3><div class="empty">এই ডেমো ভার্সনে বিস্তারিত সার্ভার-ভিত্তিক History নেই।</div>`)}
function profilePage(){return `<div class="card profile-head"><div class="big-avatar">👤</div><h2>${state.name}</h2><div class="muted">Ludo Tournament Player</div></div><div class="section-title"><h3>Account</h3></div><div class="list-item" onclick="editName()">✏️ <span>নাম পরিবর্তন</span><span>›</span></div><div class="list-item" onclick="showSettings()">⚙️ <span>Settings</span><span>›</span></div><div class="list-item" onclick="showBonus()">🎁 <span>Bonus / Referral</span><span>›</span></div>`}
function editName(){openModal(`<h3>নাম পরিবর্তন</h3><input class="input" id="newName" value="${state.name}"><button class="btn primary full" onclick="state.name=document.getElementById('newName').value||'Player';save();closeModal();showPage('profile')">Save</button>`)}
function showSettings(){openModal(`<h3>⚙️ Settings</h3><div class="list-item">🔔 Notifications <span>ON</span></div><div class="list-item">🔐 PIN Security <span>ON</span></div>`)}
function showBonus(){openModal(`<h3>🎁 Bonus / Referral</h3><p>আপনার Referral Code</p><div class="card"><b>LU-${state.name.toUpperCase().slice(0,6)}</b></div><p class="muted">বন্ধুকে রেফার করে বোনাস পাওয়ার UI এখানে থাকবে।</p>`)}
function notificationsPage(){return `<div class="section-title"><h2>🔔 Notifications</h2></div><div class="list-item"><div><b>Welcome!</b><div class="muted">Ludo Tournament-এ স্বাগতম।</div></div></div><div class="list-item"><div><b>Tournament Update</b><div class="muted">নতুন Tournament যোগ হয়েছে।</div></div></div>`}
function openModal(html){document.getElementById("modalContent").innerHTML=html;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.getElementById("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
showPage("home");
// ১. রেজিস্ট্রেশন পেজ / মোডাল দেখানোর ফাংশন
function showRegisterPage() {
    let registerHTML = `
        <div style="padding: 20px; text-align: center; font-family: sans-serif;">
            <h3>নতুন অ্যাকাউন্ট তৈরি করুন</h3>
            <input type="text" id="regName" placeholder="আপনার নাম" style="width: 80%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 5px;"><br>
            <input type="number" id="regPhone" placeholder="মোবাইল নম্বর" style="width: 80%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 5px;"><br>
            <input type="password" id="regPassword" placeholder="পাসওয়ার্ড" style="width: 80%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 5px;"><br>
            <button onclick="handleRegister()" style="width: 85%; padding: 10px; background-color: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin-top: 10px;">রেজিস্ট্রেশন করুন</button>
            <p style="margin-top: 15px; font-size: 14px;">অ্যাকাউন্ট আছে? <a href="#" onclick="showLoginPage()">লগইন করুন</a></p>
        </div>
    `;
    openModal(registerHTML);
}

// ২. লগইন পেজ / মোডাল দেখানোর ফাংশন
function showLoginPage() {
    let loginHTML = `
        <div style="padding: 20px; text-align: center; font-family: sans-serif;">
            <h3>লুডু টুর্নামেন্টে লগইন করুন</h3>
            <input type="number" id="loginPhone" placeholder="মোবাইল নম্বর" style="width: 80%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 5px;"><br>
            <input type="password" id="loginPassword" placeholder="পাসওয়ার্ড" style="width: 80%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 5px;"><br>
            <button onclick="handleLogin()" style="width: 85%; padding: 10px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; margin-top: 10px;">লগইন করুন</button>
            <p style="margin-top: 15px; font-size: 14px;">নতুন প্লেয়ার? <a href="#" onclick="showRegisterPage()">অ্যাকাউন্ট খুলুন</a></p>
        </div>
    `;
    openModal(loginHTML);
}

// ৩. রেজিস্ট্রেশন বাটনের কাজ (Firebase-এ ডেটা পাঠানো)
function handleRegister() {
    const name = document.getElementById("regName").value;
    const phone = document.getElementById("regPhone").value;
    const password = document.getElementById("regPassword").value;

    if(!name || !phone || !password) {
        alert("সবগুলো ঘর সঠিকভাবে পূরণ করুন!");
        return;
    }

    // ফায়ারবেস রিয়েলটাইম ডাটাবেজে ইউজার সেভ করা
    database.ref('players/' + phone).set({
        name: name,
        phone: phone,
        password: password,
        coins: 0,
        joinedAt: new Date().toLocaleString()
    }).then(() => {
        alert("অ্যাকাউন্ট তৈরি সফল হয়েছে! এখন লগইন করুন।");
        showLoginPage(); // লগইন পেজে নিয়ে যাবে
    }).catch((error) => {
        alert("ভুল হয়েছে: " + error.message);
    });
}

// ৪. লগইন বাটনের কাজ (Firebase থেকে ডেটা চেক করা)
function handleLogin() {
    const phone = document.getElementById("loginPhone").value;
    const password = document.getElementById("loginPassword").value;

    if(!phone || !password) {
        alert("ফোন নম্বর এবং পাসওয়ার্ড দিন!");
        return;
    }

    database.ref('players/' + phone).once('value').then((snapshot) => {
        if (snapshot.exists()) {
            const userData = snapshot.val();
            
            if (userData.password === password) {
                alert("স্বাগতম, " + userData.name + "! লগইন সফল হয়েছে।");
                
                // অ্যাপের লোকাল মেমোরিতে ডেটা রাখা
                localStorage.setItem("name", userData.name);
                localStorage.setItem("balance", userData.coins);
                
                closeModal(); // মোডাল বন্ধ করা
                showPage("home"); // অ্যাপের হোম পেজে নিয়ে যাওয়া
            } else {
                alert("ভুল পাসওয়ার্ড! আবার চেষ্টা করুন।");
            }
        } else {
            alert("এই নম্বরে কোনো অ্যাকাউন্ট নেই! দয়া করে রেজিস্ট্রেশন করুন।");
        }
    });
}