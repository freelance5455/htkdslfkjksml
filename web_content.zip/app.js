/* ============================================================
   FONTE — suivi détaillé de "The Bodybuilding Transformation System"
   Toutes les données restent en localStorage, sur cet appareil.
   ============================================================ */

const STORE_KEY = 'fonte_tracker_v1';
const TOTAL_SESSIONS = PROGRAM.length; // 60

const FEEL_OPTIONS = [
  {v:1, e:'😞', label:'Difficile'},
  {v:2, e:'😐', label:'Moyen'},
  {v:3, e:'🙂', label:'Bien'},
  {v:4, e:'💪', label:'Excellent'},
];

const RIR_OPTIONS = ['0 (échec)','1','2','3','4','5+'];

// ---------- state ----------
let state = loadState();
let activeIndex = state.cursor; // session index currently shown in "Aujourd'hui"
let currentView = 'today';

function defaultState(){
  return {
    profile: null, // {name, unit, wrist, startDate}
    cursor: 0,
    logs: [],
    drafts: {} // sessionIndex -> form draft
  };
}

function loadState(){
  try{
    const raw = localStorage.getItem(STORE_KEY);
    if(!raw) return defaultState();
    const parsed = JSON.parse(raw);
    return Object.assign(defaultState(), parsed);
  }catch(e){
    console.error('Lecture des données impossible', e);
    return defaultState();
  }
}

function saveState(){
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
}

function todayISO(){
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0,10);
}

function fmtDate(iso){
  if(!iso) return '';
  const [y,m,d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

function parseDefaultSets(str){
  if(!str) return 1;
  const m = String(str).match(/\d+/);
  return m ? parseInt(m[0],10) : 1;
}

function dayShort(dayLabel){
  return dayLabel.split(' ')[0];
}

function weekNum(weekLabel){
  const m = weekLabel.match(/\d+/);
  return m ? parseInt(m[0],10) : 0;
}

function toast(msg){
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.remove('hidden');
  clearTimeout(toast._t);
  toast._t = setTimeout(()=> el.classList.add('hidden'), 2200);
}

// ============================================================
// BOOT
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  if(state.profile){
    showMainShell();
  }else{
    document.getElementById('view-onboarding').classList.remove('hidden');
  }
  wireOnboarding();
  wireTabs();
  wireSettings();
  registerSW();
});

function wireOnboarding(){
  const unitSeg = document.getElementById('ob-unit');
  unitSeg.querySelectorAll('.seg-btn').forEach(b=>{
    b.addEventListener('click', ()=>{
      unitSeg.querySelectorAll('.seg-btn').forEach(x=>x.classList.remove('active'));
      b.classList.add('active');
    });
  });
  document.getElementById('ob-startdate').value = todayISO();

  document.getElementById('ob-submit').addEventListener('click', ()=>{
    const name = document.getElementById('ob-name').value.trim() || 'Athlète';
    const unit = unitSeg.querySelector('.seg-btn.active').dataset.val;
    const wrist = document.getElementById('ob-wrist').value;
    const startDate = document.getElementById('ob-startdate').value || todayISO();
    state.profile = { name, unit, wrist: wrist || null, startDate };
    saveState();
    document.getElementById('view-onboarding').classList.add('hidden');
    showMainShell();
  });
}

function showMainShell(){
  document.getElementById('main-shell').classList.remove('hidden');
  document.getElementById('hdr-name').textContent = state.profile.name;
  activeIndex = state.cursor;
  renderToday();
  renderProgramTab();
  renderHistory();
  renderProgress();
  renderSettingsForm();
}

function wireTabs(){
  document.querySelectorAll('.tab-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('#views .view').forEach(v=>v.classList.add('hidden'));
      currentView = btn.dataset.view;
      document.getElementById('view-'+currentView).classList.remove('hidden');
      if(currentView==='history') renderHistory();
      if(currentView==='progress') renderProgress();
    });
  });
  document.getElementById('hdr-settings').addEventListener('click', ()=>{
    document.querySelectorAll('.tab-btn').forEach(b=>b.classList.remove('active'));
    document.querySelectorAll('#views .view').forEach(v=>v.classList.add('hidden'));
    document.getElementById('view-settings').classList.remove('hidden');
    currentView='settings';
  });
}

// ============================================================
// TODAY VIEW
// ============================================================
function getDraft(idx){
  if(!state.drafts[idx]) state.drafts[idx] = buildEmptyDraft(idx);
  return state.drafts[idx];
}

function buildEmptyDraft(idx){
  const sess = PROGRAM[idx];
  return {
    date: todayISO(),
    bodyweight: '',
    feel: null,
    note: '',
    duration: '',
    exercises: sess.exercises.map(ex => ({
      variant: ex.name,
      note: '',
      sets: Array.from({length: parseDefaultSets(ex.working_sets)}, ()=>({reps:'', weight:'', rir:''}))
    }))
  };
}

function renderToday(){
  if(activeIndex >= TOTAL_SESSIONS){
    document.getElementById('cursor-card').innerHTML = `
      <div class="cursor-day">Programme terminé 🎉</div>
      <div class="cursor-meta">Tu as bouclé les ${TOTAL_SESSIONS} séances des 12 semaines. Regarde ta progression, ou relance un nouveau cycle depuis l'onglet Programme.</div>
    `;
    document.getElementById('today-session-block').innerHTML = '';
    return;
  }
  const sess = PROGRAM[activeIndex];
  const cursorCard = document.getElementById('cursor-card');
  const pct = Math.round((state.cursor/TOTAL_SESSIONS)*100);
  const isJumped = activeIndex !== state.cursor;

  cursorCard.innerHTML = `
    <div class="cursor-top">
      <span class="cursor-block">${sess.block === 'Foundation Block' ? 'Bloc Fondation' : 'Bloc Montée en charge'}</span>
      <span class="cursor-week">${sess.week.replace('WEEK','SEMAINE')}</span>
    </div>
    <div class="cursor-day">${translateDay(sess.day)}</div>
    <div class="cursor-meta">${sess.exercises.length} exercices · séance ${activeIndex+1} / ${TOTAL_SESSIONS}${isJumped ? ' · consultation libre' : ''}</div>
    <div class="cursor-actions">
      ${isJumped ? `<button class="btn-secondary" id="btn-back-cursor">Revenir à ma séance</button>` : `<button class="btn-secondary" id="btn-skip">Passer</button>`}
    </div>
    <div class="cursor-progress"><div class="cursor-progress-fill" style="width:${pct}%"></div></div>
    <div class="cursor-progress-label">${pct}% du programme complété (${state.cursor}/${TOTAL_SESSIONS} séances)</div>
  `;

  if(isJumped){
    document.getElementById('btn-back-cursor').addEventListener('click', ()=>{
      activeIndex = state.cursor;
      renderToday();
    });
  } else {
    document.getElementById('btn-skip')?.addEventListener('click', ()=>{
      if(confirm('Passer cette séance sans l\'enregistrer ? Elle sera marquée comme sautée.')){
        delete state.drafts[activeIndex];
        state.cursor = Math.min(TOTAL_SESSIONS, state.cursor+1);
        activeIndex = state.cursor;
        saveState();
        renderToday();
        renderProgress();
      }
    });
  }

  document.getElementById('today-session-block').innerHTML = '';
  document.getElementById('today-session-block').appendChild(renderSessionForm(activeIndex, true));
}

function translateDay(day){
  return day
    .replace('Upper','Haut du corps')
    .replace('Lower','Bas du corps')
    .replace('Pull','Tirage')
    .replace('Push','Poussée')
    .replace('Legs','Jambes')
    .replace('Strength Focus','Focus force')
    .replace('Hypertrophy Focus','Focus hypertrophie');
}

// Builds the full interactive logging form for a given session index.
// isTodayContext=true wires the "finish session" bottom controls.
function renderSessionForm(idx, isTodayContext){
  const sess = PROGRAM[idx];
  const draft = getDraft(idx);
  const wrap = document.createElement('div');

  const head = document.createElement('div');
  head.className = 'session-head';
  head.innerHTML = `<h3>${translateDay(sess.day)}</h3><span class="badge">${sess.week.replace('WEEK','S.')}</span>`;
  wrap.appendChild(head);

  sess.exercises.forEach((ex, exIdx) => {
    wrap.appendChild(renderExerciseCard(idx, exIdx, ex, draft.exercises[exIdx]));
  });

  // session-level wrap fields
  const wrapFields = document.createElement('div');
  wrapFields.className = 'session-wrap-fields';
  wrapFields.innerHTML = `
    <div class="wrap-grid">
      <label class="field" style="margin-bottom:0;">
        <span>Date</span>
        <input type="date" data-field="date" value="${draft.date}">
      </label>
      <label class="field" style="margin-bottom:0;">
        <span>Poids de corps (${state.profile.unit})</span>
        <input type="number" step="0.1" inputmode="decimal" data-field="bodyweight" value="${draft.bodyweight}" placeholder="optionnel">
      </label>
    </div>
    <label class="field">
      <span>Comment tu te sens ?</span>
      <div class="feel-row">
        ${FEEL_OPTIONS.map(f=>`<button type="button" class="feel-btn ${draft.feel===f.v?'active':''}" data-feel="${f.v}">${f.e}</button>`).join('')}
      </div>
    </label>
    <label class="field">
      <span>Notes sur la séance</span>
      <textarea data-field="note" placeholder="Sommeil, énergie, douleurs, contexte...">${draft.note}</textarea>
    </label>
    <label class="field" style="margin-bottom:0;">
      <span>Durée (minutes, optionnel)</span>
      <input type="number" inputmode="numeric" data-field="duration" value="${draft.duration}" placeholder="ex : 65">
    </label>
    ${isTodayContext ? `<button class="btn-primary btn-block" id="finish-session-btn" style="margin-top:18px;">Terminer la séance</button>` : ''}
  `;
  wrap.appendChild(wrapFields);

  wrapFields.querySelectorAll('[data-field]').forEach(inp=>{
    inp.addEventListener('input', ()=>{
      draft[inp.dataset.field] = inp.value;
      saveState();
    });
  });
  wrapFields.querySelectorAll('.feel-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      draft.feel = parseInt(btn.dataset.feel,10);
      wrapFields.querySelectorAll('.feel-btn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      saveState();
    });
  });

  if(isTodayContext){
    wrapFields.querySelector('#finish-session-btn').addEventListener('click', ()=> finishSession(idx));
  }

  return wrap;
}

function renderExerciseCard(sessIdx, exIdx, ex, exDraft){
  const card = document.createElement('div');
  card.className = 'ex-card';

  const hasData = exDraft.sets.some(s=>s.reps && s.weight);
  if(hasData) card.classList.add('ex-done');

  const top = document.createElement('div');
  top.className = 'ex-top';
  top.innerHTML = `
    <div class="ex-name-row">
      <div class="ex-name"><span class="ex-index">${exIdx+1}.</span>${ex.name}</div>
      <div class="ex-check">${hasData ? '✓' : ''}</div>
    </div>
    <div class="ex-prescription">
      <span><b>${ex.working_sets}</b> séries × <b>${ex.reps}</b> reps</span>
      <span>RPE dernière série <b>${ex.last_rpe}</b></span>
      <span>Repos <b>${ex.rest}</b></span>
      ${ex.warmup_sets && ex.warmup_sets !== '0' ? `<span>${ex.warmup_sets} série(s) d'échauffement</span>` : ''}
    </div>
    ${ex.technique && ex.technique !== 'N/A' ? `<div class="ex-technique-tag">${ex.technique}</div>` : ''}
    <div class="ex-notes-toggle" data-toggle>Voir la consigne + alternatives</div>
    <div class="ex-notes-body hidden" data-body>
      <div>${ex.notes}</div>
      <div class="sub-line">Alternative 1 : ${ex.sub1 || '—'}</div>
      <div class="sub-line">Alternative 2 : ${ex.sub2 || '—'}</div>
    </div>
    <div class="variant-row">
      <select data-variant>
        <option value="${escapeAttr(ex.name)}" ${exDraft.variant===ex.name?'selected':''}>${ex.name} (exercice principal)</option>
        ${ex.sub1 ? `<option value="${escapeAttr(ex.sub1)}" ${exDraft.variant===ex.sub1?'selected':''}>${ex.sub1} (alternative 1)</option>` : ''}
        ${ex.sub2 ? `<option value="${escapeAttr(ex.sub2)}" ${exDraft.variant===ex.sub2?'selected':''}>${ex.sub2} (alternative 2)</option>` : ''}
      </select>
    </div>
  `;
  card.appendChild(top);

  top.querySelector('[data-toggle]').addEventListener('click', (e)=>{
    top.querySelector('[data-body]').classList.toggle('hidden');
  });
  top.querySelector('[data-variant]').addEventListener('change', (e)=>{
    exDraft.variant = e.target.value;
    saveState();
  });

  const setsWrap = document.createElement('div');
  setsWrap.className = 'sets-table';
  setsWrap.innerHTML = `<div class="set-row head"><span></span><span>Poids (${state.profile.unit})</span><span>Reps</span><span>RIR</span><span></span></div>`;

  function addSetRow(setIdx){
    const s = exDraft.sets[setIdx];
    const row = document.createElement('div');
    row.className = 'set-row';
    row.innerHTML = `
      <span class="set-num">#${setIdx+1}</span>
      <input type="number" step="0.5" inputmode="decimal" data-k="weight" value="${s.weight}">
      <input type="number" inputmode="numeric" data-k="reps" value="${s.reps}">
      <select data-k="rir">
        <option value="">–</option>
        ${RIR_OPTIONS.map(o=>`<option value="${o}" ${s.rir===o?'selected':''}>${o}</option>`).join('')}
      </select>
      <button class="set-remove" title="Retirer la série">✕</button>
    `;
    row.querySelector('[data-k="weight"]').addEventListener('input', e=>{ s.weight = e.target.value; refreshDoneState(); saveState(); });
    row.querySelector('[data-k="reps"]').addEventListener('input', e=>{ s.reps = e.target.value; refreshDoneState(); saveState(); });
    row.querySelector('[data-k="rir"]').addEventListener('change', e=>{ s.rir = e.target.value; saveState(); });
    row.querySelector('.set-remove').addEventListener('click', ()=>{
      exDraft.sets.splice(setIdx,1);
      saveState();
      rerenderSetsTable();
    });
    return row;
  }

  function rerenderSetsTable(){
    setsWrap.innerHTML = `<div class="set-row head"><span></span><span>Poids (${state.profile.unit})</span><span>Reps</span><span>RIR</span><span></span></div>`;
    exDraft.sets.forEach((s,i)=> setsWrap.appendChild(addSetRow(i)));
    const addRow = document.createElement('div');
    addRow.className = 'set-add-row';
    addRow.innerHTML = `<button class="set-add-btn">+ Ajouter une série</button><span></span>`;
    addRow.querySelector('button').addEventListener('click', ()=>{
      exDraft.sets.push({reps:'',weight:'',rir:''});
      saveState();
      rerenderSetsTable();
    });
    setsWrap.appendChild(addRow);
  }
  rerenderSetsTable();
  card.appendChild(setsWrap);

  function refreshDoneState(){
    const nowHas = exDraft.sets.some(s=>s.reps && s.weight);
    card.classList.toggle('ex-done', nowHas);
    top.querySelector('.ex-check').textContent = nowHas ? '✓' : '';
  }

  const noteField = document.createElement('div');
  noteField.className = 'ex-note-field';
  noteField.style.padding = '0 16px 14px';
  noteField.innerHTML = `<textarea placeholder="Note sur cet exercice (sensation, douleur, technique...)">${exDraft.note}</textarea>`;
  noteField.querySelector('textarea').addEventListener('input', e=>{ exDraft.note = e.target.value; saveState(); });
  card.appendChild(noteField);

  return card;
}

function escapeAttr(s){
  return String(s).replace(/"/g,'&quot;');
}

function finishSession(idx){
  const sess = PROGRAM[idx];
  const draft = state.drafts[idx];
  const hasAnySet = draft.exercises.some(e=> e.sets.some(s=>s.reps && s.weight));
  if(!hasAnySet){
    if(!confirm('Aucune série n\'a de poids/reps renseignés. Enregistrer quand même ?')) return;
  }

  const log = {
    id: Date.now()+'-'+idx,
    sessionIndex: idx,
    block: sess.block,
    week: sess.week,
    day: sess.day,
    date: draft.date || todayISO(),
    bodyweight: draft.bodyweight || null,
    feel: draft.feel,
    note: draft.note || '',
    duration: draft.duration || null,
    exercises: draft.exercises.map((e,i)=>({
      name: sess.exercises[i].name,
      variant: e.variant,
      technique: sess.exercises[i].technique,
      note: e.note,
      sets: e.sets.filter(s=>s.reps || s.weight || s.rir)
    })).filter(e=>e.sets.length>0)
  };

  state.logs.push(log);
  delete state.drafts[idx];

  if(idx >= state.cursor){
    state.cursor = idx+1;
  }
  saveState();
  toast('Séance enregistrée 💪');
  activeIndex = state.cursor;
  renderToday();
  renderHistory();
  renderProgress();
}

// ============================================================
// PROGRAM TAB (browse / reference / log any session)
// ============================================================
function renderProgramTab(){
  const weekSel = document.getElementById('prog-select-week');
  const daySel = document.getElementById('prog-select-day');

  const weeks = [...new Set(PROGRAM.map(s=>s.week))];
  weekSel.innerHTML = weeks.map(w=>`<option value="${w}">${w.replace('WEEK','Semaine ')}</option>`).join('');

  function refreshDayOptions(){
    const w = weekSel.value;
    const sessionsInWeek = PROGRAM.filter(s=>s.week===w);
    daySel.innerHTML = sessionsInWeek.map(s=>{
      const gi = PROGRAM.indexOf(s);
      return `<option value="${gi}">${translateDay(s.day)}</option>`;
    }).join('');
  }
  refreshDayOptions();

  function renderChosen(){
    const gi = parseInt(daySel.value,10);
    const holder = document.getElementById('prog-session-view');
    holder.innerHTML = '';
    holder.appendChild(renderSessionForm(gi, false));
    const jumpBtn = document.createElement('button');
    jumpBtn.className = 'btn-secondary btn-block';
    jumpBtn.textContent = 'Enregistrer / consulter cette séance dans "Aujourd\'hui"';
    jumpBtn.addEventListener('click', ()=>{
      activeIndex = gi;
      document.querySelector('.tab-btn[data-view="today"]').click();
      renderToday();
    });
    holder.insertBefore(jumpBtn, holder.firstChild.nextSibling);
  }

  weekSel.addEventListener('change', ()=>{ refreshDayOptions(); renderChosen(); });
  daySel.addEventListener('change', renderChosen);

  // preselect the cursor session
  const clampedCursor = Math.min(state.cursor, TOTAL_SESSIONS-1);
  const cur = PROGRAM[clampedCursor];
  weekSel.value = cur.week;
  refreshDayOptions();
  daySel.value = String(clampedCursor);
  renderChosen();
}

// ============================================================
// HISTORY TAB
// ============================================================
function renderHistory(){
  const list = document.getElementById('history-list');
  if(state.logs.length === 0){
    list.innerHTML = `<div class="empty-note">Pas encore de séance enregistrée. Ta première séance loguée apparaîtra ici.</div>`;
    return;
  }
  const sorted = [...state.logs].sort((a,b)=> b.date.localeCompare(a.date) || b.sessionIndex - a.sessionIndex);
  list.innerHTML = '';
  sorted.forEach(log=>{
    const item = document.createElement('div');
    item.className = 'hist-item';
    const feelObj = FEEL_OPTIONS.find(f=>f.v===log.feel);
    item.innerHTML = `
      <div class="hist-head">
        <div>
          <div class="hist-title">${translateDay(log.day)} — ${log.week.replace('WEEK','S.')}</div>
          <div class="hist-date">${fmtDate(log.date)}${log.bodyweight ? ' · '+log.bodyweight+' '+state.profile.unit : ''} ${feelObj ? '· '+feelObj.e : ''}</div>
        </div>
        <span>▾</span>
      </div>
      <div class="hist-body">
        ${log.exercises.map(e=>`
          <div class="hist-ex">
            <div class="hist-ex-name">${e.variant}${e.variant!==e.name?' <span style="color:var(--text-faint);font-weight:400;">(alt. de '+e.name+')</span>':''}</div>
            <div class="hist-ex-sets">${e.sets.map(s=>`${s.weight||'–'}${state.profile.unit}×${s.reps||'–'}${s.rir?' (RIR '+s.rir+')':''}`).join('  ·  ')}</div>
            ${e.note ? `<div style="margin-top:4px;color:var(--text-dim);">${e.note}</div>` : ''}
          </div>
        `).join('')}
        ${log.note ? `<div style="margin-top:10px;padding-top:10px;border-top:1px solid var(--line-soft);color:var(--text-dim);"><b>Note de séance :</b> ${log.note}</div>` : ''}
      </div>
    `;
    item.querySelector('.hist-head').addEventListener('click', ()=>{
      item.querySelector('.hist-body').classList.toggle('open');
    });
    list.appendChild(item);
  });
}

// ============================================================
// PROGRESS TAB
// ============================================================
function allExerciseNames(){
  const set = new Set();
  PROGRAM.forEach(s=> s.exercises.forEach(e=> set.add(e.name)));
  return [...set].sort((a,b)=>a.localeCompare(b));
}

function renderProgress(){
  const sel = document.getElementById('progress-exercise-select');
  if(sel.options.length === 0){
    allExerciseNames().forEach(name=>{
      const o = document.createElement('option');
      o.value = name; o.textContent = name;
      sel.appendChild(o);
    });
    sel.addEventListener('change', drawProgressForSelected);
  }
  drawProgressForSelected();
  renderOverview();
}

function drawProgressForSelected(){
  const sel = document.getElementById('progress-exercise-select');
  const name = sel.value || sel.options[0]?.value;
  if(!name) return;

  const points = [];
  const sortedLogs = [...state.logs].sort((a,b)=>a.date.localeCompare(b.date));
  sortedLogs.forEach(log=>{
    log.exercises.forEach(e=>{
      if(e.variant === name || e.name === name){
        const weights = e.sets.map(s=>parseFloat(s.weight)).filter(v=>!isNaN(v));
        if(weights.length){
          points.push({date: log.date, value: Math.max(...weights)});
        }
      }
    });
  });

  const canvas = document.getElementById('progress-canvas');
  const emptyNote = document.getElementById('progress-empty');
  const statsHolder = document.getElementById('progress-stats');

  if(points.length === 0){
    canvas.classList.add('hidden');
    emptyNote.classList.remove('hidden');
    statsHolder.innerHTML = '';
    return;
  }
  canvas.classList.remove('hidden');
  emptyNote.classList.add('hidden');
  drawLineChart(canvas, points);

  const best = Math.max(...points.map(p=>p.value));
  const last = points[points.length-1].value;
  statsHolder.innerHTML = `
    <div class="pstat"><div class="v">${best}</div><div class="l">Record (${state.profile.unit})</div></div>
    <div class="pstat"><div class="v">${last}</div><div class="l">Dernière séance</div></div>
    <div class="pstat"><div class="v">${points.length}</div><div class="l">Séances loguées</div></div>
  `;
}

function drawLineChart(canvas, points){
  const ctx = canvas.getContext('2d');
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0,0,W,H);
  const padL = 40, padR = 16, padT = 20, padB = 30;
  const plotW = W - padL - padR, plotH = H - padT - padB;

  const values = points.map(p=>p.value);
  let min = Math.min(...values), max = Math.max(...values);
  if(min === max){ min -= 5; max += 5; }
  const pad = (max-min)*0.12;
  min -= pad; max += pad;

  ctx.strokeStyle = '#2b2f37';
  ctx.lineWidth = 1;
  ctx.fillStyle = '#6A6D70';
  ctx.font = '11px -apple-system, sans-serif';
  const gridLines = 4;
  for(let i=0;i<=gridLines;i++){
    const y = padT + plotH - (i/gridLines)*plotH;
    ctx.beginPath();
    ctx.moveTo(padL,y); ctx.lineTo(W-padR,y);
    ctx.stroke();
    const val = min + (i/gridLines)*(max-min);
    ctx.fillText(val.toFixed(0), 4, y+4);
  }

  const stepX = points.length > 1 ? plotW/(points.length-1) : 0;
  function xAt(i){ return padL + (points.length>1 ? i*stepX : plotW/2); }
  function yAt(v){ return padT + plotH - ((v-min)/(max-min))*plotH; }

  // line
  ctx.strokeStyle = '#C4442A';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  points.forEach((p,i)=>{
    const x=xAt(i), y=yAt(p.value);
    if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  });
  ctx.stroke();

  // fill under line
  ctx.lineTo(xAt(points.length-1), padT+plotH);
  ctx.lineTo(xAt(0), padT+plotH);
  ctx.closePath();
  ctx.fillStyle = 'rgba(196,68,42,0.12)';
  ctx.fill();

  // points
  points.forEach((p,i)=>{
    const x=xAt(i), y=yAt(p.value);
    ctx.beginPath();
    ctx.arc(x,y,3.5,0,Math.PI*2);
    ctx.fillStyle = '#ECE8E0';
    ctx.fill();
    ctx.strokeStyle = '#C4442A';
    ctx.lineWidth = 2;
    ctx.stroke();
  });

  // x labels (first, middle, last)
  ctx.fillStyle = '#6A6D70';
  ctx.font = '10px -apple-system, sans-serif';
  const idxs = points.length > 1 ? [0, Math.floor((points.length-1)/2), points.length-1] : [0];
  idxs.forEach(i=>{
    const label = fmtDate(points[i].date);
    const x = xAt(i);
    ctx.textAlign = i===0 ? 'left' : (i===points.length-1 ? 'right' : 'center');
    ctx.fillText(label, x, H-8);
  });
  ctx.textAlign = 'left';
}

function renderOverview(){
  const holder = document.getElementById('overview-stats');
  const totalSets = state.logs.reduce((acc,l)=> acc + l.exercises.reduce((a2,e)=>a2+e.sets.length,0), 0);
  const daysSinceStart = state.profile.startDate ? Math.max(0, Math.round((new Date(todayISO()) - new Date(state.profile.startDate))/86400000)) : 0;
  const avgFeel = (() => {
    const feels = state.logs.map(l=>l.feel).filter(f=>f);
    if(!feels.length) return '—';
    return (feels.reduce((a,b)=>a+b,0)/feels.length).toFixed(1);
  })();

  holder.innerHTML = `
    <div class="ov-card"><div class="v">${state.cursor}/${TOTAL_SESSIONS}</div><div class="l">Séances complétées</div></div>
    <div class="ov-card"><div class="v">${state.logs.length}</div><div class="l">Séances enregistrées</div></div>
    <div class="ov-card"><div class="v">${totalSets}</div><div class="l">Séries totales loguées</div></div>
    <div class="ov-card"><div class="v">${daysSinceStart}</div><div class="l">Jours depuis le début</div></div>
    <div class="ov-card"><div class="v">${avgFeel}</div><div class="l">Ressenti moyen (/4)</div></div>
    <div class="ov-card"><div class="v">${Math.ceil((TOTAL_SESSIONS-state.cursor)/5)}</div><div class="l">Semaines restantes (est.)</div></div>
  `;
}

// ============================================================
// SETTINGS
// ============================================================
function renderSettingsForm(){
  document.getElementById('set-name').value = state.profile.name;
  document.getElementById('set-wrist').value = state.profile.wrist || '';
  document.getElementById('set-startdate').value = state.profile.startDate;
  document.querySelectorAll('#set-unit .seg-btn').forEach(b=>{
    b.classList.toggle('active', b.dataset.val === state.profile.unit);
  });
}

function wireSettings(){
  document.querySelectorAll('#set-unit .seg-btn').forEach(b=>{
    b.addEventListener('click', ()=>{
      document.querySelectorAll('#set-unit .seg-btn').forEach(x=>x.classList.remove('active'));
      b.classList.add('active');
    });
  });

  document.getElementById('set-save').addEventListener('click', ()=>{
    state.profile.name = document.getElementById('set-name').value.trim() || state.profile.name;
    state.profile.unit = document.querySelector('#set-unit .seg-btn.active').dataset.val;
    state.profile.wrist = document.getElementById('set-wrist').value || null;
    state.profile.startDate = document.getElementById('set-startdate').value || state.profile.startDate;
    saveState();
    document.getElementById('hdr-name').textContent = state.profile.name;
    toast('Profil mis à jour');
    renderToday();
  });

  document.getElementById('export-btn').addEventListener('click', ()=>{
    const blob = new Blob([JSON.stringify(state, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fonte-sauvegarde-${todayISO()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });

  document.getElementById('import-input').addEventListener('change', (e)=>{
    const file = e.target.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try{
        const imported = JSON.parse(reader.result);
        if(!imported.profile) throw new Error('Format invalide');
        state = Object.assign(defaultState(), imported);
        saveState();
        toast('Sauvegarde importée');
        activeIndex = state.cursor;
        renderToday(); renderProgramTab(); renderHistory(); renderProgress(); renderSettingsForm();
      }catch(err){
        alert('Fichier invalide : '+err.message);
      }
    };
    reader.readAsText(file);
  });

  document.getElementById('reset-btn').addEventListener('click', ()=>{
    if(confirm('Cela efface définitivement ton profil et tout ton historique sur cet appareil. Continuer ?')){
      if(confirm('Dernière confirmation : tout supprimer ?')){
        localStorage.removeItem(STORE_KEY);
        location.reload();
      }
    }
  });
}

// ============================================================
// SERVICE WORKER
// ============================================================
function registerSW(){
  if('serviceWorker' in navigator){
    window.addEventListener('load', ()=>{
      navigator.serviceWorker.register('sw.js').catch(()=>{});
    });
  }
}
