const $=id=>document.getElementById(id);
const modal=$("modal"),fields=$("modalFields");
const configs={
 customer:["ग्राहक जोड़ें",["पहला नाम","दूसरा नाम","मोबाइल नंबर","ईमेल","शुरुआती उधार (₹)"]],
 supplier:["सप्लायर जोड़ें",["कंपनी / पहला नाम","दूसरा नाम","मोबाइल नंबर","ईमेल","शुरुआती बैलेंस (₹)"]],
 invoice:["नया बिल बनाएँ",["ग्राहक का नाम","बिल प्रकार (GST / Non-GST)","आइटम नाम","क्वांटिटी","रेट","छूट (₹)"]],
 jama:["जमा दर्ज करें",["ग्राहक का नाम","रकम (₹)","दिनांक","नोट"]],
 udhar:["उधार दर्ज करें",["ग्राहक का नाम","रकम (₹)","दिनांक","नोट"]]
};
document.querySelectorAll("[data-modal]").forEach(b=>b.onclick=()=>openModal(b.dataset.modal));
function openModal(type){let c=configs[type];$("modalTitle").textContent=c[0];fields.innerHTML=c[1].map((x,i)=>`<label>${x}${x.includes("नाम")||x.includes("मोबाइल")||x.includes("रकम")?'<input required placeholder="'+x+'">':'<input placeholder="'+x+'">'}</label>`).join("");modal.classList.add("show");}
$("closeModal").onclick=()=>modal.classList.remove("show");
modal.onclick=e=>{if(e.target===modal)modal.classList.remove("show")};
$("modalForm").onsubmit=e=>{e.preventDefault();alert("डेमो में फॉर्म स्वीकार किया गया। पूर्ण सेविंग और लेजर सुविधा अगले संस्करण में जोड़ी जाएगी।");modal.classList.remove("show")};
$("searchToggle").onclick=()=>{$("searchbar").classList.toggle("show");$("searchInput").focus()};
$("searchShortcut").onclick=()=>{$("searchbar").classList.add("show");$("searchInput").focus()};
$("searchInput").oninput=e=>{let q=e.target.value.toLowerCase();document.querySelectorAll("#transactions tr").forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?"":"none")};
