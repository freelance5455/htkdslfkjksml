(() => {
"use strict";
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const KEY = "proofly_phase2_history";
let imgA=null,imgB=null,pdfA=null,pdfB=null,pdfPageA=null,pdfPageB=null,lastImageDiff=null,lastPdfDiff=null,toastTimer;
const esc = s => String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2700);}
function showModal(title,body){$("#modalTitle").textContent=title;$("#modalBody").textContent=body;$("#modal").classList.remove("hidden");}
function hideModal(){$("#modal").classList.add("hidden");}
$("#closeModal").addEventListener("click",hideModal);$("#modalOk").addEventListener("click",hideModal);$("#modal").addEventListener("click",e=>{if(e.target===$("#modal"))hideModal();});
$("#helpBtn").addEventListener("click",()=>showModal("كيف يعمل Proofly؟","كشف فروقات الصور يتم محليًا بمقارنة قيم البكسلات على Canvas. عرض PDF يستخدم مكتبة PDF.js لتحويل الصفحات إلى صور داخل المتصفح. لا يوجد OCR أو فهم دلالي أو رفع ملفات إلى خادم. مكتبة PDF.js في هذه الحزمة تُحمّل من الإنترنت؛ اقرأ README لمعرفة طريقة تجهيز نسخة تعمل دون اتصال."));
$("#privacyBtn").addEventListener("click",()=>showModal("الخصوصية والحدود","تُقرأ الصور وملفات PDF داخل المتصفح. لا يرسل هذا الكود الملفات إلى خادم. سجل النتائج يحفظ أسماء الملفات وبعض الأرقام والملخصات في localStorage فقط، وليس ملفاتك نفسها. حذف بيانات التطبيق قد يمحو السجل. لا تُدخل مستندات حساسة في نسخة غير مختبرة، خصوصًا داخل WebView تابع لطرف ثالث."));
$$(".mode").forEach(b=>b.addEventListener("click",()=>{ $$(".mode").forEach(x=>x.classList.toggle("active",x===b));$("#imageMode").classList.toggle("hidden",b.dataset.mode!=="images");$("#pdfMode").classList.toggle("hidden",b.dataset.mode!=="pdf");}));
function validImage(file){return file&&file.type.startsWith("image/");}
function readImageFile(file){return new Promise((resolve,reject)=>{const url=URL.createObjectURL(file),img=new Image();img.onload=()=>resolve({img,url,file});img.onerror=()=>{URL.revokeObjectURL(url);reject(new Error("تعذر فتح الصورة."));};img.src=url;});}
$("#imageA").addEventListener("change",async e=>{try{if(imgA?.url)URL.revokeObjectURL(imgA.url);if(!validImage(e.target.files[0]))throw new Error("اختر ملف صورة صالحًا.");imgA=await readImageFile(e.target.files[0]);$("#imageNameA").textContent=imgA.file.name;updateImageButton();}catch(err){toast(err.message);}});
$("#imageB").addEventListener("change",async e=>{try{if(imgB?.url)URL.revokeObjectURL(imgB.url);if(!validImage(e.target.files[0]))throw new Error("اختر ملف صورة صالحًا.");imgB=await readImageFile(e.target.files[0]);$("#imageNameB").textContent=imgB.file.name;updateImageButton();}catch(err){toast(err.message);}});
function updateImageButton(){$("#runImageDiff").disabled=!(imgA&&imgB);}
$("#threshold").addEventListener("input",e=>$("#thresholdValue").value=e.target.value);
$("#pdfThreshold").addEventListener("input",e=>$("#pdfThresholdValue").value=e.target.value);
function makeCanvas(w,h){const c=document.createElement("canvas");c.width=w;c.height=h;return c;}
function drawContain(img,canvas){const ctx=canvas.getContext("2d",{willReadFrequently:true});ctx.fillStyle="#fff";ctx.fillRect(0,0,canvas.width,canvas.height);const scale=Math.min(canvas.width/img.naturalWidth,canvas.height/img.naturalHeight);const w=img.naturalWidth*scale,h=img.naturalHeight*scale;ctx.drawImage(img,(canvas.width-w)/2,(canvas.height-h)/2,w,h);}
function compareCanvases(ca,cb,threshold){
 const w=Math.min(1400,Math.max(ca.width,cb.width)),h=Math.min(1400,Math.max(ca.height,cb.height));
 const a=makeCanvas(w,h),b=makeCanvas(w,h),ctxA=a.getContext("2d",{willReadFrequently:true}),ctxB=b.getContext("2d",{willReadFrequently:true});
 ctxA.fillStyle=ctxB.fillStyle="#fff";ctxA.fillRect(0,0,w,h);ctxB.fillRect(0,0,w,h);
 ctxA.drawImage(ca,0,0,w,h);ctxB.drawImage(cb,0,0,w,h);
 const da=ctxA.getImageData(0,0,w,h),db=ctxB.getImageData(0,0,w,h),out=makeCanvas(w,h),ctxO=out.getContext("2d"),od=ctxO.createImageData(w,h);
 let changed=0;const limit=Number(threshold)*3;
 for(let i=0;i<da.data.length;i+=4){
  const delta=Math.abs(da.data[i]-db.data[i])+Math.abs(da.data[i+1]-db.data[i+1])+Math.abs(da.data[i+2]-db.data[i+2]);
  if(delta>limit){changed++;od.data[i]=255;od.data[i+1]=45;od.data[i+2]=85;od.data[i+3]=225;}
  else{const gray=Math.round((da.data[i]*.299+da.data[i+1]*.587+da.data[i+2]*.114)*.22);od.data[i]=gray;od.data[i+1]=gray;od.data[i+2]=gray+3;od.data[i+3]=150;}
 }
 ctxO.putImageData(od,0,0);return {canvas:out,changed,total:w*h,percent:changed/(w*h)*100};
}
function canvasToPng(canvas,name){canvas.toBlob(blob=>{if(!blob){toast("تعذر إنشاء الصورة.");return;}const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}, "image/png");}
function renderCanvas(parent,title,canvas){const card=document.createElement("div");card.className="canvas-card";const label=document.createElement("div");label.className="canvas-title";label.textContent=title;card.append(label,canvas);parent.append(card);}
$("#runImageDiff").addEventListener("click",()=>{
 if(!imgA||!imgB)return;
 try{
  const maxW=Math.max(imgA.img.naturalWidth,imgB.img.naturalWidth),maxH=Math.max(imgA.img.naturalHeight,imgB.img.naturalHeight);
  const w=Math.min(1400,maxW),h=Math.min(1400,maxH),ca=makeCanvas(w,h),cb=makeCanvas(w,h);
  drawContain(imgA.img,ca);drawContain(imgB.img,cb);
  const mode=$("#diffMode").value,results=$("#imageResults"),grid=$("#imageCanvasGrid");grid.innerHTML="";results.classList.remove("hidden");
  if(mode==="side"){renderCanvas(grid,"A — الأصل",ca);renderCanvas(grid,"B — الجديد",cb);lastImageDiff=compareCanvases(ca,cb,Number($("#threshold").value));renderCanvas(grid,"خريطة الفروقات (تقديرية)",lastImageDiff.canvas);}
  else if(mode==="blend"){const overlay=makeCanvas(w,h),ctx=overlay.getContext("2d");ctx.drawImage(ca,0,0);ctx.globalAlpha=.5;ctx.drawImage(cb,0,0);ctx.globalAlpha=1;renderCanvas(grid,"تراكب A + B",overlay);lastImageDiff=compareCanvases(ca,cb,Number($("#threshold").value));renderCanvas(grid,"خريطة الفروقات (تقديرية)",lastImageDiff.canvas);}
  else{lastImageDiff=compareCanvases(ca,cb,Number($("#threshold").value));renderCanvas(grid,"خريطة الفروقات — الأحمر يوضح تغير البكسلات",lastImageDiff.canvas);}
  $("#diffStats").textContent=`${lastImageDiff.percent.toFixed(2)}% من البكسلات اختلفت تقريبًا`;
  $("#downloadDiff").disabled=false;addHistory({type:"image",title:`${imgA.file.name} ↔ ${imgB.file.name}`,detail:`اختلاف بكسلات تقديري: ${lastImageDiff.percent.toFixed(2)}%`});toast("اكتملت المقارنة المحلية.");
 }catch(err){console.error(err);toast("تعذرت المقارنة. جرّب صورًا أصغر.");}
});
$("#downloadDiff").addEventListener("click",()=>{if(lastImageDiff)canvasToPng(lastImageDiff.canvas,"Proofly-image-differences.png");});
$("#saveImageReport").addEventListener("click",()=>{if(!imgA||!imgB||!lastImageDiff){toast("نفّذ المقارنة أولًا.");return;}downloadText(`Proofly — تقرير مقارنة الصور\nA: ${imgA.file.name}\nB: ${imgB.file.name}\nتاريخ التقرير: ${new Date().toLocaleString()}\nنسبة البكسلات المختلفة تقديريًا: ${lastImageDiff.percent.toFixed(2)}%\nحساسية الكشف: ${$("#threshold").value}\n\nتنبيه: هذه مقارنة بكسلات وليست فهمًا لمحتوى الصورة.`, "Proofly-image-report.txt");});
function downloadText(text,name){const blob=new Blob([text],{type:"text/plain;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function addHistory(item){let arr=getHistory();arr.unshift({...item,date:new Date().toISOString()});arr=arr.slice(0,40);try{localStorage.setItem(KEY,JSON.stringify(arr));}catch(e){toast("لم يُحفظ السجل: التخزين المحلي ممتلئ.");}renderHistory();}
function getHistory(){try{const x=JSON.parse(localStorage.getItem(KEY)||"[]");return Array.isArray(x)?x:[];}catch{return[];}}
function renderHistory(){const root=$("#historyList"),items=getHistory();if(!items.length){root.innerHTML='<div class="empty">لا توجد نتائج محفوظة بعد.</div>';return;}root.innerHTML=items.map((it,i)=>`<div class="history-row"><div><strong>${esc(it.title)}</strong><small>${new Date(it.date).toLocaleString()} · ${esc(it.detail||"")}</small></div><button data-del="${i}">حذف</button></div>`).join("");$$("[data-del]",root).forEach(b=>b.addEventListener("click",()=>{const a=getHistory();a.splice(Number(b.dataset.del),1);localStorage.setItem(KEY,JSON.stringify(a));renderHistory();}));}
$("#clearHistory").addEventListener("click",()=>{if(confirm("هل تريد مسح سجل النتائج المحلي؟")){localStorage.removeItem(KEY);renderHistory();toast("تم مسح السجل.");}});
renderHistory();
function pdfReady(){return !!(window.pdfjsLib&&window.pdfjsLib.getDocument);}
function updatePdfButton(){$("#renderPdfPages").disabled=!(pdfA&&pdfB);}
async function loadPdf(file){if(!pdfReady())throw new Error("مكتبة PDF.js غير متاحة. اتصل بالإنترنت أو أضف ملفات المكتبة محليًا كما هو موضح في README.");if(file.size>60*1024*1024)throw new Error("حجم PDF يتجاوز حد النسخة التجريبية (60MB).");const bytes=await file.arrayBuffer();return await window.pdfjsLib.getDocument({data:new Uint8Array(bytes)}).promise;}
$("#pdfA").addEventListener("change",async e=>{const f=e.target.files[0];if(!f)return;try{pdfA=await loadPdf(f);$("#pdfNameA").textContent=`${f.name} · ${pdfA.numPages} صفحة`;$(" #pageA");$("#pageA").max=pdfA.numPages;updatePdfButton();toast("تم فتح ملف PDF الأول محليًا.");}catch(err){pdfA=null;$("#pdfNameA").textContent=f.name;$("#pdfNotice").textContent=err.message;toast(err.message);updatePdfButton();}});
$("#pdfB").addEventListener("change",async e=>{const f=e.target.files[0];if(!f)return;try{pdfB=await loadPdf(f);$("#pdfNameB").textContent=`${f.name} · ${pdfB.numPages} صفحة`;$("#pageB").max=pdfB.numPages;updatePdfButton();toast("تم فتح ملف PDF الثاني محليًا.");}catch(err){pdfB=null;$("#pdfNameB").textContent=f.name;$("#pdfNotice").textContent=err.message;toast(err.message);updatePdfButton();}});
async function renderPdfPage(doc,pageNumber,canvas){const n=Math.max(1,Math.min(doc.numPages,Number(pageNumber)||1)),page=await doc.getPage(n),viewport=page.getViewport({scale:1.35}),ctx=canvas.getContext("2d");canvas.width=Math.min(1600,Math.round(viewport.width));canvas.height=Math.min(2000,Math.round(viewport.height));const scale=Math.min(canvas.width/viewport.width,canvas.height/viewport.height);const v=page.getViewport({scale:1.35*scale});await page.render({canvasContext:ctx,viewport:v}).promise;return n;}
$("#renderPdfPages").addEventListener("click",async()=>{
 if(!pdfA||!pdfB)return;
 try{
  $("#pdfNotice").textContent="جارٍ تحويل الصفحات إلى صور داخل الجهاز…";
  const [a,b]=await Promise.all([renderPdfPage(pdfA,$("#pageA").value,$("#pdfCanvasA")),renderPdfPage(pdfB,$("#pageB").value,$("#pdfCanvasB"))]);
  pdfPageA=a;pdfPageB=b;$("#pdfStats").textContent=`A: صفحة ${a} · B: صفحة ${b}`;$("#pdfResults").classList.remove("hidden");$("#pdfDiffArea").classList.add("hidden");$("#pdfNotice").textContent="تم عرض الصفحتين. يمكنك الآن إجراء مقارنة بصرية تقريبية.";toast("تم عرض صفحات PDF.");
 }catch(err){console.error(err);$("#pdfNotice").textContent="تعذر عرض الصفحات. قد يكون الملف محميًا أو غير صالح.";toast("فشل عرض PDF.");}
});
$("#runPdfDiff").addEventListener("click",()=>{
 try{
  const a=$("#pdfCanvasA"),b=$("#pdfCanvasB");if(!a.width||!b.width){toast("اعرض الصفحتين أولًا.");return;}
  lastPdfDiff=compareCanvases(a,b,Number($("#pdfThreshold").value));const c=$("#pdfDiffCanvas");c.width=lastPdfDiff.canvas.width;c.height=lastPdfDiff.canvas.height;c.getContext("2d").drawImage(lastPdfDiff.canvas,0,0);
  $("#pdfDiffArea").classList.remove("hidden");$("#pdfDiffText").textContent=`اختلفت نسبة تقديرية قدرها ${lastPdfDiff.percent.toFixed(2)}% من البكسلات بعد توحيد أبعاد الصفحتين. هذا ليس تقرير اختلافات نصيًا.`;
  addHistory({type:"pdf",title:`PDF A صفحة ${pdfPageA} ↔ PDF B صفحة ${pdfPageB}`,detail:`اختلاف بكسلات تقديري: ${lastPdfDiff.percent.toFixed(2)}%`});toast("اكتملت مقارنة الصفحات.");
 }catch(err){console.error(err);toast("تعذرت مقارنة صفحات PDF.");}
});
$("#downloadPdfDiff").addEventListener("click",()=>{if(lastPdfDiff)canvasToPng(lastPdfDiff.canvas,"Proofly-PDF-differences.png");});
$("#subscribeBtn").addEventListener("click",()=>showModal("قريبًا","هذه النسخة لا تجمع بريدك ولا تنشئ اشتراكًا فعليًا. عند تجهيز خادم وإعدادات الخصوصية يمكن إضافة قائمة انتظار أو نظام اشتراكات حقيقي."));
if(!pdfReady())setTimeout(()=>{if(!pdfReady())$("#pdfNotice").textContent="مكتبة PDF.js لم تُحمّل. رفع وعرض PDF يحتاج المكتبة؛ الصور والمقارنة المحلية تعمل دونها. راجع README لإعداد PDF.js محليًا.";},1500);
})();