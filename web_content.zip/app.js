/**
 * নিজের হিসাব (Nijer Hisab) - Single-Page Offline Web Application
 * Pure Vanilla JavaScript: Real-time calculation, Local Storage persistence,
 * Password security, Bengali formatting & complete transaction logic.
 */

(() => {
  'use strict';

  // --- 1. CONSTANTS & BENGALI HELPERS ---
  const DB_KEY = 'nijer_hisab_store_v1';

  const BANGLA_MONTHS = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];

  const BANGLA_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  const ENGLISH_DIGITS = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

  function toBanglaDigits(num) {
    if (num === null || num === undefined) return '';
    return num.toString().replace(/\d/g, d => BANGLA_DIGITS[parseInt(d, 10)]);
  }

  function toEnglishDigits(str) {
    if (!str) return '';
    let result = str.toString();
    for (let i = 0; i < 10; i++) {
      result = result.split(BANGLA_DIGITS[i]).join(ENGLISH_DIGITS[i]);
    }
    return result;
  }

  function parseAmount(str) {
    if (!str) return null;
    const cleaned = toEnglishDigits(str).replace(/,/g, '').trim();
    const val = parseFloat(cleaned);
    if (isNaN(val) || val <= 0) return null;
    return Math.round(val * 100) / 100;
  }

  function formatCurrency(num) {
    if (num === null || num === undefined || isNaN(num)) return '৳ ০';
    const isNegative = num < 0;
    const absVal = Math.abs(num);
    const parts = absVal.toFixed(2).split('.');
    let intPart = parts[0];
    const decPart = parts[1];

    // South Asian formatting: 12,34,567
    let lastThree = intPart.substring(intPart.length - 3);
    const otherNumbers = intPart.substring(0, intPart.length - 3);
    if (otherNumbers !== '') {
      lastThree = ',' + lastThree;
    }
    const formattedInt = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;
    const formatted = decPart === '00' ? formattedInt : `${formattedInt}.${decPart}`;

    const banglaFormatted = toBanglaDigits(formatted);
    return isNegative ? `- ৳ ${banglaFormatted}` : `৳ ${banglaFormatted}`;
  }

  function getTodayIso() {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  function getCurrentYear() {
    return new Date().getFullYear();
  }

  function getCurrentMonthIndex() {
    return new Date().getMonth() + 1;
  }

  function formatBanglaDate(isoDate) {
    if (!isoDate) return '';
    const parts = isoDate.split('-');
    if (parts.length < 3) return isoDate;
    const year = toBanglaDigits(parts[0]);
    const monthIdx = parseInt(parts[1], 10) - 1;
    const monthName = BANGLA_MONTHS[monthIdx] || parts[1];
    const day = toBanglaDigits(parseInt(parts[2], 10));
    return `${day} ${monthName}, ${year}`;
  }

  function generateId() {
    return 'id_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  // --- 2. DATA STORE & STATE MANAGEMENT ---
  const defaultState = {
    transactions: [],
    loans: [],
    loanRepayments: [],
    salaries: [],
    settings: {
      profileImageUri: null,
      passwordEnabled: false,
      passwordCode: '',
      isLocked: false
    }
  };

  let appState = loadData();

  function loadData() {
    try {
      const raw = localStorage.getItem(DB_KEY);
      if (!raw) return JSON.parse(JSON.stringify(defaultState));
      const parsed = JSON.parse(raw);
      return {
        transactions: Array.isArray(parsed.transactions) ? parsed.transactions : [],
        loans: Array.isArray(parsed.loans) ? parsed.loans : [],
        loanRepayments: Array.isArray(parsed.loanRepayments) ? parsed.loanRepayments : [],
        salaries: Array.isArray(parsed.salaries) ? parsed.salaries : [],
        settings: Object.assign({}, defaultState.settings, parsed.settings || {})
      };
    } catch (e) {
      console.error('Error reading localStorage:', e);
      return JSON.parse(JSON.stringify(defaultState));
    }
  }

  function saveData() {
    try {
      localStorage.setItem(DB_KEY, JSON.stringify(appState));
    } catch (e) {
      console.error('Error saving to localStorage:', e);
      showToast('ডাটা সংরক্ষণে সমস্যা হয়েছে!');
    }
  }

  // --- 3. TOAST NOTIFICATION ---
  function showToast(message) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = 'toast-msg';
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 2800);
  }

  // --- 4. NAVIGATION & SCREEN SWITCHING ---
  let currentScreen = 'dashboard';

  const screenTitles = {
    dashboard: 'ড্যাশবোর্ড',
    income: 'আয়ের হিসাব',
    expense: 'খরচের হিসাব',
    deposit: 'জমা / সঞ্চয়',
    loan: 'ঋণ ব্যবস্থাপনা',
    salary: 'বেতন (মাদরাসা ও মসজিদ)',
    'quick-add': 'দ্রুত যোগ',
    report: 'আর্থিক রিপোর্ট',
    settings: 'সেটিংস ও প্রোফাইল'
  };

  function switchScreen(screenName) {
    if (!screenTitles[screenName]) return;
    currentScreen = screenName;

    // Update screen visibility
    document.querySelectorAll('.app-screen').forEach(el => {
      el.classList.remove('active');
    });
    const targetScreen = document.getElementById(`screen-${screenName}`);
    if (targetScreen) targetScreen.classList.add('active');

    // Update title
    const titleEl = document.getElementById('current-screen-title');
    if (titleEl) titleEl.textContent = screenTitles[screenName];

    // Update active state in drawer
    document.querySelectorAll('.drawer-item').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-screen') === screenName);
    });

    // Update bottom nav
    document.querySelectorAll('.bottom-nav .nav-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-screen') === screenName);
    });

    // Close drawer
    closeDrawer();

    // Re-render specific screen content
    renderScreen(screenName);
  }

  // Drawer handlers
  const drawerEl = document.getElementById('app-drawer');
  const backdropEl = document.getElementById('drawer-backdrop');

  function openDrawer() {
    if (drawerEl) drawerEl.classList.add('open');
    if (backdropEl) backdropEl.classList.add('active');
  }

  function closeDrawer() {
    if (drawerEl) drawerEl.classList.remove('open');
    if (backdropEl) backdropEl.classList.remove('active');
  }

  // --- 5. CALCULATION ENGINE ---
  function getDashboardStats() {
    const todayIso = getTodayIso();
    const currentYear = getCurrentYear();
    const currentMonth = getCurrentMonthIndex();
    const monthPrefix = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;

    let totalIncome = 0;
    let totalExpense = 0;
    let totalDeposit = 0;

    let todayIncome = 0;
    let todayExpense = 0;
    let todayDeposit = 0;
    let todayLoan = 0;

    let monthIncome = 0;
    let monthExpense = 0;
    let monthDeposit = 0;

    // Process transactions
    appState.transactions.forEach(tx => {
      const isToday = tx.date === todayIso;
      const isThisMonth = tx.date.startsWith(monthPrefix);

      if (
        tx.type === 'INCOME' ||
        tx.type === 'POND_INCOME' ||
        tx.type === 'MADRASAH_SALARY_INCOME' ||
        tx.type === 'MOSQUE_SALARY_INCOME'
      ) {
        totalIncome += tx.amount;
        if (isToday) todayIncome += tx.amount;
        if (isThisMonth) monthIncome += tx.amount;
      } else if (tx.type === 'EXPENSE' || tx.type === 'POND_FEED_EXPENSE') {
        totalExpense += tx.amount;
        if (isToday) todayExpense += tx.amount;
        if (isThisMonth) monthExpense += tx.amount;
      } else if (tx.type === 'DEPOSIT') {
        totalDeposit += tx.amount;
        if (isToday) todayDeposit += tx.amount;
        if (isThisMonth) monthDeposit += tx.amount;
      }
    });

    // Loans and Repayments
    let totalBorrowed = 0;
    let totalRepaid = 0;

    appState.loans.forEach(l => {
      totalBorrowed += l.amount;
      if (l.date === todayIso) todayLoan += l.amount;
    });

    appState.loanRepayments.forEach(r => {
      totalRepaid += r.amount;
    });

    const netRemainingDebt = Math.max(0, totalBorrowed - totalRepaid);
    const netBalance = totalIncome - totalExpense;
    const monthNet = monthIncome - monthExpense;

    return {
      netBalance,
      totalIncome,
      totalExpense,
      totalDeposit,
      todayIncome,
      todayExpense,
      todayDeposit,
      todayLoan,
      monthIncome,
      monthExpense,
      monthDeposit,
      monthNet,
      totalBorrowed,
      totalRepaid,
      netRemainingDebt,
      monthName: BANGLA_MONTHS[currentMonth - 1]
    };
  }

  function getLenderSummaries() {
    const summaryMap = {};

    appState.loans.forEach(loan => {
      const name = (loan.lenderName || 'অজ্ঞাত').trim();
      if (!summaryMap[name]) {
        summaryMap[name] = { lenderName: name, totalBorrowed: 0, totalRepaid: 0, balance: 0 };
      }
      summaryMap[name].totalBorrowed += loan.amount;
    });

    appState.loanRepayments.forEach(repay => {
      const name = (repay.lenderName || 'অজ্ঞাত').trim();
      if (!summaryMap[name]) {
        summaryMap[name] = { lenderName: name, totalBorrowed: 0, totalRepaid: 0, balance: 0 };
      }
      summaryMap[name].totalRepaid += repay.amount;
    });

    const list = Object.values(summaryMap);
    list.forEach(item => {
      item.balance = item.totalBorrowed - item.totalRepaid;
    });
    return list.sort((a, b) => b.balance - a.balance);
  }

  // --- 6. RENDERERS ---

  // Render Dashboard
  function renderDashboard() {
    const stats = getDashboardStats();

    // Hero cards
    const netEl = document.getElementById('dash-net-balance');
    const badgeEl = document.getElementById('dash-status-badge');
    if (netEl) netEl.textContent = formatCurrency(stats.netBalance);
    if (badgeEl) {
      if (stats.netBalance >= 0) {
        badgeEl.textContent = 'উদ্বৃত্ত';
        badgeEl.className = 'hero-badge';
      } else {
        badgeEl.textContent = 'ঘাটতি';
        badgeEl.className = 'hero-badge deficit';
      }
    }

    const incEl = document.getElementById('dash-total-income');
    const expEl = document.getElementById('dash-total-expense');
    const depEl = document.getElementById('dash-total-deposit');
    if (incEl) incEl.textContent = formatCurrency(stats.totalIncome);
    if (expEl) expEl.textContent = formatCurrency(stats.totalExpense);
    if (depEl) depEl.textContent = formatCurrency(stats.totalDeposit);

    // Today stats
    document.getElementById('dash-today-income').textContent = formatCurrency(stats.todayIncome);
    document.getElementById('dash-today-expense').textContent = formatCurrency(stats.todayExpense);
    document.getElementById('dash-today-deposit').textContent = formatCurrency(stats.todayDeposit);
    document.getElementById('dash-today-loan').textContent = formatCurrency(stats.todayLoan);

    // Month stats
    document.getElementById('dash-month-name').textContent = stats.monthName;
    document.getElementById('dash-month-income').textContent = formatCurrency(stats.monthIncome);
    document.getElementById('dash-month-expense').textContent = formatCurrency(stats.monthExpense);
    document.getElementById('dash-month-deposit').textContent = formatCurrency(stats.monthDeposit);
    document.getElementById('dash-total-remaining-debt').textContent = formatCurrency(stats.netRemainingDebt);

    const monthNetEl = document.getElementById('dash-month-net-balance');
    const monthLabelEl = document.getElementById('dash-month-net-label');
    if (monthNetEl) {
      monthNetEl.textContent = formatCurrency(Math.abs(stats.monthNet));
      monthNetEl.className = stats.monthNet >= 0 ? 'text-income' : 'text-expense';
    }
    if (monthLabelEl) {
      monthLabelEl.textContent = stats.monthNet >= 0 ? 'মাসের শেষে উদ্বৃত্ত:' : 'মাসের শেষে ঘাটতি:';
    }

    // Recent 5 transactions
    const recentListEl = document.getElementById('dash-recent-list');
    if (recentListEl) {
      const sorted = [...appState.transactions].sort((a, b) => (b.date > a.date ? 1 : -1)).slice(0, 5);
      if (sorted.length === 0) {
        recentListEl.innerHTML = '<div class="empty-state">কোনো লেনদেন পাওয়া যায়নি</div>';
      } else {
        recentListEl.innerHTML = sorted.map(tx => renderTransactionItem(tx, false)).join('');
      }
    }
  }

  // Render Income Screen
  function renderIncomeScreen() {
    const searchVal = (document.getElementById('income-search')?.value || '').trim().toLowerCase();
    const filterDate = document.getElementById('income-filter-date')?.value || '';

    const list = appState.transactions.filter(tx => {
      const isIncomeType =
        tx.type === 'INCOME' ||
        tx.type === 'POND_INCOME' ||
        tx.type === 'MADRASAH_SALARY_INCOME' ||
        tx.type === 'MOSQUE_SALARY_INCOME';
      if (!isIncomeType) return false;
      if (filterDate && tx.date !== filterDate) return false;
      if (searchVal) {
        const matchesCat = (tx.categoryLabel || '').toLowerCase().includes(searchVal);
        const matchesDesc = (tx.description || '').toLowerCase().includes(searchVal);
        return matchesCat || matchesDesc;
      }
      return true;
    }).sort((a, b) => (b.date > a.date ? 1 : -1));

    const totalIncome = list.reduce((sum, tx) => sum + tx.amount, 0);
    document.getElementById('income-screen-total').textContent = formatCurrency(totalIncome);
    document.getElementById('income-list-count').textContent = toBanglaDigits(list.length);

    const container = document.getElementById('income-items-list');
    if (container) {
      if (list.length === 0) {
        container.innerHTML = '<div class="empty-state">কোনো আয়ের হিসাব পাওয়া যায়নি</div>';
      } else {
        container.innerHTML = list.map(tx => renderTransactionItem(tx, true)).join('');
      }
    }
  }

  // Render Expense Screen
  function renderExpenseScreen() {
    const searchVal = (document.getElementById('expense-search')?.value || '').trim().toLowerCase();
    const filterDate = document.getElementById('expense-filter-date')?.value || '';
    const todayIso = getTodayIso();
    const monthPrefix = `${getCurrentYear()}-${String(getCurrentMonthIndex()).padStart(2, '0')}`;

    const list = appState.transactions.filter(tx => {
      const isExpType = tx.type === 'EXPENSE' || tx.type === 'POND_FEED_EXPENSE';
      if (!isExpType) return false;
      if (filterDate && tx.date !== filterDate) return false;
      if (searchVal) {
        const matchesCat = (tx.categoryLabel || '').toLowerCase().includes(searchVal);
        const matchesDesc = (tx.description || '').toLowerCase().includes(searchVal);
        return matchesCat || matchesDesc;
      }
      return true;
    }).sort((a, b) => (b.date > a.date ? 1 : -1));

    let totalExpense = 0;
    let todayExpense = 0;
    let monthExpense = 0;

    list.forEach(tx => {
      totalExpense += tx.amount;
      if (tx.date === todayIso) todayExpense += tx.amount;
      if (tx.date.startsWith(monthPrefix)) monthExpense += tx.amount;
    });

    document.getElementById('expense-screen-total').textContent = formatCurrency(totalExpense);
    document.getElementById('expense-screen-today').textContent = formatCurrency(todayExpense);
    document.getElementById('expense-screen-month').textContent = formatCurrency(monthExpense);
    document.getElementById('expense-list-count').textContent = toBanglaDigits(list.length);

    const container = document.getElementById('expense-items-list');
    if (container) {
      if (list.length === 0) {
        container.innerHTML = '<div class="empty-state">কোনো খরচের হিসাব পাওয়া যায়নি</div>';
      } else {
        container.innerHTML = list.map(tx => renderTransactionItem(tx, true)).join('');
      }
    }
  }

  // Render Deposit Screen
  function renderDepositScreen() {
    const searchVal = (document.getElementById('deposit-search')?.value || '').trim().toLowerCase();
    const filterDate = document.getElementById('deposit-filter-date')?.value || '';

    const list = appState.transactions.filter(tx => {
      if (tx.type !== 'DEPOSIT') return false;
      if (filterDate && tx.date !== filterDate) return false;
      if (searchVal) {
        const matchesCat = (tx.categoryLabel || '').toLowerCase().includes(searchVal);
        const matchesDesc = (tx.description || '').toLowerCase().includes(searchVal);
        return matchesCat || matchesDesc;
      }
      return true;
    }).sort((a, b) => (b.date > a.date ? 1 : -1));

    const totalDeposit = list.reduce((sum, tx) => sum + tx.amount, 0);
    document.getElementById('deposit-screen-total').textContent = formatCurrency(totalDeposit);
    document.getElementById('deposit-list-count').textContent = toBanglaDigits(list.length);

    const container = document.getElementById('deposit-items-list');
    if (container) {
      if (list.length === 0) {
        container.innerHTML = '<div class="empty-state">কোনো জমার হিসাব পাওয়া যায়নি</div>';
      } else {
        container.innerHTML = list.map(tx => renderTransactionItem(tx, true)).join('');
      }
    }
  }

  // Render Loan Screen
  let activeLoanSubtab = 'lenders';

  function renderLoanScreen() {
    const stats = getDashboardStats();
    document.getElementById('loan-screen-net-debt').textContent = formatCurrency(stats.netRemainingDebt);
    document.getElementById('loan-screen-total-borrowed').textContent = formatCurrency(stats.totalBorrowed);
    document.getElementById('loan-screen-total-repaid').textContent = formatCurrency(stats.totalRepaid);

    // Subtab 1: Lenders summary
    const lendersContainer = document.getElementById('lenders-summary-list');
    const lenderList = getLenderSummaries();
    if (lendersContainer) {
      if (lenderList.length === 0) {
        lendersContainer.innerHTML = '<div class="empty-state">এখনো কোনো ঋণের হিসাব নেই</div>';
      } else {
        lendersContainer.innerHTML = lenderList.map(item => `
          <div class="card-3d tx-item-card" style="flex-direction: column; align-items: stretch; gap: 8px;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
              <div>
                <strong style="font-size: 15px; color: var(--text-main);">👤 ${escapeHtml(item.lenderName)}</strong>
                <div style="font-size: 11px; color: var(--text-muted); margin-top: 2px;">
                  মোট গৃহীত: ${formatCurrency(item.totalBorrowed)} | পরিশোধিত: ${formatCurrency(item.totalRepaid)}
                </div>
              </div>
              <span class="status-tag ${item.balance <= 0 ? 'paid' : 'unpaid'}">
                ${item.balance <= 0 ? 'পরিশোধিত' : 'বাকি আছে'}
              </span>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--border-subtle); padding-top: 6px;">
              <span style="font-size: 12px; font-weight: 600; color: var(--text-muted);">বাকি টাকা:</span>
              <strong style="font-size: 15px;" class="${item.balance > 0 ? 'text-loan' : 'text-income'}">
                ${formatCurrency(item.balance)}
              </strong>
            </div>
          </div>
        `).join('');
      }
    }

    // Subtab 2: Loan records
    const loansContainer = document.getElementById('loans-history-list');
    if (loansContainer) {
      const sortedLoans = [...appState.loans].sort((a, b) => (b.date > a.date ? 1 : -1));
      if (sortedLoans.length === 0) {
        loansContainer.innerHTML = '<div class="empty-state">কোনো ঋণ গ্রহণের রেকর্ড নেই</div>';
      } else {
        loansContainer.innerHTML = sortedLoans.map(loan => `
          <div class="tx-item-card">
            <div class="tx-item-left">
              <div class="tx-icon-pill bg-loan-light">🤝</div>
              <div class="tx-item-details">
                <div class="tx-item-title">${escapeHtml(loan.lenderName)}</div>
                <div class="tx-item-sub">${formatBanglaDate(loan.date)} ${loan.description ? '• ' + escapeHtml(loan.description) : ''}</div>
              </div>
            </div>
            <div class="tx-item-right">
              <span class="tx-amount-badge text-loan">+ ${formatCurrency(loan.amount)}</span>
              <div class="tx-actions">
                <button type="button" class="action-btn-small edit" onclick="window.NijerHisab.editLoan('${loan.id}')" title="সম্পাদনা">✏️</button>
                <button type="button" class="action-btn-small delete" onclick="window.NijerHisab.deleteLoan('${loan.id}')" title="মুছুন">🗑️</button>
              </div>
            </div>
          </div>
        `).join('');
      }
    }

    // Subtab 3: Repayment records
    const repaysContainer = document.getElementById('repayments-history-list');
    if (repaysContainer) {
      const sortedRepays = [...appState.loanRepayments].sort((a, b) => (b.date > a.date ? 1 : -1));
      if (sortedRepays.length === 0) {
        repaysContainer.innerHTML = '<div class="empty-state">কোনো ঋণ পরিশোধের রেকর্ড নেই</div>';
      } else {
        repaysContainer.innerHTML = sortedRepays.map(repay => `
          <div class="tx-item-card">
            <div class="tx-item-left">
              <div class="tx-icon-pill bg-repaid-light">✅</div>
              <div class="tx-item-details">
                <div class="tx-item-title">${escapeHtml(repay.lenderName)}</div>
                <div class="tx-item-sub">${formatBanglaDate(repay.date)} ${repay.description ? '• ' + escapeHtml(repay.description) : ''}</div>
              </div>
            </div>
            <div class="tx-item-right">
              <span class="tx-amount-badge text-repaid">- ${formatCurrency(repay.amount)}</span>
              <div class="tx-actions">
                <button type="button" class="action-btn-small delete" onclick="window.NijerHisab.deleteRepayment('${repay.id}')" title="মুছুন">🗑️</button>
              </div>
            </div>
          </div>
        `).join('');
      }
    }
  }

  // Render Salary Screen
  let activeSalaryInstitution = 'মাদরাসা';
  let activeSalaryYear = getCurrentYear();

  function renderSalaryScreen() {
    // Render Year Pills
    const pillsWrap = document.getElementById('salary-year-pills');
    if (pillsWrap) {
      const years = [activeSalaryYear - 1, activeSalaryYear, activeSalaryYear + 1];
      pillsWrap.innerHTML = years.map(y => `
        <button type="button" class="year-pill ${y === activeSalaryYear ? 'active' : ''}" onclick="window.NijerHisab.setSalaryYear(${y})">
          ${toBanglaDigits(y)}
        </button>
      `).join('');
    }

    // Filter salaries for selected institution and year
    const institutionSalaries = appState.salaries.filter(
      s => s.institution === activeSalaryInstitution && s.year === activeSalaryYear
    );

    const totalPaid = institutionSalaries
      .filter(s => s.isPaid)
      .reduce((sum, s) => sum + s.amount, 0);

    document.getElementById('salary-tab-total-paid').textContent = formatCurrency(totalPaid);

    // Render 12 Months
    const monthsContainer = document.getElementById('salary-months-list');
    if (monthsContainer) {
      let html = '';
      for (let i = 1; i <= 12; i++) {
        const monthName = BANGLA_MONTHS[i - 1];
        const record = institutionSalaries.find(s => s.monthIndex === i);
        const isPaid = record && record.isPaid;

        html += `
          <div class="card-3d salary-month-card">
            <div class="month-badge-square ${isPaid ? 'paid' : ''}">
              ${monthName.substring(0, 3)}
            </div>
            <div class="month-card-info">
              <div class="month-card-header-row">
                <span class="month-name">${monthName}</span>
                ${record ? `
                  <span class="status-tag ${isPaid ? 'paid' : 'unpaid'}">
                    ${isPaid ? 'পরিশোধিত' : 'বকেয়া'}
                  </span>
                ` : ''}
              </div>
              <div class="month-card-sub">
                ${record ? `টাকা: ${formatCurrency(record.amount)} • তারিখ: ${formatBanglaDate(record.date)}` : 'বেতন যোগ করা হয়নি'}
                ${record && record.description ? `<br>${escapeHtml(record.description)}` : ''}
              </div>
            </div>
            <div>
              ${record ? `
                <div class="tx-actions">
                  <button type="button" class="action-btn-small edit" onclick="window.NijerHisab.openSalaryModal('${activeSalaryInstitution}', ${activeSalaryYear}, ${i}, '${monthName}', '${record.id}')" title="সম্পাদনা">✏️</button>
                  <button type="button" class="action-btn-small delete" onclick="window.NijerHisab.deleteSalary('${record.id}')" title="মুছুন">🗑️</button>
                </div>
              ` : `
                <button type="button" class="btn-3d btn-primary" style="padding: 6px 10px; font-size: 11px;" onclick="window.NijerHisab.openSalaryModal('${activeSalaryInstitution}', ${activeSalaryYear}, ${i}, '${monthName}')">
                  + বেতন যোগ
                </button>
              `}
            </div>
          </div>
        `;
      }
      monthsContainer.innerHTML = html;
    }
  }

  // Render Report Screen
  let activeReportTab = 'monthly';
  let reportSelectedMonth = getCurrentMonthIndex();
  let reportSelectedYear = getCurrentYear();

  function renderReportScreen() {
    // 1. Monthly Report Tab
    const chipsWrap = document.getElementById('report-months-chips');
    if (chipsWrap) {
      chipsWrap.innerHTML = BANGLA_MONTHS.map((m, idx) => `
        <button type="button" class="chip-btn ${reportSelectedMonth === (idx + 1) ? 'active' : ''}" onclick="window.NijerHisab.setReportMonth(${idx + 1})">
          ${m}
        </button>
      `).join('');
    }

    const monthPrefix = `${reportSelectedYear}-${String(reportSelectedMonth).padStart(2, '0')}`;
    const monthName = BANGLA_MONTHS[reportSelectedMonth - 1];
    document.getElementById('report-month-title').textContent = `${monthName}, ${toBanglaDigits(reportSelectedYear)} খতিয়ান`;

    let mIncome = 0;
    let mExpense = 0;
    let mDeposit = 0;
    let mLoan = 0;
    let mRepaid = 0;

    appState.transactions.forEach(tx => {
      if (tx.date.startsWith(monthPrefix)) {
        if (
          tx.type === 'INCOME' ||
          tx.type === 'POND_INCOME' ||
          tx.type === 'MADRASAH_SALARY_INCOME' ||
          tx.type === 'MOSQUE_SALARY_INCOME'
        ) {
          mIncome += tx.amount;
        } else if (tx.type === 'EXPENSE' || tx.type === 'POND_FEED_EXPENSE') {
          mExpense += tx.amount;
        } else if (tx.type === 'DEPOSIT') {
          mDeposit += tx.amount;
        }
      }
    });

    appState.loans.forEach(l => {
      if (l.date.startsWith(monthPrefix)) mLoan += l.amount;
    });

    appState.loanRepayments.forEach(r => {
      if (r.date.startsWith(monthPrefix)) mRepaid += r.amount;
    });

    const mNet = mIncome - mExpense;
    const isSurplus = mNet >= 0;

    document.getElementById('rep-m-income').textContent = formatCurrency(mIncome);
    document.getElementById('rep-m-expense').textContent = formatCurrency(mExpense);
    document.getElementById('rep-m-deposit').textContent = formatCurrency(mDeposit);
    document.getElementById('rep-m-loan').textContent = formatCurrency(mLoan);
    document.getElementById('rep-m-repaid').textContent = formatCurrency(mRepaid);

    const mNetBadge = document.getElementById('report-month-badge');
    if (mNetBadge) {
      mNetBadge.textContent = isSurplus ? 'উদ্বৃত্ত' : 'ঘাটতি';
      mNetBadge.className = isSurplus ? 'hero-badge' : 'hero-badge deficit';
    }

    const netLabel = document.getElementById('rep-m-net-label');
    if (netLabel) {
      netLabel.textContent = isSurplus ? 'মাসের শেষে মোট উদ্বৃত্ত:' : 'মাসের শেষে মোট ঘাটতি:';
    }

    const netVal = document.getElementById('rep-m-net');
    if (netVal) {
      netVal.textContent = formatCurrency(Math.abs(mNet));
      netVal.className = isSurplus ? 'text-income' : 'text-expense';
    }

    // 2. Pond Salary Special Report Tab
    const pondTxs = appState.transactions.filter(tx => tx.type === 'POND_INCOME');
    const totalPond = pondTxs.reduce((sum, tx) => sum + tx.amount, 0);
    document.getElementById('rep-pond-total').textContent = formatCurrency(totalPond);

    // Group by month
    const pondByMonth = {};
    pondTxs.forEach(tx => {
      const ym = tx.date.substring(0, 7);
      if (!pondByMonth[ym]) pondByMonth[ym] = { ym, total: 0, count: 0 };
      pondByMonth[ym].total += tx.amount;
      pondByMonth[ym].count += 1;
    });

    const pondMonthListEl = document.getElementById('rep-pond-monthly-list');
    if (pondMonthListEl) {
      const monthKeys = Object.keys(pondByMonth).sort().reverse();
      if (monthKeys.length === 0) {
        pondMonthListEl.innerHTML = '<div class="empty-state">কোনো পুকুরের বেতন যোগ করা হয়নি</div>';
      } else {
        pondMonthListEl.innerHTML = monthKeys.map(ym => {
          const item = pondByMonth[ym];
          const parts = ym.split('-');
          const mName = BANGLA_MONTHS[parseInt(parts[1], 10) - 1] || parts[1];
          const yr = toBanglaDigits(parts[0]);
          return `
            <div class="card-3d tx-item-card">
              <div>
                <strong style="font-size: 14px;">${mName} ${yr}</strong>
                <div style="font-size: 11px; color: var(--text-muted);">লেনদেন: ${toBanglaDigits(item.count)} বার</div>
              </div>
              <strong class="text-deposit" style="font-size: 15px;">${formatCurrency(item.total)}</strong>
            </div>
          `;
        }).join('');
      }
    }

    const pondHistoryEl = document.getElementById('rep-pond-history-list');
    if (pondHistoryEl) {
      const sortedPond = [...pondTxs].sort((a, b) => (b.date > a.date ? 1 : -1));
      if (sortedPond.length === 0) {
        pondHistoryEl.innerHTML = '<div class="empty-state">তালিকা খালি</div>';
      } else {
        pondHistoryEl.innerHTML = sortedPond.map(tx => `
          <div class="card-3d tx-item-card">
            <div>
              <div style="font-size: 14px; font-weight: 600;">${escapeHtml(tx.description || 'পুকুর থেকে বেতন')}</div>
              <div style="font-size: 11px; color: var(--text-muted);">${formatBanglaDate(tx.date)}</div>
            </div>
            <strong class="text-deposit" style="font-size: 15px;">+ ${formatCurrency(tx.amount)}</strong>
          </div>
        `).join('');
      }
    }

    // 3. Daily Report Tab
    renderDailyReport();
  }

  function renderDailyReport() {
    const singleDateInput = document.getElementById('rep-single-date');
    if (!singleDateInput.value) {
      singleDateInput.value = getTodayIso();
    }
    const selDate = singleDateInput.value;
    document.getElementById('rep-daily-title').textContent = `${formatBanglaDate(selDate)}-এর সামগ্রিক হিসাব`;

    let dIncome = 0;
    let dExpense = 0;
    let dDeposit = 0;
    let dLoan = 0;
    let dRepaid = 0;

    appState.transactions.forEach(tx => {
      if (tx.date === selDate) {
        if (
          tx.type === 'INCOME' ||
          tx.type === 'POND_INCOME' ||
          tx.type === 'MADRASAH_SALARY_INCOME' ||
          tx.type === 'MOSQUE_SALARY_INCOME'
        ) {
          dIncome += tx.amount;
        } else if (tx.type === 'EXPENSE' || tx.type === 'POND_FEED_EXPENSE') {
          dExpense += tx.amount;
        } else if (tx.type === 'DEPOSIT') {
          dDeposit += tx.amount;
        }
      }
    });

    appState.loans.forEach(l => {
      if (l.date === selDate) dLoan += l.amount;
    });

    appState.loanRepayments.forEach(r => {
      if (r.date === selDate) dRepaid += r.amount;
    });

    const dNet = dIncome - dExpense;

    document.getElementById('rep-d-income').textContent = formatCurrency(dIncome);
    document.getElementById('rep-d-expense').textContent = formatCurrency(dExpense);
    document.getElementById('rep-d-deposit').textContent = formatCurrency(dDeposit);
    document.getElementById('rep-d-loan').textContent = formatCurrency(dLoan);
    document.getElementById('rep-d-repaid').textContent = formatCurrency(dRepaid);

    const dNetEl = document.getElementById('rep-d-net');
    if (dNetEl) {
      dNetEl.textContent = formatCurrency(dNet);
      dNetEl.className = dNet >= 0 ? 'text-income' : 'text-expense';
    }
  }

  // Render Settings Screen
  function renderSettingsScreen() {
    updateProfileAvatars();
    const pwStatus = document.getElementById('password-status-text');
    const toggleBtn = document.getElementById('btn-toggle-password');
    if (appState.settings.passwordEnabled) {
      if (pwStatus) pwStatus.textContent = 'পাসওয়ার্ড লক সক্রিয় আছে';
      if (toggleBtn) toggleBtn.textContent = 'পাসওয়ার্ড পরিবর্তন / বন্ধ';
    } else {
      if (pwStatus) pwStatus.textContent = 'পাসওয়ার্ড বর্তমানে বন্ধ আছে';
      if (toggleBtn) toggleBtn.textContent = 'পাসওয়ার্ড সেট করুন';
    }
  }

  function renderScreen(screenName) {
    switch (screenName) {
      case 'dashboard':
        renderDashboard();
        break;
      case 'income':
        renderIncomeScreen();
        break;
      case 'expense':
        renderExpenseScreen();
        break;
      case 'deposit':
        renderDepositScreen();
        break;
      case 'loan':
        renderLoanScreen();
        break;
      case 'salary':
        renderSalaryScreen();
        break;
      case 'quick-add':
        // Quick add form reset
        document.getElementById('quick-date').value = getTodayIso();
        break;
      case 'report':
        renderReportScreen();
        break;
      case 'settings':
        renderSettingsScreen();
        break;
    }
  }

  // Helper for single transaction item HTML
  function renderTransactionItem(tx, showActions = true) {
    let icon = '💰';
    let colorClass = 'text-income';
    let bgClass = 'bg-income-light';
    let sign = '+';

    if (tx.type === 'EXPENSE' || tx.type === 'POND_FEED_EXPENSE') {
      icon = '💸';
      colorClass = 'text-expense';
      bgClass = 'bg-expense-light';
      sign = '-';
    } else if (tx.type === 'DEPOSIT') {
      icon = '🏦';
      colorClass = 'text-deposit';
      bgClass = 'bg-deposit-light';
      sign = '';
    } else if (tx.type === 'POND_INCOME') {
      icon = '🐟';
      colorClass = 'text-deposit';
      bgClass = 'bg-deposit-light';
      sign = '+';
    }

    return `
      <div class="tx-item-card">
        <div class="tx-item-left">
          <div class="tx-icon-pill ${bgClass}">${icon}</div>
          <div class="tx-item-details">
            <div class="tx-item-title">${escapeHtml(tx.categoryLabel || tx.description || 'হিসাব')}</div>
            <div class="tx-item-sub">${formatBanglaDate(tx.date)} ${tx.description && tx.description !== tx.categoryLabel ? '• ' + escapeHtml(tx.description) : ''}</div>
          </div>
        </div>
        <div class="tx-item-right">
          <span class="tx-amount-badge ${colorClass}">${sign} ${formatCurrency(tx.amount)}</span>
          ${showActions ? `
            <div class="tx-actions">
              <button type="button" class="action-btn-small edit" onclick="window.NijerHisab.editTransaction('${tx.id}')" title="সম্পাদনা">✏️</button>
              <button type="button" class="action-btn-small delete" onclick="window.NijerHisab.deleteTransaction('${tx.id}')" title="মুছুন">🗑️</button>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function updateProfileAvatars() {
    const uri = appState.settings.profileImageUri;
    const headerAvatar = document.getElementById('header-avatar');
    const drawerAvatar = document.getElementById('drawer-avatar');
    const previewAvatar = document.getElementById('settings-avatar-preview');

    const renderImg = `<img src="${uri}" alt="প্রোফাইল">`;
    const defaultSvg = `
      <svg viewBox="0 0 24 24" width="100%" height="100%" fill="currentColor">
        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
      </svg>
    `;

    if (uri) {
      if (headerAvatar) headerAvatar.innerHTML = renderImg;
      if (drawerAvatar) drawerAvatar.innerHTML = renderImg;
      if (previewAvatar) previewAvatar.innerHTML = renderImg;
    } else {
      if (headerAvatar) headerAvatar.innerHTML = defaultSvg;
      if (drawerAvatar) drawerAvatar.innerHTML = defaultSvg;
      if (previewAvatar) previewAvatar.innerHTML = defaultSvg;
    }
  }

  // --- 7. MODALS & FORMS HANDLING ---

  function openModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('hidden');
  }

  function closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
  }

  // Generic Confirmation Modal
  let pendingConfirmAction = null;
  function showConfirmDialog(title, message, onConfirm) {
    document.getElementById('confirm-title').textContent = title;
    document.getElementById('confirm-message').textContent = message;
    pendingConfirmAction = onConfirm;
    openModal('modal-confirm');
  }

  document.getElementById('btn-confirm-cancel')?.addEventListener('click', () => {
    closeModal('modal-confirm');
    pendingConfirmAction = null;
  });

  document.getElementById('btn-confirm-proceed')?.addEventListener('click', () => {
    if (typeof pendingConfirmAction === 'function') {
      pendingConfirmAction();
    }
    closeModal('modal-confirm');
    pendingConfirmAction = null;
  });

  // Close buttons on all modals
  document.querySelectorAll('[data-close-modal]').forEach(btn => {
    btn.addEventListener('click', () => {
      const modalId = btn.getAttribute('data-close-modal');
      closeModal(modalId);
    });
  });

  // Modal 1: Transactions (Income, Expense, Deposit)
  function openTransactionModal(type, existing = null) {
    const form = document.getElementById('form-transaction');
    form.reset();
    document.getElementById('tx-id').value = existing ? existing.id : '';
    document.getElementById('tx-type').value = type;
    document.getElementById('tx-date').value = existing ? existing.date : getTodayIso();
    document.getElementById('tx-amount').value = existing ? existing.amount : '';
    document.getElementById('tx-category').value = existing ? existing.categoryLabel : '';
    document.getElementById('tx-desc').value = existing ? existing.description : '';

    const titleEl = document.getElementById('modal-tx-title');
    const saveBtn = document.getElementById('btn-save-tx');

    if (type === 'INCOME') {
      titleEl.textContent = existing ? 'আয় সংশোধন' : 'নতুন আয় যোগ';
      saveBtn.className = 'btn-3d btn-income';
    } else if (type === 'EXPENSE') {
      titleEl.textContent = existing ? 'খরচ সংশোধন' : 'নতুন খরচ যোগ';
      saveBtn.className = 'btn-3d btn-expense';
    } else if (type === 'DEPOSIT') {
      titleEl.textContent = existing ? 'জমা সংশোধন' : 'নতুন জমা যোগ';
      saveBtn.className = 'btn-3d btn-deposit';
    }

    openModal('modal-transaction');
  }

  document.getElementById('form-transaction')?.addEventListener('submit', e => {
    e.preventDefault();
    const id = document.getElementById('tx-id').value;
    const type = document.getElementById('tx-type').value;
    const date = document.getElementById('tx-date').value;
    const amountVal = parseAmount(document.getElementById('tx-amount').value);
    const category = document.getElementById('tx-category').value.trim();
    const desc = document.getElementById('tx-desc').value.trim();

    if (!amountVal || amountVal <= 0) {
      showToast('সঠিক টাকার পরিমাণ লিখুন!');
      return;
    }
    if (!category) {
      showToast('ধরন বা খাত লিখুন!');
      return;
    }

    if (id) {
      const existingIdx = appState.transactions.findIndex(t => t.id === id);
      if (existingIdx !== -1) {
        appState.transactions[existingIdx].date = date;
        appState.transactions[existingIdx].amount = amountVal;
        appState.transactions[existingIdx].categoryLabel = category;
        appState.transactions[existingIdx].description = desc;
      }
      showToast('হিসাব সফলভাবে সংশোধন করা হয়েছে');
    } else {
      appState.transactions.push({
        id: generateId(),
        type,
        categoryLabel: category,
        amount: amountVal,
        date,
        description: desc,
        createdAt: Date.now()
      });
      showToast('নতুন হিসাব সফলভাবে সংরক্ষিত হয়েছে');
    }

    saveData();
    closeModal('modal-transaction');
    renderDashboard();
    if (currentScreen === 'income') renderIncomeScreen();
    if (currentScreen === 'expense') renderExpenseScreen();
    if (currentScreen === 'deposit') renderDepositScreen();
  });

  // Modal 2: Loan Add/Edit
  function openLoanModal(existing = null) {
    const form = document.getElementById('form-loan');
    form.reset();
    document.getElementById('loan-id').value = existing ? existing.id : '';
    document.getElementById('loan-lender').value = existing ? existing.lenderName : '';
    document.getElementById('loan-amount').value = existing ? existing.amount : '';
    document.getElementById('loan-date').value = existing ? existing.date : getTodayIso();
    document.getElementById('loan-desc').value = existing ? existing.description : '';

    const titleEl = document.getElementById('modal-loan-title');
    if (titleEl) titleEl.textContent = existing ? 'ঋণ গ্রহণ সংশোধন' : 'নতুন ঋণ গ্রহণ';
    openModal('modal-loan');
  }

  document.getElementById('form-loan')?.addEventListener('submit', e => {
    e.preventDefault();
    const id = document.getElementById('loan-id').value;
    const lender = document.getElementById('loan-lender').value.trim();
    const amountVal = parseAmount(document.getElementById('loan-amount').value);
    const date = document.getElementById('loan-date').value;
    const desc = document.getElementById('loan-desc').value.trim();

    if (!lender) {
      showToast('ব্যক্তির নাম লিখুন!');
      return;
    }
    if (!amountVal || amountVal <= 0) {
      showToast('সঠিক টাকার পরিমাণ লিখুন!');
      return;
    }

    if (id) {
      const idx = appState.loans.findIndex(l => l.id === id);
      if (idx !== -1) {
        appState.loans[idx].lenderName = lender;
        appState.loans[idx].amount = amountVal;
        appState.loans[idx].date = date;
        appState.loans[idx].description = desc;
      }
      showToast('ঋণ সফলভাবে সংশোধন করা হয়েছে');
    } else {
      appState.loans.push({
        id: generateId(),
        lenderName: lender,
        amount: amountVal,
        date,
        description: desc,
        createdAt: Date.now()
      });
      showToast('নতুন ঋণ সংরক্ষিত হয়েছে');
    }

    saveData();
    closeModal('modal-loan');
    renderLoanScreen();
    renderDashboard();
  });

  // Modal 3: Loan Repayment
  function openRepayModal(prefilledLender = null) {
    const form = document.getElementById('form-repay');
    form.reset();
    document.getElementById('repay-date').value = getTodayIso();

    const selectEl = document.getElementById('repay-lender-select');
    selectEl.innerHTML = '<option value="">ব্যক্তি নির্বাচন করুন...</option>';

    const lenders = getLenderSummaries().filter(item => item.balance > 0);
    if (lenders.length === 0) {
      showToast('পরিশোধ করার মতো কোনো বাকি ঋণ নেই!');
      return;
    }

    lenders.forEach(item => {
      const opt = document.createElement('option');
      opt.value = item.lenderName;
      opt.textContent = `${item.lenderName} (বাকি: ${formatCurrency(item.balance)})`;
      if (prefilledLender && item.lenderName === prefilledLender) {
        opt.selected = true;
      }
      selectEl.appendChild(opt);
    });

    updateRepayHint();
    openModal('modal-repay');
  }

  function updateRepayHint() {
    const selectEl = document.getElementById('repay-lender-select');
    const hintEl = document.getElementById('repay-balance-hint');
    const selectedName = selectEl.value;
    if (!selectedName) {
      hintEl.textContent = '';
      return;
    }
    const summaries = getLenderSummaries();
    const found = summaries.find(s => s.lenderName === selectedName);
    if (found) {
      hintEl.textContent = `${found.lenderName}-এর বর্তমান বাকি ঋণ: ${formatCurrency(found.balance)}`;
    }
  }

  document.getElementById('repay-lender-select')?.addEventListener('change', updateRepayHint);

  document.getElementById('form-repay')?.addEventListener('submit', e => {
    e.preventDefault();
    const lender = document.getElementById('repay-lender-select').value;
    const amountVal = parseAmount(document.getElementById('repay-amount').value);
    const date = document.getElementById('repay-date').value;
    const desc = document.getElementById('repay-desc').value.trim();

    if (!lender) {
      showToast('অনুগ্রহ করে ব্যক্তি নির্বাচন করুন!');
      return;
    }
    if (!amountVal || amountVal <= 0) {
      showToast('সঠিক টাকার পরিমাণ লিখুন!');
      return;
    }

    appState.loanRepayments.push({
      id: generateId(),
      lenderName: lender,
      amount: amountVal,
      date,
      description: desc,
      createdAt: Date.now()
    });

    showToast('ঋণ পরিশোধ সফলভাবে সংরক্ষিত হয়েছে');
    saveData();
    closeModal('modal-repay');
    renderLoanScreen();
    renderDashboard();
  });

  // Modal 4: Salary Modal & Duplicate Warning
  let duplicateWarningSalaryData = null;

  function openSalaryModal(institution, year, monthIndex, monthName, existingId = null) {
    const form = document.getElementById('form-salary');
    form.reset();

    const existing = existingId ? appState.salaries.find(s => s.id === existingId) : null;

    document.getElementById('salary-id').value = existing ? existing.id : '';
    document.getElementById('salary-institution').value = institution;
    document.getElementById('salary-year').value = year;
    document.getElementById('salary-month-index').value = monthIndex;
    document.getElementById('salary-month-name').value = monthName;

    document.getElementById('salary-amount').value = existing ? existing.amount : '';
    document.getElementById('salary-date').value = existing ? existing.date : getTodayIso();
    document.getElementById('salary-desc').value = existing ? existing.description : '';
    document.getElementById('salary-is-paid').checked = existing ? existing.isPaid : true;

    document.getElementById('modal-salary-title').textContent = `${institution} বেতন (${monthName}, ${toBanglaDigits(year)})`;
    openModal('modal-salary');
  }

  document.getElementById('form-salary')?.addEventListener('submit', e => {
    e.preventDefault();
    const id = document.getElementById('salary-id').value;
    const institution = document.getElementById('salary-institution').value;
    const year = parseInt(document.getElementById('salary-year').value, 10);
    const monthIndex = parseInt(document.getElementById('salary-month-index').value, 10);
    const monthName = document.getElementById('salary-month-name').value;
    const amountVal = parseAmount(document.getElementById('salary-amount').value);
    const date = document.getElementById('salary-date').value;
    const desc = document.getElementById('salary-desc').value.trim();
    const isPaid = document.getElementById('salary-is-paid').checked;

    if (!amountVal || amountVal <= 0) {
      showToast('সঠিক টাকার পরিমাণ লিখুন!');
      return;
    }

    // Check duplicate if not editing existing record
    if (!id) {
      const duplicate = appState.salaries.find(
        s => s.institution === institution && s.year === year && s.monthIndex === monthIndex
      );
      if (duplicate) {
        duplicateWarningSalaryData = {
          existingId: duplicate.id,
          institution,
          year,
          monthIndex,
          monthName,
          amount: amountVal,
          date,
          description: desc,
          isPaid
        };
        document.getElementById('dup-warning-text').textContent =
          `${monthName} মাসের বেতন পূর্বে ইতিমধ্যে সংরক্ষিত রয়েছে (পূর্বে যোগ করা: ${formatCurrency(duplicate.amount)})।`;
        openModal('modal-duplicate-warning');
        return;
      }
    }

    saveSalaryRecord(id, institution, year, monthIndex, monthName, amountVal, date, desc, isPaid);
  });

  function saveSalaryRecord(id, institution, year, monthIndex, monthName, amount, date, description, isPaid) {
    if (id) {
      const idx = appState.salaries.findIndex(s => s.id === id);
      if (idx !== -1) {
        appState.salaries[idx].amount = amount;
        appState.salaries[idx].date = date;
        appState.salaries[idx].description = description;
        appState.salaries[idx].isPaid = isPaid;
      }
      showToast('বেতন সফলভাবে সংশোধন করা হয়েছে');
    } else {
      appState.salaries.push({
        id: generateId(),
        institution,
        year,
        monthIndex,
        monthName,
        amount,
        date,
        description,
        isPaid,
        createdAt: Date.now()
      });
      showToast('বেতন সফলভাবে যোগ করা হয়েছে');
    }

    saveData();
    closeModal('modal-salary');
    renderSalaryScreen();
  }

  // Duplicate Warning Confirm / Cancel
  document.getElementById('btn-dup-confirm')?.addEventListener('click', () => {
    if (duplicateWarningSalaryData) {
      const d = duplicateWarningSalaryData;
      saveSalaryRecord(d.existingId, d.institution, d.year, d.monthIndex, d.monthName, d.amount, d.date, d.description, d.isPaid);
      duplicateWarningSalaryData = null;
    }
    closeModal('modal-duplicate-warning');
  });

  document.getElementById('btn-dup-cancel')?.addEventListener('click', () => {
    duplicateWarningSalaryData = null;
    closeModal('modal-duplicate-warning');
  });

  // Modal 5: Quick Add
  let activeQuickType = 'INCOME';

  const quickTypeConfigs = {
    INCOME: {
      type: 'INCOME',
      title: 'দ্রুত আয়ের তথ্য লিখুন',
      category: 'সাধারণ আয়',
      colorClass: 'text-income',
      defaultDesc: 'সাধারণ আয়'
    },
    EXPENSE: {
      type: 'EXPENSE',
      title: 'দ্রুত খরচের তথ্য লিখুন',
      category: 'সাধারণ খরচ',
      colorClass: 'text-expense',
      defaultDesc: 'সাধারণ খরচ'
    },
    POND_INCOME: {
      type: 'POND_INCOME',
      title: 'পুকুর থেকে বেতনের তথ্য লিখুন',
      category: 'পুকুর থেকে বেতন',
      colorClass: 'text-deposit',
      defaultDesc: 'পুকুর থেকে প্রাপ্ত বেতন'
    },
    POND_FEED_EXPENSE: {
      type: 'POND_FEED_EXPENSE',
      title: 'পুকুরে খাবারের খরচের তথ্য লিখুন',
      category: 'পুকুরে খাবার',
      colorClass: 'text-loan',
      defaultDesc: 'পুকুরের মাছের খাবার'
    }
  };

  document.querySelectorAll('.quick-opt-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.quick-opt-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      activeQuickType = card.getAttribute('data-quick-type');
      const cfg = quickTypeConfigs[activeQuickType];
      const titleEl = document.getElementById('quick-form-title');
      if (titleEl) {
        titleEl.textContent = cfg.title;
        titleEl.className = `form-title ${cfg.colorClass}`;
      }
      document.getElementById('quick-desc').placeholder = cfg.defaultDesc;
    });
  });

  document.getElementById('btn-save-quick')?.addEventListener('click', () => {
    const date = document.getElementById('quick-date').value || getTodayIso();
    const amountVal = parseAmount(document.getElementById('quick-amount').value);
    const descVal = document.getElementById('quick-desc').value.trim();
    const cfg = quickTypeConfigs[activeQuickType];

    if (!amountVal || amountVal <= 0) {
      showToast('সঠিক টাকার পরিমাণ লিখুন!');
      return;
    }

    appState.transactions.push({
      id: generateId(),
      type: cfg.type,
      categoryLabel: cfg.category,
      amount: amountVal,
      date,
      description: descVal || cfg.defaultDesc,
      createdAt: Date.now()
    });

    saveData();
    showToast('দ্রুত হিসাব সফলভাবে সংরক্ষিত হয়েছে');
    document.getElementById('quick-amount').value = '';
    document.getElementById('quick-desc').value = '';
    renderDashboard();
  });

  // Modal 6: Password Management
  function openPasswordModal() {
    const form = document.getElementById('form-password');
    form.reset();
    document.getElementById('pw-error-msg').textContent = '';

    const currentGroup = document.getElementById('pw-current-group');
    if (appState.settings.passwordEnabled) {
      currentGroup.classList.remove('hidden');
    } else {
      currentGroup.classList.add('hidden');
    }
    document.getElementById('pw-is-enabled').checked = appState.settings.passwordEnabled;
    openModal('modal-password');
  }

  document.getElementById('form-password')?.addEventListener('submit', e => {
    e.preventDefault();
    const isEnabled = document.getElementById('pw-is-enabled').checked;
    const currentCode = document.getElementById('pw-current').value.trim();
    const newCode = document.getElementById('pw-new').value.trim();
    const confirmCode = document.getElementById('pw-confirm').value.trim();
    const errorEl = document.getElementById('pw-error-msg');

    if (appState.settings.passwordEnabled) {
      if (currentCode !== appState.settings.passwordCode) {
        errorEl.textContent = 'বর্তমান পাসওয়ার্ড সঠিক নয়!';
        return;
      }
    }

    if (!isEnabled) {
      // User turned off password
      appState.settings.passwordEnabled = false;
      appState.settings.passwordCode = '';
      appState.settings.isLocked = false;
      saveData();
      showToast('পাসওয়ার্ড লক বন্ধ করা হয়েছে');
      closeModal('modal-password');
      renderSettingsScreen();
      return;
    }

    if (!newCode || newCode.length < 4) {
      errorEl.textContent = 'পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে!';
      return;
    }

    if (newCode !== confirmCode) {
      errorEl.textContent = 'উভয় পাসওয়ার্ড মিলছে না!';
      return;
    }

    appState.settings.passwordEnabled = true;
    appState.settings.passwordCode = newCode;
    saveData();
    showToast('পাসওয়ার্ড সফলভাবে সংরক্ষিত হয়েছে');
    closeModal('modal-password');
    renderSettingsScreen();
  });

  // Lock Screen Logic
  function checkLockStatus() {
    const lockScreen = document.getElementById('lock-screen');
    if (appState.settings.passwordEnabled) {
      lockScreen.classList.remove('hidden');
      document.getElementById('lock-input').value = '';
      document.getElementById('lock-error').textContent = '';
      updatePinDots(0);
      document.getElementById('lock-input').focus();
    } else {
      lockScreen.classList.add('hidden');
    }
  }

  function unlockApp() {
    const inputCode = document.getElementById('lock-input').value.trim();
    const errorEl = document.getElementById('lock-error');
    if (inputCode === appState.settings.passwordCode) {
      document.getElementById('lock-screen').classList.add('hidden');
      showToast('লগইন সফল হয়েছে');
    } else {
      errorEl.textContent = 'ভুল পাসওয়ার্ড! পুনরায় চেষ্টা করুন।';
      document.getElementById('lock-input').value = '';
      updatePinDots(0);
    }
  }

  function updatePinDots(len) {
    const dots = document.querySelectorAll('.pin-dot');
    dots.forEach((dot, idx) => {
      dot.classList.toggle('filled', idx < len);
    });
  }

  document.getElementById('lock-input')?.addEventListener('input', e => {
    updatePinDots(e.target.value.length);
    if (e.target.value.length >= 4 && e.target.value === appState.settings.passwordCode) {
      unlockApp();
    }
  });

  document.getElementById('lock-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') unlockApp();
  });

  document.getElementById('btn-unlock')?.addEventListener('click', unlockApp);

  // Profile Picture Upload
  document.getElementById('profile-photo-input')?.addEventListener('change', e => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = event => {
      appState.settings.profileImageUri = event.target.result;
      saveData();
      updateProfileAvatars();
      showToast('প্রোফাইল ছবি সফলভাবে পরিবর্তিত হয়েছে');
    };
    reader.readAsDataURL(file);
  });

  // Backup Download (JSON)
  document.getElementById('btn-download-backup')?.addEventListener('click', () => {
    try {
      const backupData = JSON.stringify(appState, null, 2);
      const blob = new Blob([backupData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `nijer_hisab_backup_${getTodayIso()}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast('ব্যাকআপ ফাইল সফলভাবে ডাউনলোড হয়েছে');
    } catch (e) {
      console.error(e);
      showToast('ব্যাকআপ ফাইলে সমস্যা হয়েছে');
    }
  });

  // File Restore
  document.getElementById('restore-file-input')?.addEventListener('change', e => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = event => {
      restoreFromJsonString(event.target.result);
    };
    reader.readAsText(file);
  });

  // Text Restore Modal
  document.getElementById('btn-open-text-restore')?.addEventListener('click', () => {
    document.getElementById('restore-json-textarea').value = '';
    openModal('modal-text-restore');
  });

  document.getElementById('btn-submit-text-restore')?.addEventListener('click', () => {
    const text = document.getElementById('restore-json-textarea').value.trim();
    if (!text) {
      showToast('অনুগ্রহ করে ব্যাকআপ কোড পেস্ট করুন!');
      return;
    }
    const success = restoreFromJsonString(text);
    if (success) {
      closeModal('modal-text-restore');
    }
  });

  function restoreFromJsonString(jsonStr) {
    try {
      const parsed = JSON.parse(jsonStr);
      if (!parsed || typeof parsed !== 'object') {
        showToast('অকার্যকর ব্যাকআপ ফাইল!');
        return false;
      }
      appState = {
        transactions: Array.isArray(parsed.transactions) ? parsed.transactions : [],
        loans: Array.isArray(parsed.loans) ? parsed.loans : [],
        loanRepayments: Array.isArray(parsed.loanRepayments) ? parsed.loanRepayments : [],
        salaries: Array.isArray(parsed.salaries) ? parsed.salaries : [],
        settings: Object.assign({}, defaultState.settings, parsed.settings || {})
      };
      saveData();
      showToast('ডাটা সফলভাবে রিস্টোর হয়েছে!');
      renderDashboard();
      renderSettingsScreen();
      return true;
    } catch (e) {
      console.error(e);
      showToast('ব্যাকআপ কোড পার্স করতে ব্যর্থ হয়েছে!');
      return false;
    }
  }

  // Clear All Data
  document.getElementById('btn-open-clear-data')?.addEventListener('click', () => {
    showConfirmDialog(
      'সব ডাটা মুছে ফেলতে চান?',
      'সতর্কতা: এটি নিশ্চিত করলে আপনার সমস্ত সংরক্ষিত আয়, খরচ, জমা, ঋণ ও বেতনের হিসাব স্থায়ীভাবে মুছে যাবে। এটি আর ফিরিয়ে আনা যাবে না!',
      () => {
        appState.transactions = [];
        appState.loans = [];
        appState.loanRepayments = [];
        appState.salaries = [];
        saveData();
        showToast('সব হিসাবের ডাটা সফলভাবে মুছে ফেলা হয়েছে');
        renderDashboard();
      }
    );
  });

  // --- 8. GLOBAL EXPOSURES FOR INLINE CLICKS ---
  window.NijerHisab = {
    editTransaction: function(id) {
      const tx = appState.transactions.find(t => t.id === id);
      if (!tx) return;
      openTransactionModal(tx.type, tx);
    },

    deleteTransaction: function(id) {
      const tx = appState.transactions.find(t => t.id === id);
      if (!tx) return;
      showConfirmDialog(
        'লেনদেন মুছে ফেলবেন?',
        `আপনি কি নিশ্চিতভাবে এই লেনদেনটি (${formatCurrency(tx.amount)}) মুছে ফেলতে চান?`,
        () => {
          appState.transactions = appState.transactions.filter(t => t.id !== id);
          saveData();
          showToast('লেনদেন মুছে ফেলা হয়েছে');
          renderDashboard();
          if (currentScreen === 'income') renderIncomeScreen();
          if (currentScreen === 'expense') renderExpenseScreen();
          if (currentScreen === 'deposit') renderDepositScreen();
        }
      );
    },

    editLoan: function(id) {
      const loan = appState.loans.find(l => l.id === id);
      if (!loan) return;
      openLoanModal(loan);
    },

    deleteLoan: function(id) {
      const loan = appState.loans.find(l => l.id === id);
      if (!loan) return;
      showConfirmDialog(
        'ঋণের রেকর্ড মুছে ফেলবেন?',
        `আপনি কি নিশ্চিতভাবে ${loan.lenderName}-এর ${formatCurrency(loan.amount)} ঋণের হিসাব মুছে ফেলতে চান?`,
        () => {
          appState.loans = appState.loans.filter(l => l.id !== id);
          saveData();
          showToast('ঋণ মুছে ফেলা হয়েছে');
          renderLoanScreen();
          renderDashboard();
        }
      );
    },

    deleteRepayment: function(id) {
      const repay = appState.loanRepayments.find(r => r.id === id);
      if (!repay) return;
      showConfirmDialog(
        'পরিশোধের রেকর্ড মুছে ফেলবেন?',
        `আপনি কি নিশ্চিতভাবে ${repay.lenderName}-এর ${formatCurrency(repay.amount)} পরিশোধের হিসাব মুছে ফেলতে চান?`,
        () => {
          appState.loanRepayments = appState.loanRepayments.filter(r => r.id !== id);
          saveData();
          showToast('পরিশোধের রেকর্ড মুছে ফেলা হয়েছে');
          renderLoanScreen();
          renderDashboard();
        }
      );
    },

    setSalaryYear: function(year) {
      activeSalaryYear = year;
      renderSalaryScreen();
    },

    openSalaryModal: openSalaryModal,

    deleteSalary: function(id) {
      const salary = appState.salaries.find(s => s.id === id);
      if (!salary) return;
      showConfirmDialog(
        'বেতনের হিসাব মুছে ফেলবেন?',
        `আপনি কি নিশ্চিতভাবে ${salary.monthName} মাসের বেতন (${formatCurrency(salary.amount)}) মুছে ফেলতে চান?`,
        () => {
          appState.salaries = appState.salaries.filter(s => s.id !== id);
          saveData();
          showToast('বেতন মুছে ফেলা হয়েছে');
          renderSalaryScreen();
        }
      );
    },

    setReportMonth: function(monthIdx) {
      reportSelectedMonth = monthIdx;
      renderReportScreen();
    }
  };

  // --- 9. EVENT LISTENERS SETUP ---
  function setupEventListeners() {
    // Drawer buttons
    document.getElementById('btn-toggle-drawer')?.addEventListener('click', openDrawer);
    backdropEl?.addEventListener('click', closeDrawer);

    // Profile Click in Header
    document.getElementById('header-profile-btn')?.addEventListener('click', () => {
      switchScreen('settings');
    });

    // Drawer menu item clicks
    document.querySelectorAll('.drawer-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const screen = btn.getAttribute('data-screen');
        switchScreen(screen);
      });
    });

    // Bottom navigation clicks
    document.querySelectorAll('.bottom-nav .nav-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const screen = btn.getAttribute('data-screen');
        switchScreen(screen);
      });
    });

    // Dashboard goto clicks
    document.querySelectorAll('[data-goto]').forEach(el => {
      el.addEventListener('click', () => {
        const screen = el.getAttribute('data-goto');
        switchScreen(screen);
      });
    });

    // Dashboard View all
    document.getElementById('dash-view-all-btn')?.addEventListener('click', () => {
      switchScreen('income');
    });

    // Quick add buttons on dashboard
    document.getElementById('quick-add-income-btn')?.addEventListener('click', () => {
      openTransactionModal('INCOME');
    });
    document.getElementById('quick-add-expense-btn')?.addEventListener('click', () => {
      openTransactionModal('EXPENSE');
    });
    document.getElementById('quick-add-deposit-btn')?.addEventListener('click', () => {
      openTransactionModal('DEPOSIT');
    });
    document.getElementById('quick-add-loan-btn')?.addEventListener('click', () => {
      openLoanModal();
    });

    // Screen specific action buttons
    document.getElementById('btn-open-add-income')?.addEventListener('click', () => openTransactionModal('INCOME'));
    document.getElementById('btn-open-add-expense')?.addEventListener('click', () => openTransactionModal('EXPENSE'));
    document.getElementById('btn-open-add-deposit')?.addEventListener('click', () => openTransactionModal('DEPOSIT'));
    document.getElementById('btn-open-add-loan')?.addEventListener('click', () => openLoanModal());
    document.getElementById('btn-open-repay-loan')?.addEventListener('click', () => openRepayModal());

    // Search and Date Filters
    document.getElementById('income-search')?.addEventListener('input', renderIncomeScreen);
    document.getElementById('income-filter-date')?.addEventListener('change', renderIncomeScreen);
    document.getElementById('income-clear-filter')?.addEventListener('click', () => {
      document.getElementById('income-search').value = '';
      document.getElementById('income-filter-date').value = '';
      renderIncomeScreen();
    });

    document.getElementById('expense-search')?.addEventListener('input', renderExpenseScreen);
    document.getElementById('expense-filter-date')?.addEventListener('change', renderExpenseScreen);
    document.getElementById('expense-clear-filter')?.addEventListener('click', () => {
      document.getElementById('expense-search').value = '';
      document.getElementById('expense-filter-date').value = '';
      renderExpenseScreen();
    });

    document.getElementById('deposit-search')?.addEventListener('input', renderDepositScreen);
    document.getElementById('deposit-filter-date')?.addEventListener('change', renderDepositScreen);
    document.getElementById('deposit-clear-filter')?.addEventListener('click', () => {
      document.getElementById('deposit-search').value = '';
      document.getElementById('deposit-filter-date').value = '';
      renderDepositScreen();
    });

    // Loan Subtabs
    document.querySelectorAll('[data-subtab]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('[data-subtab]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const target = btn.getAttribute('data-subtab');
        document.querySelectorAll('.subtab-pane').forEach(p => p.classList.remove('active'));
        document.getElementById(`subtab-${target}`)?.classList.add('active');
      });
    });

    // Salary Subtabs (মাদরাসা vs মসজিদ)
    document.querySelectorAll('[data-salary-inst]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('[data-salary-inst]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeSalaryInstitution = btn.getAttribute('data-salary-inst');
        renderSalaryScreen();
      });
    });

    // Report Subtabs
    document.querySelectorAll('[data-report-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('[data-report-tab]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const tab = btn.getAttribute('data-report-tab');
        document.querySelectorAll('.report-tab-pane').forEach(p => p.classList.remove('active'));
        document.getElementById(`report-tab-${tab}`)?.classList.add('active');
      });
    });

    document.getElementById('rep-single-date')?.addEventListener('change', renderDailyReport);

    // Settings Password Button
    document.getElementById('btn-toggle-password')?.addEventListener('click', openPasswordModal);

    // Escape Key to Close Modals & Drawer
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        closeDrawer();
        document.querySelectorAll('.app-modal-overlay').forEach(modal => {
          modal.classList.add('hidden');
        });
      }
    });
  }

  // --- 10. INITIALIZATION ---
  function init() {
    setupEventListeners();
    updateProfileAvatars();
    renderDashboard();
    checkLockStatus();

    // Set today date label
    const todayLabel = document.getElementById('dash-today-date');
    if (todayLabel) {
      todayLabel.textContent = formatBanglaDate(getTodayIso());
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
