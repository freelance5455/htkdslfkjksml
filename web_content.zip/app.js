const personas = [
  {id:"atlas",name:"Atlas",role:"المحلل",initial:"A",prompt:"أنت Atlas، شخصية تحليلية ومنظمة. تفكر بهدوء، تشرح المنطق والخطوات، ولا تتظاهر بمعرفة شيء غير متأكد منه."},
  {id:"axel",name:"Axel",role:"المساعد التنفيذي",initial:"X",prompt:"أنت Axel، مساعد تنفيذي هادئ ومحترف. كن مباشرًا، افهم الأوامر العربية والمختلطة، ونادِ المستخدم Sir عند الحاجة."},
  {id:"max",name:"Max",role:"العملي",initial:"M",prompt:"أنت Max، عملي وسريع. ركز على الحلول القابلة للتنفيذ، وقلل الكلام غير الضروري."},
  {id:"vela",name:"Vela",role:"الاجتماعية",initial:"V",prompt:"أنت Vela، شخصية اجتماعية ودودة. حافظ على حوار طبيعي، واسأل أسئلة مفيدة عندما تحتاج معلومات إضافية."},
  {id:"muhammad",name:"Muhammad",role:"المساعد المعرفي",initial:"H",prompt:"أنت Muhammad، مساعد معرفي يحافظ على الدقة. عند الحديث عن الدين، فرّق بين القرآن والحديث والرأي، ولا تنسب قولًا بلا مصدر موثوق."}
];

let state = {
  persona: localStorage.getItem("vora_persona") || "atlas",
  chats: JSON.parse(localStorage.getItem("vora_chats") || "{}"),
  memory: localStorage.getItem("vora_memory") || "",
  settings: JSON.parse(localStorage.getItem("vora_settings") || "{}")
};

const $ = s => document.querySelector(s);
const chatEl = $("#chat");

function currentPersona(){ return personas.find(p=>p.id===state.persona) || personas[0]; }
function save(){ localStorage.setItem("vora_persona",state.persona); localStorage.setItem("vora_chats",JSON.stringify(state.chats)); }
function history(){ return state.chats[state.persona] || []; }
function setHistory(h){ state.chats[state.persona]=h; save(); }

function renderPersonas(){
  $("#personas").innerHTML = personas.map(p=>`
    <button class="persona ${p.id===state.persona?'active':''}" data-id="${p.id}">
      <span class="p-avatar">${p.initial}</span>
      <span><strong>${p.name}</strong><small>${p.role}</small></span>
    </button>`).join("");
  document.querySelectorAll(".persona").forEach(b=>b.onclick=()=>switchPersona(b.dataset.id));
}

function switchPersona(id){
  state.persona=id; save(); renderPersonas(); updateTop(); renderChat();
  $("#sidebar").classList.remove("open");
}
function updateTop(){
  const p=currentPersona();
  $("#topName").textContent=p.name; $("#topRole").textContent=p.role; $("#topAvatar").textContent=p.initial;
}

function renderChat(){
  const h=history();
  if(!h.length){
    chatEl.innerHTML=$("#welcome").outerHTML;
    document.querySelectorAll(".quick button").forEach(b=>b.onclick=()=>{ $("#input").value=b.dataset.q; $("#composer").requestSubmit(); });
    return;
  }
  chatEl.innerHTML="";
  h.forEach(m=>addMessage(m.role,m.content,false));
  chatEl.scrollTop=chatEl.scrollHeight;
}

function addMessage(role,content,scroll=true){
  const p=currentPersona();
  const row=document.createElement("div");
  row.className=`message ${role}`;
  const av=document.createElement("div"); av.className="msg-avatar"; av.textContent=role==="user"?"You":p.initial;
  const bubble=document.createElement("div"); bubble.className="bubble"; bubble.textContent=content;
  row.append(av,bubble); chatEl.appendChild(row);
  if(scroll) chatEl.scrollTop=chatEl.scrollHeight;
}

function demoReply(text){
  const p=currentPersona();
  const t=text.toLowerCase();
  if(/عرّف|اسمك|مين انت/.test(t)) return `أنا ${p.name}، ${p.role} داخل VORA.\n${p.prompt.split("أنت ")[1] || "أساعدك في المحادثة والمهام اليومية."}`;
  if(/تستطيع|تقدر|ماذا تعمل/.test(t)) return `أقدر أساعدك في التفكير، تنظيم الأفكار، شرح المعلومات، كتابة النصوص، وتحويل طلبك إلى خطوات عملية.\n\nحالياً أنا في الوضع التجريبي؛ من الإعدادات يمكنك ربط API حقيقي.`;
  if(/يوم|تنظيم|جدول/.test(t)) return `لننظم اليوم ببساطة:\n1) حدد أهم مهمة.\n2) اقسمها إلى خطوات صغيرة.\n3) خصص وقتاً للراحة.\n4) في نهاية اليوم راجع ما تم إنجازه.`;
  if(/ذاكرة|تذكر/.test(t)) return state.memory ? `لدي هذه الذاكرة المحلية:\n${state.memory}` : "لا توجد ذاكرة محفوظة حالياً. يمكنك إضافتها من زر «الذاكرة».";
  return `فهمت رسالتك: «${text}»\n\nأنا ${p.name} في الوضع التجريبي. لردود AI حقيقية، فعّل استخدام الـAPI من الإعدادات وأدخل Endpoint وModel والمفتاح.`;
}

async function callAI(text){
  const s=state.settings;
  if(!s.useAI || !s.endpoint) return demoReply(text);
  const messages=[
    {role:"system",content:`${currentPersona().prompt}\n\nالذاكرة المحلية للمستخدم:\n${state.memory || "لا توجد ذاكرة."}`},
    ...history().slice(-16).map(x=>({role:x.role==="assistant"?"assistant":"user",content:x.content})),
    {role:"user",content:text}
  ];
  const headers={"Content-Type":"application/json"};
  if(s.apiKey) headers.Authorization=`Bearer ${s.apiKey}`;
  const res=await fetch(s.endpoint,{method:"POST",headers,body:JSON.stringify({model:s.model||"default",messages,temperature:.7})});
  if(!res.ok) throw new Error(`API Error ${res.status}`);
  const data=await res.json();
  return data.choices?.[0]?.message?.content || data.output_text || "لم يصل رد مفهوم من الـAPI.";
}

async function sendMessage(text){
  const clean=text.trim(); if(!clean)return;
  const h=history(); h.push({role:"user",content:clean}); setHistory(h);
  renderChat();
  addMessage("assistant","جاري التفكير...",true);
  const last=chatEl.lastElementChild.querySelector(".bubble"); last.classList.add("typing");
  try{
    const answer=await callAI(clean);
    last.textContent=answer; last.classList.remove("typing");
    h.push({role:"assistant",content:answer}); setHistory(h);
  }catch(e){
    last.textContent=`حدث خطأ في الاتصال بالـAPI.\n${e.message}\n\nيمكنك تعطيل وضع الـAPI والعودة للوضع التجريبي.`;
    last.classList.remove("typing");
    h.push({role:"assistant",content:last.textContent}); setHistory(h);
  }
  chatEl.scrollTop=chatEl.scrollHeight;
}

$("#composer").addEventListener("submit",e=>{e.preventDefault(); const i=$("#input"); const t=i.value; i.value=""; i.style.height="auto"; sendMessage(t);});
$("#input").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("#composer").requestSubmit();}});
$("#input").addEventListener("input",e=>{e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,150)+"px";});

$("#newChat").onclick=()=>{setHistory([]);renderChat();};
$("#clearBtn").onclick=()=>{if(confirm("مسح المحادثة الحالية؟")){setHistory([]);renderChat();}};
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");

function openModal(id){$(id).classList.remove("hidden")}
function closeModals(){document.querySelectorAll(".modal").forEach(m=>m.classList.add("hidden"))}
document.querySelectorAll("[data-close]").forEach(x=>x.onclick=closeModals);
$("#settingsBtn").onclick=()=>{
  $("#endpoint").value=state.settings.endpoint||"";
  $("#apiKey").value=state.settings.apiKey||"";
  $("#model").value=state.settings.model||"";
  $("#useAI").checked=!!state.settings.useAI; openModal("#settingsModal");
};
$("#saveSettings").onclick=()=>{
  state.settings={endpoint:$("#endpoint").value.trim(),apiKey:$("#apiKey").value.trim(),model:$("#model").value.trim(),useAI:$("#useAI").checked};
  localStorage.setItem("vora_settings",JSON.stringify(state.settings)); closeModals();
};
$("#memoryBtn").onclick=()=>{$("#memoryText").value=state.memory;openModal("#memoryModal")};
$("#saveMemory").onclick=()=>{state.memory=$("#memoryText").value;localStorage.setItem("vora_memory",state.memory);closeModals()};
$("#eraseMemory").onclick=()=>{state.memory="";localStorage.removeItem("vora_memory");$("#memoryText").value=""};

renderPersonas(); updateTop(); renderChat();
