const CHANNELS=[{name:"MrRoanInc",type:"Telegram",url:"https://t.me/MrRoanInc"},{name:"no_name_teech",type:"Telegram",url:"https://t.me/no_name_teech"},{name:"digitale_empire",type:"Telegram",url:"https://t.me/digitale_empire"},{name:"Chaîne WhatsApp DK7",type:"WhatsApp Channel",url:"https://whatsapp.com/channel/0029VbDsfDvKWEL0VT5hBu2C"},{name:"Groupe WhatsApp",type:"WhatsApp Group",url:"https://chat.whatsapp.com/BeSz9RNgCjcH5CVhZu830J?s=cl&p=a&mlu=4&ilr=4"}];
const cover="./assets/yackuza-cover.jpg",grid=document.querySelector("#channels");
grid.innerHTML=CHANNELS.map((c,i)=>`<article class="channel"><div class="channel-bg" style="background-image:url('${cover}')"></div><div class="channel-body"><div class="channel-name">${c.name}</div><div class="channel-type">${c.type}</div><button class="openlink" data-i="${i}">OUVRIR</button></div></article>`).join("");
grid.onclick=e=>{const b=e.target.closest("[data-i]");if(b)window.open(CHANNELS[+b.dataset.i].url,"_blank","noopener,noreferrer")};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#"+b.dataset.tab).classList.add("active")});
$("#boost").onclick=()=>{document.body.classList.toggle("boost");$("#boost").classList.toggle("on");$("#mode").textContent=document.body.classList.contains("boost")?"MODE BOOST":"MODE STANDARD"};

const KEY="yackuza_templates_v2";
let templates=JSON.parse(localStorage.getItem(KEY)||"[]"),selected="";
function save(){localStorage.setItem(KEY,JSON.stringify(templates))}
function renderTemplates(){
 $("#templates").innerHTML=templates.length?templates.map((t,i)=>`<div class="template"><div><strong>${esc(t.name)}</strong><small>${t.text.length} caractères</small></div><div><button data-load="${i}">CHARGER</button> <button data-del="${i}">×</button></div></div>`).join(""):`<div class="help">Aucun modèle. Commence par écrire ton propre message ci-dessus.</div>`;
 $("#templateSelect").innerHTML=`<option value="">— Choisir un modèle —</option>`+templates.map((t,i)=>`<option value="${i}">${esc(t.name)}</option>`).join("");
 if(selected!=="")$("#templateSelect").value=selected;
}
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
renderTemplates();
$("#saveTemplate").onclick=()=>{const name=$("#templateName").value.trim()||`Message ${templates.length+1}`,text=$("#templateText").value.trim();if(!text){alert("Écris ton message avant d'enregistrer.");return}templates.push({name,text});selected=String(templates.length-1);save();renderTemplates();$("#templateName").value="";$("#templateText").value=""};
$("#clearTemplate").onclick=()=>{$("#templateName").value="";$("#templateText").value="";selected="";renderTemplates()};
$("#templates").onclick=e=>{const load=e.target.closest("[data-load]"),del=e.target.closest("[data-del]");if(load){const t=templates[+load.dataset.load];selected=load.dataset.load;$("#templateName").value=t.name;$("#templateText").value=t.text;renderTemplates()}if(del){templates.splice(+del.dataset.del,1);selected="";save();renderTemplates()}};
$("#templateSelect").onchange=e=>selected=e.target.value;
$("#generate").onclick=()=>{if(selected===""){alert("Choisis d'abord un de tes messages.");return}const t=templates[+selected];let out=t.text;const num=$("#target").value.trim(),rep=$("#replacement").value.trim();out=out.replaceAll("{{numero}}",num||"{{numero}}").replaceAll("{{valeur}}",rep||"{{valeur}}");localStorage.setItem("lastOutput",out);$("#output").textContent=out};
$("#copy").onclick=async()=>{const t=$("#output").textContent;if(t==="Aucun message généré.")return;try{await navigator.clipboard.writeText(t);$("#copy").textContent="COPIÉ ✓";setTimeout(()=>$("#copy").textContent="COPIER",1000)}catch{}};

const DB="yackuza_media_v2";
function db(){return new Promise((ok,no)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore("files");r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})}
async function put(k,v){const d=await db();return new Promise((ok,no)=>{const t=d.transaction("files","readwrite");t.objectStore("files").put(v,k);t.oncomplete=ok;t.onerror=()=>no(t.error)})}
async function get(k){const d=await db();return new Promise((ok,no)=>{const r=d.transaction("files").objectStore("files").get(k);r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})}
async function del(k){const d=await db();d.transaction("files","readwrite").objectStore("files").delete(k)}
function applyBg(f){if(!f)return;const u=URL.createObjectURL(f);document.body.style.backgroundImage=`linear-gradient(#0008,#000b),url("${u}")`}
$("#bgFile").onchange=async e=>{const f=e.target.files[0];if(f){await put("bg",f);applyBg(f)}};
$("#resetBg").onclick=async()=>{await del("bg");document.body.style.backgroundImage=""};
$("#audioFile").onchange=async e=>{const f=e.target.files[0];if(f){await put("audio",f);$("#audioName").textContent=f.name;$("#audio").src=URL.createObjectURL(f)}};
$("#play").onclick=()=>$("#audio").play().catch(()=>{});
$("#stop").onclick=()=>{$("#audio").pause();$("#audio").currentTime=0};
(async()=>{try{const bg=await get("bg"),audio=await get("audio");if(bg)applyBg(bg);if(audio){$("#audio").src=URL.createObjectURL(audio);$("#audioName").textContent=audio.name||"Musique enregistrée"}}catch{}})();

function addBubble(text,who){const d=document.createElement("div");d.className=`bubble ${who}`;d.textContent=text;$("#chat").appendChild(d);$("#chat").scrollTop=$("#chat").scrollHeight}
async function ask(){
 const msg=$("#chatInput").value.trim();if(!msg)return;addBubble(msg,"user");$("#chatInput").value="";$("#send").disabled=true;
 try{const r=await fetch("/.netlify/functions/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:msg})});const data=await r.json();if(!r.ok)throw Error(data.error||"Erreur");addBubble(data.reply||"Réponse vide.","ai");$("#apiState").textContent="IA CONNECTÉE"}catch(e){addBubble("L'IA distante n'est pas encore configurée. Ajoute OPENAI_API_KEY dans les variables d'environnement Netlify.","ai")}finally{$("#send").disabled=false}
}
$("#send").onclick=ask;$("#chatInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();ask()}});
$("#lock").onclick=()=>{sessionStorage.removeItem("openedChannels");location.reload()};

document.querySelectorAll("[data-jump]").forEach(b=>b.onclick=()=>{const id=b.dataset.jump;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===id));document.querySelectorAll(".screen").forEach(x=>x.classList.toggle("active",x.id===id))});
const LOGKEY="yackuza_activity_v5";let logs=JSON.parse(localStorage.getItem(LOGKEY)||"[]");function logActivity(a,d){logs.unshift({a,d,t:new Date().toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"})});logs=logs.slice(0,30);localStorage.setItem(LOGKEY,JSON.stringify(logs));renderLog()}function renderLog(){const e=document.querySelector("#activityLog");if(e)e.innerHTML=logs.length?logs.map(x=>`<div class="log-item"><b>${x.a}</b><span>${x.d}</span><time>${x.t}</time></div>`).join(""):"<div class=\"micro\">Aucune activité.</div>"}renderLog();
document.querySelector("#exportTemplates")?.addEventListener("click",()=>{const t=JSON.parse(localStorage.getItem("yackuza_templates_v2")||"[]"),a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(t,null,2)],{type:"application/json"}));a.download="yackuza-templates.json";a.click();logActivity("Export","Modèles JSON")});
document.querySelector("#importTemplates")?.addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const t=JSON.parse(r.result);if(!Array.isArray(t))throw 0;localStorage.setItem("yackuza_templates_v2",JSON.stringify(t));location.reload()}catch{alert("JSON invalide")}};r.readAsText(f)});
document.querySelector("#copyLast")?.addEventListener("click",async()=>{const t=localStorage.getItem("lastOutput");if(!t)return alert("Aucun résultat.");try{await navigator.clipboard.writeText(t);logActivity("Copie","Dernier résultat")}catch{}});
document.querySelector("#wipeTemplates")?.addEventListener("click",()=>{if(confirm("Effacer les modèles ?")){localStorage.removeItem("yackuza_templates_v2");location.reload()}});document.querySelector("#clearLog")?.addEventListener("click",()=>{logs=[];localStorage.setItem(LOGKEY,"[]");renderLog()});
