const audio = document.getElementById('audio');
const filesInput = document.getElementById('audioFiles');
const trackList = document.getElementById('trackList');
const playBtn = document.getElementById('playBtn');
const seek = document.getElementById('seek');
const currentTimeEl = document.getElementById('currentTime');
const durationEl = document.getElementById('duration');
const nowTitle = document.getElementById('nowTitle');
const nowSub = document.getElementById('nowSub');
const toast = document.getElementById('toast');
let tracks = [];
let currentIndex = -1;
let db;
function showToast(msg){toast.textContent=msg;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2600)}
function fmt(t){if(!Number.isFinite(t))return '00:00';const m=Math.floor(t/60),s=Math.floor(t%60);return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')}
function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open('TorathAudioDB',1);req.onupgradeneeded=()=>req.result.createObjectStore('tracks',{keyPath:'id',autoIncrement:true});req.onsuccess=()=>{db=req.result;resolve(db)};req.onerror=()=>reject(req.error)})}
function txStore(mode='readonly'){return db.transaction('tracks',mode).objectStore('tracks')}
async function loadTracks(){await openDB();return new Promise((resolve,reject)=>{const r=txStore().getAll();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error)})}
function saveTrack(file){return new Promise((resolve,reject)=>{const r=txStore('readwrite').add({name:file.name,blob:file,added:Date.now()});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
function deleteTrack(id){return new Promise((resolve,reject)=>{const r=txStore('readwrite').delete(id);r.onsuccess=resolve;r.onerror=()=>reject(r.error)})}
function renderTracks(){document.getElementById('trackCount').textContent=tracks.length+' تلاوة';if(!tracks.length){trackList.innerHTML='<div class="empty-state">مكتبتك لسه فاضية<br><small>ابدأ بإضافة أول تلاوة</small></div>';return}trackList.innerHTML='';tracks.forEach((t,i)=>{const row=document.createElement('div');row.className='track';row.innerHTML=`<div class="track-art">♫</div><div class="track-details"><b></b><small>محفوظة على جهازك · تشغيل بدون إنترنت</small></div><button class="track-play" aria-label="تشغيل">▶</button><button class="track-remove" aria-label="حذف">×</button>`;row.querySelector('b').textContent=t.name;row.querySelector('.track-play').onclick=()=>playTrack(i);row.querySelector('.track-remove').onclick=async()=>{if(currentIndex===i){audio.pause();audio.removeAttribute('src');currentIndex=-1;playBtn.textContent='▶'}await deleteTrack(t.id);tracks=await loadTracks();renderTracks();showToast('تم حذف التلاوة من المكتبة')};trackList.appendChild(row)})}
async function playTrack(i){if(i<0||i>=tracks.length)return;currentIndex=i;const t=tracks[i];audio.src=URL.createObjectURL(t.blob);audio.load();nowTitle.textContent=t.name;nowSub.textContent='تلاوة محفوظة على جهازك';playBtn.textContent='Ⅱ';audio.play().then(()=>{}).catch(()=>{playBtn.textContent='▶';showToast('اضغط تشغيل لبدء التلاوة')});document.querySelectorAll('.track-play').forEach((b,j)=>b.textContent=j===i?'Ⅱ':'▶')}
filesInput.addEventListener('change',async e=>{const chosen=Array.from(e.target.files||[]);if(!chosen.length)return;try{for(const f of chosen){if(f.type.startsWith('audio/'))await saveTrack(f)}tracks=await loadTracks();renderTracks();showToast('تمت إضافة التلاوات وحفظها على الجهاز');}catch(err){showToast('تعذّر حفظ الملفات. جرّب ملفًا أصغر أو مساحة تخزين أخرى.')}filesInput.value=''});
playBtn.onclick=()=>{if(!audio.src){if(tracks.length)playTrack(0);else showToast('أضف تلاوة من مكتبتك أولًا');return}if(audio.paused){audio.play();playBtn.textContent='Ⅱ'}else{audio.pause();playBtn.textContent='▶'}};
document.getElementById('backBtn').onclick=()=>{audio.currentTime=Math.max(0,audio.currentTime-10)};
document.getElementById('forwardBtn').onclick=()=>{audio.currentTime=Math.min(audio.duration||0,audio.currentTime+10)};
audio.addEventListener('timeupdate',()=>{currentTimeEl.textContent=fmt(audio.currentTime);durationEl.textContent=fmt(audio.duration);seek.value=audio.duration?audio.currentTime/audio.duration*100:0});
audio.addEventListener('ended',()=>{playBtn.textContent='▶';if(currentIndex+1<tracks.length)playTrack(currentIndex+1)});
seek.addEventListener('input',()=>{if(audio.duration)audio.currentTime=(Number(seek.value)/100)*audio.duration});
document.querySelectorAll('[data-scroll]').forEach(b=>b.addEventListener('click',()=>{const id=b.dataset.scroll;if(id==='top'){window.scrollTo({top:0,behavior:'smooth'});return}document.getElementById(id)?.scrollIntoView({behavior:'smooth',block:'start'});document.querySelectorAll('.nav-item').forEach(n=>n.classList.toggle('active',n.dataset.scroll===id))}));
document.getElementById('searchBtn').onclick=()=>showToast('يمكنك إضافة البحث في مرحلة لاحقة');
document.getElementById('menuBtn').onclick=()=>showToast('تراث Torath · الإصدار التجريبي الأول');
(async()=>{try{tracks=await loadTracks();renderTracks()}catch(e){showToast('التخزين المحلي غير متاح في هذا المتصفح')}})();
if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}

const memorialSplash = document.getElementById('memorialSplash');
document.getElementById('enterApp')?.addEventListener('click',()=>{
  memorialSplash.classList.add('hidden');
  try{sessionStorage.setItem('torathSplashSeen','1')}catch(e){}
});
try{if(sessionStorage.getItem('torathSplashSeen')==='1')memorialSplash?.classList.add('hidden')}catch(e){}
