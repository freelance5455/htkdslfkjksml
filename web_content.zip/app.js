const systems = [
 {name:"PlayStation Portable",short:"PSP",brand:"Sony",icon:"◈",desc:"La portátil legendaria. Para abrir PPSSPP, instálalo y carga desde él un archivo de juego compatible.",packages:["org.ppsspp.ppsspp","org.ppsspp.ppssppgold"],color:"#a18aff",tint:"rgba(161,138,255,.2)"},
 {name:"PlayStation 1",short:"PS1",brand:"Sony",icon:"◉",desc:"La era de los clásicos 3D y los discos plateados.",packages:["com.github.stenzek.duckstation"],color:"#70f3ff",tint:"rgba(112,243,255,.16)"},
 {name:"PlayStation 2",short:"PS2",brand:"Sony",icon:"✦",desc:"Una de las bibliotecas más queridas de la historia gaming.",packages:["xyz.aethersx2.android","com.aethersx2.android"],color:"#8ba8ff",tint:"rgba(139,168,255,.18)"},
 {name:"PlayStation 3",short:"PS3",brand:"Sony",icon:"▣",desc:"Sistema avanzado; la emulación no suele ser práctica en móviles Android.",packages:["net.rpcs3"],color:"#b3a0ff",tint:"rgba(179,160,255,.17)"},
 {name:"Nintendo Entertainment System",short:"NES",brand:"Nintendo",icon:"▤",desc:"8 bits, aventuras clásicas y el nacimiento de muchas sagas.",packages:["com.retroarch"],color:"#ff777f",tint:"rgba(255,119,127,.15)"},
 {name:"Super Nintendo",short:"SNES",brand:"Nintendo",icon:"▥",desc:"La edad dorada de los 16 bits.",packages:["com.retroarch"],color:"#c7a4ff",tint:"rgba(199,164,255,.16)"},
 {name:"Game Boy / Color",short:"GB / GBC",brand:"Nintendo",icon:"▣",desc:"La portátil clásica para jugar en cualquier sitio.",packages:["com.retroarch"],color:"#9bf6a5",tint:"rgba(155,246,165,.14)"},
 {name:"Game Boy Advance",short:"GBA",brand:"Nintendo",icon:"▧",desc:"Una portátil de 32 bits con grandes aventuras.",packages:["com.retroarch"],color:"#70f3ff",tint:"rgba(112,243,255,.15)"},
 {name:"Nintendo DS",short:"NDS",brand:"Nintendo",icon:"▦",desc:"Dos pantallas y una forma diferente de jugar.",packages:["me.magnum.melonds","com.dsemu.drastic"],color:"#ffb0d9",tint:"rgba(255,176,217,.15)"},
 {name:"Nintendo 3DS",short:"3DS",brand:"Nintendo",icon:"◇",desc:"La portátil de Nintendo con efecto 3D.",packages:["org.lime3ds.android"],color:"#ffbd76",tint:"rgba(255,189,118,.15)"},
 {name:"Nintendo 64",short:"N64",brand:"Nintendo",icon:"◍",desc:"La revolución del 3D en los salones de casa.",packages:["com.retroarch"],color:"#ff9f8c",tint:"rgba(255,159,140,.15)"},
 {name:"GameCube",short:"GC",brand:"Nintendo",icon:"⬡",desc:"Una pequeña consola con una gran personalidad.",packages:["org.dolphinemu.dolphinemu"],color:"#8fa7ff",tint:"rgba(143,167,255,.16)"},
 {name:"Nintendo Wii",short:"Wii",brand:"Nintendo",icon:"◎",desc:"Movimiento, familia y juegos para compartir.",packages:["org.dolphinemu.dolphinemu"],color:"#b5d5ff",tint:"rgba(181,213,255,.15)"},
 {name:"Sega Master System",short:"SMS",brand:"SEGA",icon:"▤",desc:"Una pieza importante de la historia de SEGA.",packages:["com.retroarch"],color:"#70f3ff",tint:"rgba(112,243,255,.15)"},
 {name:"Sega Mega Drive",short:"GENESIS",brand:"SEGA",icon:"◆",desc:"La era de los 16 bits y la velocidad arcade.",packages:["com.retroarch"],color:"#ff7c8e",tint:"rgba(255,124,142,.15)"},
 {name:"Sega Saturn",short:"SATURN",brand:"SEGA",icon:"◈",desc:"Una consola de culto para los amantes del retro.",packages:["com.retroarch"],color:"#c0a2ff",tint:"rgba(192,162,255,.15)"},
 {name:"Sega Dreamcast",short:"DC",brand:"SEGA",icon:"✧",desc:"La última consola doméstica de SEGA, adelantada a su tiempo.",packages:["com.retroarch"],color:"#ffce7b",tint:"rgba(255,206,123,.15)"},
 {name:"Arcade / MAME",short:"ARCADE",brand:"Arcade",icon:"👾",desc:"La esencia de las recreativas clásicas.",packages:["com.retroarch","com.seleuco.mame4droid"],color:"#ff8ce0",tint:"rgba(255,140,224,.15)"},
 {name:"Neo Geo",short:"NEO GEO",brand:"Retro",icon:"✹",desc:"Acción arcade, lucha y píxeles de lujo.",packages:["com.retroarch"],color:"#ff987b",tint:"rgba(255,152,123,.15)"},
 {name:"Atari 2600",short:"ATARI",brand:"Retro",icon:"▰",desc:"Los primeros días del videojuego doméstico.",packages:["com.retroarch"],color:"#ffda78",tint:"rgba(255,218,120,.15)"},
 {name:"PC Engine",short:"PCE",brand:"Retro",icon:"▱",desc:"Una consola compacta con una gran colección retro.",packages:["com.retroarch"],color:"#d0a6ff",tint:"rgba(208,166,255,.15)"},
 {name:"MSX",short:"MSX",brand:"Retro",icon:"▦",desc:"La cultura de los microordenadores clásicos.",packages:["com.retroarch"],color:"#91f2be",tint:"rgba(145,242,190,.15)"},
 {name:"Commodore 64",short:"C64",brand:"Retro",icon:"▧",desc:"Un icono de los ordenadores domésticos.",packages:["com.retroarch"],color:"#a0b6ff",tint:"rgba(160,182,255,.15)"},
 {name:"RetroArch Multi-System",short:"MULTI",brand:"Retro",icon:"∞",desc:"Un frontend multidispositivo para sistemas compatibles.",packages:["com.retroarch"],color:"#70f3ff",tint:"rgba(112,243,255,.15)"},
 {name:"WonderSwan",short:"WS",brand:"Retro",icon:"▣",desc:"Una portátil poco común para coleccionistas retro.",packages:["com.retroarch"],color:"#ffa6d9",tint:"rgba(255,166,217,.15)"},
 {name:"Atari Lynx",short:"LYNX",brand:"Retro",icon:"▰",desc:"Una portátil clásica de Atari.",packages:["com.retroarch"],color:"#ffbd76",tint:"rgba(255,189,118,.15)"},
 {name:"Virtual Boy",short:"VB",brand:"Nintendo",icon:"◉",desc:"Uno de los experimentos más peculiares de Nintendo.",packages:["com.retroarch"],color:"#ff777f",tint:"rgba(255,119,127,.15)"},
 {name:"PlayStation Vita",short:"PS VITA",brand:"Sony",icon:"◇",desc:"Portátil de Sony; la compatibilidad de emulación Android es limitada.",packages:["org.vita3k.emulator"],color:"#a18aff",tint:"rgba(161,138,255,.18)"},
 {name:"Xbox",short:"XBOX",brand:"Xbox",icon:"✕",desc:"Emulación en Android limitada y dependiente del dispositivo.",packages:["com.retroarch"],color:"#8df7a7",tint:"rgba(141,247,167,.15)"},
 {name:"Xbox 360",short:"360",brand:"Xbox",icon:"◉",desc:"Sistema exigente; no hay garantía de emulación en el móvil.",packages:[],color:"#9cf6b3",tint:"rgba(156,246,179,.15)"},
 {name:"Juegos musicales",short:"RHYTHM",brand:"Arcade",icon:"♫",desc:"Accesos para tus juegos de ritmo favoritos instalados.",packages:[],color:"#ff8fe0",tint:"rgba(255,143,224,.15)"},
 {name:"Juegos de lucha",short:"FIGHT",brand:"Arcade",icon:"✦",desc:"Tu rincón para juegos de lucha que ya tengas instalados.",packages:[],color:"#ff987b",tint:"rgba(255,152,123,.15)"}
];
const grid=document.querySelector("#systemGrid"), search=document.querySelector("#searchInput"), count=document.querySelector("#resultCount"), empty=document.querySelector("#emptyState"), toastEl=document.querySelector("#toast");
let activeFilter="Todos", selected=null, toastTimer;
const favorites=new Set(JSON.parse(localStorage.getItem("aura-favorites")||"[]"));
function toast(msg){toastEl.textContent=msg;toastEl.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>toastEl.classList.remove("show"),3000)}
function saveFav(){localStorage.setItem("aura-favorites",JSON.stringify([...favorites]))}
function render(){
 const q=search.value.trim().toLocaleLowerCase("es");
 const items=systems.filter(s=>{
  const text=(s.name+" "+s.short+" "+s.brand+" "+s.desc).toLocaleLowerCase("es");
  return text.includes(q) && (activeFilter==="Todos" || (activeFilter==="Favoritos"?favorites.has(s.name):s.brand===activeFilter));
 });
 grid.innerHTML="";count.textContent=items.length;empty.classList.toggle("hidden",items.length!==0);
 items.forEach(s=>{
  const card=document.createElement("article");card.className="system-card";card.style.setProperty("--card-accent",s.color);card.style.setProperty("--tint",s.tint);
  card.innerHTML=`<div class="card-top"><div class="system-icon">${s.icon}</div><button class="favorite ${favorites.has(s.name)?"on":""}" aria-label="Guardar favorito" title="Favorito">${favorites.has(s.name)?"★":"☆"}</button></div><h3>${s.name}</h3><p>${s.short} · ${s.brand}</p><div class="card-footer"><span>VER SISTEMA</span><span>↗</span></div>`;
  card.addEventListener("click",()=>openDetail(s));
  card.querySelector(".favorite").addEventListener("click",e=>{e.stopPropagation();favorites.has(s.name)?favorites.delete(s.name):favorites.add(s.name);saveFav();render();toast(favorites.has(s.name)?"Añadido a favoritos":"Eliminado de favoritos")});
  grid.appendChild(card);
 });
}
function setFilter(f){activeFilter=f;document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b.dataset.filter===f));render()}
document.querySelectorAll(".filter").forEach(b=>b.addEventListener("click",()=>setFilter(b.dataset.filter)));
search.addEventListener("input",render);
document.addEventListener("keydown",e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();search.focus()}if(e.key==="Escape")document.querySelector("#detailDialog").close?.()});
function openDetail(s){
 selected=s;document.querySelector("#dialogIcon").textContent=s.icon;document.querySelector("#dialogIcon").style.color=s.color;
 document.querySelector("#dialogBrand").textContent=s.brand+" / "+s.short;
 document.querySelector("#dialogName").textContent=s.name;
 document.querySelector("#dialogDesc").textContent=s.desc;
 document.querySelector("#dialogFavorite").textContent=favorites.has(s.name)?"★ GUARDADO":"☆ GUARDAR FAVORITO";
 const dlg=document.querySelector("#detailDialog");if(dlg.showModal)dlg.showModal();else launch(s);
}
function launch(s){
 if(!s.packages.length){toast("No hay una aplicación configurada para abrir este sistema. Instala un emulador compatible.");return}
 toast("Buscando una aplicación instalada para "+s.name+"…");
 // Web pages cannot launch arbitrary apps reliably. Use Android intent URI only inside Android Chrome.
 const pkg=s.packages[0];
 const intentUrl="intent://launch/#Intent;scheme=aura;package="+pkg+";end";
 if(/Android/i.test(navigator.userAgent)){
   location.href=intentUrl;
   setTimeout(()=>toast("Si no se abre, instala el emulador compatible y ábrelo desde el móvil."),1200);
 } else {
   toast("Para abrir el emulador, abre esta web en tu móvil Android con la aplicación compatible instalada.");
 }
}
document.querySelector("#dialogLaunch").addEventListener("click",()=>{if(selected)launch(selected)});
document.querySelector("#dialogFavorite").addEventListener("click",()=>{if(!selected)return;favorites.has(selected.name)?favorites.delete(selected.name):favorites.add(selected.name);saveFav();document.querySelector("#dialogFavorite").textContent=favorites.has(selected.name)?"★ GUARDADO":"☆ GUARDAR FAVORITO";render();toast("Favoritos guardados en este navegador")});
document.querySelector("#dialogClose").addEventListener("click",()=>document.querySelector("#detailDialog").close());
document.querySelector("#openPsp").addEventListener("click",()=>launch(systems[0]));
document.querySelector("#openSpotify").addEventListener("click",()=>{
 if(/Android|iPhone|iPad/i.test(navigator.userAgent)){location.href="spotify://";setTimeout(()=>toast("Si Spotify no se abre, comprueba que esté instalado."),900)}
 else toast("Instala Spotify en tu dispositivo para abrir la aplicación directamente.");
});
const picker=document.querySelector("#filePicker");
function pickFiles(){picker.click()}
document.querySelector("#chooseFiles").addEventListener("click",pickFiles);
document.querySelector("#addFileBtn").addEventListener("click",pickFiles);
document.querySelector("#libraryBrowse").addEventListener("click",pickFiles);
picker.addEventListener("change",()=>{
 const files=[...picker.files];if(!files.length)return;
 document.querySelector("#selectedFileName").textContent=files.length+" ARCHIVO(S) SELECCIONADO(S)";
 const holder=document.querySelector("#fileList");holder.innerHTML="";
 files.forEach(f=>{const chip=document.createElement("span");chip.className="file-chip";chip.textContent="▤ "+f.name;holder.appendChild(chip)});
 toast("Archivos seleccionados localmente. No se han subido.");
});
document.querySelector("#randomBtn").addEventListener("click",()=>{const s=systems[Math.floor(Math.random()*systems.length)];openDetail(s)});
document.querySelector("#themeBtn").addEventListener("click",()=>{document.body.classList.toggle("luminous");toast(document.body.classList.contains("luminous")?"Aura luminosa activada":"Aura estándar activada")});
document.querySelector("#aboutBtn").addEventListener("click",()=>alert("AURA INFINITA es un lanzador web gratuito. No contiene juegos ni emuladores. Los accesos directos dependen de las aplicaciones instaladas y de las limitaciones del navegador."));
render();
