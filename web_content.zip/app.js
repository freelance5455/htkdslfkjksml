
// ===============================
// V5 APP
// ===============================

const modal = document.getElementById("modal");
const closeModal = document.getElementById("closeModal");
const saveBtn = document.getElementById("saveBtn");

const titleInput = document.getElementById("titleInput");
const categoryInput = document.getElementById("categoryInput");
const detailsInput = document.getElementById("detailsInput");
const tagsInput = document.getElementById("tagsInput");

const fileList = document.getElementById("fileList");
const totalCount = document.getElementById("totalCount");
const documentCount = document.getElementById("documentCount");
const photoCount = document.getElementById("photoCount");
const otherCount = document.getElementById("otherCount");
const fileCount = document.getElementById("fileCount");
const searchInput = document.getElementById("searchInput");


// ===============================
// DETAILS MODAL
// ===============================

const detailsModal = document.getElementById("detailsModal");
const closeDetails = document.getElementById("closeDetails");

const viewTitle = document.getElementById("viewTitle");
const viewCategory = document.getElementById("viewCategory");
const viewDetails = document.getElementById("viewDetails");
const viewTags = document.getElementById("viewTags");
const viewDate = document.getElementById("viewDate");
const viewUpdated = document.getElementById("viewUpdated");

const editFileBtn = document.getElementById("editFileBtn");
const deleteFileBtn = document.getElementById("deleteFileBtn");


// ===============================
// DATA
// ===============================

let files = JSON.parse(localStorage.getItem("v5Files")) || [];

let selectedFileId = null;
let editingFileId = null;
let selectedCategory = "All";


// ===============================
// OPEN ADD
// ===============================

function openAddModal() {
    editingFileId = null;

    titleInput.value = "";
    categoryInput.value = "Documents";
    detailsInput.value = "";
    tagsInput.value = "";

    modal.classList.remove("hidden");
}


// ===============================
// CLOSE ADD
// ===============================

if (closeModal) {
    closeModal.addEventListener("click", function () {
        modal.classList.add("hidden");
    });
}


// ===============================
// SAVE
// ===============================

if (saveBtn) {
    saveBtn.addEventListener("click", function () {
        const title = titleInput.value.trim();
        const category = categoryInput.value;
        const details = detailsInput.value.trim();
        const tags = tagsInput.value.trim();

        if (title === "") {
            alert("Please enter a title.");
            titleInput.focus();
            return;
        }

        // EDIT EXISTING FILE
        if (editingFileId !== null) {
            const index = files.findIndex(function (file) {
                return file.id === editingFileId;
            });

            if (index !== -1) {
                files[index].title = title;
                files[index].category = category;
                files[index].details = details;
                files[index].tags = tags;
                files[index].updatedAt = new Date().toLocaleString();
            }

            editingFileId = null;
        } 
        // ADD NEW FILE
        else {
            const newFile = {
                id: Date.now(),
                title: title,
                category: category,
                details: details,
                tags: tags,
                createdAt: new Date().toLocaleString(),
                updatedAt: ""
            };

            files.unshift(newFile);
        }

        // SAVE
        localStorage.setItem("v5Files", JSON.stringify(files));

        // CLEAR FORM
        titleInput.value = "";
        categoryInput.value = "Documents";
        detailsInput.value = "";
        tagsInput.value = "";

        // CLOSE
        modal.classList.add("hidden");

        // REFRESH
        displayFiles();
    });
}


// ===============================
// DISPLAY FILES
// ===============================

function displayFiles() {
    const search = searchInput ? searchInput.value.toLowerCase().trim() : "";

    if (totalCount) totalCount.textContent = files.length;

    if (documentCount) {
        documentCount.textContent = files.filter(function (file) {
            return file.category === "Documents";
        }).length;
    }

    if (photoCount) {
        photoCount.textContent = files.filter(function (file) {
            return file.category === "Photos";
        }).length;
    }

    if (otherCount) {
        otherCount.textContent = files.filter(function (file) {
            return file.category === "Others";
        }).length;
    }

    const filtered = files.filter(function (file) {
        const categoryMatch =
            selectedCategory === "All" ||
            file.category === selectedCategory;

        const searchMatch =
            file.title.toLowerCase().includes(search) ||
            file.details.toLowerCase().includes(search) ||
            file.tags.toLowerCase().includes(search);

        return categoryMatch && searchMatch;
    });

    if (fileCount) fileCount.textContent = filtered.length;

    if (!fileList) return;

    if (filtered.length === 0) {
        fileList.innerHTML = `
            <div class="empty">
                <div class="empty-icon">📁</div>
                <h3>No files yet</h3>
                <p>Tap + to add your first file or detail.</p>
            </div>
        `;
        return;
    }

    fileList.innerHTML = "";

    filtered.forEach(function (file) {
        let icon = "📦";

        if (file.category === "Documents") {
            icon = "📄";
        }

        if (file.category === "Photos") {
            icon = "🖼️";
        }

        const card = document.createElement("div");
        card.className = "file-card";

        card.addEventListener("click", function () {
            openFileDetails(file.id);
        });

        card.innerHTML = `
            <div style="font-size:30px;margin-bottom:8px;">
                ${icon}
            </div>

            <h3>${escapeHTML(file.title)}</h3>

            <small class="file-date">
                📅 ${escapeHTML(file.createdAt || "Date not available")}
            </small>

            <span class="file-category">
                ${escapeHTML(file.category)}
            </span>

            <p>${escapeHTML(file.details)}</p>

            ${
                file.tags
                ? `<div class="tags">🏷️ ${escapeHTML(file.tags)}</div>`
                : ""
            }
        `;

        fileList.appendChild(card);
    });
}


// ===============================
// OPEN FILE DETAILS
// ===============================

function openFileDetails(id) {
    const file = files.find(function (item) {
        return item.id === id;
    });

    if (!file) return;

    selectedFileId = id;

    if (viewTitle) viewTitle.textContent = file.title;
    if (viewCategory) viewCategory.textContent = file.category;
    if (viewDetails) viewDetails.textContent = file.details || "No details added.";
    if (viewTags) viewTags.textContent = file.tags || "No tags added.";
    if (viewDate) viewDate.textContent = "📅 Created: " + (file.createdAt || "Date not available");
    if (viewUpdated) {
        viewUpdated.textContent = file.updatedAt
            ? "✏️ Updated: " + file.updatedAt
            : "✏️ Not updated yet";
    }

    if (detailsModal) detailsModal.classList.remove("hidden");
}


// ===============================
// CLOSE DETAILS
// ===============================

if (closeDetails) {
    closeDetails.addEventListener("click", function () {
        detailsModal.classList.add("hidden");
    });
}


// ===============================
// EDIT
// ===============================

if (editFileBtn) {
    editFileBtn.addEventListener("click", function () {
        const file = files.find(function (item) {
            return item.id === selectedFileId;
        });

        if (!file) return;

        editingFileId = file.id;

        titleInput.value = file.title;
        categoryInput.value = file.category;
        detailsInput.value = file.details;
        tagsInput.value = file.tags;

        if (detailsModal) detailsModal.classList.add("hidden");
        if (modal) modal.classList.remove("hidden");
    });
}


// ===============================
// DELETE
// ===============================

if (deleteFileBtn) {
    deleteFileBtn.addEventListener("click", function () {
        const file = files.find(function (item) {
            return item.id === selectedFileId;
        });

        if (!file) return;

        const answer = confirm('Delete "' + file.title + '"?');
        if (!answer) return;

        files = files.filter(function (item) {
            return item.id !== selectedFileId;
        });

        localStorage.setItem("v5Files", JSON.stringify(files));

        selectedFileId = null;

        if (detailsModal) detailsModal.classList.add("hidden");

        displayFiles();
    });
}


// ===============================
// SEARCH
// ===============================

if (searchInput) {
    searchInput.addEventListener("input", function () {
        displayFiles();
    });
}


// ===============================
// CATEGORIES
// ===============================

document.querySelectorAll(".category").forEach(function (button) {
    button.addEventListener("click", function () {
        document.querySelectorAll(".category").forEach(function (btn) {
            btn.classList.remove("active");
        });

        button.classList.add("active");
        selectedCategory = button.dataset.category;
        displayFiles();
    });
});


// ===============================
// HTML SAFETY
// ===============================

function escapeHTML(text) {
    return String(text)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


// ===============================
// START & NAVIGATION
// ===============================

displayFiles();

const searchNav = document.getElementById("searchNav");
if (searchNav) {
    searchNav.addEventListener("click", function () {
        if (searchInput) searchInput.focus();
        window.scrollTo({ top: 0, behavior: "smooth" });
    });
}

const homeNav = document.querySelector(".nav-item");
if (homeNav) {
    homeNav.addEventListener("click", function () {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });
}

// ===============================
// ME SCREEN
// ===============================

const meNav = document.getElementById("meNav");
const meScreen = document.getElementById("meScreen");
const closeMe = document.getElementById("closeMe");

const meTotal = document.getElementById("meTotal");
const meDocuments = document.getElementById("meDocuments");
const mePhotos = document.getElementById("mePhotos");
const meOthers = document.getElementById("meOthers");

if (meNav) {
    meNav.addEventListener("click", function () {

        if (meTotal) {
            meTotal.textContent = files.length;
        }

        if (meDocuments) {
            meDocuments.textContent = files.filter(function (file) {
                return file.category === "Documents";
            }).length;
        }

        if (mePhotos) {
            mePhotos.textContent = files.filter(function (file) {
                return file.category === "Photos";
            }).length;
        }

        if (meOthers) {
            meOthers.textContent = files.filter(function (file) {
                return file.category === "Others";
            }).length;
        }

        if (meScreen) {
            meScreen.classList.remove("hidden");
        }
    });
}

if (closeMe) {
    closeMe.addEventListener("click", function () {
        if (meScreen) {
            meScreen.classList.add("hidden");
        }
    });
}

