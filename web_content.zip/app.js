// PDF.jsのローカルワーカーパス設定
if (typeof pdfjsLib !== 'undefined') {
    pdfjsLib.GlobalWorkerOptions.workerSrc = './lib/pdfjs/pdf.worker.min.js';
}

// A4基準サイズ (px)
const A4_PORTRAIT = { width: 794, height: 1123 };
const A4_LANDSCAPE = { width: 1123, height: 794 };

let currentBoard = {
    name: '新規ボード',
    importedPdfFileName: null,
    currentPageIndex: 0,
    pages: [{
        orientation: 'landscape',
        width: A4_LANDSCAPE.width,
        height: A4_LANDSCAPE.height,
        bgImage: null,
        items: []
    }]
};

let currentPageIndex = 0;
let interactionMode = 'select'; // 'select' | 'draw' | 'erase' | 'shape'
let eraserType = 'partial'; // 'partial' | 'stroke'

let isDrawing = false;
let activePointerId = null;
let currentStrokes = [];
let selectedItemId = null;
let isPalmRejectionEnabled = false;

// アンドゥ履歴管理 (最大5つ前まで)
let undoStack = [];
const MAX_UNDO = 5;

// モーダル用選択状態
let selectedNewOrientation = 'landscape';
let selectedAddOrientation = 'landscape';

// 選択モードでのナビ/ズームバーの表示フラグ
let isNavZoomBarVisible = false;
let lastTapTime = 0;

// ペン属性
let currentPenColor = '#1e293b';
let currentPenAlpha = 1.0;
let currentPenWidth = 4;
let currentPenStyle = 'solid'; // 'solid', 'dashed', 'dotted', 'marker'

// 消しゴム属性 (独立)
let currentEraserWidth = 16;

// 図形設定
let shapeStrokeColor = '#1e293b';
let shapeStrokeAlpha = 1.0;
let shapeStrokeWidth = 4;
let shapeFillColor = 'transparent';
let shapeFillAlpha = 0.0;

// カラーピッカー対象 ('pen' | 'shapeStroke' | 'shapeFill')
let colorPickerTarget = 'pen';
let selectedHue = 0;
let selectedSat = 1;
let selectedVal = 0.2;

// ズーム管理
let currentScale = 1.0;
let cameraStream = null;

function saveStateForUndo() {
    const state = JSON.parse(JSON.stringify({
        board: currentBoard,
        currentPageIndex: currentPageIndex,
        strokes: currentStrokes
    }));
    undoStack.push(state);
    if (undoStack.length > MAX_UNDO) {
        undoStack.shift();
    }
}

function undo() {
    if (undoStack.length === 0) {
        showToast('これ以上戻れません。', 'warning');
        return;
    }

    const previousState = undoStack.pop();
    currentBoard = previousState.board;
    currentPageIndex = previousState.currentPageIndex;
    currentStrokes = previousState.strokes || [];

    deselectAll();
    fitBoardToViewport();
    renderCurrentPage();

    const canvas = document.getElementById('drawingCanvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        redrawAllStrokes(ctx, canvas);
    }

    showToast('元に戻しました。', 'info');
}

function showToast(message, type = 'info') {
    let toast = document.getElementById('appToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'appToast';
        document.body.appendChild(toast);
    }
    
    // 背景を白、枠線と文字を黒に統一（トースト全体の視認性向上）
    let bgClass = 'bg-white text-black border-black';
    let iconClass = 'fa-solid fa-circle-info text-blue-600';
    
    if (type === 'error') {
        iconClass = 'fa-solid fa-circle-exclamation text-rose-600';
    } else if (type === 'success') {
        iconClass = 'fa-solid fa-circle-check text-emerald-600';
    } else if (type === 'warning') {
        iconClass = 'fa-solid fa-triangle-exclamation text-amber-600';
    }
    
    toast.className = `fixed top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-xs font-bold shadow-2xl transition-all duration-300 transform translate-y-0 opacity-100 flex items-center gap-2 border ${bgClass}`;
    toast.innerHTML = `<i class="${iconClass}"></i><span>${message}</span>`;
    
    clearTimeout(toast._timer);
    toast._timer = setTimeout(() => {
        toast.classList.add('-translate-y-10', 'opacity-0');
    }, 3000);
}

document.addEventListener('DOMContentLoaded', () => {
    // 起動時の画面サイズ（縦横比）を自動判別して初期キャンバスの向きを設定
    const isPortrait = window.innerHeight > window.innerWidth;
    const initialOrientation = isPortrait ? 'portrait' : 'landscape';
    const dim = isPortrait ? A4_PORTRAIT : A4_LANDSCAPE;
    if (currentBoard.pages && currentBoard.pages.length > 0) {
        currentBoard.pages[0].orientation = initialOrientation;
        currentBoard.pages[0].width = dim.width;
        currentBoard.pages[0].height = dim.height;
    }

    initPinchZoom();
    initDoubleTapHandler();
    initColorCircleCanvas();
    initKeyboardShortcuts();
    
    fitBoardToViewport();
    renderCurrentPage();

    window.addEventListener('resize', () => {
        initDrawingCanvas();
        updateScrollAreaDimensions();
    });

    document.addEventListener('click', (e) => {
        const menu = document.getElementById('saveExportMenu');
        if (menu && !menu.classList.contains('hidden') && !e.target.closest('#saveExportMenu') && !e.target.closest('button[title="保存/出力"]')) {
            menu.classList.add('hidden');
        }
    });
});

function toggleSaveExportMenu(e) {
    e.stopPropagation();
    const menu = document.getElementById('saveExportMenu');
    if (menu) {
        menu.classList.toggle('hidden');
    }
}

function triggerExport(type) {
    const menu = document.getElementById('saveExportMenu');
    if (menu) menu.classList.add('hidden');

    if (type === 'json') {
        exportToJSON();
    } else if (type === 'pdf') {
        exportToPDF();
    }
}

function openNewBoardModal() {
    document.getElementById('newBoardTitleInput').value = currentBoard.name || '新規ボード';
    setNewBoardOrientation('landscape');
    document.getElementById('newBoardModal')?.classList.remove('hidden');
}

function closeNewBoardModal() {
    document.getElementById('newBoardModal')?.classList.add('hidden');
}

function setNewBoardOrientation(orient) {
    selectedNewOrientation = orient;
    const btnLand = document.getElementById('btnNewOrientationLandscape');
    const btnPort = document.getElementById('btnNewOrientationPortrait');

    if (orient === 'landscape') {
        btnLand?.classList.add('active');
        btnPort?.classList.remove('active');
    } else {
        btnLand?.classList.remove('active');
        btnPort?.classList.add('active');
    }
}

function confirmCreateNewBoard() {
    const titleInput = document.getElementById('newBoardTitleInput').value.trim();
    const title = titleInput !== "" ? titleInput : "新規ボード";

    const dim = selectedNewOrientation === 'landscape' ? A4_LANDSCAPE : A4_PORTRAIT;

    undoStack = [];

    currentBoard = {
        name: title,
        importedPdfFileName: null,
        currentPageIndex: 0,
        pages: [{
            orientation: selectedNewOrientation,
            width: dim.width,
            height: dim.height,
            bgImage: null,
            items: []
        }]
    };

    currentPageIndex = 0;
    closeNewBoardModal();
    fitBoardToViewport();
    renderCurrentPage();
    showToast('新規ボードを作成しました。', 'success');
}

function openAddPageModal() {
    setAddPageOrientation('landscape');
    document.getElementById('addPageModal')?.classList.remove('hidden');
}

function closeAddPageModal() {
    document.getElementById('addPageModal')?.classList.add('hidden');
}

function setAddPageOrientation(orient) {
    selectedAddOrientation = orient;
    const btnLand = document.getElementById('btnAddOrientationLandscape');
    const btnPort = document.getElementById('btnAddOrientationPortrait');

    if (orient === 'landscape') {
        btnLand?.classList.add('active');
        btnPort?.classList.remove('active');
    } else {
        btnLand?.classList.remove('active');
        btnPort?.classList.add('active');
    }
}

function confirmAddPage() {
    saveStateForUndo();
    if (interactionMode === 'draw' || interactionMode === 'erase') convertHandwritingToObject();

    const dim = selectedAddOrientation === 'landscape' ? A4_LANDSCAPE : A4_PORTRAIT;

    currentBoard.pages.splice(currentPageIndex + 1, 0, {
        orientation: selectedAddOrientation,
        width: dim.width,
        height: dim.height,
        bgImage: null,
        items: []
    });

    currentPageIndex++;
    closeAddPageModal();
    fitBoardToViewport();
    renderCurrentPage();
    showToast('新しいページを追加しました。', 'success');
}

function getFormattedTimestamp() {
    const now = new Date();
    const yyyy = now.getFullYear();
    const mm = String(now.getMonth() + 1).padStart(2, '0');
    const dd = String(now.getDate()).padStart(2, '0');
    const hh = String(now.getHours()).padStart(2, '0');
    const mi = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    return `${yyyy}${mm}${dd}_${hh}${mi}${ss}`;
}

function promptExportFileName() {
    const timestamp = getFormattedTimestamp();
    let defaultAutoName = "";

    if (currentBoard.importedPdfFileName && currentBoard.importedPdfFileName.trim() !== "") {
        defaultAutoName = `${currentBoard.importedPdfFileName}_${timestamp}`;
    } else {
        defaultAutoName = `${currentBoard.name}_${timestamp}`;
    }

    const userInput = prompt("保存・出力するファイル名を入力してください。\n（空欄で決定した場合は自動で命名されます）", "");
    
    if (userInput === null) {
        return null;
    }

    const trimmed = userInput.trim();
    if (trimmed === "") {
        return defaultAutoName;
    }
    return trimmed;
}

function initDoubleTapHandler() {
    const mainArea = document.getElementById('mainCanvasWrapper');
    if (!mainArea) return;

    const handleDoubleTap = (e) => {
        if (e.target.closest('.icon-btn') || e.target.closest('.pill-btn') || e.target.closest('.handle-move') || e.target.closest('.handle-delete') || e.target.closest('.handle-resize') || e.target.closest('.board-item')) {
            return;
        }

        if (interactionMode === 'select') {
            deselectAll();
            isNavZoomBarVisible = !isNavZoomBarVisible;
            updateBottomContextBar();
        }
    };

    mainArea.addEventListener('dblclick', handleDoubleTap);
    mainArea.addEventListener('touchend', (e) => {
        const currentTime = new Date().getTime();
        const tapLength = currentTime - lastTapTime;
        if (tapLength < 300 && tapLength > 0) {
            handleDoubleTap(e);
        }
        lastTapTime = currentTime;
    });
}

function handleHandwritingObjectDoubleTap(itemId, e) {
    if (interactionMode !== 'select') return;
    const page = getCurrentPage();
    if (!page) return;

    const item = page.items.find(i => i.id === itemId);
    if (!item || !item.isHandwriting) return;

    if (e) e.stopPropagation();

    saveStateForUndo();

    if (item.strokes && item.strokes.length > 0) {
        const scaleX = (item.cropWidth && item.cropWidth > 0) ? (item.width / item.cropWidth) : 1;
        const scaleY = (item.cropHeight && item.cropHeight > 0) ? (item.height / item.cropHeight) : 1;
        const originX = item.cropMinX !== undefined ? item.cropMinX : item.x;
        const originY = item.cropMinY !== undefined ? item.cropMinY : item.y;

        const restoredStrokes = item.strokes.map(stroke => {
            return {
                ...stroke,
                width: Math.max(1, Math.round(stroke.width * Math.min(scaleX, scaleY))),
                points: stroke.points.map(pt => ({
                    x: item.x + (pt.x - originX) * scaleX,
                    y: item.y + (pt.y - originY) * scaleY
                }))
            };
        });
        currentStrokes = restoredStrokes;
    }

    deleteItem(itemId);
    setInteractionMode('draw');

    const canvas = document.getElementById('drawingCanvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        redrawAllStrokes(ctx, canvas);
    }

    showToast('手書きオブジェクトを修正モードに戻しました。', 'info');
}

function formatPx(val) {
    return String(val).padStart(2, '0') + 'px';
}

function handlePenWidthChange(val) {
    currentPenWidth = parseInt(val, 10);
    document.getElementById('penWidthText').innerText = formatPx(currentPenWidth);
}

function handleEraserWidthChange(val) {
    currentEraserWidth = parseInt(val, 10);
    document.getElementById('eraserWidthText').innerText = formatPx(currentEraserWidth);
}

function handleShapeStrokeWidthChange(val) {
    shapeStrokeWidth = parseInt(val, 10);
    document.getElementById('shapeStrokeWidthText').innerText = formatPx(shapeStrokeWidth);
    updateSelectedShapeProperties();
}

function setEraserType(type) {
    eraserType = type;
    document.getElementById('btnErasePartial')?.classList.toggle('active', type === 'partial');
    document.getElementById('btnEraseStroke')?.classList.toggle('active', type === 'stroke');
}

function openStyleModal() { document.getElementById('styleModal')?.classList.remove('hidden'); }
function closeStyleModal() { document.getElementById('styleModal')?.classList.add('hidden'); }
function selectPenStyle(style, label) {
    currentPenStyle = style;
    document.getElementById('currentStyleLabel').innerText = label;
    closeStyleModal();
}

function openShapeSelectModal() { document.getElementById('shapeSelectModal')?.classList.remove('hidden'); }
function closeShapeSelectModal() { document.getElementById('shapeSelectModal')?.classList.add('hidden'); }
function insertShapeAndClose(shapeType) {
    closeShapeSelectModal();
    addShape(shapeType);
}

function togglePalmRejection() {
    isPalmRejectionEnabled = !isPalmRejectionEnabled;
    document.getElementById('btnPalmRejection')?.classList.toggle('active', isPalmRejectionEnabled);
    showToast(`パームリジェクション: ${isPalmRejectionEnabled ? 'ON' : 'OFF'}`, 'info');
}

function updateBottomContextBar() {
    const contextBar = document.getElementById('bottomContextBar');
    const penBar = document.getElementById('penBar');
    const eraseBar = document.getElementById('eraseBar');
    const shapeBar = document.getElementById('shapeBar');
    const objectEditBar = document.getElementById('objectEditBar');
    const shapeEditBar = document.getElementById('shapeEditBar');
    const navZoomBar = document.getElementById('navZoomBar');

    if (!contextBar) return;

    penBar?.classList.add('hidden');
    eraseBar?.classList.add('hidden');
    shapeBar?.classList.add('hidden');
    objectEditBar?.classList.add('hidden');
    shapeEditBar?.classList.add('hidden');
    navZoomBar?.classList.add('hidden');

    let showAny = false;

    if (interactionMode === 'draw') {
        penBar?.classList.remove('hidden');
        showAny = true;
    } else if (interactionMode === 'erase') {
        eraseBar?.classList.remove('hidden');
        showAny = true;
    } else if (interactionMode === 'shape') {
        shapeBar?.classList.remove('hidden');
        showAny = true;
    } else if (interactionMode === 'select') {
        const page = getCurrentPage();
        const selectedItem = page?.items.find(i => i.id === selectedItemId);

        if (selectedItem) {
            objectEditBar?.classList.remove('hidden');
            showAny = true;
            if (selectedItem.type === 'shape') {
                shapeEditBar?.classList.remove('hidden');
            }
        } else if (isNavZoomBarVisible) {
            navZoomBar?.classList.remove('hidden');
            showAny = true;
        }
    }

    if (showAny) {
        contextBar.classList.remove('hidden');
    } else {
        contextBar.classList.add('hidden');
    }
}

function setInteractionMode(mode) {
    const isHandwritingMode = (interactionMode === 'draw' || interactionMode === 'erase');
    const isTargetHandwritingMode = (mode === 'draw' || mode === 'erase');

    if (isHandwritingMode && !isTargetHandwritingMode) {
        convertHandwritingToObject();
    }

    if (!isHandwritingMode && mode === 'erase') {
        return;
    }

    interactionMode = mode;

    if (mode !== 'select') {
        isNavZoomBarVisible = false;
    }

    const btnErase = document.getElementById('btnModeErase');
    const isCurrentHandwriting = (interactionMode === 'draw' || interactionMode === 'erase');

    if (btnErase) {
        if (isCurrentHandwriting) {
            btnErase.removeAttribute('disabled');
            btnErase.classList.remove('opacity-40', 'cursor-not-allowed');
            btnErase.classList.add('cursor-pointer');
            btnErase.title = "消しゴム";
        } else {
            btnErase.setAttribute('disabled', 'true');
            btnErase.classList.add('opacity-40', 'cursor-not-allowed');
            btnErase.classList.remove('cursor-pointer');
            btnErase.title = "消しゴム (手書きモード中のみ使用可能)";
        }
    }

    document.getElementById('btnModeSelect')?.classList.toggle('active', mode === 'select');
    document.getElementById('btnModeDraw')?.classList.toggle('active', mode === 'draw');
    document.getElementById('btnModeErase')?.classList.toggle('active', mode === 'erase');
    document.getElementById('btnModeShape')?.classList.toggle('active', mode === 'shape');

    const canvas = document.getElementById('drawingCanvas');
    if (canvas) {
        canvas.style.pointerEvents = (mode === 'draw' || mode === 'erase') ? 'auto' : 'none';
    }
    
    deselectAll();
    updateBottomContextBar();
}

function initColorCircleCanvas() {
    const canvas = document.getElementById('colorCircleCanvas');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const outerR = width / 2 - 2;
    const innerR = outerR - 20;

    function drawCircle() {
        ctx.clearRect(0, 0, width, height);

        for (let angle = 0; angle < 360; angle += 1) {
            const startAngle = (angle - 1) * Math.PI / 180;
            const endAngle = (angle + 1) * Math.PI / 180;
            ctx.beginPath();
            ctx.arc(centerX, centerY, (outerR + innerR) / 2, startAngle, endAngle);
            ctx.lineWidth = outerR - innerR;
            ctx.strokeStyle = `hsl(${angle}, 100%, 50%)`;
            ctx.stroke();
        }

        const rectSize = innerR * 1.2;
        const half = rectSize / 2;
        const rx = centerX - half;
        const ry = centerY - half;

        for (let x = 0; x < rectSize; x += 2) {
            for (let y = 0; y < rectSize; y += 2) {
                const sat = x / rectSize;
                const val = 1 - (y / rectSize);
                ctx.fillStyle = hsvToRgbString(selectedHue, sat, val, 1.0);
                ctx.fillRect(rx + x, ry + y, 2, 2);
            }
        }
    }

    drawCircle();

    let isInteracting = false;
    const handleInteract = (e) => {
        const rect = canvas.getBoundingClientRect();
        const x = (e.clientX || e.touches[0].clientX) - rect.left;
        const y = (e.clientY || e.touches[0].clientY) - rect.top;

        const dx = x - centerX;
        const dy = y - centerY;
        const dist = Math.hypot(dx, dy);

        if (dist >= innerR && dist <= outerR) {
            let angle = Math.atan2(dy, dx) * (180 / Math.PI);
            if (angle < 0) angle += 360;
            selectedHue = angle;
            drawCircle();
        } else if (dist < innerR) {
            const rectSize = innerR * 1.2;
            const rx = centerX - rectSize / 2;
            const ry = centerY - rectSize / 2;

            if (x >= rx && x <= rx + rectSize && y >= ry && y <= ry + rectSize) {
                selectedSat = Math.min(Math.max((x - rx) / rectSize, 0), 1);
                selectedVal = Math.min(Math.max(1 - (y - ry) / rectSize, 0), 1);
            }
        }
        updateColorFromPicker();
    };

    canvas.addEventListener('pointerdown', (e) => { isInteracting = true; handleInteract(e); });
    canvas.addEventListener('pointermove', (e) => { if (isInteracting) handleInteract(e); });
    window.addEventListener('pointerup', () => { isInteracting = false; });
}

function hsvToRgbString(h, s, v, a) {
    let c = v * s;
    let x = c * (1 - Math.abs((h / 60) % 2 - 1));
    let m = v - c;
    let r = 0, g = 0, b = 0;

    if (0 <= h && h < 60) { r = c; g = x; b = 0; }
    else if (60 <= h && h < 120) { r = x; g = c; b = 0; }
    else if (120 <= h && h < 180) { r = 0; g = c; b = x; }
    else if (180 <= h && h < 240) { r = 0; g = x; b = c; }
    else if (240 <= h && h < 300) { r = x; g = 0; b = c; }
    else if (300 <= h && h < 360) { r = c; g = 0; b = x; }

    r = Math.round((r + m) * 255);
    g = Math.round((g + m) * 255);
    b = Math.round((b + m) * 255);

    return `rgba(${r}, ${g}, ${b}, ${a})`;
}

function openColorCircleModal(target) {
    colorPickerTarget = target;
    const titleEl = document.getElementById('colorCircleTitle');
    if (target === 'pen') titleEl.innerText = 'ペン色 & 透過率設定';
    else if (target === 'shapeStroke') titleEl.innerText = '図形枠線色 & 透過率設定';
    else if (target === 'shapeFill') titleEl.innerText = '図形塗り色 & 透過率設定';

    document.getElementById('colorCircleModal')?.classList.remove('hidden');
    updateColorFromPicker();
}

function closeColorCircleModal() {
    document.getElementById('colorCircleModal')?.classList.add('hidden');
}

function updateColorFromPicker() {
    const alphaVal = parseInt(document.getElementById('colorAlphaSlider').value, 10) / 100;
    document.getElementById('colorAlphaText').innerText = `${Math.round(alphaVal * 100)}%`;

    const colorStr = hsvToRgbString(selectedHue, selectedSat, selectedVal, alphaVal);
    document.getElementById('colorSelectedPreview').style.backgroundColor = colorStr;
}

function applyColorSelection() {
    const alphaVal = parseInt(document.getElementById('colorAlphaSlider').value, 10) / 100;
    const colorStr = hsvToRgbString(selectedHue, selectedSat, selectedVal, alphaVal);

    if (colorPickerTarget === 'pen') {
        currentPenColor = colorStr;
        currentPenAlpha = alphaVal;
        document.getElementById('penColorPreview').style.backgroundColor = colorStr;
    } else if (colorPickerTarget === 'shapeStroke') {
        shapeStrokeColor = colorStr;
        shapeStrokeAlpha = alphaVal;
        document.getElementById('shapeStrokePreview').style.backgroundColor = colorStr;
        updateSelectedShapeProperties();
    } else if (colorPickerTarget === 'shapeFill') {
        shapeFillColor = colorStr;
        shapeFillAlpha = alphaVal;
        document.getElementById('shapeFillPreview').style.backgroundColor = colorStr;
        updateSelectedShapeProperties();
    }

    closeColorCircleModal();
}

function initDrawingCanvas() {
    const canvas = document.getElementById('drawingCanvas');
    const container = document.getElementById('boardContainer');
    if (!canvas || !container) return;

    canvas.width = container.clientWidth || 1123;
    canvas.height = container.clientHeight || 794;
    canvas.style.pointerEvents = (interactionMode === 'draw' || interactionMode === 'erase') ? 'auto' : 'none';

    const ctx = canvas.getContext('2d');

    const handlePointerDown = (e) => {
        if (interactionMode === 'select' || interactionMode === 'shape') return;
        if (isPalmRejectionEnabled && e.pointerType !== 'pen') return;

        if (e.cancelable) e.preventDefault();

        saveStateForUndo();

        isDrawing = true;
        activePointerId = e.pointerId;

        try { canvas.setPointerCapture(e.pointerId); } catch (err) {}

        const pos = getBoardCoordinates(e.clientX, e.clientY);

        if (interactionMode === 'erase') {
            eraseStrokesAtPoint(pos.x, pos.y);
            redrawAllStrokes(ctx, canvas);
            drawEraserCursor(ctx, pos.x, pos.y);
        } else if (interactionMode === 'draw') {
            currentStrokes.push({
                points: [{ x: pos.x, y: pos.y }],
                color: currentPenColor,
                width: currentPenWidth,
                style: currentPenStyle
            });
            redrawAllStrokes(ctx, canvas);
        }
    };

    const handlePointerMove = (e) => {
        if (!isDrawing && interactionMode !== 'erase') return;
        if (isPalmRejectionEnabled && e.pointerType !== 'pen') return;

        if (e.cancelable) e.preventDefault();

        const pos = getBoardCoordinates(e.clientX, e.clientY);

        if (interactionMode === 'erase') {
            if (isDrawing) {
                eraseStrokesAtPoint(pos.x, pos.y);
            }
            redrawAllStrokes(ctx, canvas);
            drawEraserCursor(ctx, pos.x, pos.y);
        } else if (interactionMode === 'draw' && isDrawing) {
            if (currentStrokes.length > 0) {
                const currentStroke = currentStrokes[currentStrokes.length - 1];
                currentStroke.points.push({ x: pos.x, y: pos.y });
                redrawAllStrokes(ctx, canvas);
            }
        }
    };

    const endDrawing = () => {
        if (isDrawing) {
            isDrawing = false;
            if (activePointerId !== null) {
                try {
                    if (canvas.hasPointerCapture && canvas.hasPointerCapture(activePointerId)) {
                        canvas.releasePointerCapture(activePointerId);
                    }
                } catch (err) {}
                activePointerId = null;
            }
            if (interactionMode === 'erase') {
                redrawAllStrokes(ctx, canvas);
            }
        }
    };

    canvas.onpointerdown = handlePointerDown;
    canvas.onpointermove = handlePointerMove;
    canvas.onpointerup = endDrawing;
    canvas.onpointercancel = endDrawing;
}

function drawEraserCursor(ctx, x, y) {
    const radius = Math.max(currentEraserWidth / 2, 8);
    ctx.save();
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2;
    ctx.setLineDash([4, 4]);
    ctx.stroke();
    ctx.restore();
}

function eraseStrokesAtPoint(eraseX, eraseY) {
    const eraseRadius = Math.max(currentEraserWidth / 2, 8);

    if (eraserType === 'stroke') {
        currentStrokes = currentStrokes.filter(stroke => {
            return !stroke.points.some(pt => Math.hypot(pt.x - eraseX, pt.y - eraseY) <= eraseRadius);
        });
    } else {
        const nextStrokes = [];
        currentStrokes.forEach(stroke => {
            const pts = stroke.points;
            let currentSegment = [];

            for (let i = 0; i < pts.length; i++) {
                const pt = pts[i];
                if (Math.hypot(pt.x - eraseX, pt.y - eraseY) > eraseRadius) {
                    currentSegment.push(pt);
                } else {
                    if (currentSegment.length > 0) {
                        nextStrokes.push({ ...stroke, points: currentSegment });
                        currentSegment = [];
                    }
                }
            }
            if (currentSegment.length > 0) {
                nextStrokes.push({ ...stroke, points: currentSegment });
            }
        });
        currentStrokes = nextStrokes;
    }
}

function redrawAllStrokes(ctx, canvas) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    currentStrokes.forEach(stroke => {
        const pts = stroke.points;
        if (pts.length === 0) return;

        ctx.save();
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        const strokeWidth = (stroke.style === 'marker') ? stroke.width * 2.5 : stroke.width;
        ctx.lineWidth = strokeWidth;
        ctx.strokeStyle = stroke.color;

        if (stroke.style === 'marker') {
            ctx.globalAlpha = 0.4;
            ctx.setLineDash([]);
        } else if (stroke.style === 'dashed') {
            ctx.setLineDash([strokeWidth * 3, strokeWidth * 2]);
        } else if (stroke.style === 'dotted') {
            ctx.setLineDash([strokeWidth, strokeWidth * 1.5]);
        } else {
            ctx.setLineDash([]);
        }

        ctx.beginPath();
        ctx.moveTo(pts[0].x, pts[0].y);

        if (pts.length === 1) {
            ctx.lineTo(pts[0].x, pts[0].y);
        } else {
            for (let i = 1; i < pts.length - 1; i++) {
                const midX = (pts[i].x + pts[i + 1].x) / 2;
                const midY = (pts[i].y + pts[i + 1].y) / 2;
                ctx.quadraticCurveTo(pts[i].x, pts[i].y, midX, midY);
            }
            ctx.lineTo(pts[pts.length - 1].x, pts[pts.length - 1].y);
        }

        ctx.stroke();
        ctx.restore();
    });
}

function convertHandwritingToObject() {
    const canvas = document.getElementById('drawingCanvas');
    const page = getCurrentPage();
    if (!canvas || !page || currentStrokes.length === 0) return;

    const ctx = canvas.getContext('2d');
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imgData.data;

    let minX = canvas.width, minY = canvas.height, maxX = 0, maxY = 0;
    let hasPixel = false;

    for (let y = 0; y < canvas.height; y++) {
        for (let x = 0; x < canvas.width; x++) {
            const alpha = pixels[(y * canvas.width + x) * 4 + 3];
            if (alpha > 0) {
                hasPixel = true;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
    }

    if (!hasPixel) { currentStrokes = []; return; }

    const padding = 8;
    minX = Math.max(0, minX - padding);
    minY = Math.max(0, minY - padding);
    maxX = Math.min(canvas.width, maxX + padding);
    maxY = Math.min(canvas.height, maxY + padding);

    const cropWidth = maxX - minX;
    const cropHeight = maxY - minY;

    if (cropWidth <= 0 || cropHeight <= 0) { currentStrokes = []; return; }

    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = cropWidth;
    tempCanvas.height = cropHeight;
    const tempCtx = tempCanvas.getContext('2d');

    tempCtx.drawImage(canvas, minX, minY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);
    const croppedDataUrl = tempCanvas.toDataURL('image/png');

    const newItem = {
        id: 'item_' + Date.now(),
        type: 'image',
        isHandwriting: true,
        x: minX,
        y: minY,
        width: cropWidth,
        height: cropHeight,
        cropMinX: minX,
        cropMinY: minY,
        cropWidth: cropWidth,
        cropHeight: cropHeight,
        src: croppedDataUrl,
        strokes: JSON.parse(JSON.stringify(currentStrokes))
    };

    page.items.push(newItem);
    renderBoardItem(newItem, page.items.length - 1);

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    currentStrokes = [];
}

function createShapeSvg(shapeType, strokeColor, strokeWidth, fillColor) {
    let inner = '';
    switch(shapeType) {
        case 'circle':
            inner = `<circle cx="50" cy="50" r="42" fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}"/>`;
            break;
        case 'triangle':
            inner = `<polygon points="50,8 92,88 8,88" fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}"/>`;
            break;
        case 'rect':
            inner = `<rect x="8" y="8" width="84" height="84" rx="4" fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}"/>`;
            break;
        case 'arrow-up':
            inner = `<path d="M50 8 L88 44 H64 V88 H36 V44 H12 Z" fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}"/>`;
            break;
        case 'arrow-down':
            inner = `<path d="M50 88 L88 52 H64 V12 H36 V52 H12 Z" fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}"/>`;
            break;
        case 'arrow-left':
            inner = `<path d="M8 50 L44 12 V36 H88 V64 H44 V88 Z" fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}"/>`;
            break;
        case 'arrow-right':
            inner = `<path d="M92 50 L56 12 V36 H12 V64 H56 V88 Z" fill="${fillColor}" stroke="${strokeColor}" stroke-width="${strokeWidth}"/>`;
            break;
    }
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100%" height="100%">${inner}</svg>`;
}

function addShape(shapeType) {
    saveStateForUndo();
    const page = getCurrentPage();
    const svgContent = createShapeSvg(shapeType, shapeStrokeColor, shapeStrokeWidth, shapeFillColor);
    const svgBlob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    const newItem = {
        id: 'item_' + Date.now(),
        type: 'shape',
        shapeType: shapeType,
        strokeColor: shapeStrokeColor,
        strokeWidth: shapeStrokeWidth,
        fillColor: shapeFillColor,
        x: 120,
        y: 120,
        width: 120,
        height: 120,
        src: url
    };

    page.items.push(newItem);
    renderBoardItem(newItem, page.items.length - 1);
    selectItem(newItem.id);
}

function updateSelectedShapeProperties() {
    if (!selectedItemId) return;
    const page = getCurrentPage();
    const item = page?.items.find(i => i.id === selectedItemId);

    if (item && item.type === 'shape') {
        saveStateForUndo();
        item.strokeColor = shapeStrokeColor;
        item.strokeWidth = shapeStrokeWidth;
        item.fillColor = shapeFillColor;

        const svgContent = createShapeSvg(item.shapeType, item.strokeColor, item.strokeWidth, item.fillColor);
        const svgBlob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
        item.src = URL.createObjectURL(svgBlob);

        const index = page.items.findIndex(i => i.id === selectedItemId);
        renderBoardItem(item, index);
    }
}

function addTextBox() {
    saveStateForUndo();
    const page = getCurrentPage();
    const newItem = {
        id: 'item_' + Date.now(),
        type: 'text',
        x: 100,
        y: 100,
        width: 200,
        height: 100,
        text: 'テキストを入力'
    };
    page.items.push(newItem);
    renderBoardItem(newItem, page.items.length - 1);
    selectItem(newItem.id);
}

function addImageObject(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
        const img = new Image();
        img.onload = () => {
            saveStateForUndo();
            const page = getCurrentPage();
            let w = img.width, h = img.height;
            const maxDimension = 350;

            if (w > maxDimension || h > maxDimension) {
                const scale = Math.min(maxDimension / w, maxDimension / h);
                w = Math.round(w * scale);
                h = Math.round(h * scale);
            }

            const newItem = {
                id: 'item_' + Date.now(),
                type: 'image',
                x: 100,
                y: 100,
                width: w,
                height: h,
                src: evt.target.result
            };

            page.items.push(newItem);
            renderBoardItem(newItem, page.items.length - 1);
            selectItem(newItem.id);
        };
        img.src = evt.target.result;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
}

async function openCameraModal() {
    const modal = document.getElementById('cameraModal');
    const video = document.getElementById('cameraVideo');
    if (!modal || !video) return;

    modal.classList.remove('hidden');

    try {
        let constraints = { video: { facingMode: { exact: "environment" } } };
        try {
            cameraStream = await navigator.mediaDevices.getUserMedia(constraints);
        } catch (e) {
            constraints = { video: { facingMode: "environment" } };
            try {
                cameraStream = await navigator.mediaDevices.getUserMedia(constraints);
            } catch (e2) {
                cameraStream = await navigator.mediaDevices.getUserMedia({ video: true });
            }
        }
        video.srcObject = cameraStream;
    } catch (err) {
        showToast('カメラの起動に失敗しました。', 'error');
        closeCameraModal();
    }
}

function closeCameraModal() {
    const modal = document.getElementById('cameraModal');
    const video = document.getElementById('cameraVideo');
    if (modal) modal.classList.add('hidden');
    if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
        cameraStream = null;
    }
    if (video) video.srcObject = null;
}

function captureCameraSquare() {
    const video = document.getElementById('cameraVideo');
    if (!video || !video.videoWidth) return;

    saveStateForUndo();

    const vW = video.videoWidth;
    const vH = video.videoHeight;
    const squareSize = Math.min(vW, vH);

    const startX = (vW - squareSize) / 2;
    const startY = (vH - squareSize) / 2;

    const canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 400;
    const ctx = canvas.getContext('2d');

    ctx.drawImage(video, startX, startY, squareSize, squareSize, 0, 0, 400, 400);

    const page = getCurrentPage();
    const newItem = {
        id: 'item_' + Date.now(),
        type: 'image',
        x: 100,
        y: 100,
        width: 250,
        height: 250,
        src: canvas.toDataURL('image/jpeg', 0.9)
    };

    page.items.push(newItem);
    renderBoardItem(newItem, page.items.length - 1);
    selectItem(newItem.id);

    closeCameraModal();
}

function openHelpModal() { document.getElementById('helpModal')?.classList.remove('hidden'); }
function closeHelpModal() { document.getElementById('helpModal')?.classList.add('hidden'); }

function renderBoardItem(item, zIndex) {
    const boardContainer = document.getElementById('boardContainer');
    if (!boardContainer) return;

    let el = document.getElementById(item.id);
    if (!el) {
        el = document.createElement('div');
        el.id = item.id;
        boardContainer.appendChild(el);
    }

    el.className = 'board-item' + (selectedItemId === item.id ? ' selected' : '');
    el.style.left = `${item.x}px`;
    el.style.top = `${item.y}px`;
    el.style.width = `${item.width}px`;
    el.style.height = `${item.height}px`;
    if (zIndex !== undefined) {
        el.style.zIndex = zIndex + 10;
    }

    let innerHTML = '';
    if (item.type === 'text') {
        innerHTML = `<div class="item-content" contenteditable="true" style="padding:8px; background:rgba(255,255,255,0.9); border:1px solid #cbd5e1; border-radius:4px; width:100%; height:100%; color:#0f172a;" onblur="updateText('${item.id}', this.innerText)">${item.text}</div>`;
    } else if (item.type === 'image' || item.type === 'shape') {
        innerHTML = `<img src="${item.src}">`;
    }

    // 移動、削除、拡大縮小ハンドルの表示設定（白いフォントで ✜ ✖ ⇲ を表示）
    innerHTML += `
        <div class="handle-move" onpointerdown="startDrag(event, '${item.id}')" title="移動">✜</div>
        <div class="handle-delete" onclick="deleteItem('${item.id}')" title="削除">✖</div>
        <div class="handle-resize" onpointerdown="startResize(event, '${item.id}')" title="拡大縮小">⇲</div>
    `;
    el.innerHTML = innerHTML;

    el.onclick = (e) => {
        if (interactionMode === 'erase') return;
        e.stopPropagation();
        selectItem(item.id);
    };

    if (item.isHandwriting) {
        let lastItemTapTime = 0;
        el.ondblclick = (e) => {
            handleHandwritingObjectDoubleTap(item.id, e);
        };
        el.ontouchend = (e) => {
            if (e.target.closest('.handle-move') || e.target.closest('.handle-delete') || e.target.closest('.handle-resize')) {
                return;
            }
            const currentTime = new Date().getTime();
            const tapLength = currentTime - lastItemTapTime;
            if (tapLength < 300 && tapLength > 0) {
                handleHandwritingObjectDoubleTap(item.id, e);
            }
            lastItemTapTime = currentTime;
        };
    } else {
        el.ondblclick = null;
        el.ontouchend = null;
    }
}

function selectItem(id) {
    deselectAll();
    selectedItemId = id;
    const el = document.getElementById(id);
    if (el) el.classList.add('selected');

    updateBottomContextBar();
}

function deselectAll() {
    if (selectedItemId) {
        const el = document.getElementById(selectedItemId);
        if (el) el.classList.remove('selected');
    }
    selectedItemId = null;
    updateBottomContextBar();
}

// レイヤー操作：選択されているオブジェクトをひとつ上の階層（前面）に動かす
function moveLayerUp() {
    if (!selectedItemId) return;
    const page = getCurrentPage();
    if (!page) return;

    const index = page.items.findIndex(i => i.id === selectedItemId);
    if (index === -1 || index >= page.items.length - 1) return; // すでに最前面

    saveStateForUndo();

    const temp = page.items[index];
    page.items[index] = page.items[index + 1];
    page.items[index + 1] = temp;

    const currentId = selectedItemId;
    renderCurrentPage();
    selectItem(currentId);
}

// レイヤー操作：選択されているオブジェクトをひとつ下の階層（背面）に動かす
function moveLayerDown() {
    if (!selectedItemId) return;
    const page = getCurrentPage();
    if (!page) return;

    const index = page.items.findIndex(i => i.id === selectedItemId);
    if (index <= 0) return; // すでに最背面

    saveStateForUndo();

    const temp = page.items[index];
    page.items[index] = page.items[index - 1];
    page.items[index - 1] = temp;

    const currentId = selectedItemId;
    renderCurrentPage();
    selectItem(currentId);
}

function deleteItem(id) {
    saveStateForUndo();
    const page = getCurrentPage();
    if (!page) return;
    page.items = page.items.filter(i => i.id !== id);
    const el = document.getElementById(id);
    if (el) el.remove();
    if (selectedItemId === id) selectedItemId = null;
    updateBottomContextBar();
}

function updateText(id, text) {
    const page = getCurrentPage();
    const item = page?.items.find(i => i.id === id);
    if (item) {
        if (item.text !== text) saveStateForUndo();
        item.text = text;
    }
}

function startDrag(e, id) {
    if (interactionMode !== 'select') return;
    e.stopPropagation();
    selectItem(id);

    saveStateForUndo();

    const page = getCurrentPage();
    const item = page.items.find(i => i.id === id);
    const el = document.getElementById(id);

    let startX = e.clientX;
    let startY = e.clientY;
    let initX = item.x;
    let initY = item.y;

    try { el.setPointerCapture(e.pointerId); } catch (err) {}

    el.onpointermove = (pe) => {
        const dx = (pe.clientX - startX) / currentScale;
        const dy = (pe.clientY - startY) / currentScale;
        item.x = initX + dx;
        item.y = initY + dy;
        el.style.left = `${item.x}px`;
        el.style.top = `${item.y}px`;
    };

    el.onpointerup = () => {
        el.onpointermove = null;
        el.onpointerup = null;
    };
}

function startResize(e, id) {
    if (interactionMode !== 'select') return;
    e.stopPropagation();
    selectItem(id);

    saveStateForUndo();

    const page = getCurrentPage();
    const item = page.items.find(i => i.id === id);
    const el = document.getElementById(id);

    let startX = e.clientX;
    let startY = e.clientY;
    let initW = item.width;
    let initH = item.height;
    const aspectRatio = initW / initH;

    try { el.setPointerCapture(e.pointerId); } catch (err) {}

    el.onpointermove = (pe) => {
        const dx = (pe.clientX - startX) / currentScale;
        const dy = (pe.clientY - startY) / currentScale;

        let newW, newH;

        if (item.type === 'image' || item.type === 'shape') {
            const delta = Math.max(dx, dy * aspectRatio);
            newW = Math.max(30, initW + delta);
            newH = Math.round(newW / aspectRatio);
        } else {
            newW = Math.max(30, initW + dx);
            newH = Math.max(30, initH + dy);
        }

        item.width = newW;
        item.height = newH;
        el.style.width = `${newW}px`;
        el.style.height = `${newH}px`;
    };

    el.onpointerup = () => {
        el.onpointermove = null;
        el.onpointerup = null;
    };
}

function getBoardCoordinates(clientX, clientY) {
    const container = document.getElementById('boardContainer');
    const rect = container.getBoundingClientRect();
    return {
        x: (clientX - rect.left) / currentScale,
        y: (clientY - rect.top) / currentScale
    };
}

function getCurrentPage() {
    return currentBoard.pages[currentPageIndex];
}

function renderCurrentPage() {
    const page = getCurrentPage();
    if (!page) return;

    const boardContainer = document.getElementById('boardContainer');
    if (!boardContainer) return;

    boardContainer.style.width = `${page.width}px`;
    boardContainer.style.height = `${page.height}px`;

    if (page.bgImage) {
        boardContainer.style.backgroundImage = `url(${page.bgImage})`;
        boardContainer.style.backgroundSize = 'contain';
        boardContainer.style.backgroundPosition = 'center';
        boardContainer.style.backgroundRepeat = 'no-repeat';
        boardContainer.classList.remove('bg-grid');
    } else {
        boardContainer.style.backgroundImage = '';
        boardContainer.classList.add('bg-grid');
    }

    boardContainer.innerHTML = '<canvas id="drawingCanvas"></canvas>';
    initDrawingCanvas();

    page.items.forEach((item, index) => renderBoardItem(item, index));
    
    const indicator = document.getElementById('pageIndicator');
    if (indicator) {
        indicator.innerText = `${currentPageIndex + 1} / ${currentBoard.pages.length}`;
    }

    updateScrollAreaDimensions();
}

function updateScrollAreaDimensions() {
    const page = getCurrentPage();
    const scrollArea = document.getElementById('boardScrollArea');
    const scaleWrapper = document.getElementById('boardScaleWrapper');
    
    if (!page || !scrollArea || !scaleWrapper) return;

    const scaledWidth = page.width * currentScale;
    const scaledHeight = page.height * currentScale;

    scaleWrapper.style.transform = `scale(${currentScale})`;
    
    const padding = 20;
    scrollArea.style.width = `${scaledWidth + padding * 2}px`;
    scrollArea.style.height = `${scaledHeight + padding * 2}px`;
}

function fitBoardToViewport() {
    const wrapper = document.getElementById('mainCanvasWrapper');
    const page = getCurrentPage();
    if (!wrapper || !page) return;

    const padding = 40;
    const availWidth = wrapper.clientWidth - padding;
    const availHeight = wrapper.clientHeight - padding;

    if (availWidth > 0 && availHeight > 0) {
        const scaleX = availWidth / page.width;
        const scaleY = availHeight / page.height;
        currentScale = Math.min(scaleX, scaleY, 1.0);
        currentScale = Math.max(currentScale, 0.2);
    }
    updateScrollAreaDimensions();
}

function zoomIn() {
    const wrapper = document.getElementById('mainCanvasWrapper');
    if (!wrapper) return;
    const rect = wrapper.getBoundingClientRect();
    zoomAtPoint(rect.left + rect.width / 2, rect.top + rect.height / 2, Math.min(currentScale + 0.15, 4.0));
}

function zoomOut() {
    const wrapper = document.getElementById('mainCanvasWrapper');
    if (!wrapper) return;
    const rect = wrapper.getBoundingClientRect();
    zoomAtPoint(rect.left + rect.width / 2, rect.top + rect.height / 2, Math.max(currentScale - 0.15, 0.2));
}

function resetZoom() {
    fitBoardToViewport();
    const wrapper = document.getElementById('mainCanvasWrapper');
    if (wrapper) {
        wrapper.scrollLeft = (wrapper.scrollWidth - wrapper.clientWidth) / 2;
        wrapper.scrollTop = (wrapper.scrollHeight - wrapper.clientHeight) / 2;
    }
}

function zoomAtPoint(targetX, targetY, newScale) {
    if (newScale === currentScale) return;

    const wrapper = document.getElementById('mainCanvasWrapper');
    if (!wrapper) return;

    const wrapperRect = wrapper.getBoundingClientRect();
    const clickXRelativeToWrapper = targetX - wrapperRect.left + wrapper.scrollLeft;
    const clickYRelativeToWrapper = targetY - wrapperRect.top + wrapper.scrollTop;

    const oldScale = currentScale;
    currentScale = newScale;
    
    updateScrollAreaDimensions();

    const scaleFactor = currentScale / oldScale;
    
    wrapper.scrollLeft = clickXRelativeToWrapper * scaleFactor - (targetX - wrapperRect.left);
    wrapper.scrollTop = clickYRelativeToWrapper * scaleFactor - (targetY - wrapperRect.top);
}

function initPinchZoom() {
    const wrapper = document.getElementById('mainCanvasWrapper');
    if (!wrapper) return;
    
    let initialPinchDistance = null;
    let initialScale = 1.0;

    wrapper.addEventListener('touchstart', (e) => {
        if (e.touches.length === 2) {
            initialPinchDistance = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );
            initialScale = currentScale;
        }
    }, { passive: false });

    wrapper.addEventListener('touchmove', (e) => {
        if (e.touches.length === 2 && initialPinchDistance) {
            e.preventDefault();

            const touchCenterX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
            const touchCenterY = (e.touches[0].clientY + e.touches[1].clientY) / 2;

            const currentDistance = Math.hypot(
                e.touches[0].clientX - e.touches[1].clientX,
                e.touches[0].clientY - e.touches[1].clientY
            );

            if (currentDistance > 0) {
                const factor = currentDistance / initialPinchDistance;
                const newScale = Math.min(Math.max(initialScale * factor, 0.2), 4.0);
                zoomAtPoint(touchCenterX, touchCenterY, newScale);
            }
        }
    }, { passive: false });

    wrapper.addEventListener('touchend', (e) => {
        if (e.touches.length < 2) {
            initialPinchDistance = null;
        }
    });
}

function deleteCurrentCanvasPage() {
    if (currentBoard.pages.length <= 1) {
        showToast('キャンバスが1つしかないため削除できません。', 'warning');
        return;
    }
    document.getElementById('deleteConfirmModal')?.classList.remove('hidden');
}

function closeDeleteConfirmModal() {
    document.getElementById('deleteConfirmModal')?.classList.add('hidden');
}

function confirmDeleteCurrentPage() {
    saveStateForUndo();
    closeDeleteConfirmModal();
    if (interactionMode === 'draw' || interactionMode === 'erase') convertHandwritingToObject();

    currentBoard.pages.splice(currentPageIndex, 1);
    if (currentPageIndex >= currentBoard.pages.length) {
        currentPageIndex = currentBoard.pages.length - 1;
    }
    fitBoardToViewport();
    renderCurrentPage();
    showToast('キャンバスを削除しました。', 'info');
}

function prevPage() {
    if (currentPageIndex > 0) {
        if (interactionMode === 'draw' || interactionMode === 'erase') convertHandwritingToObject();
        currentPageIndex--;
        renderCurrentPage();
    }
}

function nextPage() {
    if (currentPageIndex < currentBoard.pages.length - 1) {
        if (interactionMode === 'draw' || interactionMode === 'erase') convertHandwritingToObject();
        currentPageIndex++;
        renderCurrentPage();
    }
}

async function handlePdfUpload(e) {
    const file = e.target.files[0];
    if (!file || typeof pdfjsLib === 'undefined') return;

    undoStack = [];

    const rawFileName = file.name.replace(/\.[^/.]+$/, "");
    currentBoard.importedPdfFileName = rawFileName;

    showToast('PDFを読み込んでいます...', 'info');

    try {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({
            data: arrayBuffer,
            cMapUrl: './lib/pdfjs/cmaps/',
            cMapPacked: true
        }).promise;

        currentBoard.pages = [];

        for (let i = 1; i <= pdf.numPages; i++) {
            const page = await pdf.getPage(i);
            const viewport = page.getViewport({ scale: 2.0 });

            const canvas = document.createElement('canvas');
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            const ctx = canvas.getContext('2d');

            await page.render({ canvasContext: ctx, viewport: viewport }).promise;

            const isLandscape = viewport.width >= viewport.height;
            const pageRatio = viewport.width / viewport.height;

            let boardW = isLandscape ? 1123 : Math.round(1123 * pageRatio);
            let boardH = isLandscape ? Math.round(1123 / pageRatio) : 1123;

            currentBoard.pages.push({
                orientation: isLandscape ? 'landscape' : 'portrait',
                width: boardW,
                height: boardH,
                bgImage: canvas.toDataURL('image/jpeg', 0.88),
                items: []
            });
        }

        currentPageIndex = 0;
        fitBoardToViewport();
        renderCurrentPage();
        showToast('PDFを取り込みました。', 'success');
    } catch (err) {
        showToast('PDFの取り込みに失敗しました。', 'error');
    }
    e.target.value = '';
}

function exportToJSON() {
    if (interactionMode === 'draw' || interactionMode === 'erase') convertHandwritingToObject();
    
    const fileName = promptExportFileName();
    if (fileName === null) return;

    const blob = new Blob([JSON.stringify(currentBoard, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('JSONファイルを保存しました。', 'success');
}

function importFromJSON(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
        try {
            const data = JSON.parse(evt.target.result);
            if (data && data.pages) {
                undoStack = [];
                currentBoard = data;
                currentPageIndex = 0;
                fitBoardToViewport();
                renderCurrentPage();
                showToast('JSONデータを読み込みました。', 'success');
            }
        } catch (err) {
            showToast('JSONの読み込みに失敗しました。', 'error');
        }
    };
    reader.readAsText(file);
    e.target.value = '';
}

async function generatePageImageDataUrl(page) {
    const canvas = document.createElement('canvas');
    canvas.width = page.width;
    canvas.height = page.height;
    const ctx = canvas.getContext('2d');

    if (page.bgImage) {
        const bgImg = new Image();
        bgImg.src = page.bgImage;
        await new Promise(r => bgImg.onload = r);
        ctx.drawImage(bgImg, 0, 0, page.width, page.height);
    } else {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, page.width, page.height);
    }

    for (const item of page.items) {
        if (item.type === 'text') {
            ctx.save();
            ctx.fillStyle = 'rgba(255,255,255,0.9)';
            ctx.fillRect(item.x, item.y, item.width, item.height);
            ctx.strokeStyle = '#cbd5e1';
            ctx.strokeRect(item.x, item.y, item.width, item.height);
            ctx.fillStyle = '#0f172a';
            ctx.font = '16px "M PLUS Rounded 1c", sans-serif';
            ctx.fillText(item.text, item.x + 8, item.y + 24);
            ctx.restore();
        } else if (item.type === 'image' || item.type === 'shape') {
            const img = new Image();
            img.src = item.src;
            await new Promise(r => img.onload = r);
            ctx.drawImage(img, item.x, item.y, item.width, item.height);
        }
    }
    return canvas.toDataURL('image/jpeg', 0.92);
}

async function exportToPDF() {
    if (interactionMode === 'draw' || interactionMode === 'erase') convertHandwritingToObject();
    if (typeof window.jspdf === 'undefined') return;

    const fileName = promptExportFileName();
    if (fileName === null) return;

    showToast('PDFを出力中...', 'info');

    try {
        const { jsPDF } = window.jspdf;
        let pdf = null;

        for (let i = 0; i < currentBoard.pages.length; i++) {
            const page = currentBoard.pages[i];
            const imgData = await generatePageImageDataUrl(page);
            const orientation = page.width > page.height ? 'landscape' : 'portrait';

            if (i === 0) {
                pdf = new jsPDF({ orientation: orientation, unit: 'px', format: [page.width, page.height] });
            } else {
                pdf.addPage([page.width, page.height], orientation);
            }
            pdf.addImage(imgData, 'JPEG', 0, 0, page.width, page.height);
        }
        pdf.save(`${fileName}.pdf`);
        showToast('PDFを出力しました。', 'success');
    } catch (err) {
        showToast('PDF出力に失敗しました。', 'error');
    }
}

function initKeyboardShortcuts() {
    window.addEventListener('keydown', (e) => {
        // F11キーでフルスクリーンのトグル切替
        if (e.key === 'F11') {
            e.preventDefault();
            toggleFullScreen();
        }
    });

    // フルスクリーン状態変更時のビューポート調整
    document.addEventListener('fullscreenchange', () => {
        setTimeout(() => {
            fitBoardToViewport();
            initDrawingCanvas();
            updateScrollAreaDimensions();
        }, 100);
    });
}

function toggleFullScreen() {
    if (!document.fullscreenElement && 
        !document.webkitFullscreenElement && 
        !document.msFullscreenElement) {
        const docEl = document.documentElement;
        if (docEl.requestFullscreen) {
            docEl.requestFullscreen();
        } else if (docEl.webkitRequestFullscreen) {
            docEl.webkitRequestFullscreen();
        } else if (docEl.msRequestFullscreen) {
            docEl.msRequestFullscreen();
        }
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }
}