const $ = id => document.getElementById(id);
const API = "https://api.alquran.cloud/v1";
let currentSurah = 1;
let surahs = [];
let deferredInstall = null;
let currentAyahText = "";
let currentAyahNumber = 1;

function toast(message){const t=$("toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
$("themeToggle").addEventListener("click",()=>{document.body.classList.toggle("dark");localStorage.setItem("noor-theme",document.body.classList.contains("dark")?"dark":"light")});
if(localStorage.getItem("noor-theme")==="dark")document.body.classList.add("dark");
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;$("installBtn").hidden=false});
$("installBtn").addEventListener("click",async()=>{if(!deferredInstall)return;deferredInstall.prompt();await deferredInstall.userChoice;deferredInstall=null;$("installBtn").hidden=true});

async function loadSurahMenu(){
 try{
  const r=await fetch(`${API}/surah`);if(!r.ok)throw Error();const j=await r.json();surahs=j.data;
  fillListenSurahs();
  $("surahSelect").innerHTML=surahs.map(s=>`<option value="${s.number}">${s.number}. ${s.name} — ${s.englishName}</option>`).join("");
  const last=Number(localStorage.getItem("noor-last-surah")||1);$("surahSelect").value=last;
  await displaySurah(last);
 }catch(e){$("surahSelect").innerHTML='<option>تعذر تحميل السور - تحقق من الإنترنت</option>';toast("تعذر الاتصال بمصدر القرآن")}
}
async function displaySurah(n){
 currentSurah=Number(n);$("surahMeta").textContent="جاري تحميل السورة...";
 try{
  const r=await fetch(`${API}/surah/${currentSurah}/quran-uthmani`);if(!r.ok)throw Error();const j=await r.json();const s=j.data;
  $("surahMeta").textContent=`${s.name} · ${s.numberOfAyahs} آية · ${s.revelationType==="Meccan"?"مكية":"مدنية"}`;
  $("bismillah").style.display=[1,9].includes(currentSurah)?"none":"block";
  $("ayahContainer").innerHTML=s.ayahs.map(a=>`<span class="ayah" data-num="${a.numberInSurah}" data-text="${a.text.replace(/&/g,"&amp;").replace(/"/g,"&quot;")}">${a.text} <span class="ayah-number">۞ ${a.numberInSurah}</span> </span>`).join("");
  currentAyahNumber=1; currentAyahText=s.ayahs[0]?.text||"";
  localStorage.setItem("noor-last-surah",currentSurah);
  $("ayahContainer").querySelectorAll(".ayah").forEach(el=>el.addEventListener("click",()=>{ $("ayahContainer").querySelectorAll(".ayah").forEach(x=>x.classList.remove("selected"));el.classList.add("selected");currentAyahNumber=Number(el.dataset.num);currentAyahText=el.childNodes[0].textContent.trim(); }));
  $("audioLabel").textContent=`سورة ${s.name} · ${$("readerSelect").selectedOptions[0].text}`;setSurahAudio();
 }catch(e){$("surahMeta").textContent="تعذر تحميل السورة. حاول مرة أخرى."}
}
$("loadSurah").addEventListener("click",()=>displaySurah($("surahSelect").value));
$("saveLast").addEventListener("click",()=>{localStorage.setItem("noor-last-surah",currentSurah);toast("تم حفظ آخر سورة وصلت إليها")});
$("readerSelect").addEventListener("change",()=>{$("audioLabel").textContent="القارئ: "+$("readerSelect").selectedOptions[0].text});
let surahAudioEditions = [];
let reciterAudioCatalog = [];
let listenQueue = [];
let listenQueueIndex = 0;

function getEdition(value){return reciterAudioCatalog.find(x=>String(x.key)===String(value));}
function editionHasSurah(edition,surah){return !!edition && edition.surahs.includes(Number(surah));}
function surahAudioUrl(editionValue,surah){
 const edition=typeof editionValue==="object"?editionValue:getEdition(editionValue);
 if(!edition || !editionHasSurah(edition,surah))return "";
 return `${edition.server}${String(surah).padStart(3,"0")}.mp3`;
}
function editionLabel(x){return x.reciterName;}
function fillEditionSelect(id,selectedValue,query=""){
 const el=$(id);if(!el)return;
 const q=String(query||"").trim().toLocaleLowerCase("ar");
 const list=reciterAudioCatalog.filter(x=>!q||x.reciterName.toLocaleLowerCase("ar").includes(q));
 el.innerHTML=list.map(x=>`<option value="${x.key}">${x.reciterName.replace(/</g,"&lt;")}</option>`).join("");
 if(selectedValue!=null && list.some(x=>String(x.key)===String(selectedValue)))el.value=String(selectedValue);
 if(!list.length)el.innerHTML='<option value="">لا توجد نتائج مطابقة</option>';
}
function bindReciterSearch(inputId,selectId){
 const input=$(inputId),select=$(selectId);if(!input||!select)return;
 input.addEventListener("input",()=>{
  const previous=select.value;
  fillEditionSelect(selectId,previous,input.value);
  if(selectId==="readerSelect")setSurahAudio();
  else updateListenAvailability();
 });
}
async function loadAudioEditions(){
 try{
  const r=await fetch("./reciters.json");if(!r.ok)throw Error(`HTTP ${r.status}`);
  const data=await r.json();
  if(!Array.isArray(data.reciters))throw Error("تنسيق ملف القراء غير صحيح");
  let key=0;reciterAudioCatalog=[];
  const required=Array.from({length:114},(_,i)=>i+1);
  for(const reciter of data.reciters){
   // نعرض تسجيلًا واحدًا فقط لكل شيخ، ولا نقبل إلا التسجيل الذي يعلن صراحةً اكتمال السور الـ114.
   const complete=(reciter.moshaf||[]).map(m=>{
    const surahs=[...new Set(String(m.surah_list||"").split(",").map(Number).filter(n=>Number.isInteger(n)&&n>=1&&n<=114))];
    return {...m,_surahs:surahs};
   }).filter(m=>m.server && m._surahs.length===114 && required.every(n=>m._surahs.includes(n)) && Number(m.surah_total||114)===114);
   if(!complete.length)continue;
   // عند وجود أكثر من تسجيل كامل لنفس الشيخ نختار حفص إن توفر، وإلا أول تسجيل كامل.
   const chosen=complete.find(m=>/حفص|hafs/i.test(m.name||""))||complete[0];
   const server=String(chosen.server).trim();
   reciterAudioCatalog.push({key:key++,reciterId:reciter.id,reciterName:reciter.name,moshafId:chosen.id,moshafName:chosen.name||"تلاوة",server:server.endsWith("/")?server:server+"/",surahs:required.slice()});
  }
  if(!reciterAudioCatalog.length)throw Error("لم يتم العثور على تسجيلات مكتملة للسور الـ114");
  fillEditionSelect("readerSelect");fillEditionSelect("listenReader");
  bindReciterSearch("readerSearch","readerSelect");
  bindReciterSearch("listenReaderSearch","listenReader");
  setSurahAudio();
  $("audioStatus").textContent=`تم التحقق من بيانات التغطية: ${reciterAudioCatalog.length} شيخًا، ولكل واحد قائمة السور الـ114 كاملة.`;
  updateListenAvailability();
 }catch(e){
  reciterAudioCatalog=[];
  $("audioStatus").textContent=`تعذر تحميل ملف reciters.json: ${e.message}. تأكد أنه موجود بجانب index.html.`;
  $("listenStatus").textContent="تعذر تحميل قائمة القراء. تأكد من وجود ملف reciters.json بجانب التطبيق.";
 }
}
function setSurahAudio(){
 const edition=getEdition($("readerSelect").value),audio=$("quranAudio");
 if(!edition){$("audioStatus").textContent="قائمة القراء غير جاهزة.";return;}
 if(!editionHasSurah(edition,currentSurah)){
  audio.pause();audio.removeAttribute("src");audio.load();
  $("audioLabel").textContent=`${editionLabel(edition)} — السورة غير متاحة`;
  $("audioStatus").textContent="التسجيل المختار لا يحتوي على هذه السورة. اختر قارئًا أو رواية أخرى.";return;
 }
 audio.pause();audio.src=surahAudioUrl(edition,currentSurah);audio.load();
 $("audioLabel").textContent=`سورة ${surahs.find(x=>x.number===currentSurah)?.name||currentSurah} · ${editionLabel(edition)}`;
 $("audioStatus").textContent="تم تجهيز رابط التلاوة من مكتبة MP3Quran؛ اضغط تشغيل.";
}
function updateListenAvailability(){
 const edition=getEdition($("listenReader").value);const surahSelect=$("listenSurah");
 if(!edition||!surahSelect)return;
 const available=edition.surahs;
 [...surahSelect.options].forEach(o=>{o.disabled=!available.includes(Number(o.value));});
 if(!available.includes(Number(surahSelect.value))&&available.length)surahSelect.value=String(available[0]);
 $("listenStatus").textContent=`${edition.reciterName}: متاح ${available.length} سورة من أصل 114.`;
}
$("loadSurah").addEventListener("click",setSurahAudio);
$("readerSelect").addEventListener("change",setSurahAudio);
$("quranAudio").addEventListener("error",()=>{$("audioStatus").textContent="تعذر تشغيل التسجيل حاليًا. قد يكون الرابط غير متاح مؤقتًا؛ جرّب تسجيلًا آخر.";toast("تعذر تشغيل التلاوة حاليًا")});
$("quranAudio").addEventListener("canplay",()=>{$("audioStatus").textContent="التلاوة جاهزة للتشغيل ✓"});

$("copySelected").onclick=async()=>{if(!currentAyahText){toast("اختار آية الأول");return}try{await navigator.clipboard.writeText(currentAyahText);toast("تم نسخ الآية")}catch(e){toast("ميزة النسخ غير متاحة في هذا المتصفح")}};
$("bookmarkSelected").onclick=()=>{if(!currentAyahText){toast("اختار آية الأول");return}const list=JSON.parse(localStorage.getItem("noor-bookmarks")||"[]");const item={surah:currentSurah,ayah:currentAyahNumber,text:currentAyahText};if(!list.some(x=>x.surah===item.surah&&x.ayah===item.ayah))list.push(item);localStorage.setItem("noor-bookmarks",JSON.stringify(list));toast("اتحفظت الآية في علاماتك ★")};
$("showBookmarks").onclick=()=>{const list=JSON.parse(localStorage.getItem("noor-bookmarks")||"[]");if(!list.length){toast("لسه مفيش آيات محفوظة");return}alert(list.map(x=>`سورة رقم ${x.surah} · آية ${x.ayah}\n${x.text}`).join("\n\n"))};

$("downloadAudio").addEventListener("click",async()=>{
 const url=$("quranAudio").src;if(!url){toast("اختر سورة أولًا");return}
 try{const a=document.createElement("a");a.href=url;a.download=`NOOR-surah-${currentSurah}.mp3`;document.body.appendChild(a);a.click();a.remove();toast("بدأ تنزيل التلاوة")}
 catch(e){toast("تعذر تنزيل الصوت من هذا المتصفح")}
});

const azkarData={
 morning:[
 ["أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.","مرة واحدة","أبو داود"],
 ["اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ.","مرة واحدة","الترمذي"],
 ["سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.","١٠٠ مرة","صحيح مسلم"],
 ["اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ.","مرة واحدة","أبو داود"]
 ],
 evening:[
 ["أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.","مرة واحدة","أبو داود"],
 ["اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ.","مرة واحدة","الترمذي"],
 ["أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.","٣ مرات","صحيح مسلم"],
 ["سُبْحَانَ اللَّهِ وَبِحَمْدِهِ.","١٠٠ مرة","صحيح مسلم"]
 ],
 sleep:[
 ["بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.","مرة واحدة","صحيح البخاري"],
 ["اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ.","٣ مرات","أبو داود"],
 ["سُبْحَانَ اللَّهِ.","٣٣ مرة","صحيح البخاري"]
 ],
 after:[
 ["أَسْتَغْفِرُ اللَّهَ.","٣ مرات","صحيح مسلم"],
 ["اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ.","مرة واحدة","صحيح مسلم"],
 ["سُبْحَانَ اللَّهِ.","٣٣ مرة","صحيح مسلم"],
 ["الْحَمْدُ لِلَّهِ.","٣٣ مرة","صحيح مسلم"],
 ["اللَّهُ أَكْبَرُ.","٣٣ مرة","صحيح مسلم"]
 ]
};
function renderAzkar(kind){
 $("azkarList").innerHTML=azkarData[kind].map((z,i)=>`<article class="zikr"><p>${z[0]}</p><div class="zikr-bottom"><small>${z[2]} · ${z[1]}</small><button class="count-btn" data-count="${i}" data-total="${parseInt(z[1])||1}">تم ٠ / ${z[1]}</button></div></article>`).join("");
 $("azkarList").querySelectorAll(".count-btn").forEach(btn=>{let c=0;btn.addEventListener("click",()=>{c++;btn.textContent=`تم ${c} / ${btn.dataset.total}`;if(c>=Number(btn.dataset.total)){btn.textContent="اكتمل ✓";btn.disabled=true}})});
}
$("azkarTabs").addEventListener("click",e=>{if(!e.target.dataset.kind)return;$("azkarTabs").querySelectorAll("button").forEach(b=>b.classList.toggle("active",b===e.target));renderAzkar(e.target.dataset.kind)});
renderAzkar("morning");

const names=["الرَّحْمَٰن","الرَّحِيم","الْمَلِك","الْقُدُّوس","السَّلَام","الْمُؤْمِن","الْمُهَيْمِن","الْعَزِيز","الْجَبَّار","الْمُتَكَبِّر","الْخَالِق","الْبَارِئ","الْمُصَوِّر","الْغَفَّار","الْقَهَّار","الْوَهَّاب","الرَّزَّاق","الْفَتَّاح","الْعَلِيم","الْقَابِض","الْبَاسِط","الْخَافِض","الرَّافِع","الْمُعِزّ","الْمُذِلّ","السَّمِيع","الْبَصِير","الْحَكَم","الْعَدْل","اللَّطِيف","الْخَبِير","الْحَلِيم","الْعَظِيم","الْغَفُور","الشَّكُور","الْعَلِيّ","الْكَبِير","الْحَفِيظ","الْمُقِيت","الْحَسِيب","الْجَلِيل","الْكَرِيم","الرَّقِيب","الْمُجِيب","الْوَاسِع","الْحَكِيم","الْوَدُود","الْمَجِيد","الْبَاعِث","الشَّهِيد","الْحَقّ","الْوَكِيل","الْقَوِيّ","الْمَتِين","الْوَلِيّ","الْحَمِيد","الْمُحْصِي","الْمُبْدِئ","الْمُعِيد","الْمُحْيِي","الْمُمِيت","الْحَيّ","الْقَيُّوم","الْوَاجِد","الْمَاجِد","الْوَاحِد","الصَّمَد","الْقَادِر","الْمُقْتَدِر","الْمُقَدِّم","الْمُؤَخِّر","الأَوَّل","الآخِر","الظَّاهِر","الْبَاطِن","الْوَالِي","الْمُتَعَالِي","الْبَرّ","التَّوَّاب","الْمُنْتَقِم","العَفُوّ","الرَّؤُوف","مَالِكُ الْمُلْك","ذُو الْجَلَالِ وَالإِكْرَام","الْمُقْسِط","الْجَامِع","الْغَنِيّ","الْمُغْنِي","الْمَانِع","الضَّارّ","النَّافِع","النُّور","الْهَادِي","الْبَدِيع","الْبَاقِي","الْوَارِث","الرَّشِيد","الصَّبُور"];
$("namesGrid").innerHTML=names.map((n,i)=>`<div class="name-item">${n}<small>${i+1}</small></div>`).join("");

const hadiths=[
 ["إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى.","صحيح البخاري وصحيح مسلم"],
 ["مَنْ لَا يَرْحَمُ لَا يُرْحَمُ.","صحيح البخاري وصحيح مسلم"],
 ["لَا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ.","صحيح البخاري وصحيح مسلم"],
 ["الْكَلِمَةُ الطَّيِّبَةُ صَدَقَةٌ.","صحيح البخاري وصحيح مسلم"],
 ["مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ.","صحيح مسلم"]
];
let hi=0;$("anotherHadith").onclick=()=>{hi=(hi+1)%hadiths.length;$("hadithText").textContent="«"+hadiths[hi][0]+"»";$("hadithSource").textContent=hadiths[hi][1]};

const prayerNames={Fajr:"الفجر",Dhuhr:"الظهر",Asr:"العصر",Maghrib:"المغرب",Isha:"العشاء"};
async function getPrayer(lat,lon,city="موقعك"){
 try{
  const date=new Date(),stamp=`${date.getDate()}-${date.getMonth()+1}-${date.getFullYear()}`;
  const r=await fetch(`https://api.aladhan.com/v1/timings/${stamp}?latitude=${lat}&longitude=${lon}&method=5`);
  const j=await r.json();if(j.code!==200)throw Error();const t=j.data.timings;
  $("prayerCity").textContent=city;
  $("prayerTimes").innerHTML=Object.entries(prayerNames).map(([k,v])=>`<span>${v} ${t[k]}</span>`).join("");
  const now=new Date(),mins=now.getHours()*60+now.getMinutes();
  let next=Object.keys(prayerNames).find(k=>{const [h,m]=t[k].split(" ")[0].split(":").map(Number);return h*60+m>mins});
  if(!next)next="Fajr";
  $("nextPrayerName").textContent="الصلاة القادمة: "+prayerNames[next];
  $("nextPrayerTime").textContent=t[next].split(" ")[0];
 }catch(e){$("prayerTimes").textContent="تعذر تحميل المواقيت حاليًا."}
}
function locate(){
 if(!navigator.geolocation){toast("المتصفح لا يدعم تحديد الموقع");return}
 $("locateBtn").textContent="جاري تحديد الموقع...";
 navigator.geolocation.getCurrentPosition(p=>{getPrayer(p.coords.latitude,p.coords.longitude);$("locateBtn").textContent="تحديث موقعي ↻";calculateQibla(p.coords.latitude,p.coords.longitude)},()=>{$("locateBtn").textContent="تحديث موقعي ↻";toast("اسمح للموقع بالوصول إلى موقعك أو تحقق من إعدادات الجهاز")},{enableHighAccuracy:true,timeout:12000});
}
$("locateBtn").onclick=locate;$("qiblaBtn").onclick=locate;
function calculateQibla(lat,lon){
 const kaabaLat=21.4225*Math.PI/180,kaabaLon=39.8262*Math.PI/180,phi=lat*Math.PI/180,lam=lon*Math.PI/180;
 const y=Math.sin(kaabaLon-lam),x=Math.cos(phi)*Math.tan(kaabaLat)-Math.sin(phi)*Math.cos(kaabaLon-lam);
 const deg=(Math.atan2(y,x)*180/Math.PI+360)%360;
 $("qiblaDegree").textContent=Math.round(deg)+"°";
 $("qiblaMessage").textContent="اتجه نحو السهم بالنسبة للشمال الحقيقي.";
 $("compassArrow").style.transform=`rotate(${deg}deg)`;
}
function loadDailyVerse(){
 const verses=[["إِنَّ مَعَ الْعُسْرِ يُسْرًا","الشرح · ٦"],["فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ","البقرة · ١٨٦"],["أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ","الرعد · ٢٨"],["وَهُوَ مَعَكُمْ أَيْنَ مَا كُنْتُمْ","الحديد · ٤"],["لَا تَقْنَطُوا مِنْ رَحْمَةِ اللَّهِ","الزمر · ٥٣"]];
 const v=verses[Math.floor(Math.random()*verses.length)];$("dailyVerse").textContent=v[0];$("dailyVerseRef").textContent="سورة "+v[1];
}
$("newVerse").onclick=loadDailyVerse;loadDailyVerse();loadSurahMenu();loadAudioEditions().then(initListen);
getPrayer(30.1286,31.2422,"القاهرة الكبرى"); // قيمة افتراضية مؤقتة حتى يحدد المستخدم موقعه
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}))}

// قائمة جانبية وأقسام مستقلة
const pageGroups={
 home:["hero","daily-grid","features"], quran:["quran"], listen:["listen"], radio:["radio"], azkar:["azkar"],
 duas:["duas"], qibla:["qibla"], names:["names"], hadith:["hadith"], tasbeeh:["tasbeeh"], ai:["ai"]
};
function showPage(page){
 const chosen=pageGroups[page]?page:"home";
 document.querySelectorAll("main > section").forEach(el=>el.classList.toggle("page-hidden",!pageGroups[chosen].includes(el.id)));
 document.querySelectorAll(".drawer-link").forEach(b=>b.classList.toggle("active",b.dataset.page===chosen));
 closeMenu(); window.scrollTo({top:0,behavior:"smooth"});
}
function openMenu(){ $("sideDrawer").classList.add("open");$("drawerBackdrop").classList.add("show");$("menuToggle").setAttribute("aria-expanded","true"); }
function closeMenu(){ const d=$("sideDrawer");if(!d)return;d.classList.remove("open");$("drawerBackdrop").classList.remove("show");$("menuToggle").setAttribute("aria-expanded","false"); }
$("menuToggle").addEventListener("click",openMenu);$("closeDrawer").addEventListener("click",closeMenu);$("drawerBackdrop").addEventListener("click",closeMenu);
document.querySelectorAll(".drawer-link").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
document.querySelectorAll("a[href^='#']").forEach(a=>a.addEventListener("click",e=>{
 const target=a.getAttribute("href").slice(1);
 if(pageGroups[target]){e.preventDefault();showPage(target);return;}
}));
showPage("home");

// قسم الاستماع: قوائم السور والقراء تُبنى من مصدر الصوت المتاح.
function fillListenSurahs(){const el=$("listenSurah");if(el&&surahs.length){el.innerHTML=surahs.map(s=>`<option value="${s.number}">${s.number}. ${s.name}</option>`).join("");if(reciterAudioCatalog.length)updateListenAvailability();}}
function initListen(){
 const surahSelect=$("listenSurah");
 fillListenSurahs();
 $("listenScope").addEventListener("change",()=>{$("listenSurahWrap").hidden=$("listenScope").value==="all"});
 $("listenReader").addEventListener("change",updateListenAvailability);
 surahSelect.addEventListener("change",()=>{
  const ed=getEdition($("listenReader").value);
  if(ed&&!editionHasSurah(ed,Number(surahSelect.value)))updateListenAvailability();
 });
 $("startListen").onclick=()=>{
  const scope=$("listenScope").value,selected=Number(surahSelect.value),edition=getEdition($("listenReader").value);
  if(!edition){toast("قائمة القراء غير جاهزة");return;}
  listenQueue=scope==="all"?edition.surahs.slice():[selected].filter(n=>editionHasSurah(edition,n));listenQueueIndex=0;
  if(!listenQueue.length){toast("السورة غير متاحة لهذا التسجيل");return;}
  playListenQueueItem(edition.key);
 };
 $("downloadSelected").onclick=()=>{
  const edition=getEdition($("listenReader").value),surah=Number(surahSelect.value);if(!edition){toast("اختار قارئًا أولًا");return;}
  const url=surahAudioUrl(edition,surah);if(!url){toast("السورة غير متاحة في التسجيل المختار");return;}
  const a=document.createElement("a");a.href=url;a.target="_blank";a.rel="noopener";a.download=`NOOR-${String(surah).padStart(3,"0")}-${edition.reciterName}.mp3`;document.body.appendChild(a);a.click();a.remove();
  $("listenStatus").textContent="تم فتح ملف التلاوة من مصدر MP3Quran؛ قد يعرضه المتصفح بدل تنزيله.";
 };
 $("downloadPlan").onclick=()=>{
  const edition=getEdition($("listenReader").value);
  const editions=[edition].filter(Boolean);
  if(!editions.length){toast("اختار الشيخ أولًا");return;}
  const scope=$("listenScope").value,surah=Number(surahSelect.value);
  const jobs=editions.flatMap(ed=>(scope==="all"?ed.surahs:[surah].filter(n=>editionHasSurah(ed,n))).map(n=>({edition:ed,surah:n})));
  const total=jobs.length;if(!total){toast("لا توجد سور متاحة للتنزيل بالاختيارات الحالية");return;}
  if(total>1&&!confirm(`سيتم إرسال ${total} طلب تنزيل لهذا الشيخ. التنزيل المتعدد قد يتطلب سماح المتصفح ويستهلك بيانات ومساحة. هل تريد المتابعة؟`))return;
  let i=0;const box=$("downloadProgress");box.hidden=false;
  const next=()=>{if(i>=total){box.textContent=`انتهى إرسال طلبات التنزيل (${total} ملف). راجع إشعارات التنزيلات في المتصفح.`;return;}
   const job=jobs[i],a=document.createElement("a");a.href=surahAudioUrl(job.edition,job.surah);a.target="_blank";a.rel="noopener";a.download=`NOOR-${String(job.surah).padStart(3,"0")}-${job.edition.reciterName}.mp3`;document.body.appendChild(a);a.click();a.remove();i++;
   box.textContent=`تم إرسال ${i} من ${total} طلب تنزيل...`;setTimeout(next,1400);
  };next();
 };
}
function playListenQueueItem(editionKey){
 const audio=$("listenAudio"),surah=listenQueue[listenQueueIndex],edition=getEdition(editionKey);if(!surah||!edition)return;
 const url=surahAudioUrl(edition,surah);if(!url){$("listenStatus").textContent="السورة غير متاحة لهذا التسجيل.";return;}
 audio.pause();audio.src=url;audio.load();
 const name=surahs.find(x=>x.number===surah)?.name||`رقم ${surah}`;
 $("listenTitle").textContent=`سورة ${name} · ${editionLabel(edition)}`;
 $("listenStatus").textContent=`السورة ${listenQueueIndex+1} من ${listenQueue.length} · جاري تجهيز التلاوة`;
 audio.play().then(()=>$("listenStatus").textContent=`تعمل الآن: ${name} (${listenQueueIndex+1}/${listenQueue.length})`).catch(()=>$("listenStatus").textContent="لم يبدأ التشغيل تلقائيًا. اضغط تشغيل من المشغل.");
}
$("listenAudio").addEventListener("ended",()=>{if(listenQueueIndex<listenQueue.length-1){listenQueueIndex++;playListenQueueItem($("listenReader").value);}else{$("listenStatus").textContent="انتهت التلاوة المختارة. جزاك الله خيرًا.";}});


// مكتبة الأدعية: نصوص قرآنية ونبوية مع مصادرها وتصنيفاتها.
const duaItems=[
{c:"أدعية قرآنية",t:"رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",s:"سورة البقرة، الآية 201"},
{c:"أدعية قرآنية",t:"رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً إِنَّكَ أَنْتَ الْوَهَّابُ",s:"سورة آل عمران، الآية 8"},
{c:"أدعية قرآنية",t:"رَبِّ زِدْنِي عِلْمًا",s:"سورة طه، الآية 114"},
{c:"أدعية قرآنية",t:"رَبِّ اشْرَحْ لِي صَدْرِي ۝ وَيَسِّرْ لِي أَمْرِي",s:"سورة طه، الآيتان 25–26"},
{c:"أدعية قرآنية",t:"رَبَّنَا ظَلَمْنَا أَنْفُسَنَا وَإِنْ لَمْ تَغْفِرْ لَنَا وَتَرْحَمْنَا لَنَكُونَنَّ مِنَ الْخَاسِرِينَ",s:"سورة الأعراف، الآية 23"},
{c:"أدعية قرآنية",t:"رَبَّنَا أَفْرِغْ عَلَيْنَا صَبْرًا وَتَوَفَّنَا مُسْلِمِينَ",s:"سورة الأعراف، الآية 126"},
{c:"أدعية قرآنية",t:"رَبِّ أَوْزِعْنِي أَنْ أَشْكُرَ نِعْمَتَكَ الَّتِي أَنْعَمْتَ عَلَيَّ وَعَلَىٰ وَالِدَيَّ وَأَنْ أَعْمَلَ صَالِحًا تَرْضَاهُ",s:"سورة النمل، الآية 19"},
{c:"أدعية قرآنية",t:"رَبَّنَا هَبْ لَنَا مِنْ أَزْوَاجِنَا وَذُرِّيَّاتِنَا قُرَّةَ أَعْيُنٍ وَاجْعَلْنَا لِلْمُتَّقِينَ إِمَامًا",s:"سورة الفرقان، الآية 74"},
{c:"أدعية قرآنية",t:"رَبِّ اغْفِرْ وَارْحَمْ وَأَنْتَ خَيْرُ الرَّاحِمِينَ",s:"سورة المؤمنون، الآية 118"},
{c:"أذكار الصباح والمساء",t:"أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ",s:"صحيح مسلم، 2723 (ورد الصباح، وله لفظ للمساء)"},
{c:"أذكار الصباح والمساء",t:"اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا وَبِكَ نَحْيَا وَبِكَ نَمُوتُ وَإِلَيْكَ النُّشُورُ",s:"سنن أبي داود والترمذي"},
{c:"أذكار الصباح والمساء",t:"بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",s:"سنن أبي داود والترمذي"},
{c:"أذكار الصباح والمساء",t:"رَضِيتُ بِاللَّهِ رَبًّا وَبِالْإِسْلَامِ دِينًا وَبِمُحَمَّدٍ ﷺ نَبِيًّا",s:"سنن أبي داود والترمذي"},
{c:"أدعية الاستغفار والتوبة",t:"اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ... فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",s:"صحيح البخاري، 6306 (سيد الاستغفار؛ النص مختصر هنا)"},
{c:"أدعية الاستغفار والتوبة",t:"رَبَّنَا اغْفِرْ لَنَا ذُنُوبَنَا وَإِسْرَافَنَا فِي أَمْرِنَا وَثَبِّتْ أَقْدَامَنَا",s:"سورة آل عمران، الآية 147"},
{c:"أدعية الكرب والهم",t:"لَا إِلَهَ إِلَّا أَنْتَ سُبْحَانَكَ إِنِّي كُنْتُ مِنَ الظَّالِمِينَ",s:"سورة الأنبياء، الآية 87"},
{c:"أدعية الكرب والهم",t:"اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْهَمِّ وَالْحَزَنِ، وَالْعَجْزِ وَالْكَسَلِ، وَالْجُبْنِ وَالْبُخْلِ، وَضَلَعِ الدَّيْنِ وَغَلَبَةِ الرِّجَالِ",s:"صحيح البخاري، 6369"},
{c:"أدعية الكرب والهم",t:"اللَّهُمَّ رَحْمَتَكَ أَرْجُو فَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ، وَأَصْلِحْ لِي شَأْنِي كُلَّهُ",s:"سنن أبي داود، 5090"},
{c:"أدعية الرزق",t:"اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا وَرِزْقًا طَيِّبًا وَعَمَلًا مُتَقَبَّلًا",s:"سنن ابن ماجه، 925"},
{c:"أدعية الرزق",t:"اللَّهُمَّ اكْفِنِي بِحَلَالِكَ عَنْ حَرَامِكَ، وَأَغْنِنِي بِفَضْلِكَ عَمَّنْ سِوَاكَ",s:"سنن الترمذي، 3563"},
{c:"أدعية العلم والدراسة",t:"رَبِّ زِدْنِي عِلْمًا",s:"سورة طه، الآية 114"},
{c:"أدعية العلم والدراسة",t:"اللَّهُمَّ انْفَعْنِي بِمَا عَلَّمْتَنِي، وَعَلِّمْنِي مَا يَنْفَعُنِي، وَزِدْنِي عِلْمًا",s:"سنن الترمذي، 3599"},
{c:"أدعية الوالدين والأسرة",t:"رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا",s:"سورة الإسراء، الآية 24"},
{c:"أدعية الوالدين والأسرة",t:"رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ",s:"سورة إبراهيم، الآية 41"},
{c:"أدعية الشفاء",t:"أَذْهِبِ الْبَاسَ رَبَّ النَّاسِ، اشْفِ وَأَنْتَ الشَّافِي، لَا شِفَاءَ إِلَّا شِفَاؤُكَ، شِفَاءً لَا يُغَادِرُ سَقَمًا",s:"صحيح البخاري، 5675؛ صحيح مسلم، 2191"},
{c:"أدعية السفر",t:"سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَىٰ رَبِّنَا لَمُنْقَلِبُونَ",s:"سورة الزخرف، الآيتان 13–14؛ من دعاء السفر"},
{c:"أدعية النوم",t:"بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",s:"صحيح البخاري، 6324"},
{c:"أدعية الاستيقاظ",t:"الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ",s:"صحيح البخاري، 6312"},
{c:"أدعية الطعام والشراب",t:"بِسْمِ اللَّهِ",s:"صحيح البخاري، 5376؛ عند بدء الطعام"},
{c:"أدعية الطعام والشراب",t:"الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ",s:"سنن أبي داود، 4023؛ حسن"},
{c:"أدعية عامة",t:"اللَّهُمَّ أَعِنِّي عَلَى ذِكْرِكَ وَشُكْرِكَ وَحُسْنِ عِبَادَتِكَ",s:"سنن أبي داود، 1522؛ صحيح"},
{c:"أدعية عامة",t:"اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى وَالتُّقَى وَالْعَفَافَ وَالْغِنَى",s:"صحيح مسلم، 2721"},
{c:"أدعية عامة",t:"يَا مُقَلِّبَ الْقُلُوبِ، ثَبِّتْ قَلْبِي عَلَى دِينِكَ",s:"سنن الترمذي، 2140"}
];
function renderDuas(){
 const list=$("duaList"),cat=$("duaCategory"),search=$("duaSearch");if(!list||!cat)return;
 const cats=[...new Set(duaItems.map(x=>x.c))];
 if(!cat.dataset.ready){cat.innerHTML='<option value="all">كل التصنيفات</option>'+cats.map(c=>`<option>${c}</option>`).join("");cat.dataset.ready="1";}
 const q=(search.value||"").trim().toLowerCase(),selected=cat.value;
 const rows=duaItems.filter(x=>(selected==="all"||x.c===selected)&&(!q||(x.t+" "+x.c+" "+x.s).toLowerCase().includes(q)));
 list.innerHTML=rows.map(x=>`<article><span class="dua-category">${x.c}</span><p>${x.t}</p><small>${x.s}</small></article>`).join("")||'<p class="muted">مفيش نتائج مطابقة لبحثك.</p>';
 $("duaCount").textContent=`عرض ${rows.length} من ${duaItems.length} دعاء.`;
}
$("duaSearch")?.addEventListener("input",renderDuas);$("duaCategory")?.addEventListener("change",renderDuas);renderDuas();

// الإذاعات: إزالة التكرار من ملف البيانات مع إظهار حالة الاتصال الحقيقية عند محاولة التشغيل.
let radioStations=[];
async function loadRadios(){
 try{
  const r=await fetch("./radios.json");if(!r.ok)throw Error("تعذر تحميل القائمة");
  const data=await r.json(),seen=new Set();
  radioStations=(data.radios||[]).filter(x=>x.name&&x.url&&!seen.has(x.url.trim())).filter(x=>{seen.add(x.url.trim());return true;}).sort((a,b)=>a.name.localeCompare(b.name,"ar"));
  renderRadioOptions();
 }catch(e){$("radioStatus").textContent="تعذر تحميل قائمة الإذاعات. أعد تحميل التطبيق.";}
}
function renderRadioOptions(){
 const q=($("radioSearch").value||"").trim().toLowerCase(),select=$("radioSelect"),old=select.value;
 const rows=radioStations.filter(x=>x.name.toLowerCase().includes(q));
 select.innerHTML=rows.map(x=>`<option value="${x.id}">${x.name}</option>`).join("");
 if(rows.some(x=>String(x.id)===old))select.value=old;
 if(!rows.length){select.innerHTML='<option value="">لا توجد نتائج</option>';}
}
$("radioSearch").addEventListener("input",renderRadioOptions);
$("radioPlay").addEventListener("click",()=>{
 const station=radioStations.find(x=>String(x.id)===$("radioSelect").value),audio=$("radioAudio");
 if(!station){$("radioStatus").textContent="اختار إذاعة من القائمة أولًا.";return;}
 audio.pause();audio.src=station.url;audio.load();$("radioTitle").textContent=station.name;
 $("radioStatus").textContent="جاري الاتصال بالبث...";
 audio.play().then(()=>$("radioStatus").textContent=`يعمل البث الآن: ${station.name}`).catch(()=>$("radioStatus").textContent="لم يبدأ البث تلقائيًا. اضغط تشغيل من مشغل الصوت أو جرّب إذاعة أخرى.");
});
$("radioAudio").addEventListener("error",()=>$("radioStatus").textContent="تعذر تشغيل هذا البث حاليًا؛ قد يكون الرابط متوقفًا أو غير متوافق. جرّب إذاعة أخرى.");
$("radioAudio").addEventListener("playing",()=>$("radioStatus").textContent="البث يعمل الآن.");
$("radioAudio").addEventListener("waiting",()=>$("radioStatus").textContent="جاري تحميل البث...");
loadRadios();

// مفتاح FreeModel يُقرأ من ملف config.js خارج واجهة التطبيق.
const aiBaseUrl="https://freemodel.in/v1";
let cachedChatModel=null;
async function getFreeModelChatModel(key){
 const r=await fetch(`${aiBaseUrl}/models`,{headers:{"Authorization":`Bearer ${key}`}});
 if(!r.ok){let detail="";try{const j=await r.json();detail=j.error?.message||"";}catch(e){}throw Error(detail||`HTTP ${r.status}`);}
 const j=await r.json();
 const list=Array.isArray(j.data)?j.data:[];
 const model=list.find(x=>x.type==="chat")||list.find(x=>typeof x.id==="string");
 if(!model?.id)throw Error("لم يرجع FreeModel أي موديل متاح لهذا المفتاح.");
 return model.id;
}
function addAiMessage(role,text){const d=document.createElement("div");d.className=`ai-message ${role}`;d.textContent=text;$("aiChat").appendChild(d);$("aiChat").scrollTop=$("aiChat").scrollHeight;}
$("aiForm").addEventListener("submit",async e=>{
 e.preventDefault();const question=$("aiQuestion").value.trim();if(!question)return;
 const key=window.NOOR_CONFIG?.FREEMODEL_API_KEY?.trim();
 if(!key||key.includes("PASTE_YOUR_API_KEY_HERE")){toast("ملف config.js يحتاج إضافة مفتاح API");return;}
 addAiMessage("user",question);$("aiQuestion").value="";$("aiSend").disabled=true;addAiMessage("assistant","جاري مراجعة السؤال...");const pending=$("aiChat").lastElementChild;
 const systemPrompt="أنت مساعد معلومات إسلامية عام، ولست مفتيًا. أجب فقط عن الأسئلة المتعلقة بالإسلام. التزم بالقرآن الكريم والأحاديث الصحيحة والمصادر المعتمدة المعروفة. لا تخترع آية أو حديثًا أو نسبة أو حكمًا. إذا لم تعرف أو اختلف أهل العلم أو احتاج السؤال لتفصيل، صرّح بعدم اليقين ووجّه السائل لعالم مؤهل أو دار إفتاء رسمية. ميّز بين النص الشرعي والشرح. اذكر اسم المصدر وموضعه عندما تعرفه بدقة، ولا تخترع مراجع. ارفض الأسئلة خارج الدين بأدب. لا تصدر أحكامًا شخصية قاطعة في النوازل.";
 try{
  if(!cachedChatModel)cachedChatModel=await getFreeModelChatModel(key);
  const r=await fetch(`${aiBaseUrl}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},body:JSON.stringify({model:cachedChatModel,messages:[{role:"system",content:systemPrompt},{role:"user",content:question}],temperature:0.2})});
  if(!r.ok){let detail="";try{const j=await r.json();detail=j.error?.message||"";}catch(e){}throw Error(detail||`HTTP ${r.status}`);}
  const j=await r.json();const answer=j.choices?.[0]?.message?.content||"لم يصل رد مفهوم من مزود الخدمة.";pending.textContent=typeof answer==="string"?answer:JSON.stringify(answer);
 }catch(err){pending.textContent=`تعذر الاتصال بـ FreeModel: ${err.message}. تأكد من المفتاح والإنترنت وتوفر الموديل.`;}
 finally{$("aiSend").disabled=false;}
});

let tasbeehCount=Number(localStorage.getItem("noor-tasbeeh")||0);
$("tasbeehCount").textContent=tasbeehCount;
$("tasbeehTap").onclick=()=>{tasbeehCount++;$("tasbeehCount").textContent=tasbeehCount;localStorage.setItem("noor-tasbeeh",tasbeehCount)};
$("tasbeehReset").onclick=()=>{tasbeehCount=0;$("tasbeehCount").textContent="0";localStorage.setItem("noor-tasbeeh","0")};
