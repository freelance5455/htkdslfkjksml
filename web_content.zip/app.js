'use strict';

const ITERATIONS = 210000;
const MAGIC = 'MC1';
const enc = new TextEncoder();
const dec = new TextDecoder();
const $ = id => document.getElementById(id);

function toast(message, error=false){
  const t=$('toast'); t.textContent=message; t.className='toast show'+(error?' error':'');
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.className='toast',3000);
}
function b64(bytes){let s='';for(const b of bytes)s+=String.fromCharCode(b);return btoa(s)}
function unb64(s){const bin=atob(s);const out=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i);return out}
async function derive(password,salt){
  if(!window.crypto?.subtle) throw new Error('لا يدعم هذا الجهاز تشفير Web Crypto. استخدم إصدار WebView حديثًا.');
  const base=await crypto.subtle.importKey('raw',enc.encode(password),{name:'PBKDF2'},false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:ITERATIONS,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
async function encryptMessage(text,password){
  if(!text.trim()) throw new Error('اكتب الرسالة أولًا.');
  if(password.length<6) throw new Error('المفتاح يجب أن يتكون من 6 أحرف على الأقل.');
  const salt=crypto.getRandomValues(new Uint8Array(16));
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const key=await derive(password,salt);
  const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv,tagLength:128},key,enc.encode(text));
  return [MAGIC,b64(salt),b64(iv),b64(new Uint8Array(cipher))].join('.');
}
async function decryptMessage(payload,password){
  if(!payload.trim()) throw new Error('الصق الرسالة المشفرة أولًا.');
  if(!password) throw new Error('أدخل المفتاح السري.');
  const parts=payload.trim().split('.');
  if(parts.length!==4 || parts[0]!==MAGIC) throw new Error('النص المشفر غير صالح أو ليس من Mohamed Cipher.');
  let salt,iv,cipher;
  try{salt=unb64(parts[1]);iv=unb64(parts[2]);cipher=unb64(parts[3]);}catch{throw new Error('النص المشفر تالف أو غير صالح.');}
  if(salt.length!==16||iv.length!==12||cipher.length<17) throw new Error('النص المشفر تالف أو غير مكتمل.');
  try{
    const key=await derive(password,salt);
    const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv,tagLength:128},key,cipher);
    return dec.decode(plain);
  }catch{throw new Error('فشل فك التشفير: المفتاح غير صحيح أو تم تعديل الرسالة.');}
}

$('encryptBtn').addEventListener('click',async()=>{
  const btn=$('encryptBtn');btn.disabled=true;btn.textContent='⏳ جارٍ التشفير...';
  try{$('encryptedText').value=await encryptMessage($('plainText').value,$('encKey').value);toast('تم تشفير الرسالة بنجاح.');}
  catch(e){toast(e.message||'حدث خطأ أثناء التشفير.',true)}
  finally{btn.disabled=false;btn.textContent='🔒 تشفير الرسالة';}
});
$('decryptBtn').addEventListener('click',async()=>{
  const btn=$('decryptBtn');btn.disabled=true;btn.textContent='⏳ جارٍ فك التشفير...';$('decryptedText').value='';
  try{$('decryptedText').value=await decryptMessage($('cipherText').value,$('decKey').value);toast('تم فك التشفير بنجاح.');}
  catch(e){toast(e.message||'تعذر فك التشفير.',true)}
  finally{btn.disabled=false;btn.textContent='🔓 فك التشفير';}
});
async function copyValue(id){const value=$(id).value;if(!value){toast('لا يوجد محتوى لنسخه.',true);return}try{await navigator.clipboard.writeText(value);toast('تم النسخ.')}catch{$(id).select();document.execCommand('copy');toast('تم النسخ.')}}
$('copyEnc').addEventListener('click',()=>copyValue('encryptedText'));
$('copyDec').addEventListener('click',()=>copyValue('decryptedText'));
$('clearDec').addEventListener('click',()=>{$('cipherText').value='';$('decKey').value='';$('decryptedText').value='';toast('تم المسح.')});
$('shareEnc').addEventListener('click',async()=>{const text=$('encryptedText').value;if(!text){toast('قم بتشفير رسالة أولًا.',true);return}if(navigator.share){try{await navigator.share({title:'Mohamed Cipher',text})}catch{}}else{await copyValue('encryptedText');toast('المشاركة غير متاحة، تم نسخ الرسالة بدلًا من ذلك.')}});

document.querySelectorAll('.eye').forEach(btn=>btn.addEventListener('click',()=>{const input=$(btn.dataset.target);input.type=input.type==='password'?'text':'password';btn.textContent=input.type==='password'?'👁':'🙈'}));
$('encryptTab').addEventListener('click',()=>switchTab(true));
$('decryptTab').addEventListener('click',()=>switchTab(false));
function switchTab(encMode){$('encryptPanel').classList.toggle('hidden',!encMode);$('decryptPanel').classList.toggle('hidden',encMode);$('encryptTab').classList.toggle('active',encMode);$('decryptTab').classList.toggle('active',!encMode);$('encryptTab').setAttribute('aria-selected',encMode);$('decryptTab').setAttribute('aria-selected',!encMode)}
$('themeBtn').addEventListener('click',()=>{document.body.classList.toggle('dark');$('themeBtn').textContent=document.body.classList.contains('dark')?'☀':'☾';localStorage.setItem('mc-theme',document.body.classList.contains('dark')?'dark':'light')});
if(localStorage.getItem('mc-theme')==='dark'){document.body.classList.add('dark');$('themeBtn').textContent='☀'}
