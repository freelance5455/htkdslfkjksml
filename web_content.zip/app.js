(function(){
"use strict";
var C=window.Core;
function $(i){return document.getElementById(i)}
function bn(s){return String(s).replace(/\d/g,function(d){return "০১২৩৪৫৬৭৮৯".charAt(d)})}
function mmss(s){s=Math.max(0,Math.floor(s||0));var h=Math.floor(s/3600),m=Math.floor(s%3600/60),r=s%60;return (h?h+":":"")+(h?("0"+m).slice(-2):m)+":"+("0"+r).slice(-2)}
function digits(str){var o="",c=bn(str);for(var i=0;i<c.length;i++){o+=c.charAt(i)===":"?'<span class="cl">:</span>':'<span class="d">'+c.charAt(i)+'</span>'}return o}
function esc(s){return String(s).replace(/[&<>]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;"}[c]})}
var MN=["জানুয়ারি","ফেব্রুয়ারি","মার্চ","এপ্রিল","মে","জুন","জুলাই","আগস্ট","সেপ্টেম্বর","অক্টোবর","নভেম্বর","ডিসেম্বর"];
var WD=["রবিবার","সোমবার","মঙ্গলবার","বুধবার","বৃহস্পতিবার","শুক্রবার","শনিবার"];
function dstr(t){var d=new Date(t),h=d.getHours(),m=d.getMinutes(),p=h>=4&&h<6?"ভোর":h>=6&&h<12?"সকাল":h>=12&&h<16?"দুপুর":h>=16&&h<18?"বিকাল":h>=18&&h<20?"সন্ধ্যা":"রাত",h12=h%12||12;return WD[d.getDay()]+", "+bn(d.getDate())+" "+MN[d.getMonth()]+" "+bn(d.getFullYear())+" · "+p+" "+bn(h12)+":"+bn(("0"+m).slice(-2))}
var tt=null;function toast(m){var t=$("toast");t.textContent=m;t.classList.add("on");clearTimeout(tt);tt=setTimeout(function(){t.classList.remove("on")},3600)}
function busy(on,m){$("busy").classList.toggle("on",!!on);if(m)$("busyt").textContent=m}
function loadScript(src){return new Promise(function(res,rej){var s=document.createElement("script");s.src=src;s.onload=res;s.onerror=function(){rej(new Error("ইন্টারনেট সংযোগ লাগবে (লাইব্রেরি নামানো যায়নি)"))};document.head.appendChild(s)})}

/* সেটিংস */
var S={theme:"auto",fs:26,nz:"mid",lb:5,dict:"",rate:1,voice:""};
try{var s0=JSON.parse(localStorage.getItem("sp_set"));if(s0)for(var k in s0)S[k]=s0[k]}catch(e){}
function saveS(){try{localStorage.setItem("sp_set",JSON.stringify(S))}catch(e){}}
function applyTheme(){var t=S.theme;if(t==="auto")t=(window.matchMedia&&matchMedia("(prefers-color-scheme: dark)").matches)?"dark":"light";document.documentElement.setAttribute("data-theme",t);document.body.setAttribute("data-theme",t);var m=document.querySelector('meta[name=theme-color]');if(m)m.content=t==="dark"?"#0e1416":"#2a8c80";
 var b=$("thc").querySelectorAll("button");for(var i=0;i<b.length;i++)b[i].classList.toggle("on",b[i].getAttribute("data-v")===S.theme)}
function cycleTheme(){var o=["auto","light","dark"];S.theme=o[(o.indexOf(S.theme)+1)%3];saveS();applyTheme();drawAll();toast("থিম: "+({auto:"স্বয়ংক্রিয়",light:"লাইট",dark:"ডার্ক"})[S.theme])}
function chipSet(id,val,cb){var b=$(id).querySelectorAll("button");for(var i=0;i<b.length;i++){(function(x){x.classList.toggle("on",x.getAttribute("data-v")===String(val));x.onclick=function(){cb(x.getAttribute("data-v"));for(var j=0;j<b.length;j++)b[j].classList.toggle("on",b[j]===x)}})(b[i])}}

/* ডাটাবেস */
var DB=null;
function dbOpen(){return new Promise(function(res,rej){var r=indexedDB.open("swarpath",1);r.onupgradeneeded=function(){r.result.createObjectStore("rec",{keyPath:"id",autoIncrement:true})};r.onsuccess=function(){DB=r.result;res(DB)};r.onerror=function(){rej(r.error)}})}
function tx(mode,fn){return new Promise(function(res,rej){var t=DB.transaction("rec",mode),s=t.objectStore("rec"),q=fn(s);t.oncomplete=function(){res(q&&q.result)};t.onerror=function(){rej(t.error)};t.onabort=function(){rej(t.error)}})}
function dbPut(r){return tx("readwrite",function(s){return s.put(r)})}
function dbAll(){return tx("readonly",function(s){return s.getAll()})}
function dbGet(id){return tx("readonly",function(s){return s.get(id)})}
function dbDel(id){return tx("readwrite",function(s){return s.delete(id)})}

/* নেভিগেশন */
var cur="rec";
function show(v){cur=v;var vs=document.querySelectorAll(".view");for(var i=0;i<vs.length;i++)vs[i].classList.toggle("on",vs[i].id==="v-"+v);
 var nb=document.querySelectorAll("nav button");for(var j=0;j<nb.length;j++)nb[j].classList.toggle("on",nb[j].getAttribute("data-v")===(v==="det"?"lib":v));
 if(v==="lib")renderLib();if(v==="stat")renderStat();if(v==="set")renderSet();window.scrollTo(0,0)}

/* ===== মাইক্রোফোন অনুমতি ===== */
function setMic(st,msg){
 var el=$("mic"),box=$("micbox");el.textContent=msg;el.className="pill"+(st==="granted"?" ok":st==="denied"?" no":"");
 box.style.display=(st==="granted")?"none":"block";$("micst2").textContent="অবস্থা: "+msg;
}
async function micStatus(){
 if(!window.isSecureContext){setMic("insecure","⛔ মাইক: https/ইনস্টল দরকার");return}
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){setMic("none","⛔ মাইক সমর্থিত নয়");return}
 try{var p=await navigator.permissions.query({name:"microphone"});
  var f=function(s){setMic(s,s==="granted"?"✅ মাইক চালু":s==="denied"?"⛔ মাইক বন্ধ (অনুমতি নেই)":"❓ মাইকের অনুমতি দেননি")};
  f(p.state);p.onchange=function(){f(this.state)}}
 catch(e){setMic("unknown","❓ মাইকের অবস্থা অজানা")}
}
async function askMic(){
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){toast("এই ডিভাইস/ব্রাউজারে মাইক সমর্থিত নয়");return}
 if(!window.isSecureContext){toast("মাইক শুধু https ঠিকানা বা ইনস্টল করা অ্যাপে চলে");return}
 try{var s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(function(t){t.stop()});toast("✅ অনুমতি পাওয়া গেছে");micStatus()}
 catch(e){var n=e&&e.name;toast(n==="NotFoundError"?"কোনো মাইক্রোফোন পাওয়া যায়নি":"অনুমতি পাওয়া যায়নি — নিচের ধাপ অনুযায়ী ফোনের সেটিংসে অনুমতি দিন");$("micbox").style.display="block";micStatus()}
}
function openPhoneSettings(){
 toast("সেটিংস খোলার চেষ্টা চলছে; না খুললে হাতে সেটিংস → অ্যাপস → Chrome → অনুমতি দেখুন");
 try{location.href="intent:#Intent;action=android.settings.APPLICATION_DETAILS_SETTINGS;data=package:com.android.chrome;end"}catch(e){}
}

/* ===== রেকর্ডিং ===== */
var state="idle",mr=null,stream=null,chunks=[],rctx=null,an=null,t0=0,pAt=0,acc=0,cuts=[],hist=[],raf=0,lastPush=0,mime="";
var pend={img:null,url:""};
function elapsed(){if(state==="idle")return 0;var n=state==="paused"?pAt:Date.now();return Math.max(0,(n-t0-acc)/1000)}
function pickMime(){var c=["audio/webm;codecs=opus","audio/webm","audio/mp4","audio/ogg;codecs=opus"];for(var i=0;i<c.length;i++){if(window.MediaRecorder&&MediaRecorder.isTypeSupported&&MediaRecorder.isTypeSupported(c[i]))return c[i]}return ""}
function setUi(){
 var on=state!=="idle";
 $("rbtn").classList.toggle("on",state==="rec");$("rdrec").classList.toggle("on",state==="rec");
 $("rbtn").textContent=on?"⏹":"🎙";$("rdrec").textContent=on?"⏹":"🎙";
 $("pbtn").disabled=!on;$("tbtn").disabled=!on;
 $("pbtn").textContent=state==="paused"?"▶ আবার চালু":"⏸ বিরতি";
 $("st").textContent=state==="idle"?"রেকর্ড শুরু করতে নিচের বোতাম চাপুন":state==="rec"?"রেকর্ড হচ্ছে… স্পষ্ট ও ধীরে পড়ুন":"বিরতিতে আছে";
}
async function startRec(){
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia||!window.MediaRecorder){toast("এই ডিভাইসে রেকর্ডিং সমর্থিত নয়। ‘অডিও ফাইল যোগ করো’ ব্যবহার করুন।");$("micbox").style.display="block";return}
 try{stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true,channelCount:1}})}
 catch(e){toast("মাইক্রোফোনের অনুমতি পাওয়া যায়নি। নিচের ধাপ দেখুন।");$("micbox").style.display="block";micStatus();return}
 mime=pickMime();chunks=[];cuts=[];hist=[];
 try{mr=mime?new MediaRecorder(stream,{mimeType:mime}):new MediaRecorder(stream)}catch(e){mr=new MediaRecorder(stream)}
 mr.ondataavailable=function(e){if(e.data&&e.data.size)chunks.push(e.data)};
 mr.onstop=onStopped;
 try{rctx=new (window.AudioContext||window.webkitAudioContext)();var src=rctx.createMediaStreamSource(stream);an=rctx.createAnalyser();an.fftSize=1024;src.connect(an);if(rctx.resume)rctx.resume()}catch(e){an=null}
 mr.start(1000);state="rec";t0=Date.now();acc=0;lastPush=0;setUi();loop();micStatus();
 try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch(e){}
}
function loop(){
 if(state==="idle")return;
 $("tm").innerHTML=digits(mmss(elapsed()));
 if(an&&state==="rec"){var d=new Uint8Array(an.fftSize);an.getByteTimeDomainData(d);var m=0;for(var i=0;i<d.length;i++){var a=Math.abs(d[i]-128)/128;if(a>m)m=a}
  var n=Date.now();if(n-lastPush>70){hist.push(m);if(hist.length>140)hist.shift();lastPush=n}}
 drawLive();raf=requestAnimationFrame(loop);
}
function css(v){return getComputedStyle(document.body).getPropertyValue(v).trim()||"#2a8c80"}
function fit(cv){var r=window.devicePixelRatio||1,w=cv.clientWidth||cv.width,h=cv.clientHeight||cv.height;if(cv.width!==Math.round(w*r)){cv.width=Math.round(w*r);cv.height=Math.round(h*r)}return [cv.width,cv.height]}
function drawLive(){
 var cv=$("wf"),c=cv.getContext("2d"),sz=fit(cv),W=sz[0],H=sz[1];c.clearRect(0,0,W,H);
 var bw=W/140,mid=H/2;c.fillStyle=css("--ac");
 for(var i=0;i<hist.length;i++){var h=Math.max(3,hist[i]*H*0.95),x=W-(hist.length-i)*bw;c.fillRect(x+1,mid-h/2,Math.max(2,bw-2),h)}
 if(!hist.length){c.fillStyle=css("--line");c.fillRect(0,mid-1,W,2)}
}
function pauseRec(){
 if(state==="rec"){mr.pause();state="paused";pAt=Date.now()}else if(state==="paused"){mr.resume();acc+=Date.now()-pAt;state="rec"}
 setUi();
}
function retake(){
 if(state==="idle")return;var t=elapsed(),lb=parseFloat(S.lb)||5;
 cuts.push([Math.max(0,t-lb),t]);toast("শেষ "+bn(lb)+" সেকেন্ড বাদ যাবে — বাক্যটি আবার বলুন");
 try{navigator.vibrate&&navigator.vibrate(60)}catch(e){}
}
function stopRec(){if(state==="idle")return;var dur=elapsed();if(state==="paused"){acc+=Date.now()-pAt}state="idle";cancelAnimationFrame(raf);try{mr.stop()}catch(e){onStopped()}try{stream.getTracks().forEach(function(t){t.stop()})}catch(e){}try{rctx&&rctx.close()}catch(e){}$("tm").innerHTML=digits(mmss(dur));setUi()}
function toggleRec(){if(state==="idle")startRec();else stopRec()}
async function onStopped(){
 var blob=new Blob(chunks,{type:mime||"audio/webm"});
 if(blob.size<800){toast("রেকর্ডিং খুব ছোট; সেভ হয়নি।");return}
 await saveFromBlob(blob,cuts.slice());
 hist=[];drawLive();$("tm").innerHTML="";
}
async function saveFromBlob(blob,cutList,nameHint){
 var title=$("rtitle").value.trim()||nameHint||("রেকর্ডিং "+bn(new Date().getDate())+" "+MN[new Date().getMonth()]),ref=$("rref").value;
 busy(true,"নয়েজ কমানো ও ভুল অংশ কাটা চলছে…");
 try{
  var out=await process(blob,cutList,S.nz);
  var rec={title:title,created:Date.now(),dur:out.dur,ref:ref,text:"",fixes:{spell:0,speech:0},fin:false,wav:new Blob([out.wav],{type:"audio/wav"}),peaks:out.peaks,size:out.wav.byteLength,cuts:cutList.length,nz:S.nz,gated:Math.round(out.gated*100),img:pend.img||null};
  await dbPut(rec);busy(false);toast("✅ সেভ হয়েছে — লাইব্রেরিতে দেখুন");$("rtitle").value="";clearPhoto();
 }catch(e){busy(false);toast("প্রক্রিয়া ব্যর্থ: "+(e&&e.message?e.message:"অজানা ত্রুটি"))}
}
async function process(blob,cutList,level){
 var ab=await blob.arrayBuffer();
 var AC=window.AudioContext||window.webkitAudioContext,dc=new AC();
 var buf=await new Promise(function(res,rej){var p=dc.decodeAudioData(ab,res,rej);if(p&&p.then)p.then(res,rej)});
 var ch=buf.numberOfChannels,n=buf.length,x=new Float32Array(n),i,c;
 for(c=0;c<ch;c++){var d=buf.getChannelData(c);for(i=0;i<n;i++)x[i]+=d[i]/ch}
 var sr=buf.sampleRate;
 x=C.removeRanges(x,sr,cutList,15);
 if(x.length<sr*0.4)throw new Error("কাটার পর অডিও প্রায় ফাঁকা");
 var tb=dc.createBuffer(1,x.length,sr);if(tb.copyToChannel)tb.copyToChannel(x,0);else tb.getChannelData(0).set(x);
 var TR=16000,len=Math.ceil(x.length/sr*TR),oc=new (window.OfflineAudioContext||window.webkitOfflineAudioContext)(1,len,TR);
 var s=oc.createBufferSource();s.buffer=tb;
 var hp=oc.createBiquadFilter();hp.type="highpass";hp.frequency.value=level==="high"?130:level==="low"?80:105;hp.Q.value=.7;
 var lp=oc.createBiquadFilter();lp.type="lowpass";lp.frequency.value=7200;lp.Q.value=.7;
 var pk=oc.createBiquadFilter();pk.type="peaking";pk.frequency.value=2800;pk.gain.value=2.5;pk.Q.value=.9;
 var cp=oc.createDynamicsCompressor();cp.threshold.value=-26;cp.knee.value=20;cp.ratio.value=3;cp.attack.value=.01;cp.release.value=.2;
 s.connect(hp);hp.connect(lp);lp.connect(pk);pk.connect(cp);cp.connect(oc.destination);s.start(0);
 var r=await oc.startRendering(),y=new Float32Array(r.getChannelData(0));
 try{dc.close()}catch(e){}
 var g=C.denoiseGate(y,TR,level);C.normalize(y,.89);
 return {wav:C.encodeWav(y,TR),peaks:C.peaksOf(y,220),dur:y.length/TR,gated:g.gated||0};
}

/* ===== ছবি (ক্যামেরা/গ্যালারি) ও OCR ===== */
function shrink(file){return new Promise(function(res,rej){var u=URL.createObjectURL(file),im=new Image();im.onload=function(){var M=1600,w=im.width,h=im.height,k=Math.min(1,M/Math.max(w,h)),cv=document.createElement("canvas");cv.width=Math.round(w*k);cv.height=Math.round(h*k);cv.getContext("2d").drawImage(im,0,0,cv.width,cv.height);URL.revokeObjectURL(u);cv.toBlob(function(b){b?res(b):rej(new Error("ছবি প্রক্রিয়া ব্যর্থ"))},"image/jpeg",.85)};im.onerror=function(){rej(new Error("ছবি পড়া যায়নি"))};im.src=u})}
async function setPhoto(file){
 if(!file)return;
 try{var b=await shrink(file);clearPhoto();pend.img=b;pend.url=URL.createObjectURL(b);$("timg").src=pend.url;$("thumb").style.display="block";toast("📷 ছবি যোগ হয়েছে — রিডিং মোডে দেখা যাবে")}
 catch(e){toast(e.message)}
}
function clearPhoto(){if(pend.url)URL.revokeObjectURL(pend.url);pend={img:null,url:""};$("thumb").style.display="none";$("timg").removeAttribute("src")}
async function ocr(blob){
 busy(true,"ছবি থেকে লেখা বের হচ্ছে… (প্রথমবার ডাটা নামবে, সময় লাগবে)");
 try{
  if(!window.Tesseract)await loadScript("https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js");
  var r=await window.Tesseract.recognize(blob,"ben");busy(false);return C.normBn(r.data.text||"").trim();
 }catch(e){busy(false);throw e}
}
async function ocrToRef(blob,target){
 if(!blob){toast("আগে একটি ছবি দিন");return}
 try{var t=await ocr(blob);if(!t){toast("ছবিতে লেখা পাওয়া যায়নি");return}target.value=t;target.dispatchEvent&&target.dispatchEvent(new Event("input"));toast("লেখা বের হয়েছে — ভুল থাকলে ঠিক করে নিন")}
 catch(e){toast("ব্যর্থ: "+e.message)}
}

/* ===== রিডিং মোড ===== */
function openRd(){
 var t=$("rref").value.trim();if(!t&&!pend.url){toast("আগে পড়ার লেখা দিন বা পৃষ্ঠার ছবি তুলুন");return}
 $("rdt").textContent=t;$("rdt").style.fontSize=S.fs+"px";
 if(pend.url){$("rdimg").src=pend.url;$("rdi").classList.add("on")}else{$("rdi").classList.remove("on")}
 $("rd").classList.add("on");
}
function fsChange(d){S.fs=Math.max(18,Math.min(44,S.fs+d));$("rdt").style.fontSize=S.fs+"px";saveS()}

/* ===== লাইব্রেরি ===== */
async function renderLib(){
 var all=(await dbAll()).sort(function(a,b){return b.created-a.created});
 $("lcount").textContent="("+bn(all.length)+")";
 if(!all.length){$("llist").innerHTML='<p class="mu">এখনো কোনো রেকর্ডিং নেই। “রেকর্ড” ট্যাবে গিয়ে শুরু করুন।</p>';return}
 var o="";all.forEach(function(r){o+='<div class="it" data-id="'+r.id+'"><div class="ic">'+(r.fin?"✅":"▶")+'</div><div style="flex:1;min-width:0"><b>'+esc(r.title)+'</b><small>'+dstr(r.created)+'</small><br><small>'+bn(mmss(r.dur))+' · '+bn((r.size/1048576).toFixed(1))+' MB'+(r.cuts?' · '+bn(r.cuts)+'টি ভুল অংশ কাটা':'')+(r.img?' · 🖼':'')+'</small></div></div>'});
 $("llist").innerHTML=o;
 var it=$("llist").querySelectorAll(".it");for(var i=0;i<it.length;i++)it[i].onclick=function(){openDet(parseInt(this.getAttribute("data-id"),10))};
}

/* ===== বিস্তারিত / প্লেয়ার ===== */
var R=null,au=null,url="",A=null,B=null,looping=false,praf=0,delArm=0,durl="";
async function openDet(id){
 R=await dbGet(id);if(!R)return;
 if(au){au.pause();URL.revokeObjectURL(url)}
 url=URL.createObjectURL(R.wav);au=new Audio(url);au.preload="auto";au.playbackRate=parseFloat($("spd").value)||1;A=B=null;looping=false;
 au.addEventListener("loadedmetadata",function(){$("ptot").textContent=bn(mmss(au.duration||R.dur))});
 au.addEventListener("ended",function(){$("pplay").textContent="▶"});
 au.addEventListener("play",function(){$("pplay").textContent="⏸";mediaSess()});
 au.addEventListener("pause",function(){$("pplay").textContent="▶"});
 $("dtitle").value=R.title;$("dref").value=R.ref||"";$("dtxt").value=R.text||"";$("dres").style.display="none";
 $("dmeta").textContent=dstr(R.created)+" · "+bn(mmss(R.dur))+" · নয়েজ: "+({low:"কম",mid:"মাঝারি",high:"বেশি"})[R.nz||"mid"];
 $("dfin").textContent=R.fin?"✅ অধ্যায় শেষ":"☐ অধ্যায় শেষ";$("lstat").textContent="";$("pcur").textContent=bn("0:00");
 if(durl){URL.revokeObjectURL(durl);durl=""}
 if(R.img){durl=URL.createObjectURL(R.img);$("dimg").src=durl;$("dimgc").style.display="block"}else{$("dimgc").style.display="none"}
 show("det");cancelAnimationFrame(praf);drawPlayer();
}
function mediaSess(){try{if(!("mediaSession" in navigator))return;navigator.mediaSession.metadata=new MediaMetadata({title:R.title,artist:"স্বরপাঠ"});
 navigator.mediaSession.setActionHandler("play",function(){au.play()});navigator.mediaSession.setActionHandler("pause",function(){au.pause()});
 navigator.mediaSession.setActionHandler("seekbackward",function(){seek(-10)});navigator.mediaSession.setActionHandler("seekforward",function(){seek(10)})}catch(e){}}
function seek(d){if(!au)return;au.currentTime=Math.max(0,Math.min((au.duration||R.dur)-0.05,au.currentTime+d))}
function drawPlayer(){
 if(!R||cur!=="det")return;
 var cv=$("pw"),c=cv.getContext("2d"),sz=fit(cv),W=sz[0],H=sz[1],p=R.peaks||[],n=p.length,bw=W/n,dur=(au&&au.duration)||R.dur,pos=au?au.currentTime/dur:0;
 c.clearRect(0,0,W,H);
 if(A!==null&&B!==null){c.fillStyle=css("--ac");c.globalAlpha=.16;c.fillRect(A/dur*W,0,(B-A)/dur*W,H);c.globalAlpha=1}
 for(var i=0;i<n;i++){var h=Math.max(3,p[i]*H*.92);c.fillStyle=(i/n<=pos)?css("--ac"):css("--mu");c.globalAlpha=(i/n<=pos)?1:.45;c.fillRect(i*bw+1,(H-h)/2,Math.max(1.5,bw-2),h)}
 c.globalAlpha=1;c.fillStyle=css("--rec");c.fillRect(pos*W-1,0,2,H);
 if(A!==null){c.fillStyle=css("--tx");c.fillRect(A/dur*W-1,0,2,H)}if(B!==null){c.fillStyle=css("--tx");c.fillRect(B/dur*W-1,0,2,H)}
 $("pcur").textContent=bn(mmss(au?au.currentTime:0));
 if(looping&&A!==null&&B!==null&&au&&au.currentTime>=B){au.currentTime=A}
 praf=requestAnimationFrame(drawPlayer);
}
function drawAll(){drawLive();if(cur==="det"){cancelAnimationFrame(praf);drawPlayer()}}

/* সংশোধন */
function userDict(){return C.parseDict(S.dict)}
function showRes(r,title){
 var el=$("dres");el.style.display="block";
 if(r.err){el.innerHTML="⚠️ "+esc(r.err);return}
 if(!r.count){el.innerHTML="✅ "+title+": কোনো সংশোধন লাগেনি।";return}
 var o="<b>"+title+": "+bn(r.count)+"টি শব্দ ঠিক হয়েছে</b><br>";
 r.changes.slice(0,60).forEach(function(c){o+="<mark>"+esc(c.from)+"</mark> → <b>"+esc(c.to)+"</b>"+(c.count>1?" ("+bn(c.count)+"×)":"")+"<br>"});
 el.innerHTML=o;
}
async function doSpell(){
 var t=$("dtxt").value||$("dref").value;if(!t.trim()){toast("আগে ট্রান্সক্রিপ্ট বা মূল লেখা দিন");return}
 var r=C.spellFix(t,userDict());
 if($("dtxt").value)$("dtxt").value=r.text;else $("dref").value=r.text;
 R.fixes.spell+=r.count;showRes(r,"বানান সংশোধন");await persistText();
}
async function doSpeech(){
 var r=C.alignFix($("dtxt").value,$("dref").value);
 if(!r.err){$("dtxt").value=r.text;R.fixes.speech+=r.count}
 showRes(r,"মূল লেখার সঙ্গে মেলানো");await persistText();
}
async function persistText(){R.title=$("dtitle").value.trim()||R.title;R.ref=$("dref").value;R.text=$("dtxt").value;R.words=Math.max(C.wordCount(R.text),C.wordCount(R.ref));await dbPut(R)}

/* এক্সপোর্ট */
function dl(blob,name){var a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){document.body.removeChild(a)},500)}
function safe(n){return (n||"rec").replace(/[\\/:*?"<>|]+/g,"_")}
function fullText(){return (R.title+"\n"+dstr(R.created)+"\n\n"+(R.text||R.ref||""))}
async function share(){
 try{var f=new File([R.wav],safe(R.title)+".wav",{type:"audio/wav"});
  if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],title:R.title});return}
 }catch(e){}
 toast("এই ডিভাইসে সরাসরি শেয়ার চলছে না; WAV ডাউনলোড করুন।")
}

/* ===== পিডিএফ ও পড়ে শোনানো ===== */
var pdfDoc=null,CDN="https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/";
async function pdfOpen(file){
 if(!file)return;
 busy(true,"পিডিএফ খোলা হচ্ছে… (প্রথমবার ইন্টারনেট লাগবে)");
 try{
  if(!window.pdfjsLib){await loadScript(CDN+"pdf.min.js");window.pdfjsLib.GlobalWorkerOptions.workerSrc=CDN+"pdf.worker.min.js"}
  var buf=await file.arrayBuffer();pdfDoc=await window.pdfjsLib.getDocument({data:buf}).promise;
  $("pinfo").textContent=file.name+" — মোট "+bn(pdfDoc.numPages)+" পৃষ্ঠা";$("pfrom").value=1;$("pto").value=Math.min(pdfDoc.numPages,10);
  busy(false);await pdfGet();
 }catch(e){busy(false);toast("পিডিএফ খোলা যায়নি: "+(e&&e.message?e.message:""))}
}
async function pdfGet(){
 if(!pdfDoc){toast("আগে একটি পিডিএফ বাছাই করুন");return}
 var a=Math.max(1,parseInt($("pfrom").value,10)||1),b=Math.min(pdfDoc.numPages,parseInt($("pto").value,10)||a);if(b<a)b=a;
 busy(true,"লেখা বের হচ্ছে…");var out=[];
 try{for(var p=a;p<=b;p++){var pg=await pdfDoc.getPage(p),tc=await pg.getTextContent();out.push(C.itemsToText(tc.items))}}
 catch(e){busy(false);toast("লেখা বের করা যায়নি");return}
 busy(false);var t=C.normBn(out.join("\n\n")).trim();
 if(!t){toast("এই পৃষ্ঠাগুলোয় লেখা পাওয়া যায়নি (স্ক্যান করা ছবি হতে পারে)");return}
 $("ptxt").value=t;buildSents();toast("✅ "+bn(C.wordCount(t))+" শব্দ পাওয়া গেছে");
}
var TS={q:[],i:0,on:false,paused:false,voices:[]};
function buildSents(){TS.q=C.splitSentences($("ptxt").value,200);TS.i=0;var o="";TS.q.forEach(function(s,i){o+='<span data-i="'+i+'">'+esc(s)+' </span>'});$("sl").innerHTML=o;
 var sp=$("sl").querySelectorAll("span");for(var j=0;j<sp.length;j++)sp[j].onclick=function(){ttsFrom(parseInt(this.getAttribute("data-i"),10))};
 $("tst").textContent=TS.q.length?bn(TS.q.length)+"টি বাক্য":""}
function loadVoices(){
 if(!window.speechSynthesis)return;
 var v=speechSynthesis.getVoices();TS.voices=v.filter(function(x){return /^bn/i.test(x.lang)});
 var list=TS.voices.length?TS.voices:v,o="";
 list.forEach(function(x,i){o+='<option value="'+esc(x.name)+'"'+(x.name===S.voice?" selected":"")+'>'+esc(x.name)+" ("+esc(x.lang)+")</option>"});
 $("vsel").innerHTML=o||'<option value="">কোনো কণ্ঠ পাওয়া যায়নি</option>';
 if(!TS.voices.length&&v.length)$("tst").textContent="⚠️ বাংলা কণ্ঠ নেই — ফোনের সেটিংসে Google Text-to-speech-এ বাংলা ভয়েস নামান";
}
function curVoice(){var n=$("vsel").value,v=speechSynthesis.getVoices();for(var i=0;i<v.length;i++)if(v[i].name===n)return v[i];return null}
function mark(i){var sp=$("sl").querySelectorAll("span");for(var j=0;j<sp.length;j++)sp[j].classList.toggle("on",j===i);if(sp[i]&&sp[i].scrollIntoView)try{sp[i].scrollIntoView({block:"nearest"})}catch(e){}}
function ttsSpeakAt(i){
 if(!window.speechSynthesis){toast("এই ডিভাইসে পড়ে শোনানো সমর্থিত নয়");return}
 if(i>=TS.q.length){ttsStop();$("tst").textContent="✅ শেষ";return}
 TS.i=i;mark(i);
 var u=new SpeechSynthesisUtterance(TS.q[i]),v=curVoice();if(v){u.voice=v;u.lang=v.lang}else u.lang="bn-BD";
 u.rate=parseFloat($("rtr").value)||1;
 var my=i;u.onend=function(){if(TS.on&&!TS.paused&&TS.i===my)ttsSpeakAt(my+1)};
 u.onerror=function(){};
 speechSynthesis.cancel();speechSynthesis.speak(u);
}
function ttsFrom(i){if(!TS.q.length)buildSents();if(!TS.q.length){toast("আগে লেখা দিন");return}TS.on=true;TS.paused=false;ttsSpeakAt(i)}
function ttsStop(){TS.on=false;TS.paused=false;try{speechSynthesis.cancel()}catch(e){}mark(-1)}
function ttsPause(){if(!TS.on)return;if(TS.paused){TS.paused=false;ttsSpeakAt(TS.i);$("tpause").textContent="⏸ বিরতি"}else{TS.paused=true;try{speechSynthesis.cancel()}catch(e){}$("tpause").textContent="▶ চালু"}}
function speakText(t){$("ptxt").value=t;buildSents();show("pdf");ttsFrom(0)}

/* হিসাব */
async function renderStat(){
 var all=await dbAll(),tot=0,w=0,fx=0,fin=[];
 all.forEach(function(r){tot+=r.dur||0;w+=r.words||Math.max(C.wordCount(r.text),C.wordCount(r.ref));fx+=(r.fixes?r.fixes.spell+r.fixes.speech:0);if(r.fin)fin.push(r.title)});
 $("k1").textContent=bn(mmss(tot));$("k2").textContent=bn(w);$("k3").textContent=bn(fx);$("k4").textContent=bn(fin.length);
 $("kfin").innerHTML=fin.length?fin.map(esc).join("<br>"):"এখনো কোনো অধ্যায় শেষ করা হয়নি।";
 var rec=all.sort(function(a,b){return b.created-a.created}).slice(0,10);
 $("krec").innerHTML=rec.length?rec.map(function(r){return '<div class="it" style="cursor:default"><div style="flex:1"><b>'+esc(r.title)+'</b><small>'+dstr(r.created)+'</small></div><small>'+bn(mmss(r.dur))+'</small></div>'}).join(""):'<span class="mu">কিছু নেই</span>';
}
async function renderSet(){
 applyTheme();$("fsv").textContent=bn(S.fs)+" px";$("fsr").value=S.fs;$("cdict").value=S.dict||"";micStatus();
 try{if(navigator.storage&&navigator.storage.estimate){var e=await navigator.storage.estimate();$("stor").textContent="সংরক্ষণ ব্যবহার: "+bn((e.usage/1048576).toFixed(1))+" MB / "+bn((e.quota/1048576).toFixed(0))+" MB"}}catch(x){}
}
async function backup(){var all=await dbAll();var d={v:1,dict:S.dict,items:all.map(function(r){return {title:r.title,created:r.created,dur:r.dur,ref:r.ref,text:r.text,fixes:r.fixes,fin:r.fin,words:r.words}})};dl(new Blob([JSON.stringify(d)],{type:"application/json"}),"swarpath-backup.json")}
function restore(f){var rd=new FileReader();rd.onload=function(){try{var d=JSON.parse(rd.result);if(d.dict)S.dict=d.dict;saveS();toast("পুনরুদ্ধার হয়েছে: সেটিংস ও বানান-তালিকা (অডিও আলাদা)")}catch(e){toast("ফাইলটি পড়া যায়নি")}};rd.readAsText(f)}

/* ===== সংযোগ ===== */
function init(){
 applyTheme();
 $("thb").onclick=cycleTheme;
 var nb=document.querySelectorAll("nav button");for(var i=0;i<nb.length;i++)nb[i].onclick=function(){show(this.getAttribute("data-v"))};
 $("rbtn").onclick=toggleRec;$("pbtn").onclick=pauseRec;$("tbtn").onclick=retake;
 $("micask").onclick=askMic;$("micask2").onclick=askMic;$("micset").onclick=openPhoneSettings;$("micset2").onclick=openPhoneSettings;
 chipSet("nz",S.nz,function(v){S.nz=v;saveS()});chipSet("lb",S.lb,function(v){S.lb=parseFloat(v);saveS()});
 $("afile").onchange=function(){var f=this.files[0];this.value="";if(f)saveFromBlob(f,[],f.name.replace(/\.[^.]+$/,""))};
 $("cam").onchange=function(){var f=this.files[0];this.value="";setPhoto(f)};$("gal").onchange=function(){var f=this.files[0];this.value="";setPhoto(f)};
 $("timgx").onclick=clearPhoto;
 $("ocrb").onclick=function(){ocrToRef(pend.img,$("rref"))};
 $("rref").oninput=function(){$("rwc").textContent=C.wordCount(this.value)?bn(C.wordCount(this.value))+" শব্দ":""};
 $("rdopen").onclick=openRd;$("rdx").onclick=function(){$("rd").classList.remove("on")};
 $("rdimg").onclick=function(){this.classList.toggle("z")};
 $("rda").onclick=function(){fsChange(-2)};$("rdp").onclick=function(){fsChange(2)};$("rdth").onclick=cycleTheme;
 $("rdrec").onclick=toggleRec;$("rdtk").onclick=retake;
 $("rtts").onclick=function(){var t=$("rref").value.trim();if(!t){toast("আগে পড়ার লেখা দিন");return}speakText(t)};
 $("rpdf").onclick=function(){show("pdf")};
 $("dback").onclick=function(){if(au)au.pause();show("lib")};
 $("pplay").onclick=function(){if(au.paused)au.play();else au.pause()};
 $("b10").onclick=function(){seek(-10)};$("f10").onclick=function(){seek(10)};
 $("spd").onchange=function(){if(au)au.playbackRate=parseFloat(this.value)};
 function lst(){$("lstat").textContent=(A!==null?"A: "+bn(mmss(A)):"")+(B!==null?"  B: "+bn(mmss(B))+(looping?"  🔁 লুপ চলছে":""):"")}
 $("la").onclick=function(){A=au.currentTime;if(B!==null&&B<=A)B=null;lst()};
 $("lb2").onclick=function(){if(A===null){toast("আগে A চিহ্ন দিন");return}B=au.currentTime;if(B<=A){B=null;toast("B চিহ্ন A-এর পরে হতে হবে");return}looping=true;au.currentTime=A;au.play();lst()};
 $("lc").onclick=function(){A=B=null;looping=false;lst()};
 $("l10").onclick=function(){var e=au.currentTime;A=Math.max(0,e-10);B=e;looping=true;au.currentTime=A;au.play();lst()};
 $("pw").onclick=function(e){var r=this.getBoundingClientRect();au.currentTime=((e.clientX-r.left)/r.width)*(au.duration||R.dur)};
 $("dimg").onclick=function(){this.style.width=this.style.width==="200%"?"100%":"200%"};
 $("docr").onclick=function(){ocrToRef(R.img,$("dref"))};
 $("dfin").onclick=async function(){R.fin=!R.fin;this.textContent=R.fin?"✅ অধ্যায় শেষ":"☐ অধ্যায় শেষ";await persistText();toast(R.fin?"অধ্যায় শেষ হিসেবে চিহ্নিত":"চিহ্ন সরানো হয়েছে")};
 $("cs").onclick=doSpell;$("cv").onclick=doSpeech;$("dsave").onclick=async function(){await persistText();toast("সংরক্ষিত")};
 $("dtts").onclick=function(){var t=$("dtxt").value.trim()||$("dref").value.trim();if(!t){toast("শোনানোর মতো লেখা নেই");return}speakText(t)};
 $("dtitle").onchange=persistText;
 $("xwav").onclick=function(){dl(R.wav,safe(R.title)+".wav")};
 $("xtxt").onclick=function(){dl(new Blob([fullText()],{type:"text/plain;charset=utf-8"}),safe(R.title)+".txt")};
 $("xdoc").onclick=function(){dl(new Blob(['<html><head><meta charset="utf-8"></head><body style="font-family:Noto Sans Bengali,sans-serif"><h2>'+esc(R.title)+'</h2><p>'+esc(dstr(R.created))+'</p><p>'+esc(R.text||R.ref||"").replace(/\n/g,"<br>")+'</p></body></html>'],{type:"application/msword"}),safe(R.title)+".doc")};
 $("xshare").onclick=share;
 $("xdel").onclick=async function(){var b=this;if(!delArm){delArm=1;b.textContent="⚠️ নিশ্চিত? আবার চাপুন";setTimeout(function(){delArm=0;b.textContent="🗑 রেকর্ডিং মুছুন"},4000);return}delArm=0;b.textContent="🗑 রেকর্ডিং মুছুন";if(au)au.pause();await dbDel(R.id);R=null;toast("মুছে ফেলা হয়েছে");show("lib")};
 $("pfile").onchange=function(){var f=this.files[0];this.value="";pdfOpen(f)};$("pget").onclick=pdfGet;
 $("ptxt").oninput=function(){TS.q=[];$("sl").innerHTML="";TS.i=0};
 $("tplay").onclick=function(){if(!TS.q.length||!$("sl").innerHTML)buildSents();ttsFrom(TS.paused?TS.i:0)};
 $("tpause").onclick=ttsPause;$("tstop").onclick=function(){ttsStop();$("tpause").textContent="⏸ বিরতি"};
 $("tprev").onclick=function(){if(TS.on)ttsFrom(Math.max(0,TS.i-1))};$("tnext").onclick=function(){if(TS.on)ttsFrom(TS.i+1)};
 $("rtr").value=S.rate;$("rtv").textContent=bn(S.rate)+"×";
 $("rtr").oninput=function(){S.rate=parseFloat(this.value);$("rtv").textContent=bn(S.rate)+"×";saveS()};
 $("vsel").onchange=function(){S.voice=this.value;saveS()};
 $("p2r").onclick=function(){$("rref").value=$("ptxt").value;$("rref").oninput();show("rec");toast("পড়ার লেখায় বসানো হয়েছে")};
 if(window.speechSynthesis){loadVoices();speechSynthesis.onvoiceschanged=loadVoices}else{$("tst").textContent="⚠️ এই ডিভাইসে পড়ে শোনানো সমর্থিত নয়"}
 chipSet("thc",S.theme,function(v){S.theme=v;saveS();applyTheme();drawAll()});
 $("fsr").oninput=function(){S.fs=parseInt(this.value,10);$("fsv").textContent=bn(S.fs)+" px";saveS()};
 $("cdsave").onclick=function(){S.dict=$("cdict").value;saveS();toast("সংরক্ষিত")};
 $("bk").onclick=backup;$("bkf").onchange=function(){if(this.files[0])restore(this.files[0])};
 setUi();drawLive();micStatus();
 if("serviceWorker" in navigator&&location.protocol.indexOf("http")===0)navigator.serviceWorker.register("sw.js");
}
dbOpen().then(init).catch(function(){document.body.insertAdjacentHTML("afterbegin",'<p style="padding:20px">এই ব্রাউজারে ডাটাবেস চালু করা যায়নি।</p>')});
})();
