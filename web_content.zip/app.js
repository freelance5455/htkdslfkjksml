const memes=[
{id:1,categoria:"Escola",texto:"Professor: A prova vai ser fácil 😂",imagem:"https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=800",likes:120},
{id:2,categoria:"Amizade",texto:"Eu e o meu melhor amigo depois de fazer uma coisa errada 😂",imagem:"https://images.unsplash.com/photo-1499209974431-9dddcece7f88?w=800",likes:230},
{id:4,categoria:"Popular",texto:"Quando dizem que amanhã não tem aulas 😂",imagem:"https://images.unsplash.com/photo-1529390079861-591de354faf5?w=800",likes:500}
];
let memesAtuais=[...memes];
function mostrarMemes(lista){const c=document.getElementById("memes");c.innerHTML="";if(!lista.length){c.innerHTML='<p style="text-align:center">😢 Nenhum meme encontrado.</p>';return}lista.forEach(m=>{const card=document.createElement("div");card.className="meme-card";card.innerHTML=`<img src="${m.imagem}" alt="Meme" loading="lazy"><div class="meme-info"><div class="category">#${m.categoria}</div><p>${m.texto.replace(/\n/g,"<br>")}</p><div class="actions"><button onclick="curtir(${m.id})">❤️ ${m.likes}</button><button onclick="partilhar('${m.texto.replace(/'/g,"\\'")}')">📤 Partilhar</button></div></div>`;c.appendChild(card)})}
function mostrarTodos(){memesAtuais=[...memes];document.getElementById("titulo").innerText="🔥 Memes";mostrarMemes(memesAtuais)}
function filtrar(cat){memesAtuais=memes.filter(m=>m.categoria===cat);document.getElementById("titulo").innerText="😂 "+cat;mostrarMemes(memesAtuais)}
function pesquisarMemes(){const t=document.getElementById("search").value.toLowerCase();mostrarMemes(memes.filter(m=>m.texto.toLowerCase().includes(t)||m.categoria.toLowerCase().includes(t)))}
function curtir(id){const m=memes.find(x=>x.id===id);if(m){m.likes++;mostrarMemes(memesAtuais)}}
async function partilhar(texto){const mensagem=texto+"\n\n😂 MemeMoz";if(navigator.share){try{await navigator.share({title:"MemeMoz",text:mensagem})}catch(e){}}else{await navigator.clipboard.writeText(mensagem);alert("Texto copiado! Agora podes enviar no WhatsApp.")}}
let imagemSelecionada=null;
function abrirCriador(){document.getElementById("criador").style.display="flex"}
function fecharCriador(){document.getElementById("criador").style.display="none"}
function carregarImagem(event){const arquivo=event.target.files[0];if(!arquivo)return;const reader=new FileReader();reader.onload=e=>{imagemSelecionada=new Image();imagemSelecionada.onload=desenharMeme;imagemSelecionada.src=e.target.result};reader.readAsDataURL(arquivo)}
function desenharMeme(){if(!imagemSelecionada)return;const canvas=document.getElementById("canvas"),ctx=canvas.getContext("2d");canvas.width=imagemSelecionada.width;canvas.height=imagemSelecionada.height;ctx.drawImage(imagemSelecionada,0,0);const cima=document.getElementById("textoCima").value,baixo=document.getElementById("textoBaixo").value;ctx.textAlign="center";ctx.font=`${Math.max(canvas.width/12,30)}px Impact`;ctx.fillStyle="white";ctx.strokeStyle="black";ctx.lineWidth=8;if(cima){ctx.strokeText(cima,canvas.width/2,70);ctx.fillText(cima,canvas.width/2,70)}if(baixo){ctx.strokeText(baixo,canvas.width/2,canvas.height-40);ctx.fillText(baixo,canvas.width/2,canvas.height-40)}}
function gerarMeme(){if(!imagemSelecionada){alert("Escolhe primeiro uma imagem.");return}desenharMeme()}
function baixarMeme(){if(!imagemSelecionada){alert("Cria primeiro o teu meme.");return}const link=document.createElement("a");link.download="meme-mememoz.png";link.href=document.getElementById("canvas").toDataURL("image/png");link.click()}
document.getElementById("textoCima").addEventListener("input",desenharMeme);
document.getElementById("textoBaixo").addEventListener("input",desenharMeme);
mostrarMemes(memes);
