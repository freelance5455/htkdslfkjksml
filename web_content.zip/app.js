const msg=document.getElementById('message');
document.querySelectorAll('.menuitem').forEach(button=>{
 button.addEventListener('click',()=>{msg.textContent=button.dataset.msg;});
});
document.getElementById('saveUser').addEventListener('click',()=>{
 const name=document.getElementById('username').value.trim();
 document.getElementById('userMsg').textContent=name ? `デモ用ユーザーネーム「${name}」を入力しました。外部には送信されません。` : 'ユーザーネームを入力してください。';
});
