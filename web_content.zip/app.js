/**
 * TPH X Core Logic Engine
 */

class TphXEngine {
    constructor() {
        this.currentCategory = 'web';
        this.historyEnabled = true;
        this.searchHistory = [];
        this.documents = [];

        // DuckDuckGo Route Target Schemas
        this.endpoints = {
            web: 'https://duckduckgo.com/?q=',
            images: 'https://duckduckgo.com/?q={term}&iax=images&ia=images',
            news: 'https://duckduckgo.com/?q={term}&iar=news&ia=news',
            docs: 'https://duckduckgo.com/?q={term}+filetype%3Apdf'
        };
    }

    init() {
        this.loadSettings();
        this.loadHistory();
        this.loadDocuments();
        this.setupEventListeners();
        this.renderHistory();
        this.renderLibraryCount();
        this.executeLocalSearch(); // Init empty list
    }

    setupEventListeners() {
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.executeExternalSearch();
            });
            searchInput.addEventListener('input', (e) => {
                const btn = document.getElementById('clear-input-btn');
                if (btn) {
                    if (e.target.value.length > 0) btn.className = '';
                    else btn.className = 'clear-input-hidden';
                }
            });
        }
    }

    switchView(viewName) {
        document.querySelectorAll('.view-section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));

        document.getElementById(`view-${viewName}`).classList.add('active');
        document.getElementById(`nav-${viewName}-btn`).classList.add('active');
    }

    setCategory(cat) {
        this.currentCategory = cat;
        document.querySelectorAll('.cat-btn').forEach(b => {
            if (b.getAttribute('data-category') === cat) b.classList.add('active');
            else b.classList.remove('active');
        });
    }

    clearSearchInput() {
        const input = document.getElementById('search-input');
        input.value = '';
        document.getElementById('clear-input-btn').className = 'clear-input-hidden';
        input.focus();
    }

    // External Navigation Core
    executeExternalSearch(overrideTerm = null) {
        const term = overrideTerm || document.getElementById('search-input').value.trim();
        if (!term) return;

        if (!overrideTerm && this.historyEnabled) {
            this.pushHistory(term);
        }

        const encoded = encodeURIComponent(term);
        let targetUrl = '';

        if (this.currentCategory === 'web') {
            targetUrl = this.endpoints.web + encoded;
        } else {
            targetUrl = this.endpoints[this.currentCategory].replace('{term}', encoded);
        }

        // Show context transparent route fallback layout element
        const fallbackContainer = document.getElementById('fallback-container');
        const fallbackLink = document.getElementById('fallback-link');
        if (fallbackContainer && fallbackLink) {
            fallbackLink.href = targetUrl;
            fallbackContainer.className = '';
        }

        // Execute primary target break out to native view context handler
        window.open(targetUrl, '_blank');
    }

    // Storage System Managers
    loadSettings() {
        const stored = localStorage.getItem('tphx_history_enabled');
        this.historyEnabled = stored !== 'false';
        const toggle = document.getElementById('toggle-history');
        if (toggle) toggle.checked = this.historyEnabled;
    }

    toggleHistorySetting(e) {
        this.historyEnabled = e.target.checked;
        localStorage.setItem('tphx_history_enabled', this.historyEnabled);
        if (!this.historyEnabled) this.clearAllHistory();
    }

    loadHistory() {
        const data = localStorage.getItem('tphx_history');
        this.searchHistory = data ? JSON.parse(data) : [];
    }

    pushHistory(term) {
        this.searchHistory = this.searchHistory.filter(i => i !== term);
        this.searchHistory.unshift(term);
        if (this.searchHistory.length > 50) this.searchHistory.pop();
        localStorage.setItem('tphx_history', JSON.stringify(this.searchHistory));
        this.renderHistory();
    }

    deleteHistoryItem(term, e) {
        if (e) e.stopPropagation();
        this.searchHistory = this.searchHistory.filter(i => i !== term);
        localStorage.setItem('tphx_history', JSON.stringify(this.searchHistory));
        this.renderHistory();
    }

    clearAllHistory() {
        this.searchHistory = [];
        localStorage.removeItem('tphx_history');
        this.renderHistory();
    }

    renderHistory() {
        const list = document.getElementById('history-list');
        if (!list) return;
        list.innerHTML = '';
        if (this.searchHistory.length === 0) {
            list.innerHTML = '<li class="setting-info-text">No recent queries recorded.</li>';
            return;
        }
        this.searchHistory.forEach(term => {
            const li = document.createElement('li');
            li.innerHTML = `
                <span class="history-item-text">${this.escapeHtml(term)}</span>
                <button class="delete-btn">&times;</button>
            `;
            li.querySelector('.history-item-text').addEventListener('click', () => {
                document.getElementById('search-input').value = term;
                this.executeExternalSearch(term);
            });
            li.querySelector('.delete-btn').addEventListener('click', (e) => this.deleteHistoryItem(term, e));
            list.appendChild(li);
        });
    }

    // Document Processor Core Subsystems
    loadDocuments() {
        const data = localStorage.getItem('tphx_docs');
        this.documents = data ? JSON.parse(data) : [];
    }

    saveDocuments() {
        localStorage.setItem('tphx_docs', JSON.stringify(this.documents));
        this.renderLibraryCount();
    }

    renderLibraryCount() {
        const el = document.getElementById('library-count');
        if (el) el.textContent = `${this.documents.length} document${this.documents.length === 1 ? '' : 's'} indexed`;
    }

    handleFileImport(e) {
        const files = e.target.files;
        if (!files) return;

        Array.from(files).forEach(file => {
            const name = file.name;
            const ext = name.split('.').pop().toLowerCase();

            if (ext === 'pdf') {
                // PDF Parsing capability wrapper fallback (Client UI engine limited window context handling)
                this.extractPdfPlaceholder(file);
            } else {
                const reader = new FileReader();
                reader.onload = (evt) => {
                    const content = evt.target.result;
                    this.addDocumentRecord(name, content);
                };
                reader.readAsText(file);
            }
        });
        e.target.value = ''; // Flush control
    }

    extractPdfPlaceholder(file) {
        // Since native webview environment may lack standalone heavy pdf components, 
        // provide systematic mapping wrapper using structural metadata context parsing strategy
        this.addDocumentRecord(file.name, `[PDF Binary Document Framework Metadata] Size: ${file.size} bytes. Isolated local database binary indexing placeholder.`);
    }

    addDocumentRecord(name, content) {
        this.documents.push({
            id: Date.now() + Math.random().toString(36).substr(2, 5),
            name: name,
            content: content
        });
        this.saveDocuments();
        this.executeLocalSearch();
    }

    deleteDocument(id) {
        this.documents = this.documents.filter(d => d.id !== id);
        this.saveDocuments();
        this.executeLocalSearch();
    }

    clearAllDocuments() {
        this.documents = [];
        this.saveDocuments();
        this.executeLocalSearch();
    }

    executeLocalSearch() {
        const query = document.getElementById('local-search-input').value.toLowerCase().trim();
        const container = document.getElementById('local-results-list');
        if (!container) return;

        container.innerHTML = '';

        const targetDocs = query ? this.documents.filter(d => 
            d.name.toLowerCase().includes(query) || d.content.toLowerCase().includes(query)
        ) : this.documents;

        if (targetDocs.length === 0) {
            container.innerHTML = '<p class="setting-info-text">No target matched in local library indexes.</p>';
            return;
        }

        targetDocs.forEach(doc => {
            const card = document.createElement('div');
            card.className = 'doc-card';
            
            let extract = doc.content.substring(0, 180);
            if (doc.content.length > 180) extract += '...';

            if (query) {
                extract = this.highlightMatch(extract, query);
            }

            card.innerHTML = `
                <div class="doc-card-header">
                    <span class="doc-title">${this.escapeHtml(doc.name)}</span>
                    <button class="delete-btn" data-id="${doc.id}">&times;</button>
                </div>
                <div class="doc-extract">${extract}</div>
            `;

            card.querySelector('.delete-btn').addEventListener('click', () => this.deleteDocument(doc.id));
            container.appendChild(card);
        });
    }

    highlightMatch(text, query) {
        const idx = text.toLowerCase().indexOf(query);
        if (idx === -1) return this.escapeHtml(text);
        
        const regex = new RegExp(`(${this.escapeRegExp(query)})`, 'gi');
        return text.replace(regex, '<span class="match-highlight">$1</span>');
    }

    exportLibrary() {
        if (this.documents.length === 0) {
            alert('Document engine index pool empty.');
            return;
        }
        const blob = new Blob([JSON.stringify(this.documents, null, 2)], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'tphx_library_export.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // Utility Helpers
    escapeHtml(str) {
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    escapeRegExp(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
}

// System Core Global Execution Pointer Setup
const app = new TphXEngine();
window.addEventListener('DOMContentLoaded', () => app.init());
