// Yalla Kora - direct Supabase connection; no Netlify dependency.
// Fill in config.js with your Supabase project URL and publishable/anon key.
const { SUPABASE_URL, SUPABASE_ANON_KEY, MATCHES_TABLE } = window.YALLA_CONFIG || {};
let allMatches = [];
let currentFilter = "all";
let hlsInstance = null;

const matchesEl = document.getElementById("matches");
const noticeEl = document.getElementById("notice");
const video = document.getElementById("videoPlayer");
const placeholder = document.getElementById("playerPlaceholder");
const playerTitle = document.getElementById("playerTitle");
const playerMessage = document.getElementById("playerMessage");
document.getElementById("year").textContent = new Date().getFullYear();

function textValue(obj, keys, fallback = "") {
  for (const key of keys) if (obj && obj[key] != null && String(obj[key]).trim() !== "") return String(obj[key]);
  return fallback;
}
function normalStatus(m) {
  const s = textValue(m, ["status","state","match_status"]).toLowerCase();
  if (["live","playing","in_play","inplay","مباشر"].includes(s)) return "live";
  if (["ended","finished","ft","complete","انتهت"].includes(s)) return "ended";
  return "upcoming";
}
function statusLabel(s) { return s === "live" ? "مباشر" : s === "ended" ? "انتهت" : "قادمة"; }
function safeUrl(url) {
  try { const u = new URL(url); return ["http:","https:"].includes(u.protocol) ? u.href : ""; } catch (_) { return ""; }
}
function getStream(m) { return textValue(m, ["streamUrl","stream_url","url","m3u8","stream","play_url","link"]); }
function getTeam(m, side) {
  return side === "home"
    ? textValue(m, ["home","home_team","homeTeam","team_home","team1","home_name"], "الفريق الأول")
    : textValue(m, ["away","away_team","awayTeam","team_away","team2","away_name"], "الفريق الثاني");
}
function getLeague(m) { return textValue(m, ["league","competition","tournament","league_name"], "مباراة"); }
function getScore(m) { return textValue(m, ["score","result"], "VS"); }
function getTime(m) { return textValue(m, ["hour","time","match_time","kickoff","start_time","match_date"], ""); }
function getChannel(m) { return textValue(m, ["channel","channel_name","broadcast_channel"], ""); }
function getCommentator(m) { return textValue(m, ["commentator","commentator_name"], ""); }

function renderMatches() {
  const filtered = allMatches.filter(m => currentFilter === "all" || normalStatus(m) === currentFilter);
  matchesEl.innerHTML = "";
  if (!filtered.length) {
    matchesEl.innerHTML = '<div class="empty">ماكو مباريات للعرض حالياً، أو أن الجدول لا يحتوي بيانات متوافقة مع واجهة العرض.</div>';
    return;
  }
  filtered.forEach(m => {
    const status = normalStatus(m), home = getTeam(m,"home"), away = getTeam(m,"away");
    const channel = getChannel(m), commentator = getCommentator(m), time = getTime(m);
    const stream = safeUrl(getStream(m));
    const card = document.createElement("article");
    card.className = "match-card";
    const meta = [time ? "🕒 " + time : "", channel ? "📺 " + channel : "", commentator ? "🎙 " + commentator : ""].filter(Boolean);
    card.innerHTML = `<div class="match-head"><span class="league"></span><span class="status ${status}">${statusLabel(status)}</span></div>
      <div class="teams"><div class="team home"></div><div class="score"></div><div class="team away"></div></div>
      <div class="meta"></div><div class="match-actions"><button class="watch">${stream ? "▶ مشاهدة المباراة" : "عرض المباراة"}</button></div>`;
    card.querySelector(".league").textContent = getLeague(m);
    card.querySelector(".home").textContent = home; card.querySelector(".away").textContent = away;
    card.querySelector(".score").textContent = getScore(m);
    card.querySelector(".meta").textContent = meta.length ? meta.join("　•　") : "تفاصيل المباراة";
    card.querySelector(".watch").addEventListener("click", () => {
      if (stream) playStream(stream, `${home} × ${away}`);
      else {
        playerTitle.textContent = `${home} × ${away}`;
        playerMessage.textContent = "ماكو رابط بث مباشر محفوظ ضمن بيانات المباراة.";
        document.getElementById("playerSection").scrollIntoView({behavior:"smooth"});
      }
    });
    matchesEl.appendChild(card);
  });
}

async function loadMatches() {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY || SUPABASE_URL.includes("YOUR_PROJECT")) {
    noticeEl.textContent = "أكمل إعداد config.js بإضافة رابط مشروع Supabase ومفتاح publishable/anon.";
    allMatches = []; renderMatches(); return;
  }
  noticeEl.textContent = "جارٍ تحميل المباريات مباشرة من Supabase…";
  try {
    const root = SUPABASE_URL.replace(/\/+$/,"");
    const table = encodeURIComponent(MATCHES_TABLE || "match_overrides");
    const res = await fetch(`${root}/rest/v1/${table}?select=*`, {
      headers: {"apikey": SUPABASE_ANON_KEY, "Authorization": `Bearer ${SUPABASE_ANON_KEY}`, "Accept":"application/json"},
      cache:"no-store"
    });
    if (!res.ok) {
      const detail = await res.text();
      throw new Error(`Supabase HTTP ${res.status}: ${detail.slice(0,180)}`);
    }
    const data = await res.json();
    allMatches = Array.isArray(data) ? data : [];
    renderMatches();
    noticeEl.textContent = `تم تحميل ${allMatches.length} سجل مباشرة من Supabase.`;
  } catch (err) {
    allMatches = []; renderMatches();
    noticeEl.textContent = "تعذّر الاتصال بـ Supabase: " + (err?.message || "خطأ اتصال") + ". تحقق من الرابط والمفتاح وصلاحيات القراءة (RLS).";
  }
}

function stopPlayer() {
  if (hlsInstance) { hlsInstance.destroy(); hlsInstance = null; }
  video.pause(); video.removeAttribute("src"); video.load();
}
function playStream(url, title) {
  stopPlayer(); playerTitle.textContent = title || "البث المباشر";
  playerMessage.textContent = "جارٍ فتح البث…"; placeholder.classList.add("hidden");
  if (/\.m3u8($|[?#])/i.test(url) && window.Hls && Hls.isSupported()) {
    hlsInstance = new Hls({enableWorker:true, lowLatencyMode:true});
    hlsInstance.loadSource(url); hlsInstance.attachMedia(video);
    hlsInstance.on(Hls.Events.MANIFEST_PARSED, () => { playerMessage.textContent = "تم تحميل البث. اضغط تشغيل إذا لم يبدأ تلقائياً."; video.play().catch(()=>{}); });
    hlsInstance.on(Hls.Events.ERROR, (_, d) => { if (d?.fatal) playerMessage.textContent = "تعذّر تشغيل البث. تحقق من صلاحية الرابط وقيود المصدر."; });
  } else {
    video.src = url;
    video.play().then(()=>playerMessage.textContent="البث يعمل.").catch(()=>playerMessage.textContent="اضغط تشغيل. قد لا يكون الرابط متوافقاً أو قد يمنع المصدر التشغيل المضمّن.");
  }
  document.getElementById("playerSection").scrollIntoView({behavior:"smooth"});
}
document.getElementById("refreshBtn").addEventListener("click", loadMatches);
document.querySelectorAll(".tab").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".tab").forEach(b => b.classList.remove("active"));
  btn.classList.add("active"); currentFilter = btn.dataset.filter; renderMatches();
}));
loadMatches();
