
const sidebar = document.getElementById("sidebar");
const menuBtn = document.getElementById("menuBtn");
const overlay = document.getElementById("overlay");
const searchInput = document.getElementById("searchInput");
const toolsGrid = document.getElementById("toolsGrid");
const emptyState = document.getElementById("emptyState");
const pageTitle = document.getElementById("pageTitle");
const toast = document.getElementById("toast");

let activeFilter = "all";
let walletBackActive = false;
let accountBackActive = false;
let aiBackActive = false;
let sidebarBackActive = false;
let imageBackActive = false;
let contentCreatorBackActive = false;
let hashtagGeneratorBackActive = false;
let studyAssistantBackActive = false;
const sectionNames = {
  home: "الرئيسية",
  ai: "الذكاء الاصطناعي",
  files: "أدوات الملفات",
  content: "صناعة المحتوى",
  study: "الدراسة والتعلم",
  work: "أدوات العمل",
  images: "أدوات الصور",
  account: "حسابي",
  wallet: "رصيدي",
  plans: "الاشتراكات"
};

const homeElements = [
  document.querySelector(".welcome"),
  document.querySelector(".stats"),
  document.getElementById("toolsArea"),
  document.querySelector(".bottom-banner"),
  document.querySelector("footer")
];

const walletSection = document.getElementById("walletSection");
const imageStudioSection = document.getElementById("imageStudioSection");
const filesSection = document.getElementById("filesSection");
const contentCreatorSection = document.getElementById("contentCreatorSection");
const hashtagGeneratorSection = document.getElementById("hashtagGeneratorSection");
const studyAssistantSection = document.getElementById("studyAssistantSection");
const cvBuilderSection = document.getElementById("cvBuilderSection");
let cvBuilderBackActive = false;
let filesBackActive = false;
const aiChatSection = document.getElementById("aiChatSection");

// عرض وإخفاء عناصر الرئيسية
function setHomeVisibility(visible) {
  homeElements.forEach(element => {
    if (element) element.hidden = !visible;
  });
}

// تحديث عنوان الصفحة والقائمة النشطة
function setActiveSection(section) {
  if (pageTitle) {
    pageTitle.textContent = sectionNames[section] || "الرئيسية";
  }

  document.querySelectorAll(".nav-item").forEach(item => {
    item.classList.toggle(
      "active",
      item.dataset.section === section
    );
  });
}

// إشعارات المنصة
function showToast(message) {
  if (!toast) return;

  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(showToast.timer);

  showToast.timer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2500);
}

// تحديث حالة الأدوات المتاحة فعلياً
function updateToolAvailability() {
  const availableCategories = ["ai", "images", "files"];
const availableTools = ["صانع السيرة الذاتية"];
  let availableCount = 0;

  document.querySelectorAll(".tool-card").forEach(card => {
    const status = card.querySelector(".tool-status");
    const category = card.dataset.category;

    if (!status) return;

    if (
  availableCategories.includes(category) ||
  availableTools.includes(card.dataset.name)
) {
      status.textContent = "متاحة";
      status.classList.add("available");
      availableCount++;
    } else {
      status.textContent = "قريباً";
      status.classList.remove("available");
    }
  });

  const toolsCount = document.querySelector(
    ".stats .stat-card:first-child h2"
  );

  if (toolsCount) {
    toolsCount.innerHTML =
      String(availableCount).padStart(2, "0") +
      ' <span>أدوات متاحة</span>';
  }
}

// فتح وإغلاق القائمة الجانبية
function closeSidebar(fromBack = false) {
  if (!sidebar || !overlay) return;

  sidebar.classList.remove("open");
  overlay.classList.remove("show");

  if (sidebarBackActive) {
    sidebarBackActive = false;

    if (!fromBack) {
      history.back();
    }
  }
}

if (menuBtn) {
  menuBtn.addEventListener("click", () => {
    if (sidebar.classList.contains("open")) return;

    sidebar.classList.add("open");
    overlay.classList.add("show");

    history.pushState(
      { ahmadSidebar: true },
      "",
      location.href
    );

    sidebarBackActive = true;
  });
}

if (overlay) {
  overlay.addEventListener("click", () => {
    closeSidebar();
  });
}

// البحث والتصفية
function filterTools() {
  if (!searchInput || !emptyState) return;

  const query = searchInput.value.trim().toLowerCase();
  const cards = document.querySelectorAll(".tool-card");

  let visibleCount = 0;

  cards.forEach(card => {
    const category = card.dataset.category || "";
    const name = (card.dataset.name || "").toLowerCase();

    const description =
      card.querySelector("p")?.textContent.toLowerCase() || "";

    const matchesFilter =
      activeFilter === "all" || category === activeFilter;

    const matchesSearch =
      name.includes(query) || description.includes(query);

    const visible = matchesFilter && matchesSearch;

    card.style.display = visible ? "" : "none";

    if (visible) visibleCount++;
  });

  emptyState.hidden = visibleCount !== 0;
}

if (searchInput) {
  searchInput.addEventListener("input", filterTools);
}

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(item => {
      item.classList.remove("active");
    });

    button.classList.add("active");
    activeFilter = button.dataset.filter || "all";

    filterTools();
  });
});
function registerPageBack(type) {
  if (sidebarBackActive) {
    sidebarBackActive = false;

    sidebar.classList.remove("open");
    overlay.classList.remove("show");

    history.replaceState(
      { ahmadView: type },
      "",
      location.href
    );
  } else {
    history.pushState(
      { ahmadView: type },
      "",
      location.href
    );
  }

  walletBackActive = type === "wallet";
  accountBackActive = type === "account";
  imageBackActive = type === "images";
  filesBackActive = type === "files";
  contentCreatorBackActive = type === "contentCreator";
hashtagGeneratorBackActive = type === "hashtags";
  studyAssistantBackActive = type === "studyAssistant";
  cvBuilderBackActive = type === "cvBuilder";
  window.accountBackActive = accountBackActive;
}
// إغلاق الأقسام المفتوحة
function closeOtherSections() {
  if (walletSection) walletSection.hidden = true;
  if (imageStudioSection) imageStudioSection.hidden = true;
  if (aiChatSection) aiChatSection.hidden = true;
  if (filesSection) filesSection.hidden = true;
  if (contentCreatorSection) contentCreatorSection.hidden = true;
  if (hashtagGeneratorSection) hashtagGeneratorSection.hidden = true;
  if (cvBuilderSection) cvBuilderSection.hidden = true;
filesBackActive = false;
  aiBackActive = false;
  walletBackActive = false;
  imageBackActive = false;
}

// التنقل بين الأقسام
document.querySelectorAll(".nav-item").forEach(button => {
  button.addEventListener("click", () => {
    const section = button.dataset.section;

    if (!section) return;

    setActiveSection(section);

    // الرئيسية
    if (section === "home") {
      closeOtherSections();
      setHomeVisibility(true);

      activeFilter = "all";

      if (searchInput) {
        searchInput.value = "";
      }

      document.querySelectorAll(".filter").forEach(item => {
        item.classList.toggle(
          "active",
          item.dataset.filter === "all"
        );
      });

      filterTools();
    }
// المحفظة
else if (section === "wallet") {
  closeOtherSections();
  setHomeVisibility(false);

  if (walletSection) {
    walletSection.hidden = false;
  }

  registerPageBack("wallet");
} 
else if (section === "files") {
  closeOtherSections();
  setHomeVisibility(false);

  if (filesSection) {
    filesSection.hidden = false;
  }

  registerPageBack("files");
}
else if (section === "images") {
  closeOtherSections();
  setHomeVisibility(false);

  if (imageStudioSection) {
    imageStudioSection.hidden = false;
  }

  registerPageBack("images");
}

    // أقسام الأدوات
    else if (
      ["ai", "files", "content", "study", "work"].includes(section)
    ) {
      closeOtherSections();
      setHomeVisibility(true);

      activeFilter = section;

      document.querySelectorAll(".filter").forEach(item => {
        item.classList.toggle(
          "active",
          item.dataset.filter === section
        );
      });

      filterTools();
    }

    // الحساب
    else if (section === "account") {
      registerPageBack("account");

      if (typeof window.openAccountModal === "function") {
        window.openAccountModal();
      } else {
        showToast("تعذر فتح الحساب حالياً.");
      }
    }

    // الاشتراكات
    else if (section === "plans") {
      showToast("سيتم تطوير قسم الاشتراكات في مرحلة قادمة.");
    }

    closeSidebar();
  });
});


// فتح الأدوات من البطاقات
document.querySelectorAll(".tool-open").forEach(button => {
  button.addEventListener("click", () => {
    const tool = button.dataset.tool;

    if (tool === "المساعد الذكي") {
      if (!aiChatSection) {
        showToast("تعذر فتح المساعد حالياً.");
        return;
      }

      if (!aiChatSection.hidden) return;

      closeOtherSections();
      setHomeVisibility(false);

      aiChatSection.hidden = false;

      if (!aiBackActive) {
        history.pushState(
          { ahmadAI: true },
          "",
          location.href
        );

        aiBackActive = true;
      }

      return;
    }
// فتح استوديو الصور من البطاقة الرئيسية
if (tool === "استوديو الصور") {
  const imagesButton = document.querySelector(
    '.nav-item[data-section="images"]'
  );

  if (imagesButton) {
    imagesButton.click();
  } else {
    showToast("تعذر فتح استوديو الصور.");
  }

  return;
}
// فتح قسم صناعة المحتوى
if (tool === "صانع المحتوى") {
  if (!contentCreatorSection) {
    showToast("تعذر فتح قسم صناعة المحتوى.");
    return;
  }

  closeOtherSections();
  setHomeVisibility(false);

  contentCreatorSection.hidden = false;
  registerPageBack("contentCreator");

  return;
}

// فتح مولّد الهاشتاغات
if (tool === "مولّد الهاشتاغات") {
  if (!hashtagGeneratorSection) {
    showToast("تعذر فتح مولّد الهاشتاغات.");
    return;
  }

  closeOtherSections();
  setHomeVisibility(false);

  hashtagGeneratorSection.hidden = false;
registerPageBack("hashtags");
  return;
}

if (tool === "تحويل الملفات") {
  const filesButton = document.querySelector(
    '.nav-item[data-section="files"]'
  );

  if (filesButton) {
    filesButton.click();
  } else {
    showToast("تعذر فتح أدوات الملفات.");
  }

  return;
}
// فتح قسم المساعد الدراسي
if (tool === "المساعد الدراسي") {
  if (!studyAssistantSection) {
    showToast("تعذر فتح المساعد الدراسي.");
    return;
  }

  closeOtherSections();
  setHomeVisibility(false);

  studyAssistantSection.hidden = false;
  registerPageBack("studyAssistant");

  return;
}

// فتح صانع السيرة الذاتية
if (tool === "صانع السيرة الذاتية") {
  if (!cvBuilderSection) {
    showToast("تعذر فتح صانع السيرة الذاتية.");
    return;
  }

  closeOtherSections();
  setHomeVisibility(false);

  cvBuilderSection.hidden = false;
  registerPageBack("cvBuilder");

  return;
}



    showToast("أداة " + tool + " قيد التطوير.");
  });
});

// إغلاق المساعد والعودة للرئيسية
function closeAIChatView() {
  if (!aiChatSection || aiChatSection.hidden) return;

  aiChatSection.hidden = true;
  aiBackActive = false;

  setHomeVisibility(true);
  setActiveSection("home");
}

// زر الرجوع داخل المساعد
document.getElementById("closeAIChat")?.addEventListener("click", () => {
  if (aiBackActive) {
    history.back();
  } else {
    closeAIChatView();
  }
});
// زر الرجوع داخل صناعة المحتوى
document.getElementById("contentCreatorBack")?.addEventListener("click", () => {
  if (contentCreatorSection) {
    contentCreatorSection.hidden = true;
  }

  setHomeVisibility(true);
  setActiveSection("home");
});

// زر الرجوع داخل مولّد الهاشتاغات
document.getElementById("hashtagGeneratorBack")?.addEventListener("click", () => {
  if (hashtagGeneratorSection) {
    hashtagGeneratorSection.hidden = true;
  }

  setHomeVisibility(true);
  setActiveSection("home");
});

// زر الرجوع داخل المساعد الدراسي
document.getElementById("studyAssistantBack")?.addEventListener("click", () => {
  if (studyAssistantBackActive) {
    history.back();
  } else {
    if (studyAssistantSection) {
      studyAssistantSection.hidden = true;
    }

    setHomeVisibility(true);
    setActiveSection("home");
  }
});


// زر الرجوع داخل صانع السيرة الذاتية
document.getElementById("cvBuilderBack")?.addEventListener("click", () => {
  if (cvBuilderBackActive) {
    history.back();
  } else {
    if (cvBuilderSection) {
      cvBuilderSection.hidden = true;
    }

    setHomeVisibility(true);
    setActiveSection("home");
  }
});
// تحديث الأدوات عند تشغيل الصفحة
updateToolAvailability();
filterTools();








// إدارة زر الرجوع في الهاتف والمتصفح
window.addEventListener("popstate", () => {

  // إغلاق القائمة الجانبية
  if (sidebarBackActive) {
    closeSidebar(true);
    return;
  }

  // الرجوع من المساعد الذكي
  if (aiBackActive) {
    aiBackActive = false;
    closeAIChatView();
    return;
  }

  // الرجوع من المحفظة
  if (walletBackActive) {
    walletBackActive = false;
    if (walletSection) walletSection.hidden = true;
    setHomeVisibility(true);
    setActiveSection("home");
    return;
  }

  // الرجوع من أدوات الملفات
  if (filesBackActive) {
    filesBackActive = false;
    if (filesSection) filesSection.hidden = true;
    setHomeVisibility(true);
    setActiveSection("home");
    return;
  }

  // الرجوع من استوديو الصور
  if (imageBackActive) {
    imageBackActive = false;
    if (imageStudioSection) imageStudioSection.hidden = true;
    setHomeVisibility(true);
    setActiveSection("home");
    return;
  }

  // الرجوع من صناعة المحتوى
  if (contentCreatorBackActive) {
    contentCreatorBackActive = false;
    if (contentCreatorSection) contentCreatorSection.hidden = true;
    setHomeVisibility(true);
    setActiveSection("home");
    return;
  }

  // الرجوع من مولّد الهاشتاغات
  if (hashtagGeneratorBackActive) {
    hashtagGeneratorBackActive = false;
    if (hashtagGeneratorSection) hashtagGeneratorSection.hidden = true;
    setHomeVisibility(true);
    setActiveSection("home");
    return;
  }
  // الرجوع من المساعد الدراسي
if (studyAssistantBackActive) {
  studyAssistantBackActive = false;

  if (studyAssistantSection) {
    studyAssistantSection.hidden = true;
  }

  setHomeVisibility(true);
  setActiveSection("home");
  return;
}


// الرجوع من صانع السيرة الذاتية
if (cvBuilderBackActive) {
  cvBuilderBackActive = false;

  if (cvBuilderSection) {
    cvBuilderSection.hidden = true;
  }

  setHomeVisibility(true);
  setActiveSection("home");
  return;
}

  // الرجوع من الحساب
  if (accountBackActive || window.accountBackActive) {
    accountBackActive = false;
    window.accountBackActive = false;

    if (typeof window.closeAccountModal === "function") {
      window.closeAccountModal(true);
    }

    return;
  }

});