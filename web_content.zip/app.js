(() => {
'use strict';

/* =========================================================
   KIBAIGWA DEPOT MANAGEMENT — Updated per requirements
   - Login required
   - Fixed sales type validation (datalist + free text)
   - Leader ledger with full closing balances
   - Banks: NMB / CRDB only + auto account number
   - Damage reasons: Stitching open / Stitching damage / Bag damage
   - Transfer: Factory or Depot only
   - Petty cash: voucher, receipt, approved by (CEO/CFO/Others), Received option, auto balance
   - Global Depot / RSO type selector
   - Opening stock & petty cash openings lock after save
   - Full P&L + Consolidation reports
   - All reports: CSV + Print/PDF
   ========================================================= */

const PRODUCTS = [
  'CAAN PLUS - 5 KG', 'CAAN PLUS - 50 KG', 'CAAN PLUS - 25 KG',
  'DAAP PLUS - 5 KG', 'DAAP PLUS - 50 KG',
  'NPK 10-10-20 WHITE DIAMOND PAMBA 5 KG', 'NPK 10-10-20 WHITE DIAMOND PAMBA 50 KG',
  'UREA - 50 KG', 'SA - 50 KG', 'MoHP - 50 KG',
  'NPK 10-18-24 TOBACCO - 50 KG', 'NPK 25-5-15 CHAI 50 KG',
  'NPK 20-10-15 COFFEE KAHAWA 50 KG'
];

const BANKS = {
  'NMB': '20110001234',
  'CRDB': '0150123456789'
};

const DAMAGE_REASONS = ['Stitching open', 'Stitching damage', 'Bag damage', 'Handling damage', 'Others'];
const TRANSFER_DEST = ['Depot', 'Factory'];
const APPROVERS = ['CEO', 'CFO', 'Others'];
const SEED_DEALERS = [
  {name:'SUNLUSH AGROVET', tfra:'14251', tin:'200-423-763', contact:'690055462', mobile:'690055462'},
  {name:'FRANK AGROVET', tfra:'21189', tin:'140-778-206', contact:'763142903', mobile:'763142903'},
  {name:'MKOKELI AGROVET', tfra:'5506', tin:'124-229-839', contact:'712967680', mobile:'712967680'},
  {name:'JITEGEMEE AGROVET', tfra:'20271', tin:'106-187-886', contact:'757656866', mobile:'757656866'},
  {name:'SAMAR AFRICA LTD', tfra:'11623', tin:'175-824-421', contact:'658321872', mobile:'658321872'},
  {name:'MUJULE AGROVET', tfra:'5509', tin:'126-100-809', contact:'626188145', mobile:'626188145'},
  {name:'VILLAS CHAULA AGROVET', tfra:'28827', tin:'153-572-755', contact:'625986926', mobile:'625986926'},
  {name:'DAMIANO AGROVET', tfra:'8368', tin:'100-268-027', contact:'656116776', mobile:'656116776'},
  {name:'PEMBEJEO', tfra:'28959', tin:'202-444-288', contact:'789091811', mobile:'789091811'},
  {name:'FRIMINA STEPHANI', tfra:'29386', tin:'176-995-831', contact:'717728206', mobile:'717728206'},
  {name:'JESCA MASSAWE', tfra:'29553', tin:'137-218-934', contact:'718492834', mobile:'718492834'}
];

const T = {
  en: {
    Dashboard: 'Dashboard', Sales: 'Sales', Inventory: 'Inventory', Payments: 'Payments',
    Dealers: 'Dealer Ledger', PayConfirm: 'Payment Confirm', Invoice: 'Invoice', Damage: 'Damage bags', Transfers: 'Transfers',
    DepotCash: 'Petty cash — Depot', RSOCash: 'Petty cash — RSO', Reports: 'Reports',
    settings: 'Data & backup', Login: 'Login', today: 'DEPOT OPERATIONS',
    salesToday: "Today's sales", bagsSold: 'Bags sold', stockValue: 'Stock on hand',
    outstanding: 'Dealer outstanding', salesMT: 'MT sold today', quick: 'Quick actions',
    recent: 'Recent transactions', stock: 'Stock overview', newSale: 'New sale',
    receive: 'Receive stock', payment: 'Record payment', expense: 'Add expense / received',
    newDamage: 'Record damage', transfer: 'Stock transfer', saleForm: 'Sales entry',
    receiptForm: 'Stock receipt', paymentForm: 'Payment entry', expenseForm: 'Petty cash entry',
    damageForm: 'Damage entry', transferForm: 'Stock transfer', save: 'Save record',
    cancel: 'Cancel', date: 'Date', product: 'Product', qty: 'Quantity (bags)',
    price: 'Price per bag (TZS)', amount: 'Amount (TZS)', dealer: 'Dealer / customer',
    name: 'Name', tfra: 'TFRA ID', tin: 'TIN', contact: 'Contact / phone',
    order: 'Sales order no.', delivery: 'Delivery note no.', invoice: 'Invoice no.',
    type: 'Customer type', notes: 'Remarks', source: 'Received from',
    reference: 'Payment / bank reference', bank: 'Bank name', account: 'Bank account no.',
    cashType: 'Cash book', category: 'Expense category', reason: 'Reason',
    from: 'From', to: 'To', direction: 'Transaction type', loaded: 'Loaded bags',
    damageQty: 'Damage bags', shortage: 'Shortage bags', truck: 'Truck number',
    driver: 'Driver name', total: 'Total', report: 'Generate report',
    download: 'Download CSV', print: 'Print / Save PDF', period: 'Report period',
    start: 'Start date', end: 'End date', dailyStock: 'Daily closing stock',
    salesAnalysis: 'Sales analysis', monthly: 'Monthly summary', ledger: 'Dealer ledger',
    cashReport: 'Petty cash statement', profit: 'Profit & loss', consolidation: 'Depot consolidation',
    transactions: 'Transactions', noData: 'No records yet. Add your first transaction.',
    saved: 'Record saved on this device.', backup: 'Export backup', restore: 'Import backup',
    reset: 'Reset local data', confirmReset: 'Delete all locally saved app data? Export a backup first.',
    search: 'Search', all: 'All', opening: 'Opening stock (set initial stock)',
    setOpening: 'Save opening stock', openingQty: 'Opening bags', stockReceived: 'Stock received',
    sold: 'Sold', damaged: 'Damaged', transferIn: 'Transfer in', transferOut: 'Transfer out',
    closing: 'Closing stock', grossSales: 'Sales revenue', collections: 'Payments collected',
    expenses: 'Expenses', grossProfit: 'Gross profit', netProfit: 'Estimated net profit',
    cost: 'Cost per bag (TZS)', noteCost: 'Enter cost per bag in product setup to calculate reliable profit.',
    localOnly: 'Local only · Offline saving works on this device.', language: 'Language',
    typeDealer: 'Dealer', typeFarmer: 'Farmer', typeRetail: 'Retail',
    cashDepot: 'Depot', cashRSO: 'RSO', receipt: 'Stock receipt', salesReport: 'Sales report',
    openingBalance: 'Opening balance', currentBalance: 'Current balance',
    expenseDate: 'Date', description: 'Description', backupDone: 'Backup exported.',
    restoreDone: 'Backup imported.', importInvalid: 'This file is not a valid Kibaigwa app backup.',
    reportInfo: 'Choose a date range. Reports use transactions recorded in this app only.',
    allTime: 'All dates', downloadBackup: 'Download JSON backup', productCost: 'Product cost setup',
    setCost: 'Save cost settings', mt: 'Metric tonnes', value: 'Value', count: 'Records',
    editLater: 'Saved records can be exported. Individual edit/delete not yet included.',
    voucher: 'Voucher no.', receiptNo: 'Receipt no.', approvedBy: 'Approved by',
    received: 'Received (reimbursement)', expenseType: 'Expense', directionLabel: 'Type',
    locked: 'Locked – cannot change again', setOpeningCash: 'Set petty cash opening',
    username: 'Username', password: 'Password', loginBtn: 'Sign in', logout: 'Logout',
    wrongPass: 'Incorrect username or password', depotType: 'Operation type',
    leaderBalance: 'Running Balance', addLeader: 'Add dealer',
    transferOnly: 'Transfer to Factory or Depot only'
  },
  sw: {
    Dashboard: 'Dashibodi', Sales: 'Mauzo', Inventory: 'Hesabu ya bidhaa', Payments: 'Malipo',
    Dealers: 'Daftari la Wauzaji', PayConfirm: 'Thibitisha Malipo', Invoice: 'Ankara', Damage: 'Mifuko iliyoharibika', Transfers: 'Uhamisho',
    DepotCash: 'Fedha ndogo — Depo', RSOCash: 'Fedha ndogo — RSO', Reports: 'Ripoti',
    settings: 'Data na nakala', Login: 'Ingia', today: 'SHUGHULI ZA DEPO',
    salesToday: 'Mauzo ya leo', bagsSold: 'Mifuko iliyouzwa', stockValue: 'Bidhaa zilizopo',
    outstanding: 'Madeni ya wauzaji', salesMT: 'Tani zilizouzwa leo', quick: 'Vitendo vya haraka',
    recent: 'Shughuli za karibuni', stock: 'Muhtasari wa bidhaa', newSale: 'Mauzo mapya',
    receive: 'Pokea bidhaa', payment: 'Rekodi malipo', expense: 'Ongeza matumizi / pokea',
    newDamage: 'Rekodi uharibifu', transfer: 'Uhamisho wa bidhaa', saleForm: 'Ingiza mauzo',
    receiptForm: 'Kupokea bidhaa', paymentForm: 'Ingiza malipo', expenseForm: 'Fedha ndogo',
    damageForm: 'Ingiza uharibifu', transferForm: 'Uhamisho', save: 'Hifadhi', cancel: 'Ghairi',
    date: 'Tarehe', product: 'Bidhaa', qty: 'Idadi (mifuko)', price: 'Bei kwa mfuko (TZS)',
    amount: 'Kiasi (TZS)', dealer: 'Muuzaji / mteja', name: 'Jina', tfra: 'TFRA ID',
    tin: 'TIN', contact: 'Simu', order: 'Namba ya oda', delivery: 'Namba ya delivery',
    invoice: 'Namba ya invoice', type: 'Aina ya mteja', notes: 'Maelezo', source: 'Imetoka wapi',
    reference: 'Rejea ya benki', bank: 'Jina la benki', account: 'Namba ya akaunti',
    cashType: 'Kitabu cha fedha', category: 'Aina ya matumizi', reason: 'Sababu',
    from: 'Kutoka', to: 'Kwenda', direction: 'Aina ya shughuli', loaded: 'Mifuko iliyopakiwa',
    damageQty: 'Mifuko iliyoharibika', shortage: 'Upungufu', truck: 'Namba ya gari',
    driver: 'Dereva', total: 'Jumla', report: 'Tengeneza ripoti', download: 'Pakua CSV',
    print: 'Chapisha / Hifadhi PDF', period: 'Kipindi', start: 'Tarehe ya kuanza',
    end: 'Tarehe ya mwisho', dailyStock: 'Hesabu ya mwisho', salesAnalysis: 'Uchambuzi wa mauzo',
    monthly: 'Muhtasari wa mwezi', ledger: 'Daftari la kiongozi', cashReport: 'Taarifa ya fedha ndogo',
    profit: 'Faida na hasara', consolidation: 'Muhtasari wa depo', transactions: 'Shughuli',
    noData: 'Hakuna rekodi bado.', saved: 'Rekodi imehifadhiwa.', backup: 'Nakala ya data',
    restore: 'Ingiza nakala', reset: 'Futa data', confirmReset: 'Futa data yote? Tengeneza nakala kwanza.',
    search: 'Tafuta', all: 'Zote', opening: 'Hesabu ya mwanzo', setOpening: 'Hifadhi hesabu ya mwanzo',
    openingQty: 'Mifuko ya mwanzo', stockReceived: 'Zilizopokelewa', sold: 'Zilizouzwa',
    damaged: 'Zilizoharibika', transferIn: 'Zilizoingia', transferOut: 'Zilizotoka',
    closing: 'Hesabu ya mwisho', grossSales: 'Mapato ya mauzo', collections: 'Malipo yaliyopokelewa',
    expenses: 'Matumizi', grossProfit: 'Faida ghafi', netProfit: 'Faida halisi',
    cost: 'Gharama kwa mfuko', noteCost: 'Weka gharama ili kukokotoa faida.',
    localOnly: 'Kwenye kifaa hiki pekee.', language: 'Lugha',
    typeDealer: 'Mfanyabiashara', typeFarmer: 'Mkulima', typeRetail: 'Rejareja',
    cashDepot: 'Depo', cashRSO: 'RSO', receipt: 'Kupokea', salesReport: 'Ripoti ya mauzo',
    openingBalance: 'Salio la mwanzo', currentBalance: 'Salio la sasa',
    expenseDate: 'Tarehe', description: 'Maelezo', backupDone: 'Nakala imetolewa.',
    restoreDone: 'Nakala imeingizwa.', importInvalid: 'Faili si nakala halali.',
    reportInfo: 'Chagua tarehe. Ripoti hutumia data ya programu hii pekee.',
    allTime: 'Tarehe zote', downloadBackup: 'Pakua nakala ya JSON', productCost: 'Gharama za bidhaa',
    setCost: 'Hifadhi gharama', mt: 'Tani', value: 'Thamani', count: 'Rekodi',
    editLater: 'Rekodi zinaweza kupakuliwa.',
    voucher: 'Namba ya voucher', receiptNo: 'Namba ya risiti', approvedBy: 'Imeidhinishwa na',
    received: 'Imepokelewa (reimbursement)', expenseType: 'Matumizi', directionLabel: 'Aina',
    locked: 'Imefungwa – haiwezi kubadilishwa tena', setOpeningCash: 'Weka salio la mwanzo',
    username: 'Jina la mtumiaji', password: 'Nenosiri', loginBtn: 'Ingia', logout: 'Toka',
    wrongPass: 'Jina au nenosiri si sahihi', depotType: 'Aina ya shughuli',
    leaderBalance: 'Salio la sasa', addLeader: 'Ongeza muuzaji',
    transferOnly: 'Uhamisho kwenda Factory au Depot pekee'
  }
};

const $ = id => document.getElementById(id);
const today = () => new Date().toISOString().slice(0, 10);
const fmt = n => Number(n || 0).toLocaleString('en-TZ', { maximumFractionDigits: 2 });
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const money = n => 'TZS ' + fmt(n);

let lang = localStorage.getItem('kibaigwaLang') || 'en';
let page = 'Dashboard';
let loggedIn = sessionStorage.getItem('kibaigwaLogged') === '1';
let db = load();

function emptyDB() {
  return {
    sales: [], receipts: [], payments: [], expenses: [], damages: [], transfers: [],
    dealers: SEED_DEALERS.map(d => ({ ...d, id: uid() })),
    opening: {}, costs: {},
    cashOpening: { Depot: 0, RSO: 0 },
    openingLocked: false,
    cashLocked: { Depot: false, RSO: false },
    depotType: 'Depot',
    banks: { ...BANKS },
    users: { admin: 'kibaigwa2026' },
    meta: { version: 2, created: new Date().toISOString() }
  };
}

function load() {
  try {
    let d = JSON.parse(localStorage.getItem('kibaigwaDB'));
    if (d && d.meta) {
      if (!d.cashOpening) d.cashOpening = { Depot: 0, RSO: 0 };
      if (!d.openingLocked) d.openingLocked = false;
      if (!d.cashLocked) d.cashLocked = { Depot: false, RSO: false };
      if (!d.depotType) d.depotType = 'Depot';
      if (!d.banks) d.banks = { ...BANKS };
      if (!d.users) d.users = { admin: 'kibaigwa2026' };
      return d;
    }
  } catch (e) {}
  return emptyDB();
}

function persist() {
  localStorage.setItem('kibaigwaDB', JSON.stringify(db));
  const el = $('syncText');
  if (el) el.textContent = tr('localOnly');
}

function tr(k) { return (T[lang] && T[lang][k]) || T.en[k] || k; }
function toast(s) {
  const t = $('toast');
  if (!t) return;
  t.textContent = s;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}

function options(items, first) {
  return `<option value="">${first || '— Select —'}</option>` +
    items.map(x => `<option value="${esc(x)}">${esc(x)}</option>`).join('');
}
function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function bagMT(qty, product) {
  const m = String(product || '').match(/(\d+)\s*KG/i);
  const kg = m ? Number(m[1]) : 50;
  return (Number(qty || 0) * kg) / 1000;
}

function allTx() {
  return [
    ...db.sales.map(x => ({ ...x, kind: 'sale' })),
    ...db.receipts.map(x => ({ ...x, kind: 'receipt' })),
    ...db.payments.map(x => ({ ...x, kind: 'payment' })),
    ...db.expenses.map(x => ({ ...x, kind: 'expense' })),
    ...db.damages.map(x => ({ ...x, kind: 'damage' })),
    ...db.transfers.map(x => ({ ...x, kind: 'transfer' }))
  ].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
}

function sum(arr, fn) { return arr.reduce((s, x) => s + Number(fn(x) || 0), 0); }
function salesIn(range) {
  return db.sales.filter(x => (!range?.start || x.date >= range.start) && (!range?.end || x.date <= range.end));
}

function stockFor(product, date = today()) {
  const opening = Number(db.opening[product] || 0);
  const receipts = sum(db.receipts.filter(x => x.product === product && x.date <= date), x => x.qty);
  const sold = sum(db.sales.filter(x => x.product === product && x.date <= date), x => x.qty);
  const damaged = sum(db.damages.filter(x => x.product === product && x.date <= date), x => x.qty);
  const tin = sum(db.transfers.filter(x => x.product === product && x.to === 'Depot' && x.date <= date), x => x.qty);
  const tout = sum(db.transfers.filter(x => x.product === product && x.from === 'Depot' && x.date <= date), x => x.qty);
  return opening + receipts - sold - damaged + tin - tout;
}

function cashBalance(book) {
  const open = Number(db.cashOpening[book] || 0);
  const exps = sum(db.expenses.filter(x => (x.book || 'Depot') === book && x.direction !== 'Received'), x => x.amount);
  const rec = sum(db.expenses.filter(x => (x.book || 'Depot') === book && x.direction === 'Received'), x => x.amount);
  return open + rec - exps;
}

function showLogin() {
  document.body.innerHTML = `
  <div class="login-wrap">
    <div class="login-card">
      <div class="brand-mark big">KD</div>
      <h1>Kibaigwa Depot</h1>
      <p class="muted">Sign in to continue</p>
      <form id="loginForm">
        <div class="field"><label>${tr('username')}</label><input name="user" required autocomplete="username" value="admin"></div>
        <div class="field"><label>${tr('password')}</label><input name="pass" type="password" required autocomplete="current-password"></div>
        <button class="btn full" type="submit">${tr('loginBtn')}</button>
      </form>
      <p class="muted small" id="loginErr"></p>
      <p class="muted small">Default: admin / kibaigwa2026</p>
    </div>
  </div>
  <div id="toast" role="status"></div>`;
  document.getElementById('loginForm').onsubmit = e => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const u = fd.get('user').trim();
    const p = fd.get('pass');
    if (db.users[u] && db.users[u] === p) {
      loggedIn = true;
      sessionStorage.setItem('kibaigwaLogged', '1');
      boot();
    } else {
      document.getElementById('loginErr').textContent = tr('wrongPass');
    }
  };
}

function navItems() {
  const type = db.depotType || 'Depot';
  return [
    ['Dashboard', '▣'],
    ['Sales', '¤'],
    ['Inventory', '▦'],
    ['Payments', '฿'],
    ['PayConfirm', '✓'],
    ['Invoice', '📄'],
    ['Dealers', '☺'],
    ['Damage', '⚠'],
    ['Transfers', '⇄'],
    [type === 'RSO' ? 'RSOCash' : 'DepotCash', '₵'],
    ['Reports', '▤'],
    ['settings', '⚙']
  ];
}

function renderNav() {
  const nav = $('nav');
  if (!nav) return;
  nav.innerHTML = navItems().map(([p, ico]) =>
    `<button class="${page === p ? 'active' : ''}" data-page="${p}"><span class="ico">${ico}</span>${tr(p)}</button>`
  ).join('');
  nav.querySelectorAll('button').forEach(b => b.onclick = () => go(b.dataset.page));
}

function go(p) {
  page = p;
  renderNav();
  $('pageTitle').textContent = tr(p);
  $('todayLabel').textContent = tr('today') + ' · ' + (db.depotType || 'Depot');
  if (p === 'Dashboard') dashboard();
  else if (p === 'Sales') listPage('sales');
  else if (p === 'Inventory') inventory();
  else if (p === 'Payments') listPage('payments');
  else if (p === 'PayConfirm') payConfirmPage();
  else if (p === 'Invoice') invoicePage();
  else if (p === 'Dealers') dealers();
  else if (p === 'Damage') listPage('damages');
  else if (p === 'Transfers') listPage('transfers');
  else if (p === 'DepotCash' || p === 'RSOCash') listPage('expenses', p === 'RSOCash' ? 'RSO' : 'Depot');
  else if (p === 'Reports') reports();
  else if (p === 'settings') settings();
}

function dashboard() {
  const td = salesIn({ start: today(), end: today() });
  const all = salesIn({});
  let outstanding = 0;
  db.dealers.forEach(d => {
    const s = sum(db.sales.filter(x => x.dealer === d.name), x => x.total);
    const p = sum(db.payments.filter(x => x.dealer === d.name), x => x.amount);
    outstanding += (s - p);
  });
  const stockBags = sum(PRODUCTS, p => stockFor(p));
  const stockVal = sum(PRODUCTS, p => stockFor(p) * Number(db.costs[p] || 0));

  $('content').innerHTML = `
  <div class="grid stats">
    <div class="card"><div class="stat-label">${tr('salesToday')}</div><div class="stat-value">${money(sum(td, x => x.total))}</div>
      <div class="stat-foot">${fmt(sum(td, x => x.qty))} bags · ${fmt(sum(td, x => x.mt))} MT</div></div>
    <div class="card"><div class="stat-label">${tr('bagsSold')}</div><div class="stat-value">${fmt(sum(all, x => x.qty))}</div>
      <div class="stat-foot">All time</div></div>
    <div class="card"><div class="stat-label">${tr('stockValue')}</div><div class="stat-value">${fmt(stockBags)}</div>
      <div class="stat-foot">${stockVal ? money(stockVal) : 'Set costs for value'}</div></div>
    <div class="card"><div class="stat-label">${tr('outstanding')}</div><div class="stat-value">${money(outstanding)}</div>
      <div class="stat-foot">Dealers</div></div>
  </div>
  <div class="grid two-col">
    <div class="card">
      <div class="card-head"><h2>${tr('quick')}</h2></div>
      <div class="actions-grid">
        <button class="quick" data-action="sale"><span>¤</span><b>${tr('newSale')}</b></button>
        <button class="quick" data-action="receipt"><span>↓</span><b>${tr('receive')}</b></button>
        <button class="quick" data-action="payment"><span>฿</span><b>${tr('payment')}</b></button>
        <button class="quick" data-action="expense"><span>₵</span><b>${tr('expense')}</b></button>
        <button class="quick" data-action="damage"><span>⚠</span><b>${tr('newDamage')}</b></button>
        <button class="quick" data-action="transfer"><span>⇄</span><b>${tr('transfer')}</b></button>
      </div>
    </div>
    <div class="card">
      <div class="card-head"><h2>${tr('stock')}</h2></div>
      ${PRODUCTS.slice(0, 6).map(p => {
        const q = stockFor(p);
        return `<div class="stock-row"><div><div class="stock-name">${esc(p)}</div>
          <div class="stock-sub">${fmt(bagMT(q, p))} MT</div></div>
          <div class="stock-num">${fmt(q)}</div></div>`;
      }).join('')}
    </div>
  </div>
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h2>${tr('recent')}</h2></div>
    <div class="table-wrap">${renderListTable(allTx().slice(0, 12), 'mixed')}</div>
  </div>`;
  $('content').querySelectorAll('[data-action]').forEach(b => b.onclick = () => openForm(b.dataset.action));
}

function field(label, name, type = 'text', extra = '') {
  return `<div class="field"><label>${label}</label><input name="${name}" type="${type}" ${extra}></div>`;
}
function text(label, name, extra = '') { return field(label, name, 'text', extra); }
function num(label, name, extra = '') { return field(label, name, 'number', `min="0" step="any" ${extra}`); }
function sel(label, name, items, first) {
  return `<div class="field"><label>${label}</label><select name="${name}" required>${options(items, first)}</select></div>`;
}

function openForm(kind) {
  const titles = {
    sale: tr('saleForm'), receipt: tr('receiptForm'), payment: tr('paymentForm'),
    expense: tr('expenseForm'), damage: tr('damageForm'), transfer: tr('transferForm')
  };
  let form = `<div class="card form-card"><div class="card-head"><h2>${titles[kind]}</h2>
    <button class="btn secondary" id="cancelForm">${tr('cancel')}</button></div>
    <form id="entryForm"><div class="form-grid">
    ${field(tr('date'), 'date', 'date', `value="${today()}" required`)}`;

  if (kind === 'sale') {
    form += `
      <div class="field"><label>${tr('dealer')}</label>
        <input list="dealerList" name="dealer" id="saleDealer" required placeholder="Type or select dealer">
        <datalist id="dealerList">${db.dealers.map(d => `<option value="${esc(d.name)}">`).join('')}</datalist>
      </div>
      ${sel(tr('type'), 'customerType', [tr('typeDealer'), tr('typeFarmer'), tr('typeRetail')], tr('type'))}
      ${text('Mobile number', 'mobile', 'required')}
      ${text('TFRA number', 'tfra')}
      ${text('TIN number', 'tin', 'id="tinField"')}
      ${text(tr('order'), 'order')}
      ${text('Delivery Note No.', 'delivery')}
      ${text(tr('invoice') + ' (can enter later)', 'invoice')}
      ${text('Truck number', 'truck')}
      ${text('Driver name', 'driver')}
      ${text('Driver mobile', 'driverMobile')}
      ${text('Payment confirmed by', 'paymentConfirmedBy')}
      ${text('Payment slip ref / file', 'paymentSlipRef')}
      ${text('Loading photo / file note', 'loadingPhotoNote')}
      ${text(tr('notes'), 'notes')}
      </div>
      <div style="margin:14px 0 8px;font-weight:600">Products on this Delivery (add multiple)</div>
      <div class="table-wrap"><table id="saleLines">
        <thead><tr><th>Product</th><th>Qty (bags)</th><th>Price / bag</th><th>Line total</th><th></th></tr></thead>
        <tbody id="saleLinesBody">
          <tr class="sale-line">
            <td><select name="line_product" class="line-product">${PRODUCTS.map(p=>`<option value="${esc(p)}">${esc(p)}</option>`).join('')}</select></td>
            <td><input type="number" name="line_qty" class="line-qty" min="0" step="1" value="0" style="width:90px"></td>
            <td><input type="number" name="line_price" class="line-price" min="0" step="1" value="0" style="width:110px"></td>
            <td class="line-total">0</td>
            <td><button type="button" class="btn secondary rm-line" style="padding:4px 8px">✕</button></td>
          </tr>
        </tbody>
      </table></div>
      <button type="button" class="btn secondary" id="addSaleLine" style="margin:8px 0">+ Add another product</button>
      <div id="saleGrand" style="font-weight:700;margin:8px 0">Grand total: TZS 0 · 0 MT</div>
      <div class="form-grid">`;
  }

  if (kind === 'receipt') {
    form += `
      ${text(tr('source'), 'source', 'required')}
      ${sel(tr('product'), 'product', PRODUCTS, tr('product'))}
      ${num(tr('loaded'), 'loaded', 'required')}
      ${num(tr('damageQty'), 'damageQty')}
      ${num(tr('shortage'), 'shortage')}
      ${text(tr('delivery'), 'delivery')}
      ${text(tr('truck'), 'truck')}
      ${text(tr('driver'), 'driver')}
      ${text(tr('notes'), 'notes')}`;
  }

  if (kind === 'payment') {
    form += `
      <div class="field"><label>${tr('dealer')}</label>
        <input list="dealerList" name="dealer" required>
        <datalist id="dealerList">${db.dealers.map(d => `<option value="${esc(d.name)}">`).join('')}</datalist>
      </div>
      ${num(tr('amount'), 'amount', 'required')}
      ${text(tr('reference'), 'reference', 'required')}
      <div class="field"><label>${tr('bank')}</label>
        <select name="bank" id="bankSelect" required>
          <option value="">— Select —</option>
          <option value="NMB">NMB</option>
          <option value="CRDB">CRDB</option>
        </select>
      </div>
      ${text(tr('account'), 'account', 'id="accountField" readonly')}
      ${text(tr('notes'), 'notes')}`;
  }

  if (kind === 'expense') {
    const book = page === 'RSOCash' ? 'RSO' : 'Depot';
    form += `
      <input type="hidden" name="book" value="${book}">
      ${sel(tr('directionLabel'), 'direction', [tr('expenseType'), tr('received')], tr('directionLabel'))}
      ${text(tr('voucher'), 'voucher')}
      ${text(tr('receiptNo'), 'receiptNo')}
      ${sel(tr('approvedBy'), 'approvedBy', APPROVERS, tr('approvedBy'))}
      ${sel(tr('category'), 'category', ['Transport', 'Fuel', 'Meals', 'Repair & maintenance', 'Office supplies', 'Communication', 'Accommodation', 'Other'], tr('category'))}
      ${num(tr('amount'), 'amount', 'required')}
      ${text(tr('reference'), 'reference')}
      ${text('Voucher / Receipt file note (or image name)', 'attachmentNote')}
      ${text(tr('notes'), 'notes', 'required')}`;
  }

  if (kind === 'damage') {
    form += `
      ${sel(tr('product'), 'product', PRODUCTS, tr('product'))}
      ${num(tr('qty'), 'qty', 'required')}
      ${sel(tr('reason'), 'reason', DAMAGE_REASONS, tr('reason'))}
      ${sel(tr('to'), 'transferTo', TRANSFER_DEST, 'Transfer to (optional)')}
      ${text(tr('delivery'), 'delivery')}
      ${text(tr('notes'), 'notes')}`;
  }

  if (kind === 'transfer') {
    form += `
      ${sel(tr('product'), 'product', PRODUCTS, tr('product'))}
      ${num(tr('qty'), 'qty', 'required')}
      ${sel(tr('from'), 'from', TRANSFER_DEST, tr('from'))}
      ${sel(tr('to'), 'to', TRANSFER_DEST, tr('to'))}
      ${text(tr('delivery'), 'delivery')}
      ${text(tr('truck'), 'truck')}
      ${text(tr('notes'), 'notes')}
      <p class="muted full">${tr('transferOnly')}</p>`;
  }

  form += `</div><div class="btn-row"><button class="btn" type="submit">${tr('save')}</button>
    <span class="muted" id="calc"></span></div></form></div>`;
  $('content').innerHTML = form;
  $('cancelForm').onclick = () => go(page === 'DepotCash' || page === 'RSOCash' ? page : 'Dashboard');

  const f = $('entryForm');

  if (kind === 'payment') {
    const bs = $('bankSelect');
    const af = $('accountField');
    if (bs && af) {
      bs.onchange = () => { af.value = db.banks[bs.value] || BANKS[bs.value] || ''; };
    }
  }

  if (kind === 'sale') {
    const dealerInput = $('saleDealer');
    const tinField = document.querySelector('[name="tin"]');
    const tfraField = document.querySelector('[name="tfra"]');
    const mobileField = document.querySelector('[name="mobile"]');
    if (dealerInput) {
      dealerInput.addEventListener('change', () => {
        const d = db.dealers.find(x => x.name === dealerInput.value);
        if (d) {
          if (tinField) tinField.value = d.tin || '';
          if (tfraField) tfraField.value = d.tfra || '';
          if (mobileField) mobileField.value = d.mobile || d.contact || '';
        }
      });
    }
  }

  if (kind === 'sale') {
    const recalcLines = () => {
      let grand = 0, grandMT = 0;
      document.querySelectorAll('.sale-line').forEach(row => {
        const q = Number(row.querySelector('.line-qty')?.value || 0);
        const p = Number(row.querySelector('.line-price')?.value || 0);
        const prod = row.querySelector('.line-product')?.value || '';
        const total = q * p;
        const cell = row.querySelector('.line-total');
        if (cell) cell.textContent = money(total);
        grand += total;
        grandMT += bagMT(q, prod);
      });
      const g = $('saleGrand');
      if (g) g.textContent = `Grand total: ${money(grand)} · ${fmt(grandMT)} MT`;
    };
    const bindLine = (row) => {
      row.querySelector('.line-qty').oninput = recalcLines;
      row.querySelector('.line-price').oninput = recalcLines;
      row.querySelector('.line-product').onchange = recalcLines;
      row.querySelector('.rm-line').onclick = () => {
        if (document.querySelectorAll('.sale-line').length > 1) { row.remove(); recalcLines(); }
      };
    };
    document.querySelectorAll('.sale-line').forEach(bindLine);
    if ($('addSaleLine')) {
      $('addSaleLine').onclick = () => {
        const body = $('saleLinesBody');
        const tr = document.createElement('tr');
        tr.className = 'sale-line';
        tr.innerHTML = `<td><select name="line_product" class="line-product">${PRODUCTS.map(p=>`<option value="${esc(p)}">${esc(p)}</option>`).join('')}</select></td>
          <td><input type="number" name="line_qty" class="line-qty" min="0" step="1" value="0" style="width:90px"></td>
          <td><input type="number" name="line_price" class="line-price" min="0" step="1" value="0" style="width:110px"></td>
          <td class="line-total">0</td>
          <td><button type="button" class="btn secondary rm-line" style="padding:4px 8px">✕</button></td>`;
        body.appendChild(tr);
        bindLine(tr);
        recalcLines();
      };
    }
    recalcLines();
  }

  f.onsubmit = e => {
    e.preventDefault();
    const v = Object.fromEntries(new FormData(f).entries());
    v.id = uid();

    if (kind === 'sale') {
      if (!v.dealer || !v.customerType) {
        toast('Please fill Dealer and Customer type');
        return;
      }
      if (v.customerType === tr('typeDealer') || v.customerType === 'Dealer') {
        if (!v.tin || !String(v.tin).trim()) {
          toast('TIN number is required for Dealer');
          return;
        }
      }
      if (!v.mobile || !String(v.mobile).trim()) {
        toast('Mobile number is required');
        return;
      }
      // Collect multi-product lines
      const products = Array.from(f.querySelectorAll('.line-product')).map(el => el.value);
      const qtys = Array.from(f.querySelectorAll('.line-qty')).map(el => Number(el.value || 0));
      const prices = Array.from(f.querySelectorAll('.line-price')).map(el => Number(el.value || 0));
      const lines = [];
      for (let i = 0; i < products.length; i++) {
        if (qtys[i] > 0 && PRODUCTS.includes(products[i])) {
          lines.push({ product: products[i], qty: qtys[i], price: prices[i] });
        }
      }
      if (!lines.length) {
        toast('Add at least one product with quantity > 0');
        return;
      }
      if (v.dealer && !db.dealers.find(d => d.name === v.dealer)) {
        db.dealers.push({ id: uid(), name: v.dealer, tfra: v.tfra || '', tin: v.tin || '', mobile: v.mobile || '', contact: v.mobile || '' });
      }
      // Create one sale record per product line (same delivery header)
      const groupId = uid();
      lines.forEach(line => {
        const rec = {
          id: uid(), groupId, date: v.date, dealer: v.dealer, customerType: v.customerType,
          mobile: v.mobile, tfra: v.tfra || '', tin: v.tin || '',
          order: v.order || '', delivery: v.delivery || '', invoice: v.invoice || '',
          truck: v.truck || '', driver: v.driver || '', driverMobile: v.driverMobile || '',
          paymentConfirmedBy: v.paymentConfirmedBy || '',
          paymentSlipRef: v.paymentSlipRef || '', loadingPhotoNote: v.loadingPhotoNote || '',
          notes: v.notes || '',
          product: line.product, qty: line.qty, price: line.price,
          total: line.qty * line.price, mt: bagMT(line.qty, line.product), kind: 'sale'
        };
        db.sales.push(rec);
      });
    } else if (kind === 'receipt') {
      v.qty = Math.max(0, Number(v.loaded || 0) - Number(v.shortage || 0));
      v.loaded = Number(v.loaded || 0); v.damageQty = Number(v.damageQty || 0);
      v.shortage = Number(v.shortage || 0); v.kind = 'receipt';
      db.receipts.push(v);
      if (v.damageQty) {
        db.damages.push({
          id: uid(), date: v.date, product: v.product, qty: v.damageQty,
          reason: 'Stitching damage', notes: 'Auto from receipt ' + (v.delivery || ''), source: 'receipt'
        });
      }
    } else if (kind === 'payment') {
      v.amount = +v.amount;
      if (!v.bank || !['NMB', 'CRDB'].includes(v.bank)) {
        toast('Select NMB or CRDB only');
        return;
      }
      db.payments.push(v);
    } else if (kind === 'expense') {
      v.amount = +v.amount;
      v.book = v.book || 'Depot';
      v.direction = v.direction || tr('expenseType');
      db.expenses.push(v);
    } else if (kind === 'damage') {
      v.qty = +v.qty;
      if (!DAMAGE_REASONS.includes(v.reason)) {
        toast('Select a valid damage reason');
        return;
      }
      db.damages.push(v);
    } else if (kind === 'transfer') {
      v.qty = +v.qty;
      if (!TRANSFER_DEST.includes(v.from) || !TRANSFER_DEST.includes(v.to)) {
        toast(tr('transferOnly'));
        return;
      }
      if (v.from === v.to) {
        toast('From and To must differ');
        return;
      }
      db.transfers.push(v);
    }

    persist();
    toast(tr('saved'));
    const next = kind === 'sale' ? 'Sales'
      : (kind === 'receipt' || kind === 'damage' || kind === 'transfer') ? 'Inventory'
      : kind === 'payment' ? 'Payments'
      : (v.book === 'RSO' ? 'RSOCash' : 'DepotCash');
    go(next);
  };
}

function listPage(key, book) {
  let arr = db[key] || [];
  if (book) arr = arr.filter(x => (x.book || 'Depot') === book);

  const heading = (page === 'DepotCash' || page === 'RSOCash') ? tr(page) : tr(page);
  const addMap = { sales: 'sale', payments: 'payment', expenses: 'expense', damages: 'damage', transfers: 'transfer' };
  const add = addMap[key];
  const addLabel = {
    sale: tr('newSale'), payment: tr('payment'), expense: tr('expense'),
    damage: tr('newDamage'), transfer: tr('transfer')
  }[add] || tr('save');

  let balanceHtml = '';
  if (key === 'expenses' && book) {
    const bal = cashBalance(book);
    const locked = db.cashLocked[book];
    balanceHtml = `<div class="balance-banner">
      <div><span class="stat-label">${tr('currentBalance')} (${book})</span>
        <div class="stat-value">${money(bal)}</div></div>
      ${locked ? `<span class="pill locked">${tr('locked')}</span>` :
        `<button class="btn secondary" id="setCashOpen">${tr('setOpeningCash')}</button>`}
    </div>`;
  }

  $('content').innerHTML = `
  <div class="card">
    <div class="card-head"><div><h2>${heading}</h2>
      <p>${arr.length} ${tr('count').toLowerCase()}</p></div>
      <button class="btn" id="addBtn">+ ${addLabel}</button></div>
    ${balanceHtml}
    <div class="filter-row">
      <input id="searchRows" placeholder="${tr('search')}…">
      <input type="date" id="filterDate">
      <button class="btn secondary" id="exportRows">${tr('download')}</button>
      <button class="btn secondary" id="printRows">${tr('print')}</button>
    </div>
    <div id="tableArea">${renderListTable(arr, key)}</div>
  </div>`;

  $('addBtn').onclick = () => openForm(add);
  $('exportRows').onclick = () => downloadCSV(arr, `${key}-${today()}.csv`);
  $('printRows').onclick = () => window.print();

  if (key === 'expenses' && book && !db.cashLocked[book]) {
    const btn = $('setCashOpen');
    if (btn) btn.onclick = () => {
      const val = prompt(tr('openingBalance') + ' (TZS):', db.cashOpening[book] || 0);
      if (val === null) return;
      db.cashOpening[book] = Number(val) || 0;
      db.cashLocked[book] = true;
      persist();
      toast(tr('saved') + ' — ' + tr('locked'));
      listPage(key, book);
    };
  }

  function filter() {
    const q = $('searchRows').value.toLowerCase(), d = $('filterDate').value;
    const a = arr.filter(x => (!d || x.date === d) && JSON.stringify(x).toLowerCase().includes(q));
    $('tableArea').innerHTML = renderListTable(a, key);
  }
  $('searchRows').oninput = filter;
  $('filterDate').onchange = filter;

  // Select + Delete any entry
  const delBtn = document.createElement('button');
  delBtn.className = 'btn secondary';
  delBtn.style.marginLeft = '8px';
  delBtn.textContent = 'Delete selected';
  delBtn.onclick = () => {
    const sel = document.querySelector('input[name="rowSelect"]:checked');
    if (!sel) { toast('Select a row first (radio button)'); return; }
    const id = sel.value;
    if (!confirm('Delete this record permanently?')) return;
    const idx = db[key].findIndex(x => x.id === id);
    if (idx >= 0) {
      db[key].splice(idx, 1);
      persist();
      toast('Record deleted. You can re-enter if needed.');
      listPage(key, book);
    }
  };
  const filterRow = document.querySelector('.filter-row');
  if (filterRow) filterRow.appendChild(delBtn);
}

function renderListTable(arr, key) {
  if (!arr.length) return `<div class="empty">${tr('noData')}</div>`;
  let cols;
  if (key === 'sales') cols = ['date', 'order', 'invoice', 'dealer', 'customerType', 'product', 'qty', 'price', 'total', 'mobile', 'truck', 'driver'];
  else if (key === 'payments') cols = ['date', 'dealer', 'amount', 'bank', 'account', 'reference'];
  else if (key === 'expenses') cols = ['date', 'direction', 'voucher', 'receiptNo', 'approvedBy', 'category', 'amount', 'notes'];
  else if (key === 'damages') cols = ['date', 'product', 'qty', 'reason', 'transferTo', 'notes'];
  else if (key === 'transfers') cols = ['date', 'product', 'qty', 'from', 'to', 'truck'];
  else if (key === 'receipts') cols = ['date', 'product', 'qty', 'source', 'delivery'];
  else cols = ['date', 'kind', 'dealer', 'product', 'amount', 'qty'];

  const head = '<th></th>' + cols.map(c => `<th>${tr(c) || c}</th>`).join('');
  const body = arr.map(x => `<tr><td><input type="radio" name="rowSelect" value="${esc(x.id || '')}"></td>${cols.map(c => {
    let val = x[c];
    if (c === 'total' || c === 'amount' || c === 'price') val = money(val);
    if (c === 'qty' || c === 'loaded') val = fmt(val);
    return `<td>${esc(val ?? '—')}</td>`;
  }).join('')}</tr>`).join('');
  return `<div class="table-wrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>`;
}

function inventory() {
  const rows = PRODUCTS.map(p => {
    const opening = Number(db.opening[p] || 0);
    const received = sum(db.receipts.filter(x => x.product === p), x => x.qty);
    const sold = sum(db.sales.filter(x => x.product === p), x => x.qty);
    const damaged = sum(db.damages.filter(x => x.product === p), x => x.qty);
    const closing = stockFor(p);
    return { product: p, opening, received, sold, damaged, closing, mt: bagMT(closing, p) };
  });

  const locked = db.openingLocked;
  $('content').innerHTML = `
  <div class="card">
    <div class="card-head"><div><h2>${tr('stock')}</h2>
      <p>${locked ? tr('locked') : 'Set opening once, then it locks'}</p></div>
      ${locked ? `<span class="pill locked">${tr('locked')}</span>` :
        `<button class="btn" id="openingBtn">${tr('opening')}</button>`}
    </div>
    <div class="table-wrap"><table>
      <thead><tr><th>${tr('product')}</th><th>${tr('opening')}</th><th>${tr('stockReceived')}</th>
        <th>${tr('sold')}</th><th>${tr('damaged')}</th><th>${tr('closing')}</th><th>${tr('mt')}</th></tr></thead>
      <tbody>${rows.map(x => `<tr>
        <td>${esc(x.product)}</td><td>${fmt(x.opening)}</td><td>${fmt(x.received)}</td>
        <td>${fmt(x.sold)}</td><td>${fmt(x.damaged)}</td><td><b>${fmt(x.closing)}</b></td>
        <td>${fmt(x.mt)}</td></tr>`).join('')}
      </tbody></table></div>
    <div class="btn-row" style="margin-top:15px">
      <button class="btn secondary" id="exportStock">${tr('download')}</button>
      <button class="btn secondary" id="printStock">${tr('print')}</button>
      <button class="btn" data-action="receipt">+ ${tr('receive')}</button>
      <button class="btn secondary" data-action="transfer">+ ${tr('transfer')}</button>
      <button class="btn warn" data-action="damage">+ ${tr('newDamage')}</button>
    </div>
  </div>`;

  if (!locked) {
    $('openingBtn').onclick = () => {
      $('content').innerHTML = `<div class="card form-card">
        <div class="card-head"><h2>${tr('opening')}</h2>
          <button class="btn secondary" id="cancelOpen">${tr('cancel')}</button></div>
        <form id="openingForm"><div class="form-grid">
          ${PRODUCTS.map((p, i) => `<div class="field"><label>${esc(p)}</label>
            <input type="number" min="0" step="1" name="p${i}" value="${Number(db.opening[p] || 0)}"></div>`).join('')}
        </div>
        <div class="btn-row" style="margin-top:16px">
          <button class="btn">${tr('setOpening')}</button>
          <span class="muted">After save this will be locked permanently</span>
        </div></form></div>`;
      $('cancelOpen').onclick = () => inventory();
      $('openingForm').onsubmit = e => {
        e.preventDefault();
        const f = new FormData(e.target);
        PRODUCTS.forEach((p, i) => db.opening[p] = Number(f.get('p' + i) || 0));
        db.openingLocked = true;
        persist();
        toast(tr('saved') + ' — ' + tr('locked'));
        inventory();
      };
    };
  }

  $('exportStock').onclick = () => downloadCSV(rows.map(x => ({ ...x, asOf: today() })), 'closing-stock-' + today() + '.csv');
  $('printStock').onclick = () => window.print();
  $('content').querySelectorAll('[data-action]').forEach(b => b.onclick = () => openForm(b.dataset.action));
}


function dealers() {
  // Summary view of all dealers (party-wise outstanding) – only Dealer type sales/payments
  $('content').innerHTML = `
  <div class="card">
    <div class="card-head"><div><h2>${tr('Dealers')}</h2>
      <p>${db.dealers.length} dealers · party-wise running balance (Dealer type only)</p></div>
      <button class="btn" id="newDealer">+ ${tr('addLeader')}</button></div>
    <div class="filter-row">
      <input id="dealerSearch" placeholder="${tr('search')}…">
      <button class="btn secondary" id="dealerCSV">${tr('download')}</button>
      <button class="btn secondary" id="dealerPrint">${tr('print')}</button>
    </div>
    <div id="dealerTable">${dealerTable(db.dealers)}</div>
  </div>
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h2>Individual Dealer Ledger (transactions)</h2>
      <select id="pickDealer"><option value="">— Select dealer —</option>
        ${db.dealers.map(d => `<option value="${esc(d.name)}">${esc(d.name)}</option>`).join('')}
      </select>
    </div>
    <div id="indivLedger"><div class="empty">Select a dealer above to see full Cr/Dr transactions</div></div>
  </div>`;

  $('newDealer').onclick = () => {
    $('content').innerHTML = `<div class="card form-card">
      <div class="card-head"><h2>${tr('addLeader')}</h2>
        <button class="btn secondary" id="cancelD">${tr('cancel')}</button></div>
      <form id="dealerForm"><div class="form-grid">
        ${text(tr('name'), 'name', 'required')}
        ${text(tr('tfra'), 'tfra')}
        ${text(tr('tin'), 'tin')}
        ${text('Mobile', 'mobile')}
        ${text(tr('contact'), 'contact')}
      </div><div class="btn-row"><button class="btn">${tr('save')}</button></div></form></div>`;
    $('cancelD').onclick = () => dealers();
    $('dealerForm').onsubmit = e => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(e.target).entries());
      data.id = uid();
      if (!data.mobile) data.mobile = data.contact || '';
      db.dealers.push(data);
      persist();
      toast(tr('saved'));
      dealers();
    };
  };

  $('dealerCSV').onclick = () => {
    const rows = db.dealers.map(d => {
      const s = sum(db.sales.filter(x => x.dealer === d.name && (x.customerType === 'Dealer' || x.customerType === tr('typeDealer'))), x => x.total);
      const p = sum(db.payments.filter(x => x.dealer === d.name), x => x.amount);
      return { name: d.name, tfra: d.tfra, tin: d.tin, mobile: d.mobile || d.contact, sales: s, payments: p, runningBalance: s - p };
    });
    downloadCSV(rows, 'dealer-ledger-summary-' + today() + '.csv');
  };
  $('dealerPrint').onclick = () => window.print();

  $('dealerSearch').oninput = () => {
    const q = $('dealerSearch').value.toLowerCase();
    $('dealerTable').innerHTML = dealerTable(db.dealers.filter(d => JSON.stringify(d).toLowerCase().includes(q)));
  };

  // Individual ledger
  $('pickDealer').onchange = () => {
    const name = $('pickDealer').value;
    if (!name) {
      $('indivLedger').innerHTML = '<div class="empty">Select a dealer</div>';
      return;
    }
    // Collect sales (Dr) and payments (Cr) for this dealer only
    const sales = db.sales.filter(x => x.dealer === name).map(x => ({
      date: x.date, type: 'Debit', ref: x.order || x.invoice || '', bankAc: '', product: x.product,
      qty: x.qty, mt: x.mt, unitPrice: x.price, cr: '', dr: x.total, truck: x.truck || '', driver: x.driver || '', mobile: x.mobile || ''
    }));
    const pays = db.payments.filter(x => x.dealer === name).map(x => ({
      date: x.date, type: 'Credit', ref: x.reference || '', bankAc: x.account || '', product: '',
      qty: '', mt: '', unitPrice: '', cr: x.amount, dr: '', truck: '', driver: '', mobile: ''
    }));
    const all = [...sales, ...pays].sort((a, b) => (a.date || '').localeCompare(b.date || ''));
    let bal = 0;
    const rows = all.map(r => {
      bal += (Number(r.dr) || 0) - (Number(r.cr) || 0);
      return { ...r, balance: bal };
    });
    if (!rows.length) {
      $('indivLedger').innerHTML = '<div class="empty">No transactions for this dealer</div>';
      return;
    }
    $('indivLedger').innerHTML = `
      <div class="filter-row">
        <button class="btn secondary" id="indivCSV">${tr('download')}</button>
        <button class="btn secondary" id="indivPrint">${tr('print')}</button>
      </div>
      <div class="table-wrap"><table>
        <thead><tr>
          <th>Date</th><th>Particulars (Cr/Dr)</th><th>Bank Ref / Sales Order</th><th>Bank Ac No</th>
          <th>Product</th><th>Qty</th><th>MT</th><th>Unit Price</th><th>Cr</th><th>Dr</th><th>Balance</th>
          <th>Truck</th><th>Driver</th>
        </tr></thead>
        <tbody>
          ${rows.map(r => `<tr>
            <td>${esc(r.date)}</td><td>${esc(r.type)}</td><td>${esc(r.ref)}</td><td>${esc(r.bankAc)}</td>
            <td>${esc(r.product)}</td><td>${r.qty !== '' ? fmt(r.qty) : ''}</td><td>${r.mt !== '' ? fmt(r.mt) : ''}</td>
            <td>${r.unitPrice !== '' ? fmt(r.unitPrice) : ''}</td>
            <td>${r.cr !== '' ? money(r.cr) : ''}</td><td>${r.dr !== '' ? money(r.dr) : ''}</td>
            <td><b>${money(r.balance)}</b></td>
            <td>${esc(r.truck)}</td><td>${esc(r.driver)}</td>
          </tr>`).join('')}
        </tbody>
      </table></div>`;
    $('indivCSV').onclick = () => downloadCSV(rows, 'dealer-' + name.replace(/\s+/g, '_') + '-' + today() + '.csv');
    $('indivPrint').onclick = () => window.print();
  };
}


function dealerTable(ds) {
  if (!ds.length) return `<div class="empty">${tr('noData')}</div>`;
  return `<div class="table-wrap"><table><thead><tr>
    <th>${tr('name')}</th><th>${tr('tfra')}</th><th>${tr('tin')}</th><th>Mobile</th>
    <th>Sales</th><th>Payments</th><th>Running Balance / Outstanding</th></tr></thead><tbody>
    ${ds.map(d => {
      const s = sum(db.sales.filter(x => x.dealer === d.name), x => x.total);
      const p = sum(db.payments.filter(x => x.dealer === d.name), x => x.amount);
      const bal = s - p;
      return `<tr><td><b>${esc(d.name)}</b></td><td>${esc(d.tfra)}</td><td>${esc(d.tin)}</td>
        <td>${esc(d.mobile || d.contact || '')}</td><td>${money(s)}</td><td>${money(p)}</td>
        <td class="${bal > 0 ? 'danger-text' : ''}"><b>${money(bal)}</b></td></tr>`;
    }).join('')}
  </tbody></table></div>`;
}


function payConfirmPage() {
  // Sales that still need payment confirmation
  const pending = db.sales.filter(x => !x.paymentConfirmedBy || !String(x.paymentConfirmedBy).trim());
  const confirmed = db.sales.filter(x => x.paymentConfirmedBy && String(x.paymentConfirmedBy).trim());
  $('content').innerHTML = `
  <div class="card">
    <div class="card-head"><h2>Payment Confirmation</h2>
      <p>Pending: ${pending.length} · Confirmed: ${confirmed.length}</p></div>
    <div class="notice">Select a pending sale and mark it as payment confirmed. Confirmed sales move to Invoice team.</div>
    <h3 style="margin:12px 0 8px">Pending confirmation</h3>
    <div class="table-wrap"><table>
      <thead><tr><th></th><th>Date</th><th>Dealer</th><th>Product</th><th>Qty</th><th>Total</th><th>Order</th><th>Action</th></tr></thead>
      <tbody>
        ${pending.length ? pending.map(x => `<tr>
          <td><input type="radio" name="pcSel" value="${esc(x.id)}"></td>
          <td>${esc(x.date)}</td><td>${esc(x.dealer)}</td><td>${esc(x.product)}</td>
          <td>${fmt(x.qty)}</td><td>${money(x.total)}</td><td>${esc(x.order||'')}</td>
          <td></td></tr>`).join('') : '<tr><td colspan="8" class="empty">No pending sales</td></tr>'}
      </tbody>
    </table></div>
    <div class="btn-row" style="margin-top:12px">
      <input id="pcBy" placeholder="Confirmed by (name)" style="padding:8px;border-radius:8px;border:1px solid #ccc">
      <button class="btn" id="pcConfirm">Mark as Confirmed</button>
    </div>
    <h3 style="margin:18px 0 8px">Recently confirmed</h3>
    <div class="table-wrap"><table>
      <thead><tr><th>Date</th><th>Dealer</th><th>Product</th><th>Total</th><th>Confirmed By</th></tr></thead>
      <tbody>
        ${confirmed.slice(-15).reverse().map(x => `<tr>
          <td>${esc(x.date)}</td><td>${esc(x.dealer)}</td><td>${esc(x.product)}</td>
          <td>${money(x.total)}</td><td>${esc(x.paymentConfirmedBy)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">None yet</td></tr>'}
      </tbody>
    </table></div>
  </div>`;
  $('pcConfirm').onclick = () => {
    const sel = document.querySelector('input[name="pcSel"]:checked');
    const by = ($('pcBy').value || '').trim();
    if (!sel) { toast('Select a sale'); return; }
    if (!by) { toast('Enter who confirmed'); return; }
    const s = db.sales.find(x => x.id === sel.value);
    if (s) {
      s.paymentConfirmedBy = by;
      s.paymentConfirmedAt = today();
      persist();
      toast('Payment confirmed');
      payConfirmPage();
    }
  };
}

function invoicePage() {
  // Sales that are payment-confirmed but invoice number still empty
  const needInv = db.sales.filter(x => x.paymentConfirmedBy && (!x.invoice || !String(x.invoice).trim()));
  const hasInv = db.sales.filter(x => x.invoice && String(x.invoice).trim());
  $('content').innerHTML = `
  <div class="card">
    <div class="card-head"><h2>Invoice</h2>
      <p>Need invoice: ${needInv.length} · Already invoiced: ${hasInv.length}</p></div>
    <div class="notice">Invoice team: select a confirmed sale and enter the Invoice number (can be done next day).</div>
    <h3 style="margin:12px 0 8px">Waiting for Invoice number</h3>
    <div class="table-wrap"><table>
      <thead><tr><th></th><th>Date</th><th>Dealer</th><th>Product</th><th>Qty</th><th>Total</th><th>Confirmed By</th></tr></thead>
      <tbody>
        ${needInv.length ? needInv.map(x => `<tr>
          <td><input type="radio" name="invSel" value="${esc(x.id)}"></td>
          <td>${esc(x.date)}</td><td>${esc(x.dealer)}</td><td>${esc(x.product)}</td>
          <td>${fmt(x.qty)}</td><td>${money(x.total)}</td><td>${esc(x.paymentConfirmedBy||'')}</td></tr>`).join('') : '<tr><td colspan="7" class="empty">None waiting</td></tr>'}
      </tbody>
    </table></div>
    <div class="btn-row" style="margin-top:12px">
      <input id="invNo" placeholder="Invoice number" style="padding:8px;border-radius:8px;border:1px solid #ccc">
      <button class="btn" id="invSave">Save Invoice No</button>
    </div>
    <h3 style="margin:18px 0 8px">Recently invoiced</h3>
    <div class="table-wrap"><table>
      <thead><tr><th>Date</th><th>Invoice</th><th>Dealer</th><th>Product</th><th>Total</th></tr></thead>
      <tbody>
        ${hasInv.slice(-15).reverse().map(x => `<tr>
          <td>${esc(x.date)}</td><td><b>${esc(x.invoice)}</b></td><td>${esc(x.dealer)}</td>
          <td>${esc(x.product)}</td><td>${money(x.total)}</td></tr>`).join('') || '<tr><td colspan="5" class="empty">None yet</td></tr>'}
      </tbody>
    </table></div>
  </div>`;
  $('invSave').onclick = () => {
    const sel = document.querySelector('input[name="invSel"]:checked');
    const no = ($('invNo').value || '').trim();
    if (!sel) { toast('Select a sale'); return; }
    if (!no) { toast('Enter invoice number'); return; }
    const s = db.sales.find(x => x.id === sel.value);
    if (s) {
      s.invoice = no;
      persist();
      toast('Invoice number saved');
      invoicePage();
    }
  };
}

function reports() {
  const start = today().slice(0, 7) + '-01', end = today();
  $('content').innerHTML = `
  <div class="notice">${tr('reportInfo')}</div>
  <div class="card" style="margin-bottom:14px">
    <div class="card-head"><h2>${tr('period')}</h2><span class="pill">TZS</span></div>
    <div class="filter-row">
      <label class="field"><span>${tr('start')}</span><input type="date" id="reportStart" value="${start}"></label>
      <label class="field"><span>${tr('end')}</span><input type="date" id="reportEnd" value="${end}"></label>
      <button class="btn secondary" id="refreshReports">Update</button>
    </div>
  </div>
  <div class="grid report-grid" id="reportTiles"></div>
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h2 id="previewTitle">Report preview</h2>
      <div><button class="btn secondary" id="csvPreview">${tr('download')}</button>
           <button class="btn" id="printPreview">${tr('print')}</button></div>
    </div>
    <div id="reportPreview"></div>
  </div>`;

  const tiles = [
    ['dailyStock', 'Closing stock by product'],
    ['salesAnalysis', 'Sales Analysis – product & customer detail'],
    ['monthly', 'Monthly Summary – bags & MT by product'],
    ['ledger', 'Dealer ledger – individual transactions'],
    ['cashReport', 'Petty cash Depot + RSO'],
    ['profit', 'Full Profit & Loss'],
    ['consolidation', 'Overall depot consolidation']
  ];
  $('reportTiles').innerHTML = tiles.map(([id, p]) =>
    `<div class="report-tile"><span class="pill">CSV / PDF</span>
      <h3>${tr(id)}</h3><p>${p}</p>
      <button class="btn secondary" data-report="${id}">${tr('report')}</button>
      <button class="btn secondary" data-csv="${id}">${tr('download')}</button>
    </div>`).join('');

  let currentData = [], currentName = '';

  function range() {
    return { start: $('reportStart').value, end: $('reportEnd').value };
  }

  function showReport(id) {
    const r = range();
    let html = '', data = [];
    const titleMap = {
      dailyStock: 'KIBAIGWA – Daily Closing Stock',
      salesAnalysis: 'KIBAIGWA – Sales Analysis',
      monthly: 'KIBAIGWA – Monthly Wise Summary',
      ledger: 'KIBAIGWA – Dealer Ledger',
      cashReport: 'KIBAIGWA – Petty Cash Statement',
      profit: 'KIBAIGWA – Profit & Loss Account',
      consolidation: 'KIBAIGWA – Depot Consolidation'
    };
    currentName = (titleMap[id] || id).replace(/\s+/g, '_') + '_' + today();

    if (id === 'dailyStock') {
      data = PRODUCTS.map(p => {
        const opening = Number(db.opening[p] || 0);
        const received = sum(db.receipts.filter(x => x.product === p && (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end)), x => x.qty);
        const sold = sum(db.sales.filter(x => x.product === p && (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end)), x => x.qty);
        const transferOut = sum(db.transfers.filter(x => x.product === p && x.from === 'Depot' && (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end)), x => x.qty);
        const closing = stockFor(p, r.end || today());
        return {
          Product: p,
          Size_kg: (String(p).match(/(\d+)\s*KG/i) || [])[1] || '',
          Opening: opening,
          Received: received,
          Sold: sold,
          Transfer: transferOut,
          Closing: closing,
          MT: bagMT(closing, p)
        };
      });
      html = `<h3 style="text-align:center;margin:0 0 10px">${titleMap[id]}</h3>
        <p style="text-align:center;margin:0 0 12px">As of ${esc(r.end || today())}</p>
        <table><thead><tr>
          <th>Product Name</th><th>Size (kg)</th><th>Opening</th><th>Received</th><th>Sold</th><th>Transfer</th><th>Closing</th><th>MT</th>
        </tr></thead><tbody>
        ${data.map(x => `<tr>
          <td>${esc(x.Product)}</td><td>${esc(x.Size_kg)}</td><td>${fmt(x.Opening)}</td>
          <td>${fmt(x.Received)}</td><td>${fmt(x.Sold)}</td><td>${fmt(x.Transfer)}</td>
          <td><b>${fmt(x.Closing)}</b></td><td>${fmt(x.MT)}</td></tr>`).join('')}
        <tr style="font-weight:700;background:#f0f7f0">
          <td colspan="2">TOTAL</td>
          <td>${fmt(sum(data,x=>x.Opening))}</td><td>${fmt(sum(data,x=>x.Received))}</td>
          <td>${fmt(sum(data,x=>x.Sold))}</td><td>${fmt(sum(data,x=>x.Transfer))}</td>
          <td>${fmt(sum(data,x=>x.Closing))}</td><td>${fmt(sum(data,x=>x.MT))}</td>
        </tr></tbody></table>`;
    } else if (id === 'salesAnalysis') {
      const sales = salesIn(r);
      data = sales.map(x => ({
        Date: x.date,
        Sales_Order_No: x.order || '',
        Invoice_No: x.invoice || '',
        Dealer_Customer: x.dealer,
        Customer_Type: x.customerType || '',
        Product: x.product,
        Qty_Bags: x.qty,
        MT: x.mt,
        Price_Per_Bag: x.price,
        Total_TZS: x.total,
        Mobile: x.mobile || '',
        Truck: x.truck || '',
        Driver: x.driver || '',
        Delivery_Note: x.delivery || ''
      }));
      html = `<h3 style="text-align:center;margin:0 0 10px">${titleMap[id]}</h3>
        <p style="text-align:center;margin:0 0 12px">Period: ${esc(r.start)} to ${esc(r.end)}</p>
        <div class="table-wrap"><table><thead><tr>
          <th>Date</th><th>Sales Order No</th><th>Invoice No</th><th>Dealer / Customer</th><th>Type</th>
          <th>Product</th><th>Qty (Bags)</th><th>MT</th><th>Price / Bag</th><th>Total (TZS)</th>
          <th>Mobile</th><th>Truck</th><th>Driver</th><th>Delivery Note</th>
        </tr></thead><tbody>
        ${data.map(x => `<tr>
          <td>${esc(x.Date)}</td><td>${esc(x.Sales_Order_No)}</td><td>${esc(x.Invoice_No)}</td>
          <td>${esc(x.Dealer_Customer)}</td><td>${esc(x.Customer_Type)}</td>
          <td>${esc(x.Product)}</td><td>${fmt(x.Qty_Bags)}</td><td>${fmt(x.MT)}</td>
          <td>${fmt(x.Price_Per_Bag)}</td><td>${money(x.Total_TZS)}</td>
          <td>${esc(x.Mobile)}</td><td>${esc(x.Truck)}</td><td>${esc(x.Driver)}</td><td>${esc(x.Delivery_Note)}</td>
        </tr>`).join('') || '<tr><td colspan="14" class="empty">No sales in period</td></tr>'}
        </tbody></table></div>
        <p style="margin-top:10px"><b>Total Bags:</b> ${fmt(sum(sales,x=>x.qty))} &nbsp;|&nbsp;
          <b>Total MT:</b> ${fmt(sum(sales,x=>x.mt))} &nbsp;|&nbsp;
          <b>Total Value:</b> ${money(sum(sales,x=>x.total))}</p>`;
    } else if (id === 'monthly') {
      // Date-wise product MT matrix (like monthly wise summary)
      const sales = salesIn(r);
      const dates = [...new Set(sales.map(x => x.date))].sort();
      const prods = PRODUCTS;
      data = dates.map(d => {
        const row = { Date: d };
        let totalMT = 0;
        prods.forEach(p => {
          const mt = sum(sales.filter(x => x.date === d && x.product === p), x => x.mt);
          row[p] = mt || '';
          totalMT += mt;
        });
        row.Total_MT = totalMT;
        return row;
      });
      // Also bags version summary
      const bagTotals = prods.map(p => ({
        Product: p,
        Bags: sum(sales.filter(x => x.product === p), x => x.qty),
        MT: sum(sales.filter(x => x.product === p), x => x.mt),
        Value: sum(sales.filter(x => x.product === p), x => x.total)
      }));
      html = `<h3 style="text-align:center;margin:0 0 10px">${titleMap[id]}</h3>
        <p style="text-align:center;margin:0 0 12px">Period: ${esc(r.start)} to ${esc(r.end)} · Sales in MT by Date</p>
        <div class="table-wrap"><table><thead><tr>
          <th>Date</th>${prods.map(p => `<th>${esc(p)}</th>`).join('')}<th>Total MT</th>
        </tr></thead><tbody>
        ${data.map(row => `<tr>
          <td>${esc(row.Date)}</td>
          ${prods.map(p => `<td>${row[p] !== '' ? fmt(row[p]) : '-'}</td>`).join('')}
          <td><b>${fmt(row.Total_MT)}</b></td>
        </tr>`).join('') || '<tr><td colspan="'+(prods.length+2)+'" class="empty">No data</td></tr>'}
        <tr style="font-weight:700;background:#f0f7f0">
          <td>TOTAL</td>
          ${prods.map(p => `<td>${fmt(sum(sales.filter(x=>x.product===p),x=>x.mt))}</td>`).join('')}
          <td>${fmt(sum(sales,x=>x.mt))}</td>
        </tr></tbody></table></div>
        <h4 style="margin:16px 0 8px">Product Summary (Bags / MT / Value)</h4>
        <table><thead><tr><th>Product</th><th>Bags</th><th>MT</th><th>Value (TZS)</th></tr></thead>
        <tbody>${bagTotals.map(x => `<tr>
          <td>${esc(x.Product)}</td><td>${fmt(x.Bags)}</td><td>${fmt(x.MT)}</td><td>${money(x.Value)}</td>
        </tr>`).join('')}</tbody></table>`;
    } else if (id === 'ledger') {
      data = db.dealers.map(d => {
        const s = sum(db.sales.filter(x => x.dealer === d.name && (x.customerType === 'Dealer' || x.customerType === tr('typeDealer')) && (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end)), x => x.total);
        const p = sum(db.payments.filter(x => x.dealer === d.name && (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end)), x => x.amount);
        return { Dealer: d.name, TFRA: d.tfra || '', TIN: d.tin || '', Mobile: d.mobile || d.contact || '', Sales: s, Payments: p, Running_Balance: s - p };
      });
      html = `<h3 style="text-align:center;margin:0 0 10px">${titleMap[id]} – Party-wise Outstanding</h3>
        <p style="text-align:center;margin:0 0 12px">Period: ${esc(r.start)} to ${esc(r.end)}</p>
        <table><thead><tr>
          <th>Dealer</th><th>TFRA</th><th>TIN</th><th>Mobile</th><th>Sales</th><th>Payments</th><th>Running Balance</th>
        </tr></thead><tbody>
        ${data.map(x => `<tr>
          <td>${esc(x.Dealer)}</td><td>${esc(x.TFRA)}</td><td>${esc(x.TIN)}</td><td>${esc(x.Mobile)}</td>
          <td>${money(x.Sales)}</td><td>${money(x.Payments)}</td>
          <td><b>${money(x.Running_Balance)}</b></td>
        </tr>`).join('')}</tbody></table>
        <p class="muted" style="margin-top:10px">For individual Cr/Dr transactions go to Dealer Ledger tab and select a dealer.</p>`;
    } else if (id === 'cashReport') {
      const exps = db.expenses.filter(x => (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end));
      data = exps.map(x => ({
        Date: x.date, Book: x.book || 'Depot', Voucher: x.voucher || '', Receipt: x.receipt || '',
        Particulars: x.notes || x.category || '', Direction: x.direction || '',
        Credit: x.direction === 'Received' ? x.amount : '', Debit: x.direction !== 'Received' ? x.amount : '',
        Approved_By: x.approvedBy || '', Attachment: x.attachmentNote || ''
      }));
      html = `<h3 style="text-align:center;margin:0 0 10px">${titleMap[id]}</h3>
        <p style="text-align:center;margin:0 0 12px">Period: ${esc(r.start)} to ${esc(r.end)}</p>
        <table><thead><tr>
          <th>Date</th><th>Book</th><th>Voucher</th><th>Receipt</th><th>Particulars</th>
          <th>Direction</th><th>Credit</th><th>Debit</th><th>Approved By</th>
        </tr></thead><tbody>
        ${data.map(x => `<tr>
          <td>${esc(x.Date)}</td><td>${esc(x.Book)}</td><td>${esc(x.Voucher)}</td><td>${esc(x.Receipt)}</td>
          <td>${esc(x.Particulars)}</td><td>${esc(x.Direction)}</td>
          <td>${x.Credit !== '' ? money(x.Credit) : ''}</td>
          <td>${x.Debit !== '' ? money(x.Debit) : ''}</td>
          <td>${esc(x.Approved_By)}</td>
        </tr>`).join('') || '<tr><td colspan="9" class="empty">No entries</td></tr>'}
        </tbody></table>`;
    } else if (id === 'profit') {
      const salesRev = sum(salesIn(r), x => x.total);
      const cogs = sum(salesIn(r), x => x.qty * Number(db.costs[x.product] || 0));
      const expList = db.expenses.filter(x => x.direction !== 'Received' && (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end));
      const exp = sum(expList, x => x.amount);
      const byCat = {};
      expList.forEach(x => { const c = x.category || 'Other'; byCat[c] = (byCat[c]||0) + Number(x.amount||0); });
      const gross = salesRev - cogs;
      const net = gross - exp;
      data = [{ Gross_Sales: salesRev, Cost_of_Sales: cogs, Gross_Contribution: gross, Total_Expenses: exp, Net_Profit: net, ...byCat }];
      html = `<h3 style="text-align:center;margin:0 0 10px">${titleMap[id]}</h3>
        <p style="text-align:center;margin:0 0 12px">Period: ${esc(r.start)} to ${esc(r.end)} · Depot: KIBAIGWA</p>
        <div class="pl-box">
          <div class="pl-row"><span><b>GROSS SALES / NET AMOUNT (A)</b></span><b>${money(salesRev)}</b></div>
          <div class="pl-row"><span>Less: Cost of Sales (B)</span><b>${money(cogs)}</b></div>
          <div class="pl-row highlight"><span>GROSS CONTRIBUTION (C = A − B)</span><b>${money(gross)}</b></div>
          <div class="pl-row" style="margin-top:10px"><span><b>EXPENSES</b></span><span></span></div>
          ${Object.entries(byCat).map(([k,v]) => `<div class="pl-row"><span>${esc(k)}</span><b>${money(v)}</b></div>`).join('') || '<div class="pl-row"><span>No expenses in period</span><b>—</b></div>'}
          <div class="pl-row"><span><b>TOTAL EXPENSES (J)</b></span><b>${money(exp)}</b></div>
          <div class="pl-row highlight"><span><b>NET PROFIT FOR THE PERIOD (C − J)</b></span><b>${money(net)}</b></div>
          <p class="muted">${tr('noteCost')}</p>
        </div>`;
    } else if (id === 'consolidation') {
      const sales = salesIn(r);
      const bags = sum(sales, x => x.qty), mt = sum(sales, x => x.mt), rev = sum(sales, x => x.total);
      const payments = sum(db.payments.filter(x => (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end)), x => x.amount);
      const damages = sum(db.damages.filter(x => (!r.start || x.date >= r.start) && (!r.end || x.date <= r.end)), x => x.qty);
      const stockBags = sum(PRODUCTS.map(p => stockFor(p, r.end || today())));
      const cashD = sum(db.expenses.filter(x => (x.book||'Depot')==='Depot' && x.direction==='Received'), x => x.amount) -
                    sum(db.expenses.filter(x => (x.book||'Depot')==='Depot' && x.direction!=='Received'), x => x.amount);
      const cashR = sum(db.expenses.filter(x => x.book==='RSO' && x.direction==='Received'), x => x.amount) -
                    sum(db.expenses.filter(x => x.book==='RSO' && x.direction!=='Received'), x => x.amount);
      data = [{ Period: r.start+' to '+r.end, Sales_Bags: bags, Sales_MT: mt, Sales_Value: rev, Payments: payments, Damage_Bags: damages, Stock_Bags: stockBags, Petty_Cash_Depot: cashD, Petty_Cash_RSO: cashR, Dealers: db.dealers.length }];
      html = `<h3 style="text-align:center;margin:0 0 10px">${titleMap[id]}</h3>
        <div class="pl-box">
          <div class="pl-row"><span>Period</span><b>${esc(r.start)} → ${esc(r.end)}</b></div>
          <div class="pl-row"><span>Sales (bags)</span><b>${fmt(bags)}</b></div>
          <div class="pl-row"><span>Sales (MT)</span><b>${fmt(mt)}</b></div>
          <div class="pl-row"><span>Sales value</span><b>${money(rev)}</b></div>
          <div class="pl-row"><span>Payments collected</span><b>${money(payments)}</b></div>
          <div class="pl-row"><span>Damage bags</span><b>${fmt(damages)}</b></div>
          <div class="pl-row"><span>Current stock (bags)</span><b>${fmt(stockBags)}</b></div>
          <div class="pl-row"><span>Petty cash – Depot</span><b>${money(cashD)}</b></div>
          <div class="pl-row"><span>Petty cash – RSO</span><b>${money(cashR)}</b></div>
          <div class="pl-row"><span>Dealers / products</span><b>${db.dealers.length} / ${PRODUCTS.length}</b></div>
        </div>`;
    }

    currentData = data;
    $('previewTitle').textContent = titleMap[id] || tr(id);
    $('reportPreview').innerHTML = html || '<div class="empty">No data</div>';
  }

  $('reportTiles').querySelectorAll('[data-report]').forEach(b => b.onclick = () => showReport(b.dataset.report));
  $('reportTiles').querySelectorAll('[data-csv]').forEach(b => b.onclick = () => {
    showReport(b.dataset.csv);
    if (currentData.length) downloadCSV(currentData, currentName + '.csv');
  });
  $('csvPreview').onclick = () => { if (currentData.length) downloadCSV(currentData, currentName + '.csv'); };
  $('printPreview').onclick = () => window.print();
}

function settings() {
  $('content').innerHTML = `
  <div class="card">
    <div class="card-head"><h2>${tr('settings')}</h2></div>
    <div class="form-grid">
      <div class="field"><label>${tr('depotType')}</label>
        <select id="depotTypeSel">
          <option value="Depot" ${db.depotType === 'Depot' ? 'selected' : ''}>Depot</option>
          <option value="RSO" ${db.depotType === 'RSO' ? 'selected' : ''}>RSO</option>
        </select>
      </div>
      <div class="field"><label>NMB account number</label>
        <input id="nmbAcc" value="${esc(db.banks.NMB || BANKS.NMB)}"></div>
      <div class="field"><label>CRDB account number</label>
        <input id="crdbAcc" value="${esc(db.banks.CRDB || BANKS.CRDB)}"></div>
    </div>
    <div class="btn-row" style="margin-top:12px">
      <button class="btn" id="saveSettings">Save settings</button>
    </div>
  </div>
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h2>${tr('productCost')}</h2></div>
    <form id="costForm"><div class="form-grid">
      ${PRODUCTS.map((p, i) => `<div class="field"><label>${esc(p)}</label>
        <input type="number" min="0" step="1" name="c${i}" value="${Number(db.costs[p] || 0)}"></div>`).join('')}
    </div><div class="btn-row"><button class="btn">${tr('setCost')}</button></div></form>
  </div>
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h2>${tr('backup')}</h2></div>
    <div class="btn-row">
      <button class="btn" id="backupBtn2">${tr('downloadBackup')}</button>
      <label class="btn secondary" style="cursor:pointer">Import JSON
        <input type="file" id="restoreFile" accept=".json" hidden>
      </label>
      <button class="btn warn" id="resetBtn">${tr('reset')}</button>
      <button class="btn secondary" id="logoutBtn">${tr('logout')}</button>
    </div>
    <p class="muted" style="margin-top:10px">${tr('localOnly')}</p>
  </div>`;

  $('saveSettings').onclick = () => {
    db.depotType = $('depotTypeSel').value;
    db.banks.NMB = $('nmbAcc').value.trim() || BANKS.NMB;
    db.banks.CRDB = $('crdbAcc').value.trim() || BANKS.CRDB;
    persist();
    toast(tr('saved'));
    renderNav();
  };

  $('costForm').onsubmit = e => {
    e.preventDefault();
    const f = new FormData(e.target);
    PRODUCTS.forEach((p, i) => db.costs[p] = Number(f.get('c' + i) || 0));
    persist();
    toast(tr('saved'));
  };

  $('backupBtn2').onclick = () => {
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'kibaigwa-backup-' + today() + '.json';
    a.click();
    toast(tr('backupDone'));
  };

  $('restoreFile').onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const d = JSON.parse(ev.target.result);
        if (!d.meta) throw new Error();
        db = d;
        persist();
        toast(tr('restoreDone'));
        go('Dashboard');
      } catch (err) { toast(tr('importInvalid')); }
    };
    reader.readAsText(file);
  };

  $('resetBtn').onclick = () => {
    if (confirm(tr('confirmReset'))) {
      db = emptyDB();
      persist();
      toast('Data reset');
      go('Dashboard');
    }
  };

  $('logoutBtn').onclick = () => {
    sessionStorage.removeItem('kibaigwaLogged');
    loggedIn = false;
    showLogin();
  };
}

function downloadCSV(rows, filename) {
  if (!rows.length) { toast(tr('noData')); return; }
  const keys = Object.keys(rows[0]);
  const lines = [keys.join(',')].concat(rows.map(r => keys.map(k => {
    const v = r[k] ?? '';
    return `"${String(v).replace(/"/g, '""')}"`;
  }).join(',')));
  const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
}

function boot() {
  document.body.innerHTML = `
  <div class="app-shell">
    <aside class="sidebar">
      <div class="brand"><div class="brand-mark">KD</div>
        <div><strong>Kibaigwa Depot</strong><small>Management system</small></div></div>
      <nav id="nav"></nav>
      <div class="side-bottom"><span class="offline-dot"></span><span id="syncText">${tr('localOnly')}</span></div>
    </aside>
    <main class="main">
      <header class="topbar">
        <div><div class="eyebrow" id="todayLabel">${tr('today')}</div><h1 id="pageTitle">Dashboard</h1></div>
        <div class="top-actions">
          <select id="language" aria-label="Language">
            <option value="en">English</option><option value="sw">Kiswahili</option>
          </select>
          <button class="icon-btn" id="backupBtn" title="Backup">↥</button>
        </div>
      </header>
      <section id="content"></section>
      <footer>Kibaigwa Depot v2.5 · Offline-first · Data stays on this device</footer>
    </main>
  </div>
  <div id="toast" role="status"></div>`;

  $('language').value = lang;
  $('language').onchange = () => {
    lang = $('language').value;
    localStorage.setItem('kibaigwaLang', lang);
    go(page);
  };
  $('backupBtn').onclick = () => {
    const blob = new Blob([JSON.stringify(db, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'kibaigwa-backup-' + today() + '.json';
    a.click();
    toast(tr('backupDone'));
  };

  renderNav();
  go('Dashboard');
}

if (!loggedIn) showLogin();
else boot();

})();
