(() => {
  const $ = id => document.getElementById(id);
  const STORE = "healthBuddyDataV1";
  const load = () => { try { return JSON.parse(localStorage.getItem(STORE)) || {readings:[],diary:[],goal:{}}; } catch { return {readings:[],diary:[],goal:{}}; } };
  let data = load();
  let language = "ur";
  const today = new Date().toISOString().slice(0,10);
  $("today").textContent = new Date().toLocaleDateString("en-GB",{day:"2-digit",month:"short",year:"numeric"});
  $("readingDate").value = today;
  const save = () => localStorage.setItem(STORE, JSON.stringify(data));
  const val = id => $(id).value.trim();
  const has = v => v !== "" && Number.isFinite(Number(v));
  function render(){
    const sorted = [...data.readings].sort((a,b)=>b.date.localeCompare(a.date));
    const latest = key => sorted.find(x=>x[key] !== null && x[key] !== undefined);
    $("weightStat").textContent = latest("weight")?.weight ?? "—";
    $("glucoseStat").textContent = latest("glucose")?.glucose ?? "—";
    const bp = latest("sys");
    $("bpStat").textContent = bp ? `${bp.sys}/${bp.dia ?? "—"}` : "—";
    $("goalCurrent").value = data.goal.current ?? "";
    $("goalTarget").value = data.goal.target ?? "";
    renderGoal();
    $("historyList").innerHTML = sorted.length ? sorted.map(x => `<div class="history-item"><strong>${escapeHtml(x.date)}</strong><div>${x.weight!=null?`وزن: ${x.weight} kg · `:""}${x.glucose!=null?`شوگر: ${x.glucose} · `:""}${x.sys!=null?`BP: ${x.sys}/${x.dia} · `:""}${x.a1c!=null?`HbA1c: ${x.a1c}%`:""}</div></div>`).join("") : '<p class="muted">ابھی کوئی ریکارڈ نہیں۔</p>';
  }
  function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  function renderGoal(){
    const c=Number(data.goal.current), t=Number(data.goal.target);
    if(!c || !t || c<=0 || t<=0 || c===t){$("progressBar").style.width="0%";$("goalText").textContent="اپنا موجودہ اور ہدف وزن درج کریں۔";return;}
    const first = data.readings.map(x=>Number(x.weight)).filter(Boolean).sort((a,b)=>b-a)[0] || c;
    const pct=Math.max(0,Math.min(100,((first-c)/(first-t))*100));
    $("progressBar").style.width=pct+"%";
    $("goalText").textContent=`ہدف: ${t} kg · موجودہ: ${c} kg · پیش رفت: ${Math.round(pct)}%`;
  }
  $("readingForm").addEventListener("submit",e=>{
    e.preventDefault();
    const entry={date:val("readingDate"),weight:has(val("weight"))?Number(val("weight")):null,glucose:has(val("glucose"))?Number(val("glucose")):null,sys:has(val("sys"))?Number(val("sys")):null,dia:has(val("dia"))?Number(val("dia")):null,a1c:has(val("a1c"))?Number(val("a1c")):null};
    if(!Object.values(entry).some((v,i)=>i>0&&v!==null)){ $("formMessage").textContent="کم از کم ایک ریڈنگ درج کریں۔"; return; }
    data.readings=data.readings.filter(x=>x.date!==entry.date);data.readings.push(entry);save();render();e.target.reset();$("readingDate").value=today;$("formMessage").textContent="ریکارڈ محفوظ ہو گیا۔";
  });
  $("saveGoal").addEventListener("click",()=>{
    const c=Number(val("goalCurrent")),t=Number(val("goalTarget"));
    if(!c||!t||c<=0||t<=0){$("goalText").textContent="درست وزن درج کریں۔";return;}
    data.goal={current:c,target:t};save();renderGoal();
  });
  $("diaryForm").addEventListener("submit",e=>{
    e.preventDefault();const entry={date:today,water:val("water"),meals:val("meals"),notes:val("notes")};
    data.diary=data.diary.filter(x=>x.date!==today);data.diary.push(entry);save();$("diaryMessage").textContent="آج کی ڈائری محفوظ ہو گئی۔";
  });
  document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
    document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===btn));
    document.querySelectorAll(".panel").forEach(x=>x.classList.toggle("hidden",x.id!==btn.dataset.tab));
  }));
  $("exportBtn").addEventListener("click",()=>{
    const rows=[["date","weight_kg","glucose_mg_dl","systolic","diastolic","hba1c_percent"],...data.readings.map(x=>[x.date,x.weight??"",x.glucose??"",x.sys??"",x.dia??"",x.a1c??""])];
    const csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
    const blob=new Blob(["\ufeff"+csv],{type:"text/csv;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="health-buddy-records.csv";a.click();URL.revokeObjectURL(url);
  });
  $("clearBtn").addEventListener("click",()=>{if(confirm("کیا آپ واقعی اس فون سے تمام Health Buddy ڈیٹا حذف کرنا چاہتے ہیں؟")){data={readings:[],diary:[],goal:{}};save();render();}});
  $("langBtn").addEventListener("click",()=>{
    language=language==="ur"?"en":"ur";document.documentElement.lang=language;document.documentElement.dir=language==="ur"?"rtl":"ltr";
    document.querySelectorAll("[data-ur][data-en]").forEach(el=>el.textContent=el.dataset[language]);
    $("langBtn").textContent=language==="ur"?"EN":"اردو";
  });
  render();
})();