const clubs = [
  ["WJ FC","WJ"],["Paris Saint-Germain","PSG"],["Real Madrid","RMA"],["FC Barcelona","BAR"],
  ["Manchester City","MCI"],["Manchester United","MUN"],["Liverpool","LIV"],["Arsenal","ARS"],
  ["Chelsea","CHE"],["Bayern de Munique","BAY"],["Juventus","JUV"],["Inter","INT"],
  ["AC Milan","MIL"],["Borussia Dortmund","BVB"],["Atlético de Madrid","ATM"],
  ["Benfica","BEN"],["Porto","POR"],["Sporting CP","SCP"],["Ajax","AJA"],["Napoli","NAP"],
  ["Al Ahly","AHL"],["Mamelodi Sundowns","SUN"],["Kaizer Chiefs","KAI"],["Orlando Pirates","ORL"]
];

const wjRoster = [
  ["Valério",81,"Guarda-redes","Titular"],["Paulo Langa",80,"Defesa","Titular"],
  ["Abel",80,"Defesa","Titular"],["Ercílio",81,"Defesa","Titular"],
  ["Stélio David",83,"Defesa","Titular"],["Ronaldo",83,"Médio","Titular"],
  ["João Chilaves",87,"Médio","Capitão"],["Justino Chavane",84,"Médio","Titular"],
  ["Nelson Sitoe",84,"Avançado","Titular"],["Micas",86,"Avançado","Titular"],
  ["Titos Sitoe",81,"Avançado","Titular"],["Fernando",81,"Guarda-redes","Suplente"],
  ["Idelson",82,"Médio","Suplente"],["Egas",80,"Médio","Suplente"],
  ["Anderson",79,"Avançado","Suplente"],["Joel",83,"Médio","Suplente"],
  ["Edu Chavane",82,"Defesa","Suplente"]
];

const state = {
  coins: Number(localStorage.getItem("w5_coins") ?? 500),
  diamonds: 20,
  matches: Number(localStorage.getItem("w5_matches") ?? 0),
  wins: Number(localStorage.getItem("w5_wins") ?? 0),
  home: "WJ FC",
  away: "Paris Saint-Germain",
  rewarded: false
};

const $ = id => document.getElementById(id);
function save() {
  localStorage.setItem("w5_coins", state.coins);
  localStorage.setItem("w5_matches", state.matches);
  localStorage.setItem("w5_wins", state.wins);
  renderWallet();
}
function renderWallet() {
  $("coins").textContent = state.coins;
  $("diamonds").textContent = state.diamonds;
  $("careerCoins").textContent = state.coins;
  $("matchesPlayed").textContent = state.matches;
  $("wins").textContent = state.wins;
}
function showScreen(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.toggle("active", s.id === id));
  document.querySelectorAll(".bottom-nav button").forEach(b => b.classList.toggle("selected", b.dataset.go === id));
  window.scrollTo(0,0);
}
document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => {
  const id = b.dataset.go;
  if (id === "team") renderRoster();
  if (id === "clubs") renderClubs();
  if (id === "career") $("careerClub").textContent = state.home;
  showScreen(id);
}));

function populateClubSelects() {
  const options = clubs.map(c => `<option value="${c[0]}">${c[0]}</option>`).join("");
  $("homeClub").innerHTML = options;
  $("awayClub").innerHTML = options;
  $("homeClub").value = state.home;
  $("awayClub").value = state.away;
}
function renderClubs() {
  $("clubGrid").innerHTML = clubs.map(c => `
    <button class="club-card ${c[0] === state.home ? "chosen" : ""}" data-club="${c[0]}">
      <b>${c[1]} · ${c[0]}</b><small>${c[0] === "WJ FC" ? "Clube inicial do jogador" : "Clube disponível para seleção"}</small>
    </button>`).join("");
  $("clubGrid").querySelectorAll("[data-club]").forEach(btn => btn.addEventListener("click", () => {
    state.home = btn.dataset.club;
    $("homeClub").value = state.home;
    $("careerClub").textContent = state.home;
    renderClubs();
    toast("Clube selecionado: " + state.home);
  }));
}
function renderRoster() {
  $("teamClubName").textContent = state.home;
  const list = state.home === "WJ FC" ? wjRoster : [
    ["Guarda-redes titular",82,"Guarda-redes","Titular"],["Defesa 1",81,"Defesa","Titular"],
    ["Defesa 2",82,"Defesa","Titular"],["Defesa 3",80,"Defesa","Titular"],
    ["Defesa 4",83,"Defesa","Titular"],["Médio 1",84,"Médio","Titular"],
    ["Médio 2",85,"Médio","Titular"],["Médio 3",82,"Médio","Titular"],
    ["Avançado 1",86,"Avançado","Titular"],["Avançado 2",87,"Avançado","Titular"],
    ["Avançado 3",84,"Avançado","Titular"],["Guarda-redes suplente",78,"Guarda-redes","Suplente"],
    ["Defesa suplente",79,"Defesa","Suplente"],["Médio suplente",80,"Médio","Suplente"],
    ["Avançado suplente",81,"Avançado","Suplente"]
  ];
  $("roster").innerHTML = list.map(p => `<div class="player"><span class="rating">${p[1]}</span><b>${p[0]}</b><small>${p[2]} · ${p[3]}</small></div>`).join("");
}
function toast(msg) {
  const el = $("toast"); el.textContent = msg; el.classList.add("show");
  clearTimeout(window.toastTimer); window.toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}
$("homeClub").addEventListener("change", e => { state.home = e.target.value; $("careerClub").textContent = state.home; });
$("awayClub").addEventListener("change", e => state.away = e.target.value);
$("startMatch").addEventListener("click", () => {
  state.home = $("homeClub").value; state.away = $("awayClub").value;
  if (state.home === state.away) return toast("Escolhe dois clubes diferentes.");
  $("previewHome").textContent = state.home; $("previewAway").textContent = state.away;
  $("previewHomeBadge").textContent = clubs.find(c=>c[0]===state.home)?.[1] || "W5";
  $("previewAwayBadge").textContent = clubs.find(c=>c[0]===state.away)?.[1] || "W5";
  showScreen("matchPreview");
});
$("launchDemo").addEventListener("click", () => {
  state.rewarded = false;
  $("demoHome").textContent = state.home; $("demoAway").textContent = state.away;
  $("demoScore").textContent = "0 — 0";
  showScreen("demo");
  toast("Demonstração iniciada. O motor 3D será integrado na próxima etapa.");
});
$("finishDemo").addEventListener("click", () => {
  if (!state.rewarded) {
    state.coins += 100; state.matches += 1; state.rewarded = true; save();
  }
  toast("Recompensa de 100 moedas recebida!");
  showScreen("home");
});
$("resetProgress").addEventListener("click", () => {
  if (!confirm("Tens a certeza de que queres apagar o progresso guardado neste dispositivo?")) return;
  state.coins = 500; state.matches = 0; state.wins = 0; save();
  toast("Progresso reiniciado.");
});

populateClubSelects();
renderClubs();
renderRoster();
renderWallet();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
