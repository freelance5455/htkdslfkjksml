(function(){
"use strict";
const $=s=>document.querySelector(s);
const uid=()=>{try{return crypto.randomUUID()}catch(e){return Date.now().toString(36)+Math.random().toString(36).slice(2)}};
const read=(k,d)=>{try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}};
const write=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};

let state={
 tab:"chat",
 messages:[{role:"assistant",text:"I am Offline AI Assistant. I can work with your local memory, imported text documents, study tools, calculations, and offline speech. This build uses local browser/device features and does not pretend that a cloud AI is running offline."}],
 memory:read("offline-ai-memory",[]),
 docs:read("offline-ai-docs",[]),
 study:"Mathematics", studyTopic:"", calc:"", result:"", floating:false,
 selectedVoice:localStorage.getItem("offline-ai-voice")||""
};

function save(){write("offline-ai-memory",state.memory);write("offline-ai-docs",state.docs);if(state.selectedVoice)localStorage.setItem("offline-ai-voice",state.selectedVoice)}
function escape(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function speak(text){if(!("speechSynthesis"in window))return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);const v=(window.speechSynthesis.getVoices()||[]).find(x=>x.voiceURI===state.selectedVoice);if(v)u.voice=v;window.speechSynthesis.speak(u)}
function answer(q){
 const lower=q.toLowerCase().trim(); if(!lower)return "";
 if(lower.startsWith("remember ")){const t=q.slice(9).trim();if(t){state.memory.push({id:uid(),text:t});save();return "Saved locally. You can view or clear it in Memory."}}
 if(lower.startsWith("forget ")){const term=q.slice(7).trim().toLowerCase();const before=state.memory.length;state.memory=state.memory.filter(x=>!x.text.toLowerCase().includes(term));save();return before===state.memory.length?"I could not find a matching local memory.":"Matching local memory was cleared."}
 if(/^[0-9+\\-*/().%\\s^]+$/.test(q)){try{const safe=q.replaceAll("^","**");const val=Function('"use strict";return ('+safe+')')();if(Number.isFinite(val))return "Calculator result: "+val}catch(e){}}
 if(lower.includes("what do you remember")||lower==="memory")return state.memory.length?"Local memory:\\n"+state.memory.map(x=>"• "+x.text).join("\\n"):"Your local memory is empty.";
 const words=lower.split(/\\s+/).filter(w=>w.length>3);
 const matches=state.docs.filter(d=>{const t=d.text.toLowerCase();return t.includes(lower)||words.some(w=>t.includes(w))});
 if(matches.length)return "I found relevant local document content in: "+matches.map(d=>d.name).join(", ")+". Open Documents to read the imported text.";
 if(lower==="hello"||lower.startsWith("hello ")||lower==="hi"||lower.startsWith("hi "))return "Hello! I am running in offline-first mode on this device.";
 return "I can handle local memory commands, calculations, imported text-document search, study prompts, and offline read-aloud. A true on-device LLM requires a bundled model and native runtime; this HTML build does not claim to provide one.";
}
function send(){
 const input=$("#chatInput"); const q=input.value.trim();if(!q)return;
 const a=answer(q);state.messages.push({role:"user",text:q},{role:"assistant",text:a});input.value="";render();
}
function importFiles(list){if(!list)return;Array.from(list).forEach(f=>{if(!/\\.(txt|md|csv|html?|json)$/i.test(f.name)&&f.type!=="text/plain")return;const r=new FileReader();r.onload=()=>{state.docs.push({id:uid(),name:f.name,text:String(r.result||"")});save();render()};r.readAsText(f)});}
function calc(){try{const safe=state.calc.replaceAll("^","**");const val=Function('"use strict";return ('+safe+')')();state.result=Number.isFinite(val)?String(val):"Invalid"}catch(e){state.result="Invalid expression"}render()}
function nav(id){state.tab=id;render()}
function render(){
 const app=$("#app");
 const navs=[["chat","💬","Chat"],["study","📖","Study"],["documents","📄","Documents"],["memory","🧠","Memory"],["tools","🛠","Tools"],["settings","⚙","Settings"]];
 let content="";
 if(state.tab==="chat")content=`<section><div class="hero"><div><h1>Private, local tools</h1><p>Memory, documents, study help, calculations and offline speech stay on this device.</p></div><button class="primary" data-act="float">Open floating AI</button></div><div class="chatbox">${state.messages.map((m,i)=>`<div class="bubble ${m.role}"><b>${m.role==="user"?"You":"Offline AI"}</b><div>${escape(m.text)}</div>${m.role==="assistant"?`<button class="iconbtn" data-speak="${i}" title="Read aloud">🔊</button>`:""}</div>`).join("")}</div><div class="composer"><input id="chatInput" placeholder="Ask, calculate, or say “remember …”"><button class="primary" data-act="send">Send</button><button class="iconbtn" data-act="mic">🎙</button></div></section>`;
 if(state.tab==="study")content=`<section><h2>Study Mode</h2><p>Lightweight offline study prompts.</p><div class="grid">${["Mathematics","Science","English","Biology","Physics","Chemistry","History","Geography"].map(s=>`<button class="card ${state.study===s?"selected":""}" data-study="${s}">${s}</button>`).join("")}</div><input id="studyTopic" class="wide" value="${escape(state.studyTopic)}" placeholder="Topic in ${state.study}"><button class="primary" data-act="study">Start study explanation</button></section>`;
 if(state.tab==="documents")content=`<section><div class="sectionhead"><div><h2>Documents</h2><p>Imported plain-text files stay local. This simple builder version intentionally does not fake PDF/EPUB parsing.</p></div><label class="primary">📂 Import text<input id="fileInput" hidden type="file" multiple accept=".txt,.md,.csv,.html,.htm,.json,text/plain"></label></div>${state.docs.length?state.docs.map(d=>`<article class="doc"><div><b>${escape(d.name)}</b><p>${escape(d.text.slice(0,900))}${d.text.length>900?"…":""}</p></div><button class="iconbtn" data-del-doc="${d.id}">🗑</button></article>`).join(""):`<div class="empty">No local text documents yet.</div>`}</section>`;
 if(state.tab==="memory")content=`<section><div class="sectionhead"><div><h2>Local Memory</h2><p>Stored only in this device's local storage.</p></div><button class="danger" data-act="clear-memory">🗑 Clear all</button></div>${state.memory.length?state.memory.map(m=>`<div class="row"><span>${escape(m.text)}</span><button class="iconbtn" data-del-memory="${m.id}">🗑</button></div>`).join(""):`<div class="empty">No memories saved.</div>`}<button class="secondary" data-act="export">⬇ Export memory</button></section>`;
 if(state.tab==="tools")content=`<section><h2>Tools</h2><div class="toolcard"><div>🧮</div><div><h3>Calculator</h3><p>Local arithmetic, percentages and powers.</p></div></div><div class="calc"><input id="calcInput" value="${escape(state.calc)}" placeholder="Example: (12.5 * 8) / 2"><button class="primary" data-act="calc">Calculate</button><strong>${escape(state.result)}</strong></div><div class="toolcard"><div>📱</div><div><h3>Phone actions</h3><p>HTML apps cannot safely control arbitrary Android apps or create a system-wide overlay. Those features require native Android components.</p></div></div></section>`;
 if(state.tab==="settings")content=`<section><h2>Settings & Privacy</h2><div class="privacy"><div>🛡</div><div><b>Offline-first</b><p>This build uses local browser storage. Memories and imported text are not uploaded by this app.</p></div></div><div class="voice-settings"><div><h3>Voice</h3><p>Choose a voice already available on your phone.</p></div><select id="voiceSelect"><option value="">System default voice</option>${(window.speechSynthesis?window.speechSynthesis.getVoices():[]).map(v=>`<option value="${escape(v.voiceURI)}" ${v.voiceURI===state.selectedVoice?"selected":""}>${escape(v.name)} — ${escape(v.lang)}</option>`).join("")}</select><button class="secondary" data-act="testvoice">🔊 Test voice</button><small>${(window.speechSynthesis&&window.speechSynthesis.getVoices().length)?"":"No voices are currently exposed by this WebView. Check Android text-to-speech settings."}</small></div><button class="secondary" data-act="clear-all">🗑 Clear all local app data</button></section>`;
 app.innerHTML=`<div class="app-shell"><header class="topbar"><div><div class="brand">Offline AI</div><div class="sub">Personal assistant • local-first</div></div><div class="status"><span class="dot"></span> Offline — running on device</div></header><div class="layout"><aside class="sidebar">${navs.map(n=>`<button class="nav ${state.tab===n[0]?"active":""}" data-nav="${n[0]}">${n[1]} ${n[2]}</button>`).join("")}</aside><main class="main">${content}</main></div><button class="floating-trigger" data-act="float">AI</button>${state.floating?`<div class="floating"><div class="floathead"><b>Offline AI</b><button class="iconbtn" data-act="closefloat">✕</button></div><div class="floatbody"><p>Local floating assistant. Try a memory command or calculation.</p><input id="floatInput" placeholder="Ask something…"><div class="floatactions"><button class="primary" data-act="floatsend">Send</button><button class="iconbtn" data-act="closefloat">—</button></div></div></div>`:""}</div>`;
 bind();
}
function bind(){
 document.querySelectorAll("[data-nav]").forEach(b=>b.onclick=()=>nav(b.dataset.nav));
 document.querySelectorAll("[data-act]").forEach(b=>b.onclick=()=>{const a=b.dataset.act;
  if(a==="send")send();
  if(a==="float"){state.floating=true;render()}
  if(a==="closefloat"){state.floating=false;render()}
  if(a==="mic"){if("webkitSpeechRecognition"in window){const R=window.webkitSpeechRecognition;const r=new R();r.onresult=e=>{$("#chatInput").value=e.results[0][0].transcript};r.start()}else alert("Speech recognition is not available in this browser/WebView.")}
  if(a==="study"){const t=$("#studyTopic").value.trim();state.studyTopic=t;if(t){state.messages.push({role:"user",text:"Study: "+state.study+" — "+t},{role:"assistant",text:"Study prompt created locally. Explain the topic in your own words, list the key terms, then test yourself with three questions. For calculations, use Tools → Calculator."});state.tab="chat";render()}}
  if(a==="clear-memory"){state.memory=[];save();render()}
  if(a==="export"){const blob=new Blob([JSON.stringify(state.memory,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="offline-ai-memory.json";a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
  if(a==="calc"){state.calc=$("#calcInput").value;calc()}
  if(a==="testvoice"){speak("This is your selected phone voice.")}
  if(a==="clear-all"){try{localStorage.clear()}catch(e){}state.memory=[];state.docs=[];state.messages=[{role:"assistant",text:"Local app data cleared."}];render()}
  if(a==="floatsend"){const i=$("#floatInput");const q=i.value.trim();if(q){state.messages.push({role:"user",text:q},{role:"assistant",text:answer(q)});state.floating=false;render()}}
 });
 document.querySelectorAll("[data-speak]").forEach(b=>b.onclick=()=>speak(state.messages[Number(b.dataset.speak)].text));
 document.querySelectorAll("[data-study]").forEach(b=>b.onclick=()=>{state.study=b.dataset.study;render()});
 document.querySelectorAll("[data-del-doc]").forEach(b=>b.onclick=()=>{state.docs=state.docs.filter(x=>x.id!==b.dataset.delDoc);save();render()});
 document.querySelectorAll("[data-del-memory]").forEach(b=>b.onclick=()=>{state.memory=state.memory.filter(x=>x.id!==b.dataset.delMemory);save();render()});
 const fi=$("#fileInput");if(fi)fi.onchange=e=>importFiles(e.target.files);
 const ci=$("#chatInput");if(ci){ci.onkeydown=e=>{if(e.key==="Enter")send()};ci.focus()}
 const si=$("#studyTopic");if(si)si.oninput=()=>state.studyTopic=si.value;
 const vi=$("#voiceSelect");if(vi)vi.onchange=()=>{state.selectedVoice=vi.value;save()}
}
if("speechSynthesis"in window)window.speechSynthesis.onvoiceschanged=()=>{if(state.tab==="settings")render()};
render();
})();