
        // Database categorized by Positions & Ratings
        const playersByPos = {
            GK: [
                { name: "ايميليانو مارنيتنيز", pos: "GK", rating: 98, type: "حدث CHAMPIONS" },
                { name: "مانويل نوير", pos: "GK", rating: 99, type: "حالي" },
                { name: "مارك اندريه تير شتيغين", pos: "GK", rating: 98, type: "حالي" },
                { name: "روبرت سانشيز", pos: "GK", rating: 84, type: "حالي" },
                { name: "اليكس ميريت", pos: "GK", rating: 80, type: "حالي" },
                { name: "ليف ياشين", pos: "GK", rating: 99, type: "أيكونز ICON" },
                { name: "جانلويجى بوفون", pos: "GK", rating: 99, type: "أيكونز ICON" },
                { name: "ايكر كاسياس", pos: "GK", rating: 99, type: "أيكونز ICON" },
                { name: "بيتر تشيك", pos: "GK", rating: 98, type: "أيكونز ICON" },
                { name: "بيتر شمايكل", pos: "GK", rating: 98, type: "أيكونز ICON" },
                { name: "إدوين فاندار سار", pos: "GK", rating: 98, type: "أيكونز ICON" },
                { name: "ديفيد دى خيا", pos: "GK", rating: 98, type: "حالي" },
                { name: "تيبوا كورتوا", pos: "GK", rating: 98, type: "حالي" },
                { name: "اليسون بيكر", pos: "GK", rating: 97, type: "حالي" },
                { name: "ديدا", pos: "GK", rating: 97, type: "أيكونز ICON" },
                { name: "إديرسون", pos: "GK", rating: 95, type: "حالي" },
                { name: "جانلويجى دوناروما", pos: "GK", rating: 94, type: "حالي" },
                { name: "ديفيد رايا", pos: "GK", rating: 94, type: "حالي" },
                { name: "عصام الحضرى", pos: "GK", rating: 93, type: "أيكونز ICON" },
                { name: "محمد الشناوى", pos: "GK", rating: 89, type: "حالي" },
                { name: "مصطفى شوبير", pos: "GK", rating: 87, type: "حالي" },
                { name: "أحمد الشناوى", pos: "GK", rating: 82, type: "حالي" },
                { name: "اندريه اونانا", pos: "GK", rating: 79, type: "حالي" }
            ],
            LB: [
                { name: "أشلى كول", pos: "LB", rating: 99, type: "أيكونز ICON" },
                { name: "ثيو هيرناندز", pos: "LB", rating: 92, type: "حالي" },
                { name: "ألفونسو ديفيز", pos: "LB", rating: 92, type: "حالي" },
                { name: "ديماركو", pos: "LB", rating: 92, type: "حالي" },
                { name: "بالدى", pos: "LB", rating: 86, type: "حالي" },
                { name: "ميندى", pos: "LB", rating: 82, type: "حالي" },
                { name: "روبيرتو كارلوس", pos: "LB", rating: 99, type: "أيكونز ICON" },
                { name: "مارسيلو", pos: "LB", rating: 99, type: "أيكونز ICON" },
                { name: "فيليب لام", pos: "LB", rating: 99, type: "أيكونز ICON" },
                { name: "زامبيروتا", pos: "LB", rating: 98, type: "أيكونز ICON" },
                { name: "نونو مينديش", pos: "LB", rating: 95, type: "حالي" },
                { name: "مارك كوكوريا", pos: "LB", rating: 95, type: "حالي" },
                { name: "أحمد فتوح", pos: "LB", rating: 83, type: "حالي" },
                { name: "هاتو", pos: "LB", rating: 78, type: "حالي" }
            ],
            CB: [
                { name: "سيرجيو راموس", pos: "CB", rating: 99, type: "أيكونز ICON" },
                { name: "اليساندرو نيستا", pos: "CB", rating: 99, type: "أيكونز ICON" },
                { name: "رونالد كومان", pos: "CB", rating: 98, type: "أيكونز ICON" },
                { name: "روبن دياس", pos: "CB", rating: 90, type: "حالي" },
                { name: "رونالد اراوخو", pos: "CB", rating: 84, type: "حالي" },
                { name: "باولو مالدينى", pos: "CB", rating: 99, type: "أيكونز ICON" },
                { name: "فيرجيل فان دايك", pos: "CB", rating: 99, type: "حالي" },
                { name: "فرانز بيكنباور", pos: "CB", rating: 99, type: "أيكونز ICON" },
                { name: "فرانكو باريزى", pos: "CB", rating: 99, type: "أيكونز ICON" },
                { name: "فابيو كانفارو", pos: "CB", rating: 99, type: "أيكونز ICON" },
                { name: "كيلينى", pos: "CB", rating: 99, type: "أيكونز ICON" },
                { name: "بوبى مور", pos: "CB", rating: 99, type: "أيكونز ICON" },
                { name: "ريو فيرديناند", pos: "CB", rating: 98, type: "أيكونز ICON" },
                { name: "جون تيرى", pos: "CB", rating: 98, type: "أيكونز ICON" },
                { name: "جابريال مجاليش", pos: "CB", rating: 95, type: "حالي" },
                { name: "ويليان ساليبا", pos: "CB", rating: 94, type: "حالي" },
                { name: "دين هاوسين", pos: "CB", rating: 93, type: "حالي" },
                { name: "ابراهيما كوناتى", pos: "CB", rating: 92, type: "حالي" },
                { name: "ماركينيوس", pos: "CB", rating: 93, type: "حالي" },
                { name: "وائل جمعة", pos: "CB", rating: 93, type: "أيكونز ICON" },
                { name: "إبراهيم حسن", pos: "CB", rating: 93, type: "أيكونز ICON" },
                { name: "ياسر ابراهيم", pos: "CB", rating: 84, type: "حالي" },
                { name: "رامى رابيعا", pos: "CB", rating: 83, type: "حالي" },
                { name: "إريك داير", pos: "CB", rating: 80, type: "حالي" },
                { name: "هارى ماجواير", pos: "CB", rating: 78, type: "حالي" }
            ],
            RB: [
                { name: "كارلوس البيرتو", pos: "RB", rating: 99, type: "أيكونز ICON" },
                { name: "ليليان تورام", pos: "RB", rating: 99, type: "أيكونز ICON" },
                { name: "غارى نيفيل", pos: "RB", rating: 97, type: "أيكونز ICON" },
                { name: "أشرف حكيمى", pos: "RB", rating: 95, type: "حالي" },
                { name: "كافو", pos: "RB", rating: 99, type: "أيكونز ICON" },
                { name: "زانيتى", pos: "RB", rating: 99, type: "أيكونز ICON" },
                { name: "دانيل كارفاخال", pos: "RB", rating: 99, type: "حالي" },
                { name: "دانى الفيس", pos: "RB", rating: 99, type: "أيكونز ICON" },
                { name: "ارنولد", pos: "RB", rating: 95, type: "حالي" },
                { name: "نصير مازراوى", pos: "RB", rating: 85, type: "حالي" },
                { name: "محمد هانى", pos: "RB", rating: 83, type: "حالي" },
                { name: "ديجو دالوت", pos: "RB", rating: 80, type: "حالي" }
            ],
            CM: [
                { name: "فرانك لامبارد", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "استيفين جيرارد", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "اندريا بيرلو", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "بول سكولز", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "كاى جوندوجان", pos: "CM", rating: 91, type: "حالي" },
                { name: "كارلوس سولير", pos: "CM", rating: 80, type: "حالي" },
                { name: "زين الدين زيدان", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "رود خوليت", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "لوثار ماتيوس", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "باتريك فييرا", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "تونى كروس", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "اندريس انيستا", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "لوكا مودريتش", pos: "CM", rating: 99, type: "حالي" },
                { name: "اتشافى هيرناندز", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "اتشابى الونسو", pos: "CM", rating: 99, type: "أيكونز ICON" },
                { name: "مايكل بالاك", pos: "CM", rating: 98, type: "أيكونز ICON" },
                { name: "كلارنس سيدروف", pos: "CM", rating: 98, type: "أيكونز ICON" },
                { name: "فرانك رايكارد", pos: "CM", rating: 98, type: "أيكونز ICON" },
                { name: "جود بيلنجهام", pos: "CM", rating: 96, type: "حالي" },
                { name: "بيدرى", pos: "CM", rating: 96, type: "حالي" },
                { name: "بيرناندو سيلفا", pos: "CM", rating: 94, type: "حالي" },
                { name: "الخطيب", pos: "CM", rating: 94, type: "أيكونز ICON" },
                { name: "جافى", pos: "CM", rating: 92, type: "حالي" },
                { name: "إمام عاشور", pos: "CM", rating: 87, type: "حالي" }
            ],
            CAM: [
                { name: "يوهان كرويف", pos: "CAM", rating: 99, type: "أيكونز ICON" },
                { name: "كاكا", pos: "CAM", rating: 99, type: "أيكونز ICON" },
                { name: "ديجو مارادونا", pos: "CAM", rating: 99, type: "أيكونز ICON" },
                { name: "زيكو", pos: "CAM", rating: 99, type: "أيكونز ICON" },
                { name: "روبيرت باجيو", pos: "CAM", rating: 99, type: "أيكونز ICON" },
                { name: "ميشيل بلاتينى", pos: "CAM", rating: 99, type: "أيكونز ICON" },
                { name: "جورجى هاجى", pos: "CAM", rating: 97, type: "أيكونز ICON" },
                { name: "كيفين دى بروين", pos: "CAM", rating: 97, type: "حالي" },
                { name: "فلوريان فيرتز", pos: "CAM", rating: 95, type: "حالي" },
                { name: "جمال موسيالا", pos: "CAM", rating: 94, type: "حالي" },
                { name: "ايسكو", pos: "CAM", rating: 91, type: "حالي" },
                { name: "فيليبى كوتينيو", pos: "CAM", rating: 90, type: "حالي" },
                { name: "ديلى الى", pos: "CAM", rating: 81, type: "حالي" },
                { name: "لينغارد", pos: "CAM", rating: 79, type: "حالي" }
            ],
            RW: [
                { name: "ديسير دوى", pos: "RW", rating: 100, type: "حدث CHAMPIONS" },
                { name: "ليونيل ميسي", pos: "RW", rating: 99, type: "حالي" },
                { name: "لويس فيجو", pos: "RW", rating: 99, type: "أيكونز ICON" },
                { name: "جورج بيست", pos: "RW", rating: 99, type: "أيكونز ICON" },
                { name: "محمد صلاح", pos: "RW", rating: 99, type: "حالي" },
                { name: "جارينشيا", pos: "RW", rating: 99, type: "أيكونز ICON" },
                { name: "جارزينيو", pos: "RW", rating: 99, type: "أيكونز ICON" },
                { name: "بوكايو ساكا", pos: "RW", rating: 85, type: "حالي" },
                { name: "لامين يامال", pos: "RW", rating: 87, type: "حالي" },
                { name: "عثمان ديمبيلى", pos: "RW", rating: 87, type: "حالي" },
                { name: "مايكل اوليسي", pos: "RW", rating: 87, type: "حالي" },
                { name: "أنتونى", pos: "RW", rating: 83, type: "حالي" },
                { name: "سيرج غنابرى", pos: "RW", rating: 82, type: "حالي" },
                { name: "سانشو", pos: "RW", rating: 80, type: "حالي" }
            ],
            LW: [
                { name: "كفارتسخيليا", pos: "LW", rating: 100, type: "حدث CHAMPIONS" },
                { name: "كريستيانو رونالدو", pos: "LW", rating: 99, type: "حالي" },
                { name: "نيمار", pos: "LW", rating: 99, type: "حالي" },
                { name: "رونالدينيو", pos: "LW", rating: 99, type: "أيكونز ICON" },
                { name: "ريفالدو", pos: "LW", rating: 99, type: "أيكونز ICON" },
                { name: "هازارد", pos: "LW", rating: 99, type: "أيكونز ICON" },
                { name: "فينيسيوس جونيور", pos: "LW", rating: 96, type: "حالي" },
                { name: "ماركوس راشفورد", pos: "LW", rating: 82, type: "حالي" },
                { name: "انسوا فاتى", pos: "LW", rating: 80, type: "حالي" },
                { name: "رحيم سترلينح", pos: "LW", rating: 80, type: "حالي" }
            ],
            ST: [
                { name: "رونالدو الظاهرة", pos: "ST", rating: 99, type: "أيكونز ICON" },
                { name: "فان باستين", pos: "ST", rating: 99, type: "أيكونز ICON" },
                { name: "غيرد مولر", pos: "ST", rating: 99, type: "أيكونز ICON" },
                { name: "اوزيبيو", pos: "ST", rating: 99, type: "أيكونز ICON" },
                { name: "تييرى هنرى", pos: "ST", rating: 99, type: "أيكونز ICON" },
                { name: "كريم بنزيما", pos: "ST", rating: 99, type: "أيكونز ICON" },
                { name: "زلاتان ابراهيموفيتش", pos: "ST", rating: 99, type: "أيكونز ICON" },
                { name: "كيليان امبابى", pos: "ST", rating: 98, type: "حالي" },
                { name: "هارى كين", pos: "ST", rating: 97, type: "حالي" },
                { name: "فيكتور جيوكيريس", pos: "ST", rating: 95, type: "حالي" },
                { name: "لوكاكو", pos: "ST", rating: 84, type: "حالي" },
                { name: "الفارو موراتا", pos: "ST", rating: 82, type: "حالي" }
            ]
        };

        const posNames11 = [
            { key: "GK", name: "حارس مرمى (GK)" },
            { key: "LB", name: "ظهير أيسر (LB)" },
            { key: "CB", name: "قلب دفاع أول (CB1)" },
            { key: "CB", name: "قلب دفاع ثاني (CB2)" },
            { key: "RB", name: "ظهير أيمن (RB)" },
            { key: "CM", name: "وسط ملعـب أول (CM1)" },
            { key: "CM", name: "وسط ملعـب ثاني (CM2)" },
            { key: "CAM", name: "وسط مهاجم (CAM)" },
            { key: "RW", name: "جناح أيمن (RW)" },
            { key: "LW", name: "جناح أيسر (LW)" },
            { key: "ST", name: "مهاجم صريح (ST)" }
        ];

        const posNames5 = [
            { key: "GK", name: "حارس مرمى (GK)" },
            { key: "CB", name: "مدافع (DF)" },
            { key: "CM", name: "لاعب وسط (MF)" },
            { key: "CAM", name: "وسط مهاجم (CAM)" },
            { key: "ST", name: "مهاجم (FW)" }
        ];

        let auctionPosList = posNames11;
        let p1Name = "BA";
        let p2Name = "BE";
        let budgetP1 = 2000;
        let budgetP2 = 2000;
        let initialBudget = 2000;
        let currentBidVal = 10;
        let activeTurn = 1;
        let currentCard = null;
        let auctionRound = 0;
        let selectedMode = '1v1';

        let p1Squad = [];
        let p2Squad = [];
        
        let usedPlayerNames = new Set();

        let p1WildcardUsed = false;
        let p2WildcardUsed = false;

        // Deal Or No Deal System Data
        let dealStage = 0;
        let dealP1Data = { attempts: 0, chosenPlayer: null, isDone: false, tempPlayer: null };
        let dealP2Data = { attempts: 0, chosenPlayer: null, isDone: false, tempPlayer: null };

        let matchSummaryText = "";

        function showSection(id) {
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            document.getElementById(id).classList.add('active');
        }

        function openModal(id) { document.getElementById(id).style.display = 'flex'; }
        function closeModal(id) { document.getElementById(id).style.display = 'none'; }
function selectMode(mode) { selectedMode=mode;document.getElementById('player-inputs').style.display='block';document.getElementById('room-box').style.display=mode==='room'?'block':'none';if(mode==='ai')document.getElementById('p2-name').value='الروبوت الذكي (AI)';else if(document.getElementById('p2-name').value==='الروبوت الذكي (AI)')document.getElementById('p2-name').value='BE'; }
        function goToGameMenu() {
            p1Name = document.getElementById('p1-name').value || "BA";
            p2Name = document.getElementById('p2-name').value || "BE";
            showSection('menu-section');
        }
