
const $ = id => document.getElementById(id);

let characters = JSON.parse(localStorage.getItem("characters") || "[]");
let current = -1;

function save() {
  localStorage.setItem("characters", JSON.stringify(characters));
}

function showCharacters() {
  $("characterList").innerHTML = "";

  characters.forEach((c, i) => {
    const btn = document.createElement("button");
    btn.className = "character";

    const avatar = document.createElement("div");
    avatar.className = "avatar";
    if (c.photo) avatar.style.backgroundImage = `url("${c.photo}")`;

    const name = document.createElement("strong");
    name.textContent = c.name;

    btn.append(avatar, name);
    btn.onclick = () => openChat(i);
    $("characterList").appendChild(btn);
  });
}

function openChat(index) {
  current = index;
  const c = characters[index];

  $("home").classList.add("hidden");
  $("settings").classList.add("hidden");
  $("chat").classList.remove("hidden");

  $("chatName").textContent = c.name;
  $("chatAvatar").style.backgroundImage =
    c.photo ? `url("${c.photo}")` : "";

  $("messages").innerHTML = "";
  (c.messages || []).forEach(showMessage);
}

function showMessage(message) {
  const bubble = document.createElement("div");
  bubble.className = "bubble " + (message.from === "me" ? "me" : "bot");
  bubble.textContent = message.text;
  $("messages").appendChild(bubble);
  $("messages").scrollTop = $("messages").scrollHeight;
}

$("addBtn").onclick = () => {
  const name = prompt("Karakterin adı ne olsun?");
  if (!name || !name.trim()) return;

  characters.push({
    name: name.trim(),
    photo: "",
    messages: []
  });

  save();
  showCharacters();
};

$("backBtn").onclick = () => {
  $("chat").classList.add("hidden");
  $("home").classList.remove("hidden");
  current = -1;
};

$("messageForm").onsubmit = event => {
  event.preventDefault();

  const text = $("messageInput").value.trim();
  if (!text || current < 0) return;

  const c = characters[current];
  c.messages.push({ text, from: "me" });

  save();
  showMessage({ text, from: "me" });
  $("messageInput").value = "";
};

$("chatAvatar").onclick = () => $("photoInput").click();

$("photoInput").onchange = event => {
  const file = event.target.files[0];
  if (!file || current < 0) return;

  const reader = new FileReader();

  reader.onload = () => {
    characters[current].photo = reader.result;
    save();
    $("chatAvatar").style.backgroundImage = `url("${reader.result}")`;
    showCharacters();
  };

  reader.readAsDataURL(file);
};

$("savePersonality").onclick = () => {
  if (current < 0) {
    alert("Önce bir karakter oluştur.");
    return;
  }

  characters[current].personality = $("personality").value;
  save();
  alert("Kişilik kaydedildi!");
};

showCharacters();
btn.classNameavatar.classNamec.photoavatar.style.backgroundImagename.textContentc.namebtn.onclickbubble.classNamebubble.textContentreader.onload