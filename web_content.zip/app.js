/**
 * CALCULADORA DE PRECIOS 3D - JOXE 3D ESTUDIO
 * Lógica matemática en tiempo real, interactividad táctil, persistencia y exportación
 */

(function () {
  'use strict';

  // =========================================================================
  // REFERENCIAS DOM
  // =========================================================================
  const el = {
    // Datos de impresión
    jobName: document.getElementById('job-name'),
    currencySelect: document.getElementById('currency-select'),
    filamentUsed: document.getElementById('filament-used'),
    printHours: document.getElementById('print-hours'),
    printMinutes: document.getElementById('print-minutes'),

    // Filamento
    filamentPills: document.getElementById('filament-pills'),
    spoolPrice: document.getElementById('spool-price'),
    spoolWeight: document.getElementById('spool-weight'),
    wastePercentage: document.getElementById('waste-percentage'),
    wasteValDisplay: document.getElementById('waste-val-display'),

    // Electricidad
    powerWatts: document.getElementById('power-watts'),
    kwhPrice: document.getElementById('kwh-price'),
    printerPresets: document.getElementById('printer-presets'),

    // Mano de obra
    prepTime: document.getElementById('prep-time'),
    postTime: document.getElementById('post-time'),
    hourlyRate: document.getElementById('hourly-rate'),

    // Máquina y mantenimiento
    printerCost: document.getElementById('printer-cost'),
    lifespanHours: document.getElementById('lifespan-hours'),
    maintenanceRate: document.getElementById('maintenance-rate'),
    amortizationRateDisplay: document.getElementById('amortization-rate-display'),

    // Extras
    extraItemsList: document.getElementById('extra-items-list'),
    btnAddExtra: document.getElementById('btn-add-extra'),

    // IVA
    taxToggle: document.getElementById('tax-toggle'),
    taxInputsRow: document.getElementById('tax-inputs-row'),
    taxRate: document.getElementById('tax-rate'),
    taxAmountDisplay: document.getElementById('tax-amount-display'),

    // Desglose (Resultados)
    costFilament: document.getElementById('cost-filament'),
    costElectricity: document.getElementById('cost-electricity'),
    costLabor: document.getElementById('cost-labor'),
    costAmortization: document.getElementById('cost-amortization'),
    costMaintenance: document.getElementById('cost-maintenance'),
    costExtras: document.getElementById('cost-extras'),
    costTotal: document.getElementById('cost-total'),

    // Margen
    marginButtons: document.getElementById('margin-buttons'),
    marginCaption: document.getElementById('margin-caption'),
    customMargin: document.getElementById('custom-margin'),
    btnClearCustomMargin: document.getElementById('btn-clear-custom-margin'),

    // Precio de venta recomendado
    recommendedPrice: document.getElementById('recommended-price'),
    taxNoteLabel: document.getElementById('tax-note-label'),
    baseCostDisplay: document.getElementById('base-cost-display'),
    profitBadge: document.getElementById('profit-badge'),
    profitText: document.getElementById('profit-text'),
    profitAmount: document.getElementById('profit-amount'),

    // Acciones
    btnCopyPrice: document.getElementById('btn-copy-price'),
    btnExportPdf: document.getElementById('btn-export-pdf'),
    btnReset: document.getElementById('btn-reset'),

    // Barra móvil
    mobilePriceDisplay: document.getElementById('mobile-price-display'),
    mobileProfitDisplay: document.getElementById('mobile-profit-display'),
    btnMobileScroll: document.getElementById('btn-mobile-scroll'),
    summaryColumn: document.getElementById('summary-column'),

    // Toast
    toast: document.getElementById('toast'),
    toastMessage: document.getElementById('toast-message'),

    // Elementos de moneda dinámicos
    currencySymbols: document.querySelectorAll('.currency-symbol')
  };

  // =========================================================================
  // ESTADO DE LA APLICACIÓN
  // =========================================================================
  const state = {
    currency: '€',
    selectedFilament: 'PLA',
    currentMultiplier: 4,
    isCustomMultiplier: false,
    extraItems: [
      // Concepto por defecto sugerido
      { id: 1, name: 'Caja y protección embalaje', cost: 0.80 }
    ],
    calculations: {
      filamentCost: 0,
      electricityCost: 0,
      laborCost: 0,
      amortizationCost: 0,
      maintenanceCost: 0,
      extrasCost: 0,
      baseCost: 0,
      salePrice: 0,
      taxAmount: 0,
      finalPrice: 0,
      profit: 0
    }
  };

  const marginCaptions = {
    '2': 'Grandes series (+50 uds) — mínimo margen, máxima rotación',
    '2.5': 'Series medianas (16–50 uds) — margen equilibrado',
    '3': 'Series cortas (6–15 uds) — margen estándar de taller',
    '3.5': 'Pocas unidades (2–5 uds) — buen margen comercial',
    '4': 'Pieza única — margen máximo para cubrir preparación'
  };

  // =========================================================================
  // INICIALIZACIÓN
  // =========================================================================
  function init() {
    loadUserSettings();
    renderExtraItems();
    attachEventListeners();
    calculateAll();
    registerServiceWorker();
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator && (window.location.protocol === 'http:' || window.location.protocol === 'https:')) {
      navigator.serviceWorker.register('sw.js').catch(err => {
        console.log('SW registration skipped or error:', err);
      });
    }
  }

  // =========================================================================
  // EVENT LISTENERS
  // =========================================================================
  function attachEventListeners() {
    // Recalcular ante cualquier cambio en inputs numéricos o texto
    const watchInputs = [
      el.jobName, el.filamentUsed, el.printHours, el.printMinutes,
      el.spoolPrice, el.spoolWeight, el.powerWatts, el.kwhPrice,
      el.prepTime, el.postTime, el.hourlyRate,
      el.printerCost, el.lifespanHours, el.maintenanceRate,
      el.taxRate
    ];

    watchInputs.forEach(input => {
      if (input) {
        input.addEventListener('input', () => {
          saveUserSettings();
          calculateAll();
        });
      }
    });

    // Moneda
    el.currencySelect.addEventListener('change', (e) => {
      state.currency = e.target.value;
      updateCurrencySymbols();
      calculateAll();
      saveUserSettings();
    });

    // Slider de desperdicio
    el.wastePercentage.addEventListener('input', (e) => {
      el.wasteValDisplay.textContent = `${e.target.value}%`;
      calculateAll();
    });

    // Pills de filamento
    el.filamentPills.querySelectorAll('.pill-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        el.filamentPills.querySelectorAll('.pill-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.selectedFilament = btn.dataset.type;

        // Si se pulsa, sugerir el precio típico del rollo
        if (btn.dataset.price) {
          el.spoolPrice.value = btn.dataset.price;
        }
        calculateAll();
      });
    });

    // Presets de impresoras (Watts)
    el.printerPresets.querySelectorAll('.chip-btn').forEach(chip => {
      chip.addEventListener('click', () => {
        el.printerPresets.querySelectorAll('.chip-btn').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        el.powerWatts.value = chip.dataset.watts;
        calculateAll();
      });
    });

    // Acordeones (Máquina, Extras, IVA)
    document.querySelectorAll('.accordion-header').forEach(header => {
      header.addEventListener('click', () => {
        const card = header.closest('.accordion-card');
        const isOpen = card.classList.toggle('open');
        header.setAttribute('aria-expanded', isOpen);
      });
    });

    // Toggle de IVA
    el.taxToggle.addEventListener('change', (e) => {
      el.taxInputsRow.style.display = e.target.checked ? 'grid' : 'none';
      calculateAll();
    });

    // Botones de margen
    el.marginButtons.querySelectorAll('.margin-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        el.marginButtons.querySelectorAll('.margin-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        state.currentMultiplier = parseFloat(btn.dataset.multiplier);
        state.isCustomMultiplier = false;
        el.customMargin.value = '';
        updateMarginCaption();
        calculateAll();
      });
    });

    // Input margen personalizado
    el.customMargin.addEventListener('input', (e) => {
      const val = parseFloat(e.target.value);
      if (!isNaN(val) && val > 0) {
        state.currentMultiplier = val;
        state.isCustomMultiplier = true;
        el.marginButtons.querySelectorAll('.margin-btn').forEach(b => b.classList.remove('active'));
        el.marginCaption.textContent = `Margen personalizado ×${val}`;
      } else {
        // Restaurar botón por defecto si está vacío
        resetToDefaultMargin();
      }
      calculateAll();
    });

    // Botón borrar margen personalizado
    el.btnClearCustomMargin.addEventListener('click', () => {
      el.customMargin.value = '';
      resetToDefaultMargin();
      calculateAll();
    });

    // Botón añadir extra dinámico
    el.btnAddExtra.addEventListener('click', () => {
      addExtraItem('', 0);
    });

    // Chips de extras habituales
    document.querySelectorAll('.quick-chip-btn').forEach(chip => {
      chip.addEventListener('click', () => {
        addExtraItem(chip.dataset.name, parseFloat(chip.dataset.cost) || 0);
      });
    });

    // Botón Copiar Precio / Presupuesto
    el.btnCopyPrice.addEventListener('click', copySummaryToClipboard);

    // Botón Exportar PDF / Imprimir
    el.btnExportPdf.addEventListener('click', openPrintDialog);

    // Botón Limpiar
    el.btnReset.addEventListener('click', resetAllFields);



    // Scroll móvil al desglose
    if (el.btnMobileScroll) {
      el.btnMobileScroll.addEventListener('click', () => {
        el.summaryColumn.scrollIntoView({ behavior: 'smooth' });
      });
    }
  }

  // =========================================================================
  // GESTIÓN DE EXTRAS DINÁMICOS
  // =========================================================================
  function renderExtraItems() {
    el.extraItemsList.innerHTML = '';
    state.extraItems.forEach((item, index) => {
      const row = document.createElement('div');
      row.className = 'extra-row';
      row.innerHTML = `
        <div class="extra-name-input">
          <input type="text" placeholder="Concepto (ej: Envío, tornillos...)" value="${escapeHtml(item.name)}" data-index="${index}" class="extra-name-field">
        </div>
        <div class="extra-cost-input-wrapper">
          <input type="number" min="0" step="0.1" placeholder="0.00" value="${item.cost > 0 ? item.cost : ''}" data-index="${index}" class="extra-cost-field">
          <span class="input-addon">${state.currency}</span>
        </div>
        <button type="button" class="btn-remove-extra" title="Eliminar concepto" data-index="${index}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      `;

      // Eventos de la fila
      row.querySelector('.extra-name-field').addEventListener('input', (e) => {
        state.extraItems[index].name = e.target.value;
      });

      row.querySelector('.extra-cost-field').addEventListener('input', (e) => {
        state.extraItems[index].cost = parseFloat(e.target.value) || 0;
        calculateAll();
      });

      row.querySelector('.btn-remove-extra').addEventListener('click', () => {
        state.extraItems.splice(index, 1);
        renderExtraItems();
        calculateAll();
      });

      el.extraItemsList.appendChild(row);
    });
  }

  function addExtraItem(name = '', cost = 0) {
    state.extraItems.push({
      id: Date.now(),
      name: name,
      cost: cost
    });
    renderExtraItems();
    calculateAll();
  }

  // =========================================================================
  // MOTOR DE CÁLCULO
  // =========================================================================
  function calculateAll() {
    // 1. Datos básicos
    const filamentUsed = parseFloat(el.filamentUsed.value) || 0;
    const hours = parseFloat(el.printHours.value) || 0;
    const minutes = parseFloat(el.printMinutes.value) || 0;
    const totalPrintHours = hours + (minutes / 60);

    // 2. Filamento
    const spoolPrice = parseFloat(el.spoolPrice.value) || 0;
    const spoolWeight = parseFloat(el.spoolWeight.value) || 1000;
    const wastePercent = parseFloat(el.wastePercentage.value) || 0;

    const totalFilamentUsedWithWaste = filamentUsed * (1 + (wastePercent / 100));
    const pricePerGram = spoolWeight > 0 ? (spoolPrice / spoolWeight) : 0;
    const filamentCost = pricePerGram * totalFilamentUsedWithWaste;

    // 3. Electricidad
    const powerWatts = parseFloat(el.powerWatts.value) || 0;
    const kwhPrice = parseFloat(el.kwhPrice.value) || 0;
    const kwhConsumed = (powerWatts / 1000) * totalPrintHours;
    const electricityCost = kwhConsumed * kwhPrice;

    // 4. Mano de obra
    const prepMin = parseFloat(el.prepTime.value) || 0;
    const postMin = parseFloat(el.postTime.value) || 0;
    const hourlyRate = parseFloat(el.hourlyRate.value) || 0;
    const totalLaborHours = (prepMin + postMin) / 60;
    const laborCost = totalLaborHours * hourlyRate;

    // 5. Máquina y mantenimiento
    const printerCost = parseFloat(el.printerCost.value) || 0;
    const lifespanHours = parseFloat(el.lifespanHours.value) || 0;
    const maintenanceRate = parseFloat(el.maintenanceRate.value) || 0;

    let amortizationPerHour = 0;
    if (printerCost > 0 && lifespanHours > 0) {
      amortizationPerHour = printerCost / lifespanHours;
    }
    const amortizationCost = amortizationPerHour * totalPrintHours;
    const maintenanceCost = maintenanceRate * totalPrintHours;

    // Actualizar badge de tasa de amortización
    el.amortizationRateDisplay.innerHTML = `${formatMoney(amortizationPerHour)} <span class="currency-symbol">${state.currency}</span>/h`;

    // 6. Costes adicionales (Extras)
    const extrasCost = state.extraItems.reduce((sum, item) => sum + (parseFloat(item.cost) || 0), 0);

    // 7. Coste total base
    const baseCost = filamentCost + electricityCost + laborCost + amortizationCost + maintenanceCost + extrasCost;

    // 8. Margen y precio de venta recomendado
    const multiplier = state.currentMultiplier;
    const salePriceBeforeTax = baseCost * multiplier;

    // 9. IVA
    const hasTax = el.taxToggle.checked;
    const taxPercentage = parseFloat(el.taxRate.value) || 0;
    let taxAmount = 0;
    let finalRecommendedPrice = salePriceBeforeTax;

    if (hasTax && taxPercentage > 0) {
      taxAmount = salePriceBeforeTax * (taxPercentage / 100);
      finalRecommendedPrice = salePriceBeforeTax + taxAmount;
    }

    // 10. Ganancia real
    const realProfit = salePriceBeforeTax - baseCost;

    // Guardar en el estado interno
    state.calculations = {
      filamentCost,
      electricityCost,
      laborCost,
      amortizationCost,
      maintenanceCost,
      extrasCost,
      baseCost,
      salePrice: salePriceBeforeTax,
      taxAmount,
      finalPrice: finalRecommendedPrice,
      profit: realProfit
    };

    // Actualizar la interfaz gráfica
    updateUI();
  }

  // =========================================================================
  // ACTUALIZACIÓN DE LA INTERFAZ
  // =========================================================================
  function updateUI() {
    const calc = state.calculations;
    const sym = state.currency;

    // Desglose de costes
    el.costFilament.textContent = `${formatMoney(calc.filamentCost)} ${sym}`;
    el.costElectricity.textContent = `${formatMoney(calc.electricityCost)} ${sym}`;
    el.costLabor.textContent = `${formatMoney(calc.laborCost)} ${sym}`;
    el.costAmortization.textContent = `${formatMoney(calc.amortizationCost)} ${sym}`;
    el.costMaintenance.textContent = `${formatMoney(calc.maintenanceCost)} ${sym}`;
    el.costExtras.textContent = `${formatMoney(calc.extrasCost)} ${sym}`;
    el.costTotal.textContent = `${formatMoney(calc.baseCost)} ${sym}`;

    // Precio recomendado
    el.recommendedPrice.textContent = formatMoney(calc.finalPrice);
    el.baseCostDisplay.textContent = `${formatMoney(calc.baseCost)} ${sym}`;

    // IVA display
    if (el.taxToggle.checked) {
      const taxRateVal = parseFloat(el.taxRate.value) || 21;
      el.taxNoteLabel.textContent = `IVA (${taxRateVal}%) incluido (+${formatMoney(calc.taxAmount)} ${sym})`;
      el.taxAmountDisplay.innerHTML = `+${formatMoney(calc.taxAmount)} <span class="currency-symbol">${sym}</span>`;
    } else {
      el.taxNoteLabel.textContent = 'IVA no incluido';
      el.taxAmountDisplay.innerHTML = `0.00 <span class="currency-symbol">${sym}</span>`;
    }

    // Ganancia
    const multLabel = state.isCustomMultiplier ? `×${state.currentMultiplier}` : `×${state.currentMultiplier}`;
    el.profitText.textContent = `Tu ganancia real (${multLabel}):`;
    el.profitAmount.textContent = `+${formatMoney(calc.profit)} ${sym}`;

    // Barra flotante móvil
    if (el.mobilePriceDisplay) {
      el.mobilePriceDisplay.textContent = `${formatMoney(calc.finalPrice)} ${sym}`;
      el.mobileProfitDisplay.textContent = `+${formatMoney(calc.profit)} ${sym} ganancia`;
    }
  }

  function updateCurrencySymbols() {
    document.querySelectorAll('.currency-symbol').forEach(node => {
      node.textContent = state.currency;
    });
    // Actualizar sufijos en filas de extras
    document.querySelectorAll('.extra-cost-input-wrapper .input-addon').forEach(addon => {
      addon.textContent = state.currency;
    });
  }

  function updateMarginCaption() {
    const key = String(state.currentMultiplier);
    if (marginCaptions[key]) {
      el.marginCaption.textContent = marginCaptions[key];
    } else {
      el.marginCaption.textContent = `Margen aplicado: ×${state.currentMultiplier}`;
    }
  }

  function resetToDefaultMargin() {
    state.currentMultiplier = 4;
    state.isCustomMultiplier = false;
    el.marginButtons.querySelectorAll('.margin-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.multiplier === '4');
    });
    updateMarginCaption();
  }

  function formatMoney(amount) {
    if (isNaN(amount) || amount === null || amount === undefined) return '0.00';
    return Number(amount).toLocaleString('es-ES', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // =========================================================================
  // COPIAR AL PORTAPAPELES
  // =========================================================================
  function copySummaryToClipboard() {
    const calc = state.calculations;
    const sym = state.currency;
    const name = el.jobName.value.trim() || 'Pieza 3D';
    const hours = el.printHours.value || 0;
    const minutes = el.printMinutes.value || 0;
    const grams = el.filamentUsed.value || 0;

    let text = `📦 *PRESUPUESTO DE IMPRESIÓN 3D* - JOXE 3D\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━\n`;
    text += `🔹 *Proyecto:* ${name}\n`;
    text += `🔹 *Material:* ${state.selectedFilament} (~${grams}g)\n`;
    text += `🔹 *Tiempo de impresión:* ${hours}h ${minutes}min\n\n`;
    text += `💰 *DESGLOSE DE COSTES:*\n`;
    text += `• Filamento: ${formatMoney(calc.filamentCost)} ${sym}\n`;
    text += `• Electricidad: ${formatMoney(calc.electricityCost)} ${sym}\n`;
    text += `• Mano de obra: ${formatMoney(calc.laborCost)} ${sym}\n`;
    if (calc.amortizationCost > 0) text += `• Amortización máq.: ${formatMoney(calc.amortizationCost)} ${sym}\n`;
    if (calc.maintenanceCost > 0) text += `• Mantenimiento: ${formatMoney(calc.maintenanceCost)} ${sym}\n`;
    if (calc.extrasCost > 0) text += `• Extras / Envíos: ${formatMoney(calc.extrasCost)} ${sym}\n`;
    text += `─────────────\n`;
    text += `• *Coste Base Total:* ${formatMoney(calc.baseCost)} ${sym}\n`;
    text += `• *Margen aplicado:* ×${state.currentMultiplier}\n\n`;
    text += `🏷️ *PRECIO DE VENTA: ${formatMoney(calc.finalPrice)} ${sym}*`;
    if (el.taxToggle.checked) {
      text += ` (IVA incl.)`;
    } else {
      text += ` (IVA no incl.)`;
    }

    navigator.clipboard.writeText(text).then(() => {
      showToast('✓ Presupuesto copiado al portapapeles');
    }).catch(() => {
      // Fallback manual si el navegador restringe clipboard
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      showToast('✓ Presupuesto copiado al portapapeles');
    });
  }

  // =========================================================================
  // EXPORTAR PDF / IMPRIMIR
  // =========================================================================
  function openPrintDialog() {
    const calc = state.calculations;
    const sym = state.currency;
    const name = el.jobName.value.trim() || 'Proyecto de Impresión 3D';
    const hours = el.printHours.value || 0;
    const minutes = el.printMinutes.value || 0;
    const grams = el.filamentUsed.value || 0;
    const waste = el.wastePercentage.value || 0;

    // Rellenar la hoja de impresión (#print-sheet)
    document.getElementById('print-date').textContent = new Date().toLocaleDateString('es-ES', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
    document.getElementById('print-job-name').textContent = name;
    document.getElementById('print-material').textContent = state.selectedFilament;
    document.getElementById('print-weight').textContent = `${grams} g (+ ${waste}% desperdicio)`;
    document.getElementById('print-time').textContent = `${hours} h ${minutes} min`;

    // Desglose
    document.getElementById('print-c-filament').textContent = `${formatMoney(calc.filamentCost)} ${sym}`;
    document.getElementById('print-c-power').textContent = `${formatMoney(calc.electricityCost)} ${sym}`;
    document.getElementById('print-c-labor').textContent = `${formatMoney(calc.laborCost)} ${sym}`;
    document.getElementById('print-c-amort').textContent = `${formatMoney(calc.amortizationCost)} ${sym}`;
    document.getElementById('print-c-maint').textContent = `${formatMoney(calc.maintenanceCost)} ${sym}`;
    document.getElementById('print-c-extras').textContent = `${formatMoney(calc.extrasCost)} ${sym}`;
    document.getElementById('print-c-total').textContent = `${formatMoney(calc.baseCost)} ${sym}`;

    // Resumen comercial
    document.getElementById('print-margin-tag').textContent = `×${state.currentMultiplier}`;
    document.getElementById('print-final-price').textContent = `${formatMoney(calc.finalPrice)} ${sym}`;

    const printTaxRow = document.getElementById('print-tax-row');
    if (el.taxToggle.checked) {
      printTaxRow.style.display = 'flex';
      const taxRateVal = parseFloat(el.taxRate.value) || 21;
      document.getElementById('print-tax-detail').textContent = `Base: ${formatMoney(calc.salePrice)} ${sym} + IVA (${taxRateVal}%): ${formatMoney(calc.taxAmount)} ${sym}`;
    } else {
      printTaxRow.style.display = 'none';
    }

    // Abrir diálogo nativo de impresión / guardar como PDF
    if (window.AndroidPrint && typeof window.AndroidPrint.printDocument === 'function') {
      window.AndroidPrint.printDocument(name);
    } else {
      window.print();
    }
  }

  // =========================================================================
  // NOTIFICACIÓN TOAST
  // =========================================================================
  let toastTimeout;
  function showToast(message) {
    if (toastTimeout) clearTimeout(toastTimeout);
    el.toastMessage.textContent = message;
    el.toast.classList.add('show');
    toastTimeout = setTimeout(() => {
      el.toast.classList.remove('show');
    }, 2500);
  }

  // =========================================================================
  // GUARDADO Y CARGA LOCAL (PREFERENCIAS Y PRESUPUESTOS)
  // =========================================================================
  function saveUserSettings() {
    const settings = {
      currency: state.currency,
      kwhPrice: el.kwhPrice.value,
      hourlyRate: el.hourlyRate.value,
      printerCost: el.printerCost.value,
      lifespanHours: el.lifespanHours.value,
      maintenanceRate: el.maintenanceRate.value,
      taxRate: el.taxRate.value
    };
    try {
      localStorage.setItem('joxe3d_user_settings', JSON.stringify(settings));
    } catch (e) {
      console.warn('LocalStorage no disponible');
    }
  }

  function loadUserSettings() {
    try {
      const saved = localStorage.getItem('joxe3d_user_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.currency) {
          state.currency = parsed.currency;
          el.currencySelect.value = parsed.currency;
          updateCurrencySymbols();
        }
        if (parsed.kwhPrice) el.kwhPrice.value = parsed.kwhPrice;
        if (parsed.hourlyRate) el.hourlyRate.value = parsed.hourlyRate;
        if (parsed.printerCost) el.printerCost.value = parsed.printerCost;
        if (parsed.lifespanHours) el.lifespanHours.value = parsed.lifespanHours;
        if (parsed.maintenanceRate) el.maintenanceRate.value = parsed.maintenanceRate;
        if (parsed.taxRate) el.taxRate.value = parsed.taxRate;
      }
    } catch (e) {
      console.warn('Error al cargar configuración');
    }
  }



  function resetAllFields() {
    if (confirm('¿Deseas restablecer todos los campos del presupuesto actual?')) {
      el.jobName.value = '';
      el.filamentUsed.value = '';
      el.printHours.value = 0;
      el.printMinutes.value = 0;
      el.prepTime.value = '';
      el.postTime.value = '';
      el.wastePercentage.value = 5;
      el.wasteValDisplay.textContent = '5%';
      state.extraItems = [{ id: 1, name: 'Caja y protección embalaje', cost: 0.80 }];
      renderExtraItems();
      resetToDefaultMargin();
      calculateAll();
      showToast('Formulario restablecido');
    }
  }

  // Inicializar al cargar el DOM
  document.addEventListener('DOMContentLoaded', init);

})();
