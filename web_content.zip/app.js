(() => {
'use strict';

/* Defaults are embedded because fetch('config.json') fails on file:// and in some WebView builders.
   If config.json loads, it overrides these values. */
const DEFAULT_CONFIG = {
  gridSize: 8,
  storageKey: 'paperBlocks.best',
  dragLiftCells: 2.2,
  trayScale: 0.5,
  vibrate: true,
  sound: true,
  scoring: { perCell: 1, perLine: 10, comboStep: 5, perfectClear: 100 },
  colors: {
    blue: '#4a9ad9', red: '#e5534b', yellow: '#f2c94c', green: '#5cb85c', purple: '#9b59b6',
    orange: '#f39a3d', teal: '#2fa89a', pink: '#ef7fa9', lime: '#a6cf3c', magenta: '#c93a9c',
    brown: '#9a6a43', cyan: '#3fc1d6'
  },
  ink: '#2c3a8f',
  pencil: '#3a3d4d'
};
const FONT = '"Segoe Print","Bradley Hand","Chalkboard SE","Marker Felt","Comic Sans MS","Patrick Hand",cursive';

/* ---------- shapes ---------- */
const FAMILIES = [
  { color: 'blue',    base: [['#.', '#.', '##'], ['#.', '##'], ['#..', '#..', '###'], ['#.', '#.', '#.', '##']], rotate: true, mirror: false },
  { color: 'orange',  base: [['.#', '.#', '##'], ['.#', '.#', '.#', '##']], rotate: true, mirror: false },
  { color: 'red',     base: [['###', '.#.'], ['###', '.#.', '.#.']], rotate: true, mirror: false },
  { color: 'yellow',  base: [['#'], ['##'], ['###'], ['####'], ['#####']], rotate: true, mirror: false },
  { color: 'green',   base: [['##', '##'], ['###', '###', '###'], ['##', '##', '##']], rotate: true, mirror: false },
  { color: 'purple',  base: [['##.', '.##']], rotate: true, mirror: true },
  { color: 'teal',    base: [['##.', '.#.', '.##']], rotate: true, mirror: true },
  { color: 'pink',    base: [['.#.', '###', '.#.']], rotate: false, mirror: false },
  { color: 'lime',    base: [['.##', '##.', '.#.']], rotate: true, mirror: true },
  { color: 'magenta', base: [['#..', '##.', '.##']], rotate: true, mirror: false },
  { color: 'brown',   base: [['##', '##', '#.']], rotate: true, mirror: true },
  { color: 'cyan',    base: [['#.#', '###']], rotate: true, mirror: false }
];

function parse(rows) {
  const cells = [];
  rows.forEach((s, r) => [...s].forEach((ch, c) => { if (ch === '#') cells.push([r, c]); }));
  return cells;
}
function norm(cells) {
  const mr = Math.min(...cells.map(p => p[0])), mc = Math.min(...cells.map(p => p[1]));
  return cells.map(([r, c]) => [r - mr, c - mc]).sort((a, b) => a[0] - b[0] || a[1] - b[1]);
}
function rot(cells) {
  const h = Math.max(...cells.map(p => p[0])) + 1;
  return norm(cells.map(([r, c]) => [c, h - 1 - r]));
}
function mir(cells) {
  const w = Math.max(...cells.map(p => p[1])) + 1;
  return norm(cells.map(([r, c]) => [r, w - 1 - c]));
}
const SHAPES = [];
(function buildShapes() {
  const seen = new Set();
  for (const fam of FAMILIES) {
    for (const rows of fam.base) {
      const starts = [norm(parse(rows))];
      if (fam.mirror) starts.push(mir(starts[0]));
      for (let s of starts) {
        for (let k = 0; k < (fam.rotate ? 4 : 1); k++) {
          const key = fam.color + JSON.stringify(s);
          if (!seen.has(key)) {
            seen.add(key);
            const weight = ({ 1: 0.5, 2: 1, 3: 1, 4: 1, 5: 0.6 })[s.length] || 0.6;
            SHAPES.push({
              id: SHAPES.length, color: fam.color, cells: s, weight,
              w: Math.max(...s.map(p => p[1])) + 1, h: Math.max(...s.map(p => p[0])) + 1
            });
          }
          s = rot(s);
        }
      }
    }
  }
})();
const TOTAL_WEIGHT = SHAPES.reduce((a, s) => a + s.weight, 0);
function randomShape() {
  let t = Math.random() * TOTAL_WEIGHT;
  for (const s of SHAPES) { t -= s.weight; if (t <= 0) return s; }
  return SHAPES[SHAPES.length - 1];
}

/* ---------- helpers ---------- */
const $ = id => document.getElementById(id);
function seeded(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hashStr(s) { let h = 7; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; }
function shade(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  const cl = v => Math.max(0, Math.min(255, v));
  return `rgb(${cl((n >> 16) + amt)},${cl(((n >> 8) & 255) + amt)},${cl((n & 255) + amt)})`;
}
function wobblyLine(g, x1, y1, x2, y2, rnd, amp) {
  g.beginPath();
  g.moveTo(x1 + (rnd() - .5) * amp, y1 + (rnd() - .5) * amp);
  const steps = 5;
  for (let k = 1; k <= steps; k++) {
    const t = k / steps;
    g.lineTo(x1 + (x2 - x1) * t + (rnd() - .5) * amp, y1 + (y2 - y1) * t + (rnd() - .5) * amp);
  }
  g.stroke();
}
function mergeConfig(base, over) {
  const out = { ...base, ...over };
  out.scoring = { ...base.scoring, ...(over && over.scoring) };
  out.colors = { ...base.colors, ...(over && over.colors) };
  return out;
}
const clamp01 = v => Math.max(0, Math.min(1, v));
const lerp = (a, b, t) => a + (b - a) * t;
const easeOut = t => 1 - Math.pow(1 - t, 3);
const easeOutBack = t => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };

/* ---------- sound (synthesized with WebAudio, no audio files) ---------- */
const Sound = (() => {
  let ac = null, master = null, noiseBuf = null, muted = false;
  function init() {
    if (ac) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      ac = new AC();
      master = ac.createGain(); master.gain.value = 0.7; master.connect(ac.destination);
      noiseBuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
      const d = noiseBuf.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    } catch (e) { ac = null; }
  }
  function unlock() { init(); if (ac && ac.state === 'suspended') ac.resume().catch(() => {}); }
  function suspend() { if (ac && ac.state === 'running') ac.suspend().catch(() => {}); }
  function tone(freq, t, dur, type, vol, endFreq) {
    const o = ac.createOscillator(), g = ac.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.05);
  }
  function noise(t, dur, vol, type, f0, f1, q) {
    const s = ac.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const f = ac.createBiquadFilter(); f.type = type; f.Q.value = q || 1;
    f.frequency.setValueAtTime(f0, t);
    if (f1) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + Math.min(0.02, dur / 3));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(master); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
  }
  const play = fn => { if (!ac || muted) return; try { fn(ac.currentTime); } catch (e) { /* ignore */ } };
  const SCALE = [523.25, 587.33, 659.25, 783.99, 880, 1046.5, 1174.66, 1318.5];
  return {
    unlock, suspend,
    setMuted(m) { muted = !!m; },
    isMuted() { return muted; },
    pick() { play(t => { noise(t, 0.06, 0.12, 'bandpass', 2200, 1500, 2); tone(660, t, 0.05, 'sine', 0.06, 880); }); },
    drop() { play(t => { noise(t, 0.1, 0.3, 'lowpass', 700, 300, 1); tone(150, t, 0.14, 'sine', 0.45, 60); }); },
    invalid() { play(t => { tone(240, t, 0.18, 'triangle', 0.18, 140); noise(t, 0.1, 0.08, 'lowpass', 600, 300, 1); }); },
    clear(n, streak) {
      play(t => {
        noise(t, 0.38, 0.28, 'bandpass', 900, 3800, 1.2);
        noise(t + 0.05, 0.3, 0.14, 'highpass', 2500, 6000, 0.7);
        tone(130, t, 0.2, 'sine', 0.35, 60);
        const shift = Math.pow(2, Math.min(streak, 8) / 12);
        const count = Math.min(3 + n, SCALE.length);
        for (let k = 0; k < count; k++) tone(SCALE[k] * shift, t + 0.08 + k * 0.055, 0.28, 'triangle', 0.16);
      });
    },
    deal(delay) { play(t => { for (let k = 0; k < 3; k++) noise(t + (delay || 0) + k * 0.11, 0.07, 0.1, 'bandpass', 3000 + k * 400, 1800, 2); }); },
    over() {
      play(t => {
        [392, 349.23, 293.66, 196].forEach((f, k) => tone(f, t + k * 0.17, 0.26, 'triangle', 0.22));
        noise(t + 0.6, 0.25, 0.12, 'lowpass', 500, 200, 1);
      });
    },
    record() {
      play(t => { [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, k) => tone(f, t + k * 0.09, 0.3, 'triangle', 0.2)); });
    },
    ui() { play(t => tone(800, t, 0.05, 'sine', 0.1, 600)); }
  };
})();

/* ---------- state ---------- */
let cfg = DEFAULT_CONFIG, N = 8;
const canvas = $('game'), ctx = canvas.getContext('2d');
let grid, pops, tray, trayT, placeable, score, shown, best = 0, bestAtStart = 0, recordShown, streak, paused, over, gameId = 0;
let dragging = null, rets = [], effects = [], floats = [], shake = null;
let W = 0, H = 0, dpr = 1, cell = 0, boardX = 0, boardY = 0, trayX = 0, trayY = 0, trayW = 0, trayH = 0, slotW = 0, bm = 0;
let boardBg = null, trayBg = null;
const spriteCache = new Map();

/* ---------- game logic ---------- */
function fits(shape, r, c) {
  return shape.cells.every(([dr, dc]) => {
    const rr = r + dr, cc = c + dc;
    return rr >= 0 && rr < N && cc >= 0 && cc < N && !grid[rr][cc];
  });
}
function canPlaceAnywhere(shape) {
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (fits(shape, r, c)) return true;
  return false;
}
function fullLines(g) {
  const rows = [], cols = [];
  for (let r = 0; r < N; r++) if (g[r].every(v => v)) rows.push(r);
  for (let c = 0; c < N; c++) { let ok = true; for (let r = 0; r < N; r++) if (!g[r][c]) { ok = false; break; } if (ok) cols.push(c); }
  return { rows, cols };
}
function dealPieces() {
  let pick;
  for (let attempt = 0; attempt < 40; attempt++) {
    pick = [0, 1, 2].map(randomShape);
    if (pick.some(canPlaceAnywhere)) break;
  }
  return pick;
}
function refreshPlaceable() { placeable = tray.map(p => !!p && canPlaceAnywhere(p)); }
function dealTray(now, delayMs) {
  tray = dealPieces();
  trayT = [now + delayMs, now + delayMs + 110, now + delayMs + 220];
  refreshPlaceable();
  Sound.deal(delayMs / 1000);
}
function newGame() {
  gameId++;
  grid = Array.from({ length: N }, () => Array(N).fill(null));
  pops = Array.from({ length: N }, () => Array(N).fill(0));
  score = 0; shown = 0; streak = 0; paused = false; over = false; dragging = null;
  rets = []; effects = []; floats = []; shake = null;
  bestAtStart = best; recordShown = false;
  dealTray(performance.now(), 0);
  $('overlay').hidden = true;
  renderScore(false);
}
function placePiece(i, row, col) {
  const shape = tray[i];
  const now = performance.now();
  for (const [dr, dc] of shape.cells) { grid[row + dr][col + dc] = shape.color; pops[row + dr][col + dc] = now; }
  tray[i] = null;
  let gain = shape.cells.length * cfg.scoring.perCell;
  Sound.drop(); buzz(12);

  const { rows, cols } = fullLines(grid);
  const n = rows.length + cols.length;
  let word = null;
  if (n > 0) {
    streak++;
    const keys = new Set();
    rows.forEach(r => { for (let c = 0; c < N; c++) keys.add(r * N + c); });
    cols.forEach(c => { for (let r = 0; r < N; r++) keys.add(r * N + c); });
    const cleared = [], particles = [];
    keys.forEach(k => {
      const r = Math.floor(k / N), c = k % N;
      cleared.push({ r, c, color: grid[r][c] });
      for (let p = 0; p < 6; p++) {
        const a = Math.random() * Math.PI * 2, sp = (0.3 + Math.random() * 1.0) * cell;
        particles.push({
          x: boardX + (c + .5) * cell, y: boardY + (r + .5) * cell, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp - cell * 0.4,
          s: 1.5 + Math.random() * 3, color: Math.random() < 0.55 ? cfg.colors[grid[r][c]] : null,
          rot: Math.random() * 6, spin: (Math.random() - .5) * 8
        });
      }
    });
    keys.forEach(k => { grid[Math.floor(k / N)][k % N] = null; });
    effects.push({ cells: cleared, rows, cols, particles, t0: now, dur: 750 });
    gain += cfg.scoring.perLine * n * n + cfg.scoring.comboStep * (streak - 1) * n;
    if (grid.every(row => row.every(v => !v))) { gain += cfg.scoring.perfectClear; word = 'Perfect!'; }
    else word = n >= 4 ? 'Amazing!' : n === 3 ? 'Great!' : n === 2 ? 'Nice!' : null;
    if (n >= 2) shake = { t0: now, amp: cell * (0.07 + 0.035 * Math.min(n, 4)) };
    Sound.clear(n, streak - 1);
    buzz([20, 30, 40]);
  } else {
    streak = 0;
  }
  score += gain;

  const cx = boardX + N * cell / 2;
  floats.push({ kind: 'score', text: '+' + gain, sub: streak > 1 ? 'combo x' + streak : '', t0: now, dur: 1200, x: cx, y: boardY + N * cell * 0.5 });
  if (word) floats.push({ kind: 'word', text: word, t0: now, dur: 1300, x: cx, y: boardY + N * cell * 0.3, color: '#d9534f' });
  if (score > best) {
    best = score; saveBest();
    if (bestAtStart > 0 && !recordShown) {
      recordShown = true;
      floats.push({ kind: 'word', text: 'New best!', t0: now + 250, dur: 1500, x: cx, y: boardY + N * cell * 0.14, color: '#3a6fc4' });
      Sound.record();
      $('best').parentElement.classList.remove('flash'); void $('best').offsetWidth; $('best').parentElement.classList.add('flash');
    }
  }
  renderScore(true);

  if (tray.every(p => !p)) dealTray(now, n > 0 ? 350 : 120);
  else refreshPlaceable();

  if (!tray.some(p => p && canPlaceAnywhere(p))) {
    over = true;
    const id = gameId;
    setTimeout(() => {
      if (id !== gameId) return;
      Sound.over();
      showOverlay('No more room!', 'Score ' + pad6(score) + '\nBest ' + pad6(best), 'Try again', newGame);
    }, n > 0 ? 1000 : 600);
  }
}

/* ---------- ui ---------- */
function pad6(v) { return String(v).padStart(6, '0'); }
function renderScore(bump) {
  const el = $('score');
  el.textContent = pad6(Math.round(shown));
  $('best').textContent = pad6(best);
  if (bump) { el.classList.remove('bump'); void el.offsetWidth; el.classList.add('bump'); }
}
function showOverlay(title, text, label, action) {
  $('ovTitle').textContent = title;
  $('ovText').textContent = text;
  const b = $('ovBtn');
  b.textContent = label;
  b.onclick = () => { Sound.ui(); action(); };
  $('overlay').hidden = false;
}
function pause() {
  if (over || paused) return;
  paused = true; dragging = null;
  Sound.ui();
  showOverlay('Paused', 'Your board is safe.', 'Resume', resume);
}
function resume() { paused = false; $('overlay').hidden = true; }
function buzz(p) { try { if (cfg.vibrate && navigator.vibrate) navigator.vibrate(p); } catch (e) { /* ignore */ } }
function loadBest() { try { best = parseInt(localStorage.getItem(cfg.storageKey), 10) || 0; } catch (e) { best = 0; } }
function saveBest() { try { localStorage.setItem(cfg.storageKey, String(best)); } catch (e) { /* ignore */ } }
function loadMute() {
  let m = cfg.sound === false;
  try { const v = localStorage.getItem(cfg.storageKey + '.muted'); if (v !== null) m = v === '1'; } catch (e) { /* ignore */ }
  setMuted(m, false);
}
function setMuted(m, save) {
  Sound.setMuted(m);
  $('sound').classList.toggle('off', m);
  if (save) { try { localStorage.setItem(cfg.storageKey + '.muted', m ? '1' : '0'); } catch (e) { /* ignore */ } }
}

/* ---------- hand-drawn art (all generated, no image files) ---------- */
function getSprite(color, variant) {
  const px = Math.max(8, Math.round(cell * dpr));
  const key = color + '|' + variant + '|' + px;
  let cv = spriteCache.get(key);
  if (cv) return cv;
  cv = document.createElement('canvas');
  cv.width = cv.height = px;
  const g = cv.getContext('2d');
  const rnd = seeded(variant * 977 + hashStr(color));
  const m = px * 0.07, j = () => (rnd() - .5) * px * 0.05;
  const base = cfg.colors[color] || '#888888';
  const poly = () => {
    g.beginPath();
    g.moveTo(m + j(), m + j()); g.lineTo(px - m + j(), m + j());
    g.lineTo(px - m + j(), px - m + j()); g.lineTo(m + j(), px - m + j());
    g.closePath();
  };
  g.save();
  poly(); g.fillStyle = base; g.fill(); g.clip();
  g.lineCap = 'round';
  g.strokeStyle = shade(base, -45); g.globalAlpha = .33; g.lineWidth = px * .04;
  for (let k = -px; k < px; k += px / 6) { g.beginPath(); g.moveTo(k + j(), j()); g.lineTo(k + px + j(), px + j()); g.stroke(); }
  g.strokeStyle = '#fff'; g.globalAlpha = .22; g.lineWidth = px * .05;
  for (let k = 0; k < px * 2; k += px / 5) { g.beginPath(); g.moveTo(k + j(), j()); g.lineTo(k - px + j(), px + j()); g.stroke(); }
  g.restore();
  g.strokeStyle = cfg.pencil; g.lineJoin = 'round';
  for (let pass = 0; pass < 2; pass++) {
    g.globalAlpha = pass ? .4 : .8; g.lineWidth = px * (pass ? .03 : .045);
    poly(); g.stroke();
  }
  spriteCache.set(key, cv);
  return cv;
}
function drawSprite(color, variant, x, y, size, alpha) {
  ctx.globalAlpha = alpha === undefined ? 1 : alpha;
  ctx.drawImage(getSprite(color, variant), x, y, size, size);
  ctx.globalAlpha = 1;
}
function drawSpriteC(color, variant, cx, cy, size, alpha) { drawSprite(color, variant, cx - size / 2, cy - size / 2, size, alpha); }
function drawPiece(shape, x, y, size, alpha) {
  const pad = size * 0.1;
  ctx.save();
  ctx.globalAlpha = alpha === undefined ? 1 : alpha;
  ctx.shadowColor = 'rgba(40,40,60,.3)'; ctx.shadowBlur = 6; ctx.shadowOffsetY = 2;
  ctx.fillStyle = '#fffdf6';
  ctx.beginPath();
  for (const [dr, dc] of shape.cells) ctx.rect(x + dc * size - pad, y + dr * size - pad, size + 2 * pad, size + 2 * pad);
  ctx.fill();
  ctx.restore();
  for (const [dr, dc] of shape.cells) drawSprite(shape.color, (dr * 3 + dc * 5 + shape.id) % 3, x + dc * size, y + dr * size, size, alpha);
}
function drawPieceC(shape, cx, cy, size, alpha, angle) {
  ctx.save();
  ctx.translate(cx, cy);
  if (angle) ctx.rotate(angle);
  drawPiece(shape, -shape.w * size / 2, -shape.h * size / 2, size, alpha);
  ctx.restore();
}

function buildBackdrops() {
  bm = Math.round(cell * 0.12);
  const bw = cell * N + 2 * bm;
  boardBg = document.createElement('canvas');
  boardBg.width = boardBg.height = Math.ceil(bw * dpr);
  let g = boardBg.getContext('2d'); g.scale(dpr, dpr);
  let rnd = seeded(42);
  g.fillStyle = '#fbf8ee'; g.fillRect(0, 0, bw, bw);
  g.lineCap = 'round';
  g.strokeStyle = 'rgba(70,115,200,.72)'; g.lineWidth = 1.6;
  for (let i = 0; i <= N; i++) {
    wobblyLine(g, bm + i * cell, bm, bm + i * cell, bm + N * cell, rnd, 2);
    wobblyLine(g, bm, bm + i * cell, bm + N * cell, bm + i * cell, rnd, 2);
  }
  g.strokeStyle = cfg.ink; g.lineWidth = 3;
  for (let pass = 0; pass < 2; pass++) {
    const o = pass * 2.5;
    wobblyLine(g, 2 + o, 2 + o, bw - 2 - o, 2 + o, rnd, 2.5); wobblyLine(g, bw - 2 - o, 2 + o, bw - 2 - o, bw - 2 - o, rnd, 2.5);
    wobblyLine(g, bw - 2 - o, bw - 2 - o, 2 + o, bw - 2 - o, rnd, 2.5); wobblyLine(g, 2 + o, bw - 2 - o, 2 + o, 2 + o, rnd, 2.5);
    g.lineWidth = 1.5;
  }
  const tw = trayW + 2 * bm, th = trayH;
  trayBg = document.createElement('canvas');
  trayBg.width = Math.ceil(tw * dpr); trayBg.height = Math.ceil(th * dpr);
  g = trayBg.getContext('2d'); g.scale(dpr, dpr);
  rnd = seeded(7);
  const grad = g.createLinearGradient(0, 0, 0, th);
  grad.addColorStop(0, '#e3e9f4'); grad.addColorStop(1, '#cdd6e8');
  g.fillStyle = grad; g.fillRect(0, 0, tw, th);
  g.lineCap = 'round'; g.strokeStyle = cfg.ink; g.lineWidth = 3;
  for (let pass = 0; pass < 2; pass++) {
    const o = 2 + pass * 3.5;
    wobblyLine(g, o, o, tw - o, o, rnd, 2.5); wobblyLine(g, tw - o, o, tw - o, th - o, rnd, 2.5);
    wobblyLine(g, tw - o, th - o, o, th - o, rnd, 2.5); wobblyLine(g, o, th - o, o, o, rnd, 2.5);
    g.lineWidth = 1.5;
  }
}

function drawPaperBg() {
  const c = $('bg'); const w = c.width = window.innerWidth, h = c.height = window.innerHeight;
  const g = c.getContext('2d'); const rnd = seeded(2166);
  g.fillStyle = '#f3efe3'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 70; i++) {
    const cx = rnd() * w, cy = rnd() * h, r = 60 + rnd() * 200, a = rnd() * Math.PI * 2;
    g.beginPath();
    for (let k = 0; k < 3; k++) { const aa = a + k * 2.1 + rnd(); g.lineTo(cx + Math.cos(aa) * r, cy + Math.sin(aa) * r); }
    g.closePath();
    const gr = g.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
    gr.addColorStop(0, 'rgba(255,255,255,.28)'); gr.addColorStop(1, 'rgba(90,80,50,.07)');
    g.fillStyle = gr; g.fill();
  }
  g.lineCap = 'round';
  for (let i = 0; i < 22; i++) {
    const x1 = rnd() * w, y1 = rnd() * h, x2 = x1 + (rnd() - .5) * w * .8, y2 = y1 + (rnd() - .5) * h * .5;
    g.strokeStyle = 'rgba(90,80,50,.09)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x1, y1); g.lineTo(x2, y2); g.stroke();
    g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x1 + 1.5, y1 + 1.5); g.lineTo(x2 + 1.5, y2 + 1.5); g.stroke();
  }
  for (let i = 0; i < 1800; i++) { g.fillStyle = `rgba(80,70,40,${rnd() * .06})`; g.fillRect(rnd() * w, rnd() * h, 1.5, 1.5); }
}

/* ---------- layout ---------- */
function layout() {
  const r = $('stage').getBoundingClientRect();
  W = Math.max(1, r.width); H = Math.max(1, r.height);
  dpr = Math.min(window.devicePixelRatio || 1, 3);
  canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
  const pad = Math.max(10, W * 0.03), gap = Math.max(8, W * 0.02), trayCells = 3.2;
  cell = Math.max(10, Math.floor(Math.min((W - 2 * pad) / N, (H - 2 * pad - gap) / (N + trayCells))));
  const total = N * cell + gap + trayCells * cell;
  boardX = Math.round((W - N * cell) / 2);
  boardY = Math.round(Math.max(pad, (H - total) / 2));
  trayW = N * cell; trayH = Math.round(trayCells * cell);
  trayX = boardX; trayY = boardY + N * cell + gap;
  slotW = trayW / 3;
  spriteCache.clear();
  buildBackdrops();
}
function traySize(shape) { return Math.min(cell * cfg.trayScale, slotW * 0.88 / shape.w, trayH * 0.86 / shape.h); }
function slotCenter(i) { return { x: trayX + slotW * (i + .5), y: trayY + trayH / 2 }; }

/* ---------- input ---------- */
function pt(e) { const r = canvas.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
function targetFor(d) {
  const shape = tray[d.i];
  const px = d.x - shape.w * cell / 2;
  const py = d.y - shape.h * cell / 2 - cfg.dragLiftCells * cell;
  const col = Math.round((px - boardX) / cell), row = Math.round((py - boardY) / cell);
  return { shape, px, py, row, col, ok: fits(shape, row, col) };
}
function dragVisual(d, now) {
  const shape = tray[d.i], t = targetFor(d), sc = slotCenter(d.i);
  const e = easeOut(clamp01((now - d.t0) / 140));
  const tcx = t.px + shape.w * cell / 2, tcy = t.py + shape.h * cell / 2;
  const s0 = traySize(shape);
  return { t, shape, cx: lerp(sc.x, tcx, e), cy: lerp(sc.y, tcy, e), size: lerp(s0, cell, e) };
}
canvas.addEventListener('pointerdown', e => {
  Sound.unlock();
  if (paused || over || dragging) return;
  const { x, y } = pt(e);
  if (y < trayY - cell * 0.4) return;
  const i = Math.max(0, Math.min(2, Math.floor((x - trayX) / slotW)));
  if (!tray[i] || performance.now() < trayT[i]) return;
  rets = rets.filter(r => r.i !== i);
  dragging = { i, x, y, sx: x, sy: y, moved: false, t0: performance.now(), id: e.pointerId };
  try { canvas.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  Sound.pick(); buzz(6);
  e.preventDefault();
});
canvas.addEventListener('pointermove', e => {
  if (!dragging || e.pointerId !== dragging.id) return;
  const p = pt(e); dragging.x = p.x; dragging.y = p.y;
  if (Math.hypot(p.x - dragging.sx, p.y - dragging.sy) > 8) dragging.moved = true;
  e.preventDefault();
});
function endDrag(e, commit) {
  if (!dragging || e.pointerId !== dragging.id) return;
  const p = pt(e); dragging.x = p.x; dragging.y = p.y;
  const d = dragging; dragging = null;
  const shape = tray[d.i];
  if (!shape) return;
  const now = performance.now();
  if (commit && !paused && !over) {
    const t = targetFor(d);
    if (t.ok) { placePiece(d.i, t.row, t.col); return; }
  }
  const v = dragVisual(d, now);
  rets.push({ i: d.i, shape, cx: v.cx, cy: v.cy, size: v.size, t0: now, dur: 280 });
  if (commit && d.moved) Sound.invalid();
}
canvas.addEventListener('pointerup', e => endDrag(e, true));
canvas.addEventListener('pointercancel', e => endDrag(e, false));
canvas.addEventListener('contextmenu', e => e.preventDefault());

/* ---------- drawing ---------- */
function zigzag(x0, y0, x1, y1) {
  const dx = x1 - x0, dy = y1 - y0, len = Math.hypot(dx, dy);
  if (len < 1) return;
  const steps = Math.max(2, Math.round(len / (cell * 0.3)));
  const nx = -dy / len, ny = dx / len;
  ctx.beginPath(); ctx.moveTo(x0, y0);
  for (let k = 1; k <= steps; k++) {
    const t = k / steps, o = (k % 2 ? 1 : -1) * cell * 0.14;
    ctx.lineTo(x0 + dx * t + nx * o, y0 + dy * t + ny * o);
  }
  ctx.stroke();
}
function drawEffects(now) {
  effects = effects.filter(e => now - e.t0 < e.dur);
  for (const e of effects) {
    const p = (now - e.t0) / e.dur;
    for (const c of e.cells) {
      const x = boardX + c.c * cell, y = boardY + c.r * cell;
      drawSpriteC(c.color, (c.r * 7 + c.c * 13) % 3, x + cell / 2, y + cell / 2, cell * (1 + p * 0.3), Math.max(0, 1 - p * 1.4));
      const a = Math.sin(Math.PI * Math.min(1, p * 1.15)) * 0.55;
      const gr = ctx.createRadialGradient(x + cell / 2, y + cell / 2, 0, x + cell / 2, y + cell / 2, cell * 0.8);
      gr.addColorStop(0, `rgba(40,40,50,${a})`); gr.addColorStop(1, 'rgba(40,40,50,0)');
      ctx.fillStyle = gr; ctx.fillRect(x - cell * .3, y - cell * .3, cell * 1.6, cell * 1.6);
    }
    ctx.save();
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.strokeStyle = `rgba(70,150,230,${0.6 * (1 - p * p)})`; ctx.lineWidth = cell * 0.42;
    const reach = Math.min(1, p * 1.7) * cell * N;
    e.rows.forEach(r => { const y = boardY + (r + .5) * cell; zigzag(boardX, y, boardX + reach, y); });
    e.cols.forEach(c => { const x = boardX + (c + .5) * cell; zigzag(x, boardY, x, boardY + reach); });
    ctx.restore();
    const grav = cell * 2.4 * p * p;
    for (const q of e.particles) {
      const px = q.x + q.vx * p, py = q.y + q.vy * p + grav, a = 1 - p;
      if (q.color) {
        ctx.save(); ctx.translate(px, py); ctx.rotate(q.rot + q.spin * p);
        ctx.fillStyle = q.color; ctx.globalAlpha = a * 0.9;
        ctx.fillRect(-q.s * 1.2, -q.s * 1.2, q.s * 2.4, q.s * 2.4);
        ctx.strokeStyle = cfg.pencil; ctx.lineWidth = 1; ctx.strokeRect(-q.s * 1.2, -q.s * 1.2, q.s * 2.4, q.s * 2.4);
        ctx.restore();
      } else {
        ctx.fillStyle = `rgba(50,50,60,${0.6 * a})`;
        ctx.beginPath(); ctx.arc(px, py, q.s, 0, Math.PI * 2); ctx.fill();
      }
    }
  }
}
function drawFloats(now) {
  floats = floats.filter(f => now - f.t0 < f.dur);
  for (const f of floats) {
    const p = (now - f.t0) / f.dur;
    if (p < 0) continue;
    ctx.save();
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    if (f.kind === 'word') {
      const pop = easeOutBack(clamp01(p * 4));
      ctx.globalAlpha = p > 0.7 ? Math.max(0, 1 - (p - 0.7) / 0.3) : 1;
      ctx.translate(f.x, f.y - p * cell * 0.5); ctx.rotate(-0.07); ctx.scale(pop, pop);
      ctx.font = `700 ${Math.round(cell * 1.15)}px ${FONT}`;
      ctx.lineWidth = cell * 0.24; ctx.strokeStyle = '#fffdf6'; ctx.strokeText(f.text, 0, 0);
      ctx.lineWidth = cell * 0.05; ctx.strokeStyle = cfg.ink; ctx.strokeText(f.text, 0, 0);
      ctx.fillStyle = f.color; ctx.fillText(f.text, 0, 0);
    } else {
      ctx.globalAlpha = Math.max(0, 1 - p * p);
      const y = f.y - p * cell * 1.3;
      ctx.font = `700 ${Math.round(cell * 0.95)}px ${FONT}`;
      ctx.lineWidth = cell * 0.18; ctx.strokeStyle = '#fffdf6'; ctx.strokeText(f.text, f.x, y);
      ctx.fillStyle = cfg.ink; ctx.fillText(f.text, f.x, y);
      if (f.sub) {
        ctx.font = `700 ${Math.round(cell * 0.55)}px ${FONT}`;
        ctx.strokeText(f.sub, f.x, y + cell * 0.8);
        ctx.fillStyle = '#d9534f'; ctx.fillText(f.sub, f.x, y + cell * 0.8);
      }
    }
    ctx.restore();
  }
}
function draw(now) {
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);
  if (shake && now - shake.t0 < 380) {
    const a = shake.amp * (1 - (now - shake.t0) / 380);
    ctx.translate(Math.sin(now * 0.09) * a, Math.cos(now * 0.11) * a);
  }
  ctx.drawImage(boardBg, boardX - bm, boardY - bm, cell * N + 2 * bm, cell * N + 2 * bm);
  ctx.drawImage(trayBg, trayX - bm, trayY, trayW + 2 * bm, trayH);

  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const color = grid[r][c];
    if (!color) continue;
    const x = boardX + c * cell, y = boardY + r * cell, v = (r * 7 + c * 13) % 3;
    const p = (now - pops[r][c]) / 280;
    if (p >= 0 && p < 1) drawSpriteC(color, v, x + cell / 2, y + cell / 2, cell * (1 + 0.22 * Math.sin(Math.PI * p) * (1 - p)));
    else drawSprite(color, v, x, y, cell);
  }

  if (dragging && tray[dragging.i]) {
    const t = targetFor(dragging);
    if (t.ok) {
      const tmp = grid.map(row => row.slice());
      t.shape.cells.forEach(([dr, dc]) => { tmp[t.row + dr][t.col + dc] = 'x'; });
      const fl = fullLines(tmp);
      ctx.fillStyle = 'rgba(70,150,230,.28)';
      fl.rows.forEach(r => ctx.fillRect(boardX, boardY + r * cell, N * cell, cell));
      fl.cols.forEach(c => ctx.fillRect(boardX + c * cell, boardY, cell, N * cell));
      t.shape.cells.forEach(([dr, dc]) => drawSprite(t.shape.color, (dr * 3 + dc * 5 + t.shape.id) % 3, boardX + (t.col + dc) * cell, boardY + (t.row + dr) * cell, cell, 0.4));
    }
  }

  drawEffects(now);

  rets = rets.filter(r => now - r.t0 < r.dur);
  for (let i = 0; i < 3; i++) {
    const shape = tray[i];
    if (!shape || (dragging && dragging.i === i) || rets.some(r => r.i === i)) continue;
    const p = clamp01((now - trayT[i]) / 380);
    if (p <= 0) continue;
    const sc = slotCenter(i), e = easeOutBack(p);
    const bob = Math.sin(now / 900 + i * 2.1) * cell * 0.025, tilt = Math.sin(now / 700 + i * 1.7) * 0.018;
    const alpha = Math.min(1, p * 3) * (placeable[i] ? 1 : 0.42);
    drawPieceC(shape, sc.x, sc.y + bob + (1 - e) * cell * 3.5, traySize(shape), alpha, tilt);
  }
  for (const r of rets) {
    const e = easeOut(clamp01((now - r.t0) / r.dur)), sc = slotCenter(r.i);
    drawPieceC(r.shape, lerp(r.cx, sc.x, e), lerp(r.cy, sc.y, e), lerp(r.size, traySize(r.shape), e), placeable[r.i] ? 1 : 0.42, 0);
  }
  if (dragging && tray[dragging.i]) {
    const v = dragVisual(dragging, now);
    drawPieceC(v.shape, v.cx, v.cy, v.size, 1, -0.04);
  }
  drawFloats(now);
}
function frame(now) {
  if (shown !== score) {
    const diff = score - shown;
    shown = Math.abs(diff) < 1 ? score : shown + Math.sign(diff) * Math.max(1, Math.ceil(Math.abs(diff) * 0.16));
    renderScoreText();
  }
  draw(now);
  requestAnimationFrame(frame);
}
function renderScoreText() { $('score').textContent = pad6(Math.round(shown)); }

/* ---------- boot ---------- */
async function loadConfig() {
  try {
    const res = await fetch('config.json', { cache: 'no-store' });
    if (res.ok) return mergeConfig(DEFAULT_CONFIG, await res.json());
  } catch (e) { /* use embedded defaults */ }
  return DEFAULT_CONFIG;
}
let resizeTimer = 0;
function onResize() {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => { dragging = null; drawPaperBg(); layout(); }, 120);
}

(async function boot() {
  cfg = await loadConfig();
  N = Math.max(5, Math.min(12, parseInt(cfg.gridSize, 10) || 8));
  loadBest();
  loadMute();
  drawPaperBg();
  newGame();
  layout();
  $('retry').addEventListener('click', () => { Sound.unlock(); Sound.ui(); newGame(); });
  $('pause').addEventListener('click', () => { Sound.unlock(); if (paused) { Sound.ui(); resume(); } else pause(); });
  $('sound').addEventListener('click', () => { Sound.unlock(); const m = !Sound.isMuted(); setMuted(m, true); if (!m) Sound.ui(); });
  window.addEventListener('resize', onResize);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { pause(); Sound.suspend(); } else Sound.unlock();
  });
  requestAnimationFrame(frame);
})();
})();
