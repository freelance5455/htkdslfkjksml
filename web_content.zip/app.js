import { firebaseConfig } from "./firebase-config.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/13.2.0/firebase-app.js";
import { getAuth, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc, deleteDoc, collection, getDocs } from "https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js";

const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);

const $ = id => document.getElementById(id);
const lockScreen = $("lockScreen"), appEl = $("app");
let user = null, currentDate = null, viewDate = new Date(), records = {}, currentRows = [];
const PIN_KEY = "vs_pin_hash_v1", SALT_KEY = "vs_pin_salt_v1";

function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
function dateKey(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
function parseDate(key){const [y,m,d]=key.split("-").map(Number);return new Date(y,m-1,d)}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function hashPin(pin,salt){const enc=new TextEncoder();const key=await crypto.subtle.importKey("raw",enc.encode(pin),"PBKDF2",false,["deriveBits"]);const bits=await crypto.subtle.deriveBits({name:"PBKDF2",salt:enc.encode(salt),iterations:180000,hash:"SHA-256"},key,256);return [...new Uint8Array(bits)].map(b=>b.toString(16).padStart(2,"0")).join("")}
async function setPin(){const pin=$("pinInput").value.trim();if(!/^\d{6}$/.test(pin)){ $("lockError").textContent="Enter exactly six digits.";return false;}const salt=crypto.randomUUID();localStorage.setItem(SALT_KEY,salt);localStorage.setItem(PIN_KEY,await hashPin(pin,salt));$("pinInput").value="";$("lockError").textContent="Password saved on this device.";return true}
async function unlock(){const pin=$("pinInput").value.trim();if(!/^\d{6}$/.test(pin)){ $("lockError").textContent="Enter your six-digit password.";return;}let stored=localStorage.getItem(PIN_KEY);if(!stored){const ok=await setPin();if(ok)showApp();return;}const actual=await hashPin(pin,localStorage.getItem(SALT_KEY));if(actual===stored){$("pinInput").value="";$("lockError").textContent="";showApp();}else $("lockError").textContent="Incorrect password. Try again."}
function showApp(){lockScreen.hidden=true;appEl.hidden=false;renderCalendar();openCalendar();$("cloudStatus").textContent=user?"Connected to Firebase":"Connecting…"}
function lockApp(){appEl.hidden=true;lockScreen.hidden=false;$("pinInput").value="";$("lockError").textContent=""}
$("unlockBtn").addEventListener("click",unlock);
$("pinInput").addEventListener("keydown",e=>{if(e.key==="Enter")unlock()});
$("setPinBtn").addEventListener("click",async()=>{if(localStorage.getItem(PIN_KEY)){const old=prompt("Enter current app password");if(!old)return;const check=await hashPin(old,localStorage.getItem(SALT_KEY));if(check!==localStorage.getItem(PIN_KEY)){toast("Current password is incorrect");return;}}if(await setPin())toast("App password saved");});
$("lockNowBtn").onclick=lockApp;
$("changePinBtn").onclick=()=>$("setPinBtn").click();

async function connectCloud(){
  try{const cred=await signInAnonymously(auth);user=cred.user;$("cloudStatus").textContent="Connected";await loadMonthRecords();}
  catch(e){console.error(e);$("cloudStatus").textContent="Not connected: "+e.message;toast("Cloud connection failed. Check Firebase Authentication and Firestore rules.");}
}
onAuthStateChanged(auth,u=>{if(u){user=u;$("cloudStatus").textContent="Connected";if(!appEl.hidden)loadMonthRecords();}});
async function loadMonthRecords(){
  if(!user)return;
  const start=new Date(viewDate.getFullYear(),viewDate.getMonth(),1),end=new Date(viewDate.getFullYear(),viewDate.getMonth()+1,0);
  const tasks=[];for(let d=1;d<=end.getDate();d++){const key=dateKey(new Date(start.getFullYear(),start.getMonth(),d));tasks.push((async()=>{try{const snap=await getDoc(doc(db,"users",user.uid,"dailyRecords",key));if(snap.exists())records[key]=snap.data();else delete records[key];}catch(e){console.error(e);}})());}
  await Promise.all(tasks);renderCalendar();
}
function renderCalendar(){
  const y=viewDate.getFullYear(),m=viewDate.getMonth();$("monthLabel").textContent=new Intl.DateTimeFormat("en-IN",{month:"long",year:"numeric"}).format(viewDate);
  const first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate(),today=dateKey(new Date()),grid=$("calendarGrid");grid.innerHTML="";
  for(let i=0;i<first;i++){const b=document.createElement("div");b.className="day empty";grid.append(b);}
  for(let d=1;d<=days;d++){const key=dateKey(new Date(y,m,d)),b=document.createElement("button");b.className="day"+(key===today?" today":"")+(records[key]?" saved":"")+(key===currentDate?" selected":"");b.textContent=d;b.onclick=()=>openSheet(key);grid.append(b);}
}
$("prevMonth").onclick=async()=>{viewDate=new Date(viewDate.getFullYear(),viewDate.getMonth()-1,1);await loadMonthRecords();renderCalendar()};
$("nextMonth").onclick=async()=>{viewDate=new Date(viewDate.getFullYear(),viewDate.getMonth()+1,1);await loadMonthRecords();renderCalendar()};
$("todayBtn").onclick=()=>openSheet(dateKey(new Date()));
function openCalendar(){ $("calendarView").hidden=false;$("sheetView").hidden=true;$("settingsView").hidden=true;setNav("navCalendar");}
function setNav(id){["navCalendar","navSearch","navSettings"].forEach(x=>$(x).classList.toggle("active",x===id))}
$("backBtn").onclick=openCalendar;
$("settingsBtn").onclick=()=>openSettings();
$("navCalendar").onclick=openCalendar;
$("navSettings").onclick=()=>openSettings();
function openSettings(){$("calendarView").hidden=true;$("sheetView").hidden=true;$("settingsView").hidden=false;setNav("navSettings")}
function openSheet(key){currentDate=key;viewDate=parseDate(key);$("calendarView").hidden=true;$("sheetView").hidden=false;$("settingsView").hidden=true;$("selectedDateLabel").textContent=new Intl.DateTimeFormat("en-IN",{dateStyle:"full"}).format(parseDate(key));currentRows=(records[key]?.rows||[]).map(x=>({...x}));if(!currentRows.length)currentRows=[blankRow(1)];renderRows();$("syncStatus").textContent=records[key]?"Saved in cloud":"New sheet";setNav("navCalendar")}
function blankRow(n){return {kaalam:String(n),type:"வரவு",description:"",amount:"",total:""}}
function renderRows(){const body=$("rowsBody");body.innerHTML="";currentRows.forEach((r,i)=>{const tr=document.createElement("tr");tr.innerHTML=`
<td><input data-i="${i}" data-k="kaalam" value="${escapeHtml(r.kaalam)}" aria-label="காலம்"></td>
<td><select class="type" data-i="${i}" data-k="type"><option ${r.type==="வரவு"?"selected":""}>வரவு</option><option ${r.type==="செலவு"?"selected":""}>செலவு</option></select></td>
<td><input class="desc" data-i="${i}" data-k="description" value="${escapeHtml(r.description)}" aria-label="விவரம்"></td>
<td><input class="amount" type="number" min="0" step="0.01" data-i="${i}" data-k="amount" value="${escapeHtml(r.amount)}" aria-label="தொகை"></td>
<td><input type="number" step="0.01" data-i="${i}" data-k="total" value="${escapeHtml(r.total)}" aria-label="மொத்தம்"></td>
<td><button class="row-delete" data-delete="${i}" title="Delete row">×</button></td>`;body.append(tr);});
body.querySelectorAll("[data-i]").forEach(el=>el.addEventListener("input",e=>{const i=+e.target.dataset.i,k=e.target.dataset.k;currentRows[i][k]=e.target.value;}));
body.querySelectorAll("[data-delete]").forEach(el=>el.onclick=()=>{currentRows.splice(+el.dataset.delete,1);if(!currentRows.length)currentRows.push(blankRow(1));renderRows();});
}
$("addRowBtn").onclick=()=>{currentRows.push(blankRow(currentRows.length+1));renderRows();};
$("saveBtn").onclick=saveSheet;
async function saveSheet(){
 if(!user){toast("Cloud is not connected yet.");return;}
 const clean=currentRows.map(r=>({kaalam:String(r.kaalam||""),type:r.type==="செலவு"?"செலவு":"வரவு",description:String(r.description||""),amount:r.amount===""?"":Number(r.amount),total:r.total===""?"":Number(r.total)}));
 $("syncStatus").textContent="Saving…";
 try{await setDoc(doc(db,"users",user.uid,"dailyRecords",currentDate),{date:currentDate,rows:clean,updatedAt:new Date().toISOString()});records[currentDate]={date:currentDate,rows:clean};$("syncStatus").textContent="Saved ✓";renderCalendar();toast("Saved to cloud");}
 catch(e){console.error(e);$("syncStatus").textContent="Save failed";toast("Could not save. Check Firestore security rules.");}
}
$("deleteDayBtn").onclick=async()=>{if(!user||!currentDate)return;if(!confirm("Delete all records for this date?"))return;try{await deleteDoc(doc(db,"users",user.uid,"dailyRecords",currentDate));delete records[currentDate];toast("Day deleted");openCalendar();renderCalendar();}catch(e){toast("Delete failed. Check security rules.");}};
$("settingsBackBtn").onclick=openCalendar;
$("navSearch").onclick=()=>{$("searchDialog").showModal();$("searchInput").focus();setNav("navSearch")};
$("searchInput").addEventListener("input",()=>{const q=$("searchInput").value.toLowerCase(),box=$("searchResults");box.innerHTML="";Object.entries(records).filter(([date,data])=>date.includes(q)||(data.rows||[]).some(r=>(r.description||"").toLowerCase().includes(q))).sort(([a],[b])=>b.localeCompare(a)).forEach(([date,data])=>{const b=document.createElement("button");b.className="result";b.textContent=date+" — "+(data.rows||[]).map(r=>r.description).filter(Boolean).join(", ");b.onclick=()=>{$("searchDialog").close();openSheet(date)};box.append(b);});});
$("exportBtn").onclick=()=>{const blob=new Blob([JSON.stringify(records,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="varavu-selavu-backup.json";a.click();URL.revokeObjectURL(url);};
$("importFile").onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());if(!user)throw new Error("Cloud not connected");for(const [date,record] of Object.entries(data)){if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Array.isArray(record.rows))continue;await setDoc(doc(db,"users",user.uid,"dailyRecords",date),{date,rows:record.rows,updatedAt:new Date().toISOString()});}await loadMonthRecords();toast("Import completed");}catch(err){toast("Import failed: "+err.message)}e.target.value="";};

connectCloud();
if("serviceWorker" in navigator)navigator.serviceWorker.register("./sw.js").catch(console.warn);
