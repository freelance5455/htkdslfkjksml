import*as M from './memory.js';import{reply}from './ai-engine.js';import{PRESETS,loadLocal,localReady}from './model-manager.js';
const $=i=>document.getElementById(i),F=['mode','preset','url','key','model','persona'];
let cfg={mode:'online',preset:'pollinations',url:PRESETS.pollinations.url,model:'openai',key:'',persona:'',sendMem:true,maxTokens:350},chats=[],cur,ctl;
const esc=s=>s.replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
function md(s){const b=[];s=esc(s).replace(/```\w*\n?([\s\S]*?)(```|$)/g,(_,c)=>{b.push(c);return'\u0000'+(b.length-1)+'\u0000'});
 s=s.replace(/`([^`\n]+)`/g,'<code>$1</code>').replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>').replace(/^#{1,3} (.+)$/gm,'<h4>$1</h4>').replace(/^[-*] (.+)$/gm,'• $1').replace(/\n/g,'<br>');
 return s.replace(/\u0000(\d+)\u0000/g,(_,i)=>'<div class="code"><button class="cp">Copiar</button><pre>'+b[i]+'</pre></div>')}
const newChat=()=>{const c={id:M.uid(),title:'Nova conversa',msgs:[],ts:Date.now()};chats.unshift(c);return c};
function bubble(m){const d=document.createElement('div');d.className='m '+m.role;m.role==='user'?d.textContent=m.content:d.innerHTML=md(m.content);$('msgs').append(d);d.scrollIntoView({block:'end'});return d}
function draw(){$('mode').textContent='Online · '+(cfg.model||'modelo não configurado');$('chats').innerHTML='';
 for(const c of chats){const b=document.createElement('div');b.className='ch'+(c===cur?' on':'');b.textContent=c.title;b.onclick=()=>{cur=c;draw();$('side').classList.remove('open')};
  const x=document.createElement('i');x.textContent='✕';x.onclick=async e=>{e.stopPropagation();await M.del('chats',c.id);chats=chats.filter(k=>k!==c);if(cur===c)cur=chats[0]||newChat();draw()};b.append(x);$('chats').append(b)}
 $('msgs').innerHTML='';cur.msgs.forEach(bubble)}
$('f').onsubmit=async e=>{e.preventDefault();if(ctl){ctl.abort();return}
 const t=$('in').value.trim();if(!t)return;$('in').value='';$('in').style.height='auto';
 const hist=[...cur.msgs],u={role:'user',content:t};cur.msgs.push(u);if(!hist.length)cur.title=t.slice(0,32);bubble(u);
 const a={role:'assistant',content:''},d=bubble(a);d.classList.add('gen');ctl=new AbortController();$('send').textContent='■';
 try{if(cfg.mode==='offline'&&!localReady()){d.textContent='Carregando modelo local…';await loadLocal(p=>d.textContent='Baixando modelo: '+Math.round(p*100)+'%')}
  a.content=await reply(cfg,hist,t,x=>{a.content=x;d.innerHTML=md(x);d.scrollIntoView({block:'end'})},ctl.signal)}
 catch(err){if(err.name!=='AbortError')a.content+='\n⚠ '+err.message}
 a.content=a.content||'(interrompido)';cur.msgs.push(a);cur.ts=Date.now();await M.put('chats',cur);ctl=null;$('send').textContent='➤';draw()};
$('in').oninput=e=>{e.target.style.height='auto';e.target.style.height=Math.min(e.target.scrollHeight,140)+'px'};
$('msgs').onclick=e=>{if(e.target.classList.contains('cp')){navigator.clipboard.writeText(e.target.nextElementSibling.textContent);e.target.textContent='Copiado'}};
$('menu').onclick=()=>$('side').classList.toggle('open');$('new').onclick=()=>{cur=newChat();draw();$('side').classList.remove('open')};
async function mems(){const l=$('mems');l.innerHTML='';for(const m of await M.all('mems')){const r=document.createElement('div'),i=document.createElement('input'),x=document.createElement('button');
 i.value=m.text;i.onchange=()=>M.put('mems',{...m,text:i.value});x.type='button';x.textContent='✕';x.onclick=async()=>{await M.del('mems',m.id);mems()};r.append(i,x);l.append(r)}}
$('cfg').onclick=async()=>{for(const k of F)$('s_'+k).value=cfg[k]||'';$('s_mem').checked=!!cfg.sendMem;await mems();$('dlg').showModal()};
$('s_preset').onchange=e=>{const p=PRESETS[e.target.value];$('s_url').value=p.url;$('s_model').value=p.model};
$('s_save').onclick=async()=>{for(const k of F)cfg[k]=$('s_'+k).value.trim();cfg.sendMem=$('s_mem').checked;cfg.mode='online';await M.put('cfg',{id:'cfg',...cfg});draw();$('dlg').close()};
$('s_close').onclick=()=>$('dlg').close();
$('add').onclick=async()=>{const v=$('s_new').value.trim();if(v){await M.remember(v);$('s_new').value='';mems()}};
$('s_wipe').onclick=async()=>{if(confirm('Apagar TODOS os dados locais (conversas, memórias, configurações e modelo baixado)?')){await M.wipe();for(const k of await caches.keys())await caches.delete(k);location.reload()}};
(async()=>{Object.assign(cfg,await M.get('cfg')||{});cfg.mode='online';chats=(await M.all('chats')).sort((a,b)=>b.ts-a.ts);cur=chats[0]||newChat();draw();if('serviceWorker'in navigator)navigator.serviceWorker.register('service-worker.js')})();
