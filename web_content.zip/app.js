/* MADAR STORE — Static RTL storefront + Supabase backend. Guest checkout never requires login.
   Demo mode is explicitly marked and persists only to this browser. */
(()=>{
'use strict';
const cfg=window.STORE_CONFIG||{};
const expectsBackend=!!(cfg.supabaseUrl&&cfg.supabaseAnonKey);
if(expectsBackend&&!window.supabase){document.querySelector("#app").innerHTML="<div class=\"loading-screen\"><h2>تعذر تحميل اتصال قاعدة البيانات</h2><p>تحقق من الاتصال بالإنترنت وأعد تحميل الصفحة.</p></div>";return;}
const backendReady=!!(expectsBackend&&window.supabase);
const db=backendReady?window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey):null;
const CART_KEY='madar_cart_v1', DEMO_P_KEY='madar_products_v1', DEMO_O_KEY='madar_orders_v1', VISITOR_KEY='madar_unique_browser_v1';
// These six storefront sections always exist, regardless of the number of products.
// Additional sections are stored separately in Supabase so deleting products never removes them.
const DEFAULT_SECTIONS=['الأجهزة الكهربائية','الشواحن والكابلات','الجوالات','الملابس الرجالية','الملابس النسائية','الإكسسوارات'];
function mergeSections(saved,products){
 const used=Array.isArray(products)?products.filter(p=>p.active!==false).map(p=>p.category):[];
 return [...new Set([...DEFAULT_SECTIONS,...(Array.isArray(saved)?saved:[]),...used].filter(c=>typeof c==='string'&&c.trim()).map(c=>c.trim()))];
}
const money=(v)=>new Intl.NumberFormat('ar-SA',{maximumFractionDigits:2}).format(Number(v)||0)+' '+(cfg.currency||'ر.س');
const esc=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const getJ=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
const setJ=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
const demoProducts=[
{id:'d1',name:'سماعات لاسلكية بتقنية عزل الضوضاء',category:'إلكترونيات',price:189,compare_at:249,stock:24,image_url:'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=900&auto=format&fit=crop&q=80',description:'صوت نقي وتصميم مريح للاستخدام اليومي، مع وسائد أذن ناعمة وعمر بطارية طويل.',featured:true,active:true,emoji:'🎧'},
{id:'d2',name:'ساعة يد عصرية بتصميم فاخر',category:'أزياء وإكسسوارات',price:249,compare_at:320,stock:15,image_url:'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=900&auto=format&fit=crop&q=80',description:'ساعة أنيقة بتفاصيل راقية تضيف لمسة تميز إلى إطلالتك اليومية.',featured:true,active:true,emoji:'⌚'},
{id:'d3',name:'عطر فاخر بنفحات شرقية',category:'عطور وجمال',price:139,compare_at:189,stock:32,image_url:'https://images.unsplash.com/photo-1541643600914-78b084683601?w=900&auto=format&fit=crop&q=80',description:'تركيبة عطرية متوازنة بروائح دافئة ولمسات شرقية رائعة. الحجم: 100 مل.',featured:true,active:true,emoji:'🧴'},
{id:'d4',name:'كاميرا رقمية لمحبي التصوير',category:'إلكترونيات',price:899,compare_at:null,stock:6,image_url:'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=900&auto=format&fit=crop&q=80',description:'تصميم عملي يناسب تصوير اللحظات المميزة والمناسبات الشخصية.',featured:false,active:true,emoji:'📷'},
{id:'d5',name:'حقيبة أنيقة للاستخدام اليومي',category:'أزياء وإكسسوارات',price:165,compare_at:219,stock:18,image_url:'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=900&auto=format&fit=crop&q=80',description:'حقيبة بحجم مناسب وتفاصيل أنيقة، تجمع العملية والأناقة.',featured:true,active:true,emoji:'👜'},
{id:'d6',name:'حامل لابتوب مكتبي قابل للتعديل',category:'المنزل والمكتب',price:95,compare_at:125,stock:40,image_url:'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=900&auto=format&fit=crop&q=80',description:'حامل متين يساعد على ترتيب مساحة العمل وتحسين وضعية الجلوس.',featured:false,active:true,emoji:'💻'},
{id:'d7',name:'مجموعة أكواب قهوة بتصميم مميز',category:'المنزل والمكتب',price:79,compare_at:null,stock:48,image_url:'https://images.unsplash.com/photo-1442512595331-e89e73853f31?w=900&auto=format&fit=crop&q=80',description:'مجموعة أكواب مناسبة للقهوة الصباحية والضيافة المنزلية.',featured:false,active:true,emoji:'☕'},
{id:'d8',name:'مكبر صوت بلوتوث محمول',category:'إلكترونيات',price:129,compare_at:165,stock:17,image_url:'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=900&auto=format&fit=crop&q=80',description:'مكبر صوت صغير وسهل الحمل، مع اتصال لاسلكي سريع.',featured:true,active:true,emoji:'🔊'}
];
let state={products:[],storeCategories:[...DEFAULT_SECTIONS],orders:[],cart:getJ(CART_KEY,[]),settings:{name:'مدار ستور',tagline:'كل ما تحتاجه في مكان واحد',delivery_fee:20,hero_title:'كل احتياجاتك... في مكان واحد',hero_subtitle:'منتجات مختارة بعناية، أسعار تناسبك، وتجربة تسوق سهلة من أول نقرة.',phone:'',whatsapp_enabled:true,whatsapp_number:'+966530748045',whatsapp_message:'مرحباً، لدي استفسار بخصوص أحد المنتجات المعروضة في متجركم.',orders_enabled:false,merchant_name:'',merchant_address:'',merchant_registration:'',merchant_tax_id:'',contact_email:'mohamedkhrsani1@gmail.com',allowed_cities:[],delivery_estimate:'',shipping_policy:'',returns_policy:'',complaints_policy:''},filter:'الكل',search:'',sort:'featured',adminTab:'overview',adminReady:false,adminUser:null,viewLoading:false,location:null,map:null,marker:null,productEdit:null,qtyDetail:1,detailImageIndex:0,visitorData:{real_unique_browsers:0,display_count:5000}};
let editorImages=[];
const app=document.querySelector('#app');const $=sel=>document.querySelector(sel);
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(window.toastT);window.toastT=setTimeout(()=>el.classList.remove('show'),3100)}
function defaultData(){state.products=getJ(DEMO_P_KEY,demoProducts);state.orders=getJ(DEMO_O_KEY,[]);state.storeCategories=mergeSections(getJ('madar_demo_sections_v1',[]),state.products)}
async function loadPublic(){if(!backendReady){defaultData();return}const [products,setting,sectionList]=await Promise.all([db.from('products').select('*').eq('active',true).order('created_at',{ascending:false}),db.from('store_settings').select('name,tagline,delivery_fee,hero_title,hero_subtitle,phone,whatsapp_enabled,whatsapp_number,whatsapp_message,orders_enabled,merchant_name,merchant_address,merchant_registration,merchant_tax_id,contact_email,allowed_cities,delivery_estimate,shipping_policy,returns_policy,complaints_policy').eq('id',1).maybeSingle(),db.from('madar_store_categories').select('name').order('display_order',{ascending:true}).order('created_at',{ascending:true})]);if(products.error)throw products.error;state.products=products.data||[];state.storeCategories=mergeSections(sectionList.error?state.storeCategories:(sectionList.data||[]).map(c=>c.name),state.products);if(sectionList.error)console.warn('تعذر تحميل الأقسام المحفوظة',sectionList.error);if(setting.data)state.settings={...state.settings,...setting.data};}
// Anonymous browser-based counter: no IP address, email, phone or fingerprint is collected.
const formatVisits=n=>new Intl.NumberFormat('en-US',{maximumFractionDigits:0}).format(Math.max(0,Number(n)||0));
function storeBrowserId(){
  const uuidRx=/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  let id='';
  try{id=localStorage.getItem(VISITOR_KEY)||''}catch(_){ }
  if(uuidRx.test(id))return id;
  if(!window.crypto?.getRandomValues)return null;
  const bytes=new Uint8Array(16);window.crypto.getRandomValues(bytes);
  bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;
  const h=[...bytes].map(b=>b.toString(16).padStart(2,'0')).join('');
  id=`${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
  try{localStorage.setItem(VISITOR_KEY,id)}catch(_){
    try{const remembered=sessionStorage.getItem(VISITOR_KEY);if(uuidRx.test(remembered))return remembered;sessionStorage.setItem(VISITOR_KEY,id)}catch(_){return null}
  }
  return id;
}
function updateVisitorDisplay(){
  const d=state.visitorData;
  document.querySelectorAll('[data-visitor-display]').forEach(e=>{e.textContent=formatVisits(d.display_count)});
  document.querySelectorAll('[data-visitor-real]').forEach(e=>{e.textContent=formatVisits(d.real_unique_browsers)});
}
let visitRequestSerial=0;
async function syncVisitorCounter(){
  if(!backendReady)return;
  const seq=++visitRequestSerial;
  const isAdminPage=route().startsWith('admin');
  try{
    const id=isAdminPage?null:storeBrowserId();
    if(!isAdminPage&&!id)return;
    const response=isAdminPage
      ? await db.rpc('get_madar_store_visit_stats')
      : await db.rpc('record_madar_store_visit',{p_browser_id:id});
    if(response.error || !response.data || seq!==visitRequestSerial)return;
    const real=Number(response.data.real_unique_browsers);
    if(!Number.isSafeInteger(real)||real<0)return;
    state.visitorData={real_unique_browsers:real,display_count:5000+real};
    updateVisitorDisplay();
  }catch(e){console.warn('تعذر تحديث عداد المتجر',e)}
}
const href=(s)=>'#/'+(s||'');const route=()=>decodeURIComponent(location.hash.replace(/^#\/?/,'')||'');
const icon=(name)=>({cart:'🛒',heart:'♡',search:'⌕',user:'♙',home:'⌂',pack:'▦',chart:'◫',logout:'↩',back:'←'}[name]||'✦');
function getProduct(id){return state.products.find(x=>x.id===id)}
function cartItems(){return state.cart.map(it=>({...it,product:getProduct(it.id)})).filter(x=>x.product&&x.product.active!==false&&x.product.stock>0&&!x.product.demo_product)}
function cartCount(){return cartItems().reduce((s,x)=>s+x.qty,0)}
function subTotal(){return cartItems().reduce((s,x)=>s+x.qty*x.product.price,0)}
function cartStore(){setJ(CART_KEY,state.cart)}
function addToCart(id,qty=1){const p=getProduct(id);if(!p||p.stock<=0||p.demo_product){toast('هذا المنتج مخصص للعرض فقط وغير متاح للشراء');return}const existing=state.cart.find(x=>x.id===id);const current=existing?existing.qty:0;if(current+qty>p.stock){toast('الكمية المطلوبة أكبر من المتوفر');return}if(existing)existing.qty+=qty;else state.cart.push({id,qty});cartStore();toast('تمت إضافة المنتج إلى السلة 🛒');render()}
function setCartQty(id,qty){const p=getProduct(id);state.cart=state.cart.filter(x=>x.id!==id);if(p&&!p.demo_product&&qty>0)state.cart.push({id,qty:Math.min(qty,p.stock,20)});cartStore();render()}
function galleryImages(p){
  const fromGallery=Array.isArray(p?.image_urls)?p.image_urls.filter(u=>typeof u==='string'&&(/^(https:\/\/|data:image\/(?:jpeg|png|webp);base64,)/i.test(u))).slice(0,10):[];
  return fromGallery.length?fromGallery:(p?.image_url&&/^(https:\/\/|data:image\/(?:jpeg|png|webp);base64,)/i.test(p.image_url)?[p.image_url]:[]);
}
function productUrl(p){return 'https://madar-store-sa.madarstore.workers.dev/#/product/'+encodeURIComponent(p.id)}
async function copyProductLink(p){
  const value=productUrl(p);
  try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(value);toast('تم نسخ رابط المنتج ✓');return}}
  catch(_){}
  const temp=document.createElement('textarea');temp.value=value;temp.setAttribute('readonly','');temp.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.appendChild(temp);temp.select();
  try{if(document.execCommand('copy'))toast('تم نسخ رابط المنتج ✓');else throw Error('copy')}catch(_){toast('رابط المنتج: '+value)}finally{temp.remove()}
}
async function shareProduct(p){
  if(!p)return;
  const url=productUrl(p);
  if(navigator.share){try{await navigator.share({title:p.name,text:'شاهد هذا المنتج في مدار ستور',url});return}catch(e){if(e?.name==='AbortError')return}}
  await copyProductLink(p)
}
function productPic(p,cl=''){const first=galleryImages(p)[0];const src=first?`<img src="${esc(first)}" loading="lazy" alt="${esc(p.name)}" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"/>`:'';return `<div class="${cl||'product-pic'}">${src}<span class="fallback">${esc(p.emoji||'📦')}</span></div>`}
function isOffer(p){return Boolean(p&&p.offer_active&&Number(p.compare_at)>Number(p.price)&&Number(p.price)>0)}
function offerPercent(p){return isOffer(p)?Math.max(1,Math.round((1-Number(p.price)/Number(p.compare_at))*100)):0}
function offerBadge(p){return isOffer(p)?`<span class="offer-discount-badge">${p.demo_product?'عرض تجريبي · ':''}خصم ${offerPercent(p)}%</span>`:''}
function productCard(p){return `<article class="product-card"><a href="#/product/${encodeURIComponent(p.id)}" aria-label="تفاصيل ${esc(p.name)}"><div class="product-pic">${productPic(p,'product-image')} ${offerBadge(p)} ${p.demo_product?'<span class="badge showcase-demo-badge">للعرض فقط</span>':p.compare_at>p.price&&!isOffer(p)?'<span class="badge green">عرض خاص</span>':''}</div></a><div class="product-info"><div class="cat">${esc(p.category)}</div><a href="#/product/${encodeURIComponent(p.id)}"><h3>${esc(p.name)}</h3></a><div class="bottom"><div><span class="price">${money(p.price)}</span> ${p.compare_at>p.price?`<div class="old-price">${money(p.compare_at)}</div>`:''}</div><div class="card-action-buttons"><button class="product-share-btn" type="button" title="مشاركة رابط المنتج" aria-label="مشاركة ${esc(p.name)}" data-action="share-product" data-id="${esc(p.id)}">↗</button><button aria-label="أضف ${esc(p.name)} إلى السلة" class="mini-cart" data-action="add" data-id="${esc(p.id)}" ${p.stock<=0||p.demo_product?'disabled':''}>＋</button></div></div></div></article>`}
function categories(){return ['الكل',...mergeSections(state.storeCategories,state.products)]}
function brandMark(){return `<span class="logo-mark" aria-hidden="true"><svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" role="img" focusable="false"><defs><linearGradient id="mg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#163f39"/><stop offset="100%" stop-color="#0b2523"/></linearGradient><linearGradient id="ag" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#f1d29a"/><stop offset="100%" stop-color="#c79b57"/></linearGradient></defs><rect x="3" y="3" width="58" height="58" rx="18" fill="url(#mg)"/><circle cx="32" cy="32" r="22" fill="none" stroke="rgba(255,255,255,.12)" stroke-width="1.5"/><path d="M20 19.5a3 3 0 0 1 3-3h18a3 3 0 0 1 3 3v24.5a3 3 0 0 1-3 3H23a3 3 0 0 1-3-3V19.5Z" fill="none" stroke="url(#ag)" stroke-width="3"/><path d="M25 22.5c0-4.2 3.1-7.5 7-7.5s7 3.3 7 7.5" fill="none" stroke="url(#ag)" stroke-width="3" stroke-linecap="round"/><path d="M32 25v14m0 0c0-3.4-2.4-5.4-5.2-5.4m5.2 5.4c0-3.4 2.4-5.4 5.2-5.4" fill="none" stroke="url(#ag)" stroke-width="3.1" stroke-linecap="round" stroke-linejoin="round"/></svg></span>`}
function header(){return `<div class="site-top">✦ ${state.settings.orders_enabled?'اطلب منتجاتك بدون إنشاء حساب':'مدار ستور — التجهيز النهائي قبل الافتتاح'} ✦</div><header class="header"><div class="container header-main"><a href="#/" class="logo" aria-label="الصفحة الرئيسية">${brandMark()}<div><h2>${esc(state.settings.name)}</h2><small>تجربة تسوق بتفاصيل مختلفة</small></div></a><div class="header-search"><span style="font-size:25px">⌕</span><input id="global-search" type="search" placeholder="ابحث عن منتجك المفضل..." value="${esc(state.search)}" autocomplete="off" aria-label="البحث عن المنتجات"/><span class="muted tiny">بحث</span></div><div class="head-actions"><a href="#/admin" class="row gap8"><span style="font-size:19px">♙</span><span class="label fine bold">لوحة الإدارة</span></a><a href="#/cart" class="header-cart circle" aria-label="سلة المشتريات"><span style="font-size:18px">🛒</span><span class="cart-dot">${cartCount()}</span></a></div></div><nav class="container nav-links"><a href="#/">الرئيسية</a><a href="#/products">جميع المنتجات</a><a class="offers-nav-link" href="#/offers">🏷 العروض والتخفيضات</a><a href="#/track">📦 تتبع الطلب</a>${categories().slice(1,4).map(c=>`<a href="#/products?category=${encodeURIComponent(c)}">${esc(c)}</a>`).join('')}</nav></header>${!backendReady?'<div class="demo-note">🟠 وضع معاينة: المنتجات والطلبات تجريبية ومحفوظة على هذا الجهاز فقط، ولا تصلك رسائل بريد الآن.</div>':!state.settings.orders_enabled?'<div class="demo-note">🔒 المتجر قيد التجهيز — الطلبات غير مفعّلة حتى إكمال بيانات التوصيل والسياسات وإضافة منتجات حقيقية.</div>':''}`}
function footer(){return `<footer class="footer"><div class="container"><div class="footer-grid"><div><div class="logo">${brandMark()}<div><h2>${esc(state.settings.name)}</h2><small>متجر متنوع</small></div></div><p>تسوق بكل سهولة، اختر منتجاتك، وأرسل طلبك مباشرة دون إنشاء حساب. نعمل لنقدم لك تجربة شراء عملية ومريحة.</p></div><div><h4>روابط سريعة</h4><div class="footer-links"><a href="#/">الرئيسية</a><a href="#/products">المنتجات</a><a href="#/offers">العروض والتخفيضات</a><a href="#/cart">السلة</a><a href="#/track">تتبع الطلب</a><a href="#/admin">إدارة المتجر</a></div></div><div><h4>معلومات المتجر</h4><div class="footer-links"><a href="#/policy">الخصوصية والطلبات</a><span>الدفع عند الاستلام</span><span>السعر بالريال السعودي</span></div></div></div><div class="footer-bottom row between wrap"><span>© ${new Date().getFullYear()} ${esc(state.settings.name)} — جميع الحقوق محفوظة</span><span>${esc(state.settings.contact_email||'')} • الدفع عند الاستلام</span></div></div></footer><div class="mobile-bottom"><a href="#/"><span>⌂</span>الرئيسية</a><a href="#/products"><span>▦</span>المنتجات</a><a href="#/cart"><span>🛒</span>السلة (${cartCount()})</a><a href="#/track"><span>📦</span>طلبك</a><a href="#/admin"><span>♙</span>الإدارة</a></div>`}

// WhatsApp: independently managed admin contact, visible on every customer-facing page.
function normalizeWhatsApp(raw){
  const v=String(raw||'').replace(/[^0-9]/g,'');
  const international=v.startsWith('00')?v.slice(2):v;
  const number=international.startsWith('05')&&international.length===10?'966'+international.slice(1):international;
  return number.length>=9&&number.length<=15?number:'';
}
function whatsappLink(){
  const st=state.settings;
  if(st.whatsapp_enabled!==true)return '';
  const number=normalizeWhatsApp(st.whatsapp_number);
  if(!number)return '';
  const message=String(st.whatsapp_message||'').trim().slice(0,500);
  const url='https://wa.me/'+number+(message?'?text='+encodeURIComponent(message):'');
  return `<a class="whatsapp-float" href="${esc(url)}" target="_blank" rel="noopener noreferrer" aria-label="التواصل مع المتجر عبر واتساب" title="تواصل معنا على واتساب">
    <span class="whatsapp-float-icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.966-.273-.099-.471-.148-.67.15-.198.297-.767.965-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.058-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.174.198-.298.297-.496.1-.198.05-.371-.025-.52-.074-.149-.669-1.612-.916-2.206-.242-.579-.487-.5-.67-.51l-.57-.01c-.199 0-.52.075-.793.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.29.173-1.413-.074-.124-.272-.198-.57-.347m-5.422 7.768h-.004a9.82 9.82 0 0 1-5.006-1.37l-.359-.213-3.723.977.993-3.631-.233-.372a9.813 9.813 0 0 1-1.507-5.242c.002-5.426 4.417-9.842 9.852-9.842a9.79 9.79 0 0 1 6.967 2.889 9.79 9.79 0 0 1 2.887 6.977c-.002 5.426-4.418 9.842-9.867 9.842m8.384-18.236A11.86 11.86 0 0 0 12.009.31C5.456.31.121 5.645.118 12.199a11.86 11.86 0 0 0 1.588 5.936L0 24l6.008-1.575a11.9 11.9 0 0 0 5.999 1.528h.005c6.553 0 11.889-5.335 11.892-11.892a11.84 11.84 0 0 0-3.47-8.383z"/></svg></span>
    <span class="whatsapp-float-text">تواصل واتساب</span>
  </a>`;
}
function layout(content){return header()+`<main class="container" id="main-content">${content}</main>`+footer()+whatsappLink()}
function sectionIcon(category){
 const shapes={
  'الأجهزة الكهربائية':'<rect x="7" y="6" width="34" height="36" rx="8"/><circle cx="24" cy="23" r="9"/><circle cx="24" cy="23" r="3"/><path d="M13 12h4m5 0h4"/>',
  'الشواحن والكابلات':'<rect x="15" y="9" width="18" height="27" rx="5"/><path d="M20 9V4m8 5V4M24 36v7m-3-20 5-8-1 7h5l-8 10 2-9z"/>',
  'الجوالات':'<rect x="13" y="5" width="22" height="38" rx="5"/><path d="M20 10h8"/><circle cx="24" cy="37" r="1.5"/>',
  'الملابس الرجالية':'<path d="m15 7 9 4 9-4 9 11-7 7-4-4v22H17V21l-4 4-7-7 9-11z"/><path d="m21 10 3 6 3-6"/>',
  'الملابس النسائية':'<path d="M17 5h14l-3 12 11 24H9l11-24-3-12z"/><path d="M17 18h14m-9-12 2 5 2-5"/>',
  'الإكسسوارات':'<rect x="9" y="17" width="30" height="25" rx="6"/><path d="M17 17v-4c0-10 14-10 14 0v4M9 26h30"/><circle cx="24" cy="32" r="2"/>',
  'إلكترونيات وإكسسوارات':'<rect x="9" y="12" width="30" height="27" rx="5"/><path d="M24 12V6m-7 6V8m14 4V8M9 25h30"/>',
  'المنزل والمكتب':'<path d="M4 24 24 7l20 17M11 22v21h26V22M20 43V30h8v13"/>',
  'ساعات رجالي - نسائي':'<circle cx="24" cy="24" r="13"/><path d="M24 15v10l7 5M19 4h10M19 44h10"/>'
 };
 const shape=shapes[category];if(!shape)return '<span class="cat-fallback">✦</span>';
 return '<span class="cat-svg-wrap"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="64" height="64" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true">'+shape+'</svg></span>';
}
// Source and review metadata remain available to administrators, but are not shown to shoppers.
function customerDescription(p){
  const description=String(p?.description||'').trim();
  if(p?.demo_product && p?.source_url && /^(?:منتج كما يرد اسمه في موقع|المنتج الأصلي كما يرد اسمه في موقع|منتج من متجر)/.test(description))return '';
  return description;
}
function home(){
const active=state.products.filter(p=>p.active!==false);
const picked=active.filter(p=>p.featured);
const featured=[...picked,...active.filter(p=>!p.featured)].slice(0,8);
const star=featured[0];
const categoryNames=categories().slice(1);
const nonEmptyCategories=new Set(active.map(p=>p.category));
const categorySymbols={'إلكترونيات وإكسسوارات':'⌘','ساعات رجالي - نسائي':'⌚','إلكترونيات':'⌘','أزياء وإكسسوارات':'✧','عطور وجمال':'✿','المنزل والمكتب':'⌂','رياضة':'◌','أطفال':'✳'};
const city=(state.settings.allowed_cities||[]).length===1?state.settings.allowed_cities[0]:'المدن المتاحة';
const card=star?`<a class="hero-showcase" href="#/product/${encodeURIComponent(star.id)}" aria-label="اكتشف ${esc(star.name)}"><div class="showcase-top"><span class="showcase-collection">من اختيارات مدار</span><span class="showcase-star">✦</span></div><div class="showcase-image"><span class="showcase-fallback" aria-hidden="true">✦</span>${star.image_url?`<img src="${esc(star.image_url)}" alt="${esc(star.name)}" onerror="this.style.display='none'"/>`:`<span class="showcase-fallback">✦</span>`}</div><div class="showcase-caption"><div><span class="tiny">منتج مميز</span><strong>${esc(star.name)}</strong></div><span class="showcase-price">${money(star.price)}</span></div></a>`:`<div class="hero-showcase hero-showcase-empty"><div class="showcase-fallback">✦</div><span>اكتشف مجموعتنا قريباً</span></div>`;
return layout(`
<section class="hero" aria-label="أهلاً بك في مدار ستور">
  <div class="hero-visitor-badge" aria-label="مؤشر زوار المتجر">
    ${brandMark()}
    <div class="hero-visitor-info"><span class="hero-visitor-title">مؤشر زوار المتجر</span><strong data-visitor-display>${formatVisits(state.visitorData.display_count)}</strong></div>
    <span class="hero-visitor-tag">رقم عرض</span>
  </div>
  <div class="hero-content"><div class="hero-kicker"><span class="kicker-line"></span> تجربة تسوق تستحق الاكتشاف</div>
   <h1>كل شيء أجمل <span class="hero-head-accent">مع مدار.</span></h1>
   <p>${esc(state.settings.hero_subtitle||'تسوق بسهولة، واختر ما يناسبك من منتجاتنا المتاحة.')}</p>
   <div class="hero-actions"><a class="btn btn-gold" href="#/products">اكتشف المنتجات <span aria-hidden="true">←</span></a><a class="hero-track-link" href="#/track">تتبع طلبك <span aria-hidden="true">↗</span></a></div>
   <div class="hero-micro"><span>✳ الدفع عند الاستلام</span><span>✳ طلب بدون حساب</span><span>✳ دعم وتوصيل داخل الرياض</span></div>
  </div>
  <div class="hero-art"><div class="hero-glow"></div><div class="hero-orbit orbit-one"></div><div class="hero-orbit orbit-two"></div>${card}<div class="hero-float hero-float-top static-chip"><span class="float-icon">✦</span> تسوق بثقة وراحة</div><div class="hero-float hero-float-bottom static-chip"><span class="float-icon">⌂</span> التوصيل داخل ${esc(city)}</div></div>
</section>
<section class="benefits" aria-label="مميزات المتجر">
 <div class="benefit"><div class="benefit-icon">⌂</div><div><strong>توصيل داخل ${esc(city)}</strong><small>${esc(state.settings.delivery_estimate||'تعرّف على موعد التوصيل عند الطلب')}</small></div></div>
 <div class="benefit"><div class="benefit-icon">▢</div><div><strong>الدفع عند الاستلام</strong><small>اطلب الآن وادفع عند وصول الطلب</small></div></div>
 <div class="benefit"><div class="benefit-icon">✦</div><div><strong>منتجات في مكان واحد</strong><small>تجربة تصفح منظمة وسهلة</small></div></div>
 <div class="benefit"><div class="benefit-icon">↗</div><div><strong>تابع حالة طلبك</strong><small>باستخدام رقم الطلب والبريد</small></div></div>
</section>
<section class="category-section" aria-label="تسوق حسب الفئة"><div class="section-head"><div><div class="eyebrow">اكتشف عالم مدار</div><h2>تسوق حسب القسم</h2><p>كل ما تبحث عنه في خطوات بسيطة</p></div><a class="text-link" href="#/products">تصفح جميع المنتجات <span>←</span></a></div>
<div class="category-gallery">${categoryNames.map((c,i)=>`<a class="category-tile tile-${i%5}${nonEmptyCategories.has(c)?'':' category-is-empty'}" href="#/products?category=${encodeURIComponent(c)}" aria-label="${esc(c)}${nonEmptyCategories.has(c)?'':' — قسم فارغ حالياً'}"><span class="category-tile-art">${sectionIcon(c)}</span><span class="category-tile-caption"><strong>${esc(c)}</strong><span>${nonEmptyCategories.has(c)?'تصفح القسم ←':'لا توجد منتجات حالياً'}</span></span></a>`).join('')}<a class="category-tile category-all" href="#/products"><span class="category-tile-art">↗</span><span class="category-tile-caption"><strong>جميع المنتجات</strong><span>اكتشف المزيد ←</span></span></a></div>
</section>
${offersHomeSection(active)}
<section class="featured-section" aria-label="المنتجات المتاحة"><div class="section-head"><div><div class="eyebrow">مختارة من مدار</div><h2>منتجات تستحق اهتمامك <span class="product-section-star">✳</span></h2><p>استكشف أحدث المنتجات المتوفرة في المتجر</p></div><a class="btn btn-outline btn-sm" href="#/products">مشاهدة الجميع ←</a></div>
<div class="product-grid">${featured.map(productCard).join('')||'<div class="empty box" style="grid-column:1/-1">ستظهر منتجاتك هنا بعد إضافتها من لوحة التحكم.</div>'}</div>
</section>
<section class="steps-panel"><div class="steps-copy"><div class="eyebrow">تسوق بكل سهولة</div><h2>طلبك في ثلاث خطوات</h2><p>بدون حساب وبدون إجراءات معقدة.</p></div><div class="steps-flow"><div><span class="step-num">01</span><strong>اختر منتجاتك</strong><small>أضف ما يعجبك إلى السلة</small></div><div><span class="step-num">02</span><strong>حدّد عنوانك</strong><small>أكمل بيانات التوصيل داخل الرياض</small></div><div><span class="step-num">03</span><strong>تابع طلبك</strong><small>استعلم عن حالة الطلب بسهولة</small></div></div></section>
<section class="promo"><div><div class="eyebrow">كل ما تحتاجه، أقرب إليك</div><strong>جاهز تختار طلبك القادم؟</strong><p class="muted fine" style="margin:7px 0 0">ابدأ التصفح الآن واستمتع بتجربة تسوق بسيطة وواضحة.</p></div><a class="btn" href="#/products">ابدأ التسوق ←</a></section>
`)}
function offersHomeSection(activeProducts){
 const deals=activeProducts.filter(isOffer).slice(0,4);
 return `<section class="offers-home" aria-label="العروض والتخفيضات">
  <div class="offers-home-heading"><div><div class="eyebrow">خصومات واختيارات مميزة</div><h2>✦ العروض والتخفيضات</h2><p>تصفح المنتجات التي اختيرت للعروض، مع أسعار قبل وبعد الخصم</p></div><a class="btn btn-outline btn-sm" href="#/offers">جميع العروض ←</a></div>
  ${deals.length?`<div class="product-grid">${deals.map(productCard).join('')}</div>`:'<div class="offers-empty-small">✦ ترقب عروضاً جديدة قريباً</div>'}
 </section>`;
}
function offersPage(){
 const deals=state.products.filter(p=>p.active!==false&&isOffer(p));
 return layout(`<div class="crumb"><a href="#/">الرئيسية</a> / العروض والتخفيضات</div>
  <section class="offers-page-head"><span class="offers-page-icon" aria-hidden="true">%</span><div><span class="eyebrow">تخفيضات مدار ستور</span><h1>العروض والتخفيضات</h1></div><span class="offers-count">${deals.length} عرض</span></section>
  ${deals.length?`<div class="product-grid">${deals.map(productCard).join('')}</div>`:`<div class="empty box"><div class="em">🏷️</div><h2>لا توجد عروض حالياً</h2><p>يمكن لصاحب المتجر إضافة العروض من لوحة الإدارة.</p><a class="btn" href="#/products">استكشف المنتجات</a></div>`}`);
}
function productsPage(){const qs=new URLSearchParams((route().split('?')[1]||''));const activeCat=qs.get('category')||state.filter;const list=state.products.filter(p=>p.active!==false&&(activeCat==='الكل'||p.category===activeCat)&&(!state.search||`${p.name} ${p.description} ${p.category}`.toLowerCase().includes(state.search.toLowerCase())));if(state.sort==='low')list.sort((a,b)=>a.price-b.price);if(state.sort==='high')list.sort((a,b)=>b.price-a.price);return layout(`<div class="crumb"><a href="#/">الرئيسية</a> / المنتجات</div><div class="section-head"><div><div class="eyebrow">تشكيلتنا المتنوعة</div><h2>جميع المنتجات</h2><p>عدد المنتجات المتاحة: ${list.length}</p></div><select id="sort-products" style="border:1px solid var(--line);background:white;border-radius:10px;padding:12px;color:var(--ink)"><option value="featured" ${state.sort==='featured'?'selected':''}>الترتيب الافتراضي</option><option value="low" ${state.sort==='low'?'selected':''}>السعر: الأقل أولاً</option><option value="high" ${state.sort==='high'?'selected':''}>السعر: الأعلى أولاً</option></select></div><div class="category-row">${categories().map(c=>`<a href="#/products?category=${encodeURIComponent(c)}" class="category ${activeCat===c?'active':''}">${esc(c)}</a>`).join('')}</div>${list.length?`<div class="product-grid">${list.map(productCard).join('')}</div>`:`<div class="empty"><div class="em">${activeCat!=='الكل'&&!state.search?'📦':'🔎'}</div><h3>${activeCat!=='الكل'&&!state.search?'لا توجد منتجات في هذا القسم حالياً':'لا توجد منتجات مطابقة'}</h3><p>${activeCat!=='الكل'&&!state.search?'قسم '+esc(activeCat)+' فارغ الآن. ستظهر المنتجات هنا عند إضافتها إلى هذا القسم.':'جرّب البحث باسم آخر أو اختر قسماً مختلفاً'}</p><a href="#/products?category=${encodeURIComponent('الكل')}" class="btn">عرض جميع المنتجات</a></div>`}`)}
function productGallery(p){
  const images=galleryImages(p),n=images.length;
  if(!n)return `<div class="detail-media gallery-empty"><span style="font-size:80px">${esc(p.emoji||'📦')}</span></div>`;
  const i=Math.min(state.detailImageIndex,n-1);
  return `<div class="detail-gallery" aria-label="صور ${esc(p.name)}">
  <div class="detail-media gallery-stage" id="product-gallery-stage">
    <button type="button" class="gallery-zoom" data-action="gallery-zoom" data-id="${esc(p.id)}" aria-label="تكبير صورة المنتج">⌕</button>
    <img id="gallery-main" src="${esc(images[i])}" alt="${esc(p.name)} - الصورة ${i+1}" loading="eager" onerror="this.style.opacity='.1'"/>
    ${n>1?`<button type="button" class="gallery-arrow arrow-prev" data-action="gallery-step" data-step="-1" aria-label="الصورة السابقة">❮</button><button type="button" class="gallery-arrow arrow-next" data-action="gallery-step" data-step="1" aria-label="الصورة التالية">❯</button><span class="gallery-counter" id="gallery-counter">${i+1} / ${n}</span>`:''}
  </div>${n>1?`<div class="gallery-thumbnails" aria-label="اختيار صورة المنتج">${images.map((url,j)=>`<button type="button" class="gallery-thumb ${j===i?'active':''}" data-action="gallery-select" data-index="${j}" aria-label="عرض الصورة ${j+1}"><img src="${esc(url)}" alt="" loading="lazy"/></button>`).join('')}</div>`:''}
  </div>`
}
function setGalleryImage(next,p=getProduct(route().split('/')[1])){
 const images=galleryImages(p);if(!images.length)return;
 state.detailImageIndex=(next+images.length)%images.length;
 const im=$('#gallery-main');if(im){im.src=images[state.detailImageIndex];im.alt=p.name+' - الصورة '+(state.detailImageIndex+1)}
 const counter=$('#gallery-counter');if(counter)counter.textContent=(state.detailImageIndex+1)+' / '+images.length;
 document.querySelectorAll('.gallery-thumb').forEach((x,i)=>{x.classList.toggle('active',i===state.detailImageIndex);x.setAttribute('aria-pressed',String(i===state.detailImageIndex))});
 const big=document.querySelector('#lightbox-main');if(big)big.src=images[state.detailImageIndex];
 const bcounter=document.querySelector('#lightbox-counter');if(bcounter)bcounter.textContent=(state.detailImageIndex+1)+' / '+images.length;
}
function zoomGallery(p){const images=galleryImages(p);if(!images.length)return;
 modal(`<div class="photo-lightbox" role="group" aria-label="تكبير صور المنتج"><div class="photo-lightbox-bar"><strong>${esc(p.name)}</strong><span id="lightbox-counter">${state.detailImageIndex+1} / ${images.length}</span><button type="button" class="lightbox-close" data-action="close-modal" aria-label="إغلاق">×</button></div><div class="photo-lightbox-stage"><button type="button" class="lightbox-nav" data-action="lightbox-step" data-step="-1" aria-label="السابق">❮</button><img id="lightbox-main" src="${esc(images[state.detailImageIndex])}" alt="${esc(p.name)}"/><button type="button" class="lightbox-nav" data-action="lightbox-step" data-step="1" aria-label="التالي">❯</button></div></div>`,true);
 $('#modal-holder').addEventListener('click',e=>{const b=e.target.closest('[data-action="lightbox-step"]');if(b)setGalleryImage(state.detailImageIndex+Number(b.dataset.step),p)})
}
function detailPage(id){const p=getProduct(id);if(!p||p.active===false)return layout(`<div class="empty"><h2>المنتج غير موجود</h2><a href="#/products" class="btn">عودة للمنتجات</a></div>`);return layout(`<div class="crumb"><a href="#/">الرئيسية</a> / <a href="#/products">المنتجات</a> / ${esc(p.name)}</div><div class="product-detail">${productGallery(p)}<div class="detail-content"><span class="pill">${esc(p.category)}</span>${offerBadge(p)}<h1>${esc(p.name)}</h1><div class="row gap12"><span class="detail-price">${money(p.price)}</span>${p.compare_at>p.price?`<span class="old-price" style="font-size:18px">${money(p.compare_at)}</span>`:''}</div>${isOffer(p)?`<p class="offer-savings">${p.demo_product?'سعر ترويجي توضيحي · ':''}توفير ${money(Number(p.compare_at)-Number(p.price))} (${offerPercent(p)}%)</p>`:''}${p.demo_product?'':`<p class="muted tiny" style="margin-top:7px">${p.stock>0?`✓ متوفر حالياً (${p.stock} قطعة)`:'غير متوفر حالياً'}</p>`}<div class="share-product-panel"><span>هل أعجبك المنتج؟ شاركه مع من تحب</span><div class="share-product-actions"><button type="button" class="btn btn-outline btn-sm" data-action="share-product" data-id="${esc(p.id)}">↗ مشاركة المنتج</button><button type="button" class="btn btn-light btn-sm" data-action="copy-product" data-id="${esc(p.id)}">⎘ نسخ الرابط</button></div></div><div class="divider" style="margin:25px 0"></div>${customerDescription(p)?`<h3 style="font-size:15px">وصف المنتج</h3><p class="description">${esc(customerDescription(p))}</p>`:''}<div class="row gap12 wrap" style="margin:35px 0"><div class="qty"><button data-action="detail-qty" data-delta="-1">−</button><span id="detail-qty-number">${state.qtyDetail}</span><button data-action="detail-qty" data-delta="1">＋</button></div><button class="btn" data-action="detail-add" data-id="${esc(p.id)}" ${p.stock<=0||p.demo_product?'disabled':''}>${p.demo_product?'للعرض فقط — غير متاح للشراء':'🛒 إضافة إلى السلة'}</button><a href="#/cart" class="btn btn-outline">مشاهدة السلة</a></div><div class="notice">🔒 يمكنك إتمام طلبك دون تسجيل حساب. الدفع عند الاستلام، والتوصيل وفق المدن المتاحة.</div></div></div>`)}
function itemRows(){const list=cartItems();return list.map(({product:p,qty})=>`<div class="cart-line">${p.image_url?`<img src="${esc(p.image_url)}" alt="${esc(p.name)}"/>`:`<div class="img-fallback">${esc(p.emoji||'📦')}</div>`}<div style="flex:1;min-width:0"><a href="#/product/${encodeURIComponent(p.id)}"><h3>${esc(p.name)}</h3></a><div class="muted tiny">${esc(p.category)}</div><div class="price" style="font-size:15px">${money(p.price)}</div><button class="trash" data-action="remove" data-id="${esc(p.id)}">حذف المنتج</button></div><div class="qty"><button data-action="cart-minus" data-id="${esc(p.id)}">−</button><span>${qty}</span><button data-action="cart-plus" data-id="${esc(p.id)}">＋</button></div></div>`).join('')}
function bill(checkout=false){const n=cartItems().length;return `<div class="box" style="position:sticky;top:100px"><h3>ملخص الطلب</h3><div class="summary-row"><span>المنتجات (${cartCount()})</span><strong>${money(subTotal())}</strong></div><div class="summary-row"><span>التوصيل وفق المدن المتاحة</span><strong>${money(state.settings.delivery_fee)}</strong></div><div class="summary-row total"><span>الإجمالي</span><span>${money(subTotal()+Number(state.settings.delivery_fee))}</span></div>${checkout?'<div class="notice">🔒 يُحسب السعر النهائي من قاعدة بيانات المتجر عند تأكيد الطلب.</div>':`<a href="#/checkout" class="btn btn-block" ${n?'':'style="pointer-events:none;opacity:.5"'}>إتمام الطلب ←</a>`}<div class="muted tiny" style="text-align:center;margin-top:13px">💳 الدفع عند الاستلام</div></div>`}
function cartPage(){const list=cartItems();return layout(`<div class="crumb"><a href="#/">الرئيسية</a> / سلة المشتريات</div><h1 class="page-title">سلة المشتريات <span class="muted fine">(${cartCount()} منتجات)</span></h1>${list.length?`<div class="cart-grid"><div class="box"><div class="row between"><h3>المنتجات المختارة</h3><button class="ghost tiny" data-action="clear-cart">إفراغ السلة</button></div>${itemRows()}</div>${bill()}</div>`:`<div class="empty box"><div class="em">🛒</div><h2>سلتك فارغة</h2><p>ابدأ باختيار المنتجات التي تعجبك</p><a href="#/products" class="btn">تسوق الآن</a></div>`}`)}
function checkoutPage(){if(backendReady&&!state.settings.orders_enabled)return layout(`<div class="box empty" style="max-width:680px;margin:60px auto"><div class="em">🛍️</div><h2>المتجر قيد التجهيز</h2><p>سيتم تفعيل إرسال الطلبات بعد اعتماد التوصيل والسياسات والمنتجات الحقيقية.</p><a class="btn" href="#/products">العودة للمنتجات</a></div>`);if(!cartItems().length)return layout(`<div class="empty"><h2>لا توجد منتجات لإتمام طلبها</h2><a class="btn" href="#/products">العودة للمتجر</a></div>`);return layout(`<div class="crumb"><a href="#/">الرئيسية</a> / <a href="#/cart">السلة</a> / إتمام الطلب</div><h1 class="page-title">إتمام الطلب</h1><div class="steps"><span>① سلة المشتريات</span> / <span class="step-current">② معلومات التوصيل</span> / <span>③ تأكيد الطلب</span></div><div class="checkout-grid"><form id="checkout-form" class="box"><h3>📍 معلومات التواصل والتوصيل</h3><p class="muted fine">لا تحتاج إلى إنشاء حساب لإتمام طلبك.</p><div class="form-grid"><div class="field"><label for="customer-name">الاسم الكامل *</label><input name="customer_name" id="customer-name" maxlength="90" minlength="2" placeholder="الاسم الكامل" required autocomplete="name"/></div><div class="field"><label for="customer-email">البريد الإلكتروني * (لمتابعة حالة الطلب)</label><input type="email" name="customer_email" id="customer-email" maxlength="254" placeholder="example@email.com" required autocomplete="email" inputmode="email" dir="ltr"/></div><div class="field"><label for="customer-phone">رقم الجوال *</label><input name="phone" id="customer-phone" type="tel" inputmode="tel" maxlength="20" pattern="[+]?[0-9\\s-]{8,20}" placeholder="05xxxxxxxx" required autocomplete="tel"/></div><div class="field"><label for="customer-city">المدينة *</label><input name="city" id="customer-city" list="delivery-cities" maxlength="80" placeholder="الرياض" required autocomplete="address-level2"/></div><datalist id="delivery-cities">${(state.settings.allowed_cities||[]).map(c=>`<option value="${esc(c)}"></option>`).join('')}</datalist><div class="field"><label for="customer-district">الحي *</label><input name="district" id="customer-district" maxlength="90" placeholder="اسم الحي" required/></div></div><div class="field"><label for="customer-address">العنوان التفصيلي *</label><textarea name="address" id="customer-address" maxlength="500" required placeholder="اسم الشارع، المبنى، رقم الوحدة، علامة مميزة..." autocomplete="street-address"></textarea></div><div class="notice">🚚 مدة التوصيل المتوقعة: ${esc(state.settings.delivery_estimate||'حسب المدينة')} — المدن: ${esc((state.settings.allowed_cities||[]).join('، '))}</div><div class="row between wrap gap8"><strong style="font-size:14px">تحديد الموقع على الخريطة (اختياري)</strong><button type="button" data-action="geolocate" class="btn btn-sm btn-outline">📍 تحديد موقعي</button></div><div class="map" id="checkout-map"></div><div id="location-label" class="location-chip">انقر على الخريطة لوضع علامة التوصيل، أو استخدم زر تحديد موقعي.</div><div class="field" style="margin-top:19px"><label for="customer-notes">ملاحظات للطلب (اختياري)</label><textarea name="notes" id="customer-notes" maxlength="500" placeholder="وقت التسليم المناسب أو أي توضيحات إضافية..." style="min-height:80px"></textarea></div><div class="notice">🛡️ تُستخدم بياناتك لتنفيذ طلبك والتواصل معك. راجع <a href="#/policy" style="text-decoration:underline">السياسات</a> قبل تأكيد الطلب. الدفع عند الاستلام فقط.</div>${!backendReady?'<div class="notice warn">⚠️ هذه معاينة تجريبية؛ الطلب الذي ترسله هنا لن يصل إلى بريد صاحب المتجر ولن يُسجل في قاعدة بيانات حقيقية.</div>':''}<label style="display:block;margin:16px 0;font-size:13px"><input type="checkbox" name="accepted_policies" required/> أقر بأنني اطلعت على <a href="#/policy" target="_blank" rel="noopener" style="text-decoration:underline">سياسات التوصيل والاسترجاع والخصوصية</a>.</label><input type="text" name="website" tabindex="-1" autocomplete="off" class="form-honeypot" aria-hidden="true"/><button type="submit" class="btn btn-block" id="submit-order" ${backendReady&&!state.settings.orders_enabled?'disabled':''}>${backendReady&&!state.settings.orders_enabled?'الطلبات غير مفعّلة حالياً':backendReady?'تأكيد الطلب والدفع عند الاستلام':'تجربة تأكيد الطلب (معاينة فقط)'}</button></form>${bill(true)}</div>`)}
function successPage(){const result=getJ('madar_last_order',null);return layout(`<section class="box success-layout"><div class="success-icon">✅</div><h1>${backendReady?'تم استلام طلبك بنجاح':'تم إنشاء طلب تجريبي'}</h1><p class="muted">${backendReady?'شكراً لك! احتفظ برقم الطلب لتستطيع متابعة الشحن باستخدامه مع بريدك الإلكتروني.':'هذه تجربة للمتجر فقط؛ لم تُرسل بياناتك إلى بريد إلكتروني أو قاعدة بيانات خارجية.'}</p>${result?`<div class="notice" style="text-align:right"><strong>رقم الطلب: </strong>${esc(result.number)}<br/><strong>الإجمالي: </strong>${money(result.total)}</div>`:''}<div class="row gap12 wrap" style="justify-content:center"><a href="#/track" class="btn">📦 تتبع حالة الطلب</a><a href="#/" class="btn btn-outline">العودة إلى المتجر</a></div></section>`)}
function trackingPage(){return layout(`<div class="crumb"><a href="#/">الرئيسية</a> / تتبع الطلب</div><section class="box" style="max-width:720px;margin:22px auto 60px"><h1 class="page-title">📦 تتبع حالة طلبك</h1><p class="muted">لا تحتاج إلى حساب أو كلمة مرور. أدخل البريد الإلكتروني الذي استخدمته عند الطلب ورقم الطلب الظاهر في تأكيد الشراء. نطلب رقم الطلب أيضاً للحفاظ على خصوصيتك.</p><form id="tracking-form"><div class="field"><label for="tracking-email">البريد الإلكتروني</label><input type="email" name="email" id="tracking-email" required maxlength="254" autocomplete="email" placeholder="example@email.com" dir="ltr"/></div><div class="field"><label for="tracking-number">رقم الطلب</label><input type="text" name="number" id="tracking-number" required maxlength="40" placeholder="MDR-XXXXXXXXX" dir="ltr"/></div><button class="btn btn-block" type="submit" id="tracking-submit">عرض حالة الطلب</button></form><div id="tracking-result" role="status" aria-live="polite" style="margin-top:18px"></div><p class="muted tiny">إذا لم تجد الطلب، تأكد من البريد ورقم الطلب. للاستفسارات، تواصل مع متجرنا عبر البريد: ${esc(state.settings.contact_email||'')}</p></section>`)}
async function trackOrder(ev){ev.preventDefault();const holder=$('#tracking-result'),button=$('#tracking-submit');if(!holder||!button)return;const fd=new FormData(ev.target);const email=String(fd.get('email')||'').trim().toLowerCase(),number=String(fd.get('number')||'').trim().toUpperCase();button.disabled=true;holder.innerHTML='<div class="notice">جارٍ البحث عن طلبك...</div>';try{if(!backendReady)throw Error('خدمة التتبع تحتاج الاتصال بقاعدة بيانات المتجر');const {data,error}=await db.rpc('lookup_order_status',{p_customer_email:email,p_order_number:number});if(error)throw error;if(!data?.found){holder.innerHTML='<div class="notice warn">لم نعثر على طلب مطابق. تأكد من كتابة البريد ورقم الطلب بشكل صحيح.</div>';return}const names={new:'🛍️ تم استلام الطلب',processing:'📦 قيد التجهيز',shipped:'🚚 تم الشحن',delivered:'✅ تم التسليم',cancelled:'❌ تم إلغاء الطلب'};const title=names[data.status]||'حالة الطلب غير معروفة';const when=data.updated_at?new Date(data.updated_at).toLocaleString('ar-SA'):'—';holder.innerHTML=`<div class="notice" style="line-height:2"><strong>الطلب ${esc(data.order_number)}</strong><h2 style="font-size:22px;margin:9px 0">${esc(title)}</h2><p>آخر تحديث: ${esc(when)}</p>${data.status==='shipped'?'<p>تم تحويل طلبك إلى حالة الشحن. لمزيد من تفاصيل التوصيل تواصل مع المتجر.</p>':''}</div>`}catch(e){holder.innerHTML='<div class="notice warn">تعذّر التحقق من حالة الطلب حالياً. أعد المحاولة لاحقاً.</div>'}finally{button.disabled=false}}
function policyPage(){const x=state.settings;const section=(heading,body)=>`<h3>${heading}</h3><p style="white-space:pre-line">${esc(body||'لم تُعتمد هذه السياسة بعد. يرجى التواصل مع صاحب المتجر.')}</p>`;return layout(`<div class="crumb"><a href="#/">الرئيسية</a> / سياسات المتجر</div><div class="box" style="max-width:920px;margin:20px auto 50px"><h1 class="page-title">الشحن والاسترجاع والخصوصية</h1>${!x.orders_enabled?'<div class="notice warn">المتجر قيد التجهيز ولم يبدأ استقبال الطلبات بعد. السياسات الظاهرة لا تصبح نهائية حتى يعتمدها صاحب المتجر.</div>':''}${section('معلومات المتجر',[(x.merchant_name||x.name),x.merchant_address,x.merchant_registration?'رقم السجل: '+x.merchant_registration:'',x.merchant_tax_id?'الرقم الضريبي: '+x.merchant_tax_id:''].filter(Boolean).join(' — '))}${section('طرق التواصل',[(x.phone?'الجوال: '+x.phone:''),(x.contact_email?'البريد: '+x.contact_email:'')].filter(Boolean).join(' — '))}${section('نطاق التوصيل',((x.allowed_cities||[]).join('، ')||'لم يتم تحديده بعد'))}${section('المدة المتوقعة للتوصيل',x.delivery_estimate)}${section('سياسة الشحن',x.shipping_policy)}${section('الاستبدال والاسترجاع والاسترداد',x.returns_policy)}${section('الشكاوى والتواصل',x.complaints_policy)}<h3>خصوصية معلومات العميل</h3><p>نجمع الاسم والبريد الإلكتروني ورقم الاتصال والمدينة والحي والعنوان وتفاصيل الطلب لتنفيذه والتواصل بشأنه؛ والموقع الجغرافي اختياري. لا نطلب بيانات البطاقات لأن وسيلة الدفع الحالية عند الاستلام. تُخزّن بيانات الطلبات في قاعدة بيانات المتجر ولا تُعرض للعملاء الآخرين؛ وقد تُشارك بيانات التوصيل الضرورية مع مزود خدمة التوصيل عند الحاجة. للتواصل بشأن بياناتك أو طلب حذفها وفق الالتزامات النظامية، استخدم بريد التواصل المبين أعلاه.</p></div>`)}
function initMap(){const el=$('#checkout-map');if(!el)return;state.map=null;state.marker=null;if(!window.L){el.innerHTML='<div class="notice warn">الخريطة غير متاحة حالياً، يمكنك إكمال الطلب باستخدام العنوان المكتوب.</div>';return}try{const m=L.map(el,{scrollWheelZoom:false}).setView([24.7136,46.6753],10);state.map=m;L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap contributors',maxZoom:19}).addTo(m);m.on('click',(e)=>{setPin(e.latlng.lat,e.latlng.lng)});setTimeout(()=>m.invalidateSize(),150)}catch(e){el.innerHTML='يتعذر تحميل الخريطة الآن. يرجى كتابة العنوان يدوياً.'}}
function setPin(lat,lng){lat=Number(lat);lng=Number(lng);if(!Number.isFinite(lat)||!Number.isFinite(lng))return;state.location={lat,lng};if(state.map){if(state.marker)state.marker.setLatLng([lat,lng]);else state.marker=L.marker([lat,lng]).addTo(state.map);state.map.setView([lat,lng],15)}const el=$('#location-label');if(el)el.textContent=`✓ تم تحديد نقطة التوصيل: ${lat.toFixed(5)}، ${lng.toFixed(5)}`}
async function geolocate(){if(!navigator.geolocation){toast('المتصفح لا يدعم تحديد الموقع');return}toast('جارٍ طلب إذن الموقع من المتصفح...');navigator.geolocation.getCurrentPosition(p=>{setPin(p.coords.latitude,p.coords.longitude);toast('تم تحديد الموقع على الخريطة')},()=>toast('تعذّر تحديد الموقع. يمكنك اختيار نقطة على الخريطة أو كتابة العنوان.'),{enableHighAccuracy:false,timeout:10000,maximumAge:60000})}
async function submitOrder(ev){ev.preventDefault();const form=ev.target;if(form.website.value)return;const btn=$('#submit-order');btn.disabled=true;btn.textContent='جاري حفظ الطلب...';const fd=new FormData(form);const dto={customer_name:String(fd.get('customer_name')||'').trim(),customer_email:String(fd.get('customer_email')||'').trim().toLowerCase(),phone:String(fd.get('phone')||'').trim(),city:String(fd.get('city')||'').trim(),district:String(fd.get('district')||'').trim(),address:String(fd.get('address')||'').trim(),notes:String(fd.get('notes')||'').trim(),latitude:state.location?.lat??null,longitude:state.location?.lng??null};try{if(backendReady&&!state.settings.orders_enabled)throw Error('المتجر قيد التجهيز ولا يستقبل طلبات بعد');if(!fd.has('accepted_policies'))throw Error('يرجى الموافقة على سياسات المتجر');if(dto.customer_name.length<2||!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(dto.customer_email)||dto.customer_email.length>254||dto.phone.replace(/\D/g,'').length<8||!dto.city||!dto.district||dto.address.length<5)throw Error('يرجى استكمال الاسم ورقم التواصل والعنوان بشكل صحيح');const cart=cartItems().map(x=>({id:x.product.id,qty:x.qty}));if(!cart.length)throw Error('السلة فارغة');let order;if(backendReady){const {data,error}=await db.rpc('place_order_with_email',{p_cart:cart,p_customer_name:dto.customer_name,p_customer_email:dto.customer_email,p_phone:dto.phone,p_city:dto.city,p_district:dto.district,p_address:dto.address,p_notes:dto.notes,p_latitude:dto.latitude,p_longitude:dto.longitude});if(error)throw error;order={number:data?.order_number||data?.number||data?.id?.slice(0,8),total:data?.total??subTotal()+Number(state.settings.delivery_fee)}}else{if(!cfg.allowDemoCheckout)throw Error('الدفع التجريبي غير مفعّل');order={number:'DEMO-'+Date.now().toString().slice(-7),total:subTotal()+Number(state.settings.delivery_fee),id:'demo-'+Date.now(),status:'new',created_at:new Date().toISOString(),...dto,items:cartItems().map(x=>({product_name:x.product.name,qty:x.qty,unit_price:x.product.price,line_total:x.qty*x.product.price}))};state.orders.unshift(order);setJ(DEMO_O_KEY,state.orders)}setJ('madar_last_order',order);state.cart=[];cartStore();state.location=null;location.hash='#/success';render()}catch(e){toast('لم يتم إتمام الطلب: '+friendlyError(e));btn.disabled=false;btn.textContent=backendReady?'تأكيد الطلب والدفع عند الاستلام':'تجربة تأكيد الطلب (معاينة فقط)'}}
function friendlyError(e){const s=String(e.message||e);if(/CITY_NOT_SUPPORTED/.test(s))return 'هذه المدينة غير مشمولة بالتوصيل، يرجى اختيار مدينة من القائمة';if(/STORE_NOT_OPEN|STORE_SETUP_INCOMPLETE/.test(s))return 'المتجر قيد التجهيز حالياً';if(/product|stock|الكمية|غير متوفر|quantity|sold out/i.test(s))return 'تأكد من توفر المنتجات والكمية ثم أعد المحاولة';return s.slice(0,160)}
async function loadAdmin(){if(!backendReady){state.adminReady=true;state.orders=getJ(DEMO_O_KEY,[]);state.products=getJ(DEMO_P_KEY,demoProducts);return true}const {data:{session}}=await db.auth.getSession();if(!session?.user){state.adminReady=false;return false}const {data,error}=await db.from('admin_users').select('user_id').eq('user_id',session.user.id).maybeSingle();if(error||!data){state.adminReady=false;return false}state.adminUser=session.user;state.adminReady=true;const [p,o,s,sectionList]=await Promise.all([db.from('products').select('*').order('created_at',{ascending:false}),db.from('orders').select('*,order_items(*)').order('created_at',{ascending:false}).limit(500),db.from('store_settings').select('*').eq('id',1).maybeSingle(),db.from('madar_store_categories').select('name').order('display_order',{ascending:true}).order('created_at',{ascending:true})]);if(p.error||o.error)throw p.error||o.error;state.products=p.data||[];state.storeCategories=mergeSections(sectionList.error?state.storeCategories:(sectionList.data||[]).map(c=>c.name),state.products);state.orders=o.data||[];if(s.data)state.settings={...state.settings,...s.data};return true}
function adminShell(content){const tabs=[['overview','◫','نظرة عامة'],['products','▦','المنتجات'],['offers','🏷','العروض والتخفيضات'],['orders','🛍','الطلبات'],['usage','▥','استهلاك الاستضافة'],['settings','⚙','الإعدادات']];return `<div class="admin-shell"><aside class="admin-side"><a href="#/" class="logo">${brandMark()}<div><h2>${esc(state.settings.name)}</h2><small>لوحة الإدارة</small></div></a><nav class="admin-menu">${tabs.map(t=>`<button class="${state.adminTab===t[0]?'active':''}" data-action="admin-tab" data-tab="${t[0]}">${t[1]} &nbsp; ${t[2]}</button>`).join('')}<button data-action="admin-logout">↩ &nbsp; ${backendReady?'تسجيل الخروج':'العودة للمتجر'}</button></nav></aside><main class="admin-main"><div class="admin-top"><div><div class="eyebrow">إدارة متجرك من مكان واحد</div><h1>${tabs.find(t=>t[0]===state.adminTab)?.[2]||'الإدارة'}</h1></div><div class="row gap12 wrap"><span class="pill">${backendReady?(state.settings.orders_enabled?'🟢 الطلبات مفعّلة':'🟠 قيد التجهيز'):'🟠 وضع المعاينة'}</span><a class="btn btn-outline btn-sm" href="#/">مشاهدة المتجر ↗</a></div></div>${!backendReady?'<div class="notice warn">لوحة تجريبية: التعديلات والطلبات محفوظة داخل هذا المتصفح فقط. لحماية الإدارة ومزامنة الطلبات الفعلية، يجب ربط Supabase أولاً.</div>':''}${content}</main></div>`}
function adminLogin(){return layout(`<div class="login-view"><div class="login-card"><div class="logo">${brandMark()}<div><h2>${esc(state.settings.name)}</h2><small>دخول صاحب المتجر</small></div></div><h2 style="text-align:center">لوحة تحكم المتجر</h2>${!backendReady?'<div class="notice warn">هذه معاينة؛ لا توجد كلمة مرور حتى يتم إعداد الإدارة الحقيقية.</div>':''}<form id="login-form">${backendReady?`<div class="field"><label>البريد الإلكتروني للمدير</label><input type="email" name="email" autocomplete="username" required/></div><div class="field"><label>كلمة المرور</label><input type="password" name="password" autocomplete="current-password" required/></div>`:''}<button class="btn btn-block" type="submit">${backendReady?'تسجيل الدخول':'الدخول إلى المعاينة'}</button></form>${backendReady?`<details style="margin-top:22px"><summary style="color:var(--pine);font-weight:800;cursor:pointer">إعداد حساب المدير للمرة الأولى</summary><form id="register-form" style="margin-top:15px"><div class="notice warn">يجب استخدام البريد المعتمد لإدارة المتجر. لا تشارك كلمة المرور معنا أو مع أي شخص.</div><div class="field"><label>البريد الإلكتروني المعتمد</label><input type="email" name="email" autocomplete="email" required/></div><div class="field"><label>إنشاء كلمة مرور قوية</label><input type="password" name="password" minlength="12" autocomplete="new-password" required/></div><button class="btn btn-block btn-outline" type="submit">إنشاء الحساب وإرسال رسالة التحقق</button></form><p class="muted tiny" style="margin-top:8px">إذا لم تصلك رسالة التحقق، راجع إعداد إرسال رسائل Supabase قبل تكرار المحاولة.</p></details>`:''}<p class="muted tiny" style="text-align:center;margin-top:13px">هذه الصفحة لصاحب المتجر فقط، ولا يحتاج العملاء إلى حساب.</p></div></div>`)}
let usageData=null;
let usageInFlight=false;
let usageError=false;
let usageFetchedAt=0;
const usageFmt=(bytes)=>{
 const n=Number(bytes);
 if(!Number.isFinite(n)||n<0)return '—';
 if(n>=1024*1024*1024)return new Intl.NumberFormat('ar-SA',{maximumFractionDigits:2}).format(n/(1024**3))+' GB';
 if(n>=1024*1024)return new Intl.NumberFormat('ar-SA',{maximumFractionDigits:1}).format(n/(1024**2))+' MB';
 if(n>=1024)return new Intl.NumberFormat('ar-SA',{maximumFractionDigits:0}).format(n/1024)+' KB';
 return new Intl.NumberFormat('ar-SA').format(n)+' B';
};
function usagePercent(value,limit){
 const ratio=100*Number(value||0)/Math.max(Number(limit||1),1);
 if(!Number.isFinite(ratio))return '—';
 if(ratio>0&&ratio<0.1)return 'أقل من 0.1%';
 return new Intl.NumberFormat('ar-SA',{maximumFractionDigits:1}).format(ratio)+'%';
}
function usageMeter(label,bytes,limit,symbol){
 const ratio=100*Math.max(0,Number(bytes)||0)/Math.max(1,Number(limit)||1);
 const bar=Math.min(100,Math.max(ratio>0?0.3:0,ratio));
 const barColor=ratio>=90?'critical':ratio>=75?'warning':'ok';
 return `<div class="storage-meter">
   <div class="storage-meter-heading"><div class="storage-meter-label"><span class="storage-meter-symbol" aria-hidden="true">${symbol}</span><strong>${esc(label)}</strong></div><span class="storage-percent ${barColor}">${esc(usagePercent(bytes,limit))}</span></div>
   <div class="storage-meter-values"><strong dir="ltr">${esc(usageFmt(bytes))}</strong><span>من <bdi dir="ltr">${esc(usageFmt(limit))}</bdi></span></div>
   <div class="storage-track" role="progressbar" aria-label="${esc(label)}" aria-valuenow="${Math.max(0,Math.min(100,Math.round(ratio*10)/10))}" aria-valuemin="0" aria-valuemax="100"><span class="storage-fill ${barColor}" style="width:${bar}%"></span></div>
 </div>`;
}
function usageContent(){
 if(!backendReady)return '<div class="usage-state">هذه معاينة محلية، وتظهر المقاييس الفعلية بعد تسجيل دخول المدير إلى المتجر المتصل بقاعدة البيانات.</div>';
 if(usageError)return '<div class="usage-state usage-error">تعذّر جلب الاستهلاك من Supabase الآن. تأكد من الاتصال واضغط «تحديث الآن» لإعادة المحاولة.</div>';
 if(!usageData)return '<div class="usage-state"><span class="usage-loader" aria-hidden="true"></span> جاري قراءة الاستخدام الفعلي من Supabase...</div>';
 const now=usageData.measured_at?new Date(usageData.measured_at).toLocaleString('ar-SA',{dateStyle:'short',timeStyle:'short'}):'—';
 return `${usageMeter('قاعدة البيانات',usageData.db_bytes,usageData.db_limit_bytes,'▤')}
  <div class="storage-divider"></div>
  ${usageMeter('مساحة صور المنتجات',usageData.storage_bytes,usageData.storage_limit_bytes,'▧')}
  <div class="usage-bottom"><span>آخر قراءة: <bdi dir="ltr">${esc(now)}</bdi> · الصور المحفوظة: ${esc(usageData.file_count??'—')}</span><span>القراءة خاصة بقاعدة البيانات والملفات، ولا تشمل عدد الزيارات أو نقل البيانات.</span></div>`;
}
function usageSection(){return `<section class="usage-dashboard" aria-labelledby="usage-title">
  <div class="usage-dashboard-top"><div><span class="usage-overline">SUPABASE • FREE PLAN</span><h2 id="usage-title">الاستهلاك الفعلي الآن</h2><p>مراقبة سعة قاعدة البيانات ومساحة صور المتجر</p></div>
  <button type="button" class="usage-refresh" data-action="usage-refresh" ${usageInFlight?'disabled':''} aria-label="تحديث الاستهلاك الآن"><span aria-hidden="true">↻</span> تحديث الآن</button></div>
  <div id="usage-panel-content" class="usage-dashboard-body" aria-live="polite">${usageContent()}</div>
 </section>`}
function paintUsage(){const el=document.getElementById('usage-panel-content');if(!el)return;el.innerHTML=usageContent();const btn=document.querySelector('[data-action="usage-refresh"]');if(btn)btn.disabled=usageInFlight;}
async function refreshUsage(force=false){
 if(!backendReady||!state.adminReady||usageInFlight)return;
 if(!force&&usageData&&Date.now()-usageFetchedAt<90000){paintUsage();return;}
 usageInFlight=true;usageError=false;paintUsage();
 try{
   const {data,error}=await db.rpc('get_madar_usage_stats');
   if(error||!data||!Number.isFinite(Number(data.db_bytes)))throw error||Error('bad_usage_response');
   usageData=data;usageFetchedAt=Date.now();usageError=false;
 }catch(e){usageError=true;console.warn('تعذر تحميل الاستهلاك:',e?.message||e)}
 finally{usageInFlight=false;paintUsage();}
}
function overview(){const orders=state.orders,valid=orders.filter(o=>o.status!=='cancelled'),revenue=valid.filter(o=>o.status==='delivered').reduce((s,o)=>s+Number(o.total||0),0);const low=state.products.filter(p=>Number(p.stock)<=5).length;return `<section class="stat-grid"><div class="stat"><small>إجمالي الطلبات</small><strong>${orders.length}</strong><span class="muted tiny">جميع الطلبات</span></div><div class="stat"><small>الطلبات الجديدة</small><strong>${orders.filter(o=>o.status==='new').length}</strong><span class="muted tiny">تحتاج إلى معالجة</span></div><div class="stat"><small>مبيعات تم تسليمها</small><strong style="font-size:21px">${money(revenue)}</strong><span class="muted tiny">لا تشمل الطلبات غير المسلّمة</span></div><div class="stat"><small>المنتجات</small><strong>${state.products.length}</strong><span class="muted tiny">${low} منخفضة المخزون</span></div></section><section class="admin-visitor-panel" aria-labelledby="admin-visitor-title"><div><h3 id="admin-visitor-title">◉ متابعة الزوار</h3><p>عدّاد تقديري للمتصفحات الجديدة منذ بدء التسجيل، ولا يحدد الأشخاص عبر أجهزة مختلفة.</p></div><div class="admin-visitor-figures"><div><small>العدد الفعلي منذ التفعيل</small><strong data-visitor-real>${formatVisits(state.visitorData.real_unique_browsers)}</strong></div><div><small>رقم العرض (أساس 5,000)</small><strong data-visitor-display>${formatVisits(state.visitorData.display_count)}</strong></div></div></section>${usageSection()}<div class="box" style="margin-top:24px"><div class="row between gap12"><h3>آخر الطلبات</h3><button class="btn btn-light btn-sm" data-action="admin-tab" data-tab="orders">عرض جميع الطلبات</button></div>${ordersTable(orders.slice(0,6))}</div>`}
const statusNames={new:'جديد',processing:'قيد التجهيز',shipped:'تم الشحن',delivered:'تم التسليم',cancelled:'ملغى'};
function statusBadge(s){return `<span class="badge ${s==='new'?'orange':s==='delivered'?'green':s==='cancelled'?'red':''}">${statusNames[s]||esc(s)}</span>`}
function ordersTable(arr){if(!arr.length)return '<div class="empty">لا توجد طلبات بعد</div>';return `<div class="data-table-wrap"><table class="data-table"><thead><tr><th>الطلب</th><th>العميل</th><th>المدينة</th><th>الإجمالي</th><th>الحالة</th><th>التفاصيل</th></tr></thead><tbody>${arr.map(o=>`<tr><td><strong>#${esc(o.order_number||o.number||o.id?.slice(0,8))}</strong><br/><span class="muted tiny">${new Date(o.created_at).toLocaleDateString('ar-SA')}</span></td><td>${esc(o.customer_name)}<br/><span class="muted">${esc(o.phone)}</span>${o.customer_email?`<br/><span class="muted tiny">${esc(o.customer_email)}</span>`:''}</td><td>${esc(o.city)}</td><td>${money(o.total)}</td><td>${statusBadge(o.status)}</td><td><div class="order-row-actions"><button class="btn btn-light btn-sm" data-action="order-view" data-id="${esc(o.id)}">عرض</button>${o.status==='cancelled'?`<button type="button" class="btn btn-sm order-delete-btn" data-action="order-delete" data-id="${esc(o.id)}" aria-label="حذف الطلب الملغى ${esc(o.order_number||o.number||'')}">حذف</button>`:''}</div></td></tr>`).join('')}</tbody></table></div>`}
function adminProducts(){return `<div class="box"><div class="toolbar"><div><strong>إدارة المنتجات</strong><div class="muted tiny">أضف المنتجات، أو عدّلها أو احذفها نهائياً. حافظ على سجلات الطلبات قبل حذف منتجات حقيقية.</div></div><button class="btn btn-sm" data-action="product-new">＋ إضافة منتج</button></div><div class="bulk-products-toolbar"><div><strong>إدارة جميع المنتجات</strong><small>يمكن حذف كل المنتجات دفعة واحدة بعد تأكيد نهائي، بما فيها المنتجات المخفية والتجريبية.</small></div><button type="button" class="btn btn-sm bulk-products-delete-button" data-action="product-delete-all" ${state.products.length?'':'disabled'}>🗑 حذف جميع المنتجات (${state.products.length})</button></div><div class="admin-product-filters"><input id="admin-product-search" type="search" placeholder="ابحث عن منتج بالاسم أو القسم…" autocomplete="off" aria-label="بحث المنتجات"/><select id="admin-product-category" aria-label="تصفية المنتجات حسب القسم"><option value="">كل الأقسام</option>${categories().filter(c=>c!=='الكل').map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('')}</select><small id="admin-product-count" class="muted tiny">${state.products.length} منتج</small></div><div class="data-table-wrap"><table class="data-table"><thead><tr><th>المنتج</th><th>القسم</th><th>السعر</th><th>المخزون</th><th>الحالة</th><th>الإجراء</th></tr></thead><tbody>${state.products.map(p=>`<tr class="admin-product-row" data-category="${esc(p.category)}" data-search="${esc((p.name+' '+p.category).toLocaleLowerCase())}"><td><div class="product-small">${p.image_url?`<img src="${esc(p.image_url)}" alt="">`:`<div class="emoji">📦</div>`}<span style="max-width:250px;white-space:normal;font-weight:700">${esc(p.name)}</span></div></td><td>${esc(p.category)}</td><td>${money(p.price)}</td><td>${p.demo_product?'عرض فقط':p.stock}</td><td>${p.active===false?statusBadge('cancelled'):p.demo_product?'<span class="badge showcase-admin-demo">تجريبي</span>':'<span class="badge green">ظاهر</span>'}</td><td><button class="btn btn-sm btn-light" data-action="product-edit" data-id="${esc(p.id)}">تعديل</button> ${isOffer(p)?`<button class="btn btn-sm btn-light offer-mini" data-action="offer-edit" data-id="${esc(p.id)}">تعديل العرض</button>`:`<button class="btn btn-sm btn-light offer-mini" data-action="offer-add-single" data-id="${esc(p.id)}">إضافة للعرض</button>`} <button type="button" class="btn btn-sm btn-light" data-action="copy-product" data-id="${esc(p.id)}" title="نسخ رابط المنتج">⎘ رابط</button> <button type="button" class="btn btn-sm admin-product-delete" data-action="product-delete" data-id="${esc(p.id)}" title="حذف المنتج نهائياً">🗑 حذف</button></td></tr>`).join('')}</tbody></table></div>${state.products.length?'':'<div class="empty">أضف أول منتج لتبدأ البيع</div>'}</div>`}
function adminOffers(){
 const offers=state.products.filter(isOffer),available=state.products.filter(p=>!isOffer(p));
 return `<section class="admin-offers-intro"><div><div class="eyebrow">إدارة الحملات السعرية</div><h2>العروض والتخفيضات</h2><p>أضف منتجات موجودة إلى العروض، وعدّل سعر الخصم أو أزلها منه دون حذف المنتج. سعر العرض للمنتجات القابلة للشراء هو السعر الذي يحاسَب به العميل.</p></div><div class="admin-offers-count"><strong>${offers.length}</strong><span>عرض حالياً</span></div></section>
 <div class="offers-admin-actions"><button type="button" class="btn" data-action="offer-new">＋ إضافة منتج إلى العروض</button><button type="button" class="btn btn-outline" data-action="product-new">＋ إنشاء منتج جديد</button><a class="btn btn-light" href="#/offers">↗ معاينة قسم العروض</a></div>
 <div class="box admin-offers-list"><h3>المنتجات الموجودة في العروض</h3>${offers.length?`<div class="admin-offer-grid">${offers.map(p=>`<article class="admin-offer-item"><img src="${esc(p.image_url||'')}" alt="" loading="lazy" onerror="this.style.opacity='.15'"/><div class="admin-offer-data"><strong>${esc(p.name)}</strong><small class="muted">${esc(p.category)} ${p.demo_product?'· عرض تجريبي غير قابل للشراء':''}</small><div class="admin-offer-prices"><strong>${money(p.price)}</strong><del>${money(p.compare_at)}</del><span class="offer-mini-percent">-${offerPercent(p)}%</span></div><div class="admin-offer-buttons"><button type="button" class="btn btn-sm" data-action="offer-edit" data-id="${esc(p.id)}">تعديل الخصم</button><button type="button" class="btn btn-sm btn-light" data-action="product-edit" data-id="${esc(p.id)}">تعديل المنتج</button><button type="button" class="btn btn-sm admin-remove-offer" data-action="offer-remove" data-id="${esc(p.id)}">إزالة من العروض</button><button type="button" class="btn btn-sm admin-product-delete" data-action="product-delete" data-id="${esc(p.id)}">🗑 حذف المنتج</button></div></div></article>`).join('')}</div>`:'<div class="empty"><div class="em">🏷️</div><p>لم تضف أي منتجات إلى العروض بعد.</p></div>'}</div>
 <p class="muted tiny admin-offers-footnote">إزالة منتج من العروض تعيد سعره السابق تلقائياً، ولا تحذف المنتج أو الصور أو سجلات الطلبات. المنتجات المصنفة «للعرض فقط» تظل غير قابلة للشراء حتى أثناء التخفيض.</p>`;
}
function editOffer(p){
 if(!state.adminReady)return;
 const existing=isOffer(p);
 const available=state.products.filter(x=>!isOffer(x));
 if(!p&&!available.length){toast('كل المنتجات ضمن العروض. يمكنك إنشاء منتج جديد.');return;}
 const reg=existing?Number(p.compare_at):Number(p?.price||0);
 const sale=existing?Number(p.price):'';
 modal(`<div class="modal-head"><h2>${existing?'تعديل عرض المنتج':'إضافة منتج إلى العروض'}</h2><button type="button" class="close" data-action="close-modal">×</button></div>
 <form id="offer-form">
 ${p?`<div class="offer-selected-product"><strong>${esc(p.name)}</strong><small>${esc(p.category)}</small></div><input type="hidden" name="product_id" value="${esc(p.id)}"/>`:`<div class="field"><label for="offer-product-select">اختر المنتج من المتجر *</label><select required id="offer-product-select" name="product_id"><option value="">— اختر منتجاً —</option>${available.map(x=>`<option value="${esc(x.id)}" data-price="${Number(x.price)}">${esc(x.name)} · ${money(x.price)}${x.demo_product?' · عرض فقط':''}</option>`).join('')}</select></div>`}
 <div class="offer-form-prices"><div class="field"><label for="offer-regular-price">السعر الأساسي قبل الخصم (ر.س)</label><input id="offer-regular-price" name="regular_price" type="number" min="0.01" step="0.01" max="1000000" value="${reg||''}" ${!existing?'readonly':''} required/></div><div class="field"><label for="offer-discount-price">السعر بعد الخصم (ر.س) *</label><input id="offer-discount-price" name="discount_price" type="number" min="0.01" step="0.01" max="1000000" value="${sale}" placeholder="أقل من السعر الأصلي" required/></div></div>
 <div class="offer-calculation" id="offer-calculation">أدخل سعر الخصم لحساب النسبة.</div>
 <div class="notice">${p?.demo_product?'هذا المنتج للعرض فقط، وسيظل الشراء معطلاً حتى بعد إضافته إلى العروض.':'تظهر التخفيضات للزائر، ويُستخدم السعر المخفّض عند الشراء للمنتجات الحقيقية.'} ${p?.source_url?'السعر الأساسي من المصدر، أما التخفيض فهو عرض توضيحي داخل مدار ستور.':''}</div>
 <div class="row gap12 wrap"><button class="btn" type="submit" id="offer-save-btn">${existing?'حفظ التعديلات':'تفعيل العرض'}</button><button class="btn btn-outline" type="button" data-action="close-modal">إلغاء</button></div>
 </form>`,true);
 const form=$('#offer-form');
 const updatePreview=()=>{
   const selected=state.products.find(x=>x.id===form.elements.product_id?.value);
   if(!p&&selected){form.elements.regular_price.value=Number(selected.price).toFixed(2)}
   const full=Number(form.elements.regular_price.value),discount=Number(form.elements.discount_price.value),el=$('#offer-calculation');
   if(el)el.textContent=full>discount&&discount>0?`الخصم ${Math.round((1-discount/full)*100)}% · التوفير ${money(full-discount)}`:'أدخل سعراً مخفّضاً أقل من السعر الأساسي.';
 };
 form.addEventListener('input',updatePreview);
 form.addEventListener('change',updatePreview);
 form.addEventListener('submit',saveOffer);
 updatePreview();
}
async function saveOffer(ev){
 ev.preventDefault();const form=ev.target,button=form.querySelector('#offer-save-btn');
 const fd=new FormData(form),id=String(fd.get('product_id')||''),product=state.products.find(x=>x.id===id);
 const regular=Number(fd.get('regular_price')),discount=Number(fd.get('discount_price'));
 if(!product||!Number.isFinite(regular)||!Number.isFinite(discount)||discount<=0||regular<=discount||regular>1000000){toast('اختر المنتج وأدخل سعراً بعد الخصم أقل من السعر الأساسي');return;}
 if(!isOffer(product)&&Math.abs(Number(product.price)-regular)>0.005){toast('تغير السعر الأساسي؛ أغلق النافذة وأعد المحاولة');return;}
 button.disabled=true;button.textContent='جارٍ حفظ العرض…';
 try{
  if(backendReady){
   const {data,error}=await db.rpc('set_madar_product_offer',{p_product_id:id,p_regular_price:regular,p_discount_price:discount});
   if(error||!data?.ok)throw error||Error('لم يؤكد الخادم حفظ العرض');
   await loadAdmin();
  }else{
   state.products=state.products.map(x=>x.id===id?{...x,price:discount,compare_at:regular,offer_active:true,offer_previous_compare_at:x.offer_active?x.offer_previous_compare_at:x.compare_at}:x);
   setJ(DEMO_P_KEY,state.products);
  }
  $('#modal-holder')?.remove();await render();toast('تم حفظ العرض بنجاح');
 }catch(e){toast('تعذر حفظ العرض: '+friendlyError(e));button.disabled=false;button.textContent='إعادة المحاولة';}
}
async function removeOffer(id){
 const p=state.products.find(x=>x.id===id);if(!p||!isOffer(p))return;
 if(!confirm(`هل تريد إزالة «${p.name}» من العروض وإعادة سعره الأساسي ${money(p.compare_at)}؟ لن يتم حذف المنتج.`))return;
 try{
  if(backendReady){const {data,error}=await db.rpc('remove_madar_product_offer',{p_product_id:id});if(error||!data?.ok)throw error||Error('لم يؤكد الخادم الإزالة');await loadAdmin();}
  else{state.products=state.products.map(x=>x.id===id?{...x,price:Number(x.compare_at),compare_at:x.offer_previous_compare_at??null,offer_previous_compare_at:null,offer_active:false}:x);setJ(DEMO_P_KEY,state.products)}
  await render();toast('تمت إزالة العرض وعاد السعر الأساسي');
 }catch(e){toast('تعذر إزالة العرض: '+friendlyError(e))}
}
function adminOrders(){return `<div class="box"><div class="toolbar"><div><strong>إدارة الطلبات</strong><div class="muted tiny">راجع بيانات العميل وحدّث حالة الطلب. الحذف النهائي متاح للطلبات الملغاة فقط بعد كتابة رقم الطلب للتأكيد.</div></div><select id="orders-filter"><option value="all">كل الحالات</option>${Object.entries(statusNames).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></div><div id="orders-table-holder">${ordersTable(state.orders)}</div></div>`}
function adminSettings(){const x=state.settings;const multi=(key,label,placeholder='')=>`<div class="field"><label>${label}</label><textarea name="${key}" maxlength="3000" placeholder="${placeholder}">${esc(x[key]||'')}</textarea></div>`;return `<div class="box" style="max-width:960px"><h3>إعدادات المتجر وتجهيز الافتتاح</h3><div class="notice ${x.orders_enabled?'':'warn'}">${x.orders_enabled?'الطلبات مفعّلة، راجع مخزون المنتجات باستمرار.':'الطلبات مغلقة الآن. أضف معلومات النشاط والتوصيل والسياسات الحقيقية، ثم فعّل استقبال الطلبات.'}</div>
  <section class="whatsapp-admin-panel" aria-labelledby="wa-settings-heading">
    <div class="whatsapp-admin-head"><span class="whatsapp-admin-logo"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.966-.273-.099-.471-.148-.67.15-.198.297-.767.965-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.058-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.174.198-.298.297-.496.1-.198.05-.371-.025-.52-.074-.149-.669-1.612-.916-2.206-.242-.579-.487-.5-.67-.51l-.57-.01c-.199 0-.52.075-.793.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.29.173-1.413-.074-.124-.272-.198-.57-.347m-5.422 7.768h-.004a9.82 9.82 0 0 1-5.006-1.37l-.359-.213-3.723.977.993-3.631-.233-.372a9.813 9.813 0 0 1-1.507-5.242c.002-5.426 4.417-9.842 9.852-9.842a9.79 9.79 0 0 1 6.967 2.889 9.79 9.79 0 0 1 2.887 6.977c-.002 5.426-4.418 9.842-9.867 9.842m8.384-18.236A11.86 11.86 0 0 0 12.009.31C5.456.31.121 5.645.118 12.199a11.86 11.86 0 0 0 1.588 5.936L0 24l6.008-1.575a11.9 11.9 0 0 0 5.999 1.528h.005c6.553 0 11.889-5.335 11.892-11.892a11.84 11.84 0 0 0-3.47-8.383z"/></svg></span><div><h3 id="wa-settings-heading">زر واتساب العائم</h3><p class="muted fine">يظهر أسفل يسار المتجر على الجوال والكمبيوتر، ويبدأ محادثة بالرسالة التي تحددها.</p></div></div>
    <form id="whatsapp-settings-form">
      <label class="whatsapp-switch"><input type="checkbox" name="whatsapp_enabled" ${x.whatsapp_enabled?'checked':''}/><span>إظهار زر واتساب في المتجر</span></label>
      <div class="field"><label for="whatsapp-number">رقم واتساب مع رمز الدولة</label><input id="whatsapp-number" name="whatsapp_number" type="tel" inputmode="tel" dir="ltr" maxlength="25" value="${esc(x.whatsapp_number||'')}" placeholder="+966530748045" autocomplete="off" /></div>
      <div class="field"><label for="whatsapp-message">الرسالة الجاهزة للعميل عند فتح واتساب</label><textarea id="whatsapp-message" name="whatsapp_message" maxlength="500" rows="3" placeholder="مرحباً، لدي استفسار عن أحد المنتجات">${esc(x.whatsapp_message||'')}</textarea><small class="muted">يمكنك تغيير الرسالة في أي وقت؛ تظهر للعميل داخل واتساب قبل أن يضغط إرسال.</small></div>
      <div id="whatsapp-save-feedback" role="status" aria-live="polite"></div>
      <div class="whatsapp-admin-actions"><button type="submit" class="btn whatsapp-save-btn">حفظ إعدادات واتساب</button><a href="#/" class="btn btn-outline">معاينة الزر بالمتجر ↗</a></div>
    </form>
  </section><form id="settings-form"><div class="form-grid"><div class="field"><label>اسم المتجر</label><input name="name" maxlength="80" required value="${esc(x.name)}"/></div><div class="field"><label>اسم صاحب النشاط أو المنشأة *</label><input name="merchant_name" maxlength="160" value="${esc(x.merchant_name||'')}"/></div><div class="field"><label>رقم التواصل مع العملاء *</label><input name="phone" maxlength="24" value="${esc(x.phone||'')}"/></div><div class="field"><label>البريد المعلن لخدمة العملاء *</label><input name="contact_email" type="email" value="${esc(x.contact_email||'')}"/></div><div class="field"><label>رسوم التوصيل (ر.س) *</label><input type="number" name="delivery_fee" min="0" max="5000" step="0.01" value="${esc(x.delivery_fee)}" required/></div><div class="field"><label>المدن المتاحة للتوصيل (افصل بفاصلة) *</label><input name="allowed_cities" maxlength="600" placeholder="الرياض، جدة، الدمام" value="${esc((x.allowed_cities||[]).join('، '))}"/></div><div class="field"><label>رقم السجل التجاري (إن وجد)</label><input name="merchant_registration" value="${esc(x.merchant_registration||'')}"/></div><div class="field"><label>الرقم الضريبي (إن وجد)</label><input name="merchant_tax_id" value="${esc(x.merchant_tax_id||'')}"/></div></div><div class="field"><label>عنوان المنشأة أو بياناتها النظامية *</label><textarea name="merchant_address" maxlength="500">${esc(x.merchant_address||'')}</textarea></div><div class="field"><label>مدة التوصيل المتوقعة *</label><input name="delivery_estimate" maxlength="300" placeholder="مثال: ..." value="${esc(x.delivery_estimate||'')}"/></div>${multi('shipping_policy','سياسة الشحن والتوصيل *','حدد رسوم الشحن ومناطق التغطية وشركة التوصيل والمسؤوليات')}${multi('returns_policy','سياسة الاستبدال والاسترجاع والاسترداد *','اكتب سياسة مطابقة لطبيعة منتجاتك والأنظمة المطبقة')}${multi('complaints_policy','آلية الشكاوى والرد على العملاء *','حدد كيف يتواصل العميل ومتى يتلقى رداً') }<div class="field"><label>الوصف في الصفحة الرئيسية</label><textarea name="hero_subtitle" maxlength="500">${esc(x.hero_subtitle||'')}</textarea></div><div class="field"><label>عبارة المتجر التعريفية</label><input name="tagline" maxlength="150" value="${esc(x.tagline||'')}"/></div><button class="btn" type="submit">حفظ بيانات المتجر والسياسات</button></form><div class="divider" style="margin:28px 0"></div><h3>التحكم في إطلاق المتجر</h3><p class="muted fine">قبل الافتتاح، تأكد من وجود منتجات حقيقية في المخزون، وأن سياسات الشحن والإرجاع والبيانات التجارية صحيحة. الطلبات تُدفع عند الاستلام، ولا توجد بوابة دفع إلكترونية حالياً.</p><label class="fine" style="display:block;margin:13px 0"><input type="checkbox" id="launch-confirm"/> أؤكد أن المنتجات حقيقية ومتوفرة، وأن المعلومات والسياسات صحيحة وأنني جاهز لاستلام طلبات العملاء.</label><button class="btn ${x.orders_enabled?'btn-outline':''}" type="button" data-action="launch-toggle" data-enable="${x.orders_enabled?'false':'true'}">${x.orders_enabled?'إيقاف استقبال الطلبات':'تفعيل استقبال الطلبات'}</button><div class="notice" style="margin-top:15px">✉️ بريد إشعارات الطلبات: mohamedkhrsani1@gmail.com. تُرسل إشعارات عند الطلب عبر Resend. لإرسال رسائل من عنوان تجاري خاص بك، يلزم توثيق دومين إرسال.</div></div>`}
function adminPage(){const tab=state.adminTab;return adminShell(tab==='products'?adminProducts():tab==='offers'?adminOffers():tab==='orders'?adminOrders():tab==='settings'?adminSettings():tab==='usage'?usageSection():overview())}
function modal(html,wide=false){const existing=$('#modal-holder');if(existing)existing.remove();const el=document.createElement('div');el.id='modal-holder';el.innerHTML=`<div class="modal-bg" role="presentation"><div class="modal ${wide?'wide':''}" role="dialog" aria-modal="true">${html}</div></div>`;document.body.appendChild(el);el.querySelector('.modal-bg').addEventListener('click',e=>{if(e.target===e.currentTarget)el.remove()});el.querySelectorAll('[data-action="close-modal"]').forEach(b=>b.addEventListener('click',()=>el.remove()))}
function galleryEditor(){return `<div class="gallery-editor" id="gallery-editor">${editorImages.map((it,i)=>`<div class="gallery-edit-item"><img src="${esc(it.preview||it.url)}" alt="صورة المنتج ${i+1}"/><span class="gallery-edit-num">${i+1}</span>${i===0?'<span class="gallery-main-tag">رئيسية</span>':''}<div class="gallery-edit-actions"><button type="button" class="tiny-btn" data-gallery-action="main" data-index="${i}" title="اجعلها الصورة الرئيسية" aria-label="تعيين الصورة الرئيسية">★</button><button type="button" class="tiny-btn" data-gallery-action="up" data-index="${i}" title="تقديم الصورة" aria-label="تقديم الصورة">↑</button><button type="button" class="tiny-btn" data-gallery-action="down" data-index="${i}" title="تأخير الصورة" aria-label="تأخير الصورة">↓</button><button type="button" class="tiny-btn delete" data-gallery-action="remove" data-index="${i}" title="حذف الصورة" aria-label="حذف الصورة">×</button></div></div>`).join('')}${!editorImages.length?'<p class="muted tiny">لا توجد صور بعد. اختر صوراً من جهازك أو أضف رابط صورة.</p>':''}</div><p class="muted tiny">${editorImages.length} من 10 صور • النجمة تجعل الصورة الأولى هي الرئيسية، والأسهم تغيّر ترتيب الصور</p>`}
function renderGalleryEditor(){const el=$('#gallery-editor-holder');if(el)el.innerHTML=galleryEditor()}
function editProduct(p){
 state.productEdit=p||null;editorImages=galleryImages(p).map(url=>({url}));
 modal(`<div class="modal-head"><h2>${p?'تعديل المنتج':'إضافة منتج جديد'}</h2><button class="close" data-action="close-modal">×</button></div><form id="product-form">
 <div class="form-grid"><div class="field"><label>اسم المنتج *</label><input required name="name" maxlength="150" value="${esc(p?.name||'')}"/></div><div class="field"><label>القسم *</label><input required name="category" list="known-cats" maxlength="70" value="${esc(p?.category||'')}"/><datalist id="known-cats">${categories().slice(1).map(c=>`<option value="${esc(c)}"></option>`).join('')}</datalist></div><div class="field"><label>السعر (ريال) *</label><input required name="price" type="number" step="0.01" min="0.01" max="1000000" value="${esc(p?.price??'')}"/></div><div class="field"><label>السعر قبل الخصم (اختياري)</label><input name="compare_at" type="number" step="0.01" min="0" max="1000000" value="${esc(p?.compare_at??'')}"/></div><div class="field"><label>الكمية المتاحة *</label><input required name="stock" type="number" step="1" min="0" max="1000000" value="${esc(p?.stock??1)}"/></div></div>
 <div class="field"><label>معرض صور المنتج — حتى 10 صور</label><input id="gallery-files" name="photos" type="file" multiple accept="image/jpeg,image/png,image/webp"/><small>ارفع صوراً من جهازك (JPG أو PNG أو WebP، كل صورة حتى 3 ميجابايت).</small></div>
 <div class="field"><label>أو أضف صورة برابط HTTPS</label><div class="gallery-url-row"><input id="gallery-url" type="url" placeholder="https://example.com/image.jpg" autocomplete="off" dir="ltr"/><button type="button" class="btn btn-sm btn-outline" data-gallery-action="add-url">إضافة الرابط</button></div></div>
 <div id="gallery-editor-holder">${galleryEditor()}</div>
 ${p?.offer_active?'<div class="notice">هذا المنتج موجود في العروض. لتغيير سعر الخصم أو إلغاء العرض استخدم قسم «العروض والتخفيضات».</div>':''}
 <div class="field"><label>وصف المنتج</label><textarea name="description" maxlength="6000">${esc(p?.description||'')}</textarea></div><div class="row gap12 wrap"><label class="fine"><input type="checkbox" name="featured" ${p?.featured?'checked':''}/> منتج مميز</label><label class="fine"><input type="checkbox" name="active" ${p?.active!==false?'checked':''}/> ظاهر في المتجر</label><label class="fine"><input type="checkbox" name="demo_product" ${p?.demo_product?'checked':''}/> نموذج عرض فقط (غير قابل للشراء)</label></div><p class="muted tiny">للمنتج التجريبي اجعل المخزون صفراً. لتحويله إلى منتج للبيع، ألغِ اختيار «نموذج عرض» وأدخل مخزونك الحقيقي.</p>
 <div class="row gap12 wrap" style="margin-top:24px"><button class="btn" type="submit" id="save-product">حفظ المنتج وصوره</button>${p?`<button type="button" class="btn btn-outline" data-gallery-action="copy-share">⎘ نسخ رابط المنتج</button>`:''}<button type="button" class="btn btn-outline" data-action="close-modal">إلغاء</button></div>
 </form>`,true);
 $('#product-form').addEventListener('submit',saveProduct);
 $('#gallery-files').addEventListener('change',e=>{
  for(const file of e.target.files){if(editorImages.length>=10){toast('الحد الأقصى 10 صور للمنتج');break}if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>3*1024*1024){toast('الصورة يجب أن تكون JPG أو PNG أو WebP وأقل من 3 ميجابايت');continue}editorImages.push({file,preview:URL.createObjectURL(file)})}
  e.target.value='';renderGalleryEditor()
 });
 $('#modal-holder').addEventListener('click',async e=>{
  const b=e.target.closest('[data-gallery-action]');if(!b)return;e.preventDefault();
  const action=b.dataset.galleryAction,i=Number(b.dataset.index);
  if(action==='copy-share'){if(p)await copyProductLink(p);return}
  if(action==='add-url'){const input=$('#gallery-url'),value=input.value.trim();if(editorImages.length>=10){toast('الحد الأقصى 10 صور');return}if(!/^https:\/\/\S+$/i.test(value)){toast('اكتب رابط صورة يبدأ بـ https://');return}editorImages.push({url:value});input.value='';renderGalleryEditor();return}
  if(!Number.isInteger(i)||i<0||i>=editorImages.length)return;
  if(action==='remove'){const item=editorImages.splice(i,1)[0];if(item.preview)URL.revokeObjectURL(item.preview)}
  if(action==='main'){const item=editorImages.splice(i,1)[0];editorImages.unshift(item)}
  if(action==='up'&&i>0)[editorImages[i-1],editorImages[i]]=[editorImages[i],editorImages[i-1]];
  if(action==='down'&&i<editorImages.length-1)[editorImages[i+1],editorImages[i]]=[editorImages[i],editorImages[i+1]];
  renderGalleryEditor();
 });
}
async function saveProduct(ev){ev.preventDefault();const btn=$('#save-product');btn.disabled=true;btn.textContent='جارٍ حفظ المنتج والصور...';
 const fd=new FormData(ev.target),p=state.productEdit;
 try{
  if(editorImages.length>10)throw Error('الحد الأقصى 10 صور');
  const images=[];
  for(const it of editorImages){if(!it.file){images.push(it.url);continue}
    if(backendReady){const ext=it.file.type==='image/png'?'png':it.file.type==='image/webp'?'webp':'jpg';const path=`products/${crypto.randomUUID()}.${ext}`;const {error}=await db.storage.from('product-images').upload(path,it.file,{contentType:it.file.type,upsert:false});if(error)throw error;images.push(db.storage.from('product-images').getPublicUrl(path).data.publicUrl)}
    else images.push(await new Promise((res,rej)=>{const reader=new FileReader();reader.onload=()=>res(reader.result);reader.onerror=rej;reader.readAsDataURL(it.file)}));
  }
  const item={name:String(fd.get('name')).trim(),category:String(fd.get('category')).trim(),price:Number(fd.get('price')),compare_at:fd.get('compare_at')?Number(fd.get('compare_at')):null,stock:Number(fd.get('stock')),image_url:images[0]||'',image_urls:images,description:String(fd.get('description')||'').trim(),featured:fd.has('featured'),active:fd.has('active'),demo_product:fd.has('demo_product')};
  // Editing a sourced product invalidates its captured market price/photo provenance.
  if(p?.source_url){item.source_url=null;item.source_name=null;item.source_checked_at=null;}
  if(!item.name||!item.category||!(item.price>0)||!Number.isInteger(item.stock)||item.stock<0)throw Error('تحقق من بيانات المنتج');if(item.demo_product&&item.stock!==0)throw Error('المنتج التجريبي يجب أن تكون كميته صفراً. إذا أردت بيعه ألغِ خيار نموذج العرض.');
  if(backendReady){const {error}=p?await db.from('products').update(item).eq('id',p.id):await db.from('products').insert(item);if(error)throw error;await loadAdmin()}
  else{if(p)state.products=state.products.map(x=>x.id===p.id?{...x,...item}:x);else state.products.unshift({id:'demo-'+Date.now(),...item});state.storeCategories=mergeSections(state.storeCategories,state.products);setJ('madar_demo_sections_v1',state.storeCategories);setJ(DEMO_P_KEY,state.products)}
  $('#modal-holder')?.remove();editorImages=[];toast(item.demo_product?'تم حفظ نموذج العرض بنجاح':'تم حفظ المنتج والصور بنجاح');render();
 }catch(e){toast('تعذر حفظ المنتج: '+friendlyError(e));btn.disabled=false;btn.textContent='حفظ المنتج وصوره'}
}
function filterAdminProductRows(){
 const input=document.getElementById('admin-product-search');
 const sel=document.getElementById('admin-product-category');
 if(!input||!sel)return;
 const needle=input.value.trim().toLocaleLowerCase(), category=sel.value;
 let count=0;
 document.querySelectorAll('.admin-product-row').forEach(row=>{
   const ok=(!category||row.dataset.category===category)&&(!needle||row.dataset.search.includes(needle));
   row.hidden=!ok;
   if(ok)count++;
 });
 const output=document.getElementById('admin-product-count');
 if(output)output.textContent=`${count} من ${state.products.length} منتج`;
}
function downloadProductsBackup(){
  if(!state.adminReady){toast('يمكن للمدير فقط تصدير المنتجات');return;}
  const backup={
    export_type:'madar_store_products_backup',
    created_at:new Date().toISOString(),
    store_name:state.settings.name,
    product_count:state.products.length,
    products:state.products
  };
  const data=new Blob([JSON.stringify(backup,null,2)],{type:'application/json;charset=utf-8'});
  const url=URL.createObjectURL(data);
  const a=document.createElement('a');
  a.href=url;a.download=`madar-products-backup-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a);a.click();a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
  toast('تم تجهيز نسخة احتياطية من بيانات المنتجات');
}
function confirmDeleteAllProducts(){
  if(!state.adminReady){toast('هذا الإجراء متاح للمدير فقط');return;}
  const count=state.products.length;
  if(count===0){toast('لا توجد منتجات لحذفها');return;}
  const original=state.products.filter(p=>!p.demo_product).length;
  const hidden=state.products.filter(p=>p.active===false).length;
  modal(`<div class="modal-head"><h2>🗑 حذف جميع المنتجات نهائياً</h2><button type="button" class="close" data-action="close-modal" aria-label="إغلاق النافذة">×</button></div>
    <div class="notice warn bulk-delete-warning"><strong>تنبيه: عملية لا يمكن التراجع عنها!</strong><p>سيتم حذف <b>${count}</b> منتجاً من قاعدة بيانات المتجر دفعة واحدة، بما فيها <b>${original}</b> منتجاً غير تجريبي و<b>${hidden}</b> منتجاً مخفياً، وجميع منتجات العروض والتخفيضات.</p></div>
    <p class="fine">ستظل الطلبات السابقة وتفاصيلها وأسعارها محفوظة. صور Supabase Storage لا تُحذف تلقائياً. إذا كنت تريد إخفاء المنتجات مؤقتاً، فلا تستخدم هذا الزر.</p>
    <button type="button" class="btn btn-outline btn-sm" id="products-backup-download">⬇ تنزيل نسخة احتياطية من بيانات المنتجات</button>
    <div class="field bulk-delete-type"><label for="bulk-delete-confirm-phrase">اكتب العبارة التالية كما هي لتأكيد الحذف:</label><p class="bulk-confirm-phrase">حذف جميع المنتجات</p><input type="text" id="bulk-delete-confirm-phrase" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="اكتب: حذف جميع المنتجات"/></div>
    <label class="bulk-delete-check"><input type="checkbox" id="bulk-delete-understand"/><span>أفهم أن الحذف نهائي ويشمل <b>كل المنتجات</b> وليس نتائج البحث الحالية فقط.</span></label>
    <div class="row gap12 wrap"><button type="button" class="btn bulk-products-delete-button" id="confirm-all-products-delete" disabled>حذف ${count} منتج نهائياً</button><button type="button" class="btn btn-outline" data-action="close-modal">إلغاء</button></div>`);
  const dialog=document.getElementById('modal-holder');
  const phrase=dialog.querySelector('#bulk-delete-confirm-phrase');
  const checkbox=dialog.querySelector('#bulk-delete-understand');
  const btn=dialog.querySelector('#confirm-all-products-delete');
  const validate=()=>{btn.disabled=phrase.value.trim()!=='حذف جميع المنتجات'||!checkbox.checked;};
  phrase.addEventListener('input',validate);
  checkbox.addEventListener('change',validate);
  dialog.querySelector('#products-backup-download').addEventListener('click',downloadProductsBackup);
  btn.addEventListener('click',async()=>{
    if(btn.disabled||phrase.value.trim()!=='حذف جميع المنتجات'||!checkbox.checked)return;
    btn.disabled=true;btn.textContent='جارٍ حذف جميع المنتجات...';
    try{
      if(backendReady){
        const {data,error}=await db.rpc('delete_all_madar_products',{
          p_confirmation:phrase.value.trim(),p_expected_count:count
        });
        if(error)throw error;
        if(!data?.deleted||Number(data.deleted_count)!==count)throw Error('تعذر التأكد من عدد المنتجات المحذوفة');
        await loadAdmin();
      }else{
        state.products=[];
        setJ(DEMO_P_KEY,[]);
      }
      state.cart=[];cartStore();state.filter='الكل';state.search='';
      dialog.remove();await render();
      toast(`تم حذف ${count} منتجاً بنجاح. الطلبات السابقة محفوظة.`);
    }catch(err){
      const msg=String(err?.message||err);
      toast(msg.includes('PRODUCT_COUNT_CHANGED')?'تغير عدد المنتجات. حدّث لوحة الإدارة ثم أعد المحاولة.':msg.includes('ADMIN_ONLY')?'هذه العملية متاحة لمدير المتجر فقط':msg.includes('CONFIRMATION_PHRASE_MISMATCH')?'عبارة التأكيد غير صحيحة':'تعذر الحذف الجماعي: '+friendlyError(err));
      btn.disabled=false;btn.textContent=`حذف ${count} منتج نهائياً`;
    }
  });
  phrase.focus();
}
function confirmDeleteProduct(id){
 const p=getProduct(id);
 if(!p||!state.adminReady){toast('هذا الإجراء متاح لمدير المتجر فقط');return;}
 const orderMatches=state.orders.filter(o=>(o.order_items||[]).some(item=>item.product_id===p.id));
 const warning=orderMatches.length
   ?`⚠️ لهذا المنتج ${orderMatches.length} طلب/طلبات مرتبطة. ستبقى تفاصيل وأسعار الطلبات القديمة محفوظة، لكن المنتج نفسه سيُحذف نهائياً من الكتالوج.`
   :'⚠️ حذف نهائي: لن يظهر المنتج بعد الآن في المتجر أو لوحة الإدارة. لن تُحذف صور Supabase Storage تلقائياً، لتجنب إزالة صورة مشتركة مع منتج آخر.';
 modal(`<div class="modal-head"><h2>حذف المنتج نهائياً</h2><button class="close" data-action="close-modal" aria-label="إغلاق">×</button></div><div class="notice warn">${warning}</div><p class="fine">اكتب اسم المنتج التالي بالكامل لتأكيد الحذف:</p><p class="product-confirm-name">${esc(p.name)}</p><div class="field"><label for="confirm-product-name">اسم المنتج للتأكيد</label><input id="confirm-product-name" type="text" autocomplete="off" spellcheck="false" placeholder="اكتب اسم المنتج كما يظهر" /></div><div class="row gap12 wrap"><button type="button" class="btn admin-product-delete" id="confirm-product-delete" disabled>حذف المنتج نهائياً</button><button type="button" class="btn btn-outline" data-action="close-modal">إلغاء</button></div>`);
 const dialog=document.getElementById('modal-holder'),input=dialog.querySelector('#confirm-product-name'),button=dialog.querySelector('#confirm-product-delete');
 input.addEventListener('input',()=>{button.disabled=input.value.trim()!==p.name.trim()});
 button.addEventListener('click',async()=>{
   if(button.disabled||input.value.trim()!==p.name.trim())return;
   button.disabled=true;button.textContent='جارٍ حذف المنتج...';
   try{
     if(backendReady){
       const {data,error}=await db.rpc('delete_madar_product',{p_product_id:p.id,p_confirm_name:input.value.trim()});
       if(error)throw error;
       if(!data?.deleted)throw Error('لم يؤكد الخادم حذف المنتج');
       await loadAdmin();
     }else{
       state.products=state.products.filter(x=>x.id!==p.id);
       setJ(DEMO_P_KEY,state.products);
     }
     state.cart=state.cart.filter(x=>x.id!==p.id);cartStore();
     dialog.remove();await render();toast('تم حذف المنتج من المتجر بنجاح');
   }catch(err){
     const msg=String(err?.message||err);
     toast(msg.includes('ADMIN_ONLY')?'ليس لديك صلاحية حذف المنتجات':msg.includes('PRODUCT_NOT_FOUND')?'المنتج غير موجود أو تم حذفه':msg.includes('PRODUCT_NAME_MISMATCH')?'اسم المنتج غير مطابق':'تعذر حذف المنتج: '+friendlyError(err));
     button.disabled=false;button.textContent='حذف المنتج نهائياً';
   }
 });
 input.focus();
}
function orderDetails(id){const o=state.orders.find(o=>o.id===id);if(!o)return;const lines=o.order_items||o.items||[];const gps=(o.latitude!==null&&o.latitude!==undefined&&o.longitude!==null&&o.longitude!==undefined)?`<p><strong>موقع التوصيل:</strong> <a href="https://www.google.com/maps?q=${Number(o.latitude)},${Number(o.longitude)}" target="_blank" rel="noopener noreferrer" style="color:var(--pine);text-decoration:underline">فتح النقطة على الخرائط ↗</a></p>`:'';modal(`<div class="modal-head"><h2>تفاصيل الطلب #${esc(o.order_number||o.number||o.id.slice(0,8))}</h2><button class="close" data-action="close-modal">×</button></div><div class="form-grid"><p><strong>العميل:</strong> ${esc(o.customer_name)}</p><p><strong>الجوال:</strong> <a href="tel:${esc(o.phone)}">${esc(o.phone)}</a></p><p><strong>البريد:</strong> ${o.customer_email?`<a href="mailto:${esc(o.customer_email)}">${esc(o.customer_email)}</a>`:'لم يقدمه العميل'}</p><p><strong>المدينة:</strong> ${esc(o.city)}</p><p><strong>الحي:</strong> ${esc(o.district)}</p></div><p><strong>العنوان:</strong> ${esc(o.address)}</p>${gps}<p><strong>ملاحظات:</strong> ${esc(o.notes||'لا يوجد')}</p><div class="divider"></div><h3 style="margin-top:17px">المنتجات</h3>${lines.length?lines.map(x=>`<div class="summary-row"><span>${esc(x.product_name)} × ${x.qty}</span><strong>${money(x.line_total??x.qty*x.unit_price)}</strong></div>`).join(''):'<p class="muted fine">تفاصيل العناصر غير متاحة.</p>'}<div class="summary-row total"><span>إجمالي الطلب</span><strong>${money(o.total)}</strong></div><div class="field"><label>حالة الطلب</label><select id="order-status" ${o.status==='cancelled'?'disabled':''}>${Object.entries(statusNames).map(([k,v])=>`<option value="${k}" ${o.status===k?'selected':''}>${v}</option>`).join('')}</select></div><div class="row gap12 wrap"><button type="button" class="btn" data-action="order-save" data-id="${esc(o.id)}" ${o.status==='cancelled'?'disabled':''}>حفظ حالة الطلب</button>${o.status==='cancelled'?`<button type="button" class="btn order-delete-btn" data-action="order-delete" data-id="${esc(o.id)}">حذف الطلب الملغى نهائياً</button>`:''}</div><p class="tiny muted" style="margin-top:12px">ملاحظة: لا يمكن إعادة تفعيل طلب ملغى. إلغاء الطلب يُعيد الكمية إلى المخزون.</p>`);const holder=$('#modal-holder');
const saveButton=holder?.querySelector('[data-action="order-save"]');
saveButton?.addEventListener('click',()=>{void saveStatus(id,saveButton)});
const deleteButton=holder?.querySelector('[data-action="order-delete"]');
deleteButton?.addEventListener('click',()=>confirmDeleteOrder(id));}
function confirmDeleteOrder(id){
  const o=state.orders.find(x=>x.id===id);
  if(!o)return;
  if(o.status!=='cancelled'){
    toast('يمكن حذف الطلبات الملغاة فقط. غيّر الحالة إلى ملغى أولاً إذا كان الطلب تجريبياً.');
    return;
  }
  const number=String(o.order_number||o.number||o.id);
  modal(`<div class="modal-head"><h2>حذف الطلب الملغى</h2><button class="close" data-action="close-modal" aria-label="إغلاق">×</button></div><div class="notice warn">هذا الإجراء نهائي، وسيحذف سجل الطلب وتفاصيل منتجاته. لا تُحذف المنتجات نفسها، ولا تتغير كميات المخزون لأن الطلب ملغى مسبقاً. لا تحذف السجلات التي يلزم الاحتفاظ بها نظامياً أو محاسبياً.</div><p class="fine">لتأكيد الحذف، اكتب رقم الطلب كما يظهر هنا:</p><p class="order-confirm-number" dir="ltr">${esc(number)}</p><div class="field"><label for="delete-order-number">رقم الطلب للتأكيد</label><input type="text" id="delete-order-number" dir="ltr" autocomplete="off" spellcheck="false" placeholder="${esc(number)}" /></div><div class="row gap12 wrap"><button class="btn order-delete-btn" type="button" id="confirm-delete-order" disabled>حذف نهائي</button><button type="button" class="btn btn-outline" data-action="close-modal">إلغاء</button></div>`);
  const holder=$('#modal-holder'), input=holder.querySelector('#delete-order-number'), btn=holder.querySelector('#confirm-delete-order');
  input.addEventListener('input',()=>{btn.disabled=input.value.trim().toUpperCase()!==number.toUpperCase();});
  btn.addEventListener('click',async()=>{
    if(input.value.trim().toUpperCase()!==number.toUpperCase())return;
    btn.disabled=true;btn.textContent='جارٍ الحذف...';
    try{
      if(backendReady){
        const {data,error}=await db.rpc('delete_cancelled_madar_order',{p_order_id:o.id,p_confirm_order_number:input.value.trim()});
        if(error)throw error;
        if(!data?.deleted)throw Error('لم يتم تأكيد حذف الطلب');
        await loadAdmin();
      }else{
        state.orders=state.orders.filter(x=>x.id!==o.id);
        setJ(DEMO_O_KEY,state.orders);
      }
      holder.remove();toast('تم حذف الطلب الملغى وتفاصيله نهائياً');await render();
    }catch(e){
      const msg=String(e?.message||e);
      toast(msg.includes('CANCEL_ORDER_FIRST')?'لا يمكن حذف هذا الطلب قبل إلغائه':msg.includes('ADMIN_ONLY')?'ليس لديك تصريح بالحذف':msg.includes('ORDER_NUMBER_CONFIRMATION_MISMATCH')?'رقم تأكيد الطلب غير مطابق':'تعذر الحذف: '+friendlyError(e));
      btn.disabled=false;btn.textContent='حذف نهائي';
    }
  });
  input.focus();
}
async function saveStatus(id,button){
 const statusInput=document.getElementById('order-status');
 const next=statusInput?.value;
 const order=state.orders.find(o=>o.id===id);
 if(!order||!next||!button||button.disabled)return;
 if(order.status==='cancelled'){toast('الطلب الملغى لا يمكن إعادة فتحه');return;}
 if(order.status===next){toast('حالة الطلب محفوظة بالفعل، اختر حالة مختلفة للتحديث');return;}
 button.disabled=true;
 const originalText=button.textContent;
 button.textContent='جارٍ حفظ الحالة...';
 try{
   if(backendReady){
     const {data,error}=await db.rpc('set_madar_order_status',{p_order_id:id,p_status:next});
     if(error)throw error;
     if(!data?.ok||data?.status!==next)throw Error('ORDER_UPDATE_NOT_CONFIRMED');
     // Read back the persisted status; do not say "saved" until the server verifies it.
     const {data:confirmed,error:readError}=await db.from('orders').select('id,status').eq('id',id).single();
     if(readError||confirmed?.status!==next)throw readError||Error('ORDER_STATUS_READBACK_MISMATCH');
     order.status=next;
     try{await loadAdmin()}catch(refreshError){console.warn('Order saved, list refresh delayed:',refreshError)}
   }else{
     order.status=next;
     setJ(DEMO_O_KEY,state.orders);
   }
   document.getElementById('modal-holder')?.remove();
   await render();
   toast('تم حفظ الحالة بنجاح: '+(statusNames[next]||next));
 }catch(e){
   console.error('Order status update failed:',e);
   const message=String(e?.message||e);
   const friendly=message.includes('ADMIN_ONLY')?'تحتاج إلى تسجيل الدخول بحساب مدير المتجر':
      message.includes('CANCELLED_ORDER_CANNOT_REOPEN')?'لا يمكن إعادة فتح طلب ملغى':
      message.includes('ORDER_NOT_FOUND')?'لم يُعثر على الطلب؛ حدّث الصفحة':
      message.includes('ORDER_UPDATE_NOT_CONFIRMED')?'لم يتم تأكيد حفظ حالة الطلب':
      message.includes('ORDER_STATUS_READBACK_MISMATCH')?'تعذر تأكيد الحالة الجديدة، أعد فتح الطلب':
      friendlyError(e);
   toast('تعذر حفظ حالة الطلب: '+friendly);
   button.disabled=false;
   button.textContent=originalText;
 }
}

async function saveWhatsApp(ev){
 ev.preventDefault();
 const form=ev.target, fd=new FormData(form);
 const enabled=fd.has('whatsapp_enabled');
 let raw=String(fd.get('whatsapp_number')||'').trim();
 const number=normalizeWhatsApp(raw);
 const message=String(fd.get('whatsapp_message')||'').trim();
 const feedback=form.querySelector('#whatsapp-save-feedback');
 if((enabled&&!number)||(raw&&!number)){
   if(feedback)feedback.textContent='يرجى إدخال رقم واتساب صحيح مع رمز الدولة، مثل +966530748045.';
   return;
 }
 if(message.length>500){if(feedback)feedback.textContent='الرسالة طويلة جداً (الحد 500 حرف).';return;}
 if(number)raw='+'+number;
 const settings={whatsapp_enabled:enabled,whatsapp_number:raw,whatsapp_message:message};
 const button=form.querySelector('button[type="submit"]');
 if(button){button.disabled=true;button.textContent='جارٍ حفظ واتساب…';}
 if(feedback)feedback.textContent='';
 try{
   if(backendReady){
     const {data,error}=await db.from('store_settings').update(settings).eq('id',1)
        .select('whatsapp_enabled,whatsapp_number,whatsapp_message').maybeSingle();
     if(error)throw error;
     if(!data)throw Error('لم يتم تأكيد حفظ التغيير. تأكد من صلاحيات الإدارة.');
     Object.assign(state.settings,data);
   }else{
     state.settings={...state.settings,...settings};
     setJ('madar_demo_settings',state.settings);
   }
   await render();
   toast('تم حفظ رقم ورسالة واتساب بنجاح ✓');
 }catch(e){
   if(feedback)feedback.textContent='تعذّر حفظ واتساب: '+friendlyError(e);
   toast('لم يتم حفظ إعدادات واتساب');
   if(button){button.disabled=false;button.textContent='حفظ إعدادات واتساب';}
 }
}
async function saveSettings(ev){ev.preventDefault();const d=new FormData(ev.target);const cities=String(d.get('allowed_cities')||'').split(/[،,\n]+/).map(x=>x.trim()).filter(Boolean);const s={name:String(d.get('name')||'').trim(),merchant_name:String(d.get('merchant_name')||'').trim(),merchant_address:String(d.get('merchant_address')||'').trim(),merchant_registration:String(d.get('merchant_registration')||'').trim(),merchant_tax_id:String(d.get('merchant_tax_id')||'').trim(),contact_email:String(d.get('contact_email')||'').trim(),phone:String(d.get('phone')||'').trim(),delivery_fee:Number(d.get('delivery_fee')),allowed_cities:[...new Set(cities)],delivery_estimate:String(d.get('delivery_estimate')||'').trim(),shipping_policy:String(d.get('shipping_policy')||'').trim(),returns_policy:String(d.get('returns_policy')||'').trim(),complaints_policy:String(d.get('complaints_policy')||'').trim(),tagline:String(d.get('tagline')||'').trim(),hero_subtitle:String(d.get('hero_subtitle')||'').trim()};if(!s.name||!Number.isFinite(s.delivery_fee)||s.delivery_fee<0||s.delivery_fee>5000){toast('تحقق من الاسم ورسوم التوصيل');return}try{if(backendReady){const {error}=await db.from('store_settings').update(s).eq('id',1);if(error)throw error;}else setJ('madar_demo_settings',{...state.settings,...s});state.settings={...state.settings,...s};toast('تم حفظ الإعدادات بنجاح');render()}catch(e){toast(friendlyError(e))}}
async function launchToggle(target){if(!backendReady){toast('تفعيل الطلبات يحتاج إلى اتصال بقاعدة البيانات');return}const enable=target.dataset.enable==='true';if(enable&&!$('#launch-confirm')?.checked){toast('أكّد جاهزية المتجر أولاً');return}if(enable&&!confirm('هل تأكدت من أن المنتجات حقيقية وأن الشحن والسياسات والالتزامات النظامية جاهزة؟ سيبدأ قبول الطلبات الحقيقية مباشرة.'))return;target.disabled=true;try{const {error}=await db.from('store_settings').update({orders_enabled:enable}).eq('id',1);if(error)throw error;await loadAdmin();toast(enable?'تم فتح استقبال الطلبات بنجاح':'تم إيقاف استقبال الطلبات');render()}catch(e){toast(String(e?.message||e).includes('STORE_SETUP_INCOMPLETE')?'لا يمكن الافتتاح: أكمل معلومات النشاط والشحن والسياسات وأضف منتجاً حقيقياً نشطاً':'تعذر تحديث حالة المتجر: '+friendlyError(e))}finally{target.disabled=false}}
async function login(ev){ev.preventDefault();if(!backendReady){state.adminReady=true;state.adminTab='overview';render();return}const fd=new FormData(ev.target),b=ev.target.querySelector('button[type=submit]');b.disabled=true;try{const {error}=await db.auth.signInWithPassword({email:String(fd.get('email')),password:String(fd.get('password'))});if(error)throw error;const ok=await loadAdmin();if(!ok)throw Error('هذا الحساب غير مصرّح له بإدارة المتجر');state.adminTab='overview';render();toast('مرحباً بك في لوحة التحكم')}catch(e){await db.auth.signOut();toast(friendlyError(e));b.disabled=false}}
async function registerAdmin(ev){ev.preventDefault();if(!backendReady)return;const form=ev.target;const fd=new FormData(form);const b=form.querySelector('button[type=submit]');b.disabled=true;try{const email=String(fd.get('email')||'').trim().toLowerCase();const password=String(fd.get('password')||'');if(email!=='mohamedkhrsani1@gmail.com')throw Error('استخدم البريد المعتمد لإدارة المتجر');if(password.length<12)throw Error('كلمة المرور يجب أن تكون 12 حرفاً أو أكثر');const {data,error}=await db.auth.signUp({email,password,options:{emailRedirectTo:location.origin+location.pathname+'#/admin'}});if(error)throw error;if(data?.session){toast('تم إنشاء الحساب، يمكنك الآن تسجيل الدخول');}else{toast('تحقق من بريدك الإلكتروني لتأكيد الحساب، ثم عد وسجل الدخول');}form.reset()}catch(e){toast('تعذر التسجيل: '+friendlyError(e))}finally{b.disabled=false}}
async function logout(){if(backendReady)await db.auth.signOut();state.adminReady=false;location.hash='#/';render()}
let onRender=0;
async function render(){const seq=++onRender;const r=route();const isAdmin=r.startsWith('admin');document.body.classList.toggle('checkout-view-active',r.split('?')[0]==='checkout');if(isAdmin){if(backendReady){try{const ok=await loadAdmin();if(seq!==onRender)return;app.innerHTML=ok?adminPage():adminLogin();if(ok&&(state.adminTab==='overview'||state.adminTab==='usage'))void refreshUsage()}catch(e){app.innerHTML=`<div class="empty"><h3>حدث خطأ في لوحة الإدارة</h3><p>${esc(friendlyError(e))}</p><button class="btn" onclick="location.reload()">إعادة المحاولة</button></div>`}}else{const localSettings=getJ('madar_demo_settings',null);if(localSettings)state.settings=localSettings;app.innerHTML=state.adminReady?adminPage():adminLogin()}return}if(!state.products.length&&!backendReady)defaultData();const rBase=r.split('?')[0];const content=rBase===''?home():rBase==='products'?productsPage():rBase==='offers'?offersPage():rBase.startsWith('product/')?detailPage(rBase.split('/')[1]):rBase==='cart'?cartPage():rBase==='checkout'?checkoutPage():rBase==='success'?successPage():rBase==='track'?trackingPage():rBase==='policy'?policyPage():layout('<div class="empty"><h2>الصفحة غير موجودة</h2><a class="btn" href="#/">الرئيسية</a></div>');if(seq!==onRender)return;app.innerHTML=content;if(rBase==='checkout')setTimeout(initMap,50);if(rBase==='products'){const inp=$('#global-search');if(inp&&state.search){inp.focus();inp.setSelectionRange(inp.value.length,inp.value.length)}}}
app.addEventListener('click',async e=>{const target=e.target.closest('[data-action]');if(!target)return;const action=target.dataset.action,id=target.dataset.id;switch(action){case'share-product':await shareProduct(getProduct(id));break;case'copy-product':await copyProductLink(getProduct(id));break;case'gallery-select':setGalleryImage(Number(target.dataset.index));break;case'gallery-step':setGalleryImage(state.detailImageIndex+Number(target.dataset.step));break;case'gallery-zoom':zoomGallery(getProduct(id));break;case'add':addToCart(id);break;case'detail-qty':{const p=getProduct(route().split('/')[1]);state.qtyDetail=Math.max(1,Math.min(20,p?.stock||1,state.qtyDetail+Number(target.dataset.delta)));const q=$('#detail-qty-number');if(q)q.textContent=state.qtyDetail;break}case'detail-add':addToCart(id,state.qtyDetail);break;case'cart-minus':{const x=state.cart.find(x=>x.id===id);setCartQty(id,(x?.qty||1)-1);break}case'cart-plus':{const x=state.cart.find(x=>x.id===id);setCartQty(id,(x?.qty||0)+1);break}case'remove':setCartQty(id,0);break;case'clear-cart':state.cart=[];cartStore();render();break;case'filter-home':state.filter=target.dataset.category;location.hash='#/products';break;case'geolocate':geolocate();break;case'admin-tab':state.adminTab=target.dataset.tab;render();break;case'usage-refresh':await refreshUsage(true);break;case'admin-logout':logout();break;case'product-new':editProduct();break;case'offer-new':editOffer(null);break;case'offer-add-single':editOffer(state.products.find(p=>p.id===id));break;case'offer-edit':editOffer(state.products.find(p=>p.id===id));break;case'offer-remove':await removeOffer(id);break;case'product-edit':editProduct(getProduct(id));break;case'product-delete':confirmDeleteProduct(id);break;case'product-delete-all':confirmDeleteAllProducts();break;case'order-view':orderDetails(id);break;case'order-delete':confirmDeleteOrder(id);break;case'order-save':{const button=target;void saveStatus(id,button);break}case'launch-toggle':launchToggle(target);break;default:break}});
let galleryTouchStartX=null;
app.addEventListener('touchstart',e=>{if(e.target.closest('#product-gallery-stage'))galleryTouchStartX=e.touches[0]?.clientX??null},{passive:true});
app.addEventListener('touchend',e=>{if(galleryTouchStartX===null)return;const x=e.changedTouches[0]?.clientX??galleryTouchStartX,delta=x-galleryTouchStartX;galleryTouchStartX=null;if(Math.abs(delta)>45)setGalleryImage(state.detailImageIndex+(delta<0?1:-1))},{passive:true});
document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#modal-holder')?.remove();if((e.key==='ArrowRight'||e.key==='ArrowLeft')&&($('#product-gallery-stage')||$('#lightbox-main'))){const p=getProduct(route().split('/')[1]);if(p)setGalleryImage(state.detailImageIndex+(e.key==='ArrowLeft'?1:-1),p)}});
app.addEventListener('submit' ,e=>{if(e.target.id==='checkout-form')submitOrder(e);else if(e.target.id==='tracking-form')trackOrder(e);else if(e.target.id==='login-form')login(e);else if(e.target.id==='register-form')registerAdmin(e);else if(e.target.id==='settings-form')saveSettings(e);else if(e.target.id==='whatsapp-settings-form')saveWhatsApp(e)});
app.addEventListener('input',e=>{if(e.target.id==='admin-product-search')filterAdminProductRows()});
app.addEventListener('change',e=>{if(e.target.id==='admin-product-category')filterAdminProductRows();if(e.target.id==='sort-products'){state.sort=e.target.value;render()}if(e.target.id==='orders-filter'){const status=e.target.value;const el=$('#orders-table-holder');if(el)el.innerHTML=ordersTable(status==='all'?state.orders:state.orders.filter(o=>o.status===status))}});
app.addEventListener('input',e=>{if(e.target.id==='global-search'){state.search=e.target.value;const r=route();if(!r.startsWith('products'))location.hash='#/products';else{clearTimeout(window.searchT);window.searchT=setTimeout(()=>{const caret=e.target.selectionStart;render().then(()=>{const inp=$('#global-search');if(inp){inp.focus();try{inp.setSelectionRange(caret,caret)}catch{}}})},280)}}});
window.addEventListener('hashchange',async()=>{state.qtyDetail=1;state.detailImageIndex=0;await render();void syncVisitorCounter();requestAnimationFrame(()=>{if(route().split('?')[0]==='checkout'){document.documentElement.scrollLeft=0;document.body.scrollLeft=0;}window.scrollTo({top:0,left:0,behavior:'instant'});});});
(async()=>{try{if(!backendReady){const saved=getJ('madar_demo_settings',null);if(saved)state.settings=saved}await loadPublic();await render();void syncVisitorCounter()}catch(e){app.innerHTML=`<div class="container empty box"><h2>تعذر تحميل المتجر</h2><p>${esc(friendlyError(e))}</p><button class="btn" onclick="location.reload()">إعادة المحاولة</button></div>`}})();
})();
