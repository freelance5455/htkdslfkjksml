(function(){
"use strict";
var C=window.Core;
function $(i){return document.getElementById(i)}
function bn(s){return String(s).replace(/\d/g,function(d){return "০১২৩৪৫৬৭৮৯".charAt(d)})}
function mmss(s){s=Math.max(0,Math.floor(s||0));var h=Math.floor(s/3600),m=Math.floor(s%3600/60),r=s%60;return (h?h+":":"")+(h?("0"+m).slice(-2):m)+":"+("0"+r).slice(-2)}
function digits(str){var o="",c=bn(str);for(var i=0;i<c.length;i++){o+=c.charAt(i)===":"?'<span class="cl">:</span>':'<span class="d">'+c.charAt(i)+'</span>'}return o}
function esc(s){return String(s).replace(/[&<>]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;"}[c]})}
var MN=["জানুয়ারি","ফেব্রুয়ারি","মার্চ","এপ্রিল","মে","জুন","জুলাই","আগস্ট","সেপ্টেম্বর","অক্টোবর","নভেম্বর","ডিসেম্বর"];
var WD=["রবিবার","সোমবার","মঙ্গলবার","বুধবার","বৃহস্পতিবার","শুক্রবার","শনিবার"];
function dstr(t){var d=new Date(t),h=d.getHours(),m=d.getMinutes(),p=h>=4&&h<6?"ভোর":h>=6&&h<12?"সকাল":h>=12&&h<16?"দুপুর":h>=16&&h<18?"বিকাল":h>=18&&h<20?"সন্ধ্যা":"রাত",h12=h%12||12;return WD[d.getDay()]+", "+bn(d.getDate())+" "+MN[d.getMonth()]+" "+bn(d.getFullYear())+" · "+p+" "+bn(h12)+":"+bn(("0"+m).slice(-2))}
var tt=null;function toast(m){var t=$("toast");t.textContent=m;t.classList.add("on");clearTimeout(tt);tt=setTimeout(function(){t.classList.remove("on")},3200)}
function busy(on,m){$("busy").classList.toggle("on",!!on);if(m)$("busyt").textContent=m}

/* সেটিংস */
var S={theme:"auto",fs:26,nz:"mid",lb:5,dict:""};
try{var s0=JSON.parse(localStorage.getItem("sp_set"));if(s0)for(var k in s0)S[k]=s0[k]}catch(e){}
function saveS(){try{localStorage.setItem("sp_set",JSON.stringify(S))}catch(e){}}
function applyTheme(){var t=S.theme;if(t==="auto")t=(window.matchMedia&&matchMedia("(prefers-color-scheme: dark)").matches)?"dark":"light";document.documentElement.setAttribute("data-theme",t);document.body.setAttribute("data-theme",t);var m=document.querySelector('meta[name=theme-color]');if(m)m.content=t==="dark"?"#0e1416":"#2a8c80";
 var b=$("thc").querySelectorAll("button");for(var i=0;i<b.length;i++)b[i].classList.toggle("on",b[i].getAttribute("data-v")===S.theme)}
function cycleTheme(){var o=["auto","light","dark"];S.theme=o[(o.indexOf(S.theme)+1)%3];saveS();applyTheme();drawAll();toast("থিম: "+({auto:"স্বয়ংক্রিয়",light:"লাইট",dark:"ডার্ক"})[S.theme])}
function chipSet(id,val,cb){var b=$(id).querySelectorAll("button");for(var i=0;i<b.length;i++){(function(x){x.classList.toggle("on",x.getAttribute("data-v")===String(val));x.onclick=function(){cb(x.getAttribute("data-v"));for(var j=0;j<b.length;j++)b[j].classList.toggle("on",b[j]===x)}})(b[i])}}

/* ডাটাবেস */
var DB=null;
function dbOpen(){return new Promise(function(res,rej){var r=indexedDB.open("swarpath",1);r.onupgradeneeded=function(){r.result.createObjectStore("rec",{keyPath:"id",autoIncrement:true})};r.onsuccess=function(){DB=r.result;res(DB)};r.onerror=function(){rej(r.error)}})}
function tx(mode,fn){return new Promise(function(res,rej){var t=DB.transaction("rec",mode),s=t.objectStore("rec"),q=fn(s);t.oncomplete=function(){res(q&&q.result)};t.onerror=function(){rej(t.error)};t.onabort=function(){rej(t.error)}})}
function dbPut(r){return tx("readwrite",function(s){return s.put(r)})}
function dbAll(){return tx("readonly",function(s){return s.getAll()})}
function dbGet(id){return tx("readonly",function(s){return s.get(id)})}
function dbDel(id){return tx("readwrite",function(s){return s.delete(id)})}

/* নেভিগেশন */
var cur="rec";
function show(v){cur=v;var vs=document.querySelectorAll(".view");for(var i=0;i<vs.length;i++)vs[i].classList.toggle("on",vs[i].id==="v-"+v);
 var nb=document.querySelectorAll("nav button");for(var j=0;j<nb.length;j++)nb[j].classList.toggle("on",nb[j].getAttribute("data-v")===(v==="det"?"lib":v));
 if(v==="lib")renderLib();if(v==="stat")renderStat();if(v==="set")renderSet();window.scrollTo(0,0)}

/* ===== রেকর্ডিং ===== */
var state="idle",mr=null,stream=null,chunks=[],rctx=null,an=null,t0=0,pAt=0,acc=0,cuts=[],hist=[],raf=0,lastPush=0,mime="";
function elapsed(){if(state==="idle")return 0;var n=state==="paused"?pAt:Date.now();return Math.max(0,(n-t0-acc)/1000)}
function pickMime(){var c=["audio/webm;codecs=opus","audio/webm","audio/mp4","audio/ogg;codecs=opus"];for(var i=0;i<c.length;i++){if(window.MediaRecorder&&MediaRecorder.isTypeSupported&&MediaRecorder.isTypeSupported(c[i]))return c[i]}return ""}
function setUi(){
 var on=state!=="idle";
 $("rbtn").classList.toggle("on",state==="rec");$("rdrec").classList.toggle("on",state==="rec");
 $("rbtn").textContent=on?"⏹":"🎙";$("rdrec").textContent=on?"⏹":"🎙";
 $("pbtn").disabled=!on;$("tbtn").disabled=!on;
 $("pbtn").textContent=state==="paused"?"▶ আবার চালু":"⏸ বিরতি";
 $("st").textContent=state==="idle"?"রেকর্ড শুরু করতে নিচের বোতাম চাপুন":state==="rec"?"রেকর্ড হচ্ছে… স্পষ্ট ও ধীরে পড়ুন":"বিরতিতে আছে";
}
async function startRec(){
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia||!window.MediaRecorder){toast("এই ডিভাইসে রেকর্ডিং সমর্থিত নয়।");return}
 try{
  stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true,channelCount:1}});
 }catch(e){toast("মাইক্রোফোনের অনুমতি পাওয়া যায়নি। সেটিংসে অনুমতি দিন।");return}
 mime=pickMime();chunks=[];cuts=[];hist=[];
 try{mr=mime?new MediaRecorder(stream,{mimeType:mime}):new MediaRecorder(stream)}catch(e){mr=new MediaRecorder(stream)}
 mr.ondataavailable=function(e){if(e.data&&e.data.size)chunks.push(e.data)};
 mr.onstop=onStopped;
 try{rctx=new (window.AudioContext||window.webkitAudioContext)();var src=rctx.createMediaStreamSource(stream);an=rctx.createAnalyser();an.fftSize=1024;src.connect(an);if(rctx.resume)rctx.resume()}catch(e){an=null}
 mr.start(1000);state="rec";t0=Date.now();acc=0;lastPush=0;setUi();loop();
 try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist()}catch(e){}
}
function loop(){
 if(state==="idle")return;
 $("tm").innerHTML=digits(mmss(elapsed()));
 if(an&&state==="rec"){var d=new Uint8Array(an.fftSize);an.getByteTimeDomainData(d);var m=0;for(var i=0;i<d.length;i++){var a=Math.abs(d[i]-128)/128;if(a>m)m=a}
  var n=Date.now();if(n-lastPush>70){hist.push(m);if(hist.length>140)hist.shift();lastPush=n}}
 drawLive();raf=requestAnimationFrame(loop);
}
function css(v){return getComputedStyle(document.body).getPropertyValue(v).trim()||"#2a8c80"}
function fit(cv){var r=window.devicePixelRatio||1,w=cv.clientWidth||cv.width,h=cv.clientHeight||cv.height;if(cv.width!==Math.round(w*r)){cv.width=Math.round(w*r);cv.height=Math.round(h*r)}return [cv.width,cv.height]}
function drawLive(){
 var cv=$("wf"),c=cv.getContext("2d"),sz=fit(cv),W=sz[0],H=sz[1];c.clearRect(0,0,W,H);
 var bw=W/140,mid=H/2;c.fillStyle=css("--ac");
 for(var i=0;i<hist.length;i++){var h=Math.max(3,hist[i]*H*0.95),x=W-(hist.length-i)*bw;c.fillRect(x+1,mid-h/2,Math.max(2,bw-2),h)}
 if(!hist.length){c.fillStyle=css("--line");c.fillRect(0,mid-1,W,2)}
}
function pauseRec(){
 if(state==="rec"){mr.pause();state="paused";pAt=Date.now()}else if(state==="paused"){mr.resume();acc+=Date.now()-pAt;state="rec"}
 setUi();
}
function retake(){
 if(state==="idle")return;var t=elapsed(),lb=parseFloat(S.lb)||5;
 cuts.push([Math.max(0,t-lb),t]);toast("শেষ "+bn(lb)+" সেকেন্ড বাদ যাবে — বাক্যটি আবার বলুন");
 try{navigator.vibrate&&navigator.vibrate(60)}catch(e){}
}
function stopRec(){if(state==="idle")return;var dur=elapsed();if(state==="paused"){acc+=Date.now()-pAt}state="idle";cancelAnimationFrame(raf);try{mr.stop()}catch(e){onStopped()}try{stream.getTracks().forEach(function(t){t.stop()})}catch(e){}try{rctx&&rctx.close()}catch(e){}$("tm").innerHTML=digits(mmss(dur));setUi();window._dur=dur}
function toggleRec(){if(state==="idle")startRec();else stopRec()}
async function onStopped(){
 var blob=new Blob(chunks,{type:mime||"audio/webm"});
 if(blob.size<800){toast("রেকর্ডিং খুব ছোট; সেভ হয়নি।");return}
 var title=$("rtitle").value.trim()||("রেকর্ডিং "+bn(new Date().getDate())+" "+MN[new Date().getMonth()]),ref=$("rref").value;
 busy(true,"নয়েজ কমানো ও ভুল অংশ কাটা চলছে…");
 try{
  var out=await process(blob,cuts.slice(),S.nz);
  var rec={title:title,created:Date.now(),dur:out.dur,ref:ref,text:"",fixes:{spell:0,speech:0},fin:false,wav:new Blob([out.wav],{type:"audio/wav"}),peaks:out.peaks,size:out.wav.byteLength,cuts:cuts.length,nz:S.nz,gated:Math.round(out.gated*100)};
  await dbPut(rec);busy(false);toast("✅ সেভ হয়েছে — লাইব্রেরিতে দেখুন");$("rtitle").value="";hist=[];drawLive();$("tm").innerHTML="";
 }catch(e){busy(false);toast("প্রক্রিয়া ব্যর্থ: "+(e&&e.message?e.message:"অজানা ত্রুটি"))}
}
async function process(blob,cutList,level){
 var ab=await blob.arrayBuffer();
 var AC=window.AudioContext||window.webkitAudioContext,dc=new AC();
 var buf=await new Promise(function(res,rej){var p=dc.decodeAudioData(ab,res,rej);if(p&&p.then)p.then(res,rej)});
 var ch=buf.numberOfChannels,n=buf.length,x=new Float32Array(n),i,c;
 for(c=0;c<ch;c++){var d=buf.getChannelData(c);for(i=0;i<n;i++)x[i]+=d[i]/ch}
 var sr=buf.sampleRate;
 x=C.removeRanges(x,sr,cutList,15);
 if(x.length<sr*0.4)throw new Error("কাটার পর অডিও প্রায় ফাঁকা");
 var tb=dc.createBuffer(1,x.length,sr);tb.copyToChannel?tb.copyToChannel(x,0):tb.getChannelData(0).set(x);
 var TR=16000,len=Math.ceil(x.length/sr*TR),oc=new (window.OfflineAudioContext||window.webkitOfflineAudioContext)(1,len,TR);
 var s=oc.createBufferSource();s.buffer=tb;
 var hp=oc.createBiquadFilter();hp.type="highpass";hp.frequency.value=level==="high"?130:level==="low"?80:105;hp.Q.value=.7;
 var lp=oc.createBiquadFilter();lp.type="lowpass";lp.frequency.value=7200;lp.Q.value=.7;
 var pk=oc.createBiquadFilter();pk.type="peaking";pk.frequency.value=2800;pk.gain.value=2.5;pk.Q.value=.9;
 var cp=oc.createDynamicsCompressor();cp.threshold.value=-26;cp.knee.value=20;cp.ratio.value=3;cp.attack.value=.01;cp.release.value=.2;
 s.connect(hp);hp.connect(lp);lp.connect(pk);pk.connect(cp);cp.connect(oc.destination);s.start(0);
 var r=await oc.startRendering(),y=new Float32Array(r.getChannelData(0));
 try{dc.close()}catch(e){}
 var g=C.denoiseGate(y,TR,level);C.normalize(y,.89);
 return {wav:C.encodeWav(y,TR),peaks:C.peaksOf(y,220),dur:y.length/TR,gated:g.gated||0};
}

/* ===== রিডিং মোড ===== */
function openRd(){var t=$("rref").value.trim();if(!t){toast("আগে ‘পড়ার লেখা’ বক্সে লেখা দিন");return}$("rdt").textContent=t;$("rdt").style.fontSize=S.fs+"px";$("rd").classList.add("on")}
function fsChange(d){S.fs=Math.max(18,Math.min(44,S.fs+d));$("rdt").style.fontSize=S.fs+"px";saveS()}

/* ===== লাইব্রেরি ===== */
async function renderLib(){
 var all=(await dbAll()).sort(function(a,b){return b.created-a.created});
 $("lcount").textContent="("+bn(all.length)+")";
 if(!all.length){$("llist").innerHTML='<p class="mu">এখনো কোনো রেকর্ডিং নেই। “রেকর্ড” ট্যাবে গিয়ে শুরু করুন।</p>';return}
 var o="";all.forEach(function(r){o+='<div class="it" data-id="'+r.id+'"><div class="ic">'+(r.fin?"✅":"▶")+'</div><div style="flex:1;min-width:0"><b>'+esc(r.title)+'</b><small>'+dstr(r.created)+'</small><br><small>'+bn(mmss(r.dur))+' · '+bn((r.size/1048576).toFixed(1))+' MB'+(r.cuts?' · '+bn(r.cuts)+'টি ভুল অংশ কাটা':'')+'</small></div></div>'});
 $("llist").innerHTML=o;
 var it=$("llist").querySelectorAll(".it");for(var i=0;i<it.length;i++)it[i].onclick=function(){openDet(parseInt(this.getAttribute("data-id"),10))};
}

/* ===== বিস্তারিত / প্লেয়ার ===== */
var R=null,au=null,url="",A=null,B=null,looping=false,praf=0,delArm=0;
async function openDet(id){
 R=await dbGet(id);if(!R)return;
 if(au){au.pause();URL.revokeObjectURL(url)}
 url=URL.createObjectURL(R.wav);au=new Audio(url);au.preload="auto";au.playbackRate=parseFloat($("spd").value)||1;A=B=null;looping=false;
 au.addEventListener("loadedmetadata",function(){$("ptot").textContent=bn(mmss(au.duration||R.dur))});
 au.addEventListener("ended",function(){$("pplay").textContent="▶"});
 au.addEventListener("play",function(){$("pplay").textContent="⏸";mediaSess()});
 au.addEventListener("pause",function(){$("pplay").textContent="▶"});
 $("dtitle").value=R.title;$("dref").value=R.ref||"";$("dtxt").value=R.text||"";$("dres").style.display="none";
 $("dmeta").textContent=dstr(R.created)+" · "+bn(mmss(R.dur))+" · নয়েজ: "+({low:"কম",mid:"মাঝারি",high:"বেশি"})[R.nz||"mid"];
 $("dfin").textContent=R.fin?"✅ অধ্যায় শেষ":"☐ অধ্যায় শেষ";$("lstat").textContent="";$("pcur").textContent=bn("0:00");
 show("det");cancelAnimationFrame(praf);drawPlayer();
}
function mediaSess(){try{if(!("mediaSession" in navigator))return;navigator.mediaSession.metadata=new MediaMetadata({title:R.title,artist:"স্বরপাঠ"});
 navigator.mediaSession.setActionHandler("play",function(){au.play()});navigator.mediaSession.setActionHandler("pause",function(){au.pause()});
 navigator.mediaSession.setActionHandler("seekbackward",function(){seek(-10)});navigator.mediaSession.setActionHandler("seekforward",function(){seek(10)})}catch(e){}}
function seek(d){if(!au)return;au.currentTime=Math.max(0,Math.min((au.duration||R.dur)-0.05,au.currentTime+d))}
function drawPlayer(){
 if(!R||cur!=="det")return;
 var cv=$("pw"),c=cv.getContext("2d"),sz=fit(cv),W=sz[0],H=sz[1],p=R.peaks||[],n=p.length,bw=W/n,dur=(au&&au.duration)||R.dur,pos=au?au.currentTime/dur:0;
 c.clearRect(0,0,W,H);
 if(A!==null&&B!==null){c.fillStyle=css("--ac");c.globalAlpha=.16;c.fillRect(A/dur*W,0,(B-A)/dur*W,H);c.globalAlpha=1}
 for(var i=0;i<n;i++){var h=Math.max(3,p[i]*H*.92);c.fillStyle=(i/n<=pos)?css("--ac"):css("--mu");c.globalAlpha=(i/n<=pos)?1:.45;c.fillRect(i*bw+1,(H-h)/2,Math.max(1.5,bw-2),h)}
 c.globalAlpha=1;c.fillStyle=css("--rec");c.fillRect(pos*W-1,0,2,H);
 if(A!==null){c.fillStyle=css("--tx");c.fillRect(A/dur*W-1,0,2,H)}if(B!==null){c.fillStyle=css("--tx");c.fillRect(B/dur*W-1,0,2,H)}
 $("pcur").textContent=bn(mmss(au?au.currentTime:0));
 if(looping&&A!==null&&B!==null&&au&&au.currentTime>=B){au.currentTime=A}
 praf=requestAnimationFrame(drawPlayer);
}
function drawAll(){drawLive();if(cur==="det")drawPlayer()}

/* সংশোধন */
function userDict(){return C.parseDict(S.dict)}
function showRes(r,title){
 var el=$("dres");el.style.display="block";
 if(r.err){el.innerHTML="⚠️ "+esc(r.err);return}
 if(!r.count){el.innerHTML="✅ "+title+": কোনো সংশোধন লাগেনি।";return}
 var o="<b>"+title+": "+bn(r.count)+"টি শব্দ ঠিক হয়েছে</b><br>";
 r.changes.slice(0,60).forEach(function(c){o+="<mark>"+esc(c.from)+"</mark> → <b>"+esc(c.to)+"</b>"+(c.count>1?" ("+bn(c.count)+"×)":"")+"<br>"});
 el.innerHTML=o;
}
async function doSpell(){
 var t=$("dtxt").value||$("dref").value;if(!t.trim()){toast("আগে ট্রান্সক্রিপ্ট বা মূল লেখা দিন");return}
 var r=C.spellFix(t,userDict());
 if($("dtxt").value)$("dtxt").value=r.text;else $("dref").value=r.text;
 R.fixes.spell+=r.count;showRes(r,"বানান সংশোধন");await persistText();
}
async function doSpeech(){
 var r=C.alignFix($("dtxt").value,$("dref").value);
 if(!r.err){$("dtxt").value=r.text;R.fixes.speech+=r.count}
 showRes(r,"মূল লেখার সঙ্গে মেলানো");await persistText();
}
async function persistText(){R.title=$("dtitle").value.trim()||R.title;R.ref=$("dref").value;R.text=$("dtxt").value;R.words=Math.max(C.wordCount(R.text),C.wordCount(R.ref));await dbPut(R)}

/* এক্সপোর্ট */
function dl(blob,name){var a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){document.body.removeChild(a)},500)}
function safe(n){return (n||"rec").replace(/[\\/:*?"<>|]+/g,"_")}
function fullText(){return (R.title+"\n"+dstr(R.created)+"\n\n"+(R.text||R.ref||""))}
async function share(){
 try{var f=new File([R.wav],safe(R.title)+".wav",{type:"audio/wav"});
  if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f],title:R.title});return}
 }catch(e){}
 toast("এই ডিভাইসে সরাসরি শেয়ার চলছে না; WAV ডাউনলোড করুন।")
}

/* হিসাব */
async function renderStat(){
 var all=await dbAll(),tot=0,w=0,fx=0,fin=[];
 all.forEach(function(r){tot+=r.dur||0;w+=r.words||Math.max(C.wordCount(r.text),C.wordCount(r.ref));fx+=(r.fixes?r.fixes.spell+r.fixes.speech:0);if(r.fin)fin.push(r.title)});
 $("k1").textContent=bn(mmss(tot));$("k2").textContent=bn(w);$("k3").textContent=bn(fx);$("k4").textContent=bn(fin.length);
 $("kfin").innerHTML=fin.length?fin.map(esc).join("<br>"):"এখনো কোনো অধ্যায় শেষ করা হয়নি।";
 var rec=all.sort(function(a,b){return b.created-a.created}).slice(0,10);
 $("krec").innerHTML=rec.length?rec.map(function(r){return '<div class="it" style="cursor:default"><div style="flex:1"><b>'+esc(r.title)+'</b><small>'+dstr(r.created)+'</small></div><small>'+bn(mmss(r.dur))+'</small></div>'}).join(""):'<span class="mu">কিছু নেই</span>';
}
async function renderSet(){
 applyTheme();$("fsv").textContent=bn(S.fs)+" px";$("fsr").value=S.fs;$("cdict").value=S.dict||"";
 try{if(navigator.storage&&navigator.storage.estimate){var e=await navigator.storage.estimate();$("stor").textContent="সংরক্ষণ ব্যবহার: "+bn((e.usage/1048576).toFixed(1))+" MB / "+bn((e.quota/1048576).toFixed(0))+" MB"}}catch(x){}
}
async function backup(){var all=await dbAll();var d={v:1,dict:S.dict,items:all.map(function(r){return {title:r.title,created:r.created,dur:r.dur,ref:r.ref,text:r.text,fixes:r.fixes,fin:r.fin,words:r.words}})};dl(new Blob([JSON.stringify(d)],{type:"application/json"}),"swarpath-backup.json")}
function restore(f){var rd=new FileReader();rd.onload=async function(){try{var d=JSON.parse(rd.result);if(d.dict)S.dict=d.dict;saveS();toast("পুনরুদ্ধার হয়েছে: সেটিংস ও বানান-তালিকা (অডিও আলাদা)")}catch(e){toast("ফাইলটি পড়া যায়নি")}};rd.readAsText(f)}

/* ===== সংযোগ ===== */
function init(){
 applyTheme();
 $("thb").onclick=cycleTheme;
 var nb=document.querySelectorAll("nav button");for(var i=0;i<nb.length;i++)nb[i].onclick=function(){show(this.getAttribute("data-v"))};
 $("rbtn").onclick=toggleRec;$("pbtn").onclick=pauseRec;$("tbtn").onclick=retake;
 chipSet("nz",S.nz,function(v){S.nz=v;saveS()});chipSet("lb",S.lb,function(v){S.lb=parseFloat(v);saveS()});
 $("rref").oninput=function(){$("rwc").textContent=C.wordCount(this.value)?bn(C.wordCount(this.value))+" শব্দ":""};
 $("rdopen").onclick=openRd;$("rdx").onclick=function(){$("rd").classList.remove("on")};
 $("rda").onclick=function(){fsChange(-2)};$("rdp").onclick=function(){fsChange(2)};$("rdth").onclick=cycleTheme;
 $("rdrec").onclick=toggleRec;$("rdtk").onclick=retake;
 $("dback").onclick=function(){if(au)au.pause();show("lib")};
 $("pplay").onclick=function(){if(au.paused)au.play();else au.pause()};
 $("b10").onclick=function(){seek(-10)};$("f10").onclick=function(){seek(10)};
 $("spd").onchange=function(){if(au)au.playbackRate=parseFloat(this.value)};
 $("la").onclick=function(){A=au.currentTime;if(B!==null&&B<=A)B=null;lst()};
 $("lb2").onclick=function(){if(A===null){toast("আগে A চিহ্ন দিন");return}B=au.currentTime;if(B<=A){B=null;toast("B চিহ্ন A-এর পরে হতে হবে");return}looping=true;au.currentTime=A;au.play();lst()};
 $("lc").onclick=function(){A=B=null;looping=false;lst()};
 $("l10").onclick=function(){var e=au.currentTime;A=Math.max(0,e-10);B=e;looping=true;au.currentTime=A;au.play();lst()};
 function lst(){$("lstat").textContent=(A!==null?"A: "+bn(mmss(A)):"")+(B!==null?"  B: "+bn(mmss(B))+(looping?"  🔁 লুপ চলছে":""):"")}
 $("pw").onclick=function(e){var r=this.getBoundingClientRect();au.currentTime=((e.clientX-r.left)/r.width)*(au.duration||R.dur)};
 $("dfin").onclick=async function(){R.fin=!R.fin;this.textContent=R.fin?"✅ অধ্যায় শেষ":"☐ অধ্যায় শেষ";await persistText();toast(R.fin?"অধ্যায় শেষ হিসেবে চিহ্নিত":"চিহ্ন সরানো হয়েছে")};
 $("cs").onclick=doSpell;$("cv").onclick=doSpeech;$("dsave").onclick=async function(){await persistText();toast("সংরক্ষিত")};
 $("dtitle").onchange=persistText;
 $("xwav").onclick=function(){dl(R.wav,safe(R.title)+".wav")};
 $("xtxt").onclick=function(){dl(new Blob([fullText()],{type:"text/plain;charset=utf-8"}),safe(R.title)+".txt")};
 $("xdoc").onclick=function(){dl(new Blob(['<html><head><meta charset="utf-8"></head><body style="font-family:Noto Sans Bengali,sans-serif"><h2>'+esc(R.title)+'</h2><p>'+esc(dstr(R.created))+'</p><p>'+esc(R.text||R.ref||"").replace(/\n/g,"<br>")+'</p></body></html>'],{type:"application/msword"}),safe(R.title)+".doc")};
 $("xshare").onclick=share;
 $("xdel").onclick=async function(){var b=this;if(!delArm){delArm=1;b.textContent="⚠️ নিশ্চিত? আবার চাপুন";setTimeout(function(){delArm=0;b.textContent="🗑 রেকর্ডিং মুছুন"},4000);return}delArm=0;b.textContent="🗑 রেকর্ডিং মুছুন";if(au)au.pause();await dbDel(R.id);R=null;toast("মুছে ফেলা হয়েছে");show("lib")};
 chipSet("thc",S.theme,function(v){S.theme=v;saveS();applyTheme();drawAll()});
 $("fsr").oninput=function(){S.fs=parseInt(this.value,10);$("fsv").textContent=bn(S.fs)+" px";saveS()};
 $("cdsave").onclick=function(){S.dict=$("cdict").value;saveS();toast("সংরক্ষিত")};
 $("bk").onclick=backup;$("bkf").onchange=function(){if(this.files[0])restore(this.files[0])};
 setUi();drawLive();
 if("serviceWorker" in navigator&&location.protocol.indexOf("http")===0)navigator.serviceWorker.register("sw.js");
}
dbOpen().then(init).catch(function(){document.body.insertAdjacentHTML("afterbegin",'<p style="padding:20px">এই ব্রাউজারে ডাটাবেস চালু করা যায়নি।</p>')});
})();
