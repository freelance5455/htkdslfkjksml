const $=id=>document.getElementById(id);
const chat=$("chat"), statusEl=$("status"), wave=$("wave");
let endpoint="", apiKey="", model="your-model-name", recognition=null, listening=false;
let soundEnabled=true;
function sfx(name){if(!soundEnabled)return;const a=new Audio("assets/sfx/"+name+".wav");a.volume=.42;a.play().catch(()=>{});}
window.addEventListener("load",()=>setTimeout(()=>sfx("startup"),450));
function status(s){statusEl.textContent=s.toUpperCase()}
function add(text,who="bot"){sfx(who==="user"?"click":"response");const el=document.createElement("div");el.className="message "+who;el.textContent=text;chat.appendChild(el);chat.scrollTop=chat.scrollHeight;return el}
function speak(text){if(!("speechSynthesis" in window))return; speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=1;u.pitch=1; speechSynthesis.speak(u)}
function openSearch(q,site=""){const url=site==="youtube"?"https://www.youtube.com/results?search_query="+encodeURIComponent(q):"https://www.google.com/search?q="+encodeURIComponent(q);window.open(url,"_blank")}
function handleCommand(raw){const t=raw.trim();const low=t.toLowerCase();if(!t)return;
 if(low==="open youtube"||low==="youtube"){window.open("https://www.youtube.com","_blank");return "Opening YouTube."}
 if(low.startsWith("search youtube for ")){const q=t.slice(19);openSearch(q,"youtube");return "Searching YouTube for "+q}
 if(low.startsWith("search for ")||low.startsWith("google ")){const q=t.replace(/^search for |^google /i,"");openSearch(q);return "Searching the web for "+q}
 if(low==="open google"){window.open("https://www.google.com","_blank");return "Opening Google."}
 if(low==="open maps"){window.open("https://maps.google.com","_blank");return "Opening Google Maps."}
 if(low==="open telegram"){window.open("https://t.me","_blank");return "Opening Telegram."}
 if(low==="open instagram"){window.open("https://www.instagram.com","_blank");return "Opening Instagram."}
 return null;
}
async function ask(text){
 add(text,"user");$("prompt").value="";
 const command=handleCommand(text);if(command){add(command);speak(command);return}
 if(!endpoint||!apiKey){const msg="AI is not connected yet. Open Settings and add your API endpoint, key and model. You can still use commands such as: 'open YouTube' or 'search YouTube for Minecraft builds'.";add(msg);speak(msg);return}
 const bubble=add("Thinking…");
 status("Thinking");sfx("listen");
 try{
  const r=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json","Authorization":"Bearer "+apiKey},body:JSON.stringify({model,messages:[{role:"system",content:"You are JARVIS V9, a helpful phone assistant. Be concise. You cannot control other apps, read contacts, send messages, or change device settings from this web page. Explain limitations honestly."},{role:"user",content:text}],temperature:.7})});
  if(!r.ok)throw new Error("API error "+r.status);
  const data=await r.json();const answer=data.choices?.[0]?.message?.content||data.output_text||"The API returned no readable text.";
  bubble.textContent=answer;speak(answer);
 }catch(e){bubble.textContent="Connection failed: "+e.message+". Check the endpoint, model, key and internet connection."}
 finally{status("System ready")}
}
$("composer").addEventListener("submit",e=>{e.preventDefault();ask($("prompt").value)});
document.querySelectorAll("[data-action]").forEach(b=>b.addEventListener("click",()=>{const a=b.dataset.action;const urls={youtube:"https://www.youtube.com",google:"https://www.google.com",maps:"https://maps.google.com",telegram:"https://t.me"};window.open(urls[a],"_blank")}));
$("settingsBtn").onclick=()=>{$("settings").showModal();sfx("click")};
$("closeSettings").onclick=()=>$("settings").close();
$("soundToggle").onchange=()=>{soundEnabled=$("soundToggle").checked;sfx("click")};
$("saveSettings").onclick=()=>{endpoint=$("endpoint").value.trim();apiKey=$("apiKey").value.trim();model=$("model").value.trim();$("settings").close();add("Settings saved for this session. API key is not saved permanently.");};
function startListening(){
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){add("Speech recognition is not supported in this browser. Try Chrome, or type your request.");return}
 if(recognition){try{recognition.stop()}catch(e){}}
 recognition=new SR();recognition.lang="en-US";recognition.continuous=false;recognition.interimResults=false;
 recognition.onstart=()=>{sfx("listen");listening=true;status("Listening");wave.classList.add("active");$("micBtn").textContent="🎙 LISTENING…"};
 recognition.onresult=e=>{const heard=e.results[0][0].transcript;$("prompt").value=heard;ask(heard)};
 recognition.onerror=e=>{sfx("error");add("Microphone error: "+e.error+". Check browser microphone permission.");};
 recognition.onend=()=>{listening=false;wave.classList.remove("active");$("micBtn").textContent="🎙 START LISTENING";status("System ready")};
 recognition.start();
}
$("micBtn").onclick=startListening;
$("stopBtn").onclick=()=>{if(recognition)recognition.stop();if("speechSynthesis"in window)speechSynthesis.cancel();status("Voice stopped")};
if("serviceWorker"in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("sw.js").catch(()=>{});
