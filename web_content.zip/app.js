const screen=document.getElementById('screen'), toast=document.getElementById('toast');
const phone='5521975613428';
let state=JSON.parse(localStorage.getItem('pinturize_state')||'null')||{orders:[],form:{}};
const save=()=>localStorage.setItem('pinturize_state',JSON.stringify(state));
const money=v=>v?new Intl.NumberFormat('pt-BR',{style:'currency',currency:'BRL'}).format(v):'—';
function showToast(t){toast.textContent=t;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2500)}
function navActive(id){document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.screen===id))}
function render(id='home'){
 navActive(id);
 const views={home,services,orders,contact,request,service,measure,photos,address,customer,review,sent,detail,quote,profile};
 (views[id]||home)();
 window.scrollTo(0,0);
}
function home(){screen.innerHTML=`<section class="hero"><img src="assets/logo-pinturize.jpg"><h1>Solicite seu orçamento</h1><p>Qualidade, confiança e profissionalismo.</p></section>
<div class="grid">
<button class="card-btn" onclick="render('request')"><span class="emoji">📝</span>Solicitar orçamento</button>
<button class="card-btn" onclick="render('services')"><span class="emoji">🛠️</span>Nossos serviços</button>
<button class="card-btn" onclick="render('photos')"><span class="emoji">📸</span>Enviar fotos</button>
<button class="card-btn" onclick="render('orders')"><span class="emoji">📋</span>Meus pedidos</button>
</div><br><button class="success" onclick="whatsapp()">💬 Falar com a Pinturize</button>
<div class="notice" style="margin-top:16px">Faça seu pedido pelo celular, envie fotos e acompanhe o andamento do orçamento.</div>`}
function services(){const items=[['🏠','Pintura residencial','Casas e apartamentos'],['🏢','Pintura comercial','Lojas e empresas'],['🏗️','Pintura predial','Prédios e condomínios'],['🖌️','Pintura interna','Ambientes internos'],['🏡','Pintura externa','Fachadas e áreas externas'],['🚪','Portões','Portões e estruturas'],['🏠','Telhados','Pintura e proteção'],['🔧','Manutenção','Reparos e manutenção'],['💧','Impermeabilização','Proteção contra umidade'],['➕','Outro serviço','Conte o que precisa']];screen.innerHTML=`<h2>Nossos serviços</h2><p class="sub">Escolha um serviço para iniciar seu orçamento.</p><div class="service-list">${items.map(x=>`<button class="service" onclick="startService('${x[1]}')"><span>${x[0]} <b>${x[1]}</b><small>${x[2]}</small></span><span>›</span></button>`).join('')}</div>`}
function startService(s){state.form={service:s};save();render('measure')}
function request(){screen.innerHTML=`<h2>Solicitar orçamento</h2><p class="sub">Vamos montar seu pedido em poucos passos.</p><div class="service-list">
<button class="service" onclick="render('services')">🎨 <b>Escolher serviço</b><span>›</span></button>
<button class="service" onclick="render('measure')">📐 <b>Informar medidas</b><span>›</span></button>
<button class="service" onclick="render('photos')">📸 <b>Adicionar fotos</b><span>›</span></button>
<button class="service" onclick="render('address')">📍 <b>Informar endereço</b><span>›</span></button>
<button class="service" onclick="render('customer')">👤 <b>Meus dados</b><span>›</span></button></div>`}
function measure(){let f=state.form;screen.innerHTML=`<h2>Medidas do serviço</h2><p class="sub">Essas informações ajudam na análise.</p>
${input('largura','Largura (m)',f.largura||'','Ex.: 5')}${input('altura','Altura (m)',f.altura||'','Ex.: 3')}${input('comprimento','Comprimento (m)',f.comprimento||'','Ex.: 10')}
<div class="form-group"><label>Quantidade de cômodos</label><select id="comodos"><option value="">Selecione</option>${[1,2,3,4,5,6,7,8,9,10].map(n=>`<option ${f.comodos==n?'selected':''}>${n}</option>`).join('')}</select></div>
${input('area','Área aproximada (m²)',f.area||'','Ex.: 50')}<div class="notice">A área é uma estimativa. O orçamento final depende da avaliação da Pinturize.</div>
<div class="actions"><button class="secondary" onclick="render('services')">Voltar</button><button class="primary" onclick="saveMeasure()">Continuar</button></div>`}
function saveMeasure(){['largura','altura','comprimento','area'].forEach(k=>state.form[k]=document.getElementById(k).value);state.form.comodos=document.getElementById('comodos').value;save();render('photos')}
function photos(){screen.innerHTML=`<h2>Fotos do serviço</h2><p class="sub">Envie fotos do local para ajudar na análise.</p><div class="form-group"><label>Adicionar fotos</label><input id="photosInput" type="file" accept="image/*" multiple></div><div id="previews" class="photo-grid"></div><div class="actions"><button class="secondary" onclick="render('measure')">Voltar</button><button class="primary" onclick="render('address')">Continuar</button></div>`;
document.getElementById('photosInput').onchange=e=>{const p=document.getElementById('previews');p.innerHTML='';[...e.target.files].slice(0,6).forEach(file=>{const r=new FileReader();r.onload=()=>p.innerHTML+=`<img src="${r.result}">`;r.readAsDataURL(file)});state.form.photoNames=[...e.target.files].map(x=>x.name);save()}}
function address(){let f=state.form;screen.innerHTML=`<h2>Local do serviço</h2>${input('cep','CEP',f.cep||'','00000-000')}${input('endereco','Endereço',f.endereco||'','Rua, avenida...')}${input('numero','Número',f.numero||'','123')}${input('complemento','Complemento',f.complemento||'','Apartamento, casa...')}${input('bairro','Bairro',f.bairro||'','Centro')}${input('cidade','Cidade',f.cidade||'','Rio de Janeiro')}<div class="actions"><button class="secondary" onclick="render('photos')">Voltar</button><button class="primary" onclick="saveAddress()">Continuar</button></div>`}
function saveAddress(){['cep','endereco','numero','complemento','bairro','cidade'].forEach(k=>state.form[k]=document.getElementById(k).value);save();render('customer')}
function customer(){let f=state.form;screen.innerHTML=`<h2>Seus dados</h2>${input('nome','Nome completo',f.nome||'','Seu nome')}${input('whatsapp','WhatsApp',f.whatsapp||'','(21) 99999-9999')}${input('email','E-mail',f.email||'','seu@email.com')}${input('doc','CPF/CNPJ (opcional)',f.doc||'','000.000.000-00')}<div class="actions"><button class="secondary" onclick="render('address')">Voltar</button><button class="primary" onclick="saveCustomer()">Continuar</button></div>`}
function saveCustomer(){['nome','whatsapp','email','doc'].forEach(k=>state.form[k]=document.getElementById(k).value);save();render('review')}
function review(){let f=state.form;screen.innerHTML=`<h2>Resumo do pedido</h2><div class="summary">${row('Serviço',f.service||'Não informado')}${row('Área aproximada',f.area?f.area+' m²':'Não informada')}${row('Cômodos',f.comodos||'—')}${row('Endereço',`${f.endereco||''}, ${f.numero||''} — ${f.bairro||''} — ${f.cidade||''}`)}${row('Cliente',f.nome||'—')}${row('WhatsApp',f.whatsapp||'—')}${row('Fotos',f.photoNames?.length?f.photoNames.length+' arquivo(s)':'Nenhuma')}</div><br><div class="form-group"><label>Descrição do serviço</label><textarea id="desc" placeholder="Conte mais detalhes...">${f.desc||''}</textarea></div><div class="actions"><button class="secondary" onclick="render('customer')">Voltar</button><button class="success" onclick="sendOrder()">Enviar pedido</button></div>`}
function sendOrder(){state.form.desc=document.getElementById('desc').value;const n='PNT-'+new Date().getFullYear()+'-'+String(Date.now()).slice(-6);const order={id:n,...state.form,status:'Em análise',date:new Date().toLocaleString('pt-BR')};state.orders.unshift(order);state.form={};save();render('sent');}
function sent(){const id=state.orders[0]?.id||'PNT-000000';screen.innerHTML=`<div style="text-align:center;padding:35px 5px"><div style="font-size:65px">✅</div><h2>Pedido enviado!</h2><p>Recebemos sua solicitação com sucesso.</p><div class="summary"><b>Número do pedido</b><h2>${id}</h2></div><br><button class="primary" onclick="render('orders')">Ver meus pedidos</button><br><br><button class="secondary" onclick="render('home')">Voltar ao início</button></div>`}
function orders(){if(!state.orders.length){screen.innerHTML=`<h2>Meus pedidos</h2><div class="empty">Você ainda não possui pedidos.<br><br><button class="primary" onclick="render('request')">Solicitar orçamento</button></div>`;return}screen.innerHTML=`<h2>Meus pedidos</h2>${state.orders.map(o=>`<button class="order-card" style="width:100%;text-align:left;background:#fff" onclick="openOrder('${o.id}')"><b>${o.id}</b><br><span class="sub">${o.service}</span><br><span class="badge">${o.status}</span> <small>${o.date}</small></button>`).join('')}`}
function openOrder(id){const o=state.orders.find(x=>x.id===id);if(!o)return;screen.innerHTML=`<h2>${o.id}</h2><div class="summary">${row('Serviço',o.service)}${row('Cliente',o.nome)}${row('Local',`${o.endereco}, ${o.numero} — ${o.cidade}`)}${row('Descrição',o.desc||'—')}</div><h3>Acompanhamento</h3>${status('Recebido',true)}${status('Em análise',o.status==='Em análise'||o.status==='Orçamento enviado'||o.status==='Aprovado'||o.status==='Concluído')} ${status('Orçamento enviado',o.status==='Orçamento enviado'||o.status==='Aprovado'||o.status==='Concluído')} ${status('Aprovado',o.status==='Aprovado'||o.status==='Concluído')} ${status('Concluído',o.status==='Concluído')}<button class="success" onclick="whatsapp('Olá, gostaria de falar sobre o pedido '+o.id)">💬 Tirar dúvidas</button>`}
function quote(){screen.innerHTML=`<h2>Orçamento</h2><div class="summary">${row('Serviço','A definir pela Pinturize')}${row('Mão de obra','A definir')}${row('Materiais','A definir')}<div class="row"><b>Total</b><b>R$ —</b></div></div><div class="notice">O valor será disponibilizado pela Pinturize após a análise do seu pedido.</div>`}
function contact(){screen.innerHTML=`<h2>Fale conosco</h2><div class="contact-box"><a class="card-btn" href="https://wa.me/${phone}" target="_blank">🟢 WhatsApp<br><small>(21) 97561-3428 — toque para conversar</small></a><div class="card-btn">📞 (21) 97561-3428</div><div class="card-btn">🏢 CNPJ: 64.722.773/0001-64</div></div><br><button class="success" onclick="whatsapp()">Falar pelo WhatsApp</button>`}
function profile(){screen.innerHTML=`<h2>Meu perfil</h2><div class="summary"><h3>${state.form.nome||'Cliente'}</h3><p>${state.form.email||'E-mail não informado'}</p><p>${state.form.whatsapp||'WhatsApp não informado'}</p></div>`}
function input(id,label,value,ph){return `<div class="form-group"><label>${label}</label><input id="${id}" value="${String(value).replace(/"/g,'&quot;')}" placeholder="${ph}"></div>`}
function row(a,b){return `<div class="row"><b>${a}</b><span>${b}</span></div>`}
function status(t,on){return `<div class="status"><span class="dot ${on?'active':''}"></span><div><b>${t}</b><br><small>${on?'Etapa registrada':'Aguardando'}</small></div></div>`}
function saveAddress(){}
function whatsapp(msg='Olá! Gostaria de solicitar um orçamento com a Pinturize Pinturas e Manutenção.'){window.open('https://wa.me/'+phone+'?text='+encodeURIComponent(msg),'_blank')}
document.getElementById('backBtn').onclick=()=>history.length>1?history.back():render('home');
document.getElementById('menuBtn').onclick=()=>showToast('Use o menu inferior para navegar.');
document.querySelectorAll('.bottom-nav button').forEach(b=>b.onclick=()=>render(b.dataset.screen));
render('home');
