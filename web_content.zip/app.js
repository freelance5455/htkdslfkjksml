const T=window.__TAURI__,W=T.window.getCurrentWindow(),{LogicalSize,LogicalPosition}=T.dpi;
const $=i=>document.getElementById(i);
const LS={g(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c])),clean=s=>String(s).replace(/[<>&"'`]/g,"").slice(0,40);
const CFG=window.PROTWAVE_CFG||{},VER="1.0.0";
let L=[],spent=0,pct=0,isOpen=false,det=false,lastBase=0,cur="",files=0,imgs=[],note="",detSteps=0,timer,BK="prose",obStep=-1,ledgerUpdated="",EX={},shortInfo=null,piiInfo=null,maskOn=1,animId=0,fbLast=0,
 cal=LS.g('cal',{}),hist=LS.g('hist',[]),st=Object.assign({saved:0,tok:0},LS.g('st',{}));
const sleep=ms=>new Promise(r=>setTimeout(r,ms)),RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
function countUp(el,to){if(!el)return;el.textContent=to.toLocaleString();if(RM)return;const from=Math.round(to*.6),t0=performance.now();(function f(t){const p=Math.min(1,(t-t0)/260),e=1-Math.pow(1-p,3);el.textContent=Math.round(from+(to-from)*e).toLocaleString();if(p<1)requestAnimationFrame(f);else el.textContent=to.toLocaleString()})(t0);setTimeout(()=>{el.textContent=to.toLocaleString()},700)}
const baseCache=new Map();
let ledgerSrc="bundled with this app",hfOk=true,runId=0,shownK=-1,lastCalc=null,scanSkip=false,rq=0,monC=null,monT=0;const PIIMAX=1500000,MAXC=1500000,ERR=[],NET=[];
addEventListener('error',e=>ERR.push(String(e.message)));addEventListener('unhandledrejection',e=>ERR.push(String(e.reason)));
// Every network call goes through here so the user can see exactly what Protwave contacted (Privacy & data > Network log).
async function nfetch(purpose,url,opts){let ok=false;try{const r=await fetch(url,opts);ok=r.ok;return r}finally{try{const u=new URL(url,location.href);NET.push({t:new Date(),purpose,host:u.host,path:u.pathname,ok});if(NET.length>40)NET.shift()}catch(e){}}}
const rr=()=>{if(rq)return;rq=requestAnimationFrame(()=>{rq=0;cur&&render(false)})};
const sv=()=>LS.s('st',st),CJK="\\u3040-\\u30ff\\u3400-\\u9fff\\uac00-\\ud7af";
// ---------- window: invisible until used ----------
async function mon(){if(monC&&Date.now()-monT<3000)return monC;const m=await T.window.currentMonitor(),s=m.scaleFactor;monT=Date.now();return monC={s,x:m.position.x/s,y:m.position.y/s,w:m.size.width/s,h:m.size.height/s}}
async function placeAt(w,h,c){const M=await mon();let x,y;
 if(c&&c[0]!=null){const cx=c[0]/M.s,cy=c[1]/M.s;if(cx>=M.x&&cx<M.x+M.w&&cy>=M.y&&cy<M.y+M.h){x=cx+14;y=cy+14}}
 if(x==null){x=M.x+M.w-w-16;y=M.y+M.h-h-64}
 x=Math.max(M.x+8,Math.min(x,M.x+M.w-w-8));y=Math.max(M.y+8,Math.min(y,M.y+M.h-h-8));
 await Promise.all([W.setSize(new LogicalSize(w,h)),W.setPosition(new LogicalPosition(x,y))])}
const dims=async()=>{const M=await mon(),c=$('card');return{M,w:Math.max(360,c.scrollWidth+24),h:Math.min(M.h-60,c.offsetHeight+16)}};
// Resize to content with a short ease; keeps the top-left corner and nudges up if it would leave the screen.
async function fit(){await new Promise(r=>requestAnimationFrame(r));const{M,w,h}=await dims(),p=await W.outerPosition(),z=await W.outerSize(),s=M.s,x0=p.x/s,y0=p.y/s,w0=z.width/s,h0=z.height/s,id=++animId;
 const ny=Math.max(M.y+8,Math.min(y0,M.y+M.h-h-8)),nx=Math.max(M.x+8,Math.min(x0,M.x+M.w-w-8));
 if(Math.abs(w-w0)+Math.abs(h-h0)<4){await W.setSize(new LogicalSize(w,h));return}
 for(let i=1;i<=6&&id===animId;i++){const t=1-Math.pow(1-i/6,3);await W.setSize(new LogicalSize(w0+(w-w0)*t,h0+(h-h0)*t));await W.setPosition(new LogicalPosition(x0+(nx-x0)*t,y0+(ny-y0)*t))}}
async function open(c){$('card').classList.add('on');isOpen=true;await new Promise(r=>requestAnimationFrame(r));const{w,h}=await dims();await placeAt(w,h,c);await W.show();try{await W.setFocus()}catch(e){}arm()}
async function close(){clearTimeout(timer);isOpen=false;det=false;const c=$('card');$('bar').classList.remove('go');if(!RM){c.classList.add('out');await sleep(300)}$('det').classList.remove('on'),$('card').classList.remove('mo');await W.hide();c.classList.remove('on','out')}
function arm(){clearTimeout(timer);const sec=+LS.g('ah',10),b=$('bar');b.classList.remove('go');if(isOpen&&!det&&obStep<0&&sec>0){void b.offsetWidth;b.style.animationDuration=sec+'s';b.classList.add('go');timer=setTimeout(close,sec*1000)}}
// ---------- engine ----------
function heur(t){let n=(t.match(new RegExp("["+CJK+"]","g"))||[]).length;
 (t.match(/[A-Za-z]+/g)||[]).forEach(w=>n+=w.length<=6?1:Math.ceil(w.length/4.5));
 (t.match(/\d+/g)||[]).forEach(d=>n+=Math.ceil(d.length/3));
 n+=.75*(t.match(new RegExp("[^\\sA-Za-z\\d"+CJK+"]","g"))||[]).length+.5*(t.match(/\n/g)||[]).length;return Math.ceil(n)}
async function base(t){if(baseCache.has(t))return baseCache.get(t);let n;try{n=await T.core.invoke('count_openai',{text:t})}catch(e){n=heur(t)}if(baseCache.size>30)baseCache.delete(baseCache.keys().next().value);baseCache.set(t,n);return n}
const INT=[[/summari[sz]e|tl;?dr|shorten/i,.2,150],[/translate/i,1.1,0],[/refactor|rewrite|fix|convert|proofread|edit/i,.9,0],[/classify|extract|label/i,0,80],[/write|generate|create|draft|build|implement/i,0,700],[/explain|analy[sz]e|compare|why|how/i,0,500]];
let ocal=LS.g('ocal',{}),lastOut={key:'def',v:350};
// Optional factory calibration shipped with the app (made by benchmark/fit.mjs from real measured counts); the user's own corrections always win.
fetch('seed_calibration.json').then(r=>r.ok?r.json():{}).then(x=>{for(const k in x)if(!cal[k])cal[k]=x[k]}).catch(()=>{});
// Reply length is the biggest uncertainty, so it is learned per kind of request from your own "real reply tokens" entries.
function outEst(t,n){const s=t.slice(0,800);let m,key='def',v=350;
 if(/yes or no|true or false|one word/i.test(s)){key='x';v=5}
 else if(m=s.match(/(\d+)\s*-?\s*words?\b/i)){key='x';v=Math.round(+m[1]*1.35)}
 else if(m=s.match(/(\d+)\s*sentences?/i)){key='x';v=+m[1]*28}
 else if(m=s.match(/(\d+)\s*(?:bullets?|points?|ideas?|examples?|tips?|steps?)/i)){key='x';v=+m[1]*35}
 else for(let i=0;i<INT.length;i++){const[r,k,x]=INT[i];if(r.test(s)){key='i'+i;v=Math.min(8000,Math.max(x,Math.round(n*k)));break}}
 lastOut={key,v};return Math.max(1,Math.round(v*((ocal[key]||{}).r||1)))}
function tierWhy(s,n){const d=s.length?(s.match(/[{}();=<>\[\]\/\\_]/g)||[]).length/s.length:0,kw=(s.match(/(architect|refactor|trade-?off|debug|optimi[sz]e|design|prove|analy[sz]e|migrate|security)/i)||[])[0],w=[];let sc=0;
 if(n>400){sc++;w.push('it is '+n.toLocaleString()+' tokens long')}if(n>1500)sc++;if(d>.05){sc++;w.push('it looks like code ('+Math.round(d*100)+'% symbols)')}if(kw){sc++;w.push('it mentions "'+kw.toLowerCase()+'"')}
 return{t:sc>=3?3:sc>=1?2:1,w}}
const tier=(s,n)=>tierWhy(s,n).t;
function bk(s){const n=s.length||1;if((s.match(new RegExp("["+CJK+"]","g"))||[]).length/n>.2)return"cjk";return(s.match(/[{}();=<>\[\]\/\\_]/g)||[]).length/n>.05?"code":(s.match(/\d/g)||[]).length/n>.15?"data":"prose"}
function imgTok(m){let t=0;for(const{w,h}of imgs){if(m.fam==='claude'){const s=Math.min(1,1568/Math.max(w,h));t+=Math.ceil(w*s*h*s/750)}
 else if(m.fam==='openai'){const s=Math.min(1,2048/Math.max(w,h));let a=w*s,b=h*s;const k=Math.min(1,768/Math.min(a,b));t+=85+170*Math.ceil(a*k/512)*Math.ceil(b*k/512)}
 else if(m.fam==='gemini')t+=(w<=384&&h<=384)?258:258*Math.ceil(w/768)*Math.ceil(h/768)}return t}
let FX={USD:1,EUR:.92,GBP:.78,INR:84,JPY:150},CUR=LS.g('cur','USD');const SYM={USD:"$",EUR:"€",GBP:"£",INR:"₹",JPY:"¥"};
const usd=v=>{const x=v*(FX[CUR]||1);return SYM[CUR]+x.toFixed(x<.0001?6:x<.01?4:x<1?3:2)};
const clampR=r=>Math.min(1.8,Math.max(.6,r));
// Family-aware calibration: a model's own corrections count most, and corrections on any model of the same family (same tokenizer) are borrowed until it has its own.
function calFor(m){const o=cal[m.n+"|"+BK],f=cal[m.fam+"|"+BK]||{r:1,n:0,e:.12},rf=1+(f.r-1)*f.n/(f.n+1);if(!o)return{r:rf,n:f.n,e:f.e,own:0};const w=o.n/(o.n+1.5);return{r:w*o.r+(1-w)*rf,n:o.n+f.n,e:o.e,own:o.n}}
const trimMean=h=>{const s=[...h].sort((a,b)=>a-b),t=s.length>=5?s.slice(1,-1):s;return t.reduce((a,b)=>a+b,0)/t.length};
// Robust learning: the ratio is a trimmed mean of your last 20 corrections (outliers dropped). Each stored error is an out-of-sample residual (how far off the estimate was BEFORE learning from that correction); the first two are skipped because the predictor was still a blind guess then.
function learn(k,r,err){const c=cal[k]||{r:1,n:0,e:.12},h=(c.h||(c.n?[c.r]:[])).concat(r).slice(-20),x=(c.n>=2?(c.x||[]).concat(err):(c.x||[])).slice(-40);cal[k]={r:clampR(trimMean(h)),n:c.n+1,e:x.length?x.reduce((a,b)=>a+b,0)/x.length:err,h,x}}
// Calibrated 95% range (split-conformal): after 19+ residuals the range is the 95th-percentile error, so about 95% of future true counts should fall inside it if your text resembles what you calibrated on. Before that it is provisional and wider.
function q95(m){const o=cal[m.n+"|"+BK]||{},f=cal[m.fam+"|"+BK]||{},pool=(o.x&&o.x.length>=19)?o.x:(f.x||o.x||[]),n=pool.length;
 if(n>=19){const s=pool.map(Math.abs).sort((a,b)=>a-b);return{q:Math.max(.02,s[Math.min(n-1,Math.ceil((n+1)*.95)-1)]),n,prov:false}}
 return{q:n?Math.min(.5,Math.max(.1,Math.max(...pool.map(Math.abs))*1.5)):.25,n,prov:true}}
function est(m,b){const c=calFor(m),ex=m.fam==="deepseek"&&EX.deepseek!=null,Q=(ex||m.fam==="openai")?null:q95(m),rel=ex?.02:m.fam==="openai"?.03:Q.q;return{k:ex?EX.deepseek+(b-lastBase)+imgTok(m):Math.ceil(b*m.f*c.r)+imgTok(m),rel,prov:Q?Q.prov:false,nq:Q?Q.n:0}}
const accPct=()=>hist.length?Math.round(100*(1-hist.reduce((a,b)=>a+b,0)/hist.length)):null;
// Prompt shortener: safe, local, rule-based. Skips code fences; only trims politeness/filler and whitespace.
const FILL=[[/^(?:hi|hello|hey)(?: there)?[,!.]?\s+/i,""],[/\b(?:i was wondering if|i hope this (?:message )?finds you well|if possible,?|as an ai(?: language model)?,?)\s*/gi,""],[/\b(?:please|kindly)\b,?\s*/gi,""],[/\b(?:i would like you to|i want you to|i need you to|could you please|can you please|would you mind|feel free to)\s+/gi,""],[/\bin order to\b/gi,"to"],[/\bdue to the fact that\b/gi,"because"],[/\bat this point in time\b/gi,"now"],[/\bit is important to (?:note|remember) that\s*/gi,""],[/\b(?:thanks|thank you)(?: so much)?(?: in advance)?[.!]?\s*$/gi,""],[/\bas a matter of fact\b,?\s*/gi,""]];
function shorten(t){return t.split(/(```[\s\S]*?```)/g).map((p,i)=>{if(i%2)return p;let o=p;for(const[r,x]of FILL)o=o.replace(r,x);return o}).join("").replace(/[ \t]+$/gm,"").replace(/[ ]{2,}/g," ").replace(/\n{3,}/g,"\n\n").trim()}
function diff(a,b){const x=a.split(/(\s+)/),y=b.split(/(\s+)/),n=x.length,m=y.length;if(n*m>4e6)return null;const d=Array.from({length:n+1},()=>new Uint16Array(m+1));
 for(let i=n-1;i>=0;i--)for(let j=m-1;j>=0;j--)d[i][j]=x[i]===y[j]?d[i+1][j+1]+1:Math.max(d[i+1][j],d[i][j+1]);
 let i=0,j=0,o="";while(i<n&&j<m){if(x[i]===y[j]){o+=esc(x[i]);i++;j++}else if(d[i+1][j]>=d[i][j+1]){o+="<del>"+esc(x[i++])+"</del>"}else{o+="<ins>"+esc(y[j++])+"</ins>"}}
 while(i<n)o+="<del>"+esc(x[i++])+"</del>";while(j<m)o+="<ins>"+esc(y[j++])+"</ins>";return o}
function luhn(s){const d=s.replace(/\D/g,"");if(d.length<13||d.length>16)return false;let t=0;for(let i=0;i<d.length;i++){let n=+d[d.length-1-i];if(i%2){n*=2;if(n>9)n-=9}t+=n}return t%10===0}
const PII=[[/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g,"[REDACTED_JWT]"],[/-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g,"[REDACTED_PRIVATE_KEY]"],[/\b(?:sk-[A-Za-z0-9_-]{20,}|AIza[0-9A-Za-z_-]{35}|AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{30,}|xox[abp]-[A-Za-z0-9-]{10,})/g,"[REDACTED_API_KEY]"],[/(?:^|[^A-Za-z0-9])(?:[A-Za-z0-9_-]*(?:password|passwd|secret|token|api[_-]?key|access[_-]?key|private[_-]?key)[A-Za-z0-9_-]*)["']?\s*[:=]\s*["']?[^\s"',;]{4,}/gi,m=>m.replace(/([:=]\s*["']?)[^\s"',;]{4,}$/,"$1[REDACTED_SECRET]")],[/\bBearer\s+[A-Za-z0-9._~+\/-]{16,}=*/g,"Bearer [REDACTED_TOKEN]"],[/\b[a-z][a-z0-9+.-]*:\/\/[^\s:@\/]+:[^\s@\/]+@[^\s]+/gi,"[REDACTED_CONNECTION_STRING]"],[/\b(?:sk|rk|pk)_(?:live|test)_[A-Za-z0-9]{16,}/g,"[REDACTED_API_KEY]"],[/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g,"[REDACTED_EMAIL]"],[/\b(?:\d[ -]?){13,16}\b/g,m=>luhn(m)?"[REDACTED_CARD]":m],[/\b\d{3}-\d{2}-\d{4}\b/g,"[REDACTED_SSN]"]];
function redact(t){let c=0,o=t;for(const[r,x]of PII)o=o.replace(r,(...a)=>{const v=typeof x==="function"?x(a[0]):x;if(v!==a[0])c++;return v});return{out:o,count:c}}
// ---------- signed price ledger ----------
const okModel=m=>m&&typeof m.n==="string"&&m.i>=0&&m.i<1e4&&m.o>=0&&m.o<1e4&&[1,2,3].includes(m.t)&&m.f>0&&m.f<3&&m.th>=1&&m.th<10&&(m.cr==null||(m.cr>0&&m.cr<=1));
function fillTools(sel){$('tool').innerHTML="";L.forEach((m,i)=>$('tool').add(new Option(m.n,i)));const k=L.findIndex(m=>m.n===sel);$('tool').value=k>=0?k:Math.max(0,L.findIndex(m=>m.n==='Claude Sonnet 5.5'))}
function applyLedger(j){if(!j||!Array.isArray(j.models)||j.models.length>200)return false;const ms=j.models.filter(okModel).map(m=>({...m,n:clean(m.n),fam:clean(m.fam||"other")}));if(ms.length<3)return false;
 const sel=L[+$('tool').value]&&L[+$('tool').value].n;L=ms.concat(LS.g('custom',[]));fillTools(sel);
 if(j.fx&&typeof j.fx==="object")for(const c of Object.keys(SYM))if(j.fx[c]>0&&j.fx[c]<1e5)FX[c]=j.fx[c];ledgerUpdated=j.updated||ledgerUpdated;ledgerSrc='signed update ✓';cur&&render(false);return true}
const verified=async(text,sig)=>{try{return await T.core.invoke('verify_ledger',{text,sig})}catch(e){return false}};
// Only ledgers signed with the owner's Ed25519 key (public half baked into the app) are applied; the bundled ledger is the offline fallback.
async function syncLedger(b0){ledgerUpdated=b0.updated||"";if(b0.fx)for(const c of Object.keys(SYM))if(b0.fx[c]>0)FX[c]=b0.fx[c];
 const ca=LS.g('ledger2',null);if(ca&&await verified(ca.text,ca.sig)){const j=JSON.parse(ca.text);if((j.updated||"")>(b0.updated||""))applyLedger(j)}
 if(!CFG.ledgerUrl)return;
 try{const c=new AbortController();setTimeout(()=>c.abort(),5000);const[r1,r2]=await Promise.all([nfetch('price update',CFG.ledgerUrl,{signal:c.signal,cache:"no-store"}),nfetch('price signature',CFG.ledgerUrl+".sig",{signal:c.signal,cache:"no-store"})]);if(!r1.ok||!r2.ok)return;
  const text=await r1.text(),sig=(await r2.text()).trim();if(!await verified(text,sig)){toast("Ignored a price update with a bad signature.");ledgerSrc='bundled (a tampered update was ignored)';return}
  const j=JSON.parse(text),have=(ca&&JSON.parse(ca.text).updated)||b0.updated||"";if((j.updated||"")>have&&applyLedger(j))LS.s('ledger2',{text,sig})}catch(e){}}
const stale=()=>{if(!ledgerUpdated)return"";const d=Math.floor((Date.now()-new Date(ledgerUpdated))/864e5);return d>21?` · ⚠ prices ${d}d old`:""};
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),5000)}
const footText=()=>`Session ${usd(spent)} of ${usd(+$('bud').value||1)} · est. saved ${usd(st.saved)} · ${st.tok.toLocaleString()} tokens trimmed${stale()}`;
function credit(tokens,money){st.saved+=Math.max(0,money);st.tok+=Math.max(0,tokens);sv();$('foot').textContent=footText()}
// ---------- render ----------
// Minimal card: show ONE suggestion by default (secret warning > budget alert > weak-model warning > cheaper model > shorter prompt > best-pick note). The rest wait behind "More".
// Prompt analyser: where the tokens go, what is removable, and an efficiency score. All local.
function dedupe(t){const seen=new Set();return t.split(/\n{2,}/).filter(p=>{const k=p.toLowerCase().replace(/\s+/g," ").trim();if(!k)return true;if(seen.has(k))return false;seen.add(k);return true}).join("\n\n")}
function analyse(t){const parts=t.split(/\n{2,}/).map(s=>s.trim()).filter(Boolean),w=parts.map(s=>({s,k:heur(s)})),tot=Math.max(1,w.reduce((a,x)=>a+x.k,0)),
 kind=s=>/^```/.test(s)||/^\s*[{\[]/.test(s)||(s.match(/[{}();=<>\[\]\/\\_]/g)||[]).length/s.length>.05?"code/data":/(^|\n)\s*(?:[-*•]|\d+[.)])\s/.test(s)?"list":/\?\s*$|^(?:you are|act as|your task|write|summari[sz]e|explain|translate|rewrite)/i.test(s)?"instruction":"context",
 lean=shorten(dedupe(t)),waste=Math.max(0,heur(t)-heur(lean)),by={};
 w.forEach(x=>{const k=kind(x.s);by[k]=(by[k]||0)+x.k});
 return{tot,waste,score:Math.max(0,Math.round(100*(1-waste/tot))),by,parts:w.length,dups:parts.length-dedupe(t).split(/\n{2,}/).filter(Boolean).length,
  top:w.slice().sort((a,b)=>b.k-a.k).slice(0,3).map(x=>({pct:Math.round(100*x.k/tot),kind:kind(x.s),s:x.s.replace(/\s+/g," ").slice(0,48)}))}}
function analyseHTML(){if(cur.length>PIIMAX)return"Too large to analyse.";const A=analyse(cur);
 return`<p><b>Efficiency ${A.score}%</b> · ${A.tot.toLocaleString()} tokens in ${A.parts} part${A.parts>1?"s":""}${A.waste?` · about ${A.waste} removable`:""}${A.dups?` · ${A.dups} repeated paragraph${A.dups>1?"s":""}`:""}</p><p>Where the tokens go: ${Object.entries(A.by).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`${esc(k)} ${Math.round(100*v/A.tot)}%`).join(" · ")}</p>${A.top.map(x=>`<p>${x.pct}% · ${esc(x.kind)} · “${esc(x.s)}…”</p>`).join("")}`}
function pickOne(){const pi=$('pi'),sh=$('sh'),v=$('v'),has=e=>e.innerHTML.trim()!=="";let top=null;
 if(has(pi))top=pi;else if(has(v)&&(v.classList.contains('w')||/of budget/.test(v.textContent)||v.querySelector('#sw')))top=v;else if(has(sh))top=sh;else if(has(v))top=v;
 for(const e of[pi,sh,v])e.classList.toggle('hid',e!==top)}
function render(charge){
 const ctx=+$('ctx').value||0,b=lastBase+ctx,TW=tierWhy(cur,b),a=TW.t,i=+$('tool').value,o=+$('outv').value||outEst(cur,lastBase),N=Math.max(1,+$('steps').value||detSteps||1);
 const rows=L.map((m,j)=>{const e=est(m,b),out=Math.ceil(o*m.th),tin=e.k*N+out*N*(N-1)/2,tout=out*N,crv=($('cch').checked&&m.cr)?m.cr:1,inC=m.i*(e.k+crv*((N-1)*e.k+out*N*(N-1)/2));return{m,j,k:Math.round(tin),out:tout,rel:e.rel,prov:e.prov,nq:e.nq,cf:inC/Math.max(1e-12,tin*m.i),c:(inC+tout*m.o)/1e6}}),
 ok=rows.filter(r=>r.m.t>=a).sort((x,y)=>x.c-y.c),w=ok[0]||rows[0],me=rows[i]||rows[0];
 if(charge)spent+=me.c;const bud=+$('bud').value||1;pct=spent/bud;
 $('big').innerHTML=`${(me.m.fam==="openai"||(me.m.fam==="deepseek"&&EX.deepseek!=null))?"":"~"}<span id="bn">${me.k.toLocaleString()}</span> <small>tokens · ${usd(me.c)}</small>`;if(me.k!==shownK){countUp($('bn'),me.k);shownK=me.k}else $('bn').textContent=me.k.toLocaleString();
 $('sub').textContent=`${N>1?N+" steps · ":""}${files?files+" file"+(files>1?"s":"")+" · ":""}~${me.out.toLocaleString()} reply tokens · ${(me.m.fam==="openai"||(me.m.fam==="deepseek"&&EX.deepseek!=null))?"near-exact":"95% range ±"+Math.round(me.rel*100)+"%"+(me.prov?" (provisional, "+Math.min(19,me.nq)+"/19 checks)":"")}`;
 {const e1=est(me.m,b),op=Math.ceil(o*me.m.th),c1=(e1.k*me.m.i+op*me.m.o)/1e6,cN=((e1.k+op*(N-1))*me.m.i+op*me.m.o)/1e6;$('note').textContent=(note+(scanSkip?" Over 300,000 characters: shortener and secret scan skipped.":"")+(N>1?` Step 1 ${usd(c1)} → step ${N} ${usd(cN)} (context re-sent each step).`:"")).trim()}
 $('sh').innerHTML=shortInfo?`<span>✂️ Shorter version: <b>−${shortInfo.pct}%</b> (${shortInfo.save} tokens)</span><span><button class="x" id="dfb">Diff<kbd>D</kbd></button> <button class="p" id="cp">Copy shortened<kbd>C</kbd></button></span>`:"";
 $('pi').innerHTML=piiInfo?`<span>⚠️ <b>PII detected</b>: ${piiInfo.count} item${piiInfo.count>1?"s":""} <label class="m" style="white-space:nowrap"><input type="checkbox" id="mk"${maskOn?" checked":""}> Mask</label></span><button class="p" id="rc">Copy ${maskOn?"masked":"redacted"}</button>`:"";
 const mk=$('mk');if(mk)mk.onchange=async()=>{maskOn=mk.checked?1:0;LS.s('msk',maskOn);$('msk').checked=!!maskOn;await prep();render(false)};
 const rc=$('rc');if(rc)rc.onclick=async()=>{try{await T.core.invoke('copy_text',{text:piiInfo.out});rc.textContent='✓ Copied';rc.classList.add('ok')}catch(e){rc.textContent='Failed'}};
 const dfb=$('dfb');if(dfb)dfb.onclick=()=>{$('df').innerHTML=diff(shortInfo.from.trim(),shortInfo.text)||'Too long to preview';$('df').classList.toggle('on')};
 const cp=$('cp');if(cp)cp.onclick=async()=>{if(cp.dataset.d)return;try{await T.core.invoke('copy_text',{text:shortInfo.text});cp.dataset.d=1;cp.textContent='✓ Copied';cp.classList.add('ok');credit(shortInfo.save,shortInfo.save*me.m.i/1e6)}catch(e){cp.textContent='Failed'}};
 const v=$('v');v.className=me.m.t<a?'w':'';
 if(me.m.t<a)v.innerHTML=`<span>⚠️ Too weak for this. Try ${w.m.n}</span><button class="p" id="sw">Switch<kbd>↵</kbd></button>`;
 else if(w.j==i)v.innerHTML=`<span>✅ ${me.m.n} is the best pick</span>`;
 else v.innerHTML=`<span>💡 ${w.m.n} saves ${Math.round((1-w.c/me.c)*100)}%</span><button class="p" id="sw">Switch<kbd>↵</kbd></button>`;
 if(pct>=.8)v.innerHTML+=`<span>🚨 ${Math.round(pct*100)}% of budget</span>`;
 const sw=$('sw');if(sw)sw.onclick=()=>{credit(0,me.c-w.c);$('tool').value=w.j;LS.s('tool2',w.j);render(false)};
 pickOne();$('anb').innerHTML=analyseHTML();$('tbl').innerHTML="<tr><th>Tool</th><th>In/Out</th><th>Cost</th></tr>"+rows.sort((x,y)=>x.c-y.c).map(r=>`<tr class="${r.j==i?'s':''}" title="$${r.m.i} in / $${r.m.o} out per 1M tokens"><td>${r.m.n}${(r.m.fam==="openai"||(r.m.fam==="deepseek"&&EX.deepseek!=null))?'':' <span class="m">~</span>'}${r.j==w.j?' ★':''}</td><td>${r.k.toLocaleString()}/${r.out.toLocaleString()}</td><td>${usd(r.c)}</td></tr>`).join("");
 {const sp=.4/(1+.5*((ocal[lastOut.key]||{}).n||0)),lo=(me.k*me.cf*(1-me.rel)*me.m.i+me.out*(1-sp)*me.m.o)/1e6,hi=(me.k*me.cf*(1+me.rel)*me.m.i+me.out*(1+1.5*sp)*me.m.o)/1e6;$('spent').textContent=`Likely range ${usd(lo)} to ${usd(hi)} · measured accuracy: ${accPct()===null?'n/a (calibrate to measure)':accPct()+'%'}`}$('foot').textContent=footText();lastCalc={me,w,a,o,N,b,tw:TW.w};if($('why').open)fillWhy()}
async function prep(){shortInfo=null;scanSkip=cur.length>PIIMAX;$('df').classList.remove('on');if(scanSkip){piiInfo=null;return}
 const rd=redact(cur);piiInfo=rd.count?rd:null;const src=maskOn&&piiInfo?rd.out:cur;
 if(!files){const sh=shorten(src);if(sh!==src.trim()){const b2=await base(sh),b1=await base(src),sv2=b1-b2;if(sv2>=8&&sv2/b1>=.05)shortInfo={text:sh,from:src,save:sv2,pct:Math.round(sv2/b1*100)}}}}
async function run(t,c){cur=t||" ";let trunc=false;if(cur.length>MAXC){cur=cur.slice(0,MAXC);trunc=true}
 BK=bk(cur);const n=(cur.match(/^\s*(?:step\s*\d+[:.)]?|\d+[.)])\s/gim)||[]).length;detSteps=n>=2?n:0;$('steps').placeholder=detSteps||1;
 $('ob').hidden=true;$('card').classList.remove('onb');shownK=-1;EX={};shortInfo=piiInfo=null;
 if(trunc)note=(note+" Large selection: only the first "+MAXC.toLocaleString()+" characters were counted.").trim();
 lastBase=await base(cur);render(true);await open(c);
 // Show the answer first; the heavier extras (exact DeepSeek count, shortener, secret scan) fill in a moment later.
 const id=++runId;(async()=>{if(hfOk){try{EX.deepseek=await T.core.invoke('count_hf',{name:'deepseek',text:cur})}catch(e){hfOk=false}}await prep();if(id===runId)render(false)})()}
const INTN={x:'a length you stated',def:'a general request',i0:'summarising',i1:'translating',i2:'editing or refactoring',i3:'classifying or extracting',i4:'writing something new',i5:'explaining or analysing'};
function fillWhy(){const c=lastCalc;if(!c){$('whyb').textContent='Select some text first.';return}
 const{me,w,a,o,N,b,tw}=c,m=me.m,cl=calFor(m),ex=m.fam==="deepseek"&&EX.deepseek!=null,oc=ocal[lastOut.key]||{r:1,n:0},ctx=+$('ctx').value||0,li=[];
 li.push(m.fam==="openai"?`<b>Input:</b> counted with the OpenAI tokenizer on this device (near-exact): ${lastBase.toLocaleString()} tokens${ctx?` + ${ctx.toLocaleString()} already in chat`:""}.`
  :ex?`<b>Input:</b> counted with the bundled ${esc(m.n)} tokenizer (near-exact).`
  :`<b>Input (estimate):</b> OpenAI-tokenizer count ${b.toLocaleString()} × family prior ${m.f} × your calibration ${cl.r.toFixed(2)} (${cl.n} sample${cl.n===1?"":"s"} for ${BK} text). ${esc(m.fam)} doesn't publish its tokenizer, so expect about ±${Math.round(me.rel*100)}%.`);
 if(imgs.length)li.push(`<b>Images:</b> ${imgs.length} counted by size using the ${esc(m.fam)} formula, since only dimensions are read.`);
 li.push(`<b>Reply:</b> about ${o.toLocaleString()} tokens, because this looks like ${INTN[lastOut.key]||'a general request'}${oc.n?` (adjusted ×${oc.r.toFixed(2)} from your ${oc.n} real entr${oc.n===1?"y":"ies"})`:""}. Hidden thinking ×${m.th} makes the billed output ${Math.ceil(o*m.th).toLocaleString()}.`);
 if(N>1)li.push(`<b>Agent steps:</b> ${N}. Each step re-sends the prompt and earlier replies${$('cch').checked&&m.cr?`, priced at ${Math.round(m.cr*100)}% because you said the context is cached`:""}.`);
 li.push(`<b>Price:</b> $${m.i} in / $${m.o} out per 1M tokens (list price, no discounts). Price list: ${esc(ledgerSrc)}, dated ${esc(ledgerUpdated)}.`);
 li.push(`<b>Pick:</b> this task looks ${['','light','moderate','heavy'][a]}${tw.length?` because ${tw.join(', ')}`:" because it is short and simple"}. Cheapest model rated for that: ${esc(w.m.n)}.`);
 li.push(`<i>Estimates, not invoices. Compare with your provider's usage page.</i>`);
 $('whyb').innerHTML=`<ul>${li.map(x=>`<li>${x}</li>`).join("")}</ul>`}
function fillPriv(){const rows=NET.slice(-12).reverse().map(n=>`<div class="m">${n.t.toLocaleTimeString()} · ${esc(n.purpose)} → ${esc(n.host+n.path)} ${n.ok?'✓':'✗'}</div>`).join('')||'<div class="m">No network requests yet this session.</div>';
 const host=u=>{try{return new URL(u).host}catch(e){return u}};
 $('privb').innerHTML=`<p class="m"><b>Your text</b> is analysed on this device only. To capture a selection Protwave presses copy, reads it, then restores your clipboard (a non-text clipboard, such as an image, is replaced when text is captured).</p>
 <p class="m"><b>Network:</b> nothing is sent by default. Protwave can contact only: the price list (${CFG.ledgerUrl?esc(host(CFG.ledgerUrl)):"not set"})${CFG.url?`, and your feedback server (${esc(host(CFG.url))}) if you send feedback or switch on anonymous usage`:""}.</p>
 <div><b class="m">Network log (this session)</b>${rows}</div>
 <p class="m"><b>Stored here:</b> your settings, ${Object.keys(cal).length} calibration entr${Object.keys(cal).length===1?"y":"ies"}, savings totals. <button class="x b" id="exp">Copy data</button> <button class="x b" id="era">Erase all</button></p>
 <p class="m">Version ${VER} · prices ${esc(ledgerUpdated)} (${esc(ledgerSrc)})</p><div class="m">${ERR.length?"Recent errors: "+esc(ERR.slice(-3).join(" | ")):"No errors this session."}</div>`;
 $('exp').onclick=async()=>{const d={};for(const k of Object.keys(localStorage))if(k!=='ledger2')d[k]=localStorage.getItem(k);try{await T.core.invoke('copy_text',{text:JSON.stringify(d,null,1)});$('exp').textContent='✓ Copied'}catch(e){$('exp').textContent='Failed'}};
 $('era').onclick=()=>{if(!$('era').dataset.s){$('era').dataset.s=1;$('era').textContent='Click again to erase';return}try{localStorage.clear()}catch(e){}location.reload()}}
async function flash(msg,c){shortInfo=piiInfo=null;$('big').textContent=msg;$('sub').textContent="Select some text, then press "+hkLabel()+".";$('note').textContent="";for(const x of['v','sh','pi'])$(x).innerHTML="";$('df').classList.remove('on');$('ob').hidden=true;$('card').classList.remove('onb');$('foot').textContent="";await open(c);clearTimeout(timer);timer=setTimeout(close,2500)}
// ---------- capture & files ----------
async function onCap(e){const[t,sel,x,y]=e.payload||[],s=(t||"").trim();
 if(obStep===3&&s.includes('Select this sentence to test')){$('obst').textContent='✅ Hotkey works!';$('obn').disabled=false;return}
 if(!s){await flash("Nothing selected",[x,y]);return}files=0;imgs=[];note=sel===false?"No selection found, so I used your clipboard.":"";run(s,[x,y])}
async function onDrop(paths){const items=await T.core.invoke('read_paths',{paths}),txt=[],sk=[];imgs=[];files=0;
 for(const f of items){if(f.text!=null){txt.push("// file: "+f.name+"\n"+f.text);files++}else if(f.w){imgs.push({w:f.w,h:f.h});files++}else sk.push(f.name+" ("+f.skipped+")")}
 note=(imgs.length?imgs.length+" image(s) estimated by size. ":"")+(sk.length?"Skipped: "+sk.slice(0,3).join(", ")+(sk.length>3?" +"+(sk.length-3):""):"");
 if(!files){cur="";shortInfo=piiInfo=null;await open(null);$('big').textContent="Can't read that yet";$('sub').textContent=note||"Nothing readable";$('v').innerHTML="";return}
 run(txt.join("\n\n"),null)}
async function pickFiles(){try{const r=await T.dialog.open({multiple:true});if(r)await onDrop(Array.isArray(r)?r:[r])}catch(e){}}
// ---------- hotkey ----------
const hkLabel=()=>LS.g('hk','Alt+Shift+T').replace('Super','Cmd/Win').replace('Control','Ctrl');
async function setHotkey(acc){try{await T.core.invoke('set_hotkey',{accel:acc});LS.s('hk',acc);$('hkmsg').textContent="";return true}catch(x){$('hkmsg').textContent=String(x);return false}}
function recordHotkey(){const b=$('hk');b.textContent='Press keys… (Esc cancels)';$('hkmsg').textContent='';
 const h=async e=>{e.preventDefault();e.stopPropagation();if(['Shift','Control','Alt','Meta'].includes(e.key))return;removeEventListener('keydown',h,true);
  if(e.key==='Escape'){b.textContent=hkLabel();return}
  const c=e.code,k=/^Key[A-Z]$/.test(c)?c.slice(3):/^Digit\d$/.test(c)?c.slice(5):/^F\d{1,2}$/.test(c)?c:c==='Space'?'Space':null,m=[e.ctrlKey&&'Control',e.altKey&&'Alt',e.shiftKey&&'Shift',e.metaKey&&'Super'].filter(Boolean);
  if(!k||!m.length){b.textContent='Use a modifier + letter/number/F-key';setTimeout(()=>b.textContent=hkLabel(),1800);return}
  await setHotkey([...m,k].join('+'));b.textContent=hkLabel()};
 addEventListener('keydown',h,true)}
// ---------- first-run onboarding ----------
const OSN=/Mac/i.test(navigator.platform)?"mac":/Win/i.test(navigator.platform)?"win":"lin";
const hkLabelOf=a=>a.replace('Super','Cmd/Win').replace('Control','Ctrl'),caps=a=>hkLabelOf(a).split('+').map(k=>`<kbd>${k}</kbd>`).join(' ');
async function demoHTML(){const smp="Please could you kindly summarize the quarterly report in order to help me, due to the fact that I am busy.",b=await base(smp),sh=shorten(smp),b2=await base(sh),o=outEst(smp,b),
 A=L.find(m=>m.n==='Claude Sonnet 5.5')||L[0],B=L.find(m=>m.n==='GPT-6 Luna')||L[L.length-1],tk=Math.round(b*A.f),ca=(tk*A.i+o*A.th*A.o)/1e6,cb=(Math.round(b*B.f)*B.i+o*B.th*B.o)/1e6;
 return `<div class="n" style="user-select:text"><span class="m">You select:</span><br>${esc(smp)}</div><div style="margin:8px 0"><div style="font-size:26px;font-weight:700">${tk} <small class="m" style="font-weight:500">tokens · ${usd(ca)}</small></div><div style="margin-top:6px;border:1px solid var(--ok);border-radius:12px;padding:8px 10px;font-weight:600">💡 ${esc(B.n)} saves ${Math.round((1-cb/ca)*100)}%</div><div class="m" style="margin-top:6px">✂️ A shorter version saves ${Math.round((1-b2/b)*100)}% (${b-b2} tokens)</div></div>`}
async function obRender(){const o=$('ob');o.hidden=false;$('card').classList.add('onb');$('big').textContent="";$('sub').textContent="";$('note').textContent="";for(const x of['v','sh','pi','foot'])$(x).innerHTML="";
 const alt="Alt+Shift+T",ctl=(OSN==="mac"?"Super":"Control")+"+Shift+T",dots=[0,1,2,3,4].map(i=>`<i style="display:inline-block;width:${i===obStep?18:6}px;height:6px;border-radius:3px;margin:0 2px;background:${i===obStep?'var(--ac)':'var(--bd)'};transition:width .2s"></i>`).join("");
 const S=[`<div style="text-align:center;padding:10px 0 4px"><div style="font-size:36px;font-weight:800;letter-spacing:-.03em;background:linear-gradient(100deg,var(--ac),#22d3ee);-webkit-background-clip:text;background-clip:text;color:transparent">Protwave</div><p style="margin:8px 0 2px;font-size:15px">Know what every prompt costs,<br>before you send it.</p><p class="m">Invisible until you need it.</p></div>`,
 `<b>Here's what you'll see</b><p class="m">Select text anywhere, press your hotkey, and about a second later:</p>${obStep===1?await demoHTML():""}`,
 `<b>${OSN==="mac"?"Allow capture":"Quick setup"}</b><div class="m" style="margin-top:6px">${OSN==="mac"?"System Settings › Privacy &amp; Security › <b>Accessibility</b>: switch Protwave on, or the hotkey can't copy your selection.<br><br>Not code-signed yet? Right-click the app, choose <b>Open</b>, then <b>Open</b> again.":OSN==="win"?"Not code-signed yet? On the blue SmartScreen screen click <b>More info</b>, then <b>Run anyway</b>.":"Make the AppImage executable (chmod +x) and run it."}</div><label class="m" style="display:block;margin-top:10px"><input type="checkbox" id="oas" ${LS.g('oas',1)?"checked":""}> Start Protwave at login (runs invisibly)</label><p class="m">Only run builds from your company's or the official release page.</p>`,
 `<b>Choose and test your hotkey</b><div class="r" style="margin:6px 0"><button class="x b" data-k="${alt}">${alt} (recommended)</button><button class="x b" data-k="${ctl}">${hkLabelOf(ctl)}</button></div><p class="m">${hkLabelOf(ctl)} is also "reopen closed tab" in browsers; Protwave would take it over everywhere.</p><div class="n" style="user-select:text;cursor:text">Select this sentence to test Protwave.</div><div class="m" id="obst" style="margin-top:6px">Select the sentence, then press <b id="obk">${hkLabel()}</b>…</div>`,
 `<div style="text-align:center;padding:6px 0"><div style="font-size:26px;font-weight:700">You're set ✓</div><p class="m" style="margin:8px 0 4px">Select text anywhere, then press</p><div style="margin:6px 0;font-size:16px">${caps(LS.g('hk','Alt+Shift+T'))}</div><p class="m"><kbd>Enter</kbd> switch · <kbd>C</kbd> copy shorter · <kbd>D</kbd> diff · <kbd>Esc</kbd> close<br>Settings live in the tray / menu-bar icon.</p></div>`];
 const last=obStep===4;
 o.innerHTML=S[obStep]+`<div style="text-align:center;margin-top:10px">${dots}</div><div class="r" style="margin-top:8px">${last?"<span></span>":`<button class="x" id="obs">${obStep===3?"Skip test":obStep===0?"Skip":"Skip all"}</button>`}${last?'<button class="p" id="obd">Start using Protwave</button>':obStep===0?'<button class="p" id="obn">Get started</button>':`<button class="p" id="obn"${obStep===3?" disabled":""}>Next</button>`}</div>`;
 const fin=async()=>{try{if(LS.g('oas',1))await T.autostart.enable()}catch(e){}o.hidden=true;$('card').classList.remove('onb');LS.s('ob',1);obStep=-1;close()};
 const next=()=>{if($('oas'))LS.s('oas',$('oas').checked?1:0);obStep++;obRender()};
 if($('obs'))$('obs').onclick=obStep===3?next:fin;if($('obn'))$('obn').onclick=next;if($('obd'))$('obd').onclick=fin;
 o.querySelectorAll('[data-k]').forEach(b=>b.onclick=async()=>{if(await setHotkey(b.dataset.k)){$('obk').textContent=hkLabel();$('hk').textContent=hkLabel()}else $('obst').textContent=$('hkmsg').textContent});
 if(obStep===3)setTimeout(()=>{if(obStep===3&&$('obst')&&$('obn')&&$('obn').disabled)$('obst').textContent="Nothing yet? Another app may own this shortcut. Try the other choice or pick your own in ⋯ › Hotkey."},20000)}
// ---------- optional feedback & anonymous usage (off unless configured) ----------
const fnPost=b=>nfetch('feedback',CFG.url+"/functions/v1/submit-feedback",{method:"POST",headers:{"Content-Type":"application/json",apikey:CFG.key,Authorization:"Bearer "+CFG.key},body:JSON.stringify(b)});
const sbPost=(t,row)=>nfetch('usage ping',CFG.url+"/rest/v1/"+t,{method:"POST",headers:{"Content-Type":"application/json",apikey:CFG.key,Authorization:"Bearer "+CFG.key,Prefer:"return=minimal"},body:JSON.stringify(row)});
const iid=()=>{let i=LS.g('iid',"");if(!i){i=crypto.randomUUID();LS.s('iid',i)}return i};
async function ping(){if(!CFG.url||!LS.g('tel',0))return;const d=new Date().toDateString();if(LS.g('lastping','')===d)return;try{await sbPost('pings',{install_id:iid(),version:VER,os:navigator.platform});LS.s('lastping',d)}catch(e){}}
function bucketTake(){const b=LS.g('fbb',{n:3,t:Date.now()}),k=Math.floor((Date.now()-b.t)/6e5);if(k>0){b.n=Math.min(3,b.n+k);b.t+=k*6e5}if(b.n<1){LS.s('fbb',b);return false}b.n--;LS.s('fbb',b);return true}
async function pow(ch,bits){const e=new TextEncoder();for(let n=0;;n++){const h=new Uint8Array(await crypto.subtle.digest('SHA-256',e.encode(ch+':'+n)));let z=0;for(const x of h){if(x===0)z+=8;else{z+=Math.clz32(x)-24;break}}if(z>=bits)return n}}
// ---------- init ----------
async function init(){const LED0=await (await fetch('ledger.json')).json();L=LED0.models.concat(LS.g('custom',[]));fillTools(null);
 try{$('tool').value=LS.g('tool2',$('tool').value)}catch(e){}
 $('tool').onchange=()=>{LS.s('tool2',$('tool').value);cur&&render(false);arm()};
 ['outv','ctx','bud','steps'].forEach(id=>$(id).oninput=rr);$('cch').checked=!!LS.g('cch',0);$('cch').onchange=()=>{LS.s('cch',$('cch').checked?1:0);rr()};
 $('why').ontoggle=()=>{if($('why').open)fillWhy()};$('priv').ontoggle=()=>{if($('priv').open)fillPriv()};
 $('info').onclick=()=>{det=true;$('det').classList.add('on'),$('card').classList.add('mo');$('why').open=true;fillWhy();arm();$('why').scrollIntoView({block:'nearest'})};
 $('cl').onclick=close;$('mb').onclick=()=>$('more').click();$('more').onclick=()=>{det=!det;$('det').classList.toggle('on',det),$('card').classList.toggle('mo',det);arm()};
 $('card').onmouseenter=()=>{clearTimeout(timer);$('bar').classList.remove('go')};$('card').onmouseleave=arm;$('card').addEventListener('focusin',()=>{clearTimeout(timer);$('bar').classList.remove('go')});
 new ResizeObserver(()=>{clearTimeout(fit.t);fit.t=setTimeout(()=>isOpen&&fit(),30)}).observe($('card'));
 CUR=LS.g('cur','USD');$('cur').value=CUR;$('cur').onchange=()=>{CUR=$('cur').value;LS.s('cur',CUR);cur&&render(false)};syncLedger(LED0);
 maskOn=LS.g('msk',1);$('msk').checked=!!maskOn;$('msk').onchange=()=>{maskOn=$('msk').checked?1:0;LS.s('msk',maskOn);cur&&prep().then(()=>render(false))};
 $('ah').value=LS.g('ah',10);$('ah').onchange=()=>{LS.s('ah',$('ah').value);arm()};
 try{$('as').checked=await T.autostart.isEnabled();$('as').onchange=async()=>{try{$('as').checked?await T.autostart.enable():await T.autostart.disable()}catch(e){$('as').checked=!$('as').checked}}}catch(e){$('as').parentElement&&($('as').style.display='none')}
 $('hk').textContent=hkLabel();$('hk').onclick=recordHotkey;{const hk=LS.g('hk',null);if(hk)try{await T.core.invoke('set_hotkey',{accel:hk})}catch(e){}}
 $('fpick').onclick=pickFiles;
 $('cma').onclick=()=>{const n=clean($('cmn').value.trim()),i=+$('cmi').value,o=+$('cmo').value;if(!n||!(i>=0)||!(o>=0))return;const c=LS.g('custom',[]),mdl={n,i,o,t:2,f:1,th:1,fam:'other'};c.push(mdl);LS.s('custom',c);L.push(mdl);$('tool').add(new Option(n,L.length-1));$('tool').value=L.length-1;LS.s('tool2',L.length-1);['cmn','cmi','cmo'].forEach(x=>$(x).value="");cur&&render(false)};
$('calo').onclick=()=>{const a=+$('actout').value,v=lastOut.v;if(!a||!v)return;const r=a/v,c=ocal[lastOut.key]||{r:1,n:0};ocal[lastOut.key]={r:Math.min(3,Math.max(.3,c.n?.7*c.r+.3*r:r)),n:c.n+1};LS.s('ocal',ocal);$('actout').value="";cur&&render(false)};
 $('cal').onclick=()=>{const a=+$('act').value,m=L[+$('tool').value],k=m.n+"|"+BK;if(!a||!lastBase)return;
  const c=calFor(m),bs=lastBase+(+$('ctx').value||0),err=Math.abs(Math.ceil(bs*m.f*c.r)-a)/a,r=a/(bs*m.f);
  learn(k,r,err);learn(m.fam+"|"+BK,r,err);
  hist.push(Math.min(1,err));hist=hist.slice(-30);LS.s('cal',cal);LS.s('hist',hist);$('act').value="";const before=Math.ceil(bs*m.f*c.r);render(false);toast(`Learned: Protwave said ${before.toLocaleString()}, real was ${a.toLocaleString()}. ${m.n} now adjusts ×${calFor(m).r.toFixed(2)} for ${BK} text.`)};
 $('act').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('cal').click()}});
 if(!CFG.url)$('fb').style.display='none';else{$('tel').checked=!!LS.g('tel',0);$('tel').onchange=()=>{LS.s('tel',$('tel').checked?1:0);ping()};
  // Client token bucket (3 messages, +1 per 10 min) + proof-of-work from the server. Real limits are server-side (IP hash, install, global).
  $('fbs').onclick=async()=>{const m=$('fbm').value.trim();if(!m)return;if(!bucketTake()){$('fbs').textContent="Slow down";setTimeout(()=>$('fbs').textContent="Send",2000);return}
   try{const c=await(await fnPost({action:"challenge"})).json(),n=await pow(c.ch,c.bits),r=await fnPost({type:$('fbt').value,message:m.slice(0,1000),version:VER,os:navigator.platform,install_id:iid(),pow:{ch:c.ch,n}});if(!r.ok)throw 0;$('fbm').value="";$('fbs').textContent="Thanks!"}catch(e){$('fbs').textContent="Failed"}setTimeout(()=>$('fbs').textContent="Send",2000)};ping();setInterval(ping,36e5)}
 addEventListener('keydown',e=>{if(!isOpen||obStep>=0)return;if(e.key==='Escape'){close();return}
  if(/^(INPUT|SELECT|TEXTAREA|BUTTON)$/.test(e.target.tagName||'')||e.metaKey||e.ctrlKey||e.altKey)return;
  const k=e.key.toLowerCase(),go=id=>{const b=$(id);if(b&&b.offsetParent!==null){e.preventDefault();b.click()}};
  if(e.key==='Enter')go('sw');else if(k==='c')go('cp');else if(k==='m')go('rc');else if(k==='d')go('dfb');else if(e.key===','){e.preventDefault();$('more').click()}});
 await T.event.listen('captured',onCap);
 await T.event.listen('tauri://drag-drop',e=>onDrop(e.payload.paths));
 await T.event.listen('open-settings',async()=>{det=true;$('det').classList.add('on'),$('card').classList.add('mo');if(!cur){$('big').textContent="Protwave";$('sub').textContent="Settings. Select text anywhere and press "+hkLabel()+".";for(const x of['v','sh','pi'])$(x).innerHTML="";$('foot').textContent=footText()}await open(null)});
 await T.event.listen('pick-files',pickFiles);
 if(!LS.g('ob',0)){obStep=0;await obRender();await open(null)}}
init();
