pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js';

const mainMenu = document.getElementById("main-menu");
const statusText = document.getElementById("status-text");

const pdfSection = document.getElementById("pdf-section");
const btnBackPdf = document.getElementById("btn-back-pdf");
const pdfUpload = document.getElementById("pdf-upload");
const pdfContent = document.getElementById("pdf-content");

document.getElementById("btn-pdf").addEventListener("click", function() {
    mainMenu.style.display = "none";
    pdfSection.style.display = "block";
    statusText.innerText = "PDF Reader opened. Select a PDF file.";
});

btnBackPdf.addEventListener("click", function() {
    pdfSection.style.display = "none";
    mainMenu.style.display = "block";
    statusText.innerText = "Select an option below:";
    pdfContent.innerText = "";
    pdfUpload.value = "";
});

pdfUpload.addEventListener("change", function(event) {
    const file = event.target.files[0];
    if (file && file.type === "application/pdf") {
        statusText.innerText = "Reading PDF, please wait...";
        const fileReader = new FileReader();
        
        fileReader.onload = function() {
            const typedarray = new Uint8Array(this.result);
            
            pdfjsLib.getDocument(typedarray).promise.then(function(pdf) {
                let textPromises = [];
                for (let i = 1; i <= pdf.numPages; i++) {
                    textPromises.push(pdf.getPage(i).then(function(page) {
                        return page.getTextContent().then(function(textContent) {
                            return textContent.items.map(item => item.str).join(' ');
                        });
                    }));
                }
                
                Promise.all(textPromises).then(function(texts) {
                    pdfContent.innerText = texts.join('\n\n');
                    statusText.innerText = "PDF loaded successfully.";
                });
            }).catch(function(error) {
                statusText.innerText = "Error reading PDF. Document might be protected.";
            });
        };
        fileReader.readAsArrayBuffer(file);
    } else {
        statusText.innerText = "Please upload a valid PDF file.";
    }
});

document.getElementById("btn-image").addEventListener("click", function() {
    statusText.innerText = "Image Scan selected. Feature coming soon.";
});

document.getElementById("btn-text").addEventListener("click", function() {
    statusText.innerText = "Text Reader selected. Feature coming soon.";
});
