const DB_NAME = "monee-db";
const DB_VERSION = 1;
let db;
let selectedMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
let currentType = "expense";
let transactionFilter = "all";
let transactionSearch = "";

const DEFAULT_CATEGORIES = [
  {name:"อาหาร", icon:"🍜", type:"expense"},
  {name:"เดินทาง", icon:"🚗", type:"expense"},
  {name:"ช้อปปิ้ง", icon:"🛍️", type:"expense"},
  {name:"บ้าน", icon:"🏠", type:"expense"},
  {name:"บันเทิง", icon:"🎮", type:"expense"},
  {name:"สุขภาพ", icon:"❤", type:"expense"},
  {name:"การศึกษา", icon:"🎓", type:"expense"},
  {name:"เงินเดือน", icon:"💼", type:"income"},
  {name:"รายได้เสริม", icon:"✨", type:"income"}
];

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

function openDB(){
  return new Promise((resolve,reject)=>{
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = e=>{
      const d = e.target.result;
      if(!d.objectStoreNames.contains("transactions")){
        const s = d.createObjectStore("transactions",{keyPath:"id",autoIncrement:true});
        s.createIndex("date","date");
        s.createIndex("type","type");
      }
      if(!d.objectStoreNames.contains("categories")){
        d.createObjectStore("categories",{keyPath:"id",autoIncrement:true});
      }
      if(!d.objectStoreNames.contains("meta")){
        d.createObjectStore("meta",{keyPath:"key"});
      }
    };
    req.onsuccess = ()=>{ db=req.result; resolve(db); };
    req.onerror = ()=>reject(req.error);
  });
}
function store(name, mode="readonly"){ return db.transaction(name,mode).objectStore(name); }
function getAll(name){ return new Promise((res,rej)=>{const r=store(name).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
function add(name,value){ return new Promise((res,rej)=>{const r=store(name,"readwrite").add(value);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
function put(name,value){ return new Promise((res,rej)=>{const r=store(name,"readwrite").put(value);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error);});}
function del(name,key){ return new Promise((res,rej)=>{const r=store(name,"readwrite").delete(key);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}
function clearStore(name){ return new Promise((res,rej)=>{const r=store(name,"readwrite").clear();r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}

async function seedCategories(){
  const categories = await getAll("categories");
  if(!categories.length){
    for(const c of DEFAULT_CATEGORIES) await add("categories",c);
  }
}
function monthKey(d){ return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`; }
function dateMonthKey(v){ const d = new Date(v+"T00:00:00"); return monthKey(d); }
function formatMonth(d){ return new Intl.DateTimeFormat("th-TH",{month:"long",year:"numeric"}).format(d); }
function money(v){ return new Intl.NumberFormat("th-TH",{style:"currency",currency:"THB",minimumFractionDigits:2}).format(Number(v||0)); }
function shortDate(v){ return new Intl.DateTimeFormat("th-TH",{day:"numeric",month:"short",year:"2-digit"}).format(new Date(v+"T00:00:00")); }
function escapeHTML(str=""){ return str.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m])); }

async function monthTransactions(){
  const all = await getAll("transactions");
  const key = monthKey(selectedMonth);
  return all.filter(t=>dateMonthKey(t.date)===key).sort((a,b)=>(b.date+b.time).localeCompare(a.date+a.time));
}
async function categoriesMap(){
  const list = await getAll("categories");
  return Object.fromEntries(list.map(c=>[c.id,c]));
}

async function renderAll(){
  const txs = await monthTransactions();
  const cmap = await categoriesMap();
  const income = txs.filter(t=>t.type==="income").reduce((s,t)=>s+Number(t.amount),0);
  const expense = txs.filter(t=>t.type==="expense").reduce((s,t)=>s+Number(t.amount),0);
  const balance = income-expense;

  $("#monthLabel").textContent = formatMonth(selectedMonth);
  $$(".current-month").forEach(el=>el.textContent=formatMonth(selectedMonth));
  $("#balanceAmount").textContent = money(balance);
  $("#incomeAmount").textContent = money(income);
  $("#expenseAmount").textContent = money(expense);
  $("#analysisIncome").textContent = money(income);
  $("#analysisExpense").textContent = money(expense);
  $("#savingRate").textContent = income>0 ? `${Math.round((balance/income)*100)}%` : "0%";
  $("#balanceHint").textContent = txs.length ? `${txs.length} รายการในเดือนนี้` : "เริ่มบันทึกรายการแรกของคุณ";

  renderBars("#categoryBars", txs, cmap, 5);
  renderBars("#analysisBars", txs, cmap, 8);
  renderTransactions("#recentList", txs.slice(0,5), cmap);
  {
    let visible = transactionFilter==="all" ? txs : txs.filter(t=>t.type===transactionFilter);
    const q = transactionSearch.trim().toLowerCase();
    if(q){
      visible = visible.filter(t=>{
        const c = cmap[t.categoryId] || {name:""};
        return `${t.note||""} ${c.name||""} ${t.amount||""}`.toLowerCase().includes(q);
      });
    }
    renderTransactions("#transactionList", visible, cmap);
  }
  await renderCategorySettings();
}
function renderBars(sel, txs, cmap, limit){
  const box=$(sel);
  const expenseTx = txs.filter(t=>t.type==="expense");
  if(!expenseTx.length){ box.className="category-bars empty-state"; box.textContent="ยังไม่มีรายจ่ายในเดือนนี้"; return; }
  const totals={}; expenseTx.forEach(t=>totals[t.categoryId]=(totals[t.categoryId]||0)+Number(t.amount));
  const rows=Object.entries(totals).sort((a,b)=>b[1]-a[1]).slice(0,limit);
  const max=rows[0]?.[1]||1;
  box.className="category-bars";
  box.innerHTML=rows.map(([id,amt])=>{
    const c=cmap[id]||{name:"ไม่ระบุ",icon:"●"};
    return `<div class="bar-item">
      <div class="bar-icon">${escapeHTML(c.icon||"●")}</div>
      <div class="bar-main">
        <div class="bar-label"><span>${escapeHTML(c.name)}</span></div>
        <div class="bar-track"><div class="bar-fill" style="width:${Math.max(6,amt/max*100)}%"></div></div>
      </div>
      <div class="bar-amount">${money(amt)}</div>
    </div>`;
  }).join("");
}
function renderTransactions(sel, txs, cmap){
  const box=$(sel);
  if(!txs.length){ box.className=sel==="#transactionList"?"transaction-list full empty-state":"transaction-list empty-state"; box.textContent="ยังไม่มีรายการ"; return; }
  box.className=sel==="#transactionList"?"transaction-list full":"transaction-list";
  box.innerHTML=txs.map(t=>{
    const c=cmap[t.categoryId]||{name:"ไม่ระบุ",icon:"●"};
    const sign=t.type==="expense"?"−":"+";
    return `<button class="transaction-item" data-edit="${t.id}" style="width:100%;text-align:left">
      <div class="transaction-icon">${escapeHTML(c.icon||"●")}</div>
      <div class="transaction-main"><b>${escapeHTML(t.note||c.name)}</b><small>${escapeHTML(c.name)} · ${shortDate(t.date)}</small></div>
      <div class="transaction-amount ${t.type}">${sign}${money(t.amount)}<small>${escapeHTML(t.time||"")}</small></div>
    </button>`;
  }).join("");
  box.querySelectorAll("[data-edit]").forEach(btn=>btn.addEventListener("click",()=>openEdit(Number(btn.dataset.edit))));
}
async function renderCategorySettings(){
  const list=await getAll("categories");
  const box=$("#categoryList");
  box.innerHTML=list.map(c=>`<div class="setting-row">
    <div class="setting-row-main"><div class="setting-row-icon">${escapeHTML(c.icon||"●")}</div><div><b>${escapeHTML(c.name)}</b><small>${c.type==="expense"?"รายจ่าย":"รายรับ"}</small></div></div>
    <button class="mini-delete" data-del-cat="${c.id}">ลบ</button>
  </div>`).join("");
  box.querySelectorAll("[data-del-cat]").forEach(b=>b.addEventListener("click",()=>removeCategory(Number(b.dataset.delCat))));
}

function switchPage(page){
  $$(".page").forEach(p=>p.classList.toggle("active",p.id===`page-${page}`));
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
function changeMonth(delta){
  selectedMonth = new Date(selectedMonth.getFullYear(),selectedMonth.getMonth()+delta,1);
  renderAll();
}
function nowForm(){
  const d=new Date();
  $("#dateInput").value=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  $("#timeInput").value=`${String(d.getHours()).padStart(2,"0")}:${String(d.getMinutes()).padStart(2,"0")}`;
}
async function refreshCategorySelect(){
  const cats=(await getAll("categories")).filter(c=>c.type===currentType);
  $("#categorySelect").innerHTML=cats.map(c=>`<option value="${c.id}">${escapeHTML(c.icon||"●")} ${escapeHTML(c.name)}</option>`).join("");
}
function showSheet(el){
  $("#sheetBackdrop").classList.add("show"); el.classList.add("open"); el.setAttribute("aria-hidden","false");
}
function hideSheets(){
  $("#sheetBackdrop").classList.remove("show");
  $$(".bottom-sheet").forEach(s=>{s.classList.remove("open");s.setAttribute("aria-hidden","true");});
}
async function openAdd(){
  $("#transactionForm").reset(); $("#editId").value=""; $("#sheetTitle").textContent="เพิ่มรายการ"; $("#deleteTransactionBtn").classList.add("hidden");
  currentType="expense"; setTypeUI(); nowForm(); await refreshCategorySelect(); showSheet($("#transactionSheet"));
  setTimeout(()=>$("#amountInput").focus(),250);
}
async function openEdit(id){
  const all=await getAll("transactions"); const t=all.find(x=>x.id===id); if(!t)return;
  $("#editId").value=id; $("#sheetTitle").textContent="แก้ไขรายการ"; $("#deleteTransactionBtn").classList.remove("hidden");
  currentType=t.type; setTypeUI(); await refreshCategorySelect();
  $("#amountInput").value=t.amount; $("#categorySelect").value=t.categoryId; $("#dateInput").value=t.date; $("#timeInput").value=t.time; $("#noteInput").value=t.note||"";
  showSheet($("#transactionSheet"));
}
function setTypeUI(){
  $$("#typeSwitch button").forEach(b=>b.classList.toggle("active",b.dataset.type===currentType));
  $$("#typeSwitch button").forEach(b=>b.classList.toggle("expense-tab",b.dataset.type==="expense"));
}

async function saveTransaction(e){
  e.preventDefault();
  const obj={
    type:currentType, amount:Number($("#amountInput").value), categoryId:Number($("#categorySelect").value),
    date:$("#dateInput").value, time:$("#timeInput").value, note:$("#noteInput").value.trim()
  };
  if(!obj.amount || obj.amount<=0) return toast("กรุณาใส่จำนวนเงิน");
  const id=Number($("#editId").value);
  if(id){ obj.id=id; await put("transactions",obj); toast("แก้ไขรายการแล้ว"); }
  else { await add("transactions",obj); toast("บันทึกรายการแล้ว"); }
  selectedMonth=new Date(obj.date+"T00:00:00"); selectedMonth=new Date(selectedMonth.getFullYear(),selectedMonth.getMonth(),1);
  hideSheets(); await renderAll();
}
async function deleteCurrent(){
  const id=Number($("#editId").value); if(!id)return;
  if(confirm("ลบรายการนี้ใช่ไหม?")){ await del("transactions",id); hideSheets(); toast("ลบรายการแล้ว"); await renderAll(); }
}
async function addCategoryForm(e){
  e.preventDefault();
  const name=$("#categoryNameInput").value.trim(), icon=$("#categoryIconInput").value.trim()||"●", type=$("#categoryTypeInput").value;
  if(!name)return;
  await add("categories",{name,icon,type}); $("#categoryForm").reset(); $("#categoryIconInput").value="●"; hideSheets(); toast("เพิ่มหมวดหมู่แล้ว"); await renderAll();
}
async function removeCategory(id){
  const txs=await getAll("transactions");
  if(txs.some(t=>t.categoryId===id)) return toast("หมวดหมู่นี้ถูกใช้อยู่ จึงยังลบไม่ได้");
  if(confirm("ลบหมวดหมู่นี้ใช่ไหม?")){ await del("categories",id); toast("ลบหมวดหมู่แล้ว"); await renderAll(); }
}
function toast(msg){
  const el=$("#toast"); el.textContent=msg; el.classList.add("show"); clearTimeout(toast.t); toast.t=setTimeout(()=>el.classList.remove("show"),2200);
}
async function exportData(){
  const data={version:1,exportedAt:new Date().toISOString(),transactions:await getAll("transactions"),categories:await getAll("categories")};
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=`monee-backup-${new Date().toISOString().slice(0,10)}.json`; a.click(); URL.revokeObjectURL(a.href);
  toast("สร้างไฟล์สำรองแล้ว");
}
async function importData(file){
  try{
    const data=JSON.parse(await file.text());
    if(!Array.isArray(data.transactions)||!Array.isArray(data.categories)) throw new Error();
    await clearStore("transactions"); await clearStore("categories");
    for(const c of data.categories){ const copy={...c}; delete copy.id; await add("categories",copy); }
    // Preserve category links by remapping old IDs based on order
    const newCats=await getAll("categories");
    const oldCats=data.categories;
    const map={}; oldCats.forEach((c,i)=>map[c.id]=newCats[i]?.id);
    for(const t of data.transactions){ const copy={...t,categoryId:map[t.categoryId]||t.categoryId}; delete copy.id; await add("transactions",copy); }
    toast("กู้คืนข้อมูลเรียบร้อย"); await renderAll();
  }catch(e){ toast("ไฟล์สำรองไม่ถูกต้อง"); }
}
async function clearAll(){
  if(!confirm("ข้อมูลรายรับรายจ่ายและหมวดหมู่ทั้งหมดจะถูกลบ ต้องการดำเนินการต่อหรือไม่?"))return;
  await clearStore("transactions"); await clearStore("categories"); await seedCategories(); toast("ล้างข้อมูลแล้ว"); await renderAll();
}
function toggleTheme(){
  document.body.classList.toggle("dark"); const dark=document.body.classList.contains("dark"); localStorage.setItem("monee-theme",dark?"dark":"light"); $("#themeBtn").textContent=dark?"☀":"☾";
}
function initTheme(){
  const dark=localStorage.getItem("monee-theme")==="dark"; document.body.classList.toggle("dark",dark); $("#themeBtn").textContent=dark?"☀":"☾";
}
function bind(){
  $("#prevMonth").addEventListener("click",()=>changeMonth(-1)); $("#nextMonth").addEventListener("click",()=>changeMonth(1));
  $$("[data-month='prev']").forEach(b=>b.addEventListener("click",()=>changeMonth(-1))); $$("[data-month='next']").forEach(b=>b.addEventListener("click",()=>changeMonth(1)));
  $$(".nav-item").forEach(b=>b.addEventListener("click",()=>switchPage(b.dataset.page)));
  $$("[data-go]").forEach(b=>b.addEventListener("click",()=>switchPage(b.dataset.go)));
  $("#openAddBtn").addEventListener("click",openAdd);
  $("#sheetBackdrop").addEventListener("click",hideSheets); $$("[data-close-sheet]").forEach(b=>b.addEventListener("click",hideSheets)); $$("[data-close-category]").forEach(b=>b.addEventListener("click",hideSheets));
  $$("#typeSwitch button").forEach(b=>b.addEventListener("click",async()=>{currentType=b.dataset.type;setTypeUI();await refreshCategorySelect();}));
  $("#transactionForm").addEventListener("submit",saveTransaction); $("#deleteTransactionBtn").addEventListener("click",deleteCurrent);
  $("#transactionFilter").addEventListener("click",e=>{const b=e.target.closest("button");if(!b)return;transactionFilter=b.dataset.filter; $$("#transactionFilter button").forEach(x=>x.classList.toggle("active",x===b));renderAll();});
  $("#transactionSearch").addEventListener("input",e=>{ transactionSearch=e.target.value||""; renderAll(); });
  $("#addCategoryBtn").addEventListener("click",()=>{ $("#categoryForm").reset(); $("#categoryIconInput").value="●"; showSheet($("#categorySheet")); });
  $("#categoryForm").addEventListener("submit",addCategoryForm);
  $("#exportBtn").addEventListener("click",exportData); $("#importInput").addEventListener("change",e=>e.target.files[0]&&importData(e.target.files[0])); $("#clearBtn").addEventListener("click",clearAll);
  $("#themeBtn").addEventListener("click",toggleTheme);
}
async function init(){
  initTheme(); bind(); await openDB(); await seedCategories(); await renderAll();
  if("serviceWorker" in navigator){ navigator.serviceWorker.register("./sw.js").catch(()=>{}); }
}
init();
