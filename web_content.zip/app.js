let selectedMonth = new Date().toISOString().slice(0, 7);

let attendanceData =
    JSON.parse(localStorage.getItem("attendanceData")) || {};

let pmData =
    JSON.parse(localStorage.getItem("pmData")) || {};


/* =========================
   MONTH SELECTOR
========================= */

function createMonthSelector() {

    const selector = document.getElementById("monthSelector");

    selector.innerHTML = "";

    const year = new Date().getFullYear();

    for (let month = 0; month < 12; month++) {

        const value =
            year + "-" + String(month + 1).padStart(2, "0");

        const option = document.createElement("option");

        option.value = value;

        option.textContent =
            new Date(year, month, 1).toLocaleString(
                "en-US",
                { month: "long" }
            ) + " " + year;

        if (value === selectedMonth) {
            option.selected = true;
        }

        selector.appendChild(option);
    }
}


/* =========================
   CHANGE MONTH
========================= */

function changeMonth() {

    selectedMonth =
        document.getElementById("monthSelector").value;

    updateSummary();
}


/* =========================
   MONTH NAME
========================= */

function getMonthName(monthValue) {

    const parts = monthValue.split("-");

    const date =
        new Date(
            Number(parts[0]),
            Number(parts[1]) - 1,
            1
        );

    return date.toLocaleString(
        "en-US",
        { month: "long" }
    );
}


/* =========================
   SCREEN CONTROL
========================= */

function hideAllScreens() {
    document.getElementById("homeScreen").classList.add("hidden");
    document.getElementById("attendanceScreen").classList.add("hidden");
    document.getElementById("pmScreen").classList.add("hidden");
    document.getElementById("reportScreen").classList.add("hidden");
}

function openAttendance() {
    hideAllScreens();
    document.getElementById("attendanceScreen").classList.remove("hidden");
    history.pushState({ screen: "attendance" }, "", "#attendance");
    loadAttendance();
}

function openPM() {
    hideAllScreens();
    document.getElementById("pmScreen").classList.remove("hidden");
    history.pushState({ screen: "pm" }, "", "#pm");
    loadPM();
}

function openReport() {
    hideAllScreens();
    document.getElementById("reportScreen").classList.remove("hidden");
    history.pushState({ screen: "report" }, "", "#report");
    createReportMonthSelector();
    previewReport();
}

function goHome() {
    hideAllScreens();
    document.getElementById("homeScreen").classList.remove("hidden");
    updateSummary();
}

/* =========================
   PHONE BACK BUTTON
========================= */

window.addEventListener("popstate", function () {
    const reportScreen = document.getElementById("reportScreen");
    const attendanceScreen = document.getElementById("attendanceScreen");
    const pmScreen = document.getElementById("pmScreen");

    if (!reportScreen.classList.contains("hidden") ||
        !attendanceScreen.classList.contains("hidden") ||
        !pmScreen.classList.contains("hidden")) {
        goHome();
    }
});


/* =========================
   DATE KEY
========================= */

function makeDateKey(day) {

    return selectedMonth +
        "-" +
        String(day).padStart(2, "0");
}


/* =========================
   LOAD ATTENDANCE
========================= */

function loadAttendance() {

    const list =
        document.getElementById("attendanceList");

    list.innerHTML = "";

    const [year, month] =
        selectedMonth.split("-").map(Number);

    const daysInMonth =
        new Date(year, month, 0).getDate();


    for (let day = 1; day <= daysInMonth; day++) {

        const dateKey = makeDateKey(day);

        if (!attendanceData[dateKey]) {

            attendanceData[dateKey] = {
                status: null,
                ot: false
            };
        }

        const data =
            attendanceData[dateKey];

        const dateObject =
            new Date(year, month - 1, day);

        const dayName =
            dateObject.toLocaleString(
                "en-US",
                { weekday: "short" }
            );


        const card =
            document.createElement("div");

        card.className = "day-card";


        let statusText = "";

        if (!data.status) {

            statusText =
                `<div class="pending">⏳ Pending</div>`;
        }


        card.innerHTML = `

            <div class="day-header">

                <div class="day-number">
                    Day ${day}
                </div>

                <div class="day-date">
                    ${dayName}, ${day}
                    ${getMonthName(selectedMonth)}
                </div>

            </div>


            <div class="status-buttons">

                <button
                    class="${data.status === "Present"
                        ? "active-present" : ""}"
                    onclick="setStatus('${dateKey}', 'Present')">

                    Present

                </button>


                <button
                    class="${data.status === "Absent"
                        ? "active-absent" : ""}"
                    onclick="setStatus('${dateKey}', 'Absent')">

                    Absent

                </button>


                <button
                    class="${data.status === "Leave"
                        ? "active-leave" : ""}"
                    onclick="setStatus('${dateKey}', 'Leave')">

                    Leave

                </button>

            </div>


            ${statusText}


            <div class="ot-row">

                <span class="ot-label">
                    🟡 OT
                </span>


                <label class="switch">

                    <input
                        type="checkbox"
                        ${data.ot ? "checked" : ""}
                        onchange="changeOT('${dateKey}', this.checked)"
                    >

                    <span class="slider"></span>

                </label>

            </div>
        `;


        list.appendChild(card);
    }
}


/* =========================
   SET STATUS
========================= */

function setStatus(dateKey, status) {

    if (!attendanceData[dateKey]) {

        attendanceData[dateKey] = {
            status: null,
            ot: false
        };
    }

    attendanceData[dateKey].status = status;

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    loadAttendance();

    updateSummary();
}


/* =========================
   OT
========================= */

function changeOT(dateKey, value) {

    if (!attendanceData[dateKey]) {

        attendanceData[dateKey] = {
            status: null,
            ot: false
        };
    }

    attendanceData[dateKey].ot = value;

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    updateSummary();
}


/* =========================
   SAVE ATTENDANCE
========================= */

function saveAttendance() {

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    alert("Attendance saved successfully! ✅");
}


/* =========================
   SUMMARY
========================= */

function updateSummary() {

    let present = 0;
    let absent = 0;
    let otDays = 0;


    Object.keys(attendanceData).forEach(key => {

        if (!key.startsWith(selectedMonth)) {
            return;
        }

        const data = attendanceData[key];


        if (data.status === "Present") {
            present++;
        }


        if (data.status === "Absent") {
            absent++;
        }


        if (data.ot === true) {
            otDays++;
        }

    });


    document.getElementById("presentCount")
        .textContent = present;

    document.getElementById("absentCount")
        .textContent = absent;

    document.getElementById("otDays")
        .textContent = otDays;
}


/* =========================
   PM TRACKER
========================= */

function loadPM() {

    const data =
        pmData[selectedMonth] || {};

    document.getElementById("pm1").value =
        data.pm1 || "";

    document.getElementById("pm2").value =
        data.pm2 || "";

    document.getElementById("pm3").value =
        data.pm3 || "";

    document.getElementById("pm4").value =
        data.pm4 || "";

    document.getElementById("pm5").value =
        data.pm5 || "";

    document.getElementById("monthlyPM").value =
        data.monthlyPM || "";
}


/* =========================
   SAVE PM
========================= */

function savePM() {

    pmData[selectedMonth] = {

        pm1: document.getElementById("pm1").value,

        pm2: document.getElementById("pm2").value,

        pm3: document.getElementById("pm3").value,

        pm4: document.getElementById("pm4").value,

        pm5: document.getElementById("pm5").value,

        monthlyPM:
            document.getElementById("monthlyPM").value
    };


    localStorage.setItem(
        "pmData",
        JSON.stringify(pmData)
    );


    alert("PM details saved successfully! ✅");
}


/* =========================
   MONTHLY REPORT
========================= */

let reportMonth = selectedMonth;

function createReportMonthSelector() {
    const selector = document.getElementById("reportMonthSelector");
    if (!selector) return;

    selector.innerHTML = "";
    const year = new Date().getFullYear();

    for (let month = 0; month < 12; month++) {
        const value = year + "-" + String(month + 1).padStart(2, "0");
        const option = document.createElement("option");
        option.value = value;
        option.textContent = new Date(year, month, 1).toLocaleString(
            "en-US", { month: "long" }
        ) + " " + year;
        option.selected = value === reportMonth;
        selector.appendChild(option);
    }
}

function changeReportMonth() {
    reportMonth = document.getElementById("reportMonthSelector").value;
    previewReport();
}

function getReportData(monthValue) {
    const [year, month] = monthValue.split("-").map(Number);
    const daysInMonth = new Date(year, month, 0).getDate();
    const rows = [];
    let present = 0, absent = 0, leave = 0, pending = 0, otDays = 0;

    for (let day = 1; day <= daysInMonth; day++) {
        const dateKey = monthValue + "-" + String(day).padStart(2, "0");
        const data = attendanceData[dateKey] || { status: null, ot: false };
        const dateObject = new Date(year, month - 1, day);
        const dayName = dateObject.toLocaleString("en-US", { weekday: "short" });
        const status = data.status || "Pending";

        if (status === "Present") present++;
        else if (status === "Absent") absent++;
        else if (status === "Leave") leave++;
        else pending++;
        if (data.ot === true) otDays++;

        rows.push({
            day,
            dayName,
            date: String(day).padStart(2, "0") + " " + getMonthName(monthValue),
            status,
            ot: data.ot === true ? "Yes" : "No"
        });
    }

    return {
        monthValue,
        monthName: getMonthName(monthValue),
        year,
        totalDays: daysInMonth,
        present,
        absent,
        leave,
        pending,
        otDays,
        rows,
        pm: pmData[monthValue] || {}
    };
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (char) {
        return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[char];
    });
}

function previewReport() {
    const box = document.getElementById("reportPreview");
    if (!box) return;

    const report = getReportData(reportMonth);
    const pm = report.pm;

    const rowsHTML = report.rows.map(row => {
        const cls = "status-" + row.status.toLowerCase();
        return `<tr>
            <td>${row.day}</td>
            <td>${escapeHTML(row.dayName)}</td>
            <td>${escapeHTML(row.date)}</td>
            <td class="${cls}">${escapeHTML(row.status)}</td>
            <td>${row.ot}</td>
        </tr>`;
    }).join("");

    box.innerHTML = `
        <div class="report-paper">
            <h1 class="report-title">Monthly Attendance Report</h1>
            <div class="report-subtitle">${escapeHTML(report.monthName)} ${report.year}</div>

            <div class="report-summary-grid">
                <div class="report-stat">Present<b>${report.present}</b></div>
                <div class="report-stat">Absent<b>${report.absent}</b></div>
                <div class="report-stat">Leave<b>${report.leave}</b></div>
                <div class="report-stat">Pending<b>${report.pending}</b></div>
                <div class="report-stat">OT Days<b>${report.otDays}</b></div>
                <div class="report-stat">Total Days<b>${report.totalDays}</b></div>
            </div>

            <h3 class="report-section-title">Attendance Details</h3>
            <table class="report-table">
                <thead>
                    <tr><th>Day</th><th>Week</th><th>Date</th><th>Status</th><th>OT</th></tr>
                </thead>
                <tbody>${rowsHTML}</tbody>
            </table>

            <h3 class="report-section-title">PM Tracker</h3>
            <div class="pm-report-grid">
                <div class="pm-report-item"><span>PM 1</span>${escapeHTML(pm.pm1 || "Not set")}</div>
                <div class="pm-report-item"><span>PM 2</span>${escapeHTML(pm.pm2 || "Not set")}</div>
                <div class="pm-report-item"><span>PM 3</span>${escapeHTML(pm.pm3 || "Not set")}</div>
                <div class="pm-report-item"><span>PM 4</span>${escapeHTML(pm.pm4 || "Not set")}</div>
                <div class="pm-report-item"><span>PM 5</span>${escapeHTML(pm.pm5 || "Not set")}</div>
                <div class="pm-report-item"><span>Monthly PM</span>${escapeHTML(pm.monthlyPM || "Not set")}</div>
            </div>
        </div>
    `;
}

function pdfEscape(text) {
    return String(text)
        .replace(/\\/g, "\\\\")
        .replace(/\(/g, "\\(")
        .replace(/\)/g, "\\)")
        .replace(/[^\x20-\x7E]/g, "?");
}

function wrapText(text, maxChars) {
    const words = String(text).split(/\s+/);
    const lines = [];
    let line = "";
    words.forEach(word => {
        if ((line + " " + word).trim().length > maxChars && line) {
            lines.push(line);
            line = word;
        } else {
            line = (line + " " + word).trim();
        }
    });
    if (line) lines.push(line);
    return lines;
}

function buildPDF(report) {
    const pages = [];
    let lines = [];

    const add = (text, size=10, bold=false) => {
        const prefix = bold ? "BT /F2 " : "BT /F1 ";
        lines.push({ text, size, bold });
    };

    add("MONTHLY ATTENDANCE REPORT", 16, true);
    add(report.monthName + " " + report.year, 11);
    add("", 6);
    add("SUMMARY", 12, true);
    add("Present: " + report.present + "    Absent: " + report.absent + "    Leave: " + report.leave, 10);
    add("Pending: " + report.pending + "    OT Days: " + report.otDays + "    Total Days: " + report.totalDays, 10);
    add("", 6);
    add("ATTENDANCE DETAILS", 12, true);
    add("Day  Week  Date       Status    OT", 9, true);
    add("----------------------------------------------", 8);

    report.rows.forEach(row => {
        const line = String(row.day).padStart(2," ") + "  " +
            row.dayName.padEnd(3," ") + "  " +
            row.date.padEnd(15," ") + " " +
            row.status.padEnd(8," ") + " " + row.ot;
        wrapText(line, 82).forEach(x => add(x, 8));
    });

    add("", 6);
    add("PM TRACKER", 12, true);
    add("PM 1: " + (report.pm.pm1 || "Not set"), 9);
    add("PM 2: " + (report.pm.pm2 || "Not set"), 9);
    add("PM 3: " + (report.pm.pm3 || "Not set"), 9);
    add("PM 4: " + (report.pm.pm4 || "Not set"), 9);
    add("PM 5: " + (report.pm.pm5 || "Not set"), 9);
    add("Monthly PM: " + (report.pm.monthlyPM || "Not set"), 9);

    const perPage = 47;
    for (let i = 0; i < lines.length; i += perPage) pages.push(lines.slice(i, i + perPage));

    const objects = [];
    const offsets = [];
    const addObj = body => { offsets.push(0); objects.push(body); return objects.length; };

    addObj("<< /Type /Catalog /Pages 2 0 R >>");
    const pageNums = [];
    const contentNums = [];
    const font1 = 3, font2 = 4;

    for (let i = 0; i < pages.length; i++) {
        pageNums.push(addObj(""));
        contentNums.push(addObj(""));
    }

    addObj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
    addObj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>");

    const kids = pageNums.map(n => n + " 0 R").join(" ");
    objects[1] = `<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`;

    pages.forEach((page, i) => {
        let stream = "q\nBT\n/F1 10 Tf\n50 800 Td\n";
        page.forEach(item => {
            const font = item.bold ? "/F2" : "/F1";
            stream += `${font} ${item.size} Tf\n0 -${item.size + 5} Td\n(${pdfEscape(item.text)}) Tj\n`;
        });
        stream += "ET\nQ\n";
        objects[pageNums[i]-1] = `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${font1} 0 R /F2 ${font2} 0 R >> >> /Contents ${contentNums[i]} 0 R >>`;
        objects[contentNums[i]-1] = `<< /Length ${stream.length} >>\nstream\n${stream}endstream`;
    });

    let pdf = "%PDF-1.4\n";
    const objOffsets = [0];
    for (let i = 0; i < objects.length; i++) {
        objOffsets[i+1] = pdf.length;
        pdf += `${i+1} 0 obj\n${objects[i]}\nendobj\n`;
    }
    const xref = pdf.length;
    pdf += `xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;
    for (let i = 1; i <= objects.length; i++) {
        pdf += String(objOffsets[i]).padStart(10,"0") + " 00000 n \n";
    }
    pdf += `trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
    return pdf;
}

function downloadPDF() {
    const report = getReportData(reportMonth);
    const pdf = buildPDF(report);
    const blob = new Blob([pdf], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "Attendance_Report_" + report.monthValue + ".pdf";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
}


/* =========================
   START APP
========================= */

createMonthSelector();
createReportMonthSelector();
updateSummary();