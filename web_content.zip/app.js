const KEY="glowlink_state_v1";
let state=JSON.parse(localStorage.getItem(KEY)||"null")||{
 users:[
  {id:"glow",email:"glowlink@official.local",password:"demo",first:"Glow",last:"Link",followers:0,verified:true,admin:true,following:[]},
  {id:"demo1",email:"demo1@example.com",password:"demo",first:"Demo",last:"Kullanıcı",followers:0,verified:false,admin:false,following:[]}
 ],
 videos:[
  {id:"v1",owner:"glow",title:"Glow Link'e Hoş Geldin!",desc:"İlk video",url:"https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",likes:0,likedBy:[],views:0}
 ],
 session:null
};
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function me(){return state.users.find(u=>u.id===state.session)}
function login(){
 const e=document.getElementById("email").value.trim().toLowerCase(),p=document.getElementById("password").value;
 let u=state.users.find(x=>x.email.toLowerCase()===e&&x.password===p);
 if(!u){alert("E-posta veya şifre hatalı. Demo yönetici hesabı: glowlink@official.local / demo");return}
 state.session=u.id;save();start();
}
function guest(){state.session=null;save();start(true)}
function logout(){state.session=null;save();location.reload()}
function start(guestMode=false){
 document.getElementById("login").classList.add("hidden");
 document.getElementById("nav").classList.remove("hidden");
 show("home"); renderFeed();
}
function show(id){
 document.querySelectorAll(".screen").forEach(x=>x.classList.add("hidden"));
 document.getElementById(id).classList.remove("hidden");
 if(id==="profile")renderProfile();
 if(id==="home")renderFeed();
}
function renderFeed(){
 let q=(document.getElementById("search")?.value||"").toLowerCase();
 let vids=state.videos.filter(v=>{let o=state.users.find(u=>u.id===v.owner);return !q||v.title.toLowerCase().includes(q)||(o&&(o.first+" "+o.last).toLowerCase().includes(q))});
 const f=document.getElementById("feed"); if(!f)return;
 f.innerHTML=vids.length?vids.map(v=>{
  const o=state.users.find(u=>u.id===v.owner),liked=me()?.id&&v.likedBy.includes(me().id);
  return `<article class="video"><video controls playsinline preload="metadata" src="${esc(v.url)}" onplay="view('${v.id}')"></video><div class="video-body"><b>${esc(v.title)}</b><p class="muted">${esc(v.desc||"")}<br>${esc(o?.first+" "+o?.last||"")} ${o?.verified?'<span class="verified">✓</span>':''}</p><div class="actions"><button class="${liked?'liked':''}" onclick="like('${v.id}')">❤️ ${v.likes}</button><button>👁️ ${v.views}</button><button onclick="follow('${o.id}')">➕ ${me()?.following?.includes(o.id)?'Takiptesin':'Takip Et'}</button></div></div></article>`
 }).join(""):'<div class="empty">Video bulunamadı.</div>';
}
function like(id){
 if(!me()){alert("Beğenmek için giriş yapmalısın.");return}
 let v=state.videos.find(x=>x.id===id),i=v.likedBy.indexOf(me().id);
 if(i<0){v.likedBy.push(me().id);v.likes++}else{v.likedBy.splice(i,1);v.likes--}
 save();renderFeed();
}
function follow(uid){
 if(!me()){alert("Takip etmek için giriş yapmalısın.");return}
 if(uid===me().id){alert("Kendi hesabını takip edemezsin.");return}
 let m=me(),u=state.users.find(x=>x.id===uid),i=m.following.indexOf(uid);
 if(i<0){m.following.push(uid);u.followers++}else{m.following.splice(i,1);u.followers=Math.max(0,u.followers-1)}
 save();renderFeed();renderProfile();
}
function view(id){let v=state.videos.find(x=>x.id===id);if(!v._viewed){v.views++;v._viewed=true;save()}}
function renderProfile(){
 let u=me();if(!u)return;
 document.getElementById("profileName").innerHTML=esc((u.first+" "+u.last).trim()||"Kullanıcı")+" "+(u.verified?'<span class="verified">✓</span>':'');
 document.getElementById("profileEmail").textContent=u.email;
 document.getElementById("followers").textContent=u.followers;
 let a=document.getElementById("avatar");a.innerHTML=u.avatar?`<img src="${esc(u.avatar)}">`:esc((u.first||"G")[0].toUpperCase());
 document.getElementById("adminBtn").classList.toggle("hidden",!u.admin);
 document.getElementById("myVideos").innerHTML=state.videos.filter(v=>v.owner===u.id).map(v=>`<div class="card" style="margin:10px 0"><b>${esc(v.title)}</b><div class="muted">${v.views} izlenme · ${v.likes} beğeni</div><button class="danger" onclick="deleteVideo('${v.id}')">🗑️ Videoyu Sil</button></div>`).join("")||'<div class="empty">Henüz videon yok.</div>';
}
function addVideo(){
 if(!me()){alert("Video eklemek için giriş yapmalısın.");return}
 let t=document.getElementById("videoTitle").value.trim(),url=document.getElementById("videoUrl").value.trim(),d=document.getElementById("videoDesc").value.trim();
 if(!t||!url){alert("Başlık ve video URL gerekli.");return}
 state.videos.unshift({id:"v"+Date.now(),owner:me().id,title:t,desc:d,url,likes:0,likedBy:[],views:0});
 save();document.getElementById("videoTitle").value="";document.getElementById("videoUrl").value="";document.getElementById("videoDesc").value="";show("home");renderFeed();
}
function deleteVideo(id){if(confirm("Bu videoyu silmek istediğine emin misin?")){state.videos=state.videos.filter(v=>v.id!==id);save();renderProfile()}}
function openSettings(){
 if(!me()){alert("Ayarlar için giriş yapmalısın.");return}
 let u=me();document.getElementById("firstName").value=u.first;document.getElementById("lastName").value=u.last;document.getElementById("avatarInput").value=u.avatar||"";
 document.getElementById("settings").classList.remove("hidden")
}
function closeSettings(){document.getElementById("settings").classList.add("hidden")}
function saveProfile(){let u=me();u.first=document.getElementById("firstName").value.trim()||u.first;u.last=document.getElementById("lastName").value.trim()||u.last;u.avatar=document.getElementById("avatarInput").value.trim();save();closeSettings();renderProfile()}
function openAdmin(){
 if(!me()?.admin)return;
 document.getElementById("users").innerHTML=state.users.map(u=>`<div class="userrow"><div><b>${esc(u.first+" "+u.last)}</b> ${u.verified?'<span class="verified">✓</span>':''}<br><span class="muted">${esc(u.email)} · ${u.followers} takipçi</span></div><span>${u.admin?"👑 Yönetici":"Kullanıcı"}</span></div>`).join("");
 document.getElementById("admin").classList.remove("hidden")
}
function closeAdmin(){document.getElementById("admin").classList.add("hidden")}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
if(state.session)start();
