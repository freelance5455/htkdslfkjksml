const cfg=window.SILVER_ONE_CONFIG||{};
let sb=null;
const state={page:'home',cat:'silver',silver:[],watches:[],perfumes:[],invoices:[],expenses:[],activities:[],session:null,cart:[]};
const $=s=>document.querySelector(s);
const money=n=>Number(n||0).toLocaleString('en-US',{minimumFractionDigits:0,maximumFractionDigits:2})+' د.أ';
const dateEN=d=>new Date(d).toLocaleDateString('en-US');
const dateTimeEN=d=>new Date(d).toLocaleString('en-US');
function configured(){return cfg.SUPABASE_URL&&cfg.SUPABASE_ANON_KEY&&!cfg.SUPABASE_URL.includes('YOUR_')&&!cfg.SUPABASE_ANON_KEY.includes('YOUR_')}
function toast(t){let x=document.createElement('div');x.className='toast';x.textContent=t;document.body.appendChild(x);setTimeout(()=>x.remove(),2500)}
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
async function boot(){
  if(!configured()){showSetup();return}
  sb=supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);
  const {data:{session}}=await sb.auth.getSession(); state.session=session;
  if(!session){showLogin();return}
  sb.auth.onAuthStateChange((_e,s)=>{state.session=s;if(!s)showLogin()});
  await refresh();
  if(sb.channel){sb.channel('silver-one-sync').on('postgres_changes',{event:'*',schema:'public',table:'products'},refresh).on('postgres_changes',{event:'*',schema:'public',table:'invoices'},refresh).on('postgres_changes',{event:'*',schema:'public',table:'expenses'},refresh).on('postgres_changes',{event:'*',schema:'public',table:'activity_logs'},refresh).subscribe()}
  render();
}
function showSetup(){document.body.innerHTML=`<div class="auth-screen"><div class="auth-card"><div class="logo big">S1</div><h1>Silver One</h1><p>النسخة السحابية جاهزة، لكن لم يتم ربطها بقاعدة البيانات بعد.</p><div class="setup-note">افتح ملف <b>config.js</b> وضع Project URL و Publishable/Anon key من Supabase، ثم ارفع المجلد من جديد.</div></div></div>`}
function showLogin(){document.body.innerHTML=`<div class="auth-screen"><div class="auth-card"><div class="logo big">S1</div><h1>Silver One</h1><p>تسجيل الدخول للنظام السحابي</p><div class="field"><label>البريد الإلكتروني</label><input id="loginEmail" type="email" autocomplete="username"></div><div class="field"><label>كلمة المرور</label><input id="loginPass" type="password" autocomplete="current-password"></div><button class="btn gold" style="width:100%;margin-top:12px" onclick="login()">تسجيل الدخول</button><div id="loginMsg" class="setup-note" style="margin-top:12px">كل حساب مسجل يمكنه استخدام النظام بالكامل.</div></div></div>`}
async function login(){let e=$('#loginEmail').value.trim(),p=$('#loginPass').value;if(!e||!p)return toast('أدخل البريد وكلمة المرور');let {error}=await sb.auth.signInWithPassword({email:e,password:p});if(error)$('#loginMsg').textContent='تعذر تسجيل الدخول: '+error.message;else await boot()}
async function logout(){await sb.auth.signOut();showLogin()}
async function refresh(){
  const [p,i,e,a]=await Promise.all([
    sb.from('products').select('*').eq('active',true).order('created_at',{ascending:true}),
    sb.from('invoices').select('id,invoice_no,total,created_at,created_by,invoice_items(*)').order('created_at',{ascending:false}),
    sb.from('expenses').select('*').order('created_at',{ascending:false}),
    sb.from('activity_logs').select('*').order('created_at',{ascending:false}).limit(300)
  ]);
  if(p.error){toast('تعذر تحميل المخزون');console.error(p.error);return}
  if(i.error){toast('تعذر تحميل الفواتير');console.error(i.error)}
  if(e.error){toast('تعذر تحميل المصروفات');console.error(e.error)}
  if(a.error){toast('تعذر تحميل سجل النشاطات');console.error(a.error)}
  state.silver=(p.data||[]).filter(x=>x.category==='silver').map(mapProduct);
  state.watches=(p.data||[]).filter(x=>x.category==='watches').map(mapProduct);
  state.perfumes=(p.data||[]).filter(x=>x.category==='perfumes').map(mapProduct);
  state.invoices=(i.data||[]).map(x=>({dbid:x.id,id:x.invoice_no,date:x.created_at,total:Number(x.total),created_by:x.created_by,items:(x.invoice_items||[]).map(y=>({name:y.name,code:y.code,qty:Number(y.qty),price:Number(y.price)}))}));
  state.expenses=(e.data||[]).map(x=>({id:x.id,title:x.title,category:x.category,amount:Number(x.amount),notes:x.notes||'',created_by:x.created_by,date:x.created_at}));
  state.activities=(a.data||[]).map(x=>({id:x.id,action:x.action,details:x.details||'',reference_id:x.reference_id||'',amount:x.amount==null?null:Number(x.amount),created_by:x.created_by,date:x.created_at}));
  if(document.body.querySelector('#content'))render();
}
function mapProduct(x){return {dbid:x.id,id:x.code,name:x.name,type:x.type||'',weight:Number(x.weight||0),price:Number(x.price||0),qty:Number(x.qty||0),total:Number(x.total||0)}}
function allProducts(){return [...state.silver,...state.watches,...state.perfumes]}
function setPage(p){state.page=p;document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===p));render();document.querySelector('.sidebar')?.classList.remove('open')}
function render(){if(!$('#content'))return;let titles={home:'الرئيسية',sales:'بيع',stock:'المخزون',invoices:'الفواتير',archive:'الأرشيف',reports:'التقارير',activities:'سجل النشاطات',expenses:'المصروفات',settings:'الإعدادات'};$('#pageTitle').textContent=titles[state.page]||'Silver One';$('#date').textContent=new Date().toLocaleDateString('en-US',{weekday:'long',year:'numeric',month:'long',day:'numeric'});({home,sales,stock,invoices,archive,reports,activities,expenses,settings}[state.page]||home)()}
function getPeriodStats(from=null,to=null){let inv=state.invoices,ex=state.expenses;if(from){let f=new Date(from+'T00:00:00');let t=to?new Date(to+'T23:59:59.999'):new Date(from+'T23:59:59.999');inv=inv.filter(x=>new Date(x.date)>=f&&new Date(x.date)<=t);ex=ex.filter(x=>new Date(x.date)>=f&&new Date(x.date)<=t)}return {inv,ex,sales:inv.reduce((a,x)=>a+x.total,0),expenses:ex.reduce((a,x)=>a+x.amount,0)}}
function home(){
  let today=new Date().toISOString().slice(0,10),s=getPeriodStats(today,today);
  $('#content').innerHTML=`<div class="page modern-home">
    <div class="modern-head">
      <div class="brand-mark"><div class="gem-logo">◇</div><div><b>Silver One</b><span>إدارة أعمالك بكل سهولة</span></div></div>
      <div class="date-chip">${new Date().toLocaleDateString('ar-JO',{weekday:'long',day:'numeric',month:'long',year:'numeric'})} <span>▣</span></div>
    </div>
    <div class="modern-hero"><div><h1>أهلاً بك في<br><strong>Silver One</strong></h1><p>نظامك الذكي لإدارة المبيعات والمخزون</p></div><div class="hero-art">⌚</div></div>
    <div class="section-title"><span>الخيارات الرئيسية</span><i></i></div>
    <div class="quick-grid">
      <button class="quick-card q-sale" onclick="setPage('sales')"><span class="quick-icon">🛒</span><strong>بيع</strong><small>إنشاء فاتورة مبيعات جديدة</small><em>‹</em></button>
      <button class="quick-card q-stock" onclick="setPage('stock')"><span class="quick-icon">▣</span><strong>المخزون</strong><small>إدارة الأصناف والكميات</small><em>‹</em></button>
      <button class="quick-card q-report" onclick="setPage('reports')"><span class="quick-icon">▥</span><strong>التقارير</strong><small>متابعة الأداء والإحصائيات</small><em>‹</em></button>
      <button class="quick-card q-exp" onclick="setPage('expenses')"><span class="quick-icon">د.أ</span><strong>المصروفات</strong><small>إضافة ومتابعة المصروفات</small><em>‹</em></button>
    </div>
    <div class="daily-summary"><div><b>ملخص اليوم</b><small>${today}</small></div><div><span>إجمالي المبيعات</span><strong>${money(s.sales)}</strong></div><div><span>المصروفات</span><strong>${money(s.expenses)}</strong></div><div><span>صافي اليوم</span><strong>${money(s.sales-s.expenses)}</strong></div></div>
    <div class="home-archive-note" onclick="setPage('archive')"><span>🗂</span><div><b>كل الأدوات في الأرشيف</b><small>الفواتير، سجل النشاطات، الإعدادات والمزيد</small></div><em>‹</em></div>
  </div>`
}
function archive(){
  $('#content').innerHTML=`<div class="page archive-page"><div class="section-title"><span>الأرشيف</span><i></i></div><p class="archive-sub">كل الصفحات الإضافية موجودة هنا حتى تبقى الواجهة الرئيسية بسيطة.</p><div class="archive-grid">
    <button class="archive-card" onclick="setPage('invoices')">🧾<b>الفواتير</b><small>عرض وحفظ فواتير الزبائن</small></button>
    <button class="archive-card" onclick="setPage('reports')">📊<b>التقارير</b><small>الأرشيف اليومي والشهري</small></button>
    <button class="archive-card" onclick="setPage('activities')">📋<b>سجل النشاطات</b><small>متابعة كل العمليات</small></button>
    <button class="archive-card" onclick="setPage('settings')">⚙️<b>الإعدادات</b><small>إعدادات النظام</small></button>
  </div></div>`
}

function stock(){
  let cat=state.cat,arr=state[cat],names={silver:'الفضة',watches:'الساعات',perfumes:'العطور'};
  let rows=arr.map(x=>`<tr><td><b>${esc(x.id)}</b></td><td>${esc(x.name)}</td><td>${esc(x.type||'—')}</td>${cat==='silver'?`<td>${x.weight} غ</td>`:''}<td>${money(x.price)}</td><td>${x.total}</td><td><span class="pill ${x.qty<=2?'low':''}">${x.qty}</span></td><td class="row-actions"><button class="btn light" onclick="printLabel('${esc(x.dbid)}')">🏷 طباعة الكود</button><button class="btn" onclick="addToCartById('${esc(x.dbid)}')">🛒 بيع</button><button class="btn danger" onclick="deleteProduct('${esc(x.dbid)}')">🗑 حذف</button></td></tr>`).join('');
  let colspan=cat==='silver'?8:7;
  $('#content').innerHTML=`<div class="page"><div class="toolbar"><div><h2>${names[cat]}</h2><p>البيانات محفوظة سحابياً ومشتركة بين الأجهزة.</p></div><div class="actions"><button class="btn gold" onclick="openAdd('${cat}')">+ إضافة صنف</button></div></div><div class="tabs"><button class="tab ${cat==='silver'?'active':''}" onclick="state.cat='silver';render()">💍 فضة</button><button class="tab ${cat==='watches'?'active':''}" onclick="state.cat='watches';render()">⌚ ساعات</button><button class="tab ${cat==='perfumes'?'active':''}" onclick="state.cat='perfumes';render()">🌸 عطور</button></div><input class="search" id="q" placeholder="ابحث بالكود أو الاسم..." oninput="filterRows()"><div class="table-wrap" style="margin-top:15px"><table class="table"><thead><tr><th>الكود</th><th>الاسم</th><th>النوع</th>${cat==='silver'?'<th>الوزن</th>':''}<th>السعر</th><th>الكلي</th><th>المتبقي</th><th>إجراء</th></tr></thead><tbody id="rows">${rows||`<tr><td colspan="${colspan}" class="empty">لا توجد أصناف بعد</td></tr>`}</tbody></table></div></div>`
}
function filterRows(){let q=$('#q')?.value.trim().toLowerCase()||'';document.querySelectorAll('#rows tr').forEach(r=>r.style.display=r.textContent.toLowerCase().includes(q)?'':'none')}
async function deleteProduct(id){
  let x=allProducts().find(a=>a.dbid===id);if(!x)return;
  if(!confirm(`هل أنت متأكد من حذف الصنف «${x.name}» (${x.id})؟\nسيتم إخفاؤه من المخزون مع الاحتفاظ بسجل مبيعاته.`))return;
  let {error}=await sb.from('products').update({active:false}).eq('id',id);if(error){toast('تعذر حذف الصنف');console.error(error);return}
  await sb.rpc('add_activity',{p_action:'حذف صنف',p_details:`إخفاء الصنف ${x.name} (${x.id})`,p_reference_id:x.id});
  await refresh();toast('تم حذف الصنف من المخزون')
}
function addToCartById(id){let x=allProducts().find(a=>a.dbid===id);if(!x)return toast('الصنف غير موجود');if(x.qty<1)return toast('الكمية غير متوفرة');addToCart(x);setPage('sales')}
function addToCart(x){let row=state.cart.find(a=>a.product_id===x.dbid);if(row){if(row.qty>=x.qty)return toast('لا يمكن تجاوز الكمية المتوفرة');row.qty++}else state.cart.push({product_id:x.dbid,code:x.id,name:x.name,price:x.price,available:x.qty,qty:1});toast('تمت إضافة الصنف للفاتورة')}
function changeCart(id,delta){let r=state.cart.find(x=>x.product_id===id),p=allProducts().find(x=>x.dbid===id);if(!r||!p)return;if(delta>0&&r.qty>=p.qty)return toast('لا يمكن تجاوز الكمية المتوفرة');r.qty+=delta;if(r.qty<=0)state.cart=state.cart.filter(x=>x.product_id!==id);render()}
function removeCart(id){state.cart=state.cart.filter(x=>x.product_id!==id);render()}
function cartTotal(){return state.cart.reduce((a,x)=>a+x.price*x.qty,0)}
async function finalizeSale(){
  if(!state.cart.length)return toast('السلة فارغة');
  let items=state.cart.map(x=>({product_id:x.product_id,qty:x.qty,price:x.price}));
  let {data,error}=await sb.rpc('create_sale',{p_items:items,p_total:cartTotal()});
  if(error){let m=error.message||'';toast(m.includes('INSUFFICIENT_STOCK')?'الكمية غير متوفرة':'تعذر تسجيل البيع: '+m);console.error(error);return}
  let no=data?.invoice_no;state.cart=[];await refresh();toast(`تم إصدار الفاتورة ${no||''}`);if(no){let inv=state.invoices.find(x=>x.id===no);if(inv)setTimeout(()=>showInvoice(no),250)}
}
function sellByCode(code){let q=String(code||'').trim().toLowerCase();let x=allProducts().find(a=>String(a.id).toLowerCase()===q);if(!x)return toast('الكود غير موجود');addToCart(x);render()}
function openScanner(){
  let modal=$('#modal');modal.className='modal';modal.innerHTML=`<div class="modal-box scanner-box"><div class="modal-head"><h3>مسح كود الصنف</h3><button class="close" onclick="stopScanner();closeModal()">✕</button></div><div id="reader" style="width:100%;max-width:520px;margin:auto"></div><div class="scan-fallback"><label>أو أدخل الكود يدويًا</label><div style="display:flex;gap:8px"><input id="manualCode" class="search" placeholder="مثال S-0001"><button class="btn gold" onclick="manualSellCode()">إضافة للفاتورة</button></div></div><p class="setup-note">وجهي الكاميرا على الباركود، وسيضاف الصنف إلى سلة الفاتورة.</p></div>`;
  try{window._scanner=new Html5Qrcode('reader');window._scanner.start({facingMode:'environment'},{fps:10,qrbox:{width:250,height:120}},code=>{stopScanner();closeModal();sellByCode(code)},()=>{}).catch(()=>toast('تعذر فتح الكاميرا، استخدمي الإدخال اليدوي'))}catch(e){toast('تعذر تشغيل الماسح')}
}
function manualSellCode(){let code=$('#manualCode')?.value||'';stopScanner();closeModal();sellByCode(code)}
function stopScanner(){if(window._scanner){window._scanner.stop().catch(()=>{});window._scanner.clear().catch(()=>{});window._scanner=null}}
function printLabel(dbid){let x=allProducts().find(a=>a.dbid===dbid);if(!x)return;let w=window.open('','_blank');if(!w)return toast('اسمحي بالنوافذ المنبثقة للطباعة');w.document.write(`<html dir="rtl"><head><title>كود ${esc(x.id)}</title><style>body{font-family:Arial;text-align:center;padding:20px}.label{width:280px;margin:auto;border:1px dashed #999;padding:14px}.name{font-weight:bold;margin-bottom:8px}.code{font-size:18px;letter-spacing:2px;margin-top:5px}@media print{body{padding:0}.label{border:0}}</style></head><body><div class="label"><div class="name">${esc(x.name)}</div><svg id="barcode"></svg><div class="code">${esc(x.id)}</div></div><script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"><\/script><script>JsBarcode('#barcode','${esc(x.id)}',{format:'CODE128',displayValue:false,height:55,margin:8});window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body></html>`);w.document.close()}
function openAdd(cat){
  if(cat==='silver'){$('#modal').className='modal';$('#modal').innerHTML=`<div class="modal-box"><div class="modal-head"><h3>إضافة قطعة فضة</h3><button class="close" onclick="closeModal()">✕</button></div><div class="form"><div class="field"><label>اسم القطعة</label><input id="f0" type="text"></div><div class="field"><label>النوع</label><select id="f1" onchange="updateSilverPrice()"><option value="ستاتي">ستاتي — 6 د.أ/غرام</option><option value="رجالي">رجالي — 5 د.أ/غرام</option></select></div><div class="field"><label>الوزن بالغرام</label><input id="f2" type="number" step="0.01" oninput="updateSilverPrice()"></div><div class="field"><label>سعر القطعة المحسوب</label><input id="silverPrice" type="text" readonly></div><div class="field"><label>عدد القطع</label><input id="f4" type="number" step="1" value="1"></div><div class="full"><button class="btn gold" style="width:100%;margin-top:5px" onclick="addItem('silver')">حفظ الصنف وتوليد الكود</button></div></div></div>`;updateSilverPrice();return}
  let title=cat==='watches'?'ساعة':'عطر';$('#modal').className='modal';$('#modal').innerHTML=`<div class="modal-box"><div class="modal-head"><h3>إضافة ${title}</h3><button class="close" onclick="closeModal()">✕</button></div><div class="form"><div class="field"><label>الاسم</label><input id="f0" type="text"></div><div class="field"><label>النوع</label><input id="f1" type="text"></div><div class="field"><label>السعر</label><input id="f2" type="number" step="0.01"></div><div class="field"><label>الكمية</label><input id="f3" type="number" step="1" value="1"></div><div class="full"><button class="btn gold" style="width:100%;margin-top:5px" onclick="addItem('${cat}')">حفظ الصنف وتوليد الكود</button></div></div></div>`
}
function updateSilverPrice(){let w=Number($('#f2')?.value||0),type=$('#f1')?.value,rate=type==='رجالي'?5:6,p=w*rate;if($('#silverPrice'))$('#silverPrice').value=money(p)}
async function getNextProductCode(cat){
  // Prefer the database sequence function. If the SQL upgrade has not been run yet,
  // fall back to the current inventory so adding items still works.
  const r=await sb.rpc('next_product_code',{p_category:cat});
  if(!r.error && r.data)return String(r.data);
  console.warn('next_product_code RPC unavailable; using client fallback',r.error);
  const prefix=cat==='silver'?'S':cat==='watches'?'W':'P';
  const {data:rows,error}=await sb.from('products').select('code').like('code',prefix+'-%');
  if(error)throw error;
  let max=0;
  (rows||[]).forEach(x=>{const m=String(x.code||'').match(new RegExp('^'+prefix+'-(\\d+)$'));if(m)max=Math.max(max,Number(m[1]));});
  return prefix+'-'+String(max+1).padStart(4,'0');
}
async function addItem(cat){
  let code;try{code=await getNextProductCode(cat)}catch(e){toast('تعذر توليد كود الصنف — تأكدي من الاتصال بقاعدة البيانات');console.error(e);return}
  let item;
  if(cat==='silver'){let name=$('#f0').value.trim(),type=$('#f1').value,weight=Number($('#f2').value),qty=Number($('#f4').value),rate=type==='رجالي'?5:6,price=weight*rate;if(!name||weight<=0||qty<=0)return toast('أكمل البيانات بشكل صحيح');item={code,category:cat,name,type,weight,price,qty,total:qty}}
  else{let name=$('#f0').value.trim(),type=$('#f1').value.trim(),price=Number($('#f2').value),qty=Number($('#f3').value);if(!name||price<=0||qty<=0)return toast('أكمل البيانات بشكل صحيح');item={code,category:cat,name,type,price,qty,total:qty}}
  let {error}=await sb.from('products').insert(item);if(error){toast(error.code==='23505'?'الكود مستخدم بالفعل':'تعذر حفظ الصنف');console.error(error);return}
  await sb.rpc('add_activity',{p_action:'إضافة صنف',p_details:`إضافة ${item.name} (${code})`,p_reference_id:code});closeModal();await refresh();toast(`تمت إضافة الصنف — الكود ${code}`);setTimeout(()=>printLabelByCode(code),300)
}
function printLabelByCode(code){let x=allProducts().find(a=>a.id===code);if(x)printLabel(x.dbid)}
function closeModal(){$('#modal').className='modal hidden'}
function sales(){
  let total=cartTotal();let list=allProducts().filter(x=>x.qty>0).slice(0,30);
  $('#content').innerHTML=`<div class="page"><div class="toolbar"><div><h2>المبيعات</h2><p>أضيفي أكثر من صنف للفاتورة، ثم أصدريها مرة واحدة.</p></div><div class="actions"><button class="btn gold" onclick="openScanner()">📷 مسح كود</button></div></div><div class="sales-layout"><div class="card"><h3>اختيار الأصناف</h3><input class="search" id="saleSearch" placeholder="ابحث بالكود أو الاسم..." oninput="renderSaleProducts()"><div id="saleProducts" class="product-list">${saleProductHtml(list)}</div></div><div class="card cart-card"><div class="toolbar"><h3 style="margin:0">🛒 سلة المشتريات</h3><button class="btn light" onclick="state.cart=[];render()">تفريغ</button></div>${state.cart.map(x=>`<div class="cart-row"><div><b>${esc(x.name)}</b><small>${esc(x.code)} · ${money(x.price)}</small></div><div class="qty-controls"><button onclick="changeCart('${esc(x.product_id)}',-1)">−</button><b>${x.qty}</b><button onclick="changeCart('${esc(x.product_id)}',1)">+</button><button class="trash" onclick="removeCart('${esc(x.product_id)}')">🗑</button></div><strong>${money(x.qty*x.price)}</strong></div>`).join('')||'<div class="empty">السلة فارغة. امسحي الكود أو اختاري صنفًا.</div>'}<div class="cart-total"><span>الإجمالي الكلي</span><b>${money(total)}</b></div><button class="btn gold big-btn" onclick="finalizeSale()">🧾 إصدار الفاتورة</button></div></div></div>`
}
function saleProductHtml(list){return list.map(x=>`<div class="product-line"><div><b>${esc(x.name)}</b><small>${esc(x.id)} ${x.type?`· ${esc(x.type)}`:''} · ${money(x.price)} · متوفر ${x.qty}</small></div><button class="btn" onclick="addToCartById('${esc(x.dbid)}')">+ إضافة</button></div>`).join('')||'<div class="empty">لا توجد أصناف متوفرة.</div>'}
function renderSaleProducts(){let q=$('#saleSearch')?.value.trim().toLowerCase()||'';let list=allProducts().filter(x=>x.qty>0&&(x.name.toLowerCase().includes(q)||x.id.toLowerCase().includes(q))).slice(0,50);$('#saleProducts').innerHTML=saleProductHtml(list)}
function invoices(){$('#content').innerHTML=`<div class="page"><div class="toolbar"><div><h2>فواتير الزبائن</h2><p>أرشيف جميع الفواتير محفوظ تلقائيًا حسب التاريخ.</p></div></div><div class="table-wrap"><table class="table"><thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>الأصناف</th><th>الإجمالي</th><th></th></tr></thead><tbody>${state.invoices.map(i=>`<tr><td>${esc(i.id)}</td><td>${dateTimeEN(i.date)}</td><td>${i.items.length}</td><td>${money(i.total)}</td><td><button class="btn light" onclick="showInvoice('${esc(i.id)}')">عرض / طباعة</button></td></tr>`).join('')||'<tr><td colspan="5" class="empty">لا توجد فواتير</td></tr>'}</tbody></table></div></div>`}
function showInvoice(id){let i=state.invoices.find(x=>x.id===id);if(!i)return;$('#modal').className='modal';$('#modal').innerHTML=`<div class="modal-box"><div class="invoice" id="printArea"><div class="invoice-head"><div><h2>Silver One</h2><div>نظام الفوترة والمخزون</div></div><div><b>${esc(i.id)}</b><br>${dateTimeEN(i.date)}</div></div><table><thead><tr><th>الصنف</th><th>الكود</th><th>الكمية</th><th>السعر</th><th>المجموع</th></tr></thead><tbody>${i.items.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.code)}</td><td>${x.qty}</td><td>${money(x.price)}</td><td>${money(x.qty*x.price)}</td></tr>`).join('')}</tbody></table><div class="total">الإجمالي: ${money(i.total)}</div></div><div style="display:flex;gap:8px;margin-top:15px"><button class="btn gold" onclick="printInvoice()">🖨 طباعة</button><button class="btn light" onclick="closeModal()">إغلاق</button></div></div>`}
function printInvoice(){let w=window.open('','_blank');if(!w)return toast('اسمحي بالنوافذ المنبثقة للطباعة');w.document.write(`<html dir="rtl"><head><title>Silver One</title><style>body{font-family:Arial;padding:30px}table{width:100%;border-collapse:collapse;margin-top:20px}td,th{padding:10px;border-bottom:1px solid #ddd;text-align:right}.total{text-align:left;font-size:20px;font-weight:bold;margin-top:20px}</style></head><body>${$('#printArea').innerHTML}</body></html>`);w.document.close();w.print()}
function reports(){
  let now=new Date(),ym=now.toISOString().slice(0,7),monthInv=state.invoices.filter(x=>x.date.slice(0,7)===ym),monthExp=state.expenses.filter(x=>x.date.slice(0,7)===ym),monthSales=monthInv.reduce((a,x)=>a+x.total,0),monthExpenses=monthExp.reduce((a,x)=>a+x.amount,0),days={};
  state.invoices.forEach(i=>{let d=i.date.slice(0,10);if(!days[d])days[d]={sales:0,count:0};days[d].sales+=i.total;days[d].count++});
  state.expenses.forEach(e=>{let d=e.date.slice(0,10);if(!days[d])days[d]={sales:0,count:0};days[d].expenses=(days[d].expenses||0)+e.amount});
  let daily=Object.entries(days).sort((a,b)=>b[0].localeCompare(a[0])).slice(0,31);
  let low=allProducts().filter(x=>x.qty<=2),silverWeight=state.silver.reduce((a,x)=>a+x.weight*x.qty,0);
  $('#content').innerHTML=`<div class="page"><div class="toolbar"><div><h2>التقارير والأرشيف</h2><p>المبيعات محفوظة يومًا بيوم وشهرًا بشهر من خلال تاريخ الفواتير.</p></div><button class="btn gold" onclick="setPage('invoices')">عرض كل الفواتير</button></div><div class="cards"><div class="card"><div class="label">مبيعات هذا الشهر</div><div class="value">${money(monthSales)}</div></div><div class="card"><div class="label">مصروفات هذا الشهر</div><div class="value">${money(monthExpenses)}</div></div><div class="card"><div class="label">صافي هذا الشهر</div><div class="value">${money(monthSales-monthExpenses)}</div></div><div class="card"><div class="label">فواتير هذا الشهر</div><div class="value">${monthInv.length}</div></div></div><div class="cards" style="margin-top:15px"><div class="card"><div class="label">إجمالي المخزون</div><div class="value">${allProducts().reduce((a,x)=>a+x.qty,0)} قطعة</div></div><div class="card"><div class="label">وزن الفضة المتبقي</div><div class="value">${silverWeight.toFixed(2)} غ</div></div><div class="card"><div class="label">أصناف منخفضة المخزون</div><div class="value">${low.length}</div></div><div class="card"><div class="label">إجمالي المبيعات الكلي</div><div class="value">${money(state.invoices.reduce((a,x)=>a+x.total,0))}</div></div></div><div class="card" style="margin-top:18px"><h3>📅 الأرشيف اليومي</h3><div class="table-wrap"><table class="table"><thead><tr><th>اليوم</th><th>المبيعات</th><th>المصروفات</th><th>الصافي</th><th>الفواتير</th></tr></thead><tbody>${daily.map(([d,v])=>`<tr><td>${dateEN(d)}</td><td>${money(v.sales)}</td><td>${money(v.expenses||0)}</td><td><b>${money(v.sales-(v.expenses||0))}</b></td><td>${v.count}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">لا توجد بيانات بعد.</td></tr>'}</tbody></table></div></div><div class="card" style="margin-top:18px"><h3>📆 أرشيف الأشهر</h3>${monthArchiveHtml()}</div></div>`
}
function monthArchiveHtml(){let m={};state.invoices.forEach(i=>{let k=i.date.slice(0,7);if(!m[k])m[k]={sales:0,count:0,expenses:0};m[k].sales+=i.total;m[k].count++});state.expenses.forEach(e=>{let k=e.date.slice(0,7);if(!m[k])m[k]={sales:0,count:0,expenses:0};m[k].expenses+=e.amount});let rows=Object.entries(m).sort((a,b)=>b[0].localeCompare(a[0]));return `<div class="table-wrap"><table class="table"><thead><tr><th>الشهر</th><th>المبيعات</th><th>المصروفات</th><th>الصافي</th><th>الفواتير</th></tr></thead><tbody>${rows.map(([k,v])=>`<tr><td>${esc(k)}</td><td>${money(v.sales)}</td><td>${money(v.expenses)}</td><td><b>${money(v.sales-v.expenses)}</b></td><td>${v.count}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">لا توجد بيانات بعد.</td></tr>'}</tbody></table></div>`}
function activities(){$('#content').innerHTML=`<div class="page"><div class="toolbar"><div><h2>سجل النشاطات</h2><p>كل العمليات المهمة في النظام مرتبة من الأحدث إلى الأقدم.</p></div></div><div class="table-wrap"><table class="table"><thead><tr><th>التاريخ</th><th>النشاط</th><th>التفاصيل</th><th>المرجع</th><th>المبلغ</th></tr></thead><tbody>${state.activities.map(a=>`<tr><td>${dateTimeEN(a.date)}</td><td><span class="activity-badge">${esc(a.action)}</span></td><td>${esc(a.details)}</td><td>${esc(a.reference_id||'—')}</td><td>${a.amount==null?'—':money(a.amount)}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">لا يوجد نشاط مسجل بعد.</td></tr>'}</tbody></table></div></div>`}
function expenses(){let total=state.expenses.reduce((a,x)=>a+x.amount,0);$('#content').innerHTML=`<div class="page"><div class="toolbar"><div><h2>المصروفات</h2><p>سجلي مصروفات المحل ليظهر صافي الربح في التقارير.</p></div><button class="btn gold" onclick="openExpense()">+ إضافة مصروف</button></div><div class="cards"><div class="card"><div class="label">إجمالي المصروفات</div><div class="value">${money(total)}</div></div><div class="card"><div class="label">عدد المصروفات</div><div class="value">${state.expenses.length}</div></div></div><div class="table-wrap" style="margin-top:18px"><table class="table"><thead><tr><th>التاريخ</th><th>المصروف</th><th>التصنيف</th><th>المبلغ</th><th>ملاحظات</th><th></th></tr></thead><tbody>${state.expenses.map(x=>`<tr><td>${dateTimeEN(x.date)}</td><td>${esc(x.title)}</td><td>${esc(x.category)}</td><td>${money(x.amount)}</td><td>${esc(x.notes||'—')}</td><td><button class="btn danger" onclick="deleteExpense('${esc(x.id)}')">🗑 حذف</button></td></tr>`).join('')||'<tr><td colspan="6" class="empty">لا توجد مصروفات بعد.</td></tr>'}</tbody></table></div></div>`}
function openExpense(){$('#modal').className='modal';$('#modal').innerHTML=`<div class="modal-box"><div class="modal-head"><h3>إضافة مصروف</h3><button class="close" onclick="closeModal()">✕</button></div><div class="form"><div class="field"><label>اسم/وصف المصروف</label><input id="exTitle" placeholder="مثال: كهرباء"></div><div class="field"><label>التصنيف</label><select id="exCat"><option>كهرباء</option><option>إيجار</option><option>رواتب</option><option>شراء بضاعة</option><option>مواصلات</option><option>صيانة</option><option>أخرى</option></select></div><div class="field"><label>المبلغ</label><input id="exAmount" type="number" step="0.01"></div><div class="field"><label>التاريخ</label><input id="exDate" type="date" value="${new Date().toISOString().slice(0,10)}"></div><div class="field full"><label>ملاحظات</label><input id="exNotes"></div><div class="full"><button class="btn gold" style="width:100%" onclick="saveExpense()">حفظ المصروف</button></div></div></div>`}
async function saveExpense(){let title=$('#exTitle').value.trim(),category=$('#exCat').value,amount=Number($('#exAmount').value),notes=$('#exNotes').value.trim(),ds=$('#exDate').value;if(!title||amount<0||!ds)return toast('أكمل بيانات المصروف');let created=ds===new Date().toISOString().slice(0,10)?new Date().toISOString():new Date(ds+'T12:00:00').toISOString();let {data,error}=await sb.from('expenses').insert({title,category,amount,notes,created_by:state.session?.user?.id,created_at:created}).select().single();if(error){toast('تعذر حفظ المصروف');console.error(error);return}await sb.rpc('add_activity',{p_action:'إضافة مصروف',p_details:`${title} — ${category}`,p_reference_id:data.id,p_amount:amount});closeModal();await refresh();toast('تم حفظ المصروف')}
async function deleteExpense(id){let x=state.expenses.find(a=>a.id===id);if(!x)return;if(!confirm(`حذف المصروف «${x.title}» بقيمة ${money(x.amount)}؟`))return;let {error}=await sb.from('expenses').delete().eq('id',id);if(error){toast('تعذر حذف المصروف');return}await sb.rpc('add_activity',{p_action:'حذف مصروف',p_details:`حذف ${x.title}`,p_reference_id:id,p_amount:x.amount});await refresh();toast('تم حذف المصروف')}
function settings(){$('#content').innerHTML=`<div class="page"><h2>الإعدادات</h2><div class="card"><h3>الحساب</h3><p>${esc(state.session?.user?.email||'')}</p><button class="btn light" onclick="logout()">تسجيل الخروج</button></div><div class="card" style="margin-top:15px"><h3>حالة البيانات</h3><p>البيانات محفوظة في قاعدة بيانات سحابية مشتركة بين الأجهزة، مع أرشيف للفواتير والمصروفات وسجل للنشاطات.</p></div></div>`}
window.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.nav').forEach(x=>x.onclick=()=>setPage(x.dataset.page));boot()});
