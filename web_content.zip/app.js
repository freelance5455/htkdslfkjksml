const API = localStorage.getItem("ilostan_api") || "http://localhost:3000/api";
let vehicles=[], currentUser=null;

const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(t){const x=$("#toast");x.textContent=t;x.style.display="block";setTimeout(()=>x.style.display="none",2200)}
async function api(path,opt={}){try{const r=await fetch(API+path,{credentials:"include",...opt});if(!r.ok)throw new Error(await r.text());return await r.json()}catch(e){throw e}}
function view(id){document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));$("#"+id).classList.add("active");window.scrollTo(0,0);if(id==="vehicles")loadVehicles();if(id==="stats")loadStats();if(id==="account")renderAccount()}

document.addEventListener("click",e=>{const v=e.target.closest("[data-view]");if(v)view(v.dataset.view)});
$("#searchBtn").onclick=()=>loadVehicles($("#search").value.trim());
$("#search").onkeydown=e=>{if(e.key==="Enter")loadVehicles(e.target.value.trim())};
$("#addVehicleBtn").onclick=()=>renderAdd();

async function loadVehicles(q=""){
  $("#vehicleList").innerHTML='<div class="panel">Ładowanie…</div>';
  try{
    const d=await api("/vehicles"+(q?"?search="+encodeURIComponent(q):""));
    vehicles=d.vehicles||d||[];
  }catch(e){
    vehicles=JSON.parse(localStorage.getItem("demoVehicles")||"[]");
    if(!vehicles.length)vehicles=[
      {id:1,series:"EP09",number:"001",name:"EP09-001",type:"lokomotywa elektryczna",status:"czynny"},
      {id:2,series:"EU07",number:"001",name:"EU07-001",type:"lokomotywa elektryczna",status:"czynny"},
      {id:3,series:"SM42",number:"3001",name:"SM42-3001",type:"lokomotywa spalinowa",status:"odstawiony"}
    ].filter(v=>!q||JSON.stringify(v).toLowerCase().includes(q.toLowerCase()));
  }
  $("#vehicleList").innerHTML=vehicles.length?vehicles.map(v=>`<article class="vehicle" data-id="${v.id}"><div class="photo">🚆</div><h3>${esc(v.name||((v.series||"")+" "+(v.number||"")))}</h3><span class="tag">${esc(v.type||"pojazd")}</span><p class="muted">${esc(v.status||"brak statusu")}</p></article>`).join(""):"<div class='panel'>Brak pojazdów.</div>";
  document.querySelectorAll(".vehicle[data-id]").forEach(x=>x.onclick=()=>loadVehicle(x.dataset.id));
}
async function loadVehicle(id){
  view("vehicle");$("#vehicleDetail").innerHTML='<div class="panel">Ładowanie…</div>';
  let v;
  try{v=await api("/vehicles/"+id)}catch(e){v=vehicles.find(x=>String(x.id)===String(id))}
  if(!v){$("#vehicleDetail").innerHTML="<div class='panel'>Nie znaleziono pojazdu.</div>";return}
  $("#vehicleDetail").innerHTML=`<div class="detail"><div class="detail-photo">🚂</div><div class="panel"><p class="eyebrow">POJAZD</p><h2>${esc(v.name||v.series+" "+v.number)}</h2><span class="tag">${esc(v.type||"")}</span><div class="meta"><div><small>Seria</small><strong>${esc(v.series||"-")}</strong></div><div><small>Numer</small><strong>${esc(v.number||"-")}</strong></div><div><small>Status</small><strong>${esc(v.status||"-")}</strong></div><div><small>Przewoźnik</small><strong>${esc(v.carrier||"-")}</strong></div></div><button class="primary" id="photoBtn">📷 Dodaj zdjęcie</button></div></div><div class="panel" style="margin-top:18px"><h3>Komentarze</h3><div id="comments">Ładowanie…</div><div class="form"><textarea id="commentText" placeholder="Dodaj komentarz"></textarea><button class="primary" id="commentBtn">Dodaj komentarz</button></div></div>`;
  $("#photoBtn").onclick=()=>{if(!currentUser)return toast("Najpierw zaloguj się.");toast("W tej wersji webowej wybór zdjęcia wymaga podpięcia endpointu uploadu.");};
  try{const c=await api("/vehicles/"+id+"/comments");$("#comments").innerHTML=(c.comments||c||[]).map(x=>`<div class="comment"><strong>${esc(x.user_name||x.email||"Użytkownik")}</strong><div>${esc(x.content||x.text)}</div></div>`).join("")||"<p class='muted'>Brak komentarzy.</p>"}catch(e){$("#comments").innerHTML="<p class='muted'>Komentarze pojawią się po połączeniu z serwerem.</p>"}
  $("#commentBtn").onclick=async()=>{const text=$("#commentText").value.trim();if(!text)return;if(!currentUser)return toast("Zaloguj się, aby komentować.");try{await api("/vehicles/"+id+"/comments",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({content:text})});toast("Dodano komentarz.");loadVehicle(id)}catch(e){toast("Nie udało się dodać komentarza.")}};
}
async function loadStats(){
  try{const s=await api("/stats");renderStats(s)}catch(e){renderStats({vehicles:vehicles.length,users:"—",comments:"—",photos:"—"})}
}
function renderStats(s){const data=[["Pojazdy",s.vehicles??s.totalVehicles??0],["Użytkownicy",s.users??0],["Komentarze",s.comments??0],["Zdjęcia",s.photos??0]];$("#statsCards").innerHTML=data.map(x=>`<div class="card"><strong>${esc(x[1])}</strong><span class="muted">${esc(x[0])}</span></div>`).join("");$("#homeStats").innerHTML=data.slice(0,3).map(x=>`<div class="card"><strong>${esc(x[1])}</strong><span class="muted">${esc(x[0])}</span></div>`).join("")}
function renderAccount(){
 if(currentUser){$("#accountContent").innerHTML=`<div class="panel"><p class="eyebrow">KONTO</p><h2>Witaj, ${esc(currentUser.name||currentUser.email)}</h2><p class="muted">${esc(currentUser.email||"")}</p><button id="logout" class="primary">Wyloguj</button></div>`;$("#logout").onclick=async()=>{try{await api("/logout",{method:"POST"})}catch(e){}currentUser=null;renderAccount();toast("Wylogowano.")}}
 else $("#accountContent").innerHTML=`<div class="panel form"><p class="eyebrow">KONTO</p><h2>Zaloguj się</h2><input id="email" type="email" placeholder="E-mail"><input id="password" type="password" placeholder="Hasło"><button id="login" class="primary">Zaloguj</button><hr><h3>Rejestracja</h3><input id="regName" placeholder="Nazwa użytkownika"><input id="regEmail" type="email" placeholder="E-mail"><input id="regPassword" type="password" placeholder="Hasło"><button id="register">Utwórz konto</button></div>`;
 if(!currentUser){$("#login").onclick=async()=>{try{currentUser=await api("/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:$("#email").value,password:$("#password").value})});toast("Zalogowano.");renderAccount()}catch(e){toast("Błędny login lub hasło.")}};$("#register").onclick=async()=>{try{currentUser=await api("/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name:$("#regName").value,email:$("#regEmail").value,password:$("#regPassword").value})});toast("Konto utworzone.");renderAccount()}catch(e){toast("Nie udało się utworzyć konta.")}}}
}
function renderAdd(){
 if(!currentUser){toast("Zaloguj się, aby dodać pojazd.");return}
 $("#vehicleDetail").innerHTML=`<div class="panel form"><button class="back" data-view="vehicles">← Wróć</button><h2>Dodaj pojazd</h2><input id="series" placeholder="Seria"><input id="number" placeholder="Numer"><input id="name" placeholder="Nazwa / oznaczenie"><input id="type" placeholder="Typ"><input id="status" placeholder="Status"><button class="primary" id="saveVehicle">Zapisz pojazd</button></div>`;
 view("vehicle");
 $("#saveVehicle").onclick=async()=>{const body={series:$("#series").value,number:$("#number").value,name:$("#name").value,type:$("#type").value,status:$("#status").value};try{await api("/vehicles",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});toast("Pojazd dodany.");view("vehicles")}catch(e){toast("Nie udało się dodać pojazdu.")}};
}
(async()=>{try{currentUser=await api("/me")}catch(e){}loadVehicles();loadStats();renderAccount()})();