const input=document.getElementById('photoInput'), canvas=document.getElementById('canvas'), ctx=canvas.getContext('2d',{willReadFrequently:true});
const empty=document.getElementById('empty'), enhanceBtn=document.getElementById('enhanceBtn'), resetBtn=document.getElementById('resetBtn'), saveBtn=document.getElementById('saveBtn'), applyBtn=document.getElementById('applyBtn');
const sliders=['brightness','contrast','color','sharpness']; let original=null, imageName='enhanced-photo';
function setReady(v){[enhanceBtn,resetBtn,saveBtn,applyBtn].forEach(b=>b.disabled=!v)}
input.addEventListener('change',()=>{
 const file=input.files&&input.files[0]; if(!file)return;
 if(!file.type.startsWith('image/')){alert('Please choose an image file.');return}
 imageName=(file.name||'photo').replace(/\.[^.]+$/,'');
 const url=URL.createObjectURL(file), img=new Image();
 img.onload=()=>{const max=2400,scale=Math.min(1,max/Math.max(img.width,img.height));canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);ctx.drawImage(img,0,0,canvas.width,canvas.height);original=ctx.getImageData(0,0,canvas.width,canvas.height);canvas.style.display='block';empty.style.display='none';URL.revokeObjectURL(url);setReady(true);sliders.forEach(id=>document.getElementById(id).value=0);updateLabels();};
 img.onerror=()=>{URL.revokeObjectURL(url);alert('Could not open this image.')};img.src=url;
});
function updateLabels(){sliders.forEach(id=>{const v=+document.getElementById(id).value;document.getElementById(id+'Out').textContent=(id==='brightness'&&v>0?'+':'')+v})}
sliders.forEach(id=>document.getElementById(id).addEventListener('input',updateLabels));
function process(enhance=false){
 if(!original)return;
 const data=new Uint8ClampedArray(original.data), b=+document.getElementById('brightness').value, c=+document.getElementById('contrast').value, sat=+document.getElementById('color').value, sharp=+document.getElementById('sharpness').value;
 const contrast=(259*(c+255))/(255*(259-c)), factor=1+sat/100;
 // Optional one-click balanced enhancement; this is deterministic pixel processing, not a neural AI model.
 const autoB=enhance?5:0, autoC=enhance?14:0, autoS=enhance?12:0;
 const cf=(259*(c+autoC+255))/(255*(259-c-autoC));
 for(let i=0;i<data.length;i+=4){
   let r=data[i],g=data[i+1],bl=data[i+2];
   const gray=.299*r+.587*g+.114*bl;
   const f=enhance?1.12:factor;
   r=gray+(r-gray)*f;g=gray+(g-gray)*f;bl=gray+(bl-gray)*f;
   const con=enhance?cf:contrast, br=b+autoB;
   data[i]=con*(r-128)+128+br;data[i+1]=con*(g-128)+128+br;data[i+2]=con*(bl-128)+128+br;
 }
 let out=new ImageData(data,original.width,original.height);
 ctx.putImageData(out,0,0);
 const amount=Math.min(1,(sharp+autoS)/100);
 if(amount>0) sharpen(amount);
}
function sharpen(amount){
 const src=ctx.getImageData(0,0,canvas.width,canvas.height), a=src.data, out=ctx.createImageData(src), d=out.data,w=canvas.width,h=canvas.height;
 for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){let i=(y*w+x)*4;for(let ch=0;ch<3;ch++){let v=5*a[i+ch]-a[i-4+ch]-a[i+4+ch]-a[i-w*4+ch]-a[i+w*4+ch];d[i+ch]=a[i+ch]*(1-amount)+v*amount;}d[i+3]=a[i+3]}
 ctx.putImageData(out,0,0);
}
function restore(){if(original)ctx.putImageData(original,0,0)}
enhanceBtn.addEventListener('click',()=>{sliders.forEach(id=>document.getElementById(id).value=0);updateLabels();process(true)});
applyBtn.addEventListener('click',()=>process(false));
resetBtn.addEventListener('click',()=>{restore();sliders.forEach(id=>document.getElementById(id).value=0);updateLabels()});
saveBtn.addEventListener('click',()=>{canvas.toBlob(blob=>{if(!blob)return;const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=imageName+'-enhanced.png';a.click();URL.revokeObjectURL(url)},'image/png')});
