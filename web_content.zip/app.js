
const $=id=>document.getElementById(id);
let game=null, undoStack=[];
function makePlayerInputs(team,box){$(box).innerHTML='';for(let i=1;i<=11;i++){let inp=document.createElement('input');inp.id=team+i;inp.value=`Team ${team} Player ${i}`;inp.placeholder=`Player ${i}`;inp.setAttribute('aria-label',`Team ${team} player ${i}`);$(box).append(inp)}}
makePlayerInputs('A','playersA');makePlayerInputs('B','playersB');
function teamName(t){return game.names[t]}
function players(t){return game.lineups[t]}
function oversText(b){return Math.floor(b/6)+'.'+(b%6)}
function newStats(names,kind){let o={};names.forEach(n=>o[n]=kind==='bat'?{runs:0,balls:0,fours:0,sixes:0,out:false}:{balls:0,runs:0,wickets:0});return o}
function startMatch(){let a=$('teamA').value.trim(),b=$('teamB').value.trim();if(!a||!b||a===b){alert('Enter two different team names.');return}
let la=Array.from({length:11},(item,i)=>$('A'+(i+1)).value.trim()||`Player ${i+1}`),lb=Array.from({length:11},(item,i)=>$('B'+(i+1)).value.trim()||`Player ${i+1}`);
if(new Set(la).size!==la.length||new Set(lb).size!==lb.length){alert('Player names must be unique within each team.');return}
game={names:{A:a,B:b},lineups:{A:la,B:lb},overs:+$('overs').value,first:$('first').value,bat:$('first').value,bowl:$('first').value==='A'?'B':'A',inn:1,runs:0,wickets:0,balls:0,extras:0,target:null,si:0,ni:1,next:2,bi:0,batStats:{},bowlStats:{},records:[],finished:false};
resetInnings();undoStack=[];$('setup').classList.add('hidden');$('resultScreen').classList.add('hidden');$('match').classList.remove('hidden');render()}
function resetInnings(){game.runs=0;game.wickets=0;game.balls=0;game.extras=0;game.si=0;game.ni=1;game.next=2;game.bi=0;game.batStats=newStats(players(game.bat),'bat');game.bowlStats=newStats(players(game.bowl),'bowl')}
function snap(){undoStack.push(JSON.stringify(game));if(undoStack.length>100)undoStack.shift()}
function currentBatter(){return players(game.bat)[game.si]}
function currentBowler(){return players(game.bowl)[game.bi]}
function over(){return game.balls>=game.overs*6||game.wickets>=10||(game.target!==null&&game.runs>=game.target)}
function ensureLive(){if(game.finished)return false;if(over()){completeInnings();return false}return true}
function rotate(){[game.si,game.ni]=[game.ni,game.si]}
function addRuns(n){if(!ensureLive())return;snap();let batter=currentBatter(),bowler=currentBowler();game.runs+=n;game.batStats[batter].runs+=n;if(n===4)game.batStats[batter].fours++;if(n===6)game.batStats[batter].sixes++;game.bowlStats[bowler].runs+=n;legalBall(n,true);afterBall()}
function legalBall(teamRuns,face){let batter=currentBatter(),bowler=currentBowler();if(face)game.batStats[batter].balls++;game.bowlStats[bowler].balls++;game.balls++;if(teamRuns%2)rotate();if(game.balls%6===0){rotate();game.bi=(game.bi+1)%players(game.bowl).length}}
function afterBall(){render();if(over())setTimeout(completeInnings,150)}
function extra(type){if(!ensureLive())return;let max=type==='wide'||type==='noball'?7:6;let opts=Array.from({length:max},(_,i)=>i+(type==='wide'||type==='noball'?1:0));let title=type==='noball'?'No-ball total':type==='wide'?'Wide total':type==='bye'?'Bye runs':'Leg-bye runs';openModal(`<h2>${title}</h2><p class="muted">${type==='wide'||type==='noball'?'Total team runs including the 1-run penalty.':'Runs taken as extras.'}</p><div class="buttons">${opts.map(n=>`<button data-call="recordExtra('${type}',${n})">${n}</button>`).join('')}</div><div class="modal-foot"><button data-call="closeModal()">Cancel</button></div>`)}
function recordExtra(type,total){closeModal();if(!ensureLive())return;snap();let bowler=currentBowler();let penalty=(type==='wide'||type==='noball')?1:0;game.runs+=total;game.extras+=total;if(type==='wide'||type==='noball'){game.bowlStats[bowler].runs+=total;game.bowlStats[bowler].runs+=0; if(type==='noball'){let batter=currentBatter();let batRuns=Math.max(0,total-penalty);game.batStats[batter].runs+=batRuns;if(batRuns===4)game.batStats[batter].fours++;if(batRuns===6)game.batStats[batter].sixes++;}if(total%2)rotate()}else{let batter=currentBatter();game.batStats[batter].balls++;game.bowlStats[bowler].balls++;game.balls++;if(total%2)rotate();if(game.balls%6===0){rotate();game.bi=(game.bi+1)%players(game.bowl).length}}afterBall()}
function wicket(){if(!ensureLive())return;snap();let batter=currentBatter(),bowler=currentBowler();game.batStats[batter].out=true;game.batStats[batter].balls++;game.wickets++;game.bowlStats[bowler].balls++;game.bowlStats[bowler].wickets++;game.balls++;if(game.wickets<10){let available=players(game.bat).map((n,i)=>({n,i})).filter(x=>x.i!==game.si&&x.i!==game.ni&&!game.batStats[x.n].out&&x.i>=game.next);if(available.length){game.si=available[0].i;game.next=game.si+1}else if(game.wickets<10){game.wickets=10}}if(game.balls%6===0){rotate();game.bi=(game.bi+1)%players(game.bowl).length}afterBall()}
function changeStrike(){if(!game)return;snap();rotate();render()}
function changeBowler(name){let i=players(game.bowl).indexOf(name);if(i>=0){snap();game.bi=i;render()}}
function chooseBatter(){let eligible=players(game.bat).map((n,i)=>({n,i})).filter(x=>x.i!==game.si&&x.i!==game.ni&&!game.batStats[x.n].out&&x.i>=game.next);if(!eligible.length){alert('No eligible batters remain in this lineup.');return}openModal(`<h2>Choose next batter</h2><p class="muted">Batting team: ${esc(teamName(game.bat))}</p><label>Player</label><select id="nextChoice">${eligible.map(x=>`<option value="${x.i}">${esc(x.n)}</option>`).join('')}</select><div class="modal-foot"><button class="primary" data-call="setBatter()">Set next batter</button><button data-call="closeModal()">Cancel</button></div>`)}
function setBatter(){let i=+$('nextChoice').value;let next=Math.min(game.next,players(game.bat).length-1);[players(game.bat)[i],players(game.bat)[next]]=[players(game.bat)[next],players(game.bat)[i]];closeModal();render()}
function addPlayer(){openModal(`<h2>Add player to a team</h2><label>Team</label><select id="addTeam"><option value="${game.bat}">${esc(teamName(game.bat))} (batting)</option><option value="${game.bowl}">${esc(teamName(game.bowl))} (bowling)</option></select><label>Player name</label><input id="newPlayer" placeholder="Enter player name" maxlength="40"><div class="modal-foot"><button class="primary" data-call="savePlayer()">Add player</button><button data-call="closeModal()">Cancel</button></div><p class="muted">A new player joins the chosen team's lineup. To select someone already in the lineup, use Choose next batter.</p>`)}
function savePlayer(){let t=$('addTeam').value,n=$('newPlayer').value.trim();if(!n)return alert('Enter a player name.');if(players(t).includes(n))return alert('That player is already in this team.');players(t).push(n);if(t===game.bat)game.batStats[n]={runs:0,balls:0,fours:0,sixes:0,out:false};else game.bowlStats[n]={balls:0,runs:0,wickets:0};closeModal();render()}
function undo(){if(!undoStack.length)return alert('Nothing to undo.');game=JSON.parse(undoStack.pop());render()}
function endInnings(){if(confirm('End this innings now?'))completeInnings(true)}
function recordInnings(){let bat={},bowl={};players(game.bat).forEach(n=>bat[n]={...game.batStats[n]});players(game.bowl).forEach(n=>bowl[n]={...game.bowlStats[n]});return {innings:game.inn,battingTeam:teamName(game.bat),bowlingTeam:teamName(game.bowl),runs:game.runs,wickets:game.wickets,balls:game.balls,overs:oversText(game.balls),extras:game.extras,batters:bat,bowlers:bowl}}
function completeInnings(manual=false){if(!game||game.finished||game.completing)return;game.completing=true;let rec=recordInnings();if(!game.records.length||game.records[game.records.length-1].innings!==game.inn)game.records.push(rec);if(game.inn===1){game.target=game.runs+1;openModal(`<h2>Innings 1 complete</h2><div class="score"><div class="big">${game.runs}/${game.wickets}</div><div>${esc(rec.battingTeam)} · ${rec.overs} overs · Extras ${rec.extras}</div><div>Target: ${game.target}</div></div>${scorecardHTML(rec)}<button class="primary" data-call="startSecond()">Start second innings</button>`)}else{let first=game.records[0],second=rec;let result=second.runs>=game.target?`${second.battingTeam} won by ${10-second.wickets} wicket(s).`:second.runs===first.runs?'The match is tied.':`${first.battingTeam} won by ${first.runs-second.runs} run(s).`;game.finished=true;let entry={date:new Date().toISOString(),teamA:game.names.A,teamB:game.names.B,overs:game.overs,result,innings:game.records};let hist=historyList();hist.unshift(entry);saveHistoryList(hist);game.completing=false;showFinal(result,entry);return}game.completing=false}

function endMatch(){
 if(!game||game.finished)return;
 if(!confirm('End the match now and save the current result?'))return;
 const rec=recordInnings();
 if(!game.records.length||game.records[game.records.length-1].innings!==game.inn)game.records.push(rec);
 const first=game.records[0];
 let result;
 if(game.inn===2){
  const second=rec;
  result=second.runs>=game.target?`${second.battingTeam} won by ${10-second.wickets} wicket(s).`:second.runs===first.runs?'The match is tied.':`${first.battingTeam} won by ${first.runs-second.runs} run(s).`;
 }else{
  result=`Match ended early. ${rec.battingTeam}: ${rec.runs}/${rec.wickets} (${rec.overs} overs).`;
 }
 game.finished=true;
 const entry={date:new Date().toISOString(),teamA:game.names.A,teamB:game.names.B,overs:game.overs,result,innings:game.records};
 const hist=historyList();hist.unshift(entry);saveHistoryList(hist);showFinal(result,entry);
}

function startSecond(){closeModal();game.inn=2;[game.bat,game.bowl]=[game.bowl,game.bat];resetInnings();undoStack=[];render()}
function scorecardHTML(r){return `<h3>Batting · ${esc(r.battingTeam)}</h3><div style="overflow:auto"><table><tr><th>Batter</th><th>Status</th><th>R</th><th>B</th><th>4s</th><th>6s</th></tr>${Object.entries(r.batters).map(([n,s])=>`<tr><td>${esc(n)}</td><td>${s.out?'Out':'Not out'}</td><td>${s.runs}</td><td>${s.balls}</td><td>${s.fours}</td><td>${s.sixes}</td></tr>`).join('')}</table></div><h3>Bowling · ${esc(r.bowlingTeam)}</h3><div style="overflow:auto"><table><tr><th>Bowler</th><th>Overs</th><th>Runs</th><th>Wkts</th><th>Econ.</th></tr>${Object.entries(r.bowlers).map(([n,s])=>`<tr><td>${esc(n)}</td><td>${oversText(s.balls)}</td><td>${s.runs}</td><td>${s.wickets}</td><td>${s.balls?(s.runs/(s.balls/6)).toFixed(2):'0.00'}</td></tr>`).join('')}</table></div>`}
function showFinal(result,entry){$('match').classList.add('hidden');$('setup').classList.add('hidden');$('resultScreen').classList.remove('hidden');$('resultContent').innerHTML=`<h2>🏆 Final match result</h2><p style="font-size:19px;font-weight:800">${esc(result)}</p><p class="muted">Saved on this phone · ${new Date(entry.date).toLocaleString()}</p>${entry.innings.map(scorecardHTML).join('')}`}
function historyList(){try{return JSON.parse(window.localStorage.getItem('zainElevenResults')||'[]')}catch(e){return []}}
function saveHistoryList(items){try{window.localStorage.setItem('zainElevenResults',JSON.stringify(items));return true}catch(e){console.warn('Local history storage unavailable:',e);return false}}
function showHistory(){let h=historyList();openModal(`<h2>Saved match history</h2>${h.length?h.map((m,i)=>`<div class="result-item"><strong>${esc(m.teamA)} vs ${esc(m.teamB)}</strong><p>${esc(m.result)}</p><p class="muted">${new Date(m.date).toLocaleString()} · ${m.overs} overs</p><button data-call="viewHistoryItem(${i})">View scorecard</button></div>`).join(''):'<p class="muted">No completed matches saved yet.</p>'}<div class="modal-foot"><button data-call="closeModal()">Close</button>${h.length?'<button class="danger" data-call="clearHistory()">Clear history</button>':''}</div>`)}
function viewHistoryItem(i){let m=historyList()[i];openModal(`<h2>${esc(m.teamA)} vs ${esc(m.teamB)}</h2><p><b>${esc(m.result)}</b></p>${m.innings.map(scorecardHTML).join('')}<button class="primary" data-call="showHistory()">Back to history</button>`)}
function clearHistory(){if(confirm('Delete all saved match results from this phone?')){try{window.localStorage.removeItem('zainElevenResults')}catch(e){}showHistory()}}
function backToSetup(){if(confirm('Leave this match and return to setup? Current unfinished match will be discarded.')){game=null;$('match').classList.add('hidden');$('setup').classList.remove('hidden');renderHistoryPreview()}}
function newMatch(){game=null;$('resultScreen').classList.add('hidden');$('setup').classList.remove('hidden');renderHistoryPreview()}
function renderHistoryPreview(){let h=historyList();$('historyPreview').innerHTML=h.length?h.slice(0,3).map(m=>`<div class="result-item"><b>${esc(m.teamA)} vs ${esc(m.teamB)}</b><div>${esc(m.result)}</div><small class="muted">${new Date(m.date).toLocaleDateString()}</small></div>`).join(''):'No completed matches saved yet.'}
function render(){if(!game)return;$('inningsTitle').textContent=`INNINGS ${game.inn} · ${teamName(game.bat)} batting`;$('score').textContent=`${game.runs}/${game.wickets}`;$('oversLine').textContent=`Overs ${oversText(game.balls)} / ${game.overs} · Extras ${game.extras}`;$('targetLine').textContent=game.target?'Target: '+game.target:'';$('batTeamLabel').textContent='BATTING · '+teamName(game.bat);$('bowlTeamLabel').textContent='BOWLING · '+teamName(game.bowl);let s=currentBatter(),n=players(game.bat)[game.ni],b=currentBowler(),ss=game.batStats[s],ns=game.batStats[n],bs=game.bowlStats[b];$('striker').textContent='★ '+s;$('strikerStats').textContent=`${ss.runs} runs · ${ss.balls} balls · ${ss.fours} fours · ${ss.sixes} sixes`;$('nonStriker').textContent=n;$('nonStrikerStats').textContent=`${ns.runs} runs · ${ns.balls} balls`;$('bowler').textContent=b;$('bowlerStats').textContent=`${oversText(bs.balls)} overs · ${bs.runs} runs · ${bs.wickets} wickets`;$('bowlerSelect').innerHTML=players(game.bowl).map(x=>`<option ${x===b?'selected':''}>${esc(x)}</option>`).join('');$('runButtons').innerHTML=[0,1,2,3,4,6].map(n=>`<button data-call="addRuns(${n})">${n}</button>`).join('');renderHistoryPreview()}
function openModal(html){$('modalBody').innerHTML=html;$('modal').showModal()}function closeModal(){$('modal').close()}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
renderHistoryPreview();


// Delegated handlers: compatible with wrappers that block inline onclick/onchange attributes.
function parseCallArgs(raw, element) {
  if (!raw || !raw.trim()) return [];
  if (raw.trim() === 'this.value') return [element.value];
  const args=[]; let cur='', quote=null, depth=0;
  for (let i=0;i<raw.length;i++) {
    const c=raw[i];
    if (quote) { cur+=c; if(c===quote && raw[i-1] !== '\\') quote=null; continue; }
    if(c==='\'' || c==='"' || c==='`'){quote=c;cur+=c;continue;}
    if(c==='(' || c==='[' || c==='{') depth++;
    if(c===')' || c===']' || c==='}') depth--;
    if(c===',' && depth===0){args.push(cur.trim());cur='';} else cur+=c;
  }
  if(cur.trim()) args.push(cur.trim());
  return args.map(v=>{
    if(v==='this.value') return element.value;
    if((v[0]==='\'' && v[v.length-1]==='\'') || (v[0]==='"' && v[v.length-1]==='"')) return v.slice(1,-1).replace(/\\'/g,"'").replace(/\\\\/g,'\\');
    if(v!=='' && !Number.isNaN(Number(v))) return Number(v);
    return v;
  });
}
function runDelegatedCall(element, attr) {
  const call=element.getAttribute(attr); if(!call) return;
  const match=call.match(/^\s*([A-Za-z_$][\w$]*)\s*\((.*)\)\s*$/s);
  if(!match) return;
  const fn=window[match[1]];
  if(typeof fn!=='function'){console.error('Zain Eleven action not found:',match[1]);return;}
  try { fn(...parseCallArgs(match[2],element)); }
  catch(err){console.error('Zain Eleven action failed:',match[1],err);alert('Could not run '+match[1]+': '+(err && err.message ? err.message : String(err)));}
}
document.addEventListener('click', function(event){
  const el=event.target.closest('[data-call]'); if(!el) return;
  event.preventDefault(); runDelegatedCall(el,'data-call');
});
document.addEventListener('change', function(event){
  const el=event.target.closest('[data-change]'); if(!el) return;
  runDelegatedCall(el,'data-change');
});
