const KEY="familyvault_demo_v1";
const $=s=>document.querySelector(s);
const state=JSON.parse(localStorage.getItem(KEY)||"null")||{
  owner:{name:"My Profile",mobile:""},
  profiles:[{id:"p1",name:"My Profile",relation:"Owner",initial:"M"}],
  credentials:[
    {id:"CRED-100001",type:"Identity profile",holder:"My Profile",issuer:"Demo issuer",status:"Active"},
    {id:"CRED-100002",type:"Education record",holder:"My Profile",issuer:"Demo issuer",status:"Active"}
  ],
  activity:[{text:"Wallet created",time:new Date().toLocaleString()}]
};
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function esc(x){return String(x).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function show(id){document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));$(id).classList.remove("hidden");$("#nav").classList.toggle("hidden",id!=="#walletView")}
function render(){
 $("#ownerName").textContent=state.owner.name;
 $("#ownerAvatar").textContent=(state.owner.name[0]||"M").toUpperCase();
 $("#profiles").innerHTML=state.profiles.map(p=>`<div class="card"><div class="card-icon">👤</div><div class="card-main"><strong>${esc(p.name)}</strong><small>${esc(p.relation)}</small></div><button class="dots" onclick="shareProfile('${p.id}')">↗</button></div>`).join("");
 $("#credentials").innerHTML=state.credentials.map(c=>`<div class="card"><div class="card-icon">🪪</div><div class="card-main"><strong>${esc(c.type)}</strong><small>${esc(c.holder)} · ${esc(c.status)}</small></div><button class="dots" onclick="showCredential('${c.id}')">⋮</button></div>`).join("");
 $("#activity").innerHTML=state.activity.slice(0,6).map(a=>`<div class="event">${esc(a.text)}<small>${esc(a.time)}</small></div>`).join("");
}
function log(text){state.activity.unshift({text,time:new Date().toLocaleString()});save();render()}
function modal(title,body){$("#modalTitle").textContent=title;$("#modalBody").innerHTML=body;$("#modal").classList.remove("hidden")}
function closeModal(){$("#modal").classList.add("hidden")}
$("#closeModal").onclick=closeModal;
$("#modal").onclick=e=>{if(e.target.id==="modal")closeModal()};

$("#loginForm").onsubmit=e=>{
 e.preventDefault();
 const mobile=$("#mobile").value.trim(), pass=$("#password").value;
 if(pass.length<6){alert("Use at least 6 characters.");return}
 state.owner.mobile=mobile; state.owner.name=state.owner.name==="My Profile"?"My Wallet":state.owner.name;
 if(!state.profiles.length)state.profiles.push({id:"p1",name:state.owner.name,relation:"Owner",initial:"M"});
 state.logged=true;save();show("#walletView");render();log("Wallet unlocked");
};
function addCredential(){
 modal("Add credential",`<form id="credForm">
 <label>Credential type<input name="type" placeholder="e.g. Student ID" required></label>
 <label>Holder<input name="holder" value="${esc(state.owner.name)}" required></label>
 <label>Issuer<input name="issuer" placeholder="Issuing organization" required></label>
 <button class="primary">Create demo credential</button>
 </form>`);
 $("#credForm").onsubmit=e=>{e.preventDefault();let f=new FormData(e.target);let id="CRED-"+Math.floor(100000+Math.random()*899999);state.credentials.unshift({id,type:f.get("type"),holder:f.get("holder"),issuer:f.get("issuer"),status:"Active"});save();closeModal();render();log("Credential created: "+id)}
}
function family(){
 modal("Family profiles",`<p class="muted">Profiles are separated so access can be managed independently.</p>
 <div id="familyList">${state.profiles.map(p=>`<div class="card"><div class="card-icon">👤</div><div class="card-main"><strong>${esc(p.name)}</strong><small>${esc(p.relation)}</small></div></div>`).join("")}</div>
 <button class="choice" id="addMember">＋ Add family member</button>`);
 $("#addMember").onclick=()=>{modal("Add family member",`<form id="memberForm">
 <label>Name<input name="name" required></label><label>Relationship<input name="relation" placeholder="Parent, child, guardian..." required></label>
 <button class="primary">Add profile</button></form>`);
 $("#memberForm").onsubmit=e=>{e.preventDefault();let f=new FormData(e.target);state.profiles.push({id:"p"+Date.now(),name:f.get("name"),relation:f.get("relation"),initial:f.get("name")[0]});save();closeModal();render();log("Family profile added")}}
}
function shareProfile(id){
 const p=state.profiles.find(x=>x.id===id)||state.profiles[0];
 const token=btoa(JSON.stringify({profile:p.id,issued:Date.now()})).replace(/=/g,"");
 const url=location.href.split("#")[0]+"#verify="+encodeURIComponent(token);
 modal("Share profile",`<p><strong>${esc(p.name)}</strong></p><p class="muted">Demo share link. It identifies a profile without placing private credential data inside the URL.</p><input id="shareUrl" value="${esc(url)}" readonly><button class="primary" id="copyShare">Copy link</button><div style="margin-top:15px;text-align:center;font-size:50px">▦</div><small class="muted">For production, use a server-issued, short-lived signed token and never put sensitive information in a QR code.</small>`);
 $("#copyShare").onclick=()=>navigator.clipboard?.writeText(url).then(()=>alert("Link copied"));
}
function share(){shareProfile(state.profiles[0]?.id)}
function showCredential(id){let c=state.credentials.find(x=>x.id===id);if(!c)return;modal("Credential details",`<div class="card"><div class="card-icon">🪪</div><div class="card-main"><strong>${esc(c.type)}</strong><small>ID: ${esc(c.id)}<br>Holder: ${esc(c.holder)}<br>Issuer: ${esc(c.issuer)}<br>Status: ${esc(c.status)}</small></div></div><button class="primary" style="margin-top:14px;width:100%" onclick="closeModal();showVerify('${c.id}')">Open verification</button>`)}
function showVerify(id=""){show("#verifyView");$("#verifyId").value=id;$("#verifyResult").innerHTML=""}
$("#verifyBtn").onclick=()=>{let id=$("#verifyId").value.trim();let c=state.credentials.find(x=>x.id===id);$("#verifyResult").innerHTML=c?`<div class="verified"><strong>✓ Active demo credential</strong><br>${esc(c.type)} · ${esc(c.holder)}<br><small>Issuer: ${esc(c.issuer)}</small></div>`:`<div class="notfound"><strong>Credential not found</strong><br>This demo verifier has no matching local record.</div>`;log("Credential verification checked")}
function lock(){state.logged=false;save();show("#loginView");$("#password").value=""}
document.addEventListener("click",e=>{let a=e.target.closest("[data-action]")?.dataset.action;if(!a)return;if(a==="home"){show("#walletView");render()}if(a==="add")addCredential();if(a==="family")family();if(a==="share")share();if(a==="scan")showVerify()});
$("#lockBtn").onclick=lock;$("#navLock").onclick=lock;
function boot(){if(location.hash.startsWith("#verify=")){show("#verifyView");return}if(state.logged){show("#walletView");render()}else show("#loginView")}
boot();
