const API=localStorage.getItem("AMEEN_API")||"http://localhost:3000";let token=localStorage.getItem("token"),me=JSON.parse(localStorage.getItem("user")||"null"),current=null;
const $=id=>document.getElementById(id);
function setStatus(x){$("status").textContent=x}
async function req(path,opt={}){opt.headers={...(opt.headers||{}),"Content-Type":"application/json",...(token?{Authorization:"Bearer "+token}:{})};let r=await fetch(API+path,opt);let d=await r.json();if(!r.ok)throw Error(d.error||"Request failed");return d}
async function login(){try{let d=await req("/api/login",{method:"POST",body:JSON.stringify({username:$("username").value,password:$("password").value})});save(d)}catch(e){setStatus(e.message)}}
async function register(){try{let d=await req("/api/register",{method:"POST",body:JSON.stringify({username:$("username").value,password:$("password").value})});save(d)}catch(e){setStatus(e.message)}}
function save(d){token=d.token;me=d.user;localStorage.setItem("token",token);localStorage.setItem("user",JSON.stringify(me));$("auth").hidden=true;$("chat").hidden=false;$("me").textContent="@"+me.username;loadUsers()}
function logout(){localStorage.clear();location.reload()}
async function loadUsers(){if(!token)return;try{let d=await req("/api/users?q="+encodeURIComponent($("search").value));$("users").innerHTML=d.users.map(u=>`<div class="user" onclick="openChat(${u.id},'${u.username}')">@${u.username}</div>`).join("")}catch(e){}}
async function openChat(id,name){current={id,name};$("conversation").hidden=false;$("with").textContent="@"+name;await loadMessages()}
async function loadMessages(){let d=await req("/api/messages/"+current.id);$("messages").innerHTML=d.messages.map(m=>`<div class="msg ${m.sender_id===me.id?"mine":""}">${esc(m.text)}</div>`).join("");$("messages").scrollTop=$("messages").scrollHeight}
async function send(){let t=$("text").value.trim();if(!t||!current)return;await req("/api/messages",{method:"POST",body:JSON.stringify({receiver_id:current.id,text:t})});$("text").value="";loadMessages()}
function esc(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
if(token&&me)save({token,user:me});