const questions=[
{c:"Real Numbers",q:"यदि HCF(18, 24) = ?",o:["3","6","9","12"],a:1,s:"18 और 24 का सबसे बड़ा समान भाजक 6 है।"},
{c:"Algebra",q:"यदि x² − 5x + 6 = 0, तो x के मान हैं:",o:["1, 6","2, 3","3, 4","2, 4"],a:1,s:"x²−5x+6=(x−2)(x−3), इसलिए x=2 या 3।"},
{c:"Algebra",q:"द्विघात समीकरण ax²+bx+c=0 का discriminant क्या है?",o:["b²−4ac","b²+4ac","4ac−b²","a²−4bc"],a:0,s:"Discriminant D = b² − 4ac।"},
{c:"Geometry",q:"दो त्रिभुजों के समान होने का एक मानदंड कौन-सा है?",o:["AAA","SSS ही","क्षेत्रफल समान","परिमाप समान"],a:0,s:"AAA similarity criterion है।"},
{c:"Trigonometry",q:"sin 30° का मान है:",o:["1","√3/2","1/2","0"],a:2,s:"sin 30° = 1/2।"},
{c:"Coordinate Geometry",q:"बिंदु (0,0) को क्या कहते हैं?",o:["x-intercept","Origin","Vertex","Midpoint"],a:1,s:"(0,0) को Origin कहते हैं।"},
{c:"Statistics",q:"सभी observations का योग / observations की संख्या किसका सूत्र है?",o:["Median","Mode","Mean","Range"],a:2,s:"Arithmetic Mean = Σx/n।"},
{c:"Probability",q:"एक निश्चित घटना की probability क्या होती है?",o:["0","1/2","1","2"],a:2,s:"Certain event की probability 1 होती है।"}
];

let current=[], index=0, answered=false, attempted=+localStorage.getItem("attempted")||0, correct=+localStorage.getItem("correct")||0;
const $=id=>document.getElementById(id);

function save(){localStorage.setItem("attempted",attempted);localStorage.setItem("correct",correct);updateStats()}
function updateStats(){$("attempted").textContent=attempted;$("correct").textContent=correct;$("accuracy").textContent=(attempted?Math.round(correct/attempted*100):0)+"%"}
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active")}
function goHome(){show("home");updateStats()}
function buildChapters(){let cs=[...new Set(questions.map(x=>x.c))];$("chapters").innerHTML=cs.map(c=>`<button onclick='startChapter(${JSON.stringify(c)})'>📘 ${c}</button>`).join("")}
function startChapter(c){current=questions.filter(x=>x.c===c);index=0;show("practice");render()}
function startRandom(){current=[...questions].sort(()=>Math.random()-.5);index=0;show("practice");render()}
function startTest(){current=[...questions].sort(()=>Math.random()-.5).slice(0,5);index=0;show("practice");render(true)}
function render(test=false){let x=current[index];answered=false;$("mode").textContent=(test?"⏱️ Test":"📚 "+x.c);$("counter").textContent=`${index+1}/${current.length}`;$("question").textContent=x.q;$("result").innerHTML="";$("next").style.display="none";$("options").innerHTML=x.o.map((o,i)=>`<button class="option" onclick="answer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join("")}
function answer(i){if(answered)return;answered=true;attempted++;let x=current[index];let btns=document.querySelectorAll(".option");btns[x.a].classList.add("correct");if(i===x.a){correct++;$("result").innerHTML='<div class="answer">✅ सही उत्तर!</div>'}else{$(btns[i]).classList.add("wrong");$("result").innerHTML=`<div class="answer">❌ गलत।<br><b>सही उत्तर:</b> ${x.o[x.a]}<br><br><b>Solution:</b> ${x.s}</div>`}save();$("next").style.display="block"}
function nextQuestion(){index++;if(index>=current.length){$("question").textContent="🎉 Practice complete!";$("options").innerHTML=`<div class="answer">Score: ${correct}/${attempted} overall accuracy ${Math.round(correct/attempted*100)}%</div>`;$("result").innerHTML="";$("next").style.display="none";return}render(current.length===5)}
buildChapters();updateStats();
