const grid = document.getElementById("videoGrid");
const statusEl = document.getElementById("status");
const emptyState = document.getElementById("emptyState");
const countEl = document.getElementById("videoCount");
const searchInput = document.getElementById("searchInput");
const loadMoreBtn = document.getElementById("loadMoreBtn");
const modal = document.getElementById("playerModal");
const playerFrame = document.getElementById("playerFrame");
const playerTitle = document.getElementById("playerTitle");

// Detect phone/tablet/computer for diagnostics and device-specific styling.
function updateDeviceClass() {
  const width = window.matchMedia("(max-width: 760px)").matches;
  document.documentElement.dataset.device = width ? "mobile" : (window.matchMedia("(max-width: 1100px)").matches ? "tablet" : "desktop");
}
updateDeviceClass(); window.addEventListener("resize", updateDeviceClass, {passive:true});

// Keep the header and navigation fixed; calculate the content start from the real device layout.
const masthead = document.querySelector(".masthead");
const mainNav = document.querySelector(".main-nav");
const footer = document.querySelector("footer");
function updateViewportLayout() {
  const headerHeight = Math.ceil(masthead.getBoundingClientRect().height);
  const navHeight = Math.ceil(mainNav.getBoundingClientRect().height);
  const footerHeight = Math.ceil(footer.getBoundingClientRect().height);
  document.documentElement.style.setProperty("--masthead-height", `${headerHeight}px`);
  document.documentElement.style.setProperty("--nav-height", `${navHeight}px`);
  document.documentElement.style.setProperty("--content-top", `${headerHeight + navHeight}px`);
  document.documentElement.style.setProperty("--footer-height", `${footerHeight}px`);
}
updateViewportLayout();
window.addEventListener("resize", updateViewportLayout, { passive: true });
if ("ResizeObserver" in window) {
  const layoutObserver = new ResizeObserver(updateViewportLayout);
  layoutObserver.observe(masthead);
  layoutObserver.observe(mainNav);
  layoutObserver.observe(footer);
}
const LANGUAGES = [
  ["uz","🇺🇿","O‘zbekcha"],["en","🇺🇸","English"],["hi","🇮🇳","हिन्दी"],["zh-CN","🇨🇳","中文"],["tr","🇹🇷","Türkçe"],["fa","🇮🇷","فارسی"],["ru","🇷🇺","Русский"],["ko","🇰🇷","한국어"],["ja","🇯🇵","日本語"],["ar","🇸🇦","العربية"],
  ["es","🇪🇸","Español"],["fr","🇫🇷","Français"],["de","🇩🇪","Deutsch"],["pt","🇵🇹","Português"],["it","🇮🇹","Italiano"],["nl","🇳🇱","Nederlands"],["pl","🇵🇱","Polski"],["uk","🇺🇦","Українська"],["kk","🇰🇿","Қазақша"],["ky","🇰🇬","Кыргызча"],
  ["az","🇦🇿","Azərbaycanca"],["tk","🇹🇲","Türkmençe"],["ur","🇵🇰","اردو"],["bn","🇧🇩","বাংলা"],["pa","🇮🇳","ਪੰਜਾਬੀ"],["ta","🇱🇰","தமிழ்"],["te","🇮🇳","తెలుగు"],["mr","🇮🇳","मराठी"],["id","🇮🇩","Bahasa Indonesia"],["ms","🇲🇾","Bahasa Melayu"],
  ["th","🇹🇭","ไทย"],["vi","🇻🇳","Tiếng Việt"],["fil","🇵🇭","Filipino"],["he","🇮🇱","עברית"],["el","🇬🇷","Ελληνικά"],["sv","🇸🇪","Svenska"],["no","🇳🇴","Norsk"],["da","🇩🇰","Dansk"],["fi","🇫🇮","Suomi"],["cs","🇨🇿","Čeština"],
  ["sk","🇸🇰","Slovenčina"],["hu","🇭🇺","Magyar"],["ro","🇷🇴","Română"],["bg","🇧🇬","Български"],["sr","🇷🇸","Српски"],["hr","🇭🇷","Hrvatski"],["sw","🇰🇪","Kiswahili"],["am","🇪🇹","አማርኛ"],["ps","🇦🇫","پښتو"],["ku","🏳️","Kurdî"]
];
const UI_TEXT = {
  uz:{search:"Videolarni qidirish...",home:"Bosh sahifa",videos:"Videolar",news:"Yangiliklar",loading:"Videolar yuklanmoqda...",empty:"Hozircha video topilmadi",emptyHint:"Video ro‘yxatini keyinroq qayta tekshiring.",more:"Yana videolar",language:"TIL",views:"ko‘rish",refresh:"Videolarni yangilash",online:"ONLAYN"},
  en:{search:"Search videos...",home:"Home",videos:"Videos",news:"News",loading:"Loading videos...",empty:"No videos found yet",emptyHint:"Please check the video list again later.",more:"Load more videos",language:"LANGUAGE",views:"views",refresh:"Refresh videos",online:"ONLINE"},
  ru:{search:"Поиск видео...",home:"Главная",videos:"Видео",news:"Новости",loading:"Загрузка видео...",empty:"Видео пока не найдены",emptyHint:"Проверьте список видео позже.",more:"Ещё видео",language:"ЯЗЫК",views:"просмотров",refresh:"Обновить видео",online:"В СЕТИ"},
  hi:{search:"वीडियो खोजें...",home:"होम",videos:"वीडियो",news:"समाचार",loading:"वीडियो लोड हो रहे हैं...",empty:"अभी कोई वीडियो नहीं मिला",emptyHint:"बाद में वीडियो सूची फिर देखें।",more:"और वीडियो",language:"भाषा",views:"बार देखा गया",refresh:"वीडियो रीफ़्रेश करें",online:"ऑनलाइन"},
  "zh-CN":{search:"搜索视频...",home:"首页",videos:"视频",news:"新闻",loading:"正在加载视频...",empty:"暂未找到视频",emptyHint:"请稍后再查看视频列表。",more:"加载更多",language:"语言",views:"次观看",refresh:"刷新视频",online:"在线"},
  tr:{search:"Video ara...",home:"Ana Sayfa",videos:"Videolar",news:"Haberler",loading:"Videolar yükleniyor...",empty:"Henüz video bulunamadı",emptyHint:"Video listesini daha sonra tekrar kontrol edin.",more:"Daha fazla video",language:"DİL",views:"görüntüleme",refresh:"Videoları yenile",online:"ÇEVRİM İÇİ"},
  fa:{search:"جستجوی ویدیو...",home:"خانه",videos:"ویدیوها",news:"اخبار",loading:"در حال بارگذاری ویدیوها...",empty:"هنوز ویدیویی پیدا نشد",emptyHint:"بعداً فهرست ویدیوها را بررسی کنید.",more:"ویدیوهای بیشتر",language:"زبان",views:"بازدید",refresh:"تازه‌سازی ویدیوها",online:"آنلاین"},
  ko:{search:"동영상 검색...",home:"홈",videos:"동영상",news:"뉴스",loading:"동영상 불러오는 중...",empty:"아직 동영상이 없습니다",emptyHint:"나중에 동영상 목록을 다시 확인하세요.",more:"동영상 더 보기",language:"언어",views:"조회",refresh:"동영상 새로고침",online:"온라인"},
  ar:{search:"ابحث عن الفيديوهات...",home:"الرئيسية",videos:"الفيديوهات",news:"الأخبار",loading:"جارٍ تحميل الفيديوهات...",empty:"لم يتم العثور على فيديوهات",emptyHint:"تحقق من القائمة لاحقًا.",more:"المزيد من الفيديوهات",language:"اللغة",views:"مشاهدة",refresh:"تحديث الفيديوهات",online:"متصل"},
  es:{search:"Buscar videos...",home:"Inicio",videos:"Videos",news:"Noticias",loading:"Cargando videos...",empty:"Todavía no hay videos",emptyHint:"Vuelve a revisar la lista más tarde.",more:"Más videos",language:"IDIOMA",views:"visualizaciones",refresh:"Actualizar videos",online:"EN LÍNEA"},
  fr:{search:"Rechercher des vidéos...",home:"Accueil",videos:"Vidéos",news:"Actualités",loading:"Chargement des vidéos...",empty:"Aucune vidéo trouvée",emptyHint:"Réessayez plus tard.",more:"Plus de vidéos",language:"LANGUE",views:"vues",refresh:"Actualiser les vidéos",online:"EN LIGNE"},
  de:{search:"Videos suchen...",home:"Startseite",videos:"Videos",news:"Nachrichten",loading:"Videos werden geladen...",empty:"Noch keine Videos gefunden",emptyHint:"Bitte später erneut versuchen.",more:"Mehr Videos",language:"SPRACHE",views:"Aufrufe",refresh:"Videos aktualisieren",online:"ONLINE"},
  ja:{search:"動画を検索...",home:"ホーム",videos:"動画",news:"ニュース",loading:"動画を読み込み中...",empty:"動画が見つかりません",emptyHint:"後でもう一度確認してください。",more:"さらに動画を表示",language:"言語",views:"回視聴",refresh:"動画を更新",online:"オンライン"},
  id:{search:"Cari video...",home:"Beranda",videos:"Video",news:"Berita",loading:"Memuat video...",empty:"Video belum ditemukan",emptyHint:"Periksa daftar video lagi nanti.",more:"Video lainnya",language:"BAHASA",views:"tayangan",refresh:"Muat ulang video",online:"ONLINE"},
  pt:{search:"Pesquisar vídeos...",home:"Início",videos:"Vídeos",news:"Notícias",loading:"Carregando vídeos...",empty:"Nenhum vídeo encontrado",emptyHint:"Tente novamente mais tarde.",more:"Mais vídeos",language:"IDIOMA",views:"visualizações",refresh:"Atualizar vídeos",online:"ONLINE"},
  it:{search:"Cerca video...",home:"Home",videos:"Video",news:"Notizie",loading:"Caricamento video...",empty:"Nessun video trovato",emptyHint:"Riprova più tardi.",more:"Altri video",language:"LINGUA",views:"visualizzazioni",refresh:"Aggiorna video",online:"ONLINE"}
};
let currentLang = "uz";
const translatedTitles = new Map();
const translationPending = new Set();
const languageMenu = document.getElementById("languageMenu");
const languageButton = document.getElementById("languageButton");
const currentFlag = document.getElementById("currentFlag");
const currentLanguage = document.getElementById("currentLanguage");
const languageLabel = document.getElementById("languageLabel");
const sparks = document.querySelector(".space-glow");
for (let i = 0; i < 52; i++) {
  const spark = document.createElement("i"); spark.className = "spark";
  spark.style.setProperty("--x", `${(i * 37) % 100}%`);
  spark.style.setProperty("--y", `${(i * 53) % 115}%`);
  spark.style.setProperty("--size", `${1 + (i % 3)}px`);
  spark.style.setProperty("--duration", `${5 + (i % 8)}s`);
  spark.style.setProperty("--delay", `${-(i % 11)}s`);
  spark.style.setProperty("--drift", `${(i % 2 ? 1 : -1) * (12 + (i % 32))}px`);
  spark.style.setProperty("--spark-color", ["#ffb45f","#54dfff","#ff5dba","#b7ff66","#ffffff"][i % 5]);
  sparks.appendChild(spark);
}
for (const [code, flag, name] of LANGUAGES) {
  const option = document.createElement("button"); option.type = "button"; option.className = "language-option";
  option.setAttribute("role", "option"); option.dataset.lang = code; option.setAttribute("aria-selected", code === currentLang ? "true" : "false");
  option.innerHTML = `<span class="lang-flag" aria-hidden="true">${flag}</span><span class="lang-name"></span>`;
  option.querySelector(".lang-name").textContent = name;
  option.addEventListener("click", () => setLanguage(code)); languageMenu.appendChild(option);
}
function ui(key) { return (UI_TEXT[currentLang] || UI_TEXT.en)[key] || UI_TEXT.en[key] || key; }
function setLanguage(code) {
  const lang = LANGUAGES.find(item => item[0] === code) || LANGUAGES[0];
  currentLang = lang[0]; document.documentElement.lang = code;
  currentFlag.textContent = lang[1]; currentLanguage.textContent = lang[2].toLocaleUpperCase(); languageLabel.textContent = ui("language");
  languageMenu.hidden = true; languageButton.setAttribute("aria-expanded", "false");
  languageMenu.querySelectorAll(".language-option").forEach(el => el.setAttribute("aria-selected", el.dataset.lang === code ? "true" : "false"));
  searchInput.placeholder = ui("search"); searchInput.setAttribute("aria-label", ui("search"));
  document.querySelector(".nav-home").textContent = ui("home"); document.querySelector(".nav-videos").textContent = ui("videos"); document.querySelector(".nav-news").textContent = ui("news");
  const refresh = document.getElementById("refreshBtn"); refresh.title = ui("refresh"); refresh.setAttribute("aria-label", ui("refresh"));
  loadMoreBtn.innerHTML = `${ui("more")} <span>＋</span>`;
  const emptyHeading = emptyState.querySelector("h2"); if (emptyHeading) emptyHeading.textContent = ui("empty");
  const emptyHint = emptyState.querySelector("p"); if (emptyHint) emptyHint.textContent = ui("emptyHint");
  document.querySelector(".footer-status").lastChild.textContent = ` ${ui("online")}`;
  // Keep the initial loading spinner/text hidden for a cleaner interface.
  renderVideos();
  translateVisibleTitles();
}
languageButton.addEventListener("click", () => { languageMenu.hidden = !languageMenu.hidden; languageButton.setAttribute("aria-expanded", String(!languageMenu.hidden)); });
document.addEventListener("click", event => { if (!event.target.closest(".language-picker")) { languageMenu.hidden = true; languageButton.setAttribute("aria-expanded", "false"); } });
async function translatedTitle(title, code) {
  const key = `${code}:${title}`; if (translatedTitles.has(key)) return translatedTitles.get(key);
  if (translationPending.has(key)) return title;
  translationPending.add(key);
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${encodeURIComponent(code)}&dt=t&q=${encodeURIComponent(title)}`;
    const response = await fetch(url); if (!response.ok) return title;
    const data = await response.json(); const result = Array.isArray(data[0]) ? data[0].map(part => part[0] || "").join("") : title;
    translatedTitles.set(key, result || title); return result || title;
  } catch { return title; } finally { translationPending.delete(key); }
}
async function translateVisibleTitles() {
  const langAtStart = currentLang;
  for (const video of allVideos) {
    const original = safeText(video.title);
    const translated = await translatedTitle(original, langAtStart);
    if (currentLang !== langAtStart) return;
    video.__xhouseTranslatedTitle = translated;
    const card = [...grid.children].find(el => el.dataset.videoTitle === original);
    if (card) { const titleEl = card.querySelector(".card-title"); if (titleEl) { titleEl.textContent = translated; titleEl.title = translated; } }
  }
  renderVideos();
}

let allVideos = [];
let page = 1;
let totalPages = 1;
let loading = false;

document.getElementById("year").textContent = new Date().getFullYear();

function formatDuration(value) {
  if (value === undefined || value === null || value === "") return "VIDEO";
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0) return String(value);
  const h = Math.floor(n / 3600), m = Math.floor((n % 3600) / 60), s = Math.floor(n % 60);
  return h ? `${h}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}` : `${m}:${String(s).padStart(2,"0")}`;
}
function safeText(value, fallback="Video") {
  return String(value || fallback).replace(/[\u0000-\u001f]/g, "").trim();
}
function thumbnailOf(video) {
  return video.single_img || video.splash_img || video.thumb_img || "";
}
function renderVideos() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = allVideos.filter(v => safeText(v.title).toLowerCase().includes(query) || safeText(v.__xhouseTranslatedTitle || "").toLowerCase().includes(query));
  countEl.textContent = filtered.length ? `(${filtered.length})` : "(0)";
  grid.innerHTML = "";
  for (const video of filtered) {
    const code = video.file_code || video.filecode || "";
    const directUrl = video.__xhouseUrl || "";
    if (!code && !directUrl) continue;
    const card = document.createElement("article");
    card.className = "video-card";
    card.dataset.videoTitle = safeText(video.title);
    card.tabIndex = 0;
    card.setAttribute("role", "button");
    card.setAttribute("aria-label", `Videoni ko‘rish: ${safeText(video.title)}`);
    const thumb = document.createElement("div");
    thumb.className = "thumb";
    const placeholder = document.createElement("div");
    placeholder.className = "thumb-placeholder";
    placeholder.textContent = "▶";
    thumb.appendChild(placeholder);
    const imgUrl = thumbnailOf(video);
    if (imgUrl) {
      const img = document.createElement("img");
      img.loading = "lazy";
      img.alt = "";
      img.src = imgUrl;
      img.addEventListener("load", () => placeholder.remove(), { once: true });
      img.addEventListener("error", () => img.remove(), { once: true });
      thumb.appendChild(img);
    }
    const play = document.createElement("span");
    play.className = "play-button";
    play.textContent = "▶";
    thumb.appendChild(play);
    const duration = document.createElement("span");
    duration.className = "duration";
    duration.textContent = formatDuration(video.length);
    thumb.appendChild(duration);
    const info = document.createElement("div");
    info.className = "card-info";
    const title = document.createElement("h3");
    title.className = "card-title";
    title.textContent = safeText(video.__xhouseTranslatedTitle || video.title);
    title.title = title.textContent;
    const meta = document.createElement("div");
    meta.className = "card-meta";
    const uploaded = document.createElement("span");
    uploaded.textContent = video.uploaded ? String(video.uploaded).slice(0,10) : "Xhouse";
    const views = document.createElement("span");
    views.className = "views";
    views.textContent = `${video.views || 0} ${ui("views")}`;
    meta.append(uploaded, views);
    info.append(title, meta);
    card.append(thumb, info);
    if (video.__xhouseManualId || code) {
      const metricId = video.__xhouseManualId || `dood:${code}`;
      const votes = document.createElement("div"); votes.className = "xhouse-votes";
      const like = document.createElement("button"); like.type="button"; like.textContent=`👍 ${video.likes||0}`; like.setAttribute("aria-label","Like");
      const dislike = document.createElement("button"); dislike.type="button"; dislike.textContent=`👎 ${video.dislikes||0}`; dislike.setAttribute("aria-label","Dislike");
      const vote = async (action,button) => { button.disabled=true; try { const r=await fetch('/.netlify/functions/metrics',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:metricId,action})}); if(!r.ok) throw new Error(); const d=await r.json(); video.views=d.views??video.views;video.likes=d.likes??video.likes;video.dislikes=d.dislikes??video.dislikes;like.textContent=`👍 ${video.likes||0}`;dislike.textContent=`👎 ${video.dislikes||0}`; } catch {} finally {button.disabled=false;} };
      like.addEventListener('click',e=>{e.stopPropagation();vote('like',like)}); dislike.addEventListener('click',e=>{e.stopPropagation();vote('dislike',dislike)}); votes.append(like,dislike); card.append(votes);
    }
    const open = () => { if(video.__xhouseManualId || code) fetch('/.netlify/functions/metrics',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:video.__xhouseManualId || `dood:${code}`,action:'view'})}).then(r=>r.ok?r.json():null).then(d=>{if(d){video.views=d.views;renderVideos()}}).catch(()=>{}); openPlayer(directUrl || code, safeText(video.__xhouseTranslatedTitle || video.title), Boolean(directUrl), video); };
    card.addEventListener("click", open);
    card.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); } });
    grid.appendChild(card);
  }
  grid.hidden = grid.children.length === 0;
  emptyState.hidden = grid.children.length !== 0;
}
function openPlayer(code, title, isDirectUrl=false, currentVideo=null) {
  // Open inside Xhouse. Sandboxed iframe prevents provider pages from navigating the top-level site.
  playerTitle.textContent = title;
  let safeSrc = "";
  if (isDirectUrl) {
    try {
      const u = new URL(code, location.origin);
      if (u.protocol === "https:" && !/^(javascript|data):$/i.test(u.protocol)) safeSrc = u.href;
    } catch (_) {}
  } else if (/^[a-zA-Z0-9_-]{3,120}$/.test(String(code))) {
    safeSrc = `https://dood.to/e/${encodeURIComponent(code)}`;
  }
  if (!safeSrc) {
    playerTitle.textContent = "Video havolasi xavfsiz emas";
    playerFrame.src = "about:blank";
  } else playerFrame.src = safeSrc;
  renderRelatedVideos(currentVideo);
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  document.getElementById("closePlayer").focus();
}
function renderRelatedVideos(currentVideo=null) {
  const host = document.getElementById("relatedVideos");
  if (!host) return;
  host.replaceChildren();
  const currentKey = currentVideo ? String(currentVideo.__xhouseManualId || currentVideo.file_code || currentVideo.filecode || currentVideo.__xhouseUrl || currentVideo.title) : "";
  const candidates = allVideos.filter(v => {
    const code = v.file_code || v.filecode || "";
    const url = v.__xhouseUrl || "";
    if (!code && !url) return false;
    const key = String(v.__xhouseManualId || code || url || v.title);
    return key !== currentKey;
  }).slice(0, 12);
  if (!candidates.length) {
    const note = document.createElement("p"); note.className = "related-empty"; note.textContent = "Hozircha boshqa video yo‘q."; host.appendChild(note); return;
  }
  for (const video of candidates) {
    const card = document.createElement("button"); card.type = "button"; card.className = "related-card";
    const imgUrl = thumbnailOf(video);
    if (imgUrl) { const img = document.createElement("img"); img.src = imgUrl; img.alt = ""; img.loading = "lazy"; img.referrerPolicy = "no-referrer"; card.appendChild(img); }
    const title = document.createElement("span"); title.className = "related-card-title"; title.textContent = safeText(video.__xhouseTranslatedTitle || video.title); card.appendChild(title);
    const meta = document.createElement("small"); meta.textContent = `${Number(video.views || 0).toLocaleString()} ko‘rish`; card.appendChild(meta);
    card.addEventListener("click", () => {
      const code = video.file_code || video.filecode || ""; const url = video.__xhouseUrl || "";
      openPlayer(url || code, safeText(video.__xhouseTranslatedTitle || video.title), Boolean(url), video);
      document.querySelector(".player-dialog")?.scrollTo({top:0,behavior:"smooth"});
    });
    host.appendChild(card);
  }
}
function closePlayer() {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
  playerFrame.src = "about:blank";
  document.body.style.overflow = "";
}
document.getElementById("closePlayer").addEventListener("click", closePlayer);
modal.addEventListener("click", e => { if (e.target.dataset.close === "true") closePlayer(); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && modal.classList.contains("open")) closePlayer(); });
searchInput.addEventListener("input", renderVideos);

async function loadVideos(nextPage=1) {
  if (loading) return;
  loading = true;
  statusEl.hidden = true;
  statusEl.innerHTML = "";
  try {
    let result = {}, files = [], apiError = null;
    try {
      const response = await fetch(`/.netlify/functions/videos?page=${nextPage}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "API so‘rovi bajarilmadi");
      result = data.result || {};
      files = Array.isArray(result.files) ? result.files : (Array.isArray(result) ? result : []);
    } catch (err) { apiError = err; }
    let manualVideos = [];
    if (nextPage === 1) {
      try {
        const catalogResponse = await fetch('/.netlify/functions/catalog');
        const catalogData = await catalogResponse.json();
        manualVideos = (catalogData.videos || []).map(v => ({
          title: v.title, uploaded: v.createdAt, views: v.views || 0, likes: v.likes || 0, dislikes: v.dislikes || 0, length: 0,
          __xhouseUrl: v.url, __xhouseManualId: v.id
        }));
      } catch { manualVideos = []; }
    }
    allVideos = nextPage === 1 ? manualVideos.concat(files) : allVideos.concat(files);
    page = nextPage;
    totalPages = Number(result.total_pages || 1);
    renderVideos();
    if (apiError && manualVideos.length === 0) { statusEl.hidden=false; statusEl.textContent='Tashqi video API sozlanmagan yoki vaqtincha ishlamayapti. Admin panel orqali qo‘shilgan videolar bo‘lsa ular ko‘rinadi.'; }
    else statusEl.hidden = true;
    loadMoreBtn.hidden = page >= totalPages || totalPages <= 1;
  } catch (error) {
    statusEl.hidden = false;
    statusEl.innerHTML = `<span>⚠</span><span>${safeText(error.message, "Videolarni yuklab bo‘lmadi")}. Netlify Environment variables sozlamasini tekshiring.</span>`;
    emptyState.hidden = true;
    grid.hidden = true;
    loadMoreBtn.hidden = true;
  } finally {
    loading = false;
  }
}
loadMoreBtn.addEventListener("click", () => loadVideos(page + 1));
document.getElementById("refreshBtn").addEventListener("click", () => { allVideos = []; loadVideos(1); });

// Mobile pull-to-refresh, only when the page is at the top.
(function setupPullToRefresh(){
  const indicator=document.getElementById("pullRefreshIndicator"), label=document.getElementById("pullRefreshText");
  if(!indicator || !("ontouchstart" in window)) return;
  let sx=0,sy=0,pulling=false,eligible=false,distance=0,busy=false; const threshold=78;
  const blocked=t=>!!(t&&t.closest&&t.closest(".video-card,.player-dialog,iframe,button,input,textarea,select,a,.language-picker"));
  const hide=()=>{indicator.classList.remove("visible","refreshing");indicator.style.transform="translate(-50%,-110%)";};
  const show=(n,refreshing=false)=>{indicator.style.transform=`translate(-50%,${Math.max(-100,Math.min(0,-100+n))}%)`;indicator.classList.toggle("visible",n>0||refreshing);indicator.classList.toggle("refreshing",refreshing);label.textContent=refreshing?"Videolar yangilanmoqda...":(n>=threshold?"Qo‘yib yuboring — yangilanadi":"Yangilash uchun torting");};
  document.addEventListener("touchstart",e=>{if(busy||e.touches.length!==1){eligible=false;return;}const t=e.touches[0];sx=t.clientX;sy=t.clientY;distance=0;pulling=false;eligible=window.scrollY<=2&&!blocked(e.target)&&!document.getElementById("playerModal")?.classList.contains("open");},{passive:true});
  document.addEventListener("touchmove",e=>{if(!eligible||busy||e.touches.length!==1)return;const t=e.touches[0],dy=t.clientY-sy,dx=t.clientX-sx;if(dy<=0||Math.abs(dx)>Math.abs(dy)*.8){if(!pulling)eligible=false;return;}if(window.scrollY>2){eligible=false;return;}pulling=true;distance=Math.min(120,dy*.58);show(distance);if(e.cancelable)e.preventDefault();},{passive:false});
  document.addEventListener("touchend",async()=>{if(!pulling){eligible=false;return;}const refresh=distance>=threshold;eligible=false;pulling=false;if(!refresh||busy){hide();return;}busy=true;show(90,true);try{allVideos=[];await loadVideos(1);}finally{busy=false;hide();label.textContent="Yangilash uchun torting";distance=0;}},{passive:true});
  document.addEventListener("touchcancel",()=>{eligible=false;pulling=false;distance=0;hide();},{passive:true});
})();

setLanguage("uz");
loadVideos(1);
