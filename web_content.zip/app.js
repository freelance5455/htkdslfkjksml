const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={user:null,apiKey:localStorage.getItem("nova_gemini_key")||"",model:localStorage.getItem("nova_model")||"gemini-3.7-flash",messages:JSON.parse(localStorage.getItem("nova_messages")||"[]"),library:JSON.parse(localStorage.getItem("nova_library")||"[]")};
const firebaseConfig={apiKey:"PASTE_FIREBASE_WEB_API_KEY",authDomain:"PASTE_FIREBASE_AUTH_DOMAIN",projectId:"PASTE_FIREBASE_PROJECT_ID",storageBucket:"PASTE_FIREBASE_STORAGE_BUCKET",messagingSenderId:"PASTE_FIREBASE_MESSAGING_SENDER_ID",appId:"PASTE_FIREBASE_APP_ID"};
let firebaseReady=false;
try{ if(firebaseConfig.apiKey.startsWith("PASTE_")===false){firebase.initializeApp(firebaseConfig);firebaseReady=true;} }catch(e){console.warn(e)}

function toast(t){const el=$("#toast");el.textContent=t;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2500)}
function save(){localStorage.setItem("nova_messages",JSON.stringify(state.messages));localStorage.setItem("nova_library",JSON.stringify(state.library));localStorage.setItem("nova_model",state.model)}
function setLoggedIn(user){state.user=user;$("#loginView").classList.add("hidden");$("#appView").classList.remove("hidden");$("#accountInfo").textContent=user?`${user.displayName||"Google User"} • ${user.email||""}`:"Not signed in";$("#profileBtn").textContent=(user?.displayName||"G").slice(0,1).toUpperCase();renderMessages();renderLibrary()}
function showLogin(){state.user=null;$("#appView").classList.add("hidden");$("#loginView").classList.remove("hidden")}
if(firebaseReady){
 firebase.auth().onAuthStateChanged(u=>u?setLoggedIn(u):showLogin());
}else{
 $("#loginStatus").innerHTML="Firebase config বসালে Google Login চালু হবে। <br><b>Developer setup প্রয়োজন।</b>";
}
$("#googleLoginBtn").onclick=async()=>{if(!firebaseReady){toast("আগে Firebase config বসান।");return}try{const p=new firebase.auth.GoogleAuthProvider();await firebase.auth().signInWithRedirect(p)}catch(e){toast(e.message)}};
async function logout(){if(firebaseReady)await firebase.auth().signOut();showLogin()}
$("#logoutBtn").onclick=logout;$("#settingsLogout").onclick=logout;

$("#modelSelect").value=state.model;$("#modelSelect").onchange=e=>{state.model=e.target.value;save()};
$("#apiKeyInput").value=state.apiKey;$("#saveKey").onclick=()=>{state.apiKey=$("#apiKeyInput").value.trim();localStorage.setItem("nova_gemini_key",state.apiKey);toast(state.apiKey?"API key saved locally.":"API key removed.")};

function openDrawer(){ $("#drawer").classList.add("open");$("#backdrop").classList.remove("hidden") }
function closeDrawer(){ $("#drawer").classList.remove("open");$("#backdrop").classList.add("hidden") }
$("#menuBtn").onclick=openDrawer;$("#closeDrawer").onclick=closeDrawer;$("#backdrop").onclick=closeDrawer;

function screen(name){$$(".screen").forEach(x=>x.classList.add("hidden"));$("#"+name+"Screen").classList.remove("hidden");closeDrawer()}
$$("[data-screen]").forEach(b=>b.onclick=()=>screen(b.dataset.screen+"Screen"===b.dataset.screen?b.dataset.screen:b.dataset.screen));

const toolMeta={
chat:["AI Chat","সাধারণ প্রশ্ন ও কথোপকথন"],study:["Study Assistant","পড়া বোঝানো, quiz, summary"],writing:["Writing Assistant","গল্প, script, post, email"],coding:["AI Coding","কোড তৈরি, ব্যাখ্যা ও debug"],image:["AI Image","ছবি generation/editing workflow"],pdf:["PDF Assistant","PDF থেকে summary ও প্রশ্ন"],voice:["Voice AI","কথা শুনে AI response"],tts:["Text-to-Speech","লেখা থেকে voice"],video:["AI Video","ভিডিও generation workflow"],research:["Research Assistant","গবেষণা ও report"],translate:["Translation","অনুবাদ ও language learning"],agent:["AI Agent","Goal থেকে multi-step task"],memory:["Memory & Library","Saved chats ও personal library"]};
function openTool(t){$("#homeScreen").classList.add("hidden");$("#libraryScreen").classList.add("hidden");$("#searchScreen").classList.add("hidden");$("#settingsScreen").classList.add("hidden");$("#toolScreen").classList.remove("hidden");$("#toolTitle").textContent=toolMeta[t][0];$("#toolDesc").textContent=toolMeta[t][1];$("#toolBody").innerHTML=toolHTML(t);bindTool(t);closeDrawer()}
$$("[data-tool]").forEach(b=>b.onclick=()=>openTool(b.dataset.tool));$("#backHome").onclick=()=>screen("home");
function toolHTML(t){
 if(t==="image")return `<div class="tool-card"><h3>🖼️ Image Generator</h3><textarea id="toolPrompt" class="tool-input" placeholder="যেমন: একটি cinematic গ্রামের দৃশ্য..."></textarea><div class="tool-actions"><button class="primary" id="toolRun">Generate</button><button class="chip">16:9</button><button class="chip">1:1</button><button class="chip">9:16</button></div><div id="toolResult"></div></div>`;
 if(t==="video")return `<div class="tool-card"><h3>🎬 Video Generator</h3><textarea id="toolPrompt" class="tool-input" placeholder="ভিডিওর prompt লিখুন..."></textarea><div class="tool-actions"><button class="chip">Text-to-Video</button><button class="chip">Image-to-Video</button><button class="chip">5s</button><button class="chip">8s</button><button class="primary" id="toolRun">Generate</button></div><div id="toolResult"></div></div>`;
 if(t==="pdf")return `<div class="tool-card"><h3>📄 PDF Assistant</h3><input id="pdfFile" type="file" accept=".pdf" class="tool-input"><textarea id="toolPrompt" class="tool-input" placeholder="PDF নিয়ে কী করতে চান? যেমন: সারাংশ তৈরি করুন"></textarea><button class="primary" id="toolRun">Analyze PDF</button><div id="toolResult"></div></div>`;
 if(t==="voice")return `<div class="tool-card center"><div class="brand-mark">🎤</div><h3>Voice AI</h3><p class="muted">Browser microphone permission দিয়ে speech-to-text চেষ্টা করুন।</p><button class="primary" id="voiceStart">Start Listening</button><div id="voiceText" class="message ai" style="margin:16px auto 0"></div></div>`;
 if(t==="tts")return `<div class="tool-card"><h3>🔊 Text-to-Speech</h3><textarea id="toolPrompt" class="tool-input" placeholder="যে লেখা শুনতে চান..."></textarea><button class="primary" id="toolRun">Speak</button></div>`;
 if(t==="translate")return `<div class="tool-card"><h3>🌐 Translation</h3><textarea id="toolPrompt" class="tool-input" placeholder="অনুবাদ করার লেখা..."></textarea><div class="tool-actions"><button class="chip">Bangla → English</button><button class="chip">English → Bangla</button><button class="primary" id="toolRun">Translate</button></div><div id="toolResult"></div></div>`;
 if(t==="agent")return `<div class="tool-card"><h3>🧑‍💻 AI Agent</h3><textarea id="toolPrompt" class="tool-input" placeholder="Goal লিখুন, যেমন: একটি বিষয় নিয়ে report তৈরি করো"></textarea><button class="primary" id="toolRun">Run Agent</button><div id="toolResult"></div></div>`;
 return `<div class="tool-card"><h3>${toolMeta[t][0]}</h3><textarea id="toolPrompt" class="tool-input" placeholder="আপনার কাজ বা প্রশ্ন লিখুন..."></textarea><div class="tool-actions"><button class="chip">Summarize</button><button class="chip">Explain</button><button class="chip">Generate</button><button class="primary" id="toolRun">Run AI</button></div><div id="toolResult"></div></div>`;
}
function bindTool(t){
 $("#toolRun")?.addEventListener("click",async()=>{const p=$("#toolPrompt")?.value?.trim();if(!p)return toast("Prompt দিন।");if(t==="tts"){speechSynthesis.speak(new SpeechSynthesisUtterance(p));return}if(t==="video"||t==="image"){toast("এই static build-এ generation adapter placeholder আছে; model/API capability অনুযায়ী backend adapter লাগবে।");return}if(t==="pdf"){return handlePDF()}$("#toolResult").innerHTML="<div class='message ai'>Generating…</div>";try{$("#toolResult").innerHTML=msgHTML(await gemini(p,systemFor(t)))}catch(e){$("#toolResult").innerHTML=msgHTML("Error: "+e.message)}});
 $("#voiceStart")?.addEventListener("click",startVoice);
}
function systemFor(t){return `You are the ${toolMeta[t]?.[0]||"AI Assistant"} inside Nova AI.
IMPORTANT LANGUAGE RULE: Reply in exactly the same language the user used in their latest message.
- If the user writes Bangla, reply in Bangla.
- If the user writes English, reply in English.
- If the user writes Hindi, reply in Hindi.
- If the user writes Japanese, reply in Japanese.
- For any other language, reply in that same language when possible.
- If the user mixes languages, use the dominant language of the latest message.
Do not automatically translate the user's message into another language unless they ask you to.
Keep the same language for the entire answer unless the user explicitly requests another language.`}
function msgHTML(text){return `<div class="message ai">${escapeHTML(text)}<div class="message-actions"><button class="mini" onclick="navigator.clipboard.writeText(this.parentElement.parentElement.innerText)">Copy</button></div></div>`}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

async function gemini(prompt,system="You are a helpful assistant."){
 if(!state.apiKey)throw new Error("Settings থেকে Gemini API Key দিন।");
 const url=`https://generativelanguage.googleapis.com/v1beta/interactions`;
 const body={model:state.model,input:[{type:"text",text:prompt}],system_instruction:system};
 const r=await fetch(url,{method:"POST",headers:{"x-goog-api-key":state.apiKey,"Content-Type":"application/json"},body:JSON.stringify(body)});
 const data=await r.json();if(!r.ok)throw new Error(data.error?.message||"Gemini API request failed");
 return data.output_text||data.outputs?.map(x=>x.text||"").join("")||JSON.stringify(data);
}
function renderMessages(){const box=$("#chatList");box.innerHTML="";state.messages.forEach((m,i)=>{box.innerHTML+=`<div class="message ${m.role==='user'?'user':'ai'}">${escapeHTML(m.text)}${m.role==='model'?`<div class="message-actions"><button class="mini" onclick="navigator.clipboard.writeText(${JSON.stringify(m.text)})">Copy</button></div>`:""}</div>`)});box.scrollTop=box.scrollHeight}
async function send(){
 const p=$("#promptInput").value.trim();if(!p)return;if(!state.user){return toast("Google Account দিয়ে আগে login করুন।")}
 if(!state.apiKey){screen("settings");return toast("Settings-এ Gemini API Key দিন।")}
 $("#promptInput").value="";state.messages.push({role:"user",text:p});renderMessages();const pending={role:"model",text:"Thinking…"};state.messages.push(pending);renderMessages();
 try{pending.text=await gemini(p,`You are Nova AI, a helpful multimodal assistant.
LANGUAGE RULE: Answer in exactly the same language as the user's latest message. If the user writes Bangla, answer in Bangla; English → English; Hindi → Hindi; Japanese → Japanese; and so on. If mixed, use the dominant language. Do not translate unless asked. Be concise but useful.`);}
 catch(e){pending.text="⚠️ "+e.message}save();renderMessages()
}
$("#sendBtn").onclick=send;$("#promptInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send()}});
$("#attachBtn").onclick=()=>$("#attachPanel").classList.toggle("hidden");
$$("[data-attach]").forEach(b=>b.onclick=()=>{$("#fileInput").click();$("#attachPanel").classList.add("hidden")});
$("#fileInput").onchange=async e=>{const f=e.target.files[0];if(!f)return;state.library.unshift({name:f.name,type:f.type,size:f.size,date:new Date().toISOString()});save();renderLibrary();toast(`${f.name} Library-তে যোগ হয়েছে।`)};

async function handlePDF(){const f=$("#pdfFile")?.files?.[0],p=$("#toolPrompt")?.value?.trim()||"Summarize this PDF.";if(!f)return toast("PDF নির্বাচন করুন।");if(f.size>50*1024*1024)return toast("PDF 50MB-এর বেশি।");if(!state.apiKey)return toast("API key দিন।");$("#toolResult").innerHTML="<div class='message ai'>Uploading and analyzing PDF…</div>";const b64=await toBase64(f);try{const r=await fetch("https://generativelanguage.googleapis.com/v1beta/models/"+encodeURIComponent(state.model)+":generateContent",{method:"POST",headers:{"x-goog-api-key":state.apiKey,"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:p},{inlineData:{mimeType:"application/pdf",data:b64}}]}]})});const d=await r.json();if(!r.ok)throw new Error(d.error?.message||"PDF request failed");$("#toolResult").innerHTML=msgHTML(d.candidates?.[0]?.content?.parts?.map(x=>x.text||"").join("")||"No response");}catch(e){$("#toolResult").innerHTML=msgHTML("Error: "+e.message)}}
function toBase64(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(",")[1]);r.onerror=rej;r.readAsDataURL(file)})}
function startVoice(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return toast("এই browser-এ speech recognition নেই।");const r=new SR();r.lang="bn-BD";r.interimResults=false;r.onresult=e=>{$("#voiceText").textContent=e.results[0][0].transcript;$("#promptInput").value=e.results[0][0].transcript;send()};r.onerror=e=>toast(e.error||"Voice error");r.start()}

function renderLibrary(){const g=$("#libraryGrid");if(!g)return;g.innerHTML=state.library.length?state.library.map((x,i)=>`<div class="lib-card"><b>${escapeHTML(x.name)}</b><small>${escapeHTML(x.type||"file")}</small><small>${new Date(x.date).toLocaleString()}</small><button class="mini" onclick="state.library.splice(${i},1);save();renderLibrary()">Delete</button></div>`).join(""):`<div class="muted">Library এখন খালি।</div>`}
$("#clearLibrary").onclick=()=>{state.library=[];save();renderLibrary()};
$("#searchInput").oninput=e=>{const q=e.target.value.toLowerCase();$("#searchResults").innerHTML=state.messages.filter(x=>x.text.toLowerCase().includes(q)).slice(-30).map(x=>`<div class="message ${x.role==='user'?'user':'ai'}">${escapeHTML(x.text)}</div>`).join("")||"<p class='muted'>কোনো ফল পাওয়া যায়নি।</p>"};
$("#themeBtn").onclick=()=>document.body.classList.toggle("light");
$("#profileBtn").onclick=()=>screen("settings");

screen("home");renderMessages();renderLibrary();
