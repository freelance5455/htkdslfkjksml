
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import { getFirestore, collection, addDoc, doc, setDoc, updateDoc, deleteDoc, onSnapshot, query, orderBy, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

/* PASTE YOUR FIREBASE CONFIG HERE */
const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT.firebasestorage.app",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const $ = id => document.getElementById(id);
let currentUser = null, technicians = [], orders = [], unsubTech = null, unsubOrders = null;

function show(id){
  document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
  $(id).classList.add("active");
  document.querySelectorAll("nav button").forEach(x=>x.classList.remove("active"));
  document.querySelector(`nav button[data-page="${id}"]`)?.classList.add("active");
}
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>show(b.dataset.page));

function render(){
  $("mOpen").textContent=orders.filter(o=>o.status!=="Completed").length;
  $("mDone").textContent=orders.filter(o=>o.status==="Completed").length;
  $("mScore").textContent=technicians.reduce((s,t)=>s+(t.points||0),0);
  $("otech").innerHTML=technicians.map(t=>`<option value="${t.id}">${t.name}</option>`).join("");
  const card=o=>{
    const t=technicians.find(x=>x.id===o.technicianId);
    const overdue=o.dueDate && o.status!=="Completed" && new Date(o.dueDate+"T23:59:59")<new Date();
    return `<div class="order ${overdue?"overdue":""}">
      <div class="row"><div><b>${o.workOrderId} — ${o.site}</b><div class="small">${t?.name||"Unknown"} • ${o.priority} • Due ${o.dueDate||"—"}</div></div>
      <span class="badge">${overdue?"OVERDUE":o.status}</span></div>
      <div class="small note">${o.notes||"No notes."}</div>
      <div class="row"><select onchange="changeStatus('${o.id}',this.value)">
        ${["Pending","In Progress","Completed"].map(s=>`<option ${s===o.status?"selected":""}>${s}</option>`).join("")}</select>
        <button class="danger" onclick="removeOrder('${o.id}')">Delete</button></div></div>`;
  };
  $("ordersList").innerHTML=orders.map(card).join("")||"<div class='card'>No WorkOrders.</div>";
  $("dashOrders").innerHTML=orders.slice(0,6).map(card).join("")||"<div class='card'>No WorkOrders.</div>";
  $("techList").innerHTML=technicians.map(t=>`<div class="card"><div class="row"><b>${t.name}</b><b>${t.points||0} pts</b></div></div>`).join("");
  const sorted=[...technicians].sort((a,b)=>(b.points||0)-(a.points||0));
  $("board").innerHTML=sorted.map((t,i)=>`<tr><td>${i+1}</td><td>${t.name}</td><td>${orders.filter(o=>o.technicianId===t.id&&o.status==="Completed").length}</td><td><b>${t.points||0}</b></td></tr>`).join("");
}


// Direct-open mode: no login screen.
(function startApp(){
  const userLabel = document.getElementById("userEmail");
  if (userLabel) userLabel.textContent = "Field Operations";
  unsubTech = onSnapshot(collection(db,"technicians"), s => {
    technicians = s.docs.map(d => ({id:d.id,...d.data()}));
    render();
  });
  unsubOrders = onSnapshot(query(collection(db,"workorders"),orderBy("createdAt","desc")), s => {
    orders = s.docs.map(d => ({id:d.id,...d.data()}));
    render();
  });
})();
