const STORAGE_KEY = 'contador-cup-state-v1';
const DEFAULT_VALUES = [20000, 10000, 5000, 2000, 1000, 500, 200, 100, 50, 20, 10, 5, 3, 1];
const format = new Intl.NumberFormat('es-CU', { maximumFractionDigits: 2 });
const list = document.querySelector('#denominationList');
const countedOutput = document.querySelector('#countedTotal');
const grandOutput = document.querySelector('#grandTotal');
const differenceOutput = document.querySelector('#difference');
const initialInput = document.querySelector('#initialAmount');
const targetInput = document.querySelector('#targetAmount');
let currentTheme = document.documentElement.dataset.theme || 'light';
let state = loadState();

function freshState() {
  return { denominations: DEFAULT_VALUES.map(value => ({ value, quantity: 0 })), initial: '', target: '', theme: currentTheme };
}
function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (saved && Array.isArray(saved.denominations)) {
      return {
        denominations: saved.denominations.filter(item => Number.isFinite(Number(item.value)) && Number(item.value) > 0).map(item => ({ value: Number(item.value), quantity: Math.max(0, Number(item.quantity) || 0) })),
        initial: saved.initial ?? '',
        target: saved.target ?? '',
        theme: saved.theme === 'dark' || saved.theme === 'light' ? saved.theme : currentTheme
      };
    }
  } catch (error) { console.warn('No se pudo leer el estado guardado.', error); }
  return freshState();
}
function saveState() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  catch (error) { console.warn('No se pudo guardar el estado.', error); }
}
function amount(value) { return Number(value) || 0; }
function setTheme(theme) {
  currentTheme = theme;
  document.documentElement.dataset.theme = theme;
  document.querySelector('meta[name="theme-color"]').content = theme === 'dark' ? '#111a16' : '#f4f5ef';
  const toggle = document.querySelector('#themeToggle');
  toggle.textContent = theme === 'dark' ? '☀' : '☾';
  toggle.setAttribute('aria-label', theme === 'dark' ? 'Activar modo claro' : 'Activar modo oscuro');
  if (state) { state.theme = theme; saveState(); }
}
function render() {
  list.replaceChildren();
  state.denominations.forEach((item, index) => {
    const row = document.createElement('div');
    row.className = 'denom-row';
    const value = document.createElement('input');
    value.className = 'denom-value'; value.type = 'number'; value.min = '0.01'; value.step = 'any'; value.value = item.value;
    value.setAttribute('aria-label', 'Valor de la denominación');
    value.addEventListener('input', () => { state.denominations[index].value = amount(value.value); updateTotals(); saveState(); });
    const quantity = document.createElement('input');
    quantity.className = 'quantity-input'; quantity.type = 'number'; quantity.min = '0'; quantity.step = '1'; quantity.inputMode = 'numeric'; quantity.value = item.quantity;
    quantity.setAttribute('aria-label', 'Cantidad de ' + format.format(item.value) + ' CUP');
    quantity.addEventListener('input', () => { state.denominations[index].quantity = Math.max(0, amount(quantity.value)); updateTotals(); saveState(); });
    const subtotal = document.createElement('span'); subtotal.className = 'subtotal'; subtotal.textContent = format.format(item.value * item.quantity);
    const remove = document.createElement('button'); remove.className = 'delete-row'; remove.type = 'button'; remove.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 5h9l-.6 8h-7.8L3.5 5Zm2-2h5l.7 1.5H4.8L5.5 3Zm-.2 4 .3 4.2m2.4-4.2v4.2m2.4-4.2-.3 4.2"/></svg>'; remove.setAttribute('aria-label', 'Eliminar denominación de ' + format.format(item.value) + ' CUP');
    remove.addEventListener('click', () => { state.denominations.splice(index, 1); render(); saveState(); });
    row.append(value, quantity, subtotal, remove); list.append(row);
  });
  initialInput.value = state.initial;
  targetInput.value = state.target;
  document.querySelector('#denominationCount').textContent = state.denominations.length + (state.denominations.length === 1 ? ' valor' : ' valores');
  updateTotals();
}
function updateTotals() {
  let counted = 0;
  [...list.children].forEach((row, index) => {
    const item = state.denominations[index];
    if (!item) return;
    const valueInput = row.querySelector('.denom-value');
    const quantityInput = row.querySelector('.quantity-input');
    item.value = Math.max(0, amount(valueInput.value));
    item.quantity = Math.max(0, amount(quantityInput.value));
    const subtotal = item.value * item.quantity;
    row.querySelector('.subtotal').textContent = format.format(subtotal);
    counted += subtotal;
  });
  const grand = counted + amount(initialInput.value);
  countedOutput.innerHTML = format.format(counted) + ' <small>CUP</small>';
  grandOutput.innerHTML = format.format(grand) + ' <small>CUP</small>';
  document.querySelector('#formulaCounted').textContent = format.format(counted) + ' CUP';
  document.querySelector('#formulaInitial').textContent = '+ ' + format.format(amount(initialInput.value)) + ' CUP';
  differenceOutput.className = 'difference';
  if (targetInput.value === '') differenceOutput.textContent = 'Escribe una meta para ver la diferencia';
  else {
    const difference = amount(targetInput.value) - grand;
    if (Math.abs(difference) < 0.005) { differenceOutput.innerHTML = '<strong>¡Meta alcanzada!</strong>'; differenceOutput.classList.add('is-over'); }
    else if (difference > 0) { differenceOutput.innerHTML = 'Faltan <strong>' + format.format(difference) + ' CUP</strong>'; differenceOutput.classList.add('is-short'); }
    else { differenceOutput.innerHTML = 'Sobran <strong>' + format.format(Math.abs(difference)) + ' CUP</strong>'; differenceOutput.classList.add('is-over'); }
  }
}
initialInput.addEventListener('input', () => { state.initial = initialInput.value; updateTotals(); saveState(); });
targetInput.addEventListener('input', () => { state.target = targetInput.value; updateTotals(); saveState(); });
document.querySelector('#addForm').addEventListener('submit', event => {
  event.preventDefault();
  const input = document.querySelector('#newDenomination');
  const value = Number(input.value);
  if (!Number.isFinite(value) || value <= 0) return;
  state.denominations.push({ value, quantity: 0 });
  state.denominations.sort((a, b) => b.value - a.value);
  input.value = ''; render(); saveState();
});
document.querySelector('#resetButton').addEventListener('click', () => { state = freshState(); render(); saveState(); });

const drawer = document.querySelector('#toolsDrawer');
const toolsButton = document.querySelector('#toolsButton');
const drawerBackdrop = document.querySelector('#drawerBackdrop');
const drawerClose = document.querySelector('#drawerClose');
function openDrawer() {
  drawer.inert = false; drawer.setAttribute('aria-hidden', 'false');
  drawerBackdrop.classList.add('is-visible'); drawer.classList.add('is-open');
  toolsButton.setAttribute('aria-expanded', 'true'); document.body.classList.add('drawer-open');
  drawerClose.focus();
}
function closeDrawer() {
  if (!drawer.classList.contains('is-open')) return;
  drawer.classList.remove('is-open'); drawerBackdrop.classList.remove('is-visible');
  drawer.setAttribute('aria-hidden', 'true'); drawer.inert = true;
  toolsButton.setAttribute('aria-expanded', 'false'); document.body.classList.remove('drawer-open');
  toolsButton.focus();
}
toolsButton.addEventListener('click', openDrawer);
drawerClose.addEventListener('click', closeDrawer);
drawerBackdrop.addEventListener('click', closeDrawer);
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeDrawer(); });
document.querySelector('#themeToggle').addEventListener('click', () => setTheme(currentTheme === 'dark' ? 'light' : 'dark'));

let expression = '';
let lastResult = null;
let justEvaluated = false;
const calcOutput = document.querySelector('#calcDisplay');
const operatorSymbols = { '*': '×', '/': '÷', '-': '−', '+': '+' };
function paintCalc() { calcOutput.textContent = expression ? expression.replace(/[*/+-]/g, operator => operatorSymbols[operator]) : '0'; }
function evaluateExpression(source) {
  const tokens = source.match(/(?:\d+\.?\d*|\.\d+)|[+*/-]/g);
  if (!tokens || tokens.join('') !== source || !/\d/.test(source)) throw new Error('Expresión incompleta');
  let index = 0;
  function primary() {
    let sign = 1;
    while (tokens[index] === '+' || tokens[index] === '-') { if (tokens[index] === '-') sign *= -1; index++; }
    const token = tokens[index++];
    if (!token || !/^(?:\d+\.?\d*|\.\d+)$/.test(token) || !Number.isFinite(Number(token))) throw new Error('Número inválido');
    return sign * Number(token);
  }
  function term() {
    let value = primary();
    while (tokens[index] === '*' || tokens[index] === '/') {
      const operator = tokens[index++]; const next = primary();
      value = operator === '*' ? value * next : value / next;
    }
    return value;
  }
  function sum() {
    let value = term();
    while (tokens[index] === '+' || tokens[index] === '-') {
      const operator = tokens[index++]; const next = term();
      value = operator === '+' ? value + next : value - next;
    }
    return value;
  }
  const result = sum();
  if (index !== tokens.length || !Number.isFinite(result)) throw new Error('Resultado no válido');
  return Number(result.toPrecision(12));
}
function toggleLastSign() {
  const match = expression.match(/\d*\.?\d+\.?\d*$/);
  if (!match) return;
  const start = match.index;
  const previous = expression[start - 1];
  if (previous === '-' && (start === 1 || '+-*/'.includes(expression[start - 2]))) expression = expression.slice(0, start - 1) + expression.slice(start);
  else expression = expression.slice(0, start) + '-' + expression.slice(start);
}
function calcAction(action, value) {
  if (action === 'clear') { expression = ''; lastResult = null; justEvaluated = false; }
  else if (action === 'digit') {
    if (justEvaluated) { expression = ''; justEvaluated = false; }
    if (expression.length < 36) expression += value;
  } else if (action === 'decimal') {
    if (justEvaluated) { expression = ''; justEvaluated = false; }
    const currentNumber = expression.match(/\d*\.?\d*$/)?.[0] ?? '';
    if (!currentNumber.includes('.')) expression += currentNumber ? '.' : '0.';
  } else if (action === 'operator') {
    if (justEvaluated) {
      if (lastResult === null) { expression = ''; justEvaluated = false; return; }
      expression = String(lastResult); justEvaluated = false;
    }
    if (!expression) return;
    if (/[+*/-]$/.test(expression)) expression = expression.slice(0, -1) + value;
    else expression += value;
  } else if (action === 'sign') {
    if (justEvaluated) { expression = String(lastResult); justEvaluated = false; }
    toggleLastSign();
  } else if (action === 'backspace') {
    if (justEvaluated) { expression = ''; justEvaluated = false; lastResult = null; }
    else expression = expression.slice(0, -1);
  } else if (action === 'equals' && expression) {
    try { lastResult = evaluateExpression(expression); expression = String(lastResult); justEvaluated = true; }
    catch { expression = 'Error'; justEvaluated = true; lastResult = null; }
  }
  paintCalc();
}
document.querySelector('#calcKeys').addEventListener('click', event => {
  const button = event.target.closest('button');
  if (button) calcAction(button.dataset.action, button.dataset.value);
});
setTheme(state.theme);
render();