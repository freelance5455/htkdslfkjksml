// Application entry point; the app stores its data locally in the browser.

import './script.js';
