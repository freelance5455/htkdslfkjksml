// ==========================================
// MASTER LOCALIZED RECIPE DATA SHEET
// ==========================================
// Removed hardcoded arrays. Hydrated asynchronously at boot sequence via server pipelines.
//import { defaultRecipes } from './RecipeExtraction.js';
var activeViewRoutingMarker="welcom";
var currentActiveView="Loading";
/// ==========================================
// JSONBIN.IO SERVER SYNC SETUPS CONFIG
// ==========================================
var MASTER_KEY = '$2a$10$IFsoAQUJmzOdlmpBah4HuerhSgv8FxIOOLG8dlJc7GM8S0qpmnPCO';

// 🔒 Admin Node Bin (Only your administration terminal connects here to view/review submissions)
var MASTER_BIN_ID = '6ab22f6eac6210605ae8802a';
var MASTER_CLOUD_DATABASE_URL = "https://api.jsonbin.io/v3/b/" + MASTER_BIN_ID;

// 🌐 Public Distribution Bin (Regular users download from here; locked & uneditable)
var PUBLIC_BIN_ID = '6ab55e16ffd5d160532b3af5'; 
var PUBLIC_CLOUD_DATABASE_URL = "https://api.jsonbin.io/v3/b/" + PUBLIC_BIN_ID;

// Administrative Flag: Set to true ONLY on your machine. Set to false for the files you sell/distribute.
var IS_ADMIN_BUILD_TERMINAL = false;

var communityRecipesShared= [];

// Neutral fallback artwork used whenever a recipe has no usable image URL.
var DEFAULT_RECIPE_IMAGE = "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1200&q=80&auto=format&fit=crop";

// ==========================================
// APP STATE & PROFILES ENVIRONMENT CONFIG
// ========================================== 
var appState = {
    unit: 'metric',
    lang: "en",
    audioEnabled: false,
    currentScreen: "welcome-screen",
    currentTab: "all",
    activeRecipeId: null,
    currentUser: "User_1",
    screenHistory: ["welcome-screen"] 
};

var expandedCategories = {
    "Book_1": false, "Book_2": false, "Book_3": false, "Book_4": false, "Book_5": false,
    "Book_6": false, "Book_7": false, "Book_8": false, "Book_9": false, "Book_10": false,
};

var categoryTranslations = {
    "Book_1":  {en: "Artisanal Baking, Breakfast & Breads", af: "Ontbyt, Bakkery en Tradisionele Brode"},
    "Book_2":  {en: "Starters, Small Bites & Appetizers", af: "Voorgeregte, Happies en Smeere"},
    "Book_3":  {en: "Soups, Potjies & Hearty Stews", af: "Soppe, Bredies en Potjiekos"},
    "Book_4":  {en: "Fresh Salads & Wholesome Veggie Sides", af: "Vars Slaaie en Groente Bygeregte"},
    "Book_5":  {en: "Light Meals, Casual Pies & Burgers", af: "Ligter Geregtes, Pasteie en Burgers"},
    "Book_6":  {en: "Mains: Premium Poultry, Meats & Game", af: "Hoofgeregte: Hoender, Vleis en Wildsvleis"},
    "Book_7":  {en: "Mains: Seafood & Coastal Catches", af: "Hoofgeregte: Seekos en Vis-Spesialiteite"},
    "Book_8":  {en: "Aromatic Curries & Heritage Dishes", af: "Geurige Kerries en Tradisionele Afval"},
    "Book_9":  {en: "Celebration Cakes, Desserts & Treats", af: "Nageregte, Koeke en Soet Bederfies"},
    "Book_10": {en: "Pantry Staples, Preserves & Beverages", af: "Ingelê, Blatjan, Biltong en Drankies"}
};

// ==========================================
// HARDWARE BACK BUTTON OVERRIDE SYSTEM
// ==========================================
if (typeof window !== 'undefined') {
    window.addEventListener('load', function() {
        window.history.pushState({ screen: "welcome-screen" }, "");
    });

    window.addEventListener('popstate', function(event) {
        if (appState.screenHistory.length > 1) {
            window.history.pushState(null, null, window.location.pathname);
            
            var currentScreenId = appState.currentScreen;
            appState.screenHistory.pop();
            var previousScreen = appState.screenHistory[appState.screenHistory.length - 1];
            
            if (window.speechSynthesis) window.speechSynthesis.cancel();
            
            document.getElementById(currentScreenId).classList.replace('active', 'hidden');
            document.getElementById(previousScreen).classList.replace('hidden', 'active');
            appState.currentScreen = previousScreen;
            
            if (previousScreen === 'list-screen') {
                renderRecipeList();
            }
        } else {
            window.history.pushState(null, null, window.location.pathname);
        }
    });
}


// Ensure navigation systems attach directly onto global window scope targets natively
// Ensure navigation systems attach directly onto global window scope targets natively
if (typeof window !== 'undefined') {
    window.nextScreen = function(screenId) {
        var currentEl = document.getElementById(appState.currentScreen);
        var targetEl = document.getElementById(screenId);
        
        if (currentEl && targetEl) {
            currentEl.classList.remove('active');
            currentEl.classList.add('hidden');
            
            targetEl.classList.remove('hidden');
            targetEl.classList.add('active');
            
            appState.currentScreen = screenId;
            appState.screenHistory.push(screenId);
            window.history.pushState({ screen: screenId }, "");
        }
    };

    // FIXED MASTER WELCOME CLICK ROUTER: Safely avoids event bubbling traps completely
    window.handleWelcomeClick = function(event) {
        if (event && event.target) {
            if (event.target.closest('#welcome-activate-btn') || 
                event.target.closest('#welcome-trial-status-container') ||
                event.target.closest('#lockout-screen')) {
                
                if (typeof event.stopPropagation === 'function') event.stopPropagation();
                return; 
            }
        }
        
        if (event && typeof event.stopPropagation === 'function') {
            event.stopPropagation();
        }
        
        console.log("Welcome screen background tap verified. Advancing to onboarding sequence...");
        window.nextScreen('unit-screen'); 
    };
}

 window.validateLicenseKey = function() {
    var key = document.getElementById('license-key-input').value.trim();
    if (key === "100123200345300678400901") {
        localStorage.setItem('recipe_app_unlocked', 'true');
        
        // Instantly switch off structural layout visibility of the welcome display containers
        var statusContainer = document.getElementById('welcome-trial-status-container');
        if (statusContainer) {
            statusContainer.style.display = 'none';
        }
        
        // Return user to onboarding flow safely without forcing a hard browser canvas rebuild
        var lockoutScreen = document.getElementById('lockout-screen');
        if (lockoutScreen) {
            lockoutScreen.classList.replace('active', 'hidden');
        }
        
        // Put the welcome screen back on view cleanly
        var welcomeScreen = document.getElementById('welcome-screen');
        if (welcomeScreen) {
    welcomeScreen.classList.replace('hidden', 'active');
    appState.currentScreen = "welcome-screen";
}

// FORCE LOCAL STORAGE HYDRATION ROUTINE
initializeUserEnvironments();

alert("Verification Success! Device registered permanently.");
    } else {
        alert("Invalid authorization sequence validation entry parameter code.");
    }
};


/// ==========================================
// DYNAMIC APP INITIALIZATION DELEGATES
// ==========================================
if (typeof document !== 'undefined') {
    document.addEventListener("DOMContentLoaded", function() {
        var accessGranted = checkRegistrationStatus();
        if (accessGranted) {
            initializeUserEnvironments();
            populateUserDropdown();

            const formElement = document.getElementById('custom-recipe-form');
            if (formElement) {
                formElement.addEventListener('submit', saveCustomRecipe);
            }
        }
    });
}
    
// ==========================================
// EXCLUSIVE WELCOME SCREEN TRIAL CONTROLLER
// ==========================================
function checkRegistrationStatus() {
    if (localStorage.getItem('recipe_app_unlocked') === 'true') {
        return true;
    }
    var now = new Date().getTime();
    var installDate = localStorage.getItem('app_install_date');

    if (!installDate) {
        localStorage.setItem('app_install_date', now); 
        installDate = now;
    }

    var totalTrialDuration = 14 * 24 * 60 * 60 * 1000; 
    var timeElapsed = now - parseInt(installDate);
    var timeLeft = totalTrialDuration - timeElapsed;
    var daysLeft = Math.ceil(timeLeft / (1000 * 60 * 60 * 24));

    // Hydrate the layout element state safely right away on canvas load
    setTimeout(function() {
        var statusContainer = document.getElementById('welcome-trial-status-container');
        var textEl = document.getElementById('welcome-trial-days-text');
        if (statusContainer) {
            if (localStorage.getItem('recipe_app_unlocked') === 'true') {
                statusContainer.style.display = 'none';
            } else {
                statusContainer.style.display = 'block';
                if (textEl) {
                    textEl.innerText = appState.lang === 'en' ? 
                        "Trial Status: " + daysLeft + " days remaining" : 
                        "Proef Status: " + daysLeft + " dae oor";
                }
            }
        }
    }, 50);

    if (daysLeft <= 0) {
        showLockout("Trial Expired / Proeftyd Verby", "Your 14-day trial period has ended. Please enter your code to permanently restore catalog configurations.");
        return false;
    }
    return true;
}


function openActivationModal() {
    showLockout("Activation Key Entry", "Enter your system authorization signature key code to verify lifetime premium application profiles.");
}

// ==========================================
// USER CONFIGURATION & CREATION MANAGEMENT
// ==========================================
// ==========================================
// USER CONFIGURATION & CREATION MANAGEMENT
// ==========================================
function initializeUserEnvironments() {
    var standardUsers = JSON.parse(localStorage.getItem('recipe_app_users'));
    if (!standardUsers || !Array.isArray(standardUsers) || standardUsers.length === 0) {
        standardUsers = [{ id: "User_1", name: "My Profile" }];
    }
    localStorage.setItem('recipe_app_users', JSON.stringify(standardUsers));

    standardUsers.forEach(function(usrObj) {
        var usrId = usrObj.id;
        if (!localStorage.getItem(usrId + '_favorites')) localStorage.setItem(usrId + '_favorites', JSON.stringify([]));
        if (!localStorage.getItem(usrId + '_customs')) localStorage.setItem(usrId + '_customs', JSON.stringify([]));
    });
    
    var userExists = standardUsers.some(function(u) { return u.id === appState.currentUser; });
    if (!userExists && standardUsers.length > 0) {
        appState.currentUser = standardUsers[0].id;
    }

    // Immediately load cached cloud data from memory to allow rapid offline startup
    var cachedCloudData = localStorage.getItem('app_cloud_cache_backup');
    if (cachedCloudData) {
        try { communityRecipesShared = JSON.parse(cachedCloudData); } catch(e) { communityRecipesShared = []; }
    }
    
    // Initialize localization text strings
    if (typeof localizeLabels === "function") {
        localizeLabels();
    }
    
    var activeDatabaseTargetUrl = IS_ADMIN_BUILD_TERMINAL ? MASTER_CLOUD_DATABASE_URL : PUBLIC_CLOUD_DATABASE_URL;
    
    // OFFLINE SHORT-CIRCUIT: Skip network lag if the device is already flagged offline
    if (!navigator.onLine) {
        console.warn("Device offline. Loaded local memory datasets safely.");
        renderRecipeList();
        return;
    }

    // Fetch latest recipe list from jsonbin.io
    fetch(activeDatabaseTargetUrl, { method: 'GET', headers: { 'X-Master-Key': MASTER_KEY } })
        .then(function(res) { 
            if (!res.ok) throw new Error("Server response error status: " + res.status);
            return res.json(); 
        })
        .then(function(data) { 
            var fullCloudRecordList = data.record || data || []; 
            if (Array.isArray(fullCloudRecordList) && fullCloudRecordList.length > 0) { 
                communityRecipesShared = fullCloudRecordList.filter(function(recipe) { 
                    return recipe && recipe.id !== "init_seed_placeholder" && recipe.isCustom === true; 
                }); 
                localStorage.setItem('app_cloud_cache_backup', JSON.stringify(communityRecipesShared));
            }
            console.log("Cloud server database updated and synced successfully."); 

            if(typeof localizeLabels==="function")localizeLabels();
            renderRecipeList();
        })
        .catch(function (layoutError) {
            console.warn("Cloud connection missed. Proceeding with local standalone fallback.", layoutError);
            renderRecipeList();
        });
}

function populateUserDropdown() {
    var select = document.getElementById('user-selector');
    if (!select) return;
    
    var standardUsers = JSON.parse(localStorage.getItem('recipe_app_users')) || [{ id: "User_1", name: "My Profile" }];
    select.innerHTML = "";
    
    standardUsers.forEach(function(usrObj) {
        var opt = document.createElement('option');
        opt.value = usrObj.id;
        opt.innerText = usrObj.name;
        select.appendChild(opt);
    });
    select.value = appState.currentUser;
    
    var headerElement = select.parentElement;
    if (headerElement) {
        var oldWrapper = document.getElementById('profile-actions-wrapper');
        if (oldWrapper) oldWrapper.remove();
        
        var controlsWrapper = document.createElement('span');
        controlsWrapper.id = 'profile-actions-wrapper';
        controlsWrapper.style.display = 'inline-flex';
        controlsWrapper.style.gap = '4px';
        controlsWrapper.style.marginLeft = '6px';
        headerElement.insertBefore(controlsWrapper, select.nextSibling);
        
        controlsWrapper.innerHTML = `
            <span id="network-sync-badge" class="online-badge">⚡ ONLINE</span>
            <button class="theme-toggle-btn" title="Toggle Light/Dark Theme" onclick="toggleApplicationThemeStyle()">🌓</button>
            <button class="add-user-btn" title="Add User" onclick="createNewUserProfile()">+</button>
            <button class="add-user-btn" style="font-size:0.85rem; padding:6px 8px;" title="Rename User" onclick="renameUserProfile()">✎</button>
            <button class="add-user-btn" style="font-size:0.85rem; padding:6px 8px; background-color:#d32f2f;" title="Remove User" onclick="deleteUserProfile()">✕</button>
        `;
        initializeNetworkSynchronizationEngine();
    }
}

function createNewUserProfile() {
    var standardUsers = JSON.parse(localStorage.getItem('recipe_app_users')) || [{ id: "User_1", name: "My Profile" }];
    if (standardUsers.length >= 3) {
        alert(appState.lang === 'en' ? "Maximum limit of 3 users reached for this application!" : "Maksimum limiet van 3 gebruikers is bereik vir hierdie toepassing!");
        return;
    }
    
    var promptMsg = appState.lang === 'en' ? "Enter name for new profile:" : "Voer naam in vir nuwe profiel:";
    var rawInput = prompt(promptMsg, "");
    if (!rawInput || rawInput.trim() === "") return;
    
    var safeName = rawInput.replace(/[<>]/g, "").trim().substring(0, 20);
    if (safeName === "") return;
    
    var newUserId = "User_" + new Date().getTime();
    standardUsers.push({ id: newUserId, name: safeName });
    
    localStorage.setItem('recipe_app_users', JSON.stringify(standardUsers));
    localStorage.setItem(newUserId + '_favorites', JSON.stringify([]));
    localStorage.setItem(newUserId + '_customs', JSON.stringify([]));
    
    appState.currentUser = newUserId;
    populateUserDropdown();
    renderRecipeList();
}

function renameUserProfile() {
    var standardUsers = JSON.parse(localStorage.getItem('recipe_app_users')) || [];
    var userIndex = standardUsers.findIndex(function(u) { return u.id === appState.currentUser; });
    if (userIndex === -1) return;
    
    var promptMsg = appState.lang === 'en' ? "Enter new name for this profile:" : "Voer nuwe naam in vir hierdie profiel:";
    var rawInput = prompt(promptMsg, standardUsers[userIndex].name);
    if (!rawInput || rawInput.trim() === "") return;
    
    var safeName = rawInput.replace(/[<>]/g, "").trim().substring(0, 20);
    if (safeName === "") return;
    
    standardUsers[userIndex].name = safeName;
    localStorage.setItem('recipe_app_users', JSON.stringify(standardUsers));
    populateUserDropdown();
}

function deleteUserProfile() {
    var standardUsers = JSON.parse(localStorage.getItem('recipe_app_users')) || [];
    if (standardUsers.length <= 1) {
        alert(appState.lang === 'en' ? "Cannot delete profile! The application requires at least one active profile." : "Kan nie profiel uitvee nie! Die toepassing vereis ten minste een aktiewe profiel.");
        return;
    }
    
    var confirmMsg = appState.lang === 'en' ? "Are you sure you want to delete this profile? All custom recipes and favorites will be permanently cleared." : "Is jy seker jy wil hierdie profiel uitvee? Alle pasgemaakte resepte en gunstelinge sal permanent verwyder word.";
    if (!confirm(confirmMsg)) return;
    
    var activeIdToDelete = appState.currentUser;
    standardUsers = standardUsers.filter(function(u) { return u.id !== activeIdToDelete; });
    localStorage.setItem('recipe_app_users', JSON.stringify(standardUsers));
    
            localStorage.removeItem(activeIdToDelete + '_favorites');
    localStorage.removeItem(activeIdToDelete + '_customs');
    
    appState.currentUser = standardUsers[0].id; 
 
    populateUserDropdown();
    renderRecipeList();
    
    var payloadPacket = { id: activeIdToDelete };
    if (navigator.onLine) {
        synchronizeProfileRemovalsWithCloud(payloadPacket);
    } else {
        queueOfflineSyncTask(payloadPacket, "DELETE_USER");
    }
}

function switchUser(val) {
    appState.currentUser = val;
    renderRecipeList();
}

function getAllRecipes() {
    var text = localStorage.getItem(appState.currentUser + '_customs');
    var localCustoms = [];
    try {
        if (text) localCustoms = JSON.parse(text);
    } catch (e) {
        localCustoms = [];
    }
    var masterList = [];
    // Look up your global database array correctly to populate your screen
    var offlineDataSheet = window.defaultRecipes || [];
    if (Array.isArray(offlineDataSheet)) masterList = masterList.concat(offlineDataSheet);
    if (Array.isArray(localCustoms)) masterList = masterList.concat(localCustoms);
    if (Array.isArray(communityRecipesShared)) masterList = masterList.concat(communityRecipesShared);
    return masterList;
}


function showLockout(title, message) {
    document.querySelectorAll('.screen').forEach(function(s) { s.classList.replace('active', 'hidden'); });
    var lockout = document.getElementById('lockout-screen');
    if (lockout) lockout.classList.replace('hidden', 'active');
    
    var tEl = document.getElementById('lockout-title');
    var mEl = document.getElementById('lockout-message');
    if (tEl) tEl.innerText = title;
    if (mEl) mEl.innerText = message;
}

function selectUnit(unit) {
    appState.unit = unit;
    nextScreen('language-screen');
}

function selectLanguage(lang) {
    appState.lang = lang;
    localizeLabels();
    nextScreen('audio-screen');
}

function selectAudio(enabled) {
    appState.audioEnabled = enabled;
    nextScreen('list-screen');
}

function localizeLabels() {
    var isEn = appState.lang === 'en';
    
    // Core label interface nodes lookup safety validation checklist
    var audioTitle = document.getElementById('audio-title');
    var listTitle = document.getElementById('list-title');
    var tabAll = document.getElementById('tab-all');
    var tabFav = document.getElementById('tab-fav');
    var addTitle = document.getElementById('add-title');
    var discTitle = document.getElementById('disc-title');
    var discText = document.getElementById('disc-text');

    if (audioTitle) audioTitle.innerText = isEn ? "Read Aloud?" : "Wil jy hê die resep moet hardop gelees word?";
    if (listTitle) listTitle.innerText = isEn ? "Categories" : "Kategorieë";
    if (tabAll) tabAll.innerText = isEn ? "Index Tree" : "Inhoudsboom";
    if (tabFav) tabFav.innerText = isEn ? "★ My Favorites" : "★ My Gunstelinge";
    if (addTitle) addTitle.innerText = isEn ? "Add Recipe" : "Nuwe Resep";
    if (discTitle) discTitle.innerText = isEn ? "Disclaimer:" : "Vrywaring:";
    if (discText) discText.innerText = isEn ?
        "Any custom recipe submitted will be securely synchronized to our master catalog database for verification review, and may be featured in future official version prints." :
        "Enige pasgemaakte resep wat ingedien word, sal veilig gesinchroniseer word na ons meesterkatalogusdatabasis vir hersiening, en kan in toekomstige amptelike uitgawes verskyn.";

    // Refresh dynamic trial tracking box strings inside the welcome screen card layout
    var now = new Date().getTime();
    var installDate = parseInt(localStorage.getItem('app_install_date') || now);
    var daysLeft = Math.ceil(((14 * 24 * 60 * 60 * 1000) - (now - installDate)) / (1000 * 60 * 60 * 24));
    
    var statusContainer = document.getElementById('welcome-trial-status-container');
    var textEl = document.getElementById('welcome-trial-days-text');
    var activateBtn = document.getElementById('welcome-activate-btn');
    
    if (statusContainer) {
        if (localStorage.getItem('recipe_app_unlocked') === 'true') {
            statusContainer.style.setProperty('display', 'none', 'important');
        } else {
            // FIXED: Only alters the visibility display configuration property of the trial tracking box block asset.
            // It completely leaves your active screen transitions alone!
            statusContainer.style.display = 'block';
            if (textEl) {
                textEl.innerText = isEn ? "Trial Status: " + daysLeft + " days remaining" : "Proef Status: " + daysLeft + " dae oor";
            }
            if (activateBtn) {
                activateBtn.innerText = isEn ? "Activate Premium" : "Aktiveer Premium";
            }
        }
    }
}

function switchTab(t) {
    appState.currentTab = t;
    document.getElementById('tab-all').classList.toggle('active-tab', t==='all');
    document.getElementById('tab-fav').classList.toggle('active-tab', t==='fav');
    renderRecipeList();
}

// Resolves the correct ingredient array for a recipe, gracefully falling back
// across unit systems (metric/imperial) and languages when data is missing.
function getRecipeIngredients(recipe, unit, lang) {
    if (!recipe) return [];
    if (recipe.isCustom) return Array.isArray(recipe.ingredients) ? recipe.ingredients : [];
    if (!recipe.ingredients || typeof recipe.ingredients !== 'object') return [];

    var units = [unit];
    if (unit === 'imperial') units.push('impereal');
    units.push(unit === 'metric' ? 'imperial' : 'metric');

    var langs = [lang, lang === 'en' ? 'af' : 'en'];

    for (var u = 0; u < units.length; u++) {
        var unitData = recipe.ingredients[units[u]];
        if (!unitData || typeof unitData !== 'object') continue;
        for (var l = 0; l < langs.length; l++) {
            var arr = unitData[langs[l]];
            if (Array.isArray(arr) && arr.length > 0) return arr;
        }
    }

    // Last resort: return any non-empty array we can find.
    for (var key in recipe.ingredients) {
        var ud = recipe.ingredients[key];
        if (ud && typeof ud === 'object') {
            for (var lk in ud) {
                if (Array.isArray(ud[lk]) && ud[lk].length > 0) return ud[lk];
            }
        }
    }
    return [];
}

// Resolves the correct preparation steps, falling back across languages.
function getRecipeMethod(recipe, lang) {
    if (!recipe) return [];
    if (recipe.isCustom) return Array.isArray(recipe.method) ? recipe.method : [];
    if (!recipe.method || typeof recipe.method !== 'object') return [];

    var langs = [lang, lang === 'en' ? 'af' : 'en'];
    for (var i = 0; i < langs.length; i++) {
        var arr = recipe.method[langs[i]];
        if (Array.isArray(arr) && arr.length > 0) return arr;
    }
    return [];
}

// Escapes user-supplied strings before they are injected into innerHTML,
// preventing stored XSS from custom / cloud-submitted recipes.
function escapeHtml(value) {
    if (value === null || value === undefined) return "";
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

function renderRecipeList() {
    var container = document.getElementById('recipe-list-container');
    
    // SAFE LANDING CHECK: If the container isn't loaded on the canvas yet, exit gracefully
    if (!container) return;
    
    container.innerHTML = "";

    
    var searchInput = document.getElementById('recipe-search-input');
    if (!searchInput) {
        var wrapper = document.createElement('div');
        wrapper.style.padding = "10px 15px 5px 15px";
        wrapper.style.width = "100%";
        
        var placeholderText = appState.lang === 'en' ? "Search recipe name or ingredients (comma separated)..." : "Soek resepnaam of bestanddele (geskei met komma)...";
        wrapper.innerHTML = `<input type="text" id="recipe-search-input" class="form-input" style="margin: 0; padding: 10px 12px; font-size: 0.95rem; width: 100%; box-shadow: inset 0 1px 3px rgba(0,0,0,0.05);" placeholder="${placeholderText}" oninput="renderRecipeList()">`;
        container.parentNode.insertBefore(wrapper, container);
        searchInput = document.getElementById('recipe-search-input');
    }

    var list = getAllRecipes();
    var query = searchInput ? searchInput.value.toLowerCase().trim() : "";
    if (query !== "") {
        var queryTokens = query.split(',').map(function(t) { return t.trim(); }).filter(function(t) { return t !== ""; });
        
        list = list.filter(function(recipe) {
            var rawName = recipe.isCustom ? recipe.name : (recipe.name ? recipe.name[appState.lang] : "");
            var recipeName = (rawName || "").toLowerCase();
            var ingredientsList = getRecipeIngredients(recipe, appState.unit, appState.lang);
            var combinedIngredientsText = (Array.isArray(ingredientsList) ? ingredientsList.join(' ') : "").toLowerCase();

            var matchesName = queryTokens.some(function(token) { return recipeName.indexOf(token) !== -1; });
            var matchesIngredients = queryTokens.every(function(token) { return combinedIngredientsText.indexOf(token) !== -1; });
            
            return matchesName || matchesIngredients;
        });
    }

    if (appState.currentTab === 'fav') {
        var favs = JSON.parse(localStorage.getItem(appState.currentUser + '_favorites')) || [];
        list = list.filter(function (r) {
            return favs.includes(r.id.toString());
        });
    }

    var categories = ["Book_1", "Book_2", "Book_3", "Book_4", "Book_5", "Book_6", "Book_7", "Book_8", "Book_9", "Book_10"];

    categories.forEach(function (cat) {
        var catList = list.filter(function (r) {
            return r.category === cat;
        });
        if (catList.length === 0) return;

        var header = document.createElement('div');
        header.className = "category-tree-header";
        var arrow = expandedCategories[cat] ? " ▾" : " ▸";

        var categoryDisplayName = cat;
        if (categoryTranslations[cat]) {
            categoryDisplayName = categoryTranslations[cat][appState.lang];
        }

        header.innerText = categoryDisplayName + " (" + catList.length + ")" + arrow;

        header.onclick = function () {
            expandedCategories[cat] = !expandedCategories[cat];
            renderRecipeList();
        };

        container.appendChild(header);

        var wrapper = document.createElement('div');
        wrapper.className = "category-recipes-wrapper";
        
        var activeSearchText = document.getElementById('recipe-search-input') ? document.getElementById('recipe-search-input').value.trim() : "";
        var isCollapsed = !expandedCategories[cat] && activeSearchText === "";
        if (isCollapsed) {
            wrapper.className += " collapsed";
        }

        // Performance: skip building card DOM for collapsed categories.
        if (!isCollapsed) catList.forEach(function (recipe) {
            var card = document.createElement('div');
            card.className = "recipe-summary-card";
            var title = recipe.isCustom ? recipe.name : (recipe.name ? recipe.name[appState.lang] : "");
            var desc = recipe.isCustom ? recipe.desc : (recipe.desc ? recipe.desc[appState.lang] : "");
  var listArray = getRecipeIngredients(recipe, appState.unit, appState.lang);
var ingPreview = Array.isArray(listArray) && listArray.length > 0 ? listArray.slice(0, 3).join(', ') : 'Premium Recipe Ingredients';

            var safeId = escapeHtml(recipe.id);
            card.innerHTML = `
                <div style="position:absolute; top:15px; right:15px; display:flex; align-items:center; gap:6px;">
                    <input type="checkbox" class="checkbox-ticker recipe-select-check" data-id="${safeId}" onchange="toggleShoppingFloatingButton()">
                </div>
                <h3>${escapeHtml(title)}</h3>
                <p class="desc">${escapeHtml(desc)}</p>
                <p class="ing-preview">${appState.lang === 'en' ? 'Ingredients' : 'Bestanddele'}: ${escapeHtml(ingPreview)}...</p>
                <button class="btn" style="padding:6px 12px; margin: 5px 0 0 0; width:auto;font-size:0.85rem;" onclick="openRecipeDetail('${safeId}')">open</button>`;
            wrapper.appendChild(card);
        });
        container.appendChild(wrapper);
    });
}

function saveCustomRecipe(e) {
    e.preventDefault();
    var form = document.getElementById('custom-recipe-form');
    var editingId = form.dataset.editingId; 

    var name = document.getElementById('form-name').value;
    var cat = document.getElementById('form-category').value;
    var creator = document.getElementById('form-creator').value;
    var desc = document.getElementById('form-desc').value;
    var ings = document.getElementById('form-ingredients').value.split('\n').filter(function (line) { return line.trim() !== ''; });
    var steps = document.getElementById('form-method').value.split('\n').filter(function (line) { return line.trim() !== ''; });
    var serving = document.getElementById('form-serving').value;

    var newRecipePayload = {
        id: editingId ? editingId : 'custom_' + new Date().getTime(),
        category: cat,
        isCustom: true,
        creator: creator,
        name: name,
        desc: desc,
        img: DEFAULT_RECIPE_IMAGE,
        ingredients: ings,
        method: steps,
        serving: serving,
        userSubmittedBy: appState.currentUser
    };

    var customs = JSON.parse(localStorage.getItem(appState.currentUser + '_customs')) || [];
    if (editingId) {
        customs = customs.map(function(r) { return r.id.toString() === editingId.toString() ? newRecipePayload : r; });
        delete form.dataset.editingId; 
    } else {
        customs.push(newRecipePayload);
    }
    localStorage.setItem(appState.currentUser + '_customs', JSON.stringify(customs));

    renderRecipeList();
    nextScreen('list-screen');
    document.getElementById('custom-recipe-form').reset();

    if (navigator.onLine) {
        synchronizeLocalChangesWithCloudCloud(newRecipePayload, "ADD");
    } else {
        queueOfflineSyncTask(newRecipePayload, "ADD");
    }
}

// ==========================================
// ADVANCED OFFLINE TRANSACTION PROCESSORS
// ==========================================
function synchronizeProfileRemovalsWithCloud(userPayload) {
    var activeDatabaseTargetUrl = IS_ADMIN_BUILD_TERMINAL ? MASTER_CLOUD_DATABASE_URL : PUBLIC_CLOUD_DATABASE_URL;
    // Remove every cloud recipe that was submitted by the deleted profile, then persist the cleaned list.
    fetch(activeDatabaseTargetUrl, { method: 'GET', headers: { 'X-Master-Key': MASTER_KEY } })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            var fullCloudRecordList = data.record || data || [];
            if (!Array.isArray(fullCloudRecordList)) fullCloudRecordList = [];

            var cleanedServerList = fullCloudRecordList.filter(function(recipe) {
                return recipe && recipe.userSubmittedBy !== userPayload.id;
            });

            return fetch(activeDatabaseTargetUrl, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'X-Master-Key': MASTER_KEY },
                body: JSON.stringify(cleanedServerList)
            }).then(function() {
                communityRecipesShared = cleanedServerList.filter(function(recipe) {
                    return recipe && recipe.id !== "init_seed_placeholder" && recipe.isCustom === true;
                });
                localStorage.setItem('app_cloud_cache_backup', JSON.stringify(communityRecipesShared));
                console.log("Cloud server database array structures synced successfully.");
                renderRecipeList();
            });
        })
        .catch(function(err) {
            console.warn("Cloud tracking server timed out. Running via cached parameters layout.", err);
            queueOfflineSyncTask(userPayload, "DELETE_USER");
            renderRecipeList();
        });
}


function openRecipeDetail(id) {
    var recipe = getAllRecipes().find(function (r) { return r.id.toString() === id.toString(); });
    if (!recipe) return;
    appState.activeRecipeId = id;
    var bgEl = document.getElementById('dynamic-bg');
    if (bgEl) {
        var bgImage = (recipe.img && recipe.img.indexOf('http') === 0) ? recipe.img : DEFAULT_RECIPE_IMAGE;
        bgEl.style.backgroundImage = "url('" + bgImage + "')";
    }
    var title = recipe.isCustom ? recipe.name : (recipe.name ? recipe.name[appState.lang] : "");
    var desc = recipe.isCustom ? recipe.desc : (recipe.desc ? recipe.desc[appState.lang] : "");
    var serving = recipe.isCustom ? recipe.serving : (recipe.serving ? recipe.serving[appState.lang] : "");
    document.getElementById('recipe-name').innerText = title;
    document.getElementById('recipe-desc').innerText = desc;
    document.getElementById('recipe-serving').innerText = serving;
    document.getElementById('recipe-author').innerText = (appState.lang === 'en' ? 'By' : 'Deur') + ": " + recipe.creator;
    
    var scalerContainer = document.getElementById('recipe-portion-scaler');
    if (!scalerContainer) {
        scalerContainer = document.createElement('div');
        scalerContainer.id = 'recipe-portion-scaler';
        scalerContainer.style.margin = '10px 0';
        scalerContainer.style.fontSize = '0.9rem';
        var authorBadge = document.querySelector('.author-badge');
        if (authorBadge) authorBadge.parentNode.insertBefore(scalerContainer, authorBadge.nextSibling);
    }
    
    var promptLabel = appState.lang === 'en' ? "Portion Factor:" : "Porsie-skaal Faktor:";
    var unitLabel = appState.lang === 'en' ? "Active System:" : "Aktiewe Stelsel:";
    scalerContainer.innerHTML = `
        <div style="display:flex; flex-wrap:wrap; gap:12px; align-items:center; background:rgba(0,0,0,0.03); padding:10px; border-radius:8px; margin-bottom:12px;">
            <div>
                <label style="font-weight:bold; color:var(--primary); margin-right:6px;">${promptLabel}</label>
                <select id="portion-multiplier" class="user-select-dropdown" style="color:black; background:#fff; border:1px solid #ccc; padding:4px 8px; font-size:0.85rem;" onchange="scaleRecipePortions('${id}')">
                    <option value="0.5">0.5x (${appState.lang === 'en' ? 'Half' : 'Helfte'})</option>
                    <option value="1" selected>1.0x (${appState.lang === 'en' ? 'Standard' : 'Standaard'})</option>
                    <option value="2">2.0x (${appState.lang === 'en' ? 'Double' : 'Dubbel'})</option>
                    <option value="3">3.0x</option>
                    <option value="4">4.0x (${appState.lang === 'en' ? 'Quadruple' : 'Viervoudig'})</option>
                    <option value="10">10.0x (${appState.lang === 'en' ? 'Batch Pro' : 'Groot Maat'})</option>
                </select>
            </div>
            <div>
                <label style="font-weight:bold; color:var(--primary); margin-right:6px;">${unitLabel}</label>
                <select id="unit-interconvert-selector" class="user-select-dropdown" style="color:black; background:#fff; border:1px solid #ccc; padding:4px 8px; font-size:0.85rem;" onchange="executeDynamicUnitInterconversion('${id}')">
                    <option value="metric" ${appState.unit === 'metric' ? 'selected' : ''}>Metric (g, ml)</option>
                    <option value="imperial" ${appState.unit === 'imperial' ? 'selected' : ''}>Imperial (oz, cups)</option>
                </select>
            </div>
        </div>
    `;

    var ingUl = document.getElementById('recipe-ingredients');
    ingUl.innerHTML = "";
var localizedIngs = getRecipeIngredients(recipe, appState.unit, appState.lang);

    localizedIngs.forEach(function (ing) {
        var li = document.createElement('li');
        li.innerText = ing;
        ingUl.appendChild(li);
    });

    var ingHeading = document.getElementById('recipe-ingredients-heading');
    if (ingHeading) ingHeading.style.display = localizedIngs.length ? '' : 'none';

    var methodOl = document.getElementById('recipe-method');
    methodOl.innerHTML = "";
    var localizedSteps = getRecipeMethod(recipe, appState.lang);
    localizedSteps.forEach(function (s) {
        var li = document.createElement('li');
        li.innerText = s;
        methodOl.appendChild(li);
    });

    var methodHeading = document.getElementById('recipe-method-heading');
    if (methodHeading) methodHeading.style.display = localizedSteps.length ? '' : 'none';

    var favs = JSON.parse(localStorage.getItem(appState.currentUser + '_favorites')) || [];
    document.getElementById('fav-toggle-btn').innerText = favs.includes(id.toString()) ? "★" : "☆";
    
    var adminWrapper = document.getElementById('recipe-admin-actions');
    if (!adminWrapper) {
        adminWrapper = document.createElement('span');
        adminWrapper.id = 'recipe-admin-actions';
        adminWrapper.style.display = 'inline-flex';
        adminWrapper.style.gap = '6px';
        var headerActions = document.querySelector('.header-right-actions');
        if (headerActions) headerActions.insertBefore(adminWrapper, headerActions.firstChild);
    }
    
    if (recipe.isCustom) {
        adminWrapper.innerHTML = `
            <button class="back-btn" style="background:#ffa000;" onclick="editRecipe('${recipe.id}')">${appState.lang === 'en' ? '✎ Edit' : '✎ Wysig'}</button>
            <button class="back-btn" style="background:#d32f2f;" onclick="deleteRecipe('${recipe.id}')">${appState.lang === 'en' ? '✕ Delete' : '✕ Verwyder'}</button>
        `;
    } else {
        adminWrapper.innerHTML = ''; 
    }
    
    nextScreen('detail-screen');
    if (appState.audioEnabled) speakRecipe(title, desc, localizedIngs, localizedSteps);
}

// ==========================================
// SELECTION ARCHITECTURE FAVORITES PIPELINE
// ==========================================
function toggleFavorite() {
    var id = appState.activeRecipeId.toString();
    var key = appState.currentUser + '_favorites';
    var favs = JSON.parse(localStorage.getItem(key)) || [];
    if (favs.includes(id)) {
        favs = favs.filter(function (f) { return f !== id; });
        document.getElementById('fav-toggle-btn').innerText = "☆";
    } else {
        favs.push(id);
        document.getElementById('fav-toggle-btn').innerText = "★";
    }
    localStorage.setItem(key, JSON.stringify(favs));
}

function goBackToList() {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    window.history.back();
}

function speakRecipe(title, desc, ingredients, steps) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    var text = title + ". " + desc + ". " + (appState.lang === 'en' ? 'Ingredients' : 'Bestanddele') + ": " + ingredients.join(', ') + ". " + (appState.lang === 'en' ? 'Method' : 'Metode') + ": " + steps.join('. ');
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = appState.lang === 'en' ? 'en-US' : 'af-ZA';
    window.speechSynthesis.speak(utterance);
}

// ==========================================
// DAILY PRINT CONTROLLER LIMITATION
// ==========================================
    window.triggerPrint = function() {
    // Fix: Added [0] to extract the pure date string out of the split array mapping
    var todayStr = new Date().toISOString().split('T')[0]; 
    var lastPrintedDate = localStorage.getItem('app_last_print_date');

        if (lastPrintedDate === todayStr) {
        alert(appState.lang === 'en' ? "Print limit reached! You can only print 1 recipe per day." : "Druklimiet bereik! Jy kan slegs 1 resep per dag druk.");
        return;
    }
    
    localStorage.setItem('app_last_print_date', todayStr);
    window.print();
}

// ==========================================
// RECIPE MODIFICATION & EDITING MANAGEMENT
// ==========================================
function deleteRecipe(id) {
    var confirmMsg = appState.lang === 'en' ? "Are you sure you want to permanently delete this recipe?" : "Is jy seker jy wil hierdie resep permanent verwyder?";
    if (!confirm(confirmMsg)) return;

    var customs = JSON.parse(localStorage.getItem(appState.currentUser + '_customs')) || [];
    customs = customs.filter(function(r) { return r.id.toString() !== id.toString(); });
    localStorage.setItem(appState.currentUser + '_customs', JSON.stringify(customs));

    var activeDatabaseTargetUrl = IS_ADMIN_BUILD_TERMINAL ? MASTER_CLOUD_DATABASE_URL : PUBLIC_CLOUD_DATABASE_URL;
    fetch(activeDatabaseTargetUrl, {
        method: 'GET',
        headers: {'X-Master-Key': MASTER_KEY}
    })
    .then(function(res) { return res.json(); })
    .then(function(currentCloudData) {
        var currentServerList = currentCloudData.record || [];
        currentServerList = currentServerList.filter(function(r) { return r.id.toString() !== id.toString(); });
        return fetch(activeDatabaseTargetUrl, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'X-Master-Key': MASTER_KEY },
            body: JSON.stringify(currentServerList)
        });
    })
    .then(function() {
        alert(appState.lang === 'en' ? "Recipe removed successfully!" : "Resep suksesvol verwyder!");
        renderRecipeList();
        window.history.back(); 
    })
    .catch(function(err) {
        console.error("Cloud tracking database deletion collision error:", err);
        renderRecipeList();
        window.history.back();
    });
}

function editRecipe(id) {
    var recipe = getAllRecipes().find(function(r) { return r.id.toString() === id.toString(); });
    if (!recipe) return;

    document.getElementById('form-name').value = recipe.name;
    document.getElementById('form-category').value = recipe.category;
    document.getElementById('form-creator').value = recipe.creator;
    document.getElementById('form-desc').value = recipe.desc;
    document.getElementById('form-ingredients').value = (recipe.ingredients || []).join('\n');
    document.getElementById('form-method').value = (recipe.method || []).join('\n');
    document.getElementById('form-serving').value = recipe.serving;

    var form = document.getElementById('custom-recipe-form');
    form.dataset.editingId = id;

    nextScreen('add-recipe-screen');
}

// ==========================================
// COMMERCIAL PORTION SCALING UTILITY ENGINE
// ==========================================
function scaleRecipePortions(recipeId) {
    var recipe = getAllRecipes().find(function (r) { return r.id.toString() === recipeId.toString(); });
    if (!recipe) return;

    var select = document.getElementById('portion-multiplier');
    var factor = parseFloat(select ? select.value : 1);
    
    var ingUl = document.getElementById('recipe-ingredients');
    if (!ingUl) return;
    ingUl.innerHTML = "";

    var baseIngredients = getRecipeIngredients(recipe, appState.unit, appState.lang);

    baseIngredients.forEach(function (ingText) {
        var parsedText = ingText.replace(/^([0-9\.\/]+)/, function(match) {
            if (match.indexOf('/') !== -1) {
                var parts = match.split('/');
                var val = parseFloat(parts[0]) / parseFloat(parts[1]);
                return (val * factor).toFixed(2).replace(/\.00$/, '');
            }
            var numericValue = parseFloat(match);
            if (!isNaN(numericValue)) {
                return (numericValue * factor).toFixed(2).replace(/\.00$/, '').replace(/\.(\d)0$/, '.$1');
            }
            return match;
        });

        var li = document.createElement('li');
        li.innerText = parsedText;
        ingUl.appendChild(li);
    });
}

// ==========================================
// COMMERCIAL BATCH CHECKLIST AGGREGATOR
// ==========================================
function toggleShoppingFloatingButton() {
    var checkedBoxes = document.querySelectorAll('.recipe-select-check:checked');
    var existingBtn = document.getElementById('floating-cart-aggregator-btn');
    
    if (checkedBoxes.length > 0) {
        if (!existingBtn) {
            existingBtn = document.createElement('button');
            existingBtn.id = 'floating-cart-aggregator-btn';
            existingBtn.className = 'fab-btn';
            existingBtn.style.left = '20px'; 
            existingBtn.style.background = '#4caf50';
            existingBtn.style.fontSize = '20px';
            existingBtn.innerHTML = '🛒';
            existingBtn.onclick = compileMasterShoppingList;
            document.body.appendChild(existingBtn);
        }
    } else if (existingBtn) {
        existingBtn.remove();
    }
}

function compileMasterShoppingList() {
    var checkedBoxes = document.querySelectorAll('.recipe-select-check:checked');
    var consolidatedIngredients = {};
    
    checkedBoxes.forEach(function(box) {
        var recipeId = box.dataset.id;
        var recipe = getAllRecipes().find(function(r) { return r.id.toString() === recipeId.toString(); });
        if (!recipe) return;

        var ingredientsList = getRecipeIngredients(recipe, appState.unit, appState.lang);
        if (!Array.isArray(ingredientsList)) return;

        ingredientsList.forEach(function(ingLine) {
            var match = ingLine.trim().match(/^([0-9\.\/]+)\s*([a-zA-Z]*)\s+(.+)$/);
            
            if (match) {
                var qty = parseFloat(match[1]);
                var unitToken = match[2].toLowerCase();
                var itemName = match[3].toLowerCase().trim();
                var compoundKey = itemName + "_" + unitToken;
                
                if (consolidatedIngredients[compoundKey]) {
                    consolidatedIngredients[compoundKey].qty += qty;
                } else {
                    consolidatedIngredients[compoundKey] = { qty: qty, unit: match[2], name: match[3].trim() };
                }
            } else {
                var baselineKey = ingLine.toLowerCase().trim() + "_raw";
                if (!consolidatedIngredients[baselineKey]) {
                    consolidatedIngredients[baselineKey] = { qty: null, unit: '', name: ingLine.trim() };
                }
            }
        });
    });
    
    displayShoppingListModal(consolidatedIngredients);
}

function displayShoppingListModal(itemsData) {
    var oldModal = document.getElementById('shopping-aggregator-modal-view');
    if (oldModal) oldModal.remove();
    
    var backdrop = document.createElement('div');
    backdrop.id = 'shopping-aggregator-modal-view';
    backdrop.style.position = 'fixed';
    backdrop.style.top = '0';
    backdrop.style.left = '0';
    backdrop.style.width = '100%';
    backdrop.style.height = '100%';
    backdrop.style.background = 'rgba(0,0,0,0.6)';
    backdrop.style.zIndex = '999';
    
    var modal = document.createElement('div');
    modal.className = 'shopping-list-modal';
    
    var headingTitle = appState.lang === 'en' ? 'Unified Shopping List' : 'Gekombineerde Inkopieslys';
    var closePrompt = appState.lang === 'en' ? 'Close' : 'Sluit';
    
    var listRowsHtml = '';
    for (var key in itemsData) {
        var item = itemsData[key];
 var quantityDisplay = item.qty !== null ? item.qty.toFixed(2).replace(/\.00$/, '') + (item.unit ? ' ' + item.unit : '') + ' ' : '';

        listRowsHtml += `
            <div class="shopping-item-row">
                <input type="checkbox" class="checkbox-ticker">
                <span><strong>${escapeHtml(quantityDisplay)}</strong>${escapeHtml(item.name)}</span>
            </div>
        `;
    }
    
        modal.innerHTML = `
        <h2 style="color:var(--primary); font-size:1.4rem; margin-bottom:15px; border-bottom:2px solid var(--primary); padding-bottom:6px;">${headingTitle}</h2>
        <div style="max-height:300px; overflow-y:auto; margin-bottom:20px;">
            ${listRowsHtml}
        </div>
        <button class="btn" style="margin:0; background:#666;" id="modal-close-btn">${closePrompt}</button>
    `;
    
    backdrop.appendChild(modal);
    document.body.appendChild(backdrop);
    
    document.getElementById('modal-close-btn').addEventListener('click', function() {
        document.getElementById('shopping-aggregator-modal-view').remove();
    });
}


// ==========================================
// BACKGROUND AUTOMATED SYNC & TTS INTEGRATION
// ==========================================
function initializeNetworkSynchronizationEngine() {
    var badge = document.getElementById('network-sync-badge');
    
    function updateInterfaceStatus() {
        if (navigator.onLine) {
            if (badge) {
                badge.innerText = appState.lang === 'en' ? "⚡ ONLINE" : "⚡ LYN-IN";
                badge.className = "online-badge";
            }
            processPendingOfflineQueues();
        } else if (badge) {
            badge.innerText = appState.lang === 'en' ? "🔌 OFFLINE" : "🔌 LYN-UIT";
            badge.className = "offline-badge";
        }
    }

    window.addEventListener('online', updateInterfaceStatus);
    window.addEventListener('offline', updateInterfaceStatus);
    updateInterfaceStatus();
}

function queueOfflineSyncTask(payload, actionType) {
    var queue = JSON.parse(localStorage.getItem('pending_sync_tasks')) || [];
    queue = queue.filter(function(task) { return task.payload.id !== payload.id; });
    queue.push({ action: actionType, payload: payload, timestamp: new Date().getTime() });
    localStorage.setItem('pending_sync_tasks', JSON.stringify(queue));
}

// ==========================================
// AUTOMATED INTERNET DATA NORMALIZATION PIPELINE
// ==========================================
function processPendingOfflineQueues() {
    var queue = JSON.parse(localStorage.getItem('pending_sync_tasks')) || [];
    if (queue.length === 0) return;

    console.log("Internet link active. Normalizing database queue sequences...");
    var activeDatabaseTargetUrl = IS_ADMIN_BUILD_TERMINAL ? MASTER_CLOUD_DATABASE_URL : PUBLIC_CLOUD_DATABASE_URL;

    fetch(activeDatabaseTargetUrl, { method: 'GET', headers: {'X-Master-Key': MASTER_KEY} })
        .then(function(res) { return res.json(); })
        .then(function(currentCloudData) {
            var currentServerList = currentCloudData.record || [];
            
            // 1. Process Profile Purge Records Safely
            var userPurgeTasks = queue.filter(function(t) { return t.action === "DELETE_USER"; });
            userPurgeTasks.forEach(function(taskItem) {
                currentServerList = currentServerList.filter(function(r) { return r.userSubmittedBy !== taskItem.payload.id; });
            });

            // 2. Process Added Custom Recipes
            var standardAddTasks = queue.filter(function(t) { return t.action === "ADD"; });
            standardAddTasks.forEach(function(task) {
                var matchIndex = currentServerList.findIndex(function(r) { return r.id.toString() === task.payload.id.toString(); });
                if (matchIndex !== -1) {
                    currentServerList[matchIndex] = task.payload;
                } else {
                    currentServerList.push(task.payload);
                }
            });

            return fetch(activeDatabaseTargetUrl, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'X-Master-Key': MASTER_KEY },
                body: JSON.stringify(currentServerList)
            });
        })
        .then(function() {
            console.log("Background synchronization complete. Queue cleared clean.");
            localStorage.removeItem('pending_sync_tasks');
        })
        .catch(function(err) {
            console.error("Failed background synchronization loop. Retaining queue parameters.", err);
        });
}


function synchronizeLocalChangesWithCloudCloud(payload, actionType) {
    var activeDatabaseTargetUrl = IS_ADMIN_BUILD_TERMINAL ? MASTER_CLOUD_DATABASE_URL : PUBLIC_CLOUD_DATABASE_URL;

    fetch(activeDatabaseTargetUrl, { method: 'GET', headers: {'X-Master-Key': MASTER_KEY} })
        .then(function(res) { return res.json(); })
        .then(function(currentCloudData) {
            var currentServerList = currentCloudData.record || [];
            var matchIndex = currentServerList.findIndex(function(r) { return r.id.toString() === payload.id.toString(); });
            
            if (matchIndex !== -1) {
                currentServerList[matchIndex] = payload;
            } else {
                currentServerList.push(payload);
            }
            
            return fetch(activeDatabaseTargetUrl, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'X-Master-Key': MASTER_KEY },
                body: JSON.stringify(currentServerList)
            });
        })
        .catch(function(err) {
            console.warn("Direct live link missed. Queueing transaction task packet.", err);
            queueOfflineSyncTask(payload, actionType);
        });
}

// ==========================================
// COMMERCIAL SYSTEM INTERCONVERSION & THEMES
// ==========================================
function toggleApplicationThemeStyle() {
    var body = document.body;
    if (body.classList.contains('light-theme-profile')) {
        body.classList.remove('light-theme-profile');
        localStorage.setItem('app_visual_theme_mode', 'dark');
    } else {
        body.classList.add('light-theme-profile');
        localStorage.setItem('app_visual_theme_mode', 'light');
    }
}

//  NEW COMPATIBLE CODE
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    window.addEventListener('DOMContentLoaded', function() {
        var activeSavedTheme = localStorage.getItem('app_visual_theme_mode');
        if (activeSavedTheme === 'light') {
            document.body.classList.add('light-theme-profile');
        }
    });
}

// Ensure global functions are attached to window namespace safely
if (typeof window !== 'undefined') {
    window.executeDynamicUnitInterconversion = function(recipeId) {
        var recipe = getAllRecipes().find(function (r) { return r.id.toString() === recipeId.toString(); });
        if (!recipe) return;

        var unitSelector = document.getElementById('unit-interconvert-selector');
        var targetUnitMode = unitSelector ? unitSelector.value : 'metric';
        
        var structuralBackupUnit = appState.unit;
        appState.unit = targetUnitMode;
        
        scaleRecipePortions(recipeId);
        
        appState.unit = structuralBackupUnit;
    };
}
