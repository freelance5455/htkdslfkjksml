(() => {
  const $ = id => document.getElementById(id);
  const buddy = $("buddy"), speech = $("speech"), mouth = $("mouth");
  const nameInput = $("nameInput"), buddyName = $("buddyName");
  const messageInput = $("messageInput"), status = $("status");
  const ttsBtn = $("ttsBtn"), meterFill = $("meterFill");
  let tts = true, micStream = null, audioCtx = null, analyser = null, raf = 0;

  const emoticons = [":)",":-)",":D","XD",";)",":P",":o",":/",":(",">:(","^_^","-_-","O_o","<3"]
    .map(x => x.trim()).filter(Boolean);

  function saveName() {
    const n = (nameInput.value || "Buddy").trim().slice(0,24) || "Buddy";
    nameInput.value = n; buddyName.textContent = n;
    say("My name is " + n + " now :)");
  }
  function setMouth(text) {
    const found = emoticons.find(e => text.includes(e));
    mouth.textContent = found || ":)";
  }
  function say(text) {
    text = String(text || "").trim().slice(0,180);
    if (!text) return;
    speech.textContent = text;
    setMouth(text);
    status.textContent = buddyName.textContent + " says " + (emoticons.find(e=>text.includes(e)) || ":)");
    buddy.classList.remove("wiggle"); void buddy.offsetWidth; buddy.classList.add("wiggle");
    if (tts && "speechSynthesis" in window) {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 1.02; u.pitch = 1.05; speechSynthesis.speak(u);
    }
  }

  nameInput.addEventListener("change", saveName);
  nameInput.addEventListener("keydown", e => { if(e.key==="Enter") saveName(); });
  $("sayBtn").addEventListener("click", () => say(messageInput.value));
  messageInput.addEventListener("keydown", e => { if(e.key==="Enter") say(messageInput.value); });

  document.querySelectorAll("[data-msg]").forEach(b => b.addEventListener("click", () => say(b.dataset.msg)));
  ttsBtn.addEventListener("click", () => {
    tts = !tts; ttsBtn.textContent = "TTS: " + (tts ? "On" : "Off");
    if (!tts && "speechSynthesis" in window) speechSynthesis.cancel();
  });

  $("emoteBtn").addEventListener("click", () => {
    const e = emoticons[Math.floor(Math.random()*emoticons.length)];
    say(e + " " + buddyName.textContent + " approves.");
  });
  $("wiggleBtn").addEventListener("click", () => {
    buddy.classList.remove("wiggle"); void buddy.offsetWidth; buddy.classList.add("wiggle");
  });
  $("overlayBtn").addEventListener("click", () => {
    document.body.classList.toggle("overlay-mode");
    status.textContent = document.body.classList.contains("overlay-mode") ? "Overlay mode :)": "Normal mode :)";
  });

  $("micBtn").addEventListener("click", async () => {
    if (micStream) {
      micStream.getTracks().forEach(t=>t.stop()); micStream=null;
      if (audioCtx) audioCtx.close(); audioCtx=null; analyser=null;
      cancelAnimationFrame(raf); meterFill.style.width="0%";
      $("micBtn").textContent="Enable mic"; status.textContent="Mic off :)"; return;
    }
    try {
      micStream = await navigator.mediaDevices.getUserMedia({audio:true});
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const src = audioCtx.createMediaStreamSource(micStream);
      analyser = audioCtx.createAnalyser(); analyser.fftSize=256; src.connect(analyser);
      const data = new Uint8Array(analyser.frequencyBinCount);
      $("micBtn").textContent="Disable mic"; status.textContent="Listening :o";
      const loop=()=>{ if(!analyser)return; analyser.getByteTimeDomainData(data);
        let sum=0; for(const v of data){const x=(v-128)/128;sum+=x*x}
        const level=Math.min(100,Math.sqrt(sum/data.length)*170);
        meterFill.style.width=level+"%";
        if(level>38) buddy.classList.add("wiggle"); else buddy.classList.remove("wiggle");
        raf=requestAnimationFrame(loop);
      }; loop();
    } catch(e) {
      status.textContent="Mic permission unavailable :/";
    }
  });

  say("Hi! I'm " + buddyName.textContent + " :)");
})();
