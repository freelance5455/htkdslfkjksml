const KEY="clinic_system_v4";
const oldKeys=["clinic_system_v2"];
let state=JSON.parse(localStorage.getItem(KEY)||'null');
if(!state){for(const k of oldKeys){try{const x=JSON.parse(localStorage.getItem(k)||'null');if(x){state=x;break}}catch(e){}}}
state=state||{settings:{clinicName:"نظام العيادة",logo:"",examPrice:10,consultPrice:0,currency:"جنيه",waServerUrl:"",waEnabled:false},rates:[],bookings:[],periods:[],operations:[],surgeries:[],expenses:[],waitlist:[],patients:[],undo:[]};
// Timestamp fields: keep the original booking creation time and add actual attendance time.
state.bookings.forEach(b=>{if(!b.bookingAt)b.bookingAt=b.createdAt||Date.now();if(!("attendedAt" in b))b.attendedAt=null; if(!("examEnteredAt" in b))b.examEnteredAt=null;});
state.settings=Object.assign({clinicName:"نظام العيادة",logo:"",examPrice:10,consultPrice:0,currency:"جنيه",waServerUrl:"",waEnabled:false},state.settings||{});
state.rates=state.rates||[];state.bookings=state.bookings||[];state.periods=state.periods||[];state.operations=state.operations||[];state.surgeries=state.surgeries||[];state.expenses=state.expenses||[];state.waitlist=state.waitlist||[];state.patients=state.patients||[];state.undo=[];
const $=id=>document.getElementById(id); const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const dateAfterDays=(n)=>{const d=new Date();d.setDate(d.getDate()+n);return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
const money=n=>Number(n||0).toLocaleString("ar-EG")+" "+(state.settings.currency||"جنيه");
const esc=s=>String(s??"").replace(/[&<>\"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const fmtDate=d=>d?new Date(d+"T00:00:00").toLocaleDateString("ar-EG",{year:"numeric",month:"short",day:"numeric"}):"";
function displayTime(t){if(!t)return"";const m=String(t).match(/^(\d{1,2}):(\d{2})$/);if(!m)return t;let h=+m[1],min=m[2],ap=h<12?"ص":"م";h=h%12||12;return `${h}:${min} ${ap}`}
function displayDateTime(ts){if(!ts)return"—";const d=new Date(ts);if(Number.isNaN(d.getTime()))return"—";return d.toLocaleString("ar-EG",{year:"numeric",month:"short",day:"numeric",hour:"numeric",minute:"2-digit",hour12:true})}
function timeToMinutes(t){const [h,m]=String(t).split(":").map(Number);return h*60+m}
function rangeEndMinutes(start,end){const s=timeToMinutes(start),e=timeToMinutes(end);return e===0&&s>0?1440:e}
function snapshot(){const x=JSON.stringify({...state,undo:[]});state.undo=(state.undo||[]).slice(-9);state.undo.push(x)}
function save(){localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));renderAll()}
function commit(fn){snapshot();fn();save()}
function undoLast(){if(!state.undo?.length){alert("لا توجد عملية يمكن التراجع عنها.");return}const x=state.undo.pop();const restored=JSON.parse(x);restored.undo=state.undo;state=restored;localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));renderAll();alert("تم التراجع عن آخر عملية.")}
function typeName(t){return({exam:"كشف",consult:"استشارة",free_exam:"كشف مجاني",free_consult:"استشارة مجانية"})[t]||t||"-"}
function statusName(s){return({booked:"محجوز",confirmed:"مؤكد",attended:"حضر",noshow:"لم يحضر",canceled:"ألغى"})[s]||s}
function statusBadge(s){return `<span class="badge status-${s}">${statusName(s)}</span>`}
function getPriceForType(type){if(type==="free_exam"||type==="free_consult")return 0;if(type==="exam")return +state.settings.examPrice||0;if(type==="consult")return +state.settings.consultPrice||0;return 0}
function effectiveAmount(b){return Math.max(0,(+b.amount||0)-(+b.discount||0))}
function normalizePeriod(p){if(!p)return;p.slots=(p.slots||[]).map(x=>typeof x==="string"?{time:x,capacity:+p.capacity||5}:{time:x.time,capacity:+x.capacity||5}).filter(x=>x.time);return p}
state.periods.forEach(normalizePeriod);
state.bookings.forEach(b=>{if(!('attendanceStatus' in b)||!b.attendanceStatus)b.attendanceStatus='pending';});

document.addEventListener("click",e=>{
  const tab=e.target.closest(".tab,[data-page]");
  if(tab && tab.dataset.page && tab.closest("nav,.sidebar,.bottom-nav,#appNav,body")){
    e.preventDefault();
    e.stopPropagation();
    showPage(tab.dataset.page);
  }
});
// موحد لأزرار النوافذ: لا نعطّل الزر قبل تشغيل الإجراء، لأن ذلك كان يمنع
// مستمع الحفظ من الوصول للإجراء على بعض المتصفحات وAndroid WebView.
let modalActionBusy=false;
document.addEventListener('click',e=>{
  const b=e.target.closest('[data-modal-action]');
  if(!b)return;
  e.preventDefault();
  e.stopPropagation();
  if(modalActionBusy)return;
  const action=b.dataset.modalAction||'';
  modalActionBusy=true;
  const oldText=b.textContent;
  if(action!=='close'){
    b.disabled=true;
    b.textContent=action.startsWith('delete')?'جارٍ الحذف...':'جارٍ التنفيذ...';
  }
  try{
    if(action==='close') closeModal();
    else if(action==='save-period') savePeriod(b.dataset.id||'');
    else if(action==='delete-period') deletePeriod(b.dataset.id||'');
    else if(action==='save-booking') saveBooking(b.dataset.id||'');
    else if(action==='delete-booking') deleteBookingPermanent(b.dataset.id||'');
    else if(action==='archive-booking') archiveBooking(b.dataset.id||'');
    else if(action==='save-daily') saveDailySchedule(b.dataset.date||'');
    else if(action==='save-operation') saveOperation();
    else if(action==='save-expense') saveExpense();
  }catch(err){
    console.error('modal action error',err);
    alert('حدث خطأ أثناء تنفيذ العملية.');
  }finally{
    setTimeout(()=>{
      modalActionBusy=false;
      if(document.body.contains(b)){
        b.disabled=false;
        b.textContent=oldText;
      }
    },250);
  }
});

// أزرار الجداول الديناميكية.
document.addEventListener('click',e=>{
  const btn=e.target.closest('[data-action]');
  if(!btn)return;
  e.preventDefault();
  e.stopPropagation();
  const id=btn.dataset.id||'';
  const action=btn.dataset.action||'';
  if(action==='add') openBookingModal('', '', btn.dataset.period||'', btn.dataset.time||'');
  else if(action==='edit') openBookingModal(id);
  else if(action==='move') openMoveModal(id);
  else if(action==='receipt') receipt(id);
  else if(action==='delete') deleteBookingPermanent(id);
  else if(action==='share') shareReceipt(id);
  else if(action==='archive') archiveBooking(id);
});

function showPage(p){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));const page=$("page-"+p),tab=document.querySelector(`[data-page="${p}"]`);if(!page)return;page.classList.add("active");tab?.classList.add("active");try{syncAttendanceRecords();}catch(e){console.error("sync page",e)}try{if(p==="bookings"){renderBookings();renderWaitlist();}else{renderAll();}if(p==="attendance")renderAttendance();}catch(e){console.error("render page",e);if(p==="bookings"){try{renderBookings()}catch(_){}}}}
function calcRatePreview(){const a=+$('examCount').value||0,b=+$('examRate').value||0,c=+$('consultCount').value||0,d=+$('consultRate').value||0;$('examTotal').value=a*b;$('consultTotal').value=c*d;$('dayRateTotal').value=a*b+c*d}
let editingRateId='';
function loadRateForDate(){
  const date=$('rateDate')?.value||today(), r=state.rates.find(x=>x.date===date);
  editingRateId=r?.id||'';
  $('examCount').value=r?.examCount??0; $('examRate').value=r?.examRate??state.settings.examPrice??0;
  $('consultCount').value=r?.consultCount??0; $('consultRate').value=r?.consultRate??state.settings.consultPrice??0;
  calcRatePreview();
  const btn=document.querySelector('#page-rates button.primary'); if(btn)btn.textContent=r?'تعديل وحفظ حساب اليوم':'حفظ حساب اليوم';
}
function editRate(id){
  const r=state.rates.find(x=>x.id===id); if(!r)return;
  editingRateId=id; $('rateDate').value=r.date; $('examCount').value=r.examCount||0; $('examRate').value=r.examRate||0;
  $('consultCount').value=r.consultCount||0; $('consultRate').value=r.consultRate||0; calcRatePreview();
  const btn=document.querySelector('#page-rates button.primary'); if(btn)btn.textContent='تعديل وحفظ حساب اليوم';
  $('rateDate').scrollIntoView({behavior:'smooth',block:'center'});
}
function saveRateDay(){const date=$('rateDate').value||today();const rec={id:editingRateId||uid(),date,examCount:+$('examCount').value||0,examRate:+$('examRate').value||0,consultCount:+$('consultCount').value||0,consultRate:+$('consultRate').value||0};commit(()=>{const old=state.rates.find(x=>x.id===editingRateId||x.date===date);if(old){Object.assign(old,rec);editingRateId=old.id}else state.rates.push(rec)});const btn=document.querySelector('#page-rates button.primary');if(btn)btn.textContent='حفظ حساب اليوم';renderRates();renderReports();}
function deleteRate(id){if(confirm("حذف حساب هذا اليوم؟"))commit(()=>state.rates=state.rates.filter(x=>x.id!==id))}
function clearRates(){if(confirm("مسح كل حسابات النسب؟"))commit(()=>state.rates=[])}
function renderRates(){const rs=state.rates;const examCount=rs.reduce((s,r)=>s+(+r.examCount||0),0);const consultCount=rs.reduce((s,r)=>s+(+r.consultCount||0),0);const examAmount=rs.reduce((s,r)=>s+(+r.examCount||0)*(+r.examRate||0),0);const consultAmount=rs.reduce((s,r)=>s+(+r.consultCount||0)*(+r.consultRate||0),0);const total=examAmount+consultAmount;const months=new Set(rs.map(r=>String(r.date||'').slice(0,7)).filter(Boolean)).size;$('rateDaysTotal').textContent=rs.length;$('rateMonthsTotal').textContent=months;$('rateExamCountTotal').textContent=examCount;$('rateExamAmountTotal').textContent=money(examAmount);$('rateConsultCountTotal').textContent=consultCount;$('rateConsultAmountTotal').textContent=money(consultAmount);$('rateGrandTotal').textContent=money(total);$('ratesTable').innerHTML=rs.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(r=>`<tr><td>${fmtDate(r.date)}</td><td>${r.examCount} × ${money(r.examRate)}</td><td>${r.consultCount} × ${money(r.consultRate)}</td><td><b>${money(r.examCount*r.examRate+r.consultCount*r.consultRate)}</b></td><td><button class="secondary" onclick="editRate('${r.id}')">تعديل</button> <button class="danger ghost" onclick="deleteRate('${r.id}')">حذف</button></td></tr>`).join("")||`<tr><td colspan="5" class="empty">لا توجد حسابات.</td></tr>`}

function periodHourOptions(selected="",start=null,end=null){const s=start||$("pStart")?.value||"08:00",e=end||$("pEnd")?.value||"12:00";if(!s||!e||timeToMinutes(s)>=rangeEndMinutes(s,e))return `<option value="">اختر الساعة</option>`;const out=[];for(let m=timeToMinutes(s);m<rangeEndMinutes(s,e);m+=60){const h=String(Math.floor(m/60)).padStart(2,"0"),mi=String(m%60).padStart(2,"0"),t=`${h}:${mi}`;out.push(`<option value="${t}" ${t===selected?'selected':''}>${displayTime(t)}</option>`)}return `<option value="">اختر الساعة</option>`+out.join("")}
function refreshSlotRows(slots){const box=$("slotRows");if(!box)return;box.innerHTML=(slots||[]).map(x=>`<div class="slot-edit-row"><select class="slot-time">${periodHourOptions(x.time)}</select><input class="slot-capacity" type="number" min="1" value="${+x.capacity||5}" placeholder="عدد الحالات"><button type="button" class="danger ghost" onclick="this.parentElement.remove()">حذف</button></div>`).join("")}
function addSlotRow(){const box=$("slotRows");if(!box)return;const used=new Set([...box.querySelectorAll('.slot-time')].map(x=>x.value).filter(Boolean));const s=$("pStart")?.value||"08:00",e=$("pEnd")?.value||"12:00";let first="";for(let m=timeToMinutes(s);m<rangeEndMinutes(s,e);m+=60){const t=`${String(Math.floor(m/60)).padStart(2,"0")}:${String(m%60).padStart(2,"0")}`;if(!used.has(t)){first=t;break}}const row=document.createElement("div");row.className="slot-edit-row";row.innerHTML=`<select class="slot-time">${periodHourOptions(first)}</select><input class="slot-capacity" type="number" min="1" value="5" placeholder="عدد الحالات"><button type="button" class="danger ghost" onclick="this.parentElement.remove()">حذف</button>`;box.appendChild(row)}
function refreshPeriodHourChoices(){document.querySelectorAll('#slotRows .slot-time').forEach(sel=>{const v=sel.value;sel.innerHTML=periodHourOptions(v);if([...sel.options].some(o=>o.value===v))sel.value=v;else sel.value=""})}
function openPeriodModal(id=null){const p=id?normalizePeriod(state.periods.find(x=>x.id===id)):null;$('modalTitle').textContent=p?"تعديل الفترة":"إضافة فترة";$('modalBody').innerHTML=`<div class="form-grid"><label>اسم الفترة<input id="pName" value="${esc(p?.name||"فترة صباحية")}"></label><label>من<input id="pStart" type="time" value="${p?.start||"08:00"}"></label><label>إلى<input id="pEnd" type="time" value="${p?.end||"12:00"}"></label><div class="full"><div class="section-title">الساعات وعدد الحالات</div><div class="muted">هذه الفترة هي تعريف أساسي فقط. لتغيير مواعيد يوم محدد استخدم «مواعيد اليوم» حتى لا تتأثر باقي الأيام. ولجعلها تمتد حتى منتصف الليل اختر 12:00 ص في خانة النهاية.</div></div><div id="slotRows" class="full"></div><button class="secondary full" onclick="addSlotRow()">＋ إضافة ساعة</button></div><div class="modal-actions"><button type="button" class="primary" onclick="savePeriodDirect('${id||""}')">حفظ الفترة</button><button type="button" class="ghost" data-modal-action="close">إلغاء</button>${p?`<button class="danger" data-modal-action="delete-period" data-id="${p.id}">حذف</button>`:""}</div>`;$('modal').classList.remove('hidden');refreshSlotRows(p?.slots||[{time:"08:00",capacity:5},{time:"09:00",capacity:5},{time:"10:00",capacity:5},{time:"11:00",capacity:5}]);$('pStart').onchange=refreshPeriodHourChoices;$('pEnd').onchange=refreshPeriodHourChoices}
function savePeriodDirect(id){
  try{
    savePeriod(id||'');
  }catch(err){
    console.error(err);
    alert('تعذر حفظ الفترة. حاول مرة أخرى.');
  }
}
function savePeriod(id){const name=$('pName').value.trim()||"فترة",start=$('pStart').value,end=$('pEnd').value,slots=[...document.querySelectorAll('#slotRows .slot-edit-row')].map(r=>({time:r.querySelector('.slot-time').value,capacity:Math.max(1,+r.querySelector('.slot-capacity').value||1)})).filter(x=>x.time);slots.sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time));if(!start||!end||!slots.length){alert("أدخل بيانات الفترة وأضف ساعة واحدة على الأقل.");return}if(timeToMinutes(start)>=rangeEndMinutes(start,end)){alert("وقت البداية يجب أن يكون قبل وقت النهاية. إذا أردت حتى منتصف الليل اختر 12:00 ص.");return}const seen=new Set();for(const x of slots){if(timeToMinutes(x.time)<timeToMinutes(start)||timeToMinutes(x.time)>=rangeEndMinutes(start,end)){alert("كل ساعة يجب أن تكون داخل الفترة المحددة من وإلى.");return}if(seen.has(x.time)){alert("لا يمكن تكرار نفس الساعة.");return}seen.add(x.time)}commit(()=>{const existing=id?state.periods.find(x=>x.id===id):null;
  const oldDaily=existing?.daily||{};
  const obj={id:id||uid(),name,start,end,slots,daily:oldDaily};
  const activeDate=$('bookingDate')?.value||today();
  if(existing){
    Object.assign(existing,obj);
    initDailyPeriod(existing);
    // لا نغيّر أي يوم تم ضبطه يدويًا. إذا كان اليوم الحالي لم يُضبط بعد،
    // نجهزه تلقائيًا من ساعات الفترة حتى تظهر الساعات فورًا في الحجز.
    if(!existing.daily[dayKey(activeDate)]){
      existing.daily[dayKey(activeDate)]={enabled:true,start,end,slots:slots.map(x=>({time:x.time,capacity:x.capacity}))};
    }
  }else{
    initDailyPeriod(obj);
    state.periods.push(obj);
    // عند إضافة فترة جديدة، نفعّلها لليوم الحالي فقط. باقي الأيام تظل مستقلة ومغلقة
    // حتى يحدد المستخدم مواعيدها من زر «مواعيد اليوم».
    obj.daily[dayKey(activeDate)]={enabled:true,start,end,slots:slots.map(x=>({time:x.time,capacity:x.capacity}))};
  }
});
  try{localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));}catch(e){}
  closeModal();
  try{renderBookings();renderAttendance();renderHourlyAttendance();}catch(e){}
  try{renderAll();}catch(e){}
}

function refreshListAfterSave(targetId){
  try{renderAll()}catch(err){console.error('refresh after save',err)}
  setTimeout(()=>{const el=$(targetId);if(el)el.scrollIntoView({behavior:'smooth',block:'start'})},30);
}

function deletePeriod(id){
  id=String(id||'').trim();
  if(!id)return;
  const exists=state.periods.some(x=>String(x.id)===id);
  if(!exists)return;
  snapshot();
  state.periods=state.periods.filter(x=>String(x.id)!==id);
  localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));
  closeModal();
  renderAll();
}

function dayKey(date){return String(date||'').trim()}
function initDailyPeriod(p){
  if(!p.daily)p.daily={};
  return p;
}
state.periods.forEach(initDailyPeriod);
// كل تاريخ له إعداد مستقل تمامًا. لا نرث ساعات أو سعة من يوم آخر.
// للحفاظ على الفترات القديمة بعد التحديث، نُنشئ إعداد اليوم الحالي فقط إذا كانت
// الفترة قديمة ولم يكن لها أي إعداد يومي سابق.
(function migrateDailySchedules(){
  const d=today();
  state.periods.forEach(p=>{
    normalizePeriod(p);
    initDailyPeriod(p);
    if(Object.keys(p.daily).length===0 && p.slots?.length){
      p.daily[d]={enabled:true,start:p.start,end:p.end,slots:p.slots.map(x=>({time:x.time,capacity:+x.capacity||5}))};
    }
  });
  try{localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));}catch(e){}
})();
function getDayConfig(p,date){
  initDailyPeriod(p);
  const k=dayKey(date);
  if(p.daily[k])return p.daily[k];
  // يوم غير مُعدّ = مغلق، ولا يأخذ إعدادات الفترة الأساسية تلقائيًا.
  // يجب تحديد مواعيد هذا التاريخ صراحةً من «مواعيد اليوم».
  return {enabled:false,start:p.start,end:p.end,slots:[]};
}
function getDaySlots(p,date){
  const c=getDayConfig(p,date);
  return c&&c.enabled?(c.slots||[]):[];
}
function getDayPeriodTimes(p,date){
  const c=getDayConfig(p,date); return c||{start:p.start,end:p.end,slots:[]};
}
function dailyHourRowsHtml(pid,slots){
  return (slots||[]).map(s=>`<div class="daily-slot-row" data-time="${esc(s.time)}"><div class="daily-slot-time">${displayTime(s.time)}</div><div class="daily-slot-capacity"><span>عدد الحالات</span><div class="capacity-control"><button type="button" class="capacity-step" onclick="stepDailyCapacity('${pid}','${s.time}',-1)" aria-label="تقليل">−</button><input type="number" min="1" max="99" class="daily-capacity-input" data-pid="${pid}" data-time="${esc(s.time)}" value="${Math.max(1,+s.capacity||5)}"><button type="button" class="capacity-step" onclick="stepDailyCapacity('${pid}','${s.time}',1)" aria-label="زيادة">+</button></div></div></div>`).join('') || '<div class="empty">حدد وقت البداية والنهاية لعرض الساعات.</div>';
}
function makeDailySlots(start,end,oldSlots=[]){
  if(!start||!end||timeToMinutes(start)>=rangeEndMinutes(start,end))return [];
  const old=new Map((oldSlots||[]).map(s=>[s.time,Math.max(1,+s.capacity||5)])); const out=[];
  for(let m=timeToMinutes(start);m<rangeEndMinutes(start,end);m+=60){const time=`${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;out.push({time,capacity:old.get(time)||5});}
  return out;
}
function refreshDailySlotRows(pid){
  const card=document.querySelector(`.weekly-day[data-pid="${pid}"]`);if(!card)return;
  const start=card.querySelector('.daily-start')?.value||'08:00',end=card.querySelector('.daily-end')?.value||'12:00';
  const existing=[...card.querySelectorAll('.daily-capacity-input')].map(i=>({time:i.dataset.time,capacity:+i.value||5}));
  const box=card.querySelector('.daily-slot-rows');if(box)box.innerHTML=dailyHourRowsHtml(pid,makeDailySlots(start,end,existing));
}
function stepDailyCapacity(pid,time,delta){const input=document.querySelector(`.daily-capacity-input[data-pid="${pid}"][data-time="${time}"]`);if(input)input.value=Math.max(1,Math.min(99,(+input.value||5)+delta));}
function openDailyScheduleModal(){
  const date=$('bookingDate')?.value||today(); const dateLabel=fmtDate(date);
  const sections=state.periods.length?state.periods.map(p=>{
    const c=getDayConfig(p,date);const start=c.start||p.start||'08:00',end=c.end||p.end||'12:00';
    const slots=makeDailySlots(start,end,c.slots||[]);
    return `<div class="weekly-day" data-pid="${p.id}"><div class="weekly-day-head"><strong>${esc(p.name)}</strong><span class="muted">مواعيد هذا اليوم فقط</span></div><label class="daily-open-label"><input type="checkbox" class="daily-period-open" data-pid="${p.id}" ${c.enabled?'checked':''}> الفترة مفتوحة اليوم</label><div class="daily-time-range"><label>من<input type="time" class="daily-start" data-pid="${p.id}" value="${esc(start)}"></label><label>إلى<input type="time" class="daily-end" data-pid="${p.id}" value="${esc(end)}"></label></div><div class="daily-slots-heading"><strong>عدد الحالات لكل ساعة</strong><span class="muted small">غيّر العدد من + و− أو اكتب الرقم مباشرة</span></div><div class="daily-slot-rows">${dailyHourRowsHtml(p.id,slots)}</div><div class="muted small">تُنشأ الساعات تلقائيًا حسب البداية والنهاية، وتظل إعدادات هذا اليوم مستقلة عن باقي الأيام.</div></div>`;
  }).join(''):`<div class="empty">أضف فترة أولًا.</div>`;
  $('modalTitle').textContent=`مواعيد يوم ${dateLabel}`;
  $('modalBody').innerHTML=`<div class="muted daily-modal-intro">حدد مواعيد يوم <b>${dateLabel}</b> فقط. التعديل هنا لا يغيّر أي يوم آخر.</div>${sections}<div class="modal-actions"><button class="primary" data-modal-action="save-daily" data-date="${date}">حفظ مواعيد هذا اليوم فقط</button><button type="button" class="ghost" data-modal-action="close">إلغاء</button></div>`;
  $('modal').classList.remove('hidden');
  document.querySelectorAll('.daily-start,.daily-end').forEach(el=>el.addEventListener('change',()=>refreshDailySlotRows(el.dataset.pid)));
}
function saveDailySchedule(date){
  const bad=[];const changes={};
  state.periods.forEach(p=>{
    const card=document.querySelector(`.weekly-day[data-pid="${p.id}"]`);const enabled=!!card?.querySelector('.daily-period-open')?.checked;
    const start=card?.querySelector('.daily-start')?.value||p.start||'08:00';const end=card?.querySelector('.daily-end')?.value||p.end||'12:00';
    if(timeToMinutes(start)>=rangeEndMinutes(start,end))bad.push(`${p.name}: وقت البداية يجب أن يكون قبل النهاية (ويمكن اختيار 12:00 ص كمنتصف الليل)`);
    const slots=[...(card?.querySelectorAll('.daily-capacity-input')||[])].map(i=>({time:i.dataset.time,capacity:Math.max(1,Math.min(99,parseInt(i.value,10)||5))}));
    if(enabled&&!slots.length)bad.push(`${p.name}: لا توجد ساعات داخل الفترة`);
    changes[p.id]={enabled,start,end,slots};
  });
  if(bad.length){alert('راجع مواعيد اليوم:\n'+bad.slice(0,12).join('\n'));return;}
  commit(()=>{state.periods.forEach(p=>{initDailyPeriod(p);p.daily[dayKey(date)]=changes[p.id];});});
  closeModal();renderBookings();renderAttendance();renderHourlyAttendance();
}

function isDateOpen(date){
  return state.periods.some(p=>getDaySlots(p,date).length);
}
function periodBookings(date,pid,time){return state.bookings.filter(b=>!b.archived&&b.date===date&&b.periodId===pid&&b.time===time&&b.status!=="canceled")}
function getSlot(p,time,date){return getDaySlots(p,date||today()).find(x=>x.time===time)}
function renderPeriods(){
  const d=$('bookingDate').value||today();
  const q=($('bookingSearch')?.value||'').trim().toLowerCase();
  const type=$('bookingTypeFilter')?.value||'';
  const status=$('bookingStatusFilter')?.value||'';
  const bookingSerialMap=bookingSerials(d);
  const serial=b=>bookingSerialMap.get(b.id)||'—';
  const actionButtons=b=>`<div class="small-actions"><button type="button" class="secondary" data-action="edit" data-id="${b.id}">تعديل</button><button type="button" class="secondary" data-action="whatsapp" data-id="${b.id}">💬 واتساب</button><button type="button" class="ghost" data-action="move" data-id="${b.id}">نقل</button><button type="button" class="ghost" data-action="receipt" data-id="${b.id}">إيصال</button><button type="button" class="ghost" data-action="share" data-id="${b.id}">مشاركة</button><button type="button" class="danger ghost" data-action="delete" data-id="${b.id}">حذف</button></div>`;
  const statusClass=b=>b.status==='attended'?'row-attended':b.status==='noshow'?'row-noshow':b.status==='canceled'?'row-canceled':'';
  const renderedIds=new Set();
  $('periodsList').innerHTML=state.periods.filter(p=>getDaySlots(p,d).length).map(p=>{
    normalizePeriod(p);
    const daySlots=getDaySlots(p,d); const hourSections=daySlots.map(slot=>{
      const all=state.bookings.filter(b=>!b.archived&&b.date===d&&b.periodId===p.id&&b.time===slot.time).slice().sort((a,b)=>a.createdAt-b.createdAt);
      all.forEach(b=>renderedIds.add(b.id));
      const rows=all.filter(b=>(!q||String(b.name||'').toLowerCase().includes(q)||String(b.phone||'').includes(q))&&(!type||b.type===type)&&(!status||b.status===status));
      const cap=+slot.capacity||0, left=Math.max(0,cap-all.length);
      const stateClass=all.length>=cap?'hour-full':all.length?'hour-busy':'hour-empty';
      const body=rows.map(b=>`<tr class="${statusClass(b)}"><td>${serial(b)}</td><td><strong>${esc(b.name)}</strong></td><td>${esc(b.phone)}</td><td class="booking-timestamp">${displayDateTime(b.bookingAt||b.createdAt)}</td><td>${typeName(b.type)}</td><td>${money(effectiveAmount(b))}</td><td>${statusBadge(b.status)}</td><td>${b.paid==='no'?'لم يدفع':b.paid==='paid'?'تم الدفع':'مجاني'}</td><td>${actionButtons(b)}</td></tr>`).join('') || `<tr><td colspan="9" class="empty">لا توجد حالات في الساعة ${displayTime(slot.time)}</td></tr>`;
      return `<section class="hour-table-section ${stateClass}">
        <div class="hour-table-head"><div><span class="hour-label">الساعة</span><h4>${displayTime(slot.time)}</h4></div><div class="hour-capacity-table"><b>${all.length} / ${cap}</b><span>${all.length>=cap?'ممتلئة':`متاح ${left} حالة`}</span></div><button class="primary" ${all.length>=cap?'disabled':''} data-action="add" data-period="${p.id}" data-time="${slot.time}">＋ إضافة مريض</button></div>
        <div class="table-wrap hour-table-wrap"><table class="separated-hour-table"><thead><tr><th>م</th><th>اسم المريض</th><th>رقم الهاتف</th><th>وقت الحجز</th><th>النوع</th><th>المبلغ</th><th>الحالة</th><th>الدفع</th><th>الإجراءات</th></tr></thead><tbody>${body}</tbody></table></div>
      </section>`;
    }).join('');
    return `<section class="booking-period-section"><div class="booking-period-head"><div><span class="period-label">فترة العمل</span><h3>${esc(p.name)}</h3><p>${displayTime(getDayPeriodTimes(p,d).start||p.start)} → ${displayTime(getDayPeriodTimes(p,d).end||p.end)} · ${getDaySlots(p,d).length} ساعات اليوم</p></div><div class="small-actions"><button class="secondary" onclick="openDailyScheduleModal()">تعديل مواعيد اليوم</button><button class="danger ghost" onclick="deletePeriod('${p.id}')">حذف</button></div></div><div class="booking-hours-stack">${hourSections||'<div class="empty">لا توجد ساعات مضافة لهذه الفترة.</div>'}</div></section>`;
  }).join('');
  // Safety net: never hide a saved booking from the bookings page, even if its period/hour was later edited or removed.
  const orphaned=state.bookings.filter(b=>!b.archived&&b.date===d&&!renderedIds.has(b.id));
  if(orphaned.length){
    const filtered=orphaned.filter(b=>(!q||String(b.name||'').toLowerCase().includes(q)||String(b.phone||'').includes(q))&&(!type||b.type===type)&&(!status||b.status===status));
    const body=filtered.map(b=>`<tr class="${statusClass(b)}"><td>${serial(b)}</td><td><strong>${esc(b.name)}</strong></td><td>${esc(b.phone)}</td><td class="booking-timestamp">${displayDateTime(b.bookingAt||b.createdAt)}</td><td>${typeName(b.type)}</td><td>${money(effectiveAmount(b))}</td><td>${statusBadge(b.status)}</td><td>${b.paid==='no'?'لم يدفع':b.paid==='paid'?'تم الدفع':'مجاني'}</td><td>${actionButtons(b)}</td></tr>`).join('')||`<tr><td colspan="9" class="empty">لا توجد حالات مطابقة للفلاتر.</td></tr>`;
    $('periodsList').insertAdjacentHTML('beforeend',`<section class="booking-period-section orphan-bookings-section"><div class="booking-period-head"><div><span class="period-label">حجوزات محفوظة</span><h3>حجوزات غير مرتبطة بساعة حالية</h3><p>هذه الحجوزات محفوظة ولن تختفي من سجل الحجوزات.</p></div></div><div class="table-wrap hour-table-wrap"><table class="separated-hour-table"><thead><tr><th>م</th><th>اسم المريض</th><th>رقم الهاتف</th><th>وقت الحجز</th><th>النوع</th><th>المبلغ</th><th>الحالة</th><th>الدفع</th><th>الإجراءات</th></tr></thead><tbody>${body}</tbody></table></div></section>`);
  }
  if(!$('periodsList').innerHTML.trim()) $('periodsList').innerHTML=`<div class="empty">لا توجد فترات. ابدأ بإضافة فترة.</div>`;
}
function updateBookingAmount(){const t=$('bType')?.value;if($('bAmount'))$('bAmount').value=getPriceForType(t);if($('bDiscount'))$('bFinal').textContent=money(Math.max(0,getPriceForType(t)- (+$('bDiscount').value||0)))}
function refreshBookingPeriodOptions(){
  const sel=$("bPeriod"), date=$("bDate")?.value||today();
  if(!sel)return;
  const current=sel.value;
  const options=state.periods.filter(p=>getDaySlots(p,date).length||p.id===current);
  sel.innerHTML='<option value="">'+(options.length?'اختر الفترة':'لا توجد فترة مفتوحة لهذا اليوم')+'</option>'+options.map(p=>`<option value="${p.id}" ${p.id===current?'selected':''}>${esc(p.name)}</option>`).join('');
}
function refreshBookingTimes(preselect=""){const p=state.periods.find(x=>x.id==$('bPeriod')?.value),sel=$('bTime');if(!sel)return;if(!p){sel.innerHTML='<option value="">اختر الفترة أولًا</option>';return}normalizePeriod(p);const date=$('bDate').value||today();let daySlots=getDaySlots(p,date);
  // لا نُنشئ إعدادًا لليوم تلقائيًا. كل يوم مستقل، وإذا لم يتم ضبطه
  // صراحةً من «مواعيد اليوم» يبقى مغلقًا ولا يرث ساعات يوم آخر.
  if(!daySlots.length){sel.innerHTML='<option value="">هذا اليوم مغلق أو لا توجد ساعات</option>';return}
  sel.innerHTML=daySlots.map(slot=>{const n=periodBookings(date,p.id,slot.time).filter(x=>x.id!==window.editingBookingId).length;return `<option value="${slot.time}" ${slot.time===preselect?'selected':''} ${n>=slot.capacity?'disabled':''}>${displayTime(slot.time)} — ${n}/${slot.capacity}</option>`}).join('')}
function duplicateCheck(phone,date,id){return state.bookings.filter(x=>!x.archived&&x.phone&&phone&&x.phone===phone&&x.date===date&&x.id!==id&&x.status!=="canceled")}
function previousMissedBookings(phone,id){return state.bookings.filter(x=>!x.archived&&x.phone&&phone&&x.phone===phone&&x.id!==id&&(x.status==="noshow"||x.status==="canceled")).sort((a,b)=>b.date.localeCompare(a.date)||b.time.localeCompare(a.time))}
function latestAvailableSlotOnDate(date,excludeId){
  const candidates=[];
  state.periods.forEach(p=>{normalizePeriod(p);getDaySlots(p,date).forEach(slot=>{
    const used=periodBookings(date,p.id,slot.time).filter(x=>x.id!==excludeId).length;
    if(used<slot.capacity)candidates.push({date,periodId:p.id,time:slot.time});
  })});
  candidates.sort((a,b)=>timeToMinutes(b.time)-timeToMinutes(a.time));
  return candidates[0]||null;
}
function autoRebookSlot(excludeId){
  const t=today();
  return latestAvailableSlotOnDate(t,excludeId)||latestAvailableSlotOnDate(dateAfterDays(1),excludeId);
}

function openBookingModal(id="",unused="",pid="",time=""){const b=id?state.bookings.find(x=>x.id===id):null,date=b?.date||$('bookingDate').value||today(),periodId=b?.periodId||pid,tm=b?.time||time;window.editingBookingId=id||"";$('modalTitle').textContent=b?"تعديل الحالة":"تسجيل حالة جديدة";const availablePeriods=state.periods.filter(p=>getDaySlots(p,date).length||p.id===periodId);const periods=availablePeriods.map(p=>`<option value="${p.id}" ${p.id===periodId?'selected':''}>${esc(p.name)}</option>`).join('');$('modalBody').innerHTML=`<div class="form-grid"><label>يوم الحجز<input id="bDate" type="date" value="${date}" onchange="refreshBookingPeriodOptions();refreshBookingTimes()"></label><label>الفترة<select id="bPeriod" onchange="refreshBookingTimes()"><option value="">${periods?'اختر الفترة':'لا توجد فترة مفتوحة لهذا اليوم'}</option>${periods}</select></label><label>الساعة<select id="bTime"></select></label><label>الاسم<div class="patient-name-entry"><input id="bName" value="${esc(b?.name||"")}" autocomplete="off" placeholder="اكتب اسم المريض"><button type="button" class="secondary small" onclick="findExistingPatient()">بحث عن مريض سابق</button></div></label><label>رقم التليفون<input id="bPhone" type="tel" inputmode="tel" value="${esc(b?.phone||"")}" oninput="bookingDuplicateHint()"><span id="duplicateHint" class="hint"></span></label><label>النوع<select id="bType" onchange="updateBookingAmount()">${['exam','consult','free_exam','free_consult'].map(t=>`<option value="${t}" ${(b?.type||'exam')===t?'selected':''}>${typeName(t)}</option>`).join('')}</select></label><label>المبلغ<input id="bAmount" type="number" readonly></label><label>الخصم<input id="bDiscount" type="number" min="0" value="${+b?.discount||0}" oninput="updateBookingAmount()"></label><label>الصافي<div id="bFinal" class="amount-box"></div></label><label>حالة الحجز<select id="bStatus">${[['booked','محجوز'],['confirmed','مؤكد'],['canceled','ألغى']].map(x=>`<option value="${x[0]}" ${(b?.status||'booked')===x[0]?'selected':''}>${x[1]}</option>`).join('')}</select></label><label>الدفع<select id="bPaid"><option value="no" ${(b?.paid||'no')==='no'?'selected':''}>لم يدفع</option><option value="paid" ${b?.paid==='paid'||b?.paid==='cash'||b?.paid==='transfer'||b?.paid==='card'?'selected':''}>تم الدفع</option><option value="free" ${b?.paid==='free'?'selected':''}>مجاني</option></select></label><label class="full">سبب الإلغاء (اختياري)<input id="bCancelReason" value="${esc(b?.cancelReason||"")}"></label><label class="full">ملاحظات<textarea id="bNotes">${esc(b?.notes||"")}</textarea></label>${b?.history?.length?`<div class="full history"><div class="section-title">سجل نقل الموعد</div>${b.history.slice().reverse().map(h=>`<div class="history-row">${fmtDate(h.from.date)} ${displayTime(h.from.time)} ← ${fmtDate(h.to.date)} ${displayTime(h.to.time)}</div>`).join('')}</div>`:''}</div><div class="modal-actions"><button type="button" id="saveBookingBtn" class="primary" data-modal-action="save-booking" data-id="${id}">حفظ الحالة</button><button type="button" class="ghost" data-modal-action="close">إلغاء</button>${b?`<button type="button" class="danger" data-modal-action="delete-booking" data-id="${b.id}">حذف الحالة</button><button type="button" class="secondary" data-modal-action="archive-booking" data-id="${b.id}">أرشفة</button><button class="secondary" data-action="move" data-id="${b.id}">نقل الموعد</button><button class="secondary" data-action="receipt" data-id="${b.id}">إيصال</button>`:''}</div>`;$('modal').classList.remove('hidden');refreshBookingPeriodOptions();if(periodId&&$('bPeriod').querySelector(`option[value=\"${periodId}\"]`))$('bPeriod').value=periodId;refreshBookingTimes(tm);updateBookingAmount();bookingDuplicateHint()}
function bookingDuplicateHint(){const el=$('duplicateHint');if(!el)return;const phone=$('bPhone').value.trim(),date=$('bDate').value,a=duplicateCheck(phone,date,window.editingBookingId),prev=previousMissedBookings(phone,window.editingBookingId);let msg=a.length?`⚠️ للمريض حجز آخر اليوم (${displayTime(a[0].time)})`:'';if(prev.length)msg+=(msg?' — ':'')+`⚠️ لديه حجز سابق لم يحضر/ألغاه (${fmtDate(prev[0].date)})`;el.textContent=msg}
async function whatsappBookingSync(booking, oldBooking){
  const url=(state.settings?.waServerUrl||'').trim().replace(/\/$/,'');
  if(!state.settings?.waEnabled || !url || !booking?.phone)return;
  try{
    const res=await fetch(url+'/api/bookings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({booking:{...booking,periodName:(state.periods.find(p=>p.id===booking.periodId)?.name||'')},oldBooking,clinicName:state.settings.clinicName})});
    if(!res.ok)console.warn('WhatsApp server error',await res.text());
  }catch(e){console.warn('WhatsApp sync unavailable',e)}
}
async function sendWhatsAppNow(id){
  const b=state.bookings.find(x=>x.id===id); if(!b)return;
  if(!b.phone){alert('لا يوجد رقم هاتف للمريض.');return;}
  const url=(state.settings?.waServerUrl||'').trim().replace(/\/$/,'');
  if(!state.settings?.waEnabled||!url){alert('فعّل واتساب وأدخل عنوان خادم واتساب من الإعدادات أولًا.');return;}
  try{const p=state.periods.find(x=>x.id===b.periodId);const res=await fetch(url+'/api/send-confirmation',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({booking:{...b,periodName:p?.name||''},clinicName:state.settings.clinicName})});const data=await res.json().catch(()=>({}));if(!res.ok||data.ok===false)throw new Error(data.error||'تعذر إرسال الرسالة');alert(data.dryRun?'تم تجهيز رسالة واتساب (وضع التجربة).':'تم إرسال تأكيد الحجز عبر واتساب.');}catch(e){alert('تعذر إرسال واتساب: '+(e?.message||e));}
}


function saveBooking(id){let date=$('bDate').value,periodId=$('bPeriod').value,time=$('bTime').value,name=$('bName').value.trim(),phone=$('bPhone').value.trim(),type=$('bType').value,status=$('bStatus').value,paid=$('bPaid').value,discount=Math.max(0,+$('bDiscount').value||0),notes=$('bNotes').value.trim(),cancelReason=$('bCancelReason').value.trim();if(!date||!periodId||!time||!name){alert('أكمل التاريخ والفترة والساعة والاسم.');return}const p=state.periods.find(x=>x.id===periodId);if(!p){alert('الفترة غير موجودة.');return}normalizePeriod(p);const old=id?state.bookings.find(x=>x.id===id):null;const slot=getSlot(p,time,date);if(!slot&&!(old&&old.date===date&&old.periodId===periodId&&old.time===time)){alert('الساعة غير مسجلة داخل الفترة.');return}const count=periodBookings(date,periodId,time).filter(x=>x.id!==id).length;if(slot && status!=="canceled"&&count>=slot.capacity){alert('هذه الساعة مكتملة حسب السعة المحددة.');return}const normalizedPaid=(paid==='cash'||paid==='transfer'||paid==='card')?'paid':paid;
  const bookingNo=old?.bookingNo||1; // يُعاد ترتيبه تلقائيًا حسب وقت إنشاء الحجز داخل نفس الفترة
  const dup=duplicateCheck(phone,date,id);
  if(dup.length&&!confirm(`تنبيه: ${name} لديه حجز آخر اليوم الساعة ${displayTime(dup[0].time)}. هل تريد المتابعة؟`))return;
  if(!id){
    const previous=previousMissedBookings(phone,id);
    if(previous.length){
      const last=previous[0];
      const next=autoRebookSlot(id);
      const reason=last.status==='noshow'?'لم يحضر':'ألغى الحجز';
      if(next){
        alert(`⚠️ تنبيه: المريض ${name} سبق له الحجز بتاريخ ${fmtDate(last.date)} الساعة ${displayTime(last.time)} لكنه ${reason}.\n\nسيتم تحويل الحجز تلقائيًا إلى آخر ميعاد متاح في العيادة اليوم، وإذا لم يوجد مكان اليوم فإلى آخر ميعاد متاح غدًا.\n\nالموعد الجديد: ${fmtDate(next.date)} — ${displayTime(next.time)}`);
        date=next.date;periodId=next.periodId;time=next.time;
        $('bDate').value=date;$('bPeriod').value=periodId;refreshBookingTimes(time);$('bTime').value=time;
      }else{
        alert(`⚠️ تنبيه: المريض ${name} سبق له الحجز بتاريخ ${fmtDate(last.date)} لكنه ${reason}، ولا يوجد مكان متاح اليوم أو غدًا.`);
      }
    }
  }
  const p2=state.periods.find(x=>x.id===periodId);if(!p2){alert('الفترة غير موجودة.');return}normalizePeriod(p2);const slot2=getSlot(p2,time,date);
  if(!slot2&&!(old&&old.date===date&&old.periodId===periodId&&old.time===time)){alert('الساعة غير مسجلة داخل الفترة.');return}
  const count2=periodBookings(date,periodId,time).filter(x=>x.id!==id).length;
  if(slot2 && status!=="canceled"&&count2>=slot2.capacity){alert('هذه الساعة مكتملة حسب السعة المحددة.');return}
  // أغلق نافذة الحجز بعد نجاح التحقق وقبل إعادة الرسم؛ هذا يمنع بقاء المودال عالقًا في WebView ويجعل زر الحفظ/التعديل يعمل فورًا.
  const attendanceStatus = old ? (old.attendanceStatus || 'pending') : 'pending';
  const obj={id:id||uid(),date,periodId,time,name,phone,type,status,paid:normalizedPaid,amount:normalizedPaid==='free'?0:getPriceForType(type),discount,notes,cancelReason,history:old?.history||[],bookingNo,attendanceStatus,attendanceNo:old?.attendanceNo||null,createdAt:old?.createdAt||Date.now(),bookingAt:old?.bookingAt||Date.now(),attendedAt:old?.attendedAt||null,examEnteredAt:old?.examEnteredAt||null,archived:false};
  if(old&&(old.date!==date||old.time!==time||old.periodId!==periodId))obj.history.push({at:Date.now(),from:{date:old.date,periodId:old.periodId,time:old.time},to:{date,periodId,time}});
  // حفظ البيانات أولاً، ثم إغلاق نافذة الحجز فورًا قبل أي إعادة رسم.
  // هذا مهم خصوصًا داخل Android WebView حتى لا تبقى النافذة ظاهرة بعد ظهور رسالة الحفظ.
  snapshot();
  if(id&&old)Object.assign(old,obj);else state.bookings.push(obj);
  try{
    syncAttendanceRecords();
    localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));
  }catch(err){
    console.error('booking save error',err);
    localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));
  }
  $('bookingDate').value=date;
  $('attendanceDate').value=date;
  closeModal();
  // إعادة الرسم بعد إغلاق النافذة مباشرة، وليس قبلها.
    whatsappBookingSync(obj,old);
requestAnimationFrame(()=>{
    try{renderBookings();renderAttendance();renderHourlyAttendance();renderDashboard();renderReports();}
    catch(err){console.error('booking render error',err);}
  });
}
function archiveBooking(id){if(confirm('أرشفة الحالة بدل حذفها نهائيًا؟')){commit(()=>{const b=state.bookings.find(x=>x.id===id);if(b)b.archived=true});closeModal()}}
function restoreBooking(id){commit(()=>{const b=state.bookings.find(x=>x.id===id);if(b)b.archived=false})}
function deleteBookingPermanent(id){
  id=String(id||'').trim();
  if(!id)return;
  const exists=state.bookings.some(x=>String(x.id)===id);
  if(!exists)return;
  snapshot();
  state.bookings=state.bookings.filter(x=>String(x.id)!==id);
  localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));
  closeModal();
  renderAll();
}
function openMoveModal(id){const b=state.bookings.find(x=>x.id===id);if(!b)return;$('modalTitle').textContent='نقل الموعد';$('modalBody').innerHTML=`<div class="form-grid"><label>اليوم الجديد<input id="mDate" type="date" value="${b.date}"></label><label>الفترة<select id="mPeriod">${state.periods.map(p=>`<option value="${p.id}" ${p.id===b.periodId?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label><label class="full">الساعة<select id="mTime"></select></label></div><div class="modal-actions"><button class="primary" onclick="saveMove('${id}')">تأكيد النقل</button><button type="button" class="ghost" data-modal-action="close">إلغاء</button></div>`;$('modal').classList.remove('hidden');refreshMoveTimes(b.time);$('mDate').onchange=()=>refreshMoveTimes('');$('mPeriod').onchange=()=>refreshMoveTimes('')}
function refreshMoveTimes(pre){const p=state.periods.find(x=>x.id==$('mPeriod')?.value),sel=$('mTime');if(!p||!sel)return;const d=$('mDate').value;normalizePeriod(p);sel.innerHTML=getDaySlots(p,d).map(x=>{const n=periodBookings(d,p.id,x.time).filter(b=>b.id!==window.editingBookingId).length;return `<option value="${x.time}" ${x.time===pre?'selected':''} ${n>=x.capacity?'disabled':''}>${displayTime(x.time)} — ${n}/${x.capacity}</option>`}).join('')||'<option value="">لا توجد ساعات لهذا اليوم</option>'}
function saveMove(id){const b=state.bookings.find(x=>x.id===id),date=$('mDate').value,pid=$('mPeriod').value,time=$('mTime').value,p=state.periods.find(x=>x.id===pid),slot=getSlot(p,time,date);if(!b||!date||!pid||!time||!slot){alert('أكمل بيانات النقل.');return}if(periodBookings(date,pid,time).filter(x=>x.id!==id).length>=slot.capacity){alert('الساعة الجديدة مكتملة.');return}commit(()=>{b.history=b.history||[];b.history.push({at:Date.now(),from:{date:b.date,periodId:b.periodId,time:b.time},to:{date,periodId:pid,time}});b.date=date;b.periodId=pid;b.time=time});$('bookingDate').value=date;$('attendanceDate').value=date;closeModal();renderBookings();renderAttendance();renderHourlyAttendance();}
function serialKey(b){return `${b.date}__${b.periodId||''}`}
function bookingSerials(date){
  // مسلسل واحد متصل لكل اليوم عبر كل الساعات والفترات، حسب الساعة ثم وقت التسجيل.
  const rows=state.bookings.filter(b=>!b.archived&&b.date===date).slice().sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time)||(a.bookingAt||a.createdAt||0)-(b.bookingAt||b.createdAt||0)||String(a.id).localeCompare(String(b.id)));
  const map=new Map();rows.forEach((b,i)=>map.set(b.id,i+1));return map;
}
function syncBookingSerials(){
  if(!Array.isArray(state.bookings))return;
  const dates=[...new Set(state.bookings.filter(b=>!b.archived).map(b=>b.date))];
  dates.forEach(date=>{const rows=state.bookings.filter(b=>!b.archived&&b.date===date).slice().sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time)||(a.bookingAt||a.createdAt||0)-(b.bookingAt||b.createdAt||0)||String(a.id).localeCompare(String(b.id)));rows.forEach((b,i)=>{b.bookingNo=i+1;});});
}
function attendanceSerials(date){
  const attended=state.bookings.filter(b=>!b.archived&&b.date===date&&b.attendanceStatus==='attended'&&b.attendanceNo!=null).slice().sort((a,b)=>(a.attendedAt||0)-(b.attendedAt||0)||(a.createdAt||0)-(b.createdAt||0)||String(a.id).localeCompare(String(b.id)));
  const map=new Map();attended.forEach((b,i)=>map.set(b.id,i+1));return map;
}
function attendanceStatusSelect(b){
  const v=b.attendanceStatus||'pending';
  return `<select class="attendance-status-select status-${v}" onchange="setAttendanceStatus('${b.id}',this.value)">
    ${[['pending','في الانتظار'],['attended','حضر'],['noshow','لم يحضر'],['canceled','ألغى']].map(([x,label])=>`<option value="${x}" ${v===x?'selected':''}>${label}</option>`).join('')}
  </select>`;
}
function attendancePaymentSelect(b){
  const v=(b.paid==='cash'||b.paid==='transfer'||b.paid==='card')?'paid':(b.paid||'no');
  return `<select class="attendance-payment-select payment-${v}" onchange="setAttendancePayment('${b.id}',this.value)">
    ${[['no','لم يدفع'],['paid','تم الدفع'],['free','مجاني']].map(([x,label])=>`<option value="${x}" ${v===x?'selected':''}>${label}</option>`).join('')}
  </select>`;
}
function syncAttendanceRecords(){
  syncBookingSerials();
  if(!Array.isArray(state.bookings))state.bookings=[];
  state.bookings.forEach(b=>{if(!b.attendanceStatus)b.attendanceStatus='pending';if(!('attendedAt' in b))b.attendedAt=null;if(!('examEnteredAt' in b))b.examEnteredAt=null;if(b.attendanceStatus!=='attended'){b.attendanceNo=null;b.attendedAt=null;b.examEnteredAt=null;}});
  const dates=[...new Set(state.bookings.filter(b=>!b.archived&&b.attendanceStatus==='attended').map(b=>b.date))];
  dates.forEach(date=>{const rows=state.bookings.filter(b=>!b.archived&&b.date===date&&b.attendanceStatus==='attended').slice().sort((a,b)=>(a.attendedAt||0)-(b.attendedAt||0)||(a.createdAt||0)-(b.createdAt||0)||String(a.id).localeCompare(String(b.id)));rows.forEach((b,i)=>{b.attendanceNo=i+1;});});
}
function renderAttendance(){
  syncAttendanceRecords();
  const d=$('attendanceDate')?.value||today();
  const bookings=state.bookings.filter(b=>!b.archived&&b.date===d).slice().sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time)||(a.createdAt||0)-(b.createdAt||0));
  const bookingSerialMap=bookingSerials(d);
  const serials=attendanceSerials(d);
  const attended=bookings.filter(b=>b.attendanceStatus==='attended');
  $('attBookings').textContent=bookings.length;
  $('attTotal').textContent=attended.length; $('attNoShow').textContent=bookings.filter(b=>b.attendanceStatus==='noshow').length;
  const isFreeType=b=>b.type==='free_exam'||b.type==='free_consult';
  const isExam=b=>b.type==='exam'||b.type==='free_exam';
  const isConsult=b=>b.type==='consult'||b.type==='free_consult';
  const isFreeExam=b=>b.type==='free_exam';
  const isFreeConsult=b=>b.type==='free_consult';
  const required=attended.reduce((sum,b)=>sum+(isFreeType(b)||b.paid==='free'?0:effectiveAmount(b)),0);
  const paid=attended.filter(b=>b.paid==='paid').reduce((sum,b)=>sum+effectiveAmount(b),0);
  const remaining=Math.max(0,required-paid);
  const examAmount=attended.filter(b=>b.type==='exam').reduce((sum,b)=>sum+effectiveAmount(b),0);
  const consultAmount=attended.filter(b=>b.type==='consult').reduce((sum,b)=>sum+effectiveAmount(b),0);
  const freeExamAmount=attended.filter(isFreeExam).reduce((sum,b)=>sum+effectiveAmount(b),0);
  const freeConsultAmount=attended.filter(isFreeConsult).reduce((sum,b)=>sum+effectiveAmount(b),0);
  $('attRequired').textContent=money(required);
  $('attRemaining').textContent=money(remaining);
  $('attExamAmount').textContent=money(examAmount);
  $('attConsultAmount').textContent=money(consultAmount);
  $('attExam').textContent=attended.filter(isExam).length;
  $('attConsult').textContent=attended.filter(isConsult).length;
  $('attFreeExam').textContent=attended.filter(isFreeExam).length;
  $('attFreeConsult').textContent=attended.filter(isFreeConsult).length;
  const groups={};
  bookings.forEach(b=>(groups[b.time]??=[]).push(b));
  const html=Object.entries(groups).sort((a,b)=>timeToMinutes(a[0])-timeToMinutes(b[0])).map(([time,rows])=>{
    const attendedCount=rows.filter(b=>b.attendanceStatus==='attended').length;
    const body=rows.map(b=>{
      const cls=b.attendanceStatus==='attended'?'attendance-attended':b.attendanceStatus==='noshow'?'attendance-noshow':b.attendanceStatus==='canceled'?'attendance-canceled':'';
      return `<tr class="${cls}">
        <td class="booking-number">${bookingSerialMap.get(b.id)||'—'}</td>
        <td><strong>${esc(b.name)}</strong></td>
        <td>${esc(b.phone)}</td>
        <td class="attendance-number">${serials.get(b.id)||'—'}</td>
        <td>${typeName(b.type)}</td>
        <td>${money(effectiveAmount(b))}</td>
        <td class="booking-timestamp">${displayDateTime(b.bookingAt||b.createdAt)}</td>
        <td class="attendance-timestamp">${b.attendanceStatus==='attended'?displayDateTime(b.attendedAt):'—'}</td>
        <td class="exam-entry-cell">${b.examEnteredAt?`<span>${displayDateTime(b.examEnteredAt)}</span><button type="button" class="ghost small" onclick="setExamEntry('${b.id}',false)">إلغاء الدخول</button>`:`<button type="button" class="secondary small" onclick="setExamEntry('${b.id}',true)" ${b.attendanceStatus!=='attended'?'disabled title="سجّل حضور المريض أولًا"':''}>دخول الكشف</button>`}</td>
        <td>${attendanceStatusSelect(b)}</td>
        <td>${attendancePaymentSelect(b)}</td>
        <td><div class="small-actions"><button type="button" class="secondary" data-action="edit" data-id="${b.id}">تعديل</button><button type="button" class="ghost" data-action="receipt" data-id="${b.id}">إيصال</button><button type="button" class="ghost" data-action="share" data-id="${b.id}">مشاركة</button><button type="button" class="danger ghost" data-action="delete" data-id="${b.id}">حذف</button></div></td>
      </tr>`;
    }).join('');
    return `<section class="attendance-hour-group"><div class="attendance-hour-head"><div><span class="hour-label">الساعة</span><h3>${displayTime(time)}</h3></div><strong>${attendedCount} حضر من ${rows.length}</strong></div><div class="table-wrap"><table class="attendance-hour-table"><thead><tr><th>مسلسل الحجز</th><th>اسم المريض</th><th>رقم الهاتف</th><th>مسلسل الحضور</th><th>النوع</th><th>المبلغ</th><th>وقت الحجز</th><th>وقت الحضور</th><th>وقت دخول الكشف</th><th>الحضور</th><th>الدفع</th><th>إجراء</th></tr></thead><tbody>${body}</tbody></table></div></section>`;
  }).join('');
  $('attendanceGroups').innerHTML=html||`<div class="empty">لا توجد حجوزات لهذا اليوم.</div>`;
}
function setAttendanceStatus(id,v){
  const b=state.bookings.find(x=>x.id===id);if(!b)return;
  commit(()=>{
    const was=b.attendanceStatus;
    b.attendanceStatus=v;
    if(v==='attended' && was!=='attended'){
      // وقت الحضور هو لحظة الضغط على «حضر»، ومسلسل الحضور يُبنى على هذا الترتيب فقط.
      b.attendedAt=Date.now();
      const nums=state.bookings.filter(x=>!x.archived&&x.date===b.date&&x.periodId===b.periodId&&x.attendanceStatus==='attended'&&x.id!==id).map(x=>+x.attendanceNo||0);
      b.attendanceNo=nums.length?Math.max(...nums)+1:1;
    }else if(v!=='attended'){ b.attendanceNo=null; b.attendedAt=null; b.examEnteredAt=null; }
  });
  renderAttendance();renderHourlyAttendance();renderBookings();
}
function setAttendancePayment(id,v){
  const b=state.bookings.find(x=>x.id===id);if(!b)return;
  commit(()=>{
    b.paid=v;
    if(v==='free') b.amount=0;
    else if((+b.amount||0)===0 && !String(b.type||'').startsWith('free_')) b.amount=getPriceForType(b.type);
  });
  renderAttendance();renderBookings();renderReports();
}
function printAttendance(){window.print()}
function renderHourlyAttendance(){
  const d=$('hourlyAttendanceDate')?.value||today(), filter=$('hourlyAttendancePeriod')?.value||'';
  const ps=state.periods||[];const sel=$('hourlyAttendancePeriod');
  if(sel){const old=sel.value;sel.innerHTML='<option value="">كل الفترات</option>'+ps.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');if(ps.some(p=>p.id===old))sel.value=old;}
  const rows=[];
  ps.filter(p=>!filter||p.id===filter).forEach(p=>{normalizePeriod(p);getDaySlots(p,d).forEach(slot=>{
    const bs=periodBookings(d,p.id,slot.time);rows.push({time:slot.time,total:bs.length,att:bs.filter(b=>b.attendanceStatus==='attended').length,no:bs.filter(b=>b.attendanceStatus==='noshow').length,cancel:bs.filter(b=>b.attendanceStatus==='canceled').length});
  })});
  rows.sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time));
  $('hourlyAttendanceTable').innerHTML=rows.map(r=>`<tr><td>${displayTime(r.time)}</td><td>${r.total}</td><td>${r.att}</td><td>${r.no}</td><td>${r.cancel}</td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد بيانات.</td></tr>`;
  const totals=rows.reduce((a,r)=>({total:a.total+r.total,att:a.att+r.att,no:a.no+r.no,cancel:a.cancel+r.cancel}),{total:0,att:0,no:0,cancel:0});
  $('hourlyAttendanceFoot').innerHTML=rows.length?`<tr class="total-row"><th>الإجمالي</th><th>${totals.total}</th><th>${totals.att}</th><th>${totals.no}</th><th>${totals.cancel}</th></tr>`:'';
}
function printHourlyAttendance(){window.print()}

function renderBookings(){
  const d=$('bookingDate').value||today();
  const all=state.bookings.filter(x=>!x.archived&&x.date===d);
  $('dayBookings').textContent=all.length;
  $('dayAttended').textContent=all.filter(x=>x.status==='attended').length;
  $('dayNoShow').textContent=all.filter(x=>x.status==='noshow').length;
  $('dayCanceled').textContent=all.filter(x=>x.status==='canceled').length;
  $('dayRevenue').textContent=money(all.filter(x=>x.status==='attended').reduce((s,x)=>s+effectiveAmount(x),0));
  renderPeriods();
}

function renderWaitlist(){const d=$('bookingDate').value||today();const waits=state.waitlist.filter(x=>x.date===d);$('waitlistTable').innerHTML=waits.map(w=>`<tr><td>${esc(w.name)}</td><td>${esc(w.phone)}</td><td>${typeName(w.type)}</td><td>${w.time?displayTime(w.time):'أي وقت'}</td><td><button class="primary" onclick="promoteWait('${w.id}')">تحويل لحجز</button><button class="danger ghost" onclick="deleteWait('${w.id}')">حذف</button></td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد قائمة انتظار.</td></tr>`;const suggestions=[];waits.forEach(w=>{const candidates=[];state.periods.forEach(p=>{normalizePeriod(p);getDaySlots(p,d).forEach(slot=>{if(w.time&&w.time!==slot.time)return;const used=periodBookings(d,p.id,slot.time).length;if(used<slot.capacity)candidates.push({time:slot.time,period:p});})});candidates.sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time));if(candidates[0])suggestions.push(`${esc(w.name)} → ${displayTime(candidates[0].time)} (${esc(candidates[0].period.name)})`)});if($('waitlistAlert'))$('waitlistAlert').innerHTML=suggestions.length?`<div class="alert-item info">🔔 يوجد مواعيد متاحة لمرضى الانتظار:<br>${suggestions.slice(0,5).join('<br>')}</div>`:''} 

function deleteWait(id){commit(()=>state.waitlist=state.waitlist.filter(x=>x.id!==id))}

function openOperationModal(){
 $('modalTitle').textContent='إضافة عملية';$('modalBody').innerHTML=`<div class="form-grid"><label>التاريخ<input id="oDate" type="date" value="${today()}"></label><label>النوع<select id="oType"><option>دخل</option><option>تحصيل</option><option>مرتجع</option><option>أخرى</option></select></label><label class="full">البيان<input id="oDesc"></label><label>المبلغ<input id="oAmount" type="number" min="0"></label></div><div class="modal-actions"><button class="primary" data-modal-action="save-operation">حفظ</button><button type="button" class="ghost" data-modal-action="close">إلغاء</button></div>`;$('modal').classList.remove('hidden')}
function saveOperation(){commit(()=>state.operations.push({id:uid(),date:$('oDate').value,type:$('oType').value,desc:$('oDesc').value,amount:+$('oAmount').value||0}));closeModal();refreshListAfterSave('operationsTable');}
function deleteOperation(id){commit(()=>state.operations=state.operations.filter(x=>x.id!==id))}
function renderOperations(){$('operationsTable').innerHTML=state.operations.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<tr><td>${fmtDate(x.date)}</td><td>${esc(x.type)}</td><td>${esc(x.desc)}</td><td>${money(x.amount)}</td><td><button class="danger ghost" onclick="deleteOperation('${x.id}')">حذف</button></td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد عمليات.</td></tr>`}
function openExpenseModal(id=''){const x=id?state.expenses.find(e=>e.id===id):null;window.editingExpenseId=id||'';$('modalTitle').textContent=x?'تعديل مصروف':'إضافة مصروف';$('modalBody').innerHTML=`<div class="form-grid"><label>تاريخ الشراء<input id="eDate" type="date" value="${esc(x?.date||today())}"></label><label>اسم المصروف<input id="eItem" value="${esc(x?.item||'')}" placeholder="اكتب اسم المصروف"></label><label>مبلغ المصروف<input id="eAmount" type="number" min="0" step="0.01" value="${+x?.amount||''}" placeholder="اكتب المبلغ"></label><label>مصدر المبلغ<select id="eSource"><option value="clinic" ${(!x?.source||x.source==='clinic')?'selected':''}>خزينة العيادة</option><option value="doctor" ${x?.source==='doctor'?'selected':''}>من الدكتور</option><option value="personal" ${x?.source==='personal'?'selected':''}>من جيبي الخاص</option></select></label><label class="full">ملاحظات (اختياري)<textarea id="eNotes" placeholder="أي تفاصيل إضافية عن المصروف">${esc(x?.notes||'')}</textarea></label></div><div class="modal-actions"><button class="primary" type="button" onclick="saveExpense()">حفظ</button><button type="button" class="ghost" data-modal-action="close">إلغاء</button></div>`;$('modal').classList.remove('hidden')}
function saveExpense(){const item=$('eItem')?.value.trim(),date=$('eDate')?.value,amount=+$('eAmount')?.value||0,source=$('eSource')?.value,notes=$('eNotes')?.value.trim()||'';if(!item||!date||amount<=0){alert('اكتب اسم المصروف والمبلغ وتاريخ الشراء.');return}const id=window.editingExpenseId||'';commit(()=>{const old=state.expenses.find(e=>e.id===id);const row={id:id||uid(),item,date,amount,source,notes,createdAt:old?.createdAt||Date.now()};if(old)Object.assign(old,row);else state.expenses.push(row)});closeModal();renderExpenses();renderReports()}
function deleteExpense(id){if(!confirm('هل تريد حذف هذا المصروف؟'))return;commit(()=>state.expenses=state.expenses.filter(x=>x.id!==id));renderExpenses();renderReports()}
function renderExpenses(){const t=state.expenses.reduce((s,x)=>s+(+x.amount||0),0);$('expensesTotal').textContent=money(t);const src=x=>({clinic:'خزينة العيادة',doctor:'من الدكتور',personal:'من جيبي الخاص'}[x.source]||'يومية العيادة');$('expensesTable').innerHTML=state.expenses.slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))||(a.createdAt||0)-(b.createdAt||0)).map((x,i)=>`<tr><td>${i+1}</td><td>${esc(x.item)}</td><td>${money(x.amount)}</td><td>${fmtDate(x.date)}</td><td>${src(x)}</td><td><div class="small-actions"><button class="secondary" onclick="openExpenseModal('${x.id}')">تعديل</button><button class="danger ghost" onclick="deleteExpense('${x.id}')">حذف</button></div></td></tr>`).join('')||`<tr><td colspan="6" class="empty">لا توجد مصروفات.</td></tr>`}

function renderReports(){const bs=state.bookings.filter(x=>!x.archived),att=bs.filter(x=>x.status==='attended'),rev=att.reduce((s,x)=>s+effectiveAmount(x),0),exp=state.expenses.reduce((s,x)=>s+x.amount,0),rates=state.rates.reduce((s,r)=>s+r.examCount*r.examRate+r.consultCount*r.consultRate,0),ops=state.operations.reduce((s,x)=>s+x.amount,0);$('reportBookings').textContent=bs.length;$('reportAttended').textContent=att.length;$('reportNoShow').textContent=bs.filter(x=>x.status==='noshow').length;$('reportCanceled').textContent=bs.filter(x=>x.status==='canceled').length;$('reportRevenue').textContent=money(rev);$('reportDues').textContent=money(att.filter(x=>x.paid==='no').reduce((s,x)=>s+effectiveAmount(x),0));$('reportRates').textContent=money(rates);$('reportExpenses').textContent=money(exp);$('reportNet').textContent=money(rev+ops-rates-exp);const dates=[...new Set([...bs.map(x=>x.date),...state.rates.map(x=>x.date),...state.expenses.map(x=>x.date)])].sort().reverse();$('dailyReportTable').innerHTML=dates.map(d=>{const a=bs.filter(x=>x.date===d),r=state.rates.find(x=>x.date===d),e=state.expenses.filter(x=>x.date===d).reduce((s,x)=>s+x.amount,0);return `<tr><td>${fmtDate(d)}</td><td>${a.length}</td><td>${a.filter(x=>x.status==='attended').length}</td><td>${a.filter(x=>x.status==='noshow').length}</td><td>${a.filter(x=>x.status==='canceled').length}</td><td>${money(a.filter(x=>x.status==='attended').reduce((s,x)=>s+effectiveAmount(x),0))}</td><td>${money(e)}</td><td>${r?money(r.examCount*r.examRate+r.consultCount*r.consultRate):'—'}</td></tr>`}).join('')||`<tr><td colspan="8" class="empty">لا توجد بيانات.</td></tr>`}

function renderDashboard(){}
function searchPatients(){const q=($('patientSearch').value||'').trim().toLowerCase();const bs=state.bookings.filter(x=>!x.archived&&(!q||x.name.toLowerCase().includes(q)||x.phone.includes(q)));$('patientsTable').innerHTML=bs.sort((a,b)=>b.date.localeCompare(a.date)).slice(0,100).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td>${fmtDate(x.date)}</td><td>${displayTime(x.time)}</td><td>${typeName(x.type)}</td><td>${statusBadge(x.status)}</td><td>${money(effectiveAmount(x))}</td><td><button type="button" class="secondary" data-action="edit" data-id="${x.id}">فتح</button></td></tr>`).join('')||`<tr><td colspan="8" class="empty">لا توجد نتائج.</td></tr>`}

function openSettings(){
  $('modalTitle').textContent='إعدادات العيادة';
  const current=state.settings.logo||'assets/clinic-logo.png';
  $('modalBody').innerHTML=`
    <div class="form-grid">
      <label class="full">اسم العيادة<input id="sName" value="${esc(state.settings.clinicName)}"></label>
      <label>سعر الكشف<input id="sExamPrice" type="number" min="0" value="${+state.settings.examPrice||0}"></label>
      <label>سعر الاستشارة<input id="sConsultPrice" type="number" min="0" value="${+state.settings.consultPrice||0}"></label>
      <label>العملة<input id="sCurrency" value="${esc(state.settings.currency||'جنيه')}"></label>
      <div class="full" style="border:1px solid #dbe4ee;border-radius:16px;padding:14px;background:#f8fafc"><div class="section-title">واتساب — تأكيد الحجز والتذكير قبل 3 ساعات</div><label><input id="sWaEnabled" type="checkbox" ${state.settings.waEnabled?'checked':''}> تفعيل الإرسال التلقائي</label><label class="full">عنوان خادم واتساب<input id="sWaServerUrl" placeholder="https://your-domain.com" value="${esc(state.settings.waServerUrl||'')}"></label><p class="muted">بعد تفعيلها: عند حفظ الحجز يرسل الخادم رسالة تأكيد، ويجدول رسالة ثانية قبل الموعد بـ3 ساعات. يلزم إعداد Meta WhatsApp Cloud API على الخادم.</p></div>
      <div class="full image-picker-box">
        <div class="section-title">صورة العيادة / الشعار</div>
        <div class="image-picker-actions">
          <button type="button" class="primary" onclick="document.getElementById('sLogo').click()">📷 اختيار صورة من الجهاز</button>
          <button type="button" class="secondary" onclick="useBundledClinicLogo()">↺ استخدام شعار العيادة المرفق</button>
        </div>
        <input id="sLogo" type="file" accept="image/*" onchange="previewClinicImage(this)" style="display:none">
        <div id="sLogoName" class="muted">${state.settings.logo?'الصورة الحالية محفوظة':'شعار العيادة المرفق هو الصورة الافتراضية'}</div>
        <div class="logo-preview-wrap"><img id="sLogoPreview" class="settings-logo-preview" src="${esc(current)}" alt="معاينة شعار العيادة"></div>
      </div>
    </div>
    <p class="muted">يمكنك اختيار صورة من الهاتف أو استخدام شعار العيادة المرفق. اضغط حفظ الإعدادات لتثبيت الاختيار.</p>
    <div class="modal-actions">
      <button class="primary" type="button" onclick="saveSettings()">حفظ الإعدادات</button>
      <button class="secondary" type="button" onclick="backup()">💾 حفظ نسخة احتياطية</button>
      <button class="secondary" type="button" onclick="openAutoBackup()">🕒 آخر نسخة تلقائية</button>
      <button class="secondary" type="button" onclick="document.getElementById('restoreFile').click()">↥ استرجاع نسخة</button>
      <button class="ghost" type="button" data-modal-action="close">إلغاء</button>
    </div>`;
  $('modal').classList.remove('hidden');
}
function previewClinicImage(input){
  const f=input?.files?.[0];
  const name=$('sLogoName');
  const preview=$('sLogoPreview');
  if(!f){if(name)name.textContent='لم يتم اختيار صورة';return}
  if(name)name.textContent=`تم اختيار: ${f.name}`;
  if(preview){
    try{preview.src=URL.createObjectURL(f);preview.onload=()=>URL.revokeObjectURL(preview.src)}catch(e){}
  }
}
function useBundledClinicLogo(){
  const input=$('sLogo');
  if(input)input.value='';
  state.settings.logo='assets/clinic-logo.png';
  const preview=$('sLogoPreview'); if(preview)preview.src='assets/clinic-logo.png';
  const name=$('sLogoName'); if(name)name.textContent='تم اختيار شعار العيادة المرفق';
}
function readClinicImage(file,done){
  if(!file){done(undefined);return}
  const r=new FileReader();
  r.onerror=()=>done(undefined);
  r.onload=()=>{
    const img=new Image();
    img.onerror=()=>done(undefined);
    img.onload=()=>{
      try{
        const max=1200, scale=Math.min(1,max/Math.max(img.width,img.height));
        const c=document.createElement('canvas');
        c.width=Math.max(1,Math.round(img.width*scale));c.height=Math.max(1,Math.round(img.height*scale));
        const ctx=c.getContext('2d');ctx.drawImage(img,0,0,c.width,c.height);
        done(c.toDataURL('image/jpeg',.82));
      }catch(e){done(undefined)}
    };
    img.src=r.result;
  };
  try{r.readAsDataURL(file)}catch(e){done(undefined)}
}
function saveSettings(){
  const name=$('sName')?.value.trim()||'نظام العيادة';
  const exam=Math.max(0,+$('sExamPrice')?.value||0);
  const consult=Math.max(0,+$('sConsultPrice')?.value||0);
  const currency=$('sCurrency')?.value.trim()||'جنيه';
  const waEnabled=!!$('sWaEnabled')?.checked;
  const waServerUrl=($('sWaServerUrl')?.value||'').trim().replace(/\/$/,'');
  const f=$('sLogo')?.files?.[0];
  const finish=(logo)=>{
    commit(()=>{
      state.settings.clinicName=name;state.settings.examPrice=exam;state.settings.consultPrice=consult;state.settings.currency=currency;state.settings.waEnabled=waEnabled;state.settings.waServerUrl=waServerUrl;
      if(logo!==undefined)state.settings.logo=logo;
    });
    closeModal();renderAll();
  };
  if(f)readClinicImage(f,logo=>{if(logo===undefined){alert('تعذر قراءة الصورة من الجهاز. يمكنك استخدام شعار العيادة المرفق.');return}finish(logo)});
  else finish(state.settings.logo||'assets/clinic-logo.png');
}
function closeModal(){
  const m=$('modal');
  if(!m)return;
  m.classList.add('hidden');
  // تفريغ محتوى النافذة يمنع أي حالة قديمة من البقاء فوق الصفحة في WebView.
  const body=$('modalBody');
  if(body)body.innerHTML='';
  const title=$('modalTitle');
  if(title)title.textContent='';
}
function printAttendance(){window.print()}
function printReport(){showPage('reports');setTimeout(()=>window.print(),50)}
function receipt(id){const b=state.bookings.find(x=>x.id===id);if(!b)return;const p=state.periods.find(x=>x.id===b.periodId);const w=window.open('','_blank','width=420,height=600');w.document.write(`<html dir="rtl"><head><title>إيصال</title><style>body{font-family:Tahoma;padding:24px;text-align:center}hr{border:0;border-top:1px solid #ddd;margin:18px 0}.row{display:flex;justify-content:space-between;padding:7px 0}</style></head><body><h2>${esc(state.settings.clinicName)}</h2><h3>إيصال دفع</h3><hr><div class="row"><span>المريض</span><b>${esc(b.name)}</b></div><div class="row"><span>الخدمة</span><b>${typeName(b.type)}</b></div><div class="row"><span>التاريخ</span><b>${fmtDate(b.date)}</b></div><div class="row"><span>الساعة</span><b>${displayTime(b.time)}</b></div><div class="row"><span>الفترة</span><b>${esc(p?.name||'-')}</b></div><div class="row"><span>السعر</span><b>${money(b.amount)}</b></div><div class="row"><span>الخصم</span><b>${money(b.discount)}</b></div><div class="row"><span>الصافي</span><b>${money(effectiveAmount(b))}</b></div><hr><small>شكرًا لزيارتكم</small><script>window.print()<\/script></body></html>`);w.document.close()}
function exportCSV(){const rows=[['مسلسل','التاريخ','الاسم','الهاتف','الوقت','النوع','المبلغ','الخصم','الصافي','الحالة','الدفع'],...state.bookings.filter(x=>!x.archived).map((b,i)=>[i+1,b.date,b.name,b.phone,displayTime(b.time),typeName(b.type),b.amount,b.discount,effectiveAmount(b),statusName(b.status),b.paid])];const csv='\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='clinic-bookings.csv';a.click()}
async function shareReceipt(id){const b=state.bookings.find(x=>x.id===id);if(!b)return;const text=`إيصال — ${state.settings.clinicName}\nالمريض: ${b.name}\nالخدمة: ${typeName(b.type)}\nالتاريخ: ${fmtDate(b.date)} — ${displayTime(b.time)}\nالصافي: ${money(effectiveAmount(b))}`;try{if(navigator.share){await navigator.share({title:'إيصال العيادة',text});}else{await navigator.clipboard.writeText(text);alert('تم نسخ الإيصال للمشاركة.')}}catch(e){}}
async function shareDailyStatement(date){date=date||$('dashboardDate')?.value||today();const bs=state.bookings.filter(b=>!b.archived&&b.date===date),att=bs.filter(b=>b.attendanceStatus==='attended'),collected=att.filter(b=>b.paid==='paid').reduce((s,b)=>s+effectiveAmount(b),0),exp=state.expenses.filter(x=>x.date===date).reduce((s,x)=>s+x.amount,0);const text=`ملخص يوم ${fmtDate(date)} — ${state.settings.clinicName}\nالحجوزات: ${bs.length}\nالحضور: ${att.length}\nالمحصل: ${money(collected)}\nالمصروفات: ${money(exp)}\nالصافي: ${money(collected-exp)}`;try{if(navigator.share)await navigator.share({title:'ملخص يوم العيادة',text});else{await navigator.clipboard.writeText(text);alert('تم نسخ الملخص للمشاركة.')}}catch(e){}}
async function saveBackupFile(raw,filename='clinic-backup.json'){
  const blob=new Blob([raw],{type:'application/json;charset=utf-8'});
  const file=new File([blob],filename,{type:'application/json'});
  try{
    if(navigator.share && (!navigator.canShare || navigator.canShare({files:[file]}))){
      await navigator.share({title:'نسخة احتياطية للعيادة',text:'نسخة احتياطية لبيانات العيادة',files:[file]});
      return true;
    }
  }catch(e){}
  try{
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=filename;a.target='_blank';a.rel='noopener';
    document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),3000);
    setTimeout(()=>{
      try{navigator.clipboard?.writeText(raw)}catch(e){}
    },100);
    return true;
  }catch(e){}
  try{
    await navigator.clipboard.writeText(raw);
    alert('تعذر تنزيل الملف مباشرة في هذا الجهاز، لكن تم نسخ بيانات النسخة الاحتياطية. الصقها في ملف باسم clinic-backup.json.');
    return true;
  }catch(e){alert('تعذر حفظ النسخة الاحتياطية على هذا الجهاز.');return false}
}
async function backup(){
  const raw=JSON.stringify({...state,undo:[]},null,2);
  await saveBackupFile(raw,'clinic-backup.json');
}
function restoreBackup(){
  const f=$('restoreFile')?.files?.[0];if(!f)return;
  const r=new FileReader();
  r.onload=()=>{try{const x=JSON.parse(r.result);if(!x.bookings||!x.periods){alert('ملف غير صالح.');return}if(confirm('استبدال بيانات التطبيق بالنسخة الاحتياطية؟')){state=x;state.undo=[];save();alert('تم الاسترجاع.')}}catch(e){alert('تعذر قراءة النسخة.')}};
  r.onerror=()=>alert('تعذر قراءة ملف النسخة الاحتياطية.');
  r.readAsText(f);
}
function setupAutoBackup(){try{const last=+localStorage.getItem('clinicAutoBackupAt')||0;if(Date.now()-last>24*60*60*1000){localStorage.setItem('clinicAutoBackupAt',String(Date.now()));localStorage.setItem('clinicAutoBackupData',JSON.stringify({...state,undo:[]}));}}catch(e){}}
async function openAutoBackup(){
  try{
    const raw=localStorage.getItem('clinicAutoBackupData');
    if(!raw){alert('لا توجد نسخة تلقائية محفوظة بعد.');return}
    await saveBackupFile(raw,'clinic-auto-backup.json');
  }catch(e){alert('تعذر تجهيز النسخة التلقائية.')}
}

function patientKey(b){return String(b.phone||'').replace(/\D/g,'')||String(b.name||'').trim().toLowerCase();}
function patientRecords(){
  const map=new Map();
  state.bookings.filter(b=>!b.archived).forEach(b=>{
    const key=patientKey(b); if(!key)return;
    let p=map.get(key);
    if(!p){p={key,name:b.name||'-',phone:b.phone||'-',bookings:[],notes:'',createdAt:b.createdAt||Date.now()};map.set(key,p)}
    p.bookings.push(b);
    if((b.name||'').trim())p.name=b.name;
    if((b.phone||'').trim())p.phone=b.phone;
  });
  return [...map.values()].sort((a,b)=>String(b.bookings.map(x=>x.date).sort().pop()||'').localeCompare(String(a.bookings.map(x=>x.date).sort().pop()||'')));
}
function renderPatients(){
  const q=($('patientFileSearch')?.value||'').trim().toLowerCase();
  const all=patientRecords();
  const list=all.filter(p=>!q||p.name.toLowerCase().includes(q)||p.phone.toLowerCase().includes(q));
  if($('patientsCountBadge'))$('patientsCountBadge').textContent=`${all.length} مريض`;
  $('patientsTable').innerHTML=list.map(p=>{
    const attended=p.bookings.filter(b=>(b.attendanceStatus||'pending')==='attended').length;
    const latest=p.bookings.map(b=>b.date).sort().pop()||'';
    const due=p.bookings.filter(b=>(b.attendanceStatus||'pending')==='attended'&&b.paid!=='free').reduce((s,b)=>s+effectiveAmount(b),0);
    return `<tr><td><b>${esc(p.name)}</b></td><td>${esc(p.phone)}</td><td>${p.bookings.length}</td><td>${attended}</td><td>${fmtDate(latest)}</td><td>${money(due)}</td><td><button class="secondary" onclick="openPatientFile('${encodeURIComponent(p.key)}')">📁 فتح الملف</button></td></tr>`;
  }).join('')||`<tr><td colspan="7" class="empty">لا توجد ملفات مطابقة.</td></tr>`;
}
function openPatientFile(encodedKey){
  const key=decodeURIComponent(encodedKey||'');
  const p=patientRecords().find(x=>x.key===key); if(!p)return;
  const bs=p.bookings.slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(b.time).localeCompare(String(a.time)));
  const attended=bs.filter(b=>(b.attendanceStatus||'pending')==='attended');
  const due=attended.filter(b=>b.paid!=='free').reduce((s,b)=>s+effectiveAmount(b),0);
  const paid=attended.filter(b=>b.paid==='paid').reduce((s,b)=>s+effectiveAmount(b),0);
  $('modalTitle').textContent=`ملف المريض — ${p.name}`;
  $('modalBody').innerHTML=`<div class="patient-profile"><div class="patient-profile-head"><div><span class="eyebrow">ملف المريض</span><h3>${esc(p.name)}</h3><p>${esc(p.phone||'لا يوجد هاتف')}</p></div><div class="patient-profile-stats"><span><b>${bs.length}</b> زيارة</span><span><b>${attended.length}</b> حضر</span><span><b>${money(due)}</b> مطلوب</span><span><b>${money(paid)}</b> مدفوع</span></div></div><div class="section-title">سجل الزيارات والحجوزات</div><div class="table-wrap patient-history-wrap"><table><thead><tr><th>التاريخ</th><th>الساعة</th><th>النوع</th><th>الحالة</th><th>الدفع</th><th>المبلغ</th><th>ملاحظات</th><th>إجراء</th></tr></thead><tbody>${bs.map(b=>`<tr><td>${fmtDate(b.date)}</td><td>${displayTime(b.time)}</td><td>${typeName(b.type)}</td><td>${statusName(b.status)}</td><td>${b.paid==='paid'?'تم الدفع':b.paid==='free'?'مجاني':'لم يدفع'}</td><td>${money(effectiveAmount(b))}</td><td>${esc(b.notes||'-')}</td><td><button class="secondary" onclick="closeModal();openBookingModal('${b.id}')">فتح</button></td></tr>`).join('')}</tbody></table></div><div class="modal-actions"><button class="primary" onclick="closeModal();showPage('bookings');$('bookingSearch').value='${esc(p.phone==='-'?'':p.phone)}';renderBookings()">عرض في الحجوزات</button><button class="secondary" onclick="printPatientStatement('${encodeURIComponent(p.key)}')">🧾 كشف حساب</button><button class="ghost" onclick="closeModal()">إغلاق</button></div></div>`;
  $('modal').classList.remove('hidden');
}

function renderArchive(){const a=state.bookings.filter(x=>x.archived);$('archiveTable').innerHTML=a.map(b=>`<tr><td>${esc(b.name)}</td><td>${esc(b.phone)}</td><td>${fmtDate(b.date)}</td><td>${typeName(b.type)}</td><td><button class="secondary" onclick="restoreBooking('${b.id}')">استرجاع</button><button class="danger ghost" onclick="deleteBookingPermanent('${b.id}')">حذف نهائي</button></td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد حالات مؤرشفة.</td></tr>`}

const ZOOM_KEY='clinic_ui_zoom_v1';
let uiZoom=Number(localStorage.getItem(ZOOM_KEY)||100);
function applyZoom(){
  uiZoom=Math.max(70,Math.min(130,uiZoom));
  document.documentElement.style.setProperty('--ui-zoom',(uiZoom/100).toFixed(2));
  const el=$('zoomLevel'); if(el) el.textContent=uiZoom+'%';
  localStorage.setItem(ZOOM_KEY,String(uiZoom));
}
function changeZoom(delta){uiZoom+=delta;applyZoom()}
function resetZoom(){uiZoom=100;applyZoom()}


let calendarCursor=new Date();
function renderDashboard(){
  const d=$('dashboardDate')?.value||today();
  if($('dashboardDate')&&!$('dashboardDate').value)$('dashboardDate').value=d;
  const bs=state.bookings.filter(b=>!b.archived&&b.date===d);
  const attended=bs.filter(b=>(b.attendanceStatus||'pending')==='attended');
  const collected=attended.filter(b=>b.paid==='paid').reduce((s,b)=>s+effectiveAmount(b),0);
  const due=attended.filter(b=>b.paid!=='free'&&b.paid!=='paid').reduce((s,b)=>s+effectiveAmount(b),0);
  const exp=state.expenses.filter(x=>x.date===d).reduce((s,x)=>s+(+x.amount||0),0);
  const ops=state.operations.filter(x=>x.date===d).reduce((s,x)=>s+(+x.amount||0),0);
  [['dashBookings',bs.length],['dashAttended',attended.length],['dashNoShow',bs.filter(b=>b.status==='noshow').length],['dashCanceled',bs.filter(b=>b.status==='canceled').length]].forEach(([id,v])=>{if($(id))$(id).textContent=v});
  if($('dashCollected'))$('dashCollected').textContent=money(collected);
  if($('dashDue'))$('dashDue').textContent=money(due);
  if($('dashExpenses'))$('dashExpenses').textContent=money(exp);
  if($('dashNet'))$('dashNet').textContent=money(collected+ops-exp);
  const alerts=[];
  const pending=bs.filter(b=>(b.attendanceStatus||'pending')==='pending');
  if(pending.length) alerts.push(`<div class="alert-item warn">⏳ <b>${pending.length}</b> حالة ما زالت في الانتظار.</div>`);
  const missed=bs.filter(b=>b.status==='noshow');
  if(missed.length) alerts.push(`<div class="alert-item info">📌 ${missed.length} مريض لم يحضر اليوم.</div>`);
  const cancelled=bs.filter(b=>b.status==='canceled');
  if(cancelled.length) alerts.push(`<div class="alert-item danger">⚠️ ${cancelled.length} حجز تم إلغاؤه.</div>`);
  const waits=state.waitlist.filter(w=>w.date===d);
  if(waits.length) alerts.push(`<div class="alert-item info">⏳ ${waits.length} مريض في قائمة الانتظار.</div>`);
  if(d===today()){
    const now=new Date(); const late=bs.filter(b=>(b.attendanceStatus||'pending')==='pending' && timeToMinutes(b.time)<now.getHours()*60+now.getMinutes());
    if(late.length) alerts.push(`<div class="alert-item warn">🔔 ${late.length} موعد فات وقته ولم يتم تسجيل حضوره.</div>`);
  }
  if($('dashboardAlerts'))$('dashboardAlerts').innerHTML=alerts.join('')||'<div class="empty">لا توجد تنبيهات حالية.</div>';
}
function calendarMonthKey(y,m){return `${y}-${String(m+1).padStart(2,'0')}`}
function renderCalendar(){
  const y=calendarCursor.getFullYear(),m=calendarCursor.getMonth();
  if($('calendarTitle'))$('calendarTitle').textContent=new Date(y,m,1).toLocaleDateString('ar-EG',{year:'numeric',month:'long'});
  const first=new Date(y,m,1),days=new Date(y,m+1,0).getDate();
  let start=(first.getDay()+6)%7; const cells=[]; const names=['الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت','الأحد'];
  names.forEach(n=>cells.push(`<div class="calendar-head">${n}</div>`));
  for(let i=0;i<start;i++)cells.push('<div class="calendar-day empty-day"></div>');
  for(let day=1;day<=days;day++){
    const d=`${y}-${String(m+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
    const bs=state.bookings.filter(b=>!b.archived&&b.date===d),att=bs.filter(b=>(b.attendanceStatus||'pending')==='attended').length,no=bs.filter(b=>b.status==='noshow').length,c=bs.filter(b=>b.status==='canceled').length;
    const cls=d===today()?' today':'';
    cells.push(`<button class="calendar-day${cls}" onclick="calendarOpenDate('${d}')"><b>${day}</b><span>${bs.length} حجز</span><small>حضر ${att} · غاب ${no} · ألغى ${c}</small></button>`)
  }
  if($('calendarGrid'))$('calendarGrid').innerHTML=cells.join('');
}
function calendarPrev(){calendarCursor.setMonth(calendarCursor.getMonth()-1);renderCalendar()}
function calendarNext(){calendarCursor.setMonth(calendarCursor.getMonth()+1);renderCalendar()}
function calendarToday(){calendarCursor=new Date();renderCalendar()}
function calendarOpenDate(d){$('bookingDate').value=d;showPage('bookings');renderBookings();renderWaitlist()}
function openGlobalSearch(){
  $('modalTitle').textContent='البحث الشامل';
  $('modalBody').innerHTML=`<label class="full">اسم المريض أو رقم الهاتف<input id="globalSearchInput" autofocus oninput="renderGlobalSearch()" placeholder="اكتب للبحث..."></label><div id="globalSearchResults" class="global-search-results"></div><div class="modal-actions"><button class="ghost" onclick="closeModal()">إغلاق</button></div>`;
  $('modal').classList.remove('hidden');setTimeout(()=>$('globalSearchInput')?.focus(),30);renderGlobalSearch();
}
function renderGlobalSearch(){
  const q=($('globalSearchInput')?.value||'').trim().toLowerCase();
  const rows=state.bookings.filter(b=>!b.archived&&(!q||String(b.name||'').toLowerCase().includes(q)||String(b.phone||'').includes(q))).slice().sort((a,b)=>String(b.date).localeCompare(String(a.date))||String(b.time).localeCompare(String(a.time))).slice(0,30);
  $('globalSearchResults').innerHTML=rows.length?`<div class="table-wrap"><table><thead><tr><th>المريض</th><th>الهاتف</th><th>التاريخ</th><th>الساعة</th><th>الحالة</th><th>إجراء</th></tr></thead><tbody>${rows.map(b=>`<tr><td><b>${esc(b.name)}</b></td><td>${esc(b.phone||'-')}</td><td>${fmtDate(b.date)}</td><td>${displayTime(b.time)}</td><td>${statusName(b.status)}</td><td><button class="secondary" onclick="closeModal();openBookingModal('${b.id}')">فتح</button></td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">لا توجد نتائج.</div>';
}
function printDailyStatement(date){
  date=date||$('dashboardDate')?.value||today(); const bs=state.bookings.filter(b=>!b.archived&&b.date===date); const att=bs.filter(b=>(b.attendanceStatus||'pending')==='attended');
  const collected=att.filter(b=>b.paid==='paid').reduce((s,b)=>s+effectiveAmount(b),0), due=att.filter(b=>b.paid!=='paid'&&b.paid!=='free').reduce((s,b)=>s+effectiveAmount(b),0), exp=state.expenses.filter(x=>x.date===date).reduce((s,x)=>s+x.amount,0), ops=state.operations.filter(x=>x.date===date).reduce((s,x)=>s+x.amount,0);
  const w=window.open('','_blank','width=900,height=700');if(!w)return;w.document.write(`<html dir="rtl"><head><title>كشف يومي</title><style>body{font-family:Tahoma;padding:25px}h1{text-align:center}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.card{border:1px solid #ddd;padding:12px;border-radius:10px}.card b{display:block;font-size:20px;margin-top:5px}table{width:100%;border-collapse:collapse;margin-top:20px}th,td{border:1px solid #ddd;padding:8px;text-align:right}@media print{button{display:none}}</style></head><body><h1>${esc(state.settings.clinicName)}</h1><h2>كشف حساب اليوم — ${fmtDate(date)}</h2><div class="cards"><div class="card">الحجوزات<b>${bs.length}</b></div><div class="card">حضر<b>${att.length}</b></div><div class="card">المحصل<b>${money(collected)}</b></div><div class="card">المتبقي<b>${money(due)}</b></div><div class="card">المصروفات<b>${money(exp)}</b></div><div class="card">عمليات دخل<b>${money(ops)}</b></div><div class="card">صافي اليوم<b>${money(collected+ops-exp)}</b></div></div><table><thead><tr><th>المريض</th><th>الساعة</th><th>النوع</th><th>الحضور</th><th>الدفع</th><th>المبلغ</th></tr></thead><tbody>${bs.map(b=>`<tr><td>${esc(b.name)}</td><td>${displayTime(b.time)}</td><td>${typeName(b.type)}</td><td>${b.attendanceStatus==='attended'?'حضر':b.attendanceStatus==='noshow'?'لم يحضر':b.attendanceStatus==='canceled'?'ألغى':'في الانتظار'}</td><td>${b.paid==='paid'?'تم الدفع':b.paid==='free'?'مجاني':'لم يدفع'}</td><td>${money(effectiveAmount(b))}</td></tr>`).join('')}</tbody></table><script>window.print()<\/script></body></html>`);w.document.close();
}
function printPatientStatement(encodedKey){const key=decodeURIComponent(encodedKey||'');const p=patientRecords().find(x=>x.key===key);if(!p)return;const bs=p.bookings.slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))||String(a.time).localeCompare(String(b.time)));const due=bs.filter(b=>b.paid!=='paid'&&b.paid!=='free'&&b.attendanceStatus==='attended').reduce((s,b)=>s+effectiveAmount(b),0),paid=bs.filter(b=>b.paid==='paid'&&b.attendanceStatus==='attended').reduce((s,b)=>s+effectiveAmount(b),0);const w=window.open('','_blank','width=850,height=700');if(!w)return;w.document.write(`<html dir="rtl"><head><title>كشف حساب المريض</title><style>body{font-family:Tahoma;padding:25px}h1,h2{text-align:center}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ddd;padding:8px}</style></head><body><h1>${esc(state.settings.clinicName)}</h1><h2>كشف حساب المريض</h2><p><b>المريض:</b> ${esc(p.name)} — <b>الهاتف:</b> ${esc(p.phone)}</p><p><b>المدفوع:</b> ${money(paid)} &nbsp; <b>المتبقي:</b> ${money(due)}</p><table><thead><tr><th>التاريخ</th><th>الساعة</th><th>الخدمة</th><th>الحالة</th><th>الدفع</th><th>المبلغ</th></tr></thead><tbody>${bs.map(b=>`<tr><td>${fmtDate(b.date)}</td><td>${displayTime(b.time)}</td><td>${typeName(b.type)}</td><td>${statusName(b.status)}</td><td>${b.paid==='paid'?'تم الدفع':b.paid==='free'?'مجاني':'لم يدفع'}</td><td>${money(effectiveAmount(b))}</td></tr>`).join('')}</tbody></table><script>window.print()<\/script></body></html>`);w.document.close()}
function setupAutoBackup(){try{const last=+localStorage.getItem('clinicAutoBackupAt')||0;if(Date.now()-last>24*60*60*1000){localStorage.setItem('clinicAutoBackupAt',String(Date.now()));localStorage.setItem('clinicAutoBackupData',JSON.stringify({...state,undo:[]}));}}catch(e){}}
function openAutoBackup(){try{const raw=localStorage.getItem('clinicAutoBackupData');if(!raw){alert('لا توجد نسخة تلقائية محفوظة بعد.');return}const blob=new Blob([raw],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='clinic-auto-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}catch(e){alert('تعذر تجهيز النسخة التلقائية.')}}

// Fallback event bridge for Android WebView: all critical booking actions are handled here, without inline onclick.
(function installCriticalButtonBridge(){
  if(window.__criticalBookingBridgeInstalled)return;
  window.__criticalBookingBridgeInstalled=true;
  document.addEventListener('click',function(ev){
    const el=ev.target.closest && ev.target.closest('button');
    if(!el)return;
    const action=el.getAttribute('data-action');
    const modalAction=el.getAttribute('data-modal-action');
    const id=el.getAttribute('data-id')||'';
    if(modalAction==='save-booking'){ev.preventDefault();ev.stopImmediatePropagation();if(typeof saveBooking==='function')saveBooking(id);return;}
    if(modalAction==='delete-booking'){ev.preventDefault();ev.stopImmediatePropagation();if(typeof deleteBookingPermanent==='function')deleteBookingPermanent(id);return;}
    if(action==='add'){ev.preventDefault();ev.stopImmediatePropagation();openBookingModal();return;}
    if(action==='edit'){ev.preventDefault();ev.stopImmediatePropagation();openBookingModal(id);return;}
    if(action==='delete'){ev.preventDefault();ev.stopImmediatePropagation();deleteBookingPermanent(id);return;}
  },true);
})();

function renderAll(){
  $('clinicTitle').textContent=state.settings.clinicName||'نظام العيادة';
  const homeImg=$('clinicHomeImage'); if(homeImg)homeImg.innerHTML=`<img src="${state.settings.logo||'assets/clinic-logo.png'}" alt="شعار عيادة الدكتور أحمد عامر">`; const doctorImg=document.querySelector('.doctor-home-photo img'); if(doctorImg)doctorImg.src='assets/doctor.png';
['bookingDate','attendanceDate','hourlyAttendanceDate','queueDate'].forEach(id=>{if($(id)&&!$(id).value)$(id).value=today()});renderBookings();renderWaitlist();renderAttendance();renderHourlyAttendance();renderOperations();renderQueue();renderExpenses();renderReports();renderArchive();renderPatients();renderDashboard();renderCalendar()}
$('bookingDate').value=today();$('attendanceDate').value=today();if($('queueDate'))$('queueDate').value=today();if($('dashboardDate'))$('dashboardDate').value=today();setupAutoBackup();applyZoom();renderAll();


function setExamEntry(id,enter){const b=state.bookings.find(x=>x.id===id);if(!b)return;if(enter&&b.attendanceStatus!=='attended'){alert('سجّل حضور المريض أولًا.');return}commit(()=>{b.examEnteredAt=enter?Date.now():null});renderAttendance();renderQueue()}
function findExistingPatient(){const term=prompt('اكتب جزءًا من اسم المريض للبحث في السجل:');if(!term)return;const key=term.trim().toLowerCase();const map=new Map();(state.bookings||[]).filter(b=>!b.archived&&b.name&&String(b.name).toLowerCase().includes(key)).sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).forEach(b=>{const k=String(b.name).trim().toLowerCase();if(!map.has(k))map.set(k,b)});const matches=[...map.values()].slice(0,30);if(!matches.length){alert('لا يوجد مريض بهذا الاسم في السجل. يمكنك تسجيله كمريض جديد.');return}const choice=prompt('اختر رقم المريض:\n'+matches.map((b,i)=>`${i+1}- ${b.name} — ${b.phone||'بدون هاتف'}`).join('\n'));const i=Number(choice)-1;if(!Number.isInteger(i)||!matches[i])return;$('bName').value=matches[i].name;$('bPhone').value=matches[i].phone||'';bookingDuplicateHint()}
function renderQueue(){const d=$('queueDate')?.value||today();if($('queueDate')&&!$('queueDate').value)$('queueDate').value=d;const rows=state.bookings.filter(b=>!b.archived&&b.date===d&&b.attendanceStatus==='attended').slice().sort((a,b)=>(+a.attendanceNo||999999)-(+b.attendanceNo||999999)||(a.attendedAt||0)-(b.attendedAt||0));const entered=rows.filter(b=>b.examEnteredAt).sort((a,b)=>(b.examEnteredAt||0)-(a.examEnteredAt||0))[0];const next=rows.find(b=>!b.examEnteredAt);const set=(id,val)=>{const el=$(id);if(el)el.textContent=val};set('queueCurrentNo',entered?(entered.attendanceNo||'—'):'—');set('queueCurrentName',entered?entered.name:'لا يوجد مريض مسجل دخوله');set('queueCurrentTime',entered?'دخل الكشف '+displayDateTime(entered.examEnteredAt):'');set('queueNextNo',next?(next.attendanceNo||'—'):'—');set('queueNextName',next?next.name:'لا يوجد مريض في الانتظار');set('queueNextTime',next?'مسلسل الحضور '+(next.attendanceNo||'—'):'');const waiting=rows.filter(b=>!b.examEnteredAt);const box=$('queueList');if(box)box.innerHTML=waiting.map(b=>`<div class="queue-row"><b>الحضور ${b.attendanceNo||'—'}</b><strong>${esc(b.name)}</strong><span>${displayTime(b.time)} · ${esc(b.phone||'')}</span><button class="primary" onclick="setExamEntry('${b.id}',true)">إدخال للكشف</button></div>`).join('')||'<div class="empty">لا يوجد مرضى حاضرون في الانتظار.</div>'}
function openSurgeryModal(id=''){pendingSurgeryPhoto='';window.removeSurgeryPhoto=false;const x=id?state.surgeries.find(s=>s.id===id):null;window.editingSurgeryId=id||'';$('modalTitle').textContent=x?'تعديل حالة عملية':'إضافة حالة عملية';$('modalBody').innerHTML=`<div class="form-grid"><label>اسم المريض<input id="sName" value="${esc(x?.name||'')}"></label><label>رقم الهاتف<input id="sPhone" type="tel" value="${esc(x?.phone||'')}"></label><label>اسم العملية<input id="sOperation" value="${esc(x?.operationName||'')}"></label><label>تاريخ الكشف<input id="sExamDate" type="date" value="${esc(x?.examDate||today())}"></label><label>اليوم المحدد للعملية<input id="sSurgeryDate" type="date" value="${esc(x?.surgeryDate||'')}"></label><div class="full"><label>صورة الحالة</label><input id="sPhoto" type="file" accept="image/*" capture="environment" onchange="previewSurgeryPhoto()" style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0"><button type="button" class="secondary" onclick="document.getElementById('sPhoto').click()">📷 إضافة صورة من الهاتف</button><span class="muted">اختار صورة من المعرض أو التقط صورة بالكاميرا، والصورة اختيارية.</span></div><div class="full surgery-photo-preview" id="sPhotoPreview">${x?.photo?`<img src="${x.photo}" alt="صورة الحالة">`:'لم يتم إرفاق صورة'}</div><div class="full" id="sPhotoActions">${x?.photo?'<button type="button" class="danger ghost" onclick="removeSurgeryPhoto()">حذف الصورة الحالية</button>':''}</div></div><div class="modal-actions"><button type="button" class="primary" onclick="saveSurgery()">حفظ الحالة</button><button type="button" class="ghost" data-modal-action="close">إلغاء</button>${x?`<button type="button" class="danger ghost" onclick="deleteSurgery('${x.id}')">حذف الحالة</button>`:''}</div>`;$('modal').classList.remove('hidden')}
let pendingSurgeryPhoto='';
function removeSurgeryPhoto(){pendingSurgeryPhoto='';window.removeSurgeryPhoto=true;const box=$('sPhotoPreview');if(box)box.textContent='تم حذف الصورة — احفظ التعديل لتأكيد الحذف';const actions=$('sPhotoActions');if(actions)actions.innerHTML='';}
function previewSurgeryPhoto(){const input=$('sPhoto'),file=input?.files?.[0];if(!file)return;if(!file.type||!file.type.startsWith('image/')){alert('اختار ملف صورة فقط.');return}const reader=new FileReader();reader.onerror=()=>alert('تعذر فتح الصورة. جرّب اختيارها من المعرض مرة أخرى.');reader.onload=()=>{const img=new Image();img.onerror=()=>alert('صيغة الصورة غير مدعومة. جرّب صورة JPG أو PNG.');img.onload=()=>{const max=800,scale=Math.min(1,max/Math.max(img.width,img.height)),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));const ctx=canvas.getContext('2d');if(!ctx){alert('تعذر تجهيز الصورة على هذا الجهاز.');return}ctx.drawImage(img,0,0,canvas.width,canvas.height);pendingSurgeryPhoto=canvas.toDataURL('image/jpeg',.58);window.removeSurgeryPhoto=false;const box=$('sPhotoPreview');if(box)box.innerHTML=`<img src="${pendingSurgeryPhoto}" alt="معاينة صورة الحالة">`;const actions=$('sPhotoActions');if(actions)actions.innerHTML='<button type="button" class="danger ghost" onclick="removeSurgeryPhoto()">إلغاء الصورة</button>'};img.src=reader.result};try{reader.readAsDataURL(file)}catch(e){alert('تعذر قراءة الصورة من الهاتف.')}}
function saveSurgery(){const id=window.editingSurgeryId||'',old=id?state.surgeries.find(s=>s.id===id):null;const name=$('sName')?.value.trim()||'',phone=$('sPhone')?.value.trim()||'',operationName=$('sOperation')?.value.trim()||'',examDate=$('sExamDate')?.value||'',surgeryDate=$('sSurgeryDate')?.value||'';if(!name||!phone||!operationName||!examDate){alert('أكمل الاسم ورقم الهاتف واسم العملية وتاريخ الكشف. موعد العملية اختياري.');return}try{const photo=window.removeSurgeryPhoto?'':(pendingSurgeryPhoto||old?.photo||'');commit(()=>{const row={id:id||uid(),name,phone,operationName,examDate,surgeryDate,photo,createdAt:old?.createdAt||Date.now()};if(old)Object.assign(old,row);else state.surgeries.push(row)});pendingSurgeryPhoto='';window.removeSurgeryPhoto=false;closeModal();renderOperations()}catch(e){alert('تعذر حفظ الحالة. جرّب صورة أصغر أو احفظ الحالة بدون صورة.');console.error(e)}}
function deleteSurgery(id){if(!confirm('هل تريد حذف سجل العملية؟'))return;commit(()=>state.surgeries=state.surgeries.filter(s=>s.id!==id));closeModal();renderOperations()}
function renderOperations(){const box=$('operationsTable');if(!box)return;box.innerHTML=state.surgeries.slice().sort((a,b)=>String(a.surgeryDate||'9999-99-99').localeCompare(String(b.surgeryDate||'9999-99-99'))||(a.createdAt||0)-(b.createdAt||0)).map((x,i)=>`<tr><td>${i+1}</td><td><strong>${esc(x.name)}</strong></td><td>${esc(x.phone)}</td><td>${esc(x.operationName)}</td><td>${fmtDate(x.examDate)}</td><td>${x.surgeryDate?fmtDate(x.surgeryDate):'غير محدد'}</td><td>${x.photo?`<button type="button" class="secondary" onclick="viewSurgeryPhoto('${x.id}')">عرض الصورة</button>`:'—'}</td><td><div class="small-actions"><button type="button" class="secondary" onclick="openSurgeryModal('${x.id}')">تعديل</button><button type="button" class="danger ghost" onclick="deleteSurgery('${x.id}')">حذف</button></div></td></tr>`).join('')||'<tr><td colspan="8" class="empty">لا توجد حالات عمليات مسجلة.</td></tr>'}
function viewSurgeryPhoto(id){const x=state.surgeries.find(s=>s.id===id);if(!x?.photo)return;const w=window.open('','_blank');if(!w){alert('اسمح بفتح نافذة الصورة من إعدادات المتصفح.');return}w.document.write(`<html dir="rtl"><head><title>صورة الحالة</title><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;padding:12px;background:#f3f6fa;display:grid;place-items:center}img{max-width:100%;max-height:95vh;object-fit:contain}</style></head><body><img src="${x.photo}" alt="صورة الحالة"></body></html>`);w.document.close()}

