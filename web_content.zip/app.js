const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const KEY='fitteez_finance_records_v1';
let records=JSON.parse(localStorage.getItem(KEY)||'[]'), reminders=JSON.parse(localStorage.getItem('fitteez_reminders_v1')||'[]');
let budget=Number(localStorage.getItem('fitteez_budget_v1')||0), profileName=localStorage.getItem('fitteez_profile_v1')||'Fitteez Fashion';
const money=n=>'Rs. '+Number(n||0).toLocaleString('en-PK',{maximumFractionDigits:2});
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function notify(m){let t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
function save(){localStorage.setItem(KEY,JSON.stringify(records));render()}
function sums(){let i=0,e=0;records.forEach(r=>r.type==='income'?i+=+r.amount:e+=+r.amount);return {i,e,b:i-e}}
function dateFmt(d){return new Date(d+'T00:00:00').toLocaleDateString('en-US',{month:'short',day:'2-digit',year:'numeric'})}
function render(){
 const s=sums();$('#balance').textContent=money(s.b);$('#income').textContent=money(s.i);$('#expense').textContent=money(s.e);
 const sorted=[...records].sort((a,b)=>b.date.localeCompare(a.date)||b.created-a.created);
 $('#recentList').innerHTML=sorted.slice(0,5).map(rowRecent).join('')||'<div class="empty">No transactions yet. Add your first entry.</div>';
 $('#allRows').innerHTML=sorted.filter(r=>matches(r)).map((r)=>`<tr><td>${dateFmt(r.date)}</td><td>${esc(r.description)}</td><td>${esc(r.account)}</td><td class="positive">${r.type==='income'?money(r.amount):'—'}</td><td class="negative">${r.type==='expense'?money(r.amount):'—'}</td><td>${r.proof?`<button class="proof-btn" data-proof="${r.id}">View proof ↗</button>`:'—'}</td><td><button class="proof-btn" data-delete="${r.id}">Delete</button></td></tr>`).join('');
 $('#emptyRows').style.display=sorted.some(matches)?'none':'block';
 let running=0;const chronological=[...records].sort((a,b)=>a.date.localeCompare(b.date)||a.created-b.created);
 const balances=new Map();chronological.forEach(r=>{running+=(r.type==='income'?1:-1)*Number(r.amount);balances.set(r.id,running)});
 $('#sheetRows').innerHTML=chronological.map((r,i)=>`<tr><td>${i+1}</td><td>${dateFmt(r.date)}</td><td>${esc(r.description)}</td><td>${esc(r.account)}</td><td>${r.type==='income'?Number(r.amount).toLocaleString('en-PK'):'—'}</td><td>${r.type==='expense'?Number(r.amount).toLocaleString('en-PK'):'—'}</td><td>${money(balances.get(r.id))}</td></tr>`).join('');
 $('#reportStats').innerHTML=`<div class="stat balance"><div class="stat-label">Net balance</div><strong>${money(s.b)}</strong></div><div class="stat income"><div class="stat-label">Income</div><strong>${money(s.i)}</strong></div><div class="stat expense"><div class="stat-label">Expenses</div><strong>${money(s.e)}</strong></div>`;
 let cats={};records.filter(r=>r.type==='expense').forEach(r=>cats[r.account]=(cats[r.account]||0)+Number(r.amount));
 $('#expenseBreakdown').innerHTML=Object.keys(cats).length?Object.entries(cats).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="provider-mini"><b>${esc(k)}</b><span class="connect-state">${money(v)}</span></div>`).join(''):'Add expenses to see a breakdown.';
 drawChart();renderReminders();$('#budgetInput').value=budget||'';$('#budgetStatus').textContent=budget?`Spent ${money(s.e)} of ${money(budget)} (${Math.round(s.e/budget*100)}%).`:'No monthly budget set.';
}
function rowRecent(r){return `<div class="recent-item"><span class="tx-icon ${r.type==='income'?'in':'out'}">${r.type==='income'?'↓':'↑'}</span><div class="recent-main"><b>${esc(r.description)}</b><small>${esc(r.account)} · ${dateFmt(r.date)}</small></div><span class="tx-amount ${r.type==='income'?'in':'out'}">${r.type==='income'?'+':'−'}${money(r.amount)}</span></div>`}
function matches(r){let f=$('#filter')?.value||'all',q=($('#search')?.value||'').toLowerCase();return(f==='all'||r.type===f)&&(!q||[r.description,r.account,r.date].join(' ').toLowerCase().includes(q))}
function drawChart(){let list=records.filter(r=>$('#chartPeriod').value!=='month'||r.date.slice(0,7)===new Date().toISOString().slice(0,7));let by={};list.forEach(r=>{let k=r.date.slice(0,7);by[k]??={i:0,e:0};by[k][r.type==='income'?'i':'e']+=Number(r.amount)});let vals=Object.entries(by).sort().slice(-6);if(!vals.length){$('#chart').innerHTML='<div class="chart-empty">Add transactions to see your cash flow.</div>';return}let max=Math.max(1,...vals.flatMap(x=>[x[1].i,x[1].e]));$('#chart').innerHTML=vals.map(([k,v])=>`<div class="month-bars" title="${k}: Income ${money(v.i)}, Expenses ${money(v.e)}"><div class="bar in" style="height:${Math.max(3,v.i/max*90)}%"></div><div class="bar out" style="height:${Math.max(3,v.e/max*90)}%"></div></div>`).join('')}
function openModal(type='income'){ $('#modal').classList.add('show');setType(type);$('#date').value=new Date().toISOString().slice(0,10)}
function setType(t){$('#type').value=t;$$('.type-tabs button').forEach(b=>b.classList.toggle('selected',b.dataset.type===t))}
$('#addTop').onclick=$('#addTransactions').onclick=()=>openModal();$('#mobileAdd').onclick=()=>openModal();$('#close').onclick=()=>$('#modal').classList.remove('show');$('#modal').onclick=e=>{if(e.target.id==='modal')$('#modal').classList.remove('show')};$$('.type-tabs button').forEach(b=>b.onclick=()=>setType(b.dataset.type));
$('#entryForm').onsubmit=async e=>{e.preventDefault();let file=$('#proof').files[0],proof='';if(file){if(file.size>1.5*1024*1024){notify('Please choose a screenshot under 1.5 MB.');return}proof=await new Promise((res,rej)=>{let rd=new FileReader();rd.onload=()=>res(rd.result);rd.onerror=rej;rd.readAsDataURL(file)})}
records.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),type:$('#type').value,amount:Number($('#amount').value),description:$('#description').value.trim(),account:$('#account').value,date:$('#date').value,proof,created:Date.now()});try{localStorage.setItem(KEY,JSON.stringify(records))}catch(err){notify('Storage full. Try a smaller screenshot.');records.pop();return}$('#entryForm').reset();$('#modal').classList.remove('show');render();notify('Transaction saved.');};
$('#search').oninput=render;$('#filter').onchange=render;$('#chartPeriod').onchange=drawChart;
document.addEventListener('click',e=>{let d=e.target.closest('[data-delete]');if(d){if(confirm('Delete this transaction?')){records=records.filter(r=>r.id!==d.dataset.delete);save();notify('Transaction deleted.')}}let p=e.target.closest('[data-proof]');if(p){let r=records.find(x=>x.id===p.dataset.proof);if(r?.proof){let w=window.open();if(w)w.document.write(`<img src="${r.proof}" style="max-width:100%;height:auto">`);else notify('Allow pop-ups to view proof.')}}});
function exportCSV(){let rows=[['Date','Description','Account','Type','Amount (PKR)'],...records.map(r=>[r.date,r.description,r.account,r.type,r.amount])];let csv=rows.map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\\n');download(new Blob([csv],{type:'text/csv'}),'fitteez-transactions.csv')}
$('#exportCsv').onclick=$('#sheetExport').onclick=exportCSV;
function download(blob,name){let a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();URL.revokeObjectURL(a.href)}
$('#backup').onclick=()=>download(new Blob([JSON.stringify({records,reminders,budget,profileName},null,2)],{type:'application/json'}),'fitteez-backup.json');
$('#clearData').onclick=()=>{if(confirm('Permanently delete all transactions and reminders saved in this browser?')){records=[];reminders=[];localStorage.removeItem(KEY);localStorage.removeItem('fitteez_reminders_v1');render();notify('Local records cleared.')}};
$('#saveBudget').onclick=()=>{budget=Number($('#budgetInput').value)||0;localStorage.setItem('fitteez_budget_v1',budget);render();notify('Budget saved.')};
$('#saveProfile').onclick=()=>{profileName=$('#profileName').value.trim()||'Fitteez Fashion';localStorage.setItem('fitteez_profile_v1',profileName);notify('Profile saved.')};
$('#reminderForm').onsubmit=e=>{e.preventDefault();reminders.push({text:$('#reminderText').value,date:$('#reminderDate').value,done:false});localStorage.setItem('fitteez_reminders_v1',JSON.stringify(reminders));e.target.reset();renderReminders();notify('Reminder saved.')};
function renderReminders(){$('#reminderList').innerHTML=reminders.map((r,i)=>`<div class="provider-mini"><span>${r.done?'✓':'◷'}</span><div><b>${esc(r.text)}</b><small>${dateFmt(r.date)}</small></div><button class="proof-btn" data-rem="${i}">${r.done?'Undo':'Done'}</button></div>`).join('')||'<div class="empty">No reminders yet.</div>'}
document.addEventListener('click',e=>{let b=e.target.closest('[data-rem]');if(b){let i=+b.dataset.rem;reminders[i].done=!reminders[i].done;localStorage.setItem('fitteez_reminders_v1',JSON.stringify(reminders));renderReminders()}});
const providers=[
 ['jazz','JazzCash Business','J','jazz','Official merchant integration required'],
 ['easy','Easypaisa Business','e','easy','Official merchant integration required'],
 ['sada','SadaPay','S','sada','Provider access must be confirmed'],
 ['naya','NayaPay','N','sada','Provider access must be confirmed'],
 ['bank','Bank account','▤','bank','Bank-by-bank integration approval required'],
 ['other','Other payment account','＋','bank','Manual tracking setup available']
];
const CONNECTION_KEY='business_expenses_payment_profiles_v1';
let paymentProfiles=JSON.parse(localStorage.getItem(CONNECTION_KEY)||'{}');
function renderProviders(){
 $('#providerGrid').innerHTML=providers.map(p=>{
   const saved=paymentProfiles[p[0]];
   return `<article class="provider-card"><span class="provider-logo ${p[3]}">${p[2]}</span><h3>${p[1]}</h3>
   <p>${saved?`Tracking profile: ${esc(saved.name)}${saved.last4?' · •••• '+esc(saved.last4):''}`:p[4]}</p>
   <button type="button" data-connect="${p[0]}">${saved?'Edit account setup':'Set up account'}</button>
   ${saved?'<small class="hint">Manual tracking profile saved on this device</small>':''}</article>`;
 }).join('');
}
function openConnection(provider){
 const p=providers.find(x=>x[0]===provider); if(!p)return;
 const saved=paymentProfiles[provider]||{};
 $('#connectionProvider').value=provider;
 $('#connectionTitle').textContent=p[1];
 $('#connectionName').value=saved.name||p[1];
 $('#connectionHolder').value=saved.holder||'';
 $('#connectionLast4').value=saved.last4||'';
 $('#connectionNotes').value=saved.notes||'';
 $('#connectionRemove').style.display=saved.name?'block':'none';
 $('#connectionModal').classList.add('show');
}
$('#providerGrid').addEventListener('click',e=>{
 const b=e.target.closest('[data-connect]'); if(b)openConnection(b.dataset.connect);
});
$('#connectionClose').onclick=()=>$('#connectionModal').classList.remove('show');
$('#connectionModal').onclick=e=>{if(e.target.id==='connectionModal')$('#connectionModal').classList.remove('show')};
$('#connectionForm').onsubmit=e=>{
 e.preventDefault(); const key=$('#connectionProvider').value;
 paymentProfiles[key]={name:$('#connectionName').value.trim(),holder:$('#connectionHolder').value.trim(),last4:$('#connectionLast4').value.trim(),notes:$('#connectionNotes').value.trim()};
 localStorage.setItem(CONNECTION_KEY,JSON.stringify(paymentProfiles));
 $('#connectionModal').classList.remove('show');renderProviders();notify('Account tracking setup saved on this device.');
};
$('#connectionRemove').onclick=()=>{
 const key=$('#connectionProvider').value;
 if(confirm('Remove this saved account tracking profile?')){
   delete paymentProfiles[key];localStorage.setItem(CONNECTION_KEY,JSON.stringify(paymentProfiles));
   $('#connectionModal').classList.remove('show');renderProviders();notify('Account setup removed.');
 }
};
renderProviders();
function parseVoice(text){let m=text.match(/([\\d,]+(?:\\.\\d{1,2})?)/);if(!m){notify('Please include the amount.');return}let low=text.toLowerCase(),type=/(paid|spent|gave|expense|خرچ|دیا|دیے|بھیجے|ادا)/i.test(low)?'expense':'income';openModal(type);$('#amount').value=Number(m[1].replace(/,/g,''));$('#description').value=text;let a=['jazzcash','jazz cash','easypaisa','sadapay','nayapay','bank','cash'].find(x=>low.includes(x));if(a){let map={'jazzcash':'JazzCash','jazz cash':'JazzCash','easypaisa':'Easypaisa','sadapay':'SadaPay','nayapay':'NayaPay','bank':'Bank','cash':'Cash'};$('#account').value=map[a]}notify('Check the prepared entry, then save it.')}
function attachAssistant(inputId,buttonId){$('#'+buttonId).onclick=()=>{let v=$('#'+inputId).value.trim();if(v)parseVoice(v);else notify('Type a transaction first.')}}
attachAssistant('voiceText','prepare');attachAssistant('voiceText2','prepare2');
function voice(inputId){let SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){notify('Voice input is not supported here. Try Chrome.');return}let rec=new SR();rec.lang='ur-PK';rec.onresult=e=>{$('#'+inputId).value=e.results[0][0].transcript;notify('Speech captured. Review the words.')};rec.onerror=()=>notify('Microphone permission or voice input failed.');rec.start()}
$('#mic').onclick=()=>voice('voiceText');$('#mic2').onclick=()=>voice('voiceText2');
$$('[data-page]').forEach(b=>b.onclick=()=>showPage(b.dataset.page));$$('[data-goto]').forEach(b=>b.onclick=()=>showPage(b.dataset.goto));
function showPage(id){$$('.page').forEach(p=>p.classList.toggle('active',p.id===id));$$('.nav').forEach(n=>n.classList.toggle('active',n.dataset.page===id));$('#crumb').textContent=id[0].toUpperCase()+id.slice(1);window.scrollTo(0,0)}
$('#themeBtn').onclick=()=>{document.body.classList.toggle('light');notify('Theme preview toggled.')}
$('#today').textContent=new Date().toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric'}).toUpperCase();
$('#profileName').value=profileName;render();