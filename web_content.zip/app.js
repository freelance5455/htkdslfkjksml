const CONFIGS = Object.freeze({
  de1: "vless://50414e45-4c5f-5a45-5553-c2bbb1086aa3@t7z3veexut1s.g6z4uxe4ucms.workers.dev:80?path=%2Fstream%2FPANEL_ZEUS%2Fc2bbb1086aa3&security=none&encryption=none&host=t7z3veexut1s.g6z4uxe4ucms.workers.dev&type=ws#MoonVpn",
  de2: "vless://50414e45-4c5f-5a45-5553-c2bbb1086aa3@t7z3veexut1s.g6z4uxe4ucms.workers.dev:443?path=%2Fstream%2FPANEL_ZEUS%2Fc2bbb1086aa3&security=tls&encryption=none&insecure=0&host=t7z3veexut1s.g6z4uxe4ucms.workers.dev&type=ws&allowInsecure=0&sni=t7z3veexut1s.g6z4uxe4ucms.workers.dev#MoonVpn2",
  de3: "vless://50414e45-4c5f-5a45-5553-c2bbb1086aa3@t7z3veexut1s.g6z4uxe4ucms.workers.dev:443?path=%2Fstream%2FPANEL_ZEUS%2Fc2bbb1086aa3%2Floc-0&security=tls&encryption=none&insecure=0&host=t7z3veexut1s.g6z4uxe4ucms.workers.dev&type=ws&allowInsecure=0&sni=t7z3veexut1s.g6z4uxe4ucms.workers.dev#moonvpn3"
});

const servers=[
 {id:"de1",name:"آلمان ۱",meta:"VLESS • WS • بدون TLS",flag:"🇩🇪"},
 {id:"de2",name:"آلمان ۲",meta:"VLESS • WS • TLS",flag:"🇩🇪"},
 {id:"de3",name:"آلمان ۳",meta:"VLESS • WS • TLS",flag:"🇩🇪"}
];
let selected=localStorage.getItem("selectedServer")||"de1";
let connected=false, seconds=0, timer=null;
let personal=JSON.parse(localStorage.getItem("personalServers")||"[]");

const screen=document.getElementById("screen");
const toastEl=document.getElementById("toast");
function toast(t){toastEl.textContent=t;toastEl.classList.add("show");setTimeout(()=>toastEl.classList.remove("show"),1800)}
function nav(page){
 document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
 ({connect:renderConnect,servers:renderServers,personal:renderPersonal,settings:renderSettings}[page])();
}
function renderConnect(){
 const s=servers.find(x=>x.id===selected)||servers[0];
 const time=String(Math.floor(seconds/60)).padStart(2,"0")+":"+String(seconds%60).padStart(2,"0");
 screen.innerHTML=`<section class="connect-page">
  <div class="power-wrap"><button class="power" id="powerBtn">
   <div class="power-icon">⏻</div><div class="status">${connected?"متصل":"اتصال"}</div>
   <div class="substatus">${connected?time:"برای اتصال لمس کنید"}</div>
  </button></div>
  <div class="info-pill">${connected?"وصل":"قطع"} ●</div>
  <div class="server-card selected" id="currentServer"><div class="row">
   <div><div class="server-name">${s.flag} ${s.name}</div><div class="server-meta">${s.meta}</div></div><span class="select-dot"></span>
  </div></div>
  <div class="section-note">سرور را از بخش «سرورها» انتخاب کنید.</div>
 </section>`;
 document.getElementById("powerBtn").onclick=toggleConnection;
 document.getElementById("currentServer").onclick=()=>nav("servers");
}
function toggleConnection(){
 connected=!connected;
 if(connected){seconds=0;clearInterval(timer);timer=setInterval(()=>{seconds++;renderConnect()},1000);toast("اتصال فعال شد")}
 else{clearInterval(timer);toast("اتصال قطع شد")}
 renderConnect();
}
function renderServers(){
 screen.innerHTML=`<h1 class="page-title">سرورها</h1>
 <div class="section-note">کانفیگ‌های داخلی پنهان هستند و در رابط کاربری نمایش یا کپی نمی‌شوند.</div>
 ${servers.map(s=>`<button class="server-card ${s.id===selected?"selected":""}" data-id="${s.id}" style="width:100%;color:inherit;text-align:right">
  <div class="row"><div class="row"><span class="flag">${s.flag}</span><div><div class="server-name">${s.name}</div><div class="server-meta">${s.meta}</div></div></div><span class="select-dot"></span></div>
 </button>`).join("")}`;
 document.querySelectorAll("[data-id]").forEach(b=>b.onclick=()=>{selected=b.dataset.id;localStorage.setItem("selectedServer",selected);toast("سرور انتخاب شد");renderServers()});
}
function renderPersonal(){
 screen.innerHTML=`<h1 class="page-title">سرورهای شخصی</h1>
 <div class="section-note">کانفیگ شخصی خودت را اضافه کن. مقدار VLESS در لیست سرورها نمایش داده نمی‌شود.</div>
 <div class="personal-card">
  <input class="input" id="pname" placeholder="نام سرور">
  <textarea class="input" id="pconfig" placeholder="VLESS / VMess / Trojan ..."></textarea>
  <button class="btn" id="addPersonal" style="margin-top:12px;width:100%">＋ افزودن سرور</button>
 </div>
 ${personal.length?personal.map((p,i)=>`<div class="server-card"><div class="row">
   <div><div class="server-name">🔒 ${escapeHtml(p.name)}</div><div class="server-meta">کانفیگ مخفی</div></div>
   <button class="btn secondary" data-del="${i}">حذف</button>
 </div></div>`).join(""):`<div class="empty">هنوز سرور شخصی اضافه نشده است.</div>`}`;
 document.getElementById("addPersonal").onclick=()=>{
  const name=document.getElementById("pname").value.trim(), config=document.getElementById("pconfig").value.trim();
  if(!name||!config)return toast("نام و کانفیگ را وارد کنید");
  personal.push({name,config});localStorage.setItem("personalServers",JSON.stringify(personal));toast("سرور اضافه شد");renderPersonal();
 };
 document.querySelectorAll("[data-del]").forEach(b=>b.onclick=()=>{personal.splice(+b.dataset.del,1);localStorage.setItem("personalServers",JSON.stringify(personal));renderPersonal()});
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function renderSettings(){
 const vals=JSON.parse(localStorage.getItem("settings")||"{}");
 screen.innerHTML=`<h1 class="page-title">تنظیمات</h1>
 ${setting("auto","اتصال خودکار","هنگام اجرای برنامه",vals.auto)}
 ${setting("kill","Kill Switch","جلوگیری از ترافیک خارج از تونل",vals.kill)}
 ${setting("dns","DNS امن","استفاده از DNS سفارشی",vals.dns)}
 <div class="setting"><div class="row"><div><b>درباره</b><div class="server-meta">MoonVPN Mobile UI</div></div><span>›</span></div></div>`;
 document.querySelectorAll(".switch").forEach(sw=>sw.onclick=()=>{const k=sw.dataset.key;vals[k]=!vals[k];localStorage.setItem("settings",JSON.stringify(vals));renderSettings()});
}
function setting(key,title,desc,on){return `<div class="setting"><div class="row"><div><b>${title}</b><div class="server-meta">${desc}</div></div><span class="switch ${on?"on":""}" data-key="${key}"><i></i></span></div></div>`}
document.querySelectorAll(".nav-item").forEach(x=>x.onclick=()=>nav(x.dataset.page));
document.getElementById("refreshBtn").onclick=()=>{toast("بروزرسانی شد");nav(document.querySelector(".nav-item.active").dataset.page)}
document.getElementById("menuBtn").onclick=()=>toast("منوی سریع");
renderConnect();
