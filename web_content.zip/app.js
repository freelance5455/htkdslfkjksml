const icons = {
  grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  dumbbell:'<path d="M6 5h2v14H6zM16 5h2v14h-2zM3 8h3v8H3zM18 8h3v8h-3zM8 12h8M1 12h2m18 0h2"/>',
  book:'<path d="M5 3h14v18H6a3 3 0 0 1 0-6h13M5 3v12M9 7h6m-6 4h4"/>',
  chart:'<path d="M3 3v18h18M7 15l5-5 3 3 6-8m-5 0h5v5"/>',
  trophy:'<path d="M8 3h8v8a4 4 0 0 1-8 0V3ZM8 5H4v2a4 4 0 0 0 4 4m8-6h4v2a4 4 0 0 1-4 4m-4 4v5m-4 0h8"/>',
  target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  layers:'<path d="m12 3 9 5-9 5-9-5 9-5Zm-9 9 9 5 9-5M3 16l9 5 9-5"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  arrow:'<path d="M4 12h15m-6-6 6 6-6 6"/>',
  up:'<path d="M5 16 16 5m-8 0h8v8"/>',
  chevron:'<path d="m6 9 6 6 6-6"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  edit:'<path d="m15 5 4 4M4 20l4-1 12-12-4-4L4 15v5Z"/>',
  trash:'<path d="M4 7h16M6 7l1 13h10l1-13M9 7V4h6v3m-5 3v6m4-6v6"/>',
  close:'<path d="m6 6 12 12M6 18 18 6"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8v.1"/>',
  star:'<path d="m12 3 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1-4.4-4.3 6.1-.9L12 3Z"/>',
  play:'<path d="M8 4v16l12-8L8 4Z"/>',
  archive:'<rect x="4" y="3" width="16" height="5" rx="1"/><path d="M5 8v12h14V8m-9 4h4"/>',
  download:'<path d="M12 3v12m-4-4 4 4 4-4M4 17v4h16v-4"/>',
  check:'<path d="m5 12 4 4L19 6"/>',
  sliders:'<path d="M4 6h7m4 0h5M4 12h12m4 0h0M4 18h3m4 0h9"/><circle cx="13" cy="6" r="2"/><circle cx="18" cy="12" r="2"/><circle cx="9" cy="18" r="2"/>',
};
const icon = (name, size=20) => `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||''}</svg>`;
const $ = (sel, root=document) => root.querySelector(sel);
const esc = value => String(value).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num = n => new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}).format(n);
const key = name => name.trim().replace(/\s+/g,' ').toLocaleLowerCase('fr');
const localDay = (delta=0) => { const d = new Date(); d.setDate(d.getDate()+delta); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const dateObj = day => new Date(`${day}T12:00:00`);
const dateLabel = (day, full=false) => new Intl.DateTimeFormat('fr-FR',{day:'numeric',month:full?'long':'short',...(full&&dateObj(day).getFullYear()!==new Date().getFullYear()?{year:'numeric'}:{})}).format(dateObj(day));
const working=e=>e.sets.filter(s=>s.kind!=='warmup');
const analysisEntry=e=>({...e,sets:working(e)});
const maxLoad = e => Math.max(0,...working(e).map(s=>s.kg));
const work = e => working(e).reduce((t,s)=>t+s.reps*s.kg,0);
const unit=e=>e?.loadMode==='dumbbell'?'kg / haltère':'kg';
const dateSort = (a,b) => b.date.localeCompare(a.date) || b.timestamp-a.timestamp;
const base = ['Développé couché','Squat','Soulevé de terre','Presse à cuisses','Développé militaire','Tirage vertical','Rowing','Curl haltères'];
const demo = [
  ...[[28,50,[10,9,8]],[22,52.5,[10,9,8]],[16,55,[10,9,9]],[9,60,[10,10,9]],[5,62.5,[12,12,12]],[2,62.5,[12,12,12]]].map(([ago,kg,reps])=>[ago,base[0],kg,reps,10,12,2.5]),
  ...[[18,70,[8,7,7]],[10,75,[8,7,6]],[3,80,[7,7,6]]].map(([ago,kg,reps])=>[ago,base[1],kg,reps,6,8,2.5]),
  ...[[14,85,[7,6,6]],[6,90,[7,7,6]],[1,95,[6,6,5]]].map(([ago,kg,reps])=>[ago,base[2],kg,reps,6,8,2.5]),
].map(([ago,exercise,kg,reps,min,max,step],i)=>({id:`demo-${i}`,date:localDay(-ago),timestamp:i,exercise,sets:reps.map(reps=>({kg,reps})),min,max,step,effort:'ok'}));
const standardLook={theme:'dark',accent:'lime',density:'relaxed'};
const lookChoices={
  theme:[['dark','Sombre'],['light','Clair'],['system','Appareil']],
  accent:[['lime','Citron vert'],['ice','Bleu glacier'],['peach','Pêche']],
  density:[['relaxed','Aéré'],['compact','Compact']],
};
const prefersDark=matchMedia('(prefers-color-scheme: dark)');
const portable=$('#forge-snapshot')?JSON.parse($('#forge-snapshot').textContent):null;
const state = {data:[], programs:[], favorites:[], profiles:[], draft:null, mode:'demo', view:'home', exercise:base[0], period:30, loading:true, error:'',look:{...standardLook},previewLook:null, savingLook:false};
function showLook(){
  const look=state.previewLook||state.look, root=document.documentElement;
  root.dataset.theme=look.theme==='system'?(prefersDark.matches?'dark':'light'):look.theme;
  root.dataset.accent=look.accent;
  root.dataset.density=look.density;
  $('meta[name="theme-color"]')?.setAttribute('content',root.dataset.theme==='light'?'#f5f6ef':'#10110f');
}
prefersDark.addEventListener('change',showLook);
const remote = $('meta[name="forge-api"]')?.content||'';
const endpoint = (remote.startsWith('__PORT_') ? '' : remote.replace(/\/$/,''))+'/api';
async function request(path,options={}) {
  if(portable)return portableRequest(path,options);
  const r = await fetch(`${endpoint}${path}`, {cache:'no-store', ...options});
  const data = await r.json().catch(()=>null);
  if (!r.ok || !data) throw new Error(data?.error || 'Connexion au carnet indisponible. Réessaie dans un instant.');
  return data;
}
const api = (path='',options={})=>request(`/entries${path}`,options);
const json = (method,value)=>({method,headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});
function applyCarnet(data){
  if(data.entries)state.data=data.entries;
  if(data.programs)state.programs=data.programs;
  if(data.favorites)state.favorites=data.favorites;
  if(data.profiles)state.profiles=data.profiles;
  if(data.appearance){state.look={...standardLook,...data.appearance};showLook();}
}
function entries(){ return (state.mode==='demo'?demo:state.data).slice().sort(dateSort); }
function exerciseNames(list){ return [...new Map(list.map(e=>[key(e.exercise),e.exercise])).values()]; }
function comparable(list,name){
  const selected=list.filter(e=>key(e.exercise)===key(name)&&working(e).length);
  const loadMode=selected[0]?.loadMode||'total';
  return selected.filter(e=>(e.loadMode||'total')===loadMode).map(analysisEntry);
}
function matching(list){ return comparable(list,state.exercise); }
function syncSelection() {
  const names = exerciseNames(entries());
  state.exercise = names.find(n=>key(n)===key(state.exercise)) || (state.mode==='demo'?base[0]:names[0]) || base[0];
}
const nav = [['home','grid','Vue d’ensemble','Accueil'],['progress','chart','Progression','Progrès'],['programs','play','Programmes','Programmes'],['history','book','Journal','Journal'],['data','archive','Données','Données']];
function closeLookPreview(){state.previewLook=null;showLook();}
function modeSwitch(mode) { state.mode=mode; state.exercise=base[0]; state.period=30; if(mode==='demo'&&['programs','data'].includes(state.view)){closeLookPreview();state.view='home';window.scrollTo(0,0);} syncSelection(); render(); }
function move(view) { if(view!=='data')closeLookPreview();state.view=view; if(['programs','data'].includes(view)&&state.mode==='demo'){state.mode='real';syncSelection();} render(); window.scrollTo(0,0); }
function setup(){
  $('#brand-icon').innerHTML=icon('dumbbell',22);
  $('#mobile-icon').innerHTML=icon('dumbbell',18);
  showLook();
  render();
  load(true);
}
async function load(initial=false) {
  if (!initial) { state.loading=true; render(); }
  try {
    const data=await request('/carnet');
    applyCarnet(data);state.error='';
    if(initial&&data.draft){state.draft=hydrateDraft(data.draft);if(data.draft.rest&&data.draft.rest.until>Date.now()){rest=data.draft.rest;refreshTimer();ticker=setInterval(refreshTimer,250);}}
    if(initial && (portable||state.draft||state.data.length||state.programs.length||state.favorites.length||state.profiles.length) && state.mode==='demo') { state.mode='real'; syncSelection(); }
  } catch (err) { state.error=err.message; }
  finally {state.loading=false; render();}
}
function order(consecutive,last) {
  return last && consecutive && consecutive.date < last.date && consecutive.min===last.min && consecutive.max===last.max &&
    consecutive.sets.length===last.sets.length && consecutive.sets.every(s=>s.kg===last.sets[0].kg);
}
function repetitionTarget(list){
  const last=list[0];
  if(!last||['hard','pain'].includes(last.effort)||last.sets.some(s=>s.kg!==last.sets[0].kg||s.reps<last.min))return null;
  const advice=tip(list);
  if(advice.from!==undefined)return {kg:advice.weight,reps:last.sets.map(()=>last.min),loadMode:last.loadMode};
  const reps=last.sets.map(s=>s.reps);
  const room=reps.map((rep,i)=>({rep,i})).filter(s=>s.rep<last.max).sort((a,b)=>b.rep-a.rep || a.i-b.i)[0];
  if(room)reps[room.i]++;
  return {kg:last.sets[0].kg,reps,loadMode:last.loadMode};
}
function plateau(list){
  const last=list[0];
  if(!last || ['hard','pain'].includes(last.effort)||last.sets.some(s=>s.kg<=0||s.kg!==last.sets[0].kg||s.reps<last.min)||tip(list).from!==undefined)return false;
  const days=[...new Map(list.slice().reverse().map(e=>[e.date,e])).values()].sort(dateSort).slice(0,3);
  return days.length===3 && days.slice(1).every(e=>order(e,last)&&!['hard','pain'].includes(e.effort)&&e.sets.every((s,i)=>s.reps===last.sets[i].reps));
}
function tip(list,pain=false) {
  const last=list[0];
  if(pain||last?.effort==='pain') return {tag:'DOULEUR SIGNALÉE',title:'Ne force pas sur cet exercice.',text:'Ne retente pas le mouvement s’il provoque une douleur. Si la douleur persiste ou revient, demande conseil à un professionnel de santé.',weight:null,icon:'info'};
  if(!last) return {tag:'PREMIÈRE SÉANCE',title:'Pose ton point de départ.',text:'Note les séries d’un exercice pour obtenir une suggestion à partir de tes résultats.',weight:null,icon:'target'};
  const kg=last.sets[0].kg;
  if(last.sets.some(s=>s.kg!==kg)) return {tag:'CHARGES DIFFÉRENTES',title:'Pas de hausse automatique.',text:'Tes séries ont des charges différentes. Pour comparer deux séances, note uniquement des séries de travail à charge identique, sans l’échauffement.',weight:null,icon:'layers'};
  const low=last.sets.some(s=>s.reps<last.min);
  if(low || last.effort==='hard') return {tag:'PRIORITÉ À LA TECHNIQUE',title:'N’augmente pas la charge.',text:low?`Certaines séries sont sous ton objectif de ${last.min} répétitions. Garde la charge si tu la contrôles, ou allège-la pour retrouver une exécution propre.`:'Tu as indiqué un effort à la limite. Garde la charge si tu la contrôles, ou allège-la si ta technique se dégrade.',weight:kg,icon:'target'};
  const prev=list.find(e=>e.date<last.date);
  const ready=e=>e.sets.every(s=>s.reps>=e.max)&&['easy','ok'].includes(e.effort);
  if(ready(last) && order(prev,last) && ready(prev)) {
    if(kg>0 && last.step<=kg*.05+1e-7 && kg+last.step<=999) return {tag:'HAUSSE ENVISAGEABLE',title:'Tu peux tenter le palier suivant.',text:`Toutes tes séries ont atteint ${last.max} répétitions sur deux séances comparables. Essaie de viser au moins ${last.min} répétitions sans forcer ni sacrifier la technique.`,weight:kg+last.step,from:kg,icon:'up'};
    return {tag:'PALIER TROP GRAND',title:'Garde la charge actuelle.',text:'Ton palier ne permet pas une petite hausse (5 % maximum dans l’appli). Attends d’avoir accès à un palier plus petit ou consolide ta technique.',weight:kg,icon:'target'};
  }
  return {tag:'OBJECTIF RÉPÉTITIONS',title:'Garde la charge actuelle.',text:ready(last)?'Ton objectif est atteint sur cette séance. Confirme-le une deuxième fois à la même charge avant d’envisager une hausse.':`Vise progressivement ${last.max} répétitions par série, tant que le mouvement reste bien contrôlé.`,weight:kg,icon:'target'};
}
function plates() {
  return `<svg class="hero-art" viewBox="0 0 440 260" fill="none" aria-hidden="true">
    <defs><pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M20 0H0v20" stroke="#a8b581" stroke-opacity=".15" stroke-width="1"/></pattern>
    <radialGradient id="metal" cx=".34" cy=".24" r=".8" gradientTransform="rotate(20)"><stop stop-color="#4b5239"/><stop offset="1" stop-color="#22271a"/></radialGradient>
    <linearGradient id="shaft" x1="0" y1="0" x2="0" y2="29" gradientUnits="userSpaceOnUse"><stop stop-color="#68724a"/><stop offset=".36" stop-color="#aeb985"/><stop offset=".72" stop-color="#4f593a"/><stop offset="1" stop-color="#2e3522"/></linearGradient></defs>
    <rect x="0" y="0" width="440" height="260" fill="url(#grid)"/>
    <path d="M50 220h350m-30-183v184M68 38v185M50 41h350" stroke="#c2dc91" opacity=".23" stroke-dasharray="5 5"/>
    <path d="M62 47h12m-6-6v12m296 163h12m-6-6v12M350 44h12m-6-6v12" stroke="#c2dc91" opacity=".65"/>
    <g transform="translate(204 139) rotate(-24)">
      <ellipse cx="13" cy="15" rx="128" ry="87" fill="#161912" opacity=".36"/>
      <rect x="-128" y="-14" width="265" height="28" rx="7" fill="url(#shaft)" stroke="#8a9570"/>
      <g stroke="#77835c"><ellipse cx="63" cy="0" rx="27" ry="66" fill="#1e2518"/><ellipse cx="72" cy="0" rx="27" ry="66" fill="url(#metal)"/><ellipse cx="88" cy="0" rx="26" ry="62" fill="#232a1a"/><ellipse cx="96" cy="0" rx="25" ry="61" fill="url(#metal)"/><ellipse cx="105" cy="0" rx="22" ry="56" fill="#343d27"/><ellipse cx="106" cy="0" rx="15" ry="44" stroke="#626e4c"/><ellipse cx="109" cy="0" rx="8" ry="22" fill="#202719"/></g>
      <rect x="106" y="-12" width="43" height="24" rx="6" fill="url(#shaft)" stroke="#84916b"/><ellipse cx="148" cy="0" rx="5" ry="11" fill="#303924" stroke="#8e9a70"/>
      <g stroke="#8a9870"><ellipse cx="-32" cy="0" rx="31" ry="82" fill="#242a1e"/><ellipse cx="-45" cy="0" rx="31" ry="82" fill="url(#metal)"/><ellipse cx="-62" cy="0" rx="31" ry="86" fill="#252d1d"/><ellipse cx="-73" cy="0" rx="31" ry="86" fill="url(#metal)"/><ellipse cx="-83" cy="0" rx="28" ry="79" fill="#39442a"/><ellipse cx="-86" cy="0" rx="24" ry="71" stroke="#74815a"/><ellipse cx="-90" cy="0" rx="17" ry="52" fill="#303924"/><ellipse cx="-92" cy="0" rx="10" ry="24" fill="#222b1c"/></g>
      <rect x="-144" y="-14" width="53" height="28" rx="6" fill="url(#shaft)" stroke="#a2af7d"/><ellipse cx="-143" cy="0" rx="6" ry="13" fill="#303924" stroke="#a2af7d"/>
      <path d="M-139-8h38m-36 14h35m213-12h33" stroke="#c1ca9d" opacity=".65"/><path d="M-3-12v24m6-24v24m6-24v24m6-24v24m6-24v24m6-24v24m6-24v24" stroke="#c5d295" opacity=".38"/>
    </g>
  </svg>`;
}
const newButton = (text='Ajouter une séance') => `<button class="primary" type="button" data-action="new">${icon('plus',19)}${text}</button>`;
function heading(kicker,title,description) { return `<div class="heading"><div><div class="eyebrow"><span></span>${kicker}</div><h1>${title}</h1><p>${description}</p></div>${['programs','data'].includes(state.view)?'':newButton()}</div>`; }
function pick(names){ return `<label class="selector"><span class="sr-only">Exercice suivi</span><select id="exercise">${names.map(n=>`<option${key(n)===key(state.exercise)?' selected':''}>${esc(n)}</option>`).join('')}</select>${icon('chevron',15)}</label>`; }
const latestPain=()=>entries().find(e=>key(e.exercise)===key(state.exercise))?.effort==='pain';
function hero(scoped) {
  const pain=latestPain();
  const rec=tip(scoped,pain);
  const target=pain?null:repetitionTarget(scoped), pinned=state.favorites.some(n=>key(n)===key(state.exercise));
  return `<section class="hero" aria-labelledby="next-title">${plates()}<div class="hero-content"><div class="hero-kicker"><span>${icon(rec.icon,16)}</span> PROCHAINE SÉANCE</div><h2 id="next-title">${esc(state.exercise)}</h2><div class="hero-main">${rec.weight===null?`<strong class="hero-word">${rec.title}</strong>`:`<strong>${num(rec.weight)} <small>kg</small></strong>`}${rec.from!==undefined?`<span class="gain">${icon('up',14)} +${num(rec.weight-rec.from)} kg</span>`:''}</div><div class="hero-status">${rec.tag}${scoped[0]?.loadMode==='dumbbell'?' · PAR HALTÈRE':''}</div><p>${rec.text}</p>${target?`<div class="rep-target">${icon('target',15)} <span>Objectif : <b>${target.reps.join(' / ')} rép.</b> à ${num(target.kg)} ${unit(target)}</span></div>`:''}</div>${state.mode==='real'?`<button type="button" class="icon-button pin" data-pin="${pinned?'off':'on'}" aria-pressed="${pinned}" aria-label="${pinned?'Retirer des favoris':'Épingler cet exercice'}">${icon('star',19)}</button>`:''}<span class="hero-ref">FIG. 01 &nbsp; / &nbsp; CHARGE DE TRAVAIL</span></section>`;
}
function metrics(scoped){
  const latest=scoped[0], days=new Set(scoped.map(e=>e.date)).size;
  const load=latest?maxLoad(latest):0;
  const reps=latest?Math.max(...scoped.flatMap(e=>e.sets.filter(s=>s.kg===load).map(s=>s.reps))):0;
  const metric=(i,l,v,u,d)=>`<article class="metric"><div class="metric-label"><span>${icon(i,17)}</span>${l}</div><div class="metric-number">${v} <small>${u}</small></div><div class="metric-note">${d}</div></article>`;
  const foot=latest?.loadMode==='dumbbell'?'Charge par haltère':'Sur cet exercice';
  return `<div class="metrics">${metric('trophy','Charge record',latest?num(Math.max(...scoped.map(maxLoad))):'–','kg',foot)}${metric('target','Record de répétitions',latest?num(reps):'–','rép.',latest?`Sur une série à ${num(load)} ${unit(latest)}`:'Aucune série de travail')}${metric('layers','Volume',latest?num(work(latest)):'–','kg',latest?.loadMode==='dumbbell'?'Par haltère · poids × répétitions':'Dernière entrée · poids × répétitions')}${metric('clock','Jours d’entraînement',num(days),'',days===1?'1 jour pour cet exercice':'Sur cet exercice')}</div>`;
}
function pinnedList(names){
  if(state.mode!=='real')return '';
  const favorites=state.favorites.filter(f=>names.some(n=>key(n)===key(f)));
  return favorites.length?`<section class="favorites" aria-label="Exercices favoris"><span>${icon('star',15)} Favoris</span>${favorites.map(f=>`<button type="button" class="chip" data-favorite="${esc(f)}" aria-pressed="${key(f)===key(state.exercise)}">${esc(f)}</button>`).join('')}</section>`:'';
}
function plateauBanner(scoped){return !latestPain()&&plateau(scoped)?`<aside class="notice plateau">${icon('info',20)}<div><strong>Stagnation possible</strong><p>Mêmes charges et répétitions sur tes trois dernières séances comparables. Avant de monter la charge, regarde si ton temps de repos, ta régularité ou ton ressenti ont changé.</p></div></aside>`:'';}
function graphCard(scoped,names) {
  return `<section class="panel graph-panel" aria-labelledby="graph-title"><div class="panel-head"><div><h2 id="graph-title">Évolution des charges</h2><p>Charge de travail maximale par jour${scoped[0]?.loadMode==='dumbbell'?' · par haltère':''}</p></div>${pick(names)}</div><div class="graph-actions"><div class="legend"><span></span> Charge (${unit(scoped[0])})</div><div class="segmented" aria-label="Période">${[[30,'30 j'],[90,'90 j'],[0,'Tout']].map(([n,s])=>`<button type="button" data-period="${n}" aria-pressed="${n===state.period}">${s}</button>`).join('')}</div></div><div id="graph"></div></section>`;
}
function drawGraph(){
  const el=$('#graph');
  if(!el) return;
  const scoped=matching(entries()).filter(e=>!state.period||e.date>=localDay(1-state.period));
  const byDay=new Map();
  for(const e of scoped) byDay.set(e.date,Math.max(byDay.get(e.date)??0,maxLoad(e)));
  const points=[...byDay.entries()].reverse();
  if(!points.length){el.innerHTML=`<div class="graph-empty">${icon('chart',28)}<p>Aucune série sur cette période.</p>${state.period?'<button class="quiet" data-period="0" type="button">Voir toutes les dates</button>':''}</div>`;return;}
  const width=Math.max(265,Math.round(el.clientWidth)), height=205, left=42,right=width-13,top=12,bottom=165;
  const values=points.map(p=>p[1]), min=Math.min(...values), max=Math.max(...values);
  const raw=Math.max((max-min)/3,0.25,max*.015), scale=10**Math.floor(Math.log10(raw));
  const step=([1,2,2.5,5,10].find(n=>n>=raw/scale)||10)*scale;
  const floor=Math.max(0,Math.floor(min/step)*step-(Math.abs(min/step-Math.round(min/step))<1e-8?step:0));
  const ceil=Math.max(floor+step*3,Math.ceil(max/step)*step+step);
  const ticks=Array.from({length:Math.round((ceil-floor)/step)+1},(_,i)=>floor+i*step);
  const first=+dateObj(points[0][0]), last=+dateObj(points.at(-1)[0]);
  const x = date=> points.length===1?(left+right)/2:left+(right-left)*(+dateObj(date)-first)/(last-first);
  const y = n=> bottom-(n-floor)/(ceil-floor)*(bottom-top);
  const line=points.map(([d,n])=>`${x(d).toFixed(2)},${y(n).toFixed(2)}`).join(' ');
  const labels = new Set(Array.from({length:Math.min(points.length,width<420?3:5)},(_,i,)=>points.length===1?0:Math.round(i*(points.length-1)/(Math.min(points.length,width<420?3:5)-1))));
  el.innerHTML=`<svg width="100%" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(points.map(([d,n])=>`${dateLabel(d)} : ${num(n)} ${unit(scoped[0])}`).join(', '))}"><defs><linearGradient id="area" x2="0" y2="1" gradientUnits="objectBoundingBox"><stop stop-color="var(--accent)" stop-opacity=".22"/><stop offset="1" stop-color="var(--accent)" stop-opacity=".015"/></linearGradient></defs>
    ${ticks.map(n=>`<path d="M${left} ${y(n)}H${right}" stroke="var(--chart-grid)" stroke-dasharray="4 4"/><text x="${left-9}" y="${y(n)+4}" text-anchor="end">${num(n)}</text>`).join('')}
    ${points.length>1?`<polygon points="${left},${bottom} ${line} ${right},${bottom}" fill="url(#area)"/><polyline points="${line}" stroke="var(--accent)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`:''}
    ${points.map(([d,n],i)=>`<circle cx="${x(d)}" cy="${y(n)}" r="${i===points.length-1?5:3.5}" fill="var(--accent)" stroke="var(--panel)" stroke-width="1.7"><title>${dateLabel(d)} : ${num(n)} ${unit(scoped[0])}</title></circle>${labels.has(i)?`<text x="${Math.max(left+5,Math.min(width-27,x(d)))}" y="190" text-anchor="middle">${dateLabel(d)}</text>`:''}`).join('')}
  </svg>`;
}
const efforts={easy:'Marge confortable',ok:'Effort maîtrisé',hard:'À la limite',pain:'Douleur'};
const entryEfforts = e => e?.efforts ?? (e?.effort?[e.effort]:[]);
function effortChoices(selected, workoutIndex, setLevel=false){
  const inWorkout=workoutIndex!==undefined;
  const label=setLevel?'Ressenti de cette série':inWorkout?'Effort sur cet exercice':'Effort sur tes séries';
  return `<fieldset class="effort-picker"><legend>${label}</legend>${setLevel?'':'<p>Choisis un ou plusieurs ressentis, ici ou par série.</p>'}<div class="effort-grid">${Object.entries(efforts).map(([value,caption])=>`<label class="effort-choice"><input type="checkbox" ${setLevel?'data-set-effort':inWorkout?`data-workout-effort="${workoutIndex}"`:'name="efforts"'} value="${value}"${selected.includes(value)?' checked':''}><span>${caption}</span></label>`).join('')}</div></fieldset>`;
}
function loggedSets(e){return e.sets.map(s=>`<span${s.kind==='warmup'?' class="warmup-tag"':''}>${s.kind==='warmup'?'Échauff. · ':''}${num(s.kg)} ${unit(e)} × ${s.reps}${s.efforts?.length?` · ${s.efforts.map(v=>efforts[v]).join(' + ')}`:''}</span>`).join('');}
function rows(list,full=false) {
  return list.map(e=>`<article class="session"><div class="session-icon">${icon('dumbbell',18)}</div><div class="session-main"><strong>${esc(e.exercise)}</strong><small>${full?'':`${dateLabel(e.date)} · `}${e.sets.length} ${e.sets.length===1?'série':'séries'}${e.loadMode==='dumbbell'?' · poids par haltère':''}</small>${full?`<div class="sets-list" aria-label="Séries">${loggedSets(e)}</div><div class="effort-tags" aria-label="Ressentis">${entryEfforts(e).map(v=>`<span${v==='pain'?' class="pain"':''}>${efforts[v]}</span>`).join('')}</div>`:''}</div><div class="session-end"><b>${working(e).length?`${num(maxLoad(e))} <small>kg</small>`:'—'}</b>${full&&state.mode==='real'?`<div class="row-actions"><button class="icon-button" type="button" data-edit="${e.id}" aria-label="Modifier cette entrée">${icon('edit',16)}</button><button class="icon-button" type="button" data-delete="${e.id}" aria-label="Supprimer cette entrée">${icon('trash',16)}</button></div>`:''}</div></article>`).join('');
}
function journal(list){
  const groups=new Map();
  for(const e of list){
    const id=`${e.date}:${e.sessionId||'manual'}`;
    if(!groups.has(id))groups.set(id,{title:e.sessionName||'Entrées du jour',date:e.date,items:[]});
    groups.get(id).items.push(e);
  }
  return `<section class="panel journal"><div class="panel-head"><div><h2>Séances enregistrées</h2><p>${groups.size} ${groups.size===1?'groupe':'groupes'} · ${list.length} ${list.length===1?'exercice noté':'exercices notés'}</p></div></div>${[...groups.values()].map(g=>`<section class="journal-group"><header><h3>${esc(g.title)}</h3><span>${dateLabel(g.date,true)}</span></header>${rows(g.items,true)}</section>`).join('')}</section>`;
}
function method() { return `<details class="method"><summary>${icon('info',18)} Comment le conseil est calculé ${icon('chevron',16)}</summary><p>L’appli compare deux jours d’entraînement du même exercice, avec le même nombre de séries, la même charge et le même objectif. Elle ne propose une hausse que si toutes les séries atteignent le haut de ta plage sur les deux jours, avec un effort maîtrisé. Le palier choisi ne doit pas dépasser 5 % de ta charge. La suggestion est indicative : privilégie une technique propre et ne progresse pas en cas de douleur.</p></details>`; }
function empty() {return `<section class="panel empty"><span class="empty-icon">${icon('dumbbell',28)}</span><h2>Ton carnet est encore vide.</h2><p>Ajoute un exercice et note tes séries. Tes courbes et ton prochain objectif apparaîtront ici.</p>${newButton('Noter ma première séance')}</section>`;}
const previousFor = name=>state.data.filter(e=>key(e.exercise)===key(name)).sort(dateSort);
const profileFor=name=>state.profiles.find(p=>key(p.name)===key(name));
function goals(name){
  const p=profileFor(name)||previousFor(name)[0];
  return {min:p?.min??8,max:p?.max??12,step:p?.step??2.5,loadMode:p?.loadMode||'total'};
}
const formatTimer = seconds=>`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
const newId=()=>crypto.randomUUID?.()||'10000000-1000-4000-8000-100000000000'.replace(/[018]/g,c=>(Number(c)^crypto.getRandomValues(new Uint8Array(1))[0]&15>>Number(c)/4).toString(16));
const loadModes=(mode='total')=>`<option value="total" ${mode==='total'?'selected':''}>Charge totale</option><option value="dumbbell" ${mode==='dumbbell'?'selected':''}>Poids par haltère</option>`;
function profilesPanel(){
  return `<section class="panel profiles"><div class="panel-head"><div><h2>Réglages par exercice</h2><p>Plage de répétitions, palier et unité de charge.</p></div><button class="secondary" type="button" data-profile="new">${icon('plus',16)} Régler un exercice</button></div>${state.profiles.map((p,i)=>`<div class="profile-line"><div><b>${esc(p.name)}</b><small>${p.min} à ${p.max} rép. · palier ${num(p.step)} ${unit(p)} · ${p.loadMode==='dumbbell'?'Par haltère':'Charge totale'}</small></div><button class="icon-button" type="button" data-profile-edit="${i}" aria-label="Modifier les réglages de ${esc(p.name)}">${icon('edit',16)}</button></div>`).join('')}</section>`;
}
function openProfile(p){
  const names=[...new Set([...exerciseNames(state.data),...state.programs.flatMap(x=>x.exercises.map(e=>e.name)),...base])];
  const d=$('#profile-dialog');
  d.innerHTML=`<form id="profile-form"><div class="dialog-head"><h2 id="profile-title">Régler un exercice</h2><button type="button" class="icon-button" data-close="profile-dialog" aria-label="Fermer">${icon('close')}</button></div><div class="dialog-body"><label>Exercice<input name="profile-exercise" list="profile-names" maxlength="60" value="${esc(p?.name||'')}" ${p?'readonly':''} required></label><datalist id="profile-names">${names.map(n=>`<option value="${esc(n)}"></option>`).join('')}</datalist><div class="form-three"><label>Rép. min<input name="min" type="number" min="1" max="49" value="${p?.min??8}" required></label><label>Rép. max<input name="max" type="number" min="2" max="50" value="${p?.max??12}" required></label><label>Palier (kg)<input name="step" type="number" step="0.01" min="0.01" max="30" value="${p?.step??2.5}" required></label></div><label>Unité de charge<select name="loadMode">${loadModes(p?.loadMode)}</select></label><p class="form-hint">Le palier est la plus petite hausse disponible. Pour deux haltères, saisis le poids et le palier d’un seul haltère.</p><p class="form-error" role="alert"></p></div><div class="dialog-foot"><button type="button" class="secondary" data-close="profile-dialog">Annuler</button><button type="submit" class="primary">Enregistrer les réglages</button></div></form>`;
  d.showModal();
}
function programsView(){
  if(state.draft)return workoutView();
  if(!state.programs.length)return `<section class="panel empty"><span class="empty-icon">${icon('play',27)}</span><h2>Crée ton premier programme.</h2><p>Compose une séance réutilisable. Forge affichera les séries de la dernière fois et lancera le chrono à chaque série cochée.</p><button type="button" class="primary" data-program="new">${icon('plus',18)} Créer un programme</button></section>${profilesPanel()}`;
  return `<div class="program-toolbar"><span>${state.programs.length} ${state.programs.length===1?'programme':'programmes'}</span><button type="button" class="primary" data-program="new">${icon('plus',18)} Créer un programme</button></div><div class="program-grid">${state.programs.map(p=>`<article class="panel program-card"><div class="panel-head"><div><div class="eyebrow"><span></span> MODÈLE DE SÉANCE</div><h2>${esc(p.name)}</h2></div><div class="row-actions"><button class="icon-button" type="button" data-program-edit="${p.id}" aria-label="Modifier le programme ${esc(p.name)}">${icon('edit',16)}</button><button class="icon-button" type="button" data-program-delete="${p.id}" aria-label="Supprimer le programme ${esc(p.name)}">${icon('trash',16)}</button></div></div><ul>${p.exercises.map(e=>`<li><b>${esc(e.name)}</b><span>${e.count} ${e.count===1?'série':'séries'} · ${e.rest} s</span></li>`).join('')}</ul><button type="button" class="secondary" data-workout="${p.id}">${icon('play',16)} Lancer la séance</button></article>`).join('')}</div>${profilesPanel()}`;
}
function appearancePanel(){
  const look=state.previewLook||state.look;
  const group=(name,title)=>`<fieldset class="look-group"><legend>${title}</legend><div class="look-options">${lookChoices[name].map(([value,label])=>`<label class="look-option"><input type="radio" name="${name}" value="${value}" ${look[name]===value?'checked':''}><span>${name==='accent'?`<i class="swatch" data-tone="${value}" aria-hidden="true"></i>`:''}${label}</span></label>`).join('')}</div></fieldset>`;
  return `<section class="panel data-card appearance-card" aria-labelledby="appearance-title"><div class="appearance-copy"><span class="empty-icon">${icon('sliders',24)}</span><div><h2 id="appearance-title">Personnalisation</h2><p>Essaie un style avant de le garder. Le mode Appareil suit le thème de ton téléphone ou de ton ordinateur.</p></div></div><form id="appearance-form"><div class="look-grid">${group('theme','Thème')}${group('accent','Couleur d’accent')}${group('density','Espacement')}</div><div class="appearance-foot"><button type="submit" class="primary" data-look-save ${state.loading||state.error||state.savingLook?'disabled':''}>Enregistrer l’apparence</button><button type="button" class="secondary" data-look-reset ${state.loading||state.savingLook?'disabled':''}>Réglages d’origine</button><p class="appearance-status" role="status"></p></div></form></section>`;
}
function dataView(){
  return `${appearancePanel()}<div class="data-grid"><section class="panel data-card"><span class="empty-icon">${icon('archive',24)}</span><h2>Sauvegarde locale</h2><p>Télécharge une copie de tes séances, programmes, favoris et réglages d’apparence. Garde le fichier sur ton téléphone ou ton ordinateur.</p><div class="backup-count">${state.data.length} ${state.data.length===1?'entrée':'entrées'} · ${state.programs.length} ${state.programs.length===1?'programme':'programmes'} · ${state.favorites.length} ${state.favorites.length===1?'favori':'favoris'}</div><div class="data-actions"><button type="button" class="primary" data-backup="download" ${state.loading||state.error?'disabled':''}>${icon('download',18)} Télécharger la sauvegarde</button><button type="button" class="secondary" data-backup="pick" ${state.loading?'disabled':''}>Restaurer un fichier</button><input class="sr-only" type="file" id="backup-file" accept=".json,application/json" tabindex="-1" aria-label="Fichier de sauvegarde Forge"></div><p class="form-hint">La restauration fusionne les données sans effacer le carnet actuel. Si tu as déjà enregistré des réglages d’apparence, ils sont aussi conservés.</p><p id="backup-error" class="form-error" role="alert"></p></section><section class="panel data-card"><span class="empty-icon">${icon('plus',24)}</span><h2>Accès depuis l’écran d’accueil</h2><p>Ouvre l’aperçu Forge dans le navigateur de ton téléphone. Le raccourci réouvre le carnet web et ne permet pas de l’utiliser hors connexion.</p>${installPrompt?'<button type="button" class="secondary" data-backup="install">Installer Forge</button>':''}<details class="method"><summary>iPhone · Safari ${icon('chevron',16)}</summary><p>Dans Safari, touche Partager, puis Sur l’écran d’accueil et Ajouter.</p></details><details class="method"><summary>Android · Chrome ${icon('chevron',16)}</summary><p>Dans Chrome, ouvre le menu ⋮, puis choisis Ajouter à l’écran d’accueil, ou Installer si le navigateur le propose.</p></details></section></div>`;
}
function programRow(idx,data={}){
  return `<div class="program-row"><label>Exercice<input data-program-name maxlength="60" list="program-exercises" placeholder="Ex. : Squat" value="${esc(data.name||'')}" required></label><label>Séries<input data-program-count type="number" min="1" max="12" value="${data.count||3}" required></label><label>Repos (s)<input data-program-rest type="number" min="10" max="600" value="${data.rest||90}" required></label><button type="button" class="icon-button" data-program-remove aria-label="Retirer l’exercice ${idx+1}">${icon('close',16)}</button></div>`;
}
function updateProgramRows(){
  const rows=[...document.querySelectorAll('.program-row')];
  rows.forEach((row,i)=>{const b=$('[data-program-remove]',row);b.disabled=rows.length===1;b.setAttribute('aria-label',`Retirer l’exercice ${i+1}`);});
  $('[data-program-add]').disabled=rows.length>=12;
}
function openProgram(p){
  const d=$('#program-dialog');
  const names=[...new Set([...exerciseNames(state.data),...base])];
  d.innerHTML=`<form id="program-form" data-id="${p?.id||''}"><div class="dialog-head"><h2 id="program-title">${p?'Modifier le programme':'Créer un programme'}</h2><button type="button" class="icon-button" data-close="program-dialog" aria-label="Fermer">${icon('close')}</button></div><div class="dialog-body"><label>Nom du programme<input name="program-name" maxlength="60" value="${esc(p?.name||'')}" placeholder="Ex. : Haut du corps" required></label><datalist id="program-exercises">${names.map(n=>`<option value="${esc(n)}"></option>`).join('')}</datalist><div id="program-rows">${(p?.exercises||[{}]).map((x,i)=>programRow(i,x)).join('')}</div><button type="button" class="quiet" data-program-add>${icon('plus',16)} Ajouter un exercice</button><p class="form-error" role="alert"></p></div><div class="dialog-foot"><button type="button" class="secondary" data-close="program-dialog">Annuler</button><button type="submit" class="primary">Enregistrer le programme</button></div></form>`;
  updateProgramRows();d.showModal();
}
const blankSet=(kind='work')=>({kg:'',reps:'',done:false,kind,efforts:[]});
function draftContext(item){
  const previous=previousFor(item.name), pain=previous[0]?.effort==='pain';
  const history=comparable(previous.filter(e=>(e.loadMode||'total')===item.loadMode),item.name);
  const suggested=pain?null:repetitionTarget(history);
  return {...item,prev:history[0],pain,goal:history[0]?.min===item.min&&history[0]?.max===item.max&&history[0]?.step===item.step?suggested:null};
}
function hydrateDraft(draft){return {...draft,items:draft.items.map(draftContext)};}
let draftTimer, pendingDraft, draftWriting=false;
function packedDraft(){
  const {id,updatedAt,date,program,items}=state.draft;
  return {id,updatedAt,date,program,items:items.map(({name,rest,min,max,step,loadMode,efforts,sets})=>({name,rest,min,max,step,loadMode,efforts,sets})),rest};
}
function draftLabel(text){const label=$('#draft-status');if(label)label.textContent=text;}
function queueDraft(immediate=false){
  if(!state.draft)return;
  state.draft.updatedAt=Math.max(Date.now(),(state.draft.updatedAt||0)+1);
  pendingDraft=packedDraft();
  clearTimeout(draftTimer);
  draftLabel(portable?'Brouillon dans cette copie':'Sauvegarde du brouillon…');
  if(immediate)flushDraft();else draftTimer=setTimeout(flushDraft,260);
}
async function flushDraft(){
  if(!pendingDraft||draftWriting)return;
  const current=pendingDraft;pendingDraft=null;draftWriting=true;
  try{
    const result=await request('/carnet/draft',{...json('PUT',current),keepalive:JSON.stringify(current).length<50000});
    if(state.draft?.id!==current.id)return;
    if(result.draft?.id&&result.draft.id!==current.id){state.draft=hydrateDraft(result.draft);render();toast('Un autre brouillon était déjà enregistré.');}
    else if(!pendingDraft)draftLabel(portable?'Brouillon en mémoire · télécharge la copie pour le garder':'Brouillon enregistré');
  }catch{
    if(state.draft?.id===current.id){
      pendingDraft=pendingDraft||current;
      draftLabel('Brouillon non transmis. Réessaie avec du réseau.');
      return;
    }
  }finally{draftWriting=false;}
  if(pendingDraft)flushDraft();
}
function flushBeforeLeaving(){
  if(draftWriting&&pendingDraft&&JSON.stringify(pendingDraft).length<50000)request('/carnet/draft',{...json('PUT',pendingDraft),keepalive:true}).catch(()=>{});
  else flushDraft();
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)flushBeforeLeaving();});
window.addEventListener('pagehide',flushBeforeLeaving);
window.addEventListener('online',flushDraft);
function startWorkout(program){
  state.draft={id:newId(),program,date:localDay(),items:program.exercises.map(e=>{
    const item=draftContext({...e,...goals(e.name),efforts:[]});
    return {...item,sets:Array.from({length:e.count},(_,i)=>({...blankSet(),kg:item.pain?'':item.goal&&i<item.goal.reps.length?item.goal.kg:item.prev?.sets[i]?.kg??'',reps:item.pain?'':item.goal?.reps[i]??item.prev?.sets[i]?.reps??''}))};
  })};
  render();
  queueDraft(true);
  window.scrollTo(0,0);
}
function setKindOptions(kind){return `<option value="work" ${kind!=='warmup'?'selected':''}>Travail</option><option value="warmup" ${kind==='warmup'?'selected':''}>Échauffement</option>`;}
function workoutSet(item,i,s,j){
  const name=esc(item.name);
  return `<div class="set-block${s.kind==='warmup'?' warmup':''}" data-workout-row="${i}:${j}"><div class="set-top"><label><span class="sr-only">Type de la série ${j+1} de ${name}</span><select data-kind>${setKindOptions(s.kind)}</select></label><button type="button" class="icon-button" data-workout-remove aria-label="Retirer ${name} série ${j+1}" ${item.sets.length<2?'disabled':''}>${icon('trash',15)}</button></div><div class="workout-row${s.done?' done':''}"><span>${String(j+1).padStart(2,'0')}</span><input type="number" step="0.01" min="0" max="999" inputmode="decimal" aria-label="${name} · charge série ${j+1}" data-workout-kg value="${esc(s.kg)}"><input type="number" step="1" min="1" max="100" inputmode="numeric" aria-label="${name} · répétitions série ${j+1}" data-workout-reps value="${esc(s.reps)}"><button type="button" class="icon-button" data-workout-check aria-pressed="${s.done}" aria-label="Cocher ${name} série ${j+1}">${icon('check',19)}</button></div><details class="series-effort"><summary>Ressenti de la série${s.efforts.length?` <span class="series-count">${s.efforts.length}</span>`:''}</summary>${effortChoices(s.efforts,undefined,true)}</details></div>`;
}
function workoutView(){
  const d=state.draft;
  const checked=d.items.reduce((n,item)=>n+item.sets.filter(s=>s.done).length,0);
  const total=d.items.reduce((n,item)=>n+item.sets.length,0);
  return `<form id="workout-form"><div class="panel workout-head"><div><div class="eyebrow"><span></span> SÉANCE EN COURS</div><h2>${esc(d.program.name)}</h2><p><strong id="workout-checked">${checked}</strong> / ${total} séries cochées</p><p id="draft-status" class="draft-status">${portable?'Copie hors connexion':'Brouillon automatique'}</p></div><label>Date<input name="workout-date" type="date" min="1900-01-01" max="${localDay()}" value="${esc(d.date)}" required></label></div><div class="workout-grid">${d.items.map((item,i)=>`<section class="panel workout-item" data-workout-item="${i}"><div class="panel-head"><h2>${esc(item.name)}</h2><span class="rest-label">${icon('clock',16)} ${item.rest} s</span></div><p class="previous">${item.prev?`<b>Dernière fois :</b> ${item.prev.sets.map(s=>`${num(s.kg)} ${unit(item)} × ${s.reps}`).join(' · ')}`:'Pas encore de séries de travail pour cet exercice.'}</p><p class="goal-line"><b>Objectif :</b> ${item.goal?`${item.goal.reps.join(' / ')} rép. à ${num(item.goal.kg)} ${unit(item)}`:`${item.min} à ${item.max} rép. · palier ${num(item.step)} ${unit(item)}`}</p><div class="workout-labels"><span>Série</span><span>Charge (${unit(item)})</span><span>Répétitions</span><span></span></div>${item.sets.map((s,j)=>workoutSet(item,i,s,j)).join('')}<div class="set-actions"><button type="button" class="quiet" data-workout-add="work" ${item.sets.length>=20?'disabled':''}>${icon('plus',15)} Série de travail</button><button type="button" class="quiet" data-workout-add="warmup" ${item.sets.length>=20?'disabled':''}>${icon('plus',15)} Échauffement</button></div>${effortChoices(item.efforts,i)}</section>`).join('')}</div><div class="workout-footer"><p class="form-error" id="workout-error" role="alert"></p><button class="secondary" type="button" data-workout-cancel>Abandonner le brouillon</button><button class="primary" type="submit" ${checked?'':'disabled'}>Enregistrer la séance</button></div></form>`;
}
let rest=null, ticker;
function refreshTimer(){
  const el=$('#rest-timer');if(!rest){el.hidden=true;return;}
  const remaining=Math.max(0,Math.ceil((rest.until-Date.now())/1000));
  el.hidden=false;
  if(!$('[data-rest-count]',el))el.innerHTML=`<div class="rest-icon">${icon('clock',23)}</div><div><span class="timer-name"></span><strong data-rest-count role="timer"></strong></div><button class="icon-button" type="button" data-rest-stop aria-label="Fermer le chrono">${icon('close',18)}</button><div class="sr-only" data-rest-announcement aria-live="polite"></div>`;
  $('.timer-name',el).textContent=remaining?`Repos · ${rest.name}`:'Repos terminé';
  $('[data-rest-count]',el).textContent=formatTimer(remaining);
  if(!remaining){
    const a=$('[data-rest-announcement]',el);if(!a.textContent)a.textContent='Temps de repos terminé.';
    clearInterval(ticker);
  }
}
function endTimer(){rest=null;clearInterval(ticker);$('#rest-timer').innerHTML='';refreshTimer();}
function startTimer(item){endTimer();clearTimeout(toastTimer);$('#toast').classList.remove('show');rest={name:item.name,until:Date.now()+item.rest*1000};refreshTimer();ticker=setInterval(refreshTimer,250);}
function workoutRow(node){
  const row=node.closest('[data-workout-row]');
  if(!row)return null;
  const [i,j]=row.dataset.workoutRow.split(':').map(Number);
  return {row,i,j,item:state.draft.items[i],set:state.draft.items[i].sets[j]};
}
function validDraft(set){return set.kg!==''&&Number(set.kg)>=0&&Number(set.kg)<=999&&set.reps!==''&&Number.isInteger(Number(set.reps))&&Number(set.reps)>=1&&Number(set.reps)<=100;}
function modalConfirm(title,description,action,label){
  const d=$('#confirm');
  d.innerHTML=`<div class="dialog-head"><h2 id="confirm-title">${title}</h2><button type="button" class="icon-button" data-close="confirm" aria-label="Fermer">${icon('close')}</button></div><div class="dialog-body"><p>${esc(description)}</p><p class="form-error" role="alert"></p></div><div class="dialog-foot"><button type="button" class="secondary" data-close="confirm" autofocus>Annuler</button><button type="button" class="danger" ${action}>${label}</button></div>`;
  d.showModal();
}
let installPrompt=null;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;if(state.view==='data')render();});
function downloadBackup(){
  const filename=`forge-sauvegarde-${localDay()}.json`;
  downloadFile(JSON.stringify({format:'forge-backup',version:1,exportedAt:new Date().toISOString(),entries:state.data,programs:state.programs,favorites:state.favorites,profiles:state.profiles,appearance:state.look},null,2),'application/json',filename);
}
function downloadFile(contents,type,filename){
  const url=URL.createObjectURL(new Blob([contents],{type}));
  const a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),15000);
}
const normalizedName=name=>name.trim().replace(/\s+/g,' ');
function portableEntry(value,id=newId(),timestamp=Date.now(),session){
  const sets=value.sets.map(s=>({kg:s.kg,reps:s.reps,kind:s.kind||'work',efforts:s.efforts||[]}));
  const combined=[...value.efforts,...sets.flatMap(s=>s.kind==='work'?s.efforts:s.efforts.filter(e=>e==='pain'))];
  return {...value,exercise:normalizedName(value.exercise),id,timestamp,sets,effort:Object.keys(efforts).filter(e=>combined.includes(e)).at(-1)||'ok',...(session?.id?{sessionId:session.id,sessionName:session.name}:{})};
}
function portableRequest(path,options={}){
  const v=options.body?JSON.parse(options.body):null;
  const snap=()=>structuredClone(portable);
  if(path==='/carnet')return snap();
  if(path==='/carnet/appearance'){portable.appearance=v;return snap();}
  if(path==='/carnet/draft'){portable.draft=v;return {draft:v};}
  if(path==='/carnet/draft/close'){portable.draft=null;return {draft:null};}
  if(path==='/carnet/favorite'){portable.favorites=portable.favorites.filter(n=>key(n)!==key(v.name));if(v.pinned)portable.favorites.push(v.name);return snap();}
  if(path==='/carnet/profile'){v.name=normalizedName(v.name);portable.profiles=[...portable.profiles.filter(p=>key(p.name)!==key(v.name)),v];return snap();}
  if(path==='/carnet/program'||path==='/carnet/program/delete'){
    portable.programs=portable.programs.filter(p=>p.id!==v.id);
    if(path==='/carnet/program'){
      v.name=normalizedName(v.name);v.exercises=v.exercises.map(e=>({...e,name:normalizedName(e.name)}));
      portable.programs.push(v);
    }
    return snap();
  }
  if(path==='/carnet/session'){
    if(!portable.entries.some(e=>e.sessionId===v.id))portable.entries.push(...v.items.map(e=>portableEntry(e,undefined,undefined,v)));
    if(portable.draft?.id===v.id)portable.draft=null;
    return structuredClone(portable.entries);
  }
  if(path==='/carnet/restore')throw new Error('Restaure les sauvegardes dans Forge en ligne.');
  if(path.startsWith('/entries')){
    const id=path.split('/')[2], before=portable.entries.find(e=>e.id===id);
    if(options.method==='DELETE')portable.entries=portable.entries.filter(e=>e.id!==id);
    if(options.method==='POST')portable.entries.push(portableEntry(v));
    if(options.method==='PUT'&&before)portable.entries=portable.entries.map(e=>e.id===id?portableEntry(v,id,before.timestamp,{id:before.sessionId,name:before.sessionName}):e);
    return structuredClone(portable.entries);
  }
  throw new Error('Cette action est indisponible hors connexion.');
}
function currentPortableFile(){
  const clone=document.documentElement.cloneNode(true);
  const snapshot={entries:state.data,programs:state.programs,favorites:state.favorites,profiles:state.profiles,appearance:state.look,draft:state.draft?packedDraft():null};
  $('#forge-snapshot',clone).textContent=JSON.stringify(snapshot).replace(/[<>&]/g,c=>`\\u${c.charCodeAt(0).toString(16).padStart(4,'0')}`);
  for(const node of clone.querySelectorAll('#content,#desktop-nav,#mobile-nav,#brand-icon,#mobile-icon,#crumb,#mode,dialog,#toast,#rest-timer'))node.replaceChildren();
  $('#toast',clone).removeAttribute('class');
  $('#rest-timer',clone).hidden=true;
  for(const d of clone.querySelectorAll('dialog'))d.removeAttribute('open');
  return '<!doctype html>'+clone.outerHTML;
}
function render() {
  const list=entries(), scoped=matching(list), names=exerciseNames(list);
  $('#crumb').textContent=nav.find(n=>n[0]===state.view)[2];
  $('#mode').innerHTML=state.mode==='demo'?'<span></span> Mode démo <b>Mon carnet</b>':'<span></span> Mon carnet <b>Voir la démo</b>';
  $('#mode').setAttribute('aria-label',state.mode==='demo'?'Ouvrir mon carnet':'Voir le mode démo');
  for(const [el,mobile] of [['#desktop-nav',false],['#mobile-nav',true]]) $(el).innerHTML=nav.map(([id,i,desktop,short])=>`<button type="button" data-view="${id}" ${state.view===id?'aria-current="page"':''}>${icon(i,20)}<span>${mobile?short:desktop}</span></button>`).join('');
  const banner=state.mode==='real'&&state.error?`<div class="notice error">${icon('info',18)}<span>${esc(state.error)}</span><button data-action="retry" class="quiet" type="button">Réessayer</button></div>`:'';
  const demoNotice=state.mode==='demo'?`<div class="notice demo">${icon('info',16)}<span>Données d’exemple. Tes séances seront enregistrées dans <button type="button" class="quiet" data-action="real">Mon carnet</button>.</span></div>`:'';
  const draftNotice=state.draft&&state.view!=='programs'&&state.mode==='real'?`<div class="notice draft-notice">${icon('clock',17)}<span>Brouillon : ${esc(state.draft.program.name)}</span><button class="quiet" type="button" data-view="programs">Reprendre la séance</button></div>`:'';
  const portableNotice=portable?`<div class="notice draft-notice portable-notice">${icon('info',17)}<span>Copie hors connexion. Télécharge une nouvelle copie avant de fermer pour conserver tes changements.</span><button type="button" class="quiet" data-portable="save">Télécharger la copie mise à jour</button></div>`:'';
  const head = state.view==='home'?heading('TABLEAU DE BORD','Vue d’ensemble','Suis tes charges et décide quoi viser à ta prochaine séance.'):state.view==='progress'?heading('TES RÉSULTATS','Progression','Retrouve l’évolution de tes charges, exercice par exercice.'):state.view==='programs'?heading('TES ROUTINES','Programmes','Prépare tes séances et retrouve tes dernières séries.'):state.view==='data'?heading('TON CARNET','Données et réglages','Personnalise Forge et garde une copie de tes entraînements.'):heading('TES SÉANCES','Journal d’entraînement','Retrouve le détail de chaque série enregistrée.');
  let body;
  if(state.view==='data')body=dataView();
  else if(state.view==='programs')body=programsView();
  else if(!list.length) body=state.loading?`<section class="panel empty"><p>Chargement de ton carnet…</p></section>`:state.error?`<section class="panel empty"><h2>Ton carnet n’a pas pu être chargé.</h2><p>Réessaie avant de consulter tes données.</p></section>`:empty();
  else if(state.view==='home') body=`${pinnedList(names)}${hero(scoped)}${plateauBanner(scoped)}<div class="section-label"><span>01 / TES INDICATEURS</span><span>${esc(state.exercise)}</span></div>${metrics(scoped)}<div class="overview-bottom">${graphCard(scoped,names)}<section class="panel recent"><div class="panel-head"><div><h2>Journal récent</h2><p>Tous les exercices</p></div><button type="button" class="quiet recent-link" data-view="history">Tout voir ${icon('arrow',15)}</button></div>${rows(list.slice(0,3))}</section></div>${method()}`;
  else if(state.view==='progress') body=`${pinnedList(names)}${hero(scoped)}${plateauBanner(scoped)}<div class="section-label"><span>01 / TES INDICATEURS</span><span>${esc(state.exercise)}</span></div>${metrics(scoped)}${graphCard(scoped,names)}${method()}`;
  else body=journal(list);
  const offlineCard=state.view==='data'&&!portable?`<section class="panel data-card offline-card"><div><h2>Forge hors connexion</h2><p>Télécharge une copie autonome avec tes programmes et ton carnet. Ouvre le fichier dans un navigateur capable d’exécuter les fichiers HTML locaux. Après ta séance, exporte le JSON, puis restaure-le dans Forge en ligne.</p></div><button type="button" class="secondary" data-portable="download" ${state.loading||state.error?'disabled':''}>${icon('download',17)} Télécharger Forge hors connexion</button><p class="form-error" role="alert"></p></section>`:'';
  $('#content').innerHTML=head+banner+demoNotice+portableNotice+draftNotice+body+offlineCard;
  drawGraph();
}
function setRow(i,s={}){
  return `<div class="manual-set set-block${s.kind==='warmup'?' warmup':''}"><div class="set-top"><label><span class="sr-only">Type de la série ${i+1}</span><select data-kind>${setKindOptions(s.kind)}</select></label></div><div class="set-row"><span class="set-index">${String(i+1).padStart(2,'0')}</span><input aria-label="Charge de la série ${i+1} en kg" data-kg type="number" inputmode="decimal" min="0" max="999" step="0.01" placeholder="kg" required value="${esc(s.kg??'')}"><input aria-label="Répétitions de la série ${i+1}" data-reps type="number" inputmode="numeric" min="1" max="100" step="1" placeholder="Rép." required value="${esc(s.reps??'')}"><button class="icon-button" type="button" data-remove aria-label="Retirer la série ${i+1}">${icon('close',17)}</button></div><details class="series-effort"><summary>Ressenti de la série${s.efforts?.length?` <span class="series-count">${s.efforts.length}</span>`:''}</summary>${effortChoices(s.efforts||[],undefined,true)}</details></div>`;
}
function updateRows(){
  const all=[...document.querySelectorAll('.manual-set')];
  all.forEach((row,i)=>{ $('.set-index',row).textContent=String(i+1).padStart(2,'0'); $('[data-kg]',row).setAttribute('aria-label',`Charge de la série ${i+1} en kg`); $('[data-reps]',row).setAttribute('aria-label',`Répétitions de la série ${i+1}`); $('.set-top .sr-only',row).textContent=`Type de la série ${i+1}`;const b=$('[data-remove]',row); b.disabled=all.length===1; b.setAttribute('aria-label',`Retirer la série ${i+1}`); });
  for(const b of document.querySelectorAll('[data-action="add-set"],[data-action="add-warmup"]'))b.disabled=all.length>=20;
}
function openEditor(entry=null){
  const dialog=$('#editor');
  const exercise=entry?.exercise || (state.mode==='real'&&state.data.length?state.exercise:state.mode==='demo'?state.exercise:'');
  const previous=state.data.slice().sort(dateSort).find(e=>key(e.exercise)===key(exercise));
  const defaults=entry||goals(exercise);
  const previousSets=entry?.sets||(previous&&(previous.loadMode||'total')===defaults.loadMode&&working(previous).length?working(previous):[{}]);
  const names=[...new Map([...exerciseNames(state.data),...base].map(n=>[key(n),n])).values()];
  dialog.innerHTML=`<form id="log-form" data-id="${entry?.id||''}" data-exercise-key="${esc(key(exercise))}"><div class="dialog-head"><div><div class="eyebrow"><span></span> JOURNAL</div><h2 id="editor-title">${entry?'Modifier la séance':'Ajouter une séance'}</h2></div><button type="button" class="icon-button" data-close="editor" aria-label="Fermer">${icon('close')}</button></div>
  <div class="dialog-body"><div class="form-two"><label>Exercice<input name="exercise" list="exercise-list" placeholder="Ex. : Développé couché" autocomplete="off" maxlength="60" value="${esc(exercise)}" required></label><datalist id="exercise-list">${names.map(n=>`<option value="${esc(n)}"></option>`).join('')}</datalist><label>Date<input name="date" type="date" min="1900-01-01" max="${localDay()}" value="${entry?.date||localDay()}" required></label></div>
  <label>Unité de charge<select name="loadMode">${loadModes(defaults.loadMode)}</select></label>
  <div class="form-section"><div class="set-legend"><span>#</span><span>Charge (kg)</span><span>Répétitions</span><span></span></div><div id="set-rows">${previousSets.map((s,i)=>setRow(i,entry?s:{kg:s.kg})).join('')}</div><div class="set-actions"><button class="quiet" type="button" data-action="add-set">${icon('plus',16)} Ajouter une série</button><button class="quiet" type="button" data-action="add-warmup">${icon('plus',16)} Ajouter un échauffement</button></div></div>
  ${effortChoices(entryEfforts(entry))}
  <div class="form-three"><label>Rép. min<input name="min" type="number" min="1" max="49" value="${defaults.min}" required></label><label>Rép. max<input name="max" type="number" min="2" max="50" value="${defaults.max}" required></label><label>Palier (kg)<input name="step" type="number" inputmode="decimal" min="0.01" max="30" step="0.01" value="${defaults.step}" required></label></div><p class="form-hint">Les échauffements ne comptent pas dans les records ni les volumes.</p><p class="form-error" id="form-error" role="alert"></p></div>
  <div class="dialog-foot"><button type="button" class="secondary" data-close="editor">Annuler</button><button type="submit" class="primary">Enregistrer</button></div></form>`;
  updateRows();
  dialog.showModal();
  if(!exercise) $('input[name="exercise"]',dialog).focus();
}
let toastTimer;
function toast(msg){
  $('#toast').textContent=msg; $('#toast').classList.add('show');
  clearTimeout(toastTimer); toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),3200);
}
function deleteDialog(id){
  const entry=state.data.find(e=>e.id===id);
  if(!entry) return;
  const dialog=$('#confirm');
  dialog.innerHTML=`<div class="dialog-head"><h2 id="confirm-title">Supprimer cette entrée ?</h2><button type="button" class="icon-button" data-close="confirm" aria-label="Fermer">${icon('close')}</button></div><div class="dialog-body"><p>${esc(entry.exercise)} · ${dateLabel(entry.date,true)}. Cette action est définitive.</p><p class="form-error" role="alert"></p></div><div class="dialog-foot"><button type="button" class="secondary" data-close="confirm" autofocus>Annuler</button><button type="button" class="danger" data-confirm="${id}">Supprimer</button></div>`;
  dialog.showModal();
}
document.addEventListener('click',async e=>{
  const b=e.target.closest('button');
  if(!b) return;
  const d=b.dataset;
  if(b.id==='mode') return modeSwitch(state.mode==='demo'?'real':'demo');
  if(d.view) return move(d.view);
  if(d.period!==undefined){ state.period=Number(d.period); render(); $(`[data-period="${state.period}"]`)?.focus({preventScroll:true});return; }
  if(d.action==='real') return modeSwitch('real');
  if(d.action==='retry') return load();
  if(d.action==='new') return openEditor();
  if(d.profile==='new')return openProfile();
  if(d.profileEdit!==undefined)return openProfile(state.profiles[Number(d.profileEdit)]);
  if(d.pin){
    b.disabled=true;
    try{applyCarnet(await request('/carnet/favorite',json('PUT',{name:state.exercise,pinned:d.pin==='on'})));render();$('[data-pin]')?.focus({preventScroll:true});toast(d.pin==='on'?'Exercice épinglé.':'Exercice retiré des favoris.');}
    catch(err){toast(err.message);b.disabled=false;}
    return;
  }
  if(d.favorite){state.exercise=d.favorite;render();return;}
  if(d.program==='new')return openProgram();
  if(d.programEdit){const p=state.programs.find(p=>p.id===d.programEdit);if(p)openProgram(p);return;}
  if(d.programDelete){
    const p=state.programs.find(p=>p.id===d.programDelete);
    if(p)modalConfirm('Supprimer ce programme ?',`« ${p.name} » sera supprimé. Les séances déjà dans le journal seront conservées.`,`data-confirm-program="${p.id}"`,'Supprimer');
    return;
  }
  if(d.confirmProgram){
    b.disabled=true;
    try{applyCarnet(await request('/carnet/program/delete',json('POST',{id:d.confirmProgram})));$('#confirm').close();render();toast('Programme supprimé.');}
    catch(err){$('.form-error',$('#confirm')).textContent=err.message;b.disabled=false;}
    return;
  }
  if(d.programAdd!==undefined){
    $('#program-rows').insertAdjacentHTML('beforeend',programRow($('#program-rows').children.length));
    updateProgramRows();$('[data-program-name]',$('#program-rows').lastElementChild).focus();return;
  }
  if(d.programRemove!==undefined){b.closest('.program-row').remove();updateProgramRows();$('[data-program-add]').focus();return;}
  if(d.workout){const p=state.programs.find(p=>p.id===d.workout);if(p)startWorkout(p);return;}
  if(d.workoutAdd){
    const i=Number(b.closest('[data-workout-item]').dataset.workoutItem);
    const item=state.draft.items[i];
    if(item.sets.length>=20)return;
    const j=d.workoutAdd==='warmup'?item.sets.findIndex(s=>s.kind!=='warmup'):item.sets.length;
    const offset=j<0?item.sets.length:j;
    item.sets.splice(offset,0,blankSet(d.workoutAdd));
    render();queueDraft();
    $(`[data-workout-row="${i}:${offset}"] [data-workout-kg]`)?.focus();
    return;
  }
  if(d.workoutRemove!==undefined){
    const {i,j,item}=workoutRow(b);
    if(item.sets.length>1)item.sets.splice(j,1);
    render();queueDraft();
    $(`[data-workout-item="${i}"] [data-workout-add]`)?.focus({preventScroll:true});
    return;
  }
  if(d.workoutCheck!==undefined){
    const {row,item,set}=workoutRow(b);
    if(!set.done&&!validDraft(set)){ $('#workout-error').textContent='Renseigne la charge et les répétitions avant de cocher cette série.';row.classList.add('needs-values');$(!set.kg?'[data-workout-kg]':'[data-workout-reps]',row).focus();return;}
    set.done=!set.done;
    b.setAttribute('aria-pressed',set.done);
    $('.workout-row',row).classList.toggle('done',set.done);row.classList.remove('needs-values');
    const checked=state.draft.items.reduce((n,item)=>n+item.sets.filter(s=>s.done).length,0);
    $('#workout-checked').textContent=checked;
    $('#workout-form [type="submit"]').disabled=!checked;
    $('#workout-error').textContent='';
    if(set.done)startTimer(item);
    queueDraft();
    return;
  }
  if(d.workoutCancel!==undefined){
    modalConfirm('Abandonner le brouillon ?','Les séries de cette séance ne seront pas conservées. Pour garder le brouillon, ferme cette fenêtre et change d’onglet dans Forge.','data-confirm-workout','Abandonner la séance');
    return;
  }
  if(d.confirmWorkout!==undefined){
    b.disabled=true;
    try{await request('/carnet/draft/close',json('POST',{id:state.draft.id}));$('#confirm').close();state.draft=null;pendingDraft=null;clearTimeout(draftTimer);endTimer();render();}
    catch(err){$('.form-error',$('#confirm')).textContent=err.message;b.disabled=false;}
    return;
  }
  if(d.restStop!==undefined){endTimer();queueDraft();return;}
  if(d.portable){
    const name='forge-hors-connexion.html';
    if(d.portable==='save'){downloadFile(currentPortableFile(),'text/html',name);return;}
    b.disabled=true;
    try{
      const resp=await fetch(`${endpoint}/carnet/portable`,{cache:'no-store'});
      if(!resp.ok)throw new Error('La copie hors connexion n’a pas pu être générée.');
      const html=await resp.text();
      if(!html.includes('id="forge-snapshot"'))throw new Error('La copie hors connexion est indisponible.');
      downloadFile(html,'text/html',name);
      toast('Copie hors connexion téléchargée.');
    }catch(err){$('.form-error',b.closest('.offline-card')).textContent=err.message;}
    finally{b.disabled=false;}
    return;
  }
  if(d.lookReset!==undefined){
    const f=$('#appearance-form');
    for(const [name,value] of Object.entries(standardLook))f.elements[name].value=value;
    state.previewLook={...standardLook};showLook();
    $('.appearance-status',f).textContent='Réglages d’origine affichés. Enregistre pour les garder.';
    return;
  }
  if(d.backup==='download'){try{downloadBackup();}catch{$('#backup-error').textContent='Le navigateur n’a pas pu créer le fichier.';}return;}
  if(d.backup==='pick')return $('#backup-file')?.click();
  if(d.backup==='install'&&installPrompt){try{await installPrompt.prompt();}catch{toast('Utilise le menu du navigateur pour ajouter Forge.');}installPrompt=null;render();return;}
  if(d.action==='add-set'||d.action==='add-warmup'){
    $('#log-form').dataset.setsTouched='yes';
    const last=$('#set-rows').lastElementChild;
    const kg=$('[data-kg]',last).valueAsNumber;
    const warmup=d.action==='add-warmup';
    const ref=warmup?[...$('#set-rows').children].find(row=>$('[data-kind]',row).value==='work'):null;
    if(ref)ref.insertAdjacentHTML('beforebegin',setRow(0,{kind:'warmup'}));
    else $('#set-rows').insertAdjacentHTML('beforeend',setRow($('#set-rows').children.length,{kind:warmup?'warmup':'work',kg:!warmup&&Number.isFinite(kg)?kg:undefined}));
    updateRows(); const row=ref?.previousElementSibling||$('#set-rows').lastElementChild;
    $(warmup?'[data-kg]':'[data-reps]',row).focus();return;
  }
  if(d.remove!==undefined){ $('#log-form').dataset.setsTouched='yes';b.closest('.manual-set').remove();updateRows();$('[data-action="add-set"]').focus();return; }
  if(d.close) return $(`#${d.close}`).close();
  if(d.edit) return openEditor(state.data.find(v=>v.id===d.edit));
  if(d.delete) return deleteDialog(d.delete);
  if(d.confirm){
    b.disabled=true;
    try { state.data=await api(`/${d.confirm}`,{method:'DELETE'}); state.error=''; $('#confirm').close(); syncSelection();render();toast('Entrée supprimée.'); }
    catch(err){$('.form-error',$('#confirm')).textContent=err.message;b.disabled=false;}
  }
});
document.addEventListener('input',e=>{
  if(e.target.closest('.manual-set'))$('#log-form').dataset.setsTouched='yes';
  if(!state.draft||!e.target.closest('#workout-form'))return;
  const t=e.target;
  if(t.name==='workout-date'){state.draft.date=t.value;queueDraft();return;}
  if(t.dataset.workoutEffort!==undefined){
    state.draft.items[Number(t.dataset.workoutEffort)].efforts=[...t.closest('fieldset').querySelectorAll('input:checked')].map(x=>x.value);
    $('#workout-error').textContent='';
    queueDraft();
    return;
  }
  const obj=workoutRow(t);
  if(obj){
    if(t.hasAttribute('data-workout-kg'))obj.set.kg=t.value;
    if(t.hasAttribute('data-workout-reps'))obj.set.reps=t.value;
    if(t.hasAttribute('data-kind')){obj.set.kind=t.value;obj.row.classList.toggle('warmup',t.value==='warmup');}
    if(t.hasAttribute('data-set-effort')){obj.set.efforts=[...t.closest('fieldset').querySelectorAll('input:checked')].map(x=>x.value);syncEffortCount(t);}
    queueDraft();
  }
});
function syncEffortCount(t){
  const details=t.closest('details'),summary=$('summary',details);
  const count=details.querySelectorAll('input:checked').length;
  summary.innerHTML=`Ressenti de la série${count?` <span class="series-count">${count}</span>`:''}`;
}
document.addEventListener('change',async e=>{
  if(e.target.closest('.manual-set')&&e.target.hasAttribute('data-kind'))e.target.closest('.manual-set').classList.toggle('warmup',e.target.value==='warmup');
  if(e.target.closest('.manual-set')&&e.target.hasAttribute('data-set-effort'))syncEffortCount(e.target);
  if(e.target.closest('#appearance-form')){
    const f=e.target.form;
    state.previewLook=Object.fromEntries(new FormData(f));showLook();
    const status=$('.appearance-status',f);status.classList.remove('form-error');status.textContent='Aperçu en cours. Enregistre pour garder ces réglages.';
    return;
  }
  if(e.target.name==='efforts'&&e.target.checked&&$('#form-error')?.textContent==='Choisis au moins un ressenti.')$('#form-error').textContent='';
  if(e.target.id==='backup-file'){
    const file=e.target.files?.[0];
    if(!file)return;
    const b=$('[data-backup="pick"]'),error=$('#backup-error');
    b.disabled=true;error.textContent='';
    try {
      if(file.size>2*1024*1024)throw new Error('Ce fichier dépasse la limite de 2 Mo.');
      let archive;try{archive=JSON.parse(await file.text());}catch{throw new Error('Le fichier doit être une sauvegarde Forge au format JSON.');}
      closeLookPreview();applyCarnet(await request('/carnet/restore',json('POST',archive)));state.error='';syncSelection();render();toast('Sauvegarde restaurée. Le carnet actuel a été conservé.');
    }catch(err){error.textContent=err.message;b.disabled=false;e.target.value='';}
    return;
  }
  if(e.target.id==='exercise'){state.exercise=e.target.value;render();$('#exercise')?.focus({preventScroll:true});}
  if(e.target.name==='exercise'&&!$('#log-form')?.dataset.id){
    const f=$('#log-form');
    const k=key(e.target.value);
    if(f&&k!==f.dataset.exerciseKey){
      f.dataset.exerciseKey=k;
      const cfg=goals(e.target.value),last=previousFor(e.target.value)[0];
      f.elements.min.value=cfg.min;f.elements.max.value=cfg.max;f.elements.step.value=cfg.step;f.elements.loadMode.value=cfg.loadMode;
      if(!f.dataset.setsTouched){
        const prefilled=last?.effort!=='pain'&&last&&(last.loadMode||'total')===cfg.loadMode&&working(last).length?working(last):[{}];
        $('#set-rows').innerHTML=prefilled.map((s,i)=>setRow(i,{kg:s.kg})).join('');updateRows();
      }
    }
  }
});
document.addEventListener('submit',async e=>{
  const f=e.target;
  if(f.id==='profile-form'){
    e.preventDefault();
    const button=$('[type="submit"]',f), error=$('.form-error',f), fields=new FormData(f);
    const v={name:fields.get('profile-exercise').trim(),min:Number(fields.get('min')),max:Number(fields.get('max')),step:Number(fields.get('step')),loadMode:fields.get('loadMode')};
    if(!v.name||v.max<=v.min){error.textContent='Renseigne l’exercice et une plage de répétitions valide.';return;}
    button.disabled=true;
    try{applyCarnet(await request('/carnet/profile',json('PUT',v)));$('#profile-dialog').close();render();toast('Réglages enregistrés pour cet exercice.');}
    catch(err){error.textContent=err.message;button.disabled=false;}
    return;
  }
  if(f.id==='appearance-form'){
    e.preventDefault();
    if(state.savingLook)return;
    const values=Object.fromEntries(new FormData(f));
    const status=$('.appearance-status',f);
    state.savingLook=true;
    const controls=[...f.querySelectorAll('button,input')];controls.forEach(n=>n.disabled=true);
    status.classList.remove('form-error');status.textContent='Enregistrement…';
    try{
      applyCarnet(await request('/carnet/appearance',json('PUT',values)));
      closeLookPreview();
      if(status.isConnected)status.textContent='Apparence enregistrée.';
      else toast('Apparence enregistrée.');
    }catch(err){
      status.classList.add('form-error');status.textContent=err.message;
      if(!status.isConnected)toast(err.message);
    }finally{
      state.savingLook=false;controls.forEach(n=>n.disabled=false);
      if(!f.isConnected&&state.view==='data')render();
    }
    return;
  }
  if(f.id==='program-form'){
    e.preventDefault();
    const button=$('[type="submit"]',f),error=$('.form-error',f);
    const name=f.elements['program-name'].value.trim();
    const exercises=[...f.querySelectorAll('.program-row')].map(row=>({name:$('[data-program-name]',row).value.trim(),count:$('[data-program-count]',row).valueAsNumber,rest:$('[data-program-rest]',row).valueAsNumber}));
    if(!name||exercises.some(x=>!x.name)){error.textContent='Renseigne le nom du programme et de tous les exercices.';return;}
    if(new Set(exercises.map(x=>key(x.name))).size!==exercises.length){error.textContent='Un exercice ne peut apparaître qu’une fois dans le programme.';return;}
    button.disabled=true;error.textContent='';
    try{applyCarnet(await request('/carnet/program',json('PUT',{id:f.dataset.id||newId(),name,exercises})));state.error='';$('#program-dialog').close();render();toast('Programme enregistré.');}
    catch(err){error.textContent=err.message;button.disabled=false;}
    return;
  }
  if(f.id==='workout-form'){
    e.preventDefault();
    const error=$('#workout-error'),d=state.draft,button=$('[type="submit"]',f);
    if(!d)return;
    const items=d.items.filter(item=>item.sets.some(s=>s.done));
    if(!items.length||items.some(item=>item.sets.some(s=>s.done&&!validDraft(s)))){error.textContent='Vérifie les valeurs des séries cochées.';return;}
    const missing=items.find(item=>!item.efforts.length&&item.sets.some(s=>s.done&&s.kind==='work')&&!item.sets.some(s=>s.done&&s.kind==='work'&&s.efforts.length));
    if(missing){
      error.textContent=`Choisis au moins un ressenti pour ${missing.name}.`;
      $(`[data-workout-effort="${d.items.indexOf(missing)}"]`,f)?.focus();
      return;
    }
    const payload=items.map(item=>({date:d.date,exercise:item.name,efforts:item.efforts,min:item.min,max:item.max,step:item.step,loadMode:item.loadMode,sets:item.sets.filter(s=>s.done).map(s=>({kg:Number(s.kg),reps:Number(s.reps),kind:s.kind,efforts:s.efforts}))}));
    button.disabled=true;error.textContent='';
    try{state.data=await request('/carnet/session',json('POST',{id:d.id,name:d.program.name,items:payload}));state.error='';state.draft=null;pendingDraft=null;clearTimeout(draftTimer);state.mode='real';state.exercise=items[0].name;endTimer();move('history');toast(portable?'Séance enregistrée dans cette copie. Télécharge-la pour la garder.':'Séance enregistrée. Seules les séries cochées ont été ajoutées.');}
    catch(err){error.textContent=err.message;button.disabled=false;}
    return;
  }
  if(f.id!=='log-form')return;
  e.preventDefault();
  const error=$('#form-error'), data=new FormData(f), id=f.dataset.id;
  error.textContent='';
  const exercise=data.get('exercise').trim();
  if(!exercise){error.textContent='Renseigne un nom d’exercice.';f.elements.exercise.focus();return;}
  const min=Number(data.get('min')),max=Number(data.get('max'));
  if(max<=min){error.textContent='Le maximum de répétitions doit dépasser le minimum.';f.elements.max.focus();return;}
  const selected=data.getAll('efforts');
  const sets=[...f.querySelectorAll('.manual-set')].map(row=>({kg:$('[data-kg]',row).valueAsNumber,reps:$('[data-reps]',row).valueAsNumber,kind:$('[data-kind]',row).value,efforts:[...row.querySelectorAll('[data-set-effort]:checked')].map(x=>x.value)}));
  if(!selected.length&&sets.some(s=>s.kind==='work')&&!sets.some(s=>s.kind==='work'&&s.efforts.length)){error.textContent='Choisis au moins un ressenti.';$('[name="efforts"]',f)?.focus();return;}
  const payload={exercise,date:data.get('date'),efforts:selected,min,max,step:Number(data.get('step')),loadMode:data.get('loadMode'),sets};
  const button=$('[type="submit"]',f);button.disabled=true;button.textContent='Enregistrement…';
  try{
    state.data=await api(id?`/${id}`:'',{method:id?'PUT':'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    state.error=''; $('#editor').close(); state.mode='real'; state.exercise=exercise; state.period=30;
    syncSelection(); render(); if(state.view!=='history') window.scrollTo(0,0);
    toast(id?'Séance modifiée.':'Séance enregistrée dans ton carnet.');
  } catch(err){error.textContent=err.message;button.disabled=false;button.textContent='Enregistrer';}
});
let frame;
window.addEventListener('resize',()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(drawGraph);});
setup();
