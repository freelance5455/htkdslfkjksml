(() => {
  const KEY='study-sanctuary-v1';
  const quotes=[
    'Small progress is still progress.','Deep work is a superpower.','Protect your attention. It becomes your future.',
    'One page. One problem. One step.','You do not need motivation. Just begin.','Make the next hour count.'
  ];
  const state=Object.assign({
    goal:'',theme:'forest',sound:true,stretch:false,ambient:false,selectedMinutes:120,
    remaining:7200,total:7200,running:false,completedSessions:0,focusTodaySeconds:0,
    streak:0,lastStudyDate:null,lastSavedAt:Date.now(),activeSessionSeconds:0,nextMilestone:1800,nextStretch:3600,
    sawCompletion:false
  },JSON.parse(localStorage.getItem(KEY)||'{}'));
  const $=id=>document.getElementById(id);
  const timer=$('timer'), focusTimer=$('focusTimer'), ring=$('progressRing');
  const radius=142, circumference=2*Math.PI*radius; ring.style.strokeDasharray=`${circumference}`;

  function save(){state.lastSavedAt=Date.now();localStorage.setItem(KEY,JSON.stringify(state))}
  function hydrateElapsed(){
    if(!state.running)return;
    const elapsed=Math.max(0,Math.floor((Date.now()-(state.lastSavedAt||Date.now()))/1000));
    if(elapsed){tick(elapsed,true)}
  }
  function format(sec){
    sec=Math.max(0,Math.floor(sec)); const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;
    return [h,m,s].map(v=>String(v).padStart(2,'0')).join(':');
  }
  function minutesLabel(sec){const m=Math.floor(sec/60); return m<60?`${m}m`:`${Math.floor(m/60)}h ${m%60?m%60+'m':''}`.trim()}
  function dateKey(){return new Date().toLocaleDateString('en-CA')}
  function applyTheme(){
    document.documentElement.dataset.theme=state.theme;
    $('themeSelect').value=state.theme;
    document.querySelectorAll('.ambient').forEach(el=>el.style.opacity=state.ambient?'.85':'.55');
  }
  function render(){
    const pct=state.total?Math.max(0,Math.min(1,1-state.remaining/state.total)):0;
    timer.textContent=format(state.remaining);focusTimer.textContent=format(state.remaining);
    $('currentPercent').textContent=Math.round(pct*100)+'%';
    $('focusedToday').textContent=minutesLabel(state.focusTodaySeconds);
    $('sessionsToday').textContent=state.completedSessions;
    $('streak').textContent=`${state.streak} day${state.streak===1?'':'s'}`;
    ring.style.strokeDashoffset=circumference*(1-pct);
    $('focusProgressBar').style.width=(pct*100)+'%';
    $('savedGoal').textContent=state.goal?`Focus: ${state.goal}`:'No focus set yet.';
    $('focusGoal').textContent=state.goal||'Study with intention.';
    $('timerStatus').textContent=state.running?'Deep focus is in progress.':state.remaining===0?'Session complete — excellent work ✦':'Ready when you are.';
    $('mainBtn').textContent=state.running?'Pause':'Start Focus';
    $('mainBtn').setAttribute('aria-label',state.running?'Pause focus session':'Start focus session');
    document.querySelectorAll('.presets button').forEach(b=>b.classList.toggle('active',Number(b.dataset.minutes)===Math.round(state.total/60)));
    $('milestone').textContent=state.remaining===0?'Session complete — excellent work ✦':`Next milestone: ${Math.max(30,Math.ceil((state.activeSessionSeconds+1)/1800)*30)} minutes of focus ✦`;
  }
  function showToast(msg){
    const el=document.createElement('div');el.className='toast';el.textContent=msg;$('toastRegion').appendChild(el);
    setTimeout(()=>el.remove(),3200);
  }
  function chime(){
    if(!state.sound)return;
    try{
      const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
      const c=new C(),o=c.createOscillator(),g=c.createGain();
      o.type='sine';o.frequency.setValueAtTime(520,c.currentTime);o.frequency.exponentialRampToValueAtTime(680,c.currentTime+.32);
      g.gain.setValueAtTime(.0001,c.currentTime);g.gain.exponentialRampToValueAtTime(.045,c.currentTime+.02);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+.55);
      o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.56);
    }catch{}
  }
  function studyDay(date=dateKey()){
    if(state.lastStudyDate===date)return;
    if(!state.lastStudyDate)state.streak=1;
    else{
      const prev=new Date(state.lastStudyDate+'T12:00:00'),cur=new Date(date+'T12:00:00');
      const diff=Math.round((cur-prev)/86400000);state.streak=diff===1?state.streak+1:1;
    }
    state.lastStudyDate=date;
  }
  function tick(delta=1,restoring=false){
    if(!state.running)return;
    const before=Math.max(0,state.remaining),actual=Math.min(delta,before);
    state.remaining=before-actual;state.focusTodaySeconds+=actual;state.activeSessionSeconds+=actual;
    if(actual>0)studyDay();
    if(!restoring&&state.stretch&&state.activeSessionSeconds>=state.nextStretch){
      showToast('Stretch, breathe and drink some water ✦');state.nextStretch+=3600;
    }
    while(state.activeSessionSeconds>=state.nextMilestone&&state.remaining>0){
      showToast(`${Math.floor(state.nextMilestone/60)} minutes of focus ✦`);state.nextMilestone+=1800;
    }
    if(state.remaining<=0){
      state.running=false;state.completedSessions++;state.sawCompletion=true;
      showToast('Session complete — excellent work ✦');chime();
      $('quote').textContent=quotes[Math.floor(Math.random()*quotes.length)];
    }
    save();render();
  }
  function setPreset(min){
    state.selectedMinutes=min;state.total=min*60;state.remaining=min*60;state.running=false;
    state.activeSessionSeconds=0;state.nextMilestone=1800;state.nextStretch=3600;state.sawCompletion=false;save();render();
  }
  function toggleTimer(){
    if(state.remaining<=0)setPreset(state.selectedMinutes);
    state.running=!state.running;state.lastSavedAt=Date.now();save();render();
  }
  function reset(){state.running=false;state.remaining=state.total;state.activeSessionSeconds=0;state.nextMilestone=1800;state.nextStretch=3600;state.sawCompletion=false;save();render()}
  function addTen(){state.remaining+=600;state.total+=600;state.selectedMinutes=Math.round(state.total/60);save();render();showToast('10 minutes added ✦')}
  function focus(open){
    $('focusOverlay').hidden=!open;
    if(open){$('exitFocus').focus()}else{$('focusMode').focus()}
  }
  function updateClock(){
    const now=new Date();
    $('liveTime').textContent=now.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit',second:'2-digit'});
    $('liveDate').textContent=now.toLocaleDateString([],{weekday:'long',day:'numeric',month:'long'});
  }

  $('saveGoal').onclick=()=>{state.goal=$('goalInput').value.trim();save();render();showToast(state.goal?'Study intent saved ✦':'Study intent cleared')};
  $('goalInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('saveGoal').click()});
  $('mainBtn').onclick=toggleTimer;$('resetBtn').onclick=reset;$('addBtn').onclick=addTen;
  $('focusMode').onclick=()=>focus(true);$('exitFocus').onclick=()=>focus(false);
  document.querySelectorAll('.presets button').forEach(b=>b.onclick=()=>setPreset(Number(b.dataset.minutes)));
  $('themeSelect').onchange=e=>{state.theme=e.target.value;applyTheme();save()};
  $('soundToggle').onchange=e=>{state.sound=e.target.checked;save()};
  $('stretchToggle').onchange=e=>{state.stretch=e.target.checked;save()};
  $('ambientToggle').onchange=e=>{state.ambient=e.target.checked;applyTheme();save()};

  document.addEventListener('keydown',e=>{
    const tag=(e.target.tagName||'').toLowerCase();if(['input','textarea','select'].includes(tag))return;
    if(e.code==='Space'){e.preventDefault();toggleTimer()}
    else if(e.key.toLowerCase()==='r')reset()
    else if(e.key.toLowerCase()==='f')focus($('focusOverlay').hidden)
    else if(e.key==='+'||e.key==='=')addTen()
    else if(e.key==='Escape'&&!$('focusOverlay').hidden)focus(false)
    else if(['1','2','3','4','5'].includes(e.key))setPreset({1:60,2:90,3:120,4:180,5:240}[e.key])
  });

  setInterval(()=>{if(state.running)tick(1);updateClock()},1000);
  updateClock();applyTheme();
  $('soundToggle').checked=state.sound;$('stretchToggle').checked=state.stretch;$('ambientToggle').checked=state.ambient;
  $('goalInput').value=state.goal;hydrateElapsed();render();
  if(!state.running)$('quote').textContent=quotes[Math.floor(Math.random()*quotes.length)];
})();
