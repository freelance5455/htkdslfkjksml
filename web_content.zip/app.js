(()=>{"use strict";
const KEY="tahbaliya_accounts_v2",OLD="tahbaliya_transactions_v1", $=id=>document.getElementById(id);
const uid=()=>typeof crypto!=="undefined"&&crypto.randomUUID?crypto.randomUUID():Date.now()+"-"+Math.random().toString(16).slice(2);
const today=()=>{let d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,10)};
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const money=n=>new Intl.NumberFormat("ar",{maximumFractionDigits:2}).format(Math.round(((Number(n)||0)+Number.EPSILON)*100)/100);
let state=load();
function load(){
 try{let s=JSON.parse(localStorage.getItem(KEY)||"null");if(s&&Array.isArray(s.people)&&Array.isArray(s.entries))return s}catch(e){}
 let s={people:[],entries:[]};
 // Bring across named debt transactions from the older app when running in the same browser storage.
 try{let old=JSON.parse(localStorage.getItem(OLD)||"[]"),names={};if(Array.isArray(old))old.forEach(t=>{
  if(!t||!String(t.person||"").trim()||!(Number(t.amount)>0))return;
  if(!names[t.person]){names[t.person]=uid();s.people.push({id:names[t.person],name:String(t.person).trim(),phone:"",note:""})}
  const map={lend:"they_owe",borrow:"i_owe",collect:"they_paid",repay:"i_paid"};
  if(map[t.type])s.entries.push({id:uid(),personId:names[t.person],type:map[t.type],amount:Number(t.amount),date:t.date||today(),note:t.note||"منقول من السجل السابق",createdAt:t.createdAt||Date.now()});
 })}catch(e){}
 return s
}
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));return true}catch(e){alert("تعذّر حفظ البيانات. صدّر نسخة احتياطية وتأكد من مساحة الجهاز.");return false}}
function balance(id,excludeId=null){
 let b={they:0,me:0};
 state.entries.filter(e=>e.personId===id&&e.id!==excludeId).forEach(e=>{let a=Number(e.amount)||0;
  if(e.type==="they_owe")b.they+=a;
  if(e.type==="they_paid")b.they-=a;
  if(e.type==="i_owe")b.me+=a;
  if(e.type==="i_paid")b.me-=a;
 });
 b.they=Math.round((b.they+Number.EPSILON)*100)/100;b.me=Math.round((b.me+Number.EPSILON)*100)/100;return b
}
function render(){
 let allThey=0,allMe=0;state.people.forEach(p=>{let b=balance(p.id);allThey+=Math.max(0,b.they);allMe+=Math.max(0,b.me)});
 $("totalThey").textContent=money(allThey);$("totalMe").textContent=money(allMe);$("net").textContent=money(allThey-allMe);$("count").textContent=money(state.people.length);
 let q=$("search").value.trim().toLocaleLowerCase(),ps=state.people.filter(p=>p.name.toLocaleLowerCase().includes(q)||(p.phone||"").includes(q));
 $("people").innerHTML=ps.length?ps.map(p=>{let b=balance(p.id),n=state.entries.filter(e=>e.personId===p.id).length;return `<article class="person"><div class="avatar">${esc(p.name.slice(0,1))}</div><div class="person-main"><div class="pname">${esc(p.name)}</div><div class="muted">${esc(p.phone||"بدون رقم")} • ${n} حركة</div><div class="tags"><span class="tag green">هو مطالب لي: ${money(Math.max(0,b.they))}</span><span class="tag red">أنا مطالب ليهو: ${money(Math.max(0,b.me))}</span></div></div><div class="pactions"><button class="primary small" data-account="${esc(p.id)}">الحساب</button><button class="outline small" data-person-edit="${esc(p.id)}">تعديل</button><button class="danger small" data-person-del="${esc(p.id)}">حذف</button></div></article>`}).join(""):`<div class="empty">${q?"ما لقينا شخص بالاسم دا.":"لسه ما أضفت أشخاص. اضغط إضافة شخص عشان تبدأ."}</div>`;
}
function show(html){$("modal").innerHTML=html;$("wrap").classList.remove("hidden")}
function close(){$("wrap").classList.add("hidden");$("modal").innerHTML=""}
$("wrap").addEventListener("click",e=>{if(e.target===$("wrap"))close()});
function personForm(id){
 let p=id?state.people.find(x=>x.id===id):null;
 show(`<h2>${p?"تعديل بيانات الشخص":"إضافة شخص جديد"}</h2><form id="pf"><div class="field"><label>اسم الشخص *</label><input id="pn" maxlength="100" required value="${esc(p?.name||"")}" placeholder="مثلاً: أبوي"></div><div class="field"><label>رقم تلفون (اختياري)</label><input id="pp" value="${esc(p?.phone||"")}" inputmode="tel"></div><div class="field"><label>ملاحظات (اختياري)</label><textarea id="pnote">${esc(p?.note||"")}</textarea></div><div class="actions"><button class="primary">حفظ الشخص</button><button class="outline" type="button" id="cancel">إلغاء</button></div></form>`);
 $("cancel").onclick=close;$("pf").onsubmit=e=>{e.preventDefault();let name=$("pn").value.trim();if(!name)return;
 if(state.people.some(x=>x.name.toLocaleLowerCase()===name.toLocaleLowerCase()&&x.id!==id)){alert("في شخص بنفس الاسم. أضف وصفاً للاسم عشان تميّزو.");return}
 if(p){p.name=name;p.phone=$("pp").value.trim();p.note=$("pnote").value.trim()}else state.people.push({id:uid(),name,phone:$("pp").value.trim(),note:$("pnote").value.trim()});
 if(save()){close();render()}
 }
}
const typeLabels={they_owe:"دين جديد عليه (مستحق لي)",i_owe:"دين جديد عليّ (مستحق ليهو)",they_paid:"سداد منه لي",i_paid:"سداد مني ليهو"};
function account(id){
 let p=state.people.find(x=>x.id===id);if(!p)return;let b=balance(id);
 let es=state.entries.filter(e=>e.personId===id).sort((a,b)=>(b.date||"").localeCompare(a.date||"")||(b.createdAt||0)-(a.createdAt||0));
 show(`<div class="section" style="margin:0 0 12px"><h2>حساب ${esc(p.name)}</h2><button class="outline small" id="close">إغلاق</button></div>
 <div class="total"><div>المستحق لي من ${esc(p.name)}</div><strong>${money(Math.max(0,b.they))} ج.س</strong><div class="hint" style="color:#d8e9e1">المبلغ الباقي للشخص يسدده ليك</div></div>
 <div class="twobal"><div class="mini"><span>هو مطالب لي</span><strong>${money(Math.max(0,b.they))}</strong></div><div class="mini"><span>أنا مطالب ليهو</span><strong>${money(Math.max(0,b.me))}</strong></div></div>
 <div class="actions"><button class="primary" id="debt">＋ تسجيل دين</button><button class="soft" id="payment">↔ تسجيل سداد</button></div><hr><div class="section" style="margin:0"><h2>كشف الحركات</h2><span class="muted">${es.length} حركة</span></div>
 <div id="elist">${es.length?es.map(e=>{let plus=e.type==="they_owe"||e.type==="i_owe";return `<div class="entry"><div class="entrytop"><div><div class="entrytitle">${esc(typeLabels[e.type]||e.type)}</div><div class="muted">${esc(e.date||"")}</div></div><div class="entryamt">${plus?"+":"−"} ${money(e.amount)}</div></div>${e.note?`<div class="entrynote">${esc(e.note)}</div>`:""}<div class="entryactions"><button class="outline small" data-entry-edit="${esc(e.id)}">تعديل</button><button class="danger small" data-entry-del="${esc(e.id)}">حذف</button></div></div>`}).join(""):`<div class="empty">مافي حركات مسجلة للشخص دا.</div>`}</div>
 <p class="hint">مثال: تسجّل دين 300، وبعدها تسجّل سداد منه 50؛ المتبقي ليك 250. حساب كل شخص منفصل.</p>`);
 $("close").onclick=close;$("debt").onclick=()=>entryForm(id,null,"debt");$("payment").onclick=()=>entryForm(id,null,"payment");
 $("elist").addEventListener("click",e=>{let ed=e.target.closest("[data-entry-edit]"),del=e.target.closest("[data-entry-del]");if(ed)entryForm(id,ed.dataset.entryEdit,"edit");if(del){let ent=state.entries.find(x=>x.id===del.dataset.entryDel);if(ent&&confirm("متأكد داير تحذف الحركة دي؟ الرصيد حيتحسب من جديد.")){state.entries=state.entries.filter(x=>x.id!==ent.id);if(save()){render();account(id)}}}});
}
function entryForm(pid,eid,mode){
 let p=state.people.find(x=>x.id===pid),e=eid?state.entries.find(x=>x.id===eid):null;if(!p)return;
 let opts=mode==="debt"?[["they_owe","هو مطالب لي (دين ليك عليه)"],["i_owe","أنا مطالب ليهو (دين عليك ليهو)"]]:mode==="payment"?[["they_paid","هو سدّد لي (ينقص دينو ليك)"],["i_paid","أنا سدّدت ليهو (ينقص دينك)"]]:Object.entries(typeLabels);
 show(`<h2>${e?"تعديل حركة":mode==="payment"?"تسجيل سداد":"تسجيل دين"} — ${esc(p.name)}</h2><form id="ef"><div class="field"><label>نوع الحركة *</label><select id="et">${opts.map(o=>`<option value="${esc(o[0])}" ${(e?.type||opts[0][0])===o[0]?"selected":""}>${esc(o[1])}</option>`).join("")}</select></div><div class="field"><label>المبلغ بالجنيه السوداني *</label><input id="ea" type="number" min="0.01" step="0.01" inputmode="decimal" required value="${esc(e?.amount??"")}" placeholder="مثلاً: 300"></div><div class="field"><label>التاريخ *</label><input id="edate" type="date" required value="${esc(e?.date||today())}"></div><div class="field"><label>ملاحظات (اختياري)</label><textarea id="enote" placeholder="مثلاً: سداد جزء من الدين">${esc(e?.note||"")}</textarea></div><p class="hint">التطبيق بحسب المتبقي تلقائياً؛ ما محتاج تكتب الرصيد بيدك.</p><div class="actions"><button class="primary">${e?"حفظ التعديل":"حفظ الحركة"}</button><button class="outline" type="button" id="cancelentry">إلغاء</button></div></form>`);
 $("cancelentry").onclick=()=>account(pid);
 $("ef").onsubmit=ev=>{ev.preventDefault();let amount=Number($("ea").value),type=$("et").value,date=$("edate").value;if(!(amount>0)||!Number.isFinite(amount)||!date){alert("راجع المبلغ والتاريخ.");return}
 if(type==="they_paid"||type==="i_paid"){let b=balance(pid,e?.id||null),remaining=type==="they_paid"?b.they:b.me;if(amount>remaining){alert("مبلغ السداد أكبر من الرصيد المتبقي ("+money(Math.max(0,remaining))+"). راجع المبلغ أو سجّل ديناً صحيحاً أولاً.");return}}
 let obj={id:e?.id||uid(),personId:pid,type,amount,date,note:$("enote").value.trim(),createdAt:e?.createdAt||Date.now(),updatedAt:Date.now()};
 if(e){let i=state.entries.findIndex(x=>x.id===e.id);if(i>=0)state.entries[i]=obj}else state.entries.push(obj);
 if(save()){render();account(pid)}
 }
}
$("addPerson").onclick=()=>personForm(null);$("search").addEventListener("input",render);
$("people").addEventListener("click",e=>{
 let a=e.target.closest("[data-account]"),ed=e.target.closest("[data-person-edit]"),del=e.target.closest("[data-person-del]");
 if(a)account(a.dataset.account);if(ed)personForm(ed.dataset.personEdit);
 if(del){let p=state.people.find(x=>x.id===del.dataset.personDel);if(!p)return;let n=state.entries.filter(x=>x.personId===p.id).length;if(confirm(n?`حذف ${p.name} حيحذف حسابو وكل حركاتو (${n} حركة). متأكد؟`:`متأكد داير تحذف ${p.name}؟`)){state.people=state.people.filter(x=>x.id!==p.id);state.entries=state.entries.filter(x=>x.personId!==p.id);if(save())render()}}
});
$("export").onclick=()=>{let blob=new Blob([JSON.stringify({app:"TahbaliyaAccounts",version:2,exportedAt:new Date().toISOString(),...state},null,2)],{type:"application/json;charset=utf-8"});let url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="tahbaliya-backup-"+today()+".json";document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500)};
$("import").onchange=async e=>{let f=e.target.files?.[0];if(!f)return;try{let d=JSON.parse(await f.text());if(!Array.isArray(d.people)||!Array.isArray(d.entries)||!d.people.every(p=>p.id&&p.name)||!d.entries.every(x=>x.id&&x.personId&&["they_owe","i_owe","they_paid","i_paid"].includes(x.type)&&Number(x.amount)>0))throw Error();if(confirm("استيراد النسخة حيستبدل الحسابات الحالية. الأفضل تصدّر نسخة من الحالية أولاً. موافق؟")){state={people:d.people,entries:d.entries};if(save()){render();alert("تم استرجاع النسخة بنجاح.")}}}catch(err){alert("الملف غير صالح أو ما تابع لنسخة حسابات الطبلية.")}finally{e.target.value=""}};
render();
})();
