

const NOTES_KEY='baraa_notes_v1';
const SETTINGS_KEY='baraa_settings_v1';
const SECURE_KEY='baraa_secure_blob_v1';
const META_KEY='baraa_secure_meta_v1';
const PBKDF2_ITERATIONS=250000;
const themes=[
  ['#19bfd0','#ead3b5','#f7e7cf'],
  ['#7e57c2','#ded5e9','#f0e8f5'],
  ['#2e7d32','#d9e4d5','#edf4ea'],
  ['#d46a1f','#ead9c8','#f7eee5'],
  ['#c44569','#efd6df','#faedf1'],
  ['#2878b5','#d7e6f2','#edf6fb'],
  ['#6d4c41','#dfd0c8','#f3ebe7']
];
const NOTE_COLORS = themes.map(x=>x[0]);
let notes=[];
let settings={dark:false,theme:0,layout:'grid',autoLock:true,lang:'ar'};
let editorOpen=false;
let editorHistory=false;
let appKey=null;
let secureSalt=null;
let lockBusy=false;
let unlockAttempts=0;
let lockoutUntil=0;
let favoritesOnly=false;
let pinnedOnly=false;
let searchQuery='';
let sortMode='newest';
const SORT_MODES=['newest','oldest','title'];
let editorFavorite=false, editorPinned=false, editorColor=null, editorRemovePassword=false;
let splashDone=false;

const $=id=>document.getElementById(id);

function b64(bytes){return btoa(String.fromCharCode(...new Uint8Array(bytes)))}
function fromB64(s){const bin=atob(s);return Uint8Array.from(bin,c=>c.charCodeAt(0))}
async function deriveKey(password,salt){
  const material=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:PBKDF2_ITERATIONS,hash:'SHA-256'},material,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
async function encryptData(data,key){
  const iv=crypto.getRandomValues(new Uint8Array(12));
  const plain=new TextEncoder().encode(JSON.stringify(data));
  const cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,plain);
  return JSON.stringify({iv:b64(iv),data:b64(cipher)});
}
async function decryptData(blob,key){
  const x=JSON.parse(blob);
  const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:fromB64(x.iv)},key,fromB64(x.data));
  return JSON.parse(new TextDecoder().decode(plain));
}
function saveSettings(){localStorage.setItem(SETTINGS_KEY,JSON.stringify(settings))}
function loadSettings(){try{settings={...settings,...JSON.parse(localStorage.getItem(SETTINGS_KEY)||'{}')}}catch{}}
let saveChain=Promise.resolve();
function save(){
  if(!appKey) return Promise.reject(new Error('APP_LOCKED'));
  const snapshot=JSON.parse(JSON.stringify(notes));
  const key=appKey;
  saveChain=saveChain.catch(()=>{}).then(async()=>{
    const encrypted=await encryptData({version:1,notes:snapshot},key);
    localStorage.setItem(SECURE_KEY,encrypted);
    saveSettings();
    return true;
  });
  return saveChain;
}
function purgeExpired(){notes=notes.filter(n=>!n.deletedAt||Date.now()-new Date(n.deletedAt).getTime()<30*86400000)}

function normalizeNotes(list){
  return (list||[]).map(n=>({...n,favorite:!!n.favorite,pinned:!!n.pinned,color:(typeof n.color==='number')?n.color:null}));
}

/* ---------- toast + haptics ---------- */
let toastTimer=null;
function toast(msg,type){
  let el=$('toastEl');
  if(!el){el=document.createElement('div');el.id='toastEl';el.className='toast';document.body.appendChild(el);}
  el.textContent=msg;
  el.className='toast show'+(type==='err'?' err':'');
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>{el.classList.remove('show')},2200);
}
function vibrate(ms){try{navigator.vibrate&&navigator.vibrate(ms||15)}catch{}}

function showLockScreen(title,fieldsHtml){
  $('lockTitle').textContent=title;
  $('lockFields').innerHTML=fieldsHtml+
    '<div class="lockImportRow"><button class="secondary" type="button" style="width:100%" onclick="event.preventDefault();$(\'setupImportFile\').click()">📂 '+t('importBackup')+'</button></div>'+
    '<input type="file" id="setupImportFile" accept="application/json" style="display:none">';
  $('lockError').textContent='';
  $('lockScreen').style.display='flex';
  $('setupImportFile').onchange=handleImportFile;
}
function hideLockScreen(){$('lockScreen').style.display='none'}
function setupLock(){
  showLockScreen(t('createLock'),'<input class="field" id="setup1" type="password" inputmode="numeric" autocomplete="new-password" placeholder="'+t('pinPassword')+'"><br><br><input class="field" id="setup2" type="password" inputmode="numeric" autocomplete="new-password" placeholder="'+t('confirmPin')+'"><br><br><button class="primary" id="setupBtn">'+t('createLockBtn')+'</button>');
  $('setupBtn').onclick=async()=>{const a=$('setup1').value,b=$('setup2').value;if(a.length<4){$('lockError').textContent=t('min4');return}if(a!==b){$('lockError').textContent=t('mismatch');return}await createLock(a)};
}
async function createLock(password){
  const salt=crypto.getRandomValues(new Uint8Array(16));
  secureSalt=b64(salt);
  appKey=await deriveKey(password,salt);
  localStorage.setItem(META_KEY,JSON.stringify({salt:secureSalt,version:1}));
  notes=[];
  const old=localStorage.getItem(NOTES_KEY);
  if(old){try{notes=normalizeNotes(JSON.parse(old))}catch{notes=[]}}
  localStorage.removeItem(NOTES_KEY);
  await save();
  hideLockScreen();
  vibrate();
  purgeExpired();render();
}
async function unlockApp(password){
  if(lockBusy)return;
  if(Date.now()<lockoutUntil){$('lockError').textContent=t('tooManyAttempts');return}
  lockBusy=true;$('lockError').textContent=t('unlocking');
  try{
    const meta=JSON.parse(localStorage.getItem(META_KEY)||'{}');
    secureSalt=meta.salt;
    appKey=await deriveKey(password,fromB64(secureSalt));
    const payload=await decryptData(localStorage.getItem(SECURE_KEY),appKey);
    if(!Array.isArray(payload.notes))throw new Error();
    notes=normalizeNotes(payload.notes);hideLockScreen();unlockAttempts=0;purgeExpired();render();vibrate();
  }catch{
    unlockAttempts++;
    if(unlockAttempts>=5){lockoutUntil=Date.now()+30000;unlockAttempts=0;$('lockError').textContent=t('tooManyAttempts')}
    else{$('lockError').textContent=t('incorrectLock')}
    appKey=null;
  }
  lockBusy=false;
}
function showUnlock(){
  showLockScreen(t('enterLock'),'<input class="field" id="unlock" type="password" inputmode="numeric" autocomplete="current-password" placeholder="'+t('pinPassword')+'"><br><br><button class="primary" id="unlockBtn">'+t('unlock')+'</button>');
  $('unlockBtn').onclick=()=>unlockApp($('unlock').value);
  $('unlock').addEventListener('keydown',e=>{if(e.key==='Enter')unlockApp($('unlock').value)});
  setTimeout(()=>$('unlock').focus(),50);
}
function changeAppPasswordModal(){
  showModal(
    '<div class="modalHead"><h2>'+t('appLock')+'</h2><button class="closeX" onclick="hideModal()">×</button></div>'+
    '<div class="fieldLabel">'+t('currentPassword')+'</div><input class="field" id="cpOld" type="password">'+
    '<br><br><div class="fieldLabel">'+t('newPassword')+'</div><input class="field" id="cpNew" type="password">'+
    '<br><br><div class="fieldLabel">'+t('confirmNewPassword')+'</div><input class="field" id="cpNew2" type="password">'+
    '<div class="lockError" id="cpErr"></div>'+
    '<div class="actions"><button class="secondary" onclick="hideModal()">'+t('cancel')+'</button><button class="primary" id="cpSave">'+t('change')+'</button></div>'
  );
  $('cpSave').onclick=async()=>{
    const old=$('cpOld').value,a=$('cpNew').value,b=$('cpNew2').value;
    $('cpErr').textContent='';
    try{
      const meta=JSON.parse(localStorage.getItem(META_KEY)||'{}');
      const key=await deriveKey(old,fromB64(meta.salt));
      await decryptData(localStorage.getItem(SECURE_KEY),key);
    }catch{$('cpErr').textContent=t('incorrectCurrent');return}
    if(a.length<4){$('cpErr').textContent=t('passwordMin');return}
    if(a!==b){$('cpErr').textContent=t('passwordMismatch');return}
    const salt=crypto.getRandomValues(new Uint8Array(16));
    secureSalt=b64(salt);appKey=await deriveKey(a,salt);
    localStorage.setItem(META_KEY,JSON.stringify({salt:secureSalt,version:1}));
    await save();
    hideModal();
    toast(t('passwordChanged'));
    vibrate();
  };
}
function lockApp(){if(editorOpen)closeEditor();appKey=null;notes=[];showUnlock()}
function makeId(){
  return Date.now().toString(36)+Math.random().toString(36).slice(2,10);
}
function hash(value){
  let h=2166136261;
  for(const c of value){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}
  return (h>>>0).toString(16);
}
function esc(value){
  return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function dateLabel(iso){
  const d=new Date(iso);
  const day=String(d.getDate()).padStart(2,'0');
  const month=String(d.getMonth()+1).padStart(2,'0');
  const year=d.getFullYear();
  const hour=String(d.getHours()).padStart(2,'0');
  const minute=String(d.getMinutes()).padStart(2,'0');
  return day+'/'+month+'/'+year+' • '+hour+':'+minute;
}
const I18N={
 ar:{createLock:'أنشئ قفل الخصوصية',pinPassword:'رمز أو كلمة مرور',confirmPin:'تأكيد رمز أو كلمة المرور',createLockBtn:'إنشاء القفل',min4:'استخدم 4 أحرف أو أرقام على الأقل.',mismatch:'القيمتان غير متطابقتين.',unlocking:'جارٍ فتح التطبيق…',incorrectLock:'رمز أو كلمة المرور غير صحيحة.',enterLock:'أدخل رمز الخصوصية',unlock:'فتح',day:'الوضع النهاري',night:'الوضع الليلي',trash:'المهملات',favorites:'المفضلة',themes:'المظاهر',security:'الأمان والخصوصية',backup:'النسخ الاحتياطي المحلي',language:'English',about:'عن Baraa',grid:'عرض شبكي',portrait:'عرض طولي',list:'عرض قائمة',emptyTitle:'مذكرتك فارغة',emptyText:'أنشئ أول ملاحظة خاصة بك.',createNote:'إنشاء ملاحظة',newNote:'ملاحظة جديدة',editNote:'تعديل الملاحظة',lastSaved:'آخر حفظ: ',newUnsaved:'ملاحظة جديدة غير محفوظة',noteName:'اسم الملاحظة',writeNote:'اكتب ملاحظتك هنا…',setPassword:'تعيين كلمة مرور',changeRemovePassword:'تغيير/إزالة كلمة المرور',cancel:'إلغاء',delete:'حذف',discard:'تجاهل',saveNote:'حفظ الملاحظة',lockedNote:'ملاحظة مقفلة',lockedNoteText:'هذه الملاحظة محمية بكلمة مرور.',password:'كلمة المرور',open:'فتح',incorrectPassword:'كلمة المرور غير صحيحة.',moveTrash:'نقل هذه الملاحظة إلى المهملات؟ يمكن استعادتها خلال 30 يومًا.',trashEmpty:'المهملات فارغة.',daysRemaining:'أيام متبقية',restore:'استعادة',deleteForever:'حذف نهائي',close:'إغلاق',deletedInfo:'تُحذف الملاحظات تلقائيًا بعد 30 يومًا.',securityInfo:'تشفّر Baraa ملاحظاتك قبل حفظها في مساحة التطبيق على الهاتف.',appLock:'قفل التطبيق',appLockInfo:'يتطلب رمز الخصوصية لفتح التطبيق.',change:'تغيير',lockNow:'قفل الآن',lockNowInfo:'إخفاء الملاحظات وقفل التطبيق فورًا.',lockLeaving:'القفل عند مغادرة التطبيق',lockLeavingInfo:'يقفل التطبيق عند إرساله إلى الخلفية.',localBackup:'نسخة احتياطية محلية',localBackupInfo:'لا يستخدم Baraa Google أو أي خدمة سحابية. تبقى ملاحظاتك على هذا الهاتف.',futureBackup:'يمكنك تصدير نسخة احتياطية مشفّرة كملف، والاحتفاظ به أو نقله بنفسك.',currentPassword:'أدخل رمز/كلمة المرور الحالية',newPassword:'أدخل رمز/كلمة المرور الجديدة (4 أحرف على الأقل)',confirmNewPassword:'أكد رمز/كلمة المرور الجديدة',incorrectCurrent:'رمز/كلمة المرور الحالية غير صحيحة.',passwordChanged:'تم تغيير قفل التطبيق بنجاح.',passwordMin:'استخدم 4 أحرف أو أرقام على الأقل.',passwordMismatch:'القيمتان غير متطابقتين.',
  filterAll:'الكل',filterPinned:'مثبتة',search:'بحث',searchPlaceholder:'ابحث في ملاحظاتك…',noResults:'لا توجد نتائج مطابقة',sortBy:'الترتيب',sort_newest:'الأحدث أولًا',sort_oldest:'الأقدم أولًا',sort_title:'حسب العنوان',favLabel:'مفضلة',pinLabel:'تثبيت',noteColor:'لون الملاحظة',words:'كلمة',characters:'حرف',confirmTitle:'تأكيد',confirmBtn:'تأكيد',exportBackup:'تصدير نسخة احتياطية',exportBackupInfo:'احفظ ملفًا مشفّرًا بجميع ملاحظاتك.',importBackup:'استيراد نسخة احتياطية',importBackupInfo:'استرجع ملاحظاتك من ملف نسخة احتياطية سابق.',exportSuccess:'تم إنشاء ملف النسخة الاحتياطية.',importSuccess:'تم استيراد النسخة الاحتياطية بنجاح.',importError:'ملف غير صالح أو كلمة المرور غير صحيحة.',importWarning:'سيستبدل هذا جميع ملاحظاتك الحالية بالنسخة المستوردة. هل تريد المتابعة؟',enterBackupPassword:'أدخل كلمة مرور هذه النسخة الاحتياطية',totalNotes:'الملاحظات',tooManyAttempts:'محاولات كثيرة جدًا، حاول مرة أخرى بعد 30 ثانية.',changePassword:'تغيير كلمة المرور',removePassword:'إزالة كلمة المرور',passwordRemoved:'✓ ستتم إزالة كلمة المرور عند الحفظ',passwordWillBeRemoved:'ستتم إزالة كلمة المرور عند الحفظ',savedToast:'تم الحفظ',deletedToast:'تم النقل إلى المهملات',restoredToast:'تمت الاستعادة',deletedForeverToast:'تم الحذف نهائيًا',themeChangedToast:'تم تغيير المظهر'},
 en:{createLock:'Create your private lock',pinPassword:'PIN or password',confirmPin:'Confirm PIN or password',createLockBtn:'Create lock',min4:'Use at least 4 characters.',mismatch:'The two entries do not match.',unlocking:'Unlocking…',incorrectLock:'Incorrect PIN or password.',enterLock:'Enter your private lock',unlock:'Unlock',day:'Day mode',night:'Night mode',trash:'Trash',favorites:'Favorites',themes:'Themes',security:'Security & Privacy',backup:'Local Backup',language:'العربية',about:'About Baraa',grid:'Grid view',portrait:'Portrait view',list:'List view',emptyTitle:'Your notebook is empty',emptyText:'Create your first private note.',createNote:'Create note',newNote:'New note',editNote:'Edit note',lastSaved:'Last saved: ',newUnsaved:'New unsaved note',noteName:'Note name',writeNote:'Write your note…',setPassword:'Set password',changeRemovePassword:'Change/remove password',cancel:'Cancel',delete:'Delete',discard:'Discard',saveNote:'Save note',lockedNote:'Locked note',lockedNoteText:'This note is password protected.',password:'Password',open:'Open',incorrectPassword:'Incorrect password.',moveTrash:'Move this note to Trash? It can be restored for 30 days.',trashEmpty:'Trash is empty.',daysRemaining:'days remaining',restore:'Restore',deleteForever:'Delete',close:'Close',deletedInfo:'Deleted notes are automatically removed after 30 days.',securityInfo:'Baraa encrypts your notes before saving them in the app storage on this phone.',appLock:'App lock',appLockInfo:'PIN/password required to open the app.',change:'Change',lockNow:'Lock now',lockNowInfo:'Immediately hide and lock all notes.',lockLeaving:'Lock when leaving app',lockLeavingInfo:'Locks when the app is sent to the background.',localBackup:'Local Backup',localBackupInfo:'Baraa does not use Google or any cloud service. Your notes stay on this phone.',futureBackup:'You can export an encrypted backup file and keep or move it yourself.',currentPassword:'Enter your current PIN/password',newPassword:'Enter the new PIN/password (at least 4 characters)',confirmNewPassword:'Confirm the new PIN/password',incorrectCurrent:'Incorrect current PIN/password.',passwordChanged:'Your app lock was changed successfully.',passwordMin:'Use at least 4 characters.',passwordMismatch:'The two entries do not match.',
  filterAll:'All',filterPinned:'Pinned',search:'Search',searchPlaceholder:'Search your notes…',noResults:'No matching results',sortBy:'Sort',sort_newest:'Newest first',sort_oldest:'Oldest first',sort_title:'By title',favLabel:'Favorite',pinLabel:'Pin',noteColor:'Note color',words:'words',characters:'characters',confirmTitle:'Confirm',confirmBtn:'Confirm',exportBackup:'Export backup',exportBackupInfo:'Save an encrypted file with all your notes.',importBackup:'Import backup',importBackupInfo:'Restore your notes from a previous backup file.',exportSuccess:'Backup file created.',importSuccess:'Backup imported successfully.',importError:'Invalid file or incorrect password.',importWarning:'This will replace all your current notes with the imported backup. Continue?',enterBackupPassword:"Enter this backup's password",totalNotes:'Notes',tooManyAttempts:'Too many attempts. Try again in 30 seconds.',changePassword:'Change password',removePassword:'Remove password',passwordRemoved:'✓ Password will be removed when you save',passwordWillBeRemoved:'Password will be removed when you save',savedToast:'Saved',deletedToast:'Moved to trash',restoredToast:'Restored',deletedForeverToast:'Deleted permanently',themeChangedToast:'Theme updated'}
};
function t(k){return (I18N[settings.lang]||I18N.ar)[k]||k}
function setLanguage(lang){settings.lang=lang;saveSettings();applyLanguage();applySettings();render()}
function applyLanguage(){
  document.documentElement.lang=settings.lang;
  document.documentElement.dir=settings.lang==='ar'?'rtl':'ltr';
  const name=settings.lang==='ar'?'براءة':'Baraa';
  $('brandName').textContent=name; $('drawerBrand').textContent=name; $('lockBrand').textContent=name; $('splashBrand').textContent=name;
  $('trashText').textContent=t('trash'); $('favoritesText').textContent=t('favorites'); $('themesText').textContent=t('themes'); $('securityText').textContent=t('security'); $('backupText').textContent=t('backup'); $('languageText').textContent=t('language'); $('aboutText').textContent=t('about');
  $('chipAll').textContent=t('filterAll');
  $('chipFav').textContent='★ '+t('favorites');
  $('chipPin').textContent='📌 '+t('filterPinned');
  $('searchInput').placeholder=t('searchPlaceholder');
  updateSortIcon();
}
function applySettings(){
  document.body.classList.toggle('dark',settings.dark);
  const tTheme=themes[settings.theme]||themes[0];
  document.documentElement.style.setProperty('--a',tTheme[0]);
  document.documentElement.style.setProperty('--p',tTheme[1]);
  document.documentElement.style.setProperty('--p2',tTheme[2]);
  $('mi').textContent=settings.dark?'☾':'☀';
  $('mt').textContent=settings.dark?t('night'):t('day');
  $('ms').classList.toggle('on',settings.dark);
  $('lt').textContent=settings.layout==='grid'?t('grid'):settings.layout==='portrait'?t('portrait'):t('list');
  $('li').textContent=settings.layout==='grid'?'▦':settings.layout==='portrait'?'▤':'☷';
  applyLanguage();
}

/* ---------- filter / sort ---------- */
function setFilter(mode){
  favoritesOnly=mode==='fav';
  pinnedOnly=mode==='pin';
  syncChips();render();
}
function syncChips(){
  const mode=pinnedOnly?'pin':favoritesOnly?'fav':'all';
  document.querySelectorAll('#chips .chip').forEach(c=>c.classList.toggle('active',c.dataset.f===mode));
}
function updateSortIcon(){$('sortToggle').title=t('sortBy')+': '+t('sort_'+sortMode)}
function cycleSort(){
  const i=SORT_MODES.indexOf(sortMode);
  sortMode=SORT_MODES[(i+1)%SORT_MODES.length];
  updateSortIcon();render();
  toast(t('sort_'+sortMode));
}
function toggleSearch(){
  const bar=$('searchBar');
  const showing=bar.style.display==='flex';
  if(showing){bar.style.display='none';searchQuery='';$('searchInput').value='';render()}
  else{bar.style.display='flex';setTimeout(()=>$('searchInput').focus(),50)}
}

let favoritesOnlyPrev=false;
function activeNotes(){
  purgeExpired();
  let list=notes.filter(n=>!n.deletedAt);
  if(favoritesOnly)list=list.filter(n=>n.favorite);
  if(pinnedOnly)list=list.filter(n=>n.pinned);
  if(searchQuery.trim()){
    const q=searchQuery.trim().toLowerCase();
    list=list.filter(n=>(n.title||'').toLowerCase().includes(q)||(n.content||'').toLowerCase().includes(q));
  }
  list.sort((a,b)=>{
    if(sortMode==='title')return (a.title||'').localeCompare(b.title||'',undefined,{sensitivity:'base'});
    const diff=new Date(b.updatedAt)-new Date(a.updatedAt);
    return sortMode==='oldest'?-diff:diff;
  });
  list.sort((a,b)=>(b.pinned?1:0)-(a.pinned?1:0));
  return list;
}
function updateDrawerStats(){
  const active=notes.filter(n=>!n.deletedAt);
  const favs=active.filter(n=>n.favorite).length;
  const pins=active.filter(n=>n.pinned).length;
  const trashCount=notes.filter(n=>n.deletedAt).length;
  $('drawerStats').innerHTML=
    '<div class="statsRow"><b>'+active.length+'</b><span>'+t('totalNotes')+'</span></div>'+
    '<div class="statsRow"><b>'+favs+'</b><span>'+t('favorites')+'</span></div>'+
    '<div class="statsRow"><b>'+pins+'</b><span>'+t('filterPinned')+'</span></div>'+
    '<div class="statsRow"><b>'+trashCount+'</b><span>'+t('trash')+'</span></div>';
}
function render(){
  purgeExpired();
  const list=activeNotes();
  const c=$('content');
  c.className='content '+(settings.layout==='portrait'?'portrait':'');
  syncChips();
  updateDrawerStats();
  if(!list.length){
    const msg=searchQuery.trim()?t('noResults'):t('emptyText');
    const title=searchQuery.trim()?t('search'):t('emptyTitle');
    c.innerHTML='<div class="empty"><img src="assets/baraa_logo.png" alt="Baraa"><h2>'+esc(title)+'</h2><p>'+esc(msg)+'</p>'+(searchQuery.trim()?'':'<button class="primary" onclick="openEditor()">＋ '+t('createNote')+'</button>')+'</div>';
    return;
  }
  const cls=settings.layout==='list'?'list':'grid';
  c.innerHTML='<div class="'+cls+'">'+list.map(n=>{
    const borderStyle=(typeof n.color==='number')?('border-inline-start:6px solid '+NOTE_COLORS[n.color]+';'):'';
    const titleText=(n.pinned?'<span class="pinTag">📌</span>':'')+esc(n.title||t('newNote'));
    return '<article class="note" style="'+borderStyle+'" onclick="openNote(\''+n.id+'\')">'+
    (n.passwordHash?'<span class="lock">🔒</span>':'')+
    '<button class="star" onclick="event.stopPropagation();toggleFavorite(\''+n.id+'\')" aria-label="Favorite">'+(n.favorite?'★':'☆')+'</button>'+
    '<div class="title">'+titleText+'</div>'+    '<div class="body">'+esc(n.content||'…')+'</div>'+    '<div class="date">'+dateLabel(n.updatedAt)+'</div>'+    '</article>';
  }).join('')+'</div>';
}
function showModal(html){
  $('modal').innerHTML=html;
  $('mb').classList.add('show');
}
function hideModal(){
  const mb=$('mb');
  mb.classList.remove('show');
  mb.style.zIndex='';
  setTimeout(()=>{if(!mb.classList.contains('show'))$('modal').innerHTML=''},220);
}
function customConfirm(message,confirmLabel,danger){
  return new Promise(resolve=>{
    showModal('<div class="modalHead"><h2>'+t('confirmTitle')+'</h2><button class="closeX" id="ccX">×</button></div>'+
      '<p>'+esc(message)+'</p>'+
      '<div class="actions"><button class="secondary" id="ccCancel">'+t('cancel')+'</button>'+
      '<button class="'+(danger===false?'primary':'danger')+'" id="ccOk">'+esc(confirmLabel||t('confirmBtn'))+'</button></div>');
    const finish=(val)=>{hideModal();resolve(val)};
    $('ccX').onclick=()=>finish(false);
    $('ccCancel').onclick=()=>finish(false);
    $('ccOk').onclick=()=>finish(true);
  });
}
function openEditor(note=null){
  closeDrawer();
  editorOpen=true; editorHistory=true;
  editorFavorite=note?.favorite||false;
  editorPinned=note?.pinned||false;
  editorColor=(note&&typeof note.color==='number')?note.color:null;
  history.pushState({dafaallahEditor:true},'',location.pathname+location.search+'#editor');
  showModal(
    '<div class="modalHead"><h2>'+(note?t('editNote'):t('newNote'))+'</h2><button class="closeX" onclick="closeEditor()" aria-label="Close note">×</button></div>'+    '<div class="meta">'+(note?t('lastSaved')+dateLabel(note.updatedAt):t('newUnsaved'))+'</div>'+    '<input class="field" id="ti" placeholder="'+t('noteName')+'" value="'+esc(note?.title||'')+'">'+    '<br><br><textarea class="field area" id="bi" placeholder="'+t('writeNote')+'">'+esc(note?.content||'')+'</textarea>'+    '<div class="small counter" id="counter"></div>'+    '<br><div id="passControls"></div><div class="small" id="pwNotice"></div>'+    '<button class="secondary" id="favBtn" type="button"></button>'+    '<button class="secondary" id="pinBtn" type="button"></button>'+    '<div class="fieldLabel" style="margin-top:12px">'+t('noteColor')+'</div>'+    '<div class="colorRow" id="colorRow"></div>'+    '<div id="pa"></div>'+    '<div class="actions"><button type="button" class="secondary" id="cancelNoteBtn">'+t('cancel')+'</button>'+    (note?'<button type="button" class="danger" id="deleteNoteBtn">'+t('delete')+'</button>':'<button type="button" class="danger" id="discardNoteBtn">'+t('discard')+'</button>')+    '<button type="button" class="primary" id="saveNoteBtn">'+t('saveNote')+'</button></div>'
  );
  editorRemovePassword=false;
  updateFavBtn();updatePinBtn();renderColorRow();updateCounter();renderPasswordControls(note);
  $('favBtn').onclick=()=>{editorFavorite=!editorFavorite;updateFavBtn();vibrate(8)};
  $('pinBtn').onclick=()=>{editorPinned=!editorPinned;updatePinBtn();vibrate(8)};
  $('bi').addEventListener('input',updateCounter);
  $('cancelNoteBtn').onclick=()=>closeEditor();
  if(note){ $('deleteNoteBtn').onclick=()=>deleteFromEditor(note.id); } else { $('discardNoteBtn').onclick=()=>discardNewNote(); }
  $('saveNoteBtn').onclick=()=>saveNote(note?.id||'');
  setTimeout(()=>$('ti')?.focus(),50);
}
function updateFavBtn(){$('favBtn').textContent=(editorFavorite?'★ ':'☆ ')+t('favLabel')}
function updatePinBtn(){$('pinBtn').textContent=(editorPinned?'📌 ':'📍 ')+t('pinLabel')}
function renderColorRow(){
  $('colorRow').innerHTML=NOTE_COLORS.map((c,i)=>'<button type="button" class="colorDot '+(editorColor===i?'sel':'')+'" style="background:'+c+'" onclick="setEditorColor('+i+')" aria-label="color'+i+'"></button>').join('')+
    '<button type="button" class="colorDot none '+(editorColor===null?'sel':'')+'" onclick="setEditorColor(null)">✕</button>';
}
function setEditorColor(i){editorColor=i;renderColorRow()}
function updateCounter(){
  const val=$('bi').value;
  const chars=val.length;
  const words=(val.trim().match(/\S+/g)||[]).length;
  $('counter').textContent=words+' '+t('words')+' · '+chars+' '+t('characters');
}
function closeEditor(){
  if(!editorOpen){hideModal();return}
  const wasHistory=editorHistory && location.hash==='#editor';
  editorOpen=false;
  editorHistory=false;
  hideModal();
  if(wasHistory) history.back();
}
function discardNewNote(){closeEditor()}
async function deleteFromEditor(id){
  const n=notes.find(x=>x.id===id);
  if(!n)return;
  const ok=await customConfirm(t('moveTrash'),t('delete'));
  if(!ok){openEditor(n);return}
  const oldDeleted=n.deletedAt;
  n.deletedAt=new Date().toISOString();
  n.updatedAt=new Date().toISOString();
  try{
    await save();
    editorOpen=false; editorHistory=false; hideModal();
    if(location.hash==='#editor') history.replaceState(null,'',location.pathname+location.search);
    render();
    toast(t('deletedToast'));vibrate();
  }catch(e){
    n.deletedAt=oldDeleted;
    toast(settings.lang==='ar'?'تعذر حذف الملاحظة وحفظ التغيير.':'The note could not be deleted and saved.','err');
  }
}
function renderPasswordControls(note){
  const has=!!(note&&note.passwordHash)&&!editorRemovePassword;
  $('passControls').innerHTML = has
    ? '🔒 <button type="button" class="secondary" id="setPassBtn">'+t('changePassword')+'</button> <button type="button" class="secondary" id="removePassBtn">'+t('removePassword')+'</button>'
    : '<button type="button" class="secondary" id="setPassBtn">🔒 '+t('setPassword')+'</button>';
  $('setPassBtn').onclick=()=>toggleSetPasswordArea();
  if(has) $('removePassBtn').onclick=()=>removeNotePassword(note);
  $('pwNotice').textContent = editorRemovePassword ? t('passwordRemoved') : '';
}
function toggleSetPasswordArea(){
  editorRemovePassword=false; $('pwNotice').textContent='';
  const a=$('pa'); if(a.innerHTML){a.innerHTML='';return}
  a.innerHTML='<br><input class="field" id="p1" type="password" placeholder="'+t('password')+'">'+
    '<br><br><input class="field" id="p2" type="password" placeholder="'+t('confirmPin')+'">';
}
function removeNotePassword(note){
  editorRemovePassword=true;
  $('pa').innerHTML='';
  renderPasswordControls(note);
  toast(t('passwordWillBeRemoved'));vibrate(8);
}
async function saveNote(id){
  const saveBtn=$('saveNoteBtn');
  if(saveBtn){saveBtn.disabled=true;saveBtn.textContent=settings.lang==='ar'?'جارٍ الحفظ…':'Saving…';}
  const title=$('ti').value.trim()||t('newNote'); const content=$('bi').value;
  let n=id?notes.find(x=>x.id===id):null;
  let created=false;
  if(!n){n={id:makeId(),title:'',content:'',createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),deletedAt:null,passwordHash:null,favorite:false,pinned:false,color:null};notes.push(n);created=true}
  const previous={title:n.title,content:n.content,updatedAt:n.updatedAt,passwordHash:n.passwordHash,favorite:n.favorite,pinned:n.pinned,color:n.color};
  n.title=title;n.content=content;n.updatedAt=new Date().toISOString();
  n.favorite=editorFavorite;n.pinned=editorPinned;n.color=editorColor;
  if($('p1')){if($('p1').value!==$('p2').value){toast(t('passwordMismatch'),'err');if(created)notes=notes.filter(x=>x.id!==n.id);else Object.assign(n,previous);if(saveBtn){saveBtn.disabled=false;saveBtn.textContent=t('saveNote')}return}n.passwordHash=$('p1').value?hash($('p1').value):null}
  else if(editorRemovePassword){n.passwordHash=null}
  try{
    await save();
    editorOpen=false; editorHistory=false; hideModal();
    if(location.hash==='#editor') history.replaceState(null,'',location.pathname+location.search);
    render();
    toast(t('savedToast'));vibrate();
  }catch(e){
    if(created)notes=notes.filter(x=>x.id!==n.id);else Object.assign(n,previous);
    toast(settings.lang==='ar'?'تعذر حفظ الملاحظة. تحقق من أن التطبيق مفتوح ثم حاول مرة أخرى.':'The note could not be saved. Make sure the app is unlocked and try again.','err');
    if(saveBtn){saveBtn.disabled=false;saveBtn.textContent=t('saveNote')}
  }
}
function openNote(id){
  const n=notes.find(x=>x.id===id); if(!n)return;
  if(!n.passwordHash){openEditor(n);return}
  showModal('<div class="modalHead"><h2>🔒 '+t('lockedNote')+'</h2><button class="closeX" onclick="hideModal()">×</button></div>'+    '<p>'+t('lockedNoteText')+'</p>'+    '<input class="field" id="un" type="password" placeholder="'+t('password')+'">'+    '<div class="actions"><button class="secondary" onclick="hideModal()">'+t('cancel')+'</button><button class="primary" onclick="unlockNote(\''+id+'\')">'+t('open')+'</button></div>');
}
function unlockNote(id){const n=notes.find(x=>x.id===id);if(hash($('un').value)!==n.passwordHash){toast(t('incorrectPassword'),'err');return}hideModal();openEditor(n)}
function toggleFavorite(id){const n=notes.find(x=>x.id===id);if(!n)return;n.favorite=!n.favorite;vibrate(8);save().then(render)}
function trash(){
  closeDrawer(); const list=notes.filter(n=>n.deletedAt);
  showModal('<div class="modalHead"><h2>'+t('trash')+'</h2><button class="closeX" onclick="hideModal()">×</button></div>'+    '<p class="small">'+t('deletedInfo')+'</p>'+    (list.length?list.map(n=>{const left=Math.max(0,30-Math.floor((Date.now()-new Date(n.deletedAt).getTime())/86400000));return '<div class="row"><div class="grow"><b>'+esc(n.title)+'</b><div class="small">'+left+' '+t('daysRemaining')+'</div></div><button class="secondary" onclick="restoreNote(\''+n.id+'\')">'+t('restore')+'</button><button class="danger" onclick="deleteForever(\''+n.id+'\')">'+t('deleteForever')+'</button></div>'}).join(''):'<p>'+t('trashEmpty')+'</p>')+    '<div class="actions"><button class="primary" onclick="hideModal()">'+t('close')+'</button></div>');
}
function restoreNote(id){
  const n=notes.find(x=>x.id===id);
  if(n){n.deletedAt=null;n.updatedAt=new Date().toISOString();save()}
  render();trash();toast(t('restoredToast'));vibrate();
}
async function deleteForever(id){
  const n=notes.find(x=>x.id===id);
  const ok=await customConfirm(t('deletedInfo')+' '+t('deleteForever')+'?',t('deleteForever'));
  if(!ok){trash();return}
  notes=notes.filter(x=>x.id!==id);
  save();render();
  toast(t('deletedForeverToast'));vibrate();
  trash();
}
function showThemes(){
  closeDrawer();
  const mb=$('mb');
  if(mb && $('galleryScreen')?.classList.contains('show')) mb.style.zIndex='500';
  showModal('<div class="modalHead"><h2>'+t('themes')+'</h2><button class="closeX" onclick="hideModal()">×</button></div><div class="themes">'+themes.map((th,i)=>'<button class="swatch '+(settings.theme===i?'sel':'')+'" style="background:'+th[0]+'" onclick="setTheme('+i+')"></button>').join('')+'</div>');
}
function setTheme(i){settings.theme=i;saveSettings();applySettings();hideModal();toast(t('themeChangedToast'));vibrate()}
function security(){
  closeDrawer();
  showModal('<div class="modalHead"><h2>'+t('security')+'</h2><button class="closeX" onclick="hideModal()">×</button></div>'+    '<p>'+t('securityInfo')+'</p>'+    '<div class="row"><div class="grow"><b>'+t('appLock')+'</b><div class="small">'+t('appLockInfo')+'</div></div><button class="secondary" onclick="changeAppPasswordModal()">'+t('change')+'</button></div>'+    '<div class="row"><div class="grow"><b>'+t('lockNow')+'</b><div class="small">'+t('lockNowInfo')+'</div></div><button class="secondary" onclick="hideModal();lockApp()">🔒 '+t('lockNow')+'</button></div>'+    '<div class="row"><div class="grow"><b>'+t('lockLeaving')+'</b><div class="small">'+t('lockLeavingInfo')+'</div></div><span class="sw '+(settings.autoLock?'on':'')+'" id="autoSw"><i></i></span></div>'+    '<div class="actions"><button class="primary" onclick="hideModal()">'+t('close')+'</button></div>');
  $('autoSw').onclick=()=>{settings.autoLock=!settings.autoLock;saveSettings();security()};
}
function backup(){
  closeDrawer();
  showModal('<div class="modalHead"><h2>'+t('backup')+'</h2><button class="closeX" onclick="hideModal()">×</button></div>'+
    '<p>'+t('localBackupInfo')+'</p><p class="small">'+t('futureBackup')+'</p>'+
    '<div class="row"><div class="grow"><b>'+t('exportBackup')+'</b><div class="small">'+t('exportBackupInfo')+'</div></div><button class="secondary" onclick="exportBackup()">⬇</button></div>'+
    '<div class="row"><div class="grow"><b>'+t('importBackup')+'</b><div class="small">'+t('importBackupInfo')+'</div></div><button class="secondary" onclick="$(\'importFile\').click()">⬆</button></div>'+
    '<input type="file" id="importFile" accept="application/json" style="display:none">'+
    '<div class="actions"><button class="primary" onclick="hideModal()">'+t('close')+'</button></div>');
  $('importFile').onchange=handleImportFile;
}
function exportBackup(){
  try{
    const meta=localStorage.getItem(META_KEY);
    const blob=localStorage.getItem(SECURE_KEY);
    if(!meta||!blob){toast(t('importError'),'err');return}
    const payload=JSON.stringify({app:'baraa',version:1,exportedAt:new Date().toISOString(),meta:JSON.parse(meta),blob:JSON.parse(blob)});
    const file=new Blob([payload],{type:'application/json'});
    const url=URL.createObjectURL(file);
    const a=document.createElement('a');
    a.href=url; a.download='baraa-backup-'+new Date().toISOString().slice(0,10)+'.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),4000);
    toast(t('exportSuccess'));vibrate();
  }catch(e){toast(t('importError'),'err')}
}
async function handleImportFile(e){
  const file=e.target.files[0]; if(!file)return;
  let parsed;
  try{
    const text=await file.text();
    parsed=JSON.parse(text);
    if(!parsed.meta||!parsed.blob)throw new Error();
  }catch{toast(t('importError'),'err');return}
  showImportPasswordModal(parsed,'');
}
function showImportPasswordModal(parsed,errMsg){
  showModal(
    '<div class="modalHead"><h2>'+t('importBackup')+'</h2><button class="closeX" onclick="hideModal()">×</button></div>'+
    '<p>'+t('enterBackupPassword')+'</p>'+
    '<input class="field" id="impPass" type="password">'+
    '<div class="lockError" id="impErr">'+esc(errMsg||'')+'</div>'+
    '<div class="actions"><button class="secondary" onclick="hideModal()">'+t('cancel')+'</button><button class="primary" id="impGo">'+t('open')+'</button></div>'
  );
  setTimeout(()=>$('impPass')?.focus(),50);
  $('impGo').onclick=async()=>{
    const pw=$('impPass').value;
    try{
      const key=await deriveKey(pw,fromB64(parsed.meta.salt));
      const payload=await decryptData(JSON.stringify(parsed.blob),key);
      if(!Array.isArray(payload.notes))throw new Error();
      const ok=await customConfirm(t('importWarning'),t('confirmBtn'));
      if(!ok){showImportPasswordModal(parsed,'');return}
      localStorage.setItem(META_KEY,JSON.stringify(parsed.meta));
      localStorage.setItem(SECURE_KEY,JSON.stringify(parsed.blob));
      appKey=key;
      notes=normalizeNotes(payload.notes);
      hideModal();
      hideLockScreen();
      purgeExpired();render();
      toast(t('importSuccess'));vibrate();
    }catch{
      showImportPasswordModal(parsed,t('importError'));
    }
  };
}
let galleryItems=[];
const GALLERY_KEY='baraa_gallery_v1';
let gallerySort='newest',galleryFavOnly=false,galleryView='all',galleryIntroTimer=null;
let galleryTheme=0;
let galleryDark=false;
function applyGalleryTheme(){
  const screen=$('galleryScreen'); if(!screen)return;
  const th=themes[galleryTheme]||themes[0];
  screen.style.setProperty('--a',th[0]);
  screen.style.setProperty('--p',galleryDark?'#121212':th[1]);
  screen.style.setProperty('--p2',galleryDark?'#242424':th[2]);
  screen.style.setProperty('--bar',galleryDark?'#1b1b1b':'#fff');
  screen.style.setProperty('--t',galleryDark?'#f3f3f3':'#222');
  screen.style.setProperty('--m',galleryDark?'#bdbdbd':'#6b6b6b');
}
function showGalleryThemes(){
  const overlay=$('galleryThemePanel'); if(!overlay)return;
  overlay.innerHTML='<div class="galleryThemeBox"><div class="galleryThemeHead"><b>'+t('themes')+'</b><button id="galleryThemeClose">×</button></div><div class="themes">'+themes.map((th,i)=>'<button class="swatch '+(galleryTheme===i?'sel':'')+'" style="background:'+th[0]+'" data-gtheme="'+i+'"></button>').join('')+'</div></div>';
  overlay.classList.add('show');
  overlay.setAttribute('aria-hidden','false');
  $('galleryThemeClose').onclick=()=>{overlay.classList.remove('show');overlay.setAttribute('aria-hidden','true')};
  overlay.querySelectorAll('[data-gtheme]').forEach(b=>b.onclick=()=>{galleryTheme=Number(b.dataset.gtheme);applyGalleryTheme();overlay.classList.remove('show');overlay.setAttribute('aria-hidden','true');renderGallery();vibrate()});
}

function purgeGalleryExpired(){
  const cutoff=Date.now()-30*24*60*60*1000;
  const before=galleryItems.length;
  galleryItems=galleryItems.filter(x=>!x.deletedAt||x.deletedAt>cutoff);
  if(galleryItems.length!==before)saveGallery();
}
function normalizeGalleryItems(){
  galleryItems=galleryItems.map(x=>({
    id:x.id||makeId(),data:x.data,createdAt:x.createdAt||Date.now(),
    addedAt:x.addedAt||x.createdAt||Date.now(),artDate:x.artDate||x.createdAt||Date.now(),
    deletedAt:x.deletedAt||null,favorite:!!x.favorite,name:x.name||'Artwork'
  }));
}
function loadGallery(){
  try{galleryItems=JSON.parse(localStorage.getItem(GALLERY_KEY)||'[]');if(!Array.isArray(galleryItems))galleryItems=[]}catch{galleryItems=[]}
  normalizeGalleryItems();
  const now=Date.now();
  if(!galleryItems.length){
    galleryItems=[
      {id:'art_seed_1',data:'assets/gallery/artwork_1.jpg',createdAt:now-16000,addedAt:now-16000,artDate:now-16000,deletedAt:null,favorite:false,name:'Artwork 1'},
      {id:'art_seed_2',data:'assets/gallery/artwork_2.jpg',createdAt:now-15000,addedAt:now-15000,artDate:now-15000,deletedAt:null,favorite:false,name:'Artwork 2'},
      {id:'art_seed_3',data:'assets/gallery/artwork_3.jpg',createdAt:now-14000,addedAt:now-14000,artDate:now-14000,deletedAt:null,favorite:false,name:'Artwork 3'},
      {id:'art_seed_4',data:'assets/gallery/artwork_4.jpg',createdAt:now-13000,addedAt:now-13000,artDate:now-13000,deletedAt:null,favorite:false,name:'Artwork 4'},
      {id:'art_seed_5',data:'assets/gallery/artwork_5.jpg',createdAt:now-12000,addedAt:now-12000,artDate:now-12000,deletedAt:null,favorite:false,name:'Artwork 5'},
      {id:'art_seed_6',data:'assets/gallery/artwork_6.jpg',createdAt:now-11000,addedAt:now-11000,artDate:now-11000,deletedAt:null,favorite:false,name:'Artwork 6'},
      {id:'art_seed_7',data:'assets/gallery/artwork_7.jpg',createdAt:now-10000,addedAt:now-10000,artDate:now-10000,deletedAt:null,favorite:false,name:'Artwork 7'},
      {id:'art_seed_8',data:'assets/gallery/artwork_8.jpg',createdAt:now-9000,addedAt:now-9000,artDate:now-9000,deletedAt:null,favorite:false,name:'Artwork 8'}
    ];
  }
  // Reconcile bundled artworks on every load. This also repairs older installs
  // where the gallery list was saved before the newer bundled artworks existed.
  const bundledSeeds=[
    ['art_seed_1','assets/gallery/artwork_1.jpg','Artwork 1'],
    ['art_seed_2','assets/gallery/artwork_2.jpg','Artwork 2'],
    ['art_seed_3','assets/gallery/artwork_3.jpg','Artwork 3'],
    ['art_seed_4','assets/gallery/artwork_4.jpg','Artwork 4'],
    ['art_seed_5','assets/gallery/artwork_5.jpg','Artwork 5'],
    ['art_seed_6','assets/gallery/artwork_6.jpg','Artwork 6'],
    ['art_seed_7','assets/gallery/artwork_7.jpg','Artwork 7'],
    ['art_seed_8','assets/gallery/artwork_8.jpg','Artwork 8'],
    ['art_seed_9','assets/gallery/artwork_9.jpg','Artwork 9'],
    ['art_seed_10','assets/gallery/artwork_10.jpg','Artwork 10'],
    ['art_seed_11','assets/gallery/artwork_11.jpg','Artwork 11'],
    ['art_seed_12','assets/gallery/artwork_12.jpg','Artwork 12'],
    ['art_seed_13','assets/gallery/artwork_13.jpg','Artwork 13'],
    ['art_seed_14','assets/gallery/artwork_14.jpg','Artwork 14'],
    ['art_seed_15','assets/gallery/artwork_15.jpg','Artwork 15'],
    ['art_seed_16','assets/gallery/artwork_16.jpg','Artwork 16'],
    ['art_seed_17','assets/gallery/artwork_17.jpg','Artwork 17']
  ];
  bundledSeeds.forEach(([id,data,name],i)=>{
    if(!galleryItems.some(x=>x.id===id)){
      const ts=now-16000+(i*1000);
      galleryItems.push({id,data,createdAt:ts,addedAt:ts,artDate:ts,deletedAt:null,favorite:false,name});
    }
  });
  localStorage.setItem(GALLERY_KEY+'_seed_v2','1');
  saveGallery();
  purgeGalleryExpired();
}
function saveGallery(){localStorage.setItem(GALLERY_KEY,JSON.stringify(galleryItems))}
function galleryDate(ts,withTime=false){
  const d=new Date(ts);return d.toLocaleString(settings.lang==='ar'?'ar':'en',{year:'numeric',month:'short',day:'numeric',...(withTime?{hour:'2-digit',minute:'2-digit'}:{})});
}
function toLocalDateTime(ts){
  const d=new Date(ts||Date.now()),pad=n=>String(n).padStart(2,'0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fromLocalDateTime(v){const n=new Date(v).getTime();return Number.isFinite(n)?n:Date.now()}
function showGallery(){
  const screen=$('galleryScreen');if(!screen)return;
  const intro=$('galleryIntro');
  if(galleryIntroTimer){clearTimeout(galleryIntroTimer);galleryIntroTimer=null}
  closeDrawer();
  screen.classList.add('show');screen.setAttribute('aria-hidden','false');
  galleryView='all';galleryFavOnly=false;
  galleryTheme=settings.theme||0; galleryDark=!!settings.dark;
  applyGalleryTheme();
  // CSS handles the two-second intro independently of JavaScript timing.
  if(intro){
    intro.classList.remove('active');
    void intro.offsetWidth;
    intro.classList.add('active');
    intro.setAttribute('aria-hidden','false');
    galleryIntroTimer=setTimeout(()=>{
      intro.classList.remove('active');
      intro.setAttribute('aria-hidden','true');
      galleryIntroTimer=null;
    },2400);
  }
  try{loadGallery();renderGallery()}catch(err){
    console.error('Gallery render error',err);
    const page=$('galleryPage');
    if(page)page.innerHTML='<div class="galleryEmpty">'+(settings.lang==='ar'?'تعذر عرض الأعمال مؤقتًا. يمكنك العودة ثم فتح المعرض مرة أخرى.':'The gallery could not be rendered. Please go back and open it again.')+'</div>';
  }
}
function hideGallery(){
  if(galleryIntroTimer){clearTimeout(galleryIntroTimer);galleryIntroTimer=null}
  const intro=$('galleryIntro');
  if(intro){intro.classList.remove('active');intro.setAttribute('aria-hidden','true')}
  const screen=$('galleryScreen');if(!screen)return;
  screen.classList.remove('show');screen.setAttribute('aria-hidden','true');
  const viewer=$('galleryViewer');if(viewer)viewer.classList.remove('show');
}
function renderGallery(){
  const el=$('galleryPage'),tools=$('galleryControls');if(!el||!tools)return;
  purgeGalleryExpired();
  let list=galleryItems.slice();
  if(galleryView==='trash')list=list.filter(x=>x.deletedAt);
  else {list=list.filter(x=>!x.deletedAt);if(galleryFavOnly)list=list.filter(x=>x.favorite)}
  list.sort((a,b)=>gallerySort==='oldest'?a.artDate-b.artDate:b.artDate-a.artDate);
  tools.innerHTML=
    '<label class="secondary galleryAction" for="galleryFile">＋ '+(settings.lang==='ar'?'إضافة عمل':'Add artwork')+'</label>'+ 
    '<button class="secondary" id="galleryFavFilter">★ '+(galleryFavOnly?(settings.lang==='ar'?'كل الأعمال':'All works'):(settings.lang==='ar'?'المفضلة':'Favorites'))+'</button>'+ 
    '<button class="secondary" id="gallerySort">↕ '+(gallerySort==='newest'?(settings.lang==='ar'?'الأحدث':'Newest'):(settings.lang==='ar'?'الأقدم':'Oldest'))+'</button>'+ 
    '<button class="secondary" id="galleryTrash">♲ '+(galleryView==='trash'?(settings.lang==='ar'?'المعرض':'Gallery'):(settings.lang==='ar'?'سلة المهملات':'Trash'))+'</button>'+ 
    '<button class="secondary" id="galleryMode">'+(settings.dark?'☀':'☾')+' '+(settings.dark?t('night'):t('day'))+'</button>'+ 
    '<button class="secondary" id="galleryThemes">🎨 '+t('themes')+'</button>';
  el.innerHTML=(galleryView==='trash'?
    '<div class="gallerySectionTitle">♲ '+(settings.lang==='ar'?'سلة المهملات — الاستعادة متاحة لمدة 30 يومًا':'Trash — restore is available for 30 days')+'</div>':'')+
    (list.length?'<div class="galleryGrid">'+list.map(x=>galleryCard(x)).join('')+'</div>':'<div class="galleryEmpty">'+(galleryView==='trash'?(settings.lang==='ar'?'سلة المهملات فارغة.':'Trash is empty.'):(settings.lang==='ar'?'لم تتم إضافة أعمال فنية بعد. يمكنك رفعها من هاتفك.':'No artworks yet. Add images from your phone.'))+'</div>');
  const fi=$('galleryFile');if(fi)fi.onchange=handleGalleryFiles;
  $('galleryFavFilter').onclick=()=>{if(galleryView==='trash')galleryView='all';galleryFavOnly=!galleryFavOnly;renderGallery()};
  $('gallerySort').onclick=()=>{gallerySort=gallerySort==='newest'?'oldest':'newest';renderGallery()};
  $('galleryTrash').onclick=()=>{galleryView=galleryView==='trash'?'all':'trash';galleryFavOnly=false;renderGallery()};
  $('galleryMode').onclick=()=>{galleryDark=!galleryDark;applyGalleryTheme();renderGallery()};
  $('galleryThemes').onclick=showGalleryThemes;
  el.onclick=(ev)=>{
    const btn=ev.target.closest('.artImageBtn');
    if(btn){ev.preventDefault();ev.stopPropagation();openGalleryImage(btn.dataset.id)}
  };
}
function galleryCard(x){
  if(x.deletedAt){
    return '<article class="artCard trashCard"><button class="artImageBtn" data-id="'+x.id+'"><img src="'+x.data+'" alt="Artwork"></button><div class="artMeta"><span>'+galleryDate(x.artDate)+'</span><div class="artBtns"><button class="artAction" title="Restore" onclick="event.stopPropagation();restoreGalleryItem(\''+x.id+'\')">↩</button><button class="artAction danger" title="Delete forever" onclick="event.stopPropagation();deleteGalleryForever(\''+x.id+'\')">🗑</button></div></div><div class="trashNote">'+(settings.lang==='ar'?'محذوف منذ':'Deleted')+' '+galleryDate(x.deletedAt)+'</div></article>';
  }
  return '<article class="artCard"><button class="artImageBtn" data-id="'+x.id+'"><img src="'+x.data+'" alt="Artwork"></button><div class="artMeta"><span>'+galleryDate(x.artDate)+'</span><div class="artBtns"><button class="artAction" title="Favorite" onclick="event.stopPropagation();toggleGalleryFavorite(\''+x.id+'\')">'+(x.favorite?'★':'☆')+'</button><button class="artAction danger" title="Delete" onclick="event.stopPropagation();deleteGalleryItem(\''+x.id+'\')">🗑</button></div></div></article>';
}
function deleteGalleryItem(id){const x=galleryItems.find(a=>a.id===id);if(!x)return;x.deletedAt=Date.now();saveGallery();renderGallery();toast(settings.lang==='ar'?'نُقلت الصورة إلى سلة المهملات':'Artwork moved to trash');vibrate()}
function restoreGalleryItem(id){const x=galleryItems.find(a=>a.id===id);if(!x)return;x.deletedAt=null;saveGallery();renderGallery();toast(settings.lang==='ar'?'تمت استعادة الصورة':'Artwork restored');vibrate()}
function deleteGalleryForever(id){galleryItems=galleryItems.filter(x=>x.id!==id);saveGallery();renderGallery();toast(settings.lang==='ar'?'حُذفت الصورة نهائيًا':'Artwork deleted permanently')}
function toggleGalleryFavorite(id){const x=galleryItems.find(a=>a.id===id);if(!x)return;x.favorite=!x.favorite;saveGallery();renderGallery()}
function openGalleryImage(id){
  const x=galleryItems.find(a=>a.id===id);if(!x)return;
  const intro=$('galleryIntro');if(intro){intro.classList.remove('active');intro.setAttribute('aria-hidden','true');}
  const viewer=$('galleryViewer');if(!viewer)return;
  viewer.setAttribute('aria-hidden','false');
  viewer.innerHTML='<div class="galleryViewerBox"><div class="viewerTop"><button class="galleryBack" id="viewerClose">‹</button><div class="galleryViewerTitle">'+escapeHtml(x.name)+'</div><button class="viewerDelete" onclick="deleteGalleryItemFromViewer(\''+x.id+'\')">🗑</button></div><div class="viewerImageWrap"><img src="'+x.data+'" alt="Artwork"></div><div class="viewerInfo"><div class="dateBlock"><b>'+(settings.lang==='ar'?'تاريخ إنشاء العمل':'Artwork creation date')+'</b><input class="field" id="artDateInput" type="datetime-local" value="'+toLocalDateTime(x.artDate)+'"><small>'+(settings.lang==='ar'?'يمكنك تعديل التاريخ والوقت الأصليين للعمل.':'You can edit the original artwork date and time.')+'</small></div><div class="dateBlock"><b>'+(settings.lang==='ar'?'أضيف إلى المعرض':'Added to gallery')+'</b><div class="readOnlyDate">'+galleryDate(x.addedAt,true)+'</div></div><div class="viewerActions"><button class="secondary" id="viewerSaveDate">✓ '+(settings.lang==='ar'?'حفظ التاريخ':'Save date')+'</button><button class="secondary" id="viewerFav">★ '+(x.favorite?(settings.lang==='ar'?'إزالة من المفضلة':'Unfavorite'):(settings.lang==='ar'?'المفضلة':'Favorite'))+'</button></div></div></div>';
  viewer.classList.add('show');
  $('viewerClose').onclick=()=>{viewer.classList.remove('show');viewer.setAttribute('aria-hidden','true')};
  $('viewerSaveDate').onclick=()=>{x.artDate=fromLocalDateTime($('artDateInput').value);saveGallery();renderGallery();openGalleryImage(id);toast(settings.lang==='ar'?'تم حفظ تاريخ العمل':'Artwork date saved');};
  $('viewerFav').onclick=()=>{toggleGalleryFavorite(id);openGalleryImage(id)};
}
function deleteGalleryItemFromViewer(id){const viewer=$('galleryViewer');if(viewer){viewer.classList.remove('show');viewer.setAttribute('aria-hidden','true')}deleteGalleryItem(id)}
function escapeHtml(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
async function handleGalleryFiles(e){
  const files=Array.from(e.target.files||[]);if(!files.length)return;
  for(const file of files){
    if(!file.type.startsWith('image/'))continue;
    const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file)});
    const fileDate=Number.isFinite(file.lastModified)?file.lastModified:Date.now();
    galleryItems.push({id:makeId(),data,createdAt:fileDate,addedAt:Date.now(),artDate:fileDate,deletedAt:null,favorite:false,name:file.name});
  }
  saveGallery();e.target.value='';galleryView='all';galleryFavOnly=false;renderGallery();toast(settings.lang==='ar'?'تمت إضافة الأعمال إلى المعرض':'Artwork added to gallery');vibrate();
}
$('galleryBack').onclick=hideGallery;
function showAbout(){
  closeDrawer();
  const bio=settings.lang==='ar' ? `درس نظم المعلومات الإدارية في جامعة الخرطوم (2018–2025). وهو مصمم جرافيك، وبانٍ ومطوّر للأنظمة والتطبيقات، ومطوّر مواقع ويب. درس السلوك التنظيمي في الإدارة، والاقتصاد، والمحاسبة المالية، ومهارات الاتصال، وهو مفكر في مجال الذكاء الاصطناعي، والحواسيب الحديثة، وتقنية النانو.` : `He studied Management Information Systems at the University of Khartoum (2018–2025). He is a graphic designer, systems and application builder and developer, web developer. He studied organizational behavior in management, economics, financial accounting, and communication skills, and is a thinker in artificial intelligence, modern computers, and nanotechnology.`;
  showModal('<div class="modalHead"><h2>'+t('about')+'</h2><button class="closeX" onclick="hideModal()">×</button></div>' +
    '<img class="aboutPhoto" src="assets/about_photo.jpg" alt="Dafaallah Mohamed Ali Alshaikh">' +
    '<h3 class="aboutName">Dafaallah Mohamed Ali Alshaikh</h3>' +
    '<p class="aboutBio">'+bio+'</p>' +
    '<div class="aboutCredit">Baraa · About the creator</div>');
}
function closeDrawer(){$('drawer').classList.remove('show')}
$('menu').onclick=()=>{$('drawer').classList.add('show');updateDrawerStats()};
$('drawer').onclick=e=>{if(e.target===$('drawer'))closeDrawer()};
let addSecretTimer=null,addSecretActive=false,addSecretTriggered=false;
function setupAddLongPress(){
  const el=$('add');if(!el)return;
  const start=e=>{if(e&&e.button!==undefined&&e.button!==0)return;addSecretActive=true;addSecretTriggered=false;addSecretTimer=setTimeout(()=>{addSecretTimer=null;if(addSecretActive){addSecretActive=false;addSecretTriggered=true;showGallery();e&&e.preventDefault&&e.preventDefault()}},3000)};
  const cancel=()=>{addSecretActive=false;if(addSecretTimer){clearTimeout(addSecretTimer);addSecretTimer=null}};
  el.addEventListener('pointerdown',start);el.addEventListener('pointerup',cancel);el.addEventListener('pointercancel',cancel);el.addEventListener('pointerleave',cancel);el.addEventListener('contextmenu',e=>e.preventDefault());
  el.addEventListener('click',e=>{if(addSecretTriggered){e.preventDefault();e.stopImmediatePropagation();addSecretTriggered=false;return}openEditor();vibrate(8)},true);
}
$('mb').onclick=e=>{if(e.target===$('mb')){if(editorOpen)closeEditor();else hideModal()}};
$('mode').onclick=()=>{settings.dark=!settings.dark;saveSettings();applySettings()};
$('trash').onclick=()=>{trash()};
$('favorites').onclick=()=>{setFilter(favoritesOnly?'all':'fav');closeDrawer()};
$('themes').onclick=showThemes;
$('security').onclick=security;
$('backup').onclick=backup;
$('language').onclick=()=>setLanguage(settings.lang==='ar'?'en':'ar');
$('about').onclick=showAbout;
setupAboutSecret();setupDrawerSecrets();setupPinSecret();setupAddLongPress();
$('layout').onclick=()=>{settings.layout=settings.layout==='grid'?'portrait':settings.layout==='portrait'?'list':'grid';saveSettings();applySettings();render()};
$('searchToggle').onclick=toggleSearch;
$('searchClose').onclick=toggleSearch;
$('searchInput').oninput=e=>{searchQuery=e.target.value;render()};
$('sortToggle').onclick=cycleSort;

/* Android/browser back button: close the note editor instead of leaving DAFAALLAH. */
window.addEventListener('popstate',()=>{
  if($('galleryScreen')?.classList.contains('show')){hideGallery();return}
  if(editorOpen){
    editorOpen=false;
    editorHistory=false;
    hideModal();
    render();
  }
});

window.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden'&&appKey&&settings.autoLock)lockApp()});

let secretPressTimer=null;let secretDisplayTimer=null;let secretPressActive=false;
function restoreBrandSecret(){
  if(secretDisplayTimer){clearTimeout(secretDisplayTimer);secretDisplayTimer=null;}
  const el=$('brandName'); if(!el)return;
  el.classList.remove('secret');
  el.textContent=settings.lang==='ar'?'براءة':'Baraa';
}
function showSecretBrand(){
  if(secretDisplayTimer)clearTimeout(secretDisplayTimer);
  const el=$('brandName'); if(!el)return;
  el.classList.add('secret');
  el.textContent='يحفظكِ الرحمن';
  secretDisplayTimer=setTimeout(restoreBrandSecret,3000);
}
function startSecretPress(e){
  if(e&&e.button!==undefined&&e.button!==0)return;
  if(secretPressTimer)clearTimeout(secretPressTimer);
  secretPressActive=true;
  secretPressTimer=setTimeout(()=>{secretPressTimer=null;if(secretPressActive)showSecretBrand()},3000);
}
function cancelSecretPress(){
  secretPressActive=false;
  if(secretPressTimer){clearTimeout(secretPressTimer);secretPressTimer=null;}
}
function setupSecretBrand(){
  const el=$('brandName'); if(!el)return;
  const top=el.closest('header.top');
  const target=top||el;
  target.addEventListener('pointerdown',startSecretPress);
  target.addEventListener('pointerup',cancelSecretPress);
  target.addEventListener('pointercancel',cancelSecretPress);
  target.addEventListener('pointerleave',cancelSecretPress);
  target.addEventListener('contextmenu',e=>e.preventDefault());
}

let aboutSecretTimer=null;let aboutSecretDisplayTimer=null;let aboutSecretActive=false;
function restoreAboutSecret(){
  if(aboutSecretDisplayTimer){clearTimeout(aboutSecretDisplayTimer);aboutSecretDisplayTimer=null;}
  const el=$('aboutText'); if(!el)return;
  el.textContent=t('about');
  $('about').classList.remove('secret');
}
function showAboutSecret(){
  if(aboutSecretDisplayTimer)clearTimeout(aboutSecretDisplayTimer);
  const el=$('aboutText'); if(!el)return;
  el.textContent='Be always fine';
  $('about').classList.add('secret');
  aboutSecretDisplayTimer=setTimeout(restoreAboutSecret,3000);
}
function startAboutSecret(e){
  if(e&&e.button!==undefined&&e.button!==0)return;
  if(aboutSecretTimer)clearTimeout(aboutSecretTimer);
  aboutSecretActive=true;
  aboutSecretTimer=setTimeout(()=>{
    aboutSecretTimer=null;
    if(aboutSecretActive){
      showAboutSecret();
      e&&e.preventDefault&&e.preventDefault();
    }
  },3000);
}
function cancelAboutSecret(){
  aboutSecretActive=false;
  if(aboutSecretTimer){clearTimeout(aboutSecretTimer);aboutSecretTimer=null;}
}
function setupAboutSecret(){
  const el=$('about'); if(!el)return;
  el.addEventListener('pointerdown',startAboutSecret);
  el.addEventListener('pointerup',cancelAboutSecret);
  el.addEventListener('pointercancel',cancelAboutSecret);
  el.addEventListener('pointerleave',cancelAboutSecret);
  el.addEventListener('contextmenu',e=>e.preventDefault());
  el.addEventListener('click',e=>{
    if(el.classList.contains('secret')){e.preventDefault();e.stopImmediatePropagation();}
  },true);
}

function genericItemSecret(id,message,restoreFn){
  const el=$(id);if(!el)return;let timer=null,active=false,display=null;
  const restore=()=>{if(display)clearTimeout(display);restoreFn();el.classList.remove('secret')};
  const start=e=>{if(e&&e.button!==undefined&&e.button!==0)return;active=true;timer=setTimeout(()=>{timer=null;if(active){active=false;el.classList.add('secret');el.textContent=message;display=setTimeout(restore,3000);e&&e.preventDefault&&e.preventDefault()}},3000)};
  const cancel=()=>{active=false;if(timer){clearTimeout(timer);timer=null}};
  el.addEventListener('pointerdown',start);el.addEventListener('pointerup',cancel);el.addEventListener('pointercancel',cancel);el.addEventListener('pointerleave',cancel);el.addEventListener('contextmenu',e=>e.preventDefault());
  el.addEventListener('click',e=>{if(el.classList.contains('secret')){e.preventDefault();e.stopImmediatePropagation()}},true);
}
function setupDrawerSecrets(){
  genericItemSecret('drawerBrand','ابتسمي',()=>{$('drawerBrand').textContent=settings.lang==='ar'?'براءة':'Baraa'});
  genericItemSecret('favoritesText','1',()=>{$('favoritesText').textContent=t('favorites')});
  genericItemSecret('backupText','مُتَوَاضِعَة',()=>{$('backupText').textContent=t('backup')});
  genericItemSecret('trashText','انتِ الأفضل',()=>{$('trashText').textContent=t('trash')});
  genericItemSecret('securityText','مُثَابِرَةٌ',()=>{$('securityText').textContent=t('security')});
  genericItemSecret('themesText','عِفَّةٌوَبَهَاء',()=>{$('themesText').textContent=t('themes')});
}
function setupPinSecret(){
  const el=$('pinBtn');if(!el)return;let timer=null,active=false,display=null;
  const restore=()=>{if(display)clearTimeout(display);updatePinBtn();el.classList.remove('secret')};
  const start=e=>{if(e&&e.button!==undefined&&e.button!==0)return;active=true;timer=setTimeout(()=>{timer=null;if(active){active=false;el.classList.add('secret');el.textContent='انتِ الأفضل';display=setTimeout(restore,3000)}},3000)};
  const cancel=()=>{active=false;if(timer){clearTimeout(timer);timer=null}};
  el.addEventListener('pointerdown',start);el.addEventListener('pointerup',cancel);el.addEventListener('pointercancel',cancel);el.addEventListener('pointerleave',cancel);el.addEventListener('contextmenu',e=>e.preventDefault());
  el.addEventListener('click',e=>{if(el.classList.contains('secret')){e.preventDefault();e.stopImmediatePropagation()}},true);
}

function finishSplash(){
  if(splashDone)return;splashDone=true;
  $('splash').classList.add('hide');
  const meta=localStorage.getItem(META_KEY),blob=localStorage.getItem(SECURE_KEY);
  if(meta&&blob)showUnlock();else setupLock();
}
async function init(){
  loadSettings();applySettings();setupSecretBrand();
  window.setTimeout(finishSplash,10000);
}
init();

