const KEY="caltrack_data_v1";
let data=JSON.parse(localStorage.getItem(KEY)||'{"goal":2000,"days":{}}');
const today=()=>new Date().toISOString().slice(0,10);
function save(){localStorage.setItem(KEY,JSON.stringify(data))}
function day(){let d=today();if(!data.days[d])data.days[d]=[];return data.days[d]}
function euroDate(s){return new Date(s+"T12:00:00").toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long"})}
function render(){
 const foods=day(), eaten=foods.reduce((a,x)=>a+Number(x.kcal||0),0), rem=Math.max(0,Number(data.goal)-eaten);
 document.querySelector("#date").textContent=euroDate(today());
 document.querySelector("#goal").textContent=Math.round(data.goal);
 document.querySelector("#eaten").textContent=Math.round(eaten);
 document.querySelector("#remaining").textContent=Math.round(rem);
 document.querySelector("#goalInput").value=data.goal;
 const box=document.querySelector("#foods");
 box.innerHTML=foods.length?foods.map((x,i)=>`<div class="food"><div><b>${esc(x.name)}</b><small>${x.kcal} kcal · P ${x.p||0}g · G ${x.c||0}g · L ${x.f||0}g</small></div><button class="del" onclick="removeFood(${i})">×</button></div>`).join(""):'<p class="muted">Aucun aliment ajouté.</p>';
 let keys=Object.keys(data.days).sort().reverse();
 document.querySelector("#history").innerHTML=keys.length?keys.slice(0,30).map(k=>{let n=data.days[k].reduce((a,x)=>a+Number(x.kcal||0),0);return `<div class="day"><b>${euroDate(k)}</b><br><span class="muted">${Math.round(n)} kcal · ${data.days[k].length} aliment(s)</span></div>`}).join(""):'<p class="muted">Ton historique apparaîtra ici.</p>';
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
window.removeFood=i=>{day().splice(i,1);save();render()};
function openManual(pref={}){document.querySelector("#modalTitle").textContent="Ajouter un aliment";document.querySelector("#foodName").value=pref.name||"";document.querySelector("#foodKcal").value=pref.kcal??"";document.querySelector("#foodP").value=pref.p??0;document.querySelector("#foodC").value=pref.c??0;document.querySelector("#foodF").value=pref.f??0;document.querySelector("#modal").classList.remove("hidden")}
document.querySelector("#manualBtn").onclick=()=>openManual();
document.querySelector("#close").onclick=()=>document.querySelector("#modal").classList.add("hidden");
document.querySelector("#foodForm").onsubmit=e=>{e.preventDefault();day().push({name:foodName.value,kcal:Number(foodKcal.value),p:Number(foodP.value),c:Number(foodC.value),f:Number(foodF.value)});save();document.querySelector("#modal").classList.add("hidden");render()};
document.querySelector("#saveGoal").onclick=()=>{data.goal=Math.max(1,Number(document.querySelector("#goalInput").value));save();render()};
document.querySelector("#photoBtn").onclick=()=>document.querySelector("#photoInput").click();
document.querySelector("#photoInput").onchange=()=>{if(document.querySelector("#photoInput").files[0]){alert("Photo ajoutée. Pour éviter de fabriquer une fausse valeur calorique, confirme l'aliment et sa quantité manuellement.");openManual()}};
document.querySelector("#scanBtn").onclick=()=>document.querySelector("#scanner").classList.remove("hidden");
document.querySelector("#closeScanner").onclick=()=>document.querySelector("#scanner").classList.add("hidden");
document.querySelector("#lookup").onclick=async()=>{
 const code=document.querySelector("#barcode").value.trim(), out=document.querySelector("#scanResult");
 if(!code){out.innerHTML='<p class="muted">Entre un code-barres.</p>';return}
 out.innerHTML='<p class="muted">Recherche…</p>';
 try{
  const r=await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json`);
  const j=await r.json();
  if(j.status!==1){out.innerHTML='<p>Produit introuvable. Tu peux l’ajouter manuellement.</p>';return}
  const p=j.product,n=p.nutriments||{}, name=p.product_name_fr||p.product_name||"Produit";
  const kcal=n["energy-kcal_100g"]??(n["energy-kcal_value"]??0), prot=n.proteins_100g??0, carb=n.carbohydrates_100g??0, fat=n.fat_100g??0;
  out.innerHTML=`<div class="result"><b>${esc(name)}</b><p>${kcal} kcal / 100 g</p><button class="primary" id="useProduct">Ajouter 100 g</button></div>`;
  document.querySelector("#useProduct").onclick=()=>{day().push({name:name+" (100 g)",kcal:Number(kcal),p:Number(prot),c:Number(carb),f:Number(fat)});save();document.querySelector("#scanner").classList.add("hidden");render()};
 }catch(e){out.innerHTML='<p>Connexion impossible. Vérifie Internet puis réessaie.</p>'}
};
if("serviceWorker" in navigator)navigator.serviceWorker.register("./sw.js");
render();