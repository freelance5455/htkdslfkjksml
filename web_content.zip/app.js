/* ---------------- STATE & STORAGE ---------------- */
let state = {
  orgName:'সমিতি হিসাব',
  members:[],
  transactions:[], // {id, memberId, date, type:'deposit'|'withdrawal'|'profit', category, amount, method, remarks}
  expenses:[],      // {id, date, head, description, amount, method, paidTo}
  fdrs:[],          // {id, fdrNo, bankName, branch, accountNo, openDate, maturityDate, principal, rate, tenureMonths, status}
  profitRuns:[],     // {id, date, totalProfit, note, distributions:[{memberId, amount}]}
  users:[],          // {id, name, username, pin, role, memberId?}
  loggedInUserId:null,
  accountTypes:[],   // {id, name, group}
  accounts:[],        // {id, code, name, group, typeId, openingBalance, openingSide:'dr'|'cr', status}
  journalEntries:[],  // {id, voucherNo, date, narration, lines:[{accountId, debit, credit}]}
  systemAccountMap:{} // {cash: accountId, bank: accountId, fdr: accountId} — links COA accounts into dashboard totals
};
let activeTab = 'dashboard';
let txSubTab = 'deposit';
let storageReady = false;
let offlineMode = false;
let lastSaveError = '';

/* ---------------- ROLES & PERMISSIONS ---------------- */
const ROLES = ['সুপার অ্যাডমিন','হিসাবরক্ষক','ম্যানেজার','কালেক্টর','সদস্য'];
const ROLE_TABS = {
  'সুপার অ্যাডমিন': ['dashboard','members','transactions','fdr','profit','accounting'],
  'হিসাবরক্ষক': ['dashboard','transactions','fdr','profit','accounting'],
  'ম্যানেজার': ['dashboard','members','profit'],
  'কালেক্টর': ['dashboard','members','transactions'],
  'সদস্য': ['myaccount'],
};
const TAB_LABELS = {dashboard:'ড্যাশবোর্ড',members:'সদস্য',transactions:'লেনদেন',fdr:'এফডিআর',profit:'প্রোফিট',myaccount:'আমার হিসাব',accounting:'হিসাবরক্ষণ'};
/* Fixed, standard Chart-of-Accounts structure (matches conventional GL software):
   Account Group is a numbered category (Cash, Fixed Assets, Revenue, etc.) used for
   organizing accounts; Account Type (Balance Sheet / Income Statement / Retained
   Earnings) and Normal Balance (Debit / Credit) are independent, editable fields on
   each account — selecting a Group only fills in sensible defaults for them. */
const ACCOUNT_TYPES = [
  {code:'balance_sheet', name:'ব্যালেন্স শীট'},
  {code:'income_statement', name:'আয়-ব্যয় বিবরণী'},
  {code:'retained_earnings', name:'সঞ্চিত আয় (Retained Earnings)'},
];
const ACCOUNT_GROUPS_DEF = [
  {code:'01', name:'নগদ ও নগদ সমতুল্য (Cash & Cash Equivalents)', accountType:'balance_sheet', normalBalance:'dr'},
  {code:'02', name:'প্রাপ্য হিসাব (Accounts Receivable)', accountType:'balance_sheet', normalBalance:'dr'},
  {code:'03', name:'মজুদ (Inventory)', accountType:'balance_sheet', normalBalance:'dr'},
  {code:'04', name:'অন্যান্য চলতি সম্পদ (Other Current Assets)', accountType:'balance_sheet', normalBalance:'dr'},
  {code:'05', name:'স্থায়ী সম্পদ (Fixed Assets)', accountType:'balance_sheet', normalBalance:'dr'},
  {code:'06', name:'সঞ্চিত অবচয় (Accumulated Depreciation)', accountType:'balance_sheet', normalBalance:'cr'},
  {code:'07', name:'অন্যান্য সম্পদ (Other Assets)', accountType:'balance_sheet', normalBalance:'dr'},
  {code:'08', name:'প্রদেয় হিসাব (Accounts Payable)', accountType:'balance_sheet', normalBalance:'cr'},
  {code:'09', name:'কর সঞ্চিতি (Provision for Income Taxes)', accountType:'balance_sheet', normalBalance:'cr'},
  {code:'10', name:'অন্যান্য চলতি দায় (Other Current Liabilities)', accountType:'balance_sheet', normalBalance:'cr'},
  {code:'11', name:'দীর্ঘমেয়াদী দায় (Long Term Liabilities)', accountType:'balance_sheet', normalBalance:'cr'},
  {code:'12', name:'অন্যান্য দায় (Other Liabilities)', accountType:'balance_sheet', normalBalance:'cr'},
  {code:'13', name:'শেয়ার মূলধন (Share Capital)', accountType:'balance_sheet', normalBalance:'cr'},
  {code:'14', name:'শেয়ারহোল্ডারদের ইকুইটি (Shareholders\' Equity)', accountType:'balance_sheet', normalBalance:'cr'},
  {code:'15', name:'আয় (Revenue)', accountType:'income_statement', normalBalance:'cr'},
  {code:'16', name:'বিক্রয়/সেবা ব্যয় (Cost of Sales)', accountType:'income_statement', normalBalance:'dr'},
  {code:'17', name:'পরিচালন ব্যয় (Operating Expenses)', accountType:'income_statement', normalBalance:'dr'},
  {code:'18', name:'প্রশাসনিক ব্যয় (Administrative Expenses)', accountType:'income_statement', normalBalance:'dr'},
  {code:'19', name:'আর্থিক ব্যয় (Financial Expenses)', accountType:'income_statement', normalBalance:'dr'},
  {code:'20', name:'অন্যান্য আয়/ব্যয় (Other Income/Expense)', accountType:'income_statement', normalBalance:'cr'},
  {code:'21', name:'সঞ্চিত আয় (Retained Earnings)', accountType:'retained_earnings', normalBalance:'cr'},
];
function accountGroupInfo(code){ return ACCOUNT_GROUPS_DEF.find(g=>g.code===code) || null; }
function accountTypeLabel(code){ const t=ACCOUNT_TYPES.find(x=>x.code===code); return t?t.name:'-'; }
/* Normal Balance is now a stored, independently-editable field per account (falls
   back to the account's group default only for older records that predate this). */
function isDebitNormal(account){
  if(account.normalBalance) return account.normalBalance==='dr';
  const g = accountGroupInfo(account.groupCode);
  return g ? g.normalBalance==='dr' : true;
}
function currentUser(){ return state.users.find(u=>u.id===state.loggedInUserId) || null; }
function allowedTabs(){
  const u = currentUser();
  if(!u) return [];
  return ROLE_TABS[u.role] || [];
}
function hasTab(tab){ return allowedTabs().includes(tab); }
function canDistribute(){ const u=currentUser(); return u && (u.role==='সুপার অ্যাডমিন'||u.role==='ম্যানেজার'); }
function canManageUsers(){ const u=currentUser(); return u && u.role==='সুপার অ্যাডমিন'; }

/* ---------------- STORAGE ADAPTER ----------------
   window.storage only exists inside Claude's own app/site preview.
   When this file is opened standalone (downloaded, "Open with Chrome",
   added to home screen, etc.) that object does not exist at all, so
   calling window.storage.set(...) throws "Cannot read properties of
   undefined". This adapter uses the browser's own localStorage as the
   primary, reliable backend, and only tries window.storage first when
   it is actually present (e.g. while previewing inside Claude). */
const DB_KEY = 'samity-db';
const hasNativeStorage = (typeof window !== 'undefined' && window.storage &&
  typeof window.storage.get === 'function' && typeof window.storage.set === 'function');
async function storageGet(key){
  if(hasNativeStorage){
    try{
      const r = await window.storage.get(key, false);
      if(r && typeof r.value === 'string') return r.value;
    }catch(e){ /* fall through to localStorage */ }
  }
  try{
    return localStorage.getItem(key);
  }catch(e){ return null; }
}
async function storageSet(key, value){
  if(hasNativeStorage){
    try{
      const r = await window.storage.set(key, value, false);
      if(r) return {ok:true};
    }catch(e){ /* fall through to localStorage */ }
  }
  try{
    localStorage.setItem(key, value);
    return {ok:true};
  }catch(e){
    return {ok:false, error:(e && e.message) ? e.message : String(e)};
  }
}

async function loadState(){
  try{
    const raw = await storageGet(DB_KEY);
    if(raw){
      const parsed = JSON.parse(raw);
      state = Object.assign(state, parsed);
    }
  }catch(e){ /* no existing data yet, or unreadable — start fresh */ }
  storageReady = true;
  checkAuth();
}
async function saveState(){
  if(offlineMode) return true; // user chose to continue without persistence; skip further attempts
  const payload = JSON.stringify(state);
  let lastErr = null;
  for(let attempt=1; attempt<=2; attempt++){
    const r = await storageSet(DB_KEY, payload);
    if(r.ok) return true;
    lastErr = r.error || 'অজানা ত্রুটি';
    console.error('save attempt '+attempt+' failed:', lastErr);
    if(attempt<2) await new Promise(res=>setTimeout(res, 400));
  }
  lastSaveError = lastErr || 'অজানা ত্রুটি';
  return false;
}
function saveFailToast(){
  toast('⚠️ সংরক্ষণ ব্যর্থ হয়েছে — আবার চেষ্টা করুন');
}
/* Called after a failed saveState(). Offers the user a choice via a native confirm
   dialog: keep the change in-memory for this session (offline mode) or discard it
   (caller's rollbackFn runs). Returns true if the caller should proceed as if the
   save succeeded, false if it should roll back. */
function offerOfflineContinue(rollbackFn){
  const msg = 'সংরক্ষণ ব্যর্থ হয়েছে।\n\nকারণ: '+lastSaveError+'\n\n"OK" চাপলে এই তথ্য শুধু এই সেশনে (অস্থায়ীভাবে) রাখা হবে — পেজ বন্ধ বা রিলোড করলে হারিয়ে যাবে। ব্যাকআপ নিতে সেটিংস থেকে "ডেটা এক্সপোর্ট" ব্যবহার করুন।\n\n"Cancel" চাপলে এই পরিবর্তনটি বাতিল হবে।';
  const proceed = confirm(msg);
  if(proceed){
    offlineMode = true;
    toast('⚠️ অফলাইন মোড চালু — নিয়মিত ব্যাকআপ নিন');
    return true;
  }
  if(rollbackFn) rollbackFn();
  saveFailToast();
  return false;
}

/* ---------------- UTIL ---------------- */
function uid(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,7); }
function fmt(n){
  n = Number(n)||0;
  const neg = n<0; n=Math.abs(n);
  const s = n.toLocaleString('en-IN', {maximumFractionDigits:0});
  return (neg?'-':'')+'৳'+s;
}
function todayISO(){ return new Date().toISOString().slice(0,10); }
function fmtDate(d){
  if(!d) return '-';
  const dt = new Date(d+'T00:00:00');
  const months=['জানু','ফেব্রু','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্ট','অক্টো','নভে','ডিসে'];
  return dt.getDate()+' '+months[dt.getMonth()]+' '+dt.getFullYear();
}
function initials(name){
  if(!name) return '?';
  const parts = name.trim().split(' ');
  return parts[0][0];
}
function toast(msg){
  const t = document.createElement('div');
  t.className='toast'; t.textContent=msg;
  document.body.appendChild(t);
  setTimeout(()=>t.remove(),1800);
}
/* Reads an image file, downsizes it, and returns a compact JPEG data URL —
   keeps photos/signatures/NID copies small so localStorage doesn't fill up.
   onError receives a human-readable reason so upload failures are visible
   instead of silently doing nothing (e.g. unsupported HEIC photos, huge files). */
function resizeImageToDataURL(file, maxDim, onDone, onError){
  if(!file){ if(onError) onError('কোনো ফাইল নির্বাচিত হয়নি'); return; }
  if(!file.type || file.type.indexOf('image/')!==0){
    if(onError) onError('এটি একটি ছবি ফাইল নয়। JPG বা PNG ছবি নির্বাচন করুন।');
    return;
  }
  if(file.size > 20*1024*1024){
    if(onError) onError('ছবিটি অনেক বড় (২০ MB-এর বেশি)। ছোট আকারের ছবি নির্বাচন করুন।');
    return;
  }
  const reader = new FileReader();
  reader.onerror = function(){ if(onError) onError('ফাইলটি পড়া যায়নি।'); };
  reader.onload = function(e){
    const img = new Image();
    img.onerror = function(){
      if(onError) onError('এই ছবির ফরম্যাট সমর্থিত নয় (যেমন HEIC/HEIF)। দয়া করে JPG বা PNG ছবি ব্যবহার করুন।');
    };
    img.onload = function(){
      try{
        let w = img.width, h = img.height;
        if(!w || !h){ if(onError) onError('ছবিটি পড়া যায়নি।'); return; }
        if(w>=h){ if(w>maxDim){ h = Math.round(h*maxDim/w); w = maxDim; } }
        else { if(h>maxDim){ w = Math.round(w*maxDim/h); h = maxDim; } }
        const canvas = document.createElement('canvas');
        canvas.width=w; canvas.height=h;
        canvas.getContext('2d').drawImage(img,0,0,w,h);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.72);
        onDone(dataUrl);
      }catch(err){
        if(onError) onError('ছবি প্রসেস করা যায়নি: '+((err&&err.message)||err));
      }
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

/* Member financial helpers */
/* Transactions saved as draft (খসড়া) don't affect any balance until posted. Older records have no status and count as posted. */
function isPosted(t){ return t.status!=='draft'; }
function postedTxs(){ return state.transactions.filter(isPosted); }
function memberTx(memberId){ return postedTxs().filter(t=>t.memberId===memberId); }
function memberDeposit(memberId){ return memberTx(memberId).filter(t=>t.type==='deposit').reduce((a,b)=>a+b.amount,0); }
function memberWithdrawal(memberId){ return memberTx(memberId).filter(t=>t.type==='withdrawal').reduce((a,b)=>a+b.amount,0); }
function memberProfit(memberId){ return memberTx(memberId).filter(t=>t.type==='profit').reduce((a,b)=>a+b.amount,0); }
function memberBalance(memberId){ return memberDeposit(memberId) - memberWithdrawal(memberId) + memberProfit(memberId); }
function memberCategoryBalance(memberId, category){
  const tx = memberTx(memberId).filter(t=>t.category===category);
  const dep = tx.filter(t=>t.type==='deposit').reduce((a,b)=>a+b.amount,0);
  const wd = tx.filter(t=>t.type==='withdrawal').reduce((a,b)=>a+b.amount,0);
  return dep - wd;
}

function totals(){
  const totalDeposit = postedTxs().filter(t=>t.type==='deposit').reduce((a,b)=>a+b.amount,0);
  const totalWithdrawal = postedTxs().filter(t=>t.type==='withdrawal').reduce((a,b)=>a+b.amount,0);
  const totalProfitPaid = postedTxs().filter(t=>t.type==='profit').reduce((a,b)=>a+b.amount,0);
  const totalExpense = state.expenses.reduce((a,b)=>a+b.amount,0);
  const byMethod=(arr,method)=>arr.filter(t=>t.method===method).reduce((a,b)=>a+b.amount,0);
  const cashDep = byMethod(postedTxs().filter(t=>t.type==='deposit'),'cash');
  const cashWd = byMethod(postedTxs().filter(t=>t.type==='withdrawal'),'cash');
  const cashExp = state.expenses.filter(e=>e.method==='cash').reduce((a,b)=>a+b.amount,0);
  const bankDep = byMethod(postedTxs().filter(t=>t.type==='deposit'),'bank');
  const bankWd = byMethod(postedTxs().filter(t=>t.type==='withdrawal'),'bank');
  const bankExp = state.expenses.filter(e=>e.method==='bank').reduce((a,b)=>a+b.amount,0);
  // Manual journal entries posted to the mapped Cash/Bank/FDR accounts flow into these
  // same totals, so a journal entry actually affects the dashboard, not just the ledger.
  const map = state.systemAccountMap || {};
  const journalCash = map.cash ? accountBalance(map.cash) : 0;
  const journalBank = map.bank ? accountBalance(map.bank) : 0;
  const journalFdr = map.fdr ? accountBalance(map.fdr) : 0;
  const cashBalance = cashDep - cashWd - cashExp + journalCash;
  const bankBalance = bankDep - bankWd - bankExp + journalBank;
  const fdrPrincipal = state.fdrs.filter(f=>f.status!=='বন্ধ').reduce((a,b)=>a+Number(b.principal||0),0) + journalFdr;
  const fdrAccrued = state.fdrs.filter(f=>f.status!=='বন্ধ').reduce((a,b)=>a+fdrAccruedProfit(b),0);
  // Journal entries posted to income/expense group accounts also count toward reported totals.
  const journalIncome = state.accounts.filter(a=>a.accountType==='income_statement' && a.normalBalance==='cr').reduce((s,a)=>s-accountBalance(a.id),0);
  const journalExpense = state.accounts.filter(a=>a.accountType==='income_statement' && a.normalBalance==='dr').reduce((s,a)=>s+accountBalance(a.id),0);
  return {totalDeposit, totalWithdrawal, totalProfitPaid, totalExpense, cashBalance, bankBalance, fdrPrincipal, fdrAccrued, journalIncome, journalExpense};
}
function fdrAccruedProfit(f){
  const open = new Date(f.openDate);
  const now = new Date();
  const months = Math.max(0,(now.getFullYear()-open.getFullYear())*12 + (now.getMonth()-open.getMonth()));
  const rate = Number(f.rate||0)/100;
  return Math.round(Number(f.principal||0) * rate * (months/12));
}
function fdrMaturityAmount(f){
  const rate=Number(f.rate||0)/100;
  const years=Number(f.tenureMonths||0)/12;
  return Math.round(Number(f.principal||0)*(1+rate*years));
}
function fdrExpectedProfit(f){
  return fdrMaturityAmount(f) - Number(f.principal||0);
}
/* Expected Profit above is gross. Tax is a % of that profit; bank charge is a flat expected amount. */
function fdrTax(f){ return Math.round(fdrExpectedProfit(f) * Number(f.taxRate||0)/100); }
function fdrBankCharge(f){ return Number(f.bankCharge||0); }
function fdrNetProfit(f){ return fdrExpectedProfit(f) - fdrTax(f) - fdrBankCharge(f); }
function fdrNetMaturity(f){ return Number(f.principal||0) + fdrNetProfit(f); }

/* ---------------- AUTH ---------------- */
function checkAuth(){
  const authEl = document.getElementById('authScreen');
  const appEl = document.getElementById('app');
  if(state.users.length===0){
    appEl.style.display='none'; authEl.style.display='flex';
    renderSetup();
    return;
  }
  if(!currentUser()){
    appEl.style.display='none'; authEl.style.display='flex';
    renderLogin();
    return;
  }
  authEl.style.display='none'; appEl.style.display='flex';
  if(migrateLegacyAccounts()) saveState();
  const allowed = allowedTabs();
  if(!allowed.includes(activeTab)) activeTab = allowed[0] || 'dashboard';
  renderAll();
}
function renderSetup(){
  const el = document.getElementById('authScreen');
  el.innerHTML = `
    <div class="brand"><div class="name">সমিতি হিসাব ব্যবস্থাপনা</div><div class="tag">প্রথমবার ব্যবহারের জন্য অ্যাডমিন একাউন্ট তৈরি করুন</div></div>
    <div class="auth-card">
      <h2>সুপার অ্যাডমিন একাউন্ট তৈরি করুন</h2>
      <div class="field"><label>নাম *</label><input id="su_name"></div>
      <div class="field"><label>ইউজারনেম *</label><input id="su_user" placeholder="যেমন admin"></div>
      <div class="field"><label>৪-সংখ্যার পিন *</label><input id="su_pin" type="password" inputmode="numeric" maxlength="4"></div>
      <button class="btn block" onclick="submitSetup()">একাউন্ট তৈরি করুন ও শুরু করুন</button>
      <div class="hint">এই একাউন্টটি দিয়ে পরে আরও ইউজার (হিসাবরক্ষক, ম্যানেজার, কালেক্টর, সদস্য) যোগ করতে পারবেন সেটিংস থেকে।</div>
      <div style="text-align:center;margin-top:14px;">
        <button class="link-btn" onclick="document.getElementById('importFileInput').click()">আগের ব্যাকআপ ফাইল থেকে পুনরুদ্ধার করুন</button>
      </div>
    </div>
  `;
}
async function submitSetup(){
  const name = document.getElementById('su_name').value.trim();
  const username = document.getElementById('su_user').value.trim();
  const pin = document.getElementById('su_pin').value.trim();
  if(!name || !username){ toast('নাম ও ইউজারনেম আবশ্যক'); return; }
  if(!/^\d{4}$/.test(pin)){ toast('৪-সংখ্যার পিন দিন'); return; }
  const u = {id:uid(), name, username, pin, role:'সুপার অ্যাডমিন'};
  state.users.push(u);
  state.loggedInUserId = u.id;
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.users.pop(); state.loggedInUserId = null; }); if(!proceed) return; }
  checkAuth();
}
function renderLogin(){
  const el = document.getElementById('authScreen');
  el.innerHTML = `
    <div class="brand"><div class="name">${state.orgName}</div><div class="tag">লগইন করে প্রবেশ করুন</div></div>
    <div class="auth-card">
      <h2>লগইন</h2>
      <div class="field"><label>ইউজার নির্বাচন করুন</label>
        <select id="li_user">${state.users.map(u=>`<option value="${u.id}">${u.name} (${u.role})</option>`).join('')}</select>
      </div>
      <div class="field"><label>পিন</label><input id="li_pin" type="password" inputmode="numeric" maxlength="4"></div>
      <button class="btn block" onclick="submitLogin()">প্রবেশ করুন</button>
    </div>
  `;
}
async function submitLogin(){
  const userId = document.getElementById('li_user').value;
  const pin = document.getElementById('li_pin').value.trim();
  const u = state.users.find(x=>x.id===userId);
  if(!u || u.pin!==pin){ toast('পিন সঠিক নয়'); return; }
  state.loggedInUserId = u.id;
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.loggedInUserId = null; }); if(!proceed) return; }
  checkAuth();
}
async function logout(){
  state.loggedInUserId = null;
  saveState(); // best-effort; logging out shouldn't be blocked by a storage hiccup
  closeSheet(); checkAuth();
}

/* ---------------- USER MANAGEMENT (Super Admin) ---------------- */
function openUsersManagement(){
  showSheet(`
    <h2>ব্যবহারকারী ব্যবস্থাপনা</h2>
    <div id="usersListWrap"></div>
    <button class="btn block" style="margin-top:14px;" onclick="openUserForm()">+ নতুন ব্যবহারকারী যোগ করুন</button>
  `);
  renderUsersList();
}
function renderUsersList(){
  const wrap = document.getElementById('usersListWrap');
  if(!wrap) return;
  if(state.users.length===0){ wrap.innerHTML = `<div class="empty-state"><div class="d">কোনো ব্যবহারকারী নেই</div></div>`; return; }
  wrap.innerHTML = state.users.map(u=>{
    const m = u.memberId ? state.members.find(x=>x.id===u.memberId) : null;
    return `<div class="list-item">
      <div class="avatar">${initials(u.name)}</div>
      <div class="body"><div class="title">${u.name}</div><div class="meta userline">@${u.username} ${m?'· '+m.name:''}</div><span class="role-badge">${u.role}</span></div>
      <div class="right">
        <button class="link-btn" onclick="openUserForm(${JSON.stringify(u).replace(/"/g,'&quot;')})">সম্পাদনা</button><br>
        ${u.id!==state.loggedInUserId?`<button class="link-btn" style="color:var(--danger);margin-top:6px;" onclick="deleteUser('${u.id}')">মুছুন</button>`:''}
      </div>
    </div>`;
  }).join('');
}
function openUserForm(existing){
  const u = existing || {};
  showSheet(`
    <h2>${existing?'ব্যবহারকারী সম্পাদনা':'নতুন ব্যবহারকারী'}</h2>
    <div class="field"><label>নাম *</label><input id="u_name" value="${u.name||''}"></div>
    <div class="field-row">
      <div class="field"><label>ইউজারনেম *</label><input id="u_user" value="${u.username||''}"></div>
      <div class="field"><label>৪-সংখ্যার পিন *</label><input id="u_pin" type="password" inputmode="numeric" maxlength="4" value="${u.pin||''}"></div>
    </div>
    <div class="field"><label>রোল</label>
      <select id="u_role" onchange="toggleMemberLink()">${ROLES.map(r=>`<option ${u.role===r?'selected':''}>${r}</option>`).join('')}</select>
    </div>
    <div class="field" id="u_memberWrap" style="display:${u.role==='সদস্য'?'block':'none'};">
      <label>যুক্ত সদস্য</label>
      <select id="u_member"><option value="">-- নির্বাচন করুন --</option>${memberOptionsHtml(u.memberId)}</select>
    </div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn" onclick="saveUser('${existing?existing.id:''}')">সংরক্ষণ করুন</button>
    </div>
  `);
}
function toggleMemberLink(){
  const role = document.getElementById('u_role').value;
  document.getElementById('u_memberWrap').style.display = role==='সদস্য' ? 'block':'none';
}
async function saveUser(id){
  const name = document.getElementById('u_name').value.trim();
  const username = document.getElementById('u_user').value.trim();
  const pin = document.getElementById('u_pin').value.trim();
  const role = document.getElementById('u_role').value;
  const memberId = role==='সদস্য' ? document.getElementById('u_member').value : undefined;
  if(!name || !username){ toast('নাম ও ইউজারনেম আবশ্যক'); return; }
  if(!/^\d{4}$/.test(pin)){ toast('৪-সংখ্যার পিন দিন'); return; }
  const dupe = state.users.find(x=>x.username===username && x.id!==id);
  if(dupe){ toast('এই ইউজারনেম আগে থেকেই আছে'); return; }
  const prevUsers = JSON.parse(JSON.stringify(state.users));
  if(id){
    const idx = state.users.findIndex(x=>x.id===id);
    state.users[idx] = {...state.users[idx], name, username, pin, role, memberId};
  } else {
    state.users.push({id:uid(), name, username, pin, role, memberId});
  }
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.users = prevUsers; }); if(!proceed) return; }
  openUsersManagement(); toast('ব্যবহারকারী সংরক্ষিত হয়েছে');
}
async function deleteUser(id){
  if(!confirm('এই ব্যবহারকারীকে মুছে ফেলতে চান?')) return;
  const prevUsers = state.users;
  state.users = state.users.filter(x=>x.id!==id);
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.users = prevUsers; }); if(!proceed) return; }
  openUsersManagement();
}

/* ---------------- SHELL RENDER ---------------- */
function renderAll(){
  if(!currentUser()) return;
  renderTopStrip();
  renderBottomNav();
  const c = document.getElementById('content');
  const fab = document.getElementById('fabWrap');
  fab.innerHTML='';
  if(!storageReady){ c.innerHTML = '<div class="empty-state"><div class="icon">⏳</div><div class="t">লোড হচ্ছে…</div></div>'; return; }
  if(activeTab==='dashboard') renderDashboard(c,fab);
  else if(activeTab==='members') renderMembers(c,fab);
  else if(activeTab==='transactions') renderTransactions(c,fab);
  else if(activeTab==='fdr') renderFdr(c,fab);
  else if(activeTab==='profit') renderProfit(c,fab);
  else if(activeTab==='myaccount') renderMyAccount(c,fab);
  else if(activeTab==='accounting') renderAccounting(c,fab);
}
function renderBottomNav(){
  const nav = document.getElementById('bottomNav');
  const allowed = allowedTabs();
  nav.innerHTML = allowed.map(t=>`
    <button data-tab="${t}" onclick="switchTab('${t}')" class="${t===activeTab?'active':''}">
      ${navIcon(t)}
      <span class="lbl">${TAB_LABELS[t]}</span>
    </button>`).join('');
}
function navIcon(t){
  const icons = {
    dashboard:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/></svg>',
    members:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6.5 6.5-6.5s6.5 2.9 6.5 6.5"/><circle cx="17.5" cy="8.5" r="2.8"/><path d="M15.5 13.3c2.9.3 5 2.8 5 6.2"/></svg>',
    transactions:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7h13l-3-3M20 17H7l3 3"/></svg>',
    fdr:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/></svg>',
    profit:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 17l6-6 4 4 8-8M15 7h6v6"/></svg>',
    myaccount:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4.4 3.6-7 8-7s8 2.6 8 7"/></svg>',
    accounting:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16v16H4z"/><path d="M4 9h16M9 9v11"/></svg>',
  };
  return icons[t]||'';
}
function renderMyAccount(c,fab){
  const u = currentUser();
  const m = u.memberId ? state.members.find(x=>x.id===u.memberId) : null;
  c.innerHTML = `<div class="page-head"><div><h1>আমার হিসাব</h1><div class="sub">${u.name}</div></div></div><div id="myAccountBody"></div>`;
  fab.innerHTML='';
  const body = document.getElementById('myAccountBody');
  if(!m){ body.innerHTML = `<div class="empty-state"><div class="icon">👤</div><div class="t">কোনো সদস্য যুক্ত নেই</div><div class="d">আপনার একাউন্টের সাথে কোনো সদস্য প্রোফাইল যুক্ত করা হয়নি। অ্যাডমিনের সাথে যোগাযোগ করুন।</div></div>`; return; }
  const dep=memberDeposit(m.id), wd=memberWithdrawal(m.id), pr=memberProfit(m.id), bal=memberBalance(m.id);
  body.innerHTML = `
    <div class="stat-grid" style="margin-top:10px;">
      <div class="stat-card"><div class="k">মোট জমা</div><div class="v">${fmt(dep)}</div></div>
      <div class="stat-card danger"><div class="k">মোট উত্তোলন</div><div class="v">${fmt(wd)}</div></div>
      <div class="stat-card accent"><div class="k">প্রাপ্ত প্রোফিট</div><div class="v">${fmt(pr)}</div></div>
      <div class="stat-card"><div class="k">বর্তমান ব্যালেন্স</div><div class="v">${fmt(bal)}</div></div>
    </div>
    <div class="section-title">নমিনি</div>
    ${nomineeListHtml(m)}
    <div class="section-title">লেনদেনের বিবরণী</div>
    <div id="myStmtOut"></div>
  `;
  renderStatementFor(m.id, 'myStmtOut');
}

/* ================= ACCOUNTING: Chart of Accounts / Journal / Ledger / Trial Balance ================= */
function seedDefaultCOA(){
  if(state.accounts.length>0) return false;
  const accs = [
    {code:'01-001', name:'ক্যাশ ইন হ্যান্ড', groupCode:'01'},
    {code:'01-002', name:'ক্যাশ অ্যাট ব্যাংক', groupCode:'01'},
    {code:'04-001', name:'এফডিআর বিনিয়োগ', groupCode:'04'},
    {code:'10-001', name:'সদস্য সঞ্চয় (প্রদেয়)', groupCode:'10'},
    {code:'13-001', name:'সদস্য শেয়ার/মূলধন', groupCode:'13'},
    {code:'14-001', name:'সাধারণ তহবিল', groupCode:'14'},
    {code:'15-001', name:'এফডিআর সুদ আয়', groupCode:'15'},
    {code:'15-002', name:'সদস্য ফি আয়', groupCode:'15'},
    {code:'17-001', name:'অফিস ভাড়া', groupCode:'17'},
    {code:'17-002', name:'বেতন খরচ', groupCode:'17'},
    {code:'19-001', name:'ব্যাংক চার্জ', groupCode:'19'},
    {code:'17-003', name:'বিবিধ খরচ', groupCode:'17'},
  ].map(a=>{
    const g = accountGroupInfo(a.groupCode);
    return {id:uid(), openingBalance:0, openingSide:g?g.normalBalance:'dr',
      accountType:g?g.accountType:'balance_sheet', normalBalance:g?g.normalBalance:'dr',
      status:'সক্রিয়', ...a};
  });
  state.accounts = accs;
  const cashAcc = accs.find(a=>a.code==='01-001');
  const bankAcc = accs.find(a=>a.code==='01-002');
  const fdrAcc = accs.find(a=>a.code==='04-001');
  state.systemAccountMap = {
    cash: cashAcc ? cashAcc.id : null,
    bank: bankAcc ? bankAcc.id : null,
    fdr: fdrAcc ? fdrAcc.id : null,
  };
  return true;
}
/* Migrates accounts created under the old free-form group/type scheme (before the
   fixed Account Type + numbered Account Group structure) onto the new groupCode
   field, using a best-effort mapping so existing data keeps working. Users should
   review each migrated account's group afterwards for precision. Also backfills
   accountType/normalBalance (now independent, editable fields) for any account —
   old or newly-migrated — that doesn't have them yet, from its group's defaults. */
function migrateLegacyAccounts(){
  let changed = false;
  const legacyMap = {'সম্পদ':'04','দায়':'10','মূলধন':'14','আয়':'15','ব্যয়':'17'};
  state.accounts.forEach(a=>{
    if(!a.groupCode && a.group){
      a.groupCode = legacyMap[a.group] || '04';
      delete a.group;
      delete a.typeId;
      changed = true;
    }
    if(!a.accountType || !a.normalBalance){
      const g = accountGroupInfo(a.groupCode);
      a.accountType = a.accountType || (g?g.accountType:'balance_sheet');
      a.normalBalance = a.normalBalance || (g?g.normalBalance:'dr');
      changed = true;
    }
  });
  if(changed) delete state.accountTypes;
  return changed;
}
function accountLines(accountId){
  const lines = [];
  state.journalEntries.forEach(je=>{
    je.lines.forEach(l=>{
      if(l.accountId===accountId) lines.push({...l, date:je.date, voucherNo:je.voucherNo, narration:je.narration, entryId:je.id});
    });
  });
  return lines.sort((a,b)=>a.date.localeCompare(b.date));
}
function accountBalance(accountId){
  const acc = state.accounts.find(a=>a.id===accountId);
  if(!acc) return 0;
  let bal = Number(acc.openingBalance||0) * (acc.openingSide==='cr' ? -1 : 1);
  accountLines(accountId).forEach(l=>{ bal += Number(l.debit||0) - Number(l.credit||0); });
  return bal; // positive = net debit, negative = net credit
}
function nextVoucherNo(){ return 'JV-'+String(state.journalEntries.length+1).padStart(4,'0'); }

let accSubTab = 'coa';
function renderAccounting(c,fab){
  migrateLegacyAccounts();
  const isNew = seedDefaultCOA();
  if(isNew) saveState();
  c.innerHTML = `
    <div class="page-head"><div><h1>হিসাবরক্ষণ</h1><div class="sub">চার্ট অব একাউন্টস · ডাবল-এন্ট্রি জার্নাল</div></div></div>
    <div class="subtabs">
      <button id="acc_coa" onclick="setAccSub('coa')">চার্ট অব একাউন্টস</button>
      <button id="acc_journal" onclick="setAccSub('journal')">জার্নাল</button>
      <button id="acc_ledger" onclick="setAccSub('ledger')">খতিয়ান</button>
      <button id="acc_trial" onclick="setAccSub('trial')">ট্রায়াল ব্যালেন্স</button>
    </div>
    <div id="accBody"></div>
  `;
  document.getElementById('acc_'+accSubTab).classList.add('active');
  fab.innerHTML='';
  if(accSubTab==='coa') renderCOA(fab);
  else if(accSubTab==='journal') renderJournalList(fab);
  else if(accSubTab==='ledger') renderLedgerTab();
  else renderTrialBalance();
}
function setAccSub(t){ accSubTab=t; renderAccounting(document.getElementById('content'), document.getElementById('fabWrap')); }

/* ---- Chart of Accounts ---- */
function renderCOA(fab){
  const wrap = document.getElementById('accBody');
  const map = state.systemAccountMap || {};
  const mapName = (id)=>{ const a = state.accounts.find(x=>x.id===id); return a ? a.name : 'নির্ধারণ করা হয়নি'; };
  let html = `
    <div class="detail-card" style="margin-top:12px;">
      <div class="row-between" style="margin-bottom:6px;"><div class="title" style="font-weight:700;font-size:13.5px;">সিস্টেম একাউন্ট সংযুক্তি</div>
        <button class="link-btn" onclick="openSystemAccountMapping()">পরিবর্তন করুন</button></div>
      <div class="kv"><span class="k">ড্যাশবোর্ড ক্যাশ ব্যালেন্স ← </span><span class="v">${mapName(map.cash)}</span></div>
      <div class="kv"><span class="k">ড্যাশবোর্ড ব্যাংক ব্যালেন্স ← </span><span class="v">${mapName(map.bank)}</span></div>
      <div class="kv"><span class="k">ড্যাশবোর্ড এফডিআর ← </span><span class="v">${mapName(map.fdr)}</span></div>
    </div>
  `;
  ACCOUNT_TYPES.forEach(atype=>{
    const accsInType = state.accounts.filter(a=>a.accountType===atype.code);
    html += `<div class="section-title" style="margin-top:20px;color:var(--gold);">${atype.name}</div>`;
    if(accsInType.length===0){
      html += `<div class="empty-state" style="padding:16px;"><div class="d">এই ধরনে কোনো একাউন্ট নেই</div></div>`;
    } else {
      // group accounts within this type by their groupCode, in ACCOUNT_GROUPS_DEF order
      ACCOUNT_GROUPS_DEF.forEach(g=>{
        const accs = accsInType.filter(a=>a.groupCode===g.code);
        if(accs.length===0) return;
        html += `<div class="meta" style="margin-top:10px;font-weight:600;">${g.code} · ${g.name}</div>`;
        html += accs.map(a=>{
          const bal = accountBalance(a.id);
          const isDrNormal = isDebitNormal(a);
          const showSide = bal>=0 ? 'ডেবিট' : 'ক্রেডিট';
          return `<div class="list-item" onclick="openLedgerFor('${a.id}')">
            <div class="avatar" style="font-size:10.5px;">${a.code||'-'}</div>
            <div class="body"><div class="title">${a.name}</div><div class="meta">স্বাভাবিক ব্যালেন্স: ${a.normalBalance==='dr'?'ডেবিট':'ক্রেডিট'} ${a.status==='নিষ্ক্রিয়'?'· নিষ্ক্রিয়':''}</div></div>
            <div class="right"><div class="amt ${bal>=0?(isDrNormal?'pos':'neg'):(isDrNormal?'neg':'pos')}">${fmt(Math.abs(bal))}</div><div class="meta">${showSide}</div></div>
          </div>`;
        }).join('');
      });
    }
  });
  wrap.innerHTML = html;
  fab.innerHTML = `<button class="btn block" onclick="openAccountForm()">+ নতুন একাউন্ট</button>`;
}
function accountGroupOptionsHtml(selectedCode){
  return ACCOUNT_TYPES.map(atype=>{
    const groups = ACCOUNT_GROUPS_DEF.filter(g=>g.accountType===atype.code);
    return `<optgroup label="${atype.name}">${groups.map(g=>`<option value="${g.code}" ${g.code===selectedCode?'selected':''}>${g.code} - ${g.name}</option>`).join('')}</optgroup>`;
  }).join('');
}
function openAccountForm(existing){
  const a = existing || {};
  const groupCode = a.groupCode || ACCOUNT_GROUPS_DEF[0].code;
  const g = accountGroupInfo(groupCode);
  const accountType = a.accountType || (g?g.accountType:'balance_sheet');
  const normalBalance = a.normalBalance || (g?g.normalBalance:'dr');
  showSheet(`
    <h2>${existing?'একাউন্ট সম্পাদনা':'নতুন একাউন্ট'}</h2>
    <div class="field-row">
      <div class="field"><label>একাউন্ট কোড</label><input id="ac_code" value="${a.code||''}" placeholder="যেমন 01-001"></div>
      <div class="field"><label>স্ট্যাটাস</label>
        <select id="ac_status"><option ${!a.status||a.status==='সক্রিয়'?'selected':''}>সক্রিয়</option><option ${a.status==='নিষ্ক্রিয়'?'selected':''}>নিষ্ক্রিয়</option></select>
      </div>
    </div>
    <div class="field"><label>একাউন্টের নাম *</label><input id="ac_name" value="${a.name||''}"></div>
    <div class="field"><label>Account Group (একাউন্ট গ্রুপ) *</label>
      <select id="ac_group" onchange="onAccGroupChange()">${accountGroupOptionsHtml(groupCode)}</select>
    </div>
    <div class="field-row">
      <div class="field"><label>Account Type *</label>
        <select id="ac_type">${ACCOUNT_TYPES.map(t=>`<option value="${t.code}" ${t.code===accountType?'selected':''}>${t.name}</option>`).join('')}</select>
      </div>
      <div class="field"><label>Normal Balance *</label>
        <select id="ac_normal"><option value="dr" ${normalBalance==='dr'?'selected':''}>ডেবিট</option><option value="cr" ${normalBalance==='cr'?'selected':''}>ক্রেডিট</option></select>
      </div>
    </div>
    <div class="hint" style="margin-top:0;">Account Group বেছে নিলে Account Type ও Normal Balance স্বয়ংক্রিয়ভাবে একটা প্রস্তাবিত মান বসাবে — প্রয়োজনে সেটা নিজে বদলেও নিতে পারবেন।</div>
    <div class="field-row" style="margin-top:12px;">
      <div class="field"><label>ওপেনিং ব্যালেন্স (৳)</label><input type="number" id="ac_opening" value="${a.openingBalance||0}"></div>
      <div class="field"><label>ধরন</label>
        <select id="ac_openingSide"><option value="dr" ${(!a.openingSide||a.openingSide==='dr')?'selected':''}>ডেবিট</option><option value="cr" ${a.openingSide==='cr'?'selected':''}>ক্রেডিট</option></select>
      </div>
    </div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn" onclick="saveAccount('${existing?existing.id:''}')">সংরক্ষণ করুন</button>
    </div>
  `);
}
function onAccGroupChange(){
  const groupCode = document.getElementById('ac_group').value;
  const g = accountGroupInfo(groupCode);
  if(!g) return;
  document.getElementById('ac_type').value = g.accountType;
  document.getElementById('ac_normal').value = g.normalBalance;
}
async function saveAccount(id){
  const name = document.getElementById('ac_name').value.trim();
  const groupCode = document.getElementById('ac_group').value;
  const accountType = document.getElementById('ac_type').value;
  const normalBalance = document.getElementById('ac_normal').value;
  if(!name){ toast('একাউন্টের নাম আবশ্যক'); return; }
  const data = {
    code: document.getElementById('ac_code').value,
    name, groupCode, accountType, normalBalance,
    openingBalance: Number(document.getElementById('ac_opening').value)||0,
    openingSide: document.getElementById('ac_openingSide').value,
    status: document.getElementById('ac_status').value,
  };
  const prevAccounts = JSON.parse(JSON.stringify(state.accounts));
  if(id){
    const idx = state.accounts.findIndex(x=>x.id===id);
    state.accounts[idx] = {...state.accounts[idx], ...data};
  } else {
    data.id = uid();
    state.accounts.push(data);
  }
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.accounts = prevAccounts; }); if(!proceed) return; }
  closeSheet(); renderAccounting(document.getElementById('content'), document.getElementById('fabWrap'));
  toast('একাউন্ট সংরক্ষিত হয়েছে');
}
function openSystemAccountMapping(){
  const map = state.systemAccountMap || {};
  showSheet(`
    <h2>সিস্টেম একাউন্ট সংযুক্তি</h2>
    <div class="hint" style="margin-top:0;">এখানে যে একাউন্ট বেছে নেবেন, সেই একাউন্টে জার্নাল এন্ট্রি দিলে তা ড্যাশবোর্ডের ক্যাশ/ব্যাংক/এফডিআর ব্যালেন্স ও রিপোর্টে সরাসরি এফেক্ট করবে।</div>
    <div class="field"><label>ক্যাশ ব্যালেন্সের একাউন্ট</label>
      <select id="map_cash"><option value="">-- নির্ধারণ করা নেই --</option>${accountOptionsHtml(map.cash)}</select>
    </div>
    <div class="field"><label>ব্যাংক ব্যালেন্সের একাউন্ট</label>
      <select id="map_bank"><option value="">-- নির্ধারণ করা নেই --</option>${accountOptionsHtml(map.bank)}</select>
    </div>
    <div class="field"><label>এফডিআর ব্যালেন্সের একাউন্ট</label>
      <select id="map_fdr"><option value="">-- নির্ধারণ করা নেই --</option>${accountOptionsHtml(map.fdr)}</select>
    </div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn" onclick="saveSystemAccountMapping()">সংরক্ষণ করুন</button>
    </div>
  `);
}
async function saveSystemAccountMapping(){
  const prevMap = {...state.systemAccountMap};
  state.systemAccountMap = {
    cash: document.getElementById('map_cash').value || null,
    bank: document.getElementById('map_bank').value || null,
    fdr: document.getElementById('map_fdr').value || null,
  };
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.systemAccountMap = prevMap; }); if(!proceed) return; }
  closeSheet(); renderAccounting(document.getElementById('content'), document.getElementById('fabWrap'));
  toast('সংযুক্তি সংরক্ষিত হয়েছে');
}

/* ---- Journal (double-entry vouchers) ---- */
function renderJournalList(fab){
  const wrap = document.getElementById('accBody');
  const entries = [...state.journalEntries].sort((a,b)=>b.date.localeCompare(a.date));
  if(entries.length===0){
    wrap.innerHTML = `<div class="empty-state"><div class="icon">📗</div><div class="t">কোনো জার্নাল এন্ট্রি নেই</div><div class="d">ডাবল-এন্ট্রি ভাউচার যোগ করুন — মোট ডেবিট ও ক্রেডিট সমান হতে হবে</div></div>`;
  } else {
    wrap.innerHTML = entries.map(je=>{
      const total = je.lines.reduce((a,l)=>a+Number(l.debit||0),0);
      return `<div class="list-item" onclick="openJournalDetail('${je.id}')">
        <div class="avatar">জ</div>
        <div class="body"><div class="title">${je.voucherNo}</div><div class="meta">${fmtDate(je.date)} · ${je.narration||''}</div></div>
        <div class="right"><div class="amt pos">${fmt(total)}</div><div class="meta">${je.lines.length} লাইন</div></div>
      </div>`;
    }).join('');
  }
  fab.innerHTML = `<button class="btn block" onclick="openJournalForm()">+ নতুন জার্নাল এন্ট্রি</button>`;
}
function openJournalDetail(id){
  const je = state.journalEntries.find(x=>x.id===id);
  if(!je) return;
  const totalDr = je.lines.reduce((a,l)=>a+Number(l.debit||0),0);
  const totalCr = je.lines.reduce((a,l)=>a+Number(l.credit||0),0);
  showSheet(`
    <h2>${je.voucherNo}</h2>
    <div class="detail-card" style="margin-top:0;">
      <div class="kv"><span class="k">তারিখ</span><span class="v">${fmtDate(je.date)}</span></div>
      <div class="kv"><span class="k">বিবরণ</span><span class="v">${je.narration||'-'}</span></div>
    </div>
    <table class="stmt">
      <tr><th>একাউন্ট</th><th>ডেবিট</th><th>ক্রেডিট</th></tr>
      ${je.lines.map(l=>{
        const acc = state.accounts.find(a=>a.id===l.accountId);
        return `<tr><td style="text-align:right">${acc?acc.name:'-'}</td><td>${l.debit?fmt(l.debit):''}</td><td>${l.credit?fmt(l.credit):''}</td></tr>`;
      }).join('')}
      <tr><td style="text-align:right;font-weight:700;">মোট</td><td>${fmt(totalDr)}</td><td>${fmt(totalCr)}</td></tr>
    </table>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বন্ধ করুন</button>
      <button class="btn" style="background:var(--danger);" onclick="deleteJournalEntry('${je.id}')">এন্ট্রি মুছুন</button>
    </div>
  `);
}
async function deleteJournalEntry(id){
  if(!confirm('এই জার্নাল এন্ট্রিটি মুছে ফেলতে চান? এটি সংশ্লিষ্ট একাউন্টের ব্যালেন্স পরিবর্তন করবে।')) return;
  const prevEntries = state.journalEntries;
  state.journalEntries = state.journalEntries.filter(x=>x.id!==id);
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.journalEntries = prevEntries; }); if(!proceed) return; }
  closeSheet(); renderAccounting(document.getElementById('content'), document.getElementById('fabWrap'));
  toast('জার্নাল এন্ট্রি মুছে ফেলা হয়েছে');
}
let journalLineCount = 0;
function accountOptionsHtml(selectedId){
  if(state.accounts.length===0) return '<option value="">প্রথমে একাউন্ট যোগ করুন</option>';
  return ACCOUNT_GROUPS_DEF.map(g=>{
    const accs = state.accounts.filter(a=>a.groupCode===g.code && a.status!=='নিষ্ক্রিয়');
    if(accs.length===0) return '';
    return `<optgroup label="${g.code} - ${g.name}">${accs.map(a=>`<option value="${a.id}" ${a.id===selectedId?'selected':''}>${a.code?a.code+' - ':''}${a.name}</option>`).join('')}</optgroup>`;
  }).join('');
}
function openJournalForm(){
  if(state.accounts.length<2){ toast('জার্নাল এন্ট্রি দিতে অন্তত ২টি একাউন্ট থাকা দরকার'); return; }
  journalLineCount = 0;
  showSheet(`
    <h2>নতুন জার্নাল এন্ট্রি</h2>
    <div class="field-row">
      <div class="field"><label>ভাউচার নং</label><input id="jv_no" value="${nextVoucherNo()}"></div>
      <div class="field"><label>তারিখ</label><input type="date" id="jv_date" value="${todayISO()}"></div>
    </div>
    <div class="field"><label>বিবরণ / Narration</label><input id="jv_narration" placeholder="এই এন্ট্রির কারণ লিখুন"></div>
    <div class="section-title" style="margin-top:14px;">এন্ট্রি লাইন</div>
    <div id="jvLines"></div>
    <button class="link-btn" style="margin-top:6px;" onclick="addJournalLine()">+ আরেকটি লাইন যোগ করুন</button>
    <div class="receipt-preview" style="margin-top:14px;">
      <div class="rline"><span>মোট ডেবিট</span><span id="jv_totalDr" style="font-weight:700;">৳০</span></div>
      <div class="rline"><span>মোট ক্রেডিট</span><span id="jv_totalCr" style="font-weight:700;">৳০</span></div>
      <div class="rline"><span>অবস্থা</span><span id="jv_status" style="font-weight:700;">—</span></div>
    </div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn" onclick="saveJournalEntry()">সংরক্ষণ করুন</button>
    </div>
  `);
  addJournalLine(); addJournalLine();
}
function addJournalLine(){
  const id = 'jvl_'+(journalLineCount++);
  const wrap = document.getElementById('jvLines');
  const row = document.createElement('div');
  row.className = 'field-row';
  row.id = id;
  row.style.alignItems = 'flex-end';
  row.innerHTML = `
    <div class="field" style="flex:2;"><label>একাউন্ট</label><select onchange="updateJournalTotals()">${accountOptionsHtml()}</select></div>
    <div class="field"><label>ডেবিট</label><input type="number" oninput="onJvAmountInput(this,'debit')"></div>
    <div class="field"><label>ক্রেডিট</label><input type="number" oninput="onJvAmountInput(this,'credit')"></div>
    <button class="link-btn" style="color:var(--danger);margin-bottom:12px;" onclick="removeJournalLine('${id}')">✕</button>
  `;
  wrap.appendChild(row);
  updateJournalTotals();
}
function onJvAmountInput(input, kind){
  // typing a debit clears credit on the same line and vice versa (a line is either Dr or Cr)
  const row = input.closest('.field-row');
  const inputs = row.querySelectorAll('input[type=number]');
  if(input.value && Number(input.value)>0){
    inputs.forEach(i=>{ if(i!==input) i.value=''; });
  }
  updateJournalTotals();
}
function removeJournalLine(id){
  const el = document.getElementById(id);
  if(el) el.remove();
  updateJournalTotals();
}
function updateJournalTotals(){
  const wrap = document.getElementById('jvLines');
  if(!wrap) return;
  let totalDr=0, totalCr=0;
  wrap.querySelectorAll('.field-row').forEach(row=>{
    const inputs = row.querySelectorAll('input[type=number]');
    totalDr += Number(inputs[0].value)||0;
    totalCr += Number(inputs[1].value)||0;
  });
  document.getElementById('jv_totalDr').textContent = fmt(totalDr);
  document.getElementById('jv_totalCr').textContent = fmt(totalCr);
  const statusEl = document.getElementById('jv_status');
  const balanced = totalDr>0 && totalDr===totalCr;
  statusEl.textContent = balanced ? '✅ মিলেছে (Balanced)' : '⚠️ মিলছে না';
  statusEl.style.color = balanced ? 'var(--primary)' : 'var(--danger)';
}
async function saveJournalEntry(){
  const voucherNo = document.getElementById('jv_no').value.trim() || nextVoucherNo();
  const date = document.getElementById('jv_date').value || todayISO();
  const narration = document.getElementById('jv_narration').value;
  const rows = Array.from(document.getElementById('jvLines').querySelectorAll('.field-row'));
  const lines = [];
  for(const row of rows){
    const select = row.querySelector('select');
    const inputs = row.querySelectorAll('input[type=number]');
    const accountId = select.value;
    const debit = Number(inputs[0].value)||0;
    const credit = Number(inputs[1].value)||0;
    if(!accountId || (debit===0 && credit===0)) continue;
    lines.push({accountId, debit, credit});
  }
  if(lines.length<2){ toast('অন্তত ২টি এন্ট্রি লাইন পূরণ করুন'); return; }
  const totalDr = lines.reduce((a,l)=>a+l.debit,0);
  const totalCr = lines.reduce((a,l)=>a+l.credit,0);
  if(totalDr!==totalCr || totalDr===0){ toast('⚠️ মোট ডেবিট ও ক্রেডিট সমান হতে হবে'); return; }
  const entry = {id:uid(), voucherNo, date, narration, lines};
  state.journalEntries.push(entry);
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.journalEntries.pop(); }); if(!proceed) return; }
  closeSheet(); renderAccounting(document.getElementById('content'), document.getElementById('fabWrap'));
  toast('জার্নাল এন্ট্রি সংরক্ষিত হয়েছে');
}

/* ---- Ledger ---- */
function renderLedgerTab(){
  const wrap = document.getElementById('accBody');
  wrap.innerHTML = `
    <div class="field" style="margin-top:12px;"><label>একাউন্ট নির্বাচন করুন</label>
      <select id="ledgerAccSelect" onchange="renderLedgerFor(this.value)">
        <option value="">-- একাউন্ট নির্বাচন করুন --</option>
        ${accountOptionsHtml()}
      </select>
    </div>
    <div id="ledgerOut"></div>
  `;
}
function openLedgerFor(accountId){
  accSubTab='ledger';
  renderAccounting(document.getElementById('content'), document.getElementById('fabWrap'));
  document.getElementById('ledgerAccSelect').value = accountId;
  renderLedgerFor(accountId);
}
function renderLedgerFor(accountId){
  const out = document.getElementById('ledgerOut');
  if(!accountId){ out.innerHTML=''; return; }
  const acc = state.accounts.find(a=>a.id===accountId);
  if(!acc){ out.innerHTML=''; return; }
  const lines = accountLines(accountId);
  let bal = Number(acc.openingBalance||0) * (acc.openingSide==='cr' ? -1 : 1);
  const rows = [{date:acc.openingBalance?'':'','label':'ওপেনিং ব্যালেন্স','debit':acc.openingSide==='dr'?acc.openingBalance:0,'credit':acc.openingSide==='cr'?acc.openingBalance:0,running:bal, isOpening:true}];
  lines.forEach(l=>{
    bal += Number(l.debit||0) - Number(l.credit||0);
    rows.push({date:l.date, label:l.narration||l.voucherNo, debit:l.debit, credit:l.credit, running:bal});
  });
  const g = accountGroupInfo(acc.groupCode);
  const isDrNormal = isDebitNormal(acc);
  out.innerHTML = `
    <div class="detail-card" style="margin-top:12px;">
      <div class="row-between"><div class="title" style="font-weight:700;">${acc.name}</div><div class="amt ${bal>=0?(isDrNormal?'pos':'neg'):(isDrNormal?'neg':'pos')}">${fmt(Math.abs(bal))} ${bal>=0?'ডেবিট':'ক্রেডিট'}</div></div>
      <div class="meta">${acc.code||''} · ${g?g.name:''} · ${accountTypeLabel(acc.accountType)}</div>
    </div>
    <table class="stmt">
      <tr><th>তারিখ</th><th>বিবরণ</th><th>ডেবিট</th><th>ক্রেডিট</th><th>ব্যালেন্স</th></tr>
      ${rows.map(r=>`<tr>
        <td>${r.isOpening?'-':fmtDate(r.date)}</td><td>${r.label}</td>
        <td>${r.debit?fmt(r.debit):''}</td><td>${r.credit?fmt(r.credit):''}</td>
        <td>${fmt(Math.abs(r.running))} ${r.running>=0?'Dr':'Cr'}</td>
      </tr>`).join('')}
    </table>
  `;
}

/* ---- Trial Balance ---- */
function renderTrialBalance(){
  const wrap = document.getElementById('accBody');
  if(state.accounts.length===0){
    wrap.innerHTML = `<div class="empty-state"><div class="d">কোনো একাউন্ট নেই</div></div>`;
    return;
  }
  let totalDr=0, totalCr=0;
  const rows = state.accounts.map(a=>{
    const bal = accountBalance(a.id);
    const dr = bal>=0 ? bal : 0;
    const cr = bal<0 ? -bal : 0;
    totalDr += dr; totalCr += cr;
    return {a, dr, cr};
  });
  wrap.innerHTML = `
    <table class="stmt" style="margin-top:14px;">
      <tr><th>একাউন্ট</th><th>ডেবিট</th><th>ক্রেডিট</th></tr>
      ${rows.map(r=>`<tr><td style="text-align:right">${r.a.code?r.a.code+' - ':''}${r.a.name}</td><td>${r.dr?fmt(r.dr):''}</td><td>${r.cr?fmt(r.cr):''}</td></tr>`).join('')}
      <tr><td style="text-align:right;font-weight:700;">সর্বমোট</td><td>${fmt(totalDr)}</td><td>${fmt(totalCr)}</td></tr>
    </table>
    <div class="hint" style="margin-top:10px;color:${totalDr===totalCr?'var(--primary)':'var(--danger)'};">
      ${totalDr===totalCr ? '✅ ট্রায়াল ব্যালেন্স মিলেছে (ডেবিট = ক্রেডিট)' : '⚠️ ট্রায়াল ব্যালেন্স মিলছে না — জার্নাল এন্ট্রি পরীক্ষা করুন'}
    </div>
  `;
}

function switchTab(t){ activeTab=t; renderAll(); window.scrollTo(0,0); }
function renderTopStrip(){
  const t = totals();
  document.getElementById('orgNameDisplay').firstChild.textContent = state.orgName;
  document.getElementById('chipCash').textContent = fmt(t.cashBalance);
  document.getElementById('chipBank').textContent = fmt(t.bankBalance);
  document.getElementById('chipFdr').textContent = fmt(t.fdrPrincipal + t.fdrAccrued);
  const banner = document.getElementById('offlineBanner');
  if(offlineMode){
    banner.style.display='flex';
    banner.innerHTML = `<span>⚠️ সংরক্ষণ কাজ করছে না — ডেটা শুধু এই সেশনে আছে। বন্ধ করার আগে ব্যাকআপ নিন।</span><button onclick="retryReconnect()">আবার চেষ্টা</button>`;
  } else {
    banner.style.display='none'; banner.innerHTML='';
  }
}
async function retryReconnect(){
  offlineMode = false;
  toast('সংযোগ পরীক্ষা করা হচ্ছে…');
  const ok = await saveState();
  if(ok){ toast('✅ সংযোগ পুনরুদ্ধার হয়েছে, ডেটা সংরক্ষিত হয়েছে'); renderTopStrip(); }
  else { offlineMode = true; toast('⚠️ এখনও সংযোগ পাওয়া যাচ্ছে না'); renderTopStrip(); }
}

/* ---------------- DASHBOARD ---------------- */
function renderDashboard(c){
  const t = totals();
  const todayDep = postedTxs().filter(x=>x.type==='deposit' && x.date===todayISO()).reduce((a,b)=>a+b.amount,0);
  const distributable = state.profitRuns.length ? state.profitRuns[state.profitRuns.length-1].totalProfit : 0;
  c.innerHTML = `
    <div class="page-head"><div><h1>ড্যাশবোর্ড</h1><div class="sub">${fmtDate(todayISO())}</div></div></div>
    <div class="stat-grid">
      <div class="stat-card"><div class="k">মোট সদস্য</div><div class="v">${state.members.length}</div></div>
      <div class="stat-card"><div class="k">আজকের জমা</div><div class="v">${fmt(todayDep)}</div></div>
      <div class="stat-card"><div class="k">মোট জমা</div><div class="v">${fmt(t.totalDeposit)}</div></div>
      <div class="stat-card danger"><div class="k">মোট খরচ</div><div class="v">${fmt(t.totalExpense)}</div></div>
      <div class="stat-card"><div class="k">মোট উত্তোলন</div><div class="v">${fmt(t.totalWithdrawal)}</div></div>
      <div class="stat-card accent"><div class="k">এফডিআর মুনাফা (আনুমানিক)</div><div class="v">${fmt(t.fdrAccrued)}</div></div>
      <div class="stat-card wide accent"><div><div class="k">সদস্যদের প্রাপ্য মোট প্রোফিট</div><div class="v">${fmt(t.totalProfitPaid)}</div></div>
        <button class="btn sm ghost" onclick="switchTab('profit')">বিস্তারিত</button></div>
    </div>
    <div class="section-title">সাম্প্রতিক লেনদেন</div>
    ${recentTxHtml()}
  `;
}
function recentTxHtml(){
  const all = [...postedTxs().map(t=>({...t, kind:'tx'})), ...state.expenses.map(e=>({...e, kind:'exp', type:'expense'}))]
    .sort((a,b)=> b.date.localeCompare(a.date)).slice(0,6);
  if(all.length===0) return `<div class="empty-state"><div class="icon">🧾</div><div class="t">এখনো কোনো লেনদেন নেই</div><div class="d">জমা, উত্তোলন বা খরচ যোগ করলে এখানে দেখা যাবে</div></div>`;
  return all.map(t=>{
    if(t.kind==='exp'){
      return `<div class="list-item"><div class="avatar" style="background:var(--danger-tint);color:var(--danger)">খ</div>
        <div class="body"><div class="title">${t.head}</div><div class="meta">${fmtDate(t.date)} · খরচ</div></div>
        <div class="right"><div class="amt neg">-${fmt(t.amount)}</div></div></div>`;
    }
    const m = state.members.find(x=>x.id===t.memberId);
    const label = t.type==='deposit'?'জমা': t.type==='withdrawal'?'উত্তোলন':'প্রোফিট';
    const cls = t.type==='withdrawal' ? 'neg':'pos';
    const sign = t.type==='withdrawal' ? '-' : '+';
    return `<div class="list-item"><div class="avatar">${initials(m?m.name:'?')}</div>
      <div class="body"><div class="title">${m?m.name:'অজানা সদস্য'}</div><div class="meta">${fmtDate(t.date)} · ${label}</div></div>
      <div class="right"><div class="amt ${cls}">${sign}${fmt(t.amount)}</div></div></div>`;
  }).join('');
}

/* ---------------- MEMBERS ---------------- */
let memberSearchQuery = '';
function renderMembers(c,fab){
  c.innerHTML = `
    <div class="page-head"><div><h1>সদস্য</h1><div class="sub" id="memberCountSub">${state.members.length} জন সদস্য</div></div></div>
    <div class="search-bar">
      <input id="memberSearch" type="search" placeholder="🔍 নাম, Member ID, মোবাইল বা NID দিয়ে খুঁজুন" value="${memberSearchQuery.replace(/"/g,'&quot;')}" oninput="onMemberSearch(this.value)" autocomplete="off">
    </div>
    <div id="memberList"></div>
  `;
  renderMemberList();
  fab.innerHTML = `<button class="btn block" onclick="openMemberForm()">+ নতুন সদস্য যোগ করুন</button>`;
}
function onMemberSearch(q){
  memberSearchQuery = q;
  renderMemberList();
}
function memberMatches(m, q){
  const hay = [m.name, m.customId, m.mobile, m.nid, m.fatherHusband].filter(Boolean).join(' ').toLowerCase();
  return q.toLowerCase().split(/\s+/).filter(Boolean).every(part=>hay.includes(part));
}
function renderMemberList(){
  const list = document.getElementById('memberList');
  if(!list) return;
  const q = memberSearchQuery.trim();
  const sub = document.getElementById('memberCountSub');
  if(state.members.length===0){
    list.innerHTML = `<div class="empty-state"><div class="icon">👥</div><div class="t">কোনো সদস্য যোগ করা হয়নি</div><div class="d">নিচের বাটনে চাপ দিয়ে প্রথম সদস্য যোগ করুন</div></div>`;
    return;
  }
  const shown = q ? state.members.filter(m=>memberMatches(m,q)) : state.members;
  if(sub) sub.textContent = q ? `${shown.length} জন পাওয়া গেছে (মোট ${state.members.length} জন)` : `${state.members.length} জন সদস্য`;
  if(shown.length===0){
    list.innerHTML = `<div class="empty-state"><div class="icon">🔍</div><div class="t">কোনো সদস্য পাওয়া যায়নি</div><div class="d">অন্য নাম, আইডি বা মোবাইল নম্বর দিয়ে চেষ্টা করুন</div></div>`;
    return;
  }
  list.innerHTML = shown.map(m=>{
    const bal = memberBalance(m.id);
    return `<div class="list-item" onclick="openMemberDetail('${m.id}')">
      <div class="avatar-wrap" onclick="event.stopPropagation(); quickMemberPhoto('${m.id}')">
        ${m.photo?`<img src="${m.photo}" class="avatar-photo">`:`<div class="avatar">${initials(m.name)}</div>`}
        <span class="cam-badge">📷</span>
      </div>
      <div class="body"><div class="title">${m.name}</div><div class="meta">${m.customId?m.customId+' · ':''}${m.mobile||'মোবাইল নেই'} · ${m.status||'সক্রিয়'}</div></div>
      <div class="right"><div class="amt pos">${fmt(bal)}</div><div class="meta">ব্যালেন্স</div></div>
    </div>`;
  }).join('');
}
function quickMemberPhoto(memberId, fromDetail){
  window._quickPhotoMemberId = memberId;
  window._quickPhotoFromDetail = !!fromDetail;
  document.getElementById('quickMemberPhotoInput').value = '';
  document.getElementById('quickMemberPhotoInput').click();
}
function handleQuickMemberPhoto(input){
  const file = input.files && input.files[0];
  const memberId = window._quickPhotoMemberId;
  if(!file || !memberId) return;
  toast('⏳ ছবি প্রসেস হচ্ছে…');
  resizeImageToDataURL(file, 300,
    async (dataUrl)=>{
      const m = state.members.find(x=>x.id===memberId);
      if(!m) return;
      const prevPhoto = m.photo;
      m.photo = dataUrl;
      const ok = await saveState();
      if(!ok){ const proceed = offerOfflineContinue(()=>{ m.photo = prevPhoto; }); if(!proceed) return; }
      if(window._quickPhotoFromDetail) openMemberDetail(memberId); else renderAll();
      toast('✅ ছবি সংরক্ষিত হয়েছে');
    },
    (errMsg)=>{ toast('⚠️ '+errMsg); }
  );
}
function openMemberForm(existing){
  const m = existing || {};
  window._tmpMemberPhoto = m.photo || null;
  window._tmpMemberSignature = m.signature || null;
  showSheet(`
    <h2>${existing?'সদস্য সম্পাদনা':'নতুন সদস্য'}</h2>
    <div class="photo-row">
      <div class="photo-upload">
        <label id="f_photoLabel" for="f_photo">${m.photo?`<img src="${m.photo}">`:'📷 ছবি'}</label>
        <input type="file" id="f_photo" accept="image/*" onchange="onMemberPhotoChange(this)">
      </div>
      <div class="field" style="flex:1;margin-bottom:0;"><label>Member ID</label><input id="f_customId" value="${m.customId||''}" placeholder="যেমন M-001"></div>
    </div>
    <div class="field" style="margin-top:12px;"><label>নাম *</label><input id="f_name" value="${m.name||''}"></div>
    <div class="field-row">
      <div class="field"><label>পিতা/স্বামীর নাম</label><input id="f_father" value="${m.fatherHusband||''}"></div>
      <div class="field"><label>মাতা</label><input id="f_mother" value="${m.mother||''}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>জন্মতারিখ</label><input type="date" id="f_dob" value="${m.dob||''}"></div>
      <div class="field"><label>NID</label><input id="f_nid" value="${m.nid||''}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>মোবাইল</label><input id="f_mobile" value="${m.mobile||''}"></div>
      <div class="field"><label>পেশা</label><input id="f_occ" value="${m.occupation||''}"></div>
    </div>
    <div class="field"><label>ঠিকানা</label><input id="f_address" value="${m.address||''}"></div>
    <div class="field-row">
      <div class="field"><label>যোগদানের তারিখ</label><input type="date" id="f_join" value="${m.joinDate||todayISO()}"></div>
      <div class="field"><label>স্ট্যাটাস</label>
        <select id="f_status">
          <option ${m.status==='সক্রিয়'||!m.status?'selected':''}>সক্রিয়</option>
          <option ${m.status==='নিষ্ক্রিয়'?'selected':''}>নিষ্ক্রিয়</option>
        </select>
      </div>
    </div>
    <div class="field"><label>স্বাক্ষর</label>
      <div class="sig-upload">
        <label id="f_sigLabel" for="f_signature">${m.signature?`<img src="${m.signature}">`:'স্বাক্ষরের ছবি আপলোড করুন'}</label>
        <input type="file" id="f_signature" accept="image/*" onchange="onMemberSignatureChange(this)">
      </div>
    </div>
    <div class="field"><label>অন্যান্য তথ্য</label><textarea id="f_other">${m.otherInfo||''}</textarea></div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn" onclick="saveMember('${existing?existing.id:''}')">সংরক্ষণ করুন</button>
    </div>
  `);
}
function onMemberPhotoChange(input){
  const file = input.files && input.files[0];
  if(!file) return;
  const label = document.getElementById('f_photoLabel');
  const original = label.innerHTML;
  label.innerHTML = '⏳';
  resizeImageToDataURL(file, 300,
    (dataUrl)=>{
      window._tmpMemberPhoto = dataUrl;
      label.innerHTML = `<img src="${dataUrl}">`;
    },
    (errMsg)=>{
      label.innerHTML = original;
      toast('⚠️ '+errMsg);
      input.value='';
    }
  );
}
function onMemberSignatureChange(input){
  const file = input.files && input.files[0];
  if(!file) return;
  const label = document.getElementById('f_sigLabel');
  const original = label.innerHTML;
  label.innerHTML = 'প্রসেস হচ্ছে…';
  resizeImageToDataURL(file, 400,
    (dataUrl)=>{
      window._tmpMemberSignature = dataUrl;
      label.innerHTML = `<img src="${dataUrl}">`;
    },
    (errMsg)=>{
      label.innerHTML = original;
      toast('⚠️ '+errMsg);
      input.value='';
    }
  );
}
async function saveMember(id){
  const name = document.getElementById('f_name').value.trim();
  if(!name){ toast('নাম আবশ্যক'); return; }
  const data = {
    name,
    customId: document.getElementById('f_customId').value,
    photo: window._tmpMemberPhoto || null,
    fatherHusband: document.getElementById('f_father').value,
    mother: document.getElementById('f_mother').value,
    dob: document.getElementById('f_dob').value,
    mobile: document.getElementById('f_mobile').value,
    nid: document.getElementById('f_nid').value,
    address: document.getElementById('f_address').value,
    joinDate: document.getElementById('f_join').value,
    occupation: document.getElementById('f_occ').value,
    status: document.getElementById('f_status').value,
    signature: window._tmpMemberSignature || null,
    otherInfo: document.getElementById('f_other').value,
  };
  const prevMembers = JSON.parse(JSON.stringify(state.members));
  if(id){
    const idx = state.members.findIndex(x=>x.id===id);
    state.members[idx] = {...state.members[idx], ...data};
  } else {
    data.id = uid(); data.nominees = [];
    state.members.push(data);
  }
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.members = prevMembers; }); if(!proceed) return; }
  closeSheet(); renderAll();
  toast('সদস্য সংরক্ষিত হয়েছে');
}
function openMemberDetail(id){
  const m = state.members.find(x=>x.id===id);
  if(!m) return;
  const dep=memberDeposit(id), wd=memberWithdrawal(id), pr=memberProfit(id), bal=memberBalance(id);
  const share = memberCategoryBalance(id, 'শেয়ার/মূলধন');
  const fdrBal = memberCategoryBalance(id, 'এফডিআর');
  const c = document.getElementById('content');
  const fab = document.getElementById('fabWrap');
  c.innerHTML = `
    <div class="page-head">
      <div><h1>${m.name}</h1><div class="sub">সদস্য বিস্তারিত ${m.customId?'· '+m.customId:''}</div></div>
      <button class="link-btn" onclick="renderMembers(document.getElementById('content'), document.getElementById('fabWrap'))">← তালিকা</button>
    </div>
    <div class="detail-card">
      <div class="row-between" style="margin-bottom:10px;">
        <div class="avatar-wrap" onclick="quickMemberPhoto('${id}', true)">
          ${m.photo?`<img src="${m.photo}" class="avatar-photo lg">`:`<div class="avatar" style="width:52px;height:52px;font-size:18px;">${initials(m.name)}</div>`}
          <span class="cam-badge">📷</span>
        </div>
        <span class="tag ${m.status==='নিষ্ক্রিয়'?'red':''}" style="margin:0;">${m.status||'সক্রিয়'}</span>
      </div>
      <div class="kv"><span class="k">Member ID</span><span class="v">${m.customId || m.id.slice(0,6).toUpperCase()}</span></div>
      <div class="kv"><span class="k">মোবাইল</span><span class="v">${m.mobile||'-'}</span></div>
      <div class="kv"><span class="k">পিতা/স্বামী</span><span class="v">${m.fatherHusband||'-'}</span></div>
      <div class="kv"><span class="k">মাতা</span><span class="v">${m.mother||'-'}</span></div>
      <div class="kv"><span class="k">জন্মতারিখ</span><span class="v">${m.dob?fmtDate(m.dob):'-'}</span></div>
      <div class="kv"><span class="k">NID</span><span class="v">${m.nid||'-'}</span></div>
      <div class="kv"><span class="k">পেশা</span><span class="v">${m.occupation||'-'}</span></div>
      <div class="kv"><span class="k">ঠিকানা</span><span class="v">${m.address||'-'}</span></div>
      <div class="kv"><span class="k">যোগদান</span><span class="v">${fmtDate(m.joinDate)}</span></div>
      ${m.otherInfo?`<div class="kv"><span class="k">অন্যান্য তথ্য</span><span class="v">${m.otherInfo}</span></div>`:''}
      ${m.signature?`<div style="margin-top:10px;"><div class="k" style="font-size:12px;color:var(--muted);margin-bottom:4px;">স্বাক্ষর</div><img src="${m.signature}" style="max-height:50px;max-width:160px;"></div>`:''}
    </div>
    <div class="section-title">Financial Summary</div>
    <div class="stat-grid">
      <div class="stat-card"><div class="k">মোট জমা</div><div class="v">${fmt(dep)}</div></div>
      <div class="stat-card danger"><div class="k">মোট উত্তোলন</div><div class="v">${fmt(wd)}</div></div>
      <div class="stat-card"><div class="k">শেয়ার/মূলধন</div><div class="v">${fmt(share)}</div></div>
      <div class="stat-card"><div class="k">এফডিআর ব্যালেন্স</div><div class="v">${fmt(fdrBal)}</div></div>
      <div class="stat-card accent"><div class="k">প্রোফিট অর্জিত</div><div class="v">${fmt(pr)}</div></div>
      <div class="stat-card accent"><div class="k">প্রোফিট প্রদত্ত</div><div class="v">${fmt(pr)}</div></div>
      <div class="stat-card wide"><div class="k">নেট ব্যালেন্স</div><div class="v">${fmt(bal)}</div></div>
    </div>
    <div class="row-between" style="margin-top:22px;">
      <div class="section-title" style="margin:0;">নমিনি</div>
      <button class="link-btn" onclick="openNomineeForm('${id}')">+ নমিনি যোগ</button>
    </div>
    ${nomineeListHtml(m)}
    <div style="margin-top:20px;display:flex;gap:10px;">
      <button class="btn ghost" style="flex:1" onclick="openMemberForm(state.members.find(x=>x.id==='${id}'))">তথ্য সম্পাদনা</button>
      <button class="btn" style="flex:1" onclick="switchTab('transactions'); setTimeout(()=>openTxForm('deposit','${id}'),0)">জমা যোগ করুন</button>
    </div>
    <button class="link-btn" style="margin-top:16px" onclick="openMemberStatement('${id}')">সম্পূর্ণ স্টেটমেন্ট দেখুন →</button>
  `;
  fab.innerHTML='';
}
function nomineeListHtml(m){
  if(!m.nominees || m.nominees.length===0){
    return `<div class="empty-state" style="padding:20px;"><div class="d">কোনো নমিনি যোগ করা হয়নি</div></div>`;
  }
  return m.nominees.map(n=>`<div class="list-item">
    ${n.photo?`<img src="${n.photo}" class="avatar-photo">`:`<div class="avatar" style="background:var(--gold-tint);color:var(--gold)">${initials(n.name)}</div>`}
    <div class="body"><div class="title">${n.name}</div><div class="meta">${n.relation||''} · ${n.mobile||''}</div>
      <span class="tag ${n.status==='নিষ্ক্রিয়'?'red':'gold'}">${n.status||'সক্রিয়'}</span></div>
    <div class="right"><div class="amt" style="color:var(--gold)">${n.percent||0}%</div></div>
  </div>`).join('');
}
function openNomineeForm(memberId){
  window._tmpNomineePhoto = null;
  window._tmpNomineeNidCopy = null;
  showSheet(`
    <h2>নতুন নমিনি</h2>
    <div class="photo-row">
      <div class="photo-upload">
        <label id="nm_photoLabel" for="n_photo">📷 ছবি</label>
        <input type="file" id="n_photo" accept="image/*" onchange="onNomineePhotoChange(this)">
      </div>
      <div class="field" style="flex:1;margin-bottom:0;"><label>নাম *</label><input id="n_name"></div>
    </div>
    <div class="field-row" style="margin-top:12px;">
      <div class="field"><label>সম্পর্ক</label><input id="n_rel" placeholder="ছেলে/স্ত্রী/মেয়ে..."></div>
      <div class="field"><label>শেয়ার %</label><input id="n_pct" type="number" placeholder="যেমন ৫০"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>মোবাইল</label><input id="n_mobile"></div>
      <div class="field"><label>জন্মতারিখ</label><input type="date" id="n_dob"></div>
    </div>
    <div class="field"><label>ঠিকানা</label><input id="n_address"></div>
    <div class="field-row">
      <div class="field"><label>NID</label><input id="n_nid"></div>
      <div class="field"><label>স্ট্যাটাস</label>
        <select id="n_status"><option>সক্রিয়</option><option>নিষ্ক্রিয়</option></select>
      </div>
    </div>
    <div class="field"><label>NID কপি (ছবি)</label>
      <div class="sig-upload">
        <label id="nm_nidLabel" for="n_nidcopy">NID কপি আপলোড করুন</label>
        <input type="file" id="n_nidcopy" accept="image/*" onchange="onNomineeNidChange(this)">
      </div>
    </div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn" onclick="saveNominee('${memberId}')">সংরক্ষণ করুন</button>
    </div>
  `);
}
function onNomineePhotoChange(input){
  const file = input.files && input.files[0];
  if(!file) return;
  const label = document.getElementById('nm_photoLabel');
  const original = label.innerHTML;
  label.innerHTML = '⏳';
  resizeImageToDataURL(file, 300,
    (dataUrl)=>{
      window._tmpNomineePhoto = dataUrl;
      label.innerHTML = `<img src="${dataUrl}">`;
    },
    (errMsg)=>{
      label.innerHTML = original;
      toast('⚠️ '+errMsg);
      input.value='';
    }
  );
}
function onNomineeNidChange(input){
  const file = input.files && input.files[0];
  if(!file) return;
  const label = document.getElementById('nm_nidLabel');
  const original = label.innerHTML;
  label.innerHTML = 'প্রসেস হচ্ছে…';
  resizeImageToDataURL(file, 500,
    (dataUrl)=>{
      window._tmpNomineeNidCopy = dataUrl;
      label.innerHTML = `<img src="${dataUrl}">`;
    },
    (errMsg)=>{
      label.innerHTML = original;
      toast('⚠️ '+errMsg);
      input.value='';
    }
  );
}
async function saveNominee(memberId){
  const name = document.getElementById('n_name').value.trim();
  if(!name){ toast('নাম আবশ্যক'); return; }
  const m = state.members.find(x=>x.id===memberId);
  if(!m.nominees) m.nominees=[];
  const newNominee = {
    id:uid(), name,
    photo: window._tmpNomineePhoto || null,
    relation:document.getElementById('n_rel').value,
    percent:document.getElementById('n_pct').value,
    mobile:document.getElementById('n_mobile').value,
    dob:document.getElementById('n_dob').value,
    address:document.getElementById('n_address').value,
    nid:document.getElementById('n_nid').value,
    status:document.getElementById('n_status').value,
    nidCopy: window._tmpNomineeNidCopy || null,
  };
  m.nominees.push(newNominee);
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ m.nominees.pop(); }); if(!proceed) return; }
  closeSheet(); openMemberDetail(memberId);
  toast('নমিনি যোগ হয়েছে');
}

/* ---------------- TRANSACTIONS (deposit / withdrawal / expense) ---------------- */
function renderTransactions(c,fab){
  c.innerHTML = `
    <div class="page-head"><div><h1>লেনদেন</h1><div class="sub">জমা, উত্তোলন ও খরচ</div></div></div>
    <div class="subtabs">
      <button id="st_deposit" onclick="setTxSub('deposit')">জমা</button>
      <button id="st_withdrawal" onclick="setTxSub('withdrawal')">উত্তোলন</button>
      <button id="st_expense" onclick="setTxSub('expense')">খরচ</button>
    </div>
    ${txSubTab==='deposit' ? `<div class="excel-bar">
      <button class="btn ghost sm" onclick="exportDepositsExcel()">⬇ Excel এক্সপোর্ট</button>
      <button class="btn ghost sm" onclick="document.getElementById('depositImportInput').click()">⬆ Excel ইম্পোর্ট</button>
      <button class="link-btn" onclick="downloadDepositTemplate()">টেমপ্লেট</button>
    </div>` : ''}
    <div id="txListWrap"></div>
  `;
  document.getElementById('st_'+txSubTab).classList.add('active');
  renderTxList();
  fab.innerHTML = `<button class="btn block" onclick="openTxForm(txSubTab==='expense'?'expense':txSubTab)">+ নতুন ${txSubTab==='deposit'?'জমা':txSubTab==='withdrawal'?'উত্তোলন':'খরচ'} যোগ করুন</button>`;
}
function setTxSub(t){ txSubTab=t; renderTransactions(document.getElementById('content'), document.getElementById('fabWrap')); }
function renderTxList(){
  const wrap = document.getElementById('txListWrap');
  if(txSubTab==='expense'){
    const list = [...state.expenses].sort((a,b)=>b.date.localeCompare(a.date));
    wrap.innerHTML = list.length ? list.map(e=>`
      <div class="list-item">
        <div class="avatar" style="background:var(--danger-tint);color:var(--danger)">খ</div>
        <div class="body"><div class="title">${e.head}</div><div class="meta">${fmtDate(e.date)} · ${e.paidTo||''}</div>
          <button class="link-btn" onclick="openVoucherPreview('${e.id}')">ভাউচার / রশিদ</button></div>
        <div class="right"><div class="amt neg">-${fmt(e.amount)}</div><div class="tag red">${e.method==='bank'?'ব্যাংক':'ক্যাশ'}</div></div>
      </div>`).join('') : emptyTxHtml('খরচ');
  } else {
    const list = state.transactions.filter(t=>t.type===txSubTab).sort((a,b)=>b.date.localeCompare(a.date));
    wrap.innerHTML = list.length ? list.map(t=>{
      const m = state.members.find(x=>x.id===t.memberId);
      const cls = t.type==='withdrawal'?'neg':'pos';
      const sign = t.type==='withdrawal'?'-':'+';
      const draft = !isPosted(t);
      const actions = draft
        ? `<span class="tag red" style="margin:0 8px 0 0;">খসড়া</span><button class="link-btn" onclick="postTx('${t.id}')">পোস্ট করুন</button> <button class="link-btn" style="color:var(--danger);margin-left:10px;" onclick="deleteDraftTx('${t.id}')">মুছুন</button>`
        : `<button class="link-btn" onclick="openReceiptPreview('${t.id}')">রশিদ</button>`;
      return `<div class="list-item" style="${draft?'opacity:.85;border-style:dashed;':''}">
        <div class="avatar">${initials(m?m.name:'?')}</div>
        <div class="body"><div class="title">${m?m.name:'অজানা'}</div><div class="meta">${fmtDate(t.date)} · ${t.category||''}${t.receiptNo?' · '+t.receiptNo:''}</div>
          <div style="margin-top:3px;">${actions}</div></div>
        <div class="right"><div class="amt ${draft?'':cls}" ${draft?'style="color:var(--muted)"':''}>${sign}${fmt(t.amount)}</div><div class="tag ${t.method==='bank'?'':'gold'}">${t.method==='bank'?'ব্যাংক':'ক্যাশ'}</div></div>
      </div>`;
    }).join('') : emptyTxHtml(txSubTab==='deposit'?'জমা':'উত্তোলন');
  }
}
function emptyTxHtml(label){
  return `<div class="empty-state"><div class="icon">🧾</div><div class="t">কোনো ${label} নেই</div><div class="d">নিচের বাটনে চাপ দিয়ে নতুন এন্ট্রি যোগ করুন</div></div>`;
}
function memberOptionsHtml(selectedId){
  if(state.members.length===0) return '<option value="">প্রথমে একজন সদস্য যোগ করুন</option>';
  return state.members.map(m=>`<option value="${m.id}" ${m.id===selectedId?'selected':''}>${m.name}</option>`).join('');
}
function openTxForm(type, memberId){
  if(type!=='expense' && state.members.length===0){ toast('প্রথমে একজন সদস্য যোগ করুন'); switchTab('members'); return; }
  const title = type==='deposit'?'নতুন জমা':type==='withdrawal'?'নতুন উত্তোলন':'নতুন খরচ';
  if(type==='expense'){
    showSheet(`
      <h2>${title}</h2>
      <div class="field"><label>খরচের খাত *</label>
        <select id="e_head">
          <option>অফিস ভাড়া</option><option>বিদ্যুৎ বিল</option><option>ইন্টারনেট</option><option>বেতন</option>
          <option>যাতায়াত</option><option>খাবার</option><option>স্টেশনারি</option><option>ব্যাংক চার্জ</option>
          <option>রক্ষণাবেক্ষণ</option><option>বিবিধ</option>
        </select>
      </div>
      <div class="field"><label>বিবরণ</label><input id="e_desc"></div>
      <div class="field-row">
        <div class="field"><label>পরিমাণ (৳) *</label><input type="number" id="e_amount"></div>
        <div class="field"><label>তারিখ</label><input type="date" id="e_date" value="${todayISO()}"></div>
      </div>
      <div class="field-row">
        <div class="field"><label>প্রদান মাধ্যম</label>
          <select id="e_method"><option value="cash">ক্যাশ</option><option value="bank">ব্যাংক</option></select>
        </div>
        <div class="field"><label>কাকে প্রদান</label><input id="e_paidto"></div>
      </div>
      <div class="sheet-actions">
        <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
        <button class="btn" onclick="saveExpense()">সংরক্ষণ করুন</button>
      </div>
    `);
    return;
  }
  showSheet(`
    <h2>${title}</h2>
    <div class="field"><label>সদস্য *</label><select id="t_member">${memberOptionsHtml(memberId)}</select></div>
    <div class="field"><label>ধরন</label>
      <select id="t_category" onchange="onTxCategoryChange()">
        ${type==='deposit'?'<option value="COMBO">মাসিক সঞ্চয় + কল্যাণ তহবিল (Welfare Fund)</option>':''}
        <option>মাসিক সঞ্চয়</option><option>কল্যাণ তহবিল</option><option>সাধারণ সঞ্চয়</option><option>শেয়ার/মূলধন</option>
        <option>বিশেষ জমা</option><option>ডিপিএস</option><option>এফডিআর</option><option>অন্যান্য</option>
      </select>
    </div>
    <div id="t_comboWrap" style="display:${type==='deposit'?'block':'none'};">
      <div class="field-row">
        <div class="field"><label>১. মাসিক সঞ্চয় (৳) *</label><input type="number" id="t_amt_saving" oninput="updateComboTotal()"></div>
        <div class="field"><label>২. Welfare Fund (৳) *</label><input type="number" id="t_amt_welfare" oninput="updateComboTotal()"></div>
      </div>
      <div class="receipt-preview" style="margin:0 0 12px;"><div class="rline"><span>মোট জমা</span><span id="t_comboTotal" style="font-weight:700;">৳০</span></div></div>
    </div>
    <div class="field-row">
      <div class="field" id="t_singleWrap" style="display:${type==='deposit'?'none':'block'};"><label>পরিমাণ (৳) *</label><input type="number" id="t_amount"></div>
      <div class="field"><label>তারিখ</label><input type="date" id="t_date" value="${todayISO()}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>পদ্ধতি</label>
        <select id="t_method"><option value="cash">ক্যাশ</option><option value="bank">ব্যাংক</option><option value="mfs">বিকাশ/নগদ</option></select>
      </div>
      <div class="field"><label>রেফারেন্স/রশিদ নং</label><input id="t_ref"></div>
    </div>
    <div class="field"><label>মন্তব্য</label><input id="t_remarks"></div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn ghost" onclick="saveTx('${type}', false)">সংরক্ষণ (খসড়া)</button>
      <button class="btn" onclick="saveTx('${type}', true)">পোস্ট করুন</button>
    </div>
    <div class="hint">"সংরক্ষণ" করলে এন্ট্রি খসড়া থাকবে — ব্যালেন্স ও রিপোর্টে যোগ হবে না। "পোস্ট করুন" চাপলে সংরক্ষণ হয়ে ব্যালেন্সে কার্যকর হবে ও রশিদ নং পাবে।</div>
  `);
}
async function saveExpense(){
  const amount = Number(document.getElementById('e_amount').value);
  if(!amount || amount<=0){ toast('সঠিক পরিমাণ দিন'); return; }
  const entry = {
    id:uid(), head:document.getElementById('e_head').value, description:document.getElementById('e_desc').value,
    amount, date:document.getElementById('e_date').value||todayISO(),
    method:document.getElementById('e_method').value, paidTo:document.getElementById('e_paidto').value
  };
  state.expenses.push(entry);
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.expenses.pop(); }); if(!proceed) return; }
  closeSheet(); renderAll(); toast('খরচ সংরক্ষিত হয়েছে');
}
function onTxCategoryChange(){
  const combo = document.getElementById('t_category').value==='COMBO';
  document.getElementById('t_comboWrap').style.display = combo ? 'block' : 'none';
  document.getElementById('t_singleWrap').style.display = combo ? 'none' : 'block';
}
function updateComboTotal(){
  const a = Number(document.getElementById('t_amt_saving').value)||0;
  const b = Number(document.getElementById('t_amt_welfare').value)||0;
  document.getElementById('t_comboTotal').textContent = fmt(a+b);
}
/* Entries created from one combined deposit share a batchId (and one receipt number). */
function batchOf(t){ return t.batchId ? state.transactions.filter(x=>x.batchId===t.batchId) : [t]; }
async function saveTx(type, post){
  const memberId = document.getElementById('t_member').value;
  const category = document.getElementById('t_category').value;
  if(!memberId){ toast('সদস্য নির্বাচন করুন'); return; }
  const common = {
    memberId, type, date:document.getElementById('t_date').value||todayISO(),
    method:document.getElementById('t_method').value, ref:document.getElementById('t_ref').value,
    remarks:document.getElementById('t_remarks').value,
    status: post ? 'posted' : 'draft'
  };
  let parts;
  if(category==='COMBO'){
    const saving = Number(document.getElementById('t_amt_saving').value)||0;
    const welfare = Number(document.getElementById('t_amt_welfare').value)||0;
    if(saving<=0){ toast('মাসিক সঞ্চয়ের পরিমাণ দিন'); return; }
    if(welfare<=0){ toast('Welfare Fund-এর পরিমাণ দিন'); return; }
    parts = [{category:'মাসিক সঞ্চয়', amount:saving}, {category:'কল্যাণ তহবিল', amount:welfare}];
  } else {
    const amount = Number(document.getElementById('t_amount').value);
    if(!amount || amount<=0){ toast('সঠিক পরিমাণ দিন'); return; }
    parts = [{category, amount}];
  }
  const prevLen = state.transactions.length;
  const receiptNo = post ? nextReceiptNo(type) : null; // one number for the whole entry
  const batchId = parts.length>1 ? uid() : null;
  parts.forEach(pt=>{
    const entry = {id:uid(), ...common, category:pt.category, amount:pt.amount};
    if(batchId) entry.batchId = batchId;
    if(receiptNo) entry.receiptNo = receiptNo;
    state.transactions.push(entry);
  });
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.transactions.length = prevLen; }); if(!proceed) return; }
  closeSheet(); txSubTab=type; renderAll();
  const label = type==='deposit'?'জমা':'উত্তোলন';
  toast(post ? label+' পোস্ট হয়েছে' : label+' খসড়া হিসেবে সংরক্ষিত');
}
async function postTx(id){
  const t = state.transactions.find(x=>x.id===id);
  if(!t || isPosted(t)) return;
  const group = batchOf(t).filter(x=>!isPosted(x));
  const rNo = nextReceiptNo(t.type); // compute before flipping status so these entries aren't counted twice
  group.forEach(x=>{ x.receiptNo = rNo; x.status = 'posted'; });
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ group.forEach(x=>{ x.status='draft'; delete x.receiptNo; }); }); if(!proceed) return; }
  renderAll(); toast('পোস্ট হয়েছে — '+rNo);
}
async function deleteDraftTx(id){
  const t = state.transactions.find(x=>x.id===id);
  if(!t || isPosted(t)) return;
  if(!confirm('এই খসড়া এন্ট্রিটি মুছে ফেলতে চান?')) return;
  const prev = state.transactions;
  const ids = new Set(batchOf(t).filter(x=>!isPosted(x)).map(x=>x.id));
  state.transactions = state.transactions.filter(x=>!ids.has(x.id));
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.transactions = prev; }); if(!proceed) return; }
  renderAll();
}

/* ---------------- DEPOSIT: EXCEL EXPORT / IMPORT ---------------- */
const DEPOSIT_CATEGORIES = ['মাসিক সঞ্চয়','কল্যাণ তহবিল','সাধারণ সঞ্চয়','শেয়ার/মূলধন','বিশেষ জমা','ডিপিএস','এফডিআর','অন্যান্য'];
const DEPOSIT_HEADERS = ['Date','Member ID','Member Name','Category','Amount','Payment Method','Reference','Remarks'];
const METHOD_ALIASES = {
  cash:'cash', 'ক্যাশ':'cash',
  bank:'bank', 'ব্যাংক':'bank',
  bkash:'mfs', nagad:'mfs', mfs:'mfs', 'bkash/nagad':'mfs', 'বিকাশ':'mfs', 'বিকাশ/নগদ':'mfs', rocket:'mfs'
};
function memberDisplayId(m){ return m.customId || m.id.slice(0,6).toUpperCase(); }
function xlsxReady(){ return typeof window.XLSX !== 'undefined' && window.XLSX && window.XLSX.utils; }
function csvEscape(v){ v = String(v==null?'':v); return /[",\n\r]/.test(v) ? '"'+v.replace(/"/g,'""')+'"' : v; }
function downloadBlob(blob, filename){
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 3000);
}
/* rows: array of arrays (first row = header). Writes .xlsx when the library is loaded, otherwise a UTF-8 .csv that Excel also opens. */
function saveTable(sheets, baseName){
  if(xlsxReady()){
    const wb = XLSX.utils.book_new();
    sheets.forEach(sh=>{
      const ws = XLSX.utils.aoa_to_sheet(sh.rows);
      if(sh.widths) ws['!cols'] = sh.widths.map(w=>({wch:w}));
      XLSX.utils.book_append_sheet(wb, ws, sh.name);
    });
    XLSX.writeFile(wb, baseName+'.xlsx');
    return 'xlsx';
  }
  const csv = '\uFEFF' + sheets[0].rows.map(r=>r.map(csvEscape).join(',')).join('\r\n');
  downloadBlob(new Blob([csv], {type:'text/csv;charset=utf-8'}), baseName+'.csv');
  return 'csv';
}
function exportDepositsExcel(){
  const deposits = state.transactions.filter(t=>t.type==='deposit').sort((a,b)=>a.date.localeCompare(b.date));
  if(deposits.length===0){ toast('এক্সপোর্ট করার মতো কোনো জমা নেই'); return; }
  const rows = [[...DEPOSIT_HEADERS,'Status','Receipt No']];
  deposits.forEach(t=>{
    const m = state.members.find(x=>x.id===t.memberId);
    rows.push([t.date, m?memberDisplayId(m):'', m?m.name:'', t.category||'', Number(t.amount)||0, methodLabel(t.method), t.ref||'', t.remarks||'', isPosted(t)?'Posted':'Draft', t.receiptNo||receiptNoFor(t)]);
  });
  const kind = saveTable([{name:'Deposits', rows, widths:[12,12,24,16,12,16,16,24,10,12]}], 'deposits-'+todayISO());
  toast(kind==='xlsx' ? '✅ Excel ফাইল ডাউনলোড হচ্ছে' : '⚠️ Excel লাইব্রেরি লোড হয়নি — CSV ফাইল ডাউনলোড হচ্ছে (Excel-এ খুলবে)');
}
function downloadDepositTemplate(){
  const sample = [DEPOSIT_HEADERS, [todayISO(), state.members[0]?memberDisplayId(state.members[0]):'SH-001', state.members[0]?state.members[0].name:'নমুনা সদস্য', 'মাসিক সঞ্চয়', 5000, 'ক্যাশ', 'REF-001', 'নমুনা এন্ট্রি']];
  const guide = [
    ['ক্ষেত্র','নিয়ম'],
    ['Date','YYYY-MM-DD (যেমন 2026-10-10) অথবা DD/MM/YYYY'],
    ['Member ID','সদস্যের Member ID (যেমন SH-001) — আগে Member ID দিয়ে মেলানো হয়, না থাকলে Member Name দিয়ে'],
    ['Member Name','Member ID না থাকলে নাম হুবহু মিলতে হবে'],
    ['Category',DEPOSIT_CATEGORIES.join(' / ')],
    ['Amount','শূন্যের বেশি সংখ্যা'],
    ['Payment Method','ক্যাশ / ব্যাংক / বিকাশ/নগদ (Cash / Bank / bKash)'],
    ['Reference','ঐচ্ছিক'],
    ['Remarks','ঐচ্ছিক'],
  ];
  const memberRows = [['Member ID','Member Name','Mobile']].concat(state.members.map(m=>[memberDisplayId(m), m.name, m.mobile||'']));
  const kind = saveTable([
    {name:'Deposits', rows:sample, widths:[12,12,24,16,12,16,16,24]},
    {name:'Instructions', rows:guide, widths:[16,90]},
    {name:'Members', rows:memberRows, widths:[14,28,16]},
  ], 'deposit-import-template');
  toast(kind==='xlsx' ? '✅ টেমপ্লেট ডাউনলোড হচ্ছে' : '⚠️ CSV টেমপ্লেট ডাউনলোড হচ্ছে');
}
/* --- import --- */
function normHeader(h){ return String(h||'').toLowerCase().replace(/[\s_\-\/\.]+/g,''); }
const HEADER_MAP = {
  date:'date', 'তারিখ':'date',
  memberid:'memberId', 'সদস্যআইডি':'memberId', id:'memberId',
  membername:'memberName', name:'memberName', 'নাম':'memberName', 'সদস্যেরনাম':'memberName',
  category:'category', type:'category', 'ধরন':'category',
  amount:'amount', 'পরিমাণ':'amount', 'টাকা':'amount',
  paymentmethod:'method', method:'method', 'পদ্ধতি':'method',
  reference:'ref', ref:'ref', receiptref:'ref', 'রেফারেন্স':'ref', 'রশিদনং':'ref',
  remarks:'remarks', note:'remarks', 'মন্তব্য':'remarks',
};
function parseCsvText(text){
  const rows=[]; let row=[], cur='', inQ=false;
  text = text.replace(/^\uFEFF/,'');
  for(let i=0;i<text.length;i++){
    const ch=text[i];
    if(inQ){
      if(ch==='"'){ if(text[i+1]==='"'){ cur+='"'; i++; } else inQ=false; }
      else cur+=ch;
    } else if(ch==='"') inQ=true;
    else if(ch===','){ row.push(cur); cur=''; }
    else if(ch==='\n'||ch==='\r'){ if(ch==='\r'&&text[i+1]==='\n') i++; row.push(cur); rows.push(row); row=[]; cur=''; }
    else cur+=ch;
  }
  if(cur!==''||row.length){ row.push(cur); rows.push(row); }
  return rows.filter(r=>r.some(c=>String(c).trim()!==''));
}
function normDate(v){
  if(v===''||v==null) return null;
  if(v instanceof Date && !isNaN(v)) return v.getFullYear()+'-'+String(v.getMonth()+1).padStart(2,'0')+'-'+String(v.getDate()).padStart(2,'0');
  if(typeof v==='number' && v>20000 && v<80000){ return new Date(Math.round((v-25569)*86400000)).toISOString().slice(0,10); } // Excel serial
  const t = String(v).trim();
  if(/^\d{5}$/.test(t)) return normDate(Number(t)); // Excel serial saved as text (e.g. via CSV)
  let m = t.match(/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/);
  if(m) return validYMD(+m[1],+m[2],+m[3]);
  m = t.match(/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/);
  if(m) return validYMD(+m[3],+m[2],+m[1]);
  return null;
}
function validYMD(y,mo,d){
  const dt = new Date(Date.UTC(y,mo-1,d));
  if(dt.getUTCFullYear()!==y || dt.getUTCMonth()!==mo-1 || dt.getUTCDate()!==d) return null;
  return y+'-'+String(mo).padStart(2,'0')+'-'+String(d).padStart(2,'0');
}
function handleDepositImportFile(input){
  const file = input.files && input.files[0];
  if(!file) return;
  const isCsv = /\.csv$/i.test(file.name);
  const reader = new FileReader();
  reader.onerror = ()=>{ toast('⚠️ ফাইলটি পড়া যায়নি'); input.value=''; };
  reader.onload = ()=>{
    try{
      let table;
      if(isCsv){
        table = parseCsvText(typeof reader.result==='string' ? reader.result : new TextDecoder('utf-8').decode(reader.result));
      } else {
        if(!xlsxReady()){ toast('⚠️ Excel লাইব্রেরি লোড হয়নি (ইন্টারনেট দরকার)। ফাইলটি CSV হিসেবে সেভ করে আবার চেষ্টা করুন।'); input.value=''; return; }
        const wb = XLSX.read(reader.result, {type:'array'});
        const ws = wb.Sheets[wb.SheetNames[0]];
        table = XLSX.utils.sheet_to_json(ws, {header:1, defval:'', raw:true}).filter(r=>r.some(c=>String(c).trim()!==''));
      }
      input.value='';
      prepareDepositImport(table, file.name);
    }catch(e){ input.value=''; toast('⚠️ ফাইলটি বিশ্লেষণ করা যায়নি: '+((e&&e.message)||e)); }
  };
  if(isCsv) reader.readAsText(file, 'utf-8'); else reader.readAsArrayBuffer(file);
}
function prepareDepositImport(table, fileName){
  if(!table || table.length<2){ toast('⚠️ ফাইলে কোনো ডেটা সারি পাওয়া যায়নি'); return; }
  const colIdx = {};
  table[0].forEach((h,i)=>{ const key = HEADER_MAP[normHeader(h)]; if(key && !(key in colIdx)) colIdx[key]=i; });
  const missing = ['date','amount'].filter(k=>!(k in colIdx));
  if(!('memberId' in colIdx) && !('memberName' in colIdx)) missing.push('Member ID / Member Name');
  if(missing.length){ toast('⚠️ আবশ্যক কলাম পাওয়া যায়নি: '+missing.join(', ')); return; }
  const get = (r,k)=> (k in colIdx) ? r[colIdx[k]] : '';
  const existing = state.transactions.filter(t=>t.type==='deposit');
  const seen = new Set();
  const valid=[], errors=[]; let dupes=0, warnings=0;
  for(let i=1;i<table.length;i++){
    const r = table[i], line = i+1;
    const idRaw = String(get(r,'memberId')||'').trim(), nameRaw = String(get(r,'memberName')||'').trim();
    let m = null;
    if(idRaw) m = state.members.find(x=>memberDisplayId(x).toLowerCase()===idRaw.toLowerCase());
    if(!m && nameRaw) m = state.members.find(x=>x.name.trim().toLowerCase()===nameRaw.toLowerCase());
    if(!m){ errors.push(`সারি ${line}: সদস্য পাওয়া যায়নি (${idRaw||nameRaw||'ফাঁকা'})`); continue; }
    const date = normDate(get(r,'date'));
    if(!date){ errors.push(`সারি ${line}: তারিখ সঠিক নয় (${get(r,'date')||'ফাঁকা'})`); continue; }
    const amount = Number(String(get(r,'amount')).replace(/[,৳\s]/g,''));
    if(!amount || amount<=0){ errors.push(`সারি ${line}: পরিমাণ সঠিক নয় (${get(r,'amount')||'ফাঁকা'})`); continue; }
    let category = String(get(r,'category')||'').trim();
    if(!DEPOSIT_CATEGORIES.includes(category)){ if(category) warnings++; category = category ? 'অন্যান্য' : 'মাসিক সঞ্চয়'; }
    const methodRaw = String(get(r,'method')||'cash').trim().toLowerCase();
    const method = METHOD_ALIASES[methodRaw] || 'cash';
    if(methodRaw && !METHOD_ALIASES[methodRaw]) warnings++;
    const ref = String(get(r,'ref')||'').trim();
    const remarks = String(get(r,'remarks')||'').trim();
    const key = [m.id,date,amount,category,ref].join('|');
    if(seen.has(key) || existing.some(t=>[t.memberId,t.date,Number(t.amount),t.category,t.ref||''].join('|')===key)){ dupes++; continue; }
    seen.add(key);
    valid.push({memberId:m.id, date, amount, category, method, ref, remarks});
  }
  window._depositImport = {rows:valid};
  const errHtml = errors.length ? `<div class="hint" style="color:var(--danger);margin-top:10px;">${errors.slice(0,8).map(e=>'• '+e).join('<br>')}${errors.length>8?`<br>… আরও ${errors.length-8}টি`:''}</div>` : '';
  showSheet(`
    <h2>ইম্পোর্ট প্রিভিউ</h2>
    <div class="hint" style="margin-top:0;">${fileName}</div>
    <div class="detail-card" style="margin-top:8px;">
      <div class="kv"><span class="k">মোট সারি</span><span class="v">${table.length-1}</span></div>
      <div class="kv"><span class="k">ইম্পোর্টযোগ্য</span><span class="v" style="color:var(--primary)">${valid.length}</span></div>
      <div class="kv"><span class="k">মোট পরিমাণ</span><span class="v">${fmt(valid.reduce((a,b)=>a+b.amount,0))}</span></div>
      <div class="kv"><span class="k">ডুপ্লিকেট (বাদ)</span><span class="v">${dupes}</span></div>
      <div class="kv"><span class="k">ত্রুটিপূর্ণ (বাদ)</span><span class="v" style="color:var(--danger)">${errors.length}</span></div>
      ${warnings?`<div class="kv"><span class="k">অচেনা ধরন/পদ্ধতি (ডিফল্ট ধরা হয়েছে)</span><span class="v">${warnings}</span></div>`:''}
    </div>
    ${errHtml}
    <div class="hint">"খসড়া" দিলে ব্যালেন্সে যোগ হবে না, পরে যাচাই করে পোস্ট করা যাবে। "পোস্ট" দিলে সাথে সাথে ব্যালেন্সে কার্যকর হবে ও রশিদ নং পাবে।</div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn ghost" ${valid.length?'':'disabled'} onclick="commitDepositImport(false)">খসড়া (${valid.length})</button>
      <button class="btn" ${valid.length?'':'disabled'} onclick="commitDepositImport(true)">পোস্ট (${valid.length})</button>
    </div>
  `);
}
async function commitDepositImport(post){
  const imp = window._depositImport;
  if(!imp || !imp.rows.length) return;
  const prevLen = state.transactions.length;
  imp.rows.forEach(r=>{
    const entry = {id:uid(), memberId:r.memberId, type:'deposit', category:r.category, amount:r.amount, date:r.date,
      method:r.method, ref:r.ref, remarks:r.remarks, status: post?'posted':'draft'};
    if(post) entry.receiptNo = nextReceiptNo('deposit'); // computed before the push, so numbers run in sequence
    state.transactions.push(entry);
  });
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.transactions.length = prevLen; }); if(!proceed) return; }
  const n = imp.rows.length;
  window._depositImport = null;
  closeSheet(); txSubTab='deposit'; renderAll();
  toast(`✅ ${n}টি জমা ${post?'পোস্ট':'খসড়া হিসেবে ইম্পোর্ট'} হয়েছে`);
}

/* ---------------- FDR ---------------- */
function renderFdr(c,fab){
  c.innerHTML = `<div class="page-head"><div><h1>এফডিআর</h1><div class="sub">${state.fdrs.length} টি এফডিআর</div></div></div><div id="fdrList"></div>`;
  const wrap = document.getElementById('fdrList');
  if(state.fdrs.length===0){
    wrap.innerHTML = `<div class="empty-state"><div class="icon">🏦</div><div class="t">কোনো এফডিআর নেই</div><div class="d">সমিতির স্থায়ী আমানত এখানে যোগ করুন</div></div>`;
  } else {
    wrap.innerHTML = state.fdrs.map(f=>{
      const accrued = fdrAccruedProfit(f);
      const maturity = fdrMaturityAmount(f);
      const expectedProfit = fdrExpectedProfit(f);
      const daysLeft = Math.ceil((new Date(f.maturityDate)-new Date())/86400000);
      const statusLabel = f.status || (daysLeft<=30 && daysLeft>=0 ? 'শীঘ্রই মেয়াদপূর্ণ' : 'সক্রিয়');
      const isClosed = f.status==='বন্ধ';
      return `<div class="detail-card" style="margin-top:10px;">
        <div class="row-between"><div class="title" style="font-weight:700;">${f.bankName}</div>
          <span class="tag ${isClosed?'red':''}">${statusLabel}</span></div>
        <div class="kv"><span class="k">FDR No.</span><span class="v">${f.fdrNo||'-'}</span></div>
        <div class="kv"><span class="k">Bank Name</span><span class="v">${f.bankName}</span></div>
        <div class="kv"><span class="k">Branch</span><span class="v">${f.branch||'-'}</span></div>
        <div class="kv"><span class="k">Account No.</span><span class="v">${f.accountNo||'-'}</span></div>
        <div class="kv"><span class="k">Opening Date</span><span class="v">${fmtDate(f.openDate)}</span></div>
        <div class="kv"><span class="k">Maturity Date</span><span class="v">${fmtDate(f.maturityDate)}</span></div>
        <div class="kv"><span class="k">Principal Amount</span><span class="v">${fmt(f.principal)}</span></div>
        <div class="kv"><span class="k">Interest/Profit Rate</span><span class="v">${f.rate}%</span></div>
        <div class="kv"><span class="k">Tenure</span><span class="v">${f.tenureMonths} মাস</span></div>
        <div class="kv"><span class="k">এখন পর্যন্ত জমাকৃত মুনাফা</span><span class="v" style="color:var(--gold)">${fmt(accrued)}</span></div>
        <div class="kv"><span class="k">Expected Profit (Gross)</span><span class="v" style="color:var(--gold)">${fmt(expectedProfit)}</span></div>
        <div class="kv"><span class="k">Tax on Profit (${f.taxRate||0}%)</span><span class="v" style="color:var(--danger)">-${fmt(fdrTax(f))}</span></div>
        <div class="kv"><span class="k">Expected Bank Charge</span><span class="v" style="color:var(--danger)">-${fmt(fdrBankCharge(f))}</span></div>
        <div class="kv"><span class="k">Net Profit (করের পর)</span><span class="v" style="color:var(--gold);font-weight:700;">${fmt(fdrNetProfit(f))}</span></div>
        <div class="kv"><span class="k">Maturity Amount (Gross)</span><span class="v">${fmt(maturity)}</span></div>
        <div class="kv"><span class="k">Net Maturity Amount</span><span class="v" style="color:var(--gold);font-weight:700;">${fmt(fdrNetMaturity(f))}</span></div>
        <div class="kv"><span class="k">Status</span><span class="v">${statusLabel}</span></div>
        <div style="margin-top:10px;display:flex;gap:14px;">
          <button class="link-btn" onclick="openFdrForm(state.fdrs.find(x=>x.id==='${f.id}'))">সম্পাদনা</button>
          ${!isClosed?`<button class="link-btn" style="color:var(--danger);" onclick="closeFdr('${f.id}')">বন্ধ করুন</button>`:''}
        </div>
      </div>`;
    }).join('');
  }
  fab.innerHTML = `<button class="btn block" onclick="openFdrForm()">+ নতুন এফডিআর যোগ করুন</button>`;
}
function fdrComputeMaturityDate(openDate, tenureMonths){
  if(!openDate || !tenureMonths) return '';
  const d = new Date(openDate);
  d.setMonth(d.getMonth()+Number(tenureMonths));
  return d.toISOString().slice(0,10);
}
function updateFdrPreview(){
  const principal = Number(document.getElementById('fd_principal').value)||0;
  const rate = Number(document.getElementById('fd_rate').value)||0;
  const tenureMonths = Number(document.getElementById('fd_tenure').value)||0;
  const openDate = document.getElementById('fd_open').value;
  const taxRate = Number(document.getElementById('fd_taxRate').value)||0;
  const bankCharge = Number(document.getElementById('fd_bankCharge').value)||0;
  const expectedProfit = Math.round(principal*(rate/100)*(tenureMonths/12));
  const tax = Math.round(expectedProfit*taxRate/100);
  const netProfit = expectedProfit - tax - bankCharge;
  document.getElementById('fd_previewProfit').textContent = fmt(expectedProfit);
  document.getElementById('fd_previewTax').textContent = '-'+fmt(tax);
  document.getElementById('fd_previewCharge').textContent = '-'+fmt(bankCharge);
  document.getElementById('fd_previewNet').textContent = fmt(netProfit);
  document.getElementById('fd_previewMaturity').textContent = fmt(principal + netProfit);
  // auto-fill maturity date only if user hasn't manually edited it
  const maturityInput = document.getElementById('fd_maturity');
  if(maturityInput && !maturityInput.dataset.manual){
    maturityInput.value = fdrComputeMaturityDate(openDate, tenureMonths);
  }
}
function openFdrForm(existing){
  const f = existing || {};
  showSheet(`
    <h2>${existing?'এফডিআর সম্পাদনা':'নতুন এফডিআর'}</h2>
    <div class="field-row">
      <div class="field"><label>FDR No. (এফডিআর নং)</label><input id="fd_no" value="${f.fdrNo||''}"></div>
      <div class="field"><label>Account No. (হিসাব নং)</label><input id="fd_acc" value="${f.accountNo||''}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Bank Name (ব্যাংকের নাম) *</label><input id="fd_bank" value="${f.bankName||''}"></div>
      <div class="field"><label>Branch (শাখা)</label><input id="fd_branch" value="${f.branch||''}"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Principal Amount (আসল, ৳) *</label><input type="number" id="fd_principal" value="${f.principal||''}" oninput="updateFdrPreview()"></div>
      <div class="field"><label>Interest/Profit Rate (%) *</label><input type="number" id="fd_rate" value="${f.rate||''}" oninput="updateFdrPreview()"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Opening Date (খোলার তারিখ)</label><input type="date" id="fd_open" value="${f.openDate||todayISO()}" oninput="updateFdrPreview()"></div>
      <div class="field"><label>Tenure (মেয়াদ, মাস) *</label><input type="number" id="fd_tenure" value="${f.tenureMonths||''}" placeholder="যেমন ১২" oninput="updateFdrPreview()"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Maturity Date (মেয়াদপূর্ণের তারিখ)</label><input type="date" id="fd_maturity" value="${f.maturityDate||''}" onchange="this.dataset.manual='1'"></div>
      <div class="field"><label>Status</label>
        <select id="fd_status">
          <option ${!f.status||f.status==='সক্রিয়'?'selected':''}>সক্রিয়</option>
          <option ${f.status==='মেয়াদ উত্তীর্ণ'?'selected':''}>মেয়াদ উত্তীর্ণ</option>
          <option ${f.status==='বন্ধ'?'selected':''}>বন্ধ</option>
        </select>
      </div>
    </div>
    <div class="field-row">
      <div class="field"><label>Tax on Profit (প্রোফিটের উপর কর, %)</label><input type="number" id="fd_taxRate" value="${f.taxRate||''}" placeholder="যেমন ১০" oninput="updateFdrPreview()"></div>
      <div class="field"><label>Expected Bank Charge (৳)</label><input type="number" id="fd_bankCharge" value="${f.bankCharge||''}" placeholder="যেমন ১৫০০" oninput="updateFdrPreview()"></div>
    </div>
    <div class="receipt-preview" style="margin-top:6px;">
      <div class="rline"><span>Expected Profit (Gross)</span><span id="fd_previewProfit" style="font-weight:700;color:var(--gold);">৳০</span></div>
      <div class="rline"><span>Tax on Profit</span><span id="fd_previewTax" style="font-weight:700;color:var(--danger);">৳০</span></div>
      <div class="rline"><span>Expected Bank Charge</span><span id="fd_previewCharge" style="font-weight:700;color:var(--danger);">৳০</span></div>
      <div class="rline"><span>Net Profit</span><span id="fd_previewNet" style="font-weight:700;color:var(--gold);">৳০</span></div>
      <div class="rline"><span>Net Maturity Amount</span><span id="fd_previewMaturity" style="font-weight:700;color:var(--gold);">৳০</span></div>
    </div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বাতিল</button>
      <button class="btn" onclick="saveFdr('${existing?existing.id:''}')">সংরক্ষণ করুন</button>
    </div>
  `);
  updateFdrPreview();
}
async function saveFdr(id){
  const bankName = document.getElementById('fd_bank').value.trim();
  const principal = Number(document.getElementById('fd_principal').value);
  const rate = Number(document.getElementById('fd_rate').value);
  const tenureMonths = Number(document.getElementById('fd_tenure').value);
  const openDate = document.getElementById('fd_open').value || todayISO();
  const maturityDate = document.getElementById('fd_maturity').value || fdrComputeMaturityDate(openDate, tenureMonths);
  const status = document.getElementById('fd_status').value;
  if(!bankName || !principal || !rate || !tenureMonths){ toast('আবশ্যক তথ্যগুলো পূরণ করুন'); return; }
  const data = {
    bankName, branch:document.getElementById('fd_branch').value, fdrNo:document.getElementById('fd_no').value,
    accountNo:document.getElementById('fd_acc').value, principal, rate, tenureMonths, openDate,
    maturityDate, status,
    taxRate: Number(document.getElementById('fd_taxRate').value)||0,
    bankCharge: Number(document.getElementById('fd_bankCharge').value)||0
  };
  const prevFdrs = JSON.parse(JSON.stringify(state.fdrs));
  if(id){
    const idx = state.fdrs.findIndex(x=>x.id===id);
    state.fdrs[idx] = {...state.fdrs[idx], ...data};
  } else {
    data.id = uid();
    state.fdrs.push(data);
  }
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.fdrs = prevFdrs; }); if(!proceed) return; }
  closeSheet(); renderAll(); toast('এফডিআর সংরক্ষিত হয়েছে');
}
async function closeFdr(id){
  const f = state.fdrs.find(x=>x.id===id);
  if(!f) return;
  const prevStatus = f.status;
  f.status='বন্ধ';
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ f.status = prevStatus; }); if(!proceed) return; }
  renderAll(); toast('এফডিআর বন্ধ করা হয়েছে');
}

/* ---------------- PROFIT & STATEMENT & REPORTS ---------------- */
let profitSubTab = 'distribution';
function renderProfit(c,fab){
  const showDist = canDistribute();
  if(!showDist && profitSubTab==='distribution') profitSubTab='statement';
  c.innerHTML = `
    <div class="page-head"><div><h1>প্রোফিট ও রিপোর্ট</h1><div class="sub">বণ্টন, স্টেটমেন্ট ও রিপোর্ট</div></div></div>
    <div class="subtabs">
      ${showDist?`<button id="ps_distribution" onclick="setProfitSub('distribution')">বণ্টন</button>`:''}
      <button id="ps_statement" onclick="setProfitSub('statement')">সদস্য স্টেটমেন্ট</button>
      <button id="ps_reports" onclick="setProfitSub('reports')">রিপোর্ট</button>
    </div>
    <div id="profitBody"></div>
  `;
  document.getElementById('ps_'+profitSubTab).classList.add('active');
  fab.innerHTML='';
  if(profitSubTab==='distribution') renderDistribution();
  else if(profitSubTab==='statement') renderStatementTab();
  else renderReportsTab();
}
function setProfitSub(t){ profitSubTab=t; renderProfit(document.getElementById('content'), document.getElementById('fabWrap')); }

function renderDistribution(){
  const wrap = document.getElementById('profitBody');
  const runs = [...state.profitRuns].sort((a,b)=>b.date.localeCompare(a.date));
  wrap.innerHTML = `
    <div class="detail-card">
      <div class="field"><label>মোট বণ্টনযোগ্য প্রোফিট (৳)</label><input type="number" id="pd_total" placeholder="যেমন ৫০০০০০"></div>
      <div class="field"><label>বণ্টনের ভিত্তি</label>
        <select id="pd_basis"><option value="net">নিট জমা (জমা - উত্তোলন)</option><option value="deposit">মোট জমা</option></select>
      </div>
      <button class="btn block" onclick="previewDistribution()">হিসাব করুন / প্রিভিউ দেখুন</button>
      <div id="pd_preview"></div>
    </div>
    <div class="section-title">পূর্ববর্তী বণ্টন</div>
    ${runs.length? runs.map(r=>`<div class="list-item">
        <div class="avatar" style="background:var(--gold-tint);color:var(--gold)">প</div>
        <div class="body"><div class="title">${fmtDate(r.date)}</div><div class="meta">${r.distributions.length} জন সদস্যের মধ্যে বণ্টিত</div></div>
        <div class="right"><div class="amt" style="color:var(--gold)">${fmt(r.totalProfit)}</div></div>
      </div>`).join('') : `<div class="empty-state"><div class="d">এখনো কোনো প্রোফিট বণ্টন করা হয়নি</div></div>`}
  `;
}
function previewDistribution(){
  const total = Number(document.getElementById('pd_total').value);
  const basis = document.getElementById('pd_basis').value;
  if(!total || total<=0){ toast('সঠিক প্রোফিট পরিমাণ দিন'); return; }
  if(state.members.length===0){ toast('কোনো সদস্য নেই'); return; }
  const contributions = state.members.map(m=>{
    const c = basis==='deposit' ? memberDeposit(m.id) : (memberDeposit(m.id)-memberWithdrawal(m.id));
    return {member:m, contribution: Math.max(0,c)};
  });
  const sum = contributions.reduce((a,b)=>a+b.contribution,0);
  if(sum<=0){ document.getElementById('pd_preview').innerHTML = `<div class="empty-state"><div class="d">সদস্যদের কোনো জমা নেই, বণ্টনের ভিত্তি পাওয়া যায়নি</div></div>`; return; }
  const rows = contributions.map(x=>({...x, ratio:x.contribution/sum, amount: Math.round(total*(x.contribution/sum))}));
  window._pendingDistribution = {total, rows};
  document.getElementById('pd_preview').innerHTML = `
    <table class="stmt" style="margin-top:14px;">
      <tr><th>সদস্য</th><th>জমা ভিত্তি</th><th>অনুপাত</th><th>প্রোফিট</th></tr>
      ${rows.map(r=>`<tr><td style="text-align:right">${r.member.name}</td><td>${fmt(r.contribution)}</td><td>${(r.ratio*100).toFixed(1)}%</td><td>${fmt(r.amount)}</td></tr>`).join('')}
    </table>
    <button class="btn block" style="margin-top:14px;" onclick="applyDistribution()">বণ্টন নিশ্চিত করুন ও প্রয়োগ করুন</button>
  `;
}
async function applyDistribution(){
  const pd = window._pendingDistribution;
  if(!pd) return;
  const date = todayISO();
  const prevTxCount = state.transactions.length;
  const prevRunsCount = state.profitRuns.length;
  pd.rows.forEach(r=>{
    if(r.amount>0){
      state.transactions.push({id:uid(), memberId:r.member.id, type:'profit', category:'প্রোফিট বণ্টন', amount:r.amount, date, method:'-', remarks:'প্রোফিট বণ্টন'});
    }
  });
  state.profitRuns.push({id:uid(), date, totalProfit:pd.total, distributions:pd.rows.map(r=>({memberId:r.member.id, amount:r.amount}))});
  const ok = await saveState();
  if(!ok){
    const proceed = offerOfflineContinue(()=>{
      state.transactions.length = prevTxCount;
      state.profitRuns.length = prevRunsCount;
    });
    if(!proceed) return;
  }
  window._pendingDistribution = null;
  renderAll(); toast('প্রোফিট বণ্টন সম্পন্ন হয়েছে');
}

function renderStatementTab(){
  const wrap = document.getElementById('profitBody');
  wrap.innerHTML = `
    <div class="field" style="margin-top:12px;"><label>সদস্য নির্বাচন করুন</label>
      <select id="memberSelectStmt" onchange="renderStatementFor(this.value)">
        <option value="">-- সদস্য নির্বাচন করুন --</option>
        ${memberOptionsHtml()}
      </select>
    </div>
    <div id="stmtOut"></div>
  `;
  if(state.members.length===0){
    document.getElementById('stmtOut').innerHTML = `<div class="empty-state"><div class="d">প্রথমে সদস্য যোগ করুন</div></div>`;
  }
}
function openMemberStatement(memberId){
  switchTab('profit'); profitSubTab='statement';
  renderProfit(document.getElementById('content'), document.getElementById('fabWrap'));
  document.getElementById('memberSelectStmt').value = memberId;
  renderStatementFor(memberId);
}
function renderStatementFor(memberId, targetId){
  const out = document.getElementById(targetId||'stmtOut');
  if(!out) return;
  if(!memberId){ out.innerHTML=''; return; }
  const m = state.members.find(x=>x.id===memberId);
  const rows = memberTx(memberId).sort((a,b)=>a.date.localeCompare(b.date));
  let bal=0;
  const built = rows.map(t=>{
    if(t.type==='deposit'||t.type==='profit') bal+=t.amount; else bal-=t.amount;
    return {...t, running:bal};
  });
  out.innerHTML = `
    <div class="detail-card" style="margin-top:12px;">
      <div class="row-between"><div class="title" style="font-weight:700;">${m.name}</div><div class="amt pos">${fmt(bal)}</div></div>
      <div class="meta">সদস্য আইডি: ${m.customId || m.id.slice(0,6).toUpperCase()}</div>
    </div>
    ${built.length ? `<table class="stmt">
      <tr><th>তারিখ</th><th>বিবরণ</th><th>জমা</th><th>উত্তোলন</th><th>প্রোফিট</th><th>ব্যালেন্স</th><th></th></tr>
      ${built.map(t=>`<tr>
        <td>${fmtDate(t.date)}</td><td>${t.category||''}</td>
        <td>${t.type==='deposit'?fmt(t.amount):''}</td>
        <td>${t.type==='withdrawal'?fmt(t.amount):''}</td>
        <td>${t.type==='profit'?fmt(t.amount):''}</td>
        <td>${fmt(t.running)}</td>
        <td>${t.type!=='profit'?`<button class="link-btn" onclick="openReceiptPreview('${t.id}')">রশিদ</button>`:''}</td>
      </tr>`).join('')}
    </table>` : `<div class="empty-state"><div class="d">এই সদস্যের কোনো লেনদেন নেই</div></div>`}
  `;
}

function renderReportsTab(){
  const wrap = document.getElementById('profitBody');
  const t = totals();
  const byHead = {};
  state.expenses.forEach(e=>{ byHead[e.head] = (byHead[e.head]||0) + e.amount; });
  const headRows = Object.entries(byHead).sort((a,b)=>b[1]-a[1]);
  const byCat = {};
  postedTxs().filter(x=>x.type==='deposit').forEach(t=>{ byCat[t.category] = (byCat[t.category]||0)+t.amount; });
  const catRows = Object.entries(byCat).sort((a,b)=>b[1]-a[1]);
  wrap.innerHTML = `
    <div class="section-title" style="margin-top:14px;">ক্যাশ বই সারাংশ</div>
    <div class="detail-card">
      <div class="kv"><span class="k">মোট জমা (ক্যাশ+ব্যাংক)</span><span class="v">${fmt(t.totalDeposit)}</span></div>
      <div class="kv"><span class="k">মোট উত্তোলন</span><span class="v">${fmt(t.totalWithdrawal)}</span></div>
      <div class="kv"><span class="k">মোট খরচ (খরচ মডিউল)</span><span class="v">${fmt(t.totalExpense)}</span></div>
      <div class="kv"><span class="k">মোট প্রদত্ত প্রোফিট</span><span class="v">${fmt(t.totalProfitPaid)}</span></div>
      <div class="kv"><span class="k">ক্যাশ ব্যালেন্স</span><span class="v">${fmt(t.cashBalance)}</span></div>
      <div class="kv"><span class="k">ব্যাংক ব্যালেন্স</span><span class="v">${fmt(t.bankBalance)}</span></div>
    </div>
    <div class="section-title">জার্নাল থেকে আয়/ব্যয় (হিসাবরক্ষণ মডিউল)</div>
    <div class="detail-card">
      <div class="kv"><span class="k">জার্নাল আয় (আয় গ্রুপের একাউন্ট)</span><span class="v">${fmt(t.journalIncome)}</span></div>
      <div class="kv"><span class="k">জার্নাল ব্যয় (ব্যয় গ্রুপের একাউন্ট)</span><span class="v">${fmt(t.journalExpense)}</span></div>
    </div>
    <div class="hint" style="margin-top:0;">এই দুটো লাইন খরচ মডিউল/জমার হিসাব থেকে আলাদা রাখা হয়েছে যাতে একই লেনদেন দুই জায়গায় (খরচ এন্ট্রি + জার্নাল এন্ট্রি) দিলে ভুলবশত দ্বিগুণ গণনা না হয়।</div>
    <div class="section-title">খাত-ভিত্তিক খরচ</div>
    ${headRows.length? `<table class="stmt"><tr><th>খাত</th><th>পরিমাণ</th></tr>${headRows.map(([h,v])=>`<tr><td style="text-align:right">${h}</td><td>${fmt(v)}</td></tr>`).join('')}</table>` : `<div class="empty-state"><div class="d">কোনো খরচ নেই</div></div>`}
    <div class="section-title">জমার ধরন-ভিত্তিক সারাংশ</div>
    ${catRows.length? `<table class="stmt"><tr><th>ধরন</th><th>পরিমাণ</th></tr>${catRows.map(([h,v])=>`<tr><td style="text-align:right">${h||'অনির্দিষ্ট'}</td><td>${fmt(v)}</td></tr>`).join('')}</table>` : `<div class="empty-state"><div class="d">কোনো জমা নেই</div></div>`}
  `;
}

/* ---------------- RECEIPTS & VOUCHERS (print / PDF) ---------------- */
const BN_WORDS = ['শূন্য','এক','দুই','তিন','চার','পাঁচ','ছয়','সাত','আট','নয়','দশ','এগারো','বারো','তেরো','চৌদ্দ','পনের','ষোল','সতের','আঠারো','ঊনিশ','বিশ','একুশ','বাইশ','তেইশ','চব্বিশ','পঁচিশ','ছাব্বিশ','সাতাশ','আটাশ','ঊনত্রিশ','ত্রিশ','একত্রিশ','বত্রিশ','তেত্রিশ','চৌত্রিশ','পঁয়ত্রিশ','ছত্রিশ','সাঁইত্রিশ','আটত্রিশ','ঊনচল্লিশ','চল্লিশ','একচল্লিশ','বিয়াল্লিশ','তেতাল্লিশ','চুয়াল্লিশ','পঁয়তাল্লিশ','ছেচল্লিশ','সাতচল্লিশ','আটচল্লিশ','ঊনপঞ্চাশ','পঞ্চাশ','একান্ন','বায়ান্ন','তিপ্পান্ন','চুয়ান্ন','পঞ্চান্ন','ছাপ্পান্ন','সাতান্ন','আটান্ন','ঊনষাট','ষাট','একষট্টি','বাষট্টি','তেষট্টি','চৌষট্টি','পঁয়ষট্টি','ছিষট্টি','সাতষট্টি','আটষট্টি','ঊনসত্তর','সত্তর','একাত্তর','বাহাত্তর','তিয়াত্তর','চুয়াত্তর','পঁচাত্তর','ছিয়াত্তর','সাতাত্তর','আটাত্তর','ঊনআশি','আশি','একাশি','বিরাশি','তিরাশি','চুরাশি','পঁচাশি','ছিয়াশি','সাতাশি','আটাশি','ঊননব্বই','নব্বই','একানব্বই','বিরানব্বই','তিরানব্বই','চুরানব্বই','পঁচানব্বই','ছিয়ানব্বই','সাতানব্বই','আটানব্বই','নিরানব্বই'];
function numToWordsBn(n){
  n = Math.round(Math.abs(Number(n)||0));
  if(n===0) return BN_WORDS[0];
  if(n<100) return BN_WORDS[n];
  let parts=[];
  let crore = Math.floor(n/10000000); n%=10000000;
  let lakh = Math.floor(n/100000); n%=100000;
  let thousand = Math.floor(n/1000); n%=1000;
  let hundred = Math.floor(n/100); n%=100;
  if(crore) parts.push(numToWordsBn(crore)+' কোটি');
  if(lakh) parts.push(BN_WORDS[lakh]+' লক্ষ');
  if(thousand) parts.push(BN_WORDS[thousand]+' হাজার');
  if(hundred) parts.push(BN_WORDS[hundred]+' শত');
  if(n) parts.push(BN_WORDS[n]);
  return parts.join(' ');
}
function methodLabel(m){ return m==='bank'?'ব্যাংক':m==='mfs'?'বিকাশ/নগদ':'ক্যাশ'; }
function receiptPrefix(type){ return type==='deposit' ? 'DEP' : 'WD'; }
function receiptNoFor(t){
  if(t.receiptNo) return t.receiptNo;
  // older records (no stored number): numbered by their position among older posted entries of the same type
  const idx = state.transactions.filter(x=>x.type===t.type && isPosted(x) && !x.receiptNo).findIndex(x=>x.id===t.id);
  return receiptPrefix(t.type)+'-'+String(idx+1).padStart(4,'0');
}
/* A stored number is given the moment an entry is posted, so it never shifts when other drafts are posted later. */
function nextReceiptNo(type){
  let max = 0;
  state.transactions.filter(x=>x.type===type && isPosted(x)).forEach(x=>{
    const n = parseInt((receiptNoFor(x).split('-')[1]||'0'),10);
    if(n>max) max=n;
  });
  return receiptPrefix(type)+'-'+String(max+1).padStart(4,'0');
}
function receiptHtml(t, m){
  const rNo = receiptNoFor(t);
  const parts = batchOf(t).filter(isPosted);
  const total = parts.reduce((a,x)=>a+Number(x.amount||0),0);
  const label = t.type==='deposit' ? 'জমা' : 'উত্তোলন';
  return `
    <div class="rhead">
      <div class="org">${state.orgName}</div>
      <div class="sub">মানি রিসিট / Money Receipt</div>
    </div>
    <div class="rline"><span>রশিদ নং</span><span>${rNo}</span></div>
    <div class="rline"><span>তারিখ</span><span>${fmtDate(t.date)}</span></div>
    <div class="rline"><span>সদস্যের নাম</span><span>${m?m.name:'-'}</span></div>
    <div class="rline"><span>সদস্য আইডি</span><span>${m?(m.customId||m.id.slice(0,6).toUpperCase()):'-'}</span></div>
    <div class="rline"><span>ধরন</span><span>${label}</span></div>
    <div class="rline"><span>পদ্ধতি</span><span>${methodLabel(t.method)}</span></div>
    ${parts.length>1
      ? parts.map(x=>`<div class="rline"><span>${x.category||label}</span><span>${fmt(x.amount)}</span></div>`).join('') + `<div class="rline"><span style="font-weight:700;">মোট পরিমাণ</span><span style="font-weight:700;">${fmt(total)}</span></div>`
      : `<div class="rline"><span>বিবরণ</span><span>${t.category||label}</span></div><div class="rline"><span>পরিমাণ</span><span style="font-weight:700;">${fmt(t.amount)}</span></div>`}
    <div class="words">কথায়: ${numToWordsBn(total)} টাকা মাত্র</div>
    <div class="sign"><span>গ্রহণকারী: ${currentUser()?currentUser().name:''}</span><span>স্বাক্ষর: ...................</span></div>
  `;
}
function voucherHtml(e){
  const idx = state.expenses.findIndex(x=>x.id===e.id);
  const vNo = 'EXP-'+String(idx+1).padStart(4,'0');
  return `
    <div class="rhead">
      <div class="org">${state.orgName}</div>
      <div class="sub">পেমেন্ট ভাউচার / Payment Voucher</div>
    </div>
    <div class="rline"><span>ভাউচার নং</span><span>${vNo}</span></div>
    <div class="rline"><span>তারিখ</span><span>${fmtDate(e.date)}</span></div>
    <div class="rline"><span>খরচের খাত</span><span>${e.head}</span></div>
    <div class="rline"><span>বিবরণ</span><span>${e.description||'-'}</span></div>
    <div class="rline"><span>কাকে প্রদান</span><span>${e.paidTo||'-'}</span></div>
    <div class="rline"><span>পদ্ধতি</span><span>${methodLabel(e.method)}</span></div>
    <div class="rline"><span>পরিমাণ</span><span style="font-weight:700;">${fmt(e.amount)}</span></div>
    <div class="words">কথায়: ${numToWordsBn(e.amount)} টাকা মাত্র</div>
    <div class="sign"><span>প্রদানকারী: ${currentUser()?currentUser().name:''}</span><span>স্বাক্ষর: ...................</span></div>
  `;
}
function openReceiptPreview(txId){
  const t = state.transactions.find(x=>x.id===txId);
  if(!t) return;
  const m = state.members.find(x=>x.id===t.memberId);
  showSheet(`
    <h2>রশিদ প্রিভিউ</h2>
    <div class="receipt-preview">${receiptHtml(t,m)}</div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বন্ধ করুন</button>
      <button class="btn" onclick="doPrint('${txId}','tx')">প্রিন্ট / PDF সংরক্ষণ</button>
    </div>
    <div class="hint">প্রিন্ট ডায়ালগে "Save as PDF" নির্বাচন করলে এটি PDF হিসেবেও সংরক্ষণ হবে।</div>
  `);
}
function openVoucherPreview(expId){
  const e = state.expenses.find(x=>x.id===expId);
  if(!e) return;
  showSheet(`
    <h2>ভাউচার প্রিভিউ</h2>
    <div class="receipt-preview">${voucherHtml(e)}</div>
    <div class="sheet-actions">
      <button class="btn ghost" onclick="closeSheet()">বন্ধ করুন</button>
      <button class="btn" onclick="doPrint('${expId}','exp')">প্রিন্ট / PDF সংরক্ষণ</button>
    </div>
    <div class="hint">প্রিন্ট ডায়ালগে "Save as PDF" নির্বাচন করলে এটি PDF হিসেবেও সংরক্ষণ হবে।</div>
  `);
}
function doPrint(id, kind){
  const pa = document.getElementById('printArea');
  if(kind==='tx'){
    const t = state.transactions.find(x=>x.id===id);
    const m = state.members.find(x=>x.id===t.memberId);
    pa.innerHTML = receiptHtml(t,m);
  } else {
    const e = state.expenses.find(x=>x.id===id);
    pa.innerHTML = voucherHtml(e);
  }
  setTimeout(()=>{ window.print(); }, 80);
}
window.addEventListener('afterprint', ()=>{ const pa=document.getElementById('printArea'); if(pa) pa.innerHTML=''; });

/* ---------------- ORG SETTINGS ---------------- */
function openOrgEdit(){
  const u = currentUser();
  showSheet(`
    <h2>সেটিংস</h2>
    <div class="detail-card" style="margin-top:0;">
      <div class="kv"><span class="k">লগইনকৃত ব্যবহারকারী</span><span class="v">${u?u.name:''}</span></div>
      <div class="kv"><span class="k">রোল</span><span class="v">${u?u.role:''}</span></div>
      <div class="kv"><span class="k">সংরক্ষণ অবস্থা</span><span class="v" style="color:${offlineMode?'var(--danger)':'var(--primary)'}">${offlineMode?'অফলাইন (সংরক্ষণ হচ্ছে না)':'সংযুক্ত'}</span></div>
    </div>
    <div class="field" style="margin-top:14px;"><label>সমিতির নাম</label><input id="org_name" value="${state.orgName}"></div>
    <button class="btn block" onclick="saveOrgName()">নাম সংরক্ষণ করুন</button>
    ${canManageUsers()?`<button class="btn ghost block" style="margin-top:10px;" onclick="openUsersManagement()">ব্যবহারকারী ব্যবস্থাপনা</button>`:''}
    <div class="section-title" style="margin-top:20px;">ডেটা ব্যাকআপ</div>
    <div class="hint" style="margin-top:0;">নিয়মিত ব্যাকআপ ডাউনলোড করে রাখুন — সংরক্ষণে সমস্যা হলেও এই ফাইল থেকে ডেটা ফিরিয়ে আনতে পারবেন।</div>
    <div style="display:flex;gap:10px;margin-top:10px;">
      <button class="btn ghost" style="flex:1" onclick="exportData()">ডেটা এক্সপোর্ট</button>
      <button class="btn ghost" style="flex:1" onclick="document.getElementById('importFileInput').click()">ডেটা ইম্পোর্ট</button>
    </div>
    ${lastSaveError?`<div class="hint" style="margin-top:14px;color:var(--danger);">সর্বশেষ সংরক্ষণ ত্রুটি (কারিগরি): ${lastSaveError}</div>`:''}
    <button class="btn ghost block" style="margin-top:16px;border-color:var(--danger);color:var(--danger);" onclick="logout()">লগআউট</button>
  `);
}
function exportData(){
  const payload = JSON.stringify(state, null, 2);
  const blob = new Blob([payload], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const stamp = new Date().toISOString().slice(0,19).replace(/[:T]/g,'-');
  a.href = url; a.download = 'samity-backup-'+stamp+'.json';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url), 3000);
  toast('ব্যাকআপ ফাইল ডাউনলোড হচ্ছে');
}
function handleImportFile(input){
  const file = input.files && input.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = async ()=>{
    try{
      const parsed = JSON.parse(reader.result);
      if(!parsed || typeof parsed!=='object' || !Array.isArray(parsed.members)){
        toast('ফাইলটি সঠিক ব্যাকআপ ফরম্যাটে নেই'); return;
      }
      if(!confirm('বর্তমান ডেটার বদলে ব্যাকআপ ফাইলের ডেটা বসানো হবে। এগিয়ে যেতে চান?')) return;
      state = Object.assign(state, parsed);
      const ok = await saveState();
      if(!ok){ offerOfflineContinue(null); }
      closeSheet(); checkAuth();
      toast('ব্যাকআপ থেকে ডেটা ফিরিয়ে আনা হয়েছে');
    }catch(e){ toast('ফাইলটি পড়া যায়নি — সঠিক JSON ব্যাকআপ ফাইল নির্বাচন করুন'); }
    input.value='';
  };
  reader.readAsText(file);
}
async function saveOrgName(){
  const prev = state.orgName;
  state.orgName = document.getElementById('org_name').value.trim() || 'সমিতি হিসাব';
  const ok = await saveState();
  if(!ok){ const proceed = offerOfflineContinue(()=>{ state.orgName = prev; }); if(!proceed) return; }
  closeSheet(); renderTopStrip();
}

/* ---------------- SHEET / MODAL ---------------- */
function showSheet(html){
  closeSheet();
  const bd = document.createElement('div');
  bd.className='sheet-backdrop'; bd.id='sheetBackdrop';
  bd.onclick=(e)=>{ if(e.target.id==='sheetBackdrop') closeSheet(); };
  bd.innerHTML = `<div class="sheet"><div class="sheet-handle"></div>${html}</div>`;
  document.body.appendChild(bd);
}
function closeSheet(){
  const bd = document.getElementById('sheetBackdrop');
  if(bd) bd.remove();
}

/* ---------------- INIT ---------------- */
loadState();
