const KEY = 'safely_pwa_data_v4';

const D = {
  main_income_weekly: 800,
  possible_raise_weekly: 500,
  srd_grant: 370,
  tutoring_fee_per_student: 200,
  emergency_weekly: 50,
  mobile_kitchen_target: 3000,
  raise_activated: 0,
  theme: 'Midnight',
  font_size: 'Normal',
  currency: 'ZAR',
  locale: 'en-ZA',
  display_name: ''
};

const DEFAULT_FIXED = [
  { id: 'fe_cafe', name: 'Cafe rent', amount: 550, week: 1, active: true, year: null, month: null, category: 'Rent' },
  { id: 'fe_teaching', name: 'Teaching rent', amount: 300, week: 2, active: true, year: null, month: null, category: 'Rent' },
  { id: 'fe_a017', name: 'A017 payment', amount: 300, week: 4, active: true, year: null, month: null, category: 'Bills' },
  { id: 'fe_chatgpt', name: 'ChatGPT', amount: 150, week: 4, active: true, year: null, month: null, category: 'Subscriptions' },
  { id: 'fe_loan_w3', name: 'Loan repayment', amount: 400, week: 3, active: true, year: 2026, month: 8, category: 'Debt' },
  { id: 'fe_loan_w4', name: 'Loan repayment', amount: 300, week: 4, active: true, year: 2026, month: 8, category: 'Debt' }
];

let data = JSON.parse(localStorage.getItem(KEY) || 'null') || null;

// Migrate from v3 if present
if (!data) {
  try {
    const old = JSON.parse(localStorage.getItem('safely_pwa_data_v3') || 'null');
    if (old) data = old;
  } catch (_) {}
}

if (!data) {
  data = {
    settings: { ...D },
    transactions: [],
    students: [],
    savings: {
      Emergency: { balance: 0, target: 2500 },
      'Mobile Kitchen': { balance: 0, target: 3000 },
      'General Savings': { balance: 0, target: null }
    },
    notes: [],
    fixedExpenses: JSON.parse(JSON.stringify(DEFAULT_FIXED))
  };
}

data.settings = { ...D, ...(data.settings || {}) };
data.transactions = Array.isArray(data.transactions) ? data.transactions : [];
data.students = Array.isArray(data.students) ? data.students : [];
data.notes = Array.isArray(data.notes) ? data.notes : [];
data.savings = {
  Emergency: { balance: 0, target: 2500 },
  'Mobile Kitchen': { balance: 0, target: data.settings.mobile_kitchen_target || 3000 },
  'General Savings': { balance: 0, target: null },
  ...(data.savings || {})
};

if (!Array.isArray(data.fixedExpenses) || data.fixedExpenses.length === 0) {
  data.fixedExpenses = JSON.parse(JSON.stringify(DEFAULT_FIXED));
} else {
  data.fixedExpenses = data.fixedExpenses.map((fe, i) => ({
    id: fe.id || ('fe_' + Date.now() + '_' + i),
    name: fe.name || 'Fixed expense',
    amount: Math.max(0, Number(fe.amount) || 0),
    week: Math.min(4, Math.max(1, Number(fe.week) || 1)),
    active: fe.active !== false,
    year: fe.year != null && fe.year !== '' ? Number(fe.year) : null,
    month: fe.month != null && fe.month !== '' ? Number(fe.month) : null,
    category: fe.category || 'Bills'
  }));
}

function save() {
  localStorage.setItem(KEY, JSON.stringify(data));
}

function M(n) {
  const cur = data.settings.currency || 'ZAR';
  const loc = data.settings.locale || 'en-ZA';
  try {
    return new Intl.NumberFormat(loc, { style: 'currency', currency: cur, maximumFractionDigits: 2 }).format(Number(n || 0));
  } catch {
    return 'R' + Number(n || 0).toLocaleString('en-ZA', { maximumFractionDigits: 2 });
  }
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[c]));
}

function toast(t) {
  const x = document.getElementById('toast');
  x.textContent = t;
  x.classList.add('show');
  setTimeout(() => x.classList.remove('show'), 1600);
}

function today() { return new Date(); }
function iso(d = today()) { return d.toISOString().slice(0, 10); }
function W(d) {
  const day = d.getDate();
  if (day <= 7) return 1;
  if (day <= 14) return 2;
  if (day <= 21) return 3;
  return 4;
}

function monthWeeks(y, m) {
  const last = new Date(y, m, 0).getDate();
  const a = [];
  for (let s = 1, w = 1; s <= last; s += 7, w++) {
    a.push({ w, start: new Date(y, m - 1, s), end: new Date(y, m - 1, Math.min(s + 6, last)) });
  }
  return a;
}

function income() {
  return Number(data.settings.main_income_weekly || 0) +
    (data.settings.raise_activated ? Number(data.settings.possible_raise_weekly || 0) : 0);
}

function payments(d) {
  const w = W(d);
  const y = d.getFullYear();
  const m = d.getMonth() + 1;
  const a = [];
  (data.fixedExpenses || []).forEach(fe => {
    if (!fe.active) return;
    if (Number(fe.week) !== w) return;
    if (fe.year != null && Number(fe.year) !== y) return;
    if (fe.month != null && Number(fe.month) !== m) return;
    a.push([fe.name, Number(fe.amount) || 0, fe.id]);
  });
  return a;
}

function summary(d = today()) {
  const p = payments(d);
  const i = income();
  const o = p.reduce((s, x) => s + x[1], 0);
  return { income: i, out: o, available: i - o, p };
}

function health() {
  const s = summary();
  const em = data.savings.Emergency?.balance || 0;
  const mk = data.savings['Mobile Kitchen'] || { balance: 0, target: 3000 };
  const t = mk.target || data.settings.mobile_kitchen_target || 3000;
  const n = data.students.length;
  const rev = n * Number(data.settings.tutoring_fee_per_student || 0);
  let cost = 0;
  (data.fixedExpenses || []).forEach(fe => {
    if (!fe.active) return;
    const nm = (fe.name || '').toLowerCase();
    if (nm.includes('teaching') || nm.includes('a017')) cost += Number(fe.amount) || 0;
  });
  const a = Math.round(Math.max(0, Math.min(1, s.available / Math.max(1, s.income))) * 30);
  const b = Math.round(Math.min(1, em / Math.max(1, data.settings.emergency_weekly * 10)) * 25);
  const c = Math.round(Math.min(1, (mk.balance || 0) / Math.max(1, t)) * 25);
  const q = cost ? Math.round(Math.max(0, Math.min(1, (rev - cost) / cost)) * 20) : 0;
  const total = a + b + c + q;
  return {
    total,
    label: total >= 80 ? 'Excellent' : total >= 60 ? 'Healthy' : total >= 40 ? 'Fair' : total >= 20 ? 'At risk' : 'Critical',
    parts: [a, b, c, q]
  };
}

function alloc() {
  let r = Math.max(0, summary().available);
  const out = [];
  let x = Math.min(r, Number(data.settings.emergency_weekly || 0));
  r -= x; out.push(['Emergency', x]);
  x = r * 0.25; r -= x; out.push(['Food', x]);
  x = r * 0.35; r -= x; out.push(['General Savings', x]);
  x = r * 0.5; r -= x; out.push(['Mobile Kitchen', x]);
  out.push(['Discretionary', r]);
  return out;
}

function horizon(months) {
  const from = today();
  const start = new Date(from.getFullYear(), from.getMonth(), 1);
  const end = new Date(from.getFullYear(), from.getMonth() + months, 0);
  const startIso = iso(start);
  const endIso = iso(end);
  let scheduledIncome = 0, scheduledFixed = 0;
  const points = [];
  for (let i = 0; i < months; i++) {
    const date = new Date(start.getFullYear(), start.getMonth() + i, 1);
    const weeks = monthWeeks(date.getFullYear(), date.getMonth() + 1);
    let inc = 0, fix = 0;
    weeks.forEach(w => {
      const s = summary(w.start);
      inc += s.income;
      fix += s.out;
    });
    scheduledIncome += inc;
    scheduledFixed += fix;
    points.push({
      label: date.toLocaleString('en', { month: 'short', year: '2-digit' }),
      income: inc, fixed: fix, leftover: inc - fix
    });
  }
  const logged = data.transactions.filter(t => t.date >= startIso && t.date <= endIso);
  const loggedIncome = logged.filter(t => t.kind === 'income').reduce((s, t) => s + Number(t.amount || 0), 0);
  const loggedExpense = logged.filter(t => t.kind === 'expense').reduce((s, t) => s + Number(t.amount || 0), 0);
  const savings = Object.values(data.savings).reduce((s, g) => s + Number(g.balance || 0), 0);
  const leftover = scheduledIncome - scheduledFixed;
  const combined = leftover + loggedIncome - loggedExpense;
  return {
    months, start, end, scheduledIncome, scheduledFixed, leftover,
    loggedIncome, loggedExpense, combined, savings,
    projectedCash: savings + combined,
    perMonth: {
      income: scheduledIncome / months,
      fixed: scheduledFixed / months,
      leftover: leftover / months
    },
    points, logged
  };
}

const quotes = [
  'Build assets before upgrading lifestyle.',
  'Every rand needs a job.',
  'Protect cash flow before chasing growth.',
  'Small consistent savings beat heroic intentions.',
  'A budget is a decision made before the temptation.'
];

function closeModal() {
  const m = document.getElementById('modal');
  if (m) m.remove();
}

function openModal(title, bodyHtml, onSubmit) {
  closeModal();
  const el = document.createElement('div');
  el.id = 'modal';
  el.innerHTML = `
    <div class="modal-backdrop" data-close="1"></div>
    <div class="modal-card" role="dialog" aria-modal="true">
      <div class="modal-head">
        <strong>${esc(title)}</strong>
        <button type="button" class="btn" data-close="1" style="padding:6px 10px">Close</button>
      </div>
      <form id="modalForm" class="form">${bodyHtml}
        <button type="submit" class="btn primary">Save</button>
      </form>
    </div>`;
  document.body.appendChild(el);
  el.querySelectorAll('[data-close]').forEach(b => b.onclick = closeModal);
  document.getElementById('modalForm').onsubmit = (e) => {
    e.preventDefault();
    if (onSubmit(e)) closeModal();
  };
}

function home() {
  const d = today(), s = summary(), h = health();
  const mk = data.savings['Mobile Kitchen'] || { balance: 0, target: 3000 };
  const pct = Math.min(100, Math.round((mk.balance || 0) / Math.max(1, mk.target || 1) * 100));
  const pressure = s.available < 0 ? 'Critical' : s.income && s.available / s.income < 0.15 ? 'High pressure' : s.available / s.income < 0.5 ? 'Tight' : 'Healthy';
  const name = data.settings.display_name ? `Hello, ${esc(data.settings.display_name)}` : 'Financial command centre';
  document.getElementById('home').innerHTML = `
    <div class="title">${name}</div>
    <div class="quote">${quotes[d.getDate() % quotes.length]}</div>
    <div class="quick">
      <button class="btn primary" data-action="money-income">+ Income</button>
      <button class="btn" data-action="money-expense">+ Expense</button>
      <button class="btn" data-action="show-goals">+ Savings</button>
    </div>
    <div class="card">
      <h2>TODAY</h2>
      <div class="big">${d.toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</div>
      <div class="small">Financial week W${W(d)}</div>
    </div>
    <div class="card">
      <h2>THIS WEEK</h2>
      <div class="grid3">
        <div><div class="small">Income</div><strong class="green">${M(s.income)}</strong></div>
        <div><div class="small">Obligations</div><strong class="orange">${M(s.out)}</strong></div>
        <div><div class="small">Available</div><strong class="accent">${M(s.available)}</strong></div>
      </div>
      <div class="small" style="margin-top:9px">${s.p.map(x => esc(x[0]) + ' (' + M(x[1]) + ')').join(' · ') || 'No payments scheduled'}</div>
      <strong class="${pressure === 'Healthy' ? 'green' : pressure === 'Tight' ? 'yellow' : 'red'}">${pressure}</strong>
    </div>
    <div class="card">
      <h2>FINANCIAL HEALTH</h2>
      <div class="big">${h.total}/100 · ${h.label}</div>
      <div class="progress"><i style="width:${h.total}%"></i></div>
      <div class="small">Cash flow ${h.parts[0]}/30 · Emergency ${h.parts[1]}/25 · Assets ${h.parts[2]}/25 · Business ${h.parts[3]}/20</div>
    </div>
    <div class="card">
      <h2>SMART ALLOCATION</h2>
      ${alloc().map(x => `<div class="item"><span>${esc(x[0])}</span><b>${M(x[1])}</b></div>`).join('')}
      <div class="small">Advisory only. Nothing moves automatically.</div>
    </div>
    <div class="grid">
      <div class="card">
        <h2>EMERGENCY</h2>
        <div class="big">${M(data.savings.Emergency?.balance || 0)}</div>
        <div class="small">+${M(data.settings.emergency_weekly)}/week planned</div>
      </div>
      <div class="card">
        <h2>MOBILE KITCHEN</h2>
        <div class="big">${M(mk.balance || 0)}</div>
        <div class="progress"><i style="width:${pct}%"></i></div>
        <div class="small">${pct}% · ${M(Math.max(0, (mk.target || 0) - (mk.balance || 0)))} remaining</div>
      </div>
    </div>
    <div class="card">
      <h2>TUTORING</h2>
      <div class="big">${data.students.length} students</div>
      <div class="small">${M(data.students.reduce((a, x) => a + Number(x.fee || 0), 0))}/month estimated</div>
    </div>
    <div class="card" style="border-color:var(--accent);cursor:pointer" data-action="show-horizon">
      <h2>LOOK AHEAD</h2>
      <div class="small">See income and bills for the next 1–12 months</div>
    </div>
    <div class="principle">BUILD ASSETS BEFORE UPGRADING LIFESTYLE</div>`;
}

function moneyForm(kind = 'income') {
  try {
    const root = document.getElementById('money');
    const s = summary();
    const fixedList = (data.fixedExpenses || []).slice().sort((a, b) => a.week - b.week || a.name.localeCompare(b.name));
    const fixedHtml = fixedList.length
      ? fixedList.map(fe => {
          const scope = (fe.year != null || fe.month != null)
            ? ` · ${fe.month ? fe.month + '/' : ''}${fe.year || ''}`
            : ' · every month';
          return `
            <div class="item" style="flex-wrap:wrap" data-fe-id="${esc(fe.id)}">
              <div style="flex:1;min-width:140px">
                <b>${esc(fe.name)}</b>
                <div class="small">W${fe.week}${scope}${fe.active ? '' : ' · inactive'}${fe.category ? ' · ' + esc(fe.category) : ''}</div>
              </div>
              <b class="orange">${M(fe.amount)}</b>
              <div class="row" style="margin-top:6px;width:100%">
                <button type="button" class="btn" data-action="edit-fe" data-id="${esc(fe.id)}">Edit</button>
                <button type="button" class="btn danger" data-action="delete-fe" data-id="${esc(fe.id)}">Delete</button>
              </div>
            </div>`;
        }).join('')
      : '<div class="small">No fixed expenses defined. Add one below.</div>';

    const txs = Array.isArray(data.transactions) ? data.transactions : [];
    const recent = txs.slice().reverse().slice(0, 40).map(x => {
      const amount = Number(x.amount || 0);
      return `
        <div class="item">
          <div>
            <b>${esc(x.label || 'Transaction')}</b>
            <div class="small">${esc(x.category || 'Other')} · ${esc(x.date || '')}</div>
          </div>
          <div style="text-align:right">
            <b class="${x.kind === 'income' ? 'green' : 'orange'}">${x.kind === 'income' ? '+' : '-'}${M(amount)}</b>
            <div><button type="button" class="btn" style="padding:4px 8px;font-size:11px;margin-top:4px" data-action="delete-tx" data-id="${esc(x.id || '')}">Delete</button></div>
          </div>
        </div>`;
    }).join('') || '<div class="small">No transactions recorded yet.</div>';

    const incomeRules = [
      ['main_income_weekly', 'Main weekly income'],
      ['possible_raise_weekly', 'Possible weekly raise'],
      ['srd_grant', 'SRD grant'],
      ['emergency_weekly', 'Emergency saving (weekly plan)'],
      ['tutoring_fee_per_student', 'Tutoring fee / student']
    ];

    root.innerHTML = `
      <div class="title">Money & expenses</div>
      <div class="card">
        <h2>THIS WEEK</h2>
        <div class="grid3">
          <div><div class="small">Income</div><strong class="green">${M(s.income)}</strong></div>
          <div><div class="small">Expenses</div><strong class="orange">${M(s.out)}</strong></div>
          <div><div class="small">Available</div><strong class="accent">${M(s.available)}</strong></div>
        </div>
        <div class="small" style="margin-top:9px">${s.p.length ? s.p.map(x => esc(x[0]) + ' (' + M(x[1]) + ')').join(' · ') : 'No scheduled fixed payments'}</div>
      </div>
      <div class="card">
        <h2>RECORD TRANSACTION</h2>
        <form class="form" id="txForm">
          <div class="row">
            <select id="txKind">
              <option value="income" ${kind === 'income' ? 'selected' : ''}>Income</option>
              <option value="expense" ${kind === 'expense' ? 'selected' : ''}>Expense</option>
            </select>
            <input id="txAmt" type="number" step="0.01" min="0.01" placeholder="Amount" required>
          </div>
          <input id="txLabel" placeholder="Description" required>
          <input id="txCat" placeholder="Category (optional)">
          <button type="submit" class="btn primary">Save transaction</button>
        </form>
      </div>
      <div class="card">
        <h2>INCOME & WEEKLY SETTINGS</h2>
        <form class="form" id="rulesForm">
          ${incomeRules.map(([k, label]) => `
            <label class="small">${esc(label)}
              <input id="rule_${k}" type="number" step="0.01" min="0" value="${Number(data.settings[k] || 0)}">
            </label>`).join('')}
          <button type="submit" class="btn primary">Save income settings</button>
        </form>
      </div>
      <div class="card">
        <h2>FIXED EXPENSE TYPES</h2>
        <div class="small" style="margin-bottom:10px">Add, edit, or delete recurring bills by financial week (W1–W4). Optional year/month for limited periods.</div>
        <div class="list">${fixedHtml}</div>
        <div style="margin-top:14px;border-top:1px solid var(--border);padding-top:12px">
          <button type="button" class="btn primary" data-action="add-fe">Add fixed expense</button>
        </div>
      </div>
      <div class="card">
        <h2>RECENT ACTIVITY</h2>
        <div class="list">${recent}</div>
      </div>`;

    document.getElementById('txForm').onsubmit = (e) => {
      e.preventDefault();
      const k = document.getElementById('txKind').value;
      const a = Number(document.getElementById('txAmt').value);
      const label = document.getElementById('txLabel').value.trim();
      const cat = document.getElementById('txCat').value.trim() || 'Other';
      if (!a || a <= 0 || !label) return;
      data.transactions.push({
        id: 'tx_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
        date: iso(), kind: k, amount: a, label, category: cat
      });
      save();
      moneyForm(k);
      toast('Transaction saved');
    };

    document.getElementById('rulesForm').onsubmit = (e) => {
      e.preventDefault();
      incomeRules.forEach(([k]) => {
        const el = document.getElementById('rule_' + k);
        if (el) data.settings[k] = Math.max(0, Number(el.value) || 0);
      });
      save();
      moneyForm();
      home();
      toast('Income settings saved');
    };
  } catch (err) {
    console.error(err);
    document.getElementById('money').innerHTML = `<div class="title">Money</div><div class="card"><h2>ERROR</h2><div class="small">${esc(String(err.message || err))}</div></div>`;
  }
}

function openFixedForm(existing) {
  const fe = existing || {
    id: '', name: '', amount: 0, week: 1, active: true, year: null, month: null, category: 'Bills'
  };
  openModal(existing ? 'Edit fixed expense' : 'Add fixed expense', `
    <label class="small">Name<input id="m_name" required value="${esc(fe.name)}"></label>
    <div class="row">
      <label class="small">Amount<input id="m_amt" type="number" min="0" step="0.01" required value="${fe.amount || ''}"></label>
      <label class="small">Week
        <select id="m_week">
          <option value="1" ${fe.week === 1 ? 'selected' : ''}>Week 1</option>
          <option value="2" ${fe.week === 2 ? 'selected' : ''}>Week 2</option>
          <option value="3" ${fe.week === 3 ? 'selected' : ''}>Week 3</option>
          <option value="4" ${fe.week === 4 ? 'selected' : ''}>Week 4</option>
        </select>
      </label>
    </div>
    <label class="small">Category<input id="m_cat" value="${esc(fe.category || 'Bills')}"></label>
    <div class="row">
      <label class="small">Year (optional)<input id="m_year" type="number" min="2020" max="2100" placeholder="Every year" value="${fe.year != null ? fe.year : ''}"></label>
      <label class="small">Month 1–12 (optional)<input id="m_month" type="number" min="1" max="12" placeholder="Every month" value="${fe.month != null ? fe.month : ''}"></label>
    </div>
    <label class="small"><input id="m_active" type="checkbox" ${fe.active !== false ? 'checked' : ''}> Active</label>
  `, () => {
    const name = document.getElementById('m_name').value.trim();
    const amount = Math.max(0, Number(document.getElementById('m_amt').value) || 0);
    const week = Math.min(4, Math.max(1, Number(document.getElementById('m_week').value) || 1));
    const yearRaw = document.getElementById('m_year').value;
    const monthRaw = document.getElementById('m_month').value;
    const year = yearRaw === '' ? null : Number(yearRaw);
    const month = monthRaw === '' ? null : Number(monthRaw);
    if (!name) { toast('Name required'); return false; }
    if (year != null && (isNaN(year) || year < 2020 || year > 2100)) { toast('Invalid year'); return false; }
    if (month != null && (isNaN(month) || month < 1 || month > 12)) { toast('Invalid month'); return false; }
    const row = {
      id: fe.id || ('fe_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7)),
      name, amount, week,
      active: document.getElementById('m_active').checked,
      year: year != null && !isNaN(year) ? year : null,
      month: month != null && !isNaN(month) ? month : null,
      category: document.getElementById('m_cat').value.trim() || 'Bills'
    };
    data.fixedExpenses = Array.isArray(data.fixedExpenses) ? data.fixedExpenses : [];
    const idx = data.fixedExpenses.findIndex(x => x.id === row.id);
    if (idx >= 0) data.fixedExpenses[idx] = row;
    else data.fixedExpenses.push(row);
    save();
    moneyForm();
    home();
    toast(existing ? 'Fixed expense updated' : 'Fixed expense added');
    return true;
  });
}

function horizonScreen(months = 3) {
  const h = horizon(months);
  const maxBar = Math.max(1, ...h.points.map(p => Math.max(p.income, p.fixed)));
  document.getElementById('horizon').innerHTML = `
    <div class="title">Horizon</div>
    <div class="small" style="margin-bottom:10px">Income, bills, and leftover over a chosen stretch of time.</div>
    <div class="row" style="margin-bottom:12px">
      ${[1, 3, 6, 12].map(m => `<button class="btn ${months === m ? 'primary' : ''}" data-action="horizon-m" data-m="${m}">${m} mo</button>`).join('')}
    </div>
    <div class="card">
      <h2>${h.start.toLocaleString('en', { month: 'short', year: 'numeric' })} – ${h.end.toLocaleString('en', { month: 'short', year: 'numeric' })}</h2>
      <div class="grid3">
        <div><div class="small">Scheduled income</div><strong class="green">${M(h.scheduledIncome)}</strong></div>
        <div><div class="small">Scheduled bills</div><strong class="orange">${M(h.scheduledFixed)}</strong></div>
        <div><div class="small">Leftover</div><strong class="accent">${M(h.leftover)}</strong></div>
      </div>
      <div class="grid3" style="margin-top:10px">
        <div><div class="small">Logged income</div><b>${M(h.loggedIncome)}</b></div>
        <div><div class="small">Logged spending</div><b>${M(h.loggedExpense)}</b></div>
        <div><div class="small">Combined</div><b class="accent">${M(h.combined)}</b></div>
      </div>
      <div class="small" style="margin-top:8px">Average month: ${M(h.perMonth.income)} in · ${M(h.perMonth.fixed)} out · ${M(h.perMonth.leftover)} left</div>
    </div>
    <div class="card">
      <h2>CASH POSITION</h2>
      <div class="big">${M(h.projectedCash)}</div>
      <div class="small">Savings now ${M(h.savings)} plus combined outlook if this pattern continues.</div>
    </div>
    <div class="card">
      <h2>MONTH BY MONTH</h2>
      ${h.points.map(p => `
        <div class="barrow"><span>${esc(p.label)}</span><div class="bar"><i style="width:${p.income / maxBar * 100}%"></i></div><b>${M(p.income)}</b></div>
        <div class="barrow"><span>Bills</span><div class="bar"><i style="width:${p.fixed / maxBar * 100}%;background:var(--orange)"></i></div><b>${M(p.fixed)}</b></div>
        <div class="small" style="margin-bottom:8px">Left ${M(p.leftover)}</div>
      `).join('')}
    </div>`;
}

function calendar() {
  const d = today();
  const ws = monthWeeks(d.getFullYear(), d.getMonth() + 1);
  document.getElementById('calendar').innerHTML =
    '<div class="title">' + d.toLocaleString('en', { month: 'long', year: 'numeric' }) + '</div>' +
    ws.map(w => {
      const s = summary(w.start);
      return `
        <div class="card">
          <h2>W${w.w} · ${w.start.getDate()}–${w.end.getDate()}</h2>
          <div class="grid3">
            <div><div class="small">Income</div><b class="green">${M(s.income)}</b></div>
            <div><div class="small">Out</div><b class="orange">${M(s.out)}</b></div>
            <div><div class="small">Left</div><b class="accent">${M(s.available)}</b></div>
          </div>
          <div class="small" style="margin-top:8px">${s.p.map(x => esc(x[0]) + ' ' + M(x[1])).join(' · ') || 'No scheduled payments'}</div>
        </div>`;
    }).join('');
}

function goals() {
  document.getElementById('goals').innerHTML = `
    <div class="title">Goals & savings</div>
    ${Object.entries(data.savings).map(([n, x]) => {
      const p = x.target ? Math.min(100, Math.round(x.balance / x.target * 100)) : null;
      return `
        <div class="card">
          <h2>${esc(n)}</h2>
          <div class="big">${M(x.balance)}${x.target ? ' / ' + M(x.target) : ''}</div>
          ${p !== null ? `<div class="progress"><i style="width:${p}%"></i></div><div class="small">${p}% complete</div>` : ''}
        </div>`;
    }).join('')}
    <div class="card">
      <h2>CONTRIBUTE</h2>
      <form class="form" id="goalForm">
        <select id="gn">${Object.keys(data.savings).map(n => `<option>${esc(n)}</option>`).join('')}</select>
        <input id="ga" type="number" min=".01" step=".01" placeholder="Amount" required>
        <button class="btn primary">Add savings</button>
      </form>
    </div>
    <div class="card">
      <h2>TUTORING</h2>
      ${data.students.map((s, i) => `
        <div class="item">
          <span>${esc(s.name)}<div class="small">${M(s.fee)}/month</div></span>
          <button class="btn" data-action="del-student" data-i="${i}">Remove</button>
        </div>`).join('')}
      <form class="form" id="studentForm" style="margin-top:9px">
        <input id="sn" placeholder="Student name" required>
        <input id="sf" type="number" value="200">
        <button class="btn primary">Add student</button>
      </form>
    </div>`;
  document.getElementById('goalForm').onsubmit = (e) => {
    e.preventDefault();
    data.savings[gn.value].balance += Number(ga.value);
    save(); goals(); home(); toast('Savings updated');
  };
  document.getElementById('studentForm').onsubmit = (e) => {
    e.preventDefault();
    data.students.push({ name: sn.value, fee: Number(sf.value) || 200 });
    save(); goals(); home(); toast('Student added');
  };
}

function analytics() {
  const d = today();
  const ws = monthWeeks(d.getFullYear(), d.getMonth() + 1);
  const mx = Math.max(1, ...ws.map(w => summary(w.start).income));
  const cats = {};
  data.transactions.filter(x => x.kind === 'expense').forEach(x => {
    cats[x.category] = (cats[x.category] || 0) + x.amount;
  });
  const fixedByWeek = [0, 0, 0, 0, 0];
  (data.fixedExpenses || []).forEach(fe => {
    if (!fe.active) return;
    const now = today();
    if (fe.year != null && fe.year !== now.getFullYear()) return;
    if (fe.month != null && fe.month !== now.getMonth() + 1) return;
    fixedByWeek[fe.week] += Number(fe.amount) || 0;
  });
  const monthlyFixed = fixedByWeek.reduce((a, b) => a + b, 0);
  document.getElementById('analytics').innerHTML = `
    <div class="title">Analytics</div>
    <div class="card">
      <h2>WEEKLY CASH FLOW</h2>
      ${ws.map((w, i) => {
        const s = summary(w.start);
        return `
          <div class="barrow"><span>W${i + 1}</span><div class="bar"><i style="width:${s.income / mx * 100}%"></i></div><b>${M(s.income)}</b></div>
          <div class="barrow"><span>Out</span><div class="bar"><i style="width:${s.out / mx * 100}%;background:var(--orange)"></i></div><b>${M(s.out)}</b></div>`;
      }).join('')}
    </div>
    <div class="card">
      <h2>FIXED EXPENSES THIS MONTH</h2>
      <div class="grid3">
        <div><div class="small">W1</div><b class="orange">${M(fixedByWeek[1])}</b></div>
        <div><div class="small">W2</div><b class="orange">${M(fixedByWeek[2])}</b></div>
        <div><div class="small">W3</div><b class="orange">${M(fixedByWeek[3])}</b></div>
      </div>
      <div class="grid3" style="margin-top:8px">
        <div><div class="small">W4</div><b class="orange">${M(fixedByWeek[4])}</b></div>
        <div><div class="small">Total</div><b class="orange">${M(monthlyFixed)}</b></div>
      </div>
    </div>
    <div class="card">
      <h2>EXPENSE BREAKDOWN (logged)</h2>
      ${Object.entries(cats).sort((a, b) => b[1] - a[1]).map(x => `
        <div class="item"><span>${esc(x[0])}</span><b class="orange">${M(x[1])}</b></div>`).join('') ||
        '<div class="small">No logged expenses.</div>'}
    </div>`;
}

function more() {
  document.getElementById('more').innerHTML = `
    <div class="title">More</div>
    <div class="card">
      <h2>DAILY NOTES</h2>
      <textarea id="note" placeholder="Record a decision, win, warning or observation"></textarea>
      <button class="btn primary" style="margin-top:8px" data-action="add-note">Save note</button>
      ${data.notes.slice().reverse().slice(0, 6).map(n => `
        <div class="item"><span>${esc(n.text)}<div class="small">${esc(n.date)}</div></span></div>`).join('')}
    </div>
    <div class="card">
      <h2>WHAT-IF</h2>
      <div class="form">
        <input id="raise" type="number" value="${Number(data.settings.possible_raise_weekly || 0)}" placeholder="Weekly raise">
        <input id="stud" type="number" value="${data.students.length}" placeholder="Students">
        <button class="btn primary" data-action="whatif">Calculate</button>
        <div class="small" id="result">No scenario calculated.</div>
      </div>
    </div>
    <div class="card">
      <h2>SETTINGS</h2>
      <div class="form">
        <input id="dispName" placeholder="Your name" value="${esc(data.settings.display_name || '')}">
        <select id="currency">
          ${[['ZAR','en-ZA'],['USD','en-US'],['GBP','en-GB'],['EUR','en-IE']].map(([c,l]) =>
            `<option value="${c}" data-locale="${l}" ${data.settings.currency===c?'selected':''}>${c}</option>`).join('')}
        </select>
        <select id="theme">
          <option ${data.settings.theme==='Midnight'?'selected':''}>Midnight</option>
          <option ${data.settings.theme==='Classic Elite'?'selected':''}>Classic Elite</option>
          <option ${data.settings.theme==='Academic'?'selected':''}>Academic</option>
          <option ${data.settings.theme==='Neon'?'selected':''}>Neon</option>
          <option ${data.settings.theme==='Glass'?'selected':''}>Glass</option>
        </select>
        <select id="font">
          <option ${data.settings.font_size==='Normal'?'selected':''}>Normal</option>
          <option ${data.settings.font_size==='Large'?'selected':''}>Large</option>
          <option ${data.settings.font_size==='Extra Large'?'selected':''}>Extra Large</option>
        </select>
        <label class="small"><input id="ractive" type="checkbox" ${data.settings.raise_activated?'checked':''}> Include possible raise in forecast</label>
        <input id="target" type="number" value="${data.settings.mobile_kitchen_target}" placeholder="Mobile Kitchen target">
        <button class="btn primary" data-action="settings-save">Save settings</button>
        <button class="btn" data-action="show-money">Edit income & fixed expenses</button>
      </div>
    </div>
    <div class="card">
      <h2>BACKUP</h2>
      <div class="small">All data stays on this device. Export before clearing browser storage.</div>
      <div class="row" style="margin-top:8px">
        <button class="btn" data-action="export">Export JSON</button>
        <label class="btn">Import JSON<input type="file" accept=".json" id="importFile" hidden></label>
      </div>
      <button class="btn danger" style="margin-top:8px" data-action="reset">Reset local data</button>
    </div>`;
  document.getElementById('importFile').onchange = importData;
}

function themeApply() {
  const t = data.settings.theme || 'Midnight';
  const x = {
    Midnight: ['#0f1115', '#1b1f27', '#232833', '#f2f3f5', '#9aa3b2', '#4cc9f0'],
    'Classic Elite': ['#f5f7fa', '#fff', '#edf0f5', '#172033', '#667085', '#3157d5'],
    Academic: ['#f4f0e7', '#fffdf7', '#eae3d3', '#302b23', '#746c60', '#7a4e2d'],
    Neon: ['#101015', '#191922', '#22222e', '#f8f8ff', '#a9a9b8', '#c45cff'],
    Glass: ['#eaf4f6', '#f9feff', '#dceef1', '#15323a', '#637e86', '#168aa3']
  }[t] || null;
  if (x) {
    const s = document.documentElement.style;
    s.setProperty('--bg', x[0]);
    s.setProperty('--card', x[1]);
    s.setProperty('--alt', x[2]);
    s.setProperty('--text', x[3]);
    s.setProperty('--muted', x[4]);
    s.setProperty('--accent', x[5]);
  }
  document.body.style.fontSize = ({ Normal: 1, Large: 1.08, 'Extra Large': 1.16 }[data.settings.font_size] || 1) + 'em';
}

function exportData() {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  a.download = 'safely-backup-' + iso() + '.json';
  a.click();
}

function importData(e) {
  const f = e.target.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    try {
      data = JSON.parse(r.result);
      if (!Array.isArray(data.fixedExpenses)) data.fixedExpenses = JSON.parse(JSON.stringify(DEFAULT_FIXED));
      save();
      location.reload();
    } catch {
      toast('Invalid backup');
    }
  };
  r.readAsText(f);
}

function show(id) {
  document.querySelectorAll('.screen').forEach(x => x.classList.remove('active'));
  const el = document.getElementById(id);
  if (el) el.classList.add('active');
  document.querySelectorAll('.nav button').forEach(x => x.classList.toggle('active', x.dataset.s === id));
  const map = {
    home, money: () => moneyForm(), horizon: () => horizonScreen(3),
    calendar, goals, analytics, more
  };
  (map[id] || home)();
}

document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-action]');
  if (!t) return;
  const a = t.dataset.action;
  if (a === 'money-income') { show('money'); moneyForm('income'); }
  else if (a === 'money-expense') { show('money'); moneyForm('expense'); }
  else if (a === 'show-goals') show('goals');
  else if (a === 'show-horizon') show('horizon');
  else if (a === 'show-money') show('money');
  else if (a === 'horizon-m') horizonScreen(Number(t.dataset.m) || 3);
  else if (a === 'add-fe') openFixedForm(null);
  else if (a === 'edit-fe') {
    const fe = (data.fixedExpenses || []).find(x => x.id === t.dataset.id);
    if (fe) openFixedForm(fe);
  }
  else if (a === 'delete-fe') {
    if (!confirm('Delete this fixed expense type?')) return;
    data.fixedExpenses = (data.fixedExpenses || []).filter(x => x.id !== t.dataset.id);
    save(); moneyForm(); home(); toast('Fixed expense deleted');
  }
  else if (a === 'delete-tx') {
    if (!confirm('Delete this transaction?')) return;
    data.transactions = (data.transactions || []).filter(x => x.id !== t.dataset.id);
    save(); moneyForm(); toast('Transaction deleted');
  }
  else if (a === 'del-student') {
    data.students.splice(Number(t.dataset.i), 1);
    save(); goals(); home();
  }
  else if (a === 'add-note') {
    const note = document.getElementById('note');
    if (!note || !note.value.trim()) return;
    data.notes.push({ date: iso(), text: note.value.trim() });
    save(); more(); toast('Note saved');
  }
  else if (a === 'whatif') {
    const r = Number(document.getElementById('raise').value) || 0;
    const n = Number(document.getElementById('stud').value) || 0;
    const inc = Number(data.settings.main_income_weekly || 0) + r;
    const pay = summary().out;
    document.getElementById('result').innerHTML =
      `Scenario weekly income: <b>${M(inc)}</b><br>After scheduled obligations: <b>${M(inc - pay)}</b><br>Tutoring revenue: <b>${M(n * Number(data.settings.tutoring_fee_per_student || 0))}/month</b>`;
  }
  else if (a === 'settings-save') {
    data.settings.display_name = document.getElementById('dispName').value.trim();
    const cur = document.getElementById('currency');
    data.settings.currency = cur.value;
    data.settings.locale = cur.selectedOptions[0]?.dataset.locale || 'en-ZA';
    data.settings.theme = theme.value;
    data.settings.font_size = font.value;
    data.settings.raise_activated = ractive.checked ? 1 : 0;
    data.settings.mobile_kitchen_target = Number(target.value) || 3000;
    if (data.savings['Mobile Kitchen']) data.savings['Mobile Kitchen'].target = data.settings.mobile_kitchen_target;
    save(); themeApply(); more(); home(); toast('Settings saved');
  }
  else if (a === 'export') exportData();
  else if (a === 'reset') {
    if (confirm('Reset all Safely data stored on this device?')) {
      localStorage.removeItem(KEY);
      localStorage.removeItem('safely_pwa_data_v3');
      location.reload();
    }
  }
});

document.querySelectorAll('.nav button').forEach(x => (x.onclick = () => show(x.dataset.s)));
document.getElementById('today').textContent = today().toLocaleDateString('en-ZA', {
  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
});
themeApply();
home();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
