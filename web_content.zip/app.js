// Jil Std 11 & 12 Science PRO
// Mobile-first HTML app. Works in an HTML->APK WebView.
// Firebase is included as requested. Client Firebase apiKey is not a password/secret.
// Real admin authorization must be enforced with Firebase Auth + Firestore/Storage Rules.

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, deleteDoc, doc, serverTimestamp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyBikZocqAIowHgjY8DVatclwaB1m32zt_0",
  authDomain: "jil-std-11-12-pro.firebaseapp.com",
  projectId: "jil-std-11-12-pro",
  storageBucket: "jil-std-11-12-pro.firebasestorage.app",
  messagingSenderId: "12217113174",
  appId: "1:12217113174:web:a69bbc7144189f56c8f9f7",
  measurementId: "G-V5BBQ0KNDH"
};

const fb = initializeApp(firebaseConfig);
const db = getFirestore(fb);

const ADMIN_HASH = "87e156f83b5ad9d9035f9f7370b0b1394fff1e0496f13c8356f7988256ad502f"; // SHA-256("Sat Shree 108")
const KEY = "jil_std1112_pro_data_v1";
const DOWNLOAD_KEY = "jil_std1112_pro_downloads_v1";

const data = {
  "11": {
    Physics:[
      "એકમ અને માપન","સુરેખ પથ પર ગતિ","સમતલમાં ગતિ","ગતિના નિયમો","કાર્ય, ઉર્જા અને પાવર","કણોના તંત્ર અને ચાકગતિ","ગુરુત્વાકર્ષણ","ઘન પદાર્થોના યાંત્રિક ગુણધર્મો","પ્રવાહીના યાંત્રિક ગુણધર્મો","દ્રવ્યના તાપીય ગુણધર્મો","થર્મોડાયનેમિક્સ","ગતિવાદ","દોલનો","તરંગો"
    ],
    Chemistry:[
      "રસાયણવિજ્ઞાનની કેટલીક પાયાની સંકલ્પનાઓ","પરમાણુનું બંધારણ","તત્ત્વોનું વર્ગીકરણ અને ગુણધર્મોમાં આવર્તીયતા","રાસાયણિક બંધન અને આણ્વીય રચના","દ્રવ્યની અવસ્થાઓ: વાયુ અને પ્રવાહી","ઉષ્માગતિશાસ્ત્ર","સંતુલન","રેડોક્સ પ્રક્રિયાઓ","હાઇડ્રોજન","s-વિભાગના તત્ત્વો","p-વિભાગના તત્ત્વો (સમૂહ 13 અને 14)","કાર્બનિક રસાયણવિજ્ઞાન: કેટલાક પાયાના સિદ્ધાંતો અને પદ્ધતિઓ","હાઇડ્રોકાર્બન","પર્યાવરણીય રસાયણવિજ્ઞાન"
    ],
    Mathematics:[
      "ગણ (Sets)","સંબંધ અને વિધેય","ત્રિકોણમિતીય વિધેયો","ગણિતિય આગમનનો સિદ્ધાંત","સંકર સંખ્યાઓ અને દ્વિઘાત સમીકરણો","સુરેખ અસમતાઓ","ક્રમચય અને સંચય","દ્વિપદી પ્રમેય","શ્રેણી અને શ્રેઢી","યામ ભૂમિતિ (રેખાઓ, શંકુ છેદો)","ત્રિપરિમાણીય ભૂમિતિનો પરિચય","સીમા અને વિકલન","ગણિતિય તર્કશાસ્ત્ર","સંભાવના"
    ],
    Biology:[
      "સજીવ વિશ્વ","જૈવિક વર્ગીકરણ","વનસ્પતિ સૃષ્ટિ","પ્રાણી સૃષ્ટિ","સપુષ્પ વનસ્પતિઓની બાહ્યાકાર વિદ્યા","સપુષ્પ વનસ્પતિઓની અંતઃસ્થ રચના","પ્રાણીઓમાં રચનાકીય આયોજન","કોષ: જીવનનો એકમ","જૈવ અણુઓ","કોષચક્ર અને કોષવિભાજન","વનસ્પતિઓમાં વહન","ખનિજ પોષણ","ઉચ્ચ વનસ્પતિઓમાં પ્રકાશસંશ્લેષણ","વનસ્પતિઓમાં શ્વસન","વનસ્પતિ વૃદ્ધિ અને વિકાસ","પાચન અને શોષણ","શ્વસન અને વાયુઓનું વિનિમય","દેહજળ અને રુધિરાભિસરણ","ઉત્સર્ગ પદાર્થો અને તેનો નિકાલ","પ્રચલન અને હલનચલન","ચેતાકીય નિયંત્રણ અને સંકલન","રાસાયણિક સંકલન અને સમ્બદ્ધતા"
    ]
  },
  "12": {
    Physics:[
      "વિદ્યુતભારો અને વિદ્યુતક્ષેત્રો","સ્થિર વિદ્યુતસ્થિતિમાન અને કેપેસિટન્સ","પ્રવાહ વિદ્યુત","ગતિમાન વિદ્યુતભારો અને ચુંબકત્વ","ચુંબકત્વ અને દ્રવ્ય","વિદ્યુતચુંબકીય પ્રેરણ","અલ્ટરનેટિંગ કરંટ (A.C.)","વિદ્યુતચુંબકીય તરંગો","કિરણ પ્રકાશશાસ્ત્ર અને પ્રકાશીય ઉપકરણો","તરંગ પ્રકાશશાસ્ત્ર","વિકિરણ અને દ્રવ્યની દ્વૈત પ્રકૃતિ","પરમાણુઓ","ન્યુક્લિયસ","સેમિકન્ડક્ટર ઇલેક્ટ્રોનિક્સ: દ્રવ્યો, રચનાઓ અને સરળ પરિપથો"
    ],
    Chemistry:[
      "દ્રાવણો (Solutions)","વિદ્યુતરસાયણ (Electrochemistry)","રાસાયણિક ગતિકી (Chemical Kinetics)","d- અને f-વિભાગના તત્ત્વો","સવર્ગ સંયોજનો","હેલોએલ્કેન અને હેલોએરીન સંયોજનો","આલ્કોહોલ, ફીનોલ અને ઈથર સંયોજનો","આલ્ડિહાઈડ, કિટોન અને કાર્બોક્સિલિક એસિડ સંયોજનો","એમાઈન સંયોજનો","જૈવિક અણુઓ (Biomolecules)"
    ],
    Mathematics:[
      "સંબંધ અને વિધેય","પ્રતિલોમ ત્રિકોણમિતીય વિધેયો","શ્રેણિક (Matrices)","નિશ્ચાયક (Determinants)","સાતત્ય અને વિકલનીયતા (Continuity and Differentiability)","વિકલિતના ઉપયોગો (Application of Derivatives)","સંકલન (Integrals)","સંકલનના ઉપયોગો (Application of Integrals)","વિકલ સમીકરણો (Differential Equations)","સદિશ બીજગણિત (Vector Algebra)","ત્રિપરિમાણીય ભૂમિતિ (Three Dimensional Geometry)","રૈખિક પ્રોગ્રામિંગ (Linear Programming)","સંભાવના (Probability)"
    ],
    Biology:[
      "સપુષ્પ વનસ્પતિઓમાં લિંગી પ્રજનન","માનવ પ્રજનન","પ્રજનન સ્વાસ્થ્ય","વંશગત અને ભિન્નતાના સિદ્ધાંતો","વારસાગતનો આણ્વીય આધાર","ઉત્ક્રાંતિ","માનવ સ્વાસ્થ્ય અને રોગો","માનવ કલ્યાણમાં સૂક્ષ્મજીવો","બાયોટેકનોલોજી: સિદ્ધાંતો અને પ્રક્રિયાઓ","બાયોટેકનોલોજી અને તેના ઉપયોગો","સજીવો અને વસ્તી","ઇકોસિસ્ટમ (પરિવસ્ર્તંત્ર)","જૈવવિવિધતા અને સંરક્ષણ"
    ]
  }
};

let state = {page:"home", std:"11", subject:"Physics", chapter:0, tab:"Board", qIndex:0, score:0};
let content = loadLocal();
let downloads = JSON.parse(localStorage.getItem(DOWNLOAD_KEY)||"[]");

const el = id => document.getElementById(id);
const esc = s => String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));

function saveLocal(){localStorage.setItem(KEY,JSON.stringify(content))}
function loadLocal(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch{return[]}}
function chapterName(){return data[state.std][state.subject][state.chapter] || ""}
function subjectIcon(s){return {Physics:"⚛️",Chemistry:"🧪",Mathematics:"π",Biology:"🌿"}[s]||"📘"}
function subjectColor(s){return {Physics:"#168ff5",Chemistry:"#ff9f16",Mathematics:"#24bd62",Biology:"#a45cff"}[s]||"#168ff5"}
function isJeeAllowed(){return state.subject!=="Biology"}

function openModal(html){el("sheet").innerHTML=html;el("modal").classList.add("show")}
function closeModal(){el("modal").classList.remove("show")}
el("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});

function render(){
  const a=el("app");
  a.innerHTML=`
  <div class="topbar">
    <div class="brand"><img src="assets/app-icon.png"><div><b>Jil Std 11 & 12</b><small>SCIENCE PRO • NCERT + Board + JEE</small></div></div>
    <button class="iconbtn" onclick="window.app.go('admin')">⚙️</button>
  </div>
  <main class="page">${pageHTML()}</main>
  <nav class="nav">
    ${nav("home","⌂","Home")}${nav("library","▤","Library")}${nav("quiz","✓","Quiz")}${nav("downloads","⇩","Downloads")}${nav("more","☰","More")}
  </nav>`;
}
function nav(p,icon,label){return `<button class="${state.page===p?'active':''}" onclick="window.app.go('${p}')"><span class="ni">${icon}</span>${label}</button>`}

function pageHTML(){
 if(state.page==="home") return homeHTML();
 if(state.page==="library") return libraryHTML();
 if(state.page==="chapter") return chapterHTML();
 if(state.page==="quiz") return quizHTML();
 if(state.page==="downloads") return downloadsHTML();
 if(state.page==="admin") return adminHTML();
 if(state.page==="more") return moreHTML();
 return homeHTML();
}

function homeHTML(){
 return `<section class="hero"><img src="assets/app-icon.png"><h1>Jil Std 11 & 12</h1><p>Science PRO — Learn • Prepare • Achieve</p>
 <div class="chips"><span class="chip">NCERT</span><span class="chip">Board</span><span class="chip">JEE</span><span class="chip">Offline Library</span></div></section>
 <div class="section-title"><h2>ધોરણ પસંદ કરો</h2></div>
 <div class="grid"><button class="stdcard" onclick="window.app.setStd('11')"><b>11</b><br><span>Std 11 Science</span></button><button class="stdcard" onclick="window.app.setStd('12')"><b>12</b><br><span>Std 12 Science</span></button></div>
 <div class="section-title"><h2>Subjects</h2></div>
 <div class="grid">${Object.keys(data[state.std]).map(s=>`<button class="subject" onclick="window.app.openSubject('${s}')"><span class="subicon" style="background:${subjectColor(s)}22">${subjectIcon(s)}</span><span><b>${s}</b><small>${data[state.std][s].length} Chapters</small></span></button>`).join("")}</div>
 <div class="section-title"><h2>Quick Access</h2></div>
 <div class="grid"><button class="stdcard" onclick="window.app.go('quiz')">🧠<br><b style="font-size:16px">Chapter Quiz</b><br><span>Std ${state.std} મુજબ auto</span></button><button class="stdcard" onclick="window.app.go('downloads')">⇩<br><b style="font-size:16px">My Downloads</b><br><span>App અંદર જ</span></button></div>
 <div class="footer">Jil Education • Version 1.0 • Student Study App</div>`;
}

function libraryHTML(){
 return `<div class="section-title"><h2>Std ${state.std} Library</h2></div>
 <div class="tabs">${["Physics","Chemistry","Mathematics","Biology"].map(s=>`<button class="tab ${state.subject===s?'active':''}" onclick="window.app.openSubject('${s}')">${subjectIcon(s)} ${s}</button>`).join("")}</div>
 <div class="section-title"><h2>${subjectIcon(state.subject)} ${state.subject}</h2><span class="muted">${data[state.std][state.subject].length} Ch</span></div>
 <div>${data[state.std][state.subject].map((c,i)=>`<button class="chapter" onclick="window.app.openChapter(${i})"><span class="num">${i+1}</span><span><b>${esc(c)}</b><small>Board • NCERT${isJeeAllowed()?' • JEE':''} • Extra</small></span><span class="chev">›</span></button>`).join("")}</div>`;
}

function chapterHTML(){
 const c=chapterName();
 const allowedTabs=isJeeAllowed()?["Board","NCERT","JEE","Extra"]:["Board","NCERT","Extra"];
 const items=content.filter(x=>String(x.std)===state.std && x.subject===state.subject && Number(x.chapter)===state.chapter && x.tab===state.tab);
 return `<button class="btn alt" onclick="window.app.go('library')">← Back</button>
 <div class="section-title"><div><h2>Ch ${state.chapter+1}: ${esc(c)}</h2><span class="muted">Std ${state.std} • ${state.subject}</span></div></div>
 <div class="tabs">${allowedTabs.map(t=>`<button class="tab ${state.tab===t?'active':''}" onclick="window.app.setTab('${t}')">${t}</button>`).join("")}</div>
 <div class="notice">આ chapter માટે ${state.tab} content અહીં Admin Panel માં ઉમેરેલા પ્રમાણે automatic દેખાશે.</div>
 <div style="margin-top:12px">${items.length?items.map(contentCard).join(""):`<div class="empty">હજુ ${state.tab} content ઉમેરાયેલું નથી.<br><br>Admin Panel → Add Content માં link/PDF/video ઉમેરો.</div>`}</div>
 <div class="section-title"><h2>🧠 Chapter Quiz</h2><button class="btn" onclick="window.app.startQuiz()">Start</button></div>`;
}
function contentCard(x){
 const icon=x.type==="video"?"▶️":x.type==="pdf"?"📕":"🔗";
 return `<div class="content-card"><div class="content-row"><span class="ctype">${icon}</span><div><h3>${esc(x.title)}</h3><small>${esc(x.tab)} • Ch ${Number(x.chapter)+1}</small></div></div>
 <div class="actions"><button class="btn" onclick="window.app.openContent('${esc(x.id||"")}')">${x.type==="video"?"Watch":"Open"}</button><button class="btn alt" onclick="window.app.saveDownload('${esc(x.id||"")}')">⇩ Save in App</button></div></div>`;
}

function quizHTML(){
 const qs=quizBank[state.std][state.subject]?.[state.chapter] || genericQuiz(state.std,state.subject,state.chapter);
 const q=qs[state.qIndex] || qs[0];
 return `<div class="section-title"><div><h2>🧠 Auto Chapter Quiz</h2><span class="muted">Std ${state.std} • ${state.subject} • Ch ${state.chapter+1}</span></div></div>
 <div class="notice">Quiz standard અને chapter પ્રમાણે automatic બદલાય છે. Biology માં JEE નથી.</div>
 <div class="quizq"><h3>Q${state.qIndex+1}/${qs.length}. ${esc(q.q)}</h3>${q.o.map((o,i)=>`<button class="option" onclick="window.app.answer(${i},${q.a})">${esc(o)}</button>`).join("")}</div>
 <div class="section-title"><span>Score: ${state.score}</span><button class="btn alt" onclick="window.app.go('chapter')">Chapter</button></div>`;
}

const quizBank={
"11":{
 Physics:{
  0:[{q:"SI systemમાં lengthનું unit કયું છે?",o:["cm","m","km","mm"],a:1}],
  1:[{q:"Uniform motionમાં velocity કેવી હોય છે?",o:["Constant","Always zero","Infinite","Random"],a:0}],
  2:[{q:"Projectile motionમાં horizontal acceleration કેટલું હોય છે (air resistance ignore)?",o:["g","0","2g","1/g"],a:1}],
  3:[{q:"Newton's second lawનું સામાન્ય સ્વરૂપ શું છે?",o:["F=ma","F=m/a","F=a/m","F=mv"],a:0}],
  4:[{q:"Workનું SI unit કયું છે?",o:["Watt","Joule","Newton","Pascal"],a:1}]
 },
 Chemistry:{
  0:[{q:"1 moleમાં particlesની સંખ્યા કેટલી?",o:["6.022×10²³","9.8","3×10⁸","1.6×10⁻¹⁹"],a:0}],
  1:[{q:"Electronનો charge કયો છે?",o:["Positive","Negative","Neutral","Variable"],a:1}],
  2:[{q:"Periodic tableમાં same groupના elementsમાં શું સામાન્ય હોય છે?",o:["Valence pattern","Same mass","Same neutron count","Same period"],a:0}],
  3:[{q:"Covalent bond સામાન્ય રીતે શું કરે છે?",o:["Electron pair share","Only proton share","Neutron transfer","No interaction"],a:0}]
 },
 Mathematics:{
  0:[{q:"Empty setનું cardinality કેટલું છે?",o:["0","1","-1","∞"],a:0}],
  1:[{q:"Functionમાં દરેક inputને કેટલા output મળે?",o:["Exactly one","At least two","None","Infinite"],a:0}],
  2:[{q:"sin²θ + cos²θ = ?",o:["0","1","2","sinθ"],a:1}]
 }
},
"12":{
 Physics:{0:[{q:"Electric chargeનું SI unit કયું છે?",o:["Volt","Coulomb","Ohm","Tesla"],a:1}],1:[{q:"Capacitanceનું SI unit કયું છે?",o:["Farad","Henry","Weber","Joule"],a:0}]},
 Chemistry:{0:[{q:"Molarityનું unit સામાન્ય રીતે શું છે?",o:["mol L⁻¹","kg mol⁻¹","Pa","J"],a:0}],1:[{q:"Electrochemical cellમાં oxidation કયા electrode પર થાય છે?",o:["Anode","Cathode","Both always","Neither"],a:0}]},
 Mathematics:{0:[{q:"A functionના inverse માટે સામાન્ય notation શું છે?",o:["f⁻¹","f²","1/f only","df"],a:0}],1:[{q:"Identity matrixનું diagonal શું હોય છે?",o:["1","0 only","-1","2"],a:0}]}
}};

function genericQuiz(std,sub,ch){
 const name=data[std][sub][ch];
 return [{q:`“${name}” chapterનું મુખ્ય study focus શું છે?`,o:["Concept + formulas + practice","Only handwriting","Only memorization","Only videos"],a:0}];
}

function downloadsHTML(){
 return `<div class="section-title"><h2>⇩ My Downloads</h2><span class="muted">${downloads.length} saved</span></div>
 <div class="notice">Saved items app storage (IndexedDB/local storage) માં રાખવાનો પ્રયાસ થાય છે. Google Drive જેવી external URL CORS/permission કારણે actual file blob ન આપે તો app link reference સાચવે છે.</div>
 ${downloads.length?downloads.map((d,i)=>`<div class="content-card"><div class="content-row"><span class="ctype">${d.type==="video"?"▶️":d.type==="pdf"?"📕":"🔗"}</span><div><h3>${esc(d.title)}</h3><small>Std ${d.std} • ${esc(d.subject)} • Ch ${Number(d.chapter)+1}</small></div></div><div class="actions"><button class="btn" onclick="window.app.openSaved(${i})">Open</button><button class="btn red" onclick="window.app.removeDownload(${i})">Remove</button></div></div>`).join(""):`<div class="empty">હજુ કોઈ download નથી.</div>`}`;
}

function moreHTML(){
 return `<div class="section-title"><h2>More</h2></div>
 <div class="grid">
 <button class="stdcard" onclick="window.app.go('admin')">🛡️<br><b style="font-size:16px">Admin Panel</b><br><span>Content management</span></button>
 <button class="stdcard" onclick="window.app.showAbout()">ℹ️<br><b style="font-size:16px">About App</b><br><span>Jil Science PRO</span></button>
 </div>
 <hr><div class="notice"><b>Security:</b> આ HTML/APK client છે. Local admin password gate convenience માટે છે; સાચી production security માટે Firebase Authentication + Firestore/Storage Security Rules ફરજિયાત છે.</div>`;
}

function adminHTML(){
 return `<div class="section-title"><div><h2>🛡️ Admin Panel</h2><span class="muted">Authorized content management</span></div></div>
 <div class="admin-stat"><div class="stat"><b>${content.length}</b><small>Content</small></div><div class="stat"><b>${downloads.length}</b><small>Saved</small></div><div class="stat"><b>${Object.values(data[state.std]).reduce((a,x)=>a+x.length,0)}</b><small>Chapters</small></div></div>
 <div class="form-card"><h3 style="margin-top:0">➕ Add Content</h3>
 <label class="label">Standard</label><select id="aStd">${["11","12"].map(x=>`<option>${x}</option>`).join("")}</select>
 <label class="label">Subject</label><select id="aSub">${["Physics","Chemistry","Mathematics","Biology"].map(x=>`<option>${x}</option>`).join("")}</select>
 <label class="label">Chapter</label><select id="aCh"></select>
 <label class="label">Category</label><select id="aTab"><option>Board</option><option>NCERT</option><option>JEE</option><option>Extra</option></select>
 <label class="label">Type</label><select id="aType"><option value="pdf">PDF / Notes / Drill Book</option><option value="video">Video (Google Drive link)</option><option value="link">Other Link</option></select>
 <label class="label">Title</label><input id="aTitle" placeholder="Example: Ch 2 Notes / Video Lecture">
 <label class="label">URL / Google Drive link</label><input id="aUrl" placeholder="Paste your Drive sharing link here">
 <button class="btn" style="width:100%" onclick="window.app.addContent()">Add Content</button>
 </div>
 <div class="form-card"><h3 style="margin-top:0">📊 All Admin Content</h3><input class="search" id="adminSearch" oninput="window.app.renderAdminList()" placeholder="Search content..."><div id="adminList"></div></div>
 <div class="form-card"><h3 style="margin-top:0">☁️ Firebase</h3><div class="notice">Project connected in code. For secure cloud editing, use Firebase Authentication and restrictive Firestore Rules. Never put a service-account private key in this HTML.</div><div class="actions"><button class="btn alt" onclick="window.app.loadCloud()">Load Cloud</button><button class="btn" onclick="window.app.syncCloud()">Sync Local → Cloud</button></div></div>
 <button class="btn red" style="width:100%;margin-top:8px" onclick="window.app.clearLocal()">Clear Local Content</button>`;
}

function renderAdminList(){
 const box=document.getElementById("adminList"); if(!box)return;
 const q=(document.getElementById("adminSearch")?.value||"").toLowerCase();
 const arr=content.filter(x=>(x.title+" "+x.subject+" "+x.tab).toLowerCase().includes(q));
 box.innerHTML=arr.length?arr.map(x=>`<div class="content-card"><div class="content-row"><span class="ctype">${x.type==="video"?"▶️":x.type==="pdf"?"📕":"🔗"}</span><div><h3>${esc(x.title)}</h3><small>Std ${x.std} • ${esc(x.subject)} • Ch ${Number(x.chapter)+1} • ${x.tab}</small></div></div><div class="actions"><button class="btn red" onclick="window.app.deleteContent('${esc(x.id)}')">Delete</button></div></div>`).join(""):`<div class="empty">No content.</div>`;
}
function fillAdminChapters(){
 const s=document.getElementById("aStd")?.value||"11", sub=document.getElementById("aSub")?.value||"Physics";
 const ch=document.getElementById("aCh"); if(!ch)return;
 ch.innerHTML=data[s][sub].map((x,i)=>`<option value="${i}">Ch ${i+1}: ${esc(x)}</option>`).join("");
}
document.addEventListener("change",e=>{if(e.target.id==="aStd"||e.target.id==="aSub")fillAdminChapters()});

async function sha256(text){
 const buf=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(text));
 return [...new Uint8Array(buf)].map(b=>b.toString(16).padStart(2,"0")).join("");
}
async function adminLogin(){
 const pass=prompt("Enter Admin Password");
 if(pass===null)return;
 if(await sha256(pass)===ADMIN_HASH){sessionStorage.setItem("jil_admin","1");state.page="admin";render();setTimeout(fillAdminChapters,0);setTimeout(renderAdminList,0)}
 else alert("Wrong admin password.");
}

async function addContent(){
 if(sessionStorage.getItem("jil_admin")!=="1") return adminLogin();
 const x={
  id:crypto.randomUUID(),std:document.getElementById("aStd").value,
  subject:document.getElementById("aSub").value,chapter:Number(document.getElementById("aCh").value),
  tab:document.getElementById("aTab").value,type:document.getElementById("aType").value,
  title:document.getElementById("aTitle").value.trim(),url:document.getElementById("aUrl").value.trim(),createdAt:Date.now()
 };
 if(!x.title||!x.url)return alert("Title અને URL બંને નાખો.");
 if(x.subject==="Biology" && x.tab==="JEE"){return alert("Biology માટે JEE category રાખવામાં આવી નથી.");}
 content.unshift(x);saveLocal();alert("Content added. Chapterમાં automatic દેખાશે.");render();setTimeout(fillAdminChapters,0);setTimeout(renderAdminList,0);
}
async function syncCloud(){
 if(!content.length)return alert("Local content નથી.");
 try{
  for(const x of content) await addDoc(collection(db,"jilContent"),{...x,createdAt:serverTimestamp()});
  alert("Cloud sync request complete. Firestore Rules secure હોવી જરૂરી છે.");
 }catch(e){alert("Firebase sync failed: "+e.message)}
}
async function loadCloud(){
 try{
  const snap=await getDocs(collection(db,"jilContent"));
  const cloud=snap.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.title&&x.url);
  const map=new Map(content.map(x=>[x.id,x])); cloud.forEach(x=>map.set(x.id,x)); content=[...map.values()]; saveLocal(); render(); setTimeout(fillAdminChapters,0);setTimeout(renderAdminList,0);
  alert(`${cloud.length} cloud items loaded.`);
 }catch(e){alert("Firebase load failed: "+e.message)}
}

function openContent(id){
 const x=content.find(z=>z.id===id); if(!x)return;
 if(x.type==="video") openModal(`<button class="close" onclick="window.app.closeModal()">×</button><h2>▶️ ${esc(x.title)}</h2><div class="notice">Google Drive video link open થાય છે. Share permission “Anyone with the link / Viewer” પ્રમાણે રાખજો.</div><button class="btn" style="width:100%;margin-top:12px" onclick="window.open('${esc(x.url)}','_blank','noopener')">Open Video</button><button class="btn alt" style="width:100%;margin-top:8px" onclick="window.app.saveDownload('${esc(x.id)}')">Save in App</button>`);
 else openModal(`<button class="close" onclick="window.app.closeModal()">×</button><h2>${x.type==="pdf"?"📕":"🔗"} ${esc(x.title)}</h2><button class="btn" style="width:100%" onclick="window.open('${esc(x.url)}','_blank','noopener')">Open</button><button class="btn alt" style="width:100%;margin-top:8px" onclick="window.app.saveDownload('${esc(x.id)}')">Save in App</button>`);
}
function normalizeDrive(url){
 // Keep original URL. Direct Google Drive file download depends on permissions and CORS.
 const m=url.match(/\/d\/([a-zA-Z0-9_-]+)/); if(m)return `https://drive.google.com/uc?export=download&id=${m[1]}`;
 return url;
}
async function saveDownload(id){
 const x=content.find(z=>z.id===id); if(!x)return;
 let blobUrl=null, mode="link";
 try{
   const r=await fetch(normalizeDrive(x.url),{mode:"cors"});
   if(r.ok){
     const blob=await r.blob();
     const key="blob_"+Date.now();
     await idbPut(key,blob);
     blobUrl=key; mode="blob";
   }
 }catch(e){}
 downloads=downloads.filter(d=>d.id!==x.id);downloads.unshift({...x,mode,blobKey:blobUrl,savedAt:Date.now()});
 localStorage.setItem(DOWNLOAD_KEY,JSON.stringify(downloads));
 alert(mode==="blob"?"File app storageમાં save થયું.":"Link app Downloadsમાં save થયું. Drive permission/CORSના કારણે actual file blob save ન થઈ શક્યું.");
}
async function openSaved(i){
 const d=downloads[i]; if(!d)return;
 if(d.mode==="blob"&&d.blobKey){
  const blob=await idbGet(d.blobKey); if(blob){const u=URL.createObjectURL(blob);openModal(`<button class="close" onclick="window.app.closeModal()">×</button><h2>${esc(d.title)}</h2>${d.type==="video"?`<video controls style="width:100%;border-radius:14px" src="${u}"></video>`:`<iframe style="width:100%;height:65vh;border:0;border-radius:14px;background:white" src="${u}"></iframe>`}`);return;}
 }
 window.open(d.url,"_blank","noopener");
}
function removeDownload(i){downloads.splice(i,1);localStorage.setItem(DOWNLOAD_KEY,JSON.stringify(downloads));render()}
function idbOpen(){return new Promise((res,rej)=>{const r=indexedDB.open("jilFiles",1);r.onupgradeneeded=()=>r.result.createObjectStore("files");r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
async function idbPut(k,v){const dbi=await idbOpen();return new Promise((res,rej)=>{const tx=dbi.transaction("files","readwrite");tx.objectStore("files").put(v,k);tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
async function idbGet(k){const dbi=await idbOpen();return new Promise((res,rej)=>{const tx=dbi.transaction("files","readonly");const r=tx.objectStore("files").get(k);r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}

function answer(chosen,correct){
 document.querySelectorAll(".option").forEach(b=>b.disabled=true);
 const opts=document.querySelectorAll(".option"); opts[correct]?.classList.add("correct"); if(chosen!==correct)opts[chosen]?.classList.add("wrong");
 if(chosen===correct)state.score++;
 setTimeout(()=>{
  const qs=quizBank[state.std][state.subject]?.[state.chapter]||genericQuiz(state.std,state.subject,state.chapter);
  if(state.qIndex+1<qs.length)state.qIndex++; else {alert(`Quiz complete! Score: ${state.score}/${qs.length}`);state.qIndex=0;state.score=0;state.page="chapter";}
  render();
 },700);
}
function startQuiz(){state.qIndex=0;state.score=0;state.page="quiz";render()}

function showAbout(){openModal(`<button class="close" onclick="window.app.closeModal()">×</button><div style="text-align:center"><img src="assets/app-icon.png" style="width:120px;border-radius:28px"><h2>Jil Std 11 & 12 Science PRO</h2><p class="muted">NCERT + Board + JEE • Gujarati Medium</p><p class="muted">Physics • Chemistry • Mathematics • Biology</p><p class="notice">Biologyમાં JEE category નથી. Physics/Chemistry/Mathematicsમાં JEE tab છે.</p></div>`)}

function go(p){ if(p==="admin" && sessionStorage.getItem("jil_admin")!=="1") return adminLogin(); state.page=p;render();if(p==="admin"){setTimeout(fillAdminChapters,0);setTimeout(renderAdminList,0)}}
function setStd(s){state.std=s;state.subject="Physics";state.chapter=0;state.tab="Board";state.page="library";render()}
function openSubject(s){state.subject=s;state.chapter=0;state.tab="Board";state.page="library";render()}
function openChapter(i){state.chapter=i;state.tab="Board";state.page="chapter";render()}
function setTab(t){state.tab=t;render()}
function deleteContent(id){if(!confirm("Delete this content?"))return;content=content.filter(x=>x.id!==id);saveLocal();renderAdminList()}
function clearLocal(){if(confirm("Local content clear કરવું?")){content=[];saveLocal();render();}}
window.app={go,setStd,openSubject,openChapter,setTab,startQuiz,answer,openContent,saveDownload,openSaved,removeDownload,closeModal,showAbout,addContent,deleteContent,clearLocal,renderAdminList,loadCloud,syncCloud};
render();
