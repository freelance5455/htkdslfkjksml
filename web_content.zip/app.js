const pages=document.querySelectorAll('.page');
function show(id){pages.forEach(p=>p.classList.toggle('active',p.id===id));window.scrollTo(0,0)}
function openNote(subject){show('notes');document.querySelector('#noteBox').innerHTML=`<h2>${subject}</h2><p>এখানে ${subject}-এর গুরুত্বপূর্ণ সূত্র, সংজ্ঞা ও পরীক্ষার নোট যোগ করা যাবে।</p><p>💡 Tip: প্রতিদিন একটি chapter শেষ করে MCQ practice করো।</p>`}

let questions=[
 {q:"Faraday's law কোন রাশির পরিবর্তনের সাথে সম্পর্কিত?",o:["Magnetic flux","Resistance","Mass","Temperature"],a:0},
 {q:"AC-এর angular frequency-এর প্রতীক কোনটি?",o:["α","ω","λ","μ"],a:1},
 {q:"Ohm's law কোনটি?",o:["V=IR","P=VI²","F=ma","Q=mc"],a:0}
], qi=0,score=0,answered=false;
function loadQ(){let x=questions[qi];document.querySelector('#q').textContent=`${qi+1}. ${x.q}`;document.querySelector('#result').textContent='';let box=document.querySelector('#opts');box.innerHTML='';x.o.forEach((v,i)=>{let b=document.createElement('button');b.className='option';b.textContent=v;b.onclick=()=>answer(i,b);box.appendChild(b)});answered=false}
function answer(i,b){if(answered)return;answered=true;let x=questions[qi];document.querySelectorAll('.option')[x.a].classList.add('correct');if(i===x.a){score++;b.classList.add('correct')}else b.classList.add('wrong');localStorage.setItem('score',score);document.querySelector('#quizScore').textContent=score}
function nextQ(){qi=(qi+1)%questions.length;loadQ()}
loadQ();document.querySelector('#quizScore').textContent=localStorage.getItem('score')||0;

let sec=1500,timer=null;function render(){let m=String(Math.floor(sec/60)).padStart(2,'0'),s=String(sec%60).padStart(2,'0');document.querySelector('#clock').textContent=`${m}:${s}`}
function startTimer(){if(timer)return;timer=setInterval(()=>{if(sec>0){sec--;render();}else{clearInterval(timer);timer=null;alert('Study session complete! 🎉')}},1000)}
function pauseTimer(){clearInterval(timer);timer=null}
function resetTimer(){pauseTimer();sec=1500;render()}
document.querySelector('#theme').onclick=()=>document.body.classList.toggle('dark');
render();