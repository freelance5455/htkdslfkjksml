(() => {
"use strict";
const $=id=>document.getElementById(id);
const canvas=$("cadCanvas"), ctx=canvas.getContext("2d");
let entities=[], layers=new Map(), fileTitle="", view={scale:1,ox:0,oy:0}, tool="select", selected=-1, measurePts=[], undoStack=[], pointer=null, pinch=null, lastWorld=null;
const colorMap={1:"#ff5555",2:"#ffff55",3:"#55dd55",4:"#55ffff",5:"#5555ff",6:"#ff55ff",7:"#ffffff",8:"#999999",9:"#777777"};
function status(s){$("status").textContent=s}
function resize(){const r=canvas.getBoundingClientRect(),d=window.devicePixelRatio||1;canvas.width=Math.max(1,Math.round(r.width*d));canvas.height=Math.max(1,Math.round(r.height*d));ctx.setTransform(d,0,0,d,0,0);draw()}
window.addEventListener("resize",resize);
function parsePairs(text){const a=text.replace(/\r/g,"").split("\n");let p=[];for(let i=0;i<a.length-1;i+=2){p.push([a[i].trim(),a[i+1].trim()])}return p}
function parseDXF(text){
 const p=parsePairs(text),out=[];let inEntities=false,cur=null;
 const finish=()=>{if(cur){try{const e=makeEntity(cur);if(e)out.push(e)}catch(_){ }cur=null}};
 for(const [c,v] of p){
  if(c==="0"){finish();if(v==="SECTION"){inEntities=false;continue}if(v==="ENDSEC"){inEntities=false;continue}if(v==="ENTITIES"){inEntities=true;continue}if(inEntities)cur={type:v,raw:[]};}
  else if(cur)cur.raw.push([c,v]);
 }
 finish();return out;
}
function vals(raw,code){return raw.filter(x=>x[0]===String(code)).map(x=>x[1])}
function val(raw,code,def=0){const v=vals(raw,code)[0];return v===undefined?def:Number(v)}
function str(raw,code,def="0"){return vals(raw,code)[0]??def}
function makeEntity(o){
 const r=o.raw,t=o.type,base={type:t,layer:str(r,8,"0"),color:val(r,62,7),raw:r};
 if(t==="LINE")return {...base,x1:val(r,10),y1:val(r,20),x2:val(r,11),y2:val(r,21)};
 if(t==="CIRCLE")return {...base,x:val(r,10),y:val(r,20),r:Math.abs(val(r,40))};
 if(t==="ARC")return {...base,x:val(r,10),y:val(r,20),r:Math.abs(val(r,40)),a1:val(r,50),a2:val(r,51)};
 if(t==="LWPOLYLINE"){let pts=[],x=null;for(const [c,v] of r){if(c==="10")x=Number(v);if(c==="20"&&x!==null){pts.push([x,Number(v)]);x=null}}return {...base,pts,closed:(val(r,70)&1)!==0}}
 if(t==="TEXT"||t==="MTEXT")return {...base,x:val(r,10),y:val(r,20),height:Math.max(.1,val(r,40,2)),text:vals(r,1).join(" ")||vals(r,3).join("")};
 return null;
}
function bounds(){let xs=[],ys=[];for(const e of entities){if(e.type==="LINE"){xs.push(e.x1,e.x2);ys.push(e.y1,e.y2)}else if(e.type==="CIRCLE"||e.type==="ARC"){xs.push(e.x-e.r,e.x+e.r);ys.push(e.y-e.r,e.y+e.r)}else if(e.pts){e.pts.forEach(p=>{xs.push(p[0]);ys.push(p[1])})}else if(e.x!==undefined){xs.push(e.x);ys.push(e.y)}}if(!xs.length)return null;return {minX:Math.min(...xs),maxX:Math.max(...xs),minY:Math.min(...ys),maxY:Math.max(...ys)}}
function fit(){const b=bounds();if(!b)return;const w=canvas.clientWidth,h=canvas.clientHeight,pad=35,dx=Math.max(1e-6,b.maxX-b.minX),dy=Math.max(1e-6,b.maxY-b.minY);view.scale=Math.min((w-pad*2)/dx,(h-pad*2)/dy);view.ox=(w-(b.minX+b.maxX)*view.scale)/2;view.oy=(h+(b.minY+b.maxY)*view.scale)/2;draw()}
function screen(x,y){return [view.ox+x*view.scale,view.oy-y*view.scale]}
function world(x,y){return [(x-view.ox)/view.scale,(view.oy-y)/view.scale]}
function layerVisible(name){return layers.get(name)?.visible!==false}
function entityColor(e){if(e.color===256||e.color===0||!e.color)return layers.get(e.layer)?.color||"#e8eef2";return colorMap[Math.abs(e.color)]||"#d9e2e8"}
function draw(){
 const w=canvas.clientWidth,h=canvas.clientHeight;ctx.clearRect(0,0,w,h);ctx.fillStyle="#0c141b";ctx.fillRect(0,0,w,h);
 const step=50;ctx.strokeStyle="#182630";ctx.lineWidth=1;ctx.beginPath();for(let x=(view.ox%step+step)%step;x<w;x+=step){ctx.moveTo(x,0);ctx.lineTo(x,h)}for(let y=(view.oy%step+step)%step;y<h;y+=step){ctx.moveTo(0,y);ctx.lineTo(w,y)}ctx.stroke();
 entities.forEach((e,i)=>{if(!layerVisible(e.layer))return;ctx.strokeStyle=i===selected?"#ffb000":entityColor(e);ctx.fillStyle=ctx.strokeStyle;ctx.lineWidth=i===selected?2.5:1.25;ctx.beginPath();
 if(e.type==="LINE"){let a=screen(e.x1,e.y1),b=screen(e.x2,e.y2);ctx.moveTo(...a);ctx.lineTo(...b)}
 else if(e.type==="CIRCLE"){let a=screen(e.x,e.y);ctx.arc(a[0],a[1],Math.max(.5,e.r*view.scale),0,Math.PI*2)}
 else if(e.type==="ARC"){let a=screen(e.x,e.y);let start=-e.a1*Math.PI/180,end=-e.a2*Math.PI/180;ctx.arc(a[0],a[1],Math.max(.5,e.r*view.scale),start,end,true)}
 else if(e.pts?.length){let a=screen(...e.pts[0]);ctx.moveTo(...a);for(let j=1;j<e.pts.length;j++){a=screen(...e.pts[j]);ctx.lineTo(...a)}if(e.closed)ctx.closePath()}
 ctx.stroke();
 if((e.type==="TEXT"||e.type==="MTEXT")&&e.text){let a=screen(e.x,e.y);ctx.save();ctx.translate(a[0],a[1]);ctx.scale(1,-1);ctx.font=Math.max(8,e.height*view.scale)+"px Arial";ctx.fillText(e.text,0,0);ctx.restore()}
 });
 if(measurePts.length){ctx.strokeStyle="#ffb000";ctx.fillStyle="#ffb000";ctx.lineWidth=2;measurePts.forEach(p=>{let s=screen(...p);ctx.beginPath();ctx.arc(...s,4,0,Math.PI*2);ctx.fill()});if(measurePts.length===2){let a=screen(...measurePts[0]),b=screen(...measurePts[1]);ctx.beginPath();ctx.moveTo(...a);ctx.lineTo(...b);ctx.stroke()}}
 $("zoomLabel").textContent=Math.round(view.scale*100)+"%";
}
function loadFile(file){const reader=new FileReader();reader.onload=()=>{try{const text=String(reader.result);if(!/SECTION/i.test(text))throw Error("No parece ser un DXF ASCII válido.");entities=parseDXF(text);if(!entities.length)throw Error("No se encontraron entidades compatibles. Probá con DXF ASCII.");fileTitle=file.name;selected=-1;undoStack=[];layers.clear();entities.forEach(e=>{if(!layers.has(e.layer))layers.set(e.layer,{visible:true,color:entityColor(e)})});$("fileName").textContent=file.name;$("entityCount").textContent=entities.length+" entidades";$("emptyState").style.display="none";canvas.parentElement.classList.add("loaded");renderLayers();showProps();fit();status("DXF cargado: "+entities.length+" entidades compatibles");}catch(e){alert("No se pudo abrir el archivo: "+e.message);status("Error al abrir DXF")}};reader.onerror=()=>alert("No se pudo leer el archivo.");reader.readAsText(file)}
function renderLayers(){$("layers").innerHTML="";if(!layers.size){$("layers").innerHTML='<p class="muted">No hay capas.</p>';return}for(const [name,l] of layers){const row=document.createElement("label");row.className="layer-row";row.innerHTML=`<input type="checkbox" ${l.visible?"checked":""}><span class="swatch" style="background:${l.color}"></span><span class="layer-name"></span>`;row.querySelector(".layer-name").textContent=name;row.querySelector("input").onchange=e=>{l.visible=e.target.checked;draw()};$("layers").append(row)}}
function showProps(){if(selected<0||!entities[selected]){$("properties").innerHTML='<p class="muted">Seleccioná una entidad.</p>';return}const e=entities[selected];const fields=Object.entries(e).filter(([k,v])=>!["raw","pts"].includes(k)&&typeof v!=="object");$("properties").innerHTML=fields.map(([k,v])=>`<div class="prop"><span>${k}</span><b>${String(v)}</b></div>`).join("")+(e.pts?`<div class="prop"><span>vértices</span><b>${e.pts.length}</b></div>`:"")}
function nearest(x,y){let best=-1,dist=Infinity;entities.forEach((e,i)=>{if(!layerVisible(e.layer))return;let d=1e9;if(e.type==="LINE"){d=pointSeg(x,y,e.x1,e.y1,e.x2,e.y2)}else if(e.type==="CIRCLE"||e.type==="ARC"){d=Math.abs(Math.hypot(x-e.x,y-e.y)-e.r)}else if(e.pts){for(let j=1;j<e.pts.length;j++)d=Math.min(d,pointSeg(x,y,...e.pts[j-1],...e.pts[j]))}else if(e.x!==undefined)d=Math.hypot(x-e.x,y-e.y);if(d<dist){dist=d;best=i}});return dist<14/view.scale?best:-1}
function pointSeg(px,py,x1,y1,x2,y2){let dx=x2-x1,dy=y2-y1,t=((px-x1)*dx+(py-y1)*dy)/(dx*dx+dy*dy||1);t=Math.max(0,Math.min(1,t));return Math.hypot(px-x1-t*dx,py-y1-t*dy)}
function saveUndo(){undoStack.push(JSON.stringify(entities));if(undoStack.length>30)undoStack.shift()}
function pointerPos(ev){const r=canvas.getBoundingClientRect();return [ev.clientX-r.left,ev.clientY-r.top]}
canvas.addEventListener("pointerdown",ev=>{canvas.setPointerCapture(ev.pointerId);const p=pointerPos(ev),w=world(...p);pointer={id:ev.pointerId,start:p,last:p,world:w,moved:false};if(tool==="measure"){measurePts.push(w);if(measurePts.length===2){const d=Math.hypot(measurePts[1][0]-measurePts[0][0],measurePts[1][1]-measurePts[0][1]);$("measureResult").textContent="Distancia: "+d.toFixed(3)+" unidades";}draw();return}if(tool==="select"){const i=nearest(...w);selected=i;showProps();if(i>=0)lastWorld=w}draw()});
canvas.addEventListener("pointermove",ev=>{const p=pointerPos(ev),w=world(...p);$("coords").textContent="X: "+w[0].toFixed(2)+"  Y: "+w[1].toFixed(2);if(!pointer||pointer.id!==ev.pointerId)return;const dx=p[0]-pointer.last[0],dy=p[1]-pointer.last[1];if(Math.hypot(p[0]-pointer.start[0],p[1]-pointer.start[1])>3)pointer.moved=true;if(tool==="pan"||(tool==="select"&&selected<0)){view.ox+=dx;view.oy+=dy}else if(tool==="select"&&selected>=0&&pointer.moved){const e=entities[selected],ddx=w[0]-lastWorld[0],ddy=w[1]-lastWorld[1];if(e.type==="LINE"){e.x1+=ddx;e.y1+=ddy;e.x2+=ddx;e.y2+=ddy}else if(e.x!==undefined){e.x+=ddx;e.y+=ddy}else if(e.pts)e.pts=e.pts.map(q=>[q[0]+ddx,q[1]+ddy]);lastWorld=w}pointer.last=p;draw()});
canvas.addEventListener("pointerup",()=>{if(pointer?.moved&&selected>=0&&tool==="select"){status("Entidad movida")}pointer=null});
canvas.addEventListener("wheel",ev=>{ev.preventDefault();const p=pointerPos(ev),before=world(...p),factor=ev.deltaY<0?1.12:.89;view.scale=Math.max(.0001,Math.min(1e6,view.scale*factor));const after=screen(...before);view.ox+=p[0]-after[0];view.oy+=p[1]-after[1];draw()},{passive:false});
canvas.addEventListener("dblclick",fit);
document.querySelectorAll("[data-tool]").forEach(b=>b.onclick=()=>{tool=b.dataset.tool;document.querySelectorAll("[data-tool]").forEach(x=>x.classList.toggle("active",x===b));if(tool==="measure"){measurePts=[];$("measureResult").textContent="Tocá dos puntos del plano."}status("Herramienta: "+b.textContent)});
$("openBtn").onclick=$("emptyOpen").onclick=()=>$("fileInput").click();
$("fileInput").onchange=e=>{if(e.target.files[0])loadFile(e.target.files[0]);e.target.value=""};
$("fitBtn").onclick=fit;
$("allLayersBtn").onclick=()=>{layers.forEach(l=>l.visible=true);renderLayers();draw()};
$("deleteBtn").onclick=()=>{if(selected<0)return;saveUndo();entities.splice(selected,1);selected=-1;$("entityCount").textContent=entities.length+" entidades";showProps();draw();status("Entidad eliminada")};
$("undoBtn").onclick=()=>{if(!undoStack.length){status("No hay cambios para deshacer");return}entities=JSON.parse(undoStack.pop());selected=-1;$("entityCount").textContent=entities.length+" entidades";showProps();draw();status("Deshacer aplicado")};
$("exportBtn").onclick=exportDXF;
function exportDXF(){if(!entities.length){alert("No hay un dibujo para exportar.");return}let lines=["0","SECTION","2","HEADER","0","ENDSEC","0","SECTION","2","ENTITIES"];for(const e of entities){lines.push("0",e.type,"8",e.layer);if(e.color!==7)lines.push("62",String(e.color));if(e.type==="LINE")lines.push("10",e.x1,"20",e.y1,"11",e.x2,"21",e.y2);else if(e.type==="CIRCLE")lines.push("10",e.x,"20",e.y,"40",e.r);else if(e.type==="ARC")lines.push("10",e.x,"20",e.y,"40",e.r,"50",e.a1,"51",e.a2);else if(e.type==="LWPOLYLINE"){lines.push("90",String(e.pts.length),"70",e.closed?"1":"0");e.pts.forEach(p=>lines.push("10",p[0],"20",p[1]))}else if(e.type==="TEXT"||e.type==="MTEXT")lines.push("10",e.x,"20",e.y,"40",e.height,"1",e.text||"")};lines.push("0","ENDSEC","0","EOF");const blob=new Blob([lines.join("\r\n")+"\r\n"],{type:"application/dxf"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=(fileTitle.replace(/\.dxf$/i,"")||"dibujo")+"_editado.dxf";a.click();URL.revokeObjectURL(url);status("DXF exportado")}
resize();
})();