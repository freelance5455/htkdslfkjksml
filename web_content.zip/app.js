/* =========================================================================
   خزنة المفاتيح — منطق التطبيق (تطبيق جوال PWA)
   -------------------------------------------------------------------------
   - التخزين: IndexedDB (خزنة مشفّرة واحدة)
   - التشفير: PBKDF2-SHA256 (310,000 دورة) + AES-256-GCM
   - المفتاح يبقى في الذاكرة فقط (CryptoKey غير قابل للاستخراج)
   - لا يوجد أي طلب شبكة — التطبيق يعمل بالكامل دون اتصال
   ========================================================================= */
'use strict';

(() => {
  /* ------------------------------------------------------------- أدوات */

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const enc = new TextEncoder();
  const dec = new TextDecoder();
  const nowIso = () => new Date().toISOString();

  function esc(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, (c) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
    }[c]));
  }

  function uid() {
    if (crypto.randomUUID) return crypto.randomUUID();
    return 'id-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
  }

  function b64FromBytes(buf) {
    const arr = new Uint8Array(buf);
    let bin = '';
    for (let i = 0; i < arr.length; i += 1) bin += String.fromCharCode(arr[i]);
    return btoa(bin);
  }

  function bytesFromB64(b64) {
    const bin = atob(String(b64));
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
    return out;
  }

  let toastTimer;
  function toast(msg, kind = '') {
    const el = $('#toast');
    el.textContent = msg;
    el.className = 'toast' + (kind ? ' ' + kind : '');
    el.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.hidden = true; }, 2600);
  }

  function fmtDate(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '—';
    try {
      return d.toLocaleString('ar', { dateStyle: 'medium', timeStyle: 'short' });
    } catch {
      return d.toISOString().slice(0, 16).replace('T', ' ');
    }
  }

  /* ------------------------------------------------------- طبقة IndexedDB */

  const DB_NAME = 'passvault-db';
  const STORE = 'kv';

  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function idbGet(key) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const req = db.transaction(STORE, 'readonly').objectStore(STORE).get(key);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  async function idbSet(key, value) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function idbDel(key) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  /* --------------------------------------------------------- طبقة التشفير
     كل المنطق موجود في vault-core.js (PV) — تنسيق v2 مع كلمة الاسترجاع.
  */

  // (b64FromBytes / bytesFromB64 معرّفتان أعلى الصفحة)

  /* ------------------------------------------------------------- الحالة */

  const state = {
    unlocked: false,
    key: null,
    data: null,
    envelope: null,
    tab: 'list',
    query: '',
    revealed: new Set(),
    editingId: null,
    idleTimer: null,
    hiddenAt: null,
    clipboardTimer: null,
    lastActivity: Date.now(),
    filterTag: '',           // وسم واحد مُختار للفلترة ('' = الكل)
    recoveryMode: false,     // فتح بكلمة الاسترجاع بدل كلمة المرور
    pendingRecoveryPhrase: null,
    sortBy: 'name',
  };

  /* ------------------------------------------------------------- الوسوم */

  const TAG_COLORS = ['#5b8cff', '#22d3ee', '#34d399', '#fbbf24', '#f472b6', '#a78bfa', '#fb923c', '#94a3b8'];

  function tagList() {
    if (!state.data) return [];
    if (!Array.isArray(state.data.tags)) state.data.tags = [];
    return state.data.tags;
  }

  /** كل الوسوم المعروفة: المُنشأة يدويًا + المستخدمة في المدخلات. */
  function allTags() {
    const known = new Map();
    tagList().forEach((t) => known.set(t.name, t));
    entries().forEach((e) => (e.tags || []).forEach((name) => {
      if (!known.has(name)) known.set(name, { id: name, name, color: tagColor(name), implicit: true });
    }));
    return Array.from(known.values()).sort((a, b) => a.name.localeCompare(b.name, 'ar'));
  }

  function tagColor(name) {
    const found = tagList().find((t) => t.name === name);
    if (found && found.color) return found.color;
    let h = 0;
    for (let i = 0; i < String(name).length; i += 1) h = (h * 31 + String(name).charCodeAt(i)) >>> 0;
    return TAG_COLORS[h % TAG_COLORS.length];
  }

  /** إنشاء وسم مُعرَّف مسبقًا إن لم يكن موجودًا. */
  function ensureTag(name) {
    const clean = String(name || '').trim();
    if (!clean) return null;
    let tag = tagList().find((t) => t.name === clean);
    if (!tag) {
      tag = { id: uid(), name: clean, color: tagColor(clean) };
      tagList().push(tag);
    }
    return tag;
  }

  function removeTagFromEntries(name) {
    entries().forEach((e) => {
      e.tags = (e.tags || []).filter((t) => t !== name);
    });
  }

  /* ----------------------------------------------------------- الصور */

  const ICON_SIZE = 160;

  /** تصغير الصورة إلى مربع وحفظها كـdata URL داخل الخزنة المشفّرة. */
  function resizeImage(file) {
    return new Promise((resolve, reject) => {
      if (!file || !file.type.startsWith('image/')) {
        reject(new Error('الملف ليس صورة'));
        return;
      }
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('تعذّر قراءة الملف'));
      reader.onload = () => {
        const img = new Image();
        img.onerror = () => reject(new Error('تعذّر فتح الصورة'));
        img.onload = () => {
          const canvas = document.createElement('canvas');
          canvas.width = ICON_SIZE;
          canvas.height = ICON_SIZE;
          const ctx = canvas.getContext('2d');
          const side = Math.min(img.width, img.height); // قص مركزي مربّع
          ctx.drawImage(
            img,
            (img.width - side) / 2, (img.height - side) / 2, side, side,
            0, 0, ICON_SIZE, ICON_SIZE,
          );
          try {
            resolve(canvas.toDataURL('image/png'));
          } catch {
            reject(new Error('تعذّر معالجة الصورة'));
          }
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  function safeIcon(src) {
    return typeof src === 'string' && src.startsWith('data:image/') ? src : '';
  }

  function defaultPayload() {
    return {
      version: 3,
      entries: [],
      tags: [],
      log: [],
      settings: {
        vaultName: 'خزنة المفاتيح',
        autoLockMinutes: 5,
        clipboardClearSeconds: 15,
      },
      createdAt: nowIso(),
      updatedAt: nowIso(),
    };
  }

  const settings = () => (state.data && state.data.settings) || defaultPayload().settings;

  /* ------------------------------------------------------ إنشاء/فتح الخزنة */

  async function createVault(password, vaultName) {
    const payload = PV.defaultPayload();
    payload.settings.vaultName = vaultName || 'خزنة المفاتيح';
    const created = await PV.createEnvelope(password, payload, { recovery: true });
    await idbSet('vault', created.envelope);
    state.dataKeyBytes = created.dataKeyBytes;
    state.data = created.payload;
    state.envelope = created.envelope;
    state.unlocked = true;
    state.pendingRecoveryPhrase = created.recoveryPhrase;
    return created;
  }

  async function unlockVault(secret) {
    const envelope = await idbGet('vault');
    if (!envelope) throw new Error('لا توجد خزنة محفوظة على هذا الجهاز بعد.');
    let opened;
    try {
      opened = await PV.openEnvelope(envelope, secret);
    } catch {
      if (state.recoveryMode) {
        throw new Error('كلمة الاسترجاع غير صحيحة.');
      }
      throw new Error(
        PV.hasRecovery(envelope)
          ? 'كلمة المرور الرئيسية غير صحيحة (أو استخدم كلمة الاسترجاع).'
          : 'كلمة المرور الرئيسية غير صحيحة.',
      );
    }
    state.dataKeyBytes = opened.dataKeyBytes;
    state.data = opened.payload;
    state.envelope = envelope;
    state.unlocked = true;
    state.usedRecovery = opened.usedRecovery;
    if (!state.data.settings) state.data.settings = PV.defaultPayload().settings;
    if (!Array.isArray(state.data.tags)) state.data.tags = [];
    if (!Array.isArray(state.data.log)) state.data.log = [];
    // تسجيل حدث الفتح في سجل الأمان (مشفّر ومربوط ببصمة السجل السابق)
    await PV.appendLog(state.data, 'unlock', opened.usedRecovery ? 'فتح بكلمة الاسترجاع' : '');
    await persist();
    return opened;
  }

  async function persist() {
    if (!state.unlocked) return;
    state.data.updatedAt = nowIso();
    await PV.saveEnvelope(state.envelope, state.dataKeyBytes, state.data);
    await idbSet('vault', state.envelope);
  }

  /* --------------------------------------------------------------- القفل */

  function lock(reason) {
    if (!state.unlocked) return;
    // تسجيل حدث القفل قبل محو البيانات (لا يعطّل القفل الفوري)
    const data = state.data;
    const keyBytes = state.dataKeyBytes;
    if (data) {
      PV.appendLog(data, 'lock').then(async () => {
        try {
          await PV.saveEnvelope(state.envelope, keyBytes, data);
          await idbSet('vault', state.envelope);
        } catch { /* تجاهل */ }
      }).catch(() => { /* تجاهل */ });
    }
    state.unlocked = false;
    state.data = null;
    state.dataKeyBytes = null;
    state.revealed.clear();
    state.query = '';
    state.filterTag = '';
    clearTimeout(state.idleTimer);
    state.idleTimer = null;
    closeSheet();
    $('#app-screen').hidden = true;
    $('#lock-screen').hidden = false;
    // نعود دائمًا لشاشة "فتح الخزنة" لا لشاشة الإنشاء
    $('#unlock-form').hidden = false;
    $('#create-form').hidden = true;
    $('#master-input').value = '';
    $('#unlock-error').hidden = true;
    if (reason) toast(reason);
  }

  function touchActivity() {
    state.lastActivity = Date.now();
    if (!state.unlocked) return;
    clearTimeout(state.idleTimer);
    const minutes = Number(settings().autoLockMinutes) || 5;
    state.idleTimer = setTimeout(() => lock('قُفلت الخزنة تلقائيًا للخمول'), minutes * 60 * 1000);
  }

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      state.hiddenAt = Date.now();
      // قفل فوري عند مغادرة التطبيق (اختياري)
      if (state.unlocked && settings().lockOnBackground) {
        lock('قُفلت الخزنة لمغادرة التطبيق');
      }
    } else if (state.unlocked && state.hiddenAt) {
      const minutes = Number(settings().autoLockMinutes) || 5;
      if (Date.now() - state.hiddenAt > minutes * 60 * 1000) lock('قُفلت الخزنة لانتهاء المهلة');
    }
    state.hiddenAt = null;
  });

  ['pointerdown', 'keydown', 'wheel'].forEach((evt) => {
    document.addEventListener(evt, touchActivity, { passive: true });
  });

  /* ------------------------------------------------------------- الحافظة */

  async function copyText(text, label, autoClear = true) {
    if (!text) { toast('لا يوجد شيء لنسخه'); return false; }
    let ok = false;
    try {
      await navigator.clipboard.writeText(text);
      ok = true;
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try { ok = document.execCommand('copy'); } catch { ok = false; }
      document.body.removeChild(ta);
    }
    if (!ok) { toast('تعذّر النسخ', 'err'); return false; }

    const seconds = autoClear ? (Number(settings().clipboardClearSeconds) || 0) : 0;
    if (seconds > 0) {
      clearTimeout(state.clipboardTimer);
      state.clipboardTimer = setTimeout(async () => {
        try { await navigator.clipboard.writeText(''); } catch { /* المتصفح قد يمنع */ }
        toast('تم مسح الحافظة');
      }, seconds * 1000);
      toast(`تم نسخ ${label} — سيُمسح بعد ${seconds} ثانية`, 'ok');
    } else {
      toast(`تم نسخ ${label}`, 'ok');
    }
    return true;
  }

  /* ------------------------------------------------------- نظام الأوراق */

  function openSheet(html, onMount) {
    const panel = $('#sheet');
    panel.innerHTML = `<div class="sheet-grip"></div>${html}`;
    $('#sheet-backdrop').hidden = false;
    if (onMount) onMount(panel);
  }

  function closeSheet() {
    $('#sheet-backdrop').hidden = true;
    $('#sheet').innerHTML = '';
    state.editingId = null;
  }

  $('#sheet-backdrop').addEventListener('click', (e) => {
    if (e.target.id === 'sheet-backdrop') closeSheet();
  });

  function confirmDialog(title, text, yesLabel = 'تأكيد') {
    return new Promise((resolve) => {
      $('#confirm-title').textContent = title;
      $('#confirm-text').textContent = text;
      $('#confirm-yes').textContent = yesLabel;
      $('#confirm-backdrop').hidden = false;
      const done = (val) => {
        $('#confirm-backdrop').hidden = true;
        $('#confirm-yes').removeEventListener('click', onYes);
        $('#confirm-no').removeEventListener('click', onNo);
        resolve(val);
      };
      const onYes = () => done(true);
      const onNo = () => done(false);
      $('#confirm-yes').addEventListener('click', onYes);
      $('#confirm-no').addEventListener('click', onNo);
    });
  }

  /* --------------------------------------------------------- مدخلات: CRUD */

  function entries() {
    return (state.data && state.data.entries) || [];
  }

  function findEntry(ref) {
    const q = String(ref || '').trim().toLowerCase();
    return entries().find((e) => e.id === ref)
      || entries().find((e) => e.id.startsWith(q))
      || entries().find((e) => e.title.toLowerCase() === q);
  }

  function filteredEntries() {
    const q = state.query.trim().toLowerCase();
    const wanted = state.filterTag;
    const list = entries().filter((e) => {
      const entryTags = e.tags || [];
      if (wanted && !entryTags.includes(wanted)) return false;
      if (!q) return true;
      return [e.title, e.username, e.url, e.notes, ...entryTags]
        .join('\n').toLowerCase().includes(q);
    });
    list.sort((a, b) => {
      if (!!b.favorite !== !!a.favorite) return b.favorite ? 1 : -1;
      if (state.sortBy === 'updated') {
        return String(b.updatedAt || '').localeCompare(String(a.updatedAt || ''));
      }
      if (state.sortBy === 'created') {
        return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
      }
      return a.title.localeCompare(b.title, 'ar');
    });
    return list;
  }

  /* ------------------------------------------------------- منتقي الوسوم */

  /**
   * نافذة اختيار عامة (فوق الأوراق) — تُستخدم لاختيار وسم واحد
   * (الفلترة) أو عدة وسوم (داخل المحرّر).
   */
  function openPicker(opts) {
    const { title, subtitle = '', options = [], multi = false, onApply, onCancel } = opts;
    const picker = $('#picker');
    const selected = new Set(options.filter((o) => o.active).map((o) => o.value));

    const paint = () => {
      picker.innerHTML = `
        <div class="sheet-grip"></div>
        <h3>${esc(title)}</h3>
        ${subtitle ? `<p class="muted" style="margin:-6px 0 12px">${esc(subtitle)}</p>` : ''}
        <div class="picker-list" id="picker-list"></div>
        ${multi ? `<div class="action-row">
          <button class="primary-btn" id="picker-apply">تطبيق</button>
          <button class="secondary-btn" id="picker-cancel">إلغاء</button>
        </div>` : ''}`;

      $('#picker-list').innerHTML = options.map((o) => `
        <button type="button" class="picker-row ${selected.has(o.value) ? 'active' : ''}" data-val="${esc(o.value)}">
          ${o.color ? `<span class="tag-dot" style="--tc:${o.color}"></span>` : ''}
          <span class="picker-label">${esc(o.label)}</span>
          ${o.hint ? `<span class="picker-hint">${esc(o.hint)}</span>` : ''}
          ${selected.has(o.value) ? '<span class="picker-check">✔</span>' : ''}
        </button>`).join('');

      $('#picker-list').addEventListener('click', (ev) => {
        const row = ev.target.closest('[data-val]');
        if (!row) return;
        const val = row.dataset.val;
        if (multi) {
          if (selected.has(val)) selected.delete(val);
          else selected.add(val);
          paint();
        } else {
          closePicker();
          if (onApply) onApply([val]);
        }
      });

      if (multi) {
        $('#picker-apply').addEventListener('click', () => {
          closePicker();
          if (onApply) onApply(Array.from(selected));
        });
        $('#picker-cancel').addEventListener('click', () => {
          closePicker();
          if (onCancel) onCancel();
        });
      }
    };

    paint();
    $('#picker-backdrop').hidden = false;
  }

  function closePicker() {
    $('#picker-backdrop').hidden = true;
    $('#picker').innerHTML = '';
  }

  /** فلترة المدخلات بوسم واحد. */
  function openTagFilterPicker() {
    const counts = {};
    entries().forEach((e) => (e.tags || []).forEach((t) => { counts[t] = (counts[t] || 0) + 1; }));
    const options = [
      { label: 'كل الوسوم', value: '', active: !state.filterTag, hint: `${entries().length} مدخل` },
      ...allTags().map((t) => ({
        label: t.name,
        value: t.name,
        color: t.color,
        active: state.filterTag === t.name,
        hint: `${counts[t.name] || 0} مدخل`,
      })),
    ];
    openPicker({
      title: 'تصفية حسب الوسم',
      subtitle: 'اختر وسمًا واحدًا — أو «كل الوسوم» لإلغاء الفلترة',
      options,
      onApply: (sel) => {
        state.filterTag = sel[0] || '';
        renderList();
      },
    });
  }

  /** اختيار وسوم المدخل داخل المحرّر (متعدد). */
  function openTagPickerForEditor(selected, onDone) {
    const options = allTags().map((t) => ({
      label: t.name,
      value: t.name,
      color: t.color,
      active: selected.includes(t.name),
    }));
    if (!options.length) {
      toast('لا توجد وسوم بعد — أنشئ وسمًا من زر «وسم جديد»');
      return;
    }
    openPicker({
      title: 'اختيار الوسوم',
      subtitle: 'اختر وسمًا أو أكثر، أو اتركه فارغًا',
      options,
      multi: true,
      onApply: (sel) => onDone(sel),
    });
  }

  /** تحديث القائمة دون تدمير صفحة أخرى (مثل الإعدادات) معروضة حاليًا. */
  function refreshListIfActive() {
    if (state.tab === 'list') renderList();
    else renderTagFilter();
  }

  /** شريط فلترة الوسوم: زر واحد يفتح قائمة بكل الوسوم. */
  function renderTagFilter() {
    const bar = $('#tag-filter');
    if (!bar) return;
    const tags = allTags();
    if (!tags.length) {
      bar.hidden = true;
      bar.innerHTML = '';
      return;
    }
    bar.hidden = false;
    const active = state.filterTag;
    const color = active ? tagColor(active) : 'var(--muted)';
    const sortLabels = { name: 'الاسم', updated: 'الأحدث تعديلًا', created: 'الأحدث إضافة' };
    bar.innerHTML = `
      <button type="button" class="tag-bar-btn" id="tag-filter-btn">
        <span class="tag-dot" style="--tc:${color}"></span>
        <span id="tag-filter-label">${esc(active || 'كل الوسوم')}</span>
        <span class="tag-bar-caret">▾</span>
      </button>
      <button type="button" class="tag-bar-btn" id="sort-btn">
        <span>${esc(sortLabels[state.sortBy] || 'الاسم')}</span>
        <span class="tag-bar-caret">▾</span>
      </button>`;
    $('#tag-filter-btn').addEventListener('click', openTagFilterPicker);
    $('#sort-btn').addEventListener('click', openSortPicker);
  }

  /** اختيار ترتيب قائمة المدخلات. */
  function openSortPicker() {
    const labels = { name: 'حسب الاسم', updated: 'حسب آخر تعديل', created: 'حسب تاريخ الإضافة' };
    openPicker({
      title: 'ترتيب المدخلات',
      options: Object.keys(labels).map((key) => ({
        label: labels[key],
        value: key,
        active: state.sortBy === key,
      })),
      onApply: (sel) => {
        state.sortBy = sel[0] || 'name';
        renderList();
      },
    });
  }

  /* ------------------------------------------------ عرض القائمة الرئيسية */

  function renderList() {
    renderTagFilter();
    const list = filteredEntries();
    const view = $('#view');
    if (!list.length) {
      view.innerHTML = `
        <div class="empty-state">
          <div class="big">🗝️</div>
          <p>${state.query || state.filterTag ? 'لا نتائج مطابقة للفلتر.' : 'خزنتك فارغة — أضف أول مدخل.'}</p>
        </div>`;
      return;
    }
    const html = list.map((e) => {
      const initial = (e.title || '؟').trim().charAt(0);
      const icon = safeIcon(e.icon);
      const avatar = icon
        ? `<div class="entry-avatar entry-avatar-img"><img src="${icon}" alt="" loading="lazy"></div>`
        : `<div class="entry-avatar">${esc(initial)}</div>`;
      const tagChips = (e.tags || []).slice(0, 3)
        .map((t) => `<span class="tag-chip mini" style="--tc:${tagColor(t)}">${esc(t)}</span>`).join('');
      return `
      <div class="entry-card" data-id="${esc(e.id)}">
        ${avatar}
        <div class="entry-main">
          <div class="entry-title">${esc(e.title)}${e.favorite ? ' <span class="fav">★</span>' : ''}</div>
          <div class="entry-sub">${esc(e.username || e.url || '—')}</div>
          ${tagChips ? `<div class="entry-tags">${tagChips}</div>` : ''}
        </div>
        <div class="entry-actions">
          <button class="mini-btn" data-act="copy-user" data-id="${esc(e.id)}" title="نسخ المستخدم" aria-label="نسخ اسم المستخدم">
            <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/></svg>
          </button>
          <button class="mini-btn" data-act="copy-pass" data-id="${esc(e.id)}" title="نسخ كلمة المرور" aria-label="نسخ كلمة المرور">
            <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="9" width="12" height="12" rx="2.5"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/></svg>
          </button>
        </div>
      </div>`;
    }).join('');
    view.innerHTML = html;
  }

  /* ------------------------------------------------------ ورقة تفاصيل المدخل */

  async function openEntrySheet(id) {
    const e = findEntry(id);
    if (!e) return;
    const revealed = state.revealed.has(e.id);
    const tags = (e.tags || []).map((t) => `<span class="pill">${esc(t)}</span>`).join(' ');

    const icon = safeIcon(e.icon);
    openSheet(`
      ${icon ? `<div class="detail-icon"><img src="${icon}" alt=""></div>` : ''}
      <h3>${esc(e.title)}</h3>
      <div class="detail-row">
        <span class="detail-label">المستخدم</span>
        <span class="detail-value">${esc(e.username || '—')}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">كلمة المرور</span>
        <span class="detail-value mono secret">${revealed ? esc(e.password) : '•'.repeat(Math.min(16, (e.password || '').length))}</span>
      </div>
      ${e.url ? `<div class="detail-row">
        <span class="detail-label">الرابط</span>
        <span class="detail-value"><a href="${esc(e.url)}" target="_blank" rel="noopener noreferrer" style="color:var(--accent)">${esc(e.url)}</a></span>
      </div>` : ''}
      ${tags ? `<div class="detail-row"><span class="detail-label">الوسوم</span><span class="detail-value">${tags}</span></div>` : ''}
      ${e.notes ? `<div class="detail-row"><span class="detail-label">ملاحظات</span><span class="detail-value">${esc(e.notes)}</span></div>` : ''}
      <div class="detail-row">
        <span class="detail-label">أُضيف</span><span class="detail-value muted">${esc(fmtDate(e.createdAt))}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">آخر تعديل</span><span class="detail-value muted">${esc(fmtDate(e.updatedAt))}</span>
      </div>
      <div class="action-row three">
        <button class="secondary-btn" data-sheet-act="reveal" data-id="${esc(e.id)}">${revealed ? 'إخفاء' : 'إظهار'}</button>
        <button class="secondary-btn" data-sheet-act="copy-pass" data-id="${esc(e.id)}">نسخ</button>
        <button class="secondary-btn" data-sheet-act="edit" data-id="${esc(e.id)}">تعديل</button>
      </div>
      <div class="action-row">
        <button class="secondary-btn" data-sheet-act="copy-user" data-id="${esc(e.id)}">نسخ المستخدم</button>
        <button class="secondary-btn danger" data-sheet-act="delete" data-id="${esc(e.id)}" style="color:var(--danger)">حذف</button>
      </div>
    `);
  }

  /* -------------------------------------------- ورقة كلمة الاسترجاع */

  function showRecoveryPhraseSheet(phrase, onDone) {
    const formatted = PV.formatPhrase(phrase);
    openSheet(`
      <h3>⚠ احفظ كلمة الاسترجاع</h3>
      <p class="muted">هذه 12 كلمة تفتح خزنتك إذا نسيت كلمة المرور الرئيسية.
        احفظها في مكان آمن <b>خارج الجوال</b> (ورقة، مدير كلمات، صورة).</p>
      <div class="phrase-box">${esc(formatted)}</div>
      <div class="action-row">
        <button class="primary-btn" id="phrase-copy">نسخ الكلمات</button>
        <button class="secondary-btn" id="phrase-save">حفظ كملف</button>
      </div>
      <button class="secondary-btn" id="phrase-done" style="margin-top:10px">حفظتها — ابدأ الاستخدام</button>
    `, (panel) => {
      $('#phrase-copy', panel).addEventListener('click', () => {
        copyText(formatted, 'كلمة الاسترجاع', false);
      });
      $('#phrase-save', panel).addEventListener('click', () => {
        download(
          'passvault-recovery.txt',
          `خزنة المفاتيح — كلمة الاسترجاع\n\n${formatted}\n\n` +
            `احفظها في مكان آمن. بدونها لا يمكن فتح الخزنة إذا نسيت كلمة المرور الرئيسية.\n`,
          'text/plain',
        );
        toast('تم تنزيل الملف — احفظه في مكان آمن', 'ok');
      });
      $('#phrase-done', panel).addEventListener('click', () => {
        closeSheet();
        if (onDone) onDone();
      });
    });
  }

  /* ------------------------------------------------------ ورقة تحرير المدخل */

  function openEditorSheet(id, opts = {}) {
    const existing = id ? findEntry(id) : null;
    state.editingId = existing ? existing.id : null;
    const e = existing || { title: '', username: '', password: '', url: '', notes: '', tags: [], favorite: false };
    const icon = safeIcon(e.icon);
    let selectedTags = Array.isArray(e.tags) ? e.tags.slice() : [];
    let iconData = icon;

    openSheet(`
      <h3>${existing ? 'تعديل مدخل' : 'مدخل جديد'}</h3>
      <form id="entry-form">
        <div class="icon-row">
          <button type="button" class="icon-picker" id="icon-picker" aria-label="اختيار صورة">
            ${iconData
              ? `<img id="icon-preview" src="${iconData}" alt="">`
              : `<span id="icon-preview-placeholder">🖼️</span>`}
          </button>
          <div class="icon-meta">
            <div class="lbl">صورة التطبيق</div>
            <div class="sub">اختر أيقونة من جهازك — تُحفظ مشفّرة داخل الخزنة</div>
            <div class="row gap" style="margin-top:8px">
              <button type="button" class="setting-btn" id="icon-choose">اختيار صورة</button>
              <button type="button" class="setting-btn" id="icon-clear" ${iconData ? '' : 'hidden'}>إزالة</button>
            </div>
          </div>
        </div>

        <label class="field">
          <span>العنوان *</span>
          <input type="text" id="f-title" value="${esc(e.title)}" required maxlength="80" placeholder="مثال: البريد">
        </label>
        <label class="field">
          <span>اسم المستخدم</span>
          <div class="input-wrap">
            <input type="text" id="f-user" value="${esc(e.username)}" maxlength="120" autocapitalize="off" autocorrect="off" spellcheck="false">
            <button type="button" class="ghost-btn" data-paste="f-user">لصق</button>
          </div>
        </label>
        <label class="field">
          <span>كلمة المرور</span>
          <div class="input-wrap">
            <input type="password" id="f-pass" value="${esc(e.password)}" autocomplete="new-password" autocapitalize="off" autocorrect="off" spellcheck="false">
            <button type="button" class="ghost-btn" data-toggle="f-pass">إظهار</button>
          </div>
        </label>
        <div class="row gap" style="margin:-6px 0 14px;flex-wrap:wrap">
          <button type="button" class="setting-btn" id="gen-for-field">🎲 توليد</button>
          <button type="button" class="setting-btn" data-paste="f-pass">📋 لصق كلمة المرور</button>
          <button type="button" class="setting-btn" id="toggle-fav">${e.favorite ? '★ مفضّل' : '☆ مفضّل'}</button>
        </div>
        <label class="field">
          <span>الرابط</span>
          <input type="text" id="f-url" value="${esc(e.url)}" inputmode="url" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="https://">
        </label>
        <div class="field">
          <span>الوسوم</span>
          <button type="button" class="tag-bar-btn wide" id="f-tags-btn">
            <span class="tag-dot" style="--tc:var(--accent)"></span>
            <span id="f-tags-label">${esc(selectedTags.length ? selectedTags.join('، ') : 'بدون وسوم')}</span>
            <span class="tag-bar-caret">▾</span>
          </button>
          <div class="row gap" style="margin-top:8px">
            <input type="text" id="f-tag-new" placeholder="وسم جديد…" maxlength="24">
            <button type="button" class="setting-btn" id="add-tag-btn">إضافة</button>
          </div>
        </div>
        <label class="field">
          <span>ملاحظات</span>
          <textarea id="f-notes" rows="3">${esc(e.notes)}</textarea>
        </label>
        <label class="switch-row" style="border:0;padding-top:0">
          <span>حفظ وإضافة مدخل آخر</span>
          <label class="switch"><input type="checkbox" id="f-quick"><span class="slider"></span></label>
        </label>
        <div class="action-row">
          <button type="submit" class="primary-btn">حفظ</button>
          <button type="button" class="secondary-btn" id="cancel-edit">إلغاء</button>
        </div>
      </form>
    `, (panel) => {
      const form = $('#entry-form', panel);
      const favBtn = $('#toggle-fav', panel);
      let favorite = !!e.favorite;

      favBtn.addEventListener('click', () => {
        favorite = !favorite;
        favBtn.textContent = favorite ? '★ مفضّل' : '☆ مفضّل';
      });

      // ---- الوسوم ----
      const tagLabel = $('#f-tags-label', panel);
      const paintTags = () => {
        tagLabel.textContent = selectedTags.length ? selectedTags.join('، ') : 'بدون وسوم';
      };

      $('#f-tags-btn', panel).addEventListener('click', () => {
        openTagPickerForEditor(selectedTags.slice(), (sel) => {
          selectedTags = sel;
          paintTags();
        });
      });

      const addTagFromInput = () => {
        const input = $('#f-tag-new', panel);
        const raw = input.value.split(/[،,]/).map((t) => t.trim()).filter(Boolean);
        if (!raw.length) return;
        raw.forEach((name) => {
          ensureTag(name);
          if (!selectedTags.includes(name)) selectedTags.push(name);
        });
        input.value = '';
        paintTags();
      };

      $('#add-tag-btn', panel).addEventListener('click', addTagFromInput);
      $('#f-tag-new', panel).addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') { ev.preventDefault(); addTagFromInput(); }
      });

      // ---- الصورة ----
      const fileInput = document.createElement('input');
      fileInput.type = 'file';
      fileInput.accept = 'image/*';
      fileInput.addEventListener('change', async () => {
        const file = fileInput.files && fileInput.files[0];
        if (!file) return;
        try {
          iconData = await resizeImage(file);
          const holder = $('#icon-picker', panel);
          holder.innerHTML = `<img id="icon-preview" src="${iconData}" alt="">`;
          $('#icon-clear', panel).hidden = false;
          toast('تم حفظ الصورة', 'ok');
        } catch (err) {
          toast(err.message || 'تعذّر تحميل الصورة', 'err');
        }
      });

      const chooseImage = () => fileInput.click();
      $('#icon-choose', panel).addEventListener('click', chooseImage);
      $('#icon-picker', panel).addEventListener('click', chooseImage);
      $('#icon-clear', panel).addEventListener('click', () => {
        iconData = '';
        $('#icon-picker', panel).innerHTML = '<span id="icon-preview-placeholder">🖼️</span>';
        $('#icon-clear', panel).hidden = true;
      });

      // ---- اللصق ----
      $$('[data-paste]', panel).forEach((btn) => {
        btn.addEventListener('click', async () => {
          const target = document.getElementById(btn.dataset.paste);
          if (!target) return;
          try {
            const text = await navigator.clipboard.readText();
            if (!text) { toast('الحافظة فارغة'); return; }
            target.value = text;
            if (target.type === 'password') target.type = 'text';
            toast('تم اللصق', 'ok');
          } catch {
            toast('تعذّر قراءة الحافظة — الصق يدويًا', 'err');
          }
        });
      });

      $('#gen-for-field', panel).addEventListener('click', () => {
        const pwd = generatePassword(20);
        $('#f-pass', panel).value = pwd;
        $('#f-pass', panel).type = 'text';
        toast('تم توليد كلمة مرور قوية');
      });

      $('#cancel-edit', panel).addEventListener('click', closeSheet);

      form.addEventListener('submit', async (ev) => {
        ev.preventDefault();
        const title = $('#f-title', panel).value.trim();
        if (!title) { toast('العنوان مطلوب', 'err'); return; }
        const fields = {
          title,
          username: $('#f-user', panel).value.trim(),
          password: $('#f-pass', panel).value,
          url: $('#f-url', panel).value.trim(),
          notes: $('#f-notes', panel).value.trim(),
          tags: selectedTags.slice(),
          icon: iconData,
          favorite,
        };
        if (existing) {
          Object.assign(existing, fields, { updatedAt: nowIso() });
          await PV.appendLog(state.data, 'update', existing.title);
        } else {
          entries().push({ id: uid(), createdAt: nowIso(), updatedAt: nowIso(), ...fields });
          await PV.appendLog(state.data, 'create', fields.title);
        }
        await persist();
        refreshListIfActive();
        if ($('#f-quick', panel).checked) {
          // وضع الإضافة السريعة: نُبقي النموذج مفتوحًا بمدخل جديد
          toast('تم الحفظ — أضف المدخل التالي', 'ok');
          state.editingId = null;
          $('#f-title', panel).value = '';
          $('#f-user', panel).value = '';
          $('#f-pass', panel).value = '';
          $('#f-url', panel).value = '';
          $('#f-notes', panel).value = '';
          iconData = '';
          $('#icon-picker', panel).innerHTML = '<span id="icon-preview-placeholder">🖼️</span>';
          $('#icon-clear', panel).hidden = true;
          $('#f-title', panel).focus();
          return;
        }
        closeSheet();
        toast(existing ? 'تم حفظ التعديلات' : 'تمت إضافة المدخل', 'ok');
      });
    });
  }

  /* ------------------------------------------------------ استيراد CSV */

  /** محلّل CSV بسيط يدعم الاقتباس والفواصل داخل الحقول. */
  function parseCsv(text) {
    const rows = [];
    let row = [];
    let field = '';
    let quoted = false;
    const src = String(text || '').replace(/^\uFEFF/, '');
    for (let i = 0; i < src.length; i += 1) {
      const ch = src[i];
      if (quoted) {
        if (ch === '"') {
          if (src[i + 1] === '"') { field += '"'; i += 1; }
          else quoted = false;
        } else field += ch;
      } else if (ch === '"') quoted = true;
      else if (ch === ',') { row.push(field); field = ''; }
      else if (ch === '\n') { row.push(field); rows.push(row); row = []; field = ''; }
      else if (ch !== '\r') field += ch;
    }
    if (field.length || row.length) { row.push(field); rows.push(row); }
    return rows.filter((r) => r.some((c) => String(c).trim() !== ''));
  }

  const CSV_FIELDS = [
    { key: 'title', label: 'العنوان', required: true, hints: ['title', 'name', 'account', 'service', 'site', 'label'] },
    { key: 'username', label: 'اسم المستخدم', hints: ['username', 'user', 'login', 'email', 'user name', 'user_name'] },
    { key: 'password', label: 'كلمة المرور', hints: ['password', 'pass', 'pwd', 'secret'] },
    { key: 'url', label: 'الرابط', hints: ['url', 'website', 'site', 'link', 'uri'] },
    { key: 'notes', label: 'الملاحظات', hints: ['notes', 'note', 'comment', 'comments', 'extra'] },
    { key: 'tags', label: 'الوسوم', hints: ['tags', 'tag', 'group', 'folder', 'category'] },
  ];

  /** مطابقة تلقائية بين حقولنا وأعمدة ملف CSV. */
  function autoMapCsv(headers) {
    const norm = headers.map((h) => String(h || '').trim().toLowerCase());
    const map = {};
    CSV_FIELDS.forEach((f) => {
      let idx = -1;
      f.hints.forEach((hint) => {
        if (idx !== -1) return;
        idx = norm.findIndex((h) => h === hint || h.includes(hint));
      });
      map[f.key] = idx;
    });
    return map;
  }

  function importCsv() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.csv,text/csv,text/plain';
    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      if (!file) return;
      let rows;
      try {
        rows = parseCsv(await file.text());
      } catch {
        toast('تعذّر قراءة الملف', 'err');
        return;
      }
      if (rows.length < 2) {
        toast('الملف لا يحتوي صفوفًا كافية', 'err');
        return;
      }
      const headers = rows[0];
      const dataRows = rows.slice(1);
      const mapping = autoMapCsv(headers);
      if (mapping.title === -1) {
        toast('تعذّر التعرف على عمود العنوان — عيّن الأعمدة يدويًا', 'err');
      }
      showCsvMappingSheet(headers, dataRows, mapping);
    });
    input.click();
  }

  function showCsvMappingSheet(headers, dataRows, mapping) {
    const rows = dataRows;
    const render = () => {
      const summary = CSV_FIELDS.map((f) => {
        const idx = mapping[f.key];
        const label = idx === -1 ? '—' : headers[idx] || `عمود ${idx + 1}`;
        return `
          <div class="picker-row csv-map-row">
            <span class="picker-label">${esc(f.label)}${f.required ? ' *' : ''}</span>
            <span class="picker-hint">${esc(label)}</span>
            <button type="button" class="setting-btn" data-map="${esc(f.key)}">تغيير</button>
          </div>`;
      }).join('');
      return `
        <div class="sheet-grip"></div>
        <h3>استيراد من CSV</h3>
        <p class="muted" style="margin:-6px 0 12px">${rows.length} صف جاهز للاستيراد — عيّن الأعمدة إن لزم.</p>
        <div class="picker-list">${summary}</div>
        <div class="action-row">
          <button class="primary-btn" id="csv-import">استيراد ${rows.length} مدخل</button>
          <button class="secondary-btn" id="csv-cancel">إلغاء</button>
        </div>`;
    };

    openSheet(render(), (panel) => {
      const bind = () => {
        $$('[data-map]', panel).forEach((btn) => {
          btn.addEventListener('click', () => {
            const key = btn.dataset.map;
            const field = CSV_FIELDS.find((f) => f.key === key);
            openPicker({
              title: `عمود: ${field.label}`,
              subtitle: 'اختر العمود المقابل لهذا الحقل',
              options: [
                { label: 'بدون', value: '-1', active: mapping[key] === -1 },
                ...headers.map((h, i) => ({ label: h || `عمود ${i + 1}`, value: String(i), active: mapping[key] === i })),
              ],
              onApply: (sel) => {
                mapping[key] = Number(sel[0]);
                panel.innerHTML = `<div class="sheet-grip"></div>${render()}`;
                bind();
              },
            });
          });
        });
        $('#csv-cancel', panel).addEventListener('click', closeSheet);
        $('#csv-import', panel).addEventListener('click', async () => {
          if (mapping.title === -1) {
            toast('عيّن عمود العنوان أولًا', 'err');
            return;
          }
          let added = 0;
          const existing = new Set(entries().map((e) => e.title));
          rows.forEach((r) => {
            const get = (k) => (mapping[k] === -1 ? '' : String(r[mapping[k]] ?? '').trim());
            const title = get('title');
            if (!title || existing.has(title)) return;
            const tags = get('tags').split(/[،,]/).map((t) => t.trim()).filter(Boolean);
            tags.forEach((t) => ensureTag(t));
            entries().push({
              id: uid(),
              title,
              username: get('username'),
              password: get('password'),
              url: get('url'),
              notes: get('notes'),
              tags,
              icon: '',
              favorite: false,
              createdAt: nowIso(),
              updatedAt: nowIso(),
            });
            existing.add(title);
            added += 1;
          });
          await PV.appendLog(state.data, 'import', `${added} مدخل من CSV`);
          await persist();
          closeSheet();
          refreshListIfActive();
          toast(`تم استيراد ${added} مدخل`, 'ok');
        });
      };
      bind();
    });
  }
  /* ------------------------------------------------- تبويب سجل الأمان */

  const LOG_LABELS = {
    unlock: 'فتح الخزنة',
    lock: 'قفل الخزنة',
    create: 'إضافة مدخل',
    update: 'تعديل مدخل',
    delete: 'حذف مدخل',
    import: 'استيراد مدخلات',
    export: 'تصدير مدخلات',
    rekey: 'تغيير كلمة المرور / تقوية التشفير',
    recovery: 'تعديل كلمة الاسترجاع',
    upgrade: 'ترقية صيغة الخزنة',
  };

  const LOG_ICONS = {
    unlock: '🔓', lock: '🔒', create: '➕', update: '✏️', delete: '🗑️',
    import: '📥', export: '📤', rekey: '🔑', recovery: '🛟', upgrade: '⬆️',
  };

  async function renderLogTab() {
    const view = $('#view');
    const log = (state.data && state.data.log) || [];
    const list = log.slice().reverse();
    const kdf = (state.envelope && state.envelope.kdf) || PV.KDF;
    const memMiB = Math.round((128 * (kdf.N || 32768) * (kdf.r || 8)) / 1048576);

    view.innerHTML = `
      <div class="crypto-card">
        <div class="crypto-title">🛡️ التشفير الحالي</div>
        <div class="crypto-grid">
          <div><span>اشتقاق المفتاح</span><b>scrypt</b></div>
          <div><span>ذاكرة كل محاولة</span><b>${memMiB} MiB</b></div>
          <div><span>تشفير المحتوى</span><b>AES-256-GCM</b></div>
          <div><span>مفتاح لكل مدخل</span><b>HKDF-SHA256</b></div>
        </div>
        <p class="muted" style="margin:10px 0 0">
          كل مدخل مشفّر بمفتاح مستقل مربوط بمعرّفه، فلا يمكن تبديل مدخل بآخر،
          ولا يكفي كشف مفتاح مدخل واحد لكشف بقية الخزنة.
        </p>
      </div>

      <div class="section-title"><span>سجل الأحداث (${log.length})</span></div>
      ${list.length ? `
        <div class="log-list">
          ${list.map((r) => `
            <div class="log-item">
              <div class="log-icon">${LOG_ICONS[r.action] || '•'}</div>
              <div class="log-body">
                <div class="log-t">${esc(LOG_LABELS[r.action] || r.action)}${r.target ? ` — ${esc(r.target)}` : ''}</div>
                <div class="log-d mono">${esc(fmtDate(r.ts))} · بصمة ${esc((r.hash || '').slice(0, 12))}</div>
              </div>
            </div>`).join('')}
        </div>` : `
        <div class="empty-state">
          <div class="big">📜</div>
          <p>السجل فارغ.</p>
          <p class="muted" style="margin-top:6px">كل عملية (فتح، قفل، إضافة، تعديل، حذف) تُسجَّل هنا داخل الخزنة المشفّرة.</p>
        </div>`}

      <button class="secondary-btn" id="log-verify" style="width:100%;margin-top:12px">
        تحقّق من سلامة السجل
      </button>
      <p class="muted" style="text-align:center;margin-top:10px;font-size:12px">
        كل سجل مرتبط ببصمة SHA-256 للسجل السابق — أي حذف أو تعديل يكسر السلسلة ويُكتشف هنا.
      </p>
    `;

    $('#log-verify').addEventListener('click', async () => {
      const verdict = await PV.verifyLog((state.data && state.data.log) || []);
      if (verdict.ok) {
        toast(`سلسلة السجل سليمة (${verdict.count} سجل)`, 'ok');
      } else {
        toast(`تم اكتشاف تلاعب عند الحدث ${verdict.brokenAt + 1} — ${verdict.reason}`, 'err');
      }
    });
  }

  /* ------------------------------------------------------------- المولّد */

  const CHARSETS = {
    lower: 'abcdefghijklmnopqrstuvwxyz',
    upper: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    digits: '0123456789',
    symbols: '!@#$%^&*()-_=+[]{};:,.?/',
  };
  const AMBIGUOUS = 'Il1O0o|`\'";:.,';

  function generatePassword(length = 20, opts = {}) {
    const groups = [];
    const add = (key, on) => {
      if (!on) return;
      let set = CHARSETS[key];
      if (opts.avoidAmbiguous !== false) set = set.split('').filter((c) => !AMBIGUOUS.includes(c)).join('');
      if (set) groups.push(set);
    };
    add('lower', opts.lower !== false);
    add('upper', opts.upper !== false);
    add('digits', opts.digits !== false);
    add('symbols', opts.symbols !== false);
    if (!groups.length) return '';
    const all = groups.join('');
    const pick = (set) => set[crypto.getRandomValues(new Uint32Array(1))[0] % set.length];
    const chars = groups.map(pick);
    while (chars.length < length) chars.push(pick(all));
    for (let i = chars.length - 1; i > 0; i -= 1) {
      const j = crypto.getRandomValues(new Uint32Array(1))[0] % (i + 1);
      [chars[i], chars[j]] = [chars[j], chars[i]];
    }
    return chars.join('');
  }

  function renderGenerator() {
    const view = $('#view');
    view.innerHTML = `
      <div class="gen-output" id="gen-out">—</div>
      <div class="action-row" style="margin-bottom:16px">
        <button class="primary-btn" id="gen-run">توليد</button>
        <button class="secondary-btn" id="gen-copy">نسخ</button>
      </div>
      <div class="settings-list">
        <div class="switch-row">
          <span>الطول: <b id="gen-len-val">20</b></span>
          <input type="range" id="gen-len" min="8" max="64" value="20" style="width:45%">
        </div>
        <div class="switch-row">
          <span>أحرف صغيرة (a-z)</span>
          <label class="switch"><input type="checkbox" id="gen-lower" checked><span class="slider"></span></label>
        </div>
        <div class="switch-row">
          <span>أحرف كبيرة (A-Z)</span>
          <label class="switch"><input type="checkbox" id="gen-upper" checked><span class="slider"></span></label>
        </div>
        <div class="switch-row">
          <span>أرقام (0-9)</span>
          <label class="switch"><input type="checkbox" id="gen-digits" checked><span class="slider"></span></label>
        </div>
        <div class="switch-row">
          <span>رموز (!@#…)</span>
          <label class="switch"><input type="checkbox" id="gen-symbols" checked><span class="slider"></span></label>
        </div>
        <div class="switch-row">
          <span>تجنّب الأحرف المتشابهة (l1O0)</span>
          <label class="switch"><input type="checkbox" id="gen-ambig" checked><span class="slider"></span></label>
        </div>
      </div>
      <button class="secondary-btn" id="gen-use" style="margin-top:14px">استخدامه في مدخل جديد</button>
    `;

    const genOpts = () => ({
      length: Number($('#gen-len').value),
      lower: $('#gen-lower').checked,
      upper: $('#gen-upper').checked,
      digits: $('#gen-digits').checked,
      symbols: $('#gen-symbols').checked,
      avoidAmbiguous: $('#gen-ambig').checked,
    });

    const run = () => {
      $('#gen-out').textContent = generatePassword(genOpts().length, genOpts());
    };

    $('#gen-len').addEventListener('input', (e) => { $('#gen-len-val').textContent = e.target.value; });
    $('#gen-run').addEventListener('click', run);
    $('#gen-copy').addEventListener('click', () => {
      const val = $('#gen-out').textContent;
      if (!val || val === '—') { toast('ولّد كلمة مرور أولاً'); return; }
      copyText(val, 'كلمة المرور');
    });
    $('#gen-use').addEventListener('click', () => {
      const val = $('#gen-out').textContent;
      if (!val || val === '—') { toast('ولّد كلمة مرور أولاً'); return; }
      openEditorSheet(null);
      setTimeout(() => {
        const pass = $('#f-pass');
        if (pass) { pass.value = val; pass.type = 'text'; }
      }, 60);
    });
    run();
  }

  /* -------------------------------------------------------------- التدقيق */

  const COMMON = new Set([
    'password', 'passw0rd', '123456', '12345678', '123456789', '1234567890', 'qwerty',
    'azerty', 'abc123', 'letmein', 'welcome', 'admin', 'admin123', 'root', 'iloveyou',
    'monkey', 'dragon', 'sunshine', 'princess', 'football', 'baseball', 'master',
    'shadow', 'superman', 'trustno1', 'passwd', 'secret', 'changeme', 'p@ssw0rd',
    'hello', 'freedom', 'whatever', 'qazwsx', '123qwe',
  ]);

  function assess(pwd) {
    const p = String(pwd || '');
    const issues = [];
    if (!p) return { entropy: 0, level: 'فارغة', score: 0, issues: ['لا توجد كلمة مرور'] };
    let size = 0;
    if (/[a-z]/.test(p)) size += 26;
    if (/[A-Z]/.test(p)) size += 26;
    if (/[0-9]/.test(p)) size += 10;
    if (/[^A-Za-z0-9]/.test(p)) size += 33;
    if (!size) size = 1;
    const entropy = Math.round(p.length * Math.log2(size));
    if (p.length < 12) issues.push(`قصيرة (${p.length} حرفًا، والمفضّل 12+)`);
    if (COMMON.has(p.toLowerCase())) issues.push('من أشهر كلمات المرور استخدامًا');
    if (/^(.)\1+$/.test(p)) issues.push('كل الحروف متطابقة');
    if (/^(19|20)\d{2}$/.test(p)) issues.push('تبدو كسنة فقط');
    let score = entropy >= 95 ? 4 : entropy >= 75 ? 3 : entropy >= 55 ? 2 : entropy >= 35 ? 1 : 0;
    if (issues.length && score > 1) score -= 1;
    const level = ['ضعيفة جدًا', 'ضعيفة', 'متوسطة', 'قوية', 'قوية جدًا'][score];
    return { entropy, level, score, issues };
  }

  function renderAudit() {
    const list = entries();
    const byPass = new Map();
    const issues = [];

    for (const e of list) {
      const a = assess(e.password);
      if (a.score <= 1) {
        issues.push({ type: 'weak', entry: e, text: `كلمة المرور ${a.level} (${a.entropy} بت)` });
      }
      a.issues.forEach((i) => issues.push({ type: 'detail', entry: e, text: i }));
      if (e.password) {
        if (!byPass.has(e.password)) byPass.set(e.password, []);
        byPass.get(e.password).push(e);
      }
      const age = (Date.now() - Date.parse(e.updatedAt || e.createdAt || 0)) / 86400000;
      if (Number.isFinite(age) && age > 180) {
        issues.push({ type: 'stale', entry: e, text: `لم تُحدَّث منذ ${Math.floor(age)} يومًا` });
      }
    }
    let reused = 0;
    byPass.forEach((group) => {
      if (group.length > 1) {
        reused += group.length - 1;
        issues.push({
          type: 'reused',
          entry: group[0],
          text: `كلمة المرور نفسها مستخدمة في ${group.length} مدخلات: ${group.map((g) => g.title).join('، ')}`,
        });
      }
    });

    const strong = list.filter((e) => assess(e.password).score >= 3).length;
    const score = list.length ? Math.max(0, Math.min(100, Math.round((strong / list.length) * 100 - issues.length * 2))) : 100;
    const color = score >= 80 ? 'var(--ok)' : score >= 50 ? 'var(--warn)' : 'var(--danger)';

    const view = $('#view');
    view.innerHTML = `
      <div class="score-ring" style="border-color:${color};color:${color}">${score}%</div>
      <p class="muted" style="text-align:center;margin-bottom:16px">درجة أمان كلمات المرور</p>
      <div class="settings-list" style="margin-bottom:14px">
        <div class="settings-item"><span class="lbl">عدد المدخلات</span><span class="pill">${list.length}</span></div>
        <div class="settings-item"><span class="lbl">كلمات مرور قوية</span><span class="pill ok">${strong}</span></div>
        <div class="settings-item"><span class="lbl">كلمات مرور ضعيفة</span><span class="pill ${list.length - strong ? 'danger' : ''}">${list.length - strong}</span></div>
        <div class="settings-item"><span class="lbl">كلمات مرور مكرّرة</span><span class="pill ${reused ? 'warn' : ''}">${reused}</span></div>
      </div>
      <div class="section-title"><span>الملاحظات (${issues.length})</span></div>
      ${issues.length
        ? issues.map((i) => `
          <div class="audit-item">
            <div class="t">${esc(i.entry.title)}</div>
            <div class="d">${esc(i.text)}</div>
          </div>`).join('')
        : '<div class="empty-state"><div class="big">✅</div><p>لا توجد ملاحظات — كلمات المرور بحالة جيدة.</p></div>'}
    `;
  }

  /* ----------------------------------------------------------- الإعدادات */

  function renderSettings() {
    const s = settings();
    const view = $('#view');
    view.innerHTML = `
      <div class="install-tip" id="install-tip" hidden>
        <b>تثبيت على الجهاز:</b> افتح قائمة المتصفح ← «إضافة إلى الشاشة الرئيسية» لتطبيقه كتطبيق مستقل يعمل بدون إنترنت.
      </div>
      <div class="section-title"><span>الخزنة</span></div>
      <div class="settings-list">
        <div class="settings-item">
          <div><div class="lbl">اسم الخزنة</div><div class="sub" id="vault-meta"></div></div>
          <button class="setting-btn" id="rename-vault">تغيير</button>
        </div>
        <div class="settings-item">
          <div><div class="lbl">القفل التلقائي</div><div class="sub">بعد فترة خمول أو مغادرة التطبيق</div></div>
          <select class="setting-select" id="set-autolock">
            ${[1, 2, 5, 10, 30].map((m) => `<option value="${m}" ${Number(s.autoLockMinutes) === m ? 'selected' : ''}>${m} دقيقة</option>`).join('')}
          </select>
        </div>
        <div class="settings-item">
          <div><div class="lbl">قفل فوري عند مغادرة التطبيق</div><div class="sub">تُقفل الخزنة بمجرد الانتقال لتطبيق آخر</div></div>
          <label class="switch"><input type="checkbox" id="set-lock-bg" ${settings().lockOnBackground ? 'checked' : ''}><span class="slider"></span></label>
        </div>
        <div class="settings-item">
          <div><div class="lbl">مسح الحافظة</div><div class="sub">مسح كلمة المرور المنسوخة تلقائيًا</div></div>
          <select class="setting-select" id="set-clipboard">
            ${[0, 10, 15, 30, 60].map((m) => `<option value="${m}" ${Number(s.clipboardClearSeconds) === m ? 'selected' : ''}>${m === 0 ? 'بدون' : m + ' ثانية'}</option>`).join('')}
          </select>
        </div>
      </div>

      <div class="section-title" style="margin-top:18px"><span>الوسوم</span></div>
      <div class="settings-list" id="tag-manager"></div>
      <div class="row gap" style="margin-top:10px">
        <input type="text" id="new-tag-input" placeholder="اسم وسم جديد" maxlength="24">
        <button class="setting-btn" id="add-tag-btn-settings">إضافة</button>
      </div>

      <div class="section-title" style="margin-top:18px"><span>الاسترجاع</span></div>
      <div class="settings-list">
        <div class="settings-item">
          <div><div class="lbl">كلمة الاسترجاع</div><div class="sub" id="recovery-status">${PV.hasRecovery(state.envelope) ? 'مفعّلة — يمكن فتح الخزنة بها' : 'غير مفعّلة'}</div></div>
          <button class="setting-btn" id="recovery-new">${PV.hasRecovery(state.envelope) ? 'كلمة جديدة' : 'تفعيل'}</button>
        </div>
        <div class="settings-item">
          <div><div class="lbl">تعطيل الاسترجاع</div><div class="sub">لن يُسمح بفتح الخزنة إلا بكلمة المرور</div></div>
          <button class="setting-btn" id="recovery-off" style="color:var(--danger)" ${PV.hasRecovery(state.envelope) ? '' : 'disabled'}>تعطيل</button>
        </div>
      </div>

      <div class="section-title" style="margin-top:18px"><span>النسخ الاحتياطي</span></div>
      <div class="settings-list">
        <div class="settings-item">
          <div><div class="lbl">تصدير نسخة مشفّرة</div><div class="sub">ملف .pv آمن يمكن استعادته على أي جهاز</div></div>
          <button class="setting-btn" id="exp-enc">تصدير</button>
        </div>
        <div class="settings-item">
          <div><div class="lbl">استيراد ملف</div><div class="sub">ملف .pv مشفّر أو نسخة JSON</div></div>
          <button class="setting-btn" id="imp-btn">استيراد</button>
        </div>
        <div class="settings-item">
          <div><div class="lbl">استيراد من CSV</div><div class="sub">ترحيل من تطبيقات أخرى مع مطابقة الأعمدة</div></div>
          <button class="setting-btn" id="imp-csv">استيراد</button>
        </div>
        <div class="settings-item">
          <div><div class="lbl">تصدير نصّي (غير مشفّر)</div><div class="sub">⚠ كلمات المرور ستظهر بدون تشفير</div></div>
          <button class="setting-btn" id="exp-plain">تصدير</button>
        </div>
      </div>

      <div class="section-title" style="margin-top:18px"><span>الأمان</span></div>
      <div class="settings-list">
        <div class="settings-item">
          <div><div class="lbl">تغيير كلمة المرور الرئيسية</div><div class="sub">يعيد تغليف مفتاح الخزنة فقط — بلا إعادة تشفير للمحتوى</div></div>
          <button class="setting-btn" id="chg-master">تغيير</button>
        </div>
        <div class="settings-item">
          <div><div class="lbl">تقوية التشفير</div><div class="sub">scrypt بـ 64 MiB بدل 32 MiB — أبطأ عند الفتح وأقوى ضد التخمين</div></div>
          <button class="setting-btn" id="strengthen">تقوية</button>
        </div>
        <div class="settings-item">
          <div><div class="lbl">حذف الخزنة نهائيًا</div><div class="sub">يمسح كل شيء من هذا الجهاز</div></div>
          <button class="setting-btn" id="wipe-vault" style="color:var(--danger)">حذف</button>
        </div>
      </div>

      <p class="muted" style="text-align:center;margin-top:22px">
        خزنة المفاتيح · AES-256-GCM + scrypt (32 MiB)<br>مفتاح مستقل لكل مدخل · لا تتصل بأي خادم — بياناتك لا تغادر جهازك
      </p>
    `;

    $('#vault-meta').textContent = `${entries().length} مدخل · أُنشئت ${fmtDate(state.envelope && state.envelope.createdAt)}`;
    $('#rename-vault').addEventListener('click', renameVault);
    $('#chg-master').addEventListener('click', changeMasterPassword);
    $('#strengthen').addEventListener('click', strengthenCrypto);
    $('#wipe-vault').addEventListener('click', wipeVault);
    $('#exp-enc').addEventListener('click', exportEncrypted);
    $('#exp-plain').addEventListener('click', exportPlain);
    $('#imp-btn').addEventListener('click', importVault);
    // ---- إدارة الوسوم ----
    const paintTagManager = () => {
      const box = $('#tag-manager');
      const list = tagList();
      box.innerHTML = list.length
        ? list.map((t) => `
          <div class="settings-item">
            <div class="row gap">
              <span class="tag-dot" style="--tc:${t.color}"></span>
              <span class="lbl">${esc(t.name)}</span>
            </div>
            <div class="row gap">
              <button class="setting-btn" data-tag-rename="${esc(t.id)}">اسم</button>
              <button class="setting-btn" data-tag-del="${esc(t.id)}" style="color:var(--danger)">حذف</button>
            </div>
          </div>`).join('')
        : '<div class="settings-item"><span class="muted">لا توجد وسوم مُنشأة — تُنشأ تلقائيًا عند استخدام وسم جديد في أي مدخل.</span></div>';
    };
    paintTagManager();

    $('#tag-manager').addEventListener('click', async (ev) => {
      const ren = ev.target.closest('[data-tag-rename]');
      const del = ev.target.closest('[data-tag-del]');
      if (ren) {
        const tag = tagList().find((t) => t.id === ren.dataset.tagRename);
        if (!tag) return;
        const name = window.prompt('الاسم الجديد للوسم:', tag.name);
        if (!name || !name.trim()) return;
        const oldName = tag.name;
        tag.name = name.trim();
        entries().forEach((e) => {
          e.tags = (e.tags || []).map((t) => (t === oldName ? tag.name : t));
        });
        await persist();
        paintTagManager();
        refreshListIfActive();
        toast('تم تعديل اسم الوسم', 'ok');
      }
      if (del) {
        const tag = tagList().find((t) => t.id === del.dataset.tagDel);
        if (!tag) return;
        const ok = await confirmDialog(
          'حذف الوسم',
          `سيُحذف الوسم "${tag.name}" من كل المدخلات التي تستخدمه.`,
          'حذف',
        );
        if (!ok) return;
        removeTagFromEntries(tag.name);
        state.data.tags = tagList().filter((t) => t.id !== tag.id);
        if (state.filterTag === tag.name) state.filterTag = '';
        await persist();
        paintTagManager();
        refreshListIfActive();
        toast('تم حذف الوسم', 'ok');
      }
    });

    $('#add-tag-btn-settings').addEventListener('click', async () => {
      const input = $('#new-tag-input');
      const name = input.value.trim();
      if (!name) return;
      ensureTag(name);
      input.value = '';
      await persist();
      paintTagManager();
      refreshListIfActive();
      toast('تمت إضافة الوسم', 'ok');
    });

    // ---- إدارة الاسترجاع ----
    $('#recovery-new').addEventListener('click', async () => {
      const phrase = await PV.enableRecovery(state.envelope, state.dataKeyBytes);
      await idbSet('vault', state.envelope);
      showRecoveryPhraseSheet(phrase, () => {
        renderSettings();
        toast('تم إنشاء كلمة استرجاع جديدة', 'ok');
      });
    });

    $('#recovery-off').addEventListener('click', async () => {
      const ok = await confirmDialog(
        'تعطيل الاسترجاع',
        'لن تتمكن بعدها من فتح الخزنة إلا بكلمة المرور الرئيسية. هل أنت متأكد؟',
        'تعطيل',
      );
      if (!ok) return;
      PV.disableRecovery(state.envelope);
      await idbSet('vault', state.envelope);
      renderSettings();
      toast('تم تعطيل الاسترجاع', 'ok');
    });

    $('#set-autolock').addEventListener('change', async (e) => {
      state.data.settings.autoLockMinutes = Number(e.target.value);
      await persist();
      touchActivity();
      toast('تم حفظ الإعداد', 'ok');
    });
    $('#imp-csv').addEventListener('click', importCsv);

    $('#set-lock-bg').addEventListener('change', async (e) => {
      state.data.settings.lockOnBackground = e.target.checked;
      await persist();
      toast('تم حفظ الإعداد', 'ok');
    });

    $('#set-clipboard').addEventListener('change', async (e) => {
      state.data.settings.clipboardClearSeconds = Number(e.target.value);
      await persist();
      toast('تم حفظ الإعداد', 'ok');
    });

    if (deferredInstallPrompt) $('#install-tip').hidden = false;
  }

  async function renameVault() {
    const name = window.prompt('اسم الخزنة الجديد:', settings().vaultName);
    if (!name || !name.trim()) return;
    state.data.settings.vaultName = name.trim();
    $('#vault-title').textContent = state.data.settings.vaultName;
    await persist();
    renderSettings();
    toast('تم تغيير الاسم', 'ok');
  }

  async function changeMasterPassword() {
    const current = window.prompt('كلمة المرور الحالية:');
    if (!current) return;
    try {
      await PV.openEnvelope(state.envelope, current);
    } catch {
      toast('كلمة المرور الحالية غير صحيحة', 'err');
      return;
    }
    const next = window.prompt('كلمة المرور الجديدة (12 حرفًا على الأقل):');
    if (!next) return;
    if (next.length < 12) { toast('قصيرة جدًا — 12 حرفًا على الأقل', 'err'); return; }
    const again = window.prompt('أعد كتابة كلمة المرور الجديدة:');
    if (next !== again) { toast('كلمتا المرور غير متطابقتين', 'err'); return; }

    await PV.changeMasterPassword(state.envelope, state.dataKeyBytes, next);
    await PV.appendLog(state.data, 'rekey', 'تغيير كلمة المرور الرئيسية');
    await persist();
    toast('تم تغيير كلمة المرور الرئيسية', 'ok');
  }

  /** تقوية معاملات scrypt (32 MiB ← 64 MiB) دون تغيير كلمة المرور. */
  async function strengthenCrypto() {
    const ok = await confirmDialog(
      'تقوية التشفير',
      'سيُعاد اشتقاق مفتاح الخزنة بمعاملات أقوى: scrypt بـ 64 MiB بدل 32 MiB. ' +
      'كلمة المرور لا تتغيّر، وقد يستغرق الفتح بضع ثوانٍ بعد إعادة التشغيل.',
      'تقوية',
    );
    if (!ok) return;
    const current = window.prompt('كلمة المرور الحالية (لتأكيد هويتك):');
    if (!current) return;
    try {
      await PV.openEnvelope(state.envelope, current);
    } catch {
      toast('كلمة المرور الحالية غير صحيحة', 'err');
      return;
    }
    try {
      await PV.changeMasterPassword(state.envelope, state.dataKeyBytes, current, PV.STRONG_KDF);
      await PV.appendLog(state.data, 'rekey', 'تقوية: scrypt 64 MiB');
      await persist();
      toast('تم تقوية التشفير — 64 MiB لكل محاولة تخمين', 'ok');
    } catch (err) {
      toast(err.message || 'تعذّر التقوية', 'err');
    }
  }

  async function wipeVault() {
    const ok = await confirmDialog(
      'حذف الخزنة',
      'سيتم مسح كل المدخلات نهائيًا من هذا الجهاز. لا يمكن التراجع.',
      'حذف نهائي',
    );
    if (!ok) return;
    await idbDel('vault');
    lock('تم حذف الخزنة');
    $('#create-toggle').click();
  }

  /* ------------------------------------------------------- تصدير/استيراد */

  function download(filename, content, type = 'application/json') {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }

  async function exportEncrypted() {
    await PV.appendLog(state.data, 'export', 'نسخة مشفّرة (.pv)');
    await persist();
    const stamp = nowIso().slice(0, 10);
    download(`passvault-${stamp}.pv`, JSON.stringify(state.envelope, null, 2));
    toast('تم تنزيل النسخة المشفّرة', 'ok');
  }

  async function exportPlain() {
    const ok = await confirmDialog(
      'تصدير غير مشفّر',
      'سيحتوي الملف على كلمات المرور كنص صريح. احفظه في مكان آمن واحذفه بعد الاستخدام.',
      'تصدير',
    );
    if (!ok) return;
    const payload = { exportedAt: nowIso(), entries: state.data.entries };
    await PV.appendLog(state.data, 'export', 'نسخة نصية (غير مشفّرة)');
    await persist();
    download(`passvault-plain-${nowIso().slice(0, 10)}.json`, JSON.stringify(payload, null, 2));
    toast('تم التنزيل — احذف الملف بعد النسخ', 'ok');
  }

  function importVault() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.pv,.json,application/json';
    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      if (!file) return;
      let parsed;
      try {
        parsed = JSON.parse(await file.text());
      } catch {
        toast('الملف غير صالح', 'err');
        return;
      }

      // ملف خزنة مشفّر (.pv)
      if (parsed && parsed.format === 'passvault' && (parsed.vault || parsed.cipher)) {
        const pw = window.prompt('كلمة المرور الرئيسية أو كلمة الاسترجاع لملف النسخة الاحتياطية:');
        if (!pw) return;
        try {
          const opened = await PV.openEnvelope(parsed, pw);
          const existing = new Set(entries().map((e) => e.title));
          let added = 0;
          (opened.payload.entries || []).forEach((e) => {
            if (!existing.has(e.title)) { entries().push(e); added += 1; }
          });
          await PV.appendLog(state.data, 'import', `${added} مدخل من نسخة مشفّرة`);
          await persist();
          refreshListIfActive();
          toast(`تمت إضافة ${added} مدخل من النسخة`, 'ok');
        } catch {
          toast('تعذّر فك تشفير الملف — كلمة مرور خاطئة؟', 'err');
        }
        return;
      }

      // نسخة JSON نصية
      if (parsed && Array.isArray(parsed.entries)) {
        const ok = await confirmDialog(
          'استيراد نسخة نصية',
          `سيُستورد ${parsed.entries.length} مدخلًا. المدخلات التي لها نفس العنوان لن تُستبدل.`,
          'استيراد',
        );
        if (!ok) return;
        const existing = new Set(entries().map((e) => e.title));
        let added = 0;
        parsed.entries.forEach((e) => {
          if (!existing.has(e.title)) {
            entries().push({ ...e, id: e.id || uid(), createdAt: e.createdAt || nowIso(), updatedAt: e.updatedAt || nowIso() });
            added += 1;
          }
        });
        await PV.appendLog(state.data, 'import', `${added} مدخل من ملف نصي`);
        await persist();
        refreshListIfActive();
        toast(`تمت إضافة ${added} مدخل`, 'ok');
        return;
      }

      toast('صيغة الملف غير مدعومة', 'err');
    });
    input.click();
  }

  /* ---------------------------------------------------------- التبويبات */

  function setTab(tab) {
    state.tab = tab;
    $$('.tab').forEach((b) => b.classList.toggle('active', b.dataset.tab === tab));
    $('#search-row').style.display = tab === 'list' ? 'flex' : 'none';
    if (tab === 'list') renderList();
    else if (tab === 'log') renderLogTab();
    else if (tab === 'gen') renderGenerator();
    else if (tab === 'audit') renderAudit();
    else if (tab === 'settings') renderSettings();
  }

  /* -------------------------------------------------------------- التهيئة */

  let deferredInstallPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredInstallPrompt = e;
  });

  async function boot() {
    const env = await idbGet('vault');
    $('#boot').hidden = true;
    if (env) {
      $('#lock-screen').hidden = false;
      $('#unlock-form').hidden = false;
      $('#create-form').hidden = true;
      setTimeout(() => $('#master-input').focus(), 120);
    } else {
      $('#lock-screen').hidden = false;
      $('#create-toggle').click();
    }
  }

  /* --------------------------------------------------------- الأحداث العامة */

  $$('[data-toggle]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = document.getElementById(btn.dataset.toggle);
      if (!input) return;
      const isPass = input.type === 'password';
      input.type = isPass ? 'text' : 'password';
      btn.textContent = isPass ? 'إخفاء' : 'إظهار';
    });
  });

  $('#unlock-form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const errBox = $('#unlock-error');
    const btn = $('#unlock-btn');
    const input = state.recoveryMode ? $('#recovery-input') : $('#master-input');
    errBox.hidden = true;
    btn.disabled = true;
    btn.textContent = state.recoveryMode ? 'جارٍ الاسترجاع…' : 'جارٍ الفتح…';
    try {
      await unlockVault(input.value);
      input.value = '';
      enterApp();
      if (state.usedRecovery) {
        toast('تم الفتح بكلمة الاسترجاع', 'ok');
      }
    } catch (err) {
      errBox.textContent = err.message;
      errBox.hidden = false;
    } finally {
      btn.disabled = false;
      btn.textContent = state.recoveryMode ? 'استرجاع الخزنة' : 'فتح الخزنة';
    }
  });

  // التبديل بين كلمة المرور وكلمة الاسترجاع
  $('#recovery-toggle').addEventListener('click', () => {
    state.recoveryMode = !state.recoveryMode;
    $('#master-field').hidden = state.recoveryMode;
    $('#recovery-field').hidden = !state.recoveryMode;
    $('#unlock-btn').textContent = state.recoveryMode ? 'استرجاع الخزنة' : 'فتح الخزنة';
    $('#recovery-toggle').textContent = state.recoveryMode
      ? 'استخدم كلمة المرور الرئيسية'
      : 'نسيت كلمة المرور؟ استخدم كلمة الاسترجاع';
    $('#unlock-error').hidden = true;
    setTimeout(() => {
      const target = state.recoveryMode ? $('#recovery-input') : $('#master-input');
      if (target) target.focus();
    }, 80);
  });

  $('#create-form').addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const pwd = $('#new-master-input').value;
    const pwd2 = $('#new-master-input2').value;
    const errBox = $('#create-error');
    errBox.hidden = true;
    if (pwd.length < 12) {
      errBox.textContent = 'كلمة المرور الرئيسية يجب أن تكون 12 حرفًا على الأقل.';
      errBox.hidden = false;
      return;
    }
    if (pwd !== pwd2) {
      errBox.textContent = 'كلمتا المرور غير متطابقتين.';
      errBox.hidden = false;
      return;
    }
    const btn = $('#create-btn');
    btn.disabled = true;
    btn.textContent = 'جارٍ الإنشاء…';
    try {
      const created = await createVault(pwd, $('#vault-name-input').value.trim());
      $('#new-master-input').value = '';
      $('#new-master-input2').value = '';
      if (created.recoveryPhrase) {
        showRecoveryPhraseSheet(created.recoveryPhrase, () => {
          enterApp();
          toast('تم إنشاء الخزنة', 'ok');
        });
      } else {
        enterApp();
        toast('تم إنشاء الخزنة', 'ok');
      }
    } catch (err) {
      errBox.textContent = err.message || 'تعذّر إنشاء الخزنة';
      errBox.hidden = false;
    } finally {
      btn.disabled = false;
      btn.textContent = 'إنشاء الخزنة';
    }
  });

  $('#create-toggle').addEventListener('click', () => {
    $('#unlock-form').hidden = true;
    $('#create-form').hidden = false;
    setTimeout(() => $('#new-master-input').focus(), 60);
  });

  $('#back-to-unlock').addEventListener('click', () => {
    $('#create-form').hidden = true;
    $('#unlock-form').hidden = false;
    setTimeout(() => $('#master-input').focus(), 60);
  });

  $('#new-master-input').addEventListener('input', (e) => {
    const a = assess(e.target.value);
    const bar = $('#meter-bar');
    const colors = ['var(--danger)', 'var(--danger)', 'var(--warn)', 'var(--ok)', 'var(--ok)'];
    bar.style.width = `${Math.min(100, (a.score / 4) * 100)}%`;
    bar.style.background = colors[a.score];
    $('#meter-text').textContent = a.entropy
      ? `${a.level} · ${a.entropy} بت${a.issues.length ? ' — ' + a.issues.join('، ') : ''}`
      : 'استخدم 12 حرفًا على الأقل مع حروف وأرقام ورموز';
  });

  $('#lock-btn').addEventListener('click', () => lock('قُفلت الخزنة'));
  $('#settings-btn').addEventListener('click', () => setTab('settings'));
  $('#fab').addEventListener('click', () => openEditorSheet(null));

  $$('.tab').forEach((btn) => btn.addEventListener('click', () => setTab(btn.dataset.tab)));

  $('#search-input').addEventListener('input', (e) => {
    state.query = e.target.value;
    refreshListIfActive();
  });

  $('#view').addEventListener('click', (ev) => {
    const card = ev.target.closest('.entry-card');
    const btn = ev.target.closest('[data-act]');
    if (btn) {
      ev.stopPropagation();
      const entry = findEntry(btn.dataset.id);
      if (!entry) return;
      if (btn.dataset.act === 'copy-user') copyText(entry.username, 'اسم المستخدم');
      if (btn.dataset.act === 'copy-pass') copyText(entry.password, 'كلمة المرور');
      return;
    }
    if (card) openEntrySheet(card.dataset.id);
  });

  $('#sheet').addEventListener('click', async (ev) => {
    const btn = ev.target.closest('[data-sheet-act]');
    if (!btn) return;
    const id = btn.dataset.id;
    const entry = findEntry(id);
    if (!entry) return;
    const act = btn.dataset.sheetAct;

    if (act === 'reveal') {
      if (state.revealed.has(id)) state.revealed.delete(id);
      else state.revealed.add(id);
      openEntrySheet(id);
    }
    if (act === 'copy-pass') copyText(entry.password, 'كلمة المرور');
    if (act === 'copy-user') copyText(entry.username, 'اسم المستخدم');
    if (act === 'edit') openEditorSheet(id);
    if (act === 'delete') {
      const ok = await confirmDialog('حذف المدخل', `سيُحذف "${entry.title}" نهائيًا.`, 'حذف');
      if (!ok) return;
      const idx = entries().findIndex((x) => x.id === entry.id);
      if (idx >= 0) entries().splice(idx, 1);
      await PV.appendLog(state.data, 'delete', entry.title);
      await persist();
      closeSheet();
      refreshListIfActive();
      toast('تم حذف المدخل', 'ok');
    }
  });

  function enterApp() {
    $('#lock-screen').hidden = true;
    $('#app-screen').hidden = false;
    $('#vault-title').textContent = settings().vaultName || 'خزنة المفاتيح';
    state.query = '';
    $('#search-input').value = '';
    setTab('list');
    touchActivity();
  }

  // تسجيل عامل الخدمة للعمل دون اتصال.
  // داخل تطبيق أندرويد (غلاف WebViewAssetLoader) كل الملفات محلية أصلاً،
  // فلا حاجة لعامل الخدمة — وعند تخطيه نتفادى أي خطأ تسجيل في بيئة بلا TLS.
  const INSIDE_ANDROID_APP = /appassets\.androidplatform\.net$/.test(location.hostname);
  if ('serviceWorker' in navigator && location.protocol.startsWith('http') && !INSIDE_ANDROID_APP) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').catch(() => { /* تجاهل */ });
    });
  }

  boot().catch((err) => {
    $('#boot').hidden = true;
    toast(err.message || 'تعذّر بدء التطبيق', 'err');
  });
})();
