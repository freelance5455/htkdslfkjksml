'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)], clone=x=>JSON.parse(JSON.stringify(x));
const colors={childBoy:['#283447','#5b8de3','#d0a07d'],childGirl:['#4b3155','#e06aa5','#d6a07f'],hero:['#242733','#4169b1','#c98f68'],boy:['#252936','#3d6bd6','#c98f68'],girl:['#6b2c5c','#c84d91','#d29b78'],robot:['#aab2c0','#566273','#aab2c0'],monster:['#233a2b','#4f7b50','#5e7b61'],orc:['#223d2c','#6b4f36','#6d8a63'],ogre:['#3a3430','#6d5741','#78805f'],knight:['#333740','#69727e','#c4936c'],armored:['#262a35','#464b59','#b68462'],alien:['#2e2341','#7b4fb3','#83bda1'],fantasy:['#3a244b','#8b4bb1','#d19b77']};
function char(name='البطل',type='hero',x=0){let c=colors[type]||colors.hero;return{name,type,hair:c[0],shirt:c[1],skin:c[2],x,y:55,rot:0,scale:1,angle:0,expression:'normal',action:'idle',weaponR:'بدون',weaponL:'بدون',armor:'بدون',accessory:'none'}}
const defaultState={version:5.3,backgroundMotion:true,physics:true,weather:'none',easing:'easeInOut',onionSkin:false,lipSync:'simple',autoSave:true,mode:'2d',fps:24,duration:20,time:0,playing:false,recording:false,camera:'mid',bg:'city',fx:'none',fourth:false,fourthMode:'look',dialogue:'',characters:[char()],keys:[],camKeys:[],textKeys:[],fxKeys:[],audioKeys:[],objects:[],scenes:[{name:'المشهد 1',background:'city',objects:[],keys:[],camKeys:[],textKeys:[],fxKeys:[]}],sceneIndex:0,history:[],future:[],buildingCount:0,engine:{quality:'balanced',shadow:false,aa:false,threeDepth:true,cameraFov:55,cameraX:0,cameraY:1.2,cameraZ:6}};
let state=clone(defaultState),timer=null,mediaRecorder=null,videoChunks=[],lastSaveAt=0;
function active(){return state.characters[state.activeChar||0]}
function snap(){state.history.push(clone(state));if(state.history.length>30)state.history.shift();state.future=[]}
function undo(){if(!state.history.length)return;state.future.push(clone(state));state=state.history.pop();syncAll()}
function redo(){if(!state.future.length)return;state.history.push(clone(state));state=state.future.pop();syncAll()}
function syncSceneState(){let s=state.scenes[state.sceneIndex];if(!s)return;s.background=state.bg;s.objects=clone(state.objects);s.keys=clone(state.keys);s.camKeys=clone(state.camKeys);s.textKeys=clone(state.textKeys);s.fxKeys=clone(state.fxKeys)}
function saveLocal(){try{syncSceneState();localStorage.setItem('animeCreator5Project',JSON.stringify(state))}catch(e){}}
function bgStyle(bg){return{studio:'#202631',city:'#182434',house:'#33271f',street:'#1e242b',school:'#2a303a',forest:'#122b20',sea:'#102a38',desert:'#403326',space:'#090b1c',planet:'#30202d',night:'#090d19',castle:'#242034'}[bg]||'#182434'}
function roundRect(ctx,x,y,w,h,r){ctx.beginPath();ctx.roundRect(x,y,w,h,r);ctx.fill()}
function drawBackground(ctx){
ctx.fillStyle=bgStyle(state.bg);ctx.fillRect(0,0,960,540);let t=state.time;
if(['city','street','school','house','castle'].includes(state.bg)){ctx.fillStyle='#202735';for(let i=0;i<12;i++){let h=80+(i*37)%170,x=i*85-20;ctx.fillRect(x,330-h,70,h);ctx.fillStyle='#d9b85d';for(let wy=0;wy<3;wy++)for(let wx=0;wx<2;wx++)ctx.fillRect(x+12+wx*25,350-h+wy*32,10,14);ctx.fillStyle='#202735'}ctx.fillStyle='#25292f';ctx.fillRect(0,430,960,110);ctx.fillStyle='#d4b34f';let off=(t*90)%100;for(let x=-100+off;x<960;x+=100)ctx.fillRect(x,482,55,6);if(state.backgroundMotion){ctx.fillStyle='rgba(255,255,255,.25)';for(let x=-80+((t*45)%120);x<960;x+=120)ctx.fillRect(x,440,42,3)}}
else if(state.bg==='forest'){ctx.fillStyle='#183c28';ctx.fillRect(0,350,960,190);for(let i=0;i<12;i++){let sway=state.backgroundMotion?Math.sin(t*2+i)*5:0;ctx.save();ctx.translate(70+i*80+sway,0);ctx.fillStyle='#4d3425';ctx.fillRect(-12,245,24,180);ctx.fillStyle='#1d5936';ctx.beginPath();ctx.arc(0,220,70,0,7);ctx.fill();ctx.restore()}}
else if(state.bg==='sea'){ctx.fillStyle='#0f5870';ctx.fillRect(0,300,960,240);ctx.fillStyle='#d4e8ef';let wave=state.backgroundMotion?Math.sin(t*2)*18:0;for(let y=340;y<500;y+=45)for(let x=-90;x<960;x+=90)ctx.fillRect(x+((t*55+y)%90)+wave,y,45,4)}
else if(state.bg==='space'||state.bg==='night'||state.bg==='planet'){ctx.fillStyle='#e9eef8';for(let i=0;i<70;i++){let sx=(i*137)%960,sy=(i*71)%360;let dx=state.backgroundMotion?Math.sin(t*.5+i)*8:0;ctx.fillRect(sx+dx,sy,2,2)}if(state.bg==='planet'){ctx.fillStyle='#694b7e';ctx.beginPath();ctx.arc(800+(state.backgroundMotion?Math.sin(t*.4)*25:0),130,80,0,7);ctx.fill()}}
else if(state.bg==='desert'){ctx.fillStyle='#9b754c';ctx.fillRect(0,350,960,190);ctx.fillStyle='#d3b47b';let dx=state.backgroundMotion?(t*25)%120:0;for(let x=-120+dx;x<960;x+=120){ctx.beginPath();ctx.arc(x,380,70,Math.PI,2*Math.PI);ctx.fill()}}
if(state.weather==='rain'){ctx.strokeStyle='rgba(170,210,255,.55)';ctx.lineWidth=2;for(let i=0;i<120;i++){let x=(i*97+t*220)%980,y=(i*53+t*420)%540;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-7,y+18);ctx.stroke()}}
if(state.weather==='snow'){ctx.fillStyle='rgba(255,255,255,.82)';for(let i=0;i<90;i++){let x=(i*113+t*28)%980,y=(i*67+t*42)%540;ctx.beginPath();ctx.arc(x,y,2+(i%3),0,7);ctx.fill()}}
if(state.weather==='clouds'){ctx.fillStyle='rgba(255,255,255,.16)';for(let i=0;i<7;i++){let x=((i*170+t*22)%1120)-120;ctx.beginPath();ctx.arc(x,110+(i%2)*45,34,0,7);ctx.arc(x+40,100+(i%2)*45,45,0,7);ctx.arc(x+82,115+(i%2)*45,30,0,7);ctx.fill()}}
if(state.weather==='fire'){ctx.font='48px serif';for(let i=0;i<8;i++)ctx.fillText('🔥',90+i*115,500-Math.abs(Math.sin(t*3+i))*35)}
if(state.weather==='smoke'){ctx.fillStyle='rgba(220,220,220,.18)';for(let i=0;i<8;i++){let x=120+i*110+Math.sin(t+i)*18,y=430-Math.abs(Math.sin(t*1.5+i))*90;ctx.beginPath();ctx.arc(x,y,24+(i%3)*8,0,7);ctx.fill()}}
if(state.weather==='sunset'){let g=ctx.createLinearGradient(0,0,0,540);g.addColorStop(0,'rgba(120,90,160,.18)');g.addColorStop(1,'rgba(255,150,60,.30)');ctx.fillStyle=g;ctx.fillRect(0,0,960,540);ctx.fillStyle='rgba(255,190,70,.8)';ctx.beginPath();ctx.arc(820,150,38,0,7);ctx.fill()}
ctx.fillStyle='rgba(0,0,0,.18)';ctx.fillRect(0,0,960,42);ctx.fillStyle='#fff';ctx.font='bold 20px system-ui';ctx.fillText(state.bg.toUpperCase()+(state.backgroundMotion?' • ANIMATED':''),20,28)}
function evalObject(o,t){let q=Object.assign({},o);if(o.motion==='float'){q.y+=(Math.sin(t*o.speed+o.phase)*o.amplitude)}if(o.motion==='orbit'){q.x+=Math.cos(t*o.speed+o.phase)*o.radius;q.y+=Math.sin(t*o.speed+o.phase)*o.radius*.55}if(o.motion==='tornado'){let a=t*o.speed+o.phase;q.x+=Math.cos(a)*o.radius;q.y+=Math.sin(a)*o.radius*.45-o.lift*t*20;q.rot+=(a*180/Math.PI)}if(o.motion==='fly'){q.x+=o.vx*t;q.y+=o.vy*t-o.gravity*t*t*.5;q.rot+=o.spin*t}if(o.motion==='collapse'){q.y+=Math.min(o.drop||120,t*o.dropSpeed);q.rot+=t*o.collapseSpin}return q}
function drawObject(ctx,o){o=evalObject(o,state.time);let x=o.x,y=o.y,s=o.scale||1;ctx.save();ctx.translate(x,y);ctx.rotate((o.rot||0)*Math.PI/180);ctx.scale(s,s);ctx.font='72px serif';ctx.textAlign='center';ctx.textBaseline='middle';let emoji={building:'🏢',house:'🏠',tower:'🏢',school:'🏫',shop:'🏪',castle:'🏰',factory:'🏭',bridge:'🌉',road:'🛣️',boat:'⛵',car:'🚗',spaceship:'🚀',planet:'🪐',tree:'🌳',prop:'📦',food:'🍎'}[o.type]||'◆';ctx.fillText(emoji,0,0);if(o.custom){ctx.font='12px system-ui';ctx.fillText(o.custom,0,55)}ctx.restore()}
function drawChar(ctx,c,index){let x=480+c.x,y=360-c.y,sc=c.scale;ctx.save();ctx.translate(x,y);ctx.rotate((c.rot+c.angle*.15)*Math.PI/180);ctx.scale(sc*(['childBoy','childGirl'].includes(c.type)?.72:1),sc*(['childBoy','childGirl'].includes(c.type)?.72:1));if(state.camera==='close')ctx.scale(1.35,1.35);if(state.camera==='wide')ctx.scale(.72,.72);if(state.camera==='orbit')ctx.rotate(Math.sin(state.time*1.5)*.18);ctx.lineWidth=5;ctx.strokeStyle='#111';
ctx.fillStyle=c.shirt;roundRect(ctx,-42,-5,84,105,18);ctx.fillStyle=c.skin;ctx.beginPath();ctx.arc(0,-55,38,0,7);ctx.fill();ctx.fillStyle=c.hair;ctx.beginPath();ctx.arc(0,-68,41,Math.PI,2*Math.PI);ctx.fill();ctx.fillStyle='#111';let eyeY=-58;if(c.expression==='happy'){ctx.beginPath();ctx.arc(-14,eyeY,4,0,7);ctx.arc(14,eyeY,4,0,7);ctx.fill()}else{ctx.beginPath();ctx.arc(-14,eyeY,4,0,7);ctx.arc(14,eyeY,4,0,7);ctx.fill()}if(c.talking){ctx.fillStyle='#4a1018';ctx.beginPath();ctx.ellipse(0,-35,9,5,0,0,7);ctx.fill()}ctx.fillStyle='#eef1f7';ctx.font='bold 12px system-ui';ctx.textAlign='center';ctx.fillText('Y',0,45);ctx.fillStyle='#1c2531';ctx.fillRect(-32,98,24,50);ctx.fillRect(8,98,24,50);
if(c.accessory==='cap'){ctx.fillStyle=c.hair;ctx.fillRect(-43,-88,86,14);ctx.fillRect(8,-82,38,8)}if(c.accessory==='glasses'){ctx.strokeStyle='#111';ctx.strokeRect(-31,-67,25,18);ctx.strokeRect(6,-67,25,18);ctx.beginPath();ctx.moveTo(-6,-58);ctx.lineTo(6,-58);ctx.stroke()}if(c.accessory==='scarf'){ctx.fillStyle='#d45a6a';ctx.fillRect(-43,-25,86,14)}if(c.accessory==='armor'||c.armor!=='بدون'){ctx.strokeStyle='#aab3c1';ctx.strokeRect(-47,-10,94,112)}
ctx.strokeStyle='#151515';ctx.lineWidth=7;ctx.beginPath();ctx.moveTo(-35,12);ctx.lineTo(-70,45);ctx.moveTo(35,12);ctx.lineTo(70,45);ctx.stroke();
ctx.font='34px serif';ctx.textAlign='center';if(c.weaponL!=='بدون')ctx.fillText('⚔️',-78,50);if(c.weaponR!=='بدون')ctx.fillText('⚔️',78,50);
if(state.fourth && index===0){ctx.strokeStyle='#f2cf59';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-13,-52);ctx.lineTo(-5,-51);ctx.moveTo(13,-52);ctx.lineTo(5,-51);ctx.stroke()}ctx.restore();}
function drawSpeech(ctx){if(!state.dialogue&&!state.fourth)return;let text=state.fourth?('👁 '+(state.dialogue||'أنا بكلمك إنت!')):state.dialogue;ctx.fillStyle='rgba(255,255,255,.94)';roundRect(ctx,620,60,300,90,16);ctx.fillStyle='#111';ctx.font='18px system-ui';ctx.textAlign='right';let words=text.split(' '),line='',lines=[];for(let w of words){let test=line+w+' ';if(ctx.measureText(test).width>270){lines.push(line);line=w+' '}else line=test}lines.push(line);lines.slice(0,3).forEach((l,i)=>ctx.fillText(l,895,92+i*25))}
function lerp(a,b,t){return a+(b-a)*t}
function ease(t){t=Math.max(0,Math.min(1,t));switch(state.easing){case'easeIn':return t*t;case'easeOut':return 1-(1-t)*(1-t);case'smooth':return t*t*t*(t*(t*6-15)+10);case'linear':return t;default:return t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2}}
function evalChar(base,index,t){let ks=(state.keys||[]).filter(k=>k.char&&k.charIndex===index).sort((a,b)=>a.t-b.t);if(!ks.length)return base;let before=ks.filter(k=>k.t<=t).pop(),after=ks.find(k=>k.t>t);if(!before)return base;if(!after)return Object.assign({},base,before.char);let q=ease((t-before.t)/(after.t-before.t));let a=before.char,b=after.char,o=Object.assign({},base,before.char);['x','y','rot','scale','angle'].forEach(k=>o[k]=lerp(Number(a[k]||0),Number(b[k]||0),q));return o}
function render2D(){const ctx=$('#canvas2d').getContext('2d');ctx.clearRect(0,0,960,540);drawBackground(ctx);state.objects.forEach(o=>drawObject(ctx,o)); if(state.fx==='tornado'){ctx.save();ctx.strokeStyle='rgba(210,230,255,.65)';ctx.lineWidth=5;for(let i=0;i<9;i++){ctx.beginPath();let r=30+i*18;ctx.arc(700,310,r,0,Math.PI*1.7);ctx.stroke()}ctx.restore()} if(state.fx==='collapse'){ctx.fillStyle='rgba(0,0,0,.18)';ctx.fillRect(650,310,180,80)}if(state.showMotionPath){ctx.save();ctx.strokeStyle='rgba(255,255,255,.35)';ctx.setLineDash([8,8]);ctx.beginPath();let cc=active();ctx.moveTo(480+cc.x,360-cc.y);for(let k of state.keys.filter(k=>k.charIndex===(state.activeChar||0)).sort((a,b)=>a.t-b.t)){ctx.lineTo(480+(k.char?.x||0),360-(k.char?.y||0))}ctx.stroke();ctx.restore()}
if(state.onionSkin){let prev=state.keys.filter(k=>k.charIndex===(state.activeChar||0)&&k.t<state.time).pop();if(prev){ctx.save();ctx.globalAlpha=.22;drawChar(ctx,prev.char,state.activeChar||0);ctx.restore()}}
state.characters.forEach((c,i)=>drawChar(ctx,evalChar(c,i,state.time),i));if(state.fx==='flash'){ctx.fillStyle='rgba(255,255,255,.65)';ctx.fillRect(0,0,960,540)}if(['explosion','buildingBreak','boatBreak','shipBreak'].includes(state.fx)){ctx.font='100px serif';ctx.textAlign='center';ctx.fillText('💥',700,250)}if(state.fx==='swordClash'){ctx.font='70px serif';ctx.fillText('⚔️',600,250);ctx.fillText('✨',650,220)}drawSpeech(ctx);if(state.fourth){ctx.fillStyle='rgba(255,220,80,.9)';ctx.font='bold 16px system-ui';ctx.textAlign='left';ctx.fillText('FOURTH WALL',18,520)}}
function mat4Perspective(fov,aspect,near,far){let f=1/Math.tan(fov*Math.PI/360),nf=1/(near-far);return new Float32Array([f/aspect,0,0,0,0,f,0,0,0,0,(far+near)*nf,-1,0,0,(2*far*near)*nf,0])}
function mat4Mul(a,b){let o=new Float32Array(16);for(let r=0;r<4;r++)for(let c=0;c<4;c++)o[c+r*4]=a[r*4]*b[c]+a[r*4+1]*b[c+4]+a[r*4+2]*b[c+8]+a[r*4+3]*b[c+12];return o}
function mat4Translate(x,y,z){let m=new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]);m[12]=x;m[13]=y;m[14]=z;return m}
function mat4Scale(x,y,z){return new Float32Array([x,0,0,0,0,y,0,0,0,0,z,0,0,0,0,1])}
function mat4RotY(a){let c=Math.cos(a),s=Math.sin(a);return new Float32Array([c,0,-s,0,0,1,0,0,s,0,c,0,0,0,0,1])}
function mat4RotX(a){let c=Math.cos(a),s=Math.sin(a);return new Float32Array([1,0,0,0,0,c,s,0,0,-s,c,0,0,0,0,1])}
function hex4(h){h=(h||'#6688aa').replace('#','');if(h.length===3)h=h.split('').map(x=>x+x).join('');return [parseInt(h.slice(0,2),16)/255,parseInt(h.slice(2,4),16)/255,parseInt(h.slice(4,6),16)/255,1]}
let gl3d=null,gl3dProg=null,gl3dBuf=null,gl3dIndex=null;
function init3D(gl){if(gl3d===gl&&gl3dProg)return;gl3d=gl;const vs=`attribute vec3 p;attribute vec3 n;uniform mat4 uMVP;uniform mat4 uModel;varying vec3 vN;void main(){gl_Position=uMVP*vec4(p,1.0);vN=mat3(uModel)*n;}`;const fs=`precision mediump float;uniform vec4 uColor;varying vec3 vN;void main(){float l=max(dot(normalize(vN),normalize(vec3(-.4,.8,.6))),.18);gl_FragColor=vec4(uColor.rgb*l,uColor.a);}`;function sh(t,src){let x=gl.createShader(t);gl.shaderSource(x,src);gl.compileShader(x);return x}gl3dProg=gl.createProgram();gl.attachShader(gl3dProg,sh(gl.VERTEX_SHADER,vs));gl.attachShader(gl3dProg,sh(gl.FRAGMENT_SHADER,fs));gl.linkProgram(gl3dProg);gl3dBuf=gl.createBuffer();const v=[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1],[-1,-1,-1],[-1,1,-1],[1,1,-1],[1,-1,-1]],faces=[[0,1,2,3,0,0,1],[1,7,6,2,1,0,0],[4,5,6,7,0,0,-1],[0,4,7,1,-1,0,0],[3,2,6,5,0,1,0],[0,4,5,3,0,-1,0]];let data=[];for(let f of faces){let q=f.slice(0,4),n=f.slice(4);for(let i of [0,1,2,0,2,3]){data.push(...v[q[i]],...n)}}gl.bindBuffer(gl.ARRAY_BUFFER,gl3dBuf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);gl3dIndex=data.length/6}
function drawCube3D(gl,viewProj,x,y,z,sx,sy,sz,color,rot=0){let model=mat4Mul(mat4Translate(x,y,z),mat4Mul(mat4RotY(rot),mat4Scale(sx,sy,sz)));let mvp=mat4Mul(viewProj,model);gl.uniformMatrix4fv(gl.getUniformLocation(gl3dProg,'uMVP'),false,mvp);gl.uniformMatrix4fv(gl.getUniformLocation(gl3dProg,'uModel'),false,model);gl.uniform4f(gl.getUniformLocation(gl3dProg,'uColor'),...hex4(color));gl.drawArrays(gl.TRIANGLES,0,gl3dIndex)}
function render3D(){const c=$('#canvas3d'),gl=c.getContext('webgl',{antialias:state.engine?.aa||false,preserveDrawingBuffer:true});if(!gl)return;init3D(gl);gl.viewport(0,0,c.width,c.height);gl.enable(gl.DEPTH_TEST);gl.clearColor(.025,.035,.06,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(gl3dProg);const aspect=c.width/c.height;let camX=state.engine?.cameraX||0,camY=state.engine?.cameraY||1.2,camZ=state.engine?.cameraZ||6;let orbit=state.camera==='orbit'?state.time*.45:0;let eyeX=camX+Math.sin(orbit)*camZ,eyeZ=camZ*Math.cos(orbit),fov=state.engine?.cameraFov||55;let p=mat4Perspective(fov,aspect,.1,100);let view=mat4Mul(mat4RotX(-.08),mat4Translate(-eyeX,-camY,-eyeZ));let vp=mat4Mul(p,view);let ground=state.bg==='space'||state.bg==='night'?'#11172b':'#28343a';drawCube3D(gl,vp,0,-1.25,0,7,.1,5,ground);state.objects.forEach((o,i)=>{let x=(o.x-480)/90,z=(o.y-280)/70;let sc=(o.scale||1);let col=o.type==='tree'?'#3b7047':o.type==='building'||['house','tower','school','shop','castle','factory'].includes(o.type)?'#667080':'#4c7aa1';let h=Math.min(3.8,Math.max(.6,(o.floors||1)*.45))*sc;drawCube3D(gl,vp,x/2,h-1.2,z/2,.45*sc,h,.45*sc,col,i*.15) });state.characters.forEach((c,i)=>{let x=c.x/150,z=i*.4;let sc=c.scale||1;drawCube3D(gl,vp,x/2,.1,z,.38*sc,.8*sc,.28*sc,c.shirt,(c.rot||0)*Math.PI/180);drawCube3D(gl,vp,x/2,1.05*sc,z,.3*sc,.3*sc,.3*sc,c.skin,0);drawCube3D(gl,vp,x/2,1.33*sc,z,.32*sc,.16*sc,.32*sc,c.hair,0);if(c.armor!=='بدون')drawCube3D(gl,vp,x/2,.1,z,.43*sc,.83*sc,.32*sc,'#aab3c1',0)});if(state.fx==='explosion'||state.fx==='buildingBreak'||state.fx==='shipBreak')drawCube3D(gl,vp,2,1,0,.5,.5,.5,'#f0a030',state.time*3);if(state.fourth)drawCube3D(gl,vp,0,1,-1.2,.02,.02,.02,'#f2cf59',0);$('#renderStatus').textContent='3D محرك خفيف • WebGL';}

function render(){render2D();if(state.mode==='3d')render3D();$('#renderStatus').textContent=state.mode==='2d'?'2D جاهز':'3D WebGL جاهز'}
function syncCharInputs(){let c=active();$('#charName').value=c.name;$('#charType').value=c.type;$('#hairColor').value=c.hair;$('#shirtColor').value=c.shirt;$('#skinColor').value=c.skin;$('#angle').value=c.angle;$('#weaponR').value=c.weaponR;$('#weaponL').value=c.weaponL;$('#armor').value=c.armor;$('#activeChar').value=state.activeChar||0}
function draw(){render();$('#time').textContent=Number(state.time).toFixed(1)+' ث';$('#scrub').max=state.duration;$('#scrub').value=state.time;['keys','camKeys','textKeys','fxKeys','audioKeys'].forEach(id=>{let arr=state[id]||[];let el=$('#'+id);el.innerHTML='';arr.forEach(k=>{let d=document.createElement('span');d.className='key';d.style.left=(k.t/state.duration*100)+'%';d.title=k.t+' ث';el.appendChild(d)})});$('#sceneList').innerHTML='';state.scenes.forEach((s,i)=>{let b=document.createElement('button');b.className='miniItem';b.textContent=(i===state.sceneIndex?'▶ ':'')+s.name;b.onclick=()=>selectScene(i);$('#sceneList').appendChild(b)});$('#buildingList').innerHTML='';state.objects.forEach((o,i)=>{let d=document.createElement('span');d.className='miniItem';d.textContent=(i+1)+': '+o.type;$('#buildingList').appendChild(d)});saveLocal()}
function syncAll(){if(!state.characters.length)state.characters=[char()];state.activeChar=Math.min(state.activeChar||0,state.characters.length-1);$('#fps').value=state.fps;$('#duration').value=state.duration;$('#scrub').max=state.duration;$('#dialogueText').value=state.dialogue||'';syncCharInputs();render();draw()}
function addKey(){snap();state.keys.push({t:Number($('#scrub').value),char:clone(active()),charIndex:state.activeChar||0,easing:state.easing});draw()}
function addText(){let v=$('#dialogueText').value.trim();if(!v)return;snap();state.dialogue=v;state.textKeys.push({t:Number($('#scrub').value),text:v});draw()}
function addFx(fx){snap();state.fx=fx;state.fxKeys.push({t:Number($('#scrub').value),fx});draw()}
function selectScene(i){syncSceneState();state.sceneIndex=i;let s=state.scenes[i];state.bg=s.background||'city';state.objects=s.objects||[];state.keys=s.keys||[];state.camKeys=s.camKeys||[];state.textKeys=s.textKeys||[];state.fxKeys=s.fxKeys||[];draw()}
function save(){saveLocal();let blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AnimeCreator5_5-project.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function addScene(){syncSceneState();snap();state.scenes.push({name:'المشهد '+(state.scenes.length+1),background:state.bg,objects:[],keys:[],camKeys:[],textKeys:[],fxKeys:[]});selectScene(state.scenes.length-1)}
function duplicateScene(){let s=clone(state.scenes[state.sceneIndex]);s.name+=' - نسخة';state.scenes.splice(state.sceneIndex+1,0,s);selectScene(state.sceneIndex+1)}
function deleteScene(){if(state.scenes.length<2)return;snap();state.scenes.splice(state.sceneIndex,1);selectScene(Math.max(0,state.sceneIndex-1))}
function setType(type){let c=active(),v=colors[type]||colors.hero;c.type=type;[c.hair,c.shirt,c.skin]=v;syncCharInputs();draw()}
function addObject(type){snap();state.objects.push({type,x:120+(state.objects.length%5)*120,y:280+(state.objects.length%2)*60,scale:Number($('#buildingScale').value)||1});draw()}
function addBuilding(){let type=$('#buildingType').value;let floors=Number($('#floors').value)||3;snap();state.objects.push({type,x:720,y:290,scale:Number($('#buildingScale').value)||1,custom:'طوابق '+floors,floors});draw()}
function interaction(name){snap();state.keys.push({t:Number($('#scrub').value),interaction:name});draw()}
function fourth(mode){snap();state.fourth=true;state.fourthMode=mode;draw()}
function play(){state.playing=true;clearInterval(timer);let last=performance.now();function tick(now){if(!state.playing)return;let dt=Math.min(.05,(now-last)/1000);last=now;state.time+=dt;if(state.time>state.duration)state.time=0;let c=active();if(c.action==='run'||c.action==='walk'){c.x+= (c.action==='run'?180:90)*dt;if(c.x>420)c.x=-420} if(state.physics && state.fx==='tornado'){state.objects.forEach((o,i)=>{o.motion='tornado';o.speed=2.2+i*.15;o.radius=35+i*12;o.amplitude=8;o.phase=i;o.lift=0.7})} draw();timer=requestAnimationFrame(tick)}timer=requestAnimationFrame(tick)}
function stop(){state.playing=false;clearInterval(timer)}
function toggleBgMotion(){snap();state.backgroundMotion=!state.backgroundMotion;draw()}
function tornadoObjects(){snap();state.fx='tornado';state.objects.forEach((o,i)=>Object.assign(o,{motion:'tornado',speed:2+i*.12,radius:35+i*14,phase:i*.7,lift:.35}));draw()}
function collapseBuilding(){snap();let o=state.objects.find(x=>['building','house','tower','school','shop','castle','factory'].includes(x.type));if(o){o.motion='collapse';o.drop=140;o.dropSpeed=.7;o.collapseSpin=(Math.random()-.5)*35}else{state.objects.push({type:'building',x:720,y:290,scale:1,floors:3,motion:'collapse',drop:140,dropSpeed:.7,collapseSpin:-18})}state.fx='collapse';draw()}
function setWeather(w){snap();state.weather=w;draw()}
function smartMove(){snap();let c=active(),start=c.x,target=Math.max(-380,Math.min(380,start<0?300:-300));c.action='run';let t0=state.time;state.keys.push({t:Number(t0.toFixed(3)),char:clone(c),charIndex:state.activeChar||0,easing:'easeInOut'});let end=Math.min(state.duration,t0+2);let c2=clone(c);c2.x=target;state.keys.push({t:Number(end.toFixed(3)),char:c2,charIndex:state.activeChar||0,easing:'easeInOut'});draw()}
function cameraFocus(){snap();state.camera='close';state.camKeys.push({t:Number(state.time),camera:'close'});draw()}
function cameraTransition(){snap();state.camKeys.push({t:Number(state.time),camera:state.camera,transition:'smooth'});draw()}
function previewLip(){state.lipSync='simple';state.dialogue=state.dialogue||'مرحبًا!';draw();let start=performance.now();let loop=now=>{let dt=(now-start)/1000;if(dt>2){active().talking=false;draw();return}active().talking=Math.floor(dt*10)%2===0;draw();requestAnimationFrame(loop)};requestAnimationFrame(loop)}
function motionPath(){state.showMotionPath=!state.showMotionPath;draw()}
function autoSaveTick(){if(state.autoSave){try{syncSceneState();localStorage.setItem('animeCreator5Autosave',JSON.stringify(state));lastSaveAt=Date.now();let el=$('#saveStatus');if(el)el.textContent='آخر حفظ تلقائي: '+new Date(lastSaveAt).toLocaleTimeString('ar-EG')}catch{}}}
let recordRAF=0,lastRecord=0;function record(){state.recording=!state.recording;$('#recordBadge').classList.toggle('hidden',!state.recording);if(state.recording){lastRecord=0;function sample(now){if(!state.recording)return;if(now-lastRecord>=1000/state.fps){lastRecord=now;state.keys.push({t:Number(state.time.toFixed(3)),char:clone(active()),charIndex:state.activeChar||0})}recordRAF=requestAnimationFrame(sample)}recordRAF=requestAnimationFrame(sample)}else cancelAnimationFrame(recordRAF);draw()}
function exportVideo(){stop();let canvas=state.mode==='2d'?$('#canvas2d'):$('#canvas3d');if(!canvas.captureStream||!window.MediaRecorder){alert('التصدير غير مدعوم في WebView الحالي. افتح المشروع في متصفح حديث يدعم MediaRecorder.');return}videoChunks=[];let stream=canvas.captureStream(state.fps),mime=['video/mp4;codecs=avc1','video/webm;codecs=vp9','video/webm'].find(x=>MediaRecorder.isTypeSupported(x))||'';try{mediaRecorder=new MediaRecorder(stream,mime?{mimeType:mime}:undefined)}catch{mediaRecorder=new MediaRecorder(stream)}let outType=mediaRecorder.mimeType||'video/webm',ext=outType.includes('mp4')?'mp4':'webm';mediaRecorder.ondataavailable=e=>{if(e.data.size)videoChunks.push(e.data)};mediaRecorder.onstop=()=>{let blob=new Blob(videoChunks,{type:outType}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='AnimeCreator5_5-episode.'+ext;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),2000)};mediaRecorder.start();let old=state.time,startT=performance.now();state.time=0;let loop=now=>{if(now-startT>=state.duration*1000){mediaRecorder.stop();state.time=old;draw();return}state.time=(now-startT)/1000;render();requestAnimationFrame(loop)};requestAnimationFrame(loop)}
$('#easing').onchange=e=>{snap();state.easing=e.target.value;draw()};$('#onionSkin').onchange=e=>{state.onionSkin=e.target.checked;draw()};$('#motionPath').onclick=motionPath;$('#smartMove').onclick=smartMove;$('#cameraFocus').onclick=cameraFocus;$('#cameraTransition').onclick=cameraTransition;$('#previewLipSync').onclick=previewLip;$('#lipSync').onchange=e=>{state.lipSync=e.target.value;draw()};$('#weatherRain').onclick=()=>setWeather('rain');$('#weatherSnow').onclick=()=>setWeather('snow');$('#weatherClouds').onclick=()=>setWeather('clouds');$('#weatherFire').onclick=()=>setWeather('fire');$('#weatherSmoke').onclick=()=>setWeather('smoke');$('#weatherSunset').onclick=()=>setWeather('sunset');$('#recoverAutosave').onclick=()=>{try{let a=localStorage.getItem('animeCreator5Autosave');if(a){state=Object.assign(clone(defaultState),JSON.parse(a));syncAll();alert('تم استرجاع آخر حفظ محلي.')}}catch{alert('لا يوجد حفظ صالح')}};$('#clearAutosave').onclick=()=>{localStorage.removeItem('animeCreator5Autosave');let e=$('#saveStatus');if(e)e.textContent='تم مسح الحفظ المؤقت.'};$('#autoSave').onchange=e=>{state.autoSave=e.target.checked};
$('#play').onclick=play;$('#stop').onclick=stop;$('#record').onclick=record;$('#addKey').onclick=addKey;$('#addScene').onclick=addScene;$('#duplicateScene').onclick=duplicateScene;$('#deleteScene').onclick=deleteScene;$('#addText').onclick=addText;$('#addDialogueKey').onclick=addText;$('#speak').onclick=()=>{if('speechSynthesis'in window){let u=new SpeechSynthesisUtterance(state.dialogue||'');u.lang='ar-EG';speechSynthesis.cancel();speechSynthesis.speak(u)}};$('#save').onclick=save;$('#exportProject').onclick=save;$('#exportVideo').onclick=exportVideo;$('#exportCharacter').onclick=()=>{let blob=new Blob([JSON.stringify(active(),null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=(active().name||'character')+'.character.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};$('#importCharacter').onclick=()=>$('#charFile').click();$('#charFile').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let c=JSON.parse(r.result);snap();state.characters[state.activeChar||0]=Object.assign(char(),c);syncAll()}catch{alert('ملف شخصية غير صالح')}};r.readAsText(f)};$('#undo').onclick=undo;$('#redo').onclick=redo;$('#newProject').onclick=()=>{if(confirm('بدء مشروع جديد؟')){state=clone(defaultState);syncAll()}};$('#load').onclick=()=>$('#file').click();$('#file').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{state=Object.assign(clone(defaultState),JSON.parse(r.result));state.version=5.5; ensure54();state.weather=state.weather||'none';state.easing=state.easing||'easeInOut';state.lipSync=state.lipSync||'simple';state.backgroundMotion=state.backgroundMotion!==false;state.physics=state.physics!==false;state.engine=Object.assign(clone(defaultState.engine),state.engine||{});syncAll()}catch{alert('ملف غير صالح')}};r.readAsText(f)};$('#addAudio').onclick=()=>$('#audioFile').click();$('#audioFile').onchange=e=>{let f=e.target.files[0];if(f){snap();state.audioKeys.push({t:Number(state.time),name:f.name});draw()}};
['x','y','rot','scale'].forEach(id=>$('#'+id).oninput=e=>{active()[id]=Number(e.target.value);draw()});$('#angle').oninput=e=>{active().angle=Number(e.target.value);draw()};$('#scrub').oninput=e=>{state.time=Number(e.target.value);draw()};$('#fps').onchange=e=>{snap();state.fps=Number(e.target.value);draw()};$('#duration').onchange=e=>{snap();state.duration=Math.max(1,Math.min(300,Number(e.target.value)||20));draw()};$('#activeChar').onchange=e=>{state.activeChar=Number(e.target.value);syncCharInputs();draw()};$('#charName').oninput=e=>{active().name=e.target.value;draw()};$('#charType').onchange=e=>{snap();setType(e.target.value)};$('#hairColor').oninput=e=>{active().hair=e.target.value;draw()};$('#shirtColor').oninput=e=>{active().shirt=e.target.value;draw()};$('#skinColor').oninput=e=>{active().skin=e.target.value;draw()};$('#weaponR').onchange=e=>{snap();active().weaponR=e.target.value;draw()};$('#weaponL').onchange=e=>{snap();active().weaponL=e.target.value;draw()};$('#armor').onchange=e=>{snap();active().armor=e.target.value;draw()};
$$('[data-preset]').forEach(b=>b.onclick=()=>{snap();setType(b.dataset.preset)});$$('[data-accessory]').forEach(b=>b.onclick=()=>{snap();active().accessory=b.dataset.accessory;draw()});$$('[data-expression]').forEach(b=>b.onclick=()=>{snap();active().expression=b.dataset.expression;draw()});$$('[data-action]').forEach(b=>b.onclick=()=>{snap();active().action=b.dataset.action;draw()});$$('[data-interaction]').forEach(b=>b.onclick=()=>interaction(b.dataset.interaction));$$('[data-bg]').forEach(b=>b.onclick=()=>{snap();state.bg=b.dataset.bg;state.scenes[state.sceneIndex].background=state.bg;draw()});$$('[data-fx]').forEach(b=>b.onclick=()=>addFx(b.dataset.fx));$$('[data-cam]').forEach(b=>b.onclick=()=>{snap();state.camera=b.dataset.cam;$$('[data-cam]').forEach(x=>x.classList.toggle('active',x===b));state.camKeys.push({t:Number(state.time),camera:state.camera});draw()});$('#camReset').onclick=()=>{state.camera='mid';$$('[data-cam]').forEach(x=>x.classList.toggle('active',x.dataset.cam==='mid'));draw()};$('#addCharacter').onclick=()=>{if(state.characters.length>=2)return alert('يدعم الإصدار الحالي شخصيتين داخل المشهد');snap();state.characters.push(char('الشخصية 2','girl',130));state.activeChar=1;syncAll()};$('#dualAttack').onclick=()=>{snap();active().weaponR=active().weaponR==='بدون'?'سيف':active().weaponR;active().weaponL=active().weaponL==='بدون'?'فأس':active().weaponL;active().action='attack';addKey()};$('#food').onclick=()=>{addObject('food');interaction('eat')};$('#objectInteract').onclick=()=>interaction('objectInteract');$('#throwObject').onclick=()=>interaction('throw');$('#addBuilding').onclick=addBuilding;['addRoad','addBoat','addCar','addSpaceship','addPlanet','addTree','addProp'].forEach(id=>$('#'+id).onclick=()=>addObject(id.replace('add','').toLowerCase()));$('#toggleBgMotion').onclick=toggleBgMotion;$('#tornadoObjects').onclick=tornadoObjects;$('#collapseBuilding').onclick=collapseBuilding;$('#cameraShake').onclick=()=>addFx('cameraShake');$('#cameraZoom').onclick=()=>addFx('cameraZoom');$('#cameraFollow').onclick=()=>addFx('cameraFollow');$('#fourthWall').onclick=()=>fourth('look');$('#lookCamera').onclick=()=>fourth('look');$('#talkCamera').onclick=()=>fourth('talk');$('#pointCamera').onclick=()=>fourth('point');$('#cameraReply').onclick=()=>fourth('reply');$('#fourthEnabled').onchange=e=>{snap();state.fourth=e.target.checked;draw()};$$('[data-mode]').forEach(b=>b.onclick=()=>{state.mode=b.dataset.mode;$$('[data-mode]').forEach(x=>x.classList.toggle('active',x===b));$('#canvas2d').classList.toggle('hidden',state.mode!=='2d');$('#canvas3d').classList.toggle('hidden',state.mode!=='3d');render()});
function setEngine(){state.engine=state.engine||clone(defaultState.engine);$('#engineQuality').value=state.engine.quality;$('#fov').value=state.engine.cameraFov;$('#camX').value=state.engine.cameraX;$('#camY').value=state.engine.cameraY;$('#camZ').value=state.engine.cameraZ}
['engineQuality','fov','camX','camY','camZ'].forEach(id=>$('#'+id).oninput=e=>{state.engine=state.engine||clone(defaultState.engine);if(id==='engineQuality')state.engine.quality=e.target.value;else if(id==='fov')state.engine.cameraFov=Number(e.target.value);else state.engine[{camX:'cameraX',camY:'cameraY',camZ:'cameraZ'}[id]]=Number(e.target.value);draw()});$('#engineAuto').onclick=()=>{state.engine.quality='low';state.engine.aa=false;state.fps=Math.min(state.fps,24);setEngine();draw()};$('#engineReset').onclick=()=>{state.engine.cameraX=0;state.engine.cameraY=1.2;state.engine.cameraZ=6;state.engine.cameraFov=55;setEngine();draw()};


/* ===================== AnimeCreator 5.4 Safe & Smooth =====================
/* 5.4 keeps everything local and adds lightweight features without external libraries. */
state.version=5.5;
state.v54=state.v54||{safeMode:true,weatherSpeed:1,weatherIntensity:1,worldSpeed:1,gravity:false,collision:true,bounce:false,groundLock:true,dragging:false,rig:{}};
function ensure54(){
  state.version=5.5;
  state.v54=Object.assign({safeMode:true,weatherSpeed:1,weatherIntensity:1,worldSpeed:1,gravity:false,collision:true,bounce:false,groundLock:true,rig:{}},state.v54||{});
  state.characters.forEach((c,i)=>{c.bodyPreset=c.bodyPreset||'normal';c.headScale=c.headScale||1;c.bodyScale=c.bodyScale||1;c.pose=c.pose||{};c.pose.armR=Number(c.pose.armR||0);c.pose.armL=Number(c.pose.armL||0);c.pose.legR=Number(c.pose.legR||0);c.pose.legL=Number(c.pose.legL||0);});
}
ensure54();
const v54download=(blob,name)=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1200)};
function addCharacter54(){snap();let i=state.characters.length+1;state.characters.push(char('الشخصية '+i,i%2?'boy':'girl',-180+((i*90)%360)));state.activeChar=state.characters.length-1;ensure54();syncAll()}
function duplicateCharacter54(){snap();let c=clone(active());c.name=c.name+' - نسخة';c.x+=70;state.characters.push(c);state.activeChar=state.characters.length-1;syncAll()}
function removeCharacter54(){if(state.characters.length<=1)return;snap();state.characters.splice(state.activeChar||0,1);state.activeChar=Math.max(0,(state.activeChar||0)-1);syncAll()}
function centerCharacter54(){snap();active().x=0;active().y=55;draw()}
function setBody54(v){let c=active();c.bodyPreset=v;if(v==='slim'){c.bodyScale=.88;c.headScale=.98}else if(v==='strong'){c.bodyScale=1.15;c.headScale=1.02}else if(v==='child'){c.bodyScale=.78;c.headScale=1.12}else{c.bodyScale=1;c.headScale=1}draw()}
function setPose54(name){snap();let c=active();let p={armR:0,armL:0,legR:0,legL:0};if(name==='talk'){p.armR=18;p.armL=-12}else if(name==='run'){p.armR=-35;p.armL=35;p.legR=25;p.legL=-25}else if(name==='jump'){p.armR=-35;p.armL=-35;p.legR=20;p.legL=-20}else if(name==='point'){p.armR=-55;p.armL=10}c.pose=p;c.action=name==='run'?'run':name==='talk'?'talk':'idle';draw()}
function setRig54(k,v){active().pose=active().pose||{};active().pose[k]=Number(v);draw()}
function worldTemplate54(kind){snap();state.objects=[];let add=(type,x,y,scale=1,extra={})=>state.objects.push(Object.assign({type,x,y,scale},extra));if(kind==='city'){for(let i=0;i<7;i++)add('building',90+i*125,315-(i%3)*35,1+(i%2)*.25,{floors:2+i%5});for(let i=0;i<4;i++)add('car',80+i*220,430,1)}else if(kind==='school'){add('school',480,300,1.7,{floors:3});for(let i=0;i<3;i++)add('tree',100+i*360,350,1)}else if(kind==='forest'){for(let i=0;i<10;i++)add('tree',60+i*95,330+(i%2)*35,1)}else if(kind==='space'){add('planet',760,150,1.8);add('spaceship',250,230,1);add('spaceship',500,180,.7)}else{for(let i=0;i<5;i++)add('house',80+i*190,330,1);for(let i=0;i<4;i++)add('tree',40+i*240,360,.8)}draw()}
function addWorldPart54(type){snap();state.objects.push({type,x:300+(state.objects.length%4)*150,y:320-(state.objects.length%2)*40,scale:1});draw()}
function physics54(){state.v54.gravity=!state.v54.gravity;draw()}
function collision54(){state.v54.collision=!state.v54.collision;draw()}
function bounce54(){state.v54.bounce=!state.v54.bounce;draw()}
function ground54(){snap();active().y=55;state.v54.groundLock=true;draw()}
function clearMotion54(){snap();state.keys=state.keys.filter(k=>k.charIndex!==(state.activeChar||0));active().action='idle';draw()}
function smartPath54(action){snap();let c=active(),idx=state.activeChar||0,start=clone(c),end=clone(c);end.x=c.x<0?330:-330;end.action=action;let t=Number(state.time.toFixed(3)),e=Math.min(state.duration,t+2.5);state.keys.push({t,char:start,charIndex:idx,easing:'easeInOut'});state.keys.push({t:Number(e.toFixed(3)),char:end,charIndex:idx,easing:'easeInOut'});draw()}
function autoFollow54(){snap();let idx=state.activeChar||0,target=state.characters.findIndex((_,i)=>i!==idx);if(target<0)return;let c=clone(active()),other=state.characters[target];c.x=other.x-90;state.keys.push({t:Number(state.time),char:clone(active()),charIndex:idx});let e=Math.min(state.duration,state.time+2),end=clone(c);end.x=other.x-50;state.keys.push({t:Number(e.toFixed(3)),char:end,charIndex:idx});draw()}
function addCam54(camera){snap();state.camera=camera;state.camKeys.push({t:Number(state.time.toFixed(3)),camera,transition:'smooth'});draw()}
function safeMode54(){state.v54.safeMode=!state.v54.safeMode;state.engine.aa=false;state.engine.quality=state.v54.safeMode?'low':'balanced';if(state.v54.safeMode)state.fps=Math.min(state.fps,24);setEngine();draw()}
function optimize54(){state.engine.quality='low';state.engine.aa=false;state.engine.shadow=false;state.fps=Math.min(state.fps,24);state.v54.worldSpeed=.75;state.v54.weatherIntensity=.65;setEngine();draw()}
function lowMemory54(){state.engine.quality='low';state.engine.aa=false;state.engine.shadow=false;state.fps=12;state.duration=Math.min(state.duration,120);state.v54.weatherIntensity=.4;setEngine();draw()}
function diagnostic54(){let parts=[];parts.push('FPS '+state.fps);parts.push('شخصيات '+state.characters.length);parts.push('أشياء '+state.objects.length);parts.push('مفاتيح '+state.keys.length);parts.push('مشاهد '+state.scenes.length);let el=$('#diagnosticTextV54');if(el)el.textContent='فحص محلي: '+parts.join(' • ');}
function bind54(){
 const q=id=>document.getElementById(id); const on=(id,ev,fn)=>{let e=q(id);if(e)e[ev]=fn};
 on('addCharacterV54','onclick',addCharacter54);on('duplicateCharacterV54','onclick',duplicateCharacter54);on('removeCharacterV54','onclick',removeCharacter54);on('centerCharacterV54','onclick',centerCharacter54);
 on('bodyPresetV54','onchange',e=>{snap();setBody54(e.target.value)});on('headV54','oninput',e=>{active().headScale=Number(e.target.value);draw()});on('bodyV54','oninput',e=>{active().bodyScale=Number(e.target.value);draw()});
 [['poseResetV54','idle'],['poseTalkV54','talk'],['poseRunV54','run'],['poseJumpV54','jump'],['posePointV54','point']].forEach(([id,p])=>on(id,'onclick',()=>setPose54(p)));
 [['armRV54','armR'],['armLV54','armL'],['legRV54','legR'],['legLV54','legL']].forEach(([id,k])=>on(id,'oninput',e=>setRig54(k,e.target.value)));
 [['worldCityV54','city'],['worldSchoolV54','school'],['worldForestV54','forest'],['worldSpaceV54','space'],['worldVillageV54','village']].forEach(([id,k])=>on(id,'onclick',()=>worldTemplate54(k)));
 [['addRoomV54','room'],['addFloorV54','floor'],['addWindowV54','window'],['addLightV54','light']].forEach(([id,k])=>on(id,'onclick',()=>addWorldPart54(k)));on('clearObjectsV54','onclick',()=>{snap();state.objects=[];draw()});
 on('weatherSpeedV54','oninput',e=>{state.v54.weatherSpeed=Number(e.target.value);draw()});on('weatherIntensityV54','oninput',e=>{state.v54.weatherIntensity=Number(e.target.value);draw()});on('worldSpeedV54','oninput',e=>{state.v54.worldSpeed=Number(e.target.value);draw()});
 on('physicsToggleV54','onclick',()=>{state.physics=!state.physics;draw()});on('gravityV54','onclick',physics54);on('bounceV54','onclick',bounce54);on('collisionV54','onclick',collision54);on('groundV54','onclick',ground54);on('autoWalkV54','onclick',()=>smartPath54('walk'));on('autoRunV54','onclick',()=>smartPath54('run'));on('autoFollowV54','onclick',autoFollow54);on('clearMotionV54','onclick',clearMotion54);
 [['shotWideV54','wide'],['shotMediumV54','mid'],['shotCloseV54','close'],['shotOverV54','over'],['shotOrbitV54','orbit']].forEach(([id,k])=>on(id,'onclick',()=>addCam54(k)));on('followV54','onclick',()=>addFx('cameraFollow'));on('focusV54','onclick',cameraFocus);on('shakeV54','onclick',()=>addFx('cameraShake'));on('transitionV54','onclick',cameraTransition);on('cameraResetV54','onclick',()=>{state.camera='mid';draw()});
 on('keyStartV54','onclick',()=>{state.time=0;addKey()});on('keyEndV54','onclick',()=>{state.time=state.duration;addKey()});on('duplicateKeyV54','onclick',()=>{let c=clone(active()),idx=state.activeChar||0;snap();state.keys.push({t:Number(Math.min(state.duration,state.time+1).toFixed(3)),char:c,charIndex:idx});draw()});on('clearKeysV54','onclick',clearMotion54);on('easeAllV54','onclick',()=>{state.easing='smooth';draw()});
 on('safeModeV54','onclick',safeMode54);on('optimizeV54','onclick',optimize54);on('lowMemoryV54','onclick',lowMemory54);on('diagnosticV54','onclick',diagnostic54);
}
function pointerDrag54(){const c=$('#canvas2d');if(!c)return;let down=false,offsetX=0,offsetY=0;const pos=e=>{let r=c.getBoundingClientRect(),x=(e.clientX-r.left)*960/r.width,y=(e.clientY-r.top)*540/r.height;return{x,y}};const hit=(x,y)=>{let best=-1,dist=80;state.characters.forEach((ch,i)=>{let px=480+ch.x,py=360-ch.y,d=Math.hypot(x-px,y-py);if(d<dist){dist=d;best=i}});return best};c.addEventListener('pointerdown',e=>{if(state.mode!=='2d')return;let p=pos(e),i=hit(p.x,p.y);if(i<0)return;state.activeChar=i;syncCharInputs();down=true;let cp=active();offsetX=p.x-(480+cp.x);offsetY=p.y-(360-cp.y);c.setPointerCapture?.(e.pointerId);});c.addEventListener('pointermove',e=>{if(!down)return;let p=pos(e),ch=active();ch.x=p.x-480-offsetX;ch.y=360-p.y+offsetY;draw()});c.addEventListener('pointerup',e=>{if(!down)return;down=false;addKey()});c.addEventListener('pointercancel',()=>down=false)}
function patchDraw54(){ensure54();let orig=window.draw;window.draw=function(){orig();let el=document.getElementById('saveStatus');if(el&&state.v54)el.dataset.v54='1';}}
function migrate54(){ensure54();state.scenes=state.scenes||[];state.scenes.forEach(s=>{s.objects=s.objects||[];s.keys=s.keys||[];s.camKeys=s.camKeys||[];s.textKeys=s.textKeys||[];s.fxKeys=s.fxKeys||[]});try{localStorage.setItem('animeCreator54Project',JSON.stringify(state))}catch{}}
try{migrate54();bind54();pointerDrag54();}catch(e){console.warn('AnimeCreator 5.4 init',e)}

try{let old=localStorage.getItem('animeCreator5Project');if(old)state=Object.assign(clone(defaultState),JSON.parse(old));state.engine=Object.assign(clone(defaultState.engine),state.engine||{});if(!state.scenes[0].objects)state.scenes.forEach(x=>Object.assign(x,{objects:x.objects||[],keys:x.keys||[],camKeys:x.camKeys||[],textKeys:x.textKeys||[],fxKeys:x.fxKeys||[]}))}catch{}setEngine();syncAll();setInterval(autoSaveTick,5000);try{let a=localStorage.getItem('animeCreator5Autosave');if(a&&state.autoSave===true){/* recovery is manual */}}catch{}


/* 5.4 visual rig + lightweight physics patch */
(function(){
 const oldDrawChar=drawChar;
 drawChar=function(ctx,c,index){
   let x=480+c.x,y=360-c.y,sc=c.scale||1,pose=c.pose||{};
   ctx.save();ctx.translate(x,y);ctx.rotate((c.rot+(c.angle||0)*.15)*Math.PI/180);
   const child=['childBoy','childGirl'].includes(c.type)||c.bodyPreset==='child';
   const body=(c.bodyScale||1)*(child?.82:1),head=(c.headScale||1)*(child?1.1:1);
   ctx.scale(sc*body,sc*body); if(state.camera==='close')ctx.scale(1.35,1.35);if(state.camera==='wide')ctx.scale(.72,.72);if(state.camera==='orbit')ctx.rotate(Math.sin(state.time*1.5)*.18);
   ctx.lineWidth=5;ctx.strokeStyle='#111';
   ctx.fillStyle=c.shirt;roundRect(ctx,-42,-5,84,105,18);
   ctx.fillStyle=c.skin;ctx.beginPath();ctx.arc(0,-55,38*head,0,7);ctx.fill();
   ctx.fillStyle=c.hair;ctx.beginPath();ctx.arc(0,-68,41*head,Math.PI,2*Math.PI);ctx.fill();
   ctx.fillStyle='#111';ctx.beginPath();ctx.arc(-14,-58,4,0,7);ctx.arc(14,-58,4,0,7);ctx.fill();
   if(c.talking){ctx.fillStyle='#4a1018';ctx.beginPath();ctx.ellipse(0,-35,9,5,0,0,7);ctx.fill()}
   ctx.fillStyle='#eef1f7';ctx.font='bold 12px system-ui';ctx.textAlign='center';ctx.fillText('Y',0,45);
   ctx.fillStyle='#1c2531';ctx.fillRect(-32,98,24,50);ctx.fillRect(8,98,24,50);
   ctx.strokeStyle='#151515';ctx.lineWidth=7;
   ctx.save();ctx.translate(-35,12);ctx.rotate((pose.armL||0)*Math.PI/180);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-35,33);ctx.stroke();ctx.restore();
   ctx.save();ctx.translate(35,12);ctx.rotate((pose.armR||0)*Math.PI/180);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(35,33);ctx.stroke();ctx.restore();
   ctx.save();ctx.translate(-20,98);ctx.rotate((pose.legL||0)*Math.PI/180);ctx.fillRect(-12,0,24,50);ctx.restore();
   ctx.save();ctx.translate(20,98);ctx.rotate((pose.legR||0)*Math.PI/180);ctx.fillRect(-12,0,24,50);ctx.restore();
   if(c.accessory==='cap'){ctx.fillStyle=c.hair;ctx.fillRect(-43,-88,86,14);ctx.fillRect(8,-82,38,8)}
   if(c.accessory==='glasses'){ctx.strokeStyle='#111';ctx.strokeRect(-31,-67,25,18);ctx.strokeRect(6,-67,25,18);ctx.beginPath();ctx.moveTo(-6,-58);ctx.lineTo(6,-58);ctx.stroke()}
   if(c.accessory==='scarf'){ctx.fillStyle='#d45a6a';ctx.fillRect(-43,-25,86,14)}
   if(c.accessory==='armor'||c.armor!=='بدون'){ctx.strokeStyle='#aab3c1';ctx.strokeRect(-47,-10,94,102)}
   if(state.fourth&&index===0){ctx.strokeStyle='#f2cf59';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-13,-52);ctx.lineTo(-5,-51);ctx.moveTo(13,-52);ctx.lineTo(5,-51);ctx.stroke()}
   ctx.restore();
 };
 const oldPlay=play;
 play=function(){
   state.playing=true;clearInterval(timer);let last=performance.now();function tick(now){if(!state.playing)return;let dt=Math.min(.05,(now-last)/1000);last=now;state.time+=dt;if(state.time>state.duration)state.time=0;
     if(state.physics&&state.v54?.gravity){state.characters.forEach(c=>{if(c.y>55){c.y=Math.max(55,c.y-180*dt);if(c.y===55&&state.v54.bounce)c.y=72}})}
     state.objects.forEach(o=>{if(o.motion==='fly'&&state.v54?.gravity)o.vy=(o.vy||0)+220*dt;if(state.v54?.groundLock&&['car','boat','road'].includes(o.type))o.y=Math.min(o.y,440)});
     let c=active();if(c.action==='run'||c.action==='walk'){c.x+=(c.action==='run'?180:90)*dt;if(c.x>420)c.x=-420}
     if(state.physics&&state.fx==='tornado'){state.objects.forEach((o,i)=>{o.motion='tornado';o.speed=2.2+i*.15;o.radius=35+i*12;o.amplitude=8;o.phase=i;o.lift=.7})}
     draw();timer=requestAnimationFrame(tick)}timer=requestAnimationFrame(tick)
 };
})();

/* ================= AnimeCreator 5.5 FINAL ENGINE PATCH ================= */
(function(){
  const V='animeCreator55Project';
  function e(id){return document.getElementById(id)}
  function ensure55(){
    state.version=5.5;
    state.v55=Object.assign({characterModes:{},modelStyles:{},camAngle:'normal',lowCam:1.2,portals:[],combat:{power:1,speed:1,sequence:0}},state.v55||{});
    state.v55.characterModes=state.v55.characterModes||{}; state.v55.modelStyles=state.v55.modelStyles||{};
    state.v55.portals=state.v55.portals||[]; state.v55.combat=Object.assign({power:1,speed:1,sequence:0},state.v55.combat||{});
    state.characters.forEach((c,i)=>{c.renderMode=c.renderMode||state.v55.characterModes[i]||'2d';c.modelStyle=c.modelStyle||state.v55.modelStyles[i]||'anime';c.fallState=c.fallState||0});
  }
  function save55(){try{localStorage.setItem(V,JSON.stringify(state))}catch(_){} }
  function setStatus(t){let x=e('statusV55');if(x)x.textContent=t}
  function active55(){return state.characters[state.activeChar||0]||state.characters[0]}
  function sync55(){ensure55();let c=active55();if(e('renderModeV55'))e('renderModeV55').value=c.renderMode||'2d';if(e('modelStyleV55'))e('modelStyleV55').value=c.modelStyle||'anime';if(e('camAngleV55'))e('camAngleV55').value=state.v55.camAngle||'normal';if(e('lowCamV55'))e('lowCamV55').value=state.v55.lowCam??1.2}
  function addPortal55(kind){snap();ensure55();let n=state.v55.portals.length,o={kind,shape:e('portalShapeV55')?.value||'circle',color:e('portalColorV55')?.value||'#6d5dfc',size:Number(e('portalSizeV55')?.value||1),action:e('portalActionV55')?.value||'teleport',x:260+(n%4)*140,y:400,active:true,targetX:-280+(n%3)*140,targetY:70};state.v55.portals.push(o);state.objects.push({type:kind==='pit'?'pit':kind==='gate'?'gate':'portal',x:o.x,y:o.y,scale:o.size,portalIndex:n});draw();setStatus(kind==='pit'?'تمت إضافة حفرة':'تمت إضافة بوابة')}
  function clearPortals55(){snap();state.v55.portals=[];state.objects=state.objects.filter(o=>!['portal','pit','gate'].includes(o.type));draw();setStatus('تم مسح البوابات والحفر')}
  function obj55(type){snap();state.objects.push({type:'prop',custom:type,x:150+(state.objects.length%6)*120,y:390,scale:1,motion:'none'});draw()}
  function setMode55(v){snap();let c=active55();c.renderMode=v;state.v55.characterModes[state.activeChar||0]=v;sync55();draw();setStatus('الشخصية الحالية: '+(v==='3d'?'3D':'2D'))}
  function setCam55(v){state.v55.camAngle=v; if(v==='low'||v==='ground')state.engine.cameraY=Number(e('lowCamV55')?.value||0.2); else if(v==='high')state.engine.cameraY=3.5; else state.engine.cameraY=1.2;draw();setStatus(v==='low'||v==='ground'?'كاميرا من أسفل إلى أعلى':'زاوية الكاميرا: '+v)}
  function combat55(kind){snap();ensure55();let c=active55(),idx=state.activeChar||0,p=Number(e('combatPowerV55')?.value||1),speed=Number(e('combatSpeedV55')?.value||1),t=Number(state.time.toFixed(3));c.action=kind;c.combat={type:kind,power:p,speed:speed,at:t};state.v55.combat={power:p,speed,sequence:(state.v55.combat.sequence||0)+1};state.keys.push({t,char:clone(c),charIndex:idx,easing:'easeInOut',combat:true});if(kind==='combo'){let c2=clone(c);c2.x+=80*p;c2.rot=8;c2.pose={armL:-55,armR:55,legL:18,legR:-18};state.keys.push({t:Math.min(state.duration,t+0.35/speed),char:c2,charIndex:idx,easing:'easeOut',combat:true})}if(kind==='dodge'){let c2=clone(c);c2.x+=(idx%2?-100:100)*p;c2.y+=45*p;state.keys.push({t:Math.min(state.duration,t+0.4/speed),char:c2,charIndex:idx,easing:'easeInOut',combat:true})}if(kind==='dash'){let c2=clone(c);c2.x+=(c.x<0?180:-180)*p;state.keys.push({t:Math.min(state.duration,t+0.3/speed),char:c2,charIndex:idx,easing:'easeOut',combat:true})}addFx(kind==='shockwave'?'energy':'cameraShake');draw();setStatus('تمت إضافة حركة قتال: '+kind)}
  function autoScene55(){snap();ensure55();state.bg='city';state.objects.push({type:'building',x:180,y:300,scale:1.2,floors:3},{type:'streetlight',custom:'streetlight',x:650,y:370,scale:1},{type:'tree',x:780,y:350,scale:1},{type:'portal',x:520,y:390,scale:1,portalIndex:state.v55.portals.length});state.v55.portals.push({kind:'portal',shape:'circle',color:'#6d5dfc',size:1,action:'teleport',x:520,y:390,targetX:-260,targetY:70,active:true});state.characters[0].x=-220;if(state.characters[1])state.characters[1].x=170;state.camera='mid';draw();setStatus('تم بناء مشهد تلقائي')}
  function cinematic55(){snap();state.camera='close';state.camKeys.push({t:state.time,camera:'wide',transition:'smooth'},{t:Math.min(state.duration,state.time+1),camera:'mid',transition:'smooth'},{t:Math.min(state.duration,state.time+2),camera:'low',transition:'smooth'},{t:Math.min(state.duration,state.time+3),camera:'close',transition:'smooth'});state.fx='cameraShake';draw();setStatus('تم إنشاء لقطة سينمائية')}
  function optimize55(){state.engine.quality='low';state.engine.aa=false;state.engine.shadow=false;state.fps=Math.min(Number(state.fps)||24,24);state.v54=state.v54||{};state.v54.safeMode=true;state.v54.weatherIntensity=.55;save55();draw();setStatus('تم تحسين المحرك لوضع خفيف')}
  function diag55(){ensure55();setStatus('5.5 • '+state.characters.length+' شخصيات • '+state.objects.length+' مجسم • '+state.v55.portals.length+' بوابة/حفرة • '+state.keys.length+' حركة')}
  function portalCollision55(){ensure55();state.characters.forEach(c=>{state.v55.portals.forEach(o=>{if(!o.active)return;let d=Math.hypot((c.x+480)-o.x,(360-c.y)-o.y);let hit=o.kind==='pit'?55:65;if(d<hit*(o.size||1)){if(o.action==='teleport'){c.x=(o.targetX||0);c.y=(o.targetY||70)}else if(o.action==='fall'){c.fallState=.001;c.y=Math.max(-80,c.y-140*.016);if(c.y<=-70){c.x=o.targetX||0;c.y=o.targetY||70;c.fallState=0}}else{c.x=o.targetX||c.x;c.y=o.targetY||c.y}}})})}
  const oldRender3D=window.render3D;
  window.render3D=function(){
    const c=$('#canvas3d'),gl=c&&c.getContext('webgl',{antialias:state.engine?.aa||false,preserveDrawingBuffer:true});if(!gl){oldRender3D();return}init3D(gl);gl.viewport(0,0,c.width,c.height);gl.enable(gl.DEPTH_TEST);gl.clearColor(.018,.024,.05,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.useProgram(gl3dProg);
    const aspect=c.width/c.height;let low=state.v55?.camAngle==='low'||state.v55?.camAngle==='ground';let high=state.v55?.camAngle==='high';let camY=state.v55?.camAngle==='ground'?-.35:(low?Number(state.v55?.lowCam??.3):(high?3.5:(state.engine?.cameraY||1.2)));let camZ=state.engine?.cameraZ||6;let orbit=state.camera==='orbit'?state.time*.45:0;let eyeX=(state.engine?.cameraX||0)+Math.sin(orbit)*camZ,eyeZ=camZ*Math.cos(orbit),fov=state.engine?.cameraFov||55;let p=mat4Perspective(fov,aspect,.1,100),view=mat4Mul(mat4RotX(low?.13:-.08),mat4Translate(-eyeX,-camY,-eyeZ)),vp=mat4Mul(p,view);
    drawCube3D(gl,vp,0,-1.25,0,7,.1,5,state.bg==='space'?'#151a35':'#28343a');
    state.objects.forEach((o,i)=>{let x=(o.x-480)/90,z=(o.y-280)/70,sc=o.scale||1;if(['portal','pit','gate'].includes(o.type)){let col=state.v55?.portals?.[o.portalIndex]?.color||'#6d5dfc';drawCube3D(gl,vp,x/2,-1.08,z/2,.7*sc,.05,.7*sc,col,i*.2);return}let col=o.type==='tree'?'#3b7047':o.type==='building'?'#667080':'#4c7aa1';let h=Math.min(3.8,Math.max(.6,(o.floors||1)*.45))*sc;drawCube3D(gl,vp,x/2,h-1.2,z/2,.45*sc,h,.45*sc,col,i*.15)});
    state.characters.forEach((ch,i)=>{let x=ch.x/150,z=(i*.45);let sc=ch.scale||1;if((ch.renderMode||'2d')==='3d'){let h=(ch.bodyScale||1)*sc;drawCube3D(gl,vp,x/2,.15,z,.38*h,.9*h,.28*h,ch.shirt,(ch.rot||0)*Math.PI/180);drawCube3D(gl,vp,x/2,1.18*h,z,.3*h,.32*h,.3*h,ch.skin,0);drawCube3D(gl,vp,x/2,1.5*h,z,.33*h,.18*h,.33*h,ch.hair,0);if(ch.accessory==='cap')drawCube3D(gl,vp,x/2,1.67*h,z,.4*h,.06*h,.38*h,ch.hair,0)}else{drawCube3D(gl,vp,x/2,.15,z,.38*sc,.9*sc,.28*sc,ch.shirt,(ch.rot||0)*Math.PI/180)}});
    if(state.fx==='explosion'||state.fx==='cameraShake'||state.fx==='energy')drawCube3D(gl,vp,0,1,0,.55,.55,.55,state.fx==='energy'?'#65b7ff':'#f0a030',state.time*3);$('#renderStatus').textContent='3D 5.5 • WebGL خفيف • كاميرا '+(low?'من أسفل':high?'من أعلى':'سينمائية');
  };
  const oldDrawChar55=window.drawChar;
  window.drawChar=function(ctx,c,index){oldDrawChar55(ctx,c,index);if(c.renderMode==='3d'){ctx.save();ctx.strokeStyle='rgba(100,180,255,.5)';ctx.lineWidth=2;let x=480+c.x,y=360-c.y;ctx.beginPath();ctx.arc(x,y-55,48,0,Math.PI*2);ctx.stroke();ctx.restore()}};
  const oldDraw55=window.draw;
  window.draw=function(){ensure55();oldDraw55();portalCollision55();save55()};
  function bind55(){
    ensure55();sync55();
    if(e('renderModeV55'))e('renderModeV55').onchange=x=>setMode55(x.target.value);if(e('modelStyleV55'))e('modelStyleV55').onchange=x=>{active55().modelStyle=x.target.value;state.v55.modelStyles[state.activeChar||0]=x.target.value;draw()};if(e('camAngleV55'))e('camAngleV55').onchange=x=>setCam55(x.target.value);if(e('lowCamV55'))e('lowCamV55').oninput=x=>{state.v55.lowCam=Number(x.target.value);if(state.v55.camAngle==='low'||state.v55.camAngle==='ground')setCam55(state.v55.camAngle);};
    e('lowShotV55')&&(e('lowShotV55').onclick=()=>setCam55('low'));e('frontShotV55')&&(e('frontShotV55').onclick=()=>setCam55('normal'));e('topShotV55')&&(e('topShotV55').onclick=()=>setCam55('high'));e('resetShotV55')&&(e('resetShotV55').onclick=()=>setCam55('normal'));
    e('addPortalV55')&&(e('addPortalV55').onclick=()=>addPortal55('portal'));e('addPitV55')&&(e('addPitV55').onclick=()=>addPortal55('pit'));e('addGateV55')&&(e('addGateV55').onclick=()=>addPortal55('gate'));e('clearPortalsV55')&&(e('clearPortalsV55').onclick=clearPortals55);
    document.querySelectorAll('[data-v55obj]').forEach(b=>b.onclick=()=>obj55(b.dataset.v55obj));
    [['comboV55','combo'],['dodgeV55','dodge'],['blockV55','block'],['impactV55','impact'],['dashV55','dash'],['shockwaveV55','shockwave']].forEach(([id,k])=>e(id)&&(e(id).onclick=()=>combat55(k)));
    e('autoSceneV55')&&(e('autoSceneV55').onclick=autoScene55);e('cinematicV55')&&(e('cinematicV55').onclick=cinematic55);e('optimizeV55')&&(e('optimizeV55').onclick=optimize55);e('diagnosticV55')&&(e('diagnosticV55').onclick=diag55);
  }
  try{let old=localStorage.getItem(V);if(old)state=Object.assign(clone(defaultState),JSON.parse(old));}catch(_){}
  ensure55();bind55();save55();
  /* 5.5 animation tick: portal triggers + lightweight combat motion */
  const prevPlay=window.play;
  window.play=function(){state.playing=true;clearInterval(timer);let last=performance.now();function tick(now){if(!state.playing)return;let dt=Math.min(.05,(now-last)/1000);last=now;state.time+=dt;if(state.time>state.duration)state.time=0;state.characters.forEach(c=>{if(c.action==='combo'||c.action==='impact'){c.y=Math.max(55,c.y+Math.sin(state.time*18)*2)}if(c.action==='dodge'){c.rot=Math.sin(state.time*15)*8}if(c.action==='dash'){c.x+=dt*260*(c.x<0?1:-1)}});portalCollision55();draw();timer=requestAnimationFrame(tick)}timer=requestAnimationFrame(tick)};
})();

/* AnimeCreator 5.6 — Adaptive Anime Engine for Android 10 / 2GB RAM
   Design choice: 2D cel-shaded anime renderer is the default visual engine.
   Lightweight WebGL 3D remains optional for depth/camera shots. */
(function(){
  const AC56_KEY='animeCreator56Project';
  function ensure56(){
    state.version=5.6;
    state.v56=Object.assign({engine:'adaptive-anime-2d',quality:'low',pixelRatio:1,maxVisibleObjects:36,maxCharacters:4,aa:false,shadows:false,outline:true,cel:true,threeEnabled:true,threeMaxObjects:24,threeMaxCharacters:3},state.v56||{});
    state.engine=Object.assign({quality:'low',shadow:false,aa:false,threeDepth:true,cameraFov:55,cameraX:0,cameraY:1.2,cameraZ:6},state.engine||{});
    state.engine.quality='low';state.engine.aa=false;state.engine.shadow=false;
    state.characters=(state.characters||[]).slice(0,4);
    state.characters.forEach(c=>{c.renderMode=c.renderMode||'2d';c.modelStyle=c.modelStyle||'anime';c.faceStyle=c.faceStyle||'anime';c.outline=c.outline!==false});
  }
  function save56(){try{syncSceneState();localStorage.setItem(AC56_KEY,JSON.stringify(state))}catch(_){}
  }
  ensure56();

  // Lightweight anime/cartoon 2D renderer: simple cel shading, clean silhouette, no heavy assets.
  function animeChar56(ctx,c,index){
    let x=480+c.x,y=360-c.y,sc=(c.scale||1)*(['childBoy','childGirl'].includes(c.type)?.72:1);
    if(state.camera==='close')sc*=1.25; else if(state.camera==='wide')sc*=.78;
    ctx.save();ctx.translate(x,y);ctx.rotate(((c.rot||0)+(c.angle||0)*.12)*Math.PI/180);ctx.scale(sc,sc);
    const outline=c.outline!==false?'#141820':'transparent';
    const skin=c.skin||'#c98f68',hair=c.hair||'#283447',shirt=c.shirt||'#4169b1';
    // shadow
    ctx.fillStyle='rgba(0,0,0,.18)';ctx.beginPath();ctx.ellipse(0,151,48,10,0,0,Math.PI*2);ctx.fill();
    // legs / shoes
    ctx.fillStyle='#20242d';ctx.fillRect(-30,88,24,58);ctx.fillRect(6,88,24,58);
    ctx.fillStyle='#f2f4f7';ctx.beginPath();ctx.ellipse(-18,150,24,9,0,0,Math.PI*2);ctx.ellipse(18,150,24,9,0,0,Math.PI*2);ctx.fill();
    // torso with cel highlight
    ctx.fillStyle=shirt;roundRect(ctx,-45,-8,90,104,20);ctx.fillStyle='rgba(255,255,255,.10)';roundRect(ctx,-37,2,18,78,10);
    // neck/head
    ctx.fillStyle=skin;ctx.fillRect(-11,-18,22,18);ctx.beginPath();ctx.arc(0,-58,40,0,Math.PI*2);ctx.fill();
    // ears
    ctx.beginPath();ctx.arc(-39,-56,7,0,Math.PI*2);ctx.arc(39,-56,7,0,Math.PI*2);ctx.fill();
    // hair silhouette + spikes
    ctx.fillStyle=hair;ctx.beginPath();ctx.arc(0,-69,43,Math.PI,Math.PI*2);ctx.lineTo(37,-62);ctx.lineTo(29,-78);ctx.lineTo(15,-70);ctx.lineTo(5,-90);ctx.lineTo(-8,-72);ctx.lineTo(-25,-87);ctx.lineTo(-24,-68);ctx.lineTo(-43,-61);ctx.closePath();ctx.fill();
    // eyes / expression
    ctx.fillStyle='#141820';let ey=-57;
    if(c.expression==='happy'){ctx.lineWidth=4;ctx.strokeStyle='#141820';ctx.beginPath();ctx.arc(-14,ey,7,Math.PI+.2,Math.PI*2-.2);ctx.arc(14,ey,7,Math.PI+.2,Math.PI*2-.2);ctx.stroke()}
    else {ctx.beginPath();ctx.ellipse(-14,ey,5,8,0,0,Math.PI*2);ctx.ellipse(14,ey,5,8,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(-12,-60,2,0,7);ctx.arc(16,-60,2,0,7);ctx.fill()}
    if(c.expression==='angry'){ctx.strokeStyle='#141820';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-24,-69);ctx.lineTo(-7,-64);ctx.moveTo(24,-69);ctx.lineTo(7,-64);ctx.stroke()}
    if(c.expression==='surprised'||c.expression==='scared'){ctx.fillStyle='#431b2b';ctx.beginPath();ctx.ellipse(0,-33,8,11,0,0,7);ctx.fill()}
    else if(c.talking){ctx.fillStyle='#431b2b';ctx.beginPath();ctx.ellipse(0,-33,10,5,0,0,7);ctx.fill()}
    // Y logo
    ctx.fillStyle='#f3f5f8';ctx.font='bold 14px system-ui';ctx.textAlign='center';ctx.fillText('Y',0,48);
    // arms: pose-aware but intentionally simple
    const p=c.pose||{};ctx.strokeStyle=outline;ctx.lineWidth=9;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(-37,14);ctx.lineTo(p.armL||-68,46);ctx.moveTo(37,14);ctx.lineTo(p.armR||68,46);ctx.stroke();
    // clean outline around body/head, kept minimal for performance
    if(c.outline!==false){ctx.strokeStyle=outline;ctx.lineWidth=3;ctx.beginPath();ctx.roundRect(-45,-8,90,104,20);ctx.stroke();ctx.beginPath();ctx.arc(0,-58,40,0,Math.PI*2);ctx.stroke()}
    if(c.accessory==='glasses'){ctx.strokeStyle='#151a22';ctx.lineWidth=3;ctx.strokeRect(-31,-67,25,18);ctx.strokeRect(6,-67,25,18);ctx.beginPath();ctx.moveTo(-6,-58);ctx.lineTo(6,-58);ctx.stroke()}
    if(c.accessory==='cap'){ctx.fillStyle=hair;ctx.fillRect(-43,-88,86,13);ctx.fillRect(8,-81,38,7)}
    if(c.accessory==='scarf'){ctx.fillStyle='#d45a6a';ctx.fillRect(-44,-24,88,13)}
    if(state.fourth&&index===0){ctx.strokeStyle='#f2cf59';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-11,-53);ctx.lineTo(-4,-51);ctx.moveTo(11,-53);ctx.lineTo(4,-51);ctx.stroke()}
    ctx.restore();
  }
  window.drawChar=animeChar56;

  // Adaptive background: preserve existing backgrounds but cap expensive particles.
  const oldDrawBackground=window.drawBackground;
  window.drawBackground=function(ctx){oldDrawBackground(ctx);};

  // Performance-safe 2D render wrapper. Objects are capped to avoid runaway scenes on 2GB RAM.
  const oldRender2D=window.render2D;
  window.render2D=function(){
    ensure56();
    const oldObjects=state.objects;
    if(oldObjects.length>state.v56.maxVisibleObjects) state.objects=oldObjects.slice(0,state.v56.maxVisibleObjects);
    try{oldRender2D()}finally{state.objects=oldObjects}
    if(state.mode==='2d' && state.v56.outline){
      const ctx=$('#canvas2d')?.getContext('2d');
      if(ctx && state.characters.length){state.characters.slice(0,4).forEach((c,i)=>animeChar56(ctx,c,i)); if(typeof drawSpeech==='function')drawSpeech(ctx)}
    }
  };

  // Make 3D deliberately low-poly and cheap: one WebGL context, no AA, limited draw calls, DPR=1.
  const oldRender3D56=window.render3D;
  window.render3D=function(){
    ensure56();
    const c=$('#canvas3d'); if(!c)return;
    c.width=960;c.height=540;
    try{oldRender3D56()}catch(e){$('#renderStatus').textContent='3D غير متاح — استخدم 2D الخفيف'}
    $('#renderStatus').textContent='3D اختياري • Low Poly • بدون ظلال/AA';
  };

  // Smart device profile. The app always prefers the light profile on this phone class.
  window.anime56LightMode=function(){
    ensure56();state.v56.quality='low';state.v56.engine='adaptive-anime-2d';state.v56.threeEnabled=true;state.v56.maxVisibleObjects=36;state.v56.threeMaxObjects=24;state.fps=Math.min(Number(state.fps)||24,24);state.engine.quality='low';state.engine.aa=false;state.engine.shadow=false;state.engine.cameraZ=6;save56();draw();
  };
  window.anime56SetEngine=function(mode){
    ensure56(); if(mode==='2d'){state.mode='2d';state.v56.engine='anime-2d';}
    else if(mode==='3d'){state.mode='3d';state.v56.engine='low-poly-3d';}
    else {state.mode='2d';state.v56.engine='adaptive-anime-2d';}
    $('#canvas2d')?.classList.toggle('hidden',state.mode!=='2d');$('#canvas3d')?.classList.toggle('hidden',state.mode!=='3d');save56();draw();
  };
  window.anime56LightMode();

  // Use the new local save key while retaining old project compatibility.
  const oldSave56=window.saveLocal;
  window.saveLocal=function(){try{save56()}catch(_){try{oldSave56()}catch(__){}}};
  window.animeCreatorEngine='5.6 Adaptive Anime — 2D Cel + Optional Low-Poly 3D';
  setTimeout(()=>{try{save56();draw()}catch(_){ }},0);
})();

/* ===================== AnimeCreator 5.6.1 Upgrade Pack =====================
/* Local-first: no network calls, no camera/microphone APIs, lightweight on Android 10/2GB. */
(function(){
  'use strict';
  const q=id=>document.getElementById(id), esc=s=>String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  function ensure(){
    state.version=5.61;
    state.v561=Object.assign({localOnly:true,autoKey:true,weaponVisual:true,actionFx:true,maxChars:4,maxObjects:36},state.v561||{});
    state.characters=(state.characters||[]).slice(0,4);
    state.characters.forEach(c=>{c.pose=c.pose||{};c.bodyScale=c.bodyScale||1;c.headScale=c.headScale||1;c.weaponR=c.weaponR||'بدون';c.weaponL=c.weaponL||'بدون';c.expression=c.expression||'normal';c.action=c.action||'idle';});
    state.audioKeys=state.audioKeys||[]; state.textKeys=state.textKeys||[]; state.camKeys=state.camKeys||[]; state.fxKeys=state.fxKeys||[];
  }
  ensure();
  function panel(){
    if(q('upgrade561')) return;
    const host=document.querySelector('.tools'); if(!host)return;
    const p=document.createElement('div');p.id='upgrade561';p.className='up56';
    p.innerHTML=`<h3>🚀 حزمة التطوير 5.6.1</h3>
    <div class="up56grid">
      <button id="upAddChar">👥 إضافة شخصية</button><button id="upDupChar">⧉ نسخ الشخصية</button><button id="upDelChar">🗑 حذف الشخصية</button>
      <button id="upKey">◆ إضافة Keyframe</button><button id="upClearKeys">🧹 مفاتيح الشخصية</button><button id="upCenter">🎯 توسيط</button>
      <button id="upLowCam">📷 لقطة من أسفل</button><button id="upGroundCam">🎥 من مستوى الأرض</button><button id="upTopCam">⬆️ لقطة علوية</button>
      <button id="upBattle">⚔️ لقطة قتال</button><button id="upBreakBuilding">🏢 انهيار مبنى</button><button id="upBreakShip">🚀 انفجار مؤثر للمركبة</button>
      <button id="upImpact">💥 تأثير اصطدام</button><button id="upEnergy">⚡ موجة طاقة</button><button id="upDash">💨 اندفاع</button>
      <button id="upCity">🏙 مدينة جاهزة</button><button id="upSpace">🌌 مشهد فضائي</button><button id="upSchool">🏫 مدرسة جاهزة</button>
      <button id="upLocalCheck">🔒 فحص محلي</button><button id="upClearStorage">🧹 مسح الحفظ المحلي</button>
    </div><div class="status" id="upStatus">5.6.1 • محلي • حتى 4 شخصيات • مناسب للوضع الخفيف</div><div class="danger">لن يطلب هذا الإصدار كاميرا أو ميكروفون، ولا يضيف اتصالًا خارجيًا.</div>`;
    host.appendChild(p);
    const on=(id,fn)=>{let e=q(id);if(e)e.onclick=fn};
    on('upAddChar',()=>{if(state.characters.length>=4){msg('الحد الأقصى 4 شخصيات في المشهد الخفيف');return}snap();let i=state.characters.length+1;state.characters.push(char('الشخصية '+i,i%2?'boy':'girl',-180+((i*100)%360)));state.activeChar=i-1;ensure();syncAll();msg('تمت إضافة الشخصية '+i)});
    on('upDupChar',()=>{if(state.characters.length>=4){msg('الحد الأقصى 4 شخصيات');return}snap();let c=clone(active());c.name=(c.name||'الشخصية')+' - نسخة';c.x+=70;state.characters.push(c);state.activeChar=state.characters.length-1;syncAll();msg('تم نسخ الشخصية')});
    on('upDelChar',()=>{if(state.characters.length<=1){msg('يجب أن تبقى شخصية واحدة');return}snap();state.characters.splice(state.activeChar||0,1);state.activeChar=Math.max(0,(state.activeChar||0)-1);syncAll();msg('تم حذف الشخصية')});
    on('upKey',()=>{snap();state.keys.push({t:Number(state.time.toFixed(3)),char:clone(active()),charIndex:state.activeChar||0,easing:state.easing,source:'5.6.1'});draw();msg('تم حفظ الحركة في خط الزمن')});
    on('upClearKeys',()=>{snap();let i=state.activeChar||0;state.keys=state.keys.filter(k=>k.charIndex!==i);draw();msg('تم مسح مفاتيح الشخصية الحالية')});
    on('upCenter',()=>{snap();active().x=0;active().y=55;addKey();draw();msg('تم توسيط الشخصية وإضافة حركة')});
    on('upLowCam',()=>shot('low'));on('upGroundCam',()=>shot('ground'));on('upTopCam',()=>shot('high'));
    on('upBattle',()=>{snap();let c=active();c.action='attack';c.pose={armR:55,armL:-55,legR:18,legL:-18};c.weaponR=c.weaponR==='بدون'?'سيف':c.weaponR;c.weaponL=c.weaponL==='بدون'?'فأس':c.weaponL;state.fx='impact';state.fxKeys.push({t:Number(state.time.toFixed(3)),fx:'impact'});state.keys.push({t:Number(state.time.toFixed(3)),char:clone(c),charIndex:state.activeChar||0,easing:'easeInOut',combat:true});draw();msg('تم إنشاء لقطة قتال غير دموية')});
    on('upBreakBuilding',()=>addObjectFX('buildingBreak','🏢 انهيار مؤثر'));
    on('upBreakShip',()=>addObjectFX('shipBreak','🚀 مؤثر مركبة'));
    on('upImpact',()=>addObjectFX('impact','💥 اصطدام'));
    on('upEnergy',()=>addObjectFX('energy','⚡ موجة طاقة'));
    on('upDash',()=>{snap();let c=active(),i=state.activeChar||0,t=Number(state.time.toFixed(3)),e=Math.min(state.duration,t+.45);c.action='dash';let a=clone(c),b=clone(c);b.x+=(c.x<0?180:-180);state.keys.push({t,char:a,charIndex:i,easing:'easeInOut'},{t:e,char:b,charIndex:i,easing:'easeOut'});state.fx='cameraShake';draw();msg('تمت إضافة اندفاع سريع')});
    on('upCity',()=>template('city'));on('upSpace',()=>template('space'));on('upSchool',()=>template('school'));
    on('upLocalCheck',()=>{let suspicious=[];try{let src=document.documentElement.innerHTML+'\n'+(window.__acSourceHint||'');['fetch(','XMLHttpRequest','WebSocket(','getUserMedia','mediaDevices','navigator.geolocation','<iframe'].forEach(x=>{if(src.includes(x))suspicious.push(x)})}catch(e){}msg(suspicious.length?'تنبيه: راجع '+suspicious.join('، '):'الفحص المحلي: لا توجد واجهات شبكة/كاميرا/ميكروفون في الواجهة الحالية');});
    on('upClearStorage',()=>{if(confirm('مسح الحفظ المحلي للمشروع؟')){localStorage.removeItem('animeCreator56Project');localStorage.removeItem('animeCreator5Project');msg('تم مسح الحفظ المحلي فقط')}});
  }
  function msg(t){let s=q('upStatus');if(s)s.textContent='5.6.1 • '+t}
  function shot(v){snap();state.v55=state.v55||{};state.v55.camAngle=v;state.camKeys.push({t:Number(state.time.toFixed(3)),camera:v,transition:'smooth'});state.engine=state.engine||{};state.engine.cameraY=v==='high'?3.5:v==='ground'?-0.35:.25;draw();msg(v==='low'?'لقطة من أسفل إلى أعلى':v==='ground'?'كاميرا مستوى الأرض':'لقطة علوية')}
  function addObjectFX(fx,label){snap();state.fx=fx;state.fxKeys.push({t:Number(state.time.toFixed(3)),fx});let type=fx==='shipBreak'?'spaceship':'building';state.objects.push({type,x:640,y:330,scale:1.15,motion:'collapse',drop:90,dropSpeed:80,collapseSpin:12});draw();msg('تمت إضافة '+label)}
  function template(kind){snap();state.bg=kind==='space'?'space':kind==='school'?'school':'city';state.objects=[];if(kind==='city'){for(let i=0;i<6;i++)state.objects.push({type:'building',x:80+i*155,y:315-(i%3)*25,scale:1+(i%2)*.2,floors:2+i%4});state.objects.push({type:'car',x:240,y:430,scale:1},{type:'tree',x:820,y:360,scale:1})}else if(kind==='space'){state.objects.push({type:'planet',x:790,y:145,scale:1.6},{type:'spaceship',x:250,y:235,scale:1},{type:'spaceship',x:500,y:185,scale:.7})}else{state.objects.push({type:'school',x:480,y:300,scale:1.7,floors:3});for(let i=0;i<3;i++)state.objects.push({type:'tree',x:100+i*360,y:350,scale:1})}draw();msg('تم إنشاء '+(kind==='space'?'مشهد فضائي':kind==='school'?'مشهد مدرسة':'مشهد مدينة'))}
  // Upgrade the lightweight renderer with visible non-graphic weapons/poses and action effects.
  const baseAnime=window.drawChar;
  window.drawChar=function(ctx,c,index){baseAnime(ctx,c,index);let x=480+c.x,y=360-c.y,sc=(c.scale||1)*(['childBoy','childGirl'].includes(c.type)?.72:1);if(state.camera==='close')sc*=1.25;else if(state.camera==='wide')sc*=.78;ctx.save();ctx.translate(x,y);ctx.rotate(((c.rot||0)+(c.angle||0)*.12)*Math.PI/180);ctx.scale(sc,sc);ctx.lineWidth=7;ctx.lineCap='round';ctx.strokeStyle='#151922';
    function weapon(side,name){if(!name||name==='بدون')return;let s=side==='R'?1:-1;ctx.save();ctx.translate(42*s,25);ctx.rotate((side==='R'?.2:-.2));ctx.beginPath();if(name==='سيف'){ctx.moveTo(0,0);ctx.lineTo(58*s,-12);ctx.stroke();ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(15*s,-4);ctx.lineTo(15*s,10);ctx.stroke()}else if(name==='فأس'||name==='مطرقة'){ctx.lineWidth=9;ctx.moveTo(0,0);ctx.lineTo(42*s,-8);ctx.stroke();ctx.lineWidth=12;ctx.beginPath();ctx.moveTo(38*s,-18);ctx.lineTo(38*s,2);ctx.stroke()}else if(name==='رمح'||name==='سلاح خيالي'){ctx.moveTo(0,0);ctx.lineTo(65*s,-10);ctx.stroke();ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(65*s,-10);ctx.lineTo(52*s,-17);ctx.moveTo(65*s,-10);ctx.lineTo(52*s,-3);ctx.stroke()}else if(name==='قوس'){ctx.lineWidth=4;ctx.beginPath();ctx.arc(18*s,0,20,side==='R'?-.9:2.2,side==='R'?0.9:4.0);ctx.stroke()}ctx.restore()}
    weapon('R',c.weaponR);weapon('L',c.weaponL);if(c.armor&&c.armor!=='بدون'){ctx.strokeStyle='#9ca8b7';ctx.lineWidth=5;ctx.strokeRect(-42,-3,84,95)}
    if(['attack','combo','impact'].includes(c.action)){ctx.strokeStyle='rgba(255,255,255,.65)';ctx.lineWidth=3;for(let i=0;i<3;i++){ctx.beginPath();ctx.arc(55,20,35+i*12,-.5,.55);ctx.stroke()}}
    ctx.restore();
  };
  const baseRender2D=window.render2D;
  window.render2D=function(){baseRender2D();let ctx=q('canvas2d')?.getContext('2d');if(!ctx)return;let t=state.time;
    if(state.fx==='impact'||state.fx==='energy'||state.fx==='buildingBreak'||state.fx==='shipBreak'){let x=680,y=315,r=30+Math.abs(Math.sin(t*10))*35;ctx.save();ctx.globalAlpha=.7;ctx.lineWidth=7;ctx.strokeStyle=state.fx==='energy'?'rgba(100,200,255,.8)':'rgba(255,190,80,.8)';ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.stroke();ctx.restore()}
    if(state.fx==='cameraShake'){ctx.save();ctx.globalAlpha=.28;ctx.fillStyle='#fff';ctx.fillRect(0,0,960,540);ctx.restore()}
  };
  panel();
  setTimeout(()=>{ensure();if(q('upStatus'))q('upStatus').textContent='5.6.1 • تم تفعيل التطوير • محلي • 2D خفيف + 3D اختياري';try{saveLocal()}catch(e){}},0);
})();
