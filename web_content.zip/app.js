// ===== 0. Initialization & Theme Fix =====
const theme = localStorage.getItem("theme");

if (theme === "light") {
    document.body.classList.add("lightMode");
}

// ===== Voice System =====
const tts = window.speechSynthesis;

function speak(text) {
    if (!tts) return;
    tts.cancel(); // पुरानी आवाज बंद करने के लिए

    const msg = new SpeechSynthesisUtterance(text);
    msg.lang = "en-US";
    msg.rate = 1;
    msg.pitch = 1;

    tts.speak(msg);
}

// Voice Map (इसे लूप के बाहर रखा गया है ताकि परफॉर्मेंस खराब न हो)
const voiceMap = {
    "0": "Zero", "1": "One", "2": "Two", "3": "Three", "4": "Four",
    "5": "Five", "6": "Six", "7": "Seven", "8": "Eight", "9": "Nine",
    "+": "Plus", "-": "Minus", "×": "Multiply", "÷": "Divide",
    ".": "Point", "%": "Percent", "C": "Clear", "⌫": "Backspace", "=": "Equal",
    "sqrt": "Square Root", "square": "Square", "cube": "Cube",
    "inverse": "Inverse", "pi": "Pi", "euler": "Euler"
};

// DOM Elements
const clearHistory = document.getElementById("clearHistory");
const historyBtn = document.getElementById("historyBtn");
const historyBox = document.getElementById("historyBox");
const sciBtn = document.getElementById("sciBtn");
const scientificPanel = document.getElementById("scientificPanel");
const screen = document.getElementById("screen");
const buttons = document.querySelectorAll(".btn:not(.sciToggle)");

let historyList = JSON.parse(localStorage.getItem("calcHistory")) || [];
let expression = "";
let SECRET_PIN = localStorage.getItem("vaultPin");

if (!SECRET_PIN) {
    window.location.href = "createPin.html";
}

// ===== 1. SCI Panel Toggle Logic =====
if (sciBtn && scientificPanel) {
    sciBtn.addEventListener("click", () => {
        if (scientificPanel.style.display === "none" || scientificPanel.style.display === "") {
            scientificPanel.style.display = "grid";
        } else {
            scientificPanel.style.display = "none";
        }
    });
}

// ===== Flower Burst Effect =====
function flowerBurst(x, y) {
    const effects = document.getElementById("effects");
    if (!effects) return;

    const ring = document.createElement("div");
    ring.className = "ring";
    ring.style.left = x + "px";
    ring.style.top = y + "px";
    effects.appendChild(ring);

    setTimeout(() => ring.remove(), 600);

    for (let i = 0; i < 25; i++) {
        const flowers = ["🌸", "👻", "🌼", "🌺"];
        const colors = ["#ff0080", "#00e5ff", "#00ff66", "#ffd600", "#ff3d00", "#7c4dff", "#ffffff"];

        const f = document.createElement("span");
        f.className = "flower";

        if (i < 8) {
            f.innerHTML = flowers[Math.floor(Math.random() * flowers.length)];
            f.style.fontSize = "22px";
        } else {
            f.innerHTML = "";
            f.style.width = "8px";
            f.style.height = "8px";
            f.style.borderRadius = "50%";
            f.style.background = colors[Math.floor(Math.random() * colors.length)];
            f.style.boxShadow = "0 0 15px " + f.style.background;
        }

        f.style.left = x + "px";
        f.style.top = y + "px";
        f.style.setProperty("--x", (Math.random() * 160 - 80) + "px");
        f.style.setProperty("--y", (Math.random() * 160 - 80) + "px");

        effects.appendChild(f);
        setTimeout(() => f.remove(), 700);
    }
}

// ===== 2. Calculator Buttons Event Handler =====
buttons.forEach(button => {
    button.addEventListener("click", () => {
        const value = button.dataset.value;
        if (!value) return;

        // Visual & Haptic Feedback
        const rect = button.getBoundingClientRect();
        flowerBurst(rect.left + rect.width / 2, rect.top + rect.height / 2);

        button.animate(
            [
                { transform: "scale(1)" },
                { transform: "scale(0.88) rotate(-5deg)" },
                { transform: "scale(1.15) rotate(5deg)" },
                { transform: "scale(1)" }
            ],
            { duration: 500, easing: "ease-out" }
        );

        if (navigator.vibrate) {
            navigator.vibrate(5);
        }

        // ===== Voice Execution =====
        if (voiceMap[value]) {
            speak(voiceMap[value]);
        }

        // ===== Operations Logic =====
        if (value === "sqrt") {
            expression = Math.sqrt(Number(expression) || 0).toString();
            screen.value = expression;
            return;
        }

        if (value === "square") {
            expression = Math.pow(Number(expression) || 0, 2).toString();
            screen.value = expression;
            return;
        }

        if (value === "cube") {
            expression = Math.pow(Number(expression) || 0, 3).toString();
            screen.value = expression;
            return;
        }

        if (value === "inverse") {
            if (Number(expression) === 0 || !expression) {
                screen.value = "Error";
                expression = "";
            } else {
                expression = (1 / Number(expression)).toString();
                screen.value = expression;
            }
            return;
        }

        if (value === "pi") {
            expression += Math.PI.toFixed(8);
            screen.value = expression;
            return;
        }

        if (value === "euler") {
            expression += Math.E.toFixed(8);
            screen.value = expression;
            return;
        }

        // Clear
        if (value === "C") {
            expression = "";
            screen.value = "0";
            return;
        }

        // Backspace
        if (value === "⌫") {
            expression = expression.slice(0, -1);
            screen.value = expression || "0";
            return;
        }

        // Equal
        if (value === "=") {
            try {
                if (expression === SECRET_PIN) {
                    window.location.href = "vault.html";
                    expression = "";
                    screen.value = "0";
                    return;
                }

                let exp = expression.replace(/×/g, "*").replace(/÷/g, "/");
                let result = eval(exp).toString();
                
                // स्पीच सिस्टम में रिजल्ट बोलने का विकल्प (Optional)
                speak("Equals " + result);

                historyList.unshift(exp + " = " + result);
                if (historyList.length > 30) historyList.pop();

                localStorage.setItem("calcHistory", JSON.stringify(historyList));
                expression = result;
                screen.value = expression;
            } catch {
                screen.value = "Error";
                speak("Error");
                setTimeout(() => {
                    screen.value = expression || "0";
                }, 1000);
            }
            return;
        }

        // Normal Digits/Operators
        expression += value;
        screen.value = expression;

        // Dynamic Font Size Adjustments
        if (expression.length > 24) screen.style.fontSize = "14px";
        else if (expression.length > 16) screen.style.fontSize = "18px";
        else if (expression.length > 10) screen.style.fontSize = "24px";
        else screen.style.fontSize = "30px";
    });
});

// ===== 3. History Operations Logic =====
if (historyBtn && historyBox && clearHistory) {
    historyBtn.addEventListener("click", () => {
        if (historyBox.style.display === "block") {
            historyBox.style.display = "none";
            clearHistory.style.display = "none";
            return;
        }

        historyBox.innerHTML = "";

        if (historyList.length === 0) {
            historyBox.innerHTML = "<p>No History</p>";
        } else {
            historyList.forEach(item => {
                const div = document.createElement("div");
                div.className = "historyItem";
                div.textContent = item;

                div.addEventListener("click", () => {
                    expression = item.split(" = ")[0];
                    screen.value = expression;
                    historyBox.style.display = "none";
                    clearHistory.style.display = "none";
                });

                historyBox.appendChild(div);
            });
        }

        historyBox.style.display = "block";
        clearHistory.style.display = "block";
    });

    clearHistory.addEventListener("click", () => {
        historyList = [];
        localStorage.setItem("calcHistory", JSON.stringify(historyList));
        historyBox.innerHTML = "<p>No History</p>";
    });
}

// ===== 4. User Profile & Settings =====
const userName = document.getElementById("userName");
const saveName = document.getElementById("saveName");

if (userName && saveName) {
    let savedName = localStorage.getItem("userName");

    if (savedName) {
        userName.value = savedName;
        userName.disabled = true;
        saveName.style.display = "none";
    }

    saveName.onclick = function () {
        if (userName.value.trim() === "") {
            alert("Enter Your Name");
            return;
        }
        localStorage.setItem("userName", userName.value.trim());
        userName.disabled = true;
        saveName.style.display = "none";
    };
}

const settingsBtn = document.getElementById("settings");
if (settingsBtn) {
    settingsBtn.onclick = function () {
        window.location.href = "settings.html";
    };
}