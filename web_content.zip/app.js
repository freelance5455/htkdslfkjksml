const chat=document.querySelector('#chat'), input=document.querySelector('#input'), send=document.querySelector('#send'), mic=document.querySelector('#mic');
function add(text,who='kiru'){const d=document.createElement('div');d.className='msg '+who;d.innerHTML=who==='kiru'?'<b>KIRU</b><div></div>':'<div></div>';d.querySelector('div').textContent=text;chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
function localReply(t){t=t.toLowerCase();if(t.includes('hello')||t.includes('hi')||t.includes('hey'))return 'Hello! I am KIRU. How can I help you?';if(t.includes('name'))return 'My name is KIRU AI.';if(t.includes('time'))return 'I can show the current time when connected to a live time service.';return 'I heard you: '+t+'. Connect an AI API in this project to turn KIRU into a full AI assistant.'}
function speak(text){if('speechSynthesis' in window){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(text))}}
function ask(){const t=input.value.trim();if(!t)return;add(t,'user');input.value='';const r=localReply(t);setTimeout(()=>{add(r);speak(r)},350)}
send.onclick=ask;input.addEventListener('keydown',e=>{if(e.key==='Enter')ask()});
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){const rec=new SR();rec.lang='en-US';rec.interimResults=false;rec.onstart=()=>mic.classList.add('listening');rec.onend=()=>mic.classList.remove('listening');rec.onresult=e=>{input.value=e.results[0][0].transcript;ask()};mic.onclick=()=>rec.start()}else{mic.onclick=()=>alert('Voice recognition is not supported in this browser. Try Chrome.')}
