// KisuFire Tracker Logic
let transactions = JSON.parse(localStorage.getItem('kisufire_tx') || '[]');
let currentLang = 'en';

const translations = {
  en: {
    sub: 'Expense & Budget Tracker',
    balance: 'Total Balance',
    income: 'Income',
    expense: 'Expense',
    addTitle: 'Add Transaction',
    btnSave: '+ Save Transaction',
    history: 'Recent Transactions',
    clear: 'Clear All',
    empty: 'No transactions yet. Add your first item above!',
  },
  hi: {
    sub: 'खर्च और बजट ट्रैकर',
    balance: 'कुल शेष (बैलेंस)',
    income: 'आमदनी (इनकम)',
    expense: 'खर्च (एक्सपेंस)',
    addTitle: 'नया लेनदेन जोड़ें',
    btnSave: '+ सुरक्षित करें',
    history: 'हाल के लेनदेन',
    clear: 'सब हटाएं',
    empty: 'अभी कोई लेनदेन नहीं है। ऊपर नया खर्च जोड़ें!',
  }
};

function saveAndRender() {
  localStorage.setItem('kisufire_tx', JSON.stringify(transactions));
  render();
}

function render() {
  const t = translations[currentLang];
  document.getElementById('subheading').textContent = t.sub;
  document.getElementById('lblTotalBalance').textContent = t.balance;
  document.getElementById('lblIncome').textContent = t.income;
  document.getElementById('lblExpense').textContent = t.expense;
  document.getElementById('lblAddTitle').innerHTML = '<span class="w-2 h-2 rounded-full bg-red-500"></span> ' + t.addTitle;
  document.getElementById('addBtn').textContent = t.btnSave;
  document.getElementById('lblHistory').textContent = t.history;
  document.getElementById('clearAllBtn').textContent = t.clear;

  let income = 0;
  let expense = 0;

  transactions.forEach(tx => {
    if (tx.type === 'income') income += tx.amount;
    else expense += tx.amount;
  });

  const total = income - expense;
  document.getElementById('totalBalance').textContent = '₹' + total.toFixed(2);
  document.getElementById('incomeAmount').textContent = '+₹' + income.toFixed(2);
  document.getElementById('expenseAmount').textContent = '-₹' + expense.toFixed(2);

  const listEl = document.getElementById('txList');
  if (transactions.length === 0) {
    listEl.innerHTML = '<div class="text-center py-6 text-xs text-gray-500">' + t.empty + '</div>';
    return;
  }

  listEl.innerHTML = transactions.map((tx, idx) => {
    const isInc = tx.type === 'income';
    return `
      <div class="flex items-center justify-between p-3 rounded-lg bg-black/40 border border-gray-800/80 hover:border-gray-700 transition">
        <div>
          <p class="text-sm font-medium text-white">${tx.desc}</p>
          <span class="text-[10px] text-gray-500">${new Date(tx.date).toLocaleDateString()}</span>
        </div>
        <div class="flex items-center gap-3">
          <span class="text-sm font-semibold ${isInc ? 'text-green-400' : 'text-red-400'}">
            ${isInc ? '+' : '-'}₹${tx.amount.toFixed(2)}
          </span>
          <button onclick="removeTx(${idx})" class="text-gray-600 hover:text-red-400 text-xs px-1">&times;</button>
        </div>
      </div>
    `;
  }).join('');
}

window.removeTx = function(idx) {
  transactions.splice(idx, 1);
  saveAndRender();
};

document.getElementById('addBtn').addEventListener('click', () => {
  const desc = document.getElementById('descInput').value.trim();
  const amount = parseFloat(document.getElementById('amountInput').value);
  const type = document.getElementById('typeSelect').value;

  if (!desc || isNaN(amount) || amount <= 0) {
    alert('Please enter a valid title and positive amount.');
    return;
  }

  transactions.unshift({
    desc,
    amount,
    type,
    date: new Date().toISOString()
  });

  document.getElementById('descInput').value = '';
  document.getElementById('amountInput').value = '';
  saveAndRender();
});

document.getElementById('langToggle').addEventListener('click', () => {
  currentLang = currentLang === 'en' ? 'hi' : 'en';
  render();
});

document.getElementById('clearAllBtn').addEventListener('click', () => {
  if (confirm('Clear all transaction history?')) {
    transactions = [];
    saveAndRender();
  }
});

if (transactions.length === 0) {
  transactions = [
    { desc: 'Freelance Design', amount: 15000, type: 'income', date: new Date().toISOString() },
    { desc: 'Cloud Server Hosting', amount: 1200, type: 'expense', date: new Date().toISOString() },
    { desc: 'Office Coffee & Snacks', amount: 350, type: 'expense', date: new Date().toISOString() }
  ];
}

render();