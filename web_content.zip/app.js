const KEY="ZgamesStaff_v1";
const DEFAULT_PASS="6342";
let db=JSON.parse(localStorage.getItem(KEY)||"null");
let adminMode=false, menuOpen=false;

function save(){localStorage.setItem(KEY,JSON.stringify(db))}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function toast(t){let x=document.createElement("div");x.className="toast";x.textContent=t;document.body.appendChild(x);setTimeout(()=>x.remove(),1800)}
function now(){return new Date().toLocaleString()}
function status(id){
  for(let i=db.events.length-1;i>=0;i--) if(db.events[i].staffId===id) return db.events[i].type==="CHECK-IN"?"IN":"OUT";
  return "OUT";
}
function staffById(id){return db.staff.find(x=>x.id===id)}
function layout(content){document.getElementById("app").innerHTML=`<div class="wrap">${content}</div>`}
function menu(){
 return `<div class="menuBox">
 <button onclick="adminLogin();closeMenu()">🔐 Admin Login</button>
 <button onclick="about();closeMenu()">ℹ️ About</button></div>`
}
function closeMenu(){menuOpen=false;render()}
function render(){
 if(!db){createAdmin();return}
 adminMode?admin():staffScreen()
}
function createAdmin(){
 layout(`<div class="card"><div class="brand">ZgamesStaff</div><div class="sub">Admin Login</div>
 <input id="aname" class="field" placeholder="Admin name">
 <input id="apass" class="field" type="password" inputmode="numeric" placeholder="Admin password">
 <button class="btn" onclick="firstLogin()">LOGIN</button></div>`)
}
function firstLogin(){
 const name=aname.value.trim();
 if(!name)return toast("Enter admin name");
 if(apass.value!=="6342")return toast("Incorrect admin password");
 db={storeName:"",adminName:name,adminPass:"6342",staff:[],events:[]};
 save(); adminMode=true; render()
}
function staffScreen(){
 layout(`<div class="card">
 <div class="top"><div><div class="brand">${esc(db.storeName)}</div><div class="sub">Staff Check-In / Check-Out</div></div>
 <button class="btn menu" onclick="menuOpen=!menuOpen;render()">⋮</button></div>
 ${menuOpen?menu():""}
 <input id="sid" class="field" inputmode="numeric" maxlength="4" placeholder="Enter 4-digit Staff ID">
 <button class="btn" onclick="toggleStaff()">CHECK-IN / CHECK-OUT</button>
 <div class="muted small">Use your registered 4-digit staff ID.</div>
 </div>`)
}
function toggleStaff(){
 let id=sid.value.trim(), s=staffById(id);
 if(!s)return toast("Invalid Staff ID");
 let type=status(id)==="OUT"?"CHECK-IN":"CHECK-OUT";
 db.events.push({staffId:id,name:s.name,type,time:now()});save();toast(`${s.name} — ${type}`);render()
}
function adminLogin(){
  // Reload saved configuration every time Admin Login is opened.
  try {
    const saved=localStorage.getItem(KEY);
    if(saved) db=JSON.parse(saved);
  } catch(e) {}

  layout(`<div class="card"><h1>Admin Login</h1>
 <input id="loginAdminName" class="field" type="text" value="${esc(db.adminName||"")}" placeholder="Admin name" autocomplete="username">
 <input id="loginAdminPass" class="field" type="password" placeholder="Admin password" autocomplete="current-password">
 <button class="btn" onclick="loginAdmin()">LOGIN</button><button class="btn secondary" onclick="render()">BACK</button></div>`)
}
function loginAdmin(){
  try {
    const saved=localStorage.getItem(KEY);
    if(saved) db=JSON.parse(saved);
  } catch(e) {
    return toast("Saved admin data read nahi ho raha");
  }

  const nameEl=document.getElementById("loginAdminName");
  const passEl=document.getElementById("loginAdminPass");
  const name=nameEl ? nameEl.value.trim() : "";
  const pass=passEl ? passEl.value : "";

  if(!name || !pass) return toast("Admin name aur password daalo");
  if(name===db.adminName && pass===db.adminPass){
    adminMode=true;
    save();
    render();
  } else {
    toast("Invalid admin name or password");
  }
}
function admin(){
 layout(`<div class="card"><div class="top"><div><h1>Admin Panel</h1><div class="muted">${esc(db.storeName)}</div></div></div>
 <h2>Staff</h2>
 ${db.staff.length?db.staff.map(s=>`<div class="staff"><div><b>${esc(s.name)}</b><div class="small muted">${s.id}</div></div><span class="pill ${status(s.id)==="IN"?"in":"out"}">${status(s.id)==="IN"?"CHECKED IN":"CHECKED OUT"}</span></div>`).join(""):`<div class="muted">No staff added yet.</div>`}
 <button class="btn" onclick="addStaff()">➕ ADD STAFF</button>
 <button class="btn secondary" onclick="history()">ATTENDANCE HISTORY</button>
 <button class="btn secondary" onclick="exportCSV()">EXPORT CSV</button>
 <button class="btn secondary" onclick="backup()">BACKUP DATA</button>
 <button class="btn secondary" onclick="restore()">RESTORE DATA</button>
 <button class="btn secondary" onclick="resetPassword()">RESET ADMIN PASSWORD</button>
 <button class="btn secondary" onclick="about()">ABOUT</button>
 <button class="btn danger" onclick="adminMode=false;menuOpen=false;save();render()">LOGOUT ADMIN</button>
 </div>`)
}
function addStaff(){
 let n=prompt("Staff name:"), id=prompt("Unique 4-digit ID:");
 if(!n||!id)return;
 if(!/^\d{4}$/.test(id)||staffById(id))return toast("Enter a unique 4-digit ID");
 db.staff.push({name:n.trim(),id});save();render()
}
function history(){
 if(!db.events.length)return alert("No events yet.");
 alert(db.events.map(e=>`${e.time}  |  ${e.name} (${e.staffId})  |  ${e.type}`).join("\n"))
}
function about(){alert("This app is created by Abdul Raheem\nOman")}
function resetPassword(){
 let old=prompt("Current admin password:"), np=prompt("New admin password:"), rp=prompt("Retype new password:");
 if(old!==db.adminPass)return toast("Current password is incorrect");
 if(!np||np!==rp)return toast("New passwords do not match");
 db.adminPass=np;save();toast("Admin password updated")
}
function backup(){
 let data=JSON.stringify(db,null,2), blob=new Blob([data],{type:"application/json"}), a=document.createElement("a");
 a.href=URL.createObjectURL(blob);a.download=`ZgamesStaff_Backup_${new Date().toISOString().slice(0,19).replace(/[:T]/g,"_")}.zgs`;a.click();URL.revokeObjectURL(a.href)
}
function restore(){
 let input=document.createElement("input");input.type="file";input.accept=".zgs,.json,application/json";
 input.onchange=()=>{let f=input.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let o=JSON.parse(r.result);if(!o.staff||!o.events||!o.adminPass)throw 0;db=o;save();toast("Restore complete");render()}catch(e){toast("Invalid backup file")}};r.readAsText(f)};input.click()
}
function exportCSV(){
 let rows=[["Staff ID","Name","Event","Date Time"],...db.events.map(e=>[e.staffId,e.name,e.type,e.time])];
 let csv=rows.map(r=>r.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(",")).join("\n");
 let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download="ZgamesStaff_Attendance.csv";a.click()
}
render();