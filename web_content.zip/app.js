const $=id=>document.getElementById(id);
const statusBox=$("status");

function buildQuestions(){
  const n=+$("questionCount").value;
  const box=$("questions");
  box.innerHTML="";
  for(let i=1;i<=n;i++){
    box.insertAdjacentHTML("beforeend",`
      <div class="qrow" data-q="${i}">
        <div class="qnum">${i}</div>
        <textarea id="q${i}" placeholder="اكتب نص السؤال رقم ${i}"></textarea>
        <input id="m${i}" type="number" min="0" step="0.5" placeholder="الدرجة">
        <button class="del" title="مسح السؤال" onclick="clearQuestion(${i})">×</button>
      </div>`);
  }
}
buildQuestions();

function val(id){return $(id)?.value.trim()||""}
function setStatus(t){statusBox.textContent=t;setTimeout(()=>{if(statusBox.textContent===t)statusBox.textContent=""},3500)}
function clearQuestion(i){$("q"+i).value="";$("m"+i).value=""}
function arabicDate(v){if(!v)return"";const p=v.split("-");return `${p[2]}/${p[1]}/${p[0]}`}

function collect(){
  const n=+$("questionCount").value, qs=[];
  for(let i=1;i<=n;i++)qs.push({text:val("q"+i),mark:val("m"+i)});
  return {
    school:val("school"),subject:val("subject"),grade:val("grade"),className:val("className"),
    date:val("date"),time:val("time"),teacher:val("teacher"),year:val("year"),
    totalMark:val("totalMark"),fontSize:$("fontSize").value,footer:val("footerText"),questions:qs
  };
}
function fillData(d){
  ["school","subject","grade","className","date","time","teacher","year","totalMark"].forEach(k=>{if($(k))$(k).value=d[k]||""});
  $("fontSize").value=d.fontSize||"24";$("footerText").value=d.footer||"مع تمنياتنا لكم بالنجاح";
  $("questionCount").value=Math.min(50,Math.max(1,(d.questions||[]).length||10));buildQuestions();
  (d.questions||[]).forEach((q,i)=>{if($("q"+(i+1))){$("q"+(i+1)).value=q.text||"";$("m"+(i+1)).value=q.mark||""}});
}
function saveData(){localStorage.setItem("examMakerData",JSON.stringify(collect()));setStatus("تم حفظ الورقة على الجهاز")}
function loadData(){const d=localStorage.getItem("examMakerData");if(!d){setStatus("لا توجد بيانات محفوظة");return}fillData(JSON.parse(d));setStatus("تم استرجاع البيانات")}
function newExam(){if(confirm("بدء ورقة جديدة ومسح البيانات الحالية؟")){localStorage.removeItem("examMakerData");document.querySelectorAll("input,textarea").forEach(e=>e.value="");$("footerText").value="مع تمنياتنا لكم بالنجاح";$("questionCount").value=10;buildQuestions();setStatus("تم إنشاء ورقة جديدة")}}
function fillDemo(){for(let i=1;i<=+$("questionCount").value;i++){ $("q"+i).value=`اكتب نص السؤال رقم ${i} هنا`; $("m"+i).value=10 } setStatus("تم إدخال مثال تجريبي")}

function paperHTML(d){
  let h=`<div class="paper-title">${d.school||"اسم المدرسة"}</div>
  <div class="paper-info">المادة: ${d.subject||"................"}<br>
  الصف: ${d.grade||"................"} ${d.className?`&nbsp;&nbsp;&nbsp; الشعبة: ${d.className}`:""}<br>
  ${d.teacher?`المدرس: ${d.teacher}<br>`:""}
  التاريخ: ${arabicDate(d.date)||"................"} &nbsp;&nbsp; الوقت: ${d.time||"................"} ${d.year?`&nbsp;&nbsp; العام الدراسي: ${d.year}`:""}</div>
  <div class="solid"></div>`;
  d.questions.forEach((q,i)=>{h+=`<div class="pq" style="font-size:${d.fontSize}px"><b>س${i+1}/</b> ${q.text||"........................................................"}
  <span class="mark">(الدرجة: ${q.mark||"...."})</span></div>`;if(i<d.questions.length-1)h+=`<div class="dash"></div>`});
  h+=`<div class="paper-footer">${d.footer||"مع تمنياتنا لكم بالنجاح"}</div>`;
  return h;
}
function preview(){$("paper").innerHTML=paperHTML(collect());$("previewModal").classList.remove("hidden")}
function closePreview(){$("previewModal").classList.add("hidden")}

async function exportWord(){
  if(!window.docx){setStatus("تعذر تحميل مكتبة Word. افتح التطبيق مع اتصال بالإنترنت.");return}
  const d=collect();
  const {Document,Packer,Paragraph,TextRun,AlignmentType,BorderStyle,Table,TableCell,TableRow,WidthType}=docx;
  const children=[];
  children.push(new Paragraph({alignment:AlignmentType.CENTER,spacing:{after:100},children:[new TextRun({text:d.school||"اسم المدرسة",bold:true,size:30})]}));
  const info=[["المادة",d.subject],["الصف",d.grade+(d.className?"   |   الشعبة: "+d.className:"")],
    ...(d.teacher?[["المدرس",d.teacher]]:[]),["التاريخ",arabicDate(d.date)],["الوقت",d.time],...(d.year?[["العام الدراسي",d.year]]:[])];
  children.push(new Table({width:{size:100,type:WidthType.PERCENTAGE},rows:info.map(x=>new TableRow({children:[new TableCell({children:[new Paragraph({alignment:AlignmentType.RIGHT,children:[new TextRun({text:`${x[0]}: ${x[1]||"................"}`,bold:true,size:22})]})],borders:{top:{style:BorderStyle.NONE},bottom:{style:BorderStyle.NONE},left:{style:BorderStyle.NONE},right:{style:BorderStyle.NONE}}})]})),borders:{top:{style:BorderStyle.NONE},bottom:{style:BorderStyle.NONE},left:{style:BorderStyle.NONE},right:{style:BorderStyle.NONE},insideHorizontal:{style:BorderStyle.NONE},insideVertical:{style:BorderStyle.NONE}}}));
  children.push(new Paragraph({border:{bottom:{style:BorderStyle.SINGLE,size:12,color:"000000",space:8}},spacing:{after:180}}));
  d.questions.forEach((q,i)=>{
    children.push(new Paragraph({alignment:AlignmentType.RIGHT,spacing:{before:70,after:110},children:[
      new TextRun({text:`س${i+1}/ `,bold:true,size:+d.fontSize}),new TextRun({text:q.text||"........................................................",size:+d.fontSize}),
      new TextRun({text:`    (الدرجة: ${q.mark||"...."})`,bold:true,size:18})
    ]}));
    if(i<d.questions.length-1)children.push(new Paragraph({border:{bottom:{style:BorderStyle.DASHED,size:6,color:"666666",space:6}},spacing:{after:150}}));
  });
  children.push(new Paragraph({alignment:AlignmentType.CENTER,spacing:{before:300},children:[new TextRun({text:d.footer||"مع تمنياتنا لكم بالنجاح",bold:true,size:24})]}));
  const doc=new Document({sections:[{properties:{page:{margin:{top:650,bottom:650,left:700,right:700}}},children}]});
  setStatus("جارٍ إنشاء ملف Word...");
  const blob=await Packer.toBlob(doc);
  const safe=(d.school||"ورقة_اسئلة").replace(/[\\/:*?"<>|]/g,"_");
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`${safe}_ورقة_اسئلة.docx`;a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),2000);
  localStorage.setItem("examMakerData",JSON.stringify(d));
  setStatus("تم إنشاء ملف Word وحفظه في التنزيلات");
}

$("date").valueAsDate=new Date();
