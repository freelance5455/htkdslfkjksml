const KEY="attendance_web_v1";let data=JSON.parse(localStorage.getItem(KEY)||"null")||{records:{},holidays:[],settings:{standard:450,break:60}};let view=new Date(),calview=new Date();
const pad=n=>String(n).padStart(2,"0"),key=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`,wd=["日","月","火","水","木","金","土"];
function save(){localStorage.setItem(KEY,JSON.stringify(data))} function rec(d){return data.records[key(d)]||(data.records[key(d)]={})}
function weekend(d){return d.getDay()==0||d.getDay()==6} function holiday(d){return weekend(d)||data.holidays.includes(key(d))}
function mins(s){if(!s)return null;let a=s.split(":").map(Number);return a[0]*60+a[1]} function hm(n){if(n==null)return"--:--";let sg=n<0?"-":"";n=Math.abs(n);return sg+Math.floor(n/60)+":"+pad(n%60)} function signed(n){return n>0?"+"+hm(n):hm(n)}
function calc(d){let r=rec(d);if(!r.in||!r.out)return{w:null,o:null};let w=mins(r.out)-mins(r.in)-data.settings.break;return{w:Math.max(0,w),o:Math.max(0,w)-(holiday(d)?0:data.settings.standard)}}
function toast(x){let t=document.querySelector("#toast");t.textContent=x;t.style.display="block";setTimeout(()=>t.style.display="none",1500)}
function home(){let d=new Date(),r=rec(d),c=calc(d);document.querySelector("#today").textContent=`${d.getFullYear()}年${d.getMonth()+1}月${d.getDate()}日（${wd[d.getDay()]}）`;inTime.textContent=r.in||"--:--";outTime.textContent=r.out||"--:--";workTime.textContent=hm(c.w);overtime.textContent=c.o==null?"--:--":signed(c.o);clockIn.disabled=!!r.in;clockOut.disabled=!r.in||!!r.out}
function month(){let y=view.getFullYear(),m=view.getMonth(),body="",tw=0,to=0;monthTitle.textContent=`${y}年${m+1}月`;for(let n=1;n<=new Date(y,m+1,0).getDate();n++){let d=new Date(y,m,n),r=rec(d),c=calc(d),h=holiday(d);if(c.w!=null){tw+=c.w;to+=c.o}body+=`<tr class="${h?"holiday-row":""}"><td>${n}</td><td>${wd[d.getDay()]}</td><td>${h?"休日":"勤務"}</td><td>${r.in||"--:--"}</td><td>${r.out||"--:--"}</td><td>${hm(c.w)}</td><td>${c.o==null?"--:--":signed(c.o)}</td><td><button onclick="edit('${key(d)}')">編集</button></td></tr>`}monthBody.innerHTML=body;totalWork.textContent=hm(tw);totalOvertime.textContent=signed(to)}
let editingKey=null;
function edit(k){
  editingKey=k;
  let r=data.records[k]||{};
  editTitle.textContent=`時間を修正（${k}）`;
  editIn.value=r.in||"";
  editOut.value=r.out||"";
  editModal.classList.remove("hidden");
}
function closeEdit(){editingKey=null;editModal.classList.add("hidden")}
editCancel.onclick=closeEdit;
editSave.onclick=()=>{
  if(!editingKey)return;
  let i=editIn.value,o=editOut.value;
  if(i && !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(i))return alert("出勤時間を正しく入力してください");
  if(o && !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(o))return alert("退勤時間を正しく入力してください");
  if(i && o && mins(o)<mins(i))return alert("退勤時間は出勤時間より後にしてください");
  if(!i&&!o) delete data.records[editingKey];
  else data.records[editingKey]={in:i||"",out:o||""};
  save();closeEdit();month();home();toast("時間を修正しました");
};
editClear.onclick=()=>{
  if(!editingKey)return;
  if(confirm(`${editingKey} の打刻を削除しますか？`)){
    delete data.records[editingKey];save();closeEdit();month();home();toast("打刻を削除しました");
  }
};
function calendar(){let y=calview.getFullYear(),m=calview.getMonth();holidayTitle.textContent=`${y}年${m+1}月`;calendarGrid.innerHTML=wd.map(x=>`<div class="dow">${x}</div>`).join("");let first=new Date(y,m,1).getDay();for(let i=0;i<first;i++)calendarGrid.innerHTML+=`<div></div>`;for(let n=1;n<=new Date(y,m+1,0).getDate();n++){let d=new Date(y,m,n),k=key(d),h=data.holidays.includes(k);calendarGrid.innerHTML+=`<div class="day ${weekend(d)?"weekend":""} ${h?"holiday":""} ${k==key(new Date())?"today":""}" onclick="toggleHoliday('${k}',${weekend(d)})"><b>${n}</b><small>${weekend(d)?"土日":h?"任意休日":"勤務日"}</small></div>`}}
function toggleHoliday(k,w){if(w)return toast("土日は自動休日です");let i=data.holidays.indexOf(k);if(i>=0){data.holidays.splice(i,1)}else data.holidays.push(k);save();calendar();month()}
function tab(id){document.querySelectorAll(".tab").forEach(x=>x.classList.add("hidden"));document.querySelector("#"+id).classList.remove("hidden");document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.tab==id));if(id=="home")home();if(id=="month")month();if(id=="calendar")calendar()}
document.querySelectorAll(".nav").forEach(x=>x.onclick=()=>tab(x.dataset.tab));
clockIn.onclick=()=>{let d=new Date(),r=rec(d);if(!r.in){r.in=pad(d.getHours())+":"+pad(d.getMinutes());save();home();toast("出勤を記録しました")}};clockOut.onclick=()=>{let d=new Date(),r=rec(d);if(r.in&&!r.out){r.out=pad(d.getHours())+":"+pad(d.getMinutes());save();home();toast("退勤を記録しました")}};
prevMonth.onclick=()=>{view.setMonth(view.getMonth()-1);month()};nextMonth.onclick=()=>{view.setMonth(view.getMonth()+1);month()};prevHolidayMonth.onclick=()=>{calview.setMonth(calview.getMonth()-1);calendar()};nextHolidayMonth.onclick=()=>{calview.setMonth(calview.getMonth()+1);calendar()};
standardMinutes.value=data.settings.standard;breakMinutes.value=data.settings.break;saveSettings.onclick=()=>{data.settings.standard=+standardMinutes.value;data.settings.break=+breakMinutes.value;save();home();month();toast("保存しました")};
exportCsv.onclick=()=>{let y=view.getFullYear(),m=view.getMonth(),a=[["日付","曜日","区分","出勤","退勤","実働","残業"]];for(let n=1;n<=new Date(y,m+1,0).getDate();n++){let d=new Date(y,m,n),r=rec(d),c=calc(d);a.push([key(d),wd[d.getDay()],holiday(d)?"休日":"勤務",r.in||"",r.out||"",c.w==null?"":hm(c.w),c.o==null?"":signed(c.o)])}let csv="\ufeff"+a.map(r=>r.map(x=>`"${String(x).replaceAll('"','""')}"`).join(",")).join("\n"),ael=document.createElement("a");ael.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));ael.download=`勤怠_${y}-${pad(m+1)}.csv`;ael.click()};
backup.onclick=()=>{let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));a.download="勤怠バックアップ.json";a.click()};restore.onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader;r.onload=()=>{try{data=JSON.parse(r.result);save();location.reload()}catch{alert("不正なバックアップです")}};r.readAsText(f)};clearData.onclick=()=>{if(confirm("全データを削除しますか？")){localStorage.removeItem(KEY);location.reload()}};home();
