// --- SÉCURITÉ ANTI-PLANTAGE ---
const storage = (() => {
    try { localStorage.setItem('t', 't'); localStorage.removeItem('t'); return localStorage; } 
    catch (e) { return { getItem: () => null, setItem: () => {}, removeItem: () => {} }; }
})();

// --- SPLASH SCREEN ---
setTimeout(() => {
    const splash = document.getElementById('splash-screen');
    if(splash) { splash.style.opacity = '0'; setTimeout(() => splash.remove(), 500); }
}, 2000);

// --- GESTION DES THÈMES ---
const waifuBgs = [
    'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1080',
    'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?q=80&w=1080',
    'https://images.unsplash.com/photo-1560972550-aba3456b5564?q=80&w=1080'
];

function ouvrirTheme() { document.getElementById('modalTheme').classList.remove('hidden'); }
function fermerTheme() { document.getElementById('modalTheme').classList.add('hidden'); }

function changerTheme(theme) {
    // Enlever toutes les classes de thème existantes
    document.body.className = ''; 
    document.getElementById('bgImage').classList.remove('active');
    document.getElementById('bgImage').style.backgroundImage = 'none';

    if (theme === 'dark') {
        document.body.classList.add('theme-dark');
    } else if (theme === 'light') {
        document.body.classList.add('theme-light');
    } else if (theme === 'transparent') {
        document.body.classList.add('theme-dark', 'theme-transparent');
    } else if (theme.startsWith('waifu')) {
        document.body.classList.add('theme-dark'); // Base sombre
        const index = parseInt(theme.replace('waifu', '')) - 1;
        const bgDiv = document.getElementById('bgImage');
        bgDiv.style.backgroundImage = `url('${waifuBgs[index]}')`;
        bgDiv.classList.add('active');
    }
    
    // Sauvegarder le thème
    storage.setItem('otakus_theme', theme);
    fermerTheme();
}

document.getElementById('themeBtn').addEventListener('click', ouvrirTheme);

// --- CHARGEMENT DES MANGAS TENDANCES (Kitsu API) ---
async function chargerMangasTendances() {
    const container = document.getElementById('trendingMangas');
    try {
        const response = await fetch('https://kitsu.io/api/edge/manga?page[limit]=10&sort=-averageRating');
        const data = await response.json();
        container.innerHTML = ''; 
        data.data.forEach(manga => {
            const titre = manga.attributes.canonicalTitle;
            const imageUrl = manga.attributes.posterImage ? manga.attributes.posterImage.medium : 'https://via.placeholder.com/110x160/333/fff?text=Manga';
            container.innerHTML += `
                <div class="media-card">
                    <img src="${imageUrl}" class="card-img" style="object-fit:cover;">
                    <p>${titre}</p>
                </div>
            `;
        });
    } catch (error) {
        container.innerHTML = '<p style="color: var(--accent); font-size: 0.9rem; padding-left: 5px;">⚠️ Vérifie ta connexion pour voir les tendances.</p>';
    }
}

// --- WALLPAPERS SECTION ---
const wallpapers = [
    { title: "Naruto Fanart", url: "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=1080" },
    { title: "Anime Girl Cool", url: "https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=1080" },
    { title: "Samourai", url: "https://images.unsplash.com/photo-1618336753974-aae8e04506aa?q=80&w=1080" },
    { title: "Manga Aesthetic", url: "https://images.unsplash.com/photo-1560972550-aba3456b5564?q=80&w=1080" },
    { title: "Neon City", url: "https://images.unsplash.com/photo-1528360983277-13d401cdc186?q=80&w=1080" },
    { title: "Cherry Blossom", url: "https://images.unsplash.com/photo-1553949345-eb786bb3f7ba?q=80&w=1080" }
];

function afficherWallpapers() {
    const grid = document.getElementById('wallpaperGrid');
    grid.innerHTML = '';
    wallpapers.forEach((wp, index) => {
        grid.innerHTML += `
            <div class="collection-item glass">
                <img src="${wp.url}" style="height:150px;">
                <h4>${wp.title}</h4>
                <button onclick="telechargerImage('${wp.url}', 'wallpaper_${index}')" style="padding:8px; font-size:0.8rem; margin-top:8px; background:var(--accent); border-radius:8px; width:100%;">⬇️ Télécharger</button>
            </div>
        `;
    });
}

function telechargerImage(url, nom) {
    // Créer un lien virtuel pour forcer le téléchargement
    const a = document.createElement('a');
    a.href = url;
    a.download = nom + '.jpg';
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

// --- NAVIGATION ---
function changerOnglet(idOnglet, bouton) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById('tab-' + idOnglet).classList.add('active');
    bouton.classList.add('active');
    const btnFlottant = document.querySelector('.btn-flottant');
    if (btnFlottant) btnFlottant.style.display = (idOnglet === 'collection') ? 'flex' : 'none';
}

// --- COLLECTION ---
let maCollection = JSON.parse(storage.getItem('otakus_v6')) || [];
let filtreActuel = 'tout';
let rechercheActuelle = "";

function afficherCollection() {
    const grid = document.getElementById('maCollection');
    const homeRow = document.getElementById('homeCollection');
    grid.innerHTML = ''; homeRow.innerHTML = '';
    
    let items = maCollection;
    if (filtreActuel !== 'tout') items = items.filter(item => item.type === filtreActuel);
    if (rechercheActuelle !== "") items = items.filter(item => item.titre.toLowerCase().includes(rechercheActuelle.toLowerCase()));

    const tri = document.getElementById('sortSelect').value;
    if (tri === 'recent') items.sort((a, b) => b.id - a.id);
    if (tri === 'ancien') items.sort((a, b) => a.id - b.id);
    if (tri === 'alpha') items.sort((a, b) => a.titre.localeCompare(b.titre));

    if (items.length === 0) {
        grid.innerHTML = '<p style="grid-column: 1/-1; text-align:center; color:var(--text-dim);">Aucun média trouvé.</p>';
    } else {
        items.forEach(item => {
            let visuel = '';
            if (item.type === 'image' && (item.data || item.url)) {
                visuel = `<img src="${item.data || item.url}" onerror="this.src='https://via.placeholder.com/110x120/333/fff?text=Erreur'">`;
            } else {
                visuel = `<div class="card-img ${item.type === 'video' ? 'bg-1' : 'bg-2'}" style="height:100px;">${item.type === 'video' ? '🎥' : '📁'}</div>`;
            }
            grid.innerHTML += `
                <div class="collection-item glass" onclick="ouvrirDetails(${item.id})">
                    ${visuel}
                    <h4>${item.titre}</h4>
                </div>
            `;
        });
    }

    let recents = [...maCollection].sort((a,b) => b.id - a.id).slice(0, 5);
    if (recents.length === 0) {
        homeRow.innerHTML = '<p style="color:var(--text-dim); font-size:0.9rem; padding-left:5px;">Ta collection est vide.</p>';
    } else {
        recents.forEach(item => {
            let visuel = item.type === 'image' && (item.data || item.url) 
                ? `<img src="${item.data || item.url}" class="card-img" style="object-fit:cover;" onerror="this.src='https://via.placeholder.com/110x160/333/fff?text=Erreur'">` 
                : `<div class="card-img bg-3">Média</div>`;
            homeRow.innerHTML += `
                <div class="media-card" onclick="ouvrirDetails(${item.id})">
                    ${visuel}
                    <p>${item.titre}</p>
                </div>
            `;
        });
    }
}

// --- RECHERCHE ET TRI ---
function rechercherMedia() { rechercheActuelle = document.getElementById('searchInput').value; afficherCollection(); }
function trierMedia() { afficherCollection(); }
function filtrer(type, bouton) {
    document.querySelectorAll('.filtre-btn').forEach(btn => btn.classList.remove('active'));
    bouton.classList.add('active');
    filtreActuel = type;
    afficherCollection();
}

// --- FORMULAIRE D'AJOUT ---
function toggleChamps() {
    const type = document.getElementById('type').value;
    document.getElementById('champsVideo').style.display = (type === 'video') ? 'block' : 'none';
    document.getElementById('champsImage').style.display = (type === 'image') ? 'flex' : 'none';
}

document.getElementById('mediaForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const titre = document.getElementById('titre').value;
    const type = document.getElementById('type').value;
    
    let nouvelItem = { id: Date.now(), titre, type, url: null, data: null };

    if (type === 'video') {
        nouvelItem.url = document.getElementById('mediaUrl').value;
        sauvegarderItem(nouvelItem);
    } else if (type === 'image') {
        const urlInput = document.getElementById('imageUrl').value;
        const file = document.getElementById('imageFile').files[0];

        if (file) {
            const reader = new FileReader();
            reader.onload = (evt) => { nouvelItem.data = evt.target.result; sauvegarderItem(nouvelItem); };
            reader.readAsDataURL(file);
        } else if (urlInput) {
            nouvelItem.url = urlInput;
            sauvegarderItem(nouvelItem);
        } else {
            alert("Choisis un fichier ou colle un lien d'image.");
        }
    }
});

function ajouterLien() {
    const nom = document.getElementById('lienNom').value;
    const url = document.getElementById('lienUrl').value;
    if(nom && url) {
        sauvegarderItem({ id: Date.now(), titre: nom, type: 'video', url: url, data: null });
        document.getElementById('lienNom').value = '';
        document.getElementById('lienUrl').value = '';
        alert("Lien ajouté !");
    } else { alert("Remplis le nom et le lien."); }
}

function sauvegarderItem(item) {
    maCollection.push(item);
    storage.setItem('otakus_v6', JSON.stringify(maCollection));
    afficherCollection();
    fermerFormulaire();
}

// --- MODAL FORMULAIRE ---
function ouvrirFormulaire() { document.getElementById('modalForm').classList.remove('hidden'); toggleChamps(); }
function fermerFormulaire() { document.getElementById('modalForm').classList.add('hidden'); document.getElementById('mediaForm').reset(); }

// --- MODAL DETAILS ---
function ouvrirDetails(id) {
    const item = maCollection.find(i => i.id === id);
    if(!item) return;

    let contenu = `<h2>${item.titre}</h2>`;
    if (item.type === 'image' && (item.data || item.url)) {
        contenu += `<img src="${item.data || item.url}" onerror="this.src='https://via.placeholder.com/300x400/333/fff?text=Erreur+de+chargement'">`;
    } else if (item.type === 'video' && item.url) {
        contenu += `<p>Lien vidéo prêt à être regardé.</p>`;
    }

    contenu += `
        <div class="detail-btns">
            ${item.url ? `<a href="${item.url}" target="_blank" style="flex:1;"><button style="width:100%;">▶ Ouvrir le lien</button></a>` : ''}
            <button class="btn-del-detail" onclick="supprimerItem(${item.id})">🗑️ Supprimer</button>
        </div>
    `;

    document.getElementById('detailsContent').innerHTML = contenu;
    document.getElementById('modalDetails').classList.remove('hidden');
}
function fermerDetails() { document.getElementById('modalDetails').classList.add('hidden'); }

function supprimerItem(id) {
    if(confirm("Supprimer définitivement ?")) {
        maCollection = maCollection.filter(i => i.id !== id);
        storage.setItem('otakus_v6', JSON.stringify(maCollection));
        afficherCollection();
        fermerDetails();
    }
}

// --- CHAT ---
function envoyerMessage() {
    const input = document.getElementById('chatMessage');
    const box = document.getElementById('chatBox');
    if(input.value.trim() !== "") {
        box.innerHTML += `<div style="background:var(--accent); color:white; padding:12px 15px; border-radius:15px 15px 0 15px; align-self:flex-end; max-width:80%;">${input.value}</div>`;
        input.value = '';
        box.scrollTop = box.scrollHeight;
    }
}

// --- LANCEMENT ET RESTAURATION DU THÈME ---
afficherCollection();
chargerMangasTendances();
afficherWallpapers();
document.querySelector('.btn-flottant').style.display = 'none';

// Appliquer le thème sauvegardé
const themeSauvegarde = storage.getItem('otakus_theme') || 'dark';
changerTheme(themeSauvegarde);
