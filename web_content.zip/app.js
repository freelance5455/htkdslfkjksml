// --- 1. تعريف المتغيرات والعناصر ---
const monthNames = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];

let currentFilter = 'الكل';
let currentSearch = '';
let currentDetailId = null;
let currentPickerType = ''; // لمعرفة إحنا بنختار إيه دلوقتي

// الشاشات
const viewHome = document.getElementById('viewHome');
const viewForm = document.getElementById('viewForm');
const viewDetail = document.getElementById('viewDetail');

// عناصر الشاشة الرئيسية
const deviceList = document.getElementById('deviceList');
const emptyState = document.getElementById('emptyState');
const searchInput = document.getElementById('searchInput');
const filterChips = document.getElementById('filterChips');
const fabAdd = document.getElementById('fabAdd');

// عناصر الفورم
const deviceForm = document.getElementById('deviceForm');
const formTitle = document.getElementById('formTitle');
const deviceIdInput = document.getElementById('deviceId');
const deviceNameInput = document.getElementById('deviceName');
const deviceTypeInput = document.getElementById('deviceType'); // الحقل المخفي
const warrantyMonthsInput = document.getElementById('warrantyMonths');
const invoiceImageInput = document.getElementById('invoiceImage');
const imagePreview = document.getElementById('imagePreview');
const cancelBtn = document.getElementById('cancelBtn');

// عناصر النافذة المنبثقة
const pickerModal = document.getElementById('customPickerModal');
const pickerList = document.getElementById('pickerList');
const pickerTitle = document.getElementById('pickerTitle');

// عناصر التفاصيل
const detailContent = document.getElementById('detailContent');
const backBtn = document.getElementById('backBtn');
const editBtn = document.getElementById('editBtn');

// --- 2. دوال التنقل بين الشاشات ---
function showView(view) {
  viewHome.classList.remove('active');
  viewForm.classList.remove('active');
  viewDetail.classList.remove('active');
  
  view.classList.add('active');
  
  if (view === viewHome) {
    fabAdd.classList.remove('hidden');
  } else {
    fabAdd.classList.add('hidden');
  }
}

// --- 3. دوال القائمة المخصصة (Custom Picker) ---
function openPicker(type) {
  currentPickerType = type;
  pickerList.innerHTML = '';
  let options = [];
  let currentValue = '';
  let title = '';

  if (type === 'day') {
    title = 'اختر اليوم';
    currentValue = document.getElementById('purchaseDay').value;
    for(let i=1; i<=31; i++) options.push({ val: i.toString().padStart(2, '0'), text: i });
  } else if (type === 'month') {
    title = 'اختر الشهر';
    currentValue = document.getElementById('purchaseMonth').value;
    monthNames.forEach((name, index) => {
      options.push({ val: (index + 1).toString().padStart(2, '0'), text: name });
    });
  } else if (type === 'year') {
    title = 'اختر السنة';
    currentValue = document.getElementById('purchaseYear').value;
    const currentYear = new Date().getFullYear();
    for(let i=currentYear; i>=1990; i--) options.push({ val: i.toString(), text: i });
  } else if (type === 'type') {
    title = 'اختر النوع';
    currentValue = document.getElementById('deviceType').value;
    const types = ['موبايل', 'لابتوب', 'غسالة', 'تكييف', 'ثلاجة', 'تلفزيون', 'أخرى'];
    types.forEach(t => options.push({ val: t, text: t }));
  }

  pickerTitle.innerText = title;

  options.forEach(opt => {
    const div = document.createElement('div');
    div.className = 'picker-item';
    if (opt.val === currentValue) div.classList.add('selected');
    div.innerText = opt.text;
    div.onclick = () => selectPickerValue(opt.val, opt.text);
    pickerList.appendChild(div);
  });

  pickerModal.classList.add('show');
}

function selectPickerValue(val, text) {
  if (currentPickerType === 'day') {
    document.getElementById('purchaseDay').value = val;
    document.getElementById('btnDay').innerText = text;
  } else if (currentPickerType === 'month') {
    document.getElementById('purchaseMonth').value = val;
    document.getElementById('btnMonth').innerText = text;
  } else if (currentPickerType === 'year') {
    document.getElementById('purchaseYear').value = val;
    document.getElementById('btnYear').innerText = text;
  } else if (currentPickerType === 'type') {
    document.getElementById('deviceType').value = val;
    document.getElementById('btnType').innerText = text;
  }
  closePicker();
}

function closePicker() {
  pickerModal.classList.remove('show');
}

// دالة لضبط تاريخ اليوم كقيمة افتراضية
function setDefaultDate() {
  const today = new Date();
  const day = today.getDate().toString().padStart(2, '0');
  const month = (today.getMonth() + 1).toString().padStart(2, '0');
  const year = today.getFullYear().toString();

  document.getElementById('purchaseDay').value = day;
  document.getElementById('btnDay').innerText = day;
  
  document.getElementById('purchaseMonth').value = month;
  document.getElementById('btnMonth').innerText = monthNames[parseInt(month) - 1];
  
  document.getElementById('purchaseYear').value = year;
  document.getElementById('btnYear').innerText = year;

  // تصفير النوع
  document.getElementById('deviceType').value = '';
  document.getElementById('btnType').innerText = 'اختر النوع';
}

// --- 4. حسابات التواريخ ---
function calculateDates(purchaseDateStr, months) {
  const purchaseDate = new Date(purchaseDateStr);
  const expiryDate = new Date(purchaseDate);
  expiryDate.setMonth(expiryDate.getMonth() + parseInt(months));
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const diffTime = expiryDate - today;
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  let statusClass = 'status-safe';
  let statusText = `باقي ${diffDays} يوم`;
  
  if (diffDays < 0) {
    statusClass = 'status-expired';
    statusText = 'انتهى الضمان';
  } else if (diffDays <= 7) {
    statusClass = 'status-danger';
    statusText = `باقي ${diffDays} أيام`;
  } else if (diffDays <= 30) {
    statusClass = 'status-warning';
    statusText = `باقي ${diffDays} يوم`;
  }

  return {
    expiryDateStr: expiryDate.toLocaleDateString('ar-EG'),
    diffDays,
    statusClass,
    statusText
  };
}

// --- 5. عرض الأجهزة في الشاشة الرئيسية ---
function renderDevices() {
  let devices = getDevices();

  if (currentSearch) {
    devices = devices.filter(d => d.name.toLowerCase().includes(currentSearch.toLowerCase()));
  }
  
  if (currentFilter !== 'الكل') {
    devices = devices.filter(d => d.type === currentFilter);
  }

  devices.sort((a, b) => {
    const dateA = calculateDates(a.purchaseDate, a.warrantyMonths).diffDays;
    const dateB = calculateDates(b.purchaseDate, b.warrantyMonths).diffDays;
    return dateA - dateB;
  });

  deviceList.innerHTML = '';

  if (devices.length === 0) {
    emptyState.style.display = 'block';
  } else {
    emptyState.style.display = 'none';
    
    devices.forEach(device => {
      const dates = calculateDates(device.purchaseDate, device.warrantyMonths);
      
      const card = document.createElement('div');
      card.className = 'device-card';
      card.onclick = () => openDetail(device.id);
      
      card.innerHTML = `
        <div class="device-card-header">
          <span class="device-card-name">${device.name}</span>
          <span class="device-card-type">${device.type}</span>
        </div>
        <div class="device-card-info">
          ينتهي في: ${dates.expiryDateStr}
        </div>
        <div class="device-card-status ${dates.statusClass}">
          ${dates.statusText}
        </div>
      `;
      deviceList.appendChild(card);
    });
  }
}

function renderFilterChips() {
  const types = ['الكل', 'موبايل', 'لابتوب', 'غسالة', 'تكييف', 'ثلاجة', 'تلفزيون', 'أخرى'];
  filterChips.innerHTML = '';
  
  types.forEach(type => {
    const chip = document.createElement('button');
    chip.className = `chip ${currentFilter === type ? 'active' : ''}`;
    chip.innerText = type;
    chip.onclick = () => {
      currentFilter = type;
      renderFilterChips();
      renderDevices();
    };
    filterChips.appendChild(chip);
  });
}

// --- 6. شاشة التفاصيل ---
function openDetail(id) {
  const device = getDeviceById(id);
  if (!device) return;
  
  currentDetailId = id;
  const dates = calculateDates(device.purchaseDate, device.warrantyMonths);
  
  let countdownClass = 'countdown-box';
  if (dates.diffDays < 0) countdownClass += ' expired';
  else if (dates.diffDays <= 7) countdownClass += ' danger';
  else if (dates.diffDays <= 30) countdownClass += ' warning';

  let imageHtml = '';
  if (device.image) {
    imageHtml = `<div style="margin-top:20px;text-align:center;">
                   <img src="${device.image}" style="max-width:100%;border-radius:12px;" alt="الفاتورة">
                 </div>`;
  }

  detailContent.innerHTML = `
    <h2 style="color:var(--primary);margin-bottom:16px;">${device.name}</h2>
    <div class="detail-row">
      <span class="detail-label">النوع</span>
      <span class="detail-value">${device.type}</span>
    </div>
    <div class="detail-row">
      <span class="detail-label">تاريخ الشراء</span>
      <span class="detail-value">${new Date(device.purchaseDate).toLocaleDateString('ar-EG')}</span>
    </div>
    <div class="detail-row">
      <span class="detail-label">مدة الضمان</span>
      <span class="detail-value">${device.warrantyMonths} شهر</span>
    </div>
    <div class="detail-row">
      <span class="detail-label">تاريخ الانتهاء</span>
      <span class="detail-value">${dates.expiryDateStr}</span>
    </div>
    
    <div class="${countdownClass}">
      <span>الأيام المتبقية</span>
      <span class="countdown-days">${dates.diffDays < 0 ? '0' : dates.diffDays}</span>
      <span>${dates.diffDays < 0 ? 'انتهى الضمان' : 'يوم'}</span>
    </div>

    ${imageHtml}
    
    <div class="form-actions" style="margin-top:24px;">
      <button type="button" class="btn-secondary" style="color:var(--danger);border-color:var(--danger);" onclick="handleDelete()">حذف الجهاز</button>
    </div>
  `;
  
  showView(viewDetail);
}

// --- 7. شاشة الإضافة والتعديل ---
function openForm(id = null) {
  deviceForm.reset();
  imagePreview.innerHTML = '';
  
  if (id) {
    const device = getDeviceById(id);
    if (device) {
      formTitle.innerText = 'تعديل جهاز';
      deviceIdInput.value = device.id;
      deviceNameInput.value = device.name;
      
      // تحديث قوائم التاريخ
      const parts = device.purchaseDate.split('-'); 
      if (parts.length === 3) {
        document.getElementById('purchaseYear').value = parts[0];
        document.getElementById('btnYear').innerText = parts[0];
        
        document.getElementById('purchaseMonth').value = parts[1];
        document.getElementById('btnMonth').innerText = monthNames[parseInt(parts[1]) - 1];
        
        document.getElementById('purchaseDay').value = parts[2];
        document.getElementById('btnDay').innerText = parts[2];
      }
      
      // تحديث النوع
      document.getElementById('deviceType').value = device.type;
      document.getElementById('btnType').innerText = device.type;
      
      warrantyMonthsInput.value = device.warrantyMonths;
      
      if (device.image) {
        imagePreview.innerHTML = `<img src="${device.image}" alt="الفاتورة">`;
      }
    }
  } else {
    formTitle.innerText = 'إضافة جهاز';
    deviceIdInput.value = '';
    setDefaultDate(); // بنحط تاريخ النهاردة افتراضيًا
  }
  
  showView(viewForm);
}

// --- 8. معالجة الأحداث (Event Listeners) ---
fabAdd.onclick = () => openForm();

cancelBtn.onclick = () => {
  showView(viewHome);
};

searchInput.oninput = (e) => {
  currentSearch = e.target.value;
  renderDevices();
};

invoiceImageInput.onchange = (e) => {
  const file = e.target.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (event) => {
      imagePreview.innerHTML = `<img src="${event.target.result}" alt="الفاتورة">`;
    };
    reader.readAsDataURL(file);
  } else {
    imagePreview.innerHTML = '';
  }
};

deviceForm.onsubmit = (e) => {
  e.preventDefault();
  
  const id = deviceIdInput.value;
  const name = deviceNameInput.value;
  const type = document.getElementById('deviceType').value;
  
  // تجميع التاريخ
  const day = document.getElementById('purchaseDay').value;
  const month = document.getElementById('purchaseMonth').value;
  const year = document.getElementById('purchaseYear').value;
  
  // التحقق من إن المستخدم اختار نوع وتاريخ
  if (!type) {
    alert('الرجاء اختيار نوع الجهاز');
    return;
  }
  if (!day || !month || !year) {
    alert('الرجاء اختيار تاريخ الشراء');
    return;
  }

  const purchaseDate = `${year}-${month}-${day}`;
  const warrantyMonths = warrantyMonthsInput.value;
  
  const saveData = (imageBase64 = '') => {
    const device = {
      id: id || null,
      name,
      type,
      purchaseDate,
      warrantyMonths,
      image: imageBase64
    };
    
    saveDevice(device);
    
    showView(viewHome);
    renderDevices();
    
    if(typeof checkAndScheduleNotifications === 'function') {
       checkAndScheduleNotifications();
    }
  };

  if (invoiceImageInput.files.length > 0) {
    const file = invoiceImageInput.files[0];
    const reader = new FileReader();
    reader.onload = (event) => saveData(event.target.result);
    reader.readAsDataURL(file);
  } else {
    const oldDevice = id ? getDeviceById(id) : null;
    saveData(oldDevice ? oldDevice.image : '');
  }
};

backBtn.onclick = () => {
  showView(viewHome);
  renderDevices();
};

editBtn.onclick = () => {
  openForm(currentDetailId);
};

window.handleDelete = () => {
  if (confirm('هل أنت متأكد من حذف هذا الجهاز؟')) {
    deleteDevice(currentDetailId);
    showView(viewHome);
    renderDevices();
  }
};

// --- 9. التشغيل الأولي ---
setDefaultDate(); // تعيين تاريخ اليوم
renderFilterChips();
renderDevices();