(function () {
  'use strict';

  var MAX_TEXT_BYTES = 1024 * 1024;
  var MAX_HEX_BYTES = 4096;
  var MAX_ARCHIVE_CENTRAL_BYTES = 8 * 1024 * 1024;
  var MAX_ARCHIVE_ENTRIES = 5000;
  var MAX_COMPARE_BYTES = 128 * 1024 * 1024;
  var paneNames = ['left', 'right'];
  var state = {
    left: { files: [], selectedId: null, search: '' },
    right: { files: [], selectedId: null, search: '' },
    activePane: 'left',
    activeTab: 'info',
    nextId: 1,
    textCache: {},
    archiveCache: new WeakMap(),
    imageUrl: null,
    lastValidation: null,
    lastCompare: null,
    operationLog: []
  };

  var $ = function (id) { return document.getElementById(id); };
  var elements = {
    leftPicker: $('leftPicker'), rightPicker: $('rightPicker'),
    leftList: $('leftList'), rightList: $('rightList'),
    leftCount: $('leftCount'), rightCount: $('rightCount'),
    leftSummary: $('leftSummary'), rightSummary: $('rightSummary'),
    leftSearch: $('leftSearch'), rightSearch: $('rightSearch'),
    workspaceEmpty: $('workspaceEmpty'), workspaceContent: $('workspaceContent'),
    fileSummaryCard: $('fileSummaryCard'), tabStrip: $('tabStrip'),
    viewerPanel: $('viewerPanel'), workbenchActions: $('workbenchActions'),
    activeFileChip: $('activeFileChip'), compareResult: $('compareResult'),
    statusText: $('statusText'), statusLed: $('statusLed')
  };

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function formatBytes(bytes) {
    if (!Number.isFinite(bytes) || bytes < 0) return '—';
    if (bytes < 1024) return bytes + ' B';
    var units = ['KB', 'MB', 'GB'];
    var value = bytes / 1024;
    var index = 0;
    while (value >= 1024 && index < units.length - 1) { value /= 1024; index += 1; }
    return value.toFixed(value >= 10 ? 1 : 2) + ' ' + units[index];
  }

  function extensionOf(name) {
    var clean = String(name || '').split(/[?#]/)[0];
    var dot = clean.lastIndexOf('.');
    return dot > -1 ? clean.slice(dot + 1).toLowerCase() : '';
  }

  function setStatus(message, isError) {
    elements.statusText.textContent = message;
    elements.statusLed.classList.toggle('error', !!isError);
  }

  function logOperation(type, detail) {
    state.operationLog.push({ time: new Date().toISOString(), type: type, detail: String(detail || '') });
    if (state.operationLog.length > 100) state.operationLog.shift();
  }

  function byteString(bytes) {
    var result = '';
    for (var i = 0; i < bytes.length; i += 1) result += String.fromCharCode(bytes[i]);
    return result;
  }

  function detectFromHeader(bytes, name, mime) {
    var ext = extensionOf(name);
    var type = 'Không xác định';
    var category = 'unknown';
    var signature = 'Chưa nhận diện';
    var ascii = byteString(bytes);
    if (bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && (bytes[2] === 0x03 || bytes[2] === 0x05 || bytes[2] === 0x07)) {
      type = 'ZIP / gói APK'; category = 'archive'; signature = 'PK ZIP';
    } else if (bytes.length >= 8 && ascii.slice(0, 4) === '\x89PNG') {
      type = 'PNG Image'; category = 'image'; signature = 'PNG';
    } else if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
      type = 'JPEG Image'; category = 'image'; signature = 'JPEG';
    } else if (ascii.slice(0, 6) === 'GIF87a' || ascii.slice(0, 6) === 'GIF89a') {
      type = 'GIF Image'; category = 'image'; signature = 'GIF';
    } else if (ascii.slice(0, 4) === 'RIFF' && ascii.slice(8, 12) === 'WEBP') {
      type = 'WebP Image'; category = 'image'; signature = 'RIFF/WEBP';
    } else if (ascii.slice(0, 4) === '%PDF') {
      type = 'PDF Document'; category = 'document'; signature = '%PDF';
    } else if (bytes.length >= 4 && bytes[0] === 0x7f && ascii.slice(1, 4) === 'ELF') {
      type = 'ELF / thư viện native'; category = 'binary'; signature = 'ELF';
    } else if (ascii.slice(0, 4) === 'dex\n') {
      type = 'Dalvik DEX'; category = 'binary'; signature = 'DEX';
    } else if (ascii.slice(0, 4) === 'OggS') {
      type = 'OGG Audio'; category = 'audio'; signature = 'OggS';
    } else if (ascii.slice(0, 4) === 'SQLite format 3') {
      type = 'SQLite Database'; category = 'database'; signature = 'SQLite';
    } else if (bytes[0] === 0x1f && bytes[1] === 0x8b) {
      type = 'GZIP'; category = 'archive'; signature = 'GZIP';
    } else if (ascii.slice(0, 3) === 'ID3' || (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0)) {
      type = 'MP3 Audio'; category = 'audio'; signature = 'MP3';
    } else if (ascii.slice(0, 4) === 'RIFF' && ascii.slice(8, 12) === 'WAVE') {
      type = 'WAV Audio'; category = 'audio'; signature = 'RIFF/WAVE';
    } else if (mime && mime.indexOf('image/') === 0) {
      type = 'Image'; category = 'image'; signature = 'MIME';
    } else {
      var byExt = {
        apk: ['APK (theo phần mở rộng)', 'archive'], zip: ['ZIP (theo phần mở rộng)', 'archive'],
        xml: ['XML', 'text'], json: ['JSON', 'text'], txt: ['Text', 'text'],
        html: ['HTML', 'text'], htm: ['HTML', 'text'], css: ['CSS', 'text'],
        js: ['JavaScript', 'text'], smali: ['Smali', 'text'], java: ['Java', 'text'],
        md: ['Markdown', 'text'], csv: ['CSV', 'text'], log: ['Log', 'text'],
        yml: ['YAML', 'text'], yaml: ['YAML', 'text'], ini: ['INI', 'text'],
        properties: ['Properties', 'text'], svg: ['SVG', 'text'],
        png: ['PNG Image', 'image'], jpg: ['JPEG Image', 'image'], jpeg: ['JPEG Image', 'image'], webp: ['WebP Image', 'image'],
        so: ['Shared Object (SO)', 'binary'], dex: ['Dalvik DEX', 'binary'], bin: ['Binary', 'binary'], dat: ['Data', 'binary'], arsc: ['Android resources.arsc', 'binary']
      };
      if (byExt[ext]) { type = byExt[ext][0]; category = byExt[ext][1]; signature = 'Phần mở rộng'; }
      else if (mime && mime.indexOf('text/') === 0) { type = 'Text'; category = 'text'; signature = 'MIME'; }
    }
    return { type: type, category: category, signature: signature, extension: ext || 'không có' };
  }

  async function inspectFile(file) {
    try {
      var header = new Uint8Array(await file.slice(0, 32).arrayBuffer());
      return detectFromHeader(header, file.name, file.type);
    } catch (error) {
      return { type: 'Không đọc được header', category: 'unknown', signature: 'Lỗi đọc', extension: extensionOf(file.name) || 'không có' };
    }
  }

  function getEntry(paneName, id) {
    var pane = state[paneName];
    for (var i = 0; i < pane.files.length; i += 1) if (pane.files[i].id === id) return pane.files[i];
    return null;
  }

  function getSelected(paneName) {
    var pane = state[paneName];
    return pane.selectedId == null ? null : getEntry(paneName, pane.selectedId);
  }

  function activeEntry() { return getSelected(state.activePane); }

  function paneLabel(name) { return name === 'left' ? 'A' : 'B'; }

  function rowIcon(entry) {
    var ext = entry.info.extension;
    if (entry.info.category === 'archive') return 'ZIP';
    if (entry.info.category === 'image') return 'IMG';
    if (entry.info.category === 'text') return 'TXT';
    if (entry.info.category === 'audio') return 'AUD';
    if (entry.info.category === 'binary') return ext.slice(0, 3).toUpperCase() || 'BIN';
    return 'FILE';
  }

  function renderPane(name) {
    var pane = state[name];
    var listEl = name === 'left' ? elements.leftList : elements.rightList;
    var countEl = name === 'left' ? elements.leftCount : elements.rightCount;
    var summaryEl = name === 'left' ? elements.leftSummary : elements.rightSummary;
    var query = pane.search.toLowerCase();
    var visible = pane.files.filter(function (entry) {
      return !query || entry.file.name.toLowerCase().indexOf(query) !== -1 || entry.info.type.toLowerCase().indexOf(query) !== -1;
    });
    countEl.textContent = pane.files.length + ' FILE';
    var total = pane.files.reduce(function (sum, entry) { return sum + entry.file.size; }, 0);
    summaryEl.textContent = pane.files.length ? pane.files.length + ' file · ' + formatBytes(total) : 'Đang chờ file';
    if (!visible.length) {
      listEl.innerHTML = '<div class="empty-list"><span>' + (pane.files.length ? '⌕' : '＋') + '</span><b>' + (pane.files.length ? 'Không tìm thấy file' : 'Chưa có file') + '</b><small>' + (pane.files.length ? 'Thử từ khóa khác' : 'Chọn file hoặc thả file vào đây') + '</small></div>';
      return;
    }
    listEl.innerHTML = visible.map(function (entry) {
      var selected = pane.selectedId === entry.id ? ' selected' : '';
      return '<button type="button" class="file-row' + selected + '" role="listitem" data-pane="' + name + '" data-file-id="' + entry.id + '">' +
        '<span class="file-row-icon">' + escapeHtml(rowIcon(entry)) + '</span>' +
        '<span class="file-row-main"><span class="file-row-name">' + escapeHtml(entry.file.name) + '</span>' +
        '<span class="file-row-meta">' + escapeHtml(entry.info.type) + '</span></span>' +
        '<span class="file-row-size">' + formatBytes(entry.file.size) + '</span></button>';
    }).join('');
  }

  function renderAllPanes() {
    renderPane('left'); renderPane('right');
    $('leftPane').classList.toggle('is-active', state.activePane === 'left');
    $('rightPane').classList.toggle('is-active', state.activePane === 'right');
  }

  async function addFiles(name, fileList) {
    var files = Array.prototype.slice.call(fileList || []);
    if (!files.length) return;
    var pane = state[name];
    var added = [];
    files.forEach(function (file) {
      if (!file || typeof file.name !== 'string') return;
      var id = state.nextId++;
      var entry = { id: id, file: file, info: { type: 'Đang nhận diện…', category: 'unknown', signature: 'Đang đọc', extension: extensionOf(file.name) || 'không có' } };
      pane.files.push(entry); added.push(entry);
    });
    if (pane.selectedId == null && added.length) pane.selectedId = added[0].id;
    state.activePane = name;
    renderAllPanes();
    setStatus('Đang nhận diện ' + added.length + ' file ở khung ' + paneLabel(name) + '…');
    for (var i = 0; i < added.length; i += 1) {
      added[i].info = await inspectFile(added[i].file);
    }
    renderAllPanes(); renderWorkspace();
    setStatus('Đã thêm ' + added.length + ' file vào khung ' + paneLabel(name) + '.');
    logOperation('add_files', paneLabel(name) + ': ' + added.map(function (item) { return item.file.name; }).join(', '));
  }

  function selectFile(name, id) {
    if (!getEntry(name, id)) return;
    state[name].selectedId = id;
    state.activePane = name;
    state.activeTab = 'info';
    state.lastValidation = null;
    renderAllPanes(); renderWorkspace();
    setStatus('Đang xem ' + getEntry(name, id).file.name + ' ở khung ' + paneLabel(name) + '.');
  }

  function canTreatAsText(entry) {
    var ext = entry.info.extension;
    return entry.info.category === 'text' || ['xml','json','txt','html','htm','css','js','smali','java','md','csv','log','yml','yaml','ini','properties','svg'].indexOf(ext) !== -1;
  }

  function availableTabs(entry) {
    var tabs = [{ id: 'info', label: 'Thông tin' }, { id: 'hex', label: 'HEX' }];
    if (canTreatAsText(entry)) tabs.splice(1, 0, { id: 'text', label: 'Văn bản' });
    if (entry.info.category === 'archive' || entry.info.extension === 'apk' || entry.info.extension === 'zip') tabs.push({ id: 'archive', label: 'Cấu trúc gói' });
    if (entry.info.category === 'image') tabs.push({ id: 'image', label: 'Ảnh xem trước' });
    if (entry.info.signature === 'DEX' || entry.info.extension === 'dex') tabs.push({ id: 'dex', label: 'DEX info' });
    return tabs;
  }

  function renderSummary(entry) {
    var pane = paneLabel(state.activePane);
    elements.activeFileChip.textContent = pane + ' / ' + entry.file.name;
    elements.fileSummaryCard.innerHTML = '<div class="summary-main"><div class="summary-name">' + escapeHtml(entry.file.name) + '</div>' +
      '<div class="summary-sub">Khung ' + pane + ' · ' + formatBytes(entry.file.size) + ' · ' + escapeHtml(entry.info.signature) + '</div></div>' +
      '<span class="type-badge">' + escapeHtml(entry.info.type) + '</span>';
  }

  function renderWorkspace() {
    var entry = activeEntry();
    if (!entry) {
      elements.workspaceEmpty.hidden = false; elements.workspaceContent.hidden = true;
      elements.activeFileChip.textContent = 'Chưa chọn file';
      if (state.imageUrl) { URL.revokeObjectURL(state.imageUrl); state.imageUrl = null; }
      return;
    }
    elements.workspaceEmpty.hidden = true; elements.workspaceContent.hidden = false;
    renderSummary(entry);
    var tabs = availableTabs(entry);
    if (!tabs.some(function (tab) { return tab.id === state.activeTab; })) state.activeTab = 'info';
    elements.tabStrip.innerHTML = tabs.map(function (tab) {
      return '<button type="button" class="tab-button' + (state.activeTab === tab.id ? ' active' : '') + '" data-tab="' + tab.id + '">' + tab.label + '</button>';
    }).join('');
    renderViewer(entry);
    renderActions(entry);
  }

  function infoHtml(entry) {
    return '<div class="info-grid">' +
      infoCell('Tên file', entry.file.name) + infoCell('Dung lượng', formatBytes(entry.file.size)) +
      infoCell('Loại nhận diện', entry.info.type) + infoCell('Chữ ký', entry.info.signature) +
      infoCell('Phần mở rộng', entry.info.extension) + infoCell('MIME', entry.file.type || 'Không được hệ thống cung cấp') +
      infoCell('Ngày sửa đổi', entry.file.lastModified ? new Date(entry.file.lastModified).toLocaleString() : 'Không rõ') +
      infoCell('Khung', paneLabel(state.activePane)) + '</div>' +
      '<div class="validation-result">Nhận diện dựa trên chữ ký đầu file và phần mở rộng. Đây là bước phân loại, không phải xác minh toàn vẹn hay chứng nhận file an toàn.</div>';
  }

  function infoCell(label, value) {
    return '<div class="info-cell"><span>' + escapeHtml(label) + '</span><b>' + escapeHtml(value) + '</b></div>';
  }

  async function readText(entry) {
    if (entry.file.size > MAX_TEXT_BYTES) throw new Error('File vượt giới hạn đọc văn bản ' + formatBytes(MAX_TEXT_BYTES) + ' để bảo vệ RAM.');
    if (Object.prototype.hasOwnProperty.call(state.textCache, entry.id)) return state.textCache[entry.id];
    var buffer = await entry.file.arrayBuffer();
    var raw = new Uint8Array(buffer);
    var encoding = 'utf-8';
    if (raw.length >= 2 && raw[0] === 0xff && raw[1] === 0xfe) encoding = 'utf-16le';
    else if (raw.length >= 2 && raw[0] === 0xfe && raw[1] === 0xff) encoding = 'utf-16be';
    var decoder = new TextDecoder(encoding, { fatal: false });
    var text = decoder.decode(buffer);
    if (text.indexOf('\u0000') !== -1) throw new Error('File có byte NUL; có thể đây là file nhị phân, không nên mở như văn bản.');
    state.textCache[entry.id] = { original: text, value: text, dirty: false };
    return state.textCache[entry.id];
  }

  async function renderTextViewer(entry) {
    elements.viewerPanel.innerHTML = '<div class="viewer-note">Đang đọc văn bản…</div>';
    try {
      var data = await readText(entry);
      if (activeEntry() !== entry || state.activeTab !== 'text') return;
      elements.viewerPanel.innerHTML = '<textarea id="textEditor" class="code-editor" spellcheck="false" autocapitalize="off" autocomplete="off"></textarea>' +
        '<div class="editor-meta"><span id="editorState">' + (data.dirty ? 'Có thay đổi chưa xuất' : 'Bản gốc · chỉ sửa bản sao') + '</span><span id="editorLength">' + data.value.length.toLocaleString() + ' ký tự</span></div>';
      var editor = $('textEditor'); editor.value = data.value;
      editor.addEventListener('input', function () {
        data.value = editor.value; data.dirty = data.value !== data.original;
        $('editorState').textContent = data.dirty ? 'Có thay đổi chưa xuất' : 'Không có thay đổi';
        $('editorLength').textContent = data.value.length.toLocaleString() + ' ký tự';
      });
    } catch (error) {
      elements.viewerPanel.innerHTML = '<div class="validation-result bad">' + escapeHtml(error.message || 'Không thể đọc file này như văn bản.') + '</div>';
    }
  }

  async function renderHexViewer(entry) {
    elements.viewerPanel.innerHTML = '<div class="viewer-note">Đang đọc dữ liệu HEX…</div>';
    try {
      var buffer = await entry.file.slice(0, MAX_HEX_BYTES).arrayBuffer();
      if (activeEntry() !== entry || state.activeTab !== 'hex') return;
      var bytes = new Uint8Array(buffer); var lines = [];
      for (var offset = 0; offset < bytes.length; offset += 16) {
        var chunk = bytes.slice(offset, Math.min(offset + 16, bytes.length));
        var hex = []; var ascii = '';
        for (var j = 0; j < 16; j += 1) hex.push(j < chunk.length ? chunk[j].toString(16).padStart(2, '0').toUpperCase() : '  ');
        for (var k = 0; k < chunk.length; k += 1) ascii += chunk[k] >= 32 && chunk[k] <= 126 ? String.fromCharCode(chunk[k]) : '.';
        lines.push('<span class="hex-offset">' + offset.toString(16).padStart(8, '0') + '</span>  ' + hex.join(' ') + '  <span class="hex-ascii">' + escapeHtml(ascii) + '</span>');
      }
      elements.viewerPanel.innerHTML = '<div class="hex-view">' + (lines.join('\n') || 'File rỗng') + '</div><div class="editor-meta"><span>Hiển thị tối đa ' + formatBytes(MAX_HEX_BYTES) + '</span><span>' + formatBytes(entry.file.size) + ' tổng dung lượng</span></div>';
    } catch (error) {
      elements.viewerPanel.innerHTML = '<div class="validation-result bad">Không đọc được HEX: ' + escapeHtml(error.message) + '</div>';
    }
  }

  function findEndOfCentralDirectory(bytes) {
    var view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    for (var i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i -= 1) {
      if (view.getUint32(i, true) === 0x06054b50) return { offset: i, view: view };
    }
    return null;
  }

  async function parseZip(file) {
    var cachedArchive = state.archiveCache.get(file);
    if (cachedArchive) return cachedArchive;
    var tailStart = Math.max(0, file.size - 65557);
    var tail = new Uint8Array(await file.slice(tailStart).arrayBuffer());
    var eocd = findEndOfCentralDirectory(tail);
    if (!eocd) throw new Error('Không tìm thấy cấu trúc ZIP hợp lệ. File có thể không phải ZIP hoặc đã hỏng.');
    var v = eocd.view; var p = eocd.offset;
    var disk = v.getUint16(p + 4, true);
    var centralDisk = v.getUint16(p + 6, true);
    var entriesOnDisk = v.getUint16(p + 8, true);
    var totalEntries = v.getUint16(p + 10, true);
    var centralSize = v.getUint32(p + 12, true);
    var centralOffset = v.getUint32(p + 16, true);
    if (disk !== 0 || centralDisk !== 0 || entriesOnDisk !== totalEntries) throw new Error('ZIP nhiều phân vùng không được hỗ trợ.');
    if (totalEntries === 0xffff || centralSize === 0xffffffff || centralOffset === 0xffffffff) throw new Error('ZIP64 vượt phạm vi bộ phân tích nhẹ này.');
    if (totalEntries > MAX_ARCHIVE_ENTRIES) throw new Error('Gói có quá nhiều mục (' + totalEntries + '); giới hạn an toàn là ' + MAX_ARCHIVE_ENTRIES + '.');
    if (centralSize > MAX_ARCHIVE_CENTRAL_BYTES) throw new Error('Danh mục ZIP quá lớn để xử lý an toàn trên thiết bị RAM 3 GB.');
    if (centralOffset + centralSize > file.size) throw new Error('Vị trí danh mục ZIP nằm ngoài kích thước file.');
    var central = new Uint8Array(await file.slice(centralOffset, centralOffset + centralSize).arrayBuffer());
    var cv = new DataView(central.buffer, central.byteOffset, central.byteLength);
    var entries = []; var cursor = 0;
    for (var n = 0; n < totalEntries; n += 1) {
      if (cursor + 46 > central.length || cv.getUint32(cursor, true) !== 0x02014b50) throw new Error('Danh mục ZIP bị lỗi tại mục ' + (n + 1) + '.');
      var flags = cv.getUint16(cursor + 8, true);
      var method = cv.getUint16(cursor + 10, true);
      var compressed = cv.getUint32(cursor + 20, true);
      var uncompressed = cv.getUint32(cursor + 24, true);
      var nameLength = cv.getUint16(cursor + 28, true);
      var extraLength = cv.getUint16(cursor + 30, true);
      var commentLength = cv.getUint16(cursor + 32, true);
      var totalLength = 46 + nameLength + extraLength + commentLength;
      if (cursor + totalLength > central.length) throw new Error('Tên hoặc metadata ZIP vượt giới hạn danh mục.');
      var nameBytes = central.slice(cursor + 46, cursor + 46 + nameLength);
      var name;
      try { name = new TextDecoder((flags & 0x800) ? 'utf-8' : 'utf-8').decode(nameBytes); }
      catch (ignore) { name = byteString(nameBytes); }
      entries.push({ name: name, compressed: compressed, size: uncompressed, method: method, flags: flags, directory: /\/$/.test(name) });
      cursor += totalLength;
    }
    var result = { entries: entries, totalEntries: totalEntries, centralSize: centralSize, zip64: false };
    state.archiveCache.set(file, result);
    return result;
  }

  function classifyArchiveName(name) {
    var lower = name.toLowerCase();
    if (lower.indexOf('assets/') === 0) return 'assets';
    if (lower.indexOf('res/') === 0) return 'res';
    if (lower.indexOf('lib/') === 0 || /\.so$/.test(lower)) return 'native';
    if (/\.dex$/.test(lower)) return 'dex';
    if (lower.indexOf('meta-inf/') === 0) return 'signature';
    if (/\.(png|jpg|jpeg|webp|ogg|wav|mp3|mp4|json|xml|dat|bundle|pak)$/i.test(lower)) return 'resource';
    return 'other';
  }

  async function renderArchiveViewer(entry) {
    elements.viewerPanel.innerHTML = '<div class="viewer-note">Đang đọc danh mục ZIP/APK…</div>';
    try {
      var parsed = await parseZip(entry.file);
      if (activeEntry() !== entry || state.activeTab !== 'archive') return;
      var counts = { assets: 0, res: 0, native: 0, dex: 0, signature: 0, resource: 0, other: 0 };
      parsed.entries.forEach(function (item) { if (!item.directory) counts[classifyArchiveName(item.name)] += 1; });
      var totalUncompressed = parsed.entries.reduce(function (sum, item) { return sum + (item.directory ? 0 : item.size); }, 0);
      var stats = '<div class="archive-summary">' +
        archiveStat(parsed.totalEntries, 'Mục trong gói') + archiveStat(formatBytes(totalUncompressed), 'Dung lượng mở') + archiveStat(counts.native + counts.dex, 'Native / DEX') + '</div>';
      var rows = parsed.entries.slice(0, 250).map(function (item) {
        var suffix = item.directory ? 'THƯ MỤC' : formatBytes(item.size) + ' · ' + (item.method === 0 ? 'STORE' : item.method === 8 ? 'DEFLATE' : 'METHOD ' + item.method);
        return '<div class="archive-row"><span>' + escapeHtml(item.name) + '</span><span>' + escapeHtml(suffix) + '</span></div>';
      }).join('');
      var tailNote = parsed.entries.length > 250 ? '<div class="validation-result">Đang hiển thị 250/' + parsed.entries.length + ' mục đầu tiên để giữ nhẹ bộ nhớ.</div>' : '';
      elements.viewerPanel.innerHTML = stats + '<div class="archive-list">' + (rows || '<div class="viewer-note">Gói không có mục hiển thị.</div>') + '</div>' + tailNote +
        '<div class="validation-result">Đã đọc danh mục ZIP. Chưa giải nén hoặc xác minh CRC/nội dung từng mục. File AndroidManifest.xml trong APK thường là XML nhị phân và chưa được chuyển thành XML văn bản ở đây.</div>';
    } catch (error) {
      elements.viewerPanel.innerHTML = '<div class="validation-result bad">' + escapeHtml(error.message || 'Không thể phân tích gói.') + '</div>';
    }
  }

  function archiveStat(value, label) { return '<div class="archive-stat"><b>' + escapeHtml(value) + '</b><span>' + escapeHtml(label) + '</span></div>'; }

  function renderImageViewer(entry) {
    if (state.imageUrl) { URL.revokeObjectURL(state.imageUrl); state.imageUrl = null; }
    if (entry.file.size > 12 * 1024 * 1024) {
      elements.viewerPanel.innerHTML = '<div class="validation-result">Ảnh lớn hơn 12 MB. Để tránh tốn RAM trên máy 3 GB, bản xem trước bị tắt; bạn vẫn có thể xuất bản sao.</div>';
      return;
    }
    state.imageUrl = URL.createObjectURL(entry.file);
    elements.viewerPanel.innerHTML = '<div class="image-view"><img id="imagePreview" alt="Xem trước hình ảnh"></div><div class="editor-meta"><span>' + escapeHtml(entry.info.type) + '</span><span>' + formatBytes(entry.file.size) + '</span></div>';
    $('imagePreview').src = state.imageUrl;
  }

  function renderDexViewer(entry) {
    elements.viewerPanel.innerHTML = '<div class="viewer-note">Đang đọc header DEX…</div>';
    entry.file.slice(0, 112).arrayBuffer().then(function (buffer) {
      if (activeEntry() !== entry || state.activeTab !== 'dex') return;
      var bytes = new Uint8Array(buffer); var header = byteString(bytes);
      if (header.slice(0, 4) !== 'dex\n' || bytes.length < 112) {
        elements.viewerPanel.innerHTML = '<div class="validation-result bad">Không tìm thấy header DEX hợp lệ hoặc header quá ngắn.</div>'; return;
      }
      var view = new DataView(buffer);
      var fileSize = view.getUint32(32, true);
      var headerSize = view.getUint32(36, true);
      var endian = view.getUint32(40, true);
      var strings = view.getUint32(56, true);
      var types = view.getUint32(64, true);
      var methods = view.getUint32(88, true);
      var classes = view.getUint32(96, true);
      var version = header.slice(4, 7);
      elements.viewerPanel.innerHTML = '<div class="info-grid">' +
        infoCell('DEX version', version) + infoCell('Kích thước khai báo', formatBytes(fileSize)) +
        infoCell('Header size', headerSize + ' bytes') + infoCell('Endian tag', endian.toString(16)) +
        infoCell('String IDs', strings) + infoCell('Type IDs', types) +
        infoCell('Method IDs', methods) + infoCell('Class definitions', classes) + '</div>' +
        '<div class="validation-result">Đây là phân tích header DEX cơ bản, không phải dịch ngược class thành mã Java. Không có mã nguồn gốc đầy đủ nếu ứng dụng đã bị tối ưu hóa hoặc làm rối.</div>';
    }).catch(function (error) {
      elements.viewerPanel.innerHTML = '<div class="validation-result bad">Lỗi đọc DEX: ' + escapeHtml(error.message) + '</div>';
    });
  }

  function renderViewer(entry) {
    if (state.imageUrl && state.activeTab !== 'image') { URL.revokeObjectURL(state.imageUrl); state.imageUrl = null; }
    if (state.activeTab === 'info') elements.viewerPanel.innerHTML = infoHtml(entry);
    else if (state.activeTab === 'text') renderTextViewer(entry);
    else if (state.activeTab === 'hex') renderHexViewer(entry);
    else if (state.activeTab === 'archive') renderArchiveViewer(entry);
    else if (state.activeTab === 'image') renderImageViewer(entry);
    else if (state.activeTab === 'dex') renderDexViewer(entry);
  }

  function renderActions(entry) {
    var buttons = [];
    buttons.push('<button type="button" class="tool-button" data-action="info">Thông tin</button>');
    if (canTreatAsText(entry)) {
      buttons.push('<button type="button" class="tool-button" data-action="validate">Kiểm tra cú pháp</button>');
      if (entry.info.extension === 'json') buttons.push('<button type="button" class="tool-button" data-action="format-json">Định dạng JSON</button>');
      buttons.push('<button type="button" class="tool-button important" data-action="save-text">Xuất bản đã sửa</button>');
    }
    buttons.push('<button type="button" class="tool-button" data-action="export-original">Xuất bản sao gốc</button>');
    buttons.push('<button type="button" class="tool-button" data-action="hash">Tính SHA-256</button>');
    elements.workbenchActions.innerHTML = buttons.join('');
    if (state.lastValidation) {
      var result = document.createElement('div');
      result.className = 'validation-result ' + (state.lastValidation.ok ? 'good' : 'bad');
      result.textContent = state.lastValidation.message;
      elements.workbenchActions.appendChild(result);
    }
  }

  function validateXml(text) {
    if (typeof DOMParser === 'undefined') return { ok: false, message: 'WebView không cung cấp DOMParser để kiểm tra XML.' };
    var doc = new DOMParser().parseFromString(text, 'application/xml');
    var errors = doc.getElementsByTagName('parsererror');
    if (errors.length) return { ok: false, message: 'XML không hợp lệ: ' + (errors[0].textContent || 'lỗi cú pháp').trim().slice(0, 240) };
    return { ok: true, message: 'XML có thể phân tích cú pháp. Điều này chưa xác nhận các resource hoặc schema bên ngoài.' };
  }

  async function validateCurrent() {
    var entry = activeEntry(); if (!entry) return;
    try {
      var data = await readText(entry);
      var ext = entry.info.extension;
      var result;
      if (ext === 'json') {
        JSON.parse(data.value);
        result = { ok: true, message: 'JSON hợp lệ. Không phát hiện lỗi cú pháp.' };
      } else if (ext === 'xml') result = validateXml(data.value);
      else if (ext === 'html' || ext === 'htm') {
        if (typeof DOMParser === 'undefined') result = { ok: false, message: 'Không có DOMParser trong WebView.' };
        else {
          var doc = new DOMParser().parseFromString(data.value, 'text/html');
          result = { ok: true, message: 'HTML đã được trình phân tích của trình duyệt đọc. Đây không phải kiểm tra đầy đủ theo tiêu chuẩn hoặc kiểm tra JavaScript.' };
        }
      } else result = { ok: false, message: 'Chưa có bộ kiểm tra cú pháp chuyên dụng cho .' + ext + '. File chưa bị thay đổi.' };
      state.lastValidation = result;
      renderActions(entry);
      setStatus(result.message, !result.ok);
      logOperation('validate', entry.file.name + ': ' + result.message);
    } catch (error) {
      state.lastValidation = { ok: false, message: 'Lỗi kiểm tra: ' + (error.message || 'Nội dung không hợp lệ') };
      renderActions(entry); setStatus(state.lastValidation.message, true);
      logOperation('validate_failed', entry.file.name + ': ' + error.message);
    }
  }

  async function formatJson() {
    var entry = activeEntry(); if (!entry || entry.info.extension !== 'json') return;
    try {
      var data = await readText(entry);
      var parsed = JSON.parse(data.value);
      data.value = JSON.stringify(parsed, null, 2);
      data.dirty = data.value !== data.original;
      state.lastValidation = { ok: true, message: 'Đã định dạng JSON. Đây là thay đổi trong bản nháp; nhấn “Xuất bản đã sửa” để lưu thành file mới.' };
      state.activeTab = 'text'; renderWorkspace();
      setStatus('JSON đã được định dạng trong bản nháp.');
      logOperation('format_json', entry.file.name);
    } catch (error) {
      state.lastValidation = { ok: false, message: 'Không thể định dạng JSON: ' + error.message };
      renderWorkspace(); setStatus(state.lastValidation.message, true);
    }
  }

  function downloadBlob(blob, filename) {
    var url = URL.createObjectURL(blob);
    var anchor = document.createElement('a');
    anchor.href = url; anchor.download = filename; anchor.style.display = 'none';
    document.body.appendChild(anchor); anchor.click();
    setTimeout(function () { URL.revokeObjectURL(url); if (anchor.parentNode) anchor.parentNode.removeChild(anchor); }, 1500);
  }

  function editedFilename(name) {
    var dot = name.lastIndexOf('.');
    if (dot > 0) return name.slice(0, dot) + '.edited' + name.slice(dot);
    return name + '.edited';
  }

  async function saveEditedText() {
    var entry = activeEntry(); if (!entry) return;
    try {
      var data = await readText(entry);
      if (!data.dirty) { setStatus('Chưa có thay đổi để xuất.'); return; }
      var blob = new Blob([data.value], { type: 'text/plain;charset=utf-8' });
      var name = editedFilename(entry.file.name);
      downloadBlob(blob, name);
      setStatus('Đã yêu cầu xuất bản sao đã sửa: ' + name + '. Hãy kiểm tra thư mục Tải xuống.');
      logOperation('save_edited', name);
    } catch (error) { setStatus('Không thể xuất file: ' + error.message, true); }
  }

  function exportOriginal() {
    var entry = activeEntry(); if (!entry) return;
    var name = entry.file.name;
    downloadBlob(entry.file, name);
    setStatus('Đã yêu cầu tải bản sao gốc: ' + name + '. Hãy kiểm tra thư mục Tải xuống.');
    logOperation('export_original', name);
  }

  async function calculateSha256() {
    var entry = activeEntry(); if (!entry) return;
    if (!window.crypto || !window.crypto.subtle || !window.crypto.subtle.digest) {
      state.lastValidation = { ok: false, message: 'WebView hiện tại không hỗ trợ Web Crypto trong ngữ cảnh này. Không thể tính SHA-256.' };
      renderActions(entry); setStatus(state.lastValidation.message, true); return;
    }
    if (entry.file.size > 32 * 1024 * 1024) {
      state.lastValidation = { ok: false, message: 'File lớn hơn 32 MB; bỏ qua SHA-256 để tránh dùng quá nhiều RAM.' };
      renderActions(entry); setStatus(state.lastValidation.message, true); return;
    }
    try {
      setStatus('Đang tính SHA-256…');
      var digest = await window.crypto.subtle.digest('SHA-256', await entry.file.arrayBuffer());
      var hash = Array.prototype.map.call(new Uint8Array(digest), function (byte) { return byte.toString(16).padStart(2, '0'); }).join('');
      state.lastValidation = { ok: true, message: 'SHA-256: ' + hash };
      renderActions(entry); setStatus('Đã tính SHA-256 cho ' + entry.file.name + '.');
      logOperation('sha256', entry.file.name + ': ' + hash);
    } catch (error) {
      state.lastValidation = { ok: false, message: 'Lỗi SHA-256: ' + error.message };
      renderActions(entry); setStatus(state.lastValidation.message, true);
    }
  }

  async function compareSelected() {
    var a = getSelected('left'); var b = getSelected('right');
    elements.compareResult.hidden = false;
    if (!a || !b) {
      elements.compareResult.textContent = 'Cần chọn một file ở khung A và một file ở khung B trước khi so sánh.';
      setStatus('Thiếu file ở khung A hoặc B.', true); return;
    }
    if (a.file.size > MAX_COMPARE_BYTES || b.file.size > MAX_COMPARE_BYTES) {
      elements.compareResult.textContent = 'Giới hạn so sánh là ' + formatBytes(MAX_COMPARE_BYTES) + ' cho mỗi file để giữ mức dùng RAM an toàn.';
      setStatus('File quá lớn để so sánh trên cấu hình này.', true); return;
    }
    elements.compareResult.textContent = 'Đang so sánh ' + a.file.name + ' với ' + b.file.name + '…';
    setStatus('Đang so sánh hai file theo từng khối…');
    var max = Math.max(a.file.size, b.file.size); var diff = 0; var first = -1; var chunkSize = 512 * 1024;
    try {
      for (var offset = 0; offset < max; offset += chunkSize) {
        var lenA = Math.max(0, Math.min(chunkSize, a.file.size - offset));
        var lenB = Math.max(0, Math.min(chunkSize, b.file.size - offset));
        var bufA = lenA ? new Uint8Array(await a.file.slice(offset, offset + lenA).arrayBuffer()) : new Uint8Array(0);
        var bufB = lenB ? new Uint8Array(await b.file.slice(offset, offset + lenB).arrayBuffer()) : new Uint8Array(0);
        var len = Math.max(bufA.length, bufB.length);
        for (var i = 0; i < len; i += 1) {
          var va = i < bufA.length ? bufA[i] : -1;
          var vb = i < bufB.length ? bufB[i] : -1;
          if (va !== vb) { diff += 1; if (first < 0) first = offset + i; }
        }
      }
      var same = diff === 0;
      var message = same ? 'Hai file giống hệt nhau theo từng byte.' : 'Phát hiện ' + diff.toLocaleString() + ' vị trí byte khác nhau. Vị trí khác đầu tiên: 0x' + first.toString(16).toUpperCase() + ' (' + first + ' thập phân).';
      if (a.file.size !== b.file.size) message += ' Kích thước khác nhau: ' + formatBytes(a.file.size) + ' và ' + formatBytes(b.file.size) + '.';
      state.lastCompare = { a: a.file.name, b: b.file.name, same: same, differenceCount: diff, firstDifference: first, message: message };
      elements.compareResult.innerHTML = '<strong>' + (same ? '✓ Trùng khớp' : '≠ Có khác biệt') + '</strong><br>' + escapeHtml(a.file.name) + ' ↔ ' + escapeHtml(b.file.name) + '<br>' + escapeHtml(message);
      setStatus(same ? 'So sánh hoàn tất: hai file giống nhau.' : 'So sánh hoàn tất: phát hiện khác biệt.', !same);
      logOperation('compare', message);
    } catch (error) {
      elements.compareResult.textContent = 'Không thể so sánh: ' + error.message;
      setStatus('Lỗi khi so sánh file.', true);
    }
  }

  function createReport() {
    var report = {
      application: 'MyToolbox File Lab', version: '1.0', generatedAt: new Date().toISOString(),
      note: 'Báo cáo chỉ gồm metadata và thao tác trong phiên. Không chứa nội dung file.',
      panels: {}, comparison: state.lastCompare, operations: state.operationLog.slice()
    };
    paneNames.forEach(function (name) {
      report.panels[paneLabel(name)] = state[name].files.map(function (entry) {
        return { name: entry.file.name, size: entry.file.size, type: entry.info.type, signature: entry.info.signature, extension: entry.info.extension, selected: state[name].selectedId === entry.id };
      });
    });
    var blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json;charset=utf-8' });
    downloadBlob(blob, 'mytoolbox-report-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json');
    setStatus('Đã tạo báo cáo JSON. Hãy kiểm tra thư mục Tải xuống.');
    logOperation('export_report', 'Báo cáo phiên');
  }

  function clearPane(name) {
    var pane = state[name];
    pane.files.forEach(function (entry) {
      delete state.textCache[entry.id];
    });
    pane.files = []; pane.selectedId = null; pane.search = '';
    if (name === 'left') elements.leftSearch.value = ''; else elements.rightSearch.value = '';
    if (state.activePane === name) {
      state.activeTab = 'info'; state.lastValidation = null;
      if (!getSelected(name)) {
        var other = name === 'left' ? 'right' : 'left';
        if (getSelected(other)) state.activePane = other;
      }
    }
    renderAllPanes(); renderWorkspace(); setStatus('Đã xóa danh sách khung ' + paneLabel(name) + '. File gốc trên thiết bị không bị xóa.');
    logOperation('clear_panel', paneLabel(name));
  }

  function handleAction(action) {
    if (action === 'validate') validateCurrent();
    else if (action === 'format-json') formatJson();
    else if (action === 'save-text') saveEditedText();
    else if (action === 'export-original') exportOriginal();
    else if (action === 'hash') calculateSha256();
    else if (action === 'info') { state.activeTab = 'info'; renderWorkspace(); }
  }

  function addDropSupport(name, element) {
    element.addEventListener('dragover', function (event) { event.preventDefault(); element.classList.add('drag-over'); });
    element.addEventListener('dragleave', function () { element.classList.remove('drag-over'); });
    element.addEventListener('drop', function (event) {
      event.preventDefault(); element.classList.remove('drag-over');
      if (event.dataTransfer && event.dataTransfer.files) addFiles(name, event.dataTransfer.files);
    });
  }

  elements.leftPicker.addEventListener('change', function (event) { addFiles('left', event.target.files); event.target.value = ''; });
  elements.rightPicker.addEventListener('change', function (event) { addFiles('right', event.target.files); event.target.value = ''; });
  elements.leftList.addEventListener('click', function (event) {
    var button = event.target.closest('[data-file-id]'); if (button) selectFile(button.getAttribute('data-pane'), Number(button.getAttribute('data-file-id')));
  });
  elements.rightList.addEventListener('click', function (event) {
    var button = event.target.closest('[data-file-id]'); if (button) selectFile(button.getAttribute('data-pane'), Number(button.getAttribute('data-file-id')));
  });
  elements.leftSearch.addEventListener('input', function (event) { state.left.search = event.target.value; renderPane('left'); });
  elements.rightSearch.addEventListener('input', function (event) { state.right.search = event.target.value; renderPane('right'); });
  $('leftClear').addEventListener('click', function () { clearPane('left'); });
  $('rightClear').addEventListener('click', function () { clearPane('right'); });
  $('compareButton').addEventListener('click', compareSelected);
  $('reportButton').addEventListener('click', createReport);
  elements.tabStrip.addEventListener('click', function (event) {
    var button = event.target.closest('[data-tab]'); if (!button) return;
    state.activeTab = button.getAttribute('data-tab'); renderWorkspace();
  });
  elements.workbenchActions.addEventListener('click', function (event) {
    var button = event.target.closest('[data-action]'); if (button) handleAction(button.getAttribute('data-action'));
  });
  $('helpButton').addEventListener('click', function () { $('helpDialog').showModal(); });
  $('closeHelp').addEventListener('click', function () { $('helpDialog').close(); });
  $('helpOk').addEventListener('click', function () { $('helpDialog').close(); });
  addDropSupport('left', $('leftPane'));
  addDropSupport('right', $('rightPane'));

  renderAllPanes(); renderWorkspace();
})();
