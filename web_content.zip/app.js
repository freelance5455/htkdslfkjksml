const DB_KEY = "integrityReporterCasesV1";
const form = document.getElementById("reportForm");
const historyEl = document.getElementById("history");
const countEl = document.getElementById("caseCount");
const dialog = document.getElementById("detailDialog");
const detailBody = document.getElementById("detailBody");
const usernameInput = document.getElementById("username");
let cases = loadCases();
let installPrompt = null;

function loadCases(){ try { return JSON.parse(localStorage.getItem(DB_KEY) || "[]"); } catch { return []; } }
function persist(){ localStorage.setItem(DB_KEY, JSON.stringify(cases)); }
function safeText(value){ return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function prettyDate(value){ try { return new Date(value).toLocaleString(); } catch { return value; } }
function normalizeUsername(value){ return value.trim(); }
function render(){
  countEl.textContent = `${cases.length} ${cases.length === 1 ? "case" : "cases"}`;
  if(!cases.length){ historyEl.className="history-empty"; historyEl.textContent="Your saved drafts will appear here."; return; }
  historyEl.className="";
  historyEl.innerHTML = cases.slice().sort((a,b)=>b.createdAt-a.createdAt).map(item => `
    <article class="case">
      <div class="case-top"><div><h3>${safeText(item.username)}</h3><p>${safeText(item.issue)} · Saved ${safeText(prettyDate(item.createdAt))}</p></div><span class="status">DRAFT SAVED</span></div>
      <p>${safeText((item.details || "No details added").slice(0,180))}${(item.details||"").length>180?"…":""}</p>
      <div class="case-actions">
        <button class="secondary" data-action="view" data-id="${item.id}">View draft</button>
        <button class="secondary" data-action="copy" data-id="${item.id}">Copy report text</button>
        <button class="secondary" data-action="export" data-id="${item.id}">Export JSON</button>
        <button class="secondary" data-action="delete" data-id="${item.id}">Delete</button>
      </div>
    </article>`).join("");
}
function reportText(item){
  return `Good-faith TikTok integrity report draft\\n\\nUsername/profile: ${item.username}\\nSuspected issue: ${item.issue}\\nDate observed: ${item.observed || "Not specified"}\\nPublic content URL: ${item.profileUrl || "Not supplied"}\\nObservations: ${item.details || "No details supplied."}\\nEvidence files: ${(item.evidence||[]).map(f=>f.name).join(", ") || "None attached"}\\n\\nPlease review the publicly available information under TikTok's policies. This is a report draft, not a finding that a violation occurred.`;
}
function findCase(id){ return cases.find(x=>x.id===id); }
function viewCase(item){
  detailBody.innerHTML = `
    <div class="detail-row"><b>USERNAME / PROFILE</b>${safeText(item.username)}</div>
    <div class="detail-row"><b>SUSPECTED ISSUE</b>${safeText(item.issue)}</div>
    <div class="detail-row"><b>DATE OBSERVED</b>${safeText(item.observed || "Not specified")}</div>
    <div class="detail-row"><b>PUBLIC CONTENT URL</b>${safeText(item.profileUrl || "Not supplied")}</div>
    <div class="detail-row"><b>OBSERVATIONS</b>${safeText(item.details || "No details supplied.")}</div>
    <div class="detail-row"><b>EVIDENCE FILES</b>${(item.evidence||[]).map(f=>safeText(f.name)+" ("+Math.round(f.size/1024)+" KB)").join("<br>") || "None attached"}</div>
    <div class="detail-row"><b>RECORD STATUS</b>Draft saved locally. Not submitted to TikTok.</div>
    <div class="actions"><button class="primary" id="copyFromDialog" type="button">Copy report text</button></div>`;
  document.getElementById("copyFromDialog").onclick = () => copyText(reportText(item));
  dialog.showModal();
}
async function copyText(text){
  try { await navigator.clipboard.writeText(text); alert("Report text copied."); }
  catch { const ta=document.createElement("textarea"); ta.value=text; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); alert("Report text copied."); }
}
function downloadFile(name, content, type){
  const blob = new Blob([content], {type});
  const url = URL.createObjectURL(blob);
  const a=document.createElement("a"); a.href=url; a.download=name; a.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}
form.addEventListener("submit", async event => {
  event.preventDefault();
  const files = [...document.getElementById("evidence").files];
  const maxEach = 700 * 1024;
  if(files.some(f=>f.size>maxEach)){ alert("Please use evidence files under 700 KB each for this local prototype."); return; }
  const evidence = files.map(f=>({name:f.name,size:f.size,type:f.type,lastModified:f.lastModified}));
  const item = {
    id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())+Math.random().toString(16).slice(2)),
    username: normalizeUsername(document.getElementById("username").value),
    issue: document.getElementById("issue").value,
    observed: document.getElementById("observed").value,
    details: document.getElementById("details").value.trim(),
    profileUrl: document.getElementById("profileUrl").value.trim(),
    evidence,
    createdAt: Date.now()
  };
  // Store evidence contents locally as data URLs for this prototype.
  item.evidenceData = await Promise.all(files.map(file => new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve({name:file.name,dataUrl:reader.result});
    reader.onerror=()=>reject(reader.error);
    reader.readAsDataURL(file);
  })));
  cases.push(item);
  try { persist(); }
  catch { cases.pop(); alert("Browser storage is full. Export/delete older records or use smaller evidence files."); return; }
  localStorage.setItem("integrityReporterLastUsername", item.username);
  form.reset();
  usernameInput.value = item.username;
  render();
  alert("Draft saved on this device. It has not been sent to TikTok.");
});
document.getElementById("clearForm").addEventListener("click",()=>{form.reset();});
historyEl.addEventListener("click", async event=>{
  const button=event.target.closest("button[data-action]");
  if(!button) return;
  const item=findCase(button.dataset.id); if(!item) return;
  switch(button.dataset.action){
    case "view": viewCase(item); break;
    case "copy": await copyText(reportText(item)); break;
    case "export": downloadFile(`report-${item.id}.json`, JSON.stringify(item,null,2), "application/json"); break;
    case "delete":
      if(confirm("Delete this saved draft and its locally stored evidence?")){ cases=cases.filter(x=>x.id!==item.id); persist(); render(); }
      break;
  }
});
document.getElementById("closeDialog").addEventListener("click",()=>dialog.close());
const lastUsername=localStorage.getItem("integrityReporterLastUsername");
if(lastUsername) usernameInput.value=lastUsername;
render();

window.addEventListener("beforeinstallprompt", event=>{
  event.preventDefault(); installPrompt=event; document.getElementById("installBtn").classList.remove("hidden");
});
document.getElementById("installBtn").addEventListener("click",async()=>{
  if(!installPrompt) return;
  installPrompt.prompt(); await installPrompt.userChoice; installPrompt=null;
  document.getElementById("installBtn").classList.add("hidden");
});
if("serviceWorker" in navigator && location.protocol.startsWith("http")){
  window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
}
