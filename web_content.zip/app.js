const API = localStorage.getItem("ilostan_api") || "http://localhost:3000/api";
let vehicles=[], currentUser=null;

const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(t){const x=$("#toast");x.textContent=t;x.style.display="block";setTimeout(()=>x.style.display="none",2200)}
function getPhotos(id){return JSON.parse(localStorage.getItem("photos_"+id)||"[]")}
function savePhotos(id,photos){localStorage.setItem("photos_"+id,JSON.stringify(photos))}
function renderGallery(id){
  const photos=getPhotos(id);
  return `<div class="gallery">${photos.map((src,i)=>`<div class="gallery-item"><img src="${src}" alt="Zdjęcie pojazdu"><button class="delete-photo" data-photo="${i}" title="Usuń zdjęcie">×</button></div>`).join("")}</div>`;
}
async function addPhotos(id,files){
  const photos=getPhotos(id);
  for(const file of files){
    if(!file.type.startsWith("image/")) continue;
    const data=await new Promise((resolve,reject)=>{
      const r=new FileReader(); r.onload=()=>resolve(r.result); r.onerror=reject; r.readAsDataURL(file);
    });
    photos.push(data);
  }
  savePhotos(id,photos);
}
async function api(path,opt={}){try{const r=await fetch(API+path,{credentials:"include",...opt});if(!r.ok)throw new Error(await r.text());return await r.json()}catch(e){throw e}}
function view(id){document.querySelectorAll(".view").forEach(x=>x.classList.remove("active"));$("#"+id).classList.add("active");window.scrollTo(0,0);if(id==="vehicles")loadVehicles();if(id==="stats")loadStats();if(id==="account")renderAccount()}

document.addEventListener("click",e=>{const v=e.target.closest("[data-view]");if(v)view(v.dataset.view)});
$("#searchBtn").onclick=()=>loadVehicles($("#search").value.trim());
$("#search").onkeydown=e=>{if(e.key==="Enter")loadVehicles(e.target.value.trim())};
$("#addVehicleBtn").onclick=()=>renderAdd();

async function loadVehicles(q=""){
  $("#vehicleList").innerHTML='<div class="panel">Ładowanie…</div>';
  vehicles=JSON.parse(localStorage.getItem("ilostanVehicles")||"[]");
  if(!vehicles.length) vehicles=[
    {id:1,series:"EP09",number:"001",name:"EP09-001",type:"lokomotywa elektryczna",status:"czynny",carrier:"PKP Intercity"},
    {id:2,series:"EU07",number:"001",name:"EU07-001",type:"lokomotywa elektryczna",status:"czynny",carrier:"PKP Cargo"},
    {id:3,series:"SM42",number:"3001",name:"SM42-3001",type:"lokomotywa spalinowa",status:"odstawiony",carrier:"PKP Cargo"}
  ];
  if(q) vehicles=vehicles.filter(v=>JSON.stringify(v).toLowerCase().includes(q.toLowerCase()));
  $("#vehicleList").innerHTML=vehicles.length?vehicles.map(v=>`<article class="vehicle" data-id="${v.id}"><div class="photo">🚆</div><h3>${esc(v.name||((v.series||"")+" "+(v.number||"")))}</h3><span class="tag">${esc(v.type||"pojazd")}</span><p class="muted">${esc(v.status||"brak statusu")}</p></article>`).join(""):"<div class='panel'>Brak pojazdów.</div>";
  document.querySelectorAll(".vehicle[data-id]").forEach(x=>x.onclick=()=>loadVehicle(x.dataset.id));
}
async function loadVehicle(id){
  view("vehicle"); const v=vehicles.find(x=>String(x.id)===String(id));
  if(!v){$("#vehicleDetail").innerHTML="<div class='panel'>Nie znaleziono pojazdu.</div>";return}
  const comments=JSON.parse(localStorage.getItem("comments_"+id)||"[]");
  const photos=getPhotos(id);
  $("#vehicleDetail").innerHTML=`<div class="detail"><div><div class="detail-photo">${photos[0]?`<img src="${photos[0]}" alt="Zdjęcie pojazdu">`:"🚂"}</div>${renderGallery(id)}</div><div class="panel"><p class="eyebrow">POJAZD</p><h2>${esc(v.name||v.series+" "+v.number)}</h2><span class="tag">${esc(v.type||"")}</span><div class="meta"><div><small>Seria</small><strong>${esc(v.series||"-")}</strong></div><div><small>Numer</small><strong>${esc(v.number||"-")}</strong></div><div><small>Status</small><strong>${esc(v.status||"-")}</strong></div><div><small>Przewoźnik</small><strong>${esc(v.carrier||"-")}</strong></div></div><button id="photoBtn" class="primary">📷 Dodaj zdjęcia</button><input id="photoInput" type="file" accept="image/*" multiple hidden><p class="muted">Zdjęcia zapisują się lokalnie na tym urządzeniu.</p></div></div><div class="panel" style="margin-top:18px"><h3>Komentarze</h3><div id="comments">${comments.map(x=>`<div class="comment"><strong>Gość</strong><div>${esc(x)}</div></div>`).join("")||"<p class='muted'>Brak komentarzy.</p>"}</div><div class="form"><textarea id="commentText" placeholder="Dodaj komentarz"></textarea><button class="primary" id="commentBtn">Dodaj komentarz</button></div></div>`;
  $("#photoBtn").onclick=()=>$("#photoInput").click();
  $("#photoInput").onchange=async e=>{
    if(!e.target.files.length)return;
    await addPhotos(id,[...e.target.files]);
    toast("Zdjęcia dodane.");
    loadVehicle(id);
  };
  document.querySelectorAll(".delete-photo").forEach(btn=>btn.onclick=()=>{
    const p=getPhotos(id); p.splice(Number(btn.dataset.photo),1); savePhotos(id,p); loadVehicle(id);
  });
  $("#commentBtn").onclick=()=>{const text=$("#commentText").value.trim();if(!text)return;comments.push(text);localStorage.setItem("comments_"+id,JSON.stringify(comments));toast("Dodano komentarz.");loadVehicle(id)};
}
async function loadStats(){
  try{const s=await api("/stats");renderStats(s)}catch(e){renderStats({vehicles:vehicles.length,users:"—",comments:"—",photos:"—"})}
}
function renderStats(s){const localPhotos=vehicles.reduce((n,v)=>n+getPhotos(v.id).length,0);const data=[["Pojazdy",s.vehicles??s.totalVehicles??vehicles.length],["Użytkownicy","—"],["Komentarze",vehicles.reduce((n,v)=>n+JSON.parse(localStorage.getItem("comments_"+v.id)||"[]").length,0)],["Zdjęcia",localPhotos]];$("#statsCards").innerHTML=data.map(x=>`<div class="card"><strong>${esc(x[1])}</strong><span class="muted">${esc(x[0])}</span></div>`).join("");$("#homeStats").innerHTML=data.slice(0,3).map(x=>`<div class="card"><strong>${esc(x[1])}</strong><span class="muted">${esc(x[0])}</span></div>`).join("")}
function renderAccount(){
  $("#accountContent").innerHTML=`<div class="panel"><p class="eyebrow">TRYB GOŚCIA</p><h2>Ilostan bez kont</h2><p class="muted">Nie musisz się logować. Możesz przeglądać pojazdy i dodawać lokalne komentarze.</p><button class="primary" data-view="vehicles">Przejdź do pojazdów</button></div>`;
}
function renderAdd(){
 $("#vehicleDetail").innerHTML=`<div class="panel form"><button class="back" data-view="vehicles">← Wróć</button><h2>Dodaj pojazd</h2><input id="series" placeholder="Seria"><input id="number" placeholder="Numer"><input id="name" placeholder="Nazwa / oznaczenie"><input id="type" placeholder="Typ"><input id="status" placeholder="Status"><input id="carrier" placeholder="Przewoźnik"><button class="primary" id="saveVehicle">Zapisz pojazd</button></div>`;
 view("vehicle");
 $("#saveVehicle").onclick=()=>{const list=JSON.parse(localStorage.getItem("ilostanVehicles")||"[]");const body={id:Date.now(),series:$("#series").value,number:$("#number").value,name:$("#name").value,type:$("#type").value,status:$("#status").value,carrier:$("#carrier").value};list.push(body);localStorage.setItem("ilostanVehicles",JSON.stringify(list));toast("Pojazd zapisany na tym urządzeniu.");view("vehicles")};
}
(async()=>{try{currentUser=await api("/me")}catch(e){}loadVehicles();loadStats();renderAccount()})();