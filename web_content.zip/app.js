const services=["General Pest Control","Cockroach Control","Rodent Control","Termite Control","Mosquito Control","Fly Control","Ant Control","Bed Bug Control","Lizard Control","Spider Control","Disinfection","Pharma Pest Control","Hotel Pest Control","Restaurant Pest Control","Industrial Pest Control","Customized Pest Control"];
let role="admin", tasks=JSON.parse(localStorage.getItem("spc_tasks")||"[]");
const $=id=>document.getElementById(id);
$("serviceType").innerHTML=services.map(x=>`<option>${x}</option>`).join("");
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));b.classList.add("active");role=b.dataset.role});
$("loginBtn").onclick=login;
$("logout").onclick=()=>{ $("dashboard").classList.add("hidden"); $("login").classList.remove("hidden"); };
function login(){
 if(!navigator.onLine){$("loginMsg").textContent="Internet connection required.";return}
 const id=$("loginId").value.trim(), pass=$("password").value;
 if(role==="admin" && id==="admin" && pass==="admin123"){showDashboard("Admin");return}
 const emp=JSON.parse(localStorage.getItem("spc_employee")||"null");
 if(role==="employee" && emp && id===emp.login && pass===emp.pass){showDashboard(emp.name);return}
 $("loginMsg").textContent="Invalid Login ID or Password";
}
function showDashboard(name){
 $("login").classList.add("hidden");$("dashboard").classList.remove("hidden");
 $("welcome").textContent=`Welcome, ${name}`;$("roleBadge").textContent="  •  "+role.toUpperCase();
 $("adminPanel").classList.toggle("hidden",role!=="admin");render();
}
function render(){
 const visible=role==="admin"?tasks:tasks.filter(t=>t.employeeLogin===($("loginId").value||""));
 const done=visible.filter(t=>t.status==="DONE").length, nd=visible.filter(t=>t.status==="NOT DONE").length, pending=visible.length-done-nd;
 $("cards").innerHTML=[["Clients",new Set(visible.map(t=>t.client)).size],["Tasks",visible.length],["Done",done],["Not Done",nd],["Pending",pending]].map(x=>`<div class="card">${x[0]}<b>${x[1]}</b></div>`).join("");
 $("tasks").innerHTML=visible.length?visible.map((t,i)=>taskHtml(t,i)).join(""):"<p>No tasks available.</p>";
 document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>updateStatus(+b.dataset.i,b.dataset.action));
}
function taskHtml(t,i){
 return `<div class="task"><b>${t.client}</b><br>${t.address}<br>📞 ${t.mobile}<br>🛠 ${t.service}<br>📅 ${t.date} ⏰ ${t.time}<br>👷 ${t.employee}<br>
<span class="status ${t.status.toLowerCase().replace(" ","")}">Status: ${t.status}</span>
${t.map?`<br><a href="${t.map}" target="_blank">📍 Open Google Maps</a>`:""}
<br><button data-action="DONE" data-i="${i}" class="primary">✅ SERVICE DONE</button>
<button data-action="NOT DONE" data-i="${i}" class="danger">❌ SERVICE NOT DONE</button></div>`;
}
function updateStatus(i,status){
 tasks[i].status=status;tasks[i].updatedAt=new Date().toISOString();localStorage.setItem("spc_tasks",JSON.stringify(tasks));render();
}
$("createTask").onclick=()=>{
 const emp={name:$("empName").value,mobile:$("empMobile").value,login:$("empLogin").value,pass:$("empPass").value};
 if(!emp.name||!emp.login||!emp.pass||!$("clientName").value){$("adminMsg").textContent="Employee name, Login ID, Password and Client Name are required.";return}
 localStorage.setItem("spc_employee",JSON.stringify(emp));
 tasks.push({client:$("clientName").value,address:$("clientAddress").value,mobile:$("clientMobile").value,service:$("serviceType").value,date:$("serviceDate").value,time:$("serviceTime").value,map:$("mapLocation").value,employee:emp.name,employeeLogin:emp.login,status:"PENDING",createdAt:new Date().toISOString()});
 localStorage.setItem("spc_tasks",JSON.stringify(tasks));$("adminMsg").textContent="Employee account and task created successfully.";render();
};
window.addEventListener("offline",()=>{if(!$("dashboard").classList.contains("hidden")){alert("Internet connection lost. Application access requires internet.");location.reload()}});
