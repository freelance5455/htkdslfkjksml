(() => {
  "use strict";
  const $ = (s) => document.querySelector(s);
  const backdrop = $("#modalBackdrop"), modalTitle = $("#modalTitle"), modalKicker = $("#modalKicker"), modalBody = $("#modalBody");
  let toastTimer;
  const showToast = (message) => {
    const t = $("#toast"); t.textContent = message; t.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 3200);
  };
  const openModal = (title, kicker, html) => {
    modalTitle.textContent = title; modalKicker.textContent = kicker; modalBody.innerHTML = html;
    backdrop.hidden = false; document.body.style.overflow = "hidden";
  };
  const closeModal = () => { backdrop.hidden = true; document.body.style.overflow = ""; };
  $("#modalClose").addEventListener("click", closeModal);
  backdrop.addEventListener("click", e => { if (e.target === backdrop) closeModal(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

  const readProfile = () => {
    try { return localStorage.getItem("cubelyra-profile") || "Local profile"; } catch { return "Local profile"; }
  };
  $("#profileSummary").textContent = readProfile();

  function navigate(page) {
    document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.page === page));
    if (page === "home") { window.scrollTo({top:0,behavior:"smooth"}); return; }
    if (page === "versions") {
      openModal("Game versions", "VERSION MANAGER", `<p>This prototype does not download or install Minecraft versions yet.</p><p>Once connected to a compatible, authorized Java launcher, choose and manage versions there.</p><button class="save-button" id="versionInfoButton">Got it</button>`);
      $("#versionInfoButton").onclick = closeModal; return;
    }
    if (page === "mods") {
      openModal("Mods & packs", "EXTENSIONS", `<p>Mod, shader, and resource-pack management is not connected in this prototype.</p><ul><li>Mod loader support: pending</li><li>Resource packs: pending</li><li>Shaders: pending</li></ul><p>Only install mods from sources you trust and that match your Minecraft version.</p><button class="save-button" id="modsOk">Close</button>`);
      $("#modsOk").onclick = closeModal; return;
    }
    if (page === "settings") {
      let reduce = false; try { reduce = localStorage.getItem("cubelyra-reduce-motion") === "true"; } catch {}
      openModal("Settings", "PREFERENCES", `<label for="profileName">Local profile label</label><input id="profileName" maxlength="32" value="${escapeHtml(readProfile())}" placeholder="Player name"><label for="motion">Animation preference</label><select id="motion"><option value="false" ${!reduce?"selected":""}>Ambient animation on</option><option value="true" ${reduce?"selected":""}>Reduced motion preference</option></select><p>These are local interface preferences only. No Microsoft credentials are requested or stored.</p><button class="save-button" id="saveSettings">Save settings</button>`);
      $("#saveSettings").onclick = () => {
        const name = ($("#profileName").value.trim() || "Local profile").slice(0,32);
        try { localStorage.setItem("cubelyra-profile", name); localStorage.setItem("cubelyra-reduce-motion", $("#motion").value); } catch {}
        $("#profileSummary").textContent = name; closeModal(); showToast("Preferences saved on this device.");
      }; return;
    }
  }
  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  document.querySelectorAll("[data-page]").forEach(b => b.addEventListener("click", () => navigate(b.dataset.page)));
  $("#profileButton").addEventListener("click", () => navigate("profile"));
  // Profile opens the same safe local settings panel.
  document.querySelectorAll('[data-page="profile"]').forEach(b => b.addEventListener("click", () => navigate("settings")));

  $("#playButton").addEventListener("click", () => {
    openModal("Java launcher required", "PLAY JAVA", `<p><strong>Cubelyra's web prototype cannot run Minecraft Java by itself.</strong></p><p>Install and configure a reputable Android-compatible Java launcher separately, sign in through its authorized account flow, and install the game files there.</p><p>This APK wrapper cannot reliably start another Android app unless the converter adds a native Android bridge. The button is intentionally honest instead of pretending the game launched.</p><button class="save-button" id="playGotIt">Understood</button>`);
    $("#playGotIt").onclick = closeModal;
  });
  $("#versionButton").addEventListener("click", () => {
    const current = $("#versionName").textContent;
    $("#versionName").textContent = current === "Latest compatible" ? "Stable release (demo)" : "Latest compatible";
    showToast("Display changed only. Game version is not installed or changed.");
  });
  $("#launcherInfo").addEventListener("click", () => {
    openModal("Java launcher information", "EXTERNAL INTEGRATION", `<p>This is a web-based UI prototype. It does not include a Java runtime or game files.</p><p>For real Minecraft Java gameplay on Android, use a reputable compatible launcher, obtain the game through an authorized account, and follow that launcher's documentation.</p><button class="save-button" id="infoClose">Close</button>`);
    $("#infoClose").onclick = closeModal;
  });
  $("#officialSite").addEventListener("click", () => window.open("https://www.minecraft.net/", "_blank", "noopener,noreferrer"));
  // PWA install support when the hosting environment supports it.
  let deferredPrompt;
  window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferredPrompt = e; });
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    navigator.serviceWorker.register("./service-worker.js").catch(() => {});
  }
})();