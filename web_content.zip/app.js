/* ===== app.js — منطق منصة دَرْب ===== */
(() => {
  "use strict";

  /* ---------- أيقونات SVG ---------- */
  const P = {
    sigma: '<path d="M18 7V4H6l6 8-6 8h12v-3"/>',
    atom: '<circle cx="12" cy="12" r="1"/><path d="M20.2 20.2c2-2-.5-7.8-5.6-12.9S4.4 1.8 2.4 3.8s.5 7.8 5.6 12.9 10.2 5.5 12.2 3.5Z"/><path d="M15.7 15.7c5.1-5.1 7.6-10.9 5.6-12.9s-7.8.5-12.9 5.6-7.6 10.9-5.6 12.9 7.8-.5 12.9-5.6Z"/>',
    flask: '<path d="M10 2v7.5L4.2 19A2 2 0 0 0 6 22h12a2 2 0 0 0 1.8-3L14 9.5V2"/><path d="M8.5 2h7M7 16h10"/>',
    leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10Z"/><path d="M2 21c0-3 1.9-5.4 5.2-6.1C9.6 14.4 12 13 13 12"/>',
    book: '<path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/>',
    globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20M2 12h20"/>',
    code: '<path d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>',
    landmark: '<path d="M3 22h18M6 18v-7M10 18v-7M14 18v-7M18 18v-7M12 2l8 5H4Z"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    layers: '<path d="m12 2 10 5-10 5L2 7Z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
    pen: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    chart: '<path d="M3 3v18h18"/><path d="M18 17V9M13 17V5M8 17v-3"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M6.3 17.7l-1.4 1.4M19.1 4.9l-1.4 1.4"/>',
    moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    arrow: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
    play: '<path d="m6 3 14 9-14 9Z"/>',
    pause: '<path d="M6 4h4v16H6zM14 4h4v16h-4z"/>',
    reset: '<path d="M3 12a9 9 0 1 0 9-9 9.7 9.7 0 0 0-6.7 2.7L3 8"/><path d="M3 3v5h5"/>',
    shuffle: '<path d="M2 18h1.4c1.3 0 2.5-.6 3.3-1.7l6.1-8.6c.7-1.1 2-1.7 3.3-1.7H22"/><path d="m18 2 4 4-4 4M2 6h1.9c1.5 0 2.9.9 3.6 2.2M22 18h-5.9c-1.3 0-2.6-.7-3.3-1.8l-.5-.8"/><path d="m18 14 4 4-4 4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    flame: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.4-.5-2-1-3-1.1-2.1-.2-4 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.2.4-2.3 1-3.3.4 1.4 1.4 2.8 2.5 2.8Z"/>',
    bulb: '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5M9 18h6M10 22h4"/>'
  };
  const icon = (n, s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n] || ""}</svg>`;

  /* ---------- تخزين في الذاكرة (نسخة المعاينة) ---------- */
  const mem = {};
  const store = {
    get(k, d) { return k in mem ? mem[k] : d; },
    set(k, v) { mem[k] = v; }
  };

  const state = {
    done: store.get("done", []),
    best: store.get("best", {}),
    notes: store.get("notes", []),
    tasks: store.get("tasks", {}),
    focusMin: store.get("focusMin", 0),
    activity: store.get("activity", {}),
    known: store.get("known", {})
  };
  const save = (k) => store.set(k, state[k]);
  const today = () => new Date().toISOString().slice(0, 10);
  const logActivity = () => { const d = today(); state.activity[d] = (state.activity[d] || 0) + 1; save("activity"); };

  /* ---------- أدوات ---------- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const ar = (n) => Number(n).toLocaleString("ar-EG");
  const main = $("#main");
  const allLessons = SUBJECTS.flatMap((s) => s.units.flatMap((u) => u.lessons.map((l) => ({ ...l, subject: s, unit: u.title }))));
  const subjectLessons = (s) => s.units.flatMap((u) => u.lessons);
  const subjectPct = (s) => { const ls = subjectLessons(s); return Math.round((ls.filter((l) => state.done.includes(l.id)).length / ls.length) * 100); };
  const streak = () => { let n = 0; const d = new Date(); for (;;) { const k = d.toISOString().slice(0, 10); if (state.activity[k]) { n++; d.setDate(d.getDate() - 1); } else break; } return n; };

  let toastT;
  const toast = (msg) => { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 2400); };

  /* ---------- التوجيه (داخل الذاكرة) ---------- */
  const routes = {};
  let current = { view: "home", arg: null };
  function go(view, arg = null) {
    current = { view, arg };
    (routes[view] || routes.home)(arg);
    const top = { subject: "subjects", lesson: "subjects" }[view] || view;
    $$(".nav__link").forEach((b) => b.dataset.go === top ? b.setAttribute("aria-current", "page") : b.removeAttribute("aria-current"));
    $("#nav").classList.remove("open"); $("#menuToggle").setAttribute("aria-expanded", "false");
    window.scrollTo(0, 0);
    main.focus({ preventScroll: true });
  }
  document.addEventListener("click", (e) => {
    const el = e.target.closest("[data-go]");
    if (el) { e.preventDefault(); go(el.dataset.go, el.dataset.arg || null); }
  });

  const subjectCard = (s) => `
    <button class="subject" style="--c:${s.color}" data-go="subject" data-arg="${s.id}">
      <span class="subject__icon">${icon(s.icon, 26)}</span>
      <h3>${s.name}</h3>
      <p>${s.desc}</p>
      <div class="bar"><i style="width:${subjectPct(s)}%"></i></div>
      <div class="meta"><span>${ar(subjectLessons(s).length)} دروس · ${ar(s.quiz.length)} أسئلة</span><span>${ar(subjectPct(s))}٪</span></div>
    </button>`;

  /* ---------- الرئيسية ---------- */
  routes.home = () => {
    const tip = TIPS[new Date().getDate() % TIPS.length];
    main.innerHTML = `
      <section class="hero">
        <div class="wrap hero__grid">
          <div class="reveal">
            <span class="eyebrow">${icon("flame", 16)} سلسلة ${ar(streak())} يوم متواصل</span>
            <h1>ذاكِر بذكاء، <span>وتقدّم كل يوم</span></h1>
            <p class="lead">دروس مختصرة، واختبارات فورية، وبطاقات مراجعة، ومؤقت تركيز، ومخطط أسبوعي — كل ما تحتاجه للدراسة في مكان واحد.</p>
            <div class="row">
              <button class="btn btn--primary" data-go="subjects">ابدأ التعلم ${icon("arrow", 18)}</button>
              <button class="btn btn--ghost" data-go="quiz">اختبر نفسك</button>
            </div>
            <div class="stats stagger">
              <div class="stat"><b>${ar(SUBJECTS.length)}</b><span>مواد دراسية</span></div>
              <div class="stat"><b>${ar(allLessons.length)}</b><span>درساً</span></div>
              <div class="stat"><b>${ar(SUBJECTS.reduce((a, s) => a + s.quiz.length, 0))}</b><span>سؤالاً</span></div>
              <div class="stat"><b>${ar(state.done.length)}</b><span>درساً أنجزته</span></div>
            </div>
          </div>
          <div class="hero__visual" aria-hidden="true">
            <div class="orbit"></div><div class="orbit orbit--2"></div><div class="orbit orbit--3">دَرْب</div>
            <div class="chip-float" style="top:6%;inset-inline-start:2%">${icon("sigma", 18)} رياضيات</div>
            <div class="chip-float" style="top:46%;inset-inline-end:-4%">${icon("atom", 18)} فيزياء</div>
            <div class="chip-float" style="bottom:6%;inset-inline-start:12%">${icon("code", 18)} برمجة</div>
          </div>
        </div>
      </section>

      <section class="section">
        <div class="wrap">
          <div class="row" style="justify-content:space-between;margin-bottom:var(--s5)">
            <div><h2>المواد الدراسية</h2><p class="muted" style="margin:0">اختر مادة وابدأ من أول درس.</p></div>
            <button class="btn btn--ghost btn--sm" data-go="subjects">عرض الكل</button>
          </div>
          <div class="grid grid--4 stagger">${SUBJECTS.map(subjectCard).join("")}</div>
        </div>
      </section>

      <section class="section">
        <div class="wrap">
          <h2 style="margin-bottom:var(--s5)">أدوات تساعدك على الإنجاز</h2>
          <div class="grid grid--3 stagger">
            ${[["target", "اختبارات فورية", "أسئلة اختيار من متعدد مع شرح لكل إجابة وحفظ لأفضل نتيجة.", "quiz"],
               ["layers", "بطاقات المراجعة", "اقلب البطاقة لتتذكر القوانين والمفاهيم، وعلّم ما حفظته.", "cards"],
               ["clock", "مؤقت التركيز", "جلسات بومودورو 25 دقيقة مع استراحات تلقائية.", "focus"],
               ["calendar", "المخطط الأسبوعي", "وزّع مهامك على أيام الأسبوع وتابع ما أنجزته.", "planner"],
               ["pen", "الملاحظات", "دوّن ملخصاتك واحفظها تلقائياً على جهازك.", "notes"],
               ["chart", "لوحة التقدم", "نسب الإنجاز لكل مادة وخريطة نشاطك اليومي.", "progress"]]
              .map(([i, t, d, g]) => `<button class="card feature" data-go="${g}" style="text-align:start"><span class="feature__icon">${icon(i)}</span><span><h3>${t}</h3><p>${d}</p></span></button>`).join("")}
          </div>
        </div>
      </section>

      <section class="section">
        <div class="wrap">
          <div class="tip">
            ${icon("bulb", 40)}
            <p>${tip}</p>
            <button class="btn btn--ghost" data-go="focus" style="margin-inline-start:auto">ابدأ جلسة تركيز</button>
          </div>
        </div>
      </section>`;
  };

  /* ---------- المواد ---------- */
  routes.subjects = () => {
    main.innerHTML = `
      <div class="wrap page-head reveal"><span class="eyebrow">${icon("book", 16)} المكتبة</span><h1>كل المواد</h1><p class="lead">${ar(allLessons.length)} درساً موزعة على ${ar(SUBJECTS.length)} مواد.</p></div>
      <div class="wrap"><div class="grid grid--4 stagger">${SUBJECTS.map(subjectCard).join("")}</div></div>`;
  };

  routes.subject = (id) => {
    const s = SUBJECTS.find((x) => x.id === id) || SUBJECTS[0];
    let n = 0;
    main.innerHTML = `
      <div class="wrap page-head reveal">
        <div class="crumbs"><button data-go="subjects">المواد</button> / <span>${s.name}</span></div>
        <h1>${s.name}</h1><p class="lead">${s.desc}</p>
        <div style="max-width:420px"><div class="bar"><i style="width:${subjectPct(s)}%"></i></div><div class="meta" style="margin-top:6px"><span>نسبة الإنجاز</span><span>${ar(subjectPct(s))}٪</span></div></div>
        <div class="row" style="margin-top:var(--s5)">
          <button class="btn btn--primary" data-go="quiz" data-arg="${s.id}">${icon("target", 18)} اختبار ${s.name}</button>
          <button class="btn btn--ghost" data-go="cards" data-arg="${s.id}">${icon("layers", 18)} بطاقات المراجعة</button>
        </div>
      </div>
      <div class="wrap">
        ${s.units.map((u) => `
          <div class="unit">
            <h2 class="unit__title">${u.title} <span>${ar(u.lessons.length)} دروس</span></h2>
            <div class="stagger">${u.lessons.map((l) => { n++; const d = state.done.includes(l.id); return `
              <button class="lesson-row ${d ? "done" : ""}" data-go="lesson" data-arg="${l.id}">
                <span class="lesson-row__num">${d ? icon("check", 18) : ar(n)}</span>
                <span class="lesson-row__body"><b>${l.title}</b><br><small>${ar(l.minutes)} دقيقة قراءة${d ? " · مكتمل" : ""}</small></span>
                ${icon("arrow", 18)}
              </button>`; }).join("")}</div>
          </div>`).join("")}
      </div>`;
  };

  routes.lesson = (id) => {
    const l = allLessons.find((x) => x.id === id);
    if (!l) return go("subjects");
    const s = l.subject; const list = subjectLessons(s); const i = list.findIndex((x) => x.id === id);
    const prev = list[i - 1], next = list[i + 1]; const done = state.done.includes(id);
    main.innerHTML = `
      <div class="wrap page-head reveal">
        <div class="crumbs"><button data-go="subjects">المواد</button> / <button data-go="subject" data-arg="${s.id}">${s.name}</button> / <span>${l.unit}</span></div>
        <h1>${l.title}</h1>
        <p class="muted">${icon("clock", 16)} ${ar(l.minutes)} دقيقة · الدرس ${ar(i + 1)} من ${ar(list.length)}</p>
      </div>
      <div class="wrap lesson">
        <article class="lesson__content reveal">
          <p>${esc(l.body)}</p>
          <h2>النقاط الأساسية</h2>
          <ul class="keypoints">${l.points.map((p) => `<li>${icon("check", 18)}<span>${esc(p)}</span></li>`).join("")}</ul>
          <div class="example"><b>مثال</b><pre>${esc(l.example)}</pre></div>
          <div class="row">
            ${prev ? `<button class="btn btn--ghost" data-go="lesson" data-arg="${prev.id}">الدرس السابق</button>` : ""}
            ${next ? `<button class="btn btn--ghost" data-go="lesson" data-arg="${next.id}">الدرس التالي</button>` : `<button class="btn btn--ghost" data-go="quiz" data-arg="${s.id}">انتقل إلى الاختبار</button>`}
          </div>
        </article>
        <aside class="aside">
          <div class="card">
            <h3>حالة الدرس</h3>
            <p class="muted" style="font-size:var(--text-sm)">${done ? "أنهيت هذا الدرس. أحسنت." : "علّم الدرس مكتملاً بعد فهمه."}</p>
            <button class="btn ${done ? "btn--ghost" : "btn--primary"}" id="toggleDone" style="width:100%">${done ? "إلغاء الإكمال" : icon("check", 18) + " تعليم كمكتمل"}</button>
          </div>
          <div class="card">
            <h3>ملاحظة سريعة</h3>
            <label for="quickNote" class="sr">ملاحظة على الدرس</label>
            <textarea class="field" id="quickNote" rows="4" placeholder="اكتب ملخصك هنا…" style="width:100%"></textarea>
            <button class="btn btn--ghost btn--sm" id="saveQuick" style="margin-top:var(--s3)">حفظ في الملاحظات</button>
          </div>
        </aside>
      </div>`;
    $("#toggleDone").onclick = () => {
      if (state.done.includes(id)) state.done = state.done.filter((x) => x !== id);
      else { state.done.push(id); logActivity(); toast("رائع، تم تسجيل الدرس مكتملاً"); }
      save("done"); routes.lesson(id);
    };
    $("#saveQuick").onclick = () => {
      const t = $("#quickNote").value.trim(); if (!t) return toast("اكتب شيئاً أولاً");
      state.notes.unshift({ id: Date.now(), title: l.title, body: t, at: Date.now() }); save("notes");
      $("#quickNote").value = ""; toast("حُفظت الملاحظة");
    };
  };

  /* ---------- الاختبارات ---------- */
  routes.quiz = (id) => {
    if (!id) {
      main.innerHTML = `
        <div class="wrap page-head reveal"><span class="eyebrow">${icon("target", 16)} الاختبارات</span><h1>اختر اختباراً</h1><p class="lead">أسئلة مرتبة عشوائياً مع شرح فوري لكل إجابة.</p></div>
        <div class="wrap"><div class="grid grid--4 stagger">${SUBJECTS.map((s) => `
          <button class="subject" style="--c:${s.color}" data-go="quiz" data-arg="${s.id}">
            <span class="subject__icon">${icon(s.icon, 26)}</span><h3>${s.name}</h3>
            <p>${ar(s.quiz.length)} أسئلة</p>
            <div class="meta"><span>أفضل نتيجة</span><span>${s.id in state.best ? ar(state.best[s.id]) + "٪" : "—"}</span></div>
          </button>`).join("")}</div></div>`;
      return;
    }
    const s = SUBJECTS.find((x) => x.id === id);
    const qs = [...s.quiz].sort(() => Math.random() - 0.5);
    let i = 0, score = 0; const log = [];
    const keys = ["أ", "ب", "ج", "د"];
    const render = () => {
      const q = qs[i];
      main.innerHTML = `
        <div class="wrap page-head"><div class="crumbs"><button data-go="quiz">الاختبارات</button> / <span>${s.name}</span></div></div>
        <div class="wrap"><div class="quiz card reveal">
          <div class="quiz__top"><span>السؤال ${ar(i + 1)} من ${ar(qs.length)}</span><span>النتيجة: ${ar(score)}</span></div>
          <div class="bar" style="margin-bottom:var(--s5)"><i style="width:${(i / qs.length) * 100}%"></i></div>
          <p class="quiz__q">${esc(q.q)}</p>
          <div class="options">${q.a.map((a, k) => `<button class="option" data-k="${k}"><span class="option__key">${keys[k]}</span><span><bdi>${esc(a)}</bdi></span></button>`).join("")}</div>
          <div id="after"></div>
        </div></div>`;
      $$(".option").forEach((b) => b.onclick = () => {
        const k = +b.dataset.k; const ok = k === q.c; if (ok) score++;
        log.push({ q: q.q, ok, right: q.a[q.c] });
        $$(".option").forEach((o) => { o.disabled = true; if (+o.dataset.k === q.c) o.classList.add("correct"); });
        if (!ok) b.classList.add("wrong");
        $("#after").innerHTML = `<div class="explain"><b>${ok ? "إجابة صحيحة." : "إجابة غير صحيحة."}</b> ${esc(q.e)}</div>
          <div class="row" style="margin-top:var(--s4);justify-content:flex-end"><button class="btn btn--primary" id="nextQ">${i + 1 < qs.length ? "السؤال التالي" : "عرض النتيجة"}</button></div>`;
        $("#nextQ").focus();
        $("#nextQ").onclick = () => { i++; i < qs.length ? render() : finish(); };
      });
    };
    const finish = () => {
      const pct = Math.round((score / qs.length) * 100);
      const prevBest = state.best[id] ?? -1;
      if (pct > prevBest) { state.best[id] = pct; save("best"); }
      logActivity();
      const C = 2 * Math.PI * 70;
      main.innerHTML = `
        <div class="wrap page-head"><div class="crumbs"><button data-go="quiz">الاختبارات</button> / <span>${s.name}</span></div></div>
        <div class="wrap"><div class="quiz card reveal" style="text-align:center">
          <div class="score-ring"><svg width="160" height="160" viewBox="0 0 160 160"><circle cx="80" cy="80" r="70" stroke="var(--surface-2)" stroke-width="12" fill="none"/><circle cx="80" cy="80" r="70" stroke="${pct >= 60 ? "var(--primary)" : "var(--accent)"}" stroke-width="12" fill="none" stroke-linecap="round" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - pct / 100)}"/></svg><b>${ar(pct)}٪</b></div>
          <h2>${pct >= 80 ? "ممتاز، أداء رائع" : pct >= 60 ? "جيد، استمر" : "تحتاج إلى مراجعة"}</h2>
          <p class="muted">أجبت عن ${ar(score)} من ${ar(qs.length)} إجابة صحيحة${pct > prevBest && prevBest >= 0 ? " — رقم قياسي جديد" : ""}.</p>
          <div class="row" style="justify-content:center">
            <button class="btn btn--primary" data-go="quiz" data-arg="${id}">${icon("reset", 18)} أعد المحاولة</button>
            <button class="btn btn--ghost" data-go="subject" data-arg="${id}">راجع الدروس</button>
          </div>
          <div class="review" style="text-align:start">${log.map((r) => `<div class="${r.ok ? "ok" : "no"}"><b>${esc(r.q)}</b><br><span class="muted">الإجابة الصحيحة: <bdi>${esc(r.right)}</bdi></span></div>`).join("")}</div>
        </div></div>`;
    };
    render();
  };

  /* ---------- البطاقات ---------- */
  routes.cards = (id) => {
    const sid = id || SUBJECTS[0].id;
    const s = SUBJECTS.find((x) => x.id === sid);
    let deck = [...s.cards], i = 0;
    const known = () => state.known[sid] || [];
    const render = () => {
      const c = deck[i]; const isKnown = known().includes(c.f);
      main.innerHTML = `
        <div class="wrap page-head reveal"><span class="eyebrow">${icon("layers", 16)} بطاقات المراجعة</span><h1>راجع ${s.name}</h1><p class="lead">اضغط على البطاقة لقلبها، أو استخدم مفتاح المسافة.</p></div>
        <div class="wrap">
          <div class="tabs" role="group" aria-label="اختر المادة">${SUBJECTS.map((x) => `<button class="tab" aria-pressed="${x.id === sid}" data-go="cards" data-arg="${x.id}">${x.name}</button>`).join("")}</div>
          <div class="flash-wrap">
            <div class="meta" style="margin-bottom:var(--s3)"><span>البطاقة ${ar(i + 1)} من ${ar(deck.length)}</span><span>حفظت ${ar(known().length)} من ${ar(s.cards.length)}</span></div>
            <button class="flash" id="flash" aria-label="اقلب البطاقة">
              <span class="flash__face flash__face--front">${esc(c.f)}<small>${isKnown ? "محفوظة" : "اضغط للقلب"}</small></span>
              <span class="flash__face flash__face--back"><bdi>${esc(c.b)}</bdi></span>
            </button>
            <div class="flash-ctrl">
              <button class="btn btn--ghost" id="prevC" ${i === 0 ? "disabled" : ""}>السابقة</button>
              <button class="btn ${isKnown ? "btn--ghost" : "btn--accent"}" id="knowC">${isKnown ? "إلغاء الحفظ" : icon("check", 18) + " حفظتها"}</button>
              <button class="btn btn--ghost" id="nextC" ${i === deck.length - 1 ? "disabled" : ""}>التالية</button>
              <button class="icon-btn" id="shufC" aria-label="خلط البطاقات">${icon("shuffle", 18)}</button>
            </div>
          </div>
        </div>`;
      const f = $("#flash"); f.onclick = () => f.classList.toggle("flipped");
      $("#prevC").onclick = () => { i--; render(); };
      $("#nextC").onclick = () => { i++; render(); };
      $("#shufC").onclick = () => { deck.sort(() => Math.random() - .5); i = 0; render(); toast("تم خلط البطاقات"); };
      $("#knowC").onclick = () => {
        const k = known(); state.known[sid] = k.includes(c.f) ? k.filter((x) => x !== c.f) : [...k, c.f];
        save("known"); if (!k.includes(c.f)) logActivity();
        if (i < deck.length - 1 && !k.includes(c.f)) i++; render();
      };
    };
    render();
  };
  document.addEventListener("keydown", (e) => {
    if (current.view !== "cards" || /INPUT|TEXTAREA/.test(document.activeElement.tagName)) return;
    if (e.code === "Space" && $("#flash")) { e.preventDefault(); $("#flash").classList.toggle("flipped"); }
    if (e.key === "ArrowLeft" && $("#nextC") && !$("#nextC").disabled) $("#nextC").click();
    if (e.key === "ArrowRight" && $("#prevC") && !$("#prevC").disabled) $("#prevC").click();
  });

  /* ---------- مؤقت التركيز ---------- */
  const T = { mode: "focus", total: 25 * 60, left: 25 * 60, running: false, id: null, sessions: store.get("sessionsToday", { d: today(), n: 0 }) };
  if (T.sessions.d !== today()) T.sessions = { d: today(), n: 0 };
  const MODES = { focus: [25, "جلسة تركيز"], short: [5, "استراحة قصيرة"], long: [15, "استراحة طويلة"] };
  const fmt = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  const setMode = (m) => { T.mode = m; T.total = T.left = MODES[m][0] * 60; stopT(); paintT(); };
  const stopT = () => { T.running = false; clearInterval(T.id); };
  const beep = () => { try { const a = new (window.AudioContext || window.webkitAudioContext)(); const o = a.createOscillator(); const g = a.createGain(); o.connect(g); g.connect(a.destination); o.frequency.value = 660; g.gain.setValueAtTime(.2, a.currentTime); g.gain.exponentialRampToValueAtTime(.001, a.currentTime + 1); o.start(); o.stop(a.currentTime + 1); } catch {} };
  const tick = () => {
    T.left--;
    if (T.left <= 0) {
      stopT(); beep();
      if (T.mode === "focus") {
        state.focusMin += MODES.focus[0]; save("focusMin"); logActivity();
        T.sessions.n++; store.set("sessionsToday", T.sessions);
        toast("أحسنت، انتهت جلسة التركيز. خذ استراحة");
        setMode(T.sessions.n % 4 === 0 ? "long" : "short");
      } else { toast("انتهت الاستراحة، لنعد إلى التركيز"); setMode("focus"); }
      return;
    }
    paintT();
  };
  const paintT = () => {
    document.title = T.running ? `${fmt(T.left)} — دَرْب` : "دَرْب — منصتك الدراسية";
    if (current.view !== "focus") return;
    const C = 2 * Math.PI * 140;
    $("#tTime").textContent = fmt(T.left);
    $("#tProg").style.strokeDashoffset = C * (1 - T.left / T.total);
    $("#tPlay").innerHTML = T.running ? icon("pause", 18) + " إيقاف مؤقت" : icon("play", 18) + " ابدأ";
    $(".timer").classList.toggle("break", T.mode !== "focus");
    $("#tLabel").textContent = MODES[T.mode][1];
    $$("[data-mode]").forEach((b) => b.setAttribute("aria-pressed", b.dataset.mode === T.mode));
  };
  routes.focus = () => {
    const C = 2 * Math.PI * 140;
    main.innerHTML = `
      <div class="wrap page-head reveal"><span class="eyebrow">${icon("clock", 16)} مؤقت التركيز</span><h1>ركّز بلا مشتتات</h1><p class="lead">تقنية بومودورو: 25 دقيقة تركيز ثم 5 دقائق راحة، واستراحة طويلة بعد كل 4 جلسات.</p></div>
      <div class="wrap timer">
        <div class="timer__ring">
          <svg viewBox="0 0 300 300"><circle class="timer__track" cx="150" cy="150" r="140"/><circle class="timer__prog" id="tProg" cx="150" cy="150" r="140" stroke-dasharray="${C}" stroke-dashoffset="0"/></svg>
          <div class="timer__time"><b id="tTime">25:00</b><span id="tLabel">جلسة تركيز</span></div>
        </div>
        <div class="card">
          <div class="tabs" role="group" aria-label="نوع الجلسة">${Object.entries(MODES).map(([k, [m, n]]) => `<button class="tab" data-mode="${k}" aria-pressed="false">${n} · ${ar(m)} د</button>`).join("")}</div>
          <div class="row" style="margin-bottom:var(--s5)">
            <button class="btn btn--primary" id="tPlay"></button>
            <button class="btn btn--ghost" id="tReset">${icon("reset", 18)} إعادة</button>
          </div>
          <div class="grid" style="grid-template-columns:1fr 1fr">
            <div class="stat"><b>${ar(T.sessions.n)}</b><span>جلسات اليوم</span></div>
            <div class="stat"><b>${ar(state.focusMin)}</b><span>دقيقة تركيز إجمالاً</span></div>
          </div>
        </div>
      </div>`;
    $$("[data-mode]").forEach((b) => b.onclick = () => setMode(b.dataset.mode));
    $("#tPlay").onclick = () => { if (T.running) stopT(); else { T.running = true; T.id = setInterval(tick, 1000); } paintT(); };
    $("#tReset").onclick = () => setMode(T.mode);
    paintT();
  };

  /* ---------- المخطط الأسبوعي ---------- */
  const DAYS = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];
  routes.planner = () => {
    const td = new Date().getDay();
    const total = Object.values(state.tasks).flat().length;
    const doneN = Object.values(state.tasks).flat().filter((t) => t.done).length;
    main.innerHTML = `
      <div class="wrap page-head reveal"><span class="eyebrow">${icon("calendar", 16)} المخطط</span><h1>خطة الأسبوع</h1><p class="lead">أنجزت ${ar(doneN)} من ${ar(total)} مهمة هذا الأسبوع.</p></div>
      <div class="wrap">
        <form class="form-row" id="taskForm">
          <label for="taskText" class="sr">المهمة</label>
          <input class="field" id="taskText" placeholder="مثال: حل تمارين المعادلات التربيعية" style="flex:1 1 260px" required>
          <label for="taskDay" class="sr">اليوم</label>
          <select class="field" id="taskDay">${DAYS.map((d, k) => `<option value="${k}" ${k === td ? "selected" : ""}>${d}</option>`).join("")}</select>
          <label for="taskSub" class="sr">المادة</label>
          <select class="field" id="taskSub"><option value="">بدون مادة</option>${SUBJECTS.map((s) => `<option value="${s.name}">${s.name}</option>`).join("")}</select>
          <button class="btn btn--primary">${icon("plus", 18)} إضافة</button>
        </form>
        <div class="week">${DAYS.map((d, k) => { const ts = state.tasks[k] || []; return `
          <div class="day ${k === td ? "today" : ""}">
            <h3>${d}<span class="muted">${ar(ts.filter((t) => t.done).length)}/${ar(ts.length)}</span></h3>
            ${ts.length ? ts.map((t) => `<label class="task ${t.done ? "done" : ""}"><input type="checkbox" data-day="${k}" data-id="${t.id}" ${t.done ? "checked" : ""}><span>${esc(t.t)}${t.s ? `<br><small class="muted">${esc(t.s)}</small>` : ""}</span><button type="button" aria-label="حذف المهمة" data-del="${t.id}" data-day="${k}">×</button></label>`).join("") : `<small class="muted">لا مهام</small>`}
          </div>`; }).join("")}</div>
      </div>`;
    $("#taskForm").onsubmit = (e) => {
      e.preventDefault(); const t = $("#taskText").value.trim(); if (!t) return;
      const d = $("#taskDay").value; (state.tasks[d] ||= []).push({ id: Date.now(), t, s: $("#taskSub").value, done: false });
      save("tasks"); toast("أُضيفت المهمة"); routes.planner();
    };
    $$(".task input").forEach((c) => c.onchange = () => { const t = state.tasks[c.dataset.day].find((x) => x.id == c.dataset.id); t.done = c.checked; if (c.checked) logActivity(); save("tasks"); routes.planner(); });
    $$("[data-del]").forEach((b) => b.onclick = (e) => { e.preventDefault(); state.tasks[b.dataset.day] = state.tasks[b.dataset.day].filter((x) => x.id != b.dataset.del); save("tasks"); routes.planner(); });
  };

  /* ---------- الملاحظات ---------- */
  let activeNote = null;
  routes.notes = () => {
    if (activeNote && !state.notes.find((n) => n.id === activeNote)) activeNote = null;
    const n = state.notes.find((x) => x.id === activeNote);
    main.innerHTML = `
      <div class="wrap page-head reveal"><span class="eyebrow">${icon("pen", 16)} الملاحظات</span><h1>ملخصاتي</h1><p class="lead">تُحفظ ملاحظاتك تلقائياً على هذا الجهاز.</p></div>
      <div class="wrap notes">
        <div>
          <div class="row" style="margin-bottom:var(--s3)">
            <label for="noteFilter" class="sr">ابحث في الملاحظات</label>
            <input class="field" id="noteFilter" placeholder="ابحث…" style="flex:1">
            <button class="btn btn--primary" id="newNote" aria-label="ملاحظة جديدة">${icon("plus", 18)}</button>
          </div>
          <div class="note-list" id="noteList"></div>
        </div>
        <div class="card">
          ${n ? `<div class="editor">
              <label for="nTitle" class="sr">العنوان</label><input class="field" id="nTitle" value="${esc(n.title)}" placeholder="العنوان">
              <label for="nBody" class="sr">المحتوى</label><textarea class="field" id="nBody" rows="14" placeholder="اكتب هنا…">${esc(n.body)}</textarea>
              <div class="row" style="justify-content:space-between"><small class="muted" id="nSaved">محفوظة</small><button class="btn btn--ghost btn--sm" id="nDel">${icon("trash", 16)} حذف</button></div>
            </div>` : `<div class="empty">${icon("pen", 40)}<p style="margin-top:var(--s3)">اختر ملاحظة من القائمة أو أنشئ واحدة جديدة.</p></div>`}
        </div>
      </div>`;
    const list = (q = "") => {
      const items = state.notes.filter((x) => (x.title + x.body).includes(q));
      $("#noteList").innerHTML = items.length ? items.map((x) => `<button class="note-item" data-note="${x.id}" aria-current="${x.id === activeNote}"><b>${esc(x.title || "بدون عنوان")}</b><small>${esc(x.body || "…")}</small></button>`).join("") : `<div class="empty" style="padding:var(--s5)">لا ملاحظات بعد</div>`;
      $$("[data-note]").forEach((b) => b.onclick = () => { activeNote = +b.dataset.note; routes.notes(); });
    };
    list();
    $("#noteFilter").oninput = (e) => list(e.target.value.trim());
    $("#newNote").onclick = () => { const x = { id: Date.now(), title: "ملاحظة جديدة", body: "", at: Date.now() }; state.notes.unshift(x); save("notes"); activeNote = x.id; logActivity(); routes.notes(); $("#nTitle").select(); };
    if (n) {
      let t; const upd = () => { n.title = $("#nTitle").value; n.body = $("#nBody").value; n.at = Date.now(); $("#nSaved").textContent = "جارٍ الحفظ…"; clearTimeout(t); t = setTimeout(() => { save("notes"); $("#nSaved").textContent = "محفوظة"; list($("#noteFilter").value.trim()); }, 400); };
      $("#nTitle").oninput = upd; $("#nBody").oninput = upd;
      $("#nDel").onclick = () => { state.notes = state.notes.filter((x) => x.id !== n.id); save("notes"); activeNote = null; toast("حُذفت الملاحظة"); routes.notes(); };
    }
  };

  /* ---------- التقدم ---------- */
  routes.progress = () => {
    const pct = Math.round((state.done.length / allLessons.length) * 100);
    const days = [...Array(28)].map((_, k) => { const d = new Date(); d.setDate(d.getDate() - (27 - k)); const v = state.activity[d.toISOString().slice(0, 10)] || 0; return v ? Math.min(3, Math.ceil(v / 2)) : 0; });
    main.innerHTML = `
      <div class="wrap page-head reveal"><span class="eyebrow">${icon("chart", 16)} تقدّمي</span><h1>لوحة الإنجاز</h1><p class="lead">أكملت ${ar(pct)}٪ من كل الدروس المتاحة.</p></div>
      <div class="wrap">
        <div class="kpis stagger">
          <div class="card kpi"><b>${ar(state.done.length)}</b><span>دروس مكتملة</span></div>
          <div class="card kpi"><b>${ar(Object.keys(state.best).length)}</b><span>اختبارات أُجريت</span></div>
          <div class="card kpi"><b>${ar(state.focusMin)}</b><span>دقيقة تركيز</span></div>
          <div class="card kpi"><b>${ar(streak())}</b><span>أيام متتالية</span></div>
        </div>
        <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr))">
          <div class="card"><h2>الدروس حسب المادة</h2>${SUBJECTS.map((s) => `<div class="prog-row"><span>${s.name}</span><div class="bar"><i style="width:${subjectPct(s)}%"></i></div><b>${ar(subjectPct(s))}٪</b></div>`).join("")}</div>
          <div class="card"><h2>أفضل نتائج الاختبارات</h2>${SUBJECTS.map((s) => `<div class="prog-row"><span>${s.name}</span><div class="bar bar--accent"><i style="width:${state.best[s.id] || 0}%"></i></div><b>${s.id in state.best ? ar(state.best[s.id]) + "٪" : "—"}</b></div>`).join("")}</div>
        </div>
        <div class="card" style="margin-top:var(--s4)">
          <h2>نشاطك خلال آخر 28 يوماً</h2>
          <div class="heat" role="img" aria-label="خريطة النشاط اليومي">${days.map((l) => `<i data-l="${l}"></i>`).join("")}</div>
          <div class="row" style="justify-content:flex-end;margin-top:var(--s4)"><button class="btn btn--ghost btn--sm" id="resetAll">${icon("trash", 16)} مسح كل البيانات</button></div>
        </div>
      </div>`;
    const r = $("#resetAll"); let armed = false;
    r.onclick = () => {
      if (!armed) { armed = true; r.innerHTML = "اضغط مرة أخرى للتأكيد"; setTimeout(() => { armed = false; if (r.isConnected) r.innerHTML = icon("trash", 16) + " مسح كل البيانات"; }, 3000); return; }
      Object.assign(state, { done: [], best: {}, notes: [], tasks: {}, focusMin: 0, activity: {}, known: {} });
      ["done", "best", "notes", "tasks", "focusMin", "activity", "known"].forEach(save); toast("تم مسح البيانات"); routes.progress();
    };
  };

  /* ---------- البحث ---------- */
  const sIn = $("#globalSearch"), sOut = $("#searchResults");
  sIn.addEventListener("input", () => {
    const q = sIn.value.trim();
    if (q.length < 2) { sOut.hidden = true; return; }
    const hits = allLessons.filter((l) => (l.title + l.body + l.subject.name).toLowerCase().includes(q.toLowerCase())).slice(0, 8);
    sOut.innerHTML = hits.length ? hits.map((l) => `<button class="search__item" role="option" data-go="lesson" data-arg="${l.id}"><b>${esc(l.title)}</b><small>${l.subject.name} · ${esc(l.unit)}</small></button>`).join("") : `<div class="search__item muted">لا نتائج لـ "${esc(q)}"</div>`;
    sOut.hidden = false;
  });
  sOut.addEventListener("click", () => { sOut.hidden = true; sIn.value = ""; });
  document.addEventListener("click", (e) => { if (!e.target.closest(".search")) sOut.hidden = true; });
  sIn.addEventListener("keydown", (e) => { if (e.key === "Escape") { sOut.hidden = true; sIn.blur(); } if (e.key === "Enter") { const f = $(".search__item[data-go]", sOut); if (f) f.click(); } });

  /* ---------- الوضع الليلي والقائمة ---------- */
  const themeBtn = $("#themeToggle");
  const applyTheme = (t) => { document.documentElement.dataset.theme = t; themeBtn.innerHTML = icon(t === "dark" ? "sun" : "moon", 20); store.set("theme", t); };
  applyTheme(store.get("theme", matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
  themeBtn.onclick = () => applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");
  const menuBtn = $("#menuToggle"); menuBtn.innerHTML = icon("menu", 20);
  menuBtn.onclick = () => { const o = $("#nav").classList.toggle("open"); menuBtn.setAttribute("aria-expanded", o); };

  go("home");
})();
