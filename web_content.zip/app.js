const dialog=document.getElementById('infoDialog');
const moduleDetails={
 ia:['Inteligência artificial','Área preparada para integrar um serviço de IA. A conexão, as chaves e os controles de privacidade ainda precisam ser configurados.'],
 voice:['Comandos de voz','A interface pode solicitar o microfone quando você tocar em conversar. A palavra de ativação contínua JARVIS ainda não está implementada.'],
 files:['Gerenciador de arquivos','Próxima etapa: integrar o seletor de arquivos do Android e operações locais com permissões adequadas.'],
 cloud:['JARVIS Cloud','A nuvem de 10 GB por conta exige backend, autenticação e armazenamento de objetos. Ainda não está ativa neste protótipo.'],
 images:['Laboratório de imagens','Próxima etapa: conectar um serviço de geração/edição de imagens e criar histórico de projetos.'],
 animation:['Laboratório de animações','Próxima etapa: editor de frames, camadas, timeline, pré-visualização e exportação.'],
 textures:['Laboratório de texturas','Próxima etapa: tela de pintura, paletas, camadas, importação e exportação de texturas.'],
 audio:['Laboratório de áudio','Próxima etapa: gravador, editor de waveform e biblioteca de efeitos.'],
 minecraft:['Minecraft Studio','Próxima etapa: modelos de projeto, editor de manifest/JSON, validação e empacotamento conforme a edição do Minecraft.'],
 productivity:['Produtividade','Próxima etapa: tarefas, notas, lembretes e calendário.'],
 security:['Segurança','Próxima etapa: controles de privacidade, permissões, exportação e exclusão de dados.'],
 settings:['Configurações','Preferências visuais, voz, notificações e gerenciamento de permissões serão adicionados aqui.']
};
document.querySelectorAll('[data-module]').forEach(btn=>btn.addEventListener('click',()=>{
 const [title,desc]=moduleDetails[btn.dataset.module];document.getElementById('dialogTitle').textContent=title;document.getElementById('dialogText').textContent=desc;dialog.showModal();
}));
document.getElementById('closeDialog').addEventListener('click',()=>dialog.close());
document.getElementById('dialogOk').addEventListener('click',()=>dialog.close());
document.getElementById('themeButton').addEventListener('click',()=>document.body.classList.toggle('light'));
document.getElementById('quickCommand').addEventListener('click',()=>{
 document.getElementById('commandInput').focus();
 document.getElementById('commandFeedback').textContent='Digite seu pedido no campo abaixo.';
});
document.getElementById('sendCommand').addEventListener('click',submitCommand);
document.getElementById('commandInput').addEventListener('keydown',e=>{if(e.key==='Enter')submitCommand()});
function submitCommand(){
 const input=document.getElementById('commandInput');const value=input.value.trim();
 document.getElementById('commandFeedback').textContent=value?`Pedido registrado neste protótipo: “${value}”. Para executar tarefas reais, será necessário conectar o motor de IA.`:'Digite um pedido primeiro.';
 if(value) input.value='';
}
document.getElementById('talkButton').addEventListener('click',()=>{
 const status=document.getElementById('statusText');
 if(!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)){
   status.textContent='Reconhecimento de voz não está disponível neste navegador. Use a caixa de texto ou integre um serviço compatível.';
   return;
 }
 const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
 const recognition=new SpeechRecognition();recognition.lang='pt-BR';recognition.interimResults=false;
 status.textContent='Estou ouvindo…';
 recognition.onresult=e=>{const said=e.results[0][0].transcript;document.getElementById('commandInput').value=said;document.getElementById('commandFeedback').textContent='Comando reconhecido. Toque na seta para registrar.';status.textContent='Comando reconhecido.'};
 recognition.onerror=()=>status.textContent='Não consegui reconhecer. Verifique a permissão do microfone.';
 recognition.onend=()=>{if(status.textContent==='Estou ouvindo…')status.textContent='Pronto para receber comandos';};
 try{recognition.start()}catch(_){status.textContent='Não foi possível iniciar o microfone.'}
});
document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>{
 document.querySelectorAll('[data-nav]').forEach(x=>x.classList.remove('active'));b.classList.add('active');
 if(b.dataset.nav!=='home'){document.getElementById('commandFeedback').textContent=`Seção ${b.dataset.nav} selecionada. Os módulos são acessados pela Central de Controle.`}
}));
