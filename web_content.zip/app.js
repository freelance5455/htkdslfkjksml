(() => {
  'use strict';

  const APP_VERSION = '1.7.8';
  const SCREEN_TITLES = {
    home: 'Home', mathematics: 'Mathematics', english: 'English', reasoning: 'Reasoning',
    generalStudies: 'General Studies', totalAttemptedQuestions: 'Attempted Questions',
    correctQuestions: 'Correct Questions', incorrectQuestions: 'Incorrect Questions',
    bookmarkQuestions: 'Bookmarked Questions', achievements: 'Achievements', progressReport: 'Progress Report',
    appearance: 'Appearance', settings: 'Settings', about: 'About'
  };
  // Keep old bookmark URLs working when opening links saved from earlier versions.
  const LEGACY_SCREEN_ALIASES = { bookmarkedQuestions: 'bookmarkQuestions' };
  const normalizeScreen = screen => LEGACY_SCREEN_ALIASES[screen] || screen;
  const PALETTES = [
    { id: 'red', name: 'Red', color: '#d90016' },
    { id: 'blue', name: 'Blue', color: '#245bd8' },
    { id: 'purple', name: 'Purple', color: '#7541c8' },
    { id: 'green', name: 'Green', color: '#14835d' },
    { id: 'amber', name: 'Amber', color: '#b66b00' }
  ];
  // Counts are intentionally zero until the question/practice data layer is added.
  const PRACTICE_COUNTS = {
    totalAttemptedQuestions: 0,
    correctQuestions: 0,
    incorrectQuestions: 0,
    bookmarkQuestions: 0
  };
  const ICONS = {
    menu: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
    back: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6M9 12h11"/></svg>',
    microphone: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11v1a7 7 0 0 0 14 0v-1M12 19v3m-4 0h8"/></svg>',
    mathematics: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h2m4 0h2m-8 4h2m4 0h2m-8 3h2m4 0h2"/></svg>',
    english: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 5.5A2.5 2.5 0 0 1 5.5 3H12v17H5.5A2.5 2.5 0 0 0 3 22zM21 5.5A2.5 2.5 0 0 0 18.5 3H12v17h6.5A2.5 2.5 0 0 1 21 22z"/><path d="M6 7h3m-3 4h3m6-4h3m-3 4h3"/></svg>',
    reasoning: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9.5 3.5a4 4 0 0 0-4 4 3.7 3.7 0 0 0 .7 2.2A4 4 0 0 0 7 17h1v3h8v-3h1a4 4 0 0 0 .8-7.3 3.7 3.7 0 0 0 .7-2.2 4 4 0 0 0-4-4 4.3 4.3 0 0 0-2.5.8 4.3 4.3 0 0 0-2.5-.8Z"/><path d="M12 5v12m-3-8 3 2 3-2m-5 8h4"/></svg>',
    generalStudies: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3.5 9h17M3.5 15h17M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>',
    totalAttemptedQuestions: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 3.5h6M8.5 9H10l1 1 2-2m-4.5 6H10l1 1 2-2m-4.5 3h7"/></svg>',
    correctQuestions: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16.5 8.5"/></svg>',
    incorrectQuestions: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="m9 9 6 6m0-6-6 6"/></svg>',
    bookmarkQuestions: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 4.5A1.5 1.5 0 0 1 7.5 3h9A1.5 1.5 0 0 1 18 4.5V21l-6-4-6 4z"/></svg>',
    achievements: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 21h8m-4-4v4M7 4h10v5a5 5 0 0 1-10 0zM7 6H4v2a4 4 0 0 0 4 4m9-6h3v2a4 4 0 0 1-4 4"/><path d="m12 6 1.1 2.2 2.4.3-1.8 1.7.4 2.4-2.1-1.2-2.1 1.2.4-2.4-1.8-1.7 2.4-.3z"/></svg>',
    progressReport: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 19V5m0 14h17"/><path d="m7 15 4-4 3 2 5-6"/><path d="M16 7h3v3"/></svg>',
    sun: '<svg class="sun-icon" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42"/></svg>',
    moon: '<svg class="moon-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M20.5 14.2A8.5 8.5 0 0 1 9.8 3.5 8.7 8.7 0 1 0 20.5 14.2Z"/></svg>',
    empty: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8m-8 4h5"/></svg>',
    appearance: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 3v18M12 12h9"/></svg>',
    chevron: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg>'
  };

  const main = document.getElementById('mainContent');
  const title = document.getElementById('pageTitle');
  const topbarStandard = document.getElementById('topbarStandard');
  const topbarSearch = document.getElementById('topbarSearch');
  const menuButton = document.getElementById('menuButton');
  const searchButton = document.getElementById('searchButton');
  const searchBackButton = document.getElementById('searchBackButton');
  const chapterSearchInput = document.getElementById('chapterSearchInput');
  const micButton = document.getElementById('micButton');
  const drawer = document.getElementById('navigationDrawer');
  const drawerScrim = document.getElementById('drawerScrim');
  let currentScreen = 'home';
  let backStack = [];
  let searchMode = false;
  let voiceRecognition = null;

  const safeStorage = {
    get(key, fallback) { try { return localStorage.getItem(key) ?? fallback; } catch { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, value); } catch { /* The app remains usable without storage. */ } }
  };

  function applyPreferences() {
    const theme = safeStorage.get('ssc-theme', 'light') === 'dark' ? 'dark' : 'light';
    const savedPalette = safeStorage.get('ssc-palette', 'red');
    const palette = PALETTES.some(item => item.id === savedPalette) ? savedPalette : 'red';
    document.documentElement.dataset.theme = theme;
    document.body.dataset.theme = theme;
    document.body.dataset.palette = palette;
    const themeMeta = document.querySelector('meta[name="theme-color"]');
    if (themeMeta) themeMeta.setAttribute('content', PALETTES.find(item => item.id === palette).color);
  }

  function setTheme(nextTheme) {
    if (!['light', 'dark'].includes(nextTheme)) return;
    safeStorage.set('ssc-theme', nextTheme);
    applyPreferences();
    renderScreen();
  }

  function setPalette(nextPalette) {
    if (!PALETTES.some(item => item.id === nextPalette)) return;
    safeStorage.set('ssc-palette', nextPalette);
    applyPreferences();
    renderScreen();
  }

  function updateNavigationControl() {
    const onHome = currentScreen === 'home';
    if (!onHome) searchMode = false;
    topbarStandard.hidden = searchMode;
    topbarSearch.hidden = !searchMode;
    menuButton.innerHTML = onHome ? ICONS.menu : ICONS.back;
    menuButton.setAttribute('aria-label', onHome ? 'Open navigation menu' : 'Go back');
    menuButton.setAttribute('aria-expanded', onHome && drawer.classList.contains('open') ? 'true' : 'false');
    menuButton.setAttribute('aria-controls', onHome ? 'navigationDrawer' : 'mainContent');
    menuButton.dataset.action = onHome ? 'menu' : 'back';
    searchButton.hidden = !onHome;
    searchButton.setAttribute('aria-expanded', searchMode ? 'true' : 'false');
  }

  function enterSearchMode() {
    if (currentScreen !== 'home') return;
    searchMode = true;
    updateNavigationControl();
    chapterSearchInput.focus();
  }

  function stopVoiceSearch() {
    if (voiceRecognition) {
      const activeRecognition = voiceRecognition;
      voiceRecognition = null;
      try { activeRecognition.abort(); } catch { /* Recognition may already have ended. */ }
    }
    micButton.classList.remove('recording');
    micButton.setAttribute('aria-pressed', 'false');
  }

  function exitSearchMode() {
    if (!searchMode) return;
    stopVoiceSearch();
    searchMode = false;
    updateNavigationControl();
    searchButton.focus();
  }

  function startVoiceSearch() {
    if (!searchMode) return;
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) {
      micButton.setAttribute('title', 'Voice input is not supported by this browser');
      chapterSearchInput.focus();
      return;
    }
    if (voiceRecognition) {
      stopVoiceSearch();
      return;
    }
    try {
      const recognition = new Recognition();
      voiceRecognition = recognition;
      recognition.lang = 'en-IN';
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;
      micButton.classList.add('recording');
      micButton.setAttribute('aria-pressed', 'true');
      micButton.setAttribute('title', 'Listening… tap to stop');
      recognition.onresult = event => {
        const transcript = event.results && event.results[0] && event.results[0][0]
          ? event.results[0][0].transcript : '';
        if (transcript) chapterSearchInput.value = transcript.trim();
      };
      recognition.onerror = event => {
        micButton.dataset.voiceError = event.error || 'unknown';
      };
      recognition.onend = () => {
        if (voiceRecognition === recognition) voiceRecognition = null;
        micButton.classList.remove('recording');
        micButton.setAttribute('aria-pressed', 'false');
        micButton.setAttribute('title', 'Speak chapter name');
      };
      recognition.start();
    } catch {
      stopVoiceSearch();
      micButton.setAttribute('title', 'Could not start voice input');
    }
  }

  function openDrawer() {
    if (currentScreen !== 'home') return;
    drawer.classList.add('open');
    drawer.setAttribute('aria-hidden', 'false');
    drawer.removeAttribute('inert');
    drawerScrim.hidden = false;
    updateNavigationControl();
    const first = drawer.querySelector('button');
    if (first) first.focus();
  }

  function closeDrawer(returnFocus = true) {
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden', 'true');
    drawer.setAttribute('inert', '');
    drawerScrim.hidden = true;
    updateNavigationControl();
    if (returnFocus) menuButton.focus();
  }

  function navigate(screen, { replace = false } = {}) {
    screen = normalizeScreen(screen);
    if (!SCREEN_TITLES[screen]) return;
    closeDrawer(false);
    if (searchMode) { stopVoiceSearch(); searchMode = false; }
    if (screen !== currentScreen) {
      if (!replace) backStack.push(currentScreen);
      currentScreen = screen;
      const state = { screen };
      if (replace) history.replaceState(state, '', `#${screen}`);
      else history.pushState(state, '', `#${screen}`);
    }
    renderScreen();
    main.focus({ preventScroll: true });
    window.scrollTo({ top: 0, behavior: 'instant' });
  }

  function goBack() {
    if (searchMode) {
      exitSearchMode();
    } else if (drawer.classList.contains('open')) {
      closeDrawer();
    } else if (backStack.length > 0) {
      history.back();
    } else if (currentScreen !== 'home') {
      navigate('home', { replace: true });
    }
  }

  function homeScreen() {
    const subjects = [
      ['mathematics', 'Mathematics'], ['english', 'English'],
      ['reasoning', 'Reasoning'], ['generalStudies', 'General Studies']
    ];
    const subjectTile = ([id, label]) => `<button class="tile subject-tile" type="button" data-screen="${id}" aria-label="Open ${label}"><span class="tile-label">${label}</span><span class="tile-icon">${ICONS[id]}</span></button>`;
    return `<div class="home-screen">
      <section class="home-section subjects-section" aria-label="Subjects"><h2 class="section-heading">Subjects</h2><div class="subject-grid">${subjects.map(subjectTile).join('')}</div></section>
    </div>`;
  }

  function placeholderScreen() {
    return `<section class="placeholder-card" aria-label="${SCREEN_TITLES[currentScreen]}"><div class="placeholder-art">${ICONS.empty}</div></section>`;
  }

  function appearanceScreen() {
    const selected = document.body.dataset.palette;
    const theme = document.body.dataset.theme === 'dark' ? 'dark' : 'light';
    const themeLabel = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
    return `<div class="appearance-options">
      <section class="settings-section" aria-label="Display mode">
        <div class="settings-row"><span class="settings-label">Display Mode</span><button class="display-mode-button" type="button" data-theme-toggle aria-label="${themeLabel}" title="${themeLabel}">${ICONS.sun}${ICONS.moon}</button></div>
      </section>
      <section class="theme-section" aria-label="Theme">
        <h2 class="theme-heading">Theme</h2>
        <div class="palette-list" role="group" aria-label="Colour schemes">${PALETTES.map(p => `<button class="palette-option" type="button" data-palette="${p.id}" aria-pressed="${selected === p.id}"><span class="palette-left"><span class="palette-color-dot" style="--swatch:${p.color}" aria-hidden="true"></span><span class="palette-name">${p.name}</span></span><span class="palette-indicator" style="--swatch:${p.color}" aria-hidden="true"></span></button>`).join('')}</div>
      </section>
    </div>`;
  }

  function settingsScreen() {
    return `<button class="settings-link" type="button" data-screen="appearance"><span class="settings-link-start"><span class="settings-link-icon">${ICONS.appearance}</span><span>Appearance</span></span><span class="settings-link-arrow">${ICONS.chevron}</span></button>`;
  }

  function aboutScreen() {
    return `<section class="info-card about-card"><img class="about-mark" src="assets/icon-192.png" alt=""><h2 class="about-title">SSC Personal Practice App</h2><p class="about-brand">SSC PYQ Bank</p><p class="about-version">Version ${APP_VERSION}</p></section>`;
  }

  function renderScreen() {
    title.textContent = SCREEN_TITLES[currentScreen] || 'Home';
    main.classList.toggle('home-active', currentScreen === 'home');
    updateNavigationControl();
    document.querySelectorAll('.drawer-item').forEach(item => {
      const active = item.dataset.screen === currentScreen;
      item.classList.toggle('active', active);
      if (active) item.setAttribute('aria-current', 'page');
      else item.removeAttribute('aria-current');
    });
    switch (currentScreen) {
      case 'home': main.innerHTML = homeScreen(); break;
      case 'appearance': main.innerHTML = appearanceScreen(); break;
      case 'settings': main.innerHTML = settingsScreen(); break;
      case 'about': main.innerHTML = aboutScreen(); break;
      default: main.innerHTML = placeholderScreen(); break;
    }
  }

  menuButton.addEventListener('click', () => {
    if (currentScreen !== 'home') {
      goBack();
      return;
    }
    drawer.classList.contains('open') ? closeDrawer() : openDrawer();
  });

  searchButton.addEventListener('click', enterSearchMode);
  searchBackButton.addEventListener('click', exitSearchMode);
  micButton.addEventListener('click', startVoiceSearch);
  chapterSearchInput.addEventListener('keydown', event => {
    if (event.key === 'Enter') event.preventDefault();
  });

  drawerScrim.addEventListener('click', () => closeDrawer());
  drawer.addEventListener('click', event => {
    const item = event.target.closest('[data-screen]');
    if (item) navigate(item.dataset.screen);
  });

  main.addEventListener('click', event => {
    const screenButton = event.target.closest('[data-screen]');
    if (screenButton) { navigate(screenButton.dataset.screen); return; }
    const paletteButton = event.target.closest('[data-palette]');
    if (paletteButton) { setPalette(paletteButton.dataset.palette); return; }
    const themeToggle = event.target.closest('[data-theme-toggle]');
    if (themeToggle) {
      setTheme(document.body.dataset.theme === 'dark' ? 'light' : 'dark');
      return;
    }
  });

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && searchMode) exitSearchMode();
    else if (event.key === 'Escape' && drawer.classList.contains('open')) closeDrawer();
  });

  window.addEventListener('popstate', event => {
    if (drawer.classList.contains('open')) closeDrawer(false);
    if (backStack.length) backStack.pop();
    const requestedScreen = event.state && event.state.screen ? normalizeScreen(event.state.screen) : 'home';
    const next = SCREEN_TITLES[requestedScreen] ? requestedScreen : 'home';
    currentScreen = next;
    renderScreen();
  });

  applyPreferences();
  const start = normalizeScreen(location.hash.slice(1));
  if (SCREEN_TITLES[start] && start !== 'home') {
    currentScreen = start;
    history.replaceState({ screen: start }, '', `#${start}`);
  } else {
    history.replaceState({ screen: 'home' }, '', '#home');
  }
  renderScreen();

  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./service-worker.js').catch(() => {
      // The app remains usable online if service-worker registration is unavailable.
    }));
  }
})();
