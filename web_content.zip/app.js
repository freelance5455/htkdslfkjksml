// ========================================
// Barber Book ✂️ v2
// ========================================

// ----------------------------------------
// DATA
// ----------------------------------------

let records = [];


// Monthly summaries are saved separately.
// This means Reset Today will NOT delete them.

let monthlySummaries = {};


// ----------------------------------------
// DATE
// ----------------------------------------

function getDate() {

  const now = new Date();

  return (
    now.getFullYear() +
    "-" +
    String(now.getMonth() + 1).padStart(2, "0") +
    "-" +
    String(now.getDate()).padStart(2, "0")
  );

}


function getMonthKey(date) {

  return String(date).slice(0, 7);

}


function getTime() {

  return new Date().toLocaleTimeString(
    "en-US",
    {
      hour: "2-digit",
      minute: "2-digit"
    }
  );

}


// ----------------------------------------
// SAVE
// ----------------------------------------

function saveData() {

  localStorage.setItem(
    "barberBookDataV2",
    JSON.stringify(records)
  );

  localStorage.setItem(
    "barberBookMonthlyV2",
    JSON.stringify(monthlySummaries)
  );

}


// ----------------------------------------
// LOAD
// ----------------------------------------

function loadData() {

  const savedRecords =
    localStorage.getItem("barberBookDataV2");

  const savedMonthly =
    localStorage.getItem("barberBookMonthlyV2");


  if (savedRecords) {

    try {
      records = JSON.parse(savedRecords);
    } catch (error) {
      records = [];
    }

  }


  if (savedMonthly) {

    try {
      monthlySummaries =
        JSON.parse(savedMonthly);
    } catch (error) {
      monthlySummaries = {};
    }

  }


  updateApp();

}


// ========================================
// MONTHLY SUMMARY SYSTEM
// ========================================

function addToMonthlySummary(record) {

  const month =
    getMonthKey(record.date);

  if (!monthlySummaries[month]) {

    monthlySummaries[month] = {

      income: 0,

      expense: 0,

      customers: 0

    };

  }


  const amount =
    Number(record.amount);


  if (record.type === "income") {

    monthlySummaries[month].income += amount;

    monthlySummaries[month].customers++;

  }


  if (record.type === "expense") {

    monthlySummaries[month].expense += amount;

  }

}


function removeFromMonthlySummary(record) {

  const month =
    getMonthKey(record.date);

  if (!monthlySummaries[month]) {
    return;
  }


  const amount =
    Number(record.amount);


  if (record.type === "income") {

    monthlySummaries[month].income -= amount;

    monthlySummaries[month].customers--;

  }


  if (record.type === "expense") {

    monthlySummaries[month].expense -= amount;

  }


  if (
    monthlySummaries[month].income <= 0 &&
    monthlySummaries[month].expense <= 0 &&
    monthlySummaries[month].customers <= 0
  ) {

    delete monthlySummaries[month];

  }

}


// ========================================
// INCOME
// ========================================

function addIncome(amount) {

  amount = Number(amount);

  if (!amount || amount <= 0) {
    return;
  }


  const record = {

    type: "income",

    amount: amount,

    name: "Customer",

    time: getTime(),

    date: getDate()

  };


  records.push(record);

  addToMonthlySummary(record);

  saveData();

  updateApp();

}


// ========================================
// CUSTOM INCOME
// ========================================

function addCustomIncome() {

  const input =
    document.getElementById("customAmount");

  const amount =
    Number(input.value);


  if (!amount || amount <= 0) {

    alert("ငွေပမာဏ ထည့်ပါ။");

    input.focus();

    return;

  }


  addIncome(amount);

  input.value = "";

}


// ========================================
// EXPENSE
// ========================================

function addExpense() {

  const nameInput =
    document.getElementById("expenseName");

  const amountInput =
    document.getElementById("expenseAmount");


  const name =
    nameInput.value.trim();

  const amount =
    Number(amountInput.value);


  if (!name) {

    alert("ထွက်ငွေအမည် ထည့်ပါ။");

    nameInput.focus();

    return;

  }


  if (!amount || amount <= 0) {

    alert("ထွက်ငွေပမာဏ ထည့်ပါ။");

    amountInput.focus();

    return;

  }


  const record = {

    type: "expense",

    amount: amount,

    name: name,

    time: getTime(),

    date: getDate()

  };


  records.push(record);

  addToMonthlySummary(record);

  saveData();

  updateApp();


  nameInput.value = "";

  amountInput.value = "";

}


// ========================================
// UPDATE APP
// ========================================

function updateApp() {

  updateSummary();

  renderHistory();

  updateToday();

}


// ========================================
// MAIN SUMMARY
// ========================================

function updateSummary() {

  let income = 0;

  let expense = 0;

  let customers = 0;


  records.forEach(record => {

    if (record.type === "income") {

      income += Number(record.amount);

      customers++;

    }


    if (record.type === "expense") {

      expense += Number(record.amount);

    }

  });


  const profit =
    income - expense;


  setText(
    "income",
    income.toLocaleString() + " Ks"
  );

  setText(
    "expense",
    expense.toLocaleString() + " Ks"
  );

  setText(
    "customers",
    customers
  );

  setText(
    "profit",
    profit.toLocaleString() + " Ks"
  );

}


// ========================================
// HISTORY
// ========================================

function renderHistory() {

  const list =
    document.getElementById("historyList");

  const count =
    document.getElementById("recordCount");


  if (!list || !count) {
    return;
  }


  const today =
    getDate();


  const todayRecords =
    records.filter(
      record => record.date === today
    );


  count.textContent =
    todayRecords.length + " ခု";


  if (todayRecords.length === 0) {

    list.innerHTML = `
      <div class="empty">
        📭 ဒီနေ့စာရင်းမရှိသေးပါ
      </div>
    `;

    return;

  }


  list.innerHTML = "";


  [...todayRecords]
    .reverse()
    .forEach(record => {

      const item =
        document.createElement("div");


      item.className =
        "history-item " +
        (
          record.type === "income"
            ? "income-item"
            : "expense-item"
        );


      const icon =
        record.type === "income"
          ? "✂️"
          : "💸";


      const sign =
        record.type === "income"
          ? "+"
          : "-";


      item.innerHTML = `

        <div class="history-icon">
          ${icon}
        </div>

        <div class="history-info">

          <strong>
            ${escapeHTML(record.name)}
          </strong>

          <small>
            ${record.date} • ${record.time}
          </small>

        </div>

        <div class="history-money">

          ${sign}${Number(record.amount).toLocaleString()} Ks

        </div>

      `;


      list.appendChild(item);

    });

}


// ========================================
// UNDO LAST
// ========================================

function undoLast() {

  if (records.length === 0) {

    alert("ဖျက်ရန် စာရင်းမရှိသေးပါ။");

    return;

  }


  const answer =
    confirm(
      "နောက်ဆုံးစာရင်းကို ပြန်ဖျက်မလား?"
    );


  if (!answer) {
    return;
  }


  const lastRecord =
    records.pop();


  // Remove from monthly summary too.
  removeFromMonthlySummary(lastRecord);


  saveData();

  updateApp();


  // If report is open, refresh it.
  if (
    document.getElementById("reportPage")
      ?.style.display === "block"
  ) {

    updateReport();

  }

}


// ========================================
// RESET TODAY
// ========================================

function resetToday() {

  const answer =
    confirm(
      "ဒီနေ့စာရင်းကိုပဲ ရှင်းမှာ သေချာလား?\n\n" +
      "📆 လချုပ်စာရင်းကို မဖျက်ပါ။"
    );


  if (!answer) {
    return;
  }


  const today =
    getDate();


  // IMPORTANT:
  // Only today's records are removed.
  // Monthly summaries stay untouched.

  records =
    records.filter(
      record => record.date !== today
    );


  saveData();

  updateApp();


  if (
    document.getElementById("reportPage")
      ?.style.display === "block"
  ) {

    updateReport();

  }

}


// ========================================
// TODAY
// ========================================

function updateToday() {

  const element =
    document.getElementById("today");


  if (!element) {
    return;
  }


  element.textContent =
    new Date().toLocaleDateString(
      "my-MM",
      {
        day: "numeric",
        month: "short",
        year: "numeric"
      }
    );

}


// ========================================
// HOME
// ========================================

function goHome() {

  const main =
    document.querySelector("main");

  const report =
    document.getElementById("reportPage");


  if (main) {
    main.style.display = "block";
  }


  if (report) {
    report.style.display = "none";
  }


  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });

}


// ========================================
// HISTORY
// ========================================

function goHistory() {

  const main =
    document.querySelector("main");

  const report =
    document.getElementById("reportPage");


  if (main) {
    main.style.display = "block";
  }


  if (report) {
    report.style.display = "none";
  }


  setTimeout(() => {

    const history =
      document.getElementById("historySection");


    if (history) {

      history.scrollIntoView({
        behavior: "smooth"
      });

    }

  }, 100);

}


// ========================================
// REPORT
// ========================================

function showReport() {

  const main =
    document.querySelector("main");

  const report =
    document.getElementById("reportPage");


  if (main) {
    main.style.display = "none";
  }


  if (report) {
    report.style.display = "block";
  }


  updateReport();


  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });

}


// ========================================
// CLOSE REPORT
// ========================================

function closeReport() {

  const main =
    document.querySelector("main");

  const report =
    document.getElementById("reportPage");


  if (report) {
    report.style.display = "none";
  }


  if (main) {
    main.style.display = "block";
  }


  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });

}


// ========================================
// REPORT
// ========================================

function updateReport() {

  const today =
    getDate();

  const currentMonth =
    getMonthKey(today);


  // TODAY

  let dailyIncome = 0;

  let dailyExpense = 0;

  let dailyCustomers = 0;


  records.forEach(record => {

    if (record.date !== today) {
      return;
    }


    const amount =
      Number(record.amount);


    if (record.type === "income") {

      dailyIncome += amount;

      dailyCustomers++;

    }


    if (record.type === "expense") {

      dailyExpense += amount;

    }

  });


  // CURRENT MONTH
  // Use the separate monthly summary.

  let monthlyIncome = 0;

  let monthlyExpense = 0;

  let monthlyCustomers = 0;


  if (monthlySummaries[currentMonth]) {

    monthlyIncome =
      Number(
        monthlySummaries[currentMonth].income
      );

    monthlyExpense =
      Number(
        monthlySummaries[currentMonth].expense
      );

    monthlyCustomers =
      Number(
        monthlySummaries[currentMonth].customers
      );

  }


  // ALL TIME

  let allIncome = 0;

  let allExpense = 0;

  let allCustomers = 0;


  Object.keys(monthlySummaries)
    .forEach(month => {

      const data =
        monthlySummaries[month];


      allIncome +=
        Number(data.income || 0);

      allExpense +=
        Number(data.expense || 0);

      allCustomers +=
        Number(data.customers || 0);

    });


  // DAILY

  setText(
    "dailyCustomers",
    dailyCustomers
  );

  setText(
    "dailyIncome",
    dailyIncome.toLocaleString() + " Ks"
  );

  setText(
    "dailyExpense",
    dailyExpense.toLocaleString() + " Ks"
  );

  setText(
    "dailyProfit",
    (dailyIncome - dailyExpense)
      .toLocaleString() + " Ks"
  );


  // MONTHLY

  setText(
    "monthlyCustomers",
    monthlyCustomers
  );

  setText(
    "monthlyIncome",
    monthlyIncome.toLocaleString() + " Ks"
  );

  setText(
    "monthlyExpense",
    monthlyExpense.toLocaleString() + " Ks"
  );

  setText(
    "monthlyProfit",
    (monthlyIncome - monthlyExpense)
      .toLocaleString() + " Ks"
  );


  // ALL

  setText(
    "allCustomers",
    allCustomers
  );

  setText(
    "allIncome",
    allIncome.toLocaleString() + " Ks"
  );

  setText(
    "allExpense",
    allExpense.toLocaleString() + " Ks"
  );

  setText(
    "allProfit",
    (allIncome - allExpense)
      .toLocaleString() + " Ks"
  );


  renderMonthlyReport();

  renderDailyReport();

}


// ========================================
// MONTHLY REPORT LIST
// ========================================

function renderMonthlyReport() {

  const list =
    document.getElementById(
      "monthlyReportList"
    );


  if (!list) {
    return;
  }


  const months =
    Object.keys(monthlySummaries)
      .sort()
      .reverse();


  if (months.length === 0) {

    list.innerHTML = `
      <div class="empty">
        📭 လချုပ်စာရင်းမရှိသေးပါ
      </div>
    `;

    return;

  }


  list.innerHTML = "";


  months.forEach(month => {

    const data =
      monthlySummaries[month];


    const income =
      Number(data.income || 0);

    const expense =
      Number(data.expense || 0);

    const customers =
      Number(data.customers || 0);

    const profit =
      income - expense;


    const item =
      document.createElement("div");


    item.className =
      "monthly-report-item";


    item.innerHTML = `

      <div class="report-item-info">

        <strong>
          📆 ${formatMonth(month)}
        </strong>

        <small>
          👤 ${customers} Customers
          <br>
          💰 ဝင်ငွေ: ${income.toLocaleString()} Ks
          <br>
          💸 ထွက်ငွေ: ${expense.toLocaleString()} Ks
        </small>

      </div>


      <div class="report-item-right">

        <span class="report-item-money">
          ${income.toLocaleString()} Ks
        </span>

        <span class="report-item-profit">
          အမြတ် ${profit.toLocaleString()} Ks
        </span>

      </div>


      <button
        class="delete-report"
        onclick="deleteMonthlyReport('${month}')"
      >
        🗑️
      </button>

    `;


    list.appendChild(item);

  });

}


// ========================================
// DELETE MONTHLY SUMMARY
// ========================================

function deleteMonthlyReport(month) {

  const data =
    monthlySummaries[month];


  if (!data) {
    return;
  }


  const answer =
    confirm(
      formatMonth(month) +
      " လချုပ်ကို ဖျက်မှာ သေချာလား?\n\n" +
      "⚠️ ဒီလချုပ်စာရင်းကိုပဲ ဖျက်ပါမယ်။"
    );


  if (!answer) {
    return;
  }


  delete monthlySummaries[month];


  saveData();

  updateReport();

}


// ========================================
// DAILY REPORT
// ========================================

function renderDailyReport() {

  const list =
    document.getElementById(
      "dailyReportList"
    );


  if (!list) {
    return;
  }


  const dailyData = {};


  records.forEach(record => {

    if (!record.date) {
      return;
    }


    if (!dailyData[record.date]) {

      dailyData[record.date] = {

        income: 0,

        expense: 0,

        customers: 0

      };

    }


    const amount =
      Number(record.amount);


    if (record.type === "income") {

      dailyData[record.date].income += amount;

      dailyData[record.date].customers++;

    }


    if (record.type === "expense") {

      dailyData[record.date].expense += amount;

    }

  });


  const dates =
    Object.keys(dailyData)
      .sort()
      .reverse();


  if (dates.length === 0) {

    list.innerHTML = `
      <div class="empty">
        📭 နေ့အလိုက်စာရင်းမရှိသေးပါ
      </div>
    `;

    return;

  }


  list.innerHTML = "";


  dates.forEach(date => {

    const data =
      dailyData[date];


    const profit =
      data.income - data.expense;


    const item =
      document.createElement("div");


    item.className =
      "daily-report-item";


    item.innerHTML = `

      <div class="report-item-info">

        <strong>
          📅 ${date}
        </strong>

        <small>
          👤 ${data.customers} Customers
          <br>
          💰 ဝင်ငွေ: ${data.income.toLocaleString()} Ks
          <br>
          💸 ထွက်ငွေ: ${data.expense.toLocaleString()} Ks
        </small>

      </div>


      <div class="report-item-right">

        <span class="report-item-money">
          ${data.income.toLocaleString()} Ks
        </span>

        <span class="report-item-profit">
          အမြတ် ${profit.toLocaleString()} Ks
        </span>

      </div>

    `;


    list.appendChild(item);

  });

}


// ========================================
// FORMAT MONTH
// ========================================

function formatMonth(month) {

  const parts =
    month.split("-");


  const year =
    parts[0];

  const monthNumber =
    Number(parts[1]);


  const monthNames = [

    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"

  ];


  return (
    monthNames[monthNumber - 1] +
    " " +
    year
  );

}


// ========================================
// SAFE TEXT
// ========================================

function setText(id, value) {

  const element =
    document.getElementById(id);


  if (element) {
    element.textContent = value;
  }

}


function escapeHTML(text) {

  const div =
    document.createElement("div");

  div.textContent =
    String(text);

  return div.innerHTML;

}


// ========================================
// SETTINGS
// ========================================

function showSettings() {

  alert(
    "⚙️ Settings\n\n" +
    "Settings ကို နောက်ပိုင်းမှာ " +
    "ထပ်ထည့်နိုင်ပါတယ်။"
  );

}


// ========================================
// START
// ========================================

loadData();