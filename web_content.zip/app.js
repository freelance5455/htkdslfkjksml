/* Proxima – aperçu fonctionnel (mode démo, tout est dans l'appareil)
   Pour une vraie flotte, remplacer la partie « DONNÉES » par un serveur partagé (voir LISEZ-MOI). */
'use strict';
const $=id=>document.getElementById(id);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const LILLE={lat:50.6292,lon:3.0573};
const ST={libre:{l:'Libre',c:'#16a34a'},route:{l:'En route vers le client',c:'#2f6bd0'},course:{l:'En course',c:'#e63946'},pause:{l:'Pause',c:'#f59e0b'},off:{l:'Hors service',c:'#8592a8'}};

/* ====================== CARTE (tuiles OpenStreetMap, sans bibliothèque) ====================== */
function MV(el,o){
  o=o||{};const T=256;const DPR=(window.devicePixelRatio||1)>1.2;let sm=false,fails=0,okc=0;let z=o.z||13,c={lat:o.lat||LILLE.lat,lon:o.lon||LILLE.lon},W=1,H=1,pend=false;
  const tl=document.createElement('div');tl.className='tl';
  const ns='http://www.w3.org/2000/svg',sv=document.createElementNS(ns,'svg');sv.setAttribute('class','rt');
  const poly=document.createElementNS(ns,'polyline');poly.setAttribute('fill','none');poly.setAttribute('stroke','#0a9396');poly.setAttribute('stroke-width','6');poly.setAttribute('stroke-linecap','round');poly.setAttribute('stroke-linejoin','round');poly.setAttribute('stroke-opacity','.85');const poly0=poly.cloneNode();poly0.setAttribute('stroke','#fff');poly0.setAttribute('stroke-width','11');poly0.setAttribute('stroke-opacity','1');sv.append(poly0,poly);
  const mk=document.createElement('div');
  const zm=document.createElement('div');zm.className='zoom';zm.innerHTML='<button type="button" aria-label="Zoom +">+</button><button type="button" aria-label="Zoom −">−</button><button type="button" aria-label="Recentrer">◎</button>';
  const at=document.createElement('div');at.className='attr';at.textContent='© OpenStreetMap © CARTO';
  const msg=document.createElement('div');msg.className='mapmsg';msg.hidden=true;msg.innerHTML='<b>Carte indisponible</b><span>Vérifiez la connexion Internet</span><button type="button">Réessayer</button>';
  el.classList.add('mv');el.append(tl,sv,mk,zm,at,msg);
  const tiles={},marks=[];let route=null;
  const wp=(lat,lon,zz)=>{const s=T*Math.pow(2,zz),sr=Math.sin(lat*Math.PI/180);return [(lon+180)/360*s,(0.5-Math.log((1+sr)/(1-sr))/(4*Math.PI))*s]};
  const inv=(x,y,zz)=>{const s=T*Math.pow(2,zz),n=Math.PI-2*Math.PI*y/s;return {lon:x/s*360-180,lat:180/Math.PI*Math.atan(Math.sinh(n))}};
  const scr=(lat,lon)=>{const p=wp(lat,lon,z),q=wp(c.lat,c.lon,z);return [W/2+p[0]-q[0],H/2+p[1]-q[1]]};
  function render(){
    pend=false;const tr=sm;W=el.clientWidth||1;H=el.clientHeight||1;
    const zi=Math.max(1,Math.min(19,Math.round(z))),sc=Math.pow(2,z-zi),ts=T*sc,cw=wp(c.lat,c.lon,zi),n=Math.pow(2,zi);
    const ox=W/2-cw[0]*sc,oy=H/2-cw[1]*sc,x0=Math.floor(-ox/ts),x1=Math.floor((W-ox)/ts),y0=Math.floor(-oy/ts),y1=Math.floor((H-oy)/ts),used={};
    for(let x=x0;x<=x1;x++)for(let y=y0;y<=y1;y++){
      if(y<0||y>=n)continue;const k=zi+'/'+(((x%n)+n)%n)+'/'+y+'/'+x;used[k]=1;let im=tiles[k];
      if(!im){im=document.createElement('img');im.alt='';im.draggable=false;const X=((x%n)+n)%n;im.onload=()=>{okc++;msg.hidden=true};im.onerror=()=>{if(!im.fb){im.fb=1;im.src='https://tile.openstreetmap.org/'+zi+'/'+X+'/'+y+'.png'}else if(++fails>=3&&!okc)msg.hidden=false};im.src='https://'+'abcd'[(x+y)&3]+'.basemaps.cartocdn.com/rastertiles/voyager/'+zi+'/'+X+'/'+y+(DPR?'@2x':'')+'.png';tl.appendChild(im);tiles[k]=im}
      const l=Math.round(ox+x*ts),t=Math.round(oy+y*ts);im.style.left=l+'px';im.style.top=t+'px';im.style.width=(Math.round(ox+(x+1)*ts)-l)+'px';im.style.height=(Math.round(oy+(y+1)*ts)-t)+'px';
    }
    for(const k in tiles)if(!used[k]){tiles[k].remove();delete tiles[k]}
    marks.forEach(m=>{const p=scr(m.lat,m.lon);m.el.style.transition=(tr&&m.shown)?'transform 1s linear':'none';m.shown=1;m.el.style.transform='translate3d('+p[0].toFixed(1)+'px,'+p[1].toFixed(1)+'px,0)'});
    const pts=route?route.map(p=>scr(p[1],p[0]).map(v=>v.toFixed(1)).join(',')).join(' '):'';poly.setAttribute('points',pts);poly0.setAttribute('points',pts);
  }
  const req=s=>{sm=pend?(sm&&!!s):!!s;if(!pend){pend=true;requestAnimationFrame(render)}};
  function zoomAt(sx,sy,nz){
    nz=Math.max(3,Math.min(18.5,nz));const q=wp(c.lat,c.lon,z),pre=inv(q[0]+sx-W/2,q[1]+sy-H/2,z);
    z=nz;const p=wp(pre.lat,pre.lon,z);c=inv(p[0]-(sx-W/2),p[1]-(sy-H/2),z);req();
  }
  function pan(dx,dy){const q=wp(c.lat,c.lon,z);c=inv(q[0]-dx,q[1]-dy,z);req()}
  /* gestes */
  const ptr={};let drag=0,start=null,d0=0,z0=0;
  el.addEventListener('pointerdown',e=>{if(e.target.closest('.zoom'))return;el.setPointerCapture(e.pointerId);ptr[e.pointerId]=[e.clientX,e.clientY];drag=0;start=[e.clientX,e.clientY];
    const ks=Object.keys(ptr);if(ks.length===2){const a=ptr[ks[0]],b=ptr[ks[1]];d0=Math.hypot(a[0]-b[0],a[1]-b[1]);z0=z}});
  el.addEventListener('pointermove',e=>{if(!ptr[e.pointerId])return;const p=ptr[e.pointerId],ks=Object.keys(ptr);
    if(ks.length===1){pan(e.clientX-p[0],e.clientY-p[1]);drag+=Math.abs(e.clientX-p[0])+Math.abs(e.clientY-p[1])}
    else if(ks.length===2){ptr[e.pointerId]=[e.clientX,e.clientY];const a=ptr[ks[0]],b=ptr[ks[1]],d=Math.hypot(a[0]-b[0],a[1]-b[1]),r=el.getBoundingClientRect();drag+=10;
      zoomAt((a[0]+b[0])/2-r.left,(a[1]+b[1])/2-r.top,z0+Math.log2(d/d0))}
    ptr[e.pointerId]=[e.clientX,e.clientY]});
  const up=e=>{if(!ptr[e.pointerId])return;const n=Object.keys(ptr).length;delete ptr[e.pointerId];
    if(n===1&&drag<6&&o.onTap){const r=el.getBoundingClientRect(),q=wp(c.lat,c.lon,z),ll=inv(q[0]+(e.clientX-r.left)-W/2,q[1]+(e.clientY-r.top)-H/2,z);o.onTap(ll.lat,ll.lon)}};
  el.addEventListener('pointerup',up);el.addEventListener('pointercancel',e=>{delete ptr[e.pointerId]});
  el.addEventListener('wheel',e=>{e.preventDefault();const r=el.getBoundingClientRect();zoomAt(e.clientX-r.left,e.clientY-r.top,z-e.deltaY*.0018)},{passive:false});
  zm.children[0].onclick=()=>zoomAt(W/2,H/2,z+1);zm.children[1].onclick=()=>zoomAt(W/2,H/2,z-1);zm.children[2].onclick=()=>o.onLocate&&o.onLocate();
  msg.querySelector('button').onclick=()=>api.retry();
  if('ResizeObserver' in window)new ResizeObserver(()=>req()).observe(el);else addEventListener('resize',()=>req());
  req();
  const api={
    addMarker(html,cls){const d=document.createElement('div');d.className='mk';d.innerHTML=html;mk.appendChild(d);const m={el:d,lat:0,lon:0,set(la,lo){m.lat=la;m.lon=lo;req(true)},html(h){d.innerHTML=h},remove(){d.remove();marks.splice(marks.indexOf(m),1);req()}};marks.push(m);return m},
    center(lat,lon,zz){c={lat,lon};if(zz)z=zz;req()},
    fit(pts){if(!pts.length)return;let a=90,b=-90,l=180,r=-180;pts.forEach(p=>{a=Math.min(a,p[0]);b=Math.max(b,p[0]);l=Math.min(l,p[1]);r=Math.max(r,p[1])});
      c={lat:(a+b)/2,lon:(l+r)/2};let zz=17;while(zz>4){const p1=wp(a,l,zz),p2=wp(b,r,zz);if(Math.abs(p2[0]-p1[0])<W-110&&Math.abs(p2[1]-p1[1])<H-110)break;zz-=.25}z=zz;req()},
    route(coords){route=coords;req()},resize:req,retry(){for(const k in tiles){tiles[k].remove();delete tiles[k]}fails=0;okc=0;msg.hidden=true;req()}
  };return api;
}

/* ====================== DONNÉES (démo locale ; à remplacer par un serveur pour la vraie flotte) ====================== */
const km=(a,b)=>{const R=6371,t=Math.PI/180,dl=(b.lat-a.lat)*t,dn=(b.lon-a.lon)*t,x=Math.sin(dl/2)**2+Math.cos(a.lat*t)*Math.cos(b.lat*t)*Math.sin(dn/2)**2;return 2*R*Math.asin(Math.sqrt(x))};
const etaMin=k=>Math.max(1,Math.round(k*1.35/28*60));
const fk=k=>k.toFixed(1).replace('.',',')+' km';
const D=[
 {id:1,name:'Karim',lat:50.6366,lon:3.0702,st:'libre'},
 {id:2,name:'Sophie',lat:50.6430,lon:3.0630,st:'libre'},
 {id:3,name:'Mehdi',lat:50.6190,lon:3.1380,st:'course',tgt:{lat:50.6292,lon:3.0573}},
 {id:4,name:'Julie',lat:50.6150,lon:3.0560,st:'libre'},
 {id:5,name:'Thomas',lat:50.6460,lon:2.9890,st:'pause'},
 {id:6,name:'Nadia',lat:50.6942,lon:3.1746,st:'libre'},
 {id:7,name:'Yanis',lat:50.6070,lon:3.0900,st:'off'}
];
D.forEach(d=>{d.upd=Date.now();d.offer=null});
const ME={id:1,gps:false};
const ACTS=[];                     // courses attribuées
let DEST=null,RANK=[],SEL=null,shownAct=null;
function setHdg(d,a){const p=d.hdg==null?a:d.hdg;d.hdg=p+(((a-p+540)%360)-180);const e=d.mk&&d.mk.el.querySelector('.hd');if(e){e.style.display='';e.style.transform='rotate('+d.hdg+'deg)'}}
const bearing=(la,lo,pl,po)=>{const dy=la-pl,dx=(lo-po)*Math.cos(la*Math.PI/180);return Math.abs(dx)+Math.abs(dy)>1e-7?Math.atan2(dx,dy)*180/Math.PI:null};

/* ====================== INTERFACE ====================== */
const toast=(t)=>{const e=document.createElement('div');e.className='toast';e.textContent=t;document.body.appendChild(e);setTimeout(()=>e.remove(),3200)};
function beep(){try{const a=new (window.AudioContext||window.webkitAudioContext)(),o=a.createOscillator(),g=a.createGain();o.connect(g);g.connect(a.destination);o.frequency.value=880;g.gain.setValueAtTime(.2,a.currentTime);g.gain.exponentialRampToValueAtTime(.001,a.currentTime+.6);o.start();o.stop(a.currentTime+.6)}catch(e){}if(navigator.vibrate)navigator.vibrate([300,150,300])}
const carHTML=d=>'<div class="car '+(d.st==='libre'?'libre':'')+(SEL===d.id?' sel':'')+'" style="--c:'+ST[d.st].c+'"><i class="hd" style="'+(d.hdg==null?'display:none;':'')+'transform:rotate('+(d.hdg||0)+'deg)"></i>'+esc(d.name[0])+'<small>'+esc(d.name)+'</small></div>';

const map=new MV($('map'),{onLocate:()=>map.fit(D.filter(d=>d.st!=='off').map(d=>[d.lat,d.lon])),onTap:(la,lo)=>{setTab('ride');setDest(la,lo,'Point choisi sur la carte')}});
const map2=new MV($('map2'),{onLocate:()=>{const m=D.find(x=>x.id===ME.id);map2.center(m.lat,m.lon,16)}});
D.forEach(d=>{d.mk=map.addMarker(carHTML(d));d.mk.set(d.lat,d.lon)});
const meMk=map2.addMarker('<div class="me"><i class="hd"></i></div>'),carMk2=null;
let pinMk=null,pinMk2=null;
const PIN='<svg class="pin" viewBox="0 0 34 44"><path d="M17 1C8 1 1 8 1 17c0 12 16 26 16 26s16-14 16-26C33 8 26 1 17 1z" fill="#e63946" stroke="#fff" stroke-width="2"/><circle cx="17" cy="17" r="6" fill="#fff"/></svg>';

function updMarker(d){d.mk.html(carHTML(d));d.mk.set(d.lat,d.lon)}
function setTab(t){document.querySelectorAll('#ptabs button').forEach(b=>b.classList.toggle('on',b.dataset.t===t));$('pDrivers').hidden=t!=='drivers';$('pRide').hidden=t!=='ride'}
document.querySelectorAll('#ptabs button').forEach(b=>b.onclick=()=>setTab(b.dataset.t));
document.querySelectorAll('#mode button').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('#mode button').forEach(x=>x.classList.toggle('on',x===b));
  $('vReg').hidden=b.dataset.m!=='reg';$('vDrv').hidden=b.dataset.m!=='drv';
  if(b.dataset.m==='drv'){renderMe();const m=D.find(x=>x.id===ME.id);map2.center(m.lat,m.lon,15);if(GEO.ok&&!$('gps').checked){$('gps').checked=true;$('gps').onchange()}}else map.resize();
});

/* liste des chauffeurs */
function ago(d){const s=Math.round((Date.now()-d.upd)/1000);return s<5?'à l\'instant':s<60?'il y a '+s+' s':'il y a '+Math.round(s/60)+' min'}
function renderDrivers(){
  const cnt={};D.forEach(d=>cnt[d.st]=(cnt[d.st]||0)+1);
  $('cnt').innerHTML=Object.keys(ST).filter(k=>cnt[k]).map(k=>'<span style="--c:'+ST[k].c+'">'+cnt[k]+' '+ST[k].l.replace(' vers le client','')+'</span>').join('');
  $('dlist').innerHTML='';
  D.slice().sort((a,b)=>Object.keys(ST).indexOf(a.st)-Object.keys(ST).indexOf(b.st)).forEach(d=>{
    const b=document.createElement('button');b.type='button';b.className='drv';b.style.setProperty('--c',ST[d.st].c);
    const dd=DEST&&d.st==='libre'?'<small>'+fk(km(d,DEST))+' du client</small>':'<small>'+ago(d)+'</small>';
    b.innerHTML='<span class="av">'+esc(d.name[0])+'</span><span><b>'+esc(d.name)+(d.id===ME.id?' (moi)':'')+'</b>'+dd+'</span><span class="st">'+ST[d.st].l+'</span>';
    b.onclick=()=>{SEL=d.id;D.forEach(updMarker);map.center(d.lat,d.lon,15)};$('dlist').appendChild(b)});
}

/* nouvelle course : adresse -> classement */
let tAddr,nAddr=0;
$('addr').addEventListener('input',()=>{clearTimeout(tAddr);const q=$('addr').value.trim();if(q.length<3){$('sug').hidden=true;return}
  tAddr=setTimeout(async()=>{const my=++nAddr;try{const r=await fetch('https://api-adresse.data.gouv.fr/search/?limit=5&autocomplete=1&lat=50.63&lon=3.06&q='+encodeURIComponent(q)),j=await r.json();if(my!==nAddr)return;
    $('sug').innerHTML='';(j.features||[]).forEach(f=>{const b=document.createElement('button');b.type='button';b.innerHTML='<b></b> <small></small>';b.firstChild.textContent=f.properties.name;b.lastChild.textContent=f.properties.postcode+' '+f.properties.city;
      b.onclick=()=>{$('addr').value=f.properties.label;$('sug').hidden=true;setDest(f.geometry.coordinates[1],f.geometry.coordinates[0],f.properties.label);map.center(f.geometry.coordinates[1],f.geometry.coordinates[0],14)};$('sug').appendChild(b)});
    $('sug').hidden=!$('sug').children.length}catch(e){$('sug').hidden=true}},250)});
function setDest(lat,lon,label){
  DEST={lat,lon,label};if(!pinMk)pinMk=map.addMarker(PIN);pinMk.set(lat,lon);
  if(label==='Point choisi sur la carte')$('addr').value='';
  computeRank();
}
async function osrm(a,b){const r=await fetch('https://router.project-osrm.org/route/v1/driving/'+a.lon+','+a.lat+';'+b.lon+','+b.lat+'?overview=full&geometries=geojson'),j=await r.json();
  if(!j.routes||!j.routes[0])throw 0;return{km:j.routes[0].distance/1000,min:Math.max(1,Math.round(j.routes[0].duration/60)),coords:j.routes[0].geometry.coordinates}}
function computeRank(){
  RANK=D.filter(d=>d.st==='libre').map(d=>{const k=km(d,DEST);return{d,km:k,min:etaMin(k),exact:false}}).sort((a,b)=>a.km-b.km);
  renderRank();renderDrivers();
  RANK.slice(0,3).forEach(async r=>{try{const x=await osrm(r.d,DEST);if(!DEST||r.d.st!=='libre')return;r.km=x.km;r.min=x.min;r.coords=x.coords;r.exact=true;RANK.sort((a,b)=>a.min-b.min);renderRank()}catch(e){}});
  map.fit([[DEST.lat,DEST.lon]].concat(RANK.slice(0,3).map(r=>[r.d.lat,r.d.lon])));
}
function renderRank(){
  const bx=$('rank');if(!DEST){bx.innerHTML='';return}
  let h='<div class="h3">Chauffeurs libres, du plus proche au plus loin</div>';
  if(!RANK.length)h+='<p class="note">Aucun chauffeur libre pour le moment.</p>';
  RANK.forEach((r,i)=>{h+='<div class="drv'+(i===0?' best':'')+'" style="--c:'+ST.libre.c+'" data-i="'+i+'"><span class="av">'+esc(r.d.name[0])+'</span><span><b>'+esc(r.d.name)+'</b><small>'+fk(r.km)+(r.exact?' · par la route':' · à vol d\'oiseau')+(i===0?' · le plus proche':'')+'</small></span><span class="eta">'+r.min+' min<small>d\'arrivée</small></span><button class="go" data-a="'+i+'">Attribuer</button></div>'});
  bx.innerHTML=h;
  bx.querySelectorAll('.drv').forEach(e=>e.onclick=ev=>{if(ev.target.closest('.go'))return;const r=RANK[+e.dataset.i];map.route(r.coords||null);map.center(r.d.lat,r.d.lon);map.fit([[DEST.lat,DEST.lon],[r.d.lat,r.d.lon]])});
  bx.querySelectorAll('.go').forEach(b=>b.onclick=()=>assign(RANK[+b.dataset.a]));
}
function assign(r){
  const d=r.d;if(d.offer&&d.offer.status==='pending'){toast(d.name+' a déjà une proposition en attente');return}
  d.offer={dest:Object.assign({},DEST),min:r.min,km:r.km,t0:Date.now(),status:'pending',coords:r.coords||null};
  const a={id:Date.now(),d,label:DEST.label,status:'pending'};ACTS.unshift(a);d.offer.act=a;
  if(d.id===ME.id){beep();$('mdot').hidden=false}
  else setTimeout(()=>{if(d.offer!==null&&d.offer.act===a&&a.status==='pending')answer(d,Math.random()<.8)},3000+Math.random()*4000);
  renderActs();setTab('ride');toast('Proposition envoyée à '+d.name);
}
function answer(d,ok,timeout){
  const o=d.offer;if(!o||o.status!=='pending')return;
  o.status=ok?'accepted':(timeout?'timeout':'refused');o.act.status=o.status;
  if(ok){d.st='route';d.tgt=o.dest;d.upd=Date.now();d.legCoords=o.coords;toast(d.name+' accepte la course')}
  else toast(d.name+(timeout?' n\'a pas répondu':' refuse la course'));
  updMarker(d);renderActs();renderDrivers();renderMe();
  if(ok){DEST=null;RANK=[];renderRank();map.route(null)}else if(DEST)computeRank();
}
function renderActs(){
  $('actH').hidden=!ACTS.length;
  $('acts').innerHTML=ACTS.slice(0,6).map(a=>{const t={pending:'⏳ En attente de réponse…',accepted:'✅ Acceptée – en route',refused:'❌ Refusée',timeout:'⌛ Sans réponse'}[a.status];
    return '<div class="act"><b>'+esc(a.d.name)+' → '+esc(a.label)+'</b><span class="s">'+t+(a.status==='accepted'&&a.d.st==='route'&&a.d.tgt?' · '+etaMin(km(a.d,a.d.tgt))+' min':'')+'</span>'+infoHTML(a)+'</div>'}).join('');
}

/* ====================== VUE CHAUFFEUR ====================== */
$('me').innerHTML=D.map(d=>'<option value="'+d.id+'">'+esc(d.name)+'</option>').join('');
$('me').onchange=()=>{ME.id=+$('me').value;renderMe();const m=D.find(x=>x.id===ME.id);map2.center(m.lat,m.lon,15)};
document.querySelectorAll('#big button').forEach(b=>b.onclick=()=>{const m=D.find(x=>x.id===ME.id);m.st=b.dataset.s;m.tgt=null;m.upd=Date.now();updMarker(m);renderMe();renderDrivers()});
function renderMe(){
  const m=D.find(x=>x.id===ME.id);$('stbar').textContent=ST[m.st].l;$('stbar').style.setProperty('--c',ST[m.st].c);
  document.querySelectorAll('#big button').forEach(b=>b.classList.toggle('on',b.dataset.s===m.st));
  const o=m.offer,ob=$('offerBox');
  if(o&&o.status==='pending'){
    ob.innerHTML='<div class="offer"><h2>🚖 Nouvelle course</h2><div><b>Prise en charge :</b> '+esc(o.dest.label)+'</div><div><b>À '+o.min+' min</b> de vous · '+fk(o.km)+'</div><div class="tm"><i id="tmI"></i></div><div class="row"><button class="btn ko" id="refB">Refuser</button><button class="btn ok" id="accB">Accepter</button></div></div>';
    $('accB').onclick=()=>{answer(m,true);dictate()};$('refB').onclick=()=>answer(m,false);
    map2.route(o.coords||null);if(!pinMk2)pinMk2=map2.addMarker(PIN);pinMk2.set(o.dest.lat,o.dest.lon);map2.fit([[m.lat,m.lon],[o.dest.lat,o.dest.lon]]);
  }else ob.innerHTML='';
  const f=$('flow');
  if(m.st==='route'&&m.tgt){f.innerHTML='<div class="offer" style="border-color:#2f6bd0"><h2>En route vers le client</h2><div>'+esc(m.tgt.label||'')+'</div><div>Arrivée dans ≈ '+etaMin(km(m,m.tgt))+' min</div><div class="row"><button class="btn ok" id="onB">Client à bord</button></div></div>';
    $('onB').onclick=()=>{m.st='course';m.tgt=null;m.upd=Date.now();updMarker(m);renderMe();renderDrivers();map2.route(null)};
    if(!pinMk2)pinMk2=map2.addMarker(PIN);pinMk2.set(m.tgt.lat,m.tgt.lon);
  }else if(m.st==='course'){f.innerHTML='<div class="offer" style="border-color:#e63946"><h2>Course en cours</h2><div class="row"><button class="btn ok" id="endB">Course terminée → Libre</button></div></div>';
    $('endB').onclick=()=>{m.st='libre';m.upd=Date.now();updMarker(m);renderMe();renderDrivers()};
  }else f.innerHTML='';
  if(m.st!=='route'&&!(o&&o.status==='pending')&&pinMk2){pinMk2.remove();pinMk2=null;map2.route(null)}
  if(!(o&&o.status==='pending'))$('mdot').hidden=true;
  const act=o&&o.act,show=!!(act&&act.status==='accepted'&&(m.st==='route'||m.st==='course'));
  $('infoBox').hidden=!show;
  if(show&&shownAct!==act){shownAct=act;act.info=act.info||{name:'',pax:0,dest:'',note:''};fillInfo()}
  if(!show)shownAct=null;
}
$('gps').onchange=()=>{
  if(!$('gps').checked){ME.gps=false;if(ME.w!=null)navigator.geolocation.clearWatch(ME.w);return}
  if(!navigator.geolocation){toast('GPS indisponible sur cet appareil');$('gps').checked=false;return}
  try{navigator.wakeLock&&navigator.wakeLock.request('screen').catch(()=>{})}catch(e){}
  ME.w=navigator.geolocation.watchPosition(p=>{ME.gps=true;const m=D.find(x=>x.id===ME.id);const pl=m.lat,po=m.lon;m.lat=p.coords.latitude;m.lon=p.coords.longitude;const h=p.coords.heading,b=(h!=null&&!isNaN(h))?h:bearing(m.lat,m.lon,pl,po);if(b!=null)m.hdg=m.hdg==null?b:m.hdg+(((b-m.hdg+540)%360)-180);ME.acc=Math.round(p.coords.accuracy);$('gpsInfo').textContent='Précision GPS ± '+ME.acc+' m';m.upd=Date.now();updMarker(m)},
    ()=>{toast('Position refusée : autorisez la localisation');$('gps').checked=false;ME.gps=false},{enableHighAccuracy:true,maximumAge:3000});
};


/* ====================== INFOS COURSE : DICTÉE VOCALE ====================== */
const NUM={un:1,une:1,deux:2,trois:3,quatre:4,cinq:5,six:6,sept:7,huit:8},NB='(\\d+|un|une|deux|trois|quatre|cinq|six|sept|huit)';
const cap=s=>s.replace(/(^|[\s'’-])(\p{L})/gu,(m,a,b)=>a+b.toUpperCase());
function parseRide(t){
  const o={};let m=t.match(new RegExp(NB+'\\s*(?:personnes?|clients?|passagers?|pax|adultes?)','i'));
  if(m)o.pax=NUM[m[1].toLowerCase()]||+m[1];
  m=t.match(/(?:monsieur|madame|mme|mlle)\s+([\p{L}'-]+)/iu)||t.match(/(?:client|cliente|nom|au nom de|nommé)\s+(?:est\s+)?(?!\d)([\p{L}'-]+)/iu);
  if(m)o.name=(/madame|mme|mlle/i.test(m[0])?'Mme ':/monsieur/i.test(m[0])?'M. ':'')+cap(m[1]);
  m=t.match(/\b(?:direction|destination(?:\s+de)?|vers|jusqu['’]\s*(?:à|a|au)|pour aller (?:à|a|au|aux))\s+(.+)/iu);
  if(m)o.dest=cap(m[1].split(new RegExp('\\s+(?:avec\\s+|et\\s+)?'+NB+'\\s*(?:personnes?|clients?|passagers?|valises?|bagages?|sacs?)','i'))[0].replace(/[.,]+$/,'').trim());
  const nt=[];m=t.match(new RegExp(NB+'\\s*(valises?|bagages?|sacs?)','i'));if(m)nt.push(m[1]+' '+m[2]);
  m=t.match(/fauteuil roulant|siège (?:bébé|enfant)|rehausseur|poussette|animal|chien/i);if(m)nt.push(m[0]);
  if(nt.length)o.note=nt.join(', ');
  if(!o.pax&&!o.name&&!o.dest&&!o.note)o.note=t;
  return o}
function fillInfo(){const i=shownAct.info;$('iName').value=i.name||'';$('iDest').value=i.dest||'';$('iNote').value=i.note||'';$('heard').hidden=true;
  $('iPax').innerHTML=[1,2,3,4,5,6,7,8].map(n=>'<button type="button" data-n="'+n+'"'+(i.pax===n?' class="on"':'')+'>'+n+'</button>').join('')}
$('iPax').onclick=e=>{const b=e.target.closest('button');if(!b||!shownAct)return;shownAct.info.pax=+b.dataset.n;fillInfo()};
['iName','iDest','iNote'].forEach(id=>$(id).addEventListener('input',()=>{if(!shownAct)return;const i=shownAct.info;i.name=$('iName').value;i.dest=$('iDest').value;i.note=$('iNote').value}));
const infoTxt=i=>[i.name,i.pax?i.pax+' pers.':'',i.dest?'→ '+i.dest:'',i.note].filter(Boolean).join(' · ');
const infoHTML=a=>a.info&&infoTxt(a.info)?'<span class="inf">👤 '+esc(infoTxt(a.info))+'</span>':'';
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;let rec=null;
function dictate(){
  if(!SR){toast('Dictée indisponible ici : utilisez le micro 🎙️ du clavier dans chaque champ');return}
  if(rec){rec.stop();return}
  const r=rec=new SR(),hb=$('heard');let fin='';r.lang='fr-FR';r.interimResults=true;
  $('mic').classList.add('rec');hb.hidden=false;hb.textContent='J\'écoute… ex : « Client Dupont, 3 personnes, 2 valises, direction gare Lille Europe »';
  r.onresult=e=>{let t='';for(const x of e.results)t+=x[0].transcript+' ';fin=t.trim();hb.textContent='« '+fin+' »'};
  r.onerror=e=>toast(e.error==='not-allowed'?'Micro refusé : autorisez-le dans les réglages':'Dictée interrompue');
  r.onend=()=>{rec=null;$('mic').classList.remove('rec');if(!fin||!shownAct){if(!fin)hb.hidden=true;return}
    const p=parseRide(fin),i=shownAct.info;if(p.name)i.name=p.name;if(p.pax)i.pax=p.pax;if(p.dest)i.dest=p.dest;if(p.note)i.note=p.note;fillInfo();hb.hidden=false;hb.textContent='✓ Noté : « '+fin+' » — vérifiez ci-dessous';
    try{const u=new SpeechSynthesisUtterance('Noté. '+infoTxt(i));u.lang='fr-FR';speechSynthesis.speak(u)}catch(e){}};
  try{r.start()}catch(e){rec=null;$('mic').classList.remove('rec')}
}
$('mic').onclick=dictate;

/* ====================== SIMULATION (chauffeurs fictifs) ====================== */
function step(d,t,sp){const dl=t.lat-d.lat,dn=t.lon-d.lon,L=Math.hypot(dl,dn);if(L<sp){d.lat=t.lat;d.lon=t.lon;return true}d.lat+=dl/L*sp;d.lon+=dn/L*sp;return false}
setInterval(()=>{
  D.forEach(d=>{
    if(d.id===ME.id&&ME.gps)return;
    const prev=d.lat+','+d.lon;
    if((d.st==='route'||d.st==='course')&&d.tgt){
      const arrived=step(d,d.tgt,d.st==='route'?.0003:.0002);
      if(arrived&&d.id!==ME.id){
        if(d.st==='route'&&!d.hold){d.hold=Date.now()}
        if(d.st==='route'&&d.hold&&Date.now()-d.hold>4000){d.hold=0;d.st='course';d.tgt={lat:LILLE.lat+(Math.random()-.5)*.1,lon:LILLE.lon+(Math.random()-.5)*.14};d.upd=Date.now()}
        else if(d.st==='course'){d.st='libre';d.tgt=null;d.upd=Date.now();if(DEST)computeRank()}
      }
    }else if(d.st==='libre'){
      d.hd=(d.hd||Math.random()*6.28)+(Math.random()-.5)*.8;d.lat+=Math.sin(d.hd)*.00009;d.lon+=Math.cos(d.hd)*.00014;
      if(km(d,LILLE)>7){d.hd=Math.atan2(LILLE.lat-d.lat,LILLE.lon-d.lon)}
    }
    if(d.lat+','+d.lon!==prev){const pl=prev.split(','),b=bearing(d.lat,d.lon,+pl[0],+pl[1]);if(b!=null)setHdg(d,b);d.upd=Date.now();d.mk.set(d.lat,d.lon)}
    if(d.st!==d._ls){d._ls=d.st;updMarker(d)}
  });
  renderDrivers();renderActs();
  const m=D.find(x=>x.id===ME.id);meMk.set(m.lat,m.lon);{const he=meMk.el.querySelector('.hd');if(he)he.style.transform='rotate('+(m.hdg||0)+'deg)'}
  if(!$('vDrv').hidden){
    const o=m.offer;if(o&&o.status==='pending'){const p=(Date.now()-o.t0)/30000;const e=$('tmI');if(e)e.style.width=Math.max(0,100-p*100)+'%';if(p>=1)answer(m,false,true)}
    if(m.st==='route'||m.st==='course')map2.center(m.lat,m.lon);
    if(m.st==='route'&&m.tgt&&Math.hypot(m.lat-m.tgt.lat,m.lon-m.tgt.lon)<.0004&&!m.arr){m.arr=1;toast('Vous êtes arrivé chez le client');beep()}if(m.st!=='route')m.arr=0;
    const f=$('flow').querySelector('div div:nth-of-type(2)');if(f&&m.st==='route'&&m.tgt)f.textContent='Arrivée dans ≈ '+etaMin(km(m,m.tgt))+' min';
  }
},1000);


/* ====================== CONNEXION + AUTORISATION DE POSITION ====================== */
const GEO={ok:false};let youMk=null;
function netChk(){const n=$('net');if(location.protocol==='file:'){n.textContent='⚠️ Ouvrez Proxima depuis son adresse internet (pas depuis le fichier) pour voir la carte.';n.hidden=false}
  else if(!navigator.onLine){n.textContent='📡 Pas de connexion Internet : la carte et les adresses en ont besoin.';n.hidden=false}else n.hidden=true}
addEventListener('offline',netChk);addEventListener('online',()=>{netChk();map.retry();map2.retry();toast('Connexion rétablie')});netChk();
function geoStart(){
  if(!navigator.geolocation){toast('GPS indisponible sur cet appareil');return}
  navigator.geolocation.getCurrentPosition(p=>{GEO.ok=true;if(!youMk)youMk=map.addMarker('<div class="me"></div>');youMk.set(p.coords.latitude,p.coords.longitude);toast('Position activée ✓')},
    e=>toast(e.code===1?'Position refusée : autorisez-la (cadenas de l\'adresse > Autorisations)':'Position introuvable, réessayez à l\'extérieur'),{enableHighAccuracy:true,timeout:15000});
}
$('gateOk').onclick=()=>{$('gate').hidden=true;geoStart()};$('gateNo').onclick=()=>{$('gate').hidden=true};
(async()=>{try{const s=await navigator.permissions.query({name:'geolocation'});if(s.state==='granted')geoStart();else if(s.state==='prompt')$('gate').hidden=false;else toast('Localisation bloquée : autorisez-la dans les réglages du navigateur')}catch(e){$('gate').hidden=false}})();

renderDrivers();renderMe();renderActs();
map.fit(D.filter(d=>d.st!=='off').map(d=>[d.lat,d.lon]));
if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
