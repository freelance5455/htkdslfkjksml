
function contact(){
 alert('للطلب والتواصل: أضف رقم الهاتف هنا');
}
