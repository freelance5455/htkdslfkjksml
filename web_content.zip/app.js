const $ = (id) => document.getElementById(id);
const toast = $("toast");
let toastTimer;
function notify(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 4200);
}
$("menuBtn").addEventListener("click", () => $("nav").classList.toggle("open"));
document.querySelectorAll("#nav a").forEach(a => a.addEventListener("click", () => $("nav").classList.remove("open")));
document.querySelectorAll("[data-notice]").forEach(button => button.addEventListener("click", () => notify(button.dataset.notice)));
$("year").textContent = new Date().getFullYear();

try {
  $("playerName").value = localStorage.getItem("dlsPlayerName") || "";
  $("playerTeam").value = localStorage.getItem("dlsPlayerTeam") || "";
} catch (_) {}

$("saveProfile").addEventListener("click", () => {
  const name = $("playerName").value.trim();
  const team = $("playerTeam").value.trim();
  if (!name) {
    $("profileMessage").textContent = "Entre d’abord ton nom de joueur.";
    $("playerName").focus();
    return;
  }
  try {
    localStorage.setItem("dlsPlayerName", name);
    localStorage.setItem("dlsPlayerTeam", team);
    $("profileMessage").textContent = `Profil enregistré sur cet appareil : ${name}${team ? " — " + team : ""}.`;
  } catch (_) {
    $("profileMessage").textContent = "Le navigateur ne permet pas l’enregistrement local.";
  }
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./service-worker.js").catch(() => {}));
}