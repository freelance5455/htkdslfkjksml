const KEY = "riu-code-tracker-v1";
let state = load();
function load(){try{return JSON.parse(localStorage.getItem(KEY))||{accounts:[],codes:[],claims:{}}}catch{return{accounts:[],codes:[],claims:{}}}}
function save(){localStorage.setItem(KEY,JSON.stringify(state));render()}
function id(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function toast(msg){const el=document.getElementById("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2200)}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===btn));
  document.querySelectorAll(".panel").forEach(x=>x.classList.toggle("hidden",x.id!==btn.dataset.tab));
}));
document.getElementById("accountForm").addEventListener("submit",e=>{
  e.preventDefault();const name=document.getElementById("accountName").value.trim();
  if(!name)return;if(state.accounts.some(a=>a.name.toLowerCase()===name.toLowerCase()))return toast("Essa conta já foi adicionada.");
  state.accounts.push({id:id(),name});e.target.reset();save();toast("Conta adicionada!");
});
document.getElementById("codeForm").addEventListener("submit",e=>{
  e.preventDefault();const name=document.getElementById("codeName").value.trim(),note=document.getElementById("codeNote").value.trim();
  if(!name)return;if(state.codes.some(c=>c.name.toLowerCase()===name.toLowerCase()))return toast("Esse código já existe.");
  state.codes.push({id:id(),name,note});e.target.reset();save();toast("Código adicionado!");
});
document.getElementById("accountFilter").addEventListener("input",renderMatrix);

function renderMatrix(){
 const wrap=document.getElementById("matrixWrap"),filter=document.getElementById("accountFilter").value.toLowerCase();
 const accounts=state.accounts.filter(a=>a.name.toLowerCase().includes(filter));
 if(!state.accounts.length||!state.codes.length){wrap.innerHTML='<div class="empty">Adicione pelo menos uma conta e um código na aba <b>Gerenciar</b> para começar.<br>Depois, marque a caixa quando o código já tiver sido resgatado naquela conta.</div>';return}
 if(!accounts.length){wrap.innerHTML='<div class="empty">Nenhuma conta encontrada.</div>';return}
 let html='<table class="matrix"><thead><tr><th>Conta / Código</th>'+state.codes.map(c=>`<th title="${esc(c.note||c.name)}">${esc(c.name)}</th>`).join("")+'</tr></thead><tbody>';
 for(const a of accounts){html+=`<tr><td><strong>${esc(a.name)}</strong><small>Conta Roblox</small></td>`;
  for(const c of state.codes){const checked=!!(state.claims[a.id]&&state.claims[a.id][c.id]);html+=`<td><input class="check" type="checkbox" aria-label="Marcar ${esc(c.name)} como resgatado em ${esc(a.name)}" data-account="${a.id}" data-code="${c.id}" ${checked?"checked":""}></td>`}
  html+='</tr>'}
 html+='</tbody></table>';wrap.innerHTML=html;
 wrap.querySelectorAll(".check").forEach(ch=>ch.addEventListener("change",()=>{
  const a=ch.dataset.account,c=ch.dataset.code;state.claims[a]??={};state.claims[a][c]=ch.checked;
  if(!ch.checked)delete state.claims[a][c];save();toast(ch.checked?"Resgate marcado!":"Marcação removida.");
 }));
}
function renderLists(){
 const al=document.getElementById("accountsList"),cl=document.getElementById("codesList");
 al.innerHTML=state.accounts.length?state.accounts.map(a=>`<div class="item"><span class="item-name">${esc(a.name)}</span><button class="mini" data-del-account="${a.id}">Excluir</button></div>`).join(""):'<p class="empty">Nenhuma conta ainda.</p>';
 cl.innerHTML=state.codes.length?state.codes.map(c=>`<div class="item"><span class="item-name">${esc(c.name)}<small>${esc(c.note||"Sem observação")}</small></span><button class="mini" data-del-code="${c.id}">Excluir</button></div>`).join(""):'<p class="empty">Nenhum código ainda.</p>';
 al.querySelectorAll("[data-del-account]").forEach(b=>b.onclick=()=>{if(confirm("Excluir esta conta e suas marcações?")){state.accounts=state.accounts.filter(a=>a.id!==b.dataset.delAccount);delete state.claims[b.dataset.delAccount];save();toast("Conta excluída.")}});
 cl.querySelectorAll("[data-del-code]").forEach(b=>b.onclick=()=>{if(confirm("Excluir este código e suas marcações?")){state.codes=state.codes.filter(c=>c.id!==b.dataset.delCode);Object.values(state.claims).forEach(row=>delete row[b.dataset.delCode]);save();toast("Código excluído.")}});
}
function render(){
 document.getElementById("totalCodes").textContent=state.codes.length;
 document.getElementById("totalAccounts").textContent=state.accounts.length;
 document.getElementById("totalClaims").textContent=Object.values(state.claims).reduce((n,row)=>n+Object.values(row).filter(Boolean).length,0);
 renderMatrix();renderLists();
}
document.getElementById("exportBtn").onclick=()=>{
 const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");
 a.href=url;a.download="riu-code-tracker-backup.json";a.click();URL.revokeObjectURL(url);toast("Backup exportado.");
};
document.getElementById("importFile").onchange=async e=>{
 const file=e.target.files[0];if(!file)return;
 try{const data=JSON.parse(await file.text());if(!Array.isArray(data.accounts)||!Array.isArray(data.codes)||typeof data.claims!=="object")throw Error();
  state=data;save();toast("Backup importado com sucesso!");
 }catch{toast("Arquivo inválido. Escolha um backup exportado pelo app.");}e.target.value="";
};
document.getElementById("resetBtn").onclick=()=>{if(confirm("Isso apagará todas as contas, códigos e marcações deste aparelho. Continuar?")){state={accounts:[],codes:[],claims:{}};save();toast("Dados apagados.")}};
render();