
const $ = id => document.getElementById(id);

let articulos = [];

try {
  articulos = JSON.parse(localStorage.getItem("miInventario")) || [];
  if (!Array.isArray(articulos)) articulos = [];
} catch {
  articulos = [];
}

function guardar() {
  localStorage.setItem("miInventario", JSON.stringify(articulos));
}

function incremento() {
  const personalizado = Number($("personalizado").value);
  return personalizado > 0
    ? Math.floor(personalizado)
    : Number($("incremento").value) || 1;
}

function escapar(texto) {
  return String(texto).replace(/[&<>"']/g, caracter => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[caracter]);
}

function renderizar() {
  const busqueda = $("buscar").value.trim().toLowerCase();

  const visibles = articulos.filter(a =>
    a.nombre.toLowerCase().includes(busqueda) ||
    a.descripcion.toLowerCase().includes(busqueda)
  );

  $("totalArticulos").textContent = articulos.length;
  $("totalUnidades").textContent = articulos.reduce(
    (total, a) => total + a.cantidad, 0
  );

  $("lista").innerHTML = visibles.map(a => `
    <article class="articulo">
      <h3>${escapar(a.nombre)}</h3>
      ${a.descripcion
        ? `<p class="descripcion">${escapar(a.descripcion)}</p>`
        : ""}
      <div class="controles">
        <button class="menos" data-accion="menos" data-id="${a.id}"
          aria-label="Restar">−</button>
        <span class="cantidad">${a.cantidad}</span>
        <button class="mas" data-accion="mas" data-id="${a.id}"
          aria-label="Sumar">+</button>
      </div>
      <div class="acciones">
        <button data-accion="editar" data-id="${a.id}">Editar</button>
        <button data-accion="eliminar" data-id="${a.id}">Eliminar</button>
      </div>
    </article>
  `).join("");

  $("vacio").hidden = visibles.length > 0;
  $("lista").hidden = visibles.length === 0;
}

$("formulario").addEventListener("submit", evento => {
  evento.preventDefault();

  const nombre = $("nombre").value.trim();
  const descripcion = $("descripcion").value.trim();
  const cantidad = Number($("cantidadInicial").value);

  if (!nombre || !Number.isSafeInteger(cantidad) || cantidad < 0) {
    alert("Introduce un nombre y una cantidad válida.");
    return;
  }

  articulos.push({
    id: Date.now().toString() + Math.random().toString(36).slice(2),
    nombre,
    descripcion,
    cantidad
  });

  guardar();
  $("formulario").reset();
  $("cantidadInicial").value = "0";
  renderizar();
});

$("lista").addEventListener("click", evento => {
  const boton = evento.target.closest("button[data-accion]");
  if (!boton) return;

  const articulo = articulos.find(a => a.id === boton.dataset.id);
  if (!articulo) return;

  switch (boton.dataset.accion) {
    case "mas":
      articulo.cantidad += incremento();
      break;

    case "menos":
      articulo.cantidad = Math.max(0, articulo.cantidad - incremento());
      break;

    case "editar": {
      const nombre = prompt("Nombre del artículo:", articulo.nombre);
      if (nombre === null || !nombre.trim()) return;

      const descripcion = prompt(
        "Descripción:", articulo.descripcion
      );
      if (descripcion === null) return;

      articulo.nombre = nombre.trim();
      articulo.descripcion = descripcion.trim();
      break;
    }

    case "eliminar":
      if (!confirm(`¿Eliminar "${articulo.nombre}"?`)) return;
      articulos = articulos.filter(a => a.id !== articulo.id);
      break;
  }

  guardar();
  renderizar();
});

$("buscar").addEventListener("input", renderizar);

$("exportar").addEventListener("click", () => {
  const archivo = new Blob(
    [JSON.stringify(articulos, null, 2)],
    { type: "application/json" }
  );

  const url = URL.createObjectURL(archivo);
  const enlace = document.createElement("a");
  enlace.href = url;
  enlace.download = "mi-inventario.json";
  enlace.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});

$("importarBtn").addEventListener("click", () => $("archivo").click());

$("archivo").addEventListener("change", async evento => {
  const archivo = evento.target.files[0];
  if (!archivo) return;

  try {
    const datos = JSON.parse(await archivo.text());

    if (!Array.isArray(datos) || !datos.every(a =>
      a &&
      typeof a.nombre === "string" &&
      typeof a.descripcion === "string" &&
      Number.isSafeInteger(a.cantidad) &&
      a.cantidad >= 0
    )) {
      throw new Error("Archivo no válido");
    }

    if (!confirm("¿Reemplazar el inventario actual por esta copia?")) {
      return;
    }

    articulos = datos.map(a => ({
      id: String(a.id || (
        Date.now() + Math.random()
      )),
      nombre: a.nombre,
      descripcion: a.descripcion,
      cantidad: a.cantidad
    }));

    guardar();
    renderizar();
    alert("Inventario importado correctamente.");
  } catch {
    alert("No se pudo importar. Comprueba el archivo JSON.");
  } finally {
    evento.target.value = "";
  }
});

renderizar();
