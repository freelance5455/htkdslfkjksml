const state={project:{name:"",client:"",date:new Date().toISOString().slice(0,10)},items:[],materials:{},saved:false};
const modules=[
["béton","🧱","Béton","Volume, ciment, sable, gravier, eau"],
["acier","🔩","Ferraillage","Barres, longueur, nombre, poids"],
["poteaux","🏗️","Poteaux","Béton, acier, étriers"],
["poutres","🏠","Poutres","Béton, armatures, étriers"],
["dalles","🧱","Dalles","Béton, treillis/armatures"],
["semelles","⬛","Semelles","Béton, ferraillage, excavation"],
["fondations","🕳️","Fondations","Fouilles, propreté, béton, remblai"],
["maconnerie","🧱","Maçonnerie","Blocs/briques + mortier"],
["mortier","🪣","Mortier","Ciment + sable + eau"],
["enduit","🧱","Enduit","Surface + ciment + sable"],
["peinture","🎨","Peinture","Surface + litres"],
["terrassement","🏗️","Terrassement","Déblai, remblai, terre"],
["conversion","🪨","Sable / Gravier","m³ ↔ tonnes ↔ kg"],
["transport","🚚","Transport","Quantité + voyages"],
["devis","💰","Devis","Quantité × prix unitaire"],
["recap","📊","Récapitulatif","Synthèse du projet"]
];

const density={sable:1.6,gravier:1.5,terre:1.7,beton:2.4};
const dosage={cement:350,sand:.40,gravel:.80,water:175};

const $=id=>document.getElementById(id);
function toast(t){$("toast").textContent=t;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),1800)}
function show(id){document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));$(id).classList.add("active");window.scrollTo(0,0)}
function num(id){return parseFloat($(id)?.value)||0}
function f(n,d=3){return Number(n||0).toLocaleString("fr-FR",{maximumFractionDigits:d})}
function moduleCard(m){return `<button class="module" data-module="${m[0]}"><span style="font-size:25px">${m[1]}</span><b>${m[2]}</b><small>${m[3]}</small></button>`}
$("moduleGrid").innerHTML=modules.map(moduleCard).join("");
document.querySelectorAll(".module").forEach(b=>b.onclick=()=>openModule(b.dataset.module));
$("homeBtn").onclick=()=>show("home");
$("backBtn").onclick=()=>show("home");
$("recapBack").onclick=()=>show("home");
$("quoteBack").onclick=()=>show("home");
$("newProjectBtn").onclick=()=>{state.project={name:"",client:"",date:new Date().toISOString().slice(0,10)};state.items=[];state.materials={};renderHome();toast("Nouveau projet créé")};
$("saveProjectBtn").onclick=saveProject;
$("loadProjectBtn").onclick=loadProject;

function openModule(type){
  if(type==="recap"){renderRecap();show("recap");return}
  if(type==="devis"){renderQuote();show("quote");return}
  $("moduleTitle").textContent=modules.find(x=>x[0]===type)?.[2]||"Module";
  $("moduleBody").innerHTML=renderModule(type);
  bindModule(type);show("calculator");
}

function renderModule(t){
const head=`<div class="card"><label>Nom du projet</label><input id="projectName" value="${state.project.name}" placeholder="Ex. Immeuble R+3"><label>Client</label><input id="client" value="${state.project.client}" placeholder="Nom du client"><label>Date</label><input id="date" type="date" value="${state.project.date}"></div>`;
if(["béton","poteaux","poutres","dalles","semelles"].includes(t)) return head+concreteForm(t);
if(t==="acier") return head+steelForm();
if(t==="fondations") return head+foundationForm();
if(t==="maconnerie") return head+masonryForm();
if(t==="mortier") return head+mortarForm();
if(t==="enduit") return head+plasterForm();
if(t==="peinture") return head+paintForm();
if(t==="terrassement") return head+earthForm();
if(t==="conversion") return head+conversionForm();
if(t==="transport") return head+transportForm();
return head;
}
function commonSave(){state.project.name=$("projectName").value;state.project.client=$("client").value;state.project.date=$("date").value}
function concreteForm(t){
let title={béton:"Élément béton libre",poteaux:"Poteau",poutres:"Poutre",dalles:"Dalle",semelles:"Semelle"}[t];
return `<div class="card"><h3>${title}</h3><div class="form-grid">
<label>Longueur (m)<input id="L" type="number" step="0.01"></label>
<label>Largeur (m)<input id="W" type="number" step="0.01"></label>
<label>Hauteur/épaisseur (m)<input id="H" type="number" step="0.01"></label>
<label>Nombre<input id="N" type="number" value="1" step="1"></label>
<label>Ciment (kg/m³)<input id="cement" type="number" value="350"></label>
<label>Sable (m³/m³)<input id="sand" type="number" value="0.40" step="0.01"></label>
<label>Gravier (m³/m³)<input id="gravel" type="number" value="0.80" step="0.01"></label>
<label>Eau (L/m³)<input id="water" type="number" value="175"></label>
</div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div>
<div class="notice">Résultats indicatifs. Les dimensions structurelles et le ferraillage doivent être validés par l’ingénieur responsable selon les charges, le sol et la norme applicable.</div></div>`
}
function steelForm(){return `<div class="card"><div class="form-grid">
<label>Diamètre (mm)<input id="D" type="number" value="12"></label><label>Longueur d'une barre (m)<input id="BL" type="number" value="12"></label>
<label>Nombre de barres<input id="BN" type="number" value="1"></label><label>Coefficient de poids (kg/m)<input id="KW" type="number" step="0.001" value="0.888"></label>
</div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div></div>`}
function foundationForm(){return `<div class="card"><div class="form-grid">
<label>Longueur fouille (m)<input id="L" type="number"></label><label>Largeur fouille (m)<input id="W" type="number"></label><label>Profondeur (m)<input id="H" type="number"></label>
<label>Volume béton de propreté (m³)<input id="VP" type="number" value="0"></label><label>Volume béton armé (m³)<input id="VA" type="number" value="0"></label><label>Remblai estimé (m³)<input id="VR" type="number" value="0"></label>
</div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div></div>`}
function masonryForm(){return `<div class="card"><div class="form-grid">
<label>Longueur mur (m)<input id="L" type="number"></label><label>Hauteur mur (m)<input id="H" type="number"></label><label>Ouvertures à déduire (m²)<input id="O" type="number" value="0"></label>
<label>Blocs par m²<input id="B" type="number" value="12.5"></label><label>Mortier par m² (m³)<input id="M" type="number" value="0.02" step="0.001"></label><label>Nombre de murs<input id="N" type="number" value="1"></label>
</div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div></div>`}
function mortarForm(){return `<div class="card"><div class="form-grid"><label>Volume mortier (m³)<input id="V" type="number"></label><label>Ciment (kg/m³)<input id="C" type="number" value="300"></label><label>Sable (m³/m³)<input id="S" type="number" value="1.2" step=".01"></label><label>Eau (L/m³)<input id="E" type="number" value="180"></label></div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div></div>`}
function plasterForm(){return `<div class="card"><div class="form-grid"><label>Surface (m²)<input id="A" type="number"></label><label>Épaisseur (mm)<input id="T" type="number" value="15"></label><label>Ciment (kg/m³)<input id="C" type="number" value="300"></label><label>Sable (m³/m³)<input id="S" type="number" value="1.2"></label></div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div></div>`}
function paintForm(){return `<div class="card"><div class="form-grid"><label>Surface (m²)<input id="A" type="number"></label><label>Nombre de couches<input id="N" type="number" value="2"></label><label>Rendement (m²/L/couche)<input id="R" type="number" value="10"></label><label>Pertes (%)<input id="P" type="number" value="10"></label></div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div></div>`}
function earthForm(){return `<div class="card"><div class="form-grid"><label>Longueur (m)<input id="L" type="number"></label><label>Largeur (m)<input id="W" type="number"></label><label>Profondeur (m)<input id="H" type="number"></label><label>Remblai (m³)<input id="R" type="number" value="0"></label><label>Facteur foisonnement (%)<input id="F" type="number" value="15"></label></div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div></div>`}
function conversionForm(){return `<div class="card"><div class="form-grid"><label>Matériau<select id="mat"><option value="sable">Sable</option><option value="gravier">Gravier</option><option value="terre">Terre</option><option value="beton">Béton</option></select></label><label>Volume (m³)<input id="V" type="number"></label></div><div class="actions"><button class="btn" id="calc">Convertir</button></div><div id="out"></div></div>`}
function transportForm(){return `<div class="card"><div class="form-grid"><label>Quantité totale<input id="Q" type="number"></label><label>Unité<input id="U" value="m³"></label><label>Capacité camion<input id="C" type="number"></label><label>Prix par voyage<input id="P" type="number"></label></div><div class="actions"><button class="btn" id="calc">Calculer</button><button class="btn secondary" id="add">Ajouter au projet</button></div><div id="out"></div></div>`}

function bindModule(t){
commonSave();
const calc=$("calc"); if(!calc)return;
calc.onclick=()=>{
 let r={}; 
 if(["béton","poteaux","poutres","dalles","semelles"].includes(t)){
   let v=num("L")*num("W")*num("H")*Math.max(1,num("N"));r={volume:v,cement:v*num("cement"),bags:v*num("cement")/50,sand:v*num("sand"),gravel:v*num("gravel"),water:v*num("water")};
   $("out").innerHTML=resultHTML(r);
   calc._result=r;
 } else if(t==="acier"){
   let total=num("BL")*num("BN")*num("KW");r={length:num("BL")*num("BN"),weight:total,bars:num("BN"),diameter:num("D")};$("out").innerHTML=resultHTML(r);calc._result=r;
 } else if(t==="fondations"){
   let fouille=num("L")*num("W")*num("H");r={fouille,bp:num("VP"),ba:num("VA"),remblai:num("VR")};$("out").innerHTML=resultHTML(r);calc._result=r;
 } else if(t==="maconnerie"){
   let area=Math.max(0,num("L")*num("H")*Math.max(1,num("N"))-num("O"));r={surface:area,blocks:area*num("B"),mortar:area*num("M")};$("out").innerHTML=resultHTML(r);calc._result=r;
 } else if(t==="mortier"){
   let v=num("V");r={volume:v,cement:v*num("C"),bags:v*num("C")/50,sand:v*num("S"),water:v*num("E")};$("out").innerHTML=resultHTML(r);calc._result=r;
 } else if(t==="enduit"){
   let v=num("A")*num("T")/1000;r={surface:num("A"),volume:v,cement:v*num("C"),sand:v*num("S")};$("out").innerHTML=resultHTML(r);calc._result=r;
 } else if(t==="peinture"){
   let litres=num("A")*num("N")/num("R")*(1+num("P")/100);r={surface:num("A"),litres};$("out").innerHTML=resultHTML(r);calc._result=r;
 } else if(t==="terrassement"){
   let v=num("L")*num("W")*num("H"),exc=v*(1+num("F")/100);r={volume:v,excavationWithSwelling:exc,backfill:num("R")};$("out").innerHTML=resultHTML(r);calc._result=r;
 } else if(t==="conversion"){
   let v=num("V"),tonnes=v*density[$("mat").value],kg=tonnes*1000;r={volume:v,tonnes,kg};$("out").innerHTML=resultHTML(r);calc._result=r;
 } else if(t==="transport"){
   let trips=Math.ceil(num("Q")/num("C"));r={quantity:num("Q"),unit:$("U").value,trips,cost:trips*num("P")};$("out").innerHTML=resultHTML(r);calc._result=r;
 }
};
if($("add"))$("add").onclick=()=>{if(!calc._result){calc.click()}let r=calc._result;if(!r){toast("Effectue d'abord le calcul");return}state.items.push({module:t,date:new Date().toISOString(),result:r});commonSave();state.saved=false;renderHome();toast("Ajouté au projet")};
}
function resultHTML(r){return `<div class="result"><strong>Résultat</strong><pre style="white-space:pre-wrap;font-family:inherit;margin-bottom:0">${Object.entries(r).map(([k,v])=>`${k} : ${typeof v==="number"?f(v):v}`).join("\\n")}</pre></div>`}

function renderHome(){
$("projectSummary").innerHTML=state.items.length?`<b>${state.project.name||"Projet sans nom"}</b><br>${state.items.length} élément(s) calculé(s)<br>Client : ${state.project.client||"—"}`:"Aucun calcul enregistré.";
}
function saveProject(){
commonProjectInputs();
localStorage.setItem("klingBtpProject",JSON.stringify(state));state.saved=true;toast("Projet enregistré sur cet appareil");renderHome();
}
function commonProjectInputs(){ /* project data already maintained by forms */ }
function loadProject(){
let s=localStorage.getItem("klingBtpProject");if(!s){toast("Aucun projet sauvegardé");return}
try{Object.assign(state,JSON.parse(s));renderHome();toast("Projet chargé")}catch(e){toast("Erreur de chargement")}
}
function renderRecap(){
let rows=state.items.map((x,i)=>`<tr><td>${i+1}</td><td>${x.module}</td><td>${Object.entries(x.result).map(([k,v])=>`${k}: ${typeof v==="number"?f(v):v}`).join("<br>")}</td><td><button class="btn danger" onclick="removeItem(${i})">Supprimer</button></td></tr>`).join("");
$("recapBody").innerHTML=`<div class="card"><h3>${state.project.name||"Projet sans nom"}</h3><p>Client : ${state.project.client||"—"} | Date : ${state.project.date}</p><table><tr><th>#</th><th>Module</th><th>Résultats</th><th>Action</th></tr>${rows||"<tr><td colspan=4>Aucun élément.</td></tr>"}</table><div class="actions"><button class="btn" onclick="window.print()">Imprimer / PDF</button><button class="btn secondary" onclick="exportCSV()">Exporter Excel (CSV)</button><button class="btn secondary" onclick="openModule('devis')">Créer le devis</button></div><div class="notice">Document d'aide au métré. Les résultats structurels doivent être contrôlés par un ingénieur compétent avant exécution.</div></div>`;
}
function removeItem(i){state.items.splice(i,1);renderRecap();renderHome();toast("Élément supprimé")}
function renderQuote(){
let items=state.items.map((x,i)=>`<tr><td>${i+1}</td><td>${x.module}</td><td>${Object.values(x.result).find(v=>typeof v==="number")||0}</td><td><input class="price" data-i="${i}" type="number" value="0"></td><td class="amount" data-i="${i}">0</td></tr>`).join("");
$("quoteBody").innerHTML=`<div class="card"><label>Numéro de devis</label><input id="quoteNo" value="KLING-${new Date().getFullYear()}-001"><table><tr><th>#</th><th>Désignation</th><th>Quantité</th><th>Prix unitaire</th><th>Montant</th></tr>${items||"<tr><td colspan=5>Aucun poste.</td></tr>"}</table><div class="form-grid"><label>Main-d'œuvre<input id="labor" type="number" value="0"></label><label>Transport<input id="transportCost" type="number" value="0"></label><label>Autres<input id="other" type="number" value="0"></label></div><div class="total">Total : <span id="grandTotal">0</span> $</div><div class="actions"><button class="btn" id="calcQuote">Calculer le devis</button><button class="btn secondary" id="pdfQuote">Imprimer / PDF</button><button class="btn secondary" id="csvQuote">Exporter CSV</button></div></div>`;
document.querySelectorAll(".price").forEach(x=>x.oninput=calcQuote);["labor","transportCost","other"].forEach(id=>$(id).oninput=calcQuote);$("calcQuote").onclick=calcQuote;$("pdfQuote").onclick=()=>window.print();$("csvQuote").onclick=exportQuoteCSV;
}
function calcQuote(){
let total=0;document.querySelectorAll(".price").forEach(p=>{let q=parseFloat(p.closest("tr").children[2].textContent)||0,a=q*(parseFloat(p.value)||0);document.querySelector(`.amount[data-i="${p.dataset.i}"]`).textContent=f(a,2);total+=a});total+=num("labor")+num("transportCost")+num("other");$("grandTotal").textContent=f(total,2)
}
function download(name,text,type="text/csv"){let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function exportCSV(){
let rows=[["Projet",state.project.name],["Client",state.project.client],["Date",state.project.date],[],["Module","Résultats"]];
state.items.forEach(x=>rows.push([x.module,Object.entries(x.result).map(([k,v])=>`${k}=${v}`).join(" | ")]));
download("KLING_recapitulatif.csv",rows.map(r=>r.map(v=>`"${String(v??"").replaceAll('"','""')}"`).join(";")).join("\\n"));
toast("CSV téléchargé")
}
function exportQuoteCSV(){
let rows=[["Projet",state.project.name],["Devis",$("quoteNo").value],[],["Module","Quantité","Prix unitaire","Montant"]];
document.querySelectorAll(".price").forEach(p=>{let tr=p.closest("tr");rows.push([tr.children[1].textContent,tr.children[2].textContent,p.value,tr.querySelector(".amount").textContent])});
rows.push(["Main-d'œuvre","","",num("labor")],["Transport","","",num("transportCost")],["Autres","","",num("other")],["TOTAL","","",$("grandTotal").textContent]);
download("KLING_devis.csv",rows.map(r=>r.map(v=>`"${String(v??"").replaceAll('"','""')}"`).join(";")).join("\\n"));toast("Devis CSV téléchargé")
}
renderHome();
