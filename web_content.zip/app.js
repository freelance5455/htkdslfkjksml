(function () {
  'use strict';

  var LEVELS = [100, 125, 150, 175, 200];

  var audio = document.getElementById('audio');
  var fileInput = document.getElementById('fileInput');
  var levelsEl = document.getElementById('levels');
  var slider = document.getElementById('boostSlider');
  var boostValue = document.getElementById('boostValue');
  var titleEl = document.getElementById('trackTitle');
  var seek = document.getElementById('seek');
  var timeEl = document.getElementById('time');
  var playBtn = document.getElementById('play');
  var prevBtn = document.getElementById('prev');
  var nextBtn = document.getElementById('next');
  var limiterBox = document.getElementById('limiter');
  var listEl = document.getElementById('playlist');

  var ctx = null, source = null, gainNode = null, limiter = null;
  var tracks = [];
  var index = -1;
  var boost = 100;
  var currentUrl = null;
  var seeking = false;

  // ---------- Audio graph: <audio> -> gain (boost) -> limiter -> speakers ----------

  function initAudio() {
    if (ctx) return;
    var AC = window.AudioContext || window.webkitAudioContext;
    ctx = new AC();
    source = ctx.createMediaElementSource(audio);
    gainNode = ctx.createGain();
    limiter = ctx.createDynamicsCompressor();
    limiter.threshold.value = -6;
    limiter.knee.value = 6;
    limiter.ratio.value = 12;
    limiter.attack.value = 0.003;
    limiter.release.value = 0.1;
    wire();
    applyBoost();
  }

  function wire() {
    source.disconnect();
    gainNode.disconnect();
    limiter.disconnect();
    source.connect(gainNode);
    if (limiterBox.checked) {
      gainNode.connect(limiter);
      limiter.connect(ctx.destination);
    } else {
      gainNode.connect(ctx.destination);
    }
  }

  function applyBoost() {
    if (gainNode) gainNode.gain.value = boost / 100;
  }

  function setBoost(pct) {
    boost = pct;
    boostValue.textContent = pct + '%';
    slider.value = pct;
    var buttons = levelsEl.children;
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].classList.toggle('active', LEVELS[i] === pct);
    }
    applyBoost();
  }

  // ---------- UI setup ----------

  LEVELS.forEach(function (pct) {
    var b = document.createElement('button');
    b.textContent = pct + '%';
    b.addEventListener('click', function () { setBoost(pct); });
    levelsEl.appendChild(b);
  });

  slider.addEventListener('input', function () { setBoost(parseInt(slider.value, 10)); });

  limiterBox.addEventListener('change', function () { if (ctx) wire(); });

  // ---------- Playlist / playback ----------

  fileInput.addEventListener('change', function () {
    var files = Array.prototype.slice.call(fileInput.files);
    if (!files.length) return;
    tracks = files;
    renderList();
    play(0);
  });

  function renderList() {
    listEl.innerHTML = '';
    tracks.forEach(function (f, i) {
      var li = document.createElement('li');
      li.textContent = f.name;
      li.className = i === index ? 'current' : '';
      li.addEventListener('click', function () { play(i); });
      listEl.appendChild(li);
    });
  }

  function play(i) {
    if (!tracks.length) return;
    index = (i + tracks.length) % tracks.length;
    initAudio();
    if (currentUrl) URL.revokeObjectURL(currentUrl);
    currentUrl = URL.createObjectURL(tracks[index]);
    audio.src = currentUrl;
    titleEl.textContent = tracks[index].name;
    renderList();
    ctx.resume();
    audio.play().catch(function () {});
  }

  playBtn.addEventListener('click', function () {
    if (!tracks.length) { fileInput.click(); return; }
    initAudio();
    ctx.resume();
    if (audio.paused) {
      if (!audio.src) { play(Math.max(index, 0)); } else { audio.play(); }
    } else {
      audio.pause();
    }
  });

  prevBtn.addEventListener('click', function () { play(index - 1); });
  nextBtn.addEventListener('click', function () { play(index + 1); });

  audio.addEventListener('play', function () { playBtn.textContent = 'Pause'; });
  audio.addEventListener('pause', function () { playBtn.textContent = 'Play'; });
  audio.addEventListener('ended', function () { play(index + 1); });

  // ---------- Seek bar ----------

  function fmt(sec) {
    if (!isFinite(sec)) return '0:00';
    var s = Math.floor(sec);
    return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2);
  }

  audio.addEventListener('timeupdate', function () {
    if (!seeking && audio.duration) seek.value = (audio.currentTime / audio.duration) * 100;
    timeEl.textContent = fmt(audio.currentTime) + ' / ' + fmt(audio.duration);
  });

  seek.addEventListener('input', function () {
    seeking = true;
    if (audio.duration) audio.currentTime = (seek.value / 100) * audio.duration;
  });
  seek.addEventListener('change', function () { seeking = false; });

  setBoost(100);
})();
