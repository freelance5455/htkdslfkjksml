const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const KEY="khetcycle_state_v2";
const DEMO_KEY="khetcycle_demo";
const demoListings=[
{id:"d1",material:"Sugarcane Residue",crop:"Sugarcane",quantity:500,unit:"kg",location:"Nashik, Maharashtra",availability:"Available now",status:"active",emoji:"🌾",description:"Clean sugarcane crop residue suitable for verified biomass and agricultural processing uses.",farmer:"Demo Farmer"},
{id:"d2",material:"Wheat Straw",crop:"Wheat",quantity:300,unit:"kg",location:"Pune, Maharashtra",availability:"Available now",status:"active",emoji:"🌾",description:"Dry wheat straw, stored under cover.",farmer:"Demo Farmer"},
{id:"d3",material:"Cotton Residue",crop:"Cotton",quantity:250,unit:"kg",location:"Ahmednagar, Maharashtra",availability:"Available in 3 days",status:"active",emoji:"🌿",description:"Cotton crop residue from the latest harvest.",farmer:"Demo Farmer"},
{id:"d4",material:"Rice Straw",crop:"Rice",quantity:400,unit:"kg",location:"Kolhapur, Maharashtra",availability:"Available now",status:"active",emoji:"🌾",description:"Rice straw available for suitable downstream uses.",farmer:"Demo Farmer"}];

let state=loadState();
let screen="dashboard";
let selectedListing=null;
let currentAuth="login";
let aiResult=null;

function loadState(){
  try{
    const x=JSON.parse(localStorage.getItem(KEY)||"null");
    if(x) return x;
  }catch(e){}
  return {user:null,users:[],listings:demoListings,requests:[],notifications:[],saved:[],demo:false};
}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function initials(name="User"){return name.trim().split(/\s+/).map(x=>x[0]).slice(0,2).join("").toUpperCase()}
function escapeHtml(v=""){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function show(id){$("#splash").classList.toggle("hidden",id!=="splash");$("#authView").classList.toggle("hidden",id!=="auth");$("#mainView").classList.toggle("hidden",id!=="main")}
function boot(){
  setTimeout(()=>{if(state.user) showMain(); else show("auth")},800);
}
function showMain(){
  show("main"); renderNav(); renderScreen();
  $("#profileTop").textContent=initials(state.user?.name||"U");
  updateNotifyDot();
}
function renderNav(){
  const buyer=state.user?.role==="buyer";
  const items=buyer?[
    ["dashboard","⌂","Marketplace"],["requests","↗","My Requests"],["saved","♡","Saved Listings"],["notifications","🔔","Notifications"]
  ]:[
    ["dashboard","⌂","Dashboard"],["marketplace","◈","Marketplace"],["add","＋","Add Crop Residue"],["listings","▤","My Listings"],["requests","↗","Requests"],["notifications","🔔","Notifications"]
  ];
  $("#nav").innerHTML=items.map(x=>`<button class="nav-item ${screen===x[0]?"active":""}" data-screen="${x[0]}">${x[1]} <span>${x[2]}</span></button>`).join("");
  $$(".nav-item[data-screen]").forEach(b=>b.onclick=()=>{screen=b.dataset.screen;$("#sidebar").classList.remove("open");renderNav();renderScreen()});
}
function renderScreen(){
  const c=$("#content");
  const buyer=state.user?.role==="buyer";
  if(screen==="dashboard") c.innerHTML=buyer?buyerDashboard():farmerDashboard();
  else if(screen==="marketplace") c.innerHTML=marketplace();
  else if(screen==="add") c.innerHTML=addResidue();
  else if(screen==="listings") c.innerHTML=myListings();
  else if(screen==="requests") c.innerHTML=requestsScreen();
  else if(screen==="saved") c.innerHTML=savedScreen();
  else if(screen==="notifications") c.innerHTML=notificationsScreen();
  else if(screen==="profile") c.innerHTML=profileScreen();
  bindScreen();
}
function head(title,sub,button=""){
  return `<div class="page-head"><div><h1>${title}</h1><p>${sub}</p></div>${button}</div>`;
}
function farmerDashboard(){
  const mine=state.listings.filter(x=>x.farmerId===state.user?.id || (state.demo&&x.farmer==="Demo Farmer"));
  const req=state.requests.filter(x=>x.farmerId===state.user?.id);
  return head("Good evening, "+escapeHtml(state.user?.name||"Farmer"),"Manage your crop residues and buyer requests.",`<button class="primary" data-go="add">＋ Add Crop Residue</button>`)
  +`<section class="hero"><div><h2>Turn crop residue into value.</h2><p>List what you have, reach relevant buyers and reduce waste.</p></div><button class="primary" data-go="add">Create a listing</button></section>
  <div class="stats"><div class="stat"><small>Active listings</small><strong>${mine.filter(x=>x.status==="active").length}</strong></div><div class="stat"><small>Total quantity</small><strong>${mine.reduce((a,x)=>a+Number(x.quantity||0),0)} kg</strong></div><div class="stat"><small>Requests received</small><strong>${req.length}</strong></div><div class="stat"><small>Completed</small><strong>${req.filter(x=>x.status==="completed").length}</strong></div></div>
  <div class="grid-2"><section class="panel"><h3>Recent listings</h3>${mine.slice(-4).reverse().map(listingRow).join("")||empty("No listings yet.","Add your first crop residue.")}</section>
  <section class="panel"><h3>Quick actions</h3><div class="two-col"><button class="secondary" data-go="add">📷 Scan residue</button><button class="secondary" data-go="marketplace">🔎 Find buyers</button><button class="secondary" data-go="listings">▤ My listings</button><button class="secondary" data-go="requests">↗ Requests</button></div></section></div>`;
}
function buyerDashboard(){
  return head("Discover agricultural materials","Find crop residues from suppliers across your marketplace.",`<button class="primary" data-go="marketplace">Browse marketplace</button>`)
  +`<section class="hero"><div><h2>Find the material you need.</h2><p>Search by crop residue, quantity and location.</p></div><button class="primary" data-go="marketplace">Explore listings</button></section>
  <div class="stats"><div class="stat"><small>Available listings</small><strong>${state.listings.filter(x=>x.status==="active").length}</strong></div><div class="stat"><small>Requests sent</small><strong>${state.requests.filter(x=>x.buyerId===state.user?.id).length}</strong></div><div class="stat"><small>Accepted</small><strong>${state.requests.filter(x=>x.buyerId===state.user?.id&&x.status==="accepted").length}</strong></div><div class="stat"><small>Saved</small><strong>${state.saved.length}</strong></div></div>
  <section class="panel"><h3>Recommended for you</h3><div class="listing-grid">${state.listings.filter(x=>x.status==="active").slice(0,3).map(card).join("")}</div></section>`;
}
function marketplace(){
  return head("Marketplace","Search crop residues and discover relevant suppliers.")
  +`<div class="toolbar"><input id="marketSearch" class="search" placeholder="Search sugarcane, wheat, rice..." value="${escapeHtml(window.marketQ||"")}"><button class="outline" id="filterBtn">⚙ Filters</button></div>
  <div class="chips">${["All","Sugarcane","Wheat","Rice","Cotton","Maize"].map(x=>`<button class="chip ${(!window.marketCrop&&x==="All")||(window.marketCrop===x)?"active":""}" data-crop="${x}">${x}</button>`).join("")}</div>
  <div id="marketResults" class="listing-grid" style="margin-top:18px">${marketCards()}</div>`;
}
function marketCards(){
  let q=(window.marketQ||"").toLowerCase(), crop=window.marketCrop||"All";
  let a=state.listings.filter(x=>x.status==="active"&&(crop==="All"||x.crop===crop)&&(!q||`${x.material} ${x.crop} ${x.location}`.toLowerCase().includes(q)));
  return a.length?a.map(card).join(""):empty("No matching materials found.","Try another crop or search term.");
}
function card(x){
  const match=matchScore(x), saved=state.saved.includes(x.id);
  return `<article class="listing"><div class="listing-img">${x.emoji||"🌾"}</div><div class="listing-body"><div style="display:flex;justify-content:space-between;gap:8px"><div><h3>${escapeHtml(x.material)}</h3><div class="meta">${x.quantity} ${x.unit} · ${escapeHtml(x.location)}</div></div><button class="icon-btn save-btn" data-save="${x.id}">${saved?"♥":"♡"}</button></div><div class="meta">${escapeHtml(x.availability)}</div><div class="listing-foot"><span class="badge">${match}% Match</span><button class="outline view-btn" data-id="${x.id}">View details</button></div></div></article>`;
}
function listingRow(x){
 return `<div class="request"><div><strong>${escapeHtml(x.material)}</strong><div class="meta">${x.quantity} ${x.unit} · ${escapeHtml(x.location)}</div></div><div><span class="badge">${escapeHtml(x.status)}</span> <button class="outline view-btn" data-id="${x.id}">View</button></div></div>`;
}
function addResidue(){
 return head("Add Crop Residue","Use a photo for AI-assisted identification, then confirm the details.")
 +`<div class="steps"><span class="step active"></span><span class="step"></span><span class="step"></span></div>
 <div class="two-col"><section class="panel"><h3>1. Capture residue</h3><div class="upload"><div id="uploadArea"><div style="font-size:48px">📷</div><strong>Take a photo or choose from gallery</strong><p class="muted">AI analysis is an estimate and must be confirmed.</p><input id="photoInput" type="file" accept="image/*" capture="environment" hidden><button class="primary" id="choosePhoto">Choose photo</button></div><img id="photoPreview" class="preview hidden"></div><div id="aiPanel" class="ai-box hidden" style="margin-top:15px"></div></section>
 <section class="panel"><h3>2. Listing details</h3><form id="listingForm" class="form-grid">
 <div class="field"><label>Material</label><input id="material" required placeholder="e.g. Sugarcane Residue"></div>
 <div class="field"><label>Crop</label><select id="crop"><option>Sugarcane</option><option>Wheat</option><option>Rice</option><option>Cotton</option><option>Maize</option><option>Groundnut</option><option>Banana</option><option>Soybean</option><option>Other</option></select></div>
 <div class="field"><label>Quantity</label><input id="qty" type="number" min="1" required placeholder="500"></div>
 <div class="field"><label>Unit</label><select id="unit"><option>kg</option><option>quintal</option><option>tonne</option></select></div>
 <div class="field full-field"><label>Location</label><input id="location" required value="${escapeHtml(state.user?.location||"Nashik, Maharashtra")}"></div>
 <div class="field"><label>Availability</label><select id="availability"><option>Available now</option><option>Available in 3 days</option><option>Available in 7 days</option></select></div>
 <div class="field"><label>Expected price (optional)</label><input id="price" type="number" min="0" placeholder="₹ per unit"></div>
 <div class="field full-field"><label>Description</label><textarea id="desc" rows="4" placeholder="Describe condition, storage and other useful details."></textarea></div>
 <div class="full-field" style="display:flex;gap:10px;justify-content:flex-end"><button type="button" class="outline" data-go="dashboard">Cancel</button><button class="primary" type="submit">Publish Listing</button></div>
 </form></section></div>`;
}
function myListings(){
 const a=state.listings.filter(x=>x.farmerId===state.user?.id || (state.demo&&x.farmer==="Demo Farmer"));
 return head("My Listings","Manage the crop residues you have published.",`<button class="primary" data-go="add">＋ Add Crop Residue</button>`)
 +`<div class="listing-grid">${a.map(card).join("")||empty("No active listings yet.","Create your first listing.")}</div>`;
}
function requestsScreen(){
 const buyer=state.user?.role==="buyer";
 const a=state.requests.filter(x=>buyer?x.buyerId===state.user?.id:x.farmerId===state.user?.id);
 return head(buyer?"My Requests":"Buyer Requests",buyer?"Track your purchase requests.":"Review and respond to requests from buyers.")
 +`${a.length?a.map(requestCard).join(""):empty(buyer?"No requests yet.":"No buyer requests yet.","Requests will appear here when activity starts.")}`;
}
function requestCard(x){
 const l=state.listings.find(z=>z.id===x.listingId);
 const buyer=state.user?.role==="buyer";
 return `<div class="request"><div><strong>${escapeHtml(l?.material||x.material||"Listing")}</strong><div class="meta">${x.requestedQuantity} kg · ${escapeHtml(x.message||"No message")}</div><div class="meta">${buyer?"Farmer":"Buyer"}: ${escapeHtml(buyer?(x.farmerName||"Farmer"):(x.buyerName||"Buyer"))}</div></div><div style="text-align:right"><div class="status ${x.status}">${escapeHtml(x.status)}</div>${!buyer&&x.status==="pending"?`<div style="margin-top:8px;display:flex;gap:6px"><button class="primary accept" data-request="${x.id}">Accept</button><button class="outline reject" data-request="${x.id}">Reject</button></div>`:""}</div></div>`;
}
function savedScreen(){
 const a=state.listings.filter(x=>state.saved.includes(x.id));
 return head("Saved Listings","Materials you bookmarked for later.")+`<div class="listing-grid">${a.map(card).join("")||empty("No saved listings.","Tap ♡ on a marketplace listing to save it.")}</div>`;
}
function notificationsScreen(){
 const a=state.notifications.slice().reverse();
 return head("Notifications","Updates about your listings and requests.")+(a.length?a.map(n=>`<div class="request"><div><strong>${escapeHtml(n.title)}</strong><div class="meta">${escapeHtml(n.message)}</div></div><div class="meta">${new Date(n.createdAt).toLocaleString()}</div></div>`).join(""):empty("You're all caught up.","New activity will appear here."));
}
function profileScreen(){
 const u=state.user||{};
 return head("Profile & Settings","Manage your KhetCycle account.")
 +`<section class="panel"><div class="profile-card"><div class="profile-big">${initials(u.name||"User")}</div><div><h2 style="margin:0">${escapeHtml(u.name||"User")}</h2><div class="muted">${escapeHtml(u.role||"user")} · ${escapeHtml(u.location||"")}</div></div></div><div style="margin-top:20px">
 <div class="kv"><b>Email</b><span>${escapeHtml(u.email||"")}</span></div><div class="kv"><b>Mobile</b><span>${escapeHtml(u.phone||"Not provided")}</span></div><div class="kv"><b>Account mode</b><span>${state.demo?"Demo Mode":"Local account / Firebase-ready"}</span></div></div></section>
 <section class="panel" style="margin-top:16px"><h3>Account</h3><div style="display:flex;gap:10px;flex-wrap:wrap"><button class="outline" id="editProfile">Edit profile</button><button class="outline" id="changePass">Change password</button><button class="outline" data-go="notifications">Notification settings</button><button class="outline" id="aboutBtn">About KhetCycle</button><button class="primary" id="logout2">Log out</button></div></section>`;
}
function empty(title,sub){return `<div style="padding:28px;text-align:center;color:var(--muted);grid-column:1/-1"><div style="font-size:38px;margin-bottom:8px">🌱</div><strong style="display:block;color:var(--ink);font-size:17px">${title}</strong><span>${sub}</span></div>`}
function matchScore(x){
 let score=72;
 if((state.user?.location||"").split(",")[0].toLowerCase()===x.location.split(",")[0].toLowerCase()) score+=18;
 if(x.availability==="Available now") score+=5;
 if(x.quantity>=200) score+=3;
 return Math.min(score,98);
}
function bindScreen(){
 $$("[data-go]").forEach(b=>b.onclick=()=>{screen=b.dataset.go;renderNav();renderScreen()});
 $$(".view-btn").forEach(b=>b.onclick=()=>openListing(b.dataset.id));
 $$(".save-btn").forEach(b=>b.onclick=()=>{const id=b.dataset.save;state.saved=state.saved.includes(id)?state.saved.filter(x=>x!==id):[...state.saved,id];save();renderScreen()});
 $$(".accept").forEach(b=>b.onclick=()=>setRequest(b.dataset.request,"accepted"));
 $$(".reject").forEach(b=>b.onclick=()=>setRequest(b.dataset.request,"rejected"));
 const s=$("#marketSearch");if(s)s.oninput=e=>{window.marketQ=e.target.value;$("#marketResults").innerHTML=marketCards();bindScreen()};
 $$("[data-crop]").forEach(b=>b.onclick=()=>{window.marketCrop=b.dataset.crop==="All"?"":b.dataset.crop;renderScreen()});
 const fb=$("#filterBtn");if(fb)fb.onclick=()=>toast("Filters: material, quantity, location and availability are ready in the marketplace.");
 const cp=$("#choosePhoto"),pi=$("#photoInput");if(cp&&pi){cp.onclick=()=>pi.click();pi.onchange=()=>handlePhoto(pi.files?.[0])}
 const lf=$("#listingForm");if(lf)lf.onsubmit=publishListing;
 $("#logout2")?.addEventListener("click",logout);
 $("#editProfile")?.addEventListener("click",editProfile);
 $("#changePass")?.addEventListener("click",()=>toast("For a Firebase-connected build, password reset is handled through Firebase Authentication."));
 $("#aboutBtn")?.addEventListener("click",()=>openModal("About KhetCycle",`<p><strong>KhetCycle</strong> connects agricultural residue suppliers with potential buyers and helps turn crop waste into value.</p><p class="muted">Prototype architecture: authentication, marketplace, AI-assisted listing flow, requests, notifications and profile management.</p>`));
}
function handlePhoto(file){
 if(!file)return;
 const r=new FileReader();r.onload=()=>{$("#photoPreview").src=r.result;$("#photoPreview").classList.remove("hidden");$("#uploadArea").classList.add("hidden");simulateAI();};r.readAsDataURL(file);
}
function simulateAI(){
 const p=$("#aiPanel");p.classList.remove("hidden");p.innerHTML=`<strong>AI Analysis</strong><p class="muted">Analyzing crop residue image...</p><div class="loader" style="background:#d8e8de"></div>`;
 setTimeout(()=>{aiResult={material:"Sugarcane Residue",crop:"Sugarcane",confidence:.89,uses:["Biomass","Composting","Industrial processing"]};p.innerHTML=`<strong>AI-assisted identification</strong><div style="margin-top:10px"><b>${aiResult.material}</b><div class="meta">Suggested crop: ${aiResult.crop}</div><div class="confidence"><span style="width:${aiResult.confidence*100}%"></span></div><div class="meta">${Math.round(aiResult.confidence*100)}% estimated confidence</div><p class="meta">Possible uses: ${aiResult.uses.join(" · ")}</p><button class="secondary" id="confirmAI">Confirm suggestion</button> <button class="outline" id="manualAI">Choose manually</button><p class="tiny">AI output is an estimate. Confirm before publishing.</p></div>`;$("#confirmAI").onclick=()=>{$("#material").value=aiResult.material;$("#crop").value=aiResult.crop;toast("AI suggestion confirmed. Review the listing before publishing.")};$("#manualAI").onclick=()=>{$("#material").focus();toast("Manual selection enabled.")}},900);
}
function publishListing(e){
 e.preventDefault();
 const l={id:"l"+Date.now(),material:$("#material").value.trim(),crop:$("#crop").value,quantity:Number($("#qty").value),unit:$("#unit").value,location:$("#location").value.trim(),availability:$("#availability").value,status:"active",emoji:"🌾",description:$("#desc").value.trim(),expectedPrice:$("#price").value?Number($("#price").value):null,farmerId:state.user?.id||"demo",farmerName:state.user?.name||"Demo Farmer"};
 state.listings.push(l);save();toast("Listing published successfully.");screen="listings";renderNav();renderScreen();
}
function setRequest(id,status){
 const r=state.requests.find(x=>x.id===id);if(!r)return;
 r.status=status;r.updatedAt=new Date().toISOString();
 if(status==="accepted") addNotification(r.buyerId,"Request accepted","Your request has been accepted by the farmer.");
 if(status==="rejected") addNotification(r.buyerId,"Request declined","The farmer declined your request.");
 save();toast(`Request ${status}.`);renderScreen();updateNotifyDot();
}
function openListing(id){
 const l=state.listings.find(x=>x.id===id);if(!l)return;
 const buyer=state.user?.role==="buyer";
 openModal(l.material,`<div class="listing-img" style="height:180px;border-radius:16px">${l.emoji||"🌾"}</div><h2>${escapeHtml(l.quantity)} ${escapeHtml(l.unit)}</h2><div class="meta">${escapeHtml(l.location)} · ${escapeHtml(l.availability)}</div><p>${escapeHtml(l.description||"No description provided.")}</p><div class="ai-box"><strong>Why this matches</strong><p class="meta">✓ Material match &nbsp; ✓ Quantity suitable &nbsp; ✓ Location considered &nbsp; ✓ Availability considered</p><strong>${matchScore(l)}% Match</strong></div>${buyer?`<button class="primary full" style="margin-top:15px" id="requestBtn">Request Purchase</button>`:`<button class="outline full" style="margin-top:15px" id="pauseBtn">Pause listing</button>`}`);
 $("#requestBtn")?.addEventListener("click",()=>requestPurchase(l));
 $("#pauseBtn")?.addEventListener("click",()=>{l.status=l.status==="active"?"paused":"active";save();closeModal();renderScreen();toast(l.status==="active"?"Listing active":"Listing paused")});
}
function requestPurchase(l){
 openModal("Request Purchase",`<form id="requestForm" class="auth-form"><div class="field"><label>Requested quantity (kg)</label><input id="rq" type="number" min="1" max="${l.quantity}" value="${Math.min(100,l.quantity)}" required></div><div class="field"><label>Preferred date</label><input id="rd" type="date"></div><div class="field"><label>Message</label><textarea id="rm" rows="4" placeholder="Tell the farmer what you need."></textarea></div><button class="primary full">Send request</button></form>`);
 $("#requestForm").onsubmit=e=>{e.preventDefault();const r={id:"r"+Date.now(),listingId:l.id,buyerId:state.user?.id||"demoBuyer",buyerName:state.user?.name||"Demo Buyer",farmerId:l.farmerId||"demo",farmerName:l.farmerName||"Demo Farmer",requestedQuantity:Number($("#rq").value),message:$("#rm").value,preferredDate:$("#rd").value,status:"pending",createdAt:new Date().toISOString()};state.requests.push(r);addNotification(r.farmerId,"New buyer request",`${r.buyerName} requested ${r.requestedQuantity} kg of ${l.material}.`);save();closeModal();toast("Purchase request sent.");updateNotifyDot()}}
function addNotification(userId,title,message){state.notifications.push({id:"n"+Date.now()+Math.random(),userId,title,message,read:false,createdAt:new Date().toISOString()})}
function updateNotifyDot(){const d=$("#notifyDot");if(!d)return;d.classList.toggle("on",state.notifications.some(n=>!n.read))}
function openModal(title,body){
 const x=document.createElement("div");x.className="modal-backdrop";x.id="modal";x.innerHTML=`<div class="modal"><div class="modal-head"><h2 style="margin:0">${title}</h2><button class="close" id="closeModal">✕</button></div><div style="margin-top:15px">${body}</div></div>`;document.body.appendChild(x);$("#closeModal").onclick=closeModal;x.onclick=e=>{if(e.target===x)closeModal()}
}
function closeModal(){$("#modal")?.remove()}
function editProfile(){
 openModal("Edit profile",`<form id="profileForm" class="auth-form"><label>Name<input id="pn" value="${escapeHtml(state.user.name||"")}"></label><label>Mobile<input id="pp" value="${escapeHtml(state.user.phone||"")}"></label><label>Location<input id="pl" value="${escapeHtml(state.user.location||"")}"></label><button class="primary">Save changes</button></form>`);
 $("#profileForm").onsubmit=e=>{e.preventDefault();state.user.name=$("#pn").value.trim();state.user.phone=$("#pp").value.trim();state.user.location=$("#pl").value.trim();save();closeModal();showMain();toast("Profile updated.")};
}
function notificationsMarkRead(){state.notifications.forEach(n=>{if(n.userId===state.user?.id)n.read=true});save();updateNotifyDot()}
function logout(){state.user=null;state.demo=false;save();show("auth");switchAuth("login")}
function register(e){
 e.preventDefault();
 const email=$("#regEmail").value.trim().toLowerCase();
 if(state.users.some(u=>u.email===email)){toast("An account with this email already exists.");return}
 const u={id:"u"+Date.now(),name:$("#regName").value.trim(),email,phone:$("#regPhone").value.trim(),password:$("#regPassword").value,role:$("#regRole").value,location:$("#regLocation").value.trim()};
 state.users.push(u);state.user={...u};state.demo=false;save();toast("Account created.");showMain();
}
function login(e){
 e.preventDefault();const email=$("#loginEmail").value.trim().toLowerCase(),pass=$("#loginPassword").value;
 const u=state.users.find(x=>x.email===email&&x.password===pass);
 if(!u){toast("Incorrect email or password. Use Demo Mode for the presentation.");return}
 state.user={...u};state.demo=false;save();showMain();
}
function demoLogin(){
 state.demo=true;state.user={id:"demoFarmer",name:"Demo Farmer",email:"demo@khetcycle.app",phone:"+91 90000 00000",role:"farmer",location:"Nashik, Maharashtra"};state.requests=[];state.notifications=[];state.saved=[];save();showMain();toast("Demo Mode started.")}
function switchAuth(mode){
 currentAuth=mode;$$(".tab").forEach(x=>x.classList.toggle("active",x.dataset.auth===mode));$("#loginForm").classList.toggle("hidden",mode!=="login");$("#registerForm").classList.toggle("hidden",mode!=="register")
}
function forgot(){const e=$("#loginEmail").value.trim();toast(e?`Password reset would be sent to ${e} when Firebase Auth is connected.`:"Enter your email first.")}
document.addEventListener("click",e=>{const b=e.target.closest("[data-screen]");if(b&&b.closest("#nav")){screen=b.dataset.screen;renderNav();renderScreen()}});
$("#demoBtn").onclick=demoLogin;$("#loginForm").onsubmit=login;$("#registerForm").onsubmit=register;$("#forgotBtn").onclick=forgot;
$$(".tab").forEach(x=>x.onclick=()=>switchAuth(x.dataset.auth));
$("#logoutBtn").onclick=logout;$("#profileTop").onclick=()=>{screen="profile";renderNav();renderScreen()};$("#notifyBtn").onclick=()=>{screen="notifications";notificationsMarkRead();renderNav();renderScreen()};
$("#menuBtn").onclick=()=>$("#sidebar").classList.toggle("open");
boot();
