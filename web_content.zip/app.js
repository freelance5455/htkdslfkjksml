/* SPRM Rice Mill app. Local-only database; export backups regularly. */
const DB='sprm-rice-mill-v2', STORE='records';
const MODULES=[
 ['dashboard','Dashboard','⌂'],['hulling','Hulling','⚙'],['purchase','Purchase','＋'],['dispatch','Dispatch','⇢'],['sales','Sales','₹'],
 ['parties','Parties','♙'],['expenses','Expenses','−'],['labour','Labour','♧'],['electricity','Electricity','ϟ'],['reports','Reports','▤'],
 ['outstanding','Outstanding','◷'],['audit','Audit Log','≡'],['settings','Settings','⚙']
];
const $=s=>document.querySelector(s), num=v=>Number(v||0), today=()=>new Date().toISOString().slice(0,10);
const money=n=>'₹'+num(n).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
let db,current='dashboard',editing=null,lastBackupAt=null;
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function toast(s){const el=$('#toast');el.textContent=s;el.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(()=>el.style.display='none',3000)}
function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:'id',autoIncrement:true});r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
function all(){return new Promise((res,rej)=>{const r=db.transaction(STORE).objectStore(STORE).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
function save(rec){return new Promise((res,rej)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).put(rec);tx.oncomplete=()=>res(rec);tx.onerror=()=>rej(tx.error)})}
function add(rec){return new Promise((res,rej)=>{
 // Forms include an empty hidden id field. IndexedDB rejects empty-string keys,
 // so remove any missing/blank id and let the autoIncrement key generator assign it.
 if(rec.id===undefined||rec.id===null||rec.id==='') delete rec.id;
 const tx=db.transaction(STORE,'readwrite');const r=tx.objectStore(STORE).add(rec);
 r.onsuccess=()=>rec.id=r.result;tx.oncomplete=()=>res(rec);tx.onerror=()=>rej(tx.error);tx.onabort=()=>rej(tx.error||new Error('Database transaction aborted'));
 })}
function del(id){return new Promise((res,rej)=>{const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).delete(Number(id));tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
async function audit(action,module,id,detail){await add({module:'audit',date:today(),createdAt:new Date().toISOString(),action,target:module,targetId:id||'',summary:`${action} ${module}: ${detail||''}`})}
function sum(rows,fn){return rows.reduce((a,r)=>a+num(fn(r)),0)}
function getRecords(rows,module){return rows.filter(r=>r.module===module)}
function paddyConsumers(rows,excludeId=null){return rows.filter(r=>(r.module==='dispatch'||(r.module==='sales'&&r.saleType==='Paddy Sale'))&&r.id!==excludeId)}
function stockByVariety(rows,excludeId=null){
 const purchases=getRecords(rows,'purchase').sort((a,b)=>(a.date||'').localeCompare(b.date||'')||a.id-b.id);
 const used={}; for(const r of paddyConsumers(rows,excludeId)){for(const a of (r.allocations||[]))used[a.purchaseId]=(used[a.purchaseId]||0)+num(a.quantity)}
 const result={}; for(const p of purchases){const rem=Math.max(0,num(p.quantity)-(used[p.id]||0));const key=(p.variety||'Unspecified').trim().toLowerCase();if(!result[key])result[key]={variety:p.variety||'Unspecified',color:p.color||'',quantity:0,lots:[]};result[key].quantity+=rem;result[key].lots.push({id:p.id,remaining:rem,party:p.party,date:p.date})}
 return result;
}
function stockTotals(rows){
 const paddy=sum(Object.values(stockByVariety(rows)),x=>x.quantity);
 const sales=getRecords(rows,'sales');
 const riceOpening=sum(getRecords(rows,'openingStock'),r=>r.rice);
 const branOpening=sum(getRecords(rows,'openingStock'),r=>r.bran);
 const huskOpening=sum(getRecords(rows,'openingStock'),r=>r.husk);
 return {paddy,rice:riceOpening-sum(sales.filter(r=>r.saleType==='Rice Sale'),r=>r.quantity),bran:branOpening-sum(sales.filter(r=>r.saleType==='Bran Sale'),r=>r.quantity),husk:huskOpening-sum(sales.filter(r=>r.saleType==='Husk Sale'),r=>r.quantity)};
}
function allocateFIFO(rows,variety,qty,excludeId=null){
 const remaining=num(qty), purchases=getRecords(rows,'purchase').filter(p=>(p.variety||'').toLowerCase()===(variety||'').toLowerCase()).sort((a,b)=>(a.date||'').localeCompare(b.date||'')||a.id-b.id);
 const used={};for(const r of paddyConsumers(rows,excludeId)){for(const a of (r.allocations||[]))used[a.purchaseId]=(used[a.purchaseId]||0)+num(a.quantity)}
 let left=remaining,alloc=[];for(const p of purchases){const avail=Math.max(0,num(p.quantity)-(used[p.id]||0));const take=Math.min(avail,left);if(take>0){alloc.push({purchaseId:p.id,quantity:take});left-=take}if(left<=0.0000001)break}
 if(left>0.0001)throw new Error(`Insufficient ${variety||'paddy'} stock. Available: ${(remaining-left).toFixed(3)} QTL.`);
 return alloc;
}
const configs={
 hulling:{title:'Hulling Service',fields:[['date','Date','date'],['party','Party Name','text'],['vehicle','Vehicle Number','text'],['bags','Bags','number'],['quantity','Quantity (QTL)','number'],['rate','Rate per QTL (₹)','number'],['cgst','CGST (₹)','number'],['sgst','SGST (₹)','number'],['amount','Total Amount (₹)','number'],['received','Amount Received (₹)','number'],['paymentMode','Payment Mode','select',['Cash','UPI','Bank','Credit']],['paymentStatus','Payment Status','select',['Pending','Part-paid','Paid']],['note','Notes','text']]},
 purchase:{title:'Paddy Purchase',fields:[['date','Date','date'],['party','Party Name','text'],['vehicle','Vehicle Number','text'],['variety','Paddy Variety','text'],['color','Paddy Color','select',['Red','White']],['category','Paddy Category','select',['Small Paddy','Big Paddy']],['bags','Total Bags','number'],['quantity','Net Quantity (QTL)','number'],['rate','Rate per QTL (₹)','number'],['amount','Total Amount (₹)','number'],['paid','Amount Paid (₹)','number'],['paymentMode','Payment Mode','select',['Cash','UPI','Bank','Credit']],['note','Notes','text']]},
 dispatch:{title:'Paddy Dispatch',fields:[['date','Date','date'],['party','Party Name','text'],['vehicle','Vehicle Number','text'],['category','Paddy Category','select',['Small Paddy','Big Paddy']],['variety','Paddy Variety','selectDynamic','varieties'],['grossKg','Gross Loaded Weight (kg)','number'],['emptyKg','Empty Vehicle Weight (kg)','number'],['bagDeductionKg','Bag Weight Deduction (kg)','number'],['otherDeductionKg','Other Deductions (kg)','number'],['deductionReason','Deduction Reason','text'],['totalDeductionsKg','Total Deductions (kg)','number'],['netKg','Net Paddy Weight (kg)','number'],['netQtl','Net Paddy Quantity (QTL)','number'],['rateUnit','Rate Unit','select',['Per Quintal','Per KG']],['rate','Rate','number'],['amount','Total Dispatch Amount (₹)','number'],['note','Notes','text']]},
 sales:{title:'Sales',fields:[['date','Date','date'],['saleType','Sale Type','select',['Paddy Sale','Rice Sale','Bran Sale','Husk Sale','Misc Sale']],['party','Party Name','text'],['variety','Variety','text'],['bags','Bags','number'],['quantity','Quantity (QTL)','number'],['rate','Rate per QTL (₹)','number'],['cgst','CGST (₹)','number'],['sgst','SGST (₹)','number'],['amount','Total Amount (₹)','number'],['received','Amount Received (₹)','number'],['paymentMode','Payment Mode','select',['Cash','UPI','Bank','Credit']],['note','Notes','text']]},
 parties:{title:'Party Master',fields:[['party','Party Name','text'],['phone','Phone','tel'],['address','Address','text'],['gstin','GSTIN','text'],['openingBalance','Opening Balance (₹)','number'],['balanceType','Opening Balance Type','select',['Receivable','Payable']]]},
 expenses:{title:'Expenses',fields:[['date','Date','date'],['category','Category','select',['Labour','Electricity','Transport','Maintenance','Machinery','Other']],['amount','Amount (₹)','number'],['description','Description','text'],['paymentMode','Payment Mode','select',['Cash','UPI','Bank','Credit']]]},
 labour:{title:'Labour Register',fields:[['date','Date','date'],['worker','Worker Name','text'],['quantity','Hulling Quantity (QTL)','number'],['rate','Rate per QTL (₹)','number'],['amount','Total Wage (₹)','number'],['paymentMode','Payment Mode','select',['Cash','UPI','Bank']],['paymentStatus','Payment Status','select',['Pending','Part-paid','Paid']]]},
 electricity:{title:'Electricity Register',fields:[['date','Bill Date','date'],['units','Units Consumed','number'],['amount','Bill Amount (₹)','number'],['paymentStatus','Payment Status','select',['Pending','Paid']],['note','Notes','text']]}
};
function field(name,label,type,opts={},value=''){
 const val=value??opts.value??'';
 if(type==='select')return `<div class="field"><label>${esc(label)}</label><select name="${name}">${opts.map(x=>`<option value="${esc(x)}" ${x===val?'selected':''}>${esc(x)}</option>`).join('')}</select></div>`;
 if(type==='selectDynamic'){const values=opts.length?opts:['No purchase varieties yet'];return `<div class="field"><label>${esc(label)}</label><select name="${name}">${values.map(x=>`<option value="${esc(x)}" ${x===val?'selected':''}>${esc(x)}</option>`).join('')}</select></div>`}
 const ntype=type==='number'?'number':type;return `<div class="field"><label>${esc(label)}</label><input name="${name}" type="${ntype}" value="${esc(val)}" ${ntype==='number'?'min="0" step="any"':''} ${['date','party','variety','quantity'].includes(name)?'required':''}></div>`;
}
function panel(title,body){return `<section class="panel"><h3>${title}</h3>${body}</section>`}
function table(rows,module){
 if(!rows.length)return '<div class="empty">No records yet.</div>';
 return `<div class="tablewrap"><table><thead><tr><th>Date</th><th>Party / Details</th><th>Variety / Type</th><th>Quantity</th><th>Amount</th><th>Actions</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.date||'—')}</td><td>${esc(r.party||r.worker||r.description||r.summary||r.vehicle||'—')}</td><td>${esc(r.variety||r.saleType||r.category||r.action||'—')}</td><td>${r.netQtl!==undefined?num(r.netQtl).toFixed(3)+' QTL':r.quantity!==undefined?num(r.quantity).toFixed(2)+' QTL':'—'}</td><td>${r.amount!==undefined?money(r.amount):'—'}</td><td><button class="btn secondary small" data-edit="${r.id}">Edit</button> <button class="btn danger small" data-delete="${r.id}">Delete</button></td></tr>`).join('')}</tbody></table></div>`;
}
function nav(){
 const main=['dashboard','hulling','purchase','sales','more'];
 const labels={dashboard:'⌂|Home',hulling:'⚙|Hulling',purchase:'＋|Purchase',sales:'₹|Sales',more:'☰|More'};
 $('#sidebar').innerHTML=MODULES.map(([id,l])=>`<button class="navbtn ${id===current?'active':''}" data-nav="${id}">${l}</button>`).join('');
 $('#bottomNav').innerHTML=main.map(id=>{const [ico,label]=labels[id].split('|');return `<button class="bottombtn ${((id==='more'&&!['dashboard','hulling','purchase','sales'].includes(current))||id===current)?'active':''}" data-nav="${id==='more'?'more':id}"><span>${ico}</span>${label}</button>`}).join('');
 document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>{editing=null;if(b.dataset.nav==='more'){current='more'}else current=b.dataset.nav;render()});
}
async function render(){
 nav();const rows=await all();const list=getRecords(rows,current).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||b.id-a.id);let html='';
 if(current==='more'){
  html=`<h2>More Modules</h2><p class="sub">Mill records and administration</p><div class="cards">${MODULES.filter(x=>!['dashboard','hulling','purchase','sales','dispatch'].includes(x[0])).map(([id,l,ico])=>`<button class="card" style="text-align:left;border:1px solid var(--line)" data-goto="${id}"><div style="font-size:24px">${ico}</div><strong>${l}</strong><div class="muted">Open module →</div></button>`).join('')}</div>`;
 }else if(current==='dashboard'){
  const s=stockTotals(rows),h=sum(getRecords(rows,'hulling'),r=>r.amount),sales=sum(getRecords(rows,'sales'),r=>r.amount),exp=sum(getRecords(rows,'expenses'),r=>r.amount)+sum(getRecords(rows,'labour'),r=>r.amount)+sum(getRecords(rows,'electricity'),r=>r.amount);
  const rec=sum(getRecords(rows,'hulling'),r=>Math.max(0,num(r.amount)-num(r.received)))+sum(getRecords(rows,'sales'),r=>Math.max(0,num(r.amount)-num(r.received)));
  const pay=sum(getRecords(rows,'purchase'),r=>Math.max(0,num(r.amount)-num(r.paid)));
  html=`<h2>Dashboard</h2><p class="sub">Business snapshot · ${today()}</p><div class="cards"><div class="card"><div class="label">Paddy Stock</div><div class="metric">${s.paddy.toFixed(3)}</div><div class="muted">Quintals</div></div><div class="card"><div class="label">Rice Stock*</div><div class="metric">${s.rice.toFixed(3)}</div><div class="muted">Quintals</div></div><div class="card"><div class="label">Bran Stock*</div><div class="metric">${s.bran.toFixed(3)}</div><div class="muted">Quintals</div></div><div class="card"><div class="label">Husk Stock*</div><div class="metric">${s.husk.toFixed(3)}</div><div class="muted">Quintals</div></div></div><div class="cards" style="margin-top:10px"><div class="card"><div class="label">Hulling Income</div><div class="metric">${money(h)}</div></div><div class="card"><div class="label">Sales Recorded</div><div class="metric">${money(sales)}</div></div><div class="card"><div class="label">Expenses Recorded</div><div class="metric">${money(exp)}</div></div><div class="card"><div class="label">Net (simple)</div><div class="metric">${money(h+sales-exp)}</div></div></div><div class="cards" style="margin-top:10px"><div class="card"><div class="label">Receivables*</div><div class="metric">${money(rec)}</div></div><div class="card"><div class="label">Purchase Payables*</div><div class="metric">${money(pay)}</div></div></div><div class="notice warn">*Rice/bran/husk opening stock must be entered in Settings. This snapshot is a simple operational summary, not a full accrual-accounting profit statement.</div>${panel('Quick actions',`<div class="quickgrid">${[['hulling','+ Hulling'],['purchase','+ Paddy Purchase'],['dispatch','+ Dispatch'],['sales','+ Sale'],['expenses','+ Expense']].map(([id,l])=>`<button class="btn" data-goto="${id}">${l}</button>`).join('')}</div>`)}${panel('Paddy stock by variety',stockTable(stockByVariety(rows)))}${panel('Recent activity',table(rows.filter(r=>r.module!=='audit').sort((a,b)=>b.id-a.id).slice(0,8)))}`;
 }else if(current==='dispatch'){
  const stock=stockByVariety(rows);
  html=`<h2>Paddy Dispatch</h2><p class="sub">Weight deductions, final net quantity and FIFO stock allocation.</p><div class="stockbadge">Available paddy stock: ${stockTotals(rows).paddy.toFixed(3)} QTL</div>${panel(editing?'Edit dispatch':'New dispatch',formHTML(configs.dispatch,rows,editing))}${panel('Dispatch history',table(list,'dispatch'))}`;
 }else if(current==='settings'){
  const p=getRecords(rows,'profile')[0]||{millName:'Shri Parshwnatha Rice Mill',locality:'Bellow Sullalli, 577453'};
  const opening=getRecords(rows,'openingStock')[0]||{rice:0,bran:0,husk:0};
  html=`<h2>Settings & Backup</h2><p class="sub">Mill profile, opening stocks and data protection</p>${panel('Mill profile',`<form id="profileForm"><div class="formgrid">${field('millName','Mill Name','text',{},p.millName)}${field('locality','Locality','text',{},p.locality)}${field('phone','Phone','tel',{},p.phone||'')}</div><button class="btn" type="submit">Save profile</button></form>`)}${panel('Opening stock (QTL)',`<form id="openingForm"><div class="formgrid">${field('rice','Rice opening stock (QTL)','number',{},opening.rice)}${field('bran','Bran opening stock (QTL)','number',{},opening.bran)}${field('husk','Husk opening stock (QTL)','number',{},opening.husk)}</div><p class="muted">This sets starting stock for rice, bran and husk. Production yield tracking is not yet included.</p><button class="btn" type="submit">Save opening stock</button></form>`)}${panel('Backup & restore',`<p>Export JSON, then save/share the file to Google Drive. Restore replaces records stored on this device.</p><div class="actions"><button class="btn" id="backup">Export JSON backup</button><label class="btn secondary" for="restoreFile">Restore JSON backup</label><input id="restoreFile" type="file" accept=".json,application/json" hidden></div><p class="notice warn">Back up before app updates, phone changes or restore. Google Drive backup is manual, not automatic sync.</p><p class="muted">${rows.length} local records · last backup ${lastBackupAt||'not recorded in this session'}</p><button class="btn danger" id="erase">Erase all local data</button>`)}${panel('Variety management',`<p class="muted">Paddy variety options are created by recording a purchase. Rice varieties can be entered in Rice Sale records.</p>`)}`;
 }else if(current==='reports'){
  html=`<h2>Reports / Daily Closing</h2><p class="sub">Operational report snapshot for all local records.</p>${panel('Daily closing summary',`<div class="cards"><div class="card"><div class="label">Purchases</div><div class="metric">${money(sum(getRecords(rows,'purchase'),r=>r.amount))}</div></div><div class="card"><div class="label">Dispatch valuation</div><div class="metric">${money(sum(getRecords(rows,'dispatch'),r=>r.amount))}</div></div><div class="card"><div class="label">Sales</div><div class="metric">${money(sum(getRecords(rows,'sales'),r=>r.amount))}</div></div><div class="card"><div class="label">Expenses</div><div class="metric">${money(sum(getRecords(rows,'expenses'),r=>r.amount)+sum(getRecords(rows,'labour'),r=>r.amount)+sum(getRecords(rows,'electricity'),r=>r.amount))}</div></div></div><div class="actions"><button class="btn" id="csvAll">Export all records CSV</button><button class="btn secondary" onclick="window.print()">Print report</button></div>`)}${panel('All transactions',table(rows.filter(r=>r.module!=='audit').sort((a,b)=>b.id-a.id).slice(0,200)))}`;
 }else if(current==='outstanding'){
  const due=[...getRecords(rows,'hulling').map(r=>({...r,due:Math.max(0,num(r.amount)-num(r.received)),kind:'Receivable'})),...getRecords(rows,'sales').map(r=>({...r,due:Math.max(0,num(r.amount)-num(r.received)),kind:'Receivable'})),...getRecords(rows,'purchase').map(r=>({...r,due:Math.max(0,num(r.amount)-num(r.paid)),kind:'Payable'}))].filter(r=>r.due>0);
  html=`<h2>Outstanding Ledger</h2><p class="sub">Unpaid balances calculated from recorded bills.</p><div class="cards"><div class="card"><div class="label">Receivables</div><div class="metric">${money(sum(due.filter(r=>r.kind==='Receivable'),r=>r.due))}</div></div><div class="card"><div class="label">Payables</div><div class="metric">${money(sum(due.filter(r=>r.kind==='Payable'),r=>r.due))}</div></div></div>${panel('Bill-level outstanding',due.length?`<div class="tablewrap"><table><thead><tr><th>Date</th><th>Party</th><th>Type</th><th>Bill amount</th><th>Due</th></tr></thead><tbody>${due.map(r=>`<tr><td>${esc(r.date)}</td><td>${esc(r.party)}</td><td>${r.kind}</td><td>${money(r.amount)}</td><td>${money(r.due)}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">No outstanding balances found.</div>')}`;
 }else{
  const title=MODULES.find(x=>x[0]===current)?.[1]||current;
  if(configs[current]) html=`<h2>${title}</h2><p class="sub">Records are stored locally on this device.</p>${panel(editing?'Edit record':`New ${title} entry`,formHTML(configs[current],rows,editing))}${panel('Saved entries',table(list,current))}`;
  else if(current==='audit') html=`<h2>Audit Log</h2><p class="sub">Create, edit and delete events.</p>${panel('Audit trail',table(list,'audit'))}`;
  else html=`<h2>${title}</h2><div class="empty">Module unavailable.</div>`;
 }
 $('#view').innerHTML=html;
 document.querySelectorAll('[data-goto]').forEach(b=>b.onclick=()=>{current=b.dataset.goto;editing=null;render()});
 document.querySelectorAll('[data-edit]').forEach(b=>b.onclick=()=>editRecord(Number(b.dataset.edit)));
 document.querySelectorAll('[data-delete]').forEach(b=>b.onclick=()=>deleteRecord(Number(b.dataset.delete)));
 wireForm(rows);
 wireSettings(rows);
 if($('#backup'))$('#backup').onclick=backup;
 if($('#restoreFile'))$('#restoreFile').onchange=restore;
 if($('#erase'))$('#erase').onclick=eraseAll;
 if($('#csvAll'))$('#csvAll').onclick=()=>downloadCSV(rows);
}
function stockTable(stock){const vals=Object.values(stock);if(!vals.length)return '<div class="empty">No paddy purchases recorded.</div>';return `<div class="tablewrap"><table><thead><tr><th>Variety</th><th>Color</th><th>Available QTL</th></tr></thead><tbody>${vals.map(v=>`<tr><td>${esc(v.variety)}</td><td>${esc(v.color||'—')}</td><td>${v.quantity.toFixed(3)}</td></tr>`).join('')}</tbody></table></div>`}
function formHTML(c,rows,record){
 const rec=record||{};let fields=c.fields;
 if(c.title==='Paddy Dispatch')fields=fields.filter(([n])=>!['totalDeductionsKg','netKg','netQtl','amount'].includes(n));
 const varietyList=[...new Set(getRecords(rows,'purchase').map(r=>r.variety).filter(Boolean))];
 return `<form id="entryForm" data-editing="${rec.id||''}"><div class="formgrid">${fields.map(([n,l,t,opts])=>{let value=rec[n]??(n==='date'?today():n==='rateUnit'?'Per Quintal':'');if(t==='selectDynamic')return field(n,l,t,varietyList,value);if(t==='select')return field(n,l,t,opts,value);return field(n,l,t,{},value)}).join('')}</div>${c.title==='Paddy Dispatch'?`<div class="notice">Formula: total deductions = empty vehicle + bag deduction + other deductions. Net kg = gross kg − total deductions. Net QTL = net kg ÷ 100. Edit calculated fields below if needed; use Recalculate to reset formula-based values.</div><div class="formgrid" style="margin-top:10px">${field('totalDeductionsKg','Total Deductions (kg)','number',{},rec.totalDeductionsKg??'')}${field('netKg','Net Paddy Weight (kg)','number',{},rec.netKg??'')}${field('netQtl','Net Paddy Quantity (QTL)','number',{},rec.netQtl??'')}${field('amount','Total Dispatch Amount (₹)','number',{},rec.amount??'')}</div><div class="actions"><button class="btn secondary" type="button" id="recalculate">↻ Recalculate</button><span class="override" id="overrideStatus"></span></div><div id="dispatchStock" class="stockbadge">Select a variety to view available stock.</div>`:''}<div class="actions"><button class="btn" type="submit">${rec.id?'Save changes':'Save entry'}</button><button class="btn secondary" type="button" id="cancelEdit">Cancel</button></div></form>`;
}
function readForm(form){const fd=new FormData(form),r={};for(const [k,v] of fd.entries()){const el=form.elements[k];r[k]=el&&el.type==='number'?num(v):v}return r}
function wireForm(rows){
 const form=$('#entryForm');if(!form)return;
 const isDispatch=current==='dispatch';let overridden=new Set();
 if(isDispatch){
  ['totalDeductionsKg','netKg','netQtl','amount'].forEach(n=>form.elements[n]?.addEventListener('input',()=>{overridden.add(n);$('#overrideStatus').textContent='Manual override: '+[...overridden].join(', ')}));
  const calc=()=>{const r=readForm(form),ded=num(r.emptyKg)+num(r.bagDeductionKg)+num(r.otherDeductionKg),net=num(r.grossKg)-ded,qtl=net/100,amt=(r.rateUnit==='Per KG'?net:num(qtl)) * num(r.rate);form.elements.totalDeductionsKg.value=ded.toFixed(2);form.elements.netKg.value=net.toFixed(2);form.elements.netQtl.value=qtl.toFixed(4);form.elements.amount.value=amt.toFixed(2);overridden.clear();$('#overrideStatus').textContent='Auto-calculated';updateDispatchStock(rows,form)};
  form.querySelectorAll('input,select').forEach(el=>el.addEventListener('input',()=>{if(!['totalDeductionsKg','netKg','netQtl','amount'].includes(el.name))updateDispatchStock(rows,form)}));
  $('#recalculate').onclick=calc;form.elements.variety.addEventListener('change',()=>updateDispatchStock(rows,form));updateDispatchStock(rows,form);
  if(!form.dataset.editing)calc();
 }
 form.onsubmit=async e=>{
  e.preventDefault();
  try{
   let rec=readForm(form),old=null;
   if(form.dataset.editing){old=rows.find(r=>r.id===Number(form.dataset.editing));if(!old)throw Error('Record not found')}
   rec.module=current;rec.id=old?.id;rec.createdAt=old?.createdAt||new Date().toISOString();rec.updatedAt=new Date().toISOString();
   for(const [k,v] of Object.entries(rec)){if(typeof v==='number'&&v<0)throw Error(`${k} cannot be negative`)}
   if(['purchase','dispatch','sales','hulling','labour'].includes(current)&&num(rec.quantity)<=0&&current!=='dispatch')throw Error('Quantity must be greater than zero');
   if(current==='purchase'){
    rec.amount=rec.amount||num(rec.quantity)*num(rec.rate);rec.balance=Math.max(0,num(rec.amount)-num(rec.paid));
    if(old){const allocated=sum(paddyConsumers(rows,old.id),r=>sum((r.allocations||[]).filter(a=>a.purchaseId===old.id),a=>a.quantity));if(num(rec.quantity)<allocated-0.0001)throw Error(`This purchase lot has ${allocated.toFixed(3)} QTL allocated. Quantity cannot be reduced below that.`)}
   }
   if(current==='dispatch'){
    const gross=num(rec.grossKg),ded=num(rec.totalDeductionsKg),net=num(rec.netKg),qtl=num(rec.netQtl);
    if(gross<ded)throw Error('Gross loaded weight must be greater than or equal to total deductions.');
    if(Math.abs(net-(gross-ded))>0.01 && !overridden.has('netKg'))throw Error('Net weight is inconsistent. Click Recalculate or correct it.');
    if(Math.abs(net/100-qtl)>0.0001 && !overridden.has('netQtl'))throw Error('Net weight and net quantity are inconsistent. Click Recalculate or align both fields.');
    if(!rec.variety)throw Error('Choose a paddy variety.');
    rec.netKg=net;rec.netQtl=qtl;rec.amount=num(rec.amount)||qtl*num(rec.rate);
    rec.allocations=allocateFIFO(rows,rec.variety,qtl,old?.id);
   }
   if(current==='sales'){
    rec.amount=rec.amount||num(rec.quantity)*num(rec.rate)+num(rec.cgst)+num(rec.sgst);
    rec.balance=Math.max(0,num(rec.amount)-num(rec.received));
    if(rec.saleType==='Paddy Sale')rec.allocations=allocateFIFO(rows,rec.variety,num(rec.quantity),old?.id);
    else if(['Rice Sale','Bran Sale','Husk Sale'].includes(rec.saleType)){
      const stockKey=rec.saleType==='Rice Sale'?'rice':rec.saleType==='Bran Sale'?'bran':'husk';
      const available=stockTotals(rows)[stockKey]+(old&&old.saleType===rec.saleType?num(old.quantity):0);
      if(num(rec.quantity)>available+0.0001)throw Error(`Insufficient ${stockKey} stock. Available: ${available.toFixed(3)} QTL. Check Settings opening stock.`);
    }
   }
   if(current==='hulling'){rec.amount=rec.amount||num(rec.quantity)*num(rec.rate)+num(rec.cgst)+num(rec.sgst);rec.balance=Math.max(0,num(rec.amount)-num(rec.received))}
   if(current==='labour')rec.amount=rec.amount||num(rec.quantity)*num(rec.rate);
   if(old)await save(rec);else await add(rec);
   await audit(old?'EDIT':'CREATE',current,rec.id,`${rec.party||rec.worker||rec.variety||rec.description||''} · ${rec.quantity??rec.netQtl??''}`);
   editing=null;toast(old?'Changes saved':'Entry saved');render();
  }catch(err){alert(err.message||'Could not save record')}
 };
 $('#cancelEdit').onclick=()=>{editing=null;render()};
}
function updateDispatchStock(rows,form){
 const variety=form.elements.variety.value,stock=stockByVariety(rows,Number(form.dataset.editing)||null),entry=Object.values(stock).find(v=>v.variety.toLowerCase()===String(variety).toLowerCase());
 const available=num(entry?.quantity);const q=num(form.elements.netQtl.value);
 $('#dispatchStock').textContent=`${variety||'Select a variety'} · Available: ${available.toFixed(3)} QTL · After this dispatch: ${(available-q).toFixed(3)} QTL`;
 $('#dispatchStock').classList.toggle('negative',q>available+0.0001);
}
async function editRecord(id){
 const rows=await all(),rec=rows.find(r=>r.id===id);if(!rec)return;
 if(['audit','openingStock','profile'].includes(rec.module)){toast('This record is managed in Settings or audit history.');return}
 current=rec.module;editing=rec;render();
}
async function deleteRecord(id){
 const rows=await all(),rec=rows.find(r=>r.id===id);if(!rec)return;
 if(rec.module==='purchase'){
  const allocated=sum(paddyConsumers(rows),r=>sum((r.allocations||[]).filter(a=>a.purchaseId===id),a=>a.quantity));
  if(allocated>0.0001){alert(`Cannot delete this purchase lot: ${allocated.toFixed(3)} QTL is allocated to dispatches or paddy sales. Delete or edit dependent transactions first.`);return}
 }
 if(!confirm(`Delete this ${rec.module} record? Stock allocations will be recalculated from saved transactions.`))return;
 await del(id);await audit('DELETE',rec.module,id,rec.party||rec.variety||'');toast('Record deleted');render();
}
function wireSettings(rows){
 if($('#profileForm'))$('#profileForm').onsubmit=async e=>{e.preventDefault();const r=readForm(e.target);const old=getRecords(rows,'profile')[0];if(old){r.module='profile';r.id=old.id;await save(r)}else{r.module='profile';await add(r)}$('#millTitle').textContent=r.millName||'Shri Parshwnatha Rice Mill';toast('Profile saved');render()};
 if($('#openingForm'))$('#openingForm').onsubmit=async e=>{e.preventDefault();const r=readForm(e.target),old=getRecords(rows,'openingStock')[0];r.module='openingStock';r.date=today();if(old){r.id=old.id;await save(r)}else await add(r);await audit('UPDATE','openingStock',r.id,'Opening stock updated');toast('Opening stock saved');render()};
}
async function backup(){
 const rows=await all(),payload={app:'Shri Parshwnatha Rice Mill',schemaVersion:2,exportedAt:new Date().toISOString(),records:rows};
 const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
 const filename=`SPRM-backup-${today()}.json`;
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);lastBackupAt=new Date().toLocaleString();toast('Backup file downloaded. Save it to Google Drive.');
}
async function restore(e){
 const file=e.target.files?.[0];if(!file)return;
 try{const payload=JSON.parse(await file.text());if(!Array.isArray(payload.records))throw Error('Backup file does not contain records.');if(!confirm(`Restore ${payload.records.length} records? Existing local data will be replaced. Export a backup first.`))return;
  const tx=db.transaction(STORE,'readwrite'),os=tx.objectStore(STORE);os.clear();for(const r of payload.records){const item={...r};delete item.id;os.add(item)}
  tx.oncomplete=()=>{toast('Backup restored');render()};tx.onerror=()=>alert('Restore failed. Existing data may not have changed completely; restore a valid backup.');
 }catch(err){alert('Restore failed: '+err.message)}e.target.value='';
}
async function eraseAll(){
 if(!confirm('Erase all local data? Export a backup first.'))return;
 if(!confirm('Final confirmation: permanently erase every record on this device?'))return;
 const tx=db.transaction(STORE,'readwrite');tx.objectStore(STORE).clear();tx.oncomplete=()=>{toast('Local records erased');render()};
}
function downloadCSV(rows){
 const keys=[...new Set(rows.flatMap(Object.keys))],csv=[keys.map(csvCell).join(','),...rows.map(r=>keys.map(k=>csvCell(r[k])).join(','))].join('\r\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download=`SPRM-export-${today()}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function csvCell(v){return '"'+String(v??'').replace(/"/g,'""')+'"'}
$('#topBackup').onclick=backup;
(async()=>{try{db=await openDB();const rows=await all();const p=getRecords(rows,'profile')[0];if(p?.millName)$('#millTitle').textContent=p.millName;render()}catch(e){$('#view').innerHTML='<div class="notice warn">Could not open local database. Restart the app and try again.</div>';console.error(e)}})();
