
const KEY='santosh_dhaba_entries';
let entries=JSON.parse(localStorage.getItem(KEY)||'[]');
const $=id=>document.getElementById(id);
$('date').value=new Date().toISOString().slice(0,10);

function save(){localStorage.setItem(KEY,JSON.stringify(entries));render();}
function show(name){
 const titles={sales:'Daily Sales',gst:'GST',staff:'Attendance & Staff',salary:'Salary',
 purchase:'Purchase',expenses:'Expenses',cash:'Closing Cash / Excess-Short',items:'Items / Inventory',report:'Monthly Report'};
 $('panel').querySelector('h2').textContent=titles[name]||name;
 render();
}
$('entryForm').addEventListener('submit',e=>{
 e.preventDefault();
 entries.push({date:$('date').value,label:$('label').value,amount:+$('amount').value,type:$('type').value});
 $('label').value='';$('amount').value='';save();
});
function render(){
 const total=t=>entries.filter(x=>x.type===t).reduce((s,x)=>s+x.amount,0);
 $('summary').innerHTML=`<div class="totals">
 <div class="box"><b>Sales</b><br>₹${total('Sales').toFixed(2)}</div>
 <div class="box"><b>Purchase</b><br>₹${total('Purchase').toFixed(2)}</div>
 <div class="box"><b>Expense</b><br>₹${total('Expense').toFixed(2)}</div>
 <div class="box"><b>Salary</b><br>₹${total('Salary').toFixed(2)}</div>
 </div>`;
 $('list').innerHTML=entries.slice().reverse().map((x,i)=>
 `<div class="row"><span>${x.date} — ${escapeHtml(x.label)}<br><small>${x.type}</small></span><b>₹${x.amount.toFixed(2)}</b></div>`).join('')||'<p>No entries yet.</p>';
}
function exportCSV(){
 let csv='Date,Description,Amount,Type\n'+entries.map(x=>`${x.date},"${x.label.replaceAll('"','""')}",${x.amount},${x.type}`).join('\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='Santosh_Dhaba_Data.csv';a.click();
}
function clearData(){if(confirm('Delete all saved entries?')){entries=[];save();}}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
render();
