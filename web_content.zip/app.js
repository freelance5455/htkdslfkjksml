const KEY="iraqi_exam_maker_v2", BANKKEY="iraqi_exam_bank_v1";
let exams=JSON.parse(localStorage.getItem(KEY)||"[]");
let bank=JSON.parse(localStorage.getItem(BANKKEY)||"[]");
let current={id:null,school:"",subject:"العربية",grade:"",examType:"",year:"",date:"",duration:"",totalMark:100,teacher:"",headerText:"",footerText:"مع تمنياتنا لكم بالنجاح",paperDirection:"rtl",fontSize:"16",logoData:"",questions:[]};
let deferredPrompt=null;
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;document.getElementById("installBtn").hidden=false});
document.getElementById("installBtn").onclick=async()=>{if(deferredPrompt){deferredPrompt.prompt();deferredPrompt=null}};
const $=id=>document.getElementById(id);
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function toast(t){let x=$("toast");x.textContent=t;x.style.display="block";setTimeout(()=>x.style.display="none",1800)}
function showScreen(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");if(id==="dashboard")renderList();if(id==="bank")renderBank();updateStats()}
function updateStats(){let q=current.questions?.length||0,m=current.questions?.reduce((a,x)=>a+(Number(x.mark)||0)+x.subs.reduce((b,s)=>b+(Number(s.mark)||0),0),0)||0;$("statQuestions").textContent=q;$("statMarks").textContent=m;$("statSaved").textContent=exams.length}
function newExam(){current={id:Date.now(),school:"",subject:"العربية",grade:"",examType:"",year:"",date:new Date().toISOString().slice(0,10),duration:"",totalMark:100,teacher:"",headerText:"",footerText:"مع تمنياتنا لكم بالنجاح",paperDirection:"rtl",fontSize:"16",logoData:"",questions:[]};addQuestion();loadForm();showScreen("editor")}
function loadForm(){["school","subject","grade","examType","year","date","duration","totalMark","teacher","headerText","footerText","paperDirection","fontSize"].forEach(k=>{if($(k))$(k).value=current[k]??""});renderQuestions();updateStats()}
function readForm(){["school","subject","grade","examType","year","duration","totalMark","teacher","headerText","footerText","paperDirection","fontSize"].forEach(k=>{if($(k))current[k]=$(k).value});if($("date"))current.date=$("date").value}
$("logoData").addEventListener("change",e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{current.logoData=r.result};r.readAsDataURL(f)});
function saveExam(){readForm();let i=exams.findIndex(e=>e.id===current.id);if(i<0)exams.push(JSON.parse(JSON.stringify(current)));else exams[i]=JSON.parse(JSON.stringify(current));localStorage.setItem(KEY,JSON.stringify(exams));updateStats();toast("تم حفظ الامتحان على الجهاز")}
function duplicateExam(){readForm();current.id=Date.now();current.school=(current.school||"امتحان")+" - نسخة";saveExam();toast("تم إنشاء نسخة جديدة")}
function deleteExam(id){if(!confirm("حذف هذا الامتحان؟"))return;exams=exams.filter(e=>e.id!==id);localStorage.setItem(KEY,JSON.stringify(exams));renderList()}
function editExam(id){let e=exams.find(x=>x.id===id);if(!e)return;current=JSON.parse(JSON.stringify(e));loadForm();showScreen("editor")}
function resetExam(){if(confirm("مسح بيانات الامتحان الحالي؟")){current.questions=[];loadForm()}}
function renderList(){let box=$("examList");$("countBadge").textContent=exams.length;if(!exams.length){box.innerHTML='<div class="hint">لا توجد امتحانات محفوظة بعد.</div>';return}box.innerHTML=exams.map(e=>`<div class="exam-item"><div class="exam-meta"><strong>${esc(e.school||"بدون اسم")} — ${esc(e.subject)}</strong><small>${esc(e.grade||"")} ${e.date?" • "+esc(e.date):""}</small></div><div class="exam-actions"><button class="secondary small" onclick="editExam(${e.id})">فتح</button><button class="secondary small" onclick="deleteExam(${e.id})">حذف</button></div></div>`).join("")}
function subjectChanged(){current.subject=$("subject").value}
function addQuestion(text="",mark="",meta={}){current.questions.push({id:Date.now()+Math.random(),text,mark,subs:[],bankMeta:meta});renderQuestions()}
function addMathQuestion(){addQuestion("حل المعادلة:  x² + 2x + 1 = 0","");toast("تمت إضافة سؤال رياضيات")}
function addSub(qi){current.questions[qi].subs.push({text:"",mark:""});renderQuestions()}
function removeQuestion(i){current.questions.splice(i,1);renderQuestions()}
function removeSub(qi,si){current.questions[qi].subs.splice(si,1);renderQuestions()}
function moveQ(i,d){let j=i+d;if(j<0||j>=current.questions.length)return;[current.questions[i],current.questions[j]]=[current.questions[j],current.questions[i]];renderQuestions()}
function autoNumber(){current.questions.forEach((q,i)=>q.autoNumber=i+1);renderQuestions();toast("تم تفعيل الترقيم التلقائي")}
function numberStyle(){let s=prompt("اختر نمط الترقيم: 1 = السؤال 1، 2 = س1، 3 = Q1","1");if(!["1","2","3"].includes(s))return;current.numberStyle=s;renderQuestions();toast("تم تغيير نمط الترقيم")}
function questionLabel(i){let n=i+1,style=current.numberStyle||"1";return style==="2"?`س${n}`:style==="3"?`Q${n}`:`السؤال ${n}`}
function renderQuestions(){let box=$("questions");if(!current.questions.length){box.innerHTML='<div class="hint">لم تتم إضافة أسئلة.</div>';return}box.innerHTML=current.questions.map((q,i)=>`<div class="question"><div class="qhead"><span class="qnum">${questionLabel(i)}</span><div class="qtools"><button class="secondary small" onclick="moveQ(${i},-1)">↑</button><button class="secondary small" onclick="moveQ(${i},1)">↓</button><button class="secondary small" onclick="addSub(${i})">+ فقرة</button><button class="secondary small" onclick="saveToBank(${i})">إلى البنك</button><button class="secondary small" onclick="removeQuestion(${i})">حذف</button></div></div><div class="qbody"><textarea oninput="current.questions[${i}].text=this.value;updateStats()" placeholder="اكتب نص السؤال هنا...">${esc(q.text)}</textarea><div class="math-toolbar"><button onclick="insertAtQuestion(${i},'√')">√</button><button onclick="insertAtQuestion(${i},'²')">x²</button><button onclick="insertAtQuestion(${i},'π')">π</button><button onclick="insertAtQuestion(${i},'≤')">≤</button><button onclick="insertAtQuestion(${i},'≥')">≥</button><button onclick="insertAtQuestion(${i},'±')">±</button><button onclick="insertAtQuestion(${i},'∑')">∑</button><button onclick="insertAtQuestion(${i},'Δ')">Δ</button></div><div class="subq"><span>الدرجة</span><input type="number" value="${esc(q.mark)}" oninput="current.questions[${i}].mark=this.value;updateStats()" placeholder="درجة"><span></span><span></span></div>${q.subs.map((s,j)=>`<div class="subq"><span>${String.fromCharCode(97+j)})</span><textarea oninput="current.questions[${i}].subs[${j}].text=this.value;updateStats()" placeholder="فقرة فرعية">${esc(s.text)}</textarea><input type="number" value="${esc(s.mark)}" oninput="current.questions[${i}].subs[${j}].mark=this.value;updateStats()" placeholder="درجة"><button class="secondary small" onclick="removeSub(${i},${j})">×</button></div>`).join("")}</div></div>`).join("")}
function insertAtQuestion(i,s){current.questions[i].text+=s;renderQuestions()}
function saveToBank(i){
 let q=current.questions[i];
 let meta=q.bankMeta||{};
 bank.push({id:Date.now()+Math.random(),subject:current.subject,grade:current.grade||"",unit:meta.unit||"",chapter:meta.chapter||"",type:meta.type||"مقالي",difficulty:meta.difficulty||"متوسط",text:q.text,mark:q.mark,subs:q.subs});
 localStorage.setItem(BANKKEY,JSON.stringify(bank));renderBank();toast("تم حفظ السؤال في البنك");
}
function openBank(){showScreen("bank")}
function newBankQuestion(){
 let text=prompt("نص السؤال:"); if(!text)return;
 let subject=prompt("المادة:",current.subject)||current.subject;
 let grade=prompt("الصف:",current.grade||"")||"";
 let chapter=prompt("الفصل / الباب:","")||"";
 let unit=prompt("الوحدة / الموضوع:","")||"";
 let type=prompt("نوع السؤال: اختيار من متعدد / صح وخطأ / أكمل الفراغ / تعريف / مسألة / مقالي / عملي","مقالي")||"مقالي";
 let difficulty=prompt("الصعوبة: سهل / متوسط / صعب","متوسط")||"متوسط";
 let mark=prompt("الدرجة:","")||"";
 bank.push({id:Date.now()+Math.random(),subject,grade,chapter,unit,type,difficulty,text,mark,subs:[]});
 localStorage.setItem(BANKKEY,JSON.stringify(bank));renderBank();toast("تمت الإضافة إلى بنك الأسئلة");
}
function seedDemoBank(){
 const samples=[
  {subject:"الرياضيات",grade:"الثالث المتوسط",chapter:"الجبر",unit:"المعادلات",type:"مسألة",difficulty:"متوسط",text:"حل المعادلة: 2x + 5 = 17",mark:"5"},
  {subject:"الإنكليزية",grade:"الثالث المتوسط",chapter:"Unit 1",unit:"Grammar",type:"أكمل الفراغ",difficulty:"سهل",text:"Complete: She ____ to school every day.",mark:"2"},
  {subject:"الفيزياء",grade:"السادس الإعدادي",chapter:"الحركة",unit:"القوانين",type:"مسألة",difficulty:"صعب",text:"احسب السرعة إذا قطعت سيارة 120 m خلال 10 s.",mark:"5"},
  {subject:"الكيمياء",grade:"السادس الإعدادي",chapter:"المحاليل",unit:"التركيز",type:"تعريف",difficulty:"متوسط",text:"عرّف التركيز المولاري.",mark:"3"},
  {subject:"العربية",grade:"الثالث المتوسط",chapter:"النحو",unit:"المفعول به",type:"مقالي",difficulty:"متوسط",text:"استخرج المفعول به واذكر علامة نصبه في الجملة الآتية.",mark:"4"}
 ];
 bank=[...bank,...samples.map((x,i)=>({...x,id:Date.now()+i}))];
 localStorage.setItem(BANKKEY,JSON.stringify(bank));renderBank();toast("تمت إضافة نماذج إلى البنك");
}
function renderBank(){
 let box=$("bankList");if(!box)return;
 let s=($("bankSearch")?.value||"").toLowerCase(),sub=$("bankSubject")?.value||"",grade=$("bankGrade")?.value||"",type=$("bankType")?.value||"",difficulty=$("bankDifficulty")?.value||"";
 let list=bank.filter(q=>(!s||q.text.toLowerCase().includes(s))&&(!sub||q.subject===sub)&&(!grade||q.grade===grade)&&(!type||q.type===type)&&(!difficulty||q.difficulty===difficulty));
 $("bankCount").textContent=bank.length;
 box.innerHTML=list.length?list.map(q=>`<div class="bank-item"><div><p><b>${esc(q.subject)}</b> — ${esc(q.text)}</p><div class="bank-tags"><span class="tag">${esc(q.grade||"بدون صف")}</span><span class="tag">${esc(q.chapter||"بدون فصل")}</span><span class="tag">${esc(q.unit||"بدون وحدة")}</span><span class="tag">${esc(q.type||"مقالي")}</span><span class="tag">${esc(q.difficulty||"متوسط")}</span>${q.mark?`<span class="tag">${esc(q.mark)} درجة</span>`:""}</div></div><div><button class="secondary small" onclick="useBank(${q.id})">إضافة</button><button class="secondary small" onclick="editBank(${q.id})">تعديل</button><button class="secondary small" onclick="deleteBank(${q.id})">حذف</button></div></div>`).join(""):'<div class="hint">لا توجد نتائج مطابقة.</div>';
}
function useBank(id){
 let q=bank.find(x=>x.id===id);if(!q)return;
 current.questions.push({id:Date.now()+Math.random(),text:q.text,mark:q.mark,subs:JSON.parse(JSON.stringify(q.subs||[])),bankMeta:{chapter:q.chapter,unit:q.unit,type:q.type,difficulty:q.difficulty}});
 renderQuestions();showScreen("editor");toast("تمت إضافة السؤال وترقيمه تلقائيًا");
}
function editBank(id){
 let q=bank.find(x=>x.id===id);if(!q)return;
 let text=prompt("نص السؤال:",q.text);if(text===null)return;
 q.text=text;q.chapter=prompt("الفصل / الباب:",q.chapter||"")??q.chapter;q.unit=prompt("الوحدة / الموضوع:",q.unit||"")??q.unit;
 q.type=prompt("نوع السؤال:",q.type||"مقالي")||q.type;q.difficulty=prompt("الصعوبة:",q.difficulty||"متوسط")||q.difficulty;q.mark=prompt("الدرجة:",q.mark||"")??q.mark;
 localStorage.setItem(BANKKEY,JSON.stringify(bank));renderBank();toast("تم تعديل السؤال");
}
function deleteBank(id){if(!confirm("حذف السؤال من البنك؟"))return;bank=bank.filter(x=>x.id!==id);localStorage.setItem(BANKKEY,JSON.stringify(bank));renderBank()}
function exportBankJSON(){
 let blob=new Blob([JSON.stringify(bank,null,2)],{type:"application/json;charset=utf-8"});downloadBlob(blob,"بنك_الأسئلة.json");toast("تم تصدير البنك");
}
function importBankJSON(event){
 let f=event.target.files[0];if(!f)return;let r=new FileReader();
 r.onload=()=>{try{let data=JSON.parse(r.result);if(!Array.isArray(data))throw 0;bank=[...bank,...data];localStorage.setItem(BANKKEY,JSON.stringify(bank));renderBank();toast("تم استيراد البنك بنجاح")}catch(e){toast("ملف البنك غير صالح")}};
 r.readAsText(f);event.target.value="";
}


function openGenerator(){
 showScreen("generator");
 if($("genSubject"))$("genSubject").value=current.subject||"";
 if($("genGrade"))$("genGrade").value=current.grade||"";
}
function shuffle(arr){for(let i=arr.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[arr[i],arr[j]]=[arr[j],arr[i]]}return arr}
function generateExam(){
 let subject=$("genSubject").value,grade=$("genGrade").value,chapter=$("genChapter").value.trim(),unit=$("genUnit").value.trim();
 let count=Math.max(1,Number($("genCount").value)||10),total=Math.max(1,Number($("genTotal").value)||100);
 let easy=Math.max(0,Number($("genEasy").value)||0),medium=Math.max(0,Number($("genMedium").value)||0),hard=Math.max(0,Number($("genHard").value)||0);
 let sum=easy+medium+hard;if(sum===0){medium=100;sum=100}
 let type=$("genType").value;
 let pool=bank.filter(q=>(!subject||q.subject===subject)&&(!grade||q.grade===grade)&&(!chapter||q.chapter===chapter)&&(!unit||q.unit===unit)&&(!type||q.type===type));
 if(!pool.length){$("generatorResult").innerHTML='<div class="hint">لا توجد أسئلة مطابقة. أضف أسئلة إلى البنك أو وسّع شروط البحث.</div>';return}
 let buckets={سهل:shuffle(pool.filter(q=>q.difficulty==="سهل")),متوسط:shuffle(pool.filter(q=>q.difficulty==="متوسط")),صعب:shuffle(pool.filter(q=>q.difficulty==="صعب"))};
 let targets=[Math.round(count*easy/sum),Math.round(count*medium/sum),Math.round(count*hard/sum)];
 while(targets.reduce((a,b)=>a+b,0)<count)targets[1]++;
 let selected=[];
 [["سهل",targets[0]],["متوسط",targets[1]],["صعب",targets[2]]].forEach(([d,n])=>{
   let take=buckets[d].slice(0,n);selected.push(...take);
 });
 // Fill missing from remaining pool, prioritizing unused
 if(selected.length<count){
   let ids=new Set(selected.map(x=>x.id));
   let rest=shuffle(pool.filter(x=>!ids.has(x.id)));
   selected.push(...rest.slice(0,count-selected.length));
 }
 selected=shuffle(selected).slice(0,count);
 let auto=$("genAutoMarks").checked;
 let each=Math.floor(total/selected.length),rem=total-each*selected.length;
 current.questions=selected.map((q,i)=>({...JSON.parse(JSON.stringify(q)),id:Date.now()+Math.random()+i,mark:auto?String(each+(i===selected.length-1?rem:0)):q.mark}));
 current.subject=subject||current.subject;current.grade=grade||current.grade;current.totalMark=total;
 loadForm();
 let counts=selected.reduce((o,q)=>(o[q.difficulty||"متوسط"]=(o[q.difficulty||"متوسط"]||0)+1,o),{});
 $("generatorResult").innerHTML=`<div class="generated-card"><b>تم توليد ${selected.length} أسئلة</b><div class="number-preview">سهل: ${counts.سهل||0} — متوسط: ${counts.متوسط||0} — صعب: ${counts.صعب||0} — المجموع: ${total} درجة</div><div class="generator-actions"><button class="primary" onclick="applyGenerated()">اعتماد الامتحان</button><button class="secondary" onclick="generateExam()">توليد جديد</button></div></div>`;
}
function applyGenerated(){saveExam();showScreen("editor");toast("تم اعتماد الامتحان المولد")}
function shuffleGenerated(){
 if(!current.questions.length)return;
 current.questions=shuffle(current.questions);renderQuestions();toast("تمت إعادة ترتيب الأسئلة");
}
function clearGenerated(){$("generatorResult").innerHTML="";toast("تم مسح نتيجة التوليد")}

function paperHTML(){readForm();let dir=current.paperDirection||"rtl";return `<div class="${dir}" style="font-size:${current.fontSize}px"><div class="paper-header">${current.logoData?`<img src="${current.logoData}" style="max-width:90px;max-height:90px;margin-bottom:5px">`:""}${current.headerText?`<div>${esc(current.headerText).replace(/\n/g,"<br>")}</div>`:""}<h1>${esc(current.school||"اسم المدرسة")}</h1><h2>امتحان ${esc(current.subject)}</h2><p>${esc(current.examType||"")} ${current.year?"— "+esc(current.year):""}</p></div><div class="paper-info"><span>الصف: ${esc(current.grade)}</span><span>الوقت: ${esc(current.duration)}</span><span>التاريخ: ${esc(current.date)}</span><span>الدرجة: ${esc(current.totalMark)}</span></div>${current.questions.map((q,i)=>`<div class="paper-q"><div class="paper-q-title">${questionLabel(i)}${q.mark?` (${esc(q.mark)} درجات)`:``}: ${esc(q.text).replace(/\n/g,"<br>")}</div>${q.subs.map((s,j)=>`<div class="paper-sub">${String.fromCharCode(97+j)}) ${esc(s.text).replace(/\n/g,"<br>")} ${s.mark?`(${esc(s.mark)})`:``}</div>`).join("")}</div>`).join("")}<div class="paper-footer">${esc(current.footerText||"").replace(/\n/g,"<br>")}<br>${current.teacher?`المدرس/المعلم: ${esc(current.teacher)}`:""}</div></div>`}
function previewExam(){readForm();$("paper").innerHTML=paperHTML();showScreen("preview")}
function fileBase(){return (current.school||"امتحان")+"_"+(current.subject||"")}
async function exportPDF(){readForm();let holder=document.createElement("div");holder.innerHTML=paperHTML();holder.style.background="#fff";document.body.appendChild(holder);let el=holder.firstElementChild;await html2pdf().set({margin:8,filename:fileBase()+".pdf",image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:true},jsPDF:{unit:"mm",format:"a4",orientation:"portrait"}}).from(el).save();holder.remove()}
async function exportWord(){
 readForm();
 let W=window.docx;
 if(!W){toast("تعذر تحميل Word؛ تحقق من الإنترنت");return}
 let C=W, children=[];
 children.push(new C.Paragraph({text:current.school||"اسم المدرسة",heading:C.HeadingLevel.TITLE,alignment:C.AlignmentType.CENTER}));
 children.push(new C.Paragraph({text:`امتحان ${current.subject||""} — ${current.examType||""}`,alignment:C.AlignmentType.CENTER}));
 children.push(new C.Paragraph({text:`الصف: ${current.grade||""}    الوقت: ${current.duration||""}    التاريخ: ${current.date||""}    الدرجة: ${current.totalMark||""}`,alignment:C.AlignmentType.CENTER}));
 if(current.headerText) children.push(new C.Paragraph({text:current.headerText,alignment:C.AlignmentType.CENTER}));
 current.questions.forEach((q,i)=>{
   children.push(new C.Paragraph({text:`${questionLabel(i)}${q.mark?` (${q.mark} درجات)`:""}: ${q.text}`,bold:true}));
   (q.subs||[]).forEach((sub,j)=>children.push(new C.Paragraph({text:`${String.fromCharCode(97+j)}) ${sub.text}${sub.mark?` (${sub.mark})`:""}`,indent:{right:500}})));
 });
 if(current.footerText) children.push(new C.Paragraph({text:current.footerText,alignment:C.AlignmentType.CENTER}));
 if(current.teacher) children.push(new C.Paragraph({text:`المدرس/المعلم: ${current.teacher}`,alignment:C.AlignmentType.CENTER}));
 let doc=new C.Document({sections:[{properties:{page:{margin:{top:720,right:720,bottom:720,left:720}}},children}]});
 downloadBlob(await C.Packer.toBlob(doc),fileBase()+".docx");
}
function downloadBlob(blob,name){let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
async function exportBoth(){await exportPDF();await exportWord()}
document.addEventListener("DOMContentLoaded",()=>{renderList();newExam()});
if("serviceWorker"in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
