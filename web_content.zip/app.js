const KEY="horfi_demo_v1";
const defaultData={
  settings:{areaLevel:"قرية / منطقة",areaName:"منطقة البداية"},
  users:[{id:"u1",name:"المالك",username:"admin",password:"1234",role:"owner"}],
  customers:[],requests:[],craftsmen:[],applications:[]
};
let data=JSON.parse(localStorage.getItem(KEY)||"null")||defaultData;
let session=null, currentPage="dashboard";

function save(){localStorage.setItem(KEY,JSON.stringify(data))}
function esc(s=""){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.remove("hidden");setTimeout(()=>t.classList.add("hidden"),2800)}
function uid(p){return p+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
function fmt(d){return d?new Date(d).toLocaleDateString("ar-TN"):"—"}

function publicPage(){
document.getElementById("app").innerHTML=`
<header class="topbar"><div class="brand"><div class="logo">🛠️</div><div><h1>حرفي</h1><small>حرفي موثوق... بسعر عادل... بضغطة زر</small></div></div><button class="btn btn-secondary" onclick="showLogin()">دخول الإدارة</button></header>
<main class="public">
<section class="hero">
<div><h2>أصلح عطبك مع <span>حرفي</span> موثوق</h2><p>أرسل طلبك في أقل من دقيقة. في البداية نحتاج فقط إلى بيانات الاتصال والموقع وصورة للعطل إن وجدت، ثم يتواصل معك فريق حرفي لاستكمال التفاصيل.</p>
<div class="features"><span class="pill">📍 تغطية جغرافية تدريجية</span><span class="pill">🛡️ متابعة وضمان</span><span class="pill">⭐ تقييم الخدمة</span><span class="pill">📋 سجل خدمات دائم</span></div></div>
<div class="request-card"><h3>طلب خدمة جديد</h3><div class="hint">4 معلومات فقط — التفاصيل تأتي لاحقًا عبر فريق حرفي.</div>
<form onsubmit="submitRequest(event)"><div class="grid">
<div class="field"><label>الاسم واللقب *</label><input id="cName" required placeholder="مثال: أحمد العجيمي"></div>
<div class="field"><label>رقم الهاتف *</label><input id="cPhone" required type="tel" placeholder="مثال: 20 000 000"></div>
<div class="field full"><label>الموقع *</label><input id="cLocation" required placeholder="المنطقة / المدينة / العنوان المختصر"></div>
<div class="field full"><label>صورة العطل (اختياري)</label><div class="upload"><input id="cImage" type="file" accept="image/*"></div></div>
</div><button class="btn btn-primary submit">📨 إرسال الطلب</button></form><div id="successBox"></div></div>
</section><div class="public-note">بعد الإرسال، يتصل بك فريق حرفي لاستكمال نوع الخدمة، التفاصيل، الموعد، الميزانية وقطع الغيار عند الحاجة.</div>
</main>`;
}
function submitRequest(e){
e.preventDefault();const name=cName.value.trim(),phone=cPhone.value.trim(),location=cLocation.value.trim();
let customer=data.customers.find(x=>x.phone===phone);
if(!customer){customer={id:uid("c"),name,phone,location,createdAt:new Date().toISOString(),services:[]};data.customers.push(customer)}
else{customer.name=name;customer.location=location}
const file=document.getElementById("cImage").files[0];
data.requests.unshift({id:uid("r"),customerId:customer.id,name,phone,location,imageName:file?file.name:"",createdAt:new Date().toISOString(),status:"جديد",details:{},serviceHistoryAdded:false});
save();document.getElementById("successBox").innerHTML=`<div class="success">تم استلام طلبك بنجاح. رقم الطلب: ${data.requests[0].id.toUpperCase()}<br>سيتواصل معك فريق حرفي لاستكمال التفاصيل.</div>`;e.target.reset();toast("تم إرسال الطلب")}
function showLogin(){document.getElementById("app").innerHTML=`
<div class="login"><div class="login-card"><div class="login-logo"><div class="logo">🛠️</div><h2>حرفي — الإدارة</h2><p>الدخول إلى لوحة التحكم</p></div>
<form onsubmit="login(event)"><div class="field"><label>اسم المستخدم</label><input id="loginUser" required value="admin"></div><div class="field" style="margin-top:12px"><label>كلمة المرور</label><input id="loginPass" required type="password" value="1234"></div><button class="btn btn-primary submit">دخول</button><div id="loginError"></div></form><button class="btn btn-secondary submit" onclick="publicPage()">← العودة لواجهة العميل</button>
<small style="display:block;text-align:center;color:#8a98a8;margin-top:14px">نسخة تجريبية: admin / 1234</small></div></div>`}
function login(e){e.preventDefault();const u=data.users.find(x=>x.username===loginUser.value&&x.password===loginPass.value);if(!u){loginError.innerHTML='<div class="error">اسم المستخدم أو كلمة المرور غير صحيحة.</div>';return}session=u;currentPage="dashboard";adminPage()}
function logout(){session=null;publicPage()}

function adminPage(){
document.getElementById("app").innerHTML=`<header class="topbar"><div class="brand"><div class="logo">🛠️</div><div><h1>حرفي</h1><small>لوحة الإدارة — ${esc(session.name)}</small></div></div><button class="btn btn-secondary" onclick="logout()">خروج</button></header>
<div class="admin-layout"><aside class="sidebar">${nav("dashboard","📊 لوحة التحكم")}${nav("requests","📥 طلبات العملاء")}${nav("customers","👥 العملاء")}${nav("craftsmen","🔧 الحرفيون")}${nav("applications","📨 طلبات الانضمام")}${session.role==="owner"?nav("staff","👤 الموظفون"): ""}${session.role==="owner"?nav("settings","⚙️ الإعدادات"): ""}</aside><main class="main" id="content"></main></div>`;renderPage()}
function nav(id,label){return `<button class="nav-btn ${currentPage===id?"active":""}" onclick="go('${id}')">${label}</button>`}
function go(p){currentPage=p;adminPage()}

function renderPage(){const c=document.getElementById("content");if(currentPage==="dashboard")dashboard(c);if(currentPage==="requests")requests(c);if(currentPage==="customers")customers(c);if(currentPage==="craftsmen")craftsmen(c);if(currentPage==="applications")applications(c);if(currentPage==="staff")staff(c);if(currentPage==="settings")settings(c)}
function dashboard(c){
const open=data.requests.filter(r=>r.status!=="مكتمل").length, done=data.requests.filter(r=>r.status==="مكتمل").length;
c.innerHTML=`<div class="page-head"><div><h2>لوحة التحكم</h2><p>نظرة سريعة على نشاط منصة حرفي</p></div></div>
<div class="stats"><div class="stat"><div class="icon">📥</div><strong>${data.requests.length}</strong><span>إجمالي الطلبات</span></div><div class="stat"><div class="icon">⏳</div><strong>${open}</strong><span>طلبات قيد المتابعة</span></div><div class="stat"><div class="icon">👥</div><strong>${data.customers.length}</strong><span>عملاء محفوظون</span></div><div class="stat"><div class="icon">🔧</div><strong>${data.craftsmen.length}</strong><span>حرفيون معتمدون</span></div></div>
<div class="card panel"><h3>آخر الطلبات</h3>${requestTable(data.requests.slice(0,7))}</div>`;
}
function requestTable(rows){if(!rows.length)return '<div class="empty">لا توجد طلبات حتى الآن.</div>';return `<div class="table-wrap"><table class="table"><thead><tr><th>التاريخ</th><th>العميل</th><th>الهاتف</th><th>الموقع</th><th>الحالة</th><th>إجراء</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${fmt(r.createdAt)}</td><td>${esc(r.name)}</td><td>${esc(r.phone)}</td><td>${esc(r.location)}</td><td>${badge(r.status)}</td><td><button class="btn btn-secondary" onclick="openRequest('${r.id}')">فتح</button></td></tr>`).join("")}</tbody></table></div>`}
function badge(s){let cls=s==="مكتمل"?"green":s==="جديد"?"blue":s==="ملغى"?"red":"orange";return `<span class="badge ${cls}">${esc(s)}</span>`}

function requests(c){c.innerHTML=`<div class="page-head"><div><h2>طلبات العملاء</h2><p>استقبل الطلب أولًا ثم استكمل التفاصيل أثناء التواصل مع العميل.</p></div></div>
<div class="card panel"><div class="toolbar"><input id="rqSearch" placeholder="بحث بالاسم أو الهاتف..." oninput="filterRequests()"><select id="rqStatus" onchange="filterRequests()"><option value="">كل الحالات</option><option>جديد</option><option>تم التواصل</option><option>قيد التنفيذ</option><option>مكتمل</option><option>ملغى</option></select></div><div id="rqTable">${requestTable(data.requests)}</div></div>`}
function filterRequests(){let q=rqSearch.value.toLowerCase(),s=rqStatus.value;let rows=data.requests.filter(r=>(!q||(r.name+r.phone).toLowerCase().includes(q))&&(!s||r.status===s));rqTable.innerHTML=requestTable(rows)}
function openRequest(id){const r=data.requests.find(x=>x.id===id);const customer=data.customers.find(x=>x.id===r.customerId);
document.body.insertAdjacentHTML("beforeend",`<div class="modal show" id="requestModal"><div class="modal-box"><div class="modal-head"><h3>طلب ${esc(r.id.toUpperCase())}</h3><button class="close" onclick="closeModal()">✕</button></div>
<div class="two-col"><div class="detail"><div class="detail-item"><b>العميل:</b>${esc(r.name)}</div><div class="detail-item"><b>الهاتف:</b>${esc(r.phone)}</div><div class="detail-item"><b>الموقع:</b>${esc(r.location)}</div><div class="detail-item"><b>الصورة:</b>${esc(r.imageName||"لم تُرفق")}</div><div class="detail-item"><b>أُرسل في:</b>${fmt(r.createdAt)}</div></div>
<div><div class="field"><label>الحالة</label><select id="mStatus"><option ${r.status==="جديد"?"selected":""}>جديد</option><option ${r.status==="تم التواصل"?"selected":""}>تم التواصل</option><option ${r.status==="قيد التنفيذ"?"selected":""}>قيد التنفيذ</option><option ${r.status==="مكتمل"?"selected":""}>مكتمل</option><option ${r.status==="ملغى"?"selected":""}>ملغى</option></select></div>
<div class="field" style="margin-top:10px"><label>نوع الخدمة</label><input id="mService" value="${esc(r.details.service||"")}"></div>
<div class="field" style="margin-top:10px"><label>تفاصيل العطل</label><textarea id="mDetails">${esc(r.details.details||"")}</textarea></div>
<div class="field" style="margin-top:10px"><label>الاستعجال</label><select id="mUrgency"><option ${r.details.urgency==="عادي"?"selected":""}>عادي</option><option ${r.details.urgency==="مستعجل"?"selected":""}>مستعجل</option><option ${r.details.urgency==="طارئ"?"selected":""}>طارئ</option></select></div>
<div class="field" style="margin-top:10px"><label>السعر</label><input id="mPrice" type="number" value="${esc(r.details.price||"")}"></div>
<div class="field" style="margin-top:10px"><label>الحرفي</label><select id="mCraft"><option value="">— اختر —</option>${data.craftsmen.map(x=>`<option value="${x.id}" ${r.details.craftsmanId===x.id?"selected":""}>${esc(x.name)} — ${esc(x.specialty)}</option>`).join("")}</select></div></div></div>
<div style="display:flex;gap:10px;margin-top:20px;justify-content:flex-start"><button class="btn btn-primary" onclick="saveRequest('${r.id}')">حفظ التحديث</button><button class="btn btn-secondary" onclick="closeModal()">إغلاق</button></div></div></div>`)}
function saveRequest(id){const r=data.requests.find(x=>x.id===id);r.status=mStatus.value;r.details={service:mService.value,details:mDetails.value,urgency:mUrgency.value,price:mPrice.value,craftsmanId:mCraft.value};
if(r.status==="مكتمل"&&!r.serviceHistoryAdded){let c=data.customers.find(x=>x.id===r.customerId);if(c){c.services.unshift({id:uid("s"),requestId:r.id,date:new Date().toISOString(),service:r.details.service,details:r.details.details,price:r.details.price,craftsmanId:r.details.craftsmanId,warranty:"حسب الاتفاق"});r.serviceHistoryAdded=true}}save();closeModal();toast("تم حفظ الطلب");renderPage()}
function closeModal(){document.querySelectorAll(".modal").forEach(x=>x.remove())}

function customers(c){c.innerHTML=`<div class="page-head"><div><h2>أرشيف العملاء</h2><p>بعد أول خدمة يصبح للعميل ملف دائم وسجل كامل للخدمات.</p></div></div><div class="card panel"><div class="toolbar"><input id="cuSearch" placeholder="ابحث بالهاتف أو الاسم..." oninput="filterCustomers()"></div><div id="cuTable">${customerTable(data.customers)}</div></div>`}
function customerTable(rows){if(!rows.length)return '<div class="empty">لا يوجد عملاء محفوظون.</div>';return `<div class="table-wrap"><table class="table"><thead><tr><th>الاسم</th><th>الهاتف</th><th>الموقع</th><th>عدد الخدمات</th><th>آخر خدمة</th><th></th></tr></thead><tbody>${rows.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td>${esc(x.location)}</td><td>${x.services.length}</td><td>${x.services[0]?fmt(x.services[0].date):"—"}</td><td><button class="btn btn-secondary" onclick="openCustomer('${x.id}')">الملف</button></td></tr>`).join("")}</tbody></table></div>`}
function filterCustomers(){let q=cuSearch.value.toLowerCase();cuTable.innerHTML=customerTable(data.customers.filter(x=>(x.name+x.phone+x.location).toLowerCase().includes(q)))}
function openCustomer(id){const x=data.customers.find(c=>c.id===id);document.body.insertAdjacentHTML("beforeend",`<div class="modal show"><div class="modal-box"><div class="modal-head"><h3>ملف العميل</h3><button class="close" onclick="closeModal()">✕</button></div><div class="detail"><div class="detail-item"><b>الاسم:</b>${esc(x.name)}</div><div class="detail-item"><b>الهاتف:</b>${esc(x.phone)}</div><div class="detail-item"><b>الموقع:</b>${esc(x.location)}</div></div><h3 style="margin-top:20px">سجل الخدمات</h3>${x.services.length?x.services.map(s=>`<div class="card panel" style="box-shadow:none;background:#f8fafc"><b>${esc(s.service||"خدمة")}</b><br>التاريخ: ${fmt(s.date)}<br>السعر: ${esc(s.price||"—")}<br>الضمان: ${esc(s.warranty||"—")}<br>${esc(s.details||"")}</div>`).join(""):'<div class="empty">لم تكتمل أي خدمة بعد.</div>'}</div></div>`)}

function craftsmen(c){c.innerHTML=`<div class="page-head"><div><h2>الحرفيون</h2><p>إدارة شبكة الحرفيين المعتمدين.</p></div></div><div class="card panel">${data.craftsmen.length?`<div class="table-wrap"><table class="table"><thead><tr><th>الاسم</th><th>الهاتف</th><th>التخصص</th><th>المنطقة</th><th>الحالة</th></tr></thead><tbody>${data.craftsmen.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td>${esc(x.specialty)}</td><td>${esc(x.area)}</td><td>${badge(x.status)}</td></tr>`).join("")}</tbody></table></div>`:'<div class="empty">لا يوجد حرفيون معتمدون. ستظهر طلبات الانضمام في القسم المخصص.</div>'}</div>`}
function applications(c){c.innerHTML=`<div class="page-head"><div><h2>طلبات الانضمام</h2><p>راجع طلبات الحرفيين وتواصل معهم ثم اعتمد من يستوفي الشروط.</p></div></div><div class="card panel">${data.applications.length?`<div class="table-wrap"><table class="table"><thead><tr><th>الاسم</th><th>الهاتف</th><th>التخصص</th><th>المنطقة</th><th>الحالة</th><th>إجراء</th></tr></thead><tbody>${data.applications.map(a=>`<tr><td>${esc(a.name)}</td><td>${esc(a.phone)}</td><td>${esc(a.specialty)}</td><td>${esc(a.area)}</td><td>${badge(a.status)}</td><td>${a.status==="جديد"?`<button class="btn btn-green" onclick="approveApp('${a.id}')">اعتماد</button>`:"—"}</td></tr>`).join("")}</tbody></table></div>`:'<div class="empty">لا توجد طلبات انضمام.</div>'}</div>`}
function approveApp(id){let a=data.applications.find(x=>x.id===id);a.status="معتمد";data.craftsmen.unshift({id:uid("h"),name:a.name,phone:a.phone,specialty:a.specialty,area:a.area,status:"نشط"});save();toast("تم اعتماد الحرفي");renderPage()}

function staff(c){if(session.role!=="owner")return c.innerHTML='<div class="card panel"><div class="empty">ليس لديك صلاحية إدارة الموظفين.</div></div>';
c.innerHTML=`<div class="page-head"><div><h2>الموظفون والصلاحيات</h2><p>المالك يحتفظ بكامل الصلاحيات، ويمكنه توزيع العمل على الفريق.</p></div><button class="btn btn-primary" onclick="addStaffModal()">+ موظف جديد</button></div><div class="card panel"><div class="table-wrap"><table class="table"><thead><tr><th>الاسم</th><th>اسم المستخدم</th><th>الدور</th></tr></thead><tbody>${data.users.map(u=>`<tr><td>${esc(u.name)}</td><td>${esc(u.username)}</td><td>${u.role==="owner"?badge("المالك"):badge(u.role)}</td></tr>`).join("")}</tbody></table></div></div>`}
function addStaffModal(){document.body.insertAdjacentHTML("beforeend",`<div class="modal show"><div class="modal-box"><div class="modal-head"><h3>إضافة موظف</h3><button class="close" onclick="closeModal()">✕</button></div><div class="grid"><div class="field"><label>الاسم</label><input id="sName"></div><div class="field"><label>اسم المستخدم</label><input id="sUser"></div><div class="field"><label>كلمة المرور</label><input id="sPass" type="password"></div><div class="field"><label>الدور</label><select id="sRole"><option value="خدمة العملاء">خدمة العملاء</option><option value="علاقات الحرفيين">علاقات الحرفيين</option><option value="المتابعة">المتابعة</option></select></div></div><button class="btn btn-primary" style="margin-top:18px" onclick="saveStaff()">إضافة</button></div></div>`)}
function saveStaff(){if(!sName.value||!sUser.value||!sPass.value)return toast("أكمل البيانات");if(data.users.some(x=>x.username===sUser.value))return toast("اسم المستخدم موجود");data.users.push({id:uid("u"),name:sName.value,username:sUser.value,password:sPass.value,role:sRole.value});save();closeModal();toast("تمت إضافة الموظف");renderPage()}

function settings(c){if(session.role!=="owner")return;c.innerHTML=`<div class="page-head"><div><h2>إعدادات المشروع</h2><p>تحديد نطاق العمل الجغرافي والتوسع تدريجيًا.</p></div></div><div class="card panel"><h3>النطاق الجغرافي الحالي</h3><div class="grid"><div class="field"><label>مستوى التغطية</label><select id="areaLevel"><option ${data.settings.areaLevel==="قرية / منطقة"?"selected":""}>قرية / منطقة</option><option ${data.settings.areaLevel==="مدينة"?"selected":""}>مدينة</option><option ${data.settings.areaLevel==="ولاية / محافظة"?"selected":""}>ولاية / محافظة</option><option ${data.settings.areaLevel==="جهوي"?"selected":""}>جهوي</option></select></div><div class="field"><label>اسم المنطقة</label><input id="areaName" value="${esc(data.settings.areaName)}"></div></div><button class="btn btn-primary" style="margin-top:18px" onclick="saveSettings()">حفظ الإعدادات</button></div>
<div class="card panel"><h3>تنبيه</h3><p style="color:var(--muted);line-height:1.9">هذه نسخة تجريبية تعمل محليًا داخل المتصفح. عند الانتقال للإنتاج يجب نقل قاعدة البيانات والمستخدمين والمصادقة إلى خادم آمن وعدم تخزين كلمات المرور بهذه الطريقة.</p></div>`}
function saveSettings(){data.settings.areaLevel=areaLevel.value;data.settings.areaName=areaName.value;save();toast("تم حفظ النطاق الجغرافي")}
publicPage();
