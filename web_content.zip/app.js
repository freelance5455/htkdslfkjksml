// مدیریت مالی شخصی + نمودار + وام‌ها + تاریخ شمسی

const STORAGE_KEY = 'personal_finance_data_v3';
const LOANS_KEY = 'personal_finance_loans_v3';

let transactions = JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
let loans = JSON.parse(localStorage.getItem(LOANS_KEY)) || [];

// ========== تبدیل تاریخ میلادی به شمسی ==========
function toJalali(gy, gm, gd) {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy = (gy <= 1600) ? 0 : 979;
  gy -= (gy <= 1600) ? 621 : 1600;
  let gy2 = (gm > 2) ? (gy + 1) : gy;
  let days = (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + g_d_m[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let jm = (days < 186) ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  let jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
  return [jy, jm, jd];
}

function getGregorianParts(dateStr) {
  if (!dateStr) return null;
  const m = String(dateStr).match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (!m) return null;
  const gy = Number(m[1]), gm = Number(m[2]), gd = Number(m[3]);
  if (!gy || !gm || !gd || gm < 1 || gm > 12 || gd < 1 || gd > 31) return null;
  return [gy, gm, gd];
}

function formatJalali(dateStr) {
  const parts = getGregorianParts(dateStr);
  if (!parts) return '-';
  const [jy, jm, jd] = toJalali(parts[0], parts[1], parts[2]);
  const months = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
  return `${jd} ${months[jm - 1]} ${jy}`;
}

function formatJalaliShort(dateStr) {
  const parts = getGregorianParts(dateStr);
  if (!parts) return '-';
  const [jy, jm, jd] = toJalali(parts[0], parts[1], parts[2]);
  return `${jy}/${String(jm).padStart(2,'0')}/${String(jd).padStart(2,'0')}`;
}

// محاسبه تاریخ پایان اقساط
function calcEndDate(remaining, monthly, startDate) {
  if (!monthly || monthly <= 0 || remaining <= 0) return null;
  const monthsLeft = Math.ceil(remaining / monthly);
  const d = startDate ? new Date(startDate) : new Date();
  d.setMonth(d.getMonth() + monthsLeft);
  return d.toISOString().slice(0, 10);
}

// عناصر DOM
const form = document.getElementById('transactionForm');
const amountInput = document.getElementById('amount');
const categorySelect = document.getElementById('category');
const noteInput = document.getElementById('note');
const dateInput = document.getElementById('date');
const totalBalanceEl = document.getElementById('totalBalance');
const monthIncomeEl = document.getElementById('monthIncome');
const monthExpenseEl = document.getElementById('monthExpense');
const transactionListEl = document.getElementById('transactionList');
const emptyMessage = document.getElementById('emptyMessage');
const filterMonth = document.getElementById('filterMonth');
const clearAllBtn = document.getElementById('clearAll');
const loanForm = document.getElementById('loanForm');
const loanListEl = document.getElementById('loanList');
const loanEmpty = document.getElementById('loanEmpty');

dateInput.value = new Date().toISOString().slice(0, 10);
updatePersianDatePreview();
dateInput.addEventListener('change', updatePersianDatePreview);
dateInput.addEventListener('input', updatePersianDatePreview);

// تب‌ها
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
    if (tab.dataset.tab === 'charts') drawCharts();
    if (tab.dataset.tab === 'summary') {
      populateSummaryMonthFilter();
      const sumSel = document.getElementById('summaryMonth');
      renderSummary(sumSel ? sumSel.value : 'all');
    }
  });
});

function formatToman(num) {
  return new Intl.NumberFormat('fa-IR').format(Math.abs(Math.round(num))) + ' تومان';
}


// پیش‌نمایش زنده تاریخ شمسی زیر فیلد تاریخ
function updatePersianDatePreview() {
  const input = document.getElementById('date');
  const preview = document.getElementById('persianDatePreview');
  if (!input || !preview) return;

  const parts = getGregorianParts(input.value);
  if (!parts) {
    preview.textContent = 'تاریخ شمسی: —';
    preview.classList.remove('has-date');
    return;
  }

  const [jy, jm, jd] = toJalali(parts[0], parts[1], parts[2]);
  const fa = `${jy}/${String(jm).padStart(2,'0')}/${String(jd).padStart(2,'0')}`
    .replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
  preview.textContent = 'تاریخ شمسی: ' + fa;
  preview.classList.add('has-date');
}

// قالب‌بندی مبالغ هنگام تایپ: جداکنندهٔ سه‌رقمی + اعداد فارسی
function normalizeDigits(value) {
  return String(value || '')
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[^0-9]/g, '');
}

function formatInputNumber(value) {
  const digits = normalizeDigits(value);
  if (!digits) return '';
  const grouped = Number(digits).toLocaleString('fa-IR');
  return grouped;
}

function getInputNumberValue(el) {
  const digits = normalizeDigits(el.value);
  return digits ? Number(digits) : 0;
}

function setupMoneyInput(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('input', () => {
    const raw = el.value;
    const digits = normalizeDigits(raw);
    el.value = digits ? Number(digits).toLocaleString('fa-IR') : '';
  });
  el.addEventListener('blur', () => {
    if (el.value) el.value = formatInputNumber(el.value);
  });
}

setupMoneyInput('amount');
setupMoneyInput('loanTotal');
setupMoneyInput('loanRemaining');
setupMoneyInput('loanMonthly');

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
  localStorage.setItem(LOANS_KEY, JSON.stringify(loans));
}

function calculateSummary() {
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  let total = 0, monthIncome = 0, monthExpense = 0;

  transactions.forEach(t => {
    total += t.type === 'income' ? t.amount : -t.amount;
    const tDate = new Date(t.date);
    if (tDate.getMonth() === currentMonth && tDate.getFullYear() === currentYear) {
      if (t.type === 'income') monthIncome += t.amount;
      else monthExpense += t.amount;
    }
  });

  totalBalanceEl.textContent = formatToman(total);
  monthIncomeEl.textContent = formatToman(monthIncome);
  monthExpenseEl.textContent = formatToman(monthExpense);
}

function populateMonthFilter() {
  const months = new Set();
  transactions.forEach(t => {
    const d = new Date(t.date);
    months.add(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  });
  filterMonth.innerHTML = '<option value="all">همه ماه‌ها</option>';
  [...months].sort().reverse().forEach(m => {
    const [year, month] = m.split('-');
    const name = formatJalali(`${year}-${month}-01`).split(' ').slice(1).join(' ');
    const opt = document.createElement('option');
    opt.value = m;
    opt.textContent = name;
    filterMonth.appendChild(opt);
  });
}

function renderTransactions(filter = 'all') {
  let list = [...transactions];
  if (filter !== 'all') {
    list = list.filter(t => {
      const parts = getGregorianParts(t.date);
      if (!parts) return false;
      return `${parts[0]}-${String(parts[1]).padStart(2, '0')}` === filter;
    });
  }
  list.sort((a, b) => String(b.date).localeCompare(String(a.date)));
  transactionListEl.innerHTML = '';

  if (list.length === 0) {
    emptyMessage.style.display = 'block';
    return;
  }
  emptyMessage.style.display = 'none';

  list.forEach(t => {
    const item = document.createElement('div');
    item.className = `transaction-item ${t.type}`;
    item.innerHTML = `
      <div class="transaction-info">
        <div class="category">${t.category || 'بدون دسته'}</div>
        ${t.note ? `<div class="note">${t.note}</div>` : ''}
        <div class="date">تاریخ: ${formatJalali(t.date)}</div>
      </div>
      <div class="transaction-amount">${t.type === 'income' ? '+' : '-'} ${formatToman(t.amount)}</div>
      <div class="transaction-actions">
        <button type="button" class="edit-transaction-btn" data-id="${String(t.id)}">✏️ ویرایش</button>
        <button type="button" class="delete-transaction-btn" data-id="${String(t.id)}">🗑️ حذف</button>
      </div>
    `;
    transactionListEl.appendChild(item);
  });
}

// رویداد واحد برای دکمه‌های تراکنش؛ حتی بعد از innerHTML مجدد هم کار می‌کند.
if (transactionListEl && !transactionListEl.dataset.v17Events) {
  transactionListEl.dataset.v17Events = '1';
  transactionListEl.addEventListener('click', function (e) {
    const deleteBtn = e.target.closest('.delete-transaction-btn');
    if (deleteBtn && transactionListEl.contains(deleteBtn)) {
      e.preventDefault();
      const id = deleteBtn.dataset.id;
      const index = transactions.findIndex(t => String(t.id) === String(id));
      if (index === -1) {
        alert('تراکنش پیدا نشد.');
        return;
      }
      // دکمه حذف دقیقاً از همان منطق «مبلغ صفر» استفاده می‌کند.
      // یعنی تراکنش را وارد حالت ویرایش می‌کنیم، مبلغ را صفر می‌گذاریم
      // و همان مسیر حذفِ تأییدشده در submit را اجرا می‌کنیم.
      amountInput.value = '۰';
      // برای حذف بدون پرسش، دسته‌بندی را خودکار روی «حقوق» قرار می‌دهیم.
      // سپس همان مسیر ثبت با مبلغ صفر اجرا می‌شود.
      categorySelect.value = 'حقوق';
      form.dataset.editId = String(id);
      form.requestSubmit();
      return;
    }

    const editBtn = e.target.closest('.edit-transaction-btn');
    if (editBtn && transactionListEl.contains(editBtn)) {
      e.preventDefault();
      const id = editBtn.dataset.id;
      const t = transactions.find(x => String(x.id) === String(id));
      if (!t) {
        alert('تراکنش پیدا نشد.');
        return;
      }
      const radio = document.querySelector(`input[name="type"][value="${t.type}"]`);
      if (radio) radio.checked = true;
      // در حالت ویرایش، مبلغ عمداً از صفر شروع می‌شود؛ اگر کاربر صفر ذخیره کند،
      // همان تراکنش حذف می‌شود.
      amountInput.value = '۰';
      categorySelect.value = t.category || '';
      noteInput.value = t.note || '';
      dateInput.value = t.date || '';
      form.dataset.editId = String(id);
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.textContent = 'ذخیره تغییرات';
      updatePersianDatePreview();
      form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
}

// ===== وام‌ها =====
function renderLoans() {
  loanListEl.innerHTML = '';
  if (loans.length === 0) {
    loanEmpty.style.display = 'block';
    return;
  }
  loanEmpty.style.display = 'none';

  loans.forEach(loan => {
    const paid = loan.total - loan.remaining;
    const percent = loan.total > 0 ? Math.min(100, (paid / loan.total) * 100) : 0;
    const installmentsLeft = loan.monthly > 0 ? Math.ceil(loan.remaining / loan.monthly) : 0;
    const dueDay = loan.dueDay || '-';

    const item = document.createElement('div');
    item.className = 'loan-item';
    item.innerHTML = `
      <div class="loan-info">
        <div class="name">${loan.name}</div>
        <div class="details">
          کل وام: ${formatToman(loan.total)}<br>
          مانده: ${formatToman(loan.remaining)}<br>
          قسط ماهانه: ${formatToman(loan.monthly)}<br>
          <strong>قسط‌های مانده: ${installmentsLeft} قسط</strong><br>
          روز سررسید هر ماه: <strong>${dueDay}</strong>
        </div>
        <div class="loan-progress">
          <div class="loan-progress-bar" style="width:${percent}%"></div>
        </div>
        <div style="font-size:0.8rem;color:#666;margin-top:4px">${percent.toFixed(0)}٪ پرداخت شده</div>
      </div>
      <div class="loan-actions">
        <button class="btn-pay" data-id="${loan.id}">پرداخت قسط</button>
        <button class="btn-edit-loan" data-id="${loan.id}">ویرایش</button>
        <button class="btn-delete-loan" data-id="${loan.id}">حذف</button>
      </div>
    `;
    loanListEl.appendChild(item);
  });

  document.querySelectorAll('.btn-pay').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.dataset.id;
      const loan = loans.find(l => l.id === id);
      if (!loan) return;
      const pay = Math.min(loan.monthly, loan.remaining);
      if (pay <= 0) {
        alert('این وام کاملاً تسویه شده است.');
        return;
      }
      loan.remaining -= pay;
      transactions.push({
        id: Date.now().toString(),
        type: 'expense',
        amount: pay,
        category: 'قسط وام',
        note: 'قسط ' + loan.name,
        date: new Date().toISOString().slice(0, 10)
      });
      saveData();
      updateUI();
      alert('قسط با موفقیت ثبت شد.\nمانده: ' + formatToman(loan.remaining));
    });
  });

  // ویرایش وام
  document.querySelectorAll('.btn-edit-loan').forEach(btn => {
    btn.addEventListener('click', e => {
      const id = e.target.dataset.id;
      const loan = loans.find(l => l.id === id);
      if (!loan) return;
      document.getElementById('loanName').value = loan.name;
      document.getElementById('loanTotal').value = loan.total;
      document.getElementById('loanRemaining').value = loan.remaining;
      document.getElementById('loanMonthly').value = loan.monthly;
      document.getElementById('loanDueDay').value = loan.dueDay || '';
      loanForm.dataset.editId = id;
      document.querySelector('#loanForm button[type="submit"]').textContent = 'ذخیره تغییرات';
      // برو به بالای فرم
      document.getElementById('tab-loans').scrollIntoView({ behavior: 'smooth' });
    });
  });

  document.querySelectorAll('.btn-delete-loan').forEach(btn => {
    btn.addEventListener('click', e => {
      if (confirm('این وام حذف شود؟')) {
        loans = loans.filter(l => l.id !== e.target.dataset.id);
        saveData();
        renderLoans();
      }
    });
  });
}

loanForm.addEventListener('submit', e => {
  e.preventDefault();
  const name = document.getElementById('loanName').value.trim();
  const total = getInputNumberValue(document.getElementById('loanTotal'));
  const remaining = getInputNumberValue(document.getElementById('loanRemaining'));
  const monthly = getInputNumberValue(document.getElementById('loanMonthly'));
  const dueDay = parseInt(document.getElementById('loanDueDay').value);

  if (!name || !total || remaining < 0 || !monthly || !dueDay || dueDay < 1 || dueDay > 31) {
    alert('لطفاً همه فیلدها را درست پر کنید.\nروز سررسید باید بین ۱ تا ۳۱ باشد.');
    return;
  }

  // اگر در حالت ویرایش هستیم
  if (loanForm.dataset.editId) {
    const loan = loans.find(l => l.id === loanForm.dataset.editId);
    if (loan) {
      loan.name = name;
      loan.total = total;
      loan.remaining = remaining;
      loan.monthly = monthly;
      loan.dueDay = dueDay;
    }
    delete loanForm.dataset.editId;
    document.querySelector('#loanForm button[type="submit"]').textContent = 'ثبت وام';
  } else {
    loans.push({
      id: Date.now().toString(),
      name,
      total,
      remaining,
      monthly,
      dueDay
    });
  }
  saveData();
  renderLoans();
  loanForm.reset();
});

// ===== نمودارها =====
function drawCharts() {
  drawBarChart();
  drawPieChart();
}

function drawBarChart() {
  const canvas = document.getElementById('barChart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const width = canvas.width = Math.max(canvas.parentElement.clientWidth - 24, 320);
  const height = canvas.height = 260;

  // داده‌های ۱۲ ماه سال جاری
  const now = new Date();
  const year = now.getFullYear();
  const incomes = new Array(12).fill(0);
  const expenses = new Array(12).fill(0);

  transactions.forEach(t => {
    const td = new Date(t.date);
    if (td.getFullYear() === year) {
      const m = td.getMonth(); // 0-11
      if (t.type === 'income') incomes[m] += t.amount;
      else expenses[m] += t.amount;
    }
  });

  const maxVal = Math.max(...incomes, ...expenses, 1);
  const paddingLeft = 55;
  const paddingRight = 15;
  const paddingTop = 25;
  const paddingBottom = 40;
  const chartW = width - paddingLeft - paddingRight;
  const chartH = height - paddingTop - paddingBottom;
  const groupWidth = chartW / 12;
  const barWidth = Math.max(groupWidth * 0.35, 6);
  const gap = 2;

  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#fafafa';
  ctx.fillRect(0, 0, width, height);

  // محورها
  ctx.strokeStyle = '#ccc';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(paddingLeft, paddingTop);
  ctx.lineTo(paddingLeft, height - paddingBottom);
  ctx.lineTo(width - paddingRight, height - paddingBottom);
  ctx.stroke();

  // خطوط افقی راهنما + برچسب مبلغ
  ctx.fillStyle = '#888';
  ctx.font = '10px Tahoma';
  ctx.textAlign = 'left';
  for (let i = 0; i <= 4; i++) {
    const val = Math.round((maxVal / 4) * i);
    const y = height - paddingBottom - (chartH * i / 4);
    ctx.strokeStyle = '#eee';
    ctx.beginPath();
    ctx.moveTo(paddingLeft, y);
    ctx.lineTo(width - paddingRight, y);
    ctx.stroke();
    ctx.fillStyle = '#666';
    const label = val >= 1000000 ? (val/1000000).toFixed(1) + 'M' : (val >= 1000 ? Math.round(val/1000) + 'K' : String(val));
    ctx.fillText(label, 4, y + 3);
  }

  // میله‌ها و شماره ماه ۱ تا ۱۲
  for (let i = 0; i < 12; i++) {
    const groupX = paddingLeft + i * groupWidth + groupWidth / 2;
    const xIncome = groupX - barWidth - gap / 2;
    const xExpense = groupX + gap / 2;

    // درآمد (سبز)
    const hInc = (incomes[i] / maxVal) * chartH;
    ctx.fillStyle = '#43a047';
    ctx.fillRect(xIncome, height - paddingBottom - hInc, barWidth, hInc);

    // هزینه (قرمز) - کنار هم
    const hExp = (expenses[i] / maxVal) * chartH;
    ctx.fillStyle = '#e53935';
    ctx.fillRect(xExpense, height - paddingBottom - hExp, barWidth, hExp);

    // شماره ماه ۱ تا ۱۲
    ctx.fillStyle = '#333';
    ctx.font = '11px Tahoma';
    ctx.textAlign = 'center';
    ctx.fillText(String(i + 1), groupX, height - paddingBottom + 16);
  }

  // راهنما
  ctx.fillStyle = '#43a047';
  ctx.fillRect(width - 95, 8, 12, 12);
  ctx.fillStyle = '#333';
  ctx.font = '11px Tahoma';
  ctx.textAlign = 'right';
  ctx.fillText('درآمد', width - 18, 18);

  ctx.fillStyle = '#e53935';
  ctx.fillRect(width - 95, 26, 12, 12);
  ctx.fillStyle = '#333';
  ctx.fillText('هزینه', width - 18, 36);
}

function drawPieChart() {
  const canvas = document.getElementById('pieChart');
  const legend = document.getElementById('pieLegend');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const width = canvas.width = canvas.parentElement.clientWidth - 24;
  const height = canvas.height = 220;
  const cx = width / 2;
  const cy = height / 2;
  const radius = Math.min(cx, cy) - 20;

  const cats = {};
  transactions.filter(t => t.type === 'expense').forEach(t => {
    cats[t.category] = (cats[t.category] || 0) + t.amount;
  });
  const entries = Object.entries(cats);
  const total = entries.reduce((s, [, v]) => s + v, 0) || 1;
  const colors = ['#e53935','#fb8c00','#fdd835','#43a047','#1e88e5','#8e24aa','#00acc1','#6d4c41'];

  ctx.clearRect(0, 0, width, height);
  if (entries.length === 0) {
    ctx.fillStyle = '#999';
    ctx.font = '14px Tahoma';
    ctx.textAlign = 'center';
    ctx.fillText('هنوز هزینه‌ای ثبت نشده', cx, cy);
    legend.innerHTML = '';
    return;
  }

  let start = -Math.PI / 2;
  entries.forEach(([, val], i) => {
    const slice = (val / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, radius, start, start + slice);
    ctx.closePath();
    ctx.fillStyle = colors[i % colors.length];
    ctx.fill();
    start += slice;
  });

  legend.innerHTML = entries.map(([cat, val], i) => {
    const pct = ((val / total) * 100).toFixed(0);
    return `<span><i style="background:${colors[i % colors.length]}"></i>${cat} (${pct}٪)</span>`;
  }).join('');
}


// ===== خلاصه =====
function renderSummary(filter = 'all') {
  const container = document.getElementById('summaryContent');
  const emptyEl = document.getElementById('summaryEmpty');
  if (!container) return;

  let list = [...transactions];
  if (filter !== 'all') {
    list = list.filter(t => {
      const d = new Date(t.date);
      return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}` === filter;
    });
  }

  if (list.length === 0) {
    container.innerHTML = '';
    emptyEl.style.display = 'block';
    return;
  }
  emptyEl.style.display = 'none';

  // جدا کردن درآمد و هزینه
  const incomes = list.filter(t => t.type === 'income');
  const expenses = list.filter(t => t.type === 'expense');

  function groupByCategoryThenNote(items) {
    // دسته → یادداشت → مبلغ
    const catMap = {};
    items.forEach(t => {
      const cat = t.category || 'بدون دسته';
      const note = (t.note && t.note.trim()) ? t.note.trim() : 'بدون یادداشت';
      if (!catMap[cat]) catMap[cat] = {};
      if (!catMap[cat][note]) catMap[cat][note] = 0;
      catMap[cat][note] += t.amount;
    });
    return catMap;
  }

  function buildGroupHtml(title, color, items) {
    if (items.length === 0) return '';
    const groups = groupByCategoryThenNote(items);
    let total = items.reduce((s, t) => s + t.amount, 0);
    let html = `<div class="summary-block" style="border-right:4px solid ${color}">
      <div class="summary-title" style="color:${color}">${title} — جمع کل: ${formatToman(total)}</div>`;

    Object.keys(groups).sort().forEach(cat => {
      const notes = groups[cat];
      const catTotal = Object.values(notes).reduce((s, v) => s + v, 0);
      html += `<div class="summary-cat">
        <div class="summary-cat-name">${cat} <span class="summary-cat-total">${formatToman(catTotal)}</span></div>
        <div class="summary-notes">`;
      Object.keys(notes).sort().forEach(note => {
        html += `<div class="summary-note-row">
          <span class="summary-note">${note}</span>
          <span class="summary-note-amount">${formatToman(notes[note])}</span>
        </div>`;
      });
      html += `</div></div>`;
    });
    html += `</div>`;
    return html;
  }

  let out = '';
  out += buildGroupHtml('درآمدها (دارایی)', '#2e7d32', incomes);
  out += buildGroupHtml('هزینه‌ها (مخارج)', '#c62828', expenses);
  container.innerHTML = out;
}

function populateSummaryMonthFilter() {
  const sel = document.getElementById('summaryMonth');
  if (!sel) return;
  const months = new Set();
  transactions.forEach(t => {
    const d = new Date(t.date);
    months.add(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
  });
  const current = sel.value;
  sel.innerHTML = '<option value="all">همه ماه‌ها</option>';
  [...months].sort().reverse().forEach(m => {
    const [year, month] = m.split('-');
    const name = formatJalali(`${year}-${month}-01`).split(' ').slice(1).join(' ');
    const opt = document.createElement('option');
    opt.value = m;
    opt.textContent = name;
    sel.appendChild(opt);
  });
  if ([...sel.options].some(o => o.value === current)) sel.value = current;
}


function updateUI() {
  calculateSummary();
  populateMonthFilter();
  populateSummaryMonthFilter();
  renderTransactions(filterMonth.value);
  renderLoans();
  const sumSel = document.getElementById('summaryMonth');
  renderSummary(sumSel ? sumSel.value : 'all');
  if (document.getElementById('tab-charts').classList.contains('active')) {
    drawCharts();
  }
}

form.addEventListener('submit', e => {
  e.preventDefault();
  const typeEl = document.querySelector('input[name="type"]:checked');
  const type = typeEl ? typeEl.value : 'income';
  const amount = getInputNumberValue(amountInput);
  const category = categorySelect.value;
  const note = noteInput.value.trim();
  const date = dateInput.value;

  // در حالت ویرایش، مبلغ صفر یعنی کاربر می‌خواهد کل همان تراکنش پاک شود.
  if (form.dataset.editId && amount === 0) {
    const editId = String(form.dataset.editId);
    const index = transactions.findIndex(x => String(x.id) === editId);
    if (index !== -1) {
      transactions.splice(index, 1);
      saveData();
      delete form.dataset.editId;
      const submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.textContent = 'ثبت تراکنش';
      form.reset();
      dateInput.value = new Date().toISOString().slice(0, 10);
      updatePersianDatePreview();
      const incomeRadio = document.querySelector('input[name="type"][value="income"]');
      if (incomeRadio) incomeRadio.checked = true;
      updateUI();
    }
    return;
  }

  if (!amount || amount < 1 || !category || !date) {
    alert('لطفاً مبلغ را بیشتر از صفر وارد کنید و همه فیلدهای ضروری را پر کنید.');
    return;
  }

  if (form.dataset.editId) {
    const t = transactions.find(x => String(x.id) === String(form.dataset.editId));
    if (t) {
      t.type = type;
      t.amount = amount;
      t.category = category;
      t.note = note;
      t.date = date;
    }
    delete form.dataset.editId;
    const submitBtn = form.querySelector('button[type="submit"]');
    if (submitBtn) submitBtn.textContent = 'ثبت تراکنش';
  } else {
    transactions.push({
      id: Date.now().toString(),
      type,
      amount,
      category,
      note,
      date
    });
  }

  saveData();
  updateUI();
  form.reset();
  dateInput.value = new Date().toISOString().slice(0, 10);
  updatePersianDatePreview();
  const incomeRadio = document.querySelector('input[name="type"][value="income"]');
  if (incomeRadio) incomeRadio.checked = true;
});

filterMonth.addEventListener('change', () => renderTransactions(filterMonth.value));

document.getElementById('summaryMonth')?.addEventListener('change', (e) => {
  renderSummary(e.target.value);
});


// ===== پشتیبان‌گیری و بازیابی =====
function doImportData(data) {
  if (!data || !data.transactions || !Array.isArray(data.transactions)) {
    alert('فایل یا متن بکاپ معتبر نیست.');
    return false;
  }
  if (!confirm('با لود بکاپ، داده‌های فعلی جایگزین می‌شوند.\\nادامه می‌دهید؟')) return false;
  transactions = data.transactions || [];
  loans = data.loans || [];
  saveData();
  updateUI();
  alert('داده‌ها با موفقیت لود شدند.\\nتراکنش‌ها: ' + transactions.length + '\\nوام‌ها: ' + loans.length);
  return true;
}

document.getElementById('btnExport')?.addEventListener('click', () => {
  const backup = {
    version: 3,
    app: 'برنامه مالی',
    exportDate: new Date().toISOString(),
    transactions: transactions,
    loans: loans
  };
  const json = JSON.stringify(backup, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'backup-mali-' + new Date().toISOString().slice(0, 10) + '.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  alert('بکاپ گرفته شد.\\nفایل را در گوشی نگه دارید.');
});

document.getElementById('btnImport')?.addEventListener('click', () => {
  const panel = document.getElementById('importPanel');
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
});

document.getElementById('btnCloseImport')?.addEventListener('click', () => {
  document.getElementById('importPanel').style.display = 'none';
  document.getElementById('importText').value = '';
});

document.getElementById('btnChooseFile')?.addEventListener('click', () => {
  document.getElementById('importFile').click();
});

document.getElementById('importFile')?.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    try {
      const data = JSON.parse(ev.target.result);
      if (doImportData(data)) {
        document.getElementById('importPanel').style.display = 'none';
        document.getElementById('importText').value = '';
      }
    } catch (err) {
      alert('خطا در خواندن فایل.\\nمطمئن شوید فایل بکاپ JSON است.');
    }
    e.target.value = '';
  };
  reader.readAsText(file);
});

document.getElementById('btnLoadPaste')?.addEventListener('click', () => {
  const text = document.getElementById('importText').value.trim();
  if (!text) {
    alert('ابتدا متن بکاپ را Paste کنید یا فایل انتخاب کنید.');
    return;
  }
  try {
    const data = JSON.parse(text);
    if (doImportData(data)) {
      document.getElementById('importPanel').style.display = 'none';
      document.getElementById('importText').value = '';
    }
  } catch (err) {
    alert('متن وارد شده JSON معتبر نیست.\\nکل محتوای فایل بکاپ را کپی و اینجا Paste کنید.');
  }
});


clearAllBtn.addEventListener('click', () => {
  if (confirm('همه تراکنش‌ها و وام‌ها حذف شوند؟')) {
    transactions = [];
    loans = [];
    saveData();
    updateUI();
  }
});

updateUI();
