const $ = id => document.getElementById(id);
const money = n => "₹" + Math.round(Number(n)||0).toLocaleString("en-IN");

const defaults = [
  {area:"",name:"MAIN FABRIC",rate:830,unit:"MTR",qty:47.5,fabric:false},
  {area:"",name:"SHEER FABRIC",rate:578,unit:"MTR",qty:38.5,fabric:false},
  {area:"",name:"BLACKOUT FABRIC",rate:345,unit:"MTR",qty:47,fabric:false},
  {area:"",name:"CURTAIN STITCHING",rate:170,unit:"PCS",qty:29,fabric:false}
];

let items = JSON.parse(localStorage.getItem("fr_items") || "null") || defaults;

function todayISO(){
  const d=new Date(), z=n=>String(n).padStart(2,"0");
  return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}`;
}
$("quoteDate").value = localStorage.getItem("fr_date") || "2026-08-20";

function addItem(item={area:"",name:"",rate:0,unit:"MTR",qty:1,fabric:false}){
  items.push(item); renderEditor(); calculate();
}
$("addItemBtn").onclick=()=>addItem();

function renderEditor(){
  const box=$("itemsEditor"); box.innerHTML="";
  items.forEach((it,i)=>{
    const row=document.createElement("div"); row.className="item-row";
    row.innerHTML=`
      <input class="item-area" value="${esc(it.area||"")}" placeholder="Area">
      <input class="item-name" value="${esc(it.name)}" placeholder="Material">
      <input class="item-rate" type="number" min="0" step="0.01" value="${it.rate}">
      <input class="item-unit" value="${esc(it.unit)}" placeholder="Unit">
      <input class="item-qty" type="number" min="0" step="0.01" value="${it.qty}">
      <div class="item-amount">${money(it.rate*it.qty)}</div>
      <button class="icon-btn delete-item">×</button>`;
    const inputs=row.querySelectorAll("input");
    inputs.forEach((el,k)=>el.addEventListener("input",()=>{
      items[i]={
        area:row.querySelector(".item-area").value,
        name:row.querySelector(".item-name").value,
        rate:Number(row.querySelector(".item-rate").value)||0,
        unit:row.querySelector(".item-unit").value,
        qty:Number(row.querySelector(".item-qty").value)||0,
        fabric:false
      };
      save(); calculate();
    }));
    row.querySelector(".delete-item").onclick=()=>{items.splice(i,1);save();renderEditor();calculate()};
    box.appendChild(row);
  });
}
function esc(s){return String(s??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll('"',"&quot;")}

function calculate(){
  let total=0;
  items.forEach(x=>{ total += (Number(x.rate)||0)*(Number(x.qty)||0); });
  const advance=Number($("advanceAmount").value)||0;
  const payable=Math.max(0,total-advance);
  $("pTotal").textContent=money(total);
  $("pAdvance").textContent=money(advance);
  $("pPayable").textContent=money(payable);
  $("pItems").innerHTML=items.map((x,i)=>`<tr>
    <td>${esc(x.area||"")}</td><td>${esc(x.name)}</td><td>${money(x.rate)}</td>
    <td>${esc(x.unit)}</td><td>${x.qty}</td><td>${money(x.rate*x.qty)}</td>
  </tr>`).join("");
  save();
}

function bind(id,pid,format=v=>v){
  $(id).addEventListener("input",()=>{$(pid).textContent=format($(id).value);save()});
}
bind("companyName","pCompanyName");
bind("ownerName","pOwnerName");
bind("companyAddress","pCompanyAddress");
bind("companyPhone","pCompanyPhone");
bind("companyEmail","pCompanyEmail");
bind("quoteNo","pQuoteNo");
bind("customerName","pCustomerName");
bind("customerAddress","pCustomerAddress");
bind("customerPhone","pCustomerPhone");
bind("closingMessage","pClosing");
bind("signatureText","pSignature");
bind("authorizedText","pAuthorized");
$("advanceAmount").addEventListener("input",calculate);
$("quoteDate").addEventListener("input",()=>{updateDate();save()});
$("terms").addEventListener("input",()=>{updateTerms();save()});

function updateDate(){
  const v=$("quoteDate").value;
  if(!v)return;
  const [y,m,d]=v.split("-");
  $("pDate").textContent=`${d}-${m}-${y}`;
}
function updateTerms(){
  const lines=$("terms").value.split(/\n+/).map(x=>x.trim()).filter(Boolean);
  $("pTerms").innerHTML=lines.map(x=>`<li>${esc(x.replace(/^\d+\.\s*/,""))}</li>`).join("");
}
function save(){
  localStorage.setItem("fr_items",JSON.stringify(items));
  ["companyName","ownerName","companyAddress","companyPhone","companyEmail","quoteNo","quoteDate","advanceAmount","customerName","customerAddress","customerPhone","terms","closingMessage","signatureText","authorizedText"].forEach(id=>localStorage.setItem("fr_"+id,$(id).value));
}
function load(){
  ["companyName","ownerName","companyAddress","companyPhone","companyEmail","quoteNo","quoteDate","advanceAmount","customerName","customerAddress","customerPhone","terms","closingMessage","signatureText","authorizedText"].forEach(id=>{
    const v=localStorage.getItem("fr_"+id); if(v!==null)$(id).value=v;
  });
}
function init(){
  load(); renderEditor(); updateDate(); updateTerms(); calculate();
}
$("printBtn").onclick=()=>window.print();
$("newBtn").onclick=()=>{
  if(!confirm("Start a new quotation? Current quotation data will be replaced."))return;
  localStorage.clear();
  items=JSON.parse(JSON.stringify(defaults));
  $("quoteNo").value=String(Number($("quoteNo").value||1567)+1);
  $("quoteDate").value=todayISO();
  $("advanceAmount").value=0;
  $("customerName").value=""; $("customerAddress").value=""; $("customerPhone").value="";
  renderEditor();updateDate();updateTerms();calculate();
};

let deferredInstallPrompt=null;
window.addEventListener("beforeinstallprompt",(e)=>{
  e.preventDefault();
  deferredInstallPrompt=e;
  const b=$("installBtn");
  if(b){b.hidden=false;}
});
$("installBtn").onclick=async()=>{
  if(!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt=null;
  $("installBtn").hidden=true;
};
window.addEventListener("appinstalled",()=>{
  const b=$("installBtn");
  if(b) b.hidden=true;
});

if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("service-worker.js").catch(()=>{}));
init();
