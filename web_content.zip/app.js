/* ===== MSS Satpam • PT. Mitracomm ===== */
const DB = {
  barcodes: 'mss_v2_barcodes',
  patrols:  'mss_v2_patrols',
  incidents:'mss_v2_incidents',
  user:     'mss_v2_user'
};

let user = null;
let scanner = null;
let photos = [];          // current form photos
let photoTarget = 0;      // which slot is being filled

/* ---------- helpers ---------- */
const $ = (s, el=document) => el.querySelector(s);
const $$ = (s, el=document) => [...el.querySelectorAll(s)];

function load(key) {
  try { return JSON.parse(localStorage.getItem(key) || '[]'); }
  catch { return []; }
}
function save(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}
function nowISO() { return new Date().toISOString(); }
function nowText() {
  return new Date().toLocaleString('id-ID', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
}
function fmt(iso) {
  if (!iso) return '-';
  return new Date(iso).toLocaleString('id-ID', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}
function toast(msg, type='') {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast ' + type;
  clearTimeout(t._tm);
  t._tm = setTimeout(() => t.classList.add('hidden'), 2800);
}
function uid(prefix) {
  return prefix + Date.now() + Math.random().toString(36).slice(2, 6);
}

/* ---------- init ---------- */
document.addEventListener('DOMContentLoaded', () => {
  // seed barcodes
  if (!localStorage.getItem(DB.barcodes)) {
    save(DB.barcodes, [
      { id: 'BC001', area: 'Gerbang Utama', lokasi: 'Pintu Masuk Utama', createdAt: nowISO() },
      { id: 'BC002', area: 'Parkiran Karyawan', lokasi: 'Area Parkir Barat', createdAt: nowISO() },
      { id: 'BC003', area: 'Gudang A', lokasi: 'Gudang Material A', createdAt: nowISO() },
      { id: 'BC004', area: 'Kantor Admin', lokasi: 'Lantai 1 Ruang Admin', createdAt: nowISO() },
      { id: 'BC005', area: 'Pos Keamanan', lokasi: 'Pos Satpam Depan', createdAt: nowISO() }
    ]);
  }
  if (!localStorage.getItem(DB.patrols)) save(DB.patrols, []);
  if (!localStorage.getItem(DB.incidents)) save(DB.incidents, []);

  const saved = localStorage.getItem(DB.user);
  if (saved) {
    user = JSON.parse(saved);
    showMain();
  }

  $('#btn-login').onclick = doLogin;
  $('#btn-logout').onclick = doLogout;
  $('#modal-bg').onclick = (e) => { if (e.target === $('#modal-bg')) closeModal(); };
});

/* ---------- auth ---------- */
function doLogin() {
  const name = $('#inp-name').value.trim();
  const role = $('#inp-role').value;
  if (!name) { toast('Nama wajib diisi', 'err'); return; }
  user = { name, role, at: nowISO() };
  localStorage.setItem(DB.user, JSON.stringify(user));
  showMain();
}
function doLogout() {
  stopScanner();
  user = null;
  localStorage.removeItem(DB.user);
  $('#screen-main').classList.remove('active');
  $('#screen-login').classList.add('active');
  $('#inp-name').value = '';
}
function showMain() {
  $('#screen-login').classList.remove('active');
  $('#screen-main').classList.add('active');
  $('#lbl-user').textContent = `${user.name} • ${user.role === 'admin' ? 'Admin' : 'Petugas'}`;
  buildTabs();
  go('home');
}

/* ---------- tabs ---------- */
function buildTabs() {
  const isAdmin = user.role === 'admin';
  const tabs = [
    { id: 'home', label: 'Beranda' },
    { id: 'patrol', label: 'Patroli' },
    { id: 'incident', label: 'Laporan' }
  ];
  if (isAdmin) {
    tabs.push({ id: 'barcode', label: 'Barcode' });
    tabs.push({ id: 'data', label: 'Semua Data' });
  } else {
    tabs.push({ id: 'history', label: 'Riwayat' });
  }
  $('#nav-tabs').innerHTML = tabs.map(t =>
    `<button class="tab" data-id="${t.id}">${t.label}</button>`
  ).join('');
  $$('.tab').forEach(b => b.onclick = () => go(b.dataset.id));
}

function go(id) {
  stopScanner();
  photos = [];
  $$('.tab').forEach(b => b.classList.toggle('active', b.dataset.id === id));
  const page = $('#page-content');
  page.innerHTML = '';
  const map = {
    home: renderHome,
    patrol: renderPatrol,
    incident: renderIncident,
    barcode: renderBarcodeAdmin,
    data: renderAllData,
    history: renderHistory
  };
  (map[id] || renderHome)(page);
}

/* ---------- modal ---------- */
function openModal(html) {
  $('#modal-body').innerHTML = html;
  $('#modal-bg').classList.remove('hidden');
}
function closeModal() {
  stopScanner();
  $('#modal-bg').classList.add('hidden');
}

/* ---------- scanner ---------- */
function stopScanner() {
  if (scanner) {
    try { scanner.stop().then(() => scanner = null).catch(() => { scanner = null; }); }
    catch { scanner = null; }
  }
}

/* ========== HOME ========== */
function renderHome(el) {
  const patrols = load(DB.patrols);
  const incidents = load(DB.incidents);
  const today = new Date().toDateString();
  const tPatrol = patrols.filter(p => new Date(p.createdAt).toDateString() === today).length;
  const tInc = incidents.filter(i => new Date(i.createdAt).toDateString() === today).length;
  const temuan = patrols.filter(p => p.kondisi === 'Temuan').length;
  const aktif = incidents.filter(i => i.status !== 'Selesai').length;

  el.innerHTML = `
    <div class="stats">
      <div class="stat"><div class="n">${tPatrol}</div><div class="l">Patroli Hari Ini</div></div>
      <div class="stat"><div class="n">${tInc}</div><div class="l">Laporan Hari Ini</div></div>
      <div class="stat"><div class="n">${temuan}</div><div class="l">Total Temuan</div></div>
      <div class="stat"><div class="n">${aktif}</div><div class="l">Kejadian Aktif</div></div>
    </div>
    <div class="card">
      <div class="card-h">Patroli Terbaru</div>
      ${listRecent(patrols.slice(-5).reverse(), 'patrol')}
    </div>
    <div class="card">
      <div class="card-h">Laporan Terbaru</div>
      ${listRecent(incidents.slice(-5).reverse(), 'incident')}
    </div>`;
}

function listRecent(items, type) {
  if (!items.length) return `<div class="empty"><div class="ico">📋</div>Belum ada data</div>`;
  return items.map(it => {
    if (type === 'patrol') {
      return `<div class="item" onclick="showPatrol('${it.id}')">
        <div class="item-h">
          <div class="item-t">${it.area || it.barcodeId}</div>
          <span class="badge ${it.kondisi==='Aman'?'b-ok':'b-warn'}">${it.kondisi}</span>
        </div>
        <div class="item-m">${it.petugas} • ${fmt(it.createdAt)}</div>
      </div>`;
    }
    return `<div class="item" onclick="showIncident('${it.id}')">
      <div class="item-h">
        <div class="item-t">${it.jenis}</div>
        <span class="pill p-${it.status.toLowerCase()}">${it.status}</span>
      </div>
      <div class="item-m">${it.petugas} • ${fmt(it.createdAt)}</div>
    </div>`;
  }).join('');
}

/* ========== PATROL ========== */
function renderPatrol(el) {
  const bcs = load(DB.barcodes);
  el.innerHTML = `
    <div class="card">
      <div class="card-h">Patroli Barcode</div>
      <p class="muted" style="margin-bottom:14px">Scan barcode di lokasi. Kamera akan aktif otomatis.</p>
      <button class="btn btn-primary btn-full" onclick="openScanner()">📷 Mulai Scan Barcode</button>
    </div>
    <div class="card">
      <div class="card-h">Atau Pilih Area Manual</div>
      <select id="sel-bc">
        <option value="">-- Pilih Area --</option>
        ${bcs.map(b => `<option value="${b.id}">${b.id} — ${b.area}</option>`).join('')}
      </select>
    </div>
    <div id="patrol-form"></div>`;

  $('#sel-bc').onchange = () => {
    const id = $('#sel-bc').value;
    if (id) onBarcode(id);
  };
}

function openScanner() {
  openModal(`
    <div class="modal-h">
      <h3>Scan Barcode</h3>
      <button class="modal-x" onclick="closeModal()">×</button>
    </div>
    <div id="reader"></div>
    <div class="scan-status" id="scan-st">Mengaktifkan kamera...</div>
    <p class="muted" style="text-align:center;margin-top:6px;font-size:.8rem">Arahkan kamera ke barcode area</p>`);

  setTimeout(() => {
    scanner = new Html5Qrcode('reader');
    scanner.start(
      { facingMode: 'environment' },
      { fps: 10, qrbox: { width: 250, height: 140 }, aspectRatio: 1.333 },
      (code) => {
        stopScanner();
        closeModal();
        onBarcode(code.trim());
      },
      () => {}
    ).then(() => {
      const st = $('#scan-st');
      if (st) st.textContent = 'Kamera aktif • Arahkan ke barcode';
    }).catch(err => {
      const st = $('#scan-st');
      if (st) st.textContent = 'Gagal akses kamera';
      toast('Izinkan akses kamera di browser', 'err');
    });
  }, 250);
}

function onBarcode(code) {
  const list = load(DB.barcodes);
  const bc = list.find(b => b.id.toLowerCase() === code.toLowerCase());
  if (!bc) {
    toast('Barcode tidak dikenali: ' + code, 'err');
    return;
  }
  showPatrolForm(bc);
}

function showPatrolForm(bc) {
  photos = [null, null, null];
  const box = $('#patrol-form');
  if (!box) { go('patrol'); setTimeout(() => showPatrolForm(bc), 80); return; }

  box.innerHTML = `
    <div class="card">
      <div class="card-h">Form Patroli <span class="badge b-info">${bc.id}</span></div>
      <div class="row"><div class="k">Area</div><div class="v">${bc.area}</div></div>
      <div class="row"><div class="k">Lokasi</div><div class="v">${bc.lokasi}</div></div>
      <div class="row"><div class="k">Petugas</div><div class="v">${user.name}</div></div>

      <label class="lbl">Kondisi *</label>
      <div class="radio-row">
        <label class="radio" id="r-aman" onclick="setKondisi('Aman')">
          <input type="radio" name="kondisi" value="Aman" /> ✅ Aman
        </label>
        <label class="radio" id="r-temuan" onclick="setKondisi('Temuan')">
          <input type="radio" name="kondisi" value="Temuan" /> ⚠️ Temuan
        </label>
      </div>

      <div id="box-temuan" style="display:none">
        <label class="lbl">Detail Temuan * (maks 100 kata)</label>
        <textarea id="txt-temuan" maxlength="700" placeholder="Jelaskan temuan secara ringkas..."></textarea>
        <small class="muted" id="wc">0 / 100 kata</small>
      </div>

      <label class="lbl">Dokumentasi Foto * (wajib 3 foto)</label>
      <div class="photos" id="photo-grid">
        ${[0,1,2].map(i => `
          <div class="slot" id="slot-${i}" onclick="pickPhoto(${i})">
            <div class="ico">📷</div><span>Foto ${i+1}</span>
          </div>`).join('')}
      </div>
      <input type="file" id="file-photo" accept="image/*" capture="environment" hidden />

      <div class="actions">
        <button class="btn btn-outline" onclick="$('#patrol-form').innerHTML=''">Batal</button>
        <button class="btn btn-success" onclick="submitPatrol('${bc.id}')">Kirim Laporan</button>
      </div>
    </div>`;

  const ta = $('#txt-temuan');
  if (ta) {
    ta.oninput = () => {
      const n = ta.value.trim().split(/\s+/).filter(Boolean).length;
      const w = $('#wc');
      w.textContent = `${n} / 100 kata`;
      w.style.color = n > 100 ? 'var(--danger)' : 'var(--muted)';
    };
  }
  $('#file-photo').onchange = onPhotoPicked;
}

function setKondisi(v) {
  $$('.radio').forEach(r => r.classList.remove('sel-ok','sel-warn'));
  if (v === 'Aman') {
    $('#r-aman').classList.add('sel-ok');
    $('#r-aman input').checked = true;
    $('#box-temuan').style.display = 'none';
  } else {
    $('#r-temuan').classList.add('sel-warn');
    $('#r-temuan input').checked = true;
    $('#box-temuan').style.display = 'block';
  }
}

function pickPhoto(i) {
  photoTarget = i;
  $('#file-photo').click();
}
function onPhotoPicked(e) {
  const f = e.target.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = ev => {
    photos[photoTarget] = ev.target.result;
    const slot = $(`#slot-${photoTarget}`);
    slot.innerHTML = `<img src="${ev.target.result}" alt="" /><button class="x" onclick="event.stopPropagation();clearPhoto(${photoTarget})">×</button>`;
  };
  r.readAsDataURL(f);
  e.target.value = '';
}
function clearPhoto(i) {
  photos[i] = null;
  const slot = $(`#slot-${i}`);
  slot.innerHTML = `<div class="ico">📷</div><span>Foto ${i+1}</span>`;
  slot.onclick = () => pickPhoto(i);
}

function submitPatrol(bcId) {
  const kond = document.querySelector('input[name="kondisi"]:checked');
  if (!kond) { toast('Pilih kondisi Aman atau Temuan', 'err'); return; }
  const kondisi = kond.value;
  let detail = '';
  if (kondisi === 'Temuan') {
    detail = ($('#txt-temuan')?.value || '').trim();
    if (!detail) { toast('Detail temuan wajib diisi', 'err'); return; }
    if (detail.split(/\s+/).filter(Boolean).length > 100) {
      toast('Detail temuan maksimal 100 kata', 'err'); return;
    }
  }
  const ph = photos.filter(Boolean);
  if (ph.length < 3) { toast('Wajib 3 foto dokumentasi', 'err'); return; }

  const bc = load(DB.barcodes).find(b => b.id === bcId);
  const rec = {
    id: uid('P'),
    barcodeId: bcId,
    area: bc?.area || '',
    lokasi: bc?.lokasi || '',
    petugas: user.name,
    kondisi,
    detailTemuan: detail,
    photos: ph,
    createdAt: nowISO(),
    tanggal: nowText()
  };
  const list = load(DB.patrols);
  list.push(rec);
  save(DB.patrols, list);
  toast('Patroli berhasil dikirim', 'ok');
  $('#patrol-form').innerHTML = '';
  photos = [];
}

/* ========== INCIDENT ========== */
function renderIncident(el) {
  photos = [null, null, null];
  el.innerHTML = `
    <div class="card">
      <div class="card-h">Laporan Harian / Kejadian</div>

      <label class="lbl">Nama Petugas</label>
      <input type="text" value="${user.name}" readonly />

      <label class="lbl">Jenis Kejadian *</label>
      <select id="inc-jenis">
        <option value="">-- Pilih Jenis --</option>
        <option>Kebakaran</option>
        <option>Pencurian / Kehilangan</option>
        <option>Kecelakaan Kerja</option>
        <option>Gangguan Keamanan</option>
        <option>Kerusakan Fasilitas</option>
        <option>Kebocoran (Air/Gas)</option>
        <option>Gangguan Listrik</option>
        <option>Lainnya</option>
      </select>

      <label class="lbl">Kronologis / Detail Kejadian *</label>
      <textarea id="inc-krono" placeholder="Jelaskan kronologi kejadian..."></textarea>

      <label class="lbl">Action Petugas *</label>
      <textarea id="inc-action" placeholder="Tindakan yang sudah dilakukan..."></textarea>

      <label class="lbl">Status Kejadian *</label>
      <select id="inc-status">
        <option value="Open">Open (Baru)</option>
        <option value="Proses">Proses</option>
        <option value="Selesai">Selesai</option>
      </select>

      <label class="lbl">Dokumentasi Foto * (wajib 3 foto)</label>
      <div class="photos">
        ${[0,1,2].map(i => `
          <div class="slot" id="islot-${i}" onclick="pickIncPhoto(${i})">
            <div class="ico">📷</div><span>Foto ${i+1}</span>
          </div>`).join('')}
      </div>
      <input type="file" id="inc-file" accept="image/*" capture="environment" hidden />

      <button class="btn btn-success btn-full" style="margin-top:16px" onclick="submitIncident()">Kirim Laporan Kejadian</button>
    </div>`;
  $('#inc-file').onchange = onIncPhoto;
}

function pickIncPhoto(i) {
  photoTarget = i;
  $('#inc-file').click();
}
function onIncPhoto(e) {
  const f = e.target.files[0];
  if (!f) return;
  const r = new FileReader();
  r.onload = ev => {
    photos[photoTarget] = ev.target.result;
    const slot = $(`#islot-${photoTarget}`);
    slot.innerHTML = `<img src="${ev.target.result}" alt="" /><button class="x" onclick="event.stopPropagation();clearIncPhoto(${photoTarget})">×</button>`;
  };
  r.readAsDataURL(f);
  e.target.value = '';
}
function clearIncPhoto(i) {
  photos[i] = null;
  const slot = $(`#islot-${i}`);
  slot.innerHTML = `<div class="ico">📷</div><span>Foto ${i+1}</span>`;
  slot.onclick = () => pickIncPhoto(i);
}

function submitIncident() {
  const jenis = $('#inc-jenis').value;
  const krono = $('#inc-krono').value.trim();
  const action = $('#inc-action').value.trim();
  const status = $('#inc-status').value;
  if (!jenis) { toast('Jenis kejadian wajib dipilih', 'err'); return; }
  if (!krono) { toast('Kronologis wajib diisi', 'err'); return; }
  if (!action) { toast('Action petugas wajib diisi', 'err'); return; }
  const ph = photos.filter(Boolean);
  if (ph.length < 3) { toast('Wajib 3 foto dokumentasi', 'err'); return; }

  const rec = {
    id: uid('I'),
    petugas: user.name,
    jenis, kronologi: krono, action, status,
    photos: ph,
    createdAt: nowISO(),
    tanggal: nowText(),
    updatedAt: nowISO()
  };
  const list = load(DB.incidents);
  list.push(rec);
  save(DB.incidents, list);
  toast('Laporan kejadian berhasil dikirim', 'ok');
  go('incident');
}

/* ========== BARCODE ADMIN ========== */
function renderBarcodeAdmin(el) {
  const list = load(DB.barcodes);
  el.innerHTML = `
    <div class="card">
      <div class="card-h">
        Manajemen Barcode
        <button class="btn btn-primary btn-sm" onclick="modalAddBarcode()">+ Tambah</button>
      </div>
      <p class="muted" style="margin-bottom:12px">Buat barcode area, lalu print & tempel di lokasi.</p>
      ${list.length ? list.map(b => `
        <div class="item">
          <div class="item-h">
            <div class="item-t">${b.id} — ${b.area}</div>
            <div>
              <button class="btn btn-outline btn-sm" onclick="previewBC('${b.id}')">Lihat</button>
              <button class="btn btn-danger btn-sm" onclick="delBC('${b.id}')">Hapus</button>
            </div>
          </div>
          <div class="item-m">${b.lokasi} • ${fmt(b.createdAt)}</div>
        </div>`).join('') : '<div class="empty"><div class="ico">🏷️</div>Belum ada barcode</div>'}
    </div>`;
}

function modalAddBarcode() {
  openModal(`
    <div class="modal-h"><h3>Tambah Barcode</h3><button class="modal-x" onclick="closeModal()">×</button></div>
    <label class="lbl">Kode Barcode * (unik)</label>
    <input id="nb-id" placeholder="Contoh: BC006" />
    <label class="lbl">Nama Area *</label>
    <input id="nb-area" placeholder="Contoh: Gudang B" />
    <label class="lbl">Lokasi *</label>
    <input id="nb-lok" placeholder="Contoh: Lantai 2 Belakang" />
    <div class="modal-act">
      <button class="btn btn-outline" onclick="closeModal()">Batal</button>
      <button class="btn btn-primary" onclick="addBC()">Simpan</button>
    </div>`);
}

function addBC() {
  const id = ($('#nb-id').value || '').trim().toUpperCase();
  const area = ($('#nb-area').value || '').trim();
  const lokasi = ($('#nb-lok').value || '').trim();
  if (!id || !area || !lokasi) { toast('Semua field wajib', 'err'); return; }
  const list = load(DB.barcodes);
  if (list.some(b => b.id === id)) { toast('Kode sudah ada', 'err'); return; }
  list.push({ id, area, lokasi, createdAt: nowISO() });
  save(DB.barcodes, list);
  closeModal();
  toast('Barcode ditambahkan', 'ok');
  go('barcode');
}

function delBC(id) {
  if (!confirm('Hapus barcode ' + id + '?')) return;
  save(DB.barcodes, load(DB.barcodes).filter(b => b.id !== id));
  toast('Barcode dihapus', 'ok');
  go('barcode');
}

function previewBC(id) {
  const b = load(DB.barcodes).find(x => x.id === id);
  if (!b) return;
  openModal(`
    <div class="modal-h"><h3>Barcode ${b.id}</h3><button class="modal-x" onclick="closeModal()">×</button></div>
    <div class="barcode-box">
      <svg id="bc-svg"></svg>
      <p style="margin-top:10px;font-weight:700">${b.area}</p>
      <p class="muted">${b.lokasi}</p>
      <p style="font-size:.8rem;margin-top:6px">Kode: ${b.id}</p>
    </div>
    <p class="muted" style="text-align:center;font-size:.8rem">Screenshot / print untuk ditempel di lokasi</p>
    <div class="modal-act"><button class="btn btn-primary btn-full" onclick="closeModal()">Tutup</button></div>`);
  setTimeout(() => {
    try {
      JsBarcode('#bc-svg', b.id, { format:'CODE128', width:2, height:78, displayValue:true, fontSize:15, margin:8 });
    } catch {
      $('#bc-svg').outerHTML = '<p style="color:red">Gagal generate</p>';
    }
  }, 80);
}

/* ========== ALL DATA (Admin) ========== */
function renderAllData(el) {
  el.innerHTML = `
    <div class="card">
      <div class="card-h">Semua Laporan</div>
      <div class="filters">
        <select id="f-type" onchange="drawTables()">
          <option value="all">Semua Jenis</option>
          <option value="patrol">Patroli</option>
          <option value="incident">Kejadian</option>
        </select>
        <select id="f-date" onchange="drawTables()">
          <option value="all">Semua Tanggal</option>
          <option value="today">Hari Ini</option>
          <option value="week">7 Hari</option>
        </select>
      </div>
      <div class="actions" style="margin-bottom:12px">
        <button class="btn btn-outline btn-sm" onclick="exportXLS()">📥 Excel</button>
        <button class="btn btn-outline btn-sm" onclick="exportPDF()">📄 PDF</button>
      </div>
      <div id="tables"></div>
    </div>`;
  drawTables();
}

function filtered() {
  const type = $('#f-type')?.value || 'all';
  const dateF = $('#f-date')?.value || 'all';
  let patrols = load(DB.patrols);
  let incidents = load(DB.incidents);
  const now = new Date();
  if (dateF === 'today') {
    const t = now.toDateString();
    patrols = patrols.filter(p => new Date(p.createdAt).toDateString() === t);
    incidents = incidents.filter(i => new Date(i.createdAt).toDateString() === t);
  } else if (dateF === 'week') {
    const w = new Date(now - 7*864e5);
    patrols = patrols.filter(p => new Date(p.createdAt) >= w);
    incidents = incidents.filter(i => new Date(i.createdAt) >= w);
  }
  return { type, patrols: patrols.reverse(), incidents: incidents.reverse() };
}

function drawTables() {
  const { type, patrols, incidents } = filtered();
  let h = '';
  if (type === 'all' || type === 'patrol') {
    h += `<div class="sec">Patroli (${patrols.length})</div>`;
    if (!patrols.length) h += `<div class="empty">Tidak ada data</div>`;
    else h += `<div class="table-wrap"><table>
      <thead><tr><th>Waktu</th><th>Area</th><th>Petugas</th><th>Kondisi</th><th></th></tr></thead>
      <tbody>${patrols.map(p => `
        <tr>
          <td>${fmt(p.createdAt)}</td>
          <td>${p.area}<br><small>${p.barcodeId}</small></td>
          <td>${p.petugas}</td>
          <td><span class="badge ${p.kondisi==='Aman'?'b-ok':'b-warn'}">${p.kondisi}</span></td>
          <td>
            <button class="btn btn-outline btn-sm" onclick="showPatrol('${p.id}')">Detail</button>
            <button class="btn btn-danger btn-sm" onclick="delPatrol('${p.id}')">Hapus</button>
          </td>
        </tr>`).join('')}
      </tbody></table></div>`;
  }
  if (type === 'all' || type === 'incident') {
    h += `<div class="sec">Kejadian (${incidents.length})</div>`;
    if (!incidents.length) h += `<div class="empty">Tidak ada data</div>`;
    else h += `<div class="table-wrap"><table>
      <thead><tr><th>Waktu</th><th>Jenis</th><th>Petugas</th><th>Status</th><th></th></tr></thead>
      <tbody>${incidents.map(i => `
        <tr>
          <td>${fmt(i.createdAt)}</td>
          <td>${i.jenis}</td>
          <td>${i.petugas}</td>
          <td><span class="pill p-${i.status.toLowerCase()}">${i.status}</span></td>
          <td>
            <button class="btn btn-outline btn-sm" onclick="showIncident('${i.id}')">Detail</button>
            <button class="btn btn-primary btn-sm" onclick="editInc('${i.id}')">Edit</button>
            <button class="btn btn-danger btn-sm" onclick="delInc('${i.id}')">Hapus</button>
          </td>
        </tr>`).join('')}
      </tbody></table></div>`;
  }
  $('#tables').innerHTML = h;
}

/* ========== HISTORY (Petugas) ========== */
function renderHistory(el) {
  const name = user.name;
  const patrols = load(DB.patrols).filter(p => p.petugas === name).reverse();
  const incidents = load(DB.incidents).filter(i => i.petugas === name).reverse();
  el.innerHTML = `
    <div class="card">
      <div class="card-h">Riwayat Saya</div>
      <div class="sec">Patroli (${patrols.length})</div>
      ${patrols.length ? patrols.map(p => `
        <div class="item" onclick="showPatrol('${p.id}')">
          <div class="item-h">
            <div class="item-t">${p.area}</div>
            <span class="badge ${p.kondisi==='Aman'?'b-ok':'b-warn'}">${p.kondisi}</span>
          </div>
          <div class="item-m">${fmt(p.createdAt)}</div>
        </div>`).join('') : '<div class="empty">Belum ada patroli</div>'}
      <div class="sec">Laporan Kejadian (${incidents.length})</div>
      ${incidents.length ? incidents.map(i => `
        <div class="item" onclick="showIncident('${i.id}')">
          <div class="item-h">
            <div class="item-t">${i.jenis}</div>
            <span class="pill p-${i.status.toLowerCase()}">${i.status}</span>
          </div>
          <div class="item-m">${fmt(i.createdAt)}</div>
        </div>`).join('') : '<div class="empty">Belum ada laporan</div>'}
    </div>`;
}

/* ========== DETAIL ========== */
function showPatrol(id) {
  const p = load(DB.patrols).find(x => x.id === id);
  if (!p) return;
  openModal(`
    <div class="modal-h"><h3>Detail Patroli</h3><button class="modal-x" onclick="closeModal()">×</button></div>
    <div class="row"><div class="k">ID</div><div class="v">${p.id}</div></div>
    <div class="row"><div class="k">Waktu</div><div class="v">${p.tanggal || fmt(p.createdAt)}</div></div>
    <div class="row"><div class="k">Barcode</div><div class="v">${p.barcodeId}</div></div>
    <div class="row"><div class="k">Area</div><div class="v">${p.area}</div></div>
    <div class="row"><div class="k">Lokasi</div><div class="v">${p.lokasi}</div></div>
    <div class="row"><div class="k">Petugas</div><div class="v">${p.petugas}</div></div>
    <div class="row"><div class="k">Kondisi</div><div class="v"><span class="badge ${p.kondisi==='Aman'?'b-ok':'b-warn'}">${p.kondisi}</span></div></div>
    ${p.detailTemuan ? `<div class="row"><div class="k">Detail Temuan</div><div class="v">${p.detailTemuan}</div></div>` : ''}
    <div class="row"><div class="k">Foto</div><div class="v"><div class="photo-row">${(p.photos||[]).map(ph=>`<img src="${ph}">`).join('')}</div></div></div>
    <div class="modal-act"><button class="btn btn-primary btn-full" onclick="closeModal()">Tutup</button></div>`);
}

function showIncident(id) {
  const i = load(DB.incidents).find(x => x.id === id);
  if (!i) return;
  const isAdmin = user.role === 'admin';
  openModal(`
    <div class="modal-h"><h3>Detail Kejadian</h3><button class="modal-x" onclick="closeModal()">×</button></div>
    <div class="row"><div class="k">ID</div><div class="v">${i.id}</div></div>
    <div class="row"><div class="k">Waktu</div><div class="v">${i.tanggal || fmt(i.createdAt)}</div></div>
    <div class="row"><div class="k">Petugas</div><div class="v">${i.petugas}</div></div>
    <div class="row"><div class="k">Jenis</div><div class="v">${i.jenis}</div></div>
    <div class="row"><div class="k">Kronologis</div><div class="v">${i.kronologi}</div></div>
    <div class="row"><div class="k">Action</div><div class="v">${i.action}</div></div>
    <div class="row"><div class="k">Status</div><div class="v"><span class="pill p-${i.status.toLowerCase()}">${i.status}</span></div></div>
    <div class="row"><div class="k">Foto</div><div class="v"><div class="photo-row">${(i.photos||[]).map(ph=>`<img src="${ph}">`).join('')}</div></div></div>
    <div class="modal-act">
      ${isAdmin ? `<button class="btn btn-primary" onclick="closeModal();editInc('${i.id}')">Edit Status</button>` : ''}
      <button class="btn btn-outline" onclick="closeModal()">Tutup</button>
    </div>`);
}

function editInc(id) {
  const i = load(DB.incidents).find(x => x.id === id);
  if (!i) return;
  openModal(`
    <div class="modal-h"><h3>Edit Kejadian</h3><button class="modal-x" onclick="closeModal()">×</button></div>
    <label class="lbl">Status</label>
    <select id="ed-status">
      <option value="Open" ${i.status==='Open'?'selected':''}>Open</option>
      <option value="Proses" ${i.status==='Proses'?'selected':''}>Proses</option>
      <option value="Selesai" ${i.status==='Selesai'?'selected':''}>Selesai</option>
    </select>
    <label class="lbl">Action Petugas</label>
    <textarea id="ed-action">${i.action}</textarea>
    <div class="modal-act">
      <button class="btn btn-outline" onclick="closeModal()">Batal</button>
      <button class="btn btn-primary" onclick="saveInc('${id}')">Simpan</button>
    </div>`);
}

function saveInc(id) {
  const list = load(DB.incidents);
  const idx = list.findIndex(x => x.id === id);
  if (idx < 0) return;
  list[idx].status = $('#ed-status').value;
  list[idx].action = $('#ed-action').value.trim();
  list[idx].updatedAt = nowISO();
  save(DB.incidents, list);
  closeModal();
  toast('Berhasil diupdate', 'ok');
  if ($('#tables')) drawTables(); else go('data');
}

function delPatrol(id) {
  if (!confirm('Hapus data patroli?')) return;
  save(DB.patrols, load(DB.patrols).filter(p => p.id !== id));
  toast('Dihapus', 'ok');
  drawTables();
}
function delInc(id) {
  if (!confirm('Hapus data kejadian?')) return;
  save(DB.incidents, load(DB.incidents).filter(i => i.id !== id));
  toast('Dihapus', 'ok');
  drawTables();
}

/* ========== EXPORT ========== */
function exportXLS() {
  const { type, patrols, incidents } = filtered();
  const wb = XLSX.utils.book_new();
  if (type === 'all' || type === 'patrol') {
    const rows = patrols.map(p => ({
      ID: p.id, 'Tanggal/Waktu': p.tanggal || fmt(p.createdAt),
      Barcode: p.barcodeId, Area: p.area, Lokasi: p.lokasi,
      Petugas: p.petugas, Kondisi: p.kondisi, 'Detail Temuan': p.detailTemuan || ''
    }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows.length ? rows : [{Info:'Kosong'}]), 'Patroli');
  }
  if (type === 'all' || type === 'incident') {
    const rows = incidents.map(i => ({
      ID: i.id, 'Tanggal/Waktu': i.tanggal || fmt(i.createdAt),
      Petugas: i.petugas, 'Jenis Kejadian': i.jenis,
      Kronologis: i.kronologi, Action: i.action, Status: i.status
    }));
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows.length ? rows : [{Info:'Kosong'}]), 'Kejadian');
  }
  XLSX.writeFile(wb, `MSS_Laporan_${new Date().toISOString().slice(0,10)}.xlsx`);
  toast('Excel diunduh', 'ok');
}

function exportPDF() {
  const { type, patrols, incidents } = filtered();
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  let y = 14;
  doc.setFontSize(15);
  doc.text('Laporan MSS Satpam - PT. Mitracomm', 14, y);
  y += 7;
  doc.setFontSize(9);
  doc.text('Diekspor: ' + new Date().toLocaleString('id-ID'), 14, y);
  y += 8;

  if ((type === 'all' || type === 'patrol') && patrols.length) {
    doc.setFontSize(11);
    doc.text('Data Patroli', 14, y);
    doc.autoTable({
      startY: y + 3,
      head: [['Waktu','Area','Petugas','Kondisi','Detail']],
      body: patrols.map(p => [
        fmt(p.createdAt), p.area + ' (' + p.barcodeId + ')',
        p.petugas, p.kondisi, (p.detailTemuan || '-').slice(0,40)
      ]),
      styles: { fontSize: 7.5 },
      margin: { left: 14 }
    });
    y = doc.lastAutoTable.finalY + 10;
  }
  if ((type === 'all' || type === 'incident') && incidents.length) {
    if (y > 250) { doc.addPage(); y = 14; }
    doc.setFontSize(11);
    doc.text('Data Kejadian', 14, y);
    doc.autoTable({
      startY: y + 3,
      head: [['Waktu','Jenis','Petugas','Status']],
      body: incidents.map(i => [fmt(i.createdAt), i.jenis, i.petugas, i.status]),
      styles: { fontSize: 7.5 },
      margin: { left: 14 }
    });
  }
  doc.save(`MSS_Laporan_${new Date().toISOString().slice(0,10)}.pdf`);
  toast('PDF diunduh', 'ok');
}
