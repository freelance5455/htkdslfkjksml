const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const pages={dashboard:"Dashboard",html:"HTML Studio",apk:"APK Builder",website:"Website Studio",store:"App Store",hosting:"Hosting Panel",ai:"AI Assistant",projects:"My Projects",profile:"Profile & Settings"};
let projects=[{name:"PREDX Music",type:"Mobile App",status:"In progress",icon:"♫"},{name:"PREDX Store",type:"Website",status:"Ready",icon:"◎"},{name:"AI Agent",type:"Web App",status:"In progress",icon:"✧"},{name:"Pixel Pro",type:"Creative App",status:"Draft",icon:"✦"}];
function toast(msg){let t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>t.classList.remove("show"),2400)}
function go(page){$$(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+page));$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("#pageName").textContent=pages[page]||"Dashboard";$(".sidebar").classList.remove("open");window.scrollTo(0,0)}
$$("[data-page]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.page)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("#menuBtn").addEventListener("click",()=>$(".sidebar").classList.toggle("open"));
function renderProjects(){let html=projects.map(p=>`<div class="project-row"><div class="project-symbol">${p.icon}</div><div class="project-info"><b>${p.name}</b><small>${p.type} · Updated recently</small></div><span class="project-tag">${p.status}</span></div>`).join("");$("#recentProjects").innerHTML=html;$("#allProjects").innerHTML=html;$("#projectCount").textContent=String(projects.length).padStart(2,"0")}
renderProjects();
const starter=`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PREDX App</title>
  <style>
    body { font-family: Arial, sans-serif; background: #07110b; color: white;
      display: grid; place-items: center; min-height: 90vh; text-align: center; }
    h1 { color: #39ff14; }
    .card { padding: 36px; border: 1px solid #39ff14; border-radius: 18px; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Hello, PREDX!</h1>
    <p>Your new website starts here.</p>
    <button onclick="alert('Welcome!')">Get Started</button>
  </div>
</body>
</html>`;
$("#codeEditor").value=starter;
function updateLines(){let n=$("#codeEditor").value.split("\n").length;$("#lineCount").textContent=n+" lines"}
function runPreview(){let code=$("#codeEditor").value;$("#previewFrame").srcdoc=code;updateLines();toast("Preview updated")}
$("#runCode").addEventListener("click",runPreview);$("#codeEditor").addEventListener("input",updateLines);$("#resetCode").addEventListener("click",()=>{if(confirm("Reset the editor to starter code?")){$("#codeEditor").value=starter;runPreview()}});runPreview();
let selectedZip=null;
$("#zipInput").addEventListener("change",e=>{selectedZip=e.target.files[0]||null;$("#fileName").textContent=selectedZip?selectedZip.name+" · "+(selectedZip.size/1024/1024).toFixed(2)+" MB":"No file selected";$("#buildStatus").textContent=selectedZip?"ZIP selected. Complete the app details, then prepare the build workflow.":"Select a ZIP to begin."});
$("#dropzone").addEventListener("dragover",e=>{e.preventDefault();$("#dropzone").style.borderColor="#39ff14"});$("#dropzone").addEventListener("dragleave",()=>$("#dropzone").style.borderColor="#2d8e46");$("#dropzone").addEventListener("drop",e=>{e.preventDefault();let f=e.dataTransfer.files[0];if(f&&f.name.toLowerCase().endsWith(".zip")){$("#zipInput").files=e.dataTransfer.files;selectedZip=f;$("#fileName").textContent=f.name;$("#buildStatus").textContent="ZIP selected. Complete the app details, then prepare the build workflow."}else toast("Please choose a .zip archive")});
$("#buildBtn").addEventListener("click",()=>{if(!selectedZip){toast("Please select a ZIP archive first");return}let name=$("#appName").value.trim(),pkg=$("#packageId").value.trim();if(!name||!pkg){toast("Enter app name and package ID");return}$("#buildStatus").textContent=`Ready for backend handoff: ${name} (${pkg}). No APK has been compiled in this browser demo.`;toast("Project details validated")});
$("#editSite").addEventListener("click",()=>go("html"));$("#publishSite").addEventListener("click",()=>{$("#siteNotice").textContent="To publish publicly, connect a hosting provider or deployment API.";toast("Hosting connection required")});$("#copySite").addEventListener("click",()=>{let value="Local PREDX Website Studio preview";navigator.clipboard?.writeText(value).then(()=>toast("Preview label copied")).catch(()=>toast(value))});$("#newWebsite").addEventListener("click",()=>{let name=prompt("Enter your website project name:");if(name){projects.unshift({name,type:"Website",status:"Draft",icon:"◎"});renderProjects();toast("Website project added")}});$("#createProject").addEventListener("click",()=>{let name=prompt("Enter a project name:");if(name){projects.unshift({name,type:"New Project",status:"Draft",icon:"✦"});renderProjects();toast("Project created")}});$("#hostingNotice").textContent="No hosting provider is connected yet.";$$("[data-host]").forEach(b=>b.addEventListener("click",()=>{$("#hostingNotice").textContent=b.dataset.host+" requires a connected hosting provider.";toast("External service connection required")}));
$("#storeSearch").addEventListener("input",filterStore);let currentFilter="All";$$(".filter").forEach(b=>b.addEventListener("click",()=>{currentFilter=b.dataset.filter;$$(".filter").forEach(x=>x.classList.toggle("active",x===b));filterStore()}));function filterStore(){let q=$("#storeSearch").value.toLowerCase();$$(".store-card").forEach(c=>c.style.display=(currentFilter==="All"||c.dataset.category===currentFilter)&&c.textContent.toLowerCase().includes(q)?"flex":"none")}
$$(".install-btn").forEach(b=>b.addEventListener("click",()=>toast("This is a demo store listing — app download is not connected.")));
function addMessage(text,who){let el=document.createElement("div");el.className="message "+who;el.textContent=text;$("#chatMessages").appendChild(el);$("#chatMessages").scrollTop=$("#chatMessages").scrollHeight}
function sendChat(text){if(!text.trim())return;addMessage(text,"user");let answer="This interface is running in demo mode. Connect your preferred AI API through a secure backend to receive live answers. I can still help you plan the steps: define the goal, list the features, design the screens, then implement and test each part.";setTimeout(()=>addMessage(answer,"bot"),250)}
$("#chatForm").addEventListener("submit",e=>{e.preventDefault();sendChat($("#chatInput").value);$("#chatInput").value=""});$$(".suggestions button").forEach(b=>b.addEventListener("click",()=>sendChat(b.textContent)));$("#clearChat").addEventListener("click",()=>{$("#chatMessages").innerHTML="";addMessage("Chat cleared. What would you like to build next?","bot")});
