/*
  Bubble Clicker
  Real-time leaderboard: Supabase Realtime + Postgres.
  Put your Supabase URL and anon key below.
*/
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY";

const hasBackend = !SUPABASE_URL.startsWith("PASTE_") && !SUPABASE_ANON_KEY.startsWith("PASTE_");
const client = hasBackend ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const $ = id => document.getElementById(id);
const state = {
  // Никнейм является одновременно уникальным ID игрока.
  id: localStorage.getItem("bubble_player_id") || "",
  name: localStorage.getItem("bubble_player_name") || "",
  score: 0,
  leaders: []
};

$("playerNameLabel").textContent = state.name || "Bubble Player";
$("settingsName").value = state.name || "Bubble Player";

function format(n){ return Number(n||0).toLocaleString("ru-RU"); }
function toast(text, ms=2200){
  $("toast").textContent = text; $("toast").classList.add("show");
  setTimeout(()=>$("toast").classList.remove("show"),ms);
}
function setScore(n){ state.score = Math.max(0, Number(n)||0); $("score").textContent = format(state.score); }

async function ensurePlayer(){
  if(!state.name){
    $("nameDialog").showModal();
    return false;
  }
  if(!client){ $("connectionText").textContent = "Демо"; return true; }
  const { error } = await client.from("players").upsert(
    { id: state.id, name: state.name, score: state.score, updated_at: new Date().toISOString() },
    { onConflict: "id" }
  );
  if(error) { console.error(error); $("connectionText").textContent = "Офлайн"; }
  return true;
}

$("nameForm").addEventListener("submit", async e=>{
  e.preventDefault();
  const name = $("nameInput").value.trim();
  if(name.length < 3 || name.length > 10){
    toast("Ник должен быть от 3 до 10 символов");
    return;
  }
  state.name=name;
  state.id=name;
  localStorage.setItem("bubble_player_name",name);
  localStorage.setItem("bubble_player_id",name);
  $("playerNameLabel").textContent=name; $("settingsName").value=name;
  $("nameDialog").close();
  await ensurePlayer();
  loadLeaderboard();
});

async function clickBubble(){
  if(!state.name){ $("nameDialog").showModal(); return; }

  // Exactly 1% reset probability: integer 0..99 equals 0.
  const reset = crypto.getRandomValues(new Uint32Array(1))[0] % 100 === 0;

  if(reset){
    setScore(0);
    $("bubble").classList.add("bump"); setTimeout(()=>$("bubble").classList.remove("bump"),140);
    toast("💥 Сброс! 1% сработал — снова 0");
  }else{
    setScore(state.score + 1);
  }

  if(client){
    const { error } = await client.from("players")
      .update({ score: state.score, name: state.name, updated_at: new Date().toISOString() })
      .eq("id", state.id);
    if(error) console.error(error);
  }
}
$("bubble").addEventListener("pointerdown", e=>{ e.preventDefault(); clickBubble(); });

async function loadLeaderboard(){
  if(!client){
    const demo = [
      ["Bubble Master", 12843],["Blue Whale", 9820],["No Sleep", 7311],["Lucky One", 6250],["Bubble King", 4902]
    ];
    state.leaders = demo.map((x,i)=>({id:"demo"+i,name:x[0],score:x[1]}));
    renderLeaderboard(); return;
  }
  const { data, error } = await client.from("players")
    .select("id,name,score,updated_at")
    .order("score",{ascending:false})
    .limit(100);
  if(error){ console.error(error); $("connectionText").textContent="Офлайн"; return; }
  $("connectionText").textContent="Онлайн";
  state.leaders=data||[];
  renderLeaderboard();
}
function renderLeaderboard(){
  const box=$("leaderboard");
  if(!state.leaders.length){ box.innerHTML='<div class="leader"><span>—</span><span>Пока никого нет</span><b>0</b></div>'; return; }
  box.innerHTML=state.leaders.map((p,i)=>{
    const medal=i===0?"🥇":i===1?"🥈":i===2?"🥉":`<span class="place">${i+1}</span>`;
    return `<div class="leader ${p.id===state.id?'me':''}">
      <span class="medal">${medal}</span>
      <span class="lname">${escapeHtml(p.name)}${p.id===state.id?' <small>(ты)</small>':''}</span>
      <span class="lscore">${format(p.score)}</span>
    </div>`;
  }).join("");
  const meIndex=state.leaders.findIndex(p=>p.id===state.id);
  $("rankBadge").textContent=meIndex>=0?`#${meIndex+1}`:"#—";
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

function subscribeRealtime(){
  if(!client) return;
  client.channel("players-live")
    .on("postgres_changes",{event:"*",schema:"public",table:"players"},()=>loadLeaderboard())
    .subscribe();
}

function openPanel(name){
  document.querySelectorAll(".panel").forEach(p=>p.classList.add("hidden"));
  const p=$(name+"Panel"); if(p) p.classList.remove("hidden");
  if(name==="top") loadLeaderboard();
}
document.querySelectorAll(".nav-btn").forEach(btn=>{
  btn.addEventListener("click",()=>openPanel(btn.dataset.panel));
});
document.querySelectorAll(".close-panel").forEach(b=>b.addEventListener("click",()=>b.closest(".panel").classList.add("hidden")));
$("backFromTop").addEventListener("click",()=>$("topPanel").classList.add("hidden"));

$("saveName").addEventListener("click", async ()=>{
  const name=$("settingsName").value.trim().slice(0,18);
  if(!name) return;
  state.name=name; localStorage.setItem("bubble_player_name",name);
  $("playerNameLabel").textContent=name;
  await ensurePlayer(); toast("Имя сохранено");
});

(async function init(){
  if(state.name && state.name.length >= 3 && state.name.length <= 10){
    state.id = state.name;
    localStorage.setItem("bubble_player_id", state.id);
    $("playerNameLabel").textContent = state.name;
    $("settingsName").value = state.name;
    await ensurePlayer();
    loadLeaderboard();
    subscribeRealtime();
  } else {
    $("nameDialog").showModal();
  }
})();
