/*
  UNNATI – Rural Women Skill Development
  APK-friendly offline prototype.
  No external libraries/CDNs are required.
  Demo data is stored in localStorage. For production, connect a secure backend,
  real AI/NLP services, verified government APIs, maps and payment/order systems.
*/
(() => {
  'use strict';

  const app = document.getElementById('app');
  const USER_KEY = 'unnati_user_v2';
  const ASSESS_KEY = 'unnati_assessment_v2';
  const LISTING_KEY = 'unnati_listings_v2';

  const DATA = {
    skills: ['Tailoring','Agriculture','Computer / IT','Food Processing','Handicrafts','Beauty & Wellness','Dairy / Poultry','Digital Service Centre'],
    goals: ['Job / Career','Start a Business','Learn a Skill','Sell Products','Digital Services','Improve Existing Business'],
    businesses: [
      ['🧵','Tailoring','Blouse, dress, school uniform, alteration and stitching services.'],
      ['🍱','Food Processing','Pickles, papad, spices, snacks, packaging and local food products.'],
      ['🧺','Handicrafts','Baskets, decor, handmade utility products and local craft items.'],
      ['💄','Beauty & Wellness','Beauty, mehendi, wellness and home-service opportunities.'],
      ['🐄','Dairy / Poultry','Milk, poultry, eggs and allied rural enterprise options.'],
      ['🌾','Agriculture','Nursery, farm products and value-added agriculture opportunities.'],
      ['💻','Digital Service Centre','Online forms, documentation, digital payments and local digital support.']
    ],
    schemes: [
      ['DAY-NRLM','Rural livelihoods / SHG support','Explore eligible livelihood, training and group-enterprise pathways.'],
      ['PMEGP','Micro-enterprise pathway','Explore entrepreneurship-oriented support for eligible new micro enterprises.'],
      ['PMFME','Food-processing pathway','Explore eligible food-processing and value-addition support.']
    ],
    trainings: [
      ['Tailoring Basics','Measurements, cutting, stitching, finishing and customer orders.','🧵'],
      ['Digital Skills','Smartphone, online forms, email, digital services and safety.','💻'],
      ['Food Processing','Hygiene, basic processing, packaging, pricing and records.','🍱'],
      ['Handicraft Business','Product design, costing, cataloguing and selling.','🧺'],
      ['Beauty & Wellness','Basic service workflow, hygiene and customer care.','💄'],
      ['Agriculture Enterprise','Local opportunity, value addition, records and market basics.','🌾']
    ],
    villageSkills: [
      ['🧵','Tailoring',12],['🌾','Agriculture',18],['💻','Computer / IT',8],['🍱','Food Processing',10],['🧺','Handicrafts',15],['💄','Beauty & Wellness',9]
    ]
  };

  const state = { route: 'home', auth: 'login', toast: '' };

  function read(key, fallback = null) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
  }
  function write(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
  function user() { return read(USER_KEY, null); }
  function assessment() { return read(ASSESS_KEY, null); }
  function listings() { return read(LISTING_KEY, []); }
  function esc(value = '') {
    return String(value).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  }
  function firstName(name='') { return esc(name.trim().split(/\s+/)[0] || 'मित्र'); }
  function updateUser(patch) { const u = user(); if (!u) return; write(USER_KEY, {...u, ...patch}); }
  function toast(message) {
    state.toast = message; renderToast();
    clearTimeout(window.__unnatiToast); window.__unnatiToast = setTimeout(() => { state.toast=''; renderToast(); }, 2600);
  }
  function renderToast() {
    document.querySelector('.toast')?.remove();
    if (!state.toast) return;
    const el = document.createElement('div'); el.className='toast'; el.textContent=state.toast; document.body.appendChild(el);
  }
  function go(route) { state.route=route; window.scrollTo({top:0,behavior:'smooth'}); render(); }
  function logout() { localStorage.removeItem(USER_KEY); localStorage.removeItem(ASSESS_KEY); state.route='home'; toast('तुम्ही सुरक्षितपणे Logout केले.'); render(); }
  function resetDemo() { localStorage.removeItem(USER_KEY); localStorage.removeItem(ASSESS_KEY); localStorage.removeItem(LISTING_KEY); state.route='home'; state.auth='register'; render(); toast('Demo data reset झाला.'); }

  function topbar() {
    const u=user();
    return `<header class="topbar">
      <button class="brand" data-route="${u?'dashboard':'home'}"><img class="mini-logo" src="assets/unnati-logo.svg" alt="उन्नती logo"><span>उन्नती</span></button>
      <div class="top-actions">
        ${u ? '<button class="iconbtn" data-action="voice" aria-label="Voice assistant">🎙️</button><button class="iconbtn" data-route="profile" aria-label="Profile">👤</button>' : ''}
      </div>
    </header>`;
  }
  function nav() {
    if (!user()) return '';
    const items=[['dashboard','🏠','Home'],['assessment','🧠','AI Test'],['training','📚','Training'],['market','🛍️','Market'],['schemes','🏛️','Schemes'],['profile','👩‍🌾','Profile']];
    return `<nav class="bottomnav"><div class="nav-inner">${items.map(([r,i,l])=>`<button class="nav-item ${state.route===r?'active':''}" data-route="${r}"><span>${i}</span>${l}</button>`).join('')}</div></nav>`;
  }
  function layout(content) { return `<div class="app">${topbar()}<main class="page">${content}</main>${nav()}${user()?'<button class="assistant" data-action="voice" aria-label="Voice assistant">🎙️</button>':''}</div>`; }

  function authPage() {
    const login = state.auth==='login';
    return `<div class="auth"><section class="auth-card">
      <div class="brand-big"><div class="logo"><img src="assets/unnati-logo.svg" alt="उन्नती"></div><h1>उन्नती</h1><p class="subtitle">ग्रामीण महिलांसाठी Skill • Career • Business • Market • Scheme एकाच ठिकाणी</p></div>
      <div class="tabs"><button class="tab ${login?'active':''}" data-auth="login">Login</button><button class="tab ${!login?'active':''}" data-auth="register">Create Account</button></div>
      ${login ? loginForm() : registerForm()}
      <p class="footer-note">APK-friendly offline prototype • पुढे secure backend / AI / APIs जोडता येतील.</p>
    </section></div>`;
  }
  function loginForm() {
    return `<form class="form" id="loginForm">
      <div class="field"><label for="loginId">Mobile / Email</label><input id="loginId" required placeholder="Mobile किंवा Email" autocomplete="username"></div>
      <div class="field"><label for="loginPass">Password</label><input id="loginPass" type="password" required placeholder="Password" autocomplete="current-password"></div>
      <button class="btn btn-primary">Login to Unnati</button>
      <div class="notice">🔐 Create Account केल्यानंतरच Login करता येईल. Demo मध्ये credentials या device वर localStorage मध्ये ठेवले जातात.</div>
    </form>`;
  }
  function registerForm() {
    return `<form class="form" id="registerForm">
      <div class="two"><div class="field"><label for="rName">Full Name</label><input id="rName" required placeholder="तुमचे नाव"></div><div class="field"><label for="rMobile">Mobile</label><input id="rMobile" inputmode="numeric" pattern="[0-9]{10}" maxlength="10" required placeholder="10 digit mobile"></div></div>
      <div class="two"><div class="field"><label for="rEmail">Email</label><input id="rEmail" type="email" required placeholder="name@email.com"></div><div class="field"><label for="rVillage">Village</label><input id="rVillage" required placeholder="गाव"></div></div>
      <div class="two"><div class="field"><label for="rDistrict">District</label><input id="rDistrict" required placeholder="जिल्हा"></div><div class="field"><label for="rEducation">Education</label><select id="rEducation"><option>School</option><option>12th</option><option>Graduate</option><option>Post Graduate</option><option>Other</option></select></div></div>
      <div class="two"><div class="field"><label for="rSkill">Current Skill</label><select id="rSkill">${DATA.skills.map(s=>`<option>${s}</option>`).join('')}</select></div><div class="field"><label for="rGoal">Goal / Preference</label><select id="rGoal">${DATA.goals.map(s=>`<option>${s}</option>`).join('')}</select></div></div>
      <div class="field"><label for="rPass">Password</label><input id="rPass" type="password" minlength="6" required placeholder="किमान 6 characters"></div>
      <label class="small"><input id="rConsent" type="checkbox" required> माझी माहिती demo profile साठी वापरण्यास मी सहमत आहे.</label>
      <button class="btn btn-primary">Create Account</button>
      <div class="notice">🛡️ Digital Safety: हा prototype आहे. Production मध्ये password hashing, secure authentication, HTTPS, access control आणि privacy controls आवश्यक आहेत.</div>
    </form>`;
  }

  function home() {
    return `<div class="auth"><section class="auth-card">
      <div class="brand-big"><div class="logo"><img src="assets/unnati-logo.svg" alt="उन्नती"></div><h1>उन्नती</h1><p class="subtitle">ग्रामीण महिला कौशल्य विकास</p></div>
      <div class="hero" style="padding:20px;margin-bottom:18px"><span class="pill">🤖 AI • Local Language • Opportunity Access</span><h1 style="font-size:26px">तुमच्या कौशल्याला योग्य संधीशी जोडा.</h1><p>Scattered skills, careers, training, business ideas, schemes आणि market access एका connected platform मध्ये आणण्याची संकल्पना.</p></div>
      <div class="grid g2" style="margin-bottom:18px"><div class="card feature"><span class="ico">🧠</span><span><h3>AI Skill Assessment</h3><p>Skill level, strengths आणि skill gaps समजून घेण्यासाठी.</p></span></div><div class="card feature"><span class="ico">🛍️</span><span><h3>Digital Marketplace</h3><p>Product/service, customers, orders आणि income visibility.</p></span></div><div class="card feature"><span class="ico">🏛️</span><span><h3>Scheme Discovery</h3><p>DAY-NRLM, PMEGP, PMFME सारख्या pathways.</p></span></div><div class="card feature"><span class="ico">🗺️</span><span><h3>Village Skill Mapping</h3><p>स्थानिक skill groups आणि smart-village concept.</p></span></div></div>
      ${authPage().match(/<div class="tabs">[\s\S]*?<\/form>/)?.[0] || ''}
    </section></div>`;
  }

  function dashboard() {
    const u=user(), a=assessment();
    return layout(`<div class="hero"><span class="pill">🌱 नमस्कार, ${firstName(u.name)}</span><h1>तुमच्या कौशल्यातून पुढची संधी.</h1><p>उन्नती digital profile, AI assessment, training, business pathways, government scheme discovery, marketplace आणि village skill mapping यांना एकत्र जोडते.</p><div class="hero-actions"><button class="btn btn-light" data-route="assessment">🧠 AI Skill Assessment</button><button class="btn btn-light" data-route="business">💼 Business Match</button><button class="btn btn-light" data-route="market">🛍️ Marketplace</button><button class="btn btn-light" data-route="schemes">🏛️ Schemes</button></div></div>
      <section class="section grid g4"><div class="stat"><b>${esc(u.skill)}</b><span>Current skill</span></div><div class="stat"><b>${a?a.score+'%':'—'}</b><span>AI profile score</span></div><div class="stat"><b>${Object.keys(u.progress||{}).length}</b><span>Training started</span></div><div class="stat"><b>${(u.orders||[]).length}</b><span>Orders / requests</span></div></section>
      <section class="section"><div class="section-head"><div><h2>AI Connects the Dots</h2><p>Skills scattered असतील तरी एकाच platform वर पुढचा मार्ग.</p></div></div><div class="grid g3">
        ${[['🧠','AI Skill Assessment','Current skill, level, strengths आणि skill gaps.','assessment'],['🤖','AI Analysis','Assessment वरून personalized pathway आणि next action.','assessment'],['💼','Career / Business Match','Skill + goal + local opportunity match.','business'],['🎓','Personalized Training','Training recommendation आणि progress tracking.','training'],['🏛️','Government Scheme Match','Relevant scheme categories आणि checklist flow.','schemes'],['📈','Market Demand Analysis','Product → customer → local demand signals.','market'],['🛍️','Digital Marketplace','Seller profile, product/service, orders, income.','market'],['🗺️','Village Skill Mapping','Tailoring, agriculture, IT, food, handicraft इ. visibility.','village'],['🏘️','Smart Village Concept','Local skill groups, community dashboard आणि impact.','impact']].map(([i,t,d,r])=>`<button class="card feature" data-route="${r}"><span class="ico">${i}</span><span><h3>${t}</h3><p>${d}</p></span></button>`).join('')}
      </div></section>
      <section class="section grid g2"><div class="card"><div class="section-head"><div><h2>🗺️ Village Skill Mapping</h2><p>Demo community skill visibility.</p></div><button class="btn btn-soft" data-route="village">Open</button></div>${villageList()}</div><div class="card"><div class="section-head"><div><h2>📊 Community Insights</h2><p>Smart village dashboard concept.</p></div></div>${chart()}</div></section>
      <section class="section card"><h3>🔐 Digital Safety & Privacy</h3><div class="grid g3"><div class="check"><b>✓</b><span><strong>Consent-first</strong><br><small class="muted">User consent आणि purpose clarity.</small></span></div><div class="check"><b>✓</b><span><strong>Secure production plan</strong><br><small class="muted">HTTPS, hashed passwords, RBAC.</small></span></div><div class="check"><b>✓</b><span><strong>Verified integrations</strong><br><small class="muted">Official APIs / verified services.</small></span></div></div></section>`);
  }
  function villageList(){ return `<div class="list">${DATA.villageSkills.map(([i,n,c])=>`<div class="list-row"><span>${i} ${n}</span><span class="tag">${c} demo profiles</span></div>`).join('')}</div>`; }
  function chart(){ const vals=[45,65,80,55,72,90,62], labels=['T','A','IT','F','H','D','B']; return `<div class="chart">${vals.map((v,i)=>`<div class="bar" style="height:${v}%"><span>${labels[i]}</span></div>`).join('')}</div>`; }

  function assessmentPage(){
    const a=assessment();
    return layout(`<div class="section-head"><div><h2>🧠 AI Skill Assessment</h2><p>Current skill • skill level • strengths • skill gaps</p></div><span class="tag">Demo AI engine</span></div>
      <div class="grid g2"><div class="card"><form class="form" id="assessmentForm"><div class="field"><label for="aSkill">Current / preferred skill</label><select id="aSkill">${DATA.skills.map(s=>`<option ${user().skill===s?'selected':''}>${s}</option>`).join('')}</select></div><div class="field"><label for="aLevel">Current level</label><select id="aLevel"><option>Beginner</option><option>Basic</option><option>Intermediate</option><option>Advanced</option></select></div><div class="field"><label for="aStrength">What are your strengths?</label><select id="aStrength"><option>Creativity</option><option>Communication</option><option>Hand skills</option><option>Digital interest</option><option>Planning</option></select></div><div class="field"><label for="aGoal">Main goal</label><select id="aGoal">${DATA.goals.map(g=>`<option>${g}</option>`).join('')}</select></div><button class="btn btn-primary">Run AI Analysis</button></form></div>${a?assessmentResult(a):`<div class="card"><div class="bigico">🤖</div><h3>AI Analysis</h3><p class="muted">Assessment submit केल्यावर score, strengths, skill gaps आणि recommended pathway येथे दिसेल.</p><div class="notice">हे offline demo rule-engine आहे. Real AI जोडण्यासाठी backend/API आवश्यक आहे.</div></div>`}</div>`);
  }
  function assessmentResult(a){ return `<div class="card"><div class="section-head"><div><h3>AI Analysis Result</h3><p>${esc(a.skill)} • ${esc(a.level)}</p></div><div class="score">${a.score}%</div></div><div class="progress"><i style="width:${a.score}%"></i></div><h4>Strengths</h4><div>${a.strengths.map(x=>`<span class="tag">✓ ${esc(x)}</span>`).join('')}</div><h4>Skill Gaps</h4><div>${a.gaps.map(x=>`<span class="tag">→ ${esc(x)}</span>`).join('')}</div><div class="notice success" style="margin-top:12px"><b>Recommended pathway:</b> ${esc(a.recommendation)}</div><button class="btn btn-soft" data-route="training" style="margin-top:12px">Start Personalized Training</button></div>`; }

  function businessPage(){ return layout(`<div class="section-head"><div><h2>💼 AI Business / Career Recommendation</h2><p>Skill + goal + local opportunity + market demand यांचा match.</p></div></div><div class="grid g2">${DATA.businesses.map((b,i)=>`<article class="card feature"><span class="ico">${b[0]}</span><span><h3>${b[1]}</h3><p>${b[2]}</p><div><span class="tag">AI Match ${86-i*5}%</span><span class="tag">Local opportunity</span></div><button class="btn btn-soft" data-pathway="${esc(b[1])}" style="margin-top:9px">Explore Pathway</button></span></article>`).join('')}</div><section class="section card"><h3>🤖 AI Architecture</h3><div class="timeline"><div class="step"><span class="step-num">1</span><div><h4>Input Data</h4><p>Profile, education, skill, goal, village context आणि product interest.</p></div></div><div class="step"><span class="step-num">2</span><div><h4>AI Engine</h4><p>Recommendation + NLP + market signals + skill-gap logic.</p></div></div><div class="step"><span class="step-num">3</span><div><h4>User Services</h4><p>Training, schemes, marketplace, local access आणि support.</p></div></div></div></section>`); }

  function schemesPage(){ return layout(`<div class="section-head"><div><h2>🏛️ Government Scheme Match</h2><p>DAY-NRLM • PMEGP • PMFME</p></div></div><div class="grid g3">${DATA.schemes.map(s=>`<article class="card"><div class="bigico">🏛️</div><h3>${s[0]}</h3><p class="muted">${s[1]}</p><p>${s[2]}</p><button class="btn btn-soft" data-scheme="${s[0]}">Check Match</button></article>`).join('')}</div><section class="section card"><h3>Scheme Match Flow</h3><div class="timeline">${['Digital profile तयार करा','Skill + goal analysis','Relevant scheme category match','Documents / eligibility checklist','Official source / verified integration कडे पुढे जा'].map((x,i)=>`<div class="step"><span class="step-num">${i+1}</span><div><h4>${x}</h4><p>उन्नती demo मध्ये पुढील step साठी guidance.</p></div></div>`).join('')}</div><div class="notice" style="margin-top:13px">महत्त्वाचे: eligibility, benefit amount आणि application rules अधिकृत सरकारी स्रोतावरच अंतिम तपासा.</div></section>`); }

  function trainingPage(){ const u=user(); return layout(`<div class="section-head"><div><h2>📚 Personalized Training</h2><p>Recommendation → lesson → progress → next match improvement</p></div></div><div class="grid g3">${DATA.trainings.map(t=>{const p=(u.progress||{})[t[0]]||0;return `<article class="card"><div class="bigico">${t[2]}</div><h3>${t[0]}</h3><p class="muted">${t[1]}</p><div class="progress"><i style="width:${p}%"></i></div><p class="small">Progress: ${p}%</p><button class="btn btn-primary" data-training="${esc(t[0])}">${p?'Continue':'Start Training'}</button></article>`}).join('')}</div><section class="section card"><h3>🎯 Personalization Logic</h3><p class="muted">AI assessment result → recommended skill pathway → lessons → progress tracking → improved next recommendation.</p></section>`); }

  function marketPage(){ const ls=listings(); return layout(`<div class="section-head"><div><h2>🛍️ Digital Marketplace</h2><p>Seller profile • product/service • AI description • customers • orders • income</p></div><button class="btn btn-primary" data-action="addListing">+ Add Product</button></div><div class="grid g3">${defaultProducts().concat(ls).map(p=>`<article class="card"><div class="bigico">${p.icon}</div><h3>${esc(p.name)}</h3><p class="muted">${esc(p.category)} • Local seller</p><div class="list-row"><b>${esc(p.price||'Price on request')}</b><span class="tag">AI description</span></div><p class="small muted">${esc(p.description||'Local-language friendly listing description.')}</p><button class="btn btn-soft" data-order="${esc(p.name)}" data-price="${esc(p.price||'On request')}">Request / Order</button></article>`).join('')}</div><section class="section grid g2"><div class="card"><h3>📣 Digital Visibility</h3><p class="muted">Seller profile, product cards, service availability आणि future verified integrations.</p><span class="tag">Local language</span><span class="tag">Verified integration planned</span></div><div class="card"><h3>📈 AI Market Demand Analysis</h3><p class="muted">Product → customer → local demand signals → suggested pricing and promotion.</p><div class="notice success">Demo signal: locally made, clearly priced products can be highlighted for local discovery.</div></div></section>`); }
  function defaultProducts(){return [['🧵','Handmade Blouse','₹650','Tailoring'],['🍱','Homemade Masala Pack','₹180','Food Processing'],['🧺','Handmade Basket','₹420','Handicrafts'],['🌿','Farm Fresh Pack','₹300','Agriculture'],['💻','Digital Form Service','₹50','Digital Service Centre'],['💄','Home Beauty Service','₹350','Beauty & Wellness']].map(x=>({icon:x[0],name:x[1],price:x[2],category:x[3]}));}

  function villagePage(){ return layout(`<div class="section-head"><div><h2>🗺️ Village Skill Mapping</h2><p>Tailoring • Agriculture • Computer/IT • Food Processing • Handicrafts • Beauty</p></div></div><div class="grid g2"><div class="card"><div class="map"><div class="map-title">📍 Demo Village Opportunity Map</div><div class="pin a"><i></i><b>Tailoring Group</b></div><div class="pin b"><i></i><b>Agriculture</b></div><div class="pin c"><i></i><b>Food Processing</b></div><div class="pin d"><i></i><b>Digital Services</b></div></div></div><div class="card"><h3>Available Skills</h3>${villageList()}<div class="notice" style="margin-top:12px">Future scope: GPS/geographical maps आणि verified community data जोडता येईल.</div></div></div><section class="section card"><h3>🏘️ Smart Village Concept</h3><p class="muted">उदाहरण: Rural BCS group, Rural Women Skill Group, local institutions आणि community services यांना digital visibility देणे.</p><div class="grid g3"><div class="feature"><span class="ico">👩‍🌾</span><span><b>Skill Groups</b><p>Local women skill groups.</p></span></div><div class="feature"><span class="ico">🏫</span><span><b>Institutions</b><p>Village-level training/support.</p></span></div><div class="feature"><span class="ico">📊</span><span><b>Dashboard</b><p>Community skills and impact.</p></span></div></div></section>`); }

  function impactPage(){ return layout(`<div class="section-head"><div><h2>🌱 Expected Benefits, Impact & Future Scope</h2><p>Individual empowerment → local economic development → smart village</p></div></div><div class="grid g3">${[['🎯','Career Guidance','Clear pathways based on skill and goal.'],['👀','Skill Visibility','Local talent becomes easier to discover.'],['🤝','Market Connection','Connect products/services with customers.'],['🔓','Opportunity Access','Training, schemes and business pathways.'],['🏛️','Scheme Discovery','One place to explore relevant scheme categories.'],['📱','Digital Visibility','Profiles, listings and local services online.']].map(x=>`<div class="card feature"><span class="ico">${x[0]}</span><span><h3>${x[1]}</h3><p>${x[2]}</p></span></div>`).join('')}</div><section class="section card"><h3>🚀 Future Scope</h3>${['Local dialects','Mobile + Offline support','Verified integrations','Business planning','Community dashboards','Geographical maps','Impact analysis','Digital safety improvements','Real AI/NLP services','Secure backend and database'].map(x=>`<span class="tag">${x}</span>`).join('')}</section>`); }

  function profilePage(){ const u=user(); return layout(`<div class="section-head"><div><h2>👩‍🌾 My Digital Profile</h2><p>Basic details • education • skill • goal • safety</p></div><button class="btn btn-danger" data-action="logout">Logout</button></div><div class="grid g2"><div class="card"><div class="bigico">🌸</div><h3>${esc(u.name)}</h3><div class="list"><div class="list-row"><span>📱 Mobile</span><b>${esc(u.mobile)}</b></div><div class="list-row"><span>✉️ Email</span><b>${esc(u.email)}</b></div><div class="list-row"><span>📍 Village / District</span><b>${esc(u.village)}, ${esc(u.district)}</b></div><div class="list-row"><span>🎓 Education</span><b>${esc(u.education)}</b></div><div class="list-row"><span>🧵 Skill</span><b>${esc(u.skill)}</b></div><div class="list-row"><span>🎯 Goal</span><b>${esc(u.goal)}</b></div></div></div><div class="card"><h3>🔐 Digital Safety & Privacy</h3><div class="timeline"><div class="step"><span class="step-num">✓</span><div><h4>Consent</h4><p>Registration मध्ये consent घेतला जातो.</p></div></div><div class="step"><span class="step-num">✓</span><div><h4>Demo storage</h4><p>Prototype data localStorage मध्ये आहे.</p></div></div><div class="step"><span class="step-num">✓</span><div><h4>Production security</h4><p>HTTPS, secure auth, password hashing, role-based access, encrypted transport/storage आणि privacy controls आवश्यक.</p></div></div><div class="step"><span class="step-num">✓</span><div><h4>Verified integrations</h4><p>Government/market services साठी trusted official APIs वापरणे आवश्यक.</p></div></div></div></div></div><section class="section card"><h3>🧹 Demo Data Control</h3><p class="muted">Prototype testing साठी local demo data reset करू शकता.</p><button class="btn btn-outline" data-action="reset">Reset Demo Data</button></section>`); }

  function voiceModal(){ return `<div><h2>🎙️ Marathi / Local Language Voice Assistant</h2><p class="muted">Voice input → speech recognition → AI understanding → recommendation → voice/text response.</p><button class="btn btn-primary" id="startVoice">🎙️ Start Voice</button><button class="btn btn-soft" id="speakDemo" style="margin-left:7px">🔊 Speak Demo</button><div id="voiceResult" style="margin-top:13px"></div><div class="notice">उदा. “माझ्याकडे शिवणकामाचे कौशल्य आहे, मी काय सुरू करू?” असे बोला. Browser support असल्यास speech recognition वापरले जाईल.</div></div>`; }
  function openModal(content){ closeModal(); const m=document.createElement('div');m.className='modal';m.id='modal';m.innerHTML=`<div class="modal-card"><div class="modal-head"><button class="close" id="closeModal">×</button></div>${content}</div>`;document.body.appendChild(m); }
  function closeModal(){ document.getElementById('modal')?.remove(); }
  function startVoice(){ const R=window.SpeechRecognition||window.webkitSpeechRecognition; const out=document.getElementById('voiceResult'); if(!out)return; if(!R){out.innerHTML='<div class="notice danger">या browser मध्ये speech recognition उपलब्ध नाही. Text mode किंवा keyboard वापरा.</div>';return;} const r=new R();r.lang='mr-IN';r.interimResults=false;r.maxAlternatives=1;r.onresult=e=>{const spoken=e.results[0][0].transcript;out.innerHTML=`<div class="notice success"><b>तुम्ही म्हणालात:</b> ${esc(spoken)}</div><div class="card" style="margin-top:10px"><b>🤖 उन्नती:</b> तुमच्या profile, skill assessment, training, business recommendation आणि scheme discovery मधून योग्य पुढचा pathway पाहा.</div>`;};r.onerror=()=>{out.innerHTML='<div class="notice danger">Voice input मिळाला नाही. पुन्हा प्रयत्न करा.</div>';};r.start(); }
  function speak(text){ if('speechSynthesis' in window){ const s=new SpeechSynthesisUtterance(text);s.lang='mr-IN';window.speechSynthesis.cancel();window.speechSynthesis.speak(s); } }

  function render(){
    if(!user()){ app.innerHTML = authPage(); bind(); renderToast(); return; }
    const pages={dashboard,assessment:assessmentPage,business:businessPage,schemes:schemesPage,training:trainingPage,market:marketPage,village:villagePage,impact:impactPage,profile:profilePage};
    app.innerHTML = pages[state.route] ? pages[state.route]() : dashboard();
    bind(); renderToast();
  }

  function bind(){
    document.querySelectorAll('[data-route]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.route)));
    document.querySelectorAll('[data-auth]').forEach(b=>b.addEventListener('click',()=>{state.auth=b.dataset.auth;render();}));
    document.getElementById('registerForm')?.addEventListener('submit',e=>{e.preventDefault();
      const mobile=document.getElementById('rMobile').value.trim();
      if(!/^\d{10}$/.test(mobile)){toast('Mobile number 10 digits असावा.');return;}
      const u={name:document.getElementById('rName').value.trim(),mobile,email:document.getElementById('rEmail').value.trim().toLowerCase(),village:document.getElementById('rVillage').value.trim(),district:document.getElementById('rDistrict').value.trim(),education:document.getElementById('rEducation').value,skill:document.getElementById('rSkill').value,goal:document.getElementById('rGoal').value,password:document.getElementById('rPass').value,progress:{},orders:[],createdAt:new Date().toISOString()};
      write(USER_KEY,u);state.route='dashboard';toast('Account तयार झाले. स्वागत आहे!');render();
    });
    document.getElementById('loginForm')?.addEventListener('submit',e=>{e.preventDefault();const id=document.getElementById('loginId').value.trim().toLowerCase(),p=document.getElementById('loginPass').value,u=user();if(u&&[u.mobile,u.email].includes(id)&&u.password===p){state.route='dashboard';render();}else toast('Login details जुळले नाहीत. आधी Create Account करा किंवा तपशील तपासा.');});
    document.querySelectorAll('[data-action="logout"]').forEach(b=>b.addEventListener('click',logout));
    document.querySelectorAll('[data-action="reset"]').forEach(b=>b.addEventListener('click',()=>{if(confirm('Demo data reset करायचा?'))resetDemo();}));
    document.querySelectorAll('[data-action="voice"]').forEach(b=>b.addEventListener('click',()=>{openModal(voiceModal());document.getElementById('closeModal').addEventListener('click',closeModal);document.getElementById('startVoice').addEventListener('click',startVoice);document.getElementById('speakDemo').addEventListener('click',()=>speak('उन्नतीमध्ये तुमच्या कौशल्याला योग्य प्रशिक्षण, व्यवसाय, बाजारपेठ आणि योजना शोधता येतात.'));}));
    document.getElementById('closeModal')?.addEventListener('click',closeModal);
    document.getElementById('assessmentForm')?.addEventListener('submit',e=>{e.preventDefault();const skill=document.getElementById('aSkill').value,level=document.getElementById('aLevel').value,strength=document.getElementById('aStrength').value,goal=document.getElementById('aGoal').value;const base={Beginner:55,Basic:65,Intermediate:78,Advanced:90}[level];const score=Math.min(98,base+(goal.includes('Business')?3:0)+(skill==='Digital Service Centre'?2:0));const gaps=level==='Beginner'?['Practical experience','Digital confidence','Market exposure']:level==='Basic'?['Advanced practice','Pricing / costing','Customer reach']:['Market analytics','Business planning','Digital visibility'];const rec=goal==='Start a Business'?`${skill} + business planning + marketplace`:goal==='Job / Career'?`${skill} + personalized training + career pathway`:`${skill} + personalized training + marketplace`;const a={skill,level,score,strengths:[strength,'Local opportunity awareness'],gaps,recommendation:rec,goal,date:new Date().toISOString()};write(ASSESS_KEY,a);updateUser({skill});toast('AI Analysis पूर्ण झाला!');render();});
    document.querySelectorAll('[data-training]').forEach(b=>b.addEventListener('click',()=>{const u=user();const key=b.dataset.training;const progress={...(u.progress||{})};progress[key]=Math.min(100,(progress[key]||0)+25);write(USER_KEY,{...u,progress});toast(`${key}: progress ${progress[key]}%`);render();}));
    document.querySelectorAll('[data-order]').forEach(b=>b.addEventListener('click',()=>{const u=user();const orders=[...(u.orders||[]),{product:b.dataset.order,price:b.dataset.price,date:new Date().toLocaleDateString('en-IN')}];write(USER_KEY,{...u,orders});toast(`${b.dataset.order} ची request/order demo मध्ये save झाली.`);}));
    document.querySelectorAll('[data-pathway]').forEach(b=>b.addEventListener('click',()=>toast(`${b.dataset.pathway}: pathway saved for demo.`)));
    document.querySelectorAll('[data-scheme]').forEach(b=>b.addEventListener('click',()=>toast(`${b.dataset.scheme}: official eligibility तपासण्याची checklist उघडली.`)));
    document.querySelector('[data-action="addListing"]')?.addEventListener('click',()=>openListingModal());
  }

  function openListingModal(){ openModal(`<div><h2>➕ Add Product / Service</h2><form class="form" id="listingForm"><div class="field"><label for="pName">Product / Service</label><input id="pName" required placeholder="उदा. Handmade Blouse"></div><div class="two"><div class="field"><label for="pPrice">Price</label><input id="pPrice" placeholder="₹650"></div><div class="field"><label for="pCat">Category</label><select id="pCat">${DATA.skills.map(s=>`<option>${s}</option>`).join('')}</select></div></div><div class="field"><label for="pDesc">Description</label><textarea id="pDesc" rows="3" placeholder="तुमच्या product/service बद्दल थोडक्यात..."></textarea></div><button class="btn btn-primary">Create AI-style Listing</button></form></div>`);document.getElementById('closeModal').addEventListener('click',closeModal);document.getElementById('listingForm').addEventListener('submit',e=>{e.preventDefault();const name=document.getElementById('pName').value.trim(),price=document.getElementById('pPrice').value.trim()||'Price on request',category=document.getElementById('pCat').value,desc=document.getElementById('pDesc').value.trim()||`${name} – local customers साठी तयार केलेली ${category} सेवा / product.`;const arr=listings();arr.push({icon:'🌸',name,price,category,description:desc,createdAt:new Date().toISOString()});write(LISTING_KEY,arr);closeModal();toast('Listing तयार झाली.');render();}); }

  // Start
  render();
})();
