import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';

const KEY='mht_records_v1', REM='mht_reminder_v1', THEME='mht_theme_v1';
let records=new Set(JSON.parse(localStorage.getItem(KEY)||'[]'));
let cursor=new Date(); cursor.setDate(1);
const $=id=>document.getElementById(id);
const save=()=>localStorage.setItem(KEY,JSON.stringify([...records]));
const iso=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const pretty=s=>new Date(s+'T12:00:00').toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'});
function render(){
  $('monthName').textContent=cursor.toLocaleDateString(undefined,{month:'long',year:'numeric'});
  $('calendarGrid').innerHTML='';
  const first=new Date(cursor.getFullYear(),cursor.getMonth(),1);
  const offset=(first.getDay()+6)%7;
  const count=new Date(cursor.getFullYear(),cursor.getMonth()+1,0).getDate();
  for(let i=0;i<offset;i++){const e=document.createElement('div');e.className='day empty';$('calendarGrid').append(e)}
  for(let n=1;n<=count;n++){
    const d=new Date(cursor.getFullYear(),cursor.getMonth(),n), key=iso(d);
    const b=document.createElement('button');b.className='day'+(records.has(key)?' applied':'')+(key===iso(new Date())?' today':'');b.textContent=n;
    b.setAttribute('aria-label',pretty(key)+(records.has(key)?', applied':', not marked'));
    b.onclick=()=>{records.has(key)?records.delete(key):records.add(key);save();render()};
    $('calendarGrid').append(b);
  }
  const monthRecords=[...records].filter(x=>x.startsWith(`${cursor.getFullYear()}-${String(cursor.getMonth()+1).padStart(2,'0')}`));
  const daysElapsed=cursor.getFullYear()===new Date().getFullYear()&&cursor.getMonth()===new Date().getMonth()?new Date().getDate():count;
  const rate=cursor>new Date(new Date().getFullYear(),new Date().getMonth(),1)?0:Math.round(monthRecords.length/Math.max(1,daysElapsed)*100);
  $('totalDays').textContent=records.size;$('monthRate').textContent=rate+'%';
  $('streak').textContent=calcStreak();
  $('progressPercent').textContent=rate+'%';$('progressRing').style.background=`conic-gradient(var(--green) ${rate}%,#ffffff18 0)`;
  $('progressTitle').textContent=records.size?'Keep building your routine':'A fresh start';
  $('progressText').textContent=`You have recorded ${records.size} application day${records.size===1?'':'s'} in total.`;
  const hist=[...records].sort().reverse().slice(0,20);
  $('historyList').innerHTML=hist.length?hist.map(x=>`<li>${pretty(x)}</li>`).join(''):'<li class="muted">No dates recorded yet.</li>';
}
function calcStreak(){
  let d=new Date();let k=iso(d);if(!records.has(k)){d.setDate(d.getDate()-1);k=iso(d)}
  let n=0;while(records.has(k)&&n<3660){n++;d.setDate(d.getDate()-1);k=iso(d)}return n;
}
$('prevMonth').onclick=()=>{cursor.setMonth(cursor.getMonth()-1);render()};
$('nextMonth').onclick=()=>{cursor.setMonth(cursor.getMonth()+1);render()};
document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===t));document.querySelectorAll('.view').forEach(v=>v.classList.add('hidden'));$(t.dataset.view+'View').classList.remove('hidden')});
$('themeBtn').onclick=()=>{document.body.classList.toggle('light');localStorage.setItem(THEME,document.body.classList.contains('light')?'light':'dark')};
if(localStorage.getItem(THEME)==='light')document.body.classList.add('light');
$('todayLabel').textContent=new Date().toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'long'});
function loadReminder(){const r=JSON.parse(localStorage.getItem(REM)||'{}');$('reminderEnabled').checked=!!r.enabled;$('reminderTime').value=r.time||'20:00';$('reminderStatus').textContent=r.enabled?`Daily reminder set for ${r.time}.`:'Reminder is off.'}
async function permission(){if(Capacitor.isNativePlatform()){const p=await LocalNotifications.requestPermissions();return p.display==='granted'}if('Notification'in window){const p=await Notification.requestPermission();return p==='granted'}alert('Notifications are not supported in this browser.');return false}
async function scheduleReminder(enabled,time){
  if(Capacitor.isNativePlatform()){
    try{await LocalNotifications.cancel({notifications:[{id:101}]});if(enabled){const ok=await permission();if(!ok)return false;const [h,m]=time.split(':').map(Number);await LocalNotifications.schedule({notifications:[{id:101,title:'MY HAIR TRACKER',body:'Time to apply your hair serum!',schedule:{on:{hour:h,minute:m},allowWhileIdle:true},repeats:true,smallIcon:'ic_stat_icon_config_sample'}]})}return true}catch(e){alert('Could not schedule the reminder. Check notification permission and Android setup.');return false}
  }
  if(enabled){alert('For reliable reminders when the app is closed, install the Android APK. Browser reminders may not run in the background.');return false}
  return true;
}
$('saveReminder').onclick=async()=>{const enabled=$('reminderEnabled').checked,time=$('reminderTime').value;if(!time){alert('Choose a reminder time.');return}const ok=await scheduleReminder(enabled,time);if(enabled&&!ok){$('reminderEnabled').checked=false;return}localStorage.setItem(REM,JSON.stringify({enabled,time}));loadReminder()};
$('askPermission').onclick=async()=>{const ok=await permission();alert(ok?'Notifications are allowed.':'Notification permission was not granted.')};
$('previewSound').onclick=()=>{try{const C=window.AudioContext||window.webkitAudioContext;const c=new C();const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.setValueAtTime(660,c.currentTime);o.frequency.exponentialRampToValueAtTime(880,c.currentTime+.16);g.gain.setValueAtTime(.0001,c.currentTime);g.gain.exponentialRampToValueAtTime(.16,c.currentTime+.03);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+.38);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.4)}catch(e){alert('Sound preview is unavailable on this device.')}};
loadReminder();render();
if('serviceWorker'in navigator && !Capacitor.isNativePlatform())navigator.serviceWorker.register('/sw.js').catch(()=>{});
