(() => {
const $=s=>document.querySelector(s);
const audio=$("#audio"), input=$("#fileInput"), bubble=$("#bubble"), mini=$("#mini");
const KEY="game_music_bubble_v1";
let tracks=[], current=-1, dragging=false, moved=false, startX=0,startY=0,origX=0,origY=0;

const defaults={size:58,opacity:.9,autoOpen:false,shuffle:false,repeat:false,gaming:false,volume:.9,x:18,y:null};
let settings={...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")};

function save(){localStorage.setItem(KEY,JSON.stringify({...settings}));}
function fmt(v){if(!isFinite(v))return"0:00";let m=Math.floor(v/60),s=Math.floor(v%60);return m+":"+String(s).padStart(2,"0")}
function applySettings(){
 bubble.style.width=bubble.style.height=settings.size+"px";
 bubble.style.opacity=settings.opacity;
 if(settings.x!=null)bubble.style.left=settings.x+"px";
 if(settings.y!=null)bubble.style.top=settings.y+"px";
 $("#sizeRange").value=settings.size; $("#opacityRange").value=Math.round(settings.opacity*100);
 $("#autoOpen").checked=settings.autoOpen;$("#shuffleToggle").checked=settings.shuffle;
 $("#repeatToggle").checked=settings.repeat;$("#gamingToggle").checked=settings.gaming;
 audio.volume=settings.volume;
}
function setScreen(id){
 document.querySelectorAll(".screen").forEach(x=>x.classList.toggle("active",x.id===id));
 document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.screen===id));
}
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>setScreen(b.dataset.screen));
["addBtn","addTop","addLibrary"].forEach(id=>$("#"+id).onclick=()=>input.click());

input.onchange=()=>{[...input.files].forEach(file=>{
 if(!file.type.startsWith("audio/"))return;
 tracks.push({name:file.name,url:URL.createObjectURL(file),file});
});render();if(current<0&&tracks.length)load(0,false);input.value=""};

function render(){
 const lists=[$("#libraryList"),$("#playlistList")];
 lists.forEach(list=>list.innerHTML="");
 tracks.forEach((t,i)=>{
  const el=document.createElement("div");el.className="track";
  el.innerHTML=`<div class="track-icon">♫</div><div class="track-info"><b></b><small>Local audio</small></div><button>▶</button>`;
  el.querySelector("b").textContent=t.name;
  el.querySelector("button").onclick=()=>{load(i,true);};
  lists[0].appendChild(el);lists[1].appendChild(el.cloneNode(true));
  lists[1].lastChild.querySelector("b").textContent=t.name;
  lists[1].lastChild.querySelector("button").onclick=()=>load(i,true);
 });
 if(!tracks.length){lists.forEach(l=>l.innerHTML='<div class="card empty">No music added yet.</div>')}
 updateLabels();
}
function load(i,autoplay){
 if(!tracks[i])return; current=i;audio.src=tracks[i].url;audio.load();updateLabels();
 if(autoplay)play();
}
async function play(){
 if(current<0&&tracks.length)load(0,false);
 if(current<0)return;
 try{await audio.play();}catch(e){console.warn(e)}
}
function pause(){audio.pause()}
function next(){
 if(!tracks.length)return;
 let i=settings.shuffle?Math.floor(Math.random()*tracks.length):(current+1)%tracks.length;
 load(i,true);
}
function prev(){if(!tracks.length)return;let i=(current-1+tracks.length)%tracks.length;load(i,true)}
function updateLabels(){
 const name=current>=0&&tracks[current]?tracks[current].name:"No track selected";
 $("#homeTrack").textContent=name;$("#miniTitle").textContent=name;
}
function state(){
 const playing=!audio.paused;
 bubble.classList.toggle("playing",playing);
 $("#miniPlay").textContent=playing?"❚❚":"▶";
 if(window.GameMusicAndroid?.setPlaybackState)window.GameMusicAndroid.setPlaybackState(playing?"playing":"paused");
}
audio.onplay=state;audio.onpause=state;
audio.ontimeupdate=()=>{$("#progress").value=audio.duration?(audio.currentTime/audio.duration)*100:0;$("#currentTime").textContent=fmt(audio.currentTime);$("#totalTime").textContent=fmt(audio.duration)};
audio.onended=()=>settings.repeat?play():next();
audio.onerror=()=>console.warn("Audio playback error");

$("#playBtn").onclick=()=>audio.paused?play():pause();
$("#miniPlay").onclick=()=>audio.paused?play():pause();
$("#nextBtn").onclick=next;$("#prevBtn").onclick=prev;
$("#progress").oninput=e=>{if(audio.duration)audio.currentTime=(e.target.value/100)*audio.duration};
$("#volume").oninput=e=>{settings.volume=+e.target.value;audio.volume=settings.volume;save()};
$("#shuffleBtn").onclick=()=>{settings.shuffle=!settings.shuffle;$("#shuffleToggle").checked=settings.shuffle;save()};
$("#miniShuffle").onclick=()=>{$("#shuffleToggle").click()};
$("#miniRepeat").onclick=()=>{$("#repeatToggle").click()};
$("#clearBtn").onclick=()=>{tracks.forEach(t=>URL.revokeObjectURL(t.url));tracks=[];current=-1;audio.removeAttribute("src");render();state()};

function openMini(){mini.classList.remove("hidden");}
function closeMini(){mini.classList.add("hidden")}
bubble.onclick=()=>{if(!moved)openMini()};
$("#closeMini").onclick=closeMini;
mini.addEventListener("click",e=>{if(e.target===mini)closeMini()});

bubble.addEventListener("pointerdown",e=>{dragging=true;moved=false;bubble.setPointerCapture(e.pointerId);startX=e.clientX;startY=e.clientY;origX=parseFloat(getComputedStyle(bubble).left);origY=parseFloat(getComputedStyle(bubble).top)});
bubble.addEventListener("pointermove",e=>{if(!dragging)return;let dx=e.clientX-startX,dy=e.clientY-startY;if(Math.abs(dx)+Math.abs(dy)>6)moved=true;settings.x=Math.max(0,Math.min(innerWidth-settings.size,origX+dx));settings.y=Math.max(0,Math.min(innerHeight-settings.size,origY+dy));bubble.style.left=settings.x+"px";bubble.style.top=settings.y+"px"});
bubble.addEventListener("pointerup",()=>{if(!dragging)return;dragging=false;settings.x=settings.x<innerWidth/2?4:innerWidth-settings.size-4;save();bubble.style.left=settings.x+"px";});

$("#sizeRange").oninput=e=>{settings.size=+e.target.value;applySettings();save()};
$("#opacityRange").oninput=e=>{settings.opacity=+e.target.value/100;applySettings();save()};
$("#autoOpen").onchange=e=>{settings.autoOpen=e.target.checked;save()};
$("#shuffleToggle").onchange=e=>{settings.shuffle=e.target.checked;save()};
$("#repeatToggle").onchange=e=>{settings.repeat=e.target.checked;save()};
$("#gamingToggle").onchange=e=>{settings.gaming=e.target.checked;document.body.classList.toggle("gaming",settings.gaming);save()};
$("#resetBubble").onclick=()=>{settings.x=18;settings.y=innerHeight*.45;applySettings();save()};

if("mediaSession" in navigator){
 navigator.mediaSession.setActionHandler("play",play);
 navigator.mediaSession.setActionHandler("pause",pause);
 navigator.mediaSession.setActionHandler("nexttrack",next);
 navigator.mediaSession.setActionHandler("previoustrack",prev);
}
function mediaMeta(){
 if(!("mediaSession" in navigator)||current<0)return;
 navigator.mediaSession.metadata=new MediaMetadata({title:tracks[current].name,artist:"Game Music Bubble"});
}
audio.onloadedmetadata=mediaMeta;

window.GameMusicBubbleNativeBridge={
 showOverlay(){window.GameMusicAndroid?.showOverlay?.()},
 hideOverlay(){window.GameMusicAndroid?.hideOverlay?.()},
 setOverlayPosition(x,y){window.GameMusicAndroid?.setOverlayPosition?.(Math.round(x),Math.round(y))},
 setPlaybackState(s){window.GameMusicAndroid?.setPlaybackState?.(s)}
};

if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("service-worker.js").catch(()=>{});
applySettings();settings.y??=innerHeight*.45;render();state();
})();