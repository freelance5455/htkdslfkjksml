(() => {
  const SMS_DESTINATION = '09366439842';
  const nameInput = document.querySelector('#customer-name');
  const mobileInput = document.querySelector('#mobile');
  const detailsInput = document.querySelector('#details');
  const feedback = document.querySelector('#feedback');

  document.querySelector('#send').addEventListener('click', () => {
    const name = nameInput.value.trim();
    const mobile = mobileInput.value.trim();
    const details = detailsInput.value.trim();
    const lines = ['سلام، سفارش دارم.'];
    if (name) lines.push(`نام و نام خانوادگی: ${name}`);
    if (mobile) lines.push(`شماره تماس: ${mobile}`);
    if (details) lines.push(`توضیحات: ${details}`);

    const url = `sms:${SMS_DESTINATION}?body=${encodeURIComponent(lines.join('\n'))}`;
    feedback.textContent = 'برنامهٔ پیامک در حال بازشدن است؛ برای ارسال، دکمهٔ ارسال گوشی را بزنید.';
    feedback.className = 'feedback success';
    window.location.href = url;
  });
})();