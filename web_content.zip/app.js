/* ============================================================================
   AURA PLAYER — app.js
   Reproductor de música 100 % local con "atmósferas" dinámicas.

   ARQUITECTURA (ver README.md para la guía completa)
   ---------------------------------------------------------------------------
   1. UTILIDADES            normalización, hash, tiempo, carga diferida
   2. ESTADO Y AJUSTES      biblioteca, reproducción y persistencia (localStorage)
   3. INDEXEDDB             guarda el "handle" de la carpeta (File System Access)
   4. MOTOR DE TEMAS        5 niveles de prioridad para el fondo de cada canción:
                              1. Portada del álbum  → paleta de 3 colores (ColorThief)
                              2. Nombre de carpeta  → palabras clave (Rock, Jazz…)
                              3. Género ID3         → mismas palabras clave
                              4. Nombre de artista  → color HSL determinista por hash
                              5. Tema neutro        → gris azulado por defecto
   5. CARGA DE BIBLIOTECA   3 niveles según capacidades del navegador:
                              A. File System Access API  → carpeta permanente,
                                 relectura automática + FileSystemObserver
                              B. <input webkitdirectory> → elegir carpeta por sesión
                                 (Chrome Android, memoria interna y SD)
                              C. <input type="file">     → archivos sueltos
   6. METADATOS             cola asíncrona con concurrencia máx. 5
                            (ID3 vía jsmediatags, portada 300 px, duración)
   7. REPRODUCCIÓN          HTMLAudioElement + Media Session API
   8. INTERFAZ              lista paginada, búsqueda, filtros, mini + full player
   9. GESTOS Y TECLADO      swipe en la portada, atajos de teclado
  10. ARRANQUE              restaurar ajustes, carpeta persistente, Service Worker
   ============================================================================ */

'use strict';

/* ============================================================================
   1. UTILIDADES
   ============================================================================ */

const $  = (sel) => document.querySelector(sel);
const $$ = (sel) => [...document.querySelectorAll(sel)];

/** Normaliza texto: minúsculas y SIN tildes (para comparar "Reggaetón" == "reggaeton"). */
function norm(s) {
  return (s == null ? '' : String(s)).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
}

/** Hash FNV-1a de 32 bits: determinista (mismo artista → mismo color siempre). */
function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** 95 → "1:35"; 3800 → "1:03:20" */
function fmtTime(sec) {
  if (!isFinite(sec) || sec < 0) return '–:––';
  sec = Math.round(sec);
  const m = Math.floor(sec / 60), s = sec % 60;
  if (m >= 60) {
    const h = Math.floor(m / 60);
    return `${h}:${String(m % 60).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
  return `${m}:${String(s).padStart(2, '0')}`;
}

function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

/** requestIdleCallback con respaldo (para trabajo de baja prioridad). */
function idle(fn) {
  if ('requestIdleCallback' in window) requestIdleCallback(fn, { timeout: 800 });
  else setTimeout(fn, 60);
}

/** Carga una <img> desde una URL de objeto. */
function loadImage(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = url;
  });
}

/* Extensiones de audio admitidas (según códecs habituales de Chrome/Android). */
const AUDIO_EXT = new Set(['mp3', 'm4a', 'aac', 'ogg', 'oga', 'opus', 'wav', 'flac', 'weba', 'webm']);
const extOf = (name) => { const i = name.lastIndexOf('.'); return i < 0 ? '' : name.slice(i + 1).toLowerCase(); };

/** "01 - Mi canción.mp3" → "Mi canción" (limpia números y guiones iniciales). */
function prettyTitle(fileName) {
  let t = fileName.replace(/\.[^.]+$/, '');           // sin extensión
  t = t.replace(/^\s*\d{1,3}\s*[-_.)]*\s*/, '');      // sin "01 - "
  t = t.replace(/[_]+/g, ' ').replace(/\s{2,}/g, ' ').trim();
  return t || fileName;
}

/* ============================================================================
   2. ESTADO GLOBAL Y AJUSTES PERSISTENTES
   ============================================================================ */

const state = {
  songs: [],            // biblioteca completa (objetos Song)
  view: [],             // índices visibles tras buscar/filtrar/ordenar
  currentIndex: -1,     // índice en state.songs de la canción actual
  source: null,         // { type:'fsa'|'input', rootName, handle? }
  pendingHandle: null,  // handle FSA guardado esperando permiso del usuario

  shuffle: false,
  bag: [],               // "bolsa" de índices barajados pendientes
  history: [],           // historial para "anterior" en modo aleatorio
  repeat: 'off',         // 'off' | 'all' | 'one'

  query: '',
  folderFilter: 'all',
  sortMode: 'added',

  rendered: 0,           // filas ya pintadas (paginación)
  rowEls: new Map(),     // id → <li> para actualizar filas sin re-pintar todo

  metaQueue: [],         // canciones pendientes de metadatos
  metaActive: 0,         // trabajos activos (máx. META_CONCURRENCY)
  rescanning: false,
  lastScan: 0,
  fsObserver: null,      // FileSystemObserver (si está disponible)
  errorStreak: 0,        // archivos fallidos consecutivos (evita bucles)
};

const META_CONCURRENCY = 5;   // límite de lecturas de metadatos en paralelo
const LS_KEY = 'auraPlayer.v1';

function defaultSettings() {
  return {
    volume: 0.9,
    shuffle: false,
    repeat: 'off',
    mode: 'auto',            // 'auto' | 'light' | 'dark'
    lastPath: null,          // relPath de la última canción
    positions: {},           // relPath → segundos guardados
    sortMode: 'added',
  };
}

function loadSettings() {
  try {
    return Object.assign(defaultSettings(), JSON.parse(localStorage.getItem(LS_KEY) || '{}'));
  } catch { return defaultSettings(); }
}

const settings = loadSettings();

const saveSettings = debounce(() => {
  try { localStorage.setItem(LS_KEY, JSON.stringify(settings)); } catch { /* modo privado */ }
}, 400);

/** Guardado inmediato (al ocultar/cerrar la página). */
function flushSettings() {
  try { localStorage.setItem(LS_KEY, JSON.stringify(settings)); } catch { /* ignore */ }
}

/* ============================================================================
   3. INDEXEDDB — persistencia del handle de carpeta (File System Access API)
   Solo se usa en navegadores con showDirectoryPicker (Chrome/Edge escritorio).
   ============================================================================ */

let idbPromise = null;
function idb() {
  if (!('indexedDB' in window)) return Promise.resolve(null);
  if (!idbPromise) {
    idbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open('aura-player', 1);
        req.onupgradeneeded = () => { try { req.result.createObjectStore('kv'); } catch { /* ya existe */ } };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => resolve(null);
      } catch { resolve(null); }
    });
  }
  return idbPromise;
}

async function idbSet(key, value) {
  const db = await idb();
  if (!db) return;
  return new Promise((resolve) => {
    try {
      const tx = db.transaction('kv', 'readwrite');
      tx.objectStore('kv').put(value, key);
      tx.oncomplete = tx.onerror = tx.onabort = () => resolve();
    } catch { resolve(); }
  });
}

async function idbGet(key) {
  const db = await idb();
  if (!db) return undefined;
  return new Promise((resolve) => {
    try {
      const rq = db.transaction('kv', 'readonly').objectStore('kv').get(key);
      rq.onsuccess = () => resolve(rq.result);
      rq.onerror = () => resolve(undefined);
    } catch { resolve(undefined); }
  });
}

/* ============================================================================
   Mensajes accesibles (toast + región aria-live)
   ============================================================================ */

let toastTimer = null;
function toast(msg, ms = 2600) {
  const el = $('#toast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), ms);
}

function announce(msg) {
  const el = $('#announce');
  if (el) el.textContent = msg;
}

/* ============================================================================
   4. MOTOR DE TEMAS — el "aura" de cada canción
   ============================================================================
   Cadena de prioridad (la primera que aplite gana):

     1. PORTADA   → ColorThief extrae 3 colores dominantes del arte del álbum
     2. CARPETA   → palabras clave en la ruta: "Music/Rock/..." → rojos
     3. GÉNERO    → etiqueta ID3 con las mismas palabras clave
     4. ARTISTA   → color HSL determinista a partir de un hash del nombre
     5. NEUTRO    → gris azulado con acento azul (tema por defecto)

   Mientras los metadatos se cargan en segundo plano, la canción arranca con
   los niveles 2–5 y "sube" al nivel 1 cuando llega la paleta: la transición
   del fondo (1,5 s) hace que el cambio sea parte de la experiencia.
   ============================================================================ */

const DEFAULT_THEME = {
  type: 'default',
  source: 'default',
  gradient: 'linear-gradient(135deg, #232936, #2f3b52, #3f6ea8)',
  textColor: '#f2f5fb',
  accent: '#6ea8ff',
  accentContrast: '#0d1117',
  swatch: '#141821',
};

/* Palabras clave (ya normalizadas: minúsculas y sin tildes).
   Cada grupo define el degradado característico de ese género/ánimo. */
const FOLDER_THEMES = [
  { name: 'rock',       keys: ['rock', 'metal', 'punk', 'grunge', 'hard rock', 'indie'],
    colors: ['#17141d', '#c62828', '#ef6c00'] },                        // rojo/naranja/negro
  { name: 'chill',      keys: ['chill', 'relax', 'relajante', 'lofi', 'lo-fi', 'lo fi', 'downtempo', 'ambient'],
    colors: ['#7fc7dd', '#a5d9b5', '#f5cfe3'] },                        // azul/verde/pastel
  { name: 'electronica', keys: ['electronica', 'edm', 'techno', 'house', 'trance', 'dubstep', 'electro', 'rave'],
    colors: ['#3a0ca3', '#b5179e', '#4cc9f0'] },                        // púrpura/magenta/cian neón
  { name: 'pop',        keys: ['pop', 'kpop', 'top hits', 'exitos'],
    colors: ['#ff4f9a', '#ffb3d1', '#ffd166'] },                        // rosa/amarillo
  { name: 'clasica',    keys: ['clasica', 'classical', 'opera', 'orquesta', 'soundtrack', 'banda sonora'],
    colors: ['#4e342e', '#b8860b', '#e8d5a3'] },                        // marrón/dorado/beige
  { name: 'jazz',       keys: ['jazz', 'blues', 'bossa', 'swing', 'soul'],
    colors: ['#0b2545', '#577399', '#ffb703'] },                        // azul profundo/ámbar
  { name: 'hiphop',     keys: ['hip hop', 'hip-hop', 'rap', 'trap', 'drill'],
    colors: ['#26282f', '#4a4e5a', '#c9a227'] },                        // gris/dorado
  { name: 'latina',     keys: ['latina', 'latino', 'salsa', 'reggaeton', 'cumbia', 'bachata', 'merengue', 'vallenato', 'tropical'],
    colors: ['#c1121f', '#e85d04', '#ffba08'] },                        // naranja/rojo/amarillo
];

function rgbToHex([r, g, b]) {
  return '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
}

/** Luminancia media aproximada (0–255). */
function luminance([r, g, b]) {
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

/** Texto claro u oscuro según el brillo medio de los colores del tema. */
function autoTextColor(colors) {
  const rgb = colors.map(hexToRgb).filter(Boolean);
  if (!rgb.length) return DEFAULT_THEME.textColor;
  const lum = rgb.reduce((a, c) => a + luminance(c), 0) / rgb.length;
  return lum > 150 ? '#171d29' : '#f6f8fc';
}

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex);
  if (!m) return null;
  return [parseInt(m[1].slice(0, 2), 16), parseInt(m[1].slice(2, 4), 16), parseInt(m[1].slice(4, 6), 16)];
}

/** El color más "vivo" de la paleta será el color de acento de la interfaz. */
function pickVivid(palette) {
  let best = palette[0], bestScore = -1;
  for (const c of palette) {
    const score = (Math.max(c[0], c[1], c[2]) - Math.min(c[0], c[1], c[2])); // saturación aproximada
    if (score > bestScore) { bestScore = score; best = c; }
  }
  return rgbToHex(best);
}

/** Tema a partir de una lista de colores (portada o grupo por palabras clave). */
function themeFromColors(colors, source) {
  const textColor = autoTextColor(colors);
  const accent = pickVivid(colors.map(hexToRgb).filter(Boolean).length ? colors.map(hexToRgb).filter(Boolean) : [hexToRgb('#6ea8ff')]);
  const accentRgb = hexToRgb(accent) || [110, 168, 255];
  return {
    type: source,
    source,
    gradient: `linear-gradient(135deg, ${colors.join(', ')})`,
    textColor,
    accent,
    accentContrast: luminance(accentRgb) > 150 ? '#141821' : '#ffffff',
    swatch: colors[0],
  };
}

/** Nivel 2/3: busca palabras clave en el nombre de carpeta o en el género. */
function themeFromKeywords(str) {
  if (!str) return null;
  const n = norm(str);
  for (const t of FOLDER_THEMES) {
    if (t.keys.some((k) => n.includes(k))) {
      return themeFromColors(t.colors, t.name);
    }
  }
  return null;
}

/** Nivel 4: color determinista por hash del nombre del artista. */
function themeFromArtist(artist) {
  const h = hashStr(norm(artist) || 'artista desconocido');
  const hue = h % 360;
  const hue2 = (hue + 25 + ((h >>> 4) % 110)) % 360;
  const sat = 42 + ((h >>> 8) % 26);        // 42–67 %
  const l1 = 18 + ((h >>> 12) % 12);        // 18–29 % (fondo oscuro, texto claro)
  const l2 = l1 + 10 + ((h >>> 16) % 8);
  return {
    type: 'artist',
    source: 'artist',
    gradient: `linear-gradient(135deg, hsl(${hue} ${sat}% ${l1}%), hsl(${hue2} ${Math.min(sat + 14, 80)}% ${l2}%))`,
    textColor: '#f5f7fb',
    accent: `hsl(${hue} 75% 62%)`,
    accentContrast: '#141821',
    swatch: `hsl(${hue} ${sat}% ${l1 + 6}%)`,
  };
}

/**
 * getThemeForSong(song) → tema visual de una canción.
   Implementa la cadena de prioridad completa. `song.palette` es la paleta
   [[r,g,b], …] extraída de la portada (nivel 1); llega de forma asíncrona.
 */
function getThemeForSong(song) {
  // Nivel 1: portada del álbum
  if (song && Array.isArray(song.palette) && song.palette.length >= 2) {
    const colors = song.palette.slice(0, 3).map(rgbToHex);
    const theme = themeFromColors(colors, 'cover');
    theme.source = 'cover';
    return theme;
  }
  // Nivel 2: nombre de la carpeta ("Music/Rock/..." → rock)
  if (song && song.folder) {
    const t = themeFromKeywords(song.folder);
    if (t) return t;
  }
  // Nivel 3: género de la etiqueta ID3
  if (song && song.genre) {
    const t = themeFromKeywords(song.genre);
    if (t) return t;
  }
  // Nivel 4: artista → color determinista
  if (song && song.artist) {
    return themeFromArtist(song.artist);
  }
  // Nivel 5: tema neutro
  return { ...DEFAULT_THEME };
}

/* ----------------------------------------------------------------------------
   Aplicación visual del tema: fundido cruzado entre dos capas de fondo.
   La capa invisible recibe el nuevo degradado y entonces se intercambian
   las opacidades → transición suave de 1,5 s sin cortes.
   ---------------------------------------------------------------------------- */
let bgFlip = false;

function applyTheme(theme) {
  const layerIn = bgFlip ? $('#bg-a') : $('#bg-b');
  const layerOut = bgFlip ? $('#bg-b') : $('#bg-a');
  bgFlip = !bgFlip;

  if (layerIn && layerOut) {
    layerIn.style.backgroundImage = theme.gradient;
    layerIn.style.backgroundSize = '200% 200%';
    // Double rAF: garantiza que el navegador pinte el nuevo degradado antes
    // de iniciar la transición de opacidad.
    requestAnimationFrame(() => requestAnimationFrame(() => {
      layerIn.classList.add('is-visible');
      layerOut.classList.remove('is-visible');
    }));
  }

  // Color de acento + contraste del acento (botones principales)
  const rootStyle = document.documentElement.style;
  rootStyle.setProperty('--accent', theme.accent);
  rootStyle.setProperty('--accent-contrast', theme.accentContrast);

  // Polaridad del texto según la luminosidad del tema
  document.body.dataset.themeContrast =
    (theme.textColor === '#171d29' || theme.textColor === '#1b2230') ? 'dark-text' : 'light-text';

  // Color de la barra del navegador/PWA
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', theme.swatch || DEFAULT_THEME.swatch);
}

/** Tema de la canción actual (o neutro si no hay ninguna). */
function applyThemeForCurrent() {
  const song = currentSong();
  applyTheme(getThemeForSong(song));
}

/* ============================================================================
   5. BIBLIOTECA — carga desde carpeta o archivos
   ============================================================================ */

/** Crea el objeto Song a partir de un File y su ruta relativa. */
function makeSong(file, relPath) {
  const folder = relPath.includes('/') ? relPath.slice(0, relPath.lastIndexOf('/')) : '';
  return {
    id: relPath,                 // identidad estable entre re-lecturas
    relPath,
    folder,
    file,
    size: file.size,
    mtime: file.lastModified,
    title: prettyTitle(file.name),
    artist: '',
    album: '',
    genre: '',
    url: null,                   // URL de objeto (se crea al reproducir)
    coverBlob: null,             // portada original (transitoria)
    coverURL: null,              // miniatura 300 px para la interfaz
    palette: null,               // [[r,g,b]…] de ColorThief (nivel 1 del tema)
    duration: NaN,
    metaDone: false,
  };
}

const currentSong = () => (state.currentIndex >= 0 ? state.songs[state.currentIndex] : null);
const isCurrent = (song) => song && state.currentIndex >= 0 && state.songs[state.currentIndex] === song;

/** Carpeta de primer nivel ("Music/Rock/x.mp3" → "Rock") para el filtro. */
function topFolder(song) {
  const parts = song.relPath.split('/');
  return parts.length > 1 ? parts[0] : '(raíz)';
}

/* ----------------------- Nivel A: File System Access ---------------------- */

const FSA_SUPPORTED = 'showDirectoryPicker' in window;

/** Pide una carpeta nueva con permiso persistente y la guarda en IndexedDB. */
async function pickFolderFSA() {
  if (!FSA_SUPPORTED) return;
  let handle;
  try {
    handle = await window.showDirectoryPicker({ id: 'aura-music', mode: 'read', startIn: 'music' });
  } catch (err) {
    if (err instanceof TypeError) {
      handle = await window.showDirectoryPicker();          // opciones no soportadas
    } else if (err && err.name === 'AbortError') {
      return;                                                // el usuario canceló
    } else {
      throw err;
    }
  }
  await idbSet('musicDir', handle);
  state.source = { type: 'fsa', handle, rootName: handle.name };
  hideReconnect();
  await rescanLibrary(true);
}

/**
 * Al arrancar: si hay una carpeta guardada y el permiso sigue concedido
 * (PWA instalada), la biblioteca se relee sola. Si el permiso venció,
 * mostramos el botón "Reconectar" (el navegador exige un gesto del usuario).
 */
async function tryAutoReconnect() {
  if (!FSA_SUPPORTED) return;
  const handle = await idbGet('musicDir');
  if (!handle) return;
  try {
    const perm = await handle.queryPermission({ mode: 'read' });
    if (perm === 'granted') {
      state.source = { type: 'fsa', handle, rootName: handle.name };
      await rescanLibrary(true);
    } else {
      state.pendingHandle = handle;
      showReconnect(handle.name);
    }
  } catch { /* handle inválido (carpeta borrada): se ignora */ }
}

function showReconnect(name) {
  const btn = $('#btn-reconnect');
  $('#reconnect-label').textContent = `Reconectar «${name}»`;
  btn.classList.remove('hidden');
}

function hideReconnect() {
  $('#btn-reconnect').classList.add('hidden');
  state.pendingHandle = null;
}

async function reconnectFSA() {
  const handle = state.pendingHandle || await idbGet('musicDir');
  if (!handle) { hideReconnect(); return; }
  try {
    const perm = await handle.requestPermission({ mode: 'read' });
    if (perm === 'granted') {
      state.pendingHandle = null;
      state.source = { type: 'fsa', handle, rootName: handle.name };
      hideReconnect();
      await rescanLibrary(true);
    } else {
      toast('Permiso denegado. Toca de nuevo «Reconectar» cuando quieras.');
    }
  } catch { toast('No se pudo pedir permiso para la carpeta.'); }
}

/* Directorios del sistema que no vale la pena recorrer. */
const SKIP_DIRS = new Set(['android', '.thumbnails', '.trash', '.trash-1000', 'alarms', 'notifications', 'ringtones']);

/**
 * Recorre recursivamente un directorio (máx. 8 niveles) y junta todos los
 * archivos de audio con su ruta relativa. Los ocultos se omiten.
 */
async function walkDir(dirHandle, prefix, out, depth) {
  if (depth > 8 || !dirHandle.values) {
    throw new Error('Este navegador no permite leer el contenido de la carpeta.');
  }
  for await (const entry of dirHandle.values()) {
    if (entry.name.startsWith('.')) continue;
    if (entry.kind === 'directory') {
      if (SKIP_DIRS.has(norm(entry.name))) continue;
      await walkDir(entry, prefix + entry.name + '/', out, depth + 1);
    } else if (entry.kind === 'file' && AUDIO_EXT.has(extOf(entry.name))) {
      out.push({ relPath: prefix + entry.name, handle: entry });
    }
  }
}

/**
 * Relee la carpeta conectada (nivel A). Se usa:
   - al conectar/reconectar,
   - automáticamente en cada apertura con permiso concedido,
   - al volver a la app si pasaron >30 s (visibilitychange),
   - en tiempo real si existe FileSystemObserver (API experimental).
 */
async function rescanLibrary(first) {
  if (!state.source || state.source.type !== 'fsa' || state.rescanning) return;
  state.rescanning = true;
  try {
    const found = [];
    await walkDir(state.source.handle, '', found, 0);

    const entries = [];
    for (const f of found) {
      try {
        const file = await f.handle.getFile();   // lazy: no lee el contenido aún
        entries.push({ relPath: f.relPath, file });
      } catch { /* archivo inaccesible: se omite */ }
    }
    const stats = mergeLibrary(entries);
    state.lastScan = Date.now();
    attachObserver();
    if (!first) reportChanges(stats);
  } catch (err) {
    toast('No se pudo leer la carpeta: ' + (err && err.message ? err.message : 'error'));
  } finally {
    state.rescanning = false;
  }
}

/** FileSystemObserver: relectura en vivo si el navegador lo soporta. */
function attachObserver() {
  try {
    if (typeof FileSystemObserver === 'undefined' || !state.source || state.source.type !== 'fsa') return;
    if (state.fsObserver) { try { state.fsObserver.disconnect(); } catch { /* ignore */ } }
    state.fsObserver = new FileSystemObserver(throttleRescan);
    state.fsObserver.observe(state.source.handle, { recursive: true });
  } catch { /* API experimental: el botón "Actualizar" sigue disponible */ }
}

const throttleRescan = debounce(() => {
  if (Date.now() - state.lastScan > 3000) rescanLibrary(false);
}, 1500);

/* ------------------ Nivel B/C: <input> (carpeta o archivos) --------------- */

async function handleInputChange(input, fromDirectory) {
  const files = [...input.files];
  input.value = '';                      // permite re-elegir la misma carpeta
  if (!files.length) return;

  const entries = [];
  let rootName = fromDirectory ? 'Carpeta' : 'Archivos';
  for (const f of files) {
    if (!AUDIO_EXT.has(extOf(f.name))) continue;
    const rel = fromDirectory && f.webkitRelativePath ? f.webkitRelativePath : f.name;
    entries.push({ relPath: rel, file: f });
  }
  if (!entries.length) {
    toast('No se encontró música compatible (MP3, M4A, OGG, OPUS, WAV, FLAC).');
    return;
  }
  // Nombre de la carpeta raíz ("Music/Rock/x.mp3" → "Music")
  const first = entries[0].relPath;
  if (first.includes('/')) rootName = first.slice(0, first.indexOf('/'));

  state.source = { type: 'input', rootName };
  mergeLibrary(entries);
  state.lastScan = Date.now();
  startMetaQueue();
  updateChip();
}

/* --------------------------- Fusión de resultados -------------------------- */

/**
 * Une los archivos leídos con la biblioteca actual, conservando metadatos de
 * canciones que no cambiaron (mismo tamaño y fecha) y conservando la canción
 * en reproducción aunque se hayan eliminado archivos.
 */
function mergeLibrary(entries) {
  const byPath = new Map(entries.map((e) => [e.relPath, e]));
  const prev = new Map(state.songs.map((s) => [s.id, s]));
  const next = [];
  let added = 0, changed = 0, removed = 0;

  for (const [relPath, e] of byPath) {
    const old = prev.get(relPath);
    if (old && old.size === e.file.size && old.mtime === e.file.lastModified) {
      old.file = e.file;                 // refresco la referencia al archivo
      next.push(old);
    } else {
      if (old) changed++;
      else added++;
      next.push(makeSong(e.file, relPath));
    }
  }

  // Limpieza de canciones que ya no existen
  const nextPaths = new Set(next.map((s) => s.id));
  for (const s of state.songs) {
    if (!nextPaths.has(s.id)) {
      removed++;
      if (s.coverURL) { try { URL.revokeObjectURL(s.coverURL); } catch { /* ignore */ } }
      if (s.url && !isCurrent(s)) { try { URL.revokeObjectURL(s.url); } catch { /* ignore */ } }
    }
  }

  // Orden natural: alfabético por ruta (≈ orden de carpetas)
  next.sort((a, b) => a.relPath.localeCompare(b.relPath, 'es', { numeric: true }));

  const hadSongs = state.songs.length > 0;
  state.songs = next;

  // Poda de posiciones guardadas que ya no existen
  const pos = settings.positions;
  for (const k of Object.keys(pos)) if (!nextPaths.has(k)) delete pos[k];

  refreshFolderFilter();
  computeView();
  renderList();
  updateChip();
  startMetaQueue();

  if (state.currentIndex < 0 || !state.songs[state.currentIndex]) {
    restoreLastSong();
  }

  if (!hadSongs && next.length) {
    document.body.dataset.screen = 'library';
    $('#view-start').hidden = true;
    $('#view-library').hidden = false;
    toast(`${next.length} ${next.length === 1 ? 'canción cargada' : 'canciones cargadas'}. ¡A escuchar!`);
  }

  return { added, changed, removed, total: next.length };
}

function reportChanges(stats) {
  if (!stats) return;
  const parts = [];
  if (stats.added) parts.push(`+${stats.added} ${stats.added === 1 ? 'nueva' : 'nuevas'}`);
  if (stats.removed) parts.push(`−${stats.removed} ${stats.removed === 1 ? 'quitada' : 'quitadas'}`);
  if (stats.changed) parts.push(`${stats.changed} ${stats.changed === 1 ? 'cambiada' : 'cambiadas'}`);
  const msg = parts.length
    ? `Biblioteca actualizada: ${parts.join(' · ')}`
    : 'Biblioteca actualizada, sin cambios';
  toast(msg);
  announce(msg);
}

/* ============================================================================
   6. COLA DE METADATOS — concurrencia máx. 5, sin bloquear la interfaz
   Cada trabajo lee: etiquetas ID3 → portada (miniatura 300 px + paleta)
   → duración aproximada. Los resultados se aplican a las filas en pantalla.
   ============================================================================ */

/** Encola metadatos de una canción. priority=true la pone al frente de la cola. */
function queueMeta(song, priority) {
  if (!song || song.metaDone || song.metaQueued) return;
  song.metaQueued = true;
  state.metaQueue.push(song);
  if (priority) {
    const i = state.metaQueue.indexOf(song);
    if (i >= 0) {
      state.metaQueue.splice(i, 1);
      state.metaQueue.unshift(song);
    }
  }
  pumpMeta();
}

/** Encola todas las canciones pendientes de metadatos (tras cargar biblioteca). */
function startMetaQueue() {
  for (const s of state.songs) {
    if (!s.metaDone && !s.metaQueued) {
      s.metaQueued = true;
      state.metaQueue.push(s);
    }
  }
  pumpMeta();
}

function pumpMeta() {
  while (state.metaActive < META_CONCURRENCY && state.metaQueue.length) {
    state.metaActive++;
    runMetaJob(state.metaQueue.shift())
      .catch(() => {})
      .finally(() => { state.metaActive--; pumpMeta(); });
  }
}

async function runMetaJob(song) {
  await ensureLibs();          // garantiza jsmediatags/ColorThief (locales o CDN)
  await readTags(song);
  await extractCover(song);
  await probeDuration(song);
  song.metaDone = true;
  updateRow(song);
  if (isCurrent(song)) {
    refreshNowUI(song);
    applyThemeForCurrent();     // la canción puede "subir" al nivel 1 (portada)
    updateMediaSession();
  }
}

/** Etiquetas ID3v1/ID3v2, MP4 y FLAC con jsmediatags (con tiempo límite). */
function readTags(song) {
  return new Promise((resolve) => {
    if (!window.jsmediatags) return resolve();
    let settled = false;
    const done = () => { if (!settled) { settled = true; resolve(); } };
    const timer = setTimeout(done, 10000);
    try {
      window.jsmediatags.read(song.file, {
        onSuccess: (result) => {
          clearTimeout(timer);
          const tags = result && result.tags ? result.tags : {};
          if (tags.title) song.title = String(tags.title).trim() || song.title;
          if (tags.artist) song.artist = String(tags.artist).trim();
          if (tags.album) song.album = String(tags.album).trim();
          if (tags.genre) song.genre = String(tags.genre).trim();
          if (tags.picture && tags.picture.data && tags.picture.data.length) {
            try {
              song.coverBlob = new Blob([new Uint8Array(tags.picture.data)], {
                type: tags.picture.format || 'image/jpeg',
              });
            } catch { /* portada ilegible */ }
          }
          done();
        },
        onError: () => { clearTimeout(timer); done(); },
      });
    } catch { clearTimeout(timer); done(); }
  });
}

/**
 * Portada: recorta a cuadrado, reduce a 300×300 JPEG (memoria) y extrae la
 * paleta de 3 colores con ColorThief — base del nivel 1 del motor de temas.
 */
async function extractCover(song) {
  if (!song.coverBlob) return;
  const fullURL = URL.createObjectURL(song.coverBlob);
  try {
    const img = await loadImage(fullURL);
    if (img.naturalWidth < 24 || img.naturalHeight < 24) return;

    // La miniatura se crea siempre que haya portada (así la lista muestra arte
    // aunque ColorThief no esté disponible).
    song.coverURL = await makeThumb(img, 300);

    // Paleta de 3 colores → nivel 1 del motor de temas.
    if (window.ColorThief) {
      try {
        const thumbImg = await loadImage(song.coverURL);
        const palette = new window.ColorThief().getPalette(thumbImg, 3, 5);
        song.palette = Array.isArray(palette) && palette.length >= 2 ? palette : null;
      } catch { song.palette = null; }
    }
  } catch { /* sin portada: el tema saldrá de carpeta/género/artista */ }
  finally {
    URL.revokeObjectURL(fullURL);
    song.coverBlob = null;
  }
}

/** Recorta al centro y escala la portada a size×size JPEG. */
function makeThumb(img, size) {
  return new Promise((resolve, reject) => {
    try {
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = size;
      const ctx = canvas.getContext('2d');
      const side = Math.min(img.naturalWidth, img.naturalHeight);
      ctx.drawImage(
        img,
        (img.naturalWidth - side) / 2, (img.naturalHeight - side) / 2, side, side,
        0, 0, size, size
      );
      canvas.toBlob(
        (blob) => (blob ? resolve(URL.createObjectURL(blob)) : reject(new Error('toBlob falló'))),
        'image/jpeg', 0.85
      );
    } catch (err) { reject(err); }
  });
}

/** Duración: se lee solo la cabecera (preload=metadata), sin decodificar todo. */
function probeDuration(song) {
  return new Promise((resolve) => {
    if (isFinite(song.duration)) return resolve();
    const a = new Audio();
    a.preload = 'metadata';
    const ownURL = !song.url ? URL.createObjectURL(song.file) : null;
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      a.removeAttribute('src');
      a.load();
      if (ownURL) URL.revokeObjectURL(ownURL);
      resolve();
    };
    const timer = setTimeout(done, 8000);
    a.onloadedmetadata = () => { if (isFinite(a.duration)) song.duration = a.duration; done(); };
    a.onerror = done;
    a.src = song.url || ownURL;
  });
}

/* ============================================================================
   6b. CARGA TARDÍA DE LIBRERÍAS (respaldo por CDN si faltan las locales)
   jsmediatags — https://github.com/aadsm/jsmediatags (licencia MIT)
   ColorThief   — https://github.com/lokesh/color-thief (licencia MIT)
   ============================================================================ */

const CDN = {
  jsmediatags: 'https://cdn.jsdelivr.net/gh/aadsm/jsmediatags@master/dist/jsmediatags.min.js',
  colorthief: 'https://cdn.jsdelivr.net/npm/colorthief@2.3.2/dist/color-thief.umd.js',
};

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = src;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error('No se pudo cargar ' + src));
    document.head.appendChild(s);
  });
}

let ensurePromise = null;
/** Garantiza que existan window.jsmediatags y window.ColorThief (8 s máx.). */
function ensureLibs() {
  if (!ensurePromise) {
    ensurePromise = (async () => {
      const jobs = [];
      if (!window.jsmediatags) jobs.push(loadScript(CDN.jsmediatags).catch(() => {}));
      if (!window.ColorThief) jobs.push(loadScript(CDN.colorthief).catch(() => {}));
      if (jobs.length) {
        // Sin internet la app sigue funcionando: solo se pierden etiquetas/paleta
        await Promise.race([Promise.allSettled(jobs), new Promise((r) => setTimeout(r, 8000))]);
      }
    })();
  }
  return ensurePromise;
}

/* ============================================================================
   7. REPRODUCCIÓN — HTMLAudioElement + orden + aleatorio + repetición
   ============================================================================ */

const audio = new Audio();
audio.preload = 'auto';
audio.volume = Math.max(0, Math.min(1, Number(settings.volume) || 0.9));
document.body.classList.add('paused');

let resumePending = 0;    // posición pendiente de restaurar (metadata no lista aún)
let seeking = false;      // el usuario está arrastrando la barra de progreso
let lastVolume = 1;       // para recuperar el volumen al quitar el silencio

state.pendingResume = 0;  // posición guardada de la última sesión (al restaurar)

function attemptPlay() {
  audio.play().catch((err) => {
    if (err && err.name === 'NotAllowedError') {
      toast('Toca el botón de reproducir para empezar.');
    }
  });
}

/**
 * Secuencia de reproducción: si la canción actual está en la vista filtrada,
 * se avanza dentro de esa vista; si no, dentro de toda la biblioteca.
 */
function currentSeq() {
  if (state.view.length && (state.currentIndex === -1 || state.view.includes(state.currentIndex))) {
    return state.view;
  }
  return state.songs.map((_, i) => i);
}

/** Baraja (Fisher–Yates) los índices excepto el actual. */
function shuffledBag(exclude) {
  const bag = state.songs.map((_, i) => i).filter((i) => i !== exclude);
  for (let i = bag.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [bag[i], bag[j]] = [bag[j], bag[i]];
  }
  return bag;
}

/** Siguiente índice. auto=true cuando la canción terminó sola (respeta repeat). */
function nextIndex(auto) {
  const seq = currentSeq();
  if (!seq.length) return -1;
  if (state.shuffle) {
    if (!state.bag.length) {
      if (auto && state.repeat !== 'all') return -1;   // fin del ciclo aleatorio
      state.bag = shuffledBag(state.currentIndex);
    }
    return state.bag.pop();
  }
  const pos = seq.indexOf(state.currentIndex);
  if (pos === -1) return seq[0];
  if (pos + 1 < seq.length) return seq[pos + 1];
  return (state.repeat === 'all' || !auto) ? seq[0] : -1;
}

function prevIndex() {
  const seq = currentSeq();
  if (!seq.length) return -1;
  if (state.shuffle && state.history.length) return state.history.pop();
  const pos = seq.indexOf(state.currentIndex);
  if (pos === -1) return seq[0];
  return seq[(pos - 1 + seq.length) % seq.length];
}

function next(manual = true) {
  if (state.currentIndex >= 0) {
    state.history.push(state.currentIndex);            // para "atrás" en aleatorio
    if (state.history.length > 120) state.history.shift();
  }
  const i = nextIndex(!manual);
  if (i < 0 || i >= state.songs.length) {             // fin de la lista
    audio.pause();
    try { audio.currentTime = 0; } catch { /* ignore */ }
    return;
  }
  playIndex(i);
}

function prev() {
  // Como Spotify: si llevas más de 3 s escuchando, la canción vuelve a empezar
  if (audio.currentTime > 3 && isFinite(audio.currentTime)) {
    audio.currentTime = 0;
    return;
  }
  const i = prevIndex();
  if (i >= 0) playIndex(i);
}

/**
 * Carga y reproduce una canción.
 * @param {number} index  índice en state.songs
 * @param {object} opts   { autoplay=true, resume=0 }  resume en segundos
 */
function playIndex(index, { autoplay = true, resume = 0 } = {}) {
  const song = state.songs[index];
  if (!song) return;

  const sameSong = index === state.currentIndex && !!audio.src;
  state.currentIndex = index;
  state.pendingResume = 0;
  state.errorStreak = 0;
  settings.lastPath = song.id;
  saveSettings();

  if (!sameSong) {
    if (!song.url) song.url = URL.createObjectURL(song.file);
    resumePending = resume > 0 ? resume : 0;
    audio.src = song.url;
  } else if (resume > 0) {
    if (audio.readyState >= 1) { try { audio.currentTime = resume; } catch { /* ignore */ } }
    else resumePending = resume;
  }

  if (autoplay) attemptPlay();

  queueMeta(song, true);            // sus metadatos pasan al frente de la cola
  refreshNowUI(song);
  applyThemeForCurrent();           // ← aquí cambia el "aura" de la canción
  updateMediaSession();
  markActiveRow();
  announce(`Reproduciendo ${song.title}, de ${song.artist || 'artista desconocido'}`);
}

function togglePlay() {
  const song = currentSong();
  if (!song) {
    const seq = currentSeq();
    if (seq.length) playIndex(seq[0]);
    return;
  }
  if (audio.paused) {
    if (!audio.src) playIndex(state.currentIndex, { autoplay: true, resume: state.pendingResume || 0 });
    else attemptPlay();
  } else {
    audio.pause();
  }
}

function stopAtEnd() {
  audio.pause();
  try { audio.currentTime = 0; } catch { /* ignore */ }
}

/* --------------------------- Eventos del <audio> -------------------------- */

audio.addEventListener('loadedmetadata', () => {
  if (resumePending > 0) {
    try { audio.currentTime = Math.min(resumePending, Math.max(0, (audio.duration || 0) - 1)); } catch { /* ignore */ }
    resumePending = 0;
  }
  $('#time-total').textContent = fmtTime(audio.duration);
  const song = currentSong();
  if (song && isFinite(audio.duration) && !isFinite(song.duration)) {
    song.duration = audio.duration;
    updateRow(song);
  }
});

audio.addEventListener('durationchange', () => {
  $('#time-total').textContent = fmtTime(audio.duration);
});

audio.addEventListener('play', syncPlayIcons);
audio.addEventListener('pause', syncPlayIcons);

audio.addEventListener('ended', () => {
  if (state.repeat === 'one') {
    audio.currentTime = 0;
    attemptPlay();
    return;
  }
  next(false);
});

audio.addEventListener('error', () => {
  const song = currentSong();
  if (!song || !audio.error) return;
  state.errorStreak++;
  if (state.errorStreak >= 5) {
    toast('Varios archivos seguidos no se pueden reproducir; se detuvo la reproducción.');
    return;
  }
  toast(`No se puede reproducir «${song.title}». ¿El formato es compatible?`);
  setTimeout(() => next(false), 900);
});

let progressRaf = false;
let lastPosSave = 0;

audio.addEventListener('timeupdate', () => {
  if (!progressRaf) {
    progressRaf = true;
    requestAnimationFrame(() => { progressRaf = false; renderProgress(); });
  }
  const song = currentSong();
  if (song && isFinite(audio.duration) && audio.duration > 0 &&
      audio.currentTime > 3 && audio.currentTime < audio.duration - 2) {
    const now = Date.now();
    if (now - lastPosSave > 4000) {                  // guardar posición cada 4 s
      settings.positions[song.id] = audio.currentTime;
      lastPosSave = now;
      saveSettings();
    }
  }
});

function renderProgress() {
  const dur = audio.duration;
  const cur = audio.currentTime || 0;
  if (!seeking) {
    $('#seek').value = isFinite(dur) && dur > 0 ? String(Math.round((cur / dur) * 1000)) : '0';
    $('#time-cur').textContent = fmtTime(cur);
  }
  $('#mini-progress-fill').style.width =
    isFinite(dur) && dur > 0 ? `${(cur / dur) * 100}%` : '0%';
  updatePositionState();
}

function seekBy(delta) {
  if (!isFinite(audio.duration) || audio.duration <= 0) return;
  audio.currentTime = Math.max(0, Math.min(audio.duration, audio.currentTime + delta));
}

/* ============================================================================
   8. MEDIA SESSION API — controles en la barra de notificaciones
   Disponible en Chrome Android cuando la pestaña/PWA está activa.
   ============================================================================ */

function updateMediaSession() {
  if (!('mediaSession' in navigator)) return;
  const song = currentSong();
  if (!song) return;
  try {
    navigator.mediaSession.metadata = new window.MediaMetadata({
      title: song.title,
      artist: song.artist || 'Artista desconocido',
      album: song.album || '',
      artwork: [song.coverURL
        ? { src: song.coverURL, sizes: '300x300', type: 'image/jpeg' }
        : { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' }],
    });
  } catch { /* algunos WebViews no implementan MediaMetadata */ }
}

function updatePositionState() {
  if (!('mediaSession' in navigator) || !navigator.mediaSession.setPositionState) return;
  try {
    if (isFinite(audio.duration) && audio.duration > 0) {
      navigator.mediaSession.setPositionState({
        duration: audio.duration,
        playbackRate: audio.playbackRate || 1,
        position: Math.min(audio.currentTime, audio.duration),
      });
    }
  } catch { /* ignore */ }
}

function bindMediaSession() {
  if (!('mediaSession' in navigator)) return;
  const set = (action, handler) => {
    try { navigator.mediaSession.setActionHandler(action, handler); } catch { /* no soportada */ }
  };
  set('play', () => { if (!audio.src) togglePlay(); else attemptPlay(); });
  set('pause', () => audio.pause());
  set('previoustrack', () => prev());
  set('nexttrack', () => next(true));
  set('stop', () => stopAtEnd());
  set('seekto', (d) => { if (d && d.seekTime != null && isFinite(d.seekTime)) audio.currentTime = d.seekTime; });
  set('seekbackward', (d) => seekBy(-((d && d.seekOffset) || 10)));
  set('seekforward', (d) => seekBy((d && d.seekOffset) || 10));
}

/* ============================================================================
   9. INTERFAZ — lista paginada, búsqueda, filtros, mini y full player
   ============================================================================ */

const PAGE = 80;   // filas por lote (bibliotecas grandes sin bloquear la UI)

function sub(song) {
  return [song.artist || 'Artista desconocido', song.album].filter(Boolean).join(' · ');
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

/** Vista = buscar + filtrar + ordenar. Trabaja con índices de state.songs. */
function computeView() {
  const q = norm(state.query).trim();
  let idx = state.songs.map((_, i) => i);

  if (state.folderFilter !== 'all') {
    idx = idx.filter((i) => topFolder(state.songs[i]) === state.folderFilter);
  }
  if (q) {
    idx = idx.filter((i) => {
      const s = state.songs[i];
      return norm(s.title).includes(q) || norm(s.artist).includes(q) || norm(s.album).includes(q);
    });
  }

  const byPath = (a, b) => state.songs[a].relPath.localeCompare(state.songs[b].relPath, 'es', { numeric: true });
  const byTitle = (a, b) => norm(state.songs[a].title).localeCompare(norm(state.songs[b].title), 'es', { numeric: true }) || byPath(a, b);
  const cmp = {
    added: byPath,
    title: byTitle,
    artist: (a, b) => (norm(state.songs[a].artist) || 'zzz').localeCompare(norm(state.songs[b].artist) || 'zzz', 'es') || byTitle(a, b),
    album: (a, b) => (norm(state.songs[a].album) || 'zzz').localeCompare(norm(state.songs[b].album) || 'zzz', 'es') || byTitle(a, b),
  };
  idx.sort(cmp[state.sortMode] || cmp.added);
  state.view = idx;
}

function renderList() {
  const list = $('#song-list');
  list.innerHTML = '';
  state.rowEls.clear();
  state.rendered = 0;
  $('#empty-note').hidden = !(state.view.length === 0 && state.songs.length > 0);
  renderMore();
}

function renderMore(count = PAGE) {
  const list = $('#song-list');
  const frag = document.createDocumentFragment();
  const end = Math.min(state.view.length, state.rendered + count);
  for (; state.rendered < end; state.rendered++) {
    const idx = state.view[state.rendered];
    const song = state.songs[idx];
    const row = makeRow(song, idx);
    state.rowEls.set(song.id, row);
    frag.appendChild(row);
  }
  list.appendChild(frag);
  markActiveRow();
}

function makeRow(song, idx) {
  const li = document.createElement('li');
  li.className = 'song-row';
  li.setAttribute('role', 'button');
  li.setAttribute('tabindex', '0');
  li.dataset.id = song.id;
  li.innerHTML = `
    <span class="row-thumb">${song.coverURL ? `<img src="${esc(song.coverURL)}" alt="">`
      : '<svg class="ic" aria-hidden="true"><use href="#i-note"/></svg>'}</span>
    <span class="row-tx">
      <span class="row-title"></span>
      <span class="row-sub"></span>
    </span>
    <span class="row-end">
      <span class="eq" aria-hidden="true"><span></span><span></span><span></span></span>
      <span class="row-dur"></span>
    </span>`;
  li.querySelector('.row-title').textContent = song.title;
  li.querySelector('.row-sub').textContent = sub(song);
  li.querySelector('.row-dur').textContent = isFinite(song.duration) ? fmtTime(song.duration) : '–:––';

  const activate = () => {
    if (isCurrent(song)) togglePlay();     // tocar la canción activa = pausar/seguir
    else playIndex(idx);
  };
  li.addEventListener('click', activate);
  li.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); activate(); }
  });
  return li;
}

/** Actualiza una fila en sitio cuando llegan metadatos (sin re-pintar la lista). */
function updateRow(song) {
  const row = state.rowEls.get(song.id);
  if (!row) return;
  const t = row.querySelector('.row-title');
  if (t.textContent !== song.title) t.textContent = song.title;
  const s = row.querySelector('.row-sub');
  const subText = sub(song);
  if (s.textContent !== subText) s.textContent = subText;
  const d = row.querySelector('.row-dur');
  const durText = isFinite(song.duration) ? fmtTime(song.duration) : '–:––';
  if (d.textContent !== durText) d.textContent = durText;
  if (song.coverURL && !row.querySelector('.row-thumb img')) {
    row.querySelector('.row-thumb').innerHTML = `<img src="${esc(song.coverURL)}" alt="">`;
  }
}

function markActiveRow() {
  const cur = currentSong();
  for (const [, el] of state.rowEls) {
    const active = !!(cur && el.dataset.id === cur.id);
    el.classList.toggle('active', active);
    if (active) el.setAttribute('aria-current', 'true');
    else el.removeAttribute('aria-current');
  }
}

function setCover(el, song, iconClass) {
  if (song && song.coverURL) {
    el.innerHTML = '';
    const img = document.createElement('img');
    img.src = song.coverURL;
    img.alt = '';
    el.appendChild(img);
  } else {
    el.innerHTML = `<svg class="${iconClass || 'ic'}" aria-hidden="true"><use href="#i-note"/></svg>`;
  }
}

/** Sincroniza mini reproductor + reproductor completo con la canción actual. */
function refreshNowUI(song) {
  if (!song) return;
  $('#mini-title').textContent = song.title;
  $('#mini-artist').textContent = song.artist || 'Artista desconocido';
  setCover($('#mini-cover'), song, 'ic');
  $('#player-title').textContent = song.title;
  $('#player-sub').textContent = sub(song);
  setCover($('#player-cover'), song, 'ic ic-xl');
  $('#mini-player').hidden = false;

  const dur = (audio.src && isFinite(audio.duration)) ? audio.duration : song.duration;
  $('#time-total').textContent = fmtTime(dur);
  if (!audio.src) {
    $('#time-cur').textContent = fmtTime(state.pendingResume || 0);
    $('#seek').value = '0';
  }
}

/** Restaura la última canción de la sesión anterior (en pausa, en su posición). */
function restoreLastSong() {
  if (state.currentIndex >= 0 && state.songs[state.currentIndex]) return;
  const path = settings.lastPath;
  if (!path) return;
  const idx = state.songs.findIndex((s) => s.id === path);
  if (idx < 0) return;
  state.currentIndex = idx;
  state.pendingResume = Math.max(0, settings.positions[path] || 0);
  refreshNowUI(state.songs[idx]);
  applyThemeForCurrent();
  updateMediaSession();
  markActiveRow();
  queueMeta(state.songs[idx], true);
}

/* ------------------------------ Toolbar ---------------------------------- */

function refreshFolderFilter() {
  const sel = $('#select-folder');
  const folders = [...new Set(state.songs.map(topFolder))].sort((a, b) => a.localeCompare(b, 'es'));
  const current = state.folderFilter;
  sel.innerHTML = '<option value="all">Todas las carpetas</option>' +
    folders.map((f) => `<option value="${esc(f)}">${esc(f)}</option>`).join('');
  if (folders.includes(current)) sel.value = current;
  else { state.folderFilter = 'all'; sel.value = 'all'; }
}

function updateChip() {
  if (!state.source) return;
  $('#source-name').textContent = state.source.rootName || 'Carpeta';
  const n = state.songs.length;
  $('#source-count').textContent = `${n} ${n === 1 ? 'canción' : 'canciones'}`;
}

/* --------------------- Controles de transporte ---------------------------- */

function toggleShuffle() {
  state.shuffle = !state.shuffle;
  settings.shuffle = state.shuffle;
  saveSettings();
  state.bag = [];
  syncTransportUI();
  toast(state.shuffle ? 'Aleatorio: activado' : 'Aleatorio: desactivado', 1400);
}

function cycleRepeat() {
  state.repeat = state.repeat === 'off' ? 'all' : (state.repeat === 'all' ? 'one' : 'off');
  settings.repeat = state.repeat;
  saveSettings();
  syncTransportUI();
  toast({ off: 'Repetición: desactivada', all: 'Repetir: todas las canciones', one: 'Repetir: esta canción' }[state.repeat], 1500);
}

function syncTransportUI() {
  $('#btn-shuffle').setAttribute('aria-pressed', String(state.shuffle));
  const rep = $('#btn-repeat');
  rep.setAttribute('aria-pressed', String(state.repeat !== 'off'));
  const r1 = rep.querySelector('.r1');
  if (r1) r1.hidden = state.repeat !== 'one';
  $('#vol').value = String(Math.round(audio.volume * 100));
  syncMuteIcon();
}

function syncPlayIcons() {
  const playing = !audio.paused && !audio.ended;
  const href = playing ? '#i-pause' : '#i-play';
  const big = $('#play-ic use'), mini = $('#mini-play-ic use');
  if (big) big.setAttribute('href', href);
  if (mini) mini.setAttribute('href', href);
  document.body.classList.toggle('paused', !playing);
  if ('mediaSession' in navigator) {
    try { navigator.mediaSession.playbackState = playing ? 'playing' : 'paused'; } catch { /* ignore */ }
  }
}

function setVolume(v) {
  const nv = Math.max(0, Math.min(1, v));
  audio.volume = nv;
  settings.volume = nv;
  saveSettings();
  if (nv > 0) lastVolume = nv;
  $('#vol').value = String(Math.round(nv * 100));
  syncMuteIcon();
}

function toggleMute() {
  if (audio.volume > 0) setVolume(0);
  else setVolume(lastVolume || 0.9);
}

function syncMuteIcon() {
  const use = $('#mute-ic use');
  if (use) use.setAttribute('href', audio.volume <= 0.001 ? '#i-vol-off' : '#i-vol');
}

/* ------------------------- Modo de color ---------------------------------- */

const MODES = ['auto', 'light', 'dark'];
const MODE_ICONS = { auto: '#i-auto', light: '#i-sun', dark: '#i-moon' };

function applyModeUI() {
  document.body.dataset.mode = settings.mode || 'auto';
  const use = $('#mode-icon-use');
  if (use) use.setAttribute('href', MODE_ICONS[settings.mode] || '#i-auto');
}

function cycleMode() {
  const i = MODES.indexOf(settings.mode);
  settings.mode = MODES[(i + 1) % MODES.length];
  saveSettings();
  applyModeUI();
  toast({ auto: 'Color: automático (según tu sistema)', light: 'Color: claro', dark: 'Color: oscuro' }[settings.mode], 1600);
}

/* --------------------- Reproductor a pantalla completa -------------------- */

function openPlayer() {
  const ov = $('#player-overlay');
  ov.classList.add('open');
  ov.setAttribute('aria-hidden', 'false');
  const btn = $('#btn-close-player');
  if (btn) btn.focus({ preventScroll: true });
}

function closePlayer() {
  const ov = $('#player-overlay');
  ov.classList.remove('open');
  ov.setAttribute('aria-hidden', 'true');
  const btn = $('#mini-play');
  if (btn) btn.focus({ preventScroll: true });
}

/* ============================================================================
   10. GESTOS Y TECLADO
   ============================================================================ */

function bindGestures() {
  const zone = $('#swipe-zone');
  const cover = $('#player-cover');
  if (!zone || !cover) return;

  let x0 = 0, y0 = 0, dx = 0, dy = 0, tracking = false;

  zone.addEventListener('touchstart', (e) => {
    const t = e.touches[0];
    x0 = t.clientX; y0 = t.clientY; dx = 0; dy = 0;
    tracking = true;
  }, { passive: true });

  zone.addEventListener('touchmove', (e) => {
    if (!tracking) return;
    const t = e.touches[0];
    dx = t.clientX - x0;
    dy = t.clientY - y0;
    const lim = Math.max(-70, Math.min(70, dx * 0.4));   // desplazamiento con resistencia
    cover.style.transform = `translateX(${lim}px)`;
  }, { passive: true });

  zone.addEventListener('touchend', () => {
    if (!tracking) return;
    tracking = false;
    cover.style.transform = '';
    if (Math.abs(dx) > 55 && Math.abs(dy) < 60) {
      if (dx < 0) next(true);   // deslizar a la izquierda → siguiente
      else prev();              // deslizar a la derecha → anterior
    }
  });
}

function bindKeyboard() {
  document.addEventListener('keydown', (e) => {
    const tag = (e.target && e.target.tagName) || '';
    const typing = /^(INPUT|SELECT|TEXTAREA)$/.test(tag);

    if (e.key === 'Escape') {
      if ($('#player-overlay').classList.contains('open')) closePlayer();
      return;
    }
    if (typing) return;

    switch (e.key) {
      case ' ': e.preventDefault(); togglePlay(); break;
      case 'ArrowRight': e.preventDefault(); (e.shiftKey ? next(true) : seekBy(10)); break;
      case 'ArrowLeft':  e.preventDefault(); (e.shiftKey ? prev() : seekBy(-10)); break;
      case 'ArrowUp':    e.preventDefault(); setVolume(audio.volume + 0.05); break;
      case 'ArrowDown':  e.preventDefault(); setVolume(audio.volume - 0.05); break;
      case 'm': case 'M': toggleMute(); break;
      case 's': case 'S': toggleShuffle(); break;
      case 'r': case 'R': cycleRepeat(); break;
      case 'f': case 'F':
        if ($('#player-overlay').classList.contains('open')) closePlayer();
        else if (currentSong()) openPlayer();
        break;
    }
  });
}

/* ============================================================================
   11. ENLACE DE EVENTOS DE LA INTERFAZ
   ============================================================================ */

function bindUI() {
  // Pantalla de inicio
  $('#btn-folder').addEventListener('click', () => $('#input-dir').click());
  $('#btn-fsa').addEventListener('click', () => {
    pickFolderFSA().catch((e) => toast('No se pudo abrir el selector de carpetas: ' + (e && e.message || '')));
  });
  $('#btn-files').addEventListener('click', () => $('#input-files').click());
  $('#btn-reconnect').addEventListener('click', () => reconnectFSA());

  // Entradas de archivos
  $('#input-dir').addEventListener('change', (e) => handleInputChange(e.target, true));
  $('#input-files').addEventListener('change', (e) => handleInputChange(e.target, false));

  // Toolbar
  $('#input-search').addEventListener('input', debounce((e) => {
    state.query = e.target.value || '';
    computeView();
    renderList();
  }, 250));

  $('#select-folder').addEventListener('change', (e) => {
    state.folderFilter = e.target.value || 'all';
    computeView();
    renderList();
  });

  $('#select-sort').addEventListener('change', (e) => {
    state.sortMode = e.target.value;
    settings.sortMode = state.sortMode;
    saveSettings();
    computeView();
    renderList();
  });

  $('#btn-refresh').addEventListener('click', onRefresh);
  $('#btn-mode').addEventListener('click', cycleMode);

  // Mini reproductor
  $('#mini-open').addEventListener('click', openPlayer);
  $('#mini-prev').addEventListener('click', () => prev());
  $('#mini-play').addEventListener('click', togglePlay);
  $('#mini-next').addEventListener('click', () => next(true));

  // Reproductor completo
  $('#btn-close-player').addEventListener('click', closePlayer);
  $('#btn-shuffle').addEventListener('click', toggleShuffle);
  $('#btn-prev').addEventListener('click', () => prev());
  $('#btn-play').addEventListener('click', togglePlay);
  $('#btn-next').addEventListener('click', () => next(true));
  $('#btn-repeat').addEventListener('click', cycleRepeat);
  $('#btn-mute').addEventListener('click', toggleMute);

  // Barras
  const seekEl = $('#seek');
  seekEl.addEventListener('input', () => {
    seeking = true;
    const dur = audio.duration;
    $('#time-cur').textContent = fmtTime(isFinite(dur) && dur > 0 ? (seekEl.value / 1000) * dur : 0);
  });
  seekEl.addEventListener('change', () => {
    const dur = audio.duration;
    if (isFinite(dur) && dur > 0) audio.currentTime = (seekEl.value / 1000) * dur;
    seeking = false;
  });

  $('#vol').addEventListener('input', (e) => setVolume((e.target.valueAsNumber || 0) / 100));
}

async function onRefresh() {
  if (state.source && state.source.type === 'fsa') {
    await rescanLibrary(false);
  } else if (state.source && state.source.type === 'input') {
    toast('El navegador pide confirmar de nuevo: elige la carpeta para releerla.');
    $('#input-dir').click();
  } else {
    $('#input-dir').click();
  }
}

/** Paginación infinita: un "centinela" al final dispara el siguiente lote. */
function bindSentinel() {
  const sentinel = $('#list-sentinel');
  if (!sentinel || !('IntersectionObserver' in window)) return;
  const io = new IntersectionObserver((entries) => {
    if (entries.some((en) => en.isIntersecting) && state.rendered < state.view.length) {
      renderMore();
    }
  }, { rootMargin: '600px' });
  io.observe(sentinel);
}

/* ============================================================================
   12. CICLO DE VIDA — guardar al salir, refrescar al volver
   ============================================================================ */

function saveCurrentPosition() {
  const song = currentSong();
  if (song && audio.currentTime > 3 && isFinite(audio.duration) &&
      audio.currentTime < audio.duration - 2) {
    settings.positions[song.id] = audio.currentTime;
  }
}

function onVisibility() {
  if (document.visibilityState === 'visible') {
    // Al volver a la app: releer la carpeta permanente si pasaron >30 s
    if (state.source && state.source.type === 'fsa' && Date.now() - state.lastScan > 30000) {
      (async () => {
        try {
          const p = await state.source.handle.queryPermission({ mode: 'read' });
          if (p === 'granted') rescanLibrary(false);
        } catch { /* ignore */ }
      })();
    }
  } else {
    saveCurrentPosition();
    flushSettings();
  }
}

/* ============================================================================
   13. SERVICE WORKER — caché offline de la propia aplicación
   Solo se registra en https:// o localhost (en file://, dentro del APK,
   no existe y la app funciona igualmente sin él).
   ============================================================================ */

function registerSW() {
  if (!('serviceWorker' in navigator)) return;
  const isLocal = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  if (location.protocol !== 'https:' && !isLocal) return;
  navigator.serviceWorker.register('sw.js').catch(() => { /* sin SW la app funciona */ });
}

/* ============================================================================
   14. ARRANQUE
   ============================================================================ */

async function init() {
  // Estado restaurado
  state.shuffle = !!settings.shuffle;
  state.repeat = ['off', 'all', 'one'].includes(settings.repeat) ? settings.repeat : 'off';
  state.sortMode = ['added', 'title', 'artist', 'album'].includes(settings.sortMode) ? settings.sortMode : 'added';
  $('#select-sort').value = state.sortMode;

  // Tema neutro inicial + modo de color del usuario
  applyTheme(DEFAULT_THEME);
  applyModeUI();

  // Interfaz
  bindUI();
  bindMediaSession();
  bindGestures();
  bindKeyboard();
  bindSentinel();
  syncTransportUI();
  syncPlayIcons();

  // "Conectar carpeta permanente" solo donde exista la API (escritorio Chromium)
  if (FSA_SUPPORTED) $('#btn-fsa').classList.remove('hidden');

  // Librerías de respaldo por CDN (si faltan las locales) en segundo plano
  idle(() => { ensureLibs(); });

  // Carpeta persistente guardada (si el permiso sigue concedido, se lee sola)
  await tryAutoReconnect();

  // Pedir almacenamiento persistente (protege el handle en IndexedDB)
  if (navigator.storage && navigator.storage.persist) {
    try { navigator.storage.persist().catch(() => {}); } catch { /* ignore */ }
  }

  registerSW();

  window.addEventListener('pagehide', () => { saveCurrentPosition(); flushSettings(); });
  document.addEventListener('visibilitychange', onVisibility);
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();

