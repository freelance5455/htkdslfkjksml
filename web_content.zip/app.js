const screen=document.getElementById('screen');let page='home';
const chords=[['C','دو ماژور'],['G','سل ماژور'],['D','ر ماژور'],['Em','می مینور'],['Am','لا مینور'],['Bm','سی مینور']];
function layout(x){screen.innerHTML='<div class="content">'+x+'</div>';document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===page));}
function home(){layout(`<div class="welcome"><div class="guitar">🎸</div><h1>به دنیای گیتار خوش آمدید!</h1><p>یادگیری گیتار، قدم به قدم</p></div><div class="grid">
<div class="card green" onclick="showChords()">🎓<b>آموزش آکوردها</b><small>آکوردهای پایه تا پیشرفته</small></div>
<div class="card blue" onclick="showScales()">♫<b>مقیاس‌ها و ملودی‌ها</b><small>تمرین و تکرار</small></div>
<div class="card purple" onclick="showPractice()">♩<b>تمرین ریتم</b><small>با مترونوم</small></div>
<div class="card orange"><b>🎸 آهنگ‌های تمرینی</b><small>از ساده تا حرفه‌ای</small></div>
<div class="card wide">⚙ <b>تنظیمات و راهنما</b><small>تنظیمات برنامه و نکات مفید</small></div></div>`)}
function showChords(){page='chords';layout(`<h2>آکوردها</h2><div class="list">${chords.map(c=>`<div class="row" onclick="detail('${c[0]}')"><div class="left"><div class="dot">${c[0]}</div><div><b>${c[0]}</b><br><small>${c[1]}</small></div></div><span>‹</span></div>`).join('')}</div>`)}
function detail(c){layout(`<h2>آکورد ${c}</h2><div class="diagram"><h1 style="text-align:center">${c}</h1>${[1,2,3,4,5,6].map((_,i)=>`<div class="fret"><span class="dotmark" style="left:${[25,50,68,35,60,45][i]}%"></span></div>`).join('')}</div><p>نمایش انگشت‌گذاری آکورد و فرت‌های مورد استفاده.</p><button class="btn">▶ پخش صدای آکورد</button>`)}
function showScales(){page='scales';layout(`<h2>مقیاس‌ها</h2><div class="list">${['C Major','A Minor','G Major','E Minor','D Major','D Minor'].map(x=>`<div class="row"><div class="left"><div class="dot">${x[0]}</div><div><b>${x}</b><br><small>مقیاس روی گیتار</small></div></div><span>‹</span></div>`).join('')}</div>`)}
function showPractice(){page='practice';layout(`<h2>تمرین‌ها</h2><div class="list"><div class="row">🎵 <b>تمرین تعویض آکوردها</b><small> ۵ دقیقه</small></div><div class="row">♩ <b>تمرین ریتم با مترونوم</b><small> ۵ دقیقه</small></div><div class="row">🎸 <b>پیشرفت آکوردها</b><small> ۱۰ دقیقه</small></div><div class="row">🎶 <b>تمرین ملودی ساده</b><small> ۵ دقیقه</small></div><div class="row" onclick="tuner()">🎛 <b>تیونر</b><small> کوک گیتار</small></div></div>`)}
function tuner(){page='practice';layout(`<h2>تیونر</h2><div class="tuner"><div class="dial">E</div><div class="ok">✓ سیم شما درست کوک است!</div><p>فرکانس: 329.6 Hz</p><div class="grid">${['E','A','D','G','B','E'].map(x=>`<div class="card">${x}</div>`).join('')}</div></div>`)}
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>{page=b.dataset.page;({home,chords:showChords,scales:showScales,practice:showPractice})[page]()});
document.getElementById('back').onclick=()=>home();home();