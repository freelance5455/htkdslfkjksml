"use strict";

const $ = s => document.querySelector(s),
  esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]),
  fmt = x => x == null ? "—" : x.toLocaleString("fr-FR", {
    maximumFractionDigits: 2
  }),
  uid = () => "u" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
let D = fresh(),
  page = "Accueil",
  T = 1,
  courseId = "",
  filterSub = "",
  query = "",
  quiz = null,
  timer = null,
  toastTimer,
  storageIssue = "",
  volatileMode = false,
  previousFocus,
  serial = "",
  todaySeen = day();
const paths = {
  Accueil: "M3 11 12 3l9 8v9h-6v-6H9v6H3z",
  Révisions: "M3 5q5-2 9 1 4-3 9-1v14q-5-2-9 1-4-3-9-1z M12 6v14",
  Moyennes: "M4 20h17 M6 16v-5m6 5V4m6 12V8",
  Bac: "m2 9 10-5 10 5-10 5z M6 11v5q6 5 12 0v-5 M22 9v6",
  Profil: "M8 8a4 4 0 1 0 8 0 4 4 0 1 0-8 0 M4 21c0-8 16-8 16 0",
  flame: "M13 2c1 5 6 6 6 12a7 7 0 0 1-14 0c0-3 2-5 4-7 0 4 2 5 2 5 2-3 3-6 2-10z",
  xp: "m14 2-11 13h8l-1 7 11-14h-8z",
  target: "M3 12a9 9 0 1 0 18 0 9 9 0 1 0-18 0 M8 12a4 4 0 1 0 8 0 4 4 0 1 0-8 0",
  arrow: "M4 12h15m-6-6 6 6-6 6"
};
function icon(k) {
  return '<svg class="icon" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="' + paths[k] + '"/></svg>';
}
const btn = (s, fn, c = "") => '<button class="' + c + '" onclick="' + esc(fn) + '">' + s + '</button>';
const heading = (k, s) => '<div class="eyebrow">' + k + '</div><h1>' + s + '</h1>';
const box = (s, body) => '<section class="card"><h2>' + s + '</h2>' + body + '</section>';
const bar = x => '<div class="bar"><i style="width:' + Math.min(100, Math.max(0, x)) + '%"></i></div>';
const option = (v, s, sel) => '<option value="' + esc(v) + '" ' + (String(v) === String(sel) ? "selected" : "") + '>' + esc(s) + '</option>';
const field = (label, name, v = "", type = "text", attr = "") => '<label>' + label + '<input name="' + name + '" type="' + type + '" value="' + esc(v) + '" ' + attr + '></label>';
const choose = (label, name, opts) => '<label>' + label + '<select name="' + name + '">' + opts + '</select></label>';
const check = (label, name, v) => '<label class="check"><input type="checkbox" name="' + name + '" ' + (v ? "checked" : "") + '>' + label + '</label>';
function notice(s) {
  $("#toast").textContent = s;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("#toast").textContent = "", 4300);
}
function save() {
  try {
    let next = JSON.stringify(D);
    if (!valid(D)) throw Error("Données invalides.");
    if (volatileMode) {
      serial = next;
      return true;
    }
    if (storageIssue) throw Error(storageIssue);
    if (localStorage.getItem(keyName) !== serial) throw Error("Données modifiées ailleurs. Recharge la page.");
    try {
      localStorage.setItem(keyName, next);
    } catch (e) {
      volatileMode = true;
      storageIssue = "Stockage local indisponible ou plein. Exporte ton JSON avant de fermer cette page.";
    }
    serial = next;
    return true;
  } catch (e) {
    D = serial && validSafe(serial) ? JSON.parse(serial) : fresh();
    notice("Enregistrement impossible. " + e.message);
    return false;
  }
}
function validSafe(raw) {
  try {
    return valid(JSON.parse(raw));
  } catch (e) {
    return false;
  }
}
function boot() {
  try {
    serial = localStorage.getItem(keyName);
    if (serial) {
      if (validSafe(serial)) D = JSON.parse(serial);else storageIssue = "Sauvegarde incompatible ou endommagée. Exporte le texte brut depuis Profil.";
    }
  } catch (e) {
    volatileMode = true;
    storageIssue = "Mode temporaire : exporte le JSON avant de fermer la page. Active le stockage DOM pour la sauvegarde automatique.";
  }
  T = term(D);
  $(".close").onclick = closeDlg;
  $("#overlay").onclick = e => {
    if (e.target === $("#overlay")) closeDlg();
  };
  document.addEventListener("keydown", e => {
    if (e.key === "Escape" && !$("#overlay").hidden) closeDlg();
    if (e.key === "Tab" && !$("#overlay").hidden) {
      let a = [...$(".dialog").querySelectorAll("button,input,select,textarea,[tabindex]")].filter(x => x.offsetParent !== null);
      if (e.shiftKey && document.activeElement === a[0]) {
        e.preventDefault();
        a[a.length - 1].focus();
      } else if (!e.shiftKey && document.activeElement === a[a.length - 1]) {
        e.preventDefault();
        a[0].focus();
      }
    }
  });
  render();
  setInterval(() => {
    if (day() !== todaySeen) {
      todaySeen = day();
      if (page === "Accueil") render();
    }
  }, 15000);
}
function dlg(title, html, handler) {
  previousFocus = document.activeElement;
  $("#dlgtitle").textContent = title;
  $("#inside").innerHTML = html;
  $("#overlay").hidden = false;
  document.body.style.overflow = "hidden";
  $(".close").focus();
  let f = $("#inside form");
  if (f && handler) f.onsubmit = e => {
    e.preventDefault();
    handler(f);
  };
}
function closeDlg() {
  $("#overlay").hidden = true;
  $("#inside").innerHTML = "";
  document.body.style.overflow = "";
  if (previousFocus && previousFocus.isConnected) previousFocus.focus();
}
function commit() {
  if (!save()) return;
  closeDlg();
  render();
  notice(volatileMode ? "En mémoire pour cette ouverture. Pense à exporter le JSON." : "Enregistré sur cet appareil.");
}
function confirmAction(message, action) {
  dlg("Confirmer", '<p>' + esc(message) + '</p><div class="inline"><button id="accept" class="primary">Confirmer</button><button id="cancel">Annuler</button></div>');
  $("#accept").onclick = () => {
    closeDlg();
    action();
  };
  $("#cancel").onclick = closeDlg;
}
function go(p) {
  if (quiz && !quiz.done && p !== page) {
    confirmAction("Quitter cette séance ? Les réponses déjà validées restent dans tes statistiques.", () => {
      quiz = null;
      go(p);
    });
    return;
  }
  if (p !== page) {
    quiz = null;
    courseId = "";
  }
  page = p;
  render();
  window.scrollTo(0, 0);
}
function render() {
  clearInterval(timer);
  document.body.classList.toggle("light", D.settings.theme === "clair");
  $("#nav").innerHTML = Object.keys(paths).slice(0, 5).map(p => '<button ' + (p === page ? 'class="active" aria-current="page"' : '') + ' onclick="go(\'' + p + '\')">' + icon(p) + p + '</button>').join("");
  let html = page === "Accueil" ? home() : page === "Moyennes" ? gradesPage() : page === "Révisions" ? revision() : page === "Bac" ? bacPage() : profile();
  $("#main").innerHTML = (storageIssue ? '<p role="alert" class="feedback miss">' + esc(storageIssue) + '</p>' : '') + html;
  if (quiz && page === "Révisions") tick();
}
function stats(ch) {
  let a = ch ? D.answers.filter(a => a.ch === ch) : D.answers;
  let recent = a.slice(-10);
  return {
    n: a.length,
    ok: a.filter(x => x.ok).length,
    rate: recent.length ? recent.filter(x => x.ok).length / recent.length : 0,
    distinct: new Set(a.map(x => x.q)).size,
    sec: a.reduce((v, x) => v + x.sec, 0)
  };
}
function activeCourses() {
  return COURSES.filter(c => D.subjects.some(s => s.id === c.sub && s.show));
}
function mastered(c) {
  let a = stats(c.id);
  return a.distinct >= 5 && a.rate >= .8;
}
function weak() {
  return activeCourses().filter(c => {
    let s = stats(c.id);
    return s.n && s.rate < .7;
  }).sort((a, b) => stats(a.id).rate - stats(b.id).rate);
}
const nameOf = id => (D.subjects.find(s => s.id === id) || {
  name: SUBJECTS[id] || id
}).name;
function recommend() {
  const active = activeCourses();
  const due = active.map(c => {
    const history = D.answers.filter(a => a.ch === c.id);
    if (!history.length) return null;
    const last = history[history.length - 1].date;
    const interval = mastered(c) ? Math.min(14, 2 * Math.floor(history.length / 5)) : 1;
    return {course: c, date: shift(last, interval)};
  }).filter(item => item && item.date <= day()).sort((a,b) => a.date.localeCompare(b.date));
  return weak()[0] || (due[0] && due[0].course) || active.find(c => !mastered(c)) || active[0];
}
function metric(k, label, num, unit) {
  return '<div class="metric"><span class="tileicon">' + icon(k) + '</span><span class="small">' + label + '</span><strong>' + num + ' <small>' + unit + '</small></strong></div>';
}
function chart() {
  let vs = [1, 2, 3].map(t => general(D, t)),
    pts = vs.map((v, i) => v == null ? null : [42 + i * 112, 72 - v * 3]);
  return '<svg class="chart" viewBox="0 0 300 100" role="img" aria-label="' + esc(vs.map((v, i) => 'T' + (i + 1) + ' ' + fmt(v)).join(', ')) + '">' + [0, 10, 20].map(v => '<text x="0" y="' + (76 - v * 3) + '">' + v + '</text><line x1="24" x2="286" y1="' + (72 - v * 3) + '" y2="' + (72 - v * 3) + '"/>').join("") + pts.map((p, i) => '<text x="' + (33 + i * 112) + '" y="95">T' + (i + 1) + '</text>' + (!p ? '' : (i > 0 && pts[i - 1] ? '<line style="stroke:var(--vio);stroke-width:3" x1="' + pts[i - 1][0] + '" y1="' + pts[i - 1][1] + '" x2="' + p[0] + '" y2="' + p[1] + '"/>' : '') + '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="4" fill="var(--aqua)"/>')).join("") + '</svg>';
}
function home() {
  let c = recommend(),
    s = streak(D.sessions),
    xp = D.answers.concat(D.sessions).reduce((n, v) => n + v.xp, 0),
    tt = term(D),
    date = day(),
    monday = shift(date, -((new Date().getDay() + 6) % 7)),
    active = activeCourses(),
    wk = s.days.filter(d => d >= monday).length,
    mins = D.answers.filter(a => a.date === date).reduce((x, a) => x + a.sec, 0) / 60;
  return heading("Terminale STI2D · ITEC", "Tableau de bord") + '<section class="hero"><img src="icons/transmission.svg" alt=""><div><div class="eyebrow">Prochaine révision</div><h2>' + esc(c ? c.title : "Bibliothèque masquée") + '</h2><p>' + esc(c ? nameOf(c.sub) + " · 5 questions" : "Choisis tes matières dans Profil.") + '</p>' + btn("Réviser maintenant " + icon("arrow"), c ? "startQuiz('" + c.id + "')" : "go('Profil')", "primary") + '</div></section><div class="stats">' + metric("Moyennes", "Moyenne T" + tt, fmt(general(D, tt)), "/ 20") + metric("flame", "Série actuelle", s.current, "jour" + (s.current > 1 ? "s" : "")) + metric("xp", "Expérience", xp, "XP · niv. " + (1 + Math.floor(Math.sqrt(xp / 100)))) + metric("target", "Objectif", fmt(D.settings.goal), "/ 20") + '</div><div class="grid"><div class="cards">' + box("Ta semaine", '<div class="row"><span class="small">Journées validées</span><b>' + wk + ' / 7</b></div><div class="week">' + ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map((v, i) => {
    let d = shift(monday, i);
    return '<span>' + v + '<b class="' + (s.days.includes(d) ? "done " : "") + (d === date ? "today" : "") + '">' + (s.days.includes(d) ? "✓" : +d.slice(-2)) + '</b></span>';
  }).join("") + '</div><p class="small">Aujourd’hui · ' + fmt(mins) + ' / ' + D.settings.daily + ' min de pratique</p>' + bar(mins / D.settings.daily * 100)) + box("Évolution des moyennes", chart() + (general(D, 0) == null ? '<p class="small">Ta première note fera apparaître un point sur la courbe.</p>' : '') + btn("Ouvrir le carnet", "go('Moyennes')", "link")) + '</div><div class="cards">' + box("Tes points faibles", weak().length ? weak().slice(0, 3).map(c => btn(esc(c.title), "readCourse('" + c.id + "')", "link")).join("") : '<p>' + (!D.answers.length ? "Réponds à cinq questions pour commencer à repérer les notions à retravailler." : "Aucun chapitre étudié sous le seuil de 70 % sur ses dernières réponses.") + '</p>') + box("Chapitres maîtrisés", '<strong>' + active.filter(mastered).length + ' / ' + active.length + '</strong>' + bar(100 * active.filter(mastered).length / (active.length || 1))) + box("Dernières séances", D.sessions.length ? D.sessions.slice(-3).reverse().map(s => '<div class="entry"><strong>' + esc(s.title) + '</strong><div class="small">' + s.date + ' · ' + s.right + '/' + s.n + ' réponses justes</div></div>').join("") : '<p>Ta première séance terminée apparaîtra ici.</p>') + '</div></div>';
}
