/* OmniWeb Studio - full web app (vanilla JS, zero dependencies) */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var esc = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  /* ---------- icons (24x24 material-style paths) ---------- */
  var P = {
    back: 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
    add: 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
    search: 'M15.5 14h-.79l-.28-.27A6.47 6.47 0 0016 9.5 6.5 6.5 0 109.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
    close: 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
    more: 'M12 8a2 2 0 100-4 2 2 0 000 4zm0 2a2 2 0 100 4 2 2 0 000-4zm0 6a2 2 0 100 4 2 2 0 000-4z',
    grid: 'M3 3h8v8H3V3zm0 10h8v8H3v-8zM13 3h8v8h-8V3zm0 10h8v8h-8v-8z',
    list: 'M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z',
    folder: 'M10 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z',
    save: 'M17 3H5a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2V7l-4-4zm-5 16a3 3 0 110-6 3 3 0 010 6zm3-10H5V5h10v4z',
    lock: 'M18 8h-1V6a5 5 0 00-10 0v2H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V10a2 2 0 00-2-2zm-6 9a2 2 0 110-4 2 2 0 010 4zm3.1-9H8.9V6a3.1 3.1 0 016.2 0v2z',
    check: 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
    refresh: 'M17.65 6.35A7.96 7.96 0 0012 4a8 8 0 100 16c3.73 0 6.84-2.55 7.73-6h-2.08A6 6 0 1112 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
    play: 'M8 5v14l11-7z',
    terminal: 'M20 4H4a2 2 0 00-2 2v12a2 2 0 002 2h16a2 2 0 002-2V6a2 2 0 00-2-2zm0 14H4V8h16v10zm-2-1h-6v-2h6v2zM7.5 17l-1.41-1.41L8.67 13l-2.59-2.59L7.5 9l4 4-4 4z',
    wifi: 'M1 9l2 2a14 14 0 0118 0l2-2A17 17 0 001 9zm8 8l3 3 3-3a4.2 4.2 0 00-6 0zm-4-4l2 2a7 7 0 0110 0l2-2a10 10 0 00-14 0z',
    wifiOff: 'M23.64 7A17 17 0 0012 3c-1.5 0-2.89.19-4.15.48L18.18 13.8 23.64 7zm-6.6 8.22L3.27 1.44 2 2.72l2.05 2.06C1.91 5.76.59 6.82.36 7L12 21.5l3.9-4.86 3.32 3.32 1.27-1.27-3.45-3.47z',
    full: 'M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z',
    star: 'M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z',
    edit: 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04a1 1 0 000-1.41l-2.34-2.34a1 1 0 00-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
    copy: 'M16 1H4a2 2 0 00-2 2v14h2V3h12V1zm3 4H8a2 2 0 00-2 2v14a2 2 0 002 2h11a2 2 0 002-2V7a2 2 0 00-2-2zm0 16H8V7h11v14z',
    trash: 'M6 19a2 2 0 002 2h8a2 2 0 002-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
    build: 'M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z',
    android: 'M6 18a1 1 0 001 1h1v3.5a1.5 1.5 0 003 0V19h2v3.5a1.5 1.5 0 003 0V19h1a1 1 0 001-1V8H6v10zM3.5 8A1.5 1.5 0 002 9.5v7a1.5 1.5 0 003 0v-7A1.5 1.5 0 003.5 8zm17 0A1.5 1.5 0 0019 9.5v7a1.5 1.5 0 003 0v-7A1.5 1.5 0 0020.5 8zM15.53 2.16l1.3-1.3a.5.5 0 00-.71-.71l-1.48 1.48A5.84 5.84 0 0012 1c-.96 0-1.86.23-2.66.63L7.85.15a.5.5 0 00-.71.71l1.31 1.31A6 6 0 006 7h12a6 6 0 00-2.47-4.84zM10 5H9V4h1v1zm5 0h-1V4h1v1z',
    archive: 'M20.54 5.23l-1.39-1.68A1.5 1.5 0 0018 3H6c-.47 0-.88.21-1.16.55L3.46 5.23C3.17 5.57 3 6.02 3 6.5V19a2 2 0 002 2h14a2 2 0 002-2V6.5c0-.48-.17-.93-.46-1.27zM12 17.5L6.5 12H10v-2h4v2h3.5L12 17.5zM5.12 5l.81-1h12l.94 1H5.12z',
    upload: 'M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z',
    code: 'M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z',
    globe: 'M12 2a10 10 0 100 20 10 10 0 000-20zm6.93 6h-2.95a15.65 15.65 0 00-1.38-3.56A8.03 8.03 0 0118.92 8zM12 4.04c.83 1.2 1.48 2.53 1.91 3.96h-3.82c.43-1.43 1.08-2.76 1.91-3.96zM4.26 14a8 8 0 010-4h3.38a16 16 0 000 4H4.26zm.82 2h2.95c.32 1.25.78 2.45 1.38 3.56A8 8 0 015.08 16zm2.95-8H5.08a8 8 0 014.33-3.56A15.65 15.65 0 008.03 8zM12 19.96c-.83-1.2-1.48-2.53-1.91-3.96h3.82c-.43 1.43-1.08 2.76-1.91 3.96zM14.34 14H9.66a14 14 0 010-4h4.68a14 14 0 010 4zm.25 5.56c.6-1.11 1.06-2.31 1.38-3.56h2.95a8 8 0 01-4.33 3.56zM16.36 14a16 16 0 000-4h3.38a8 8 0 010 4h-3.38z',
    file: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
    palette: 'M12 3a9 9 0 000 18c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.3-.5-.8-.5-1.2 0-1.1.9-2 2-2h2.4A4.6 4.6 0 0022 10c0-3.9-4.5-7-10-7z',
    shield: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z',
    app: 'M17 1H7a2 2 0 00-2 2v18a2 2 0 002 2h10a2 2 0 002-2V3a2 2 0 00-2-2zm0 18H7V5h10v14z',
    video: 'M18 4l2 4h-3l-2-4h-2l2 4h-3l-2-4H8l2 4H7L5 4H4a2 2 0 00-2 2v12a2 2 0 002 2h16a2 2 0 002-2V4h-4z',
    download: 'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z'
  };
  function ic(name, cls) {
    return '<svg class="' + (cls || 'ico') + '" viewBox="0 0 24 24" aria-hidden="true"><path d="' + P[name] + '"/></svg>';
  }
  function ib(action, icon, label, extra) {
    return '<button class="ib ' + (extra && extra.cls || '') + '" data-action="' + action + '"' +
      (extra && extra.id ? ' data-id="' + extra.id + '"' : '') + ' aria-label="' + label + '" title="' + label + '">' + ic(icon) + '</button>';
  }

  /* ---------- minimal ZIP (store method) ---------- */
  function crc32(data) {
    var table = crc32._t;
    if (!table) {
      table = crc32._t = new Uint32Array(256);
      for (var n = 0; n < 256; n++) {
        var c = n;
        for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
        table[n] = c;
      }
    }
    var crc = 0 ^ (-1);
    var bytes = typeof data === 'string' ? new TextEncoder().encode(data) : data;
    for (var i = 0; i < bytes.length; i++) crc = (crc >>> 8) ^ table[(crc ^ bytes[i]) & 0xFF];
    return (crc ^ (-1)) >>> 0;
  }
  function u16(n) { return new Uint8Array([n & 0xFF, (n >> 8) & 0xFF]); }
  function u32(n) { return new Uint8Array([n & 0xFF, (n >> 8) & 0xFF, (n >> 16) & 0xFF, (n >> 24) & 0xFF]); }
  function concat(arrs) {
    var len = 0; arrs.forEach(function (a) { len += a.length; });
    var out = new Uint8Array(len), o = 0;
    arrs.forEach(function (a) { out.set(a, o); o += a.length; });
    return out;
  }
  function makeZip(files) {
    var local = [], central = [], offset = 0;
    var names = Object.keys(files);
    names.forEach(function (name) {
      var data = new TextEncoder().encode(files[name]);
      var nameBytes = new TextEncoder().encode(name);
      var crc = crc32(data);
      var localHeader = concat([
        u32(0x04034b50), u16(20), u16(0), u16(0), u16(0), u16(0),
        u32(crc), u32(data.length), u32(data.length), u16(nameBytes.length), u16(0),
        nameBytes, data
      ]);
      local.push(localHeader);
      var centralHeader = concat([
        u32(0x02014b50), u16(20), u16(20), u16(0), u16(0), u16(0), u16(0),
        u32(crc), u32(data.length), u32(data.length), u16(nameBytes.length), u16(0), u16(0),
        u16(0), u16(0), u32(0), u32(offset), nameBytes
      ]);
      central.push(centralHeader);
      offset += localHeader.length;
    });
    var centralDir = concat(central);
    var end = concat([
      u32(0x06054b50), u16(0), u16(0), u16(names.length), u16(names.length),
      u32(centralDir.length), u32(offset), u16(0)
    ]);
    return concat(local.concat([centralDir, end]));
  }
  function downloadBlob(data, filename) {
    var blob = new Blob([data], { type: 'application/zip' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename; a.style.display = 'none';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 1500);
  }
  function parseZip(arrayBuffer) {
    var view = new DataView(arrayBuffer);
    var bytes = new Uint8Array(arrayBuffer);
    var files = {};
    var pos = 0;
    while (pos + 4 < bytes.length) {
      var sig = view.getUint32(pos, true);
      if (sig === 0x04034b50) {
        var method = view.getUint16(pos + 8, true);
        var compSize = view.getUint32(pos + 18, true);
        var nameLen = view.getUint16(pos + 26, true);
        var extraLen = view.getUint16(pos + 28, true);
        var name = new TextDecoder().decode(bytes.subarray(pos + 30, pos + 30 + nameLen));
        var dataStart = pos + 30 + nameLen + extraLen;
        var data = bytes.subarray(dataStart, dataStart + compSize);
        if (method === 0 && name && name.slice(-1) !== '/') {
          try { files[name] = new TextDecoder().decode(data); } catch (e) {}
        }
        pos = dataStart + compSize;
      } else if (sig === 0x02014b50 || sig === 0x06054b50) break;
      else pos++;
    }
    return files;
  }

  /* ---------- templates ---------- */
  var BLANK = {
    'index.html': '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>OmniWeb Project</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <div class="container">\n    <h1>Welcome to OmniWeb Studio</h1>\n    <p>Start building your web app by editing these files.</p>\n    <button id="mainButton" onclick="handleClick()">Click Me</button>\n  </div>\n  <script src="script.js"><\/script>\n</body>\n</html>\n',
    'style.css': '* { margin: 0; padding: 0; box-sizing: border-box; }\nbody {\n  font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, sans-serif;\n  background: #0f172a;\n  color: #e2e8f0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-height: 100vh;\n}\n.container { text-align: center; padding: 24px; }\nh1 { font-size: 2rem; margin-bottom: 12px; color: #38bdf8; }\np { margin-bottom: 24px; color: #94a3b8; }\nbutton {\n  background: #38bdf8;\n  color: #0f172a;\n  border: none;\n  padding: 12px 28px;\n  border-radius: 8px;\n  font-size: 1rem;\n  font-weight: 600;\n  cursor: pointer;\n}\nbutton:hover { opacity: 0.85; }\n',
    'script.js': 'function handleClick() {\n  console.log(\'Button clicked at \' + new Date().toISOString());\n  alert(\'Hello from OmniWeb Studio!\');\n}\n'
  };
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function defaultConfig(name) {
    return { appName: name, pkg: 'com.omniweb.app', vName: '1.0.0', vCode: 1, color: '#38bdf8', dark: true, full: false, desktop: false, orient: 'auto', icon: false, perms: ['INTERNET'] };
  }

  var LANDING = {
    'index.html': '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>Bean There</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <header><h1>Bean There</h1><p>Small-batch coffee, roasted on Tuesdays.</p></header>\n  <main>\n    <section><h2>Today\'s roast</h2><p>Ethiopia Guji - blueberry, jasmine, honey.</p></section>\n    <section><h2>Visit us</h2><p>12 Market Lane, open 7am to 6pm.</p></section>\n  </main>\n</body>\n</html>\n',
    'style.css': 'body{margin:0;font-family:Georgia,serif;background:#fdf6ec;color:#3b2a20}\nheader{padding:48px 24px;background:#3b2a20;color:#fdf6ec;text-align:center}\nh1{font-size:2.2rem;margin:0 0 8px}\nmain{padding:24px;display:grid;gap:16px}\nsection{background:#fff;border-radius:12px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,.08)}\n'
  };

  /* ---------- persistence ---------- */
  var STORAGE_KEY = 'omniweb_studio_v1';
  var FREE_LIMIT = 3;
  var AD_UNLOCK_MS = 2 * 60 * 60 * 1000; /* 2 hours */

  function loadState() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      return JSON.parse(raw);
    } catch (e) { return null; }
  }
  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        projects: S.projects,
        uid: uid,
        view: S.view,
        proUntil: S.proUntil || 0,
        proLifetime: !!S.proLifetime,
        proLabel: S.proLabel || ''
      }));
    } catch (e) {}
  }
  function isPro() {
    if (S.proLifetime) return true;
    if (S.proUntil && Date.now() < S.proUntil) return true;
    if (S.proUntil && Date.now() >= S.proUntil) {
      S.proUntil = 0;
      S.proLabel = '';
      saveState();
    }
    return false;
  }
  function proRemaining() {
    if (S.proLifetime) return 'Lifetime access';
    if (S.proUntil && Date.now() < S.proUntil) {
      var ms = S.proUntil - Date.now();
      var h = Math.floor(ms / 3600000);
      var m = Math.floor((ms % 3600000) / 60000);
      if (h > 0) return h + 'h ' + m + 'm remaining';
      return m + ' min remaining';
    }
    return '';
  }

  /* ---------- state ---------- */
  var uid = 3;
  var S = {
    route: { name: 'splash' },
    stack: [],
    view: 'grid',
    q: '',
    proUntil: 0,
    proLifetime: false,
    proLabel: '',
    projects: [
      { id: 1, name: 'My Project', files: clone(BLANK), main: 'index.html', cfg: defaultConfig('My Project'), updated: Date.now() - 86400000 * 2 },
      { id: 2, name: 'Bean There', files: clone(LANDING), main: 'index.html', cfg: defaultConfig('Bean There'), updated: Date.now() - 3600000 * 5 }
    ]
  };
  var ED = { file: 'index.html', explorer: false, saveTimer: null, dirty: false };
  var PV = { device: 'auto', console: false, online: true, full: false, logs: [] };
  var EX = { running: false, done: false, lines: [], pct: 0, name: '', kind: '', blob: null };

  (function initFromStorage() {
    var saved = loadState();
    if (saved) {
      if (Array.isArray(saved.projects) && saved.projects.length) S.projects = saved.projects;
      if (saved.uid) uid = saved.uid;
      if (saved.view) S.view = saved.view;
      S.proUntil = saved.proUntil || 0;
      S.proLifetime = !!saved.proLifetime;
      S.proLabel = saved.proLabel || '';
    }
  })();

  function proj(id) { return S.projects.filter(function (p) { return p.id === id; })[0]; }
  function cur() { return proj(S.route.id); }
  function bytes(p) { var n = 0; for (var k in p.files) n += new Blob([p.files[k]]).size; return n; }
  function fmt(n) { return n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB'; }
  function dateFmt(t) { return new Date(t).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); }
  function canCreate() { return isPro() || S.projects.length < FREE_LIMIT; }

  /* ---------- navigation ---------- */
  function nav(name, params) {
    S.stack.push(S.route);
    S.route = Object.assign({ name: name }, params || {});
    render();
  }
  function back() {
    S.route = S.stack.pop() || { name: 'dashboard' };
    render();
  }

  var app = $('#app');
  var splashTimer = null;
  function render() {
    var r = S.route.name;
    clearTimeout(splashTimer);
    if (r === 'splash') {
      app.innerHTML = '<div class="splash"><div class="logo">' + ic('code') + '</div><h1>OmniWeb Studio</h1><h2>APK Builder Pro</h2><div class="bar"><i></i></div><p>Loading workspace...</p></div>';
      splashTimer = setTimeout(function () { S.route = { name: 'dashboard' }; render(); }, 1400);
      return;
    }
    var views = { dashboard: vDashboard, editor: vEditor, preview: vPreview, builder: vBuilder, export: vExport, paywall: vPaywall };
    app.innerHTML = '<div class="screen">' + views[r]() + '</div>';
    if (r === 'editor') mountEditor();
    if (r === 'preview') mountPreview();
  }

  function bar(title, sub, actions, noBack) {
    return '<div class="appbar">' + (noBack ? '' : ib('back', 'back', 'Back')) +
      '<div class="title">' + esc(title) + (sub ? '<small id="bar-sub">' + esc(sub) + '</small>' : '') + '</div>' + (actions || '') + '</div>';
  }

  /* ---------- toast / sheet / dialog ---------- */
  var toastTimer;
  function toast(msg, kind) {
    var t = $('#toast');
    t.textContent = msg;
    t.className = 'toast show ' + (kind || '');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.className = 'toast'; }, 2800);
  }
  function closeOverlay() { $('#overlay').innerHTML = ''; }
  function sheet(items, title) {
    var h = '<div class="scrim" data-action="scrim"><div class="sheet" role="dialog"><div class="grab"></div>' + (title || '') +
      items.map(function (it, i) {
        return '<button class="it ' + (it.danger ? 'danger' : '') + '" data-sheet="' + i + '">' +
          (it.sub ? '<span class="ti">' + ic(it.icon) + '</span><span>' + esc(it.label) + '<small>' + esc(it.sub) + '</small></span>' : ic(it.icon) + '<span>' + esc(it.label) + '</span>') + '</button>';
      }).join('') + '</div></div>';
    $('#overlay').innerHTML = h;
    $('#overlay').firstChild._items = items;
  }
  function dialog(o) {
    var h = '<div class="scrim mid" data-action="scrim"><div class="dlg" role="dialog"><h3>' + (o.icon ? ic(o.icon) : '') + esc(o.title) + '</h3>' +
      (o.text ? '<p>' + esc(o.text) + '</p>' : '') + (o.body || '') +
      '<div class="acts">' + o.actions.map(function (a, i) {
        return '<button class="btn ' + (a.primary ? 'sm' : 'text') + (a.danger ? ' danger' : '') + '" data-dlg="' + i + '">' + esc(a.label) + '</button>';
      }).join('') + '</div></div></div>';
    $('#overlay').innerHTML = h;
    $('#overlay').firstChild._acts = o.actions;
    var inp = $('#overlay input'); if (inp) { inp.focus(); inp.select(); }
  }
  function promptDlg(title, label, value, okLabel, cb) {
    dialog({
      title: title,
      body: '<input class="input" id="dlg-in" aria-label="' + esc(label) + '" placeholder="' + esc(label) + '" value="' + esc(value) + '">',
      actions: [{ label: 'Cancel' }, { label: okLabel, primary: true, run: function () { var v = $('#dlg-in').value.trim(); if (v) cb(v); } }]
    });
  }
  function upgradeDlg(msg) {
    dialog({
      title: 'Upgrade to Pro', icon: 'star', text: msg,
      actions: [{ label: 'Later' }, { label: 'Go Pro', primary: true, run: function () { nav('paywall'); } }]
    });
  }

  /* ---------- dashboard ---------- */
  function filtered() {
    var q = S.q.toLowerCase();
    return S.projects.filter(function (p) { return !q || p.name.toLowerCase().indexOf(q) >= 0; });
  }
  function vDashboard() {
    var banner = isPro()
      ? '<div class="banner pro-on">' + ic('star') + '<div><b>Pro Active</b><span>' + esc(proRemaining() || S.proLabel || 'All features unlocked') + '</span></div></div>'
      : '<div class="banner">' + ic('star') + '<div><b>Unlock Pro Features</b><span>Custom package ID, icons, advanced permissions & more.</span></div><button class="btn text sm" data-action="paywall">Go Pro</button></div>';
    return bar('OmniWeb Studio', '', ib('toggleView', S.view === 'grid' ? 'list' : 'grid', 'Switch view'), true) +
      '<div class="scroll" id="dash-scroll"><div class="pad"><label class="search">' + ic('search') + '<input id="q" placeholder="Search projects..." value="' + esc(S.q) + '" aria-label="Search projects"></label></div>' +
      '<div class="chips" id="stats"></div>' + banner + '<div id="plist"></div></div>' +
      '<button class="fab" data-action="create" aria-label="New project">' + ic('add') + '</button>';
  }
  function renderList() {
    var list = filtered(), files = 0, size = 0;
    S.projects.forEach(function (p) { files += Object.keys(p.files).length; size += bytes(p); });
    var statsEl = $('#stats');
    if (!statsEl) return;
    statsEl.innerHTML = '<span class="stat">' + ic('folder') + S.projects.length + ' projects</span><span class="stat">' + ic('file') + files + ' files</span><span class="stat">' + ic('archive') + fmt(size) + '</span>';
    var plist = $('#plist');
    if (!plist) return;
    if (!list.length) {
      plist.innerHTML = '<div class="empty">' + ic('globe') + '<h3>No projects yet</h3><p>' + (S.q ? 'No projects match "' + esc(S.q) + '"' : 'Create a blank project or import a ZIP archive') + '</p></div>';
      return;
    }
    if (S.view === 'grid') {
      plist.innerHTML = '<div class="grid">' + list.map(function (p) {
        return '<div class="card pcard" role="button" tabindex="0" data-action="openEditor" data-id="' + p.id + '"><div class="thumb">' + ic('globe') + '</div><h3>' + esc(p.name) + '</h3><p>' + dateFmt(p.updated) + '</p><div class="foot"><p>' + Object.keys(p.files).length + ' files</p><button class="more" data-action="projMenu" data-id="' + p.id + '" aria-label="Project actions">' + ic('more', 'ico sm') + '</button></div></div>';
      }).join('') + '</div>';
    } else {
      plist.innerHTML = list.map(function (p) {
        return '<div class="card lrow" role="button" tabindex="0" data-action="openEditor" data-id="' + p.id + '"><div class="thumb">' + ic('globe') + '</div><div class="meta"><h3>' + esc(p.name) + '</h3><p>' + Object.keys(p.files).length + ' files · ' + dateFmt(p.updated) + '</p></div><button class="ib" data-action="projMenu" data-id="' + p.id + '" aria-label="Project actions">' + ic('more') + '</button></div>';
      }).join('');
    }
  }
  function projMenu(p) {
    sheet([
      { icon: 'edit', label: 'Open Editor', run: function () { ED.file = p.main; ED.explorer = false; nav('editor', { id: p.id }); } },
      { icon: 'play', label: 'Live Preview', run: function () { nav('preview', { id: p.id }); } },
      { icon: 'build', label: 'Build / Export', run: function () { nav('builder', { id: p.id }); } },
      { icon: 'copy', label: 'Clone Project', run: function () { cloneProj(p); } },
      { icon: 'edit', label: 'Rename', run: function () { promptDlg('Rename Project', 'Project name', p.name, 'Rename', function (v) { p.name = v; p.updated = Date.now(); saveState(); renderList(); }); } },
      { icon: 'trash', label: 'Delete', danger: true, run: function () {
        dialog({ title: 'Delete Project', text: 'Delete "' + p.name + '"? This cannot be undone.', actions: [{ label: 'Cancel' }, { label: 'Delete', danger: true, run: function () { S.projects = S.projects.filter(function (x) { return x !== p; }); saveState(); renderList(); toast('Project deleted', 'ok'); } }] });
      } }
    ]);
  }
  function cloneProj(p) {
    if (!canCreate()) { upgradeDlg('Free users are limited to ' + FREE_LIMIT + ' projects.'); return; }
    var c = clone(p); c.id = ++uid; c.name = p.name + ' (Copy)'; c.updated = Date.now();
    S.projects.push(c); saveState(); renderList(); toast('Cloned "' + p.name + '"', 'ok');
  }
  function createMenu() {
    sheet([
      { icon: 'add', label: 'Create Blank Project', sub: 'Boilerplate HTML5 + CSS + JS template', run: function () {
        if (!canCreate()) { upgradeDlg('Free users are limited to ' + FREE_LIMIT + ' projects. Upgrade to Pro for unlimited projects.'); return; }
        promptDlg('New Blank Project', 'Project name', 'My Project', 'Create', function (v) {
          var p = { id: ++uid, name: v, files: clone(BLANK), main: 'index.html', cfg: defaultConfig(v), updated: Date.now() };
          S.projects.push(p); saveState(); toast('Project "' + v + '" created', 'ok'); nav('editor', { id: p.id });
        });
      } },
      { icon: 'upload', label: 'Import ZIP Archive', sub: 'Import HTML/CSS/JS from a .zip file', run: function () {
        if (!canCreate()) { upgradeDlg('Free users are limited to ' + FREE_LIMIT + ' projects. Upgrade to Pro for unlimited projects.'); return; }
        var inp = $('#zip-import');
        inp.value = '';
        inp.onchange = function () {
          var file = inp.files && inp.files[0];
          if (!file) return;
          var reader = new FileReader();
          reader.onload = function () {
            try {
              var zfiles = parseZip(reader.result);
              var keys = Object.keys(zfiles).filter(function (k) { return /\.(html?|css|js|json|txt|md|svg)$/i.test(k) && zfiles[k]; });
              if (!keys.length) { toast('No web files found in ZIP', 'err'); return; }
              var main = keys.find(function (k) { return /index\.html?$/i.test(k); }) || keys.find(function (k) { return /\.html?$/i.test(k); }) || keys[0];
              var name = (file.name || 'imported').replace(/\.zip$/i, '') || 'imported-site';
              var map = {};
              keys.forEach(function (k) {
                var short = k.split('/').pop();
                if (short) map[short] = zfiles[k];
              });
              var mainShort = main.split('/').pop();
              S.projects.push({ id: ++uid, name: name, files: map, main: mainShort, cfg: defaultConfig(name), updated: Date.now() });
              saveState();
              renderList();
              toast('Imported "' + name + '" (' + Object.keys(map).length + ' files)', 'ok');
            } catch (err) {
              toast('Could not read ZIP file', 'err');
            }
          };
          reader.readAsArrayBuffer(file);
        };
        inp.click();
      } }
    ]);
  }

  /* ---------- editor ---------- */
  var SNIPS = [
    ['<!DOCTYPE>', '<!DOCTYPE html>\n'],
    ['<html>', '<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>App</title>\n</head>\n<body>\n\n</body>\n</html>'],
    ['<style>', '<style>\n\n</style>'], ['<script>', '<script>\n\n<\/script>'],
    ['<div>', '<div class="">\n\n</div>'], ['<a>', '<a href="">Link</a>'],
    ['<meta>', '<meta name="viewport" content="width=device-width, initial-scale=1.0">']
  ];
  function vEditor() {
    var p = cur();
    if (!p || !p.files) return bar('Editor') + '<div class="empty"><p>Project not found</p></div>';
    if (!p.files[ED.file]) ED.file = p.main;
    var files = Object.keys(p.files).sort();
    var explorer = ED.explorer ? '<aside class="explorer"><header>' + ic('folder') + '<span>Files</span><button class="ib" style="width:32px;height:32px" data-action="newFile" aria-label="New file">' + ic('add', 'ico sm') + '</button></header>' +
      files.map(function (n) {
        return '<div class="fitem' + (n === ED.file ? ' act' : '') + '" role="button" tabindex="0" data-action="openFile" data-name="' + esc(n) + '">' + ic('file', 'ico sm') + '<span>' + esc(n) + '</span>' + (n !== p.main ? '<button class="x ib" style="width:22px;height:22px" data-action="delFile" data-name="' + esc(n) + '" aria-label="Delete ' + esc(n) + '">' + ic('close', 'ico sm x') + '</button>' : '') + '</div>';
      }).join('') + '</aside>' : '';
    return bar(p.name, ED.file,
      ib('toggleExplorer', 'folder', 'Files') + ib('find', 'search', 'Find') + ib('save', 'save', 'Save') + ib('edMenu', 'more', 'More')) +
      '<div class="ed-body">' + explorer +
      '<div class="ed-main"><div class="snips">' +
      SNIPS.map(function (s, i) { return '<button class="chip" data-action="snip" data-i="' + i + '">' + esc(s[0]) + '</button>'; }).join('') +
      '</div><div class="codewrap"><div class="gutter" id="gut"></div><textarea id="ta" spellcheck="false" autocomplete="off" autocapitalize="off" aria-label="Code editor">' + esc(p.files[ED.file] || '') + '</textarea></div></div></div>';
  }
  function setDirty(d) {
    ED.dirty = d;
    var sub = $('#bar-sub');
    if (sub) sub.textContent = ED.file + (d ? ' •' : '');
  }
  function gutter() {
    var ta = $('#ta'), gut = $('#gut');
    if (!ta || !gut) return;
    var lines = ta.value.split('\n').length;
    var h = '';
    for (var i = 1; i <= lines; i++) h += i + '\n';
    gut.textContent = h;
  }
  function saveNow(silent) {
    var p = cur(); if (!p) return;
    var ta = $('#ta');
    if (ta) {
      p.files[ED.file] = ta.value;
      p.updated = Date.now();
      setDirty(false);
      saveState();
      if (!silent) toast('Saved', 'ok');
    }
  }
  function mountEditor() {
    gutter();
    var ta = $('#ta');
    if (ta) {
      ta.addEventListener('scroll', function () { var g = $('#gut'); if (g) g.scrollTop = ta.scrollTop; });
    }
  }
  function insertAtCursor(text) {
    var ta = $('#ta'); if (!ta) return;
    var start = ta.selectionStart, end = ta.selectionEnd;
    ta.value = ta.value.slice(0, start) + text + ta.value.slice(end);
    ta.selectionStart = ta.selectionEnd = start + text.length;
    ta.focus();
    setDirty(true);
    gutter();
  }
  function findDlg() {
    dialog({
      title: 'Find in file',
      body: '<input class="input" id="dlg-in" placeholder="Search text..." aria-label="Search">',
      actions: [{ label: 'Cancel' }, { label: 'Find', primary: true, run: function () {
        var q = $('#dlg-in').value; if (!q) return;
        var ta = $('#ta'); if (!ta) return;
        var idx = ta.value.indexOf(q, ta.selectionEnd);
        if (idx < 0) idx = ta.value.indexOf(q);
        if (idx < 0) { toast('Not found', 'err'); return; }
        ta.focus(); ta.setSelectionRange(idx, idx + q.length);
        var line = ta.value.slice(0, idx).split('\n').length;
        ta.scrollTop = (line - 3) * 18;
      } }]
    });
  }

  /* ---------- preview ---------- */
  function vPreview() {
    var p = cur();
    if (!p) return bar('Preview') + '<div class="empty"><p>Project not found</p></div>';
    var devices = [['auto', 'Auto'], ['phone', 'Phone'], ['tablet', 'Tablet']];
    return (PV.full ? '' :
      bar('Preview: ' + p.name, '', ib('net', PV.online ? 'wifi' : 'wifiOff', 'Toggle network', { cls: PV.online ? '' : 'acc' }) + ib('console', 'terminal', 'Console') + ib('reload', 'refresh', 'Reload') + ib('full', 'full', 'Fullscreen'))) +
      '<div class="pv' + (PV.full ? ' full' : '') + '">' +
      (PV.online ? '' : '<div class="pv-off">Offline — page hidden</div>') +
      '<div class="pv-frame ' + PV.device + '" id="pv-frame"><iframe id="pv-iframe" sandbox="allow-scripts allow-same-origin allow-forms allow-modals" title="Live preview"></iframe></div>' +
      (PV.console ? '<div class="pv-console"><header>Console <button class="btn text sm" data-action="clearLogs">Clear</button></header><div id="pv-logs"></div></div>' : '') +
      (PV.full ? '<button class="fab" data-action="full" aria-label="Exit fullscreen" style="bottom:20px">' + ic('close') + '</button>' : '') +
      '<div class="pv-devices">' + devices.map(function (d) {
        return '<button class="chip' + (PV.device === d[0] ? ' act' : '') + '" data-action="device" data-id="' + d[0] + '">' + d[1] + '</button>';
      }).join('') + '</div></div>';
  }
  function mountPreview() {
    var p = cur(); if (!p || !PV.online) return;
    var iframe = $('#pv-iframe'); if (!iframe) return;
    var html = p.files[p.main] || '';
    var css = p.files['style.css'] || p.files['styles.css'] || '';
    var js = p.files['script.js'] || p.files['main.js'] || p.files['app.js'] || '';
    Object.keys(p.files).forEach(function (n) {
      if (/\.css$/i.test(n) && n !== 'style.css' && n !== 'styles.css') css += '\n' + p.files[n];
      if (/\.js$/i.test(n) && n !== 'script.js' && n !== 'main.js' && n !== 'app.js' && n !== p.main) js += '\n' + p.files[n];
    });
    var src = html;
    if (css && src.indexOf('</head>') >= 0) src = src.replace('</head>', '<style>' + css + '</style></head>');
    else if (css) src = '<style>' + css + '</style>' + src;
    if (js && src.indexOf('</body>') >= 0) src = src.replace('</body>', '<script>' + js + '<\/script></body>');
    else if (js) src += '<script>' + js + '<\/script>';
    iframe.srcdoc = src;
    PV.logs = [];
    renderLogs();
    try {
      iframe.onload = function () {
        try {
          var w = iframe.contentWindow;
          var orig = w.console.log;
          w.console.log = function () {
            var args = Array.prototype.slice.call(arguments).map(String).join(' ');
            PV.logs.push({ t: 'log', m: args });
            renderLogs();
            if (orig) orig.apply(w.console, arguments);
          };
        } catch (e) {}
      };
    } catch (e) {}
  }
  function renderLogs() {
    var el = $('#pv-logs'); if (!el) return;
    el.innerHTML = PV.logs.map(function (l) { return '<div class="' + l.t + '">' + esc(l.m) + '</div>'; }).join('') || '<div class="dim">No output yet</div>';
    el.scrollTop = el.scrollHeight;
  }

  /* ---------- builder ---------- */
  function proLock(title, body) {
    if (isPro()) return body;
    return '<div class="locked">' + body + '<div class="lock-overlay" data-action="paywall">' + ic('lock') + '<span>Pro feature</span></div></div>';
  }
  function vBuilder() {
    var p = cur(); if (!p) return bar('Builder') + '<div class="empty"><p>Project not found</p></div>';
    var c = p.cfg;
    var colors = ['#38bdf8', '#22c55e', '#f59e0b', '#ef4444', '#a78bfa', '#ec4899', '#14b8a6', '#f97316'];
    var orients = [['auto', 'Auto'], ['portrait', 'Portrait'], ['landscape', 'Landscape']];
    var perms = ['INTERNET', 'CAMERA', 'ACCESS_FINE_LOCATION', 'RECORD_AUDIO', 'WRITE_EXTERNAL_STORAGE', 'READ_EXTERNAL_STORAGE'];
    return bar('Build Config') + '<div class="scroll"><div class="pad" style="padding-bottom:32px">' +
      '<div class="h3" style="margin-top:8px">App Identity</div>' +
      '<label class="field"><span>App Name</span><input class="input" id="b-name" value="' + esc(c.appName) + '"></label>' +
      proLock('Package', '<label class="field"><span>Package Name</span><input class="input" id="b-pkg" value="' + esc(c.pkg) + '"' + (isPro() ? '' : ' disabled') + '></label>') +
      '<div class="row"><label class="field" style="flex:1"><span>Version Name</span><input class="input" id="b-vn" value="' + esc(c.vName) + '"></label>' +
      '<label class="field" style="flex:1"><span>Version Code</span><input class="input" id="b-vc" type="number" min="1" value="' + c.vCode + '"></label></div>' +
      '<div class="h3">Theme Color</div><div class="colors">' + colors.map(function (col) {
        return '<button class="swatch' + (c.color === col ? ' act' : '') + '" style="background:' + col + '" data-action="color" data-c="' + col + '" aria-label="' + col + '"></button>';
      }).join('') + '</div>' +
      '<div class="h3">Options</div>' +
      '<button class="tog' + (c.dark ? ' on' : '') + '" data-action="tog" data-key="dark"><span>Dark Theme Status Bar</span><i></i></button>' +
      '<button class="tog' + (c.full ? ' on' : '') + '" data-action="tog" data-key="full"><span>Fullscreen</span><i></i></button>' +
      '<button class="tog' + (c.desktop ? ' on' : '') + '" data-action="tog" data-key="desktop"><span>Desktop Mode Support</span><i></i></button>' +
      '<div class="h3">Orientation</div><div class="row">' + orients.map(function (o) {
        return '<button class="chip' + (c.orient === o[0] ? ' act' : '') + '" data-action="orient" data-o="' + o[0] + '">' + o[1] + '</button>';
      }).join('') + '</div>' +
      proLock('Custom App Icon', '<button class="icon-row" data-action="icon"><span class="box">' + ic(c.icon ? 'check' : 'add') + '</span><span class="t">App Launcher Icon (PNG)<small>' + (c.icon ? 'Icon selected' : 'Tap to choose from gallery') + '</small></span></button>') +
      proLock('Permissions', '<div class="h3">Permissions</div>' + perms.map(function (n) {
        var on = c.perms.indexOf(n) >= 0;
        var locked = n !== 'INTERNET' && !isPro();
        return '<button class="tog' + (on ? ' on' : '') + (locked ? ' dim' : '') + '" data-action="tog" data-key="perm:' + n + '"' + (locked ? ' disabled' : '') + '><span>' + n + '</span><i></i></button>';
      }).join('')) +
      '<div style="height:20px"></div><button class="btn block" data-action="proceed" style="padding:16px">' + ic('build') + ' Proceed to Export</button></div></div>';
  }
  function readCfg() {
    var c = cur().cfg;
    c.appName = ($('#b-name').value.trim() || c.appName);
    if (isPro() && $('#b-pkg')) c.pkg = ($('#b-pkg').value.trim() || c.pkg);
    c.vName = ($('#b-vn').value.trim() || c.vName);
    c.vCode = parseInt($('#b-vc').value, 10) || c.vCode;
    if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/.test(c.pkg)) { toast('Invalid package name. Use lowercase, e.g. com.mycompany.myapp', 'err'); return false; }
    saveState();
    return true;
  }

  /* ---------- export ---------- */
  function buildAndroidProject(p) {
    var c = p.cfg;
    var pkgPath = c.pkg.replace(/\./g, '/');
    var files = {};
    Object.keys(p.files).forEach(function (n) {
      files['app/src/main/assets/www/' + n] = p.files[n];
    });
    files['settings.gradle.kts'] = 'pluginManagement {\n  repositories { google(); mavenCentral(); gradlePluginPortal() }\n}\ndependencyResolutionManagement {\n  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)\n  repositories { google(); mavenCentral() }\n}\nrootProject.name = "' + c.appName.replace(/"/g, '') + '"\ninclude(":app")\n';
    files['build.gradle.kts'] = 'plugins {\n  id("com.android.application") version "8.2.0" apply false\n  id("org.jetbrains.kotlin.android") version "1.9.22" apply false\n}\n';
    files['gradle.properties'] = 'org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nkotlin.code.style=official\nandroid.nonTransitiveRClass=true\n';
    files['app/build.gradle.kts'] =
      'plugins {\n  id("com.android.application")\n  id("org.jetbrains.kotlin.android")\n}\n\nandroid {\n  namespace = "' + c.pkg + '"\n  compileSdk = 34\n\n  defaultConfig {\n    applicationId = "' + c.pkg + '"\n    minSdk = 24\n    targetSdk = 34\n    versionCode = ' + c.vCode + '\n    versionName = "' + c.vName + '"\n  }\n\n  buildTypes {\n    release {\n      isMinifyEnabled = false\n      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")\n    }\n  }\n  compileOptions {\n    sourceCompatibility = JavaVersion.VERSION_17\n    targetCompatibility = JavaVersion.VERSION_17\n  }\n  kotlinOptions { jvmTarget = "17" }\n}\n\ndependencies {\n  implementation("androidx.core:core-ktx:1.12.0")\n  implementation("androidx.appcompat:appcompat:1.6.1")\n  implementation("com.google.android.material:material:1.11.0")\n}\n';
    files['app/proguard-rules.pro'] = '# Add project specific ProGuard rules here.\n';
    var permXml = c.perms.map(function (x) { return '    <uses-permission android:name="android.permission.' + x + '" />'; }).join('\n');
    var orient = c.orient === 'portrait' ? 'portrait' : c.orient === 'landscape' ? 'landscape' : 'unspecified';
    var appLabel = String(c.appName).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    files['app/src/main/AndroidManifest.xml'] =
      '<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android">\n' + permXml + '\n  <application\n    android:allowBackup="true"\n    android:icon="@mipmap/ic_launcher"\n    android:label="' + appLabel + '"\n    android:supportsRtl="true"\n    android:theme="@style/Theme.App"\n    android:usesCleartextTraffic="true">\n    <activity\n      android:name=".MainActivity"\n      android:exported="true"\n      android:screenOrientation="' + orient + '"' + (c.full ? '\n      android:theme="@style/Theme.App.Fullscreen"' : '') + '>\n      <intent-filter>\n        <action android:name="android.intent.action.MAIN" />\n        <category android:name="android.intent.category.LAUNCHER" />\n      </intent-filter>\n    </activity>\n  </application>\n</manifest>\n';
    files['app/src/main/java/' + pkgPath + '/MainActivity.kt'] =
      'package ' + c.pkg + '\n\nimport android.annotation.SuppressLint\nimport android.os.Bundle\nimport android.webkit.WebChromeClient\nimport android.webkit.WebSettings\nimport android.webkit.WebView\nimport android.webkit.WebViewClient\nimport androidx.appcompat.app.AppCompatActivity\n\nclass MainActivity : AppCompatActivity() {\n  @SuppressLint("SetJavaScriptEnabled")\n  override fun onCreate(savedInstanceState: Bundle?) {\n    super.onCreate(savedInstanceState)\n    val webView = WebView(this)\n    setContentView(webView)\n    webView.webViewClient = WebViewClient()\n    webView.webChromeClient = WebChromeClient()\n    val s: WebSettings = webView.settings\n    s.javaScriptEnabled = true\n    s.domStorageEnabled = true\n    s.allowFileAccess = true\n    s.mediaPlaybackRequiresUserGesture = false\n    webView.loadUrl("file:///android_asset/www/' + p.main + '")\n  }\n}\n';
    files['app/src/main/res/values/themes.xml'] =
      '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n  <style name="Theme.App" parent="Theme.MaterialComponents.DayNight.NoActionBar">\n    <item name="colorPrimary">' + c.color + '</item>\n    <item name="colorPrimaryVariant">' + c.color + '</item>\n    <item name="android:statusBarColor">' + (c.dark ? '#0f172a' : c.color) + '</item>\n  </style>\n  <style name="Theme.App.Fullscreen" parent="Theme.App">\n    <item name="android:windowFullscreen">true</item>\n  </style>\n</resources>\n';
    files['app/src/main/res/values/strings.xml'] =
      '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n  <string name="app_name">' + appLabel + '</string>\n</resources>\n';
    files['README.md'] =
      '# ' + c.appName + '\n\nAndroid project generated by **OmniWeb Studio**.\n\n## Open in Android Studio\n1. Unzip this archive\n2. Open the folder in Android Studio\n3. Let Gradle sync\n4. Run on emulator or device\n\n## Build APK (CLI)\n```bash\n./gradlew assembleRelease\n```\n\nPackage: `' + c.pkg + '`  \nVersion: ' + c.vName + ' (' + c.vCode + ')\n';
    files['.github/workflows/build.yml'] =
      'name: Build APK\non:\n  push:\n    branches: [ main ]\n  workflow_dispatch:\njobs:\n  build:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: 17\n      - name: Setup Gradle\n        uses: gradle/actions/setup-gradle@v3\n      - name: Build Release APK\n        run: ./gradlew assembleRelease\n      - uses: actions/upload-artifact@v4\n        with:\n          name: app-release\n          path: app/build/outputs/apk/release/*.apk\n';
    return files;
  }

  function vExport() {
    var p = cur(), c = p.cfg;
    var head = bar('Export & Build') + '<div class="scroll"><div class="pad" style="padding-bottom:28px"><div class="card sum"><h2>' + esc(p.name) + '</h2><p>' + esc(c.pkg) + ' · v' + esc(c.vName) + ' (' + c.vCode + ')</p><span class="stat">' + ic('file') + Object.keys(p.files).length + ' files</span> <span class="stat">' + ic('archive') + fmt(bytes(p)) + '</span></div>';
    if (!EX.running) {
      return head +
        '<button class="card opt" data-action="exportZip"><span class="ic" style="background:rgba(34,197,94,.15);color:var(--ok)">' + ic('archive') + '</span><span class="t"><b>Export Web ZIP Bundle</b><span class="badge" style="background:rgba(34,197,94,.2);color:var(--ok)">FREE</span><p>Package project for web hosting or further editing</p></span></button>' +
        '<button class="card opt" data-action="exportAndroid"><span class="ic" style="background:rgba(56,189,248,.15);color:var(--acc)">' + ic('android') + '</span><span class="t"><b>Export Android Project</b><span class="badge" style="background:rgba(56,189,248,.2);color:var(--acc)">PRO</span><p>Android Studio project (Kotlin + WebView) with your app settings, plus a GitHub Actions workflow that builds the APK.</p></span>' + (isPro() ? '' : ic('lock', 'ico')) + '</button>' +
        '</div></div>';
    }
    return head + '<div style="font-size:13px;font-weight:500;color:' + (EX.done ? 'var(--ok)' : 'var(--acc)') + ';margin-bottom:8px">' + (EX.done ? 'Export complete' : 'Exporting...') + '</div><div class="prog"><i style="width:' + EX.pct + '%"></i></div>' +
      '<div class="term" id="term">' + EX.lines.map(function (l) { return '<div class="' + (l.charAt(0) === '\u2705' ? 'ok' : '') + '">' + esc(l) + '</div>'; }).join('') + '</div>' +
      (EX.done ? '<div class="done"><b>Export successful!</b><code>' + esc(EX.name) + '</code><div class="row"><button class="btn sm" data-action="doDownload">' + ic('download') + ' Download</button><button class="btn ghost sm" data-action="newExport">New Export</button></div></div>' : '') +
      '</div></div>';
  }
  var exTimers = [];
  function runExport(kind) {
    var p = cur(), c = p.cfg;
    var safe = function (s) { return String(s).trim().replace(/[^A-Za-z0-9._-]+/g, '_') || 'export'; };
    EX = { running: true, done: false, lines: [], pct: 0, kind: kind, name: kind === 'zip' ? safe(p.name) + '_web.zip' : safe(c.appName) + '_android_project.zip', blob: null };
    var steps = kind === 'zip'
      ? ['\ud83d\udce6 Packaging web project bundle...', '\ud83d\udcc2 Source: ' + Object.keys(p.files).length + ' files', '\ud83d\uddc4\ufe0f  Creating ZIP archive...']
      : ['\ud83d\ude80 Generating Android (Kotlin + WebView) project', '   App: ' + c.appName, '   Package: ' + c.pkg + '  v' + c.vName + ' (' + c.vCode + ')', '\ud83d\udcdd Writing Gradle & manifest files...', '\ud83d\udcc2 Copying web files into app/src/main/assets/www ...', '\ud83d\uddc4\ufe0f  Creating ZIP archive...'];
    steps.push('\u2705 Done: ' + EX.name);
    render();
    steps.forEach(function (line, i) {
      exTimers.push(setTimeout(function () {
        if (S.route.name !== 'export') return;
        EX.lines.push(line); EX.pct = Math.round(((i + 1) / steps.length) * 100);
        if (i === steps.length - 1) {
          EX.done = true;
          try {
            var payload = kind === 'zip' ? p.files : buildAndroidProject(p);
            EX.blob = makeZip(payload);
          } catch (err) {
            EX.lines.push('\u274c Export failed: ' + (err && err.message || 'unknown'));
            toast('Export failed', 'err');
          }
        }
        render();
        var t = $('#term'); if (t) t.scrollTop = t.scrollHeight;
      }, 380 * (i + 1)));
    });
  }

  /* ---------- paywall ---------- */
  function vPaywall() {
    if (isPro()) {
      return bar('OmniWeb Pro') + '<div class="proact"><div class="medal">' + ic('star') + '</div><h2>Pro Active!</h2><p>' + esc(S.proLabel || proRemaining()) + '</p></div>';
    }
    var bens = [
      ['app', 'Custom Package Name', 'Set your own com.yourname.app ID'],
      ['palette', 'Custom App Icons', 'Upload and inject launcher icons'],
      ['shield', 'Advanced Permissions', 'Camera, location, microphone, storage'],
      ['folder', 'Unlimited Projects', 'No project count restrictions'],
      ['android', 'Android Project Export', 'Buildable Android Studio project + APK workflow']
    ];
    return bar('Upgrade to Pro') + '<div class="scroll"><div class="pad" style="padding:16px 20px 40px">' +
      '<div class="hero">' + ic('star') + '<h2>Unlock OmniWeb Pro</h2><p>Everything you need to build and publish professional Android apps from your web projects.</p></div>' +
      '<div class="h3">Pro Benefits</div>' + bens.map(function (b) {
        return '<div class="ben"><span class="bi">' + ic(b[0]) + '</span><div><b>' + b[1] + '</b><span>' + b[2] + '</span></div>' + ic('check', 'ico ck') + '</div>';
      }).join('') +
      '<div class="h3">Choose Your Plan</div>' +
      '<button class="plan" data-action="buy" data-plan="month"><span class="t"><b>Monthly</b><small>/month</small></span><span class="pr">$4.99</span></button>' +
      '<button class="plan pop" data-action="buy" data-plan="life"><span class="t"><b>Lifetime<span class="tag">BEST VALUE</span></b><small>one-time</small></span><span class="pr">$19.99</span></button>' +
      '<div class="h3" style="font-size:14px;margin-top:20px">Have a Promo Code?</div><div class="row" style="align-items:center"><input class="input" id="promo" placeholder="Enter promo code" style="text-transform:uppercase" aria-label="Promo code"><button class="btn" data-action="promo" style="flex:none">Apply</button></div>' +
      '<div class="adbox"><div class="ben" style="margin-bottom:12px"><span class="bi">' + ic('video') + '</span><div><b>Watch an Ad, Get Pro Free</b><span>Unlock all Pro features for 2 hours</span></div></div><button class="btn ghost block" data-action="ad">' + ic('play') + ' Watch Ad</button></div>' +
      '<div style="text-align:center;margin-top:16px"><button class="btn text" data-action="restore">Restore Purchases</button></div>' +
      '</div></div>';
  }
  function setPro(opts) {
    if (opts.lifetime) {
      S.proLifetime = true;
      S.proUntil = 0;
      S.proLabel = opts.label || 'You have lifetime access to all Pro features.';
    } else {
      S.proLifetime = false;
      S.proUntil = opts.until || (Date.now() + AD_UNLOCK_MS);
      S.proLabel = opts.label || ('Temporary unlock');
    }
    saveState();
    closeOverlay();
    render();
    toast(opts.msg || 'Pro unlocked!', 'ok');
  }

  /* ---------- events ---------- */
  document.addEventListener('click', function (e) {
    var sh = e.target.closest('[data-sheet]');
    if (sh) { var items = $('#overlay').firstChild._items; closeOverlay(); items[+sh.dataset.sheet].run(); return; }
    var dl = e.target.closest('[data-dlg]');
    if (dl) {
      var acts = $('#overlay').firstChild._acts, a = acts[+dl.dataset.dlg];
      if (a.run) { a.run(); if ($('#overlay').firstChild && $('#overlay').firstChild._acts === acts) closeOverlay(); }
      else closeOverlay();
      return;
    }
    var t = e.target.closest('[data-action]'); if (!t) return;
    var act = t.dataset.action, id = +t.dataset.id;
    if (act === 'scrim') { if (e.target === t) closeOverlay(); return; }
    var A = {
      toggleView: function () { S.view = S.view === 'grid' ? 'list' : 'grid'; saveState(); render(); },
      create: createMenu,
      paywall: function () { nav('paywall'); },
      openEditor: function () { ED.file = proj(id).main; ED.explorer = false; nav('editor', { id: id }); },
      projMenu: function () { projMenu(proj(id)); },
      back: function () {
        if (S.route.name === 'editor') saveNow(true);
        exTimers.forEach(clearTimeout);
        EX = { running: false, lines: [], blob: null };
        back();
      },
      toggleExplorer: function () { saveNow(true); ED.explorer = !ED.explorer; render(); },
      find: findDlg,
      save: function () { saveNow(false); },
      edMenu: function () {
        saveNow(true); var pr = cur();
        sheet([
          { icon: 'play', label: 'Live Preview', run: function () { nav('preview', { id: pr.id }); } },
          { icon: 'build', label: 'Build / Export', run: function () { nav('builder', { id: pr.id }); } }
        ]);
      },
      snip: function () { insertAtCursor(SNIPS[+t.dataset.i][1]); },
      openFile: function () { saveNow(true); ED.file = t.dataset.name; render(); },
      newFile: function () {
        promptDlg('New File', 'File name (e.g., about.html)', '', 'Create', function (v) {
          var pr = cur();
          if (pr.files[v] != null) { toast(v + ' already exists', 'err'); return; }
          if (/[\\/]|\.\./.test(v)) { toast('Invalid file name', 'err'); return; }
          saveNow(true); pr.files[v] = ''; ED.file = v; saveState(); render(); toast('Created ' + v, 'ok');
        });
      },
      delFile: function () {
        var n = t.dataset.name; e.stopPropagation();
        dialog({
          title: 'Delete File', text: 'Delete ' + n + '?',
          actions: [{ label: 'Cancel' }, { label: 'Delete', danger: true, run: function () {
            var pr = cur(); delete pr.files[n]; if (ED.file === n) ED.file = pr.main; saveState(); render(); toast('File deleted', 'ok');
          } }]
        });
      },
      device: function () { PV.device = t.dataset.id; render(); },
      net: function () { PV.online = !PV.online; render(); },
      console: function () { PV.console = !PV.console; render(); },
      reload: function () { PV.logs = []; render(); },
      full: function () { PV.full = !PV.full; render(); },
      clearLogs: function () { PV.logs = []; renderLogs(); },
      tog: function () {
        var c = cur().cfg, k = t.dataset.key;
        if (k.indexOf('perm:') === 0) {
          var n = k.slice(5), i = c.perms.indexOf(n);
          if (i >= 0) { if (n !== 'INTERNET') c.perms.splice(i, 1); }
          else c.perms.push(n);
        } else c[k] = !c[k];
        saveState();
        keepScroll(render);
      },
      color: function () { cur().cfg.color = t.dataset.c; saveState(); keepScroll(render); },
      orient: function () { cur().cfg.orient = t.dataset.o; saveState(); keepScroll(render); },
      icon: function () {
        if (!isPro()) { nav('paywall'); return; }
        cur().cfg.icon = !cur().cfg.icon;
        saveState();
        keepScroll(render);
        toast(cur().cfg.icon ? 'Icon marked as selected' : 'Icon cleared', 'ok');
      },
      saveCfg: function () { if (readCfg()) toast('Build configuration saved', 'ok'); },
      proceed: function () { if (readCfg()) { EX = { running: false, lines: [], blob: null }; nav('export', { id: S.route.id }); } },
      exportZip: function () { runExport('zip'); },
      exportAndroid: function () { if (!isPro()) nav('paywall'); else runExport('android'); },
      newExport: function () { EX = { running: false, lines: [], blob: null }; render(); },
      doDownload: function () {
        if (EX.blob) {
          downloadBlob(EX.blob, EX.name);
          toast('Download started', 'ok');
        } else toast('Nothing to download', 'err');
      },
      buy: function () {
        var life = t.dataset.plan === 'life';
        if (life) {
          setPro({ lifetime: true, label: 'You have lifetime access to all Pro features.', msg: 'Pro unlocked permanently!' });
        } else {
          setPro({ until: Date.now() + 30 * 24 * 60 * 60 * 1000, label: 'Monthly plan active for 30 days.', msg: 'Pro unlocked for 30 days!' });
        }
      },
      promo: function () {
        var v = ($('#promo').value || '').trim().toUpperCase();
        if (v === 'OMNIWEB' || v === 'PRO2024') {
          setPro({ lifetime: true, label: 'You have lifetime access to all Pro features.', msg: 'Promo code accepted!' });
        } else toast('Invalid promo code.', 'err');
      },
      restore: function () {
        if (isPro()) toast('Pro is already active.', 'ok');
        else toast('No previous purchases found.', 'err');
      },
      ad: function () {
        var left = 3;
        dialog({ title: 'Watching Ad...', body: '<p id="ad-t">Reward will be available in 3 seconds.</p>', actions: [{ label: 'Please wait...' }] });
        var iv = setInterval(function () {
          var el = $('#ad-t'); if (!el) { clearInterval(iv); return; }
          left--;
          if (left > 0) { el.textContent = 'Reward will be available in ' + left + ' seconds.'; return; }
          clearInterval(iv);
          dialog({
            title: 'Ad Complete!',
            body: '<p>Tap below to unlock Pro features for <b>2 hours</b>.</p>',
            actions: [{
              label: 'Claim Reward', primary: true, run: function () {
                setPro({
                  until: Date.now() + AD_UNLOCK_MS,
                  label: 'Temporary unlock — expires in 2 hours.',
                  msg: 'Pro features unlocked for 2 hours!'
                });
              }
            }]
          });
        }, 1000);
      }
    };
    if (A[act]) A[act]();
  });

  function keepScroll(fn) {
    var sc = $('.scroll'), y = sc ? sc.scrollTop : 0;
    fn(); sc = $('.scroll'); if (sc) sc.scrollTop = y;
  }

  document.addEventListener('keydown', function (e) {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('[role=button][data-action]')) { e.preventDefault(); e.target.click(); }
    if (e.key === 'Escape') closeOverlay();
  });

  document.addEventListener('input', function (e) {
    if (e.target.id === 'q') {
      S.q = e.target.value; renderList();
    } else if (e.target.id === 'ta') {
      gutter(); setDirty(true);
      clearTimeout(ED.saveTimer);
      ED.saveTimer = setTimeout(function () { saveNow(true); }, 900);
    }
  });
  document.addEventListener('scroll', function (e) {
    if (e.target && e.target.id === 'ta') { var g = $('#gut'); if (g) g.scrollTop = e.target.scrollTop; }
  }, true);
  document.addEventListener('keydown', function (e) {
    if (e.target.id === 'ta' && e.key === 'Tab') { e.preventDefault(); insertAtCursor('  '); }
  });

  var baseRender = render;
  render = function () { baseRender(); if (S.route.name === 'dashboard') renderList(); };

  setInterval(function () {
    if (S.proUntil && Date.now() >= S.proUntil && !S.proLifetime) {
      S.proUntil = 0; S.proLabel = '';
      saveState();
      if (S.route.name === 'dashboard' || S.route.name === 'paywall') render();
    }
  }, 30000);

  render();
})();
