const $ = (id) => document.getElementById(id);

const suggestions = {
  "يومي": {
    "معتدل": ["تيشيرت سادة أبيض أو زيتي", "جينز أزرق أو أسود", "كوتشي أبيض", "ساعة بسيطة أو قميص مفتوح"],
    "حار": ["تيشيرت قطني فاتح", "بنطلون خفيف أو جينز فاتح", "حذاء خفيف ومريح", "كاب ونظارة شمسية"],
    "بارد": ["سويت شيرت أو تيشيرت مع طبقة دافئة", "جينز غامق", "كوتشي مغلق", "جاكيت مناسب للجو"]
  },
  "شغل": {
    "معتدل": ["قميص سادة أو بولو", "بنطلون قماش أو تشينو", "حذاء بسيط ونظيف", "ساعة أو حزام بلون متناسق"],
    "حار": ["قميص قطني فاتح", "بنطلون خفيف بلون محايد", "حذاء خفيف أنيق", "إكسسوار بسيط"],
    "بارد": ["قميص مع بلوفر خفيف", "بنطلون قماش غامق", "حذاء مغلق", "جاكيت أو بليزر"]
  },
  "رسمي": {
    "معتدل": ["قميص أبيض أو سماوي", "بنطلون قماش غامق", "حذاء رسمي نظيف", "بليزر وحزام متناسق"],
    "حار": ["قميص خفيف بلون فاتح", "بنطلون قماش خفيف", "حذاء رسمي مريح", "ساعة بسيطة"],
    "بارد": ["قميص مع بليزر أو بدلة", "بنطلون بدلة متناسق", "حذاء رسمي", "معطف أنيق إذا لزم"]
  },
  "رياضة": {
    "معتدل": ["تيشيرت رياضي مريح", "بنطلون رياضي", "حذاء رياضي مناسب", "زجاجة مياه"],
    "حار": ["تيشيرت رياضي خفيف", "شورت أو بنطلون خفيف", "حذاء جيد التهوية", "كاب عند ممارسة الرياضة بالخارج"],
    "بارد": ["طبقة رياضية طويلة", "بنطلون رياضي", "حذاء رياضي", "جاكيت خفيف للإحماء"]
  },
  "منزل": {
    "معتدل": ["تيشيرت قطني مريح", "بنطلون منزلي", "شبشب مريح", "اختار ألوان بتحبها"],
    "حار": ["تيشيرت خفيف", "شورت قطني", "شبشب خفيف", "خامة تسمح بمرور الهواء"],
    "بارد": ["بلوفر مريح", "بنطلون منزلي دافئ", "شبشب مغلق", "جوارب دافئة"]
  }
};

const tips = [
  "نصيحة: خليك في لونين أو ثلاثة متناسقين.",
  "نصيحة: اختار الراحة والمقاس المناسب قبل اتباع الموضة.",
  "نصيحة: الألوان المحايدة زي الأبيض والأسود والبيج سهلة التنسيق.",
  "نصيحة: المناسبة ونوع القماش مهمين زي اللون تمامًا."
];

$("suggestBtn").addEventListener("click", () => {
  const occasion = $("occasion").value;
  const weather = $("weather").value;
  const outfit = suggestions[occasion][weather];
  $("resultTitle").textContent = `تنسيق مناسب لـ${occasion}`;
  $("topSuggestion").textContent = outfit[0];
  $("bottomSuggestion").textContent = outfit[1];
  $("shoeSuggestion").textContent = outfit[2];
  $("extraSuggestion").textContent = outfit[3];
  $("tip").textContent = tips[Math.floor(Math.random() * tips.length)];
});

const STORAGE_KEY = "labsEhWardrobeV1";
let wardrobe = [];

function loadWardrobe() {
  try {
    wardrobe = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    wardrobe = [];
  }
  renderWardrobe();
}

function saveWardrobe() {
  // الصور الكبيرة قد تتجاوز مساحة التخزين؛ نحتفظ بالوصف حتى لو تعذر حفظ صورة.
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(wardrobe));
  } catch {
    wardrobe = wardrobe.map(item => ({ ...item, photo: "" }));
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(wardrobe)); } catch {}
    alert("مساحة حفظ الصور غير كافية؛ تم الاحتفاظ بأوصاف القطع فقط.");
  }
}

function renderWardrobe() {
  const list = $("wardrobeList");
  list.replaceChildren();
  if (!wardrobe.length) {
    const p = document.createElement("p");
    p.className = "empty-state";
    p.textContent = "لسه مفيش قطع مضافة. ابدأ بقطعة بتحبها.";
    list.appendChild(p);
    return;
  }
  wardrobe.forEach(item => {
    const card = document.createElement("article");
    card.className = "wardrobe-item";
    if (item.photo) {
      const img = document.createElement("img");
      img.src = item.photo;
      img.alt = item.description;
      card.appendChild(img);
    } else {
      const icon = document.createElement("div");
      icon.className = "placeholder";
      icon.textContent = item.type === "بنطلون" ? "👖" : item.type === "حذاء" ? "👟" : item.type === "إكسسوار" ? "⌚" : item.type === "جاكيت" ? "🧥" : "👕";
      card.appendChild(icon);
    }
    const info = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = item.description;
    const type = document.createElement("small");
    type.textContent = item.type;
    const remove = document.createElement("button");
    remove.className = "delete-item";
    remove.type = "button";
    remove.textContent = "حذف";
    remove.addEventListener("click", () => {
      wardrobe = wardrobe.filter(x => x.id !== item.id);
      saveWardrobe();
      renderWardrobe();
    });
    info.append(name, type, document.createElement("br"), remove);
    card.appendChild(info);
    list.appendChild(card);
  });
}

$("itemForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const description = $("itemDescription").value.trim();
  if (!description) return;
  const file = $("itemPhoto").files[0];
  let photo = "";
  if (file && file.type.startsWith("image/")) {
    if (file.size > 1.5 * 1024 * 1024) {
      alert("اختار صورة أصغر من 1.5 ميجابايت عشان تفضل محفوظة على الجهاز.");
      return;
    }
    photo = await new Promise(resolve => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => resolve("");
      reader.readAsDataURL(file);
    });
  }
  wardrobe.unshift({
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    type: $("itemType").value,
    description,
    photo
  });
  saveWardrobe();
  renderWardrobe();
  event.target.reset();
});

loadWardrobe();
