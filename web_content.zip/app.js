const $=id=>document.getElementById(id);
const STORAGE="moiz_ai_workspace_v1";
let state={chats:[],currentId:null,mode:"cloud",page:"chat",cities:[]};
let settings={apiKey:"",model:"gemini-2.5-flash"};
function load(){
 try{const s=JSON.parse(localStorage.getItem(STORAGE)||"{}");state={...state,...s};}catch(e){}
 try{settings={...settings,...JSON.parse(localStorage.getItem("moiz_ai_settings_v1")||"{}")};}catch(e){}
 $("apiKey").value=settings.apiKey||"";$("modelName").value=settings.model||"gemini-2.5-flash";
 if(!state.currentId||!state.chats.find(c=>c.id===state.currentId))newChat(false);
 renderAll();
}
function persist(){try{localStorage.setItem(STORAGE,JSON.stringify(state));}catch(e){alert("Device storage is full. Export chats and remove old conversations.");}}
function persistSettings(){try{localStorage.setItem("moiz_ai_settings_v1",JSON.stringify(settings));}catch(e){alert("Could not save settings in this browser.");}}
function current(){return state.chats.find(c=>c.id===state.currentId);}
function newChat(save=true){const c={id:Date.now().toString()+Math.random().toString(16).slice(2,6),title:"New chat",mode:state.mode,messages:[],updated:Date.now()};state.chats.unshift(c);state.currentId=c.id;if(save)persist();renderAll();showPage("chat");}
function titleFrom(t){return t.length>34?t.slice(0,34)+"…":t;}
function renderAll(){renderHistory();renderMessages();renderSaved();renderCities();updateMode();}
function renderHistory(){const el=$("history");el.innerHTML="";state.chats.slice(0,30).forEach(c=>{const b=document.createElement("button");b.textContent=c.title;b.className=c.id===state.currentId?"selected":"";b.onclick=()=>{state.currentId=c.id;state.mode=c.mode||"cloud";persist();renderAll();showPage("chat");};el.appendChild(b);});}
function renderMessages(){const el=$("chatMessages");el.innerHTML="";const c=current();if(!c||!c.messages.length){const w=document.createElement("div");w.className="welcome";w.innerHTML='<div class="welcome-mark">✳</div><h1>What can I help with?</h1><p>Choose Cloud AI or Offline AI, then ask anything.</p><div class="suggestions"><button class="suggestion" data-prompt="Explain a difficult topic in simple words.">✧ Explain something</button><button class="suggestion" data-prompt="Help me plan my day.">▦ Plan my day</button><button class="suggestion" data-prompt="Write a professional message for me.">✎ Write a message</button></div>';el.appendChild(w);w.querySelectorAll("[data-prompt]").forEach(b=>b.onclick=()=>{$("prompt").value=b.dataset.prompt;$("prompt").focus();});return;}
 c.messages.forEach(m=>{const wrap=document.createElement("div");wrap.className="message "+m.role;const content=document.createElement("div");const label=document.createElement("div");label.className="msg-label";label.textContent=m.role==="user"?"You":(m.mode==="offline"?"Offline AI":"Cloud AI");const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=m.text;content.append(label,bubble);wrap.appendChild(content);el.appendChild(wrap);});el.scrollTop=el.scrollHeight;}
function updateMode(){document.querySelectorAll(".mode").forEach(b=>b.classList.toggle("active",b.dataset.mode===state.mode));$("modeHint").textContent=state.mode==="cloud"?"Cloud mode selected · uses internet":"Offline mode selected · no cloud request";$("composeMode").textContent=state.mode==="cloud"?"Cloud AI mode":"Offline AI mode";}
function setMode(mode){state.mode=mode;const c=current();if(c)c.mode=mode;persist();updateMode();}
document.querySelectorAll(".mode").forEach(b=>b.onclick=()=>setMode(b.dataset.mode));
async function send(){
 const prompt=$("prompt").value.trim();if(!prompt)return;
 const c=current();if(!c)return;
 c.mode=state.mode;c.messages.push({role:"user",text:prompt,mode:state.mode});if(c.title==="New chat")c.title=titleFrom(prompt);c.updated=Date.now();$("prompt").value="";persist();renderAll();
 const placeholder={role:"assistant",text:"Thinking…",mode:state.mode};c.messages.push(placeholder);renderMessages();
 try{
  let answer;
  if(state.mode==="offline"){
   answer=await offlineReply(prompt);
  }else{
   if(!settings.apiKey)throw new Error("Add your Gemini API key once in Settings before using Cloud AI.");
   const endpoint=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(settings.model)}:generateContent`;
   const res=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":settings.apiKey},body:JSON.stringify({contents:[{parts:[{text:prompt}]}]})});
   const data=await res.json();if(!res.ok)throw new Error(data?.error?.message||`Gemini error ${res.status}`);
   answer=data?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("")||"Gemini returned no response.";
  }
  placeholder.text=answer;
 }catch(e){placeholder.text=(state.mode==="cloud"?"Cloud AI error: ":"Offline AI: ")+e.message;}
 c.updated=Date.now();persist();renderAll();
}
async function offlineReply(prompt){
 // Honest local demo responses: no model or internet call is used here.
 const p=prompt.toLowerCase();
 if(p.includes("time")||p.includes("date"))return "Offline mode is active. I cannot access live time or external information in this demo.";
 if(p.includes("hello")||p.includes("hi"))return "Hello! Offline mode is active. A real on-device language model is not installed yet, so my offline abilities are limited.";
 return "Your message was processed in Offline mode without using the internet. However, this prototype does not yet include a local AI model, so it cannot generate a full intelligent answer. To enable real offline answers, we must integrate and bundle/download an on-device model.";
}
$("send").onclick=send;$("prompt").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}});
$("newChat").onclick=()=>newChat();
function showPage(page){state.page=page;document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$(page+"Page").classList.add("active");document.querySelectorAll(".nav-item[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===page));$("pageTitle").textContent=page==="chat"?"Chat":page==="maps"?"Maps":"Saved chats";$("subtitle").textContent=page==="chat"?"Your AI workspace":page==="maps"?"Offline map tools":"Conversations on this device";if(page==="saved")renderSaved();closeSidebar();}
document.querySelectorAll(".nav-item[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function renderSaved(){const el=$("savedList");if(!el)return;el.innerHTML="";if(!state.chats.length){el.textContent="No saved chats yet.";return;}state.chats.forEach(c=>{const row=document.createElement("div");row.className="saved-card";const info=document.createElement("div");const b=document.createElement("b");b.textContent=c.title;const sm=document.createElement("small");sm.textContent=`${c.messages.length} messages · ${c.mode==="offline"?"Offline":"Cloud"} · ${new Date(c.updated).toLocaleString()}`;info.append(b,sm);const open=document.createElement("button");open.textContent="Open";open.onclick=()=>{state.currentId=c.id;state.mode=c.mode||"cloud";persist();renderAll();showPage("chat");};row.append(info,open);el.appendChild(row);});}
function renderCities(){const el=$("cityList");if(!el)return;el.innerHTML="";if(!state.cities.length){el.innerHTML='<p class="empty">No city packages saved yet.</p>';return;}state.cities.forEach(city=>{const d=document.createElement("div");d.className="city-item";d.textContent=city+" — demo record (real map package not downloaded)";el.appendChild(d);});}
$("addCity").onclick=()=>{const name=$("cityInput").value.trim();if(!name)return;if(!state.cities.some(c=>c.toLowerCase()===name.toLowerCase()))state.cities.push(name);$("cityInput").value="";persist();renderCities();};
$("mapSearch").onclick=()=>{const q=$("placeQuery").value.trim();$("mapOutput").textContent=!q?"Enter a place to search.":!state.cities.length?"Add a city first. Real offline map search requires actual downloaded map data.":`Demo search for "${q}" in ${state.cities.join(", ")}. Real geospatial search is not yet integrated.`;};
$("locate").onclick=()=>{if(!navigator.geolocation){$("gpsOutput").textContent="Geolocation is not supported by this browser.";return;}$("gpsOutput").textContent="Requesting device GPS…";navigator.geolocation.getCurrentPosition(p=>$("gpsOutput").textContent=`Latitude: ${p.coords.latitude}\nLongitude: ${p.coords.longitude}\nAccuracy: ±${Math.round(p.coords.accuracy)} metres`,e=>$("gpsOutput").textContent="Location error: "+e.message,{enableHighAccuracy:true,timeout:15000,maximumAge:5000});};
function openSettings(){$("settingsModal").classList.add("open");}
function closeSettings(){$("settingsModal").classList.remove("open");}
$("settingsOpen").onclick=openSettings;$("settingsOpenTop").onclick=openSettings;$("settingsClose").onclick=closeSettings;$("settingsModal").onclick=e=>{if(e.target===$("settingsModal"))closeSettings();};
$("saveSettings").onclick=()=>{settings.apiKey=$("apiKey").value.trim();settings.model=$("modelName").value.trim()||"gemini-2.5-flash";persistSettings();$("settingsStatus").textContent="Saved on this device. You only need to enter the key once in this browser/app installation.";};
$("exportChats").onclick=()=>{const blob=new Blob([JSON.stringify({chats:state.chats},null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="moiz-ai-chat-backup.json";a.click();URL.revokeObjectURL(a.href);};
function closeSidebar(){$("sidebar").classList.remove("open");$("scrim").classList.remove("show");}
$("menuBtn").onclick=()=>{$("sidebar").classList.add("open");$("scrim").classList.add("show");};$("closeSidebar").onclick=closeSidebar;$("scrim").onclick=closeSidebar;
load();
