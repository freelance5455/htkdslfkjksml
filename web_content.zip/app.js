/* =========================================================
   APP.JS — v7.0 (FIXED)
   Editor, Stage, Home, Settings — all wired safely.
   Every external dependency has a fallback. Zero console errors.
   ========================================================= */
(function () {
  'use strict';

  const S = window.ShapeStudio = window.ShapeStudio || {};

  /* =========================================================
     SAFE DEPENDENCIES
     ========================================================= */
  const SHAPES = Array.isArray(S.SHAPES) ? S.SHAPES : [];
  const LIBRARY_SHAPES = Array.isArray(S.LIBRARY_SHAPES) ? S.LIBRARY_SHAPES : [];
  const PALETTE = Array.isArray(S.PALETTE) ? S.PALETTE : [
    '#8b7cff','#7c9dff','#4dd4ff','#4dffcc','#9dff7c',
    '#d4ff5c','#ffd45c','#ff9d5c','#ff7c5c','#ff7c9d',
    '#ff7cff','#b87cff','#a0a0ff','#4dffcc','#c8ff5c'
  ];

  const settings = S.settings = S.settings || {
    controlMode: 'touch', autoSpeed: 0.7, glowStrength: 1, dotBrightness: 1,
    particleSize: 1, volume: 0.7, haptic: true, sound: false,
    quality: 'medium', theme: 'default', animations: true,
    animRipple: true, animBurst: true, animTrail: false, animConfetti: true,
    handTrack: false, rotationSpeed: 1.0, smoothing: 0.18,
    mirrorX: false, mirrorY: false, reduceMotion: false
  };

  if (!S.QUALITY_CFG) {
    S.QUALITY_CFG = {
      low:    { dpr: 1,    dotMult: 0.5, glowMult: 0.5, shadowMax: 4 },
      medium: { dpr: 1.25, dotMult: 1,   glowMult: 1,   shadowMax: 8 },
      high:   { dpr: 1.5,  dotMult: 1.5, glowMult: 1.3, shadowMax: 12 },
      ultra:  { dpr: 2,    dotMult: 2,   glowMult: 1.6, shadowMax: 16 }
    };
  }
  if (!S.qualityCfg) S.qualityCfg = S.QUALITY_CFG[settings.quality] || S.QUALITY_CFG.medium;

  const isOn = (typeof S.isFeatureOn === 'function') ? S.isFeatureOn : function () { return false; };

  const _sfx = S.SFX || {};
  const SFX = {
    tap:     typeof _sfx.tap === 'function'     ? () => _sfx.tap()     : () => {},
    click:   typeof _sfx.click === 'function'   ? () => _sfx.click()   : () => {},
    open:    typeof _sfx.open === 'function'    ? () => _sfx.open()    : () => {},
    close:   typeof _sfx.close === 'function'   ? () => _sfx.close()   : () => {},
    hover:   typeof _sfx.hover === 'function'   ? () => _sfx.hover()   : () => {},
    success: typeof _sfx.success === 'function' ? () => _sfx.success() : () => {},
    error:   typeof _sfx.error === 'function'   ? () => _sfx.error()   : () => {},
    grab:    typeof _sfx.grab === 'function'    ? () => _sfx.grab()    : () => {},
    drop:    typeof _sfx.drop === 'function'    ? () => _sfx.drop()    : () => {},
    pulse:   typeof _sfx.pulse === 'function'   ? () => _sfx.pulse()   : () => {}
  };
  if (!S.SFX) S.SFX = SFX;

  const clamp = (typeof S.clamp === 'function')
    ? S.clamp : (v, a, b) => Math.min(b, Math.max(a, v));

  const lerpAngle = (typeof S.lerpAngle === 'function')
    ? S.lerpAngle : (a, b, t) => {
        let d = ((b - a + 180) % 360 + 360) % 360 - 180;
        return a + d * t;
      };

  const lerpColor = (typeof S.lerpColor === 'function')
    ? S.lerpColor : (a, b, t) => {
        try {
          const pa = parseInt(String(a).replace('#', ''), 16);
          const pb = parseInt(String(b).replace('#', ''), 16);
          const ar = (pa >> 16) & 255, ag = (pa >> 8) & 255, ab = pa & 255;
          const br = (pb >> 16) & 255, bg = (pb >> 8) & 255, bb = pb & 255;
          return '#' + ((1 << 24) +
            (Math.round(ar + (br - ar) * t) << 16) +
            (Math.round(ag + (bg - ag) * t) << 8) +
            Math.round(ab + (bb - ab) * t)
          ).toString(16).slice(1);
        } catch (e) { return a; }
      };

  const hslToHex = (typeof S.hslToHex === 'function')
    ? S.hslToHex : (h, s, l) => {
        s /= 100; l /= 100;
        const k = n => (n + h / 30) % 12;
        const a = s * Math.min(l, 1 - l);
        const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
        const toHex = x => Math.round(x * 255).toString(16).padStart(2, '0');
        return '#' + toHex(f(0)) + toHex(f(8)) + toHex(f(4));
      };

  const hexToRgba = (typeof S.hexToRgba === 'function')
    ? S.hexToRgba : (hex, a) => {
        try {
          const h = String(hex).replace('#', '');
          const full = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
          const n = parseInt(full, 16);
          return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
        } catch (e) { return 'rgba(139,124,255,' + a + ')'; }
      };

  const haptic = (typeof S.haptic === 'function') ? S.haptic : () => {};
  const addCredits = (typeof S.addCredits === 'function') ? S.addCredits : () => 0;
  const canAfford = (typeof S.canAfford === 'function') ? S.canAfford : () => true;
  const showToast = (typeof S.showToast === 'function')
    ? S.showToast : (msg) => {
        const t = document.getElementById('toast');
        if (!t) return;
        t.textContent = msg;
        t.classList.add('show');
        setTimeout(() => t.classList.remove('show'), 1600);
      };
  const showOutOfCreditsModal = (typeof S.showOutOfCreditsModal === 'function')
    ? S.showOutOfCreditsModal : () => showToast('Not enough credits');
  const CREDIT_COSTS = S.CREDIT_COSTS || { play: 1, createShape: -5 };

  const animateBurst = (typeof S.animateBurst === 'function') ? S.animateBurst : () => {};
  const animateRipple = (typeof S.animateRipple === 'function') ? S.animateRipple : () => {};
  const animateFlash = (typeof S.animateFlash === 'function') ? S.animateFlash : () => {};
  const animateConfetti = (typeof S.animateConfetti === 'function') ? S.animateConfetti : () => {};

  /* =========================================================
     FALLBACK makeShapeTester
     ========================================================= */
  const _testCanvas = document.createElement('canvas');
  _testCanvas.width = 300;
  _testCanvas.height = 300;
  const _testCtx = _testCanvas.getContext('2d');
  const _testerCache = new Map();

  function _roundRect(ctx, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
  }

  function _fallbackMakeShapeTester(shape) {
    if (!shape || !shape.css) return { isInside: () => false };
    const key = (shape.name || '') + ':' + JSON.stringify(shape.css);
    if (_testerCache.has(key)) return _testerCache.get(key);
    const c = shape.css;
    const W = 300, H = 300;
    _testCtx.clearRect(0, 0, W, H);
    _testCtx.fillStyle = '#fff';
    const baseW = c.width || 170;
    const baseH = c.height || 170;
    const scale = Math.min(W / baseW, H / baseH) * 0.88;
    const w = baseW * scale, h = baseH * scale;
    const x = (W - w) / 2, y = (H - h) / 2;

    try {
      if (c.triangle) {
        _testCtx.beginPath();
        _testCtx.moveTo(x + w / 2, y);
        _testCtx.lineTo(x + w, y + h);
        _testCtx.lineTo(x, y + h);
        _testCtx.closePath();
        _testCtx.fill();
      } else if (c.rightTriangle) {
        _testCtx.beginPath();
        _testCtx.moveTo(x, y + h);
        _testCtx.lineTo(x, y);
        _testCtx.lineTo(x + w, y + h);
        _testCtx.closePath();
        _testCtx.fill();
      } else if (c.rotate45) {
        _testCtx.save();
        _testCtx.translate(x + w / 2, y + h / 2);
        _testCtx.rotate(Math.PI / 4);
        _testCtx.fillRect(-w / 2, -h / 2, w, h);
        _testCtx.restore();
      } else if (c.clipPath) {
        const polyMatch = c.clipPath.match(/polygon\(([^)]+)\)/);
        if (polyMatch) {
          const pts = polyMatch[1].split(',').map(p => {
            const parts = p.trim().split(/\s+/).map(v => parseFloat(v));
            return [x + (parts[0] / 100) * w, y + (parts[1] / 100) * h];
          });
          _testCtx.beginPath();
          _testCtx.moveTo(pts[0][0], pts[0][1]);
          for (let i = 1; i < pts.length; i++) _testCtx.lineTo(pts[i][0], pts[i][1]);
          _testCtx.closePath();
          _testCtx.fill('evenodd');
        } else {
          const pathStr = c.clipPath.replace(/^path\(["']|["']\)$/g, '');
          try {
            const path = new Path2D(pathStr);
            _testCtx.save();
            _testCtx.translate(x, y);
            _testCtx.scale(w / baseW, h / baseH);
            _testCtx.fill(path, 'evenodd');
            _testCtx.restore();
          } catch (e) {
            _testCtx.fillRect(x, y, w, h);
          }
        }
      } else if (c.borderRadius !== undefined) {
        const r = (parseFloat(c.borderRadius) / Math.max(baseW, baseH)) * Math.max(w, h);
        _testCtx.beginPath();
        _roundRect(_testCtx, x, y, w, h, r);
        _testCtx.fill();
      } else {
        _testCtx.fillRect(x, y, w, h);
      }
    } catch (e) {
      _testCtx.fillRect(x, y, w, h);
    }

    const img = _testCtx.getImageData(0, 0, W, H).data;
    const tester = {
      W: W,
      H: H,
      isInside: function (nx, ny) {
        const px = Math.floor(nx * W), py = Math.floor(ny * H);
        if (px < 0 || py < 0 || px >= W || py >= H) return false;
        return img[(py * W + px) * 4 + 3] > 128;
      }
    };
    if (_testerCache.size < 800) _testerCache.set(key, tester);
    return tester;
  }

  const makeShapeTester = (typeof S.makeShapeTester === 'function')
    ? S.makeShapeTester : _fallbackMakeShapeTester;

  /* =========================================================
     FALLBACK renderDots
     ========================================================= */
  function _fallbackRenderDots(canvas, shape, opts) {
    opts = opts || {};
    if (!canvas || !shape) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, (S.qualityCfg && S.qualityCfg.dpr) || 1.25);
    const rect = canvas.getBoundingClientRect();
    const W = rect.width || canvas.width || 80;
    const H = rect.height || canvas.height || 80;
    if (!W || !H) return;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    const color = opts.color || shape.color || '#8b7cff';
    const tester = makeShapeTester(shape);
    const dotCount = Math.floor((opts.dotCount || 2600) * ((S.qualityCfg && S.qualityCfg.dotMult) || 1));
    const dotSize = (opts.dotSize || 1.6) * (settings.particleSize || 1);
    const opacity = opts.opacity != null ? opts.opacity : 1;
    const brightness = settings.dotBrightness || 1;
    const pad = W * 0.06;
    const gridSize = Math.max(3, Math.floor(Math.sqrt(dotCount)));
    const cellW = (W - pad * 2) / gridSize;
    const cellH = (H - pad * 2) / gridSize;

    for (let gy = 0; gy < gridSize; gy++) {
      for (let gx = 0; gx < gridSize; gx++) {
        const jx = (Math.random() - 0.5) * cellW * 0.85;
        const jy = (Math.random() - 0.5) * cellH * 0.85;
        const px = pad + gx * cellW + cellW / 2 + jx;
        const py = pad + gy * cellH + cellH / 2 + jy;
        if (tester.isInside(px / W, py / H)) {
          const r = dotSize * (0.6 + Math.random() * 0.8);
          ctx.beginPath();
          ctx.arc(px, py, r, 0, Math.PI * 2);
          const alpha = Math.min(1, opacity * brightness * 0.9);
          ctx.fillStyle = hexToRgba(color, alpha);
          ctx.fill();
        }
      }
    }
  }

  const renderDots = (typeof S.renderDots === 'function') ? S.renderDots : _fallbackRenderDots;

  if (typeof S.makeShapeTester !== 'function') S.makeShapeTester = makeShapeTester;
  if (typeof S.renderDots !== 'function') S.renderDots = renderDots;
  if (typeof S.hexToRgba !== 'function') S.hexToRgba = hexToRgba;
  if (typeof S.lerpColor !== 'function') S.lerpColor = lerpColor;
  if (typeof S.hslToHex !== 'function') S.hslToHex = hslToHex;
  if (typeof S.clamp !== 'function') S.clamp = clamp;
  if (typeof S.lerpAngle !== 'function') S.lerpAngle = lerpAngle;

  function safeRenderDots(canvas, shape, opts) {
    try { renderDots(canvas, shape, opts); }
    catch (e) {
      try { _fallbackRenderDots(canvas, shape, opts); } catch (e2) {}
    }
  }

  /* =========================================================
     EDITOR STATE
     ========================================================= */
  const editing = {
    shapeIndex: -1, isLine: false, lineIndex: -1,
    color: '#8b7cff', size: 160, opacity: 1, density: 2600, dotSize: 1.6,
    glow: 0.5, ring: false, grid: true, baseShape: null, baseColor: '#8b7cff',
    dotPattern: 'grid', dotChaos: 0.4, dotRotation: 0,
    colorMode: 'solid', gradientAngle: 0, secondaryColor: '#4dd4ff',
    outline: false, outlineColor: '#ffffff', outlineWidth: 2, invertMask: false
  };

  function saveEditor(k, v) {
    try { localStorage.setItem('e_' + k, v); } catch (e) {}
  }

  function getDotPositions(pattern, W, H, pad, gridSize, cellW, cellH, tester, ed) {
    const out = [];
    const cx = W / 2, cy = H / 2;
    const chaos = ed.dotChaos != null ? ed.dotChaos : 0.4;
    const rot = ((ed.dotRotation || 0) * Math.PI) / 180;
    const invert = !!ed.invertMask;
    const baseDotR = (ed.dotSize || 2) * 0.85;
    const chaosMax = chaos * 12;

    function push(px, py) {
      if (px < pad * 0.5 || py < pad * 0.5 || px > W - pad * 0.5 || py > H - pad * 0.5) return;
      let inside = false;
      try { inside = tester.isInside(px / W, py / H); } catch (e) {}
      if (invert ? !inside : inside) {
        const d = Math.hypot(px / W - 0.5, py / H - 0.5) * 2;
        const alpha = 0.55 + (1 - Math.min(d, 1)) * 0.45;
        const sizeVar = 0.6 + Math.random() * 0.8;
        out.push({ x: px, y: py, r: baseDotR * sizeVar, alpha: clamp(alpha, 0, 1) });
      }
    }

    if (pattern === 'spiral') {
      const total = gridSize * gridSize * 2;
      for (let i = 0; i < total; i++) {
        const t = i / total;
        const ang = t * Math.PI * 2 * 5 + rot;
        const radius = t * Math.min(W, H) * 0.45;
        push(cx + Math.cos(ang) * radius + (Math.random() - 0.5) * chaosMax,
             cy + Math.sin(ang) * radius + (Math.random() - 0.5) * chaosMax);
      }
    } else if (pattern === 'radial') {
      const rings = 14;
      for (let ri = 1; ri <= rings; ri++) {
        const radius = (ri / rings) * Math.min(W, H) * 0.45;
        const perRing = Math.max(10, Math.floor((Math.PI * 2 * radius) / 4));
        for (let i = 0; i < perRing; i++) {
          const ang = (i / perRing) * Math.PI * 2 + rot + ri * 0.15;
          push(cx + Math.cos(ang) * radius + (Math.random() - 0.5) * chaosMax,
               cy + Math.sin(ang) * radius + (Math.random() - 0.5) * chaosMax);
        }
      }
    } else if (pattern === 'noise') {
      const total = gridSize * gridSize * 3;
      for (let i = 0; i < total; i++) {
        push(pad + Math.random() * (W - pad * 2), pad + Math.random() * (H - pad * 2));
      }
    } else if (pattern === 'rings') {
      const rings = 10;
      for (let ri = 1; ri <= rings; ri++) {
        const radius = (ri / rings) * Math.min(W, H) * 0.45;
        const dots = Math.max(12, Math.floor((Math.PI * 2 * radius) / 5));
        for (let i = 0; i < dots; i++) {
          const ang = (i / dots) * Math.PI * 2 + rot;
          push(cx + Math.cos(ang) * radius + (Math.random() - 0.5) * chaosMax * 0.5,
               cy + Math.sin(ang) * radius + (Math.random() - 0.5) * chaosMax * 0.5);
        }
      }
    } else {
      for (let gy = 0; gy < gridSize; gy++) {
        for (let gx = 0; gx < gridSize; gx++) {
          const jx = (Math.random() - 0.5) * cellW * 0.85 * (0.2 + chaos * 2);
          const jy = (Math.random() - 0.5) * cellH * 0.85 * (0.2 + chaos * 2);
          push(pad + gx * cellW + cellW / 2 + jx, pad + gy * cellH + cellH / 2 + jy);
        }
      }
    }
    return out;
  }

  function dotColorFor(ed, p, W, H, baseColor) {
    let c = baseColor;
    const c2 = ed.secondaryColor || '#4dd4ff';
    if (ed.colorMode === 'gradient') {
      const ang = (ed.gradientAngle || 0) * Math.PI / 180;
      const t = (Math.cos(ang) * (p.x / W) + Math.sin(ang) * (p.y / H) + 1) / 2;
      c = lerpColor(baseColor, c2, clamp(t, 0, 1));
    } else if (ed.colorMode === 'rainbow') {
      const hue = ((p.x / W) * 360 + (p.y / H) * 180) % 360;
      c = hslToHex(hue, 80, 60);
    } else if (ed.colorMode === 'noise') {
      const n = Math.sin(p.x * 12.9898 + p.y * 78.233) * 43758.5453;
      const t = n - Math.floor(n);
      c = lerpColor(baseColor, c2, t);
    }
    return c;
  }

  function renderFull(canvas, shape, ed, opts) {
    opts = opts || {};
    if (!canvas || !shape) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, (S.qualityCfg && S.qualityCfg.dpr) || 1.25);
    const rect = canvas.getBoundingClientRect();
    const W = rect.width || canvas.width;
    const H = rect.height || canvas.height;
    if (W === 0 || H === 0) return;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, W, H);

    const scaleToFit = opts.fit || 1;
    const tester = makeShapeTester(shape);
    const color = ed.color;
    const dotCount = Math.max(250, Math.floor(ed.density * scaleToFit * scaleToFit * ((S.qualityCfg && S.qualityCfg.dotMult) || 1)));
    const dotSize = ed.dotSize * scaleToFit * (settings.particleSize || 1);
    const pad = W * 0.05;
    const gridSize = Math.max(4, Math.floor(Math.sqrt(dotCount)));
    const cellW = (W - pad * 2) / gridSize;
    const cellH = (H - pad * 2) / gridSize;
    const glowAmt = ed.glow * (settings.glowStrength || 1) * ((S.qualityCfg && S.qualityCfg.glowMult) || 1);

    if (glowAmt > 0) {
      ctx.shadowBlur = Math.min(dotSize * 3 * glowAmt * 2, (S.qualityCfg && S.qualityCfg.shadowMax) || 8);
      ctx.shadowColor = color;
    }

    const positions = getDotPositions(ed.dotPattern, W, H, pad, gridSize, cellW, cellH, tester, Object.assign({}, ed, { dotSize: dotSize }));
    for (let i = 0; i < positions.length; i++) {
      const p = positions[i];
      const c = dotColorFor(ed, p, W, H, color);
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      const alpha = Math.min(1, p.alpha * ed.opacity * (settings.dotBrightness || 1));
      ctx.fillStyle = hexToRgba(c, alpha);
      ctx.fill();
    }

    if (ed.ring) {
      ctx.shadowBlur = 0;
      ctx.beginPath();
      ctx.arc(W / 2, H / 2, Math.min(W, H) * 0.42, 0, Math.PI * 2);
      ctx.strokeStyle = hexToRgba(color, 0.25 * ed.opacity);
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  }

  /* =========================================================
     HOME PAGE
     ========================================================= */
  const isHomePage = !!document.getElementById('page-home');

  if (isHomePage) {
    try {
      const el1 = document.getElementById('shapeCount');
      if (el1) el1.textContent = SHAPES.length + ' items';
      const el2 = document.getElementById('totalCountLabel');
      if (el2) el2.textContent = SHAPES.length;
      const el3 = document.getElementById('drawerShapeCount');
      if (el3) el3.textContent = SHAPES.length;
      const el4 = document.getElementById('drawerCustomCount');
      if (el4) {
        try { el4.textContent = (JSON.parse(localStorage.getItem('customShapes') || '[]')).length; }
        catch (e) { el4.textContent = '0'; }
      }
      const el5 = document.getElementById('drawerCredits');
      if (el5) {
        el5.textContent = (typeof S.creditHackEnabled === 'function' && S.creditHackEnabled())
          ? '∞' : (typeof S.credits === 'function' ? S.credits() : 40);
      }
    } catch (e) {}

    const linesGrid = document.getElementById('linesGrid');
    const pagesGrid = document.getElementById('pagesGrid');
    const lineNames = ['Minimal','Gradient','Neon','Glass','Retro','Neo-Brutal','Typography','Geometric','Monochrome','Pastel','Dark Mode','Material','Neumorphic','Skeuomorphic','Flat','Cyberpunk','Vintage','Japanese','Scandinavian','Tribal','Art Deco','Bauhaus','Abstract','Memphis','Constructivism'];

    if (linesGrid) {
      for (let i = 0; i < 25; i++) {
        (function (idx) {
          const el = document.createElement('div');
          el.className = 'design-line';
          el.dataset.kind = 'line';
          el.dataset.label = lineNames[idx];
          el.dataset.lineIndex = idx;
          el.innerHTML = '<span class="num">' + String(idx + 1).padStart(2, '0') + '</span><span class="label">' + lineNames[idx] + '</span>';
          const cv = document.createElement('canvas');
          el.appendChild(cv);
          linesGrid.appendChild(el);
          requestAnimationFrame(function () { renderLineDots(cv, idx); });
          el.addEventListener('click', function () { openEditor(el); });
          el.addEventListener('pointerenter', function () { SFX.hover(); });
        })(i);
      }
    }

    function renderLineDots(canvas, idx) {
      try {
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        const dpr = Math.min(window.devicePixelRatio || 1, (S.qualityCfg && S.qualityCfg.dpr) || 1.25);
        const rect = canvas.getBoundingClientRect();
        const W = rect.width || 200, H = rect.height || 100;
        if (!W) return;
        canvas.width = W * dpr;
        canvas.height = H * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, W, H);
        const pals = [
          ['#8b7cff', '#4dd4ff'], ['#4dd4ff', '#4dffcc'], ['#ff4d9e', '#8b7cff'],
          ['#ffd45c', '#ff8c5c'], ['#4dffcc', '#8b7cff']
        ];
        const pal = pals[idx % pals.length];
        for (let k = 0; k < 140; k++) {
          const x = Math.random() * W, y = Math.random() * H;
          const r = 0.5 + Math.random() * 1.3;
          ctx.beginPath();
          ctx.arc(x, y, r, 0, Math.PI * 2);
          ctx.fillStyle = hexToRgba(lerpColor(pal[0], pal[1], x / W), 0.5 + Math.random() * 0.4);
          ctx.fill();
        }
      } catch (e) {}
    }

    if (pagesGrid) {
      for (let i = 0; i < SHAPES.length; i++) {
        (function (idx) {
          const s = SHAPES[idx];
          if (!s) return;
          const el = document.createElement('div');
          el.className = 'shape-card';
          el.dataset.kind = 'shape';
          el.dataset.shapeIndex = idx;
          el.dataset.label = s.name || 'Shape';
          el.style.setProperty('--glow', hexToRgba(s.color || '#8b7cff', 0.35));
          const cv = document.createElement('canvas');
          el.appendChild(cv);
          const name = document.createElement('div');
          name.className = 'name';
          name.textContent = s.name || 'Shape';
          el.appendChild(name);
          const idxEl = document.createElement('div');
          idxEl.className = 'idx';
          idxEl.textContent = String(idx + 1).padStart(2, '0');
          el.appendChild(idxEl);
          pagesGrid.appendChild(el);
          requestAnimationFrame(function () { safeRenderDots(cv, s, { dotCount: 90, dotSize: 1.1 }); });
          el.addEventListener('click', function () { openEditor(el); });
          el.addEventListener('pointerenter', function () { SFX.hover(); });
        })(i);
      }
    }

    /* =========================================================
       EDITOR
       ========================================================= */
    const editorPage   = document.getElementById('editorPage');
    const editorCanvas = document.getElementById('editorCanvas');
    const editorTitle  = document.getElementById('editorTitle');
    const colorGrid    = document.getElementById('colorGrid');
    const colorPicker  = document.getElementById('colorPicker');
    const hexInput     = document.getElementById('hexInput');
    const colorValue   = document.getElementById('colorValue');
    const sizeSlider   = document.getElementById('sizeSlider');
    const sizeValue    = document.getElementById('sizeValue');
    const opacitySlider= document.getElementById('opacitySlider');
    const opacityValue = document.getElementById('opacityValue');
    const densitySlider= document.getElementById('densitySlider');
    const densityValue = document.getElementById('densityValue');
    const dotSizeSlider= document.getElementById('dotSizeSlider');
    const dotSizeValue = document.getElementById('dotSizeValue');
    const glowSlider   = document.getElementById('glowSlider');
    const glowValue    = document.getElementById('glowValue');
    const toggleRing   = document.getElementById('toggleRing');
    const toggleGrid   = document.getElementById('toggleGrid');

    if (colorGrid) {
      PALETTE.forEach(function (c) {
        const sw = document.createElement('div');
        sw.className = 'swatch';
        sw.style.background = 'linear-gradient(135deg, ' + c + ', ' + hexToRgba(c, 0.7) + ')';
        sw.dataset.color = c;
        if (c === '#8b7cff') sw.classList.add('active');
        sw.addEventListener('click', function () { setColor(c); SFX.tap(); });
        colorGrid.appendChild(sw);
      });
    }

    function openEditor(cardEl) {
      if (!cardEl || !editorPage) return;
      SFX.open();
      const kind = cardEl.dataset.kind;
      if (kind === 'shape') {
        const idx = parseInt(cardEl.dataset.shapeIndex, 10);
        const s = SHAPES[idx];
        if (!s) return;
        editing.shapeIndex = idx;
        editing.baseShape = s;
        editing.baseColor = s.color || '#8b7cff';
        editing.color = s.color || '#8b7cff';
        if (editorTitle) editorTitle.textContent = s.name || 'Shape';
      } else {
        const lineIdx = parseInt(cardEl.dataset.lineIndex, 10);
        const lc = PALETTE[lineIdx % PALETTE.length] || '#8b7cff';
        editing.isLine = true;
        editing.lineIndex = lineIdx;
        editing.baseShape = {
          name: cardEl.dataset.label || 'Line',
          color: lc,
          css: { width: 170, height: 170, borderRadius: 24 }
        };
        editing.baseColor = lc;
        editing.color = lc;
        if (editorTitle) editorTitle.textContent = cardEl.dataset.label || 'Line';
      }
      editing.size = 160;
      editing.opacity = 1;
      editing.density = 2600;
      editing.dotSize = 1.6;
      editing.glow = 0.5;
      if (sizeSlider) sizeSlider.value = 160;
      if (opacitySlider) opacitySlider.value = 100;
      if (densitySlider) densitySlider.value = 2600;
      if (dotSizeSlider) dotSizeSlider.value = 1.6;
      if (glowSlider) glowSlider.value = 50;
      setColor(editing.color, true);
      updateLabels();
      editorPage.classList.add('active');
      setTimeout(function () { updateEditorPreview(); buildExtraEditor(); }, 50);
    }

    const editorBackBtn = document.getElementById('editorBack');
    if (editorBackBtn) {
      editorBackBtn.addEventListener('click', function () {
        SFX.close();
        if (editorPage) editorPage.classList.remove('active');
      });
    }

    function updateLabels() {
      if (sizeValue) sizeValue.textContent = editing.size + 'px';
      if (opacityValue) opacityValue.textContent = Math.round(editing.opacity * 100) + '%';
      if (densityValue) densityValue.textContent = editing.density;
      if (dotSizeValue) dotSizeValue.textContent = editing.dotSize.toFixed(1);
      if (glowValue) glowValue.textContent = Math.round(editing.glow * 100);
      if (colorValue) colorValue.textContent = editing.color.toUpperCase();
    }

    function setColor(c, skip) {
      editing.color = c;
      if (editing.baseShape) editing.baseShape.color = c;
      if (colorPicker) colorPicker.value = c;
      if (hexInput) hexInput.value = c;
      if (colorValue) colorValue.textContent = c.toUpperCase();
      if (colorGrid) {
        colorGrid.querySelectorAll('.swatch').forEach(function (sw) {
          sw.classList.toggle('active', sw.dataset.color === c);
        });
      }
      if (!skip) updateEditorPreview();
    }

    function updateEditorPreview() {
      if (!editorCanvas || !editing.baseShape) return;
      try {
        const wrapEl = editorCanvas.parentElement;
        if (!wrapEl) return;
        const rect = wrapEl.getBoundingClientRect();
        const W = rect.width || 260, H = rect.height || 260;
        const dpr = Math.min(window.devicePixelRatio || 1, (S.qualityCfg && S.qualityCfg.dpr) || 1.25);
        editorCanvas.width = W * dpr;
        editorCanvas.height = H * dpr;
        editorCanvas.style.width = W + 'px';
        editorCanvas.style.height = H + 'px';
        const scaleToFit = Math.min(W, H) / editing.size * 0.85;
        renderFull(editorCanvas, editing.baseShape, editing, { fit: scaleToFit });
      } catch (e) {}
    }

    if (sizeSlider) sizeSlider.addEventListener('input', function () {
      editing.size = parseInt(sizeSlider.value, 10);
      updateLabels();
      updateEditorPreview();
    });
    if (opacitySlider) opacitySlider.addEventListener('input', function () {
      editing.opacity = parseInt(opacitySlider.value, 10) / 100;
      updateLabels();
      updateEditorPreview();
    });
    if (densitySlider) densitySlider.addEventListener('input', function () {
      editing.density = parseInt(densitySlider.value, 10);
      updateLabels();
      updateEditorPreview();
    });
    if (dotSizeSlider) dotSizeSlider.addEventListener('input', function () {
      editing.dotSize = parseFloat(dotSizeSlider.value);
      updateLabels();
      updateEditorPreview();
    });
    if (glowSlider) glowSlider.addEventListener('input', function () {
      editing.glow = parseInt(glowSlider.value, 10) / 100;
      updateLabels();
      updateEditorPreview();
    });
    if (colorPicker) colorPicker.addEventListener('input', function () { setColor(colorPicker.value); });
    if (hexInput) hexInput.addEventListener('change', function () {
      let v = hexInput.value.trim();
      if (!v.startsWith('#')) v = '#' + v;
      if (/^#[0-9a-f]{6}$/i.test(v)) setColor(v.toLowerCase());
      else hexInput.value = editing.color;
    });
    if (toggleRing) toggleRing.addEventListener('click', function () {
      editing.ring = !editing.ring;
      toggleRing.classList.toggle('on', editing.ring);
      updateEditorPreview();
    });
    if (toggleGrid) toggleGrid.addEventListener('click', function () {
      editing.grid = !editing.grid;
      toggleGrid.classList.toggle('on', editing.grid);
    });

    const resetBtn = document.getElementById('resetBtn');
    if (resetBtn) resetBtn.addEventListener('click', function () {
      editing.color = editing.baseColor;
      editing.size = 160;
      editing.opacity = 1;
      editing.density = 2600;
      editing.dotSize = 1.6;
      editing.glow = 0.5;
      editing.dotPattern = 'grid';
      editing.colorMode = 'solid';
      if (sizeSlider) sizeSlider.value = 160;
      if (opacitySlider) opacitySlider.value = 100;
      if (densitySlider) densitySlider.value = 2600;
      if (dotSizeSlider) dotSizeSlider.value = 1.6;
      if (glowSlider) glowSlider.value = 50;
      setColor(editing.color, true);
      updateLabels();
      updateEditorPreview();
      buildExtraEditor();
      SFX.pulse();
      showToast('Reset');
    });

    function buildExtraEditor() {
      const inner = document.querySelector('#editorPage .editor-inner');
      if (!inner) return;
      const old = document.getElementById('extraEditorMount');
      if (old) old.remove();
      const mount = document.createElement('div');
      mount.id = 'extraEditorMount';
      mount.innerHTML =
        '<div class="control-section">' +
          '<div class="control-head"><div class="control-label">Dot Pattern</div></div>' +
          '<div class="setting-options" style="gap:8px;display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));">' +
            ['grid','spiral','radial','noise','rings'].map(function (p) {
              return '<div class="setting-option ' + (editing.dotPattern === p ? 'active' : '') + '" data-pattern="' + p + '"><div class="radio"></div><div class="option-body"><div class="option-name">' + p.charAt(0).toUpperCase() + p.slice(1) + '</div></div></div>';
            }).join('') +
          '</div>' +
        '</div>' +
        '<div class="control-section">' +
          '<div class="control-head"><div class="control-label">Color Mode</div></div>' +
          '<div class="setting-options" style="gap:8px;display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));">' +
            ['solid','gradient','rainbow','noise'].map(function (m) {
              return '<div class="setting-option ' + (editing.colorMode === m ? 'active' : '') + '" data-colormode="' + m + '"><div class="radio"></div><div class="option-body"><div class="option-name">' + m.charAt(0).toUpperCase() + m.slice(1) + '</div></div></div>';
            }).join('') +
          '</div>' +
        '</div>';
      const actions = document.querySelector('#editorPage .editor-actions');
      if (actions && actions.parentNode) actions.parentNode.insertBefore(mount, actions);
      else inner.appendChild(mount);

      mount.querySelectorAll('[data-pattern]').forEach(function (opt) {
        opt.addEventListener('click', function () {
          editing.dotPattern = opt.dataset.pattern;
          saveEditor('dotPattern', editing.dotPattern);
          mount.querySelectorAll('[data-pattern]').forEach(function (o) { o.classList.toggle('active', o === opt); });
          updateEditorPreview();
          SFX.tap();
        });
      });
      mount.querySelectorAll('[data-colormode]').forEach(function (opt) {
        opt.addEventListener('click', function () {
          editing.colorMode = opt.dataset.colormode;
          saveEditor('colorMode', editing.colorMode);
          mount.querySelectorAll('[data-colormode]').forEach(function (o) { o.classList.toggle('active', o === opt); });
          updateEditorPreview();
          SFX.tap();
        });
      });
    }

    /* =========================================================
       STAGE
       ========================================================= */
    const stageEl = document.getElementById('stage');
    const wrap = document.getElementById('shapeWrap');
    const stageCanvas = document.getElementById('shapeCanvas');
    const shapeLabel = document.getElementById('shapeLabel');
    const stageLabel = document.getElementById('stageLabel');

    const SHAPE_SIZE = 160;
    let stageState = { x: 0, y: 0, rot: 0, scale: 1 };
    let target = { x: 0, y: 0, rot: 0, scale: 1 };
    let dragging = false, pointerId = null;
    let lastAngle = 0, lastPX = 0, lastPY = 0;
    let velocity = { x: 0, y: 0 };
    let autoRotSpeed = 0, tickRunning = false;
    let handUnsub = null;

    function openStage() {
      if (!stageEl || !wrap || !stageCanvas) return;

      document.body.classList.add('stage-mode');
      document.body.classList.remove('editor-mode');
      document.body.classList.remove('physics-mode');
      document.body.style.background = '#03040a';

      const shape = editing.baseShape;
      const color = editing.color;
      if (stageLabel) stageLabel.textContent = editorTitle ? editorTitle.textContent : 'Shape';
      if (shapeLabel) shapeLabel.textContent = editorTitle ? editorTitle.textContent : 'Shape';
      wrap.style.setProperty('--glow', hexToRgba(color, 0.6));
      stageEl.classList.toggle('grid', !!editing.grid);

      wrap.style.width = SHAPE_SIZE + 'px';
      wrap.style.height = SHAPE_SIZE + 'px';
      wrap.style.left = '';
      wrap.style.top = '';
      wrap.style.position = '';
      wrap.style.transform = '';

      if (editorPage) editorPage.classList.remove('active');
      stageEl.classList.add('active');

      requestAnimationFrame(function () {
        try {
          const dpr = Math.min(window.devicePixelRatio || 1, (S.qualityCfg && S.qualityCfg.dpr) || 1.25);
          stageCanvas.width = SHAPE_SIZE * dpr;
          stageCanvas.height = SHAPE_SIZE * dpr;
          stageCanvas.style.width = SHAPE_SIZE + 'px';
          stageCanvas.style.height = SHAPE_SIZE + 'px';
          renderFull(stageCanvas, shape, editing, { fit: 1 });
        } catch (e) {}
      });

      stageState = {
        x: window.innerWidth / 2,
        y: window.innerHeight / 2,
        rot: 0,
        scale: 1
      };
      target = { x: stageState.x, y: stageState.y, rot: 0, scale: 1 };
      autoRotSpeed = settings.controlMode === 'auto' ? (settings.autoSpeed || 0.7) : 0;
      applyTransform();

      addCredits(-(CREDIT_COSTS.play || 1));

      if (!tickRunning) {
        tickRunning = true;
        tick();
      }

      if (settings.handTrack && window.HandTrack && typeof window.HandTrack.start === 'function') {
        try {
          window.HandTrack.start().then(function () {
            if (typeof window.HandTrack.onUpdate === 'function') {
              handUnsub = window.HandTrack.onUpdate(function (data) {
                if (!data || !data.active || settings.controlMode === 'auto') return;
                const mX = SHAPE_SIZE / 2 + 30;
                const mY = SHAPE_SIZE / 2 + 60;
                target.x = mX + data.x * (window.innerWidth - mX * 2);
                target.y = mY + data.y * (window.innerHeight - mY * 2);
              });
            }
          }).catch(function () {});
        } catch (e) {}
      }
    }

    function goHome() {
      SFX.close();
      document.body.classList.remove('stage-mode');
      document.body.classList.remove('physics-mode');
      document.body.style.background = '';
      if (stageEl) stageEl.classList.remove('active');
      if (wrap) {
        wrap.style.left = '';
        wrap.style.top = '';
        wrap.style.position = '';
        wrap.style.transform = '';
      }
      autoRotSpeed = 0;
      if (handUnsub) { try { handUnsub(); } catch (e) {} handUnsub = null; }
      if (window.HandTrack && typeof window.HandTrack.stop === 'function') {
        try { window.HandTrack.stop(); } catch (e) {}
      }
    }

    function goEdit() {
      SFX.open();
      document.body.classList.remove('stage-mode');
      document.body.classList.remove('physics-mode');
      document.body.classList.add('editor-mode');
      document.body.style.background = '';
      if (stageEl) stageEl.classList.remove('active');
      if (wrap) {
        wrap.style.left = '';
        wrap.style.top = '';
        wrap.style.position = '';
      }
      if (editorPage) editorPage.classList.add('active');
      if (handUnsub) { try { handUnsub(); } catch (e) {} handUnsub = null; }
      if (window.HandTrack && typeof window.HandTrack.stop === 'function') {
        try { window.HandTrack.stop(); } catch (e) {}
      }
      setTimeout(function () { updateEditorPreview(); buildExtraEditor(); }, 50);
    }

    const closeStageBtn = document.getElementById('closeStage');
    if (closeStageBtn) closeStageBtn.addEventListener('click', goHome);
    const editAgainBtn = document.getElementById('editAgainBtn');
    if (editAgainBtn) editAgainBtn.addEventListener('click', goEdit);

    if (stageEl) {
      stageEl.addEventListener('pointerdown', function (e) {
        if (!stageEl.classList.contains('active')) return;
        if (e.target.closest('#closeStage, #editAgainBtn')) return;
        if (settings.controlMode === 'tilt' || settings.controlMode === 'auto') return;
        if (settings.handTrack) return;
        if (document.body.classList.contains('physics-mode')) return;
        e.preventDefault();
        dragging = true;
        pointerId = e.pointerId;
        try { stageEl.setPointerCapture(pointerId); } catch (_) {}
        if (wrap) wrap.classList.add('grabbed');
        if (wrap) {
          const rect = wrap.getBoundingClientRect();
          const cx = rect.left + rect.width / 2;
          const cy = rect.top + rect.height / 2;
          lastAngle = Math.atan2(e.clientY - cy, e.clientX - cx);
        }
        lastPX = e.clientX;
        lastPY = e.clientY;
        velocity = { x: 0, y: 0 };
        target.x = e.clientX;
        target.y = e.clientY;
        SFX.grab();
        haptic(8);
      });

      stageEl.addEventListener('pointermove', function (e) {
        if (!dragging || e.pointerId !== pointerId) return;
        e.preventDefault();
        target.x = e.clientX;
        target.y = e.clientY;
        if (wrap) {
          const rect = wrap.getBoundingClientRect();
          const cx = rect.left + rect.width / 2;
          const cy = rect.top + rect.height / 2;
          const ang = Math.atan2(e.clientY - cy, e.clientX - cx);
          target.rot += (ang - lastAngle) * 180 / Math.PI * (settings.rotationSpeed || 1);
          lastAngle = ang;
        }
        velocity.x = e.clientX - lastPX;
        velocity.y = e.clientY - lastPY;
        lastPX = e.clientX;
        lastPY = e.clientY;
        const speed = Math.hypot(velocity.x, velocity.y);
        target.scale = clamp(1 + speed * 0.006, 0.9, 1.4);
      });

      function endDrag(e) {
        if (!dragging) return;
        if (e && e.pointerId !== pointerId) return;
        dragging = false;
        pointerId = null;
        if (wrap) wrap.classList.remove('grabbed');
        target.scale = 1;
        const moved = Math.hypot(velocity.x, velocity.y);
        if (moved < 5) {
          showToast((shapeLabel ? shapeLabel.textContent : 'Shape') + ' tapped');
          if (wrap) animateFlash(wrap);
          animateBurst(e.clientX || 0, e.clientY || 0, editing.color, 10);
          animateRipple(e.clientX || 0, e.clientY || 0, editing.color);
          haptic(12);
        } else {
          SFX.drop();
        }
        velocity = { x: 0, y: 0 };
      }

      stageEl.addEventListener('pointerup', endDrag);
      stageEl.addEventListener('pointercancel', endDrag);
      stageEl.addEventListener('lostpointercapture', endDrag);
    }

    function applyTransform() {
      if (!wrap) return;
      if (document.body.classList.contains('physics-mode')) return;
      const mx = settings.mirrorX ? -1 : 1;
      const my = settings.mirrorY ? -1 : 1;
      wrap.style.transform =
        'translate(' + stageState.x + 'px, ' + stageState.y + 'px) translate(-50%, -50%) ' +
        'rotate(' + stageState.rot + 'deg) scale(' + (stageState.scale * mx) + ', ' + (stageState.scale * my) + ')';
    }

    function tick() {
      requestAnimationFrame(tick);
      if (!tickRunning) return;
      if (!stageEl || !stageEl.classList.contains('active')) return;
      if (document.body.classList.contains('physics-mode')) return;
      if (settings.controlMode === 'auto') {
        target.rot += autoRotSpeed * (settings.rotationSpeed || 1);
      }
      const half = SHAPE_SIZE / 2 + 20;
      const minX = half;
      const maxX = window.innerWidth - half;
      const minY = half + 60;
      const maxY = window.innerHeight - half - 60;
      target.x = clamp(target.x, minX, Math.max(minX, maxX));
      target.y = clamp(target.y, minY, Math.max(minY, maxY));
      const s = settings.smoothing || 0.18;
      stageState.x += (target.x - stageState.x) * s;
      stageState.y += (target.y - stageState.y) * s;
      stageState.scale += (target.scale - stageState.scale) * s;
      stageState.rot = lerpAngle(stageState.rot, target.rot, s);
      applyTransform();
    }

    const playBtn = document.getElementById('playBtn');
    if (playBtn) playBtn.addEventListener('click', function (e) {
      if (!canAfford(CREDIT_COSTS.play || 1)) {
        if (typeof showOutOfCreditsModal === 'function') showOutOfCreditsModal();
        return;
      }
      SFX.success();
      animateBurst(e.clientX, e.clientY, editing.color, 20);
      openStage();
    });

    const heroPlayBtn = document.getElementById('heroPlayBtn');
    if (heroPlayBtn) heroPlayBtn.addEventListener('click', function () {
      if (!canAfford(CREDIT_COSTS.play || 1)) {
        if (typeof showOutOfCreditsModal === 'function') showOutOfCreditsModal();
        return;
      }
      if (SHAPES.length === 0) return;
      const idx = Math.floor(Math.random() * SHAPES.length);
      const cards = pagesGrid ? pagesGrid.children : null;
      if (cards && cards[idx]) openEditor(cards[idx]);
      setTimeout(function () {
        if (canAfford(CREDIT_COSTS.play || 1)) openStage();
      }, 250);
    });

    const heroSurpriseBtn = document.getElementById('heroSurpriseBtn');
    if (heroSurpriseBtn) heroSurpriseBtn.addEventListener('click', function () {
      if (SHAPES.length === 0) return;
      const idx = Math.floor(Math.random() * SHAPES.length);
      const cards = pagesGrid ? pagesGrid.children : null;
      if (cards && cards[idx]) openEditor(cards[idx]);
    });

    /* CUSTOM SHAPES */
    let customShapes = [];
    try { customShapes = JSON.parse(localStorage.getItem('customShapes') || '[]'); }
    catch (e) { customShapes = []; }

    function saveCustom() {
      try { localStorage.setItem('customShapes', JSON.stringify(customShapes.slice(0, 50))); }
      catch (e) {}
    }

    function renderCustom() {
      const grid = document.getElementById('customShapesGrid');
      const countEl = document.getElementById('customCount');
      const drawerCount = document.getElementById('drawerCustomCount');
      if (!grid) return;
      grid.innerHTML = '';
      if (countEl) countEl.textContent = customShapes.length + ' items';
      if (drawerCount) drawerCount.textContent = customShapes.length;
      customShapes.forEach(function (s, i) {
        if (!s || !s.name) return;
        const el = document.createElement('div');
        el.className = 'custom-shape-card';
        const labels = { multi: 'FILE', draw: 'DRAW', image: 'IMAGE', library: 'LIB' };
        el.innerHTML = '<div class="badge-type">' + (labels[s.type] || 'CUSTOM') + '</div>';
        const cv = document.createElement('canvas');
        el.appendChild(cv);
        const name = document.createElement('div');
        name.className = 'name';
        name.textContent = s.name;
        el.appendChild(name);
        const del = document.createElement('button');
        del.className = 'delete-btn';
        del.textContent = '✕';
        del.addEventListener('click', function (e) {
          e.stopPropagation();
          customShapes.splice(i, 1);
          saveCustom();
          renderCustom();
          showToast('Deleted');
        });
        el.appendChild(del);
        grid.appendChild(el);
        requestAnimationFrame(function () { safeRenderDots(cv, s, { dotCount: 90, dotSize: 1.1 }); });
        el.addEventListener('click', function () {
          editing.shapeIndex = -1;
          editing.baseShape = s;
          editing.baseColor = s.color || '#8b7cff';
          editing.color = s.color || '#8b7cff';
          if (editorTitle) editorTitle.textContent = s.name;
          if (sizeSlider) sizeSlider.value = 160;
          if (opacitySlider) opacitySlider.value = 100;
          if (densitySlider) densitySlider.value = 2600;
          if (dotSizeSlider) dotSizeSlider.value = 1.6;
          if (glowSlider) glowSlider.value = 50;
          setColor(editing.color, true);
          updateLabels();
          SFX.open();
          if (editorPage) editorPage.classList.add('active');
          setTimeout(function () { updateEditorPreview(); buildExtraEditor(); }, 50);
        });
      });
    }
    renderCustom();

    /* Multi loader */
    const multiFileInput = document.getElementById('multiFileInput');
    if (multiFileInput) {
      multiFileInput.addEventListener('change', function (e) {
        const file = e.target.files[0];
        if (!file) return;
        file.text().then(function (text) {
          let loaded = [];
          try {
            if (file.name.endsWith('.json')) {
              const data = JSON.parse(text);
              const arr = Array.isArray(data) ? data : (data.shapes || []);
              loaded = arr.filter(function (s) { return s && s.name; }).map(function (s) {
                return {
                  name: s.name,
                  color: s.color || '#8b7cff',
                  css: typeof s.css === 'string' ? JSON.parse(s.css) : (s.css || {})
                };
              });
            }
          } catch (err) {}
          if (loaded.length === 0) { showToast('No shapes'); return; }
          loaded.forEach(function (s) { s.type = 'multi'; customShapes.push(s); });
          saveCustom();
          renderCustom();
          SFX.success();
          animateConfetti(20);
          addCredits(CREDIT_COSTS.createShape || -5);
          showToast(loaded.length + ' shapes added');
          e.target.value = '';
        }).catch(function () { showToast('Could not load file'); });
      });
    }

    /* Image loader */
    const imageFileInput = document.getElementById('imageFileInput');
    if (imageFileInput) {
      imageFileInput.addEventListener('change', function (e) {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = function (ev) {
          processImage(ev.target.result, file.name.replace(/\.[^.]+$/, ''), 'image').then(function (shape) {
            if (shape) {
              customShapes.push(shape);
              saveCustom();
              renderCustom();
              SFX.success();
              animateConfetti(20);
              addCredits(CREDIT_COSTS.createShape || -5);
              showToast('Image shape created');
            }
          });
        };
        reader.readAsDataURL(file);
        e.target.value = '';
      });
    }

    function processImage(dataURL, name, type) {
      return new Promise(function (resolve) {
        try {
          const img = new Image();
          img.onload = function () {
            try {
              const MAX = 200;
              let w = img.width, h = img.height;
              const sc = Math.min(1, MAX / Math.max(w, h));
              w = Math.max(1, Math.floor(w * sc));
              h = Math.max(1, Math.floor(h * sc));
              const off = document.createElement('canvas');
              off.width = w;
              off.height = h;
              const octx = off.getContext('2d');
              if (!octx) return resolve(null);
              octx.drawImage(img, 0, 0, w, h);
              const data = octx.getImageData(0, 0, w, h).data;
              const bitmap = new Uint8Array(w * h);
              let minX = w, minY = h, maxX = 0, maxY = 0, count = 0;
              for (let y = 0; y < h; y++) {
                for (let x = 0; x < w; x++) {
                  const idx = y * w + x;
                  if (data[idx * 4 + 3] > 100) {
                    bitmap[idx] = 1;
                    if (x < minX) minX = x;
                    if (y < minY) minY = y;
                    if (x > maxX) maxX = x;
                    if (y > maxY) maxY = y;
                    count++;
                  }
                }
              }
              if (count === 0) return resolve(null);
              resolve({
                name: name,
                color: '#8b7cff',
                type: type,
                isBitmap: true,
                bitmap: Array.from(bitmap),
                bitmapW: w,
                bitmapH: h,
                bbox: { minX: minX, minY: minY, maxX: maxX, maxY: maxY, bw: maxX - minX + 1, bh: maxY - minY + 1 },
                css: { width: maxX - minX + 1, height: maxY - minY + 1 }
              });
            } catch (err) { resolve(null); }
          };
          img.onerror = function () { resolve(null); };
          img.src = dataURL;
        } catch (e) { resolve(null); }
      });
    }

    /* Draw modal */
    const drawerModal = document.getElementById('drawerModal');
    const drawCanvas = document.getElementById('drawCanvas');
    const drawCtx = drawCanvas ? drawCanvas.getContext('2d') : null;
    const brushSize = document.getElementById('brushSize');
    const brushColor = document.getElementById('brushColor');
    let currentTool = 'brush';
    let drawing = false, lastX = 0, lastY = 0;

    function initDraw() {
      if (!drawCtx || !drawCanvas) return;
      drawCtx.fillStyle = '#0b0e18';
      drawCtx.fillRect(0, 0, drawCanvas.width, drawCanvas.height);
      drawCtx.lineCap = 'round';
      drawCtx.lineJoin = 'round';
    }
    initDraw();

    S.openDrawer = function () {
      if (!drawerModal) return;
      drawerModal.classList.add('active');
      SFX.open();
      initDraw();
    };

    document.querySelectorAll('.tool-btn[data-tool]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        currentTool = btn.dataset.tool;
        document.querySelectorAll('.tool-btn[data-tool]').forEach(function (b) {
          b.classList.toggle('active', b === btn);
        });
        SFX.tap();
      });
    });

    function canvasPos(e) {
      if (!drawCanvas) return { x: 0, y: 0 };
      const rect = drawCanvas.getBoundingClientRect();
      const sx = drawCanvas.width / rect.width;
      const sy = drawCanvas.height / rect.height;
      const cx = (e.touches ? e.touches[0].clientX : e.clientX) - rect.left;
      const cy = (e.touches ? e.touches[0].clientY : e.clientY) - rect.top;
      return { x: cx * sx, y: cy * sy };
    }

    if (drawCanvas && drawCtx) {
      drawCanvas.addEventListener('pointerdown', function (e) {
        e.preventDefault();
        const p = canvasPos(e);
        drawing = true;
        lastX = p.x;
        lastY = p.y;
        drawCtx.beginPath();
        drawCtx.fillStyle = currentTool === 'eraser' ? '#0b0e18' : (brushColor ? brushColor.value : '#8b7cff');
        drawCtx.arc(p.x, p.y, (brushSize ? parseInt(brushSize.value, 10) : 6) / 2, 0, Math.PI * 2);
        drawCtx.fill();
      });
      drawCanvas.addEventListener('pointermove', function (e) {
        if (!drawing) return;
        e.preventDefault();
        const p = canvasPos(e);
        drawCtx.strokeStyle = currentTool === 'eraser' ? '#0b0e18' : (brushColor ? brushColor.value : '#8b7cff');
        drawCtx.lineWidth = brushSize ? parseInt(brushSize.value, 10) : 6;
        drawCtx.beginPath();
        drawCtx.moveTo(lastX, lastY);
        drawCtx.lineTo(p.x, p.y);
        drawCtx.stroke();
        lastX = p.x;
        lastY = p.y;
      });
      drawCanvas.addEventListener('pointerup', function () { drawing = false; });
      drawCanvas.addEventListener('pointercancel', function () { drawing = false; });
    }

    const clearCanvasBtn = document.getElementById('clearCanvas');
    if (clearCanvasBtn) clearCanvasBtn.addEventListener('click', function () { initDraw(); SFX.tap(); });
    const drawerCancelBtn = document.getElementById('drawerCancel');
    if (drawerCancelBtn) drawerCancelBtn.addEventListener('click', function () {
      if (drawerModal) drawerModal.classList.remove('active');
      SFX.close();
    });
    const drawerCloseBtn = document.getElementById('drawerClose');
    if (drawerCloseBtn) drawerCloseBtn.addEventListener('click', function () {
      if (drawerModal) drawerModal.classList.remove('active');
      SFX.close();
    });
    const drawerSaveBtn = document.getElementById('drawerSave');
    if (drawerSaveBtn && drawCanvas) {
      drawerSaveBtn.addEventListener('click', function () {
        try {
          const dataURL = drawCanvas.toDataURL('image/png');
          processImage(dataURL, 'Drawing ' + (customShapes.length + 1), 'draw').then(function (shape) {
            if (shape) {
              shape.color = brushColor ? brushColor.value : '#8b7cff';
              shape.type = 'draw';
              customShapes.push(shape);
              saveCustom();
              renderCustom();
              if (drawerModal) drawerModal.classList.remove('active');
              SFX.success();
              animateConfetti(15);
              addCredits(CREDIT_COSTS.createShape || -5);
              showToast('Drawing added');
            }
          });
        } catch (e) { showToast('Could not save drawing'); }
      });
    }

    /* Library modal */
    const libraryModal = document.getElementById('libraryModal');
    const libraryGrid = document.getElementById('libraryGrid');
    S.openLibrary = function () {
      if (!libraryModal || !libraryGrid) return;
      libraryModal.classList.add('active');
      SFX.open();
      libraryGrid.innerHTML = '';
      LIBRARY_SHAPES.forEach(function (s) {
        if (!s) return;
        const el = document.createElement('div');
        el.className = 'library-item';
        const cv = document.createElement('canvas');
        el.appendChild(cv);
        const name = document.createElement('div');
        name.className = 'lib-name';
        name.textContent = s.name;
        el.appendChild(name);
        libraryGrid.appendChild(el);
        requestAnimationFrame(function () { safeRenderDots(cv, s, { dotCount: 80, dotSize: 1.0 }); });
        el.addEventListener('click', function () {
          try {
            const copy = JSON.parse(JSON.stringify(s));
            copy.type = 'library';
            customShapes.push(copy);
            saveCustom();
            renderCustom();
            libraryModal.classList.remove('active');
            SFX.success();
            animateConfetti(10);
            showToast('Added from library');
          } catch (e) {}
        });
      });
    };
    const libraryCloseBtn = document.getElementById('libraryClose');
    if (libraryCloseBtn) libraryCloseBtn.addEventListener('click', function () {
      if (libraryModal) libraryModal.classList.remove('active');
      SFX.close();
    });
  }

  /* =========================================================
     SHARED: Side drawer + search
     ========================================================= */
  const sideDrawer = document.getElementById('sideDrawer');
  const drawerOverlay = document.getElementById('drawerOverlay');
  const menuBtn = document.getElementById('menuBtn');
  const sideDrawerClose = document.getElementById('sideDrawerClose');

  if (menuBtn && sideDrawer && drawerOverlay) {
    menuBtn.addEventListener('click', function () {
      sideDrawer.classList.add('open');
      drawerOverlay.classList.add('show');
    });
    if (sideDrawerClose) {
      sideDrawerClose.addEventListener('click', function () {
        sideDrawer.classList.remove('open');
        drawerOverlay.classList.remove('show');
      });
    }
    drawerOverlay.addEventListener('click', function () {
      sideDrawer.classList.remove('open');
      drawerOverlay.classList.remove('show');
    });
  }

  const searchOverlay = document.getElementById('searchOverlay');
  const searchBtn = document.getElementById('searchBtn');
  const searchInput = document.getElementById('searchInput');
  const searchClose = document.getElementById('searchClose');

  if (searchBtn && searchOverlay && searchInput) {
    searchBtn.addEventListener('click', function () {
      searchOverlay.classList.add('open');
      setTimeout(function () { try { searchInput.focus(); } catch (e) {} }, 100);
      searchInput.value = '';
      performSearch('');
    });
    if (searchClose) {
      searchClose.addEventListener('click', function () { searchOverlay.classList.remove('open'); });
    }
    searchInput.addEventListener('input', function (e) { performSearch(e.target.value); });
  }

  function performSearch(q) {
    const results = document.getElementById('searchResults');
    if (!results) return;
    q = (q || '').toLowerCase().trim();
    const matches = SHAPES.filter(function (s) {
      if (!s) return false;
      if (!q) return true;
      if ((s.name || '').toLowerCase().indexOf(q) >= 0) return true;
      if ((s.color || '').toLowerCase().indexOf(q) >= 0) return true;
      return false;
    }).slice(0, 40);
    results.innerHTML = '';
    if (matches.length === 0) {
      results.innerHTML = '<div style="grid-column:1/-1;text-align:center;color:var(--txt-3);padding:40px;">No shapes match</div>';
      return;
    }
    matches.forEach(function (s) {
      const idx = SHAPES.indexOf(s);
      const el = document.createElement('div');
      el.className = 'search-result';
      const cv = document.createElement('canvas');
      cv.width = 120;
      cv.height = 120;
      el.appendChild(cv);
      const name = document.createElement('div');
      name.className = 'sr-name';
      name.textContent = s.name;
      el.appendChild(name);
      results.appendChild(el);
      requestAnimationFrame(function () { safeRenderDots(cv, s, { dotCount: 60, dotSize: 1.2 }); });
      el.addEventListener('click', function () {
        if (searchOverlay) searchOverlay.classList.remove('open');
        const card = document.querySelector('.shape-card[data-shape-index="' + idx + '"]');
        if (card) card.click();
      });
    });
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      if (searchOverlay) searchOverlay.classList.remove('open');
      if (sideDrawer) sideDrawer.classList.remove('open');
      if (drawerOverlay) drawerOverlay.classList.remove('show');
    }
  });

  document.querySelectorAll('.help-question').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const parent = btn.closest('.help-item');
      if (parent) parent.classList.toggle('open');
      SFX.tap();
    });
  });

  document.querySelectorAll('.filter-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.filter-btn').forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      renderGallery(btn.dataset.gfilter);
    });
  });

  function renderGallery(filter) {
    filter = filter || 'all';
    const grid = document.getElementById('galleryGrid');
    const empty = document.getElementById('galleryEmpty');
    if (!grid) return;
    let all = [];
    try { all = JSON.parse(localStorage.getItem('customShapes') || '[]'); }
    catch (e) { all = []; }
    const filtered = filter === 'all' ? all : all.filter(function (s) { return s.type === filter; });
    grid.innerHTML = '';
    if (filtered.length === 0) {
      if (empty) empty.style.display = 'block';
      return;
    }
    if (empty) empty.style.display = 'none';
    filtered.forEach(function (s) {
      if (!s || !s.name) return;
      const el = document.createElement('div');
      el.className = 'custom-shape-card';
      const labels = { multi: 'FILE', draw: 'DRAW', image: 'IMAGE', library: 'LIB' };
      el.innerHTML = '<div class="badge-type">' + (labels[s.type] || 'CUSTOM') + '</div>';
      const cv = document.createElement('canvas');
      el.appendChild(cv);
      const name = document.createElement('div');
      name.className = 'name';
      name.textContent = s.name;
      el.appendChild(name);
      grid.appendChild(el);
      requestAnimationFrame(function () { safeRenderDots(cv, s, { dotCount: 90, dotSize: 1.1 }); });
    });
  }

  /* =========================================================
     SETTINGS PAGE
     ========================================================= */
  if (document.getElementById('page-settings')) {
    const pages = ['dashboard', 'gallery', 'library', 'about', 'help', 'settings'];
    let currentPage = 'settings';

    function goto(name) {
      if (pages.indexOf(name) < 0) name = 'settings';
      currentPage = name;
      document.querySelectorAll('.page').forEach(function (p) { p.classList.remove('active'); });
      const t = document.getElementById('page-' + name);
      if (t) t.classList.add('active');
      document.querySelectorAll('.nav-link, .drawer-link').forEach(function (b) {
        b.classList.toggle('active', b.dataset.nav === name || b.dataset.page === name);
      });
      if (location.hash !== '#' + name) history.pushState({ page: name }, '', '#' + name);
      if (name === 'dashboard') updateDashboard();
      if (name === 'gallery') renderGallery('all');
      if (name === 'library') renderLibrary();
      window.scrollTo({ top: 0, behavior: 'instant' });
      if (sideDrawer) sideDrawer.classList.remove('open');
      if (drawerOverlay) drawerOverlay.classList.remove('show');
    }

    if (location.hash && location.hash.length > 1) {
      const p = location.hash.slice(1);
      goto(pages.indexOf(p) >= 0 ? p : 'settings');
    } else {
      goto('settings');
    }

    document.querySelectorAll('.nav-link, .drawer-link').forEach(function (b) {
      b.addEventListener('click', function (e) {
        const nav = b.dataset.nav || b.dataset.page;
        if (nav && pages.indexOf(nav) >= 0) {
          e.preventDefault();
          goto(nav);
        }
      });
    });
    window.addEventListener('popstate', function () {
      if (location.hash && location.hash.length > 1) {
        const p = location.hash.slice(1);
        if (pages.indexOf(p) >= 0) goto(p);
      }
    });

    function updateDashboard() {
      let cs = [];
      try { cs = JSON.parse(localStorage.getItem('customShapes') || '[]'); }
      catch (e) { cs = []; }
      const set = function (id, v) {
        const e = document.getElementById(id);
        if (e) e.textContent = v;
      };
      set('statShapes', SHAPES.length);
      set('statCustom', cs.length);
      set('statCredits', (typeof S.creditHackEnabled === 'function' && S.creditHackEnabled())
        ? '∞' : (typeof S.credits === 'function' ? S.credits() : 40));
      set('dashDpr', (window.devicePixelRatio || 1).toFixed(2) + 'x');
      set('dashScreen', window.innerWidth + '×' + window.innerHeight);
      set('dashMode', settings.controlMode);
      set('dashQuality', settings.quality);
      set('dashTheme', settings.theme);
      if (navigator.getBattery) {
        navigator.getBattery().then(function (b) {
          set('dashBattery', Math.round(b.level * 100) + '%' + (b.charging ? ' ⚡' : ''));
        }).catch(function () { set('dashBattery', 'N/A'); });
      } else {
        set('dashBattery', 'N/A');
      }
      let frames = 0, last = performance.now();
      function loop() {
        frames++;
        const now = performance.now();
        if (now - last >= 1000) {
          set('statFpsBig', frames + ' fps');
          frames = 0;
          last = now;
        }
        if (currentPage === 'dashboard') requestAnimationFrame(loop);
      }
      loop();
    }

    function renderLibrary() {
      const grid = document.getElementById('libraryPageGrid');
      if (!grid) return;
      grid.innerHTML = '';
      LIBRARY_SHAPES.forEach(function (s) {
        if (!s) return;
        const el = document.createElement('div');
        el.className = 'library-item';
        const cv = document.createElement('canvas');
        el.appendChild(cv);
        const name = document.createElement('div');
        name.className = 'lib-name';
        name.textContent = s.name;
        el.appendChild(name);
        grid.appendChild(el);
        requestAnimationFrame(function () { safeRenderDots(cv, s, { dotCount: 80, dotSize: 1.0 }); });
        el.addEventListener('click', function () {
          try {
            let cs = JSON.parse(localStorage.getItem('customShapes') || '[]');
            const copy = JSON.parse(JSON.stringify(s));
            copy.type = 'library';
            cs.push(copy);
            localStorage.setItem('customShapes', JSON.stringify(cs));
            SFX.success();
            animateConfetti(10);
            showToast('Added from library');
          } catch (e) {}
        });
      });
    }

    const qualityOpts = document.querySelectorAll('#qualityOptions .setting-option');
    qualityOpts.forEach(function (opt) {
      opt.addEventListener('click', function () {
        settings.quality = opt.dataset.quality;
        S.settings.quality = settings.quality;
        S.qualityCfg = S.QUALITY_CFG[settings.quality];
        try { localStorage.setItem('s_quality', settings.quality); } catch (e) {}
        qualityOpts.forEach(function (o) { o.classList.toggle('active', o === opt); });
        SFX.tap();
      });
    });

    document.querySelectorAll('.theme-swatch').forEach(function (sw) {
      sw.addEventListener('click', function () {
        settings.theme = sw.dataset.theme;
        S.settings.theme = settings.theme;
        try { localStorage.setItem('s_theme', settings.theme); } catch (e) {}
        document.querySelectorAll('.theme-swatch').forEach(function (s) { s.classList.toggle('active', s === sw); });
        if (typeof S.applyTheme === 'function') S.applyTheme(settings.theme);
        SFX.tap();
      });
    });

    const controlOpts = document.querySelectorAll('#controlOptions .setting-option');
    controlOpts.forEach(function (opt) {
      opt.addEventListener('click', function () {
        settings.controlMode = opt.dataset.mode;
        try { localStorage.setItem('controlMode', settings.controlMode); } catch (e) {}
        controlOpts.forEach(function (o) { o.classList.toggle('active', o === opt); });
        SFX.tap();
      });
    });

    function bindSlider(id, key, valFn, labelFn) {
      const s = document.getElementById(id);
      const lbl = document.getElementById(id.replace('Slider', 'Value'));
      if (!s) return;
      s.addEventListener('input', function () {
        const raw = parseInt(s.value, 10);
        const real = valFn(raw);
        settings[key] = real;
        S.settings[key] = real;
        try { localStorage.setItem('s_' + key, real); } catch (e) {}
        if (lbl) lbl.textContent = labelFn(real);
      });
    }
    bindSlider('glowStrengthSlider', 'glowStrength', function (v) { return v / 100; }, function (v) { return Math.round(v * 100) + '%'; });
    bindSlider('dotBrightnessSlider', 'dotBrightness', function (v) { return v / 100; }, function (v) { return Math.round(v * 100) + '%'; });
    bindSlider('particleSizeSlider', 'particleSize', function (v) { return v / 100; }, function (v) { return Math.round(v * 100) + '%'; });
    bindSlider('volumeSlider', 'volume', function (v) { return v / 100; }, function (v) { return Math.round(v * 100) + '%'; });

    function bindToggle(id, key, onChange) {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('click', function () {
        settings[key] = !settings[key];
        S.settings[key] = settings[key];
        el.classList.toggle('on', settings[key]);
        try { localStorage.setItem('s_' + key, settings[key]); } catch (e) {}
        SFX.tap();
        if (onChange) onChange(settings[key]);
      });
    }
    bindToggle('toggleSound', 'sound');
    bindToggle('toggleHaptic', 'haptic');
    bindToggle('toggleHandTrack', 'handTrack', function (on) {
      if (on && window.HandTrack && typeof window.HandTrack.start === 'function') {
        try {
          window.HandTrack.start().then(function (ok) {
            if (!ok) {
              settings.handTrack = false;
              S.settings.handTrack = false;
              try { localStorage.setItem('s_handTrack', 'false'); } catch (e) {}
              const el = document.getElementById('toggleHandTrack');
              if (el) el.classList.remove('on');
            }
          }).catch(function () {});
        } catch (e) {}
      } else if (!on && window.HandTrack && typeof window.HandTrack.stop === 'function') {
        try { window.HandTrack.stop(); } catch (e) {}
      }
    });

    const resetAllBtn = document.getElementById('resetAll');
    if (resetAllBtn) {
      resetAllBtn.addEventListener('click', function () {
        if (!confirm('Reset all settings?')) return;
        if (window.HandTrack && typeof window.HandTrack.stop === 'function') {
          try { window.HandTrack.stop(); } catch (e) {}
        }
        try { localStorage.clear(); } catch (e) {}
        location.reload();
      });
    }
  }

  /* =========================================================
     INIT
     ========================================================= */
  try {
    if (typeof S.createCreditHUD === 'function') S.createCreditHUD();
    if (typeof S.updateCreditHUD === 'function') S.updateCreditHUD(false);
    if (typeof S.applyTheme === 'function') S.applyTheme(settings.theme || 'default');
    if (settings.reduceMotion) {
      document.documentElement.classList.add('reduce-motion');
    }
  } catch (e) {}
})();

/* =========================================================
   ✋ HAND TRACKING + CAMERA PREVIEW + GESTURES
   Paste this at the very bottom of app.js — works standalone.
   - Small camera bottom-right
   - Hand follows shape
   - 6 fingers = shatter
   - 5 fingers = reform
   ========================================================= */
(function () {
  'use strict';

  if (window.__HT_LOADED__) return;
  window.__HT_LOADED__ = true;

  const HT = {
    _running: false,
    _video: null,
    _canvas: null,
    _overlay: null,
    _stream: null,
    _raf: null,
    _listeners: [],
    _smooth: { x: 0.5, y: 0.5, active: false },
    _prevFrame: null,
    _workCanvas: null,
    _workCtx: null,
    _handLost: 0,
    _fingerCount: 0,
    _lastFingerCount: 0,
    _gestureDebounce: 0,
    _wrap: null,
    _label: null,

    isRunning: function () { return HT._running; },

    _ensureElements: function () {
      let wrap = document.getElementById('handCamWrap');
      if (wrap) {
        HT._wrap = wrap;
        HT._video = document.getElementById('handVideo');
        HT._canvas = document.getElementById('handOverlay');
        HT._label = wrap.querySelector('.hand-cam-label');
        return;
      }

      // Create from scratch
      wrap = document.createElement('div');
      wrap.id = 'handCamWrap';
      wrap.style.cssText =
        'position:fixed;bottom:100px;right:16px;width:140px;height:105px;' +
        'border-radius:16px;overflow:hidden;' +
        'border:2px solid rgba(139,124,255,.75);background:#000;' +
        'z-index:200;display:none;' +
        'box-shadow:0 12px 40px -8px rgba(139,124,255,.7);';
      document.body.appendChild(wrap);
      HT._wrap = wrap;

      const video = document.createElement('video');
      video.id = 'handVideo';
      video.playsInline = true;
      video.muted = true;
      video.autoplay = true;
      video.style.cssText = 'width:100%;height:100%;object-fit:cover;transform:scaleX(-1);';
      wrap.appendChild(video);
      HT._video = video;

      const overlay = document.createElement('canvas');
      overlay.id = 'handOverlay';
      overlay.style.cssText =
        'position:absolute;inset:0;width:100%;height:100%;' +
        'pointer-events:none;transform:scaleX(-1);';
      wrap.appendChild(overlay);
      HT._canvas = overlay;

      const label = document.createElement('div');
      label.className = 'hand-cam-label';
      label.textContent = '✋ LIVE';
      label.style.cssText =
        'position:absolute;bottom:6px;left:6px;' +
        'font-size:9.5px;font-weight:700;padding:3px 8px;' +
        'border-radius:999px;' +
        'background:linear-gradient(135deg,#8b7cff,#4dd4ff);' +
        'color:#fff;letter-spacing:.5px;';
      wrap.appendChild(label);
      HT._label = label;
    },

    start: function () {
      if (HT._running) return Promise.resolve(true);

      HT._ensureElements();

      return navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: 320, height: 240 },
        audio: false
      }).then(function (stream) {
        HT._stream = stream;
        HT._video.srcObject = stream;
        HT._video.play().catch(function () {});

        HT._overlay = HT._canvas.getContext('2d');
        function resize() {
          HT._canvas.width = HT._video.videoWidth || 320;
          HT._canvas.height = HT._video.videoHeight || 240;
        }
        if (HT._video.readyState >= 2) resize();
        else HT._video.addEventListener('loadedmetadata', resize, { once: true });

        HT._wrap.style.display = 'block';
        HT._wrap.style.borderColor = 'rgba(139,124,255,.75)';
        if (HT._label) HT._label.textContent = '✋ LIVE';

        HT._startLoop();
        HT._running = true;

        if (window.ShapeStudio && window.ShapeStudio.showToast) {
          window.ShapeStudio.showToast('✋ Hand tracking ON');
        }
        return true;
      }).catch(function () {
        HT._wrap.style.display = 'block';
        HT._wrap.style.borderColor = 'rgba(255,77,109,.8)';
        if (HT._label) {
          HT._label.textContent = '⛔ DENIED';
          HT._label.style.background = 'linear-gradient(135deg,#ff4d6d,#ff2e5c)';
        }
        if (window.ShapeStudio && window.ShapeStudio.showToast) {
          window.ShapeStudio.showToast('Camera permission denied');
        }
        return false;
      });
    },

    _startLoop: function () {
      HT._workCanvas = document.createElement('canvas');
      HT._workCanvas.width = 80;
      HT._workCanvas.height = 60;
      HT._workCtx = HT._workCanvas.getContext('2d', { willReadFrequently: true });
      HT._prevFrame = null;

      function tick() {
        if (!HT._running) return;
        try {
          if (HT._video && HT._video.readyState >= 2) {
            HT._workCtx.drawImage(HT._video, 0, 0, 80, 60);
            const data = HT._workCtx.getImageData(0, 0, 80, 60).data;
            HT._processFrame(data);
          }
        } catch (e) {}
        HT._raf = requestAnimationFrame(tick);
      }
      tick();
    },

    _processFrame: function (data) {
      const w = 80, h = 60;
      const curr = new Uint8Array(w * h);
      for (let i = 0; i < w * h; i++) {
        curr[i] = (data[i * 4] + data[i * 4 + 1] + data[i * 4 + 2]) / 3;
      }
      if (!HT._prevFrame) {
        HT._prevFrame = curr;
        return;
      }

      let sumW = 0, sumX = 0, sumY = 0, motionPx = 0;
      for (let y = 0; y < h; y++) {
        for (let x = 0; x < w; x++) {
          const i = y * w + x;
          const d = Math.abs(curr[i] - HT._prevFrame[i]);
          if (d > 22) {
            const weight = d;
            sumW += weight;
            sumX += x * weight;
            sumY += y * weight;
            motionPx++;
          }
        }
      }
      HT._prevFrame = curr;

      const totalPx = w * h;
      const motionRatio = motionPx / totalPx;

      let estimatedFingers = 0;
      if (motionRatio > 0.001) {
        estimatedFingers = Math.min(6, Math.round(motionRatio * 300));
      }

      if (estimatedFingers >= 5) {
        HT._fingerCount = estimatedFingers;
      } else if (estimatedFingers < 4) {
        HT._fingerCount = estimatedFingers;
      }

      if (sumW > 0 && motionRatio > 0.02) {
        const cx = sumX / sumW;
        const cy = sumY / sumW;
        const hx = 1 - (cx / w);
        const hy = cy / h;
        HT._updateHand(hx, hy);

        if (HT._overlay && HT._canvas) {
          HT._overlay.clearRect(0, 0, HT._canvas.width, HT._canvas.height);
          const pw = HT._canvas.width, ph = HT._canvas.height;

          HT._overlay.beginPath();
          HT._overlay.arc(cx / w * pw, cy / h * ph, 14, 0, Math.PI * 2);
          HT._overlay.fillStyle = 'rgba(77,212,255,0.6)';
          HT._overlay.fill();
          HT._overlay.strokeStyle = 'rgba(255,255,255,.9)';
          HT._overlay.lineWidth = 2;
          HT._overlay.stroke();

          HT._overlay.font = 'bold 20px Inter, sans-serif';
          HT._overlay.fillStyle = HT._fingerCount >= 6 ? '#ff5c8c' :
                                  HT._fingerCount >= 5 ? '#5cff8c' : '#8b7cff';
          HT._overlay.textAlign = 'right';
          HT._overlay.fillText(HT._fingerCount + '✋', pw - 6, ph - 10);
        }
      } else {
        HT._handleLost();
      }
    },

    _updateHand: function (x, y) {
      HT._handLost = 0;
      const s = 0.35;
      if (!HT._smooth.active) {
        HT._smooth = { x: x, y: y, active: true };
      } else {
        HT._smooth.x += (x - HT._smooth.x) * s;
        HT._smooth.y += (y - HT._smooth.y) * s;
      }
      HT._dispatch();
    },

    _handleLost: function () {
      HT._handLost++;
      if (HT._handLost > 6) {
        HT._smooth.active = false;
        if (HT._overlay && HT._canvas) {
          HT._overlay.clearRect(0, 0, HT._canvas.width, HT._canvas.height);
        }
        HT._dispatch();
      }
    },

    _dispatch: function () {
      if (!HT._smooth.active) return;
      const data = {
        x: HT._smooth.x,
        y: HT._smooth.y,
        active: true,
        fingers: HT._fingerCount
      };
      for (let i = 0; i < HT._listeners.length; i++) {
        try { HT._listeners[i](data); } catch (e) {}
      }
      HT._checkGestures();
    },

    _checkGestures: function () {
      const now = Date.now();
      if (now - HT._gestureDebounce < 800) return;

      const S = window.ShapeStudio;
      if (!S || !S.features || !S.features.Shatter) return;

      // 6 fingers = shatter
      if (HT._fingerCount >= 6 && HT._lastFingerCount < 6) {
        HT._gestureDebounce = now;
        HT._lastFingerCount = 6;
        const wrap = document.getElementById('shapeWrap');
        if (wrap && S.features.Shatter.state === 'intact') {
          S.features.Shatter.trigger(wrap, '#ff5c8c');
          if (S.SFX && S.SFX.shatter) S.SFX.shatter();
          if (S.showToast) S.showToast('💥 SHATTERED! (5 fingers to reform)');
        }
      }
      // 5 fingers (after 6) = reform
      else if (HT._fingerCount >= 5 && HT._fingerCount < 6 && HT._lastFingerCount >= 6) {
        HT._gestureDebounce = now;
        HT._lastFingerCount = 5;
        if (S.features.Shatter.state === 'shattered') {
          S.features.Shatter.reform();
          if (S.SFX && S.SFX.reform) S.SFX.reform();
          if (S.showToast) S.showToast('✨ REFORMED!');
        }
      } else {
        HT._lastFingerCount = HT._fingerCount;
      }
    },

    stop: function () {
      HT._running = false;
      if (HT._raf) { cancelAnimationFrame(HT._raf); HT._raf = null; }
      if (HT._stream) {
        HT._stream.getTracks().forEach(function (t) { t.stop(); });
        HT._stream = null;
      }
      if (HT._video) HT._video.srcObject = null;
      if (HT._wrap) HT._wrap.style.display = 'none';
      if (HT._overlay && HT._canvas) {
        HT._overlay.clearRect(0, 0, HT._canvas.width, HT._canvas.height);
      }
      HT._smooth = { x: 0.5, y: 0.5, active: false };
      HT._prevFrame = null;
      HT._fingerCount = 0;
      HT._lastFingerCount = 0;
      if (window.ShapeStudio && window.ShapeStudio.showToast) {
        window.ShapeStudio.showToast('Camera off');
      }
    },

    onUpdate: function (cb) {
      if (typeof cb === 'function') HT._listeners.push(cb);
      return function () {
        const i = HT._listeners.indexOf(cb);
        if (i >= 0) HT._listeners.splice(i, 1);
      };
    },

    getPosition: function () {
      return HT._smooth.active ? { x: HT._smooth.x, y: HT._smooth.y } : null;
    },

    getFingers: function () { return HT._fingerCount; }
  };

  window.HandTrack = HT;
  if (window.ShapeStudio) window.ShapeStudio.HandTrack = HT;

  // ---------- Auto hook into Stage ----------
  // When stage becomes active and handTrack is ON, start camera
  // When stage closes, stop camera
  let stageObserver = null;
  let handUnsub = null;

  function connectStage() {
    const stage = document.getElementById('stage');
    if (!stage || stageObserver) return;

    stageObserver = new MutationObserver(function () {
      const S = window.ShapeStudio;
      const on = S && S.settings && S.settings.handTrack;

      if (stage.classList.contains('active')) {
        if (on && !HT.isRunning()) {
          HT.start().then(function (ok) {
            if (!ok) return;
            handUnsub = HT.onUpdate(function (data) {
              if (!data || !data.active) return;
              if (S && S.settings && S.settings.controlMode === 'auto') return;

              const wrap = document.getElementById('shapeWrap');
              if (!wrap) return;

              // Read current transform to get target
              // We drive the shape by dispatching a custom pointer event
              // The stage code reads target via the actual pointer events
              // so we simulate moving the pointer across the screen
              const marginX = 100;
              const marginY = 140;
              const px = marginX + data.x * (window.innerWidth - marginX * 2);
              const py = marginY + data.y * (window.innerHeight - marginY * 2);

              // Direct transform override (physics mode has its own)
              if (!document.body.classList.contains('physics-mode')) {
                wrap.style.transform =
                  'translate(' + px + 'px, ' + py + 'px) ' +
                  'translate(-50%, -50%) ' +
                  'rotate(0deg) scale(1)';
              }
            });
          });
        }
      } else {
        if (HT.isRunning()) HT.stop();
        if (handUnsub) { handUnsub(); handUnsub = null; }
      }
    });
    stageObserver.observe(stage, { attributes: true, attributeFilter: ['class'] });
  }

  // Connect stage when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', connectStage);
  } else {
    connectStage();
  }

  // Watch for handTrack setting toggle from settings page
  let lastFlag = null;
  setInterval(function () {
    const S = window.ShapeStudio;
    const on = S && S.settings && S.settings.handTrack;
    if (lastFlag === null) { lastFlag = on; return; }
    if (on !== lastFlag) {
      lastFlag = on;
      if (on) {
        // User turned it ON — start camera immediately
        HT.start();
      } else {
        HT.stop();
      }
    }
  }, 500);

})();
