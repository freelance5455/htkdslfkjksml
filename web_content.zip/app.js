function predict(){
 const raw=document.getElementById('history').value;
 const nums=raw.split(',').map(x=>parseFloat(x.trim())).filter(x=>Number.isFinite(x)&&x>=1);
 const out=document.getElementById('result');
 if(nums.length<3){out.textContent='Please enter at least 3 valid multipliers.';return;}
 const avg=nums.reduce((a,b)=>a+b,0)/nums.length;
 const recent=nums.slice(-5);
 const r=recent.reduce((a,b)=>a+b,0)/recent.length;
 const estimate=Math.max(1.01,Math.min(10,(avg+r)/2));
 const confidence=Math.max(5,Math.min(95,Math.round(50+Math.min(30,(avg-1)*8))));
 out.innerHTML='<div>Demo estimate</div><div class="value">'+estimate.toFixed(2)+'×</div>'+
 '<div>Confidence indicator: '+confidence+'%</div>'+
 '<small>Random crash games cannot be reliably predicted. Use this only as a statistical demo.</small>';
}