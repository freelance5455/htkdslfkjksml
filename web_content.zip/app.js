const $=id=>document.getElementById(id);
const state={questions:JSON.parse(localStorage.getItem("iraqiQuestions")||"[]")};
function subjectValue(){return $("subject").value==="other"?$("customSubject").value.trim():$("subject").value}
function timeText(){let h=Math.max(0,Number($("hours").value)||0),m=Math.max(0,Number($("minutes").value)||0);return `${h} ساعة${m?` و ${m} دقيقة`:""}`}
function updateNumbers(){document.querySelectorAll(".question-editor").forEach((q,i)=>q.querySelector(".q-number").textContent=`السؤال ${i+1}`)}
function addQuestion(data={}){const node=$("questionTemplate").content.cloneNode(true),q=node.querySelector(".question-editor");$("questions").appendChild(q);
q.querySelector(".q-type").value=data.type||"عادي";q.querySelector(".q-mark").value=data.mark??10;q.querySelector(".q-text").value=data.text||"";
[...q.querySelectorAll(".options input")].forEach((x,i)=>x.value=(data.options||[])[i]||"");
bindQuestion(q);updateNumbers();toggleOptions(q)}
function bindQuestion(q){
 q.querySelector(".delete").onclick=()=>{q.remove();updateNumbers()};
 q.querySelector(".duplicate").onclick=()=>{addQuestion({type:q.querySelector(".q-type").value,mark:q.querySelector(".q-mark").value,text:q.querySelector(".q-text").value,options:[...q.querySelectorAll(".options input")].map(x=>x.value)})};
 q.querySelector(".q-type").onchange=()=>toggleOptions(q);
 q.querySelectorAll("textarea,input").forEach(x=>x.oninput=()=>{});
 q.querySelectorAll(".math-toolbar button").forEach(b=>b.onclick=()=>{let t=q.querySelector(".q-text"),p=t.selectionStart||t.value.length,s=t.selectionEnd||p;t.value=t.value.slice(0,p)+b.dataset.insert+t.value.slice(s);t.focus();t.selectionStart=t.selectionEnd=p+b.dataset.insert.length});
}
function toggleOptions(q){q.querySelector(".options").classList.toggle("hidden",q.querySelector(".q-type").value!=="اختيار من متعدد")}
function collect(){return [...document.querySelectorAll(".question-editor")].map(q=>({type:q.querySelector(".q-type").value,mark:Number(q.querySelector(".q-mark").value)||0,text:q.querySelector(".q-text").value,options:[...q.querySelectorAll(".options input")].map(x=>x.value)}))}
function saveLocal(){state.questions=collect();localStorage.setItem("iraqiQuestions",JSON.stringify(state.questions))}
function paperHTML(){
 const school=$("school").value||"—",grade=$("grade").value||"—",sub=subjectValue()||"—",teacher=$("teacher").value||"—";
 const type=$("teacherType").value,date=$("examDate").value||"—",header=$("headerText").value.trim(),footer=$("footerText").value.trim()||"مع تمنياتنا لكم بالنجاح";
 let qs=collect(), rows=qs.map((x,i)=>`<div class="paper-question"><strong>${i+1}. ${escapeHTML(x.text||"")}</strong>${x.type==="اختيار من متعدد"?`<div class="paper-options">${x.options.map((o,j)=>`<span>${"أبجد"[j]||j+1}. ${escapeHTML(o)}</span>`).join("")}</div>`:""}<span style="float:left;font-weight:700">(${x.mark} درجة)</span></div>`).join("");
 return `<div class="paper-head">${header?`<div class="paper-headline">${escapeHTML(header)}</div>`:""}<table class="info-table"><tr><td class="key">اسم المدرسة:</td><td>${escapeHTML(school)}</td><td class="key">المادة:</td><td>${escapeHTML(sub)}</td></tr><tr><td class="key">${escapeHTML(type)}:</td><td>${escapeHTML(teacher)}</td><td class="key">الصف:</td><td>${escapeHTML(grade)}</td></tr><tr><td class="key">الوقت:</td><td>${escapeHTML(timeText())}</td><td class="key">التاريخ:</td><td>${escapeHTML(date)}</td></tr></table><div class="double-line"></div>${qs.length?qs.map((x,i)=>`<div class="paper-question"><strong>${i+1}. ${escapeHTML(x.text||"")}</strong>${x.type==="اختيار من متعدد"?`<div class="paper-options">${x.options.map((o,j)=>`<span>${["أ","ب","ج","د"][j]}. ${escapeHTML(o)}</span>`).join("")}</div>`:""}<span style="float:left;font-weight:700">(${x.mark} درجة)</span></div>`).join(""):`<p>لا توجد أسئلة بعد.</p>`}<div class="paper-footer">${escapeHTML(footer)}</div></div>`
}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function preview(){saveLocal();$("preview").innerHTML=paperHTML()}
async function exportWord(){
 saveLocal(); if(!window.docx){alert("مكتبة Word لم تُحمّل. تحقق من اتصال الإنترنت ثم حاول مرة أخرى.");return}
 const {Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,WidthType,AlignmentType,PageOrientation,PageSize}=docx;
 const q=collect(),sub=subjectValue()||"—",school=$("school").value||"—",grade=$("grade").value||"—",teacher=$("teacher").value||"—",type=$("teacherType").value,date=$("examDate").value||"—",footer=$("footerText").value||"مع تمنياتنا لكم بالنجاح";
 const cell=(a,b)=>new TableCell({children:[new Paragraph({children:[new TextRun({text:a,bold:true}),new TextRun({text:" "+b})]})]});
 const info=new Table({width:{size:100,type:WidthType.PERCENTAGE},rows:[
  new TableRow({children:[cell("اسم المدرسة:",school),cell("المادة:",sub)]}),
  new TableRow({children:[cell(type+":",teacher),cell("الصف:",grade)]}),
  new TableRow({children:[cell("الوقت:",timeText()),cell("التاريخ:",date)]})
 ]});
 const children=[new Paragraph({text:$("headerText").value||"امتحان",alignment:AlignmentType.CENTER}),info,
 new Paragraph({border:{top:{style:"single",size:18},bottom:{style:"single",size:18}},text:""})];
 q.forEach((x,i)=>{children.push(new Paragraph({spacing:{after:180},border:{bottom:{style:"single",size:12}},children:[new TextRun({text:`${i+1}. ${x.text}`,bold:true}),new TextRun({text:`   (${x.mark} درجة)`,bold:true})]}));if(x.type==="اختيار من متعدد")x.options.forEach((o,j)=>children.push(new Paragraph({text:`${["أ","ب","ج","د"][j]}. ${o}`,indent:{right:500}})))});
 children.push(new Paragraph({text:footer,alignment:AlignmentType.CENTER,spacing:{before:500}}));
 const doc=new Document({sections:[{properties:{page:{size:{width:11906,height:16838,orientation:PageOrientation.PORTRAIT},margin:{top:850,right:850,bottom:850,left:850}}},children}]});
 const blob=await Packer.toBlob(doc);const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="امتحان_A4.docx";a.click()
}
$("subject").onchange=()=>{$("customSubject").classList.toggle("hidden",$("subject").value!=="other")};
$("addQuestion").onclick=()=>addQuestion();$("previewBtn").onclick=preview;
$("printBtn").onclick=()=>{preview();setTimeout(()=>window.print(),100)};
$("wordBtn").onclick=exportWord;
$("clearQuestions").onclick=()=>{if(confirm("مسح جميع الأسئلة؟")){$("questions").innerHTML="";state.questions=[];saveLocal()}};
$("saveBank").onclick=()=>{const bank=JSON.parse(localStorage.getItem("iraqiQuestionBank")||"[]");bank.push(...collect().map(x=>({...x,subject:subjectValue(),difficulty:$("difficulty").value,unit:$("bankUnit").value})));localStorage.setItem("iraqiQuestionBank",JSON.stringify(bank));alert("تم حفظ الأسئلة في بنك الأسئلة")};
$("loadBank").onclick=()=>{const bank=JSON.parse(localStorage.getItem("iraqiQuestionBank")||"[]"),term=$("bankSearch").value.trim();bank.filter(x=>!term||x.text.includes(term)).slice(0,20).forEach(addQuestion)};
$("generateQuestions").onclick=()=>{const bank=JSON.parse(localStorage.getItem("iraqiQuestionBank")||"[]"),pool=bank.filter(x=>!subjectValue()||x.subject===subjectValue());pool.sort(()=>Math.random()-.5).slice(0,5).forEach(addQuestion)};
$("fullscreenBtn").onclick=()=>{if(!document.fullscreenElement)document.documentElement.requestFullscreen?.();else document.exitFullscreen?.()};
window.addEventListener("load",()=>{if(!state.questions.length)addQuestion();else state.questions.forEach(addQuestion);preview()});
window.addEventListener("beforeunload",saveLocal);
document.addEventListener("fullscreenchange",()=>{$("app").classList.toggle("fullscreen",!!document.fullscreenElement)});
document.addEventListener("keydown",e=>{if(e.key==="F11"){e.preventDefault();$("fullscreenBtn").click()}});
