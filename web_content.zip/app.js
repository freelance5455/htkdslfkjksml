// ==========================================
// MASTER RECIPE BOOK APPLICATION LOGIC
// ==========================================
var defaultRecipes = [
    {
        id: 1,
        category: "Breakfast",
        isCustom: false,
        creator: 'System',
        name: { en: "Classic Pancakes", af: "Klassieke Pannekoeke" },
        desc: { en: "Fluffy and golden breakfast favorites.", af: "Flouerige en goue ontbytgunstelinge." },
        img: "https://unsplash.com",
        ingredients: {
            metric: { en: ["200g Flour", "2 Eggs", "300ml Milk"], af: ["200g Meel", "2 Eiers", "300ml Melk"] },
            imperial: { en: ["1.5 Cups Flour", "2 Eggs", "1.25 Cups Milk"], af: ["1.5 Koppies Meel", "2 Eiers", "1.25 Koppies Melk"] }
        },
        method: { en: ["Whisk flour.", "Cook on hot skillet."], af: ["Klits meel.", "Bak op ‘n warm pan."] },
        serving: { en: "Serve with syrup.", af: "Sit voor met stroop." }
    },
    {
        id: 2,
        category: "Main Dishes",
        isCustom: false,
        creator: "System",
        name: { en: "Spiced Bobotie", af: "Gekruide Bobotie" },
        desc: { en: "Traditional South African baked minced meat dish.", af: "Tradisionele Suid-Afrikaanse gebakte maalvleisgereg." },
        img: "https://unsplash.com",
        ingredients: {
            metric: { en: ["500g Minced Beef", "1 Onion, Chopped", "1 slice White Bread", "250ml Milk", "2 Eggs", "1 tbsp Curry Powder"], af: ["500g Maalvleis", "1 Ui, Gekap", "1 sny Witbrood", "250ml Melk", "2 Eiers", "1 e Kerriepoeier"] },
            imperial: { en: ["1.1 lbs Minced Beef", "1 Onion, Chopped", "1 slice White Bread", "1 Cup Milk", "2 Eggs", "1 tbsp Curry Powder"], af: ["1.1 lbs Maalvleis", "1 Ui, Gekap", "1 sny Witbrood", "1 k Melk", "2 Eiers", "1 e Kerriepoeier"] }
        },
        method: { en: ["Soak bread in milk.", "Brown mince and onion with curry spices.", "Mix together, pour egg custard over, and bake at 180°C."], af: ["Week brood in melk.", "Braai maalvleis en ui saam met kerriespeserye.", "Meng alles saam, gooi eiervla oor en bak by 180°C."] },
        serving: { en: "Serve warm with yellow rice and chutney.", af: "Sit warm voor saam met geelrys and blatjang." }
    },
    {
        id: 3,
        category: "Desserts",
        isCustom: false,
        creator: "System",
        name: { en: "Malva Pudding", af: "Malvapoeding" },
        desc: { en: "A sweet, rich, and spongy traditional baked pudding.", af: "n Soet, ryk en sponserige tradisionele gebakte poeding." },
        img: "https://unsplash.com",
        ingredients: {
            metric: { en: ["200g Sugar", "2 Large Eggs", "1 tbsp Apricot Jam", "150g Cake Flour", "1 tsp Baking Soda", "30g Butter", "100ml Milk"], af: ["200g Suiker", "2 Groot Eiers", "1 e Appelkooskonfyt", "150g Koekmeel", "1 t Koeksoda", "30g Botter", "100ml Melk"] },
            imperial: { en: ["1 Cup Sugar", "2 Large Eggs", "1 tbsp Apricot Jam", "1.25 Cups Flour", "1 tsp Baking Soda", "2 tbsp Butter", "0.4 Cup Milk"], af: ["1 k Suiker", "2 Groot Eiers", "1 e Appelkooskonfyt", "1.25 k Meel", "1 t Koeksoda", "2 e Botter", "0.4 k Melk"] }
        },
        method: { en: ["Whisk sugar and eggs, fold in jam, melted butter, flour and milk.", "Bake at 180°C until golden.", "Pour hot cream sauce over the hot pudding instantly when out of the oven."], af: ["Klits suiker en eiers, vou konfyt, gesmelte botter, meel en melk in.", "Bak by 180°C tot goudbruin.", "Gooi warm roomsous dadelik oor die warm poeding wanneer dit uit die oond kom."] },
        serving: { en: "Serve warm with warm custard or vanilla ice cream.", af: "Sit warm voor met warm vla of vanilla-roomys." }
    }
];

// SIMULATED VERSION TRACKING 
var CURRENT_VERSION = "1.0.0";
var CLOUD_DATABASE_URL = "https://jsonbin.io";
var MASTER_KEY = '$2a$10$IFsoAQUJmzOdlmpBah4HuerhSgv8FxIOOLG8dlJc7GM8S0qpmnPCO';
var communityRecipesShared = [];

var appState = {
    unit: 'metric',
    lang: "en",
    audioEnabled: false,
    currentScreen: "welcome-screen",
    currentTab: "all",
    activeRecipeId: null,
    currentUser: "User_1"
};

var expandedCategories = { "Breakfast": true, "Main Dishes": true, "Desserts": true };

document.addEventListener("DOMContentLoaded", function() {
    initializeUserEnvironments();
    checkForApplicationUpdates();
    populateUserDropdown();
    renderRecipeList();
});

// ==========================================
// FEATURE 1: MULTI-USER REGISTRATION ENGINE
// ==========================================
function initializeUserEnvironments() {
    var usersList = JSON.parse(localStorage.getItem('app_registered_users')) || ["User_1"];
    localStorage.setItem('app_registered_users', JSON.stringify(usersList));
    
    usersList.forEach(function(usr) {
        if (!localStorage.getItem(usr + '_favorites')) localStorage.setItem(usr + '_favorites', JSON.stringify([]));
        if (!localStorage.getItem(usr + '_customs')) localStorage.setItem(usr + '_customs', JSON.stringify([]));
    });
    
    appState.currentUser = usersList[0];
}

function populateUserDropdown() {
    var select = document.getElementById('user-selector');
    if (!select) return;
    var usersList = JSON.parse(localStorage.getItem('app_registered_users')) || ["User_1"];
    
    select.innerHTML = "";
    usersList.forEach(function(usr) {
        var opt = document.createElement('option');
        opt.value = usr;
        opt.innerText = usr.replace('_', ' ');
        select.appendChild(opt);
    });
    select.value = appState.currentUser;
}

function createNewUserPrompt() {
    var rawName = prompt(appState.lang === 'en' ? "Enter New Username:" : "Voer nuwe gebruikersnaam in:");
    if (!rawName) return;
    
    var sanitized = rawName.trim().replace(/\s+/g, '_');
    var usersList = JSON.parse(localStorage.getItem('app_registered_users')) || [];
    
    if (usersList.includes(sanitized)) {
        alert(appState.lang === 'en' ? "User already exists!" : "Gebruiker bestaan reeds!");
        return;
    }
    
    usersList.push(sanitized);
    localStorage.setItem('app_registered_users', JSON.stringify(usersList));
    
    localStorage.setItem(sanitized + '_favorites', JSON.stringify([]));
    localStorage.setItem(sanitized + '_customs', JSON.stringify([]));
    
    appState.currentUser = sanitized;
    populateUserDropdown();
    renderRecipeList();
}

function switchUser(val) {
    appState.currentUser = val;
    renderRecipeList();
}

// ==========================================
// FEATURE 2: MOBILE AUDIO ENGINE COOLDOWN RECOVERY
// ==========================================
function speakRecipe(title, desc, ingredients, steps) {
    if (!window.speechSynthesis) {
        console.warn("Speech engine completely unsupported by WebView container platform.");
        return;
    }
    
    window.speechSynthesis.cancel(); 
    var text = title + ". " + desc + ". " + 
               (appState.lang === 'en' ? 'Ingredients' : 'Bestanddele') + ": " + ingredients.join(', ') + ". " + 
               (appState.lang === 'en' ? 'Method' : 'Metode') + ": " + steps.join('. ');
               
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = appState.lang === 'en' ? 'en-US' : 'af-ZA';
    utterance.rate = 0.95; 
    
    var speechEnforcerTimer = setInterval(function () {
        if (!window.speechSynthesis.speaking) {
            clearInterval(speechEnforcerTimer);
        } else {
            window.speechSynthesis.resume();
        }
    }, 8000);
    
    utterance.onerror = function(e) {
        console.error("Mobile Speech Error caught: ", e);
    };
    window.speechSynthesis.speak(utterance);
}

// ==========================================
// FEATURE 3: PHONE PRINT LIMIT COOLDOWN (1 PER DAY)
// ==========================================
function triggerPrint() {
    var todayStr = new Date().toISOString().split('T')[0]; 
    var lastPrintDate = localStorage.getItem('device_last_print_date');
    
    if (lastPrintDate === todayStr) {
        var errorMsg = appState.lang === 'en' ? 
            "Print Limit Reached! Only 1 print copy allowed per day on this device profile." : 
            "Drukbeperking bereik! Slegs 1 afskrif per dag word toegelaat op hierdie toestel.";
        alert(errorMsg);
        return;
    }
    
    localStorage.setItem('device_last_print_date', todayStr);
    updatePrintStatusLabel();
    window.print();
}

function updatePrintStatusLabel() {
    var todayStr = new Date().toISOString().split('T')[0];
    var lastPrintDate = localStorage.getItem('device_last_print_date');
    var label = document.getElementById('print-limit-status');
    if (!label) return;
    
    if (lastPrintDate === todayStr) {
        label.innerText = appState.lang === 'en' ? "⚠️ Daily print used for today." : "⚠️ Daaglikse druk reeds gebruik vir vandag.";
        label.style.color = "#dc3545";
    } else {
        label.innerText = appState.lang === 'en' ? "✅ 1 print copy available for today." : "✅ 1 afskrif beskikbaar vir vandag.";
        label.style.color = "#28a745";
    }
}

// ==========================================
// FEATURE 4: AUTOMATED SYSTEM VERSION CHECKS
// ==========================================
function checkForApplicationUpdates() {
    fetch(CLOUD_DATABASE_URL + "/latest", { method: 'GET', headers: { 'X-Master-Key': MASTER_KEY } })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            var latestServerVersion = data.metadata?.version || "1.0.0";
            if (latestServerVersion !== CURRENT_VERSION) {
                var banner = document.getElementById('update-notification-banner');
                if (banner) banner.style.display = "block";
            }
        })
        .catch(function(err) { 
            console.log("Version verification check bypassed due to network state.", err); 
        });
}

function applyAppUpdate() {
    alert(appState.lang === 'en' ? "Downloading systemic update patches... Clearing Cache." : "Laai tans stelselopdaterings af... Maak kas skoon.");
    location.reload(true);
}

// ==========================================
// STANDARD APPLICATION INTERFACE PLUMBING
// ==========================================
function getAllRecipes() {
    var text = localStorage.getItem(appState.currentUser + '_customs');
    var localCustoms = [];
    try {
        if (text) localCustoms = JSON.parse(text);
    } catch (e) {
        localCustoms = [];
    }
    return defaultRecipes.concat(localCustoms).concat(communityRecipesShared);
}

function nextScreen(screenId) {
    document.getElementById(appState.currentScreen).classList.replace('active', 'hidden');
    document.getElementById(screenId).classList.replace('hidden', 'active');
    appState.currentScreen = screenId;
}

function selectUnit(unit) { 
    appState.unit = unit; 
    nextScreen('language-screen'); 
}

function selectLanguage(lang) { 
    appState.lang = lang; 
    
    var isEn = lang === 'en';
    var audioTitle = document.getElementById('audio-title');
    var audioYes = document.getElementById('audio-yes');
    var audioNo = document.getElementById('audio-no');
    
    if (audioTitle) audioTitle.innerText = isEn ? "Read Aloud?" : "Wil jy hê die resep moet hardop gelees word?";
    if (audioYes) audioYes.innerText = isEn ? "Yes / Ja" : "Ja";
    if (audioNo) audioNo.innerText = isEn ? "No / Nee" : "Nee";

    nextScreen('audio-screen'); 
}

function selectAudio(enabled) { 
    appState.audioEnabled = enabled; 
    
    var isEn = appState.lang === 'en';
    var listTitle = document.getElementById('list-title');
    var tabAll = document.getElementById('tab-all');
    var tabFav = document.getElementById('tab-fav');
    var addTitle = document.getElementById('add-title');
    
    if (listTitle) listTitle.innerText = isEn ? "Recipe Categories" : "Resep Kategorieë";
    if (tabAll) tabAll.innerText = isEn ? "Index Tree" : "Inhoudsboom";
    if (tabFav) tabFav.innerText = isEn ? "★ My Favorites" : "★ My Gunstelinge";
    if (addTitle) addTitle.innerText = isEn ? "Add Recipe" : "Nuwe Resep";
    
    renderRecipeList();
    nextScreen('list-screen'); 
}

function switchTab(t) {
    appState.currentTab = t;
    var tabAll = document.getElementById('tab-all');
    var tabFav = document.getElementById('tab-fav');
    if (tabAll) tabAll.classList.toggle('active-tab', t === 'all');
    if (tabFav) tabFav.classList.toggle('active-tab', t === 'fav');
    renderRecipeList();
}

function renderRecipeList() {
    var container = document.getElementById('recipe-list-container');
    if (!container) return;
    container.innerHTML = "";
    var list = getAllRecipes();
    
    if (appState.currentTab === 'fav') {
        var favs = JSON.parse(localStorage.getItem(appState.currentUser + '_favorites')) || [];
        list = list.filter(function (r) {
            return favs.includes(r.id.toString());
        });
    }
    
    var categories = ["Breakfast", "Main Dishes", "Desserts"];
    categories.forEach(function (cat) {
        var catList = list.filter(function (r) { 
            return r.category === cat; 
        });
        if (catList.length === 0) return;
        
        var header = document.createElement('div');
        header.className = "category-tree-header";
        
        var displayCategoryName = cat;
        if (appState.lang === 'af') {
            if (cat === "Breakfast") displayCategoryName = "Ontbyt";
            if (cat === "Main Dishes") displayCategoryName = "Hoofgeregte";
            if (cat === "Desserts") displayCategoryName = "Nageregte";
        }
        
        header.innerText = displayCategoryName + " (" + catList.length + ") ▾";
        container.appendChild(header);
        
        var wrapper = document.createElement('div');
        wrapper.className = "category-recipes-wrapper";
        
        catList.forEach(function (recipe) {
            var card = document.createElement('div');
            card.className = "recipe-summary-card";
            
            var title = recipe.isCustom ? recipe.name : recipe.name[appState.lang];
            var desc = recipe.isCustom ? recipe.desc : recipe.desc[appState.lang];
            var listArray = [];
            
            if (recipe.isCustom) {
                listArray = recipe.ingredients || [];
            } else if (recipe.ingredients && recipe.ingredients[appState.unit]) {
                listArray = recipe.ingredients[appState.unit][appState.lang] || [];
            }
            
            var ingPreview = listArray.slice(0, 3).join(', ');
            
            card.innerHTML = `<h3>${title}</h3>
                             <p class="desc" style="font-style: italic; font-size: 0.9rem; color: #555; margin-bottom: 5px; margin-top: 5px;">${desc}</p>
                             <p class="ing-preview" style="font-size: 0.8rem; color: #777; margin-bottom: 10px;">
                                ${appState.lang === 'en' ? 'Ingredients' : 'Bestanddele'}: ${ingPreview ? ingPreview + '...' : '---'}
                             </p>
                             <button class="btn" style="padding: 6px 12px; margin: 5px 0 0 0; width: auto; font-size: 0.85rem;" onclick="openRecipeDetail('${recipe.id}')">
                                ${appState.lang === 'en' ? 'Open' : 'Maak Oop'}
                             </button>`;
                             
            wrapper.appendChild(card);
        });
        container.appendChild(wrapper);
    });
}

function toggleFavorite() {
    var id = appState.activeRecipeId.toString();
    var key = appState.currentUser + '_favorites';
    var favs = JSON.parse(localStorage.getItem(key)) || [];
    if (favs.includes(id)) {
        favs = favs.filter(function (f) { 
            return f !== id; 
        });
        document.getElementById('fav-toggle-btn').innerText = "☆";
    } else {
        favs.push(id);
        document.getElementById('fav-toggle-btn').innerText = "★";
    }
    localStorage.setItem(key, JSON.stringify(favs));
}

function openRecipeDetail(id) {
    var recipe = getAllRecipes().find(function (r) { 
        return r.id.toString() === id.toString(); 
    });
    if (!recipe) return;
    appState.activeRecipeId = id;
    
    document.getElementById('recipe-name').innerText = recipe.isCustom ? recipe.name : recipe.name[appState.lang];
    document.getElementById('recipe-desc').innerText = recipe.isCustom ? recipe.desc : recipe.desc[appState.lang];
    
    var ingUl = document.getElementById('recipe-ingredients');
    ingUl.innerHTML = "";
    var localizedIngs = recipe.isCustom ? recipe.ingredients : recipe.ingredients[appState.unit][appState.lang];
    localizedIngs.forEach(function (ing) {
        var li = document.createElement('li'); 
        li.innerText = ing; 
        ingUl.appendChild(li);
    });
    
    var methodOl = document.getElementById('recipe-method');
    methodOl.innerHTML = "";
    var localizedSteps = recipe.isCustom ? recipe.method : recipe.method[appState.lang];
    localizedSteps.forEach(function (s) {
        var li = document.createElement('li'); 
        li.innerText = s; 
        methodOl.appendChild(li);
    });
    
    var favs = JSON.parse(localStorage.getItem(appState.currentUser + '_favorites')) || [];
    document.getElementById('fav-toggle-btn').innerText = favs.includes(id.toString()) ? "★" : "☆";
    
    updatePrintStatusLabel();
    nextScreen('detail-screen');
    
    if (appState.audioEnabled) {
        speakRecipe(
            recipe.isCustom ? recipe.name : recipe.name[appState.lang],
            recipe.isCustom ? recipe.desc : recipe.desc[appState.lang],
            localizedIngs,
            localizedSteps
        );
    }
}

function goBackToList() {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    renderRecipeList();
    nextScreen('list-screen');
}
