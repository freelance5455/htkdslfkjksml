let currentTab = 0;
let isModerator = false;
let currentTaskId = null;

let tasks = [
  {
    id: 1,
    title: "ГРС-18, ул. Ленина 45",
    address: "ул. Ленина, 45",
    description: "Проверка и замена регулятора давления. Утечка по фланцу.",
    time: "09:15",
    status: "pending",
    crew: "Экипаж 1"
  },
  {
    id: 2,
    title: "Дом 12, пер. Строителей",
    address: "пер. Строителей, 12",
    description: "Устранение утечки на вводе в дом. Замена крана.",
    time: "11:30",
    status: "inprogress",
    crew: "Экипаж 1"
  }
];

let reports = [];

let crews = [
  {
    id: 1,
    name: "Экипаж 1",
    members: [
      { name: "Иванов Алексей", role: "Старший водитель", avatar: "https://api.dicebear.com/9.x/notionists/svg?seed=driver1" },
      { name: "Петров Сергей", role: "Слесарь", avatar: "https://api.dicebear.com/9.x/notionists/svg?seed=driver2" }
    ]
  },
  {
    id: 2,
    name: "Экипаж 2",
    members: [
      { name: "Сидоров Константин", role: "Водитель", avatar: "https://api.dicebear.com/9.x/notionists/svg?seed=driver3" },
      { name: "Морозов Дмитрий", role: "Инженер", avatar: "https://api.dicebear.com/9.x/notionists/svg?seed=driver4" }
    ]
  }
];

let moderatorTasks = [...tasks];
let moderatorReports = [];

function saveToLocal() {
  localStorage.setItem('gasguard_tasks', JSON.stringify(tasks));
  localStorage.setItem('gasguard_reports', JSON.stringify(reports));
  localStorage.setItem('gasguard_crews', JSON.stringify(crews));
}

function loadFromLocal() {
  const savedTasks = localStorage.getItem('gasguard_tasks');
  if (savedTasks) tasks = JSON.parse(savedTasks);
  const savedReports = localStorage.getItem('gasguard_reports');
  if (savedReports) reports = JSON.parse(savedReports);
  const savedCrews = localStorage.getItem('gasguard_crews');
  if (savedCrews) crews = JSON.parse(savedCrews);
  moderatorTasks = [...tasks];
}

function renderTasks() {
  const container = document.getElementById('task-list');
  container.innerHTML = '';
  
  if (tasks.length === 0) {
    document.getElementById('tasks-empty').classList.remove('hidden');
    return;
  }
  
  document.getElementById('tasks-empty').classList.add('hidden');
  
  tasks.forEach(task => {
    const div = document.createElement('div');
    div.className = `task-card`;
    div.innerHTML = `
      <div class="task-header">
        <div class="task-status ${task.status}">${task.status === 'pending' ? 'Запланировано' : 'В работе'}</div>
        <div style="font-size:13px;color:#888">${task.time}</div>
      </div>
      <div class="task-title">${task.title}</div>
      <div style="margin-bottom:12px;font-size:14px;color:var(--color-text-secondary)">${task.description}</div>
      <div class="task-meta">
        <div>🚚 ${task.crew}</div>
        <div>⏳ 2ч 15м</div>
      </div>
    `;
    div.onclick = () => openTaskDetail(task);
    container.appendChild(div);
  });
  
  document.getElementById('task-count').textContent = tasks.length;
}

function renderReports() {
  const container = document.getElementById('report-list');
  container.innerHTML = '';
  
  if (reports.length === 0) {
    const empty = document.createElement('div');
    empty.style.cssText = 'text-align:center;padding:60px 20px;color:#888';
    empty.innerHTML = `<div style="font-size:42px;margin-bottom:16px">📋</div><div style="font-weight:500">Отчётов пока нет</div>`;
    container.appendChild(empty);
    return;
  }
  
  reports.forEach(report => {
    const div = document.createElement('div');
    div.className = 'task-card';
    div.style.cursor = 'default';
    div.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-size:15px;font-weight:600">${report.taskTitle}</div>
          <div style="font-size:13px;color:#666;margin-top:4px">${report.date}</div>
        </div>
        <div style="background:#e5f5e5;color:#006d00;padding:3px 11px;border-radius:9999px;font-size:13px">Завершено</div>
      </div>
      <div style="margin-top:16px;font-size:14px;line-height:1.4;color:var(--color-text-secondary)">${report.text.substring(0, 95)}...</div>
      <div style="margin-top:12px;font-size:13px;color:var(--color-text-muted)">Затрачено: ${report.time} мин • ${report.materials}</div>
    `;
    container.appendChild(div);
  });
}

function renderCrew() {
  const container = document.getElementById('crew-card');
  const crew = crews[0];
  let html = `<div style="font-weight:600;font-size:17px;margin-bottom:16px">${crew.name}</div>`;
  
  crew.members.forEach(member => {
    html += `
      <div class="crew-member">
        <img src="${member.avatar}" alt="">
        <div style="flex:1">
          <div style="font-weight:600">${member.name}</div>
          <div style="font-size:13px;color:var(--color-text-muted)">${member.role}</div>
        </div>
        <div style="background:#e0f0ff;color:var(--color-primary);padding:4px 14px;border-radius:9999px;font-size:13px">На смене</div>
      </div>
    `;
  });
  
  container.innerHTML = html;
}

function renderModeratorTasks() {
  const container = document.getElementById('mod-task-list');
  container.innerHTML = '';
  
  moderatorTasks.forEach((task, index) => {
    const div = document.createElement('div');
    div.className = 'task-card';
    div.innerHTML = `
      <div class="task-header">
        <div class="task-status ${task.status}">${task.status === 'pending' ? 'Запланировано' : 'В работе'}</div>
        <div style="font-size:13px;color:#888">${task.time}</div>
      </div>
      <div class="task-title">${task.title}</div>
      <div style="margin:8px 0 12px;font-size:14px;color:var(--color-text-secondary)">${task.description}</div>
      <div style="display:flex;gap:12px">
        <button onclick="editModeratorTask(${index});event.stopImmediatePropagation()" style="flex:1;height:38px;font-size:14px">Редактировать</button>
        <button onclick="deleteModeratorTask(${index});event.stopImmediatePropagation()" style="flex:1;height:38px;font-size:14px;background:#ff3b30;color:white">Удалить</button>
      </div>
    `;
    container.appendChild(div);
  });
}

function renderModeratorReports() {
  const container = document.getElementById('mod-report-list');
  container.innerHTML = '';
  
  if (moderatorReports.length === 0) {
    const empty = document.createElement('div');
    empty.style.cssText = 'padding:60px 30px;text-align:center;color:#777';
    empty.innerHTML = 'Выполненные отчёты будут появляться здесь';
    container.appendChild(empty);
    return;
  }
  
  moderatorReports.forEach(r => {
    const card = document.createElement('div');
    card.className = 'task-card';
    card.innerHTML = `<div style="font-weight:600">${r.taskTitle}</div><div style="font-size:13px;margin-top:8px;color:#006d00">${r.text}</div>`;
    container.appendChild(card);
  });
}

function renderModeratorCrews() {
  const container = document.getElementById('mod-crew-list');
  container.innerHTML = '';
  
  crews.forEach(crew => {
    const div = document.createElement('div');
    div.className = 'task-card';
    div.innerHTML = `<div style="font-weight:600;margin-bottom:12px">${crew.name}</div>`;
    crew.members.forEach(m => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:12px;padding:10px 0;border-top:1px solid #eee';
      row.innerHTML = `<img src="${m.avatar}" width="32" height="32" style="border-radius:50%"> <div><div>${m.name}</div><div style="font-size:12px;color:#888">${m.role}</div></div>`;
      div.appendChild(row);
    });
    container.appendChild(div);
  });
}

function openTaskDetail(task) {
  currentTaskId = task.id;
  const sheet = document.getElementById('task-detail-sheet');
  const content = document.getElementById('task-detail-content');
  
  content.innerHTML = `
    <div style="padding:0 24px 24px">
      <div style="font-size:13px;color:var(--color-text-muted);margin-bottom:4px">${task.time} • ${task.crew}</div>
      <div style="font-size:24px;font-weight:700;line-height:1.2;margin-bottom:8px">${task.title}</div>
      <div style="background:#f0f7ff;padding:16px;border-radius:12px;margin-bottom:24px">
        <div style="font-size:15px;font-weight:500;color:var(--color-primary)">Описание</div>
        <div style="margin-top:6px;line-height:1.45">${task.description}</div>
      </div>
      
      <div onclick="startReportFlow()" style="background:var(--color-primary);color:white;height:54px;display:flex;align-items:center;justify-content:center;border-radius:14px;font-size:17px;font-weight:600;cursor:pointer">Заполнить отчёт и закрыть</div>
      
      <div style="margin-top:32px;font-size:13px;color:var(--color-text-muted);text-align:center">Нажмите на кнопку выше, чтобы завершить работу</div>
    </div>
  `;
  
  sheet.classList.add('open');
  
  // close on background click
  sheet.onclick = function(e) {
    if (e.target.id === 'task-detail-sheet') closeTaskDetail();
  };
}

function closeTaskDetail() {
  const sheet = document.getElementById('task-detail-sheet');
  sheet.classList.remove('open');
}

function startReportFlow() {
  closeTaskDetail();
  setTimeout(() => {
    document.getElementById('report-sheet').classList.add('open');
  }, 280);
}

function closeReportSheet() {
  document.getElementById('report-sheet').classList.remove('open');
}

function submitReport() {
  const text = document.getElementById('report-text').value || 'Работы выполнены';
  const time = document.getElementById('report-time').value || '75';
  const materials = document.getElementById('report-materials').value || '—';
  const completed = document.getElementById('report-complete').checked;
  
  const activeTask = tasks.find(t => t.id === currentTaskId);
  
  reports.unshift({
    id: Date.now(),
    taskTitle: activeTask ? activeTask.title : 'Задание',
    text: text,
    time: time,
    materials: materials,
    date: 'Сегодня, 14:22',
    completed: completed
  });
  
  // move from active tasks
  tasks = tasks.filter(t => t.id !== currentTaskId);
  moderatorReports.unshift(reports[0]);
  
  saveToLocal();
  closeReportSheet();
  renderTasks();
  renderReports();
  renderModeratorReports();
  
  showToast('Отчёт отправлен модератору');
}

function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2600);
}

function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.tab').forEach((t, i) => {
    t.classList.toggle('active', i === tab);
  });
  document.querySelectorAll('.screen').forEach((s, i) => {
    s.classList.toggle('active', i === tab && !isModerator);
  });
}

function showProfileModal() {
  document.getElementById('profile-modal').classList.add('open');
}

function hideProfileModal() {
  document.getElementById('profile-modal').classList.remove('open');
}

function loginAsDriver() {
  isModerator = false;
  hideProfileModal();
  document.getElementById('moderator-screen').classList.add('hidden');
  document.getElementById('top-nav').style.display = 'block';
  switchTab(0);
}

function loginAsModerator() {
  hideProfileModal();
  document.getElementById('password-overlay').classList.remove('hidden');
  document.getElementById('mod-password').focus();
}

function verifyModeratorPassword() {
  const pass = document.getElementById('mod-password').value;
  if (pass === '4963') {
    document.getElementById('password-overlay').classList.add('hidden');
    isModerator = true;
    document.getElementById('top-nav').style.display = 'none';
    document.getElementById('moderator-screen').classList.remove('hidden');
    modTab(0);
  } else {
    const input = document.getElementById('mod-password');
    input.style.border = '2px solid red';
    setTimeout(() => input.style.border = '', 800);
  }
}

function cancelModeratorLogin() {
  document.getElementById('password-overlay').classList.add('hidden');
}

function exitModerator() {
  isModerator = false;
  document.getElementById('moderator-screen').classList.add('hidden');
  document.getElementById('top-nav').style.display = 'block';
  switchTab(0);
}

function modTab(n) {
  document.querySelectorAll('.mod-tab').forEach((el, i) => el.classList.toggle('active', i === n));
  document.querySelectorAll('.mod-content').forEach((el, i) => {
    el.classList.toggle('hidden', i !== n);
  });
  
  if (n === 0) renderModeratorTasks();
  if (n === 1) renderModeratorCrews();
  if (n === 2) renderModeratorReports();
}

function showNewTaskModal() {
  document.getElementById('new-task-modal').classList.add('open');
}

function hideNewTaskModal() {
  document.getElementById('new-task-modal').classList.remove('open');
}

function createNewTask() {
  const address = document.getElementById('new-task-address').value || 'Новый объект';
  const desc = document.getElementById('new-task-desc').value || 'Описание отсутствует';
  
  const newTask = {
    id: Date.now(),
    title: address,
    address: address,
    description: desc,
    time: '14:00',
    status: 'pending',
    crew: 'Экипаж 1'
  };
  
  tasks.unshift(newTask);
  moderatorTasks.unshift(newTask);
  saveToLocal();
  hideNewTaskModal();
  renderTasks();
  renderModeratorTasks();
  showToast('Задание создано');
}

function showNewCrewModal() {
  document.getElementById('new-crew-modal').classList.add('open');
}

function hideNewCrewModal() {
  document.getElementById('new-crew-modal').classList.remove('open');
}

function createNewCrew() {
  const name = document.getElementById('new-crew-name').value || 'Новый экипаж';
  const d1 = document.getElementById('new-crew-driver1').value || 'Водитель 1';
  const d2 = document.getElementById('new-crew-driver2').value || 'Водитель 2';
  
  crews.unshift({
    id: Date.now(),
    name: name,
    members: [
      { name: d1, role: 'Водитель', avatar: 'https://api.dicebear.com/9.x/notionists/svg?seed=' + Math.random() },
      { name: d2, role: 'Слесарь', avatar: 'https://api.dicebear.com/9.x/notionists/svg?seed=' + Math.random() }
    ]
  });
  
  saveToLocal();
  hideNewCrewModal();
  renderModeratorCrews();
  showToast('Экипаж добавлен');
}

function editModeratorTask(index) {
  const task = moderatorTasks[index];
  const newDesc = prompt('Изменить описание задания:', task.description);
  if (newDesc !== null) {
    task.description = newDesc;
    saveToLocal();
    renderModeratorTasks();
  }
}

function deleteModeratorTask(index) {
  if (confirm('Удалить задание?')) {
    const removed = moderatorTasks.splice(index, 1)[0];
    tasks = tasks.filter(t => t.id !== removed.id);
    saveToLocal();
    renderModeratorTasks();
    renderTasks();
  }
}

function init() {
  loadFromLocal();
  renderTasks();
  renderReports();
  renderCrew();
  renderModeratorTasks();
  renderModeratorReports();
  renderModeratorCrews();
  
  // close sheets when pressing escape
  document.addEventListener('keydown', function(e) {
    if (e.key === "Escape") {
      const openSheet = document.querySelector('.bottom-sheet.open');
      if (openSheet) openSheet.classList.remove('open');
      const openModals = document.querySelectorAll('.modal.open');
      openModals.forEach(m => m.classList.remove('open'));
    }
  });
  
  // demo: add one report if none
  if (reports.length === 0) {
    reports.push({
      id: 98123,
      taskTitle: "ГРС-18, ул. Ленина 45",
      text: "Замена запорной арматуры выполнена. Утечка устранена. Система проверена на герметичность.",
      time: "110",
      materials: "Кран 50мм, фланцы",
      date: "Сегодня, 11:40",
      completed: true
    });
  }
  
  // initial tab
  switchTab(0);
}

window.onload = init;

// expose some functions to onclick handlers in HTML
window.switchTab = switchTab;
window.showProfileModal = showProfileModal;
window.hideProfileModal = hideProfileModal;
window.loginAsDriver = loginAsDriver;
window.loginAsModerator = loginAsModerator;
window.verifyModeratorPassword = verifyModeratorPassword;
window.cancelModeratorLogin = cancelModeratorLogin;
window.exitModerator = exitModerator;
window.modTab = modTab;
window.openTaskDetail = openTaskDetail;
window.closeTaskDetail = closeTaskDetail;
window.startReportFlow = startReportFlow;
window.closeReportSheet = closeReportSheet;
window.submitReport = submitReport;
window.showNewTaskModal = showNewTaskModal;
window.hideNewTaskModal = hideNewTaskModal;
window.createNewTask = createNewTask;
window.showNewCrewModal = showNewCrewModal;
window.hideNewCrewModal = hideNewCrewModal;
window.createNewCrew = createNewCrew;
window.editModeratorTask = editModeratorTask;
window.deleteModeratorTask = deleteModeratorTask;