let currentUser = {
  name: "Алексей Морозов",
  avatar: "А"
};

let tasks = [
  {
    id: "BG-7841",
    address: "ул. Ленина, 45, кв. 12",
    problem: "Утечка газа на кухне. Запах газа",
    date: "2025-01-28",
    time: "09:15",
    status: "planned",
    priority: "high"
  },
  {
    id: "BG-7842",
    address: "пр. Мира, 112, подъезд 3",
    problem: "Замена счетчика газа",
    date: "2025-01-28",
    time: "11:30",
    status: "planned",
    priority: "medium"
  },
  {
    id: "BG-7843",
    address: "ул. Советская, 8, частный дом",
    problem: "Проверка газопровода после ремонта",
    date: "2025-01-29",
    time: "14:00",
    status: "planned",
    priority: "low"
  }
];

let activeJob = null;

let archive = [
  {
    id: "BG-7829",
    address: "ул. Гагарина, 27, кв. 84",
    date: "2025-01-26",
    timeSpent: 65,
    description: "Заменён регулятор давления, проведена опрессовка",
    photos: 3
  },
  {
    id: "BG-7814",
    address: "ул. Победы, 19",
    date: "2025-01-25",
    timeSpent: 110,
    description: "Устранена утечка на вводе, заменён кран",
    photos: 5
  }
];

let selectedWorkers = [0, 2];
const availableWorkers = [
  { id: 0, name: "Иван Соколов", role: "Слесарь", avatar: "И" },
  { id: 1, name: "Пётр Васин", role: "Помощник", avatar: "П" },
  { id: 2, name: "Дмитрий Ковалёв", role: "Сварщик", avatar: "Д" },
  { id: 3, name: "Сергей Мороз", role: "Слесарь", avatar: "С" }
];

let capturedPhotos = [];

// Render tasks list
function renderTasks(filteredTasks) {
  const container = document.getElementById('tasks-list');
  container.innerHTML = '';

  if (filteredTasks.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <p>Нет задач на сегодня</p>
      </div>
    `;
    return;
  }

  filteredTasks.forEach(task => {
    const card = document.createElement('div');
    card.className = 'task-card';
    card.innerHTML = `
      <div class="task-header">
        <div class="task-id">${task.id}</div>
        <div class="task-status planned">Запланировано</div>
      </div>
      <div class="task-body">
        <div class="task-address">${task.address}</div>
        <div class="task-desc">${task.problem}</div>
        <div class="task-meta">
          <div>${task.date} • ${task.time}</div>
          <div style="color:${task.priority==='high'?'#ff3b30':'#0066ff'}">• ${task.priority === 'high' ? 'СРОЧНО' : 'Обычный'}</div>
        </div>
      </div>
    `;
    card.addEventListener('click', () => showTaskDetail(task));
    container.appendChild(card);
  });
}

function renderArchive() {
  const container = document.getElementById('archive-list');
  container.innerHTML = '';

  archive.forEach(item => {
    const div = document.createElement('div');
    div.className = 'task-card';
    div.innerHTML = `
      <div class="task-header">
        <div class="task-id">${item.id}</div>
        <div style="background:#e5f7e5;color:#1e8a1e;font-size:12px;padding:2px 9px;border-radius:9999px">Завершено</div>
      </div>
      <div class="task-body">
        <div class="task-address">${item.address}</div>
        <div style="font-size:13px;color:#666;margin:8px 0 12px">${item.description}</div>
        <div class="task-meta">
          <div>${item.date}</div>
          <div>${item.timeSpent} мин • ${item.photos} фото</div>
        </div>
      </div>
    `;
    container.appendChild(div);
  });
}

function renderActiveJob() {
  const container = document.getElementById('active-job-view');
  if (!activeJob) {
    container.innerHTML = `
      <div class="empty-state" style="padding-top:120px">
        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="none" stroke="#ccc" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2"></path></svg>
        <p style="margin-top:24px;font-size:17px">Нет активного выезда</p>
        <p style="font-size:14px">Выберите задачу на вкладке «Задачи»</p>
      </div>
    `;
    document.getElementById('btn-complete-job').style.display = 'none';
    return;
  }

  document.getElementById('btn-complete-job').style.display = 'block';

  container.innerHTML = `
    <div class="job-active">
      <div class="job-card">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <div style="font-size:13px;color:#0066ff;font-weight:600">${activeJob.id}</div>
          <div style="background:#ffe8c2;color:#c36b00;padding:3px 11px;border-radius:9999px;font-size:12px">В работе</div>
        </div>
        <div class="job-address-big">${activeJob.address}</div>
        <div class="job-problem">
          <strong>Проблема:</strong><br>${activeJob.problem}
        </div>
        
        <div style="margin-top:22px">
          <div style="font-size:15px;color:#555;font-weight:500;margin-bottom:10px">Состав бригады</div>
          <div class="team-members">
            ${selectedWorkers.map(i => {
              const w = availableWorkers[i];
              return `<div class="team-member-tag">${w.avatar} ${w.name}</div>`;
            }).join('')}
          </div>
        </div>
        
        <div style="margin-top:32px;font-size:13px;color:#777">
          Начало: сегодня в ${activeJob.time}<br>
          Ожидаемое время: 1ч 45мин
        </div>
      </div>
    </div>
  `;
}

function showTaskDetail(task) {
  const sheet = document.getElementById('bottom-sheet');
  const content = document.getElementById('sheet-content');
  content.innerHTML = `
    <h2 style="margin:0 0 6px;font-size:24px">${task.id}</h2>
    <div style="font-size:18px;font-weight:600;margin-bottom:20px">${task.address}</div>
    <div style="background:#f8f8f8;padding:16px;border-radius:12px;margin-bottom:24px">
      <strong>Описание:</strong><br>
      <span style="color:#222">${task.problem}</span>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;font-size:14px">
      <div><span style="color:#888">Дата</span><br><strong>${task.date}</strong></div>
      <div><span style="color:#888">Время</span><br><strong>${task.time}</strong></div>
    </div>
    <div style="margin-top:40px">
      <button onclick="startJobFromDetail()" class="btn-primary" style="margin:0">Начать работу с этой задачей</button>
    </div>
  `;
  sheet.classList.add('active');
  window.currentTask = task;
}

window.startJobFromDetail = function() {
  const sheet = document.getElementById('bottom-sheet');
  sheet.classList.remove('active');
  activeJob = window.currentTask;
  showTeamModal();
};

function showTeamModal() {
  const modal = document.getElementById('modal-team');
  const list = document.getElementById('worker-list');
  list.innerHTML = '';

  availableWorkers.forEach((worker, index) => {
    const checked = selectedWorkers.includes(index);
    const el = document.createElement('div');
    el.className = `worker-item ${checked ? 'selected' : ''}`;
    el.innerHTML = `
      <div style="width:36px;height:36px;background:#0066ff;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;margin-right:14px">${worker.avatar}</div>
      <div style="flex:1">
        <div style="font-weight:600">${worker.name}</div>
        <div style="font-size:13px;color:#666">${worker.role}</div>
      </div>
    `;
    el.addEventListener('click', () => {
      if (selectedWorkers.includes(index)) {
        selectedWorkers = selectedWorkers.filter(i => i !== index);
      } else {
        selectedWorkers.push(index);
      }
      showTeamModal();
    });
    list.appendChild(el);
  });

  modal.classList.add('active');
}

function hideModals() {
  document.querySelectorAll('.modal').forEach(m => m.classList.remove('active'));
  document.getElementById('bottom-sheet').classList.remove('active');
}

function showToast(text) {
  const toast = document.getElementById('toast');
  toast.textContent = text;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2800);
}

function switchTab(tab) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');

  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + tab).classList.add('active');

  if (tab === 'archive') renderArchive();
  if (tab === 'active') renderActiveJob();
}

// Main initialization
function init() {
  // Tab navigation
  document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const target = tab.getAttribute('data-tab');
      switchTab(target);
    });
  });

  // Render initial tasks
  renderTasks(tasks);

  // Filter chips
  const allChip = document.getElementById('filter-all');
  const todayChip = document.getElementById('filter-today');

  allChip.addEventListener('click', () => {
    allChip.classList.add('active');
    todayChip.classList.remove('active');
    renderTasks(tasks);
  });

  todayChip.addEventListener('click', () => {
    todayChip.classList.add('active');
    allChip.classList.remove('active');
    const todayTasks = tasks.filter(t => t.date === "2025-01-28");
    renderTasks(todayTasks);
  });

  // Team modal controls
  document.getElementById('close-team').addEventListener('click', hideModals);
  document.getElementById('cancel-team').addEventListener('click', hideModals);
  document.getElementById('confirm-team').addEventListener('click', () => {
    hideModals();
    setTimeout(() => {
      switchTab('active');
      renderActiveJob();
      showToast('Выезд начат. Бригада в пути');
    }, 400);
  });

  // Report modal
  const reportModal = document.getElementById('modal-report');
  document.getElementById('btn-complete-job').addEventListener('click', () => {
    if (!activeJob) return;
    document.getElementById('report-description').value = `Устранена утечка в ${activeJob.address}. Выполнена продувка и опрессовка.`;
    capturedPhotos = [];
    renderPhotos();
    reportModal.classList.add('active');
  });

  document.getElementById('close-report').addEventListener('click', () => reportModal.classList.remove('active'));
  document.getElementById('cancel-report').addEventListener('click', () => reportModal.classList.remove('active'));

  document.getElementById('submit-report').addEventListener('click', () => {
    const description = document.getElementById('report-description').value || 'Работы выполнены успешно';
    const timeSpent = parseInt(document.getElementById('report-time').value) || 75;

    archive.unshift({
      id: activeJob.id,
      address: activeJob.address,
      date: "2025-01-28",
      timeSpent: timeSpent,
      description: description,
      photos: capturedPhotos.length || 2
    });

    reportModal.classList.remove('active');
    activeJob = null;
    renderActiveJob();
    switchTab('archive');
    showToast('Отчёт отправлен. Задача перемещена в архив');
  });

  // Photo upload simulation
  const photoInput = document.getElementById('photo-input');
  const uploadArea = document.getElementById('photo-upload-area');

  uploadArea.addEventListener('click', () => {
    if (capturedPhotos.length < 4) {
      photoInput.click();
    }
  });

  photoInput.addEventListener('change', (e) => {
    if (e.target.files && e.target.files[0]) {
      const fakeUrl = `https://picsum.photos/id/${100 + capturedPhotos.length}/300/300`;
      capturedPhotos.push(fakeUrl);
      renderPhotos();
    }
  });

  function renderPhotos() {
    const grid = document.getElementById('photos-grid');
    grid.innerHTML = '';
    capturedPhotos.forEach(src => {
      const img = document.createElement('img');
      img.src = src;
      img.className = 'photo-preview';
      grid.appendChild(img);
    });
    if (capturedPhotos.length === 0) {
      document.getElementById('photo-placeholder').style.display = 'flex';
    } else {
      document.getElementById('photo-placeholder').style.display = 'none';
    }
  }

  // Archive search
  const archiveSearch = document.getElementById('archive-search');
  archiveSearch.addEventListener('input', () => {
    const term = archiveSearch.value.toLowerCase().trim();
    if (!term) {
      renderArchive();
      return;
    }
    const filtered = archive.filter(item => 
      item.address.toLowerCase().includes(term) || 
      item.description.toLowerCase().includes(term)
    );
    const container = document.getElementById('archive-list');
    container.innerHTML = '';
    if (filtered.length === 0) {
      container.innerHTML = `<div class="empty-state"><p>Ничего не найдено</p></div>`;
      return;
    }
    filtered.forEach(item => {
      const div = document.createElement('div');
      div.className = 'task-card';
      div.innerHTML = `
        <div class="task-header">
          <div class="task-id">${item.id}</div>
        </div>
        <div class="task-body">
          <div class="task-address">${item.address}</div>
          <div style="font-size:13px;color:#555;margin:8px 0">${item.description}</div>
          <div class="task-meta">
            <div>${item.date}</div>
            <div>${item.timeSpent} мин</div>
          </div>
        </div>
      `;
      container.appendChild(div);
    });
  });

  // Close bottom sheet on outside tap (simple)
  document.getElementById('bottom-sheet').addEventListener('click', function(e) {
    if (e.target.id === 'bottom-sheet') this.classList.remove('active');
  });

  // Keyboard support for modals
  document.addEventListener('keydown', function(e) {
    if (e.key === "Escape") {
      const activeModal = document.querySelector('.modal.active');
      if (activeModal) activeModal.classList.remove('active');
      const sheet = document.getElementById('bottom-sheet');
      if (sheet.classList.contains('active')) sheet.classList.remove('active');
    }
  });

  // Set user info
  document.getElementById('user-name').textContent = currentUser.name;
  document.getElementById('user-avatar').textContent = currentUser.avatar;

  // Show first screen
  switchTab('tasks');

  // Demo: pre-load one active job after 1200ms
  setTimeout(() => {
    if (!activeJob) {
      activeJob = tasks[0];
      selectedWorkers = [0, 2];
    }
  }, 1800);
}

window.onload = init;