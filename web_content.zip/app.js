(()=>{
"use strict";
const $=id=>document.getElementById(id),editor=$("editor"),output=$("output");
const DB="acce-studio-4",STORE="files";let db,files={},active="welcome.acce",dirty=false;
const templates={
 "مشروع ACCE": {
 "main.acce":"# برنامج ACCE تجريبي\nخزن\\الاسم\\ACCE\nاطبع\\مرحبًا بك في\nاطبع\\الاسم\nاطبع\\نتيجة الجمع:\nاجمع\\20\\30\n",
 "README.txt":"مشروع بلغة ACCE. افتح main.acce واضغط تشغيل."
 },
 "موقع ويب": {
 "index.html":"<!doctype html>\n<html lang=\"ar\" dir=\"rtl\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>موقعي الأول</title><link rel=\"stylesheet\" href=\"style.css\"></head><body><main><h1>مرحبًا بك في موقعي</h1><p>تم إنشاء هذا الموقع باستخدام ACCE STUDIO.</p><button onclick=\"alert('أهلاً!')\">اضغط هنا</button></main><script src=\"app.js\"></script></body></html>",
 "style.css":"body{margin:0;font-family:Tahoma;background:#101827;color:white;display:grid;min-height:100vh;place-items:center}main{text-align:center;padding:30px}h1{color:#a78bfa}button{padding:12px 20px;border:0;border-radius:10px;background:#7c3aed;color:white;font-size:17px}",
 "app.js":"console.log('موقعي يعمل!');"
 },
 "آلة حاسبة": {
 "index.html":"<!doctype html><html lang=\"ar\" dir=\"rtl\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>آلة حاسبة</title><link rel=\"stylesheet\" href=\"style.css\"></head><body><main><h1>آلة حاسبة</h1><input id=\"a\" type=\"number\" placeholder=\"الرقم الأول\"><input id=\"b\" type=\"number\" placeholder=\"الرقم الثاني\"><div><button onclick=\"calc('+')\">جمع</button><button onclick=\"calc('-')\">طرح</button><button onclick=\"calc('*')\">ضرب</button><button onclick=\"calc('/')\">قسمة</button></div><h2 id=\"result\">النتيجة ستظهر هنا</h2></main><script src=\"app.js\"></script></body></html>",
 "style.css":"body{font-family:Tahoma;background:#101827;color:white;display:grid;place-items:center;min-height:100vh}main{background:#1e293b;padding:25px;border-radius:18px;text-align:center;width:min(90%,420px)}input{display:block;width:90%;padding:12px;margin:10px auto;border-radius:8px;border:0}button{padding:10px;margin:4px;background:#7c3aed;color:white;border:0;border-radius:8px}h1{color:#c4b5fd}",
 "app.js":"function calc(op){let a=Number(document.getElementById('a').value),b=Number(document.getElementById('b').value);if(op==='/'&&b===0){document.getElementById('result').textContent='لا يمكن القسمة على صفر';return;}let r=op==='+'?a+b:op==='-'?a-b:op==='*'?a*b:a/b;document.getElementById('result').textContent='النتيجة: '+r;}"
 },
 "مشروع ملفات": {
 "README.txt":"اكتب وصف مشروعك هنا.",
 "data.json":"{\n  \"name\": \"My Project\",\n  \"version\": 1\n}",
 "notes.txt":"ملف ملاحظات المشروع."
 }
};
function openDB(){return new Promise((res,rej)=>{let q=indexedDB.open(DB,1);q.onupgradeneeded=()=>q.result.createObjectStore(STORE);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error);});}
function store(mode="readonly"){return db.transaction(STORE,mode).objectStore(STORE);}
function put(k,v){return new Promise((res,rej)=>{let q=store("readwrite").put(v,k);q.onsuccess=res;q.onerror=()=>rej(q.error);});}
function del(k){return new Promise((res,rej)=>{let q=store("readwrite").delete(k);q.onsuccess=res;q.onerror=()=>rej(q.error);});}
function all(){return new Promise((res,rej)=>{let q=store().getAll(),k=store().getAllKeys();let a,b;q.onsuccess=()=>{a=q.result;if(b)res(Object.fromEntries(b.map((x,i)=>[x,a[i]])));};k.onsuccess=()=>{b=k.result;if(a)res(Object.fromEntries(b.map((x,i)=>[x,a[i]])));};q.onerror=k.onerror=()=>rej(q.error||k.error);});}
function msg(s){output.textContent=s;}
function render(){let t=$("tree");t.innerHTML="";Object.keys(files).sort().forEach(k=>{let b=document.createElement("button");b.textContent=(k===active?"● ":"📄 ")+k;b.className=k===active?"active":"";b.onclick=()=>open(k);t.appendChild(b);});}
function open(k){if(dirty&&!confirm("توجد تعديلات غير محفوظة. فتح ملف آخر؟"))return;active=k;editor.value=files[k]||"";$("path").textContent=k;dirty=false;render();}
async function save(){files[active]=editor.value;await put(active,editor.value);dirty=false;msg("✓ تم حفظ "+active);render();}
async function newFile(){let n=prompt("اسم الملف مع الامتداد، مثل index.html أو main.acce");if(!n)return;n=n.trim().replace(/^\/+/,"");if(!n||n.includes("..")||n.endsWith("/"))return alert("اسم الملف غير صالح");if(n in files)return alert("الملف موجود بالفعل");files[n]="";await put(n,"");open(n);}
async function newProject(){let choices=Object.keys(templates);let choice=prompt("اختر نوع المشروع بكتابة الرقم:\\n"+choices.map((x,i)=>(i+1)+" - "+x).join("\\n"));let ix=Number(choice)-1;if(!Number.isInteger(ix)||!templates[choices[ix]])return;let prefix=prompt("اسم مجلد المشروع:","MyProject");if(!prefix)return;for(let [k,v] of Object.entries(templates[choices[ix]])){let path=prefix.replace(/\/$/,"")+"/"+k;files[path]=v;await put(path,v);}render();let first=prefix.replace(/\/$/,"")+"/"+Object.keys(templates[choices[ix]])[0];open(first);msg("✓ تم إنشاء مشروع "+choices[ix]+"\\nافتح الملفات من القائمة وعدّلها.");}
async function run(){await save();if(active.endsWith(".acce")){msg(new ACCEEngine().execute(editor.value)||"(لا توجد مخرجات)");return;}if(active.endsWith(".html")){showPreview();msg("تم فتح معاينة صفحة HTML.");return;}if(active.endsWith(".js")){msg("تم حفظ ملف JavaScript. شغّله من صفحة HTML مرتبطة به عبر زر معاينة الموقع.");return;}msg("تم حفظ الملف. هذا النوع لا يتم تشغيله مباشرة.");}
function showPreview(){let html=files[active]??editor.value;if(!active.endsWith(".html")){let h=Object.keys(files).find(k=>k.endsWith(".html"));if(!h)return alert("لا يوجد ملف HTML في المشروع.");active=h;html=files[h];editor.value=html;$("path").textContent=h;render();}
let base=active.slice(0,active.lastIndexOf("/")+1);html=html.replace(/<link([^>]+)href=["']([^"']+\.css)["']([^>]*)>/gi,(m,a,p,b)=>{let css=files[base+p]||files[p]||"";return "<style>"+css+"</style>";}).replace(/<script([^>]*)src=["']([^"']+\.js)["']([^>]*)><\/script>/gi,(m,a,p,b)=>{let js=files[base+p]||files[p]||"";return "<script>"+js.replace(/<\/script/gi,"<\\/script")+"</script>";});$("frame").srcdoc=html;$("previewLayer").classList.remove("hidden");}
function download(name,data,type){let blob=new Blob([data],{type}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function exportProject(){download("ACCE_PROJECT.json",JSON.stringify({name:"ACCE STUDIO Project",version:"4.0",files},null,2),"application/json");}
function exportHtml(){let htmlKey=active.endsWith(".html")?active:Object.keys(files).find(k=>k.endsWith(".html"));if(!htmlKey)return alert("أنشئ ملف index.html أولاً.");let saved=active,content=editor.value;if(dirty)files[active]=content;active=htmlKey;showPreview();let result=$("frame").srcdoc;active=saved;download("ACCE_WEBSITE.html",result,"text/html");}
$("save").onclick=save;$("newFile").onclick=newFile;$("newProject").onclick=newProject;$("run").onclick=run;$("preview").onclick=showPreview;$("closePreview").onclick=()=>$("previewLayer").classList.add("hidden");$("clear").onclick=()=>msg("");$("delete").onclick=async()=>{if(!confirm("حذف الملف "+active+"؟"))return;await del(active);delete files[active];active=Object.keys(files)[0]||"";if(active)open(active);else{editor.value="";$("path").textContent="لا يوجد ملف";}render();msg("تم حذف الملف.");};$("export").onclick=exportProject;$("exportHtml").onclick=exportHtml;$("import").onclick=()=>$("importFile").click();$("importFile").onchange=async e=>{let f=e.target.files[0];if(!f)return;try{let d=JSON.parse(await f.text()),incoming=d.files||d;for(let [k,v] of Object.entries(incoming)){if(typeof v==="string"&&!k.includes("..")){files[k]=v;await put(k,v);}}render();msg("✓ تم استيراد المشروع.");}catch(err){alert("تعذر استيراد المشروع: "+err.message);}e.target.value="";};
editor.addEventListener("input",()=>{dirty=true;$("path").textContent=active+" • تعديلات غير محفوظة";});
(async()=>{try{db=await openDB();files=await all();if(!Object.keys(files).length){files["welcome.acce"]="# أهلاً بك في ACCE STUDIO 4.0\\nاطبع\\\\من هنا تبدأ في بناء مشروعك!\\n";await put("welcome.acce",files["welcome.acce"]);}render();open(Object.keys(files)[0]);msg("النظام جاهز. اضغط ＋ مشروع لإنشاء آلة حاسبة أو موقع ويب أو مشروع ملفات.");}catch(e){msg("تعذر بدء التخزين المحلي: "+e.message);}})();
})();