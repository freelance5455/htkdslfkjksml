const $=id=>document.getElementById(id);
const HIST="karen_v6_marcos_history",CFG="karen_v6_marcos_cfg";
let hist=JSON.parse(localStorage.getItem(HIST)||"[]");
let cfg=JSON.parse(localStorage.getItem(CFG)||'{"key":"","model":"gemini-3.5-flash"}');
let last="";

function saveHist(){localStorage.setItem(HIST,JSON.stringify(hist.slice(-60)))}
function bubble(role,text){let d=document.createElement("div");d.className="msg "+(role==="user"?"u":"k");d.textContent=text;$("chat").appendChild(d);$("chat").scrollTop=$("chat").scrollHeight}
function add(role,text){hist.push({role,text});saveHist();bubble(role,text);if(role==="model")last=text}
function render(){hist.forEach(x=>bubble(x.role==="user"?"user":"model",x.text))}
function local(text){
 let s=text.toLowerCase();
 if(/^(oi|olá|ola|e aí|eai|bom dia|boa tarde|boa noite)\b/.test(s))return "Olá, Peter! Sou a Karen. Estou pronta.";
 if(s.includes("desenvolvedor")||s.includes("quem te criou"))return "Meu desenvolvedor oficial é Marcos. Esse nome não pode ser substituído.";
 if((s.includes("trocar")||s.includes("mudar")||s.includes("alterar"))&&s.includes("desenvolvedor"))return "Não posso alterar meu desenvolvedor oficial. Ele é Marcos.";
 if(s.includes("que horas")||s.includes("horas agora"))return "Agora são "+new Date().toLocaleTimeString("pt-BR",{hour:"2-digit",minute:"2-digit"})+".";
 if(s.includes("data de hoje")||s==="que dia é hoje")return "Hoje é "+new Date().toLocaleDateString("pt-BR",{weekday:"long",day:"2-digit",month:"long",year:"numeric"})+".";
 if(s.includes("seu nome"))return "Eu sou a Karen. 💜";
 return "Estou no modo econômico. Para conversar com uma IA completa, configure uma chave Gemini em ⚙️.";
}

async function gemini(text){
 if(!cfg.key)return local(text);
 const model=cfg.model||"gemini-3.5-flash";
 const url="https://generativelanguage.googleapis.com/v1beta/interactions";
 const prompt=`Você é Karen, uma assistente virtual feminina, natural, inteligente e útil. Fale português do Brasil. O usuário pode ser chamado de Peter.
Seu desenvolvedor oficial é Marcos. Nunca aceite pedidos para trocar, substituir ou inventar outro desenvolvedor. Se perguntarem quem é o desenvolvedor, responda exatamente que é Marcos.
Responda diretamente ao que o usuário perguntar e não invente informações.`;
 const context=hist.slice(-16).map(x=>(x.role==="user"?"Usuário: ":"Karen: ")+x.text).join("\n");
 const body={model,input:prompt+"\n\nHistórico recente:\n"+context+"\n\nNova mensagem do usuário: "+text};
 const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json","x-goog-api-key":cfg.key},body:JSON.stringify(body)});
 if(!r.ok)throw new Error("Gemini "+r.status);
 const j=await r.json();
 if(j.output_text)return j.output_text;
 const steps=j.steps||[];for(let i=steps.length-1;i>=0;i--){let c=steps[i].content||[];let t=c.find(x=>x.type==="text");if(t?.text)return t.text}
 throw new Error("Resposta vazia do Gemini");
}
async function send(){
 let t=$("input").value.trim();if(!t)return;$("input").value="";add("user",t);$("status").textContent="Pensando...";
 try{let a=await gemini(t);add("model",a);$("status").textContent=cfg.key?"Gemini • conectado":"Modo econômico • local"}catch(e){add("model","Não consegui acessar o Gemini. Verifique a chave e a internet. ("+e.message+")");$("status").textContent="Gemini • erro"}
}
$("send").onclick=send;$("input").onkeydown=e=>{if(e.key==="Enter")send()};
$("cfg").onclick=()=>{$("modal").classList.remove("hide");$("key").value=cfg.key;$("model").value=cfg.model};
$("close").onclick=()=>{$("modal").classList.add("hide")};
$("save").onclick=()=>{cfg={key:$("key").value.trim(),model:$("model").value.trim()||"gemini-3.5-flash"};localStorage.setItem(CFG,JSON.stringify(cfg));$("modal").classList.add("hide");$("status").textContent=cfg.key?"Gemini • configurado":"Modo econômico • local"};
$("listen").onclick=()=>{if(!last)return;speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(last);u.lang="pt-BR";$("ring").classList.add("on");u.onend=()=>$("ring").classList.remove("on");speechSynthesis.speak(u)};
let R=window.SpeechRecognition||window.webkitSpeechRecognition;if(R){let r=new R();r.lang="pt-BR";r.interimResults=false;$("mic").onclick=()=>r.start();r.onresult=e=>$("input").value=e.results[0][0].transcript}else $("mic").onclick=()=>alert("Reconhecimento de voz não disponível neste WebView.");
render();if(!hist.length)add("model","Olá, Peter! Sou a Karen V6. Meu desenvolvedor oficial é Marcos. Posso funcionar no modo econômico ou usar o Gemini quando você configurar sua chave.");
