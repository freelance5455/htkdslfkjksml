"use strict";

const Mushahid = (() => {
      const STORAGE_KEYS = {
            theme: "mushahid_theme",
            data: "mushahid_data",
            colors: "mushahid_colors"
      };

      const SECTIONS = {
            playlists: {
                  title: "قوائمي",
                  description: "قوائمك الشخصية للمشاهدة",
                  empty: "لم تنشئ أي قوائم بعد."
            },
            "watch-later": {
                  title: "المشاهدة لاحقًا",
                  description: "مقاطع تريد مشاهدتها مستقبلًا",
                  empty: "لا توجد مقاطع محفوظة للمشاهدة لاحقًا."
            },
            "continue-watching": {
                  title: "متابعة المشاهدة",
                  description: "المقاطع التي لم تكمل مشاهدتها",
                  empty: "لا توجد مقاطع تحتاج إلى متابعة."
            }
      };

      const mainContent = document.getElementById("main-content");

      let currentPage = "home";
      let activePlaylistId = null;
      let toastTimer = null;

      function createInitialWatchData() {
            return {
                  progress: {},
                  watched: {},
                  notes: {},
                  watchLater: [],
                  stats: { daily: {} },
                  settings: { speed: 1, autoNext: true }
            };
      }

      // تجهيز بيانات المشاهدة وإكمال الحقول الناقصة (توافق مع البيانات القديمة)
      function normalizeWatchData(raw) {
            const base = createInitialWatchData();

            if (!raw || typeof raw !== "object") return base;

            const isObject = value =>
                  value && typeof value === "object" && !Array.isArray(value);

            const settings = isObject(raw.settings) ? raw.settings : {};
            const speed = Number(settings.speed);
            const stats = isObject(raw.stats) ? raw.stats : {};

            return {
                  progress: isObject(raw.progress) ? raw.progress : base.progress,
                  watched: isObject(raw.watched) ? raw.watched : base.watched,
                  notes: isObject(raw.notes) ? raw.notes : base.notes,
                  watchLater: Array.isArray(raw.watchLater)
                        ? raw.watchLater.filter(item => typeof item === "string")
                        : base.watchLater,
                  stats: {
                        daily: isObject(stats.daily) ? stats.daily : {}
                  },
                  settings: {
                        speed: speed > 0 ? speed : 1,
                        autoNext: settings.autoNext !== false
                  }
            };
      }

      function createInitialData() {
            return {
                  channels: [],
                  playlists: [],
                  videos: [],
                  watch: createInitialWatchData()
            };
      }

      function loadAppData() {
            try {
                  const saved = localStorage.getItem(STORAGE_KEYS.data);

                  if (!saved) return createInitialData();

                  const parsed = JSON.parse(saved);

                  return {
                        channels: Array.isArray(parsed.channels)
                              ? parsed.channels : [],
                        playlists: Array.isArray(parsed.playlists)
                              ? parsed.playlists : [],
                        videos: Array.isArray(parsed.videos)
                              ? parsed.videos : [],
                        watch: normalizeWatchData(parsed.watch)
                  };
            } catch (error) {
                  console.error("تعذرت قراءة البيانات:", error);
                  return createInitialData();
            }
      }

      let appData = loadAppData();

      function saveAppData(silent = false) {
            try {
                  localStorage.setItem(
                        STORAGE_KEYS.data,
                        JSON.stringify(appData)
                  );
                  return true;
            } catch (error) {
                  console.error("تعذر حفظ البيانات:", error);

                  if (!silent) {
                        showToast("تعذر حفظ البيانات على هذا الجهاز.");
                  }

                  return false;
            }
      }

      function createId() {
            if (
                  typeof crypto !== "undefined" &&
                  typeof crypto.randomUUID === "function"
            ) {
                  return crypto.randomUUID();
            }

            return Date.now().toString(36) +
                  Math.random().toString(36).slice(2);
      }

      function escapeHTML(value) {
            return String(value).replace(/[&<>"']/g, character => {
                  const entities = {
                        "&": "&amp;",
                        "<": "&lt;",
                        ">": "&gt;",
                        '"': "&quot;",
                        "'": "&#39;"
                  };

                  return entities[character];
            });
      }

      function showToast(message) {
            let toast = document.getElementById("mushahid-toast");

            if (!toast) {
                  toast = document.createElement("div");
                  toast.id = "mushahid-toast";
                  toast.className = "mushahid-toast";
                  toast.setAttribute("role", "status");
                  toast.setAttribute("aria-live", "polite");
                  document.body.appendChild(toast);
            }

            toast.textContent = message;
            toast.classList.add("visible");

            clearTimeout(toastTimer);

            toastTimer = setTimeout(() => {
                  toast.classList.remove("visible");
            }, 2600);
      }


      async function copyVideoLink(url) {
            try {
                  if (navigator.clipboard && window.isSecureContext) {
                        await navigator.clipboard.writeText(url);
                  } else {
                        const textArea = document.createElement("textarea");
                        textArea.value = url;
                        textArea.style.position = "fixed";
                        textArea.style.opacity = "0";
                        document.body.appendChild(textArea);
                        textArea.select();

                        const copied = document.execCommand("copy");
                        textArea.remove();

                        if (!copied) {
                              throw new Error("تعذر نسخ الرابط");
                        }
                  }

                  showToast("تم نسخ رابط الفيديو.");
            } catch (error) {
                  showToast("تعذر نسخ الرابط. افتح الفيديو وانسخ رابطه يدويًا.");
            }
      }


      // المظهر

      function applyTheme(theme, save = true) {
            if (theme !== "light" && theme !== "dark") {
                  theme = "dark";
            }

            document.body.classList.toggle(
                  "light-theme",
                  theme === "light"
            );

            document.documentElement.style.colorScheme = theme;

            const meta = document.querySelector(
                  'meta[name="theme-color"]'
            );

            if (meta) {
                  meta.setAttribute(
                        "content",
                        theme === "light" ? "#f5f5f5" : "#141414"
                  );
            }

            if (save) {
                  try {
                        localStorage.setItem(STORAGE_KEYS.theme, theme);
                  } catch (error) {
                        showToast("تعذر حفظ إعداد المظهر.");
                  }
            }

            document.querySelectorAll("[data-theme-choice]")
                  .forEach(button => {
                        const selected =
                              button.dataset.themeChoice === theme;

                        button.classList.toggle("selected", selected);
                        button.setAttribute("aria-pressed", String(selected));
                  });

            applyCustomColors();
      }

      // الرئيسية

      function getSectionIcon(key) {
            const icons = {
                  playlists: "☷",
                  "watch-later": "◷",
                  "continue-watching": "▶"
            };

            return icons[key] || "•";
      }


      function renderPlaylistCards() {
            if (appData.playlists.length === 0) {
                  return `
                <div class="empty-state">
                    <div class="empty-icon">☷</div>
                    <h4>لم تنشئ قوائم بعد</h4>
                    <p>أنشئ قائمة لتنظيم المقاطع التي تريد مشاهدتها.</p>
                    <button class="text-button" data-action="add-list">
                        إنشاء أول قائمة ←
                    </button>
                </div>
            `;
            }

            return `
            <div class="playlist-list">
                ${appData.playlists.map(playlist => `
                    <div class="playlist-row">
                        <button class="playlist-open"
                            data-action="open-playlist"
                            data-id="${escapeHTML(playlist.id)}">
                            <span class="playlist-symbol">☷</span>
                            <span class="playlist-info">
                                <strong>${escapeHTML(playlist.name)}</strong>
                                <small>${escapeHTML(playlist.description || "قائمة شخصية")}</small>
                            </span>
                            <span class="card-arrow">←</span>
                        </button>
                    </div>
                `).join("")}
            </div>
        `;
      }

      // إنشاء قائمة

      function openCreatePlaylist() {
            closeModal();

            const modal = document.createElement("div");
            modal.id = "mushahid-modal";
            modal.className = "modal-backdrop";

            modal.innerHTML = `
            <section class="modal-card"
                role="dialog"
                aria-modal="true"
                aria-labelledby="modal-title">

                <div class="modal-heading">
                    <h3 id="modal-title">إنشاء قائمة جديدة</h3>
                    <button class="modal-close"
                        data-action="close-modal"
                        aria-label="إغلاق">×</button>
                </div>

                <form id="create-playlist-form">
                    <label class="field-label" for="playlist-name">
                        اسم القائمة
                    </label>

                    <input id="playlist-name"
                        name="playlistName"
                        class="text-field"
                        type="text"
                        maxlength="60"
                        placeholder="مثال: التاريخ الإسلامي"
                        required>

                    <label class="field-label" for="playlist-description">
                        وصف القائمة (اختياري)
                    </label>

                    <textarea id="playlist-description"
                        name="playlistDescription"
                        class="text-field"
                        maxlength="180"
                        rows="3"
                        placeholder="ما نوع المقاطع التي ستجمعها هنا؟"></textarea>

                    <p id="playlist-error"
                        class="form-error"
                        aria-live="polite"></p>

                    <div class="modal-actions">
                        <button type="button"
                            class="secondary-button"
                            data-action="close-modal">
                            إلغاء
                        </button>

                        <button type="submit" class="primary-button">
                            إنشاء القائمة
                        </button>
                    </div>
                </form>
            </section>
        `;

            document.body.appendChild(modal);

            modal.addEventListener("click", event => {
                  if (event.target === modal) closeModal();
            });

            document.getElementById("playlist-name").focus();
      }


      function openAddVideoModal(playlistId) {
            const playlist = appData.playlists.find(
                  item => item.id === playlistId
            );

            if (!playlist) {
                  showToast("لم يتم العثور على القائمة.");
                  return;
            }

            closeModal();

            const modal = document.createElement("div");
            modal.id = "mushahid-modal";
            modal.className = "modal-backdrop";

            modal.innerHTML = `
        <div class="modal-card" role="dialog"
             aria-modal="true" aria-labelledby="add-video-title">

            <div class="modal-heading">
                <h2 id="add-video-title">إضافة مقطع</h2>
                <button type="button" class="modal-close"
                        data-action="close-modal"
                        aria-label="إغلاق">×</button>
            </div>

            <p class="welcome-description">
                أضف رابط يوتيوب إلى قائمة
                <strong>${escapeHTML(playlist.name)}</strong>.
            </p>

            <form id="add-video-form" data-playlist-id="${escapeHTML(playlistId)}">
                <label class="field-label" for="youtube-video-url">
                    رابط المقطع
                </label>

                <input class="text-field" id="youtube-video-url"
                       name="videoUrl" type="url"
                       placeholder="https://www.youtube.com/watch?v=..."
                       required>

                <p id="youtube-video-error" class="form-error"
                   hidden></p>

                <div class="modal-actions">
                    <button type="button" class="secondary-button"
                            data-action="close-modal">
                        إلغاء
                    </button>

                    <button type="submit" class="primary-button">
                        إضافة المقطع
                    </button>
                </div>
            </form>
        </div>
    `;

            document.body.appendChild(modal);

            modal.addEventListener("click", event => {
                  if (event.target === modal) closeModal();
            });

            modal.querySelector("#youtube-video-url").focus();
      }


      function openRenamePlaylist(id) {
            const playlist = appData.playlists.find(item => item.id === id);

            if (!playlist) {
                  showToast("لم يتم العثور على القائمة.");
                  return;
            }

            closeModal();

            const modal = document.createElement("div");
            modal.id = "mushahid-modal";
            modal.className = "modal-backdrop";

            modal.innerHTML = `
        <section class="modal-card"
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title">

            <div class="modal-heading">
                <h3 id="modal-title">إعادة تسمية القائمة</h3>
                <button class="modal-close"
                    data-action="close-modal"
                    aria-label="إغلاق">×</button>
            </div>

            <form id="rename-playlist-form" data-id="${escapeHTML(id)}">
                <label class="field-label" for="rename-playlist-name">
                    اسم القائمة
                </label>

                <input id="rename-playlist-name"
                    name="playlistName"
                    class="text-field"
                    type="text"
                    maxlength="60"
                    value="${escapeHTML(playlist.name)}"
                    required>

                <label class="field-label" for="rename-playlist-description">
                    وصف القائمة (اختياري)
                </label>

                <textarea id="rename-playlist-description"
                    name="playlistDescription"
                    class="text-field"
                    maxlength="180"
                    rows="3"
                    placeholder="أضف وصفًا للقائمة">${escapeHTML(playlist.description || "")}</textarea>

                <p class="form-error" id="rename-playlist-error"
                    aria-live="polite"></p>

                <div class="modal-actions">
                    <button type="button"
                        class="secondary-button"
                        data-action="close-modal">
                        إلغاء
                    </button>

                    <button type="submit" class="primary-button">
                        حفظ التغييرات
                    </button>
                </div>
            </form>
        </section>
    `;

            document.body.appendChild(modal);

            modal.addEventListener("click", event => {
                  if (event.target === modal) closeModal();
            });

            const nameInput = document.getElementById("rename-playlist-name");
            nameInput.focus();
            nameInput.select();
      }


      function closeModal() {
            const modalIds = [
                  "mushahid-modal",
                  "edit-video-title-modal",
                  "transfer-video-modal"
            ];

            modalIds.forEach(id => {
                  const modal = document.getElementById(id);

                  if (modal) {
                        modal.remove();
                  }
            });
      }

      function openDeletePlaylistModal(id) {
            const playlist = appData.playlists.find(item => item.id === id);

            if (!playlist) {
                  showToast("لم يتم العثور على القائمة.");
                  return;
            }

            closeModal();

            const modal = document.createElement("div");
            modal.id = "mushahid-modal";
            modal.className = "modal-backdrop";

            modal.innerHTML = `
        <div class="modal-card" role="dialog"
             aria-modal="true" aria-labelledby="delete-modal-title">

            <div class="modal-heading">
                <h2 id="delete-modal-title">حذف القائمة</h2>
                <button type="button" class="modal-close"
                        data-action="close-modal"
                        aria-label="إغلاق">×</button>
            </div>

            <p>
                هل أنت متأكد من حذف قائمة
                <strong>${escapeHTML(playlist.name)}</strong>؟
                لا يمكن التراجع عن هذا الإجراء.
            </p>

            <div class="modal-actions">
                <button type="button" class="secondary-button"
                        data-action="close-modal">
                    إلغاء
                </button>

                <button type="button" class="primary-button"
                        data-action="confirm-delete-playlist"
                        data-id="${escapeHTML(id)}">
                    حذف القائمة
                </button>
            </div>
        </div>
    `;

            document.body.appendChild(modal);

            modal.addEventListener("click", event => {
                  if (event.target === modal) {
                        closeModal();
                  }
            });
      }


      function createPlaylist(name, description) {
            const cleanName = name.trim();
            const cleanDescription = description.trim();

            if (!cleanName) {
                  showToast("اكتب اسم القائمة أولًا.");
                  return false;
            }

            const playlist = {
                  id: createId(),
                  name: cleanName,
                  description: cleanDescription,
                  videoIds: [],
                  createdAt: new Date().toISOString()
            };

            appData.playlists.unshift(playlist);

            if (!saveAppData()) {
                  appData.playlists.shift();
                  return false;
            }

            closeModal();
            showToast("تم إنشاء القائمة بنجاح.");

            if (currentPage === "playlists") {
                  renderSection("playlists");
            } else {
                  renderHome();
            }

            return true;
      }

      // عرض الأقسام


      // فتح قائمة محددة


      function getYouTubeVideoId(url) {
            try {
                  const parsed = new URL(url.trim());
                  let videoId = "";

                  if (
                        parsed.hostname === "youtu.be" ||
                        parsed.hostname === "www.youtu.be"
                  ) {
                        videoId = parsed.pathname.split("/").filter(Boolean)[0] || "";
                  } else if (
                        ["youtube.com", "www.youtube.com", "m.youtube.com",
                              "music.youtube.com"].includes(parsed.hostname)
                  ) {
                        if (parsed.pathname === "/watch") {
                              videoId = parsed.searchParams.get("v") || "";
                        } else {
                              const match = parsed.pathname.match(
                                    /^\/(?:embed|shorts|live)\/([a-zA-Z0-9_-]{11})/
                              );
                              videoId = match ? match[1] : "";
                        }
                  }

                  return /^[a-zA-Z0-9_-]{11}$/.test(videoId)
                        ? videoId
                        : null;
            } catch {
                  return null;
            }
      }



      function openPlaylist(id) {
            leaveWatchPage();

            const playlist = appData.playlists.find(item => item.id === id);

            if (!playlist) {
                  showToast("لم يتم العثور على القائمة.");
                  return;
            }

            currentPage = "playlist-detail";
            activePlaylistId = id;
            setActiveNav("playlists");

            const playlistVideos = getPlaylistOrder(playlist)
                  .map(findVideo)
                  .filter(Boolean);

            const isManualOrder = playlist.sortMode === "manual";

            const videosHTML = playlistVideos.length > 0
                  ? `
            <div class="playlist-videos">
                ${playlistVideos.map((video, index) => `
                    <div class="playlist-video-card">
                        <a class="playlist-video-link"
                           href="#"
                           data-action="watch-video"
                           data-video-id="${escapeHTML(video.id)}"
                           data-id="${escapeHTML(playlist.id)}">

                            <img
                                class="playlist-video-thumbnail"
                                src="${escapeHTML(video.thumbnail)}"
                                alt=""
                                loading="lazy">
                            ${renderProgressLine(video.id)}

                            <div class="playlist-video-info">
                                <h4>${escapeHTML(video.title)}</h4>
                                <p>${getVideoStatusText(video.id)}</p>
                            </div>
                        </a>

                        <div class="playlist-video-actions">
                              <button
                                    class="video-menu-toggle"
                                    data-action="toggle-video-menu"
                                    data-video-id="${escapeHTML(video.id)}"
                                    aria-label="خيارات المقطع"
                                    aria-expanded="false">
                                    <svg viewBox="0 0 24 24" aria-hidden="true">
                                          <circle cx="12" cy="5" r="2"/>
                                          <circle cx="12" cy="12" r="2"/>
                                          <circle cx="12" cy="19" r="2"/>
                                    </svg>
                              </button>

                              ${isManualOrder ? `
                              <div class="video-reorder">
                                    <button
                                          data-action="move-video-order"
                                          data-id="${escapeHTML(playlist.id)}"
                                          data-video-id="${escapeHTML(video.id)}"
                                          data-direction="up"
                                          aria-label="نقل للأعلى"
                                          ${index === 0 ? "disabled" : ""}>
                                          <svg viewBox="0 0 24 24" aria-hidden="true">
                                                <path d="M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z"/>
                                          </svg>
                                    </button>
                                    <button
                                          data-action="move-video-order"
                                          data-id="${escapeHTML(playlist.id)}"
                                          data-video-id="${escapeHTML(video.id)}"
                                          data-direction="down"
                                          aria-label="نقل للأسفل"
                                          ${index === playlistVideos.length - 1 ? "disabled" : ""}>
                                          <svg viewBox="0 0 24 24" aria-hidden="true">
                                                <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6z"/>
                                          </svg>
                                    </button>
                              </div>
                              ` : ""}

                              <div class="video-menu" id="video-menu-${escapeHTML(video.id)}" hidden>
                                    <button
                                          data-action="copy-video-link"
                                          data-video-url="${escapeHTML(video.url)}">
                                          نسخ الرابط
                                    </button>

                                    <button
                                          data-action="edit-video-title"
                                          data-video-id="${escapeHTML(video.id)}">
                                          تعديل العنوان
                                    </button>

                                    <button
                                          data-action="move-video"
                                          data-id="${escapeHTML(playlist.id)}"
                                          data-video-id="${escapeHTML(video.id)}">
                                          نقل إلى قائمة أخرى
                                    </button>

                                    <button
                                          data-action="copy-video-to-playlist"
                                          data-id="${escapeHTML(playlist.id)}"
                                          data-video-id="${escapeHTML(video.id)}">
                                          نسخ إلى قائمة أخرى
                                    </button>

                                    <button
                                          data-action="toggle-watch-later"
                                          data-video-id="${escapeHTML(video.id)}">
                                          ${isInWatchLater(video.id) ? "إزالة من المشاهدة لاحقًا" : "إضافة إلى المشاهدة لاحقًا"}
                                    </button>

                                    <button
                                          data-action="toggle-watched"
                                          data-video-id="${escapeHTML(video.id)}">
                                          ${isVideoWatched(video.id) ? "إلغاء علامة المشاهدة" : "تحديد كمشاهَد"}
                                    </button>

                                    <button
                                          data-action="remove-video-from-playlist"
                                          data-id="${escapeHTML(playlist.id)}"
                                          data-video-id="${escapeHTML(video.id)}">
                                          إزالة من القائمة
                                    </button>
                              </div>
                        </div>

                        
                    </div>
                `).join("")}
            </div>
        `
                  : `
            <div class="empty-state">
                <div class="empty-icon">☷</div>
                <h4>لا توجد مقاطع في هذه القائمة</h4>
                <p>اضغط على «إضافة مقطع» لإضافة أول مقطع لك.</p>
            </div>
        `;

            mainContent.innerHTML = `
        <section class="subpage-header">
            <button class="back-button"
                data-action="open-section"
                data-section="playlists">
                ← العودة إلى قوائمي
            </button>

            <p class="eyebrow">قائمة شخصية</p>
            <h2>${escapeHTML(playlist.name)}</h2>
            <p class="welcome-description">
                ${escapeHTML(playlist.description || "لا يوجد وصف لهذه القائمة.")}
            </p>
        </section>

        <div class="section-actions">
            <button class="primary-button"
                data-action="add-video-to-playlist"
                data-id="${escapeHTML(playlist.id)}">
                ＋ إضافة مقطع
            </button>

            <button class="secondary-button"
                data-action="open-bulk-add"
                data-id="${escapeHTML(playlist.id)}">
                ＋ إضافة عدة روابط
            </button>

            <button class="secondary-button"
                data-action="open-sort-menu"
                data-id="${escapeHTML(playlist.id)}">
                ترتيب: ${getSortModeLabel(playlist.sortMode)}
            </button>

            <button class="secondary-button"
                data-action="rename-playlist"
                data-id="${escapeHTML(playlist.id)}">
                إعادة التسمية
            </button>

            <button class="secondary-button"
                data-action="delete-playlist"
                data-id="${escapeHTML(playlist.id)}">
                حذف القائمة
            </button>
        </div>

        <section class="content-section">
            ${videosHTML}
        </section>
    `;

            window.scrollTo(0, 0);
      }


      function renamePlaylist(id, name, description) {
            const playlist = appData.playlists.find(item => item.id === id);

            if (!playlist) {
                  showToast("لم يتم العثور على القائمة.");
                  return false;
            }

            const cleanName = name.trim();
            const cleanDescription = description.trim();

            if (!cleanName) {
                  showToast("اكتب اسم القائمة أولًا.");
                  return false;
            }

            const oldName = playlist.name;
            const oldDescription = playlist.description;

            playlist.name = cleanName;
            playlist.description = cleanDescription;

            if (!saveAppData()) {
                  playlist.name = oldName;
                  playlist.description = oldDescription;
                  return false;
            }

            closeModal();
            showToast("تم حفظ التغييرات بنجاح.");
            openPlaylist(id);

            return true;
      }


      function deletePlaylist(id) {
            const originalPlaylists = appData.playlists;

            appData.playlists = originalPlaylists.filter(
                  playlist => playlist.id !== id
            );

            if (!saveAppData()) {
                  appData.playlists = originalPlaylists;
                  return;
            }

            closeModal();
            showToast("تم حذف القائمة.");

            if (currentPage === "playlist-detail") {
                  renderSection("playlists");
            } else {
                  renderHome();
            }
      }

      function openTransferVideoModal(playlistId, videoId, mode) {
            const video = appData.videos.find(
                  item => item.id === videoId
            );

            const sourcePlaylist = appData.playlists.find(
                  item => item.id === playlistId
            );

            if (!video || !sourcePlaylist) {
                  showToast("تعذر العثور على المقطع أو القائمة.");
                  return;
            }

            const availablePlaylists = appData.playlists.filter(playlist => {
                  if (playlist.id === playlistId) {
                        return false;
                  }

                  if (!Array.isArray(playlist.videoIds)) {
                        return true;
                  }

                  return !playlist.videoIds.includes(videoId);
            });

            if (availablePlaylists.length === 0) {
                  showToast("لا توجد قوائم أخرى مناسبة لهذا المقطع.");
                  return;
            }

            const isMove = mode === "move";
            const modalTitle = isMove ? "نقل المقطع" : "نسخ المقطع";
            const buttonText = isMove ? "نقل المقطع" : "نسخ المقطع";

            mainContent.insertAdjacentHTML("beforeend", `
        <div class="modal-backdrop" id="transfer-video-modal">
            <div class="modal-card">
                <div class="modal-heading">
                    <h3>${modalTitle}</h3>
                    <button
                        class="modal-close"
                        data-action="close-modal"
                        aria-label="إغلاق">
                        ×
                    </button>
                </div>

                <p class="welcome-description">
                    ${escapeHTML(video.title)}
                </p>

                <form
                    id="transfer-video-form"
                    data-source-id="${escapeHTML(playlistId)}"
                    data-video-id="${escapeHTML(videoId)}"
                    data-mode="${isMove ? "move" : "copy"}">

                    <label class="field-label" for="target-playlist">
                        اختر القائمة المستهدفة
                    </label>

                    <select
                        class="text-field"
                        id="target-playlist"
                        name="targetPlaylistId"
                        required>
                        ${availablePlaylists.map(playlist => `
                            <option value="${escapeHTML(playlist.id)}">
                                ${escapeHTML(playlist.name)}
                            </option>
                        `).join("")}
                    </select>

                    <div class="modal-actions">
                        <button type="submit" class="primary-button">
                            ${buttonText}
                        </button>

                        <button
                            type="button"
                            class="secondary-button"
                            data-action="close-modal">
                            إلغاء
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `);
      }

      function openEditVideoTitle(videoId) {
            const video = appData.videos.find(
                  item => item.id === videoId
            );

            if (!video) {
                  showToast("لم يتم العثور على المقطع.");
                  return;
            }

            mainContent.insertAdjacentHTML("beforeend", `
        <div class="modal-backdrop" id="edit-video-title-modal">
            <div class="modal-card">
                <div class="modal-heading">
                    <h3>تعديل عنوان المقطع</h3>
                    <button
                        class="modal-close"
                        data-action="close-modal"
                        aria-label="إغلاق">
                        ×
                    </button>
                </div>

                <form id="edit-video-title-form" data-video-id="${escapeHTML(video.id)}">
                    <label class="field-label" for="edit-video-title">
                        العنوان الجديد
                    </label>

                    <input
                        class="text-field"
                        id="edit-video-title"
                        name="title"
                        type="text"
                        maxlength="200"
                        value="${escapeHTML(video.title)}"
                        required>

                    <p class="form-error" id="edit-video-title-error" hidden></p>

                    <div class="modal-actions">
                        <button type="submit" class="primary-button">
                            حفظ العنوان
                        </button>

                        <button
                            type="button"
                            class="secondary-button"
                            data-action="close-modal">
                            إلغاء
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `);

            document.getElementById("edit-video-title").focus();
      }


      function removeVideoFromPlaylist(playlistId, videoId) {
            const playlist = appData.playlists.find(
                  item => item.id === playlistId
            );

            if (!playlist) {
                  showToast("لم يتم العثور على القائمة.");
                  return;
            }

            const originalVideoIds = [...playlist.videoIds];

            playlist.videoIds = playlist.videoIds.filter(
                  id => id !== videoId
            );

            if (!saveAppData()) {
                  playlist.videoIds = originalVideoIds;
                  return;
            }

            showToast("تمت إزالة المقطع من القائمة.");
            openPlaylist(playlistId);
      }


      // ===== إضافة روابط يوتيوب دفعة واحدة =====

      const NEW_PLAYLIST_VALUE = "__new__";

      // تحليل النص: يفصل الروابط بالأسطر والمسافات والفواصل (, ; ، ؛)
      function parseBulkLinks(text) {
            const tokens = String(text)
                  .split(/[\s,;،؛]+/)
                  .map(token => token.trim())
                  .filter(Boolean);

            const seen = new Set();
            const result = {
                  total: tokens.length,
                  validCount: 0,
                  uniqueIds: [],
                  duplicatesInBatch: 0,
                  invalid: []
            };

            tokens.forEach(token => {
                  // إن لم يبدأ الرابط بـ http نضيفها حتى يقبله فحص الرابط
                  const candidate = /^https?:\/\//i.test(token)
                        ? token
                        : "https://" + token;

                  const videoId = getYouTubeVideoId(candidate);

                  if (!videoId) {
                        result.invalid.push(token);
                        return;
                  }

                  result.validCount++;

                  if (seen.has(videoId)) {
                        result.duplicatesInBatch++;
                        return;
                  }

                  seen.add(videoId);
                  result.uniqueIds.push(videoId);
            });

            return result;
      }

      function formatVideoCount(count) {
            if (count === 1) return "مقطع واحد";
            if (count === 2) return "مقطعان";
            if (count >= 3 && count <= 10) return `${count} مقاطع`;
            return `${count} مقطعًا`;
      }

      function openBulkAddModal(preselectedPlaylistId) {
            closeModal();

            const playlists = appData.playlists;
            const hasPreselected = playlists.some(
                  item => item.id === preselectedPlaylistId
            );

            let defaultTarget = "";

            if (hasPreselected) {
                  defaultTarget = preselectedPlaylistId;
            } else if (playlists.length === 0) {
                  defaultTarget = NEW_PLAYLIST_VALUE;
            }

            const optionsHTML = [
                  hasPreselected || playlists.length === 0
                        ? ""
                        : `<option value="" selected>اختر القائمة...</option>`,
                  ...playlists.map(item => `
                        <option value="${escapeHTML(item.id)}"${item.id === defaultTarget ? " selected" : ""}>
                              ${escapeHTML(item.name)}
                        </option>`),
                  `<option value="${NEW_PLAYLIST_VALUE}"${defaultTarget === NEW_PLAYLIST_VALUE ? " selected" : ""}>
                        ＋ إنشاء قائمة جديدة...
                  </option>`
            ].join("");

            const modal = document.createElement("div");
            modal.id = "mushahid-modal";
            modal.className = "modal-backdrop";

            modal.innerHTML = `
        <div class="modal-card" role="dialog"
             aria-modal="true" aria-labelledby="bulk-add-title">

            <div class="modal-heading">
                <h2 id="bulk-add-title">إضافة عدة روابط</h2>
                <button type="button" class="modal-close"
                        data-action="close-modal"
                        aria-label="إغلاق">×</button>
            </div>

            <p class="welcome-description">
                الصق روابط يوتيوب مفصولة بسطر جديد أو مسافة أو فاصلة.
                لن يُحفظ شيء قبل الضغط على زر التأكيد.
            </p>

            <label class="field-label" for="bulk-links">الروابط</label>
            <textarea class="text-field bulk-links-field" id="bulk-links"
                      rows="6" dir="ltr" spellcheck="false"
                      placeholder="https://youtu.be/...&#10;https://www.youtube.com/watch?v=..."></textarea>

            <label class="field-label" for="bulk-target">القائمة المستهدفة</label>
            <select class="text-field" id="bulk-target">${optionsHTML}</select>

            <div id="bulk-new-wrap" hidden>
                <label class="field-label" for="bulk-new-name">اسم القائمة الجديدة</label>
                <input class="text-field" id="bulk-new-name" type="text"
                       maxlength="80" placeholder="مثال: مقاطع للمشاهدة">
            </div>

            <div class="bulk-preview" id="bulk-preview" aria-live="polite"></div>

            <p class="form-error" id="bulk-error" hidden></p>

            <div class="modal-actions">
                <button type="button" class="secondary-button"
                        data-action="close-modal">
                    إلغاء
                </button>

                <button type="button" class="primary-button"
                        id="bulk-confirm" disabled>
                    تأكيد الإضافة
                </button>
            </div>
        </div>
    `;

            document.body.appendChild(modal);

            const textarea = modal.querySelector("#bulk-links");
            const select = modal.querySelector("#bulk-target");
            const newWrap = modal.querySelector("#bulk-new-wrap");
            const newNameInput = modal.querySelector("#bulk-new-name");
            const preview = modal.querySelector("#bulk-preview");
            const errorElement = modal.querySelector("#bulk-error");
            const confirmButton = modal.querySelector("#bulk-confirm");

            // المعرّفات الموجودة في القائمة المستهدفة الحالية
            function getTargetExistingIds() {
                  const target = appData.playlists.find(
                        item => item.id === select.value
                  );

                  return new Set(
                        target && Array.isArray(target.videoIds)
                              ? target.videoIds
                              : []
                  );
            }

            function updatePreview() {
                  errorElement.hidden = true;
                  newWrap.hidden = select.value !== NEW_PLAYLIST_VALUE;

                  const parsed = parseBulkLinks(textarea.value);

                  if (parsed.total === 0) {
                        preview.innerHTML = `
                              <p class="bulk-preview-hint">
                                    الصق الروابط لتظهر المعاينة هنا.
                              </p>`;
                        confirmButton.disabled = true;
                        return;
                  }

                  const existingIds = getTargetExistingIds();
                  const alreadyInTarget = parsed.uniqueIds.filter(
                        videoId => existingIds.has(videoId)
                  ).length;
                  const willAdd = parsed.uniqueIds.length - alreadyInTarget;

                  const invalidHTML = parsed.invalid.length > 0
                        ? `
                              <p class="bulk-invalid-title">روابط غير صالحة:</p>
                              <ul class="bulk-invalid">
                                    ${parsed.invalid.slice(0, 5).map(item => `
                                          <li>${escapeHTML(
                                                item.length > 60
                                                      ? item.slice(0, 60) + "…"
                                                      : item
                                          )}</li>`).join("")}
                                    ${parsed.invalid.length > 5
                                          ? `<li>… و${parsed.invalid.length - 5} أخرى</li>`
                                          : ""}
                              </ul>`
                        : "";

                  preview.innerHTML = `
                        <ul class="bulk-stats">
                              <li>عدد العناصر المدخلة <strong>${parsed.total}</strong></li>
                              <li>الروابط الصحيحة <strong>${parsed.validCount}</strong></li>
                              <li>المقاطع الفريدة <strong>${parsed.uniqueIds.length}</strong></li>
                              <li>مكررة داخل المجموعة <strong>${parsed.duplicatesInBatch}</strong></li>
                              <li>موجودة بالفعل في القائمة <strong>${alreadyInTarget}</strong></li>
                              <li>غير صالحة أو غير مدعومة <strong>${parsed.invalid.length}</strong></li>
                              <li class="bulk-stats-total">ستُضاف فعليًا <strong>${willAdd}</strong></li>
                        </ul>
                        ${invalidHTML}`;

                  confirmButton.disabled = willAdd === 0 || !select.value;
            }

            function showBulkError(message) {
                  errorElement.textContent = message;
                  errorElement.hidden = false;
            }

            function confirmBulkAdd() {
                  const parsed = parseBulkLinks(textarea.value);
                  const targetValue = select.value;

                  if (!targetValue) {
                        showBulkError("اختر القائمة المستهدفة أولًا.");
                        return;
                  }

                  let playlist = null;
                  let isNewPlaylist = false;

                  if (targetValue === NEW_PLAYLIST_VALUE) {
                        const name = newNameInput.value.trim();

                        if (!name) {
                              showBulkError("اكتب اسم القائمة الجديدة.");
                              newNameInput.focus();
                              return;
                        }

                        isNewPlaylist = true;
                        playlist = {
                              id: createId(),
                              name,
                              description: "",
                              videoIds: [],
                              createdAt: new Date().toISOString()
                        };
                  } else {
                        playlist = appData.playlists.find(
                              item => item.id === targetValue
                        );

                        if (!playlist) {
                              showBulkError("لم يتم العثور على القائمة.");
                              return;
                        }

                        if (!Array.isArray(playlist.videoIds)) {
                              playlist.videoIds = [];
                        }
                  }

                  const existingIds = new Set(playlist.videoIds);
                  const idsToAdd = parsed.uniqueIds.filter(
                        videoId => !existingIds.has(videoId)
                  );

                  if (idsToAdd.length === 0) {
                        showBulkError("لا توجد مقاطع جديدة لإضافتها.");
                        return;
                  }

                  // نسخ احتياطية في الذاكرة لاستعادة الحالة إذا فشل الحفظ
                  const backupVideos = [...appData.videos];
                  const backupPlaylists = [...appData.playlists];
                  const backupVideoIds = [...playlist.videoIds];

                  if (isNewPlaylist) {
                        appData.playlists.unshift(playlist);
                  }

                  const knownVideoIds = new Set(
                        appData.videos.map(video => video.id)
                  );

                  idsToAdd.forEach(videoId => {
                        if (!knownVideoIds.has(videoId)) {
                              appData.videos.push({
                                    id: videoId,
                                    title: `مقطع يوتيوب (${videoId})`,
                                    url: `https://www.youtube.com/watch?v=${videoId}`,
                                    thumbnail:
                                          `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
                              });
                              knownVideoIds.add(videoId);
                        }

                        playlist.videoIds.push(videoId);
                  });

                  if (!saveAppData()) {
                        appData.videos = backupVideos;
                        appData.playlists = backupPlaylists;
                        playlist.videoIds = backupVideoIds;
                        return;
                  }

                  closeModal();
                  showToast(
                        `تمت إضافة ${formatVideoCount(idsToAdd.length)} إلى «${playlist.name}».`
                  );
                  openPlaylist(playlist.id);
            }

            textarea.addEventListener("input", updatePreview);
            select.addEventListener("change", updatePreview);
            confirmButton.addEventListener("click", confirmBulkAdd);

            modal.addEventListener("click", event => {
                  if (event.target === modal) closeModal();
            });

            updatePreview();
            textarea.focus();
      }

      // ===== التنقل السفلي والصفحات الرئيسية =====

      let sectionOrigin = "playlists";

      function setActiveNav(tab) {
            document.querySelectorAll("[data-nav]").forEach(item => {
                  const active = item.dataset.nav === tab;

                  item.classList.toggle("is-active", active);

                  if (active) {
                        item.setAttribute("aria-current", "page");
                  } else {
                        item.removeAttribute("aria-current");
                  }
            });
      }

      function navigateTo(tab) {
            switch (tab) {
                  case "home":
                        renderHome();
                        break;
                  case "playlists":
                        renderSection("playlists");
                        break;
                  case "stats":
                        renderStats();
                        break;
                  case "settings":
                        renderSettings();
                        break;
            }
      }

      function renderHome() {
            leaveWatchPage();

            currentPage = "home";
            activePlaylistId = null;
            setActiveNav("home");

            const continueCount = getContinueWatchingVideos().length;
            const laterCount = appData.watch.watchLater.filter(isLibraryVideo).length;

            const counts = {
                  "continue-watching": continueCount,
                  "watch-later": laterCount
            };

            mainContent.innerHTML = `
            <section class="welcome-section">
                <p class="eyebrow">مساحتك الخاصة</p>
                <h2>شاهد ما اخترته،<br>لا ما اختير لك.</h2>
                <p class="welcome-description">
                    اجمع مقاطعك وقوائمك في مكان واحد،
                    وابتعد عن التصفح العشوائي.
                </p>
            </section>

            <section class="quick-actions quick-actions-single">
                <button class="primary-button" data-action="open-direct">
                    <span>▶</span> شاهد مباشرة
                </button>
            </section>

            <section class="content-section">
                <div class="section-heading">
                    <div>
                        <h3>مشاهدتك</h3>
                        <p>أكمل ما بدأته أو شاهد ما حفظته لاحقًا</p>
                    </div>
                </div>

                <div class="library-grid">
                    ${["continue-watching", "watch-later"].map(key => `
                        <button class="library-card"
                            data-action="open-section"
                            data-section="${key}">
                            <span class="card-icon">${getSectionIcon(key)}</span>
                            <span class="card-title">${SECTIONS[key].title}</span>
                            <span class="card-description">
                                ${counts[key] > 0
                                      ? formatVideoCount(counts[key])
                                      : SECTIONS[key].description}
                            </span>
                            <span class="card-arrow">←</span>
                        </button>
                    `).join("")}
                </div>
            </section>
        `;

            window.scrollTo(0, 0);
      }

      // تبويب «القوائم»: المشاهدة لاحقًا ثم متابعة المشاهدة ثم قوائمي
      function renderListsTab() {
            leaveWatchPage();

            currentPage = "playlists";
            activePlaylistId = null;
            setActiveNav("playlists");

            const laterCount = appData.watch.watchLater.filter(isLibraryVideo).length;
            const continueCount = getContinueWatchingVideos().length;

            const counts = {
                  "watch-later": laterCount,
                  "continue-watching": continueCount
            };

            mainContent.innerHTML = `
            <section class="subpage-header">
                <p class="eyebrow">مكتبتك</p>
                <h2>القوائم</h2>
                <p class="welcome-description">
                    ما تريد مشاهدته لاحقًا، وقوائمك الشخصية.
                </p>
            </section>

            <section class="content-section">
                <div class="library-grid">
                    ${["watch-later", "continue-watching"].map(key => `
                        <button class="library-card"
                            data-action="open-section"
                            data-section="${key}">
                            <span class="card-icon">${getSectionIcon(key)}</span>
                            <span class="card-title">${SECTIONS[key].title}</span>
                            <span class="card-description">
                                ${counts[key] > 0
                                      ? formatVideoCount(counts[key])
                                      : SECTIONS[key].description}
                            </span>
                            <span class="card-arrow">←</span>
                        </button>
                    `).join("")}
                </div>
            </section>

            <section class="content-section">
                <div class="section-heading">
                    <div>
                        <h3>قوائمي</h3>
                        <p>${SECTIONS.playlists.description}</p>
                    </div>
                </div>

                <div class="section-actions">
                    <button class="primary-button" data-action="add-video">
                        ＋ إضافة مقطع
                    </button>

                    <button class="secondary-button" data-action="add-list">
                        ＋ إنشاء قائمة
                    </button>
                </div>

                ${renderPlaylistCards()}
            </section>
        `;

            window.scrollTo(0, 0);
      }

      function renderSection(key) {
            leaveWatchPage();

            const section = SECTIONS[key];

            if (!section) return;

            if (key === "playlists") {
                  renderListsTab();
                  return;
            }

            currentPage = key;
            activePlaylistId = null;
            setActiveNav("playlists");

            const content = renderSectionVideoCards(key) || `
                <div class="empty-state">
                    <div class="empty-icon">${getSectionIcon(key)}</div>
                    <h4>${section.empty}</h4>
                    <p>${key === "watch-later"
                        ? "أضف مقطعًا من قائمة ⋮ ثم «إضافة إلى المشاهدة لاحقًا»."
                        : "ابدأ مشاهدة مقطع وسيظهر هنا حتى تكمله."}</p>
                </div>
            `;

            const backButtonHTML = sectionOrigin === "home"
                  ? `
                <button class="back-button" data-action="back">
                    ← العودة
                </button>`
                  : `
                <button class="back-button"
                    data-action="open-section"
                    data-section="playlists">
                    ← العودة إلى القوائم
                </button>`;

            mainContent.innerHTML = `
            <section class="subpage-header">
                ${backButtonHTML}
                <p class="eyebrow">مكتبتك</p>
                <h2>${section.title}</h2>
                <p class="welcome-description">${section.description}</p>
            </section>

            <section class="content-section">
                ${content}
            </section>
        `;

            window.scrollTo(0, 0);
      }

      // ===== الإحصائيات =====

      function getLocalDateKey(date = new Date()) {
            const pad = value => String(value).padStart(2, "0");

            return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
      }

      function formatDuration(totalSeconds) {
            const total = Math.max(0, Math.floor(Number(totalSeconds) || 0));

            if (total < 60) return total === 0 ? "0 دقيقة" : "أقل من دقيقة";

            const hours = Math.floor(total / 3600);
            const minutes = Math.floor((total % 3600) / 60);

            if (hours === 0) return `${minutes} دقيقة`;

            return minutes === 0
                  ? `${hours} ساعة`
                  : `${hours} ساعة و${minutes} دقيقة`;
      }

      function getWatchTimeStats() {
            const daily = appData.watch.stats.daily;
            const now = new Date();

            let last7 = 0;

            for (let offset = 0; offset < 7; offset++) {
                  const day = new Date(now.getFullYear(), now.getMonth(), now.getDate() - offset);

                  last7 += Number(daily[getLocalDateKey(day)]) || 0;
            }

            const total = Object.values(daily)
                  .reduce((sum, value) => sum + (Number(value) || 0), 0);

            return {
                  today: Number(daily[getLocalDateKey(now)]) || 0,
                  last7,
                  total
            };
      }

      function renderStats() {
            leaveWatchPage();

            currentPage = "stats";
            activePlaylistId = null;
            setActiveNav("stats");

            const time = getWatchTimeStats();
            const watch = appData.watch;

            const watchedCount = Object.keys(watch.watched).filter(isLibraryVideo).length;
            const notesCount = Object.values(watch.notes)
                  .reduce((sum, list) => sum + (Array.isArray(list) ? list.length : 0), 0);

            const cards = [
                  ["اليوم", formatDuration(time.today), true],
                  ["آخر 7 أيام", formatDuration(time.last7), true],
                  ["الإجمالي", formatDuration(time.total), true],
                  ["مقاطع المكتبة", String(appData.videos.length), false],
                  ["القوائم", String(appData.playlists.length), false],
                  ["تمت مشاهدتها", String(watchedCount), false],
                  ["قيد المتابعة", String(getContinueWatchingVideos().length), false],
                  ["المشاهدة لاحقًا", String(watch.watchLater.filter(isLibraryVideo).length), false],
                  ["العلامات الزمنية", String(notesCount), false]
            ];

            const renderCard = ([label, value, wide]) => `
                <div class="stat-card${wide ? " stat-card-wide" : ""}">
                    <strong>${escapeHTML(value)}</strong>
                    <span>${label}</span>
                </div>`;

            mainContent.innerHTML = `
            <section class="subpage-header">
                <p class="eyebrow">أرقامك</p>
                <h2>الإحصائيات</h2>
                <p class="welcome-description">
                    ملخص محلي عن مكتبتك ووقت مشاهدتك.
                </p>
            </section>

            <section class="content-section">
                <div class="section-heading">
                    <div>
                        <h3>وقت المشاهدة</h3>
                        <p>يُحتسب أثناء تشغيل المقاطع داخل التطبيق (تقريبي)</p>
                    </div>
                </div>

                <div class="stats-grid">
                    ${cards.slice(0, 3).map(renderCard).join("")}
                </div>
            </section>

            <section class="content-section">
                <div class="section-heading">
                    <div>
                        <h3>مكتبتك</h3>
                        <p>أعداد ما حفظته على هذا الجهاز</p>
                    </div>
                </div>

                <div class="stats-grid">
                    ${cards.slice(3).map(renderCard).join("")}
                </div>
            </section>
        `;

            window.scrollTo(0, 0);
      }

      // ===== الإعدادات =====

      function renderSettings() {
            leaveWatchPage();

            currentPage = "settings";
            activePlaylistId = null;
            setActiveNav("settings");

            mainContent.innerHTML = `
                <section class="subpage-header">
                    <p class="eyebrow">تفضيلاتك</p>
                    <h2>الإعدادات</h2>
                    <p class="welcome-description">
                        اختر المظهر والألوان التي تناسبك.
                    </p>
                </section>

                <section class="settings-section">
                    <div class="settings-heading">
                        <h3>المظهر</h3>
                        <p>يمكنك تغيير المظهر في أي وقت. اختيار مظهر يعيد الألوان المخصصة.</p>
                    </div>

                    <div class="theme-options">
                        <button class="theme-option"
                            data-theme-choice="dark"
                            aria-pressed="false">
                            <span class="theme-preview dark-preview">
                                <span></span><span></span><span></span>
                            </span>
                            <span class="theme-option-text">
                                <strong>الوضع الداكن</strong>
                                <small>المظهر الافتراضي</small>
                            </span>
                            <span class="theme-check">✓</span>
                        </button>

                        <button class="theme-option"
                            data-theme-choice="light"
                            aria-pressed="false">
                            <span class="theme-preview light-preview">
                                <span></span><span></span><span></span>
                            </span>
                            <span class="theme-option-text">
                                <strong>الوضع الفاتح</strong>
                                <small>خلفية فاتحة وألوان هادئة</small>
                            </span>
                            <span class="theme-check">✓</span>
                        </button>
                    </div>
                </section>

                <section class="settings-section">
                    <div class="settings-heading">
                        <h3>ألوان التطبيق</h3>
                        <p>اختر ألوانك الخاصة، وتتغير الواجهة فورًا.</p>
                    </div>

                    <div class="color-list">
                        ${COLOR_ROLES.map(role => `
                            <label class="color-row">
                                <span>${COLOR_ROLE_LABELS[role]}</span>
                                <input type="color" class="color-input"
                                       data-color-role="${role}" value="#000000">
                            </label>
                        `).join("")}
                    </div>

                    <p class="swatch-title">ألوان الأزرار الجاهزة</p>
                    <div class="swatch-row">
                        ${ACCENT_PRESETS.map(([name, color]) => `
                            <button type="button" class="color-swatch"
                                data-accent-preset="${color}"
                                style="background: ${color}"
                                aria-label="${name}"
                                aria-pressed="false"></button>
                        `).join("")}
                    </div>

                    <p class="swatch-title">خلفيات جاهزة</p>
                    <div class="swatch-row">
                        ${BACKGROUND_PRESETS.map(([name, background, surface, text]) => `
                            <button type="button" class="color-swatch color-swatch-split"
                                data-bg-preset="${background}|${surface}|${text}"
                                style="--swatch-bg: ${background}; --swatch-surface: ${surface}"
                                aria-label="${name}"
                                aria-pressed="false"><span></span></button>
                        `).join("")}
                    </div>

                    <button type="button" class="secondary-button color-reset"
                        data-action="reset-colors">
                        إعادة الألوان الافتراضية
                    </button>
                </section>

                <section class="settings-section">
                    <div class="about-card">
                        <div class="brand-icon">م</div>
                        <div>
                            <strong>مشاهد</strong>
                            <p>مكتبتك الخاصة للمشاهدة</p>
                            <small>الإصدار الأولي — قيد التطوير</small>
                        </div>
                    </div>
                </section>
            `;

            applyTheme(
                  localStorage.getItem(STORAGE_KEYS.theme) || "dark",
                  false
            );

            bindColorControls();
            updateColorControls();

            window.scrollTo(0, 0);
      }

      // ===== ألوان التطبيق المخصصة =====

      const THEME_COLORS = {
            dark: {
                  accent: "#e53935",
                  background: "#141414",
                  surface: "#1e1e1e",
                  text: "#f5f5f5"
            },
            light: {
                  accent: "#d93030",
                  background: "#f5f5f5",
                  surface: "#ffffff",
                  text: "#202020"
            }
      };

      const COLOR_ROLES = ["accent", "background", "surface", "text"];

      const COLOR_ROLE_LABELS = {
            accent: "لون الأزرار والتمييز",
            background: "لون الخلفية",
            surface: "لون البطاقات",
            text: "لون النص"
      };

      const CUSTOM_COLOR_VARS = [
            "--accent", "--accent-hover", "--accent-soft", "--on-accent",
            "--background", "--surface", "--surface-hover", "--border",
            "--text-primary", "--text-secondary"
      ];

      const ACCENT_PRESETS = [
            ["أحمر", "#e53935"],
            ["أزرق", "#1e88e5"],
            ["أخضر", "#43a047"],
            ["بنفسجي", "#8e24aa"],
            ["برتقالي", "#fb8c00"],
            ["وردي", "#d81b60"],
            ["أزرق مخضر", "#00897b"]
      ];

      // الاسم، الخلفية، البطاقات، النص
      const BACKGROUND_PRESETS = [
            ["فحمي", "#141414", "#1e1e1e", "#f5f5f5"],
            ["أسود", "#000000", "#101010", "#f5f5f5"],
            ["كحلي", "#0f172a", "#1e293b", "#f1f5f9"],
            ["أخضر داكن", "#0b1a14", "#14281f", "#e8f5ee"],
            ["بنفسجي داكن", "#15101f", "#211a30", "#f0eaff"],
            ["فاتح", "#f5f5f5", "#ffffff", "#202020"],
            ["كريمي", "#faf5ee", "#fffdf8", "#2b2118"]
      ];

      function parseHexColor(value) {
            const match = /^#([0-9a-f]{6})$/i.exec(String(value).trim());

            if (!match) return null;

            const hex = match[1];

            return {
                  r: parseInt(hex.slice(0, 2), 16),
                  g: parseInt(hex.slice(2, 4), 16),
                  b: parseInt(hex.slice(4, 6), 16)
            };
      }

      function toHexColor(color) {
            return "#" + [color.r, color.g, color.b]
                  .map(channel =>
                        Math.round(Math.max(0, Math.min(255, channel)))
                              .toString(16)
                              .padStart(2, "0")
                  )
                  .join("");
      }

      // مزج لونين: النسبة 0 = الأول، و1 = الثاني
      function mixColors(first, second, ratio) {
            const a = parseHexColor(first);
            const b = parseHexColor(second);

            return toHexColor({
                  r: a.r + (b.r - a.r) * ratio,
                  g: a.g + (b.g - a.g) * ratio,
                  b: a.b + (b.b - a.b) * ratio
            });
      }

      function getColorLuminance(hex) {
            const color = parseHexColor(hex);

            const linear = channel => {
                  const value = channel / 255;

                  return value <= 0.03928
                        ? value / 12.92
                        : Math.pow((value + 0.055) / 1.055, 2.4);
            };

            return 0.2126 * linear(color.r) +
                  0.7152 * linear(color.g) +
                  0.0722 * linear(color.b);
      }

      function getCurrentTheme() {
            return document.body.classList.contains("light-theme")
                  ? "light"
                  : "dark";
      }

      function loadCustomColors() {
            try {
                  const parsed = JSON.parse(
                        localStorage.getItem(STORAGE_KEYS.colors) || "{}"
                  );

                  const result = {};

                  COLOR_ROLES.forEach(role => {
                        if (parsed && parseHexColor(parsed[role])) {
                              result[role] = String(parsed[role]).toLowerCase();
                        }
                  });

                  return result;
            } catch (error) {
                  return {};
            }
      }

      function saveCustomColors(colors) {
            try {
                  if (Object.keys(colors).length === 0) {
                        localStorage.removeItem(STORAGE_KEYS.colors);
                  } else {
                        localStorage.setItem(
                              STORAGE_KEYS.colors,
                              JSON.stringify(colors)
                        );
                  }

                  return true;
            } catch (error) {
                  showToast("تعذر حفظ الألوان على هذا الجهاز.");
                  return false;
            }
      }

      function getEffectiveColors() {
            const base = THEME_COLORS[getCurrentTheme()];
            const custom = loadCustomColors();

            return {
                  accent: custom.accent || base.accent,
                  background: custom.background || base.background,
                  surface: custom.surface || base.surface,
                  text: custom.text || base.text
            };
      }

      // يطبّق الألوان المخصصة فوق ألوان المظهر، ويشتق الألوان المرتبطة بها
      function applyCustomColors() {
            const body = document.body;

            CUSTOM_COLOR_VARS.forEach(name => body.style.removeProperty(name));

            const custom = loadCustomColors();
            const colors = getEffectiveColors();

            if (custom.accent) {
                  const rgb = parseHexColor(colors.accent);

                  body.style.setProperty("--accent", colors.accent);
                  body.style.setProperty(
                        "--accent-hover",
                        mixColors(colors.accent, "#000000", 0.18)
                  );
                  body.style.setProperty(
                        "--accent-soft",
                        `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.14)`
                  );
                  body.style.setProperty(
                        "--on-accent",
                        getColorLuminance(colors.accent) > 0.5 ? "#1a1a1a" : "#ffffff"
                  );
            }

            if (custom.background || custom.surface || custom.text) {
                  if (custom.background) {
                        body.style.setProperty("--background", colors.background);
                  }

                  if (custom.surface) {
                        body.style.setProperty("--surface", colors.surface);
                  }

                  if (custom.text) {
                        body.style.setProperty("--text-primary", colors.text);
                  }

                  body.style.setProperty(
                        "--surface-hover",
                        mixColors(colors.surface, colors.text, 0.05)
                  );
                  body.style.setProperty(
                        "--border",
                        mixColors(colors.background, colors.text, 0.125)
                  );
                  body.style.setProperty(
                        "--text-secondary",
                        mixColors(colors.text, colors.background, 0.36)
                  );
            }

            const meta = document.querySelector('meta[name="theme-color"]');

            if (meta) meta.setAttribute("content", colors.background);

            document.documentElement.style.colorScheme = custom.background
                  ? (getColorLuminance(colors.background) < 0.4 ? "dark" : "light")
                  : getCurrentTheme();
      }

      function updateColorControls() {
            const colors = getEffectiveColors();

            mainContent.querySelectorAll("[data-color-role]").forEach(input => {
                  input.value = colors[input.dataset.colorRole];
            });

            mainContent.querySelectorAll("[data-accent-preset]").forEach(button => {
                  const selected = button.dataset.accentPreset === colors.accent;

                  button.classList.toggle("is-selected", selected);
                  button.setAttribute("aria-pressed", String(selected));
            });

            mainContent.querySelectorAll("[data-bg-preset]").forEach(button => {
                  const [background, surface, text] = button.dataset.bgPreset.split("|");

                  const selected = background === colors.background &&
                        surface === colors.surface &&
                        text === colors.text;

                  button.classList.toggle("is-selected", selected);
                  button.setAttribute("aria-pressed", String(selected));
            });
      }

      function setCustomColors(changes) {
            const colors = loadCustomColors();

            COLOR_ROLES.forEach(role => {
                  if (changes[role] && parseHexColor(changes[role])) {
                        colors[role] = String(changes[role]).toLowerCase();
                  }
            });

            if (!saveCustomColors(colors)) return;

            applyCustomColors();
            updateColorControls();
      }

      function resetCustomColors() {
            if (!saveCustomColors({})) return;

            applyCustomColors();
            updateColorControls();
            showToast("تمت إعادة الألوان الافتراضية للمظهر.");
      }

      function bindColorControls() {
            mainContent.querySelectorAll("[data-color-role]").forEach(input => {
                  input.addEventListener("input", () => {
                        setCustomColors({ [input.dataset.colorRole]: input.value });
                  });
            });

            mainContent.querySelectorAll("[data-accent-preset]").forEach(button => {
                  button.addEventListener("click", () => {
                        setCustomColors({ accent: button.dataset.accentPreset });
                  });
            });

            mainContent.querySelectorAll("[data-bg-preset]").forEach(button => {
                  button.addEventListener("click", () => {
                        const [background, surface, text] =
                              button.dataset.bgPreset.split("|");

                        setCustomColors({ background, surface, text });
                  });
            });
      }

      // ===== ترتيب مقاطع القائمة =====

      function getPlaylistOrder(playlist) {
            const ids = (Array.isArray(playlist.videoIds) ? playlist.videoIds : [])
                  .filter(findVideo);

            if (playlist.sortMode === "added-desc") {
                  return [...ids].reverse();
            }

            if (playlist.sortMode === "manual") {
                  const inList = new Set(ids);

                  const manual = (Array.isArray(playlist.manualOrder)
                        ? playlist.manualOrder
                        : []
                  ).filter((id, index, all) =>
                        inList.has(id) && all.indexOf(id) === index
                  );

                  const rest = ids.filter(id => !manual.includes(id));

                  return [...manual, ...rest];
            }

            return ids;
      }

      function getSortModeLabel(mode) {
            switch (mode) {
                  case "added-desc":
                        return "الأحدث إضافةً أولًا";
                  case "manual":
                        return "ترتيب يدوي";
                  default:
                        return "الأقدم إضافةً أولًا";
            }
      }

      function setPlaylistSortMode(playlistId, mode) {
            const playlist = appData.playlists.find(item => item.id === playlistId);

            if (!playlist || !["added-asc", "added-desc", "manual"].includes(mode)) {
                  return false;
            }

            const backup = {
                  sortMode: playlist.sortMode,
                  manualOrder: Array.isArray(playlist.manualOrder)
                        ? [...playlist.manualOrder]
                        : undefined
            };

            // عند أول تفعيل للترتيب اليدوي نبدأ من الترتيب الظاهر حاليًا
            if (mode === "manual" && !Array.isArray(playlist.manualOrder)) {
                  playlist.manualOrder = getPlaylistOrder(playlist);
            }

            playlist.sortMode = mode;

            if (!saveAppData()) {
                  playlist.sortMode = backup.sortMode;
                  playlist.manualOrder = backup.manualOrder;
                  return false;
            }

            return true;
      }

      function moveVideoInPlaylist(playlistId, videoId, direction) {
            const playlist = appData.playlists.find(item => item.id === playlistId);

            if (!playlist || playlist.sortMode !== "manual") return;

            const order = getPlaylistOrder(playlist);
            const index = order.indexOf(videoId);
            const target = direction === "up" ? index - 1 : index + 1;

            if (index < 0 || target < 0 || target >= order.length) return;

            const backup = Array.isArray(playlist.manualOrder)
                  ? [...playlist.manualOrder]
                  : undefined;

            [order[index], order[target]] = [order[target], order[index]];
            playlist.manualOrder = order;

            if (!saveAppData()) {
                  playlist.manualOrder = backup;
                  return;
            }

            const scrollY = window.scrollY;
            openPlaylist(playlistId);
            window.scrollTo(0, scrollY);
      }

      function openSortModal(playlistId) {
            closeModal();

            const playlist = appData.playlists.find(item => item.id === playlistId);

            if (!playlist) return;

            const current = playlist.sortMode || "added-asc";
            const modes = ["added-asc", "added-desc", "manual"];

            const modal = document.createElement("div");
            modal.id = "mushahid-modal";
            modal.className = "modal-backdrop";

            modal.innerHTML = `
        <div class="modal-card" role="dialog"
             aria-modal="true" aria-labelledby="sort-title">

            <div class="modal-heading">
                <h2 id="sort-title">ترتيب المقاطع</h2>
                <button type="button" class="modal-close"
                        data-action="close-modal"
                        aria-label="إغلاق">×</button>
            </div>

            ${modes.map(mode => `
                <button type="button"
                    class="sort-option${mode === current ? " is-selected" : ""}"
                    data-action="set-sort-mode"
                    data-id="${escapeHTML(playlist.id)}"
                    data-mode="${mode}">
                    <span>${getSortModeLabel(mode)}</span>
                    <span>${mode === current ? "✓" : ""}</span>
                </button>
            `).join("")}

            <p class="welcome-description">
                في الترتيب اليدوي تظهر أسهم على كل مقطع لتحريكه للأعلى أو للأسفل.
            </p>
        </div>
    `;

            document.body.appendChild(modal);

            modal.addEventListener("click", event => {
                  if (event.target === modal) closeModal();
            });
      }

      // ===== بيانات المشاهدة: تقدّم، مشاهَد، علامات، مشاهدة لاحقًا =====

      const SPEED_STEPS = [0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

      // مقاطع «شاهد مباشرة» غير المحفوظة تبقى في الذاكرة فقط
      const watchTemp = {};

      function isLibraryVideo(videoId) {
            return appData.videos.some(item => item.id === videoId);
      }

      function findVideo(videoId) {
            return appData.videos.find(item => item.id === videoId) ||
                  watchTemp[videoId] ||
                  null;
      }

      function isWatchPageActive() {
            return currentPage === "watch" || currentPage === "direct-watch";
      }

      function formatTime(totalSeconds) {
            const seconds = Math.max(0, Math.floor(Number(totalSeconds) || 0));
            const hours = Math.floor(seconds / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            const rest = seconds % 60;
            const pad = value => String(value).padStart(2, "0");

            return hours > 0
                  ? `${hours}:${pad(minutes)}:${pad(rest)}`
                  : `${minutes}:${pad(rest)}`;
      }

      // يعدّل بيانات المشاهدة ويحفظها، ويستعيد النسخة السابقة إذا فشل الحفظ
      function updateWatchData(mutator, silent = false) {
            const backup = JSON.stringify(appData.watch);

            mutator(appData.watch);

            if (!saveAppData(silent)) {
                  appData.watch = normalizeWatchData(JSON.parse(backup));
                  return false;
            }

            return true;
      }

      function getVideoProgress(videoId) {
            const entry = appData.watch.progress[videoId];

            return entry && typeof entry.time === "number" ? entry : null;
      }

      function isVideoWatched(videoId) {
            return Boolean(appData.watch.watched[videoId]);
      }

      function isInWatchLater(videoId) {
            return appData.watch.watchLater.includes(videoId);
      }

      // الثانية التي يبدأ منها التشغيل عند فتح المقطع (0 = من البداية)
      function getResumeSeconds(videoId) {
            if (isVideoWatched(videoId)) return 0;

            const progress = getVideoProgress(videoId);

            if (!progress || progress.time < 5) return 0;

            if (progress.duration && progress.time >= progress.duration - 10) {
                  return 0;
            }

            return Math.floor(progress.time);
      }

      function getProgressPercent(videoId) {
            const progress = getVideoProgress(videoId);

            if (!progress || !progress.duration || isVideoWatched(videoId)) {
                  return 0;
            }

            return Math.max(
                  0,
                  Math.min(100, Math.round((progress.time / progress.duration) * 100))
            );
      }

      function renderProgressLine(videoId) {
            const percent = getProgressPercent(videoId);

            return `<div class="progress-line${percent ? " has-progress" : ""}"><span style="width:${percent}%"></span></div>`;
      }

      function getVideoStatusText(videoId) {
            if (isVideoWatched(videoId)) return "✓ تمت المشاهدة";

            const resume = getResumeSeconds(videoId);

            if (resume > 0) return `▶ تابع من ${formatTime(resume)}`;

            return "مشاهدة داخل التطبيق ▶";
      }

      function getContinueWatchingVideos() {
            return Object.entries(appData.watch.progress)
                  .filter(([videoId, entry]) =>
                        entry && getResumeSeconds(videoId) > 0
                  )
                  .sort((a, b) => (b[1].updatedAt || 0) - (a[1].updatedAt || 0))
                  .map(([videoId]) => findVideo(videoId))
                  .filter(Boolean);
      }

      function getVideoNotes(videoId) {
            const list = appData.watch.notes[videoId];

            return Array.isArray(list) ? list : [];
      }

      // بطاقات المقاطع في قسمي «المشاهدة لاحقًا» و«متابعة المشاهدة»
      function renderSectionVideoCards(sectionKey, limit) {
            const allVideos = sectionKey === "watch-later"
                  ? appData.watch.watchLater.map(findVideo).filter(Boolean)
                  : getContinueWatchingVideos();

            const videos = limit ? allVideos.slice(0, limit) : allVideos;

            if (videos.length === 0) return "";

            return `
            <div class="section-video-list">
                ${videos.map(video => `
                    <div class="section-video-card">
                        <a class="section-video-link"
                           href="#"
                           data-action="watch-video"
                           data-video-id="${escapeHTML(video.id)}"
                           data-section="${sectionKey}">
                            <img class="section-video-thumb"
                                 src="${escapeHTML(video.thumbnail)}"
                                 alt="" loading="lazy">
                            <div class="section-video-info">
                                <h4>${escapeHTML(video.title)}</h4>
                                <p>${getVideoStatusText(video.id)}</p>
                                ${getProgressPercent(video.id) ? renderProgressLine(video.id) : ""}
                            </div>
                        </a>

                        <button class="section-video-action"
                            data-action="${sectionKey === "watch-later" ? "toggle-watch-later" : "toggle-watched"}"
                            data-video-id="${escapeHTML(video.id)}">
                            ${sectionKey === "watch-later" ? "إزالة" : "تمت مشاهدته"}
                        </button>
                    </div>
                `).join("")}
            </div>
        `;
      }

      // تحديث الصفحة الحالية بعد تغيير حالة مقطع (مع حفظ موضع التمرير)
      function refreshAfterWatchChange() {
            if (isWatchPageActive()) {
                  renderWatchMeta();
                  return;
            }

            const scrollY = window.scrollY;

            if (currentPage === "playlist-detail" && activePlaylistId) {
                  openPlaylist(activePlaylistId);
                  window.scrollTo(0, scrollY);
                  return;
            }

            if (currentPage === "watch-later" || currentPage === "continue-watching") {
                  renderSection(currentPage);
                  window.scrollTo(0, scrollY);
            }
      }

      function toggleWatchLater(videoId) {
            if (!isLibraryVideo(videoId)) {
                  showToast("لم يتم العثور على المقطع.");
                  return;
            }

            const adding = !isInWatchLater(videoId);

            const saved = updateWatchData(watch => {
                  if (adding) {
                        watch.watchLater.push(videoId);
                  } else {
                        watch.watchLater = watch.watchLater.filter(
                              id => id !== videoId
                        );
                  }
            });

            if (!saved) return;

            showToast(
                  adding
                        ? "أُضيف المقطع إلى المشاهدة لاحقًا."
                        : "أُزيل المقطع من المشاهدة لاحقًا."
            );
            refreshAfterWatchChange();
      }

      function setVideoWatched(videoId, watched, silent = false) {
            return updateWatchData(watch => {
                  if (watched) {
                        watch.watched[videoId] = true;
                        delete watch.progress[videoId];
                  } else {
                        delete watch.watched[videoId];
                  }
            }, silent);
      }

      function toggleWatched(videoId) {
            if (!isLibraryVideo(videoId)) {
                  showToast("لم يتم العثور على المقطع.");
                  return;
            }

            const watched = !isVideoWatched(videoId);

            if (!setVideoWatched(videoId, watched)) return;

            showToast(
                  watched
                        ? "تم تحديد المقطع كمشاهَد."
                        : "أُلغيت علامة المشاهدة."
            );
            refreshAfterWatchChange();
      }

      // حفظ موضع المشاهدة؛ ويُحدَّد المقطع كمشاهَد عند بلوغ 95%
      function saveWatchProgress(videoId, time, duration) {
            if (!videoId || !isLibraryVideo(videoId) || !(duration > 0) || !(time >= 0)) return;

            if (time >= duration * 0.95) {
                  if (!isVideoWatched(videoId)) {
                        setVideoWatched(videoId, true, true);

                        if (isWatchPageActive() && watchState &&
                              watchState.videoId === videoId) {
                              renderWatchMeta();
                        }
                  }
                  return;
            }

            if (time < 5) return;

            updateWatchData(watch => {
                  watch.progress[videoId] = {
                        time: Math.floor(time),
                        duration: Math.floor(duration),
                        updatedAt: Date.now()
                  };
            }, true);
      }

      function addWatchNote(videoId, time, text) {
            const note = {
                  id: createId(),
                  time: Math.max(0, Math.floor(time)),
                  text: text.trim() || "علامة",
                  createdAt: new Date().toISOString()
            };

            const saved = updateWatchData(watch => {
                  const list = Array.isArray(watch.notes[videoId])
                        ? watch.notes[videoId]
                        : [];

                  list.push(note);
                  list.sort((a, b) => a.time - b.time);
                  watch.notes[videoId] = list;
            });

            if (saved) {
                  showToast(`تمت إضافة العلامة عند ${formatTime(note.time)}.`);
                  renderWatchMeta();
            }

            return saved;
      }

      function deleteWatchNote(videoId, noteId) {
            const saved = updateWatchData(watch => {
                  const list = Array.isArray(watch.notes[videoId])
                        ? watch.notes[videoId]
                        : [];

                  const remaining = list.filter(item => item.id !== noteId);

                  if (remaining.length > 0) {
                        watch.notes[videoId] = remaining;
                  } else {
                        delete watch.notes[videoId];
                  }
            });

            if (saved) {
                  showToast("تم حذف العلامة.");
                  renderWatchMeta();
            }
      }

      function openAddNoteModal(videoId, time) {
            closeModal();

            const modal = document.createElement("div");
            modal.id = "mushahid-modal";
            modal.className = "modal-backdrop";

            modal.innerHTML = `
        <div class="modal-card" role="dialog"
             aria-modal="true" aria-labelledby="watch-note-title">

            <div class="modal-heading">
                <h2 id="watch-note-title">علامة عند ${formatTime(time)}</h2>
                <button type="button" class="modal-close"
                        data-action="close-modal"
                        aria-label="إغلاق">×</button>
            </div>

            <label class="field-label" for="watch-note-text">
                ملاحظة (اختياري)
            </label>
            <input class="text-field" id="watch-note-text" type="text"
                   maxlength="140" placeholder="مثال: شرح الفكرة الأساسية">

            <div class="modal-actions">
                <button type="button" class="secondary-button"
                        data-action="close-modal">
                    إلغاء
                </button>

                <button type="button" class="primary-button"
                        id="watch-note-save">
                    حفظ العلامة
                </button>
            </div>
        </div>
    `;

            document.body.appendChild(modal);

            const input = modal.querySelector("#watch-note-text");

            function saveNote() {
                  if (addWatchNote(videoId, time, input.value)) {
                        closeModal();
                  }
            }

            modal.querySelector("#watch-note-save")
                  .addEventListener("click", saveNote);

            input.addEventListener("keydown", event => {
                  if (event.key === "Enter") {
                        event.preventDefault();
                        saveNote();
                  }
            });

            modal.addEventListener("click", event => {
                  if (event.target === modal) closeModal();
            });

            input.focus();
      }

      // ===== صفحة المشاهدة داخل التطبيق =====

      let watchPlayer = null;
      let watchToken = 0;
      let watchTimer = null;
      let watchTicker = null;
      let watchState = null;
      let watchFullscreenHandler = null;
      let youTubeApiPromise = null;

      // تحميل واجهة مشغّل يوتيوب (تحتاج إنترنت)
      function loadYouTubeApi() {
            if (window.YT && window.YT.Player) {
                  return Promise.resolve();
            }

            if (youTubeApiPromise) return youTubeApiPromise;

            youTubeApiPromise = new Promise((resolve, reject) => {
                  const previousCallback = window.onYouTubeIframeAPIReady;
                  const script = document.createElement("script");

                  const timeout = setTimeout(() => {
                        youTubeApiPromise = null;
                        reject(new Error("youtube-api-timeout"));
                  }, 12000);

                  window.onYouTubeIframeAPIReady = () => {
                        clearTimeout(timeout);

                        if (typeof previousCallback === "function") {
                              previousCallback();
                        }

                        resolve();
                  };

                  script.src = "https://www.youtube.com/iframe_api";
                  script.async = true;

                  script.onerror = () => {
                        clearTimeout(timeout);
                        youTubeApiPromise = null;
                        script.remove();
                        reject(new Error("youtube-api-load-failed"));
                  };

                  document.head.appendChild(script);
            });

            return youTubeApiPromise;
      }

      function readWatchPosition() {
            if (!watchPlayer || typeof watchPlayer.getCurrentTime !== "function") {
                  return null;
            }

            try {
                  return {
                        time: Number(watchPlayer.getCurrentTime()) || 0,
                        duration: Number(watchPlayer.getDuration()) || 0
                  };
            } catch (error) {
                  return null;
            }
      }

      // يضيف وقت التشغيل المتراكم إلى إحصائيات اليوم
      function flushWatchTime() {
            if (!watchState) return;

            const seconds = Math.floor(watchState.pendingSeconds || 0);

            if (seconds < 1) return;

            watchState.pendingSeconds -= seconds;

            const key = getLocalDateKey();

            updateWatchData(watch => {
                  watch.stats.daily[key] =
                        (Number(watch.stats.daily[key]) || 0) + seconds;
            }, true);
      }

      function persistWatchProgress() {
            if (!watchState) return;

            flushWatchTime();

            const position = readWatchPosition();

            if (!position) return;

            watchState.lastSave = Date.now();
            saveWatchProgress(watchState.videoId, position.time, position.duration);
      }

      function leaveWatchPage() {
            if (currentPage === "watch" || watchPlayer) {
                  destroyWatchPlayer();
            }
      }

      function destroyWatchPlayer() {
            persistWatchProgress();

            watchToken++;
            clearTimeout(watchTimer);
            clearInterval(watchTicker);
            watchTimer = null;
            watchTicker = null;

            if (watchFullscreenHandler) {
                  document.removeEventListener("fullscreenchange", watchFullscreenHandler);
                  document.removeEventListener("webkitfullscreenchange", watchFullscreenHandler);
                  watchFullscreenHandler = null;
            }

            if (watchPopHandler) {
                  window.removeEventListener("popstate", watchPopHandler);
                  watchPopHandler = null;
            }

            watchFsHistoryPushed = false;

            if (document.fullscreenElement && document.exitFullscreen) {
                  try {
                        document.exitFullscreen();
                  } catch (error) {
                        console.warn("تعذر الخروج من ملء الشاشة:", error);
                  }
            }

            document.body.classList.remove("watch-pseudo-fullscreen");

            try {
                  if (screen.orientation && typeof screen.orientation.unlock === "function") {
                        screen.orientation.unlock();
                  }
            } catch (error) {
                  // بعض البيئات لا تدعم فك قفل الاتجاه
            }

            if (watchPlayer && typeof watchPlayer.destroy === "function") {
                  try {
                        watchPlayer.destroy();
                  } catch (error) {
                        console.warn("تعذر إغلاق المشغّل:", error);
                  }
            }

            watchPlayer = null;
            watchState = null;
      }

      function setWatchStatus(message, isError = false) {
            const statusElement = document.getElementById("watch-status");

            if (!statusElement) return;

            statusElement.textContent = message;
            statusElement.hidden = !message;
            statusElement.classList.toggle("is-error", Boolean(isError));
      }

      function getYouTubeErrorMessage(code) {
            switch (code) {
                  case 2:
                        return "رابط المقطع غير صالح، فلا يمكن تشغيله.";
                  case 5:
                        return "تعذر تشغيل هذا المقطع داخل المشغّل المضمّن.";
                  case 100:
                        return "المقطع غير متاح، ربما حُذف أو أصبح خاصًا.";
                  case 101:
                  case 150:
                        return "صاحب المقطع لا يسمح بتشغيله خارج يوتيوب، لذلك لا يمكن تشغيله هنا.";
                  case 153:
                        return "تعذر تشغيل المقطع داخل التطبيق بسبب طريقة تشغيل الصفحة (مثل فتح الملف مباشرة من الجهاز).";
                  default:
                        return "حدث خطأ أثناء تشغيل المقطع.";
            }
      }

      function ensureWatchReady() {
            if (!watchPlayer || !watchState || !watchState.ready) {
                  showToast("المشغّل لم يجهز بعد، انتظر لحظة.");
                  return false;
            }

            return true;
      }

      // ---- تحديث واجهة أزرار التحكم ----

      function setPlayButtonState(isPlaying) {
            const button = document.getElementById("watch-toggle");

            if (!button) return;

            button.classList.toggle("is-playing", isPlaying);
            button.setAttribute("aria-label", isPlaying ? "إيقاف مؤقت" : "تشغيل");
      }

      function updateSeekUI(time, duration) {
            const currentLabel = document.getElementById("watch-time-current");
            const totalLabel = document.getElementById("watch-time-total");
            const slider = document.getElementById("watch-seek");

            if (currentLabel) currentLabel.textContent = formatTime(time);
            if (totalLabel) totalLabel.textContent = formatTime(duration);

            if (slider && watchState && !watchState.seeking) {
                  slider.value = duration > 0
                        ? Math.round((time / duration) * 1000)
                        : 0;
            }
      }

      function setToolLabel(button, text) {
            const label = button ? button.querySelector("span") : null;

            if (label) label.textContent = text;
      }

      function updateWatchControls() {
            if (!watchState) return;

            const settings = appData.watch.settings;
            const find = name => document.querySelector(`[data-watch="${name}"]`);
            const videoId = watchState.videoId;
            const inLibrary = isLibraryVideo(videoId);

            const speedButton = find("speed");
            const loopButton = find("loop");
            const autoNextButton = find("autonext");
            const noteButton = find("note");
            const laterButton = find("later");
            const watchedButton = find("watched");
            const prevButton = find("prev");
            const nextButton = find("next");

            setToolLabel(speedButton, `السرعة ${settings.speed}×`);

            if (loopButton) {
                  loopButton.classList.toggle("is-active", watchState.loop);
                  loopButton.setAttribute("aria-pressed", String(watchState.loop));
            }

            if (autoNextButton) {
                  autoNextButton.classList.toggle("is-active", settings.autoNext);
                  autoNextButton.setAttribute("aria-pressed", String(settings.autoNext));
            }

            // أزرار المكتبة لا تظهر لمقطع «شاهد مباشرة» غير المحفوظ
            if (noteButton) noteButton.hidden = !inLibrary;
            if (laterButton) laterButton.hidden = !inLibrary;
            if (watchedButton) watchedButton.hidden = !inLibrary;

            setToolLabel(
                  laterButton,
                  isInWatchLater(videoId)
                        ? "إزالة من المشاهدة لاحقًا"
                        : "إضافة إلى المشاهدة لاحقًا"
            );

            setToolLabel(
                  watchedButton,
                  isVideoWatched(videoId)
                        ? "إلغاء علامة المشاهدة"
                        : "تحديد كمشاهَد"
            );

            // «السابق» ينتقل للمقطع الذي أسفل، و«التالي» للمقطع الذي أعلى
            if (prevButton) prevButton.disabled = !getAdjacentVideoId(1);
            if (nextButton) nextButton.disabled = !getAdjacentVideoId(-1);
      }

      // العنوان والإجراءات والعلامات (تُعاد كتابتها عند تغيّر المقطع)
      function renderWatchMeta() {
            if (!watchState) return;

            const video = findVideo(watchState.videoId);
            const metaElement = document.getElementById("watch-meta");
            const titleElement = document.getElementById("watch-title");
            const positionElement = document.getElementById("watch-position");

            if (!video || !metaElement || !titleElement || !positionElement) return;

            titleElement.textContent = video.title;

            const queueLength = watchState.queue.length;
            const index = watchState.queue.indexOf(video.id);

            if (watchState.direct) {
                  positionElement.textContent = "شاهد مباشرة";
            } else {
                  positionElement.textContent = queueLength > 1 && index >= 0
                        ? `مشاهدة · المقطع ${index + 1} من ${queueLength}`
                        : "مشاهدة";
            }

            if (!isLibraryVideo(video.id)) {
                  metaElement.innerHTML = "";
                  updateWatchControls();
                  return;
            }

            const notes = getVideoNotes(video.id);

            metaElement.innerHTML = `
        <section class="watch-notes">
            <h3>العلامات الزمنية</h3>
            ${notes.length > 0 ? `
                <ul class="watch-notes-list">
                    ${notes.map(note => `
                        <li class="watch-note">
                            <button class="watch-note-time"
                                data-action="seek-to-note"
                                data-time="${note.time}">
                                ${formatTime(note.time)}
                            </button>
                            <span class="watch-note-text">${escapeHTML(note.text)}</span>
                            <button class="watch-note-delete"
                                data-action="delete-note"
                                data-video-id="${escapeHTML(video.id)}"
                                data-note-id="${escapeHTML(note.id)}"
                                aria-label="حذف العلامة">×</button>
                        </li>
                    `).join("")}
                </ul>
            ` : `
                <p class="watch-notes-empty">
                    لا توجد علامات بعد. افتح النقاط الثلاث واضغط «علامة زمنية» أثناء المشاهدة.
                </p>
            `}
        </section>
    `;

            updateWatchControls();
      }

      // ---- أوامر التحكم ----

      function togglePlayPause() {
            if (!ensureWatchReady()) return;

            const states = window.YT.PlayerState;
            const state = watchPlayer.getPlayerState();

            if (state === states.PLAYING || state === states.BUFFERING) {
                  watchPlayer.pauseVideo();
            } else {
                  watchPlayer.playVideo();
            }
      }

      function seekToTime(time) {
            if (!ensureWatchReady()) return;

            const duration = Number(watchPlayer.getDuration()) || 0;
            let target = Math.max(0, Number(time) || 0);

            if (duration > 0) target = Math.min(target, duration);

            watchPlayer.seekTo(target, true);
            updateSeekUI(target, duration);
      }

      function seekBy(delta) {
            if (!ensureWatchReady()) return;

            seekToTime((Number(watchPlayer.getCurrentTime()) || 0) + delta);
      }

      function cycleSpeed() {
            if (!ensureWatchReady()) return;

            let available = SPEED_STEPS;

            try {
                  const rates = watchPlayer.getAvailablePlaybackRates();

                  if (Array.isArray(rates) && rates.length > 0) {
                        const filtered = SPEED_STEPS.filter(step => rates.includes(step));

                        if (filtered.length > 0) available = filtered;
                  }
            } catch (error) {
                  console.warn("تعذر قراءة السرعات المتاحة:", error);
            }

            const current = appData.watch.settings.speed;
            const index = available.indexOf(current);

            let next;

            if (index === -1) {
                  next = available.includes(1) ? 1 : available[0];
            } else {
                  next = available[(index + 1) % available.length];
            }

            updateWatchData(watch => {
                  watch.settings.speed = next;
            }, true);

            watchPlayer.setPlaybackRate(next);
            updateWatchControls();
      }

      function toggleLoop() {
            if (!watchState) return;

            watchState.loop = !watchState.loop;
            updateWatchControls();
            showToast(watchState.loop ? "تم تفعيل تكرار المقطع." : "تم إيقاف التكرار.");
      }

      function toggleAutoNext() {
            const enabled = !appData.watch.settings.autoNext;

            updateWatchData(watch => {
                  watch.settings.autoNext = enabled;
            }, true);

            updateWatchControls();
            showToast(
                  enabled
                        ? "سيُشغَّل المقطع التالي تلقائيًا."
                        : "تم إيقاف التشغيل التلقائي للتالي."
            );
      }

      function getAdjacentVideoId(direction) {
            if (!watchState) return null;

            const index = watchState.queue.indexOf(watchState.videoId);

            if (index < 0) return null;

            return watchState.queue[index + direction] || null;
      }

      function goAdjacent(direction, emptyMessage) {
            const target = getAdjacentVideoId(direction);

            if (!target) {
                  showToast(emptyMessage);
                  return;
            }

            loadWatchVideo(target);
      }

      // تحميل مقطع آخر داخل المشغّل نفسه (يعمل تلقائيًا)
      function loadWatchVideo(videoId) {
            if (!ensureWatchReady()) return;

            const video = findVideo(videoId);

            if (!video) {
                  showToast("لم يتم العثور على المقطع.");
                  return;
            }

            persistWatchProgress();

            watchState.videoId = videoId;
            watchState.lastSave = 0;

            clearTimeout(watchTimer);
            setWatchStatus("");

            try {
                  watchPlayer.loadVideoById({
                        videoId,
                        startSeconds: getResumeSeconds(videoId)
                  });
            } catch (error) {
                  console.error("تعذر تحميل المقطع:", error);
                  setWatchStatus("تعذر تحميل المقطع داخل المشغّل.", true);
                  return;
            }

            updateSeekUI(0, 0);
            renderWatchMeta();
      }

      function handleWatchEnded() {
            if (!watchState) return;

            if (isLibraryVideo(watchState.videoId)) {
                  setVideoWatched(watchState.videoId, true, true);
            }

            renderWatchMeta();

            if (watchState.loop) {
                  watchPlayer.seekTo(0, true);
                  watchPlayer.playVideo();
                  return;
            }

            if (appData.watch.settings.autoNext) {
                  const next = getAdjacentVideoId(1);

                  if (next) loadWatchVideo(next);
            }
      }

      function applyDesiredSpeed() {
            if (!watchPlayer || typeof watchPlayer.setPlaybackRate !== "function") return;

            const wanted = appData.watch.settings.speed;

            try {
                  if (watchPlayer.getPlaybackRate() !== wanted) {
                        watchPlayer.setPlaybackRate(wanted);
                  }
            } catch (error) {
                  console.warn("تعذر ضبط السرعة:", error);
            }
      }

      function handleWatchStateChange(event) {
            if (!watchState || !window.YT) return;

            const states = window.YT.PlayerState;
            const state = event.data;

            setPlayButtonState(
                  state === states.PLAYING || state === states.BUFFERING
            );

            if (state === states.PLAYING) {
                  applyDesiredSpeed();
            } else if (state === states.PAUSED) {
                  persistWatchProgress();
            } else if (state === states.ENDED) {
                  handleWatchEnded();
            }
      }

      function tickWatch() {
            if (!document.getElementById("watch-stage")) {
                  destroyWatchPlayer();
                  return;
            }

            if (!watchState || !watchState.ready) return;

            const position = readWatchPosition();

            if (!position) return;

            updateSeekUI(position.time, position.duration);

            let state = null;

            try {
                  state = watchPlayer.getPlayerState();
            } catch (error) {
                  return;
            }

            const now = Date.now();

            if (state === 1) {
                  const elapsed = watchState.lastTick
                        ? Math.min(2, (now - watchState.lastTick) / 1000)
                        : 0;

                  watchState.pendingSeconds =
                        (watchState.pendingSeconds || 0) + elapsed;

                  if (now - watchState.lastSave >= 5000) {
                        persistWatchProgress();
                  }
            }

            watchState.lastTick = now;
      }

      // ---- ملء الشاشة (الأفقي، بلا أزرار) ----

      let watchFsHistoryPushed = false;
      let watchPopHandler = null;

      function isWatchFullscreen() {
            const stage = document.getElementById("watch-stage");

            if (!stage) return false;

            return document.fullscreenElement === stage ||
                  document.webkitFullscreenElement === stage ||
                  stage.classList.contains("is-pseudo-fullscreen");
      }

      // زر الرجوع في الجهاز يخرج من ملء الشاشة بفضل إدخال في سجل التنقل
      function pushWatchFullscreenHistory() {
            try {
                  history.pushState({ mushahidFullscreen: true }, "");
                  watchFsHistoryPushed = true;
            } catch (error) {
                  watchFsHistoryPushed = false;
            }
      }

      function releaseWatchFullscreenHistory() {
            if (!watchFsHistoryPushed) return;

            watchFsHistoryPushed = false;

            try {
                  history.back();
            } catch (error) {
                  // لا شيء
            }
      }

      async function enterWatchFullscreen() {
            const stage = document.getElementById("watch-stage");

            if (!stage) return;

            let usedNative = false;

            try {
                  if (stage.requestFullscreen) {
                        await stage.requestFullscreen();
                        usedNative = true;
                  } else if (stage.webkitRequestFullscreen) {
                        stage.webkitRequestFullscreen();
                        usedNative = true;
                  }
            } catch (error) {
                  usedNative = false;
            }

            let orientationLocked = false;

            try {
                  if (screen.orientation && typeof screen.orientation.lock === "function") {
                        await screen.orientation.lock("landscape");
                        orientationLocked = true;
                  }
            } catch (error) {
                  orientationLocked = false;
            }

            const isPortrait = window.innerHeight > window.innerWidth;

            // إن تعذّر قفل الاتجاه الأفقي والشاشة عمودية، نستخدم الوضع الاحتياطي
            // الذي يدوّر المشغّل بالـ CSS ليملأ الشاشة على العرض
            if (usedNative && !orientationLocked && isPortrait) {
                  try {
                        if (document.exitFullscreen && document.fullscreenElement) {
                              await document.exitFullscreen();
                        } else if (document.webkitExitFullscreen && document.webkitFullscreenElement) {
                              document.webkitExitFullscreen();
                        }
                  } catch (error) {
                        console.warn("تعذر الخروج من ملء الشاشة:", error);
                  }

                  usedNative = false;
            }

            if (!usedNative) {
                  stage.classList.add("is-pseudo-fullscreen");
                  document.body.classList.add("watch-pseudo-fullscreen");
            }

            pushWatchFullscreenHistory();
            updateWatchControls();
      }

      async function exitWatchFullscreen(fromHistory = false) {
            const stage = document.getElementById("watch-stage");

            if (document.fullscreenElement || document.webkitFullscreenElement) {
                  try {
                        if (document.exitFullscreen) {
                              await document.exitFullscreen();
                        } else if (document.webkitExitFullscreen) {
                              document.webkitExitFullscreen();
                        }
                  } catch (error) {
                        console.warn("تعذر الخروج من ملء الشاشة:", error);
                  }
            }

            if (stage) stage.classList.remove("is-pseudo-fullscreen");
            document.body.classList.remove("watch-pseudo-fullscreen");

            try {
                  if (screen.orientation && typeof screen.orientation.unlock === "function") {
                        screen.orientation.unlock();
                  }
            } catch (error) {
                  // لا شيء
            }

            if (!fromHistory) releaseWatchFullscreenHistory();

            updateWatchControls();
      }

      function toggleWatchFullscreen() {
            if (isWatchFullscreen()) {
                  exitWatchFullscreen();
            } else {
                  enterWatchFullscreen();
            }
      }

      async function openAddNoteFlow() {
            if (!ensureWatchReady()) return;

            let time = 0;

            try {
                  time = Math.floor(Number(watchPlayer.getCurrentTime()) || 0);
            } catch (error) {
                  time = 0;
            }

            // النافذة لا تظهر فوق ملء الشاشة، لذلك نخرج منه أولًا
            if (isWatchFullscreen()) await exitWatchFullscreen();

            openAddNoteModal(watchState.videoId, time);
      }

      function toggleWatchMore() {
            const panel = document.getElementById("watch-more");
            const button = document.querySelector('[data-watch="more"]');

            if (!panel) return;

            panel.hidden = !panel.hidden;

            if (button) {
                  button.classList.toggle("is-active", !panel.hidden);
                  button.setAttribute("aria-expanded", String(!panel.hidden));
            }
      }

      function handleWatchControl(action) {
            switch (action) {
                  case "toggle":
                        togglePlayPause();
                        break;
                  case "back10":
                        seekBy(-10);
                        break;
                  case "fwd10":
                        seekBy(10);
                        break;
                  case "prev":
                        // السابق = المقطع الذي أسفل في القائمة
                        goAdjacent(1, "لا يوجد مقطع سابق.");
                        break;
                  case "next":
                        // التالي = المقطع الذي أعلى في القائمة
                        goAdjacent(-1, "لا يوجد مقطع تالٍ.");
                        break;
                  case "speed":
                        cycleSpeed();
                        break;
                  case "loop":
                        toggleLoop();
                        break;
                  case "autonext":
                        toggleAutoNext();
                        break;
                  case "note":
                        openAddNoteFlow();
                        break;
                  case "more":
                        toggleWatchMore();
                        break;
                  case "fullscreen":
                        toggleWatchFullscreen();
                        break;
                  case "copy": {
                        const video = watchState ? findVideo(watchState.videoId) : null;

                        if (video) copyVideoLink(video.url);
                        break;
                  }
                  case "later":
                        if (watchState) toggleWatchLater(watchState.videoId);
                        break;
                  case "watched":
                        if (watchState) toggleWatched(watchState.videoId);
                        break;
            }
      }

      async function startWatchPlayer(videoId) {
            const token = watchToken;

            if (navigator.onLine === false) {
                  setWatchStatus(
                        "لا يوجد اتصال بالإنترنت. تشغيل المقاطع يحتاج إلى اتصال.",
                        true
                  );
                  return;
            }

            try {
                  await loadYouTubeApi();
            } catch (error) {
                  if (token !== watchToken) return;

                  setWatchStatus(
                        "تعذر تحميل مشغّل يوتيوب. تحقق من اتصالك بالإنترنت ثم أعد فتح المقطع.",
                        true
                  );
                  return;
            }

            if (token !== watchToken || !document.getElementById("watch-player")) {
                  return;
            }

            // إن تأخر المشغّل ولم يظهر خطأ، نوضح للمستخدم ما يفعله
            watchTimer = setTimeout(() => {
                  if (token === watchToken) {
                        setWatchStatus(
                              "المشغّل يتأخر في التحميل. تحقق من اتصالك بالإنترنت.",
                              true
                        );
                  }
            }, 12000);

            try {
                  watchPlayer = new window.YT.Player("watch-player", {
                        videoId,
                        width: "100%",
                        height: "100%",
                        playerVars: {
                              controls: 0,
                              disablekb: 1,
                              fs: 0,
                              iv_load_policy: 3,
                              rel: 0,
                              playsinline: 1,
                              modestbranding: 1,
                              start: getResumeSeconds(videoId)
                        },
                        events: {
                              onReady: () => {
                                    if (token !== watchToken || !watchState) return;

                                    clearTimeout(watchTimer);
                                    watchState.ready = true;
                                    setWatchStatus("");
                                    applyDesiredSpeed();

                                    // عنوان المقطع غير المحفوظ يأتي من المشغّل نفسه
                                    if (!isLibraryVideo(watchState.videoId)) {
                                          try {
                                                const data = watchPlayer.getVideoData();
                                                const temp = watchTemp[watchState.videoId];

                                                if (data && data.title && temp) {
                                                      temp.title = data.title;
                                                      renderWatchMeta();
                                                }
                                          } catch (error) {
                                                console.warn("تعذر قراءة عنوان المقطع:", error);
                                          }
                                    }

                                    updateWatchControls();
                              },
                              onStateChange: event => {
                                    if (token === watchToken) {
                                          handleWatchStateChange(event);
                                    }
                              },
                              onError: event => {
                                    if (token !== watchToken) return;

                                    clearTimeout(watchTimer);
                                    setWatchStatus(
                                          getYouTubeErrorMessage(event.data),
                                          true
                                    );
                              }
                        }
                  });
            } catch (error) {
                  console.error("تعذر إنشاء المشغّل:", error);
                  clearTimeout(watchTimer);
                  setWatchStatus(
                        "تعذر تشغيل المقطع داخل التطبيق.",
                        true
                  );
            }
      }

      // options: { playlistId, section } تحدد من أين جاء المستخدم
      // ===== بناء مكوّنات صفحة المشاهدة =====

      function buildWatchStageHTML() {
            return `
        <div class="watch-stage" id="watch-stage">
            <div class="watch-player">
                <div id="watch-player"></div>
            </div>

            <button type="button" class="watch-exit-fs"
                    data-watch="fullscreen" aria-label="إنهاء ملء الشاشة">
                <svg viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/>
                </svg>
            </button>

            <div class="watch-controls">
                <div class="watch-seek">
                    <button type="button" class="watch-icon-btn"
                            data-watch="more" aria-label="المزيد"
                            aria-expanded="false">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <circle cx="5" cy="12" r="2"/>
                            <circle cx="12" cy="12" r="2"/>
                            <circle cx="19" cy="12" r="2"/>
                        </svg>
                    </button>

                    <span class="watch-time" id="watch-time-current">0:00</span>
                    <input type="range" id="watch-seek" min="0" max="1000"
                           value="0" step="1" aria-label="موضع التشغيل">
                    <span class="watch-time" id="watch-time-total">0:00</span>

                    <button type="button" class="watch-icon-btn"
                            id="watch-fullscreen" data-watch="fullscreen"
                            aria-label="ملء الشاشة">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/>
                        </svg>
                    </button>
                </div>

                <div class="watch-transport">
                    <button type="button" class="watch-ctrl" data-watch="prev">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z"/>
                        </svg>
                        <span>السابق</span>
                    </button>

                    <button type="button" class="watch-ctrl" data-watch="back10">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M11.99 5V1l-5 5 5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6h-2c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
                            <text x="12" y="16" text-anchor="middle" font-size="7" font-weight="700" font-family="sans-serif">10</text>
                        </svg>
                        <span>تأخير 10</span>
                    </button>

                    <button type="button" class="watch-play"
                            id="watch-toggle" data-watch="toggle" aria-label="تشغيل">
                        <svg class="icon-play" viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M8 5v14l11-7z"/>
                        </svg>
                        <svg class="icon-pause" viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M6 5h4v14H6zM14 5h4v14h-4z"/>
                        </svg>
                    </button>

                    <button type="button" class="watch-ctrl" data-watch="fwd10">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <g transform="translate(24 0) scale(-1 1)">
                                <path d="M11.99 5V1l-5 5 5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6h-2c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
                            </g>
                            <text x="12" y="16" text-anchor="middle" font-size="7" font-weight="700" font-family="sans-serif">10</text>
                        </svg>
                        <span>تقديم 10</span>
                    </button>

                    <button type="button" class="watch-ctrl" data-watch="next">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/>
                        </svg>
                        <span>التالي</span>
                    </button>
                </div>

                <div class="watch-more" id="watch-more" hidden>
                    <button type="button" class="watch-tool" data-watch="speed">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.38 8.57l-1.23 1.85a8 8 0 0 1-.22 7.58H5.07A8 8 0 0 1 15.58 6.85l1.85-1.23A10 10 0 0 0 3.35 19a2 2 0 0 0 1.72 1h13.85a2 2 0 0 0 1.74-1 10 10 0 0 0-.27-10.44zm-9.79 6.84a2 2 0 0 0 2.83 0l5.66-8.49-8.49 5.66a2 2 0 0 0 0 2.83z"/></svg>
                        <span>السرعة 1×</span>
                    </button>

                    <button type="button" class="watch-tool" data-watch="loop" aria-pressed="false">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z"/></svg>
                        <span>تكرار المقطع</span>
                    </button>

                    <button type="button" class="watch-tool" data-watch="autonext" aria-pressed="true">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 10h12v2H4zm0-4h12v2H4zm0 8h8v2H4zm10 0v6l5-3z"/></svg>
                        <span>التالي تلقائيًا</span>
                    </button>

                    <button type="button" class="watch-tool" data-watch="note">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17 3H7c-1.1 0-2 .9-2 2v16l7-3 7 3V5c0-1.1-.9-2-2-2z"/></svg>
                        <span>علامة زمنية</span>
                    </button>

                    <button type="button" class="watch-tool" data-watch="copy">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.9 12c0-1.71 1.39-3.1 3.1-3.1h4V7H7c-2.76 0-5 2.24-5 5s2.24 5 5 5h4v-1.9H7c-1.71 0-3.1-1.39-3.1-3.1zM8 13h8v-2H8v2zm9-6h-4v1.9h4c1.71 0 3.1 1.39 3.1 3.1s-1.39 3.1-3.1 3.1h-4V17h4c2.76 0 5-2.24 5-5s-2.24-5-5-5z"/></svg>
                        <span>نسخ الرابط</span>
                    </button>

                    <button type="button" class="watch-tool" data-watch="later">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z"/></svg>
                        <span>إضافة إلى المشاهدة لاحقًا</span>
                    </button>

                    <button type="button" class="watch-tool" data-watch="watched">
                        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                        <span>تحديد كمشاهَد</span>
                    </button>
                </div>
            </div>
        </div>

        <p class="watch-status" id="watch-status">جارٍ تحميل المشغّل...</p>

        <div id="watch-meta"></div>
    `;
      }

      // ربط أزرار المشغّل وبدء التشغيل بعد رسم الصفحة
      function mountWatchStage(videoId) {
            const stage = document.getElementById("watch-stage");
            const seekSlider = document.getElementById("watch-seek");

            stage.addEventListener("click", event => {
                  const button = event.target.closest("[data-watch]");

                  if (!button || button.disabled) return;

                  handleWatchControl(button.dataset.watch);
            });

            seekSlider.addEventListener("input", () => {
                  if (!watchState) return;

                  watchState.seeking = true;

                  const duration = watchPlayer && watchState.ready
                        ? Number(watchPlayer.getDuration()) || 0
                        : 0;

                  const label = document.getElementById("watch-time-current");

                  if (label) {
                        label.textContent = formatTime(
                              (Number(seekSlider.value) / 1000) * duration
                        );
                  }
            });

            seekSlider.addEventListener("change", () => {
                  if (!watchState) return;

                  watchState.seeking = false;

                  if (!watchPlayer || !watchState.ready) return;

                  const duration = Number(watchPlayer.getDuration()) || 0;

                  if (duration > 0) {
                        seekToTime((Number(seekSlider.value) / 1000) * duration);
                  }
            });

            watchFullscreenHandler = () => {
                  const activeStage = document.getElementById("watch-stage");

                  if (
                        activeStage &&
                        !document.fullscreenElement &&
                        !document.webkitFullscreenElement &&
                        !activeStage.classList.contains("is-pseudo-fullscreen")
                  ) {
                        try {
                              if (screen.orientation && typeof screen.orientation.unlock === "function") {
                                    screen.orientation.unlock();
                              }
                        } catch (error) {
                              // لا شيء
                        }

                        releaseWatchFullscreenHistory();
                  }

                  updateWatchControls();
            };

            watchPopHandler = () => {
                  // زر الرجوع في الجهاز يخرج من ملء الشاشة
                  if (isWatchFullscreen()) {
                        watchFsHistoryPushed = false;
                        exitWatchFullscreen(true);
                  }
            };

            document.addEventListener("fullscreenchange", watchFullscreenHandler);
            document.addEventListener("webkitfullscreenchange", watchFullscreenHandler);
            window.addEventListener("popstate", watchPopHandler);

            watchTicker = setInterval(tickWatch, 500);

            renderWatchMeta();
            startWatchPlayer(videoId);
      }

      // options: { playlistId, section } تحدد من أين جاء المستخدم
      function openWatchPage(videoId, options = {}) {
            const video = findVideo(videoId);

            if (!video) {
                  showToast("لم يتم العثور على المقطع.");
                  return;
            }

            const playlist = options.playlistId
                  ? appData.playlists.find(item => item.id === options.playlistId)
                  : null;

            const section = options.section === "watch-later" ||
                  options.section === "continue-watching"
                  ? options.section
                  : null;

            destroyWatchPlayer();

            currentPage = "watch";
            setActiveNav(playlist || section ? "playlists" : "home");

            if (playlist) {
                  activePlaylistId = playlist.id;
            }

            // قائمة التشغيل المتتابعة (للسابق والتالي)
            let queue = [video.id];

            if (playlist && Array.isArray(playlist.videoIds)) {
                  queue = getPlaylistOrder(playlist);
            } else if (section === "watch-later") {
                  queue = appData.watch.watchLater.filter(findVideo);
            } else if (section === "continue-watching") {
                  queue = getContinueWatchingVideos().map(item => item.id);
            }

            if (!queue.includes(video.id)) queue = [video.id];

            watchState = {
                  videoId: video.id,
                  queue,
                  ready: false,
                  seeking: false,
                  loop: false,
                  direct: false,
                  lastSave: 0,
                  lastTick: 0,
                  pendingSeconds: 0
            };

            let backButtonHTML = `
            <button class="back-button"
                data-action="open-section"
                data-section="playlists">
                ← العودة إلى القوائم
            </button>`;

            if (playlist) {
                  backButtonHTML = `
            <button class="back-button"
                data-action="back-to-playlist"
                data-id="${escapeHTML(playlist.id)}">
                ← العودة إلى ${escapeHTML(playlist.name)}
            </button>`;
            } else if (section) {
                  backButtonHTML = `
            <button class="back-button"
                data-action="open-section"
                data-section="${section}">
                ← العودة إلى ${SECTIONS[section].title}
            </button>`;
            }

            mainContent.innerHTML = `
        <section class="subpage-header watch-header">
            ${backButtonHTML}

            <p class="eyebrow" id="watch-position">مشاهدة</p>
            <h2 class="watch-title" id="watch-title"></h2>
        </section>

        ${buildWatchStageHTML()}
    `;

            window.scrollTo(0, 0);
            mountWatchStage(video.id);
      }

      // ===== شاهد مباشرة: لصق رابط ومشاهدته دون حفظه في المكتبة =====

      function openDirectWatchPage() {
            leaveWatchPage();

            currentPage = "direct-watch";
            activePlaylistId = null;
            setActiveNav("home");

            mainContent.innerHTML = `
        <section class="subpage-header watch-header">
            <p class="eyebrow" id="watch-position">شاهد مباشرة</p>
            <h2 class="watch-title" id="watch-title">الصق رابط مقطع لتشاهده فورًا</h2>
        </section>

        <div class="direct-form">
            <input class="text-field" id="direct-link" type="text"
                   dir="ltr" inputmode="url" autocomplete="off"
                   spellcheck="false" placeholder="https://youtu.be/...">

            <button type="button" class="primary-button" id="direct-play">
                تشغيل
            </button>
        </div>

        <p class="form-error" id="direct-error" hidden></p>

        <div id="direct-slot"></div>
    `;

            const input = document.getElementById("direct-link");

            document.getElementById("direct-play")
                  .addEventListener("click", playDirectLink);

            input.addEventListener("keydown", event => {
                  if (event.key === "Enter") {
                        event.preventDefault();
                        playDirectLink();
                  }
            });

            window.scrollTo(0, 0);
            input.focus();
      }

      function playDirectLink() {
            const input = document.getElementById("direct-link");
            const errorElement = document.getElementById("direct-error");
            const slot = document.getElementById("direct-slot");

            if (!input || !errorElement || !slot) return;

            const raw = input.value.trim();

            const candidate = /^https?:\/\//i.test(raw) ? raw : "https://" + raw;
            const videoId = raw ? getYouTubeVideoId(candidate) : null;

            if (!videoId) {
                  errorElement.textContent =
                        "الرابط غير صالح. الصق رابط مقطع يوتيوب صحيحًا.";
                  errorElement.hidden = false;
                  return;
            }

            errorElement.hidden = true;

            destroyWatchPlayer();

            // المقطع غير المحفوظ في المكتبة يبقى مؤقتًا في الذاكرة فقط
            if (!isLibraryVideo(videoId)) {
                  watchTemp[videoId] = {
                        id: videoId,
                        title: `مقطع يوتيوب (${videoId})`,
                        url: `https://www.youtube.com/watch?v=${videoId}`,
                        thumbnail: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
                  };
            }

            watchState = {
                  videoId,
                  queue: [videoId],
                  ready: false,
                  seeking: false,
                  loop: false,
                  direct: true,
                  lastSave: 0,
                  lastTick: 0,
                  pendingSeconds: 0
            };

            slot.innerHTML = buildWatchStageHTML();

            input.blur();
            mountWatchStage(videoId);
      }

      // أحداث الواجهة

      function closeVideoMenus() {
            document.querySelectorAll(".video-menu").forEach(menu => {
                  menu.hidden = true;
            });

            document.querySelectorAll(".video-menu-toggle").forEach(btn => {
                  btn.setAttribute("aria-expanded", "false");
            });

            document.querySelectorAll(".playlist-video-card.menu-open").forEach(card => {
                  card.classList.remove("menu-open");
            });
      }

      document.addEventListener("click", event => {
            const themeButton = event.target.closest("[data-theme-choice]");

            if (themeButton) {
                  if (Object.keys(loadCustomColors()).length > 0) {
                        saveCustomColors({});
                        showToast("أُعيدت الألوان إلى ألوان المظهر المختار.");
                  }

                  applyTheme(themeButton.dataset.themeChoice);
                  updateColorControls();
                  return;
            }

            // ===== شريط التنقل السفلي =====
            const navButton = event.target.closest("[data-nav]");

            if (navButton) {
                  event.preventDefault();
                  navigateTo(navButton.dataset.nav);
                  return;
            }

            // ===== قائمة النقاط الثلاث =====
            const menuToggle = event.target.closest(
                  '[data-action="toggle-video-menu"]'
            );

            if (menuToggle) {
                  event.preventDefault();
                  event.stopPropagation();

                  const menu = document.getElementById(
                        `video-menu-${menuToggle.dataset.videoId}`
                  );
                  if (!menu) return;

                  const shouldOpen = menu.hidden;
                  closeVideoMenus();

                  if (shouldOpen) {
                        menu.hidden = false;
                        menuToggle.setAttribute("aria-expanded", "true");
                        menuToggle
                              .closest(".playlist-video-card")
                              .classList.add("menu-open");
                  }
                  return;
            }

            // أي ضغطة أخرى: تغلق القوائم المفتوحة
            closeVideoMenus();

            const button = event.target.closest("[data-action]");


            if (!button) return;

            const action = button.dataset.action;
            const id = button.dataset.id;

            switch (action) {
                  case "back":
                        renderHome();
                        break;

                  case "open-direct":
                        openDirectWatchPage();
                        break;

                  case "reset-colors":
                        resetCustomColors();
                        break;

                  case "open-section":
                        if (currentPage === "home") {
                              sectionOrigin = "home";
                        } else if (currentPage === "playlists") {
                              sectionOrigin = "playlists";
                        }

                        renderSection(button.dataset.section);
                        break;

                  case "open-playlist":
                        openPlaylist(id);
                        break;

                  case "add-list":
                        openCreatePlaylist();
                        break;

                  case "close-modal":
                        closeModal();
                        break;

                  case "rename-playlist":
                        openRenamePlaylist(id);
                        break;

                  case "delete-playlist":
                        openDeletePlaylistModal(id);
                        break;

                  case "add-video-to-playlist":
                        openAddVideoModal(id);
                        break;

                  case "open-bulk-add":
                        openBulkAddModal(id);
                        break;

                  case "watch-video":
                        event.preventDefault();
                        openWatchPage(button.dataset.videoId, {
                              playlistId: id || null,
                              section: button.dataset.section || null
                        });
                        break;

                  case "open-sort-menu":
                        openSortModal(id);
                        break;

                  case "set-sort-mode":
                        if (setPlaylistSortMode(id, button.dataset.mode)) {
                              closeModal();
                              openPlaylist(id);
                        }
                        break;

                  case "move-video-order":
                        moveVideoInPlaylist(
                              id,
                              button.dataset.videoId,
                              button.dataset.direction
                        );
                        break;

                  case "toggle-watch-later":
                        toggleWatchLater(button.dataset.videoId);
                        break;

                  case "toggle-watched":
                        toggleWatched(button.dataset.videoId);
                        break;

                  case "seek-to-note":
                        seekToTime(Number(button.dataset.time));
                        break;

                  case "delete-note":
                        deleteWatchNote(
                              button.dataset.videoId,
                              button.dataset.noteId
                        );
                        break;

                  case "back-to-playlist":
                        destroyWatchPlayer();
                        openPlaylist(id);
                        break;

                  case "copy-video-link":
                        copyVideoLink(button.dataset.videoUrl);
                        break;

                  case "edit-video-title":
                        openEditVideoTitle(button.dataset.videoId);
                        break;

                  case "move-video":
                        openTransferVideoModal(
                              button.dataset.id,
                              button.dataset.videoId,
                              "move"
                        );
                        break;

                  case "copy-video-to-playlist":
                        openTransferVideoModal(
                              button.dataset.id,
                              button.dataset.videoId,
                              "copy"
                        );
                        break;

                  case "remove-video-from-playlist":
                        removeVideoFromPlaylist(id, button.dataset.videoId);
                        break;

                  case "add-video":
                        openBulkAddModal(null);
                        break;

                  case "confirm-delete-playlist":
                        deletePlaylist(id);
                        break;
            }
      });

      document.addEventListener("submit", async event => {
            const form = event.target;

            if (form.id === "transfer-video-form") {
                  event.preventDefault();

                  const sourceId = form.dataset.sourceId;
                  const videoId = form.dataset.videoId;
                  const mode = form.dataset.mode;
                  const targetId = form.elements.targetPlaylistId.value;

                  const sourcePlaylist = appData.playlists.find(
                        playlist => playlist.id === sourceId
                  );

                  const targetPlaylist = appData.playlists.find(
                        playlist => playlist.id === targetId
                  );

                  const videoExists = appData.videos.some(
                        video => video.id === videoId
                  );

                  if (!sourcePlaylist || !targetPlaylist || !videoExists) {
                        showToast("تعذر العثور على المقطع أو إحدى القوائم.");
                        closeModal();
                        return;
                  }

                  if (!Array.isArray(sourcePlaylist.videoIds)) {
                        sourcePlaylist.videoIds = [];
                  }

                  if (!Array.isArray(targetPlaylist.videoIds)) {
                        targetPlaylist.videoIds = [];
                  }

                  if (sourceId === targetId) {
                        showToast("اختر قائمة مختلفة.");
                        return;
                  }

                  if (targetPlaylist.videoIds.includes(videoId)) {
                        showToast("المقطع موجود بالفعل في القائمة المستهدفة.");
                        return;
                  }

                  const originalSourceIds = [...sourcePlaylist.videoIds];
                  const originalTargetIds = [...targetPlaylist.videoIds];

                  targetPlaylist.videoIds.push(videoId);

                  if (mode === "move") {
                        sourcePlaylist.videoIds = sourcePlaylist.videoIds.filter(
                              id => id !== videoId
                        );
                  }

                  if (!saveAppData()) {
                        sourcePlaylist.videoIds = originalSourceIds;
                        targetPlaylist.videoIds = originalTargetIds;
                        return;
                  }

                  closeModal();

                  showToast(
                        mode === "move"
                              ? "تم نقل المقطع بنجاح."
                              : "تم نسخ المقطع إلى القائمة بنجاح."
                  );

                  openPlaylist(sourceId);
                  return;
            }

            if (form.id === "edit-video-title-form") {
                  event.preventDefault();

                  const videoId = form.dataset.videoId;
                  const titleInput = document.getElementById("edit-video-title");
                  const errorElement = document.getElementById("edit-video-title-error");
                  const newTitle = titleInput.value.trim();

                  if (!newTitle) {
                        errorElement.textContent = "يرجى إدخال عنوان للمقطع.";
                        errorElement.hidden = false;
                        return;
                  }

                  const video = appData.videos.find(
                        item => item.id === videoId
                  );

                  if (!video) {
                        showToast("لم يتم العثور على المقطع.");
                        closeModal();
                        return;
                  }

                  const oldTitle = video.title;
                  video.title = newTitle;

                  if (!saveAppData()) {
                        video.title = oldTitle;
                        return;
                  }

                  closeModal();
                  showToast("تم تعديل عنوان المقطع.");
                  openPlaylist(activePlaylistId);
                  return;
            }

            if (form.id === "create-playlist-form") {
                  event.preventDefault();

                  const name = document.getElementById("playlist-name").value;
                  const description = document.getElementById(
                        "playlist-description"
                  ).value;

                  createPlaylist(name, description);
                  return;
            }

            if (form.id === "rename-playlist-form") {
                  event.preventDefault();

                  const id = form.dataset.id;
                  const name = document.getElementById(
                        "rename-playlist-name"
                  ).value;
                  const description = document.getElementById(
                        "rename-playlist-description"
                  ).value;

                  renamePlaylist(id, name, description);
                  return;
            }

            if (form.id === "add-video-form") {
                  event.preventDefault();

                  const playlistId = form.dataset.playlistId;
                  const url = form.elements.videoUrl.value.trim();
                  const errorElement = document.getElementById(
                        "youtube-video-error"
                  );

                  const videoId = getYouTubeVideoId(url);

                  if (!videoId) {
                        errorElement.textContent =
                              "الرابط غير صالح. أدخل رابط مقطع يوتيوب صحيحًا.";
                        errorElement.hidden = false;
                        return;
                  }

                  const playlist = appData.playlists.find(
                        item => item.id === playlistId
                  );

                  if (!playlist) {
                        showToast("لم يتم العثور على القائمة.");
                        closeModal();
                        return;
                  }

                  if (!Array.isArray(playlist.videoIds)) {
                        playlist.videoIds = [];
                  }

                  if (playlist.videoIds.includes(videoId)) {
                        errorElement.textContent =
                              "هذا المقطع موجود بالفعل في القائمة.";
                        errorElement.hidden = false;
                        return;
                  }

                  const submitButton = form.querySelector(
                        'button[type="submit"]'
                  );

                  submitButton.disabled = true;
                  submitButton.textContent = "جارٍ جلب بيانات المقطع...";

                  try {
                        let title = "مقطع يوتيوب";
                        const thumbnail =
                              `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

                        try {
                              const response = await fetch(
                                    `https://noembed.com/embed?url=${encodeURIComponent(
                                          `https://www.youtube.com/watch?v=${videoId}`
                                    )}`
                              );

                              if (response.ok) {
                                    const metadata = await response.json();

                                    if (metadata.title) {
                                          title = metadata.title;
                                    }
                              }
                        } catch (error) {
                              console.warn("تعذر جلب عنوان الفيديو:", error);
                        }

                        const video = {
                              id: videoId,
                              title,
                              url: `https://www.youtube.com/watch?v=${videoId}`,
                              thumbnail
                        };

                        const previousVideos = appData.videos;
                        const previousVideoIds = [...playlist.videoIds];

                        const existingVideo = appData.videos.find(
                              item => item.id === videoId
                        );

                        if (!existingVideo) {
                              appData.videos.push(video);
                        }

                        playlist.videoIds.push(videoId);

                        if (!saveAppData()) {
                              appData.videos = previousVideos;
                              playlist.videoIds = previousVideoIds;
                              return;
                        }

                        closeModal();
                        showToast(
                              title === "مقطع يوتيوب"
                                    ? "أُضيف المقطع، لكن تعذر جلب عنوانه."
                                    : "تمت إضافة المقطع بنجاح."
                        );

                        openPlaylist(playlistId);
                  } finally {
                        if (submitButton.isConnected) {
                              submitButton.disabled = false;
                              submitButton.textContent = "إضافة المقطع";
                        }
                  }
            }
      });


      document.addEventListener("keydown", event => {
            if (event.key === "Escape") closeModal();
      });

      function init() {
            let theme = "dark";

            try {
                  theme = localStorage.getItem(STORAGE_KEYS.theme) || "dark";
            } catch (error) {
                  // الاستمرار بالمظهر الداكن إذا تعذر الوصول للتخزين
            }

            applyTheme(theme, false);
            renderHome();
      }

      return { init };
})();

Mushahid.init();