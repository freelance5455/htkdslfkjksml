/* Paynet Bank — demo banking app (client-side, localStorage) */
'use strict';

/* ------------------------------------------------------------------ icons */
const ICONS = {
  home: '<path d="M4 10.4 12 4l8 6.4V20a1 1 0 0 1-1 1h-4.6v-6.2H9.6V21H5a1 1 0 0 1-1-1z"/>',
  clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.6V12l3 1.8"/>',
  pulse: '<path d="M3 12h3.6l2.2-6.4L13 18.4l2.3-6.4H21"/>',
  card: '<rect x="2.5" y="5" width="19" height="14" rx="3.4"/><path d="M2.5 10h19"/><path d="M6.4 14.6h3.2"/>',
  user: '<circle cx="12" cy="8.2" r="3.7"/><path d="M4.5 20.5c1.1-3.6 4-5.4 7.5-5.4s6.4 1.8 7.5 5.4"/>',
  send: '<path d="M7.5 16.5 16.5 7.5"/><path d="M9.2 7.5h7.3v7.3"/>',
  grid: '<rect x="3.5" y="3.5" width="7" height="7" rx="2"/><rect x="13.5" y="3.5" width="7" height="7" rx="2"/><rect x="3.5" y="13.5" width="7" height="7" rx="2"/><rect x="13.5" y="13.5" width="7" height="7" rx="2"/>',
  bell: '<path d="M6.2 9.7a5.8 5.8 0 0 1 11.6 0c0 4 1.4 5.3 2 5.9H4.2c.6-.6 2-1.9 2-5.9Z"/><path d="M10 19a2.2 2.2 0 0 0 4 0"/>',
  eye: '<path d="M2.6 12S6 6.3 12 6.3 21.4 12 21.4 12 18 17.7 12 17.7 2.6 12 2.6 12Z"/><circle cx="12" cy="12" r="2.9"/>',
  eyeOff: '<path d="M4 4l16 16"/><path d="M9.9 5.1A9.9 9.9 0 0 1 12 5c6 0 9.4 7 9.4 7a17 17 0 0 1-2.6 3.4"/><path d="M6.6 6.9C4 8.6 2.6 12 2.6 12S6 19 12 19a9.5 9.5 0 0 0 3.6-.7"/><path d="M9.9 10a2.9 2.9 0 0 0 4.1 4.1"/>',
  chevronRight: '<path d="m9.5 6 6 6-6 6"/>',
  chevronLeft: '<path d="m14.5 6-6 6 6 6"/>',
  plus: '<path d="M12 5.5v13M5.5 12h13"/>',
  close: '<path d="M6 6l12 12M18 6 6 18"/>',
  check: '<path d="m4.5 12.5 5 5 10-11"/>',
  shield: '<path d="M12 3.2 19 6v5.4c0 4.3-2.9 7.4-7 8.4-4.1-1-7-4.1-7-8.4V6z"/><path d="m9 12 2.2 2.2L15.4 10"/>',
  lock: '<rect x="4.5" y="10.5" width="15" height="10" rx="3"/><path d="M8.4 10.5V8a3.6 3.6 0 0 1 7.2 0v2.5"/>',
  smartphone: '<rect x="7" y="2.6" width="10" height="18.8" rx="3"/><path d="M11 18.6h2"/>',
  wifi: '<path d="M3.2 9.4a13 13 0 0 1 17.6 0"/><path d="M6.4 12.6a8.4 8.4 0 0 1 11.2 0"/><path d="M9.6 15.8a4 4 0 0 1 4.8 0"/><circle cx="12" cy="19" r=".8" fill="currentColor" stroke="none"/>',
  bolt: '<path d="M13.2 2.5 5.4 13.4h5.1L9.9 21.5l8-11.2h-5.2z"/>',
  bag: '<path d="M5.4 8h13.2l1 12.5H4.4z"/><path d="M8.6 8V6.4a3.4 3.4 0 0 1 6.8 0V8"/>',
  car: '<path d="M4.4 16.2V12l1.8-4.4h11.6L19.6 12v4.2"/><path d="M3.6 12h16.8"/><circle cx="7.6" cy="17.4" r="1.8"/><circle cx="16.4" cy="17.4" r="1.8"/>',
  heart: '<path d="M12 20s-7.4-4.6-7.4-9.6A4.2 4.2 0 0 1 12 7.4a4.2 4.2 0 0 1 7.4 3c0 5-7.4 9.6-7.4 9.6Z"/>',
  book: '<path d="M4 4.6h6a2.4 2.4 0 0 1 2 1.2 2.4 2.4 0 0 1 2-1.2h6v13.4h-6a2.4 2.4 0 0 0-2 1.2 2.4 2.4 0 0 0-2-1.2H4z"/>',
  gamepad: '<rect x="2.6" y="7" width="18.8" height="11" rx="5.2"/><path d="M7.4 11v3.6M5.6 12.8h3.6"/><circle cx="16.2" cy="11.6" r=".9" fill="currentColor" stroke="none"/><circle cx="18.2" cy="13.8" r=".9" fill="currentColor" stroke="none"/>',
  gift: '<rect x="3.4" y="8.6" width="17.2" height="4" rx="1.4"/><path d="M4.8 12.6v7.6h14.4v-7.6"/><path d="M12 8.6v11.6"/><path d="M12 8.6S9.6 4 7.8 5.4 9.4 8.6 12 8.6Zm0 0S14.4 4 16.2 5.4 14.6 8.6 12 8.6Z"/>',
  search: '<circle cx="11" cy="11" r="6.6"/><path d="m16 16 4.2 4.2"/>',
  backspace: '<path d="M9.4 5h10.4a1.6 1.6 0 0 1 1.6 1.6v10.8a1.6 1.6 0 0 1-1.6 1.6H9.4L3 12z"/><path d="m12.6 9.6 4.8 4.8M17.4 9.6l-4.8 4.8"/>',
  finger: '<path d="M8.6 20.4c-.9-2.4-1.2-4.4-1.2-6.6a4.6 4.6 0 0 1 9.2 0c0 1 0 1.8-.2 2.8"/><path d="M12 9.4a2.6 2.6 0 0 0-2.6 2.6c0 1.6.2 3.6.9 5.6"/><path d="M14.8 20.4c.6-2.2.8-4 .8-6.6"/><path d="M5.8 17.6c-.4-1.5-.6-2.8-.6-4a6.8 6.8 0 0 1 10.6-5.7"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.4"/><circle cx="12" cy="7.9" r=".9" fill="currentColor" stroke="none"/>',
  logout: '<path d="M14.6 4.5H6.4a1.8 1.8 0 0 0-1.8 1.8v11.4a1.8 1.8 0 0 0 1.8 1.8h8.2"/><path d="M17.4 8.4 21 12l-3.6 3.6"/><path d="M10.4 12H21"/>',
  key: '<circle cx="8" cy="8" r="4.2"/><path d="m11 11 8.8 8.8"/><path d="m16.4 16.4 2-2 2 2-2 2z"/>',
  devices: '<rect x="2.6" y="5.4" width="12.4" height="9" rx="2"/><path d="M6.4 18.6h5.4"/><rect x="17" y="8.6" width="4.4" height="10" rx="1.6"/>',
  transfer: '<path d="M4 8.5h16"/><path d="m16 4.5 4 4-4 4"/><path d="M20 15.5H4"/><path d="m8 11.5-4 4 4 4"/>',
  globe: '<circle cx="12" cy="12" r="8.6"/><path d="M3.6 12h16.8"/><path d="M12 3.4c2.3 2.5 3.5 5.4 3.5 8.6s-1.2 6.1-3.5 8.6c-2.3-2.5-3.5-5.4-3.5-8.6S9.7 5.9 12 3.4Z"/>',
  camera: '<path d="M4.4 8.6h2.9l1.5-2.2h6.4l1.5 2.2h2.9a1.8 1.8 0 0 1 1.8 1.8v7a1.8 1.8 0 0 1-1.8 1.8H4.4a1.8 1.8 0 0 1-1.8-1.8v-7a1.8 1.8 0 0 1 1.8-1.8Z"/><circle cx="12" cy="13.9" r="3.2"/>',
  moon: '<path d="M20 14.6A8.4 8.4 0 0 1 9.4 4a8.6 8.6 0 1 0 10.6 10.6Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.6v2.2M12 19.2v2.2M4.4 4.4l1.6 1.6M18 18l1.6 1.6M2.6 12h2.2M19.2 12h2.2M4.4 19.6 6 18M18 6l1.6-1.6"/>',
  edit: '<path d="M4 20h4.2l10-10a2.4 2.4 0 0 0-3.4-3.4l-10 10z"/><path d="m14 7.4 2.6 2.6"/>'
};
const ic = (name, cls = '') =>
  `<svg class="ic ${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;

/* ------------------------------------------------------------------ helpers */
const fmt = n => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const pad = n => String(n).padStart(2, '0');
const rid = () => 'PN' + Math.random().toString(36).slice(2, 7).toUpperCase();
const nowTime = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const months = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr'];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function dateShort(d) { return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`; }
function sameDay(a, b) { return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate(); }
function dateLabel(iso) {
  const d = new Date(iso), t = new Date();
  const y = new Date(t); y.setDate(t.getDate() - 1);
  if (sameDay(d, t)) return 'Bugun';
  if (sameDay(d, y)) return 'Kecha';
  return `${d.getDate()} ${months[d.getMonth()]}`;
}

/* ------------------------------------------------------------------ data model */
const CATS = {
  income: { label: 'Kirim', icon: 'arrowIn', color: '#0f9d67', bg: '#e6f8f0' },
  transfer: { label: 'O‘tkazma', icon: 'send', color: '#2f7cf6', bg: '#e9f1ff' },
  payment: { label: 'To‘lov', icon: 'grid', color: '#8b5cf6', bg: '#f1ecff' },
  mobile: { label: 'Mobil aloqa', icon: 'smartphone', color: '#d99008', bg: '#fef4e4' },
  internet: { label: 'Internet', icon: 'wifi', color: '#0ea5e9', bg: '#e6f6fd' },
  utility: { label: 'Kommunal', icon: 'bolt', color: '#f97316', bg: '#fff1e6' },
  food: { label: 'Oziq-ovqat', icon: 'bag', color: '#ef4444', bg: '#fdeaea' },
  transport: { label: 'Transport', icon: 'car', color: '#0d9488', bg: '#e6f8f6' },
  shopping: { label: 'Xarid', icon: 'bag', color: '#e11d48', bg: '#fde8ee' },
  game: { label: 'O‘yinlar', icon: 'gamepad', color: '#6366f1', bg: '#eceafe' },
  health: { label: 'Salomatlik', icon: 'heart', color: '#e11d48', bg: '#fde8ee' },
  bonus: { label: 'Bonus', icon: 'gift', color: '#b98908', bg: '#fdf6e3' },
  education: { label: 'Ta’lim', icon: 'book', color: '#0d9488', bg: '#e5f7f5' }
};
ICONS.arrowIn = '<path d="M17 7v9.5H7.5"/><path d="m12 11.5-4.5 5 4.5 5"/>';

const PAY_CATEGORIES = [
  { id: 'utility', name: 'Kommunal', icon: 'bolt', color: '#f97316', bg: '#fff1e6' },
  { id: 'mobile', name: 'Mobil aloqa', icon: 'smartphone', color: '#d99008', bg: '#fef4e4' },
  { id: 'internet', name: 'Internet', icon: 'wifi', color: '#0ea5e9', bg: '#e6f6fd' },
  { id: 'game', name: 'O‘yinlar', icon: 'gamepad', color: '#6366f1', bg: '#eceafe' },
  { id: 'transport', name: 'Transport', icon: 'car', color: '#0d9488', bg: '#e6f8f6' },
  { id: 'education', name: 'Ta’lim', icon: 'book', color: '#0d9488', bg: '#e5f7f5' },
  { id: 'health', name: 'Salomatlik', icon: 'heart', color: '#e11d48', bg: '#fde8ee' },
  { id: 'payment', name: 'Boshqa', icon: 'grid', color: '#8b5cf6', bg: '#f1ecff' }
];

const PAY_SERVICES = {
  utility: [
    { name: 'Hududgaz', note: 'Gaz to‘lovi' },
    { name: 'Suvsoz', note: 'Suv ta’minoti' },
    { name: 'Toshkent Issiqlik', note: 'Issiqlik energiyasi' },
    { name: 'Elektr energiya', note: 'Hududiy elektr tarmoqlari' }
  ],
  mobile: [
    { name: 'Uzmobile', note: 'Mobil aloqa operatori' },
    { name: 'Beeline', note: 'Mobil aloqa operatori' },
    { name: 'Ucell', note: 'Mobil aloqa operatori' },
    { name: 'Mobiuz', note: 'Mobil aloqa operatori' }
  ],
  internet: [
    { name: 'UZONLINE', note: 'Uy interneti' },
    { name: 'TTK', note: 'Uy interneti' },
    { name: 'Orbita Telecom', note: 'Uy interneti' }
  ],
  game: [
    { name: 'Steam', note: 'O‘yin hamyoni' },
    { name: 'PlayStation Network', note: 'PS Store' },
    { name: 'Mobile Legends', note: 'O‘yin valyutasi' }
  ],
  transport: [
    { name: 'Yandex Go', note: 'Taxi xizmati' },
    { name: 'Toshkent metro', note: 'Transport kartasi' },
    { name: 'Toshkent Park', note: 'Avtoturargoh' }
  ],
  education: [
    { name: 'IT Park', note: 'Ta’lim kurslari' },
    { name: 'Coursera', note: 'Onlayn ta’lim' },
    { name: 'IDUM', note: 'Ta’lim platformasi' }
  ],
  health: [
    { name: 'Oson Apteka', note: 'Dorixona' },
    { name: 'Med24', note: 'Klinika to‘lovi' },
    { name: 'DMed', note: 'Tibbiy xizmat' }
  ],
  payment: [
    { name: 'Mehribonlik uyi', note: 'Xayriya to‘lovi' },
    { name: 'Paynet xizmatlari', note: 'Xizmat to‘lovi' },
    { name: 'Kommunal yig‘ma', note: 'Yagona hisob' }
  ]
};

const CONTACTS = [
  { name: 'Dilnoza Ahmedova', detail: '•••• 9034', bank: 'Uzcard', initials: 'DA', bg: '#e9f1ff', ink: '#2f7cf6' },
  { name: 'Jasur Toshmatov', detail: '•••• 1188', bank: 'Humo', initials: 'JT', bg: '#e6f8f0', ink: '#0f9d67' },
  { name: 'Sevara Qodirova', detail: '+998 93 555 22 11', bank: 'Paynet', initials: 'SQ', bg: '#f1ecff', ink: '#7c5cf0' },
  { name: 'Bekzod Rahimov', detail: '•••• 7712', bank: 'Visa', initials: 'BR', bg: '#fdeee9', ink: '#d9633f' }
];

const STORAGE_KEY = 'paynet.bank.v1';

function seedTx() {
  const base = new Date();
  const at = (dAgo, h, m) => {
    const d = new Date(base);
    d.setDate(d.getDate() - dAgo);
    d.setHours(h, m, 0, 0);
    return d.toISOString();
  };
  return [
    { id: 'PN24081', dir: 'out', title: 'Yandex Go', note: 'Transport · Toshkent', amount: 24000, cat: 'transport', ts: at(0, 9, 12) },
    { id: 'PN24079', dir: 'in', title: 'Oylik maosh', note: 'Techno Soft MChJ', amount: 12000000, cat: 'income', ts: at(1, 10, 4) },
    { id: 'PN24075', dir: 'out', title: 'Korzinka', note: 'Xarid · Yunusobod', amount: 187500, cat: 'food', ts: at(1, 19, 24) },
    { id: 'PN24068', dir: 'out', title: 'Uzmobile', note: 'Mobil aloqa · +998 90 *** 45 67', amount: 45000, cat: 'mobile', ts: at(2, 8, 40) },
    { id: 'PN24061', dir: 'out', title: 'UZONLINE', note: 'Internet · Noyabr oyi', amount: 289000, cat: 'internet', ts: at(3, 21, 10) },
    { id: 'PN24055', dir: 'out', title: 'Hududgaz', note: 'Kommunal · Gaz to‘lovi', amount: 96400, cat: 'utility', ts: at(4, 12, 32) },
    { id: 'PN24047', dir: 'in', title: 'Dilnoza Ahmedova', note: 'O‘tkazma · Uzcard •••• 9034', amount: 850000, cat: 'transfer', ts: at(5, 18, 55) },
    { id: 'PN24042', dir: 'out', title: 'Uzum Market', note: 'Xarid · Elektronika', amount: 342000, cat: 'shopping', ts: at(6, 14, 18) },
    { id: 'PN24036', dir: 'out', title: 'Steam', note: 'O‘yin hamyoni', amount: 129000, cat: 'game', ts: at(7, 22, 3) },
    { id: 'PN24029', dir: 'out', title: 'Oson Apteka', note: 'Salomatlik · Dorixona', amount: 78000, cat: 'health', ts: at(8, 11, 47) },
    { id: 'PN24022', dir: 'out', title: 'Toshkent metro', note: 'Transport kartasi', amount: 1700, cat: 'transport', ts: at(9, 7, 58) },
    { id: 'PN24015', dir: 'in', title: 'Cashback', note: 'Paynet bonuslari', amount: 32500, cat: 'bonus', ts: at(10, 16, 21) },
    { id: 'PN24009', dir: 'out', title: 'Beeline', note: 'Mobil aloqa · Internet paket', amount: 55000, cat: 'mobile', ts: at(11, 9, 30) }
  ];
}

function defaults() {
  return {
    name: 'Aziz Salimov',
    phone: '+998 90 123 45 67',
    pin: '1234',
    hideBalance: false,
    theme: 'dark',
    avatar: '',
    settings: { biometric: true, twofa: true, notify: true },
    cards: [
      { id: 'c1', kind: 'Humo', theme: 'humo', pan: '8600 1400 1234 4821', last4: '4821', exp: '12/28', amount: 24850000, frozen: false },
      { id: 'c2', kind: 'Uzcard', theme: 'uzcard', pan: '8600 4900 8812 9034', last4: '9034', exp: '07/27', amount: 3200000, frozen: false },
      { id: 'c3', kind: 'Visa', theme: 'visa', pan: '4276 8800 5531 7712', last4: '7712', exp: '02/29', amount: 12400000, frozen: false }
    ],
    transactions: seedTx(),
    alerts: [
      { icon: 'check', title: 'To‘lov bajarildi', text: 'Uzmobile · 45 000 so‘m muvaffaqiyatli to‘landi.', time: 'Bugun, 08:40' },
      { icon: 'shield', title: 'Yangi kirish', text: 'iPhone 15 · Toshkent shahri. Agar bu siz bo‘lmasangiz, parolni o‘zgartiring.', time: 'Kecha, 21:04' },
      { icon: 'bolt', title: 'Kommunal eslatma', text: 'Hududgaz uchun joriy oy to‘lovi qabul qilinmoqda.', time: '19 noyabr' }
    ]
  };
}

let state;
try {
  const raw = localStorage.getItem(STORAGE_KEY);
  state = raw ? { ...defaults(), ...JSON.parse(raw) } : defaults();
} catch (err) {
  state = defaults();
}
function save() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (err) { /* storage disabled */ }
}
const mainCard = () => state.cards[0];

if (!state.theme) state.theme = 'dark';
if (typeof state.avatar !== 'string') state.avatar = '';

function applyTheme() {
  document.documentElement.dataset.theme = state.theme === 'light' ? 'light' : 'dark';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', state.theme === 'light' ? '#eef4f1' : '#070b0a');
}

const initials = name => (String(name || '').trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('') || 'P').toUpperCase();
const avatarInner = () => state.avatar ? `<img src="${state.avatar}" alt="" />` : esc(initials(state.name));

function pickAvatar(file) {
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      const size = 320;
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = size;
      const g = canvas.getContext('2d');
      const scale = Math.max(size / img.width, size / img.height);
      const w = img.width * scale, h = img.height * scale;
      g.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
      try { state.avatar = canvas.toDataURL('image/jpeg', 0.82); } catch (err) { toast('Rasmni yuklab bo‘lmadi'); return; }
      save();
      render();
      toast('Profil rasmi yangilandi');
    };
    img.onerror = () => toast('Rasmni o‘qib bo‘lmadi');
    img.src = reader.result;
  };
  reader.onerror = () => toast('Faylni o‘qib bo‘lmadi');
  reader.readAsDataURL(file);
}

/* ------------------------------------------------------------------ app state */
const TABS = [
  { id: 'home', label: 'Bosh sahifa', icon: 'home' },
  { id: 'history', label: 'Tarix', icon: 'clock' },
  { id: 'monitoring', label: 'Monitoring', icon: 'pulse' },
  { id: 'cards', label: 'Kartalar', icon: 'card' },
  { id: 'settings', label: 'Profil', icon: 'user' }
];

const app = {
  route: 'home',
  flow: null,
  q: '',
  filter: 'all',
  events: [],
  eventTimer: null
};

/* ------------------------------------------------------------------ transactions helpers */
const isToday = iso => sameDay(new Date(iso), new Date());
const sum = list => list.reduce((s, t) => s + t.amount, 0);
const todaySpend = () => sum(state.transactions.filter(t => t.dir === 'out' && isToday(t.ts)));
const todayIncome = () => sum(state.transactions.filter(t => t.dir === 'in' && isToday(t.ts)));
const todayCount = () => state.transactions.filter(t => isToday(t.ts)).length;

function last7Spend() {
  const out = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    out.push(sum(state.transactions.filter(t => t.dir === 'out' && sameDay(new Date(t.ts), d))));
  }
  return out;
}

function filteredTx() {
  const q = app.q.trim().toLowerCase();
  return state.transactions.filter(t => {
    const okFilter = app.filter === 'all' || t.dir === app.filter;
    const okQuery = !q || t.title.toLowerCase().includes(q) || t.note.toLowerCase().includes(q) || fmt(t.amount).includes(q);
    return okFilter && okQuery;
  });
}

/* ------------------------------------------------------------------ shared partials */
function txRow(t) {
  const c = CATS[t.cat] || CATS.payment;
  return `<button class="tx" data-action="tx-detail" data-id="${t.id}">
    <span class="tx-ic" style="--tone:${c.color};--tone-bg:${c.bg}">${ic(c.icon)}</span>
    <span class="tx-main"><b>${esc(t.title)}</b><span>${esc(t.note)}</span></span>
    <span class="tx-amt ${t.dir}">${t.dir === 'in' ? '+' : '−'}${fmt(t.amount)}<small>${nowTime(new Date(t.ts))}</small></span>
  </button>`;
}

function serviceTile(c) {
  return `<button class="service" data-action="pay-cat" data-cat="${c.id}">
    <span class="s-ic" style="--tone:${c.color};--tone-bg:${c.bg}">${ic(c.icon)}</span>
    <span>${c.name}</span>
  </button>`;
}

function toggleRow(title, sub, icon, key) {
  const on = key === 'hideBalance' ? state.hideBalance : state.settings[key];
  return `<div class="row-item">
    <span class="r-ic">${ic(icon)}</span>
    <span class="r-main"><b>${title}</b><span>${sub}</span></span>
    <button class="switch ${on ? 'on' : ''}" data-action="toggle-setting" data-key="${key}" aria-label="${title}" aria-pressed="${on}"></button>
  </div>`;
}

function sheetRow(k, v) {
  return `<div class="review-row"><span>${k}</span><b>${v}</b></div>`;
}

/* ------------------------------------------------------------------ views */
function homeView() {
  const recent = state.transactions.slice(0, 5);
  const hidden = state.hideBalance;
  return `
  <div class="topbar">
    <div class="who">
      <button class="avatar" data-action="open-profile" aria-label="Profil">${avatarInner()}</button>
      <div>
        <p class="eyebrow">Xayrli kun 👋</p>
        <h1>${state.name}</h1>
      </div>
    </div>
    <button class="icon-btn" data-action="alerts" aria-label="Bildirishnomalar">${ic('bell')}<i class="badge-dot"></i></button>
  </div>

  <div class="balance-card">
    <div class="bc-head">
      <div class="brand">
        <span class="brand-mark">P</span>
        <span class="brand-text"><b>Paynet</b><span>bank</span></span>
      </div>
      <span class="chip-pill">Humo</span>
    </div>
    <div class="bc-body">
      <p class="bc-label">Umumiy balans</p>
      <div class="bc-amount-row">
        <span class="bc-amount">${hidden ? '••• •••' : fmt(mainCard().amount)}<i>so‘m</i></span>
        <button class="bc-eye" data-action="toggle-balance" aria-label="Balansni yashirish">${ic(hidden ? 'eyeOff' : 'eye')}</button>
      </div>
    </div>
    <div class="bc-foot">
      <span class="bc-card">•••• 4821</span>
      <span class="bc-exp">12/28</span>
      <span class="bc-live">${ic('shield')} Himoyalangan</span>
    </div>
  </div>

  <div class="quick">
    <button data-action="new-transfer"><span class="q-ic">${ic('send')}</span>O‘tkazma</button>
    <button data-action="go" data-route="payments"><span class="q-ic">${ic('grid')}</span>To‘lovlar</button>
    <button data-action="topup"><span class="q-ic">${ic('plus')}</span>To‘ldirish</button>
    <button data-action="go" data-route="history"><span class="q-ic">${ic('clock')}</span>Tarix</button>
  </div>

  <div class="live-strip" data-action="go" data-route="monitoring">
    <i class="pulse"></i>
    <div class="ls-text"><b>Real monitoring</b><span>Bugungi xarajat · live</span></div>
    <div class="ls-amount">${fmt(todaySpend())} so‘m</div>
    ${ic('chevronRight')}
  </div>

  <div class="section">
    <div class="section-head"><h3>Tezkor to‘lovlar</h3><button data-action="go" data-route="payments">Barchasi ${ic('chevronRight')}</button></div>
    <div class="services">${PAY_CATEGORIES.map(serviceTile).join('')}</div>
  </div>

  <div class="section">
    <div class="section-head"><h3>Oxirgi amallar</h3><button data-action="go" data-route="history">Tarix ${ic('chevronRight')}</button></div>
    <div class="tx-list">${recent.map(txRow).join('')}</div>
  </div>`;
}

function historyView() {
  const items = filteredTx();
  return `
  <div class="page-head">
    <div class="row">
      <div><h1>Tarix</h1><p>O‘tkazmalar va to‘lovlar tarixi</p></div>
      <span class="live-pill" style="margin-left:auto">${items.length} amal</span>
    </div>
  </div>
  <div class="chips">
    ${[['all', 'Barchasi'], ['in', 'Kirim'], ['out', 'Chiqim']].map(([k, l]) =>
      `<button class="chip ${app.filter === k ? 'active' : ''}" data-action="filter" data-filter="${k}">${l}</button>`).join('')}
  </div>
  <div class="search">${ic('search')}<input data-search placeholder="Qidirish: nom, izoh, miqdor" value="${esc(app.q)}" /></div>
  <div id="historyList">${historyList(items)}</div>`;
}

function historyList(items) {
  if (!items.length) {
    return `<div class="empty"><b>Amallar topilmadi</b>Qidiruv yoki filtrni o‘zgartirib ko‘ring</div>`;
  }
  const groups = new Map();
  items.forEach(t => {
    const key = dateLabel(t.ts);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(t);
  });
  return [...groups.entries()].map(([label, list]) => {
    const net = list.reduce((s, t) => s + (t.dir === 'in' ? t.amount : -t.amount), 0);
    return `<div class="day-head"><span>${label}</span><span>${net > 0 ? '+' : '−'}${fmt(Math.abs(net))} so‘m</span></div>
      <div class="tx-list">${list.map(txRow).join('')}</div>`;
  }).join('');
}

function smoothPath(points) {
  let d = `M ${points[0][0].toFixed(1)} ${points[0][1].toFixed(1)}`;
  for (let i = 1; i < points.length; i++) {
    const [x0, y0] = points[i - 1];
    const [x1, y1] = points[i];
    const mx = (x0 + x1) / 2;
    d += ` C ${mx.toFixed(1)} ${y0.toFixed(1)} ${mx.toFixed(1)} ${y1.toFixed(1)} ${x1.toFixed(1)} ${y1.toFixed(1)}`;
  }
  return d;
}

function chart(values) {
  const w = 300, h = 96, bottom = h, top = 10;
  const max = Math.max(...values, 1);
  const step = w / (values.length - 1);
  const pts = values.map((v, i) => [i * step, bottom - (v / max) * (bottom - top)]);
  const line = smoothPath(pts);
  const area = `${line} L ${w} ${bottom} L 0 ${bottom} Z`;
  const last = pts[pts.length - 1];
  return `<svg viewBox="0 0 ${w} ${h + 6}" preserveAspectRatio="none" style="height:118px" aria-hidden="true">
    <defs>
      <linearGradient id="chartFill" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#7cf7d4" stop-opacity=".34"/>
        <stop offset="100%" stop-color="#7cf7d4" stop-opacity="0"/>
      </linearGradient>
    </defs>
    <path d="${area}" fill="url(#chartFill)"/>
    <path d="${line}" fill="none" stroke="#7cf7d4" stroke-width="2.4" stroke-linecap="round"/>
    <line x1="0" y1="${bottom}" x2="${w}" y2="${bottom}" stroke="rgba(255,255,255,.14)" stroke-width="1" stroke-dasharray="3 4"/>
    <circle cx="${last[0]}" cy="${last[1]}" r="4" fill="#7cf7d4" stroke="#0a1412" stroke-width="2.4"/>
  </svg>`;
}

function catBars() {
  const totals = {};
  state.transactions.filter(t => t.dir === 'out').forEach(t => {
    totals[t.cat] = (totals[t.cat] || 0) + t.amount;
  });
  const rows = Object.entries(totals).sort((a, b) => b[1] - a[1]).slice(0, 4);
  const max = Math.max(...rows.map(r => r[1]), 1);
  if (!rows.length) return '<p class="muted" style="font-size:12px">Ma’lumot yo‘q</p>';
  return rows.map(([cat, amount]) => {
    const c = CATS[cat] || CATS.payment;
    return `<div class="bar-row" style="--tone:${c.color};--tone-bg:${c.bg}">
      <span class="b-ic">${ic(c.icon)}</span>
      <div class="bar-main">
        <div class="b-top"><b>${c.label}</b><span>${fmt(amount)} so‘m</span></div>
        <div class="bar-track"><div class="bar-fill" style="width:${Math.round(amount / max * 100)}%"></div></div>
      </div>
    </div>`;
  }).join('');
}

const eventRow = e =>
  `<li class="event"><span class="event-dot ${e.warn ? 'warn' : ''}"></span><p>${esc(e.text)}</p><time>${e.time}</time></li>`;

function monitoringView() {
  const spend = todaySpend();
  const income = todayIncome();
  const count = todayCount();
  const week = last7Spend();
  const total = week.reduce((a, b) => a + b, 0);
  const avg = Math.round(spend / Math.max(1, count));
  return `
  <div class="page-head">
    <div class="row">
      <div><p class="eyebrow">Real vaqt rejimi</p><h1 style="margin-top:2px">Monitoring</h1></div>
      <span class="live-pill" style="margin-left:auto"><i></i>LIVE</span>
    </div>
    <p>Hisobingizdagi harakatlar real vaqtda kuzatiladi</p>
  </div>

  <div class="stat-grid">
    <div class="stat down"><span>Bugungi chiqim</span><b>${fmt(spend)}<i>so‘m</i></b></div>
    <div class="stat up"><span>Bugungi kirim</span><b>${fmt(income)}<i>so‘m</i></b></div>
    <div class="stat"><span>Amallar soni</span><b>${count}<i>ta</i></b></div>
    <div class="stat"><span>O‘rtacha to‘lov</span><b>${fmt(avg)}<i>so‘m</i></b></div>
  </div>

  <div class="card" style="margin-top:12px">
    <div class="card-head"><h3>Xarajat dinamikasi</h3><span>so‘nggi 7 kun</span></div>
    <div class="chart-wrap">${chart(week)}</div>
    <div class="chart-legend"><span>Haftalik jami</span><b>${fmt(total)} so‘m</b></div>
  </div>

  <div class="card">
    <div class="card-head"><h3>Kategoriyalar</h3><span>barcha amallar</span></div>
    <div class="bars">${catBars()}</div>
  </div>

  <div class="card">
    <div class="card-head"><h3>Tizim hodisalari</h3><span class="live-pill small"><i></i>live</span></div>
    <ul class="events" id="liveEvents">${app.events.map(eventRow).join('')}</ul>
  </div>

  <div class="foot-note">Ulanish himoyalangan · TLS 1.3<br/>Paynet Bank monitoring xizmati</div>`;
}

function cardHtml(c) {
  return `<div style="margin-bottom:12px">
    <div class="bank-card ${c.theme} ${c.frozen ? 'frozen' : ''}">
      <div class="bc-row"><span class="kind">${c.kind}</span><span class="kind">${c.frozen ? 'Bloklangan' : 'Faol'}</span></div>
      <div class="num">•••• •••• •••• ${c.last4}</div>
      <div class="amt">${fmt(c.amount)}<small>so‘m</small></div>
    </div>
    <div class="card-actions">
      <button data-action="card-send" data-id="${c.id}">${ic('send')} O‘tkazish</button>
      <button data-action="card-info" data-id="${c.id}">${ic('eye')} Ma’lumotlar</button>
      <button class="${c.frozen ? 'on' : ''}" data-action="card-freeze" data-id="${c.id}">${c.frozen ? 'Blokdan chiqarish' : 'Vaqtincha bloklash'}</button>
    </div>
  </div>`;
}

function cardsView() {
  return `
  <div class="page-head">
    <div class="row"><div><h1>Kartalar</h1><p>${state.cards.length} ta karta · Paynet hamyoni</p></div></div>
  </div>
  ${state.cards.map(cardHtml).join('')}
  <div class="hint">${ic('shield')} Kartalar 3D Secure va dinamik CVV bilan himoyalangan. Shubhali amalda kartani bir zumda bloklang.</div>`;
}

function settingsView() {
  return `
  <div class="page-head"><h1>Profil</h1><p>Hisob va xavfsizlik sozlamalari</p></div>

  <button class="profile-card" data-action="open-profile">
    <div class="avatar">${avatarInner()}</div>
    <div><b>${esc(state.name)}</b><span>${esc(state.phone)}</span></div>
    <span class="badge">Premium</span>
  </button>

  <div class="group-label">Ko‘rinish</div>
  <div class="group">
    <button class="row-item" data-action="open-profile">
      <span class="r-ic">${ic('edit')}</span>
      <span class="r-main"><b>Profilni tahrirlash</b><span>Ism, telefon raqami va rasm</span></span>
      <span class="chev">${ic('chevronRight')}</span>
    </button>
    <div class="row-item">
      <span class="r-ic">${ic(state.theme === 'light' ? 'sun' : 'moon')}</span>
      <span class="r-main"><b>Qorong‘u rejim</b><span>Shaffof qorong‘u interfeys</span></span>
      <button class="switch ${state.theme === 'dark' ? 'on' : ''}" data-action="toggle-theme" aria-label="Qorong‘u rejim" aria-pressed="${state.theme === 'dark'}"></button>
    </div>
    <div class="row-item">
      <span class="r-ic">${ic('globe')}</span>
      <span class="r-main"><b>Til</b><span>O‘zbekcha (lotin)</span></span>
      <span class="value">UZ</span>
    </div>
  </div>

  <div class="group-label">Xavfsizlik</div>
  <div class="group">
    <button class="row-item" data-action="change-pin">
      <span class="r-ic">${ic('key')}</span>
      <span class="r-main"><b>Kirish paroli</b><span>4 xonali parolni o‘zgartirish</span></span>
      <span class="chev">${ic('chevronRight')}</span>
    </button>
    ${toggleRow('Biometrik kirish', 'Face ID / barmoq izi', 'finger', 'biometric')}
    ${toggleRow('Ikki bosqichli himoya', 'SMS kod bilan tasdiqlash', 'shield', 'twofa')}
    ${toggleRow('Bildirishnomalar', 'To‘lov va kirim xabarlari', 'bell', 'notify')}
    ${toggleRow('Balansni yashirish', 'Bosh sahifada balans yopiq', 'eyeOff', 'hideBalance')}
  </div>

  <div class="group-label">Qurilmalar</div>
  <div class="group">
    <button class="row-item" data-action="devices">
      <span class="r-ic">${ic('devices')}</span>
      <span class="r-main"><b>Faol qurilmalar</b><span>2 ta sessiya</span></span>
      <span class="chev">${ic('chevronRight')}</span>
    </button>
  </div>

  <button class="btn btn-danger" style="margin-top:16px" data-action="logout">${ic('logout')} Hisobdan chiqish</button>
  <div class="foot-note">Paynet Bank · demo ilova<br/>Parolni hech kimga bermang</div>`;
}

function profileView() {
  return `
  <div class="page-head">
    <div class="row">
      <button class="icon-btn soft" data-action="go" data-route="settings" aria-label="Orqaga">${ic('chevronLeft')}</button>
      <div><h1>Profil</h1><p>Ism, telefon va rasmni o‘zgartiring</p></div>
    </div>
  </div>

  <div class="profile-hero">
    <div class="avatar xl">${avatarInner()}</div>
    <label class="avatar-pick">${ic('camera')} Rasm tanlash<input type="file" accept="image/*" data-avatar /></label>
    ${state.avatar ? `<button class="link-btn" data-action="remove-avatar">Rasmni o‘chirish</button>` : ''}
    <b>${esc(state.name)}</b>
    <span>${esc(state.phone)}</span>
  </div>

  <div class="field">
    <label>Ism sharif</label>
    <input data-input="name" value="${esc(state.name)}" placeholder="Ism sharif" autocomplete="off" />
  </div>
  <div class="field">
    <label>Telefon raqami</label>
    <input data-input="phone" value="${esc(state.phone)}" placeholder="+998 90 000 00 00" inputmode="tel" autocomplete="off" />
  </div>
  <button class="btn btn-primary" style="margin-top:16px" data-action="save-profile">${ic('check')} Saqlash</button>
  <div class="hint">${ic('info')} Ma’lumotlar faqat shu qurilmada saqlanadi.</div>`;
}

function paymentsView() {
  return `
  <div class="page-head"><h1>To‘lovlar</h1><p>Kommunal, aloqa va boshqa xizmatlar</p></div>
  <div class="services" style="grid-template-columns:repeat(3,1fr);gap:10px">
    ${PAY_CATEGORIES.map(c => `<button class="service" data-action="pay-cat" data-cat="${c.id}" style="padding:18px 6px">
      <span class="s-ic" style="--tone:${c.color};--tone-bg:${c.bg}">${ic(c.icon)}</span><span>${c.name}</span></button>`).join('')}
  </div>

  <div class="section" style="margin-top:20px">
    <div class="section-head"><h3>Ko‘p ishlatilgan</h3><span style="font-size:11.5px;font-weight:600;color:var(--muted)">oxirgi 30 kun</span></div>
    <div class="tx-list">
      ${[['Uzmobile', 'Mobil aloqa operatori', 'mobile', 'smartphone'],
         ['Hududgaz', 'Gaz to‘lovi', 'utility', 'bolt'],
         ['UZONLINE', 'Uy interneti', 'internet', 'wifi'],
         ['Yandex Go', 'Taxi xizmati', 'transport', 'car']].map(([name, note, cat, icon]) => {
           const c = CATS[cat];
           return `<button class="person" data-action="pay-service" data-name="${name}" data-note="${note}" data-cat="${cat}">
             <span class="tx-ic" style="--tone:${c.color};--tone-bg:${c.bg}">${ic(icon)}</span>
             <span class="tx-main"><b>${name}</b><span>${note}</span></span>
             <span class="go">${ic('chevronRight')}</span>
           </button>`;
         }).join('')}
    </div>
  </div>`;
}

/* ------------------------------------------------------------------ flow views */
function flowView() {
  const f = app.flow;
  if (!f) return homeView();
  if (f.step === 'done') return doneView(f);
  if (f.kind === 'transfer') {
    if (f.step === 'recipient') return recipientView(f);
    if (f.step === 'amount') return amountView(f);
    if (f.step === 'review') return reviewView(f);
  }
  if (f.kind === 'payment') {
    if (f.step === 'service') return serviceView(f);
    if (f.step === 'amount') return amountView(f);
    if (f.step === 'review') return reviewView(f);
  }
  if (f.kind === 'topup') {
    if (f.step === 'amount') return amountView(f);
    if (f.step === 'review') return reviewView(f);
  }
  return homeView();
}

function flowHead(kicker, title) {
  return `<div class="flow-head">
    <button class="icon-btn soft" data-action="flow-back" aria-label="Orqaga">${ic('chevronLeft')}</button>
    <div><p>${kicker}</p><h2>${title}</h2></div>
  </div>`;
}

function recipientView(f) {
  return `${flowHead('Paynet Bank', 'O‘tkazma')}
  <p class="eyebrow" style="margin:0 4px 6px">Saqlangan kontaktlar</p>
  <div class="tx-list">
    ${CONTACTS.map(c => `<button class="person" data-action="pick-contact" data-name="${c.name}" data-detail="${c.detail}" data-bank="${c.bank}">
      <span class="avatar" style="background:${c.bg};color:${c.ink}">${c.initials}</span>
      <span class="tx-main"><b>${c.name}</b><span>${c.bank} · ${c.detail}</span></span>
      <span class="go">${ic('chevronRight')}</span>
    </button>`).join('')}
  </div>

  <div class="group-label" style="padding-left:4px">Yangi karta</div>
  <div class="field"><label>Karta raqami</label>
    <input data-input="card" inputmode="numeric" autocomplete="off" maxlength="19" placeholder="8600 0000 0000 0000" value="${esc(f.card || '')}" /></div>
  <div class="field"><label>Qabul qiluvchi ismi</label>
    <input data-input="cardName" autocomplete="off" placeholder="Ism sharif" value="${esc(f.cardName || '')}" /></div>
  <button class="btn btn-primary" style="margin-top:16px" data-action="custom-recipient">Davom etish</button>`;
}

function serviceView(f) {
  const cat = PAY_CATEGORIES.find(c => c.id === f.cat) || PAY_CATEGORIES[0];
  const list = PAY_SERVICES[cat.id] || [];
  return `${flowHead(cat.name, 'Xizmatni tanlang')}
  <div class="tx-list">
    ${list.map(s => `<button class="person" data-action="pay-service" data-name="${s.name}" data-note="${s.note}" data-cat="${cat.id}">
      <span class="tx-ic" style="--tone:${cat.color};--tone-bg:${cat.bg}">${ic(cat.icon)}</span>
      <span class="tx-main"><b>${s.name}</b><span>${s.note}</span></span>
      <span class="go">${ic('chevronRight')}</span>
    </button>`).join('')}
  </div>`;
}

function amountView(f) {
  const kicker = f.kind === 'payment' ? 'To‘lov' : f.kind === 'topup' ? 'Balans' : 'O‘tkazma';
  const title = f.kind === 'payment' ? 'To‘lov miqdori' : f.kind === 'topup' ? 'To‘ldirish miqdori' : 'O‘tkazma miqdori';
  const targetIcon = f.kind === 'payment' ? 'grid' : f.kind === 'topup' ? 'plus' : 'send';
  const target = f.kind === 'payment' ? f.service.name : f.kind === 'topup' ? 'Humo •••• 4821' : f.to.name;
  const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '000', '0', 'del'];
  return `${flowHead(kicker, title)}
  <div class="amount-panel">
    <span class="to">${ic(targetIcon)} ${target}</span>
    <div class="amount-display"><span>${fmt(f.amount)}</span><i>so‘m</i></div>
    <p class="amount-hint">Mavjud balans: <b>${fmt(mainCard().amount)} so‘m</b></p>
    <div class="chips">
      ${[50000, 100000, 200000, 500000].map(v => `<button class="chip" data-action="amount-quick" data-v="${v}">${fmt(v)}</button>`).join('')}
    </div>
  </div>
  <div class="keypad">
    ${keys.map(k => k === 'del'
      ? `<button class="key ghost" data-action="amount-del" ${f.amount ? '' : 'disabled'} aria-label="O‘chirish">${ic('backspace')}</button>`
      : `<button class="key" data-action="amount-digit" data-k="${k}">${k}</button>`).join('')}
  </div>
  <button class="btn btn-primary" data-action="flow-next" ${f.amount > 0 ? '' : 'disabled'}>Davom etish</button>`;
}

function reviewView(f) {
  const rows = f.kind === 'payment'
    ? [['Xizmat', f.service.name], ['Kategoriya', f.service.note], ['To‘lov usuli', 'Paynet hamyoni']]
    : f.kind === 'topup'
      ? [['Karta', 'Humo •••• 4821'], ['Manba', 'Paynet hamyoni']]
      : [['Qabul qiluvchi', f.to.name], ['Karta', f.to.detail], ['Bank', f.to.bank]];
  const title = f.kind === 'payment' ? 'To‘lovni tasdiqlash' : f.kind === 'topup' ? 'To‘ldirishni tasdiqlash' : 'O‘tkazmani tasdiqlash';
  return `${flowHead('Tekshirib chiqing', title)}
  <div class="card review">
    ${rows.map(([k, v]) => sheetRow(k, esc(v))).join('')}
    ${sheetRow('Komissiya', '0 so‘m')}
    <div class="review-row total"><span>Jami</span><b>${fmt(f.amount)} so‘m</b></div>
  </div>
  <div class="hint">${ic('shield')} Amal 4 xonali parol bilan tasdiqlanadi. Parolni hech kimga bermang.</div>
  <button class="btn btn-primary" style="margin-top:14px" data-action="flow-confirm">${ic('lock')} Tasdiqlash</button>`;
}

function doneView(f) {
  const t = state.transactions.find(x => x.id === f.txId) || { id: rid(), ts: new Date().toISOString() };
  const isPayment = f.kind === 'payment';
  const label = f.kind === 'topup' ? 'Balans to‘ldirildi' : isPayment ? 'To‘lov amalga oshirildi' : 'O‘tkazma yuborildi';
  const target = isPayment ? f.service.name : f.kind === 'topup' ? 'Humo •••• 4821' : f.to.name;
  return `<div class="success">
    <div class="success-ring">${ic('check')}</div>
    <h2>${label}</h2>
    <p>${esc(target)}</p>
    <div class="done-amount">${f.kind === 'topup' ? '+' : '−'}${fmt(f.amount)}
      <span style="font-size:14px;font-weight:600;color:var(--muted)">so‘m</span></div>
    <div class="receipt">
      ${sheetRow('Holat', '<span style="color:var(--green-700)">Muvaffaqiyatli</span>')}
      ${sheetRow('Sana', `${dateShort(new Date(t.ts))} · ${nowTime(new Date(t.ts))}`)}
      ${sheetRow('Amal ID', t.id)}
      ${sheetRow('Qolgan balans', `${fmt(mainCard().amount)} so‘m`)}
    </div>
    <div class="btn-row" style="margin-top:18px">
      <button class="btn btn-ghost" data-action="flow-again">Yana</button>
      <button class="btn btn-primary" data-action="flow-home">Bosh sahifa</button>
    </div>
  </div>`;
}

/* ------------------------------------------------------------------ render */
function routeView() {
  switch (app.route) {
    case 'history': return historyView();
    case 'monitoring': return monitoringView();
    case 'cards': return cardsView();
    case 'settings': return settingsView();
    case 'profile': return profileView();
    case 'payments': return paymentsView();
    case 'flow': return flowView();
    default: return homeView();
  }
}

function renderTabs() {
  const nav = document.getElementById('tabbar');
  nav.innerHTML = TABS.map(t =>
    `<button class="tab ${app.route === t.id ? 'active' : ''}" data-action="go" data-route="${t.id}">
      ${ic(t.icon)}<span>${t.label}</span>
    </button>`).join('');
}

function afterRender() {
  if (app.eventTimer) { clearInterval(app.eventTimer); app.eventTimer = null; }
  if (app.route !== 'monitoring') return;
  app.eventTimer = setInterval(() => {
    const pool = [
      'Karta tranzaksiyasi shifrlandi · TLS 1.3',
      'Yangi sessiya tasdiqlandi · iPhone 15',
      'Hisob balansi sinxronlashtirildi',
      'To‘lov shlyuzi javobi · 200 OK',
      'Xavfsizlik tekshiruvi yakunlandi',
      'Push bildirishnoma yuborildi'
    ];
    app.events.unshift({ text: pool[Math.floor(Math.random() * pool.length)], time: nowTime(new Date()), warn: Math.random() < .2 });
    app.events = app.events.slice(0, 6);
    const list = document.getElementById('liveEvents');
    if (list) list.innerHTML = app.events.map(eventRow).join('');
  }, 7000);
}

function render(keepScroll) {
  const view = document.getElementById('view');
  const top = view.scrollTop;
  view.innerHTML = routeView();
  view.scrollTop = keepScroll ? top : 0;
  renderTabs();
  afterRender();
}

function show(route) {
  app.route = route;
  render();
}

function go(route) {
  app.flow = null;
  if (app.route === route) { render(); return; }
  if (location.hash === '#/' + route) { app.route = route; render(); }
  else location.hash = '#/' + route;
}

/* ------------------------------------------------------------------ sheet + toast */
function openSheet(html) {
  const layer = document.getElementById('sheetLayer');
  layer.innerHTML = `<div class="sheet-backdrop" data-action="close-sheet"></div>
    <div class="sheet" role="dialog" aria-modal="true"><div class="sheet-grip"></div>${html}</div>`;
  layer.classList.add('open');
}

function closeSheet() {
  const layer = document.getElementById('sheetLayer');
  layer.classList.remove('open');
  setTimeout(() => { if (!layer.classList.contains('open')) layer.innerHTML = ''; }, 320);
}

let toastTimer;
function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
}

/* ------------------------------------------------------------------ details */
function openTx(id) {
  const t = state.transactions.find(x => x.id === id);
  if (!t) return;
  const c = CATS[t.cat] || CATS.payment;
  const d = new Date(t.ts);
  openSheet(`
    <div class="sheet-head"><h3>Amal tafsiloti</h3>
      <button class="sheet-close" data-action="close-sheet" aria-label="Yopish">${ic('close')}</button></div>
    <div style="text-align:center;padding:2px 0 16px">
      <span class="tx-ic" style="--tone:${c.color};--tone-bg:${c.bg};width:54px;height:54px;border-radius:18px;margin:0 auto 10px">${ic(c.icon)}</span>
      <div style="font-size:26px;font-weight:820;letter-spacing:-1px;color:${t.dir === 'in' ? 'var(--green-700)' : 'var(--ink)'}">
        ${t.dir === 'in' ? '+' : '−'}${fmt(t.amount)} <span style="font-size:13px;font-weight:600;color:var(--muted)">so‘m</span></div>
      <div class="muted" style="font-size:12.5px;margin-top:4px">${esc(t.title)}</div>
    </div>
    <div class="group" style="margin-top:0">
      ${sheetRow('Holat', '<span style="color:var(--green-700)">Bajarildi</span>')}
      ${sheetRow('Kategoriya', c.label)}
      ${sheetRow('Sana', `${dateShort(d)} · ${nowTime(d)}`)}
      ${sheetRow('Amal ID', t.id)}
      ${sheetRow('Izoh', esc(t.note))}
    </div>
    <button class="btn btn-ghost btn-sm" style="margin-top:14px" data-action="repeat-tx" data-id="${t.id}">${ic('send')} Takrorlash</button>
  `);
}

function openCard(id) {
  const c = state.cards.find(x => x.id === id);
  if (!c) return;
  openSheet(`
    <div class="sheet-head"><h3>Karta ma’lumotlari</h3>
      <button class="sheet-close" data-action="close-sheet" aria-label="Yopish">${ic('close')}</button></div>
    ${cardHtml(c)}
    <div class="group" style="margin-top:0">
      ${sheetRow('Karta raqami', c.pan)}
      ${sheetRow('Amal muddati', c.exp)}
      ${sheetRow('Karta turi', c.kind)}
      ${sheetRow('Holat', c.frozen ? 'Bloklangan' : 'Faol')}
      ${sheetRow('Balans', `${fmt(c.amount)} so‘m`)}
    </div>
    <div class="hint">${ic('lock')} Karta ma’lumotlarini uchinchi shaxslarga bermang.</div>
  `);
}

function openAlerts() {
  openSheet(`
    <div class="sheet-head"><h3>Bildirishnomalar</h3>
      <button class="sheet-close" data-action="close-sheet" aria-label="Yopish">${ic('close')}</button></div>
    ${state.alerts.map(a => `<div class="notif">
      <span class="n-ic">${ic(a.icon)}</span>
      <div><b>${esc(a.title)}</b><p>${esc(a.text)}</p><time>${esc(a.time)}</time></div>
    </div>`).join('')}
  `);
}

function openDevices() {
  openSheet(`
    <div class="sheet-head"><h3>Faol qurilmalar</h3>
      <button class="sheet-close" data-action="close-sheet" aria-label="Yopish">${ic('close')}</button></div>
    <div class="tx-list">
      <div class="person"><span class="tx-ic">${ic('smartphone')}</span>
        <span class="tx-main"><b>iPhone 15 · bu qurilma</b><span>Toshkent · hozir faol</span></span></div>
      <div class="person"><span class="tx-ic">${ic('devices')}</span>
        <span class="tx-main"><b>MacBook Air</b><span>Toshkent · 2 soat oldin</span></span></div>
    </div>
    <div class="hint">${ic('shield')} Notanish qurilma ko‘rsangiz, parolni o‘zgartiring.</div>
  `);
}

/* ------------------------------------------------------------------ pin lock */
const pin = { digits: '', ctx: null, error: '', shake: false };

function askPin(opts) {
  pin.digits = '';
  pin.error = '';
  pin.shake = false;
  pin.ctx = Object.assign({ title: 'Parolni kiriting', subtitle: '', verify: true, onSuccess: null }, opts);
  document.getElementById('pinLayer').hidden = false;
  renderPin();
}

function renderPin() {
  const layer = document.getElementById('pinLayer');
  const c = pin.ctx || {};
  const dots = [0, 1, 2, 3].map(i => `<span class="pin-dot ${i < pin.digits.length ? 'filled' : ''}"></span>`).join('');
  const hint = c.verify ? 'Demo parol: 1234' : '4 xonali parol';
  layer.innerHTML = `
    <div class="pin-brand"><span class="brand-mark">P</span><b>Paynet</b></div>
    ${ic('lock', 'pin-lock')}
    <h2 class="pin-title">${esc(c.title)}</h2>
    <p class="pin-sub">${esc(c.subtitle)}</p>
    <div class="pin-dots ${pin.shake ? 'pin-shake' : ''}">${dots}</div>
    <div class="pin-error ${pin.error ? 'show' : ''}">${esc(pin.error)}</div>
    <div class="pin-keypad">
      ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button class="pin-key" data-action="pin-digit" data-n="${n}">${n}</button>`).join('')}
      <button class="pin-key flat" data-action="pin-bio" aria-label="Biometrik kirish">${ic('finger')}</button>
      <button class="pin-key" data-action="pin-digit" data-n="0">0</button>
      <button class="pin-key flat" data-action="pin-del" aria-label="O‘chirish">${ic('backspace')}</button>
    </div>
    <p class="pin-hint">${hint}</p>`;
}

function failPin(msg) {
  pin.error = msg;
  pin.digits = '';
  pin.shake = true;
  renderPin();
  setTimeout(() => { pin.shake = false; }, 420);
  if (navigator.vibrate) navigator.vibrate(70);
}

function closePin() {
  const layer = document.getElementById('pinLayer');
  layer.hidden = true;
  layer.innerHTML = '';
  pin.ctx = null;
  pin.digits = '';
  pin.error = '';
}

function checkPin() {
  const c = pin.ctx;
  if (!c) return;
  const entered = pin.digits.slice(0, 4);
  if (c.verify && entered !== String(state.pin)) {
    failPin('Parol noto‘g‘ri. Qayta urinib ko‘ring');
    return;
  }
  closePin();
  if (typeof c.onSuccess === 'function') c.onSuccess(entered);
}

function lockApp() {
  askPin({
    title: 'Xush kelibsiz',
    subtitle: `${state.name} · hisobingizga kirish uchun parolni kiriting`,
    verify: true,
    onSuccess: () => {}
  });
}

function changePin() {
  askPin({
    title: 'Joriy parolni kiriting',
    subtitle: 'Xavfsizlik uchun amaldagi parolni tasdiqlang',
    verify: true,
    onSuccess: () => {
      askPin({
        title: 'Yangi parol',
        subtitle: '4 xonali yangi parol o‘ylab toping',
        verify: false,
        onSuccess: p1 => {
          askPin({
            title: 'Parolni tasdiqlang',
            subtitle: 'Yangi parolni qayta kiriting',
            verify: false,
            onSuccess: p2 => {
              if (p1 !== p2) { toast('Parollar mos kelmadi'); return; }
              state.pin = p2;
              save();
              toast('Kirish paroli yangilandi');
            }
          });
        }
      });
    }
  });
}

/* ------------------------------------------------------------------ flows */
function startFlow(flow) {
  app.flow = Object.assign({ amount: 0 }, flow);
  show('flow');
}

function newTransfer() {
  startFlow({ kind: 'transfer', step: 'recipient' });
}

function commitFlow() {
  const f = app.flow;
  if (!f) return;
  const d = new Date();
  if (f.kind === 'topup') {
    mainCard().amount += f.amount;
    const tx = {
      id: rid(), dir: 'in', title: 'Balans to‘ldirish',
      note: `Paynet hamyon · ${mainCard().kind} •••• ${mainCard().last4}`,
      amount: f.amount, cat: 'income', ts: d.toISOString()
    };
    state.transactions.unshift(tx);
    f.txId = tx.id;
  } else {
    if (f.amount > mainCard().amount) { toast('Balansda mablag‘ yetarli emas'); return; }
    mainCard().amount -= f.amount;
    const isPayment = f.kind === 'payment';
    const tx = {
      id: rid(), dir: 'out',
      title: isPayment ? f.service.name : f.to.name,
      note: isPayment ? `To‘lov · ${f.service.note}` : `O‘tkazma · ${f.to.bank} ${f.to.detail}`,
      amount: f.amount, cat: isPayment ? f.service.cat : 'transfer', ts: d.toISOString()
    };
    state.transactions.unshift(tx);
    f.txId = tx.id;
  }
  f.step = 'done';
  save();
  render();
  toast('Amal muvaffaqiyatli bajarildi');
}

function updateAmountUI() {
  const f = app.flow;
  if (!f) return;
  const display = document.querySelector('.amount-display span');
  if (display) display.textContent = fmt(f.amount);
  const next = document.querySelector('[data-action="flow-next"]');
  if (next) next.disabled = !(f.amount > 0);
  const del = document.querySelector('[data-action="amount-del"]');
  if (del) del.disabled = !f.amount;
}

function goBackInFlow() {
  const f = app.flow;
  if (!f) { go('home'); return; }
  if (f.step === 'done') { go('home'); return; }
  if (f.step === 'review') { f.step = 'amount'; render(); return; }
  if (f.step === 'amount') {
    if (f.kind === 'transfer') { f.step = 'recipient'; render(); return; }
    if (f.kind === 'payment') { f.step = 'service'; render(); return; }
    go('home');
    return;
  }
  if (f.step === 'service') { go('payments'); return; }
  if (f.step === 'recipient') { go('home'); return; }
  go('home');
}

function maskPan(value) {
  const digits = value.replace(/\D/g, '').slice(0, 16);
  return digits.replace(/(.{4})/g, '$1 ').trim();
}

/* ------------------------------------------------------------------ actions */
const ACTIONS = {
  go: d => go(d.route),
  alerts: () => openAlerts(),
  devices: () => openDevices(),
  'toggle-balance': () => { state.hideBalance = !state.hideBalance; save(); render(); },
  'toggle-setting': d => {
    if (d.key === 'hideBalance') state.hideBalance = !state.hideBalance;
    else state.settings[d.key] = !state.settings[d.key];
    save();
    render();
  },
  'new-transfer': () => newTransfer(),
  topup: () => startFlow({ kind: 'topup', step: 'amount' }),
  'pay-cat': d => startFlow({ kind: 'payment', step: 'service', cat: d.cat }),
  'pay-service': d => {
    const f = app.flow;
    if (!f) return;
    f.service = { name: d.name, note: d.note, cat: d.cat };
    f.step = 'amount';
    render();
  },
  'pick-contact': d => {
    const f = app.flow;
    if (!f) return;
    f.to = { name: d.name, detail: d.detail, bank: d.bank };
    f.step = 'amount';
    render();
  },
  'custom-recipient': () => {
    const f = app.flow;
    if (!f) return;
    const digits = String(f.card || '').replace(/\D/g, '');
    if (digits.length < 16) { toast('Karta raqamini to‘liq kiriting'); return; }
    f.to = {
      name: (f.cardName || '').trim() || 'Yangi qabul qiluvchi',
      detail: '•••• ' + digits.slice(-4),
      bank: 'Paynet'
    };
    f.step = 'amount';
    render();
  },
  'amount-digit': d => {
    const f = app.flow;
    if (!f) return;
    f.amount = Math.min(99999999, Number(String(f.amount) + d.k));
    updateAmountUI();
  },
  'amount-del': () => {
    const f = app.flow;
    if (!f) return;
    f.amount = Math.floor(f.amount / 10);
    updateAmountUI();
  },
  'amount-quick': d => {
    const f = app.flow;
    if (!f) return;
    f.amount = Number(d.v);
    updateAmountUI();
  },
  'flow-next': () => {
    const f = app.flow;
    if (!f || !f.amount) return;
    if (f.kind !== 'topup' && f.amount > mainCard().amount) { toast('Balansda mablag‘ yetarli emas'); return; }
    f.step = 'review';
    render();
  },
  'flow-back': () => goBackInFlow(),
  'flow-confirm': () => {
    const f = app.flow;
    if (!f) return;
    askPin({
      title: 'Amalni tasdiqlang',
      subtitle: `${fmt(f.amount)} so‘m · parolni kiriting`,
      verify: true,
      onSuccess: () => commitFlow()
    });
  },
  'flow-home': () => go('home'),
  'flow-again': () => {
    const f = app.flow;
    if (!f) { go('home'); return; }
    if (f.kind === 'payment') app.flow = { kind: 'payment', step: 'service', cat: f.service.cat, amount: 0 };
    else if (f.kind === 'topup') app.flow = { kind: 'topup', step: 'amount', amount: 0 };
    else app.flow = { kind: 'transfer', step: 'recipient', amount: 0 };
    render();
  },
  filter: d => { app.filter = d.filter; render(true); },
  'tx-detail': d => openTx(d.id),
  'card-info': d => openCard(d.id),
  'card-freeze': d => {
    const card = state.cards.find(c => c.id === d.id);
    if (!card) return;
    card.frozen = !card.frozen;
    save();
    render();
    toast(card.frozen ? 'Karta vaqtincha bloklandi' : 'Karta faollashtirildi');
  },
  'repeat-tx': d => {
    const t = state.transactions.find(x => x.id === d.id);
    if (!t) return;
    closeSheet();
    startFlow({
      kind: 'transfer', step: 'amount', amount: t.amount,
      to: { name: t.title, detail: 'Takroriy amal', bank: 'Paynet' }
    });
  },
  'toggle-theme': () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    save();
    render();
  },
  'open-profile': () => go('profile'),
  'save-profile': () => {
    const nameEl = document.querySelector('[data-input="name"]');
    const phoneEl = document.querySelector('[data-input="phone"]');
    const name = (nameEl ? nameEl.value : '').trim();
    const phone = (phoneEl ? phoneEl.value : '').trim();
    if (name.length < 2) { toast('Ismni to‘liq kiriting'); return; }
    if (phone.replace(/\D/g, '').length < 7) { toast('Telefon raqamini kiriting'); return; }
    state.name = name;
    state.phone = phone;
    save();
    go('settings');
    toast('Profil yangilandi');
  },
  'remove-avatar': () => { state.avatar = ''; save(); render(); toast('Profil rasmi o‘chirildi'); },
  'card-send': d => {
    const c = state.cards.find(x => x.id === d.id);
    if (!c) return;
    startFlow({ kind: 'transfer', step: 'amount', amount: 0, to: { name: `${c.kind} •••• ${c.last4}`, detail: `•••• ${c.last4}`, bank: 'Paynet' } });
  },
  'change-pin': () => changePin(),
  logout: () => {
    toast('Hisobdan chiqdingiz');
    go('home');
    setTimeout(lockApp, 220);
  },
  'close-sheet': () => closeSheet(),
  'pin-digit': d => {
    if (!pin.ctx) return;
    if (pin.error) { pin.error = ''; }
    pin.digits += d.n;
    if (pin.digits.length >= 4) checkPin();
    else renderPin();
  },
  'pin-del': () => {
    if (!pin.ctx) return;
    pin.digits = pin.digits.slice(0, -1);
    pin.error = '';
    renderPin();
  },
  'pin-bio': () => {
    const c = pin.ctx;
    if (!c) return;
    if (!state.settings.biometric) { toast('Biometrik kirish o‘chirilgan'); return; }
    if (!c.verify) { toast('Bu amal uchun parol kerak'); return; }
    closePin();
    toast('Barmoq izi tasdiqlandi');
    if (typeof c.onSuccess === 'function') c.onSuccess(state.pin);
  }
};

/* ------------------------------------------------------------------ events */
document.addEventListener('click', e => {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const fn = ACTIONS[el.dataset.action];
  if (!fn) return;
  e.preventDefault();
  fn(el.dataset, el, e);
});

document.addEventListener('input', e => {
  const t = e.target;
  if (t.matches('[data-search]')) {
    app.q = t.value;
    const list = document.getElementById('historyList');
    if (list) list.innerHTML = historyList(filteredTx());
    return;
  }
  if (t.matches('[data-input="name"]') || t.matches('[data-input="phone"]')) {
    const hero = document.querySelector('.profile-hero');
    if (hero) {
      const b = hero.querySelector('b');
      const sp = hero.querySelector('span');
      const n = document.querySelector('[data-input="name"]');
      const p = document.querySelector('[data-input="phone"]');
      if (b && n) b.textContent = n.value || 'Ism sharif';
      if (sp && p) sp.textContent = p.value || '+998 00 000 00 00';
    }
    return;
  }
  if (!app.flow) return;
  if (t.matches('[data-input="card"]')) {
    t.value = maskPan(t.value);
    app.flow.card = t.value;
  } else if (t.matches('[data-input="cardName"]')) {
    app.flow.cardName = t.value;
  }
});

document.addEventListener('change', e => {
  const input = e.target.closest('[data-avatar]');
  if (!input || !input.files || !input.files[0]) return;
  pickAvatar(input.files[0]);
});

window.addEventListener('hashchange', () => {
  const route = (location.hash || '').replace(/^#\//, '') || 'home';
  app.route = ['home', 'history', 'monitoring', 'cards', 'settings', 'profile', 'payments'].includes(route) ? route : 'home';
  app.flow = null;
  render();
});

/* ------------------------------------------------------------------ boot */
(function init() {
  app.events = [
    { text: 'Xavfsiz ulanish o‘rnatildi · TLS 1.3', time: nowTime(new Date()) },
    { text: 'Karta tokeni yangilandi · Humo •••• 4821', time: '09:38' },
    { text: 'Balans sinxronlashtirildi', time: '09:36' },
    { text: 'Yangi qurilma aniqlandi · iPhone 15', time: '09:12', warn: true }
  ];

  const hashRoute = (location.hash || '').replace(/^#\//, '');
  if (['home', 'history', 'monitoring', 'cards', 'settings', 'profile', 'payments'].includes(hashRoute)) app.route = hashRoute;
  applyTheme();
  render();
  lockApp();
})();
