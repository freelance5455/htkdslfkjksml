const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORAGE = "studyBuddy_v1";
const defaultState = {
  profile:{name:"Student",class:"11",board:"Tamil Nadu State Board",medium:"en",stream:"science",group:"2502"},
  notes:[],tasks:[],completed:0,theme:"light"
};
let state = loadState();
function loadState(){try{return {...defaultState,...JSON.parse(localStorage.getItem(STORAGE)||"{}")}}catch(e){return structuredClone(defaultState)}}
function saveState(){localStorage.setItem(STORAGE,JSON.stringify(state));if(window.studyBuddyCloudSave)window.studyBuddyCloudSave(state);renderAll()}
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>el.classList.remove("show"),2200)}

const groups = {
 science:[
  {code:"2501",name:"Physics • Chemistry • Statistics • Mathematics",subjects:["Physics","Chemistry","Statistics","Mathematics"]},
  {code:"2502",name:"Physics • Chemistry • Computer Science • Mathematics",subjects:["Physics","Chemistry","Computer Science","Mathematics"]},
  {code:"2503",name:"Physics • Chemistry • Biology • Mathematics",subjects:["Physics","Chemistry","Biology","Mathematics"]},
  {code:"2504",name:"Physics • Chemistry • Biochemistry • Mathematics",subjects:["Physics","Chemistry","Biochemistry","Mathematics"]},
  {code:"2505",name:"Physics • Chemistry • Communicative English • Mathematics",subjects:["Physics","Chemistry","Communicative English","Mathematics"]},
  {code:"2506",name:"Physics • Chemistry • Mathematics • Home Science",subjects:["Physics","Chemistry","Mathematics","Home Science"]},
  {code:"2601",name:"Physics • Chemistry • Biology • Computer Science",subjects:["Physics","Chemistry","Biology","Computer Science"]},
  {code:"2602",name:"Physics • Chemistry • Biology • Microbiology",subjects:["Physics","Chemistry","Biology","Microbiology"]},
  {code:"2603",name:"Physics • Chemistry • Biology • Biochemistry",subjects:["Physics","Chemistry","Biology","Biochemistry"]},
  {code:"2604",name:"Physics • Chemistry • Biology • Nursing",subjects:["Physics","Chemistry","Biology","Nursing"]},
  {code:"2605",name:"Physics • Chemistry • Biology • Nutrition and Dietetics",subjects:["Physics","Chemistry","Biology","Nutrition and Dietetics"]},
  {code:"2608",name:"Physics • Chemistry • Botany • Zoology",subjects:["Physics","Chemistry","Botany","Zoology"]}
 ],
 commerce:[
  {code:"2701",name:"Statistics • Economics • Commerce • Accountancy",subjects:["Statistics","Economics","Commerce","Accountancy"]},
  {code:"2702",name:"Economics • Commerce • Accountancy • Computer Applications",subjects:["Economics","Commerce","Accountancy","Computer Applications"]},
  {code:"2703",name:"Communicative English • Economics • Commerce • Accountancy",subjects:["Communicative English","Economics","Commerce","Accountancy"]},
  {code:"2704",name:"History • Economics • Commerce • Accountancy",subjects:["History","Economics","Commerce","Accountancy"]},
  {code:"2705",name:"Economics • Political Science • Commerce • Accountancy",subjects:["Economics","Political Science","Commerce","Accountancy"]},
  {code:"2706",name:"Economics • Commerce • Accountancy • Ethics and Indian Culture",subjects:["Economics","Commerce","Accountancy","Ethics and Indian Culture"]},
  {code:"2707",name:"Economics • Commerce • Accountancy • Advanced Tamil",subjects:["Economics","Commerce","Accountancy","Advanced Tamil"]},
  {code:"2708",name:"Economics • Commerce • Accountancy • Business Mathematics and Statistics",subjects:["Economics","Commerce","Accountancy","Business Mathematics and Statistics"]}
 ],
 humanities:[
  {code:"2801",name:"Statistics • Geography • History • Economics",subjects:["Statistics","Geography","History","Economics"]},
  {code:"2802",name:"Geography • History • Economics • Computer Applications",subjects:["Geography","History","Economics","Computer Applications"]},
  {code:"2803",name:"Geography • Communicative English • History • Economics",subjects:["Geography","Communicative English","History","Economics"]},
  {code:"2804",name:"Geography • History • Economics • Political Science",subjects:["Geography","History","Economics","Political Science"]},
  {code:"2805",name:"Geography • History • Economics • Ethics and Indian Culture",subjects:["Geography","History","Economics","Ethics and Indian Culture"]},
  {code:"2806",name:"Geography • History • Economics • Advanced Tamil",subjects:["Geography","History","Economics","Advanced Tamil"]}
 ],
 vocational:[
  {code:"V-ENG",name:"Engineering and Technology vocational groups",subjects:["Basic Mechanical Engineering","Basic Electrical Engineering","Basic Electronics Engineering","Basic Civil Engineering","Basic Automobile Engineering"]},
  {code:"V-AGRI",name:"Agriculture and related vocational groups",subjects:["Agricultural Science","Horticulture","Agricultural Practices"]},
  {code:"V-HOME",name:"Home Science and service vocational groups",subjects:["Food Service Management","Textile and Dress Designing","Nutrition and Dietetics"]},
  {code:"V-COM",name:"Office, commerce and computer vocational groups",subjects:["Office Management","Computer Applications","Auditing"]}
 ],
 general:[{code:"10-GEN",name:"Class 10 – General curriculum",subjects:["Tamil","English","Mathematics","Science","Social Science"]}]
};
const commonSubjects=["Tamil","English"];
const subjectIcons={"Mathematics":"∑","Business Mathematics and Statistics":"∑","Physics":"⚛","Chemistry":"⚗","Biology":"⌁","Computer Science":"⌘","Statistics":"▥","Economics":"₹","Commerce":"▤","Accountancy":"▧","History":"◷","Geography":"◎","Political Science":"⚖","Tamil":"அ","English":"A","Malayalam":"മ"};
const mathChapters={
 "11":["Sets, Relations and Functions","Basic Algebra","Trigonometry","Combinatorics and Mathematical Induction","Binomial Theorem, Sequences and Series","Two Dimensional Analytical Geometry","Matrices and Determinants","Vector Algebra","Differential Calculus – Limits and Continuity","Differentiability and Methods of Differentiation","Integral Calculus","Introduction to Probability Theory"],
 "12":["Applications of Matrices and Determinants","Complex Numbers","Theory of Equations","Inverse Trigonometric Functions","Two Dimensional Analytical Geometry – II","Applications of Vector Algebra","Applications of Differential Calculus","Differentials and Partial Derivatives","Applications of Integration","Ordinary Differential Equations","Probability Distributions","Discrete Mathematics"]
};
const translations={
 en:{dashboard:"Dashboard",subjects:"My Subjects",maths:"Mathematics Hub",practice:"Practice & Tests",notes:"My Notes",planner:"Study Planner",resources:"Resources",settings:"Profile & Settings",welcomeBack:"WELCOME BACK",hello:"Hello",welcomeSub:"Your next learning milestone starts here.",heroTitle:"Make every study session count.",heroSub:"Learn at your pace, practise with purpose, and track your progress.",exploreSubjects:"Explore subjects →",subjectsSelected:"Subjects selected",tasksDone:"Tasks completed",notesSaved:"Notes saved",studyStreak:"Study streak",continueLearning:"CONTINUE LEARNING",yourLearning:"Your learning dashboard",viewAll:"View all →",quickAccess:"Quick access",quickSub:"Jump back into your learning",dailyTip:"Daily tip",tipText:"Small, consistent study sessions build strong results.",weeklyGoal:"Weekly goal",goalSub:"Build a steady routine",completed:"completed",openPlanner:"Open planner",mySubjectsTitle:"My Subjects",subjectsIntro:"Choose a subject to explore its learning area.",practiceTitle:"Practice & Tests",notesTitle:"My Notes",plannerTitle:"Study Planner",resourcesTitle:"Resources",profileTitle:"Profile & Settings"},
 ta:{dashboard:"முகப்பு",subjects:"என் பாடங்கள்",maths:"கணித மையம்",practice:"பயிற்சி மற்றும் தேர்வுகள்",notes:"என் குறிப்புகள்",planner:"படிப்பு திட்டம்",resources:"வளங்கள்",settings:"சுயவிவரம் மற்றும் அமைப்புகள்",welcomeBack:"மீண்டும் வரவேற்கிறோம்",hello:"வணக்கம்",welcomeSub:"உங்கள் அடுத்த கற்றல் இலக்கு இங்கே தொடங்குகிறது.",heroTitle:"ஒவ்வொரு படிப்பு நேரத்தையும் பயனுள்ளதாக மாற்றுங்கள்.",heroSub:"உங்கள் வேகத்தில் கற்று, பயிற்சி செய்து, முன்னேற்றத்தைக் கண்காணிக்கவும்.",exploreSubjects:"பாடங்களைப் பாருங்கள் →",subjectsSelected:"தேர்ந்தெடுத்த பாடங்கள்",tasksDone:"முடித்த பணிகள்",notesSaved:"சேமித்த குறிப்புகள்",studyStreak:"தொடர் படிப்பு",continueLearning:"தொடர்ந்து கற்கலாம்",yourLearning:"உங்கள் கற்றல் முகப்பு",viewAll:"அனைத்தையும் காண்க →",quickAccess:"விரைவு அணுகல்",quickSub:"கற்றலைத் தொடருங்கள்",dailyTip:"இன்றைய குறிப்பு",tipText:"தொடர்ச்சியான சிறிய படிப்பு நல்ல பலனைத் தரும்.",weeklyGoal:"வார இலக்கு",goalSub:"நல்ல படிப்பு பழக்கத்தை உருவாக்குங்கள்",completed:"முடிந்தது",openPlanner:"திட்டத்தைத் திறக்கவும்",mySubjectsTitle:"என் பாடங்கள்",subjectsIntro:"பாடத்தைத் தேர்ந்தெடுத்து கற்கத் தொடங்குங்கள்.",practiceTitle:"பயிற்சி மற்றும் தேர்வுகள்",notesTitle:"என் குறிப்புகள்",plannerTitle:"படிப்பு திட்டம்",resourcesTitle:"கற்றல் வளங்கள்",profileTitle:"சுயவிவரம் மற்றும் அமைப்புகள்"},
 ml:{dashboard:"ഡാഷ്ബോർഡ്",subjects:"എന്റെ വിഷയങ്ങൾ",maths:"ഗണിത പഠനകേന്ദ്രം",practice:"പരിശീലനവും പരീക്ഷകളും",notes:"എന്റെ കുറിപ്പുകൾ",planner:"പഠന പദ്ധതി",resources:"പഠന വിഭവങ്ങൾ",settings:"പ്രൊഫൈലും ക്രമീകരണങ്ങളും",welcomeBack:"വീണ്ടും സ്വാഗതം",hello:"നമസ്കാരം",welcomeSub:"നിങ്ങളുടെ അടുത്ത പഠനലക്ഷ്യം ഇവിടെ തുടങ്ങുന്നു.",heroTitle:"ഓരോ പഠനസമയവും പ്രയോജനകരമാക്കൂ.",heroSub:"നിങ്ങളുടെ വേഗത്തിൽ പഠിക്കൂ, പരിശീലിക്കൂ, പുരോഗതി നിരീക്ഷിക്കൂ.",exploreSubjects:"വിഷയങ്ങൾ കാണുക →",subjectsSelected:"തിരഞ്ഞെടുത്ത വിഷയങ്ങൾ",tasksDone:"പൂർത്തിയാക്കിയ ജോലികൾ",notesSaved:"സൂക്ഷിച്ച കുറിപ്പുകൾ",studyStreak:"പഠന തുടർച്ച",continueLearning:"പഠനം തുടരാം",yourLearning:"നിങ്ങളുടെ പഠന ഡാഷ്ബോർഡ്",viewAll:"എല്ലാം കാണുക →",quickAccess:"വേഗത്തിലുള്ള പ്രവേശനം",quickSub:"പഠനം തുടരുക",dailyTip:"ഇന്നത്തെ നിർദേശം",tipText:"ചെറിയതും സ്ഥിരവുമായ പഠനം മികച്ച ഫലം നൽകും.",weeklyGoal:"ആഴ്ചയിലെ ലക്ഷ്യം",goalSub:"സ്ഥിരമായ പഠനശീലം വളർത്തുക",completed:"പൂർത്തിയായി",openPlanner:"പ്ലാനർ തുറക്കുക",mySubjectsTitle:"എന്റെ വിഷയങ്ങൾ",subjectsIntro:"പഠിക്കാൻ ഒരു വിഷയം തിരഞ്ഞെടുക്കുക.",practiceTitle:"പരിശീലനവും പരീക്ഷകളും",notesTitle:"എന്റെ കുറിപ്പുകൾ",plannerTitle:"പഠന പദ്ധതി",resourcesTitle:"പഠന വിഭവങ്ങൾ",profileTitle:"പ്രൊഫൈലും ക്രമീകരണങ്ങളും"}
};
function currentGroup(){const arr=groups[state.profile.stream]||groups.science;return arr.find(g=>g.code===state.profile.group)||arr[0]}
function allSubjects(){const g=currentGroup();let list=[...g.subjects];if(state.profile.class!=="10")list=[...commonSubjects,...list];else list=[...g.subjects];return [...new Set(list)]}
function showView(name){$$(".view").forEach(v=>v.classList.toggle("active",v.id==="view-"+name));$$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===name));const active=$(`[data-view="${name}"]`);$("#pageTitle").textContent=active?active.innerText.trim():(name==="home"?"Dashboard":name);$("#sidebar").classList.remove("open");if(name==="maths")renderMaths();if(name==="subjects")renderSubjects();if(name==="notes")renderNotes();if(name==="planner")renderTasks()}
function setupNav(){$$(".nav-item").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));$$("[data-go]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.go)));$("#menuBtn").addEventListener("click",()=>$("#sidebar").classList.toggle("open"))}
function populateGroupSelect(){const stream=$("#studentStream").value;const select=$("#studentGroup");select.innerHTML=(groups[stream]||groups.science).map(g=>`<option value="${g.code}">${g.code} — ${g.name}</option>`).join("");const wanted=state.profile.group;if([...select.options].some(o=>o.value===wanted))select.value=wanted}
function fillProfile(){const p=state.profile;$("#studentName").value=p.name||"";$("#studentClass").value=p.class||"11";$("#studentBoard").value=p.board||"Tamil Nadu State Board";$("#studentMedium").value=p.medium||"en";$("#studentStream").value=p.stream||"science";populateGroupSelect();$("#studentGroup").value=p.group||$("#studentGroup").value;$("#languageSelect").value=p.medium||"en"}
function renderProfileSummary(){const p=state.profile;$("#profileName").textContent=p.name||"Student";$("#welcomeName").textContent=p.name||"Student";$("#profileMeta").textContent=`${p.class==="10"?"Class 10":p.class==="11"?"+1":"+2"} · ${p.stream}`;$("#selectedGroupTag").textContent=`${p.group} · ${currentGroup().name}`;$("#mathClassTitle").textContent=`Class ${p.class==="10"?"10":p.class==="11"?"11 (+1)":"12 (+2)"} Mathematics chapters`}
function renderSubjects(){const subjects=allSubjects();const filter=$("#subjectFilter").value;const cards=subjects.filter(s=>filter==="all"||categoryFor(s)===filter);$("#subjectGrid").innerHTML=cards.map((s,i)=>`<article class="subject-card"><div class="subject-top"><span class="subject-symbol">${subjectIcons[s]||"✦"}</span><span class="soft-tag">${categoryFor(s).toUpperCase()}</span></div><h3>${escapeHTML(s)}</h3><p>Lessons, revision notes, practice questions and chapter resources.</p><button class="text-btn" data-subject="${escapeAttr(s)}">Open learning area →</button></article>`).join("")||`<div class="empty-state">No subjects in this filter. Choose another category or update your group.</div>`;$$("[data-subject]").forEach(b=>b.addEventListener("click",()=>{if(b.dataset.subject.toLowerCase().includes("math"))showView("maths");else toast(`${b.dataset.subject}: subject workspace selected. Add verified chapter content to expand this section.`)}));}
function categoryFor(s){if(["Mathematics","Statistics","Business Mathematics and Statistics"].includes(s))return "science";if(["Physics","Chemistry","Biology","Biochemistry","Microbiology","Botany","Zoology","Computer Science","Nursing","Nutrition and Dietetics","Home Science"].includes(s))return "science";if(["Economics","Commerce","Accountancy","Business Studies","Business Mathematics and Statistics","Auditing"].includes(s))return "commerce";if(["History","Geography","Political Science","Sociology","Psychology","Ethics and Indian Culture"].includes(s))return "humanities";if(["Tamil","English","Malayalam","Communicative English","Advanced Tamil"].includes(s))return "language";return "vocational"}
function renderMaths(){const chapters=mathChapters[state.profile.class==="12"?"12":"11"];$("#mathChapterList").innerHTML=chapters.map((c,i)=>`<button class="chapter-item" data-chapter="${i+1}"><span class="chapter-no">${String(i+1).padStart(2,"0")}</span><span><b>${escapeHTML(c)}</b><small>Chapter ${i+1} · Open chapter overview</small></span></button>`).join("");$$("[data-chapter]").forEach(b=>b.addEventListener("click",()=>toast(`Chapter ${b.dataset.chapter}: add textbook explanation, examples and exercise solutions here.`)))}
function renderNotes(){const list=$("#notesList");if(!state.notes.length){list.innerHTML='<div class="empty-state">✎<br><br>No notes yet. Create your first revision note.</div>';return}list.innerHTML=state.notes.map(n=>`<article class="note-card"><button class="delete-btn" data-delete-note="${n.id}" aria-label="Delete note">×</button><h3>${escapeHTML(n.title)}</h3><small>${escapeHTML(n.subject)} · ${new Date(n.created).toLocaleDateString()}</small><p>${escapeHTML(n.body)}</p></article>`).join("");$$("[data-delete-note]").forEach(b=>b.addEventListener("click",()=>{state.notes=state.notes.filter(n=>n.id!==b.dataset.deleteNote);saveState();toast("Note deleted.")}))}
function renderTasks(){const list=$("#taskList");const done=state.tasks.filter(t=>t.done).length;$("#taskSummary").textContent=`${done} / ${state.tasks.length} completed`;if(!state.tasks.length){list.innerHTML='<div class="empty-state">▦<br><br>Your study plan is empty. Add a task to get started.</div>';return}list.innerHTML=state.tasks.map(t=>`<div class="task-row ${t.done?"done":""}"><input type="checkbox" data-task="${t.id}" ${t.done?"checked":""} aria-label="Mark task complete"><div class="task-content"><b>${escapeHTML(t.text)}</b><small>${escapeHTML(t.subject)} · ${t.date||"No date set"}</small></div><button class="delete-btn" data-delete-task="${t.id}" aria-label="Delete task">×</button></div>`).join("");$$("[data-task]").forEach(b=>b.addEventListener("change",()=>{const t=state.tasks.find(t=>t.id===b.dataset.task);if(t)t.done=b.checked;saveState()}));$$("[data-delete-task]").forEach(b=>b.addEventListener("click",()=>{state.tasks=state.tasks.filter(t=>t.id!==b.dataset.deleteTask);saveState()}))}
function renderStats(){const subjects=allSubjects().length,done=state.tasks.filter(t=>t.done).length;$("#statSubjects").textContent=subjects;$("#statTasks").textContent=done;$("#statNotes").textContent=state.notes.length;$("#goalCount").textContent=`${done} of 5`;const pct=Math.min(100,Math.round(done/5*100));$("#goalPercent").textContent=pct+"%";$("#progressRing").style.background=`conic-gradient(#6c79e9 ${pct*3.6}deg,#eceeff 0deg)`}
function renderAll(){renderProfileSummary();renderStats();renderSubjects();renderMaths();renderNotes();renderTasks();populateSubjectPickers()}
function populateSubjectPickers(){const options=allSubjects().map(s=>`<option>${escapeHTML(s)}</option>`).join("");["#noteSubject","#taskSubject"].forEach(id=>{const el=$(id);const old=el.value;el.innerHTML=options;if([...el.options].some(o=>o.value===old))el.value=old})}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function escapeAttr(s){return escapeHTML(s)}
$("#studentStream").addEventListener("change",populateGroupSelect);
$("#profileForm").addEventListener("submit",e=>{e.preventDefault();state.profile={name:$("#studentName").value.trim()||"Student",class:$("#studentClass").value,board:$("#studentBoard").value,medium:$("#studentMedium").value,stream:$("#studentStream").value,group:$("#studentGroup").value};saveState();$("#profileSaved").textContent="Profile saved successfully.";$("#languageSelect").value=state.profile.medium;applyLanguage();toast("Your learning profile has been saved.")});
$("#languageSelect").addEventListener("change",e=>{state.profile.medium=e.target.value;saveState();applyLanguage()});
function applyLanguage(){const lang=state.profile.medium||"en";document.documentElement.lang=lang;$$("[data-i18n]").forEach(el=>{const key=el.dataset.i18n;if(translations[lang][key])el.textContent=translations[lang][key]})}
$("#subjectFilter").addEventListener("change",renderSubjects);
$("#noteForm").addEventListener("submit",e=>{e.preventDefault();state.notes.unshift({id:crypto.randomUUID(),title:$("#noteTitle").value.trim(),subject:$("#noteSubject").value,body:$("#noteBody").value.trim(),created:Date.now()});$("#noteForm").reset();saveState();toast("Note saved on this device.")});
$("#taskForm").addEventListener("submit",e=>{e.preventDefault();state.tasks.push({id:crypto.randomUUID(),text:$("#taskText").value.trim(),subject:$("#taskSubject").value,date:$("#taskDate").value,done:false});$("#taskText").value="";saveState();toast("Study task added.")});
$("#themeBtn").addEventListener("click",()=>{document.body.classList.toggle("dark");state.theme=document.body.classList.contains("dark")?"dark":"light";localStorage.setItem(STORAGE,JSON.stringify(state))});
$("#resetBtn").addEventListener("click",()=>{if(confirm("Reset your profile, notes and planner tasks on this device?")){localStorage.removeItem(STORAGE);state=structuredClone(defaultState);fillProfile();renderAll();applyLanguage();toast("App data reset.")}});
const quiz=[
 {q:"What is the value of 5²?",o:["10","15","25","30"],a:2,e:"5² means 5 × 5 = 25."},
 {q:"Which of these is a prime number?",o:["21","27","29","33"],a:2,e:"29 has exactly two positive factors: 1 and 29."},
 {q:"What is the derivative of x²?",o:["x","2x","x³","2"],a:1,e:"Using the power rule, d(x²)/dx = 2x."},
 {q:"What is the sum of angles in a triangle?",o:["90°","180°","270°","360°"],a:1,e:"The interior angles of a Euclidean triangle add up to 180°."},
 {q:"If 2x = 14, what is x?",o:["5","6","7","8"],a:2,e:"Divide both sides by 2: x = 14 ÷ 2 = 7."}
];let qIndex=0,chosen=null,score=0;
function renderQuiz(){const q=quiz[qIndex];$("#quizQuestion").textContent=q.q;$("#quizCount").textContent=`${qIndex+1} / ${quiz.length}`;$("#quizFeedback").textContent="Select an answer to continue.";$("#nextQuestion").disabled=true;$("#nextQuestion").textContent=qIndex===quiz.length-1?"Finish quiz ✓":"Next question →";$("#quizOptions").innerHTML=q.o.map((o,i)=>`<button class="quiz-option" data-answer="${i}"><b>${String.fromCharCode(65+i)}.</b> ${o}</button>`).join("");$$("[data-answer]").forEach(b=>b.addEventListener("click",()=>chooseAnswer(Number(b.dataset.answer))))}
function chooseAnswer(i){if(chosen!==null)return;chosen=i;const q=quiz[qIndex];const correct=i===q.a;if(correct)score++;$$("[data-answer]").forEach((b,n)=>{b.disabled=true;if(n===q.a)b.classList.add("correct");else if(n===i)b.classList.add("wrong")});$("#quizFeedback").textContent=(correct?"Correct! ":"Not quite. ")+q.e;$("#nextQuestion").disabled=false}
$("#nextQuestion").addEventListener("click",()=>{if(chosen===null)return;if(qIndex===quiz.length-1){$("#quizQuestion").textContent=`Quiz complete — ${score} out of ${quiz.length}!`;$("#quizOptions").innerHTML='<div class="empty-state">Well done. Review the explanations and try again to improve your score.</div>';$("#quizFeedback").textContent="Your score is for this demo quiz only." ;$("#nextQuestion").textContent="Try again";$("#nextQuestion").disabled=false;$("#nextQuestion").onclick=()=>{qIndex=0;chosen=null;score=0;renderQuiz();$("#nextQuestion").onclick=null};return}qIndex++;chosen=null;renderQuiz()});
$("#taskDate").value=new Date().toISOString().slice(0,10);
setupNav();fillProfile();renderAll();applyLanguage();renderQuiz();if(state.theme==="dark")document.body.classList.add("dark");


// Cloud sync bridge. Firebase Auth and Firestore are configured in firebase-config.js.
window.studyBuddyGetState = () => state;
window.studyBuddyApplyCloudState = (remoteState) => {
  if (!remoteState || typeof remoteState !== "object") return;
  state = {...defaultState, ...remoteState,
    profile: {...defaultState.profile, ...(remoteState.profile || {})},
    notes: Array.isArray(remoteState.notes) ? remoteState.notes : [],
    tasks: Array.isArray(remoteState.tasks) ? remoteState.tasks : []
  };
  localStorage.setItem(STORAGE, JSON.stringify(state));
  fillProfile(); renderAll(); applyLanguage();
};
