
/* ===== MÓDULO: armazenamento.js ===== */

/* ============================================
   SGFE - SISTEMA DE GESTÃO FINANCEIRA ESCOLAR
   MÓDULO DE ARMAZENAMENTO LOCAL
   Tecnologia: IndexedDB
============================================ */

(function () {
    "use strict";

    const NOME_BANCO = "SGFE_Banco_Local";
    const VERSAO_BANCO = 1;

    const COLECOES = [
        "receitas",
        "pagamentos",
        "turmas",
        "funcionarios",
        "salarios",
        "despesas",
        "categorias",
        "servicos",
        "configuracoes",
        "historico"
    ];

    let banco = null;
    let inicializacao = null;


    /* 1. IDENTIFICADOR ÚNICO */

    function gerarID() {
        if (crypto.randomUUID) {
            return crypto.randomUUID();
        }

        return "SGFE-" +
            Date.now() + "-" +
            Math.random().toString(36).substring(2, 10);
    }


    /* 2. ABRIR A BASE DE ARMAZENAMENTO */

    function iniciar() {

        if (banco) {
            return Promise.resolve(banco);
        }

        if (inicializacao) {
            return inicializacao;
        }

        inicializacao = new Promise((resolve, reject) => {

            if (!("indexedDB" in window)) {
                inicializacao = null;

                reject(new Error(
                    "Este navegador não suporta armazenamento IndexedDB."
                ));

                return;
            }

            const pedido = indexedDB.open(
                NOME_BANCO,
                VERSAO_BANCO
            );

            pedido.onupgradeneeded = function (evento) {

                const db = evento.target.result;

                COLECOES.forEach(nome => {

                    if (!db.objectStoreNames.contains(nome)) {

                        const armazenamento = db.createObjectStore(
                            nome,
                            { keyPath: "id" }
                        );

                        armazenamento.createIndex(
                            "data",
                            "data",
                            { unique: false }
                        );

                        armazenamento.createIndex(
                            "estado",
                            "estado",
                            { unique: false }
                        );

                        armazenamento.createIndex(
                            "criadoEm",
                            "criadoEm",
                            { unique: false }
                        );

                    }

                });

            };


            pedido.onsuccess = function (evento) {

                banco = evento.target.result;

                banco.onversionchange = function () {
                    banco.close();
                    banco = null;
                    inicializacao = null;
                };

                banco.onclose = function () {
                    banco = null;
                    inicializacao = null;
                };

                resolve(banco);

            };


            pedido.onerror = function () {

                inicializacao = null;

                reject(
                    pedido.error ||
                    new Error("Não foi possível abrir o armazenamento.")
                );

            };


            pedido.onblocked = function () {

                console.warn(
                    "O armazenamento está bloqueado por outra janela."
                );

            };

        });

        return inicializacao;

    }


    /* 3. EXECUTAR OPERAÇÕES */

    async function executar(nome, modo, operacao) {

        const db = await iniciar();

        return new Promise((resolve, reject) => {

            let resultado;

            const transacao = db.transaction(nome, modo);
            const armazenamento = transacao.objectStore(nome);

            try {

                resultado = operacao(armazenamento);

            } catch (erro) {

                try {
                    transacao.abort();
                } catch (_) {}

                reject(erro);
                return;

            }

            transacao.oncomplete = function () {
                resolve(resultado);
            };

            transacao.onerror = function () {
                reject(
                    transacao.error ||
                    new Error("Erro ao executar operação.")
                );
            };

            transacao.onabort = function () {
                reject(
                    transacao.error ||
                    new Error("Operação cancelada.")
                );
            };

        });

    }


    /* 4. GUARDAR REGISTOS */

    async function guardar(nome, dados) {

        verificarColecao(nome);

        if (!dados || typeof dados !== "object" ||
            Array.isArray(dados)) {

            throw new Error("Os dados fornecidos são inválidos.");

        }

        const registo = { ...dados };

        if (registo.id === undefined || registo.id === null) {
            registo.id = gerarID();
        }

        if (!registo.criadoEm) {
            registo.criadoEm = new Date().toISOString();
        }

        registo.atualizadoEm = new Date().toISOString();

        await executar(nome, "readwrite", armazenamento => {
            armazenamento.put(registo);
        });

        return registo;

    }


    /* 5. CONSULTAR TODOS OS REGISTOS */

    async function listar(nome) {

        verificarColecao(nome);

        return executar(nome, "readonly", armazenamento => {

            return new Promise((resolve, reject) => {

                const pedido = armazenamento.getAll();

                pedido.onsuccess = () => resolve(pedido.result);
                pedido.onerror = () => reject(pedido.error);

            });

        });

    }


    /* 6. CONSULTAR UM REGISTO */

    async function obter(nome, id) {

        verificarColecao(nome);

        return executar(nome, "readonly", armazenamento => {

            return new Promise((resolve, reject) => {

                const pedido = armazenamento.get(id);

                pedido.onsuccess = () => {
                    resolve(pedido.result || null);
                };

                pedido.onerror = () => reject(pedido.error);

            });

        });

    }


    /* 7. ELIMINAR UM REGISTO */

    async function eliminar(nome, id) {

        verificarColecao(nome);

        await executar(nome, "readwrite", armazenamento => {
            armazenamento.delete(id);
        });

        return true;

    }


    /* 8. PESQUISAR REGISTOS */

    async function pesquisar(nome, campo, valor) {

        verificarColecao(nome);

        const dados = await listar(nome);

        return dados.filter(registo => {

            return String(registo[campo] ?? "")
                .toLowerCase()
                .includes(String(valor).toLowerCase());

        });

    }


    /* 9. VERIFICAR COLEÇÃO */

    function verificarColecao(nome) {

        if (!COLECOES.includes(nome)) {

            throw new Error(
                "Coleção não autorizada: " + nome
            );

        }

    }


    /* 10. CRIAR CÓPIA DE SEGURANÇA */

    async function criarBackup() {

        const db = await iniciar();

        const copia = {
            sistema: "SGFE",
            versao: VERSAO_BANCO,
            dataCriacao: new Date().toISOString(),
            dados: {}
        };

        for (const nome of COLECOES) {
            copia.dados[nome] = await listar(nome);
        }

        const conteudo = JSON.stringify(copia, null, 2);

        const ficheiro = new Blob(
            [conteudo],
            { type: "application/json" }
        );

        const url = URL.createObjectURL(ficheiro);

        const link = document.createElement("a");

        const data = new Date()
            .toISOString()
            .replace(/[:.]/g, "-");

        link.href = url;
        link.download = "SGFE_Backup_" + data + ".json";

        document.body.appendChild(link);
        link.click();
        link.remove();

        setTimeout(() => URL.revokeObjectURL(url), 1000);

        return true;

    }


    /* 11. RESTAURAR CÓPIA DE SEGURANÇA */

    async function restaurarBackup(ficheiro, substituir = false) {

        if (!ficheiro) {
            throw new Error("Nenhum ficheiro foi seleccionado.");
        }

        const conteudo = await ficheiro.text();

        let copia;

        try {
            copia = JSON.parse(conteudo);
        } catch (_) {
            throw new Error("O ficheiro não contém um JSON válido.");
        }

        if (
            copia.sistema !== "SGFE" ||
            !copia.dados ||
            typeof copia.dados !== "object"
        ) {
            throw new Error("Este ficheiro não é uma cópia válida do SGFE.");
        }

        const db = await iniciar();

        const nomes = COLECOES.filter(nome =>
            Object.prototype.hasOwnProperty.call(copia.dados, nome)
        );

        if (nomes.length === 0) {
            throw new Error("A cópia não contém dados reconhecidos.");
        }

        for (const nome of nomes) {

            if (!Array.isArray(copia.dados[nome])) {
                throw new Error(
                    "Dados inválidos na coleção: " + nome
                );
            }

            for (const registo of copia.dados[nome]) {

                if (
                    !registo ||
                    typeof registo !== "object" ||
                    Array.isArray(registo) ||
                    registo.id === undefined ||
                    registo.id === null
                ) {
                    throw new Error(
                        "Foi encontrado um registo inválido em " + nome
                    );
                }

            }

        }

        const transacao = db.transaction(nomes, "readwrite");

        return new Promise((resolve, reject) => {

            let erro = null;

            transacao.oncomplete = () => {
                resolve({
                    sucesso: true,
                    colecoes: nomes,
                    modo: substituir ? "substituir" : "integrar"
                });
            };

            transacao.onerror = () => {
                erro = transacao.error;
            };

            transacao.onabort = () => {
                reject(
                    erro ||
                    transacao.error ||
                    new Error("Não foi possível restaurar a cópia.")
                );
            };

            nomes.forEach(nome => {

                const armazenamento =
                    transacao.objectStore(nome);

                if (substituir) {
                    armazenamento.clear();
                }

                copia.dados[nome].forEach(registo => {
                    armazenamento.put(registo);
                });

            });

        });

    }


    /* 12. HISTÓRICO DE OPERAÇÕES */

    async function registarHistorico(dados) {

        const registo = {
            tipo: dados.tipo || "Alteração",
            modulo: dados.modulo || "Sistema",
            descricao: dados.descricao || "",
            valor: Number(dados.valor) || 0,
            motivo: dados.motivo || "",
            data: new Date().toISOString()
        };

        return guardar("historico", registo);

    }


    /* 13. CONSULTAR ESTADO DO ARMAZENAMENTO */

    async function verificarArmazenamento() {

        const db = await iniciar();

        return {
            disponivel: true,
            nome: db.name,
            versao: db.version,
            colecoes: COLECOES.length,
            armazenamento: "IndexedDB",
            offline: !navigator.onLine
        };

    }


    /* 14. DISPONIBILIZAR FUNÇÕES À APLICAÇÃO */

    window.SGFE_DB = Object.freeze({

        iniciar,
        gerarID,

        guardar,
        listar,
        obter,
        eliminar,
        pesquisar,

        criarBackup,
        restaurarBackup,

        registarHistorico,
        verificarArmazenamento,

        colecoes: [...COLECOES]

    });


    /* 15. INICIALIZAÇÃO AUTOMÁTICA */

    iniciar()
        .then(() => {

            console.info(
                "SGFE: armazenamento local iniciado com sucesso."
            );

        })
        .catch(erro => {

            console.error(
                "SGFE: erro ao iniciar armazenamento.",
                erro
            );

        });

})();


/* ===== MÓDULO: impressao.js ===== */

/* ============================================
   SGFE - MOTOR DE IMPRESSÃO
   Sistema centralizado de documentos A4
============================================ */

(function () {
    "use strict";

    let areaImpressao = null;

    function escapar(valor) {
        return String(valor ?? "").replace(/[&<>"']/g, c => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[c]);
    }

    function dataActual() {
        return new Date().toLocaleDateString("pt-AO", {
            day: "2-digit",
            month: "long",
            year: "numeric"
        });
    }

    function formatarLogo(logotipo) {
        if (!logotipo) return "";

        return `
            <img class="sgfe-logo"
                 src="${escapar(logotipo)}"
                 alt="Logótipo institucional">
        `;
    }

    function instalarEstilos() {
        if (document.getElementById("sgfe-estilos-impressao")) {
            return;
        }

        const estilo = document.createElement("style");

        estilo.id = "sgfe-estilos-impressao";

        estilo.textContent = `
            /* Área de impressão */

            #sgfe-area-impressao {
                display: none;
                background: white;
                color: #111;
                font-family: Arial, Helvetica, sans-serif;
                font-size: 11px;
                line-height: 1.4;
            }

            #sgfe-area-impressao .sgfe-cabecalho {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 15px;
                text-align: center;
                border-bottom: 2px solid #17365D;
                padding-bottom: 12px;
                margin-bottom: 18px;
            }

            #sgfe-area-impressao .sgfe-logo {
                max-width: 85px;
                max-height: 85px;
                object-fit: contain;
            }

            #sgfe-area-impressao .sgfe-identidade {
                flex: 1;
            }

            #sgfe-area-impressao .sgfe-identidade h2 {
                font-size: 16px;
                margin: 0 0 5px;
                text-transform: uppercase;
            }

            #sgfe-area-impressao .sgfe-identidade p {
                margin: 2px 0;
                font-size: 10px;
            }

            #sgfe-area-impressao .sgfe-titulo {
                text-align: center;
                margin: 15px 0 5px;
                font-size: 15px;
                text-transform: uppercase;
            }

            #sgfe-area-impressao .sgfe-periodo {
                text-align: center;
                margin-bottom: 18px;
                font-size: 11px;
            }

            #sgfe-area-impressao .sgfe-documento {
                width: 100%;
            }

            #sgfe-area-impressao h3 {
                font-size: 12px;
                margin: 15px 0 8px;
            }

            #sgfe-area-impressao p {
                margin: 5px 0;
            }

            #sgfe-area-impressao table {
                width: 100%;
                border-collapse: collapse;
                margin: 10px 0 15px;
                font-size: 10px;
            }

            #sgfe-area-impressao th,
            #sgfe-area-impressao td {
                border: 1px solid #777;
                padding: 6px;
                text-align: left;
                vertical-align: middle;
            }

            #sgfe-area-impressao th {
                background: #e9edf2 !important;
                font-weight: bold;
            }

            #sgfe-area-impressao .texto-direita {
                text-align: right;
            }

            #sgfe-area-impressao .texto-centro {
                text-align: center;
            }

            #sgfe-area-impressao .total-geral {
                font-weight: bold;
                background: #edf1f5 !important;
            }

            #sgfe-area-impressao .sgfe-resumo {
                margin: 12px 0;
                padding: 9px;
                border: 1px solid #777;
            }

            #sgfe-area-impressao .sgfe-assinaturas {
                display: flex;
                justify-content: space-around;
                gap: 25px;
                margin-top: 55px;
                text-align: center;
            }

            #sgfe-area-impressao .sgfe-assinaturas div {
                flex: 1;
                border-top: 1px solid #222;
                padding-top: 7px;
            }

            #sgfe-area-impressao .sgfe-rodape {
                margin-top: 25px;
                padding-top: 8px;
                border-top: 1px solid #aaa;
                text-align: center;
                font-size: 9px;
            }

            #sgfe-area-impressao .sgfe-quebra-pagina {
                break-before: page;
                page-break-before: always;
            }

            #sgfe-area-impressao .sgfe-grafico {
                margin: 18px 0;
            }

            #sgfe-area-impressao .sgfe-barra {
                height: 17px;
                background: #17365D;
                margin: 5px 0 12px;
                min-width: 2px;
            }

            #sgfe-area-impressao .sgfe-barra-destaque {
                background: #D5A43B;
            }

            #sgfe-area-impressao .sgfe-grafico-item {
                margin: 12px 0;
            }

            #sgfe-area-impressao .sgfe-grafico-valor {
                font-weight: bold;
            }

            @media screen {
                #sgfe-area-impressao {
                    display: none !important;
                }
            }

            @media print {
                @page {
                    size: A4 portrait;
                    margin: 14mm;
                }

                body * {
                    visibility: hidden !important;
                }

                #sgfe-area-impressao,
                #sgfe-area-impressao * {
                    visibility: visible !important;
                }

                #sgfe-area-impressao {
                    display: block !important;
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    margin: 0;
                    padding: 0;
                }

                #sgfe-area-impressao table {
                    page-break-inside: auto;
                    break-inside: auto;
                }

                #sgfe-area-impressao thead {
                    display: table-header-group;
                }

                #sgfe-area-impressao tfoot {
                    display: table-footer-group;
                }

                #sgfe-area-impressao tr {
                    break-inside: avoid;
                    page-break-inside: avoid;
                }

                #sgfe-area-impressao .sgfe-cabecalho,
                #sgfe-area-impressao .sgfe-resumo,
                #sgfe-area-impressao .sgfe-assinaturas {
                    break-inside: avoid;
                    page-break-inside: avoid;
                }

                #sgfe-area-impressao .sgfe-quebra-pagina {
                    break-before: page;
                    page-break-before: always;
                }

                #sgfe-area-impressao .sgfe-barra {
                    print-color-adjust: exact;
                    -webkit-print-color-adjust: exact;
                }

                #sgfe-area-impressao th,
                #sgfe-area-impressao .total-geral {
                    print-color-adjust: exact;
                    -webkit-print-color-adjust: exact;
                }
            }
        `;

        document.head.appendChild(estilo);
    }

    async function obterInstituicao() {
        const padrao = {
            nome: "INSTITUIÇÃO DE ENSINO",
            nomeAbreviado: "",
            logotipo: "",
            endereco: "",
            telefone: "",
            email: "",
            municipio: "",
            provincia: ""
        };

        try {
            if (!window.SGFE_CONFIGURACOES) {
                return padrao;
            }

            const config = await window.SGFE_CONFIGURACOES.carregar();

            return {
                ...padrao,
                ...(config.instituicao || {})
            };

        } catch (erro) {
            console.error("Erro ao carregar identidade institucional:", erro);
            return padrao;
        }
    }

    async function prepararDocumento(opcoes) {
        instalarEstilos();

        const instituicao = await obterInstituicao();

        const titulo = escapar(opcoes.titulo || "Relatório");
        const periodo = escapar(opcoes.periodo || "Período não especificado");

        const nome = escapar(
            instituicao.nome || "INSTITUIÇÃO DE ENSINO"
        );

        const localidade = [
            instituicao.municipio,
            instituicao.provincia
        ].filter(Boolean).join(" - ");

        const contactos = [
            instituicao.telefone,
            instituicao.email
        ].filter(Boolean).join(" | ");

        if (areaImpressao) {
            areaImpressao.remove();
        }

        areaImpressao = document.createElement("section");
        areaImpressao.id = "sgfe-area-impressao";

        areaImpressao.innerHTML = `
            <header class="sgfe-cabecalho">

                ${formatarLogo(instituicao.logotipo)}

                <div class="sgfe-identidade">
                    <h2>${nome}</h2>

                    ${instituicao.endereco
                        ? `<p>${escapar(instituicao.endereco)}</p>`
                        : ""}

                    ${localidade
                        ? `<p>${escapar(localidade)}</p>`
                        : ""}

                    ${contactos
                        ? `<p>${escapar(contactos)}</p>`
                        : ""}
                </div>

            </header>

            <h1 class="sgfe-titulo">${titulo}</h1>

            <p class="sgfe-periodo">
                <strong>Período:</strong> ${periodo}
            </p>

            <main class="sgfe-documento">
                ${opcoes.conteudo || ""}
            </main>

            ${opcoes.assinaturas !== false ? `
                <div class="sgfe-assinaturas">
                    <div>
                        O Responsável
                    </div>

                    <div>
                        A Direcção
                    </div>
                </div>
            ` : ""}

            <footer class="sgfe-rodape">
                Documento emitido pelo SGFE em ${dataActual()}
            </footer>
        `;

        document.body.appendChild(areaImpressao);
    }

    async function imprimir(opcoes = {}) {
        try {
            await prepararDocumento(opcoes);

            const estiloPagina = document.getElementById(
                "sgfe-estilos-impressao"
            );

            if (opcoes.orientacao === "paisagem") {
                const regra = `
                    @media print {
                        @page {
                            size: A4 landscape;
                            margin: 12mm;
                        }
                    }
                `;

                let paisagem = document.getElementById(
                    "sgfe-estilo-paisagem"
                );

                if (!paisagem) {
                    paisagem = document.createElement("style");
                    paisagem.id = "sgfe-estilo-paisagem";
                    document.head.appendChild(paisagem);
                }

                paisagem.textContent = regra;

            } else {
                const paisagem = document.getElementById(
                    "sgfe-estilo-paisagem"
                );

                if (paisagem) paisagem.remove();
            }

            if (!estiloPagina) {
                instalarEstilos();
            }

            window.addEventListener("afterprint", function limpar() {
                if (areaImpressao) {
                    areaImpressao.remove();
                    areaImpressao = null;
                }

                const paisagem = document.getElementById(
                    "sgfe-estilo-paisagem"
                );

                if (paisagem) paisagem.remove();

            }, { once: true });

            window.print();

        } catch (erro) {
            console.error("Erro ao preparar impressão:", erro);
            alert("Não foi possível preparar o documento para impressão.");
        }
    }

    window.SGFE_IMPRESSAO = Object.freeze({
        imprimir,
        obterInstituicao
    });

})();


/* ===== MÓDULO: painel.js ===== */

/* ============================================
   SGFE - PAINEL PRINCIPAL
   CÁLCULOS E INDICADORES FINANCEIROS
   Integração com pagamentos salariais
============================================ */

(function () {
    "use strict";

    const DB = window.SGFE_DB;

    if (!DB) {
        console.error("SGFE: armazenamento não encontrado.");
        return;
    }

    let periodoAtual = "ano";

    const ELEMENTOS = {
        receitas: document.getElementById("totalReceitas"),
        despesas: document.getElementById("totalDespesas"),
        saldo: document.getElementById("saldoPeriodo"),
        pendentes: document.getElementById("valoresPendentes"),
        despesasPendentes: document.getElementById("despesasPendentes"),
        salariosPagos: document.getElementById("salariosPagos"),
        salariosPendentes: document.getElementById("salariosPendentes"),
        mensalidades: document.getElementById("mensalidadesPendentes"),
        movimentacoes: document.getElementById("ultimasMovimentacoes"),
        periodo: document.getElementById("periodoPainel")
    };

    /* 1. FORMATAÇÃO */

    function moeda(valor) {
        return new Intl.NumberFormat("pt-AO", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(Number(valor) || 0) + " Kz";
    }

    function numero(valor) {
        const resultado = Number(valor);
        return Number.isFinite(resultado) ? resultado : 0;
    }

    function dataValida(valor) {
        if (!valor) return null;

        const data = new Date(valor);

        return Number.isNaN(data.getTime()) ? null : data;
    }

    /* 2. FILTRAR POR PERÍODO */

    function pertenceAoPeriodo(data) {
        if (!data) return false;

        const agora = new Date();

        if (periodoAtual === "mes") {
            return data.getMonth() === agora.getMonth() &&
                data.getFullYear() === agora.getFullYear();
        }

        if (periodoAtual === "trimestre") {
            return Math.floor(data.getMonth() / 3) ===
                Math.floor(agora.getMonth() / 3) &&
                data.getFullYear() === agora.getFullYear();
        }

        if (periodoAtual === "semestre") {
            return Math.floor(data.getMonth() / 6) ===
                Math.floor(agora.getMonth() / 6) &&
                data.getFullYear() === agora.getFullYear();
        }

        return data.getFullYear() === agora.getFullYear();
    }

    function filtrarPeriodo(registos) {
        return registos.filter(registo => {
            const data = dataValida(
                registo.data || registo.criadoEm
            );

            return pertenceAoPeriodo(data);
        });
    }

    /* 3. RECEITAS */

    function valorRecebido(registo) {
        if (Array.isArray(registo.pagamentos)) {
            return registo.pagamentos.reduce((total, pagamento) => {
                if (pagamento.estado === "anulado") return total;
                return total + numero(pagamento.valor);
            }, 0);
        }

        if (registo.estado === "pago") {
            return numero(registo.valor);
        }

        if (registo.estado === "parcial") {
            return numero(
                registo.valorPago ?? registo.valorRecebido
            );
        }

        return 0;
    }

    function valorPendente(registo) {
        if (registo.estado === "anulado") return 0;

        return Math.max(
            0,
            numero(registo.valor) - valorRecebido(registo)
        );
    }

    /* 4. DESPESAS COMUNS */

    function valorPago(registo) {
        if (registo.estado === "anulado") return 0;

        if (registo.estado === "pago") {
            return numero(registo.valor);
        }

        if (registo.estado === "parcial") {
            return numero(registo.valorPago);
        }

        return 0;
    }

    function valorPendenteDespesa(registo) {
        if (registo.estado === "anulado") return 0;

        return Math.max(
            0,
            numero(registo.valor) - valorPago(registo)
        );
    }

    /* 5. FOLHAS SALARIAIS */

    function pagamentosSalariais(salario) {
        return (salario.pagamentos || []).filter(
            pagamento => pagamento.estado !== "anulado"
        );
    }

    function totalPagoSalario(salario) {
        if (Array.isArray(salario.pagamentos)) {
            return pagamentosSalariais(salario).reduce(
                (total, pagamento) =>
                    total + numero(pagamento.valor),
                0
            );
        }

        // Compatibilidade com registos salariais antigos.
        return valorPago(salario);
    }

    function pendenteSalario(salario) {
        const previsto = numero(
            salario.salarioLiquido ?? salario.valor
        );

        return Math.max(
            0,
            previsto - totalPagoSalario(salario)
        );
    }

    function dataFolhaSalarial(salario) {
        if (salario.ano && salario.mes) {
            return new Date(
                Number(salario.ano),
                Number(salario.mes) - 1,
                1
            );
        }

        return dataValida(salario.data || salario.criadoEm);
    }

    function salariosDoPeriodo(salarios) {
        return salarios.filter(salario =>
            pertenceAoPeriodo(dataFolhaSalarial(salario))
        );
    }

    function pagamentosSalariaisDoPeriodo(salarios) {
        let movimentos = [];

        salarios.forEach(salario => {
            if (Array.isArray(salario.pagamentos)) {
                pagamentosSalariais(salario).forEach(pagamento => {
                    const data = dataValida(
                        pagamento.data || pagamento.criadoEm
                    );

                    if (!data || !pertenceAoPeriodo(data)) return;

                    movimentos.push({
                        data: pagamento.data,
                        descricao:
                            salario.funcionarioNome ||
                            "Pagamento salarial",
                        categoria: "Salários",
                        tipo: "Saída",
                        valor: numero(pagamento.valor)
                    });
                });
            } else {
                const valor = valorPago(salario);

                if (valor > 0) {
                    const data = salario.data || salario.criadoEm;

                    if (pertenceAoPeriodo(dataValida(data))) {
                        movimentos.push({
                            data,
                            descricao:
                                salario.funcionarioNome ||
                                "Pagamento salarial",
                            categoria: "Salários",
                            tipo: "Saída",
                            valor
                        });
                    }
                }
            }
        });

        return movimentos;
    }

    /* 6. SOMAR VALORES */

    function somar(registos, funcao) {
        return registos.reduce(
            (total, registo) => total + funcao(registo),
            0
        );
    }

    /* 7. CARREGAR DADOS */

    async function carregarDados() {
        try {
            const [
                receitas,
                pagamentos,
                despesas,
                salarios
            ] = await Promise.all([
                DB.listar("receitas"),
                DB.listar("pagamentos"),
                DB.listar("despesas"),
                DB.listar("salarios")
            ]);

            atualizarPainel({
                receitas,
                pagamentos,
                despesas,
                salarios
            });

        } catch (erro) {
            console.error(
                "Erro ao carregar painel financeiro:",
                erro
            );
        }
    }

    /* 8. ACTUALIZAR INDICADORES */

    function atualizarPainel(dados) {
        const receitas = filtrarPeriodo(dados.receitas);

        const despesas = filtrarPeriodo(dados.despesas);

        const salarios = salariosDoPeriodo(dados.salarios);

        const pagamentos = filtrarPeriodo(dados.pagamentos);

        // RECEITAS

        const totalReceitas = somar(
            receitas,
            valorRecebido
        );

        // DESPESAS COMUNS

        const despesasComuns = despesas.filter(
            despesa => despesa.origem !== "salario"
        );

        const totalDespesasComuns = somar(
            despesasComuns,
            valorPago
        );

        const despesasPendentes = somar(
            despesasComuns,
            valorPendenteDespesa
        );

        // SALÁRIOS

        const salariosPagos = somar(
            pagamentosSalariaisDoPeriodo(dados.salarios),
            pagamento => numero(pagamento.valor)
        );

        const salariosPendentes = somar(
            salarios,
            pendenteSalario
        );

        // RECEITAS PENDENTES

        const totalPendentes = somar(
            receitas,
            valorPendente
        );

        // MENSALIDADES PENDENTES

        const mensalidades = receitas.filter(receita =>
            receita.tipo === "mensalidade" ||
            receita.categoria === "mensalidade"
        );

        const totalMensalidades = somar(
            mensalidades,
            valorPendente
        );

        // TOTAL DE DESPESAS E SALDO

        const totalDespesasRealizadas =
            totalDespesasComuns + salariosPagos;

        const saldo =
            totalReceitas - totalDespesasRealizadas;

        // APRESENTAR RESULTADOS

        if (ELEMENTOS.receitas)
            ELEMENTOS.receitas.textContent = moeda(totalReceitas);

        if (ELEMENTOS.despesas)
            ELEMENTOS.despesas.textContent =
                moeda(totalDespesasRealizadas);

        if (ELEMENTOS.saldo) {
            ELEMENTOS.saldo.textContent = moeda(saldo);

            ELEMENTOS.saldo.style.color =
                saldo < 0 ? "#C64B4B" : "#23865B";
        }

        if (ELEMENTOS.pendentes)
            ELEMENTOS.pendentes.textContent = moeda(totalPendentes);

        if (ELEMENTOS.despesasPendentes)
            ELEMENTOS.despesasPendentes.textContent =
                moeda(despesasPendentes);

        if (ELEMENTOS.salariosPagos)
            ELEMENTOS.salariosPagos.textContent =
                moeda(salariosPagos);

        if (ELEMENTOS.salariosPendentes)
            ELEMENTOS.salariosPendentes.textContent =
                moeda(salariosPendentes);

        if (ELEMENTOS.mensalidades)
            ELEMENTOS.mensalidades.textContent =
                moeda(totalMensalidades);

        // MOVIMENTAÇÕES

        apresentarMovimentacoes(
            receitas,
            pagamentos,
            despesasComuns,
            pagamentosSalariaisDoPeriodo(dados.salarios)
        );
    }

    /* 9. ÚLTIMAS MOVIMENTAÇÕES */

    function apresentarMovimentacoes(
        receitas,
        pagamentos,
        despesas,
        movimentosSalariais
    ) {
        let movimentos = [];

        receitas.forEach(registo => {
            if (valorRecebido(registo) > 0) {
                movimentos.push({
                    data: registo.data || registo.criadoEm,
                    descricao:
                        registo.descricao ||
                        registo.tipo ||
                        "Receita",
                    categoria: registo.categoria || "Receitas",
                    tipo: "Entrada",
                    valor: valorRecebido(registo)
                });
            }
        });

        // Pagamentos independentes registados na colecção.
        pagamentos.forEach(registo => {
            if (registo.estado === "anulado") return;

            movimentos.push({
                data: registo.data || registo.criadoEm,
                descricao: registo.descricao || "Pagamento",
                categoria: registo.categoria || "Receitas",
                tipo: "Entrada",
                valor: numero(registo.valor)
            });
        });

        despesas.forEach(registo => {
            if (valorPago(registo) > 0) {
                movimentos.push({
                    data: registo.data || registo.criadoEm,
                    descricao: registo.descricao || "Despesa",
                    categoria: registo.categoria || "Despesas",
                    tipo: "Saída",
                    valor: valorPago(registo)
                });
            }
        });

        movimentosSalariais.forEach(registo => {
            movimentos.push(registo);
        });

        movimentos.sort((a, b) =>
            new Date(b.data) - new Date(a.data)
        );

        const recentes = movimentos.slice(0, 10);

        if (!ELEMENTOS.movimentacoes) return;

        if (recentes.length === 0) {
            ELEMENTOS.movimentacoes.innerHTML = `
                <tr>
                    <td colspan="5">
                        Ainda não existem movimentações.
                    </td>
                </tr>
            `;
            return;
        }

        ELEMENTOS.movimentacoes.innerHTML =
            recentes.map(registo => {
                const data = dataValida(registo.data);

                const dataFormatada = data
                    ? data.toLocaleDateString("pt-AO")
                    : "—";

                return `
                    <tr>
                        <td>${dataFormatada}</td>
                        <td>${escaparHTML(registo.descricao)}</td>
                        <td>${escaparHTML(registo.categoria)}</td>
                        <td>${registo.tipo}</td>
                        <td>${moeda(registo.valor)}</td>
                    </tr>
                `;
            }).join("");
    }

    /* 10. PROTEGER TEXTO */

    function escaparHTML(valor) {
        return String(valor ?? "").replace(
            /[&<>"']/g,
            caracter => ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            })[caracter]
        );
    }

    /* 11. ALTERAR PERÍODO */

    if (ELEMENTOS.periodo) {
        ELEMENTOS.periodo.addEventListener("change", function () {
            periodoAtual = this.value;
            carregarDados();
        });
    }

    /* 12. DISPONIBILIZAR ACTUALIZAÇÃO */

    window.SGFE_PAINEL = Object.freeze({
        atualizar: carregarDados
    });

    /* 13. INICIALIZAÇÃO */

    carregarDados();

})();


/* ===== MÓDULO: entradas.js ===== */

(function () {
    "use strict";

    const COLECAO_RECEITAS = "receitas";
    const COLECAO_PAGAMENTOS = "pagamentos";

    function verificarBanco() {
        if (!window.SGFE_DB) {
            throw new Error("O armazenamento do SGFE não está disponível.");
        }
    }

    function formatarValor(valor) {
        return Number(valor || 0).toLocaleString("pt-AO") + " Kz";
    }

    function escapar(texto) {
        return String(texto ?? "").replace(/[&<>"']/g, function (c) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[c];
        });
    }

    function notificar(mensagem) {
        alert(mensagem);
    }

    async function listarReceitas() {
        verificarBanco();
        return await window.SGFE_DB.listar(COLECAO_RECEITAS);
    }

    async function obterReceita(id) {
        verificarBanco();
        return await window.SGFE_DB.obter(COLECAO_RECEITAS, id);
    }

    async function listarPagamentos() {
        verificarBanco();
        return await window.SGFE_DB.listar(COLECAO_PAGAMENTOS);
    }

    async function calcularTotalPago(receitaId) {
        const pagamentos = await listarPagamentos();

        return pagamentos
            .filter(p => p.receitaId === receitaId && p.estado !== "anulado")
            .reduce((total, p) => total + Number(p.valor || 0), 0);
    }

    async function registarReceita(dados) {
        verificarBanco();

        if (!dados || !dados.descricao || !dados.tipo) {
            throw new Error("Preencha os dados obrigatórios da receita.");
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error("O valor da receita deve ser superior a zero.");
        }

        const receita = {
            id: window.SGFE_DB.gerarID(),
            descricao: String(dados.descricao).trim(),
            tipo: String(dados.tipo).trim(),
            categoria: dados.tipo,
            valor,
            aluno: dados.aluno || "",
            turma: dados.turma || "",
            referencia: dados.referencia || "",
            data: dados.data || new Date().toISOString().slice(0, 10),
            estado: "pendente",
            criadoEm: new Date().toISOString()
        };

        await window.SGFE_DB.guardar(COLECAO_RECEITAS, receita);

        await window.SGFE_DB.registarHistorico({
            operacao: "criar",
            modulo: "entradas",
            descricao: "Nova receita registada: " + receita.descricao,
            data: new Date().toISOString()
        });

        return receita;
    }

    async function atualizarReceita(id, dados) {
        const receita = await obterReceita(id);

        if (!receita) {
            throw new Error("Receita não encontrada.");
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error("O valor previsto deve ser superior a zero.");
        }

        const totalPago = await calcularTotalPago(id);

        if (valor < totalPago) {
            throw new Error(
                "O valor previsto não pode ser inferior ao total já recebido: " +
                formatarValor(totalPago)
            );
        }

        receita.descricao = String(dados.descricao || "").trim();
        receita.tipo = String(dados.tipo || "").trim();
        receita.categoria = receita.tipo;
        receita.valor = valor;
        receita.data = dados.data || receita.data;
        receita.aluno = dados.aluno || "";
        receita.turma = dados.turma || "";
        receita.referencia = dados.referencia || "";

        receita.estado = totalPago >= valor
            ? "pago"
            : totalPago > 0 ? "parcial" : "pendente";

        receita.atualizadoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO_RECEITAS, receita);

        await window.SGFE_DB.registarHistorico({
            operacao: "editar",
            modulo: "entradas",
            descricao: "Receita actualizada: " + receita.descricao,
            data: new Date().toISOString()
        });

        return receita;
    }

    async function registarPagamento(dados) {
        if (!dados || !dados.receitaId) {
            throw new Error("É necessário indicar a receita.");
        }

        const receita = await obterReceita(dados.receitaId);

        if (!receita) {
            throw new Error("A receita indicada não foi encontrada.");
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error("O valor do pagamento deve ser superior a zero.");
        }

        const totalPago = await calcularTotalPago(receita.id);
        const saldo = Number(receita.valor) - totalPago;

        if (valor > saldo) {
            throw new Error(
                "O pagamento ultrapassa o saldo em dívida. Saldo disponível: " +
                formatarValor(saldo)
            );
        }

        const pagamento = {
            id: window.SGFE_DB.gerarID(),
            receitaId: receita.id,
            descricao: receita.descricao,
            valor,
            data: dados.data || new Date().toISOString().slice(0, 10),
            metodo: dados.metodo || "Dinheiro",
            referencia: dados.referencia || "",
            estado: "confirmado",
            criadoEm: new Date().toISOString()
        };

        await window.SGFE_DB.guardar(COLECAO_PAGAMENTOS, pagamento);

        const novoTotal = totalPago + valor;

        receita.estado = novoTotal >= Number(receita.valor)
            ? "pago"
            : "parcial";

        await window.SGFE_DB.guardar(COLECAO_RECEITAS, receita);

        await window.SGFE_DB.registarHistorico({
            operacao: "pagamento",
            modulo: "entradas",
            descricao: "Pagamento recebido: " + receita.descricao,
            valor,
            data: new Date().toISOString()
        });

        return pagamento;
    }

    async function anularPagamento(id) {
        const pagamentos = await listarPagamentos();
        const pagamento = pagamentos.find(p => p.id === id);

        if (!pagamento) {
            throw new Error("Pagamento não encontrado.");
        }

        if (pagamento.estado === "anulado") {
            throw new Error("Este pagamento já foi anulado.");
        }

        const receita = await obterReceita(pagamento.receitaId);

        if (!receita) {
            throw new Error("A receita associada não foi encontrada.");
        }

        pagamento.estado = "anulado";
        pagamento.anuladoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO_PAGAMENTOS, pagamento);

        const totalPago = await calcularTotalPago(receita.id);

        receita.estado = totalPago >= Number(receita.valor)
            ? "pago"
            : totalPago > 0 ? "parcial" : "pendente";

        await window.SGFE_DB.guardar(COLECAO_RECEITAS, receita);

        await window.SGFE_DB.registarHistorico({
            operacao: "anulacao_pagamento",
            modulo: "entradas",
            descricao: "Pagamento anulado: " + receita.descricao,
            valor: pagamento.valor,
            data: new Date().toISOString()
        });

        return pagamento;
    }

    async function calcularSaldo(id) {
        const receita = await obterReceita(id);

        if (!receita) {
            throw new Error("Receita não encontrada.");
        }

        const totalPago = await calcularTotalPago(id);

        return Math.max(0, Number(receita.valor) - totalPago);
    }

    // INTERFACE DO MÓDULO

    function obterConteudo() {
        return document.getElementById("conteudoModulo");
    }

    async function abrir() {
        const conteudo = obterConteudo();

        if (!conteudo) {
            console.error("Área de conteúdo do módulo não encontrada.");
            return;
        }

        const placeholder = document.querySelector(".modulo-placeholder");

        if (placeholder) {
            placeholder.hidden = true;
        }

        conteudo.innerHTML = `
            <div class="entradas-modulo">

                <div class="cabecalho-modulo">
                    <div>
                        <h2>Gestão de Entradas</h2>
                        <p>Registo e controlo das receitas da instituição.</p>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Total previsto</span>
                        <strong id="entradasPrevisto">0 Kz</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total recebido</span>
                        <strong id="entradasRecebido">0 Kz</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total pendente</span>
                        <strong id="entradasPendente">0 Kz</strong>
                    </div>
                </div>

                <div class="entradas-acoes">
                    <button type="button" id="btnNovaReceita">
                        + Registar entrada
                    </button>

                    <button type="button" id="btnNovoPagamento">
                        + Registar pagamento
                    </button>
                </div>

                <div id="formularioEntrada" class="painel-formulario" hidden>
                    <h3>Registar nova entrada</h3>

                    <form id="formReceita">
                        <div class="formulario-grelha">

                            <label>
                                Descrição
                                <input name="descricao" required
                                    placeholder="Ex.: Mensalidade de Janeiro">
                            </label>

                            <label>
                                Tipo de entrada
                                <select name="tipo" required>
                                    <option value="">Seleccione</option>
                                    <option value="Matrícula">Matrícula</option>
                                    <option value="Mensalidade">Mensalidade</option>
                                    <option value="Cantina">Cantina</option>
                                    <option value="Papelaria">Papelaria</option>
                                    <option value="Outras receitas">Outras receitas</option>
                                </select>
                            </label>

                            <label>
                                Valor previsto (Kz)
                                <input name="valor" type="number" min="1"
                                    step="0.01" required>
                            </label>

                            <label>
                                Data de referência
                                <input name="data" type="date" required>
                            </label>

                            <label>
                                Nome do aluno (opcional)
                                <input name="aluno" placeholder="Nome do aluno">
                            </label>

                            <label>
                                Turma (opcional)
                                <input name="turma" placeholder="Ex.: 10.ª A">
                            </label>

                            <label class="campo-completo">
                                Referência / Observação
                                <input name="referencia"
                                    placeholder="Informação adicional">
                            </label>

                        </div>

                        <div class="botoes-formulario">
                            <button type="submit">Guardar entrada</button>
                            <button type="button" id="btnCancelarReceita">
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="formularioPagamento" class="painel-formulario" hidden>
                    <h3>Registar pagamento</h3>

                    <form id="formPagamento">
                        <div class="formulario-grelha">

                            <label class="campo-completo">
                                Seleccionar receita
                                <select name="receitaId" id="selectReceita" required>
                                    <option value="">Seleccione uma receita</option>
                                </select>
                            </label>

                            <label>
                                Valor recebido (Kz)
                                <input name="valor" type="number" min="1"
                                    step="0.01" required>
                            </label>

                            <label>
                                Data do pagamento
                                <input name="data" type="date" required>
                            </label>

                            <label>
                                Método de pagamento
                                <select name="metodo">
                                    <option value="Dinheiro">Dinheiro</option>
                                    <option value="Transferência">Transferência</option>
                                    <option value="Multicaixa">Multicaixa</option>
                                    <option value="Outro">Outro</option>
                                </select>
                            </label>

                            <label>
                                Referência (opcional)
                                <input name="referencia"
                                    placeholder="Número do recibo">
                            </label>

                        </div>

                        <div id="saldoReceita" class="informacao-saldo">
                            Seleccione uma receita para consultar o saldo.
                        </div>

                        <div class="botoes-formulario">
                            <button type="submit">Confirmar pagamento</button>
                            <button type="button" id="btnCancelarPagamento">
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="detalheReceita" class="painel-formulario" hidden></div>

                <div class="painel-tabela">
                    <div class="cabecalho-tabela">
                        <div>
                            <h3>Registo de entradas</h3>
                            <p>Histórico das receitas registadas.</p>
                        </div>

                        <input type="search" id="pesquisaEntradas"
                            placeholder="Pesquisar entrada...">
                    </div>

                    <div class="tabela-deslizante">
                        <table>
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Descrição</th>
                                    <th>Tipo</th>
                                    <th>Valor previsto</th>
                                    <th>Recebido</th>
                                    <th>Saldo</th>
                                    <th>Estado</th>
                                    <th>Acção</th>
                                </tr>
                            </thead>

                            <tbody id="corpoTabelaEntradas">
                                <tr>
                                    <td colspan="8">A carregar registos...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        `;

        document.getElementById("btnNovaReceita").addEventListener(
            "click", () => alternarFormulario("receita")
        );

        document.getElementById("btnNovoPagamento").addEventListener(
            "click", () => alternarFormulario("pagamento")
        );

        document.getElementById("btnCancelarReceita").addEventListener(
            "click", () => alternarFormulario("")
        );

        document.getElementById("btnCancelarPagamento").addEventListener(
            "click", () => alternarFormulario("")
        );

        document.getElementById("formReceita").addEventListener(
            "submit", guardarFormularioReceita
        );

        document.getElementById("formPagamento").addEventListener(
            "submit", guardarFormularioPagamento
        );

        document.getElementById("selectReceita").addEventListener(
            "change", atualizarSaldoSelecionado
        );

        document.getElementById("pesquisaEntradas").addEventListener(
            "input", carregarTabela
        );

        document.getElementById("corpoTabelaEntradas").addEventListener(
            "click", function (evento) {
                const botao = evento.target.closest("[data-consultar]");

                if (botao) {
                    consultarReceita(botao.dataset.consultar);
                }
            }
        );

        await atualizarInterface();
    }

    function alternarFormulario(tipo) {
        document.getElementById("formularioEntrada").hidden =
            tipo !== "receita";

        document.getElementById("formularioPagamento").hidden =
            tipo !== "pagamento";

        if (tipo) {
            fecharDetalhe();
        }
    }

    function fecharDetalhe() {
        const detalhe = document.getElementById("detalheReceita");

        if (detalhe) {
            detalhe.hidden = true;
            detalhe.innerHTML = "";
        }
    }

    async function guardarFormularioReceita(evento) {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const dados = Object.fromEntries(new FormData(formulario).entries());

        try {
            await registarReceita(dados);
            formulario.reset();
            alternarFormulario("");
            await atualizarInterface();
            notificar("Entrada registada com sucesso!");
        } catch (erro) {
            notificar(erro.message);
        }
    }

    async function guardarFormularioPagamento(evento) {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const dados = Object.fromEntries(new FormData(formulario).entries());

        try {
            await registarPagamento(dados);
            formulario.reset();
            alternarFormulario("");
            await atualizarInterface();
            notificar("Pagamento registado com sucesso!");
        } catch (erro) {
            notificar(erro.message);
        }
    }

    async function atualizarInterface() {
        await atualizarIndicadores();
        await carregarOpcoesReceitas();
        await carregarTabela();

        if (window.SGFE_PAINEL) {
            await window.SGFE_PAINEL.atualizar();
        }
    }

    async function atualizarIndicadores() {
        const receitas = await listarReceitas();
        const pagamentos = await listarPagamentos();

        const previsto = receitas.reduce(
            (total, r) => total + Number(r.valor || 0), 0
        );

        const recebido = pagamentos
            .filter(p => p.estado !== "anulado")
            .reduce((total, p) => total + Number(p.valor || 0), 0);

        const pendente = Math.max(0, previsto - recebido);

        document.getElementById("entradasPrevisto").textContent =
            formatarValor(previsto);

        document.getElementById("entradasRecebido").textContent =
            formatarValor(recebido);

        document.getElementById("entradasPendente").textContent =
            formatarValor(pendente);
    }

    async function carregarOpcoesReceitas() {
        const select = document.getElementById("selectReceita");
        const receitas = await listarReceitas();

        select.innerHTML = '<option value="">Seleccione uma receita</option>';

        for (const receita of receitas) {
            const saldo = await calcularSaldo(receita.id);

            if (saldo <= 0) continue;

            const opcao = document.createElement("option");
            opcao.value = receita.id;
            opcao.textContent =
                receita.descricao + " — Saldo: " + formatarValor(saldo);

            select.appendChild(opcao);
        }
    }

    async function atualizarSaldoSelecionado() {
        const id = document.getElementById("selectReceita").value;
        const campo = document.getElementById("saldoReceita");

        if (!id) {
            campo.textContent = "Seleccione uma receita para consultar o saldo.";
            return;
        }

        const saldo = await calcularSaldo(id);
        campo.textContent = "Saldo em dívida: " + formatarValor(saldo);
    }

    async function consultarReceita(id) {
        try {
            const receita = await obterReceita(id);

            if (!receita) {
                throw new Error("Não foi possível encontrar esta receita.");
            }

            const pagamentos = await listarPagamentos();

            const historico = pagamentos
                .filter(p => p.receitaId === receita.id)
                .sort((a, b) =>
                    String(b.data || "").localeCompare(String(a.data || ""))
                );

            const recebido = historico
                .filter(p => p.estado !== "anulado")
                .reduce((total, p) => total + Number(p.valor || 0), 0);

            const saldo = Math.max(0, Number(receita.valor || 0) - recebido);

            const estado = saldo <= 0
                ? "Pago"
                : recebido > 0 ? "Parcial" : "Pendente";

            let linhasHistorico = "";

            if (historico.length === 0) {
                linhasHistorico = `
                    <tr>
                        <td colspan="6">
                            Ainda não existem pagamentos registados.
                        </td>
                    </tr>
                `;
            } else {
                for (const pagamento of historico) {
                    const anulado = pagamento.estado === "anulado";

                    const botaoAcao = anulado
                        ? "—"
                        : `<button type="button"
                            data-anular="${escapar(pagamento.id)}">
                            Anular
                           </button>`;

                    linhasHistorico += `
                        <tr>
                            <td>${escapar(pagamento.data || "—")}</td>
                            <td>${escapar(pagamento.metodo || "Não indicado")}</td>
                            <td>${escapar(pagamento.referencia || "—")}</td>
                            <td>${formatarValor(pagamento.valor)}</td>
                            <td>
                                <span class="estado-entrada ${
                                    anulado ? "estado-pendente" : "estado-pago"
                                }">
                                    ${anulado ? "Anulado" : "Confirmado"}
                                </span>
                            </td>
                            <td>${botaoAcao}</td>
                        </tr>
                    `;
                }
            }

            const detalhe = document.getElementById("detalheReceita");

            detalhe.innerHTML = `
                <div class="cabecalho-tabela">
                    <div>
                        <h3>Detalhes da entrada</h3>
                        <p>Consulta individual da receita seleccionada.</p>
                    </div>

                    <div class="botoes-formulario">
                        <button type="button" id="btnEditarReceita">
                            Editar receita
                        </button>

                        <button type="button" id="btnFecharDetalhe">
                            Fechar consulta
                        </button>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Valor previsto</span>
                        <strong>${formatarValor(receita.valor)}</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total recebido</span>
                        <strong>${formatarValor(recebido)}</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Saldo em dívida</span>
                        <strong>${formatarValor(saldo)}</strong>
                    </div>
                </div>

                <div class="formulario-grelha">
                    <label>
                        Descrição
                        <input value="${escapar(receita.descricao)}" readonly>
                    </label>

                    <label>
                        Tipo de entrada
                        <input value="${escapar(receita.tipo)}" readonly>
                    </label>

                    <label>
                        Data de referência
                        <input value="${escapar(receita.data || "—")}" readonly>
                    </label>

                    <label>
                        Estado
                        <input value="${estado}" readonly>
                    </label>

                    <label>
                        Aluno
                        <input value="${escapar(receita.aluno || "Não indicado")}" readonly>
                    </label>

                    <label>
                        Turma
                        <input value="${escapar(receita.turma || "Não indicada")}" readonly>
                    </label>

                    <label class="campo-completo">
                        Referência / Observação
                        <input value="${escapar(receita.referencia || "Sem observações")}" readonly>
                    </label>
                </div>

                <div class="cabecalho-tabela">
                    <div>
                        <h3>Histórico de pagamentos</h3>
                        <p>${historico.length} registo(s) de pagamento.</p>
                    </div>
                </div>

                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Método</th>
                                <th>Referência</th>
                                <th>Valor</th>
                                <th>Estado</th>
                                <th>Acção</th>
                            </tr>
                        </thead>

                        <tbody>${linhasHistorico}</tbody>
                    </table>
                </div>
            `;

            detalhe.hidden = false;

            document.getElementById("btnFecharDetalhe").addEventListener(
                "click", fecharDetalhe
            );

            document.getElementById("btnEditarReceita").addEventListener(
                "click", () => abrirEdicaoReceita(receita)
            );

            detalhe.querySelectorAll("[data-anular]").forEach(botao => {
                botao.addEventListener("click", async function () {
                    const confirmar = confirm(
                        "Tem a certeza de que pretende anular este pagamento?\n\n" +
                        "O registo será mantido no histórico, mas deixará de contar " +
                        "como valor recebido."
                    );

                    if (!confirmar) return;

                    try {
                        await anularPagamento(botao.dataset.anular);
                        await atualizarInterface();
                        await consultarReceita(receita.id);
                        notificar("Pagamento anulado com sucesso!");
                    } catch (erro) {
                        notificar(erro.message);
                    }
                });
            });

            detalhe.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        } catch (erro) {
            notificar(erro.message);
        }
    }

    function abrirEdicaoReceita(receita) {
        const detalhe = document.getElementById("detalheReceita");

        const tipos = [
            "Matrícula",
            "Mensalidade",
            "Cantina",
            "Papelaria",
            "Outras receitas"
        ];

        const opcoesTipo = tipos.map(tipo => `
            <option value="${escapar(tipo)}"
                ${receita.tipo === tipo ? "selected" : ""}>
                ${escapar(tipo)}
            </option>
        `).join("");

        detalhe.innerHTML = `
            <div class="cabecalho-tabela">
                <div>
                    <h3>Editar receita</h3>
                    <p>Altere os dados da entrada seleccionada.</p>
                </div>
            </div>

            <form id="formEditarReceita">
                <div class="formulario-grelha">

                    <label>
                        Descrição
                        <input name="descricao" required
                            value="${escapar(receita.descricao)}">
                    </label>

                    <label>
                        Tipo de entrada
                        <select name="tipo" required>
                            ${opcoesTipo}
                        </select>
                    </label>

                    <label>
                        Valor previsto (Kz)
                        <input name="valor" type="number" min="1"
                            step="0.01" required
                            value="${Number(receita.valor)}">
                    </label>

                    <label>
                        Data de referência
                        <input name="data" type="date" required
                            value="${escapar(receita.data || "")}">
                    </label>

                    <label>
                        Nome do aluno
                        <input name="aluno"
                            value="${escapar(receita.aluno || "")}">
                    </label>

                    <label>
                        Turma
                        <input name="turma"
                            value="${escapar(receita.turma || "")}">
                    </label>

                    <label class="campo-completo">
                        Referência / Observação
                        <input name="referencia"
                            value="${escapar(receita.referencia || "")}">
                    </label>

                </div>

                <div class="botoes-formulario">
                    <button type="submit">Guardar alterações</button>

                    <button type="button" id="btnCancelarEdicao">
                        Cancelar
                    </button>
                </div>
            </form>
        `;

        document.getElementById("btnCancelarEdicao").addEventListener(
            "click", () => consultarReceita(receita.id)
        );

        document.getElementById("formEditarReceita").addEventListener(
            "submit",
            async function (evento) {
                evento.preventDefault();

                const dados = Object.fromEntries(
                    new FormData(evento.currentTarget).entries()
                );

                try {
                    await atualizarReceita(receita.id, dados);
                    await atualizarInterface();
                    await consultarReceita(receita.id);
                    notificar("Receita actualizada com sucesso!");
                } catch (erro) {
                    notificar(erro.message);
                }
            }
        );
    }

    async function carregarTabela() {
        const corpo = document.getElementById("corpoTabelaEntradas");

        if (!corpo) return;

        const receitas = await listarReceitas();
        const pagamentos = await listarPagamentos();

        const pesquisa = document.getElementById("pesquisaEntradas")
            .value.trim().toLowerCase();

        if (receitas.length === 0) {
            corpo.innerHTML = `
                <tr>
                    <td colspan="8">Ainda não existem entradas registadas.</td>
                </tr>
            `;
            return;
        }

        const filtradas = receitas.filter(r =>
            [
                r.descricao,
                r.tipo,
                r.aluno,
                r.turma,
                r.referencia
            ].join(" ").toLowerCase().includes(pesquisa)
        );

        if (filtradas.length === 0) {
            corpo.innerHTML = `
                <tr>
                    <td colspan="8">Nenhum resultado encontrado.</td>
                </tr>
            `;
            return;
        }

        let html = "";

        for (const receita of filtradas) {
            const recebido = pagamentos
                .filter(p =>
                    p.receitaId === receita.id &&
                    p.estado !== "anulado"
                )
                .reduce((total, p) => total + Number(p.valor || 0), 0);

            const saldo = Math.max(0, Number(receita.valor) - recebido);

            const estado = saldo <= 0
                ? "Pago"
                : recebido > 0 ? "Parcial" : "Pendente";

            html += `
                <tr>
                    <td>${escapar(receita.data)}</td>
                    <td>${escapar(receita.descricao)}</td>
                    <td>${escapar(receita.tipo)}</td>
                    <td>${formatarValor(receita.valor)}</td>
                    <td>${formatarValor(recebido)}</td>
                    <td>${formatarValor(saldo)}</td>
                    <td>
                        <span class="estado-entrada estado-${estado.toLowerCase()}">
                            ${estado}
                        </span>
                    </td>
                    <td>
                        <button type="button"
                            data-consultar="${escapar(receita.id)}">
                            Consultar
                        </button>
                    </td>
                </tr>
            `;
        }

        corpo.innerHTML = html;
    }

    window.SGFE_ENTRADAS = Object.freeze({
        registarReceita,
        listarReceitas,
        obterReceita,
        atualizarReceita,
        registarPagamento,
        listarPagamentos,
        anularPagamento,
        calcularSaldo,
        consultarReceita,
        abrir,
        atualizarInterface
    });

})();


/* ===== MÓDULO: salarios.js ===== */

/* ============================================
   SGFE - GESTÃO DE SALÁRIOS
   Funcionários, folhas salariais e pagamentos
============================================ */

(function () {
    "use strict";

    const DB = () => window.SGFE_DB;

    const MESES = [
        "Janeiro", "Fevereiro", "Março", "Abril",
        "Maio", "Junho", "Julho", "Agosto",
        "Setembro", "Outubro", "Novembro", "Dezembro"
    ];

    let funcionarios = [];
    let salarios = [];
    let cargos = [];
    let formularioFuncionarioAberto = false;
    let funcionarioEmEdicao = null;

    const moeda = valor =>
        Number(valor || 0).toLocaleString("pt-AO") + " Kz";

    const numero = valor => {
        const n = Number(valor);
        return Number.isFinite(n) ? n : 0;
    };

    const escapar = valor =>
        String(valor ?? "").replace(/[&<>"']/g, c => ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;"
        })[c]);

    const dataAtual = () =>
        new Date().toISOString().slice(0, 10);

    function notificar(mensagem) {
        alert(mensagem);
    }

    async function carregarDados() {
        funcionarios = await DB().listar("funcionarios");
        salarios = await DB().listar("salarios");
        
        if (window.SGFE_CONFIGURACOES &&
            typeof window.SGFE_CONFIGURACOES.carregar === "function") {
            
            const configuracao = await window.SGFE_CONFIGURACOES.carregar();
            
            cargos = Array.isArray(configuracao.cargos) ?
                configuracao.cargos :
                [];
            
        } else {
            cargos = [];
        }
    }

    function renderizarOpcoesCargos(cargoAtual = "") {
        const cargo = String(cargoAtual || "").trim();
        
        let opcoes = "";
        
        if (cargo && !cargos.some(c => String(c).trim() === cargo)) {
            opcoes += `
                <option value="${escapar(cargo)}" selected>
                    ${escapar(cargo)} (cargo anteriormente atribuído)
                </option>
            `;
        }
        
        opcoes += cargos.map(c => `
            <option value="${escapar(c)}"
                ${String(c).trim() === cargo ? "selected" : ""}>
                ${escapar(c)}
            </option>
        `).join("");
        
        if (!cargos.length && !cargo) {
            opcoes = `
                <option value="">Nenhum cargo cadastrado nas Definições</option>
            `;
        }
        
        return `
            <option value="">Seleccione o cargo</option>
            ${opcoes}
        `;
    }

    function pagamentosValidos(salario) {
        return (salario.pagamentos || []).filter(
            p => p.estado !== "anulado"
        );
    }

    function totalPago(salario) {
        return pagamentosValidos(salario).reduce(
            (total, p) => total + numero(p.valor), 0
        );
    }

    function saldoPendente(salario) {
        return Math.max(
            0,
            numero(salario.salarioLiquido) - totalPago(salario)
        );
    }

    function atualizarEstado(salario) {
        const pago = totalPago(salario);
        const previsto = numero(salario.salarioLiquido);

        if (pago <= 0) {
            salario.estado = "pendente";
        } else if (pago >= previsto) {
            salario.estado = "pago";
        } else {
            salario.estado = "parcial";
        }

        return salario.estado;
    }

    function estadoHTML(estado) {
        const nomes = {
            pago: "Pago",
            parcial: "Parcial",
            pendente: "Pendente"
        };

        return `<span class="estado-entrada estado-${estado}">
            ${nomes[estado] || estado}
        </span>`;
    }

    async function registarHistorico(tipo, descricao, valor, motivo = "") {
        await DB().registarHistorico({
            tipo,
            modulo: "Salários",
            descricao,
            valor,
            motivo
        });
    }

    /* ========================================
       FUNCIONÁRIOS
    ======================================== */

    async function guardarFuncionario(evento) {
        evento.preventDefault();

        const nome = document.getElementById("salNomeFuncionario").value.trim();
        const cargo = document.getElementById("salCargoFuncionario").value.trim();
        const contacto = document.getElementById("salContactoFuncionario").value.trim();
        const salarioBase = numero(document.getElementById("salBaseFuncionario").value);

        if (!nome || !cargo || salarioBase <= 0) {
            notificar("Preencha o nome, cargo e salário-base correctamente.");
            return;
        }

        const dados = {
            nome,
            cargo,
            contacto,
            salarioBase,
            estado: "ativo"
        };

        try {
            if (funcionarioEmEdicao) {
                const anterior = await DB().obter(
                    "funcionarios",
                    funcionarioEmEdicao
                );

                await DB().guardar("funcionarios", {
                    ...anterior,
                    ...dados,
                    estado: anterior.estado || "ativo"
                });

                await registarHistorico(
                    "Edição",
                    "Dados do funcionário " + nome + " actualizados.",
                    salarioBase
                );

            } else {
                await DB().guardar("funcionarios", dados);

                await registarHistorico(
                    "Registo",
                    "Novo funcionário registado: " + nome,
                    salarioBase
                );
            }

            funcionarioEmEdicao = null;
            formularioFuncionarioAberto = false;

            await carregarDados();
            abrir();

        } catch (erro) {
            console.error(erro);
            notificar("Não foi possível guardar o funcionário.");
        }
    }

    async function editarFuncionario(id) {
        const funcionario = await DB().obter("funcionarios", id);

        if (!funcionario) return;

        funcionarioEmEdicao = id;
        formularioFuncionarioAberto = true;

        abrir();

        document.getElementById("salNomeFuncionario").value = funcionario.nome || "";
        document.getElementById("salCargoFuncionario").value = funcionario.cargo || "";
        document.getElementById("salContactoFuncionario").value = funcionario.contacto || "";
        document.getElementById("salBaseFuncionario").value = funcionario.salarioBase || 0;

        document.getElementById("salNomeFuncionario").focus();
    }

    async function alterarEstadoFuncionario(id) {
        const funcionario = await DB().obter("funcionarios", id);

        if (!funcionario) return;

        const novoEstado =
            funcionario.estado === "inativo" ? "ativo" : "inativo";

        if (!confirm(
            `Deseja ${novoEstado === "ativo" ? "activar" : "desactivar"} ${funcionario.nome}?`
        )) return;

        await DB().guardar("funcionarios", {
            ...funcionario,
            estado: novoEstado
        });

        await registarHistorico(
            "Alteração",
            `Funcionário ${funcionario.nome}: estado alterado para ${novoEstado}.`
        );

        await carregarDados();
        abrir();
    }

    /* ========================================
       FOLHAS SALARIAIS
    ======================================== */

    async function gerarSalario(evento) {
        evento.preventDefault();

        const funcionarioId = document.getElementById("salFuncionario").value;
        const mes = Number(document.getElementById("salMes").value);
        const ano = Number(document.getElementById("salAno").value);

        const base = numero(document.getElementById("salBase").value);
        const subsidios = numero(document.getElementById("salSubsidios").value);
        const descontos = numero(document.getElementById("salDescontos").value);

        const funcionario = funcionarios.find(
            f => f.id === funcionarioId
        );

        if (!funcionario) {
            notificar("Seleccione um funcionário válido.");
            return;
        }

        if (base <= 0 || mes < 1 || mes > 12 || ano < 2000) {
            notificar("Verifique os valores da folha salarial.");
            return;
        }

        const liquido = base + subsidios - descontos;

        if (liquido <= 0) {
            notificar("O salário líquido deve ser superior a zero.");
            return;
        }

        const duplicado = salarios.some(s =>
            s.funcionarioId === funcionarioId &&
            Number(s.mes) === mes &&
            Number(s.ano) === ano
        );

        if (duplicado) {
            notificar("Já existe uma folha salarial para este funcionário neste mês e ano.");
            return;
        }

        const folha = {
            funcionarioId,
            funcionarioNome: funcionario.nome,
            cargo: funcionario.cargo,
            mes,
            ano,
            salarioBase: base,
            subsidios,
            descontos,
            salarioLiquido: liquido,
            pagamentos: [],
            estado: "pendente",
            data: dataAtual()
        };

        try {
            await DB().guardar("salarios", folha);

            await registarHistorico(
                "Registo",
                `Folha salarial criada para ${funcionario.nome} - ${MESES[mes - 1]} de ${ano}.`,
                liquido
            );

            await carregarDados();
            abrir();

            notificar("Folha salarial criada com sucesso.");

        } catch (erro) {
            console.error(erro);
            notificar("Não foi possível criar a folha salarial.");
        }
    }

    /* ========================================
       PAGAMENTOS
    ======================================== */

    async function registarPagamento(id) {
        const salario = await DB().obter("salarios", id);

        if (!salario) return;

        const saldo = saldoPendente(salario);

        if (saldo <= 0) {
            notificar("Esta folha salarial já está totalmente paga.");
            return;
        }

        const resposta = prompt(
            `Funcionário: ${salario.funcionarioNome}\n` +
            `Salário previsto: ${moeda(salario.salarioLiquido)}\n` +
            `Total pago: ${moeda(totalPago(salario))}\n` +
            `Saldo pendente: ${moeda(saldo)}\n\n` +
            "Introduza o valor a pagar:"
        );

        if (resposta === null) return;

        const valor = Number(resposta.replace(",", "."));

        if (!Number.isFinite(valor) || valor <= 0) {
            notificar("Introduza um valor válido.");
            return;
        }

        if (valor > saldo) {
            notificar("O pagamento não pode ultrapassar o saldo pendente.");
            return;
        }

        const metodo = prompt(
            "Método de pagamento:\n" +
            "Dinheiro, Transferência ou Outro"
        );

        if (metodo === null || !metodo.trim()) return;

        const pagamento = {
            id: DB().gerarID(),
            valor,
            data: dataAtual(),
            metodo: metodo.trim(),
            estado: "confirmado"
        };

        salario.pagamentos = salario.pagamentos || [];
        salario.pagamentos.push(pagamento);

        atualizarEstado(salario);

        try {
            await DB().guardar("salarios", salario);

            await registarHistorico(
                "Pagamento",
                `Pagamento de salário a ${salario.funcionarioNome} - ${MESES[salario.mes - 1]}/${salario.ano}.`,
                valor
            );

            await carregarDados();
            abrir();

            notificar("Pagamento registado com sucesso.");

        } catch (erro) {
            console.error(erro);
            notificar("Não foi possível registar o pagamento.");
        }
    }

    async function anularPagamento(salarioId, pagamentoId) {
        const salario = await DB().obter("salarios", salarioId);

        if (!salario) return;

        const pagamento = (salario.pagamentos || []).find(
            p => p.id === pagamentoId
        );

        if (!pagamento || pagamento.estado === "anulado") return;

        const motivo = prompt(
            "Indique o motivo da anulação deste pagamento:"
        );

        if (motivo === null || !motivo.trim()) {
            notificar("É necessário indicar o motivo da anulação.");
            return;
        }

        if (!confirm(
            `Confirma a anulação do pagamento de ${moeda(pagamento.valor)}?`
        )) return;

        pagamento.estado = "anulado";
        pagamento.motivoAnulacao = motivo.trim();
        pagamento.dataAnulacao = new Date().toISOString();

        atualizarEstado(salario);

        try {
            await DB().guardar("salarios", salario);

            await registarHistorico(
                "Anulação",
                `Pagamento de ${salario.funcionarioNome} - ${MESES[salario.mes - 1]}/${salario.ano} anulado.`,
                pagamento.valor,
                motivo.trim()
            );

            await carregarDados();
            consultarSalario(salarioId);

            notificar("Pagamento anulado. O registo foi preservado no histórico.");

        } catch (erro) {
            console.error(erro);
            notificar("Não foi possível anular o pagamento.");
        }
    }

    /* ========================================
       CONSULTA DE FOLHA
    ======================================== */

    async function consultarSalario(id) {
        const salario = await DB().obter("salarios", id);

        if (!salario) return;

        const pagamentos = (salario.pagamentos || []).map(p => `
            <tr>
                <td>${escapar(p.data || "")}</td>
                <td>${moeda(p.valor)}</td>
                <td>${escapar(p.metodo || "—")}</td>
                <td>
                    ${p.estado === "anulado"
                        ? '<span class="estado-entrada estado-pendente">Anulado</span>'
                        : '<span class="estado-entrada estado-pago">Confirmado</span>'}
                </td>
                <td>
                    ${p.estado === "anulado"
                        ? escapar(p.motivoAnulacao || "")
                        : `<button class="botao-secundario sal-anular-pagamento"
                            data-pagamento="${escapar(p.id)}"
                            data-salario="${escapar(id)}">
                            Anular
                           </button>`}
                </td>
            </tr>
        `).join("");

        const conteudo = `
            <div class="painel-formulario">
                <div class="cabecalho-tabela">
                    <h3>Detalhes da folha salarial</h3>
                    <button class="botao-secundario" id="salVoltar">
                        Voltar
                    </button>
                </div>

                <p><strong>Funcionário:</strong> ${escapar(salario.funcionarioNome)}</p>
                <p><strong>Cargo:</strong> ${escapar(salario.cargo)}</p>
                <p><strong>Período:</strong> ${MESES[salario.mes - 1]} de ${salario.ano}</p>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Salário líquido</span>
                        <strong>${moeda(salario.salarioLiquido)}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Total pago</span>
                        <strong>${moeda(totalPago(salario))}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Saldo pendente</span>
                        <strong>${moeda(saldoPendente(salario))}</strong>
                    </div>
                </div>

                <h3>Composição salarial</h3>
                <p>Salário-base: ${moeda(salario.salarioBase)}</p>
                <p>Subsídios: ${moeda(salario.subsidios)}</p>
                <p>Descontos: ${moeda(salario.descontos)}</p>

                <h3>Histórico de pagamentos</h3>
                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Valor</th>
                                <th>Método</th>
                                <th>Estado</th>
                                <th>Acção / Motivo</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${pagamentos || '<tr><td colspan="5">Ainda não existem pagamentos.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        `;

        const area = document.getElementById("conteudoModulo");
        area.innerHTML = conteudo;

        document.getElementById("salVoltar").addEventListener("click", abrir);

        area.querySelectorAll(".sal-anular-pagamento").forEach(botao => {
            botao.addEventListener("click", () =>
                anularPagamento(
                    botao.dataset.salario,
                    botao.dataset.pagamento
                )
            );
        });
    }

    /* ========================================
       INTERFACE
    ======================================== */

    function renderizarFuncionarios() {
        const ativos = funcionarios.filter(
            f => f.estado !== "inativo"
        );

        return `
            <div class="painel-tabela">
                <div class="cabecalho-tabela">
                    <h3>Funcionários registados</h3>
                </div>

                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Funcionário</th>
                                <th>Cargo</th>
                                <th>Salário-base</th>
                                <th>Estado</th>
                                <th>Acções</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${funcionarios.map(f => `
                                <tr>
                                    <td>${escapar(f.nome)}</td>
                                    <td>${escapar(f.cargo)}</td>
                                    <td>${moeda(f.salarioBase)}</td>
                                    <td>${f.estado === "inativo" ? "Inactivo" : "Activo"}</td>
                                    <td>
                                        <button class="botao-secundario sal-editar-funcionario"
                                            data-id="${escapar(f.id)}">
                                            Editar
                                        </button>
                                        <button class="botao-secundario sal-estado-funcionario"
                                            data-id="${escapar(f.id)}">
                                            ${f.estado === "inativo" ? "Activar" : "Desactivar"}
                                        </button>
                                    </td>
                                </tr>
                            `).join("") || '<tr><td colspan="5">Nenhum funcionário registado.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    function renderizarSalarios() {
        return `
            <div class="painel-tabela">
                <div class="cabecalho-tabela">
                    <h3>Folhas salariais</h3>
                </div>

                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Funcionário</th>
                                <th>Período</th>
                                <th>Salário líquido</th>
                                <th>Total pago</th>
                                <th>Pendente</th>
                                <th>Estado</th>
                                <th>Acções</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${[...salarios].sort((a, b) =>
                                Number(b.ano) - Number(a.ano) ||
                                Number(b.mes) - Number(a.mes)
                            ).map(s => `
                                <tr>
                                    <td>${escapar(s.funcionarioNome)}</td>
                                    <td>${MESES[s.mes - 1]} / ${s.ano}</td>
                                    <td>${moeda(s.salarioLiquido)}</td>
                                    <td>${moeda(totalPago(s))}</td>
                                    <td>${moeda(saldoPendente(s))}</td>
                                    <td>${estadoHTML(atualizarEstado(s))}</td>
                                    <td>
                                        <button class="botao-secundario sal-consultar"
                                            data-id="${escapar(s.id)}">
                                            Consultar
                                        </button>
                                        ${saldoPendente(s) > 0 ? `
                                            <button class="botao-principal sal-pagar"
                                                data-id="${escapar(s.id)}">
                                                Registar pagamento
                                            </button>
                                        ` : ""}
                                    </td>
                                </tr>
                            `).join("") || '<tr><td colspan="7">Nenhuma folha salarial criada.</td></tr>'}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }

    async function abrir() {
        await carregarDados();

        const area = document.getElementById("conteudoModulo");

        const totalPrevisto = salarios.reduce(
            (soma, s) => soma + numero(s.salarioLiquido), 0
        );

        const totalPagoGeral = salarios.reduce(
            (soma, s) => soma + totalPago(s), 0
        );

        const totalPendente = salarios.reduce(
            (soma, s) => soma + saldoPendente(s), 0
        );

        const ativos = funcionarios.filter(
            f => f.estado !== "inativo"
        ).length;

        const mesAtual = new Date().getMonth() + 1;
        const anoAtual = new Date().getFullYear();

        const opcoesFuncionarios = funcionarios
            .filter(f => f.estado !== "inativo")
            .map(f => `
                <option value="${escapar(f.id)}">
                    ${escapar(f.nome)} - ${escapar(f.cargo)}
                </option>
            `).join("");
        const funcionarioActual = funcionarios.find(
            f => f.id === funcionarioEmEdicao
        );
        
        const opcoesCargos = renderizarOpcoesCargos(
            funcionarioActual ? funcionarioActual.cargo : ""
        );

        area.innerHTML = `
            <div class="entradas-modulo">

                <div class="cabecalho-modulo">
                    <div>
                        <h2>Gestão de Salários</h2>
                        <p>Administração de funcionários, folhas salariais e pagamentos.</p>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Funcionários activos</span>
                        <strong>${ativos}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Total previsto</span>
                        <strong>${moeda(totalPrevisto)}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Total pago</span>
                        <strong>${moeda(totalPagoGeral)}</strong>
                    </div>
                    <div class="cartao-indicador">
                        <span>Total pendente</span>
                        <strong>${moeda(totalPendente)}</strong>
                    </div>
                </div>

                <div class="entradas-acoes">
                    <button class="botao-principal" id="salAbrirFuncionario">
                        + Registar funcionário
                    </button>
                    <button class="botao-destaque" id="salAbrirFolha">
                        + Criar folha salarial
                    </button>
                </div>

                ${formularioFuncionarioAberto ? `
                    <div class="painel-formulario">
                        <h3>${funcionarioEmEdicao ? "Editar funcionário" : "Novo funcionário"}</h3>

                        <form id="salFormFuncionario">
                            <div class="formulario-grelha">
                                <div>
                                    <label>Nome completo</label>
                                    <input id="salNomeFuncionario" required>
                                </div>
                                <div>
                                    <label>Cargo / Função</label>
                                    <select id="salCargoFuncionario" required>
                                        ${opcoesCargos}
                                    </select>
                                </div>
                                <div>
                                    <label>Contacto</label>
                                    <input id="salContactoFuncionario">
                                </div>
                                <div>
                                    <label>Salário-base (Kz)</label>
                                    <input id="salBaseFuncionario" type="number" min="1" step="0.01" required>
                                </div>
                            </div>

                            <div class="botoes-formulario">
                                <button class="botao-principal" type="submit">Guardar funcionário</button>
                                <button class="botao-secundario" type="button" id="salCancelarFuncionario">Cancelar</button>
                            </div>
                        </form>
                    </div>
                ` : ""}

                <div class="painel-formulario" id="salPainelFolha" hidden>
                    <h3>Criar folha salarial</h3>

                    <form id="salFormFolha">
                        <div class="formulario-grelha">
                            <div>
                                <label>Funcionário</label>
                                <select id="salFuncionario" required>
                                    <option value="">Seleccione o funcionário</option>
                                    ${opcoesFuncionarios}
                                </select>
                            </div>
                            <div>
                                <label>Mês</label>
                                <select id="salMes" required>
                                    ${MESES.map((m, i) => `
                                        <option value="${i + 1}" ${mesAtual === i + 1 ? "selected" : ""}>${m}</option>
                                    `).join("")}
                                </select>
                            </div>
                            <div>
                                <label>Ano</label>
                                <input id="salAno" type="number" min="2000" value="${anoAtual}" required>
                            </div>
                            <div>
                                <label>Salário-base (Kz)</label>
                                <input id="salBase" type="number" min="1" step="0.01" required>
                            </div>
                            <div>
                                <label>Subsídios (Kz)</label>
                                <input id="salSubsidios" type="number" min="0" step="0.01" value="0">
                            </div>
                            <div>
                                <label>Descontos (Kz)</label>
                                <input id="salDescontos" type="number" min="0" step="0.01" value="0">
                            </div>
                        </div>

                        <div class="informacao-saldo" id="salResumoLiquido">
                            Salário líquido: 0 Kz
                        </div>

                        <div class="botoes-formulario">
                            <button class="botao-principal" type="submit">Criar folha salarial</button>
                            <button class="botao-secundario" type="button" id="salCancelarFolha">Cancelar</button>
                        </div>
                    </form>
                </div>

                ${renderizarFuncionarios()}
                ${renderizarSalarios()}

            </div>
        `;

        ligarEventos();
    }

    /* ========================================
       EVENTOS
    ======================================== */

    function ligarEventos() {
        const area = document.getElementById("conteudoModulo");

        document.getElementById("salAbrirFuncionario")
            .addEventListener("click", () => {
                funcionarioEmEdicao = null;
                formularioFuncionarioAberto = true;
                abrir();
            });

        document.getElementById("salAbrirFolha")
            .addEventListener("click", () => {
                const painel = document.getElementById("salPainelFolha");
                painel.hidden = !painel.hidden;
            });

        const formFuncionario = document.getElementById("salFormFuncionario");

        if (formFuncionario) {
            formFuncionario.addEventListener("submit", guardarFuncionario);

            document.getElementById("salCancelarFuncionario")
                .addEventListener("click", () => {
                    formularioFuncionarioAberto = false;
                    funcionarioEmEdicao = null;
                    abrir();
                });
        }

        const formFolha = document.getElementById("salFormFolha");

        if (formFolha) {
            formFolha.addEventListener("submit", gerarSalario);

            document.getElementById("salCancelarFolha")
                .addEventListener("click", () => {
                    document.getElementById("salPainelFolha").hidden = true;
                });

            const selectFuncionario = document.getElementById("salFuncionario");

            selectFuncionario.addEventListener("change", () => {
                const funcionario = funcionarios.find(
                    f => f.id === selectFuncionario.value
                );

                document.getElementById("salBase").value =
                    funcionario ? funcionario.salarioBase : "";
            });

            const campos = [
                "salBase",
                "salSubsidios",
                "salDescontos"
            ];

            campos.forEach(id => {
                document.getElementById(id).addEventListener(
                    "input",
                    atualizarResumoLiquido
                );
            });
        }

        area.querySelectorAll(".sal-editar-funcionario").forEach(botao => {
            botao.addEventListener("click", () =>
                editarFuncionario(botao.dataset.id)
            );
        });

        area.querySelectorAll(".sal-estado-funcionario").forEach(botao => {
            botao.addEventListener("click", () =>
                alterarEstadoFuncionario(botao.dataset.id)
            );
        });

        area.querySelectorAll(".sal-consultar").forEach(botao => {
            botao.addEventListener("click", () =>
                consultarSalario(botao.dataset.id)
            );
        });

        area.querySelectorAll(".sal-pagar").forEach(botao => {
            botao.addEventListener("click", () =>
                registarPagamento(botao.dataset.id)
            );
        });
    }

    function atualizarResumoLiquido() {
        const base = numero(document.getElementById("salBase").value);
        const subsidios = numero(document.getElementById("salSubsidios").value);
        const descontos = numero(document.getElementById("salDescontos").value);

        const liquido = base + subsidios - descontos;

        document.getElementById("salResumoLiquido").textContent =
            "Salário líquido: " + moeda(liquido);
    }

    /* ========================================
       ACTUALIZAÇÃO E DISPONIBILIZAÇÃO
    ======================================== */

    async function atualizar() {
        await carregarDados();
        await abrir();
    }

    window.SGFE_SALARIOS = Object.freeze({
        abrir,
        atualizar
    });

})();


/* ===== MÓDULO: despesas.js ===== */

(function () {
    "use strict";

    const COLECAO = "despesas";

    function verificarBanco() {
        if (!window.SGFE_DB) {
            throw new Error("O armazenamento do SGFE não está disponível.");
        }
    }

    function formatarValor(valor) {
        return Number(valor || 0).toLocaleString("pt-AO") + " Kz";
    }

    function escapar(texto) {
        return String(texto ?? "").replace(/[&<>"']/g, function (c) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[c];
        });
    }

    function notificar(mensagem) {
        alert(mensagem);
    }

    function dataHoje() {
        return new Date().toISOString().slice(0, 10);
    }

    function pagamentosDaDespesa(despesa) {
        return Array.isArray(despesa.pagamentos)
            ? despesa.pagamentos
            : [];
    }

    function totalPago(despesa) {
        const pagamentos = pagamentosDaDespesa(despesa);

        if (pagamentos.length) {
            return pagamentos
                .filter(p => p.estado !== "anulado")
                .reduce((total, p) => total + Number(p.valor || 0), 0);
        }

        return Number(despesa.valorPago || 0);
    }

    function saldoDespesa(despesa) {
        return Math.max(
            0,
            Number(despesa.valor || 0) - totalPago(despesa)
        );
    }

    function estadoDespesa(despesa) {
        if (despesa.estado === "anulada") return "Anulada";

        const pago = totalPago(despesa);
        const saldo = saldoDespesa(despesa);

        if (saldo <= 0) return "Pago";
        if (pago > 0) return "Parcial";

        return "Pendente";
    }

    function classeEstado(estado) {
        const classes = {
            Pago: "estado-pago",
            Parcial: "estado-parcial",
            Pendente: "estado-pendente",
            Anulada: "estado-pendente"
        };

        return classes[estado] || "estado-pendente";
    }

    async function listarDespesas() {
        verificarBanco();
        return await window.SGFE_DB.listar(COLECAO);
    }

    async function obterDespesa(id) {
        verificarBanco();
        return await window.SGFE_DB.obter(COLECAO, id);
    }

    // REGISTAR DESPESA

    async function registarDespesa(dados) {
        verificarBanco();

        if (!dados || !dados.descricao || !dados.categoria) {
            throw new Error(
                "Informe a descrição e a categoria da despesa."
            );
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error(
                "O valor da despesa deve ser superior a zero."
            );
        }

        const despesa = {
            id: window.SGFE_DB.gerarID(),
            descricao: String(dados.descricao).trim(),
            categoria: String(dados.categoria).trim(),
            tipo: dados.tipo || "variavel",
            servico: dados.servico || "",
            fornecedor: dados.fornecedor || "",
            valor,
            valorPago: 0,
            pagamentos: [],
            data: dados.data || dataHoje(),
            vencimento: dados.vencimento || "",
            observacao: dados.observacao || "",
            estado: "pendente",
            criadoEm: new Date().toISOString()
        };

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "criar",
            modulo: "despesas",
            descricao: "Nova despesa: " + despesa.descricao,
            valor,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // EDITAR DESPESA

    async function atualizarDespesa(id, dados) {
        verificarBanco();

        const despesa = await obterDespesa(id);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        if (despesa.estado === "anulada") {
            throw new Error("Não é possível editar uma despesa anulada.");
        }

        if (!dados.descricao || !dados.categoria) {
            throw new Error(
                "Informe a descrição e a categoria da despesa."
            );
        }

        const valor = Number(dados.valor);
        const pago = totalPago(despesa);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error("O valor deve ser superior a zero.");
        }

        if (valor < pago) {
            throw new Error(
                "O valor da despesa não pode ser inferior ao total já pago: " +
                formatarValor(pago)
            );
        }

        despesa.descricao = String(dados.descricao).trim();
        despesa.categoria = String(dados.categoria).trim();
        despesa.tipo = dados.tipo || "variavel";
        despesa.servico = dados.servico || "";
        despesa.fornecedor = dados.fornecedor || "";
        despesa.valor = valor;
        despesa.data = dados.data || despesa.data;
        despesa.vencimento = dados.vencimento || "";
        despesa.observacao = dados.observacao || "";

        despesa.valorPago = pago;
        despesa.estado = pago >= valor
            ? "pago"
            : pago > 0 ? "parcial" : "pendente";

        despesa.atualizadoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "editar",
            modulo: "despesas",
            descricao: "Despesa actualizada: " + despesa.descricao,
            valor,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // REGISTAR PAGAMENTO

    async function pagarDespesa(dados) {
        verificarBanco();

        if (!dados || !dados.despesaId) {
            throw new Error("Seleccione uma despesa.");
        }

        const despesa = await obterDespesa(dados.despesaId);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        if (despesa.estado === "anulada") {
            throw new Error(
                "Não é possível pagar uma despesa anulada."
            );
        }

        const valor = Number(dados.valor);

        if (!Number.isFinite(valor) || valor <= 0) {
            throw new Error(
                "O valor do pagamento deve ser superior a zero."
            );
        }

        const saldo = saldoDespesa(despesa);

        if (valor > saldo) {
            throw new Error(
                "O pagamento ultrapassa o saldo da despesa. Saldo disponível: " +
                formatarValor(saldo)
            );
        }

        despesa.pagamentos = pagamentosDaDespesa(despesa);

        const pagamento = {
            id: window.SGFE_DB.gerarID(),
            valor,
            data: dados.data || dataHoje(),
            metodo: dados.metodo || "Dinheiro",
            referencia: dados.referencia || "",
            estado: "confirmado",
            criadoEm: new Date().toISOString()
        };

        despesa.pagamentos.push(pagamento);

        despesa.valorPago = totalPago(despesa);

        despesa.estado = despesa.valorPago >= Number(despesa.valor)
            ? "pago"
            : "parcial";

        despesa.atualizadoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "pagamento",
            modulo: "despesas",
            descricao: "Pagamento de despesa: " + despesa.descricao,
            valor,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // ANULAR PAGAMENTO

    async function anularPagamentoDespesa(despesaId, pagamentoId) {
        verificarBanco();

        const despesa = await obterDespesa(despesaId);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        const pagamentos = pagamentosDaDespesa(despesa);

        const pagamento = pagamentos.find(p => p.id === pagamentoId);

        if (!pagamento) {
            throw new Error("Pagamento não encontrado.");
        }

        if (pagamento.estado === "anulado") {
            throw new Error("Este pagamento já foi anulado.");
        }

        pagamento.estado = "anulado";
        pagamento.anuladoEm = new Date().toISOString();

        despesa.valorPago = totalPago(despesa);

        despesa.estado = despesa.valorPago >= Number(despesa.valor)
            ? "pago"
            : despesa.valorPago > 0 ? "parcial" : "pendente";

        despesa.atualizadoEm = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "anulacao_pagamento",
            modulo: "despesas",
            descricao: "Pagamento de despesa anulado: " + despesa.descricao,
            valor: pagamento.valor,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // CONSULTAR SALDO

    async function calcularSaldo(id) {
        const despesa = await obterDespesa(id);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        return saldoDespesa(despesa);
    }

    // ANULAR DESPESA

    async function anularDespesa(id, motivo) {
        verificarBanco();

        const despesa = await obterDespesa(id);

        if (!despesa) {
            throw new Error("Despesa não encontrada.");
        }

        if (despesa.estado === "anulada") {
            throw new Error("Esta despesa já foi anulada.");
        }

        if (totalPago(despesa) > 0) {
            throw new Error(
                "Não é possível anular uma despesa com pagamentos registados."
            );
        }

        despesa.estado = "anulada";
        despesa.motivoAnulacao = motivo || "Não especificado";
        despesa.dataAnulacao = new Date().toISOString();

        await window.SGFE_DB.guardar(COLECAO, despesa);

        await window.SGFE_DB.registarHistorico({
            operacao: "anulacao",
            modulo: "despesas",
            descricao: "Despesa anulada: " + despesa.descricao,
            data: new Date().toISOString()
        });

        return despesa;
    }

    // RESUMO FINANCEIRO

    async function obterResumo() {
        const despesas = await listarDespesas();

        const validas = despesas.filter(
            d => d.estado !== "anulada"
        );

        const total = validas.reduce(
            (soma, d) => soma + Number(d.valor || 0),
            0
        );

        const pago = validas.reduce(
            (soma, d) => soma + totalPago(d),
            0
        );

        return {
            quantidade: validas.length,
            total,
            pago,
            pendente: Math.max(0, total - pago)
        };
    }

    // INTERFACE DO MÓDULO

    function obterConteudo() {
        return document.getElementById("conteudoModulo");
    }

    async function abrir() {
        const conteudo = obterConteudo();

        if (!conteudo) {
            console.error(
                "Área de conteúdo do módulo não encontrada."
            );
            return;
        }

        conteudo.innerHTML = `
            <div class="entradas-modulo">

                <div class="cabecalho-modulo">
                    <div>
                        <h2>Gestão de Despesas</h2>
                        <p>Registo e controlo das saídas financeiras da instituição.</p>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Total de despesas</span>
                        <strong id="despesasTotal">0 Kz</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total pago</span>
                        <strong id="despesasPago">0 Kz</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total pendente</span>
                        <strong id="despesasPendente">0 Kz</strong>
                    </div>
                </div>

                <div class="entradas-acoes">
                    <button type="button" id="btnNovaDespesa">
                        + Registar despesa
                    </button>

                    <button type="button" id="btnNovoPagamentoDespesa">
                        + Registar pagamento
                    </button>
                </div>

                <div id="formularioDespesa" class="painel-formulario" hidden>
                    <h3>Registar nova despesa</h3>

                    <form id="formDespesa">
                        <div class="formulario-grelha">

                            <label>
                                Descrição
                                <input name="descricao" required
                                    placeholder="Ex.: Compra de material escolar">
                            </label>

                            <label>
                                Categoria
                                <select name="categoria" required>
                                    <option value="">Seleccione</option>
                                    <option value="Água">Água</option>
                                    <option value="Energia">Energia eléctrica</option>
                                    <option value="Alimentação">Alimentação</option>
                                    <option value="Material escolar">Material escolar</option>
                                    <option value="Material de escritório">Material de escritório</option>
                                    <option value="Manutenção">Manutenção</option>
                                    <option value="Transporte">Transporte</option>
                                    <option value="Comunicação">Comunicação</option>
                                    <option value="Limpeza">Limpeza</option>
                                    <option value="Serviços">Serviços</option>
                                    <option value="Outras despesas">Outras despesas</option>
                                </select>
                            </label>

                            <label>
                                Tipo de despesa
                                <select name="tipo">
                                    <option value="variavel">Variável</option>
                                    <option value="fixa">Fixa</option>
                                    <option value="extraordinaria">Extraordinária</option>
                                </select>
                            </label>

                            <label>
                                Valor previsto (Kz)
                                <input name="valor" type="number" min="1"
                                    step="0.01" required>
                            </label>

                            <label>
                                Data de registo
                                <input name="data" type="date" required>
                            </label>

                            <label>
                                Data de vencimento (opcional)
                                <input name="vencimento" type="date">
                            </label>

                            <label>
                                Fornecedor (opcional)
                                <input name="fornecedor"
                                    placeholder="Nome do fornecedor">
                            </label>

                            <label>
                                Serviço associado (opcional)
                                <input name="servico"
                                    placeholder="Ex.: Manutenção eléctrica">
                            </label>

                            <label class="campo-completo">
                                Observação
                                <input name="observacao"
                                    placeholder="Informação adicional">
                            </label>

                        </div>

                        <div class="botoes-formulario">
                            <button type="submit">Guardar despesa</button>
                            <button type="button" id="btnCancelarDespesa">
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="formularioPagamentoDespesa"
                    class="painel-formulario" hidden>

                    <h3>Registar pagamento de despesa</h3>

                    <form id="formPagamentoDespesa">
                        <div class="formulario-grelha">

                            <label class="campo-completo">
                                Seleccionar despesa
                                <select name="despesaId"
                                    id="selectDespesa" required>
                                    <option value="">Seleccione uma despesa</option>
                                </select>
                            </label>

                            <label>
                                Valor pago (Kz)
                                <input name="valor" type="number" min="1"
                                    step="0.01" required>
                            </label>

                            <label>
                                Data do pagamento
                                <input name="data" type="date" required>
                            </label>

                            <label>
                                Método de pagamento
                                <select name="metodo">
                                    <option value="Dinheiro">Dinheiro</option>
                                    <option value="Transferência">Transferência</option>
                                    <option value="Multicaixa">Multicaixa</option>
                                    <option value="Outro">Outro</option>
                                </select>
                            </label>

                            <label>
                                Referência (opcional)
                                <input name="referencia"
                                    placeholder="Número do comprovativo">
                            </label>

                        </div>

                        <div id="saldoDespesa"
                            class="informacao-saldo">
                            Seleccione uma despesa para consultar o saldo.
                        </div>

                        <div class="botoes-formulario">
                            <button type="submit">Confirmar pagamento</button>
                            <button type="button" id="btnCancelarPagamentoDespesa">
                                Cancelar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="detalheDespesa"
                    class="painel-formulario" hidden></div>

                <div class="painel-tabela">
                    <div class="cabecalho-tabela">
                        <div>
                            <h3>Registo de despesas</h3>
                            <p>Histórico das despesas da instituição.</p>
                        </div>

                        <input type="search" id="pesquisaDespesas"
                            placeholder="Pesquisar despesa...">
                    </div>

                    <div class="tabela-deslizante">
                        <table>
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Descrição</th>
                                    <th>Categoria</th>
                                    <th>Valor previsto</th>
                                    <th>Pago</th>
                                    <th>Saldo</th>
                                    <th>Estado</th>
                                    <th>Acção</th>
                                </tr>
                            </thead>

                            <tbody id="corpoTabelaDespesas">
                                <tr>
                                    <td colspan="8">A carregar despesas...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        `;

        document.getElementById("btnNovaDespesa").addEventListener(
            "click", () => alternarFormulario("despesa")
        );

        document.getElementById("btnNovoPagamentoDespesa").addEventListener(
            "click", () => alternarFormulario("pagamento")
        );

        document.getElementById("btnCancelarDespesa").addEventListener(
            "click", () => alternarFormulario("")
        );

        document.getElementById("btnCancelarPagamentoDespesa").addEventListener(
            "click", () => alternarFormulario("")
        );

        document.getElementById("formDespesa").addEventListener(
            "submit", guardarFormularioDespesa
        );

        document.getElementById("formPagamentoDespesa").addEventListener(
            "submit", guardarFormularioPagamento
        );

        document.getElementById("selectDespesa").addEventListener(
            "change", atualizarSaldoSelecionado
        );

        document.getElementById("pesquisaDespesas").addEventListener(
            "input", carregarTabela
        );

        document.getElementById("corpoTabelaDespesas").addEventListener(
            "click", function (evento) {
                const botao = evento.target.closest("[data-consultar]");

                if (botao) {
                    consultarDespesa(botao.dataset.consultar);
                }
            }
        );

        const formulario = document.getElementById("formDespesa");
        formulario.elements.data.value = dataHoje();

        const formularioPagamento =
            document.getElementById("formPagamentoDespesa");

        formularioPagamento.elements.data.value = dataHoje();

        await atualizarInterface();
    }

    function alternarFormulario(tipo) {
        const formularioDespesa =
            document.getElementById("formularioDespesa");

        const formularioPagamento =
            document.getElementById("formularioPagamentoDespesa");

        if (!formularioDespesa || !formularioPagamento) return;

        formularioDespesa.hidden = tipo !== "despesa";
        formularioPagamento.hidden = tipo !== "pagamento";

        if (tipo) {
            fecharDetalhe();
        }
    }

    function fecharDetalhe() {
        const detalhe = document.getElementById("detalheDespesa");

        if (detalhe) {
            detalhe.hidden = true;
            detalhe.innerHTML = "";
        }
    }

    // GUARDAR FORMULÁRIOS

    async function guardarFormularioDespesa(evento) {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const dados = Object.fromEntries(
            new FormData(formulario).entries()
        );

        try {
            await registarDespesa(dados);

            formulario.reset();
            formulario.elements.data.value = dataHoje();

            alternarFormulario("");
            await atualizarInterface();

            notificar("Despesa registada com sucesso!");

        } catch (erro) {
            notificar(erro.message);
        }
    }

    async function guardarFormularioPagamento(evento) {
        evento.preventDefault();

        const formulario = evento.currentTarget;
        const dados = Object.fromEntries(
            new FormData(formulario).entries()
        );

        try {
            await pagarDespesa(dados);

            formulario.reset();
            formulario.elements.data.value = dataHoje();

            alternarFormulario("");
            await atualizarInterface();

            notificar("Pagamento registado com sucesso!");

        } catch (erro) {
            notificar(erro.message);
        }
    }

    // ACTUALIZAR INTERFACE

    async function atualizarInterface() {
        await atualizarIndicadores();
        await carregarOpcoesDespesas();
        await carregarTabela();

        if (window.SGFE_PAINEL) {
            await window.SGFE_PAINEL.atualizar();
        }
    }

    async function atualizarIndicadores() {
        const resumo = await obterResumo();

        document.getElementById("despesasTotal").textContent =
            formatarValor(resumo.total);

        document.getElementById("despesasPago").textContent =
            formatarValor(resumo.pago);

        document.getElementById("despesasPendente").textContent =
            formatarValor(resumo.pendente);
    }

    async function carregarOpcoesDespesas() {
        const select = document.getElementById("selectDespesa");

        if (!select) return;

        const despesas = await listarDespesas();

        select.innerHTML =
            '<option value="">Seleccione uma despesa</option>';

        for (const despesa of despesas) {
            if (despesa.estado === "anulada") continue;

            const saldo = saldoDespesa(despesa);

            if (saldo <= 0) continue;

            const opcao = document.createElement("option");

            opcao.value = despesa.id;
            opcao.textContent =
                despesa.descricao + " — Saldo: " +
                formatarValor(saldo);

            select.appendChild(opcao);
        }
    }

    async function atualizarSaldoSelecionado() {
        const select = document.getElementById("selectDespesa");
        const campo = document.getElementById("saldoDespesa");

        if (!select || !campo) return;

        const id = select.value;

        if (!id) {
            campo.textContent =
                "Seleccione uma despesa para consultar o saldo.";
            return;
        }

        const saldo = await calcularSaldo(id);

        campo.textContent =
            "Saldo pendente: " + formatarValor(saldo);
    }

    // CONSULTAR DESPESA

    async function consultarDespesa(id) {
        try {
            const despesa = await obterDespesa(id);

            if (!despesa) {
                throw new Error(
                    "Não foi possível encontrar esta despesa."
                );
            }

            const pagamentos = pagamentosDaDespesa(despesa);

            const ordenados = [...pagamentos].sort((a, b) =>
                String(b.data || "").localeCompare(String(a.data || ""))
            );

            const pago = totalPago(despesa);
            const saldo = saldoDespesa(despesa);
            const estado = estadoDespesa(despesa);

            let linhasHistorico = "";

            if (ordenados.length === 0) {
                linhasHistorico = `
                    <tr>
                        <td colspan="6">
                            Ainda não existem pagamentos registados.
                        </td>
                    </tr>
                `;
            } else {
                for (const pagamento of ordenados) {
                    const anulado = pagamento.estado === "anulado";

                    const botaoAcao = anulado
                        ? "—"
                        : `<button type="button"
                            data-anular-pagamento="${escapar(pagamento.id)}">
                            Anular
                           </button>`;

                    linhasHistorico += `
                        <tr>
                            <td>${escapar(pagamento.data || "—")}</td>

                            <td>${escapar(
                                pagamento.metodo || "Não indicado"
                            )}</td>

                            <td>${escapar(
                                pagamento.referencia || "—"
                            )}</td>

                            <td>${formatarValor(pagamento.valor)}</td>

                            <td>
                                <span class="estado-entrada ${
                                    anulado
                                        ? "estado-pendente"
                                        : "estado-pago"
                                }">
                                    ${anulado ? "Anulado" : "Confirmado"}
                                </span>
                            </td>

                            <td>${botaoAcao}</td>
                        </tr>
                    `;
                }
            }

            const detalhe = document.getElementById("detalheDespesa");

            detalhe.innerHTML = `
                <div class="cabecalho-tabela">
                    <div>
                        <h3>Detalhes da despesa</h3>
                        <p>Consulta individual da despesa seleccionada.</p>
                    </div>

                    <div class="botoes-formulario">
                        ${
                            estado !== "Anulada"
                                ? `<button type="button" id="btnEditarDespesa">
                                    Editar despesa
                                   </button>`
                                : ""
                        }

                        ${
                            estado === "Pendente"
                                ? `<button type="button" id="btnAnularDespesa">
                                    Anular despesa
                                   </button>`
                                : ""
                        }

                        <button type="button" id="btnFecharDetalheDespesa">
                            Fechar consulta
                        </button>
                    </div>
                </div>

                <div class="entradas-indicadores">
                    <div class="cartao-indicador">
                        <span>Valor previsto</span>
                        <strong>${formatarValor(despesa.valor)}</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Total pago</span>
                        <strong>${formatarValor(pago)}</strong>
                    </div>

                    <div class="cartao-indicador">
                        <span>Saldo pendente</span>
                        <strong>${formatarValor(saldo)}</strong>
                    </div>
                </div>

                <div class="formulario-grelha">

                    <label>
                        Descrição
                        <input value="${escapar(despesa.descricao)}" readonly>
                    </label>

                    <label>
                        Categoria
                        <input value="${escapar(despesa.categoria)}" readonly>
                    </label>

                    <label>
                        Tipo
                        <input value="${escapar(despesa.tipo || "variavel")}" readonly>
                    </label>

                    <label>
                        Data de registo
                        <input value="${escapar(despesa.data || "—")}" readonly>
                    </label>

                    <label>
                        Vencimento
                        <input value="${escapar(despesa.vencimento || "—")}" readonly>
                    </label>

                    <label>
                        Estado
                        <input value="${estado}" readonly>
                    </label>

                    <label>
                        Fornecedor
                        <input value="${escapar(despesa.fornecedor || "Não indicado")}" readonly>
                    </label>

                    <label>
                        Serviço associado
                        <input value="${escapar(despesa.servico || "Não indicado")}" readonly>
                    </label>

                    <label class="campo-completo">
                        Observação
                        <input value="${escapar(despesa.observacao || "Sem observações")}" readonly>
                    </label>

                    ${
                        despesa.estado === "anulada"
                            ? `<label class="campo-completo">
                                Motivo da anulação
                                <input value="${escapar(despesa.motivoAnulacao || "Não especificado")}" readonly>
                               </label>`
                            : ""
                    }

                </div>

                <div class="cabecalho-tabela">
                    <div>
                        <h3>Histórico de pagamentos</h3>
                        <p>${ordenados.length} registo(s) de pagamento.</p>
                    </div>
                </div>

                <div class="tabela-deslizante">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Método</th>
                                <th>Referência</th>
                                <th>Valor</th>
                                <th>Estado</th>
                                <th>Acção</th>
                            </tr>
                        </thead>

                        <tbody>${linhasHistorico}</tbody>
                    </table>
                </div>
            `;

            detalhe.hidden = false;

            document.getElementById("btnFecharDetalheDespesa")
                .addEventListener("click", fecharDetalhe);

            const btnEditar = document.getElementById("btnEditarDespesa");

            if (btnEditar) {
                btnEditar.addEventListener(
                    "click",
                    () => abrirEdicaoDespesa(despesa)
                );
            }

            const btnAnular = document.getElementById("btnAnularDespesa");

            if (btnAnular) {
                btnAnular.addEventListener("click", async function () {
                    const motivo = prompt(
                        "Indique o motivo da anulação desta despesa:"
                    );

                    if (motivo === null) return;

                    const confirmar = confirm(
                        "Confirma a anulação desta despesa?"
                    );

                    if (!confirmar) return;

                    try {
                        await anularDespesa(despesa.id, motivo);

                        await atualizarInterface();
                        await consultarDespesa(despesa.id);

                        notificar("Despesa anulada com sucesso!");

                    } catch (erro) {
                        notificar(erro.message);
                    }
                });
            }

            detalhe.querySelectorAll("[data-anular-pagamento]")
                .forEach(botao => {
                    botao.addEventListener("click", async function () {
                        const confirmar = confirm(
                            "Tem a certeza de que pretende anular este pagamento?\n\n" +
                            "O registo será mantido no histórico, mas deixará " +
                            "de contar como valor pago."
                        );

                        if (!confirmar) return;

                        try {
                            await anularPagamentoDespesa(
                                despesa.id,
                                botao.dataset.anularPagamento
                            );

                            await atualizarInterface();
                            await consultarDespesa(despesa.id);

                            notificar("Pagamento anulado com sucesso!");

                        } catch (erro) {
                            notificar(erro.message);
                        }
                    });
                });

            detalhe.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        } catch (erro) {
            notificar(erro.message);
        }
    }

    // EDITAR DESPESA

    function abrirEdicaoDespesa(despesa) {
        const detalhe = document.getElementById("detalheDespesa");

        const categorias = [
            "Água",
            "Energia",
            "Alimentação",
            "Material escolar",
            "Material de escritório",
            "Manutenção",
            "Transporte",
            "Comunicação",
            "Limpeza",
            "Serviços",
            "Outras despesas"
        ];

        const opcoesCategoria = categorias.map(categoria => `
            <option value="${escapar(categoria)}"
                ${despesa.categoria === categoria ? "selected" : ""}>
                ${escapar(categoria)}
            </option>
        `).join("");

        detalhe.innerHTML = `
            <div class="cabecalho-tabela">
                <div>
                    <h3>Editar despesa</h3>
                    <p>Altere os dados da despesa seleccionada.</p>
                </div>
            </div>

            <form id="formEditarDespesa">
                <div class="formulario-grelha">

                    <label>
                        Descrição
                        <input name="descricao" required
                            value="${escapar(despesa.descricao)}">
                    </label>

                    <label>
                        Categoria
                        <select name="categoria" required>
                            ${opcoesCategoria}
                        </select>
                    </label>

                    <label>
                        Tipo de despesa
                        <select name="tipo">
                            <option value="variavel"
                                ${despesa.tipo === "variavel" ? "selected" : ""}>
                                Variável
                            </option>

                            <option value="fixa"
                                ${despesa.tipo === "fixa" ? "selected" : ""}>
                                Fixa
                            </option>

                            <option value="extraordinaria"
                                ${despesa.tipo === "extraordinaria" ? "selected" : ""}>
                                Extraordinária
                            </option>
                        </select>
                    </label>

                    <label>
                        Valor previsto (Kz)
                        <input name="valor" type="number" min="1"
                            step="0.01" required
                            value="${Number(despesa.valor)}">
                    </label>

                    <label>
                        Data de registo
                        <input name="data" type="date" required
                            value="${escapar(despesa.data || "")}">
                    </label>

                    <label>
                        Data de vencimento
                        <input name="vencimento" type="date"
                            value="${escapar(despesa.vencimento || "")}">
                    </label>

                    <label>
                        Fornecedor
                        <input name="fornecedor"
                            value="${escapar(despesa.fornecedor || "")}">
                    </label>

                    <label>
                        Serviço associado
                        <input name="servico"
                            value="${escapar(despesa.servico || "")}">
                    </label>

                    <label class="campo-completo">
                        Observação
                        <input name="observacao"
                            value="${escapar(despesa.observacao || "")}">
                    </label>

                </div>

                <div class="botoes-formulario">
                    <button type="submit">Guardar alterações</button>

                    <button type="button" id="btnCancelarEdicaoDespesa">
                        Cancelar
                    </button>
                </div>
            </form>
        `;

        document.getElementById("btnCancelarEdicaoDespesa")
            .addEventListener(
                "click",
                () => consultarDespesa(despesa.id)
            );

        document.getElementById("formEditarDespesa")
            .addEventListener("submit", async function (evento) {
                evento.preventDefault();

                const dados = Object.fromEntries(
                    new FormData(evento.currentTarget).entries()
                );

                try {
                    await atualizarDespesa(despesa.id, dados);

                    await atualizarInterface();
                    await consultarDespesa(despesa.id);

                    notificar("Despesa actualizada com sucesso!");

                } catch (erro) {
                    notificar(erro.message);
                }
            });
    }

    // CARREGAR TABELA

    async function carregarTabela() {
        const corpo = document.getElementById("corpoTabelaDespesas");

        if (!corpo) return;

        const despesas = await listarDespesas();

        const campoPesquisa =
            document.getElementById("pesquisaDespesas");

        const pesquisa = campoPesquisa
            ? campoPesquisa.value.trim().toLowerCase()
            : "";

        if (despesas.length === 0) {
            corpo.innerHTML = `
                <tr>
                    <td colspan="8">
                        Ainda não existem despesas registadas.
                    </td>
                </tr>
            `;
            return;
        }

        const filtradas = despesas.filter(d =>
            [
                d.descricao,
                d.categoria,
                d.fornecedor,
                d.servico,
                d.observacao,
                d.tipo
            ].join(" ").toLowerCase().includes(pesquisa)
        );

        if (filtradas.length === 0) {
            corpo.innerHTML = `
                <tr>
                    <td colspan="8">Nenhum resultado encontrado.</td>
                </tr>
            `;
            return;
        }

        filtradas.sort((a, b) =>
            String(b.data || "").localeCompare(String(a.data || ""))
        );

        let html = "";

        for (const despesa of filtradas) {
            const pago = totalPago(despesa);
            const saldo = saldoDespesa(despesa);
            const estado = estadoDespesa(despesa);

            html += `
                <tr>
                    <td>${escapar(despesa.data || "—")}</td>

                    <td>${escapar(despesa.descricao)}</td>

                    <td>${escapar(despesa.categoria)}</td>

                    <td>${formatarValor(despesa.valor)}</td>

                    <td>${formatarValor(pago)}</td>

                    <td>${formatarValor(saldo)}</td>

                    <td>
                        <span class="estado-entrada ${classeEstado(estado)}">
                            ${estado}
                        </span>
                    </td>

                    <td>
                        <button type="button"
                            data-consultar="${escapar(despesa.id)}">
                            Consultar
                        </button>
                    </td>
                </tr>
            `;
        }

        corpo.innerHTML = html;
    }

    // DISPONIBILIZAR MÓDULO

    window.SGFE_DESPESAS = Object.freeze({
        registarDespesa,
        listarDespesas,
        obterDespesa,
        atualizarDespesa,
        pagarDespesa,
        anularPagamentoDespesa,
        calcularSaldo,
        anularDespesa,
        obterResumo,
        abrir,
        atualizarInterface,
        consultarDespesa
    });

})();


/* ===== MÓDULO: relatorios.js ===== */
(function () {
    "use strict";

    const modulo = document.getElementById("conteudoModulo");

    const nomesDocumentos = {
        entradas: "Registo completo de entradas",
        historico: "Histórico de pagamentos e anulações",
        folhaIndividual: "Folha salarial individual",
        folhaColetiva: "Folha salarial colectiva",
        pagamentosSalariais: "Relação de pagamentos salariais",
        despesas: "Relatório de despesas",
        financeiro: "Relatório financeiro geral",
        graficos: "Gráficos financeiros"
    };

    let dados = {
        receitas: [],
        pagamentos: [],
        despesas: [],
        salarios: [],
        funcionarios: [],
        configuracao: {}
    };

    let documentoActual = "entradas";

    // --------------------------------------------------
    // FUNÇÕES GERAIS
    // --------------------------------------------------

    function escapar(valor) {
        return String(valor ?? "").replace(/[&<>"']/g, function (caractere) {
            return {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#039;"
            }[caractere];
        });
    }

    function numero(valor) {
        const n = Number(valor);
        return Number.isFinite(n) ? n : 0;
    }

    function moeda(valor) {
        return numero(valor).toLocaleString("pt-AO", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }) + " Kz";
    }

    function dataISO(valor) {
        if (!valor) return "";
        return String(valor).slice(0, 10);
    }

    function dataFormatada(valor) {
        const data = dataISO(valor);
        if (!data) return "—";

        const partes = data.split("-");

        if (partes.length !== 3) {
            return escapar(data);
        }

        return partes[2] + "/" + partes[1] + "/" + partes[0];
    }

    function dentroPeriodo(data, inicio, fim) {
        const valor = dataISO(data);

        if (!valor) return false;
        if (inicio && valor < inicio) return false;
        if (fim && valor > fim) return false;

        return true;
    }

    function somar(lista, funcao) {
        return lista.reduce(
            (total, item) => total + numero(funcao(item)),
            0
        );
    }

    // Data limite para calcular pendências
    function obterDataLimite(filtro) {
        return filtro.fim || new Date().toISOString().slice(0, 10);
    }

    function dataAteLimite(data, limite) {
        const valor = dataISO(data);

        return !!valor && valor <= limite;
    }

    // --------------------------------------------------
    // RECEITAS E PAGAMENTOS
    // --------------------------------------------------

    function obterPagamentosReceita(receitaId) {
        return dados.pagamentos.filter(p =>
            String(p.receitaId) === String(receitaId)
        );
    }

    function pagamentosConfirmadosReceita(receitaId) {
        return obterPagamentosReceita(receitaId).filter(p =>
            p.estado !== "anulado"
        );
    }

    function totalRecebido(receitaId) {
        return somar(
            pagamentosConfirmadosReceita(receitaId),
            p => p.valor
        );
    }

    function totalRecebidoAte(receitaId, limite) {
        return somar(
            pagamentosConfirmadosReceita(receitaId).filter(p =>
                dataAteLimite(p.data, limite)
            ),
            p => p.valor
        );
    }

    function totalRecebidoReceitaNoPeriodo(receitaId, filtro) {
        return somar(
            pagamentosConfirmadosReceita(receitaId).filter(p =>
                dentroPeriodo(p.data, filtro.inicio, filtro.fim)
            ),
            p => p.valor
        );
    }

    function saldoReceitaAte(receita, limite) {
        const recebido = totalRecebidoAte(receita.id, limite);

        return Math.max(
            0,
            numero(receita.valor) - recebido
        );
    }

    // --------------------------------------------------
    // SALÁRIOS
    // --------------------------------------------------

    function pagamentosSalariais(salario) {
        return Array.isArray(salario.pagamentos)
            ? salario.pagamentos
            : [];
    }

    function totalPagoSalario(salario) {
        return somar(
            pagamentosSalariais(salario).filter(p =>
                p.estado !== "anulado"
            ),
            p => p.valor
        );
    }

    function totalPagoSalarioAte(salario, limite) {
        return somar(
            pagamentosSalariais(salario).filter(p =>
                p.estado !== "anulado" &&
                dataAteLimite(p.data, limite)
            ),
            p => p.valor
        );
    }

    function saldoSalario(salario) {
        return Math.max(
            0,
            numero(salario.salarioLiquido) - totalPagoSalario(salario)
        );
    }

    function saldoSalarioAte(salario, limite) {
        return Math.max(
            0,
            numero(salario.salarioLiquido) -
            totalPagoSalarioAte(salario, limite)
        );
    }

    function estadoSalario(salario) {
        const liquido = numero(salario.salarioLiquido);
        const pago = totalPagoSalario(salario);

        if (pago >= liquido && liquido > 0) return "Pago";
        if (pago > 0) return "Parcial";

        return "Pendente";
    }

    function dataFolhaSalario(salario) {
        return String(salario.ano) + "-" +
            String(salario.mes).padStart(2, "0") + "-01";
    }

    // --------------------------------------------------
    // DESPESAS
    // --------------------------------------------------

    function pagamentosDespesa(despesa) {
        const pagamentos = Array.isArray(despesa.pagamentos)
            ? despesa.pagamentos
            : [];

        if (pagamentos.length) {
            return pagamentos.filter(p =>
                p.estado !== "anulado"
            );
        }

        if (numero(despesa.valorPago) > 0) {
            return [{
                valor: numero(despesa.valorPago),
                data: despesa.dataPagamento || despesa.data,
                estado: "confirmado",
                metodo: despesa.metodo || ""
            }];
        }

        return [];
    }

    function totalPagoDespesa(despesa) {
        return somar(
            pagamentosDespesa(despesa),
            p => p.valor
        );
    }

    function totalPagoDespesaAte(despesa, limite) {
        return somar(
            pagamentosDespesa(despesa).filter(p =>
                dataAteLimite(p.data, limite)
            ),
            p => p.valor
        );
    }

    function saldoDespesaAte(despesa, limite) {
        return Math.max(
            0,
            numero(despesa.valor) - totalPagoDespesaAte(despesa, limite)
        );
    }

    // --------------------------------------------------
    // CARREGAMENTO DOS DADOS
    // --------------------------------------------------

    async function carregarDados() {
        const db = window.SGFE_DB;

        if (!db) {
            throw new Error("O armazenamento do SGFE não está disponível.");
        }

        const resultados = await Promise.all([
            db.listar("receitas"),
            db.listar("pagamentos"),
            db.listar("despesas"),
            db.listar("salarios"),
            db.listar("funcionarios")
        ]);

        dados.receitas = resultados[0] || [];
        dados.pagamentos = resultados[1] || [];
        dados.despesas = resultados[2] || [];
        dados.salarios = resultados[3] || [];
        dados.funcionarios = resultados[4] || [];

        if (window.SGFE_CONFIGURACOES) {
            try {
                dados.configuracao =
                    await window.SGFE_CONFIGURACOES.carregar() || {};
            } catch (erro) {
                console.warn(
                    "Não foi possível carregar as configurações.",
                    erro
                );

                dados.configuracao = {};
            }
        }
    }

    // --------------------------------------------------
    // FILTROS
    // --------------------------------------------------

    function obterFiltro() {
        const inicio = document.getElementById("relatorioDataInicio");
        const fim = document.getElementById("relatorioDataFim");
        const mes = document.getElementById("relatorioMes");
        const ano = document.getElementById("relatorioAno");
        const funcionario = document.getElementById("relatorioFuncionario");

        return {
            inicio: inicio ? inicio.value : "",
            fim: fim ? fim.value : "",
            mes: mes ? Number(mes.value) : new Date().getMonth() + 1,
            ano: ano ? Number(ano.value) : new Date().getFullYear(),
            funcionarioId: funcionario ? funcionario.value : ""
        };
    }

    function filtrarPorPeriodo(lista, campo, filtro) {
        return lista.filter(item =>
            dentroPeriodo(item[campo], filtro.inicio, filtro.fim)
        );
    }

    // --------------------------------------------------
    // ELEMENTOS HTML DOS RELATÓRIOS
    // --------------------------------------------------

    function tabela(cabecalhos, linhas, classe = "") {
        let html = '<div class="sgfe-tabela-relatorio"><table class="' +
            escapar(classe) + '"><thead><tr>';

        cabecalhos.forEach(cabecalho => {
            html += "<th>" + escapar(cabecalho) + "</th>";
        });

        html += "</tr></thead><tbody>";

        if (!linhas.length) {
            html += '<tr><td colspan="' + cabecalhos.length +
                '" style="text-align:center">Não existem registos para apresentar.</td></tr>';
        } else {
            linhas.forEach(linha => {
                html += "<tr>";

                linha.forEach(celula => {
                    html += "<td>" + (celula ?? "—") + "</td>";
                });

                html += "</tr>";
            });
        }

        html += "</tbody></table></div>";

        return html;
    }

    function resumoLinha(rotulo, valor) {
        return '<div class="sgfe-resumo-linha"><span>' +
            escapar(rotulo) + '</span><strong>' +
            escapar(valor) + '</strong></div>';
    }

    function cabecalhoRelatorio(titulo, periodo) {
        return '<div class="sgfe-relatorio-cabecalho">' +
            '<h2>' + escapar(titulo) + '</h2>' +
            '<p>Período: ' + escapar(periodo || "Todos os períodos") + '</p>' +
            '<p>Data de emissão: ' +
            dataFormatada(new Date().toISOString()) +
            '</p>' +
            '</div>';
    }

    function periodoTexto(filtro) {
        if (filtro.inicio && filtro.fim) {
            return dataFormatada(filtro.inicio) +
                " a " + dataFormatada(filtro.fim);
        }

        if (filtro.inicio) {
            return "A partir de " + dataFormatada(filtro.inicio);
        }

        if (filtro.fim) {
            return "Até " + dataFormatada(filtro.fim);
        }

        return "Todos os períodos";
    }

    // --------------------------------------------------
    // FUNÇÕES DE ORGANIZAÇÃO MENSAL
    // --------------------------------------------------

    function obterMesChave(data) {
        const valor = dataISO(data);

        return /^\d{4}-\d{2}/.test(valor)
            ? valor.slice(0, 7)
            : "";
    }

    function formatarMes(mesChave) {
        const partes = mesChave.split("-");

        const nomes = [
            "Janeiro", "Fevereiro", "Março", "Abril",
            "Maio", "Junho", "Julho", "Agosto",
            "Setembro", "Outubro", "Novembro", "Dezembro"
        ];

        return nomes[Number(partes[1]) - 1] + " " + partes[0];
    }

    // --------------------------------------------------
    // REGISTO COMPLETO DE ENTRADAS
    // --------------------------------------------------

    function gerarRelatorioEntradas(filtro) {
        const limite = obterDataLimite(filtro);

        const receitas = dados.receitas.filter(receita => {
            if (receita.estado === "anulado") return false;

            const dataRegisto = dataISO(receita.data);

            if (!dataRegisto || dataRegisto > limite) {
                return false;
            }

            const pendente = saldoReceitaAte(receita, limite);

            const registadaNoPeriodo = dentroPeriodo(
                receita.data,
                filtro.inicio,
                filtro.fim
            );

            // Mostrar registos do período e dívidas antigas ainda abertas.
            return registadaNoPeriodo || pendente > 0;
        });

        receitas.sort((a, b) =>
            dataISO(b.data).localeCompare(dataISO(a.data))
        );

        let totalPrevisto = 0;
        let totalRecebidoPeriodo = 0;
        let totalPendente = 0;

        const linhas = receitas.map(receita => {
            const previsto = numero(receita.valor);
            const recebido = totalRecebidoAte(receita.id, limite);
            const pendente = Math.max(0, previsto - recebido);

            totalPrevisto += previsto;
            totalRecebidoPeriodo += recebido;
            totalPendente += pendente;

            let estado = "Pendente";

            if (pendente <= 0 && previsto > 0) {
                estado = "Pago";
            } else if (recebido > 0) {
                estado = "Parcial";
            }

            return [
                escapar(dataFormatada(receita.data)),
                escapar(receita.descricao || "Entrada"),
                escapar(receita.categoria || "—"),
                escapar(receita.aluno || "—"),
                escapar(receita.turma || "—"),
                escapar(moeda(previsto)),
                escapar(moeda(recebido)),
                escapar(moeda(pendente)),
                escapar(estado)
            ];
        });

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.entradas,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha("Total previsto dos registos apresentados", moeda(totalPrevisto)) +
            resumoLinha("Total recebido até à data final", moeda(totalRecebidoPeriodo)) +
            resumoLinha("Total ainda por receber", moeda(totalPendente)) +
            '</div>' +

            tabela(
                [
                    "Data",
                    "Descrição",
                    "Categoria",
                    "Aluno",
                    "Turma",
                    "Valor previsto",
                    "Valor recebido",
                    "Valor pendente",
                    "Estado"
                ],
                linhas
            ) +

            '<p class="sgfe-nota-relatorio">' +
            'Este relatório inclui os registos efectuados no período seleccionado ' +
            'e as receitas anteriores que ainda apresentam valores por receber. ' +
            'Os valores recebidos e pendentes são calculados até ' +
            escapar(dataFormatada(limite)) + '. ' +
            'Pagamentos anulados não são considerados.' +
            '</p>';

        return {
            titulo: nomesDocumentos.entradas,
            conteudo
        };
    }

    // --------------------------------------------------
    // RESUMO FINANCEIRO DETALHADO
    // --------------------------------------------------

    function obterResumoFinanceiroDetalhado(filtro) {
        const limite = obterDataLimite(filtro);

        // 1. Receitas efectivamente recebidas no período
        const receitasRecebidas = somar(
            dados.pagamentos.filter(p =>
                p.estado !== "anulado" &&
                dentroPeriodo(p.data, filtro.inicio, filtro.fim)
            ),
            p => p.valor
        );

        // 2. Receitas ainda por receber até à data limite
        let receitasPendentes = 0;

        dados.receitas.forEach(receita => {
            if (receita.estado === "anulado") return;

            if (!dataAteLimite(receita.data, limite)) return;

            receitasPendentes += saldoReceitaAte(receita, limite);
        });

        // 3. Despesas efectivamente pagas no período
        let despesasPagas = 0;

        dados.despesas.forEach(despesa => {
            despesasPagas += somar(
                pagamentosDespesa(despesa).filter(p =>
                    dentroPeriodo(p.data, filtro.inicio, filtro.fim)
                ),
                p => p.valor
            );
        });

        // 4. Despesas ainda por pagar até à data limite
        let despesasPendentes = 0;

        dados.despesas.forEach(despesa => {
            if (!dataAteLimite(despesa.data, limite)) return;

            despesasPendentes += saldoDespesaAte(despesa, limite);
        });

        // 5. Salários efectivamente pagos no período
        let salariosPagos = 0;

        dados.salarios.forEach(salario => {
            salariosPagos += somar(
                pagamentosSalariais(salario).filter(p =>
                    p.estado !== "anulado" &&
                    dentroPeriodo(p.data, filtro.inicio, filtro.fim)
                ),
                p => p.valor
            );
        });

        // 6. Salários ainda por pagar até à data limite
        let salariosPendentes = 0;

        dados.salarios.forEach(salario => {
            if (!dataAteLimite(dataFolhaSalario(salario), limite)) {
                return;
            }

            salariosPendentes += saldoSalarioAte(salario, limite);
        });

        const totalEntradas =
            receitasRecebidas + receitasPendentes;

        const totalSaidas =
            despesasPagas + salariosPagos;

        const totalSaidasPendentes =
            despesasPendentes + salariosPendentes;

        return {
            receitasRecebidas,
            receitasPendentes,
            totalEntradas,

            despesasPagas,
            despesasPendentes,

            salariosPagos,
            salariosPendentes,

            totalSaidas,
            totalSaidasPendentes,

            saldo: receitasRecebidas - totalSaidas,

            saldoProjetado:
                totalEntradas -
                totalSaidas -
                totalSaidasPendentes
        };
    }

    // --------------------------------------------------
    // MOVIMENTOS MENSAIS
    // --------------------------------------------------

    function obterMovimentosMensais(filtro) {
        const meses = {};

        function garantirMes(chave) {
            if (!chave) return null;

            if (!meses[chave]) {
                meses[chave] = {
                    mes: chave,
                    entradas: 0,
                    despesas: 0,
                    salarios: 0,
                    receitasPendentes: 0,
                    despesasPendentes: 0,
                    salariosPendentes: 0
                };
            }

            return meses[chave];
        }

        // Entradas efectivamente recebidas
        dados.pagamentos.forEach(p => {
            if (
                p.estado === "anulado" ||
                !dentroPeriodo(p.data, filtro.inicio, filtro.fim)
            ) {
                return;
            }

            const mes = garantirMes(obterMesChave(p.data));

            if (mes) {
                mes.entradas += numero(p.valor);
            }
        });

        // Receitas pendentes
        const limite = obterDataLimite(filtro);

        dados.receitas.forEach(r => {
            if (
                r.estado === "anulado" ||
                !dataAteLimite(r.data, limite)
            ) {
                return;
            }

            const pendente = saldoReceitaAte(r, limite);
            const mes = garantirMes(obterMesChave(r.data));

            if (mes) {
                mes.receitasPendentes += pendente;
            }
        });

        // Despesas pagas e pendentes
        dados.despesas.forEach(d => {
            pagamentosDespesa(d).forEach(p => {
                if (!dentroPeriodo(p.data, filtro.inicio, filtro.fim)) {
                    return;
                }

                const mes = garantirMes(obterMesChave(p.data));

                if (mes) {
                    mes.despesas += numero(p.valor);
                }
            });

            if (dataAteLimite(d.data, limite)) {
                const pendente = saldoDespesaAte(d, limite);
                const mes = garantirMes(obterMesChave(d.data));

                if (mes) {
                    mes.despesasPendentes += pendente;
                }
            }
        });

        // Salários pagos e pendentes
        dados.salarios.forEach(s => {
            const dataFolha = dataFolhaSalario(s);

            if (dataAteLimite(dataFolha, limite)) {
                const mes = garantirMes(obterMesChave(dataFolha));

                if (mes) {
                    mes.salariosPendentes += saldoSalarioAte(s, limite);
                }
            }

            pagamentosSalariais(s).forEach(p => {
                if (
                    p.estado === "anulado" ||
                    !dentroPeriodo(p.data, filtro.inicio, filtro.fim)
                ) {
                    return;
                }

                const mes = garantirMes(obterMesChave(p.data));

                if (mes) {
                    mes.salarios += numero(p.valor);
                }
            });
        });

        return Object.values(meses).sort((a, b) =>
            a.mes.localeCompare(b.mes)
        );
    }

    // --------------------------------------------------
    // RELATÓRIO FINANCEIRO GERAL
    // --------------------------------------------------

    function gerarRelatorioFinanceiro(filtro) {
        const resumo = obterResumoFinanceiroDetalhado(filtro);

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.financeiro,
                periodoTexto(filtro)
            ) +

            '<h3>Resumo das entradas</h3>' +

            tabela(
                ["Descrição", "Valor"],
                [
                    [
                        "Receitas recebidas no período",
                        escapar(moeda(resumo.receitasRecebidas))
                    ],
                    [
                        "Receitas pendentes até à data final",
                        escapar(moeda(resumo.receitasPendentes))
                    ],
                    [
                        "Total de entradas",
                        "<strong>" +
                        escapar(moeda(resumo.totalEntradas)) +
                        "</strong>"
                    ]
                ]
            ) +

            '<h3>Resumo das saídas</h3>' +

            tabela(
                ["Descrição", "Valor"],
                [
                    [
                        "Despesas pagas no período",
                        escapar(moeda(resumo.despesasPagas))
                    ],
                    [
                        "Despesas pendentes até à data final",
                        escapar(moeda(resumo.despesasPendentes))
                    ],
                    [
                        "Salários pagos no período",
                        escapar(moeda(resumo.salariosPagos))
                    ],
                    [
                        "Salários pendentes até à data final",
                        escapar(moeda(resumo.salariosPendentes))
                    ],
                    [
                        "Total de saídas pagas",
                        "<strong>" +
                        escapar(moeda(resumo.totalSaidas)) +
                        "</strong>"
                    ],
                    [
                        "Total de saídas pendentes",
                        "<strong>" +
                        escapar(moeda(resumo.totalSaidasPendentes)) +
                        "</strong>"
                    ]
                ]
            ) +

            '<h3>Resultado financeiro</h3>' +

            tabela(
                ["Indicador", "Valor"],
                [
                    [
                        "Total de entradas",
                        escapar(moeda(resumo.totalEntradas))
                    ],
                    [
                        "Total de saídas pagas",
                        escapar(moeda(resumo.totalSaidas))
                    ],
                    [
                        "Saldo disponível do período",
                        "<strong>" +
                        escapar(moeda(resumo.saldo)) +
                        "</strong>"
                    ],
                    [
                        "Saldo projectado após liquidação das pendências",
                        "<strong>" +
                        escapar(moeda(resumo.saldoProjetado)) +
                        "</strong>"
                    ]
                ]
            ) +

            '<p class="sgfe-nota-relatorio">' +
            'O saldo disponível corresponde às receitas recebidas no período ' +
            'menos as saídas efectivamente pagas no período. ' +
            'O saldo projectado considera também as receitas ainda por receber ' +
            'e as obrigações ainda por pagar até à data final seleccionada. ' +
            'Os pagamentos anulados não são considerados.' +
            '</p>';

        return {
            titulo: nomesDocumentos.financeiro,
            conteudo
        };
    }

    // --------------------------------------------------
    // HISTÓRICO DE PAGAMENTOS E ANULAÇÕES
    // --------------------------------------------------

    function gerarHistoricoEntradas(filtro) {
        const pagamentos = filtrarPorPeriodo(
            dados.pagamentos,
            "data",
            filtro
        );

        let confirmados = 0;
        let anulados = 0;

        const linhas = pagamentos.map(pagamento => {
            const receita = dados.receitas.find(r =>
                String(r.id) === String(pagamento.receitaId)
            );

            const anulado = pagamento.estado === "anulado";

            if (anulado) {
                anulados += numero(pagamento.valor);
            } else {
                confirmados += numero(pagamento.valor);
            }

            return [
                escapar(dataFormatada(pagamento.data)),
                escapar(
                    pagamento.descricao ||
                    receita?.descricao ||
                    "Pagamento"
                ),
                escapar(receita?.aluno || "—"),
                escapar(pagamento.metodo || "—"),
                escapar(pagamento.referencia || "—"),
                escapar(moeda(pagamento.valor)),
                anulado
                    ? '<strong style="color:#a32626">ANULADO</strong>'
                    : "Confirmado"
            ];
        });

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.historico,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha("Pagamentos confirmados", moeda(confirmados)) +
            resumoLinha("Pagamentos anulados", moeda(anulados)) +
            '</div>' +

            tabela(
                [
                    "Data",
                    "Descrição",
                    "Aluno",
                    "Método",
                    "Referência",
                    "Valor",
                    "Estado"
                ],
                linhas
            );

        return {
            titulo: nomesDocumentos.historico,
            conteudo
        };
    }

    // --------------------------------------------------
    // FOLHA SALARIAL INDIVIDUAL
    // --------------------------------------------------

    function gerarFolhaIndividual(filtro) {
        const salario = dados.salarios.find(s =>
            String(s.funcionarioId) === String(filtro.funcionarioId) &&
            Number(s.mes) === filtro.mes &&
            Number(s.ano) === filtro.ano
        );

        if (!salario) {
            return {
                titulo: nomesDocumentos.folhaIndividual,
                conteudo:
                    cabecalhoRelatorio(
                        nomesDocumentos.folhaIndividual,
                        filtro.mes + "/" + filtro.ano
                    ) +
                    '<p class="sgfe-aviso-relatorio">' +
                    'Não foi encontrada uma folha salarial para o funcionário e período seleccionados.' +
                    '</p>'
            };
        }

        const pagamentos = pagamentosSalariais(salario);

        const confirmados = pagamentos.filter(p =>
            p.estado !== "anulado"
        );

        const anulados = pagamentos.filter(p =>
            p.estado === "anulado"
        );

        const linhasPagamentos = pagamentos.map(p => [
            escapar(dataFormatada(p.data)),
            escapar(moeda(p.valor)),
            escapar(p.metodo || "—"),
            p.estado === "anulado"
                ? '<strong style="color:#a32626">Anulado</strong>'
                : "Confirmado",
            escapar(p.motivoAnulacao || "—")
        ]);

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.folhaIndividual,
                String(filtro.mes).padStart(2, "0") + "/" + filtro.ano
            ) +

            '<h3>Identificação do funcionário</h3>' +

            tabela(
                ["Nome", "Cargo", "Mês", "Ano"],
                [[
                    escapar(salario.funcionarioNome || "—"),
                    escapar(salario.cargo || "—"),
                    escapar(filtro.mes),
                    escapar(filtro.ano)
                ]]
            ) +

            '<h3>Composição salarial</h3>' +

            tabela(
                [
                    "Salário base",
                    "Subsídios",
                    "Descontos",
                    "Salário líquido"
                ],
                [[
                    escapar(moeda(salario.salarioBase)),
                    escapar(moeda(salario.subsidios)),
                    escapar(moeda(salario.descontos)),
                    escapar(moeda(salario.salarioLiquido))
                ]]
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha("Total pago", moeda(totalPagoSalario(salario))) +
            resumoLinha("Saldo pendente", moeda(saldoSalario(salario))) +
            resumoLinha("Estado da folha", estadoSalario(salario)) +
            '</div>' +

            '<h3>Histórico de pagamentos</h3>' +

            tabela(
                ["Data", "Valor", "Método", "Estado", "Observação"],
                linhasPagamentos
            ) +

            '<p class="sgfe-nota-relatorio">' +
            'Pagamentos confirmados: ' + confirmados.length +
            ' | Pagamentos anulados: ' + anulados.length +
            '</p>';

        return {
            titulo: nomesDocumentos.folhaIndividual,
            conteudo
        };
    }

    // --------------------------------------------------
    // FOLHA SALARIAL COLECTIVA
    // --------------------------------------------------

    function gerarFolhaColetiva(filtro) {
        const folhas = dados.salarios.filter(s =>
            Number(s.mes) === filtro.mes &&
            Number(s.ano) === filtro.ano
        );

        const funcionarios = dados.funcionarios.filter(f =>
            f.estado !== "inativo" &&
            f.estado !== "desativado"
        );

        const linhas = [];

        let totalBase = 0;
        let totalSubsidios = 0;
        let totalDescontos = 0;
        let totalLiquido = 0;
        let totalPago = 0;
        let totalPendente = 0;

        funcionarios.forEach(funcionario => {
            const folha = folhas.find(s =>
                String(s.funcionarioId) === String(funcionario.id)
            );

            if (!folha) {
                linhas.push([
                    escapar(funcionario.nome || "—"),
                    escapar(funcionario.cargo || "—"),
                    "—",
                    "—",
                    "—",
                    "—",
                    "—",
                    "—",
                    '<strong>Sem folha</strong>'
                ]);

                return;
            }

            const base = numero(folha.salarioBase);
            const subsidios = numero(folha.subsidios);
            const descontos = numero(folha.descontos);
            const liquido = numero(folha.salarioLiquido);
            const pago = totalPagoSalario(folha);
            const pendente = saldoSalario(folha);

            totalBase += base;
            totalSubsidios += subsidios;
            totalDescontos += descontos;
            totalLiquido += liquido;
            totalPago += pago;
            totalPendente += pendente;

            linhas.push([
                escapar(folha.funcionarioNome || funcionario.nome || "—"),
                escapar(folha.cargo || funcionario.cargo || "—"),
                escapar(moeda(base)),
                escapar(moeda(subsidios)),
                escapar(moeda(descontos)),
                escapar(moeda(liquido)),
                escapar(moeda(pago)),
                escapar(moeda(pendente)),
                escapar(estadoSalario(folha))
            ]);
        });

        linhas.push([
            "<strong>TOTAIS</strong>",
            "",
            "<strong>" + escapar(moeda(totalBase)) + "</strong>",
            "<strong>" + escapar(moeda(totalSubsidios)) + "</strong>",
            "<strong>" + escapar(moeda(totalDescontos)) + "</strong>",
            "<strong>" + escapar(moeda(totalLiquido)) + "</strong>",
            "<strong>" + escapar(moeda(totalPago)) + "</strong>",
            "<strong>" + escapar(moeda(totalPendente)) + "</strong>",
            ""
        ]);

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.folhaColetiva,
                String(filtro.mes).padStart(2, "0") + "/" + filtro.ano
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha(
                "Total líquido das folhas existentes",
                moeda(totalLiquido)
            ) +
            resumoLinha("Total pago", moeda(totalPago)) +
            resumoLinha("Total pendente", moeda(totalPendente)) +
            '</div>' +

            tabela(
                [
                    "Funcionário",
                    "Cargo",
                    "Base",
                    "Subsídios",
                    "Descontos",
                    "Líquido",
                    "Pago",
                    "Pendente",
                    "Estado"
                ],
                linhas
            );

        return {
            titulo: nomesDocumentos.folhaColetiva,
            conteudo,
            orientacao: "paisagem"
        };
    }

    // --------------------------------------------------
    // RELAÇÃO DE PAGAMENTOS SALARIAIS
    // --------------------------------------------------

    function gerarPagamentosSalariais(filtro) {
        const linhas = [];

        let totalConfirmado = 0;
        let totalAnulado = 0;

        dados.salarios.forEach(salario => {
            pagamentosSalariais(salario).forEach(pagamento => {
                if (!dentroPeriodo(
                    pagamento.data,
                    filtro.inicio,
                    filtro.fim
                )) {
                    return;
                }

                const anulado = pagamento.estado === "anulado";

                if (anulado) {
                    totalAnulado += numero(pagamento.valor);
                } else {
                    totalConfirmado += numero(pagamento.valor);
                }

                linhas.push([
                    escapar(dataFormatada(pagamento.data)),
                    escapar(salario.funcionarioNome || "—"),
                    escapar(salario.cargo || "—"),
                    escapar(moeda(pagamento.valor)),
                    escapar(pagamento.metodo || "—"),
                    anulado
                        ? '<strong style="color:#a32626">Anulado</strong>'
                        : "Confirmado",
                    escapar(pagamento.motivoAnulacao || "—")
                ]);
            });
        });

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.pagamentosSalariais,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha(
                "Pagamentos confirmados",
                moeda(totalConfirmado)
            ) +
            resumoLinha(
                "Pagamentos anulados",
                moeda(totalAnulado)
            ) +
            '</div>' +

            tabela(
                [
                    "Data",
                    "Funcionário",
                    "Cargo",
                    "Valor",
                    "Método",
                    "Estado",
                    "Observação"
                ],
                linhas
            );

        return {
            titulo: nomesDocumentos.pagamentosSalariais,
            conteudo
        };
    }

    // --------------------------------------------------
    // RELATÓRIO DE DESPESAS
    // --------------------------------------------------

    function gerarRelatorioDespesas(filtro) {
        const linhas = [];

        let totalPrevisto = 0;
        let totalPago = 0;
        let totalPendente = 0;

        const limite = obterDataLimite(filtro);

        dados.despesas.forEach(despesa => {
            const pagamentos = pagamentosDespesa(despesa);

            const pagosNoPeriodo = pagamentos.filter(p =>
                dentroPeriodo(p.data, filtro.inicio, filtro.fim)
            );

            const previstaNoPeriodo = dentroPeriodo(
                despesa.data,
                filtro.inicio,
                filtro.fim
            );

            const pendenteAteLimite = dataAteLimite(
                despesa.data,
                limite
            )
                ? saldoDespesaAte(despesa, limite)
                : 0;

            if (
                !previstaNoPeriodo &&
                !pagosNoPeriodo.length &&
                pendenteAteLimite <= 0
            ) {
                return;
            }

            const previsto = previstaNoPeriodo
                ? numero(despesa.valor)
                : 0;

            const pago = somar(pagosNoPeriodo, p => p.valor);

            totalPrevisto += previsto;
            totalPago += pago;

            if (pendenteAteLimite > 0) {
                totalPendente += pendenteAteLimite;
            }

            let estado = "Pendente";

            if (pendenteAteLimite <= 0 && previsto > 0) {
                estado = "Pago";
            } else if (pago > 0 || totalPagoDespesaAte(despesa, limite) > 0) {
                estado = "Parcial";
            }

            linhas.push([
                escapar(dataFormatada(despesa.data)),
                escapar(despesa.descricao || despesa.nome || "Despesa"),
                escapar(despesa.categoria || despesa.tipo || "—"),
                escapar(despesa.servico || "—"),
                escapar(moeda(previsto)),
                escapar(moeda(pago)),
                escapar(moeda(pendenteAteLimite)),
                escapar(estado)
            ]);
        });

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.despesas,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha("Total previsto no período", moeda(totalPrevisto)) +
            resumoLinha("Total pago no período", moeda(totalPago)) +
            resumoLinha("Total pendente até à data final", moeda(totalPendente)) +
            '</div>' +

            tabela(
                [
                    "Data",
                    "Descrição",
                    "Categoria",
                    "Serviço",
                    "Previsto",
                    "Pago no período",
                    "Pendente",
                    "Estado"
                ],
                linhas
            );

        return {
            titulo: nomesDocumentos.despesas,
            conteudo
        };
    }

    // --------------------------------------------------
    // GRÁFICOS FINANCEIROS
    // --------------------------------------------------

    function gerarGraficos(filtro) {
        const resumo = obterResumoFinanceiroDetalhado(filtro);
        const movimentos = obterMovimentosMensais(filtro);

        const maiorEntrada = Math.max(
            1,
            ...movimentos.map(m => m.entradas)
        );

        const maiorSaida = Math.max(
            1,
            ...movimentos.map(m => m.despesas + m.salarios)
        );

        function barraMensal(nome, valor, maior) {
            const largura = Math.max(
                0,
                (valor / maior) * 100
            );

            return '<div class="sgfe-grafico-linha">' +
                '<div class="sgfe-grafico-legenda">' +
                '<span>' + escapar(nome) + '</span>' +
                '<strong>' + escapar(moeda(valor)) + '</strong>' +
                '</div>' +
                '<div class="sgfe-grafico-fundo">' +
                '<div class="sgfe-barra" style="width:' +
                largura + '%"></div>' +
                '</div></div>';
        }

        const graficosEntradas = movimentos.map(m =>
            '<div class="sgfe-grafico-mes">' +
            '<h4>' + escapar(formatarMes(m.mes)) + '</h4>' +
            barraMensal(
                "Entradas recebidas",
                m.entradas,
                maiorEntrada
            ) +
            '</div>'
        ).join("");

        const graficosSaidas = movimentos.map(m =>
            '<div class="sgfe-grafico-mes">' +
            '<h4>' + escapar(formatarMes(m.mes)) + '</h4>' +
            barraMensal(
                "Despesas pagas",
                m.despesas,
                maiorSaida
            ) +
            barraMensal(
                "Salários pagos",
                m.salarios,
                maiorSaida
            ) +
            '</div>'
        ).join("");

        const linhasMensais = movimentos.map(m => [
            escapar(formatarMes(m.mes)),
            escapar(moeda(m.entradas)),
            escapar(moeda(m.despesas)),
            escapar(moeda(m.salarios)),
            escapar(moeda(
                m.entradas - m.despesas - m.salarios
            ))
        ]);

        const conteudo =
            cabecalhoRelatorio(
                nomesDocumentos.graficos,
                periodoTexto(filtro)
            ) +

            '<div class="sgfe-resumo-relatorio">' +
            resumoLinha(
                "Total de entradas",
                moeda(resumo.totalEntradas)
            ) +
            resumoLinha(
                "Total de saídas pagas",
                moeda(resumo.totalSaidas)
            ) +
            resumoLinha(
                "Saldo disponível",
                moeda(resumo.saldo)
            ) +
            resumoLinha(
                "Total de pendências",
                moeda(
                    resumo.receitasPendentes +
                    resumo.totalSaidasPendentes
                )
            ) +
            '</div>' +

            '<h3>Entradas por mês</h3>' +
            '<div class="sgfe-grafico">' +
            (
                graficosEntradas ||
                '<p>Sem movimentos de entrada no período.</p>'
            ) +
            '</div>' +

            '<div class="sgfe-quebra-pagina"></div>' +

            '<h3>Saídas por mês</h3>' +
            '<div class="sgfe-grafico">' +
            (
                graficosSaidas ||
                '<p>Sem movimentos de saída no período.</p>'
            ) +
            '</div>' +

            '<div class="sgfe-quebra-pagina"></div>' +

            '<h3>Resumo mensal de movimentos</h3>' +

            tabela(
                [
                    "Mês",
                    "Entradas",
                    "Despesas",
                    "Salários",
                    "Saldo mensal"
                ],
                linhasMensais
            ) +

            '<h3>Situação das pendências</h3>' +

            tabela(
                ["Tipo", "Valor pendente"],
                [
                    [
                        "Receitas por receber",
                        escapar(moeda(resumo.receitasPendentes))
                    ],
                    [
                        "Despesas por pagar",
                        escapar(moeda(resumo.despesasPendentes))
                    ],
                    [
                        "Salários por pagar",
                        escapar(moeda(resumo.salariosPendentes))
                    ]
                ]
            );

        return {
            titulo: nomesDocumentos.graficos,
            conteudo,
            orientacao: "paisagem"
        };
    }

    // --------------------------------------------------
    // CONSTRUIR O DOCUMENTO SELECCIONADO
    // --------------------------------------------------

    function construirDocumento(tipo, filtro) {
        switch (tipo) {
            case "entradas":
                return gerarRelatorioEntradas(filtro);

            case "historico":
                return gerarHistoricoEntradas(filtro);

            case "folhaIndividual":
                return gerarFolhaIndividual(filtro);

            case "folhaColetiva":
                return gerarFolhaColetiva(filtro);

            case "pagamentosSalariais":
                return gerarPagamentosSalariais(filtro);

            case "despesas":
                return gerarRelatorioDespesas(filtro);

            case "financeiro":
                return gerarRelatorioFinanceiro(filtro);

            case "graficos":
                return gerarGraficos(filtro);

            default:
                return gerarRelatorioEntradas(filtro);
        }
    }

    // --------------------------------------------------
    // INTERFACE DA CENTRAL DE RELATÓRIOS
    // --------------------------------------------------

    function criarInterface() {
        const hoje = new Date();

        const anoActual = hoje.getFullYear();

        const mesActual = String(
            hoje.getMonth() + 1
        ).padStart(2, "0");

        const funcionariosOptions = dados.funcionarios.map(f =>
            '<option value="' + escapar(f.id) + '">' +
            escapar(f.nome || "Funcionário") +
            '</option>'
        ).join("");

        modulo.innerHTML = `
            <section class="entradas-modulo sgfe-relatorios">
                <div class="cabecalho-modulo">
                    <div>
                        <h2>Central de Relatórios</h2>
                        <p>Consulta, organização e impressão dos documentos financeiros.</p>
                    </div>
                </div>

                <div class="painel-formulario sgfe-filtros-relatorio">
                    <h3>Seleccionar documento</h3>

                    <div class="formulario-grelha">
                        <div class="campo-formulario">
                            <label for="relatorioTipo">Tipo de relatório</label>
                            <select id="relatorioTipo">
                                <option value="entradas">Registo completo de entradas</option>
                                <option value="historico">Histórico de pagamentos e anulações</option>
                                <option value="folhaIndividual">Folha salarial individual</option>
                                <option value="folhaColetiva">Folha salarial colectiva</option>
                                <option value="pagamentosSalariais">Relação de pagamentos salariais</option>
                                <option value="despesas">Relatório de despesas</option>
                                <option value="financeiro">Relatório financeiro geral</option>
                                <option value="graficos">Gráficos financeiros</option>
                            </select>
                        </div>

                        <div class="campo-formulario">
                            <label for="relatorioDataInicio">Data inicial</label>
                            <input type="date" id="relatorioDataInicio">
                        </div>

                        <div class="campo-formulario">
                            <label for="relatorioDataFim">Data final</label>
                            <input type="date" id="relatorioDataFim">
                        </div>

                        <div class="campo-formulario sgfe-campo-folha" hidden>
                            <label for="relatorioMes">Mês da folha</label>
                            <select id="relatorioMes">
                                <option value="1">Janeiro</option>
                                <option value="2">Fevereiro</option>
                                <option value="3">Março</option>
                                <option value="4">Abril</option>
                                <option value="5">Maio</option>
                                <option value="6">Junho</option>
                                <option value="7">Julho</option>
                                <option value="8">Agosto</option>
                                <option value="9">Setembro</option>
                                <option value="10">Outubro</option>
                                <option value="11">Novembro</option>
                                <option value="12">Dezembro</option>
                            </select>
                        </div>

                        <div class="campo-formulario sgfe-campo-folha" hidden>
                            <label for="relatorioAno">Ano</label>
                            <input type="number" id="relatorioAno" min="2000" max="2100" value="${anoActual}">
                        </div>

                        <div class="campo-formulario sgfe-campo-funcionario" hidden>
                            <label for="relatorioFuncionario">Funcionário</label>
                            <select id="relatorioFuncionario">
                                <option value="">Seleccionar funcionário</option>
                                ${funcionariosOptions}
                            </select>
                        </div>
                    </div>

                    <div class="botoes-formulario">
                        <button type="button" class="botao-principal" id="btnVisualizarRelatorio">
                            Visualizar relatório
                        </button>

                        <button type="button" class="botao-secundario" id="btnImprimirRelatorio" disabled>
                            Imprimir / Guardar PDF
                        </button>
                    </div>
                </div>

                <div class="painel-tabela sgfe-area-visualizacao">
                    <div class="cabecalho-tabela">
                        <h3>Pré-visualização</h3>
                        <span id="relatorioEstado">Seleccione um documento para começar.</span>
                    </div>

                    <div id="relatorioVisualizacao" class="sgfe-visualizacao-conteudo">
                        <div class="modulo-placeholder">
                            <div class="placeholder-icone">▤</div>
                            <h3>Central de documentos</h3>
                            <p>Escolha o tipo de relatório e clique em “Visualizar relatório”.</p>
                        </div>
                    </div>
                </div>
            </section>
        `;

        document.getElementById("relatorioMes").value = mesActual;
        document.getElementById("relatorioAno").value = anoActual;

        document.getElementById("relatorioTipo").addEventListener(
            "change",
            atualizarCampos
        );

        document.getElementById("btnVisualizarRelatorio").addEventListener(
            "click",
            visualizar
        );

        document.getElementById("btnImprimirRelatorio").addEventListener(
            "click",
            imprimir
        );

        atualizarCampos();
    }

    function atualizarCampos() {
        const tipo = document.getElementById("relatorioTipo").value;

        const usaFolha =
            tipo === "folhaIndividual" ||
            tipo === "folhaColetiva";

        const usaFuncionario =
            tipo === "folhaIndividual";

        document.querySelectorAll(".sgfe-campo-folha").forEach(campo => {
            campo.hidden = !usaFolha;
        });

        document.querySelectorAll(".sgfe-campo-funcionario").forEach(campo => {
            campo.hidden = !usaFuncionario;
        });

        const usaPeriodo = !usaFolha;

        document.getElementById("relatorioDataInicio").disabled =
            !usaPeriodo;

        document.getElementById("relatorioDataFim").disabled =
            !usaPeriodo;
    }

    // --------------------------------------------------
    // VISUALIZAÇÃO DO RELATÓRIO
    // --------------------------------------------------

    async function visualizar() {
        const botao = document.getElementById("btnVisualizarRelatorio");
        const estado = document.getElementById("relatorioEstado");
        const area = document.getElementById("relatorioVisualizacao");
        const imprimirBotao = document.getElementById("btnImprimirRelatorio");

        try {
            botao.disabled = true;

            estado.textContent = "A preparar relatório...";

            await carregarDados();

            documentoActual =
                document.getElementById("relatorioTipo").value;

            const filtro = obterFiltro();

            if (
                filtro.inicio &&
                filtro.fim &&
                filtro.inicio > filtro.fim
            ) {
                throw new Error(
                    "A data inicial não pode ser posterior à data final."
                );
            }

            if (
                documentoActual === "folhaIndividual" &&
                !filtro.funcionarioId
            ) {
                throw new Error(
                    "Seleccione o funcionário para consultar a folha individual."
                );
            }

            const documento = construirDocumento(
                documentoActual,
                filtro
            );

            area.innerHTML = documento.conteudo;

            estado.textContent = "Relatório preparado.";

            imprimirBotao.disabled = false;

            area.dataset.titulo = documento.titulo;

            area.dataset.orientacao =
                documento.orientacao || "retrato";

        } catch (erro) {
            area.innerHTML =
                '<p class="sgfe-erro-relatorio">' +
                escapar(
                    erro.message ||
                    "Não foi possível gerar o relatório."
                ) +
                '</p>';

            estado.textContent =
                "Não foi possível preparar o documento.";

            imprimirBotao.disabled = true;

        } finally {
            botao.disabled = false;
        }
    }

    // --------------------------------------------------
    // IMPRESSÃO
    // --------------------------------------------------

    function imprimir() {
        const area = document.getElementById("relatorioVisualizacao");

        const botao = document.getElementById(
            "btnImprimirRelatorio"
        );

        if (
            !area ||
            !area.innerHTML.trim() ||
            botao.disabled
        ) {
            alert("Primeiro, visualize o relatório.");
            return;
        }

        if (!window.SGFE_IMPRESSAO) {
            alert(
                "O motor de impressão não está disponível. Verifique o ficheiro impressao.js."
            );

            return;
        }

        window.SGFE_IMPRESSAO.imprimir({
            titulo: area.dataset.titulo || "Relatório financeiro",
            periodo: periodoTexto(obterFiltro()),
            conteudo: area.innerHTML,
            orientacao: area.dataset.orientacao || "retrato",
            assinaturas: true
        });
    }

    // --------------------------------------------------
    // FUNÇÕES DE RESUMO DISPONÍVEIS PARA OUTROS MÓDULOS
    // --------------------------------------------------

    async function obterResumoReceitas(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const receitas = filtrarPorPeriodo(
            dados.receitas,
            "data",
            filtro
        ).filter(r => r.estado !== "anulado");

        return {
            quantidade: receitas.length,

            previsto: somar(
                receitas,
                r => r.valor
            ),

            recebido: somar(
                dados.pagamentos.filter(p =>
                    p.estado !== "anulado" &&
                    dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ),
                p => p.valor
            )
        };
    }

    async function obterResumoDespesas(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const despesas = dados.despesas.filter(d =>
            dentroPeriodo(
                d.data,
                filtro.inicio,
                filtro.fim
            )
        );

        return {
            quantidade: despesas.length,

            total: somar(
                despesas,
                d => d.valor
            ),

            pago: somar(
                despesas,
                d => somar(
                    pagamentosDespesa(d).filter(p =>
                        dentroPeriodo(
                            p.data,
                            filtro.inicio,
                            filtro.fim
                        )
                    ),
                    p => p.valor
                )
            )
        };
    }

    async function obterResumoSalarios(mes, ano) {
        await carregarDados();

        const folhas = dados.salarios.filter(s =>
            Number(s.mes) === Number(mes) &&
            Number(s.ano) === Number(ano)
        );

        return {
            quantidade: folhas.length,

            total: somar(
                folhas,
                s => s.salarioLiquido
            ),

            pago: somar(
                folhas,
                s => totalPagoSalario(s)
            ),

            pendente: somar(
                folhas,
                s => saldoSalario(s)
            )
        };
    }

    async function obterBalanco(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const receitas = somar(
            dados.pagamentos.filter(p =>
                p.estado !== "anulado" &&
                dentroPeriodo(
                    p.data,
                    filtro.inicio,
                    filtro.fim
                )
            ),
            p => p.valor
        );

        let despesas = 0;

        dados.despesas.forEach(d => {
            despesas += somar(
                pagamentosDespesa(d).filter(p =>
                    dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ),
                p => p.valor
            );
        });

        let salarios = 0;

        dados.salarios.forEach(s => {
            salarios += somar(
                pagamentosSalariais(s).filter(p =>
                    p.estado !== "anulado" &&
                    dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ),
                p => p.valor
            );
        });

        return {
            receitas,
            despesas,
            salarios,
            totalSaidas: despesas + salarios,
            saldo: receitas - despesas - salarios
        };
    }

    async function despesasPorCategoria(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const resultado = {};

        dados.despesas.forEach(d => {
            const categoria =
                d.categoria ||
                d.tipo ||
                "Sem categoria";

            const pago = somar(
                pagamentosDespesa(d).filter(p =>
                    dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ),
                p => p.valor
            );

            if (pago > 0) {
                resultado[categoria] =
                    (resultado[categoria] || 0) + pago;
            }
        });

        return resultado;
    }

    async function obterMovimentos(inicio, fim) {
        await carregarDados();

        const filtro = {
            inicio: inicio || "",
            fim: fim || ""
        };

        const movimentos = [];

        dados.pagamentos.forEach(p => {
            if (
                p.estado === "anulado" ||
                !dentroPeriodo(
                    p.data,
                    filtro.inicio,
                    filtro.fim
                )
            ) {
                return;
            }

            movimentos.push({
                tipo: "Entrada",
                descricao: p.descricao || "Pagamento recebido",
                valor: numero(p.valor),
                data: p.data
            });
        });

        dados.despesas.forEach(d => {
            pagamentosDespesa(d).forEach(p => {
                if (!dentroPeriodo(
                    p.data,
                    filtro.inicio,
                    filtro.fim
                )) {
                    return;
                }

                movimentos.push({
                    tipo: "Despesa",
                    descricao: d.descricao || d.nome || "Despesa",
                    valor: numero(p.valor),
                    data: p.data
                });
            });
        });

        dados.salarios.forEach(s => {
            pagamentosSalariais(s).forEach(p => {
                if (
                    p.estado === "anulado" ||
                    !dentroPeriodo(
                        p.data,
                        filtro.inicio,
                        filtro.fim
                    )
                ) {
                    return;
                }

                movimentos.push({
                    tipo: "Salário",
                    descricao:
                        "Pagamento salarial - " +
                        (s.funcionarioNome || ""),
                    valor: numero(p.valor),
                    data: p.data
                });
            });
        });

        return movimentos.sort((a, b) =>
            dataISO(b.data).localeCompare(dataISO(a.data))
        );
    }

    // --------------------------------------------------
    // INICIALIZAÇÃO DO MÓDULO
    // --------------------------------------------------

    async function abrir() {
        if (!modulo) {
            console.error(
                "A área conteudoModulo não foi encontrada."
            );

            return;
        }

        try {
            await carregarDados();

            criarInterface();

        } catch (erro) {
            modulo.innerHTML =
                '<div class="modulo-placeholder">' +
                '<h2>Central de Relatórios</h2>' +
                '<p>Não foi possível carregar os dados.</p>' +
                '<small>' + escapar(erro.message) + '</small>' +
                '</div>';
        }
    }

    async function atualizar() {
        await abrir();
    }

    window.SGFE_RELATORIOS = Object.freeze({
        abrir,
        atualizar,
        obterResumoReceitas,
        obterResumoDespesas,
        obterResumoSalarios,
        obterBalanco,
        despesasPorCategoria,
        obterMovimentos
    });

})();

/* ===== MÓDULO: configuracoes.js ===== */

(function () {
    "use strict";

    const COLECAO = "configuracoes";
    const CONFIG_ID = "configuracao_principal";

    let configuracaoActual = null;

    function verificarBanco() {
        if (!window.SGFE_DB) {
            throw new Error("O armazenamento do SGFE não está disponível.");
        }
    }

    // ==========================================
    // CONFIGURAÇÕES PADRÃO
    // ==========================================

    function configuracoesPadrao() {
        return {
            id: CONFIG_ID,

            instituicao: {
                nome: "",
                nomeAbreviado: "",
                logotipo: "",
                endereco: "",
                telefone: "",
                email: "",
                municipio: "",
                provincia: ""
            },

            financeira: {
                moeda: "Kz",
                casasDecimais: 2
            },

            categoriasReceitas: [
                "Matrícula",
                "Mensalidade",
                "Cantina",
                "Papelaria",
                "Outras receitas"
            ],

            categoriasDespesas: [
                "Água",
                "Energia eléctrica",
                "Internet",
                "Material escolar",
                "Manutenção",
                "Transporte",
                "Outras despesas"
            ],

            cargos: [
                "Director",
                "Director administrativo",
                "Professor",
                "Secretário",
                "Contabilista",
                "Auxiliar",
                "Outro"
            ],

            criadoEm: new Date().toISOString()
        };
    }

    // ==========================================
    // CARREGAR E GUARDAR
    // ==========================================

    async function carregar() {
        verificarBanco();

        let config = await window.SGFE_DB.obter(
            COLECAO,
            CONFIG_ID
        );

        if (!config) {
            config = configuracoesPadrao();

            await window.SGFE_DB.guardar(
                COLECAO,
                config
            );
        }

        const padrao = configuracoesPadrao();

        config.instituicao = {
            ...padrao.instituicao,
            ...(config.instituicao || {})
        };

        config.financeira = {
            ...padrao.financeira,
            ...(config.financeira || {})
        };

        config.categoriasReceitas =
            config.categoriasReceitas || padrao.categoriasReceitas;

        config.categoriasDespesas =
            config.categoriasDespesas || padrao.categoriasDespesas;

        config.cargos =
            config.cargos || padrao.cargos;

        return config;
    }

    async function guardar(dados) {
        verificarBanco();

        if (!dados || typeof dados !== "object") {
            throw new Error("Configurações inválidas.");
        }

        const anteriores = await carregar();

        const actualizadas = {
            ...anteriores,
            ...dados,

            instituicao: {
                ...anteriores.instituicao,
                ...(dados.instituicao || {})
            },

            financeira: {
                ...anteriores.financeira,
                ...(dados.financeira || {})
            },

            id: CONFIG_ID,
            actualizadoEm: new Date().toISOString()
        };

        await window.SGFE_DB.guardar(
            COLECAO,
            actualizadas
        );

        if (typeof window.SGFE_DB.registarHistorico === "function") {
            await window.SGFE_DB.registarHistorico({
                operacao: "actualizacao",
                modulo: "configuracoes",
                descricao: "Configurações gerais actualizadas.",
                data: new Date().toISOString()
            });
        }

        configuracaoActual = actualizadas;

        return actualizadas;
    }

    // ==========================================
    // GESTÃO DE CATEGORIAS
    // ==========================================

    async function adicionarCategoria(tipo, nome) {
        const config = await carregar();

        const campos = {
            receita: "categoriasReceitas",
            despesa: "categoriasDespesas",
            cargo: "cargos"
        };

        const campo = campos[tipo];

        if (!campo) {
            throw new Error("Tipo de categoria inválido.");
        }

        const valor = String(nome || "").trim();

        if (!valor) {
            throw new Error("Informe o nome da categoria.");
        }

        const lista = config[campo] || [];

        if (lista.some(item =>
            item.toLowerCase() === valor.toLowerCase()
        )) {
            throw new Error("Esta categoria já existe.");
        }

        lista.push(valor);
        config[campo] = lista;

        return await guardar(config);
    }

    async function removerCategoria(tipo, nome) {
        const config = await carregar();

        const campos = {
            receita: "categoriasReceitas",
            despesa: "categoriasDespesas",
            cargo: "cargos"
        };

        const campo = campos[tipo];

        if (!campo) {
            throw new Error("Tipo de categoria inválido.");
        }

        config[campo] = (config[campo] || []).filter(item =>
            item !== nome
        );

        return await guardar(config);
    }

    // ==========================================
    // BACKUP E RESTAURO
    // ==========================================

    async function criarBackup() {
        verificarBanco();

        return await window.SGFE_DB.criarBackup();
    }

    async function restaurarBackup(ficheiro, substituir = true) {
        verificarBanco();

        if (!ficheiro) {
            throw new Error("Seleccione um ficheiro de backup.");
        }

        return await window.SGFE_DB.restaurarBackup(
            ficheiro,
            substituir
        );
    }

    async function verificarEspaco() {
        verificarBanco();

        return await window.SGFE_DB.verificarArmazenamento();
    }

    // ==========================================
    // FUNÇÕES AUXILIARES
    // ==========================================

    function escapar(valor) {
        return String(valor ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function formatarTamanho(bytes) {
        const valor = Number(bytes || 0);

        if (valor < 1024) {
            return valor + " bytes";
        }

        if (valor < 1024 * 1024) {
            return (valor / 1024).toFixed(2) + " KB";
        }

        if (valor < 1024 * 1024 * 1024) {
            return (valor / (1024 * 1024)).toFixed(2) + " MB";
        }

        return (valor / (1024 * 1024 * 1024)).toFixed(2) + " GB";
    }

    function mostrarMensagem(mensagem, tipo) {
        const area = document.getElementById("configMensagem");

        if (!area) return;

        area.textContent = mensagem;
        area.className = "sgfe-config-mensagem " + (tipo || "info");

        area.hidden = false;

        window.setTimeout(function () {
            if (area) {
                area.hidden = true;
            }
        }, 5000);
    }

    function obterContentor() {
        return document.getElementById("conteudoModulo");
    }

    // ==========================================
    // ESTILOS DA INTERFACE
    // ==========================================

    function instalarEstilos() {
        if (document.getElementById("estilosConfiguracoesSGFE")) {
            return;
        }

        const estilo = document.createElement("style");

        estilo.id = "estilosConfiguracoesSGFE";

        estilo.textContent = `
            .sgfe-config {
                display: flex;
                flex-direction: column;
                gap: 20px;
                width: 100%;
            }

            .sgfe-config-mensagem {
                padding: 13px 16px;
                border-radius: 8px;
                font-size: 14px;
                margin-bottom: 5px;
            }

            .sgfe-config-mensagem.sucesso {
                background: #e7f6ec;
                color: #176b36;
            }

            .sgfe-config-mensagem.erro {
                background: #fdeaea;
                color: #a32222;
            }

            .sgfe-config-mensagem.info {
                background: #eaf1fa;
                color: #17365d;
            }

            .sgfe-config-card {
                background: #ffffff;
                border: 1px solid #dfe4ea;
                border-radius: 10px;
                padding: 22px;
                box-shadow: 0 2px 7px rgba(0,0,0,.035);
            }

            .sgfe-config-card h3 {
                color: #17365d;
                font-size: 17px;
                margin: 0 0 7px;
            }

            .sgfe-config-card > p {
                color: #78818b;
                font-size: 13px;
                margin: 0 0 20px;
            }

            .sgfe-config-grid {
                display: grid;
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 16px;
            }

            .sgfe-config-campo {
                display: flex;
                flex-direction: column;
                gap: 7px;
            }

            .sgfe-config-campo.largo {
                grid-column: 1 / -1;
            }

            .sgfe-config-campo label {
                font-size: 13px;
                font-weight: 600;
                color: #445064;
            }

            .sgfe-config-campo input,
            .sgfe-config-campo select {
                width: 100%;
                min-width: 0;
                padding: 11px 12px;
                border: 1px solid #d5dce5;
                border-radius: 7px;
                background: #fff;
                color: #27364a;
                font-size: 14px;
                outline: none;
            }

            .sgfe-config-campo input:focus,
            .sgfe-config-campo select:focus {
                border-color: #376da8;
                box-shadow: 0 0 0 2px rgba(55,109,168,.10);
            }

            .sgfe-config-botao {
                border: none;
                border-radius: 7px;
                padding: 11px 16px;
                font-size: 13px;
                font-weight: 600;
                cursor: pointer;
                background: #17365d;
                color: #fff;
            }

            .sgfe-config-botao:hover {
                opacity: .9;
            }

            .sgfe-config-botao.secundario {
                background: #eaf0f7;
                color: #17365d;
            }

            .sgfe-config-botao.perigo {
                background: #fbe9e9;
                color: #a72d2d;
                padding: 7px 11px;
            }

            .sgfe-config-acoes {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                margin-top: 18px;
            }

            .sgfe-config-lista {
                display: flex;
                flex-direction: column;
                gap: 9px;
            }

            .sgfe-config-item {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 12px;
                padding: 11px 13px;
                border: 1px solid #e3e7ed;
                border-radius: 7px;
                color: #39475a;
                font-size: 14px;
            }

            .sgfe-config-adicionar {
                display: flex;
                gap: 9px;
                margin-bottom: 15px;
            }

            .sgfe-config-adicionar input {
                flex: 1;
                min-width: 0;
                padding: 11px;
                border: 1px solid #d5dce5;
                border-radius: 7px;
                font-size: 14px;
            }

            .sgfe-config-info {
                padding: 15px;
                background: #f4f7fb;
                border-radius: 8px;
                color: #43536a;
                font-size: 14px;
            }

            .sgfe-config-info strong {
                display: block;
                color: #17365d;
                font-size: 19px;
                margin-top: 5px;
            }

            .sgfe-config-separador {
                height: 1px;
                background: #e8ebef;
                margin: 18px 0;
            }

            @media(max-width: 650px) {
                .sgfe-config-grid {
                    grid-template-columns: 1fr;
                }

                .sgfe-config-campo.largo {
                    grid-column: auto;
                }

                .sgfe-config-card {
                    padding: 16px;
                }

                .sgfe-config-adicionar {
                    flex-direction: column;
                }

                .sgfe-config-adicionar button {
                    width: 100%;
                }
            }
        `;

        document.head.appendChild(estilo);
    }

    // ==========================================
    // CONSTRUIR LISTA DE CATEGORIAS
    // ==========================================

    function construirLista(tipo, lista) {
        if (!lista || !lista.length) {
            return `
                <div class="sgfe-config-info">
                    Ainda não existem elementos registados.
                </div>
            `;
        }

        return `
            <div class="sgfe-config-lista">
                ${lista.map(item => `
                    <div class="sgfe-config-item">
                        <span>${escapar(item)}</span>

                        <button
                            type="button"
                            class="sgfe-config-botao perigo"
                            data-acao="remover-categoria"
                            data-tipo="${tipo}"
                            data-nome="${escapar(item)}">
                            Remover
                        </button>
                    </div>
                `).join("")}
            </div>
        `;
    }

    // ==========================================
    // INTERFACE PRINCIPAL
    // ==========================================

    async function abrir() {
        const contentor = obterContentor();

        if (!contentor) {
            console.error("Contentor de configurações não encontrado.");
            return;
        }

        instalarEstilos();

        contentor.innerHTML = `
            <div class="sgfe-config">
                <div id="configMensagem"
                    class="sgfe-config-mensagem"
                    hidden>
                </div>

                <section class="sgfe-config-card">
                    <h3>Dados da instituição</h3>
                    <p>Identificação e contactos da instituição escolar.</p>

                    <form id="formInstituicao">
                        <div class="sgfe-config-grid">

                            <div class="sgfe-config-campo largo">
                                <label>Nome da instituição</label>
                                <input name="nome" type="text"
                                    placeholder="Nome completo da instituição">
                            </div>

                            <div class="sgfe-config-campo">
                                <label>Nome abreviado</label>
                                <input name="nomeAbreviado" type="text"
                                    placeholder="Sigla ou nome curto">
                            </div>

                            <div class="sgfe-config-campo">
                                <label>Logótipo (endereço da imagem)</label>
                                <input name="logotipo" type="text"
                                    placeholder="Caminho ou endereço da imagem">
                            </div>

                            <div class="sgfe-config-campo largo">
                                <label>Endereço</label>
                                <input name="endereco" type="text"
                                    placeholder="Endereço da instituição">
                            </div>

                            <div class="sgfe-config-campo">
                                <label>Telefone</label>
                                <input name="telefone" type="tel"
                                    placeholder="Contacto telefónico">
                            </div>

                            <div class="sgfe-config-campo">
                                <label>E-mail</label>
                                <input name="email" type="email"
                                    placeholder="E-mail institucional">
                            </div>

                            <div class="sgfe-config-campo">
                                <label>Município</label>
                                <input name="municipio" type="text">
                            </div>

                            <div class="sgfe-config-campo">
                                <label>Província</label>
                                <input name="provincia" type="text">
                            </div>

                        </div>

                        <div class="sgfe-config-acoes">
                            <button class="sgfe-config-botao" type="submit">
                                Guardar dados da instituição
                            </button>
                        </div>
                    </form>
                </section>

                <section class="sgfe-config-card">
                    <h3>Configurações financeiras</h3>
                    <p>Definições utilizadas na apresentação dos valores.</p>

                    <form id="formFinanceira">
                        <div class="sgfe-config-grid">

                            <div class="sgfe-config-campo">
                                <label>Moeda</label>
                                <select name="moeda">
                                    <option value="Kz">Kwanza (Kz)</option>
                                    <option value="USD">Dólar (USD)</option>
                                    <option value="EUR">Euro (EUR)</option>
                                </select>
                            </div>

                            <div class="sgfe-config-campo">
                                <label>Casas decimais</label>
                                <select name="casasDecimais">
                                    <option value="0">0 casas decimais</option>
                                    <option value="1">1 casa decimal</option>
                                    <option value="2">2 casas decimais</option>
                                </select>
                            </div>

                        </div>

                        <div class="sgfe-config-acoes">
                            <button class="sgfe-config-botao" type="submit">
                                Guardar configurações financeiras
                            </button>
                        </div>
                    </form>
                </section>

                <section class="sgfe-config-card">
                    <h3>Categorias de receitas</h3>
                    <p>Tipos de receitas disponíveis no sistema.</p>

                    <div class="sgfe-config-adicionar">
                        <input id="novaCategoriaReceita"
                            type="text"
                            placeholder="Nova categoria de receita">

                        <button type="button"
                            class="sgfe-config-botao"
                            data-acao="adicionar-categoria"
                            data-tipo="receita">
                            + Adicionar
                        </button>
                    </div>

                    <div id="listaCategoriasReceitas"></div>
                </section>

                <section class="sgfe-config-card">
                    <h3>Categorias de despesas</h3>
                    <p>Tipos de despesas disponíveis no sistema.</p>

                    <div class="sgfe-config-adicionar">
                        <input id="novaCategoriaDespesa"
                            type="text"
                            placeholder="Nova categoria de despesa">

                        <button type="button"
                            class="sgfe-config-botao"
                            data-acao="adicionar-categoria"
                            data-tipo="despesa">
                            + Adicionar
                        </button>
                    </div>

                    <div id="listaCategoriasDespesas"></div>
                </section>

                <section class="sgfe-config-card">
                    <h3>Cargos e funções</h3>
                    <p>Lista de cargos utilizados nos registos do sistema.</p>

                    <div class="sgfe-config-adicionar">
                        <input id="novoCargo"
                            type="text"
                            placeholder="Novo cargo ou função">

                        <button type="button"
                            class="sgfe-config-botao"
                            data-acao="adicionar-categoria"
                            data-tipo="cargo">
                            + Adicionar
                        </button>
                    </div>

                    <div id="listaCargos"></div>
                </section>

                <section class="sgfe-config-card">
                    <h3>Cópia de segurança</h3>
                    <p>Protecção dos dados registados no sistema.</p>

                    <div class="sgfe-config-info">
                        Crie uma cópia de segurança dos dados da instituição
                        para evitar a perda de informações.
                    </div>

                    <div class="sgfe-config-acoes">
                        <button type="button"
                            class="sgfe-config-botao"
                            data-acao="criar-backup">
                            Criar cópia de segurança
                        </button>
                    </div>

                    <div class="sgfe-config-separador"></div>

                    <div class="sgfe-config-campo">
                        <label>Seleccionar ficheiro de backup</label>
                        <input type="file"
                            id="ficheiroBackup"
                            accept=".json,application/json">
                    </div>

                    <div class="sgfe-config-acoes">
                        <button type="button"
                            class="sgfe-config-botao secundario"
                            data-acao="restaurar-backup">
                            Restaurar cópia de segurança
                        </button>
                    </div>
                </section>

                <section class="sgfe-config-card">
                    <h3>Armazenamento local</h3>
                    <p>Informações sobre o espaço utilizado pela aplicação.</p>

                    <div id="informacaoArmazenamento"
                        class="sgfe-config-info">
                        Clique no botão para consultar o armazenamento.
                    </div>

                    <div class="sgfe-config-acoes">
                        <button type="button"
                            class="sgfe-config-botao secundario"
                            data-acao="verificar-espaco">
                            Verificar armazenamento
                        </button>
                    </div>
                </section>
            </div>
        `;

        await actualizarInterface();
        configurarEventos();
    }

    // ==========================================
    // ACTUALIZAR INTERFACE
    // ==========================================

    async function actualizarInterface() {
        configuracaoActual = await carregar();

        const formInstituicao =
            document.getElementById("formInstituicao");

        const formFinanceira =
            document.getElementById("formFinanceira");

        if (!formInstituicao || !formFinanceira) return;

        const instituicao = configuracaoActual.instituicao;
        const financeira = configuracaoActual.financeira;

        Object.keys(instituicao).forEach(campo => {
            const input = formInstituicao.elements[campo];

            if (input) {
                input.value = instituicao[campo] || "";
            }
        });

        formFinanceira.elements.moeda.value =
            financeira.moeda || "Kz";

        formFinanceira.elements.casasDecimais.value =
            String(financeira.casasDecimais ?? 2);

        document.getElementById("listaCategoriasReceitas").innerHTML =
            construirLista(
                "receita",
                configuracaoActual.categoriasReceitas
            );

        document.getElementById("listaCategoriasDespesas").innerHTML =
            construirLista(
                "despesa",
                configuracaoActual.categoriasDespesas
            );

        document.getElementById("listaCargos").innerHTML =
            construirLista(
                "cargo",
                configuracaoActual.cargos
            );
    }

    // ==========================================
    // EVENTOS
    // ==========================================

    function configurarEventos() {
        const contentor = obterContentor();

        const formInstituicao =
            document.getElementById("formInstituicao");

        const formFinanceira =
            document.getElementById("formFinanceira");

        formInstituicao.addEventListener("submit", async function (evento) {
            evento.preventDefault();

            try {
                const dados = {};

                [
                    "nome",
                    "nomeAbreviado",
                    "logotipo",
                    "endereco",
                    "telefone",
                    "email",
                    "municipio",
                    "provincia"
                ].forEach(campo => {
                    dados[campo] = this.elements[campo].value.trim();
                });

                await guardar({
                    instituicao: dados
                });

                mostrarMensagem(
                    "Dados da instituição guardados com sucesso.",
                    "sucesso"
                );

            } catch (erro) {
                console.error(erro);
                mostrarMensagem(erro.message, "erro");
            }
        });

        formFinanceira.addEventListener("submit", async function (evento) {
            evento.preventDefault();

            try {
                await guardar({
                    financeira: {
                        moeda: this.elements.moeda.value,
                        casasDecimais: Number(
                            this.elements.casasDecimais.value
                        )
                    }
                });

                mostrarMensagem(
                    "Configurações financeiras guardadas com sucesso.",
                    "sucesso"
                );

            } catch (erro) {
                console.error(erro);
                mostrarMensagem(erro.message, "erro");
            }
        });

        contentor.addEventListener("click", async function (evento) {
            const botao = evento.target.closest("[data-acao]");

            if (!botao) return;

            const acao = botao.dataset.acao;

            try {
                if (acao === "adicionar-categoria") {
                    const tipo = botao.dataset.tipo;

                    const campos = {
                        receita: "novaCategoriaReceita",
                        despesa: "novaCategoriaDespesa",
                        cargo: "novoCargo"
                    };

                    const campo = document.getElementById(campos[tipo]);

                    await adicionarCategoria(tipo, campo.value);

                    campo.value = "";

                    await actualizarInterface();

                    mostrarMensagem(
                        "Elemento adicionado com sucesso.",
                        "sucesso"
                    );
                }

                if (acao === "remover-categoria") {
                    const confirmar = window.confirm(
                        "Deseja realmente remover este elemento?"
                    );

                    if (!confirmar) return;

                    await removerCategoria(
                        botao.dataset.tipo,
                        botao.dataset.nome
                    );

                    await actualizarInterface();

                    mostrarMensagem(
                        "Elemento removido com sucesso.",
                        "sucesso"
                    );
                }

                if (acao === "criar-backup") {
                    const resultado = await criarBackup();

                    if (resultado === undefined || resultado === null) {
                        throw new Error(
                            "O sistema não devolveu os dados da cópia de segurança."
                        );
                    }

                    let blob;

                    if (resultado instanceof Blob) {
                        blob = resultado;
                    } else if (typeof resultado === "string") {
                        blob = new Blob(
                            [resultado],
                            { type: "application/json" }
                        );
                    } else if (resultado instanceof ArrayBuffer) {
                        blob = new Blob(
                            [resultado],
                            { type: "application/json" }
                        );
                    } else {
                        blob = new Blob(
                            [JSON.stringify(resultado, null, 2)],
                            { type: "application/json" }
                        );
                    }

                    const url = URL.createObjectURL(blob);

                    const link = document.createElement("a");

                    link.href = url;
                    link.download =
                        "SGFE_Backup_" +
                        new Date().toISOString().slice(0, 10) +
                        ".json";

                    document.body.appendChild(link);
                    link.click();
                    link.remove();

                    URL.revokeObjectURL(url);

                    mostrarMensagem(
                        "Cópia de segurança criada com sucesso.",
                        "sucesso"
                    );
                }

                if (acao === "restaurar-backup") {
                    const campo =
                        document.getElementById("ficheiroBackup");

                    const ficheiro = campo.files[0];

                    if (!ficheiro) {
                        throw new Error(
                            "Seleccione primeiro um ficheiro de backup."
                        );
                    }

                    const confirmar = window.confirm(
                        "Deseja restaurar esta cópia de segurança? " +
                        "Esta operação poderá substituir os dados actuais."
                    );

                    if (!confirmar) return;

                    await restaurarBackup(ficheiro, true);

                    campo.value = "";

                    configuracaoActual = await carregar();

                    await actualizarInterface();

                    mostrarMensagem(
                        "Cópia de segurança restaurada com sucesso.",
                        "sucesso"
                    );
                }

                if (acao === "verificar-espaco") {
                    const dados = await verificarEspaco();

                    const area =
                        document.getElementById("informacaoArmazenamento");

                    if (dados && typeof dados === "object") {
                        const utilizados =
                            dados.usage ??
                            dados.utilizado ??
                            dados.usado ??
                            dados.bytesInUse;

                        const limite =
                            dados.quota ??
                            dados.total ??
                            dados.limite ??
                            dados.bytesAvailable;

                        if (utilizados !== undefined) {
                            area.innerHTML = `
                                Espaço utilizado:
                                <strong>${formatarTamanho(utilizados)}</strong>

                                ${limite !== undefined
                                    ? "Limite disponível: " +
                                      escapar(formatarTamanho(limite))
                                    : ""}
                            `;
                        } else {
                            area.textContent =
                                JSON.stringify(dados, null, 2);
                        }
                    } else {
                        area.textContent = String(dados);
                    }

                    mostrarMensagem(
                        "Consulta do armazenamento concluída.",
                        "sucesso"
                    );
                }

            } catch (erro) {
                console.error("Erro nas configurações:", erro);

                mostrarMensagem(
                    erro.message || "Não foi possível executar a operação.",
                    "erro"
                );
            }
        });
    }

    // ==========================================
    // DISPONIBILIZAR MÓDULO
    // ==========================================

    window.SGFE_CONFIGURACOES = Object.freeze({
        abrir,
        carregar,
        guardar,
        adicionarCategoria,
        removerCategoria,
        criarBackup,
        restaurarBackup,
        verificarEspaco
    });

})();


/* ===== MÓDULO: app.js ===== */

(function () {
    "use strict";

    const PAGINAS = {
        painel: {
            titulo: "Painel principal",
            descricao: "Visão geral da situação financeira"
        },
        entradas: {
            titulo: "Gestão de entradas",
            descricao: "Controlo de mensalidades, matrículas e outras receitas"
        },
        salarios: {
            titulo: "Gestão de salários",
            descricao: "Funcionários, folhas salariais e pagamentos"
        },
        despesas: {
            titulo: "Outras saídas",
            descricao: "Controlo das despesas da instituição"
        },
        relatorios: {
            titulo: "Relatórios",
            descricao: "Consultas, balanços e análises financeiras"
        },
        configuracoes: {
            titulo: "Configurações",
            descricao: "Personalização e administração do sistema"
        }
    };

    let paginaAtual = "painel";

    const elementos = {
        menu: document.querySelector(".menu-lateral"),
        botaoMenu: document.getElementById("btnMenu"),
        botoesNavegacao: document.querySelectorAll("[data-pagina]"),
        paginaPainel: document.getElementById("paginaPainel"),
        paginaModulo: document.getElementById("paginaModulo"),
        moduloTitulo: document.getElementById("moduloTitulo"),
        moduloDescricao: document.getElementById("moduloDescricao"),
        dataAtual: document.getElementById("dataAtual"),
        anoAtual: document.getElementById("anoAtual"),
        conteudoModulo: document.getElementById("conteudoModulo")
    };

    // Actualizar data e ano
    function actualizarData() {
        const agora = new Date();

        if (elementos.dataAtual) {
            elementos.dataAtual.textContent =
                agora.toLocaleDateString("pt-AO", {
                    weekday: "short",
                    day: "2-digit",
                    month: "short",
                    year: "numeric"
                });
        }

        if (elementos.anoAtual) {
            elementos.anoAtual.textContent = agora.getFullYear();
        }
    }

    // Abrir uma página do sistema
    async function abrirPagina(nome) {
        const pagina = PAGINAS[nome];

        if (!pagina) return;

        paginaAtual = nome;

        // Actualizar os botões do menu
        elementos.botoesNavegacao.forEach(botao => {
            const activo = botao.dataset.pagina === nome;

            botao.classList.toggle("ativo", activo);

            if (activo) {
                botao.setAttribute("aria-current", "page");
            } else {
                botao.removeAttribute("aria-current");
            }
        });

        // Abrir painel principal
        if (nome === "painel") {
            if (elementos.paginaPainel) {
                elementos.paginaPainel.hidden = false;
            }

            if (elementos.paginaModulo) {
                elementos.paginaModulo.hidden = true;
            }

            if (window.SGFE_PAINEL) {
                try {
                    await window.SGFE_PAINEL.atualizar();
                } catch (erro) {
                    console.error("Erro ao actualizar painel:", erro);
                }
            }

        } else {
            // Abrir área dos módulos
            if (elementos.paginaPainel) {
                elementos.paginaPainel.hidden = true;
            }

            if (elementos.paginaModulo) {
                elementos.paginaModulo.hidden = false;
            }

            if (elementos.moduloTitulo) {
                elementos.moduloTitulo.textContent = pagina.titulo;
            }

            if (elementos.moduloDescricao) {
                elementos.moduloDescricao.textContent = pagina.descricao;
            }

            // Limpar conteúdo anterior
            if (elementos.conteudoModulo) {
                elementos.conteudoModulo.innerHTML = "";
            }

            // Activar o módulo correspondente
            await activarModulo(nome);
        }

        fecharMenu();
    }

    // Activar os módulos disponíveis
    async function activarModulo(nome) {
        const modulos = {
            entradas: window.SGFE_ENTRADAS,
            salarios: window.SGFE_SALARIOS,
            despesas: window.SGFE_DESPESAS,
            relatorios: window.SGFE_RELATORIOS,
            configuracoes: window.SGFE_CONFIGURACOES
        };

        const modulo = modulos[nome];

        if (modulo && typeof modulo.abrir === "function") {
            try {
                await modulo.abrir();
                return;
            } catch (erro) {
                console.error("Erro ao abrir módulo:", nome, erro);
            }
        }

        // Mensagem provisória para módulos ainda não desenvolvidos
        if (elementos.conteudoModulo) {
            elementos.conteudoModulo.innerHTML = `
                <div class="modulo-placeholder">
                    <div class="placeholder-icone">▤</div>
                    <h3>${PAGINAS[nome].titulo}</h3>
                    <p>Este módulo será desenvolvido nas próximas etapas.</p>
                </div>
            `;
        }
    }

    // Abrir menu lateral
    function abrirMenu() {
        if (elementos.menu) {
            elementos.menu.classList.add("aberto");
        }
    }

    // Fechar menu lateral
    function fecharMenu() {
        if (elementos.menu) {
            elementos.menu.classList.remove("aberto");
        }
    }

    // Alternar menu lateral
    function alternarMenu() {
        if (!elementos.menu) return;

        elementos.menu.classList.toggle("aberto");
    }

    // Eventos dos botões de navegação
    elementos.botoesNavegacao.forEach(botao => {
        botao.addEventListener("click", function () {
            abrirPagina(this.dataset.pagina);
        });
    });

    // Evento do botão do menu
    if (elementos.botaoMenu) {
        elementos.botaoMenu.addEventListener("click", function (evento) {
            evento.stopPropagation();
            alternarMenu();
        });
    }

    // Fechar menu ao clicar fora dele
    document.addEventListener("click", function (evento) {
        if (!elementos.menu || !elementos.botaoMenu) return;

        const clicouNoMenu = elementos.menu.contains(evento.target);
        const clicouNoBotao = elementos.botaoMenu.contains(evento.target);

        if (!clicouNoMenu && !clicouNoBotao) {
            fecharMenu();
        }
    });

    // Inicialização do sistema
    function iniciar() {
        actualizarData();
        abrirPagina("painel");
    }

    // Disponibilizar funções para outros módulos
    window.SGFE_APP = Object.freeze({
        abrirPagina,
        abrirMenu,
        fecharMenu,
        alternarMenu,
        actualizarData,

        get paginaAtual() {
            return paginaAtual;
        }
    });

    // Inicialização da aplicação no ambiente Android/WebView.
    iniciar();

})();
