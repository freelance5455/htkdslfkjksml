const $ = s => document.querySelector(s);
const messagesEl = $("#messages"), welcome = $("#welcome"), promptEl = $("#prompt");
(function migrateOldKeys(){
  try{["chats","profile","voice_enabled","voice_rate","reduce_motion"].forEach(k=>{
    const old=localStorage.getItem("aira_"+k);
    if(old!==null&&localStorage.getItem("alcy_"+k)===null)localStorage.setItem("alcy_"+k,old.replace(/AIRA/g,"Alcy"));
  });}catch(_){}
})();
let chats = [];
try { chats = JSON.parse(localStorage.getItem("alcy_chats") || "[]"); } catch (_) { chats = []; }
let currentId = null, holdTimer = null, suppressClick = false;
let alcyUser = { name: "" };
try {
  const savedProfile = JSON.parse(localStorage.getItem("alcy_profile") || "null");
  if (savedProfile && typeof savedProfile.name === "string") alcyUser.name = savedProfile.name;
} catch (_) {}

function cleanUsername(value) {
  return (value || "").trim().replace(/\s+/g, " ").slice(0, 24);
}
function enterAsGuest(name) {
  const username = cleanUsername(name);
  if (!username) {
    alert("Escribí un nombre de usuario para continuar.");
    return;
  }
  alcyUser.name = username;
  // Only the display name is saved locally. No email or password is stored.
  localStorage.setItem("alcy_profile", JSON.stringify({ name: username, mode: "guest" }));
  $("#entryScreen").classList.remove("visible");
  $("#mainApp").hidden = false;
  const heading = $("#welcomeHeading");
  if (heading) heading.innerHTML = `Hola, <em>${escapeHTML(username)}</em>.`;
  updateProfileUI();
}
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[char]));
}
function showEntryPanel(panel) {
  $("#accountForm").hidden = panel !== "account";
  $("#guestForm").hidden = panel !== "guest";
}


function save() {
  try { localStorage.setItem("alcy_chats", JSON.stringify(chats)); }
  catch (error) { console.warn("No se pudo guardar el historial", error); }
  renderHistory();
}
function current() { return chats.find(c => c.id === currentId); }

function newChat() {
  const chat = { id: Date.now().toString() + Math.random().toString(16).slice(2,6), title: "Nuevo chat", messages: [], pinned: false, archived: false };
  chats.unshift(chat); currentId = chat.id; save(); renderChat(); closeMenu(); promptEl.focus();
}
function selectChat(id) {
  const chat = chats.find(c => c.id === id);
  if (!chat) return;
  currentId = id; renderChat(); renderHistory(); closeMenu();
}
function renderHistory() {
  const el = $("#history");
  if (!el) return;
  el.innerHTML = "";
  const active = chats.filter(c => !c.archived).sort((a,b) => Number(!!b.pinned)-Number(!!a.pinned));
  const archived = chats.filter(c => c.archived);
  function section(label, list) {
    if (!list.length) return;
    const heading=document.createElement("div"); heading.className="side-label"; heading.textContent=label; el.appendChild(heading);
    list.forEach(chat => {
      const row=document.createElement("div"); row.className="history-item";
      const b=document.createElement("button"); b.type="button"; b.className="history-chat"+(chat.id===currentId?" active":"");
      if(chat.pinned&&!chat.archived){const pin=document.createElement("span");pin.className="pin-mark";pin.textContent="◆";b.appendChild(pin);}
      const title=document.createElement("span");title.className="history-title";title.textContent=chat.title||"Nuevo chat";b.appendChild(title);
      b.addEventListener("click",()=>{if(suppressClick){suppressClick=false;return;}selectChat(chat.id);});
      b.addEventListener("pointerdown",e=>{
        if(e.pointerType==="mouse"&&e.button!==0)return;
        suppressClick=false; clearTimeout(holdTimer);
        holdTimer=setTimeout(()=>{suppressClick=true;showChatMenu(chat,b);},600);
      });
      ["pointerup","pointerleave","pointercancel"].forEach(type=>b.addEventListener(type,()=>clearTimeout(holdTimer)));
      b.addEventListener("contextmenu",e=>{e.preventDefault();suppressClick=true;clearTimeout(holdTimer);showChatMenu(chat,b);});
      row.appendChild(b);el.appendChild(row);
    });
  }
  section("CHATS",active); section("ARCHIVADOS",archived);
}
function renderChat() {
  messagesEl.innerHTML="";
  const chat=current();
  welcome.style.display=(!chat||!chat.messages.length)?"block":"none";
  if(!chat)return;
  chat.messages.forEach(m=>addBubble(m.role,m.text,false));
  $("#conversation").scrollTop=$("#conversation").scrollHeight;
}
function addBubble(role,text,scroll=true) {
  const row=document.createElement("div");row.className="message "+role;
  const icon=document.createElement("div");icon.className="msg-icon";icon.textContent=role==="assistant"?"✦":"TÚ";
  const bubble=document.createElement("div");bubble.className="bubble";bubble.textContent=text;
  row.append(icon,bubble);
  if(role==="assistant" && localStorage.getItem("alcy_voice_enabled")!=="false"){
    const voiceButton=document.createElement("button");
    voiceButton.type="button";
    voiceButton.className="voice-button";
    voiceButton.setAttribute("aria-label","Escuchar respuesta de Alcy");
    voiceButton.title="Escuchar con la voz de Alcy";
    voiceButton.textContent="🔊";
    voiceButton.addEventListener("click",()=>speakAlcy(text,voiceButton));
    row.appendChild(voiceButton);
  }
  messagesEl.appendChild(row);
  if(scroll)$("#conversation").scrollTop=$("#conversation").scrollHeight;
}

/* ---------- VOCES DE Alcy (femenina primero, masculina segunda) ---------- */
const synthOK = "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;
const FEMALE_HINT = /female|femen|mujer|woman|sofia|sabina|helena|lucia|monica|paulina|zira|elena|marisol|carmen|laura|maria|paloma|valentina|camila|isabela|dalia|elvira|catalina|esperanza|luciana|ximena|mariana|abril|sara|lola|google espa/i;
const MALE_HINT = /jorge|diego|juan|carlos|pablo|raul|enrique|miguel|alvaro|antonio|\bmale\b|masculin|hombre|tomas|martin|andres|alberto|sergio|jaime|pedro|ricardo|gonzalo|alonso|arnau|jose|ramon|marcos|nicolas|santiago|mateo|emilio/i;

function spanishVoices() {
  try { return synthOK ? window.speechSynthesis.getVoices().filter(v => /^es([-_]|$)/i.test(v.lang)) : []; }
  catch (_) { return []; }
}
// "female" (por defecto), "male" o el nombre de una voz concreta
function voiceKind() {
  const s = localStorage.getItem("alcy_voice_name");
  return (s === null || s === "auto") ? "female" : s;
}
function pickAlcyVoice() {
  const list = spanishVoices();
  const sel = voiceKind();
  const isFem = v => FEMALE_HINT.test(v.name);
  const prefer = l => l.find(v => /es[-_](AR|MX|US|419)/i.test(v.lang)) || l[0];
  if (sel !== "female" && sel !== "male") {
    const chosen = list.find(v => v.name === sel);
    if (chosen) return { voice: chosen, pitch: 1 };
  }
  if (sel === "male") {
    const male = list.find(v => !isFem(v) && MALE_HINT.test(v.name));
    if (male) return { voice: male, pitch: 0.9 };
    // El dispositivo no indica el género: usa una voz española y baja el tono.
    return { voice: prefer(list.filter(v => !isFem(v))) || prefer(list) || null, pitch: 0.65 };
  }
  const fem = list.filter(isFem);
  if (fem.length) return { voice: prefer(fem), pitch: 1.05 };
  return { voice: prefer(list.filter(v => !MALE_HINT.test(v.name))) || prefer(list) || null, pitch: 1.25 };
}
function fillVoiceChoice() {
  const sel = $("#voiceChoice");
  if (!sel) return;
  const saved = voiceKind();
  sel.innerHTML = "";
  const add = (value, label) => { const o = document.createElement("option"); o.value = value; o.textContent = label; sel.appendChild(o); };
  add("female", "Voz femenina");
  add("male", "Voz masculina");
  spanishVoices().forEach(v => add(v.name, v.name + " · " + v.lang));
  sel.value = [...sel.options].some(o => o.value === saved) ? saved : "female";
}
fillVoiceChoice();
if (synthOK) {
  try { window.speechSynthesis.onvoiceschanged = fillVoiceChoice; } catch (_) {}
  // Algunos navegadores cargan las voces tarde: reintenta unos segundos.
  let tries = 0;
  const iv = setInterval(() => {
    tries++;
    let n = 0; try { n = window.speechSynthesis.getVoices().length; } catch (_) {}
    if (n || tries > 20) { clearInterval(iv); fillVoiceChoice(); }
  }, 300);
}
function stopSpeaking() {
  if (synthOK) window.speechSynthesis.cancel();
  document.querySelectorAll(".voice-button").forEach(b => { b.classList.remove("speaking"); b.dataset.active = "no"; });
}
function voiceModeOn() { return localStorage.getItem("alcy_voice_mode") === "true"; }

function speakAlcy(text, button) {
  if (!synthOK) {
    alert("Tu navegador no permite reproducir voz. Probá con Chrome actualizado.");
    return;
  }
  if (button && button.dataset.active === "yes") { stopSpeaking(); return; }
  stopSpeaking();
  const clean = (text || "")
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/https?:\/\/\S+/g, "")
    .replace(/[\u{1F300}-\u{1FAFF}\u2600-\u27BF✦]/gu, "")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return;
  const utterance = new SpeechSynthesisUtterance(clean);
  const picked = pickAlcyVoice();
  utterance.lang = "es-AR";
  if (picked.voice) { utterance.voice = picked.voice; utterance.lang = picked.voice.lang; }
  utterance.rate = Number(localStorage.getItem("alcy_voice_rate") || "0.96");
  utterance.pitch = picked.pitch;
  if (button) { button.dataset.active = "yes"; button.classList.add("speaking"); }
  const done = () => { if (button) { button.dataset.active = "no"; button.classList.remove("speaking"); } };
  utterance.onend = done;
  utterance.onerror = done;
  setTimeout(() => window.speechSynthesis.speak(utterance), 80);
}

/* ---------- Hablarle a Alcy (micrófono) ---------- */
const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognizer = null, listening = false;
function toggleMic() {
  if (!SpeechRec) {
    alert("Tu navegador no permite dictar por voz. Probá con Chrome.");
    return;
  }
  if (listening && recognizer) { recognizer.stop(); return; }
  stopSpeaking();
  recognizer = new SpeechRec();
  recognizer.lang = "es-AR";
  recognizer.interimResults = true;
  recognizer.continuous = false;
  let heard = "";
  recognizer.onstart = () => {
    listening = true;
    $("#micBtn").classList.add("listening");
    promptEl.placeholder = "Te escucho…";
  };
  recognizer.onresult = e => {
    heard = Array.from(e.results).map(r => r[0].transcript).join(" ");
    promptEl.value = heard;
  };
  recognizer.onerror = e => {
    if (e.error === "not-allowed" || e.error === "service-not-allowed") {
      alert("Necesito permiso para usar el micrófono. Activalo en los permisos del navegador.");
    }
  };
  recognizer.onend = () => {
    listening = false;
    $("#micBtn").classList.remove("listening");
    promptEl.placeholder = "Escribe tu mensaje a Alcy...";
    if (heard.trim()) send(heard, { spoken: true }); // si le hablás, te responde hablando
  };
  recognizer.start();
}


/* ---------- CEREBRO BÁSICO DE Alcy ---------- */
let lastTopic = null;

function normalize(s) {
  return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[¿?¡!"“”()]/g, " ")
    .replace(/(?<!\d)[.,;:]|[.,;:](?!\d)/g, " ")
    .replace(/\s+/g, " ").trim();
}
function pick(list) { return list[Math.floor(Math.random() * list.length)]; }
function capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
const toNum = s => Number(String(s).replace(",", "."));

function calculate(q) {
  const pct = q.match(/(\d+(?:[.,]\d+)?)\s*(?:%|por ciento) de (\d+(?:[.,]\d+)?)/);
  if (pct) {
    const r = toNum(pct[1]) * toNum(pct[2]) / 100;
    return "El " + pct[1] + "% de " + pct[2] + " es **" + Number(r.toFixed(8)) + "**.";
  }
  const sq = q.match(/raiz cuadrada de (\d+(?:[.,]\d+)?)/);
  if (sq) {
    const n = toNum(sq[1]);
    return "La raíz cuadrada de " + n + " es **" + Number(Math.sqrt(n).toFixed(8)) + "**.";
  }
  const t = q.replace(/\bmas\b/g, "+").replace(/\bmenos\b/g, "-").replace(/\bpor\b/g, "*")
    .replace(/\b(?:dividido por|dividido entre|dividido|entre)\b/g, "/");
  const m = t.match(/(-?\d+(?:[.,]\d+)?)\s*([+\-*x×/÷^])\s*(-?\d+(?:[.,]\d+)?)/);
  if (!m) return null;
  const a = toNum(m[1]), b = toNum(m[3]);
  let r;
  switch (m[2]) {
    case "+": r = a + b; break;
    case "-": r = a - b; break;
    case "*": case "x": case "×": r = a * b; break;
    case "^": r = Math.pow(a, b); break;
    case "/": case "÷":
      if (b === 0) return "No se puede dividir por cero.";
      r = a / b; break;
  }
  return "El resultado es **" + Number(r.toFixed(8)) + "**.";
}

const JOKES = [
  "¿Qué le dice un jardinero a otro? Disfrutemos mientras podamos.",
  "¿Por qué los programadores confunden Halloween con Navidad? Porque 31 de octubre es igual a 25 de diciembre.",
  "¿Qué hace una abeja en el gimnasio? ¡Zum-ba!",
  "¿Cómo se despiden los químicos? Ácido un placer.",
  "Mi computadora me dijo que necesitaba un descanso... y se reinició.",
  "¿Qué le dice un 0 a un 8? Lindo cinturón."
];
const FACTS = [
  "Los pulpos tienen tres corazones y su sangre es azul.",
  "En Venus, un día dura más que un año: tarda más en girar sobre sí mismo que en dar la vuelta al Sol.",
  "Botánicamente, la banana es una baya, pero la frutilla no lo es.",
  "Los koalas tienen huellas dactilares muy parecidas a las humanas.",
  "La Torre Eiffel puede crecer unos centímetros en verano porque el metal se dilata con el calor."
];
const CAPITALS = {
  "argentina": "Buenos Aires", "francia": "París", "espana": "Madrid", "italia": "Roma",
  "alemania": "Berlín", "brasil": "Brasilia", "chile": "Santiago", "uruguay": "Montevideo",
  "paraguay": "Asunción", "bolivia": "Sucre (sede constitucional) y La Paz (sede del gobierno)",
  "peru": "Lima", "colombia": "Bogotá", "mexico": "Ciudad de México", "venezuela": "Caracas",
  "ecuador": "Quito", "estados unidos": "Washington D. C.", "canada": "Ottawa", "japon": "Tokio",
  "china": "Pekín (Beijing)", "reino unido": "Londres", "portugal": "Lisboa", "rusia": "Moscú",
  "india": "Nueva Delhi", "australia": "Canberra", "egipto": "El Cairo", "cuba": "La Habana"
};

function answer(input) {
  const q = normalize(input);
  const calc = calculate(q);
  if (calc) { lastTopic = "calc"; return calc; }

  const who = alcyUser.name ? " " + alcyUser.name : "";
  const rules = [
    // Seguimientos: "otro", "otra"
    [/^(otro|otra|otro mas|otra mas|dame otro|dame otra|dale otro|dale otra)( chiste| dato| curiosidad)?$/, () => {
      if (lastTopic === "joke") return tell("joke");
      if (lastTopic === "fact") return tell("fact");
      return "¿Otro qué? Pedime un chiste o un dato curioso y después podés decirme “otro”.";
    }],
    [/(como me llamo|cual es mi nombre|sabes mi nombre)/, () =>
      alcyUser.name ? "Te llamás " + alcyUser.name + "." : "Todavía no me dijiste tu nombre. Decime “me llamo …” y lo recuerdo."],
    [/(me llamo|mi nombre es|llamame) ([a-z]+)/, m => {
      const name = capitalize(m[2]);
      alcyUser.name = name;
      localStorage.setItem("alcy_profile", JSON.stringify({ name, mode: "guest" }));
      updateProfileUI();
      return "¡Mucho gusto, " + name + "! A partir de ahora te llamo así.";
    }],
    [/^(hola|holaa|buenas|buen dia|buenas tardes|buenas noches|hey|que onda|alcy)\b/, () => {
      const h = new Date().getHours();
      const saludo = h < 6 ? "¡Hola" : h < 13 ? "¡Buen día" : h < 20 ? "¡Buenas tardes" : "¡Buenas noches";
      return saludo + who + "! Soy Alcy. Todavía estoy en una beta sin conexión a una IA real, pero puedo responder preguntas frecuentes, hacer cuentas, contarte chistes y ayudarte con ideas. ¿Qué querés saber?";
    }],
    [/(quien sos|quien eres|que sos|que eres|presentate|como te llamas|cual es tu nombre)/,
      "Soy Alcy, un asistente digital en desarrollo, creado como producto de PLÉYADES. En esta beta funciono con respuestas locales y reglas sencillas; todavía no tengo un modelo de IA conectado."],
    [/(que podes hacer|que puedes hacer|para que servis|como me ayudas|tus funciones|ayuda$|^ayuda)/,
      "Puedo responder preguntas frecuentes, hacer cuentas (sumas, restas, porcentajes, raíces), decirte la hora y la fecha, contarte chistes y datos curiosos, tirar un dado o una moneda, darte ideas y ayudarte a estudiar. Y si querés que te hable, activá el Modo voz o tocá el micrófono."],
    [/(tu voz|podes hablar|puedes hablar|hablame|modo voz|me hablas|escucharte)/,
      "¡Sí! Tocá el 🔊 al lado de mis respuestas, o activá el Modo voz en Ajustes y te las leo en voz alta. También podés tocar el micrófono 🎙 y hablarme: te respondo con voz."],
    [/(quien te creo|quien te hizo|empresa|pleyades)/,
      "Alcy es el asistente y PLÉYADES es la compañía que estamos usando como identidad matriz del proyecto."],
    [/(que significa alcy|significado de alcy|por que te llamas alcy)/,
      "Alcy es el nombre elegido para este asistente. Es un nombre propio de marca, no una sigla."],
    [/(cuantos anos tenes|cuantos anos tienes|que edad tenes|que edad tienes)/,
      "Soy muy nuevo: estoy en versión beta, así que todavía estoy aprendiendo a dar mis primeros pasos."],
    [/(como estas|todo bien|como va)/,
      "¡Funcionando y listo para probar! Todavía soy una versión básica, pero cada prueba nos ayuda a mejorar a Alcy. 💚"],
    [/(gracias|muchas gracias|te agradezco)/,
      "¡De nada! 💚 Si algo no sale bien, contame qué pasó y lo mejoramos."],
    [/(chau|adios|hasta luego|nos vemos)/,
      "¡Hasta la próxima! Cuando vuelvas, Alcy va a estar listo para otra prueba."],
    [/(que hora es|la hora actual|me decis la hora|me dices la hora)/, () => {
      lastTopic = "time";
      return "Son las " + new Date().toLocaleTimeString("es-AR", { hour: "2-digit", minute: "2-digit" }) + " según el reloj de tu dispositivo.";
    }],
    [/(que dia es|que fecha es|fecha de hoy|dia de hoy)/, () => {
      lastTopic = "date";
      return "Hoy es " + new Date().toLocaleDateString("es-AR", { weekday: "long", day: "numeric", month: "long", year: "numeric" }) + ".";
    }],
    [/(chiste|haceme reir|hazme reir|algo gracioso)/, () => tell("joke")],
    [/(dato curioso|curiosidad|dime algo curioso|decime algo curioso|sabias que)/, () => tell("fact")],
    [/(tira un dado|tirar un dado|lanza un dado|\bdado\b)/, () => "Tiré el dado y salió **" + (1 + Math.floor(Math.random() * 6)) + "**."],
    [/(cara o cruz|tira una moneda|lanza una moneda|\bmoneda\b)/, () => "Tiré la moneda y salió **" + pick(["cara", "cruz"]) + "**."],
    [/numero (?:entre|del) (\d+) (?:y|al|a) (\d+)/, m => {
      let a = Number(m[1]), b = Number(m[2]);
      if (a > b) [a, b] = [b, a];
      return "Elijo el **" + (a + Math.floor(Math.random() * (b - a + 1))) + "**.";
    }],
    [/capital de (?:la |el |los |las )?([a-z ]+)/, m => {
      const place = m[1].trim();
      return CAPITALS[place] ? "La capital de " + capitalize(place) + " es " + CAPITALS[place] + "." : null;
    }],
    [/(estoy triste|me siento mal|estoy mal|me siento solo|me siento sola)/,
      "Lamento que estés así. Si querés, contame qué pasó y lo hablamos. Y si es algo que te pesa mucho, también ayuda hablarlo con una persona de confianza."],
    [/(estoy aburrido|estoy aburrida|me aburro)/,
      "¡Entonces hagamos algo! Puedo contarte un chiste, un dato curioso, tirar un dado o darte ideas para un proyecto. ¿Qué elegís?"],
    [/(estoy cansado|estoy cansada|tengo sueno)/,
      "Si estás cansado, un descanso corto, agua y estirarte un poco pueden ayudar. Si podés, dormí lo suficiente: rinde más que cualquier truco."],
    [/(que es la inteligencia artificial|que es ia|define ia)/,
      "La inteligencia artificial (IA) es un área de la informática que crea sistemas capaces de realizar tareas como reconocer patrones, comprender lenguaje o generar contenido. No todos los sistemas de IA funcionan igual: algunos usan reglas y otros modelos entrenados con grandes cantidades de datos."],
    [/(como funciona la inteligencia artificial|como aprende una ia)/,
      "Muchos sistemas de IA se entrenan con ejemplos. Durante el entrenamiento ajustan sus parámetros para reconocer patrones y producir resultados. Después, al recibir una consulta, usan lo aprendido para generar una respuesta. Esta beta de Alcy todavía no usa ese tipo de modelo."],
    [/(que es un algoritmo|define algoritmo)/,
      "Un algoritmo es una serie ordenada de pasos para resolver un problema o realizar una tarea. Una receta de cocina, por ejemplo, puede verse como un algoritmo."],
    [/(que es internet|como funciona internet)/,
      "Internet es una red mundial de redes y dispositivos que intercambian información usando reglas comunes, como el conjunto de protocolos TCP/IP. La web es uno de los servicios que funciona sobre Internet."],
    [/(que es la fotosintesis|como hacen las plantas su alimento)/,
      "La fotosíntesis es el proceso por el que plantas, algas y algunas bacterias usan energía de la luz para transformar agua y dióxido de carbono en sustancias orgánicas. En las plantas también se libera oxígeno."],
    [/(que es la gravedad|por que caen las cosas)/,
      "La gravedad es una interacción de atracción entre cuerpos con masa. En la Tierra hace que los objetos sean atraídos hacia su centro y explica, por ejemplo, por qué caen cuando los soltamos."],
    [/(cuantos planetas|planetas del sistema solar|nombra los planetas)/,
      "En el sistema solar hay ocho planetas: Mercurio, Venus, Tierra, Marte, Júpiter, Saturno, Urano y Neptuno."],
    [/(formula del agua|de que esta hecha el agua)/,
      "La fórmula química del agua es H₂O: cada molécula tiene dos átomos de hidrógeno y uno de oxígeno."],
    [/(que es un atomo|define atomo)/,
      "Un átomo es la unidad básica de un elemento químico. Está formado por un núcleo con protones y neutrones, rodeado por electrones."],
    [/(que es una celula|define celula)/,
      "La célula es la unidad estructural y funcional básica de los seres vivos. Algunos organismos tienen una sola célula y otros están formados por muchas."],
    [/(ayudame a estudiar|como estudio|tecnica de estudio)/,
      "Probá este método: 1) leé un tema corto; 2) cerrá el apunte y explicalo con tus palabras; 3) anotá lo que no recordaste; 4) repasalo después de un rato. Si me pasás el tema, puedo prepararte preguntas de práctica."],
    [/(resumime|hacer un resumen|como resumo)/,
      "¡Sí! Pegá el texto o mandame el contenido que querés resumir. Puedo convertirlo en un resumen breve, una lista de ideas principales o una versión para exponer."],
    [/(traduci|traduccion|como se dice .* en ingles)/,
      "Puedo ayudar con traducciones sencillas. Escribí la frase y decime a qué idioma querés pasarla."],
    [/(dame ideas|ideas para|no se que crear)/,
      "Tres ideas para empezar: 1) una app que organice tareas en pequeños pasos; 2) un juego de preguntas para aprender algo nuevo; 3) un diario de ideas con etiquetas y búsqueda. Si me decís qué te interesa, las adapto."],
    [/(que es programacion|como empezar a programar|aprender a programar)/,
      "Programar es escribir instrucciones para que una computadora realice tareas. Para empezar, podés aprender HTML y CSS para interfaces, y JavaScript para agregar interacción. Lo mejor es construir un proyecto pequeño y practicar una cosa por vez."],
    [/(que es el cambio climatico|calentamiento global)/,
      "El cambio climático es una modificación a largo plazo de las temperaturas y los patrones del clima. Actualmente, el calentamiento observado se debe principalmente a las emisiones humanas de gases de efecto invernadero."],
    [/(que es la democracia|define democracia)/,
      "La democracia es una forma de organización política en la que la ciudadanía participa en las decisiones públicas, directamente o mediante representantes elegidos, dentro de un marco de derechos y leyes."],
    [/(estas conectado|estas conectada|tenes internet|tienes internet|podes buscar|puedes buscar)/,
      "No. Esta beta responde sin conexión mediante una pequeña base de respuestas y reglas. Todavía no puede consultar Internet ni conectarse a servicios externos."],
    [/(por que no respondes|no entendes|respuesta incorrecta)/,
      "Todavía tengo una comprensión muy limitada: detecto palabras y temas frecuentes, no interpreto cualquier frase como lo haría un modelo de IA. Probá reformular la pregunta o decime el tema con más detalle."]
  ];

  for (const [pattern, response] of rules) {
    const m = q.match(pattern);
    if (!m) continue;
    const out = typeof response === "function" ? response(m) : response;
    if (out) return out;
  }

  if (q.includes("porque") || q.startsWith("por que "))
    return "Buena pregunta. En esta beta todavía no puedo razonar sobre cualquier tema. Si me das un poco más de contexto, puedo intentar relacionarla con una de mis respuestas frecuentes.";
  if (q.startsWith("que es ") || q.startsWith("que significa "))
    return "Puedo intentar explicarlo, pero ese concepto todavía no está en mi pequeña base de conocimientos. ¿En qué materia o contexto aparece? Así puedo orientarte mejor.";
  if (q.startsWith("como "))
    return "Puedo ayudarte a pensarlo paso a paso, aunque esta versión tiene conocimientos limitados. Contame qué querés lograr y qué intentaste hasta ahora.";
  return "Entiendo lo que me decís: “" + input + "”.\n\nTodavía no tengo un modelo de IA conectado. Puedo responder preguntas frecuentes, hacer cuentas, contarte chistes o decirte la hora. Probá con “¿qué es la gravedad?”, “contame un chiste” o “¿cuánto es 24 × 3?”.";
}
function tell(kind) {
  lastTopic = kind;
  return kind === "joke" ? pick(JOKES) : "Dato curioso: " + pick(FACTS);
}

const GEMINI_MODEL = "gemini-3.8-flash";
function getGeminiKey(){try{return localStorage.getItem("alcy_gemini_api_key")||"";}catch(_){return "";}}
function setGeminiStatus(message, good=false){const el=$("#geminiStatus");if(el){el.textContent=message;el.style.borderColor=good?"#527b35":"#66512b";}}
async function askGemini(chat){
  const key=getGeminiKey();
  if(!key) throw new Error("Falta la clave de Gemini. Abrí el perfil → Ajustes → Inteligencia artificial.");
  const contents=chat.messages.slice(-24).map(m=>({role:m.role==="assistant"?"model":"user",parts:[{text:String(m.text||"").slice(0,12000)}]}));
  const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(key)}`,{
    method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({systemInstruction:{parts:[{text:`Tu nombre es Alcy, un asistente digital creado por PLÉYADES. Hablá en español rioplatense natural, de forma clara, amable y útil. Si conocés el nombre de usuario ${alcyUser.name||""}, podés usarlo sin exagerar. No afirmes tener capacidades que no tenés. Respetá la privacidad y no pidas contraseñas ni claves secretas.`}]},contents,generationConfig:{temperature:0.7,maxOutputTokens:1200}})
  });
  const data=await response.json().catch(()=>({}));
  if(!response.ok){const detail=data?.error?.message||`Error HTTP ${response.status}`;throw new Error(detail);}
  const result=(data.candidates||[]).flatMap(c=>c.content?.parts||[]).map(p=>p.text||"").join("\n").trim();
  if(!result)throw new Error("Google no devolvió una respuesta. Probá de nuevo en unos segundos.");
  return result;
}
async function send(text, opts = {}) {
  text=(text||"").trim();if(!text)return;
  stopSpeaking();
  if(!current())newChat();
  const chat=current();chat.archived=false;
  chat.messages.push({role:"user",text});
  if(chat.messages.length===1)chat.title=text.slice(0,30)+(text.length>30?"…":"");
  save();welcome.style.display="none";addBubble("user",text);
  promptEl.value="";promptEl.style.height="auto";
  const typing=document.createElement("div");typing.className="typing";typing.textContent="Alcy está pensando…";messagesEl.appendChild(typing);
  $("#conversation").scrollTop=$("#conversation").scrollHeight;
  $("#sendBtn").disabled=true;
  let result="";
  try{
    if(getGeminiKey()){
      result=await askGemini(chat);
    }else{
      await new Promise(resolve=>setTimeout(resolve,350));
      result=answer(text);
    }
  }catch(error){
    result="No pude conectar con Gemini: "+(error?.message||"error desconocido")+". Revisá tu conexión y la clave en Ajustes. Si la clave está correcta, puede que el modelo o el acceso a la API no estén disponibles.";
  }finally{
    typing.remove();
    chat.messages.push({role:"assistant",text:result});save();addBubble("assistant",result);
    $("#sendBtn").disabled=false;
    if(synthOK&&(voiceModeOn()||opts.spoken)){
      const btns=messagesEl.querySelectorAll(".voice-button");
      speakAlcy(result,btns[btns.length-1]||null);
    }
  }
}
function closeChatMenu(){
  const m=$("#chatActionMenu");if(m)m.remove();
  document.removeEventListener("pointerdown",outsideMenu,true);
  document.removeEventListener("keydown",menuKey);
}
function menuKey(e){if(e.key==="Escape")closeChatMenu();}
function outsideMenu(e){const m=$("#chatActionMenu");if(m&&!m.contains(e.target))closeChatMenu();}
function showChatMenu(chat,anchor){
  closeChatMenu();
  const menu=document.createElement("div");menu.id="chatActionMenu";menu.className="chat-action-menu";
  function addAction(label,icon,fn,danger=false){
    const b=document.createElement("button");b.type="button";b.className=danger?"danger":"";
    const ic=document.createElement("span");ic.className="action-icon";ic.textContent=icon;
    const tx=document.createElement("span");tx.textContent=label;b.append(ic,tx);
    b.addEventListener("click",e=>{e.stopPropagation();fn();});menu.appendChild(b);
  }
  addAction(chat.pinned?"Desanclar chat":"Anclar chat","◆",()=>{
    chat.pinned=!chat.pinned;save();closeChatMenu();
  });
  addAction(chat.archived?"Desarchivar chat":"Archivar chat","▤",()=>{
    chat.archived=!chat.archived;
    if(chat.archived&&currentId===chat.id){currentId=chats.find(c=>!c.archived&&c.id!==chat.id)?.id||null;renderChat();}
    save();closeChatMenu();
  });
  addAction("Borrar chat","⌫",()=>{
    menu.innerHTML="";
    const question=document.createElement("p");question.className="delete-question";question.textContent="¿Borrar este chat? No se puede deshacer.";menu.appendChild(question);
    const controls=document.createElement("div");controls.className="delete-controls";
    const cancel=document.createElement("button");cancel.type="button";cancel.textContent="Cancelar";cancel.onclick=closeChatMenu;
    const confirm=document.createElement("button");confirm.type="button";confirm.className="danger";confirm.textContent="Borrar";
    confirm.onclick=()=>{
      chats=chats.filter(c=>c.id!==chat.id);
      if(currentId===chat.id){currentId=chats.find(c=>!c.archived)?.id||null;renderChat();}
      save();closeChatMenu();
    };
    controls.append(cancel,confirm);menu.appendChild(controls);
    const r=anchor.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(r.left,innerWidth-202))+"px";menu.style.top=Math.max(8,Math.min(r.bottom+5,innerHeight-menu.offsetHeight-8))+"px";
  },true);
  document.body.appendChild(menu);
  const r=anchor.getBoundingClientRect();
  menu.style.left=Math.max(8,Math.min(r.left,innerWidth-202))+"px";
  menu.style.top=Math.max(8,Math.min(r.bottom+5,innerHeight-menu.offsetHeight-8))+"px";
  document.addEventListener("pointerdown",outsideMenu,true);
  document.addEventListener("keydown",menuKey);
}

$("#showGuest").addEventListener("click",()=>showEntryPanel("guest"));
$("#backFromGuest").addEventListener("click",()=>showEntryPanel("account"));
$("#guestForm").addEventListener("submit",event=>{
  event.preventDefault();
  enterAsGuest($("#guestUsername").value);
});
$("#accountForm").addEventListener("submit",event=>{
  event.preventDefault();
  const email=$("#accountEmail").value.trim();
  const password=$("#accountPassword").value;
  if(!email || !password){
    alert("Completá el correo y la contraseña de prueba.");
    return;
  }
  const username=cleanUsername(email.split("@")[0]);
  // Flujo de demostración: no se envía ni se guarda ninguna credencial.
  $("#accountPassword").value="";
  alert("El inicio de sesión real todavía no está habilitado. Por seguridad, Alcy no guardó ni envió tu correo ni tu contraseña. Vas a entrar en modo invitado para probar la beta.");
  enterAsGuest(username);
});


function updateProfileUI(){
  const name=alcyUser.name || "Invitado";
  $("#aboutBtn").textContent=name.slice(0,1).toUpperCase();
  $("#profileAvatar").textContent=name.slice(0,1).toUpperCase();
  $("#profileNameInput").value=alcyUser.name;
  $("#profileMode").textContent="Cuenta de invitado · Este dispositivo";
}
function showAccountTab(tab){
  document.querySelectorAll(".account-tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
  document.querySelectorAll(".account-panel").forEach(p=>p.classList.remove("active"));
  const panel=$("#"+tab+"Panel");
  if(panel)panel.classList.add("active");
}
document.querySelectorAll(".account-tab").forEach(button=>{
  button.addEventListener("click",()=>showAccountTab(button.dataset.tab));
});
$("#aboutBtn").onclick=()=>{
  updateProfileUI();
  showAccountTab("profile");
  $("#aboutModal").classList.add("open");
  $("#overlay").classList.add("open");
};
$("#saveProfileName").addEventListener("click",()=>{
  const name=cleanUsername($("#profileNameInput").value);
  if(!name){alert("Escribí un nombre de usuario.");return;}
  alcyUser.name=name;
  localStorage.setItem("alcy_profile",JSON.stringify({name,mode:"guest"}));
  updateProfileUI();
  const heading=$("#welcomeHeading");
  if(heading && welcome.style.display!=="none")heading.innerHTML=`Hola, <em>${escapeHTML(name)}</em>.`;
  closeAccountModal();
});
function closeAccountModal(){
  $("#aboutModal").classList.remove("open");
  $("#overlay").classList.remove("open");
}
$("#logoutButton").addEventListener("click",()=>{
  closeAccountModal();
  localStorage.removeItem("alcy_profile");
  alcyUser.name="";
  $("#mainApp").hidden=true;
  showEntryPanel("account");
  $("#entryScreen").classList.add("visible");
});
$("#voiceEnabled").checked=localStorage.getItem("alcy_voice_enabled")!=="false";
$("#voiceRate").value=localStorage.getItem("alcy_voice_rate")||"0.96";
$("#reduceMotion").checked=localStorage.getItem("alcy_reduce_motion")==="true";
$("#voiceEnabled").addEventListener("change",e=>{
  localStorage.setItem("alcy_voice_enabled",String(e.target.checked));
  if(!e.target.checked && "speechSynthesis" in window)window.speechSynthesis.cancel();
});
$("#voiceRate").addEventListener("change",e=>localStorage.setItem("alcy_voice_rate",e.target.value));
$("#reduceMotion").addEventListener("change",e=>{
  localStorage.setItem("alcy_reduce_motion",String(e.target.checked));
  document.documentElement.classList.toggle("reduce-motion",e.target.checked);
});
if($("#reduceMotion").checked)document.documentElement.classList.add("reduce-motion");
$("#clearHistoryButton").addEventListener("click",()=>{
  if(!confirm("¿Borrar todos los chats? Esta acción no se puede deshacer."))return;
  chats=[];currentId=null;localStorage.removeItem("alcy_chats");renderHistory();renderChat();
  closeAccountModal();
});

$("#chatForm").addEventListener("submit",e=>{e.preventDefault();send(promptEl.value);});
promptEl.addEventListener("input",()=>{promptEl.style.height="auto";promptEl.style.height=Math.min(promptEl.scrollHeight,130)+"px";});
$("#newChat").onclick=newChat;
document.querySelectorAll(".suggestion").forEach(b=>b.onclick=()=>send(b.dataset.prompt));
function closeMenu(){$("#sidebar").classList.remove("open");$("#overlay").classList.remove("menu-open");}
$("#menuBtn").onclick=()=>{$("#sidebar").classList.add("open");$("#overlay").classList.add("menu-open");};
$("#overlay").onclick=()=>{closeMenu();$("#aboutModal").classList.remove("open");$("#overlay").classList.remove("open");closeChatMenu();};
$("#closeModal").onclick=()=>{$("#aboutModal").classList.remove("open");$("#overlay").classList.remove("open");};
if(chats.length){currentId=chats.find(c=>!c.archived)?.id||chats[0].id;renderHistory();renderChat();}else renderHistory();
showEntryPanel("account");
updateProfileUI();
setTimeout(()=>$("#entryScreen").classList.add("visible"),2050);

// ---- Modo voz, selector de voz y micrófono ----
$("#voiceMode").checked=voiceModeOn();
$("#voiceMode").addEventListener("change",e=>{
  localStorage.setItem("alcy_voice_mode",String(e.target.checked));
  if(!e.target.checked)stopSpeaking();
});
$("#voiceChoice").addEventListener("change",e=>localStorage.setItem("alcy_voice_name",e.target.value));
$("#testVoice").addEventListener("click",()=>speakAlcy("Hola, soy Alcy. Así suena mi voz.",null));
$("#micBtn").addEventListener("click",toggleMic);

// ---- Conexión opcional con Gemini de Google ----
const geminiKeyInput=$("#geminiApiKey");
if(geminiKeyInput)geminiKeyInput.value=getGeminiKey();
if(getGeminiKey())setGeminiStatus("Clave guardada en este dispositivo. Alcy intentará usar Gemini al enviar mensajes.",true);
$("#showGeminiKey")?.addEventListener("change",e=>{if(geminiKeyInput)geminiKeyInput.type=e.target.checked?"text":"password";});
$("#saveGeminiKey")?.addEventListener("click",()=>{
  const key=(geminiKeyInput?.value||"").trim();
  if(!key){localStorage.removeItem("alcy_gemini_api_key");setGeminiStatus("Clave borrada. Alcy vuelve al modo local.");alert("Se borró la clave de este dispositivo.");return;}
  if(key.length<20){alert("La clave parece demasiado corta. Revisá que hayas copiado la clave completa.");return;}
  localStorage.setItem("alcy_gemini_api_key",key);
  setGeminiStatus("Clave guardada localmente. Tocá ‘Probar conexión con Google’ para verificarla.",true);
});
$("#testGemini")?.addEventListener("click",async()=>{
  const key=(geminiKeyInput?.value||getGeminiKey()).trim();
  if(!key){setGeminiStatus("Primero pegá tu clave de Gemini.");alert("Primero pegá tu clave de Gemini y guardala.");return;}
  localStorage.setItem("alcy_gemini_api_key",key);
  const btn=$("#testGemini");btn.disabled=true;btn.textContent="Probando conexión…";setGeminiStatus("Conectando con Google…");
  try{
    const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(key)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{role:"user",parts:[{text:"Respondé solamente: conexión correcta"}]}],generationConfig:{maxOutputTokens:30}})});
    const data=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(data?.error?.message||`Error HTTP ${response.status}`);
    setGeminiStatus("¡Conexión correcta! Alcy ya puede usar Gemini de Google.",true);
    alert("¡Conexión correcta! Ahora Alcy puede responder usando Gemini.");
  }catch(error){setGeminiStatus("No se pudo conectar: "+(error?.message||"error desconocido"));alert("No se pudo conectar con Gemini. Revisá la clave, la conexión y el acceso a la API.\n\nDetalle: "+(error?.message||"error desconocido"));}
  finally{btn.disabled=false;btn.textContent="Probar conexión con Google";}
});

