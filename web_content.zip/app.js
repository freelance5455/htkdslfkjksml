"use strict";

/*
========================================
 CODEXA APPLICATION ENGINE
========================================
*/

(function () {

    const DATA = window.CODEXA_DATA;

    if (!DATA || !Array.isArray(DATA.tracks)) {
        alert("تعذر تحميل بيانات Codexa. تأكد من وجود data.js.");
        return;
    }

    const STORAGE_KEY = "codexa_student_data_v1";

    const $ = (selector) => document.querySelector(selector);

    function highlightCode(source) {
        const escaped = safeText(source);
        return escaped
            .replace(/(&quot;.*?&quot;|&#39;.*?&#39;|".*?"|'.*?')/g, '<span class="syntax-string">$1</span>')
            .replace(/(\b(?:const|let|var|function|return|if|else|for|while|class|new|int|float|double|char|bool|void|using|namespace|include|import|from|def|print|cout|cin|public|static)\b)/g, '<span class="syntax-keyword">$1</span>')
            .replace(/(\b\d+(?:\.\d+)?\b)/g, '<span class="syntax-number">$1</span>')
            .replace(/(\/\/.*|#.*)/g, '<span class="syntax-comment">$1</span>');
    }

    const $$ = (selector) => Array.from(
        document.querySelectorAll(selector)
    );

    const state = {
        page: "home",
        activeTrack: null,
        activeLesson: null,
        quiz: null,
        quizIndex: 0,
        quizAnswers: [],
        quizResult: null,
        certificateTrack: null,
        confirmAction: null
    };

    function defaultStudent() {
        return {
            name: "",
            theme: "dark",

            points: 0,

            completedLessons: [],
            passedLessons: [],
            lessonAttempts: {},
            latestScores: {},
            bestScores: {},

            completedTracks: [],
            passedComprehensive: [],

            badges: [],
            projectUnlocks: [],

            feedback: [],

            lastLesson: null,
            lastTrack: null
        };
    }

    function loadStudent() {
        try {
            const raw = localStorage.getItem(STORAGE_KEY);

            if (!raw) {
                return defaultStudent();
            }

            const saved = JSON.parse(raw);

            return {
                ...defaultStudent(),
                ...saved,

                completedLessons:
                    Array.isArray(saved.completedLessons)
                        ? saved.completedLessons : [],

                passedLessons:
                    Array.isArray(saved.passedLessons)
                        ? saved.passedLessons : [],

                badges:
                    Array.isArray(saved.badges)
                        ? saved.badges : [],

                projectUnlocks:
                    Array.isArray(saved.projectUnlocks)
                        ? saved.projectUnlocks : [],

                feedback:
                    Array.isArray(saved.feedback)
                        ? saved.feedback : [],

                lessonAttempts:
                    saved.lessonAttempts || {},

                latestScores:
                    saved.latestScores || {},

                bestScores:
                    saved.bestScores || {},

                completedTracks:
                    Array.isArray(saved.completedTracks)
                        ? saved.completedTracks : [],

                passedComprehensive:
                    Array.isArray(saved.passedComprehensive)
                        ? saved.passedComprehensive : []
            };

        } catch (error) {
            console.error("Load error:", error);
            return defaultStudent();
        }
    }

    let student = loadStudent();

    function saveStudent() {
        try {
            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(student)
            );

            return true;

        } catch (error) {
            console.error("Save error:", error);

            toast(
                "تعذر حفظ البيانات. تأكد من مساحة التخزين.",
                "error"
            );

            return false;
        }
    }

    function escapeHTML(value) {
        return String(value ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function safeText(value) {
        return escapeHTML(value);
    }

    function getTrack(trackId) {
        return DATA.tracks.find(
            track => track.id === trackId
        );
    }

    function getLesson(trackId, lessonId) {
        const track = getTrack(trackId);

        if (!track) return null;

        return track.lessons.find(
            lesson => lesson.id === lessonId
        ) || null;
    }

    function getTrackProgress(track) {
        const total = track.lessons.length;

        if (!total) return 0;

        const passed = track.lessons.filter(
            lesson => student.passedLessons.includes(lesson.id)
        ).length;

        return Math.round((passed / total) * 100);
    }

    function getTrackPoints(track) {
        return track.lessons.reduce((total, lesson) => {
            return total + (
                student.passedLessons.includes(lesson.id)
                    ? DATA.settings.pointsPerQuiz : 0
            );
        }, 0);
    }

    function isLessonUnlocked(track, index) {
        if (index === 0) return true;

        const previousLesson = track.lessons[index - 1];

        return student.passedLessons.includes(
            previousLesson.id
        );
    }

    function getLevel() {
        return Math.floor(student.points / 100) + 1;
    }

    function getCurrentLesson() {
        if (!student.lastTrack || !student.lastLesson) {
            return null;
        }

        return getLesson(
            student.lastTrack,
            student.lastLesson
        );
    }

    function toast(message, type = "success") {
        const container = $("#toastContainer");

        if (!container) return;

        const item = document.createElement("div");

        item.className = "toast " + type;
        item.textContent = message;

        container.appendChild(item);

        setTimeout(() => {
            item.remove();
        }, 3500);
    }

    function showConfirm(title, message, action) {
        $("#confirmTitle").textContent = title;
        $("#confirmMessage").textContent = message;

        state.confirmAction = action;

        $("#confirmModal").classList.remove("hidden");
    }

    function hideConfirm() {
        $("#confirmModal").classList.add("hidden");
        state.confirmAction = null;
    }

    function syncProfile() {
        const name = student.name || "الطالب";
        const initial = name.trim().charAt(0) || "ط";

        $("#sidebarName").textContent = name;
        $("#sidebarLevel").textContent =
            "المستوى " + getLevel();

        $("#sidebarAvatar").textContent = initial;
        $("#topAvatar").textContent = initial;

        document.body.classList.toggle(
            "light-theme",
            student.theme === "light"
        );

        const themeToggle = $("#themeToggle");
        if (themeToggle) {
            const isLight = student.theme === "light";
            const icon = themeToggle.querySelector(".theme-toggle-icon");
            if (icon) {
                icon.textContent = isLight ? "☾" : "☀";
            }
            const label = isLight
                ? "التبديل إلى الوضع الداكن"
                : "التبديل إلى الوضع الفاتح";
            themeToggle.setAttribute("aria-label", label);
            themeToggle.setAttribute("title", label);
        }
    }

    function navigate(page) {
        state.page = page;

        state.quiz = null;
        state.quizResult = null;

        closeSidebar();

        render();
    }

    function closeSidebar() {
        $("#sidebar").classList.remove("open");
        $("#sidebarOverlay").classList.remove("show");
    }

    function openSidebar() {
        $("#sidebar").classList.add("open");
        $("#sidebarOverlay").classList.add("show");
    }

    function setActiveNavigation() {
        const page = state.page === "track-detail" ||
                     state.page === "lesson" ||
                     state.page === "quiz" ||
                     state.page === "quiz-result" ||
                     state.page === "certificate"
            ? "tracks"
            : state.page === "project-detail"
                ? "projects"
                : state.page;

        $$(".nav-item").forEach(button => {
            button.classList.toggle(
                "active",
                button.dataset.page === page
            );
        });
    }

    function render() {
        syncProfile();
        setActiveNavigation();

        const content = $("#pageContent");

        if (!student.name) {
            $("#app").classList.add("hidden");
            $("#welcomeScreen").classList.remove("hidden");
            return;
        }

        $("#welcomeScreen").classList.add("hidden");
        $("#app").classList.remove("hidden");

        const pages = {
            home: renderHome,
            tracks: renderTracks,
            lesson: renderLesson,
            quiz: renderQuiz,
            result: renderQuizResult,
            comprehensive: renderComprehensive,
            achievements: renderAchievements,
            projects: renderProjects,
            guide: renderGuide,
            settings: renderSettings,
            feedback: renderFeedback,
            certificate: renderCertificate
        };

        const titles = {
            home: "الرئيسية",
            tracks: "المسارات التعليمية",
            lesson: "الدرس",
            quiz: "الاختبار",
            result: "نتيجة الاختبار",
            comprehensive: "الامتحان الشامل",
            achievements: "الإنجازات",
            projects: "المشروعات",
            guide: "دليل الاستخدام",
            settings: "الإعدادات",
            feedback: "رأيك يهمنا",
            certificate: "الشهادة"
        };

        $("#pageTitle").textContent =
            titles[state.page] || "Codexa";

        const pageFunction = pages[state.page] || renderHome;

        content.innerHTML = pageFunction();

        bindDynamicEvents();
    }

    function pageHeading(title, subtitle) {
        return `
            <div class="page-heading">
                <h1>${title}</h1>
                <p>${subtitle}</p>
            </div>
        `;
    }

    function progressBar(progress) {
        return `
            <div class="progress-track">
                <div class="progress-fill"
                     style="width:${progress}%"></div>
            </div>

            <div class="progress-meta">
                <span>التقدم</span>
                <strong>${progress}%</strong>
            </div>
        `;
    }

    function renderHome() {
        const totalLessons = DATA.tracks.reduce(
            (total, track) => total + track.lessons.length,
            0
        );

        const passedLessons = student.passedLessons.length;

        const totalTracks = DATA.tracks.length;

        const completedTracks = student.completedTracks.length;

        const totalProgress = totalLessons
            ? Math.round((passedLessons / totalLessons) * 100)
            : 0;

        const lastTrack = getTrack(student.lastTrack);
        const lastLesson = getCurrentLesson();

        const continueCard = lastTrack && lastLesson
            ? `
                <div class="card">
                    <h3>📖 كمّل من حيث توقفت</h3>

                    <p>
                        ${safeText(lastTrack.title)}
                        — ${safeText(lastLesson.title)}
                    </p>

                    <div class="button-row">
                        <button class="primary-btn"
                                data-action="continue-learning">
                            تابع التعلم
                        </button>
                    </div>
                </div>
            `
            : `
                <div class="card">
                    <h3>🚀 ابدأ أول رحلة تعليمية</h3>
                    <p>اختر مسارك الأول وابدأ من الدرس الأول.</p>

                    <button class="primary-btn"
                            data-action="open-tracks">
                        استكشف المسارات
                    </button>
                </div>
            `;

        return `
            <section class="hero-card">
                <div class="hero-icon">👋</div>

                <h1>
                    أهلًا يا
                    <span class="gradient-text">
                        ${safeText(student.name)}
                    </span>
                </h1>

                <p>
                    كل سطر كود بتتعلمه بيقرّبك من هدفك.
                    ابدأ خطوة جديدة النهارده!
                </p>

                <div class="button-row">
                    <button class="primary-btn"
                            data-action="open-tracks">
                        ابدأ التعلم 🚀
                    </button>

                    <button class="secondary-btn"
                            data-action="open-achievements">
                        إنجازاتي 🏆
                    </button>
                </div>
            </section>

            <div class="section-heading">
                <h2>ملخص رحلتك</h2>
            </div>

            <div class="grid grid-4">

                <div class="card stat-card">
                    <div class="stat-icon">📚</div>
                    <div class="stat-number">${passedLessons}</div>
                    <div class="stat-label">دروس اجتزت اختباراتها</div>
                </div>

                <div class="card stat-card">
                    <div class="stat-icon">🏆</div>
                    <div class="stat-number">${completedTracks}</div>
                    <div class="stat-label">مسارات مكتملة</div>
                </div>

                <div class="card stat-card">
                    <div class="stat-icon">💎</div>
                    <div class="stat-number">${student.points}</div>
                    <div class="stat-label">نقاطك</div>
                </div>

                <div class="card stat-card">
                    <div class="stat-icon">⭐</div>
                    <div class="stat-number">${getLevel()}</div>
                    <div class="stat-label">مستواك الحالي</div>
                </div>

            </div>

            <div class="section-heading">
                <h2>التقدم الكلي</h2>
            </div>

            <div class="card">
                <p>نسبة اجتياز اختبارات الدروس في كل المسارات</p>
                ${progressBar(totalProgress)}
            </div>

            <div class="section-heading">
                <h2>متابعة التعلم</h2>
            </div>

            ${continueCard}

            <div class="section-heading">
                <h2>المسارات التعليمية</h2>

                <button class="secondary-btn"
                        data-action="open-tracks">
                    عرض الكل
                </button>
            </div>

            <div class="grid grid-2">
                ${DATA.tracks.map(track => `
                    <div class="card track-card">

                        <div class="track-icon">
                            ${track.icon}
                        </div>

                        <h3>${safeText(track.title)}</h3>

                        <p>${safeText(track.description)}</p>

                        ${progressBar(getTrackProgress(track))}

                        <button class="primary-btn"
                                data-action="open-track"
                                data-track="${track.id}">
                            افتح المسار
                        </button>

                    </div>
                `).join("")}
            </div>
        `;
    }

    function renderTracks() {
        return `
            ${pageHeading(
                "المسارات التعليمية",
                "اختار المجال اللي تحب تبدأ تتعلمه."
            )}

            <div class="grid grid-2">

                ${DATA.tracks.map(track => `
                    <div class="card track-card">

                        <div class="track-icon">${track.icon}</div>

                        <h3>${safeText(track.title)}</h3>

                        <p>${safeText(track.description)}</p>

                        <div class="progress-meta">
                            <span>
                                ${track.lessons.length} دروس
                            </span>

                            <strong>
                                ${getTrackProgress(track)}%
                            </strong>
                        </div>

                        ${progressBar(getTrackProgress(track))}

                        <button class="primary-btn"
                                data-action="open-track"
                                data-track="${track.id}">
                            عرض الدروس
                        </button>

                    </div>
                `).join("")}

            </div>
        `;
    }

    function renderTrackDetail(track) {
        const lessons = track.lessons;

        const allPassed = lessons.every(
            lesson => student.passedLessons.includes(lesson.id)
        );

        const comprehensivePassed =
            student.passedComprehensive.includes(track.id);

        return `
            ${pageHeading(
                `${track.icon} ${safeText(track.title)}`,
                safeText(track.description)
            )}

            <div class="card">
                <h3>تقدمك في المسار</h3>

                ${progressBar(getTrackProgress(track))}

                <p>
                    اجتزت اختبارات
                    ${lessons.filter(
                        lesson => student.passedLessons.includes(lesson.id)
                    ).length}
                    من أصل ${lessons.length} دروس.
                </p>
            </div>

            <div class="section-heading">
                <h2>قائمة الدروس</h2>
            </div>

            <div class="lesson-list">

                ${lessons.map((lesson, index) => {
                    const unlocked = isLessonUnlocked(track, index);
                    const passed = student.passedLessons.includes(lesson.id);
                    const completed = student.completedLessons.includes(lesson.id);

                    return `
                        <div class="lesson-row">

                            <div class="lesson-number">
                                ${
                                    passed ? "✓" :
                                    unlocked ? index + 1 : "🔒"
                                }
                            </div>

                            <div class="lesson-info">
                                <h3>${safeText(lesson.title)}</h3>

                                <small>
                                    ${safeText(lesson.duration || "")}
                                    ${
                                        passed ? " • تم اجتياز الاختبار" :
                                        completed ? " • قرأت الدرس" :
                                        unlocked ? " • متاح" :
                                        " • مقفل حتى اجتياز الاختبار السابق"
                                    }
                                </small>
                            </div>

                            <button
                                class="${unlocked ? "primary-btn" : "secondary-btn"}"
                                data-action="open-lesson"
                                data-track="${track.id}"
                                data-lesson="${lesson.id}"
                                ${unlocked ? "" : "disabled"}>

                                ${passed ? "مراجعة" : unlocked ? "ابدأ" : "مقفل"}

                            </button>

                        </div>
                    `;
                }).join("")}

            </div>

            <div class="section-heading">
                <h2>الامتحان الشامل</h2>
            </div>

            <div class="card">

                <h3>
                    ${comprehensivePassed ? "✓ تم اجتيازه" : "اختبر نفسك"}
                </h3>

                <p>
                    ${
                        allPassed
                            ? "اجتزت اختبارات الدروس كلها. يمكنك بدء الامتحان الشامل."
                            : "اجتز اختبارات الدروس أولًا لفتح الامتحان الشامل."
                    }
                </p>

                <button class="primary-btn"
                        data-action="start-comprehensive"
                        data-track="${track.id}"
                        ${allPassed ? "" : "disabled"}>

                    ${comprehensivePassed ? "إعادة الامتحان" : "ابدأ الامتحان الشامل"}

                </button>

                ${
                    comprehensivePassed && allPassed
                        ? `
                            <button class="secondary-btn"
                                    data-action="open-certificate"
                                    data-track="${track.id}">
                                عرض الشهادة
                            </button>
                        `
                        : ""
                }

            </div>

            <div class="button-row">
                <button class="secondary-btn"
                        data-action="open-projects">
                    مشروعات البرمجة
                </button>

                <button class="secondary-btn"
                        data-action="open-tracks">
                    العودة للمسارات
                </button>
            </div>
        `;
    }

    function renderLesson() {
        const track = getTrack(state.activeTrack);

        if (!track) {
            return renderTracks();
        }

        const lesson = getLesson(
            state.activeTrack,
            state.activeLesson
        );

        if (!lesson) {
            return renderTrackDetail(track);
        }

        const index = track.lessons.findIndex(
            item => item.id === lesson.id
        );

        if (!isLessonUnlocked(track, index)) {
            toast("اجتز اختبار الدرس السابق أولًا.", "error");
            state.page = "tracks";
            return renderTracks();
        }

        const previousLesson = index > 0
            ? track.lessons[index - 1] : null;

        const nextLesson = index < track.lessons.length - 1
            ? track.lessons[index + 1] : null;

        const passed = student.passedLessons.includes(lesson.id);

        return `
            ${pageHeading(
                safeText(lesson.title),
                `${safeText(track.title)} • ${index + 1} من ${track.lessons.length}`
            )}

            <div class="card">
                <div class="progress-meta">
                    <span>الدرس ${index + 1}</span>
                    <span>${safeText(lesson.duration || "")}</span>
                </div>

                ${progressBar(
                    Math.round(((index + 1) / track.lessons.length) * 100)
                )}

                <article class="lesson-body">
                    ${lesson.content || "<p>لم يُضف محتوى لهذا الدرس بعد.</p>"}
                </article>

                ${(lesson.code || []).map(example => `
                    <div class="code-card">

                        <div class="code-header">
                            <span>
                                ${safeText(example.title)}
                                • ${safeText(example.language)}
                            </span>

                            <button
                                data-action="copy-code"
                                data-code="${encodeURIComponent(example.code)}">

                                نسخ الكود 📋

                            </button>
                        </div>

                        <pre><code>${highlightCode(example.code)}</code></pre>

                    </div>
                `).join("")}

                <div class="callout">
                    <strong>نصيحة:</strong>
                    جرّب كتابة الكود بنفسك، وغيّر القيم وشاهد النتيجة.
                </div>

                <div class="button-row">

                    <button class="secondary-btn"
                            data-action="mark-completed"
                            data-track="${track.id}"
                            data-lesson="${lesson.id}">

                        ${student.completedLessons.includes(lesson.id)
                            ? "✓ تم وضع علامة الإكمال"
                            : "علّم الدرس كمكتمل"}

                    </button>

                    <button class="primary-btn"
                            data-action="start-quiz"
                            data-track="${track.id}"
                            data-lesson="${lesson.id}">

                        ${passed ? "أعد الاختبار" : "ابدأ الاختبار 📝"}

                    </button>

                </div>

                <div class="lesson-navigation">

                    <button class="secondary-btn"
                            data-action="lesson-previous"
                            ${previousLesson ? "" : "disabled"}>

                        ← الدرس السابق

                    </button>

                    <button class="secondary-btn"
                            data-action="lesson-next"
                            ${nextLesson && passed ? "" : "disabled"}>

                        الدرس التالي →

                    </button>

                </div>

            </div>
        `;
    }

    function startQuiz(trackId, lessonId, comprehensive = false) {
        const track = getTrack(trackId);

        if (!track) {
            toast("المسار غير موجود.", "error");
            return;
        }

        let questions = [];

        if (comprehensive) {
            const allPassed = track.lessons.every(
                lesson => student.passedLessons.includes(lesson.id)
            );

            if (!allPassed) {
                toast("اجتز اختبارات الدروس أولًا.", "error");
                return;
            }

            questions = track.lessons.flatMap(lesson =>
                (lesson.quiz || []).map(question => ({
                    ...question,
                    sourceLesson: lesson.title
                }))
            );

            state.quiz = {
                trackId,
                lessonId: null,
                comprehensive: true,
                questions
            };

        } else {
            const lesson = getLesson(trackId, lessonId);

            if (!lesson) return;

            const index = track.lessons.findIndex(
                item => item.id === lesson.id
            );

            if (!isLessonUnlocked(track, index)) {
                toast("الدرس مقفل.", "error");
                return;
            }

            questions = lesson.quiz || [];

            if (!questions.length) {
                toast("لا توجد أسئلة لهذا الاختبار حاليًا.", "error");
                return;
            }

            state.quiz = {
                trackId,
                lessonId,
                comprehensive: false,
                questions
            };
        }

        state.quizIndex = 0;
        state.quizAnswers = Array(questions.length).fill(null);
        state.quizResult = null;

        state.page = "quiz";

        render();
    }

    function renderQuiz() {
        if (!state.quiz) {
            state.page = "tracks";
            return renderTracks();
        }

        const questions = state.quiz.questions;
        const index = state.quizIndex;
        const question = questions[index];

        if (!question) {
            return `
                <div class="empty-state">
                    لا توجد أسئلة متاحة.
                </div>
            `;
        }

        const selected = state.quizAnswers[index];

        const title = state.quiz.comprehensive
            ? "الامتحان الشامل"
            : "اختبار الدرس";

        return `
            ${pageHeading(
                title,
                "اختار الإجابة المناسبة. تقدر ترجع لأسئلتك وتعدّل إجاباتك قبل التسليم."
            )}

            <div class="card">

                <div class="quiz-progress">
                    <span>السؤال ${index + 1} من ${questions.length}</span>
                    <span>${Math.round((index / questions.length) * 100)}% مكتمل</span>
                </div>

                ${progressBar(
                    Math.round(((index + 1) / questions.length) * 100)
                )}

                <h2 style="margin-top:25px; line-height:1.8;">
                    ${safeText(question.question)}
                </h2>

                ${
                    question.sourceLesson
                        ? `<p>الدرس: ${safeText(question.sourceLesson)}</p>`
                        : ""
                }

                <div class="quiz-options">

                    ${question.options.map((option, optionIndex) => `
                        <label class="quiz-option ${
                            selected === optionIndex ? "selected" : ""
                        }">

                            <input
                                type="radio"
                                name="quizAnswer"
                                value="${optionIndex}"
                                ${selected === optionIndex ? "checked" : ""}>

                            <span>
                                ${safeText(option)}
                            </span>

                        </label>
                    `).join("")}

                </div>

                <div class="lesson-navigation">

                    <button class="secondary-btn"
                            data-action="quiz-previous"
                            ${index === 0 ? "disabled" : ""}>

                        ← السابق

                    </button>

                    ${
                        index < questions.length - 1
                            ? `
                                <button class="primary-btn"
                                        data-action="quiz-next">

                                    السؤال التالي →

                                </button>
                            `
                            : `
                                <button class="primary-btn"
                                        data-action="quiz-submit">

                                    تسليم الاختبار

                                </button>
                            `
                    }

                </div>

                <div class="button-row">
                    <button class="secondary-btn"
                            data-action="quiz-cancel">

                        خروج من الاختبار

                    </button>
                </div>

            </div>
        `;
    }

    function collectCurrentAnswer() {
        const selected = $('input[name="quizAnswer"]:checked');

        state.quizAnswers[state.quizIndex] = selected
            ? Number(selected.value)
            : null;
    }

    function calculateScore() {
        const questions = state.quiz.questions;

        let correct = 0;

        questions.forEach((question, index) => {
            if (state.quizAnswers[index] === question.answer) {
                correct++;
            }
        });

        const score = questions.length
            ? Math.round((correct / questions.length) * 100)
            : 0;

        return {
            correct,
            total: questions.length,
            score
        };
    }

    function submitQuiz() {
        collectCurrentAnswer();

        const unanswered = state.quizAnswers.some(
            answer => answer === null
        );

        if (unanswered) {
            showConfirm(
                "فيه أسئلة بدون إجابة",
                "هل تريد تسليم الاختبار بالإجابات الحالية؟",
                () => {
                    finishQuiz();
                }
            );

            return;
        }

        finishQuiz();
    }

    function finishQuiz() {
        hideConfirm();

        const result = calculateScore();

        const trackId = state.quiz.trackId;
        const track = getTrack(trackId);

        const comprehensive = state.quiz.comprehensive;
        const lessonId = state.quiz.lessonId;

        if (!comprehensive && lessonId) {
            const attempts = student.lessonAttempts[lessonId] || 0;

            student.lessonAttempts[lessonId] = attempts + 1;

            student.latestScores[lessonId] = result.score;

            student.bestScores[lessonId] = Math.max(
                student.bestScores[lessonId] || 0,
                result.score
            );

            const passed = result.score >= DATA.settings.passingScore;

            if (passed) {
                const firstPass = !student.passedLessons.includes(lessonId);

                if (firstPass) {
                    student.passedLessons.push(lessonId);

                    student.points += DATA.settings.pointsPerQuiz;

                    awardBadge("first_pass");

                    if (result.score === 100) {
                        student.points += DATA.settings.pointsForPerfectScore;
                        awardBadge("perfect_score");
                    }
                } else if (result.score === 100) {
                    awardBadge("perfect_score");
                }

                if (!student.completedLessons.includes(lessonId)) {
                    student.completedLessons.push(lessonId);
                }
            }

            student.lastTrack = trackId;
            student.lastLesson = lessonId;

            updateTrackCompletion(track);

        } else if (comprehensive) {
            const passed =
                result.score >= DATA.settings.comprehensivePassingScore;

            if (passed) {
                if (!student.passedComprehensive.includes(trackId)) {
                    student.passedComprehensive.push(trackId);
                }

                updateTrackCompletion(track);
            }
        }

        saveStudent();

        state.quizResult = {
            ...result,
            trackId,
            lessonId,
            comprehensive,
            answers: [...state.quizAnswers],
            questions: [...state.quiz.questions]
        };

        state.quiz = null;
        state.page = "result";

        render();
    }

    function updateTrackCompletion(track) {
        if (!track) return;

        const allPassed = track.lessons.every(
            lesson => student.passedLessons.includes(lesson.id)
        );

        const comprehensivePassed =
            student.passedComprehensive.includes(track.id);

        if (allPassed && comprehensivePassed) {
            if (!student.completedTracks.includes(track.id)) {
                student.completedTracks.push(track.id);

                student.points += 50;

                awardBadge("first_track");

                toast(
                    "مبروك! أكملت المسار التعليمي 🎉"
                );
            }
        }
    }

    function awardBadge(badgeId) {
        if (!student.badges.includes(badgeId)) {
            student.badges.push(badgeId);
        }
    }

    function renderQuizResult() {
        const result = state.quizResult;

        if (!result) {
            state.page = "home";
            return renderHome();
        }

        const track = getTrack(result.trackId);

        const passed = result.score >= (
            result.comprehensive
                ? DATA.settings.comprehensivePassingScore
                : DATA.settings.passingScore
        );

        const perfect = result.score === 100;

        let title;
        let icon;

        if (perfect) {
            title = "درجة كاملة! إبداع يا بطل!";
            icon = "🏆";
        } else if (passed) {
            title = "مبروك! نجحت في الاختبار";
            icon = "🎉";
        } else {
            title = "لسه قدامك فرصة!";
            icon = "💪";
        }

        return `
            ${pageHeading(
                "نتيجة الاختبار",
                "راجع إجاباتك وتعرّف على النقاط التي تحتاج إلى مراجعتها."
            )}

            <div class="card">

                <div class="result-icon">${icon}</div>

                <h2 style="text-align:center;">
                    ${title}
                </h2>

                <div class="result-score">
                    ${result.score}%
                </div>

                <p style="text-align:center;">
                    إجابات صحيحة: ${result.correct} من ${result.total}
                </p>

                <p style="text-align:center;">
                    ${
                        passed
                            ? "تم اجتياز الاختبار بنجاح."
                            : "تحتاج إلى 60% على الأقل لاجتياز الاختبار."
                    }
                </p>

                <div class="button-row" style="justify-content:center;">

                    <button class="primary-btn"
                            data-action="result-retry"
                            data-track="${result.trackId}"
                            data-lesson="${result.lessonId || ""}"
                            data-comprehensive="${result.comprehensive}">

                        إعادة الاختبار

                    </button>

                    <button class="secondary-btn"
                            data-action="result-track"
                            data-track="${result.trackId}">

                        العودة للمسار

                    </button>

                    ${
                        result.lessonId && passed
                            ? `
                                <button class="primary-btn"
                                        data-action="result-next"
                                        data-track="${result.trackId}"
                                        data-lesson="${result.lessonId}">

                                    تابع للدرس التالي

                                </button>
                            `
                            : ""
                    }

                    ${
                        result.comprehensive && passed
                            ? `
                                <button class="primary-btn"
                                        data-action="open-certificate"
                                        data-track="${result.trackId}">

                                    عرض الشهادة

                                </button>
                            `
                            : ""
                    }

                </div>

            </div>

            <div class="section-heading">
                <h2>مراجعة الإجابات</h2>
            </div>

            ${result.questions.map((question, index) => {
                const selected = result.answers[index];

                const correct = selected === question.answer;

                return `
                    <div class="review-item">

                        <h3>
                            ${index + 1}. ${safeText(question.question)}
                        </h3>

                        <p class="${
                            correct ? "answer-good" : "answer-bad"
                        }">

                            إجابتك:
                            ${
                                selected === null
                                    ? "لم تجب عن السؤال"
                                    : safeText(question.options[selected])
                            }

                        </p>

                        <p class="answer-good">
                            الإجابة الصحيحة:
                            ${safeText(question.options[question.answer])}
                        </p>

                        <p>
                            التفسير:
                            ${safeText(question.explanation || "راجع الدرس لفهم الإجابة.")}
                        </p>

                    </div>
                `;
            }).join("")}
        `;
    }

    function renderComprehensive() {
        const track = getTrack(state.activeTrack);

        if (!track) return renderTracks();

        return `
            ${pageHeading(
                "الامتحان الشامل",
                "اختبر فهمك لمحتوى المسار بالكامل."
            )}

            <div class="card">

                <h2>${safeText(track.title)}</h2>

                <p>
                    يحتوي الامتحان على أسئلة من الدروس المتاحة
                    في هذا المسار.
                </p>

                <div class="notice">
                    النجاح من 60% مبدئيًا. يمكنك تعديل هذا الحد
                    من ملف data.js.
                </div>

                <div class="button-row">

                    <button class="primary-btn"
                            data-action="start-comprehensive"
                            data-track="${track.id}">

                        ابدأ الامتحان

                    </button>

                    <button class="secondary-btn"
                            data-action="open-track"
                            data-track="${track.id}">

                        العودة للدروس

                    </button>

                </div>

            </div>
        `;
    }

    function renderAchievements() {
        const allLessons = DATA.tracks.flatMap(
            track => track.lessons
        );

        const perfectCount = Object.values(
            student.bestScores
        ).filter(score => score === 100).length;

        const badges = [
            {
                id: "first_pass",
                icon: "📝",
                title: "أول نجاح",
                description: "اجتزت أول اختبار."
            },
            {
                id: "perfect_score",
                icon: "💯",
                title: "الدرجة الكاملة",
                description: "حققت 100% في اختبار."
            },
            {
                id: "first_track",
                icon: "🏆",
                title: "أول مسار",
                description: "أكملت مسارًا تعليميًا."
            }
        ];

        return `
            ${pageHeading(
                "الإنجازات",
                "كل خطوة ناجحة في رحلتك تستحق الاحتفال."
            )}

            <div class="grid grid-3">

                <div class="card stat-card">
                    <div class="stat-icon">💎</div>
                    <div class="stat-number">${student.points}</div>
                    <div class="stat-label">إجمالي النقاط</div>
                </div>

                <div class="card stat-card">
                    <div class="stat-icon">📚</div>
                    <div class="stat-number">${student.passedLessons.length}</div>
                    <div class="stat-label">اختبارات دروس مجتازة</div>
                </div>

                <div class="card stat-card">
                    <div class="stat-icon">💯</div>
                    <div class="stat-number">${perfectCount}</div>
                    <div class="stat-label">أفضل نتائج كاملة</div>
                </div>

            </div>

            <div class="section-heading">
                <h2>مستواك الحالي</h2>
            </div>

            <div class="card">
                <h3>المستوى ${getLevel()}</h3>
                <p>
                    استمر في التعلّم واجتياز الاختبارات
                    لجمع المزيد من النقاط.
                </p>

                ${progressBar(student.points % 100)}
                <div class="progress-meta">
                    <span>التقدم للمستوى التالي</span>
                    <strong>${student.points % 100} / 100</strong>
                </div>
            </div>

            <div class="section-heading">
                <h2>الشارات</h2>
            </div>

            <div class="badge-grid">

                ${badges.map(badge => {
                    const unlocked = student.badges.includes(badge.id);

                    return `
                        <div class="badge-card ${unlocked ? "" : "locked"}">

                            <div class="badge-icon">
                                ${unlocked ? badge.icon : "🔒"}
                            </div>

                            <h3>${safeText(badge.title)}</h3>

                            <p>${safeText(badge.description)}</p>

                        </div>
                    `;
                }).join("")}

            </div>

            <div class="section-heading">
                <h2>تقدم المسارات</h2>
            </div>

            <div class="grid grid-2">

                ${DATA.tracks.map(track => `
                    <div class="card">

                        <h3>${track.icon} ${safeText(track.title)}</h3>

                        ${progressBar(getTrackProgress(track))}

                        <p>
                            ${track.lessons.filter(
                                lesson => student.passedLessons.includes(lesson.id)
                            ).length}
                            من ${track.lessons.length} دروس.
                        </p>

                        <button class="secondary-btn"
                                data-action="open-track"
                                data-track="${track.id}">

                            عرض المسار

                        </button>

                        ${
                            student.completedTracks.includes(track.id)
                                ? `
                                    <button class="primary-btn"
                                            data-action="open-certificate"
                                            data-track="${track.id}">

                                        عرض الشهادة

                                    </button>
                                `
                                : ""
                        }

                    </div>
                `).join("")}

            </div>
        `;
    }

    function renderProjects() {
        return `
            ${pageHeading(
                "مشروعات البرمجة",
                "طبّق ما تتعلمه من خلال مشروعات عملية."
            )}

            <div class="notice">
                هذه نسخة أولية محلية. الإعلانات المكافئة لم يتم ربطها
                بخدمة إعلانية حقيقية بعد؛ لذلك لن ندّعي أنك شاهدت إعلانًا
                فعليًا. يمكنك استكشاف المشروعات المتاحة الآن.
            </div>

            <div class="section-heading">
                <h2>المشروعات</h2>
            </div>

            <div class="grid grid-2">

                ${DATA.projects.map(project => {
                    const track = getTrack(project.track);

                    const unlocked = student.projectUnlocks.includes(
                        project.id
                    );

                    return `
                        <div class="card project-card">

                            <div class="track-icon">
                                ${project.icon}
                            </div>

                            <h3>${safeText(project.title)}</h3>

                            <p>${safeText(project.description)}</p>

                            <div class="progress-meta">
                                <span>
                                    ${track ? safeText(track.title) : ""}
                                </span>

                                <span class="project-lock">
                                    ${unlocked ? "مفتوح" : "يحتاج فتح"}
                                </span>
                            </div>

                            <button class="primary-btn"
                                    data-action="open-project"
                                    data-project="${project.id}">

                                ${unlocked ? "افتح المشروع" : "استكشف المشروع"}

                            </button>

                        </div>
                    `;
                }).join("")}

            </div>
        `;
    }

    function openProject(projectId) {
        const project = DATA.projects.find(
            item => item.id === projectId
        );

        if (!project) {
            toast("المشروع غير موجود.", "error");
            return;
        }

        const unlocked = student.projectUnlocks.includes(project.id);

        if (!unlocked) {
            showConfirm(
                "فتح المشروع",
                "مشاهدة الإعلان المكافئ غير متاحة حتى ربط مزود الإعلانات. هل تريد فتح المشروع محليًا لأغراض الاختبار؟ لن يتم احتساب مشاهدة إعلان.",
                () => {
                    if (!student.projectUnlocks.includes(project.id)) {
                        student.projectUnlocks.push(project.id);
                        saveStudent();
                    }

                    hideConfirm();
                    renderProjectDetail(project);
                }
            );

            return;
        }

        renderProjectDetail(project);
    }

    function renderProjectDetail(project) {
        state.page = "project-detail";

        $("#pageTitle").textContent = project.title;

        $("#pageContent").innerHTML = `
            ${pageHeading(
                `${project.icon} ${safeText(project.title)}`,
                safeText(project.description)
            )}

            <div class="card">

                <h3>الكود الكامل</h3>

                <div class="code-card">

                    <div class="code-header">
                        <span>الكود</span>

                        <button data-action="copy-code"
                                data-code="${encodeURIComponent(project.code)}">

                            نسخ الكود 📋

                        </button>
                    </div>

                    <pre><code>${safeText(project.code)}</code></pre>

                </div>

                <div class="button-row">

                    <button class="secondary-btn"
                            data-action="open-projects">

                        العودة للمشروعات

                    </button>

                </div>

            </div>
        `;

        bindDynamicEvents();
    }

    function renderGuide() {
        return `
            ${pageHeading(
                "دليل الاستخدام",
                "كل ما تحتاج معرفته لاستخدام Codexa."
            )}

            <div class="grid">

                <div class="card">
                    <h3>1. البداية</h3>
                    <p>
                        اكتب اسمك عند فتح التطبيق أول مرة.
                        سيُستخدم الاسم لعرض التحية والشهادات التحفيزية.
                    </p>
                </div>

                <div class="card">
                    <h3>2. المسارات التعليمية</h3>
                    <p>
                        اختر أحد المسارات الأربعة.
                        يمكنك البدء بأي مسار تريده.
                    </p>
                </div>

                <div class="card">
                    <h3>3. الدروس</h3>
                    <p>
                        اقرأ الشرح وراجع الأكواد، واستخدم زر نسخ
                        الكود لتجربته في محرر البرمجة.
                    </p>
                </div>

                <div class="card">
                    <h3>4. الاختبارات</h3>
                    <p>
                        أجب عن الأسئلة، ويمكنك تعديل إجاباتك قبل التسليم.
                        النجاح يبدأ من 60% مبدئيًا.
                    </p>
                </div>

                <div class="card">
                    <h3>5. فتح الدروس</h3>
                    <p>
                        قراءة الدرس وحدها لا تفتح الدرس التالي.
                        يجب اجتياز اختبار الدرس الحالي.
                    </p>
                </div>

                <div class="card">
                    <h3>6. النقاط والإنجازات</h3>
                    <p>
                        تحصل على النقاط عند اجتياز الاختبارات.
                        وتوجد شارات للنجاح والنتائج الكاملة وإتمام المسار.
                    </p>
                </div>

                <div class="card">
                    <h3>7. الامتحان الشامل</h3>
                    <p>
                        بعد اجتياز اختبارات دروس المسار،
                        يمكنك دخول الامتحان الشامل.
                    </p>
                </div>

                <div class="card">
                    <h3>8. الشهادات التحفيزية</h3>
                    <p>
                        تتطلب الشهادة التحفيزية اجتياز جميع اختبارات المسار
                        والحصول على 100% في كل منها، واجتياز الامتحان الشامل.
                    </p>

                    <p>
                        الشهادة تحفيزية وليست اعتمادًا أكاديميًا أو مهنيًا.
                    </p>
                </div>

                <div class="card">
                    <h3>9. المشروعات</h3>
                    <p>
                        يمكنك الاطلاع على الأكواد وتجربتها.
                        فتح المشروعات محليًا في هذه النسخة لا يُعد مشاهدة إعلان.
                    </p>
                </div>

                <div class="card">
                    <h3>10. حفظ البيانات</h3>
                    <p>
                        يحفظ التطبيق التقدم محليًا على الجهاز.
                        قد يؤدي مسح بيانات التطبيق أو حذفها إلى فقدان التقدم.
                        لا توجد مزامنة سحابية في هذه النسخة.
                    </p>
                </div>

                <div class="card">
                    <h3>11. تقييم التطبيق</h3>
                    <p>
                        يمكنك تسجيل تقييمك محليًا.
                        لن يتم إرساله إلى المطوّر عبر الإنترنت في هذه النسخة.
                    </p>
                </div>

                <div class="card">
                    <h3>12. الأسئلة الشائعة</h3>

                    <p><strong>هل أحتاج إلى الإنترنت؟</strong></p>
                    <p>المحتوى الأساسي موجود محليًا في ملفات التطبيق.</p>

                    <p><strong>هل يمكنني إعادة الاختبار؟</strong></p>
                    <p>نعم، المحاولات غير محدودة.</p>

                    <p><strong>هل يمكنني تغيير اسمي؟</strong></p>
                    <p>نعم، من الإعدادات، دون مسح التقدم.</p>
                </div>

            </div>
        `;
    }

    function renderSettings() {
        return `
            ${pageHeading(
                "الإعدادات",
                "خصص تجربة التعلم بالطريقة التي تناسبك."
            )}

            <div class="card">

                <h3>الملف الشخصي</h3>

                <form id="nameForm">

                    <div class="form-group">
                        <label for="settingsName">اسم الطالب</label>

                        <input
                            id="settingsName"
                            maxlength="40"
                            value="${safeText(student.name)}"
                            required>
                    </div>

                    <button class="primary-btn" type="submit">
                        حفظ الاسم
                    </button>

                </form>

                <div class="setting-row">

                    <div>
                        <strong>المظهر</strong>
                        <p>التبديل بين الوضع الداكن والفاتح.</p>
                    </div>

                    <button class="secondary-btn"
                            data-action="toggle-theme">

                        ${student.theme === "dark" ? "الوضع الفاتح ☀" : "الوضع الداكن 🌙"}

                    </button>

                </div>

                <div class="setting-row">

                    <div>
                        <strong>إعادة تعيين مسار</strong>
                        <p>مسح التقدم والنتائج في مسار محدد.</p>
                    </div>

                    <select id="resetTrackSelect"
                            aria-label="اختر مسارًا لإعادة تعيينه">

                        <option value="">اختر مسارًا</option>

                        ${DATA.tracks.map(track => `
                            <option value="${track.id}">
                                ${safeText(track.title)}
                            </option>
                        `).join("")}

                    </select>

                </div>

                <div class="button-row">

                    <button class="danger-btn"
                            data-action="reset-track">

                        إعادة تعيين المسار المحدد

                    </button>

                    <button class="danger-btn"
                            data-action="reset-all">

                        إعادة تعيين كل التقدم

                    </button>

                </div>

                <div class="notice" style="margin-top:20px;">
                    إعادة التعيين لا يمكن التراجع عنها.
                    احتفظ بنسخة من بياناتك إن كانت مهمة.
                </div>

            </div>
        `;
    }

    function renderFeedback() {
        return `
            ${pageHeading(
                "رأيك يهمنا",
                "ساعدنا في معرفة ما يعجبك وما يحتاج إلى تحسين."
            )}

            <div class="card">

                <div class="notice">
                    هذا النموذج يحفظ التقييم على جهازك فقط.
                    لا يوجد إرسال إلى خادم أو مطوّر في هذه النسخة.
                </div>

                <form id="feedbackForm">

                    <div class="form-group">
                        <label for="feedbackRating">
                            تقييمك للتطبيق
                        </label>

                        <select id="feedbackRating" required>
                            <option value="">اختر التقييم</option>
                            <option value="5">⭐⭐⭐⭐⭐ ممتاز</option>
                            <option value="4">⭐⭐⭐⭐ جيد جدًا</option>
                            <option value="3">⭐⭐⭐ جيد</option>
                            <option value="2">⭐⭐ يحتاج تحسينًا</option>
                            <option value="1">⭐ ضعيف</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="feedbackType">
                            نوع الملاحظة
                        </label>

                        <select id="feedbackType">
                            <option value="suggestion">اقتراح ميزة</option>
                            <option value="problem">الإبلاغ عن مشكلة</option>
                            <option value="general">رأي عام</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="feedbackMessage">
                            تعليقك (اختياري)
                        </label>

                        <textarea
                            id="feedbackMessage"
                            maxlength="1000"
                            placeholder="اكتب رأيك أو اقتراحك هنا..."></textarea>
                    </div>

                    <button class="primary-btn" type="submit">
                        حفظ التقييم على الجهاز
                    </button>

                </form>

                <div class="section-heading">
                    <h2>تقييماتي المحفوظة</h2>
                </div>

                ${
                    student.feedback.length
                        ? student.feedback.slice().reverse().map(item => `
                            <div class="review-item">

                                <strong>
                                    ${"⭐".repeat(item.rating)}
                                </strong>

                                <p>${safeText(item.message || "بدون تعليق")}</p>

                                <small>
                                    ${safeText(item.type)}
                                    • ${safeText(item.date)}
                                </small>

                            </div>
                        `).join("")
                        : `<p>لم تحفظ أي تقييم بعد.</p>`
                }

            </div>
        `;
    }

    function canEarnCertificate(track) {
        const allPerfect = track.lessons.every(lesson =>
            student.bestScores[lesson.id] === 100
        );

        const comprehensivePassed =
            student.passedComprehensive.includes(track.id);

        return allPerfect && comprehensivePassed;
    }

    function renderCertificate() {
        const track = getTrack(state.certificateTrack);

        if (!track) {
            state.page = "achievements";
            return renderAchievements();
        }

        if (!canEarnCertificate(track)) {
            return `
                ${pageHeading(
                    "الشهادة التحفيزية",
                    "أكمل متطلبات الشهادة أولًا."
                )}

                <div class="card">

                    <h3>متطلبات الشهادة</h3>

                    <p>
                        يجب تحقيق 100% في أفضل نتيجة لكل اختبار درس،
                        ثم اجتياز الامتحان الشامل.
                    </p>

                    <ul>
                        ${track.lessons.map(lesson => `
                            <li>
                                ${safeText(lesson.title)}:
                                ${
                                    student.bestScores[lesson.id] === 100
                                        ? "✓ 100%"
                                        : "لم تتحقق الدرجة الكاملة بعد"
                                }
                            </li>
                        `).join("")}

                        <li>
                            الامتحان الشامل:
                            ${
                                student.passedComprehensive.includes(track.id)
                                    ? "✓ تم اجتيازه"
                                    : "لم يتم اجتيازه"
                            }
                        </li>
                    </ul>

                    <button class="secondary-btn"
                            data-action="open-track"
                            data-track="${track.id}">

                        العودة للمسار

                    </button>

                </div>
            `;
        }

        const date = new Date().toLocaleDateString("ar-EG");

        return `
            ${pageHeading(
                "شهادتك التحفيزية",
                "مبروك على إتمام متطلبات المسار!"
            )}

            <div class="certificate" id="certificatePrint">

                <div class="brand-logo"
                     style="margin:0 auto 15px;">

                    C<span>;</span>

                </div>

                <p>CODEXA • شهادة تحفيزية</p>

                <h1>شهادة إتمام مسار</h1>

                <p>تُمنح هذه الشهادة إلى</p>

                <div class="certificate-name">
                    ${safeText(student.name)}
                </div>

                <p>لإتمام متطلبات مسار</p>

                <h2>${safeText(track.title)}</h2>

                <p>
                    بعد الحصول على 100% في أفضل نتيجة لكل اختبارات الدروس،
                    واجتياز الامتحان الشامل.
                </p>

                <p>تاريخ الإصدار: ${safeText(date)}</p>

                <hr>

                <p>
                    شهادة تحفيزية غير معتمدة أكاديميًا أو مهنيًا.
                </p>

            </div>

            <div class="button-row"
                 style="justify-content:center;">

                <button class="primary-btn"
                        data-action="print-certificate">

                    طباعة الشهادة / حفظ PDF

                </button>

                <button class="secondary-btn"
                        data-action="open-track"
                        data-track="${track.id}">

                    العودة للمسار

                </button>

            </div>

            <div class="notice">
                يمكن استخدام نافذة الطباعة في المتصفح لاختيار
                الطباعة أو الحفظ بصيغة PDF. حفظ صورة PNG مباشرة
                غير مضاف في هذه النسخة.
            </div>
        `;
    }

    function markLessonCompleted(trackId, lessonId) {
        const track = getTrack(trackId);
        const lesson = getLesson(trackId, lessonId);

        if (!track || !lesson) return;

        if (!student.completedLessons.includes(lessonId)) {
            student.completedLessons.push(lessonId);
        }

        student.lastTrack = trackId;
        student.lastLesson = lessonId;

        saveStudent();

        toast(
            "تم تسجيل إكمال الدرس. اجتز الاختبار لفتح الدرس التالي."
        );

        render();
    }

    function resetTrack(trackId) {
        const track = getTrack(trackId);

        if (!track) {
            toast("اختر مسارًا صحيحًا أولًا.", "error");
            return;
        }

        showConfirm(
            "إعادة تعيين المسار",
            `سيتم مسح تقدمك ونتائجك في ${track.title}. هل أنت متأكد؟`,
            () => {
                const lessonIds = track.lessons.map(
                    lesson => lesson.id
                );

                student.completedLessons =
                    student.completedLessons.filter(
                        id => !lessonIds.includes(id)
                    );

                student.passedLessons =
                    student.passedLessons.filter(
                        id => !lessonIds.includes(id)
                    );

                lessonIds.forEach(id => {
                    delete student.lessonAttempts[id];
                    delete student.latestScores[id];
                    delete student.bestScores[id];
                });

                student.completedTracks =
                    student.completedTracks.filter(
                        id => id !== trackId
                    );

                student.passedComprehensive =
                    student.passedComprehensive.filter(
                        id => id !== trackId
                    );

                if (student.lastTrack === trackId) {
                    student.lastTrack = null;
                    student.lastLesson = null;
                }

                /*
                النقاط والشارات الإجمالية محفوظة هنا
                لأنها لا ترتبط بمصدر محدد في النسخة الحالية.
                */

                saveStudent();
                hideConfirm();

                toast("تمت إعادة تعيين المسار.");
                navigate("tracks");
            }
        );
    }

    function resetAll() {
        showConfirm(
            "إعادة تعيين كل التقدم",
            "سيتم مسح الاسم والنتائج والنقاط والشارات والتقييمات المحلية. هل تريد المتابعة؟",
            () => {
                try {
                    localStorage.removeItem(STORAGE_KEY);
                } catch (error) {
                    console.error(error);
                }

                student = defaultStudent();

                state.page = "home";
                state.activeTrack = null;
                state.activeLesson = null;
                state.quiz = null;
                state.quizResult = null;

                hideConfirm();

                render();

                toast("تمت إعادة تعيين البيانات.");
            }
        );
    }

    function renderTrack(trackId) {
        const track = getTrack(trackId);

        if (!track) {
            toast("المسار غير موجود.", "error");
            navigate("tracks");
            return;
        }

        state.activeTrack = trackId;
        state.page = "track-detail";

        $("#pageTitle").textContent = track.title;

        $("#pageContent").innerHTML = renderTrackDetail(track);

        bindDynamicEvents();
        setActiveNavigation();
    }

    function openLesson(trackId, lessonId) {
        const track = getTrack(trackId);

        if (!track) return;

        const index = track.lessons.findIndex(
            lesson => lesson.id === lessonId
        );

        if (index < 0) return;

        if (!isLessonUnlocked(track, index)) {
            toast("اجتز اختبار الدرس السابق أولًا.", "error");
            return;
        }

        state.activeTrack = trackId;
        state.activeLesson = lessonId;

        student.lastTrack = trackId;
        student.lastLesson = lessonId;

        saveStudent();

        navigate("lesson");
    }

    function moveLesson(direction) {
        const track = getTrack(state.activeTrack);

        if (!track) return;

        const index = track.lessons.findIndex(
            lesson => lesson.id === state.activeLesson
        );

        const nextIndex = index + direction;

        if (nextIndex < 0 || nextIndex >= track.lessons.length) {
            return;
        }

        const nextLesson = track.lessons[nextIndex];

        if (!isLessonUnlocked(track, nextIndex)) {
            toast("اجتز اختبار الدرس السابق لفتح هذا الدرس.", "error");
            return;
        }

        openLesson(track.id, nextLesson.id);
    }

    function openCertificate(trackId) {
        state.certificateTrack = trackId;
        navigate("certificate");
    }

    async function copyCode(encodedCode) {
        let code;

        try {
            code = decodeURIComponent(encodedCode);
        } catch (error) {
            toast("تعذر قراءة الكود.", "error");
            return;
        }

        try {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText(code);
            } else {
                const textarea = document.createElement("textarea");

                textarea.value = code;

                document.body.appendChild(textarea);

                textarea.select();

                const success = document.execCommand("copy");

                textarea.remove();

                if (!success) {
                    throw new Error("Copy failed");
                }
            }

            toast("تم نسخ الكود بنجاح 📋");

        } catch (error) {
            console.error(error);
            toast("تعذر النسخ. اضغط مطولًا على الكود وانسخه يدويًا.", "error");
        }
    }

    function bindDynamicEvents() {
        $$("[data-action]").forEach(button => {
            button.addEventListener("click", () => {
                handleAction(button);
            });
        });

        $$(".quiz-option").forEach(option => {
            option.addEventListener("click", () => {
                setTimeout(() => {
                    collectCurrentAnswer();

                    $$(".quiz-option").forEach(item => {
                        item.classList.remove("selected");
                    });

                    option.classList.add("selected");
                }, 0);
            });
        });

        const nameForm = $("#nameForm");

        if (nameForm) {
            nameForm.addEventListener("submit", event => {
                event.preventDefault();

                const newName = $("#settingsName").value.trim();

                if (!newName) {
                    toast("اكتب اسمًا صحيحًا.", "error");
                    return;
                }

                student.name = newName.slice(0, 40);

                saveStudent();

                toast("تم حفظ الاسم.");
                render();
            });
        }

        const feedbackForm = $("#feedbackForm");

        if (feedbackForm) {
            feedbackForm.addEventListener("submit", event => {
                event.preventDefault();

                const rating = Number($("#feedbackRating").value);

                if (rating < 1 || rating > 5) {
                    toast("اختر تقييمًا من 1 إلى 5.", "error");
                    return;
                }

                student.feedback.push({
                    rating,
                    type: $("#feedbackType").value,
                    message: $("#feedbackMessage").value.trim(),
                    date: new Date().toLocaleDateString("ar-EG")
                });

                saveStudent();

                toast("تم حفظ التقييم على جهازك.");
                render();
            });
        }
    }

    function handleAction(button) {
        const action = button.dataset.action;

        switch (action) {

            case "open-tracks":
                navigate("tracks");
                break;

            case "open-achievements":
                navigate("achievements");
                break;

            case "open-projects":
                navigate("projects");
                break;

            case "open-track":
                renderTrack(button.dataset.track);
                break;

            case "open-lesson":
                openLesson(
                    button.dataset.track,
                    button.dataset.lesson
                );
                break;

            case "continue-learning": {
                const lesson = getCurrentLesson();

                if (lesson && student.lastTrack) {
                    openLesson(student.lastTrack, lesson.id);
                } else {
                    navigate("tracks");
                }

                break;
            }

            case "mark-completed":
                markLessonCompleted(
                    button.dataset.track,
                    button.dataset.lesson
                );
                break;

            case "start-quiz":
                startQuiz(
                    button.dataset.track,
                    button.dataset.lesson,
                    false
                );
                break;

            case "lesson-previous":
                moveLesson(-1);
                break;

            case "lesson-next":
                moveLesson(1);
                break;

            case "quiz-previous":
                collectCurrentAnswer();

                if (state.quizIndex > 0) {
                    state.quizIndex--;
                    render();
                }

                break;

            case "quiz-next":
                collectCurrentAnswer();

                if (state.quizIndex < state.quiz.questions.length - 1) {
                    state.quizIndex++;
                    render();
                }

                break;

            case "quiz-submit":
                submitQuiz();
                break;

            case "quiz-cancel":
                showConfirm(
                    "الخروج من الاختبار",
                    "هل تريد الخروج؟ لن تُحفظ هذه المحاولة كاختبار مُسلّم.",
                    () => {
                        hideConfirm();

                        state.quiz = null;

                        if (state.activeTrack) {
                            renderTrack(state.activeTrack);
                        } else {
                            navigate("tracks");
                        }
                    }
                );

                break;

            case "result-retry":
                startQuiz(
                    button.dataset.track,
                    button.dataset.lesson || null,
                    button.dataset.comprehensive === "true"
                );
                break;

            case "result-track":
                renderTrack(button.dataset.track);
                break;

            case "result-next": {
                const track = getTrack(button.dataset.track);

                if (!track) break;

                const index = track.lessons.findIndex(
                    lesson => lesson.id === button.dataset.lesson
                );

                if (index >= 0 && index < track.lessons.length - 1) {
                    openLesson(
                        track.id,
                        track.lessons[index + 1].id
                    );
                } else {
                    renderTrack(track.id);
                }

                break;
            }

            case "start-comprehensive": {
                const trackId = button.dataset.track;

                state.activeTrack = trackId;

                startQuiz(trackId, null, true);

                break;
            }

            case "open-certificate":
                openCertificate(button.dataset.track);
                break;

            case "print-certificate":
                window.print();
                break;

            case "copy-code":
                copyCode(button.dataset.code);
                break;

            case "toggle-theme":
                student.theme = student.theme === "dark"
                    ? "light" : "dark";

                saveStudent();
                render();

                break;

            case "reset-track": {
                const select = $("#resetTrackSelect");

                if (!select || !select.value) {
                    toast("اختر المسار الذي تريد إعادة تعيينه.", "error");
                    break;
                }

                resetTrack(select.value);

                break;
            }

            case "reset-all":
                resetAll();
                break;

            case "open-project":
                openProject(button.dataset.project);
                break;

            default:
                console.warn("Unknown action:", action);
        }
    }

    function bindStaticEvents() {
        $("#welcomeForm").addEventListener("submit", event => {
            event.preventDefault();

            const name = $("#studentName").value.trim();

            if (!name) {
                toast("اكتب اسمك أولًا.", "error");
                return;
            }

            student.name = name.slice(0, 40);

            saveStudent();

            navigate("home");
        });

        $$(".nav-item").forEach(button => {
            button.addEventListener("click", () => {
                navigate(button.dataset.page);
            });
        });

        $("#menuToggle").addEventListener("click", openSidebar);

        $("#closeSidebar").addEventListener("click", closeSidebar);

        $("#sidebarOverlay").addEventListener("click", closeSidebar);

        $("#themeToggle").addEventListener("click", () => {
            student.theme = student.theme === "dark"
                ? "light" : "dark";

            saveStudent();
            render();
        });

        $("#confirmCancel").addEventListener("click", hideConfirm);

        $("#confirmAccept").addEventListener("click", () => {
            const action = state.confirmAction;

            if (typeof action === "function") {
                action();
            } else {
                hideConfirm();
            }
        });
    }

    function startApp() {
        bindStaticEvents();

        syncProfile();

        if (!student.name) {
            $("#welcomeScreen").classList.remove("hidden");
            $("#app").classList.add("hidden");
        } else {
            $("#welcomeScreen").classList.add("hidden");
            $("#app").classList.remove("hidden");
        }

        render();
    }

    /*
    ========================================
    INIT
    ========================================
    */

    startApp();

})();