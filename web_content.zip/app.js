/* Jesma Novels Platform Prototype v0.5 */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const STORE = "jesma_platform_v05";
const COLORS = [
  ["#254b3d","#e7d8b8"],["#6e3f3d","#f0d9b7"],["#243d59","#e9d7ad"],
  ["#9b7545","#fff0d2"],["#3c5147","#e8e0ca"],["#553b54","#f1dce2"],
  ["#2d4a3e","#dce8d8"],["#4a3b2f","#f2e6d4"]
];

/* ---------- Seed content (expanded) ---------- */
const seedWorks = [
  {id:"s1",title:"The Baobab Keeps Secrets",author:"Tariro Moyo",type:"Short story",language:"English",time:"5–10 min",tags:["Home","Memory","Family"],description:"In a village where every family leaves a message inside an ancient baobab, a young girl discovers a secret that changes how she understands home.",body:`The oldest baobab in Mbare had a hollow wide enough for three children to hide in. Its bark was folded like the palm of a hand, and its branches held the sky as if the sky had once been a gift.\n\nEvery year, on the first morning of the rains, families came to leave a message inside the tree. Some wrote names. Some wrote apologies. Others wrote the wishes they were too shy to say aloud.\n\nTendai had never left one. She was twelve, and she believed secrets were things that made people smaller.\n\nThat morning she found a folded paper tucked behind a root. The handwriting belonged to her grandmother, who had been gone for six rainy seasons.\n\nIt said: “When you are old enough to ask why I stayed, ask the tree what I was waiting for.”\n\nTendai read the sentence twice. Then she pressed her palm against the rough bark. The tree was warm from the early sun.\n\nFor the first time, she understood that a secret was not always a locked door. Sometimes it was a seed waiting for the right season.\n\nShe placed her own message beside her grandmother’s: “I am here. I am listening.”`,featured:true,likes:48,premium:false,created:1,license:"CC BY 4.0",comments:[{author:"Nia Okonkwo",text:"The last line stayed with me."}]},
  {id:"s2",title:"Where the Rain Begins",author:"Amara Dlamini",type:"Poetry",language:"English",time:"2–5 min",tags:["Land","Beginnings"],description:"A poem about memory, dry earth and the quiet courage of beginning again.",body:`Before the rain, the earth remembers.\nIt holds the shape of every footstep,\nevery seed that waited,\nevery name spoken softly at dusk.\n\nThen one cloud opens its hands.\nThe dust becomes a garden,\nthe road becomes a mirror,\nand even the smallest roof\nlearns the music of return.\n\nI used to think beginnings were loud.\nNow I know:\nsometimes a beginning\nis only one drop\nfinding the ground.`,featured:true,likes:36,premium:false,created:2,license:"CC BY 4.0",comments:[]},
  {id:"s3",title:"The Last Bus to Bulawayo",author:"Kuda Ncube",type:"Short story",language:"English",time:"5–10 min",tags:["Migration","Memory"],description:"Two strangers share a late-night journey and discover they are carrying the same unfinished goodbye.",body:`The bus was late by forty minutes and smelled of raincoats, warm bread and old vinyl seats. At the station, the departure board blinked as if it too were tired.\n\nMusa sat beside the window with a paper bag on his knees. Inside it was a blue cup wrapped in newspaper. He had carried it from one rented room to another for eleven years.\n\nThe woman who took the seat beside him carried no luggage. Only a small notebook and a pen with a cracked lid.\n\n“Going home?” she asked.\n\n“I think so,” Musa said. “You?”\n\nShe looked at the notebook. “Going to find out what home means now.”\n\nThe bus pulled away. Outside, the city folded itself into streetlights and wet pavements. They spoke about ordinary things first: the price of tomatoes, the stubbornness of old phones, the strange comfort of familiar roads.\n\nAt the first stop, Musa opened the paper bag. The cup had belonged to his sister. He had promised to return it after an argument. She had died before he could.\n\nThe woman closed her notebook. “I have a letter I never sent,” she said.\n\nNeither offered advice. The bus carried them through the dark, and for a while that was enough.\n\nWhen the dawn appeared, Musa knew he could not return the cup to his sister. But he could take it to her daughter. The woman began writing again. This time, she wrote an address.`,featured:true,likes:29,premium:false,created:3,license:"CC BY 4.0",comments:[]},
  {id:"s4",title:"Letters from the Dust Road",author:"Lindiwe Khumalo",type:"Essay",language:"English",time:"10–20 min",tags:["Land","History","Resilience"],description:"Reflections on walking the same red roads that carried generations of stories, labour and quiet defiance.",body:`There is a particular red that only appears after the first rains. It is not the colour of blood or of rust. It is the colour of patience.\n\nI walked that road as a child, then as a student, then as someone who had left and returned with different shoes. Each time the dust rose in the same way. Each time the old women under the jacarandas watched with the same measured kindness.\n\nWe speak often of resilience as if it were a performance. On the dust road it is quieter. It is the decision to plant again after a failed season. It is the decision to teach a child a language that schools once punished. It is the decision to keep a name that the world tried to shorten.\n\nI do not romanticise hardship. Hardship is not a teacher I would choose. But the people who walked this road before me turned hardship into a grammar of survival. They left us sentences we are still learning to finish.\n\nWhen I write, I try to listen for those sentences. Not to claim them, but to keep them company.`,featured:true,likes:41,premium:false,created:4,license:"CC BY 4.0",comments:[]},
  {id:"s5",title:"The Woman Who Spoke to Rivers",author:"Thandiwe Ndlovu",type:"Folklore",language:"English",time:"5–10 min",tags:["Folklore","Land","Women"],description:"A retelling of a southern African tale about a woman whose words could change the course of water — and of community.",body:`In the time when the hills still answered questions, there lived a woman named Nomsa whose voice could persuade rivers.\n\nShe did not shout. She spoke the way evening speaks to the day: with certainty and without hurry.\n\nWhen the drought lasted longer than the elders’ memories, the people asked her to speak to the dry riverbed. She walked barefoot into the cracked earth and said only three things.\n\nFirst: “We remember you.”\nSecond: “We have not forgotten how to wait.”\nThird: “When you return, we will still be here.”\n\nThe river did not rise that night. It rose the following season, slowly, as if testing the sincerity of the promise.\n\nFrom then on, whenever the community faced a decision that threatened to divide them, someone would say, “Speak as Nomsa spoke to the river.” Meaning: tell the truth, make no false promises, and leave room for return.`,featured:false,likes:27,premium:false,created:5,license:"CC BY 4.0",comments:[]},
  {id:"s6",title:"Night Market, Maputo",author:"José Massingue",type:"Short story",language:"English",time:"5–10 min",tags:["City","Migration"],description:"A young man sells phone credit under fluorescent lights and learns that every city keeps two versions of every person.",body:`The night market smelled of grilled prawns, diesel and the sweet smoke of roasting maize. Fluorescent tubes hummed above the stalls like tired insects.\n\nCarlos sold airtime. He knew the numbers people dialled most often: the ones that began with a pause, as if the caller were still deciding whether the conversation was worth the cost.\n\nA woman in a yellow headscarf bought credit every Thursday. She never called from the stall. She walked to the edge of the light and dialled with her back turned.\n\nOne evening the line went dead in the middle of her conversation. She returned, paid again, and said quietly, “He is in Johannesburg. He says the rain there is different.”\n\nCarlos wanted to ask how rain could be different. Instead he said, “The signal is stronger near the corner.”\n\nShe smiled the way people smile when they have already decided not to explain.\n\nLater, when the market packed away its lights, Carlos walked home past the closed windows of the city. He thought about the two versions of every person: the one who stays and the one who leaves. Both of them, he realised, keep buying credit for the same reason.`,featured:false,likes:22,premium:false,created:6,license:"CC BY 4.0",comments:[]},
  {id:"s7",title:"A Grammar of Hands",author:"Fatima El-Amin",type:"Poetry",language:"English",time:"2–5 min",tags:["Family","Memory","Women"],description:"A poem about the languages mothers teach without speaking.",body:`My mother’s hands spoke three languages\nbefore I learned one.\n\nThey spoke the language of dough,\nof folding and waiting and heat.\n\nThey spoke the language of fabric,\nof mending what the day had torn.\n\nThey spoke the language of absence —\nhow to hold a space open\nlong enough for someone to return.\n\nI write with the same hands now.\nThey still pause mid-sentence\nas if listening for a door.`,featured:true,likes:52,premium:false,created:7,license:"CC BY 4.0",comments:[]},
  {id:"s8",title:"The Quiet Season",author:"Sipho Maseko",type:"Reflection",language:"English",time:"5–10 min",tags:["Resilience","Care"],description:"On learning to sit with silence after years of noise, and discovering that rest can be a form of resistance.",body:`For a long time I believed productivity was the only proof that I was still here. If I was not producing, I was disappearing.\n\nThen came a season when the body simply refused. Not dramatically. Quietly. Like a door that would not open no matter how many times you turned the key.\n\nI learned that silence is not empty. It is full of the things we postponed: grief that never received a proper ceremony, questions we were too busy to ask, the small joys we treated as optional.\n\nRest, I discovered, is not the opposite of work. In a world that profits from exhaustion, rest can be a deliberate act of refusal.\n\nI do not have a neat ending. The quiet season is still teaching me. Some mornings I still reach for the old urgency. Some evenings I manage to sit without an agenda and feel, briefly, that this too is a form of presence.`,featured:false,likes:34,premium:false,created:8,license:"CC BY 4.0",comments:[]},
  {id:"s9",title:"Border Song",author:"Amina Diallo",type:"Poetry",language:"English",time:"2–5 min",tags:["Migration","Belonging","Language"],description:"A poem for those who carry more than one country in their mouths.",body:`I keep two passports in different pockets\nand a third language under my tongue\nfor emergencies.\n\nAt the border they ask where I am from.\nI answer with the name of a river\nthat does not appear on their maps.\n\nThey stamp a page.\nI stamp the air with the sound\nof my grandmother’s kitchen.\n\nHome is not a single coordinate.\nIt is the accumulation of all the places\nthat still answer when I call.`,featured:false,likes:31,premium:false,created:9,license:"CC BY 4.0",comments:[]},
  {id:"s10",title:"The Market of Lost Things",author:"Chinedu Okoro",type:"Short story",language:"English",time:"10–20 min",tags:["City","Memory","Magic realism"],description:"In a Lagos market that appears only at dawn, people come to recover what they thought they had permanently lost.",body:`The market opened at first light and closed before the first minibus horn. It sold only things that had been lost: keys, photographs, the exact wording of an apology, the courage to make a phone call.\n\nAdaora found it by accident. She had been looking for a different kind of market and took a wrong turn near the lagoon. An old man sat on a stool with a ledger.\n\n“What did you lose?” he asked.\n\n“Time,” she said, half joking.\n\nHe shook his head. “We do not stock time. Only what time took from you.”\n\nShe thought of her father’s voice. He had died while she was abroad, and the recordings on her phone had been deleted by a software update. She said the name.\n\nThe old man wrote something in the ledger and pointed to a stall covered in blue cloth. Inside, on a low table, lay a small cassette tape with her father’s handwriting on the label.\n\nShe paid with a memory she no longer needed — the face of a classmate she would never meet again. The trade felt fair.\n\nWhen she left the market, the street looked ordinary. The tape, however, remained in her bag. That evening she found an old player and pressed play. Her father’s voice filled the room, slightly distorted by age, still unmistakable.\n\nHe was telling a story she had heard a hundred times. For the first time, she listened without interrupting.`,featured:true,likes:61,premium:true,created:10,license:"CC BY 4.0",comments:[]},
  {id:"s11",title:"Harvest Instructions",author:"Nomvula Dube",type:"Poetry",language:"English",time:"2–5 min",tags:["Land","Family"],description:"A sequence of short poems that read like advice from an elder.",body:`1.\nDo not plant only what the market wants.\nPlant also what your grandmother would recognise.\n\n2.\nWhen the soil is tired, rest it.\nA field that never sleeps\nforgets how to dream.\n\n3.\nShare the first fruits\nwith the people who helped you dig.\nMemory is a better currency than praise.\n\n4.\nIf the rain does not come,\nstill prepare the ground.\nHope is a kind of ploughing.\n\n5.\nTeach the children the names of the weeds.\nSome of them are medicine.\nSome of them are only waiting\nto become flowers.`,featured:false,likes:19,premium:false,created:11,license:"CC BY 4.0",comments:[]},
  {id:"s12",title:"The Translator’s Daughter",author:"Zahra Hassan",type:"Short story",language:"English",time:"10–20 min",tags:["Language","Family","Identity"],description:"A young woman inherits her father’s notebooks and discovers the private translations he never published.",body:`The notebooks were stacked in a cardboard box labelled, in her father’s careful English, “Not for archive.”\n\nLeila opened the first one on a rainy Tuesday. Inside were translations of poems that had never appeared in any of his official volumes. Love poems. Angry poems. Poems that addressed the country by its older names.\n\nIn the margins he had written notes to himself in a mix of Arabic, English and a private shorthand. One note read: “This line cannot survive the crossing. Leave it on the other shore.”\n\nShe realised that translation, for him, had never been only about moving meaning from one language to another. It had been about deciding what could be carried and what had to be mourned.\n\nShe began typing the unpublished work. Not to publish it immediately, but to keep it from disappearing a second time. Each evening she read one poem aloud, testing the sound of her father’s choices in a room he had never entered.\n\nOn the final page of the last notebook he had written a single sentence: “If you find these, remember that every translation is also a letter home.”`,featured:false,likes:28,premium:true,created:12,license:"CC BY 4.0",comments:[]},
  {id:"s13",title:"Under the Mopane",author:"Boitumelo Molefe",type:"Folklore",language:"English",time:"5–10 min",tags:["Folklore","Wisdom"],description:"A tale from the dry lands about a tortoise who outwits the drought by listening more carefully than the other animals.",body:`When the waterholes shrank to the size of cooking pots, the animals gathered under the great mopane tree to argue about who should dig for the underground spring.\n\nThe elephant claimed strength. The lion claimed authority. The hare claimed cleverness. The tortoise said nothing.\n\nAfter the louder animals had exhausted themselves with plans that required tools they did not have, the tortoise walked to the edge of the shade and pressed an ear to the ground.\n\n“The water is speaking,” she said. “It is not under the place you are looking. It is under the place you have been standing while you argued.”\n\nThey dug where she indicated. The water rose slowly, clear and cold. The animals drank in turn, the largest first, as custom required. When it was the tortoise’s turn, there was still enough.\n\nFrom that day the younger animals were told: before you raise your voice, lower your ear.`,featured:false,likes:24,premium:false,created:13,license:"CC BY 4.0",comments:[]},
  {id:"s14",title:"City of Half-Remembered Names",author:"Kwame Asante",type:"Essay",language:"English",time:"10–20 min",tags:["City","History","Memory"],description:"An essay on the streets that keep changing names and the people who refuse to forget the older ones.",body:`Every city in this region has a second map that lives only in speech. Official signs change with governments. The mouths of residents change more slowly.\n\nI grew up on a street that had three names in living memory. My grandmother used the first. My mother used the second. The municipality insisted on the third. When I give directions, I still use all three, depending on the age of the person I am speaking to.\n\nThis is not mere nostalgia. It is a form of continuity. To remember an older name is to insist that the people who lived under it were not erased by the new plaque.\n\nAt the same time, new names can be acts of justice. The difficulty is knowing which renamings enlarge the story and which ones try to replace it.\n\nI walk the city listening for both maps. One is printed. The other is carried. The second is harder to confiscate.`,featured:false,likes:18,premium:false,created:14,license:"CC BY 4.0",comments:[]},
  {id:"s15",title:"The Weight of Small Kindnesses",author:"Esi Mensah",type:"Reflection",language:"English",time:"5–10 min",tags:["Community","Care"],description:"On the ordinary gestures that hold communities together when larger systems fail.",body:`I used to wait for grand gestures of solidarity. Then I began to notice the smaller ones.\n\nThe neighbour who brings extra soup without announcing a philosophy. The stranger who stands slightly closer on the bus when someone is being harassed. The colleague who covers a shift without turning it into a debt.\n\nThese acts do not trend. They do not fit easily into slogans. They are, however, the infrastructure of survival for many people.\n\nI am not arguing against organised politics. I am arguing that politics without this quieter layer becomes brittle. The small kindnesses keep the ground soft enough for larger changes to take root.\n\nWhen I write about community now, I try to include the unspectacular. The spectacular will find its own historians. The rest of us are busy keeping each other upright.`,featured:false,likes:33,premium:false,created:15,license:"CC BY 4.0",comments:[]},
  {id:"ser1",title:"The House of Returning — Chapter 1",author:"Naledi Molefe",type:"Serial",language:"English",time:"10–20 min",tags:["Family","Home","Secrets"],description:"First chapter of a serial novel. A woman returns to the family house after fifteen years and finds that the walls have been keeping careful records.",body:`Chapter 1 — The Key That Still Fit\n\nThe key still turned. That was the first surprise.\n\nThandi had expected resistance: a changed lock, a new tenant, at least a stiff mechanism after fifteen years of disuse. Instead the door opened with the same soft complaint it had always made in winter.\n\nInside, the air smelled of floor polish and closed rooms. Someone had been maintaining the place. The furniture stood where it had always stood, only more carefully dusted.\n\nOn the kitchen table lay a single envelope with her name written in her mother’s hand. The paper was recent. The handwriting was not.\n\nShe did not open it immediately. She walked through each room the way a person walks through a museum of their own childhood: slowly, checking that the exhibits had not been rearranged.\n\nIn the back bedroom the wardrobe still held her father’s coats. In the sitting room the radio still worked. When she switched it on, a station she did not recognise was playing a song she did.\n\nOnly then did she return to the envelope. Inside was a short note and a second key.\n\n“The house has been waiting,” the note said. “There are things in the loft that belong to you now. Start with the blue trunk. Do not rush. The house prefers patience.”\n\nThandi looked up at the ceiling. Somewhere above the plaster, the loft held its breath.`,featured:true,likes:44,premium:false,created:16,license:"CC BY 4.0",comments:[],series:"The House of Returning",chapter:1,next:"ser2"},
  {id:"ser2",title:"The House of Returning — Chapter 2",author:"Naledi Molefe",type:"Serial",language:"English",time:"10–20 min",tags:["Family","Home","Secrets"],description:"Second chapter. The blue trunk opens onto a history the family preferred to keep in the dark.",body:`Chapter 2 — The Blue Trunk\n\nThe loft ladder protested more than the front door had. Dust rose in the beam of her phone light. The blue trunk sat exactly where the note had promised, under a sheet that might once have been a curtain.\n\nInside: bundles of letters tied with string, a photograph album with several pages missing, and a small wooden box that rattled when she lifted it.\n\nThe letters were not in her mother’s hand. They were in a script she recognised from the few documents her father had left behind — the careful, slightly formal handwriting of a man who had learned English as a second language and never fully trusted it.\n\nThey were addressed to a name she did not know.\n\nShe read the first three. By the fourth she understood that her father had lived a parallel correspondence for nearly a decade. The recipient had lived in another city. The tone moved from formal to intimate and then, abruptly, to silence.\n\nThe wooden box contained a single key and a train ticket stub dated the year before she was born.\n\nThandi sat on the loft floor until the light from the small window turned the colour of weak tea. The house had not lied. It had simply waited until someone was ready to listen.`,featured:false,likes:21,premium:true,created:17,license:"CC BY 4.0",comments:[],series:"The House of Returning",chapter:2,prev:"ser1",next:"ser3"},
  {id:"ser3",title:"The House of Returning — Chapter 3",author:"Naledi Molefe",type:"Serial",language:"English",time:"10–20 min",tags:["Family","Home","Secrets"],description:"Third chapter. A visitor arrives who already knows the house better than Thandi does.",body:`Chapter 3 — The Woman at the Gate\n\nOn the third morning a woman stood at the gate with a basket of vegetables and an expression that suggested she had been expected.\n\n“You are the daughter,” she said. It was not a question.\n\nThandi opened the gate. The woman walked past her into the kitchen as if the intervening years had been a brief interruption.\n\n“Your mother and I kept the garden between us,” she said while unpacking tomatoes. “When she became too tired, I kept it alone. The house does not like empty soil.”\n\nThey drank tea. The woman — who introduced herself only as Mrs. Dlamini from the next street — spoke of the neighbourhood’s changes without sentimentality. She mentioned the letters only once.\n\n“Your father was a careful man. Careful men leave careful messes. The loft was his way of not throwing anything away. Including the truth.”\n\nBefore she left, Mrs. Dlamini placed a small jar of apricot jam on the table. “Your mother preferred the tart ones. I still make them that way.”\n\nThat evening Thandi climbed to the loft again. This time she did not open the trunk. She simply sat with it, listening to the house settle around her, and understood that returning was not a single action. It was a series of small permissions granted to the past.`,featured:false,likes:17,premium:true,created:18,license:"CC BY 4.0",comments:[],series:"The House of Returning",chapter:3,prev:"ser2"},
  {id:"s16",title:"Ink and Ochre",author:"Lerato Mokoena",type:"Essay",language:"English",time:"5–10 min",tags:["Art","Land","Identity"],description:"On the relationship between writing and the ochre traditions that marked bodies and landscapes long before paper.",body:`Before ink, there was ochre. Before the page, there was the body and the rock face.\n\nI do not mean this as a romantic hierarchy. I mean it as a reminder that the impulse to mark, to record, to leave a trace that outlasts the moment, is older than any of the technologies we currently worship.\n\nWhen I write, I am participating in a continuum that includes the people who ground pigment and pressed it into skin for ceremony, protection and beauty. The materials have changed. The need has not.\n\nThis does not make every written word sacred. It does, however, place a responsibility on the writer: to mark with intention, to avoid careless erasure, and to remember that some surfaces — landscapes, languages, lives — cannot be rewritten without consequence.`,featured:false,likes:16,premium:false,created:19,license:"CC BY 4.0",comments:[]},
  {id:"s17",title:"Waiting for the Generator",author:"Ibrahim Touré",type:"Short story",language:"English",time:"5–10 min",tags:["City","Everyday","Humour"],description:"A comic and tender portrait of a family evening interrupted — and somehow improved — by a power cut.",body:`The lights failed just as the football match entered its final ten minutes. A collective groan rose from the compound, followed by the familiar scramble for candles, phones and blame.\n\nIn the Touré household the hierarchy of emergency was well established. First: locate the matches. Second: prevent the youngest from using the good candles for sword fights. Third: decide whether to start the generator or wait for the municipal supply to remember its duties.\n\nUncle Sékou voted for the generator. Aunt Mariam voted for patience and conversation. The children voted for both, provided the conversation included stories.\n\nThey waited. The match remained unfinished on the dark television. Outside, other generators began their uneven chorus. Inside, Mariam told the story of the year the river flooded the market and everyone traded by the light of mobile phones.\n\nBy the time the power returned, the match was over and nobody asked for the score. They had already found a different kind of ending.`,featured:false,likes:25,premium:false,created:20,license:"CC BY 4.0",comments:[]},
  {id:"s18",title:"The Sewing Machine That Remembered",author:"Grace Nyathi",type:"Short story",language:"English",time:"5–10 min",tags:["Family","Women","Memory"],description:"A grandmother’s sewing machine becomes the unexpected archive of a family’s unspoken history.",body:`The machine was older than independence. Its black body still shone in places; in others the paint had worn to bare metal where elbows had rested for decades.\n\nWhen Grace’s grandmother died, the machine was the only object the cousins fought over. Not for its value — it was worth almost nothing — but because each of them had a different memory stitched into its sound.\n\nGrace took it home. One evening, while oiling the wheel, she found a small compartment under the base she had never noticed. Inside were folded notes in her grandmother’s hand: measurements, dates, and short sentences that were almost prayers.\n\n“For the wedding dress that was never worn.”\n“For the boy who left and sent no word.”\n“For the day the soldiers came and the cloth was still on the table.”\n\nGrace began to sew again. Not to finish the unfinished dresses, but to keep the machine’s memory warm.`,featured:true,likes:39,premium:false,created:21,license:"CC BY 4.0",comments:[]},
  {id:"s19",title:"Writing Prompt: The Object That Travelled",author:"Jesma Editors",type:"Reflection",language:"English",time:"2–5 min",tags:["Prompt","Community"],description:"A community writing prompt inviting stories about an object that crossed borders, generations or silences.",body:`This week’s prompt:\n\nChoose one object that has moved — across a border, between generations, or through a silence in your family.\n\nWrite 300–600 words. Let the object speak, or refuse to speak. You may invent, remember, or combine both.\n\nPublish under “Reflection” or “Short story” and tag your work with “Prompt”. The community will respond.\n\nThere is no prize except attention. Attention, on Jesma, is the beginning of everything.`,featured:false,likes:14,premium:false,created:22,license:"CC BY 4.0",comments:[]}
];

/* ---------- Personas (dual-user simulation) ---------- */
const PERSONAS = {
  guest: {
    id: "guest",
    name: "Guest",
    bio: "Browsing without an account. Limited library and no publishing.",
    tier: "guest",          // guest | free | premium
    isWriter: false,
    writerTier: null,      // free | pro
    coins: 0,
    avatar: "G"
  },
  reader: {
    id: "reader",
    name: "Nia Okonkwo",
    bio: "Reader of stories without borders. Community regular.",
    tier: "free",
    isWriter: false,
    writerTier: null,
    coins: 80,
    avatar: "N"
  },
  writer: {
    id: "writer",
    name: "Tariro Moyo",
    bio: "Author of “The Baobab Keeps Secrets”. Building a readership on Jesma.",
    tier: "free",
    isWriter: true,
    writerTier: "free",
    coins: 40,
    avatar: "T"
  }
};

/* ---------- State ---------- */
let memoryStore = null;
function safeGet(){ try{ return localStorage.getItem(STORE); }catch(e){ return memoryStore; } }
function safeSet(v){ memoryStore=v; try{ localStorage.setItem(STORE,v); }catch(e){} }
function safeRemove(){ memoryStore=null; try{ localStorage.removeItem(STORE); }catch(e){} }

function defaultPosts(){
  return [
    {id:"p1",author:"Nia Okonkwo",time:"2 hours ago",text:"Just finished “The Baobab Keeps Secrets”. That final image of the seed will stay with me. Grateful for stories that treat silence as something alive.",likes:14,likedBy:[],comments:[{author:"Tariro Moyo",text:"Thank you for reading with such care."}],review:false,prompt:false},
    {id:"p2",author:"Samir Bello",time:"Yesterday",text:"Review: “Letters from the Dust Road” is the kind of essay that makes you walk more slowly afterwards. Lindiwe Khumalo writes with precision and warmth.",likes:9,likedBy:[],comments:[],review:true,prompt:false},
    {id:"p3",author:"Aisha Nkosi",time:"3 days ago",text:"Is anyone else following “The House of Returning”? Chapter 1 left me impatient for the next part in the best way.",likes:18,likedBy:[],comments:[{author:"Nia Okonkwo",text:"Same — the key still fitting was such a quiet, perfect opening."}],review:false,prompt:false},
    {id:"p4",author:"Jesma Editors",time:"1 day ago",text:"Writing prompt this week: The Object That Travelled. An object that crossed a border, a generation, or a silence. Publish and tag “Prompt”. We are reading.",likes:22,likedBy:[],comments:[],review:false,prompt:true},
    {id:"p5",author:"Tariro Moyo",time:"4 days ago",text:"Author note: I am drafting a companion piece to the baobab story. If you have family rituals around trees, rivers or stones, I would love to hear them in the comments.",likes:11,likedBy:[],comments:[],review:false,prompt:false}
  ];
}

function loadState(){
  try{
    const raw=safeGet();
    if(raw){
      const s=JSON.parse(raw);
      const works=[...seedWorks];
      (s.works||[]).forEach(w=>{ if(!works.some(x=>x.id===w.id)) works.push(w); });
      return {
        works,
        activePersona: s.activePersona || "reader",
        personas: s.personas || structuredClone(PERSONAS),
        saved: s.saved || {},
        reading: s.reading || {},
        finished: s.finished || {},
        likes: s.likes || {},
        progress: s.progress || {},
        comments: s.comments || {},
        drafts: s.drafts || {},
        posts: s.posts || defaultPosts(),
        activity: s.activity || {},
        platform: s.platform || { subRevenue:0, tipCommission:0, boostRevenue:0 },
        tipsReceived: s.tipsReceived || {}
      };
    }
  }catch(e){}
  return {
    works:[...seedWorks],
    activePersona:"reader",
    personas: structuredClone(PERSONAS),
    saved:{}, reading:{}, finished:{}, likes:{}, progress:{}, comments:{}, drafts:{},
    posts: defaultPosts(),
    activity:{},
    platform:{ subRevenue:0, tipCommission:0, boostRevenue:0 },
    tipsReceived:{}
  };
}

let state = loadState();
let currentWork=null, currentFilter="All", currentLibrary="saved", currentCommunity="all";
let fontSize=18, readerTheme="light", fontFamily="serif", toastTimer=null;

function P(){ return state.personas[state.activePersona]; }
function pid(){ return state.activePersona; }

function persist(){
  safeSet(JSON.stringify({
    works: state.works.filter(w=>!seedWorks.some(s=>s.id===w.id)),
    activePersona: state.activePersona,
    personas: state.personas,
    saved: state.saved, reading: state.reading, finished: state.finished,
    likes: state.likes, progress: state.progress, comments: state.comments,
    drafts: state.drafts, posts: state.posts, activity: state.activity,
    platform: state.platform, tipsReceived: state.tipsReceived
  }));
  refreshAll();
}

function escapeHTML(s=""){ return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function coverStyle(w){ const i=Math.abs((w.title||"J").split("").reduce((a,c)=>a+c.charCodeAt(0),0))%COLORS.length; return `background:linear-gradient(145deg,${COLORS[i][0]},${COLORS[i][0]}dd);color:${COLORS[i][1]}`; }
function coverHTML(w){ const prem=w.premium?`<span class="premium-tag">PREMIUM</span>`:""; return `<div class="cover" style="${coverStyle(w)}">${prem}<span class="cover-kicker">JESMA · ${escapeHTML(w.type).toUpperCase()}</span><strong>${escapeHTML(w.title)}</strong><span class="cover-author">${escapeHTML(w.author)}</span><span class="cover-mark">✦</span><span class="cover-footer">STORIES WITHOUT BORDERS</span></div>`; }
function cardHTML(w){
  const id=pid();
  const prog=(state.progress[id]||{})[w.id]||0;
  const progBar=prog>0&&prog<100?`<div class="progress-mini"><i style="width:${prog}%"></i></div>`:"";
  const liked=((state.likes[id]||[]).includes(w.id));
  return `<article class="book-card" data-open="${escapeHTML(w.id)}">${coverHTML(w)}${progBar}<h3>${escapeHTML(w.title)}</h3><p class="byline">by ${escapeHTML(w.author)}</p><div class="card-meta"><span class="tag">${escapeHTML(w.type)}</span><button class="like-mini ${liked?"liked":""}" data-like="${escapeHTML(w.id)}">${liked?"♥":"♡"} ${w.likes||0}</button></div></article>`;
}
function showToast(msg){ const t=$("#toast"); t.textContent=msg; t.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>t.classList.remove("show"),2800); }
function addActivity(text){
  const id=pid();
  state.activity[id]=state.activity[id]||[];
  state.activity[id].unshift({text, time:new Date().toLocaleString()});
  state.activity[id]=state.activity[id].slice(0,25);
}

/* ---------- Access helpers ---------- */
function canPublish(){
  const p=P();
  if(p.tier==="guest") return false;
  if(!p.isWriter) return false;
  return true;
}
function canAccessPremium(){ return P().tier==="premium"; }
function isAuthorPro(){ return P().isWriter && P().writerTier==="pro"; }
function maxFreePublishes(){ return isAuthorPro()?999:3; }

/* ---------- Rendering ---------- */
function setView(name){
  $$(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${name}`));
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===name));
  window.scrollTo({top:0,behavior:"smooth"});
  if(name==="discover") renderDiscover();
  if(name==="library") renderLibrary();
  if(name==="community") renderCommunity();
  if(name==="write") renderStudio();
  if(name==="profile") renderProfile();
  if(name==="home") renderHome();
}

function updateAccountStrip(){
  const p=P();
  $("#stripName").textContent=p.name;
  let role="Guest mode";
  if(p.tier==="premium") role="Premium Reader";
  else if(p.tier==="free") role="Free Reader";
  if(p.isWriter){
    if(p.writerTier==="pro") role="Author Pro";
    else role=(p.tier==="premium"?"Premium + ":"")+"Free Writer";
  }
  $("#stripRole").textContent=role;
  $("#accountSwitch").textContent=p.avatar;
  $("#profileShortcut") && ($("#profileShortcut").textContent=p.avatar);
}

function renderHome(){
  const featured=state.works.filter(w=>w.featured&&w.published!==false).slice(0,6);
  $("#featuredGrid").innerHTML=featured.map(cardHTML).join("");
  const feed=state.posts.slice(0,3);
  $("#homeFeed").innerHTML=feed.map(feedCard).join("");
  $("#premiumBanner").classList.toggle("is-member", P().tier==="premium");
  $("#recruitBanner").style.display = (P().isWriter || P().tier==="guest") ? "none" : "flex";
}

function feedCard(p){
  return `<article class="feed-card">
    <div class="feed-head"><div class="feed-avatar">${escapeHTML((p.author||"J")[0])}</div>
    <div><strong>${escapeHTML(p.author)}</strong><small>${escapeHTML(p.time||"")}</small></div></div>
    <p>${escapeHTML(p.text)}</p>
    <div class="feed-actions">
      <button data-post-like="${p.id}" class="${(p.likedBy||[]).includes(pid())?"liked":""}">${(p.likedBy||[]).includes(pid())?"♥":"♡"} ${p.likes||0}</button>
      <button data-post-comment="${p.id}">Comment</button>
    </div>
  </article>`;
}

const categories=["All","Short story","Poetry","Essay","Folklore","Serial","Novel","Reflection"];
function renderChips(){ $("#filterChips").innerHTML=categories.map(c=>`<button class="${currentFilter===c?"active":""}" data-filter="${c}">${c}</button>`).join(""); }

function renderDiscover(){
  renderChips();
  const q=($("#searchInput")?.value||"").trim().toLowerCase();
  let list=state.works.filter(w=>w.published!==false&&(currentFilter==="All"||w.type===currentFilter)&&(!q||[w.title,w.author,w.description,w.type,w.language,(w.tags||[]).join(" "),w.body].join(" ").toLowerCase().includes(q)));
  const sort=$("#sortSelect")?.value||"featured";
  if(sort==="newest") list.sort((a,b)=>(b.created||0)-(a.created||0));
  if(sort==="popular") list.sort((a,b)=>(b.likes||0)-(a.likes||0));
  if(sort==="title") list.sort((a,b)=>a.title.localeCompare(b.title));
  if(sort==="featured") list.sort((a,b)=>Number(!!b.featured)-Number(!!a.featured)||(b.likes||0)-(a.likes||0));
  $("#discoverGrid").innerHTML=list.map(cardHTML).join("");
  $("#resultCount").textContent=`${list.length} works`;
  $("#emptyResults").classList.toggle("hidden",list.length>0);
}

function renderLibrary(){
  const id=pid();
  const ids=(state[currentLibrary][id]||[]);
  const list=ids.map(x=>state.works.find(w=>w.id===x)).filter(Boolean);
  $("#savedCount").textContent=(state.saved[id]||[]).length;
  $("#readingCount").textContent=(state.reading[id]||[]).length;
  $("#finishedCount").textContent=(state.finished[id]||[]).length;
  $("#libraryGrid").innerHTML=list.map(cardHTML).join("");
  $("#emptyLibrary").classList.toggle("hidden",list.length>0);
}

function renderCommunity(){
  let posts=state.posts;
  if(currentCommunity==="posts") posts=posts.filter(p=>!p.review&&!p.prompt);
  if(currentCommunity==="reviews") posts=posts.filter(p=>p.review);
  if(currentCommunity==="prompts") posts=posts.filter(p=>p.prompt);
  $("#communityFeed").innerHTML=posts.map(p=>`
    <article class="feed-card">
      <div class="feed-head"><div class="feed-avatar">${escapeHTML((p.author||"J")[0])}</div>
      <div><strong>${escapeHTML(p.author)}</strong><small>${escapeHTML(p.time||"")}${p.prompt?" · Prompt":p.review?" · Review":""}</small></div></div>
      <p>${escapeHTML(p.text)}</p>
      <div class="feed-actions">
        <button data-post-like="${p.id}" class="${(p.likedBy||[]).includes(pid())?"liked":""}">${(p.likedBy||[]).includes(pid())?"♥":"♡"} ${p.likes||0}</button>
        <button data-post-comment="${p.id}">Comment</button>
      </div>
      ${(p.comments||[]).map(c=>`<div class="comment-item"><strong>${escapeHTML(c.author)}</strong> ${escapeHTML(c.text)}</div>`).join("")}
    </article>`).join("");
  $("#communityAvatar").textContent=P().avatar;
}

function renderStudio(){
  const p=P();
  const can=canPublish();
  $("#studioIntro").textContent = can
    ? "Publish work, track tips and grow your readership. Figures are simulated."
    : "Switch to the Writer persona (or upgrade) to publish. Guests and pure readers cannot publish.";
  $("#writerUpgradeCard").classList.toggle("is-pro", isAuthorPro());
  $("#writerUpgradeCard").style.display = (p.isWriter && !isAuthorPro()) ? "flex" : "none";

  const mine=state.works.filter(w=>w.author===p.name || w.localAuthor===pid());
  const tips=state.tipsReceived[pid()]||0;
  const tipValue=tips*5;
  const share=isAuthorPro()?35:0;
  const fee=Math.round(tipValue*0.15);
  const net=tipValue-fee+share;

  $("#statPublished").textContent=mine.length;
  $("#statTips").textContent=tips;
  $("#statEarnings").textContent=`R${net}`;
  $("#earnTips").textContent=`R${tipValue}`;
  $("#earnShare").textContent=`R${share}`;
  $("#earnFee").textContent=`−R${fee}`;
  $("#earnNet").textContent=`R${net}`;

  const drafts=state.drafts[pid()]||[];
  $("#draftsList").innerHTML=drafts.map((d,i)=>`<div class="draft-item"><span>${escapeHTML(d.title||"Untitled")}</span><button data-load-draft="${i}">Edit</button></div>`).join("");
  $("#noDrafts").style.display=drafts.length?"none":"block";
  $("#myWorksList").innerHTML=mine.length
    ? mine.map(w=>`<div class="draft-item"><span>${escapeHTML(w.title)}</span><button data-open="${escapeHTML(w.id)}">View</button></div>`).join("")
    : `<p class="side-note">Nothing published yet under this name.</p>`;
  $("#authorName").value=p.name;
}

function renderProfile(){
  const p=P();
  const id=pid();
  $("#profileName").textContent=p.name;
  $("#profileBio").textContent=p.bio||"";
  $("#profileAvatar").textContent=p.avatar;
  $("#statSaved").textContent=(state.saved[id]||[]).length;
  $("#statReading").textContent=(state.reading[id]||[]).length;
  $("#statFinished").textContent=(state.finished[id]||[]).length;
  $("#statCoins").textContent=p.coins;
  let tierLabel="Guest";
  if(p.tier==="premium") tierLabel="Premium Reader";
  else if(p.tier==="free") tierLabel="Free Reader";
  $("#tierBadge").textContent=tierLabel;
  $("#writerBadge").classList.toggle("hidden",!p.isWriter);
  if(p.isWriter) $("#writerBadge").textContent=p.writerTier==="pro"?"Author Pro":"Free Writer";

  // Economics
  const plat=state.platform;
  $("#econSubs").textContent=`R${plat.subRevenue}`;
  $("#econTips").textContent=`R${plat.tipCommission}`;
  $("#econBoost").textContent=`R${plat.boostRevenue}`;
  $("#econTotal").textContent=`R${plat.subRevenue+plat.tipCommission+plat.boostRevenue}`;

  const act=state.activity[id]||[];
  $("#activityList").innerHTML=act.length
    ? act.slice(0,8).map(a=>`<div class="activity-item"><strong>${escapeHTML(a.text)}</strong><br><small>${escapeHTML(a.time)}</small></div>`).join("")
    : `<p class="side-note">Activity will appear here.</p>`;

  $$(".persona-card").forEach(b=>b.classList.toggle("active",b.dataset.persona===state.activePersona));
}

function refreshAll(){
  updateAccountStrip();
  renderHome(); renderDiscover(); renderLibrary(); renderCommunity(); renderStudio(); renderProfile();
}

/* ---------- Reader ---------- */
function openReader(id){
  const w=state.works.find(x=>x.id===id);
  if(!w) return;
  currentWork=w;
  const locked=w.premium && !canAccessPremium();
  $("#readerTitle").textContent=w.title;
  $("#readerAuthor").textContent=`${w.author} · ${w.type}${w.language?" · "+w.language:""}`;
  $("#readerBody").textContent=locked?(w.body.slice(0,260)+"…"):w.body;
  $("#readerBody").style.fontSize=fontSize+"px";
  applyReaderTheme();
  const uid=pid();
  $("#readerSave").textContent=(state.saved[uid]||[]).includes(id)?"♥":"♡";
  $("#readerLike").textContent=(state.likes[uid]||[]).includes(id)?"♥":"♡";
  $("#premiumGate").classList.toggle("hidden",!locked);
  const comments=[...(w.comments||[]),...(state.comments[id]||[])];
  $("#commentsList").innerHTML=comments.length
    ? comments.map(c=>`<div class="comment-item"><strong>${escapeHTML(c.author)}</strong> ${escapeHTML(c.text)}</div>`).join("")
    : `<p class="field-hint">No responses yet.</p>`;
  const chWrap=$("#readerChapters");
  if(w.series){
    const chapters=state.works.filter(x=>x.series===w.series).sort((a,b)=>(a.chapter||0)-(b.chapter||0));
    chWrap.classList.remove("hidden");
    chWrap.innerHTML=chapters.map(c=>`<button class="${c.id===w.id?"active":""}" data-open="${escapeHTML(c.id)}">Ch. ${c.chapter}${c.premium&&!canAccessPremium()?" · Premium":""}</button>`).join("");
  } else chWrap.classList.add("hidden");
  if(!(state.reading[uid]||[]).includes(id) && !(state.finished[uid]||[]).includes(id)){
    state.reading[uid]=[...new Set([...(state.reading[uid]||[]),id])];
  }
  updateProgressBar();
  $("#readerModal").classList.remove("hidden");
  document.body.style.overflow="hidden";
  addActivity(`Opened “${w.title}”`);
  persist();
}

function closeReader(){
  if(currentWork){
    const el=$("#readerBody");
    if(el){
      const max=el.scrollHeight-el.clientHeight;
      const pct=max>0?Math.min(100,Math.round((el.scrollTop/max)*100)):100;
      const uid=pid();
      state.progress[uid]=state.progress[uid]||{};
      state.progress[uid][currentWork.id]=Math.max(state.progress[uid][currentWork.id]||0,pct);
    }
  }
  $("#readerModal").classList.add("hidden");
  document.body.style.overflow="";
  currentWork=null;
  persist();
}

function updateProgressBar(){
  const el=$("#readerBody"), bar=$("#readerProgressBar");
  if(!el||!bar) return;
  const onScroll=()=>{ const max=el.scrollHeight-el.clientHeight; bar.style.width=(max>0?Math.min(100,(el.scrollTop/max)*100):0)+"%"; };
  el.onscroll=onScroll; onScroll();
}

function applyReaderTheme(){
  const body=$("#readerBody");
  body.classList.remove("theme-sepia","theme-dark","font-sans","font-mono");
  if(readerTheme==="sepia") body.classList.add("theme-sepia");
  if(readerTheme==="dark") body.classList.add("theme-dark");
  if(fontFamily==="sans") body.classList.add("font-sans");
  if(fontFamily==="mono") body.classList.add("font-mono");
  $$(".chip-btn[data-theme]").forEach(b=>b.classList.toggle("active",b.dataset.theme===readerTheme));
}

/* ---------- Actions ---------- */
function toggleSave(id){
  if(P().tier==="guest"){ showToast("Create a free account (switch to Nia) to save stories"); return; }
  const uid=pid();
  state.saved[uid]=state.saved[uid]||[];
  const i=state.saved[uid].indexOf(id);
  if(i>=0) state.saved[uid].splice(i,1); else state.saved[uid].push(id);
  if($("#readerSave")&&currentWork?.id===id) $("#readerSave").textContent=state.saved[uid].includes(id)?"♥":"♡";
  showToast(state.saved[uid].includes(id)?"Saved":"Removed from library");
  persist();
}

function toggleLike(id){
  if(P().tier==="guest"){ showToast("Sign in (switch persona) to like"); return; }
  const w=state.works.find(x=>x.id===id); if(!w) return;
  const uid=pid();
  state.likes[uid]=state.likes[uid]||[];
  const i=state.likes[uid].indexOf(id);
  if(i>=0){ state.likes[uid].splice(i,1); w.likes=Math.max(0,(w.likes||0)-1); }
  else { state.likes[uid].push(id); w.likes=(w.likes||0)+1; }
  if($("#readerLike")&&currentWork?.id===id) $("#readerLike").textContent=state.likes[uid].includes(id)?"♥":"♡";
  persist();
}

function markFinished(){
  if(!currentWork) return;
  const id=currentWork.id, uid=pid();
  state.finished[uid]=[...new Set([...(state.finished[uid]||[]),id])];
  state.reading[uid]=(state.reading[uid]||[]).filter(x=>x!==id);
  state.progress[uid]=state.progress[uid]||{};
  state.progress[uid][id]=100;
  addActivity(`Finished “${currentWork.title}”`);
  showToast("Marked finished");
  persist();
}

/* ---------- Monetisation (simulated) ---------- */
function openPremiumModal(forWriter=false){
  const p=P();
  if(forWriter || p.isWriter){
    openDialog(`
      <span class="eyebrow gold">AUTHOR PRO</span>
      <h2>Grow as a Jesma writer</h2>
      <p style="margin:6px 0 4px;font-size:13px;color:var(--muted)">Simulated subscription — no real payment.</p>
      <div class="premium-plan selected">
        <h3>Author Pro · Monthly</h3>
        <div class="price">R79<span style="font-size:13px;font-weight:400"> / month</span></div>
        <ul>
          <li>Unlimited publications</li>
          <li>Higher tip multiplier & visibility</li>
          <li>Featured placement eligibility</li>
          <li>Premium share of reader subscriptions</li>
          <li>Detailed earnings dashboard</li>
        </ul>
      </div>
      <button class="gold-button" id="confirmWriterPro" style="width:100%;justify-content:center;margin-top:8px">
        ${isAuthorPro()?"You are Author Pro":"Activate Author Pro (Demo)"}
      </button>
      ${isAuthorPro()?`<button class="outline-button" id="cancelWriterPro" style="width:100%;margin-top:8px">Cancel Author Pro</button>`:""}
      <div class="demo-note">Platform earns R79/month per Author Pro. Writers unlock higher earnings potential.</div>
    `);
    $("#confirmWriterPro").onclick=()=>{
      if(!isAuthorPro()){
        const per=state.personas[pid()];
        per.writerTier="pro";
        per.isWriter=true;
        if(per.tier==="guest") per.tier="free";
        state.platform.subRevenue+=79;
        addActivity("Activated Author Pro (demo)");
        showToast("Author Pro activated");
        persist();
      }
      closeDialog();
    };
    const c=$("#cancelWriterPro");
    if(c) c.onclick=()=>{ state.personas[pid()].writerTier="free"; addActivity("Cancelled Author Pro"); showToast("Author Pro cancelled"); persist(); closeDialog(); };
    return;
  }
  openDialog(`
    <span class="eyebrow gold">PREMIUM READER</span>
    <h2>Unlock the full library</h2>
    <p style="margin:6px 0 4px;font-size:13px;color:var(--muted)">Simulated — no real charges.</p>
    <div class="premium-plan selected">
      <h3>Premium Monthly</h3>
      <div class="price">R49<span style="font-size:13px;font-weight:400"> / month</span></div>
      <ul>
        <li>All Premium-locked stories & serial chapters</li>
        <li>Unlimited library saves</li>
        <li>Early access to new releases</li>
        <li>Support writers through the Premium pool</li>
      </ul>
    </div>
    <button class="gold-button" id="confirmPremium" style="width:100%;justify-content:center;margin-top:8px">
      ${P().tier==="premium"?"You are Premium":"Activate Premium (Demo)"}
    </button>
    ${P().tier==="premium"?`<button class="outline-button" id="cancelPremium" style="width:100%;margin-top:8px">Cancel Premium</button>`:""}
    <div class="demo-note">Platform earns R49/month per Premium Reader. A share is distributed to Author Pro writers.</div>
  `);
  $("#confirmPremium").onclick=()=>{
    if(P().tier!=="premium"){
      const per=state.personas[pid()];
      per.tier="premium";
      if(per.tier==="guest") per.tier="premium";
      per.coins+=25;
      state.platform.subRevenue+=49;
      addActivity("Activated Premium Reader (demo)");
      showToast("Premium activated — exclusive stories unlocked");
      persist();
    }
    closeDialog();
  };
  const c=$("#cancelPremium");
  if(c) c.onclick=()=>{ state.personas[pid()].tier="free"; addActivity("Cancelled Premium"); showToast("Premium cancelled"); persist(); closeDialog(); };
}

function tipAuthor(){
  if(!currentWork) return;
  if(P().tier==="guest"){ showToast("Switch to a reader account to tip"); return; }
  openDialog(`
    <span class="eyebrow gold">SUPPORT THE AUTHOR</span>
    <h2>Tip ${escapeHTML(currentWork.author)}</h2>
    <p style="margin:8px 0;font-size:13px;color:var(--muted)">Virtual Jesma Coins. Simulated tip.</p>
    <p style="margin-bottom:12px">Your balance: <strong>${P().coins} coins</strong></p>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
      <button class="outline-button tip-amount" data-amount="5">5 coins</button>
      <button class="outline-button tip-amount" data-amount="10">10 coins</button>
      <button class="outline-button tip-amount" data-amount="25">25 coins</button>
    </div>
    <div class="demo-note">Platform takes 15% commission. Remainder goes to the writer’s simulated earnings.</div>
  `);
  $$(".tip-amount").forEach(btn=>{
    btn.onclick=()=>{
      const amt=Number(btn.dataset.amount);
      const per=state.personas[pid()];
      if(per.coins<amt){ showToast("Not enough coins"); return; }
      per.coins-=amt;
      // Attribute tip to writer persona if the work is by Tariro, else to a generic pool
      const writerId = currentWork.author==="Tariro Moyo" ? "writer" : "writer";
      state.tipsReceived[writerId]=(state.tipsReceived[writerId]||0)+amt;
      const commission=Math.round(amt*5*0.15);
      state.platform.tipCommission+=commission;
      addActivity(`Tipped ${amt} coins to ${currentWork.author}`);
      showToast(`Tipped ${amt} coins — thank you`);
      persist();
      closeDialog();
    };
  });
}

/* ---------- Publishing ---------- */
function saveCurrentDraft(){
  if(!canPublish()){ showToast("Switch to Writer persona to save drafts"); return; }
  const draft={
    title:$("#workTitle").value.trim(), author:$("#authorName").value.trim()||P().name,
    type:$("#workType").value, language:$("#workLanguage").value, time:$("#readingTime").value,
    tags:($("#workTags").value||"").split(",").map(t=>t.trim()).filter(Boolean),
    description:$("#workDescription").value.trim(), body:$("#workBody").value.trim(),
    premium:$("#markPremium").checked
  };
  if(!draft.title&&!draft.body){ showToast("Nothing to save"); return; }
  state.drafts[pid()]=state.drafts[pid()]||[];
  state.drafts[pid()].unshift(draft);
  state.drafts[pid()]=state.drafts[pid()].slice(0,10);
  showToast("Draft saved");
  persist();
}

function publishWork(e){
  e.preventDefault();
  if(!canPublish()){ showToast("Switch to the Writer persona (Tariro) to publish"); return; }
  const mine=state.works.filter(w=>w.localAuthor===pid()||w.author===P().name);
  if(mine.length>=maxFreePublishes() && !isAuthorPro()){
    showToast("Free writers are limited to 3 works. Upgrade to Author Pro.");
    openPremiumModal(true);
    return;
  }
  const w={
    id:"u"+Date.now(),
    title:$("#workTitle").value.trim(),
    author:$("#authorName").value.trim()||P().name,
    type:$("#workType").value, language:$("#workLanguage").value, time:$("#readingTime").value,
    tags:($("#workTags").value||"").split(",").map(t=>t.trim()).filter(Boolean),
    description:$("#workDescription").value.trim(), body:$("#workBody").value.trim(),
    featured:false, likes:0, premium:$("#markPremium").checked && isAuthorPro(),
    created:Date.now(), license:"All rights reserved (user work)", comments:[],
    published:$("#publishNow").checked, localAuthor:pid()
  };
  if(!w.title||!w.body){ showToast("Title and body required"); return; }
  state.works.unshift(w);
  state.personas[pid()].name=w.author;
  addActivity(`Published “${w.title}”`);
  showToast(w.published?"Published to the library":"Saved privately");
  $("#publishForm").reset();
  $("#authorName").value=P().name;
  persist();
  setView("discover");
}

function postCommunity(){
  if(P().tier==="guest"){ showToast("Switch to a named persona to post"); return; }
  openDialog(`
    <span class="eyebrow">COMMUNITY</span>
    <h2>Share a note</h2>
    <textarea id="newPostText" rows="4" placeholder="What are you reading? What stayed with you?" style="width:100%;margin:12px 0;padding:12px;border-radius:12px;border:1px solid var(--line);background:var(--cream)"></textarea>
    <label class="check-label"><input type="checkbox" id="isReview"> Mark as review</label>
    <label class="check-label"><input type="checkbox" id="isPrompt"> Mark as writing prompt</label>
    <button class="primary-button" id="sendPost" style="width:100%;margin-top:12px;justify-content:center">Post</button>
  `);
  $("#sendPost").onclick=()=>{
    const text=$("#newPostText").value.trim(); if(!text) return;
    state.posts.unshift({
      id:"p"+Date.now(), author:P().name, time:"Just now", text,
      likes:0, likedBy:[], comments:[],
      review:$("#isReview").checked, prompt:$("#isPrompt").checked
    });
    addActivity("Posted to community");
    showToast("Posted");
    persist(); closeDialog(); setView("community");
  };
}

function editProfile(){
  if(P().tier==="guest"){ showToast("Switch to a persona first"); return; }
  openDialog(`
    <span class="eyebrow">PROFILE</span>
    <h2>Edit profile</h2>
    <label style="display:block;margin:12px 0 6px">Display name
      <input id="editName" value="${escapeHTML(P().name)}" maxlength="40" style="width:100%;margin-top:5px;padding:11px;border-radius:10px;border:1px solid var(--line);background:var(--cream)">
    </label>
    <label style="display:block;margin:12px 0 6px">Bio
      <textarea id="editBio" rows="3" maxlength="160" style="width:100%;margin-top:5px;padding:11px;border-radius:10px;border:1px solid var(--line);background:var(--cream)">${escapeHTML(P().bio||"")}</textarea>
    </label>
    <button class="primary-button" id="saveProfile" style="width:100%;margin-top:10px;justify-content:center">Save</button>
  `);
  $("#saveProfile").onclick=()=>{
    const per=state.personas[pid()];
    per.name=$("#editName").value.trim()||per.name;
    per.bio=$("#editBio").value.trim();
    showToast("Profile updated"); persist(); closeDialog();
  };
}

function switchPersona(key){
  if(!PERSONAS[key] && !state.personas[key]) return;
  state.activePersona=key;
  // Ensure persona exists
  if(!state.personas[key]) state.personas[key]=structuredClone(PERSONAS[key]);
  addActivity(`Switched to ${state.personas[key].name}`);
  showToast(`Now viewing as ${state.personas[key].name}`);
  persist();
  setView("home");
}

function resetDemo(){
  if(!confirm("Reset all demo data on this device?")) return;
  safeRemove();
  state=loadState();
  showToast("Demo reset");
  refreshAll();
  setView("home");
}

/* ---------- Dialog ---------- */
function openDialog(html){ $("#dialogBody").innerHTML=html; $("#genericModal").classList.remove("hidden"); }
function closeDialog(){ $("#genericModal").classList.add("hidden"); }

/* ---------- Theme ---------- */
function toggleTheme(){
  const html=document.documentElement;
  const next=html.getAttribute("data-theme")==="dark"?"light":"dark";
  html.setAttribute("data-theme",next);
  try{ localStorage.setItem("jesma_theme",next); }catch(e){}
}
(function(){ try{ const t=localStorage.getItem("jesma_theme"); if(t) document.documentElement.setAttribute("data-theme",t); }catch(e){} })();

/* ---------- Events ---------- */
document.addEventListener("click",e=>{
  const view=e.target.closest("[data-view]"); if(view){ setView(view.dataset.view); return; }
  const filter=e.target.closest("[data-filter]"); if(filter){ currentFilter=filter.dataset.filter; setView("discover"); renderDiscover(); return; }
  const open=e.target.closest("[data-open]"); if(open){ openReader(open.dataset.open); return; }
  const like=e.target.closest("[data-like]"); if(like){ e.stopPropagation(); toggleLike(like.dataset.like); return; }
  const lib=e.target.closest("[data-library]"); if(lib){ currentLibrary=lib.dataset.library; $$("[data-library]").forEach(b=>b.classList.toggle("active",b===lib)); renderLibrary(); return; }
  const comm=e.target.closest("[data-community]"); if(comm){ currentCommunity=comm.dataset.community; $$("[data-community]").forEach(b=>b.classList.toggle("active",b===comm)); renderCommunity(); return; }
  const persona=e.target.closest("[data-persona]"); if(persona){ switchPersona(persona.dataset.persona); return; }
  const pl=e.target.closest("[data-post-like]");
  if(pl){
    const p=state.posts.find(x=>x.id===pl.dataset.postLike);
    if(p){
      p.likedBy=p.likedBy||[];
      const liked=p.likedBy.includes(pid());
      p.likedBy=liked?p.likedBy.filter(x=>x!==pid()):[...p.likedBy,pid()];
      p.likes=Math.max(0,(p.likes||0)+(liked?-1:1));
      persist();
    }
    return;
  }
  const pc=e.target.closest("[data-post-comment]");
  if(pc){
    if(P().tier==="guest"){ showToast("Switch persona to comment"); return; }
    const p=state.posts.find(x=>x.id===pc.dataset.postComment);
    if(p){
      openDialog(`
        <span class="eyebrow">RESPONSE</span>
        <h2>Comment on ${escapeHTML(p.author)}'s post</h2>
        <textarea id="postCommentText" rows="3" placeholder="Write a response…" style="width:100%;margin:12px 0;padding:12px;border-radius:12px;border:1px solid var(--line);background:var(--cream)"></textarea>
        <button class="primary-button" id="sendPostComment" style="width:100%;justify-content:center">Post</button>
      `);
      $("#sendPostComment").onclick=()=>{
        const t=$("#postCommentText").value.trim();
        if(t){ p.comments=p.comments||[]; p.comments.push({author:P().name,text:t}); persist(); closeDialog(); showToast("Response added"); }
      };
    }
    return;
  }
  const ld=e.target.closest("[data-load-draft]");
  if(ld){
    const d=(state.drafts[pid()]||[])[Number(ld.dataset.loadDraft)];
    if(d){
      $("#workTitle").value=d.title||""; $("#authorName").value=d.author||P().name;
      $("#workType").value=d.type||"Short story"; $("#workLanguage").value=d.language||"English";
      $("#readingTime").value=d.time||"5–10 min"; $("#workTags").value=(d.tags||[]).join(", ");
      $("#workDescription").value=d.description||""; $("#workBody").value=d.body||"";
      $("#markPremium").checked=!!d.premium;
      showToast("Draft loaded");
    }
  }
});

function enterJesma(){
  const app=$("#app"), splash=$("#splash");
  if(app) app.classList.remove("hidden");
  if(splash){ splash.classList.add("leaving"); setTimeout(()=>{ if(splash.parentNode) splash.parentNode.removeChild(splash); },650); }
}
$("#enterApp").onclick=enterJesma;
setTimeout(enterJesma,1900);

$("#readerBack").onclick=closeReader;
$("#readerModal").addEventListener("click",e=>{ if(e.target===$("#readerModal")) closeReader(); });
$("#readerSave").onclick=()=>currentWork&&toggleSave(currentWork.id);
$("#readerLike").onclick=()=>currentWork&&toggleLike(currentWork.id);
$("#readerTip").onclick=tipAuthor;
$("#fontDown").onclick=()=>{ fontSize=Math.max(14,fontSize-1); $("#readerBody").style.fontSize=fontSize+"px"; };
$("#fontUp").onclick=()=>{ fontSize=Math.min(28,fontSize+1); $("#readerBody").style.fontSize=fontSize+"px"; };
$$(".chip-btn[data-theme]").forEach(b=>{ b.onclick=()=>{ readerTheme=b.dataset.theme; applyReaderTheme(); }; });
$("#fontFamily").onchange=e=>{ fontFamily=e.target.value; applyReaderTheme(); };
$("#markFinished").onclick=markFinished;
$("#unlockPremiumFromGate").onclick=()=>openPremiumModal(false);
$("#closeGate").onclick=closeReader;

$("#commentForm").onsubmit=e=>{
  e.preventDefault();
  if(!currentWork||P().tier==="guest"){ showToast("Switch persona to comment"); return; }
  const t=$("#commentInput").value.trim(); if(!t) return;
  state.comments[currentWork.id]=state.comments[currentWork.id]||[];
  state.comments[currentWork.id].push({author:P().name,text:t});
  persist(); $("#commentInput").value=""; openReader(currentWork.id); showToast("Response added");
};

$("#searchInput").addEventListener("input",renderDiscover);
$("#sortSelect").onchange=renderDiscover;
$("#clearSearch").onclick=()=>{ $("#searchInput").value=""; renderDiscover(); };
$("#saveDraft").onclick=saveCurrentDraft;
$("#publishForm").onsubmit=publishWork;
$("#openPost").onclick=postCommunity;
$("#editProfile").onclick=editProfile;
$("#resetDemo").onclick=resetDemo;
$("#themeToggle").onclick=toggleTheme;
$("#openPremium").onclick=()=>openPremiumModal(false);
$("#openPremiumProfile").onclick=()=>openPremiumModal(P().isWriter);
$("#openWriterPremium").onclick=()=>openPremiumModal(true);
$("#openAccountMenu").onclick=()=>setView("profile");
$("#accountSwitch").onclick=()=>setView("profile");
$("#dialogClose").onclick=closeDialog;
$("#genericModal").addEventListener("click",e=>{ if(e.target===$("#genericModal")) closeDialog(); });

$("#authorName").value=P().name;

/* PWA install */
let deferredPrompt=null;
window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault(); deferredPrompt=e; $("#installBtn").classList.remove("hidden");
});
$("#installBtn").onclick=()=>{
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  deferredPrompt.userChoice.finally(()=>{ deferredPrompt=null; $("#installBtn").classList.add("hidden"); });
};

window.addEventListener("online",()=>$("#connectionState").innerHTML="<i></i> Demo");
window.addEventListener("offline",()=>$("#connectionState").innerHTML="<i></i> Offline");

window.onerror=(msg,src,line)=>{
  const box=$("#startupError");
  if(box){ box.classList.remove("hidden"); $("#startupErrorText").textContent=String(msg)+(line?` (line ${line})`:""); }
};

/* Service worker registration (PWA) — only on http/https */
if("serviceWorker" in navigator && (location.protocol==="http:"||location.protocol==="https:")){
  navigator.serviceWorker.register("./sw.js").catch(()=>{});
}

refreshAll();
