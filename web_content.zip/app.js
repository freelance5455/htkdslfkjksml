(() => {
  const $ = id => document.getElementById(id);
  const config = window.KF_CONFIG || {};
  let supabaseClient = null, products = [], cart = [];
  const isConfigured = () => window.supabase && config.SUPABASE_URL &&
    !config.SUPABASE_URL.includes("YOUR-PROJECT") &&
    config.SUPABASE_ANON_KEY && !config.SUPABASE_ANON_KEY.includes("YOUR_");

  function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
  function money(n){return new Intl.NumberFormat("fa-AF").format(Number(n||0))+" افغانی"}
  function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}

  async function loadProducts(){
    if(!isConfigured()){
      $("connection").textContent="نیازمند تنظیم اتصال آنلاین";
      $("connection").className="status offline";
      $("products").innerHTML='<div class="loading">برای نمایش محصولات واقعی، اطلاعات پروژه Supabase در فایل config.js تنظیم شود. راهنمای کامل در README موجود است.</div>';
      return;
    }
    try{
      supabaseClient=window.supabase.createClient(config.SUPABASE_URL,config.SUPABASE_ANON_KEY);
      const {data,error}=await supabaseClient.from(config.TABLE_PRODUCTS).select("*").order("created_at",{ascending:false});
      if(error) throw error;
      products=data||[];
      $("connection").textContent="متصل به فروشگاه آنلاین";
      $("connection").className="status online";
      renderProducts();
    }catch(e){
      console.error(e);
      $("connection").textContent="خطا در اتصال";
      $("connection").className="status offline";
      $("products").innerHTML='<div class="loading">اتصال برقرار نشد. تنظیمات Supabase و دسترسی جدول را بررسی کنید.</div>';
    }
  }
  function renderProducts(){
    const q=$("searchInput").value.trim().toLowerCase(), sort=$("sortSelect").value;
    let list=products.filter(p=>(p.name||"").toLowerCase().includes(q)||(p.description||"").toLowerCase().includes(q));
    if(sort==="priceAsc") list.sort((a,b)=>Number(a.price)-Number(b.price));
    if(sort==="priceDesc") list.sort((a,b)=>Number(b.price)-Number(a.price));
    $("products").innerHTML=list.length?list.map((p,i)=>`
      <article class="product-card">
        <div class="product-image">${p.image_url?`<img loading="lazy" src="${escapeHtml(p.image_url)}" alt="${escapeHtml(p.name)}">`:"✦"}</div>
        <div class="product-info"><h3>${escapeHtml(p.name||"محصول")}</h3>
        <p>${escapeHtml(p.description||"محصول با کیفیت از کهکشان فیشن")}</p>
        <div class="price">${money(p.price)}</div>
        <div class="card-actions"><button class="small-btn" data-add="${i}">افزودن به سبد</button><button class="small-btn secondary" data-detail="${i}">جزئیات</button></div></div>
      </article>`).join(""):'<div class="loading">محصولی پیدا نشد.</div>';
    $("products").querySelectorAll("[data-add]").forEach(b=>b.addEventListener("click",()=>{cart.push(list[Number(b.dataset.add)]);$("cartCount").textContent=cart.length;toast("به سبد خرید اضافه شد")}));
    $("products").querySelectorAll("[data-detail]").forEach(b=>b.addEventListener("click",()=>showDetail(list[Number(b.dataset.detail)])));
  }
  function showDetail(p){
    $("productDetail").innerHTML=`<h2>${escapeHtml(p.name)}</h2><p>${escapeHtml(p.description||"")}</p><p class="total">${money(p.price)}</p>
      <div class="muted">روش‌های پرداخت و شماره‌های پرداخت پس از تنظیم امن اطلاعات فروشگاه نمایش داده می‌شوند.</div>`;
    $("productDialog").showModal();
  }
  function showCart(){
    $("cartItems").innerHTML=cart.length?cart.map(p=>`<p>${escapeHtml(p.name)} — ${money(p.price)}</p>`).join(""):"سبد خرید خالی است.";
    $("cartTotal").textContent="مجموع: "+money(cart.reduce((s,p)=>s+Number(p.price||0),0));
    $("cartDialog").showModal();
  }
  $("searchInput").addEventListener("input",renderProducts);
  $("sortSelect").addEventListener("change",renderProducts);
  $("settingsBtn").addEventListener("click",()=>$("settingsDialog").showModal());
  $("cartBtn").addEventListener("click",showCart);
  $("languageSelect").addEventListener("change",e=>{const v=e.target.value;document.documentElement.lang=v;document.documentElement.dir="rtl";toast("زبان انتخاب شد؛ ترجمه کامل پس از افزودن فایل‌های زبان فعال می‌شود.")});
  $("langBtn").addEventListener("click",()=>$("settingsDialog").showModal());
  loadProducts();
  if("serviceWorker" in navigator && location.protocol.startsWith("http")) window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(console.warn));
})();