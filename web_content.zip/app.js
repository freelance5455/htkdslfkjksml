'use strict';
function validateProblem(p){
 if(!p||!Array.isArray(p.tasks)||!p.tasks.length) throw Error('حداقل یک کار لازم است.');
 if(p.tasks.length>18) throw Error('حداکثر ۱۸ کار در این نمونه پشتیبانی می‌شود.');
 const num=(v,n)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<0)throw Error(n+' باید عدد متناهی و نامنفی باشد.');return v};
 num(p.budget,'بودجه');num(p.risk_limit??100,'حد ریسک');num(p.risk_weight??.25,'وزن ریسک');
 const ids=new Set();
 for(const t of p.tasks){if(!t||typeof t.id!=='string'||!t.id.trim()||ids.has(t.id))throw Error('شناسهٔ کارها باید یکتا و غیرخالی باشد.');ids.add(t.id);num(t.cost,t.id+'.cost');num(t.value,t.id+'.value');num(t.risk??0,t.id+'.risk');if(!Array.isArray(t.requires??[]))throw Error('requires باید فهرست باشد.');}
 if(!Number.isInteger(p.max_tasks??p.tasks.length)||(p.max_tasks??p.tasks.length)<1||(p.max_tasks??p.tasks.length)>p.tasks.length)throw Error('حداکثر تعداد کارها نامعتبر است.');
 const byId=Object.fromEntries(p.tasks.map(t=>[t.id,t])), done=new Set(), active=new Set();
 function visit(id){if(active.has(id))throw Error('وابستگی دوری مجاز نیست.');if(done.has(id))return;active.add(id);for(const d of byId[id].requires??[]){if(!ids.has(d)||d===id)throw Error('وابستگی نامعتبر برای '+id);visit(d)}active.delete(id);done.add(id)}
 for(const id of ids)visit(id);
 return {tasks:p.tasks,budget:p.budget,riskLimit:p.risk_limit??100,maxTasks:p.max_tasks??p.tasks.length,riskWeight:p.risk_weight??.25};
}
function portfolio(chosen,p){const ids=new Set(chosen.map(t=>t.id)),cost=chosen.reduce((s,t)=>s+t.cost,0),value=chosen.reduce((s,t)=>s+t.value,0),risk=chosen.reduce((s,t)=>s+(t.risk??0),0),deps=chosen.every(t=>(t.requires??[]).every(d=>ids.has(d)));return {task_ids:[...ids].sort(),task_names:chosen.map(t=>t.name||t.id),cost,value,risk,utility:value-p.riskWeight*risk,feasible:deps&&cost<=p.budget+1e-9&&risk<=p.riskLimit+1e-9&&chosen.length<=p.maxTasks,dependencies_ok:deps}}
function optimize(p0){const p=validateProblem(p0);let best=null, feasibleCount=0;for(let mask=0;mask<(1<<p.tasks.length);mask++){const chosen=p.tasks.filter((_,i)=>mask&(1<<i)),x=portfolio(chosen,p);if(x.feasible){feasibleCount++;if(!best||x.utility>best.utility+1e-9||(Math.abs(x.utility-best.utility)<1e-9&&x.cost<best.cost))best=x;}}
 const sorted=[...p.tasks].sort((a,b)=>((b.cost?b.value/b.cost:Infinity)-(a.cost?a.value/a.cost:Infinity))||b.value-a.value||a.id.localeCompare(b.id));let picked=[];for(const t of sorted){const x=portfolio([...picked,t],p);if(x.feasible)picked.push(t)}const baseline=portfolio(picked,p);return {winner:best,baseline,feasibleCount,subsets:1<<p.tasks.length,delta:best?best.utility-baseline.utility:null};}
if(typeof module!=='undefined')module.exports={validateProblem,optimize};
