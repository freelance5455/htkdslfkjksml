(() => {
"use strict";
const STORAGE_KEY="codelog_two_track_v1";
const GYM_DAYS=[
 {day:1,name:"Push A",focus:"Chest, Shoulders, Triceps — Strength Focus",items:["Bench Press|4 sets × 5-6 reps|3min","Overhead Press|4 sets × 6-8 reps|2min","Incline Dumbbell Press|3 sets × 8-10 reps|90s","Lateral Raises|4 sets × 12-15 reps|45s","Tricep Dips|3 sets × 8-10 reps|60s"]},
 {day:2,name:"Pull A",focus:"Back, Biceps — Strength Focus",items:["Deadlift|4 sets × 5 reps|3min","Barbell Row|4 sets × 6-8 reps|2min","Pull-ups|3 sets × 6-10 reps|90s","Face Pulls|3 sets × 15-20 reps|45s","Barbell Curls|3 sets × 8-10 reps|60s"]},
 {day:3,name:"Legs A",focus:"Quads, Glutes, Calves — Quad Focus",items:["Squat|4 sets × 6-8 reps|3min","Leg Press|4 sets × 10-12 reps|90s","Leg Extensions|3 sets × 12-15 reps|60s","Walking Lunges|3 sets × 12/leg|60s","Standing Calf Raises|4 sets × 12-15 reps|45s"]},
 {day:4,name:"Push B",focus:"Chest, Shoulders, Triceps — Hypertrophy Focus",items:["Incline Bench Press|4 sets × 8-10 reps|90s","Dumbbell Shoulder Press|4 sets × 10-12 reps|60s","Cable Flyes|3 sets × 12-15 reps|45s","Lateral Raises|4 sets × 15-20 reps|30s","Tricep Pushdowns|3 sets × 12-15 reps|45s","Overhead Tricep Extension|3 sets × 12-15 reps|45s"]},
 {day:5,name:"Pull B",focus:"Back, Biceps — Hypertrophy Focus",items:["Lat Pulldown|4 sets × 10-12 reps|60s","Cable Rows|4 sets × 10-12 reps|60s","Dumbbell Rows|3 sets × 10-12 reps|60s","Rear Delt Flyes|3 sets × 15-20 reps|45s","Hammer Curls|3 sets × 12-15 reps|45s","Incline Dumbbell Curls|3 sets × 12-15 reps|45s"]},
 {day:6,name:"Legs B",focus:"Hamstrings, Glutes, Calves — Hip Hinge Focus",items:["Romanian Deadlift|4 sets × 8-10 reps|2min","Hip Thrust|4 sets × 10-12 reps|90s","Leg Curls|4 sets × 12-15 reps|60s","Bulgarian Split Squats|3 sets × 10-12/leg|60s","Seated Calf Raises|4 sets × 15-20 reps|45s"]}
];
const XP={easy:20,medium:40,hard:70,boss:120};
const TRACKS={
  programming:{label:"Computer Programming",short:"PROGRAMMING",color:"green",ranks:[
    {name:"Newbie Coder",short:"NC",xp:0},{name:"Starter Coder",short:"SC",xp:200},{name:"Grinder",short:"GR",xp:500},
    {name:"Tryhard Coder",short:"TC",xp:900},{name:"Geek Coder",short:"GC",xp:1400},{name:"Code Beast",short:"CB",xp:2100},{name:"Legendary Coder",short:"LC",xp:3000}]},
  theory:{label:"Theoretical Subjects",short:"THEORY",color:"amber",ranks:[
    {name:"Fresh Reader",short:"FR",xp:0},{name:"Normal Theory",short:"NT",xp:200},{name:"Steady Learner",short:"SL",xp:500},
    {name:"Theory Runner",short:"TR",xp:900},{name:"Theory Tryhard",short:"TT",xp:1400},{name:"Geek of Theory",short:"GT",xp:2100},{name:"Theory Legend",short:"TL",xp:3000}]}
};
const sampleP={date:"YYYY-MM-DD",track:"programming",title:"Daily Programming Pack",tasks:[
 {title:"Learn one C++/STL concept",description:"Study one practical concept and write a tiny example.",difficulty:"medium",category:"C++"},
 {title:"Solve 2 DSA problems",description:"Solve, test, and review both solutions.",difficulty:"hard",category:"DSA"},
 {title:"Review one wrong answer",description:"Identify the bug and write the lesson learned.",difficulty:"easy",category:"Debugging"}]};
const sampleT={date:"YYYY-MM-DD",track:"theory",title:"Daily Theory Pack",tasks:[
 {title:"Read one focused section",description:"Read actively and mark the important ideas.",difficulty:"medium",category:"Reading"},
 {title:"Recall yesterday's topic",description:"Explain the topic without looking at notes.",difficulty:"easy",category:"Revision"},
 {title:"Write 5 short-answer questions",description:"Create and answer questions from today's material.",difficulty:"medium",category:"Active Recall"}]};
const qs=(s,p=document)=>p.querySelector(s),qsa=(s,p=document)=>[...p.querySelectorAll(s)];
const uid=()=>`${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`;
const dateKey=(d=new Date())=>{const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0"),x=String(d.getDate()).padStart(2,"0");return `${y}-${m}-${x}`};
const monthKey=(d=new Date())=>dateKey(d).slice(0,7);
const esc=v=>String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");
const fmtMonth=k=>{if(!k)return "—";const [y,m]=k.split("-").map(Number);return new Intl.DateTimeFormat("en",{month:"long",year:"numeric"}).format(new Date(y,m-1,1))};

function trackBlank(){return {xp:0,totalCompleted:0,perfectDays:0,bestStreak:0,currentStreak:0,lastActiveDate:null};}
function defaultState(){return {version:1,gym:{weekKey:null,completed:{}},profile:{name:"Coder",title:"Independent Learner"},config:{perfectDayBonus:75},currentSeason:monthKey(),tracks:{programming:trackBlank(),theory:trackBlank()},days:{},history:[],activity:[{id:uid(),ts:Date.now(),title:"System initialized",detail:"Two-track progression is ready.",xp:0,track:null}]};}
function normalizeDay(day){return day&&typeof day==="object"?day:{programming:{tasks:[],perfectBonusAwarded:false,xpEarned:0},theory:{tasks:[],perfectBonusAwarded:false,xpEarned:0}}}
function migrate(input){
 const s=defaultState(); if(!input||typeof input!=="object")return s;
 s.profile=Object.assign(s.profile,input.profile||{});s.config=Object.assign(s.config,input.config||{});s.gym=Object.assign({weekKey:null,completed:{}},input.gym||{});
 if(input.tracks){for(const t of ["programming","theory"])s.tracks[t]=Object.assign(trackBlank(),input.tracks[t]||{});}
 else if(input.season){s.tracks.programming.xp=Number(input.season.xp||0);s.tracks.programming.totalCompleted=Number(input.season.totalCompleted||0);s.tracks.programming.perfectDays=Number(input.season.perfectDays||0);s.tracks.programming.bestStreak=Number(input.season.bestStreak||0);}
 if(input.days){
   for(const [k,v] of Object.entries(input.days)){
     const d={programming:{tasks:[],perfectBonusAwarded:false,xpEarned:0},theory:{tasks:[],perfectBonusAwarded:false,xpEarned:0}};
     if(v?.programming)d.programming=v.programming;
     else if(Array.isArray(v?.tasks))d.programming.tasks=v.tasks;
     if(v?.theory)d.theory=v.theory;
     s.days[k]=d;
   }
 }
 s.currentSeason=input.currentSeason||monthKey();s.history=Array.isArray(input.history)?input.history:[];s.activity=Array.isArray(input.activity)?input.activity:[];
 if(input.streak){s.tracks.programming.currentStreak=input.streak.current||0;s.tracks.programming.lastActiveDate=input.streak.lastActiveDate||null;s.tracks.programming.bestStreak=input.streak.best||0;}
 return s;
}
function load(){try{const raw=localStorage.getItem(STORAGE_KEY);return raw?migrate(JSON.parse(raw)):defaultState()}catch{return defaultState()}}
let state=load();
function save(){localStorage.setItem(STORAGE_KEY,JSON.stringify(state))}
function ensureDay(key=dateKey()){if(!state.days[key])state.days[key]={programming:{tasks:[],perfectBonusAwarded:false,xpEarned:0},theory:{tasks:[],perfectBonusAwarded:false,xpEarned:0}};return state.days[key]}
function getDayTrack(track,key=dateKey()){const d=ensureDay(key);if(!d[track])d[track]={tasks:[],perfectBonusAwarded:false,xpEarned:0};return d[track]}
function getRank(track,xp=state.tracks[track].xp){let r=TRACKS[track].ranks[0],i=0;TRACKS[track].ranks.forEach((x,n)=>{if(xp>=x.xp){r=x;i=n}});return {...r,index:i}}
function rankProgress(track){const t=state.tracks[track],cur=getRank(track),next=TRACKS[track].ranks[cur.index+1];if(!next)return {current:cur,next:null,percent:100,within:t.xp-cur.xp,span:0,needed:0};const span=next.xp-cur.xp,within=t.xp-cur.xp;return {current:cur,next,percent:Math.max(0,Math.min(100,within/span*100)),within,span,needed:next.xp-t.xp}}
function addActivity(title,detail,xp=0,track=null){state.activity.unshift({id:uid(),ts:Date.now(),title,detail,xp,track});state.activity=state.activity.slice(0,100)}
function updateStreak(track){
 const t=state.tracks[track],today=dateKey();if(t.lastActiveDate===today)return;
 const y=new Date();y.setDate(y.getDate()-1);t.currentStreak=t.lastActiveDate===dateKey(y)?t.currentStreak+1:1;t.lastActiveDate=today;t.bestStreak=Math.max(t.bestStreak,t.currentStreak);
}
function checkPerfect(track){
 const day=getDayTrack(track),t=state.tracks[track];if(!day.tasks.length||!day.tasks.every(x=>x.completed)||day.perfectBonusAwarded)return;
 day.perfectBonusAwarded=true;const b=Number(state.config.perfectDayBonus||0);t.xp+=b;t.perfectDays++;day.xpEarned+=b;addActivity("Perfect track cleared",`${TRACKS[track].label} — bonus awarded`,b,track);toast(`${TRACKS[track].label}: +${b} perfect bonus`,"success");
}
function toggleTask(track,id){
 const day=getDayTrack(track),task=day.tasks.find(x=>x.id===id);if(!task)return;
 const old=getRank(track).index;
 if(!task.completed){task.completed=true;task.completedAt=Date.now();const xp=Number(task.xp||0),t=state.tracks[track];t.xp+=xp;t.totalCompleted++;day.xpEarned+=xp;updateStreak(track);addActivity("Task completed",task.title,xp,track);checkPerfect(track);toast(`+${xp} XP · ${TRACKS[track].label}`,"success")}
 else{const xp=Number(task.xp||0),t=state.tracks[track];task.completed=false;task.completedAt=null;t.xp=Math.max(0,t.xp-xp);t.totalCompleted=Math.max(0,t.totalCompleted-1);day.xpEarned=Math.max(0,day.xpEarned-xp);if(day.perfectBonusAwarded){const b=Number(state.config.perfectDayBonus||0);day.perfectBonusAwarded=false;t.xp=Math.max(0,t.xp-b);t.perfectDays=Math.max(0,t.perfectDays-1);day.xpEarned=Math.max(0,day.xpEarned-b)}addActivity("Task reopened",task.title,-xp,track)}
 save();const now=getRank(track).index;if(now>old)showRankUp(track,TRACKS[track].ranks[now]);renderAll();
}
function addTask(track,input){const diff=["easy","medium","hard","boss"].includes(input.difficulty)?input.difficulty:"medium";const task={id:uid(),title:String(input.title||"Untitled Task").trim(),description:String(input.description||"").trim(),difficulty:diff,category:String(input.category||"General").trim()||"General",xp:Number(input.xp)>0?Number(input.xp):XP[diff],completed:false,completedAt:null,createdAt:Date.now()};getDayTrack(track).tasks.push(task);addActivity("Task added",task.title,0,track);save();return task}
function deleteTask(track,id){const day=getDayTrack(track),task=day.tasks.find(x=>x.id===id);if(!task)return;if(task.completed){toast("Reopen the task before deleting it.","error");return}day.tasks=day.tasks.filter(x=>x.id!==id);save();renderAll()}
function resetToday(track){const day=getDayTrack(track);if(day.tasks.some(x=>x.completed)){toast("Reopen completed tasks before resetting.","error");return}day.tasks=[];day.perfectBonusAwarded=false;day.xpEarned=0;save();renderAll();toast(`${TRACKS[track].label} board reset.`)}
function importPack(track,raw,replace){
 let parsed=JSON.parse(raw),tasks=Array.isArray(parsed)?parsed:parsed.tasks;if(!Array.isArray(tasks)||!tasks.length)throw Error("No valid tasks found.");
 const day=getDayTrack(track);if(replace){if(day.tasks.some(x=>x.completed))throw Error("Cannot replace while completed tasks exist.");day.tasks=[]}
 tasks.filter(Boolean).forEach(x=>{if(typeof x==="string")addTask(track,{title:x,difficulty:"medium",category:"General"});else if(x.title)addTask(track,x)});
 addActivity("Task pack imported",`${tasks.length} tasks added to ${TRACKS[track].label}`,0,track);save();return tasks.length;
}
function archive(){
 if(!state.currentSeason)return;const exists=state.history.find(x=>x.season===state.currentSeason),record={season:state.currentSeason,programming:{xp:state.tracks.programming.xp,rank:getRank("programming").name},theory:{xp:state.tracks.theory.xp,rank:getRank("theory").name}};
 if(exists)Object.assign(exists,record);else state.history.unshift(record);save();
}
function ensureSeason(){const now=monthKey();if(state.currentSeason!==now){archive();state.currentSeason=now;for(const t of ["programming","theory"]){state.tracks[t].xp=0;state.tracks[t].totalCompleted=0;state.tracks[t].perfectDays=0}addActivity("New monthly season",fmtMonth(now),0,null);save()}}
function gymWeekKey(d=new Date()){
  const x=new Date(d.getFullYear(),d.getMonth(),d.getDate());
  const day=x.getDay(); const diff=day===0?-6:1-day; x.setDate(x.getDate()+diff); return dateKey(x);
}
function gymWeekLabel(){const k=gymWeekKey(),start=new Date(`${k}T00:00:00`),end=new Date(start);end.setDate(end.getDate()+5);return `${new Intl.DateTimeFormat("en",{month:"short",day:"numeric"}).format(start)} — ${new Intl.DateTimeFormat("en",{month:"short",day:"numeric",year:"numeric"}).format(end)}`}
function ensureGymWeek(){const k=gymWeekKey();if(!state.gym)state.gym={weekKey:k,completed:{}};if(state.gym.weekKey!==k){state.gym.weekKey=k;state.gym.completed={};save();}}
function toggleGymDay(day){ensureGymWeek();state.gym.completed[day]=!state.gym.completed[day];save();renderGym();}
function renderGym(){
 ensureGymWeek();
 const done=GYM_DAYS.filter(x=>state.gym.completed[x.day]).length,pct=Math.round(done/GYM_DAYS.length*100);
 qs("#gymWeekLabel").textContent=gymWeekLabel();qs("#gymProgressText").textContent=`${done} / ${GYM_DAYS.length} days`;qs("#gymCompletedText").textContent=done;qs("#gymRemainingText").textContent=GYM_DAYS.length-done;qs("#gymStatusText").textContent=done===GYM_DAYS.length?"WEEK CLEARED":"IN PROGRESS";qs("#gymPercent").textContent=`${pct}%`;qs("#gymProgressBar").style.width=`${pct}%`;
 qs("#gymGrid").innerHTML=GYM_DAYS.map(w=>`<article class="gym-day ${state.gym.completed[w.day]?"completed":""}"><div class="gym-day-head"><div class="gym-day-info"><div class="gym-day-number">D${w.day}</div><div><h3>${esc(w.name)}</h3><p>${esc(w.focus)}</p></div></div><button class="gym-check" data-gym-day="${w.day}" aria-label="Mark Day ${w.day} complete">${state.gym.completed[w.day]?"✓":""}</button></div><div class="gym-exercises">${w.items.map(v=>{const [name,reps,rest]=v.split("|");return `<div class="gym-exercise"><div><strong>${esc(name)}</strong><span>${esc(reps)}</span></div><div class="gym-rest">${esc(rest)}</div></div>`}).join("")}</div><div class="gym-footer">DAY ${w.day} // ${state.gym.completed[w.day]?"COMPLETED":"NOT COMPLETED"}</div></article>`).join("");
}

function renderHeader(){qs("#todayStamp").textContent=new Intl.DateTimeFormat("en",{weekday:"short",month:"short",day:"numeric"}).format(new Date());qs("#pageTitle").textContent=document.querySelector(".nav-item.active")?.textContent.trim().replace(/^\d+\s*/,"")||"Dashboard";qs("#globalStreak").textContent=Math.max(state.tracks.programming.currentStreak,state.tracks.theory.currentStreak)}
function renderTrackCard(track){
 const p=rankProgress(track),t=state.tracks[track],d=getDayTrack(track),done=d.tasks.filter(x=>x.completed).length;
 qs(`#${track}Rank`).textContent=p.current.name;qs(`#${track}Short`).textContent=p.current.short;qs(`#${track}XpText`).textContent=p.next?`${p.within} / ${p.span} XP`:`${t.xp} XP`;qs(`#${track}Percent`).textContent=p.next?`${Math.round(p.percent)}%`:"MAX";qs(`#${track}XpBar`).style.width=`${p.percent}%`;qs(`#${track}Next`).textContent=p.next?`${p.needed} XP to ${p.next.name}`:"Highest rank reached";qs(`#${track}Today`).textContent=`${done} / ${d.tasks.length}`;qs(`#${track}TodayXp`).textContent=d.xpEarned;qs(`#${track}Streak`).textContent=t.currentStreak;
 renderLadder(track,qs(`#${track}Ladder`));
}
function renderLadder(track,wrap){const p=rankProgress(track);wrap.innerHTML=TRACKS[track].ranks.map((r,i)=>`<div class="ladder-node ${i<=p.current.index?"reached":""} ${i===p.current.index?"current":""}"><div class="letter">${r.short}</div><small>${esc(r.name)}</small></div>`).join("")}
function renderDashboard(){
 renderTrackCard("programming");renderTrackCard("theory");
 const dp=getDayTrack("programming"),dt=getDayTrack("theory"),all=[...dp.tasks,...dt.tasks],done=all.filter(x=>x.completed).length,pct=all.length?Math.round(done/all.length*100):0;
 qs("#combinedPercent").textContent=`${pct}%`;qs("#combinedRing").style.background=`conic-gradient(var(--green) ${pct*3.6}deg,#ffffff09 0deg)`;qs("#combinedDone").textContent=`${done} / ${all.length}`;qs("#combinedXp").textContent=dp.xpEarned+dt.xpEarned;qs("#combinedBonus").textContent=(dp.perfectBonusAwarded?state.config.perfectDayBonus:0)+(dt.perfectBonusAwarded?state.config.perfectDayBonus:0);qs("#dailyStatus").textContent=all.length&&done===all.length?"CLEARED":"ACTIVE";
 const msg=done===0?"Start with one focused task in either track.":dp.tasks.some(x=>x.completed)&&dt.tasks.some(x=>x.completed)?"Both tracks moved today. Keep the chain alive.": "Good start. Move the other track when you have the focus.";
 qs("#dailyMessage").textContent=msg;renderActivity();
}
function renderActivity(){const w=qs("#activityList");if(!state.activity.length){w.innerHTML='<div class="empty-state">No activity yet.</div>';return}w.innerHTML=state.activity.slice(0,8).map(x=>`<div class="activity-item"><div class="activity-dot"></div><div class="activity-text"><strong>${esc(x.title)}</strong><span>${esc(x.detail)} · ${new Intl.DateTimeFormat("en",{month:"short",day:"numeric",hour:"numeric",minute:"2-digit"}).format(new Date(x.ts))}</span></div><div class="activity-xp">${x.xp?`${x.xp>0?"+":""}${x.xp} XP`:""}</div></div>`).join("")}
function renderTasks(track){
 const tasks=getDayTrack(track).tasks,filter=qs(`#${track}Filter`).value,q=qs(`#${track}Search`).value.trim().toLowerCase(),visible=tasks.filter(x=>(filter==="all"||(filter==="active"&&!x.completed)||(filter==="done"&&x.completed)||x.difficulty===filter)&&(!q||`${x.title} ${x.description} ${x.category}`.toLowerCase().includes(q))),done=tasks.filter(x=>x.completed).length;
 const t=state.tracks[track],p=rankProgress(track),s=qs(`#${track}Summary`);
 s.innerHTML=`<div class="summary-cell"><span>Current rank</span><strong>${esc(p.current.name)}</strong></div><div class="summary-cell"><span>Track XP</span><strong>${t.xp.toLocaleString()}</strong></div><div class="summary-cell"><span>Today completed</span><strong>${done} / ${tasks.length}</strong></div><div class="summary-cell"><span>XP remaining</span><strong>${tasks.filter(x=>!x.completed).reduce((a,x)=>a+Number(x.xp||0),0)}</strong></div>`;
 const w=qs(`#${track}TaskList`);if(!visible.length){w.innerHTML='<div class="empty-state">No tasks match this view. Add a task or import a pack.</div>';return}
 w.innerHTML=visible.map(x=>`<article class="task-item ${x.completed?"done":""}" data-task-id="${x.id}"><button class="task-check" data-action="toggle">${x.completed?"✓":""}</button><div class="task-main"><div class="task-title">${esc(x.title)}</div>${x.description?`<div class="task-desc">${esc(x.description)}</div>`:""}<div class="task-tags"><span class="tag ${x.difficulty}">${x.difficulty.toUpperCase()}</span><span class="tag">${esc(x.category)}</span></div></div><div class="task-side"><span class="task-xp">+${x.xp} XP</span><button class="task-menu" data-action="delete">⋮</button></div></article>`).join("");
}
function renderHistory(){
 const p=state.tracks.programming,t=state.tracks.theory;qs("#historyGrid").innerHTML=`<div class="record"><span>Programming lifetime XP</span><strong>${p.xp.toLocaleString()}</strong></div><div class="record"><span>Theory lifetime XP</span><strong>${t.xp.toLocaleString()}</strong></div><div class="record"><span>Programming rank</span><strong>${esc(getRank("programming").name)}</strong></div><div class="record"><span>Theory rank</span><strong>${esc(getRank("theory").name)}</strong></div>`;
 const b=qs("#historyTableBody");if(!state.history.length){b.innerHTML='<tr><td colspan="5" class="muted">No archived months yet.</td></tr>';return}b.innerHTML=state.history.map(x=>`<tr><td>${fmtMonth(x.season)}</td><td>${esc(x.programming.rank)}</td><td>${Number(x.programming.xp).toLocaleString()}</td><td>${esc(x.theory.rank)}</td><td>${Number(x.theory.xp).toLocaleString()}</td></tr>`).join("");
}
function renderChart(track){
 const data=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const day=state.days[dateKey(d)]?.[track];data.push({label:new Intl.DateTimeFormat("en",{weekday:"short"}).format(d),xp:day?.xpEarned||0})}
 const max=Math.max(1,...data.map(x=>x.xp));qs(`#${track}Chart`).innerHTML=data.map(x=>`<div class="bar-col"><div class="bar-track"><div class="bar-fill" style="height:${Math.max(2,x.xp/max*100)}%"></div></div><div class="bar-label">${x.label}</div></div>`).join("");
}
function renderAnalytics(){renderChart("programming");renderChart("theory");const w=qs("#calendarGrid"),items=[];for(let i=13;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);const k=dateKey(d),day=state.days[k],count=(day?.programming?.tasks||[]).filter(x=>x.completed).length+(day?.theory?.tasks||[]).filter(x=>x.completed).length;items.push(`<div class="calendar-day ${count?"active":""}"><strong>${new Intl.DateTimeFormat("en",{weekday:"short"}).format(d)}</strong><span>${count} done</span></div>`)}w.innerHTML=items.join("")}
function renderSettings(){qs("#settingName").value=state.profile.name;qs("#settingTitle").value=state.profile.title;qs("#settingPerfectBonus").value=state.config.perfectDayBonus}
function renderAll(){ensureSeason();ensureGymWeek();renderHeader();renderDashboard();renderGym();renderTasks("programming");renderTasks("theory");renderHistory();renderAnalytics();renderSettings()}
function showRankUp(track,rank){qs("#levelupTrack").textContent=`RANK UP // ${TRACKS[track].short}`;qs("#levelupRank").textContent=rank.short;qs("#levelupName").textContent=rank.name.toUpperCase();qs("#levelupOverlay").classList.add("show")}
function toast(msg,type=""){const x=document.createElement("div");x.className=`toast ${type}`;x.textContent=msg;qs("#toastContainer").appendChild(x);setTimeout(()=>x.remove(),3000)}
function openModal(id){qs("#modalBackdrop").classList.add("open");qs(id).classList.add("open");qs(id).setAttribute("aria-hidden","false")}
function closeModals(){qs("#modalBackdrop").classList.remove("open");qsa(".modal.open").forEach(x=>{x.classList.remove("open");x.setAttribute("aria-hidden","true")})}
let modalTrack="programming";
function prepareAdd(track){modalTrack=track;qs("#taskModalTitle").textContent=`Add ${TRACKS[track].label} Task`;qs("#taskTitleInput").value="";qs("#taskDescInput").value="";qs("#taskDifficultyInput").value="medium";qs("#taskXpInput").value="";qs("#taskCategoryInput").value="";openModal("#taskModal")}
function prepareImport(track){modalTrack=track;qs("#importModalTitle").textContent=`Import ${TRACKS[track].label} Pack`;qs("#importTextarea").value=JSON.stringify(track==="programming"?sampleP:sampleT,null,2);qs("#importResult").textContent="";openModal("#importModal")}
function switchView(v){qsa(".view").forEach(x=>x.classList.remove("active"));qsa(".nav-item").forEach(x=>x.classList.remove("active"));qs(`#view-${v}`).classList.add("active");qs(`.nav-item[data-view="${v}"]`).classList.add("active");renderHeader();if(innerWidth<=840)qs("#sidebar").classList.remove("open")}
function exportBackup(){const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=`codelog-backup-${dateKey()}.json`;a.click();URL.revokeObjectURL(url);toast("Backup exported.","success")}
function importBackup(file){const r=new FileReader();r.onload=()=>{try{state=migrate(JSON.parse(r.result));save();renderAll();toast("Backup imported.","success")}catch{toast("Invalid backup file.","error")}};r.readAsText(file)}

qsa(".nav-item").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.view)));
qsa("[data-jump]").forEach(b=>b.addEventListener("click",()=>switchView(b.dataset.jump)));
qs("#gymGrid").addEventListener("click",e=>{const b=e.target.closest("[data-gym-day]");if(b)toggleGymDay(Number(b.dataset.gymDay));});
qs("#menuBtn").addEventListener("click",()=>qs("#sidebar").classList.toggle("open"));
qsa("[data-add-track]").forEach(b=>b.addEventListener("click",()=>prepareAdd(b.dataset.addTrack)));
qsa("[data-import-track]").forEach(b=>b.addEventListener("click",()=>prepareImport(b.dataset.importTrack)));
qsa("[data-reset-track]").forEach(b=>b.addEventListener("click",()=>resetToday(b.dataset.resetTrack)));
["programming","theory"].forEach(track=>{
 qs(`#${track}Filter`).addEventListener("change",()=>renderTasks(track));qs(`#${track}Search`).addEventListener("input",()=>renderTasks(track));
 qs(`#${track}TaskList`).addEventListener("click",e=>{const a=e.target.closest("[data-action]"),item=e.target.closest("[data-task-id]");if(!a||!item)return;if(a.dataset.action==="toggle")toggleTask(track,item.dataset.taskId);else deleteTask(track,item.dataset.taskId)});
});
qs("#quickAddBtn").addEventListener("click",()=>prepareAdd("programming"));
qsa(".modal-close").forEach(b=>b.addEventListener("click",closeModals));qs("#modalBackdrop").addEventListener("click",closeModals);
qs("#saveTaskBtn").addEventListener("click",()=>{const title=qs("#taskTitleInput").value.trim();if(!title)return toast("Task title is required.","error");addTask(modalTrack,{title,description:qs("#taskDescInput").value.trim(),difficulty:qs("#taskDifficultyInput").value,xp:qs("#taskXpInput").value,category:qs("#taskCategoryInput").value.trim()});closeModals();renderAll();toast("Task added.","success")});
qs("#processImportBtn").addEventListener("click",()=>{try{const n=importPack(modalTrack,qs("#importTextarea").value,qs("#replaceTasksToggle").checked);qs("#importResult").textContent=`${n} tasks imported successfully.`;renderAll();toast(`${n} tasks imported.`,"success");setTimeout(closeModals,400)}catch(e){qs("#importResult").textContent=e.message;toast(e.message,"error")}});
qs("#clearLogBtn").addEventListener("click",()=>{state.activity=[];save();renderActivity();toast("Activity cleared.")});
qs("#saveProfileBtn").addEventListener("click",()=>{state.profile.name=qs("#settingName").value.trim()||"Coder";state.profile.title=qs("#settingTitle").value.trim()||"Independent Learner";save();renderAll();toast("Profile saved.","success")});
qs("#saveBonusBtn").addEventListener("click",()=>{state.config.perfectDayBonus=Math.max(0,Number(qs("#settingPerfectBonus").value)||0);save();renderAll();toast("Perfect bonus updated.","success")});
["#exportBackupBtn","#exportBtnSettings"].forEach(s=>qs(s).addEventListener("click",exportBackup));
qs("#importBackupInput").addEventListener("change",e=>{if(e.target.files[0])importBackup(e.target.files[0]);e.target.value=""});
qs("#wipeBtn").addEventListener("click",()=>{if(prompt('Type "RESET" to wipe all CODE//LOG data.')!=="RESET")return;localStorage.removeItem(STORAGE_KEY);state=defaultState();save();renderAll();toast("All local data wiped.")});
qs("#closeLevelBtn").addEventListener("click",()=>qs("#levelupOverlay").classList.remove("show"));qs("#levelupOverlay").addEventListener("click",e=>{if(e.target.id==="levelupOverlay")e.currentTarget.classList.remove("show")});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModals()});
ensureDay();renderAll();
})();


/* Mobile APK drawer helpers */
(() => {
  const sidebar = document.getElementById("sidebar");
  const menu = document.getElementById("menuBtn");
  if (!sidebar || !menu) return;

  document.addEventListener("click", (e) => {
    if (window.innerWidth > 840) return;
    if (!sidebar.classList.contains("open")) return;
    if (sidebar.contains(e.target) || menu.contains(e.target)) return;
    sidebar.classList.remove("open");
  });

  document.querySelectorAll(".nav-item").forEach(btn => {
    btn.addEventListener("click", () => {
      if (window.innerWidth <= 840) sidebar.classList.remove("open");
    });
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth > 840) sidebar.classList.remove("open");
  });
})();
