const cars=[
 {name:"Maruti Suzuki Swift",type:"Hatchback · 4 Seater",rate:14,icon:"🚗"},
 {name:"Hyundai Verna",type:"Sedan · 4 Seater",rate:18,icon:"🚘"},
 {name:"Toyota Innova",type:"SUV · 7 Seater",rate:26,icon:"🚙"},
 {name:"Toyota Fortuner",type:"SUV · 7 Seater",rate:40,icon:"🚙"}
];
let selectedCar=cars[0], fare=450, bookingId="DG"+Math.floor(100000+Math.random()*900000);

document.querySelectorAll(".role").forEach(btn=>btn.addEventListener("click",()=>{
 document.querySelectorAll(".role").forEach(x=>x.classList.remove("active"));
 document.querySelectorAll(".role-page").forEach(x=>x.classList.remove("active"));
 btn.classList.add("active"); document.getElementById(btn.dataset.role).classList.add("active");
}));

function renderCars(){
 const box=document.getElementById("cars");
 box.innerHTML=cars.map((c,i)=>`<div class="car-option ${c===selectedCar?'selected':''}" onclick="selectCar(${i})">
 <div class="car-img">${c.icon}</div><div class="grow"><b>${c.name}</b><div class="muted">${c.type}</div><small>⭐ 4.7 · ₹${c.rate}/km</small></div>
 <div class="price">₹${c.rate*3+408}<br><button class="primary" onclick="event.stopPropagation();selectCar(${i});goStep(3)">Select</button></div></div>`).join("");
}
function selectCar(i){selectedCar=cars[i];fare=selectedCar.rate*3+408;renderCars();renderSummary();}
function renderSummary(){
 document.getElementById("bookingSummary").innerHTML=`<div class="driver-box"><div class="car-img">${selectedCar.icon}</div><div><b>${selectedCar.name}</b><small>${selectedCar.type}</small></div><strong>₹${fare}</strong></div>
 <p>📍 ${document.getElementById("pickup").value} → ${document.getElementById("drop").value}</p><p>🗓 ${document.getElementById("date").value||"Today"} · ${document.getElementById("time").value}</p>`;
 document.getElementById("payAmount").textContent="₹"+fare;
}
function goStep(n){
 if(n===2)renderCars();
 if(n===3)renderSummary();
 document.querySelectorAll(".customer-step").forEach(x=>x.classList.remove("active"));
 document.getElementById("step"+n).classList.add("active");
 document.querySelectorAll(".step").forEach(x=>x.classList.toggle("active",+x.dataset.step===n));
 window.scrollTo({top:0,behavior:"smooth"});
}
function quickTrip(a,b){document.getElementById("pickup").value=a;document.getElementById("drop").value=b;goStep(2)}
function payNow(){
 bookingId="DG"+Math.floor(100000+Math.random()*900000);
 document.getElementById("bookingId").textContent=bookingId;
 document.getElementById("trackPickup").textContent=document.getElementById("pickup").value;
 document.getElementById("trackFare").textContent="₹"+fare;
 goStep(5);
}
function resetBooking(){goStep(1)}
document.getElementById("date").value=new Date().toISOString().slice(0,10);
renderCars();
