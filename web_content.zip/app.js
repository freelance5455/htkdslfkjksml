/* JOSTECH — CŒUR DE L'APPLICATION (PHASE 6 FINALE) */
const $ = id => document.getElementById(id);
["app-reader.js", "app-lesson.js"].forEach(f => { const s = document.createElement("script"); s.src = f; document.head.appendChild(s); });
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}

function safeSave(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function safeLoad(k, f) { try { return localStorage.getItem(k) || f; } catch (e) { return f; } }
function safeLoadJSON(k, f) { try { const r = localStorage.getItem(k); return r ? JSON.parse(r) : f; } catch (e) { return f; } }
function safeSaveJSON(k, o) { try { localStorage.setItem(k, JSON.stringify(o)); } catch (e) {} }
function escapeHtml(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
function renderParagraphsHtml(t) { return String(t).split("\n\n").map(p => `<p style="margin-bottom:10px;">${escapeHtml(p).replace(/\n/g, "<br>")}</p>`).join(""); }

let currentDiscId = null, currentLevelNum = 1, currentLessonId = null, reportingLesson = null, toastTimer;
const splash = $("splash"), skipBtn = $("skip-splash");
function hideSplash() { if (splash) splash.classList.add("hidden"); }
setTimeout(hideSplash, 2600);
if (skipBtn) skipBtn.addEventListener("click", hideSplash);

function navigateTo(v) {
  if (v !== "quiz-runner" && typeof stopQuizTimer === "function") stopQuizTimer();
  document.querySelectorAll(".view").forEach(el => el.classList.remove("active"));
  let nt = v;
  if (v === "discipline-detail" || v === "lesson") nt = "disciplines";
  if (v === "quiz-runner") nt = "exams";
  document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.target === nt));
  const t = $("view-" + v); if (t) t.classList.add("active");
  if (v === "home") { updateDashboardStats(); renderRecentLessons(); renderHomePilots(); }
  if (v === "exams" && typeof renderExamsScreen === "function") renderExamsScreen();
  if (v === "profile" && typeof renderProfileScreen === "function") renderProfileScreen();
  if (v === "admin" && typeof renderAdminScreen === "function") renderAdminScreen();
  if (v === "lab" && typeof initLabView === "function") initLabView();
  if (v === "ai" && typeof initAiView === "function") initAiView();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function getCompletedLessons() { return safeLoadJSON("jostech_completed_lessons", []); }
function getAllLessonsFlat() {
  const list = []; if (typeof DISCIPLINES === "undefined") return list;
  DISCIPLINES.forEach(d => { if (d.levels) [1, 2, 3].forEach(l => { const lo = d.levels[l]; if (lo && lo.chapters) lo.chapters.forEach(c => c.lessons.forEach(ls => list.push({ disc: d, levelNum: l, lesson: ls }))); }); });
  return list;
}
function countDisciplineLessons(d) {
  let n = 0; if (d.levels) [1, 2, 3].forEach(l => { if (d.levels[l] && d.levels[l].chapters) d.levels[l].chapters.forEach(c => { n += c.lessons.length; }); });
  return n;
}
function updateDashboardStats() {
  const all = getAllLessonsFlat(), done = getCompletedLessons(), count = all.filter(x => done.includes(x.lesson.id)).length;
  if ($("stat-lessons-done")) $("stat-lessons-done").textContent = `${count}/${all.length}`;
  if ($("stat-progress-pct")) $("stat-progress-pct").textContent = `${all.length ? Math.round((count / all.length) * 100) : 0} %`;
  if ($("stat-avg-20") && typeof getOverallAverage20 === "function") { const avg = getOverallAverage20(); $("stat-avg-20").textContent = avg !== null ? `${avg}/20` : "--/20"; }
  if ($("home-badges-box") && typeof renderBadgesHtml === "function") $("home-badges-box").innerHTML = renderBadgesHtml();
}
function saveRecentLesson(d, lvl, ls) {
  let r = safeLoadJSON("jostech_recent_lessons", []).filter(x => x.lessonId !== ls.id);
  r.unshift({ discId: d.id, levelNum: lvl, lessonId: ls.id, title: ls.title, discTitle: d.title });
  safeSaveJSON("jostech_recent_lessons", r.slice(0, 3));
}
function renderRecentLessons() {
  const blk = $("recent-lessons-block"), box = $("recent-lessons-list"); if (!blk || !box) return;
  const r = safeLoadJSON("jostech_recent_lessons", []);
  if (!r.length) { blk.style.display = "none"; return; }
  blk.style.display = "block"; box.innerHTML = "";
  r.forEach(i => { const row = document.createElement("div"); row.className = "recent-item"; row.onclick = () => openLesson(i.discId, i.levelNum, i.lessonId); row.innerHTML = `<div><strong>${escapeHtml(i.title)}</strong><span>${escapeHtml(i.discTitle)} • Niveau ${i.levelNum}</span></div><span>Ouvrir →</span>`; box.appendChild(row); });
}

function createDisciplineCard(d) {
  const act = d.status === "pilot" || d.status === "active", n = countDisciplineLessons(d), bt = d.status === "pilot" ? "Pilote V1" : (d.status === "active" ? "Publiée" : "En préparation");
  const card = document.createElement("div"); card.className = "disc-card"; card.onclick = () => openDiscipline(d.id, 1);
  card.innerHTML = `<div class="disc-top"><span class="disc-num">DISCIPLINE ${d.num}</span><span class="${act ? "pill-badge pilot" : "pill-badge"}">${bt}</span></div><h4>${escapeHtml(d.title)}</h4><p>${escapeHtml(d.shortDesc)}</p><div class="disc-footer"><span>3 Niveaux</span><span>${n > 0 ? n + " leçon(s) →" : d.topics.length + " modules →"}</span></div>`;
  return card;
}
function renderHomePilots() { const b = $("home-pilots"); if (!b) return; b.innerHTML = ""; DISCIPLINES.filter(d => d.status === "pilot" || d.status === "active").forEach(d => b.appendChild(createDisciplineCard(d))); }
function renderDisciplines(q = "") {
  const b = $("disciplines-list"); if (!b) return; b.innerHTML = ""; const s = q.trim().toLowerCase();
  const res = DISCIPLINES.filter(d => !s || d.title.toLowerCase().includes(s) || d.shortDesc.toLowerCase().includes(s) || d.topics.some(t => t.toLowerCase().includes(s)) || [1, 2, 3].some(l => d.levels && d.levels[l] && d.levels[l].chapters.some(c => c.title.toLowerCase().includes(s) || c.lessons.some(ls => ls.title.toLowerCase().includes(s)))));
  if (!res.length) { b.innerHTML = `<div class="info-banner">Aucun résultat pour « ${escapeHtml(q)} ».</div>`; return; }
  res.forEach(d => b.appendChild(createDisciplineCard(d)));
}
if ($("search-input")) $("search-input").addEventListener("input", e => renderDisciplines(e.target.value));

function applyTheme(c) {
  safeSave("jostech_theme", c);
  const eff = c === "auto" ? (window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark") : c;
  document.documentElement.setAttribute("data-theme", eff);
  const m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute("content", eff === "light" ? "#ffffff" : "#07090d");
  document.querySelectorAll("#theme-controls button").forEach(b => b.classList.toggle("active", b.dataset.themeChoice === c));
}
function applyFontSize(s) {
  safeSave("jostech_font", s); document.documentElement.setAttribute("data-font", s);
  document.querySelectorAll("#font-controls button").forEach(b => b.classList.toggle("active", b.dataset.fontChoice === s));
}
document.querySelectorAll("#theme-controls button").forEach(b => b.addEventListener("click", () => { applyTheme(b.dataset.themeChoice); showToast("Thème mis à jour"); }));
document.querySelectorAll("#font-controls button").forEach(b => b.addEventListener("click", () => { applyFontSize(b.dataset.fontChoice); showToast("Taille ajustée"); }));
$("quick-theme-btn").addEventListener("click", () => { const n = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark"; applyTheme(n); showToast(n === "dark" ? "Mode sombre" : "Mode clair"); });
$("btn-reset-progress").addEventListener("click", () => {
  safeSaveJSON("jostech_completed_lessons", []); safeSaveJSON("jostech_recent_lessons", []); safeSaveJSON("jostech_quiz_history", []); safeSaveJSON("jostech_favorites", []); safeSave("jostech_lab_used", "0");
  updateDashboardStats(); renderRecentLessons(); showToast("Données d'étude réinitialisées");
});

function updateNetStatus() { const p = $("net-status-pill"); if (!p) return; const on = navigator.onLine; p.textContent = on ? "En ligne" : "Hors connexion"; p.className = on ? "pill-badge pilot" : "pill-badge"; }
window.addEventListener("online", updateNetStatus); window.addEventListener("offline", updateNetStatus);
if (typeof runLabCode === "function") { const _o = runLabCode; runLabCode = function () { safeSave("jostech_lab_used", "1"); return _o.apply(this, arguments); }; }
function showToast(msg) { const t = $("toast"); if (!t) return; t.textContent = msg; t.classList.add("show"); clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2500); }
$("notif-btn").addEventListener("click", () => showToast(`JOSTECH : ${getAllLessonsFlat().length} leçons, Labo, Tuteur IA & Examens prêts !`));

if ($("diag-banner")) $("diag-banner").style.display = "none";
if (typeof initAuthAndDynamicContent === "function") initAuthAndDynamicContent();
applyTheme(safeLoad("jostech_theme", "dark")); applyFontSize(safeLoad("jostech_font", "normal"));
updateNetStatus(); updateDashboardStats(); renderRecentLessons(); renderHomePilots(); renderDisciplines();