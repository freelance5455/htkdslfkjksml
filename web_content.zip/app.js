/* =====================================================
   QUÉ BOLÁ SHOP 🛒
   JAVASCRIPT PRINCIPAL
   REGISTRO + LOGIN + SESIÓN + PERMISOS + PERFIL
   ===================================================== */

const AUTH_API =
    "https://que-bola-shop-auth.fonito93punk.workers.dev";


/* =====================================================
   UBICACIONES DE CUBA
   PROVINCIAS + MUNICIPIOS
   ===================================================== */

const MUNICIPIOS_CUBA = {

    "Pinar del Río": [
        "Pinar del Río",
        "Consolación del Sur",
        "Guane",
        "La Palma",
        "Los Palacios",
        "Mantua",
        "Minas de Matahambre",
        "San Cristóbal",
        "San Juan y Martínez",
        "San Luis",
        "Viñales"
    ],

    "Artemisa": [
        "Alquízar",
        "Artemisa",
        "Bahía Honda",
        "Bauta",
        "Caimito",
        "Candelaria",
        "Guanajay",
        "Güira de Melena",
        "Mariel",
        "San Antonio de los Baños",
        "San Cristóbal"
    ],

    "La Habana": [
        "Arroyo Naranjo",
        "Boyeros",
        "Centro Habana",
        "Cerro",
        "Cotorro",
        "Diez de Octubre",
        "Guanabacoa",
        "Habana del Este",
        "La Habana Vieja",
        "La Lisa",
        "Marianao",
        "Playa",
        "Plaza de la Revolución",
        "Regla",
        "San Miguel del Padrón"
    ],

    "Mayabeque": [
        "Batabanó",
        "Bejucal",
        "Güines",
        "Jaruco",
        "Madruga",
        "Melena del Sur",
        "Nueva Paz",
        "Quivicán",
        "San José de las Lajas",
        "San Nicolás",
        "Santa Cruz del Norte"
    ],

    "Matanzas": [
        "Calimete",
        "Cárdenas",
        "Ciénaga de Zapata",
        "Colón",
        "Jagüey Grande",
        "Jovellanos",
        "Limonar",
        "Los Arabos",
        "Martí",
        "Matanzas",
        "Pedro Betancourt",
        "Perico",
        "Unión de Reyes"
    ],

    "Villa Clara": [
        "Caibarién",
        "Camajuaní",
        "Cifuentes",
        "Corralillo",
        "Encrucijada",
        "Manicaragua",
        "Placetas",
        "Quemado de Güines",
        "Ranchuelo",
        "Remedios",
        "Sagua la Grande",
        "Santa Clara",
        "Santo Domingo"
    ],

    "Cienfuegos": [
        "Abreus",
        "Aguada de Pasajeros",
        "Cienfuegos",
        "Cruces",
        "Palmira",
        "Rodas",
        "Lajas",
        "Cumanayagua"
    ],

    "Sancti Spíritus": [
        "Cabaiguán",
        "Fomento",
        "Jatibonico",
        "La Sierpe",
        "Sancti Spíritus",
        "Taguasco",
        "Trinidad",
        "Yaguajay"
    ],

    "Ciego de Ávila": [
        "Baraguá",
        "Bolivia",
        "Chambas",
        "Ciego de Ávila",
        "Ciro Redondo",
        "Florencia",
        "Majagua",
        "Morón",
        "Primero de Enero",
        "Venezuela"
    ],

    "Camagüey": [
        "Camagüey",
        "Carlos Manuel de Céspedes",
        "Esmeralda",
        "Florida",
        "Guáimaro",
        "Jimaguayú",
        "Minas",
        "Najasa",
        "Nuevitas",
        "Santa Cruz del Sur",
        "Sibanicú",
        "Sierra de Cubitas",
        "Vertientes"
    ],

    "Las Tunas": [
        "Amancio",
        "Colombia",
        "Jesús Menéndez",
        "Jobabo",
        "Las Tunas",
        "Majibacoa",
        "Manatí",
        "Puerto Padre"
    ],

    "Holguín": [
        "Antilla",
        "Báguanos",
        "Banes",
        "Cacocum",
        "Calixto García",
        "Cueto",
        "Frank País",
        "Gibara",
        "Holguín",
        "Mayarí",
        "Moa",
        "Rafael Freyre",
        "Sagua de Tánamo",
        "Urbano Noris"
    ],

    "Granma": [
        "Bartolomé Masó",
        "Buey Arriba",
        "Campechuela",
        "Cauto Cristo",
        "Bayamo",
        "Guisa",
        "Jiguaní",
        "Manzanillo",
        "Media Luna",
        "Niquero",
        "Pilón",
        "Río Cauto",
        "Yara"
    ],

    "Santiago de Cuba": [
        "Contramaestre",
        "Guamá",
        "Julio Antonio Mella",
        "Palma Soriano",
        "San Luis",
        "Santiago de Cuba",
        "Segundo Frente",
        "Songo-La Maya",
        "Tercer Frente"
    ],

    "Guantánamo": [
        "Baracoa",
        "Caimanera",
        "El Salvador",
        "Guantánamo",
        "Imías",
        "Maisí",
        "Manuel Tames",
        "Niceto Pérez",
        "San Antonio del Sur",
        "Yateras"
    ],

    "Isla de la Juventud": [
        "Isla de la Juventud"
    ]

};


/* =====================================================
   CONFIGURACIÓN DE PERMISOS
   ===================================================== */

const PERMISOS_CONFIG = {

    ver_tienda: {
        nombre: "Ver Tienda Oficial",
        icono: "🛒"
    },

    ver_feed: {
        nombre: "Ver Feed",
        icono: "📰"
    },

    crear_publicaciones: {
        nombre: "Crear publicaciones",
        icono: "✏️"
    },

    administrar_negocio: {
        nombre: "Administrar negocio",
        icono: "🏪"
    },

    administrar_usuarios: {
        nombre: "Administrar usuarios",
        icono: "👥"
    },

    administrar_sistema: {
        nombre: "Administrar sistema",
        icono: "⚙️"
    }

};


/* =====================================================
   ELEMENTOS CONTROLADOS POR PERMISOS
   ===================================================== */

const ELEMENTOS_POR_PERMISO = {

    ver_tienda: [
        "#tienda",
        'a[href="#tienda"]'
    ],

    ver_feed: [
        "#feed",
        'a[href="#feed"]'
    ]

};


/* =====================================================
   FOTO DE PERFIL EN LA NAVEGACIÓN
   ===================================================== */

function crearBotonFotoPerfil() {

    let boton =
        document.getElementById(
            "profilePhotoNav"
        );

    if (boton) {

        return boton;

    }


    boton =
        document.createElement(
            "a"
        );


    boton.id =
        "profilePhotoNav";


    boton.href =
        "perfil.html";


    boton.className =
        "profile-photo-nav";


    boton.setAttribute(
        "aria-label",
        "Abrir mi perfil"
    );


    boton.title =
        "Mi perfil";


    const imagen =
        document.createElement(
            "img"
        );


    imagen.id =
        "profilePhotoNavImage";


    imagen.src =
        "img/icon.jpg";


    imagen.alt =
        "Mi perfil";


    boton.appendChild(
        imagen
    );


    return boton;

}


/* =====================================================
   ACTUALIZAR FOTO DE PERFIL EN LA NAVEGACIÓN
   ===================================================== */

function actualizarFotoPerfilNavegacion(
    usuario
) {

    if (!usuario) {

        const existente =
            document.getElementById(
                "profilePhotoNav"
            );


        if (existente) {

            existente.remove();

        }


        return;

    }


    const boton =
        crearBotonFotoPerfil();


    const imagen =
        boton.querySelector(
            "#profilePhotoNavImage"
        );


    if (!imagen) {

        return;

    }


    const foto =
        typeof usuario.foto_perfil_url ===
        "string"
            ? usuario.foto_perfil_url.trim()
            : "";


    if (foto) {

        imagen.src =
            foto;

        imagen.alt =
            "Foto de perfil de " +
            (
                usuario.nombre_usuario ||
                usuario.nombre ||
                "usuario"
            );

    } else {

        imagen.src =
            "img/icon.jpg";

        imagen.alt =
            "Mi perfil";

    }


    const menuButton =
        document.getElementById(
            "menuButton"
        );


    if (
        menuButton &&
        menuButton.parentElement
    ) {

        if (
            boton.parentElement !==
            menuButton.parentElement
        ) {

            menuButton.parentElement.insertBefore(
                boton,
                menuButton
            );

        }

    }


    /*
     * Algunas páginas pueden terminar de
     * construir el menú después.
     */

    window.setTimeout(
        () => {

            const usuarioActual =
                obtenerUsuario();


            if (!usuarioActual) {

                return;

            }


            const botonActual =
                document.getElementById(
                    "profilePhotoNav"
                );


            const menuActual =
                document.getElementById(
                    "menuButton"
                );


            if (
                botonActual &&
                menuActual &&
                menuActual.parentElement
            ) {

                if (
                    botonActual.parentElement !==
                    menuActual.parentElement
                ) {

                    menuActual.parentElement.insertBefore(
                        botonActual,
                        menuActual
                    );

                }

            }

        },
        300
    );

}


/* =====================================================
   ESTILOS DE LA FOTO DE PERFIL EN LA NAVEGACIÓN
   ===================================================== */

function agregarEstilosFotoPerfilNavegacion() {

    if (
        document.getElementById(
            "qbProfilePhotoNavStyles"
        )
    ) {

        return;

    }


    const style =
        document.createElement(
            "style"
        );


    style.id =
        "qbProfilePhotoNavStyles";


    style.textContent = `

        .profile-photo-nav {
            display: inline-flex;
            align-items: center;
            justify-content: center;

            width: 44px;
            height: 44px;

            margin-right: 8px;

            flex-shrink: 0;

            border-radius: 50%;

            overflow: hidden;

            background: #f1f1f1;

            border: 2px solid #ff7a00;

            text-decoration: none;

            cursor: pointer;

            transition:
                transform .2s ease,
                border-color .2s ease,
                box-shadow .2s ease;
        }


        .profile-photo-nav:hover {

            transform: scale(1.05);

            border-color: #fff;

            box-shadow:
                0 0 0 2px #ff7a00;

        }


        .profile-photo-nav img {

            display: block;

            width: 100%;
            height: 100%;

            object-fit: cover;

        }


        @media (max-width: 991px) {

            .profile-photo-nav {

                width: 42px;
                height: 42px;

                margin-right: 7px;

            }

        }


        @media (min-width: 992px) {

            .profile-photo-nav {

                width: 40px;
                height: 40px;

                margin-right: 2px;

            }

        }

    `;


    document.head.appendChild(
        style
    );

}


/* =====================================================
   INICIALIZAR FOTO DE PERFIL
   ===================================================== */

function inicializarFotoPerfilNavegacion() {

    agregarEstilosFotoPerfilNavegacion();


    const usuario =
        obtenerUsuario();


    if (usuario) {

        actualizarFotoPerfilNavegacion(
            usuario
        );

    }

}


/* =====================================================
   INICIO
   ===================================================== */

document.addEventListener("DOMContentLoaded", () => {

    /*
     * Inicializar foto de perfil.
     */

    inicializarFotoPerfilNavegacion();


    const menuButton =
        document.getElementById("menuButton");

    const mobileMenu =
        document.getElementById("mobileMenu") ||
        document.querySelector(".mobile-menu");

    const registerForm =
        document.getElementById("registerForm");

    const loginForm =
        document.getElementById("loginForm");

    const logoutButton =
        document.getElementById("logoutButton");


    /* =================================================
       UBICACIÓN DEL REGISTRO
       ================================================= */

    inicializarUbicacionRegistro();


    /* =================================================
       MENÚ MÓVIL
       ================================================= */

    if (menuButton && mobileMenu) {

        menuButton.addEventListener("click", () => {

            const activo =
                mobileMenu.classList.toggle("active");

            menuButton.setAttribute(
                "aria-expanded",
                activo ? "true" : "false"
            );

            menuButton.textContent =
                activo ? "✕" : "☰";

        });


        const mobileLinks =
            mobileMenu.querySelectorAll("a");


        mobileLinks.forEach(link => {

            link.addEventListener("click", () => {

                mobileMenu.classList.remove("active");

                menuButton.setAttribute(
                    "aria-expanded",
                    "false"
                );

                menuButton.textContent =
                    "☰";

            });

        });

    }


    /* =================================================
       REGISTRO
       ================================================= */

    if (registerForm) {

        registerForm.addEventListener(
            "submit",
            registrarUsuario
        );

    }


    /* =================================================
       LOGIN
       ================================================= */

    if (loginForm) {

        loginForm.addEventListener(
            "submit",
            iniciarSesion
        );

    }


    /* =================================================
       CERRAR SESIÓN
       ================================================= */

    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            cerrarSesion
        );

    }


    /* =================================================
       COMPROBAR SESIÓN
       ================================================= */

    cargarSesion();

});


/* =====================================================
   REGISTRO
   ===================================================== */

async function registrarUsuario(event) {

    event.preventDefault();


    const registerForm =
        document.getElementById("registerForm");

    const usernameInput =
        document.getElementById(
            "registerUsername"
        );

    const passwordInput =
        document.getElementById(
            "registerPassword"
        );

    const provinciaInput =
        document.getElementById(
            "registerProvincia"
        );

    const municipioInput =
        document.getElementById(
            "registerMunicipio"
        );


    if (
        !registerForm ||
        !usernameInput ||
        !passwordInput ||
        !provinciaInput ||
        !municipioInput
    ) {

        mostrarMensaje(
            "registerMessage",
            "No se pudo cargar el formulario.",
            "error"
        );

        return;

    }


    const nombreUsuario =
        usernameInput.value.trim();

    const password =
        passwordInput.value;

    const provincia =
        provinciaInput.value.trim();

    const municipio =
        municipioInput.value.trim();


    /* =================================================
       VALIDACIONES
       ================================================= */

    if (!nombreUsuario) {

        mostrarMensaje(
            "registerMessage",
            "Escribe un nombre de usuario.",
            "error"
        );

        usernameInput.focus();

        return;

    }


    if (nombreUsuario.length < 3) {

        mostrarMensaje(
            "registerMessage",
            "El nombre de usuario debe tener al menos 3 caracteres.",
            "error"
        );

        usernameInput.focus();

        return;

    }


    if (nombreUsuario.length > 30) {

        mostrarMensaje(
            "registerMessage",
            "El nombre de usuario no puede superar los 30 caracteres.",
            "error"
        );

        usernameInput.focus();

        return;

    }


    if (
        !/^[a-zA-Z0-9._-]+$/.test(
            nombreUsuario
        )
    ) {

        mostrarMensaje(
            "registerMessage",
            "El nombre de usuario contiene caracteres no permitidos.",
            "error"
        );

        usernameInput.focus();

        return;

    }


    if (password.length < 8) {

        mostrarMensaje(
            "registerMessage",
            "La contraseña debe tener al menos 8 caracteres.",
            "error"
        );

        passwordInput.focus();

        return;

    }


    if (password.length > 128) {

        mostrarMensaje(
            "registerMessage",
            "La contraseña no puede superar los 128 caracteres.",
            "error"
        );

        passwordInput.focus();

        return;

    }


    /* =================================================
       VALIDAR PROVINCIA
       ================================================= */

    if (!provincia) {

        mostrarMensaje(
            "registerMessage",
            "Selecciona tu provincia.",
            "error"
        );

        provinciaInput.focus();

        return;

    }


    if (
        !Object.prototype.hasOwnProperty.call(
            MUNICIPIOS_CUBA,
            provincia
        )
    ) {

        mostrarMensaje(
            "registerMessage",
            "La provincia seleccionada no es válida.",
            "error"
        );

        provinciaInput.focus();

        return;

    }


    /* =================================================
       VALIDAR MUNICIPIO
       ================================================= */

    if (!municipio) {

        mostrarMensaje(
            "registerMessage",
            "Selecciona tu municipio.",
            "error"
        );

        municipioInput.focus();

        return;

    }


    const municipiosProvincia =
        MUNICIPIOS_CUBA[provincia];


    if (
        !municipiosProvincia.includes(
            municipio
        )
    ) {

        mostrarMensaje(
            "registerMessage",
            "El municipio seleccionado no pertenece a la provincia elegida.",
            "error"
        );

        municipioInput.focus();

        return;

    }


    /* =================================================
       ENVIANDO
       ================================================= */

    mostrarMensaje(
        "registerMessage",
        "Creando tu cuenta...",
        "info"
    );


    try {

        const respuesta =
            await fetch(
                `${AUTH_API}/registro`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        nombre_usuario:
                            nombreUsuario,

                        password:
                            password,

                        provincia:
                            provincia,

                        municipio:
                            municipio

                    })

                }
            );


        let datos;


        try {

            datos =
                await respuesta.json();

        } catch {

            datos = {
                ok: false,
                error:
                    "El servidor devolvió una respuesta inválida."
            };

        }


        if (
            !respuesta.ok ||
            !datos.ok
        ) {

            mostrarMensaje(
                "registerMessage",
                datos.error ||
                "No se pudo crear la cuenta.",
                "error"
            );

            return;

        }


        /* =================================================
           REGISTRO CORRECTO
           ================================================= */

        mostrarMensaje(
            "registerMessage",
            "¡Cuenta creada correctamente! 🎉",
            "success"
        );


        registerForm.reset();


        actualizarMunicipiosRegistro();


        console.log(
            "Usuario registrado:",
            datos.usuario
        );


        /* =================================================
           IR AL LOGIN
           ================================================= */

        setTimeout(() => {

            window.location.href =
                "login.html";

        }, 1000);


    } catch (error) {

        console.error(
            "Error de conexión:",
            error
        );


        mostrarMensaje(
            "registerMessage",
            "No se pudo conectar con el servidor.",
            "error"
        );

    }

}


/* =====================================================
   LOGIN
   ===================================================== */

async function iniciarSesion(event) {

    event.preventDefault();


    const loginForm =
        document.getElementById("loginForm");

    const usernameInput =
        document.getElementById(
            "loginUsername"
        );

    const passwordInput =
        document.getElementById(
            "loginPassword"
        );


    if (
        !loginForm ||
        !usernameInput ||
        !passwordInput
    ) {

        mostrarMensaje(
            "loginMessage",
            "No se pudo cargar el formulario.",
            "error"
        );

        return;

    }


    const nombreUsuario =
        usernameInput.value.trim();

    const password =
        passwordInput.value;


    /* =================================================
       VALIDACIONES
       ================================================= */

    if (!nombreUsuario) {

        mostrarMensaje(
            "loginMessage",
            "Escribe tu nombre de usuario.",
            "error"
        );

        usernameInput.focus();

        return;

    }


    if (!password) {

        mostrarMensaje(
            "loginMessage",
            "Escribe tu contraseña.",
            "error"
        );

        passwordInput.focus();

        return;

    }


    /* =================================================
       ENVIANDO LOGIN
       ================================================= */

    mostrarMensaje(
        "loginMessage",
        "Iniciando sesión...",
        "info"
    );


    try {

        const respuesta =
            await fetch(
                `${AUTH_API}/login`,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json"
                    },

                    body: JSON.stringify({

                        nombre_usuario:
                            nombreUsuario,

                        password:
                            password

                    })

                }
            );


        let datos;


        try {

            datos =
                await respuesta.json();

        } catch {

            datos = {
                ok: false,
                error:
                    "El servidor devolvió una respuesta inválida."
            };

        }


        /* =================================================
           LOGIN INCORRECTO
           ================================================= */

        if (
            !respuesta.ok ||
            !datos.ok
        ) {

            mostrarMensaje(
                "loginMessage",
                datos.error ||
                "No se pudo iniciar sesión.",
                "error"
            );

            return;

        }


        /* =================================================
           COMPROBAR RESPUESTA
           ================================================= */

        if (
            !datos.token ||
            !datos.usuario
        ) {

            mostrarMensaje(
                "loginMessage",
                "El servidor no devolvió una sesión válida.",
                "error"
            );

            return;

        }


        /* =================================================
           GUARDAR SESIÓN
           ================================================= */

        localStorage.setItem(
            "que_bola_shop_token",
            datos.token
        );


        localStorage.setItem(
            "que_bola_shop_usuario",
            JSON.stringify(
                datos.usuario
            )
        );


        localStorage.setItem(
            "que_bola_shop_expiracion",
            datos.sesion?.fecha_expiracion ||
            ""
        );


        /* =================================================
           ACTUALIZAR FOTO DE PERFIL
           ================================================= */

        actualizarFotoPerfilNavegacion(
            datos.usuario
        );


        /* =================================================
           OBTENER PERMISOS
           ================================================= */

        const permisos =
            await cargarPermisos();


        if (!permisos) {

            console.warn(
                "La sesión inició, pero no se pudieron cargar los permisos."
            );

        }


        /* =================================================
           MOSTRAR SESIÓN
           ================================================= */

        mostrarSesion(
            datos.usuario
        );


        mostrarMensaje(
            "loginMessage",
            "¡Inicio de sesión correcto! 🎉",
            "success"
        );


        loginForm.reset();


        console.log(
            "Sesión iniciada:",
            datos.usuario
        );


        /* =================================================
           REDIRECCIÓN AL FEED
           ================================================= */

        setTimeout(() => {

            window.location.href =
                "feed.html";

        }, 500);


    } catch (error) {

        console.error(
            "Error de conexión:",
            error
        );


        mostrarMensaje(
            "loginMessage",
            "No se pudo conectar con el servidor.",
            "error"
        );

    }

}


/* =====================================================
   CARGAR SESIÓN
   ===================================================== */

async function cargarSesion() {

    const token =
        localStorage.getItem(
            "que_bola_shop_token"
        );

    const usuarioGuardado =
        localStorage.getItem(
            "que_bola_shop_usuario"
        );

    const expiracion =
        localStorage.getItem(
            "que_bola_shop_expiracion"
        );


    if (
        !token ||
        !usuarioGuardado
    ) {

        ocultarSesion();

        return;

    }


    /* =================================================
       COMPROBAR EXPIRACIÓN LOCAL
       ================================================= */

    if (expiracion) {

        const fecha =
            new Date(expiracion);


        if (
            Number.isNaN(
                fecha.getTime()
            ) ||
            fecha.getTime() <= Date.now()
        ) {

            cerrarSesion();

            return;

        }

    }


    try {

        const usuario =
            JSON.parse(
                usuarioGuardado
            );


        if (
            !usuario ||
            !usuario.id
        ) {

            cerrarSesion();

            return;

        }


        /* =================================================
           VALIDAR SESIÓN CON EL SERVIDOR
           ================================================= */

        const sesionValida =
            await validarSesionServidor();


        if (!sesionValida) {

            cerrarSesion();

            return;

        }


        /* =================================================
           ACTUALIZAR DATOS DEL USUARIO
           ================================================= */

        if (
            sesionValida.usuario
        ) {

            localStorage.setItem(
                "que_bola_shop_usuario",
                JSON.stringify(
                    sesionValida.usuario
                )
            );

        }


        if (
            sesionValida.sesion?.fecha_expiracion
        ) {

            localStorage.setItem(
                "que_bola_shop_expiracion",
                sesionValida.sesion.fecha_expiracion
            );

        }


        const usuarioActual =
            sesionValida.usuario ||
            usuario;


        /* =================================================
           ACTUALIZAR FOTO DE PERFIL
           ================================================= */

        actualizarFotoPerfilNavegacion(
            usuarioActual
        );


        /* =================================================
           CARGAR PERMISOS
           ================================================= */

        const permisos =
            await cargarPermisos();


        /* =================================================
           MOSTRAR SESIÓN
           ================================================= */

        mostrarSesion(
            usuarioActual
        );


        asegurarEnlacePerfil();


        /*
         * Asegurar el acceso administrativo usando
         * tanto el rol como los permisos reales.
         */

        asegurarAccesoAdministrativo(
            usuarioActual,
            permisos
        );


        /* =================================================
           SI ESTAMOS EN LOGIN
           → IR DIRECTAMENTE AL FEED
           ================================================= */

        if (
            esPaginaLogin()
        ) {

            window.location.href =
                "feed.html";

            return;

        }


    } catch (error) {

        console.error(
            "Error cargando sesión:",
            error
        );

        cerrarSesion();

    }

}


/* =====================================================
   COMPROBAR SI ESTAMOS EN LOGIN
   ===================================================== */

function esPaginaLogin() {

    const pagina =
        window.location.pathname
            .split("/")
            .pop()
            .toLowerCase();


    return pagina === "login.html";

}


/* =====================================================
   VALIDAR SESIÓN
   ===================================================== */

async function validarSesionServidor() {

    const token =
        obtenerToken();


    if (!token) {

        return null;

    }


    try {

        const respuesta =
            await fetch(
                `${AUTH_API}/sesion`,
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }

                }
            );


        let datos;


        try {

            datos =
                await respuesta.json();

        } catch {

            return null;

        }


        if (
            !respuesta.ok ||
            !datos.ok
        ) {

            console.warn(
                "Sesión rechazada:",
                datos.error
            );

            return null;

        }


        return datos;


    } catch (error) {

        console.error(
            "Error validando sesión:",
            error
        );

        return null;

    }

}


/* =====================================================
   CARGAR PERMISOS
   ===================================================== */

async function cargarPermisos() {

    const token =
        obtenerToken();


    if (!token) {

        localStorage.removeItem(
            "que_bola_shop_permisos"
        );

        return null;

    }


    try {

        const respuesta =
            await fetch(
                `${AUTH_API}/permisos`,
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            `Bearer ${token}`
                    }

                }
            );


        let datos;


        try {

            datos =
                await respuesta.json();

        } catch {

            console.error(
                "Respuesta inválida al obtener permisos."
            );

            return null;

        }


        if (
            !respuesta.ok ||
            !datos.ok
        ) {

            console.warn(
                "No se pudieron obtener los permisos:",
                datos.error
            );

            return null;

        }


        const permisos =
            datos.permisos || {};


        /* =================================================
           GUARDAR PERMISOS
           ================================================= */

        localStorage.setItem(
            "que_bola_shop_permisos",
            JSON.stringify(
                permisos
            )
        );


        console.log(
            "Permisos cargados:",
            permisos
        );


        /* =================================================
           ACTUALIZAR INTERFAZ
           ================================================= */

        actualizarInterfazPermisos(
            permisos
        );


        return permisos;


    } catch (error) {

        console.error(
            "Error cargando permisos:",
            error
        );

        return null;

    }

}


/* =====================================================
   ACTUALIZAR INTERFAZ SEGÚN PERMISOS
   ===================================================== */

function actualizarInterfazPermisos(
    permisos
) {

    if (!permisos) {

        ocultarElementosProtegidos();

        return;

    }


    /* =================================================
       TIENDA OFICIAL
       ================================================= */

    actualizarElementoPorPermiso(
        permisos,
        "ver_tienda"
    );


    /* =================================================
       FEED
       ================================================= */

    actualizarElementoPorPermiso(
        permisos,
        "ver_feed"
    );


    /* =================================================
       PANEL DE PERMISOS
       ================================================= */

    mostrarPanelPermisos(
        permisos
    );


    /* =================================================
       ESTADO DE PERMISOS
       ================================================= */

    actualizarEstadoPermisos(
        permisos
    );


    /*
     * Si el usuario tiene permiso de administrar
     * el sistema, aseguramos que el acceso admin
     * también esté presente.
     */

    const usuario =
        obtenerUsuario();


    if (usuario) {

        asegurarAccesoAdministrativo(
            usuario,
            permisos
        );

    }

}


/* =====================================================
   ACTUALIZAR ELEMENTOS POR PERMISO
   ===================================================== */

function actualizarElementoPorPermiso(
    permisos,
    permiso
) {

    const permitido =
        permisos[permiso] === true;


    const selectores =
        ELEMENTOS_POR_PERMISO[permiso] || [];


    selectores.forEach(
        selector => {

            document
                .querySelectorAll(selector)
                .forEach(elemento => {

                    elemento.hidden =
                        !permitido;

                });

        }
    );

}


/* =====================================================
   OCULTAR ELEMENTOS PROTEGIDOS
   ===================================================== */

function ocultarElementosProtegidos() {

    Object.values(
        ELEMENTOS_POR_PERMISO
    ).forEach(
        selectores => {

            selectores.forEach(
                selector => {

                    document
                        .querySelectorAll(selector)
                        .forEach(elemento => {

                            elemento.hidden =
                                true;

                        });

                }
            );

        }
    );

}


/* =====================================================
   MOSTRAR PANEL DE PERMISOS
   ===================================================== */

function mostrarPanelPermisos(
    permisos
) {

    const panel =
        document.getElementById(
            "permissionsPanel"
        );

    const lista =
        document.getElementById(
            "permissionsList"
        );


    if (
        !panel ||
        !lista
    ) {

        return;

    }


    lista.innerHTML = "";


    Object.entries(
        PERMISOS_CONFIG
    ).forEach(
        ([clave, configuracion]) => {

            const permitido =
                permisos[clave] === true;


            const item =
                document.createElement(
                    "div"
                );


            item.className =
                `permission-item ${
                    permitido
                        ? "permitido"
                        : "denegado"
                }`;


            const icono =
                document.createElement(
                    "span"
                );


            icono.className =
                "permission-icon";


            icono.textContent =
                permitido
                    ? "✅"
                    : "❌";


            const texto =
                document.createElement(
                    "span"
                );


            texto.textContent =
                `${configuracion.icono} ${configuracion.nombre}`;


            item.appendChild(
                icono
            );


            item.appendChild(
                texto
            );


            lista.appendChild(
                item
            );

        }
    );


    panel.hidden =
        false;

}


/* =====================================================
   ACTUALIZAR ESTADO DE PERMISOS
   ===================================================== */

function actualizarEstadoPermisos(
    permisos
) {

    const elemento =
        document.getElementById(
            "sessionPermissionStatus"
        );


    if (!elemento) {

        return;

    }


    const total =
        Object.keys(
            PERMISOS_CONFIG
        ).length;


    const permitidos =
        Object.keys(
            PERMISOS_CONFIG
        ).filter(
            permiso =>
                permisos[permiso] === true
        ).length;


    elemento.textContent =
        `${permitidos} de ${total} permisos disponibles`;


    elemento.className =
        "session-permission-status success";

}


/* =====================================================
   MOSTRAR SESIÓN
   ===================================================== */

function mostrarSesion(usuario) {

    if (!usuario) {

        return;

    }


    /*
     * Actualizar navegación.
     */

    actualizarNavegacion(
        usuario
    );


    /*
     * Actualizar foto de perfil.
     */

    actualizarFotoPerfilNavegacion(
        usuario
    );


    /*
     * Asegurar Mi perfil.
     */

    asegurarEnlacePerfil();


    const sessionInfo =
        document.getElementById(
            "sessionInfo"
        );

    const sessionWelcome =
        document.getElementById(
            "sessionWelcome"
        );

    const sessionRole =
        document.getElementById(
            "sessionRole"
        );


    /*
     * Algunas páginas no tienen panel de sesión.
     * Eso no impide actualizar el menú.
     */

    if (
        !sessionInfo ||
        !sessionWelcome ||
        !sessionRole
    ) {

        return;

    }


    const nombre =
        usuario.nombre_usuario ||
        usuario.nombre ||
        "Usuario";


    const rol =
        usuario.rol ||
        "USUARIO";


    sessionWelcome.textContent =
        `¡Hola, ${nombre}! 👋`;


    sessionRole.textContent =
        rol;


    sessionInfo.hidden =
        false;


    /* =================================================
       OCULTAR LOGIN
       ================================================= */

    const loginForm =
        document.getElementById(
            "loginForm"
        );


    if (loginForm) {

        loginForm.hidden =
            true;

    }


    /* =================================================
       BOTÓN PANEL ADMINISTRATIVO
       ================================================= */

    mostrarBotonPanelAdministrativo(
        usuario
    );


    /* =================================================
       ACTUALIZAR PERMISOS
       ================================================= */

    const permisos =
        obtenerPermisos();


    if (permisos) {

        actualizarInterfazPermisos(
            permisos
        );

    }

}


/* =====================================================
   ASEGURAR ACCESO ADMINISTRATIVO
   ===================================================== */

function asegurarAccesoAdministrativo(
    usuario,
    permisos
) {

    if (!usuario) {

        eliminarEnlacesAdministrativos();

        eliminarBotonPanelAdministrativo();

        return;

    }


    const rol =
        String(
            usuario.rol || ""
        )
        .trim()
        .toUpperCase();


    const tienePermisoAdmin =
        permisos &&
        permisos.administrar_sistema === true;


    if (
        rol !== "ADMINISTRADOR" &&
        !tienePermisoAdmin
    ) {

        eliminarEnlacesAdministrativos();

        eliminarBotonPanelAdministrativo();

        return;

    }


    agregarEnlaceAdministrativo(
        usuario
    );


    mostrarBotonPanelAdministrativo(
        usuario
    );

}


/* =====================================================
   BOTÓN PANEL ADMINISTRATIVO
   ===================================================== */

function mostrarBotonPanelAdministrativo(
    usuario
) {

    eliminarBotonPanelAdministrativo();


    if (!usuario) {

        return;

    }


    const rol =
        String(
            usuario.rol || ""
        )
        .trim()
        .toUpperCase();


    if (
        rol !== "ADMINISTRADOR"
    ) {

        return;

    }


    const sessionInfo =
        document.getElementById(
            "sessionInfo"
        );


    if (!sessionInfo) {

        return;

    }


    const boton =
        document.createElement(
            "a"
        );


    boton.href =
        "panel-admin.html";


    boton.className =
        "button button-primary button-full boton-panel-administrativo";


    boton.textContent =
        "⚙️ Panel administrativo";


    boton.setAttribute(
        "aria-label",
        "Abrir panel administrativo"
    );


    const logoutButton =
        document.getElementById(
            "logoutButton"
        );


    if (
        logoutButton &&
        logoutButton.parentElement === sessionInfo
    ) {

        sessionInfo.insertBefore(
            boton,
            logoutButton
        );

    } else {

        sessionInfo.appendChild(
            boton
        );

    }

}


/* =====================================================
   ELIMINAR BOTÓN ADMINISTRATIVO
   ===================================================== */

function eliminarBotonPanelAdministrativo() {

    document
        .querySelectorAll(
            ".boton-panel-administrativo"
        )
        .forEach(
            boton => boton.remove()
        );

}


/* =====================================================
   ACTUALIZAR NAVEGACIÓN
   ===================================================== */

function actualizarNavegacion(usuario) {

    const loginLinks =
        document.querySelectorAll(
            'a[href="#login"]'
        );


    const registerLinks =
        document.querySelectorAll(
            'a[href="#registro"]'
        );


    if (!usuario) {

        loginLinks.forEach(link => {

            link.hidden =
                false;

        });


        registerLinks.forEach(link => {

            link.hidden =
                false;

        });


        eliminarEnlacesAdministrativos();

        eliminarEnlacesPerfil();

        eliminarBotonPanelAdministrativo();

        return;

    }


    loginLinks.forEach(link => {

        link.hidden =
            true;

    });


    registerLinks.forEach(link => {

        link.hidden =
            true;

    });


    /* =================================================
       MI PERFIL
       ================================================= */

    agregarEnlacePerfil();


    /* =================================================
       ADMINISTRADOR
       ================================================= */

    agregarEnlaceAdministrativo(
        usuario
    );

}


/* =====================================================
   AGREGAR ENLACE MI PERFIL
   ===================================================== */

function agregarEnlacePerfil() {

    /*
     * Primero eliminamos enlaces anteriores
     * para evitar duplicados.
     */

    eliminarEnlacesPerfil();


    const nav =
        document.querySelector(
            "nav.main-nav"
        );


    const mobileMenu =
        document.querySelector(
            "#mobileMenu, .mobile-menu"
        );


    /*
     * MENÚ PRINCIPAL
     */

    if (nav) {

        nav.appendChild(
            crearEnlacePerfil()
        );

    }


    /*
     * MENÚ MÓVIL
     */

    if (mobileMenu) {

        mobileMenu.appendChild(
            crearEnlacePerfil()
        );

    }


    /*
     * Asegurarlo nuevamente después.
     */

    window.setTimeout(
        asegurarEnlacePerfil,
        100
    );


    window.setTimeout(
        asegurarEnlacePerfil,
        500
    );


    window.setTimeout(
        asegurarEnlacePerfil,
        1000
    );

}


/* =====================================================
   ASEGURAR ENLACE MI PERFIL
   ===================================================== */

function asegurarEnlacePerfil() {

    const usuario =
        obtenerUsuario();


    /*
     * Si no existe sesión no mostramos el enlace.
     */

    if (!usuario) {

        eliminarEnlacesPerfil();

        return;

    }


    const nav =
        document.querySelector(
            "nav.main-nav"
        );


    const mobileMenu =
        document.querySelector(
            "#mobileMenu, .mobile-menu"
        );


    /*
     * MENÚ PRINCIPAL
     */

    if (
        nav &&
        !nav.querySelector(
            '[data-profile-link="true"]'
        )
    ) {

        nav.appendChild(
            crearEnlacePerfil()
        );

    }


    /*
     * MENÚ MÓVIL
     */

    if (
        mobileMenu &&
        !mobileMenu.querySelector(
            '[data-profile-link="true"]'
        )
    ) {

        mobileMenu.appendChild(
            crearEnlacePerfil()
        );

    }

}


/* =====================================================
   CREAR ENLACE MI PERFIL
   ===================================================== */

function crearEnlacePerfil() {

    const enlace =
        document.createElement(
            "a"
        );


    enlace.href =
        "perfil.html";


    enlace.textContent =
        "👤 Mi perfil";


    enlace.className =
        "profile-link";


    enlace.setAttribute(
        "data-profile-link",
        "true"
    );


    enlace.setAttribute(
        "aria-label",
        "Abrir mi perfil"
    );


    return enlace;

}


/* =====================================================
   ELIMINAR ENLACES MI PERFIL
   ===================================================== */

function eliminarEnlacesPerfil() {

    document
        .querySelectorAll(
            '[data-profile-link="true"]'
        )
        .forEach(
            enlace => enlace.remove()
        );

}


/* =====================================================
   AGREGAR ENLACE ADMINISTRATIVO
   ===================================================== */

function agregarEnlaceAdministrativo(
    usuario
) {

    const rol =
        String(
            usuario?.rol || ""
        )
        .trim()
        .toUpperCase();


    /*
     * Primero eliminamos enlaces anteriores.
     */

    eliminarEnlacesAdministrativos();


    /*
     * Solamente ADMINISTRADOR.
     */

    if (
        rol !== "ADMINISTRADOR"
    ) {

        return;

    }


    const nav =
        document.querySelector(
            "nav.main-nav"
        );


    const mobileMenu =
        document.querySelector(
            "#mobileMenu, .mobile-menu"
        );


    /*
     * MENÚ PRINCIPAL
     */

    if (nav) {

        nav.appendChild(
            crearEnlaceAdministrativo()
        );

    }


    /*
     * MENÚ MÓVIL
     */

    if (mobileMenu) {

        mobileMenu.appendChild(
            crearEnlaceAdministrativo()
        );

    }


    /*
     * Asegurar nuevamente el enlace administrativo
     * si otro script modifica el menú.
     */

    window.setTimeout(() => {

        const usuarioActual =
            obtenerUsuario();


        if (
            usuarioActual &&
            String(
                usuarioActual.rol || ""
            )
            .trim()
            .toUpperCase() ===
            "ADMINISTRADOR"
        ) {

            const navActual =
                document.querySelector(
                    "nav.main-nav"
                );

            const mobileActual =
                document.querySelector(
                    "#mobileMenu, .mobile-menu"
                );


            if (
                navActual &&
                !navActual.querySelector(
                    '[data-admin-link="true"]'
                )
            ) {

                navActual.appendChild(
                    crearEnlaceAdministrativo()
                );

            }


            if (
                mobileActual &&
                !mobileActual.querySelector(
                    '[data-admin-link="true"]'
                )
            ) {

                mobileActual.appendChild(
                    crearEnlaceAdministrativo()
                );

            }

        }


        /*
         * Volver a asegurar Mi perfil.
         */

        asegurarEnlacePerfil();

    }, 0);

}


/* =====================================================
   CREAR ENLACE ADMINISTRATIVO
   ===================================================== */

function crearEnlaceAdministrativo() {

    const enlace =
        document.createElement(
            "a"
        );


    enlace.href =
        "panel-admin.html";


    enlace.textContent =
        "⚙️ Panel administrativo";


    enlace.className =
        "admin-panel-link";


    enlace.setAttribute(
        "data-admin-link",
        "true"
    );


    enlace.setAttribute(
        "aria-label",
        "Abrir panel administrativo"
    );


    return enlace;

}


/* =====================================================
   ELIMINAR ENLACES ADMINISTRATIVOS
   ===================================================== */

function eliminarEnlacesAdministrativos() {

    document
        .querySelectorAll(
            '[data-admin-link="true"]'
        )
        .forEach(
            enlace => enlace.remove()
        );

}


/* =====================================================
   CERRAR SESIÓN
   ===================================================== */

function cerrarSesion() {

    localStorage.removeItem(
        "que_bola_shop_token"
    );


    localStorage.removeItem(
        "que_bola_shop_usuario"
    );


    localStorage.removeItem(
        "que_bola_shop_expiracion"
    );


    localStorage.removeItem(
        "que_bola_shop_permisos"
    );


    eliminarEnlacesAdministrativos();

    eliminarEnlacesPerfil();

    eliminarBotonPanelAdministrativo();


    /*
     * Eliminar foto de navegación.
     */

    const profilePhotoNav =
        document.getElementById(
            "profilePhotoNav"
        );


    if (profilePhotoNav) {

        profilePhotoNav.remove();

    }


    ocultarSesion();


    const loginMessage =
        document.getElementById(
            "loginMessage"
        );


    if (loginMessage) {

        loginMessage.textContent =
            "Sesión cerrada correctamente.";

        loginMessage.className =
            "form-message info";

    }


    console.log(
        "Sesión cerrada"
    );

}


/* =====================================================
   OCULTAR SESIÓN
   ===================================================== */

function ocultarSesion() {

    const sessionInfo =
        document.getElementById(
            "sessionInfo"
        );


    const loginForm =
        document.getElementById(
            "loginForm"
        );


    if (sessionInfo) {

        sessionInfo.hidden =
            true;

    }


    if (loginForm) {

        loginForm.hidden =
            false;

    }


    actualizarNavegacion(
        null
    );


}


/* =====================================================
   OBTENER TOKEN
   ===================================================== */

function obtenerToken() {

    return localStorage.getItem(
        "que_bola_shop_token"
    );

}


/* =====================================================
   OBTENER USUARIO
   ===================================================== */

function obtenerUsuario() {

    const usuario =
        localStorage.getItem(
            "que_bola_shop_usuario"
        );


    if (!usuario) {

        return null;

    }


    try {

        return JSON.parse(
            usuario
        );

    } catch {

        return null;

    }

}


/* =====================================================
   OBTENER PERMISOS
   ===================================================== */

function obtenerPermisos() {

    const permisos =
        localStorage.getItem(
            "que_bola_shop_permisos"
        );


    if (!permisos) {

        return null;

    }


    try {

        return JSON.parse(
            permisos
        );

    } catch {

        return null;

    }

}


/* =====================================================
   COMPROBAR PERMISO
   ===================================================== */

function tienePermiso(
    permiso
) {

    const permisos =
        obtenerPermisos();


    if (!permisos) {

        return false;

    }


    return permisos[permiso] === true;

}


/* =====================================================
   MOSTRAR MENSAJES
   ===================================================== */

function mostrarMensaje(
    elementoId,
    mensaje,
    tipo
) {

    const elemento =
        document.getElementById(
            elementoId
        );


    if (!elemento) {

        return;

    }


    elemento.textContent =
        mensaje;


    elemento.className =
        `form-message ${tipo}`;

}


/* =====================================================
   INICIALIZAR UBICACIÓN DEL REGISTRO
   ===================================================== */

function inicializarUbicacionRegistro() {

    const provinciaInput =
        document.getElementById(
            "registerProvincia"
        );

    const municipioInput =
        document.getElementById(
            "registerMunicipio"
        );


    /*
     * Si esta página no tiene formulario
     * de registro, no hacemos nada.
     */

    if (
        !provinciaInput ||
        !municipioInput
    ) {

        return;

    }


    /* =================================================
       CARGAR PROVINCIAS
       ================================================= */

    provinciaInput.innerHTML = "";


    const opcionInicialProvincia =
        document.createElement("option");


    opcionInicialProvincia.value =
        "";


    opcionInicialProvincia.textContent =
        "Selecciona tu provincia";


    opcionInicialProvincia.disabled =
        true;


    opcionInicialProvincia.selected =
        true;


    provinciaInput.appendChild(
        opcionInicialProvincia
    );


    Object.keys(
        MUNICIPIOS_CUBA
    ).forEach(
        provincia => {

            const opcion =
                document.createElement(
                    "option"
                );


            opcion.value =
                provincia;


            opcion.textContent =
                provincia;


            provinciaInput.appendChild(
                opcion
            );

        }
    );


    /* =================================================
       CAMBIO DE PROVINCIA
       ================================================= */

    provinciaInput.addEventListener(
        "change",
        actualizarMunicipiosRegistro
    );


    /*
     * Estado inicial.
     */

    actualizarMunicipiosRegistro();

}


/* =====================================================
   ACTUALIZAR MUNICIPIOS
   ===================================================== */

function actualizarMunicipiosRegistro() {

    const provinciaInput =
        document.getElementById(
            "registerProvincia"
        );

    const municipioInput =
        document.getElementById(
            "registerMunicipio"
        );


    if (
        !provinciaInput ||
        !municipioInput
    ) {

        return;

    }


    const provincia =
        provinciaInput.value;


    /*
     * Limpiar municipios anteriores.
     */

    municipioInput.innerHTML = "";


    /* =================================================
       SIN PROVINCIA
       ================================================= */

    if (
        !provincia ||
        !MUNICIPIOS_CUBA[provincia]
    ) {

        const opcion =
            document.createElement(
                "option"
            );


        opcion.value =
            "";


        opcion.textContent =
            "Primero selecciona tu provincia";


        opcion.disabled =
            true;


        opcion.selected =
            true;


        municipioInput.appendChild(
            opcion
        );


        municipioInput.disabled =
            true;


        return;

    }


    /* =================================================
       OPCIÓN INICIAL
       ================================================= */

    const opcionInicial =
        document.createElement(
            "option"
        );


    opcionInicial.value =
        "";


    opcionInicial.textContent =
        "Selecciona tu municipio";


    opcionInicial.disabled =
        true;


    opcionInicial.selected =
        true;


    municipioInput.appendChild(
        opcionInicial
    );


    /* =================================================
       MUNICIPIOS DE LA PROVINCIA
       ================================================= */

    MUNICIPIOS_CUBA[provincia].forEach(
        municipio => {

            const opcion =
                document.createElement(
                    "option"
                );


            opcion.value =
                municipio;


            opcion.textContent =
                municipio;


            municipioInput.appendChild(
                opcion
            );

        }
    );


    municipioInput.disabled =
        false;

}