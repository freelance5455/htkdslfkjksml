(function(){
'use strict';
var KEY='tunnelproxy.v1';
var $=function(s){return document.querySelector(s)};
var db={proxies:[],active:null,mode:'tunnel'};
var status='disconnected';
var editingId=null;

function load(){try{var r=localStorage.getItem(KEY);if(r)db=Object.assign(db,JSON.parse(r))}catch(e){}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(db))}catch(e){}}
function uid(){return 'p'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
function toast(m){var t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(function(){t.hidden=true},2600)}
function bridge(){return window.NativeVpn&&typeof window.NativeVpn.start==='function'?window.NativeVpn:null}
function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function url(p){var a=p.user?encodeURIComponent(p.user)+(p.pass?':'+encodeURIComponent(p.pass):'')+'@':'';var s=p.type==='SOCKS5'?'socks5':p.type.toLowerCase();return s+'://'+a+p.host+':'+p.port}

function parse(text){
  var m=String(text).trim().match(/^(socks5h?|socks5|https?):\/\/(?:([^:@\/]*)(?::([^@\/]*))?@)?([^:\/\s]+):(\d{1,5})\/?$/i);
  if(!m)return null;
  var port=+m[5];if(port<1||port>65535)return null;
  var sch=m[1].toLowerCase();
  return {id:uid(),name:m[4],type:sch.indexOf('socks')===0?'SOCKS5':sch==='https'?'HTTPS':'HTTP',host:m[4],port:port,user:m[2]?decodeURIComponent(m[2]):'',pass:m[3]?decodeURIComponent(m[3]):''};
}

function render(){
  var ul=$('#list');ul.innerHTML='';
  $('#empty').hidden=db.proxies.length>0;
  db.proxies.forEach(function(p){
    var li=document.createElement('li');li.className='item';li.dataset.active=String(db.active===p.id);
    li.innerHTML='<input type="radio" name="sel" aria-label="Use '+esc(p.name)+'" '+(db.active===p.id?'checked':'')+'>'+
      '<div><b>'+esc(p.name)+'<span class="badge">'+p.type+'</span></b><small>'+esc(p.host)+':'+p.port+(p.user?' · '+esc(p.user):'')+'</small></div>'+
      '<div class="mini"><button class="ghost" data-a="copy">Copy</button><button class="ghost" data-a="edit">Edit</button><button class="ghost" data-a="del">Delete</button></div>';
    li.querySelector('input').onchange=function(){if(status!=='disconnected'){toast('Disconnect first to switch proxy.');render();return}db.active=p.id;save();render();setState('disconnected')};
    li.querySelector('[data-a=copy]').onclick=function(){copy(url(p),'Proxy link copied.')};
    li.querySelector('[data-a=edit]').onclick=function(){openForm(p)};
    li.querySelector('[data-a=del]').onclick=function(){if(status!=='disconnected'){toast('Disconnect first.');return}if(confirm('Delete "'+p.name+'"?')){db.proxies=db.proxies.filter(function(x){return x.id!==p.id});if(db.active===p.id)db.active=null;save();render()}};
    ul.appendChild(li);
  });
  document.querySelectorAll('input[name=mode]').forEach(function(r){r.checked=r.value===db.mode});
  $('#modeHint').textContent=db.mode==='tunnel'?'All apps on the device go through the proxy.':'Only apps that read the system proxy setting use it.';
}

function copy(text,msg){
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(function(){toast(msg)},function(){fallback()})}else fallback();
  function fallback(){var t=document.createElement('textarea');t.value=text;document.body.appendChild(t);t.select();try{document.execCommand('copy');toast(msg)}catch(e){toast('Copy failed. Long-press to copy manually.')}t.remove()}
}

var LABELS={disconnected:'Disconnected',connecting:'Connecting…',connected:'Connected',error:'Connection failed'};
function setState(s,msg){
  status=s;var b=$('#power');b.dataset.s=s;
  b.setAttribute('aria-label',s==='connected'?'Disconnect':'Connect');
  $('#state').textContent=LABELS[s];
  var p=db.proxies.find(function(x){return x.id===db.active});
  $('#stateSub').textContent=msg||(s==='connected'&&p?'Traffic is routed through '+p.name+'.':p?'Selected: '+p.name+'.':'Pick a proxy below, then connect.');
}

window.onVpnState=function(s,msg){setState(s==='connected'||s==='connecting'||s==='error'?s:'disconnected',msg)};

$('#power').onclick=function(){
  if(status==='connecting')return;
  var br=bridge();
  if(status==='connected'){if(br)br.stop();setState('disconnected');return}
  var p=db.proxies.find(function(x){return x.id===db.active});
  if(!p){toast('Add and select a proxy first.');return}
  if(!br){setState('error','This build has no native VPN bridge, so no traffic is tunnelled. See README.txt.');return}
  setState('connecting');
  try{br.start(JSON.stringify({mode:db.mode,type:p.type,host:p.host,port:p.port,user:p.user,pass:p.pass}))}
  catch(e){setState('error','Native bridge error: '+e.message)}
};

document.querySelectorAll('input[name=mode]').forEach(function(r){r.onchange=function(){if(status!=='disconnected'){toast('Disconnect first to change mode.');render();return}db.mode=r.value;save();render()}});

function openForm(p){
  editingId=p?p.id:null;var f=$('#form');f.reset();$('#formErr').hidden=true;
  $('#dlgTitle').textContent=p?'Edit proxy':'Add proxy';
  if(p){['name','type','host','port','user','pass'].forEach(function(k){f.elements[k].value=p[k]||''})}
  $('#dlg').showModal();
}
$('#addBtn').onclick=function(){openForm(null)};
$('#cancel').onclick=function(){$('#dlg').close()};
$('#form').onsubmit=function(e){
  var f=e.target,port=+f.elements.port.value,host=f.elements.host.value.trim();
  if(!(port>=1&&port<=65535)||!/^[A-Za-z0-9.\-:\[\]]+$/.test(host)){e.preventDefault();var er=$('#formErr');er.textContent='Enter a valid host and a port between 1 and 65535.';er.hidden=false;return}
  var o={id:editingId||uid(),name:f.elements.name.value.trim(),type:f.elements.type.value,host:host,port:port,user:f.elements.user.value,pass:f.elements.pass.value};
  if(editingId){db.proxies=db.proxies.map(function(x){return x.id===editingId?o:x})}else{db.proxies.push(o);if(!db.active)db.active=o.id}
  save();render();setState(status);
};

var impMode='link';
function openImp(m){impMode=m;$('#impTitle').textContent=m==='link'?'Import proxy link':'Paste backup JSON';$('#impLabel').textContent=m==='link'?'Proxy link':'JSON backup';$('#impForm').reset();$('#impErr').hidden=true;$('#impForm').elements.text.placeholder=m==='link'?'socks5://user:pass@host:1080':'[{"name":"…","type":"SOCKS5","host":"…","port":1080}]';$('#imp').showModal()}
$('#importBtn').onclick=function(){openImp('link')};
$('#importJsonBtn').onclick=function(){openImp('json')};
$('#impCancel').onclick=function(){$('#imp').close()};
$('#impForm').onsubmit=function(e){
  var t=e.target.elements.text.value,er=$('#impErr');
  if(impMode==='link'){
    var p=parse(t);if(!p){e.preventDefault();er.textContent='Not a valid link. Use scheme://user:pass@host:port with socks5, http or https.';er.hidden=false;return}
    db.proxies.push(p);if(!db.active)db.active=p.id;
  }else{
    try{var a=JSON.parse(t);if(!Array.isArray(a))throw 0;var n=0;a.forEach(function(x){if(x&&x.host&&+x.port>0&&+x.port<65536&&['SOCKS5','HTTP','HTTPS'].indexOf(x.type)>-1){db.proxies.push({id:uid(),name:String(x.name||x.host),type:x.type,host:String(x.host),port:+x.port,user:String(x.user||''),pass:String(x.pass||'')});n++}});if(!n)throw 0;if(!db.active)db.active=db.proxies[0].id}
    catch(x){e.preventDefault();er.textContent='Not a valid backup. Expected a JSON list of proxies.';er.hidden=false;return}
  }
  save();render();setState(status);
};
$('#exportBtn').onclick=function(){if(!db.proxies.length){toast('Nothing to copy yet.');return}copy(JSON.stringify(db.proxies.map(function(p){return{name:p.name,type:p.type,host:p.host,port:p.port,user:p.user,pass:p.pass}}),null,2),'Backup copied. It contains passwords, so keep it private.')};

load();render();setState('disconnected');
$('#bridgeNote').textContent=bridge()?'':'Preview mode: this build can store proxies but cannot tunnel traffic (no native VPN bridge).';
})();
