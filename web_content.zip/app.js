"use strict";

// LUNA: protótipo web local. Os dados ficam no armazenamento do navegador.
const STORAGE_KEY = "luna_archive_v1";
const quotes = [
  "Você não precisa resolver o universo inteiro hoje.",
  "Registro confirmado: você continua sendo uma pessoa foda.",
  "Até as estrelas precisam de períodos de silêncio.",
  "Sua existência não precisa ser produtiva para ter valor.",
  "Mais uma órbita, mais uma história para contar.",
  "Você merece reconhecer as coisas boas que existem em você.",
  "Nem todo dia precisa ser extraordinário para ser importante.",
  "Seu universo também merece um pouco de descanso.",
  "Existem histórias bonitas até nos dias silenciosos.",
  "Você tem permissão para mudar de ideia e descobrir novos caminhos."
];
const $ = id => document.getElementById(id);
const uid = () => globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
};
const formatDate = value => {
  if (!value) return "Data não informada";
  const d = new Date(`${value}T12:00:00`);
  return Number.isNaN(d.getTime()) ? "Data não informada" : d.toLocaleDateString("pt-BR");
};
function initialData() {
  return {
    version: 1, theme: "dark", fontSize: 17, lastQuote: "",
    notebooks: [
      { id: uid(), name: "Diário pessoal" },
      { id: uid(), name: "Pensamentos" },
      { id: uid(), name: "Memórias" }
    ],
    notes: []
  };
}
function loadData() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return initialData();
  try {
    const d = JSON.parse(raw);
    if (d.version !== 1 || !Array.isArray(d.notes) || !Array.isArray(d.notebooks)) throw new Error("Formato inválido");
    d.theme = d.theme === "light" ? "light" : "dark";
    d.fontSize = Number(d.fontSize) || 17;
    d.lastQuote = d.lastQuote || "";
    return d;
  } catch (e) {
    console.error("Não foi possível ler os dados do LUNA.", e);
    alert("Os dados locais parecem inválidos. O LUNA não os sobrescreveu. Não limpe os dados do navegador.");
    throw e;
  }
}
let data = loadData();
let editingId = null;
let selectedNotebook = null;
let selectedDay = today();
let calendarMonth = new Date();
let isFavorite = false;
let saveTimer = null;
let dirty = false;

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    dirty = false;
    if (!$("editor").hidden) $("saveStatus").textContent = "✓ Arquivo atualizado";
    return true;
  } catch (e) {
    console.error("Erro ao salvar:", e);
    if (!$("editor").hidden) $("saveStatus").textContent = "Falha ao salvar!";
    alert("Não foi possível salvar. O armazenamento pode estar cheio. Exporte seus registros antes de continuar.");
    return false;
  }
}
function scheduleSave() {
  dirty = true;
  $("saveStatus").textContent = "Salvando...";
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    if (persist()) renderNotes();
  }, 350);
}
function flushSave() {
  clearTimeout(saveTimer);
  if (dirty) persist();
}
function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
function button(text, className, action) {
  const b = el("button", className, text);
  b.type = "button";
  b.addEventListener("click", action);
  return b;
}
function notebookName(id) {
  return data.notebooks.find(n => n.id === id)?.name || "Caderno desconhecido";
}
function noteDate(note) {
  return note.eventDate || note.createdAt.slice(0, 10);
}
function init() {
  applyPreferences();
  showDailyQuote();
  renderNotebooks();
  populateNotebookSelect();
  renderNotes();
  renderCalendar();
  $("currentDate").textContent = new Date().toLocaleDateString("pt-BR", {
    weekday: "long", day: "numeric", month: "long", year: "numeric"
  });
}
function showDailyQuote() {
  const pool = quotes.filter(q => q !== data.lastQuote);
  const quote = (pool.length ? pool : quotes)[Math.floor(Math.random() * (pool.length || quotes.length))];
  $("dailyQuote").textContent = quote;
  data.lastQuote = quote;
  persist();
}
function applyPreferences() {
  document.body.classList.toggle("light", data.theme === "light");
  document.body.style.fontSize = `${data.fontSize}px`;
  $("fontSize").value = String(data.fontSize);
  $("themeButton").textContent = data.theme === "dark" ? "☼" : "☾";
}
function renderNotebooks() {
  const list = $("notebookList");
  list.replaceChildren();
  data.notebooks.forEach(n => {
    const b = button(`☷ ${n.name}`, `notebook-chip ${selectedNotebook === n.id ? "active" : ""}`, () => {
      selectedNotebook = selectedNotebook === n.id ? null : n.id;
      renderNotebooks(); renderNotes();
    });
    b.setAttribute("aria-pressed", String(selectedNotebook === n.id));
    list.append(b);
  });
}
function populateNotebookSelect() {
  const select = $("noteNotebook");
  const current = select.value;
  select.replaceChildren();
  data.notebooks.forEach(n => {
    const opt = document.createElement("option");
    opt.value = n.id; opt.textContent = n.name; select.append(opt);
  });
  if (data.notebooks.some(n => n.id === current)) select.value = current;
  else if (selectedNotebook) select.value = selectedNotebook;
}
function renderNotes() {
  const list = $("notesList");
  list.replaceChildren();
  const query = $("searchInput").value.trim().toLocaleLowerCase("pt-BR");
  const notes = data.notes.filter(n =>
    `${n.title} ${n.content}`.toLocaleLowerCase("pt-BR").includes(query) &&
    (!selectedNotebook || n.notebookId === selectedNotebook)
  ).sort((a,b) => b.updatedAt.localeCompare(a.updatedAt));
  $("recordsHeading").textContent = query ? "Resultados da pesquisa" : selectedNotebook ? notebookName(selectedNotebook) : "Registros recentes";
  $("emptyMessage").hidden = notes.length > 0;
  notes.forEach(note => {
    const card = el("article", "note-card");
    card.append(el("h3", "note-title", `${note.favorite ? "★ " : ""}${note.title || "Sem título"}`));
    card.append(el("p", "note-meta", `${notebookName(note.notebookId)} · Criado em ${formatDate(note.createdAt.slice(0,10))}`));
    card.append(el("p", "note-preview", note.content.slice(0,220) || "Registro sem conteúdo."));
    if (note.eventDate) card.append(el("p", "note-meta", `Acontecimento: ${formatDate(note.eventDate)}`));
    const actions = el("div", "actions note-actions");
    actions.append(
      button("Abrir", "secondary", () => openEditor(note.id)),
      button(note.favorite ? "★ Favorita" : "☆ Favoritar", "secondary", () => toggleFavorite(note.id)),
      button("Excluir", "secondary", () => deleteNote(note.id))
    );
    card.append(actions); list.append(card);
  });
  renderCalendar();
}
function openEditor(id = null) {
  flushSave();
  editingId = id;
  const note = data.notes.find(n => n.id === id);
  $("editor").hidden = false;
  $("noteTitle").value = note?.title || "";
  $("noteContent").value = note?.content || "";
  $("noteDate").value = note?.eventDate || "";
  isFavorite = note?.favorite || false;
  populateNotebookSelect();
  if (note) $("noteNotebook").value = note.notebookId;
  else if (selectedNotebook) $("noteNotebook").value = selectedNotebook;
  $("favoriteButton").textContent = isFavorite ? "★ Favorito" : "☆ Favoritar";
  $("saveStatus").textContent = note ? `Última edição: ${formatDate(note.updatedAt.slice(0,10))}` : "Novo registro";
  $("editor").scrollIntoView({ behavior: "auto", block: "start" });
  $("noteTitle").focus();
}
function readEditor() {
  return {
    title: $("noteTitle").value.trim(),
    content: $("noteContent").value,
    notebookId: $("noteNotebook").value,
    eventDate: $("noteDate").value,
    favorite: isFavorite
  };
}
function saveNote() {
  flushSave();
  const fields = readEditor();
  if (!fields.notebookId) return alert("Crie um caderno antes de registrar suas memórias.");
  const now = new Date().toISOString();
  if (editingId) {
    const note = data.notes.find(n => n.id === editingId);
    if (!note) return;
    Object.assign(note, fields, { updatedAt: now });
  } else {
    data.notes.unshift({ id: uid(), ...fields, createdAt: now, updatedAt: now });
  }
  dirty = true;
  if (persist()) {
    $("editor").hidden = true;
    editingId = null;
    renderNotebooks(); renderNotes();
  }
}
function autosaveEditor() {
  if ($("editor").hidden) return;
  const fields = readEditor();
  if (!fields.notebookId) return;
  if (!editingId && !fields.title && !fields.content && !fields.eventDate) return;
  const now = new Date().toISOString();
  if (!editingId) {
    const note = { id: uid(), ...fields, createdAt: now, updatedAt: now };
    data.notes.unshift(note);
    editingId = note.id;
  } else {
    const note = data.notes.find(n => n.id === editingId);
    if (!note) return;
    Object.assign(note, fields, { updatedAt: now });
  }
  scheduleSave();
}
function toggleFavorite(id) {
  flushSave();
  const note = data.notes.find(n => n.id === id);
  if (!note) return;
  note.favorite = !note.favorite;
  note.updatedAt = new Date().toISOString();
  if (persist()) renderNotes();
}
function deleteNote(id) {
  flushSave();
  const note = data.notes.find(n => n.id === id);
  if (!note || !confirm(`Excluir "${note.title || "Sem título"}" permanentemente?`)) return;
  data.notes = data.notes.filter(n => n.id !== id);
  if (editingId === id) { editingId = null; $("editor").hidden = true; }
  if (persist()) renderNotes();
}
function renderCalendar() {
  const grid = $("calendarGrid");
  if (!grid) return;
  grid.replaceChildren();
  const year = calendarMonth.getFullYear(), month = calendarMonth.getMonth();
  $("monthLabel").textContent = calendarMonth.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  ["D","S","T","Q","Q","S","S"].forEach(d => grid.append(el("div","calendar-cell weekday",d)));
  const first = new Date(year, month, 1).getDay();
  const days = new Date(year, month + 1, 0).getDate();
  for (let i=0; i<first; i++) grid.append(el("div","calendar-cell"));
  for (let day=1; day<=days; day++) {
    const date = `${year}-${String(month+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
    const hasNotes = data.notes.some(n => noteDate(n) === date);
    const b = button(String(day), `calendar-cell ${hasNotes ? "has-notes" : ""} ${selectedDay === date ? "selected" : ""}`, () => {
      selectedDay = date; renderCalendar();
    });
    b.setAttribute("aria-label", `${day}, ${hasNotes ? "com registros" : "sem registros"}`);
    grid.append(b);
  }
  $("selectedDayLabel").textContent = `Registros de ${formatDate(selectedDay)}`;
  const dayNotes = $("dayNotes");
  dayNotes.replaceChildren();
  data.notes.filter(n => noteDate(n) === selectedDay).forEach(n => {
    dayNotes.append(button(`☷ ${n.title || "Sem título"}`, "secondary", () => openEditor(n.id)));
  });
}
function addNotebook() {
  const name = prompt("Qual será o nome do novo caderno?");
  if (!name?.trim()) return;
  const notebook = { id: uid(), name: name.trim() };
  data.notebooks.push(notebook);
  selectedNotebook = notebook.id;
  if (persist()) { renderNotebooks(); populateNotebookSelect(); renderNotes(); }
}
function exportText() {
  flushSave();
  const notes = selectedNotebook ? data.notes.filter(n => n.notebookId === selectedNotebook) : data.notes;
  const content = notes.map(n => [
    n.title || "Sem título",
    `Caderno: ${notebookName(n.notebookId)}`,
    `Criado em: ${formatDate(n.createdAt.slice(0,10))}`,
    `Última edição: ${new Date(n.updatedAt).toLocaleString("pt-BR")}`,
    n.eventDate ? `Acontecimento: ${formatDate(n.eventDate)}` : "",
    "", n.content, "\n----------------------------------------\n"
  ].filter(Boolean).join("\n")).join("\n");
  const blob = new Blob([`LUNA | ARQUIVO DE MEMÓRIAS\n\n${content}`], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "luna-registros.txt"; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
$("newNoteButton").addEventListener("click", () => openEditor());
$("saveButton").addEventListener("click", saveNote);
$("cancelButton").addEventListener("click", () => {
  flushSave(); $("editor").hidden = true; editingId = null; renderNotes();
});
$("favoriteButton").addEventListener("click", () => {
  isFavorite = !isFavorite;
  $("favoriteButton").textContent = isFavorite ? "★ Favorito" : "☆ Favoritar";
  autosaveEditor();
});
["noteTitle","noteContent","noteNotebook","noteDate"].forEach(id => {
  $(id).addEventListener("input", autosaveEditor);
  $(id).addEventListener("change", autosaveEditor);
});
$("searchInput").addEventListener("input", renderNotes);
$("addNotebookButton").addEventListener("click", addNotebook);
$("showAllButton").addEventListener("click", () => {
  selectedNotebook = null; $("searchInput").value = ""; renderNotebooks(); renderNotes();
});
$("themeButton").addEventListener("click", () => {
  data.theme = data.theme === "dark" ? "light" : "dark";
  if (persist()) applyPreferences();
});
$("fontSize").addEventListener("change", e => {
  data.fontSize = Number(e.target.value);
  if (persist()) applyPreferences();
});
$("prevMonth").addEventListener("click", () => {
  calendarMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth()-1, 1);
  renderCalendar();
});
$("nextMonth").addEventListener("click", () => {
  calendarMonth = new Date(calendarMonth.getFullYear(), calendarMonth.getMonth()+1, 1);
  renderCalendar();
});
$("exportButton").addEventListener("click", exportText);
window.addEventListener("pagehide", flushSave);
init();
