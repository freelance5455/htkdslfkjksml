const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let postCount = 0;
let joinedCount = 0;

function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 2200);
}

function openScreen(name) {
  $$('.screen').forEach(screen => screen.classList.toggle('active', screen.id === name));
  $$('.nav-item').forEach(btn => btn.classList.toggle('active', btn.dataset.screen === name));
  window.scrollTo({top: 0, behavior: 'smooth'});
}
$$('.nav-item').forEach(btn => btn.addEventListener('click', () => openScreen(btn.dataset.screen)));

$('#post-input').addEventListener('input', e => $('#char-count').textContent = `${e.target.value.length}/500`);
$('#publish-btn').addEventListener('click', () => {
  const field = $('#post-input');
  const value = field.value.trim();
  if (!value) return toast('Escreva alguma coisa antes de publicar.');
  const article = document.createElement('article');
  article.className = 'panel post-card';
  const top = document.createElement('div');
  top.className = 'post-top';
  top.innerHTML = '<div class="avatar avatar-pink">V</div><div><strong>Você</strong><small>Agora mesmo · Seu mural</small></div>';
  const paragraph = document.createElement('p');
  paragraph.textContent = value;
  const actions = document.createElement('div');
  actions.className = 'post-actions';
  actions.innerHTML = '<button class="like-btn">♡ Curtir <b>0</b></button><button class="comment-btn">💬 Comentar</button>';
  article.append(top, paragraph, actions);
  $('#feed').prepend(article);
  field.value = '';
  $('#char-count').textContent = '0/500';
  postCount++;
  $('#post-total').textContent = postCount;
  toast('Publicação adicionada ao mural!');
});
$('#feed').addEventListener('click', e => {
  const button = e.target.closest('.like-btn');
  if (button) {
    const liked = button.classList.toggle('liked');
    const count = button.querySelector('b');
    if (count) count.textContent = Math.max(0, Number(count.textContent) + (liked ? 1 : -1));
    button.firstChild.textContent = liked ? '♥ Curtido ' : '♡ Curtir ';
  }
  if (e.target.closest('.comment-btn')) toast('Comentários serão adicionados em uma próxima etapa.');
});

$('#community-search').addEventListener('input', e => {
  const query = e.target.value.toLowerCase();
  $$('.community-card').forEach(card => card.hidden = !card.dataset.name.toLowerCase().includes(query));
});
$('#community-list').addEventListener('click', e => {
  const btn = e.target.closest('.join-btn');
  if (!btn) return;
  const joined = btn.classList.toggle('joined');
  btn.textContent = joined ? 'Participando ✓' : 'Participar';
  joinedCount += joined ? 1 : -1;
  $('#community-total').textContent = joinedCount;
  toast(joined ? 'Você entrou na comunidade!' : 'Você saiu da comunidade.');
});

$('#edit-profile').addEventListener('click', () => {
  $('#name-input').value = $('#profile-name').textContent === 'Seu perfil' ? '' : $('#profile-name').textContent;
  $('#bio-input').value = $('#profile-bio').textContent === 'Conte um pouco sobre você.' ? '' : $('#profile-bio').textContent;
  $('#profile-dialog').showModal();
});
$('#profile-form').addEventListener('submit', e => {
  if (e.submitter?.value !== 'save') return;
  e.preventDefault();
  const name = $('#name-input').value.trim() || 'Seu perfil';
  const bio = $('#bio-input').value.trim() || 'Conte um pouco sobre você.';
  $('#profile-name').textContent = name;
  $('#profile-bio').textContent = bio;
  $('#about-text').textContent = bio;
  $('#profile-dialog').close();
  toast('Perfil atualizado nesta demonstração!');
});

$('#create-community').addEventListener('click', () => $('#community-dialog').showModal());
$('#community-form').addEventListener('submit', e => {
  if (e.submitter?.value !== 'save') return;
  e.preventDefault();
  const name = $('#new-community-name').value.trim();
  const description = $('#new-community-description').value.trim();
  if (!name) return;
  const card = document.createElement('article');
  card.className = 'panel community-card';
  card.dataset.name = name;
  const icon = document.createElement('div');
  icon.className = 'community-icon pink-icon';
  icon.textContent = '💗';
  const info = document.createElement('div');
  info.className = 'community-info';
  const heading = document.createElement('h3'); heading.textContent = name;
  const desc = document.createElement('p'); desc.textContent = description || 'Uma nova comunidade.';
  const small = document.createElement('small'); small.textContent = 'Criada por você';
  info.append(heading, desc, small);
  const join = document.createElement('button'); join.className = 'join-btn'; join.textContent = 'Participar';
  card.append(icon, info, join);
  $('#community-list').prepend(card);
  $('#community-dialog').close();
  $('#community-form').reset();
  toast('Comunidade criada nesta demonstração!');
});
$('#notifications').addEventListener('click', () => toast('Você não tem notificações novas.'));
