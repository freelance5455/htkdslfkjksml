const STORAGE_KEY = 'tavars_v1';

const emptyData = {
  settings: { shopName: "Tavar’s", currency: "UZS", lowStock: 2 },
  products: [],
  sales: [],
  expenses: []
};

const icons = {
  dashboard: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 13h6V4H4v9Zm10 7h6V4h-6v16ZM4 20h6v-4H4v4Z"/></svg>',
  box: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m12 3 8 4.4v9.2L12 21l-8-4.4V7.4L12 3Z"/><path d="m4.4 7.5 7.6 4.2 7.6-4.2M12 11.7V21"/></svg>',
  plus: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
  sale: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 7h12l-1 11H7L6 7Z"/><path d="M9 7a3 3 0 0 1 6 0"/></svg>',
  truck: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h11v10H3zM14 10h4l3 3v3h-7zM6 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm11 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/></svg>',
  money: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8.5"/><path d="M12 7v10M15 9.2c-.5-.7-1.5-1.2-3-1.2-1.5 0-2.5.8-2.5 1.8s1 1.6 2.5 1.9 2.5.7 2.5 1.8-1 1.8-2.5 1.8-2.7-.5-3.2-1.2"/></svg>',
  settings: '<svg class="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 8.2a3.8 3.8 0 1 0 0 7.6 3.8 3.8 0 0 0 0-7.6Z"/><path d="m19 13.5 1.4 1.1-1.7 3-1.6-.6a7.6 7.6 0 0 1-1.4.8l-.2 1.7h-3.4l-.2-1.7a7.6 7.6 0 0 1-1.4-.8l-1.6.6-1.7-3L8.5 14a8 8 0 0 1 0-1.9l-1.4-1.1 1.7-3 1.6.6c.4-.3.9-.6 1.4-.8L12 6h3.4l.2 1.8c.5.2 1 .5 1.4.8l1.6-.6 1.7 3-1.4 1.1c.1.5.1 1 .1 1.4s0 .9-.1 1.4Z"/></svg>'
};

function clone(obj) { return JSON.parse(JSON.stringify(obj)); }
function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return clone(emptyData);
    const parsed = JSON.parse(raw);
    return {
      settings: { ...emptyData.settings, ...(parsed.settings || {}) },
      products: Array.isArray(parsed.products) ? parsed.products : [],
      sales: Array.isArray(parsed.sales) ? parsed.sales : [],
      expenses: Array.isArray(parsed.expenses) ? parsed.expenses : []
    };
  } catch (e) {
    console.error(e);
    return clone(emptyData);
  }
}
function saveData(data) { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
function uid(prefix='id') { return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`; }
function money(value) { return new Intl.NumberFormat('uz-UZ', { maximumFractionDigits: 0 }).format(Math.round(Number(value) || 0)) + ' so‘m'; }
function num(value) { const n = Number(value); return Number.isFinite(n) ? n : 0; }
function dateISO(value=new Date()) { return new Date(value).toISOString(); }
function dateText(value) { return new Intl.DateTimeFormat('uz-UZ', { day:'2-digit', month:'short', year:'numeric' }).format(new Date(value)); }
function monthText(value) { return new Intl.DateTimeFormat('uz-UZ', { month:'short', year:'numeric' }).format(new Date(value)); }
function escapeHtml(s='') { return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function currentPage() { return document.body.dataset.page || 'dashboard'; }
function qs(sel) { return document.querySelector(sel); }

function seedIfFirstLaunch() {
  const data = loadData();
  if (localStorage.getItem('tavars_seen') === '1') return;
  localStorage.setItem('tavars_seen', '1');
  saveData(data);
  setTimeout(() => openWelcome(), 650);
}

function showSplash() {
  const splash = qs('#splash');
  if (!splash) return;
  setTimeout(() => splash.classList.add('hide'), 1050);
}

function navTemplate() {
  const page = currentPage();
  const items = [
    ['dashboard.html','dashboard','Bosh sahifa'],
    ['inventory.html','box','Zapchastlar'],
    ['add-product.html','plus','Qo‘shish'],
    ['sales.html','sale','Sotish'],
    ['restock.html','truck','Olib kelish'],
    ['finance.html','money','Foyda / Zarar'],
    ['settings.html','settings','Sozlamalar']
  ];
  return `
    <aside class="sidebar">
      <nav class="nav">${items.map(([href,key,label]) => `<a class="${page===key?'active':''}" href="${href}">${icons[key]}<span>${label}</span>${key==='box'?`<span id="nav-stock-count" class="nav-count">0</span>`:''}</a>`).join('')}</nav>
    </aside>`;
}
function bottomNavTemplate() {
  const page = currentPage();
  const items = [
    ['dashboard.html','dashboard','Bosh'], ['inventory.html','box','Ombor'], ['add-product.html','plus','Qo‘shish'], ['sales.html','sale','Sotish'], ['finance.html','money','Moliya']
  ];
  return `<nav class="bottom-nav">${items.map(([href,key,label])=>`<a class="${page===key?'active':''}" href="${href}">${icons[key]}<span>${label}</span></a>`).join('')}</nav>`;
}

function fillCommon() {
  const data = loadData();
  const brandTitle = qs('#brand-title');
  const brandSub = qs('#brand-sub');
  if (brandTitle) brandTitle.textContent = data.settings.shopName || 'Tavar’s';
  if (brandSub) brandSub.textContent = 'Velosiped zapchastlari boshqaruvi';
  const shellNav = qs('#shell-nav'); if (shellNav) shellNav.innerHTML = navTemplate();
  const shellBottom = qs('#shell-bottom'); if (shellBottom) shellBottom.innerHTML = bottomNavTemplate();
  const count = qs('#nav-stock-count'); if (count) count.textContent = totalUnits(data.products);
}

function totalUnits(products) { return products.reduce((a,p)=>a+num(p.qty),0); }
function totalValue(products) { return products.reduce((a,p)=>a+num(p.qty)*num(p.cost),0); }
function lowStockProducts(products) { return products.filter(p => num(p.qty) <= num(loadData().settings.lowStock)); }
function monthStart(d=new Date()) { return new Date(d.getFullYear(), d.getMonth(), 1); }
function metrics(data=loadData()) {
  const start = monthStart();
  const monthSales = data.sales.filter(s => new Date(s.date) >= start);
  const revenue = monthSales.reduce((a,s)=>a+num(s.total),0);
  const cost = monthSales.reduce((a,s)=>a+num(s.costTotal),0);
  const expenses = data.expenses.filter(e => new Date(e.date) >= start).reduce((a,e)=>a+num(e.amount),0);
  const gross = revenue - cost;
  const net = gross - expenses;
  const soldUnits = monthSales.reduce((a,s)=>a+num(s.qty),0);
  return { revenue, cost, expenses, gross, net, soldUnits, stockUnits: totalUnits(data.products), stockValue: totalValue(data.products) };
}
function toast(message) {
  const el = qs('#toast'); if (!el) return;
  el.textContent = message; el.classList.add('show');
  clearTimeout(window.__toastT);
  window.__toastT = setTimeout(()=>el.classList.remove('show'), 2400);
}
function openModal(title, bodyHtml, actionsHtml='') {
  const host = qs('#modal-host'); if (!host) return;
  host.innerHTML = `<div class="modal-backdrop show" id="active-modal"><div class="modal"><div class="modal-head"><div><div class="page-kicker">Tavar’s</div><h3 style="margin:4px 0 0">${escapeHtml(title)}</h3></div><button class="btn small ghost" data-close-modal>✕</button></div>${bodyHtml}${actionsHtml?`<div class="form-actions">${actionsHtml}</div>`:''}</div></div>`;
  qs('#active-modal').addEventListener('click', e => { if (e.target.id === 'active-modal' || e.target.closest('[data-close-modal]')) closeModal(); });
}
function closeModal() { const host=qs('#modal-host'); if (host) host.innerHTML=''; }
function openWelcome() {
  openModal('Tavar’s ga xush kelibsiz', `
    <p class="page-note">Ilova mahsulotlar, sotuvlar, foyda-zarar va olib kelinadigan zapchastlarni bir joyda boshqarish uchun yaratilgan.</p>
    <div class="notice" style="margin-top:14px"><strong>Ma’lumotlaringiz shu telefonda saqlanadi.</strong><br>Internet bo‘lmasa ham asosiy funksiyalar ishlaydi.</div>
    <div class="grid grid-2" style="margin-top:14px">
      <div class="card tight"><strong>1</strong><div class="muted" style="margin-top:4px">Zapchast qo‘shing</div></div>
      <div class="card tight"><strong>2</strong><div class="muted" style="margin-top:4px">Sotilganda “Sotish” ni bosing</div></div>
      <div class="card tight"><strong>3</strong><div class="muted" style="margin-top:4px">Foyda va zarar avtomatik yuradi</div></div>
      <div class="card tight"><strong>4</strong><div class="muted" style="margin-top:4px">Backup orqali ma’lumotni saqlab oling</div></div>
    </div>
  `, `<button class="btn primary" data-close-modal>Boshlash</button>`);
}

function renderDashboard() {
  const data = loadData(); const m = metrics(data);
  const low = lowStockProducts(data.products);
  qs('#dashboard-stats').innerHTML = `
    <div class="card stat-card"><div class="stat-icon">${icons.box}</div><div class="stat-label">Omborda dona</div><div class="stat-value">${m.stockUnits}</div><div class="stat-foot">Jami mavjud zapchastlar</div></div>
    <div class="card stat-card"><div class="stat-icon">◈</div><div class="stat-label">Ombor qiymati</div><div class="stat-value">${money(m.stockValue)}</div><div class="stat-foot">Tannarx bo‘yicha</div></div>
    <div class="card stat-card"><div class="stat-icon">↗</div><div class="stat-label">Bu oy tushum</div><div class="stat-value">${money(m.revenue)}</div><div class="stat-foot">Sotuvlar jami</div></div>
    <div class="card stat-card"><div class="stat-icon">₿</div><div class="stat-label">Bu oy sof natija</div><div class="stat-value ${m.net>=0?'good-text':'bad-text'}">${money(m.net)}</div><div class="stat-foot">Foyda − xarajatlar</div></div>`;

  qs('#dashboard-panels').innerHTML = `
    <div class="card">
      <div class="toolbar"><div><h3 class="card-title">Oylik ko‘rinish</h3><div class="card-sub">${monthText(new Date())}</div></div><a class="btn small" href="finance.html">Batafsil</a></div>
      <div class="kpi-line"><span class="muted">Tushum</span><strong>${money(m.revenue)}</strong></div>
      <div class="kpi-line"><span class="muted">Mahsulot tannarxi</span><strong>${money(m.cost)}</strong></div>
      <div class="kpi-line"><span class="muted">Qo‘shimcha xarajat</span><strong>${money(m.expenses)}</strong></div>
      <div class="kpi-line"><span class="muted">Sof foyda / zarar</span><strong class="${m.net>=0?'good-text':'bad-text'}">${money(m.net)}</strong></div>
    </div>
    <div class="card">
      <div class="toolbar"><div><h3 class="card-title">Kam qolgan zapchastlar</h3><div class="card-sub">Omborni o‘z vaqtida to‘ldiring</div></div><a class="btn small" href="restock.html">Ko‘rish</a></div>
      ${low.length ? `<div class="product-list">${low.slice(0,6).map(productRow).join('')}</div>` : `<div class="empty"><strong>Ombor holati yaxshi ✅</strong>Kam miqdordagi zapchast topilmadi.</div>`}
    </div>`;

  qs('#recent-sales').innerHTML = data.sales.length ? `<div class="table-wrap"><table><thead><tr><th>Zapchast</th><th>Miqdor</th><th>Jami</th><th>Sana</th></tr></thead><tbody>${data.sales.slice().sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,8).map(s=>`<tr><td>${escapeHtml(s.productName)}</td><td>${s.qty}</td><td>${money(s.total)}</td><td>${dateText(s.date)}</td></tr>`).join('')}</tbody></table></div>` : `<div class="empty"><strong>Hali sotuv yo‘q</strong>Mahsulot sotilganda shu yerda ko‘rinadi.</div>`;
}
function productRow(p) {
  const img = p.image || 'data:image/svg+xml;utf8,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="100%" height="100%" rx="18" fill="#102036"/><path d="M25 45l10-18 10 15 7-7 7 15H25Z" fill="#7c9cff"/></svg>`);
  const status = num(p.qty)<=0 ? '<span class="badge danger">Tugagan</span>' : `<span class="badge ${num(p.qty)<=num(loadData().settings.lowStock)?'warn':'good'}">${p.qty} dona</span>`;
  return `<div class="product-row"><img class="product-thumb" src="${img}" alt=""><div class="product-main"><div class="product-name">${escapeHtml(p.name)}</div><div class="product-meta">${escapeHtml(p.category||'Boshqa')} · ${money(p.salePrice)} sotish narxi</div></div><div>${status}</div></div>`;
}

function initInventory() {
  let filter=''; let category='all';
  const data = loadData();
  const categories = [...new Set(data.products.map(p=>p.category).filter(Boolean))].sort();
  qs('#category-filter').innerHTML = `<option value="all">Barcha category</option>` + categories.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
  const render=()=>{
    const now=loadData();
    const products=now.products.filter(p=>(!filter||p.name.toLowerCase().includes(filter.toLowerCase()))&&(category==='all'||p.category===category));
    qs('#inventory-count').textContent = `${products.length} xil · ${totalUnits(products)} dona`;
    qs('#inventory-body').innerHTML=products.length?`<div class="table-wrap"><table><thead><tr><th>Zapchast</th><th>Category</th><th>Qoldiq</th><th>Tannarx</th><th>Sotish</th><th>Dona foyda</th><th>Amal</th></tr></thead><tbody>${products.map(p=>{
      const profit=num(p.salePrice)-num(p.cost); const status=num(p.qty)<=0?'danger':num(p.qty)<=num(now.settings.lowStock)?'warn':'good';
      return `<tr><td><strong>${escapeHtml(p.name)}</strong><div class="muted" style="font-size:11px;margin-top:4px">Qo‘shilgan: ${dateText(p.createdAt)}</div></td><td><span class="badge">${escapeHtml(p.category||'Boshqa')}</span></td><td><span class="badge ${status}">${p.qty} dona</span></td><td>${money(p.cost)}</td><td>${money(p.salePrice)}</td><td class="${profit>=0?'good-text':'bad-text'}">${money(profit)}</td><td><div style="display:flex;gap:6px"><button class="btn small" data-edit="${p.id}">Tahrir</button><button class="btn small danger" data-delete="${p.id}">O‘chirish</button></div></td></tr>`;
    }).join('')}</tbody></table></div>`:`<div class="empty"><strong>Zapchast topilmadi</strong>Filtrni o‘zgartiring yoki yangi mahsulot qo‘shing.</div>`;
    fillCommon();
  };
  qs('#search-input').addEventListener('input', e=>{filter=e.target.value;render();});
  qs('#category-filter').addEventListener('change', e=>{category=e.target.value;render();});
  qs('#inventory-body').addEventListener('click', e=>{
    const edit=e.target.closest('[data-edit]'); const del=e.target.closest('[data-delete]');
    if(edit) editProduct(edit.dataset.edit);
    if(del) deleteProduct(del.dataset.delete, render);
  });
  render();
}
function editProduct(id) {
  const data=loadData(); const p=data.products.find(x=>x.id===id); if(!p) return;
  openModal('Zapchastni tahrirlash', `<form id="edit-product-form" class="form-grid">
    <div class="field full"><span class="label">Nomi</span><input class="input" name="name" required value="${escapeHtml(p.name)}"></div>
    <div class="field"><span class="label">Category</span><input class="input" name="category" value="${escapeHtml(p.category||'Boshqa')}"></div>
    <div class="field"><span class="label">Miqdor</span><input class="input" type="number" min="0" name="qty" required value="${p.qty}"></div>
    <div class="field"><span class="label">Tannarx</span><input class="input" type="number" min="0" name="cost" required value="${p.cost}"></div>
    <div class="field"><span class="label">Sotish narxi</span><input class="input" type="number" min="0" name="salePrice" required value="${p.salePrice}"></div>
    <div class="field full"><span class="label">Izoh</span><textarea class="textarea" name="note">${escapeHtml(p.note||'')}</textarea></div>
  </form>`, `<button class="btn" data-close-modal>Bekor qilish</button><button class="btn primary" id="save-edit">Saqlash</button>`);
  qs('#save-edit').addEventListener('click',()=>{
    const form=qs('#edit-product-form'); const fd=new FormData(form); const d=loadData(); const idx=d.products.findIndex(x=>x.id===id); if(idx<0)return;
    d.products[idx]={...d.products[idx],name:String(fd.get('name')).trim(),category:String(fd.get('category')).trim()||'Boshqa',qty:num(fd.get('qty')),cost:num(fd.get('cost')),salePrice:num(fd.get('salePrice')),note:String(fd.get('note')).trim()};
    saveData(d); closeModal(); toast('Zapchast yangilandi'); initInventory();
  });
}
function deleteProduct(id, rerender) {
  const data=loadData(); const p=data.products.find(x=>x.id===id); if(!p)return;
  openModal('Zapchastni o‘chirish', `<div class="notice"><strong>${escapeHtml(p.name)}</strong> o‘chiriladi. Bu amalni keyin qaytarib bo‘lmaydi.</div>`, `<button class="btn" data-close-modal>Bekor qilish</button><button class="btn danger" id="confirm-delete">O‘chirish</button>`);
  qs('#confirm-delete').addEventListener('click',()=>{const d=loadData(); d.products=d.products.filter(x=>x.id!==id); saveData(d); closeModal(); toast('Zapchast o‘chirildi'); rerender();});
}

function initAddProduct() {
  qs('#add-product-form').addEventListener('submit', async e=>{
    e.preventDefault(); const fd=new FormData(e.currentTarget); const imageFile=fd.get('image');
    let image='';
    if(imageFile && imageFile.size){ image=await compressImage(imageFile); }
    const data=loadData();
    data.products.unshift({ id:uid('p'), name:String(fd.get('name')).trim(), category:String(fd.get('category')).trim()||'Boshqa', qty:num(fd.get('qty')), cost:num(fd.get('cost')), salePrice:num(fd.get('salePrice')), image, note:String(fd.get('note')).trim(), createdAt:dateISO() });
    saveData(data); e.currentTarget.reset(); qs('#img-preview').innerHTML=''; toast('Zapchast omborga qo‘shildi ✅');
  });
  qs('#image-input').addEventListener('change', async e=>{const f=e.target.files?.[0]; if(!f)return; const img=await compressImage(f,160); qs('#img-preview').innerHTML=`<img class="product-thumb" style="width:72px;height:72px" src="${img}" alt="Tanlangan rasm">`;});
}
function compressImage(file, max=600) { return new Promise((resolve,reject)=>{ const reader=new FileReader(); reader.onload=()=>{ const img=new Image(); img.onload=()=>{ const ratio=Math.min(1,max/Math.max(img.width,img.height)); const c=document.createElement('canvas'); c.width=Math.max(1,Math.round(img.width*ratio)); c.height=Math.max(1,Math.round(img.height*ratio)); c.getContext('2d').drawImage(img,0,0,c.width,c.height); resolve(c.toDataURL('image/jpeg',.78)); }; img.onerror=reject; img.src=reader.result; }; reader.onerror=reject; reader.readAsDataURL(file); }); }

function initSales() {
  const updatePreview=()=>{
    const d=loadData(); const id=qs('#sale-product').value; const p=d.products.find(x=>x.id===id); if(!p){qs('#sale-preview').textContent='Mahsulot tanlang'; return;}
    const qty=Math.max(1,num(qs('#sale-qty').value)); const total=qty*num(p.salePrice); const profit=qty*(num(p.salePrice)-num(p.cost));
    qs('#sale-preview').innerHTML=`<div class="kpi-line"><span class="muted">Ombordagi qoldiq</span><strong>${p.qty} dona</strong></div><div class="kpi-line"><span class="muted">Sotuv jami</span><strong>${money(total)}</strong></div><div class="kpi-line"><span class="muted">Taxminiy foyda</span><strong class="${profit>=0?'good-text':'bad-text'}">${money(profit)}</strong></div>`;
    qs('#sale-submit').disabled = qty<=0 || qty>num(p.qty);
  };
  const render=()=>{const d=loadData(); qs('#sale-product').innerHTML=`<option value="">Zapchast tanlang</option>`+d.products.filter(p=>num(p.qty)>0).map(p=>`<option value="${p.id}">${escapeHtml(p.name)} — ${p.qty} dona</option>`).join(''); qs('#sale-history').innerHTML=d.sales.length?`<div class="table-wrap"><table><thead><tr><th>Mahsulot</th><th>Miqdor</th><th>Tushum</th><th>Foyda</th><th>Sana</th></tr></thead><tbody>${d.sales.slice().sort((a,b)=>new Date(b.date)-new Date(a.date)).map(s=>`<tr><td>${escapeHtml(s.productName)}</td><td>${s.qty}</td><td>${money(s.total)}</td><td class="${s.profit>=0?'good-text':'bad-text'}">${money(s.profit)}</td><td>${dateText(s.date)}</td></tr>`).join('')}</tbody></table></div>`:`<div class="empty"><strong>Hali sotuvlar yo‘q</strong>Birinci sotuvni kiriting.</div>`; updatePreview(); };
  qs('#sale-product').addEventListener('change',updatePreview); qs('#sale-qty').addEventListener('input',updatePreview);
  qs('#sale-form').addEventListener('submit',e=>{e.preventDefault(); const d=loadData(); const p=d.products.find(x=>x.id===qs('#sale-product').value); const qty=Math.floor(num(qs('#sale-qty').value)); if(!p||qty<1||qty>p.qty)return toast('Miqdorni tekshiring'); const total=qty*p.salePrice; const costTotal=qty*p.cost; d.products=d.products.map(x=>x.id===p.id?{...x,qty:x.qty-qty}:x); d.sales.unshift({id:uid('s'),productId:p.id,productName:p.name,qty,total,costTotal,profit:total-costTotal,date:dateISO()}); saveData(d); e.currentTarget.reset(); toast(`${qty} dona ${p.name} sotildi ✅`); render(); fillCommon(); });
  render();
}

function initRestock() {
  const render=()=>{const d=loadData(); const low=d.products.filter(p=>num(p.qty)<=num(d.settings.lowStock)); qs('#restock-summary').textContent=`${low.length} ta zapchast e’tibor talab qiladi`;
    qs('#restock-list').innerHTML=low.length?low.map(p=>`<div class="card tight"><div class="toolbar"><div><h3 class="card-title">${escapeHtml(p.name)}</h3><div class="card-sub">${escapeHtml(p.category||'Boshqa')} · hozir ${p.qty} dona</div></div><span class="badge ${p.qty<=0?'danger':'warn'}">${p.qty<=0?'Tugagan':'Kam qolgan'}</span></div><div class="form-grid"><div class="field"><span class="label">Olib kelish miqdori</span><input class="input" type="number" min="1" id="restock-${p.id}" value="${Math.max(2, d.settings.lowStock+2)}"></div><div class="field"><span class="label">Izoh</span><input class="input" id="restock-note-${p.id}" placeholder="Masalan: payshanba kuni"></div></div><div class="form-actions"><button class="btn primary" data-restock="${p.id}">${icons.truck} Olib kelish</button></div></div>`).join(''):`<div class="card empty"><strong>Hammasi joyida ✅</strong>Kam qolgan zapchast yo‘q.</div>`;
  };
  qs('#restock-list').addEventListener('click',e=>{const b=e.target.closest('[data-restock]'); if(!b)return; const id=b.dataset.restock; const qty=Math.floor(num(qs('#restock-'+id).value)); if(qty<1)return toast('Miqdor 1 dan kam bo‘lmasin'); const d=loadData(); const p=d.products.find(x=>x.id===id); if(!p)return; p.qty+=qty; p.note=String(qs('#restock-note-'+id).value||p.note||''); saveData(d); toast(`${p.name}: +${qty} dona qo‘shildi 📦`); render(); fillCommon();});
  qs('#global-low-stock').textContent=loadData().settings.lowStock; render();
}

function initFinance() {
  const render=()=>{const d=loadData(); const m=metrics(d); qs('#finance-stats').innerHTML=`<div class="card stat-card"><div class="stat-label">Tushum</div><div class="stat-value">${money(m.revenue)}</div><div class="stat-foot">Bu oy</div></div><div class="card stat-card"><div class="stat-label">Yalpi foyda</div><div class="stat-value ${m.gross>=0?'good-text':'bad-text'}">${money(m.gross)}</div><div class="stat-foot">Tushum − tannarx</div></div><div class="card stat-card"><div class="stat-label">Xarajat</div><div class="stat-value">${money(m.expenses)}</div><div class="stat-foot">Bu oy</div></div><div class="card stat-card"><div class="stat-label">Sof natija</div><div class="stat-value ${m.net>=0?'good-text':'bad-text'}">${money(m.net)}</div><div class="stat-foot">Yakuniy</div></div>`;
    qs('#expense-history').innerHTML=d.expenses.length?`<div class="table-wrap"><table><thead><tr><th>Nomi</th><th>Summa</th><th>Sana</th><th>Izoh</th></tr></thead><tbody>${d.expenses.slice().sort((a,b)=>new Date(b.date)-new Date(a.date)).map(x=>`<tr><td>${escapeHtml(x.name)}</td><td>${money(x.amount)}</td><td>${dateText(x.date)}</td><td>${escapeHtml(x.note||'—')}</td></tr>`).join('')}</tbody></table></div>`:`<div class="empty"><strong>Xarajat kiritilmagan</strong>Ijara, transport yoki boshqa xarajatlarni shu yerda yozing.</div>`;
    qs('#profit-bars').innerHTML=buildMonthlyBars(d);
  };
  qs('#expense-form').addEventListener('submit',e=>{e.preventDefault();const fd=new FormData(e.currentTarget);const d=loadData();d.expenses.unshift({id:uid('e'),name:String(fd.get('name')).trim()||'Boshqa xarajat',amount:num(fd.get('amount')),note:String(fd.get('note')).trim(),date:dateISO()});saveData(d);e.currentTarget.reset();toast('Xarajat saqlandi');render();});
  render();
}
function buildMonthlyBars(d) {
  const months=[]; const now=new Date(); for(let i=5;i>=0;i--){const dt=new Date(now.getFullYear(),now.getMonth()-i,1); months.push(dt);} const values=months.map(m=>{const next=new Date(m.getFullYear(),m.getMonth()+1,1); const rev=d.sales.filter(s=>new Date(s.date)>=m&&new Date(s.date)<next).reduce((a,s)=>a+num(s.profit),0); return Math.max(0,rev);}); const max=Math.max(1,...values); return `<div class="chart">${months.map((m,i)=>`<div class="bar"><div class="bar-value">${values[i] ? Math.round(values[i]/1000)+'k' : '0'}</div><div class="bar-fill" style="height:${Math.max(5,Math.round(values[i]/max*120))}px"></div><div class="bar-label">${new Intl.DateTimeFormat('uz-UZ',{month:'short'}).format(m)}</div></div>`).join('')}</div>`;
}

function initSettings() {
  const d=loadData(); qs('#shop-name').value=d.settings.shopName; qs('#low-stock').value=d.settings.lowStock;
  qs('#settings-form').addEventListener('submit',e=>{e.preventDefault(); const fd=new FormData(e.currentTarget); const data=loadData(); data.settings.shopName=String(fd.get('shopName')).trim()||'Tavar’s'; data.settings.lowStock=Math.max(0,Math.floor(num(fd.get('lowStock')))); saveData(data); toast('Sozlamalar saqlandi ✅'); fillCommon();});
  qs('#export-btn').addEventListener('click',()=>{const data=loadData();downloadFile(`tavars-backup-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify(data,null,2),'application/json');toast('Backup yuklab olindi');});
  qs('#import-input').addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const incoming=JSON.parse(r.result); if(!Array.isArray(incoming.products)||!Array.isArray(incoming.sales)||!Array.isArray(incoming.expenses))throw new Error('invalid'); saveData({...clone(emptyData),...incoming,settings:{...emptyData.settings,...(incoming.settings||{})}}); toast('Backup tiklandi ✅'); setTimeout(()=>location.reload(),500);}catch{toast('Backup fayli noto‘g‘ri');}};r.readAsText(f);});
  qs('#clear-btn').addEventListener('click',()=>openModal('Barcha ma’lumotlarni tozalash',`<div class="notice"><strong>Diqqat.</strong> Mahsulotlar, sotuvlar va xarajatlar o‘chiriladi. Oldin backup oling.</div>`,`<button class="btn" data-close-modal>Bekor qilish</button><button class="btn danger" id="clear-confirm">Hammasini o‘chirish</button>`));
  document.addEventListener('click',e=>{if(e.target.id==='clear-confirm'){localStorage.removeItem(STORAGE_KEY); closeModal(); toast('Ma’lumotlar tozalandi'); setTimeout(()=>location.reload(),500);}});
}
function downloadFile(name,text,type){const blob=new Blob([text],{type});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();URL.revokeObjectURL(url);}

function boot() {
  fillCommon();
  showSplash();
  const page=currentPage();
  if(page==='dashboard') renderDashboard();
  if(page==='inventory') initInventory();
  if(page==='add') initAddProduct();
  if(page==='sales') initSales();
  if(page==='restock') initRestock();
  if(page==='finance') initFinance();
  if(page==='settings') initSettings();
  seedIfFirstLaunch();
}

document.addEventListener('DOMContentLoaded', boot);
