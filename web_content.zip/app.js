
import {
  db,
  dbRef,
  dbOnValue,
  dbUpdate,
  login,
  resetPassword,
  logout,
  watchAuth
} from "./firebase.js";

// عناصر التطبيق
const $ = id => document.getElementById(id);

let currentUser = null;
let currentRole = localStorage.getItem("steerguard_role");
let unsubscribeDatabase = null;
let motionStarted = false;
let motionStartTime = 0;
let alarmSent = false;
let protectionArmed = false;

// عرض الرسائل
function showMessage(message) {
  const element = $("message");
  if (element) element.textContent = message;
}

// الانتقال بين الشاشات
function showScreen(id) {
  document.querySelectorAll(".screen").forEach(screen => {
    screen.hidden = true;
  });

  if ($(id)) $(id).hidden = false;
}

// حالة الاتصال
function setConnection(connected, message) {
  const element = $("connectionStatus");

  if (element) {
    element.textContent = message;
    element.dataset.connected = connected ? "true" : "false";
  }
}

// تسجيل الدخول
$("loginBtn").addEventListener("click", async () => {
  const email = $("email").value.trim();
  const password = $("password").value;

  if (!email || !password) {
    showMessage("أدخل البريد الإلكتروني وكلمة المرور");
    return;
  }

  try {
    showMessage("جاري تسجيل الدخول...");
    await login(email, password);
    showMessage("تم تسجيل الدخول بنجاح");

  } catch (error) {
    console.error("LOGIN ERROR:", error);
    showMessage("خطأ تسجيل الدخول: " + error.code);
  }
});

// استعادة كلمة المرور
$("resetPasswordBtn").addEventListener("click", async () => {
  const email = $("email").value.trim();

  if (!email) {
    showMessage("اكتب البريد الإلكتروني أولاً");
    return;
  }

  try {
    await resetPassword(email);
    showMessage("تم إرسال رابط إعادة تعيين كلمة المرور");
  } catch (error) {
    showMessage("تعذر الإرسال: " + error.code);
  }
});

// اختيار وظيفة الهاتف
$("sensorRoleBtn").addEventListener("click", () => {
  selectRole("sensor");
});

$("monitorRoleBtn").addEventListener("click", () => {
  selectRole("monitor");
});

function selectRole(role) {
  currentRole = role;
  localStorage.setItem("steerguard_role", role);
  openDashboard();
}

// لوحة التحكم
function openDashboard() {
  showScreen("dashboard");

  $("roleText").textContent =
    currentRole === "sensor"
      ? "هاتف الحساس"
      : "هاتف المراقبة";

  createSensorControls();
  startDatabaseListener();
}

// إنشاء زر تشغيل الحساس
function createSensorControls() {
  const oldPanel = $("sensorPanel");

  if (oldPanel) oldPanel.remove();

  if (currentRole !== "sensor") return;

  const panel = document.createElement("div");
  panel.id = "sensorPanel";
  panel.className = "card";

  panel.innerHTML = `
    <h3>مراقبة حركة السكوتر</h3>
    <p id="sensorStatus">الحساس متوقف</p>
    <button id="startSensorBtn" class="primary-button" type="button">
      تشغيل حساس الحركة
    </button>
  `;

  $("dashboard").insertBefore(
    panel,
    $("logoutBtn")
  );

  $("startSensorBtn").addEventListener(
    "click",
    startMotionSensor
  );
}

// قراءة بيانات Firebase
function startDatabaseListener() {
  if (!currentUser || unsubscribeDatabase) return;

  setConnection(false, "جاري الاتصال...");

  unsubscribeDatabase = dbOnValue(
    dbRef(db),
    snapshot => {
      const data = snapshot.val() || {};

      setConnection(true, "متصل");

      protectionArmed = data.armed === true;

      $("protectionStatus").textContent =
        protectionArmed
          ? "الحماية مفعلة"
          : "الحماية متوقفة";

      $("alarmStatus").textContent =
        data.alarm === true
          ? "إنذار نشط"
          : "لا يوجد إنذار";

      if ($("sensorStatus")) {
        $("sensorStatus").textContent =
          motionStarted
            ? "الحساس يعمل"
            : "الحساس متوقف";
      }
    },
    error => {
      console.error(
        "DATABASE ERROR:",
        error.code,
        error.message
      );

      setConnection(false, "خطأ: " + error.code);
      unsubscribeDatabase = null;
    }
  );
}

// تفعيل الحماية
$("armBtn").addEventListener("click", () => {
  updateProtection(true);
});

// إيقاف الحماية
$("disarmBtn").addEventListener("click", () => {
  updateProtection(false);
});

async function updateProtection(value) {
  try {
    await dbUpdate(dbRef(db), {
      armed: value,
      alarm: false
    });

    showMessage(
      value
        ? "تم تفعيل الحماية"
        : "تم إيقاف الحماية"
    );

  } catch (error) {
    console.error("UPDATE ERROR:", error);
    showMessage("خطأ في التحديث: " + error.code);
  }
}

// تشغيل حساس الهاتف
async function startMotionSensor() {
  if (motionStarted) return;

  try {
    if (
      typeof DeviceMotionEvent === "undefined"
    ) {
      showMessage("هذا المتصفح لا يدعم حساس الحركة");
      return;
    }

    if (
      typeof DeviceMotionEvent.requestPermission === "function"
    ) {
      const permission =
        await DeviceMotionEvent.requestPermission();

      if (permission !== "granted") {
        showMessage("لم يتم السماح باستخدام الحساس");
        return;
      }
    }

    window.addEventListener(
      "devicemotion",
      handleMotion
    );

    motionStarted = true;

    $("sensorStatus").textContent = "الحساس يعمل";
    showMessage("تم تشغيل حساس الحركة");

  } catch (error) {
    console.error("SENSOR ERROR:", error);
    showMessage("تعذر تشغيل الحساس");
  }
}

// تحليل حركة الهاتف
function handleMotion(event) {
  if (!protectionArmed) {
    motionStartTime = 0;
    alarmSent = false;
    return;
  }

  const acceleration = event.accelerationIncludingGravity;

  if (!acceleration) return;

  const x = acceleration.x || 0;
  const y = acceleration.y || 0;
  const z = acceleration.z || 0;

  const magnitude = Math.sqrt(
    x * x + y * y + z * z
  );

  // الحركة تختلف عن الجاذبية الطبيعية
  const movement = Math.abs(magnitude - 9.81);

  if (movement > 4) {
    if (!motionStartTime) {
      motionStartTime = Date.now();
    }

    if (
      Date.now() - motionStartTime >= 500 &&
      !alarmSent
    ) {
      alarmSent = true;
      sendAlarm();
    }

  } else if (movement < 2) {
    motionStartTime = 0;
    alarmSent = false;
  }
}

// إرسال الإنذار
async function sendAlarm() {
  try {
    await dbUpdate(dbRef(db), {
      alarm: true,
      movement_detected: true
    });

    showMessage("تحذير: تم اكتشاف حركة!");

  } catch (error) {
    console.error("ALARM ERROR:", error);
    showMessage("تعذر إرسال الإنذار: " + error.code);
  }
}

// تغيير المظهر
$("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("red");

  localStorage.setItem(
    "steerguard_theme",
    document.body.classList.contains("red")
      ? "red"
      : "blue"
  );
});

if (localStorage.getItem("steerguard_theme") === "red") {
  document.body.classList.add("red");
}

// تسجيل الخروج
$("logoutBtn").addEventListener("click", async () => {
  window.removeEventListener("devicemotion", handleMotion);

  motionStarted = false;
  motionStartTime = 0;
  alarmSent = false;

  if (unsubscribeDatabase) {
    unsubscribeDatabase();
    unsubscribeDatabase = null;
  }

  try {
    await logout();
  } catch (error) {
    showMessage("تعذر تسجيل الخروج");
  }
});

// متابعة تسجيل الدخول
watchAuth(user => {
  currentUser = user;

  if (user) {
    console.log("SIGNED IN UID:", user.uid);

    if (currentRole) {
      openDashboard();
    } else {
      showScreen("roleScreen");
    }

  } else {
    if (unsubscribeDatabase) {
      unsubscribeDatabase();
      unsubscribeDatabase = null;
    }

    currentUser = null;
    motionStarted = false;

    window.removeEventListener("devicemotion", handleMotion);

    showScreen("loginScreen");
  }

}, error => {
  console.error("AUTH STATE ERROR:", error);
  showMessage("خطأ في التحقق من الحساب");
});

console.log("SteerGuard initialized");
