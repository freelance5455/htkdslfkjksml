document.getElementById('msg').textContent = 'ES module loaded OK at ' + new Date().toLocaleTimeString();
