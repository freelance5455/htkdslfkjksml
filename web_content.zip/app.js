(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const expressionEl = $("expression"), resultEl = $("result"), statusEl = $("statusMessage");
  const historyDrawer = $("historyDrawer"), historyList = $("historyList"), emptyHistory = $("emptyHistory");
  const scientificGrid = $("scientificGrid");
  let expression = "";
  let justEvaluated = false;
  let degrees = true;
  let scientificOpen = true;
  let toastTimer;
  let history = readJSON("nova-calculator-history", []);
  let lightTheme = readJSON("nova-calculator-light", false);

  if (lightTheme) document.body.classList.add("light");
  renderHistory();
  updateDisplay();

  function readJSON(key, fallback) {
    try { const v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); }
    catch (_) { return fallback; }
  }
  function saveJSON(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); }
    catch (_) { showToast("Storage is full; history may not be saved."); }
  }
  function formatNumber(value) {
    if (!Number.isFinite(value)) throw new Error("Result is not a finite number");
    if (Object.is(value, -0)) value = 0;
    if (Math.abs(value) >= 1e12 || (Math.abs(value) > 0 && Math.abs(value) < 1e-8)) {
      return value.toExponential(7).replace(/\.?0+e/, "e").replace("e+", "e");
    }
    return Number(value.toPrecision(12)).toString();
  }
  function updateDisplay(answer) {
    expressionEl.textContent = expression ? expression.replace(/\*/g, "×").replace(/\//g, "÷").replace(/-/g, "−") : "";
    if (answer !== undefined) resultEl.textContent = answer;
    else if (!expression) resultEl.textContent = "0";
    $("angleButton").textContent = degrees ? "DEG" : "RAD";
    $("modeLabel").textContent = scientificOpen ? "SCIENTIFIC" : "STANDARD";
    $("scientificToggle").innerHTML = scientificOpen ? "ƒx <span>Scientific</span>" : "ƒx <span>Show</span>";
  }
  function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2100);
  }
  function popResult() {
    resultEl.classList.remove("pop");
    void resultEl.offsetWidth;
    resultEl.classList.add("pop");
  }
  function appendValue(value) {
    if (justEvaluated && /[0-9.]|pi|e|sin|cos|tan|ln|log|sqrt|\(/.test(value)) expression = "";
    justEvaluated = false;
    if (value === ".") {
      const current = expression.split(/[+\-*/^()]/).pop();
      if (current.includes(".")) return;
      if (!current) expression += "0";
    }
    expression += value;
    updateDisplay();
    statusEl.textContent = "Editing";
  }
  function backspace() {
    if (justEvaluated) { expression = ""; justEvaluated = false; updateDisplay(); return; }
    const funcs = ["sqrt(", "sin(", "cos(", "tan(", "log(", "ln("];
    const match = funcs.find(f => expression.endsWith(f));
    expression = expression.slice(0, -(match ? match.length : 1));
    updateDisplay();
  }
  function clearAll() { expression = ""; justEvaluated = false; updateDisplay(); statusEl.textContent = "Ready"; }
  function factorial(n) {
    if (!Number.isInteger(n) || n < 0 || n > 170) throw new Error("Factorial needs a whole number from 0 to 170");
    let out = 1;
    for (let i = 2; i <= n; i++) out *= i;
    return out;
  }
  function tokenize(input) {
    const s = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/π/g, "pi").replace(/\s+/g, "");
    const tokens = [];
    let i = 0;
    while (i < s.length) {
      const rest = s.slice(i);
      const number = rest.match(/^(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i);
      const word = rest.match(/^[a-zA-Z]+/);
      if (number) { tokens.push({type:"number", value:Number(number[0])}); i += number[0].length; continue; }
      if (word) {
        const w = word[0].toLowerCase();
        if (["pi","e","sin","cos","tan","ln","log","sqrt"].includes(w)) tokens.push({type:"name", value:w});
        else throw new Error("Unknown function: " + w);
        i += word[0].length; continue;
      }
      const c = s[i];
      if ("+-*/^()!".includes(c)) tokens.push({type:"op", value:c});
      else throw new Error("Invalid character");
      i++;
    }
    return tokens;
  }
  function calculate(input) {
    const tokens = tokenize(input);
    let p = 0;
    const peek = () => tokens[p];
    const eat = (v) => { if (peek() && peek().value === v) { p++; return true; } return false; };
    const toAngle = x => degrees ? x * Math.PI / 180 : x;
    const parsePrimary = () => {
      const t = peek();
      if (!t) throw new Error("Incomplete expression");
      if (eat("+")) return parseUnary();
      if (eat("-")) return -parseUnary();
      if (eat("(")) { const v = parseAddSub(); if (!eat(")")) throw new Error("Missing closing bracket"); return v; }
      if (t.type === "number") { p++; return t.value; }
      if (t.type === "name") {
        p++;
        if (t.value === "pi") return Math.PI;
        if (t.value === "e") return Math.E;
        if (!eat("(")) throw new Error(t.value + " needs parentheses");
        const a = parseAddSub();
        if (!eat(")")) throw new Error("Missing closing bracket");
        switch (t.value) {
          case "sin": return Math.sin(toAngle(a));
          case "cos": return Math.cos(toAngle(a));
          case "tan": if (Math.abs(Math.cos(toAngle(a))) < 1e-12) throw new Error("Tangent is undefined here"); return Math.tan(toAngle(a));
          case "ln": if (a <= 0) throw new Error("ln needs a positive number"); return Math.log(a);
          case "log": if (a <= 0) throw new Error("log needs a positive number"); return Math.log10(a);
          case "sqrt": if (a < 0) throw new Error("Square root needs a non-negative number"); return Math.sqrt(a);
        }
      }
      throw new Error("Check your expression");
    };
    const parsePostfix = () => {
      let v = parsePrimary();
      while (eat("!")) v = factorial(v);
      return v;
    };
    const parsePower = () => {
      let v = parsePostfix();
      if (eat("^")) v = Math.pow(v, parseUnary());
      return v;
    };
    const parseUnary = () => {
      if (eat("+")) return parseUnary();
      if (eat("-")) return -parseUnary();
      return parsePower();
    };
    const startsPrimary = t => t && (t.type === "number" || t.type === "name" || t.value === "(");
    const parseMultiply = () => {
      let v = parseUnary();
      while (peek() && ["*","/"].includes(peek().value) || startsPrimary(peek())) {
        if (eat("*")) v *= parseUnary();
        else if (eat("/")) { const d = parseUnary(); if (d === 0) throw new Error("Cannot divide by zero"); v /= d; }
        else if (startsPrimary(peek())) v *= parseUnary();
      }
      return v;
    };
    const parseAddSub = () => {
      let v = parseMultiply();
      while (peek() && ["+","-"].includes(peek().value)) {
        if (eat("+")) v += parseMultiply();
        else if (eat("-")) v -= parseMultiply();
      }
      return v;
    };
    if (!tokens.length) throw new Error("Enter a calculation first");
    const answer = parseAddSub();
    if (p < tokens.length) throw new Error("Check the expression near " + tokens[p].value);
    if (!Number.isFinite(answer)) throw new Error("Result is outside the supported range");
    return answer;
  }
  function prettyExpression(s) { return s.replace(/\*/g,"×").replace(/\//g,"÷").replace(/-/g,"−").replace(/pi/g,"π"); }
  function evaluate() {
    if (!expression.trim()) { showToast("Enter a calculation first"); return; }
    try {
      const raw = calculate(expression);
      const answer = formatNumber(raw);
      history.unshift({ expression: prettyExpression(expression), answer, time: Date.now() });
      history = history.slice(0, 60);
      saveJSON("nova-calculator-history", history);
      renderHistory();
      expression = answer;
      justEvaluated = true;
      expressionEl.textContent = "ANSWER";
      resultEl.textContent = answer;
      statusEl.textContent = "Calculated successfully";
      popResult();
    } catch (err) {
      statusEl.textContent = "Check expression";
      showToast(err.message || "Could not calculate");
    }
  }
  function renderHistory() {
    $("historyCount").textContent = history.length;
    $("historySummary").textContent = history.length ? `${history.length} saved calculation${history.length === 1 ? "" : "s"}` : "Your recent calculations";
    historyList.innerHTML = "";
    emptyHistory.classList.toggle("visible", history.length === 0);
    history.forEach((item, index) => {
      const article = document.createElement("article");
      article.className = "history-item";
      const eq = document.createElement("div"); eq.className = "history-equation"; eq.textContent = item.expression;
      const row = document.createElement("div"); row.className = "history-answer-row";
      const ans = document.createElement("div"); ans.className = "history-answer"; ans.textContent = item.answer;
      const use = document.createElement("button"); use.className = "history-use"; use.textContent = "Use";
      use.addEventListener("click", () => { expression = item.answer; justEvaluated = true; updateDisplay(); closeHistory(); showToast("Result placed in calculator"); });
      row.append(ans, use);
      const time = document.createElement("div"); time.className = "history-time";
      time.textContent = new Date(item.time).toLocaleString([], {dateStyle:"medium", timeStyle:"short"});
      article.append(eq, row, time);
      historyList.appendChild(article);
    });
  }
  function openHistory() {
    historyDrawer.classList.add("open"); $("scrim").classList.add("visible");
    historyDrawer.setAttribute("aria-hidden","false");
  }
  function closeHistory() {
    historyDrawer.classList.remove("open"); $("scrim").classList.remove("visible");
    historyDrawer.setAttribute("aria-hidden","true");
  }
  function handleAction(action) {
    switch(action) {
      case "clear": clearAll(); break;
      case "backspace": backspace(); break;
      case "equals": evaluate(); break;
      case "toggle-scientific":
        scientificOpen = !scientificOpen;
        scientificGrid.classList.toggle("collapsed", !scientificOpen);
        updateDisplay(); break;
      case "percent":
        if (!expression) return;
        try { expression = formatNumber(calculate(expression) / 100); justEvaluated = true; updateDisplay(); }
        catch (e) { showToast(e.message); }
        break;
      case "sign":
        if (!expression) { expression = "-"; }
        else if (justEvaluated) { expression = formatNumber(-Number(expression)); justEvaluated = true; }
        else expression = "-(" + expression + ")";
        updateDisplay(); break;
    }
  }
  document.querySelectorAll("[data-value]").forEach(button => button.addEventListener("click", () => appendValue(button.dataset.value)));
  document.querySelectorAll("[data-action]").forEach(button => button.addEventListener("click", () => handleAction(button.dataset.action)));
  $("angleButton").addEventListener("click", () => { degrees = !degrees; updateDisplay(); showToast(degrees ? "Degrees mode" : "Radians mode"); });
  $("themeButton").addEventListener("click", () => {
    lightTheme = !lightTheme; document.body.classList.toggle("light", lightTheme);
    saveJSON("nova-calculator-light", lightTheme); showToast(lightTheme ? "Light theme enabled" : "Dark theme enabled");
  });
  $("historyToggle").addEventListener("click", openHistory);
  $("closeHistory").addEventListener("click", closeHistory);
  $("scrim").addEventListener("click", closeHistory);
  $("clearHistory").addEventListener("click", () => {
    if (!history.length) { showToast("History is already empty"); return; }
    history = []; saveJSON("nova-calculator-history", history); renderHistory(); showToast("History cleared");
  });
  $("copyButton").addEventListener("click", async () => {
    const value = resultEl.textContent;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) await navigator.clipboard.writeText(value);
      else { const ta = document.createElement("textarea"); ta.value = value; document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove(); }
      showToast("Result copied");
    } catch (_) { showToast("Copy isn't supported here"); }
  });
  document.addEventListener("keydown", e => {
    if (e.key === "Enter" || e.key === "=") { e.preventDefault(); evaluate(); }
    else if (e.key === "Escape") { closeHistory(); clearAll(); }
    else if (e.key === "Backspace") backspace();
    else if (/^[0-9.+\-*/^()]$/.test(e.key)) appendValue(e.key);
  });
  // Installable web-app metadata is included for compatible browsers; APK packaging is a separate step.
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
})();
