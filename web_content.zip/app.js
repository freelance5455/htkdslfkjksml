// خارق 4 — واجهة مجلس العقول
import { Marked } from "https://cdn.jsdelivr.net/npm/marked@15.0.7/lib/marked.esm.js";
import DOMPurify from "https://cdn.jsdelivr.net/npm/dompurify@3.2.4/dist/purify.es.mjs";
import hljs from "https://cdn.jsdelivr.net/gh/highlightjs/cdn-release@11.10.0/build/es/highlight.min.js";

const RAW_API = window.__API_BASE__ || "";
const API = RAW_API.startsWith("__PORT_") ? "" : RAW_API.replace(/\/$/, "");
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const fmtN = (n) => new Intl.NumberFormat("en-US").format(n);
const uid = () => Math.random().toString(36).slice(2, 10);
const secs = (ms) => (ms / 1000).toFixed(1) + "s";

/* ---------------- المجلس ---------------- */
const MEMBERS = {
  claude_opus_5_5: { name: "Claude", full: "Claude Opus 5.5", letter: "C", color: "var(--m-claude)", maker: "Anthropic" },
  gpt_5_4: { name: "GPT", full: "GPT-5.4", letter: "O", color: "var(--m-gpt)", maker: "OpenAI" },
  gemini_3_1_pro: { name: "Gemini", full: "Gemini 3.1 Pro", letter: "G", color: "var(--m-gemini)", maker: "Google" },
  grok_4_3: { name: "Grok", full: "Grok 4.3", letter: "X", color: "var(--m-grok)", maker: "xAI" },
};
const COUNCIL_IDS = Object.keys(MEMBERS);
const SINGLES = [
  { id: "claude_opus_5_5", label: "Claude وحده" },
  { id: "gpt_5_4", label: "GPT وحده" },
  { id: "gemini_3_1_pro", label: "Gemini وحده" },
  { id: "grok_4_3", label: "Grok وحده" },
  { id: "claude_sonnet_5_5", label: "Claude Sonnet" },
];
const SINGLE_META = { ...MEMBERS, gemini_3_flash: { name: "Flash", full: "Gemini 3 Flash", color: "var(--m-gemini)" }, claude_sonnet_5_5: { name: "Sonnet", full: "Claude Sonnet 5.5", color: "var(--m-claude)" } };

/* ---------------- الشخصيات ---------------- */
const ICONS = {
  spark: '<svg viewBox="0 0 24 24"><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M6 18l2.5-2.5M15.5 8.5 18 6"/></svg>',
  code: '<svg viewBox="0 0 24 24"><path d="m8 8-4 4 4 4M16 8l4 4-4 4M14 4l-4 16"/></svg>',
  pen: '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13 7 4 4"/></svg>',
  cap: '<svg viewBox="0 0 24 24"><path d="m2 9 10-5 10 5-10 5z"/><path d="M6 11v5c3 2 9 2 12 0v-5"/></svg>',
  globe: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.5 3 14.5 0 18M12 3c-3 3.5-3 14.5 0 18"/></svg>',
  chart: '<svg viewBox="0 0 24 24"><path d="M4 20V4M4 20h16"/><path d="m8 15 4-4 3 3 5-6"/></svg>',
  bulb: '<svg viewBox="0 0 24 24"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c.8.8 1 1.5 1 2.5h6c0-1 .2-1.7 1-2.5A6 6 0 0 0 12 3z"/></svg>',
  palette: '<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 1 0 0 18c1 0 1.5-.7 1.5-1.5 0-.4-.2-.8-.4-1.1-.3-.3-.4-.6-.4-1 0-.8.7-1.5 1.5-1.5H16a5 5 0 0 0 5-5c0-4.4-4-8-9-8z"/></svg>',
};
const PERSONAS = [
  { key: "all", name: "شامل", icon: "spark", prompt: "",
    starters: [["سؤال صعب للمجلس", "هل يمكن للذكاء الاصطناعي أن يصبح واعياً؟ أعطني أقوى الحجج مع وضد، ثم رأيك المرجّح."],
               ["ارسم لي", "ارسم بغداد في المستقبل ليلاً، أبراج زجاجية وأضواء ذهبية على نهر دجلة، أسلوب سينمائي"],
               ["خطة عملية", "ضع لي خطة 30 يوماً لإطلاق متجر إلكتروني صغير في العراق بميزانية محدودة."],
               ["قارن بين خيارين", "قارن بين العمل الحر والوظيفة الثابتة في جدول: الدخل، الاستقرار، الحرية، المخاطر."]] },
  { key: "code", name: "مبرمج", icon: "code", prompt: "أنت مهندس برمجيات خبير. اكتب كوداً صحيحاً وكاملاً وقابلاً للتشغيل داخل كتل كود مع تحديد اللغة، ثم اشرحه باختصار. عند طلب صفحة ويب أو لعبة اكتبها في ملف HTML واحد كامل وجميل.",
    starters: [["لعبة كاملة", "اكتب لعبة سيارات سباق ثنائية الأبعاد كاملة في ملف HTML واحد بـ canvas، مع نقاط وعوائق وسرعة متزايدة."],
               ["صفحة هبوط", "اكتب صفحة هبوط أنيقة لمقهى في ملف HTML واحد، بتصميم داكن وخطوط عربية."],
               ["بايثون", "اكتب كود بايثون يحلل نصاً ويحسب أكثر 10 كلمات تكراراً، ثم شغّله على مثال."],
               ["راجع كودي", "ما المشاكل في هذا الكود؟ for (var i=0;i<5;i++){ setTimeout(()=>console.log(i),100) }"]] },
  { key: "write", name: "كاتب", icon: "pen", prompt: "أنت كاتب محترف بأسلوب عربي فصيح وسلس. اهتم بالإيقاع وقوة الافتتاحية ووضوح الفكرة.",
    starters: [["منشور تسويقي", "اكتب منشوراً جذاباً لإنستغرام عن افتتاح مقهى جديد في بغداد."],
               ["قصة قصيرة", "اكتب قصة قصيرة من 250 كلمة عن طفل يكتشف مكتبة قديمة تحت بيت جده."],
               ["تحسين نص", "حسّن هذه الجملة واجعلها أقوى: نحن شركة جيدة ونقدم خدمات كثيرة للعملاء."],
               ["خطاب", "اكتب كلمة افتتاحية مؤثرة لحفل تخرج طلاب الهندسة."]] },
  { key: "teach", name: "معلّم", icon: "cap", prompt: "أنت معلّم صبور. اشرح خطوة بخطوة، واستخدم أمثلة، واختم بسؤال قصير يتحقق من الفهم.",
    starters: [["رياضيات", "علّمني حل معادلة من الدرجة الثانية خطوة بخطوة مع مثال."],
               ["فيزياء", "اشرح النسبية الخاصة لأينشتاين ببساطة مع أمثلة يومية."],
               ["لغة", "اشرح الفرق بين الفاعل ونائب الفاعل مع أمثلة."],
               ["اختبرني", "اعطني 5 أسئلة اختيار من متعدد عن تاريخ العراق، ثم صحح إجاباتي."]] },
  { key: "trans", name: "مترجم", icon: "globe", prompt: "أنت مترجم محترف. ترجم بدقة مع الحفاظ على المعنى والنبرة. إن لم تُحدَّد اللغة الهدف: العربية إلى الإنجليزية وغيرها إلى العربية. قدّم الترجمة أولاً ثم ملاحظات قصيرة عند الحاجة.",
    starters: [["عربي ← إنجليزي", "ترجم: نسعى لتقديم أفضل تجربة لعملائنا في كل مكان."],
               ["إنجليزي ← عربي", "Translate: The early bird catches the worm, but the second mouse gets the cheese."],
               ["بريد رسمي", "ترجم إلى الإنجليزية بأسلوب رسمي: نشكركم على تعاونكم ونتطلع إلى العمل معكم."],
               ["مصطلحات", "ما معنى: latency, throughput, bandwidth؟ بأمثلة."]] },
  { key: "analyze", name: "محلّل", icon: "chart", prompt: "أنت محلل بيانات وأعمال. نظّم إجابتك بعناوين وجداول، وفرّق بين الحقائق والافتراضات، واذكر حدود التحليل.",
    starters: [["SWOT", "اعمل تحليل SWOT لمشروع متجر إلكتروني لبيع الملابس في العراق."],
               ["بيانات", "مبيعات شهرية: 120, 135, 128, 160, 172, 190. حلّل الاتجاه وتوقّع الشهر القادم مع الافتراضات."],
               ["قرار", "أشتري سيارة جديدة بالتقسيط أم مستعملة نقداً؟ حلّل القرار."],
               ["حلّل صورة", "أرفق صورة رسم بياني أو فاتورة أو مستند، واطلب من المجلس تحليلها."]] },
  { key: "ideas", name: "عصف أفكار", icon: "bulb", prompt: "أنت مولّد أفكار جريء ومبدع. قدّم أفكاراً متنوعة وغير تقليدية مرقّمة، مع سطر يشرح لماذا كل فكرة مميزة.",
    starters: [["مشاريع", "10 أفكار مشاريع صغيرة برأس مال قليل في العراق."],
               ["أسماء", "اقترح 15 اسماً لتطبيق توصيل طعام، عربية وسهلة النطق."],
               ["محتوى", "أفكار لسلسلة فيديوهات قصيرة عن التقنية بالعربي."],
               ["حل مبتكر", "كيف نقلل الزحام أمام المدارس صباحاً؟ أفكار مبتكرة."]] },
];

/* ---------------- الحالة ---------------- */
const S = {
  mode: "council", model: "claude_opus_5_5", think: false, draw: false, aspect: "1:1",
  generating: false, abort: null, online: null,
  chats: [], current: null, persona: "all", files: [],
  settings: { extra: "", autoSpeak: false, voice: "charon" },
  theme: "dark",
};

/* ---------------- Markdown ---------------- */
let CODES = [];
const md = new Marked({ gfm: true, breaks: true, renderer: {
  code({ text, lang }) {
    const language = (lang || "").trim().split(/\s+/)[0].toLowerCase();
    let html;
    try { html = language && hljs.getLanguage(language) ? hljs.highlight(text, { language }).value : esc(text); } catch { html = esc(text); }
    const i = CODES.push({ text, lang: language }) - 1;
    const runnable = ["html", "htm", "xml", "svg", "js", "javascript", "py", "python"].includes(language) || (!language && /<html|<!doctype/i.test(text));
    return `<div class="codebox" data-i="${i}"><div class="codebox-head"><span class="lang">${esc(language || "code")}</span>
      ${runnable ? `<button class="run" data-code="run"><svg viewBox="0 0 24 24"><path d="M7 5v14l11-7z"/></svg>تشغيل</button>` : ""}
      <button data-code="copy"><svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/></svg>نسخ</button>
      <button data-code="save"><svg viewBox="0 0 24 24"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>حفظ</button></div>
      <pre><code class="hljs">${html}</code></pre></div>`;
  },
} });
function renderMD(src, el) {
  CODES = [];
  el.innerHTML = DOMPurify.sanitize(md.parse(src || ""), { ADD_ATTR: ["data-i", "data-code", "target"] });
  el._codes = CODES;
  $$("a", el).forEach((a) => { a.target = "_blank"; a.rel = "noopener noreferrer"; });
}

/* ---------------- المحادثات ---------------- */
const cur = () => S.chats.find((c) => c.id === S.current);
function newChat(silent) {
  if (S.generating) stopGen();
  const c = { id: uid(), title: "محادثة جديدة", created: Date.now(), persona: S.persona, messages: [] };
  S.chats.unshift(c); S.current = c.id; S.files = [];
  renderFiles(); renderList(); renderThread();
  if (!silent) $("#input").focus();
}
function renderList() {
  const q = $("#chatSearch").value.trim();
  const items = S.chats.filter((c) => c.messages.length && (!q || c.title.includes(q) || c.messages.some((m) => (m.content || m.prompt || "").includes(q))));
  $("#chatList").innerHTML = !items.length
    ? `<div class="chat-empty">${q ? "لا نتائج مطابقة." : "لا توجد محادثات بعد. المحادثات محفوظة في هذه الجلسة فقط؛ استخدم «تصدير» للاحتفاظ بها."}</div>`
    : `<div class="chat-group">هذه الجلسة</div>` + items.map((c) => `
      <div class="chat-item ${c.id === S.current ? "active" : ""}">
        <button class="open" data-open="${c.id}" title="${esc(c.title)}">${esc(c.title)}</button>
        <button class="mini" data-del="${c.id}" aria-label="حذف المحادثة"><svg viewBox="0 0 24 24"><path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12"/></svg></button>
      </div>`).join("");
}

/* ---------------- الواجهة الافتتاحية ---------------- */
function renderWelcome() {
  $("#personas").innerHTML = PERSONAS.map((p) => `<button class="persona" role="radio" aria-checked="${p.key === S.persona}" data-persona="${p.key}">${ICONS[p.icon]}${p.name}</button>`).join("");
  const p = PERSONAS.find((x) => x.key === S.persona);
  $("#starters").innerHTML = p.starters.map(([t, q]) => `<button class="starter" data-q="${esc(q)}"><b>${esc(t)}</b><span>${esc(q)}</span></button>`).join("");
  $("#personaTag").textContent = p.name;
}
function renderEngineSwitch() {
  const isSingle = S.mode === "single";
  $("#engineSwitch").innerHTML = `
    <button role="radio" aria-checked="${S.mode === "council"}" data-mode="council" title="المجلس: 4 عقول + دمج"><span class="dots">${COUNCIL_IDS.map((id) => `<i style="color:${MEMBERS[id].color}"></i>`).join("")}</span><span class="lbl">المجلس</span></button>
    <button role="radio" aria-checked="${S.mode === "fast"}" data-mode="fast" title="سريع: إجابة فورية"><svg viewBox="0 0 24 24" style="width:15px;height:15px"><path d="M13 3 5 14h6l-1 7 8-11h-6z"/></svg><span class="lbl">سريع</span></button>
    <select id="singleSel" class="${isSingle ? "on" : ""}" aria-label="نموذج واحد">
      <option value="" ${isSingle ? "" : "selected"}>نموذج واحد</option>
      ${SINGLES.map((m) => `<option value="${m.id}" ${isSingle && S.model === m.id ? "selected" : ""}>${m.label}</option>`).join("")}
    </select>`;
  const hint = S.draw ? "رسم صورة" : S.mode === "council" ? (S.think ? "المجلس + مراجعة" : "المجلس · 4 عقول") : S.mode === "fast" ? "سريع" : SINGLE_META[S.model]?.full || "";
  $("#modeHint").textContent = hint;
  $("#thinkBtn").disabled = S.mode !== "council" || S.draw;
  $("#thinkBtn").setAttribute("aria-pressed", String(S.think && S.mode === "council"));
}

/* ---------------- المرفقات ---------------- */
const fileIcon = '<svg viewBox="0 0 24 24"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/></svg>';
function shrinkImage(file) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => {
      const img = new Image();
      img.onload = () => {
        const max = 1600; let { width: w, height: h } = img;
        if (Math.max(w, h) > max) { const k = max / Math.max(w, h); w = Math.round(w * k); h = Math.round(h * k); }
        const cv = document.createElement("canvas"); cv.width = w; cv.height = h;
        cv.getContext("2d").drawImage(img, 0, 0, w, h);
        try { res(cv.toDataURL("image/jpeg", 0.86)); } catch { res(fr.result); }
      };
      img.onerror = rej; img.src = fr.result;
    };
    fr.onerror = rej; fr.readAsDataURL(file);
  });
}
async function addFiles(list) {
  for (const f of list) {
    if (f.type.startsWith("image/")) {
      if (S.files.filter((x) => x.img).length >= 4) { toast("الحد الأقصى 4 صور في الرسالة"); continue; }
      try { S.files.push({ id: uid(), name: f.name, img: await shrinkImage(f) }); } catch { toast(`تعذّر قراءة الصورة «${f.name}»`); }
      continue;
    }
    if (f.size > 500_000) { toast(`«${f.name}» كبير جداً (الحد 500 كيلوبايت للنصوص)`); continue; }
    const text = await f.text();
    if (/\u0000/.test(text.slice(0, 2000))) { toast(`«${f.name}» ليس ملفاً نصياً`); continue; }
    S.files.push({ id: uid(), name: f.name, text });
  }
  renderFiles();
}
function renderFiles() {
  $("#attachRow").innerHTML = S.files.map((f) => f.img
    ? `<span class="file-chip img"><img src="${f.img}" alt="${esc(f.name)}"><button type="button" data-unfile="${f.id}" aria-label="إزالة"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg></button></span>`
    : `<span class="file-chip">${fileIcon}<span>${esc(f.name)}</span><button type="button" data-unfile="${f.id}" aria-label="إزالة"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6 6 18"/></svg></button></span>`).join("");
}

/* ---------------- عرض المحادثة ---------------- */
const LOGO = '<svg><use href="#logo"/></svg>';
function renderThread() {
  const c = cur(); const thread = $("#thread");
  const empty = !c || !c.messages.length;
  $("#welcome").hidden = !empty; thread.innerHTML = "";
  if (empty) { renderWelcome(); return; }
  c.messages.forEach((m, i) => thread.appendChild(m.role === "user" ? userNode(m) : m.kind === "image" ? imageNode(m, i) : aiNode(m, i)));
  scrollEnd(true);
}
function userNode(m) {
  const d = document.createElement("div"); d.className = "msg user";
  const imgs = (m.images || []).map((u) => `<img src="${u}" alt="صورة مرفقة" data-zoom>`).join("");
  const files = (m.files || []).map((f) => `<span class="file-chip">${fileIcon}<span>${esc(f.name)}</span></span>`).join("");
  d.innerHTML = (imgs ? `<div class="thumbs">${imgs}</div>` : "") + (files ? `<div class="files">${files}</div>` : "") + (m.content ? `<div class="bubble"></div>` : "");
  if (m.content) $(".bubble", d).textContent = m.content;
  return d;
}
const toolsHTML = `<div class="msg-tools" hidden>
  <button data-tool="copy"><svg viewBox="0 0 24 24"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/></svg>نسخ</button>
  <button data-tool="speak"><svg viewBox="0 0 24 24"><path d="M4 10v4h4l5 4V6L8 10z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/></svg><span>استماع</span></button>
  <button data-tool="regen"><svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg>إعادة</button>
  <span class="stats"></span></div>`;

function aiNode(m, idx) {
  const d = document.createElement("div"); d.className = "msg ai"; d.dataset.idx = idx;
  const council = m.kind === "council";
  const meta = !council && m.model ? `<span class="single-tag"><i style="--c:${SINGLE_META[m.model]?.color}"></i>${esc(SINGLE_META[m.model]?.full || m.model)}</span>` : "";
  d.innerHTML = `<div class="avatar">${LOGO}</div><div class="ai-body">
    <div class="ai-meta"><b>خارق 4</b>${council ? `<span>المجلس</span>` : meta}</div>
    ${council ? `<div class="council">
      <div class="council-head"><span class="spin"></span><span class="stage-name">يستدعي المجلس…</span><span class="timer"></span></div>
      <div class="seats">${COUNCIL_IDS.map((id) => `<button class="seat" data-seat="${id}" aria-expanded="false" style="--c:${MEMBERS[id].color}">
        <span class="mono-badge">${MEMBERS[id].letter}</span><span class="s-name">${MEMBERS[id].name}</span><span class="s-state">بانتظار الدور</span></button>`).join("")}</div>
      <div class="draft" hidden><div class="draft-head"></div><div class="md"></div></div>
      <details class="review" hidden><summary>${ICONS.bulb}<span class="r-label">مراجعة نقدية للمسودات</span></summary><div class="md"></div></details>
      <div class="merge-line" hidden><span class="bolt">${LOGO}</span><span class="m-label"></span></div>
    </div>` : ""}
    <div class="md answer"></div>${toolsHTML}</div>`;
  paintAI(d, m, false);
  return d;
}
function paintCouncil(d, m, live) {
  const c = m.council; if (!c) return;
  const box = $(".council", d);
  const stageNames = { calling: "يستدعي المجلس…", drafts: "أربعة عقول تفكّر بالتوازي", review: "مراجعة نقدية: اتفاق وخلاف وأخطاء", synth: "خارق يدمج أفضل ما لديهم", done: "اكتمل" };
  const head = $(".council-head", box);
  $(".spin", head).style.display = live ? "" : "none";
  $(".stage-name", head).textContent = live ? stageNames[c.stage] || "…" : `قرار المجلس · ${fmtN(c.used?.length || 0)} من ${fmtN(COUNCIL_IDS.length)} عقول`;
  $(".timer", head).textContent = m.ms ? secs(m.ms) : "";
  COUNCIL_IDS.forEach((id) => {
    const s = c.seats[id] || {}; const el = $(`[data-seat="${id}"]`, box);
    el.classList.toggle("live", s.state === "live"); el.classList.toggle("done", s.state === "done"); el.classList.toggle("err", s.state === "err");
    $(".s-state", el).textContent = s.state === "live" ? `يكتب… ${fmtN(s.text?.length || 0)} حرف` : s.state === "done" ? `✓ ${secs(s.ms)}` : s.state === "err" ? "تعذّر الرد" : "بانتظار الدور";
    el.setAttribute("aria-expanded", String(c.open === id));
  });
  const dr = $(".draft", box);
  if (c.open && c.seats[c.open]) {
    dr.hidden = false; const mm = MEMBERS[c.open]; const s = c.seats[c.open];
    dr.style.setProperty("--c", mm.color);
    $(".draft-head", dr).innerHTML = `مسودة <b>${mm.full}</b> · ${esc(mm.maker)}${s.err ? " · " + esc(s.err) : ""}`;
    renderMD(s.text || (s.state === "live" ? "…" : ""), $(".md", dr));
  } else dr.hidden = true;
  const rv = $(".review", box);
  if (c.review) { rv.hidden = false; renderMD(c.review, $(".md", rv)); $(".r-label", rv).textContent = live && c.stage === "review" ? "المراجع يقارن المسودات الآن…" : "مراجعة نقدية للمسودات"; if (live && c.stage === "review") rv.open = true; }
  else rv.hidden = true;
  const ml = $(".merge-line", box);
  if (c.stage === "synth" || c.stage === "done") {
    ml.hidden = false; ml.classList.toggle("done", !live);
    $(".m-label", ml).textContent = c.fallback ? "تعذّر الدمج، نعرض أفضل مسودة متاحة" : live ? `يدمج ${fmtN(c.used?.length || 0)} مسودات في إجابة واحدة…` : `دُمجت ${fmtN(c.used?.length || 0)} مسودات في هذه الإجابة`;
  } else ml.hidden = true;
}
function paintAI(d, m, live) {
  if (m.kind === "council") paintCouncil(d, m, live);
  const box = $(".md.answer", d);
  if (m.error) box.innerHTML = `<div class="err-card">${esc(m.error)}</div>`;
  else { renderMD(m.content, box); if (live && (m.content || m.kind !== "council")) box.insertAdjacentHTML("beforeend", '<span class="cursor"></span>'); }
  const tools = $(".msg-tools", d); tools.hidden = live || !m.content;
  if (!live && m.ms) $(".stats", d).textContent = secs(m.ms);
}
function imageNode(m, idx) {
  const d = document.createElement("div"); d.className = "msg ai"; d.dataset.idx = idx;
  d.innerHTML = `<div class="avatar">${LOGO}</div><div class="ai-body">
    <div class="ai-meta"><b>خارق 4</b><span>رسم</span></div><div class="img-slot"></div></div>`;
  paintImage(d, m);
  return d;
}
function paintImage(d, m) {
  const slot = $(".img-slot", d);
  const [w, h] = (m.aspect || "1:1").split(":").map(Number);
  if (m.error) { slot.innerHTML = `<div class="err-card">${esc(m.error)}</div>`; return; }
  if (!m.image) { slot.innerHTML = `<div class="gen-img"><div class="ph" style="--ar:${w}/${h}"><span class="spin"></span>يرسم خارق صورتك… قد يستغرق ذلك حتى دقيقة</div></div>`; return; }
  slot.innerHTML = `<div class="gen-img"><img src="${m.image}" alt="${esc(m.prompt)}" data-zoom></div>
    <div class="img-actions">
      <button data-img="save"><svg viewBox="0 0 24 24"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>تنزيل</button>
      <button data-img="edit"><svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16z"/></svg>عدّل عليها</button>
      <button data-img="again"><svg viewBox="0 0 24 24"><path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/></svg>نسخة أخرى</button>
      <span class="stats">${m.ms ? secs(m.ms) : ""}</span>
    </div>
    ${m.promptUsed ? `<details><summary class="prompt-used" style="cursor:pointer;text-align:right;direction:rtl">الوصف المحسّن الذي استُخدم</summary><div class="prompt-used">${esc(m.promptUsed)}</div></details>` : ""}`;
}
function scrollEnd(force) { const st = $("#stage"); if (force || st.scrollHeight - st.scrollTop - st.clientHeight < 180) st.scrollTop = st.scrollHeight; }
const nodeFor = (idx) => $(`#thread .msg[data-idx="${idx}"]`);

/* ---------------- الإرسال ---------------- */
function userContent(m) {
  if (!m.files?.length) return m.content;
  return m.files.map((f) => `### ملف مرفق: ${f.name}\n\`\`\`\n${f.text}\n\`\`\``).join("\n\n") + "\n\n" + m.content;
}
function payloadMessages(c) {
  const out = [];
  c.messages.forEach((m, i) => {
    if (m.role === "user") out.push({ role: "user", content: userContent(m), images: i === c.messages.length - 1 ? m.images || [] : [] });
    else if (m.kind === "image" && m.image) out.push({ role: "assistant", content: `[رسمتُ صورة بناءً على: ${m.prompt}]` });
    else if (m.content && !m.error) out.push({ role: "assistant", content: m.content });
  });
  // آخر رسالة يجب أن تكون للمستخدم
  while (out.length && out[out.length - 1].role !== "user") out.pop();
  return out;
}
async function send(text) {
  if (S.generating) { stopGen(); return; }
  text = (text ?? $("#input").value).trim();
  if (!text && !S.files.length) return;
  let c = cur(); if (!c) { newChat(true); c = cur(); }
  if (!c.messages.length) c.persona = S.persona;
  const drawCmd = /^\/?ارسم\s*[:：]?\s*/.test(text);
  const isDraw = S.draw || drawCmd;
  const imgs = S.files.filter((f) => f.img).map((f) => f.img);
  const txtFiles = S.files.filter((f) => f.text != null).map(({ name, text }) => ({ name, text }));
  const content = text || (imgs.length ? "حلّل هذه الصورة بالتفصيل." : "حلّل الملفات المرفقة ولخّص أهم ما فيها.");
  c.messages.push({ role: "user", content, images: imgs, files: txtFiles });
  if (c.title === "محادثة جديدة") c.title = content.slice(0, 48);
  $("#input").value = ""; autoGrow(); S.files = []; renderFiles();
  renderThread(); renderList();
  if (isDraw) await drawImage(c, drawCmd && !S.draw ? text.replace(/^\/?ارسم\s*[:：]?\s*/, "") || text : content, imgs[0]);
  else await ask(c);
}
function setBusy(b) {
  S.generating = b; $("#sendBtn").classList.toggle("stopping", b); $("#sendBtn").setAttribute("aria-label", b ? "إيقاف" : "إرسال");
}
async function ask(c) {
  const council = S.mode === "council";
  const a = { role: "assistant", kind: council ? "council" : "single", content: "", model: S.mode === "single" ? S.model : "gemini_3_flash",
    council: council ? { stage: "calling", seats: {}, used: [], review: "", open: null } : null };
  c.messages.push(a); const idx = c.messages.length - 1;
  const node = aiNode(a, idx); node.classList.add("streaming"); $("#thread").appendChild(node); $("#welcome").hidden = true; scrollEnd(true);
  setBusy(true);
  const ctrl = new AbortController(); S.abort = ctrl;
  const t0 = performance.now(); let raf = 0;
  const timer = setInterval(() => { a.ms = performance.now() - t0; const t = $(".timer", node); if (t) t.textContent = secs(a.ms); }, 100);
  const paint = () => { raf = 0; paintAI(node, a, true); scrollEnd(); };
  const queue = () => { if (!raf) raf = requestAnimationFrame(paint); };
  const p = PERSONAS.find((x) => x.key === c.persona);
  try {
    const res = await fetch(`${API}/api/chat`, {
      method: "POST", headers: { "Content-Type": "application/json" }, signal: ctrl.signal,
      body: JSON.stringify({ messages: payloadMessages(c), mode: S.mode === "council" ? "council" : "single", model: a.model, think: council && S.think, persona: p?.prompt || "", extra: S.settings.extra }),
    });
    if (!res.ok || !res.body) throw new Error((await res.json().catch(() => ({}))).error || "تعذّر الاتصال بالخادم (" + res.status + ")");
    const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = "";
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      buf += dec.decode(value, { stream: true });
      let k;
      while ((k = buf.indexOf("\n\n")) !== -1) {
        const line = buf.slice(0, k).trim(); buf = buf.slice(k + 2);
        if (!line.startsWith("data:")) continue;
        handleEvent(a, JSON.parse(line.slice(5)));
        queue();
      }
    }
    if (!a.content && !a.error) a.error = "لم تصل إجابة. حاول مرة أخرى.";
  } catch (err) {
    if (err.name === "AbortError") { if (!a.content) a.error = "أوقفتَ التوليد."; }
    else a.error = String(err.message || err);
  } finally {
    clearInterval(timer); if (raf) cancelAnimationFrame(raf);
    a.ms = performance.now() - t0; if (a.council) a.council.stage = "done";
    Object.values(a.council?.seats || {}).forEach((s) => { if (s.state === "live") s.state = "err"; });
    node.classList.remove("streaming"); paintAI(node, a, false);
    setBusy(false); S.abort = null; renderList();
    if (S.settings.autoSpeak && a.content) speak(a, node);
  }
}
function handleEvent(a, e) {
  const c = a.council;
  switch (e.type) {
    case "stage": if (c) c.stage = e.stage; if (e.used && c) c.used = e.used; if (e.model && !c) a.model = e.model.id; break;
    case "draft_start": c.seats[e.model] = { state: "live", text: "" }; break;
    case "draft_delta": c.seats[e.model].text += e.text; break;
    case "draft_done": Object.assign(c.seats[e.model], { state: "done", ms: e.ms }); break;
    case "draft_error": c.seats[e.model] = { ...(c.seats[e.model] || {}), state: "err", err: e.message }; break;
    case "review_delta": c.review += e.text; break;
    case "delta": a.content += e.text; break;
    case "fallback": a.content = e.text; c.fallback = true; break;
    case "error": a.error = e.message; break;
  }
}
function stopGen() { S.abort?.abort(); }

async function drawImage(c, prompt, refImg) {
  const m = { role: "assistant", kind: "image", prompt, aspect: S.aspect, image: null };
  c.messages.push(m); const idx = c.messages.length - 1;
  const node = imageNode(m, idx); $("#thread").appendChild(node); $("#welcome").hidden = true; scrollEnd(true);
  setBusy(true); const ctrl = new AbortController(); S.abort = ctrl; const t0 = performance.now();
  try {
    const res = await fetch(`${API}/api/image`, { method: "POST", headers: { "Content-Type": "application/json" }, signal: ctrl.signal,
      body: JSON.stringify({ prompt, aspect: m.aspect, image: refImg || null }) });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.image) throw new Error(data.error || "تعذّر توليد الصورة");
    m.image = data.image; m.promptUsed = data.prompt;
  } catch (err) { m.error = err.name === "AbortError" ? "أوقفتَ الرسم." : String(err.message || err); }
  finally { m.ms = performance.now() - t0; paintImage(node, m); setBusy(false); S.abort = null; renderList(); scrollEnd(); }
}

/* ---------------- الصوت ---------------- */
let rec = null;
function toggleMic() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { toast("متصفحك لا يدعم الكتابة بالصوت. جرّب Chrome أو Edge."); return; }
  if (rec) { rec.stop(); return; }
  rec = new SR(); rec.lang = "ar-IQ"; rec.interimResults = true;
  const base = $("#input").value;
  rec.onresult = (ev) => { $("#input").value = (base ? base + " " : "") + [...ev.results].map((r) => r[0].transcript).join(" "); autoGrow(); };
  rec.onerror = (ev) => toast(ev.error === "not-allowed" ? "لم يُسمح باستخدام الميكروفون" : "تعذّر التعرّف على الصوت");
  rec.onend = () => { rec = null; $("#micBtn").classList.remove("rec"); };
  $("#micBtn").classList.add("rec"); rec.start();
}
let player = null;
const plainText = (t) => t.replace(/```[\s\S]*?```/g, " ").replace(/[#*_>`|]/g, " ").replace(/\s+/g, " ").trim().slice(0, 2400);
async function speak(m, node) {
  const btn = node && $('[data-tool="speak"] span', node);
  if (player && !player.paused) { player.pause(); player = null; if (btn) btn.textContent = "استماع"; return; }
  try {
    if (!m.audio) {
      if (btn) btn.textContent = "يجهّز الصوت…";
      const res = await fetch(`${API}/api/tts`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text: plainText(m.content), voice: S.settings.voice }) });
      const data = await res.json(); if (!data.audio) throw new Error(data.error);
      m.audio = data.audio;
    }
    player = new Audio(m.audio); player.onended = () => { if (btn) btn.textContent = "استماع"; };
    await player.play(); if (btn) btn.textContent = "إيقاف";
  } catch {
    if (btn) btn.textContent = "استماع";
    if ("speechSynthesis" in window) { const u = new SpeechSynthesisUtterance(plainText(m.content)); u.lang = "ar-SA"; speechSynthesis.cancel(); speechSynthesis.speak(u); }
    else toast("تعذّر تشغيل الصوت");
  }
}

/* ---------------- تشغيل الكود ---------------- */
let runnerFrame = null;
function runCode(code, lang) {
  const r = $("#runner"); const body = $("#runnerBody"); r.hidden = false; body.innerHTML = "";
  const isHTML = ["html", "htm", "xml", "svg"].includes(lang) || (!lang && /<html|<!doctype/i.test(code));
  if (lang === "py" || lang === "python") { runPython(code, body); return; }
  $("#runnerTitle").textContent = isHTML ? "معاينة الصفحة" : "تشغيل جافاسكربت";
  $("#runnerHint").textContent = "يعمل في صندوق معزول داخل متصفحك";
  const iframe = document.createElement("iframe"); iframe.setAttribute("sandbox", "allow-scripts"); iframe.title = "نتيجة التشغيل";
  if (isHTML) { iframe.srcdoc = code; body.appendChild(iframe); return; }
  const out = document.createElement("pre"); out.className = "console"; out.innerHTML = '<span class="s">▶ جارٍ التشغيل…</span>\n';
  iframe.style.display = "none"; body.append(out, iframe);
  const safe = code.replace(/<\/script/gi, "<\\/script");
  iframe.srcdoc = `<script>
    const send=(t,a)=>parent.postMessage({__k:1,t,a:a.map(x=>{try{return typeof x==='string'?x:JSON.stringify(x,null,2)}catch{return String(x)}}).join(' ')},'*');
    ['log','info','warn','error'].forEach(k=>{console[k]=(...a)=>send(k,a)});
    onerror=(m,s,l)=>{send('error',[m+(l?' (سطر '+l+')':'')])};
    onunhandledrejection=e=>send('error',[String(e.reason)]);
    (async()=>{ ${safe}\n })().then(()=>send('done',[]),e=>send('error',[String(e)]));
  <\/script>`;
  runnerFrame = { iframe, out };
}
window.addEventListener("message", (ev) => {
  if (!runnerFrame || ev.source !== runnerFrame.iframe.contentWindow || !ev.data?.__k) return;
  const { t, a } = ev.data;
  runnerFrame.out.insertAdjacentHTML("beforeend", t === "done" ? '<span class="s">✓ انتهى التشغيل</span>\n' : `<span class="${t === "error" ? "e" : ""}">${esc(a)}</span>\n`);
});
let pyodide = null;
async function runPython(code, body) {
  $("#runnerTitle").textContent = "تشغيل بايثون"; $("#runnerHint").textContent = "Pyodide داخل متصفحك";
  const out = document.createElement("pre"); out.className = "console"; body.appendChild(out);
  const write = (s, cls = "") => out.insertAdjacentHTML("beforeend", `<span class="${cls}">${esc(s)}</span>\n`);
  try {
    if (!pyodide) {
      write("▶ تحميل بايثون لأول مرة…", "s");
      const { loadPyodide } = await import("https://cdn.jsdelivr.net/pyodide/v0.27.2/full/pyodide.mjs");
      pyodide = await loadPyodide({ indexURL: "https://cdn.jsdelivr.net/pyodide/v0.27.2/full/" });
    }
    pyodide.setStdout({ batched: (s) => write(s) }); pyodide.setStderr({ batched: (s) => write(s, "e") });
    write("▶ جارٍ التشغيل…", "s");
    await pyodide.loadPackagesFromImports(code);
    const res = await pyodide.runPythonAsync(code);
    if (res !== undefined && res !== null) write(String(res));
    write("✓ انتهى التشغيل", "s");
  } catch (e) { write(String(e.message || e), "e"); }
}

/* ---------------- النوافذ ---------------- */
function openModal(title, html) { $("#modalTitle").textContent = title; $("#modalBody").innerHTML = html; $("#modal").hidden = false; }
function closeModal() { $("#modal").hidden = true; }
function openCouncilInfo() {
  openModal("كيف يعمل مجلس خارق 4", `
    <p class="lede">بدلاً من الاعتماد على عقل واحد، يطرح خارق 4 سؤالك على أربعة من أقوى النماذج في العالم في اللحظة نفسها، ثم يصنع من إجاباتهم إجابة واحدة أفضل.</p>
    <div class="steps">
      <div class="step"><span class="num">١</span><div><b>المسودات بالتوازي</b><p>Claude وGPT وGemini وGrok يكتبون إجاباتهم معاً، ويمكنك فتح مسودة كل واحد منهم ومقارنتها.</p></div></div>
      <div class="step"><span class="num">٢</span><div><b>المراجعة النقدية (مع «تفكير عميق»)</b><p>مراجع مستقل يقارن المسودات ويكشف نقاط الاتفاق والخلاف والأخطاء المحتملة والنواقص.</p></div></div>
      <div class="step"><span class="num">٣</span><div><b>الدمج</b><p>«الدامج» يجمع النقاط الصحيحة، ويصحح الأخطاء، ويحسم الخلافات، ويحذف التكرار، ثم يكتب لك الإجابة النهائية مباشرة.</p></div></div>
    </div>
    <div class="roster">${COUNCIL_IDS.map((id) => `<div style="--c:${MEMBERS[id].color}"><i></i><b class="mono">${MEMBERS[id].full}</b><span>${MEMBERS[id].maker}</span></div>`).join("")}</div>
    <p class="lede" style="margin-top:16px">وضع «سريع» يجيب بنموذج Gemini 3 Flash فوراً، ووضع «نموذج واحد» يتيح لك اختيار عقل محدد.</p>`);
}
function openSettings() {
  const s = S.settings;
  const voices = [["charon", "شارون (رجالي عميق)"], ["kore", "كوري (نسائي واضح)"], ["fenrir", "فنرير (رجالي قوي)"], ["aoede", "أويدي (نسائي دافئ)"], ["puck", "باك (حيوي)"]];
  openModal("الإعدادات", `
    <div class="field"><label>تعليمات دائمة لخارق</label>
      <textarea data-set="extra" placeholder="مثال: نادِني بـ «أبو علي»، وأجب باللهجة العراقية، واختصر قدر الإمكان.">${esc(s.extra)}</textarea>
      <small>تُضاف إلى كل رسالة يرسلها المجلس.</small></div>
    <div class="field"><label>صوت القراءة</label>
      <div class="aspects" style="flex-wrap:wrap">${voices.map(([k, n]) => `<button type="button" data-voice="${k}" aria-checked="${s.voice === k}">${n}</button>`).join("")}</div></div>
    <div class="field"><label style="justify-content:flex-start;gap:10px"><input type="checkbox" data-set="autoSpeak" ${s.autoSpeak ? "checked" : ""}> قراءة الإجابات بصوت عالٍ تلقائياً</label></div>
    <div class="btn-row"><button class="btn primary" data-act="close-modal">تم</button></div>`);
}
function openExport() {
  const c = cur();
  openModal("تصدير واستيراد", `
    <p class="lede">المحادثات لا تُحفظ خارج هذه الجلسة. صدّرها لتحتفظ بها، واستوردها لاحقاً لتكمل من حيث توقفت.</p>
    <div class="btn-row">
      <button class="btn primary" data-act="dl-md" ${c?.messages.length ? "" : "disabled"}>تنزيل المحادثة (Markdown)</button>
      <button class="btn" data-act="dl-json" ${S.chats.some((x) => x.messages.length) ? "" : "disabled"}>تنزيل كل المحادثات (JSON)</button>
      <button class="btn" data-act="copy-md" ${c?.messages.length ? "" : "disabled"}>نسخ المحادثة</button>
      <label class="btn">استيراد JSON<input type="file" accept=".json,application/json" id="importFile" hidden></label>
    </div>`);
}
function openAbout() {
  openModal("عن خارق 4", `<div class="about">
    <p>«خارق 4» تطبيق ذكاء يجمع أقوى النماذج المتاحة اليوم في مجلس واحد: <b>Claude Opus 5.5</b> و<b>GPT-5.4</b> و<b>Gemini 3.1 Pro</b> و<b>Grok 4.3</b>. يفكرون معاً على سؤالك، ويراجع أحدهم إجابات البقية، ثم يدمج خارق أفضل ما لديهم في إجابة واحدة.</p>
    <h3>الصراحة أولاً</h3>
    <p>خارق 4 ليس نموذجاً مدرّباً من الصفر، وليس Qwen ولا تابعاً لشركة Alibaba. قوته تأتي من «حكمة الجماعة»: دمج عدة نماذج رائدة يقلل الأخطاء الفردية ويجمع نقاط قوة كل نموذج. هذا أسلوب معروف في أبحاث الذكاء الاصطناعي باسم Mixture-of-Agents.</p>
    <h3>ما يجعله مختلفاً</h3>
    <ul>
      <li>أربعة عقول بالتوازي مع إمكانية رؤية مسودة كل عقل.</li>
      <li>مراجعة نقدية تكشف الخلافات والأخطاء قبل الدمج.</li>
      <li>رسم الصور وتعديلها بوصف عربي، مع تحسين الوصف تلقائياً.</li>
      <li>قراءة الصور والمستندات والرسوم البيانية وتحليلها.</li>
      <li>تشغيل الكود الذي يكتبه: صفحات ويب وألعاب وجافاسكربت وبايثون.</li>
      <li>صوت طبيعي لقراءة الإجابات، وكتابة بالصوت.</li>
      <li>سبع شخصيات وتعليمات دائمة قابلة للتخصيص.</li>
    </ul>
    <h3>حدود</h3>
    <ul>
      <li>لا يبحث في الإنترنت مباشرة، فمعرفته محدودة بتاريخ تدريب النماذج.</li>
      <li>وضع المجلس أبطأ من نموذج واحد (عادة 10 إلى 30 ثانية) لأنه ينتظر أربعة عقول ثم يدمج.</li>
      <li>تُعالج الرسائل على خوادم مزودي النماذج.</li>
    </ul>
  </div>`);
}
function chatMD(c) {
  return `# ${c.title}\n\n` + c.messages.map((m) => m.role === "user" ? `**أنت:**\n\n${m.content}` : m.kind === "image" ? `**خارق 4 (رسم):** ${m.prompt}` : `**خارق 4:**\n\n${m.content || m.error || ""}`).join("\n\n---\n\n");
}
function download(name, text, type) {
  const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
function downloadDataURL(name, url) { const a = document.createElement("a"); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); }

/* ---------------- مساعدات ---------------- */
let toastT = 0;
function toast(t) { const el = $("#toast"); el.textContent = t; el.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove("show"), 2600); }
function autoGrow() { const t = $("#input"); t.style.height = "auto"; t.style.height = Math.min(t.scrollHeight, 220) + "px"; }
async function copy(t) { try { await navigator.clipboard.writeText(t); toast("تم النسخ"); } catch { toast("تعذّر النسخ في هذا المتصفح"); } }
function setDraw(on) {
  S.draw = on; $("#drawBtn").setAttribute("aria-pressed", String(on)); $("#imgBar").hidden = !on; $("#composer").classList.toggle("drawing", on);
  $("#input").placeholder = on ? "صف الصورة التي تريدها… (أرفق صورة لتعديلها)" : "اسأل مجلس خارق أي شيء…";
  renderEngineSwitch();
}

/* ---------------- الأحداث ---------------- */
document.addEventListener("click", async (ev) => {
  const z = ev.target.closest("[data-zoom]");
  if (z) { $("#lightImg").src = z.src; $("#lightbox").hidden = false; return; }
  const t = ev.target.closest("[data-act],[data-open],[data-del],[data-persona],[data-q],[data-unfile],[data-code],[data-tool],[data-mode],[data-seat],[data-aspect],[data-img],[data-voice]");
  if (!t) return;
  const d = t.dataset;
  if (d.open) { S.current = d.open; S.persona = cur().persona; renderList(); renderThread(); $("#app").classList.remove("side-open"); return; }
  if (d.del) { S.chats = S.chats.filter((c) => c.id !== d.del); if (S.current === d.del) { S.current = null; newChat(true); } renderList(); renderThread(); return; }
  if (d.persona) { S.persona = d.persona; const c = cur(); if (c && !c.messages.length) c.persona = S.persona; renderWelcome(); return; }
  if (d.q) { if (d.q.startsWith("أرفق")) { $("#fileInput").click(); return; } send(d.q); return; }
  if (d.unfile) { S.files = S.files.filter((f) => f.id !== d.unfile); renderFiles(); return; }
  if (d.mode) { S.mode = d.mode; if (S.draw) setDraw(false); renderEngineSwitch(); return; }
  if (d.aspect) { S.aspect = d.aspect; $$("[data-aspect]").forEach((b) => b.setAttribute("aria-checked", String(b.dataset.aspect === S.aspect))); return; }
  if (d.voice) { S.settings.voice = d.voice; $$("[data-voice]").forEach((b) => b.setAttribute("aria-checked", String(b.dataset.voice === d.voice))); S.chats.forEach((c) => c.messages.forEach((m) => delete m.audio)); return; }
  if (d.seat) {
    const node = t.closest(".msg"); const m = cur().messages[+node.dataset.idx];
    if (!m.council.seats[d.seat]) { toast("لم يبدأ هذا العضو بعد"); return; }
    m.council.open = m.council.open === d.seat ? null : d.seat; paintCouncil(node, m, S.generating && +node.dataset.idx === cur().messages.length - 1); return;
  }
  if (d.code) {
    const box = t.closest(".codebox"); const item = box.closest(".md")?._codes?.[+box.dataset.i]; if (!item) return;
    if (d.code === "copy") copy(item.text);
    if (d.code === "run") runCode(item.text, item.lang);
    if (d.code === "save") { const ext = { javascript: "js", python: "py", typescript: "ts", "": "txt" }[item.lang] ?? item.lang; download("khariq-code." + ext, item.text, "text/plain"); }
    return;
  }
  if (d.img) {
    const node = t.closest(".msg"); const c = cur(); const m = c.messages[+node.dataset.idx];
    if (d.img === "save") downloadDataURL("khariq-image.png", m.image);
    if (d.img === "edit") { S.files = [{ id: uid(), name: "صورة خارق", img: m.image }]; renderFiles(); setDraw(true); $("#input").focus(); toast("اكتب التعديل الذي تريده على الصورة"); }
    if (d.img === "again" && !S.generating) { S.aspect = m.aspect; drawImage(c, m.prompt, null); }
    return;
  }
  if (d.tool) {
    const node = t.closest(".msg"); const idx = +node.dataset.idx; const c = cur(); const m = c.messages[idx];
    if (d.tool === "copy") copy(m.content);
    if (d.tool === "speak") speak(m, node);
    if (d.tool === "regen" && !S.generating) { c.messages.splice(idx); renderThread(); ask(c); }
    return;
  }
  switch (d.act) {
    case "new": newChat(); $("#app").classList.remove("side-open"); break;
    case "home": ev.preventDefault(); newChat(); break;
    case "council-info": openCouncilInfo(); break;
    case "settings": openSettings(); break;
    case "about": openAbout(); break;
    case "export": openExport(); break;
    case "close-modal": closeModal(); break;
    case "close-runner": $("#runner").hidden = true; $("#runnerBody").innerHTML = ""; runnerFrame = null; break;
    case "close-lightbox": $("#lightbox").hidden = true; break;
    case "open-side": $("#app").classList.add("side-open"); break;
    case "close-side": $("#app").classList.remove("side-open"); break;
    case "theme": S.theme = S.theme === "dark" ? "light" : "dark"; document.body.dataset.theme = S.theme; break;
    case "toggle-think": S.think = !S.think; renderEngineSwitch(); toast(S.think ? "تفكير عميق: مسودات أعمق + مراجعة نقدية قبل الدمج" : "تفكير عميق متوقف: إجابات أسرع"); break;
    case "draw": setDraw(!S.draw); $("#input").focus(); break;
    case "mic": toggleMic(); break;
    case "dl-md": download("khariq4-chat.md", chatMD(cur()), "text/markdown"); break;
    case "dl-json": download("khariq4-chats.json", JSON.stringify(S.chats.filter((c) => c.messages.length).map((c) => ({ ...c, messages: c.messages.map(({ audio, image, ...m }) => m) })), null, 2), "application/json"); break;
    case "copy-md": copy(chatMD(cur())); break;
  }
});
document.addEventListener("change", async (ev) => {
  const el = ev.target;
  if (el.id === "singleSel") { if (el.value) { S.mode = "single"; S.model = el.value; if (S.draw) setDraw(false); } renderEngineSwitch(); return; }
  if (el.id === "fileInput") { await addFiles([...el.files]); el.value = ""; return; }
  if (el.dataset?.set === "autoSpeak") { S.settings.autoSpeak = el.checked; return; }
  if (el.id === "importFile") {
    try {
      const data = JSON.parse(await el.files[0].text());
      const arr = (Array.isArray(data) ? data : [data]).filter((c) => Array.isArray(c.messages));
      arr.forEach((c) => S.chats.push({ id: uid(), title: String(c.title || "محادثة مستوردة").slice(0, 60), created: Date.now(), persona: PERSONAS.some((p) => p.key === c.persona) ? c.persona : "all",
        messages: c.messages.filter((m) => m.role === "user" || (m.role === "assistant" && m.kind !== "image")).map((m) => ({ role: m.role, kind: m.role === "assistant" ? "single" : undefined, content: String(m.content || ""), images: [], files: [] })) }));
      closeModal(); renderList(); toast(`تم استيراد ${fmtN(arr.length)} محادثة`);
    } catch { toast("ملف غير صالح"); }
  }
});
document.addEventListener("input", (ev) => {
  const el = ev.target;
  if (el.dataset?.set === "extra") S.settings.extra = el.value;
  if (el.id === "input") autoGrow();
  if (el.id === "chatSearch") renderList();
});
$("#composer").addEventListener("submit", (ev) => { ev.preventDefault(); send(); });
$("#input").addEventListener("keydown", (ev) => { if (ev.key === "Enter" && !ev.shiftKey && !ev.isComposing) { ev.preventDefault(); send(); } });
$("#input").addEventListener("paste", (ev) => { const fs = [...(ev.clipboardData?.files || [])]; if (fs.length) { ev.preventDefault(); addFiles(fs); } });
document.addEventListener("keydown", (ev) => {
  if ((ev.ctrlKey || ev.metaKey) && ev.key.toLowerCase() === "k") { ev.preventDefault(); newChat(); }
  if (ev.key === "Escape") { closeModal(); $("#lightbox").hidden = true; if (!$("#runner").hidden) $("[data-act=close-runner]").click(); }
});
document.addEventListener("dragover", (e) => e.preventDefault());
document.addEventListener("drop", (e) => { e.preventDefault(); if (e.dataTransfer?.files?.length) addFiles([...e.dataTransfer.files]); });

/* ---------------- البدء ---------------- */
(async function init() {
  newChat(true); renderWelcome(); renderEngineSwitch();
  window.__k4 = S;
  try {
    const r = await fetch(`${API}/api/health`); const j = await r.json();
    S.online = !!j.ok && !!j.ai;
  } catch { S.online = false; }
  $("#statusPill").innerHTML = S.online
    ? `<span class="dot"></span> المجلس متصل · ${fmtN(4)} عقول جاهزة`
    : `<span class="dot" style="background:var(--bad)"></span> تعذّر الاتصال بالمجلس`;
})();
