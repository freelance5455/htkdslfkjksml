(function () {
  'use strict';

  var KEY = 'pcm-tracker-v1';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var esc = function (s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };

  /* ---------- Data model ---------- */
  var ALL = [];
  CLASSES.forEach(function (c) {
    c.subjects.forEach(function (s) {
      s.chapters.forEach(function (ch) {
        ALL.push({ id: ch.id, no: ch.no, name: ch.name, scope: ch.scope,
          cls: c.id, clsName: c.name, subj: s.id, subjName: s.name });
      });
    });
  });

  var state = load();
  var ui = { '11': { q: '', subj: 'all', status: 'all', collapsed: {} },
             '12': { q: '', subj: 'all', status: 'all', collapsed: {} } };
  var deferredPrompt = null;

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) {
        var d = JSON.parse(raw);
        return { progress: d.progress || {}, logs: d.logs || {} };
      }
    } catch (e) { /* corrupt data: start clean but do not overwrite until next save */ }
    return { progress: {}, logs: {} };
  }

  function persist() {
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
      return true;
    } catch (e) {
      toast('Could not save. Storage may be full or blocked.');
      return false;
    }
  }

  function doneCount(id) {
    var p = state.progress[id] || {};
    return TASKS.reduce(function (n, t) { return n + (p[t.k] ? 1 : 0); }, 0);
  }
  function pct(id) { return doneCount(id) * 20; }
  function avg(a) { return a.length ? a.reduce(function (x, y) { return x + y; }, 0) / a.length : 0; }
  function isComplete(id) { return doneCount(id) === TASKS.length; }

  function stats(list) {
    var total = list.length;
    var completed = list.filter(function (c) { return isComplete(c.id); }).length;
    return {
      overall: avg(list.map(function (c) { return pct(c.id); })),
      total: total,
      completed: completed,
      pending: total - completed,
      tasksDone: list.reduce(function (n, c) { return n + doneCount(c.id); }, 0),
      tasksTotal: total * TASKS.length
    };
  }
  function byClass(cls) { return ALL.filter(function (c) { return c.cls === cls; }); }
  function bySubject(subj, cls) {
    return ALL.filter(function (c) { return c.subj === subj && (!cls || c.cls === cls); });
  }

  /* ---------- Small UI helpers ---------- */
  function ring(p, size, stroke, label, sub) {
    var r = (size - stroke) / 2, c = 2 * Math.PI * r, off = c * (1 - Math.min(100, Math.max(0, p)) / 100);
    return '<div class="ring" style="width:' + size + 'px;height:' + size + 'px">' +
      '<svg viewBox="0 0 ' + size + ' ' + size + '" aria-hidden="true">' +
      '<circle class="track" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke-width="' + stroke + '"/>' +
      '<circle class="val" cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke-width="' + stroke + '"' +
      ' stroke-dasharray="' + c.toFixed(2) + '" stroke-dashoffset="' + off.toFixed(2) + '"/></svg>' +
      '<div class="label"><span style="font-size:' + Math.round(size * 0.24) + 'px">' + Math.round(p) + '%</span>' +
      (sub ? '<small>' + esc(sub) + '</small>' : '') + '</div></div>';
  }
  function bar(p, label, right) {
    return '<div class="row"><span>' + esc(label) + '</span><b>' + right + '</b></div>' +
      '<div class="bar"><span style="width:' + p.toFixed(1) + '%"></span></div>';
  }
  var toastTimer;
  function toast(msg) {
    var el = $('#toast');
    el.textContent = msg;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove('show'); }, 2400);
  }

  /* ---------- Views ---------- */
  function viewHome() {
    var s = stats(ALL);
    var c11 = stats(byClass('11')), c12 = stats(byClass('12'));
    var subjects = [['phy', 'Physics'], ['chem', 'Chemistry'], ['math', 'Mathematics']];
    return '' +
      '<div class="page-head"><div><h1>Dashboard</h1><p class="muted">Your complete syllabus at a glance</p></div></div>' +
      '<section class="glass hero">' + ring(s.overall, 124, 12, 'Overall', 'Syllabus') +
      '<div class="meta"><div class="row"><span>Completed chapters</span><b>' + s.completed + '</b></div>' +
      '<div class="row"><span>Pending chapters</span><b>' + s.pending + '</b></div>' +
      '<div class="row"><span>Total chapters</span><b>' + s.total + '</b></div>' +
      '<div class="row"><span>Tasks completed</span><b>' + s.tasksDone + ' / ' + s.tasksTotal + '</b></div></div></section>' +
      '<section class="section grid3">' +
        '<div class="stat"><span>Chapters</span><b>' + s.total + '</b></div>' +
        '<div class="stat"><span>Completed</span><b style="color:#34D399">' + s.completed + '</b></div>' +
        '<div class="stat"><span>Pending</span><b style="color:#F59E0B">' + s.pending + '</b></div>' +
      '</section>' +
      '<section class="section glass"><h2>Class progress</h2><div class="stack">' +
        bar(c11.overall, 'Class 11', Math.round(c11.overall) + '%  ·  ' + c11.completed + '/' + c11.total) +
        bar(c12.overall, 'Class 12', Math.round(c12.overall) + '%  ·  ' + c12.completed + '/' + c12.total) +
      '</div></section>' +
      '<section class="section grid3">' + subjects.map(function (sj) {
        var list = bySubject(sj[0]);
        var st = stats(list);
        return '<div class="glass" style="padding:12px;text-align:center">' + ring(st.overall, 84, 8, '', '') +
          '<div style="font-size:13px;margin-top:8px;font-weight:600">' + sj[1] + '</div>' +
          '<div class="muted" style="font-size:11px">' + st.completed + '/' + st.total + ' chapters</div></div>';
      }).join('') + '</section>' +
      '<section class="section glass"><h2>Subject progress (both classes)</h2><div class="stack">' +
        subjects.map(function (sj) {
          var st = stats(bySubject(sj[0]));
          return bar(st.overall, sj[1], Math.round(st.overall) + '%');
        }).join('') + '</div></section>';
  }

  function viewClassShell(cls) {
    var u = ui[cls];
    var subjOpts = '<option value="all">All subjects</option>' + CLASSES.find(function (c) { return c.id === cls; })
      .subjects.map(function (s) { return '<option value="' + s.id + '"' + (u.subj === s.id ? ' selected' : '') + '>' + s.name + '</option>'; }).join('');
    return '' +
      '<div class="page-head"><div><h1>Class ' + cls + '</h1><p class="muted">Physics · Chemistry · Mathematics</p></div></div>' +
      '<section class="glass" id="clsSummary"></section>' +
      '<div class="toolbar">' +
        '<input type="search" id="q" placeholder="Search chapters" value="' + esc(u.q) + '" aria-label="Search chapters">' +
        '<div class="row2" style="grid-column:auto">' +
          '<select id="fSubj" aria-label="Filter by subject">' + subjOpts + '</select>' +
          '<select id="fStatus" aria-label="Filter by status">' +
            '<option value="all"' + (u.status === 'all' ? ' selected' : '') + '>All chapters</option>' +
            '<option value="done"' + (u.status === 'done' ? ' selected' : '') + '>Completed</option>' +
            '<option value="pending"' + (u.status === 'pending' ? ' selected' : '') + '>Pending</option>' +
          '</select></div></div>' +
      '<div id="subjects"></div>';
  }

  function renderClassSummary(cls) {
    var el = $('#clsSummary');
    if (!el) return;
    var st = stats(byClass(cls));
    el.innerHTML = '<div class="hero">' + ring(st.overall, 104, 11, 'Class ' + cls, 'Progress') +
      '<div class="meta"><div class="row"><span>Completed chapters</span><b>' + st.completed + ' / ' + st.total + '</b></div>' +
      '<div class="row"><span>Pending chapters</span><b>' + st.pending + '</b></div>' +
      '<div class="row"><span>Tasks completed</span><b>' + st.tasksDone + ' / ' + st.tasksTotal + '</b></div>' +
      '<p class="notice" style="margin-top:10px">Each checkbox is 20% of a chapter. A chapter is complete only when all five are ticked.</p></div></div>';
  }

  function chapterCard(c) {
    var p = state.progress[c.id] || {};
    var d = doneCount(c.id);
    var tasks = TASKS.map(function (t) {
      return '<label class="task"><input type="checkbox" data-ch="' + c.id + '" data-t="' + t.k + '"' + (p[t.k] ? ' checked' : '') + '>' +
        '<span class="box" aria-hidden="true"></span><span class="tlabel">' + t.label + '</span></label>';
    }).join('');
    return '<article class="chapter' + (d === TASKS.length ? ' complete' : '') + '">' +
      '<div class="ch-head"><div style="min-width:0"><div class="ch-no">Chapter ' + c.no + '</div><h3>' + esc(c.name) + '</h3>' +
      '<span class="tag ' + (c.scope === 'both' ? 'both' : '') + '">' + (c.scope === 'both' ? 'CBSE + JEE' : 'CBSE only') + '</span></div>' +
      '<div class="ch-pct">' + pct(c.id) + '%</div></div>' +
      '<div class="bar" style="margin-top:12px"><span style="width:' + pct(c.id) + '%"></span></div>' +
      '<div class="ch-meta"><span>' + d + ' / ' + TASKS.length + ' tasks done</span><span>' + (d === TASKS.length ? 'Completed ✓' : 'In progress') + '</span></div>' +
      '<div class="tasks">' + tasks + '</div>' +
      '<div class="ch-foot"><button class="btn small" data-action="clearCh" data-ch="' + c.id + '">Clear all</button>' +
      '<button class="btn small primary" data-action="markAll" data-ch="' + c.id + '">Mark all complete</button></div></article>';
  }

  function renderSubjects(cls) {
    var el = $('#subjects');
    if (!el) return;
    var u = ui[cls];
    var q = u.q.trim().toLowerCase();
    var cl = CLASSES.find(function (c) { return c.id === cls; });
    var html = '';
    var shown = 0;
    cl.subjects.forEach(function (s) {
      if (u.subj !== 'all' && u.subj !== s.id) return;
      var list = s.chapters.map(function (ch) {
        return ALL.find(function (a) { return a.id === ch.id; });
      }).filter(function (c) {
        if (q && c.name.toLowerCase().indexOf(q) === -1 && String(c.no) !== q) return false;
        if (u.status === 'done' && !isComplete(c.id)) return false;
        if (u.status === 'pending' && isComplete(c.id)) return false;
        return true;
      });
      if (!list.length) return;
      shown += list.length;
      var st = stats(bySubject(s.id, cls));
      var isCol = !!u.collapsed[s.id];
      html += '<section class="glass subject' + (isCol ? ' collapsed' : '') + '">' +
        '<button class="subject-head" data-action="toggleSub" data-subj="' + s.id + '" aria-expanded="' + !isCol + '">' +
          '<div class="info">' + bar(st.overall, s.name, st.completed + '/' + st.total + ' done · ' + Math.round(st.overall) + '%') + '</div>' +
          '<span class="chev" aria-hidden="true">▾</span></button>' +
        '<div class="list">' + list.map(chapterCard).join('') + '</div></section>';
    });
    el.innerHTML = html || '<div class="empty">No chapters match your search or filters.</div>';
  }

  function viewLog() {
    var today = new Date();
    var iso = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
    var dates = Object.keys(state.logs).sort().reverse();
    var totalAll = dates.reduce(function (n, d) { return n + (state.logs[d].total || 0); }, 0);
    var hist = dates.length ? dates.map(function (d) {
      var r = state.logs[d];
      return '<div class="hist-item"><div><b>' + d + '</b><small>Physics ' + r.phy + 'h · Chemistry ' + r.chem + 'h · Maths ' + r.math + 'h</small></div>' +
        '<div style="display:flex;align-items:center;gap:8px"><b>' + r.total.toFixed(2).replace(/\.?0+$/, '') + 'h</b>' +
        '<button class="btn small danger" data-action="delLog" data-date="' + d + '" aria-label="Delete entry for ' + d + '">Delete</button></div></div>';
    }).join('') : '<div class="empty">No study records yet. Add today\'s hours above.</div>';
    return '' +
      '<div class="page-head"><div><h1>Study Log</h1><p class="muted">Record daily study hours</p></div></div>' +
      '<section class="glass"><form class="form" id="logForm" autocomplete="off">' +
        '<label class="field">Date<input type="date" id="lDate" value="' + iso + '" required></label>' +
        '<div class="grid3">' +
          '<label class="field">Physics (h)<input type="number" min="0" max="24" step="0.25" inputmode="decimal" id="lPhy" value="0"></label>' +
          '<label class="field">Chemistry (h)<input type="number" min="0" max="24" step="0.25" inputmode="decimal" id="lChem" value="0"></label>' +
          '<label class="field">Maths (h)<input type="number" min="0" max="24" step="0.25" inputmode="decimal" id="lMath" value="0"></label>' +
        '</div>' +
        '<div class="row" style="margin:4px 0 0"><span class="muted">Total for the day</span><b id="lTot">0h</b></div>' +
        '<button class="btn primary" type="submit">Save record for this date</button>' +
      '</form></section>' +
      '<section class="section grid2">' +
        '<div class="stat"><span>Days logged</span><b>' + dates.length + '</b></div>' +
        '<div class="stat"><span>Total hours logged</span><b>' + totalAll.toFixed(2).replace(/\.?0+$/, '') + 'h</b></div>' +
      '</section>' +
      '<section class="section"><h2>History</h2><div class="hist">' + hist + '</div></section>';
  }

  function viewSettings() {
    var standalone = isStandalone();
    var offlineReady = !!(navigator.serviceWorker && navigator.serviceWorker.controller);
    var installBtn = (!standalone && deferredPrompt)
      ? '<button class="btn primary" data-action="install" style="width:100%">Install PCM TRACKER</button>'
      : '';
    return '' +
      '<div class="page-head"><div><h1>Settings</h1><p class="muted">Backup, install and status</p></div></div>' +
      '<section class="glass"><h2>App status</h2>' +
        '<div class="kv"><span>Installed as app</span><span>' + (standalone ? 'Yes' : 'No, running in browser') + '</span></div>' +
        '<div class="kv"><span>Offline ready</span><span>' + (offlineReady ? 'Yes' : 'Not yet. Keep the app open once while online.') + '</span></div>' +
        '<div class="kv"><span>Network</span><span>' + (navigator.onLine ? 'Online' : 'Offline. Everything still works.') + '</span></div>' +
        '<div class="kv"><span>Data storage</span><span>Saved on this device</span></div>' +
      '</section>' +
      '<section class="section glass"><h2>Install on Android</h2>' +
        (standalone ? '<p class="muted">PCM TRACKER is already installed and running as an app.</p>' : '') +
        installBtn + (installBtn ? '<div style="height:12px"></div>' : '') +
        '<ol class="guide">' +
          '<li><b>Chrome:</b> tap the ⋮ menu (top right), then tap <b>Install app</b> or <b>Add to Home screen</b>.</li>' +
          '<li><b>Brave:</b> tap the ⋮ menu, then tap <b>Install PCM TRACKER</b> or <b>Add to Home screen</b>.</li>' +
          '<li>Open PCM TRACKER from your home screen. It runs full screen with no browser bars and works offline.</li>' +
        '</ol>' +
        '<p class="notice">Installation is offered only by your browser. If no install option appears, the app is already installed or the browser does not support it.</p>' +
      '</section>' +
      '<section class="section glass"><h2>Backup and restore</h2>' +
        '<p class="muted" style="margin-bottom:12px">Export a JSON file to keep a copy of your progress and study log. Import it on any device to restore.</p>' +
        '<div class="grid2">' +
          '<button class="btn primary" data-action="export">Export backup</button>' +
          '<label class="btn" style="text-align:center;cursor:pointer">Import backup<input type="file" id="importFile" accept="application/json,.json" hidden></label>' +
        '</div>' +
        '<div style="height:12px"></div>' +
        '<button class="btn danger" data-action="reset" style="width:100%">Reset all progress</button>' +
        '<p class="notice">Importing replaces current data. Export first if you want to keep it. Reset asks for confirmation before deleting anything.</p>' +
      '</section>';
  }

  /* ---------- Router & rendering ---------- */
  var ROUTES = ['home', 'c11', 'c12', 'log', 'settings'];
  function currentRoute() {
    var h = (location.hash || '#home').replace('#', '');
    return ROUTES.indexOf(h) === -1 ? 'home' : h;
  }

  function render() {
    var r = currentRoute();
    var app = $('#app');
    document.querySelectorAll('#tabbar a').forEach(function (a) {
      a.classList.toggle('active', a.getAttribute('data-tab') === r);
    });
    if (r === 'home') app.innerHTML = viewHome();
    else if (r === 'c11' || r === 'c12') {
      var cls = r === 'c11' ? '11' : '12';
      app.innerHTML = viewClassShell(cls);
      renderClassSummary(cls);
      renderSubjects(cls);
    }
    else if (r === 'log') app.innerHTML = viewLog();
    else app.innerHTML = viewSettings();
    window.scrollTo(0, 0);
  }

  // Lightweight refresh after a data change, keeping the current view and input focus.
  function refresh() {
    var r = currentRoute();
    if (r === 'home') { $('#app').innerHTML = viewHome(); }
    else if (r === 'c11' || r === 'c12') {
      var cls = r === 'c11' ? '11' : '12';
      renderClassSummary(cls);
      renderSubjects(cls);
    }
  }

  function currentClass() {
    var r = currentRoute();
    return r === 'c11' ? '11' : r === 'c12' ? '12' : null;
  }

  /* ---------- Events ---------- */
  document.addEventListener('change', function (e) {
    var t = e.target;
    if (t.matches('input[type=checkbox][data-ch]')) {
      var id = t.getAttribute('data-ch'), k = t.getAttribute('data-t');
      if (!state.progress[id]) state.progress[id] = {};
      state.progress[id][k] = t.checked;
      if (persist()) refresh();
      return;
    }
    if (t.id === 'fSubj' || t.id === 'fStatus') {
      var cls = currentClass(); if (!cls) return;
      if (t.id === 'fSubj') ui[cls].subj = t.value; else ui[cls].status = t.value;
      renderSubjects(cls);
      return;
    }
    if (t.id === 'importFile') { importFile(t.files && t.files[0]); t.value = ''; }
  });

  document.addEventListener('input', function (e) {
    var t = e.target;
    if (t.id === 'q') {
      var cls = currentClass(); if (!cls) return;
      ui[cls].q = t.value;
      renderSubjects(cls);
      return;
    }
    if (t.id === 'lPhy' || t.id === 'lChem' || t.id === 'lMath') {
      var sum = ['lPhy', 'lChem', 'lMath'].reduce(function (n, id) { return n + (parseFloat($('#' + id).value) || 0); }, 0);
      $('#lTot').textContent = sum.toFixed(2).replace(/\.?0+$/, '') + 'h';
    }
  });

  document.addEventListener('submit', function (e) {
    if (e.target.id !== 'logForm') return;
    e.preventDefault();
    var date = $('#lDate').value;
    if (!date) { toast('Please choose a date'); return; }
    var phy = Math.max(0, parseFloat($('#lPhy').value) || 0);
    var chem = Math.max(0, parseFloat($('#lChem').value) || 0);
    var math = Math.max(0, parseFloat($('#lMath').value) || 0);
    state.logs[date] = { phy: phy, chem: chem, math: math, total: +(phy + chem + math).toFixed(2) };
    if (persist()) { toast('Saved study record for ' + date); render(); }
  });

  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-action]');
    if (!btn) return;
    var act = btn.getAttribute('data-action');

    if (act === 'toggleSub') {
      var cls = currentClass(); if (!cls) return;
      var sid = btn.getAttribute('data-subj');
      ui[cls].collapsed[sid] = !ui[cls].collapsed[sid];
      renderSubjects(cls);
    }
    else if (act === 'markAll' || act === 'clearCh') {
      var id = btn.getAttribute('data-ch');
      var val = act === 'markAll';
      state.progress[id] = {};
      TASKS.forEach(function (t) { state.progress[id][t.k] = val; });
      if (persist()) { refresh(); toast(val ? 'Chapter marked complete' : 'Chapter cleared'); }
    }
    else if (act === 'delLog') {
      var d = btn.getAttribute('data-date');
      delete state.logs[d];
      if (persist()) { render(); toast('Record deleted'); }
    }
    else if (act === 'export') exportBackup();
    else if (act === 'reset') resetAll();
    else if (act === 'install') installApp();
  });

  /* ---------- Backup / restore ---------- */
  function exportBackup() {
    var payload = {
      app: 'PCM TRACKER', format: 1, exportedAt: new Date().toISOString(),
      progress: state.progress, logs: state.logs
    };
    var blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    var stamp = new Date().toISOString().slice(0, 10);
    a.href = url; a.download = 'pcm-tracker-backup-' + stamp + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    toast('Backup file downloaded');
  }

  function importFile(file) {
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var d = JSON.parse(reader.result);
        if (!d || d.app !== 'PCM TRACKER' || typeof d.progress !== 'object' || typeof d.logs !== 'object') {
          throw new Error('invalid');
        }
        if (!confirm('Replace current progress with this backup?')) return;
        state = { progress: d.progress || {}, logs: d.logs || {} };
        if (persist()) { render(); toast('Backup restored'); }
      } catch (err) {
        toast('That file is not a valid PCM TRACKER backup');
      }
    };
    reader.readAsText(file);
  }

  function resetAll() {
    if (!confirm('Reset ALL progress and study logs? This cannot be undone.')) return;
    if (!confirm('Are you sure? Export a backup first if you might need this data.')) return;
    state = { progress: {}, logs: {} };
    if (persist()) { render(); toast('All progress has been reset'); }
  }

  /* ---------- Install ---------- */
  function isStandalone() {
    return (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  }
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferredPrompt = e;
    if (currentRoute() === 'settings') render();
  });
  window.addEventListener('appinstalled', function () {
    deferredPrompt = null;
    toast('PCM TRACKER installed');
    if (currentRoute() === 'settings') render();
  });
  function installApp() {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    deferredPrompt.userChoice.finally(function () { deferredPrompt = null; render(); });
  }

  /* ---------- Connectivity ---------- */
  function updateNet() {
    var el = $('#netState');
    if (navigator.onLine) { el.textContent = 'Offline ready'; el.classList.remove('off'); }
    else { el.textContent = 'Offline mode'; el.classList.add('off'); }
  }
  window.addEventListener('online', updateNet);
  window.addEventListener('offline', updateNet);

  /* ---------- Service worker ---------- */
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('sw.js').catch(function (err) {
        console.warn('Service worker registration failed', err);
      });
    });
  }

  window.addEventListener('hashchange', render);
  updateNet();
  render();
})();
