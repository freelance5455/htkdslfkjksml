
// ================= البيانات =================
const LS_P='b_players', LS_T='b_tournaments';
var players=[], tournaments=[];
function save(){localStorage.setItem(LS_P,JSON.stringify(players));localStorage.setItem(LS_T,JSON.stringify(tournaments));}
function load(){players=JSON.parse(localStorage.getItem(LS_P)||'[]');tournaments=JSON.parse(localStorage.getItem(LS_T)||'[]');players.forEach(p=>{if(!p.stars)p.stars=3;});seedDefaultTeams();ensureDefaultTeams();}
function ensureDefaultTeams(){const names=new Set(players.map(p=>p.name));DEFAULT_TEAMS.forEach(([n,s])=>{if(!names.has(n))players.push(mkPlayer(n,s));});save();}
const byId=id=>players.find(p=>p.id===id);
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
function mkPlayer(name,stars=3){return{id:uid(),name,rating:1000,stars:Math.max(1,Math.min(5,Number(stars)||3)),played:0,wins:0,draws:0,losses:0,gf:0,ga:0,titles:0,lastDelta:0};}
const CONTINENTS={
  africa:[
    ['🇲🇦 المغرب',5],['🇩🇿 الجزائر',4],['🇪🇬 مصر',4],['🇹🇳 تونس',4],['🇸🇳 السنغال',5],['🇬🇭 غانا',3],['🇨🇮 كوت ديفوار',4],['🇨🇩 الكونغو الديمقراطية',3],['🇿🇦 جنوب أفريقيا',3],['🇨🇻 الرأس الأخضر',3],['🇳🇬 نيجيريا',4],['🇨🇲 الكاميرون',4],['🇲🇱 مالي',4],['🇧🇫 بوركينا فاسو',3],['🇬🇳 غينيا',3],['🇿🇲 زامبيا',3],['🇺🇬 أوغندا',2],['🇦🇴 أنغولا',3],['🇧🇯 بنين',2],['🇲🇿 موزمبيق',2],['🇹🇿 تنزانيا',2],['🇿🇼 زيمبابوي',2],['🇰🇪 كينيا',2],['🇬🇦 الغابون',3],['🇨🇬 الكونغو',2],['🇳🇦 ناميبيا',2],['🇲🇬 مدغشقر',2],['🇲🇷 موريتانيا',2],['🇱🇾 ليبيا',2],['🇸🇩 السودان',2],['🇬🇼 غينيا بيساو',2],['🇬🇶 غينيا الاستوائية',2]
  ],
  europe:[
    ['🇫🇷 فرنسا',5],['🇪🇸 إسبانيا',5],['🏴 إنجلترا',5],['🇩🇪 ألمانيا',5],['🇵🇹 البرتغال',5],['🇳🇱 هولندا',4],['🇧🇪 بلجيكا',4],['🇭🇷 كرواتيا',4],['🇦🇹 النمسا',3],['🇨🇭 سويسرا',4],['🇸🇪 السويد',3],['🇳🇴 النرويج',4],['🇹🇷 تركيا',3],['🇨🇿 التشيك',3],['🇧🇦 البوسنة والهرسك',3],['🏴 اسكتلندا',3],['🇮🇹 إيطاليا',4],['🇩🇰 الدنمارك',4],['🇬🇷 اليونان',3],['🇷🇸 صربيا',3],['🇺🇦 أوكرانيا',3],['🇷🇴 رومانيا',3],['🇵🇱 بولندا',3],['🇭🇺 المجر',3],['🇸🇰 سلوفاكيا',3],['🇸🇮 سلوفينيا',3],['🇷🇺 روسيا',3],['🇮🇪 أيرلندا',2],['🇮🇸 آيسلندا',2],['🇫🇮 فنلندا',2],['🇬🇪 جورجيا',3],['🇦🇱 ألبانيا',2]
  ],
  asia:[
    ['🇯🇵 اليابان',4],['🇰🇷 كوريا الجنوبية',4],['🇮🇷 إيران',4],['🇸🇦 السعودية',3],['🇶🇦 قطر',3],['🇦🇺 أستراليا',4],['🇯🇴 الأردن',3],['🇺🇿 أوزبكستان',3],['🇮🇶 العراق',3],['🇦🇪 الإمارات',3],['🇴🇲 عُمان',2],['🇧🇭 البحرين',2],['🇨🇳 الصين',2],['🇸🇾 سوريا',2],['🇵🇸 فلسطين',2],['🇱🇧 لبنان',2],['🇻🇳 فيتنام',2],['🇹🇭 تايلاند',2],['🇮🇩 إندونيسيا',2],['🇰🇵 كوريا الشمالية',2],['🇰🇼 الكويت',2],['🇮🇳 الهند',2],['🇹🇯 طاجيكستان',2],['🇰🇬 قيرغيزستان',2],['🇹🇲 تركمانستان',2],['🇾🇪 اليمن',1],['🇵🇭 الفلبين',2],['🇲🇾 ماليزيا',2],['🇸🇬 سنغافورة',1],['🇳🇵 نيبال',1],['🇲🇻 المالديف',1],['🇭🇰 هونغ كونغ',1]
  ],
  americas:[
    ['🇦🇷 الأرجنتين',5],['🇧🇷 البرازيل',5],['🇨🇴 كولومبيا',4],['🇪🇨 الإكوادور',3],['🇵🇾 باراغواي',3],['🇺🇾 أوروغواي',4],['🇨🇦 كندا',3],['🇲🇽 المكسيك',4],['🇺🇸 الولايات المتحدة',4],['🇵🇦 بنما',3],['🇭🇹 هايتي',2],['🇨🇼 كوراساو',2],['🇨🇱 تشيلي',3],['🇵🇪 بيرو',3],['🇧🇴 بوليفيا',2],['🇻🇪 فنزويلا',3],['🇨🇷 كوستاريكا',3],['🇯🇲 جامايكا',2],['🇭🇳 هندوراس',2],['🇸🇻 السلفادور',2],['🇬🇹 غواتيمالا',2],['🇳🇮 نيكاراغوا',1],['🇹🇹 ترينيداد وتوباغو',2],['🇨🇺 كوبا',1],['🇩🇴 جمهورية الدومينيكان',1],['🇸🇷 سورينام',2],['🇬🇾 غيانا',1],['🇬🇩 غرينادا',1],['🇧🇧 بربادوس',1],['🇦🇬 أنتيغوا وبربودا',1],['🇰🇳 سانت كيتس ونيفيس',1],['🇧🇸 الباهاما',1]
  ],
  oceania:[
    ['🇳🇿 نيوزيلندا',2],['🇫🇯 فيجي',2],['🇸🇧 جزر سليمان',2],['🇳🇨 كاليدونيا الجديدة',2],['🇵🇫 تاهيتي',2],['🇻🇺 فانواتو',1],['🇵🇬 بابوا غينيا الجديدة',1],['🇼🇸 ساموا',1],['🇦🇸 ساموا الأمريكية',1],['🇹🇴 تونغا',1],['🇨🇰 جزر كوك',1]
  ]
};
const QUALIFIERS={africa:'🌍 تصفيات أفريقيا',europe:'🇪🇺 تصفيات أوروبا',asia:'🌏 تصفيات آسيا',americas:'🌎 تصفيات الأمريكتين',oceania:'🌊 تصفيات أوقيانوسيا'};

const DEFAULT_TEAMS=[...CONTINENTS.africa,...CONTINENTS.europe,...CONTINENTS.americas,...CONTINENTS.asia,...CONTINENTS.oceania];
function seedDefaultTeams(){if(players.length)return;players=DEFAULT_TEAMS.map(([n,s])=>mkPlayer(n,s));save();}

// ================= محرك التصنيف العالمي (FIFA) =================
const expected=(rA,rB)=>1/(1+Math.pow(10,(rB-rA)/600));
function applyMatch(h,a,m){
  const weH=expected(h.rating,a.rating), weA=1-weH;
  let wH,wA;
  if(m.homeScore>m.awayScore){wH=1;wA=0;}
  else if(m.awayScore>m.homeScore){wH=0;wA=1;}
  else if(m.hasPens){if(m.penHome>m.penAway){wH=.75;wA=.5;}else{wH=.5;wA=.75;}}
  else{wH=.5;wA=.5;}
  m.dH=m.importance*(wH-weH); m.dA=m.importance*(wA-weA);
  h.rating+=m.dH; a.rating+=m.dA; h.lastDelta=m.dH; a.lastDelta=m.dA;
  h.played++;a.played++;h.gf+=m.homeScore;h.ga+=m.awayScore;a.gf+=m.awayScore;a.ga+=m.homeScore;
  if(wH===1){h.wins++;a.losses++;}else if(wA===1){a.wins++;h.losses++;}else{h.draws++;a.draws++;}
}
const impForRound=n=>n>=16?25:n===8?35:n===4?40:60;
const labelForRound=n=>n>=32?'دور الـ32':n>=16?'ثمن النهائي':n===8?'ربع النهائي':n===4?'نصف النهائي':'النهائي';

// ================= مولدات البطولات =================
function standingsOf(g){
  const map={};g.playerIds.forEach(id=>map[id]={id,p:0,w:0,d:0,l:0,gf:0,ga:0});
  g.matches.forEach(m=>{
    if(!m.played||!m.homeId||!m.awayId)return;
    const h=map[m.homeId],a=map[m.awayId];
    h.p++;a.p++;h.gf+=m.homeScore;h.ga+=m.awayScore;a.gf+=m.awayScore;a.ga+=m.homeScore;
    const w=winnerOf(m);
    if(!w){h.d++;a.d++;}else if(w===m.homeId){h.w++;a.l++;}else{a.w++;h.l++;}
  });
  return Object.values(map).sort((a,b)=>((b.w*3+b.d)-(a.w*3+a.d))||(b.gf-b.ga)-(a.gf-a.ga)||(b.gf-a.gf)||(b.w-a.w)||byId(a.id).name.localeCompare(byId(b.id).name,'ar'));
}
function winnerOf(m){
  if(!m.homeId)return m.awayId; if(!m.awayId)return m.homeId;
  if(!m.played)return null;
  if(m.homeScore>m.awayScore)return m.homeId;
  if(m.awayScore>m.homeScore)return m.awayId;
  if(m.hasPens)return m.penHome>m.penAway?m.homeId:m.awayId;
  return null;
}
function mkMatch(t,round,label,grp,home,away,imp,pitch){
  return{id:uid(),tId:t.id,round,roundLabel:label,groupName:grp||null,homeId:home||null,awayId:away||null,homeScore:null,awayScore:null,hasPens:false,penHome:0,penAway:0,played:!home||!away,pitch:pitch||1,importance:imp,dH:0,dA:0};
}
function roundRobin(t,ids,grp,imp,pitches,base){
  let ps=[...ids]; if(ps.length%2)ps.push(null);
  const n=ps.length,rot=ps.slice(1),out=[];let seq=0;
  for(let r=0;r<n-1;r++){
    const rp=[ps[0],...rot];
    for(let i=0;i<n/2;i++){
      const a=rp[i],b=rp[n-1-i];
      if(a&&b){seq++;out.push(mkMatch(t,base+r,grp?grp+' - الجولة '+(r+1):'الجولة '+(r+1),grp,a,b,imp,((seq-1)%pitches)+1));}
    }
    rot.push(rot.shift());
  }
  return out;
}
function drawGroups(t,imp){
  const sh=[...t.playerIds].sort(()=>Math.random()-.5),out=[],L='ABCDEFGHIJKL';let seq=0;
  for(let i=0;i<sh.length/4;i++){
    const name='المجموعة '+L[i];
    const gr={name,playerIds:sh.slice(i*4,i*4+4),matches:roundRobin(t,sh.slice(i*4,i*4+4),name,imp,t.pitches,1)};
    gr.matches.forEach(m=>{seq++;m.pitch=((seq-1)%t.pitches)+1;});
    out.push(gr);
  }
  return out;
}
function knockoutRound(t,ids,round){
  let n=ids.length,size=2;while(size<n)size*=2;
  const out=[],imp=impForRound(size),lab=labelForRound(size);
  for(let i=0;i<size/2;i++){
    const a=i<n?ids[i]:null,b=(size-1-i)<n?ids[size-1-i]:null;
    out.push(mkMatch(t,round,lab,null,a,b,imp,1));
  }
  return out;
}
function qualifiers(groups){
  const w=[],r=[];groups.forEach(g=>{const s=standingsOf(g);w.push(s[0].id);r.push(s[1].id);});
  const out=[];w.forEach((x,i)=>{out.push(x);out.push(r[r.length-1-i]);});return out;
}
function swissRound(t,num){
  const g=t.groups[0],st=standingsOf(g),ids=st.map(s=>s.id);
  const played=new Set();g.matches.forEach(m=>{if(m.homeId&&m.awayId){played.add(m.homeId+'|'+m.awayId);played.add(m.awayId+'|'+m.homeId);}});
  const used=new Set(),out=[];
  for(let i=0;i<ids.length;i++){
    if(used.has(ids[i]))continue;
    let opp=null;
    for(let j=i+1;j<ids.length;j++)if(!used.has(ids[j])&&!played.has(ids[i]+'|'+ids[j])){opp=ids[j];break;}
    if(!opp)opp=ids.slice(i+1).find(x=>!used.has(x));
    if(!opp)continue;
    used.add(ids[i]);used.add(opp);
    out.push(mkMatch(t,num,'الجولة '+num,'السويسري',ids[i],opp,15,(out.length%t.pitches)+1));
  }
  return out;
}
function createTournament(name,type,ids,pitches,swissRounds){
  const t={id:uid(),name,type,playerIds:ids,finished:false,pitches,swissRounds,groups:[],bracket:[]};
  if(type==='league'){t.groups=[{name:'',playerIds:ids,matches:roundRobin(t,ids,'',15,pitches,1)}];}
  else if(type==='swiss'){t.groups=[{name:'السويسري',playerIds:ids,matches:[]}];t.groups[0].matches=swissRound(t,1);}
  else if(type==='knockout'){t.bracket=[knockoutRound(t,ids,1)];}
  else{t.groups=drawGroups(t,15);}
  tournaments.unshift(t);save();return t;
}
function allMatches(t){return[...t.groups.flatMap(g=>g.matches),...t.bracket.flat()];}

// ================= التقدم في البطولة =================
function recordResult(t,m,hs,as,hasPens,ph,pa){
  if(m.played)return;
  m.homeScore=hs;m.awayScore=as;m.hasPens=!!(hasPens&&hs===as&&m.importance>=25);m.penHome=ph||0;m.penAway=pa||0;m.played=true;
  const h=byId(m.homeId),a=byId(m.awayId);
  if(h&&a)applyMatch(h,a,m);
  progress(t);save();
}
function progress(t){
  if(t.finished)return;
  const award=id=>{const p=byId(id);if(p)p.titles++;};
  if(t.type==='league'){
    const ms=t.groups[0].matches;
    if(ms.every(m=>m.played)){t.finished=true;award(standingsOf(t.groups[0])[0].id);}
  }else if(t.type==='swiss'){
    const g=t.groups[0];
    const maxR=Math.max(0,...g.matches.map(m=>m.round));
    if(g.matches.filter(m=>m.round===maxR).every(m=>m.played)){
      if(maxR<t.swissRounds)g.matches.push(...swissRound(t,maxR+1));
      else{t.finished=true;award(standingsOf(g)[0].id);}
    }
  }else if(t.type==='knockout'){
    advanceBracket(t);
  }else{
    const allP=t.groups.every(g=>g.matches.every(m=>m.played));
    if(t.qualifier){
      if(allP&&!t.finished){
        t.qualifiedIds=t.groups.map(g=>standingsOf(g)[0]?.id).filter(Boolean).slice(0,8);
        t.finished=true;
        t.qualifiedIds.forEach(award);
      }
    }else if(!t.bracket.length){
      if(allP){const q=qualifiers(t.groups);
        if(q.length===2)t.bracket=[[mkMatch(t,1,'النهائي',null,q[0],q[1],60,1)]];
        else t.bracket=[knockoutRound(t,q,1)];}
    }else advanceBracket(t);
  }
}
function advanceBracket(t){
  const round=t.bracket[t.bracket.length-1];
  if(!round.every(m=>m.played))return;
  const winners=round.map(winnerOf);
  if(round.length===1){t.finished=true;const p=byId(winners[0]);if(p)p.titles++;return;}
  const next=[],imp=impForRound(winners.length),lab=labelForRound(winners.length);
  for(let i=0;i<winners.length;i+=2)next.push(mkMatch(t,t.bracket.length+1,lab,null,winners[i],winners[i+1],imp,1));
  t.bracket.push(next);
}

// ================= تصفيات كأس العالم =================
function createQualification(conf){
  const source=CONTINENTS[conf]||[];
  const ids=source.map(([name])=>players.find(p=>p.name===name)?.id).filter(Boolean);
  const use=ids.slice(0,32);
  if(use.length<32){alert('هذه القارة لا تحتوي 32 منتخبًا افتراضيًا. يمكنك إضافة منتخبات من قسم المنتخبات.');return null;}
  const name=QUALIFIERS[conf]+' — 32 منتخبًا / 8 مقاعد';
  const t=createTournament(name,'championsLeague',use,4,0);
  t.qualifier={continent:conf,slots:8};
  save();return t;
}
const DIRECT_QUALIFIERS=['africa','europe','asia','americas'];
function qualificationStatus(){
  const slots=[];
  DIRECT_QUALIFIERS.forEach(conf=>{
    const q=tournaments.find(t=>t.qualifier&&t.qualifier.continent===conf&&t.finished);
    const ids=q?(q.qualifiedIds||[]).slice(0,8):[];
    slots.push({conf,ids,tournament:q});
  });
  return slots;
}
function createWorldCupFinal(){
  const status=qualificationStatus();
  const ids=[];
  status.forEach(x=>x.ids.forEach(id=>{if(!ids.includes(id))ids.push(id);}));
  if(ids.length<32){alert('لم تكتمل المقاعد بعد. يجب أن تكتمل تصفيات أفريقيا وأوروبا وآسيا والأمريكتين أولًا (8 مقاعد لكل تصفيات = 32 منتخبًا).');return null;}
  if(tournaments.some(t=>t.type==='worldCup'&&!t.finished)){
    alert('يوجد كأس عالم قيد اللعب بالفعل.');return null;
  }
  return createTournament('كأس العالم — 32 منتخبًا','worldCup',ids.slice(0,32),4,0);
}
function qualifiedSlotsView(){
  const labels={africa:'🌍 أفريقيا',europe:'🇪🇺 أوروبا',asia:'🌏 آسيا',americas:'🌎 الأمريكتان'};
  const status=qualificationStatus();
  const all=status.flatMap(x=>x.ids);
  const ready=all.length===32;
  return '<div class="card" style="margin:8px 10px;background:#0d2f39;border:1px solid #14586a">'
    +'<div class="rowline"><div><b>🎟️ مقاعد كأس العالم</b><div class="dim">التأهل ينتقل تلقائيًا إلى هذه الخانة بعد اكتمال كل تصفيات.</div></div><span class="badge">'+all.length+'/32</span></div>'
    +status.map(x=>'<div style="margin-top:12px"><div class="rowline"><b>'+labels[x.conf]+' — '+x.ids.length+'/8</b>'+(x.ids.length===8?'<span class="up">✓ مكتملة</span>':'<span class="dim">قيد الانتظار</span>')+'</div>'
      +'<div style="margin-top:6px">'+Array.from({length:8},(_,i)=>x.ids[i]?'<div class="compact-card" style="margin:3px 0;padding:7px"><span>'+(i+1)+'. </span>'+byId(x.ids[i]).name+' <span class="dim">'+starText(byId(x.ids[i]).stars)+'</span></div>':'<div class="compact-card" style="margin:3px 0;padding:7px;color:#666">'+(i+1)+'. مقعد فارغ</div>').join('')+'</div></div>').join('')
    +'<button class="act" style="width:100%;margin-top:12px" '+(ready?'':'disabled')+' onclick="createWorldCupFinal()">'+(ready?'🏆 بدء كأس العالم بـ32 منتخبًا':'🔒 أكمل التصفيات أولًا')+'</button>'
    +'</div>';
}
function qualificationView(){
  const labels={africa:'🌍 تصفيات أفريقيا',europe:'🇪🇺 تصفيات أوروبا',asia:'🌏 تصفيات آسيا',americas:'🌎 تصفيات الأمريكتين'};
  const rows=DIRECT_QUALIFIERS.map(k=>{
    const done=tournaments.filter(t=>t.qualifier&&t.qualifier.continent===k&&t.finished).length;
    const active=tournaments.find(t=>t.qualifier&&t.qualifier.continent===k&&!t.finished);
    return '<div class="compact-card"><div class="rowline"><div><b>'+labels[k]+'</b><div class="dim">32 منتخبًا • 8 مقاعد مباشرة لكأس العالم</div></div><button class="act" data-conf="'+k+'" onclick="createQualification(this.dataset.conf)">'+(active?'تصفيات جديدة':'إنشاء')+'</button></div>'+(done?'<div class="up" style="margin-top:6px">✓ تم نقل 8 متأهلين إلى مقاعد كأس العالم</div>':'')+'</div>';
  }).join('');
  const oceania='<div class="compact-card"><div class="rowline"><div><b>🌊 أوقيانوسيا</b><div class="dim">تصفيات خاصة — لا تدخل ضمن الـ32 مقعدًا المباشرة في هذا النظام.</div></div></div></div>';
  return '<h2 style="padding:10px 12px 4px">🌍 تصفيات كأس العالم</h2>'+qualifiedSlotsView()+'<div class="card" style="margin:8px 10px"><b>النظام:</b> أفريقيا + أوروبا + آسيا + الأمريكتان. كل تصفيات تضم 32 منتخبًا، ويتأهل منها 8 مباشرة. عند اكتمال الـ32 مقعدًا تنتقل المنتخبات تلقائيًا إلى كأس العالم.</div>'+rows+oceania;
}
window.createQualification=createQualification;window.createWorldCupFinal=createWorldCupFinal;

// ================= الواجهة =================
var tab='tournaments', viewT=null;
const TYPES={league:'دوري',knockout:'خروج مغلوب',championsLeague:'دوري أبطال',worldCup:'كأس العالم',swiss:'سويسري'};
function render(){
  document.getElementById('nav').style.display=viewT?'none':'flex';
  document.getElementById('nav').innerHTML=
    [['tournaments','🏆 البطولات'],['qualifications','🎟️ التأهل'],['players','👥 المنتخبات'],['ranking','🌐 التصنيف العالمي'],['about','ℹ️ حول']]
    .map(([k,l])=>'<button class="'+(tab===k?'active':'')+'" onclick="go(\''+k+'\')">'+l+'</button>').join('');
  const app=document.getElementById('app');
  if(tab==='qualifications')app.innerHTML=qualificationView();
  else if(tab==='players')app.innerHTML=playersView();
  else if(tab==='ranking')app.innerHTML=rankingView();
  else if(tab==='about')app.innerHTML=aboutView();
  else app.innerHTML=viewT?tournamentView(viewT):tournamentsView();
}
function go(t){tab=t;viewT=null;render();}
function openT(id){viewT=tournaments.find(t=>t.id===id);render();}
window.go=go;window.openT=openT;

function playersView(){
  return '<div class="rowline"><h2>المنتخبات</h2><button class="act" onclick="addPlayer()">+ منتخب</button></div>'
  +(players.length?players.map(p=>'<div class="card"><div class="rowline"><div><b>'+p.name+'</b><div class="dim">قوة: '+starText(p.stars)+' • تصنيف '+Math.round(p.rating)+'</div><div class="dim">لعب '+p.played+' • فاز '+p.wins+' • تعادل '+p.draws+' • خسر '+p.losses+' • ألقاب '+p.titles+'</div></div><div><button class="small" onclick="editStars(\''+p.id+'\')">تعديل ⭐</button> <button class="danger" onclick="delPlayer(\''+p.id+'\')">🗑</button></div></div></div>').join(''):'<p class="dim">أضف المنتخبات أولًا</p>');
}
function starText(n){return '⭐'.repeat(Math.max(1,Math.min(5,Number(n)||3)))+'☆'.repeat(5-Math.max(1,Math.min(5,Number(n)||3)));}
function addPlayer(){const n=prompt('اسم المنتخب:');if(n&&n.trim()){const s=prompt('عدد النجوم من 1 إلى 5:','3');players.push(mkPlayer(n.trim(),s));save();render();}}
function editStars(id){const p=byId(id);if(!p)return;const s=prompt('عدد النجوم من 1 إلى 5:',p.stars);if(s!==null){p.stars=Math.max(1,Math.min(5,parseInt(s)||3));save();render();}}
function delPlayer(id){players=players.filter(p=>p.id!==id);save();render();}
window.addPlayer=addPlayer;window.editStars=editStars;window.delPlayer=delPlayer;

function rankingView(){
  const list=[...players].sort((a,b)=>b.rating-a.rating);
  if(!list.length)return '<h2>التصنيف العالمي</h2><p class="dim">لا يوجد لاعبون بعد</p>';
  const medals=['🥇','🥈','🥉'];
  return '<h2>🌐 التصنيف العالمي</h2>'+list.map((p,i)=>{
    const d=p.lastDelta;
    return '<div class="card"><div class="rowline"><div class="rowline"><span style="width:34px;text-align:center">'+(medals[i]||(i+1))+'</span><div><b>'+p.name+'</b><div class="dim">لعب '+p.played+' • فاز '+p.wins+' • تعادل '+p.draws+' • خسر '+p.losses+' 🏆'+p.titles+'</div></div></div><div style="text-align:left"><b>'+p.rating.toFixed(1)+'</b>'+(d?(d>0?'<div class="up">▲ +'+d.toFixed(1)+'</div>':'<div class="down">▼ '+d.toFixed(1)+'</div>'):'')+'</div></div></div>';
  }).join('');
}

var selType='league', selPlayers=new Set(), selPitches=2, selRounds=4;
function tournamentsView(){
  return '<div class="rowline"><h2>البطولات</h2><button class="act" onclick="showCreate()">+ بطولة</button></div>'+
  (tournaments.length?tournaments.map(t=>'<div class="card" style="cursor:pointer" onclick="openT(\''+t.id+'\')"><div class="rowline"><div><b>'+(t.finished?'🏆 ':'⚽ ')+t.name+'</b><div class="dim">'+TYPES[t.type]+' • '+t.playerIds.length+' لاعب'+(t.finished?' • انتهت':'')+(t.qualifier&&t.qualifiedIds?' • تأهل '+t.qualifiedIds.length:'')+'</div></div><button class="danger" onclick="event.stopPropagation();delT(\''+t.id+'\')">🗑</button></div></div>').join(''):'<p class="dim">أنشئ أول بطولة!</p>');
}
function delT(id){tournaments=tournaments.filter(t=>t.id!==id);save();render();}
window.delT=delT;

function showCreate(){
  selPlayers=new Set();
  const dlg=document.getElementById('dlg');
  const groupType=selType==='championsLeague'||selType==='worldCup';
  dlg.innerHTML='<h3 style="margin-bottom:10px">بطولة جديدة</h3>'
  +'<label>اسم البطولة</label><input id="c_name" placeholder="مثال: بطولة الصيف">'
  +'<label>النظام</label><select id="c_type" onchange="selType=this.value;showCreateRefresh()">'
  +Object.entries(TYPES).map(([k,v])=>'<option value="'+k+'"'+(k===selType?' selected':'')+'>'+v+'</option>').join('')+'</select>'
  +(!groupType&&selType!=='knockout'?'<label>عدد الشاشات/التلفزيونات</label><select id="c_pitches">'+[1,2,3,4,6,8].map(n=>'<option'+(n===selPitches?' selected':'')+'>'+n+'</option>').join('')+'</select>':'')
  +(selType==='swiss'?'<label>عدد الجولات</label><select id="c_rounds">'+[3,4,5,6,7].map(n=>'<option'+(n===selRounds?' selected':'')+'>'+n+'</option>').join('')+'</select>':'')
  +'<label>اللاعبون ('+selPlayers.size+' مختار)</label><div class="chips">'+players.map(p=>'<span class="chip" id="chip_'+p.id+'" onclick="toggleP(\''+p.id+'\')">'+p.name+'</span>').join('')+'</div>'
  +'<div class="rowline" style="margin-top:14px"><button class="small" onclick="dlg.close()">إلغاء</button><button class="act" onclick="doCreate()">إنشاء</button></div>';
  dlg.showModal();
}
function showCreateRefresh(){selPitches=+((document.getElementById('c_pitches')||{}).value||selPitches);selRounds=+((document.getElementById('c_rounds')||{}).value||selRounds);showCreate();}
function toggleP(id){const c=document.getElementById('chip_'+id);if(selPlayers.has(id)){selPlayers.delete(id);c.classList.remove('sel');}else{selPlayers.add(id);c.classList.add('sel');}}
function doCreate(){
  const name=(document.getElementById('c_name').value||'').trim();
  selPitches=+((document.getElementById('c_pitches')||{}).value||selPitches);
  selRounds=+((document.getElementById('c_rounds')||{}).value||selRounds);
  const n=selPlayers.size, groupType=selType==='championsLeague'||selType==='worldCup';
  const minN=selType==='league'?3:selType==='knockout'?2:selType==='swiss'?4:8;
  if(!name||(!groupType&&n<minN)||(groupType&&(n<8||n%4!==0))){alert('تحقق من الاسم وعدد اللاعبين'+(groupType?' (8، 12، 16... بمضاعفات 4)':''));return;}
  const t=createTournament(name,selType,[...selPlayers],selPitches,selRounds);
  document.getElementById('dlg').close();
  openT(t.id);
}
window.showCreate=showCreate;window.showCreateRefresh=showCreateRefresh;window.toggleP=toggleP;window.doCreate=doCreate;

var subTab='matches';
function tournamentView(t){
  const hasBracket=t.bracket.length||t.type==='championsLeague'||t.type==='worldCup';
  let body='';
  if(subTab==='matches')body=matchesView(t);
  else if(subTab==='standings')body=standingsView(t);
  else body=bracketView(t);
  return '<button class="small" onclick="viewT=null;render()">→ رجوع</button>'
  +'<h2 style="margin:8px 10px">'+t.name+' <span class="dim">'+TYPES[t.type]+'</span></h2>'
  +'<div class="top-tabs"><button class="'+(subTab==='matches'?'active':'')+'" onclick="subTab=\'matches\';render()">المباريات</button><button class="'+(subTab==='standings'?'active':'')+'" onclick="subTab=\'standings\';render()">الترتيب</button>'+(hasBracket?'<button class="'+(subTab==='bracket'?'active':'')+'" onclick="subTab=\'bracket\';render()">نصف/ربع/نهائي</button>':'')+'</div>'
  +(t.finished?'<div class="final-banner" style="margin:8px 10px">🏆 انتهت البطولة</div>'+(t.qualifier&&t.qualifiedIds?'<div class="compact-card"><b>🎟️ المنتخبات المتأهلة (8)</b><div style="margin-top:8px">'+t.qualifiedIds.map(id=>'<div class="dim" style="padding:3px 0">'+byId(id).name+' — '+starText(byId(id).stars)+'</div>').join('')+'</div></div>':''):'')
  +(subTab==='matches'&&!t.finished?'<div class="auto-card"><div><b>⚡ إكمال تلقائي لدور المجموعات</b><div class="dim">يملأ نتائج المباريات غير المكتملة بسرعة.</div></div><label class="switch"><input type="checkbox" onchange="autoGroups(this.checked,\''+t.id+'\')"><span class="slider"></span></label></div>':'')
  +body;
}
window.setSub=s=>{subTab=s;render();};

function matchesView(t){
  const ms=allMatches(t);
  if(!ms.length)return '<p class="dim">لا توجد مباريات بعد</p>';
  const labels=[...new Set(ms.map(m=>m.roundLabel))];
  return labels.map(l=>'<h3 style="margin:10px 0 6px">'+l+'</h3>'+ms.filter(m=>m.roundLabel===l).map(m=>matchCard(t,m)).join('')).join('');
}
function matchCard(t,m){
  if(!m.awayId)return'';
  const h=byId(m.homeId),a=byId(m.awayId);
  const center=m.played?'<b>'+m.homeScore+' - '+m.awayScore+'</b>'+(m.hasPens?'<div class="dim">ترجيح '+m.penHome+'-'+m.penAway+'</div>':''):'<span class="dim">؟ - ؟</span>';
  const hs=h?starText(h.stars):''; const as=a?starText(a.stars):'';
  return '<div class="match-row"><div class="pitch">المباراة<b>'+m.pitch+'</b></div><div class="team home">'+(h?h.name:'؟')+'<span class="stars">'+hs+'</span></div><div class="score '+(m.played?'':'gray')+'" onclick="'+(m.played?'':'resultDlg(tournaments.find(x=>x.id===\''+t.id+'\'),tournaments.flatMap(x=>allMatches(x)).find(x=>x.id===\''+m.id+'\'))')+'">'+center+'</div><div class="team away">'+(a?a.name:'؟')+'<span class="stars">'+as+'</span></div><button class="random-btn" '+(m.played?'disabled':'onclick="randomScore(tournaments.find(x=>x.id===\''+t.id+'\'),tournaments.flatMap(x=>allMatches(x)).find(x=>x.id===\''+m.id+'\'))"')+'>🎲</button></div>';
}

function standingsView(t){
  if(!t.groups.length)return '<p class="dim">لا يوجد ترتيب</p>';
  return t.groups.map(g=>'<h3 style="margin:10px 0 6px">'+(g.name||'الترتيب')+'</h3><div class="card" style="padding:4px"><table><tr><th>#</th><th>اللاعب</th><th>ل</th><th>ف</th><th>ت</th><th>خ</th><th>له</th><th>عليه</th><th>±</th><th>نقاط</th></tr>'
  +standingsOf(g).map((s,i)=>'<tr><td>'+(i+1)+'</td><td style="text-align:right">'+byId(s.id).name+'</td><td>'+s.p+'</td><td>'+s.w+'</td><td>'+s.d+'</td><td>'+s.l+'</td><td>'+s.gf+'</td><td>'+s.ga+'</td><td>'+(s.gf-s.ga)+'</td><td><b>'+(s.w*3+s.d)+'</b></td></tr>').join('')+'</table></div>').join('');
}
function bracketView(t){
  if(!t.bracket.length)return '<p class="dim">تُبنى الأدوار الإقصائية بعد انتهاء دور المجموعات</p>';
  return t.bracket.map(r=>'<h3 style="margin:10px 0 6px">'+r[0].roundLabel+'</h3>'+r.map(m=>matchCard(t,m)).join('')).join('');
}

function autoGroups(checked,tId){
  if(!checked)return;
  const t=tournaments.find(x=>x.id===tId);if(!t)return;
  const pending=t.groups.flatMap(g=>g.matches).filter(m=>!m.played&&m.homeId&&m.awayId);
  pending.forEach(m=>{const h=byId(m.homeId),a=byId(m.awayId);const diff=(h.stars||3)-(a.stars||3);let hs=Math.max(0,Math.min(5,Math.round(1.1+diff*.22+Math.random()*2.4)));let as=Math.max(0,Math.min(5,Math.round(1.1-diff*.22+Math.random()*2.4)));if(hs===as&&Math.random()<.35){if(diff>0)hs++;else if(diff<0)as++;}recordResult(t,m,hs,as,false,0,0);});
  save();render();
}
window.autoGroups=autoGroups;

function randomScore(t,m){
  const h=byId(m.homeId),a=byId(m.awayId); if(!h||!a||m.played)return;
  const hs=h.stars||3, as=a.stars||3;
  const diff=hs-as;
  const baseH=Math.max(0,Math.min(5,Math.round(1.2+(diff*0.28)+(Math.random()*2.4-0.9))));
  const baseA=Math.max(0,Math.min(5,Math.round(1.2-(diff*0.28)+(Math.random()*2.4-0.9))));
  let home=baseH, away=baseA;
  if(home===away && Math.random()<Math.min(.65,.35+Math.abs(diff)*.08)){if(diff>0)home=Math.min(5,home+1);else if(diff<0)away=Math.min(5,away+1);}
  const pens=m.importance>=25 && home===away && Math.random()<.35;
  const ph=pens?Math.floor(Math.random()*3)+3:0, pa=pens?Math.floor(Math.random()*3)+2:0;
  recordResult(tournaments.find(x=>x.id===m.tId),m,home,away,pens,ph,pa);render();
}
window.randomScore=randomScore;

function resultDlg(t,m){
  const dlg=document.getElementById('dlg');
  const canPens=m.importance>=25;
  dlg.innerHTML='<h3 style="margin-bottom:10px">'+(byId(m.homeId)||{}).name+' × '+(byId(m.awayId)||{}).name+'</h3>'
  +'<div class="rowline" style="justify-content:center;gap:10px;margin-bottom:8px"><input class="score-input" id="r_h" type="number" min="0" placeholder="0"><span>-</span><input class="score-input" id="r_a" type="number" min="0" placeholder="0"></div>'
  +(canPens?'<label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="r_pens" style="width:auto"> حُسمت بركلات الترجيح</label><div class="rowline" style="justify-content:center;gap:10px;margin-top:6px"><input class="score-input" id="r_ph" type="number" min="0" value="0"><span>-</span><input class="score-input" id="r_pa" type="number" min="0" value="0"></div>':'')
  +'<div class="rowline" style="margin-top:14px"><button class="small" onclick="dlg.close()">إلغاء</button><button class="act" onclick="saveResult(tournaments.find(x=>x.id===\''+t.id+'\'),\''+m.id+'\')">حفظ</button></div>';
  dlg.showModal();
}
function saveResult(t,mid){
  const hs=parseInt(document.getElementById('r_h').value),as=parseInt(document.getElementById('r_a').value);
  if(isNaN(hs)||isNaN(as)){alert('أدخل النتيجة');return;}
  const pens=document.getElementById('r_pens');
  const ph=parseInt((document.getElementById('r_ph')||{}).value||0),pa=parseInt((document.getElementById('r_pa')||{}).value||0);
  const m=allMatches(t).find(x=>x.id===mid);
  recordResult(t,m,hs,as,pens&&pens.checked,ph,pa);
  document.getElementById('dlg').close();
  render();
}
window.resultDlg=resultDlg;window.saveResult=saveResult;

function aboutView(){
  return '<h2>حول التطبيق</h2><div class="card"><b>بطولاتي</b> — مدير بطولات للعب مع الأصدقاء (FIFA / PES / أي لعبة) مع التصنيف العالمي.</div>'
  +'<div class="card"><b>نظام التصنيف العالمي (FIFA):</b><br>• كل لاعب يبدأ بـ 1000 نقطة<br>• النقاط الجديدة = القديمة + أهمية المباراة × (النتيجة − المتوقعة)<br>• الأهمية: مجموعات/سويسري 15، ثمن نهائي 25، ربع نهائي 35، نصف نهائي 40، نهائي 60<br>• النتيجة: فوز 1، تعادل 0.5، خسارة 0، فوز ترجيح 0.75، خسارة ترجيح 0.5<br>• المتوقعة = 1÷(1+10^(−فرق النقاط/600))<br>• التصنيف يتراكم عبر كل البطولات ولا يتصفّر</div>'
  +'<div class="card"><b>الأنماط:</b> دوري، خروج مغلوب، دوري أبطال، كأس العالم، سويسري</div>';
}

// ================= تشغيل =================
load();
render();
