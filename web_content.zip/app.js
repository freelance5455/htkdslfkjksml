import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

/*
  1) Supabase dashboard -> Project Settings -> API
  2) Replace both values below with your Project URL and anon/publishable key.
  NEVER put the service_role/secret key in frontend code.
*/
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY_HERE";

const configured = SUPABASE_URL.startsWith("https://") &&
  !SUPABASE_URL.includes("PASTE_") &&
  !SUPABASE_ANON_KEY.includes("PASTE_");
const supabase = configured ? createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

const $ = (id) => document.getElementById(id);
let currentUser = null;
let profilesCache = [];

function status(id, message, error = false) {
  const el = $(id);
  if (!el) return;
  el.textContent = message || "";
  el.style.color = error ? "#b42318" : "#1763c6";
}
function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}
function shortDate(value) {
  try { return new Date(value).toLocaleString("bn-BD", {dateStyle:"medium", timeStyle:"short"}); }
  catch { return value || ""; }
}
function requireSetup() {
  if (!supabase) {
    status("globalStatus", "প্রথমে app.js ফাইলে Supabase Project URL এবং anon/publishable key বসান।", true);
    return false;
  }
  return true;
}
function showSignedIn(signedIn) {
  $("authPanel").hidden = signedIn;
  $("appPanel").hidden = !signedIn;
}
async function ensureProfile(user, name = "") {
  const { data: existing, error: readError } = await supabase
    .from("profiles").select("id, full_name").eq("id", user.id).maybeSingle();
  if (readError) throw readError;
  if (!existing) {
    const { error } = await supabase.from("profiles").insert({
      id: user.id,
      full_name: name || user.user_metadata?.full_name || user.email?.split("@")[0] || "নতুন ব্যবহারকারী"
    });
    if (error) throw error;
  }
}
async function refreshSession() {
  if (!requireSetup()) return;
  const { data, error } = await supabase.auth.getSession();
  if (error) status("globalStatus", error.message, true);
  currentUser = data.session?.user || null;
  showSignedIn(Boolean(currentUser));
  if (currentUser) {
    try {
      await ensureProfile(currentUser);
      const { data: profile } = await supabase.from("profiles").select("full_name").eq("id", currentUser.id).maybeSingle();
      $("profileName").value = profile?.full_name || "";
      await Promise.all([loadPosts(), loadUsers(), loadMessages()]);
    } catch (e) { status("globalStatus", e.message, true); }
  }
}
async function signup() {
  if (!requireSetup()) return;
  const email = $("email").value.trim();
  const password = $("password").value;
  const name = $("fullName").value.trim();
  if (!email || password.length < 6 || !name) {
    status("authStatus", "নাম, ইমেইল ও কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।", true); return;
  }
  status("authStatus", "অ্যাকাউন্ট তৈরি হচ্ছে...");
  const { data, error } = await supabase.auth.signUp({
    email, password, options: { data: { full_name: name } }
  });
  if (error) { status("authStatus", error.message, true); return; }
  if (data.session) {
    currentUser = data.user;
    try { await ensureProfile(currentUser, name); } catch (e) { status("authStatus", e.message, true); return; }
    status("authStatus", "অ্যাকাউন্ট তৈরি হয়েছে।");
    await refreshSession();
  } else {
    status("authStatus", "অ্যাকাউন্ট তৈরি হয়েছে। ইমেইলে আসা confirmation link খুলে তারপর লগইন করুন।");
  }
}
async function login() {
  if (!requireSetup()) return;
  const email = $("email").value.trim();
  const password = $("password").value;
  status("authStatus", "লগইন হচ্ছে...");
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) { status("authStatus", error.message, true); return; }
  await refreshSession();
}
async function saveProfile() {
  if (!currentUser) return;
  const name = $("profileName").value.trim();
  if (!name) { status("profileStatus", "নাম লিখুন।", true); return; }
  const { error } = await supabase.from("profiles").upsert({ id: currentUser.id, full_name: name });
  status("profileStatus", error ? error.message : "প্রোফাইল সংরক্ষণ হয়েছে।", Boolean(error));
  if (!error) await loadUsers();
}
async function loadPosts() {
  if (!currentUser) return;
  const { data, error } = await supabase.from("posts")
    .select("id,user_id,content,media_url,created_at,profiles(full_name),likes(user_id),comments(id,content,user_id,created_at,profiles(full_name))")
    .order("created_at", { ascending: false }).limit(50);
  if (error) { $("postsList").innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`; return; }
  $("postsList").innerHTML = (data || []).map(post => {
    const liked = (post.likes || []).some(x => x.user_id === currentUser.id);
    const comments = (post.comments || []).map(c =>
      `<div class="tiny"><b>${escapeHtml(c.profiles?.full_name || "ব্যবহারকারী")}:</b> ${escapeHtml(c.content)}</div>`
    ).join("");
    const media = post.media_url ? `<a class="media-link" href="${escapeHtml(post.media_url)}" target="_blank" rel="noopener noreferrer">মিডিয়া খুলুন</a>` : "";
    return `<article class="post-card">
      <div class="card-head"><div class="avatar">${escapeHtml((post.profiles?.full_name || "U").slice(0,1))}</div>
      <div><b>${escapeHtml(post.profiles?.full_name || "ব্যবহারকারী")}</b><small>${escapeHtml(shortDate(post.created_at))}</small></div></div>
      <div class="post-body">${escapeHtml(post.content || "")}</div>${media}
      <div class="card-actions"><button data-like="${post.id}" data-liked="${liked}">${liked ? "♥ লাইক তুলে নিন" : "♡ লাইক"} (${(post.likes || []).length})</button>
      <button data-comment="${post.id}">কমেন্ট (${(post.comments || []).length})</button></div>
      <div class="comments">${comments}</div></article>`;
  }).join("") || `<p class="muted">এখনো কোনো পোস্ট নেই। প্রথম পোস্টটি আপনি করুন!</p>`;
  $("postsList").querySelectorAll("[data-like]").forEach(btn => btn.addEventListener("click", () => toggleLike(btn.dataset.like, btn.dataset.liked === "true")));
  $("postsList").querySelectorAll("[data-comment]").forEach(btn => btn.addEventListener("click", () => addComment(btn.dataset.comment)));
}
async function publishPost() {
  if (!currentUser) return;
  const content = $("postContent").value.trim();
  const media_url = $("postMediaUrl").value.trim() || null;
  if (!content && !media_url) { status("postStatus", "লেখা অথবা মিডিয়ার লিংক দিন।", true); return; }
  if (media_url && !/^https?:\/\//i.test(media_url)) { status("postStatus", "মিডিয়া লিংক https:// দিয়ে শুরু হতে হবে।", true); return; }
  const { error } = await supabase.from("posts").insert({ user_id: currentUser.id, content, media_url });
  status("postStatus", error ? error.message : "পোস্ট প্রকাশ হয়েছে।", Boolean(error));
  if (!error) { $("postContent").value = ""; $("postMediaUrl").value = ""; await loadPosts(); }
}
async function toggleLike(postId, alreadyLiked) {
  if (alreadyLiked) {
    const { error } = await supabase.from("likes").delete().eq("post_id", postId).eq("user_id", currentUser.id);
    if (error) status("globalStatus", error.message, true);
  } else {
    const { error } = await supabase.from("likes").insert({ post_id: postId, user_id: currentUser.id });
    if (error) status("globalStatus", error.message, true);
  }
  await loadPosts();
}
async function addComment(postId) {
  const content = prompt("কমেন্ট লিখুন:");
  if (!content?.trim()) return;
  const { error } = await supabase.from("comments").insert({ post_id: postId, user_id: currentUser.id, content: content.trim() });
  if (error) status("globalStatus", error.message, true);
  await loadPosts();
}
async function loadUsers() {
  if (!currentUser) return;
  const { data, error } = await supabase.from("profiles").select("id,full_name,created_at").order("created_at", { ascending: false }).limit(200);
  if (error) { $("usersList").innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`; return; }
  profilesCache = data || [];
  $("usersList").innerHTML = profilesCache.map(p => `<article class="user-card">
    <div class="avatar">${escapeHtml((p.full_name || "U").slice(0,1))}</div>
    <div class="user-info"><b>${escapeHtml(p.full_name || "ব্যবহারকারী")}</b><small>ID: ${escapeHtml(p.id)}</small></div>
    <button class="id-copy" data-copy-id="${p.id}">ID কপি</button>
  </article>`).join("") || `<p class="muted">কোনো ব্যবহারকারী পাওয়া যায়নি।</p>`;
  $("usersList").querySelectorAll("[data-copy-id]").forEach(btn => btn.addEventListener("click", async () => {
    $("receiverId").value = btn.dataset.copyId;
    try { await navigator.clipboard.writeText(btn.dataset.copyId); status("globalStatus", "User ID কপি হয়েছে।"); }
    catch { status("globalStatus", "ID Chat-এর ঘরে বসানো হয়েছে।"); }
    document.querySelector('[data-view="chatView"]').click();
  }));
}
async function sendMessage() {
  if (!currentUser) return;
  const receiver_id = $("receiverId").value.trim();
  const content = $("messageContent").value.trim();
  if (!receiver_id || !content) { status("chatStatus", "প্রাপকের User ID ও মেসেজ দিন।", true); return; }
  if (receiver_id === currentUser.id) { status("chatStatus", "নিজেকে মেসেজ পাঠানো যাবে না।", true); return; }
  const { error } = await supabase.from("messages").insert({ sender_id: currentUser.id, receiver_id, content });
  status("chatStatus", error ? error.message : "মেসেজ পাঠানো হয়েছে।", Boolean(error));
  if (!error) { $("messageContent").value = ""; await loadMessages(); }
}
async function loadMessages() {
  if (!currentUser) return;
  const { data, error } = await supabase.from("messages")
    .select("id,sender_id,receiver_id,content,created_at")
    .or(`sender_id.eq.${currentUser.id},receiver_id.eq.${currentUser.id}`)
    .order("created_at", { ascending: true }).limit(100);
  if (error) { $("messagesList").innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`; return; }
  $("messagesList").innerHTML = (data || []).map(m => `<article class="message-card ${m.sender_id === currentUser.id ? "mine" : ""}">
    <div class="tiny muted">${m.sender_id === currentUser.id ? "আপনি → " + escapeHtml(m.receiver_id) : "প্রেরক: " + escapeHtml(m.sender_id)} · ${escapeHtml(shortDate(m.created_at))}</div>
    <div>${escapeHtml(m.content)}</div></article>`).join("") || `<p class="muted">এখনো কোনো মেসেজ নেই।</p>`;
}
function setupNavigation() {
  document.querySelectorAll(".tab").forEach(tab => tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t === tab));
    document.querySelectorAll(".view").forEach(view => view.hidden = view.id !== tab.dataset.view);
    if (tab.dataset.view === "feedView") loadPosts();
    if (tab.dataset.view === "usersView") loadUsers();
    if (tab.dataset.view === "chatView") loadMessages();
  }));
}
$("signupBtn").addEventListener("click", signup);
$("loginBtn").addEventListener("click", login);
$("saveProfileBtn").addEventListener("click", saveProfile);
$("publishBtn").addEventListener("click", publishPost);
$("loadPostsBtn").addEventListener("click", loadPosts);
$("loadUsersBtn").addEventListener("click", loadUsers);
$("sendMessageBtn").addEventListener("click", sendMessage);
$("loadMessagesBtn").addEventListener("click", loadMessages);
$("refreshBtn").addEventListener("click", refreshSession);
$("logoutBtn").addEventListener("click", async () => {
  const { error } = await supabase.auth.signOut();
  if (error) { status("globalStatus", error.message, true); return; }
  currentUser = null; showSignedIn(false); status("authStatus", "আপনি লগআউট করেছেন।");
});
setupNavigation();
if (!configured) {
  status("globalStatus", "শুরু করতে README.md দেখুন: Supabase প্রজেক্ট তৈরি করে app.js-এ URL ও anon key বসাতে হবে।");
} else {
  supabase.auth.onAuthStateChange(() => { refreshSession(); });
  refreshSession();
}
