
const SUPABASE_URL = "https://maztcaldlmjsgftoejku.supabase.co";
const SUPABASE_KEY = "sb_publishable_g1FkJ_45yJG26sepMBN-uA_ngerEMMz";
const db = window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
let user=null, household=null, items=[], shopping=[], activeTab="vorrat", editing=null, currentProductImage=null, currentProductData=null;

const cats=["Konserven","Tiefkühl","Kühlung","Fleisch","Beilagen","Nudeln & Reis","Backen","Getränke","Süßes & Snacks","Gewürze","Sonstiges"];
const units=["Stk.","g","kg","mg","ml","l","cl","Packung","Pack","Beutel","Dose","Glas","Flasche","Karton","Schachtel","Becher","Tube","Portion","Bund","Rolle","Meter","Paar","Tablette"];
const places=["Vorratsregal","Kühlschrank","Gefrierfach","Keller","Getränkelager","Sonstiges"];

function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function daysTo(d){if(!d)return null;const a=new Date();a.setHours(0,0,0,0);const b=new Date(d+"T00:00:00");return Math.round((b-a)/86400000)}
function mhdClass(d){const x=daysTo(d);return x!==null&&x<0?"expired":x!==null&&x<=7?"soon":""}
function mhdText(d){const x=daysTo(d);if(x===null)return "kein MHD";if(x<0)return `abgelaufen · ${Math.abs(x)} T.`;if(x===0)return "heute";if(x===1)return "morgen";return `in ${x} Tagen`}
function flash(msg,type="error"){const el=document.getElementById("flash");if(el){el.className=type;el.textContent=msg;el.classList.remove("hidden");setTimeout(()=>el.classList.add("hidden"),5000)}}

async function init(){
  const {data:{session}}=await db.auth.getSession();
  if(session){user=session.user;await loadHousehold();} else renderAuth();
  db.auth.onAuthStateChange(async (_e,s)=>{user=s?.user||null;if(user){await loadHousehold()}else{household=null;renderAuth()}});
}
function renderAuth(){
document.getElementById("app").innerHTML=`<main class="auth"><div class="auth-stage"><section class="card auth-card">
<p class="auth-kicker">Euer digitaler Vorrat</p>
<img class="auth-logo-img" src="app-icon.png" alt="Unser Vorrat">
<h1>Unser Vorrat</h1>
<p class="auth-sub">Gemeinsam lagern. Gemeinsam planen. Einfach Vorrat.</p>
<div class="auth-divider"></div>
<div id="flash" class="hidden"></div>
<label>E-Mail</label><input id="email" type="email" autocomplete="email" placeholder="deine@email.de">
<label>Passwort</label><input id="pw" type="password" autocomplete="current-password" placeholder="••••••••">
<div class="row auth-actions"><button onclick="login()">Einloggen</button><button class="secondary" onclick="signup()">Konto anlegen</button></div>
<p class="auth-note">Mit demselben Konto kannst du später auf Handy, Tablet und PC zugreifen.</p>
<p class="auth-vibe"><span>✦</span> Gothic · Beats · Vorrat <span>✦</span></p>
</section></div></main>`;
}
async function login(){
 try{
  const email=document.getElementById("email").value.trim(), password=document.getElementById("pw").value;
  if(!email||!password)return flash("Bitte E-Mail und Passwort eingeben.");
  const {error}=await db.auth.signInWithPassword({email,password});
  if(error)throw error;
 }catch(e){flash(e.message||"Login fehlgeschlagen.");}
}
async function signup(){
 try{
  const email=document.getElementById("email").value.trim(), password=document.getElementById("pw").value;
  if(!email||password.length<6)return flash("Bitte E-Mail eingeben und ein Passwort mit mindestens 6 Zeichen wählen.");
  const {data,error}=await db.auth.signUp({email,password});
  if(error)throw error;
  if(data.session) {flash("Konto erstellt. Du wirst angemeldet.","ok");}
  else flash("Konto erstellt. Bitte bestätige ggf. deine E-Mail und logge dich danach ein.","ok");
 }catch(e){flash(e.message||"Konto konnte nicht erstellt werden.");}
}
async function loadHousehold(){
 const {data,error}=await db.from("household_members").select("household_id").eq("user_id",user.id);
 if(error){renderError(error.message);return}
 if(!data?.length){renderSetup();return}
 const {data:h,error:he}=await db.from("households").select("*").eq("id",data[0].household_id).single();
 if(he){renderError(he.message);return}
 household=h;await loadData();renderApp();subscribe();
}
function renderSetup(){
document.getElementById("app").innerHTML=`<main class="auth"><section class="card">
<img class="auth-logo-img" src="app-icon.png" alt="Unser Vorrat"><h1>Unser Vorrat</h1><p class="sub">Fast geschafft! Richte euren gemeinsamen Haushalt ein.</p>
<div id="flash" class="hidden"></div>
<h3>Neuen Haushalt erstellen</h3><label>Name</label><input id="hname" value="Unser Vorrat">
<button style="margin-top:12px;width:100%" onclick="createHousehold()">Haushalt erstellen</button>
<div style="height:1px;background:var(--line);margin:22px 0"></div>
<h3>Oder beitreten</h3><label>Einladungscode</label><input id="invite" placeholder="z.B. A1B2C3D4">
<button class="secondary" style="margin-top:12px;width:100%" onclick="joinHousehold()">Mit Code beitreten</button>
</section></main>`;
}
async function createHousehold(){
 try{const {data,error}=await db.rpc("create_household",{household_name:document.getElementById("hname").value.trim()||"Unser Vorrat"});if(error)throw error;household=data?.[0];alert("Haushalt erstellt. Einladungscode: "+household.invite_code);await loadData();renderApp();subscribe();}catch(e){flash(e.message)}
}
async function joinHousehold(){
 try{const {data,error}=await db.rpc("join_household",{code:document.getElementById("invite").value});if(error)throw error;household=data?.[0];await loadData();renderApp();subscribe();}catch(e){flash(e.message)}
}
async function loadData(){
 const [a,b]=await Promise.all([
  db.from("inventory_items").select("*").eq("household_id",household.id).order("mhd",{ascending:true,nullsFirst:false}).order("name"),
  db.from("shopping_items").select("*").eq("household_id",household.id).order("checked").order("name")
 ]);
 if(a.error)throw a.error;if(b.error)throw b.error;items=a.data||[];shopping=b.data||[];
}
let channel;
function subscribe(){
 if(channel)db.removeChannel(channel);
 channel=db.channel("vorrat-"+household.id).on("postgres_changes",{event:"*",schema:"public",table:"inventory_items",filter:"household_id=eq."+household.id},async()=>{await loadData();renderApp()}).on("postgres_changes",{event:"*",schema:"public",table:"shopping_items",filter:"household_id=eq."+household.id},async()=>{await loadData();renderApp()}).subscribe();
}
function renderError(msg){document.getElementById("app").innerHTML=`<main class="auth"><section class="card"><h2>Ups 😕</h2><p>${esc(msg)}</p><button onclick="location.reload()">Neu laden</button></section></main>`}
function renderApp(){
 const urgent=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d<=7}).length;
 const low=items.filter(x=>Number(x.min_qty)>0&&Number(x.qty)<Number(x.min_qty)).length;
 const under3=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d>=0&&d<=3}).length;
 const days47=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d>=4&&d<=7}).length;
 document.getElementById("app").innerHTML=`<div class="uv-app">
   <div class="uv-main">
     ${heroHeader()}
     <div id="flash" class="hidden"></div>
     ${activeTab==='vorrat'?inventoryView():activeTab==='einkauf'?shoppingView():recipeView()}
   </div>
   ${bottomNav()}
 </div>`;
 if(activeTab==='rezepte') setTimeout(renderSmartRecipes,0);
}
function heroHeader(){
 return `<header class="uv-hero">
   <div class="uv-hero-bg"></div>
   <button class="uv-hero-user" aria-label="Abmelden" onclick="logout()">↪</button>
   <button class="uv-hero-settings" aria-label="Abmelden" onclick="logout()">⚙</button>
   <div class="uv-code">${esc(household?.name||'Unser Vorrat')} · Code <b>${esc(household?.invite_code||'')}</b></div>
 </header>`;
}
function bottomNav(){
 return `<nav class="uv-bottom-nav">
   <button class="uv-nav ${activeTab==='vorrat'?'active red':''}" onclick="goTab('vorrat')"><span class="uv-nav-art nav-vorrat"></span><span>Vorrat</span></button>
   <button class="uv-nav ${activeTab==='einkauf'?'active blue':''}" onclick="goTab('einkauf')"><span class="uv-nav-art nav-einkauf"></span><span>Einkauf</span></button>
   <button class="uv-nav ${activeTab==='rezepte'?'active purple':''}" onclick="goTab('rezepte')"><span class="uv-nav-art nav-rezepte"></span><span>Rezepte</span></button>
 </nav>`;
}
function quickGo(kind){
 if(kind==='shopping'){goTab('einkauf');return;}
 activeTab='vorrat'; window._q=''; window._cat=''; window._place=''; window._status=kind; quickFilter=kind; renderApp(); setTimeout(()=>document.getElementById('uv-results')?.scrollIntoView({behavior:'smooth',block:'start'}),50);
}
function inventoryView(){
 const q=window._q||"",cat=window._cat||"",place=window._place||"",status=window._status||"";
 const under3=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d>=0&&d<=3}).length;
 const days47=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d>=4&&d<=7}).length;
 let arr=items.filter(x=>(!q||[x.name,x.barcode,x.note].join(" ").toLowerCase().includes(q.toLowerCase()))&&(!cat||x.category===cat)&&(!place||x.place===place)&&(!status||statusMatch(x,status)));
 arr.sort((a,b)=>{let da=daysTo(a.mhd),db=daysTo(b.mhd);if(da===null)return 1;if(db===null)return -1;return da-db});
 const urgent=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d<=7}).sort((a,b)=>daysTo(a.mhd)-daysTo(b.mhd)).slice(0,8);
 const catsList=cats.map(c=>`<option ${cat===c?'selected':''}>${c}</option>`).join('');
 const placesList=places.map(p=>`<option ${place===p?'selected':''}>${p}</option>`).join('');
 return `<main class="uv-content" id="uv-results">
   <section class="uv-stats">
     <button class="uv-stat stat-blue" onclick="quickGo('')"><img src="assets/stat-article.png"><span>Artikel</span><b>${items.length}</b><i>›</i></button>
     <button class="uv-stat stat-red" onclick="quickGo('0')"><img src="assets/stat-red.png"><span>≤ 3 Tage</span><b>${under3}</b><i>›</i></button>
     <button class="uv-stat stat-orange" onclick="quickGo('4')"><img src="assets/stat-orange.png"><span>4 – 7 Tage</span><b>${days47}</b><i>›</i></button>
     <button class="uv-stat stat-purple" onclick="quickGo('shopping')"><img src="assets/stat-purple.png"><span>Einkauf</span><b>${shopping.filter(x=>!x.checked).length}</b><i>›</i></button>
   </section>
   <section class="uv-search-area">
     <div class="uv-search-row"><div class="uv-search"><span>⌕</span><input placeholder="Artikel, Kategorie oder Marke suchen..." value="${esc(q)}" oninput="window._q=this.value;renderApp()"></div><button class="uv-scan" type="button" onclick="openItem()">▥</button></div>
     <div class="uv-filters"><select onchange="window._cat=this.value;renderApp()"><option value="">Alle Kategorien</option>${catsList}</select><select onchange="window._place=this.value;renderApp()"><option value="">Alle Lagerorte</option>${placesList}</select><select onchange="window._status=this.value;renderApp()"><option value="">⇅ Sortieren</option><option value="0" ${status==='0'?'selected':''}>0–3 Tage</option><option value="4" ${status==='4'?'selected':''}>4–7 Tage</option><option value="8" ${status==='8'?'selected':''}>8–30 Tage</option><option value="expired" ${status==='expired'?'selected':''}>Abgelaufen</option><option value="low" ${status==='low'?'selected':''}>Mindestbestand</option></select></div>
   </section>
   <section class="uv-urgent">
      <div class="uv-urgent-head"><div class="uv-urgent-art"></div><h3>Zuerst verbrauchen</h3><button onclick="window._status='';renderApp()">Alle anzeigen ›</button></div>
      ${urgent.map(itemHtml).join('')||'<div class="uv-empty">Nichts Dringendes 🎉</div>'}
   </section>
   <button class="uv-add" onclick="openItem()"><span>＋</span>Artikel hinzufügen <b>›</b></button>
   <section class="uv-all"><h3>Alle Artikel <em>${arr.length}</em></h3>${arr.map(itemHtml).join('')||'<div class="uv-empty">Noch keine Artikel vorhanden.</div>'}</section>
   <div id="modal"></div>
 </main>`;
}
function statusMatch(x,s){let d=daysTo(x.mhd);if(s==="expired")return d!==null&&d<0;if(s==="0")return d!==null&&d>=0&&d<=3;if(s==="4")return d!==null&&d>=4&&d<=7;if(s==="8")return d!==null&&d>=8&&d<=30;return true}
function itemHtml(x){
 const d=daysTo(x.mhd); const cls=mhdClass(x.mhd); const daysLabel=d===null?'kein MHD':d<0?'abgelaufen':d===0?'heute':d===1?'noch 1 Tag':`noch ${d} Tage`;
 const tone=d!==null&&d<=3?'red':d!==null&&d<=7?'orange':'blue';
 return `<article class="uv-item ${cls}">
   ${x.product_image_url?`<img class="uv-item-img" src="${esc(x.product_image_url)}" alt="" onerror="this.style.display='none'">`:`<div class="uv-item-img uv-no-img">🥫</div>`}
   <div class="uv-item-main"><div class="uv-item-name">${esc(x.name)}</div><div class="uv-item-meta">${esc(x.category)} <span>·</span> ${esc(x.place)}</div><div class="uv-mhd ${tone}">◷ <span>${x.mhd?new Date(x.mhd+'T00:00:00').toLocaleDateString('de-DE'):''}</span></div><div class="uv-days ${tone}">${daysLabel}</div>${x.pending_mhd?'<span class="uv-pending">🟡 Neu eingekauft</span>':''}</div>
   <div class="uv-item-actions"><div class="uv-qty"><button onclick="changeQty(${x.id},-1)">−</button><b>${esc(x.qty)}</b><button onclick="changeQty(${x.id},1)">+</button></div><div class="uv-edit"><button onclick="openItem(${x.id})">✎</button><button onclick="removeItem(${x.id})">♜</button></div></div>
   <span class="uv-item-arrow">›</span>
 </article>`;
}
function shoppingView(){return `<div class="row"><input id="newShop" placeholder="Was fehlt?"><input id="newShopQty" type="number" min="0.01" step="0.01" value="1" style="max-width:110px"><select id="newShopUnit" style="max-width:150px">${units.map(u=>`<option ${u==='Stk.'?'selected':''}>${u}</option>`).join('')}</select><button onclick="addShopping()">＋ Hinzufügen</button></div><div style="margin-top:15px">${shopping.map(x=>`<div class="item"><div style="flex:1"><input type="checkbox" style="width:auto" ${x.checked?'checked':''} onchange="toggleShopping(${x.id},this.checked)"> ${x.checked?'<s>':''}<b>${esc(x.name)}</b>${x.checked?'</s>':''}<div class="row" style="margin-top:8px"><input type="number" min="0.01" step="0.01" value="${esc(x.qty??1)}" style="max-width:100px" onchange="updateShoppingQty(${x.id},this.value)"><select style="max-width:150px" onchange="updateShoppingUnit(${x.id},this.value)">${units.map(u=>`<option ${((x.unit||'Stk.')===u)?'selected':''}>${u}</option>`).join('')}</select></div></div><button class="danger" onclick="deleteShopping(${x.id})">🗑</button></div>`).join("")||'<div class="empty">Einkaufsliste ist leer.</div>'}</div>`}
function recipeView(){return `<section id="recipeList" class="card" style="margin-top:18px"><h2>🍳 Was kochen wir heute?</h2><p class="muted">Die Vorschläge passen sich eurem aktuellen Vorrat an. Von 🇮🇹 Italienisch über 🇯🇵 Japanisch und 🇰🇷 Koreanisch bis 🇬🇷 Griechisch und mehr.</p><div class="muted">Rezepte werden geladen …</div></section>`}
function openDatePicker(el){
  if(!el) return;
  try{
    if(typeof el.showPicker === "function"){ el.showPicker(); return; }
  }catch(e){}
  el.focus();
  try{ el.click(); }catch(e){}
}
function openItem(id=null){
 editing=id?items.find(x=>x.id===id):null;
 currentProductImage=editing?.product_image_url||null;
 const unitList=editing?.unit&&!units.includes(editing.unit)?[editing.unit,...units]:units;
 const firstQty=editing?.qty??1;
 const firstMhd=editing?.mhd||'';
 document.getElementById("modal").innerHTML=`<div class="modal"><section class="card"><h2>${editing?'Artikel bearbeiten':'Artikel hinzufügen'}</h2><div id="mflash" class="hidden"><span></span></div>
<label>Name</label><input id="iname" value="${esc(editing?.name)}">
<label>Einheit</label><select id="iunit" aria-label="Einheit">${unitList.map(u=>`<option value="${esc(u)}" ${editing?.unit===u||( !editing?.unit && u==="Stk.")?"selected":""}>${esc(u)}</option>`).join("")}</select>
<label>Kategorie</label><select id="icat">${cats.map(c=>`<option ${editing?.category===c?'selected':''}>${c}</option>`).join("")}</select>
<label>Lagerort</label><select id="iplace">${places.map(p=>`<option ${editing?.place===p?'selected':''}>${p}</option>`).join("")}</select>
<label>Mindestbestand</label><input id="imin" type="number" step="0.01" value="${editing?.min_qty??0}">
<label>EAN / Barcode</label>
<div class="product-lookup"><input id="ibar" inputmode="numeric" value="${esc(editing?.barcode)}" placeholder="z. B. 4001234567890"><button type="button" class="secondary barcode-btn" onclick="lookupProductByEAN()">🔎 Produkt suchen</button></div>
<div class="row" style="margin-top:8px"><button type="button" class="secondary" onclick="startBarcodeScanner()">📷 Barcode scannen</button></div>
<div id="productLookupResult">${editing?.product_image_url?`<div class="product-preview"><img src="${esc(editing.product_image_url)}" alt="Produktbild"><div class="product-info"><div class="product-name">Gespeichertes Produktbild</div><div class="lookup-status">Produktdaten können aus eurer eigenen Datenbank geladen werden.</div></div></div>`:""}</div>
<label style="display:flex;align-items:center;gap:8px;margin-top:10px"><input id="isaveproduct" type="checkbox" style="width:auto" ${editing?.barcode?'checked':''}> Dieses Produkt mit EAN in unserer Produktdatenbank merken</label>
<label>Notiz</label><textarea id="inote">${esc(editing?.note)}</textarea>
<div style="margin-top:18px"><h3 style="margin-bottom:6px">📦 Mengen & MHD</h3><p class="muted" style="margin-top:0">Wenn derselbe Artikel mehrere unterschiedliche MHDs hat, kannst du die Chargen hier auf einmal erfassen.</p><div id="chargeRows"></div><button type="button" class="secondary" onclick="addChargeRow()">＋ Weitere Charge mit anderem MHD</button></div>
<div class="row" style="margin-top:16px"><button onclick="saveItem()">Speichern</button><button class="secondary" onclick="document.getElementById('modal').innerHTML=''">Abbrechen</button></div>
</section></div>`;
 addChargeRow(firstQty,firstMhd);
}
function addChargeRow(qty=1,mhd=''){
 const wrap=document.getElementById('chargeRows');
 if(!wrap)return;
 const row=document.createElement('div');
 row.className='charge-row';
 row.style.cssText='display:grid;grid-template-columns:minmax(90px,0.8fr) minmax(150px,1.2fr) auto;gap:10px;align-items:end;margin:10px 0;padding:12px;border:1px solid rgba(0,120,220,.25);border-radius:14px;background:rgba(0,0,0,.12)';
 const index=wrap.children.length+1;
 row.innerHTML=`<div><label style="margin-top:0">Menge ${index}</label><input class="charge-qty" type="number" min="0.01" step="0.01" value="${esc(qty)}"></div><div><label style="margin-top:0">MHD ${index}</label><div class="date-wrap"><input class="charge-mhd" type="date" value="${esc(mhd)}" onclick="openDatePicker(this)" onkeydown="if(event.key==='Enter'){openDatePicker(this)}"><button type="button" class="secondary date-btn" onclick="openDatePicker(this.parentElement.querySelector('.charge-mhd'))">📅</button></div></div><button type="button" class="danger" onclick="this.parentElement.remove();renumberChargeRows()" style="height:46px">🗑</button>`;
 wrap.appendChild(row);
}
function renumberChargeRows(){document.querySelectorAll('#chargeRows .charge-row').forEach((row,i)=>{row.querySelectorAll('label').forEach((l,j)=>{l.textContent=j===0?`Menge ${i+1}`:`MHD ${i+1}`})})}

let barcodeScanner=null;
let barcodeScannerRunning=false;
let barcodeStream=null;
let nativeBarcodeDetector=null;
let nativeScanTimer=null;

function stopCameraStream(){
  if(nativeScanTimer){ clearInterval(nativeScanTimer); nativeScanTimer=null; }
  if(barcodeStream){
    barcodeStream.getTracks().forEach(t=>t.stop());
    barcodeStream=null;
  }
  const video=document.getElementById("barcode-video");
  if(video){ try{video.pause();}catch(e){} video.srcObject=null; }
}

function closeBarcodeScanner(){
  stopCameraStream();
  if(barcodeScanner && barcodeScannerRunning){
    barcodeScanner.stop().catch(()=>{}).finally(()=>{
      try{barcodeScanner.clear()}catch(e){}
      barcodeScanner=null;
      barcodeScannerRunning=false;
    });
  }else{
    try{if(barcodeScanner) barcodeScanner.clear()}catch(e){}
    barcodeScanner=null;
    barcodeScannerRunning=false;
  }
  const modal=document.getElementById("barcodeModal");
  if(modal) modal.remove();
}

function scannerErrorMessage(err){
  const n=err?.name||"";
  if(n==="NotAllowedError" || n==="PermissionDeniedError")
    return "Chrome hat den Kamerazugriff verweigert. Bitte die Kamera-Berechtigung für diese Website erlauben.";
  if(n==="NotFoundError")
    return "Keine Kamera gefunden.";
  if(n==="NotReadableError")
    return "Die Kamera wird gerade von einer anderen App verwendet.";
  if(n==="SecurityError")
    return "Der Kamerazugriff wurde aus Sicherheitsgründen blockiert. Öffne die App über die HTTPS-Netlify-Adresse.";
  return "Kamera konnte nicht gestartet werden.";
}

async function startNativeBarcodeCamera(){
  const video=document.getElementById("barcode-video");
  const status=document.getElementById("barcode-status");
  if(!video) throw new Error("Kameraansicht nicht gefunden.");

  // Ask for the camera directly from the user's Scan button.
  // No geolocation request is made anywhere in the scanner.
  if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
    throw new Error("Dieser Browser unterstützt keinen direkten Kamerazugriff.");
  }

  barcodeStream=await navigator.mediaDevices.getUserMedia({
    audio:false,
    video:{facingMode:{ideal:"environment"}, width:{ideal:1280}, height:{ideal:720}}
  });

  video.srcObject=barcodeStream;
  await video.play();

  if(!("BarcodeDetector" in window)){
    status.textContent="Kamera läuft. Automatische Erkennung wird von diesem Browser nicht unterstützt. Bitte EAN unten eingeben.";
    return;
  }

  let formats=["ean_13","ean_8","upc_a","upc_e","code_128","code_39"];
  try{
    const supported=await BarcodeDetector.getSupportedFormats();
    formats=formats.filter(f=>supported.includes(f));
  }catch(e){}
  if(!formats.length){
    status.textContent="Kamera läuft. Dieser Browser unterstützt die benötigten Barcode-Formate nicht.";
    return;
  }

  nativeBarcodeDetector=new BarcodeDetector({formats});
  status.textContent="Kamera läuft – Barcode vor die Kamera halten …";

  nativeScanTimer=setInterval(async()=>{
    if(!video.videoWidth || !video.videoHeight || !nativeBarcodeDetector) return;
    try{
      const codes=await nativeBarcodeDetector.detect(video);
      if(codes && codes.length){
        const value=codes[0].rawValue;
        if(value){
          const input=document.getElementById("ibar");
          if(input) input.value=value;
          status.textContent="Barcode erkannt: "+value;
          setTimeout(closeBarcodeScanner,250);
        }
      }
    }catch(e){}
  },180);
}

async function startBarcodeScanner(){
  if(document.getElementById("barcodeModal")) return;

  const modal=document.createElement("div");
  modal.id="barcodeModal";
  modal.className="modal";
  modal.innerHTML=`<div class="card">
    <h2>Barcode scannen</h2>
    <div class="scanner-box"><video id="barcode-video" autoplay playsinline muted></video></div>
    <div id="barcode-status" class="scan-hint">Kamera wird gestartet …</div>
    <div class="scan-hint">Halte den EAN-Strichcode in den Rahmen.</div>
    <div class="row" style="margin-top:14px">
      <button type="button" class="secondary" onclick="closeBarcodeScanner()">Abbrechen</button>
    </div>
  </div>`;
  document.body.appendChild(modal);

  try{
    // Native getUserMedia is intentionally used first. This avoids the
    // html5-qrcode permission/device-enumeration flow that caused the
    // Android/Chrome permission dialog in the previous build.
    await startNativeBarcodeCamera();
  }catch(err){
    console.error("Barcode camera error:",err);
    stopCameraStream();
    const status=document.getElementById("barcode-status");
    if(status){
      status.innerHTML=`<div class="error">${esc(scannerErrorMessage(err))}<br><small>${esc(err?.message||"")}</small></div>`;
    }
  }
}

function normalizeBarcode(v){return String(v||'').replace(/\D/g,'');}
function deriveUnitFromQuantity(q){
  const t=String(q||'').toLowerCase().replace(',', '.');
  if(/\bkg\b/.test(t)) return 'kg';
  if(/\bg\b/.test(t)) return 'g';
  if(/\bl\b/.test(t)) return 'l';
  if(/\bml\b/.test(t)) return 'ml';
  if(/\bcl\b/.test(t)) return 'cl';
  if(/\d+\s*(stk|stück|pieces|pcs)\b/.test(t)) return 'Stk.';
  return null;
}
function mapCatalogCategory(raw){
  const t=String(raw||'').toLowerCase();
  if(/wurst|fleisch|meat|sausage|schinken|ham|salami|würst/.test(t)) return 'Fleisch';
  if(/tiefkühl|frozen/.test(t)) return 'Tiefkühl';
  if(/milch|käse|joghurt|quark|dairy|cheese|yogurt/.test(t)) return 'Kühlung';
  if(/getränk|beverage|drink|wasser|saft|cola|bier|wein/.test(t)) return 'Getränke';
  if(/nudel|pasta|reis|rice/.test(t)) return 'Nudeln & Reis';
  if(/konserve|canned|canning|dose/.test(t)) return 'Konserven';
  if(/süß|schokolade|keks|cookie|snack|candy|chocolate/.test(t)) return 'Süßes & Snacks';
  if(/gewürz|spice|herb/.test(t)) return 'Gewürze';
  if(/back|mehl|flour|baking/.test(t)) return 'Backen';
  return 'Sonstiges';
}
function showProductPreview(product,imageUrl,source='Eure Produktdatenbank',statusText='Produkt gefunden'){
  const box=document.getElementById('productLookupResult');
  if(!box)return;
  const brand=product.brand?` · ${esc(product.brand)}`:(product.brands?` · ${esc(product.brands)}`:'');
  const qty=product.quantity?` · ${esc(product.quantity)}`:'';
  box.innerHTML=`<div class="product-preview">${imageUrl?`<img src="${esc(imageUrl)}" alt="Produktbild" onerror="this.style.display='none'">`:''}<div class="product-info"><div class="product-name">${esc(product.name||product.product_name||'Produkt gefunden')}${brand}</div><div class="lookup-status">${esc(statusText)} · ${esc(source)}${qty}</div></div></div>`;
}
async function lookupProductByEAN(){
  const input=document.getElementById('ibar');
  const statusBox=document.getElementById('productLookupResult');
  const code=normalizeBarcode(input?.value);
  if(!code){ alert('Bitte zuerst eine EAN eingeben.'); return; }
  if(input) input.value=code;
  if(statusBox) statusBox.innerHTML='<div class="lookup-status">🔎 Eure Produktdatenbank wird durchsucht …</div>';
  currentProductImage=null;
  currentProductData=null;
  try{
    const {data,error}=await db.from('products').select('ean,name,brand,category,unit,quantity,image_url').eq('household_id',household.id).eq('ean',code).maybeSingle();
    if(error)throw error;
    if(data){
      currentProductData=data;
      currentProductImage=data.image_url||null;
      document.getElementById('iname').value=data.name||'';
      if(data.unit && document.getElementById('iunit')) document.getElementById('iunit').value=data.unit;
      if(data.category && document.getElementById('icat')) document.getElementById('icat').value=data.category;
      const cb=document.getElementById('isaveproduct'); if(cb) cb.checked=true;
      showProductPreview(data,data.image_url,'Eure Produktdatenbank','✓ Produkt automatisch gefunden');
      return;
    }
    const cb=document.getElementById('isaveproduct'); if(cb) cb.checked=true;
    if(statusBox) statusBox.innerHTML='<div class="lookup-status">🆕 Diese EAN ist bei euch noch nicht gespeichert. Nach dem Ausfüllen wird sie automatisch in eurer Produktdatenbank gemerkt.</div>';
  }catch(err){
    console.warn('Eigene Produktdatenbank lookup failed',err);
    if(statusBox) statusBox.innerHTML='<div class="error">❌ Die Produktdatenbank konnte nicht abgefragt werden. Bitte Supabase-Migration und Verbindung prüfen.</div>';
  }
}
async function saveProductToCatalog(base){
  const cb=document.getElementById('isaveproduct');
  const ean=normalizeBarcode(base.barcode||'');
  if(!cb?.checked || !ean || !base.name) return;
  const payload={household_id:household.id,ean,name:base.name,brand:currentProductData?.brand||null,category:base.category||null,unit:base.unit||null,quantity:currentProductData?.quantity||null,image_url:currentProductImage||null,created_by:user.id};
  const {error}=await db.from('products').upsert(payload,{onConflict:'household_id,ean'});
  if(error) console.warn('Produkt konnte nicht im Katalog gespeichert werden',error);
}

async function saveItem(){
 try{
  const name=document.getElementById("iname").value.trim();
  if(!name)throw Error("Name fehlt.");
  const rows=[...document.querySelectorAll('#chargeRows .charge-row')];
  if(!rows.length)throw Error("Mindestens eine Charge anlegen.");
  const base={household_id:household.id,user_id:user.id,name,unit:document.getElementById("iunit").value.trim()||"Stk.",category:document.getElementById("icat").value,place:document.getElementById("iplace").value,min_qty:Number(document.getElementById("imin").value||0),barcode:document.getElementById("ibar").value.trim()||null,product_image_url:currentProductImage||null,note:document.getElementById("inote").value.trim()||null};
  const charges=rows.map(row=>({qty:Number(row.querySelector('.charge-qty').value||0),mhd:row.querySelector('.charge-mhd').value||null}));
  if(charges.some(c=>c.qty<=0))throw Error("Die Menge muss größer als 0 sein.");
  if(editing){
    const first=charges[0];
    const obj={...base,...first};
    if(editing.pending_mhd && obj.mhd){obj.pending_mhd=false;if(obj.note==='🟡 Neu eingekauft – MHD eintragen')obj.note=null;}
    let r=await db.from("inventory_items").update(obj).eq("id",editing.id);if(r.error)throw r.error;
    if(charges.length>1){
      const extras=charges.slice(1).map(c=>({...base,...c,pending_mhd:false}));
      const r2=await db.from("inventory_items").insert(extras);if(r2.error)throw r2.error;
    }
  }else{
    const records=charges.map(c=>({...base,...c,pending_mhd:false}));
    const r=await db.from("inventory_items").insert(records);if(r.error)throw r.error;
  }
  await saveProductToCatalog(base);
  document.getElementById("modal").innerHTML="";await loadData();renderApp()
 }catch(e){alert(e.message)}
}
async function changeQty(id,delta){const x=items.find(i=>i.id===id);if(!x)return;const qty=Math.max(0,Number(x.qty)+delta);if(qty===0){await removeItem(id);return}const {error}=await db.from("inventory_items").update({qty}).eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function removeItem(id){if(!confirm("Artikel wirklich löschen?"))return;const {error}=await db.from("inventory_items").delete().eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function addShopping(){const el=document.getElementById("newShop"),name=el.value.trim();if(!name)return;const qty=Math.max(0.01,Number(document.getElementById("newShopQty")?.value||1));const unit=document.getElementById("newShopUnit")?.value||"Stk.";const {error}=await db.from("shopping_items").insert({household_id:household.id,user_id:user.id,name,qty,unit});if(error)flash(error.message);else{el.value="";document.getElementById("newShopQty").value=1;await loadData();renderApp()}}
async function updateShoppingQty(id,value){const qty=Math.max(0.01,Number(value||1));const {error}=await db.from("shopping_items").update({qty}).eq("id",id);if(error)flash(error.message);else await loadData()}
async function updateShoppingUnit(id,unit){const {error}=await db.from("shopping_items").update({unit}).eq("id",id);if(error)flash(error.message);else await loadData()}
async function toggleShopping(id,checked){
 const shop=shopping.find(x=>x.id===id);
 if(!shop)return;
 if(!checked){
   if(shop.inventory_item_id){
     const linked=items.find(x=>x.id===shop.inventory_item_id);
     if(linked && linked.pending_mhd && !linked.mhd){
       const {error:delError}=await db.from("inventory_items").delete().eq("id",shop.inventory_item_id);
       if(delError){flash(delError.message);return;}
     }
   }
   const {error}=await db.from("shopping_items").update({checked:false,inventory_item_id:null}).eq("id",id);
   if(error)flash(error.message);else{await loadData();renderApp()}
   return;
 }
 // Erst beim Abhaken wird der Einkauf als vorläufiger Bestand übernommen.
 const qty=Math.max(0.01,Number(shop.qty||1));
 const unit=shop.unit||"Stk.";
 const {data:inv,error:invError}=await db.from("inventory_items").insert({
   household_id:household.id,user_id:user.id,name:shop.name,qty,unit,mhd:null,
   category:"Sonstiges",place:"Vorratsregal",min_qty:0,barcode:null,
   note:"🟡 Neu eingekauft – MHD eintragen",pending_mhd:true
 }).select("id").single();
 if(invError){flash(invError.message);return;}
 const {error}=await db.from("shopping_items").update({checked:true,inventory_item_id:inv.id}).eq("id",id);
 if(error){
   await db.from("inventory_items").delete().eq("id",inv.id);
   flash(error.message);
 }else{await loadData();renderApp()}
}
async function deleteShopping(id){const {error}=await db.from("shopping_items").delete().eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function logout(){await db.auth.signOut()}
init();
