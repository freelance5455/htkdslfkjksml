const KEY='tavars_v13_data';
const AUTH_KEY='tavars_auth_v1';
const SESSION_KEY='tavars_session_v1';
const THEME_KEY='tavars_theme';
const ATT_DB='tavars_media_v1';
const ATT_STORE='files';

const defaultData={cash:0,stock:[],sales:[],expenses:[],repairs:[],debts:[],buy:[],history:[],sms:[],userName:''};
function cloneDefault(){return JSON.parse(JSON.stringify(defaultData));}
function toNum(v,fallback=0){const n=Number(v);return Number.isFinite(n)?n:fallback;}
function uid(prefix='id'){
  try{return `${prefix}_${crypto.randomUUID()}`}
  catch(e){return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,10)}`}
}
function money(n){return new Intl.NumberFormat('uz-UZ').format(toNum(n,0))+' soʻm'}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function now(){return Date.now()}

function migrateSale(x,i){
  const legacyName=String(x?.name||'').trim();
  let items=Array.isArray(x?.items)?x.items.map(it=>({name:String(it?.name||'').trim(),q:Math.max(1,Math.floor(toNum(it?.q,1))),price:Math.max(0,toNum(it?.price,0)),cost:Math.max(0,toNum(it?.cost,0))})).filter(it=>it.name):[];
  if(!items.length && legacyName){
    const q=Math.max(1,Math.floor(toNum(x?.q,1))); const total=Math.max(0,toNum(x?.total,0)); const unit= q?total/q:0;
    items=[{name:legacyName,q,price:unit,cost:Math.max(0,toNum(x?.costPerUnit,0))}];
  }
  const total=items.reduce((s,it)=>s+it.price*it.q,0);
  const costTotal=items.reduce((s,it)=>s+it.cost*it.q,0);
  const paid=Math.max(0,toNum(x?.paid,total));
  return {...x,id:x?.id||uid('sale'),receiptNo:Number.isFinite(Number(x?.receiptNo))?Number(x.receiptNo):(i+1),items, name:items.map(it=>it.name).join(', '),q:items.reduce((s,it)=>s+it.q,0),total:Math.max(total,toNum(x?.total,0)),costTotal:toNum(x?.costTotal,costTotal),paid,profit:toNum(x?.profit,total-costTotal),date:toNum(x?.date,now())};
}
function stockKey(name){return String(name??'').trim().toLocaleLowerCase('uz-UZ').replace(/\s+/g,' ')}
function normalizeStock(items){
  const map=new Map(), out=[];
  for(const raw of Array.isArray(items)?items:[]){
    const name=String(raw?.name||'').trim().replace(/\s+/g,' ');
    const qty=Math.max(0,Math.floor(toNum(raw?.qty,0)));
    if(!name||qty<=0)continue;
    const item={id:raw?.id||uid('stk'),name,price:Math.max(0,toNum(raw?.price,0)),qty,cost:Math.max(0,toNum(raw?.cost,0))};
    const key=stockKey(name);
    const idx=map.get(key);
    if(idx===undefined){map.set(key,out.length);out.push(item)}
    else{
      const existing=out[idx];
      existing.qty+=item.qty;
      existing.price=item.price;
      existing.cost=item.cost;
    }
  }
  return out;
}
function readDb(){
  let raw=null; try{raw=JSON.parse(localStorage.getItem(KEY)||'null')}catch(e){raw=null}
  const d=(raw&&typeof raw==='object')?{...cloneDefault(),...raw}:cloneDefault();
  for(const k of ['stock','sales','expenses','repairs','debts','buy','history','sms'])if(!Array.isArray(d[k]))d[k]=[];
  d.cash=toNum(d.cash,0); d.userName=typeof d.userName==='string'?d.userName:'';
  d.stock=normalizeStock(d.stock);
  d.sales=d.sales.map(migrateSale);
  d.expenses=d.expenses.map(x=>({...x,id:x?.id||uid('exp'),amount:Math.max(0,toNum(x?.amount,0)),desc:String(x?.desc||''),date:toNum(x?.date,now())})).filter(x=>x.amount>0);
  d.repairs=d.repairs.map(x=>({...x,id:x?.id||uid('rep'),amount:Math.max(0,toNum(x?.amount,0)),desc:String(x?.desc||'Remont'),date:toNum(x?.date,now())})).filter(x=>x.amount>0);
  d.debts=d.debts.map(x=>({...x,id:x?.id||uid('debt'),name:String(x?.name||'').trim(),amount:Math.max(0,toNum(x?.amount,0)),date:toNum(x?.date,now())})).filter(x=>x.name&&x.amount>0);
  d.buy=d.buy.map(x=>({...x,id:x?.id||uid('buy'),name:String(x?.name||'').trim(),price:Math.max(0,toNum(x?.price,0)),cost:Math.max(0,toNum(x?.cost,0)),date:toNum(x?.date,now())})).filter(x=>x.name);
  d.sms=d.sms.map(x=>({...x,id:x?.id||uid('sms'),from:String(x?.from||'User').slice(0,60),to:String(x?.to||'Admin').slice(0,60),text:String(x?.text||''),date:toNum(x?.date,now()),read:!!x?.read,attachment:x?.attachment||null})).filter(x=>x.text||x.attachment);
  return d;
}
let db=readDb();
function save(){try{localStorage.setItem(KEY,JSON.stringify(db));return true}catch(e){alert('Maʼlumotni saqlashda xato yuz berdi. Katta video/faylni qayta yuboring yoki kichikroq fayl tanlang.');return false}}

const session=()=>{try{return JSON.parse(sessionStorage.getItem(SESSION_KEY)||'null')}catch(e){return null}};
const role=()=>session()?.role||null; const isAdmin=()=>role()==='admin';
let loginRole='admin'; let cart=[]; let mediaRecorder=null; let recordChunks=[];

function getAuth(){
  let auth=null; try{auth=JSON.parse(localStorage.getItem(AUTH_KEY)||'null')}catch(e){auth=null}
  if(!auth||auth.schema!=='secure-login-2'||typeof auth.adminPassword!=='string'||!auth.adminPassword){auth={schema:'secure-login-2',adminPassword:'parol'};localStorage.setItem(AUTH_KEY,JSON.stringify(auth))}
  return auth;
}
function setAuth(auth){localStorage.setItem(AUTH_KEY,JSON.stringify(auth))}
function selectLoginRole(r){
  loginRole=r; document.querySelector('#adminRole')?.classList.toggle('active',r==='admin'); document.querySelector('#userRole')?.classList.toggle('active',r==='user');
  const p=document.querySelector('#loginPassword'),u=document.querySelector('#userName');
  if(p){p.classList.toggle('hidden',r!=='admin');p.value='';}
  if(u){u.classList.toggle('hidden',r!=='user');u.value=db.userName||'';}
  const hint=document.querySelector('#loginHint'); if(hint)hint.textContent=r==='admin'?'Admin uchun faqat parol kerak.':'User uchun faqat ism kerak. Ism tahrir qilinmaguncha saqlanadi.';
}
function loginWithPassword(){
  if(loginRole==='admin'){
    const p=document.querySelector('#loginPassword')?.value||''; if(p!==getAuth().adminPassword){alert('Admin paroli notoʻgʻri.');return}
    sessionStorage.setItem(SESSION_KEY,JSON.stringify({role:'admin',name:'Admin',loginAt:now()})); showMain(); page('home'); return;
  }
  const name=(document.querySelector('#userName')?.value||'').trim(); if(!name)return alert('Ismingizni kiriting.');
  if(db.userName!==name){db.userName=name;save()}
  sessionStorage.setItem(SESSION_KEY,JSON.stringify({role:'user',name,loginAt:now()})); showMain(); page('products');
}
function showMain(){document.querySelector('#login')?.classList.add('hidden');document.querySelector('#main')?.classList.remove('hidden')}
function showLogin(){sessionStorage.removeItem(SESSION_KEY);document.querySelector('#main')?.classList.add('hidden');document.querySelector('#login')?.classList.remove('hidden');selectLoginRole(loginRole)}
function logout(){if(confirm('Tizimdan chiqilsinmi?')){closeModal();cart=[];showLogin()}}

const ADMIN_PAGES=new Set(['home','stock','sell','finance','more','reports','debts','buylist','repairs','sms']);
const USER_PAGES=new Set(['products','recent','sms','more']);
function canOpen(p){return isAdmin()?ADMIN_PAGES.has(p):USER_PAGES.has(p)}
function page(p){
  if(!session()){showLogin();return}
  if(!canOpen(p)){alert('Bu bo‘limga kirish huquqi yoʻq.');return page(isAdmin()?'home':'products')}
  if(p!=='sell' && cart.length && isAdmin()){cart=[]}
  const map={home,stock,sell,finance,more,products,recent,reports,debts,buylist,repairs,sms};
  const c=document.querySelector('#content'); if(!c)return;
  c.innerHTML=(map[p]||(isAdmin()?home:products))();
  document.querySelector('#roleLabel').textContent=isAdmin()?'Admin panel':'User panel'; renderNav(p); window.scrollTo({top:0,behavior:'smooth'});
  if(p==='sms')hydrateChatAttachments();
}
function renderNav(active){
  const nav=document.querySelector('#bottomNav'); if(!nav)return; nav.classList.toggle('user-nav',!isAdmin());
  if(isAdmin()) nav.innerHTML=`<button data-page="home" onclick="page('home')">⌂<span>Bosh</span></button><button data-page="stock" onclick="page('stock')">▣<span>Ombor</span></button><button data-page="sell" onclick="page('sell')">＋<span>Sotuv</span></button><button data-page="finance" onclick="page('finance')">◈<span>Moliya</span></button><button data-page="more" onclick="page('more')">⋮<span>Menu</span></button>`;
  else nav.innerHTML=`<button data-page="products" onclick="page('products')">▣<span>Bor</span></button><button data-page="recent" onclick="page('recent')">◷<span>Yaqinda</span></button><button data-page="sms" onclick="page('sms')">✉<span>SMS</span></button><button data-page="more" onclick="page('more')">⋮<span>Menu</span></button>`;
  nav.querySelectorAll('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===active));
}

function totals(){
  const salesRevenue=db.sales.reduce((s,x)=>s+toNum(x.total),0); const cashSales=db.sales.reduce((s,x)=>s+toNum(x.paid),0); const cost=db.sales.reduce((s,x)=>s+toNum(x.costTotal),0); const expenses=db.expenses.reduce((s,x)=>s+toNum(x.amount),0); const repairs=db.repairs.reduce((s,x)=>s+toNum(x.amount),0);
  return {salesRevenue,cashSales,cost,expenses,repairs,salesProfit:salesRevenue-cost,repairProfit:repairs,profit:salesRevenue-cost+repairs-expenses};
}
function home(){const t=totals();return `<div class="hero glass"><span class="tag">ADMIN PANEL • SECURE</span><h2>Xush kelibsiz, Admin 👋</h2><p class="muted">Boshqaruv funksiyalari faqat Admin sessiyasida mavjud.</p></div><div class="grid"><div class="stat glass"><span class="muted">Menda bor pul</span><b>${money(db.cash)}</b></div><div class="stat glass"><span class="muted">Sotuv tushumi</span><b class="green">${money(t.salesRevenue)}</b></div><div class="stat glass"><span class="muted">Tannarx</span><b>${money(t.cost)}</b></div><div class="stat glass"><span class="muted">Aniq foyda</span><b class="green">${money(t.profit)}</b></div></div><div class="card glass"><div class="row"><b>Tezkor amallar</b><span class="tag">Admin</span></div><div class="actions"><button class="small-btn" onclick="addStock()">＋ Mahsulot</button><button class="small-btn" onclick="page('sell')">＋ Sotuv</button><button class="small-btn" onclick="expenseModal()">− Xarajat</button><button class="small-btn" onclick="repairModal()">🔧 Remont</button><button class="small-btn" onclick="page('sms')">✉ SMS</button></div></div>`}

function products(){
  const name=esc(session()?.name||db.userName||'User'); const unread=unreadCount();
  return `<div class="hero glass"><span class="tag">USER PANEL • BOR MAHSULOTLAR</span><h2>Salom, ${name} 👋</h2><p class="muted">Sotuvda mavjud mahsulotlar va narxlar.</p></div><div class="search-box glass"><span>⌕</span><input id="productsSearch" placeholder="Mahsulot qidirish..." oninput="filterUserProducts(this.value)"><button class="small-btn" onclick="clearUserSearch('productsSearch',filterUserProducts)">Tozalash</button></div><div id="userProducts">${renderUserProducts(db.stock.filter(x=>x.qty>0))}</div><div class="card glass"><div class="row"><b>✉ Xabarlar</b><button class="small-btn" onclick="page('sms')">SMS ${unread?`<span class="badge">${unread}</span>`:''}</button></div></div>`;
}
function renderUserProducts(list){if(!list.length)return '<div class="empty">Mos mahsulot topilmadi.</div>';return list.map(x=>`<div class="card glass user-product"><div class="row"><div><b>${esc(x.name)}</b><div class="muted">Sotuv narxi: ${money(x.price)}${x.cost?` • Kelish: ${money(x.cost)}`:''}</div></div><span class="tag">${x.qty} dona</span></div></div>`).join('')}
function filterUserProducts(q){const t=String(q||'').trim().toLocaleLowerCase('uz-UZ');const list=db.stock.filter(x=>x.qty>0&&(x.name||'').toLocaleLowerCase('uz-UZ').includes(t));const box=document.querySelector('#userProducts');if(box)box.innerHTML=renderUserProducts(list)}
function clearUserSearch(id,fn){const i=document.querySelector('#'+id);if(i)i.value='';fn('')}

function recent(){
  const unread=unreadCount(); return `<div class="hero glass"><span class="tag">USER PANEL • YAQINDA</span><h2>Yaqinda 🕘</h2><p class="muted">Admin supplierdan olib kelishni rejalashtirgan mahsulotlar.</p></div><div class="search-box glass"><span>⌕</span><input id="recentSearch" placeholder="Yaqinda qidirish..." oninput="filterRecent(this.value)"><button class="small-btn" onclick="clearUserSearch('recentSearch',filterRecent)">Tozalash</button></div><div id="recentList">${renderRecent(db.buy)}</div><div class="card glass"><div class="row"><b>✉ SMS</b><button class="small-btn" onclick="page('sms')">Xabarlarga o'tish ${unread?`<span class="badge">${unread}</span>`:''}</button></div></div>`;
}
function renderRecent(list){const arr=list.slice().sort((a,b)=>b.date-a.date);return arr.length?arr.map(x=>`<div class="card glass"><div class="row"><div><b>${esc(x.name)}</b><div class="muted">Taxminiy kelish narxi: ${money(x.cost||x.price)}</div></div><span class="tag">${new Date(x.date).toLocaleDateString('uz-UZ')}</span></div></div>`).join(''):'<div class="empty">Yaqinda ro‘yxati bo‘sh.</div>'}
function filterRecent(q){const t=String(q||'').trim().toLocaleLowerCase('uz-UZ');const list=db.buy.filter(x=>(x.name||'').toLocaleLowerCase('uz-UZ').includes(t));const box=document.querySelector('#recentList');if(box)box.innerHTML=renderRecent(list)}

function stock(){return `<div class="hero glass"><h2>Ombor 📦</h2><p class="muted">Har bir mahsulotda sotuv narxi va kelish/tannarx saqlanadi.</p><button class="primary" onclick="addStock()">＋ Mahsulot qo‘shish</button></div><div class="search-box glass"><span>⌕</span><input id="adminStockSearch" placeholder="Ombordan qidirish..." oninput="filterAdminStock(this.value)"></div><div id="adminStockList">${renderAdminStock(db.stock)}</div>`}
function renderAdminStock(list){return list.length?list.map(x=>`<div class="card glass"><div class="row"><div><b>${esc(x.name)}</b><div class="muted">Sotuv: ${money(x.price)} • Kelish: ${money(x.cost)}</div></div><span class="tag">${x.qty} dona</span></div><div class="actions"><button class="small-btn" onclick="editStockById('${x.id}')">Tahrirlash</button><button class="small-btn danger" onclick="removeStockById('${x.id}')">O‘chirish</button></div></div>`).join(''):'<div class="empty">Ombor bo‘sh.</div>'}
function filterAdminStock(q){const t=String(q||'').trim().toLocaleLowerCase('uz-UZ');const box=document.querySelector('#adminStockList');if(box)box.innerHTML=renderAdminStock(db.stock.filter(x=>(x.name||'').toLocaleLowerCase('uz-UZ').includes(t)))}

function sell(){
  const available=db.stock.filter(x=>x.qty>0); const count=cart.reduce((s,x)=>s+x.q,0); const totalsCart=cartTotals();
  return `<div class="hero glass"><div class="row"><div><h2>Sotuv 🛒</h2><p class="muted">Mahsulotlarni <b>+ / −</b> bilan bittalab tanlang. Eski versiyadagi kabi savatcha yig‘iladi.</p></div><span class="tag">${count} dona</span></div></div><div class="search-box glass"><span>⌕</span><input id="sellSearch" placeholder="Mahsulot qidirish..." oninput="filterSellProducts(this.value)"></div><div id="sellProducts">${renderSellProducts(available)}</div><div class="card glass cart-card"><div class="row"><b>🛒 Savatcha</b><span class="tag">${count} dona</span></div>${renderCart()}${cart.length?`<div class="divider"></div><div class="grid"><div class="stat"><span class="muted">Jami sotuv</span><b>${money(totalsCart.total)}</b></div><div class="stat"><span class="muted">Jami kelish</span><b>${money(totalsCart.cost)}</b></div><div class="stat"><span class="muted">Foyda / zarar</span><b class="${totalsCart.profit<0?'red':'green'}">${money(totalsCart.profit)}</b></div><div class="stat"><span class="muted">Mijoz to‘lovi</span><b>${money(totalsCart.total)}</b></div></div><button class="primary" onclick="checkoutCart()">🧾 Chek chiqarish</button>`:'<p class="muted">Mahsulot yonidagi + tugmasini bosib savdoni boshlang.</p>'}</div>${renderReceiptHistory()}`;
}
function renderSellProducts(list){if(!list.length)return '<div class="empty">Sotish uchun mahsulot yo‘q.</div>';return list.map(x=>{const c=cart.find(i=>i.id===x.id)?.q||0;return `<div class="card glass sale-product"><div class="row"><div><b>${esc(x.name)}</b><div class="muted">Sotuv ${money(x.price)} • Kelish ${money(x.cost)} • Qoldiq ${x.qty}</div></div><div class="stepper"><button onclick="adjustCart('${x.id}',-1)">−</button><b>${c}</b><button onclick="adjustCart('${x.id}',1)">＋</button></div></div></div>`}).join('')}
function filterSellProducts(q){const t=String(q||'').trim().toLocaleLowerCase('uz-UZ');const box=document.querySelector('#sellProducts');if(box)box.innerHTML=renderSellProducts(db.stock.filter(x=>x.qty>0&&(x.name||'').toLocaleLowerCase('uz-UZ').includes(t)))}
function adjustCart(id,delta){if(!isAdmin())return;const st=db.stock.find(x=>x.id===id);if(!st)return;const existing=cart.find(x=>x.id===id);const next=(existing?.q||0)+delta;if(next<=0){cart=cart.filter(x=>x.id!==id)}else{if(next>st.qty)return;const item=existing||{id,name:st.name,price:st.price,cost:st.cost,q:0};item.q=next;if(!existing)cart.push(item)}page('sell')}
function cartTotals(){return {total:cart.reduce((s,x)=>s+x.price*x.q,0),cost:cart.reduce((s,x)=>s+x.cost*x.q,0),profit:cart.reduce((s,x)=>s+(x.price-x.cost)*x.q,0)}}
function renderCart(){return cart.length?cart.map(x=>`<div class="cart-line"><div><b>${esc(x.name)}</b><div class="muted">${x.q} × ${money(x.price)} · Kelish ${money(x.cost)} / dona</div></div><div><b>${money(x.price*x.q)}</b><div class="mini-profit ${((x.price-x.cost)*x.q)<0?'red':'green'}">${money((x.price-x.cost)*x.q)}</div></div></div>`).join(''):'<div class="empty">Savatcha bo‘sh.</div>'}
function checkoutCart(){if(!cart.length)return alert('Savatcha bo‘sh.');const t=cartTotals();modal(`<button class="close" onclick="closeModal()">×</button><h3>Chekni tasdiqlash 🧾</h3><div class="card"><div class="row"><span>Jami</span><b>${money(t.total)}</b></div><div class="row"><span>Kelish</span><b>${money(t.cost)}</b></div><div class="row"><span>Foyda / zarar</span><b class="${t.profit<0?'red':'green'}">${money(t.profit)}</b></div></div><input id="saleCustomer" placeholder="Mijoz ismi" maxlength="80" autocomplete="name"><input id="salePaid" type="number" min="0" value="${t.total}" placeholder="Mijoz to‘lovi"><button class="primary" onclick="completeCartSale()">Chekni saqlash</button>`)}
function completeCartSale(){
  const paid=toNum(document.querySelector('#salePaid')?.value,-1); if(paid<0||!cart.length)return alert('Mijoz to‘lovini to‘g‘ri kiriting.');
  for(const item of cart){const st=db.stock.find(x=>x.id===item.id);if(!st||st.qty<item.q)return alert(`${item.name} qoldig‘i yetarli emas.`)}
  const t=cartTotals(); const receiptNo=db.sales.reduce((m,s)=>Math.max(m,toNum(s.receiptNo,0)),0)+1;
  const sale={id:uid('sale'),receiptNo,items:cart.map(x=>({...x})),name:cart.map(x=>x.name).join(', '),q:cart.reduce((s,x)=>s+x.q,0),total:t.total,costTotal:t.cost,paid,profit:t.profit,customer:(document.querySelector('#saleCustomer')?.value||'').trim()||'Mijoz',date:now()};
  db.sales.push(sale); db.cash+=paid;
  for(const item of cart){const st=db.stock.find(x=>x.id===item.id); if(st){st.qty-=item.q; if(st.qty<=0)db.stock=db.stock.filter(x=>x.id!==st.id)}}
  const saved = save();
  if(!saved) return;
  cart=[];
  closeModal();
  page('sell');
  setTimeout(()=>showReceipt(sale.id), 0);
}
function renderReceiptHistory(filter=''){
  const q=String(filter||'').trim().toLocaleLowerCase('uz-UZ');
  const all=db.sales.slice().sort((a,b)=>b.date-a.date);
  const receipts=all.filter(x=>!q||String(x.receiptNo).includes(q)||(x.customer||'').toLocaleLowerCase('uz-UZ').includes(q)||(x.name||'').toLocaleLowerCase('uz-UZ').includes(q));
  return `<div class="card glass receipt-history"><div class="row"><div><b>🧾 Cheklar tarixi</b><div class="muted">Yangi chek eski cheklar yoniga saqlanadi.</div></div><span class="tag">${all.length} ta</span></div><div class="search-box glass receipt-search"><span>⌕</span><input id="receiptSearch" placeholder="Chek №, mijoz yoki mahsulot qidirish..." value="${esc(filter)}" oninput="filterReceipts(this.value)"><button class="small-btn" onclick="clearReceiptSearch()">×</button></div><div id="receiptList">${renderReceiptList(receipts)}</div></div>`;
}
function renderReceiptList(receipts){
  return receipts.length?receipts.map(x=>`<div class="receipt-item"><div class="row"><div><b>Chek #${esc(x.receiptNo)}</b><div class="muted">${esc(x.customer||'Mijoz')} · ${new Date(x.date).toLocaleString('uz-UZ')}</div></div><b class="green">${money(x.total)}</b></div><div class="receipt-meta"><span>${x.items?.length||1} xil mahsulot · ${x.q} dona</span><span>Foyda: ${money(x.profit)}</span></div><button class="small-btn" onclick="showReceipt('${x.id}')">Chekni ko‘rish</button></div>`).join(''):'<p class="muted">Qidiruv bo‘yicha chek topilmadi.</p>';
}
function filterReceipts(q){const box=document.querySelector('#receiptList');if(box){const t=String(q||'').trim().toLocaleLowerCase('uz-UZ');const receipts=db.sales.slice().sort((a,b)=>b.date-a.date).filter(x=>!t||String(x.receiptNo).includes(t)||(x.customer||'').toLocaleLowerCase('uz-UZ').includes(t)||(x.name||'').toLocaleLowerCase('uz-UZ').includes(t));box.innerHTML=renderReceiptList(receipts)}}
function clearReceiptSearch(){const i=document.querySelector('#receiptSearch');if(i)i.value='';filterReceipts('')}

function showReceipt(id){
  const x=db.sales.find(s=>s.id===id);
  if(!x)return alert('Chek topilmadi.');
  modal(`<button class="close" onclick="closeModal();page('sell')">×</button><div class="receipt-print" id="receiptPrint"><div class="receipt-head"><b>TAVARs</b><span>CHEK #${esc(x.receiptNo)}</span></div><div class="receipt-customer"><span>Mijoz</span><b>${esc(x.customer||'Mijoz')}</b></div><div class="muted">${new Date(x.date).toLocaleString('uz-UZ')}</div><hr>${(x.items||[]).map(i=>`<div class="row"><span>${esc(i.name)} × ${i.q}</span><span>${money(i.price*i.q)}</span></div><div class="muted receipt-sub">Kelish: ${money(i.cost*i.q)} · Foyda: ${money((i.price-i.cost)*i.q)}</div>`).join('')}<hr><div class="row"><b>Jami sotuv</b><b>${money(x.total)}</b></div><div class="row"><span>Jami kelish</span><b>${money(x.costTotal)}</b></div><div class="row"><span>Mijoz to‘lovi</span><b>${money(x.paid)}</b></div><div class="row"><span>Foyda / zarar</span><b class="${x.profit<0?'red':'green'}">${money(x.profit)}</b></div>${x.paid<x.total?`<div class="row"><span>Qolgan qarz</span><b class="red">${money(x.total-x.paid)}</b></div>`:''}</div><div class="receipt-actions"><button class="small-btn" onclick="closeModal();page('sell')">Yopish</button><button class="primary" onclick="closeModal();page('sell')">＋ Yangi sotuv</button></div>`);
}

function finance(){const t=totals();const ops=[...db.sales.map(x=>({...x,type:'Sotuv',amount:x.paid})),...db.repairs.map(x=>({...x,type:'Remont',amount:x.amount})),...db.expenses.map(x=>({...x,type:'Xarajat',amount:-x.amount}))].sort((a,b)=>b.date-a.date).slice(0,25);return `<div class="hero glass"><h2>Moliya 💰</h2><div class="grid"><div class="stat"><span class="muted">Kassa</span><b>${money(db.cash)}</b></div><div class="stat"><span class="muted">Sotuv tushumi</span><b class="green">${money(t.salesRevenue)}</b></div><div class="stat"><span class="muted">Kelish</span><b>${money(t.cost)}</b></div><div class="stat"><span class="muted">Sof foyda</span><b class="${t.profit<0?'red':'green'}">${money(t.profit)}</b></div></div></div><div class="actions"><button class="small-btn" onclick="expenseModal()">− Xarajat</button><button class="small-btn" onclick="repairModal()">🔧 Remont</button><button class="small-btn" onclick="debtModal()">＋ Qarz</button></div><h3>Oxirgi operatsiyalar</h3>${ops.map(x=>`<div class="card glass row"><span>${esc(x.type)} · ${esc(x.name||x.desc||'')}</span><b class="${x.amount<0?'red':'green'}">${money(x.amount)}</b></div>`).join('')||'<div class="empty">Operatsiya yo‘q.</div>'}`}
function reports(){const t=totals();const entries=[...db.sales.map(x=>({date:x.date,amount:x.total,type:'Sotuv'})),...db.repairs.map(x=>({date:x.date,amount:x.amount,type:'Remont'})),...db.expenses.map(x=>({date:x.date,amount:-x.amount,type:'Xarajat'}))];const days={};entries.forEach(x=>{const d=new Date(x.date).toLocaleDateString('uz-UZ');days[d]=(days[d]||0)+x.amount});const daily=Object.entries(days).sort((a,b)=>b[1]-a[1]);return `<div class="hero glass"><h2>Statistika 📊</h2><p class="muted">Foyda sotuv narxi − kelish narxi asosida hisoblanadi.</p></div><div class="grid"><div class="stat glass"><span class="muted">Sotuv</span><b>${money(t.salesRevenue)}</b></div><div class="stat glass"><span class="muted">Kelish</span><b>${money(t.cost)}</b></div><div class="stat glass"><span class="muted">Sotuv foydasi</span><b class="${t.salesProfit<0?'red':'green'}">${money(t.salesProfit)}</b></div><div class="stat glass"><span class="muted">Sof foyda</span><b class="${t.profit<0?'red':'green'}">${money(t.profit)}</b></div></div><div class="card glass"><div class="row"><b>Kunlik balans</b><span class="tag">${daily.length} kun</span></div>${daily.slice(0,14).map(([d,a])=>`<div class="row compact-row"><span>${esc(d)}</span><b class="${a<0?'red':'green'}">${money(a)}</b></div>`).join('')||'<p class="muted">Maʼlumot yo‘q.</p>'}</div>`}
function debts(){return `<div class="hero glass"><h2>Qarzlar 🤝</h2><button class="primary" onclick="debtModal()">＋ Qarz qo‘shish</button></div>${db.debts.map(x=>`<div class="card glass"><div class="row"><div><b>${esc(x.name)}</b><div class="muted">${money(x.amount)}</div></div><button class="small-btn" onclick="payDebtById('${x.id}')">Yopish</button></div></div>`).join('')||'<div class="empty">Qarzlar yo‘q.</div>'}`}
function buylist(){return `<div class="hero glass"><h2>TAVARs buy-list 🧾</h2><p class="muted">Yetkazib beruvchidan olish rejalashtirilgan mahsulotlar.</p><button class="primary" onclick="buyModal()">＋ Ro‘yxatga qo‘shish</button></div>${db.buy.slice().sort((a,b)=>b.date-a.date).map(x=>`<div class="card glass"><div class="row"><div><b>${esc(x.name)}</b><div class="muted">Kelish: ${money(x.cost||x.price)}</div></div><div class="actions"><button class="small-btn" onclick="buyDoneById('${x.id}')">Olingan</button><button class="small-btn danger" onclick="removeBuyById('${x.id}')">×</button></div></div></div>`).join('')||'<div class="empty">Xarid ro‘yxati bo‘sh.</div>'}`}
function repairs(){return `<div class="hero glass"><h2>Remont 🔧</h2><p class="muted">Remont tushumi 100% sof foyda sifatida hisoblanadi.</p><button class="primary" onclick="repairModal()">＋ Remont qo‘shish</button></div>${db.repairs.map(x=>`<div class="card glass row"><div><b>${esc(x.desc)}</b><div class="muted">${new Date(x.date).toLocaleString('uz-UZ')}</div></div><b class="green">${money(x.amount)}</b></div>`).join('')||'<div class="empty">Remont yozuvlari yo‘q.</div>'}`}

function more(){
  if(!isAdmin()) return `<div class="hero glass"><span class="tag">USER MENU</span><h2>Menu ⚙️</h2><p class="muted">Faqat User sozlamalari.</p></div><div class="card glass"><div class="row"><div><b>👤 Ism</b><div class="muted">${esc(db.userName||session()?.name||'')}</div></div><button class="small-btn" onclick="editUserName()">Tahrirlash</button></div></div><div class="card glass"><div class="row"><div><b>🌗 Kun / Tun</b><div class="muted">Ko‘rinish saqlanadi.</div></div><button class="small-btn" onclick="toggleTheme()">${document.body.classList.contains('light')?'🌙 Tun':'☀️ Kun'}</button></div></div><div class="card glass"><button class="small-btn" onclick="page('products')">▣ Bor mahsulotlar</button><button class="small-btn" onclick="page('recent')">◷ Yaqinda</button><button class="small-btn" onclick="page('sms')">✉ SMS ${unreadCount()?`<span class="badge">${unreadCount()}</span>`:''}</button></div><div class="card glass"><button class="small-btn danger" onclick="logout()">Chiqish / Log out</button></div>`;
  return `<div class="hero glass"><span class="tag">ADMIN SETTINGS</span><h2>Menu ⚙️</h2><p class="muted">Admin va tizim sozlamalari.</p></div><div class="card glass"><div class="row"><div><b>🌗 Kun / Tun</b><div class="muted">Ko‘rinish saqlanadi.</div></div><button class="small-btn" onclick="toggleTheme()">${document.body.classList.contains('light')?'🌙 Tun':'☀️ Kun'}</button></div></div><div class="card glass"><b>Bo‘limlar</b><div class="actions"><button class="small-btn" onclick="page('reports')">📊 Statistika</button><button class="small-btn" onclick="page('debts')">🤝 Qarzlar</button><button class="small-btn" onclick="page('buylist')">🧾 TAVARs</button><button class="small-btn" onclick="page('repairs')">🔧 Remont</button><button class="small-btn" onclick="page('sms')">✉ SMS ${unreadCount()?`<span class="badge">${unreadCount()}</span>`:''}</button></div></div><div class="card glass"><b>🔐 Admin paroli</b><p class="muted">User uchun parol yo‘q.</p><button class="small-btn" onclick="passwordModal()">Parolni almashtirish</button></div><div class="card glass"><b>Maʼlumotlar</b><p class="muted">Kassa va yozuvlar shu qurilmada saqlanadi.</p><button class="small-btn danger" onclick="resetData()">Barcha maʼlumotlarni tozalash</button></div><div class="card glass"><button class="small-btn danger" onclick="logout()">Chiqish / Log out</button></div>`;
}

// SMS / Chat
function unreadCount(){return db.sms.filter(m=>m.to==='User'&&!m.read).length}
function sms(){
  const me=isAdmin()?'Admin':(session()?.name||db.userName||'User');
  const sorted=db.sms.slice().sort((a,b)=>a.date-b.date);
  setTimeout(()=>markMessagesRead(),0);
  return `<div class="hero glass"><span class="tag">${isAdmin()?'ADMIN':'USER'} • CHAT</span><h2>SMS / Chat 💬</h2><p class="muted">${isAdmin()?'User bilan to‘g‘ridan-to‘g‘ri yozishma.':'Admin bilan huddi chatdagidek yozishing.'}</p></div><div class="card glass chat"><div class="chat-stream" id="chatStream">${sorted.length?sorted.map(chatBubble).join(''):'<div class="empty">Hali xabar yo‘q. Birinchi xabarni yuboring 👋</div>'}</div><div class="chat-compose"><textarea id="chatText" placeholder="Xabar yozing..." onkeydown="chatKeydown(event)"></textarea><div id="attachmentPreview"></div><div class="chat-tools compact-tools"><label class="media-icon-btn" title="Rasm yuborish" aria-label="Rasm yuborish">🖼️<input id="mediaImage" type="file" accept="image/*" onchange="previewAttachment(this.files[0])" hidden></label><label class="media-icon-btn" title="Video yuborish" aria-label="Video yuborish">🎬<input id="mediaVideo" type="file" accept="video/*" onchange="previewAttachment(this.files[0])" hidden></label><button class="media-icon-btn" onclick="toggleRecording()" id="recordBtn" title="Ovoz yozish" aria-label="Ovoz yozish">🎙️</button><button class="small-icon-btn" onclick="clearComposer()" title="Tozalash" aria-label="Tozalash">×</button><button class="primary chat-send" onclick="sendChatMessage()" title="Yuborish" aria-label="Yuborish">➤</button></div><p class="muted tiny">Matn va media uchun ilova tomonidan qo‘yilgan limit yo‘q. Qurilma/brauzer xotira cheklovi saqlanadi.</p></div></div>`;
}
function chatBubble(m){
  const mine=(isAdmin()?m.from==='Admin':m.from==='User'); const att=m.attachment;
  let body=m.text?`<div class="bubble-text">${esc(m.text)}</div>`:'';
  if(att)body+=`<div class="attachment" data-att-id="${esc(att.id)}" data-att-type="${esc(att.type)}"><div class="muted">${att.type==='audio'?'🎙 Ovozli xabar':att.type==='image'?'🖼 Rasm':'🎥 Video'} · ${esc(att.name||'fayl')}</div><div class="media-slot">Yuklanmoqda...</div></div>`;
  return `<div class="chat-row ${mine?'mine':'theirs'}"><div class="bubble ${mine?'bubble-mine':'bubble-theirs'}"><div class="bubble-name">${esc(m.from)}</div>${body}<div class="bubble-time">${new Date(m.date).toLocaleTimeString('uz-UZ',{hour:'2-digit',minute:'2-digit'})}</div></div></div>`;
}
function chatKeydown(e){if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){e.preventDefault();sendChatMessage()}}
let pendingAttachment=null;
async function previewAttachment(file){pendingAttachment=null;const box=document.querySelector('#attachmentPreview');if(!box||!file)return;const type=file.type.startsWith('image/')?'image':file.type.startsWith('video/')?'video':null;if(!type)return alert('Faqat rasm yoki video tanlang.');pendingAttachment={file,type,name:file.name};const previewUrl=URL.createObjectURL(file);const thumb=type==='image'?`<img src="${previewUrl}" alt="Tanlangan rasm" class="preview-thumb">`:`<video src="${previewUrl}" class="preview-thumb" muted playsinline></video>`;box.innerHTML=`<div class="attachment-preview compact-preview">${thumb}<div class="preview-info"><b>${esc(file.name)}</b><span>${type==='image'?'Rasm':'Video'} · ${(file.size/1024/1024).toFixed(1)} MB</span></div><button class="small-icon-btn" onclick="clearAttachment()" title="Olib tashlash">×</button></div>`}
function clearAttachment(){pendingAttachment=null;['#mediaImage','#mediaVideo'].forEach(sel=>{const i=document.querySelector(sel);if(i)i.value=''});const b=document.querySelector('#attachmentPreview');if(b)b.innerHTML=''}
function openMediaDb(){return new Promise((resolve,reject)=>{const r=indexedDB.open(ATT_DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(ATT_STORE);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function putAttachment(file){const dbi=await openMediaDb();const id=uid('media');await new Promise((res,rej)=>{const tx=dbi.transaction(ATT_STORE,'readwrite');tx.objectStore(ATT_STORE).put({blob:file,type:file.type,name:file.name},id);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)});return id}
async function getAttachment(id){try{const dbi=await openMediaDb();return await new Promise((res,rej)=>{const tx=dbi.transaction(ATT_STORE,'readonly');const req=tx.objectStore(ATT_STORE).get(id);req.onsuccess=()=>res(req.result||null);req.onerror=()=>rej(req.error)})}catch(e){return null}}
async function hydrateChatAttachments(){for(const el of document.querySelectorAll('[data-att-id]')){const item=await getAttachment(el.dataset.attId);const slot=el.querySelector('.media-slot');if(!slot)continue;if(!item){slot.textContent='Fayl topilmadi.';continue}const url=URL.createObjectURL(item.blob);if(el.dataset.attType==='image')slot.innerHTML=`<img class="chat-media" src="${url}" alt="Rasm">`;else if(el.dataset.attType==='video')slot.innerHTML=`<video class="chat-media" src="${url}" controls playsinline></video>`;else slot.innerHTML=`<audio controls src="${url}"></audio>`}}
async function sendChatMessage(){
  const text=(document.querySelector('#chatText')?.value||'').trim(); if(!text&&!pendingAttachment&&!recordChunks.length)return alert('Xabar yoki media yuboring.');
  let attachment=null;
  if(recordChunks.length){const blob=new Blob(recordChunks,{type:mediaRecorder?.mimeType||'audio/webm'});try{const id=await putAttachment(new File([blob],'voice-message.webm',{type:blob.type}));attachment={id,type:'audio',name:'voice-message.webm'};recordChunks=[]}catch(e){return alert('Ovozli xabarni saqlab bo‘lmadi.')}}
  else if(pendingAttachment){try{const id=await putAttachment(pendingAttachment.file);attachment={id,type:pendingAttachment.type,name:pendingAttachment.name}}catch(e){return alert('Faylni saqlab bo‘lmadi.')}}
  const from=isAdmin()?'Admin':'User'; const to=isAdmin()?'User':'Admin'; db.sms.push({id:uid('sms'),from,to,text,date:now(),read:false,attachment});save();clearComposer();page('sms');
}
function clearComposer(){const t=document.querySelector('#chatText');if(t)t.value='';clearAttachment();recordChunks=[];const b=document.querySelector('#recordBtn');if(b)b.textContent='🎙 Ovoz'}
async function toggleRecording(){
  const btn=document.querySelector('#recordBtn'); if(mediaRecorder?.state==='recording'){mediaRecorder.stop();if(btn)btn.textContent='🎙 Ovoz';return}
  if(!navigator.mediaDevices?.getUserMedia)return alert('Bu qurilmada ovoz yozish mavjud emas.');
  try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});mediaRecorder=new MediaRecorder(stream);recordChunks=[];mediaRecorder.ondataavailable=e=>{if(e.data.size)recordChunks.push(e.data)};mediaRecorder.onstop=()=>{stream.getTracks().forEach(t=>t.stop());if(btn)btn.textContent='✅ Ovoz tayyor'};mediaRecorder.start();if(btn)btn.textContent='⏹ To‘xtatish'}catch(e){alert('Mikrofonga ruxsat berilmadi.')}
}
function markMessagesRead(){if(!isAdmin()){let changed=false;db.sms.forEach(m=>{if(m.to==='User'&&!m.read){m.read=true;changed=true}});if(changed)save()}}

function editUserName(){modal(`<button class="close" onclick="closeModal()">×</button><h3>User ismini tahrirlash 👤</h3><p class="muted">Yangi ism saqlanadi va keyingi kirishda shu ism qoladi.</p><input id="userNameEdit" placeholder="Ismingiz" value="${esc(db.userName||'')}" maxlength="40"><button class="primary" onclick="saveUserName()">Saqlash</button>`)}
function saveUserName(){const name=(document.querySelector('#userNameEdit')?.value||'').trim();if(!name)return alert('Ismni kiriting.');db.userName=name;const s=session();if(s&&s.role==='user'){s.name=name;sessionStorage.setItem(SESSION_KEY,JSON.stringify(s))}save();closeModal();page('more')}
function modal(html){const b=document.querySelector('#modalBody'),r=document.querySelector('#modal');if(!b||!r)return;b.innerHTML=html;r.classList.remove('hidden')}
function closeModal(){document.querySelector('#modal')?.classList.add('hidden')}
function addStock(existingId=null){const x=existingId?db.stock.find(s=>s.id===existingId):null;modal(`<button class="close" onclick="closeModal()">×</button><h3>${x?'Mahsulotni tahrirlash':'Mahsulot qo‘shish'}</h3><input id="sn" placeholder="Mahsulot nomi" value="${esc(x?.name||'')}" maxlength="80"><input id="sp" type="number" min="0" step="1" placeholder="Sotuv narxi" value="${x?.price??''}"><input id="sc" type="number" min="0" step="1" placeholder="Kelish narxi / tannarx" value="${x?.cost??''}"><input id="sq" type="number" min="1" step="1" placeholder="Miqdori" value="${x?.qty??''}"><button class="primary" onclick="saveStockById(${existingId?`'${existingId}'`:'null'})">Saqlash</button>`)}
function saveStockById(id){
  const name=(document.querySelector('#sn')?.value||'').trim().replace(/\s+/g,' ');
  const price=toNum(document.querySelector('#sp')?.value,-1);
  const cost=toNum(document.querySelector('#sc')?.value,-1);
  const qty=Math.floor(toNum(document.querySelector('#sq')?.value,0));
  if(!name||price<0||cost<0||qty<1)return alert('Nom, sotuv narxi, kelish narxi va miqdorni to‘g‘ri kiriting.');
  const cashBefore=db.cash;
  const key=stockKey(name);
  if(id){
    const x=db.stock.find(s=>s.id===id);
    if(!x)return alert('Mahsulot topilmadi.');
    const duplicate=db.stock.find(s=>s.id!==id && stockKey(s.name)===key);
    if(duplicate){
      duplicate.qty+=qty;
      duplicate.price=price;
      duplicate.cost=cost;
      db.stock=db.stock.filter(s=>s.id!==id);
      cart=cart.filter(c=>c.id!==id);
    }else{
      Object.assign(x,{name,price,cost,qty});
    }
  }else{
    const existing=db.stock.find(s=>stockKey(s.name)===key);
    if(existing){
      existing.qty+=qty;
      existing.price=price;
      existing.cost=cost;
    }else{
      db.stock.push({id:uid('stk'),name,price,cost,qty});
    }
  }
  db.stock=normalizeStock(db.stock);
  db.cash=cashBefore;
  if(!save())return;
  closeModal();
  page('stock');
}
function editStockById(id){addStock(id)}
function removeStockById(id){if(confirm('Mahsulot o‘chirilsinmi?')){db.stock=db.stock.filter(x=>x.id!==id);cart=cart.filter(x=>x.id!==id);save();page('stock')}}
function expenseModal(){modal(`<button class="close" onclick="closeModal()">×</button><h3>Xarajat qo‘shish</h3><input id="ea" type="number" min="1" step="1" placeholder="Summa"><input id="ed" placeholder="Izoh" maxlength="120"><button class="primary" onclick="addExpense()">Saqlash</button>`)}
function addExpense(){const a=toNum(document.querySelector('#ea')?.value,0);if(a<=0)return alert('Summani kiriting.');db.expenses.push({id:uid('exp'),amount:a,desc:(document.querySelector('#ed')?.value||'').trim(),date:now()});db.cash-=a;save();closeModal();page('finance')}
function repairModal(){modal(`<button class="close" onclick="closeModal()">×</button><h3>Remont daromadi 🔧</h3><input id="ra" type="number" min="1" step="1" placeholder="Mijoz to‘lovi"><input id="rd" placeholder="Xizmat nomi" maxlength="120"><button class="primary" onclick="addRepair()">Saqlash</button>`)}
function addRepair(){const a=toNum(document.querySelector('#ra')?.value,0);if(a<=0)return alert('Summani kiriting.');db.repairs.push({id:uid('rep'),amount:a,desc:(document.querySelector('#rd')?.value||'').trim()||'Remont',date:now()});db.cash+=a;save();closeModal();page('repairs')}
function debtModal(){modal(`<button class="close" onclick="closeModal()">×</button><h3>Qarz qo‘shish</h3><input id="dn" placeholder="Mijoz nomi" maxlength="80"><input id="da" type="number" min="1" step="1" placeholder="Qarz summasi"><button class="primary" onclick="addDebt()">Saqlash</button>`)}
function addDebt(){const name=(document.querySelector('#dn')?.value||'').trim();const a=toNum(document.querySelector('#da')?.value,0);if(!name||a<=0)return alert('Maʼlumotlarni to‘g‘ri kiriting.');db.debts.push({id:uid('debt'),name,amount:a,date:now()});save();closeModal();page('debts')}
function payDebtById(id){const x=db.debts.find(d=>d.id===id);if(!x)return alert('Qarz topilmadi.');if(confirm(`${x.name} qarzi yopilsinmi?`)){db.cash+=x.amount;db.debts=db.debts.filter(d=>d.id!==id);save();page('debts')}}
function buyModal(){modal(`<button class="close" onclick="closeModal()">×</button><h3>Buy-listga qo‘shish</h3><input id="bn" placeholder="Mahsulot nomi" maxlength="80"><input id="bp" type="number" min="0" step="1" placeholder="Sotuv narxi (agar ma'lum bo‘lsa)"><input id="bc" type="number" min="0" step="1" placeholder="Kelish narxi"><button class="primary" onclick="addBuy()">Saqlash</button>`)}
function addBuy(){const name=(document.querySelector('#bn')?.value||'').trim();const price=toNum(document.querySelector('#bp')?.value,0);const cost=toNum(document.querySelector('#bc')?.value,0);if(!name)return alert('Mahsulot nomini kiriting.');db.buy.push({id:uid('buy'),name,price,cost,date:now()});save();closeModal();page('buylist')}
function removeBuyById(id){db.buy=db.buy.filter(x=>x.id!==id);save();page('buylist')}
function buyDoneById(id){const x=db.buy.find(b=>b.id===id);if(!x)return alert('Mahsulot topilmadi.');const cost=prompt('Kelish narxi:',String(x.cost||0));if(cost===null)return;const c=toNum(cost,-1);if(c<0)return alert('Narx noto‘g‘ri.');const existing=db.stock.find(s=>s.name.toLocaleLowerCase()===x.name.toLocaleLowerCase());if(existing){existing.qty+=1;existing.cost=c;if(x.price>0)existing.price=x.price}else db.stock.push({id:uid('stk'),name:x.name,price:x.price,qty:1,cost:c});db.buy=db.buy.filter(b=>b.id!==id);save();page('buylist')}
function passwordModal(){modal(`<button class="close" onclick="closeModal()">×</button><h3>Admin parolini sozlash 🔐</h3><input id="oldAdminPass" type="password" placeholder="Joriy Admin paroli"><input id="newAdminPass" type="password" placeholder="Yangi Admin paroli"><button class="primary" onclick="savePasswords()">Parolni saqlash</button>`)}
function savePasswords(){const auth=getAuth();const old=document.querySelector('#oldAdminPass')?.value||'';const admin=document.querySelector('#newAdminPass')?.value||'';if(old!==auth.adminPassword)return alert('Joriy Admin paroli noto‘g‘ri.');if(admin.length<4)return alert('Admin paroli kamida 4 belgi bo‘lsin.');auth.adminPassword=admin;setAuth(auth);closeModal();alert('Admin paroli saqlandi.')}
function resetData(){if(confirm('Barcha maʼlumotlar butunlay o‘chadi. Davom etilsinmi?')){localStorage.removeItem(KEY);location.reload()}}
function applyTheme(){document.body.classList.toggle('light',localStorage.getItem(THEME_KEY)==='light')}
function toggleTheme(){localStorage.setItem(THEME_KEY,document.body.classList.contains('light')?'dark':'light');applyTheme();page('more')}
function showLoginFromClick(){showLogin()}

applyTheme();
window.addEventListener('load',()=>{getAuth();const s=session();if(s?.role==='admin'){showMain();page('home')}else if(s?.role==='user'){showMain();page('products')}else{showLogin();selectLoginRole('admin')}});
