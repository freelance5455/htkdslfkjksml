const meds=[
{name:"Paracetamol",generic:"Acetaminophen",cat:"Pain & Fever",uses:"Temporary relief of mild to moderate pain and fever.",side:"Nausea, stomach discomfort, or skin rash can occur. Serious liver injury can occur with overdose.",warn:"Do not exceed the product's labeled maximum dose. Avoid taking more than one product containing paracetamol/acetaminophen at the same time.",dose:"Dose depends on age, formulation and health status. Follow the product label or a clinician's advice."},
{name:"Ibuprofen",generic:"Ibuprofen",cat:"Pain & Inflammation",uses:"Used for pain, fever and inflammation in appropriate patients.",side:"Stomach upset, nausea, heartburn and dizziness may occur.",warn:"NSAIDs can increase stomach bleeding and kidney risks. Ask a clinician if you have ulcers, kidney disease, take blood thinners, or are pregnant.",dose:"Use the lowest effective dose for the shortest time according to the package or clinician."},
{name:"Amoxicillin",generic:"Amoxicillin",cat:"Antibiotic",uses:"Prescription antibiotic used for certain bacterial infections.",side:"Diarrhea, nausea and rash may occur. Serious allergic reactions are uncommon but require urgent medical attention.",warn:"Use only when prescribed. It does not treat viral colds or flu. Tell a clinician about penicillin allergies.",dose:"Take exactly as prescribed and complete the prescribed course unless your prescriber tells you otherwise."},
{name:"Cetirizine",generic:"Cetirizine",cat:"Allergy",uses:"Relieves symptoms such as sneezing, runny nose and itching from allergies.",side:"Drowsiness, tiredness, dry mouth and headache can occur.",warn:"Avoid activities requiring alertness if it makes you sleepy. Ask a clinician about use with other sedating medicines.",dose:"Follow the age-appropriate product label or clinician's instructions."},
{name:"Omeprazole",generic:"Omeprazole",cat:"Stomach & Acid",uses:"Reduces stomach acid and is used for certain acid-related conditions.",side:"Headache, abdominal discomfort, nausea or diarrhea may occur.",warn:"Long-term or repeated use should be discussed with a clinician, especially if symptoms persist or recur.",dose:"Take according to the specific product directions or prescription."},
{name:"Metformin",generic:"Metformin",cat:"Diabetes",uses:"Prescription medicine commonly used to improve blood glucose control in type 2 diabetes.",side:"Diarrhea, nausea, stomach upset and reduced appetite are common, especially when starting.",warn:"Kidney function and other medical conditions matter. Rarely, a serious condition called lactic acidosis can occur.",dose:"Take exactly as prescribed. Do not change the dose without your clinician."}
];
let urdu=false;
const $=id=>document.getElementById(id);
function render(){
 const q=$("search").value.trim().toLowerCase();
 const arr=meds.filter(m=>(m.name+" "+m.generic+" "+m.cat).toLowerCase().includes(q));
 $("cards").innerHTML=arr.length?arr.map((m,i)=>`<div class="card" onclick="openMed(${meds.indexOf(m)})"><div class="medicon">💊</div><div><h3>${m.name}</h3><div class="generic">${m.generic}</div><span class="cat">${m.cat}</span></div><div class="arrow">›</div></div>`).join(""):`<div class="empty">${urdu?"کوئی دوا نہیں ملی":"No medicines found"}</div>`;
}
function openMed(i){
 const m=meds[i]; $("home").classList.add("hidden");$("detail").classList.remove("hidden");$("back").classList.remove("hidden");
 $("detail").innerHTML=`<div class="detailHero"><div class="medicon">💊</div><h1>${m.name}</h1><p>${m.generic} · ${m.cat}</p></div>
 <div class="section"><h3>Uses / استعمال</h3><p>${m.uses}</p></div>
 <div class="section"><h3>Common Side Effects / عام مضر اثرات</h3><p>${m.side}</p></div>
 <div class="section"><h3>Warnings / احتیاط</h3><p>${m.warn}</p></div>
 <div class="section"><h3>Dose Reference / خوراک</h3><p>${m.dose}</p></div>
 <div class="source">Educational reference only. Always check the current medicine label and consult a doctor or pharmacist.</div>`;
}
$("search").addEventListener("input",render);
$("back").onclick=()=>{$("detail").classList.add("hidden");$("home").classList.remove("hidden");$("back").classList.add("hidden")};
$("lang").onclick=()=>{urdu=!urdu;$("lang").textContent=urdu?"English":"اردو";$("title").textContent=urdu?"ادویات کا ریفرنس":"Medicine Reference";$("desc").textContent=urdu?"ادویات، استعمال، مضر اثرات اور احتیاط تلاش کریں۔":"Search medicines, uses, side effects and warnings.";$("listTitle").textContent=urdu?"ادویات":"Medicines";$("search").placeholder=urdu?"دوا تلاش کریں...":"Search medicine...";render()};
render();