const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);let ds=JSON.parse(localStorage.ds||"[]"),pin=localStorage.vpin||"";
function esc(x){return String(x).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function render(){let b=$("#list");if(!ds.length){b.className="empty";b.textContent="No downloads yet."}else{b.className="";b.innerHTML=ds.map((d,i)=>`<div class=item><div>⬇️</div><div class=meta><b>${esc(d.n)}</b><small>${esc(d.u)}</small></div><a href="${esc(d.u)}" target="_blank">Open</a><button onclick="del(${i})">×</button></div>`).join("")}}
window.del=i=>{ds.splice(i,1);localStorage.ds=JSON.stringify(ds);render()};
$("#go").onclick=()=>{let u=$("#url").value.trim();if(!/^https?:\/\//i.test(u))u="https://"+u;$("#url").value=u;$("#web").src=u;$("#hint").style.display="none"};
$$(".quick button").forEach(b=>b.onclick=()=>{$("#url").value=b.dataset.u;$("#go").click()});
$("#add").onclick=()=>{let u=$("#media").value.trim();try{new URL(u)}catch{return alert("Enter a valid URL")}ds.unshift({u,n:decodeURIComponent(u.split("/").pop().split("?")[0])||"download"});localStorage.ds=JSON.stringify(ds);render();$("#media").value=""};
$("#clear").onclick=()=>{ds=[];localStorage.ds="[]";render()};
$$(".nav").forEach(b=>b.onclick=()=>{$$(".nav").forEach(x=>x.classList.remove("active"));b.classList.add("active");$$(".page").forEach(x=>x.classList.remove("active"));$("#"+b.dataset.p).classList.add("active")});
$("#theme").onclick=()=>document.body.classList.toggle("light");
$("#pick").onclick=()=>$("#picker").click();$("#picker").onchange=e=>{let box=$("#filesBox");box.className="grid";box.innerHTML="";[...e.target.files].forEach(f=>{let u=URL.createObjectURL(f),d=document.createElement("div");d.className="file";d.innerHTML=(f.type.startsWith("video/")?`<video controls src="${u}"></video>`:f.type.startsWith("image/")?`<img src="${u}">`:`<div style="height:110px;display:grid;place-content:center;font-size:45px">📄</div>`)+`<b>${esc(f.name)}</b>`;box.appendChild(d)})};
$("#unlock").onclick=()=>{let p=$("#pin").value;if(!pin){if(p.length<4)return $("#msg").textContent="Use at least 4 digits.";pin=p;localStorage.vpin=p;$("#msg").textContent="PIN created. Unlock again."}else $("#msg").textContent=p===pin?"Vault unlocked for this session.":"Wrong PIN."};render();
const mediaInput=$("#media"), playerBox=$("#playerBox"), player=$("#player"), downloadVideo=$("#downloadVideo"), openVideo=$("#openVideo");
let currentMediaUrl="";
function isMediaUrl(u){try{return /\.(mp4|webm|ogg|ogv|m4v|mov|avi|mkv)(?:$|[?#])/i.test(new URL(u).pathname)}catch(e){return false}}
function loadMedia(u){currentMediaUrl=u;player.src=u;playerBox.style.display="block";player.load()}
if(mediaInput){$("#add").onclick=()=>{const u=mediaInput.value.trim();try{new URL(u)}catch(e){return alert("Enter a valid URL")}if(!isMediaUrl(u))return alert("এটি সরাসরি ভিডিও ফাইলের URL নয়। যেমন https://example.com/video.mp4 ব্যবহার করুন।");loadMedia(u);ds.unshift({u,n:decodeURIComponent(u.split("/").pop().split("?")[0])||"video"});localStorage.ds=JSON.stringify(ds);render()}}
if(downloadVideo)downloadVideo.onclick=()=>{if(!currentMediaUrl)return;const a=document.createElement("a");a.href=currentMediaUrl;a.download="";a.target="_blank";document.body.appendChild(a);a.click();a.remove()};
if(openVideo)openVideo.onclick=()=>{if(currentMediaUrl)window.open(currentMediaUrl,"_blank")};
