/* RubAI 3.0 — deterministic, offline-first Roblox/Luau workspace.
   No external scripts, network calls, API keys, or hidden model reasoning. */
(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const STORE_KEY = "rubai_v3_data";
  const LEGACY_PROJECTS = "rubai_projects";
  const LEGACY_CURRENT = "rubai_current_project";
  const LEGACY_SETTINGS = "rubai_settings";
  const views = ["studio", "code", "projects", "review", "workflow", "settings"];
  const viewNames = {studio:"Студия",code:"RubAI Code",projects:"Проекты",review:"Ревью и ошибки",workflow:"Команда ИИ",settings:"Настройки"};
  const scriptTypes = ["Script", "LocalScript", "ModuleScript"];
  let selectedView = "studio";
  let selectedScriptId = null;
  let pendingFindings = [];
  let isBusy = false;
  let modalResolver = null;
  let storageWarningShown = false;

  const makeId = () => (globalThis.crypto && crypto.randomUUID)
    ? crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2,9)}`;
  const safeText = (value, max = 12000) => String(value == null ? "" : value).slice(0, max);
  const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (ch) => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  })[ch]);
  const parseJson = (value, fallback) => {
    try { return value ? JSON.parse(value) : fallback; } catch (_) { return fallback; }
  };
  const formatDate = (value) => {
    const date = new Date(value || Date.now());
    return Number.isNaN(date.getTime()) ? "сейчас" : date.toLocaleString("ru-RU", {dateStyle:"short", timeStyle:"short"});
  };
  const storageGet = (key) => {
    try { return localStorage.getItem(key); } catch (_) { return null; }
  };
  const defaultProject = () => ({
    id:makeId(), name:"Мой Roblox-проект", task:"", constraints:"", spec:"",
    notes:"", requirements:"", reviews:[], scripts:[], chats:[], currentChatId:null,
    createdAt:Date.now()
  });

  function normalizeProject(raw) {
    const project = raw && typeof raw === "object" ? raw : {};
    const normalized = {
      id:String(project.id || makeId()),
      name:safeText(project.name || "Roblox-проект", 80),
      task:safeText(project.task, 5000),
      constraints:safeText(project.constraints, 3000),
      spec:safeText(project.spec, 20000),
      notes:safeText(project.notes, 5000),
      requirements:safeText(project.requirements, 5000),
      reviews:Array.isArray(project.reviews) ? project.reviews.map((review) => ({
        id:String(review.id || makeId()),
        text:safeText(review.text || review.title, 500),
        severity:["Высокий","Средний","Низкий"].includes(review.severity) ? review.severity : "Средний",
        status:["open","fixed","wont"].includes(review.status) ? review.status : "open",
        createdAt:review.createdAt || Date.now()
      })) : [],
      scripts:Array.isArray(project.scripts) ? project.scripts.map((script) => ({
        id:String(script.id || makeId()),
        name:safeText(script.name || "NewScript", 80),
        type:scriptTypes.includes(script.type) ? script.type : "Script",
        path:safeText(script.path || "ServerScriptService", 180),
        code:safeText(script.code, 50000),
        versions:Array.isArray(script.versions) ? script.versions.slice(-20).map((version) => ({
          id:String(version.id || makeId()), code:safeText(version.code, 50000), createdAt:version.createdAt || Date.now()
        })) : [],
        updatedAt:script.updatedAt || Date.now()
      })) : [],
      chats:Array.isArray(project.chats) ? project.chats.map((chat) => ({
        id:String(chat.id || makeId()),
        title:safeText(chat.title || "Новый чат", 90),
        createdAt:chat.createdAt || Date.now(),
        updatedAt:chat.updatedAt || Date.now(),
        messages:Array.isArray(chat.messages) ? chat.messages.slice(-250).map((message) => ({
          id:String(message.id || makeId()),
          role:message.role === "user" ? "user" : "assistant",
          content:safeText(message.content, 16000),
          code:message.code && typeof message.code === "object" ? {
            id:String(message.code.id || makeId()),
            name:safeText(message.code.name || "RobloxScript", 80),
            type:scriptTypes.includes(message.code.type) ? message.code.type : "Script",
            path:safeText(message.code.path || "ServerScriptService", 180),
            source:safeText(message.code.source, 30000)
          } : null,
          plan:message.plan === true,
          summary:safeText(message.summary, 800)
        })) : []
      })) : [],
      currentChatId:project.currentChatId ? String(project.currentChatId) : null,
      createdAt:project.createdAt || Date.now()
    };
    if (normalized.currentChatId && !normalized.chats.some((chat) => chat.id === normalized.currentChatId)) normalized.currentChatId = null;
    return normalized;
  }

  function loadInitialData() {
    const stored = parseJson(storageGet(STORE_KEY), null);
    if (stored && Array.isArray(stored.projects) && stored.projects.length) {
      const projects = stored.projects.map(normalizeProject);
      const activeId = String(stored.currentProjectId || projects[0].id);
      return {
        version:3, projects,
        currentProjectId:projects.some((project) => project.id === activeId) ? activeId : projects[0].id,
        settings:{apiEndpoint:"", ...(stored.settings || {})}
      };
    }

    const legacyProjects = parseJson(storageGet(LEGACY_PROJECTS), null);
    let projects = Array.isArray(legacyProjects) ? legacyProjects.map(normalizeProject) : [];
    if (!projects.length) projects = [defaultProject()];
    const oldActive = String(storageGet(LEGACY_CURRENT) || projects[0].id);
    const settings = parseJson(storageGet(LEGACY_SETTINGS), {});
    return {
      version:3, projects,
      currentProjectId:projects.some((project) => project.id === oldActive) ? oldActive : projects[0].id,
      settings:{apiEndpoint:safeText(settings && settings.apiEndpoint, 500)}
    };
  }

  let data = loadInitialData();
  function currentProject() {
    let project = data.projects.find((item) => item.id === data.currentProjectId);
    if (!project) {
      project = data.projects[0] || defaultProject();
      if (!data.projects.length) data.projects.push(project);
      data.currentProjectId = project.id;
    }
    return project;
  }
  function currentChat(project = currentProject()) {
    return project.chats.find((chat) => chat.id === project.currentChatId) || null;
  }

  function saveData() {
    data.version = 3;
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(data));
      localStorage.setItem(LEGACY_PROJECTS, JSON.stringify(data.projects.map((project) => ({
        id:project.id, name:project.name, task:project.task, constraints:project.constraints,
        spec:project.spec, reviews:project.reviews
      }))));
      localStorage.setItem(LEGACY_CURRENT, data.currentProjectId);
      localStorage.setItem(LEGACY_SETTINGS, JSON.stringify({apiEndpoint:data.settings.apiEndpoint || ""}));
      storageWarningShown = false;
      return true;
    } catch (error) {
      if (!storageWarningShown) {
        storageWarningShown = true;
        toast("Браузер не сохранил изменения. Проверьте свободное место или экспортируйте проект.", "warn");
      }
      return false;
    }
  }

  function toast(message, type = "info", delay = 3600) {
    const container = $("toastContainer");
    if (!container) return;
    const node = document.createElement("div");
    node.className = `toast ${type}`;
    const text = document.createElement("span");
    text.textContent = message;
    const close = document.createElement("button");
    close.type = "button";
    close.setAttribute("aria-label", "Закрыть уведомление");
    close.textContent = "×";
    close.addEventListener("click", () => node.remove());
    node.append(text, close);
    container.appendChild(node);
    window.setTimeout(() => node.remove(), delay);
  }

  function openModal({title, description = "", input = false, inputValue = "", inputLabel = "", multiline = false, buttons = []}) {
    $("modalTitle").textContent = title;
    $("modalDesc").textContent = description;
    const body = $("modalBody");
    body.replaceChildren();
    let inputNode = null;
    if (input) {
      if (inputLabel) {
        const label = document.createElement("label");
        label.className = "field-label";
        label.textContent = inputLabel;
        body.appendChild(label);
      }
      inputNode = multiline ? document.createElement("textarea") : document.createElement("input");
      inputNode.className = "field";
      inputNode.value = inputValue;
      inputNode.setAttribute("aria-label", inputLabel || title);
      if (!multiline) inputNode.maxLength = 120;
      body.appendChild(inputNode);
    }
    const actions = $("modalActions");
    actions.replaceChildren();
    $("modalBack").classList.add("open");
    return new Promise((resolve) => {
      modalResolver = resolve;
      for (const button of buttons) {
        const element = document.createElement("button");
        element.type = "button";
        element.className = `btn ${button.primary ? "primary" : ""} ${button.danger ? "danger" : ""}`;
        element.textContent = button.label;
        element.addEventListener("click", () => closeModal(button.value === "input" ? (inputNode ? inputNode.value.trim() : "") : button.value));
        actions.appendChild(element);
      }
      if (inputNode) window.setTimeout(() => inputNode.focus(), 30);
    });
  }
  function closeModal(result = null) {
    $("modalBack").classList.remove("open");
    if (modalResolver) {
      const resolve = modalResolver;
      modalResolver = null;
      resolve(result);
    }
  }
  const askText = (title, description, defaultValue = "") => openModal({
    title, description, input:true, inputValue:defaultValue, buttons:[{label:"Отмена",value:null},{label:"Сохранить",value:"input",primary:true}]
  });
  const askConfirm = (title, description, destructive = false) => openModal({
    title, description, buttons:[{label:"Отмена",value:false},{label:destructive ? "Удалить" : "Подтвердить",value:true,primary:true,danger:destructive}]
  });

  function downloadFile(filename, content, mime = "text/plain;charset=utf-8") {
    const blob = new Blob([content], {type:mime});
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename.replace(/[\\/:*?"<>|]+/g, "_");
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  async function copyText(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
      else {
        const helper = document.createElement("textarea");
        helper.value = text;
        helper.style.position = "fixed";
        helper.style.opacity = "0";
        document.body.appendChild(helper);
        helper.select();
        const copied = document.execCommand("copy");
        helper.remove();
        if (!copied) throw new Error("Clipboard unavailable");
      }
      toast("Скопировано.", "success");
    } catch (_) { toast("Не удалось скопировать. Выделите и скопируйте текст вручную.", "warn"); }
  }

  function setView(name) {
    if (!views.includes(name)) return;
    selectedView = name;
    for (const view of views) {
      const section = $(`${view}View`);
      if (section) section.classList.toggle("active", view === name);
    }
    document.querySelectorAll("[data-view]").forEach((button) => button.classList.toggle("active", button.dataset.view === name));
    $("pageTitle").textContent = viewNames[name];
    $("sidebar").classList.remove("open");
    $("mobileScrim").classList.remove("open");
    if (name === "projects") renderProjects();
    if (name === "code") renderScripts();
    if (name === "review") renderReviews();
    if (name === "settings") $("modelEndpoint").value = data.settings.apiEndpoint || "";
  }

  function createChat(project = currentProject()) {
    const chat = {id:makeId(), title:"Новый чат", createdAt:Date.now(), updatedAt:Date.now(), messages:[]};
    project.chats.unshift(chat);
    project.currentChatId = chat.id;
    saveData();
    renderSidebar();
    renderChat();
    $("chatInput").focus();
    return chat;
  }
  function renderSidebar() {
    const project = currentProject();
    $("projectSelector").replaceChildren();
    data.projects.forEach((item) => {
      const option = document.createElement("option");
      option.value = item.id;
      option.textContent = item.name;
      option.selected = item.id === project.id;
      $("projectSelector").appendChild(option);
    });
    $("activeProjectChip").textContent = project.name;
    const list = $("chatHistoryList");
    list.replaceChildren();
    if (!project.chats.length) {
      const empty = document.createElement("div");
      empty.className = "hint";
      empty.style.padding = "4px 10px";
      empty.textContent = "Пока нет чатов";
      list.appendChild(empty);
    }
    project.chats.forEach((chat) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `chat-item${chat.id === project.currentChatId ? " active" : ""}`;
      button.dataset.chatId = chat.id;
      const icon = document.createElement("span");
      icon.className = "nav-icon";
      icon.textContent = "◦";
      const title = document.createElement("span");
      title.textContent = chat.title || "Новый чат";
      button.append(icon, title);
      list.appendChild(button);
    });
  }

  function highlightLuau(source) {
    const pattern = /(--\[\[[\s\S]*?\]\]|--[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|\b(?:and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while|continue|export|type)\b|\b(?:game|workspace|script|Instance|Players|DataStoreService|ReplicatedStorage|ServerScriptService|StarterGui|StarterPlayer|RunService|task|math|string|table|Vector3|CFrame|Color3|Enum|warn|print|require)\b|\b\d+(?:\.\d+)?\b|[=<>~+*/%-]+)/g;
    let html = "", last = 0, match;
    while ((match = pattern.exec(source)) !== null) {
      html += escapeHtml(source.slice(last, match.index));
      const token = match[0];
      let cls = "tok-operator";
      if (token.startsWith("--")) cls = "tok-comment";
      else if (/^["'`]/.test(token)) cls = "tok-string";
      else if (/^\d/.test(token)) cls = "tok-number";
      else if (/^(game|workspace|script|Instance|Players|DataStoreService|ReplicatedStorage|ServerScriptService|StarterGui|StarterPlayer|RunService|task|math|string|table|Vector3|CFrame|Color3|Enum|warn|print|require)$/.test(token)) cls = "tok-builtin";
      else if (/^(and|break|do|else|elseif|end|false|for|function|if|in|local|nil|not|or|repeat|return|then|true|until|while|continue|export|type)$/.test(token)) cls = "tok-key";
      html += `<span class="${cls}">${escapeHtml(token)}</span>`;
      last = pattern.lastIndex;
    }
    return html + escapeHtml(source.slice(last));
  }
  function updateEditorHighlight() {
    const editor = $("scriptEditor");
    const preview = $("scriptHighlight");
    if (!editor || !preview) return;
    preview.innerHTML = highlightLuau(editor.value || " ");
    preview.scrollTop = editor.scrollTop;
    preview.scrollLeft = editor.scrollLeft;
  }

  function createButton(label, action, className = "mini-btn", extra = {}) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = className;
    button.textContent = label;
    button.dataset.action = action;
    Object.entries(extra).forEach(([key, value]) => { button.dataset[key] = value; });
    return button;
  }
  function renderCodeCard(code, messageId) {
    const card = document.createElement("div");
    card.className = "code-card";
    const head = document.createElement("div");
    head.className = "code-card-head";
    const meta = document.createElement("div");
    meta.className = "code-meta";
    const filename = document.createElement("strong");
    filename.textContent = code.name;
    const tag = document.createElement("span");
    tag.className = "code-tag";
    tag.textContent = code.type;
    meta.append(filename, tag);
    const actions = document.createElement("div");
    actions.className = "code-actions";
    actions.append(
      createButton("Копировать", "copy-code", "code-action", {messageId}),
      createButton("Сохранить в Code", "save-generated-code", "code-action", {messageId})
    );
    head.append(meta, actions);
    const pre = document.createElement("pre");
    pre.className = "code-block";
    pre.innerHTML = highlightLuau(code.source);
    card.append(head, pre);
    const path = document.createElement("div");
    path.className = "hint";
    path.style.padding = "0 12px 10px";
    path.textContent = `Путь в Explorer: ${code.path}`;
    card.appendChild(path);
    return card;
  }
  function renderChat() {
    const project = currentProject();
    const chat = currentChat(project);
    const list = $("messageList");
    list.replaceChildren();
    const messages = chat ? chat.messages : [];
    $("welcomePanel").classList.toggle("hidden", messages.length > 0);
    messages.forEach((message) => {
      const row = document.createElement("article");
      row.className = `message ${message.role}`;
      row.dataset.messageId = message.id;
      const avatar = document.createElement("div");
      avatar.className = "avatar";
      avatar.textContent = message.role === "user" ? "Вы" : "R";
      const body = document.createElement("div");
      body.className = "message-body";
      if (message.role === "assistant") {
        const role = document.createElement("div");
        role.className = "message-role";
        role.textContent = "RubAI · локальные правила";
        body.appendChild(role);
      }
      const text = document.createElement("div");
      text.className = "message-text";
      text.textContent = message.content;
      body.appendChild(text);
      if (message.code) body.appendChild(renderCodeCard(message.code, message.id));
      if (message.summary) {
        const reason = document.createElement("div");
        reason.className = "reasoning-note";
        reason.textContent = message.summary;
        body.appendChild(reason);
      }
      if (message.plan) {
        body.appendChild(createButton("Продолжить: подготовить скрипт", "continue-plan", "mini-btn", {messageId:message.id}));
      }
      if (message.role === "user") row.append(avatar, body);
      else row.append(avatar, body);
      list.appendChild(row);
    });
    requestAnimationFrame(() => $("chatScroll").scrollTop = $("chatScroll").scrollHeight);
    renderSidebar();
  }

  function addMessage(role, content, extras = {}) {
    const project = currentProject();
    let chat = currentChat(project);
    if (!chat) chat = createChat(project);
    const message = {id:makeId(), role, content:safeText(content, 16000), code:extras.code || null, plan:extras.plan === true, summary:safeText(extras.summary, 800)};
    chat.messages.push(message);
    if (role === "user" && chat.messages.filter((item) => item.role === "user").length === 1) {
      chat.title = safeText(content.replace(/\s+/g, " ").trim(), 42) || "Новый чат";
    }
    chat.updatedAt = Date.now();
    saveData();
    renderChat();
    return message;
  }

  function classifyPrompt(prompt, mode) {
    const lower = prompt.toLowerCase();
    const hasLuau = /(game:GetService|Instance\.new|local\s+\w+\s*=|function\s+\w+|OnServerEvent|FireServer|DataStoreService|--!strict)/i.test(prompt);
    if (mode === "check" || hasLuau || /(проверь|проанализируй|найди ошибки|исправь|отлад|ошибк|ревью|debug|review)/i.test(lower)) return "analysis";
    if (/(где размещ|куда помест|объясни.*(script|localscript|modulescript)|что такое.*(remote|datastore|luau)|как работает)/i.test(lower)) return "explain";
    if (mode === "plan") return "plan";
    if (/(сгенерируй|генерируй|реализуй|напиши\s+(?:luau|код|скрипт)|создай\s+(?:luau|код|скрипт)|generate|write|implement)/i.test(lower)) return "generate";
    if (/(спланируй|планирован|архитектур|техническое задание|тз|разбей на этапы|структур)/i.test(lower)) return "plan";
    if (/(создай|сделай|напиши|код|скрипт|систем|build|create)/i.test(lower)) return "generate";
    return "answer";
  }

  function detectFeatures(text) {
    const t = text.toLowerCase();
    return {
      dataStore:/(datastore|data store|сохранени|загрузк.*дан|сохраня|прогресс игрока)/i.test(t),
      remote:/(remoteevent|remotefunction|remote event|remotes|покупк|магазин|серверн.*провер|удар|урон|награда)/i.test(t),
      leaderstats:/(leaderstats|лидерборд|таблиц.*лидер|валют|монет|coins|денег)/i.test(t),
      ui:/(интерфейс|кнопк|меню|screen gui|screengui| gui\b|ui\b)/i.test(t),
      round:/(раунд|round|волна|wave|матч|лобби)/i.test(t),
      module:/(modulescript|модуль|вспомогательн.*функц)/i.test(t)
    };
  }
  function projectContext(project) {
    return [project.name, project.task, project.constraints, project.notes, project.requirements]
      .filter(Boolean).join("\n").slice(0, 9000);
  }
  function makePlan(prompt, project) {
    const features = detectFeatures(`${prompt}\n${projectContext(project)}`);
    const steps = [
      "Уточнить правила игры, допустимые состояния и критерии готовности.",
      "Разделить серверную логику и клиентский интерфейс; сервер оставить источником истины."
    ];
    const files = [];
    if (features.remote) {
      files.push("ReplicatedStorage/Remotes/<Action> (RemoteEvent)");
      files.push("ServerScriptService/<Feature>Server (Script): типы аргументов, права, cooldown и бизнес-правила.");
      steps.push("Создать RemoteEvent и валидировать каждый аргумент на сервере; не принимать цену, награду или урон от клиента.");
    }
    if (features.dataStore) {
      files.push("ServerScriptService/DataStoreService (Script): pcall, проверка формы данных, повторная попытка и обработка выхода.");
      steps.push("Добавить загрузку/сохранение через pcall и проверить игру с включённым API доступа в тестовой копии.");
    }
    if (features.leaderstats) files.push("ServerScriptService/Leaderstats (Script) либо часть серверного менеджера экономики.");
    if (features.ui) {
      files.push("StarterGui/<Feature>Gui + StarterPlayer/StarterPlayerScripts/<Feature>Client (LocalScript).");
      steps.push("Собрать UI на клиенте; отправлять на сервер только намерение игрока и показывать ответ сервера.");
    }
    if (features.round) files.push("ServerScriptService/RoundService (Script или ModuleScript) — состояния Lobby/Intermission/Active/Results.");
    if (features.module) files.push("ReplicatedStorage/Modules/<Feature> (ModuleScript) — только общие функции без секретной серверной логики.");
    if (!files.length) files.push("ServerScriptService/<Feature>Server (Script) + при необходимости ReplicatedStorage/Modules/<Feature> (ModuleScript).");
    steps.push("Проверить сценарии: повторные запросы, неверные типы, выход игрока, сбой сохранения и несколько клиентов.");
    return {steps, files};
  }

  function generateLuau(prompt, project) {
    const features = detectFeatures(`${prompt}\n${projectContext(project)}`);
    if (features.dataStore) {
      return {
        name:"PlayerDataServer", type:"Script", path:"ServerScriptService/PlayerDataServer",
        source:`-- ServerScriptService/PlayerDataServer
-- Пример сохранения Coins. В Studio включите Enable Studio Access to API Services
-- только для тестовой версии опыта и настройте политику повторных попыток.
local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")

local playerStore = DataStoreService:GetDataStore("PlayerData_v1")
local DEFAULT_COINS = 0

local function createStats(player, savedCoins)
\tlocal leaderstats = Instance.new("Folder")
\tleaderstats.Name = "leaderstats"
\tleaderstats.Parent = player

\tlocal coins = Instance.new("IntValue")
\tcoins.Name = "Coins"
\tcoins.Value = savedCoins
\tcoins.Parent = leaderstats
end

local function loadPlayer(player)
\tlocal key = "player_" .. player.UserId
\tlocal success, data = pcall(function()
\t\treturn playerStore:GetAsync(key)
\tend)

\tlocal coins = DEFAULT_COINS
\tif success and typeof(data) == "table" and typeof(data.Coins) == "number" then
\t\tcoins = math.max(0, math.floor(data.Coins))
\telseif not success then
\t\twarn("Не удалось загрузить данные игрока:", player.UserId, data)
\tend
\tcreateStats(player, coins)
end

local function savePlayer(player)
\tlocal stats = player:FindFirstChild("leaderstats")
\tlocal coins = stats and stats:FindFirstChild("Coins")
\tif not coins or not coins:IsA("IntValue") then return end

\tlocal key = "player_" .. player.UserId
\tlocal success, err = pcall(function()
\t\tplayerStore:SetAsync(key, {Coins = coins.Value})
\tend)
\tif not success then
\t\twarn("Не удалось сохранить данные игрока:", player.UserId, err)
\tend
end

Players.PlayerAdded:Connect(loadPlayer)
Players.PlayerRemoving:Connect(savePlayer)

game:BindToClose(function()
\tfor _, player in Players:GetPlayers() do
\t\tsavePlayer(player)
\tend
end)`
      };
    }
    if (features.leaderstats && !features.remote) {
      return {
        name:"LeaderstatsServer", type:"Script", path:"ServerScriptService/LeaderstatsServer",
        source:`-- ServerScriptService/LeaderstatsServer
local Players = game:GetService("Players")

local function setupLeaderstats(player)
\tlocal leaderstats = Instance.new("Folder")
\tleaderstats.Name = "leaderstats"
\tleaderstats.Parent = player

\tlocal coins = Instance.new("IntValue")
\tcoins.Name = "Coins"
\tcoins.Value = 0
\tcoins.Parent = leaderstats
end

Players.PlayerAdded:Connect(setupLeaderstats)

for _, player in Players:GetPlayers() do
\ttask.spawn(setupLeaderstats, player)
end`
      };
    }
    if (features.remote || features.leaderstats) {
      return {
        name:"PurchaseServer", type:"Script", path:"ServerScriptService/PurchaseServer",
        source:`-- ServerScriptService/PurchaseServer
-- Создайте ReplicatedStorage/Remotes/PurchaseItem (RemoteEvent).
-- Клиент передаёт только имя предмета. Цена и проверка находятся на сервере.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local purchaseEvent = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("PurchaseItem")
local ITEMS = {
\tSpeedCoil = {price = 100},
\tJumpCoil = {price = 150},
}
local lastRequest = {}
local COOLDOWN_SECONDS = 0.35

purchaseEvent.OnServerEvent:Connect(function(player, itemName)
\tif typeof(itemName) ~= "string" or #itemName > 40 then return end
\tlocal now = os.clock()
\tif now - (lastRequest[player] or 0) < COOLDOWN_SECONDS then return end
\tlastRequest[player] = now

\tlocal item = ITEMS[itemName]
\tif not item then return end
\tlocal stats = player:FindFirstChild("leaderstats")
\tlocal coins = stats and stats:FindFirstChild("Coins")
\tif not coins or not coins:IsA("IntValue") or coins.Value < item.price then return end

\tcoins.Value -= item.price
\t-- TODO: выдать предмет сервером после списания валюты.
end)

Players.PlayerRemoving:Connect(function(player)
\tlastRequest[player] = nil
end)`
      };
    }
    if (features.ui) {
      return {
        name:"FeatureClient", type:"LocalScript", path:"StarterPlayer/StarterPlayerScripts/FeatureClient",
        source:`-- StarterPlayer/StarterPlayerScripts/FeatureClient
-- Клиентский интерфейс. Создайте RemoteEvent в ReplicatedStorage/Remotes/PurchaseItem.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local purchaseEvent = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("PurchaseItem")
local gui = Instance.new("ScreenGui")
gui.Name = "RubAIShopGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local button = Instance.new("TextButton")
button.Name = "BuySpeedCoil"
button.Size = UDim2.fromOffset(190, 48)
button.Position = UDim2.new(0, 20, 1, -72)
button.Text = "Купить Speed Coil"
button.Parent = gui

button.Activated:Connect(function()
\t-- Сервер сам сверяет предмет, баланс и цену.
\tpurchaseEvent:FireServer("SpeedCoil")
end)`
      };
    }
    if (features.round) {
      return {
        name:"RoundManager", type:"Script", path:"ServerScriptService/RoundManager",
        source:`-- ServerScriptService/RoundManager
local Players = game:GetService("Players")

local MIN_PLAYERS = 2
local INTERMISSION_SECONDS = 15
local ROUND_SECONDS = 90
local state = "Waiting"

local function setState(nextState)
\tstate = nextState
\tprint("Состояние раунда:", state)
\t-- TODO: сообщать клиентам через отдельный RemoteEvent для UI.
end

while true do
\twhile #Players:GetPlayers() < MIN_PLAYERS do
\t\tsetState("Waiting")
\t\ttask.wait(2)
\tend

\tsetState("Intermission")
\ttask.wait(INTERMISSION_SECONDS)
\tif #Players:GetPlayers() >= MIN_PLAYERS then
\t\tsetState("Active")
\t\ttask.wait(ROUND_SECONDS)
\t\tsetState("Results")
\t\ttask.wait(5)
\tend
end`
      };
    }
    if (features.module) {
      return {
        name:"FeatureModule", type:"ModuleScript", path:"ReplicatedStorage/Modules/FeatureModule",
        source:`-- ReplicatedStorage/Modules/FeatureModule
-- ModuleScript с общими чистыми функциями; секретную серверную логику храните на сервере.
local FeatureModule = {}

function FeatureModule.clampInteger(value, minimum, maximum)
\tif typeof(value) ~= "number" then
\t\treturn nil
\tend
\treturn math.clamp(math.floor(value), minimum, maximum)
end

return FeatureModule`
      };
    }
    return {
      name:"FeatureServer", type:"Script", path:"ServerScriptService/FeatureServer",
      source:`-- ServerScriptService/FeatureServer
-- Начальная серверная основа. Подставьте игровые правила проекта и добавьте проверку состояния.
local Players = game:GetService("Players")

local function onPlayerAdded(player)
\tprint("Игрок подключился:", player.Name)
\t-- TODO: инициализировать серверное состояние игрока.
end

Players.PlayerAdded:Connect(onPlayerAdded)

for _, player in Players:GetPlayers() do
\ttask.spawn(onPlayerAdded, player)
end`
    };
  }

  function analyzeCode(source) {
    const code = String(source || "");
    const findings = [];
    const fixExamples = {
      "asset-require":`-- Замените числовой asset ID на проверенный ModuleScript из вашей игры.
local TrustedModule = require(game:GetService("ReplicatedStorage"):WaitForChild("Modules"):WaitForChild("TrustedModule"))`,
      "remote-types":`purchaseEvent.OnServerEvent:Connect(function(player, itemName)
\tif typeof(itemName) ~= "string" or #itemName > 40 then return end
\t-- Проверьте право игрока, состояние игры и предмет по серверному списку.
end)`,
      "remote-rate":`local lastRequest = {}
local COOLDOWN = 0.35
-- Внутри обработчика RemoteEvent:
local now = os.clock()
if now - (lastRequest[player] or 0) < COOLDOWN then return end
lastRequest[player] = now
-- Очистите lastRequest[player] при PlayerRemoving.`,
      "datastore-pcall":`local success, result = pcall(function()
\treturn playerStore:GetAsync(key)
end)
if not success then
\twarn("Не удалось прочитать DataStore:", result)
\treturn
end
-- Проверьте тип и форму result перед использованием.`,
      "loop-yield":`while condition do
\t-- Выполните работу цикла.
\ttask.wait(1)
end`,
      "legacy-yield":`-- Используйте task.* вместо устаревших вызовов.
task.wait(1)
task.spawn(function()
\t-- Работа в отдельной задаче.
end)`,
      "client-authority":`-- В серверном обработчике проверьте запрос до изменения состояния:
remote.OnServerEvent:Connect(function(player, action)
\tif typeof(action) ~= "string" then return end
\t-- Проверьте право, cooldown и текущее состояние на сервере.
end)`,
      "client-currency":`-- Изменяйте валюту только в Script внутри ServerScriptService.
-- Сервер должен проверить источник награды и текущее состояние игрока.`
    };
    const add = (id, title, severity, description, fix = "") => {
      if (!findings.some((item) => item.id === id)) findings.push({id,title,severity,description,fix,fixCode:fixExamples[id] || ""});
    };
    const serverRemote = /OnServerEvent|OnServerInvoke/.test(code);
    const remoteUse = /FireServer|OnServerEvent|OnServerInvoke/.test(code);
    if (/loadstring\s*\(/i.test(code)) add("loadstring","Обнаружен loadstring","Высокий","Динамическое выполнение строки кода создаёт серьёзный риск. В Roblox не используйте этот подход.","Удалите динамическое выполнение; вызывайте только заранее определённые функции.");
    if (/require\s*\(\s*\d+\s*\)/i.test(code)) add("asset-require","require по числовому ID","Высокий","Загружаемый asset-модуль может выполнять чужой код. Проверьте владельца и права доступа перед использованием.","Используйте ModuleScript из контролируемого проекта или удалите неизвестную зависимость.");
    if (remoteUse && serverRemote && !/typeof\s*\(/.test(code)) add("remote-types","Нет явной проверки типов RemoteEvent","Высокий","Обработчик сервера принимает клиентские аргументы без видимой проверки типов. Клиент может прислать неожиданные значения.","Проверяйте каждый параметр через typeof, длину строк, диапазоны чисел, права игрока и актуальное серверное состояние.");
    if (remoteUse && serverRemote && !/(cooldown|rate.?limit|lastRequest|os\.clock)/i.test(code)) add("remote-rate","Нет видимого ограничения частоты запросов","Средний","Обработчик RemoteEvent не показывает cooldown или rate limit; спам может нагружать сервер.","Добавьте серверный cooldown/rate limit с очисткой состояния при PlayerRemoving.");
    if (/DataStoreService|:GetAsync\s*\(|:SetAsync\s*\(|:UpdateAsync\s*\(/.test(code) && !/pcall\s*\(/.test(code)) add("datastore-pcall","DataStore без pcall","Высокий","Сетевые операции DataStore могут завершиться ошибкой или лимитом запросов; без pcall поток кода ломается.","Оберните каждую операцию DataStore в pcall, проверяйте success и сохраняйте понятный fallback.");
    if (/(while\s+true\s+do|while\s+[^;\n]+do)/i.test(code) && !/\b(task\.wait|wait|Heartbeat|Stepped)\b/.test(code)) add("loop-yield","Цикл может не уступать управление","Высокий","Бесконечный цикл без ожидания способен блокировать поток и создавать нагрузку.","Добавьте task.wait() с подходящим интервалом или используйте событие вместо опроса.");
    if (/\b(wait|spawn|delay)\s*\(/.test(code)) add("legacy-yield","Используется устаревшая функция ожидания","Низкий","В новых скриптах Roblox предпочтительны task.wait, task.spawn и task.delay.","Замените wait() на task.wait(), spawn(fn) на task.spawn(fn), delay(t, fn) на task.delay(t, fn).");
    if (/FireServer\s*\(/.test(code) && !serverRemote) add("client-authority","Проверьте серверный обработчик RemoteEvent","Средний","В клиентском коде есть FireServer. По одному клиентскому файлу нельзя подтвердить проверку: сервер должен валидировать действие и не доверять сумме, награде или урону.","В соответствующем Script в ServerScriptService проверьте типы аргументов, права, расстояние, cooldown и игровое состояние.");
    if (/(Coins|Cash|Money|Currency)\s*\.\s*Value\s*[+\-]=/.test(code) && !/OnServerEvent|ServerScriptService/.test(code)) add("client-currency","Изменяется значение валюты вне очевидного серверного контекста","Высокий","Если этот код выполняется на клиенте, игрок может подменить экономическое состояние.","Изменяйте валюту только серверным Script после серверной проверки.");
    if (/\bscript\.Parent\s*=\s*nil\b/.test(code) && !/Destroy\s*\(/.test(code)) add("orphan-script","Скрипт отсоединяется от иерархии","Низкий","Отключение Parent может оставить объект без ожидаемого жизненного цикла и осложнить отладку.","Используйте явный жизненный цикл и Destroy() только для объектов, которые действительно нужно удалить.");
    if (!findings.length) findings.push({
      id:"no-known-rule", title:"Явных совпадений с правилами не найдено", severity:"Низкий",
      description:"Это не подтверждает корректность кода: анализ ограничен набором эвристик и не запускает Luau."
    });
    return findings;
  }

  function findingsSummary(findings) {
    const active = findings.filter((finding) => finding.id !== "no-known-rule");
    if (!active.length) return "Локальная проверка: известных паттернов риска не обнаружено; корректность не подтверждена.";
    return `Локальная проверка обнаружила ${active.length} возможных проблем. Это статические эвристики, не запуск кода и не полноценное ревью.`;
  }
  function renderFindings(target, findings, includeActions = false) {
    target.replaceChildren();
    const wrapper = document.createElement("div");
    wrapper.className = "finding-list";
    findings.forEach((finding) => {
      const card = document.createElement("article");
      card.className = "finding";
      const head = document.createElement("div");
      head.className = "finding-head";
      const title = document.createElement("strong");
      title.textContent = finding.title;
      const sev = document.createElement("span");
      sev.className = `severity ${finding.severity === "Средний" ? "medium" : finding.severity === "Низкий" ? "low" : ""}`;
      sev.textContent = finding.severity;
      head.append(title, sev);
      const desc = document.createElement("p");
      desc.textContent = finding.description;
      card.append(head, desc);
      if (finding.fix) {
        const fix = document.createElement("p");
        fix.textContent = `Предложение: ${finding.fix}`;
        card.appendChild(fix);
      }
      if (finding.fixCode) {
        const label = document.createElement("p");
        label.textContent = "Пример исправления — проверьте и адаптируйте:";
        const pre = document.createElement("pre");
        pre.className = "code-block";
        pre.innerHTML = highlightLuau(finding.fixCode);
        const copy = createButton("Копировать пример", "copy-fix-code", "mini-btn", {findingId:finding.id});
        card.append(label, pre, copy);
      }
      if (includeActions && finding.id !== "no-known-rule") {
        card.appendChild(createButton("Добавить замечание", "add-single-finding", "mini-btn", {findingId:finding.id}));
      }
      wrapper.appendChild(card);
    });
    target.appendChild(wrapper);
  }

  function createProgressCard() {
    const card = document.createElement("div");
    card.className = "progress-card";
    const title = document.createElement("div");
    title.className = "progress-title";
    title.textContent = "Этапы локальной обработки";
    const steps = document.createElement("div");
    steps.className = "progress-steps";
    const labels = ["Определяю тип задачи и признаки Roblox","Сверяю требования проекта и безопасные места скриптов","Собираю результат из локальных правил"];
    labels.forEach((label, index) => {
      const row = document.createElement("div");
      row.className = "step";
      row.dataset.step = String(index);
      const icon = document.createElement("span");
      icon.className = "step-icon";
      icon.textContent = "○";
      const text = document.createElement("span");
      text.textContent = label;
      row.append(icon, text);
      steps.appendChild(row);
    });
    card.append(title, steps);
    $("messageList").appendChild(card);
    $("chatScroll").scrollTop = $("chatScroll").scrollHeight;
    return card;
  }
  const wait = (milliseconds) => new Promise((resolve) => window.setTimeout(resolve, milliseconds));
  async function animateLocalSteps(card) {
    const rows = Array.from(card.querySelectorAll(".step"));
    for (let index = 0; index < rows.length; index += 1) {
      rows.forEach((row, position) => {
        row.classList.toggle("done", position < index);
        row.classList.toggle("current", position === index);
        row.querySelector(".step-icon").textContent = position < index ? "✓" : position === index ? "◌" : "○";
      });
      await wait(190);
    }
    rows.forEach((row) => {
      row.classList.add("done");
      row.querySelector(".step-icon").textContent = "✓";
    });
    await wait(100);
  }

  function explainPrompt(prompt) {
    const lower = prompt.toLowerCase();
    if (/localscript/.test(lower)) return "LocalScript запускается на клиенте игрока — например, в StarterPlayerScripts, StarterCharacterScripts, PlayerGui или Backpack. Используйте его для ввода и UI; сервер всё равно должен проверять игровые действия.";
    if (/modulescript|модуль/.test(lower)) return "ModuleScript возвращает значение через return и подключается через require(). Общий модуль можно положить в ReplicatedStorage/Modules; серверную логику с секретами держите в ServerScriptService.";
    if (/remote/.test(lower)) return "RemoteEvent передаёт сообщение между клиентом и сервером. Разместите объект в ReplicatedStorage, но проверяйте каждый запрос в серверном Script: типы, права, лимиты и игровое состояние.";
    if (/datastore|сохран|данн/.test(lower)) return "DataStoreService доступен только серверным Script. Оборачивайте вызовы GetAsync/SetAsync/UpdateAsync в pcall, проверяйте форму данных, учитывайте лимиты и тестируйте в отдельной опубликованной тестовой версии.";
    if (/script/.test(lower)) return "Script обычно исполняет серверную игровую логику в ServerScriptService; LocalScript работает на клиенте; ModuleScript — переиспользуемый модуль через require(). Выбор зависит от доверенной стороны и функции кода.";
    return "RubAI может объяснять только темы, для которых есть встроенные справочные правила. Уточните название Roblox API или вставьте пример Luau — тогда локальная проверка покажет известные эвристики.";
  }

  function prepareResponse(prompt, mode, project) {
    const kind = classifyPrompt(prompt, mode);
    const context = projectContext(project);
    const features = detectFeatures(`${prompt}\n${context}`);
    const featureNames = [];
    if (features.remote) featureNames.push("RemoteEvent/серверная проверка");
    if (features.dataStore) featureNames.push("DataStore");
    if (features.leaderstats) featureNames.push("leaderstats/экономика");
    if (features.ui) featureNames.push("UI/клиент");
    if (features.round) featureNames.push("раунды");
    if (features.module) featureNames.push("ModuleScript");
    const contextLine = `Контекст: ${project.name}${project.notes || project.requirements ? "; учтены заметки и требования проекта" : ""}. Правила: ${featureNames.length ? featureNames.join(", ") : "базовый Roblox/Luau набор"}.`;

    if (kind === "analysis") {
      const findings = analyzeCode(prompt);
      const summary = findingsSummary(findings);
      const active = findings.filter((finding) => finding.id !== "no-known-rule");
      let content = active.length
        ? `Проверил вставленный текст локальными правилами. ${summary}\n\n${active.map((finding, index) => `${index + 1}. ${finding.severity}: ${finding.title} — ${finding.description}`).join("\n")}`
        : `Проверил вставленный текст локальными правилами. ${summary}\n\nУбедитесь, что код выполняется в правильном контексте и протестируйте его в Roblox Studio.`;
      if (mode === "deep") content += "\n\nГлубокий режим проверил отдельно видимые риски RemoteEvent, DataStore, клиентской валюты и циклов; скрытые свойства окружения определить невозможно.";
      return {content,summary:contextLine,findings};
    }
    if (kind === "explain") {
      return {content:explainPrompt(prompt),summary:contextLine};
    }
    if (kind === "plan") {
      const plan = makePlan(prompt, project);
      const content = `План реализации для «${project.name}»\n\nЭтапы:\n${plan.steps.map((step,index) => `${index + 1}. ${step}`).join("\n")}\n\nПредлагаемая структура Roblox Studio:\n${plan.files.map((file) => `• ${file}`).join("\n")}\n\nКритерии проверки:\n• Невалидный и повторный запрос не меняет состояние игры.\n• Клиент не может назначить себе награду, валюту или урон.\n• Ошибка DataStore обрабатывается без потери всего потока.\n• Код проверен в Roblox Studio на сервере и минимум двух клиентах.\n\nПлан составлен локальными правилами, не нейросетью.`;
      project.task = safeText(prompt, 5000);
      project.constraints = project.requirements || project.constraints || "";
      saveData();
      return {content,summary:contextLine,plan:true};
    }
    if (kind === "generate") {
      const code = generateLuau(prompt, project);
      const deepNotes = mode === "deep"
        ? "\n\nПроверка решения: серверная логика отделена от клиентской; цена и состояние не принимаются на доверии; путь размещения указан. Проверьте имена RemoteEvent/объектов в своей игре."
        : "";
      const content = `Подготовил локальный шаблон ${code.type} для задачи Roblox.\n\nРазмещение: ${code.path}\n\nСкрипт рассчитан на дальнейшую адаптацию. Проверьте зависимости, имена объектов и правила вашей игры в Roblox Studio; это шаблон, а не результат запуска или компиляции.${deepNotes}`;
      return {content,summary:contextLine,code};
    }
    if (mode === "deep") {
      const plan = makePlan(prompt, project);
      return {
        content:`Локальный анализ запроса:\n\n• Задача: ${prompt}\n• Проектный контекст: ${context}\n• Рекомендуемая структура:\n${plan.files.map((file) => `  - ${file}`).join("\n")}\n• Основной риск: сервер должен перепроверять клиентские действия; сетевые сохранения нужно оборачивать в pcall.\n\nЭто краткие выводы по правилам RubAI, а не скрытая цепочка рассуждений и не ответ нейросети.`,
        summary:contextLine
      };
    }
    return {
      content:"Локальный движок не нашёл подходящего шаблона для этого вопроса. Уточните задачу Roblox, укажите нужный Script/LocalScript/ModuleScript или включите режим планирования. Ответы RubAI строятся по встроенным правилам, не генерируются нейросетью.",
      summary:contextLine
    };
  }

  async function sendPrompt(rawPrompt, selectedMode = $("thinkingMode").value) {
    const prompt = safeText(rawPrompt.trim(), 12000);
    if (!prompt || isBusy) return;
    if (!currentChat()) createChat();
    addMessage("user", prompt);
    $("chatInput").value = "";
    resizeComposer();
    isBusy = true;
    $("sendBtn").disabled = true;
    const progress = createProgressCard();
    try {
      await animateLocalSteps(progress);
      progress.remove();
      const result = prepareResponse(prompt, selectedMode, currentProject());
      pendingFindings = result.findings || [];
      addMessage("assistant", result.content, {
        code:result.code || null,
        plan:result.plan === true,
        summary:`${result.summary} Ответ сформирован локально; внешняя нейросеть не вызывалась.`
      });
      if (result.findings) {
        toast(findingsSummary(result.findings), result.findings.some((finding) => finding.severity === "Высокий") ? "warn" : "info", 4800);
      }
      saveData();
    } catch (error) {
      progress.remove();
      addMessage("assistant", "Не удалось обработать запрос локально. Проверьте объём текста и свободное место для хранения данных.");
      console.error("RubAI local processing error", error);
    } finally {
      isBusy = false;
      $("sendBtn").disabled = false;
      $("chatInput").focus();
    }
  }

  function renderProjects() {
    const grid = $("projectsList");
    grid.replaceChildren();
    data.projects.forEach((project) => {
      const card = document.createElement("article");
      card.className = `project-card${project.id === data.currentProjectId ? " active" : ""}`;
      const title = document.createElement("h3");
      title.textContent = project.name;
      const desc = document.createElement("p");
      desc.textContent = `${project.chats.length} чатов · ${project.scripts.length} скриптов · ${project.reviews.length} замечаний`;
      const actions = document.createElement("div");
      actions.className = "card-actions";
      actions.append(
        createButton(project.id === data.currentProjectId ? "Активный" : "Открыть", "select-project", project.id === data.currentProjectId ? "btn primary" : "btn", {projectId:project.id}),
        createButton("Переименовать", "rename-project", "btn", {projectId:project.id}),
        createButton("Удалить", "delete-project", "btn danger", {projectId:project.id})
      );
      card.append(title, desc, actions);
      grid.appendChild(card);
    });
    $("projectNotes").value = currentProject().notes || "";
    $("projectRequirements").value = currentProject().requirements || "";
  }
  function renderScripts() {
    const project = currentProject();
    const list = $("scriptList");
    list.replaceChildren();
    $("scriptCount").textContent = `${project.scripts.length} скриптов`;
    if (!project.scripts.length) {
      const empty = document.createElement("div");
      empty.className = "hint";
      empty.textContent = "Сохранённых скриптов пока нет.";
      list.appendChild(empty);
    }
    project.scripts.forEach((script) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `script-item${script.id === selectedScriptId ? " active" : ""}`;
      button.dataset.scriptId = script.id;
      const name = document.createElement("b");
      name.textContent = script.name;
      const meta = document.createElement("small");
      meta.textContent = `${script.type} · ${script.path}`;
      button.append(name, meta);
      list.appendChild(button);
    });
    let active = project.scripts.find((script) => script.id === selectedScriptId);
    if (!active && project.scripts.length) {
      active = project.scripts[0];
      selectedScriptId = active.id;
    }
    if (active) {
      $("editorTitle").textContent = active.name;
      $("editorSubtitle").textContent = `Обновлено ${formatDate(active.updatedAt)} · ${active.versions.length} сохранённых версий`;
      $("scriptName").value = active.name;
      $("scriptType").value = active.type;
      $("scriptPath").value = active.path;
      $("scriptEditor").value = active.code;
      updateEditorHighlight();
      renderVersions(active);
    } else {
      selectedScriptId = null;
      $("editorTitle").textContent = "Выберите скрипт";
      $("editorSubtitle").textContent = "Код сохраняется локально в проекте";
      $("scriptName").value = "";
      $("scriptType").value = "Script";
      $("scriptPath").value = "ServerScriptService";
      $("scriptEditor").value = "";
      updateEditorHighlight();
      $("versionList").replaceChildren();
    }
    $("versionDiff").classList.add("hidden");
  }
  function renderVersions(script) {
    const list = $("versionList");
    list.replaceChildren();
    if (!script.versions.length) {
      const note = document.createElement("div");
      note.className = "hint";
      note.textContent = "Истории пока нет";
      list.appendChild(note);
      return;
    }
    script.versions.slice().reverse().slice(0,5).forEach((version, reverseIndex) => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "version-row";
      row.dataset.versionId = version.id;
      row.textContent = `${reverseIndex === 0 ? "Предыдущая" : `Версия ${script.versions.length - reverseIndex}`} · ${formatDate(version.createdAt)}`;
      list.appendChild(row);
    });
  }
  function createNewScript(code = "") {
    const project = currentProject();
    const script = {
      id:makeId(), name:"NewScript", type:"Script", path:"ServerScriptService/NewScript",
      code:code || "-- ServerScriptService/NewScript\nlocal Players = game:GetService(\"Players\")\n\n-- TODO: добавьте логику проекта.\n",
      versions:[], updatedAt:Date.now()
    };
    project.scripts.unshift(script);
    selectedScriptId = script.id;
    saveData();
    renderScripts();
    $("scriptName").focus();
    $("scriptName").select();
  }
  function saveCurrentScript() {
    const project = currentProject();
    const script = project.scripts.find((item) => item.id === selectedScriptId);
    if (!script) { toast("Сначала создайте или выберите скрипт.", "warn"); return; }
    const source = safeText($("scriptEditor").value, 50000);
    const name = safeText($("scriptName").value.trim() || "NewScript", 80);
    const type = scriptTypes.includes($("scriptType").value) ? $("scriptType").value : "Script";
    const path = safeText($("scriptPath").value.trim() || (type === "LocalScript" ? "StarterPlayer/StarterPlayerScripts" : type === "ModuleScript" ? "ReplicatedStorage/Modules" : "ServerScriptService"), 180);
    if (script.code !== source) {
      script.versions.push({id:makeId(), code:script.code, createdAt:script.updatedAt || Date.now()});
      script.versions = script.versions.slice(-20);
    }
    script.code = source;
    script.name = name;
    script.type = type;
    script.path = path;
    script.updatedAt = Date.now();
    saveData();
    renderScripts();
    toast("Скрипт и версия сохранены локально.", "success");
  }
  function saveGeneratedScript(message) {
    if (!message || !message.code) return;
    const project = currentProject();
    const script = {
      id:makeId(), name:message.code.name, type:message.code.type, path:message.code.path,
      code:message.code.source, versions:[], updatedAt:Date.now()
    };
    project.scripts.unshift(script);
    selectedScriptId = script.id;
    saveData();
    toast("Скрипт добавлен в RubAI Code.", "success");
    setView("code");
    renderScripts();
  }
  function compareVersions() {
    const script = currentProject().scripts.find((item) => item.id === selectedScriptId);
    if (!script || !script.versions.length) { toast("Для сравнения нужна сохранённая предыдущая версия.", "info"); return; }
    const previous = script.versions[script.versions.length - 1].code.split("\n");
    const current = $("scriptEditor").value.split("\n");
    const max = Math.max(previous.length, current.length);
    const lines = [];
    for (let index = 0; index < max; index += 1) {
      if (previous[index] === current[index]) lines.push(`  ${String(index + 1).padStart(3," ")} ${previous[index] || ""}`);
      else {
        if (previous[index] !== undefined) lines.push(`- ${String(index + 1).padStart(3," ")} ${previous[index]}`);
        if (current[index] !== undefined) lines.push(`+ ${String(index + 1).padStart(3," ")} ${current[index]}`);
      }
    }
    $("versionDiff").textContent = lines.join("\n") || "Изменений нет.";
    $("versionDiff").classList.remove("hidden");
  }
  function runCodeAnalysis() {
    const source = $("reviewCodeInput").value.trim();
    if (!source) { toast("Вставьте Luau-код для анализа.", "warn"); return; }
    pendingFindings = analyzeCode(source).filter((finding) => finding.id !== "no-known-rule");
    renderFindings($("analysisResults"), analyzeCode(source), true);
    toast(findingsSummary(analyzeCode(source)), "info", 4200);
  }
  function addFindingsToTracker(findings = pendingFindings) {
    const project = currentProject();
    const items = findings.filter((finding) => finding.id !== "no-known-rule");
    if (!items.length) { toast("Нет найденных замечаний для добавления.", "info"); return; }
    items.forEach((finding) => {
      if (!project.reviews.some((review) => review.text === finding.title && review.status === "open")) {
        project.reviews.unshift({id:makeId(), text:`${finding.title}: ${finding.description}`, severity:finding.severity, status:"open", createdAt:Date.now()});
      }
    });
    saveData();
    renderReviews();
    toast(`В трекер добавлено замечаний: ${items.length}.`, "success");
  }
  function renderReviews() {
    const project = currentProject();
    const list = $("reviewList");
    const filter = $("reviewFilter").value;
    const reviews = project.reviews.filter((item) => filter === "all" || item.status === filter);
    $("reviewCount").textContent = `${project.reviews.length} замечаний`;
    list.replaceChildren();
    if (!reviews.length) {
      const empty = document.createElement("div");
      empty.className = "empty-state";
      empty.textContent = project.reviews.length ? "По выбранному фильтру замечаний нет." : "В этом проекте пока нет замечаний.";
      list.appendChild(empty);
      return;
    }
    reviews.forEach((review) => {
      const row = document.createElement("article");
      row.className = "review-row";
      const info = document.createElement("div");
      const title = document.createElement("strong");
      title.style.fontSize = "11px";
      title.textContent = review.text;
      const meta = document.createElement("small");
      meta.textContent = `${review.severity} · добавлено ${formatDate(review.createdAt)}`;
      const state = document.createElement("span");
      state.className = `badge ${review.status}`;
      state.textContent = review.status === "fixed" ? "Исправлено" : review.status === "wont" ? "Не исправлять" : "Открыто";
      info.append(title, document.createElement("br"), meta);
      const actions = document.createElement("div");
      actions.className = "review-actions";
      actions.append(state, createButton("Статус", "cycle-review", "btn", {reviewId:review.id}), createButton("Удалить", "delete-review", "btn danger", {reviewId:review.id}));
      row.append(info, actions);
      list.appendChild(row);
    });
  }

  function buildSpec() {
    const project = currentProject();
    const chat = currentChat(project);
    const latestUser = chat && [...chat.messages].reverse().find((message) => message.role === "user");
    const task = project.task || (latestUser && latestUser.content) || "Не указана";
    const features = detectFeatures(`${task}\n${projectContext(project)}`);
    const plan = makePlan(task, project);
    project.task = task;
    project.spec = `# Техническое задание Roblox — ${project.name}

## Цель
${task}

## Контекст проекта
${project.notes || "Заметки пока не заданы."}

## Требования
${project.requirements || project.constraints || "Уточнить перед финальной реализацией."}

## Структура Roblox Studio
${plan.files.map((file) => `- ${file}`).join("\n")}

## Обязательные проверки
- Все RemoteEvent аргументы валидируются на сервере; клиент не определяет экономику, урон или награды.
- DataStore-запросы обёрнуты в pcall; ошибки и лимиты обрабатываются.
- Проверить неверные типы, повторные запросы, выход игрока и несколько клиентов.
- UI работает при разных размерах экрана; клиентский ввод не считается доверенным.

## Распознанные области
${Object.entries(features).filter(([,value]) => value).map(([key]) => `- ${key}`).join("\n") || "- Общая игровая логика"}

## Этапы
${plan.steps.map((step,index) => `${index + 1}. ${step}`).join("\n")}

## Статус генерации
Сформировано локальными правилами RubAI 3.0. Это стартовая спецификация, не вывод настоящей нейросети.
`;
    saveData();
    toast("ТЗ сформировано из контекста проекта.", "success");
    return project.spec;
  }
  function exportSpec() {
    const project = currentProject();
    const spec = project.spec || buildSpec();
    downloadFile(`${project.name}_RubAI_TZ.md`, spec, "text/markdown;charset=utf-8");
  }
  function exportCurrentProject() {
    const project = currentProject();
    downloadFile(`${project.name}_RubAI_Project.json`, JSON.stringify({format:"RubAIProject",version:3,project}, null, 2), "application/json;charset=utf-8");
    toast("Резервная копия текущего проекта выгружена.", "success");
  }
  function exportAllData() {
    downloadFile("RubAI_3_All_Data.json", JSON.stringify(data, null, 2), "application/json;charset=utf-8");
    toast("Все локальные данные выгружены.", "success");
  }
  function makeHandoffText() {
    const project = currentProject();
    const chat = currentChat(project);
    return `ЗАДАЧА ДЛЯ ВНЕШНЕЙ AI-СИСТЕМЫ / РАЗРАБОТЧИКА

Проект: ${project.name}
Основная задача: ${project.task || "Сформулируйте цель проекта"}
Требования: ${project.requirements || project.constraints || "Не заданы"}
Заметки: ${project.notes || "Нет"}

Последние сообщения текущего чата:
${chat ? chat.messages.slice(-8).map((message) => `${message.role === "user" ? "Пользователь" : "RubAI Local"}: ${message.content}`).join("\n\n") : "Активного чата нет."}

Существующее техническое задание:
${project.spec || "Пока не сформировано."}

Важно: RubAI Local работает на шаблонах и правилах; его ответы не были созданы ChatGPT, Gemini или Grok. Проверьте требования, безопасность RemoteEvent и тестирование в Roblox Studio.`;
  }
  async function showHandoff() {
    const text = makeHandoffText();
    const result = await openModal({
      title:"Передача контекста",
      description:"Скопируйте эту задачу в выбранную AI-систему или передайте разработчику. RubAI ничего не отправляет самостоятельно.",
      input:true, inputValue:text, inputLabel:"Инструкция",
      buttons:[{label:"Закрыть",value:null},{label:"Копировать текст",value:"copy",primary:true}]
    });
    if (result === "copy") await copyText(text);
  }

  function updateProject(projectId) {
    if (!data.projects.some((project) => project.id === projectId)) return;
    data.currentProjectId = projectId;
    selectedScriptId = null;
    saveData();
    renderSidebar();
    renderChat();
    renderProjects();
    renderScripts();
    renderReviews();
  }
  async function createProject() {
    const name = await askText("Новый проект", "Укажите короткое название Roblox-проекта.", `Новая игра ${data.projects.length + 1}`);
    if (!name) return;
    const project = normalizeProject({id:makeId(),name,createdAt:Date.now()});
    data.projects.unshift(project);
    data.currentProjectId = project.id;
    selectedScriptId = null;
    saveData();
    renderSidebar();
    renderChat();
    renderProjects();
    toast(`Создан проект «${project.name}».`, "success");
  }
  async function renameProject(id) {
    const project = data.projects.find((item) => item.id === id);
    if (!project) return;
    const name = await askText("Переименовать проект", "Название обновится в локальной истории.", project.name);
    if (!name) return;
    project.name = safeText(name, 80);
    saveData();
    renderSidebar();
    renderProjects();
    renderChat();
  }
  async function deleteProject(id) {
    if (data.projects.length < 2) { toast("Нельзя удалить последний проект.", "warn"); return; }
    const project = data.projects.find((item) => item.id === id);
    if (!project || !await askConfirm("Удалить проект?", `Проект «${project.name}» и его чаты, скрипты и замечания будут удалены из этого браузера.`, true)) return;
    data.projects = data.projects.filter((item) => item.id !== id);
    if (data.currentProjectId === id) data.currentProjectId = data.projects[0].id;
    selectedScriptId = null;
    saveData();
    renderSidebar();
    renderProjects();
    renderChat();
    renderScripts();
    renderReviews();
    toast("Проект удалён из локального хранилища.", "info");
  }

  function resizeComposer() {
    const input = $("chatInput");
    input.style.height = "auto";
    input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
  }
  function selectChat(id) {
    const project = currentProject();
    if (!project.chats.some((chat) => chat.id === id)) return;
    project.currentChatId = id;
    saveData();
    renderChat();
    $("sidebar").classList.remove("open");
    $("mobileScrim").classList.remove("open");
  }

  document.querySelectorAll("[data-view]").forEach((button) => button.addEventListener("click", () => setView(button.dataset.view)));
  $("projectSelector").addEventListener("change", (event) => updateProject(event.target.value));
  $("newChatBtn").addEventListener("click", () => createChat());
  $("menuBtn").addEventListener("click", () => {
    $("sidebar").classList.add("open");
    $("mobileScrim").classList.add("open");
  });
  $("mobileScrim").addEventListener("click", () => {
    $("sidebar").classList.remove("open");
    $("mobileScrim").classList.remove("open");
  });
  $("chatForm").addEventListener("submit", (event) => {
    event.preventDefault();
    sendPrompt($("chatInput").value);
  });
  $("chatInput").addEventListener("input", resizeComposer);
  $("chatInput").addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      $("chatForm").requestSubmit();
    }
  });
  document.querySelectorAll("[data-prompt]").forEach((button) => button.addEventListener("click", () => {
    $("chatInput").value = button.dataset.prompt;
    $("chatInput").focus();
    resizeComposer();
  }));
  $("exportProjectBtn").addEventListener("click", exportCurrentProject);
  $("exportProjectJsonBtn").addEventListener("click", exportCurrentProject);
  $("downloadAllDataBtn").addEventListener("click", exportAllData);
  $("handoffBtn").addEventListener("click", showHandoff);
  $("workflowHandoffBtn").addEventListener("click", showHandoff);
  $("exportSpecBtn").addEventListener("click", exportSpec);
  $("createProjectBtn").addEventListener("click", createProject);
  $("saveContextBtn").addEventListener("click", () => {
    const project = currentProject();
    project.notes = safeText($("projectNotes").value, 5000);
    project.requirements = safeText($("projectRequirements").value, 5000);
    saveData();
    toast("Заметки и требования сохранены и доступны локальному движку.", "success");
  });
  $("importProjectJsonBtn").addEventListener("click", () => $("importFileInput").click());
  $("importFileInput").addEventListener("change", async (event) => {
    const file = event.target.files && event.target.files[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 3 * 1024 * 1024) { toast("Файл больше лимита импорта 3 МБ.", "warn"); return; }
    try {
      const parsed = JSON.parse(await file.text());
      const raw = parsed.project || parsed;
      if (!raw || typeof raw !== "object" || !raw.name) throw new Error("Unsupported");
      const imported = normalizeProject({...raw,id:makeId(),name:`${safeText(raw.name,70)} (импорт)`});
      data.projects.unshift(imported);
      data.currentProjectId = imported.id;
      saveData();
      renderSidebar();
      renderChat();
      renderProjects();
      toast("Проект импортирован.", "success");
    } catch (_) { toast("Не удалось прочитать JSON RubAI. Исходные данные не изменены.", "error"); }
  });
  $("saveSettingsBtn").addEventListener("click", () => {
    data.settings.apiEndpoint = safeText($("modelEndpoint").value.trim(), 500);
    saveData();
    toast("Настройка сохранена. Сетевые запросы не выполняются.", "success");
  });
  $("clearAllDataBtn").addEventListener("click", async () => {
    if (!await askConfirm("Сбросить все локальные данные?", "Будут удалены все проекты, чаты, скрипты, заметки и настройки из этого браузера. Сначала экспортируйте резервную копию, если она нужна.", true)) return;
    localStorage.removeItem(STORE_KEY);
    localStorage.removeItem(LEGACY_PROJECTS);
    localStorage.removeItem(LEGACY_CURRENT);
    localStorage.removeItem(LEGACY_SETTINGS);
    data = {version:3,projects:[defaultProject()],currentProjectId:"",settings:{apiEndpoint:""}};
    data.currentProjectId = data.projects[0].id;
    selectedScriptId = null;
    saveData();
    renderSidebar();
    renderChat();
    renderProjects();
    renderScripts();
    renderReviews();
    toast("Локальные данные сброшены.", "success");
  });

  $("newScriptBtn").addEventListener("click", () => createNewScript());
  $("saveScriptBtn").addEventListener("click", saveCurrentScript);
  $("copyScriptBtn").addEventListener("click", () => copyText($("scriptEditor").value));
  $("compareVersionsBtn").addEventListener("click", compareVersions);
  $("deleteScriptBtn").addEventListener("click", async () => {
    const project = currentProject();
    const script = project.scripts.find((item) => item.id === selectedScriptId);
    if (!script || !await askConfirm("Удалить скрипт?", `«${script.name}» и его версии будут удалены из проекта.`, true)) return;
    project.scripts = project.scripts.filter((item) => item.id !== script.id);
    selectedScriptId = null;
    saveData();
    renderScripts();
    toast("Скрипт удалён.", "info");
  });
  $("scriptList").addEventListener("click", (event) => {
    const item = event.target.closest("[data-script-id]");
    if (!item) return;
    selectedScriptId = item.dataset.scriptId;
    renderScripts();
  });
  $("scriptEditor").addEventListener("input", updateEditorHighlight);
  $("scriptEditor").addEventListener("scroll", updateEditorHighlight);
  $("versionList").addEventListener("click", (event) => {
    const row = event.target.closest("[data-version-id]");
    if (!row) return;
    const script = currentProject().scripts.find((item) => item.id === selectedScriptId);
    const version = script && script.versions.find((item) => item.id === row.dataset.versionId);
    if (!version) return;
    $("scriptEditor").value = version.code;
    updateEditorHighlight();
    $("versionDiff").classList.add("hidden");
    toast("Версия загружена в редактор. Нажмите «Сохранить версию», чтобы создать новую.", "info");
  });
  $("analyzeCodeBtn").addEventListener("click", runCodeAnalysis);
  $("loadSelectedScriptBtn").addEventListener("click", () => {
    const script = currentProject().scripts.find((item) => item.id === selectedScriptId);
    if (!script) { toast("Сначала выберите скрипт в библиотеке.", "info"); return; }
    $("reviewCodeInput").value = script.code;
    toast(`Загружен ${script.name}.`, "success");
  });
  $("saveFindingsBtn").addEventListener("click", () => addFindingsToTracker());
  $("addReviewBtn").addEventListener("click", () => {
    const text = $("newReviewTitle").value.trim();
    if (!text) { toast("Введите описание замечания.", "warn"); return; }
    currentProject().reviews.unshift({id:makeId(),text:safeText(text,500),severity:$("newReviewSeverity").value,status:"open",createdAt:Date.now()});
    $("newReviewTitle").value = "";
    saveData();
    renderReviews();
    toast("Замечание добавлено.", "success");
  });
  $("reviewFilter").addEventListener("change", renderReviews);
  document.querySelectorAll("[data-code-tab]").forEach((button) => button.addEventListener("click", () => {
    const audit = button.dataset.codeTab === "audit";
    document.querySelectorAll("[data-code-tab]").forEach((tab) => tab.classList.toggle("active", tab === button));
    $("scriptsTab").classList.toggle("hidden", audit);
    $("auditTab").classList.toggle("hidden", !audit);
  }));
  $("saveContextBtn").addEventListener("keydown", (event) => { if (event.key === "Enter") event.preventDefault(); });
  $("chatHistoryList").addEventListener("click", (event) => {
    const button = event.target.closest("[data-chat-id]");
    if (button) selectChat(button.dataset.chatId);
  });
  $("projectsList").addEventListener("click", async (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const id = button.dataset.projectId;
    if (button.dataset.action === "select-project") updateProject(id);
    if (button.dataset.action === "rename-project") await renameProject(id);
    if (button.dataset.action === "delete-project") await deleteProject(id);
  });
  $("reviewList").addEventListener("click", async (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const project = currentProject();
    const review = project.reviews.find((item) => item.id === button.dataset.reviewId);
    if (!review) return;
    if (button.dataset.action === "cycle-review") {
      review.status = review.status === "open" ? "fixed" : review.status === "fixed" ? "wont" : "open";
      saveData();
      renderReviews();
    } else if (button.dataset.action === "delete-review" && await askConfirm("Удалить замечание?", "Запись будет удалена из локального трекера.", true)) {
      project.reviews = project.reviews.filter((item) => item.id !== review.id);
      saveData();
      renderReviews();
    }
  });
  $("analysisResults").addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const finding = pendingFindings.find((item) => item.id === button.dataset.findingId);
    if (!finding) return;
    if (button.dataset.action === "add-single-finding") addFindingsToTracker([finding]);
    if (button.dataset.action === "copy-fix-code") copyText(finding.fixCode);
  });
  $("messageList").addEventListener("click", async (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const chat = currentChat();
    const message = chat && chat.messages.find((item) => item.id === button.dataset.messageId);
    if (!message) return;
    if (button.dataset.action === "copy-code" && message.code) await copyText(message.code.source);
    if (button.dataset.action === "save-generated-code") saveGeneratedScript(message);
    if (button.dataset.action === "continue-plan") {
      const latest = [...chat.messages].reverse().find((item) => item.role === "user");
      await sendPrompt(`Сгенерируй Luau-код по плану для задачи: ${latest ? latest.content : currentProject().task}`, "normal");
    }
  });
  $("modalBack").addEventListener("click", (event) => { if (event.target === $("modalBack")) closeModal(null); });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && $("modalBack").classList.contains("open")) closeModal(null);
  });

  renderSidebar();
  renderChat();
  renderProjects();
  renderScripts();
  renderReviews();
  $("modelEndpoint").value = data.settings.apiEndpoint || "";
  saveData();
})();
