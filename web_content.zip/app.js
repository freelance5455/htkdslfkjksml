const $=s=>document.querySelector(s);
const screens={activation:$("#activation"),home:$("#home"),content:$("#content"),player:$("#player"),settings:$("#settings")};
const menus=[["server","CHANGE SERVER","↻"],["settings","SETTINGS","⚙"],["live","LIVE TV","▣"],["movies","MOVIES","▶"],["series","SERIES","▤"]];
const demos=[
 {title:"News Live",type:"LIVE TV",url:"https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"},
 {title:"Big Buck Bunny",type:"MOVIE",url:"https://test-streams.mux.dev/bbb-360p/bbb-360p.m3u8"},
 {title:"Sample Stream",type:"SERIES",url:"https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"}];
let sel=2;
function did(){let x=localStorage.mytvDevice;if(!x){x="TV-"+crypto.randomUUID().replaceAll("-","").slice(0,12).toUpperCase();localStorage.mytvDevice=x}return x}
function show(n){Object.values(screens).forEach(x=>x.classList.add("hidden"));screens[n].classList.remove("hidden")}
function render(){const m=$("#menu");m.innerHTML="";menus.forEach((x,i)=>{let d=document.createElement("div");d.className="tile"+(i===sel?" active":"");d.tabIndex=0;d.innerHTML='<div class="icon">'+x[2]+'</div><b>'+x[1]+'</b>';d.onclick=()=>open(i);d.onfocus=()=>{sel=i;render()};m.appendChild(d)});setTimeout(()=>m.children[sel]?.scrollIntoView({inline:"center",behavior:"smooth"}),10)}
function open(i){sel=i;render();let id=menus[i][0];if(id==="settings"||id==="server"){loadSettings();show("settings")}else content(id)}
function content(type){$("#title").textContent=type==="live"?"LIVE TV":type.toUpperCase();let g=$("#grid");g.innerHTML="";let a=demos.filter(x=>type==="live"?x.type==="LIVE TV":type==="movies"?x.type==="MOVIE":type==="series"?x.type==="SERIES":true);if(!a.length)a=demos;a.forEach(x=>{let d=document.createElement("div");d.className="item";d.tabIndex=0;d.innerHTML='<h3>'+x.title+'</h3><p>'+x.type+' · Demo</p>';d.onclick=()=>play(x);g.appendChild(d)});show("content");g.firstElementChild?.focus()}
function play(x){$("#playing").textContent=x.title;$("#video").src=x.url;show("player");$("#video").play().catch(()=>{})}
async function activate(){let k=$("#key").value.trim();if(!k){$("#msg").textContent="Bitte Schlüssel eingeben.";return}let api=(localStorage.mytvApi||"").replace(/\/$/,"");if(!api){if(k.toUpperCase()==="DEMO"){localStorage.mytvToken="demo";start()}else $("#msg").textContent="Keine API hinterlegt. Für einen Test DEMO eingeben.";return}try{let r=await fetch(api+"/api/v1/activation",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({deviceId:did(),key:k})});let j=await r.json();if(!r.ok)throw Error(j.error||"Aktivierung fehlgeschlagen");localStorage.mytvToken=j.token||"active";start()}catch(e){$("#msg").textContent=e.message}}
function start(){show("home");$("#status").textContent=localStorage.mytvToken==="demo"?"DEMO":"AKTIV";render();clock()}
function clock(){let d=new Date();$("#time").textContent=d.toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"});$("#date").textContent=d.toLocaleDateString("de-DE",{weekday:"short",day:"2-digit",month:"2-digit"});setTimeout(clock,1000)}
function loadSettings(){$("#api").value=localStorage.mytvApi||"";$("#sd").textContent=did();$("#ss").textContent=localStorage.mytvToken?"AKTIV":"NICHT AKTIV"}
$("#deviceId").value=did();$("#activate").onclick=activate;$("#demo").onclick=()=>{localStorage.mytvToken="demo";start()};$("#copy").onclick=()=>navigator.clipboard?.writeText(did());
$("#prev").onclick=()=>{sel=(sel+4)%5;render()};$("#next").onclick=()=>{sel=(sel+1)%5;render()};
$("#back").onclick=()=>show("home");$("#pback").onclick=()=>{$("#video").pause();show("content")};$("#sback").onclick=()=>show("home");
$("#save").onclick=()=>{localStorage.mytvApi=$("#api").value.trim();alert("API-Adresse gespeichert.")};
$("#reset").onclick=()=>{if(confirm("Lokale App-Daten löschen?")){localStorage.clear();location.reload()}};
document.addEventListener("keydown",e=>{if(e.key==="ArrowRight"&&!screens.home.classList.contains("hidden")){sel=(sel+1)%5;render()}if(e.key==="ArrowLeft"&&!screens.home.classList.contains("hidden")){sel=(sel+4)%5;render()}if(e.key==="Enter"&&!screens.home.classList.contains("hidden"))open(sel);if(e.key==="Escape"){if(!screens.player.classList.contains("hidden")){$("#video").pause();show("content")}else if(!screens.content.classList.contains("hidden")||!screens.settings.classList.contains("hidden"))show("home")}});
if(localStorage.mytvToken)start();else show("activation");
