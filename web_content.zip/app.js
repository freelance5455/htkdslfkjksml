/* National Digital Identity Wallet concept. No real authentication, camera or credential. */
(() => {
  'use strict';
  const root = document.getElementById('view');
  const storage = window.gryphon?.storage;
  const profile = Object.freeze({ firstname: 'Amara', middlename: 'Nia', surname: 'Mensah', dateOfBirth: '1994-08-17', phoneNumber: '+233 24 555 0182', cityOrDistrict: 'Accra Metropolitan', community: 'Osu', nationality: 'Ghanaian' });
  const state = { screen: 'identify', id: '', consent: false, step: 0, password: null, passwordError: '', qrNonce: 0, qrSeconds: 30 };
  let qrTimer = null, qrDeadline = 0, toastTimer = null;
  const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[ch]);

  // Clear the earlier prototype's persisted raw ID; identity numbers stay session-only.
  async function init() {
    try { await storage?.remove('identity-wallet-demo-v1'); } catch { /* Storage is optional. */ }
    render();
  }
  function progress(active) {
    const labels = ['Enter ID', 'Live check', 'Secure match'];
    return `<div class="steps" aria-label="Verification steps">${labels.map((label, i) => `${i ? '<span class="connector"></span>' : ''}<span class="step ${i < active ? 'done' : ''} ${i === active ? 'active' : ''}"><i>${i < active ? '✓' : i + 1}</i>${label}</span>`).join('')}</div>`;
  }
  function identifyView() {
    return `<div class="welcome"><div class="eyebrow">A simpler way to prove who you are</div><h1>Your identity.<br>In your hands.</h1><p>A considered home for your national identity credentials, designed around your privacy.</p></div>
      <div class="secure-note"><span class="shield">♢</span><span><b>Private by design.</b> This concept uses sample information and does not contact a government identity service.</span></div>
      <div class="form-card"><label for="nin">National ID number</label><div class="input-wrap"><input id="nin" type="text" autocomplete="off" autocapitalize="characters" maxlength="8" placeholder="8 characters" value="${esc(state.id)}" aria-describedby="nin-hint" aria-label="8-character National ID number"></div><div class="hint" id="nin-hint">Exactly 8 letters or numbers · uppercase</div>
      <label class="consent"><input id="consent" type="checkbox" ${state.consent ? 'checked' : ''}><span>I understand this is a concept demo. No real biometric check or identity lookup will take place.</span></label><button class="primary" id="continue" type="button">Continue to identity check <span aria-hidden="true">→</span></button><p class="error" id="entry-error" role="alert"></p><p class="secure-caption">♢ &nbsp; Verification flow is illustrative only</p></div>${progress(0)}`;
  }
  const prompts = [{ icon: '◉', title: 'Look at the camera', detail: 'Center your face in the frame' }, { icon: '↗', title: 'Turn your head gently', detail: 'Follow the on-screen prompt' }, { icon: '⌒', title: 'Blink naturally', detail: 'A final presence check' }];
  function livenessView() {
    const finished = state.step >= prompts.length;
    const items = prompts.map((item, i) => `<div class="motion ${i < state.step ? 'done' : ''} ${i === state.step && !finished ? 'active' : ''}"><span class="motion-icon">${i < state.step ? '✓' : item.icon}</span><span><strong>${item.title}</strong><small>${i < state.step ? 'Complete' : item.detail}</small></span></div>`).join('');
    return `<div class="verify-head"><div class="camera-icon">${finished ? '✓' : '◉'}</div><h1>${finished ? 'Presence check complete' : 'Let’s verify it’s you'}</h1><p>${finished ? 'The demo sequence is complete. Continue to the simulated verification step.' : 'Follow the prompts. A real wallet would use a trusted biometric provider.'}</p></div>
      <div class="camera-box" role="img" aria-label="Illustrative camera frame; no camera is active"><div class="camera-silhouette"></div><span class="camera-caption">Illustration only · camera inactive</span></div><div class="motion-list">${items}</div>
      <div class="demo-warning"><b>Prototype only:</b> No camera access, liveness detection or biometric capture occurs.</div><button class="primary" id="liveness-action" type="button">${finished ? 'Continue to demo match →' : state.step === 0 ? 'Start guided demo' : 'Next demo prompt →'}</button><button class="secondary" id="back" type="button" style="margin-top:9px">Back</button>${progress(1)}`;
  }
  function validationView() {
    return `<div class="verify-head" style="padding-top:40px"><div class="camera-icon">◌</div><h1>Checking your details</h1><p>Simulated concept response. No remote identity server is connected.</p></div><div class="form-card" style="text-align:center"><div style="font-size:13px;color:#536d8c;line-height:1.7">Demo ID<br><b style="color:#1b3c67;letter-spacing:1px">${esc(state.id)}</b></div><div class="demo-warning" style="text-align:left;margin-top:18px">This is not a real authentication result.</div><button class="primary" id="show-demo-wallet" type="button">Continue to sample wallet</button><button class="secondary" id="cancel-check" type="button" style="margin-top:9px">Cancel</button></div>${progress(2)}`;
  }
  function passwordView(setup) {
    return `<div class="verify-head" style="padding-top:38px"><div class="camera-icon">${setup ? '♢' : '⌑'}</div><h1>${setup ? 'Set wallet password' : 'Unlock your wallet'}</h1><p>${setup ? 'Create a password for this demo session. You will need it after locking the wallet.' : 'Enter your password to return to your saved demo wallet.'}</p></div>
      <div class="form-card"><label for="wallet-password">${setup ? 'Create password' : 'Wallet password'}</label><div class="input-wrap"><input id="wallet-password" type="password" autocomplete="${setup ? 'new-password' : 'current-password'}" maxlength="128" placeholder="${setup ? 'At least 8 characters' : 'Enter your password'}"></div>${setup ? '<p class="hint">Use at least 8 characters for this demo.</p>' : ''}<p class="error" id="password-error" role="alert">${esc(state.passwordError)}</p><button class="primary" id="password-action" type="button">${setup ? 'Set password and open wallet' : 'Unlock wallet'}</button><button class="secondary" id="password-cancel" type="button" style="margin-top:9px">${setup ? 'Cancel' : 'Return to start'}</button></div>
      <div class="demo-warning" style="margin-top:14px"><b>Demo limitation:</b> Password is held in page memory, not secure storage, and clears when the page reloads.</div>`;
  }
  function portrait() {
    return `<svg viewBox="0 0 60 80" role="img" aria-label="Illustrative profile avatar"><ellipse cx="30" cy="26" rx="15" ry="18" fill="#e7c3a6"/><path d="M15 25c0-17 8-22 17-21 11 1 15 10 13 22-4-8-10-10-17-10-4 0-9 5-13 9z" fill="#273c53"/><path d="M7 78c1-20 10-29 23-29s22 9 23 29" fill="#587ba5"/><path d="M24 39q6 5 12 0" stroke="#ad725e" stroke-width="1.5" fill="none" stroke-linecap="round"/><circle cx="24" cy="28" r="1.4" fill="#453b3a"/><circle cx="36" cy="28" r="1.4" fill="#453b3a"/></svg>`;
  }
  // Decorative, non-scannable QR-style image; refresh is visual, not credential issuance.
  function decorativeMatrix(seed) {
    let n = 2166136261;
    for (const c of seed) n = Math.imul(n ^ c.charCodeAt(0), 16777619) >>> 0;
    const size = 21, cell = 5, quiet = 2, canvas = document.createElement('canvas');
    canvas.width = canvas.height = (size + quiet * 2) * cell;
    const ctx = canvas.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    function finder(x, y) {
      ctx.fillStyle = '#17355b'; ctx.fillRect((x + quiet) * cell, (y + quiet) * cell, 7 * cell, 7 * cell);
      ctx.fillStyle = '#fff'; ctx.fillRect((x + 1 + quiet) * cell, (y + 1 + quiet) * cell, 5 * cell, 5 * cell);
      ctx.fillStyle = '#17355b'; ctx.fillRect((x + 2 + quiet) * cell, (y + 2 + quiet) * cell, 3 * cell, 3 * cell);
    }
    finder(0, 0); finder(size - 7, 0); finder(0, size - 7);
    const reserved = (x, y) => (x < 8 && y < 8) || (x >= size - 8 && y < 8) || (x < 8 && y >= size - 8);
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
      n = (Math.imul(n, 1664525) + 1013904223) >>> 0;
      if (!reserved(x, y) && (n & 3) < 2) { ctx.fillStyle = '#17355b'; ctx.fillRect((x + quiet) * cell, (y + quiet) * cell, cell, cell); }
    }
    return canvas.toDataURL('image/png');
  }
  function walletView() {
    const fullName = [profile.firstname, profile.middlename, profile.surname].filter(Boolean).join(' ');
    const image = decorativeMatrix(`${state.id}:${fullName}:${state.qrNonce}`);
    return `<div class="wallet-title"><div><div class="eyebrow">YOUR IDENTITY WALLET</div><h1>Good morning</h1></div><span class="verified">✓ Demo profile</span></div>
      <article class="id-card" aria-label="Sample digital identity card"><div class="card-top"><span class="card-brand">NATIONAL DIGITAL IDENTITY</span><span class="card-mark">✳</span></div><div class="card-main"><div class="portrait">${portrait()}</div><div><div class="card-label">FULL NAME</div><div class="card-name">${esc(fullName)}</div><div class="card-label">NATIONAL ID NUMBER</div><div class="card-nin">${esc(state.id)}</div></div></div><div class="card-bottom"><span>PERSONAL CREDENTIAL · CONCEPT</span><span>✧ SECURE DESIGN</span></div></article>
      <section class="panel"><h2>Identity details</h2><div class="fields"><div><div class="field-label">FIRSTNAME</div><div class="field-value">${esc(profile.firstname)}</div></div><div><div class="field-label">MIDDLENAME</div><div class="field-value">${esc(profile.middlename)}</div></div><div><div class="field-label">SURNAME</div><div class="field-value">${esc(profile.surname)}</div></div><div><div class="field-label">DATE OF BIRTH</div><div class="field-value">${esc(profile.dateOfBirth.split('-').reverse().join('/'))}</div></div><div><div class="field-label">PHONE NUMBER</div><div class="field-value">${esc(profile.phoneNumber)}</div></div><div><div class="field-label">NATIONALITY</div><div class="field-value">${esc(profile.nationality)}</div></div><div style="grid-column:1/-1"><div class="field-label">PLACE OF RESIDENCE</div><div class="field-value">${esc(profile.cityOrDistrict)} · ${esc(profile.community)}</div></div></div></section>
      <section class="panel"><h2>Verification preview</h2><div class="qr-panel"><div class="qr-box"><img alt="Decorative QR-style illustration, not scannable" width="80" height="80" src="${image}"></div><div class="qr-info"><strong>Demo preview · refreshes in <span id="qr-countdown">${state.qrSeconds}</span>s</strong><span class="qr-status">Not a real credential or scannable code</span><br>No verification token has been issued.</div></div></section>
      <div class="demo-warning"><b>Sample data:</b> This prototype is not connected to a government registry, does not verify identity, and is not official ID.</div><div class="actions"><button class="secondary" id="lock-wallet" type="button">Lock wallet</button></div><p class="card-disclaimer">Concept preview · Identity details are read-only sample information.</p>`;
  }
  function render() {
    const screens = { identify: identifyView, liveness: livenessView, validating: validationView, setup: () => passwordView(true), unlock: () => passwordView(false), wallet: walletView };
    root.innerHTML = (screens[state.screen] || identifyView)(); bind();
  }
  function openWallet() {
    state.passwordError = ''; state.screen = 'wallet'; state.qrNonce++; startQrRefresh(); render();
  }
  function startQrRefresh() {
    stopQrRefresh(); qrDeadline = Date.now() + 30_000; state.qrSeconds = 30;
    qrTimer = setInterval(() => {
      if (state.screen !== 'wallet') { stopQrRefresh(); return; }
      const expired = Date.now() >= qrDeadline;
      if (expired) { state.qrNonce++; qrDeadline = Date.now() + 30_000; }
      state.qrSeconds = Math.max(1, Math.ceil((qrDeadline - Date.now()) / 1000));
      const countdown = root.querySelector('#qr-countdown');
      if (countdown) countdown.textContent = String(state.qrSeconds);
      const image = root.querySelector('.qr-box img');
      if (expired && image) image.src = decorativeMatrix(`${state.id}:${profile.firstname}:${state.qrNonce}`);
    }, 1000);
  }
  function stopQrRefresh() { if (qrTimer !== null) clearInterval(qrTimer); qrTimer = null; }
  function lockWallet() { stopQrRefresh(); state.passwordError = ''; state.screen = 'unlock'; render(); }
  function submitPassword() {
    const value = document.getElementById('wallet-password')?.value ?? '';
    if (state.screen === 'setup') {
      if (value.length < 8) { state.passwordError = 'Use at least 8 characters for the demo password.'; render(); document.getElementById('wallet-password')?.focus(); return; }
      state.password = value; openWallet(); return;
    }
    if (state.screen === 'unlock') {
      if (value !== state.password) { state.passwordError = 'Incorrect password. Try again.'; render(); document.getElementById('wallet-password')?.focus(); return; }
      openWallet();
    }
  }
  function bind() {
    const idInput = document.getElementById('nin');
    if (idInput) {
      idInput.addEventListener('input', () => {
        const value = idInput.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
        if (idInput.value !== value) idInput.value = value;
        state.id = value;
        const error = document.getElementById('entry-error'); if (error) error.textContent = '';
      });
      document.getElementById('consent').addEventListener('change', e => { state.consent = e.target.checked; });
      document.getElementById('continue').addEventListener('click', () => {
        const error = document.getElementById('entry-error');
        if (!/^[A-Z0-9]{8}$/.test(state.id)) { error.textContent = 'Enter exactly 8 letters or numbers.'; idInput.focus(); return; }
        if (!state.consent) { error.textContent = 'Please acknowledge the concept-demo notice to continue.'; return; }
        state.screen = 'liveness'; state.step = 0; render();
      });
      idInput.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('continue').click(); });
    }
    document.getElementById('liveness-action')?.addEventListener('click', () => { if (state.step < 3) { state.step++; render(); } else { state.screen = 'validating'; render(); } });
    document.getElementById('back')?.addEventListener('click', () => { state.screen = 'identify'; render(); });
    document.getElementById('show-demo-wallet')?.addEventListener('click', () => { state.passwordError = ''; state.screen = state.password === null ? 'setup' : 'unlock'; render(); });
    document.getElementById('cancel-check')?.addEventListener('click', () => { state.screen = 'identify'; render(); });
    document.getElementById('lock-wallet')?.addEventListener('click', lockWallet);
    document.getElementById('password-action')?.addEventListener('click', submitPassword);
    document.getElementById('wallet-password')?.addEventListener('keydown', e => { if (e.key === 'Enter') submitPassword(); });
    document.getElementById('password-cancel')?.addEventListener('click', () => { state.passwordError = ''; state.screen = 'identify'; render(); });
  }
  function toast(message) {
    document.querySelector('.toast')?.remove(); const node = document.createElement('div');
    node.className = 'toast'; node.setAttribute('role', 'status'); node.textContent = message; document.body.appendChild(node);
    clearTimeout(toastTimer); toastTimer = setTimeout(() => node.remove(), 2600);
  }
  window.addEventListener('pagehide', stopQrRefresh);
  init();
})();
