const $=id=>document.getElementById(id);
const chat=$('chat');let speakEnabled=true;let browserApiKey='';
let history=JSON.parse(localStorage.getItem('jarvis_history')||'[]');
const pending={};
function addMessage(role,text,save=true){
  const el=document.createElement('div');el.className='message '+role;
  const name=document.createElement('b');name.textContent=role==='bot'?'JARVIS':'TÚ';
  const p=document.createElement('p');p.textContent=text;el.append(name,p);chat.append(el);chat.scrollTop=chat.scrollHeight;
  if(save){history.push({role,text});history=history.slice(-80);localStorage.setItem('jarvis_history',JSON.stringify(history));}
  return {el,p};
}
history.forEach(m=>addMessage(m.role,m.text,false));
function localAnswer(q){
  const s=q.toLowerCase().trim();
  if(/^(hola|buenas|hey)\b/.test(s))return'Hola. Estoy operativo. ¿Qué necesitas?';
  if(s.includes('hora'))return'La hora de tu dispositivo es '+new Date().toLocaleTimeString('es-ES')+'.';
  if(s.includes('fecha')||s.includes('día de hoy'))return'Hoy es '+new Date().toLocaleDateString('es-ES',{weekday:'long',year:'numeric',month:'long',day:'numeric'})+'.';
  if(s.includes('quién eres')||s.includes('quien eres'))return'Soy JARVIS, tu asistente personal. Puedo usar un modelo local en el teléfono o un proveedor online configurable.';
  if(s.includes('ayuda')||s.includes('qué puedes hacer'))return'Puedo conversar con el modelo local LiteRT-LM si importas un archivo .litertlm, usar una IA online configurable, hablar mediante la voz de Android y recordar el historial local.';
  const m=s.match(/(?:cuánto es|cuanto es|calcula)\s+([\d+\-*\/().\s]+)$/);
  if(m){try{const expr=m[1];if(!/^[\d+\-*\/().\s]+$/.test(expr))throw 0;const val=Function('"use strict";return ('+expr+')')();if(Number.isFinite(val))return'El resultado es '+val+'.';}catch(e){}}
  return'No hay un modelo de IA local cargado. Importa un archivo .litertlm desde Ajustes o configura un proveedor online.';
}
function startLocalStream(id){
  const item=addMessage('bot','Pensando…',false);pending[id]={p:item.p,el:item.el,text:'',prompt:''};
}
function saveStream(id,text){history.push({role:'bot',text});history=history.slice(-80);localStorage.setItem('jarvis_history',JSON.stringify(history));}
function ask(q){
  const mode=$('mode').value;
  const android=!!window.AndroidJarvis;
  const hasLocal=android&&AndroidJarvis.hasLocalModel();
  const endpoint=$('endpoint').value.trim(),model=$('model').value.trim();
  const hasOnline=android&&endpoint&&model&&AndroidJarvis.hasApiKey();
  if((mode==='local'||mode==='hybrid')&&hasLocal){
    const id='l'+Date.now();startLocalStream(id);pending[id].prompt=q;$('engineState').textContent='LITERT LOCAL';$('status').textContent='IA EN EL DISPOSITIVO';
    AndroidJarvis.askLocal(id,q);return;
  }
  if(mode==='local'){
    addMessage('bot',android?'Importa primero un modelo .litertlm en Ajustes.':'El modo IA local necesita abrir JARVIS dentro de la aplicación Android.');return;
  }
  if((mode==='online'||mode==='hybrid')&&hasOnline){
    const id='r'+Date.now();pending[id]=true;$('engineState').textContent='ONLINE';$('status').textContent='CONSULTANDO IA';
    AndroidJarvis.askAI(id,q,endpoint,model);return;
  }
  if(mode==='hybrid'&&!hasLocal&&!hasOnline){
    addMessage('bot',localAnswer(q)+' Configura la conexión online o importa el modelo local.');return;
  }
  addMessage('bot',localAnswer(q));
}
function aiResult(id,text,error){
  if(!pending[id])return;delete pending[id];$('status').textContent=error?'REVISAR CONEXIÓN':'IA CONECTADA';
  $('engineState').textContent=error?'SIN CONEXIÓN':'ONLINE';addMessage('bot',text);if(speakEnabled)speak(text);
}
function localChunk(id,chunk){
  const item=pending[id];if(!item||item===true)return;item.text+=chunk;item.p.textContent=item.text;chat.scrollTop=chat.scrollHeight;
}
function localResult(id,text,error){
  const item=pending[id];if(!item)return;const originalPrompt=item.prompt||'';delete pending[id];
  item.p.textContent=text|| (error?'No se pudo completar la respuesta.':'');
  if(!error){saveStream(id,text);$('status').textContent='IA LOCAL LISTA';$('engineState').textContent='LITERT LOCAL';if(speakEnabled)speak(text);}
  else{
    const endpoint=$('endpoint').value.trim(),model=$('model').value.trim();
    if($('mode').value==='hybrid'&&window.AndroidJarvis&&endpoint&&model&&AndroidJarvis.hasApiKey()){
      const prompt=originalPrompt;item.el.remove();const remoteId='r'+Date.now();pending[remoteId]=true;$('status').textContent='RESPALDO ONLINE';$('engineState').textContent='ONLINE';AndroidJarvis.askAI(remoteId,prompt,endpoint,model);
    }else{$('status').textContent='ERROR MOTOR LOCAL';$('engineState').textContent='REVISAR MODELO';}
  }
}
function modelStatus(text,error){$('modelStatus').textContent=text;$('modelStatus').style.color=error?'#ff9b9b':'#9bc7d7';}
function speak(text){if(window.AndroidJarvis)AndroidJarvis.speak(text);else if('speechSynthesis'in window){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(text));}}
function voiceResult(text){$('prompt').value=text;voiceStatus('Texto reconocido');$('form').requestSubmit();}
function voiceStatus(text){$('voiceState').textContent=text.toUpperCase().slice(0,18);$('subtitle').textContent=text;}
$('form').addEventListener('submit',e=>{e.preventDefault();const q=$('prompt').value.trim();if(!q)return;addMessage('user',q);$('prompt').value='';ask(q);});
$('mic').onclick=()=>{if(window.AndroidJarvis)AndroidJarvis.startVoiceInput();else if('webkitSpeechRecognition'in window){const r=new webkitSpeechRecognition();r.lang='es-ES';r.onresult=e=>voiceResult(e.results[0][0].transcript);r.start();}else voiceStatus('Voz no disponible en este navegador');};
$('speak').onclick=()=>{speakEnabled=!speakEnabled;$('speak').textContent=speakEnabled?'🔊 VOZ: ACTIVADA':'🔇 VOZ: DESACTIVADA';};
$('stop').onclick=()=>{if(window.AndroidJarvis)AndroidJarvis.stopSpeaking();else if('speechSynthesis'in window)speechSynthesis.cancel();};
$('clear').onclick=()=>{history=[];localStorage.removeItem('jarvis_history');chat.innerHTML='';};
$('save').onclick=()=>{localStorage.setItem('jarvis_mode',$('mode').value);localStorage.setItem('jarvis_endpoint',$('endpoint').value);localStorage.setItem('jarvis_model',$('model').value);if(window.AndroidJarvis)AndroidJarvis.saveApiKey($('key').value);else browserApiKey=$('key').value.trim();$('key').value='';$('status').textContent='AJUSTES GUARDADOS';$('engineState').textContent=$('mode').value.toUpperCase();};
$('importModel').onclick=()=>{if(window.AndroidJarvis)AndroidJarvis.chooseLocalModel();else modelStatus('La importación de modelos funciona dentro de la app Android.',true);};
$('removeModel').onclick=()=>{if(window.AndroidJarvis)AndroidJarvis.removeLocalModel();else modelStatus('Disponible dentro de la app Android.',true);};
$('mode').value=localStorage.getItem('jarvis_mode')||'hybrid';$('endpoint').value=localStorage.getItem('jarvis_endpoint')||'';$('model').value=localStorage.getItem('jarvis_model')||'';
if(!window.AndroidJarvis){$('status').textContent='VISTA WEB';$('subtitle').textContent='Vista previa: motor local y funciones del teléfono disponibles en la app Android.';modelStatus('Importa el modelo desde la aplicación Android instalada.',false);}
