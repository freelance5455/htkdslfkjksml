/**
 * AETHER UNIVERSE AI - Ultimate Engine Client-Side
 * Gestion de l'UI, du stockage local, des générateurs et de la liaison serveur.
 */

// État global de l'application
const state = {
    currentView: 'home',
    activeChat: null,
    chats: JSON.parse(localStorage.getItem('aether_chats')) || [],
    universes: JSON.parse(localStorage.getItem('aether_universes')) || [],
    characters: JSON.parse(localStorage.getItem('aether_characters')) || [],
    creations: JSON.parse(localStorage.getItem('aether_creations')) || [],
    settings: JSON.parse(localStorage.getItem('aether_settings')) || {
        serverUrl: 'https://nova-ia-685i.onrender.com',
        apiKey: '',
        model: 'default',
        offlineMode: false
    }
};

// Initialisation au chargement
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const splash = document.getElementById('splash-screen');
        if (splash) {
            splash.style.opacity = '0';
            setTimeout(() => splash.remove(), 400);
        }
    }, 800);

    setupEventListeners();
    navigateTo('home');
});

function setupEventListeners() {
    const menuBtn = document.getElementById('menu-btn');
    const closeSidebar = document.getElementById('close-sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const sidebar = document.getElementById('sidebar');

    const toggleMenu = (open) => {
        if (open) {
            overlay.classList.remove('hidden');
            setTimeout(() => overlay.classList.remove('opacity-0'), 10);
            sidebar.classList.remove('-translate-x-full');
        } else {
            overlay.classList.add('opacity-0');
            sidebar.classList.add('-translate-x-full');
            setTimeout(() => overlay.classList.add('hidden'), 300);
        }
    };

    menuBtn?.addEventListener('click', () => toggleMenu(true));
    closeSidebar?.addEventListener('click', () => toggleMenu(false));
    overlay?.addEventListener('click', () => toggleMenu(false));
}

function closeMenu() {
    const overlay = document.getElementById('sidebar-overlay');
    const sidebar = document.getElementById('sidebar');
    if (overlay && sidebar) {
        overlay.classList.add('opacity-0');
        sidebar.classList.add('-translate-x-full');
        setTimeout(() => overlay.classList.add('hidden'), 300);
    }
}

// Routeur principal
function navigateTo(viewId, param = null) {
    state.currentView = viewId;
    const main = document.getElementById('main-content');
    
    // MAJ de la navbar active
    document.querySelectorAll('nav button').forEach(btn => {
        btn.classList.remove('text-cyan-400');
        btn.classList.add('text-gray-400');
    });
    
    const activeNav = document.getElementById(`nav-${viewId === 'creation' ? 'creation' : viewId === 'media' ? 'media' : viewId === 'library' ? 'library' : viewId === 'settings' ? 'settings' : 'home'}`);
    if (activeNav) {
        activeNav.classList.remove('text-gray-400');
        activeNav.classList.add('text-cyan-400');
    }

    main.innerHTML = '';
    const container = document.createElement('div');
    container.className = 'p-4 animate-fade-in space-y-4';

    switch(viewId) {
        case 'home':
            renderHome(container);
            break;
        case 'creation':
            renderCerveauAI(container, param);
            break;
        case 'universe':
            renderUniverseBuilder(container);
            break;
        case 'characters':
            renderCharacterCreator(container);
            break;
        case 'manga':
            renderMangaStudio(container);
            break;
        case 'media':
            renderMediaStudio(container);
            break;
        case 'library':
            renderLibrary(container);
            break;
        case 'settings':
            renderSettings(container);
            break;
        default:
            renderHome(container);
    }

    main.appendChild(container);
}

// ================= VUE ACCUEIL =================
function renderHome(container) {
    container.innerHTML = `
        <div class="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-900/60 via-purple-900/40 to-slate-900 p-6 border border-indigo-500/30 shadow-xl">
            <div class="absolute -right-6 -bottom-6 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl"></div>
            <span class="px-3 py-1 text-[10px] font-semibold bg-cyan-500/20 text-cyan-300 rounded-full uppercase tracking-wider border border-cyan-500/30">Studio Multimédia IA</span>
            <h1 class="text-2xl font-bold mt-3 text-white">AETHER UNIVERSE</h1>
            <p class="text-xs text-slate-300 mt-1 leading-relaxed">Concevez des univers narratifs profonds, des mangas, des fiches personnages et pilotez vos créations multimédias.</p>
            <div class="flex items-center space-x-3 mt-5">
                <button onclick="navigateTo('creation')" class="flex-1 py-3 px-4 bg-gradient-to-r from-cyan-500 to-indigo-600 rounded-xl font-semibold text-xs text-white shadow-lg shadow-cyan-500/20 flex items-center justify-center space-x-2 active:scale-95 transition">
                    <i class="fa-solid fa-plus"></i>
                    <span>Nouvelle Création</span>
                </button>
                <button onclick="navigateTo('universe')" class="py-3 px-4 bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 rounded-xl font-semibold text-xs text-slate-200 flex items-center justify-center space-x-2 active:scale-95 transition">
                    <i class="fa-solid fa-globe text-purple-400"></i>
                    <span>Bâtir un Univers</span>
                </button>
            </div>
        </div>

        <h2 class="text-xs font-bold uppercase tracking-wider text-slate-400 pt-2">Accès Rapides & Modules</h2>
        
        <div class="grid grid-cols-2 gap-3">
            <div onclick="navigateTo('universe')" class="glass-card p-4 rounded-xl cursor-pointer hover:border-purple-500/50 transition group">
                <div class="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center text-purple-400 mb-3 group-hover:scale-110 transition">
                    <i class="fa-solid fa-globe text-lg"></i>
                </div>
                <h3 class="font-bold text-sm text-white">Univers Fictifs</h3>
                <p class="text-[11px] text-slate-400 mt-0.5">Continents, magies et factions.</p>
            </div>

            <div onclick="navigateTo('characters')" class="glass-card p-4 rounded-xl cursor-pointer hover:border-indigo-500/50 transition group">
                <div class="w-10 h-10 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400 mb-3 group-hover:scale-110 transition">
                    <i class="fa-solid fa-user-shield text-lg"></i>
                </div>
                <h3 class="font-bold text-sm text-white">Personnages</h3>
                <p class="text-[11px] text-slate-400 mt-0.5">Fiches détaillées & pouvoirs.</p>
            </div>

            <div onclick="navigateTo('manga')" class="glass-card p-4 rounded-xl cursor-pointer hover:border-pink-500/50 transition group">
                <div class="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center text-pink-400 mb-3 group-hover:scale-110 transition">
                    <i class="fa-solid fa-book-open text-lg"></i>
                </div>
                <h3 class="font-bold text-sm text-white">Manga & Webtoon</h3>
                <p class="text-[11px] text-slate-400 mt-0.5">Planches et découpage scènes.</p>
            </div>

            <div onclick="navigateTo('media')" class="glass-card p-4 rounded-xl cursor-pointer hover:border-amber-500/50 transition group">
                <div class="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center text-amber-400 mb-3 group-hover:scale-110 transition">
                    <i class="fa-solid fa-clapperboard text-lg"></i>
                </div>
                <h3 class="font-bold text-sm text-white">Média Studio</h3>
                <p class="text-[11px] text-slate-400 mt-0.5">Images, Vidéo & Voix audio.</p>
            </div>
        </div>
    `;
}

// ================= VUE CERVEAU IA (Chat) =================
function renderCerveauAI(container, chatId) {
    if (!chatId && state.chats.length === 0) {
        createNewChat("Discussion Initiale");
        chatId = state.chats[0].id;
    } else if (!chatId) {
        chatId = state.chats[0].id;
    }
    state.activeChat = state.chats.find(c => c.id === chatId) || state.chats[0];

    container.innerHTML = `
        <div class="flex flex-col h-[calc(100vh-8.5rem)]">
            <div class="flex items-center justify-between pb-3 border-b border-slate-800">
                <div class="flex items-center space-x-2">
                    <span class="text-xs font-semibold text-cyan-400 uppercase tracking-wider">Cerveau Central</span>
                    <span class="text-xs text-slate-500">•</span>
                    <span class="text-xs text-slate-300 truncate max-w-[150px]">${state.activeChat.title}</span>
                </div>
                <button onclick="createNewChat('Nouvelle Discussion')" class="text-xs text-cyan-400 bg-cyan-500/10 hover:bg-cyan-500/20 px-3 py-1 rounded-lg transition font-medium">
                    + Nouveau
                </button>
            </div>

            <div id="chat-messages" class="flex-1 overflow-y-auto py-4 space-y-4">
                ${state.activeChat.messages.length === 0 ? `
                    <div class="text-center py-10 px-4">
                        <div class="w-12 h-12 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center mx-auto mb-3">
                            <i class="fa-solid fa-brain text-xl"></i>
                        </div>
                        <h3 class="text-sm font-bold text-white">Aether Cerveau Prêt</h3>
                        <p class="text-xs text-slate-400 mt-1">Posez vos questions, écrivez une histoire ou développez un univers complexe.</p>
                    </div>
                ` : state.activeChat.messages.map(m => `
                    <div class="flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}">
                        <div class="max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${m.role === 'user' ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-none'}">
                            ${m.content}
                        </div>
                    </div>
                `).join('')}
            </div>

            <div class="pt-2 border-t border-slate-800">
                <form onsubmit="handleChatSubmit(event)" class="flex items-center space-x-2">
                    <input type="text" id="chat-input" placeholder="Écrivez votre message..." class="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:border-cyan-500 transition">
                    <button type="submit" class="w-11 h-11 bg-gradient-to-tr from-cyan-500 to-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg active:scale-95 transition">
                        <i class="fa-solid fa-paper-plane text-xs"></i>
                    </button>
                </form>
            </div>
        </div>
    `;
    scrollToBottom();
}

function createNewChat(title) {
    const newChat = {
        id: 'chat_' + Date.now(),
        title: title,
        messages: []
    };
    state.chats.unshift(newChat);
    saveState();
    navigateTo('creation', newChat.id);
}

function handleChatSubmit(event) {
    event.preventDefault();
    const input = document.getElementById('chat-input');
    const text = input.value.trim();
    if (!text || !state.activeChat) return;

    state.activeChat.messages.push({ role: 'user', content: text });
    input.value = '';
    renderCerveauAI(document.getElementById('main-content'), state.activeChat.id);

    // Simulation de réponse intelligente connectée ou locale sécurisée
    setTimeout(() => {
        let reply = "Analyse reçue par Aether Cerveau. Je traite votre demande selon les paramètres de cohérence narrative.";
        if (text.toLowerCase().includes('univers') || text.toLowerCase().includes('monde')) {
            reply = "Module Univers actif : Pour créer un univers cohérent, définissez sa géographie, ses lois physiques et ses factions politiques.";
        } else if (text.toLowerCase().includes('personnage') || text.toLowerCase().includes('héros')) {
            reply = "Module Personnage actif : Définissez ses motivations profondes, ses pouvoirs et son évolution psychologique.";
        }
        state.activeChat.messages.push({ role: 'assistant', content: reply });
        saveState();
        renderCerveauAI(document.getElementById('main-content'), state.activeChat.id);
    }, 600);
}

function scrollToBottom() {
    const chatDiv = document.getElementById('chat-messages');
    if (chatDiv) chatDiv.scrollTop = chatDiv.scrollHeight;
}

// ================= VUE CONSTRUCTEUR D'UNIVERS =================
function renderUniverseBuilder(container) {
    container.innerHTML = `
        <div class="space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-base font-bold text-white">Constructeur d'Univers</h2>
                    <p class="text-xs text-slate-400">Générez et structurez des mondes fantastiques complets.</p>
                </div>
                <button onclick="openNewUniverseModal()" class="px-3 py-2 bg-purple-600 hover:bg-purple-500 rounded-xl text-xs font-semibold text-white transition shadow-lg shadow-purple-600/30">
                    + Créer
                </button>
            </div>

            <div class="space-y-3">
                ${state.universes.length === 0 ? `
                    <div class="glass-card p-6 rounded-2xl text-center">
                        <i class="fa-solid fa-globe text-3xl text-purple-400 mb-2"></i>
                        <h3 class="text-sm font-bold text-white">Aucun univers enregistré</h3>
                        <p class="text-xs text-slate-400 mt-1">Créez votre premier monde pour structurer vos histoires et personnages.</p>
                    </div>
                ` : state.universes.map(u => `
                    <div class="glass-card p-4 rounded-xl border border-slate-800 space-y-2">
                        <div class="flex items-center justify-between">
                            <h3 class="font-bold text-sm text-cyan-300">${u.name}</h3>
                            <span class="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-md">${u.genre}</span>
                        </div>
                        <p class="text-xs text-slate-300 leading-relaxed">${u.description}</p>
                        <div class="flex items-center justify-between pt-2 border-t border-slate-800/60 text-[11px] text-slate-400">
                            <span>Magie : ${u.magicSystem || 'Standard'}</span>
                            <button onclick="deleteUniverse('${u.id}')" class="text-rose-400 hover:text-rose-300"><i class="fa-solid fa-trash"></i> Supprimer</button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function openNewUniverseModal() {
    const name = prompt("Nom de l'univers fictif :");
    if (!name) return;
    const genre = prompt("Genre (ex: Dark Fantasy, Cyberpunk, Isekai) :") || "Fantasy";
    const description = prompt("Description rapide ou synopsis de l'univers :") || "Monde en construction.";
    const magicSystem = prompt("Système de magie ou technologies principales :") || "Énergie primordiale";

    state.universes.push({
        id: 'univ_' + Date.now(),
        name,
        genre,
        description,
        magicSystem
    });
    saveState();
    navigateTo('universe');
}

function deleteUniverse(id) {
    if (confirm("Voulez-vous supprimer cet univers ?")) {
        state.universes = state.universes.filter(u => u.id !== id);
        saveState();
        navigateTo('universe');
    }
}

// ================= VUE PERSONNAGES =================
function renderCharacterCreator(container) {
    container.innerHTML = `
        <div class="space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-base font-bold text-white">Fiches Personnages</h2>
                    <p class="text-xs text-slate-400">Héros, antagonistes et créatures.</p>
                </div>
                <button onclick="openNewCharacterModal()" class="px-3 py-2 bg-indigo-600 hover:bg-indigo-500 rounded-xl text-xs font-semibold text-white transition shadow-lg shadow-indigo-600/30">
                    + Fiche
                </button>
            </div>

            <div class="space-y-3">
                ${state.characters.length === 0 ? `
                    <div class="glass-card p-6 rounded-2xl text-center">
                        <i class="fa-solid fa-user-shield text-3xl text-indigo-400 mb-2"></i>
                        <h3 class="text-sm font-bold text-white">Aucun personnage</h3>
                        <p class="text-xs text-slate-400 mt-1">Ajoutez des héros ou des rivaux pour vos récits.</p>
                    </div>
                ` : state.characters.map(c => `
                    <div class="glass-card p-4 rounded-xl border border-slate-800 space-y-2">
                        <div class="flex items-center justify-between">
                            <h3 class="font-bold text-sm text-indigo-300">${c.name} <span class="text-xs text-slate-400 font-normal">(${c.role})</span></h3>
                            <span class="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-md">Âge: ${c.age}</span>
                        </div>
                        <p class="text-xs text-slate-300"><strong>Pouvoirs / Compétences :</strong> ${c.powers}</p>
                        <div class="flex items-end justify-between pt-2 border-t border-slate-800/60 text-[11px] text-slate-400">
                            <span>Origines : ${c.origins}</span>
                            <button onclick="deleteCharacter('${c.id}')" class="text-rose-400 hover:text-rose-300"><i class="fa-solid fa-trash"></i></button>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
}

function openNewCharacterModal() {
    const name = prompt("Nom du personnage :");
    if (!name) return;
    const role = prompt("Rôle (Héros, Antagoniste, Mentor, Rival) :") || "Héros";
    const age = prompt("Âge fictif :") || "18";
    const powers = prompt("Pouvoirs ou compétences spéciales :") || "Magie de chaos";
    const origins = prompt("Origines / Histoire personnelle :") || "Orphelin mystérieux";

    state.characters.push({
        id: 'char_' + Date.now(),
        name,
        role,
        age,
        powers,
        origins
    });
    saveState();
    navigateTo('characters');
}

function deleteCharacter(id) {
    state.characters = state.characters.filter(c => c.id !== id);
    saveState();
    navigateTo('characters');
}

// ================= VUE MANGA & WEBTOON =================
function renderMangaStudio(container) {
    container.innerHTML = `
        <div class="space-y-4">
            <div>
                <h2 class="text-base font-bold text-white">Générateur Manga & Webtoon</h2>
                <p class="text-xs text-slate-400">Préparation de planches, découpage et bulles de dialogues.</p>
            </div>

            <div class="glass-card p-5 rounded-2xl space-y-3 border border-pink-500/20">
                <span class="text-[10px] font-semibold bg-pink-500/20 text-pink-300 px-2.5 py-1 rounded-full">Format Actif : Manhwa Vertical</span>
                <h3 class="text-sm font-bold text-white">Nouveau Projet de Planche</h3>
                <input type="text" id="manga-title" placeholder="Titre du chapitre ou de la scène..." class="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-pink-500">
                <textarea id="manga-prompt" placeholder="Décrivez l'action de la scène (ex: Combat épique sous la pluie, regard déterminé)..." class="w-full h-24 bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-pink-500 resize-none"></textarea>
                <button onclick="generateMangaScene()" class="w-full py-3 bg-gradient-to-r from-pink-600 to-purple-600 rounded-xl font-semibold text-xs text-white shadow-lg shadow-pink-600/20 active:scale-95 transition">
                    Générer la Planche / Storyboard
                </button>
            </div>

            <div id="manga-results" class="space-y-3">
                <!-- Résultats générés -->
            </div>
        </div>
    `;
}

function generateMangaScene() {
    const title = document.getElementById('manga-title').value || "Chapitre 1";
    const promptText = document.getElementById('manga-prompt').value;
    if (!promptText) {
        alert("Veuillez entrer une description de scène.");
        return;
    }

    const resultsDiv = document.getElementById('manga-results');
    resultsDiv.innerHTML = `
        <div class="glass-card p-4 rounded-xl border border-slate-800 flex items-center space-x-3">
            <div class="w-8 h-8 rounded-lg bg-pink-500/20 flex items-center justify-center text-pink-400 animate-spin">
                <i class="fa-solid fa-spinner"></i>
            </div>
            <div>
                <h4 class="text-xs font-bold text-white">Génération de "${title}"...</h4>
                <p class="text-[11px] text-slate-400">Découpage des cases et stylisation en cours.</p>
            </div>
        </div>
    `;

    setTimeout(() => {
        resultsDiv.innerHTML = `
            <div class="glass-card p-4 rounded-xl border border-pink-500/30 space-y-2 animate-fade-in">
                <div class="flex items-center justify-between">
                    <h4 class="text-xs font-bold text-pink-300">${title} (Généré)</h4>
                    <span class="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-md">Succès</span>
                </div>
                <p class="text-xs text-slate-300">${promptText}</p>
                <div class="w-full h-32 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500 text-xs">
                    [Planche Graphique Manga / Manhwa Rendu Prêt]
                </div>
            </div>
        `;
    }, 1500);
}

// ================= VUE MEDIA STUDIO (Images, Vidéo, Audio) =================
function renderMediaStudio(container) {
    container.innerHTML = `
        <div class="space-y-4">
            <div>
                <h2 class="text-base font-bold text-white">Studio Multimédia IA</h2>
                <p class="text-xs text-slate-400">Générez des images, des vidéos cinématiques et des pistes audio.</p>
            </div>

            <div class="flex space-x-2 border-b border-slate-800 pb-2">
                <button onclick="switchTab('img')" id="tab-img" class="px-3 py-1.5 rounded-lg text-xs font-semibold bg-cyan-500/20 text-cyan-300 transition">Images</button>
                <button onclick="switchTab('vid')" id="tab-vid" class="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-white transition">Vidéo</button>
                <button onclick="switchTab('aud')" id="tab-aud" class="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-white transition">Audio / Voix</button>
            </div>

            <div id="media-panel-content" class="space-y-3">
                <!-- Panneau Images par défaut -->
                <div class="glass-card p-4 rounded-xl space-y-3">
                    <h3 class="text-xs font-bold text-white uppercase tracking-wider">Générateur Texte vers Image</h3>
                    <textarea id="media-prompt-input" placeholder="Décrivez l'image ou le paysage fantastique..." class="w-full h-20 bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-cyan-500 resize-none"></textarea>
                    <button onclick="triggerMediaGeneration('image')" class="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-indigo-600 rounded-xl font-semibold text-xs text-white active:scale-95 transition">
                        Générer l'Image
                    </button>
                </div>
            </div>
        </div>
    `;
}

function switchTab(type) {
    const content = document.getElementById('media-panel-content');
    if (type === 'img') {
        content.innerHTML = `
            <div class="glass-card p-4 rounded-xl space-y-3">
                <h3 class="text-xs font-bold text-white uppercase tracking-wider">Générateur Texte vers Image</h3>
                <textarea id="media-prompt-input" placeholder="Décrivez l'image ou le paysage fantastique..." class="w-full h-20 bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-cyan-500 resize-none"></textarea>
                <button onclick="triggerMediaGeneration('image')" class="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-indigo-600 rounded-xl font-semibold text-xs text-white active:scale-95 transition">
                    Générer l'Image
                </button>
            </div>
        `;
    } else if (type === 'vid') {
        content.innerHTML = `
            <div class="glass-card p-4 rounded-xl space-y-3">
                <h3 class="text-xs font-bold text-white uppercase tracking-wider">Générateur Vidéo / Animation</h3>
                <textarea id="media-prompt-input" placeholder="Décrivez la scène animée (ex: Caméra en mouvement dans une ville cyberpunk)..." class="w-full h-20 bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-purple-500 resize-none"></textarea>
                <button onclick="triggerMediaGeneration('video')" class="w-full py-2.5 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl font-semibold text-xs text-white active:scale-95 transition">
                    Générer la Vidéo
                </button>
            </div>
        `;
    } else {
        content.innerHTML = `
            <div class="glass-card p-4 rounded-xl space-y-3">
                <h3 class="text-xs font-bold text-white uppercase tracking-wider">Studio Audio & Voix Anime</h3>
                <input type="text" id="media-prompt-input" placeholder="Genre musical ou texte de doublage..." class="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500">
                <button onclick="triggerMediaGeneration('audio')" class="w-full py-2.5 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl font-semibold text-xs text-white active:scale-95 transition">
                    Générer la Piste Audio
                </button>
            </div>
        `;
    }
}

function triggerMediaGeneration(type) {
    const promptText = document.getElementById('media-prompt-input').value;
    if (!promptText) {
        alert("Veuillez entrer une description.");
        return;
    }
    alert(`Requête de génération (${type}) transmise au studio. Connexion au serveur en cours...`);
}

// ================= VUE BIBLIOTHÈQUE =================
function renderLibrary(container) {
    container.innerHTML = `
        <div class="space-y-4">
            <div>
                <h2 class="text-base font-bold text-white">Bibliothèque Universelle</h2>
                <p class="text-xs text-slate-400">Tous vos univers, personnages et créations sauvegardés.</p>
            </div>

            <div class="space-y-3">
                <div class="glass-card p-4 rounded-xl flex items-center justify-between">
                    <div>
                        <h3 class="font-bold text-xs text-white">Univers Enregistrés</h3>
                        <p class="text-[11px] text-slate-400">${state.universes.length} monde(s) actif(s)</p>
                    </div>
                    <span class="text-xs text-cyan-400 font-mono">${state.universes.length}</span>
                </div>

                <div class="glass-card p-4 rounded-xl flex items-center justify-between">
                    <div>
                        <h3 class="font-bold text-xs text-white">Fiches Personnages</h3>
                        <p class="text-[11px] text-slate-400">${state.characters.length} personnage(s)</p>
                    </div>
                    <span class="text-xs text-purple-400 font-mono">${state.characters.length}</span>
                </div>

                <div class="glass-card p-4 rounded-xl flex items-center justify-between">
                    <div>
                        <h3 class="font-bold text-xs text-white">Discussions Cerveau IA</h3>
                        <p class="text-[11px] text-slate-400">${state.chats.length} session(s)</p>
                    </div>
                    <span class="text-xs text-indigo-400 font-mono">${state.chats.length}</span>
                </div>
            </div>

            <div class="pt-2">
                <button onclick="exportData()" class="w-full py-3 bg-slate-900 border border-slate-800 rounded-xl text-xs font-semibold text-slate-200 hover:bg-slate-800 transition">
                    Exporter les Sauvegardes (JSON)
                </button>
            </div>
        </div>
    `;
}

// ================= VUE PARAMÈTRES & CLÉS =================
function renderSettings(container) {
    container.innerHTML = `
        <div class="space-y-4">
            <div>
                <h2 class="text-base font-bold text-white">Serveur & Clés IA</h2>
                <p class="text-xs text-slate-400">Configuration des endpoints et état des services connectés.</p>
            </div>

            <div class="glass-card p-4 rounded-xl space-y-3 border border-slate-800">
                <div>
                    <label class="block text-[11px] font-semibold text-slate-300 mb-1">URL du Serveur Backend</label>
                    <input type="text" id="settings-url" value="${state.settings.serverUrl}" class="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500">
                </div>

                <div>
                    <label class="block text-[11px] font-semibold text-slate-300 mb-1">Clé API / Variables sécurisées</label>
                    <input type="password" id="settings-key" placeholder="Entrez la clé API du fournisseur..." value="${state.settings.apiKey}" class="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500">
                </div>

                <button onclick="saveSettings()" class="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-indigo-600 rounded-xl font-semibold text-xs text-white active:scale-95 transition">
                    Enregistrer la Configuration
                </button>
            </div>

            <div class="glass-card p-4 rounded-xl space-y-2">
                <h3 class="text-xs font-bold text-white">État de Connexion Serveur</h3>
                <div class="flex items-center space-x-2">
                    <div class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span class="text-xs text-slate-300">Serveur Render Prêt (Précédemment configuré)</span>
                </div>
            </div>
        </div>
    `;
}

function saveSettings() {
    state.settings.serverUrl = document.getElementById('settings-url').value;
    state.settings.apiKey = document.getElementById('settings-key').value;
    saveState();
    alert("Paramètres enregistrés avec succès dans le stockage local !");
}

function saveState() {
    localStorage.setItem('aether_chats', JSON.stringify(state.chats));
    localStorage.setItem('aether_universes', JSON.stringify(state.universes));
    localStorage.setItem('aether_characters', JSON.stringify(state.characters));
    localStorage.setItem('aether_creations', JSON.stringify(state.creations));
    localStorage.setItem('aether_settings', JSON.stringify(state.settings));
}

function exportData() {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "aether_universe_backup.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
}
