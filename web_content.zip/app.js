const $=s=>document.querySelector(s);
let db,mediaRecorder,stream,chunks=[],startedAt=0,timerId,elapsed=0,currentId=null,records=[];
const DB='uar-db', STORE='audio';

function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore(STORE,{keyPath:'id'});r.onsuccess=()=>{db=r.result;res()};r.onerror=()=>rej(r.error)})}
function tx(mode){return db.transaction(STORE,mode).objectStore(STORE)}
function put(x){return new Promise((res,rej)=>{const r=tx('readwrite').put(x);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function all(){return new Promise((res,rej)=>{const r=tx('readonly').getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
function del(id){return new Promise((res,rej)=>{const r=tx('readwrite').delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
function fmt(s){s=Math.max(0,Math.floor(s));return [Math.floor(s/3600),Math.floor(s/60)%60,s%60].map(n=>String(n).padStart(2,'0')).join(':')}
function bytes(n){if(n<1024)return n+' B';if(n<1048576)return (n/1024).toFixed(1)+' KB';return (n/1048576).toFixed(1)+' MB'}
function ext(type){return type.includes('ogg')?'ogg':type.includes('mp4')?'m4a':type.includes('wav')?'wav':'webm'}

async function start(){
 try{
  if(!navigator.mediaDevices?.getUserMedia) throw Error('Microphone non disponible dans ce navigateur.');
  stream=await navigator.mediaDevices.getUserMedia({audio:true});
  let preferred=$('#quality').value==='high'?'audio/webm;codecs=opus':'audio/webm';
  let type=MediaRecorder.isTypeSupported(preferred)?preferred:'audio/webm';
  mediaRecorder=new MediaRecorder(stream,{mimeType:type});
  chunks=[]; startedAt=Date.now(); elapsed=0; updateTimer();
  mediaRecorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  mediaRecorder.onstop=saveRecording;
  mediaRecorder.start(500);
  $('#recordBtn').classList.add('recording');$('#recordBtn').textContent='●';
  $('#recordBtn').disabled=true;$('#pauseBtn').disabled=false;$('#stopBtn').disabled=false;
  $('#status').textContent='Enregistrement en cours…';
  timerId=setInterval(updateTimer,250);
 }catch(e){alert(e.message)}
}
function updateTimer(){elapsed=(Date.now()-startedAt)/1000;$('#timer').textContent=fmt(elapsed)}
function pause(){if(!mediaRecorder)return;if(mediaRecorder.state==='recording'){mediaRecorder.pause();$('#pauseBtn').textContent='▶ Reprendre';$('#status').textContent='En pause'}else{mediaRecorder.resume();$('#pauseBtn').textContent='⏸ Pause';$('#status').textContent='Enregistrement en cours…'}}
function stop(){if(!mediaRecorder)return;mediaRecorder.stop();stream?.getTracks().forEach(t=>t.stop());clearInterval(timerId);$('#status').textContent='Sauvegarde…';$('#recordBtn').disabled=false;$('#pauseBtn').disabled=true;$('#stopBtn').disabled=true}
async function saveRecording(){
 const blob=new Blob(chunks,{type:mediaRecorder.mimeType||'audio/webm'});
 const id=crypto.randomUUID();const now=new Date();
 await put({id,name:'Enregistrement '+now.toLocaleString('fr-FR').replace(/[/:]/g,'-'),blob,date:now.toISOString(),duration:elapsed,favorite:false,type:blob.type});
 mediaRecorder=null;$('#timer').textContent='00:00:00';$('#pauseBtn').textContent='⏸ Pause';$('#status').textContent='Enregistrement sauvegardé ✓';await refresh();
}
function render(){
 const q=$('#search').value.toLowerCase(), sort=$('#sort').value;
 let a=records.filter(x=>x.name.toLowerCase().includes(q));
 a.sort((x,y)=>sort==='old'?x.date.localeCompare(y.date):sort==='name'?x.name.localeCompare(y.name):sort==='duration'?y.duration-x.duration:y.date.localeCompare(x.date));
 $('#count').textContent=a.length;
 $('#list').innerHTML=a.length?a.map(x=>`<article class="item">
  <div class="itemTop"><span>🎵</span><div class="itemTitle">${escapeHtml(x.name)}</div><span class="meta">${fmt(x.duration)}</span></div>
  <div class="meta">${new Date(x.date).toLocaleString('fr-FR')} · ${bytes(x.blob.size)}</div>
  <div class="actions">
   <button onclick="play('${x.id}')">▶ Lire</button><button onclick="edit('${x.id}')">✏️ Modifier</button>
   <button onclick="downloadAudio('${x.id}')">⬇️ Exporter</button><button onclick="shareAudio('${x.id}')">📤 Partager</button>
   <button onclick="toggleFav('${x.id}')" class="${x.favorite?'fav':''}">★ Favori</button><button onclick="removeAudio('${x.id}')">🗑️ Supprimer</button>
  </div></article>`).join(''):'<div class="empty">Aucun enregistrement pour le moment.<br>Appuie sur ● pour commencer.</div>';
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
async function refresh(){records=await all();render()}
function get(id){return records.find(x=>x.id===id)}
function play(id){let x=get(id);if(!x)return;$('#playerName').textContent=x.name;$('#audio').src=URL.createObjectURL(x.blob);$('#audio').play();$('#player').classList.remove('hidden')}
function edit(id){let x=get(id);currentId=id;$('#newName').value=x.name;$('#trimStart').value=0;$('#trimEnd').value=Math.round(x.duration*10)/10;$('#editModal').classList.remove('hidden')}
async function saveEdit(){let x=get(currentId);if(!x)return;x.name=$('#newName').value.trim()||x.name;await put(x);$('#editModal').classList.add('hidden');await refresh()}
async function removeAudio(id){if(confirm('Supprimer cet enregistrement ?')){await del(id);await refresh()}}
async function toggleFav(id){let x=get(id);x.favorite=!x.favorite;await put(x);await refresh()}
function downloadAudio(id){let x=get(id);let a=document.createElement('a');a.href=URL.createObjectURL(x.blob);a.download=x.name+'.'+ext(x.blob.type);a.click()}
async function shareAudio(id){let x=get(id);let f=new File([x.blob],x.name+'.'+ext(x.blob.type),{type:x.blob.type});if(navigator.share&&navigator.canShare?.({files:[f]})){await navigator.share({title:x.name,files:[f]})}else downloadAudio(id)}
$('#recordBtn').onclick=start;$('#pauseBtn').onclick=pause;$('#stopBtn').onclick=stop;$('#search').oninput=render;$('#sort').onchange=render;
$('#closePlayer').onclick=()=>{$('#audio').pause();$('#player').classList.add('hidden')};
document.querySelectorAll('[data-speed]').forEach(b=>b.onclick=()=>$('#audio').playbackRate=+b.dataset.speed);
$('#cancelEdit').onclick=()=>$('#editModal').classList.add('hidden');$('#saveEdit').onclick=saveEdit;
$('#importInput').onchange=async e=>{for(const file of e.target.files){await put({id:crypto.randomUUID(),name:file.name.replace(/\.[^.]+$/,''),blob:file,date:new Date().toISOString(),duration:0,favorite:false,type:file.type})}e.target.value='';await refresh()};
$('#themeBtn').onclick=()=>{document.body.classList.toggle('light');localStorage.theme=document.body.classList.contains('light')?'light':'dark';$('#themeBtn').textContent=document.body.classList.contains('light')?'☀️':'🌙'};
if(localStorage.theme==='light'){$('#themeBtn').click()}
openDB().then(refresh);
