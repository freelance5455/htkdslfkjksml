if('serviceWorker' in navigator && location.protocol!=='file:'){navigator.serviceWorker.register('./sw.js').catch(()=>{});}
const KEY="tavars-v1";
const THEME_KEY="tavars-theme-v1";
const defaultState={cash:0,openingCash:0,cashAdjustments:[],products:[],sales:[],expenses:[],incomes:[],purchases:[],stockPurchases:[],settings:{shopName:"TAVAR'S",currency:"UZS",user:"None"}};
let state=load();
let route="dashboard";
let searchTerm="";
function localDateString(d=new Date()){const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0"),day=String(d.getDate()).padStart(2,"0");return `${y}-${m}-${day}`}
function localMonthString(d=new Date()){return localDateString(d).slice(0,7)}
let archiveMonth=localMonthString();
let archiveMode="month";
let archiveWeek=today();

function parseMoney(v){
  const raw=String(v??"").replace(/[^0-9-]/g,"");
  if(raw==="" || raw==="-") return 0;
  const n=Number(raw);
  return Number.isFinite(n)?n:0;
}
function formatMoneyInput(v){
  const raw=String(v??"").replace(/[^0-9]/g,"");
  return raw ? raw.replace(/\B(?=(\d{3})+(?!\d))/g,".") : "";
}
function moneyField(label,name,value="",extra=""){
  const formatted=value===""||value===null||value===undefined?"":formatMoneyInput(value);
  return `<div class="field"><label>${label}</label><input name="${name}" type="text" inputmode="numeric" autocomplete="off" value="${esc(formatted)}" data-money-input="1" ${extra}></div>`;
}
function weekRange(anchorDate){
  const start=weekStart(anchorDate||today());
  const d=dayDate(start+"T00:00:00");
  d.setDate(d.getDate()+6);
  return {start,end:localDateString(d)};
}
function formatDateUz(dateStr){
  const parts=String(dateStr||"").split("-");
  return parts.length===3?`${parts[2]}.${parts[1]}.${parts[0]}`:String(dateStr||"");
}
function shiftWeek(dateStr,amount){
  const d=dayDate(dateStr+"T00:00:00");
  d.setDate(d.getDate()+Number(amount||0)*7);
  return localDateString(d);
}


function normalizeState(raw){
  const source=raw&&typeof raw==="object"?raw:{};
  const products=(Array.isArray(source.products)?source.products:[])
    .filter(p=>p&&typeof p==="object")
    .map(p=>({...p,id:p.id||uid(),name:String(p.name||"?"),qty:Math.max(0,Number(p.qty)||0),buy:Math.max(0,Number(p.buy)||0),sell:Math.max(0,Number(p.sell)||0),addedAt:p.addedAt||nowISO()}));
  const sales=(Array.isArray(source.sales)?source.sales:[]).filter(s=>s&&typeof s==="object").map(s=>({...s,id:s.id||uid(),revenue:Math.max(0,Number(s.revenue)||0),paid:Number.isFinite(Number(s.paid))?Math.max(0,Number(s.paid)):undefined}));
  const expenses=(Array.isArray(source.expenses)?source.expenses:[]).filter(e=>e&&typeof e==="object");
  const incomes=(Array.isArray(source.incomes)?source.incomes:[]).filter(i=>i&&typeof i==="object");
  const stockPurchases=(Array.isArray(source.stockPurchases)?source.stockPurchases:[]).filter(b=>b&&typeof b==="object");
  const cashAdjustments=(Array.isArray(source.cashAdjustments)?source.cashAdjustments:[]).filter(x=>x&&typeof x==="object");

  // Legacy backups sometimes have `paid` repeated on every line of a multi-item sale.
  // Always calculate received cash by transaction, never by individual sale line.
  const salesCash=cashReceivedForSales(sales).cash;
  const incomeCash=incomes.reduce((a,i)=>a+Number(i.amount||0),0);
  const expenseCash=expenses.reduce((a,e)=>a+Number(e.amount||0),0);
  const purchaseCash=stockPurchases.reduce((a,b)=>a+Number(b.total||0),0);
  const adjustmentCash=cashAdjustments.reduce((a,x)=>a+Number(x.amount||0),0);
  const hasOpening=Number.isFinite(Number(source.openingCash));
  const hasCash=Number.isFinite(Number(source.cash));
  // If an old backup has no openingCash, reconstruct it from its saved current cash.
  // If it has neither value, use 0 instead of inventing a negative opening balance.
  const openingCash=hasOpening
    ? Number(source.openingCash)
    : hasCash
      ? Number(source.cash)-salesCash-incomeCash+expenseCash+purchaseCash-adjustmentCash
      : 0;

  return {
    ...defaultState,...source,
    products,sales,expenses,incomes,
    purchases:Array.isArray(source.purchases)?source.purchases:[],
    stockPurchases,cashAdjustments,
    openingCash:Number.isFinite(openingCash)?openingCash:0,
    cash:0,
    settings:{...defaultState.settings,...(source.settings||{}),user:String((source.settings&&source.settings.user)??"None")||"None"}
  };
}
function load(){
  try{return normalizeState(JSON.parse(localStorage.getItem(KEY)||"{}"));}
  catch{return JSON.parse(JSON.stringify(defaultState));}
}
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));return true}catch(err){toast("Saqlab bo'lmadi! Brauzer xotirasi to'lgan yoki bloklangan. Darhol JSON eksport qiling.","error");return false}}
function cashReceivedForSales(sales){
  const groups=new Map();
  for(const s of sales){
    const key=s.transactionId||s.id;
    if(!groups.has(key))groups.set(key,{total:0,paid:null});
    const g=groups.get(key);
    g.total+=Math.max(0,Number(s.revenue||0));
    if(g.paid===null && Number.isFinite(Number(s.paid)))g.paid=Number(s.paid);
  }
  let cash=0,debt=0;
  for(const g of groups.values()){
    const paid=g.paid===null?g.total:g.paid;
    cash+=Math.min(Math.max(paid,0),g.total);
    debt+=Math.max(g.total-paid,0);
  }
  return {cash,debt};
}
function calcCash(){
  const sales=cashReceivedForSales(state.sales).cash;
  const income=state.incomes.reduce((a,i)=>a+Number(i.amount||0),0);
  const expense=state.expenses.reduce((a,e)=>a+Number(e.amount||0),0);
  const buys=state.stockPurchases.reduce((a,b)=>a+Number(b.total||0),0);
  const adjustments=state.cashAdjustments.reduce((a,x)=>a+Number(x.amount||0),0);
  return Number(state.openingCash||0)+sales+income-expense-buys+adjustments;
}
function syncCash(){state.cash=calcCash();return state.cash}
function addCashAdjustment(amount,note=""){
  state.cashAdjustments.push({id:uid(),date:today(),amount:Number(amount),note:String(note||"")});
  syncCash();
}
function normalizeProductName(name){return String(name||"").trim().toLowerCase().replace(/\s+/g," ")}
function findProduct(name,buy){
  const key=normalizeProductName(name), cost=Number(buy);
  return state.products.find(p=>normalizeProductName(p.name)===key && Number(p.buy)===cost);
}
function removeEmptyProduct(p){
  // 0 dona bo'lgan mahsulot ham omborda saqlanadi.
  // U sotuv ro'yxatida ko'rinmaydi, lekin keyin yana zaxira qo'shish mumkin.
  return false;
}
function dayDate(d){const x=new Date(d);x.setHours(0,0,0,0);return x}
function weekStart(dateStr){
  const d=dayDate(dateStr+"T00:00:00"), day=d.getDay();
  const diff=day===0?-6:1-day;
  d.setDate(d.getDate()+diff);
  return localDateString(d);
}
function inDateRange(date,start,end){return String(date||"")>=start&&String(date||"")<=end}
function money(n){const v=Math.round(Number(n)||0);return String(v).replace(/\B(?=(\d{3})+(?!\d))/g,".")+" "+state.settings.currency}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function today(){return localDateString()}
function nowISO(){return new Date().toISOString()}
function monthName(m){return new Intl.DateTimeFormat("uz-UZ",{month:"long",year:"numeric"}).format(new Date(m+"-01T12:00:00"))}
function toast(msg,type="success"){const d=document.createElement("div");d.className="toast "+type;d.textContent=msg;document.getElementById("toastRoot").appendChild(d);setTimeout(()=>d.remove(),2800)}
function weekReport(){
  const {start,end}=weekRange(today());
  const ss=state.sales.filter(x=>inDateRange(x.date,start,end));
  const ii=state.incomes.filter(x=>inDateRange(x.date,start,end));
  const ee=state.expenses.filter(x=>inDateRange(x.date,start,end));
  const bb=state.stockPurchases.filter(x=>inDateRange(x.date,start,end));
  const aa=state.cashAdjustments.filter(x=>inDateRange(x.date,start,end));
  const collected=cashReceivedForSales(ss).cash;
  const revenue=ss.reduce((a,x)=>a+Number(x.revenue||0),0);
  const income=ii.reduce((a,x)=>a+Number(x.amount||0),0);
  const expense=ee.reduce((a,x)=>a+Number(x.amount||0),0);
  const buy=bb.reduce((a,x)=>a+Number(x.total||0),0);
  const adjust=aa.reduce((a,x)=>a+Number(x.amount||0),0);
  return {start,end,revenue,collected,income,expense,buy,adjust,net:collected+income+adjust-expense-buy};
}
function calcToday(){const t=today();const sales=state.sales.filter(s=>s.date===t),incomes=state.incomes.filter(i=>i.date===t),expenses=state.expenses.filter(e=>e.date===t);const collected=cashReceivedForSales(sales);return {revenue:sales.reduce((a,s)=>a+Number(s.revenue||0),0),collected:collected.cash,debt:collected.debt,profit:sales.reduce((a,s)=>a+Number(s.profit||0),0),units:sales.reduce((a,s)=>a+Number(s.qty||0),0),income:incomes.reduce((a,i)=>a+Number(i.amount||0),0),expense:expenses.reduce((a,e)=>a+Number(e.amount||0),0),buy:state.stockPurchases.filter(b=>b.date===t).reduce((a,b)=>a+Number(b.total||0),0)}}
function uid(){return (globalThis.crypto&&globalThis.crypto.randomUUID)?globalThis.crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2)}
function logBuy(name,qty,unit,date,productId){
  state.stockPurchases.push({id:uid(),date:date||today(),name,productId:productId||null,qty:Number(qty),unitCost:Number(unit),total:Number(unit)*Number(qty)});
  syncCash();
}
function applyTheme(){
  const light=localStorage.getItem(THEME_KEY)==="light";
  document.documentElement.classList.toggle("light-mode",light);
  const b=document.getElementById("themeToggle");if(b)b.textContent=light?"🌙":"☀️";
}
function toggleTheme(){const light=document.documentElement.classList.contains("light-mode");localStorage.setItem(THEME_KEY,light?"dark":"light");applyTheme();}
function render(top){document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.route===route));const app=document.getElementById("app");app.innerHTML=pages[route]();bind();if(top)window.scrollTo({top:0,behavior:"smooth"})}
function openModal(title,body,onSubmit,okText="Saqlash"){const root=document.getElementById("modalRoot");root.innerHTML=`<div class="modal-backdrop"><div class="modal"><h2>${title}</h2><form id="modalForm">${body}<div class="modal-actions"><button type="button" class="btn" id="cancelModal">Bekor qilish</button><button class="btn primary">${okText}</button></div></form></div></div>`;root.querySelector(".modal-backdrop").onclick=e=>{if(e.target===e.currentTarget)root.innerHTML=""};root.querySelector("#cancelModal").onclick=()=>root.innerHTML="";root.querySelector("form").onsubmit=e=>{e.preventDefault();onSubmit(new FormData(e.target))}}
function confirmAction(text,yes){openModal("Tasdiqlash",`<p class="muted">${esc(text)}</p>`,()=>{yes();document.getElementById("modalRoot").innerHTML=""},"Ha, davom etish")}
function field(label,name,type="text",value="",extra=""){return `<div class="field"><label>${label}</label><input name="${name}" type="${type}" value="${esc(value)}" ${extra}></div>`}
function productForm(p={}){return `<div class="form-grid">${field("Tovar nomi","name","text",p.name||"","required")}${field("Miqdor","qty","number",p.qty??0,'min="0" step="1" required')}${moneyField("Olish narxi (UZS)","buy",p.buy??0,'data-required-money="1"')}${moneyField("Sotish narxi (UZS)","sell",p.sell??0,'data-required-money="1"')}<div class="field" style="grid-column:1/-1"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="free" style="width:auto"> Boshlang'ich zaxira: kassadan pul ayirmaslik</label></div></div>`}
const pages = {
dashboard:()=>{const t=calcToday(), w=weekReport(), low=state.products.filter(p=>p.qty>0&&p.qty<=3), upcoming=state.purchases;return `<section><h1 class="page-title">Bugun do'kon qanday?</h1><p class="page-sub">Muhim raqamlar bir qarashda.</p>
<div class="grid metrics"><div class="card metric accent"><div class="label">Kassadagi pul</div><div class="value">${money(state.cash)}</div></div><div class="card metric"><div class="label">Bugungi jami sotuv</div><div class="value">${money(t.revenue)}</div></div><div class="card metric"><div class="label">Bugungi foyda</div><div class="value">${money(t.profit)}</div></div><div class="card metric"><div class="label">Bugungi xarajat</div><div class="value">${money(t.expense)}</div></div><div class="card metric"><div class="label">Qo'shimcha daromad</div><div class="value">${money(t.income)}</div></div></div>
<div class="grid two" style="margin-top:14px"><div class="card"><div class="section-head"><h2>💰 Bugungi pul hisoboti</h2></div><div class="kpi-line"><span>Sotuv summasi</span><b>${money(t.revenue)}</b></div><div class="kpi-line"><span>Kassaga tushgan pul</span><b>${money(t.collected)}</b></div><div class="kpi-line"><span>Mijozning qarzi</span><b>${money(t.debt)}</b></div><div class="kpi-line"><span>Qo'shimcha daromad</span><b>${money(t.income)}</b></div><div class="kpi-line"><span>Xarajat</span><b>− ${money(t.expense)}</b></div><div class="kpi-line"><span>Tovar xaridi</span><b>− ${money(t.buy)}</b></div><div class="kpi-line"><span>Sof pul oqimi</span><b>${money(t.collected+t.income-t.expense-t.buy)}</b></div></div><div class="card"><div class="section-head"><h2>📦 Ombor</h2><button class="btn small primary" data-action="add-product">+ Tovar qo'shish</button></div><div class="kpi-line"><span>Jami pozitsiyalar</span><b>${state.products.length}</b></div><div class="kpi-line"><span>Ombordagi dona</span><b>${state.products.reduce((a,p)=>a+p.qty,0)}</b></div><div class="kpi-line"><span>Kamayib borayotgan</span><b>${low.length}</b></div></div>
<div class="card"><div class="section-head"><h2>📅 Shu hafta pul hisoboti</h2><button class="btn small" data-route-go="archive">Arxiv</button></div><div class="kpi-line"><span>Dushanba–Yakshanba sotuv</span><b>${money(w.revenue)}</b></div><div class="kpi-line"><span>Kassaga tushgan</span><b>+ ${money(w.collected)}</b></div><div class="kpi-line"><span>Qo'shimcha daromad</span><b>+ ${money(w.income)}</b></div><div class="kpi-line"><span>Xarajatlar</span><b>− ${money(w.expense)}</b></div><div class="kpi-line"><span>Tovar xaridi</span><b>− ${money(w.buy)}</b></div><div class="kpi-line"><span>Kassaga qo'shilgan pul</span><b>+ ${money(w.adjust)}</b></div><div class="kpi-line"><span>Haftalik sof pul o'zgarishi</span><b>${money(w.net)}</b></div></div>
<div class="card"><div class="section-head"><h2>🛍 Yaqinda olinadi</h2><button class="btn small" data-route-go="purchases">Ko'rish</button></div>${upcoming.length?`<div class="list">${upcoming.slice(0,4).map(p=>`<div class="row"><div class="row-main"><div class="row-title">${esc(p.name)}</div><div class="row-meta">${p.qty} dona · ${money(p.expected)}</div></div></div>`).join("")}</div>`:`<div class="empty"><strong>🛒 Yaqinda ro'yxati bo'sh</strong>Kelajakdagi xaridlarni shu yerga yozing.</div>`}</div></div>
<div class="grid two" style="margin-top:14px"><div class="card"><div class="section-head"><h2>⚠️ Kamayib borayotgan tovarlar</h2></div>${low.length?`<div class="list">${low.map(p=>`<div class="row"><div><div class="row-title">${esc(p.name)}</div><div class="row-meta">Sotish: ${money(p.sell)}</div></div><b class="stock-low">${p.qty} dona</b></div>`).join("")}</div>`:`<div class="empty"><strong>Hammasi joyida</strong>Hozircha kam zaxira yo'q.</div>`}</div>
<div class="card"><div class="section-head"><h2>💵 Bugungi sotuvlar</h2><button class="btn small" data-route-go="sales">Sotuvga o'tish</button></div>${state.sales.filter(s=>s.date===today()).slice(-5).reverse().map(s=>`<div class="row"><div><div class="row-title">${esc(s.product)}</div><div class="row-meta">${s.qty} dona · ${s.time}</div></div><div class="row-right"><div class="price">${money(s.revenue)}</div><div class="row-meta">Foyda ${money(s.profit)}</div></div></div>`).join("")||`<div class="empty"><strong>💵 Bugun hali sotuv bo'lmadi</strong></div>`}</div></div></section>`},
inventory:()=>`<section><div class="section-head"><div><h1 class="page-title">Ombor</h1><p class="page-sub">Joriy mahsulotlar va zaxira.</p></div><button class="btn primary" data-action="add-product">+ Tovar qo'shish</button></div><div class="card"><input id="searchInventory" class="search" placeholder="Tovar qidirish..." value="${esc(searchTerm)}"><div class="list" style="margin-top:14px">${filteredProducts().map(p=>`<div class="row"><div class="row-main"><div class="row-title">${esc(p.name)}</div><div class="row-meta">Olish ${money(p.buy)} · Sotish ${money(p.sell)} · Foyda/dona ${money(p.sell-p.buy)}</div><div class="row-meta">Qo'shilgan: ${p.addedAt.slice(0,10)}</div></div><div class="row-right"><div class="${p.qty===0?'stock-zero':p.qty<=3?'stock-low':''} price">${p.qty} dona</div><div class="actions" style="margin-top:7px"><button class="btn small" data-action="edit-product" data-id="${p.id}">Tahrir</button><button class="btn small" data-action="add-stock" data-id="${p.id}">+ Zaxira</button><button class="btn small danger" data-action="delete-product" data-id="${p.id}">O'chirish</button></div></div></div>`).join("")||`<div class="empty"><strong>📦 Omborda hali tovar yo'q</strong>Yangi mahsulot qo'shing.</div>`}</div></div></section>`,
sales:()=>{const ps=state.products.filter(p=>p.qty>0&&p.name.toLowerCase().includes(searchTerm.toLowerCase()));return `<section><h1 class="page-title">Sotuv</h1><p class="page-sub">Faqat mavjud mahsulotlar ko'rsatiladi.</p><div class="card"><input id="searchSales" class="search" placeholder="Sotiladigan tovarni qidiring..." value="${esc(searchTerm)}"><div class="list" style="margin-top:14px">${ps.map(p=>`<div class="row"><div><div class="row-title">${esc(p.name)}</div><div class="row-meta">Mavjud: <b>${p.qty}</b> dona · ${money(p.sell)}</div></div><div class="actions"><input class="search sale-qty" data-id="${p.id}" type="number" min="1" max="${p.qty}" step="1" placeholder="Miqdor" value="${esc(cart[p.id]||"")}" style="width:105px;padding:10px"></div></div>`).join("")||`<div class="empty"><strong>🛒 Sotish uchun tovar yo'q</strong>Omborga zaxira qo'shing.</div>`}</div></div>${saleBar()}</section>`},
archive:()=>{
  let start,end,title;
  if(archiveMode==="week"){
    const range=weekRange(archiveWeek);
    start=range.start; end=range.end;
    title=`Hafta: ${formatDateUz(start)} — ${formatDateUz(end)}`;
  }
  else {start=archiveMonth+"-01";const d=new Date(archiveMonth+"-01T12:00:00");d.setMonth(d.getMonth()+1);d.setDate(0);end=localDateString(d);title=monthName(archiveMonth);}
  const ss=state.sales.filter(x=>inDateRange(x.date,start,end));
  const ee=state.expenses.filter(x=>inDateRange(x.date,start,end));
  const ii=state.incomes.filter(x=>inDateRange(x.date,start,end));
  const bb=state.stockPurchases.filter(x=>inDateRange(x.date,start,end));
  const aa=state.cashAdjustments.filter(x=>inDateRange(x.date,start,end));
  const rev=ss.reduce((a,x)=>a+Number(x.revenue||0),0),prof=ss.reduce((a,x)=>a+Number(x.profit||0),0);const collectedSales=cashReceivedForSales(ss);const collected=collectedSales.cash,debt=collectedSales.debt;
  const exp=ee.reduce((a,x)=>a+Number(x.amount||0),0),inc=ii.reduce((a,x)=>a+Number(x.amount||0),0);
  const buy=bb.reduce((a,x)=>a+Number(x.total||0),0),adjust=aa.reduce((a,x)=>a+Number(x.amount||0),0);
  const net=collected+inc+adjust-exp-buy;
  const map=new Map();
  ss.forEach(x=>{const key=x.productId||("name:"+normalizeProductName(x.product));if(!map.has(key))map.set(key,{name:x.product,qty:0,revenue:0,profit:0});const v=map.get(key);v.qty+=Number(x.qty||0);v.revenue+=Number(x.revenue||0);v.profit+=Number(x.profit||0)});
  const rows=[...map.values()];
  const history=[...ss].sort((a,b)=>String(b.date+" "+b.time).localeCompare(String(a.date+" "+a.time)));
  const incomes=[...ii].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  const expenses=[...ee].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  const purchases=[...bb].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  const adjustments=[...aa].sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  return `<section>
  <div class="section-head"><div><h1 class="page-title">Arxiv</h1><p class="page-sub">Sotuv, xarid, daromad va xarajatlar bir joyda.</p></div>
  <div class="actions"><button class="btn ${archiveMode==="month"?"primary":""}" data-action="archive-month">Oy</button><button class="btn ${archiveMode==="week"?"primary":""}" data-action="archive-week">Hafta</button></div></div>
  <div class="card" style="margin-bottom:14px"><div class="section-head archive-head"><h2>${title}${archiveMode==="week"?` <span class="muted tiny">(Dushanba–Yakshanba)</span>`:""}</h2>${archiveMode==="month"?`<input id="archiveMonth" class="search archive-date-input" type="month" value="${archiveMonth}" aria-label="Oy tanlash">`:`<div class="actions archive-controls"><button class="btn small" data-action="archive-prev-week" title="Oldingi hafta">← Oldingi hafta</button><input id="archiveWeek" class="search archive-date-input" type="date" value="${archiveWeek}" aria-label="Haftadagi sana"><button class="btn small" data-action="archive-current-week">Joriy hafta</button><button class="btn small" data-action="archive-next-week" title="Keyingi hafta">Keyingi hafta →</button></div>`}</div>
  <div class="grid metrics">
    <div class="metric"><div class="label">Sotuv summasi</div><div class="value">${money(rev)}</div></div>
    <div class="metric"><div class="label">Qo'shimcha daromad</div><div class="value">${money(inc)}</div></div>
    <div class="metric"><div class="label">Xarajatlar</div><div class="value">− ${money(exp)}</div></div>
    <div class="metric"><div class="label">Tovar uchun to'lov</div><div class="value">− ${money(buy)}</div></div>
  </div></div>
  <div class="card"><div class="section-head"><h2>${title} bo'yicha pul hisoboti</h2></div>
    <div class="kpi-line"><span>Jami sotuv</span><b>${money(rev)}</b></div><div class="kpi-line"><span>Kassaga tushgan pul</span><b>+ ${money(collected)}</b></div><div class="kpi-line"><span>Mijozlardan olinadigan qarz</span><b>${money(debt)}</b></div>
    <div class="kpi-line"><span>Qo'shimcha daromad</span><b>+ ${money(inc)}</b></div>
    <div class="kpi-line"><span>Kassaga qo'shilgan pul</span><b>+ ${money(adjust)}</b></div>
    <div class="kpi-line"><span>Xarajatlar</span><b>− ${money(exp)}</b></div>
    <div class="kpi-line"><span>Tovar xaridi</span><b>− ${money(buy)}</b></div>
    <div class="kpi-line"><span>Shu davrning sof pul o'zgarishi</span><b>${money(net)}</b></div>
    <div class="kpi-line"><span>Sotilgan mahsulot</span><b>${ss.reduce((a,x)=>a+Number(x.qty||0),0)} dona</b></div>
  </div>
  <div class="card" style="margin-top:14px"><div class="section-head"><h2>Mahsulotlar bo'yicha sotuv</h2></div>${rows.length?`<div class="table-wrap"><table class="table"><thead><tr><th>Tovar</th><th>Sotildi</th><th>Tushum</th><th>Foyda</th></tr></thead><tbody>${rows.map(v=>`<tr><td><b>${esc(v.name)}</b></td><td>${v.qty} dona</td><td>${money(v.revenue)}</td><td>${money(v.profit)}</td></tr>`).join("")}</tbody></table></div>`:`<div class="empty">Bu davrda sotuv bo'lmagan.</div>`}</div>
  <div class="grid two" style="margin-top:14px">
    <div class="card"><div class="section-head"><h2>Qo'shimcha daromadlar</h2><span class="muted tiny">${incomes.length} ta</span></div>${incomes.length?`<div class="list">${incomes.map(x=>`<div class="row"><div><div class="row-title">${esc(x.name)}</div><div class="row-meta">${formatDateUz(x.date)}${x.note?` · ${esc(x.note)}`:""}</div></div><b>+ ${money(x.amount)}</b></div>`).join("")}</div>`:`<div class="empty">Qo'shimcha daromad yo'q.</div>`}</div>
    <div class="card"><div class="section-head"><h2>Xarajatlar</h2><span class="muted tiny">${expenses.length} ta</span></div>${expenses.length?`<div class="list">${expenses.map(x=>`<div class="row"><div><div class="row-title">${esc(x.name)}</div><div class="row-meta">${formatDateUz(x.date)}${x.note?` · ${esc(x.note)}`:""}</div></div><b>− ${money(x.amount)}</b></div>`).join("")}</div>`:`<div class="empty">Xarajat yo'q.</div>`}</div>
  </div>
  <div class="card" style="margin-top:14px"><div class="section-head"><h2>Tovar xaridlari</h2><span class="muted tiny">${purchases.length} ta</span></div>${purchases.length?`<div class="list">${purchases.map(x=>`<div class="row"><div><div class="row-title">${esc(x.name)}</div><div class="row-meta">${formatDateUz(x.date)} · ${x.qty} dona · olish ${money(x.unitCost)}</div></div><b>− ${money(x.total)}</b></div>`).join("")}</div>`:`<div class="empty">Bu davrda tovar xaridi yo'q.</div>`}</div>
  <div class="card" style="margin-top:14px"><div class="section-head"><h2>Sotuvlar</h2><span class="muted tiny">${history.length} ta</span></div>${history.length?`<div class="list">${history.map(x=>`<div class="row"><div><div class="row-title">${esc(x.product)} — ${x.qty} dona</div><div class="row-meta">${formatDateUz(x.date)} · ${esc(x.time||"")} · olish ${money(x.purchasePrice)} · sotish ${money(x.sellingPrice)} · mijoz berdi ${money(Number.isFinite(Number(x.paid))?x.paid:x.revenue)}${x.debt?` · qarz ${money(x.debt)}`:x.change?` · qaytim ${money(x.change)}`:""}</div></div><div class="row-right"><b>${money(x.revenue)}</b><div class="row-meta">Foyda ${money(x.profit)}</div></div></div>`).join("")}</div>`:`<div class="empty">Sotuv yozuvi yo'q.</div>`}</div>
  </section>`
},
purchases:()=>`<section><div class="section-head"><div><h1 class="page-title">Yaqinda</h1><p class="page-sub">Kelajakdagi xaridlar ro'yxati.</p></div><button class="btn primary" data-action="add-purchase">+ Ro'yxatga qo'shish</button></div><div class="card"><input id="searchPurchases" class="search" placeholder="Ro'yxatdan qidirish..." value="${esc(searchTerm)}"><div class="list" style="margin-top:14px">${state.purchases.filter(p=>p.name.toLowerCase().includes(searchTerm.toLowerCase())).map(p=>`<div class="row"><div><div class="row-title">${esc(p.name)}</div><div class="row-meta">${p.qty} dona · kutilgan narx ${money(p.expected)}${p.note?` · ${esc(p.note)}`:""}</div></div><div class="actions"><button class="btn small primary" data-action="purchase-to-stock" data-id="${p.id}">Omborga olish</button><button class="btn small danger" data-action="delete-purchase" data-id="${p.id}">O'chirish</button></div></div>`).join("")||`<div class="empty"><strong>🛒 Yaqinda ro'yxati bo'sh</strong></div>`}</div></div></section>`,
settings:()=>`<section><h1 class="page-title">Sozlamalar</h1><p class="page-sub">Daromadlar, xarajatlar va mahalliy ma'lumotlarni boshqarish.</p><div class="grid two"><div class="card"><h2>➕ Qo'shimcha daromad</h2><p class="muted">Mahsulot sotuviga kirmaydigan boshqa tushumlar.</p><button class="btn primary" data-action="add-income">+ Daromad qo'shish</button><div class="list" style="margin-top:14px">${[...state.incomes].reverse().map(i=>`<div class="row"><div><div class="row-title">${esc(i.name)}</div><div class="row-meta">${esc(i.date)}${i.note?` · ${esc(i.note)}`:""}</div></div><b>${money(i.amount)}</b></div>`).join("")||`<div class="empty">Hali qo'shimcha daromad yo'q.</div>`}</div></div><div class="card"><h2>💸 Xarajatlar</h2><p class="muted">Do'kon xarajatlari naqd puldan avtomatik ayriladi.</p><button class="btn primary" data-action="add-expense">+ Xarajat qo'shish</button><div class="list" style="margin-top:14px">${[...state.expenses].reverse().map(e=>`<div class="row"><div><div class="row-title">${esc(e.name)}</div><div class="row-meta">${esc(e.date)}${e.note?` · ${esc(e.note)}`:""}</div></div><b>− ${money(e.amount)}</b></div>`).join("")||`<div class="empty">Hali xarajat yo'q.</div>`}</div></div></div><div class="card" style="margin-top:14px"><h2>⚙ Ma'lumotlar</h2><div class="grid two"><div><div class="kpi-line"><span>Mahsulotlar</span><b>${state.products.length}</b></div><div class="kpi-line"><span>Sotuv yozuvlari</span><b>${state.sales.length}</b></div><div class="kpi-line"><span>Qo'shimcha daromadlar</span><b>${state.incomes.length}</b></div></div><div><div class="kpi-line"><span>Xarajatlar</span><b>${state.expenses.length}</b></div><div class="kpi-line"><span>Xarid rejalari</span><b>${state.purchases.length}</b></div><div class="kpi-line"><span>Joriy kassa</span><b>${money(state.cash)}</b></div></div></div><div class="actions" style="margin-top:16px"><button class="btn primary" data-action="add-cash">+ Kassaga pul qo'shish</button><button class="btn" data-action="export">JSON eksport</button><button class="btn" data-action="import">JSON import</button><button class="btn danger" data-action="reset">Barcha ma'lumotni tozalash</button></div></div></section>`
}
let cart={};
function cartInfo(){let n=0,total=0;for(const [id,v] of Object.entries(cart)){const p=state.products.find(x=>x.id===id),q=Number(v);if(p&&Number.isInteger(q)&&q>0){n++;total+=p.sell*q}}return {n,total}}
function saleBar(){const c=cartInfo();return `<div class="sale-bar"><div><div class="row-meta">Tanlangan: <b id="cartCount">${c.n}</b> xil tovar</div><div class="price" id="cartTotal">Jami: ${money(c.total)}</div><div class="row-meta">Mijoz bergan pul keyingi oynada so'raladi.</div></div><button class="btn primary" data-action="sell-all">SOTUVNI YAKUNLASH</button></div>`}
function filteredProducts(){return state.products.filter(p=>p.name.toLowerCase().includes(searchTerm.toLowerCase()))}
function bind(){
const theme=document.getElementById("themeToggle");if(theme)theme.onclick=toggleTheme;
const userSelect=document.getElementById("userSelect");if(userSelect){userSelect.value=state.settings.user||"None";userSelect.onchange=()=>{state.settings.user=userSelect.value||"None";save();}}
document.querySelectorAll("[data-route]").forEach(b=>b.onclick=()=>{route=b.dataset.route;searchTerm="";render(true)});
document.querySelectorAll("[data-route-go]").forEach(b=>b.onclick=()=>{route=b.dataset.routeGo;render(true)});
const si=document.getElementById("searchInventory"),ss=document.getElementById("searchSales"),sp=document.getElementById("searchPurchases");[si,ss,sp].forEach(el=>el&&el.addEventListener("input",e=>{searchTerm=e.target.value;const keep={};document.querySelectorAll(".sale-qty").forEach(i=>keep[i.dataset.id]=i.value);render();document.querySelectorAll(".sale-qty").forEach(i=>{if(keep[i.dataset.id])i.value=keep[i.dataset.id]});const target=document.getElementById(e.target.id);if(target){target.focus();target.selectionStart=target.value.length}}));
document.querySelectorAll(".sale-qty").forEach(i=>i.oninput=()=>{cart[i.dataset.id]=i.value;const c=cartInfo(),n=document.getElementById("cartCount"),t=document.getElementById("cartTotal");if(n)n.textContent=c.n;if(t)t.textContent=money(c.total)});
const am=document.getElementById("archiveMonth");if(am)am.onchange=e=>{archiveMonth=e.target.value;render()};
const aw=document.getElementById("archiveWeek");if(aw)aw.onchange=e=>{archiveWeek=e.target.value;render()};
document.querySelectorAll("[data-money-input]").forEach(i=>{
  i.value=formatMoneyInput(i.value);
  i.addEventListener("input",()=>{
    const old=i.value, caret=i.selectionStart??old.length, digitsBefore=(old.slice(0,caret).match(/\d/g)||[]).length, raw=old.replace(/\D/g,"");
    i.value=raw?raw.replace(/\B(?=(\d{3})+(?!\d))/g,"."):"";
    if(raw && document.activeElement===i){
      let pos=0, seen=0;
      while(pos<i.value.length && seen<digitsBefore){if(/\d/.test(i.value[pos]))seen++;pos++;}
      try{i.setSelectionRange(pos,pos)}catch{}
    }
  });
  i.addEventListener("blur",()=>{i.value=formatMoneyInput(i.value);});
});
document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>actions[b.dataset.action]?.(b.dataset.id));
}
const actions={
"archive-month":()=>{archiveMode="month";render()},
"archive-week":()=>{archiveMode="week";render()},
"archive-current-week":()=>{archiveMode="week";archiveWeek=today();render()},
"archive-prev-week":()=>{archiveMode="week";archiveWeek=shiftWeek(archiveWeek||today(),-1);render()},
"archive-next-week":()=>{archiveMode="week";archiveWeek=shiftWeek(archiveWeek||today(),1);render()},
"add-product":()=>openModal("Tovar qo'shish",productForm(),f=>{
  const name=f.get("name").trim(),qty=Number(f.get("qty")),buy=parseMoney(f.get("buy")),sell=parseMoney(f.get("sell")),free=f.get("free")==="on";
  if(!name||[qty,buy,sell].some(x=>!Number.isFinite(x)||x<0)||!Number.isInteger(qty))return toast("Ma'lumotlarni to'g'ri kiriting.","error");
  const old=findProduct(name,buy);
  if(old){
    old.qty+=qty; old.sell=sell;
    if(qty>0&&!free){state.stockPurchases.push({id:uid(),date:today(),name:old.name,productId:old.id,qty,unitCost:buy,total:buy*qty});}
    toast("Bir xil olish narxidagi tovar zaxirasi qo'shildi.");
  }else{
    const p={id:uid(),name,qty,buy,sell,addedAt:nowISO()};
    state.products.push(p);
    if(qty>0&&!free){state.stockPurchases.push({id:uid(),date:today(),name,productId:p.id,qty,unitCost:buy,total:buy*qty});}
    toast("Yangi tovar qo'shildi.");
  }
  syncCash();save();document.getElementById("modalRoot").innerHTML="";render()
}),
"edit-product":id=>{const p=state.products.find(x=>x.id===id);openModal("Tovarni tahrirlash",`${field("Tovar nomi","name","text",p.name||"","required")}${moneyField("Olish narxi (UZS)","buy",p.buy??0)}${moneyField("Sotish narxi (UZS)","sell",p.sell??0)}<p class="muted tiny">Joriy zaxira: <b>${p.qty}</b> dona. Zaxirani o'zgartirish uchun “+ Zaxira”dan foydalaning.</p>`,f=>{const name=f.get("name").trim(),buy=parseMoney(f.get("buy")),sell=parseMoney(f.get("sell"));if(!name||!Number.isFinite(buy)||buy<0||!Number.isFinite(sell)||sell<0)return toast("Ma'lumotlarni to'g'ri kiriting.","error");const duplicate=state.products.find(x=>x.id!==p.id&&normalizeProductName(x.name)===normalizeProductName(name)&&Number(x.buy)===buy);if(duplicate)return toast("Bu nomli tovar allaqachon bor.","error");p.name=name;p.buy=buy;p.sell=sell;syncCash();save();document.getElementById("modalRoot").innerHTML="";toast("Tovar saqlandi.");render()})},
"add-stock":id=>{const p=state.products.find(x=>x.id===id);if(!p)return;openModal("Zaxira qo'shish",`${field("Qo'shiladigan miqdor","qty","number",1,'min="1" step="1" required')}${moneyField("Olish narxi (UZS)","buy",p.buy)}<p class="muted tiny">Boshqa narx bo'lsa, shu tovarning alohida dublikati yaratiladi.</p>`,f=>{
  const q=Number(f.get("qty")),buy=parseMoney(f.get("buy"));
  if(!Number.isInteger(q)||q<=0||!Number.isFinite(buy)||buy<0)return toast("Miqdor va narxni to'g'ri kiriting.","error");
  const target=findProduct(p.name,buy);
  if(target){target.qty+=q;state.stockPurchases.push({id:uid(),date:today(),name:target.name,productId:target.id,qty:q,unitCost:buy,total:buy*q});}
  else{const np={id:uid(),name:p.name,qty:q,buy,sell:p.sell,addedAt:nowISO()};state.products.push(np);state.stockPurchases.push({id:uid(),date:today(),name:np.name,productId:np.id,qty:q,unitCost:buy,total:buy*q});}
  syncCash();save();document.getElementById("modalRoot").innerHTML="";toast("Zaxira qo'shildi.");render()
});},
"delete-product":id=>confirmAction("Bu mahsulotni o'chirishni xohlaysizmi?",()=>{state.products=state.products.filter(p=>p.id!==id);save();toast("Mahsulot o'chirildi.");render()}),
"sell":id=>{toast("Sotuvni yakunlash tugmasidan foydalaning.","error")},
"sell-all":()=>{
  const items=[];for(const [id,v] of Object.entries(cart)){
    const p=state.products.find(x=>x.id===id); if(!p||v===""||v==null||Number(v)===0)continue;
    const q=Number(v); if(!Number.isInteger(q)||q<=0)return toast((p?.name||"Tovar")+": miqdor 0 dan katta butun son bo'lsin.","error");
    if(q>p.qty)return toast(p.name+": omborda faqat "+p.qty+" dona bor.","error");
    items.push([p,q]);
  }
  if(!items.length)return toast("Kamida bitta tovar miqdorini kiriting.","error");
  const total=items.reduce((a,[p,q])=>a+p.sell*q,0);
  openModal("Sotuvni yakunlash",`${items.map(([p,q])=>`<div class="kpi-line"><span>${esc(p.name)} · ${q} dona</span><b>${money(p.sell*q)}</b></div>`).join("")}<div class="kpi-line"><span><b>Jami summa</b></span><b>${money(total)}</b></div>${moneyField("Mijoz bergan pul (UZS)","paid",total,'required')}<div class="field"><label>Qaytim / Qarz</label><div id="paymentPreview" class="price">${money(0)}</div></div>`,f=>{
    const paid=parseMoney(f.get("paid"));
    if(!Number.isInteger(paid)||paid<0)return toast("Mijoz bergan pul 0 yoki undan katta butun summa bo'lsin.","error");
    const change=Math.max(0,paid-total),debt=Math.max(0,total-paid),tid=uid(),time=new Date().toLocaleTimeString("uz-UZ",{hour:"2-digit",minute:"2-digit",second:"2-digit"});
    items.forEach(([p,q])=>{const revenue=p.sell*q,profit=(p.sell-p.buy)*q;p.qty-=q;state.sales.push({id:uid(),transactionId:tid,product:p.name,productId:p.id,qty:q,sellingPrice:p.sell,purchasePrice:p.buy,revenue,profit,paid,change,debt,date:today(),time});removeEmptyProduct(p);});
    syncCash();cart={};save();document.getElementById("modalRoot").innerHTML="";toast(debt>0?"Sotuv saqlandi. Qarz: "+money(debt):change>0?"Sotuv saqlandi. Qaytim: "+money(change):"Sotuv saqlandi.");render()
  });
  setTimeout(()=>{const inp=document.querySelector('#modalForm input[name="paid"]'),out=document.getElementById("paymentPreview");if(inp&&out)inp.oninput=()=>{const paid=parseMoney(inp.value||0),diff=paid-total;out.textContent=diff>=0?"Qaytim: "+money(diff):"Qarz: "+money(-diff)};},0)
},
"add-cash":()=>openModal("Kassaga pul qo'shish",`${moneyField("Summa (UZS)","amount","",'required')}<div class="field"><label>Izoh (ixtiyoriy)</label><textarea name="note" placeholder="Masalan: boshlang'ich pul"></textarea></div>`,f=>{const amount=parseMoney(f.get("amount"));if(!Number.isInteger(amount)||amount<=0)return toast("Summa 0 dan katta butun son bo'lsin.","error");addCashAdjustment(amount,f.get("note"));save();document.getElementById("modalRoot").innerHTML="";toast("Kassaga pul qo'shildi.");render()}),
"add-income":()=>openModal("Qo'shimcha daromad qo'shish",`${field("Daromad nomi","name","text","","required")}${moneyField("Summa (UZS)","amount","",'required')}${field("Sana","date","date",today(),"required")}<div class="field"><label>Izoh (ixtiyoriy)</label><textarea name="note" placeholder="Masalan: yetkazib berish xizmati"></textarea></div>`,f=>{const name=f.get("name").trim(),amount=parseMoney(f.get("amount")),date=f.get("date");if(!name||!Number.isInteger(amount)||amount<=0||!date)return toast("Daromad ma'lumotlari noto'g'ri.","error");state.incomes.push({id:uid(),name,amount,date,note:f.get("note")});syncCash();save();document.getElementById("modalRoot").innerHTML="";toast("Qo'shimcha daromad saqlandi.");render()}),
"add-expense":()=>openModal("Xarajat qo'shish",`${field("Xarajat nomi","name","text","","required")}${moneyField("Summa (UZS)","amount","",'required')}${field("Sana","date","date",today(),"required")}<div class="field"><label>Izoh (ixtiyoriy)</label><textarea name="note"></textarea></div>`,f=>{const name=f.get("name").trim(),amount=parseMoney(f.get("amount")),date=f.get("date");if(!name||!Number.isInteger(amount)||amount<=0)return toast("Xarajat ma'lumotlari noto'g'ri.","error");state.expenses.push({id:uid(),name,amount,date,note:f.get("note")});syncCash();save();document.getElementById("modalRoot").innerHTML="";toast("Xarajat saqlandi.");render()}),
"add-purchase":()=>openModal("Yaqinda ro'yxatiga qo'shish",`${field("Tovar nomi","name","text","","required")}${field("Miqdor","qty","number",1,'min="1" step="1" required')}${moneyField("Kutilgan narx (UZS)","expected",0,'required')}<div class="field"><label>Izoh</label><textarea name="note"></textarea></div>`,f=>{const name=f.get("name").trim(),qty=Number(f.get("qty")),expected=parseMoney(f.get("expected"));if(!name||!Number.isInteger(qty)||qty<=0||expected<0)return toast("Ma'lumotlar noto'g'ri.","error");state.purchases.push({id:uid(),name,qty,expected,note:f.get("note")});save();document.getElementById("modalRoot").innerHTML="";toast("Ro'yxatga qo'shildi.");render()}),
"delete-purchase":id=>confirmAction("Bu xarid rejasini o'chirishni xohlaysizmi?",()=>{state.purchases=state.purchases.filter(p=>p.id!==id);save();toast("O'chirildi.");render()}),
"purchase-to-stock":id=>{const p=state.purchases.find(x=>x.id===id);if(!p)return;const existing=findProduct(p.name,p.expected);openModal("Xaridni omborga olish",`${moneyField("Haqiqiy olish narxi (UZS)","buy",p.expected,'required')}${existing?"":moneyField("Sotish narxi (UZS)","sell",0,'required')}<p class="muted tiny">${p.qty} dona · Agar olish narxi boshqa bo'lsa, yangi dublikat yaratiladi.</p>`,f=>{
  const buy=parseMoney(f.get("buy")),sell=existing?existing.sell:parseMoney(f.get("sell"));
  if(!Number.isFinite(buy)||buy<0||!Number.isFinite(sell)||sell<0)return toast("Narx noto'g'ri.","error");
  const target=findProduct(p.name,buy);
  if(target)target.qty+=p.qty;
  else {const np={id:uid(),name:p.name,qty:p.qty,buy,sell,addedAt:nowISO()};state.products.push(np);}
  const prod=target||state.products[state.products.length-1];
  state.stockPurchases.push({id:uid(),date:today(),name:p.name,productId:prod.id,qty:p.qty,unitCost:buy,total:buy*p.qty});
  state.purchases=state.purchases.filter(x=>x.id!==id);syncCash();save();document.getElementById("modalRoot").innerHTML="";toast("Xarid omborga olindi.");render()
  })},
"export":()=>{const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`tavars-backup-${today()}.json`;a.click();URL.revokeObjectURL(a.href);toast("Backup tayyor.")},
"import":()=>{const inp=document.createElement("input");inp.type="file";inp.accept="application/json,.json";inp.onchange=()=>{const f=inp.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const d=JSON.parse(r.result);if(!d||typeof d!=="object"||!Array.isArray(d.products))throw new Error("bad");const restored=normalizeState(d);restored.cash=0;confirmAction("Joriy ma'lumotlar backup fayli bilan almashtiriladi. Davom etasizmi?",()=>{state=restored;syncCash();if(!save())return;toast("Backup tiklandi. Kassa hisob-kitobi ham tekshirilib tiklandi.");render()})}catch(e){toast("Backup fayli noto'g'ri.","error")}};r.readAsText(f)};inp.click()},
reset:()=>confirmAction("Barcha mahalliy ma'lumotlar butunlay o'chiriladi. Davom etasizmi?",()=>{localStorage.removeItem(KEY);state=load();toast("Ma'lumotlar tozalandi.");render()})
};
syncCash();
applyTheme();
render();
setTimeout(()=>document.getElementById("appLoader")?.classList.add("is-hidden"),1100);
let refreshDay=today();
setInterval(()=>{const d=today();if(d!==refreshDay){refreshDay=d;render();}},60000);
document.addEventListener("keydown",e=>{if(e.key==="Escape")document.getElementById("modalRoot").innerHTML=""});
