const KEY="naam_jap_tracker_v1";
const defaultState={goal:108,mantra:"राधे राधे",days:{},theme:"dark"};
let state=load();

function localDate(d=new Date()){
  const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,"0"),day=String(d.getDate()).padStart(2,"0");
  return `${y}-${m}-${day}`;
}
function load(){try{return {...defaultState,...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch(e){return {...defaultState}}}
function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function countFor(key){return Number(state.days[key]||0)}
function fmt(n){return new Intl.NumberFormat("hi-IN").format(n)}
function dateLabel(key){
 const d=new Date(key+"T12:00:00");
 return d.toLocaleDateString("hi-IN",{day:"numeric",month:"short",year:"numeric"});
}
function render(){
 const today=localDate(), c=countFor(today), goal=Math.max(1,Number(state.goal)||108);
 document.getElementById("todayCount").textContent=fmt(c);
 document.getElementById("todayDate").textContent=new Date().toLocaleDateString("hi-IN",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
 document.getElementById("progress").style.width=Math.min(100,c/goal*100)+"%";
 document.getElementById("progressText").textContent=`${fmt(c)} / ${fmt(goal)}`;
 document.getElementById("percentText").textContent=Math.round(c/goal*100)+"%";
 document.getElementById("mantraInput").value=state.mantra||"राधे राधे";

 const keys=Object.keys(state.days);
 const total=keys.reduce((a,k)=>a+countFor(k),0);
 document.getElementById("totalCount").textContent=fmt(total);
 document.getElementById("activeDays").textContent=keys.filter(k=>countFor(k)>0).length;
 document.getElementById("avgCount").textContent=fmt(keys.length?Math.round(total/keys.length):0);
 document.getElementById("streak").textContent=fmt(calcStreak());

 renderChart(); renderAnalysis(); renderHistory();
 document.body.classList.toggle("light",state.theme==="light");
}
function calcStreak(){
 let d=new Date(), streak=0;
 if(countFor(localDate(d))===0)d.setDate(d.getDate()-1);
 while(countFor(localDate(d))>0){streak++;d.setDate(d.getDate()-1)}
 return streak;
}
function renderChart(){
 const chart=document.getElementById("chart"); chart.innerHTML="";
 const vals=[]; const now=new Date();
 for(let i=6;i>=0;i--){let d=new Date(now);d.setDate(now.getDate()-i);let k=localDate(d);vals.push({k,v:countFor(k),day:d.toLocaleDateString("hi-IN",{weekday:"short"})})}
 const max=Math.max(1,...vals.map(x=>x.v));
 vals.forEach(x=>{
   const w=document.createElement("div");w.className="bar-wrap";
   w.innerHTML=`<div class="bar-value">${fmt(x.v)}</div><div class="bar" style="height:${Math.max(2,x.v/max*115)}px"></div><div class="bar-day">${x.day}</div>`;
   chart.appendChild(w);
 });
}
function renderAnalysis(){
 const a=document.getElementById("analysis"), today=countFor(localDate()), goal=Math.max(1,Number(state.goal)||108);
 const keys=Object.keys(state.days), total=keys.reduce((s,k)=>s+countFor(k),0);
 let best=keys.sort((x,y)=>countFor(y)-countFor(x))[0];
 const items=[
  `आज ${fmt(today)} जाप दर्ज है; दैनिक लक्ष्य ${fmt(goal)} है।`,
  `कुल ${fmt(total)} जाप ${keys.filter(k=>countFor(k)>0).length} सक्रिय दिनों में दर्ज हैं।`,
  best?`सबसे अधिक जाप वाला दिन ${dateLabel(best)} रहा: ${fmt(countFor(best))} जाप।`:"अभी पर्याप्त इतिहास नहीं है।",
  `वर्तमान स्ट्रीक ${fmt(calcStreak())} दिन की है।`
 ];
 a.innerHTML=items.map(x=>`<div class="analysis-item">${x}</div>`).join("");
}
function renderHistory(){
 const h=document.getElementById("history");
 const keys=Object.keys(state.days).filter(k=>countFor(k)>0).sort().reverse().slice(0,30);
 h.innerHTML=keys.length?keys.map(k=>`<div class="history-row"><span>${dateLabel(k)}</span><strong>${fmt(countFor(k))}</strong></div>`).join(""):`<div class="muted">अभी कोई इतिहास नहीं है।</div>`;
}
function change(n){
 const k=localDate(); state.days[k]=Math.max(0,countFor(k)+n); save(); render();
}
document.getElementById("japBtn").onclick=()=>change(1);
document.getElementById("minusBtn").onclick=()=>change(-1);
document.getElementById("resetTodayBtn").onclick=()=>{if(confirm("आज की गिनती रीसेट करें?")){delete state.days[localDate()];save();render()}};
document.getElementById("goalBtn").onclick=()=>{
 const v=prompt("दैनिक लक्ष्य कितने जाप रखें?",state.goal);
 if(v!==null){const n=Number(v);if(Number.isFinite(n)&&n>0){state.goal=Math.round(n);save();render()}}
};
document.getElementById("mantraInput").onchange=e=>{state.mantra=e.target.value.trim()||"राधे राधे";save();render()};
document.getElementById("themeBtn").onclick=()=>{state.theme=state.theme==="light"?"dark":"light";save();render()};
document.getElementById("clearBtn").onclick=()=>{
 if(confirm("पूरा इतिहास हटाना है? यह वापस नहीं आएगा।")){state.days={};save();render()}
};
document.getElementById("exportBtn").onclick=()=>{
 const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"});
 const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="naam-jap-backup.json";a.click();URL.revokeObjectURL(a.href);
};
document.getElementById("importFile").onchange=e=>{
 const file=e.target.files[0];if(!file)return;
 const r=new FileReader();r.onload=()=>{
  try{const incoming=JSON.parse(r.result);if(!incoming.days||typeof incoming.days!=="object")throw 0;
    state={...defaultState,...incoming,days:incoming.days};save();render();alert("Backup import हो गया।")
  }catch(err){alert("यह valid Naam Jap backup नहीं है।")}
 };r.readAsText(file);
};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js").catch(()=>{}));
render();
