// India GPT - Pure Vanilla JavaScript Engine
const chatViewport = document.getElementById('chatViewport');
const messagesList = document.getElementById('messagesList');
const welcomeCard = document.getElementById('welcomeCard');
const chatForm = document.getElementById('chatForm');
const userInput = document.getElementById('userInput');
const voiceBtn = document.getElementById('voiceBtn');
const clearChatBtn = document.getElementById('clearChatBtn');
const micBtn = document.getElementById('micBtn');

let voiceEnabled = true;
let isSpeaking = false;
let chatHistory = [];

// Initialize Speech Synthesis
function speak(text) {
  if (!voiceEnabled || !window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'hi-IN';
  utterance.rate = 1.0;
  window.speechSynthesis.speak(utterance);
}

voiceBtn.addEventListener('click', () => {
  voiceEnabled = !voiceEnabled;
  voiceBtn.textContent = voiceEnabled ? '🔊 Awaaz On' : '🔈 Awaaz Off';
  if (!voiceEnabled && window.speechSynthesis) {
    window.speechSynthesis.cancel();
  }
});

clearChatBtn.addEventListener('click', () => {
  messagesList.innerHTML = '';
  chatHistory = [];
  welcomeCard.style.display = 'block';
  if (window.speechSynthesis) window.speechSynthesis.cancel();
});

// Append message
function appendMessage(role, text) {
  welcomeCard.style.display = 'none';
  const wrapper = document.createElement('div');
  wrapper.className = `msg-wrapper ${role}`;

  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble';
  bubble.innerText = text;

  const meta = document.createElement('div');
  meta.className = 'msg-meta';
  meta.innerText = role === 'user' ? 'Aap' : 'India GPT';

  wrapper.appendChild(bubble);
  wrapper.appendChild(meta);
  messagesList.appendChild(wrapper);

  chatViewport.scrollTop = chatViewport.scrollHeight;
  return bubble;
}

// Send user query
async function handleSend(text) {
  if (!text || !text.trim()) return;
  const userText = text.trim();
  userInput.value = '';

  appendMessage('user', userText);
  chatHistory.push({ role: 'user', content: userText });

  const aiBubble = appendMessage('ai', 'Soch raha hoon...');

  try {
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-id': localStorage.getItem('india_ai_user_id') || 'guest_user'
      },
      body: JSON.stringify({
        message: userText,
        history: chatHistory.slice(0, -1),
        model: 'gemini-3.1-flash-lite',
        persona: 'Female',
        language: 'Hinglish'
      })
    });

    if (!response.ok) {
      aiBubble.innerText = "Namaste! Server se connect karne mein samasya aayi. Kripya thodi der baad prayas karein.";
      return;
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let accumulated = '';
    aiBubble.innerText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split('\n');

      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const raw = line.slice(6).trim();
          if (raw === '[DONE]') break;
          try {
            const parsed = JSON.parse(raw);
            if (parsed.text) {
              accumulated += parsed.text;
              aiBubble.innerText = accumulated;
              chatViewport.scrollTop = chatViewport.scrollHeight;
            }
          } catch (e) {}
        }
      }
    }

    if (!accumulated) {
      accumulated = "Namaste! Main aapki kya madad kar sakta hoon?";
      aiBubble.innerText = accumulated;
    }

    chatHistory.push({ role: 'model', content: accumulated });
    speak(accumulated);

  } catch (err) {
    console.error(err);
    aiBubble.innerText = "Namaste! Network connection check karein aur punah prayas karein.";
  }
}

chatForm.addEventListener('submit', (e) => {
  e.preventDefault();
  handleSend(userInput.value);
});

window.sendQuickPrompt = function(promptText) {
  userInput.value = promptText;
  handleSend(promptText);
};

// Speech Recognition (Mic)
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.lang = 'hi-IN';
  recognition.interimResults = false;

  micBtn.addEventListener('click', () => {
    micBtn.innerText = '🔴';
    recognition.start();
  });

  recognition.onresult = (event) => {
    micBtn.innerText = '🎤';
    const transcript = event.results[0][0].transcript;
    userInput.value = transcript;
    handleSend(transcript);
  };

  recognition.onerror = () => {
    micBtn.innerText = '🎤';
  };

  recognition.onend = () => {
    micBtn.innerText = '🎤';
  };
} else {
  micBtn.style.display = 'none';
}
