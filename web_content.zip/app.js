// برنامه‌ریز شخصی - اهداف، برنامه‌ها، کارها + ورودی صوتی

const STORAGE_KEY = 'planner_app_data_v1';

let data = JSON.parse(localStorage.getItem(STORAGE_KEY)) || {
  tasks: [],
  plans: [],
  goals: [],
  daily: {
    urgentImportant: [],
    important: [],
    urgent: [],
    low: []
  }
};

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

// مهاجرت داده‌های قدیمی
if (!data.daily) {
  data.daily = { urgentImportant: [], important: [], urgent: [], low: [] };
  save();
}

function formatDate(iso) {
  if (!iso) return '';
  try {
    return new Date(iso).toLocaleDateString('fa-IR');
  } catch {
    return '';
  }
}

// تب‌ها
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById('tab-' + tab.dataset.tab).classList.add('active');
  });
});

// فیلتر کارها
let taskFilter = 'all';
document.querySelectorAll('.filter').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    taskFilter = btn.dataset.filter;
    renderTasks();
  });
});

// ===== ورودی صوتی =====
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
let currentVoiceTarget = null;

const voiceStatus = document.getElementById('voiceStatus');

function setVoiceStatus(msg) {
  if (voiceStatus) voiceStatus.textContent = msg || '';
}

if (SpeechRecognition) {
  recognition = new SpeechRecognition();
  recognition.lang = 'fa-IR';
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onstart = () => {
    setVoiceStatus('در حال گوش دادن... صحبت کنید');
    if (currentVoiceTarget) {
      document.getElementById(currentVoiceTarget.btnId)?.classList.add('listening');
    }
  };

  recognition.onresult = (event) => {
    const text = event.results[0][0].transcript.trim();
    if (text && currentVoiceTarget) {
      const input = document.getElementById(currentVoiceTarget.inputId);
      if (input) {
        input.value = (input.value ? input.value + ' ' : '') + text;
        input.focus();
      }
    }
    setVoiceStatus('متن دریافت شد');
    setTimeout(() => setVoiceStatus(''), 2000);
  };

  recognition.onerror = (event) => {
    let msg = 'خطا در تشخیص صدا';
    if (event.error === 'not-allowed') msg = 'دسترسی میکروفون داده نشده';
    else if (event.error === 'no-speech') msg = 'صدایی شنیده نشد';
    setVoiceStatus(msg);
    setTimeout(() => setVoiceStatus(''), 3000);
  };

  recognition.onend = () => {
    document.querySelectorAll('.btn-voice').forEach(b => b.classList.remove('listening'));
    currentVoiceTarget = null;
  };
}

function startVoice(inputId, btnId) {
  if (!recognition) {
    alert('مرورگر یا WebView شما از ورودی صوتی پشتیبانی نمی‌کند.\nدر کروم اندروید معمولاً کار می‌کند.');
    return;
  }
  try {
    recognition.stop();
  } catch (e) {}
  currentVoiceTarget = { inputId, btnId };
  try {
    recognition.start();
  } catch (e) {
    setVoiceStatus('نتوانست میکروفون را شروع کند');
  }
}

document.getElementById('taskVoice')?.addEventListener('click', () => startVoice('taskInput', 'taskVoice'));
document.getElementById('planVoice')?.addEventListener('click', () => startVoice('planInput', 'planVoice'));
document.getElementById('goalVoice')?.addEventListener('click', () => startVoice('goalInput', 'goalVoice'));

// ===== افزودن آیتم =====
function addItem(type, text) {
  text = (text || '').trim();
  if (!text) {
    alert('متن خالی است.');
    return;
  }
  const item = {
    id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
    text,
    done: false,
    createdAt: new Date().toISOString()
  };
  data[type].unshift(item);
  save();
  
// ===== سیستم هشدار (وقتی برنامه باز است) =====
// تبدیل تقریبی تاریخ شمسی به میلادی برای مقایسه
function shamsiToGregorian(jy, jm, jd) {
  jy = parseInt(jy); jm = parseInt(jm); jd = parseInt(jd);
  if (!jy || !jm || !jd) return null;
  const g_days_in_month = [31,28,31,30,31,30,31,31,30,31,30,31];
  const j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];
  let jy2 = (jy > 979) ? jy - 979 : jy - 0;
  let gy = (jy > 979) ? 1600 : 621;
  let days = (365 * jy2) + Math.floor(jy2 / 33) * 8 + Math.floor(((jy2 % 33) + 3) / 4);
  for (let i = 0; i < jm - 1; i++) days += j_days_in_month[i];
  days += jd - 1;
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gm = 0;
  for (; gm < 12; gm++) {
    const v = g_days_in_month[gm] + (gm === 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 1 : 0);
    if (days < v) break;
    days -= v;
  }
  return new Date(gy, gm, days + 1);
}

function parseTaskDue(item) {
  if (!item.shamsiDate || !item.time) return null;
  const parts = item.shamsiDate.split('/');
  if (parts.length < 3) return null;
  const [jy, jm, jd] = parts.map(Number);
  const g = shamsiToGregorian(jy, jm, jd);
  if (!g || isNaN(g.getTime())) return null;
  const [h, m] = item.time.split(':').map(n => parseInt(n) || 0);
  g.setHours(h, m, 0, 0);
  return g;
}

const alertedTasks = new Set(JSON.parse(sessionStorage.getItem('alertedTasks') || '[]'));

function triggerAlarm(item) {
  if (alertedTasks.has(item.id)) return;
  alertedTasks.add(item.id);
  sessionStorage.setItem('alertedTasks', JSON.stringify([...alertedTasks]));

  const title = 'هشدار کار';
  const body = item.text + (item.shamsiDate ? '\\n' + item.shamsiDate + ' ' + (item.time || '') : '');

  // تلاش برای نوتیفیکیشن سیستم
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, { body: body, requireInteraction: true });
    } catch (e) {}
  }

  // صدا (بیپ ساده با Web Audio)
  if (item.alarm === 'ring') {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playBeep = (freq, start, dur) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = freq;
        g.gain.value = 0.3;
        o.start(ctx.currentTime + start);
        o.stop(ctx.currentTime + start + dur);
      };
      playBeep(880, 0, 0.2);
      playBeep(880, 0.3, 0.2);
      playBeep(880, 0.6, 0.35);
    } catch (e) {}
  }

  alert('⏰ هشدار\\n\\n' + body);
}

function checkAlarms() {
  const now = new Date();
  (data.tasks || []).forEach(item => {
    if (item.done) return;
    if (item.alarm !== 'ring') return;
    const due = parseTaskDue(item);
    if (!due) return;
    // اگر زمان سررسید گذشته و کمتر از ۲ دقیقه از آن گذشته باشد
    const diff = now.getTime() - due.getTime();
    if (diff >= 0 && diff < 2 * 60 * 1000) {
      triggerAlarm(item);
    }
  });
}

// درخواست مجوز نوتیفیکیشن
if ('Notification' in window && Notification.permission === 'default') {
  try { Notification.requestPermission(); } catch (e) {}
}

// چک هر ۲۰ ثانیه وقتی برنامه باز است
setInterval(checkAlarms, 20000);
setTimeout(checkAlarms, 3000);


renderAll();
}

const PRIORITY_LABELS = {
  urgentImportant: 'فوری و مهم',
  urgent: 'فوری کم‌اهمیت',
  important: 'مهم غیرفوری',
  low: 'کم‌اهمیت غیرفوری'
};

document.getElementById('taskAdd')?.addEventListener('click', () => {
  const text = document.getElementById('taskInput').value.trim();
  if (!text) { alert('متن کار را بنویسید.'); return; }
  const priority = document.getElementById('taskPriority').value;
  const alarm = document.querySelector('input[name="taskAlarm"]:checked')?.value || 'silent';
  const day = document.getElementById('taskDay').value;
  const month = document.getElementById('taskMonth').value;
  const year = document.getElementById('taskYear').value;
  const hour = document.getElementById('taskHour').value;
  const minute = document.getElementById('taskMinute').value;

  let shamsiDate = '';
  if (year && month && day) {
    shamsiDate = year + '/' + String(month).padStart(2,'0') + '/' + String(day).padStart(2,'0');
  }
  let timeStr = '';
  if (hour !== '' || minute !== '') {
    timeStr = String(hour || '0').padStart(2,'0') + ':' + String(minute || '0').padStart(2,'0');
  }

  data.tasks.unshift({
    id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
    text,
    done: false,
    priority,
    alarm,
    shamsiDate,
    time: timeStr,
    createdAt: new Date().toISOString()
  });
  save();
  
// ===== سیستم هشدار (وقتی برنامه باز است) =====
// تبدیل تقریبی تاریخ شمسی به میلادی برای مقایسه
function shamsiToGregorian(jy, jm, jd) {
  jy = parseInt(jy); jm = parseInt(jm); jd = parseInt(jd);
  if (!jy || !jm || !jd) return null;
  const g_days_in_month = [31,28,31,30,31,30,31,31,30,31,30,31];
  const j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];
  let jy2 = (jy > 979) ? jy - 979 : jy - 0;
  let gy = (jy > 979) ? 1600 : 621;
  let days = (365 * jy2) + Math.floor(jy2 / 33) * 8 + Math.floor(((jy2 % 33) + 3) / 4);
  for (let i = 0; i < jm - 1; i++) days += j_days_in_month[i];
  days += jd - 1;
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gm = 0;
  for (; gm < 12; gm++) {
    const v = g_days_in_month[gm] + (gm === 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 1 : 0);
    if (days < v) break;
    days -= v;
  }
  return new Date(gy, gm, days + 1);
}

function parseTaskDue(item) {
  if (!item.shamsiDate || !item.time) return null;
  const parts = item.shamsiDate.split('/');
  if (parts.length < 3) return null;
  const [jy, jm, jd] = parts.map(Number);
  const g = shamsiToGregorian(jy, jm, jd);
  if (!g || isNaN(g.getTime())) return null;
  const [h, m] = item.time.split(':').map(n => parseInt(n) || 0);
  g.setHours(h, m, 0, 0);
  return g;
}

const alertedTasks = new Set(JSON.parse(sessionStorage.getItem('alertedTasks') || '[]'));

function triggerAlarm(item) {
  if (alertedTasks.has(item.id)) return;
  alertedTasks.add(item.id);
  sessionStorage.setItem('alertedTasks', JSON.stringify([...alertedTasks]));

  const title = 'هشدار کار';
  const body = item.text + (item.shamsiDate ? '\\n' + item.shamsiDate + ' ' + (item.time || '') : '');

  // تلاش برای نوتیفیکیشن سیستم
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, { body: body, requireInteraction: true });
    } catch (e) {}
  }

  // صدا (بیپ ساده با Web Audio)
  if (item.alarm === 'ring') {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playBeep = (freq, start, dur) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = freq;
        g.gain.value = 0.3;
        o.start(ctx.currentTime + start);
        o.stop(ctx.currentTime + start + dur);
      };
      playBeep(880, 0, 0.2);
      playBeep(880, 0.3, 0.2);
      playBeep(880, 0.6, 0.35);
    } catch (e) {}
  }

  alert('⏰ هشدار\\n\\n' + body);
}

function checkAlarms() {
  const now = new Date();
  (data.tasks || []).forEach(item => {
    if (item.done) return;
    if (item.alarm !== 'ring') return;
    const due = parseTaskDue(item);
    if (!due) return;
    // اگر زمان سررسید گذشته و کمتر از ۲ دقیقه از آن گذشته باشد
    const diff = now.getTime() - due.getTime();
    if (diff >= 0 && diff < 2 * 60 * 1000) {
      triggerAlarm(item);
    }
  });
}

// درخواست مجوز نوتیفیکیشن
if ('Notification' in window && Notification.permission === 'default') {
  try { Notification.requestPermission(); } catch (e) {}
}

// چک هر ۲۰ ثانیه وقتی برنامه باز است
setInterval(checkAlarms, 20000);
setTimeout(checkAlarms, 3000);


renderAll();
  document.getElementById('taskInput').value = '';
  document.getElementById('taskDay').value = '';
  document.getElementById('taskMonth').value = '';
  document.getElementById('taskYear').value = '';
  document.getElementById('taskHour').value = '';
  document.getElementById('taskMinute').value = '';
});
document.getElementById('planAdd')?.addEventListener('click', () => {
  addItem('plans', document.getElementById('planInput').value);
  document.getElementById('planInput').value = '';
});
document.getElementById('goalAdd')?.addEventListener('click', () => {
  addItem('goals', document.getElementById('goalInput').value);
  document.getElementById('goalInput').value = '';
});

// Enter برای افزودن
['planInput', 'goalInput'].forEach(id => {
  document.getElementById(id)?.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const map = { planInput: 'plans', goalInput: 'goals' };
      addItem(map[id], e.target.value);
      e.target.value = '';
    }
  });
});
document.getElementById('taskInput')?.addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    e.preventDefault();
    document.getElementById('taskAdd')?.click();
  }
});

// ===== رندر =====
function renderList(type, listId, emptyId, showCheck) {
  const listEl = document.getElementById(listId);
  const emptyEl = document.getElementById(emptyId);
  let items = data[type] || [];

  if (type === 'tasks' && taskFilter === 'open') items = items.filter(i => !i.done);
  if (type === 'tasks' && taskFilter === 'done') items = items.filter(i => i.done);

  listEl.innerHTML = '';
  if (items.length === 0) {
    emptyEl.style.display = 'block';
    return;
  }
  emptyEl.style.display = 'none';

  items.forEach(item => {
    const div = document.createElement('div');
    div.className = 'item' + (item.done ? ' done' : '');
    div.innerHTML = `
      ${showCheck ? `<input type="checkbox" class="item-check" data-id="${item.id}" data-type="${type}" ${item.done ? 'checked' : ''}>` : ''}
      <div class="item-body">
        <div class="item-text">${escapeHtml(item.text)}</div>
        <div class="item-meta">${formatDate(item.createdAt)}</div>
      </div>
      <div class="item-actions">
        <button data-action="edit" data-id="${item.id}" data-type="${type}" title="ویرایش">✏️</button>
        <button data-action="delete" data-id="${item.id}" data-type="${type}" title="حذف">🗑️</button>
      </div>
    `;
    listEl.appendChild(div);
  });
}

function escapeHtml(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}


// ===== ماتریس کار روزانه =====
const QUADS = ['urgentImportant', 'important', 'urgent', 'low'];

function addDailyItem(quad, text) {
  text = (text || '').trim();
  if (!text) return;
  if (!data.daily[quad]) data.daily[quad] = [];
  data.daily[quad].unshift({
    id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
    text,
    done: false,
    createdAt: new Date().toISOString()
  });
  save();
  renderDaily();
}

function renderDaily() {
  QUADS.forEach(quad => {
    const listEl = document.getElementById('list-' + quad);
    if (!listEl) return;
    const items = data.daily[quad] || [];
    listEl.innerHTML = '';
    items.forEach(item => {
      const div = document.createElement('div');
      div.className = 'q-item' + (item.done ? ' done' : '');
      div.innerHTML = `
        <input type="checkbox" ${item.done ? 'checked' : ''} data-quad="${quad}" data-id="${item.id}" class="q-check">
        <span class="q-item-text">${escapeHtml(item.text)}</span>
        <button class="q-item-del" data-quad="${quad}" data-id="${item.id}">×</button>
      `;
      listEl.appendChild(div);
    });
  });
}

document.querySelectorAll('.q-btn-add').forEach(btn => {
  btn.addEventListener('click', () => {
    const quad = btn.dataset.quad;
    const input = document.getElementById('input-' + quad);
    addDailyItem(quad, input.value);
    input.value = '';
    input.focus();
  });
});

QUADS.forEach(quad => {
  const input = document.getElementById('input-' + quad);
  input?.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addDailyItem(quad, input.value);
      input.value = '';
    }
  });
});

document.addEventListener('click', e => {
  if (e.target.classList.contains('q-check')) {
    const quad = e.target.dataset.quad;
    const id = e.target.dataset.id;
    const item = (data.daily[quad] || []).find(i => i.id === id);
    if (item) {
      item.done = e.target.checked;
      save();
      renderDaily();
    }
  }
  if (e.target.classList.contains('q-item-del')) {
    const quad = e.target.dataset.quad;
    const id = e.target.dataset.id;
    data.daily[quad] = (data.daily[quad] || []).filter(i => i.id !== id);
    save();
    renderDaily();
  }
});


function renderTasks() {
  const listEl = document.getElementById('taskList');
  const emptyEl = document.getElementById('taskEmpty');
  let items = data.tasks || [];
  if (taskFilter === 'open') items = items.filter(i => !i.done);
  if (taskFilter === 'done') items = items.filter(i => i.done);

  listEl.innerHTML = '';
  if (items.length === 0) {
    emptyEl.style.display = 'block';
    return;
  }
  emptyEl.style.display = 'none';

  items.forEach(item => {
    const p = item.priority || 'low';
    const alarmIcon = item.alarm === 'ring' ? '🔔' : '🔕';
    let meta = formatDate(item.createdAt);
    if (item.shamsiDate) meta = item.shamsiDate + (item.time ? ' ' + item.time : '');
    else if (item.time) meta = item.time;

    const div = document.createElement('div');
    div.className = 'item' + (item.done ? ' done' : '') + ' p-border-' + p;
    div.innerHTML = `
      <input type="checkbox" class="item-check" data-id="${item.id}" data-type="tasks" ${item.done ? 'checked' : ''}>
      <div class="item-body">
        <div class="item-text">${escapeHtml(item.text)}
          <span class="priority-badge p-${p}">${PRIORITY_LABELS[p] || p}</span>
          <span class="alarm-icon">${alarmIcon}</span>
        </div>
        <div class="item-meta">${meta}</div>
      </div>
      <div class="item-actions">
        <button data-action="edit" data-id="${item.id}" data-type="tasks" title="ویرایش">✏️</button>
        <button data-action="delete" data-id="${item.id}" data-type="tasks" title="حذف">🗑️</button>
      </div>
    `;
    listEl.appendChild(div);
  });
}
function renderPlans() { renderList('plans', 'planList', 'planEmpty', true); }
function renderGoals() { renderList('goals', 'goalList', 'goalEmpty', true); }
function renderAll() {
  renderTasks();
  renderPlans();
  renderGoals();
  renderDaily();
}

// رویدادهای لیست (چک، ویرایش، حذف)
document.addEventListener('click', e => {
  const t = e.target;

  // چک‌باکس
  if (t.classList.contains('item-check')) {
    const type = t.dataset.type;
    const id = t.dataset.id;
    const item = (data[type] || []).find(i => i.id === id);
    if (item) {
      item.done = t.checked;
      save();
      
// ===== سیستم هشدار (وقتی برنامه باز است) =====
// تبدیل تقریبی تاریخ شمسی به میلادی برای مقایسه
function shamsiToGregorian(jy, jm, jd) {
  jy = parseInt(jy); jm = parseInt(jm); jd = parseInt(jd);
  if (!jy || !jm || !jd) return null;
  const g_days_in_month = [31,28,31,30,31,30,31,31,30,31,30,31];
  const j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];
  let jy2 = (jy > 979) ? jy - 979 : jy - 0;
  let gy = (jy > 979) ? 1600 : 621;
  let days = (365 * jy2) + Math.floor(jy2 / 33) * 8 + Math.floor(((jy2 % 33) + 3) / 4);
  for (let i = 0; i < jm - 1; i++) days += j_days_in_month[i];
  days += jd - 1;
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gm = 0;
  for (; gm < 12; gm++) {
    const v = g_days_in_month[gm] + (gm === 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 1 : 0);
    if (days < v) break;
    days -= v;
  }
  return new Date(gy, gm, days + 1);
}

function parseTaskDue(item) {
  if (!item.shamsiDate || !item.time) return null;
  const parts = item.shamsiDate.split('/');
  if (parts.length < 3) return null;
  const [jy, jm, jd] = parts.map(Number);
  const g = shamsiToGregorian(jy, jm, jd);
  if (!g || isNaN(g.getTime())) return null;
  const [h, m] = item.time.split(':').map(n => parseInt(n) || 0);
  g.setHours(h, m, 0, 0);
  return g;
}

const alertedTasks = new Set(JSON.parse(sessionStorage.getItem('alertedTasks') || '[]'));

function triggerAlarm(item) {
  if (alertedTasks.has(item.id)) return;
  alertedTasks.add(item.id);
  sessionStorage.setItem('alertedTasks', JSON.stringify([...alertedTasks]));

  const title = 'هشدار کار';
  const body = item.text + (item.shamsiDate ? '\\n' + item.shamsiDate + ' ' + (item.time || '') : '');

  // تلاش برای نوتیفیکیشن سیستم
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, { body: body, requireInteraction: true });
    } catch (e) {}
  }

  // صدا (بیپ ساده با Web Audio)
  if (item.alarm === 'ring') {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playBeep = (freq, start, dur) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = freq;
        g.gain.value = 0.3;
        o.start(ctx.currentTime + start);
        o.stop(ctx.currentTime + start + dur);
      };
      playBeep(880, 0, 0.2);
      playBeep(880, 0.3, 0.2);
      playBeep(880, 0.6, 0.35);
    } catch (e) {}
  }

  alert('⏰ هشدار\\n\\n' + body);
}

function checkAlarms() {
  const now = new Date();
  (data.tasks || []).forEach(item => {
    if (item.done) return;
    if (item.alarm !== 'ring') return;
    const due = parseTaskDue(item);
    if (!due) return;
    // اگر زمان سررسید گذشته و کمتر از ۲ دقیقه از آن گذشته باشد
    const diff = now.getTime() - due.getTime();
    if (diff >= 0 && diff < 2 * 60 * 1000) {
      triggerAlarm(item);
    }
  });
}

// درخواست مجوز نوتیفیکیشن
if ('Notification' in window && Notification.permission === 'default') {
  try { Notification.requestPermission(); } catch (e) {}
}

// چک هر ۲۰ ثانیه وقتی برنامه باز است
setInterval(checkAlarms, 20000);
setTimeout(checkAlarms, 3000);


renderAll();
    }
    return;
  }

  // دکمه ویرایش / حذف (با closest برای کلیک روی ایموجی)
  const btn = t.closest('[data-action]');
  if (!btn) return;
  const action = btn.dataset.action;
  const type = btn.dataset.type;
  const id = btn.dataset.id;
  if (!action || !type || !id) return;

  if (action === 'delete') {
    if (confirm('حذف شود؟')) {
      data[type] = (data[type] || []).filter(i => i.id !== id);
      save();
      
// ===== سیستم هشدار (وقتی برنامه باز است) =====
// تبدیل تقریبی تاریخ شمسی به میلادی برای مقایسه
function shamsiToGregorian(jy, jm, jd) {
  jy = parseInt(jy); jm = parseInt(jm); jd = parseInt(jd);
  if (!jy || !jm || !jd) return null;
  const g_days_in_month = [31,28,31,30,31,30,31,31,30,31,30,31];
  const j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];
  let jy2 = (jy > 979) ? jy - 979 : jy - 0;
  let gy = (jy > 979) ? 1600 : 621;
  let days = (365 * jy2) + Math.floor(jy2 / 33) * 8 + Math.floor(((jy2 % 33) + 3) / 4);
  for (let i = 0; i < jm - 1; i++) days += j_days_in_month[i];
  days += jd - 1;
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gm = 0;
  for (; gm < 12; gm++) {
    const v = g_days_in_month[gm] + (gm === 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 1 : 0);
    if (days < v) break;
    days -= v;
  }
  return new Date(gy, gm, days + 1);
}

function parseTaskDue(item) {
  if (!item.shamsiDate || !item.time) return null;
  const parts = item.shamsiDate.split('/');
  if (parts.length < 3) return null;
  const [jy, jm, jd] = parts.map(Number);
  const g = shamsiToGregorian(jy, jm, jd);
  if (!g || isNaN(g.getTime())) return null;
  const [h, m] = item.time.split(':').map(n => parseInt(n) || 0);
  g.setHours(h, m, 0, 0);
  return g;
}

const alertedTasks = new Set(JSON.parse(sessionStorage.getItem('alertedTasks') || '[]'));

function triggerAlarm(item) {
  if (alertedTasks.has(item.id)) return;
  alertedTasks.add(item.id);
  sessionStorage.setItem('alertedTasks', JSON.stringify([...alertedTasks]));

  const title = 'هشدار کار';
  const body = item.text + (item.shamsiDate ? '\\n' + item.shamsiDate + ' ' + (item.time || '') : '');

  // تلاش برای نوتیفیکیشن سیستم
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, { body: body, requireInteraction: true });
    } catch (e) {}
  }

  // صدا (بیپ ساده با Web Audio)
  if (item.alarm === 'ring') {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playBeep = (freq, start, dur) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = freq;
        g.gain.value = 0.3;
        o.start(ctx.currentTime + start);
        o.stop(ctx.currentTime + start + dur);
      };
      playBeep(880, 0, 0.2);
      playBeep(880, 0.3, 0.2);
      playBeep(880, 0.6, 0.35);
    } catch (e) {}
  }

  alert('⏰ هشدار\\n\\n' + body);
}

function checkAlarms() {
  const now = new Date();
  (data.tasks || []).forEach(item => {
    if (item.done) return;
    if (item.alarm !== 'ring') return;
    const due = parseTaskDue(item);
    if (!due) return;
    // اگر زمان سررسید گذشته و کمتر از ۲ دقیقه از آن گذشته باشد
    const diff = now.getTime() - due.getTime();
    if (diff >= 0 && diff < 2 * 60 * 1000) {
      triggerAlarm(item);
    }
  });
}

// درخواست مجوز نوتیفیکیشن
if ('Notification' in window && Notification.permission === 'default') {
  try { Notification.requestPermission(); } catch (e) {}
}

// چک هر ۲۰ ثانیه وقتی برنامه باز است
setInterval(checkAlarms, 20000);
setTimeout(checkAlarms, 3000);


renderAll();
    }
  } else if (action === 'edit') {
    const item = (data[type] || []).find(i => i.id === id);
    if (!item) return;
    const neu = prompt('ویرایش متن:', item.text);
    if (neu !== null && neu.trim()) {
      item.text = neu.trim();
      save();
      
// ===== سیستم هشدار (وقتی برنامه باز است) =====
// تبدیل تقریبی تاریخ شمسی به میلادی برای مقایسه
function shamsiToGregorian(jy, jm, jd) {
  jy = parseInt(jy); jm = parseInt(jm); jd = parseInt(jd);
  if (!jy || !jm || !jd) return null;
  const g_days_in_month = [31,28,31,30,31,30,31,31,30,31,30,31];
  const j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];
  let jy2 = (jy > 979) ? jy - 979 : jy - 0;
  let gy = (jy > 979) ? 1600 : 621;
  let days = (365 * jy2) + Math.floor(jy2 / 33) * 8 + Math.floor(((jy2 % 33) + 3) / 4);
  for (let i = 0; i < jm - 1; i++) days += j_days_in_month[i];
  days += jd - 1;
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gm = 0;
  for (; gm < 12; gm++) {
    const v = g_days_in_month[gm] + (gm === 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 1 : 0);
    if (days < v) break;
    days -= v;
  }
  return new Date(gy, gm, days + 1);
}

function parseTaskDue(item) {
  if (!item.shamsiDate || !item.time) return null;
  const parts = item.shamsiDate.split('/');
  if (parts.length < 3) return null;
  const [jy, jm, jd] = parts.map(Number);
  const g = shamsiToGregorian(jy, jm, jd);
  if (!g || isNaN(g.getTime())) return null;
  const [h, m] = item.time.split(':').map(n => parseInt(n) || 0);
  g.setHours(h, m, 0, 0);
  return g;
}

const alertedTasks = new Set(JSON.parse(sessionStorage.getItem('alertedTasks') || '[]'));

function triggerAlarm(item) {
  if (alertedTasks.has(item.id)) return;
  alertedTasks.add(item.id);
  sessionStorage.setItem('alertedTasks', JSON.stringify([...alertedTasks]));

  const title = 'هشدار کار';
  const body = item.text + (item.shamsiDate ? '\\n' + item.shamsiDate + ' ' + (item.time || '') : '');

  // تلاش برای نوتیفیکیشن سیستم
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, { body: body, requireInteraction: true });
    } catch (e) {}
  }

  // صدا (بیپ ساده با Web Audio)
  if (item.alarm === 'ring') {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playBeep = (freq, start, dur) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = freq;
        g.gain.value = 0.3;
        o.start(ctx.currentTime + start);
        o.stop(ctx.currentTime + start + dur);
      };
      playBeep(880, 0, 0.2);
      playBeep(880, 0.3, 0.2);
      playBeep(880, 0.6, 0.35);
    } catch (e) {}
  }

  alert('⏰ هشدار\\n\\n' + body);
}

function checkAlarms() {
  const now = new Date();
  (data.tasks || []).forEach(item => {
    if (item.done) return;
    if (item.alarm !== 'ring') return;
    const due = parseTaskDue(item);
    if (!due) return;
    // اگر زمان سررسید گذشته و کمتر از ۲ دقیقه از آن گذشته باشد
    const diff = now.getTime() - due.getTime();
    if (diff >= 0 && diff < 2 * 60 * 1000) {
      triggerAlarm(item);
    }
  });
}

// درخواست مجوز نوتیفیکیشن
if ('Notification' in window && Notification.permission === 'default') {
  try { Notification.requestPermission(); } catch (e) {}
}

// چک هر ۲۰ ثانیه وقتی برنامه باز است
setInterval(checkAlarms, 20000);
setTimeout(checkAlarms, 3000);


renderAll();
    }
  }
});

// ===== بکاپ =====
function doImport(parsed) {
  if (!parsed || typeof parsed !== 'object') {
    alert('بکاپ معتبر نیست.');
    return false;
  }
  if (!confirm('داده‌های فعلی جایگزین می‌شوند. ادامه؟')) return false;
  data = {
    tasks: parsed.tasks || [],
    plans: parsed.plans || [],
    goals: parsed.goals || [],
    daily: parsed.daily || { urgentImportant: [], important: [], urgent: [], low: [] }
  };
  save();
  
// ===== سیستم هشدار (وقتی برنامه باز است) =====
// تبدیل تقریبی تاریخ شمسی به میلادی برای مقایسه
function shamsiToGregorian(jy, jm, jd) {
  jy = parseInt(jy); jm = parseInt(jm); jd = parseInt(jd);
  if (!jy || !jm || !jd) return null;
  const g_days_in_month = [31,28,31,30,31,30,31,31,30,31,30,31];
  const j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];
  let jy2 = (jy > 979) ? jy - 979 : jy - 0;
  let gy = (jy > 979) ? 1600 : 621;
  let days = (365 * jy2) + Math.floor(jy2 / 33) * 8 + Math.floor(((jy2 % 33) + 3) / 4);
  for (let i = 0; i < jm - 1; i++) days += j_days_in_month[i];
  days += jd - 1;
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gm = 0;
  for (; gm < 12; gm++) {
    const v = g_days_in_month[gm] + (gm === 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 1 : 0);
    if (days < v) break;
    days -= v;
  }
  return new Date(gy, gm, days + 1);
}

function parseTaskDue(item) {
  if (!item.shamsiDate || !item.time) return null;
  const parts = item.shamsiDate.split('/');
  if (parts.length < 3) return null;
  const [jy, jm, jd] = parts.map(Number);
  const g = shamsiToGregorian(jy, jm, jd);
  if (!g || isNaN(g.getTime())) return null;
  const [h, m] = item.time.split(':').map(n => parseInt(n) || 0);
  g.setHours(h, m, 0, 0);
  return g;
}

const alertedTasks = new Set(JSON.parse(sessionStorage.getItem('alertedTasks') || '[]'));

function triggerAlarm(item) {
  if (alertedTasks.has(item.id)) return;
  alertedTasks.add(item.id);
  sessionStorage.setItem('alertedTasks', JSON.stringify([...alertedTasks]));

  const title = 'هشدار کار';
  const body = item.text + (item.shamsiDate ? '\\n' + item.shamsiDate + ' ' + (item.time || '') : '');

  // تلاش برای نوتیفیکیشن سیستم
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, { body: body, requireInteraction: true });
    } catch (e) {}
  }

  // صدا (بیپ ساده با Web Audio)
  if (item.alarm === 'ring') {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playBeep = (freq, start, dur) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = freq;
        g.gain.value = 0.3;
        o.start(ctx.currentTime + start);
        o.stop(ctx.currentTime + start + dur);
      };
      playBeep(880, 0, 0.2);
      playBeep(880, 0.3, 0.2);
      playBeep(880, 0.6, 0.35);
    } catch (e) {}
  }

  alert('⏰ هشدار\\n\\n' + body);
}

function checkAlarms() {
  const now = new Date();
  (data.tasks || []).forEach(item => {
    if (item.done) return;
    if (item.alarm !== 'ring') return;
    const due = parseTaskDue(item);
    if (!due) return;
    // اگر زمان سررسید گذشته و کمتر از ۲ دقیقه از آن گذشته باشد
    const diff = now.getTime() - due.getTime();
    if (diff >= 0 && diff < 2 * 60 * 1000) {
      triggerAlarm(item);
    }
  });
}

// درخواست مجوز نوتیفیکیشن
if ('Notification' in window && Notification.permission === 'default') {
  try { Notification.requestPermission(); } catch (e) {}
}

// چک هر ۲۰ ثانیه وقتی برنامه باز است
setInterval(checkAlarms, 20000);
setTimeout(checkAlarms, 3000);


renderAll();
  alert('داده‌ها لود شدند.');
  return true;
}

document.getElementById('btnExport')?.addEventListener('click', () => {
  const backup = {
    app: 'برنامه‌ریز شخصی',
    version: 1,
    exportDate: new Date().toISOString(),
    ...data
  };
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'backup-planner-' + new Date().toISOString().slice(0, 10) + '.json';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  alert('بکاپ گرفته شد.');
});

document.getElementById('btnImport')?.addEventListener('click', () => {
  const panel = document.getElementById('importPanel');
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
});

document.getElementById('btnCloseImport')?.addEventListener('click', () => {
  document.getElementById('importPanel').style.display = 'none';
  document.getElementById('importText').value = '';
});

document.getElementById('btnChooseFile')?.addEventListener('click', () => {
  document.getElementById('importFile').click();
});

document.getElementById('importFile')?.addEventListener('change', e => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = ev => {
    try {
      if (doImport(JSON.parse(ev.target.result))) {
        document.getElementById('importPanel').style.display = 'none';
        document.getElementById('importText').value = '';
      }
    } catch {
      alert('فایل معتبر نیست.');
    }
    e.target.value = '';
  };
  reader.readAsText(file);
});

document.getElementById('btnLoadPaste')?.addEventListener('click', () => {
  const text = document.getElementById('importText').value.trim();
  if (!text) {
    alert('متن بکاپ را Paste کنید.');
    return;
  }
  try {
    if (doImport(JSON.parse(text))) {
      document.getElementById('importPanel').style.display = 'none';
      document.getElementById('importText').value = '';
    }
  } catch {
    alert('متن JSON معتبر نیست.');
  }
});


// ===== سیستم هشدار (وقتی برنامه باز است) =====
// تبدیل تقریبی تاریخ شمسی به میلادی برای مقایسه
function shamsiToGregorian(jy, jm, jd) {
  jy = parseInt(jy); jm = parseInt(jm); jd = parseInt(jd);
  if (!jy || !jm || !jd) return null;
  const g_days_in_month = [31,28,31,30,31,30,31,31,30,31,30,31];
  const j_days_in_month = [31,31,31,31,31,31,30,30,30,30,30,29];
  let jy2 = (jy > 979) ? jy - 979 : jy - 0;
  let gy = (jy > 979) ? 1600 : 621;
  let days = (365 * jy2) + Math.floor(jy2 / 33) * 8 + Math.floor(((jy2 % 33) + 3) / 4);
  for (let i = 0; i < jm - 1; i++) days += j_days_in_month[i];
  days += jd - 1;
  gy += 400 * Math.floor(days / 146097);
  days %= 146097;
  if (days > 36524) {
    gy += 100 * Math.floor(--days / 36524);
    days %= 36524;
    if (days >= 365) days++;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    gy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  let gm = 0;
  for (; gm < 12; gm++) {
    const v = g_days_in_month[gm] + (gm === 1 && ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0) ? 1 : 0);
    if (days < v) break;
    days -= v;
  }
  return new Date(gy, gm, days + 1);
}

function parseTaskDue(item) {
  if (!item.shamsiDate || !item.time) return null;
  const parts = item.shamsiDate.split('/');
  if (parts.length < 3) return null;
  const [jy, jm, jd] = parts.map(Number);
  const g = shamsiToGregorian(jy, jm, jd);
  if (!g || isNaN(g.getTime())) return null;
  const [h, m] = item.time.split(':').map(n => parseInt(n) || 0);
  g.setHours(h, m, 0, 0);
  return g;
}

const alertedTasks = new Set(JSON.parse(sessionStorage.getItem('alertedTasks') || '[]'));

function triggerAlarm(item) {
  if (alertedTasks.has(item.id)) return;
  alertedTasks.add(item.id);
  sessionStorage.setItem('alertedTasks', JSON.stringify([...alertedTasks]));

  const title = 'هشدار کار';
  const body = item.text + (item.shamsiDate ? '\\n' + item.shamsiDate + ' ' + (item.time || '') : '');

  // تلاش برای نوتیفیکیشن سیستم
  if ('Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(title, { body: body, requireInteraction: true });
    } catch (e) {}
  }

  // صدا (بیپ ساده با Web Audio)
  if (item.alarm === 'ring') {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const playBeep = (freq, start, dur) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g);
        g.connect(ctx.destination);
        o.frequency.value = freq;
        g.gain.value = 0.3;
        o.start(ctx.currentTime + start);
        o.stop(ctx.currentTime + start + dur);
      };
      playBeep(880, 0, 0.2);
      playBeep(880, 0.3, 0.2);
      playBeep(880, 0.6, 0.35);
    } catch (e) {}
  }

  alert('⏰ هشدار\\n\\n' + body);
}

function checkAlarms() {
  const now = new Date();
  (data.tasks || []).forEach(item => {
    if (item.done) return;
    if (item.alarm !== 'ring') return;
    const due = parseTaskDue(item);
    if (!due) return;
    // اگر زمان سررسید گذشته و کمتر از ۲ دقیقه از آن گذشته باشد
    const diff = now.getTime() - due.getTime();
    if (diff >= 0 && diff < 2 * 60 * 1000) {
      triggerAlarm(item);
    }
  });
}

// درخواست مجوز نوتیفیکیشن
if ('Notification' in window && Notification.permission === 'default') {
  try { Notification.requestPermission(); } catch (e) {}
}

// چک هر ۲۰ ثانیه وقتی برنامه باز است
setInterval(checkAlarms, 20000);
setTimeout(checkAlarms, 3000);


renderAll();
