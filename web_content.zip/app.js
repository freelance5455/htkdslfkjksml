(() => {
const cfg = window.FRIENDSHIP_CONFIG || {};
const $ = (id) => document.getElementById(id);
const client = window.supabase?.createClient(cfg.supabaseUrl, cfg.supabasePublishableKey);
let currentUser = null, profile = null, authMode = "login", activeConversation = null;
let messageChannel = null, presenceChannel = null, liveRoom = null, currentRoomName = null;
const esc = (s="") => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const toast = (msg) => { const el=$("toast"); el.textContent=msg; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),2600); };
const initials = (s="F") => (s.trim()[0] || "F").toUpperCase();
const showModal = (title, html) => { $("modal-title").textContent=title; $("modal-content").innerHTML=html; $("modal").classList.remove("hidden"); };
const closeModal = () => $("modal").classList.add("hidden");
function showAuth(){ $("auth-screen").classList.remove("hidden"); $("main-screen").classList.add("hidden"); }
function showMain(){ $("auth-screen").classList.add("hidden"); $("main-screen").classList.remove("hidden"); }
function setAuthMode(mode){ authMode=mode; document.querySelectorAll("[data-auth-tab]").forEach(b=>b.classList.toggle("active",b.dataset.authTab===mode)); $("name-wrap").classList.toggle("hidden",mode!=="signup"); $("auth-submit").textContent=mode==="login"?"Login":"Create account"; $("auth-message").textContent=""; }
function navigate(page){ document.querySelectorAll(".page").forEach(p=>p.classList.remove("active")); const target=$("page-"+page); if(!target){toast("This page is not available.");return;} target.classList.add("active"); document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page)); if(page==="chats") loadConversations(); if(page==="rooms") loadRooms(); if(page==="profile") loadProfile(); if(page==="moments") loadMoments(); if(page==="notifications") loadNotifications(); if(page==="wallet") loadWallet(); if(page==="ludo") loadLudo(); }
async function loadProfile(){
 if(!currentUser)return;
 const {data,error}=await client.from("profiles").select("*").eq("id",currentUser.id).maybeSingle();
 if(error) console.warn(error);
 profile=data || {id:currentUser.id,username:currentUser.email?.split("@")[0]||"friend",full_name:"Friend",bio:""};
 $("profile-name").textContent=profile.full_name||profile.username||"Friend";
 $("profile-handle").textContent="@"+(profile.username||"friend");
 $("profile-bio").textContent=profile.bio||"Add a little about yourself.";
 $("profile-avatar").textContent=initials(profile.full_name||profile.username||"F");
 $("header-avatar").textContent=initials(profile.full_name||profile.username||"F");
 const [{count:followers},{count:following}]=await Promise.all([
 client.from("follows").select("*",{count:"exact",head:true}).eq("following_id",currentUser.id),
 client.from("follows").select("*",{count:"exact",head:true}).eq("follower_id",currentUser.id)
 ]);
 $("follower-count").textContent=followers||0; $("following-count").textContent=following||0;
}
async function ensureProfile(){
 const {data}=await client.from("profiles").select("*").eq("id",currentUser.id).maybeSingle();
 if(!data){ const username=(currentUser.email?.split("@")[0]||"friend")+currentUser.id.slice(0,4); await client.from("profiles").upsert({id:currentUser.id,username,full_name:currentUser.user_metadata?.full_name||username}); }
 await loadProfile();
}
async function loadRooms(){
 const targets=[$("home-rooms"),$("all-rooms")];
 targets.forEach(t=>t.innerHTML='<div class="empty-state">Loading rooms…</div>');
 const {data,error}=await client.from("voice_rooms").select("id,room_name,description,is_private,max_seats,created_at,owner_id").eq("is_private",false).order("created_at",{ascending:false}).limit(20);
 const html=error?'<div class="empty-state">Rooms could not load. Check database permissions.</div>':(data?.length?data.map(r=>roomCard(r)).join(""):'<div class="empty-state">No public rooms yet. Create the first one!</div>');
 targets.forEach(t=>t.innerHTML=html);
}
function roomCard(r){return `<div class="room-card"><div class="room-icon">◉</div><div class="room-info"><b>${esc(r.room_name)}</b><small>${esc(r.description||"A Friendship voice room")} · up to ${r.max_seats||8} seats</small></div><span class="live-pill">ROOM</span><button class="join-btn" data-join-room="${esc(r.room_name)}">Join</button></div>`;}
async function loadFeed(){
 const el=$("feed-list"); const {data,error}=await client.from("posts").select("id,user_id,content,created_at").order("created_at",{ascending:false}).limit(20);
 if(error){el.innerHTML='<div class="empty-state">Moments are not available yet.</div>';return;}
 if(!data?.length){el.innerHTML='<div class="empty-state">No moments yet. Share the first one!</div>';return;}
 const ids=[...new Set(data.map(p=>p.user_id))]; const {data:users}=await client.from("profiles").select("id,full_name,username").in("id",ids);
 const map=Object.fromEntries((users||[]).map(u=>[u.id,u]));
 el.innerHTML=data.map(p=>`<article class="feed-card"><h3>${esc(map[p.user_id]?.full_name||map[p.user_id]?.username||"Friend")}</h3><p>${esc(p.content||"")}</p><div class="feed-meta"><span>${new Date(p.created_at).toLocaleString()}</span><span>♡ Moment</span></div></article>`).join("");
}
async function searchUsers(q){
 const el=$("search-results"); if(!q.trim()){el.innerHTML="";return;}
 const {data,error}=await client.from("profiles").select("id,username,full_name,bio").or(`username.ilike.%${q}%,full_name.ilike.%${q}%`).neq("id",currentUser.id).limit(20);
 if(error){el.innerHTML='<div class="empty-state">Search unavailable. Check profiles policy.</div>';return;}
 el.innerHTML=data?.length?data.map(u=>`<div class="user-row"><div class="user-pic">${initials(u.full_name||u.username)}</div><div class="user-info"><b>${esc(u.full_name||u.username)}</b><small>@${esc(u.username||"friend")}</small></div><button class="outline-btn" data-follow="${u.id}">Follow</button><button class="join-btn" data-message-user="${u.id}">Chat</button></div>`).join(""):'<div class="empty-state">No users found.</div>';
}
async function followUser(id){const {error}=await client.from("follows").insert({follower_id:currentUser.id,following_id:id});if(error)toast(error.code==="23505"?"Already following.":error.message);else toast("Following!");}
async function createDirectChat(id){
 const {data,error}=await client.rpc("create_direct_conversation",{target_user:id});
 if(error){toast("Could not start chat: "+error.message);return;}
 activeConversation=data; await openChat(data);
}
async function loadConversations(){
 const el=$("conversation-list"); const {data:members,error}=await client.from("conversation_members").select("conversation_id").eq("user_id",currentUser.id);
 if(error||!members?.length){el.innerHTML='<div class="empty-state">No conversations yet. Find someone and start chatting.</div>';return;}
 const ids=members.map(x=>x.conversation_id);
 const {data:convs}=await client.from("conversations").select("*").in("id",ids).order("created_at",{ascending:false});
 const rows=[];
 for(const c of convs||[]){
  const {data:other}=await client.from("conversation_members").select("user_id").eq("conversation_id",c.id).neq("user_id",currentUser.id).limit(1).maybeSingle();
  let p=null;if(other){const {data}=await client.from("profiles").select("full_name,username").eq("id",other.user_id).maybeSingle();p=data;}
  rows.push(`<div class="conversation-row" data-open-chat="${c.id}"><div class="user-pic">${initials(p?.full_name||p?.username||c.title||"C")}</div><div class="user-info"><b>${esc(p?.full_name||p?.username||c.title||"Conversation")}</b><small>Tap to open conversation</small></div><span>›</span></div>`);
 }
 el.innerHTML=rows.join("")||'<div class="empty-state">No conversations yet.</div>';
}
async function openChat(conversationId){
 activeConversation=conversationId;
 const {data:members}=await client.from("conversation_members").select("user_id").eq("conversation_id",conversationId).neq("user_id",currentUser.id).limit(1).maybeSingle();
 let p=null;if(members){const {data}=await client.from("profiles").select("full_name,username").eq("id",members.user_id).maybeSingle();p=data;}
 $("chat-title").textContent=p?.full_name||p?.username||"Conversation";
 $("chat-panel").classList.remove("hidden"); await loadMessages();
 if(messageChannel)client.removeChannel(messageChannel);
 messageChannel=client.channel("chat-"+conversationId).on("postgres_changes",{event:"INSERT",schema:"public",table:"messages",filter:`conversation_id=eq.${conversationId}`},payload=>appendMessage(payload.new)).subscribe();
 await client.rpc("mark_messages_seen",{target_conversation:conversationId});
}
function appendMessage(m){const el=$("message-list");if(el.querySelector(`[data-message-id="${m.id}"]`))return;const div=document.createElement("div");div.className="bubble"+(m.sender_id===currentUser.id?" mine":"");div.dataset.messageId=m.id;div.innerHTML=`${esc(m.content||"")}<small>${new Date(m.created_at).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}</small>`;el.appendChild(div);el.scrollTop=el.scrollHeight;}
async function loadMessages(){const {data,error}=await client.from("messages").select("*").eq("conversation_id",activeConversation).order("created_at",{ascending:true}).limit(100);const el=$("message-list");el.innerHTML="";if(error){el.innerHTML='<div class="empty-state">Could not load messages.</div>';return;} (data||[]).forEach(appendMessage);}
async function sendMessage(e){e.preventDefault();const content=$("message-input").value.trim();if(!content||!activeConversation)return;$("message-input").value="";const {error}=await client.from("messages").insert({conversation_id:activeConversation,sender_id:currentUser.id,content,message_type:"text"});if(error)toast("Message failed: "+error.message);}
async function createPost(content){const {error}=await client.from("posts").insert({user_id:currentUser.id,content});if(error)toast("Post failed: "+error.message);else{toast("Moment shared!");await loadFeed();}}
async function createRoom(name,description){const {error}=await client.from("voice_rooms").insert({owner_id:currentUser.id,room_name:name,description,is_private:false,max_seats:8});if(error)toast("Room failed: "+error.message);else{toast("Voice room created!");await loadRooms();}}
async function joinRoom(name){
 try{
  const {data,error}=await client.functions.invoke(cfg.livekitTokenFunction,{body:{roomName:name}});
  if(error||!data?.token)throw new Error(data?.error||error?.message||"Could not get voice token");
  const {Room,RoomEvent}=await import("https://esm.sh/livekit-client@2");
  liveRoom=new Room({adaptiveStream:true,dynacast:true}); currentRoomName=name;
  await liveRoom.connect(data.serverUrl,data.token);
  showModal("Voice room",`<div class="room-stage"><div class="room-orb">◉</div><h3>${esc(name)}</h3><p class="modal-note">Connected to the room. Allow microphone access when prompted.</p><button id="mic-toggle" class="outline-btn">Enable microphone</button><button id="leave-room" class="danger-btn">Leave room</button></div>`);
  $("mic-toggle").onclick=async()=>{try{await liveRoom.localParticipant.setMicrophoneEnabled(true);$("mic-toggle").textContent="Microphone enabled";}catch(e){toast("Microphone: "+e.message);}};
  $("leave-room").onclick=async()=>{await liveRoom.disconnect();liveRoom=null;closeModal();toast("Left room");};
  liveRoom.on(RoomEvent.Disconnected,()=>{liveRoom=null;});
 }catch(e){toast("Voice room: "+e.message);}
}
async function saveProfile(name,bio){const username=(profile?.username||currentUser.email.split("@")[0]).toLowerCase();const {error}=await client.from("profiles").upsert({id:currentUser.id,username,full_name:name,bio});if(error)toast(error.message);else{toast("Profile updated");closeModal();await loadProfile();}}
async function startApp(user){currentUser=user;showMain();await ensureProfile();await Promise.all([loadRooms(),loadFeed()]);}

async function loadMoments(){const el=$("moments-feed");if(!el)return;const {data,error}=await client.from("posts").select("id,user_id,content,created_at").order("created_at",{ascending:false}).limit(30);if(error){el.innerHTML='<div class="empty-state">Moments unavailable. Check database permissions.</div>';return;}if(!data?.length){el.innerHTML='<div class="empty-state">No moments yet. Share the first one!</div>';return;}const ids=[...new Set(data.map(x=>x.user_id))];const {data:users}=await client.from("profiles").select("id,full_name,username").in("id",ids);const map=Object.fromEntries((users||[]).map(x=>[x.id,x]));el.innerHTML=data.map(x=>`<article class="feed-card"><h3>${esc(map[x.user_id]?.full_name||map[x.user_id]?.username||"Friend")}</h3><p>${esc(x.content||"")}</p><div class="feed-meta"><span>${new Date(x.created_at).toLocaleString()}</span><span>Moment</span></div></article>`).join("");}
async function loadNotifications(){const el=$("notifications-list");const {data,error}=await client.from("notifications").select("*").eq("recipient_id",currentUser.id).order("created_at",{ascending:false}).limit(50);if(error){el.innerHTML='<div class="empty-state">Notifications unavailable. Check RLS.</div>';return;}el.innerHTML=data?.length?data.map(n=>`<article class="feed-card"><h3>${esc(n.title||n.type||"Update")}</h3><p>${esc(n.body||"")}</p><div class="feed-meta"><span>${new Date(n.created_at).toLocaleString()}</span><span>${n.is_read?"Read":"Unread"}</span></div></article>`).join(""):'<div class="empty-state">You are all caught up.</div>';}
async function loadWallet(){const {data,error}=await client.from("wallets").select("*").eq("user_id",currentUser.id).maybeSingle();$("wallet-balance").textContent=error?"Unavailable":data?(data.balance??data.coins??0):"0";const el=$("gift-list");const g=await client.from("gifts").select("*").eq("is_active",true).limit(30);if(g.error){el.innerHTML='<div class="empty-state">Gift catalogue unavailable.</div>';return;}el.innerHTML=g.data?.length?g.data.map(x=>`<div class="room-card"><div class="room-icon">🎁</div><div class="room-info"><b>${esc(x.name||"Gift")}</b><small>${esc(String(x.coin_cost??x.price??"—"))} coins</small></div><button class="join-btn" disabled>Send</button></div>`).join(""):'<div class="empty-state">No active gifts configured.</div>';}
async function loadLudo(){const el=$("ludo-list");const {data,error}=await client.from("ludo_games").select("*").order("created_at",{ascending:false}).limit(25);if(error){el.innerHTML='<div class="empty-state">Ludo lobbies unavailable.</div>';return;}el.innerHTML=data?.length?data.map(g=>`<div class="room-card"><div class="room-icon">🎲</div><div class="room-info"><b>${esc(g.name||g.id||"Ludo lobby")}</b><small>${esc(g.status||"Waiting for players")}</small></div><button class="join-btn" disabled>Join pending</button></div>`).join(""):'<div class="empty-state">No Ludo lobbies yet.</div>';}
async function startVideoCall(video){if(!activeConversation){toast("Open a chat first.");return;}const roomName="call-"+activeConversation;try{const {data,error}=await client.functions.invoke("quick-task",{body:{roomName}});if(error||!data?.token)throw new Error(data?.error||error?.message||"Token request failed");const {Room,RoomEvent}=await import("https://esm.sh/livekit-client@2");const room=new Room({adaptiveStream:true,dynacast:true});await room.connect(data.serverUrl,data.token);showModal(video?"Video call":"Audio call",`<div class="room-stage"><div class="room-orb">${video?"▣":"☎"}</div><h3>${esc(roomName)}</h3><p class="modal-note">Connected. Enable your microphone${video?" and camera":""}.</p><video id="call-local-video" autoplay muted playsinline style="width:100%;border-radius:12px;background:#09070f;${video?"":"display:none"}"></video><button id="call-mic" class="outline-btn">Enable microphone</button><button id="call-camera" class="outline-btn" style="${video?"":"display:none"}">Enable camera</button><button id="call-leave" class="danger-btn">Leave call</button></div>`);$("call-mic").onclick=async()=>{try{await room.localParticipant.setMicrophoneEnabled(true);toast("Microphone enabled");}catch(e){toast(e.message);}};if(video)$("call-camera").onclick=async()=>{try{await room.localParticipant.setCameraEnabled(true);const pub=[...room.localParticipant.videoTrackPublications.values()][0];if(pub?.track)pub.track.attach($("call-local-video"));toast("Camera enabled");}catch(e){toast(e.message);}};$("call-leave").onclick=async()=>{await room.disconnect();closeModal();};room.on(RoomEvent.Disconnected,closeModal);}catch(e){toast("Call error: "+e.message);}}

function bind(){
 document.querySelectorAll("[data-auth-tab]").forEach(b=>b.onclick=()=>setAuthMode(b.dataset.authTab));
 $("auth-form").onsubmit=async e=>{e.preventDefault();$("auth-message").textContent="Please wait…";const email=$("auth-email").value.trim(),password=$("auth-password").value;let result;if(authMode==="login")result=await client.auth.signInWithPassword({email,password});else result=await client.auth.signUp({email,password,options:{data:{full_name:$("auth-name").value.trim()}}});if(result.error){$("auth-message").textContent=result.error.message;return;}if(authMode==="signup"&&!result.data.session){$("auth-message").textContent="Account created. Check your email to confirm, then log in.";return;}$("auth-message").textContent="";await startApp(result.data.user);};
 document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>navigate(b.dataset.page));
 document.querySelectorAll("[data-go]").forEach(b=>b.onclick=()=>navigate(b.dataset.go));
 $("search-open").onclick=()=>navigate("search");
 $("user-search").oninput=e=>searchUsers(e.target.value);
 $("logout-btn").onclick=async()=>{await client.auth.signOut();currentUser=null;showAuth();};
 $("edit-profile").onclick=()=>showModal("Edit profile",`<label>Display name</label><input id="edit-name" value="${esc(profile?.full_name||"")}"><label>Bio</label><textarea id="edit-bio">${esc(profile?.bio||"")}</textarea><button id="save-profile" class="primary-btn full">Save profile</button>`);
 $("modal-close").onclick=closeModal;
 $("modal").onclick=e=>{if(e.target===$("modal"))closeModal();};
 $("create-post-open").onclick=()=>showModal("Share a moment",`<label>What's happening?</label><textarea id="post-content" placeholder="Share something with your friends…"></textarea><button id="publish-post" class="primary-btn full">Share moment</button>`);
 $("create-room").onclick=()=>showModal("Create voice room",`<label>Room name</label><input id="room-name" placeholder="Late night talks"><label>Description</label><textarea id="room-description" placeholder="What will you talk about?"></textarea><button id="publish-room" class="primary-btn full">Create room</button>`);
 $("chat-back").onclick=()=>{$("chat-panel").classList.add("hidden");activeConversation=null;if(messageChannel)client.removeChannel(messageChannel);loadConversations();};
 $("message-form").onsubmit=sendMessage;
 $("audio-call").onclick=()=>startVideoCall(false); $("video-call").onclick=()=>startVideoCall(true); $("moment-create").onclick=()=>showModal("Share a moment",`<label>What's happening?</label><textarea id="moment-text" placeholder="Share something…"></textarea><button id="moment-publish" class="primary-btn full">Share</button>`); $("ludo-create").onclick=()=>toast("Ludo match logic needs a trusted game backend before lobby creation can be enabled.");
 document.body.addEventListener("click",e=>{
  const follow=e.target.closest("[data-follow]");if(follow)followUser(follow.dataset.follow);
  const msg=e.target.closest("[data-message-user]");if(msg)createDirectChat(msg.dataset.messageUser);
  const join=e.target.closest("[data-join-room]");if(join)joinRoom(join.dataset.joinRoom);
  const chat=e.target.closest("[data-open-chat]");if(chat)openChat(chat.dataset.openChat);
  if(e.target.id==="save-profile")saveProfile($("edit-name").value.trim(),$("edit-bio").value.trim());
  if(e.target.id==="publish-post"){const c=$("post-content").value.trim();if(c)createPost(c).then(closeModal);else toast("Write something first");}
  if(e.target.id==="publish-room"){const n=$("room-name").value.trim();if(n)createRoom(n,$("room-description").value.trim()).then(closeModal);else toast("Enter a room name");}
  if(e.target.id==="moment-publish"){const content=$("moment-text").value.trim();if(content)client.from("posts").insert({user_id:currentUser.id,content}).then(({error})=>{if(error)toast(error.message);else{closeModal();toast("Moment shared");loadMoments();loadFeed();}});}
 });
}
async function init(){
 if(!client){$("auth-message").textContent="Supabase configuration missing.";return;}
 bind();
 const {data:{session}}=await client.auth.getSession();
 if(session?.user)await startApp(session.user);else showAuth();
 client.auth.onAuthStateChange(async(_event,session)=>{if(session?.user&&!currentUser)await startApp(session.user);});
}
init();
})();