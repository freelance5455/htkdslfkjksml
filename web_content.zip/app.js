/*
 * OTP Việt TalkBack - ZIP-to-APK friendly web shell.
 * This build deliberately does NOT call OTPVN directly from a public WebView.
 * The documented original project expected a server endpoint /api/otpvn.
 * Without a trusted backend/proxy, real API calls are disabled to avoid exposing
 * the token and to avoid guessing undocumented request schemas.
 */
(() => {
  const $ = (id) => document.getElementById(id);
  let apiToken = "";
  let services = [];
  let activeRental = null;
  let historyItems = [];

  function announce(message, kind = "info") {
    const el = $("notice");
    el.textContent = message;
    el.dataset.kind = kind;
    if ("vibrate" in navigator && kind !== "info") {
      try { navigator.vibrate(kind === "success" ? [40] : [90, 50, 90]); } catch (_) {}
    }
  }

  function needBackend(action) {
    announce(`Chức năng "${action}" chưa thể gọi API trong bản đóng gói này. Cần cấu hình máy chủ API an toàn trước khi sử dụng.`, "error");
  }

  function splitCsv(s) {
    return s.split(",").map(x => x.trim()).filter(Boolean);
  }

  function renderServices() {
    const q = $("service-search").value.trim().toLowerCase();
    const target = $("service-list");
    target.replaceChildren();
    const shown = services.filter(s => `${s.id} ${s.name}`.toLowerCase().includes(q));
    if (!shown.length) {
      const p = document.createElement("p");
      p.textContent = services.length ? "Không có dịch vụ khớp từ khóa." : "Danh sách dịch vụ chưa được tải.";
      target.appendChild(p);
      return;
    }
    shown.forEach(s => {
      const item = document.createElement("div");
      item.className = "list-item";
      item.setAttribute("role", "listitem");
      const text = document.createElement("p");
      text.textContent = `${s.id} — ${s.name}${s.price ? ` — ${s.price} VNĐ` : ""}`;
      const b = document.createElement("button");
      b.textContent = "Chọn dịch vụ này";
      b.setAttribute("aria-label", `Chọn dịch vụ ${s.name}, ID ${s.id}`);
      b.addEventListener("click", () => {
        $("service-id").value = s.id;
        announce(`Đã chọn dịch vụ ${s.name}.`);
        $("service-id").focus();
      });
      item.append(text, b);
      target.appendChild(item);
    });
  }

  $("connect").addEventListener("click", () => {
    apiToken = $("api-token").value.trim();
    if (!apiToken) {
      announce("Hãy nhập token của chính bạn. Bản này không lưu token.", "error");
      $("api-token").focus();
      return;
    }
    needBackend("kiểm tra kết nối");
  });

  $("refresh").addEventListener("click", () => needBackend("làm mới số dư và dịch vụ"));
  $("rent").addEventListener("click", () => {
    const id = $("service-id").value.trim();
    if (!/^\d+$/.test(id) || Number(id) <= 0) {
      announce("Hãy nhập ID dịch vụ hợp lệ.", "error");
      $("service-id").focus();
      return;
    }
    // Read values so the UI is ready for a future trusted backend.
    const filters = {
      carriers: splitCsv($("carrier").value),
      includePrefixes: splitCsv($("prefix-include").value),
      excludePrefixes: splitCsv($("prefix-exclude").value)
    };
    void filters;
    needBackend("thuê số");
  });
  $("service-search").addEventListener("input", renderServices);
  $("check-otp").addEventListener("click", () => needBackend("kiểm tra OTP"));
  $("rerent").addEventListener("click", () => needBackend("thuê lại số"));
  $("load-history").addEventListener("click", () => needBackend("tải lịch sử"));

  function copy(value, label) {
    if (!value) {
      announce(`Chưa có ${label} để sao chép.`, "error");
      return;
    }
    if (!navigator.clipboard || !navigator.clipboard.writeText) {
      announce("Trình duyệt đóng gói không hỗ trợ sao chép tự động. Hãy chọn và sao chép thủ công.", "error");
      return;
    }
    navigator.clipboard.writeText(value).then(
      () => announce(`Đã sao chép ${label}.`, "success"),
      () => announce(`Không thể sao chép ${label}.`, "error")
    );
  }
  $("copy-phone").addEventListener("click", () => copy(activeRental?.phoneLocal || "", "số điện thoại"));
  $("copy-otp").addEventListener("click", () => copy(activeRental?.code || "", "mã OTP"));

  $("history-filter").addEventListener("input", () => {
    const q = $("history-filter").value.toLowerCase();
    $("history").textContent = historyItems.filter(x => x.toLowerCase().includes(q)).join("\n\n") || "Không có mục lịch sử khớp.";
  });

  $("logout").addEventListener("click", () => {
    apiToken = "";
    $("api-token").value = "";
    announce("Đã xóa token khỏi bộ nhớ của trang. Không có token nào được lưu tự động.");
  });

  // Seed sample service data solely to demonstrate accessible selection/search.
  // Replace with server-provided data after a trusted backend is configured.
  services = [
    { id: 1, name: "Dịch vụ mẫu – chưa kết nối API", price: 0 }
  ];
  renderServices();
  announce("Bản giao diện đóng gói thử nghiệm đã sẵn sàng. Chức năng thuê số thật đang tắt cho đến khi cấu hình API an toàn.");
})();
