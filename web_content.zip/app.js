const $ = (s, r=document) => r.querySelector(s);
const $$ = (s, r=document) => [...r.querySelectorAll(s)];
let workspace = localStorage.getItem('zein-workspace') || 'شخصي';
let currentPage = 'home';
const platforms = [
  {id:'whatsapp',name:'WhatsApp Business',symbol:'W',desc:'رسائل الأعمال عبر واجهة Meta الرسمية',color:'#1c6c52'},
  {id:'telegram',name:'Telegram',symbol:'➤',desc:'بوتات وتكاملات Telegram المتاحة',color:'#245a83'},
  {id:'instagram',name:'Instagram',symbol:'◎',desc:'رسائل الحسابات المؤهلة عبر Meta',color:'#70406f'},
  {id:'messenger',name:'Messenger',symbol:'ϟ',desc:'رسائل صفحات Facebook المؤهلة',color:'#3e4e92'},
  {id:'gmail',name:'Gmail',symbol:'M',desc:'ربط البريد عبر OAuth والصلاحيات الرسمية',color:'#8c4545'},
  {id:'discord',name:'Discord',symbol:'◉',desc:'بوتات وخوادم وتكاملات مسموحة',color:'#4858a2'},
  {id:'x',name:'X',symbol:'𝕏',desc:'بحسب صلاحيات API والخطة المتاحة',color:'#303846'},
  {id:'manual',name:'إضافة يدوية',symbol:'＋',desc:'تسجيل قناة أو حساب للمتابعة اليدوية',color:'#48566d'}
];
let connections = JSON.parse(localStorage.getItem('zein-connections') || '[]');
let contacts = JSON.parse(localStorage.getItem('zein-contacts') || '[{"name":"سارة أحمد","detail":"عميل مميز","initial":"س"},{"name":"محمود علي","detail":"صديق","initial":"م"},{"name":"فريق المبيعات","detail":"مجموعة عمل","initial":"ف"}]');
const messages = [
 {name:'سارة أحمد',text:'هل يمكن إرسال تفاصيل العرض؟',time:'10:42',initial:'س',platform:'WhatsApp'},
 {name:'فريق العمل',text:'تم تحديث ملف المشروع',time:'09:18',initial:'ف',platform:'Telegram'},
 {name:'محمود علي',text:'صباح الخير، كيف الحال؟',time:'أمس',initial:'م',platform:'Instagram'},
 {name:'عميل جديد',text:'أرغب في معرفة الأسعار',time:'أمس',initial:'ع',platform:'Messenger'}
];
const pageNames={home:'الرئيسية',inbox:'صندوق الوارد',contacts:'جهات الاتصال',connections:'ربط المنصات',assistant:'مساعد ZEIN AI',files:'الملفات',activity:'النشاط'};
function toast(t){const el=$('#toast');el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2500)}
function save(){localStorage.setItem('zein-connections',JSON.stringify(connections));localStorage.setItem('zein-contacts',JSON.stringify(contacts));}
function go(page){currentPage=page;$('#pageTitle').textContent=pageNames[page];$$('[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));render()}
function header(title,sub,action=''){return `<div class="page-heading"><div><h1>${title}</h1><p>${sub}</p></div>${action}</div>`}
function render(){
 const root=$('#pageContent');
 if(currentPage==='home') root.innerHTML=home();
 if(currentPage==='connections') root.innerHTML=connectionsPage();
 if(currentPage==='inbox') root.innerHTML=inboxPage();
 if(currentPage==='assistant') root.innerHTML=assistantPage();
 if(currentPage==='contacts') root.innerHTML=contactsPage();
 if(currentPage==='files') root.innerHTML=filesPage();
 if(currentPage==='activity') root.innerHTML=activityPage();
}
function home(){return `<div class="notice guest-banner">أنت تستخدم ZEIN كضيف. لا يلزم تسجيل الدخول لتشغيل الأقسام المحلية، ويمكنك طلب ربط حسابك من قائمة الحساب وقت الحاجة.</div><div class="welcome"><div><div class="eyebrow">مساحتك الرقمية، بشكل أذكى</div><h1>أهلاً بك في ZEIN 👋</h1><p>كل تواصلك الشخصي والمهني يبدأ من هنا.</p></div><div class="date-chip">✦ مساحة ${workspace} · دخول كضيف</div></div>
<div class="hero"><div class="hero-content"><div class="eyebrow">ZEIN UNIFIED EXPERIENCE</div><h2>كل محادثاتك. مساحة واحدة.</h2><p>نظّم قنوات تواصلك الشخصية وأعمالك، تابع الرسائل، واستعد لتجربة مساعد ذكي يجمع مهامك اليومية في مكان واحد.</p><button class="btn-primary" data-go="connections">ابدأ ربط حساباتك ←</button></div></div>
<div class="stats"><div class="stat"><div class="stat-top">الحسابات المضافة <span class="stat-icon">⌘</span></div><strong>${connections.length}</strong><small>قنوات محفوظة في هذا الجهاز</small></div><div class="stat"><div class="stat-top">جهات الاتصال <span class="stat-icon">♧</span></div><strong>${contacts.length}</strong><small>جهات اتصال تجريبية ومحلية</small></div><div class="stat"><div class="stat-top">رسائل للمتابعة <span class="stat-icon">▤</span></div><strong>4</strong><small>بيانات عرض توضيحية</small></div><div class="stat"><div class="stat-top">حالة الحماية <span class="stat-icon">⬡</span></div><strong style="font-size:17px;color:var(--green)">محلي</strong><small>لا يوجد اتصال بخادم بعد</small></div></div>
<div class="grid-two"><div><div class="section-head"><h3>منصاتك</h3><button class="text-link" data-go="connections">إدارة المنصات ←</button></div><div class="panel"><div class="platform-list">${platforms.slice(0,4).map(p=>`<div class="platform"><div class="platform-logo" style="background:${p.color}">${p.symbol}</div><b>${p.name.split(' ')[0]}</b><small>${connections.includes(p.id)?'<span class="connected">مضاف</span>':'غير مربوط'}</small></div>`).join('')}</div></div></div>
<div><div class="section-head"><h3>آخر المحادثات</h3><button class="text-link" data-go="inbox">عرض الكل ←</button></div><div class="panel">${messages.slice(0,3).map(m=>`<div class="message-row"><div class="person-pic">${m.initial}</div><div class="message-info"><b>${m.name}</b><small>${m.text}</small></div><span class="message-time">${m.time}</span></div>`).join('')}</div></div></div>`}
function connectionsPage(){return `${header('ربط المنصات','أضف قنوات التواصل التي تريد إدارتها من ZEIN.')}<div class="notice">تنبيه مهم: هذه النسخة تحفظ اختيار القنوات محلياً فقط. الربط الحقيقي يتطلب OAuth ومفاتيح وخدمات رسمية لكل منصة، ولن نطلب كلمة مرور حسابك الاجتماعي داخل ZEIN.</div><div class="connection-grid" style="margin-top:15px">${platforms.map(p=>`<div class="connection-card"><div class="connection-card-head"><div class="platform-logo" style="background:${p.color}">${p.symbol}</div><div><h3>${p.name}</h3><span class="status">${connections.includes(p.id)?'● تمت الإضافة محلياً':'○ غير مربوط'}</span></div></div><p>${p.desc}</p><div class="connection-card-foot"><span class="status">${p.id==='manual'?'متاح يدوياً':'تكامل رسمي مطلوب'}</span><button class="${connections.includes(p.id)?'btn-secondary':'btn-primary'}" data-connect="${p.id}">${connections.includes(p.id)?'إزالة':'إضافة'}</button></div></div>`).join('')}</div>`}
function inboxPage(){return `${header('صندوق الوارد','واجهة موحدة لمراجعة محادثاتك. الرسائل المعروضة حالياً بيانات تجريبية.','<button class="btn-secondary" id="refreshInbox">↻ تحديث</button>')}<div class="chat-layout"><div class="chat-list"><h3>المحادثات <span style="color:var(--muted);font-size:10px">· 4</span></h3>${messages.map((m,i)=>`<div class="chat-card ${i===0?'active':''}" data-chat="${i}"><div class="person-pic">${m.initial}</div><div class="message-info"><b>${m.name}</b><small>${m.text}</small></div></div>`).join('')}</div><div class="chat-window"><div class="chat-empty"><div class="ai-orb" style="margin:auto">▤</div><strong>صندوق موحد قيد التجهيز</strong><span>عند تفعيل موصلات المنصات الرسمية ستظهر الرسائل هنا.</span><div class="notice">هذه المحادثات أمثلة للعرض فقط وليست رسائل حقيقية أو متصلة بحساباتك.</div></div><div class="chat-composer"><input placeholder="الردود ستتاح بعد ربط قناة مدعومة..." disabled><button class="btn-primary" disabled>إرسال</button></div></div></div>`}
function assistantPage(){return `${header('مساعد ZEIN AI','مساعدك لتنظيم الرسائل والأفكار والعمل اليومي.')}<div class="ai-card"><div class="ai-orb">✧</div><h2>مرحباً، أنا مساعد ZEIN</h2><p>أستطيع في النسخة القادمة تلخيص المحادثات المتصلة، صياغة الردود، الترجمة، واستخراج المهام. لم يتم توصيل نموذج ذكاء اصطناعي بعد، لذلك لن أدّعي إرسال طلبات إلى AI الآن.</p><div class="suggestions"><button data-prompt="لخص لي رسائل اليوم">لخص رسائل اليوم</button><button data-prompt="اكتب رداً احترافياً لعميل">صياغة رد لعميل</button><button data-prompt="ترجم رسالة إلى الإنجليزية">ترجمة رسالة</button><button data-prompt="استخرج المهام من محادثة">استخراج المهام</button></div><div class="ai-input"><input id="aiInput" class="search-input" placeholder="اكتب ما تريد مساعدتي فيه..."><button class="btn-primary" id="aiSend">إرسال</button></div><div id="aiResponse"></div><div class="notice">سيحتاج تفعيل الذكاء الاصطناعي إلى مزود API وخادم وسيط لحماية مفتاح API. لا تضع المفاتيح السرية في تطبيق Android.</div></div>`}
function contactsPage(){return `${header('جهات الاتصال','دليل موحد للأشخاص والعملاء والمجموعات.','<button class="btn-primary" id="addContact">＋ إضافة جهة</button>')}<div class="panel">${contacts.map(c=>`<div class="message-row"><div class="person-pic">${c.initial}</div><div class="message-info"><b>${c.name}</b><small>${c.detail}</small></div><span class="tag">محلي</span></div>`).join('')}</div>`}
function filesPage(){return `${header('الملفات','مساحة لتجهيز ملفاتك ومرفقات محادثاتك.')}<div class="panel"><div class="chat-empty"><div class="ai-orb" style="margin:auto">▧</div><strong>مركز الملفات</strong><p>سيتم إضافة رفع الملفات ومزامنتها سحابياً بعد تجهيز التخزين الآمن.</p><button class="btn-secondary" id="chooseFile">اختيار ملف تجريبي</button><input id="fileInput" type="file" hidden></div></div>`}
function activityPage(){return `${header('النشاط','سجل تغييرات وإجراءات مساحة ZEIN.')}<div class="panel"><div class="message-row"><div class="person-pic">Z</div><div class="message-info"><b>تم تشغيل ZEIN</b><small>بدأت جلسة محلية على هذا الجهاز.</small></div><span class="message-time">الآن</span></div><div class="message-row"><div class="person-pic">⬡</div><div class="message-info"><b>حماية البيانات</b><small>لا توجد مفاتيح وصول أو حسابات خارجية مخزنة.</small></div><span class="tag">آمن</span></div></div>`}
document.addEventListener('click',e=>{
 const nav=e.target.closest('[data-page]');if(nav){go(nav.dataset.page);return}
 const goBtn=e.target.closest('[data-go]');if(goBtn){go(goBtn.dataset.go);return}
 const conn=e.target.closest('[data-connect]');if(conn){const id=conn.dataset.connect;const platform=platforms.find(p=>p.id===id);if(connections.includes(id)){connections=connections.filter(x=>x!==id);save();render();toast('تمت الإزالة من القائمة المحلية');return}if(id==='manual'){connections=[...connections,id];save();render();toast('تمت إضافة قناة يدوية محلياً');return}openConnectionGate(platform);return}
 const prompt=e.target.closest('[data-prompt]');if(prompt){$('#aiInput').value=prompt.dataset.prompt;$('#aiInput').focus();return}
 if(e.target.id==='switchWorkspace')openWorkspace();
 if(e.target.id==='addContact')openContact();
 if(e.target.id==='aiSend')sendAI();
 if(e.target.id==='chooseFile')$('#fileInput').click();
 if(e.target.id==='refreshInbox')toast('تم تحديث العرض التجريبي');
 if(e.target.id==='searchBtn')openSearch();
 if(e.target.closest('#profileBtn'))openAccount();
});
function openAccount(){modal(`<h3>حساب ZEIN</h3><div class="notice">الحالة الحالية: دخول كضيف. يمكنك استخدام الوظائف المحلية دون تسجيل دخول، ولن تظهر شاشة تسجيل تلقائياً عند فتح التطبيق.</div><p>تسجيل الدخول إلى ZEIN اختياري، لكنه غير مفعّل في هذه النسخة لأن خادم المصادقة لم يتم ربطه واختباره بعد.</p><div class="modal-actions"><button class="btn-primary" id="requestAuthSetup">إعداد تسجيل الدخول</button><button class="btn-secondary" data-close>متابعة كضيف</button></div>`)}
function openConnectionGate(platform){modal(`<h3>ربط ${platform.name}</h3><p>${platform.desc}</p><div class="notice">سيتم طلب موافقة وتسجيل الدخول لدى المنصة نفسها عند تجهيز التكامل الرسمي. لا تدخل كلمة مرور حسابك هنا. الربط الحقيقي غير مفعّل في هذه النسخة؛ لم يتم حفظ الحساب على أنه متصل.</div><div class="modal-actions"><button class="btn-secondary" data-close>حسناً</button></div>`)}
function openWorkspace(){modal(`<h3>اختر مساحة ZEIN</h3><p>افصل سياقك الشخصي عن أعمالك مع إمكانية الانتقال بينهما.</p><div class="modal-actions"><button class="btn-primary" data-workspace="شخصي">شخصي</button><button class="btn-primary" data-workspace="أعمال">أعمال</button><button class="btn-secondary" data-close>إلغاء</button></div>`)}
function openContact(){modal(`<h3>إضافة جهة اتصال</h3><p>أضف جهة اتصال محلية إلى دليل ZEIN.</p><input class="search-input" id="newName" placeholder="الاسم"><input class="search-input" id="newDetail" placeholder="وصف مختصر" style="margin-top:9px"><div class="modal-actions"><button class="btn-primary" id="saveContact">حفظ</button><button class="btn-secondary" data-close>إلغاء</button></div>`)}
function openSearch(){modal(`<h3>بحث ZEIN</h3><p>ابحث في البيانات المحلية المتاحة حالياً.</p><input class="search-input" id="globalSearch" placeholder="اسم جهة أو منصة..."><div class="modal-actions"><button class="btn-primary" id="doSearch">بحث</button><button class="btn-secondary" data-close>إغلاق</button></div><div id="searchResults"></div>`)}
function modal(html){$('#modal').innerHTML=html;$('#modalBackdrop').classList.add('open')}
function closeModal(){$('#modalBackdrop').classList.remove('open')}
$('#modalBackdrop').addEventListener('click',e=>{if(e.target.id==='modalBackdrop'||e.target.closest('[data-close]'))closeModal();const w=e.target.closest('[data-workspace]');if(w){workspace=w.dataset.workspace;localStorage.setItem('zein-workspace',workspace);$('#workspaceLabel').textContent=workspace;closeModal();render()}});
$('#modal').addEventListener('click',e=>{if(e.target.id==='requestAuthSetup'){toast('تسجيل الدخول الاختياري يحتاج ربط خدمة المصادقة أولاً');closeModal()}if(e.target.id==='saveContact'){const name=$('#newName').value.trim();if(!name)return toast('اكتب الاسم أولاً');contacts.push({name,detail:$('#newDetail').value.trim()||'جهة جديدة',initial:name[0]});save();closeModal();render();toast('تمت إضافة جهة الاتصال')}if(e.target.id==='doSearch'){const q=$('#globalSearch').value.toLowerCase();const found=[...contacts.map(x=>x.name),...platforms.map(x=>x.name)].filter(x=>x.toLowerCase().includes(q));$('#searchResults').innerHTML=`<p>${found.length?found.join(' · '):'لا توجد نتائج محلية'}</p>`}});
function sendAI(){const input=$('#aiInput');if(!input||!input.value.trim())return;$('#aiResponse').innerHTML='<div class="notice">تم استلام طلبك في الواجهة التجريبية. اربط مزود AI بخادم ZEIN لتفعيل الإجابة الذكية الفعلية.</div>';input.value=''}
$('#workspaceLabel').textContent=workspace;render();
