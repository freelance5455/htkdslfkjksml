/* VOID FIGHTERS // ARENA PRO MAX
   Client-side vertical slice: roster, progression, RNG variants, modes,
   combat loop, difficulty, local persistence, customization and UI database. */
const IMG=["5344.jpg","5345.jpg","5346.jpg","5349.jpg","5350.jpg","5351.jpg","5353.jpg","5354.jpg","5355.jpg","5356.jpg"];
const NAMES=["VEXA","BRUTUS","NYRA","ROOK","ZANE","MIRA","DRAX","LUX","NYX","ELIRA"];
const ROLES=["VELOCISTA","TANQUE","ASESINA","CONTROL","TÉCNICA","RUSHDOWN","DEFENSORA","ZONERA","DUELISTA","EQUILIBRADA"];
const BASE_STATS=[
 {Vida:68,Daño:70,Velocidad:98,Agilidad:96,Defensa:60,Poder:82,Técnica:87,Alcance:76,Energía:90},
 {Vida:98,Daño:94,Velocidad:48,Agilidad:42,Defensa:96,Poder:88,Técnica:65,Alcance:55,Energía:72},
 {Vida:62,Daño:96,Velocidad:95,Agilidad:100,Defensa:42,Poder:90,Técnica:91,Alcance:62,Energía:86},
 {Vida:90,Daño:78,Velocidad:60,Agilidad:58,Defensa:88,Poder:79,Técnica:96,Alcance:80,Energía:70},
 {Vida:74,Daño:85,Velocidad:82,Agilidad:80,Defensa:64,Poder:91,Técnica:83,Alcance:72,Energía:92},
 {Vida:70,Daño:91,Velocidad:89,Agilidad:93,Defensa:50,Poder:86,Técnica:88,Alcance:66,Energía:89},
 {Vida:100,Daño:76,Velocidad:52,Agilidad:55,Defensa:94,Poder:84,Técnica:71,Alcance:70,Energía:75},
 {Vida:78,Daño:88,Velocidad:90,Agilidad:87,Defensa:57,Poder:95,Técnica:89,Alcance:94,Energía:88},
 {Vida:58,Daño:100,Velocidad:100,Agilidad:98,Defensa:40,Poder:100,Técnica:93,Alcance:60,Energía:100},
 {Vida:84,Daño:83,Velocidad:76,Agilidad:74,Defensa:79,Poder:89,Técnica:90,Alcance:77,Energía:81}
];
const MOVES=[
 ["Dash Relámpago","Cadenas de velocidad","Esquive dimensional","Eclipse total"],
 ["Golpe Sísmico","Muro de Hierro","Embestida Pesada","Coloso Absoluto"],
 ["Corte Fantasma","Paso Vacío","Marca de Ruptura","Noche Cero"],
 ["Ancla Cinética","Guardia Vectorial","Prisión Rota","Bastión Final"],
 ["Órbita Azul","Cambio de Fase","Lanza Técnica","Singularidad"],
 ["Ráfaga Carmesí","Cadena Relámpago","Danza Inversa","Overdrive"],
 ["Escudo Ruina","Contraataque","Impacto Titán","Fortaleza Omega"],
 ["Pulso Solar","Rayo Prisma","Zona Cero","Nova Final"],
 ["Sombra 0","Desliz Fantasma","Cuchilla Void","Eclipse Negro"],
 ["Paso Real","Comando Delta","Golpe Maestro","Corona Final"]
];
const DESCS=["La velocidad es mi arma. Cambia de dirección antes de que el rival pueda reaccionar.","Una muralla viviente que sacrifica movilidad para convertir cada golpe en una amenaza.","Ataca desde ángulos imposibles y desaparece antes de recibir el contraataque.","Controla el espacio con defensa, trampas y ataques que castigan el movimiento rival.","Especialista técnica que premia la precisión y los cambios de ritmo.","Presiona sin pausa y convierte pequeñas aperturas en cadenas largas.","Su defensa convierte la resistencia en daño y mantiene el control del centro.","Domina la distancia y obliga al enemigo a entrar en zonas peligrosas.","Luchador de alto riesgo: velocidad extrema, defensa mínima y daño explosivo.","Kit equilibrado diseñado para aprender todos los fundamentos del sistema."];
const SCENES=["Ciudad Nocturna","Templo en Ruinas","Córpus Industrial","Bosque Nevado","Desierto Abandonado","Club Nocturno"];
const SCENE_IMG=["5349.jpg","5353.jpg","5344.jpg","5351.jpg","5355.jpg","5350.jpg"];
const MODES=[["▣","Historia"],["♜","Arcade"],["🏆","Torneo"],["☠","Supervivencia"],["✦","Jefe"],["⚡","Desafíos"],["♟","Entrenamiento"],["◉","Contrarreloj"],["👥","Equipos"],["◎","Online*"],["◆","Caos"],["∞","Torre"],["⚔","Duelos"],["◇","RNG"],["☄","Boss Rush"]];
const REWARDS=[["👕","Trajes"],["🎨","Colores"],["◆","Accesorios"],["◉","Máscaras"],["✦","Efectos"],["☺","Emotes"],["T","Títulos"],["◇","Insignias"],["♫","Música"],["☄","Finishers"],["★","Marcos"],["⚜","Placas"]];
const VARIANTS=[
 {name:"BASE",rarity:"COMÚN",mod:{},luck:55,tag:"Equilibrada"},
 {name:"INFERNAL",rarity:"ÉPICA",mod:{Daño:15,Defensa:-8,Energía:10},luck:22,tag:"Daño ardiente"},
 {name:"GLACIAL",rarity:"ÉPICA",mod:{Defensa:12,Velocidad:-6,Control:15},luck:14,tag:"Congelación"},
 {name:"FUTURISTA",rarity:"LEGENDARIA",mod:{Velocidad:14,Agilidad:10,Alcance:8},luck:7,tag:"Tecnología"},
 {name:"LEGENDARIA",rarity:"LEGENDARIA",mod:{Vida:12,Daño:12,Poder:8},luck:3,tag:"Potenciada"},
 {name:"MÍTICA",rarity:"MÍTICA",mod:{Poder:20,Energía:15,Técnica:10},luck:1.5,tag:"Void reforzado"},
 {name:"MALDITA",rarity:"MALDITA",mod:{Vida:-30,Daño:15,Velocidad:20,Agilidad:10,Defensa:-25},luck:.5,tag:"MALA SUERTE"}
];
let state={selected:Number(localStorage.vfSel||0),coins:Number(localStorage.vfCoins||2500),crystals:Number(localStorage.vfCrystals||120),xp:Number(localStorage.vfXP||7450),difficulty:Number(localStorage.vfDiff||50),wins:Number(localStorage.vfWins||0),rolls:Number(localStorage.vfRolls||0),inventory:JSON.parse(localStorage.vfInv||"[]"),profiles:JSON.parse(localStorage.vfProfiles||"{}"),loadouts:JSON.parse(localStorage.vfLoadouts||"{}")};
fightersProfilesSeed = null;
const fighters=NAMES.map((name,i)=>({id:i,name,img:IMG[i],role:ROLES[i],level:Math.max(1,27-i%5),stats:{...BASE_STATS[i]},moves:MOVES[i],desc:DESCS[i]}));

function profile(i){
  const f=fighters[i];
  if(!state.profiles[i]) state.profiles[i]={level:f.level,xp:0,wins:0,variant:0,cosmetic:"BASE",stats:{...f.stats}};
  return state.profiles[i];
}
function saveProfile(i){
  const p=profile(i);
  state.profiles[i]=p;
  localStorage.setItem("vfProfiles",JSON.stringify(state.profiles));
}
function levelNeed(level){return 500 + level*120;}
function gainFighterXP(i,amount){
  const p=profile(i); p.xp+=amount;
  while(p.level<100 && p.xp>=levelNeed(p.level)){p.xp-=levelNeed(p.level);p.level++;
    Object.keys(p.stats).forEach(k=>p.stats[k]=Math.min(100,p.stats[k]+(Math.random()<0.5?1:0)));
  }
  saveProfile(i);
}
function currentFighter(i){const f=fighters[i],p=profile(i);return {...f,level:p.level,stats:{...p.stats},selectedVariant:p.variant,cosmetic:p.cosmetic};}
function applyProfileToRoster(){
  fighters.forEach((f,i)=>{const p=profile(i);f.level=p.level;f.stats={...p.stats};});
}

let battle=null;
const $=id=>document.getElementById(id);
function save(){Object.assign(localStorage,{vfSel:state.selected,vfCoins:state.coins,vfCrystals:state.crystals,vfXP:state.xp,vfDiff:state.difficulty,vfWins:state.wins,vfRolls:state.rolls,vfInv:JSON.stringify(state.inventory),vfProfiles:JSON.stringify(state.profiles),vfLoadouts:JSON.stringify(state.loadouts)})}
function toast(msg){const t=document.createElement('div');t.className='toast';t.textContent=msg;document.body.appendChild(t);setTimeout(()=>t.remove(),1800)}
function toggleSide(){$('side').classList.toggle('open')}
function showPanel(id,btn){document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));const el=$(id);if(el)el.classList.add('active');document.querySelectorAll('.nav').forEach(n=>n.classList.remove('active'));if(btn)btn.classList.add('active');$('side').classList.remove('open');window.scrollTo(0,0)}
function effectiveStats(f,v=VARIANTS[0]){const s={...f.stats};Object.entries(v.mod||{}).forEach(([k,n])=>{if(k in s)s[k]=Math.max(1,Math.min(100,s[k]+n))});return s}
function rarity(i){return i===5?'MÍTICA':i===6?'MALDITA':i===4?'LEGENDARIA':i===3?'LEGENDARIA':i===1||i===2?'ÉPICA':'COMÚN'}
function render(){
 $('crystals').textContent=state.crystals;$('coins').textContent=state.coins;$('xpBar').style.width=Math.round((state.xp/8000)*100)+'%';$('homeDiff').textContent=state.difficulty;
 $('miniRoster').innerHTML=fighters.slice(0,8).map((f,i)=>`<div class="mini-card" onclick="selectFighter(${i})"><div class="pic" style="background-image:url('assets/${f.img}')"></div><b>${f.name}</b><small>${rarity(i)} • NV.${f.level}</small></div>`).join('');
 $('sceneGrid').innerHTML=SCENES.map((s,i)=>`<div class="scene" style="background-image:url('assets/${SCENE_IMG[i]}')"><span>${s}</span></div>`).join('');
 $('fullSceneGrid').innerHTML=SCENES.map((s,i)=>`<div class="scene" style="background-image:url('assets/${SCENE_IMG[i]}')"><span>${s}<br><small>EFECTO: ${['NEÓN','VIGILANCIA','CALOR','ESCARCHA','ARENA','PÚBLICO'][i]}</small></span></div>`).join('');
 $('fighterGrid').innerHTML=fighters.map((f,i)=>`<article class="fighter-card" onclick="selectFighter(${i})"><div class="portrait" style="background-image:url('assets/${f.img}')"></div><div class="fighter-info"><h3>${f.name}</h3><div class="rank">${rarity(i)} • NV.${f.level}</div><p>${f.role} • POWER ${power(f.stats)}</p></div></article>`).join('');
 $('variantDatabase').innerHTML=fighters.flatMap(f=>VARIANTS.map((v,j)=>`<article class="variant-large ${j===6?'bad':''}"><div class="img" style="background-image:url('assets/${f.img}')"></div><div class="txt"><b>${f.name} // ${v.name}</b><br><small>${v.rarity} • ${v.tag}</small><br><small>Vida ${v.mod.Vida||0} | Daño +${v.mod.Daño||0} | Vel +${v.mod.Velocidad||0}</small></div></article>`)).join('');
 $('modeTiles').innerHTML=MODES.map((m,i)=>`<div class="mode-tile"><strong>${m[0]}</strong>${m[1]}${i===9?'<small style="display:block;color:#8a95a8;margin-top:4px">próximamente</small>':''}</div>`).join('');
 $('rewardTiles').innerHTML=REWARDS.slice(0,9).map(r=>`<div class="reward-tile"><strong>${r[0]}</strong>${r[1]}</div>`).join('');
 $('fullRewardGrid').innerHTML=REWARDS.map((r,i)=>`<div class="reward-tile"><strong>${r[0]} ${r[1]}</strong><small>${i%3===0?'Recompensa de maestría':'Completa desafíos, combates o eventos para conseguirlo.'}</small></div>`).join('');
 $('challengeList').innerHTML=[['Racha de acero','Gana 3 combates seguidos','+500 monedas'],['Variante rara','Obtén una variante ÉPICA o superior','+10 cristales'],['Maestro','Sube un luchador a nivel 30','Traje especial'],['Perfecto','Gana sin perder más del 10% de vida','Emote'],['RNG','Juega 5 combates aleatorios','Título'],['Caos','Gana en dificultad 75+','Marco de perfil']].map(x=>`<div class="challenge"><b>${x[0]}</b><p>${x[1]}</p><small>RECOMPENSA: ${x[2]}</small></div>`).join('');
 selectFighter(state.selected,true); updateMastery();
}
function power(s){return Math.round(Object.values(s).reduce((a,b)=>a+b,0)/Object.keys(s).length)}
function selectFighter(i,silent=false){state.selected=i;const f=fighters[i];$('focusName').textContent=f.name;$('focusRole').textContent=`${f.role} // ${rarity(i)} RANK`;$('focusDesc').textContent=f.desc;$('focusArt').style.backgroundImage=`url('assets/${f.img}')`;$('heroArt').style.backgroundImage=`url('assets/${f.img}')`;$('masteryChar').style.backgroundImage=`url('assets/${f.img}')`;$('customChar').style.backgroundImage=`url('assets/${f.img}')`;$('editorArt').style.backgroundImage=`url('assets/${f.img}')`;$('masteryName').textContent=f.name;$('customName').textContent=f.name;$('editorName').textContent=f.name;$('statPower').textContent='POWER '+power(f.stats);$('statList').innerHTML=Object.entries(f.stats).map(([k,v])=>`<div class="stat"><span>${k}</span><div class="statbar"><i style="width:${v}%"></i></div><b>${v}</b></div>`).join('');$('moveList').innerHTML=f.moves.map((m,j)=>`<div class="move"><b>${m}</b><small>${['MOVIMIENTO ÚNICO','CADENA ESPECIAL','TÉCNICA DE MOVILIDAD','ULTIMATE'][j]}</small></div>`).join('');$('variantGrid').innerHTML=VARIANTS.map((v,j)=>`<div class="variant ${j===6?'bad':''} ${j===5?'mythic':''} ${profile(i).variant===j?'equipped':''}" onclick="equipVariant(${j})" style="background-image:url('assets/${f.img}')"><span>${v.name} • ${v.rarity}${profile(i).variant===j?' • EQUIPADA':''}</span></div>`).join('');$('comboList').innerHTML=f.moves.slice(0,3).map((m,j)=>`<div class="combo-row"><div class="keys"><span class="key">${['A','B','↓ ↘ A'][j]}</span><span>→</span><span class="key">${j===2?'✦':'A'}</span></div><b>${m}</b><small>${j===0?'Frame 5 • rápido y cancelable':j===1?'Frame 12 • lanzador':'Frame 24 • alto impacto'}</small></div>`).join('');$('specialBox').innerHTML=`<b>ULTIMATE // ${f.moves[3]}</b><br><span>Consume energía máxima • daño escalable • animación exclusiva.</span>`;if(!silent){save();showPanel('home');toast(`${f.name} seleccionado`)}}
function updateMastery(){const f=fighters[state.selected],p=profile(state.selected),level=p.level,need=levelNeed(level);let xp=state.xp%need;$('masteryLevel').textContent='NV. '+level;$('xpText').textContent=`${xp.toLocaleString()} / ${need.toLocaleString()} XP`;$('masteryBar').style.width=Math.min(100,xp/need*100)+'%';$('milestones').innerHTML=[10,20,30,40,50,75,100].map(n=>`<div class="milestone ${level>=n?'unlocked':''}"><b>NV. ${n}</b> — ${level>=n?'DESBLOQUEADO':'BLOQUEADO'} • ${['Color alternativo','Emote','Traje especial','Efecto de combate','Animación','Traje mítico','Recompensa máxima'][[10,20,30,40,50,75,100].indexOf(n)]}</div>`).join('')}
function startQuickMatch(){const enemy=(state.selected+1+Math.floor(Math.random()*9))%10;startBattle(state.selected,enemy,state.difficulty)}
function randomMatch(){const p=Math.floor(Math.random()*fighters.length),e=Math.floor(Math.random()*fighters.length);state.selected=p;state.rolls++;save();selectFighter(p,true);const pv=VARIANTS[Math.floor(Math.random()*VARIANTS.length)],ev=VARIANTS[Math.floor(Math.random()*VARIANTS.length)];toast(`RNG: ${fighters[p].name} // ${pv.name} vs ${fighters[e].name} // ${ev.name}`);startBattle(p,e,state.difficulty,pv,ev)}
function equipVariant(j){
  const p=profile(state.selected);
  p.variant=j;
  saveProfile(state.selected); save();
  toast(`${fighters[state.selected].name} // ${VARIANTS[j].name} EQUIPADA`);
  render();
}
function rollVariant(){
  const weights=[55,22,14,7,1.5,.45,.05];
  const total=weights.reduce((a,b)=>a+b,0);
  let r=Math.random()*total,index=0;
  for(let i=0;i<weights.length;i++){r-=weights[i];if(r<=0){index=i;break}}
  const v=VARIANTS[index];
  state.rolls++;
  state.inventory.push(`${fighters[state.selected].name}:${v.name}`);
  equipVariant(index);
  if(v.name==='MALDITA') toast('☠ MALA SUERTE: VARIANTE MALDITA');
  else toast(`◆ OBTUVISTE ${v.name} // ${v.rarity}`);
  save();
}
function startBattle(pi,ei,d,pv=null,ev=null){
  const p=currentFighter(pi),e=currentFighter(ei);
  pv=pv||VARIANTS[profile(pi).variant||0]; ev=ev||VARIANTS[profile(ei).variant||0];
  const ps=effectiveStats(p,pv),es=effectiveStats(e,ev);battle={p,e,ps,es,pv,ev,php:ps.Vida*10,ehp:es.Vida*10,t:60,combo:0,d:Number(d)||50,timer:null};$('pName').textContent=p.name;$('eName').textContent=e.name;$('pVariant').textContent=pv.name;$('eVariant').textContent=ev.name;$('playerSprite').style.backgroundImage=`url('assets/${p.img}')`;$('enemySprite').style.backgroundImage=`url('assets/${e.img}')`;$('pHP').style.width='100%';$('eHP').style.width='100%';$('timer').textContent='60';$('difficulty').value=battle.d;$('diffValue').textContent=battle.d;showPanel('battle');clearInterval(battle.timer);battle.timer=setInterval(()=>{if(!battle)return;battle.t--;$('timer').textContent=battle.t;if(Math.random()<.45)enemyAttack();if(battle.t<=0)endBattle(battle.php>=battle.ehp)},1000)}
function setDifficulty(v){state.difficulty=Number(v);$('diffValue').textContent=v;save()}
function action(type){if(!battle)return;if(type==='left'||type==='right'||type==='down'){toast(type==='down'?'AGACHARSE':'MOVIMIENTO');return}if(type==='block'){toast('GUARDIA');return}let mult={light:.8,heavy:1.35,special:2.3,ultimate:4.2}[type]||1;let crit=Math.random()<(.08+battle.ps.Técnica/1000);if(crit)mult*=1.7;battle.combo++;let damage=Math.max(1,Math.round(battle.ps.Daño*mult*(.75+Math.random()*.5)*(1+battle.d/350)));battle.ehp=Math.max(0,battle.ehp-damage);$('eHP').style.width=(battle.ehp/(battle.es.Vida*10)*100)+'%';popDamage(damage,crit);if(battle.combo>=3){$('comboText').textContent=`${battle.combo} HIT COMBO`;$('comboText').style.opacity=1;setTimeout(()=>$('comboText').style.opacity=0,500)}if(battle.ehp<=0)endBattle(true)}
function popDamage(dmg,crit){$('hitText').textContent=(crit?'CRIT! ':'')+dmg;$('hitText').style.opacity=1;setTimeout(()=>$('hitText').style.opacity=0,300)}
function enemyAttack(){if(!battle)return;const mitigation=Math.max(.25,1-battle.ps.Defensa/220);const ai=.35+battle.d/160;let dmg=Math.round(battle.es.Daño*mitigation*ai*(.7+Math.random()*.5));if(battle.d>80&&Math.random()<.15)dmg*=2;battle.php=Math.max(0,battle.php-dmg);$('pHP').style.width=(battle.php/(battle.ps.Vida*10)*100)+'%';if(battle.php<=0)endBattle(false)}
function endBattle(win){
  if(!battle)return;
  clearInterval(battle.timer);
  const reward=100+Math.floor(Math.random()*300)+battle.d*2;
  const fighterXP=win?(250+battle.d*4):60;
  gainFighterXP(battle.p.id,fighterXP);
  if(win){
    const pp=profile(battle.p.id); pp.wins++;
    state.coins+=reward; state.xp+=fighterXP; state.wins++;
    if(Math.random()<.12)state.crystals+=5;
    toast(`VICTORIA // +${reward} monedas // +${fighterXP} XP DE ${battle.p.name}`);
  }else{
    state.xp+=fighterXP;
    toast(`DERROTA // +${fighterXP} XP DE APRENDIZAJE`);
  }
  save(); battle=null; applyProfileToRoster();
  setTimeout(()=>{showPanel('home');render()},350)
}
function saveSettings(){toast('CONFIGURACIÓN GUARDADA');}
document.addEventListener('pointerdown',e=>{const b=e.target.closest('[data-act]');if(b)action(b.dataset.act)});
function boot(){const lines=['LOADING RENDER PIPELINE...','MOUNTING CHARACTER DATABASE...','CALCULATING VARIANT MATRICES...','SYNCING PROGRESSION...','INITIALIZING COMBAT CORE...','SYSTEM READY.'];let i=0;const el=$('bootLog');const timer=setInterval(()=>{el.textContent=lines[Math.min(i++,lines.length-1)];if(i>=lines.length){clearInterval(timer);setTimeout(()=>{$('boot').style.opacity='0';setTimeout(()=>$('boot').remove(),450)},350)}},210)}
render();boot();

function unlockReward(kind){
  const costs={TRAJES:400,COLORES:150,ACCESORIOS:250,EFECTOS:300,EMOTES:120,POSES:180};
  const c=costs[kind]||100;
  if(state.coins<c){toast("MONEDAS INSUFICIENTES");return}
  state.coins-=c;
  state.inventory.push("REWARD:"+kind+":"+Date.now());
  save(); render(); toast(`DESBLOQUEADO // ${kind}`);
}
function setCosmetic(kind){
  const p=profile(state.selected); p.cosmetic=kind; saveProfile(state.selected); save();
  toast(`LOADOUT // ${kind}`);
}
function bindDynamicUI(){
  document.querySelectorAll('.custom-buttons button').forEach(b=>b.onclick=()=>unlockReward(b.textContent.trim()));
  document.querySelectorAll('.choice-row button').forEach(b=>b.onclick=()=>setCosmetic(b.textContent.trim()));
  document.querySelectorAll('.mode-tile').forEach((el,i)=>el.onclick=()=>{
    const map=["history","arcade","tournament","survival","challenges","training","training","random","tournament","random","random","survival","arcade","random","survival"];
    showPanel(map[i]||"home"); toast(`${MODES[i][1]} // MODO SELECCIONADO`);
  });
}
const _render=render;
render=function(){_render();setTimeout(bindDynamicUI,0)}
applyProfileToRoster();
