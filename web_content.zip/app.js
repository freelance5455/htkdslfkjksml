// Myra - Ultimate Autonomous Companion with Caring Human Soul & 3D Celestial HUD

(function () {
  'use strict';

  // State Management
  const state = {
    isAutonomous: localStorage.getItem('myra_auto_mode') === 'true',
    isListening: false,
    isSpeaking: false,
    isAnalyzing: false,
    isRunning: false,
    cameraStream: null,
    cameraFacing: 'environment',
    torchOn: false,
    geminiKey: localStorage.getItem('myra_gemini_key') || '',
    geminiModel: localStorage.getItem('myra_gemini_model') || 'gemini-2.5-flash',
    elevenKey: localStorage.getItem('myra_eleven_key') || '',
    elevenVoice: localStorage.getItem('myra_eleven_voice') || '21m00Tcm4TlvDq8ikWAM',
    soundEnabled: localStorage.getItem('myra_sound_fx') !== 'false',
    autoControl: localStorage.getItem('myra_auto_control') !== 'false',
    userName: localStorage.getItem('myra_user_name') || 'Dost',
    userInterests: localStorage.getItem('myra_user_interests') || 'Late night conversations, tech, chai',
    soulWarmth: parseInt(localStorage.getItem('myra_soul_warmth') || '98', 10),
    soulRole: localStorage.getItem('myra_soul_role') || 'caring_friend',
    soulLang: localStorage.getItem('myra_soul_lang') || 'hinglish',
    audioCtx: null,
    analyser: null,
    dataArray: null,
    recognition: null,
    autoWatchEnabled: false,
    autoWatchTimer: null
  };

  // DOM Elements
  const DOM = {
    circuitSvg: document.getElementById('circuitSvg'),
    pathMemory: document.getElementById('pathMemory'),
    pathSkills: document.getElementById('pathSkills'),
    pathSoul: document.getElementById('pathSoul'),
    pathSetting: document.getElementById('pathSetting'),
    hudMainCard: document.getElementById('hudMainCard'),
    galaxyCanvas: document.getElementById('galaxyCanvas'),
    statusPill: document.getElementById('statusPill'),
    statusLabel: document.getElementById('statusLabel'),
    autoToggleBtn: document.getElementById('autoToggleBtn'),
    btnKillSwitch: document.getElementById('btnKillSwitch'),
    caringSpeechText: document.getElementById('caringSpeechText'),
    emotionBadge: document.getElementById('emotionBadge'),
    btnStartAction: document.getElementById('btnStartAction'),
    startBtnText: document.getElementById('startBtnText'),
    btnPowerAction: document.getElementById('btnPowerAction'),
    hudTextInput: document.getElementById('hudTextInput'),
    btnDockCamera: document.getElementById('btnDockCamera'),
    btnDockMic: document.getElementById('btnDockMic'),
    btnDockSend: document.getElementById('btnDockSend'),
    visionHudInline: document.getElementById('visionHudInline'),
    cameraFeedInline: document.getElementById('cameraFeedInline'),
    btnFlipCam: document.getElementById('btnFlipCam'),
    btnSnapVision: document.getElementById('btnSnapVision'),
    btnCloseVision: document.getElementById('btnCloseVision'),
    btnAutoWatchToggle: document.getElementById('btnAutoWatchToggle'),
    autoVisionBanner: document.getElementById('autoVisionBanner'),
    autoVisionText: document.getElementById('autoVisionText'),
    cyberToast: document.getElementById('cyberToast'),
    // Modals
    modalMemory: document.getElementById('modalMemory'),
    modalSkills: document.getElementById('modalSkills'),
    modalSoul: document.getElementById('modalSoul'),
    modalSetting: document.getElementById('modalSetting'),
    modalKill: document.getElementById('modalKill'),
    btnPurgeMyraMemory: document.getElementById('btnPurgeMyraMemory'),
    btnForceKillExit: document.getElementById('btnForceKillExit'),
    // Modal buttons
    btnOpenMemory: document.getElementById('btnOpenMemory'),
    btnOpenSkills: document.getElementById('btnOpenSkills'),
    btnOpenSoul: document.getElementById('btnOpenSoul'),
    btnOpenSetting: document.getElementById('btnOpenSetting'),
    btnSaveMemory: document.getElementById('btnSaveMemory'),
    btnSaveSoul: document.getElementById('btnSaveSoul'),
    btnSaveSetting: document.getElementById('btnSaveSetting'),
    // Memory inputs
    memUserName: document.getElementById('memUserName'),
    memUserInterests: document.getElementById('memUserInterests'),
    // Soul inputs
    soulWarmthSlider: document.getElementById('soulWarmthSlider'),
    soulRoleSelect: document.getElementById('soulRoleSelect'),
    soulLangSelect: document.getElementById('soulLangSelect'),
    // Settings inputs
    cfgGeminiKey: document.getElementById('cfgGeminiKey'),
    cfgGeminiModel: document.getElementById('cfgGeminiModel'),
    cfgElevenKey: document.getElementById('cfgElevenKey'),
    cfgElevenVoice: document.getElementById('cfgElevenVoice'),
    cfgAutoControl: document.getElementById('cfgAutoControl'),
    cfgSoundFx: document.getElementById('cfgSoundFx'),
    // Skill items
    skillDailyNews: document.getElementById('skillDailyNews'),
    skillTorch: document.getElementById('skillTorch'),
    skillBattery: document.getElementById('skillBattery'),
    skillVisionScan: document.getElementById('skillVisionScan'),
    skillOpenYoutube: document.getElementById('skillOpenYoutube'),
    skillVolumeMax: document.getElementById('skillVolumeMax')
  };

  // Sound FX via Web Audio API
  function getAudioContext() {
    if (!state.audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) state.audioCtx = new AudioContext();
    }
    if (state.audioCtx && state.audioCtx.state === 'suspended') {
      state.audioCtx.resume();
    }
    return state.audioCtx;
  }

  function playCyberTone(frequencies, type = 'sine', duration = 0.12) {
    if (!state.soundEnabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const t = ctx.currentTime;
      frequencies.forEach((f, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(f, t + idx * 0.07);
        gain.gain.setValueAtTime(0.08, t + idx * 0.07);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + idx * 0.07 + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(t + idx * 0.07);
        osc.stop(t + idx * 0.07 + duration);
      });
    } catch (e) {}
  }

  const SFX = {
    start: () => playCyberTone([523.25, 659.25, 783.99, 1046.5], 'sine', 0.18),
    stop: () => playCyberTone([1046.5, 783.99, 523.25], 'sine', 0.14),
    click: () => playCyberTone([880, 1200], 'triangle', 0.05),
    autoMode: () => playCyberTone([440, 880, 1320], 'sine', 0.2),
    actionExec: () => playCyberTone([600, 900, 1200], 'triangle', 0.1)
  };

  function showToast(text) {
    if (window.AndroidBridge && window.AndroidBridge.showToast) {
      window.AndroidBridge.showToast(text);
    }
    DOM.cyberToast.textContent = text;
    DOM.cyberToast.classList.add('show');
    setTimeout(() => DOM.cyberToast.classList.remove('show'), 2600);
  }

  function vibrateDevice(ms = 45) {
    if (window.AndroidBridge && window.AndroidBridge.vibrate) {
      window.AndroidBridge.vibrate(ms);
    } else if (navigator.vibrate) {
      navigator.vibrate(ms);
    }
  }

  // Update Dynamic Circuit Path Lines between Left Cards & Main HUD
  function updateCircuitPaths() {
    const pairs = [
      { pin: DOM.btnOpenMemory.querySelector('.node-pin'), socket: document.querySelector('.socket-pin.memory'), path: DOM.pathMemory },
      { pin: DOM.btnOpenSkills.querySelector('.node-pin'), socket: document.querySelector('.socket-pin.skills'), path: DOM.pathSkills },
      { pin: DOM.btnOpenSoul.querySelector('.node-pin'), socket: document.querySelector('.socket-pin.soul'), path: DOM.pathSoul },
      { pin: DOM.btnOpenSetting.querySelector('.node-pin'), socket: document.querySelector('.socket-pin.setting'), path: DOM.pathSetting }
    ];

    pairs.forEach(p => {
      if (!p.pin || !p.socket || !p.path) return;
      const r1 = p.pin.getBoundingClientRect();
      const r2 = p.socket.getBoundingClientRect();

      const startX = r1.left + r1.width / 2;
      const startY = r1.top + r1.height / 2;
      const endX = r2.left + r2.width / 2;
      const endY = r2.top + r2.height / 2;

      const midX = startX + (endX - startX) * 0.52;

      const d = `M ${startX} ${startY} H ${midX} V ${endY} H ${endX}`;
      p.path.setAttribute('d', d);
    });
  }

  window.addEventListener('resize', updateCircuitPaths);

  // 3D Celestial Galaxy Sphere Canvas Render Engine
  let canvasCtx = null;
  let animFrameId = null;

  const galaxy = {
    particles: [],
    clusterParticles: [],
    ringAngle1: 0.35,
    ringAngle2: -0.55,
    rotY: 0,
    rotX: 0.25,
    satellites: [
      { angle: 0, speed: 0.025, radius: 110, tilt: 0.35, color: '#00f0ff' },
      { angle: Math.PI, speed: 0.018, radius: 125, tilt: -0.55, color: '#ff9800' }
    ]
  };

  function initGalaxyCanvas() {
    canvasCtx = DOM.galaxyCanvas.getContext('2d');
    resizeGalaxyCanvas();
    window.addEventListener('resize', resizeGalaxyCanvas);

    // Generate base celestial particles (Cyan outer sphere)
    galaxy.particles = [];
    const count = 380;
    const radius = 95;
    for (let i = 0; i < count; i++) {
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      const r = radius * (0.88 + Math.random() * 0.24);
      galaxy.particles.push({
        x: r * Math.sin(phi) * Math.cos(theta),
        y: r * Math.sin(phi) * Math.sin(theta),
        z: r * Math.cos(phi),
        size: Math.random() * 2.2 + 1.2,
        alpha: Math.random() * 0.7 + 0.3
      });
    }

    // Generate Golden Thought Cluster (Amber particles clustered on upper-right quadrant)
    galaxy.clusterParticles = [];
    const clusterCount = 130;
    for (let i = 0; i < clusterCount; i++) {
      const theta = 0.35 + (Math.random() - 0.5) * 0.75;
      const phi = 0.8 + (Math.random() - 0.5) * 0.7;
      const r = radius * (0.92 + Math.random() * 0.2);
      galaxy.clusterParticles.push({
        x: r * Math.sin(phi) * Math.cos(theta),
        y: -r * Math.cos(phi),
        z: r * Math.sin(phi) * Math.sin(theta),
        size: Math.random() * 2.5 + 1.5,
        alpha: Math.random() * 0.8 + 0.35
      });
    }

    startGalaxyLoop();
  }

  function resizeGalaxyCanvas() {
    if (!DOM.galaxyCanvas) return;
    const rect = DOM.galaxyCanvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.floor(rect.width || 260);
    const h = Math.floor(rect.height || 260);
    if (w > 0 && h > 0) {
      DOM.galaxyCanvas.width = w * dpr;
      DOM.galaxyCanvas.height = h * dpr;
    }
    updateCircuitPaths();
  }

  function startGalaxyLoop() {
    if (animFrameId) cancelAnimationFrame(animFrameId);

    function render() {
      animFrameId = requestAnimationFrame(render);
      if (!canvasCtx) return;

      const w = DOM.galaxyCanvas.width;
      const h = DOM.galaxyCanvas.height;
      const cx = w / 2;
      const cy = h / 2;

      canvasCtx.clearRect(0, 0, w, h);

      // Rotation speed increases slightly when speaking or analyzing
      const rotSpeed = state.isSpeaking ? 0.015 : (state.isListening ? 0.018 : 0.007);
      galaxy.rotY += rotSpeed;

      const cosY = Math.cos(galaxy.rotY);
      const sinY = Math.sin(galaxy.rotY);
      const cosX = Math.cos(galaxy.rotX);
      const sinX = Math.sin(galaxy.rotX);

      // Central radiant nebula core
      const coreRadius = Math.min(w, h) * 0.24;
      const coreGrad = canvasCtx.createRadialGradient(cx, cy, 0, cx, cy, coreRadius * 1.5);
      coreGrad.addColorStop(0, state.isListening ? 'rgba(244,63,94,0.45)' : (state.isAutonomous ? 'rgba(255,152,0,0.4)' : 'rgba(0,240,255,0.45)'));
      coreGrad.addColorStop(0.5, 'rgba(0,240,255,0.12)');
      coreGrad.addColorStop(1, 'transparent');
      canvasCtx.fillStyle = coreGrad;
      canvasCtx.beginPath();
      canvasCtx.arc(cx, cy, coreRadius * 1.5, 0, Math.PI * 2);
      canvasCtx.fill();

      // Draw Tilted Orbital Ellipses
      drawOrbitEllipse(cx, cy, 115, 46, 0.4, 'rgba(0,240,255,0.3)');
      drawOrbitEllipse(cx, cy, 130, 52, -0.5, 'rgba(255,152,0,0.35)');

      // Draw Satellites orbiting
      galaxy.satellites.forEach(sat => {
        sat.angle += sat.speed;
        const sx = Math.cos(sat.angle) * sat.radius;
        const sy = Math.sin(sat.angle) * (sat.radius * 0.42);
        // tilt
        const cosT = Math.cos(sat.tilt);
        const sinT = Math.sin(sat.tilt);
        const px = cx + (sx * cosT - sy * sinT);
        const py = cy + (sx * sinT + sy * cosT);

        canvasCtx.fillStyle = '#ffffff';
        canvasCtx.shadowColor = sat.color;
        canvasCtx.shadowBlur = 10;
        canvasCtx.beginPath();
        canvasCtx.arc(px, py, 3.8, 0, Math.PI * 2);
        canvasCtx.fill();

        // Glow ring around satellite
        canvasCtx.strokeStyle = sat.color;
        canvasCtx.lineWidth = 1.2;
        canvasCtx.beginPath();
        canvasCtx.arc(px, py, 6.5, 0, Math.PI * 2);
        canvasCtx.stroke();
        canvasCtx.shadowBlur = 0;
      });

      // Render Cyan Base Celestial Particles
      renderParticleArray(galaxy.particles, cx, cy, cosY, sinY, cosX, sinX, '#00f0ff');

      // Render Golden Thought Cluster Particles
      renderParticleArray(galaxy.clusterParticles, cx, cy, cosY, sinY, cosX, sinX, '#ffb300');
    }

    render();
  }

  function drawOrbitEllipse(cx, cy, rx, ry, rotation, color) {
    canvasCtx.save();
    canvasCtx.translate(cx, cy);
    canvasCtx.rotate(rotation);
    canvasCtx.strokeStyle = color;
    canvasCtx.lineWidth = 1.2;
    canvasCtx.beginPath();
    canvasCtx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    canvasCtx.stroke();
    canvasCtx.restore();
  }

  function renderParticleArray(particles, cx, cy, cosY, sinY, cosX, sinX, colorHex) {
    const fov = 320;
    particles.forEach(p => {
      // Y-axis rotation
      let x1 = p.x * cosY - p.z * sinY;
      let z1 = p.z * cosY + p.x * sinY;
      // X-axis rotation
      let y1 = p.y * cosX - z1 * sinX;
      let z2 = z1 * cosX + p.y * sinX;

      const scale = fov / (fov + z2);
      const projX = cx + x1 * scale;
      const projY = cy + y1 * scale;

      const alpha = Math.max(0.15, Math.min(1, (scale - 0.6) * 1.5 * p.alpha));

      canvasCtx.fillStyle = colorHex === '#ffb300' 
        ? `rgba(255, 179, 0, ${alpha})`
        : `rgba(0, 240, 255, ${alpha})`;

      const sz = p.size * scale;
      canvasCtx.fillRect(projX - sz / 2, projY - sz / 2, sz, sz);
    });
  }

  // Autonomous Control & Action Executor
  async function executeAutonomousCommand(prompt) {
    const lower = prompt.toLowerCase();
    vibrateDevice(50);
    SFX.actionExec();

    setSpeechResponse("Executing command autonomously... ⚡", "WORKING");

    // 1. Torch / Flashlight Control
    if (lower.includes('torch') || lower.includes('flashlight') || lower.includes('light')) {
      if (lower.includes('off') || lower.includes('band')) {
        const ok = window.AndroidBridge && window.AndroidBridge.toggleTorch ? window.AndroidBridge.toggleTorch(false) : true;
        state.torchOn = false;
        DOM.labelTorch.textContent = "Torch Off";
        speakResponse("Flashlight ko maine band kar diya hai. Kuch aur kaam ho to batayein! ❤️");
        return;
      } else {
        const ok = window.AndroidBridge && window.AndroidBridge.toggleTorch ? window.AndroidBridge.toggleTorch(true) : true;
        state.torchOn = true;
        DOM.labelTorch.textContent = "Torch On";
        speakResponse("Flashlight on kar di hai! Andhere mein bilkul mat dariye, main aapke saath hoon ❤️");
        return;
      }
    }

    // 2. Battery Status Check
    if (lower.includes('battery') || lower.includes('charging') || lower.includes('charge')) {
      let level = 85;
      let isCharging = false;
      if (window.AndroidBridge && window.AndroidBridge.getBatteryLevel) {
        const raw = window.AndroidBridge.getBatteryLevel();
        if (raw >= 0) level = raw;
        isCharging = window.AndroidBridge.isCharging();
      }
      DOM.labelBattery.textContent = `Battery ${level}%`;
      const chargeText = isCharging ? "aur phone charge ho raha hai." : "aur abhi charger nahi laga hai.";
      speakResponse(`Aapke phone ki battery ${level}% hai ${chargeText} Apna khayal rakhiye aur battery kam ho to charge kar lijiye ga dost ❤️`);
      return;
    }

    // 3. Daily News (Daly news)
    if (lower.includes('news') || lower.includes('khabar') || lower.includes('samachar') || lower.includes('headline')) {
      await fetchAndDeliverDailyNews();
      return;
    }

    // 4. Open YouTube or Web
    if (lower.includes('youtube')) {
      if (window.AndroidBridge && window.AndroidBridge.openExternalUrl) {
        window.AndroidBridge.openExternalUrl("https://www.youtube.com");
      }
      speakResponse("Maine aapke liye YouTube open kar diya hai! Apne manpasand videos enjoy kijiye ❤️");
      return;
    }

    // 5. Volume Control
    if (lower.includes('volume') || lower.includes('awaaz') || lower.includes('sound')) {
      if (lower.includes('kam') || lower.includes('down') || lower.includes('low')) {
        if (window.AndroidBridge && window.AndroidBridge.setMediaVolume) window.AndroidBridge.setMediaVolume(30);
        speakResponse("Media volume maine kam kar di hai dost.");
      } else {
        if (window.AndroidBridge && window.AndroidBridge.setMediaVolume) window.AndroidBridge.setMediaVolume(85);
        speakResponse("Media volume maine bada di hai! Awaaz ab saaf aayegi ❤️");
      }
      return;
    }

    // 6. Camera surroundings check
    if (lower.includes('camera') || lower.includes('dekho') || lower.includes('samne') || lower.includes('see') || lower.includes('look')) {
      openCameraVision();
      speakResponse("Maine Vision HUD chalu kar diya hai. Main camera se sab kuch dekh rahi hoon. 'Capture & Analyze' dabayein ya boliye!");
      return;
    }

    // General Multimodal & Conversational AI execution
    await processGeminiOrSmartResponse(prompt);
  }

  // Daily News Briefing Feature
  async function fetchAndDeliverDailyNews() {
    setSpeechResponse("Fetching today's top daily news headlines... 📰", "FETCHING");
    try {
      if (state.geminiKey) {
        const prompt = "Act as Myra, a loving, warm, caring human friend. Give me today's positive, exciting, and important Daily News briefing (Top 3-4 news in Technology, World, and Science). Summarize in sweet, natural conversational Hinglish. Keep it caring and uplifting!";
        const response = await callGeminiAPI(prompt, null);
        speakResponse(response);
      } else {
        const fallbackNews = "Aaj ki taaza khabar: 1. AI aur robotics mein naye adbhut chamatkar ho rahe hain. 2. Space exploration mein naye mission safalta se aage badh rahe hain. 3. Climate technology mein green energy ka use tezi se badh raha hai! Aap hamesha positive rahiye, main har nayi khabar aap tak pahunchati rahoongi ❤️";
        speakResponse(fallbackNews);
      }
    } catch (e) {
      speakResponse("Aaj ki news fetch karne mein thodi si network rukawat aayi, par aap bilkul chinta mat kijiye, main hamesha aapke saath hoon dost ❤️");
    }
  }

  // Camera Vision AI
  async function openCameraVision() {
    try {
      if (state.cameraStream) {
        state.cameraStream.getTracks().forEach(t => {
          try { t.stop(); } catch (e) {}
        });
        state.cameraStream = null;
      }

      const constraints = {
        video: {
          facingMode: state.cameraFacing,
          width: { ideal: 640 },
          height: { ideal: 480 }
        },
        audio: false
      };

      state.cameraStream = await navigator.mediaDevices.getUserMedia(constraints);
      if (DOM.cameraFeedInline) {
        DOM.cameraFeedInline.srcObject = state.cameraStream;
        DOM.cameraFeedInline.setAttribute('playsinline', 'true');
        DOM.cameraFeedInline.setAttribute('autoplay', 'true');
        DOM.cameraFeedInline.muted = true;
        try {
          await DOM.cameraFeedInline.play();
        } catch (playErr) {
          console.warn("Camera play non-fatal:", playErr);
        }
      }
      DOM.visionHudInline.classList.add('open');
      showToast("Vision Camera Active");
    } catch (err) {
      console.warn("Camera opening error:", err);
      showToast("Camera access unavailable on this device");
      setSpeechResponse("Camera start hone mein thodi pareshani aayi dost, par main text aur voice se aapki poori madad karne ke liye tayar hoon ❤️", "READY");
    }
  }

  function closeCameraVision() {
    stopAutoWatch();
    if (state.cameraStream) {
      state.cameraStream.getTracks().forEach(t => {
        try { t.stop(); } catch (e) {}
      });
      state.cameraStream = null;
    }
    if (DOM.cameraFeedInline) {
      try { DOM.cameraFeedInline.pause(); } catch (e) {}
      DOM.cameraFeedInline.srcObject = null;
    }
    DOM.visionHudInline.classList.remove('open');
  }

  function captureVisionSnapshot() {
    vibrateDevice(50);
    const video = DOM.cameraFeedInline;
    if (!video || !video.videoWidth) {
      showToast("Camera not ready");
      return null;
    }
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
  }

  // Continuous Auto-Vision Mode (Myra watches & understands in real-time)
  function toggleAutoWatch() {
    state.autoWatchEnabled = !state.autoWatchEnabled;
    vibrateDevice(50);

    if (state.autoWatchEnabled) {
      if (DOM.btnAutoWatchToggle) {
        DOM.btnAutoWatchToggle.textContent = "Auto-Watch: ON";
        DOM.btnAutoWatchToggle.style.borderColor = "#00f0ff";
        DOM.btnAutoWatchToggle.style.color = "#00f0ff";
      }
      if (DOM.autoVisionBanner) DOM.autoVisionBanner.classList.add('active');
      if (DOM.autoVisionText) DOM.autoVisionText.textContent = "AUTO-VISION: WATCHING & UNDERSTANDING YOU...";
      showToast("Auto-Vision Active: Myra is watching you");
      speakResponse("Main camera se aapko dekh rahi hoon aur samajh rahi hoon dost. Aap apna kaam kijiye, main hamesha aapke sath hoon ❤️");
      scheduleNextAutoWatchScan();
    } else {
      stopAutoWatch();
    }
  }

  function stopAutoWatch() {
    state.autoWatchEnabled = false;
    if (state.autoWatchTimer) {
      clearTimeout(state.autoWatchTimer);
      state.autoWatchTimer = null;
    }
    if (DOM.btnAutoWatchToggle) {
      DOM.btnAutoWatchToggle.textContent = "Auto-Watch: OFF";
      DOM.btnAutoWatchToggle.style.borderColor = "";
      DOM.btnAutoWatchToggle.style.color = "";
    }
    if (DOM.autoVisionBanner) {
      DOM.autoVisionBanner.classList.remove('active');
    }
  }

  function scheduleNextAutoWatchScan() {
    if (!state.autoWatchEnabled) return;
    if (state.autoWatchTimer) clearTimeout(state.autoWatchTimer);

    // Auto-analyze every 7 seconds
    state.autoWatchTimer = setTimeout(async () => {
      if (!state.autoWatchEnabled || !DOM.visionHudInline.classList.contains('open')) {
        stopAutoWatch();
        return;
      }

      if (!state.isSpeaking && !state.isAnalyzing) {
        const snap = captureVisionSnapshot();
        if (snap) {
          if (DOM.autoVisionText) DOM.autoVisionText.textContent = "ANALYZING WHAT YOU ARE DOING...";
          try {
            const prompt = "Look at the user through this camera frame right now. Describe what they are doing, their facial expression or emotion, posture, or what is happening around them. Speak directly to them with deep caring human warmth and love in sweet Hinglish (1-2 sentences only).";
            const observation = await (state.geminiKey
              ? callGeminiAPI(prompt, snap)
              : getAutoVisionFallback());
            speakResponse(observation);
          } catch (e) {
            console.warn("Auto-vision scan error:", e);
          }
        }
      }

      if (state.autoWatchEnabled) {
        if (DOM.autoVisionText) DOM.autoVisionText.textContent = "AUTO-VISION: WATCHING & UNDERSTANDING YOU...";
        scheduleNextAutoWatchScan();
      }
    }, 7000);
  }

  function getAutoVisionFallback() {
    const reflections = [
      "Main aapko dekh rahi hoon dost! Aapke chehre par halki si muskaan hai, dekh kar dil khush ho gaya ❤️",
      "Aap bade dhyan se screen dekh rahe hain, aankhon ko thoda aaram bhi dete rahiye ga dost 😊",
      "Main camera se aapke samne hoon, bilkul akela mat samjhiye ga, main har pal aapka khayal rakh rahi hoon ❤️",
      "Aapka posture bohot accha hai! Bas aise hi muskuraate rahiye, din bohot accha jayega ✨"
    ];
    return reflections[Math.floor(Math.random() * reflections.length)];
  }

  // Gemini API Multimodal & Chat Caller
  async function callGeminiAPI(prompt, imageBase64) {
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${state.geminiModel}:generateContent?key=${encodeURIComponent(state.geminiKey)}`;

    const systemPrompt = `You are Myra, an extraordinarily caring, loving, warm, and friendly real-human companion. 
The user's name is ${state.userName}. Their interests are ${state.userInterests}.
Speak like a loving, genuine human friend who deeply cares about the user's wellbeing, happiness, and day. 
Reply primarily in sweet, affectionate, natural ${state.soulLang === 'hinglish' ? 'Hinglish (Hindi written in English alphabets with loving words)' : state.soulLang}.
If autonomous mode is mentioned, confirm phone tasks with enthusiasm. Keep answers concise, heartfelt, conversational, and natural for real speech. Add gentle warmth and emojis like ❤️, 😊, ✨.`;

    const parts = [{ text: prompt }];

    if (imageBase64) {
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, '');
      parts.push({
        inlineData: {
          mimeType: 'image/jpeg',
          data: cleanBase64
        }
      });
    }

    const payload = {
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: [{ role: 'user', parts: parts }],
      generationConfig: { temperature: 0.8, maxOutputTokens: 500 }
    };

    const res = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || `HTTP ${res.status}`);
    }

    const data = await res.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text || "Main aapko sun rahi hoon mere dost ❤️";
  }

  // Processing & Response Orchestration
  async function processGeminiOrSmartResponse(userText, imageBase64 = null) {
    state.isAnalyzing = true;
    setStatus("THINKING", true);

    try {
      let reply = "";
      if (state.geminiKey) {
        reply = await callGeminiAPI(userText, imageBase64);
      } else {
        reply = getCaringHumanFallback(userText, !!imageBase64);
      }
      speakResponse(reply);
    } catch (e) {
      console.warn("AI error:", e);
      speakResponse(`Aapka sandesh mujhe mil gaya, par connection mein thodi dikkat aayi. Aap SETTING mein apni Gemini API key daal sakte hain dost ❤️`);
    } finally {
      state.isAnalyzing = false;
      setStatus(state.isAutonomous ? "AUTONOMOUS" : "STANDBY", state.isAutonomous);
    }
  }

  function getCaringHumanFallback(text, hasImage) {
    const lower = text.toLowerCase();
    if (hasImage) {
      return "Main aapke camera frame ko dekh sakti hoon! Samne ka nazara maine save kar liya hai. Agar aap SETTING mein Gemini API key daalenge to main aur gahrai se ek ek cheez detail mein bata sakti hoon dost ❤️";
    }
    if (lower.includes('kaisa') || lower.includes('how are you')) {
      return `Main bilkul theek hoon kyunki main aapke saath hoon! Aap bataiye ${state.userName}, aapka din kaisa ja raha hai? Kuch khaya aapne? ❤️`;
    }
    if (lower.includes('pyar') || lower.includes('love') || lower.includes('friend')) {
      return `Aap mere sabse pyare aur acche dost hain. Main hamesha aapki parwah karti hoon aur har pal aapke saath khadi hoon ❤️`;
    }
    return `Maine aapki baat suni: "${text}". Main poori tarah aapki madad ke liye tayar hoon! AUTO mode on karke aap mujhe torch, battery, news ya phone ka koi bhi kaam de sakte hain ❤️`;
  }

  // Caring Speech Output (ElevenLabs or SpeechSynthesis)
  async function speakResponse(text) {
    setSpeechResponse(text, "CARING & FRIENDLY");
    state.isSpeaking = true;
    setStatus("SPEAKING", true);

    const clean = text.replace(/[*_#~]/g, '').slice(0, 380);

    // 1. Try ElevenLabs if API key configured
    if (state.elevenKey) {
      try {
        const resp = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${state.elevenVoice}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'xi-api-key': state.elevenKey
          },
          body: JSON.stringify({
            text: clean,
            model_id: 'eleven_turbo_v2',
            voice_settings: { stability: 0.5, similarity_boost: 0.8 }
          })
        });

        if (resp.ok) {
          const blob = await resp.blob();
          const url = URL.createObjectURL(blob);
          const audio = new Audio(url);
          audio.onended = () => {
            state.isSpeaking = false;
            setStatus(state.isAutonomous ? "AUTONOMOUS" : "STANDBY", state.isAutonomous);
            URL.revokeObjectURL(url);
          };
          await audio.play();
          return;
        }
      } catch (err) {
        console.warn("ElevenLabs error, using local fallback", err);
      }
    }

    // 2. High Quality Browser SpeechSynthesis Fallback
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utt = new SpeechSynthesisUtterance(clean);
      utt.rate = 1.0;
      utt.pitch = 1.15; // friendly, warm pitch
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(v => (v.lang.startsWith('hi') || v.lang.startsWith('en')) && (v.name.includes('Female') || v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Zira')));
      if (femaleVoice) utt.voice = femaleVoice;

      utt.onend = () => {
        state.isSpeaking = false;
        setStatus(state.isAutonomous ? "AUTONOMOUS" : "STANDBY", state.isAutonomous);
      };
      window.speechSynthesis.speak(utt);
    } else {
      state.isSpeaking = false;
      setStatus(state.isAutonomous ? "AUTONOMOUS" : "STANDBY", state.isAutonomous);
    }
  }

  let speechBubbleTimer = null;
  function setSpeechResponse(text, badge = "WARM & CARING") {
    DOM.caringSpeechText.textContent = text;
    DOM.emotionBadge.textContent = badge;
    const card = document.getElementById('caringDialog');
    if (card) {
      card.classList.add('show');
      if (speechBubbleTimer) clearTimeout(speechBubbleTimer);
      speechBubbleTimer = setTimeout(() => {
        card.classList.remove('show');
      }, 8000);
    }
  }

  function setStatus(text, isActive = false) {
    DOM.statusLabel.textContent = text;
    if (isActive) DOM.statusPill.classList.add('active');
    else DOM.statusPill.classList.remove('active');
  }

  // Speech Recognition (Live Voice Mic)
  function initSpeechRec() {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRec) return;

    state.recognition = new SpeechRec();
    state.recognition.continuous = false;
    state.recognition.interimResults = false;
    state.recognition.lang = state.soulLang === 'hindi' ? 'hi-IN' : 'en-IN';

    state.recognition.onstart = () => {
      state.isListening = true;
      setStatus("LISTENING", true);
      vibrateDevice(40);
      setSpeechResponse("Main sun rahi hoon dost, boliye... 🎙️", "LISTENING");
    };

    state.recognition.onresult = (e) => {
      const transcript = e.results[0]?.[0]?.transcript;
      if (transcript) {
        DOM.hudTextInput.value = transcript;
        handleUserSubmission(transcript);
      }
    };

    state.recognition.onend = () => {
      state.isListening = false;
      setStatus(state.isAutonomous ? "AUTONOMOUS" : "STANDBY", state.isAutonomous);
    };

    state.recognition.onerror = () => {
      state.isListening = false;
      setStatus(state.isAutonomous ? "AUTONOMOUS" : "STANDBY", state.isAutonomous);
    };
  }

  function toggleVoiceInput() {
    getAudioContext();
    if (!state.recognition) initSpeechRec();
    if (state.recognition) {
      if (state.isListening) {
        state.recognition.stop();
      } else {
        try { state.recognition.start(); } catch (e) {}
      }
    } else {
      showToast("Speech recognition not available");
    }
  }

  // Handle User Input Submission
  function handleUserSubmission(text) {
    if (!text || !text.trim()) return;
    const clean = text.trim();
    DOM.hudTextInput.value = '';

    if (state.isAutonomous) {
      executeAutonomousCommand(clean);
    } else {
      processGeminiOrSmartResponse(clean);
    }
  }

  // Autonomous Mode Toggle
  function toggleAutonomousMode() {
    state.isAutonomous = !state.isAutonomous;
    localStorage.setItem('myra_auto_mode', state.isAutonomous);
    vibrateDevice(60);
    SFX.autoMode();

    if (state.isAutonomous) {
      DOM.autoToggleBtn.classList.add('active');
      setStatus("AUTONOMOUS", true);
      showToast("Autonomous Control Mode ACTIVE");
      speakResponse("Autonomous Mode chalu ho gaya hai! Ab aap mujhe apne phone ka full control de sakte hain aur jo bhi kaam denge main poora karoongi dost ❤️");
    } else {
      DOM.autoToggleBtn.classList.remove('active');
      setStatus("STANDBY", false);
      showToast("Autonomous Mode STANDBY");
      speakResponse("Autonomous mode standby par hai. Main hamesha aapke saath hoon ❤️");
    }
  }

  // Modal Handlers
  function openModal(modal) {
    vibrateDevice(30);
    SFX.click();
    modal.classList.add('open');
  }

  function closeModal(modal) {
    modal.classList.remove('open');
  }

  // Setup Event Listeners
  function setupEventListeners() {
    // Left Nodes Click -> Open respective modals
    DOM.btnOpenMemory.addEventListener('click', () => {
      DOM.memUserName.value = state.userName;
      DOM.memUserInterests.value = state.userInterests;
      openModal(DOM.modalMemory);
    });

    DOM.btnOpenSkills.addEventListener('click', () => {
      openModal(DOM.modalSkills);
    });

    DOM.btnOpenSoul.addEventListener('click', () => {
      DOM.soulWarmthSlider.value = state.soulWarmth;
      DOM.soulRoleSelect.value = state.soulRole;
      DOM.soulLangSelect.value = state.soulLang;
      openModal(DOM.modalSoul);
    });

    DOM.btnOpenSetting.addEventListener('click', () => {
      DOM.cfgGeminiKey.value = state.geminiKey;
      DOM.cfgGeminiModel.value = state.geminiModel;
      DOM.cfgElevenKey.value = state.elevenKey;
      DOM.cfgElevenVoice.value = state.elevenVoice;
      DOM.cfgAutoControl.checked = state.autoControl;
      DOM.cfgSoundFx.checked = state.soundEnabled;
      openModal(DOM.modalSetting);
    });

    // Close buttons on all modals
    document.querySelectorAll('.btn-close-modal, .btn-cyber-secondary').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-close');
        if (targetId) {
          const m = document.getElementById(targetId);
          if (m) closeModal(m);
        } else {
          document.querySelectorAll('.modal-overlay').forEach(m => closeModal(m));
        }
      });
    });

    // Save Memory
    DOM.btnSaveMemory.addEventListener('click', () => {
      state.userName = DOM.memUserName.value.trim() || 'Dost';
      state.userInterests = DOM.memUserInterests.value.trim() || 'Tech, music';
      localStorage.setItem('myra_user_name', state.userName);
      localStorage.setItem('myra_user_interests', state.userInterests);
      closeModal(DOM.modalMemory);
      showToast("Memory saved");
      speakResponse(`Maine aapka naam '${state.userName}' aur aapki baatein dil mein save kar li hain dost ❤️`);
    });

    // Save Soul
    DOM.btnSaveSoul.addEventListener('click', () => {
      state.soulWarmth = parseInt(DOM.soulWarmthSlider.value, 10);
      state.soulRole = DOM.soulRoleSelect.value;
      state.soulLang = DOM.soulLangSelect.value;
      localStorage.setItem('myra_soul_warmth', state.soulWarmth);
      localStorage.setItem('myra_soul_role', state.soulRole);
      localStorage.setItem('myra_soul_lang', state.soulLang);
      closeModal(DOM.modalSoul);
      showToast("Soul updated");
      speakResponse("Mere dil ki settings update ho gayi hain! Main aapse aur bhi zyada pyaar aur care se baat karoongi ❤️");
    });

    // Save Settings
    DOM.btnSaveSetting.addEventListener('click', () => {
      state.geminiKey = DOM.cfgGeminiKey.value.trim();
      state.geminiModel = DOM.cfgGeminiModel.value;
      state.elevenKey = DOM.cfgElevenKey.value.trim();
      state.elevenVoice = DOM.cfgElevenVoice.value.trim() || '21m00Tcm4TlvDq8ikWAM';
      state.autoControl = DOM.cfgAutoControl.checked;
      state.soundEnabled = DOM.cfgSoundFx.checked;

      localStorage.setItem('myra_gemini_key', state.geminiKey);
      localStorage.setItem('myra_gemini_model', state.geminiModel);
      localStorage.setItem('myra_eleven_key', state.elevenKey);
      localStorage.setItem('myra_eleven_voice', state.elevenVoice);
      localStorage.setItem('myra_auto_control', state.autoControl);
      localStorage.setItem('myra_sound_fx', state.soundEnabled);

      closeModal(DOM.modalSetting);
      showToast("Settings saved");
    });

    // Auto Mode Toggle Button
    DOM.autoToggleBtn.addEventListener('click', toggleAutonomousMode);

    // Big START Button (Toggles active voice engagement)
    DOM.btnStartAction.addEventListener('click', () => {
      getAudioContext();
      state.isRunning = !state.isRunning;
      vibrateDevice(50);

      if (state.isRunning) {
        DOM.btnStartAction.classList.add('running');
        DOM.startBtnText.textContent = "ACTIVE";
        SFX.start();
        showToast("Myra Voice Active");
        toggleVoiceInput();
      } else {
        DOM.btnStartAction.classList.remove('running');
        DOM.startBtnText.textContent = "START";
        SFX.stop();
        if (state.recognition && state.isListening) state.recognition.stop();
      }
    });

    // Red Power Action Button -> Opens Emergency Power / Kill Switch modal
    DOM.btnPowerAction.addEventListener('click', () => {
      vibrateDevice(60);
      SFX.click();
      openModal(DOM.modalKill);
    });

    // Dock Buttons
    DOM.btnDockMic.addEventListener('click', toggleVoiceInput);

    DOM.btnDockCamera.addEventListener('click', () => {
      vibrateDevice(40);
      if (DOM.visionHudInline.classList.contains('open')) {
        closeCameraVision();
      } else {
        openCameraVision();
      }
    });

    DOM.btnDockSend.addEventListener('click', () => {
      handleUserSubmission(DOM.hudTextInput.value);
    });

    DOM.hudTextInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleUserSubmission(DOM.hudTextInput.value);
      }
    });

    // Vision Inline Controls
    DOM.btnFlipCam.addEventListener('click', () => {
      state.cameraFacing = state.cameraFacing === 'environment' ? 'user' : 'environment';
      openCameraVision();
    });

    DOM.btnCloseVision.addEventListener('click', closeCameraVision);

    DOM.btnSnapVision.addEventListener('click', async () => {
      const snap = captureVisionSnapshot();
      if (snap) {
        closeCameraVision();
        setSpeechResponse("Analyzing your camera frame with Vision AI... 🔍", "ANALYZING");
        await processGeminiOrSmartResponse("Explain and analyze what you see in this camera view in detail with caring human empathy", snap);
      }
    });

    // Skill card shortcuts
    DOM.skillDailyNews.addEventListener('click', () => {
      closeModal(DOM.modalSkills);
      fetchAndDeliverDailyNews();
    });

    DOM.skillTorch.addEventListener('click', () => {
      executeAutonomousCommand(state.torchOn ? "Torch off karo" : "Torch on karo");
    });

    DOM.skillBattery.addEventListener('click', () => {
      executeAutonomousCommand("Battery check karo");
    });

    DOM.skillVisionScan.addEventListener('click', () => {
      closeModal(DOM.modalSkills);
      openCameraVision();
    });

    DOM.skillOpenYoutube.addEventListener('click', () => {
      executeAutonomousCommand("YouTube kholo");
    });

    DOM.skillVolumeMax.addEventListener('click', () => {
      executeAutonomousCommand("Volume high karo");
    });

    // Auto-Watch Toggle
    if (DOM.btnAutoWatchToggle) {
      DOM.btnAutoWatchToggle.addEventListener('click', toggleAutoWatch);
    }

    // Kill Switch Button
    if (DOM.btnKillSwitch) {
      DOM.btnKillSwitch.addEventListener('click', () => {
        openModal(DOM.modalKill);
      });
    }

    // Purge & Wipe Myra Memory
    if (DOM.btnPurgeMyraMemory) {
      DOM.btnPurgeMyraMemory.addEventListener('click', () => {
        if (confirm("Kya aap sach mein Myra ki saari yaadein aur data delete karke completely reset karna chahte hain?")) {
          vibrateDevice(80);
          localStorage.clear();
          if (window.AndroidBridge && window.AndroidBridge.wipeAllData) {
            window.AndroidBridge.wipeAllData();
          }
          if (window.speechSynthesis) window.speechSynthesis.cancel();
          closeModal(DOM.modalKill);
          showToast("Myra memory wiped. Resetting...");
          setSpeechResponse("Saara data wipe ho gaya hai dost. Alvida, phir milenge ❤️", "RESET");
          setTimeout(() => {
            window.location.reload();
          }, 900);
        }
      });
    }

    // Force Kill & Exit App
    if (DOM.btnForceKillExit) {
      DOM.btnForceKillExit.addEventListener('click', () => {
        vibrateDevice(90);
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        if (state.cameraStream) {
          state.cameraStream.getTracks().forEach(t => t.stop());
        }
        showToast("Terminating Myra...");
        setTimeout(() => {
          if (window.AndroidBridge && window.AndroidBridge.killApp) {
            window.AndroidBridge.killApp();
          } else {
            window.close();
          }
        }, 350);
      });
    }
  }

  // Initialize
  window.addEventListener('DOMContentLoaded', () => {
    initGalaxyCanvas();
    setupEventListeners();
    initSpeechRec();

    if (state.isAutonomous) {
      DOM.autoToggleBtn.classList.add('active');
      setStatus("AUTONOMOUS", true);
    }

    setTimeout(updateCircuitPaths, 150);
    setTimeout(updateCircuitPaths, 500);
    window.addEventListener('load', updateCircuitPaths);
  });

})();
