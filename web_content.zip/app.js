(function () {
  "use strict";
  const KEY = "inv_state_v1";
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = (v) => (v < 0 ? "-$" : "$") + Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const qf = (v) => String(Math.round(v * 1e6) / 1e6);
  const today = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);

  // ---------- state ----------
  let state;
  try { state = JSON.parse(localStorage.getItem(KEY)) || Core.newState(); } catch (e) { state = Core.newState(); }
  Core.ensureState(state);
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); }
    catch (e) { toast("Could not save - storage is full. Export a backup."); }
  }
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist();

  const canShareFiles = !!(navigator.canShare && (() => { try { return navigator.canShare({ files: [new File(["x"], "a.pdf", { type: "application/pdf" })] }); } catch (e) { return false; } })());

  // ---------- helpers ----------
  let toastT;
  function toast(msg) {
    const t = $("toast"); t.textContent = msg; t.classList.add("on");
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("on"), 2600);
  }
  function seg(id, onChange) {
    const el = $(id);
    el.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      el.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
      onChange && onChange(b.dataset.v);
    });
  }
  const segVal = (id) => $(id).querySelector("button.on").dataset.v;
  const segSet = (id, v) => $(id).querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
  function download(name, text, type) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(text instanceof Blob ? text : new Blob([text], { type: type || "text/plain" }));
    a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }

  // ---------- camera scanning ----------
  function scanCamera() {
    return new Promise(async (resolve) => {
      if (!navigator.mediaDevices || !("BarcodeDetector" in window)) {
        toast("Camera scanning isn't supported in this browser. Type the code or use a scanner.");
        return resolve(null);
      }
      let stream, timer, done = false;
      const cam = $("cam"), video = $("camVideo");
      const finish = (val) => {
        if (done) return; done = true;
        clearInterval(timer);
        if (stream) stream.getTracks().forEach((t) => t.stop());
        video.srcObject = null; cam.classList.remove("on"); resolve(val);
      };
      $("camCancel").onclick = () => finish(null);
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
        video.srcObject = stream; await video.play(); cam.classList.add("on");
        const det = new BarcodeDetector({ formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39"] });
        timer = setInterval(async () => {
          try {
            const r = await det.detect(video);
            if (r.length) { if (navigator.vibrate) navigator.vibrate(60); finish(r[0].rawValue); }
          } catch (e) { /* keep trying */ }
        }, 200);
      } catch (e) {
        toast("Couldn't open the camera. Allow camera permission and try again.");
        finish(null);
      }
    });
  }

  // ---------- tabs ----------
  let curTab = "sales", hlId = null, curBarcode = null;
  function showTab(t) {
    curTab = t;
    document.querySelectorAll(".tab").forEach((s) => s.classList.toggle("on", s.id === "t-" + t));
    $("nav").querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.t === t));
    $("fab").style.display = t === "items" ? "block" : "none";
    renderAll();
  }
  $("nav").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) { hlId = null; showTab(b.dataset.t); } });

  // ---------- drop-down lists and item search (name / SKU / barcode) ----------
  function refreshLists() {
    $("agentList").innerHTML = Core.agentNames(state).map((a) => '<option value="' + esc(a) + '">').join("");
    $("custList").innerHTML = [...new Set(state.invoices.map((i) => i.customer).filter(Boolean))].map((x) => '<option value="' + esc(x) + '">').join("");
  }
  function suggest(listEl, q) {
    q = q.trim(); if (q.length < 2) { listEl.innerHTML = ""; return []; }
    const rows = Core.searchItems(state, q).slice(0, 8);
    listEl.innerHTML = rows.length ? '<div class="sug">' + rows.map((r) => '<div class="s" data-bc="' + esc(r.barcode) + '"><span><b>' + esc(r.name) + '</b><div class="sub">' + esc(r.sku) + " · " + esc(r.barcode) +
      '</div></div><span class="sub">' + qf(r.on_hand) + " in stock</span></div>").join("") + "</div>" : "";
    return rows;
  }
  // Typing a name shows matches; Enter picks an exact barcode or a single match; tap a match to choose it.
  function bindFinder(inputId, listId, onPick, onMissing) {
    const inp = $(inputId), list = $(listId);
    const resolve = () => {
      const code = inp.value.trim(); if (!code) return;
      const it = Core.findItem(state, code); if (it) { list.innerHTML = ""; return onPick(it.barcode); }
      const rows = Core.searchItems(state, code);
      if (rows.length === 1) { list.innerHTML = ""; return onPick(rows[0].barcode); }
      if (rows.length) return suggest(list, code);
      onMissing && onMissing(code);
    };
    inp.addEventListener("input", () => { if (Core.findItem(state, inp.value)) list.innerHTML = ""; else suggest(list, inp.value); });
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); resolve(); } });
    list.addEventListener("click", (e) => { const s = e.target.closest("[data-bc]"); if (s) { list.innerHTML = ""; onPick(s.dataset.bc); } });
  }

  // ---------- SALES tab: scan / search, current sale, sales and returns ----------
  const OVK = ["price", "cash", "bulk", "commission"];
  const chipOf = (inv) => (inv.status === "void" ? "Void" : Core.returnedTotal(state, inv.id) ? "Returned" : inv.payment === "Cash" ? "Paid" : "Due");
  function syncCartInputs() {
    const c = state.cart, set = (id, v) => { const el = $(id); if (document.activeElement !== el) el.value = v == null ? "" : v; };
    set("cuName", c.customer); set("cuNote", c.note); set("sAgent", c.agent);
    for (const k of OVK) { set("ov_" + k, c.ov[k].v); set("ovk_" + k, c.ov[k].k); }
    segSet("sPay", c.payment);
  }
  seg("sPay", (v) => { state.cart.payment = v; save(); renderResult(); renderSale(true); });
  $("sQty").addEventListener("input", () => renderResult());
  $("cuName").addEventListener("input", () => { state.cart.customer = $("cuName").value; save(); });
  $("cuNote").addEventListener("input", () => { state.cart.note = $("cuNote").value; save(); });
  $("sAgent").addEventListener("input", () => { state.cart.agent = $("sAgent").value; save(); });
  for (const k of OVK) {
    $("ov_" + k).addEventListener("input", () => { state.cart.ov[k].v = $("ov_" + k).value; save(); renderSale(true); });
    $("ovk_" + k).addEventListener("change", () => { state.cart.ov[k].k = $("ovk_" + k).value; save(); renderSale(true); });
  }
  bindFinder("sBarcode", "sFind", (bc) => pick(bc), (code) => renderResult(code));
  $("sCam").onclick = async () => { const c = await scanCamera(); if (!c) return; const it = Core.findItem(state, c); if (it) pick(it.barcode); else { $("sBarcode").value = c; renderResult(c); } };

  function renderResult(missing) {
    const out = $("sResult");
    if (missing) { out.innerHTML = '<div class="card"><div class="msg bad">&ldquo;' + esc(missing) + '&rdquo; was not found. Check the code, or add the item on the Items tab.</div></div>'; return; }
    const item = curBarcode ? Core.findItem(state, curBarcode) : null;
    if (!item) { out.innerHTML = '<div class="card sub">Scan or search an item to see its cost, discounts, commission and profit.</div>'; return; }
    const qty = Number($("sQty").value), pay = state.cart.payment, row = Core.stockRows(state, "").find((r) => r.barcode === item.barcode);
    let h = '<div class="card"><div class="msg ok">Item found</div><div class="itemname">' + esc(item.name) + '</div><div class="sub">' + esc(item.sku) + (item.category ? " · " + esc(item.category) : "") +
      '</div><div style="margin-top:8px">On hand: <b>' + qf(row.on_hand) + '</b> <span class="chip ' + (row.status === "Out of Stock" ? "Out" : row.status) + '">' + row.status + "</span></div>";
    if (!(qty > 0)) { out.innerHTML = h + '<div class="msg bad" style="margin-top:10px">Enter a valid quantity.</div></div>'; return; }
    const r = Core.calcSale(item, qty, pay);
    const rows = [["cost", "Purchase price (cost)"], ["list", "Sales value (list)"], ["cash", "Cash discount"], ["bulk", "Bulk discount"], ["net", "Net sales value"], ["commission", "Agent commission"]];
    h += '<table class="pb"><tr><th></th><th>Per unit</th><th>For qty</th></tr>';
    for (const [k, lab] of rows) h += "<tr><td>" + lab + "</td><td>" + money(r.unit[k]) + "</td><td>" + money(r.total[k]) + "</td></tr>";
    h += '<tr class="profit"><td>PROFIT</td><td>' + money(r.unit.profit) + "</td><td>" + money(r.total.profit) + "</td></tr></table>";
    h += '<div class="note">The item\'s own settings. Margin ' + (r.margin * 100).toFixed(1) + "% of net sales · Cash discount: " + (r.cashApplied ? "applied" : "not applied (credit)") +
      " · Bulk discount: " + (r.bulkApplied ? "applied" : "needs " + qf(item.bulk_min) + "+ units") + ". Use the manual boxes in Current sale to change them.</div>";
    out.innerHTML = h + '<div style="margin-top:14px"><button class="btn" id="addBtn">Add to sale</button></div></div>';
    $("addBtn").onclick = addToSale;
  }
  function pick(barcode) {
    curBarcode = barcode; $("sBarcode").value = ""; $("sFind").innerHTML = "";
    renderResult();
    if ($("sAuto").checked) addToSale();
  }
  function addToSale() {
    const item = curBarcode ? Core.findItem(state, curBarcode) : null; if (!item) return toast("Scan or search an item first.");
    const qty = Number($("sQty").value); if (!(qty > 0)) return toast("Enter a quantity greater than zero.");
    const c = state.cart, ln = c.lines.find((l) => l.barcode === item.barcode);
    if (ln) ln.qty += qty; else c.lines.push({ barcode: item.barcode, qty });
    $("sQty").value = "1"; save(); renderResult(); renderSale(true); toast("Added: " + qf(qty) + " × " + item.name);
  }
  function renderSale(keepInputs) {
    const c = state.cart; if (!keepInputs) syncCartInputs();
    $("saleCount").textContent = c.lines.length ? c.lines.length + (c.lines.length === 1 ? " item" : " items") : "";
    if (!c.lines.length) { $("saleLines").innerHTML = '<div class="sub" style="padding:10px 0">No items in the sale yet. Scan or search an item to start.</div>'; $("saleTot").innerHTML = ""; renderCartBar(); return; }
    const tax = Number(state.settings.tax_rate) || 0; let t = null, err = "";
    try { t = Core.priceLines(state, c.lines, c.payment, tax, Core.parseOverrides(c.ov)); }
    catch (e) { err = e.message; try { t = Core.priceLines(state, c.lines, c.payment, tax); } catch (e2) { err = e2.message; } }
    if (!t) { $("saleLines").innerHTML = ""; $("saleTot").innerHTML = '<div class="msg bad">' + esc(err) + "</div>"; return; }
    $("saleLines").innerHTML = '<div class="list">' + t.lines.map((l, i) =>
      '<div class="it" style="align-items:flex-start"><div style="flex:1"><b>' + esc(l.name) + '</b><div class="sub">' + money(l.unit) + " each" + (l.disc ? " · discount " + money(l.disc) : "") +
      (l.qty > l.onHand ? ' · <span style="color:var(--red)">only ' + qf(l.onHand) + " in stock</span>" : "") + '</div></div><div class="right"><div class="stepper"><button data-q="-1" data-i="' + i +
      '">−</button><input data-qi="' + i + '" type="number" inputmode="decimal" min="0" step="any" value="' + qf(l.qty) + '"><button data-q="1" data-i="' + i + '">+</button></div><div><b>' + money(l.amount) +
      '</b></div><div><button class="btn danger" style="padding:4px 10px;font-size:12px;margin-top:4px" data-rm="' + i + '">Remove</button></div></div></div>').join("") + "</div>";
    $("saleTot").innerHTML = err ? '<div class="msg bad" style="margin-top:8px">' + esc(err) + "</div>" :
      '<div class="tot" style="margin-top:8px"><span>Subtotal</span><span>' + money(t.subtotal) + '</span></div><div class="tot"><span>Discounts</span><span>' + (t.discounts ? "-" : "") + money(t.discounts) + "</span></div>" +
      (t.tax ? '<div class="tot"><span>Tax (' + tax + '%)</span><span>' + money(t.tax) + "</span></div>" : "") + '<div class="tot big"><span>TOTAL</span><span>' + money(t.total) + '</span></div><div class="sub">Agent commission ' + money(t.commission) + " (not shown to the customer)</div>";
    renderCartBar();
  }
  $("saleLines").addEventListener("click", (e) => {
    const c = state.cart, q = e.target.closest("[data-q]"), r = e.target.closest("[data-rm]");
    if (q) { const ln = c.lines[Number(q.dataset.i)]; ln.qty = Math.max(1, Number(ln.qty) + Number(q.dataset.q)); save(); renderSale(true); }
    if (r) { c.lines.splice(Number(r.dataset.rm), 1); save(); renderSale(true); }
  });
  $("saleLines").addEventListener("change", (e) => { const inp = e.target.closest("[data-qi]"); if (!inp) return; const v = Number(inp.value); if (v > 0) state.cart.lines[Number(inp.dataset.qi)].qty = v; save(); renderSale(true); });
  $("cuClear").onclick = () => { if (!state.cart.lines.length && !OVK.some((k) => state.cart.ov[k].v)) return; if (confirm("Clear this sale?")) { const a = state.cart.agent; state.cart = Core.newCart(); state.cart.agent = a; save(); renderSale(); } };
  function renderCartBar() {
    const bar = $("cartBar"), n = state.cart.lines.length;
    if (!n || curTab !== "sales" || $("ov").classList.contains("on")) { bar.style.display = "none"; return; }
    let t = null; try { t = Core.priceLines(state, state.cart.lines, state.cart.payment, Number(state.settings.tax_rate) || 0, Core.parseOverrides(state.cart.ov)); } catch (e) { /* shown in the sale card */ }
    bar.style.display = "flex";
    bar.innerHTML = "<div><b>Sale: " + n + (n === 1 ? " item" : " items") + '</b><div class="sub" style="color:#cfe0ff">' + (t ? money(t.total) : "") + '</div></div><button class="btn" id="cartOpen">Go to sale</button>';
    $("cartOpen").onclick = () => $("saleCard").scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function recordSale() {
    const c = state.cart; if (!c.lines.length) return toast("Add at least one item to the sale first.");
    const tax = Number(state.settings.tax_rate) || 0; let ov, t;
    try { ov = Core.parseOverrides(c.ov); t = Core.priceLines(state, c.lines, c.payment, tax, ov); } catch (e) { return toast(e.message); }
    const low = t.lines.filter((l) => l.qty > l.onHand);
    if (low.length && !confirm("More than the stock on hand (" + low.map((l) => l.name).join(", ") + "). Record the sale anyway?")) return;
    let inv; try { inv = Core.createInvoice(state, { date: today(), customer: c.customer, payment: c.payment, agent: c.agent, note: c.note, lines: c.lines, overrides: ov }); } catch (e) { return toast(e.message); }
    const agent = c.agent, pay = c.payment; state.cart = Core.newCart(); state.cart.agent = Core.canonicalAgent(state, agent); state.cart.payment = pay;
    curBarcode = null; save(); renderAll(); showDone(inv);
  }
  $("cuDone").onclick = recordSale;

  // ---------- documents (print / share) ----------
  const docOf = (kind, obj) => (kind === "return" ? Core.returnDoc(state, obj) : Core.invoiceDoc(state, obj));
  function docFile(kind, obj, fmt) {
    const bytes = PDF.buildInvoice(docOf(kind, obj), fmt);
    return { blob: new Blob([bytes], { type: "application/pdf" }), name: obj.number + (fmt === "receipt" ? "_receipt80.pdf" : "_A4.pdf"), title: obj.number };
  }
  async function shareFile(r) { try { await navigator.share({ files: [new File([r.blob], r.name, { type: "application/pdf" })], title: r.title }); } catch (e) { /* cancelled */ } }
  function docButtons(kind, obj) {
    const a4 = kind === "return" ? "Return receipt (A4)" : obj.payment === "Cash" ? "Receipt (A4)" : "Invoice (A4)";
    return '<div class="row" style="margin-top:12px"><button class="btn" data-doc="a4">' + a4 + '</button><button class="btn sec" data-doc="receipt">Receipt 80 mm</button></div>' +
      (canShareFiles ? '<div class="row" style="margin-top:8px"><button class="btn sec" data-doc="share-a4">Share A4</button><button class="btn sec" data-doc="share-receipt">Share receipt</button></div>' : "");
  }
  function wireDocButtons(kind, obj) {
    $("sheet").querySelectorAll("[data-doc]").forEach((b) => {
      b.onclick = () => { const k = b.dataset.doc, share = k.startsWith("share-"), r = docFile(kind, obj, k.replace("share-", "")); if (share) shareFile(r); else { download(r.name, r.blob); toast("Saved " + r.name); } };
    });
  }
  function showDone(inv) {
    const word = inv.payment === "Cash" ? "receipt" : "invoice";
    $("sheet").innerHTML = '<h3>Sale recorded</h3><div class="card"><div class="msg ok">' + esc(inv.number) + ' saved. Stock updated.</div><div class="tot big"><span>Total</span><span>' + money(inv.total) + '</span></div><div class="sub">' +
      esc(inv.customer || "Walk-in customer") + " · " + inv.payment + '</div></div><div style="font-weight:700;margin-top:6px">Do you want to print the ' + word + "?</div>" + docButtons("invoice", inv) +
      '<div style="margin-top:12px"><button class="btn sec" id="dnClose">Not now</button></div>';
    $("ov").classList.add("on"); wireDocButtons("invoice", inv); $("dnClose").onclick = () => { closeSheet(); renderCartBar(); };
  }
  function openInvoice(id) {
    const inv = state.invoices.find((i) => i.id === id); if (!inv) return;
    const chip = chipOf(inv), rets = state.returns.filter((r) => r.invoice_id === id), can = inv.status === "ok" && Core.returnCandidates(state, id).some((x) => x.remaining > 0);
    $("sheet").innerHTML = "<h3>" + esc(inv.number) + ' <span class="chip ' + chip + '">' + chip + '</span></h3><div class="sub">' + esc(inv.date) + " · " + esc(inv.customer || "Walk-in customer") + " · " + inv.payment + (inv.agent ? " · " + esc(inv.agent) : "") + "</div>" +
      '<div class="card list" style="margin-top:10px">' + inv.lines.map((l) => '<div class="it"><div><b>' + esc(l.name) + '</b><div class="sub">' + qf(l.qty) + " × " + money(l.unit) + (l.disc ? " · discount " + money(l.disc) : "") + (l.returned ? " · returned " + qf(l.returned) : "") + '</div></div><b>' + money(l.amount) + "</b></div>").join("") + "</div>" +
      '<div class="card"><div class="tot"><span>Subtotal</span><span>' + money(inv.subtotal) + '</span></div><div class="tot"><span>Discounts</span><span>' + money(inv.discounts) + "</span></div>" + (inv.tax ? '<div class="tot"><span>Tax</span><span>' + money(inv.tax) + "</span></div>" : "") +
      '<div class="tot big"><span>TOTAL</span><span>' + money(inv.total) + "</span></div></div>" +
      (rets.length ? '<div class="sub">Returns: ' + rets.map((r) => '<a href="#" data-ret="' + r.id + '">' + esc(r.number) + (r.status === "void" ? " (void)" : " " + money(r.total)) + "</a>").join(", ") + "</div>" : "") +
      docButtons("invoice", inv) + '<div class="row" style="margin-top:12px">' + (can ? '<button class="btn sec" id="ivRet">Sales return</button>' : "") + (inv.status === "ok" ? '<button class="btn danger" id="ivVoid">Void sale</button>' : "") + '</div><div style="margin-top:8px"><button class="btn sec" id="ivClose">Close</button></div>';
    $("ov").classList.add("on"); wireDocButtons("invoice", inv); $("ivClose").onclick = closeSheet;
    $("sheet").querySelectorAll("[data-ret]").forEach((a) => a.onclick = (e) => { e.preventDefault(); openReturn(Number(a.dataset.ret)); });
    if (can) $("ivRet").onclick = () => openReturnForm(id);
    if (inv.status === "ok") $("ivVoid").onclick = () => {
      if (!confirm("Void " + inv.number + "? Its items go back into stock and it is removed from the sales reports.")) return;
      Core.voidInvoice(state, inv.id); save(); closeSheet(); renderAll(); toast(inv.number + " voided");
    };
  }
  function openReturnForm(invId) {
    const inv = state.invoices.find((i) => i.id === invId), cands = Core.returnCandidates(state, invId);
    $("sheet").innerHTML = "<h3>Sales return · " + esc(inv.number) + '</h3><div class="sub">' + esc(inv.customer || "Walk-in customer") + " · " + esc(inv.date) + "</div>" +
      '<div class="card list" style="margin-top:10px">' + cands.map((l) => '<div class="it"><div style="flex:1"><b>' + esc(l.name) + '</b><div class="sub">Sold ' + qf(l.sold) + " · returned " + qf(l.returned) + " · can return " + qf(l.remaining) +
        '</div></div><div class="right"><input data-rq="' + l.idx + '" type="number" inputmode="decimal" min="0" max="' + l.remaining + '" step="any" value="0" style="width:78px;text-align:center"></div></div>').join("") + "</div>" +
      '<label>Reason (optional)</label><input id="rtReason" autocomplete="off"><div class="msg" id="rtPrev" style="margin-top:10px"></div>' +
      '<div class="row" style="margin-top:8px"><button class="btn sec" id="rtAll">Return all remaining</button><button class="btn" id="rtGo">Record return</button></div><div style="margin-top:8px"><button class="btn sec" id="rtCancel">Cancel</button></div>';
    $("ov").classList.add("on");
    const vals = () => [...$("sheet").querySelectorAll("[data-rq]")].map((i) => [Number(i.dataset.rq), Number(i.value) || 0]);
    const preview = () => { let net = 0; for (const [idx, q] of vals()) { const l = inv.lines[idx]; if (q > 0 && l.qty) net += (l.amount * q) / l.qty; } $("rtPrev").textContent = "Refund to the customer (approx.): " + money(net + (net * (inv.tax_rate || 0)) / 100); };
    $("sheet").querySelectorAll("[data-rq]").forEach((i) => i.addEventListener("input", preview)); preview();
    $("rtAll").onclick = () => { cands.forEach((l) => { $("sheet").querySelector('[data-rq="' + l.idx + '"]').value = l.remaining; }); preview(); };
    $("rtCancel").onclick = () => openInvoice(invId);
    $("rtGo").onclick = () => {
      let ret; try { ret = Core.createReturn(state, invId, vals(), $("rtReason").value); } catch (e) { return toast(e.message); }
      save(); renderAll(); showReturnDone(ret);
    };
  }
  function showReturnDone(ret) {
    $("sheet").innerHTML = '<h3>Return recorded</h3><div class="card"><div class="msg ok">' + esc(ret.number) + " for " + esc((state.invoices.find((i) => i.id === ret.invoice_id) || {}).number) + '. Stock updated.</div><div class="tot big"><span>Refund</span><span>' + money(ret.total) +
      '</span></div></div><div style="font-weight:700;margin-top:6px">Do you want to print the return receipt?</div>' + docButtons("return", ret) + '<div style="margin-top:12px"><button class="btn sec" id="dnClose">Not now</button></div>';
    $("ov").classList.add("on"); wireDocButtons("return", ret); $("dnClose").onclick = closeSheet;
  }
  function openReturn(id) {
    const ret = state.returns.find((r) => r.id === id); if (!ret) return;
    const inv = state.invoices.find((i) => i.id === ret.invoice_id) || {};
    $("sheet").innerHTML = "<h3>" + esc(ret.number) + ' <span class="chip ' + (ret.status === "void" ? "Void" : "Ret") + '">' + (ret.status === "void" ? "Void" : "Return") + '</span></h3><div class="sub">' + esc(ret.date) + " · of " + esc(inv.number) + " · " + esc(inv.customer || "Walk-in customer") + (ret.reason ? " · " + esc(ret.reason) : "") + "</div>" +
      '<div class="card list" style="margin-top:10px">' + ret.lines.map((l) => '<div class="it"><div><b>' + esc(l.name) + '</b><div class="sub">' + qf(l.qty) + " × " + money(l.unit) + '</div></div><b>' + money(l.amount) + "</b></div>").join("") + "</div>" +
      '<div class="card"><div class="tot big"><span>Refund</span><span>' + money(ret.total) + "</span></div></div>" + docButtons("return", ret) +
      '<div class="row" style="margin-top:12px"><button class="btn sec" id="ivClose">Close</button>' + (ret.status === "ok" ? '<button class="btn danger" id="rtVoid">Void return</button>' : "") + "</div>";
    $("ov").classList.add("on"); wireDocButtons("return", ret); $("ivClose").onclick = closeSheet;
    if (ret.status === "ok") $("rtVoid").onclick = () => { if (!confirm("Void " + ret.number + "? The goods leave the stock again and the sale counts as it did before the return.")) return; Core.voidReturn(state, ret.id); save(); closeSheet(); renderAll(); toast(ret.number + " voided"); };
  }
  function renderSalesList() {
    const q = $("vSearch").value.trim().toLowerCase(), invNo = Object.fromEntries(state.invoices.map((i) => [i.id, i]));
    const rows = [];
    for (const i of state.invoices) if (!q || i.number.toLowerCase().includes(q) || (i.customer || "").toLowerCase().includes(q)) rows.push({ k: [i.date, i.id], html: '<div class="it" data-inv="' + i.id + '"><div><b>' + esc(i.number) + " · " + esc(i.customer || "Walk-in") + '</b><div class="sub">' + esc(i.date) + " · " + i.lines.length + (i.lines.length === 1 ? " item" : " items") + '</div></div><div class="right"><b>' + money(i.total) + '</b><div><span class="chip ' + chipOf(i) + '">' + chipOf(i) + "</span></div></div></div>" });
    for (const r of state.returns) { const inv = invNo[r.invoice_id] || {}; if (!q || r.number.toLowerCase().includes(q) || (inv.number || "").toLowerCase().includes(q) || (inv.customer || "").toLowerCase().includes(q)) rows.push({ k: [r.date, r.id], html: '<div class="it" data-retid="' + r.id + '"><div><b>' + esc(r.number) + " · return of " + esc(inv.number) + '</b><div class="sub">' + esc(r.date) + " · " + esc(inv.customer || "Walk-in") + '</div></div><div class="right"><b>' + money(-r.total) + '</b><div><span class="chip ' + (r.status === "void" ? "Void" : "Ret") + '">' + (r.status === "void" ? "Void" : "Return") + "</span></div></div></div>" }); }
    rows.sort((a, b) => (a.k[0] < b.k[0] ? 1 : a.k[0] > b.k[0] ? -1 : b.k[1] - a.k[1]));
    $("vList").innerHTML = rows.length ? rows.map((r) => r.html).join("") : '<div class="sub">No sales yet. Scan items, then tap <b>Record sale</b>.</div>';
  }
  $("vSearch").addEventListener("input", renderSalesList);
  $("vList").addEventListener("click", (e) => { const a = e.target.closest("[data-inv]"), b = e.target.closest("[data-retid]"); if (a) openInvoice(Number(a.dataset.inv)); else if (b) openReturn(Number(b.dataset.retid)); });

  // ---------- STOCK tab ----------
  $("kDate").value = today();
  seg("kType", (v) => { $("kOutOnly").style.display = v === "OUT" ? "block" : "none"; });
  seg("kPay");
  $("kOutOnly").style.display = "none";
  function showKName() {
    const code = $("kBarcode").value.trim(), it = Core.findItem(state, code);
    $("kName").textContent = it ? it.name + " (" + it.sku + ")" : code ? "Barcode not found" : "";
  }
  $("kBarcode").addEventListener("input", showKName);
  bindFinder("kBarcode", "kFind", (bc) => { $("kBarcode").value = bc; $("kFind").innerHTML = ""; showKName(); $("kQty").focus(); $("kQty").select(); }, () => showKName());
  $("kCam").onclick = async () => { const c = await scanCamera(); if (c) { $("kBarcode").value = c; $("kFind").innerHTML = ""; showKName(); } };
  $("kAdd").onclick = () => {
    const type = segVal("kType"), code = $("kBarcode").value.trim(), qty = Number($("kQty").value), item = Core.findItem(state, code);
    if (item && type === "OUT" && qty > Core.onHand(state, item.barcode) && !confirm("Quantity is more than the stock on hand. Record anyway?")) return;
    try {
      Core.record(state, { date: $("kDate").value || today(), barcode: code, type, payment: segVal("kPay"), agent: $("kAgent").value.trim(), note: $("kNote").value.trim(), qty });
    } catch (e) { return toast(e.message); }
    save(); toast("Entry added");
    $("kBarcode").value = ""; $("kQty").value = "1"; $("kNote").value = ""; showKName(); renderStock();
  };
  function renderStock() {
    const names = Object.fromEntries(state.items.map((i) => [i.barcode, i.name]));
    const rows = state.log.slice().sort((a, b) => (b.date + String(b.id).padStart(9, "0")).localeCompare(a.date + String(a.id).padStart(9, "0"))).slice(0, 60);
    $("kList").innerHTML = rows.length ? rows.map((e) =>
      '<div class="it"><div><b>' + esc(names[e.barcode] || e.barcode) + '</b><div class="sub">' + esc(e.date) + " · " + e.type + (e.type === "OUT" ? " · " + esc(e.payment) : "") +
      (e.agent ? " · " + esc(e.agent) : "") + (e.note ? " · " + esc(e.note) : "") + '</div></div><div class="right"><b>' + (e.type === "IN" ? "+" : "−") + qf(e.qty) + "</b>" +
      (e.type === "OUT" ? '<div class="sub">profit ' + money(e.profit) + "</div>" : "") +
      '<div><button class="btn danger" style="padding:4px 10px;font-size:12px;margin-top:4px" data-del="' + e.id + '">Delete</button></div></div></div>').join("")
      : '<div class="sub">No entries yet.</div>';
  }
  $("kList").addEventListener("click", (e) => {
    const b = e.target.closest("[data-del]"); if (!b) return;
    const ent = state.log.find((x) => x.id === Number(b.dataset.del));
    if (ent && ent.invoice_id) { const iv = state.invoices.find((i) => i.id === ent.invoice_id); return toast("This entry belongs to " + (iv ? iv.number : "a sale") + ". Void the sale (or the return) on the Sales tab instead."); }
    if (confirm("Delete this entry?")) { Core.deleteLog(state, Number(b.dataset.del)); save(); renderAll(); }
  });

  // ---------- ITEMS tab ----------
  $("iSearch").addEventListener("input", () => { hlId = null; renderItems(); });
  function renderItems() {
    const rows = Core.stockRows(state, $("iSearch").value);
    $("iList").innerHTML = rows.length ? rows.map((r) =>
      '<div class="it' + (hlId === r.id ? " hl" : "") + '" data-id="' + r.id + '"><div><b>' + esc(r.name) + '</b><div class="sub">' + esc(r.sku) + " · " + esc(r.barcode) + '</div><div class="sub">Cost ' + money(r.purchase_price) +
      " · Price " + money(r.selling_price) + '</div></div><div class="right"><b>' + qf(r.on_hand) + '</b><div><span class="chip ' + (r.status === "Out of Stock" ? "Out" : r.status) + '">' + r.status + "</span></div></div></div>").join("")
      : '<div class="sub">No items yet. Tap + to add one, or import from the ⋮ menu.</div>';
  }
  $("iList").addEventListener("click", (e) => { const it = e.target.closest("[data-id]"); if (it) openItem(Number(it.dataset.id)); });
  $("fab").onclick = () => openItem(null);

  const FIELDS = [["sku", "SKU", "text"], ["barcode", "Barcode (EAN-13)", "barcode"], ["name", "Item name", "text"], ["category", "Category", "text"],
    ["supplier", "Supplier", "text"], ["location", "Location", "text"], ["purchase_price", "Purchase price ($)", "num"], ["selling_price", "Selling price ($)", "num"],
    ["cash_disc", "Cash discount", "rate"], ["bulk_disc", "Bulk discount", "rate"], ["bulk_min", "Bulk min quantity", "num"],
    ["commission", "Agent commission", "rate"], ["reorder_level", "Reorder level", "num"], ["reorder_qty", "Reorder quantity", "num"]];

  function drawEAN(canvas, code) {
    const bits = Core.ean13Bits(code), note = $("bcNote");
    if (!bits) { canvas.style.display = "none"; note.textContent = code ? "Not a valid EAN-13 (13 digits, correct check digit) - no image preview, but it can still be used if it's scannable." : ""; return; }
    canvas.style.display = "block"; note.textContent = "";
    const m = 3, q = 30, h = 100, ctx = canvas.getContext("2d");
    canvas.width = bits.length * m + 2 * q; canvas.height = h + 36;
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = "#000";
    for (let i = 0; i < bits.length; i++) if (bits[i] === "1") {
      const guard = i < 3 || (i >= 45 && i < 50) || i >= 92;
      ctx.fillRect(q + i * m, 5, m, h + (guard ? 3 : -5));
    }
    ctx.font = "22px monospace"; ctx.textBaseline = "top";
    ctx.fillText(code[0], q - 20, h + 8); ctx.fillText(code.slice(1, 7), q + 3 * m + 2, h + 8); ctx.fillText(code.slice(7), q + 50 * m + 2, h + 8);
  }

  function openItem(id) {
    const it = id == null ? null : state.items.find((i) => i.id === id);
    let h = "<h3>" + (it ? "Edit item" : "Add item") + "</h3>";
    for (const [k, lab, type] of FIELDS) {
      let v = it ? it[k] : (k === "bulk_min" ? 1 : k === "barcode" ? Core.nextInternalBarcode(state.items) : "");
      if (type === "rate") {
        const kind = it ? it[Core.TYPE_FIELDS[k]] || "pct" : "pct";
        if (it && kind === "pct" && v !== "") v = Math.round(v * 1e6) / 1e4;
        h += "<label>" + lab + '</label><div class="ratebox"><input id="f_' + k + '" value="' + esc(v) + '" type="number" inputmode="decimal" min="0" step="any"><select id="ft_' + k + '"><option value="pct"' + (kind === "pct" ? " selected" : "") + '>% (percent)</option><option value="amt"' + (kind === "amt" ? " selected" : "") + ">$ per unit</option></select></div>";
      } else if (type === "barcode") {
        h += "<label>" + lab + '</label><div class="scanrow"><input id="f_barcode" value="' + esc(v) + '" autocomplete="off"><button class="btn icon" id="f_cam">&#128247;</button></div>' +
          '<canvas id="bcCanvas" width="10" height="10"></canvas><div class="note" id="bcNote"></div>' +
          '<div class="row" style="margin-top:6px"><button class="btn sec" id="f_gen">Generate barcode</button><button class="btn sec" id="f_img">Save image</button></div>';
      } else h += "<label>" + lab + '</label><input id="f_' + k + '" value="' + esc(v) + '" ' + (type === "text" ? 'autocomplete="off"' : 'type="number" inputmode="decimal" min="0" step="any"') + ">";
    }
    h += '<div class="note">Percent is taken from the selling price (commission: from the net sale). Fixed amount is dollars per unit sold.</div>';
    h += '<div class="row" style="margin-top:18px"><button class="btn sec" id="f_cancel">Cancel</button><button class="btn" id="f_save">Save</button></div>';
    if (it) h += '<div style="margin-top:10px"><button class="btn danger" id="f_del">Delete item</button></div>';
    $("sheet").innerHTML = h; $("ov").classList.add("on"); $("sheet").scrollTop = 0;
    const redraw = () => drawEAN($("bcCanvas"), $("f_barcode").value.trim());
    $("f_barcode").addEventListener("input", redraw); redraw();
    $("f_gen").onclick = () => { $("f_barcode").value = Core.nextInternalBarcode(state.items); redraw(); };
    $("f_cam").onclick = async () => { const c = await scanCamera(); if (c) { $("f_barcode").value = c; redraw(); } };
    $("f_img").onclick = () => {
      const c = $("bcCanvas"); if (c.style.display === "none") return toast("No barcode image to save.");
      c.toBlob((b) => { const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "barcode_" + $("f_barcode").value.trim() + ".png"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); });
    };
    $("f_cancel").onclick = closeSheet;
    $("f_save").onclick = () => {
      const d = {};
      for (const [k, , type] of FIELDS) {
        const v = $("f_" + k).value;
        if (type === "rate") {
          const kind = $("ft_" + k).value, x = v === "" ? 0 : Number(v);
          if (!(x >= 0)) return toast("Numbers can't be negative.");
          if (kind === "pct" && x > 100) return toast("A percentage can't be more than 100.");
          d[Core.TYPE_FIELDS[k]] = kind; d[k] = kind === "pct" ? x / 100 : x;
        } else d[k] = v;
      }
      try { Core.saveItem(state, d, it ? it.id : null); } catch (e) { return toast(e.message); }
      save(); closeSheet(); renderAll(); toast("Item saved");
    };
    if (it) $("f_del").onclick = () => {
      if (!confirm("Delete this item?")) return;
      try { Core.deleteItem(state, it.id); } catch (e) { return toast(e.message); }
      save(); closeSheet(); renderAll();
    };
  }
  function closeSheet() { $("ov").classList.remove("on"); }
  $("ov").addEventListener("click", (e) => { if (e.target === $("ov")) closeSheet(); });

  // ---------- DASHBOARD (every figure opens the exact list behind it) ----------
  const TILES = [["Stock", [["skus", "Total SKUs", "stock_on_hand", null], ["units", "Units on hand", "stock_on_hand", null], ["stock_value", "Stock value (cost)", "stock_on_hand", null],
      ["reorder", "Need reorder", "reorder", { status: "Reorder" }], ["out", "Out of stock", "reorder", { status: "Out of Stock" }]]],
    ["Sales", [["gross", "Gross sales", "sales", null], ["net", "Net sales", "sales", null], ["cash", "Cash discounts", "discounts", null], ["bulk", "Bulk discounts", "discounts", null],
      ["commission", "Agent commission", "commission", null], ["cogs", "Cost of goods", "by_item", null], ["profit", "TOTAL PROFIT", "by_item", null], ["margin", "Profit margin", "by_item", null]]]];
  function renderDash() {
    const t = Core.totals(state);
    let h = '<div class="sub" style="margin:0 4px 6px">Tap any figure to see the exact items or sales behind it.</div>';
    for (const [title, tiles] of TILES) {
      h += "<h2>" + title + '</h2><div class="stats">' + tiles.map(([k, lab]) => {
        const v = k === "margin" ? (t.margin * 100).toFixed(1) + "%" : ["skus", "units", "reorder", "out"].includes(k) ? qf(t[k]) : money(t[k]);
        return '<div class="stat click' + (k === "profit" ? " big" : "") + '" data-k="' + k + '">' + lab + "<b>" + v + "</b></div>";
      }).join("") + "</div>";
    }
    $("dash").innerHTML = h;
  }
  $("dash").addEventListener("click", (e) => {
    const s = e.target.closest("[data-k]"); if (!s) return;
    for (const [, tiles] of TILES) { const t = tiles.find((x) => x[0] === s.dataset.k); if (t) return openDrill(t[1], t[2], t[3]); }
  });
  const itemForRow = (tb, row) => {
    const heads = tb.cols.map((c) => c.h); let i = heads.indexOf("SKU");
    if (i >= 0 && row[i]) { const it = state.items.find((x) => x.sku === row[i]); if (it) return it; }
    i = heads.indexOf("Item"); if (i >= 0 && row[i]) return state.items.find((x) => x.name === row[i]) || null;
    return null;
  };
  function openInInventory(item) {
    closeSheet(); hlId = item.id; $("iSearch").value = item.sku; showTab("items"); window.scrollTo(0, 0); $("t-items").scrollIntoView();
    toast("Showing " + item.name);
  }
  function openDrill(title, key, opts) {
    const model = Rep.build(state, key, "", "", opts || {});
    let h = "<h3>" + esc(title) + '</h3><div class="sub">' + esc(model.title) + " · " + model.cards.map((c) => esc(c[0]) + ": " + esc(c[1])).join(" · ") + '</div><div class="note">Tap a row to open that item in Items.</div>';
    model.tables.forEach((tb, ti) => {
      h += (tb.heading ? "<h2>" + esc(tb.heading) + "</h2>" : "") + '<div class="scroll"><table class="dt"><tr>' + tb.cols.map((c) => '<th class="' + (c.a === "r" ? "r" : "") + '">' + esc(c.h) + "</th>").join("") + "</tr>";
      tb.rows.forEach((r, ri) => { h += '<tr class="' + (itemForRow(tb, r) ? "go" : "") + '" data-t="' + ti + '" data-r="' + ri + '">' + r.map((v, i) => '<td class="' + (tb.cols[i].a === "r" ? "r" : "") + '">' + esc(v) + "</td>").join("") + "</tr>"; });
      if (tb.rows.length && tb.total) h += '<tr class="t">' + tb.total.map((v, i) => '<td class="' + (tb.cols[i].a === "r" ? "r" : "") + '">' + esc(v) + "</td>").join("") + "</tr>";
      if (!tb.rows.length) h += '<tr><td colspan="' + tb.cols.length + '" class="sub">Nothing to show.</td></tr>';
      h += "</table></div>";
    });
    h += '<div class="row"><button class="btn" id="dlPdf">Create PDF</button>' + (canShareFiles ? '<button class="btn sec" id="dlShare">Share PDF</button>' : "") + '</div><div style="margin-top:8px"><button class="btn sec" id="dlClose">Close</button></div>';
    $("sheet").innerHTML = h; $("ov").classList.add("on"); $("sheet").scrollTop = 0;
    $("sheet").querySelectorAll("tr.go").forEach((tr) => tr.onclick = () => { const tb = model.tables[Number(tr.dataset.t)], it = itemForRow(tb, tb.rows[Number(tr.dataset.r)]); if (it) openInInventory(it); });
    const make = () => { const n = new Date(), p2 = (v) => String(v).padStart(2, "0"); const bytes = PDF.build(model, { business: state.settings.business, generated: today() + " " + p2(n.getHours()) + ":" + p2(n.getMinutes()) }); return { blob: new Blob([bytes], { type: "application/pdf" }), name: key + "_" + today() + ".pdf", title: model.title }; };
    $("dlPdf").onclick = () => { const r = make(); download(r.name, r.blob); toast("Saved " + r.name); };
    if (canShareFiles) $("dlShare").onclick = () => shareFile(make());
    $("dlClose").onclick = closeSheet;
  }

  // ---------- REPORTS tab ----------
  $("rBiz").value = state.settings.business || "";
  $("rBiz").addEventListener("input", () => { state.settings.business = $("rBiz").value.trim(); save(); });
  $("rPresets").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    const [f, t] = Rep.preset(b.dataset.p); $("rFrom").value = f; $("rTo").value = t;
    $("rPresets").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
  });
  const clearPreset = () => $("rPresets").querySelectorAll("button").forEach((x) => x.classList.remove("on"));
  $("rFrom").addEventListener("change", clearPreset); $("rTo").addEventListener("change", clearPreset);
  function renderReports() {
    const cats = [...new Set(state.items.map((i) => i.category).filter(Boolean))].sort(), cur = $("rCat").value;
    $("rCat").innerHTML = '<option value="">All categories</option>' + cats.map((c) => '<option value="' + esc(c) + '">' + esc(c) + "</option>").join("");
    $("rCat").value = cats.includes(cur) ? cur : "";
    $("rShareNote").textContent = state.items.length ? state.items.length + " items in your list." : "No items yet. Import your item list from the menu, or add items on the Items tab.";
    $("rList").innerHTML = Rep.LIST.filter((r) => !r[0].startsWith("barcode")).map((r) => '<div class="rep"><div><b>' + esc(r[1]) + '</b><div class="sub">' + esc(r[2]) + (r[3] ? "" : " (current stock)") + '</div></div><div class="btns">' +
      (canShareFiles ? '<button class="btn sec" data-share="' + r[0] + '">Share</button>' : "") + '<button class="btn" data-pdf="' + r[0] + '">PDF</button></div></div>').join("");
  }
  function makePDF(key) {
    const from = $("rFrom").value, to = $("rTo").value, def = Rep.LIST.find((r) => r[0] === key);
    if (def[3] && from && to && from > to) { toast("The From date is after the To date."); return null; }
    const model = Rep.build(state, key, from, to, { category: $("rCat").value, copies: $("rCopies").value, showPrice: false }), n = new Date(), p2 = (v) => String(v).padStart(2, "0");
    const bytes = PDF.build(model, { business: state.settings.business, generated: today() + " " + p2(n.getHours()) + ":" + p2(n.getMinutes()) });
    const name = key + (def[3] ? "_" + (from || "start") + "_to_" + (to || "today") : "_" + today()) + ".pdf";
    return { blob: new Blob([bytes], { type: "application/pdf" }), name, title: model.title };
  }
  $("t-reports").addEventListener("click", async (e) => {
    const b = e.target.closest("button"); if (!b) return;
    const key = b.dataset.pdf || b.dataset.share; if (!key) return;
    if (key.startsWith("barcode") && !state.items.length) return toast("Import or add items first.");
    const r = makePDF(key); if (!r) return;
    if (b.dataset.share) {
      try { await navigator.share({ files: [new File([r.blob], r.name, { type: "application/pdf" })], title: r.title }); } catch (err) { /* cancelled */ }
    } else { download(r.name, r.blob); toast("Saved " + r.name); }
  });

  // ---------- menu / import / export ----------
  $("menuBtn").onclick = (e) => { e.stopPropagation(); $("menu").classList.toggle("on"); };
  document.addEventListener("click", () => $("menu").classList.remove("on"));
  $("menu").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    const a = b.dataset.act, stamp = today();
    if (a === "expBackup") download("inventory-backup-" + stamp + ".json", JSON.stringify(state), "application/json");
    if (a === "impFile") $("fileIn").click();
    if (a === "biz") openBusiness();
    if (a === "expInv") {
      const rows = Core.stockRows(state, ""), cols = ["sku", "barcode", "name", "category", "supplier", "location", "purchase_price", "selling_price", "cash_disc", "bulk_disc", "bulk_min", "commission", "qty_in", "qty_out", "on_hand", "reorder_level", "reorder_qty", "value", "status", "cash_disc_type", "bulk_disc_type", "commission_type"];
      download("inventory-" + stamp + ".csv", Core.toCSV([cols].concat(rows.map((r) => cols.map((c) => r[c])))), "text/csv");
    }
    if (a === "expLog") {
      const names = Object.fromEntries(state.items.map((i) => [i.barcode, i])), cols = ["date", "sku", "barcode", "name", "type", "payment", "agent", "note", "qty", "gross", "cash_disc", "bulk_disc", "net", "commission", "cogs", "profit"];
      const rows = state.log.slice().sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
      download("sales-log-" + stamp + ".csv", Core.toCSV([cols].concat(rows.map((e) => cols.map((c) => c === "sku" ? (names[e.barcode] || {}).sku : c === "name" ? (names[e.barcode] || {}).name : e[c])))), "text/csv");
    }
  });
  $("fileIn").addEventListener("change", async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    try {
      const text = await f.text();
      if (f.name.toLowerCase().endsWith(".json")) {
        const d = JSON.parse(text);
        if (!d || !Array.isArray(d.items) || !Array.isArray(d.log)) throw new Error("Not a valid backup file.");
        if (!confirm("This replaces ALL data on this phone with the backup (" + d.items.length + " items, " + d.log.length + " log entries). Continue?")) return;
        state = { items: d.items, log: d.log, nextId: d.nextId || 1 + Math.max(0, ...d.items.map((i) => i.id), ...d.log.map((l) => l.id)), settings: d.settings || state.settings, invoices: d.invoices || [], returns: d.returns || [], agents: d.agents || [], cart: Core.newCart() }; Core.ensureState(state);
        $("rBiz").value = state.settings.business || "";
        toast("Backup restored");
      } else {
        const r = Core.importCSV(state, text);
        toast(r.kind === "inventory" ? "Items: " + r.added + " added, " + r.updated + " updated, " + r.skipped + " skipped" + (r.auto ? ". " + r.auto + " new barcodes created" : "") : "Log entries added: " + r.added + ", skipped: " + r.skipped);
      }
      save(); renderAll();
    } catch (err) { toast(err.message || "Import failed"); }
  });

  // ---------- business details (printed on invoices and receipts) ----------
  function openBusiness() {
    const s = state.settings;
    $("sheet").innerHTML = '<h3>Business details for invoices</h3><label>Business name</label><input id="bzName" autocomplete="off" value="' + esc(s.business) + '"><label>Address</label><textarea id="bzAddr" rows="2" placeholder="Street, city">' + esc(s.address) +
      '</textarea><label>Phone</label><input id="bzPhone" autocomplete="off" value="' + esc(s.phone) + '"><div class="row"><div><label>Tax % (0 = none)</label><input id="bzTax" type="number" inputmode="decimal" min="0" step="any" value="' + esc(s.tax_rate || "") +
      '"></div><div><label>Next invoice no.</label><input id="bzNext" type="number" inputmode="numeric" min="1" value="' + esc(s.next_invoice || 1) + '"></div></div><label>Message at the bottom</label><input id="bzFoot" autocomplete="off" value="' + esc(s.footer) + '">' +
      '<div class="row" style="margin-top:16px"><button class="btn sec" id="bzCancel">Cancel</button><button class="btn" id="bzSave">Save</button></div>';
    $("ov").classList.add("on");
    $("bzCancel").onclick = closeSheet;
    $("bzSave").onclick = () => {
      state.settings.business = $("bzName").value.trim(); state.settings.address = $("bzAddr").value.trim(); state.settings.phone = $("bzPhone").value.trim(); state.settings.footer = $("bzFoot").value.trim();
      state.settings.tax_rate = Math.max(0, Number($("bzTax").value) || 0); state.settings.next_invoice = Math.max(1, Math.floor(Number($("bzNext").value)) || 1);
      $("rBiz").value = state.settings.business; save(); closeSheet(); renderAll(); toast("Business details saved");
    };
  }

  // ---------- init ----------
  function renderAll() {
    refreshLists();
    if (curTab === "sales") { renderResult(); renderSale(); renderSalesList(); }
    if (curTab === "stock") { renderStock(); showKName(); }
    if (curTab === "items") renderItems();
    if (curTab === "reports") renderReports();
    if (curTab === "dash") renderDash();
    renderCartBar();
  }
  { const hsh = location.hash.slice(1), legacy = { scan: "sales", invoices: "sales" }, t = legacy[hsh] || hsh; if (["sales", "stock", "items", "reports", "dash"].includes(t)) curTab = t; }
  document.querySelectorAll(".tab").forEach((s) => s.classList.toggle("on", s.id === "t-" + curTab));
  $("nav").querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.t === curTab));
  $("fab").style.display = curTab === "items" ? "block" : "none";
  renderAll();
  if ("serviceWorker" in navigator && /^https:|^http:\/\/localhost/.test(location.href)) {
    navigator.serviceWorker.register("sw.js").then((reg) => {
      reg.addEventListener("updatefound", () => {
        const w = reg.installing; if (!w) return;
        w.addEventListener("statechange", () => { if (w.state === "installed" && navigator.serviceWorker.controller) toast("Update ready. Close and reopen the app to use it."); });
      });
    }).catch(() => {});
  }
})();
