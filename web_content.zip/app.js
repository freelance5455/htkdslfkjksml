const K='coach_v1',$=s=>document.querySelector(s),uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
let db=null;try{db=JSON.parse(localStorage.getItem(K))}catch(e){}
const save=()=>{try{localStorage.setItem(K,JSON.stringify(db))}catch(e){alert('ذخیره‌سازی انجام نشد')}};
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const today=()=>{const d=new Date();return new Date(d-d.getTimezoneOffset()*6e4).toISOString().slice(0,10)};
const fa=d=>d?new Date(d+'T12:00').toLocaleDateString('fa-IR-u-ca-persian',{year:'numeric',month:'long',day:'numeric'}):'';
const N=n=>Number(n).toLocaleString('fa-IR');
const sg=n=>`<span class="${n<0?'neg':'pos'}">${n>0?'+':''}${N(n)}</span>`;
let view='home',arg=null,flt={},keep={};
const T=id=>db.trainees.find(x=>x.id==id),O=id=>db.occasions.find(x=>x.id==id),R=id=>db.reasons.find(x=>x.id==id);
// Total: plain sum (provisional – rules not yet defined by coach)
const total=(id,l=db.scores)=>l.filter(s=>s.tid==id).reduce((a,s)=>a+s.val,0);
const opts=(l,sel,all)=>(all?`<option value="">${all}</option>`:'')+l.map(x=>`<option value="${x.id}" ${x.id==sel?'selected':''}>${esc(x.title||x.name)}${x.active===false?' (غیرفعال)':''}</option>`).join('');

function modal(title,html,ok,okText='ذخیره'){
 const o=document.createElement('div');o.className='ov';
 o.innerHTML=`<div><h3>${title}</h3>${html}<div class="grid"><button id="ok">${okText}</button><button class="s" id="no">انصراف</button></div></div>`;
 document.body.append(o);$('#no').onclick=()=>o.remove();
 $('#ok').onclick=()=>{const v={};o.querySelectorAll('[name]').forEach(e=>v[e.name]=e.type=='checkbox'?e.checked:e.value);if(ok(v)!==false)o.remove()};
}
const go=(v,a)=>{view=v;arg=a;render();scrollTo(0,0)};

function render(){
 if(!db){$('#h').textContent='ایجاد حساب کاربری آفلاین';$('#nav').innerHTML='';
  $('#app').innerHTML=`<div class="card"><p>این برنامه بدون اینترنت کار می‌کند و اطلاعات فقط روی همین گوشی می‌ماند.</p><label>نام گروه تربیتی</label><input id="g"><button id="mk" style="width:100%">شروع</button><p class="m">یا از نسخه پشتیبان بازیابی کنید:</p><input type="file" id="rf" accept=".json"></div>`;
  $('#mk').onclick=()=>{const g=$('#g').value.trim();if(!g)return alert('نام گروه را وارد کنید');
   db={group:g,trainees:[],reasons:[],occasions:[],scores:[]};save();go('home')};
  $('#rf').onchange=restore;return}
 const I=p=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
 const tabs=[['home',I('<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>'),'خانه'],['trainees',I('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14c2.2.6 3.5 2.6 3.5 6"/>'),'متربیان'],['add',I('<path d="M12 5v14M5 12h14"/>'),'ثبت'],['reports',I('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),'گزارش'],['more',I('<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>'),'بیشتر']];
 $('#nav').innerHTML=tabs.map(t=>`<a class="${t[0]=='add'?'fab ':''}${(view==t[0]||(t[0]=='more'&&['occ','rea','export','backup'].includes(view))||(t[0]=='trainees'&&view=='tr'))?'on':''}" onclick="go('${t[0]}')"><b>${t[1]}</b><span>${t[2]}</span></a>`).join('');
 const V={home,trainees,tr,add,reports,more,occ:()=>manage('occasions','مناسبت‌ها'),rea:()=>manage('reasons','دلایل امتیازدهی'),export:exp,backup};
 $('#h').innerHTML=`<small>نرم‌افزار مربی</small>${view!='home'?`<a class="bk" onclick="go('home')">‹</a>`:''}${esc(db.group)}`;$('#app').innerHTML=V[view]();
 if(view=='add')bindAdd();
}
function home(){
 const top=db.trainees.map(t=>[t,total(t.id)]).sort((a,b)=>b[1]-a[1]).slice(0,3);
 return `<div class="grid stats"><div class="card"><div class="m">متربیان</div><h2>${N(db.trainees.length)}</h2></div><div class="card"><div class="m">امتیازهای ثبت‌شده</div><h2>${N(db.scores.length)}</h2></div></div>
 <button style="width:100%;margin-bottom:10px" onclick="go('add')">ثبت امتیاز جدید</button>
 <div class="card"><b>بیشترین مجموع</b>${top.map(([t,n])=>`<div class="row"><span>${esc(t.name)}</span>${sg(n)}</div>`).join('')||'<p class="m">هنوز متربی‌ای اضافه نشده.</p>'}<p class="m">مجموع فعلاً جمع ساده است؛ قواعد نهایی را بعداً مشخص کنید.</p></div>
 <div class="grid"><button class="s" onclick="go('occ')">مناسبت‌ها</button><button class="s" onclick="go('rea')">دلایل امتیازدهی</button><button class="s" onclick="go('export')">خروجی برای والدین</button><button class="s" onclick="go('backup')">پشتیبان‌گیری</button></div>`;
}
function trainees(){
 const q=(flt.q||'').trim();
 const l=db.trainees.filter(t=>t.name.includes(q));
 return `<div class="row"><input placeholder="جست‌وجو…" value="${esc(q)}" oninput="flt.q=this.value;render();document.querySelector('input').focus()"><button onclick="editT()" style="margin-bottom:10px">+</button></div>`+
 (l.map(t=>`<div class="card row tl" onclick="go('tr','${t.id}')"><i class="av">${esc([...t.name][0]||'?')}</i><div style="flex:1"><b>${esc(t.name)}</b><div class="m">${esc(t.info||'')}</div></div>${sg(total(t.id))}</div>`).join('')||'<p class="m">متربی‌ای یافت نشد.</p>');
}
function editT(id){const t=id?T(id):{name:'',info:''};
 modal(id?'ویرایش متربی':'متربی جدید',`<label>نام و نام خانوادگی</label><input name="name" value="${esc(t.name)}"><label>اطلاعات تکمیلی (اختیاری: سن، تلفن والدین…)</label><textarea name="info">${esc(t.info||'')}</textarea>`,v=>{
  if(!v.name.trim()){alert('نام لازم است');return false}
  if(id){t.name=v.name.trim();t.info=v.info}else db.trainees.push({id:uid(),name:v.name.trim(),info:v.info});save();render()});}
function tr(){
 const t=T(arg);if(!t){view='trainees';return trainees()}
 const f=flt;let l=db.scores.filter(s=>s.tid==t.id&&(!f.from||s.date>=f.from)&&(!f.to||s.date<=f.to)&&(!f.o||s.oid==f.o)&&(!f.r||s.rid==f.r)).sort((a,b)=>b.date.localeCompare(a.date));
 return `<div class="card"><div class="row"><div><h3 style="margin:0"><i class="av big">${esc([...t.name][0]||'?')}</i>${esc(t.name)}</h3><div class="m">${esc(t.info||'')}</div></div><h2>${sg(total(t.id))}</h2></div>
 <div class="grid" style="margin-top:8px"><button class="s sm" onclick="editT('${t.id}')">ویرایش</button><button class="d sm" onclick="delT('${t.id}')">حذف متربی</button></div></div>
 <div class="card"><b>فیلتر</b><div class="grid"><div><label>از</label><input type="date" value="${f.from||''}" onchange="flt.from=this.value;render()"></div><div><label>تا</label><input type="date" value="${f.to||''}" onchange="flt.to=this.value;render()"></div>
 <div><label>مناسبت</label><select onchange="flt.o=this.value;render()">${opts(db.occasions,f.o,'همه')}</select></div><div><label>دلیل</label><select onchange="flt.r=this.value;render()">${opts(db.reasons,f.r,'همه')}</select></div></div></div>
 <div class="row" style="margin-bottom:8px"><b>سوابق (${N(l.length)})</b><button class="sm" onclick="go('add','${t.id}')">ثبت امتیاز</button></div>`+
 (l.map(s=>`<div class="card"><div class="row"><b>${sg(s.val)}</b><span class="m">${fa(s.date)}</span></div><div><span class="tag">${esc(O(s.oid)?.title||'—')}</span><span class="tag">${esc(R(s.rid)?.title||'—')}</span></div>${s.note?`<div class="m">${esc(s.note)}</div>`:''}
 <div class="grid" style="margin-top:6px"><button class="s sm" onclick="go('add','${t.id}|${s.id}')">ویرایش</button><button class="d sm" onclick="delS('${s.id}')">حذف</button></div></div>`).join('')||'<p class="m">رکوردی نیست.</p>');
}
function delT(id){if(confirm('این متربی و همهٔ امتیازهایش حذف شود؟')){db.trainees=db.trainees.filter(x=>x.id!=id);db.scores=db.scores.filter(s=>s.tid!=id);save();go('trainees')}}
function delS(id){if(confirm('این رکورد حذف شود؟')){db.scores=db.scores.filter(s=>s.id!=id);save();render()}}
function add(){
 const [tid,sid]=String(arg||'').split('|'),e=sid?db.scores.find(s=>s.id==sid):null;
 const d=e||{tid:tid||keep.tid,val:keep.val??1,date:keep.date||today(),oid:keep.oid,rid:keep.rid,note:''};
 if(!db.trainees.length)return '<p class="card">ابتدا از بخش «متربیان» حداقل یک متربی اضافه کنید.</p>';
 return `<div class="card"><label>متربی</label><select id="a_t">${opts(db.trainees,d.tid,'انتخاب کنید…')}</select>
 <label>مقدار امتیاز</label><div class="row"><button class="s" onclick="stp(-1)">−</button><input id="a_v" type="number" inputmode="numeric" value="${d.val}" style="text-align:center"><button class="s" onclick="stp(1)">+</button></div>
 <label>تاریخ <span id="a_f"></span></label><input id="a_d" type="date" value="${d.date}">
 <label>مناسبت</label><select id="a_o">${opts(db.occasions.filter(x=>x.active!==false||x.id==d.oid),d.oid,'—')}</select>
 <label>دلیل امتیازدهی</label><select id="a_r">${opts(db.reasons.filter(x=>x.active!==false||x.id==d.rid),d.rid,'—')}</select>
 <label>توضیحات (اختیاری)</label><input id="a_n" value="${esc(d.note)}">
 ${!db.occasions.length||!db.reasons.length?'<p class="m">مناسبت‌ها و دلایل را از «بیشتر» تعریف کنید.</p>':''}
 <button id="a_s" style="width:100%">${e?'ذخیره تغییرات':'ثبت و امتیاز بعدی'}</button></div>`;
}
const stp=n=>{$('#a_v').value=(+$('#a_v').value||0)+n};
function bindAdd(){
 const fd=()=>$('#a_f').textContent='('+fa($('#a_d').value)+')';fd();$('#a_d').onchange=fd;
 $('#a_s').onclick=()=>{
  const [,sid]=String(arg||'').split('|'),v=$('#a_v').value;
  if(!$('#a_t').value)return alert('متربی را انتخاب کنید');if(v===''||isNaN(v))return alert('مقدار امتیاز را وارد کنید');
  const r={id:sid||uid(),tid:$('#a_t').value,val:+v,date:$('#a_d').value,oid:$('#a_o').value,rid:$('#a_r').value,note:$('#a_n').value.trim()};
  if(sid)Object.assign(db.scores.find(s=>s.id==sid),r);else db.scores.push(r);
  save();keep={val:r.val,date:r.date,oid:r.oid,rid:r.rid};
  if(sid){go('tr',r.tid)}else{arg=null;render();const b=$('#a_s');b.textContent='✓ ثبت شد';setTimeout(()=>b&&(b.textContent='ثبت و امتیاز بعدی'),1200)}
 }}
function reports(){
 const f=flt,t=f.rt||'rank';let body='';
 const inP=s=>(!f.from||s.date>=f.from)&&(!f.to||s.date<=f.to);
 const per=`<div class="grid"><div><label>از</label><input type="date" value="${f.from||''}" onchange="flt.from=this.value;render()"></div><div><label>تا</label><input type="date" value="${f.to||''}" onchange="flt.to=this.value;render()"></div></div>`;
 const rk=l=>db.trainees.map(x=>[x,total(x.id,l)]).sort((a,b)=>b[1]-a[1]).map(([x,n],i)=>`<div class="row card"><span>${N(i+1)}. ${esc(x.name)}</span>${sg(n)}</div>`).join('')||'<p class="m">داده‌ای نیست.</p>';
 if(t=='rank')body=per+rk(db.scores.filter(inP));
 if(t=='occ')body=`<select onchange="flt.o=this.value;render()">${opts(db.occasions,f.o,'مناسبت را انتخاب کنید')}</select>`+(f.o?rk(db.scores.filter(s=>s.oid==f.o)):'');
 if(t=='rea')body=`<select onchange="flt.r=this.value;render()">${opts(db.reasons,f.r,'دلیل را انتخاب کنید')}</select>`+(f.r?rk(db.scores.filter(s=>s.rid==f.r)):'');
 if(t=='trend'){body=`<select onchange="flt.tt=this.value;render()">${opts(db.trainees,f.tt,'متربی را انتخاب کنید')}</select>`;
  if(f.tt){const l=db.scores.filter(s=>s.tid==f.tt).sort((a,b)=>a.date.localeCompare(b.date));let c=0;const p=l.map(s=>c+=s.val);
   if(p.length>1){const mn=Math.min(0,...p),mx=Math.max(0,...p)||1,W=300,H=120,y=v=>H-8-(v-mn)/((mx-mn)||1)*(H-16);
    body+=`<div class="card"><svg viewBox="0 0 ${W} ${H}" width="100%"><line x1="0" x2="${W}" y1="${y(0)}" y2="${y(0)}" stroke="currentColor" opacity=".25"/><polyline fill="none" stroke="var(--p)" stroke-width="2.5" points="${p.map((v,i)=>`${6+i*(W-12)/(p.length-1)},${y(v)}`).join(' ')}"/></svg><div class="m">روند مجموع تجمعی از ${fa(l[0].date)} تا ${fa(l.at(-1).date)}</div></div>`}
   else body+='<p class="m">برای رسم روند حداقل دو رکورد لازم است.</p>'}}
 const tabs=[['rank','رتبه‌ها'],['occ','مناسبت'],['rea','دلیل'],['trend','روند']];
 return `<div class="scroll row" style="margin-bottom:10px;justify-content:flex-start">${tabs.map(([k,n])=>`<button class="sm ${t==k?'':'s'}" onclick="flt.rt='${k}';render()">${n}</button>`).join('')}</div>`+body;
}
function more(){return `<div class="card"><button class="s" style="width:100%;margin-bottom:8px" onclick="go('occ')">مدیریت مناسبت‌ها</button><button class="s" style="width:100%;margin-bottom:8px" onclick="go('rea')">مدیریت دلایل امتیازدهی</button><button class="s" style="width:100%;margin-bottom:8px" onclick="go('export')">خروجی برای والدین</button><button class="s" style="width:100%" onclick="go('backup')">پشتیبان‌گیری و بازیابی</button></div>`}
function manage(k,title){
 const l=db[k];
 return `<div class="row" style="margin-bottom:10px"><h3 style="margin:0">${title}</h3><button onclick="editM('${k}')">+ افزودن</button></div>`+
 (l.map(x=>`<div class="card row ${x.active===false?'off':''}"><span>${esc(x.title)}</span><span><button class="s sm" onclick="editM('${k}','${x.id}')">ویرایش</button> <button class="s sm" onclick="tgM('${k}','${x.id}')">${x.active===false?'فعال':'غیرفعال'}</button></span></div>`).join('')||'<p class="m">هنوز موردی تعریف نشده. فهرست نهایی را خودتان مشخص کنید.</p>')+
 (k=='occasions'?'<p class="m">مناسبت و دلیل امتیازدهی مستقل از هم‌اند.</p>':'');
}
function editM(k,id){const x=id?db[k].find(i=>i.id==id):null;
 modal(x?'ویرایش عنوان':'افزودن',`<input name="title" value="${esc(x?.title||'')}">`,v=>{if(!v.title.trim())return false;
  if(x)x.title=v.title.trim();else db[k].push({id:uid(),title:v.title.trim(),active:true});save();render()})}
function tgM(k,id){const x=db[k].find(i=>i.id==id);x.active=x.active===false;save();render()}
function dl(name,obj){const b=new Blob([JSON.stringify(obj)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=name;document.body.append(a);a.click();a.remove()}
function exp(){
 return `<div class="card"><label>متربی</label><select id="e_t"><option value="*">همهٔ متربیان (یک فایل جدا برای هر نفر)</option>${opts(db.trainees)}</select>
 <b>اطلاعاتی که در فایل باشد:</b><div style="margin:8px 0"><label><input type="checkbox" id="e_o" checked>مناسبت</label></div><div><label><input type="checkbox" id="e_r" checked>دلیل</label></div><div><label><input type="checkbox" id="e_n" checked>توضیحات</label></div><div style="margin-bottom:10px"><label><input type="checkbox" id="e_g" checked>نام گروه</label></div>
 <button style="width:100%" onclick="doExp()">تهیه فایل</button><p class="m">فایل فقط شامل اطلاعات همان متربی است. برای ارسال آن از پیام‌رسان، بلوتوث یا حافظه استفاده کنید.</p></div>`}
function doExp(){
 const sel=$('#e_t').value,ids=sel=='*'?db.trainees.map(t=>t.id):[sel],c=id=>$('#'+id).checked;
 if(!ids.length)return alert('متربی‌ای وجود ندارد');
 ids.forEach(id=>{const t=T(id);dl(`${t.name.replace(/[\\/:*?"<>|\s]+/g,'_')}.parent.json`,{type:'kanoon-parent-export',v:1,exported:today(),group:c('e_g')?db.group:undefined,trainee:{id:t.id,name:t.name},
  scores:db.scores.filter(s=>s.tid==id).map(s=>({id:s.id,val:s.val,date:s.date,occasion:c('e_o')?O(s.oid)?.title:undefined,reason:c('e_r')?R(s.rid)?.title:undefined,note:c('e_n')?s.note:undefined}))})});}
function backup(){return `<div class="card"><button style="width:100%;margin-bottom:10px" onclick="dl('backup-'+today()+'.coach-backup.json',{type:'kanoon-coach-backup',v:1,db})">تهیه نسخه پشتیبان کامل</button><p class="m">این فایل شامل همهٔ اطلاعات است؛ آن را برای والدین نفرستید.</p><label>بازیابی از پشتیبان (جایگزین اطلاعات فعلی می‌شود)</label><input type="file" accept=".json" onchange="restore.call(this)"></div>`}
function restore(){
 const f=this.files[0];if(!f)return;const r=new FileReader();
 r.onload=()=>{try{const j=JSON.parse(r.result);if(j.type!='kanoon-coach-backup'||!j.db||!Array.isArray(j.db.scores))throw 0;
  if(!db||confirm('اطلاعات فعلی با پشتیبان جایگزین شود؟')){db=j.db;save();go('home')}}catch(e){alert('فایل پشتیبان معتبر نیست؛ اطلاعات قبلی تغییری نکرد.')}};
 r.readAsText(f)}
render();
