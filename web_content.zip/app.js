const seed=[
 {id:1,nickname:"Rahul Gaming",uid:"123456789",price:1200,seller:"Rahul",contact:"01700000000",desc:"Demo listing — নিজের তথ্য দিয়ে পরিবর্তন করুন।",created:Date.now()-100000},
 {id:2,nickname:"Pro Player",uid:"987654321",price:1800,seller:"Seller",contact:"01800000000",desc:"Demo listing — যোগাযোগের আগে তথ্য যাচাই করুন।",created:Date.now()-50000}
];
let listings=JSON.parse(localStorage.getItem("rahulShopListings")||"null")||seed;
const $=id=>document.getElementById(id);
function save(){localStorage.setItem("rahulShopListings",JSON.stringify(listings));}
function render(){
 const q=$("search").value.trim().toLowerCase(), s=$("sort").value;
 let data=listings.filter(x=>[x.nickname,x.uid,x.seller].join(" ").toLowerCase().includes(q));
 if(s==="low")data.sort((a,b)=>a.price-b.price);
 else if(s==="high")data.sort((a,b)=>b.price-a.price);
 else data.sort((a,b)=>b.created-a.created);
 $("count").textContent=data.length;
 $("listings").innerHTML=data.map(x=>`
  <article class="card">
   <div class="card-top"><div><div class="nick">${esc(x.nickname)}</div><div class="meta">UID: ${esc(x.uid)}</div></div><div class="price">৳${Number(x.price).toLocaleString("en-BD")}</div></div>
   <div class="meta">Seller: ${esc(x.seller)}</div>
   <div class="desc">${esc(x.desc||"কোনো বিবরণ নেই।")}</div>
   <a class="btn primary contact" href="tel:${escAttr(x.contact)}">📞 যোগাযোগ করুন</a>
  </article>`).join("");
 $("empty").classList.toggle("hidden",data.length!==0);
}
function esc(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function escAttr(v){return String(v).replace(/[^0-9+ ]/g,"")}
function openModal(){$("modal").classList.remove("hidden")}
function closeModal(){$("modal").classList.add("hidden")}
$("sellBtn").onclick=openModal;$("sellTop").onclick=openModal;$("close").onclick=closeModal;
$("modal").addEventListener("click",e=>{if(e.target===$("modal"))closeModal()});
$("search").oninput=render;$("sort").onchange=render;
$("listingForm").onsubmit=e=>{
 e.preventDefault();
 const item={id:Date.now(),nickname:$("nickname").value.trim(),uid:$("uid").value.trim(),price:Number($("price").value),seller:$("seller").value.trim(),contact:$("contact").value.trim(),desc:$("desc").value.trim(),created:Date.now()};
 listings.push(item);save();render();e.target.reset();closeModal();
 alert("Listing যোগ হয়েছে!");
};
render();