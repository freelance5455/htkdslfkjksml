// ==========================================
// ONE-TIME GMAIL LOGIN, PHOTO & TEXT HISTORY LOG
// ==========================================
const AUTH_STORAGE_KEY = "poralekha_gmail_auth_v9_1";
let currentUser = null;
let pendingLoginPhotoData = "";
let activityHistory = [];

function getUserStoragePrefix() {
  return currentUser && currentUser.email ? `poralekha_${currentUser.email}_` : "poralekha_guest_";
}

function readImageAsCompressedDataUrl(file, maxSize = 180, quality = 0.75) {
  return new Promise((resolve) => {
    if (!file) return resolve("");
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = () => resolve("");
      img.src = e.target.result;
    };
    reader.onerror = () => resolve("");
    reader.readAsDataURL(file);
  });
}

async function previewLoginPhoto(event) {
  const file = event.target.files[0];
  if (!file) return;
  pendingLoginPhotoData = await readImageAsCompressedDataUrl(file, 180, 0.75);
  if (pendingLoginPhotoData) {
    document.getElementById("loginPhotoPreview").src = pendingLoginPhotoData;
    document.getElementById("loginPhotoPreviewWrap").classList.remove("hidden");
  }
}

function initOneTimeAuth() {
  const saved = localStorage.getItem(AUTH_STORAGE_KEY);
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      if (parsed && parsed.email && parsed.loggedIn) {
        currentUser = parsed;
        applyUserProfileUI(parsed);
        document.getElementById("loginGateway").classList.add("hidden");
        document.getElementById("mainAppWrapper").classList.remove("hidden");
        loadUserScopedData();
        logActivity(`অ্যাপ ওপেন করা হয়েছে (${parsed.email})`);
        return;
      }
    } catch (e) {}
  }

  document.getElementById("loginGateway").classList.remove("hidden");
  document.getElementById("mainAppWrapper").classList.add("hidden");
}

function handleOneTimeGmailLogin(event) {
  event.preventDefault();
  const nameInput = document.getElementById("userNameInput").value.trim();
  const emailInput = document.getElementById("gmailAddressInput").value.trim().toLowerCase();
  const errBox = document.getElementById("loginErrorMsg");

  if (!nameInput) {
    errBox.textContent = "⚠️ দয়া করে আপনার নাম লিখুন।";
    errBox.classList.remove("hidden");
    return;
  }

  const gmailRegex = /^[a-z0-9._%+-]+@gmail\.com$/;
  if (!gmailRegex.test(emailInput)) {
    errBox.textContent = "⚠️ সঠিক জিমেইল অ্যাকাউন্ট দিন (যেমন: yourname@gmail.com)।";
    errBox.classList.remove("hidden");
    return;
  }

  errBox.classList.add("hidden");

  const userProfile = {
    name: nameInput,
    email: emailInput,
    photo: pendingLoginPhotoData || "",
    loggedIn: true,
    loginDate: new Date().toISOString()
  };

  localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(userProfile));
  currentUser = userProfile;

  applyUserProfileUI(userProfile);
  document.getElementById("loginGateway").classList.add("hidden");
  document.getElementById("mainAppWrapper").classList.remove("hidden");

  loadUserScopedData();
  logActivity(`Gmail (${emailInput}) দিয়ে এককালীন লগইন সম্পন্ন হয়েছে।`);
}

function applyUserProfileUI(user) {
  const initial = (user.name || user.email || "G").charAt(0).toUpperCase();

  const headerImg = document.getElementById("headerPhotoImg");
  const headerFallback = document.getElementById("headerAvatarFallback");
  const modalImg = document.getElementById("modalPhotoImg");
  const modalFallback = document.getElementById("modalAvatarLarge");

  if (user.photo) {
    headerImg.src = user.photo;
    headerImg.classList.remove("hidden");
    headerFallback.classList.add("hidden");

    modalImg.src = user.photo;
    modalImg.classList.remove("hidden");
    modalFallback.classList.add("hidden");
  } else {
    headerImg.classList.add("hidden");
    headerFallback.textContent = initial;
    headerFallback.classList.remove("hidden");

    modalImg.classList.add("hidden");
    modalFallback.textContent = initial;
    modalFallback.classList.remove("hidden");
  }

  document.getElementById("modalFullName").textContent = user.name;
  document.getElementById("modalGmailText").textContent = user.email;
}

async function updateProfilePhoto(event) {
  const file = event.target.files[0];
  if (!file || !currentUser) return;
  const dataUrl = await readImageAsCompressedDataUrl(file, 180, 0.75);
  if (dataUrl) {
    currentUser.photo = dataUrl;
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(currentUser));
    applyUserProfileUI(currentUser);
    logActivity("প্রোফাইল ছবি পরিবর্তন করা হয়েছে।");
    renderHistoryModal();
  }
}

function logActivity(text) {
  if (!currentUser || !currentUser.email) return;
  const now = new Date();
  const timeStr = now.toLocaleDateString("bn-BD") + " • " + now.toLocaleTimeString("en-GB");
  activityHistory.unshift({
    id: Date.now() + Math.random(),
    time: timeStr,
    text: text
  });
  if (activityHistory.length > 150) {
    activityHistory = activityHistory.slice(0, 150);
  }
  localStorage.setItem(getUserStoragePrefix() + "history_log", JSON.stringify(activityHistory));
}

function renderHistoryModal() {
  const logBox = document.getElementById("activityHistoryTextBox");
  document.getElementById("historyCountBadge").textContent = `${activityHistory.length}টি`;
  document.getElementById("modalTotalStudy").textContent = formatHMS(totalStudySeconds);
  document.getElementById("modalLeaveCount").textContent = `${leaveCount} বার`;

  if (!activityHistory.length) {
    logBox.innerHTML = `<div class="history-empty-msg">এখনো কোনো হিস্ট্রি যুক্ত হয়নি। অ্যাপে যা করবেন তা এখানে টেক্সট আকারে জমা হবে।</div>`;
    return;
  }

  logBox.innerHTML = activityHistory
    .map(item => `
      <div class="history-entry-item">
        <span class="history-entry-time">${item.time}</span>
        <div>• ${item.text}</div>
      </div>
    `)
    .join("");
}

function openProfileAndHistoryModal() {
  renderHistoryModal();
  document.getElementById("profileModal").classList.remove("hidden");
}

function closeProfileAndHistoryModal() {
  document.getElementById("profileModal").classList.add("hidden");
}

function handleBackdropClick(event) {
  if (event.target.id === "profileModal") {
    closeProfileAndHistoryModal();
  }
}

function clearHistoryLog() {
  if (!confirm("সব অ্যাক্টিভিটি হিস্ট্রি মুছে ফেলতে চান?")) return;
  activityHistory = [];
  localStorage.setItem(getUserStoragePrefix() + "history_log", JSON.stringify([]));
  renderHistoryModal();
}

function logoutGmailAccount() {
  if (!confirm("আপনি কি নিশ্চিতভাবে এই Gmail অ্যাকাউন্ট থেকে লগআউট করতে চান?")) return;
  localStorage.removeItem(AUTH_STORAGE_KEY);
  currentUser = null;
  pendingLoginPhotoData = "";
  closeProfileAndHistoryModal();
  document.getElementById("mainAppWrapper").classList.add("hidden");
  document.getElementById("loginGateway").classList.remove("hidden");
}

// ==========================================
// CORE CAMERA, ALARM, SNAPSHOT & TIMELAPSE
// ==========================================
let currentStream = null;
let facingMode = "user";
let isMirrored = true;
let isRecording = false;
let mediaRecorder = null;
let recordedChunks = [];
let recordedBlob = null;
let recordedFileName = "";
let captureTimer = null;
let clockInterval = null;
let startTime = 0;
let wakeLock = null;
let capturedFrameCount = 0;

let latestSnapshotBlob = null;
let latestSnapshotDataUrl = "";
let latestSnapshotFilename = "";

let totalStudySeconds = 0;
let leaveCount = 0;
let tasks = [];
let studyTicker = null;

let presenceInterval = null;
let emptyDeskFrame = null;
let isAtTable = false;
let absentCounter = 0;
let presentCounter = 0;
let hasTriggeredLeave = false;
let hasCustomAudio = false;

let audioCtx = null;
let alarmLoopInterval = null;
let isAlarmPlaying = false;

function loadUserScopedData() {
  const prefix = getUserStoragePrefix();
  totalStudySeconds = parseInt(localStorage.getItem(prefix + "study_sec") || "0", 10);
  leaveCount = parseInt(localStorage.getItem(prefix + "leave_cnt") || "0", 10);
  tasks = JSON.parse(localStorage.getItem(prefix + "tasks") || "[]");
  activityHistory = JSON.parse(localStorage.getItem(prefix + "history_log") || "[]");
  updateStatsUI();
  renderTasks();
}

setInterval(() => {
  const now = new Date();
  document.getElementById("liveClock").textContent = now.toLocaleTimeString("en-GB");
}, 1000);

function formatHMS(totalSec) {
  const hrs = String(Math.floor(totalSec / 3600)).padStart(2, "0");
  const mins = String(Math.floor((totalSec % 3600) / 60)).padStart(2, "0");
  const secs = String(totalSec % 60).padStart(2, "0");
  return `${hrs}:${mins}:${secs}`;
}

function updateStatsUI() {
  document.getElementById("totalStudyTime").textContent = formatHMS(totalStudySeconds);
  document.getElementById("leaveCountDisplay").textContent = `${leaveCount} বার`;
  const penalty = Math.min(leaveCount * 5, 85);
  document.getElementById("focusScoreDisplay").textContent = `${100 - penalty}%`;
}

async function requestWakeLock() {
  try {
    if ("wakeLock" in navigator) {
      wakeLock = await navigator.wakeLock.request("screen");
      document.getElementById("wakeLockBadge").textContent = "☀️ Screen On";
    }
  } catch (err) {}
}

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible" && currentStream) {
    requestWakeLock();
  }
});

function showError(msg) {
  const banner = document.getElementById("errorBanner");
  banner.innerHTML = msg;
  banner.classList.remove("hidden");
}

function hideError() {
  document.getElementById("errorBanner").classList.add("hidden");
}

function stopCurrentStream() {
  if (currentStream) {
    currentStream.getTracks().forEach(track => track.stop());
    currentStream = null;
  }
  if (presenceInterval) {
    clearInterval(presenceInterval);
    presenceInterval = null;
  }
  if (studyTicker) {
    clearInterval(studyTicker);
    studyTicker = null;
  }
}

async function requestCameraAccess() {
  hideError();
  initAudioContext();
  requestWakeLock();

  const videoEl = document.getElementById("cameraFeed");
  const placeholder = document.getElementById("cameraPlaceholder");
  const camStatus = document.getElementById("camStatus");

  if (!navigator.mediaDevices) navigator.mediaDevices = {};
  if (!navigator.mediaDevices.getUserMedia) {
    const legacyGetUserMedia =
      navigator.webkitGetUserMedia ||
      navigator.mozGetUserMedia ||
      navigator.getUserMedia;

    if (!legacyGetUserMedia) {
      showError(
        "⚠️ আপনার অ্যাপ বিল্ডারে Camera API সক্রিয় নেই। HTML to APK অ্যাপে <b>Camera Permission</b> এবং <b>WebRTC / File Access</b> অপশনটি অন করে বিল্ড দিন।"
      );
      return;
    }

    navigator.mediaDevices.getUserMedia = (constraints) => {
      return new Promise((resolve, reject) => {
        legacyGetUserMedia.call(navigator, constraints, resolve, reject);
      });
    };
  }

  stopCurrentStream();

  try {
    if (navigator.mediaDevices.enumerateDevices) {
      await navigator.mediaDevices.enumerateDevices();
    }
  } catch (e) {}

  const constraintAttempts = [
    { video: { facingMode: { exact: facingMode }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false },
    { video: { facingMode: { ideal: facingMode }, width: { ideal: 640 }, height: { ideal: 480 } }, audio: false },
    { video: { facingMode: facingMode }, audio: false },
    { video: true, audio: false }
  ];

  let stream = null;
  let lastError = null;

  for (const constraints of constraintAttempts) {
    try {
      stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (stream) break;
    } catch (err) {
      lastError = err;
    }
  }

  if (!stream) {
    handleCameraError(lastError);
    return;
  }

  currentStream = stream;
  videoEl.srcObject = stream;
  videoEl.setAttribute("playsinline", "true");
  videoEl.setAttribute("autoplay", "true");
  videoEl.muted = true;

  if (facingMode === "user" && isMirrored) {
    videoEl.classList.add("mirrored");
  } else {
    videoEl.classList.remove("mirrored");
  }

  try {
    await videoEl.play();
  } catch (e) {}

  placeholder.classList.add("hidden");
  document.getElementById("videoQuickTools").classList.remove("hidden");

  camStatus.textContent = facingMode === "user" ? "ফ্রন্ট ক্যামেরা চালু" : "ব্যাক ক্যামেরা চালু";
  camStatus.className = "status-pill status-on";

  document.getElementById("btnSwitchCam").disabled = false;
  document.getElementById("btnStartRec").disabled = false;
  document.getElementById("btnCalibrate").disabled = false;
  document.getElementById("btnStartCam").textContent = "🔄 রিস্টার্ট ক্যামেরা";

  logActivity(facingMode === "user" ? "ফ্রন্ট ক্যামেরা চালু করা হয়েছে।" : "ব্যাক ক্যামেরা চালু করা হয়েছে।");

  unlockAudioContext();
  startPresenceMonitor();
  startStudyTimer();
}

function handleCameraError(err) {
  const name = err ? err.name : "";
  if (name === "NotAllowedError" || name === "PermissionDeniedError") {
    showError(
      "❌ <b>ক্যামেরা পারমিশন ব্লক করা আছে!</b><br>" +
      "সমাধান: মোবাইলের <b>Settings &gt; Apps &gt; আপনার অ্যাপ &gt; Permissions &gt; Camera &gt; Allow</b> করে অ্যাপটি রিস্টার্ট করুন।"
    );
  } else if (name === "NotFoundError" || name === "DevicesNotFoundError") {
    showError("❌ এই ডিভাইসে কোনো ক্যামেরা খুঁজে পাওয়া যায়নি।");
  } else if (name === "NotReadableError" || name === "TrackStartError") {
    showError("⚠️ ক্যামেরাটি অন্য কোনো অ্যাপ ব্যবহার করছে। ব্যাকগ্রাউন্ডের অন্য অ্যাপ বন্ধ করে আবার চেষ্টা করুন।");
  } else {
    showError(
      `⚠️ ক্যামেরা চালু হয়নি (${name || "Permission Required"})। HTML to APK সেটিংসে <b>Camera Permission</b> চালু আছে কিনা নিশ্চিত করুন।`
    );
  }
}

async function switchCamera() {
  if (isRecording) {
    alert("টাইমল্যাপস রেকর্ডিং চলাকালীন ক্যামেরা পরিবর্তন করা যাবে না।");
    return;
  }
  facingMode = facingMode === "user" ? "environment" : "user";
  emptyDeskFrame = null;
  await requestCameraAccess();
}

function toggleMirror() {
  isMirrored = !isMirrored;
  const videoEl = document.getElementById("cameraFeed");
  const btn = document.getElementById("btnMirror");
  if (isMirrored && facingMode === "user") {
    videoEl.classList.add("mirrored");
    btn.textContent = "🪞 মিরর: চালু";
  } else {
    videoEl.classList.remove("mirrored");
    btn.textContent = "🪞 মিরর: বন্ধ";
  }
}

function takeSnapshot() {
  const videoEl = document.getElementById("cameraFeed");
  if (!currentStream || videoEl.readyState < 2) {
    alert("আগে ক্যামেরা চালু করুন!");
    return;
  }

  const rawW = videoEl.videoWidth || 640;
  const rawH = videoEl.videoHeight || 480;
  const scale = Math.min(1, 960 / Math.max(rawW, rawH));
  const w = Math.round(rawW * scale);
  const h = Math.round(rawH * scale);

  const snapCanvas = document.createElement("canvas");
  snapCanvas.width = w;
  snapCanvas.height = h;
  const ctx = snapCanvas.getContext("2d");

  if (isMirrored && facingMode === "user") {
    ctx.translate(w, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(videoEl, 0, 0, w, h);

  latestSnapshotFilename = `poralekha_snap_${Date.now()}.jpg`;
  latestSnapshotDataUrl = snapCanvas.toDataURL("image/jpeg", 0.88);

  snapCanvas.toBlob((blob) => {
    latestSnapshotBlob = blob;
  }, "image/jpeg", 0.88);

  document.getElementById("snapshotPreviewImg").src = latestSnapshotDataUrl;
  document.getElementById("snapshotModalBox").classList.remove("hidden");
  logActivity("ইনস্ট্যান্ট স্ন্যাপশট ক্যাপচার করা হয়েছে।");
}

function closeSnapshotBox() {
  document.getElementById("snapshotModalBox").classList.add("hidden");
}

function downloadCurrentSnapshot() {
  if (!latestSnapshotDataUrl) return;
  const a = document.createElement("a");
  a.href = latestSnapshotDataUrl;
  a.download = latestSnapshotFilename || `snapshot_${Date.now()}.jpg`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);

  logActivity(`স্ন্যাপশট সেভ/ডাউনলোড করা হয়েছে (${latestSnapshotFilename})।`);
  document.getElementById("monitorStatusText").textContent =
    `✅ স্ন্যাপশট ডাউনলোড শুরু হয়েছে (${latestSnapshotFilename})।`;
}

async function shareCurrentSnapshot() {
  if (!latestSnapshotBlob) return;
  try {
    const file = new File([latestSnapshotBlob], latestSnapshotFilename, { type: "image/jpeg" });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: "Poralekha Study Snapshot" });
      logActivity("স্ন্যাপশট শেয়ার করা হয়েছে।");
    } else {
      downloadCurrentSnapshot();
    }
  } catch (e) {
    downloadCurrentSnapshot();
  }
}

function startStudyTimer() {
  if (studyTicker) clearInterval(studyTicker);
  studyTicker = setInterval(() => {
    if (currentStream && isAtTable) {
      totalStudySeconds++;
      localStorage.setItem(getUserStoragePrefix() + "study_sec", String(totalStudySeconds));
      updateStatsUI();
    }
  }, 1000);
}

// ==========================================
// MULTI-TONE BUILT-IN ALARM SYNTHESIZER
// ==========================================
function initAudioContext() {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume().catch(() => {});
  }
}

function unlockAudioContext() {
  initAudioContext();
  const player = document.getElementById("leaveSoundPlayer");
  if (player && player.src) {
    player.muted = true;
    player.play().then(() => {
      player.pause();
      player.currentTime = 0;
      player.muted = false;
    }).catch(() => {
      player.muted = false;
    });
  }
}

function getGainVolume() {
  const slider = document.getElementById("alarmVolume");
  return slider ? parseInt(slider.value, 10) / 100 : 1.0;
}

function updateVolumeLabel() {
  const val = document.getElementById("alarmVolume").value;
  document.getElementById("volLabel").textContent = `${val}%`;
}

function onAlarmToneChange() {
  stopAllAlarms();
  const toneLabel = document.getElementById("alarmToneSelect").selectedOptions[0].text;
  logActivity(`অ্যালার্ম সাউন্ড পরিবর্তন করা হয়েছে: ${toneLabel}`);
}

function playSynthesizedTone(type) {
  initAudioContext();
  if (!audioCtx) return;

  const vol = getGainVolume();
  const now = audioCtx.currentTime;

  if (type === "siren") {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = "sawtooth";
    osc.frequency.setValueAtTime(620, now);
    osc.frequency.linearRampToValueAtTime(1350, now + 0.45);
    osc.frequency.linearRampToValueAtTime(620, now + 0.9);
    gain.gain.setValueAtTime(vol * 0.65, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.95);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(now);
    osc.stop(now + 0.95);
  } else if (type === "digital_beep") {
    for (let i = 0; i < 4; i++) {
      const start = now + i * 0.18;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "square";
      osc.frequency.setValueAtTime(2048, start);
      gain.gain.setValueAtTime(vol * 0.55, start);
      gain.gain.setValueAtTime(0.001, start + 0.11);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(start);
      osc.stop(start + 0.12);
    }
  } else if (type === "school_bell") {
    const freqs = [880, 1318.5, 1760, 2489];
    freqs.forEach((f, idx) => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = idx % 2 === 0 ? "triangle" : "sine";
      osc.frequency.setValueAtTime(f, now);
      gain.gain.setValueAtTime((vol * 0.45) / (idx + 1), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.1);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now);
      osc.stop(now + 1.15);
    });
  } else if (type === "police_horn") {
    [440, 554.37].forEach(freq => {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(vol * 0.5, now);
      gain.gain.setValueAtTime(vol * 0.5, now + 0.55);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.7);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start(now);
      osc.stop(now + 0.72);
    });
  } else if (type === "voice_bn") {
    playSynthesizedTone("digital_beep");
    speakBengaliWarning();
  }
}

function speakBengaliWarning() {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(
      "সাবধান! তুমি পড়ার টেবিল থেকে উঠে গেছো। এখনই টেবিলে ফিরে এসে পড়া শুরু করো।"
    );
    utter.lang = "bn-BD";
    utter.rate = 1.02;
    utter.pitch = 1.1;
    utter.volume = getGainVolume();
    window.speechSynthesis.speak(utter);
  }
}

function handleAudioUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  const player = document.getElementById("leaveSoundPlayer");
  player.src = URL.createObjectURL(file);
  hasCustomAudio = true;
  document.getElementById("alarmToneSelect").value = "custom_file";
  logActivity(`কাস্টম MP3 অ্যালার্ম যোগ করা হয়েছে: ${file.name}`);
  document.getElementById("monitorStatusText").textContent = `✅ কাস্টম অ্যালার্ম লোড হয়েছে: ${file.name}`;
}

function triggerSingleAlarmCycle() {
  const tone = document.getElementById("alarmToneSelect").value;
  const player = document.getElementById("leaveSoundPlayer");

  if (navigator.vibrate) {
    navigator.vibrate([400, 150, 400]);
  }

  if (tone === "custom_file") {
    if (player && (hasCustomAudio || player.readyState >= 2)) {
      player.volume = getGainVolume();
      player.currentTime = 0;
      player.play().catch(() => playSynthesizedTone("siren"));
    } else {
      playSynthesizedTone("siren");
    }
  } else {
    playSynthesizedTone(tone);
  }
}

function startLeaveAlarm(isTest = false) {
  stopAllAlarms();
  isAlarmPlaying = true;
  document.getElementById("btnStopAlarm").classList.remove("hidden");

  triggerSingleAlarmCycle();

  const shouldLoop = !isTest && document.getElementById("loopAlarmToggle").checked;
  if (shouldLoop) {
    alarmLoopInterval = setInterval(() => {
      if (!isAlarmPlaying) return;
      triggerSingleAlarmCycle();
    }, 2200);
  } else {
    setTimeout(() => {
      if (!alarmLoopInterval) {
        document.getElementById("btnStopAlarm").classList.add("hidden");
        isAlarmPlaying = false;
      }
    }, 2500);
  }
}

function stopAllAlarms() {
  isAlarmPlaying = false;
  if (alarmLoopInterval) {
    clearInterval(alarmLoopInterval);
    alarmLoopInterval = null;
  }
  const player = document.getElementById("leaveSoundPlayer");
  if (player) {
    player.pause();
    player.currentTime = 0;
  }
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
  document.getElementById("btnStopAlarm").classList.add("hidden");
}

function testAlertSound() {
  startLeaveAlarm(true);
  logActivity("অ্যালার্ম সাউন্ড টেস্ট করা হয়েছে।");
}

// ==========================================
// TABLE-LEAVE PRESENCE DETECTION
// ==========================================
function captureLowResGrayFrame() {
  const videoEl = document.getElementById("cameraFeed");
  const canvas = document.getElementById("presenceCanvas");
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (videoEl.readyState < 2) return null;

  ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
  const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
  const gray = new Uint8Array(canvas.width * canvas.height);
  for (let i = 0, j = 0; i < imgData.length; i += 4, j++) {
    gray[j] = imgData[i] * 0.299 + imgData[i + 1] * 0.587 + imgData[i + 2] * 0.114;
  }
  return gray;
}

function calculateFrameDifference(frameA, frameB) {
  if (!frameA || !frameB || frameA.length !== frameB.length) return 0;
  let changedPixels = 0;
  const pixelThreshold = 26;
  for (let i = 0; i < frameA.length; i++) {
    if (Math.abs(frameA[i] - frameB[i]) > pixelThreshold) {
      changedPixels++;
    }
  }
  return (changedPixels / frameA.length) * 100;
}

function calibrateEmptyDesk() {
  const frame = captureLowResGrayFrame();
  if (frame) {
    emptyDeskFrame = frame;
    isAtTable = false;
    hasTriggeredLeave = false;
    absentCounter = 0;
    presentCounter = 0;
    stopAllAlarms();
    logActivity("খালি টেবিল ক্যালিব্রেট/সেট করা হয়েছে।");
    document.getElementById("monitorStatusText").textContent =
      "✅ খালি টেবিল সেট করা হয়েছে! এখন ক্যামেরার সামনে টেবিলে এসে বসুন।";
  }
}

function toggleLeaveMonitor() {
  const enabled = document.getElementById("leaveAlertToggle").checked;
  const badge = document.getElementById("presenceBadge");
  if (!enabled) {
    stopAllAlarms();
    badge.classList.add("hidden");
    logActivity("টেবিল-লিভ অ্যালার্ট বন্ধ করা হয়েছে।");
    document.getElementById("monitorStatusText").textContent = "স্ট্যাটাস: টেবিল অ্যালার্ট বন্ধ রাখা হয়েছে।";
  } else if (currentStream) {
    logActivity("টেবিল-লিভ অ্যালার্ট চালু করা হয়েছে।");
    startPresenceMonitor();
  }
}

function startPresenceMonitor() {
  if (presenceInterval) clearInterval(presenceInterval);

  const badge = document.getElementById("presenceBadge");
  const statusText = document.getElementById("monitorStatusText");

  setTimeout(() => {
    if (!emptyDeskFrame && currentStream) {
      const initialFrame = captureLowResGrayFrame();
      if (initialFrame) {
        isAtTable = true;
        badge.textContent = "🟢 টেবিলে আছেন";
        badge.classList.remove("hidden", "presence-left");
        statusText.textContent =
          "স্ট্যাটাস: ক্যামেরায় আপনাকে শনাক্ত করা হয়েছে। পড়া চলাকালীন নড়াচড়ায় সাউন্ড হবে না, উঠে গেলেই অ্যালার্ম বাজবে।";
      }
    }
  }, 1200);

  let previousFrame = null;

  presenceInterval = setInterval(() => {
    const enabled = document.getElementById("leaveAlertToggle").checked;
    if (!enabled || !currentStream) return;

    const currentFrame = captureLowResGrayFrame();
    if (!currentFrame) return;

    const requiredAbsentChecks = parseInt(document.getElementById("sensitivitySelect").value, 10) || 4;

    if (emptyDeskFrame) {
      const occupancyPct = calculateFrameDifference(currentFrame, emptyDeskFrame);

      if (occupancyPct > 16) {
        presentCounter++;
        absentCounter = 0;
        if (presentCounter >= 2 && !isAtTable) {
          isAtTable = true;
          hasTriggeredLeave = false;
          stopAllAlarms();
          badge.textContent = "🟢 টেবিলে আছেন";
          badge.classList.remove("hidden", "presence-left");
          statusText.textContent = "স্ট্যাটাস: আপনি টেবিলে ফিরে এসেছেন। অ্যালার্ম বন্ধ হয়েছে।";
          logActivity("পড়ার টেবিলে ফিরে আসা হয়েছে।");
        }
      } else {
        absentCounter++;
        presentCounter = 0;
        if (isAtTable && absentCounter >= requiredAbsentChecks && !hasTriggeredLeave) {
          isAtTable = false;
          hasTriggeredLeave = true;
          leaveCount++;
          localStorage.setItem(getUserStoragePrefix() + "leave_cnt", String(leaveCount));
          updateStatsUI();

          badge.textContent = "🚨 টেবিল ছেড়ে উঠেছেন!";
          badge.classList.remove("hidden");
          badge.classList.add("presence-left");
          statusText.textContent = "🚨 অ্যালার্ট: আপনি টেবিল থেকে উঠে গেছেন! অ্যালার্ম বাজছে...";
          logActivity(`টেবিল ছেড়ে উঠে যাওয়ায় অ্যালার্ম বেজেছে (মোট ${leaveCount} বার)।`);
          startLeaveAlarm(false);
        }
      }
    } else if (previousFrame) {
      const frameDiff = calculateFrameDifference(currentFrame, previousFrame);
      if (isAtTable && frameDiff > 26) {
        setTimeout(() => {
          const settledFrame = captureLowResGrayFrame();
          if (settledFrame && !emptyDeskFrame) {
            emptyDeskFrame = settledFrame;
            isAtTable = false;
            hasTriggeredLeave = true;
            leaveCount++;
            localStorage.setItem(getUserStoragePrefix() + "leave_cnt", String(leaveCount));
            updateStatsUI();

            badge.textContent = "🚨 টেবিল ছেড়ে উঠেছেন!";
            badge.classList.remove("hidden");
            badge.classList.add("presence-left");
            statusText.textContent = "🚨 অ্যালার্ট: আপনি টেবিল থেকে উঠে গেছেন! অ্যালার্ম বাজছে...";
            logActivity(`টেবিল ছেড়ে উঠে যাওয়ায় অ্যালার্ম বেজেছে (মোট ${leaveCount} বার)।`);
            startLeaveAlarm(false);
          }
        }, 1200);
      }
    }

    previousFrame = currentFrame;
  }, 500);
}

// ==========================================
// HIGH-SPEED TIMELAPSE RECORDING
// ==========================================
function toggleRecording() {
  if (!isRecording) {
    startTimelapse();
  } else {
    stopTimelapse();
  }
}

function startTimelapse() {
  const videoEl = document.getElementById("cameraFeed");
  const canvas = document.getElementById("timelapseCanvas");
  const ctx = canvas.getContext("2d");

  const aspect = (videoEl.videoWidth && videoEl.videoHeight) ? (videoEl.videoWidth / videoEl.videoHeight) : (4 / 3);
  canvas.width = 640;
  canvas.height = Math.round(640 / aspect);

  let canvasStream;
  if (canvas.captureStream) {
    canvasStream = canvas.captureStream(0);
  } else {
    showError("⚠️ এই ডিভাইসে টাইমল্যাপস ক্যাপচার সাপোর্ট নেই।");
    return;
  }

  const videoTrack = canvasStream.getVideoTracks()[0];
  recordedChunks = [];
  recordedBlob = null;
  capturedFrameCount = 0;

  let options = { mimeType: "video/webm;codecs=vp8", videoBitsPerSecond: 650000 };
  if (!MediaRecorder.isTypeSupported(options.mimeType)) {
    options = { mimeType: "video/webm", videoBitsPerSecond: 650000 };
    if (!MediaRecorder.isTypeSupported(options.mimeType)) {
      options = { videoBitsPerSecond: 650000 };
    }
  }

  try {
    mediaRecorder = new MediaRecorder(canvasStream, options);
  } catch (e) {
    try {
      mediaRecorder = new MediaRecorder(canvasStream);
    } catch (err2) {
      showError("⚠️ এই ব্রাউজার/অ্যাপে ভিডিও রেকর্ডিং সাপোর্ট করছে না।");
      return;
    }
  }

  mediaRecorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) {
      recordedChunks.push(e.data);
    }
  };

  mediaRecorder.onstop = () => {
    document.getElementById("dlStatusTitle").textContent = "✅ টাইমল্যাপস ভিডিও প্রস্তুত!";
    recordedBlob = new Blob(recordedChunks, { type: mediaRecorder.mimeType || "video/webm" });
    recordedFileName = `poralekha_timelapse_${Date.now()}.webm`;

    const sizeMB = (recordedBlob.size / (1024 * 1024)).toFixed(2);
    document.getElementById("dlMetaText").textContent = `সাইজ: ${sizeMB} MB • মোট ${capturedFrameCount} ফ্রেম`;
    document.getElementById("downloadArea").classList.remove("hidden");
    recordedChunks = [];
    logActivity(`টাইমল্যাপস ভিডিও তৈরি হয়েছে (${capturedFrameCount} ফ্রেম, ${sizeMB} MB)।`);
  };

  mediaRecorder.start(2000);
  isRecording = true;
  startTime = Date.now();
  logActivity("টাইমল্যাপস রেকর্ডিং শুরু করা হয়েছে।");

  const intervalMs = parseInt(document.getElementById("intervalSelect").value, 10) || 2000;

  const drawFrame = () => {
    if (!isRecording) return;
    ctx.save();
    if (isMirrored && facingMode === "user") {
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
    }
    ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
    ctx.restore();

    ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
    ctx.fillRect(10, canvas.height - 30, 235, 22);
    ctx.fillStyle = "#00e676";
    ctx.font = "12px monospace";
    ctx.fillText(`Poralekha • ${new Date().toLocaleTimeString()}`, 16, canvas.height - 15);

    if (videoTrack && typeof videoTrack.requestFrame === "function") {
      videoTrack.requestFrame();
    }

    capturedFrameCount++;
    document.getElementById("frameCounterBadge").textContent = String(capturedFrameCount);
  };

  drawFrame();
  captureTimer = setInterval(drawFrame, intervalMs);

  clockInterval = setInterval(() => {
    const elapsed = Math.floor((Date.now() - startTime) / 1000);
    document.getElementById("timerDisplay").textContent = formatHMS(elapsed);
  }, 1000);

  document.getElementById("recIndicator").classList.remove("hidden");
  document.getElementById("downloadArea").classList.add("hidden");
  const btnRec = document.getElementById("btnStartRec");
  btnRec.textContent = "⏹️ থামান";
  btnRec.className = "btn btn-stop";
}

function stopTimelapse() {
  isRecording = false;
  clearInterval(captureTimer);
  clearInterval(clockInterval);

  document.getElementById("dlStatusTitle").textContent = "⏳ ভিডিও প্রসেস হচ্ছে...";
  document.getElementById("downloadArea").classList.remove("hidden");

  if (mediaRecorder && mediaRecorder.state !== "inactive") {
    mediaRecorder.stop();
  }
  document.getElementById("recIndicator").classList.add("hidden");
  const btnRec = document.getElementById("btnStartRec");
  btnRec.textContent = "⏺️ টাইমল্যাপস";
  btnRec.className = "btn btn-accent";
}

function triggerApkDownload() {
  if (!recordedBlob) {
    alert("ডাউনলোড করার মতো কোনো ভিডিও নেই।");
    return;
  }

  const url = URL.createObjectURL(recordedBlob);
  const a = document.createElement("a");
  a.style.display = "none";
  a.href = url;
  a.download = recordedFileName || `poralekha_timelapse_${Date.now()}.webm`;
  document.body.appendChild(a);
  a.click();

  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 3000);

  logActivity(`টাইমল্যাপস ভিডিও ডাউনলোড করা হয়েছে (${recordedFileName})।`);
  document.getElementById("monitorStatusText").textContent =
    "✅ ভিডিও ডাউনলোড কমান্ড পাঠানো হয়েছে! না হলে 'শেয়ার' বাটনে চাপ দিয়ে সেভ করুন।";
}

async function shareRecordedVideo() {
  if (!recordedBlob) return;
  try {
    const file = new File([recordedBlob], recordedFileName || "poralekha_timelapse.webm", {
      type: recordedBlob.type || "video/webm"
    });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ files: [file], title: "Poralekha Study Timelapse" });
      logActivity("টাইমল্যাপস ভিডিও শেয়ার করা হয়েছে।");
    } else {
      triggerApkDownload();
    }
  } catch (e) {
    triggerApkDownload();
  }
}

// ==========================================
// POMODORO FOCUS TIMER
// ==========================================
let pomoSeconds = 25 * 60;
let pomoRunning = false;
let pomoInterval = null;
let isBreakMode = false;

function updatePomoUI() {
  const mins = String(Math.floor(pomoSeconds / 60)).padStart(2, "0");
  const secs = String(pomoSeconds % 60).padStart(2, "0");
  document.getElementById("pomoDisplay").textContent = `${mins}:${secs}`;
}

function togglePomodoro() {
  initAudioContext();
  const btn = document.getElementById("btnPomoStart");
  if (!pomoRunning) {
    pomoRunning = true;
    btn.textContent = "⏸️ বিরতি";
    logActivity(isBreakMode ? "৫ মিনিটের ব্রেক টাইমার শুরু হয়েছে।" : "২৫ মিনিটের পমোডোরো সেশন শুরু হয়েছে।");
    pomoInterval = setInterval(() => {
      if (pomoSeconds > 0) {
        pomoSeconds--;
        updatePomoUI();
      } else {
        clearInterval(pomoInterval);
        pomoRunning = false;
        btn.textContent = "▶️ শুরু করুন";
        playSynthesizedTone("school_bell");
        logActivity(isBreakMode ? "ব্রেক টাইমার শেষ হয়েছে।" : "২৫ মিনিটের পমোডোরো সেশন সম্পন্ন হয়েছে।");
        alert(isBreakMode ? "ব্রেক শেষ! আবার পড়ায় ফিরে আসো।" : "দারুণ! ২৫ মিনিটের পড়া শেষ হয়েছে। এবার ৫ মিনিট ব্রেক নাও।");
      }
    }, 1000);
  } else {
    pomoRunning = false;
    clearInterval(pomoInterval);
    btn.textContent = "▶️ শুরু করুন";
    logActivity("পমোডোরো টাইমার বিরতি দেওয়া হয়েছে।");
  }
}

function resetPomodoro() {
  pomoRunning = false;
  clearInterval(pomoInterval);
  document.getElementById("btnPomoStart").textContent = "▶️ শুরু করুন";
  pomoSeconds = isBreakMode ? 5 * 60 : 25 * 60;
  updatePomoUI();
  logActivity("পমোডোরো টাইমার রিসেট করা হয়েছে।");
}

function switchPomoMode() {
  isBreakMode = !isBreakMode;
  const badge = document.getElementById("pomoModeBadge");
  if (isBreakMode) {
    badge.textContent = "ব্রেক টাইম (৫ মিনিট)";
    badge.className = "status-pill status-off";
    logActivity("পমোডোরো ব্রেক মোড (৫ মিনিট) চালু করা হয়েছে।");
  } else {
    badge.textContent = "পড়ার সেশন (২৫ মিনিট)";
    badge.className = "status-pill status-on";
    logActivity("পমোডোরো পড়ার মোড (২৫ মিনিট) চালু করা হয়েছে।");
  }
  resetPomodoro();
}

// ==========================================
// STUDY TASKS MANAGEMENT
// ==========================================
function saveTasks() {
  localStorage.setItem(getUserStoragePrefix() + "tasks", JSON.stringify(tasks));
  renderTasks();
}

function addTask() {
  const subject = document.getElementById("subjectSelect").value;
  const input = document.getElementById("taskInput");
  const text = input.value.trim();
  if (!text) return;

  tasks.unshift({ id: Date.now(), subject, text, done: false });
  input.value = "";
  saveTasks();
  logActivity(`নতুন পড়ার কাজ যোগ করা হয়েছে [${subject}]: "${text}"`);
}

function toggleTask(id) {
  const target = tasks.find(t => t.id === id);
  tasks = tasks.map(t => (t.id === id ? { ...t, done: !t.done } : t));
  saveTasks();
  if (target) {
    const nextState = !target.done;
    logActivity(
      nextState
        ? `কাজ সম্পন্ন হয়েছে [${target.subject}]: "${target.text}"`
        : `কাজ আবার অসম্পন্ন চিহ্নিত হয়েছে [${target.subject}]: "${target.text}"`
    );
  }
}

function deleteTask(id) {
  const target = tasks.find(t => t.id === id);
  tasks = tasks.filter(t => t.id !== id);
  saveTasks();
  if (target) {
    logActivity(`পড়ার কাজ মুছে ফেলা হয়েছে [${target.subject}]: "${target.text}"`);
  }
}

function renderTasks() {
  const list = document.getElementById("taskList");
  list.innerHTML = "";
  let remaining = 0;

  tasks.forEach(task => {
    if (!task.done) remaining++;
    const li = document.createElement("li");
    li.className = `task-item ${task.done ? "task-done" : ""}`;
    li.innerHTML = `
      <div class="task-left">
        <input type="checkbox" ${task.done ? "checked" : ""} onchange="toggleTask(${task.id})" />
        <span class="subject-tag">${task.subject}</span>
        <span>${task.text}</span>
      </div>
      <button class="btn-del" onclick="deleteTask(${task.id})">✕</button>
    `;
    list.appendChild(li);
  });

  document.getElementById("taskCount").textContent = `${remaining}টি বাকি`;
}

// Initialize App & One-Time Auth
initOneTimeAuth();
updatePomoUI();
