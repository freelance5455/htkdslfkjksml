// Elenco delle canzoni di base incluse nell'applicazione
let playlist = [
    { title: "Janji - Heroes Tonight", src: "musica/musica-ncs.mp3" },
];
let currentTrackIndex = 0;
let isPlaying = false;

const audio = document.getElementById('audio-element');
const titleDisplay = document.getElementById('track-title');
const playPauseBtn = document.getElementById('btn-play-pause');
const prevBtn = document.getElementById('btn-prev');
const nextBtn = document.getElementById('btn-next');
const playlistList = document.getElementById('playlist-entries');
const fileUpload = document.getElementById('file-upload');

// Disegna la lista delle canzoni sullo schermo
function renderPlaylist() {
    playlistList.innerHTML = ""; 
    playlist.forEach((track, index) => {
        const li = document.createElement('li');
        li.textContent = track.title;
        if (index === currentTrackIndex) {
            li.classList.add('active');
        }
        li.addEventListener('click', () => {
            loadTrack(index);
            playTrack();
        });
        playlistList.appendChild(li);
    });
}

// Inserisce la canzone selezionata nel lettore audio
function loadTrack(index) {
    if (playlist.length === 0) return;
    currentTrackIndex = index;
    audio.src = playlist[currentTrackIndex].src;
    titleDisplay.textContent = playlist[currentTrackIndex].title;
    
    const items = playlistList.querySelectorAll('li');
    items.forEach((item, i) => {
        if (i === index) item.classList.add('active');
        else item.classList.remove('active');
    });
}

// Gestisce l'aggiunta di nuove canzoni dal telefono
fileUpload.addEventListener('change', (event) => {
    const files = event.target.files;
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const fileURL = URL.createObjectURL(file); // Crea un link temporaneo al file sul telefono
        const cleanTitle = file.name.replace(/\.[^/.]+$/, ""); // Toglie il ".mp3" dal nome visibile
        
        playlist.push({
            title: cleanTitle,
            src: fileURL
        });
    }
    renderPlaylist();
});

function playTrack() {
    if (playlist.length === 0) return;
    audio.play();
    isPlaying = true;
    playPauseBtn.textContent = "⏸";
}

function pauseTrack() {
    audio.pause();
    isPlaying = false;
    playPauseBtn.textContent = "▶";
}

playPauseBtn.addEventListener('click', () => {
    if (isPlaying) pauseTrack();
    else playTrack();
});

nextBtn.addEventListener('click', () => {
    if (playlist.length === 0) return;
    let nextIndex = currentTrackIndex + 1;
    if (nextIndex >= playlist.length) nextIndex = 0;
    loadTrack(nextIndex);
    playTrack();
});

prevBtn.addEventListener('click', () => {
    if (playlist.length === 0) return;
    let prevIndex = currentTrackIndex - 1;
    if (prevIndex < 0) prevIndex = playlist.length - 1;
    loadTrack(prevIndex);
    playTrack();
});

// Passa alla canzone dopo quando quella attuale finisce
audio.addEventListener('ended', () => {
    nextBtn.click();
});

// Avvia il lettore all'apertura dell'app
renderPlaylist();
loadTrack(0);
