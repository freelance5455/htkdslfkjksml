/* Stockly Digital Twin v2 — ELITES CAFÉ offline PWA */
const KEY = 'stockly_elites_v2';

const DEFAULT_MENU = [
  { name: 'Bread loaf', cat: 'Ingredients', type: 'Ingredient', cost: 18, sell: 0, unit: 'loaf', stock: 8, low: 2, supplier: 'Bakery', buyUnit: 'loaf', useUnit: 'slice', conv: 20 },
  { name: 'Polony', cat: 'Ingredients', type: 'Ingredient', cost: 1, sell: 1, unit: 'slice', stock: 120, low: 20, supplier: 'ABC Foods', buyUnit: 'kg', useUnit: 'slice', conv: 40 },
  { name: 'Russian', cat: 'Ingredients', type: 'Ingredient', cost: 8, sell: 10, unit: 'unit', stock: 40, low: 10, supplier: 'ABC Foods', buyUnit: 'kg', useUnit: 'unit', conv: 12 },
  { name: 'Vienna', cat: 'Ingredients', type: 'Ingredient', cost: 5, sell: 0, unit: 'unit', stock: 35, low: 8, supplier: 'ABC Foods', buyUnit: 'kg', useUnit: 'unit', conv: 16 },
  { name: 'Cheese', cat: 'Ingredients', type: 'Ingredient', cost: 2.5, sell: 3, unit: 'slice', stock: 80, low: 15, supplier: 'ABC Foods', buyUnit: 'kg', useUnit: 'slice', conv: 40 },
  { name: 'Atchaar', cat: 'Ingredients', type: 'Ingredient', cost: 0.8, sell: 0, unit: 'portion', stock: 60, low: 12, supplier: 'Local' },
  { name: 'Chakalaka', cat: 'Ingredients', type: 'Ingredient', cost: 0.9, sell: 0, unit: 'portion', stock: 50, low: 12, supplier: 'Local' },
  { name: 'Chicken pattie', cat: 'Ingredients', type: 'Ingredient', cost: 12, sell: 0, unit: 'unit', stock: 25, low: 8, supplier: 'Butcher' },
  { name: 'Beef pattie', cat: 'Ingredients', type: 'Ingredient', cost: 14, sell: 0, unit: 'unit', stock: 20, low: 6, supplier: 'Butcher' },
  { name: 'Bun', cat: 'Ingredients', type: 'Ingredient', cost: 3, sell: 0, unit: 'unit', stock: 40, low: 10, supplier: 'Bakery' },
  { name: 'Lettuce', cat: 'Ingredients', type: 'Ingredient', cost: 0.5, sell: 0, unit: 'portion', stock: 40, low: 10, supplier: 'Market' },
  { name: 'Tomato', cat: 'Ingredients', type: 'Ingredient', cost: 0.4, sell: 0, unit: 'slice', stock: 80, low: 20, supplier: 'Market' },
  { name: 'Onion', cat: 'Ingredients', type: 'Ingredient', cost: 0.3, sell: 0, unit: 'portion', stock: 50, low: 12, supplier: 'Market' },
  { name: 'Potatoes', cat: 'Ingredients', type: 'Ingredient', cost: 0.02, sell: 0, unit: 'g', stock: 12000, low: 2000, supplier: 'Market', buyUnit: 'kg', useUnit: 'g', conv: 1000 },
  { name: 'Oil', cat: 'Ingredients', type: 'Ingredient', cost: 0.01, sell: 0, unit: 'ml', stock: 5000, low: 800, supplier: 'Wholesale', buyUnit: 'L', useUnit: 'ml', conv: 1000 },
  { name: 'Packaging', cat: 'Packaging', type: 'Packaging', cost: 1.2, sell: 0, unit: 'unit', stock: 100, low: 20, supplier: 'PackCo' },
  { name: 'Kota R15', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 15, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R20', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R25', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 25, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R30', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 30, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R35', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0 },
  { name: 'Kota R40', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 40, unit: 'unit', stock: 0, low: 0 },
  { name: 'Plain Hotdog', cat: 'Hotdogs', type: 'Menu Product', cost: 0, sell: 10, unit: 'unit', stock: 0, low: 0 },
  { name: 'Hotdog Lettuce & Cheese', cat: 'Hotdogs', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chips Small', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chips Medium', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 30, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chips Large', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chicken Burger', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0 },
  { name: 'Beef Burger', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 40, unit: 'unit', stock: 0, low: 0 },
  { name: 'Chicken Burger + Chips', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 50, unit: 'unit', stock: 0, low: 0 },
  { name: 'Beef Burger + Chips', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 55, unit: 'unit', stock: 0, low: 0 },
  { name: 'Club Sandwich', cat: 'Sandwiches', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0 },
  { name: 'Extra Polony', cat: 'Extras', type: 'Other', cost: 1, sell: 1, unit: 'unit', stock: 0, low: 0 },
  { name: 'Extra Special', cat: 'Extras', type: 'Other', cost: 1.5, sell: 2, unit: 'unit', stock: 0, low: 0 },
  { name: 'Extra Cheese', cat: 'Extras', type: 'Other', cost: 2.5, sell: 3, unit: 'unit', stock: 0, low: 0 },
  { name: 'Extra Russian', cat: 'Extras', type: 'Other', cost: 8, sell: 10, unit: 'unit', stock: 0, low: 0 },
];

const DEFAULT_RECIPES = {
  'Kota R15': [['Bread loaf', 0.15], ['Polony', 2], ['Atchaar', 1], ['Packaging', 1]],
  'Kota R20': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Vienna', 1], ['Packaging', 1]],
  'Kota R25': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Russian', 1], ['Packaging', 1]],
  'Kota R30': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Packaging', 1]],
  'Kota R35': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Vienna', 1], ['Packaging', 1]],
  'Kota R40': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Chicken pattie', 1], ['Vienna', 1], ['Packaging', 1]],
  'Plain Hotdog': [['Bun', 1], ['Vienna', 1], ['Packaging', 1]],
  'Hotdog Lettuce & Cheese': [['Bun', 1], ['Vienna', 1], ['Lettuce', 1], ['Cheese', 1], ['Packaging', 1]],
  'Chips Small': [['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Chips Medium': [['Potatoes', 250], ['Oil', 30], ['Packaging', 1]],
  'Chips Large': [['Potatoes', 350], ['Oil', 40], ['Packaging', 1]],
  'Chicken Burger': [['Bun', 1], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Packaging', 1]],
  'Beef Burger': [['Bun', 1], ['Beef pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Packaging', 1]],
  'Chicken Burger + Chips': [['Bun', 1], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Beef Burger + Chips': [['Bun', 1], ['Beef pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Club Sandwich': [['Bread loaf', 0.25], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Packaging', 1]],
  'Extra Polony': [['Polony', 1]],
  'Extra Special': [['Polony', 1], ['Atchaar', 1]],
  'Extra Cheese': [['Cheese', 1]],
  'Extra Russian': [['Russian', 1]],
};

function uid(p = 'id') { return p + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7); }
function today() { return new Date(); }
function iso(d = today()) {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function dow(d = today()) { return d.getDay(); } // 0 Sun
const DOW_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

function seed() {
  const items = DEFAULT_MENU.map(m => ({
    id: uid('it'), name: m.name, cat: m.cat, type: m.type, cost: m.cost, sell: m.sell,
    unit: m.unit, stock: m.stock, low: m.low, supplier: m.supplier || '', notes: '',
    archived: false, costHistory: [{ date: iso(), cost: m.cost }],
    buyUnit: m.buyUnit || m.unit, useUnit: m.useUnit || m.unit, conv: m.conv || 1
  }));
  const byName = Object.fromEntries(items.map(i => [i.name, i.id]));
  const recipes = {};
  Object.entries(DEFAULT_RECIPES).forEach(([prod, lines]) => {
    const pid = byName[prod];
    if (!pid) return;
    recipes[pid] = lines.map(([n, q]) => ({ itemId: byName[n], qty: q })).filter(x => x.itemId);
  });
  items.forEach(it => { if (recipes[it.id]) it.cost = recipeCost(it.id, items, recipes); });
  return {
    settings: {
      cafe: 'ELITES CAFÉ', currency: 'ZAR', locale: 'en-ZA',
      dailyTarget: 1500, fixedMonthly: 5500, float: 300, safetyDays: 1.5, leadDays: 1
    },
    items, recipes, movements: [], sales: [], expenses: [], book: [],
    workers: [
      { id: uid('wk'), name: 'Worker 1', role: 'Kitchen', payType: 'Daily', rate: 120, active: true },
      { id: uid('wk'), name: 'Worker 2', role: 'Front', payType: 'Daily', rate: 100, active: true },
    ],
    payments: [], waste: [], forecasts: [], // {date, expected, actual}
    notes: [], historyImported: false
  };
}

let data = null;
try {
  const v2 = JSON.parse(localStorage.getItem(KEY) || 'null');
  if (v2?.items?.length) data = v2;
  else {
    const v1 = JSON.parse(localStorage.getItem('stockly_elites_v1') || 'null');
    if (v1?.items?.length) { data = { ...seed(), ...v1, forecasts: v1.forecasts || [] }; }
  }
} catch (_) {}
if (!data?.items?.length) data = seed();
if (!Array.isArray(data.forecasts)) data.forecasts = [];
if (!Array.isArray(data.payments)) data.payments = [];
if (!Array.isArray(data.waste)) data.waste = [];

function save() { localStorage.setItem(KEY, JSON.stringify(data)); }

function M(n) {
  try {
    return new Intl.NumberFormat(data.settings.locale || 'en-ZA', {
      style: 'currency', currency: data.settings.currency || 'ZAR', maximumFractionDigits: 2
    }).format(Number(n) || 0);
  } catch { return 'R' + Number(n || 0).toLocaleString('en-ZA', { maximumFractionDigits: 2 }); }
}
function toast(t) {
  const x = document.getElementById('toast');
  x.textContent = t; x.classList.add('show');
  setTimeout(() => x.classList.remove('show'), 1700);
}
function itemById(id) { return (data.items || []).find(i => i.id === id); }
function activeItems() { return (data.items || []).filter(i => !i.archived); }

function recipeCost(productId, items = data.items, recipes = data.recipes) {
  return (recipes[productId] || []).reduce((s, l) => {
    const it = items.find(x => x.id === l.itemId);
    return s + (it ? Number(it.cost) * Number(l.qty) : 0);
  }, 0);
}
function refreshMenuCosts() {
  data.items.forEach(it => {
    if (data.recipes[it.id]?.length) it.cost = recipeCost(it.id);
  });
}

function stockValue() {
  return activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging')
    .reduce((s, i) => s + Number(i.stock) * Number(i.cost), 0);
}
function lowStock() {
  return activeItems().filter(i => (i.type === 'Ingredient' || i.type === 'Packaging') && i.low > 0 && i.stock > 0 && i.stock <= i.low);
}
function outStock() {
  return activeItems().filter(i => (i.type === 'Ingredient' || i.type === 'Packaging') && i.stock <= 0);
}

function salesOn(date) {
  return (data.sales || []).filter(s => s.date === date && s.status === 'confirmed');
}
function dayTotals(date = iso()) {
  const list = salesOn(date);
  let revenue = 0, cogs = 0, items = 0;
  list.forEach(s => {
    revenue += Number(s.revenue || 0);
    cogs += Number(s.cogs || 0);
    items += (s.lines || []).reduce((n, l) => n + Number(l.qty || 0), 0);
  });
  const expenses = (data.expenses || []).filter(e => e.date === date).reduce((s, e) => s + Number(e.amount || 0), 0);
  const wasteCost = (data.waste || []).filter(w => w.date === date).reduce((s, w) => s + Number(w.cost || 0), 0);
  const gross = revenue - cogs;
  return { revenue, cogs, gross, expenses, wasteCost, net: gross - expenses - wasteCost, items, count: list.length };
}

function addMovement(itemId, qty, reason, meta = {}) {
  const it = itemById(itemId);
  if (!it) return;
  it.stock = Number(it.stock || 0) + Number(qty);
  data.movements.unshift({
    id: uid('mv'), date: iso(), time: new Date().toISOString(),
    itemId, name: it.name, qty: Number(qty), reason, ...meta
  });
}
function bookEntry(type, category, amount, note, date = iso()) {
  data.book.unshift({ id: uid('bk'), date, type, category, amount: Number(amount), note: note || '' });
}

function canFulfill(productId, qty) {
  const missing = [];
  (data.recipes[productId] || []).forEach(l => {
    const it = itemById(l.itemId);
    const need = Number(l.qty) * Number(qty);
    if (!it || it.stock < need - 1e-9) missing.push({ name: it?.name || '?', need, have: it?.stock || 0 });
  });
  return { ok: !missing.length, missing };
}
function deductRecipe(productId, qty, reason = 'SALE') {
  (data.recipes[productId] || []).forEach(l => addMovement(l.itemId, -Number(l.qty) * Number(qty), reason, { productId }));
}

function sellLines(lines, payment = 'Cash', date = iso(), confirm = true) {
  let revenue = 0, cogs = 0;
  const detail = [];
  const missingAll = [];
  lines.forEach(l => {
    const it = itemById(l.itemId);
    if (!it || !l.qty) return;
    const check = canFulfill(l.itemId, l.qty);
    if (!check.ok) missingAll.push(...check.missing);
    const unitCost = data.recipes[it.id]?.length ? recipeCost(it.id) : Number(it.cost);
    revenue += Number(it.sell) * l.qty;
    cogs += unitCost * l.qty;
    detail.push({ itemId: it.id, name: it.name, qty: l.qty, sell: Number(it.sell), cost: unitCost, variation: l.variation || null });
  });
  if (missingAll.length && confirm) return { ok: false, missing: missingAll };
  const sale = { id: uid('sl'), date, payment, status: confirm ? 'confirmed' : 'draft', lines: detail, revenue, cogs, gross: revenue - cogs };
  if (confirm) {
    detail.forEach(l => {
      if (data.recipes[l.itemId]?.length) deductRecipe(l.itemId, l.qty, 'SALE');
      else addMovement(l.itemId, -l.qty, 'SALE');
    });
    data.sales.unshift(sale);
    bookEntry('Income', 'Sales', revenue, 'Sale ' + sale.id, date);
    bookEntry('Cost of sales', 'COGS', cogs, 'COGS ' + sale.id, date);
    // forecast accuracy
    const exp = expectedSalesForDate(date);
    data.forecasts.push({ date, expected: exp, actual: revenue });
    save();
  }
  return { ok: true, sale, missing: missingAll };
}

/* ---------- DIGITAL TWIN ENGINE ---------- */
function dailyRevenueByDow() {
  const buckets = Array.from({ length: 7 }, () => []);
  const byDay = {};
  (data.sales || []).filter(s => s.status === 'confirmed').forEach(s => {
    byDay[s.date] = (byDay[s.date] || 0) + Number(s.revenue || 0);
  });
  Object.entries(byDay).forEach(([date, rev]) => {
    const d = new Date(date + 'T12:00:00');
    if (!isNaN(d)) buckets[d.getDay()].push(rev);
  });
  return buckets.map((arr, i) => {
    if (!arr.length) {
      // fallback heuristic before history exists
      const base = Number(data.settings.dailyTarget) || 1500;
      const factors = [0.7, 0.55, 0.6, 0.58, 0.72, 0.95, 1.05]; // Sun..Sat relative to target scale
      return { dow: i, expected: Math.round(base * factors[i] * 0.55), samples: 0 };
    }
    const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
    return { dow: i, expected: Math.round(avg), samples: arr.length };
  });
}

function expectedSalesForDate(dateStr) {
  const d = new Date(dateStr + 'T12:00:00');
  const model = dailyRevenueByDow();
  return model[isNaN(d) ? dow() : d.getDay()].expected;
}

function expectedExpensesForDate(dateStr) {
  const month = dateStr.slice(0, 7);
  const monthExp = (data.expenses || []).filter(e => e.date.startsWith(month));
  if (monthExp.length) {
    const days = new Set(monthExp.map(e => e.date)).size || 1;
    const total = monthExp.reduce((s, e) => s + Number(e.amount), 0);
    return total / Math.max(days, 1);
  }
  // fixed monthly / 30 + typical daily variable
  return (Number(data.settings.fixedMonthly) || 5500) / 30;
}

function avgDailyUsage(itemId) {
  // from SALE movements last 30 days
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 30);
  const cut = iso(cutoff);
  const byDay = {};
  (data.movements || []).filter(m => m.itemId === itemId && m.reason === 'SALE' && m.date >= cut).forEach(m => {
    byDay[m.date] = (byDay[m.date] || 0) + Math.abs(Number(m.qty) || 0);
  });
  const vals = Object.values(byDay);
  if (!vals.length) return 0;
  return vals.reduce((a, b) => a + b, 0) / vals.length;
}

function stockRisks() {
  return activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging').map(it => {
    const use = avgDailyUsage(it.id);
    const daysLeft = use > 0 ? it.stock / use : (it.stock > 0 ? 99 : 0);
    const lead = Number(data.settings.leadDays) || 1;
    const safety = Number(data.settings.safetyDays) || 1.5;
    const reorderQty = use > 0 ? Math.ceil(use * (lead + safety + 2)) : 0;
    return {
      id: it.id, name: it.name, stock: it.stock, unit: it.unit,
      usePerDay: use, daysLeft, reorderQty,
      risk: daysLeft <= lead + safety ? (daysLeft <= lead ? 'critical' : 'warn') : 'ok'
    };
  }).filter(r => r.usePerDay > 0 || r.stock <= (itemById(r.id)?.low || 0))
    .sort((a, b) => a.daysLeft - b.daysLeft);
}

function forecastAccuracy() {
  const rows = (data.forecasts || []).filter(f => f.actual != null && f.expected > 0).slice(-30);
  if (!rows.length) return null;
  const scores = rows.map(f => {
    const err = Math.abs(f.actual - f.expected) / f.expected;
    return Math.max(0, 1 - err);
  });
  return Math.round(scores.reduce((a, b) => a + b, 0) / scores.length * 100);
}

function margin() {
  const recent = (data.sales || []).filter(s => s.status === 'confirmed').slice(0, 80);
  let rev = 0, cogs = 0;
  recent.forEach(s => { rev += s.revenue; cogs += s.cogs; });
  return rev > 0 ? (rev - cogs) / rev : 0.42;
}

function multiMonthForecast(months = 3, scenario = 'expected') {
  const m = margin();
  const avg = dailyRevenueByDow().reduce((s, x) => s + x.expected, 0) / 7;
  let growth = 0, costBump = 0;
  if (scenario === 'best') { growth = 0.12; costBump = -0.03; }
  if (scenario === 'worst') { growth = -0.15; costBump = 0.08; }
  const fixed = Number(data.settings.fixedMonthly) || 5500;
  const out = [];
  for (let i = 0; i < months; i++) {
    const d = new Date(); d.setMonth(d.getMonth() + i);
    const factor = Math.pow(1 + growth, i);
    const rev = avg * 26 * factor;
    const cogs = rev * (1 - m) * (1 + costBump);
    const exp = fixed * (1 + costBump * 0.5);
    out.push({
      label: d.toLocaleString('en', { month: 'short', year: '2-digit' }),
      rev, cogs, exp, profit: rev - cogs - exp
    });
  }
  return out;
}

function simulate(opts) {
  // opts: priceDelta, volumeDelta, wasteDelta, extraWorkerCost, extraHoursSalesBoost
  const base = multiMonthForecast(1, 'expected')[0];
  const price = 1 + (Number(opts.priceDelta) || 0) / 100;
  const vol = 1 + (Number(opts.volumeDelta) || 0) / 100;
  const wasteSave = (Number(opts.wasteDelta) || 0) / 100; // negative waste = savings
  const worker = Number(opts.extraWorkerCost) || 0;
  const boost = 1 + (Number(opts.salesBoost) || 0) / 100;
  const rev = base.rev * price * vol * boost;
  const cogs = base.cogs * vol * boost * (1 + wasteSave * 0.2);
  const exp = base.exp + worker;
  return {
    current: base,
    sim: { rev, cogs, exp, profit: rev - cogs - exp },
    delta: { rev: rev - base.rev, profit: (rev - cogs - exp) - base.profit }
  };
}

function productRanking() {
  const month = iso().slice(0, 7);
  const map = {};
  (data.sales || []).filter(s => s.date.startsWith(month) && s.status === 'confirmed').forEach(s => {
    (s.lines || []).forEach(l => {
      map[l.name] = map[l.name] || { qty: 0, rev: 0, cogs: 0 };
      map[l.name].qty += l.qty;
      map[l.name].rev += l.sell * l.qty;
      map[l.name].cogs += l.cost * l.qty;
    });
  });
  return Object.entries(map).map(([name, v]) => ({
    name, ...v, profit: v.rev - v.cogs, margin: v.rev ? (v.rev - v.cogs) / v.rev : 0
  })).sort((a, b) => b.profit - a.profit);
}

function menuEngineering() {
  const rank = productRanking();
  if (!rank.length) return [];
  const avgQty = rank.reduce((s, p) => s + p.qty, 0) / rank.length;
  const avgMargin = rank.reduce((s, p) => s + p.margin, 0) / rank.length;
  return rank.map(p => {
    const highSales = p.qty >= avgQty;
    const highMargin = p.margin >= avgMargin;
    let tag = 'Problem';
    if (highSales && highMargin) tag = 'Star';
    else if (highSales && !highMargin) tag = 'Workhorse';
    else if (!highSales && highMargin) tag = 'Hidden gem';
    return { ...p, tag };
  });
}

function askBusiness(q) {
  const key = (q || '').toLowerCase();
  const rank = productRanking();
  const risks = stockRisks();
  const t = dayTotals();
  const acc = forecastAccuracy();
  if (key.includes('profit') && (key.includes('most') || key.includes('best') || key.includes('which'))) {
    if (!rank.length) return 'Not enough sales data yet. Record sales or import past books.';
    const top = rank[0];
    return `${top.name} leads this month with ${M(top.profit)} profit (${(top.margin * 100).toFixed(0)}% margin) from ${top.qty} sold.`;
  }
  if (key.includes('run out') || key.includes('when will') || key.includes('stock last')) {
    const r = risks[0];
    if (!r) return 'No depletion risk detected from recent sales movements yet.';
    return `${r.name}: about ${r.daysLeft.toFixed(1)} days left at ~${r.usePerDay.toFixed(1)} ${r.unit}/day. Reorder ~${r.reorderQty} ${r.unit} soon.`;
  }
  if (key.includes('buy') || key.includes('reorder') || key.includes('how much stock')) {
    const need = risks.filter(r => r.risk !== 'ok').slice(0, 5);
    if (!need.length) return 'No urgent reorders from current usage patterns.';
    return need.map(r => `${r.name}: buy ~${r.reorderQty} ${r.unit} (${r.daysLeft.toFixed(1)} days left)`).join(' · ');
  }
  if (key.includes('cash') || key.includes('next week')) {
    const model = dailyRevenueByDow();
    let rev = 0;
    for (let i = 0; i < 7; i++) {
      const d = new Date(); d.setDate(d.getDate() + i);
      rev += model[d.getDay()].expected;
    }
    const exp = expectedExpensesForDate(iso()) * 7;
    return `Next 7 days expected sales ~${M(rev)}, expenses ~${M(exp)}, surplus ~${M(rev - exp)}.`;
  }
  if (key.includes('worker') || key.includes('hire')) {
    const cost = 120 * 5; // sample weekly
    return `A daily worker at R120 × 5 days adds ~${M(cost)}/week labour. Only worth it if extra capacity converts to more than that in gross profit.`;
  }
  if (key.includes('fall') || key.includes('20%') || key.includes('what if')) {
    const sim = simulate({ volumeDelta: -20 });
    return `If volume falls 20%: revenue ${M(sim.sim.rev)} (Δ ${M(sim.delta.rev)}), profit ${M(sim.sim.profit)} (Δ ${M(sim.delta.profit)}).`;
  }
  if (key.includes('today') || key.includes('expected')) {
    return `Today expected sales ${M(expectedSalesForDate(iso()))}, expenses ~${M(expectedExpensesForDate(iso()))}, actual so far ${M(t.revenue)}.`;
  }
  if (key.includes('accurate') || key.includes('forecast')) {
    return acc == null ? 'Forecast accuracy will appear after more days of expected vs actual sales.' : `Recent forecast accuracy ≈ ${acc}%.`;
  }
  if (key.includes('waste')) {
    const weekCut = new Date(); weekCut.setDate(weekCut.getDate() - 7);
    const w = (data.waste || []).filter(x => x.date >= iso(weekCut)).reduce((s, x) => s + Number(x.cost), 0);
    return `Waste cost in the last 7 days: ${M(w)}.`;
  }
  return 'Try: “Which product made the most profit?”, “When will potatoes run out?”, “How much stock should I buy?”, “What if sales fall 20%?”, or “How much cash next week?”';
}

function healthScore() {
  const t = dayTotals();
  const target = expectedSalesForDate(iso());
  const salesPart = Math.round(Math.min(1, t.revenue / Math.max(1, target)) * 25);
  const m = t.revenue ? t.gross / t.revenue : 0;
  const profitPart = Math.round(Math.min(1, Math.max(0, m) / 0.45) * 25);
  const low = lowStock().length, out = outStock().length;
  const stockPart = Math.round(Math.max(0, 25 - out * 8 - low * 2));
  const monthWaste = (data.waste || []).filter(w => w.date.slice(0, 7) === iso().slice(0, 7))
    .reduce((s, w) => s + Number(w.cost || 0), 0);
  const wastePart = Math.round(Math.max(0, 25 - Math.min(25, monthWaste / 40)));
  const total = salesPart + profitPart + stockPart + wastePart;
  return { total, parts: { sales: salesPart, profit: profitPart, stock: stockPart, waste: wastePart },
    label: total >= 80 ? 'Strong' : total >= 60 ? 'Healthy' : total >= 40 ? 'Fair' : 'Needs attention' };
}

/* ---------- UI ---------- */
let stockFilter = 'ALL';
let eodDraft = {};
let twinTab = 'overview';

function closeModal() { document.getElementById('modal')?.remove(); }
function openModal(title, body, onSubmit) {
  closeModal();
  const el = document.createElement('div');
  el.id = 'modal';
  el.innerHTML = `<div class="modal-backdrop" data-x="1"></div>
    <div class="modal-card"><div class="modal-head"><strong>${esc(title)}</strong>
    <button type="button" class="btn" data-x="1" style="padding:8px 10px">Close</button></div>
    <form id="modalForm" class="form">${body}${onSubmit ? '<button type="submit" class="btn primary">Save</button>' : ''}</form></div>`;
  document.body.appendChild(el);
  el.querySelectorAll('[data-x]').forEach(b => b.onclick = closeModal);
  if (onSubmit) document.getElementById('modalForm').onsubmit = e => { e.preventDefault(); if (onSubmit(e) !== false) closeModal(); };
}

function home() {
  const t = dayTotals();
  const h = healthScore();
  const exp = expectedSalesForDate(iso());
  const expEx = expectedExpensesForDate(iso());
  const pct = Math.min(100, Math.round(t.revenue / Math.max(1, exp) * 100));
  const low = lowStock(), out = outStock();
  document.getElementById('home').innerHTML = `
    <div class="title">${esc(data.settings.cafe)}</div>
    <div class="quote">Bookkeeping records the café. The Digital Twin models it — open Twin for forecasts and simulations.</div>
    <div class="card">
      <h2>TODAY · ACTUAL VS EXPECTED</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Actual sales</div><div class="val green">${M(t.revenue)}</div></div>
        <div class="stat"><div class="lbl">Expected sales</div><div class="val accent">${M(exp)}</div></div>
        <div class="stat"><div class="lbl">Gross profit</div><div class="val">${M(t.gross)}</div></div>
        <div class="stat"><div class="lbl">Expected expenses</div><div class="val orange">${M(expEx)}</div></div>
      </div>
      <div class="progress"><i style="width:${pct}%"></i></div>
      <div class="small">${pct}% of expected day · Net so far ${M(t.net)}</div>
    </div>
    <div class="card">
      <h2>STOCK</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Value</div><div class="val">${M(stockValue())}</div></div>
        <div class="stat"><div class="lbl">Low / Out</div><div class="val"><span class="yellow">${low.length}</span> / <span class="red">${out.length}</span></div></div>
      </div>
    </div>
    <div class="card">
      <h2>HEALTH · ${h.total}/100 · ${h.label}</h2>
      <div class="progress"><i style="width:${h.total}%"></i></div>
      <div class="small">Sales ${h.parts.sales}/25 · Profit ${h.parts.profit}/25 · Stock ${h.parts.stock}/25 · Waste ${h.parts.waste}/25</div>
    </div>
    <div class="row">
      <button class="btn" data-go="twin">Open Digital Twin</button>
      <button class="btn primary" data-go="sales">Record sales</button>
    </div>`;
}

function stock() {
  const filters = ['ALL', 'Ingredients', 'Menu', 'Low', 'Out', 'Moves', 'Waste'];
  let list = activeItems();
  if (stockFilter === 'Ingredients') list = list.filter(i => i.type === 'Ingredient' || i.type === 'Packaging');
  else if (stockFilter === 'Menu') list = list.filter(i => i.type === 'Menu Product' || i.cat === 'Extras');
  else if (stockFilter === 'Low') list = lowStock();
  else if (stockFilter === 'Out') list = outStock();
  let body = '';
  if (stockFilter === 'Moves') {
    body = (data.movements || []).slice(0, 40).map(m => `
      <div class="item"><div><b>${esc(m.name)}</b><div class="small">${esc(m.reason)} · ${esc(m.date)}</div></div>
      <b class="${m.qty >= 0 ? 'green' : 'orange'}">${m.qty >= 0 ? '+' : ''}${m.qty}</b></div>`).join('') || '<div class="empty">No movements.</div>';
  } else if (stockFilter === 'Waste') {
    body = `<button class="btn primary" data-action="waste-add" style="margin-bottom:8px">Record waste</button>
      ${(data.waste || []).slice(0, 25).map(w => `
        <div class="item"><div><b>${esc(w.name)} × ${w.qty}</b><div class="small">${esc(w.reason)} · ${esc(w.date)}</div></div>
        <b class="red">${M(w.cost)}</b></div>`).join('') || '<div class="empty">No waste.</div>'}`;
  } else {
    body = list.map(i => {
      const isIng = i.type === 'Ingredient' || i.type === 'Packaging';
      let badge = '';
      if (isIng && i.stock <= 0) badge = '<span class="badge out">OUT</span>';
      else if (isIng && i.low > 0 && i.stock <= i.low) badge = '<span class="badge low">LOW</span>';
      const dual = i.buyUnit && i.conv > 1 ? ` · ${i.buyUnit}→${i.useUnit} (×${i.conv})` : '';
      return `<div class="item" style="flex-wrap:wrap">
        <div style="flex:1;min-width:140px"><b>${esc(i.name)}</b> ${badge}
        <div class="small">${esc(i.cat)}${isIng ? ` · ${i.stock} ${esc(i.unit)}` : ''}${i.sell ? ` · ${M(i.sell)}` : ''}${dual}</div></div>
        <div class="row" style="width:100%;margin-top:6px">
          <button class="btn" data-action="item-edit" data-id="${i.id}">Edit</button>
          ${isIng ? `<button class="btn" data-action="restock" data-id="${i.id}">Restock</button>` : ''}
          <button class="btn danger" data-action="item-del" data-id="${i.id}">Archive</button>
        </div></div>`;
    }).join('') || '<div class="empty">Empty.</div>';
  }
  document.getElementById('stock').innerHTML = `
    <div class="title">Stock</div>
    <div class="chips">${filters.map(f => `<button class="chip ${stockFilter === f ? 'on' : ''}" data-action="stock-filter" data-f="${f}">${f}</button>`).join('')}</div>
    <div class="row" style="margin-bottom:10px">
      <button class="btn primary" data-action="item-add">Add item</button>
      <button class="btn" data-action="stock-count">Stock count</button>
    </div>${body}`;
}

function sales() {
  const menu = activeItems().filter(i => i.sell > 0 && (i.type === 'Menu Product' || i.cat === 'Extras'));
  const groups = {};
  menu.forEach(i => { (groups[i.cat] = groups[i.cat] || []).push(i); });
  const t = dayTotals();
  document.getElementById('sales').innerHTML = `
    <div class="title">Sales</div>
    <div class="card"><h2>TODAY</h2>
      <div class="grid3">
        <div class="stat"><div class="lbl">Revenue</div><div class="val green">${M(t.revenue)}</div></div>
        <div class="stat"><div class="lbl">COGS</div><div class="val orange">${M(t.cogs)}</div></div>
        <div class="stat"><div class="lbl">Gross</div><div class="val accent">${M(t.gross)}</div></div>
      </div>
      <div class="row" style="margin-top:8px">
        <button class="btn" data-action="history-sale">Add past day sales</button>
        <button class="btn" data-action="history-expense">Add past expense</button>
      </div>
    </div>
    <div class="card"><h2>QUICK SALE</h2>
      <form class="form" id="quickSale">
        <select id="qsItem">${menu.map(i => `<option value="${i.id}">${esc(i.name)} · ${M(i.sell)}</option>`).join('')}</select>
        <div class="row">
          <input id="qsQty" type="number" min="1" value="1" required>
          <select id="qsPay"><option>Cash</option><option>Card</option><option>EFT</option></select>
        </div>
        <button class="btn primary" type="submit">Sell now</button>
      </form>
    </div>
    <div class="card"><h2>END OF DAY</h2>
      ${Object.entries(groups).map(([cat, items]) => `
        <div style="margin:8px 0 4px;font-size:12px;font-weight:800;color:var(--muted)">${esc(cat)}</div>
        ${items.map(i => `<div class="item"><div><b>${esc(i.name)}</b><div class="small">${M(i.sell)}</div></div>
          <div class="qty">
            <button type="button" data-action="eod-dec" data-id="${i.id}">−</button>
            <input type="number" min="0" value="${eodDraft[i.id] || 0}" data-eod="${i.id}" style="width:52px;text-align:center;padding:8px">
            <button type="button" data-action="eod-inc" data-id="${i.id}">+</button>
          </div></div>`).join('')}
      `).join('')}
      <div class="row" style="margin-top:10px">
        <button class="btn" data-action="eod-calc">Calculate</button>
        <button class="btn primary" data-action="eod-confirm">Confirm day</button>
      </div>
      <div id="eodPreview" class="small" style="margin-top:8px"></div>
    </div>
    <div class="card"><h2>RECENT</h2>
      ${(data.sales || []).slice(0, 12).map(s => `
        <div class="item"><div><b>${M(s.revenue)}</b><div class="small">${esc(s.date)} · ${esc(s.payment)}</div></div>
        <span class="badge ok">OK</span></div>`).join('') || '<div class="empty">No sales.</div>'}
    </div>`;
  document.getElementById('quickSale').onsubmit = e => {
    e.preventDefault();
    const res = sellLines([{
      itemId: document.getElementById('qsItem').value,
      qty: Number(document.getElementById('qsQty').value) || 0
    }], document.getElementById('qsPay').value);
    if (!res.ok) { toast('Insufficient stock'); return; }
    toast('Sale recorded'); sales(); home();
  };
  document.querySelectorAll('[data-eod]').forEach(inp => {
    inp.onchange = () => { eodDraft[inp.dataset.eod] = Number(inp.value) || 0; };
  });
}

function calcEod() {
  document.querySelectorAll('[data-eod]').forEach(inp => { eodDraft[inp.dataset.eod] = Number(inp.value) || 0; });
  const lines = Object.entries(eodDraft).filter(([, q]) => q > 0).map(([itemId, qty]) => ({ itemId, qty }));
  if (!lines.length) return null;
  let revenue = 0, cogs = 0, items = 0;
  lines.forEach(l => {
    const it = itemById(l.itemId); if (!it) return;
    const unitCost = data.recipes[it.id]?.length ? recipeCost(it.id) : Number(it.cost);
    revenue += Number(it.sell) * l.qty; cogs += unitCost * l.qty; items += l.qty;
  });
  return { lines, revenue, cogs, gross: revenue - cogs, items };
}

function twin() {
  const exp = expectedSalesForDate(iso());
  const expEx = expectedExpensesForDate(iso());
  const t = dayTotals();
  const model = dailyRevenueByDow();
  const risks = stockRisks().slice(0, 6);
  const acc = forecastAccuracy();
  const best = multiMonthForecast(3, 'best');
  const expM = multiMonthForecast(3, 'expected');
  const worst = multiMonthForecast(3, 'worst');
  const eng = menuEngineering().slice(0, 8);

  const tabs = [
    ['overview', 'Overview'],
    ['forecast', 'Forecast'],
    ['sim', 'Simulate'],
    ['ask', 'Ask'],
    ['history', 'Past data']
  ];

  let body = '';
  if (twinTab === 'overview') {
    body = `
      <div class="card">
        <h2>DIGITAL TWIN · TODAY</h2>
        <div class="grid2">
          <div class="stat"><div class="lbl">Expected sales</div><div class="val accent">${M(exp)}</div></div>
          <div class="stat"><div class="lbl">Actual sales</div><div class="val green">${M(t.revenue)}</div></div>
          <div class="stat"><div class="lbl">Expected expenses</div><div class="val">${M(expEx)}</div></div>
          <div class="stat"><div class="lbl">Expected profit</div><div class="val">${M(exp - expEx)}</div></div>
        </div>
        ${acc != null ? `<div class="small" style="margin-top:8px">Forecast accuracy (recent): <b>${acc}%</b></div>` : '<div class="small" style="margin-top:8px">Accuracy improves as you record more days.</div>'}
      </div>
      <div class="card">
        <h2>EXPECTED BY DAY OF WEEK</h2>
        ${model.map(x => `
          <div class="barrow"><span>${DOW_NAMES[x.dow].slice(0, 3)}</span>
          <div class="bar"><i style="width:${Math.min(100, x.expected / Math.max(1, ...model.map(m => m.expected)) * 100)}%"></i></div>
          <b>${M(x.expected)}</b></div>
          <div class="small" style="margin:-2px 0 6px">${x.samples ? x.samples + ' sample days' : 'heuristic until history grows'}</div>
        `).join('')}
      </div>
      <div class="card">
        <h2>STOCK RISKS</h2>
        ${risks.length ? risks.map(r => `
          <div class="item">
            <div><b>${esc(r.name)}</b>
            <div class="small">~${r.usePerDay.toFixed(1)} ${esc(r.unit)}/day · ${r.daysLeft.toFixed(1)} days left · reorder ~${r.reorderQty}</div></div>
            <span class="badge ${r.risk === 'critical' ? 'out' : r.risk === 'warn' ? 'low' : 'ok'}">${r.risk.toUpperCase()}</span>
          </div>`).join('') : '<div class="empty">Sell more days to learn depletion rates.</div>'}
      </div>
      <div class="card">
        <h2>MENU ENGINEERING</h2>
        ${eng.length ? eng.map(p => `
          <div class="item"><div><b>${esc(p.name)}</b><div class="small">${p.qty} sold · ${(p.margin * 100).toFixed(0)}% margin</div></div>
          <span class="badge ${p.tag === 'Star' ? 'ok' : p.tag === 'Problem' ? 'out' : 'low'}">${p.tag}</span></div>`).join('') : '<div class="empty">Need monthly sales for classification.</div>'}
      </div>`;
  } else if (twinTab === 'forecast') {
    body = `
      <div class="card">
        <h2>BEST / EXPECTED / WORST · 3 MONTHS</h2>
        <div class="small" style="margin-bottom:8px">Projections from day-of-week patterns and margins. Not guarantees.</div>
        ${[0, 1, 2].map(i => `
          <div class="item" style="flex-wrap:wrap">
            <b style="width:100%">${esc(expM[i].label)}</b>
            <div class="grid3" style="width:100%;margin-top:6px">
              <div class="stat"><div class="lbl">Best profit</div><div class="val green">${M(best[i].profit)}</div></div>
              <div class="stat"><div class="lbl">Expected</div><div class="val accent">${M(expM[i].profit)}</div></div>
              <div class="stat"><div class="lbl">Worst</div><div class="val red">${M(worst[i].profit)}</div></div>
            </div>
            <div class="small" style="margin-top:4px">Expected revenue ${M(expM[i].rev)}</div>
          </div>`).join('')}
      </div>
      <div class="card">
        <h2>THIS WEEK (EXPECTED)</h2>
        ${Array.from({ length: 7 }, (_, i) => {
          const d = new Date(); d.setDate(d.getDate() + i);
          const e = expectedSalesForDate(iso(d));
          return `<div class="item"><span>${DOW_NAMES[d.getDay()]} ${d.getDate()}</span><b class="accent">${M(e)}</b></div>`;
        }).join('')}
      </div>`;
  } else if (twinTab === 'sim') {
    body = `
      <div class="card">
        <h2>SIMULATION LAB</h2>
        <div class="small" style="margin-bottom:8px">Test “what if” changes. Combined effects apply to a one-month expected baseline.</div>
        <form class="form" id="simForm">
          <label class="small">Price change %<input id="simPrice" type="number" step="1" value="0" placeholder="e.g. 10"></label>
          <label class="small">Volume change %<input id="simVol" type="number" step="1" value="0" placeholder="e.g. -5"></label>
          <label class="small">Sales boost % (hours/promo)<input id="simBoost" type="number" step="1" value="0"></label>
          <label class="small">Extra monthly labour cost<input id="simWorker" type="number" step="1" value="0"></label>
          <label class="small">Waste change % (negative = less waste)<input id="simWaste" type="number" step="1" value="0"></label>
          <button class="btn primary" type="submit">Run simulation</button>
        </form>
        <div id="simOut" class="small" style="margin-top:10px"></div>
      </div>`;
  } else if (twinTab === 'ask') {
    body = `
      <div class="card">
        <h2>ASK THE BUSINESS</h2>
        <div class="small" style="margin-bottom:8px">Structured answers from your data — not generic advice.</div>
        <form class="form" id="askForm">
          <select id="askPick">
            <option>Which product made the most profit?</option>
            <option>When will my stock run out?</option>
            <option>How much stock should I buy?</option>
            <option>How much cash will I need next week?</option>
            <option>What if sales fall 20%?</option>
            <option>Can I afford another worker?</option>
            <option>What is expected today?</option>
            <option>How accurate are forecasts?</option>
            <option>How much waste this week?</option>
          </select>
          <input id="askFree" placeholder="Or type your own question">
          <button class="btn primary" type="submit">Ask</button>
        </form>
        <div id="askOut" class="infobox" style="display:none"></div>
      </div>`;
  } else {
    body = `
      <div class="card">
        <h2>IMPORT PAST BOOKS</h2>
        <div class="small" style="margin-bottom:8px">
          Enter historical days from your paper books so the Digital Twin can learn weekday patterns, margins and forecasts faster.
          Past sales here update the model without changing today’s live stock (no ingredient deduction).
        </div>
        <button class="btn primary" data-action="history-sale">Add past sales day</button>
        <button class="btn" data-action="history-expense" style="margin-top:8px">Add past expense</button>
        <button class="btn" data-action="history-bulk" style="margin-top:8px">Bulk paste daily totals</button>
      </div>
      <div class="card">
        <h2>RECENT HISTORICAL DAYS</h2>
        ${Object.entries((data.sales || []).filter(s => s.status === 'confirmed').reduce((m, s) => {
          m[s.date] = (m[s.date] || 0) + s.revenue; return m;
        }, {})).sort((a, b) => b[0].localeCompare(a[0])).slice(0, 20).map(([d, r]) => `
          <div class="item"><span>${esc(d)}</span><b class="green">${M(r)}</b></div>
        `).join('') || '<div class="empty">No sales history yet.</div>'}
      </div>`;
  }

  document.getElementById('twin').innerHTML = `
    <div class="title">Digital Twin</div>
    <div class="chips">${tabs.map(([id, lab]) => `
      <button class="chip ${twinTab === id ? 'on' : ''}" data-action="twin-tab" data-t="${id}">${lab}</button>`).join('')}
    </div>${body}`;

  if (twinTab === 'sim') {
    document.getElementById('simForm').onsubmit = e => {
      e.preventDefault();
      const r = simulate({
        priceDelta: document.getElementById('simPrice').value,
        volumeDelta: document.getElementById('simVol').value,
        salesBoost: document.getElementById('simBoost').value,
        extraWorkerCost: document.getElementById('simWorker').value,
        wasteDelta: document.getElementById('simWaste').value
      });
      document.getElementById('simOut').innerHTML = `
        <div class="okbox">
          <b>Baseline month</b><br>Rev ${M(r.current.rev)} · Profit ${M(r.current.profit)}<br><br>
          <b>Simulation</b><br>Rev ${M(r.sim.rev)} (Δ ${M(r.delta.rev)}) · Profit ${M(r.sim.profit)} (Δ ${M(r.delta.profit)})
        </div>`;
    };
  }
  if (twinTab === 'ask') {
    document.getElementById('askForm').onsubmit = e => {
      e.preventDefault();
      const q = document.getElementById('askFree').value.trim() || document.getElementById('askPick').value;
      const out = document.getElementById('askOut');
      out.style.display = 'block';
      out.textContent = askBusiness(q);
    };
  }
}

function book() {
  const month = iso().slice(0, 7);
  const monthSales = (data.sales || []).filter(s => s.date.startsWith(month) && s.status === 'confirmed')
    .reduce((s, x) => ({ rev: s.rev + x.revenue, cogs: s.cogs + x.cogs }), { rev: 0, cogs: 0 });
  const monthExp = (data.expenses || []).filter(e => e.date.startsWith(month)).reduce((s, e) => s + Number(e.amount), 0);
  document.getElementById('book').innerHTML = `
    <div class="title">Book</div>
    <div class="card"><h2>THIS MONTH</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Revenue</div><div class="val green">${M(monthSales.rev)}</div></div>
        <div class="stat"><div class="lbl">COGS</div><div class="val orange">${M(monthSales.cogs)}</div></div>
        <div class="stat"><div class="lbl">Gross</div><div class="val accent">${M(monthSales.rev - monthSales.cogs)}</div></div>
        <div class="stat"><div class="lbl">Expenses</div><div class="val">${M(monthExp)}</div></div>
      </div>
      <div class="med" style="margin-top:8px">Net ≈ ${M(monthSales.rev - monthSales.cogs - monthExp)}</div>
    </div>
    <div class="card"><h2>ADD EXPENSE</h2>
      <form class="form" id="expForm">
        <select id="exCat"><option>Rent</option><option>Electricity</option><option>Transport</option><option>Worker pay</option><option>Packaging</option><option>Other</option></select>
        <input id="exAmt" type="number" min="0.01" step="0.01" placeholder="Amount" required>
        <input id="exNote" placeholder="Description">
        <button class="btn primary" type="submit">Save</button>
      </form>
    </div>
    <div class="card"><h2>LEDGER</h2>
      ${(data.book || []).slice(0, 35).map(b => `
        <div class="item"><div><b>${esc(b.category)}</b><div class="small">${esc(b.type)} · ${esc(b.date)} · ${esc(b.note || '')}</div></div>
        <b class="${b.type === 'Income' ? 'green' : 'orange'}">${M(b.amount)}</b></div>`).join('') || '<div class="empty">Empty.</div>'}
    </div>`;
  document.getElementById('expForm').onsubmit = e => {
    e.preventDefault();
    const amount = Number(document.getElementById('exAmt').value);
    const category = document.getElementById('exCat').value;
    const note = document.getElementById('exNote').value.trim();
    data.expenses.unshift({ id: uid('ex'), date: iso(), amount, category, note, payment: 'Cash' });
    bookEntry('Expense', category, amount, note);
    save(); toast('Expense saved'); book(); home();
  };
}

function more() {
  document.getElementById('more').innerHTML = `
    <div class="title">More</div>
    <div class="card"><h2>WORKERS</h2>
      ${(data.workers || []).map(w => `
        <div class="item"><div><b>${esc(w.name)}</b><div class="small">${esc(w.role)} · ${esc(w.payType)} · ${M(w.rate)}</div></div>
        <span class="badge ok">Active</span></div>`).join('')}
      <button class="btn" data-action="worker-pay" style="margin-top:8px">Record worker payment</button>
    </div>
    <div class="card"><h2>SETTINGS</h2>
      <form class="form" id="setForm">
        <label class="small">Café name<input id="setCafe" value="${esc(data.settings.cafe || '')}"></label>
        <label class="small">Daily target (fallback)<input id="setTarget" type="number" value="${data.settings.dailyTarget || 1500}"></label>
        <label class="small">Fixed monthly costs<input id="setFixed" type="number" value="${data.settings.fixedMonthly || 5500}"></label>
        <label class="small">Supplier lead days<input id="setLead" type="number" value="${data.settings.leadDays || 1}"></label>
        <label class="small">Safety stock days<input id="setSafety" type="number" step="0.1" value="${data.settings.safetyDays || 1.5}"></label>
        <button class="btn primary" type="submit">Save</button>
      </form>
    </div>
    <div class="card"><h2>BACKUP</h2>
      <div class="row">
        <button class="btn" data-action="export">Export JSON</button>
        <label class="btn">Import<input type="file" id="importFile" accept="application/json" hidden></label>
      </div>
      <button class="btn danger" style="margin-top:8px" data-action="reset">Reset demo data</button>
    </div>`;
  document.getElementById('setForm').onsubmit = e => {
    e.preventDefault();
    data.settings.cafe = document.getElementById('setCafe').value.trim() || 'ELITES CAFÉ';
    data.settings.dailyTarget = Number(document.getElementById('setTarget').value) || 1500;
    data.settings.fixedMonthly = Number(document.getElementById('setFixed').value) || 5500;
    data.settings.leadDays = Number(document.getElementById('setLead').value) || 1;
    data.settings.safetyDays = Number(document.getElementById('setSafety').value) || 1.5;
    save(); toast('Saved'); more(); home();
  };
  document.getElementById('importFile').onchange = e => {
    const f = e.target.files?.[0]; if (!f) return;
    const r = new FileReader();
    r.onload = () => { try { data = JSON.parse(r.result); save(); location.reload(); } catch { toast('Invalid'); } };
    r.readAsText(f);
  };
}

function openHistorySale() {
  const menu = activeItems().filter(i => i.sell > 0);
  openModal('Past sales day (from books)', `
    <div class="infobox">Records history for the Digital Twin. Does <b>not</b> deduct current stock — use for past paper books.</div>
    <label class="small">Date<input id="h_date" type="date" required value="${iso()}"></label>
    <label class="small">Product
      <select id="h_item">${menu.map(i => `<option value="${i.id}">${esc(i.name)} · ${M(i.sell)}</option>`).join('')}</select>
    </label>
    <label class="small">Quantity sold<input id="h_qty" type="number" min="1" value="1" required></label>
    <label class="small">Or total revenue only (optional override)<input id="h_rev" type="number" min="0" step="0.01" placeholder="Leave blank to use price × qty"></label>
    <label class="small">Payment<select id="h_pay"><option>Cash</option><option>Card</option><option>EFT</option><option>Mixed</option></select></label>
  `, () => {
    const date = document.getElementById('h_date').value;
    const itemId = document.getElementById('h_item').value;
    const qty = Number(document.getElementById('h_qty').value) || 0;
    const it = itemById(itemId);
    if (!it || !date || qty <= 0) return false;
    const unitCost = data.recipes[it.id]?.length ? recipeCost(it.id) : Number(it.cost);
    let revenue = Number(document.getElementById('h_rev').value);
    if (!revenue) revenue = Number(it.sell) * qty;
    const cogs = unitCost * qty;
    const sale = {
      id: uid('sl'), date, payment: document.getElementById('h_pay').value,
      status: 'confirmed', historical: true,
      lines: [{ itemId: it.id, name: it.name, qty, sell: revenue / qty, cost: unitCost }],
      revenue, cogs, gross: revenue - cogs
    };
    data.sales.unshift(sale);
    bookEntry('Income', 'Sales', revenue, 'Historical sale', date);
    bookEntry('Cost of sales', 'COGS', cogs, 'Historical COGS', date);
    data.forecasts.push({ date, expected: expectedSalesForDate(date), actual: revenue });
    data.historyImported = true;
    save(); toast('Past sales saved'); twin(); home();
    return true;
  });
}

function openHistoryExpense() {
  openModal('Past expense (from books)', `
    <label class="small">Date<input id="he_date" type="date" required value="${iso()}"></label>
    <label class="small">Category
      <select id="he_cat"><option>Rent</option><option>Electricity</option><option>Water</option><option>Transport</option>
      <option>Worker pay</option><option>Stock purchase</option><option>Packaging</option><option>Other</option></select>
    </label>
    <label class="small">Amount<input id="he_amt" type="number" min="0.01" step="0.01" required></label>
    <label class="small">Note<input id="he_note" placeholder="From paper book"></label>
  `, () => {
    const date = document.getElementById('he_date').value;
    const amount = Number(document.getElementById('he_amt').value);
    const category = document.getElementById('he_cat').value;
    const note = document.getElementById('he_note').value.trim();
    if (!date || !amount) return false;
    data.expenses.unshift({ id: uid('ex'), date, amount, category, note: note || 'Historical', payment: 'Cash', historical: true });
    bookEntry('Expense', category, amount, note || 'Historical', date);
    data.historyImported = true;
    save(); toast('Past expense saved'); twin(); book();
    return true;
  });
}

function openHistoryBulk() {
  openModal('Bulk daily totals', `
    <div class="infobox">Paste lines: <code>YYYY-MM-DD, revenue</code> or <code>YYYY-MM-DD, revenue, expenses</code><br>
    Example:<br>2026-08-01, 1200<br>2026-08-02, 980, 150</div>
    <label class="small">Lines<textarea id="bulk" placeholder="2026-08-01, 1200"></textarea></label>
  `, () => {
    const text = document.getElementById('bulk').value.trim();
    if (!text) return false;
    let n = 0;
    text.split(/\n+/).forEach(line => {
      const parts = line.split(/[,\t;]/).map(x => x.trim()).filter(Boolean);
      if (parts.length < 2) return;
      const date = parts[0];
      const rev = Number(parts[1]);
      const exp = parts[2] != null ? Number(parts[2]) : 0;
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || isNaN(rev)) return;
      const m = margin();
      const cogs = rev * (1 - m);
      data.sales.unshift({
        id: uid('sl'), date, payment: 'Mixed', status: 'confirmed', historical: true, bulk: true,
        lines: [{ itemId: 'bulk', name: 'Bulk day total', qty: 1, sell: rev, cost: cogs }],
        revenue: rev, cogs, gross: rev - cogs
      });
      bookEntry('Income', 'Sales', rev, 'Bulk historical', date);
      bookEntry('Cost of sales', 'COGS', cogs, 'Bulk estimated COGS', date);
      if (exp > 0) {
        data.expenses.unshift({ id: uid('ex'), date, amount: exp, category: 'Other', note: 'Bulk historical', historical: true });
        bookEntry('Expense', 'Other', exp, 'Bulk historical', date);
      }
      data.forecasts.push({ date, expected: expectedSalesForDate(date), actual: rev });
      n++;
    });
    if (!n) { toast('No valid lines'); return false; }
    data.historyImported = true;
    save(); toast(`Imported ${n} days`); twin(); home();
    return true;
  });
}

function openItemForm(existing) {
  const it = existing || { id: '', name: '', cat: 'Ingredients', type: 'Ingredient', cost: 0, sell: 0, unit: 'unit', stock: 0, low: 5, supplier: '', buyUnit: '', useUnit: '', conv: 1 };
  openModal(existing ? 'Edit item' : 'Add item', `
    <label class="small">Name<input id="i_name" required value="${esc(it.name)}"></label>
    <div class="row">
      <label class="small">Category<input id="i_cat" value="${esc(it.cat)}"></label>
      <label class="small">Type<select id="i_type">${['Ingredient', 'Menu Product', 'Drink', 'Packaging', 'Other'].map(t => `<option ${it.type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
    </div>
    <div class="row">
      <label class="small">Cost<input id="i_cost" type="number" min="0" step="0.01" value="${it.cost}"></label>
      <label class="small">Sell<input id="i_sell" type="number" min="0" step="0.01" value="${it.sell}"></label>
    </div>
    <div class="row">
      <label class="small">Stock unit<input id="i_unit" value="${esc(it.unit)}"></label>
      <label class="small">Stock qty<input id="i_stock" type="number" step="any" value="${it.stock}"></label>
    </div>
    <div class="row">
      <label class="small">Buy unit<input id="i_buy" value="${esc(it.buyUnit || '')}" placeholder="kg"></label>
      <label class="small">Use unit<input id="i_use" value="${esc(it.useUnit || '')}" placeholder="slices"></label>
    </div>
    <label class="small">Conversion (buy → use)<input id="i_conv" type="number" min="0" step="any" value="${it.conv || 1}"></label>
    <label class="small">Low stock<input id="i_low" type="number" value="${it.low}"></label>
  `, () => {
    const name = document.getElementById('i_name').value.trim();
    if (!name) return false;
    const cost = Number(document.getElementById('i_cost').value) || 0;
    const row = {
      id: it.id || uid('it'), name,
      cat: document.getElementById('i_cat').value.trim() || 'Other',
      type: document.getElementById('i_type').value,
      cost, sell: Number(document.getElementById('i_sell').value) || 0,
      unit: document.getElementById('i_unit').value.trim() || 'unit',
      stock: Number(document.getElementById('i_stock').value) || 0,
      low: Number(document.getElementById('i_low').value) || 0,
      buyUnit: document.getElementById('i_buy').value.trim(),
      useUnit: document.getElementById('i_use').value.trim(),
      conv: Number(document.getElementById('i_conv').value) || 1,
      archived: false, costHistory: it.costHistory || [{ date: iso(), cost }],
      supplier: it.supplier || '', notes: it.notes || ''
    };
    if (existing && Number(existing.cost) !== cost) row.costHistory = [...(existing.costHistory || []), { date: iso(), cost }];
    const idx = data.items.findIndex(x => x.id === row.id);
    if (idx >= 0) data.items[idx] = { ...data.items[idx], ...row };
    else data.items.push(row);
    refreshMenuCosts(); save(); toast('Saved'); stock();
    return true;
  });
}

function openRestock(id) {
  const it = itemById(id); if (!it) return;
  openModal('Restock · ' + it.name, `
    <div class="small">Current: <b>${it.stock} ${esc(it.unit)}</b>${it.conv > 1 ? ` · buy in ${esc(it.buyUnit || '')}` : ''}</div>
    <label class="small">Quantity (${esc(it.unit)})<input id="r_qty" type="number" min="0.01" step="any" required></label>
    <label class="small">Cost / ${esc(it.unit)}<input id="r_cost" type="number" min="0" step="0.01" value="${it.cost}"></label>
  `, () => {
    const qty = Number(document.getElementById('r_qty').value) || 0;
    const cost = Number(document.getElementById('r_cost').value) || 0;
    if (qty <= 0) return false;
    if (cost !== Number(it.cost)) { it.costHistory = [...(it.costHistory || []), { date: iso(), cost }]; it.cost = cost; }
    addMovement(it.id, qty, 'PURCHASE', { cost, total: cost * qty });
    bookEntry('Cost of sales', 'Inventory purchase', cost * qty, 'Restock ' + it.name);
    refreshMenuCosts(); save(); toast('Restocked'); stock(); home();
    return true;
  });
}

function openWaste() {
  const ings = activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging');
  openModal('Record waste', `
    <select id="w_item">${ings.map(i => `<option value="${i.id}">${esc(i.name)}</option>`).join('')}</select>
    <input id="w_qty" type="number" min="0.01" step="any" required placeholder="Qty">
    <select id="w_reason"><option>Expired</option><option>Burnt</option><option>Damaged</option><option>Spoiled</option><option>Other</option></select>
  `, () => {
    const id = document.getElementById('w_item').value;
    const qty = Number(document.getElementById('w_qty').value) || 0;
    const reason = document.getElementById('w_reason').value;
    const it = itemById(id); if (!it || qty <= 0) return false;
    const cost = qty * Number(it.cost);
    addMovement(id, -qty, 'WASTE', { reason });
    data.waste.unshift({ id: uid('ws'), date: iso(), itemId: id, name: it.name, qty, cost, reason });
    bookEntry('Adjustments', 'Waste', cost, reason + ' · ' + it.name);
    save(); toast('Waste recorded'); stock();
    return true;
  });
}

function openStockCount() {
  const ings = activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging').slice(0, 30);
  openModal('Stock count', ings.map(i => `
    <div class="item"><div><b>${esc(i.name)}</b><div class="small">System ${i.stock}</div></div>
    <input data-count="${i.id}" type="number" step="any" value="${i.stock}" style="width:80px;text-align:center"></div>`).join(''), () => {
    document.querySelectorAll('[data-count]').forEach(inp => {
      const it = itemById(inp.dataset.count); if (!it) return;
      const physical = Number(inp.value); if (isNaN(physical)) return;
      const diff = physical - Number(it.stock);
      if (Math.abs(diff) < 1e-9) return;
      addMovement(it.id, diff, 'ADJUSTMENT', { note: 'Stock count' });
    });
    save(); toast('Count saved'); stock(); return true;
  });
}

function show(id) {
  document.querySelectorAll('.screen').forEach(x => x.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.nav button').forEach(x => x.classList.toggle('active', x.dataset.s === id));
  ({ home, stock, sales, twin, book, more }[id] || home)();
}

document.addEventListener('click', e => {
  const go = e.target.closest('[data-go]');
  if (go) { show(go.dataset.go); return; }
  const t = e.target.closest('[data-action]');
  if (!t) return;
  const a = t.dataset.action;
  if (a === 'stock-filter') { stockFilter = t.dataset.f; stock(); }
  else if (a === 'twin-tab') { twinTab = t.dataset.t; twin(); }
  else if (a === 'item-add') openItemForm(null);
  else if (a === 'item-edit') openItemForm(itemById(t.dataset.id));
  else if (a === 'item-del') {
    const it = itemById(t.dataset.id); if (!it || !confirm('Archive ' + it.name + '?')) return;
    it.archived = true; save(); stock(); toast('Archived');
  }
  else if (a === 'restock') openRestock(t.dataset.id);
  else if (a === 'waste-add') openWaste();
  else if (a === 'stock-count') openStockCount();
  else if (a === 'eod-inc') { eodDraft[t.dataset.id] = (eodDraft[t.dataset.id] || 0) + 1; const i = document.querySelector(`[data-eod="${t.dataset.id}"]`); if (i) i.value = eodDraft[t.dataset.id]; }
  else if (a === 'eod-dec') { eodDraft[t.dataset.id] = Math.max(0, (eodDraft[t.dataset.id] || 0) - 1); const i = document.querySelector(`[data-eod="${t.dataset.id}"]`); if (i) i.value = eodDraft[t.dataset.id]; }
  else if (a === 'eod-calc') {
    const r = calcEod(); const el = document.getElementById('eodPreview');
    if (!r) { el.textContent = 'Enter quantities.'; return; }
    el.innerHTML = `<div class="okbox">Items ${r.items} · Rev ${M(r.revenue)} · COGS ${M(r.cogs)} · Gross ${M(r.gross)}</div>`;
  }
  else if (a === 'eod-confirm') {
    const r = calcEod(); if (!r) { toast('Nothing to confirm'); return; }
    if (!confirm(`Confirm day?\n${M(r.revenue)} revenue`)) return;
    const res = sellLines(r.lines, 'Cash', iso(), true);
    if (!res.ok) { toast('Stock short'); return; }
    eodDraft = {}; toast('Day confirmed'); sales(); home();
  }
  else if (a === 'history-sale') openHistorySale();
  else if (a === 'history-expense') openHistoryExpense();
  else if (a === 'history-bulk') openHistoryBulk();
  else if (a === 'worker-pay') {
    openModal('Worker payment', `
      <select id="wp_w">${(data.workers || []).map(w => `<option value="${w.id}">${esc(w.name)}</option>`).join('')}</select>
      <input id="wp_a" type="number" min="0.01" step="0.01" required placeholder="Amount">
      <input id="wp_n" placeholder="Note">
    `, () => {
      const w = data.workers.find(x => x.id === document.getElementById('wp_w').value);
      const amount = Number(document.getElementById('wp_a').value) || 0;
      const note = document.getElementById('wp_n').value.trim();
      if (!w || !amount) return false;
      data.payments.unshift({ id: uid('pay'), date: iso(), workerId: w.id, name: w.name, amount, note });
      data.expenses.unshift({ id: uid('ex'), date: iso(), amount, category: 'Worker pay', note: w.name, payment: 'Cash' });
      bookEntry('Expense', 'Worker pay', amount, w.name + ' · ' + note);
      save(); toast('Paid'); more(); return true;
    });
  }
  else if (a === 'export') {
    const ael = document.createElement('a');
    ael.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    ael.download = 'stockly-twin-' + iso() + '.json'; ael.click();
  }
  else if (a === 'reset') {
    if (!confirm('Reset all data?')) return;
    localStorage.removeItem(KEY); localStorage.removeItem('stockly_elites_v1'); location.reload();
  }
});

document.querySelectorAll('.nav button').forEach(b => b.onclick = () => show(b.dataset.s));
document.getElementById('todayMeta').textContent = today().toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
document.getElementById('onlinePill').textContent = navigator.onLine ? 'ONLINE' : 'OFFLINE';
window.addEventListener('online', () => document.getElementById('onlinePill').textContent = 'ONLINE');
window.addEventListener('offline', () => document.getElementById('onlinePill').textContent = 'OFFLINE');
refreshMenuCosts();
home();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
