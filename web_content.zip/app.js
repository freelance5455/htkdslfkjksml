/**
 * Islamic Amal Tracker - 30 Day Journey
 * Vanilla JS + LocalStorage
 * No backend required
 */

const STORAGE_KEY = 'islamic_amal_tracker_v1';

const DEFAULT_TARGETS = {
  istighfar: 100,
  durood: 100,
  quranPages: 1
};

const DEFAULT_PRAYER_TIMES = {
  fajr: '05:00',
  dhuhr: '12:15',
  asr: '15:45',
  maghrib: '17:50',
  isha: '19:15'
};

const PRAYERS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
const PRAYER_NAMES = {
  fajr: 'ফজর',
  dhuhr: 'যোহর',
  asr: 'আসর',
  maghrib: 'মাগরিব',
  isha: 'এশা'
};

const MORNING_ITEMS = [
  { key: 'fajr', label: 'ফজরের নামাজ', linked: true },
  { key: 'ayatulKursi', label: 'আয়াতুল কুরসি' },
  { key: 'ikhlas', label: 'সূরা ইখলাস' },
  { key: 'falaq', label: 'সূরা ফালাক' },
  { key: 'nas', label: 'সূরা নাস' },
  { key: 'istighfarDone', label: 'ইস্তিগফার' },
  { key: 'duroodDone', label: 'দরুদ' },
  { key: 'morningZikr', label: 'সকালবেলার মাসনূন যিকির' },
  { key: 'personalDua', label: 'নিজের জন্য দোয়া' },
  { key: 'parentsDua', label: 'বাবা-মায়ের জন্য দোয়া' }
];

const EVENING_ITEMS = [
  { key: 'maghrib', label: 'মাগরিবের নামাজ', linked: true },
  { key: 'ayatulKursi', label: 'আয়াতুল কুরসি' },
  { key: 'ikhlas', label: 'সূরা ইখলাস' },
  { key: 'falaq', label: 'সূরা ফালাক' },
  { key: 'nas', label: 'সূরা নাস' },
  { key: 'istighfarDone', label: 'ইস্তিগফার' },
  { key: 'duroodDone', label: 'দরুদ' },
  { key: 'eveningZikr', label: 'সন্ধ্যার মাসনূন যিকির' },
  { key: 'parentsDua', label: 'বাবা-মায়ের জন্য দোয়া' }
];

const NIGHT_ITEMS = [
  { key: 'wudu', label: 'ওযু' },
  { key: 'ayatulKursi', label: 'আয়াতুল কুরসি' },
  { key: 'ikhlas', label: 'সূরা ইখলাস' },
  { key: 'falaq', label: 'সূরা ফালাক' },
  { key: 'nas', label: 'সূরা নাস' },
  { key: 'sleepDua', label: 'ঘুমের দোয়া' },
  { key: 'dayAccount', label: 'দিনের হিসাব' },
  { key: 'tawba', label: 'তওবা' },
  { key: 'nextDayNiyyah', label: 'পরের দিনের ভালো কাজের নিয়ত' }
];

let state = null;

function getDefaultDayData() {
  return {
    prayers: { fajr: false, dhuhr: false, asr: false, maghrib: false, isha: false, fajrJamaat: false },
    istighfar: 0,
    durood: 0,
    quranPages: 0,
    ayatulKursi: false,
    surahInshirah: false,
    parentsDua: false,
    personalDua: false,
    halalEffort: false,
    ikhlas: false,
    falaq: false,
    nas: false,
    morningZikr: false,
    eveningZikr: false,
    wudu: false,
    sleepDua: false,
    dayAccount: false,
    tawba: false,
    nextDayNiyyah: false,
    reflection: '',
    customAmals: {},
    completed: false,
    sunnah: { fajr: false, dhuhrBefore: false, dhuhrAfter: false, asr: false, maghrib: false, ishaBefore: false, ishaAfter: false, witr: false }
  };
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      state = JSON.parse(raw);
      if (!state.targets) state.targets = { ...DEFAULT_TARGETS };
      if (!state.settings) state.settings = { name: '', darkMode: false, personalDua: '', personalGoal: '', halalEffortText: '' };
      if (!state.days) state.days = {};
      if (!state.customAmalDefs) state.customAmalDefs = [];
      if (!state.earnedBadges) state.earnedBadges = [];
      if (!state.prayerTimes) state.prayerTimes = { ...DEFAULT_PRAYER_TIMES };
      return;
    }
  } catch (e) {
    console.warn('Load error', e);
  }
  state = {
    startDate: null,
    currentDay: 0,
    targets: { ...DEFAULT_TARGETS },
    settings: {
      name: '',
      darkMode: false,
      personalDua: (typeof DUA_DATA !== 'undefined' ? DUA_DATA.defaultPersonalDua : ''),
      personalGoal: '',
      halalEffortText: ''
    },
    days: {},
    totalQuranPages: 0,
    completionShownToday: null,
    customAmalDefs: [],
    earnedBadges: [],
    prayerTimes: { ...DEFAULT_PRAYER_TIMES }
  };
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn('Save error', e);
    showToast('ডাটা সেভ করতে সমস্যা হয়েছে');
  }
}

function getTodayKey() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

function getTodayData() {
  const key = getTodayKey();
  if (!state.days[key]) {
    state.days[key] = getDefaultDayData();
  }
  return state.days[key];
}

function ensureToday() {
  getTodayData();
  if (state.startDate) {
    const start = new Date(state.startDate + 'T00:00:00');
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const diff = Math.floor((today - start) / (1000 * 60 * 60 * 24)) + 1;
    state.currentDay = Math.min(Math.max(diff, 1), 30);
  }
}

const BN_DAYS = ['রবিবার', 'সোমবার', 'মঙ্গলবার', 'বুধবার', 'বৃহস্পতিবার', 'শুক্রবার', 'শনিবার'];
const BN_MONTHS = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];

function formatBanglaDate(date = new Date()) {
  const day = BN_DAYS[date.getDay()];
  const d = date.getDate();
  const m = BN_MONTHS[date.getMonth()];
  const y = date.getFullYear();
  return { dayName: day, full: `${d} ${m} ${y}` };
}

function calcTodayProgress() {
  const day = getTodayData();
  const t = state.targets;
  let score = 0;
  let total = 0;

  PRAYERS.forEach(p => {
    total += 1;
    if (day.prayers[p]) score += 1;
  });

  total += 1;
  if (day.istighfar >= t.istighfar) score += 1;

  total += 1;
  if (day.durood >= t.durood) score += 1;

  total += 1;
  if (day.quranPages >= t.quranPages) score += 1;

  total += 1;
  if (day.ayatulKursi) score += 1;

  total += 1;
  if (day.parentsDua) score += 1;

  total += 1;
  if (day.personalDua) score += 1;

  total += 1;
  if (day.halalEffort) score += 1;

  total += 1;
  if (day.surahInshirah) score += 1;

  const percent = total > 0 ? Math.round((score / total) * 100) : 0;
  return { score, total, percent, complete: percent >= 100 };
}

function calcStreak() {
  if (!state.startDate) return 0;
  let streak = 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  for (let i = 0; i < 30; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const dayData = state.days[key];
    if (!dayData) {
      if (i === 0) continue;
      break;
    }
    const wasComplete = isDayComplete(dayData);
    if (wasComplete) {
      streak++;
    } else {
      if (i === 0) continue;
      break;
    }
  }
  return streak;
}

function isDayComplete(dayData) {
  if (!dayData) return false;
  const t = state.targets;
  const allPrayers = PRAYERS.every(p => dayData.prayers[p]);
  return allPrayers &&
    dayData.istighfar >= t.istighfar &&
    dayData.durood >= t.durood &&
    dayData.quranPages >= t.quranPages &&
    dayData.ayatulKursi &&
    dayData.parentsDua;
}

function getDayStatus(dayData) {
  if (!dayData) return 'empty';
  if (isDayComplete(dayData)) return 'complete';
  const hasAny = PRAYERS.some(p => dayData.prayers[p]) ||
    dayData.istighfar > 0 || dayData.durood > 0 || dayData.quranPages > 0 ||
    dayData.ayatulKursi || dayData.parentsDua || dayData.personalDua;
  return hasAny ? 'partial' : 'missed';
}


// ==================== PRAYER TIMES & PHASES ====================
function timeToMinutes(hhmm) {
  if (!hhmm) return 0;
  const parts = hhmm.split(':');
  return parseInt(parts[0], 10) * 60 + parseInt(parts[1] || 0, 10);
}

function minutesToTime(mins) {
  const h = Math.floor(mins / 60) % 24;
  const m = mins % 60;
  return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
}

function getPrayerTimes() {
  return state.prayerTimes || DEFAULT_PRAYER_TIMES;
}

function areTimesSet() {
  const t = getPrayerTimes();
  return t.fajr && t.dhuhr && t.asr && t.maghrib && t.isha;
}

function savePrayerTime(key, value) {
  if (!state.prayerTimes) state.prayerTimes = { ...DEFAULT_PRAYER_TIMES };
  state.prayerTimes[key] = value;
  saveState();
  showToast(PRAYER_NAMES[key] + ' সময় সেভ হয়েছে');
  updateDashboard();
}

function getCurrentPhase() {
  const day = getTodayData();
  if (day.completed) return { id: 'summary', title: 'আজকের সামারি', label: 'দিন শেষ' };

  // Auto complete at midnight: if last activity was yesterday and now past 00:00
  // Simple: if local hour is 0 and day not completed, we still show night until user opens after midnight on new date
  // Day key changes at midnight automatically via getTodayKey()

  if (!areTimesSet()) return { id: 'no_times', title: 'সময় সেট করুন', label: 'সেটিংস' };

  const now = new Date();
  const mins = now.getHours() * 60 + now.getMinutes();
  const t = getPrayerTimes();
  const fajr = timeToMinutes(t.fajr);
  const dhuhr = timeToMinutes(t.dhuhr);
  const asr = timeToMinutes(t.asr);
  const maghrib = timeToMinutes(t.maghrib);
  const isha = timeToMinutes(t.isha);

  // Prayer window ~ 35 minutes
  const WIN = 35;

  if (mins >= fajr && mins < fajr + WIN) {
    return { id: 'fajr', title: 'ফজর নামাজ', label: 'এখন ওয়াক্ত', prayer: 'fajr', time: t.fajr };
  }
  if (mins >= fajr + WIN && mins < dhuhr) {
    return { id: 'morning', title: 'সকালবেলার আমল', label: 'ফজরের পর', time: t.fajr + ' এর পর' };
  }
  if (mins >= dhuhr && mins < dhuhr + WIN) {
    return { id: 'dhuhr', title: 'যোহর নামাজ', label: 'এখন ওয়াক্ত', prayer: 'dhuhr', time: t.dhuhr };
  }
  if (mins >= dhuhr + WIN && mins < asr) {
    return { id: 'afternoon', title: 'বিকেলের আগে', label: 'যোহরের পর', prayer: null };
  }
  if (mins >= asr && mins < asr + WIN) {
    return { id: 'asr', title: 'আসর নামাজ', label: 'এখন ওয়াক্ত', prayer: 'asr', time: t.asr };
  }
  if (mins >= asr + WIN && mins < maghrib) {
    return { id: 'late', title: 'মাগরিবের আগে', label: 'আসরের পর' };
  }
  if (mins >= maghrib && mins < maghrib + WIN) {
    return { id: 'maghrib', title: 'মাগরিব নামাজ', label: 'এখন ওয়াক্ত', prayer: 'maghrib', time: t.maghrib };
  }
  if (mins >= maghrib + WIN && mins < isha) {
    return { id: 'evening', title: 'সন্ধ্যার আমল', label: 'মাগরিবের পর' };
  }
  if (mins >= isha && mins < isha + WIN) {
    return { id: 'isha', title: 'এশা নামাজ', label: 'এখন ওয়াক্ত', prayer: 'isha', time: t.isha };
  }
  // After Isha or before Fajr (night)
  if (mins >= isha + WIN || mins < fajr) {
    return { id: 'night', title: 'রাতের আমল · ঘুমানোর আগে', label: 'এশার পর', time: t.isha + ' এর পর' };
  }
  return { id: 'morning', title: 'সকালবেলার আমল', label: 'এখন' };
}

function renderNiyyahBlock(prayerKey) {
  const n = DUA_DATA.niyyah[prayerKey];
  if (!n) return '';
  let html = '';
  if (n.sunnah) {
    html += `<div class="content-card" style="margin-bottom:10px;">
      <div class="title" style="font-size:0.95rem;">সুন্নাতের নিয়ত</div>
      <div class="arabic">${n.sunnah.arabic}</div>
      <div class="bangla-pron">${n.sunnah.bangla}</div>
      <div class="meaning">${n.sunnah.meaning}</div>
    </div>`;
  }
  if (n.sunnahBefore) {
    html += `<div class="content-card" style="margin-bottom:10px;">
      <div class="title" style="font-size:0.95rem;">সুন্নাত (আগে) নিয়ত</div>
      <div class="arabic">${n.sunnahBefore.arabic}</div>
      <div class="bangla-pron">${n.sunnahBefore.bangla}</div>
      <div class="meaning">${n.sunnahBefore.meaning}</div>
    </div>`;
  }
  if (n.fard) {
    html += `<div class="content-card" style="margin-bottom:10px;">
      <div class="title" style="font-size:0.95rem;">ফরজের নিয়ত</div>
      <div class="arabic">${n.fard.arabic}</div>
      <div class="bangla-pron">${n.fard.bangla}</div>
      <div class="meaning">${n.fard.meaning}</div>
    </div>`;
  }
  if (n.sunnahAfter) {
    html += `<div class="content-card" style="margin-bottom:10px;">
      <div class="title" style="font-size:0.95rem;">সুন্নাত (পরে) নিয়ত</div>
      <div class="arabic">${n.sunnahAfter.arabic}</div>
      <div class="bangla-pron">${n.sunnahAfter.bangla}</div>
      <div class="meaning">${n.sunnahAfter.meaning}</div>
    </div>`;
  }
  if (n.witr) {
    html += `<div class="content-card" style="margin-bottom:10px;">
      <div class="title" style="font-size:0.95rem;">বিতরের নিয়ত</div>
      <div class="arabic">${n.witr.arabic}</div>
      <div class="bangla-pron">${n.witr.bangla}</div>
      <div class="meaning">${n.witr.meaning}</div>
    </div>`;
  }
  html += `<div class="note-box">নিয়ত মূলত অন্তরের ইচ্ছা। মুখে বলা ফরজ নয়। শেখার সুবিধার্থে দেওয়া হয়েছে।</div>`;
  return html;
}

function renderSalahPhase(prayerKey) {
  const info = PRAYER_INFO[prayerKey];
  const day = getTodayData();
  const checked = day.prayers[prayerKey] ? 'checked' : '';
  let sunnahHtml = '';
  if (prayerKey === 'fajr') {
    sunnahHtml = `<label class="checklist-item"><label class="custom-check"><input type="checkbox" ${day.sunnah && day.sunnah.fajr ? 'checked' : ''} onchange="toggleSunnah('fajr', this.checked)"><span class="checkmark"></span></label><span>সুন্নাত পড়েছি (২ রাকাত)</span></label>`;
  } else if (prayerKey === 'dhuhr') {
    sunnahHtml = `
      <label class="checklist-item"><label class="custom-check"><input type="checkbox" ${day.sunnah && day.sunnah.dhuhrBefore ? 'checked' : ''} onchange="toggleSunnah('dhuhrBefore', this.checked)"><span class="checkmark"></span></label><span>সুন্নাত আগে (৪ রাকাত)</span></label>
      <label class="checklist-item"><label class="custom-check"><input type="checkbox" ${day.sunnah && day.sunnah.dhuhrAfter ? 'checked' : ''} onchange="toggleSunnah('dhuhrAfter', this.checked)"><span class="checkmark"></span></label><span>সুন্নাত পরে (২ রাকাত)</span></label>`;
  } else if (prayerKey === 'asr') {
    sunnahHtml = `<label class="checklist-item"><label class="custom-check"><input type="checkbox" ${day.sunnah && day.sunnah.asr ? 'checked' : ''} onchange="toggleSunnah('asr', this.checked)"><span class="checkmark"></span></label><span>সুন্নাত (৪ রাকাত)</span></label>`;
  } else if (prayerKey === 'maghrib') {
    sunnahHtml = `<label class="checklist-item"><label class="custom-check"><input type="checkbox" ${day.sunnah && day.sunnah.maghrib ? 'checked' : ''} onchange="toggleSunnah('maghrib', this.checked)"><span class="checkmark"></span></label><span>সুন্নাত পরে (২ রাকাত)</span></label>`;
  } else if (prayerKey === 'isha') {
    sunnahHtml = `
      <label class="checklist-item"><label class="custom-check"><input type="checkbox" ${day.sunnah && day.sunnah.ishaBefore ? 'checked' : ''} onchange="toggleSunnah('ishaBefore', this.checked)"><span class="checkmark"></span></label><span>সুন্নাত আগে (৪ রাকাত)</span></label>
      <label class="checklist-item"><label class="custom-check"><input type="checkbox" ${day.sunnah && day.sunnah.ishaAfter ? 'checked' : ''} onchange="toggleSunnah('ishaAfter', this.checked)"><span class="checkmark"></span></label><span>সুন্নাত পরে (২ রাকাত)</span></label>
      <label class="checklist-item"><label class="custom-check"><input type="checkbox" ${day.sunnah && day.sunnah.witr ? 'checked' : ''} onchange="toggleSunnah('witr', this.checked)"><span class="checkmark"></span></label><span>বিতর (৩ রাকাত)</span></label>`;
  }

  return `
    <div class="card">
      <div class="card-title">🕌 ${info.name} — ${info.fard} রাকাত ফরজ</div>
      <div class="fs-sm text-muted mb-1">সুন্নাত: ${info.sunnah}</div>
      <div class="fs-sm text-muted mb-2">সময় নির্দেশনা: ${info.time}</div>
      ${sunnahHtml}
      <label class="checklist-item">
        <label class="custom-check">
          <input type="checkbox" ${checked} onchange="togglePrayer('${prayerKey}', this.checked)">
          <span class="checkmark"></span>
        </label>
        <span class="item-text fw-bold">ফরজ পড়েছি ✅</span>
      </label>
      ${prayerKey === 'fajr' ? `
      <label class="checklist-item">
        <label class="custom-check jamaat">
          <input type="checkbox" ${day.prayers.fajrJamaat ? 'checked' : ''} onchange="togglePrayer('fajrJamaat', this.checked)">
          <span class="checkmark"></span>
        </label>
        <span>জামাতে পড়েছি</span>
      </label>` : ''}
    </div>
    <div class="section-header">নিয়ত</div>
    ${renderNiyyahBlock(prayerKey)}
  `;
}

function renderAmalsChecklist(items, title) {
  const day = getTodayData();
  const list = items.map(item => {
    let checked = false;
    if (item.linked) checked = !!day.prayers[item.key];
    else if (item.key === 'istighfarDone') checked = day.istighfar >= state.targets.istighfar;
    else if (item.key === 'duroodDone') checked = day.durood >= state.targets.durood;
    else checked = !!day[item.key];
    const disabled = item.linked || item.key === 'istighfarDone' || item.key === 'duroodDone';
    return `<label class="checklist-item ${checked ? 'done' : ''}">
      <label class="custom-check">
        <input type="checkbox" ${checked ? 'checked' : ''} ${disabled ? 'disabled' : ''} onchange="toggleDaily('${item.key}', this.checked)">
        <span class="checkmark"></span>
      </label>
      <span class="item-text">${item.label}</span>
    </label>`;
  }).join('');
  return `<div class="card"><div class="card-title">${title}</div>${list}</div>`;
}

function renderPhaseContent(phase) {
  const el = document.getElementById('phaseContent');
  if (!el) return;
  const day = getTodayData();
  let html = '';

  if (phase.id === 'fajr' || phase.id === 'dhuhr' || phase.id === 'asr' || phase.id === 'maghrib' || phase.id === 'isha') {
    html = renderSalahPhase(phase.prayer);
  } else if (phase.id === 'morning') {
    html = renderAmalsChecklist(MORNING_ITEMS, '🌅 সকালবেলার আমল') + `
      <div class="card counter-card">
        <div class="card-title">🤲 ইস্তিগফার · ﷺ দরুদ</div>
        <div class="d-flex gap-2 justify-between">
          <div>
            <div class="fs-sm text-muted">ইস্তিগফার</div>
            <div class="fw-bold" id="phaseIst">${day.istighfar}/${state.targets.istighfar}</div>
            <button class="btn btn-primary btn-sm mt-1" onclick="addCounter('istighfar',1); updateDashboard();">+1</button>
          </div>
          <div>
            <div class="fs-sm text-muted">দরুদ</div>
            <div class="fw-bold" id="phaseDur">${day.durood}/${state.targets.durood}</div>
            <button class="btn btn-primary btn-sm mt-1" onclick="addCounter('durood',1); updateDashboard();">+1</button>
          </div>
        </div>
      </div>`;
  } else if (phase.id === 'evening') {
    html = renderAmalsChecklist(EVENING_ITEMS, '🌇 সন্ধ্যার আমল');
  } else if (phase.id === 'night') {
    html = renderAmalsChecklist(NIGHT_ITEMS, '🌙 ঘুমানোর আগের আমল');
  } else if (phase.id === 'afternoon' || phase.id === 'late') {
    html = `<div class="card"><div class="card-title">এখন যা করতে পারেন</div>
      <ul class="checklist">
        <li class="checklist-item" onclick="showPage('quran')">📖 কুরআন পড়ুন</li>
        <li class="checklist-item" onclick="showPage('amal')">📿 ইস্তিগফার / দরুদ</li>
        <li class="checklist-item" onclick="showPage('amal')">🤲 ব্যক্তিগত দোয়া</li>
      </ul>
      <p class="fs-sm text-muted mt-1">পরবর্তী ওয়াক্তের জন্য প্রস্তুত থাকুন।</p>
    </div>`;
  } else {
    html = `<div class="card text-center text-muted">গাইড লোড হচ্ছে...</div>`;
  }

  el.innerHTML = html;
}

function toggleSunnah(key, checked) {
  const day = getTodayData();
  if (!day.sunnah) day.sunnah = {};
  day.sunnah[key] = checked;
  saveState();
  updateDashboard();
}

function completeDay() {
  const day = getTodayData();
  day.completed = true;
  saveState();
  showToast('আজকের দিন শেষ হয়েছে · আলহামদুলিল্লাহ');
  updateDashboard();
  // show completion modal style summary
  setTimeout(() => showCompletionModal(), 400);
}

function checkMidnightRollover() {
  // If previous day wasn't completed and it's a new calendar day, leave it as partial/missed
  // getTodayKey already isolates days. Nothing extra needed.
}


function updateDashboard() {
  ensureToday();
  checkMidnightRollover();
  const dateInfo = formatBanglaDate();
  document.getElementById('todayDayName').textContent = dateInfo.dayName;
  document.getElementById('todayFullDate').textContent = dateInfo.full;

  if (!state.startDate) {
    document.getElementById('startBanner').style.display = 'block';
    document.getElementById('dashboard').style.display = 'none';
    document.getElementById('timesNotSetBanner').style.display = 'none';
    return;
  }
  document.getElementById('startBanner').style.display = 'none';

  if (!areTimesSet()) {
    document.getElementById('timesNotSetBanner').style.display = 'block';
    document.getElementById('dashboard').style.display = 'none';
    return;
  }
  document.getElementById('timesNotSetBanner').style.display = 'none';
  document.getElementById('dashboard').style.display = 'block';

  document.getElementById('dayBadge').textContent = 'Day ' + state.currentDay + ' / 30';

  const day = getTodayData();
  const progress = calcTodayProgress();
  document.getElementById('progressPercent').textContent = progress.percent + '%';
  const miniBar = document.getElementById('miniProgressBar');
  if (miniBar) miniBar.style.width = progress.percent + '%';

  const prayerCount = PRAYERS.filter(p => day.prayers[p]).length;
  document.getElementById('statPrayer').textContent = prayerCount + '/5';
  document.getElementById('statIstighfar').textContent = day.istighfar;
  document.getElementById('statDurood').textContent = day.durood;
  document.getElementById('statQuran').textContent = day.quranPages;

  const streak = calcStreak();
  const streakEl = document.getElementById('streakDisplay');
  if (streak > 0) {
    streakEl.style.display = 'block';
    document.getElementById('streakCount').textContent = streak;
  } else {
    streakEl.style.display = 'none';
  }

  const phase = getCurrentPhase();
  document.getElementById('phaseLabel').textContent = phase.label || 'এখন';
  document.getElementById('phaseTitle').textContent = phase.title || '';
  document.getElementById('phaseTimeRange').textContent = phase.time ? ('সময়: ' + phase.time) : '';

  const dayEnd = document.getElementById('dayEndSection');
  const daySummary = document.getElementById('daySummary');
  const phaseContent = document.getElementById('phaseContent');
  const phaseInd = document.getElementById('phaseIndicator');

  if (phase.id === 'summary' || day.completed) {
    if (dayEnd) dayEnd.style.display = 'none';
    if (phaseContent) phaseContent.style.display = 'none';
    if (phaseInd) phaseInd.style.display = 'none';
    if (daySummary) {
      daySummary.style.display = 'block';
      document.getElementById('summaryStats').innerHTML =
        '<div class="mt-1">নামাজ ' + prayerCount + '/5 · ইস্তিগফার ' + day.istighfar +
        ' · দরুদ ' + day.durood + ' · কুরআন ' + day.quranPages + ' পৃষ্ঠা</div>';
    }
    updateBadges();
    loadReflection();
  } else {
    if (daySummary) daySummary.style.display = 'none';
    if (phaseContent) phaseContent.style.display = 'block';
    if (phaseInd) phaseInd.style.display = 'block';
    if (dayEnd) dayEnd.style.display = (phase.id === 'night') ? 'block' : 'none';
    renderPhaseContent(phase);
  }
}

function renderRemainingList() {
  const day = getTodayData();
  const t = state.targets;
  const items = [];

  PRAYERS.forEach(p => {
    if (!day.prayers[p]) items.push({ label: PRAYER_NAMES[p] + ' নামাজ', page: 'salah' });
  });
  if (day.istighfar < t.istighfar) items.push({ label: `ইস্তিগফার (${day.istighfar}/${t.istighfar})`, page: 'amal' });
  if (day.durood < t.durood) items.push({ label: `দরুদ (${day.durood}/${t.durood})`, page: 'amal' });
  if (day.quranPages < t.quranPages) items.push({ label: `কুরআন (${day.quranPages}/${t.quranPages})`, page: 'quran' });
  if (!day.ayatulKursi) items.push({ label: 'আয়াতুল কুরসি', page: 'quran' });
  if (!day.parentsDua) items.push({ label: 'বাবা-মায়ের জন্য দোয়া', page: 'amal' });
  if (!day.personalDua) items.push({ label: 'ব্যক্তিগত দোয়া', page: 'amal' });
  if (!day.halalEffort) items.push({ label: 'হালাল প্রচেষ্টা', page: 'amal' });

  const ul = document.getElementById('remainingList');
  if (items.length === 0) {
    ul.innerHTML = '<li class="text-center text-muted" style="padding:12px;">✅ সব কাজ সম্পন্ন!</li>';
    return;
  }
  ul.innerHTML = items.map(it => `
    <li class="checklist-item" onclick="showPage('${it.page}')">
      <span style="color:var(--primary);">☐</span>
      <span class="item-text">${it.label}</span>
    </li>
  `).join('');
}

function updateSalahPage() {
  const day = getTodayData();
  const count = PRAYERS.filter(p => day.prayers[p]).length;
  document.getElementById('salahProgressBar').style.width = (count / 5 * 100) + '%';
  document.getElementById('salahProgressText').textContent = `${count} / 5 নামাজ সম্পন্ন`;
  document.getElementById('salahCompleteMsg').style.display = count === 5 ? 'block' : 'none';

  const list = document.getElementById('prayerList');
  list.innerHTML = PRAYERS.map(p => {
    const info = PRAYER_INFO[p];
    const checked = day.prayers[p] ? 'checked' : '';
    const jamaat = (p === 'fajr' && day.prayers.fajrJamaat) ? 'checked' : '';
    return `
      <li class="prayer-item">
        <div class="prayer-name">
          <span>${info.name}</span>
          <button class="btn btn-outline btn-sm" style="padding:4px 8px; font-size:0.75rem;" onclick="showPrayerDetail('${p}')">বিস্তারিত</button>
        </div>
        <div class="prayer-checks">
          <label class="custom-check">
            <input type="checkbox" ${checked} onchange="togglePrayer('${p}', this.checked)">
            <span class="checkmark"></span>
            <span>পড়েছি</span>
          </label>
          ${p === 'fajr' ? `
          <label class="custom-check jamaat">
            <input type="checkbox" ${jamaat} onchange="togglePrayer('fajrJamaat', this.checked)">
            <span class="checkmark"></span>
            <span>জামাত</span>
          </label>` : ''}
        </div>
      </li>
    `;
  }).join('');
}

function updateAmalPage() {
  const day = getTodayData();
  const t = state.targets;

  document.getElementById('istighfarCount').innerHTML = `${day.istighfar} <span>/ ${t.istighfar}</span>`;
  document.getElementById('istighfarBar').style.width = Math.min(100, (day.istighfar / t.istighfar) * 100) + '%';
  document.getElementById('istighfarDone').style.display = day.istighfar >= t.istighfar ? 'block' : 'none';
  document.getElementById('istighfarTargetBadge').textContent = `টার্গেট: ${t.istighfar}`;

  document.getElementById('duroodCount').innerHTML = `${day.durood} <span>/ ${t.durood}</span>`;
  document.getElementById('duroodBar').style.width = Math.min(100, (day.durood / t.durood) * 100) + '%';
  document.getElementById('duroodDone').style.display = day.durood >= t.durood ? 'block' : 'none';
  document.getElementById('duroodTargetBadge').textContent = `টার্গেট: ${t.durood}`;

  renderChecklist('morningChecklist', MORNING_ITEMS);
  renderChecklist('eveningChecklist', EVENING_ITEMS);
  renderChecklist('nightChecklist', NIGHT_ITEMS);

  document.getElementById('parentsDuaCheck').checked = !!day.parentsDua;
  document.getElementById('personalDuaCheck').checked = !!day.personalDua;
  document.getElementById('halalEffortCheck').checked = !!day.halalEffort;

  document.getElementById('personalDuaText').value = state.settings.personalDua || '';
  document.getElementById('personalGoal').value = state.settings.personalGoal || '';
  document.getElementById('halalEffortText').value = state.settings.halalEffortText || '';

  renderCustomAmals();
}

function renderChecklist(containerId, items) {
  const day = getTodayData();
  const ul = document.getElementById(containerId);
  ul.innerHTML = items.map(item => {
    let checked = false;
    if (item.linked) {
      checked = !!day.prayers[item.key];
    } else if (item.key === 'istighfarDone') {
      checked = day.istighfar >= state.targets.istighfar;
    } else if (item.key === 'duroodDone') {
      checked = day.durood >= state.targets.durood;
    } else {
      checked = !!day[item.key];
    }
    return `
      <li class="checklist-item ${checked ? 'done' : ''}">
        <label class="custom-check">
          <input type="checkbox" ${checked ? 'checked' : ''} 
            ${item.linked || item.key === 'istighfarDone' || item.key === 'duroodDone' ? 'disabled' : ''}
            onchange="toggleDaily('${item.key}', this.checked)">
          <span class="checkmark"></span>
        </label>
        <span class="item-text">${item.label}</span>
      </li>
    `;
  }).join('');

  const allDone = items.every(item => {
    if (item.linked) return !!day.prayers[item.key];
    if (item.key === 'istighfarDone') return day.istighfar >= state.targets.istighfar;
    if (item.key === 'duroodDone') return day.durood >= state.targets.durood;
    return !!day[item.key];
  });
  const doneId = containerId.replace('Checklist', 'Done');
  const doneEl = document.getElementById(doneId);
  if (doneEl) doneEl.style.display = allDone ? 'block' : 'none';
}

function updateQuranPage() {
  const day = getTodayData();
  const t = state.targets;

  document.getElementById('quranCount').innerHTML = `${day.quranPages} <span>/ ${t.quranPages} Page</span>`;
  document.getElementById('quranBar').style.width = Math.min(100, (day.quranPages / t.quranPages) * 100) + '%';
  document.getElementById('quranDone').style.display = day.quranPages >= t.quranPages ? 'block' : 'none';
  document.getElementById('totalQuranPages').textContent = state.totalQuranPages || 0;

  document.getElementById('ayatulKursiCheck').checked = !!day.ayatulKursi;
  document.getElementById('surahInshirahCheck').checked = !!day.surahInshirah;

  if (typeof DUA_DATA !== 'undefined') {
    const ak = DUA_DATA.ayatulKursi;
    document.getElementById('ayatulKursiArabic').textContent = ak.arabic;
    document.getElementById('ayatulKursiBangla').textContent = ak.bangla;
    document.getElementById('ayatulKursiMeaning').textContent = ak.meaning;
    document.getElementById('ayatulKursiRef').textContent = '📖 ' + ak.reference;

    const insh = DUA_DATA.surahInshirah;
    document.getElementById('inshirahAyahs').innerHTML = insh.ayahs.map(a => `
      <div style="margin-bottom:14px; padding-bottom:12px; border-bottom:1px solid var(--border);">
        <div class="fw-bold fs-sm text-muted">আয়াত ${a.num}</div>
        <div class="arabic">${a.arabic}</div>
        <div class="bangla-pron">${a.bangla}</div>
        <div class="meaning">${a.meaning}</div>
      </div>
    `).join('');
    document.getElementById('inshirahNote').textContent = insh.note;

    const ik = DUA_DATA.surahIkhlas;
    document.getElementById('ikhlasArabic').textContent = ik.arabic;
    document.getElementById('ikhlasBangla').textContent = ik.bangla;
    document.getElementById('ikhlasMeaning').textContent = ik.meaning;

    const fl = DUA_DATA.surahFalaq;
    document.getElementById('falaqArabic').textContent = fl.arabic;
    document.getElementById('falaqBangla').textContent = fl.bangla;
    document.getElementById('falaqMeaning').textContent = fl.meaning;

    const ns = DUA_DATA.surahNas;
    document.getElementById('nasArabic').textContent = ns.arabic;
    document.getElementById('nasBangla').textContent = ns.bangla;
    document.getElementById('nasMeaning').textContent = ns.meaning;
  }
}

function updateProgressPage() {
  if (!state.startDate) {
    document.getElementById('calendarGrid').innerHTML = '<div class="empty-state"><p>প্রথমে ৩০ দিনের যাত্রা শুরু করুন</p></div>';
    document.getElementById('statsContent').innerHTML = '';
    return;
  }

  const start = new Date(state.startDate + 'T00:00:00');
  const todayKey = getTodayKey();
  let html = '';

  for (let i = 1; i <= 30; i++) {
    const d = new Date(start);
    d.setDate(d.getDate() + (i - 1));
    const key = d.toISOString().slice(0, 10);
    const dayData = state.days[key];
    const isFuture = key > todayKey;
    const isToday = key === todayKey;
    let status = isFuture ? 'locked' : getDayStatus(dayData);
    if (isFuture) status = 'locked';

    const icon = status === 'complete' ? '✅' : status === 'partial' ? '◐' : status === 'missed' ? '❌' : status === 'locked' ? '🔒' : '·';
    html += `
      <div class="day-cell ${status} ${isToday ? 'today' : ''}" 
           onclick="${isFuture ? '' : `showDayStats('${key}', ${i})`}"
           title="Day ${i}">
        <div style="font-size:0.7rem;">${i}</div>
        <div style="font-size:0.9rem;">${icon}</div>
      </div>
    `;
  }
  document.getElementById('calendarGrid').innerHTML = html;

  let prayerTotal = 0, prayerDone = 0;
  let quranDays = 0, istighfarDays = 0, duroodDays = 0;
  let completeDays = 0;
  let totalIstighfar = 0, totalDurood = 0;

  Object.keys(state.days).forEach(key => {
    if (key < state.startDate) return;
    const day = state.days[key];
    PRAYERS.forEach(p => {
      prayerTotal++;
      if (day.prayers[p]) prayerDone++;
    });
    if (day.quranPages >= state.targets.quranPages) quranDays++;
    if (day.istighfar >= state.targets.istighfar) istighfarDays++;
    if (day.durood >= state.targets.durood) duroodDays++;
    if (isDayComplete(day)) completeDays++;
    totalIstighfar += day.istighfar || 0;
    totalDurood += day.durood || 0;
  });

  const daysTracked = Object.keys(state.days).filter(k => k >= state.startDate).length || 1;
  const prayerPct = prayerTotal ? Math.round(prayerDone / prayerTotal * 100) : 0;
  const quranPct = Math.round(quranDays / daysTracked * 100);
  const istPct = Math.round(istighfarDays / daysTracked * 100);
  const durPct = Math.round(duroodDays / daysTracked * 100);
  const overall = Math.round((prayerPct + quranPct + istPct + durPct) / 4);

  document.getElementById('statsContent').innerHTML = `
    <div class="stat-row">
      <div class="stat-label-row"><span>নামাজ</span><span>${prayerPct}%</span></div>
      <div class="progress-bar-wrap"><div class="progress-bar" style="width:${prayerPct}%"></div></div>
    </div>
    <div class="stat-row">
      <div class="stat-label-row"><span>কুরআন</span><span>${quranPct}%</span></div>
      <div class="progress-bar-wrap"><div class="progress-bar" style="width:${quranPct}%"></div></div>
    </div>
    <div class="stat-row">
      <div class="stat-label-row"><span>ইস্তিগফার</span><span>${istPct}%</span></div>
      <div class="progress-bar-wrap"><div class="progress-bar" style="width:${istPct}%"></div></div>
    </div>
    <div class="stat-row">
      <div class="stat-label-row"><span>দরুদ</span><span>${durPct}%</span></div>
      <div class="progress-bar-wrap"><div class="progress-bar" style="width:${durPct}%"></div></div>
    </div>
    <div class="stat-row">
      <div class="stat-label-row"><span>Overall</span><span class="fw-bold">${overall}%</span></div>
      <div class="progress-bar-wrap"><div class="progress-bar" style="width:${overall}%"></div></div>
    </div>
    <div class="mt-2 fs-sm text-muted">
      সম্পূর্ণ দিন: ${completeDays} · মোট ইস্তিগফার: ${totalIstighfar} · মোট দরুদ: ${totalDurood}
    </div>
  `;

  if (state.currentDay >= 30 && completeDays >= 25) {
    document.getElementById('certificateSection').style.display = 'block';
    document.getElementById('certStats').innerHTML = `
      <div class="stat-box"><div class="val">${prayerPct}%</div><div class="lbl">নামাজ</div></div>
      <div class="stat-box"><div class="val">${quranPct}%</div><div class="lbl">কুরআন</div></div>
      <div class="stat-box"><div class="val">${totalIstighfar}</div><div class="lbl">ইস্তিগফার</div></div>
      <div class="stat-box"><div class="val">${completeDays}</div><div class="lbl">সম্পূর্ণ দিন</div></div>
    `;
  }

  updateWeeklyReport();
}

function updateLearningPage() {
  if (typeof DUA_DATA === 'undefined') return;

  const acc = document.getElementById('salahLearningAccordion');
  acc.innerHTML = DUA_DATA.salahSteps.map((step, i) => `
    <div class="accordion-item" id="acc-${i}">
      <button class="accordion-header" onclick="toggleAccordion(${i})">
        <span>${step.id}. ${step.title}</span>
        <i class="bi bi-chevron-down"></i>
      </button>
      <div class="accordion-body">
        ${step.arabic && step.arabic.length > 5 ? `<div class="arabic">${step.arabic}</div>` : ''}
        ${step.bangla ? `<div class="bangla-pron">${step.bangla}</div>` : ''}
        <div class="meaning">${step.meaning}</div>
      </div>
    </div>
  `).join('');

  const niyyah = document.getElementById('niyyahContent');
  niyyah.innerHTML = Object.keys(DUA_DATA.niyyah).map(key => {
    const name = PRAYER_NAMES[key] || key;
    return `<div class="mb-2"><div class="title" style="text-align:center;font-weight:700;color:var(--primary);">${name}</div>${renderNiyyahBlock(key)}</div>`;
  }).join('');
}

function updateSettingsPage() {
  document.getElementById('settingIstighfar').value = [33, 100, 300].includes(state.targets.istighfar) ? state.targets.istighfar : 'custom';
  document.getElementById('settingDurood').value = [33, 100, 300].includes(state.targets.durood) ? state.targets.durood : 'custom';
  document.getElementById('settingQuran').value = [1, 2, 5, 10].includes(state.targets.quranPages) ? state.targets.quranPages : 'custom';

  document.getElementById('customIstighfarWrap').style.display = document.getElementById('settingIstighfar').value === 'custom' ? 'flex' : 'none';
  document.getElementById('customDuroodWrap').style.display = document.getElementById('settingDurood').value === 'custom' ? 'flex' : 'none';
  document.getElementById('customQuranWrap').style.display = document.getElementById('settingQuran').value === 'custom' ? 'flex' : 'none';

  if (document.getElementById('settingIstighfar').value === 'custom') {
    document.getElementById('customIstighfar').value = state.targets.istighfar;
  }
  if (document.getElementById('settingDurood').value === 'custom') {
    document.getElementById('customDurood').value = state.targets.durood;
  }
  if (document.getElementById('settingQuran').value === 'custom') {
    document.getElementById('customQuran').value = state.targets.quranPages;
  }

  document.getElementById('darkModeToggle').checked = !!state.settings.darkMode;
  document.getElementById('settingName').value = state.settings.name || '';

  const times = getPrayerTimes();
  const map = { fajr: 'timeFajr', dhuhr: 'timeDhuhr', asr: 'timeAsr', maghrib: 'timeMaghrib', isha: 'timeIsha' };
  Object.keys(map).forEach(k => {
    const el = document.getElementById(map[k]);
    if (el) el.value = times[k] || '';
  });
}

function startJourney() {
  const today = getTodayKey();
  state.startDate = today;
  state.currentDay = 1;
  if (!state.days[today]) state.days[today] = getDefaultDayData();
  saveState();
  showToast('৩০ দিনের যাত্রা শুরু হয়েছে! 🌙');
  updateDashboard();
}

function togglePrayer(key, checked) {
  const day = getTodayData();
  if (key === 'fajrJamaat') {
    day.prayers.fajrJamaat = checked;
  } else {
    day.prayers[key] = checked;
  }
  saveState();
  updateSalahPage();
  updateDashboard();
  updateAmalPage();
}

function addCounter(type, delta) {
  const day = getTodayData();
  if (type === 'istighfar') {
    day.istighfar = Math.max(0, (day.istighfar || 0) + delta);
  } else if (type === 'durood') {
    day.durood = Math.max(0, (day.durood || 0) + delta);
  } else if (type === 'quranPages') {
    const prev = day.quranPages || 0;
    day.quranPages = Math.max(0, prev + delta);
    if (delta > 0) {
      state.totalQuranPages = (state.totalQuranPages || 0) + delta;
    } else if (delta < 0 && prev > 0) {
      state.totalQuranPages = Math.max(0, (state.totalQuranPages || 0) + delta);
    }
  }
  saveState();
  updateAmalPage();
  updateQuranPage();
  updateDashboard();
}

function toggleDaily(key, checked) {
  const day = getTodayData();
  day[key] = checked;
  saveState();
  updateAmalPage();
  updateQuranPage();
  updateDashboard();
}

function savePersonalDua() {
  state.settings.personalDua = document.getElementById('personalDuaText').value;
  saveState();
  showToast('ব্যক্তিগত দোয়া সংরক্ষিত ✓');
}

function savePersonalGoal() {
  state.settings.personalGoal = document.getElementById('personalGoal').value;
  state.settings.halalEffortText = document.getElementById('halalEffortText').value;
  saveState();
  showToast('লক্ষ্য সংরক্ষিত ✓');
}

function updateTarget(type, value) {
  if (value === 'custom') {
    if (type === 'istighfar') document.getElementById('customIstighfarWrap').style.display = 'flex';
    if (type === 'durood') document.getElementById('customDuroodWrap').style.display = 'flex';
    if (type === 'quranPages') document.getElementById('customQuranWrap').style.display = 'flex';
    return;
  }
  const num = parseInt(value, 10);
  if (isNaN(num) || num < 1) return;
  state.targets[type] = num;
  saveState();
  updateAmalPage();
  updateQuranPage();
  updateDashboard();
  updateSettingsPage();
  showToast('টার্গেট আপডেট হয়েছে');
}

function toggleDarkMode(on) {
  state.settings.darkMode = on;
  document.documentElement.setAttribute('data-theme', on ? 'dark' : 'light');
  saveState();
}

function saveSetting(key, value) {
  state.settings[key] = value;
  saveState();
}

function showModal(title, bodyHtml) {
  document.getElementById('modalTitle').textContent = title;
  document.getElementById('modalBody').innerHTML = bodyHtml;
  document.getElementById('modalOverlay').classList.add('show');
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('show');
}

function showPrayerDetail(prayerKey) {
  const info = PRAYER_INFO[prayerKey];
  let html = `
    <div class="mb-2">
      <div class="fw-bold">${info.name} (${info.nameAr})</div>
      <div class="fs-sm text-muted">সময়: ${info.time}</div>
    </div>
    <div class="mb-2">
      <strong>ফরজ:</strong> ${info.fard} রাকাত<br>
      <strong>সুন্নাত:</strong> ${info.sunnah}
    </div>
    <div class="note-box">${info.note}</div>
    <div class="section-header">নিয়ত</div>
    ${renderNiyyahBlock(prayerKey)}
  `;
  showModal(info.name + ' নামাজ', html);
}

function showSayyidulIstighfar() {
  const s = DUA_DATA.istighfar.sayyidul;
  showModal('সিয়্যিদুল ইস্তিগফার', `
    <div class="arabic arabic-lg">${s.arabic}</div>
    <div class="bangla-pron">${s.bangla}</div>
    <div class="meaning">${s.meaning}</div>
    <div class="reference">📚 ${s.reference}</div>
  `);
}

function showDuroodText() {
  const d = DUA_DATA.durood;
  showModal('দরুদ ইবরাহিম', `
    <div class="arabic arabic-lg">${d.arabic}</div>
    <div class="bangla-pron">${d.bangla}</div>
    <div class="meaning">${d.meaning}</div>
    <div class="fs-sm text-muted mt-2">${d.where}</div>
  `);
}

function showDayStats(dateKey, dayNum) {
  const day = state.days[dateKey] || getDefaultDayData();
  const status = getDayStatus(day);
  const statusText = status === 'complete' ? '✅ সম্পূর্ণ' : status === 'partial' ? '◐ আংশিক' : '❌ মিসড';
  const prayerCount = PRAYERS.filter(p => day.prayers[p]).length;

  showModal(`Day ${dayNum} — ${dateKey}`, `
    <div class="text-center mb-2"><span class="badge ${status === 'complete' ? 'badge-success' : status === 'partial' ? 'badge-warning' : 'badge-danger'}">${statusText}</span></div>
    <div class="stat-row"><div class="stat-label-row"><span>নামাজ</span><span>${prayerCount}/5</span></div></div>
    <div class="stat-row"><div class="stat-label-row"><span>ইস্তিগফার</span><span>${day.istighfar || 0}</span></div></div>
    <div class="stat-row"><div class="stat-label-row"><span>দরুদ</span><span>${day.durood || 0}</span></div></div>
    <div class="stat-row"><div class="stat-label-row"><span>কুরআন</span><span>${day.quranPages || 0} পৃষ্ঠা</span></div></div>
    <div class="stat-row"><div class="stat-label-row"><span>আয়াতুল কুরসি</span><span>${day.ayatulKursi ? '✓' : '—'}</span></div></div>
    <div class="stat-row"><div class="stat-label-row"><span>বাবা-মা দোয়া</span><span>${day.parentsDua ? '✓' : '—'}</span></div></div>
  `);
}

function showCompletionModal() {
  document.getElementById('completionDayText').textContent = `Day ${state.currentDay} / 30 Complete`;
  const streak = calcStreak();
  document.getElementById('completionStreakText').textContent = streak > 1 ? `🔥 ${streak} Days Streak` : '';
  document.getElementById('completionModal').classList.add('show');
}

function closeCompletionModal() {
  document.getElementById('completionModal').classList.remove('show');
}

function toggleAccordion(i) {
  const el = document.getElementById('acc-' + i);
  el.classList.toggle('open');
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById('page-' + pageId);
  if (page) page.classList.add('active');

  document.querySelectorAll('.nav-item').forEach(n => {
    n.classList.toggle('active', n.dataset.page === pageId);
  });

  const titles = {
    home: 'আমল ট্র্যাকার',
    salah: 'নামাজ',
    amal: 'দৈনিক আমল',
    quran: 'কুরআন',
    progress: 'প্রোগ্রেস',
    learning: 'নামাজ শিখুন',
    settings: 'সেটিংস'
  };
  document.getElementById('headerTitle').textContent = titles[pageId] || 'আমল ট্র্যাকার';

  if (pageId === 'home') updateDashboard();
  if (pageId === 'salah') updateSalahPage();
  if (pageId === 'amal') updateAmalPage();
  if (pageId === 'quran') updateQuranPage();
  if (pageId === 'progress') updateProgressPage();
  if (pageId === 'learning') updateLearningPage();
  if (pageId === 'settings') updateSettingsPage();

  window.scrollTo(0, 0);
}

function exportData() {
  const dataStr = JSON.stringify(state, null, 2);
  const blob = new Blob([dataStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `islamic-amal-tracker-backup-${getTodayKey()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('ডাটা এক্সপোর্ট হয়েছে ✓');
}

function importData(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const imported = JSON.parse(e.target.result);
      if (!imported.days || !imported.targets) {
        showToast('অবৈধ ফাইল');
        return;
      }
      if (confirm('বর্তমান ডাটা মুছে ইমপোর্ট করা হবে। চালিয়ে যাবেন?')) {
        state = imported;
        saveState();
        applyTheme();
        updateDashboard();
        showToast('ডাটা ইমপোর্ট সফল ✓');
      }
    } catch (err) {
      showToast('ফাইল পড়তে সমস্যা');
    }
  };
  reader.readAsText(file);
  event.target.value = '';
}

function resetAllData() {
  if (!confirm('সব ডাটা মুছে ফেলা হবে। নিশ্চিত?')) return;
  if (!confirm('এটি পূর্বাবস্থায় ফেরানো যাবে না। আবার নিশ্চিত করুন।')) return;
  localStorage.removeItem(STORAGE_KEY);
  loadState();
  applyTheme();
  showPage('home');
  updateDashboard();
  showToast('সব ডাটা রিসেট হয়েছে');
}

let toastTimer;
function showToast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2500);
}

function applyTheme() {
  const dark = state.settings && state.settings.darkMode;
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
}

// ==================== BADGES / MILESTONES ====================
const BADGE_DEFS = [
  { id: 'streak3',  icon: '🔥', label: '৩ দিন',  minStreak: 3 },
  { id: 'streak7',  icon: '⭐', label: '৭ দিন',  minStreak: 7 },
  { id: 'streak15', icon: '🌟', label: '১৫ দিন', minStreak: 15 },
  { id: 'streak30', icon: '🏆', label: '৩০ দিন', minStreak: 30 }
];

function updateBadges() {
  const streak = calcStreak();
  const grid = document.getElementById('badgesGrid');
  if (!grid) return;

  // Unlock new badges
  BADGE_DEFS.forEach(b => {
    if (streak >= b.minStreak && !state.earnedBadges.includes(b.id)) {
      state.earnedBadges.push(b.id);
      saveState();
      showToast(`${b.icon} নতুন ব্যাজ আনলক: ${b.label}!`);
    }
  });

  grid.innerHTML = BADGE_DEFS.map(b => {
    const earned = state.earnedBadges.includes(b.id) || streak >= b.minStreak;
    return `
      <div class="badge-item ${earned ? 'earned' : 'locked'}">
        <span class="badge-icon">${b.icon}</span>
        <span class="badge-label">${b.label}</span>
      </div>
    `;
  }).join('');
}

// ==================== DAILY REFLECTION ====================
function saveReflection() {
  const day = getTodayData();
  day.reflection = document.getElementById('dailyReflection').value.trim();
  saveState();
  showToast('নোট সংরক্ষিত ✓');
}

function loadReflection() {
  const el = document.getElementById('dailyReflection');
  if (!el) return;
  const day = getTodayData();
  el.value = day.reflection || '';
}

// ==================== CUSTOM AMAL ====================
function addCustomAmal() {
  const input = document.getElementById('newCustomAmal');
  const label = (input.value || '').trim();
  if (!label) {
    showToast('আমলের নাম লিখুন');
    return;
  }
  if (!state.customAmalDefs) state.customAmalDefs = [];
  const id = 'custom_' + Date.now();
  state.customAmalDefs.push({ id, label });
  saveState();
  input.value = '';
  renderCustomAmals();
  showToast('কাস্টম আমল যোগ হয়েছে');
}

function toggleCustomAmal(id, checked) {
  const day = getTodayData();
  if (!day.customAmals) day.customAmals = {};
  day.customAmals[id] = checked;
  saveState();
  renderCustomAmals();
}

function deleteCustomAmal(id) {
  if (!confirm('এই আমল মুছে ফেলবেন?')) return;
  state.customAmalDefs = (state.customAmalDefs || []).filter(a => a.id !== id);
  // Clean from all days
  Object.keys(state.days).forEach(k => {
    if (state.days[k].customAmals) delete state.days[k].customAmals[id];
  });
  saveState();
  renderCustomAmals();
  showToast('মুছে ফেলা হয়েছে');
}

function renderCustomAmals() {
  const ul = document.getElementById('customAmalList');
  if (!ul) return;
  const defs = state.customAmalDefs || [];
  const day = getTodayData();
  if (!day.customAmals) day.customAmals = {};

  if (defs.length === 0) {
    ul.innerHTML = '<li class="text-muted fs-sm" style="padding:8px 0;">কোনো কাস্টম আমল নেই</li>';
    return;
  }

  ul.innerHTML = defs.map(a => {
    const checked = !!day.customAmals[a.id];
    return `
      <li class="custom-amal-item">
        <label class="custom-check">
          <input type="checkbox" ${checked ? 'checked' : ''} onchange="toggleCustomAmal('${a.id}', this.checked)">
          <span class="checkmark"></span>
        </label>
        <span class="item-text ${checked ? 'done' : ''}">${a.label}</span>
        <button class="delete-btn" onclick="deleteCustomAmal('${a.id}')" title="মুছুন">×</button>
      </li>
    `;
  }).join('');
}

// ==================== WEEKLY REPORT ====================
function updateWeeklyReport() {
  const container = document.getElementById('weeklyReport');
  if (!container) return;

  if (!state.startDate) {
    container.innerHTML = '<p class="text-muted text-center">যাত্রা শুরু করুন</p>';
    return;
  }

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const days = [];
  let completeCount = 0;
  let prayerSum = 0;

  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    const dayData = state.days[key];
    const status = getDayStatus(dayData);
    const prayerCount = dayData ? PRAYERS.filter(p => dayData.prayers[p]).length : 0;
    prayerSum += prayerCount;
    if (status === 'complete') completeCount++;

    const dayName = BN_DAYS[d.getDay()];
    const dateStr = d.getDate() + ' ' + BN_MONTHS[d.getMonth()].slice(0, 3);
    const icon = status === 'complete' ? '✅' : status === 'partial' ? '◐' : status === 'missed' ? '❌' : '·';

    days.push(`
      <div class="week-day">
        <span>${dayName} (${dateStr})</span>
        <span>${icon} ${prayerCount}/5</span>
      </div>
    `);
  }

  container.innerHTML = `
    ${days.join('')}
    <div class="week-summary">
      <div class="fw-bold">এই সপ্তাহে</div>
      <div class="mt-1">সম্পূর্ণ দিন: <strong>${completeCount}/7</strong></div>
      <div>গড় নামাজ: <strong>${(prayerSum / 7).toFixed(1)}/5</strong></div>
    </div>
  `;
}

// ==================== INIT ====================
function init() {
  loadState();
  applyTheme();
  ensureToday();

  // Register Service Worker for PWA
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  }

  document.getElementById('startJourneyBtn').addEventListener('click', startJourney);
  document.getElementById('settingsBtn').addEventListener('click', () => showPage('settings'));

  document.querySelectorAll('.stat-item[data-goto]').forEach(el => {
    el.addEventListener('click', () => showPage(el.dataset.goto));
  });

  document.getElementById('modalOverlay').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeModal();
  });
  document.getElementById('completionModal').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) closeCompletionModal();
  });

  updateDashboard();
  updateLearningPage();

  // Refresh phase every minute so waqt guide updates automatically
  setInterval(() => {
    if (document.getElementById('page-home')?.classList.contains('active')) {
      updateDashboard();
    }
  }, 60000);

  let pressTimer;
  const plusBtn = document.getElementById('istighfarPlus');
  if (plusBtn) {
    plusBtn.addEventListener('touchstart', (e) => {
      pressTimer = setTimeout(() => {
        addCounter('istighfar', 10);
        showToast('+10');
      }, 600);
    });
    plusBtn.addEventListener('touchend', () => clearTimeout(pressTimer));
    plusBtn.addEventListener('touchcancel', () => clearTimeout(pressTimer));
  }
}

document.addEventListener('DOMContentLoaded', init);
