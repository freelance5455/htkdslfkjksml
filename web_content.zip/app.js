(() => {
  const $ = id => document.getElementById(id);
  const audio = $("audio");
  const fileInput = $("fileInput");
  let songs = [];
  let current = -1;
  let shuffle = false;
  let repeat = false;
  let speed = 1;

  const stateKey = "javid_music_state_v1";
  let state = JSON.parse(localStorage.getItem(stateKey) || '{"favorites":[],"recent":[],"playlists":{}}');

  function saveState(){ localStorage.setItem(stateKey, JSON.stringify(state)); }
  function esc(s){ return String(s ?? "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function fmt(t){ if(!isFinite(t)) return "0:00"; t=Math.max(0,Math.floor(t)); return `${Math.floor(t/60)}:${String(t%60).padStart(2,"0")}`; }
  function toast(msg){ const el=$("toast"); el.textContent=msg; el.classList.add("show"); setTimeout(()=>el.classList.remove("show"),1800); }

  function render(){
    const q=($("searchBox")?.value||"").trim().toLowerCase();
    const list=songs.filter(s => !q || `${s.title} ${s.artist}`.toLowerCase().includes(q));
    renderSongs($("songs"), list);
    renderSongs($("librarySongs"), list);
    renderSongs($("results"), list);
    renderRecent();
    $("songsEmpty").classList.toggle("hidden", songs.length>0);
    $("recentEmpty").classList.toggle("hidden", state.recent.length>0);
    $("librarySongs").classList.toggle("hidden", false);
  }

  function renderSongs(el, list){
    if(!el) return;
    el.innerHTML = list.map((s,i) => {
      const realIndex=songs.indexOf(s);
      const fav=state.favorites.includes(s.id);
      return `<div class="song" data-index="${realIndex}">
        <div class="mini">♫</div>
        <div class="info"><b>${esc(s.title)}</b><small>${esc(s.artist)}</small></div>
        <button class="row-play" data-play="${realIndex}">▶</button>
        <button class="more" data-fav="${realIndex}">${fav?"♥":"♡"}</button>
      </div>`;
    }).join("");
    el.querySelectorAll("[data-play]").forEach(b=>b.onclick=e=>{e.stopPropagation();play(+b.dataset.play)});
    el.querySelectorAll("[data-fav]").forEach(b=>b.onclick=e=>{e.stopPropagation();toggleFav(+b.dataset.fav)});
    el.querySelectorAll(".song").forEach(x=>x.onclick=()=>play(+x.dataset.index));
  }

  function renderRecent(){
    const el=$("recent");
    if(!el) return;
    const recent=state.recent.map(id=>songs.find(s=>s.id===id)).filter(Boolean);
    el.innerHTML=recent.map(s=>`<div class="card" data-recent="${songs.indexOf(s)}"><div class="art">♫</div><b>${esc(s.title)}</b><small>${esc(s.artist)}</small></div>`).join("");
    el.querySelectorAll("[data-recent]").forEach(x=>x.onclick=()=>play(+x.dataset.recent));
  }

  function play(i){
    if(!songs[i]) return;
    current=i;
    const s=songs[i];
    audio.src=s.url;
    audio.playbackRate=speed;
    audio.play().catch(()=>{});
    $("nowTitle").textContent=s.title;
    $("nowArtist").textContent=s.artist;
    $("playBtn").textContent="❚❚";
    $("playerCover").textContent="♫";
    state.recent=[s.id,...state.recent.filter(x=>x!==s.id)].slice(0,12);
    saveState(); render();
  }
  function togglePlay(){
    if(current<0){ if(songs.length) play(0); return; }
    if(audio.paused){ audio.play(); $("playBtn").textContent="❚❚"; }
    else { audio.pause(); $("playBtn").textContent="▶"; }
  }
  function next(){
    if(!songs.length)return;
    let n;
    if(shuffle) n=Math.floor(Math.random()*songs.length);
    else n=(current+1)%songs.length;
    if(!repeat && current===songs.length-1 && !shuffle){ audio.pause(); $("playBtn").textContent="▶"; return; }
    play(n);
  }
  function prev(){
    if(!songs.length)return;
    if(audio.currentTime>3){audio.currentTime=0;return;}
    play((current-1+songs.length)%songs.length);
  }
  function toggleFav(i){
    const id=songs[i]?.id; if(!id)return;
    state.favorites=state.favorites.includes(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];
    saveState(); render();
  }

  fileInput.addEventListener("change", e=>{
    [...e.target.files].forEach(file=>{
      const id=`${file.name}_${file.size}_${file.lastModified}`;
      if(songs.some(s=>s.id===id))return;
      const parts=file.name.replace(/\.[^.]+$/,"").split(" - ");
      songs.push({id,title:parts[1]||parts[0],artist:parts[1]?parts[0]:"هنرمند نامشخص",url:URL.createObjectURL(file),file});
    });
    e.target.value="";
    render(); toast("آهنگ‌ها اضافه شدند");
  });

  ["openImport","libraryImport"].forEach(id=>$(id)?.addEventListener("click",()=>fileInput.click()));
  $("clearRecent")?.addEventListener("click",()=>{state.recent=[];saveState();render()});
  $("playBtn")?.addEventListener("click",togglePlay);
  $("nextBtn")?.addEventListener("click",next);
  $("prevBtn")?.addEventListener("click",prev);
  $("shuffleBtn")?.addEventListener("click",()=>{shuffle=!shuffle;$("shuffleBtn").classList.toggle("active",shuffle)});
  $("repeatBtn")?.addEventListener("click",()=>{repeat=!repeat;$("repeatBtn").classList.toggle("active",repeat)});
  $("favBtn")?.addEventListener("click",()=>current>=0&&toggleFav(current));
  $("expandBtn")?.addEventListener("click",()=>$("player").classList.toggle("expanded"));
  $("volume")?.addEventListener("input",e=>audio.volume=+e.target.value);
  $("speedBtn")?.addEventListener("click",()=>{speed=speed===1?1.25:speed===1.25?1.5:1;audio.playbackRate=speed;$("speedBtn").textContent=speed+"×"});
  $("seek")?.addEventListener("input",e=>{if(audio.duration)audio.currentTime=(+e.target.value/100)*audio.duration});
  $("searchBox")?.addEventListener("input",render);
  $("clearSearch")?.addEventListener("click",()=>{$("searchBox").value="";render()});

  audio.addEventListener("timeupdate",()=>{
    $("currentTime").textContent=fmt(audio.currentTime);
    $("duration").textContent=fmt(audio.duration);
    $("seek").value=audio.duration?(audio.currentTime/audio.duration)*100:0;
  });
  audio.addEventListener("play",()=>$("playBtn").textContent="❚❚");
  audio.addEventListener("pause",()=>$("playBtn").textContent="▶");
  audio.addEventListener("ended",next);

  document.querySelectorAll(".nav").forEach(btn=>btn.addEventListener("click",()=>{
    document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));
    document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active"); $(btn.dataset.page).classList.add("active");
  }));

  document.querySelectorAll("#libraryTabs button").forEach(btn=>btn.addEventListener("click",()=>{
    document.querySelectorAll("#libraryTabs button").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");
    if(btn.dataset.tab==="favorites"){
      const fav=songs.filter(s=>state.favorites.includes(s.id));
      renderSongs($("librarySongs"),fav);
    } else if(btn.dataset.tab==="songs") renderSongs($("librarySongs"),songs);
    else {
      $("librarySongs").innerHTML='<div class="empty">پلی‌لیست‌ها در این نسخه آماده ساخت هستند.</div>';
    }
  }));

  render();
})();
