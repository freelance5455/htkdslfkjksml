(() => {
const $ = id => document.getElementById(id);
const show = id => $(id).classList.remove('hidden');
const hide = id => $(id).classList.add('hidden');
let db=null, uid=null, room=null, role=null, approved=false, paused=false, msgRef=null, roomRef=null, lastRendered='';
const config=window.REMOTEX_FIREBASE_CONFIG||{};
const configured=config.apiKey && !config.apiKey.startsWith('PASTE_') && config.projectId!=='YOUR_PROJECT';
function status(t){$('setupMsg').textContent=t}
function switchTo(id){['setup','waiting','session'].forEach(hide);show(id)}
function code(){return String(Math.floor(100000+Math.random()*900000))}
function safeName(){return ($('displayName').value.trim()||'Phone').slice(0,32)}
function append(who,text,time){const el=document.createElement('div');el.className='termLine';const n=document.createElement('span');n.className='who';n.textContent=who+': ';const m=document.createElement('span');m.textContent=text;const tm=document.createElement('div');tm.className='time';tm.textContent=new Date(time||Date.now()).toLocaleTimeString();el.append(n,m,tm);$('terminal').append(el);$('terminal').scrollTop=$('terminal').scrollHeight}
function setupFirebase(){
 if(!configured){status('Firebase is not configured yet. Add your Firebase web-app settings in firebase-config.js, then host this folder on an HTTPS site.');return false}
 if(!window.firebase){status('Firebase SDK could not load. Check your internet connection.');return false}
 if(!firebase.apps.length)firebase.initializeApp(config);
 const auth=firebase.auth(); db=firebase.database();
 return auth.signInAnonymously().then(c=>{uid=c.user.uid;$('connection').textContent='ONLINE';return true}).catch(e=>{status('Firebase sign-in failed: '+e.message);return false});
}
async function ready(){if(!configured){setupFirebase();return false}if(!db){const ok=await setupFirebase();return !!ok}return true}
$('createBtn').onclick=async()=>{if(!await ready())return;role='controller';room=code();roomRef=db.ref('rooms/'+room);await roomRef.set({createdAt:Date.now(),owner:uid,ownerName:safeName(),status:'waiting',request:null,approved:false,paused:false});$('codeDisplay').textContent=room;show('approveBtn');$('approval').textContent='Waiting for a join request…';switchTo('waiting');listenForRequest()};
$('joinBtn').onclick=()=>{show('joinArea');$('sessionCode').focus()};
$('joinConfirm').onclick=async()=>{if(!await ready())return;const c=$('sessionCode').value.trim();if(!/^\d{6}$/.test(c)){status('Enter the six-digit session code.');return}const ref=db.ref('rooms/'+c);const snap=await ref.once('value');if(!snap.exists()||snap.val().status!=='waiting'){status('Session not found or no longer accepting requests.');return}room=c;role='target';roomRef=ref;await ref.child('request').set({uid,name:safeName(),at:Date.now()});switchTo('waiting');$('codeDisplay').textContent=room;$('approval').textContent='Join request sent. Waiting for the controller to approve this phone…';hide('approveBtn');listenForApproval()};
function listenForRequest(){roomRef.child('request').on('value',s=>{const r=s.val();if(r&&!approved){$('approval').textContent=(r.name||'A phone')+' wants to join. Approve only if you recognize this person.';show('approveBtn')}})}
$('approveBtn').onclick=async()=>{const s=await roomRef.child('request').once('value');if(!s.exists())return;await roomRef.update({approved:true,target:s.val(),status:'live'});approved=true;startSession()};
function listenForApproval(){roomRef.on('value',s=>{const v=s.val();if(!v||v.status==='ended'){endLocal('Session ended by the other phone.');return}if(v.approved&&v.status==='live'){approved=true;startSession()} })};
function startSession(){switchTo('session');$('sessionTitle').textContent='SESSION '+room;$('peerStatus').textContent=role==='controller'?'Target: approved phone connected':'Controller: connected and approved';$('terminal').innerHTML='';append('SYSTEM','Secure session approved. Live messages enabled.',Date.now());roomRef.child('messages').off();roomRef.child('messages').on('child_added',s=>{const m=s.val();if(m&&m.id!==lastRendered){lastRendered=m.id;append(m.name||'Phone',m.text||'',m.at)}});roomRef.child('paused').on('value',s=>{paused=!!s.val();$('pauseBtn').textContent=paused?'Resume':'Pause';$('peerStatus').textContent=paused?'Session paused':'Session active · '+(role==='controller'?'Target connected':'Controller connected')});roomRef.child('status').on('value',s=>{if(s.val()==='ended')endLocal('The other phone ended the session.');});}
$('sendBtn').onclick=async()=>{const text=$('message').value.trim();if(!text||text.length>500||paused)return;await roomRef.child('messages').push({id:uid+'-'+Date.now(),uid,name:safeName(),text,at:Date.now()});$('message').value='';$('count').textContent='0'};
$('message').oninput=()=>$('count').textContent=$('message').value.length;
$('clearBtn').onclick=()=>$('message').value='';
$('pauseBtn').onclick=async()=>{if(!roomRef)return;const s=await roomRef.child('paused').once('value');await roomRef.child('paused').set(!s.val())};
$('stopBtn').onclick=async()=>{if(roomRef)await roomRef.update({status:'ended',endedAt:Date.now()});endLocal('You ended the session.')};
$('cancelWait').onclick=async()=>{if(role==='controller'&&roomRef)await roomRef.update({status:'ended'});if(roomRef)roomRef.off();room=null;switchTo('setup')};
function endLocal(message){if(!room)return;append('SYSTEM',message,Date.now());roomRef&&roomRef.off();$('connection').textContent='ONLINE';room=null;setTimeout(()=>switchTo('setup'),1200)}
})();