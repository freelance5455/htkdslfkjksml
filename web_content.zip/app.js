const $ = id => document.getElementById(id);
let activeTab = "login";
let currentUser = null;
let tournaments = JSON.parse(localStorage.getItem("zozo_tournaments") || "null") || [
  {id:1,name:"Weekend Solo Clash",mode:"Solo",date:"",slots:48,prize:500,joined:[]},
  {id:2,name:"Duo Night Cup",mode:"Duo",date:"",slots:24,prize:800,joined:[]},
  {id:3,name:"Squad Community Showdown",mode:"Squad",date:"",slots:12,prize:1200,joined:[]}
];
let users = JSON.parse(localStorage.getItem("zozo_users") || "{}");
let coins = JSON.parse(localStorage.getItem("zozo_coins") || "{}");
const ADMIN_USERNAME = "zozoadmin"; // Demo only: change before testing. Not secure for production.
$("year").textContent = new Date().getFullYear();

function save(){localStorage.setItem("zozo_tournaments",JSON.stringify(tournaments));localStorage.setItem("zozo_users",JSON.stringify(users));localStorage.setItem("zozo_coins",JSON.stringify(coins));}
function setTab(tab){activeTab=tab;document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));$("authSubmit").textContent=tab==="login"?"Sign in":"Create account";$("authMessage").textContent="";}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>setTab(b.dataset.tab)));
$("authForm").addEventListener("submit",e=>{
 e.preventDefault();const name=$("username").value.trim();const pass=$("password").value;
 if(activeTab==="register"){
  if(users[name]){$("authMessage").textContent="Username already exists.";return;}
  users[name]=pass;coins[name]=100;save();
 } else if(!users[name]||users[name]!==pass){$("authMessage").textContent="Username or password is incorrect.";return;}
 currentUser=name;showDashboard();
});
function showDashboard(){
 $("authView").classList.add("hidden");$("dashboardView").classList.remove("hidden");$("logoutBtn").classList.remove("hidden");
 $("welcomeName").textContent=currentUser;$("coinCount").textContent=coins[currentUser]??100;
 $("adminPanel").classList.toggle("hidden",currentUser!==ADMIN_USERNAME);
 renderTournaments();
}
$("logoutBtn").addEventListener("click",()=>{currentUser=null;$("dashboardView").classList.add("hidden");$("authView").classList.remove("hidden");$("logoutBtn").classList.add("hidden");$("password").value="";});
function renderTournaments(){
 $("upcomingCount").textContent=tournaments.length;
 $("joinedCount").textContent=tournaments.filter(t=>t.joined.includes(currentUser)).length;
 const list=$("tournamentList");list.innerHTML="";
 if(!tournaments.length){list.innerHTML='<div class="empty">No tournaments yet. Check back soon!</div>';return;}
 tournaments.forEach(t=>{
  const joined=t.joined.includes(currentUser),full=t.joined.length>=Number(t.slots);
  const date=t.date?new Date(t.date).toLocaleString():"Schedule to be announced";
  const article=document.createElement("article");article.className="tournament";
  article.innerHTML=`<span class="chip">${escapeHtml(t.mode)} MODE</span><h3>${escapeHtml(t.name)}</h3><div class="details"><span>◷ ${escapeHtml(date)}</span><span>♙ ${t.joined.length}/${t.slots} slots</span><span>★ ${t.prize} virtual coins</span></div><button class="${joined?"secondary":"primary"}" ${joined||full?"disabled":""}>${joined?"Joined":full?"Slots full":"Join for free"}</button>${currentUser===ADMIN_USERNAME?'<button class="ghost delete-btn" style="margin-top:8px">Delete tournament</button>':""}`;
  const joinBtn=article.querySelector("button");if(!joined&&!full)joinBtn.addEventListener("click",()=>{t.joined.push(currentUser);save();renderTournaments();});
  const del=article.querySelector(".delete-btn");if(del)del.addEventListener("click",()=>{tournaments=tournaments.filter(x=>x.id!==t.id);save();renderTournaments();});
  list.appendChild(article);
 });
}
$("tournamentForm").addEventListener("submit",e=>{
 e.preventDefault();if(currentUser!==ADMIN_USERNAME)return;
 tournaments.unshift({id:Date.now(),name:$("tName").value.trim(),mode:$("tMode").value,date:$("tDate").value,slots:Number($("tSlots").value),prize:Number($("tPrize").value),joined:[]});
 save();e.target.reset();renderTournaments();
});
$("saveSupport").addEventListener("click",()=>{if(currentUser!==ADMIN_USERNAME)return;localStorage.setItem("zozo_support",$("supportInput").value);$("supportText").textContent=$("supportInput").value||"Add your official support details in the Admin Panel.";});
$("supportText").textContent=localStorage.getItem("zozo_support")||"Add your official support details in the Admin Panel.";
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
