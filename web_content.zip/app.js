const fonts = [
{name:"Inter",cat:"Modernas",family:"Inter, sans-serif"},
{name:"Playfair Display",cat:"Elegantes",family:"'Playfair Display', serif"},
{name:"Great Vibes",cat:"Caligráficas",family:"'Great Vibes', cursive"},
{name:"DM Serif Display",cat:"Elegantes",family:"'DM Serif Display', serif"},
{name:"Roboto Slab",cat:"Modernas",family:"'Roboto Slab', serif"},
{name:"DM Mono",cat:"Monoespaçadas",family:"'DM Mono', monospace"},
{name:"Arial",cat:"Minimalistas",family:"Arial, sans-serif"},
{name:"Georgia",cat:"Elegantes",family:"Georgia, serif"},
{name:"Courier New",cat:"Monoespaçadas",family:"'Courier New', monospace"},
{name:"Times New Roman",cat:"Minimalistas",family:"'Times New Roman', serif"},
{name:"Gótica (simulada)",cat:"Góticas",family:"Georgia, serif",style:"font-weight:700;letter-spacing:1px;text-shadow:1px 1px #625b8b"},
{name:"Negrito",cat:"Modernas",family:"Inter, sans-serif",style:"font-weight:800"}
];
const list=document.querySelector('#font-list'), sample=document.querySelector('#sample'), search=document.querySelector('#search'), category=document.querySelector('#category');
let favorites=new Set(), selected="";
function render(){
 const q=search.value.toLowerCase(), c=category.value, filtered=fonts.filter(f=>(c==='Todas'||f.cat===c)&&(f.name.toLowerCase().includes(q)||f.cat.toLowerCase().includes(q)));
 document.querySelector('#count').textContent=filtered.length+' fontes';
 list.innerHTML='';
 filtered.forEach(f=>{
  const card=document.createElement('article');card.className='font-card';
  const head=document.createElement('div');head.className='card-head';
  const info=document.createElement('div');info.innerHTML='<div class="font-name"></div><div class="category"></div>';
  info.querySelector('.font-name').textContent=f.name;info.querySelector('.category').textContent=f.cat;
  const fav=document.createElement('button');fav.textContent=favorites.has(f.name)?'♥':'♡';fav.setAttribute('aria-label','Favoritar '+f.name);fav.onclick=()=>{favorites.has(f.name)?favorites.delete(f.name):favorites.add(f.name);render()};
  head.append(info,fav);
  const preview=document.createElement('div');preview.className='sample-text';preview.textContent=sample.value||'O teu estilo começa aqui';preview.style.fontFamily=f.family;if(f.style)preview.style.cssText+=f.style;
  const actions=document.createElement('div');actions.className='actions';
  const test=document.createElement('button');test.textContent='Pré-visualizar';test.onclick=()=>{selected=f.name;document.querySelectorAll('.font-card').forEach(x=>x.style.borderColor='');card.style.borderColor='var(--mint)'};
  const apply=document.createElement('button');apply.className='primary';apply.textContent='Selecionar';apply.onclick=()=>{selected=f.name;alert('Selecionaste '+f.name+'. Esta escolha fica apenas nesta demonstração e não altera a fonte global do Android.')};
  actions.append(test,apply);card.append(head,preview,actions);list.append(card);
 });
}
sample.addEventListener('input',render);search.addEventListener('input',render);category.addEventListener('change',render);render();
if('serviceWorker' in navigator) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
