const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const I={play:'<path d="M7 4.5v15l12-7.5z"/>',pause:'<path d="M8 5v14M16 5v14"/>',
back:'<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M10 9.6l1.4-.9V15"/><rect x="13" y="9" width="3.2" height="6" rx="1.6"/>',
fwd:'<g transform="translate(24 0) scale(-1 1)"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></g><path d="M8.6 9.6L10 8.7V15"/><rect x="11.6" y="9" width="3.2" height="6" rx="1.6"/>',
vol:'<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>',
mute:'<path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path d="M16 9.5l5 5M21 9.5l-5 5"/>',
audio:'<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/>',
sub:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M7 12h3M13 12h4M7 15.5h6M16 15.5h1"/>',
aspect:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10V8.5h1.5M17 14v1.5h-1.5"/>',
pip:'<rect x="3" y="5" width="18" height="14" rx="2.5"/><rect x="12" y="11" width="6" height="4.5" rx="1"/>',
full:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',exit:'<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
more:'<circle cx="12" cy="5" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="19" r="1.6" fill="currentColor"/>',
folder:'<path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V17a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
list:'<path d="M4 6h16M4 12h16M4 18h10"/>',close:'<path d="M6 6l12 12M18 6L6 18"/>',
search:'<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/>',download:'<path d="M12 4v11M7.5 11L12 15.5 16.5 11M5 19h14"/>',
dual:'<path d="M3 14v-2a6 6 0 0 1 12 0v2"/><rect x="2" y="13" width="3.4" height="5" rx="1.4"/><rect x="12.6" y="13" width="3.4" height="5" rx="1.4"/><path d="M19 8.5a5 5 0 0 1 0 7M21.5 6a9 9 0 0 1 0 12"/>',prev:'<path d="M6 5v14M19 5.5v13L9 12z"/>',next:'<path d="M18 5v14M5 5.5v13L15 12z"/>',loop:'<path d="M17 3l3 3-3 3"/><path d="M4 11V9a3 3 0 0 1 3-3h13"/><path d="M7 21l-3-3 3-3"/><path d="M20 13v2a3 3 0 0 1-3 3H4"/>',shot:'<path d="M4 8a2 2 0 0 1 2-2h2l1.5-2h5L16 6h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="12.5" r="3.5"/>',speed:'<path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4-5"/>',upload:'<path d="M12 16V5M7.5 9L12 4.5 16.5 9M5 19h14"/>'};
const ic=n=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${I[n]}</svg>`;
$$('[data-ic]').forEach(e=>e.innerHTML=ic(e.dataset.ic));
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const pad=n=>String(n).padStart(2,'0');
const fmt=t=>{t=Math.floor(isFinite(t)?t:0);const h=t/3600|0,m=t%3600/60|0,s=t%60;return(h?h+':'+pad(m):pad(m))+':'+pad(s)};
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},SV=(k,x)=>{try{localStorage.setItem(k,JSON.stringify(x))}catch{}};

const v=$('#v'),stage=$('#stage'),tl=$('#tl'),modal=$('#modal'),more=$('#more');
let pl=LS('ys_pl',[]),hist=LS('ys_hist',[]),cur=LS('ys_cur',-1),files=new Map(),
remain=false,mode=0,tab='pl',url,resume=0,lastSave=0,lang='en',drag=false,skip=false,hideT,toastT;
const fid=f=>`${f.name}|${f.size}|${f.lastModified}`;
const M=['Fit Screen','Fill / Crop','Stretch','Original','9:16 Portrait','4:3 Classic'];

/* logo */
(()=>{const c=$('#logo'),x=c.getContext('2d'),d=devicePixelRatio||1,S=56;c.width=c.height=S*d;x.scale(d,d);
const col=['#00e5ff','#8b5cff','#ff3df2'];
(function f(t){x.clearRect(0,0,S,S);x.save();x.translate(S/2,S/2);
for(let i=0;i<3;i++){x.save();x.rotate(t/1000*(i%2?-1:1)*(1+i*.5)+i*2);const g=x.createLinearGradient(-S/2,0,S/2,0);g.addColorStop(0,col[i]);g.addColorStop(1,'transparent');x.strokeStyle=g;x.lineWidth=2.4;x.lineCap='round';x.beginPath();x.arc(0,0,25-i*5,0,Math.PI*1.35);x.stroke();x.restore()}
const p=1+Math.sin(t/400)*.07;x.scale(p,p);const g=x.createLinearGradient(-8,-10,10,10);g.addColorStop(0,'#fff');g.addColorStop(1,'#00e5ff');x.fillStyle=g;x.shadowColor='#00e5ff';x.shadowBlur=14;x.beginPath();x.moveTo(-6,-9);x.lineTo(10,0);x.lineTo(-6,9);x.closePath();x.fill();x.restore();requestAnimationFrame(f)})(0)})();

/* toast + auto-hide */
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>e.classList.remove('show'),1600)}
function show(){stage.classList.remove('idle');clearTimeout(hideT);hideT=setTimeout(()=>{if(!modal.classList.contains('show'))stage.classList.add('idle')},10000)}
stage.addEventListener('pointermove',show);stage.addEventListener('keydown',show);
stage.addEventListener('pointerdown',e=>{skip=stage.classList.contains('idle')&&e.pointerType!=='mouse';show()},true);
v.onclick=()=>{if(skip){skip=false;return}A.play()};v.ondblclick=()=>A.full();show();

/* playlist + history */
function add(list){const fs=[...list].filter(f=>f.type.startsWith('video/')||/\.(mkv|mp4|webm|avi|mov|m4v|ogv|ts|flv|wmv|3gp)$/i.test(f.name));if(!fs.length)return;let first=-1;
fs.forEach(f=>{const id=fid(f);files.set(id,f);let i=pl.findIndex(p=>p.id===id);if(i<0){pl.push({id,name:f.name,size:f.size});i=pl.length-1}if(first<0)first=i});SV('ys_pl',pl);play(first)}
function play(i){const p=pl[i];if(!p)return;const f=files.get(p.id);if(!f){toast('Select this file again to play it');$('#file').click();return}
cur=i;SV('ys_cur',i);if(url)URL.revokeObjectURL(url);url=URL.createObjectURL(f);clearSubs();
const old=hist.find(h=>h.id===p.id);resume=old?old.pos:0;hist=hist.filter(h=>h.id!==p.id);hist.unshift({id:p.id,name:p.name,pos:resume,dur:old?old.dur:0,at:Date.now()});hist=hist.slice(0,60);SV('ys_hist',hist);
v.src=url;$('#fname').textContent=p.name;$('#empty').hidden=true;v.play().catch(()=>{});render();show()}
function render(){const src=tab==='pl'?pl:hist;
$('#list').innerHTML=src.length?src.map((p,i)=>`<li data-i="${i}" class="${tab==='pl'&&i===cur?'on':''} ${files.has(p.id)?'':'off'}"><div class="nm"><b>${esc(p.name)}</b><small>${tab==='pl'?(p.size/1048576).toFixed(1)+' MB':fmt(p.pos)+' / '+fmt(p.dur)}</small></div><span class="x" data-rm="${i}">${ic('close')}</span></li>`).join(''):'<li class="none">Nothing here yet</li>'}
$('#list').onclick=e=>{const li=e.target.closest('li[data-i]');if(!li)return;const i=+li.dataset.i,rm=e.target.closest('[data-rm]');
if(rm){if(tab==='pl'){pl.splice(i,1);if(i<cur)cur--;else if(i===cur)cur=-1;SV('ys_pl',pl);SV('ys_cur',cur)}else{hist.splice(i,1);SV('ys_hist',hist)}render();return}
if(tab==='pl')play(i);else{const h=hist[i];let k=pl.findIndex(p=>p.id===h.id);if(k<0){pl.push({id:h.id,name:h.name,size:0});k=pl.length-1;SV('ys_pl',pl)}play(k)}};
$$('.tabs button').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;$$('.tabs button').forEach(x=>x.classList.toggle('on',x===b));render()});
$('#file').onchange=e=>{add(e.target.files);e.target.value=''};

/* timeline */
function tick(){const d=v.duration||0,t=v.currentTime,p=d?t/d*100:0;
$('#fill').style.width=$('#knob').style.left=p+'%';$('#knob').style.width='14px';
stage.style.setProperty('--tc',p<33.33?'#19e86b':p<66.66?'#ffd60a':'#ff3b4e');
if(d&&v.buffered.length)$('#buf').style.width=v.buffered.end(v.buffered.length-1)/d*100+'%';
$('#time').textContent=remain?'-'+fmt(d-t):fmt(t)+' / '+fmt(d);
if(Date.now()-lastSave>2000){lastSave=Date.now();const h=hist.find(x=>pl[cur]&&x.id===pl[cur].id);if(h&&d){h.pos=t;h.dur=d;SV('ys_hist',hist)}}}
const pos=e=>{const r=tl.getBoundingClientRect();return Math.min(1,Math.max(0,(e.clientX-r.left)/r.width))};
const seek=e=>{if(v.duration){v.currentTime=pos(e)*v.duration;tick()}};
tl.onpointerdown=e=>{tl.setPointerCapture(e.pointerId);drag=true;tl.classList.add('drag');seek(e)};
tl.onpointermove=e=>{const r=tl.getBoundingClientRect(),tip=$('#tip');tip.textContent=fmt(pos(e)*(v.duration||0));tip.style.left=Math.min(r.width-30,Math.max(30,e.clientX-r.left))+'px';if(drag)seek(e)};
tl.onpointerup=tl.onpointercancel=()=>{drag=false;tl.classList.remove('drag')};
v.addEventListener('timeupdate',tick);v.addEventListener('progress',tick);v.addEventListener('durationchange',tick);
v.addEventListener('loadedmetadata',()=>{if(resume>2&&resume<v.duration-3)v.currentTime=resume;resume=0;tracks();info();tick()});v.addEventListener('resize',info);
v.onplay=v.onpause=()=>$('#bPlay i').innerHTML=ic(v.paused?'play':'pause');
v.onvolumechange=()=>{$('#bMute i').innerHTML=ic(v.muted||!v.volume?'mute':'vol');$('#vol').value=v.muted?0:v.volume};
v.onended=()=>{if(cur+1<pl.length)play(cur+1)};
$('#vol').oninput=e=>{v.volume=+e.target.value;v.muted=false};

/* audio tracks */
function tracks(){const a=v.audioTracks,n=a?a.length:0,b=$('#abadge');b.hidden=n<2;b.textContent=n;$('#bAudio').classList.toggle('multi',n>1)}
function apopRender(){const a=v.audioTracks,p=$('#apop');let h='<div class="ph">Audio Track</div>';
if(!a)h+='<p class="mu">This browser does not expose audio tracks. Use Safari, or enable chrome://flags/#enable-experimental-web-platform-features in Chrome.</p>';
else if(a.length<2)h+='<p class="mu">'+(a.length?'This video has a single audio track.':'Open a video first.')+'</p>';
else h+=[...a].map((t,i)=>`<button data-at="${i}" class="${t.enabled?'on':''}">${ic('audio')}<span>Track ${i+1}${t.label?' - '+esc(t.label):''}${t.language?' ('+esc(t.language)+')':''}</span></button>`).join('');p.innerHTML=h}
$('#apop').onclick=e=>{const b=e.target.closest('[data-at]');if(!b)return;const n=+b.dataset.at,a=v.audioTracks;[...a].forEach((t,i)=>t.enabled=i===n);apopRender();toast('Audio track '+(n+1)+' / '+a.length)};
const qual=(w,h)=>{const m=Math.max(w,h);return m>=7680?'8K':m>=3840?'4K':m>=2560?'2K':m>=1920?'1080p':m>=1280?'720p':m>=854?'480p':m>=640?'360p':m>0?'240p':''};
function info(){const w=v.videoWidth,h=v.videoHeight,f=pl[cur]&&files.get(pl[cur].id);$('#info').hidden=!w;$('#iq').textContent=qual(w,h);$('#iq').dataset.q=qual(w,h);$('#ir').textContent=w+' \u00d7 '+h;
$('#is').textContent=f?(f.size>=1073741824?(f.size/1073741824).toFixed(2)+' GB':Math.round(f.size/1048576)+' MB'):''}
/* subtitles */
const srt2vtt=s=>'WEBVTT\n\n'+s.replace(/^\uFEFF/,'').replace(/\r/g,'').replace(/(\d+:\d+:\d+),(\d+)/g,'$1.$2');
function clearSubs(){v.querySelectorAll('track').forEach(t=>t.remove())}
function setSub(text,label){clearSubs();const t=document.createElement('track');t.kind='subtitles';t.label=label;t.default=true;t.src=URL.createObjectURL(new Blob([text],{type:'text/vtt'}));v.appendChild(t);t.track.mode='showing';toast('Subtitles: '+label);modal.classList.remove('show')}
async function subFile(f){if(!f)return;const t=await f.text();setSub(/\.vtt$/i.test(f.name)?t:srt2vtt(t),f.name)}
$('#subf').onchange=e=>{subFile(e.target.files[0]);e.target.value=''};
let CF=LS('ys_os',{k:'',u:'',p:''}),osTok=null,osBase='api.opensubtitles.com';
$('#ok').value=CF.k;$('#ou').value=CF.u;$('#op').value=CF.p;
const osq=n=>n.replace(/\.[^.]+$/,'').replace(/[._]+/g,' ').replace(/\s*[\[(]?\b((19|20)\d{2}|2160p|1080p|720p|480p|x26[45]|bluray|web-?dl|webrip|hdrip|brrip)\b.*$/i,'').trim();
async function os(path,opt={}){const h={'Api-Key':CF.k,'Content-Type':'application/json',Accept:'application/json'};if(osTok)h.Authorization='Bearer '+osTok;
const r=await fetch(`https://${osBase}/api/v1${path}`,{...opt,headers:h});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.message||'Error '+r.status);return j}
async function login(){if(osTok)return;if(!CF.u||!CF.p)throw new Error('Add your OpenSubtitles username and password to download');
const j=await os('/login',{method:'POST',body:JSON.stringify({username:CF.u,password:CF.p})});osTok=j.token;if(j.base_url)osBase=j.base_url}
async function search(){const r=$('#res'),L=lang==='ur'?'Urdu':'English',typed=$('#sq').value.trim(),q=typed||osq(pl[cur]?pl[cur].name:'');
if(!q){r.innerHTML='<p class="mu">Type a title or open a video first.</p>';return}
const web=`https://www.opensubtitles.com/en/search-all/q-${encodeURIComponent(q)}`;
if(!CF.k){r.innerHTML=`<p class="mu">Add your free API key above for in-player search. Or <a href="${web}" target="_blank" rel="noopener">search on the website</a> and drop the .srt onto the player.</p>`;return}
r.innerHTML='<p class="mu">Searching...</p>';
try{const j=await os(`/subtitles?query=${encodeURIComponent(q)}&languages=${lang}&order_by=download_count`);
const d=(j.data||[]).filter(x=>x.attributes.files&&x.attributes.files[0]).slice(0,8);
r.innerHTML=d.length?d.map(x=>{const a=x.attributes,n=a.release||a.files[0].file_name||'subtitle';return`<div class="rs"><div class="nm"><b>${esc(n)}</b><small>${L} | ${a.download_count||0} downloads</small></div><button class="ib" data-fid="${a.files[0].file_id}" data-nm="${esc(n)}">${ic('download')}</button></div>`}).join(''):'<p class="mu">No subtitles found. Try a shorter title.</p>'}
catch(e){r.innerHTML=`<p class="mu">${esc(e.message)}. You can also <a href="${web}" target="_blank" rel="noopener">search on the website</a>.</p>`}}
$('#res').onclick=async e=>{const b=e.target.closest('[data-fid]');if(!b)return;toast('Downloading...');
try{await login();const j=await os('/download',{method:'POST',body:JSON.stringify({file_id:+b.dataset.fid,sub_format:'srt'})});
try{const t=await(await fetch(j.link)).text();setSub(srt2vtt(t),b.dataset.nm)}catch{window.open(j.link,'_blank');toast('Saved to downloads. Drop the file onto the player')}}
catch(x){$('#res').insertAdjacentHTML('afterbegin',`<p class="mu">${esc(x.message)}</p>`)}};
$('#sq').onkeydown=e=>{if(e.key==='Enter')search()};
$$('.chips button').forEach(b=>b.onclick=()=>{lang=b.dataset.lang;$$('.chips button').forEach(x=>x.classList.toggle('on',x===b))});

/* actions */
const A={open:()=>$('#file').click(),side:()=>document.body.classList.toggle('sv'),
play:()=>v.src&&(v.paused?v.play():v.pause()),back:()=>v.currentTime=Math.max(0,v.currentTime-10),fwd:()=>v.currentTime=Math.min(v.duration||0,v.currentTime+10),
mute:()=>v.muted=!v.muted,timer:()=>{remain=!remain;tick()},
aspect:()=>{mode=(mode+1)%6;stage.dataset.m=mode;toast(M[mode])},
subs:()=>modal.classList.add('show'),closeSub:()=>modal.classList.remove('show'),subFile:()=>$('#subf').click(),search,subOff:()=>{clearSubs();modal.classList.remove('show');toast('Subtitles off')},
audio:()=>{apopRender();$('#apop').classList.toggle('show')},
prev:()=>{if(v.currentTime>3||cur<1)v.currentTime=0;else play(cur-1)},next:()=>{if(cur+1<pl.length)play(cur+1);else toast('End of playlist')},
speed:()=>{const S=[.5,.75,1,1.25,1.5,2],n=S[(S.indexOf(v.playbackRate)+1)%S.length]||1;v.playbackRate=n;$('#bSpd').textContent=n+'x';toast('Speed '+n+'x')},
loop:()=>{v.loop=!v.loop;$$('[data-act=loop]').forEach(b=>b.classList.toggle('act',v.loop));toast(v.loop?'Loop on':'Loop off')},
shot:()=>{if(!v.videoWidth)return;const c=document.createElement('canvas');c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d').drawImage(v,0,0);c.toBlob(b=>{const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='lumen-glass-'+fmt(v.currentTime).replace(/:/g,'-')+'.png';a.click();toast('Screenshot saved')})},
pip:()=>document.pictureInPictureElement?document.exitPictureInPicture():v.requestPictureInPicture?v.requestPictureInPicture().catch(()=>toast('PiP unavailable')):toast('PiP unsupported'),
full:()=>document.fullscreenElement?document.exitFullscreen():stage.requestFullscreen&&stage.requestFullscreen(),
more:()=>more.classList.toggle('show'),
saveCfg:()=>{CF={k:$('#ok').value.trim(),u:$('#ou').value.trim(),p:$('#op').value};SV('ys_os',CF);osTok=null;osBase='api.opensubtitles.com';toast('Saved')},
clear:()=>{if(tab==='pl'){pl=[];cur=-1;SV('ys_pl',pl);SV('ys_cur',-1)}else{hist=[];SV('ys_hist',hist)}render()}};
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');
if(b){A[b.dataset.act]&&A[b.dataset.act]();if(b.closest('#more'))more.classList.remove('show')}else if(!e.target.closest('#more'))more.classList.remove('show');
if(!e.target.closest('#apop,[data-act=audio]'))$('#apop').classList.remove('show');
if(e.target===modal)modal.classList.remove('show')});
document.addEventListener('fullscreenchange',()=>$('#bFull i').innerHTML=ic(document.fullscreenElement?'exit':'full'));

/* keys + drop */
document.addEventListener('keydown',e=>{if(/INPUT|TEXTAREA/.test(e.target.tagName)&&e.target.type!=='range')return;const k=e.key;show();
if(k===' '||k==='k'){e.preventDefault();A.play()}else if(k==='ArrowLeft')A.back();else if(k==='ArrowRight')A.fwd();
else if(k==='ArrowUp'){e.preventDefault();v.volume=Math.min(1,v.volume+.05)}else if(k==='ArrowDown'){e.preventDefault();v.volume=Math.max(0,v.volume-.05)}
else if(k==='n')A.next();else if(k==='p')A.prev();else if(k==='m')A.mute();else if(k==='f')A.full();else if(k==='Escape')modal.classList.remove('show')});
addEventListener('dragover',e=>e.preventDefault());
addEventListener('drop',e=>{e.preventDefault();const fs=[...e.dataTransfer.files],s=fs.find(f=>/\.(srt|vtt)$/i.test(f.name));if(s)subFile(s);else add(fs)});
render();tick();
