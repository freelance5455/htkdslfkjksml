const navs=document.querySelectorAll('.nav');const views=document.querySelectorAll('.view');const title=document.getElementById('title');
const names={chat:'المساعد القانوني',cases:'القضايا',docs:'المستندات',drafts:'الصياغة',calendar:'المواعيد'};
navs.forEach(n=>n.onclick=()=>{navs.forEach(x=>x.classList.remove('active'));n.classList.add('active');views.forEach(v=>v.classList.remove('active'));document.getElementById(n.dataset.view).classList.add('active');title.textContent=names[n.dataset.view]});
const messages=document.getElementById('messages'),prompt=document.getElementById('prompt'),files=document.getElementById('files');
let legalDocs=[];
document.getElementById('fileInput').onchange=async e=>{
 files.innerHTML=''; legalDocs=[];
 for(const f of [...e.target.files]){
  const s=document.createElement('span');s.className='chip';s.textContent='⏳ '+f.name;files.appendChild(s);
  try{
 let d;
 if(/\.(png|jpe?g)$/i.test(f.name)){s.textContent='⏳ OCR '+f.name; d={name:f.name,pages:[{page:1,text:await extractImageText(f)}]};}
 else d=await extractDocument(f);
 legalDocs.push(d); s.textContent='✅ '+f.name;
}catch(err){s.textContent='⚠️ '+f.name+' (تعذر القراءة)';}
 }
};
function add(text,cls){const d=document.createElement('div');d.className='message '+cls;d.innerHTML=cls==='user'?`<p>${escapeHtml(text)}</p>`:`<b>مساعد المحامي</b><p>${text}</p>`;messages.appendChild(d);messages.scrollTop=messages.scrollHeight}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
import('./web/ai.js').then(({askLegalAI})=>import('./web/documents.js').then(({extractDocument,buildContext})=>{
document.getElementById('send').onclick=async()=>{
 const q=prompt.value.trim(); if(!q)return;
 add(q,'user'); prompt.value='';
 add('جاري تشغيل النموذج المجاني على جهازك… أول تشغيل قد يستغرق وقتًا لتحميل النموذج.','ai');
 try {
   const answer=await askLegalAI(q, buildContext(legalDocs));
   messages.lastElementChild.querySelector('p').textContent=answer;
 } catch(e) {
   messages.lastElementChild.querySelector('p').textContent='تعذر تشغيل النموذج على هذا الجهاز. جرّب متصفحًا يدعم WebGPU أو استخدم نسخة الخادم المحلية.';
 }
};
});
prompt.onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();document.getElementById('send').click()}};

document.getElementById('searchBtn')?.addEventListener('click',()=>{
 const q=document.getElementById('docSearch').value, box=document.getElementById('searchResults');
 const hits=searchDocuments(legalDocs,q);
 box.innerHTML=hits.length?hits.map(h=>`<div class="result">📄 ${escapeHtml(h.name)} — صفحة ${h.page}<br>${escapeHtml(h.text.slice(0,220))}</div>`).join(""):"لا توجد نتائج.";
});
const caseList=document.getElementById('caseList');
function renderCases(){
 const a=JSON.parse(localStorage.getItem('legal_cases')||'[]');
 caseList.innerHTML=a.length?a.map((c,i)=>`<div class="card"><strong>${escapeHtml(c.name)}</strong><span>العميل: ${escapeHtml(c.client)}<br>رقم القضية: ${escapeHtml(c.number)}</span><button onclick="deleteCase(${i})">حذف</button></div>`).join(""):'<div class="empty">لا توجد قضايا محفوظة.</div>';
}
window.deleteCase=i=>{const a=JSON.parse(localStorage.getItem('legal_cases')||'[]');a.splice(i,1);localStorage.setItem('legal_cases',JSON.stringify(a));renderCases()};
renderCases();

import { searchDocuments } from './web/search.js';
import * as API from './api.js';

const authBox=document.getElementById('auth'), appBox=document.getElementById('app');
function showApp(){authBox.style.display='none';appBox.style.display='flex';loadRemoteCases();loadRemoteAppointments();}
function showAuth(){authBox.style.display='grid';appBox.style.display='none';}
async function auth(action){
 const u=document.getElementById('authUser').value.trim(),p=document.getElementById('authPass').value;
 const msg=document.getElementById('authMsg');
 try{
  if(!u||p.length<10) throw new Error('اسم المستخدم مطلوب وكلمة المرور 10 أحرف على الأقل');
  if(action==='register'){await API.register(u,p);msg.textContent='تم إنشاء الحساب، اضغط دخول.';return;}
  const d=await API.login(u,p);localStorage.setItem('LEGAL_TOKEN',d.token);showApp();
 }catch(e){msg.textContent=e.message}
}
document.getElementById('loginBtn').onclick=()=>auth('login');
document.getElementById('registerBtn').onclick=()=>auth('register');

async function loadRemoteCases(){
 const box=document.getElementById('caseList'); if(!box)return;
 try{
  const a=await API.cases();
  box.innerHTML=a.length?a.map(c=>`<div class="card"><strong>${escapeHtml(c.name)}</strong><span>العميل: ${escapeHtml(c.client)}<br>رقم القضية: ${escapeHtml(c.case_number)}</span><button onclick="removeRemoteCase(${c.id})">حذف</button></div>`).join(""):'<div class="empty">لا توجد قضايا محفوظة.</div>';
 }catch(e){box.innerHTML='<div class="empty">تعذر تحميل القضايا: '+escapeHtml(e.message)+'</div>'}
}
window.removeRemoteCase=async id=>{try{await API.deleteCase(id);loadRemoteCases()}catch(e){alert(e.message)}};
document.getElementById('saveCase')?.addEventListener('click',async()=>{
 const name=document.getElementById('caseName').value.trim(),client=document.getElementById('clientName').value.trim(),number=document.getElementById('caseNumber').value.trim();
 if(!name)return alert('اكتب اسم القضية');
 try{await API.addCase({name,client,case_number:number});document.getElementById('caseName').value='';document.getElementById('clientName').value='';document.getElementById('caseNumber').value='';loadRemoteCases()}catch(e){alert(e.message)}
});

async function loadRemoteAppointments(){
 const box=document.getElementById('apptList');if(!box)return;
 try{const a=await API.appointments();box.innerHTML=a.length?a.map(x=>`<div class="card"><strong>${escapeHtml(x.title)}</strong><span>${escapeHtml(x.due)}<br>${escapeHtml(x.notes||'')}</span></div>`).join(""):'<div class="empty">لا توجد مواعيد.</div>'}
 catch(e){box.innerHTML='<div class="empty">'+escapeHtml(e.message)+'</div>'}
}
document.getElementById('saveAppt')?.addEventListener('click',async()=>{
 const title=document.getElementById('apptTitle').value.trim(),due=document.getElementById('apptDue').value,notes=document.getElementById('apptNotes').value.trim();
 if(!title||!due)return alert('اكتب عنوان الموعد وتاريخه');
 try{await API.addAppointment({title,due,notes});document.getElementById('apptTitle').value='';document.getElementById('apptDue').value='';document.getElementById('apptNotes').value='';loadRemoteAppointments()}catch(e){alert(e.message)}
});
if(API.token()) showApp(); else showAuth();
