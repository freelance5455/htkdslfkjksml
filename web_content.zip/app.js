const $ = (id) => document.getElementById(id);
const messages = $("messages");
const input = $("input");
const statusEl = $("status");
const voiceBtn = $("voiceBtn");
const voiceLabel = $("voiceLabel");
const orb = document.querySelector(".orb");
const dialog = $("settingsDialog");
let recognition = null;
let isListening = false;

function addMessage(text, role="assistant") {
  const row = document.createElement("article");
  row.className = `message ${role}`;
  const avatar = document.createElement("span");
  avatar.className = "avatar";
  avatar.textContent = role === "assistant" ? "A" : "V";
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  row.append(avatar, bubble);
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
}

function getName() {
  return localStorage.getItem("abbyName") || "Abby";
}

function localReply(text) {
  const t = text.toLocaleLowerCase("pt-BR");
  if (/^(oi|olá|ola|e aí|eai|bom dia|boa tarde|boa noite)\b/.test(t))
    return `Olá! 💙 Eu sou a ${getName()}. Ainda estou em fase de protótipo, mas já consigo conversar por texto e voz quando o navegador oferece esse recurso.`;
  if (t.includes("seu nome") || t.includes("quem é você") || t.includes("quem e voce"))
    return `Meu nome é ${getName()}, sua assistente pessoal em desenvolvimento.`;
  if (t.includes("hora") || t.includes("data") || t.includes("dia é hoje"))
    return `A data e hora deste aparelho são: ${new Date().toLocaleString("pt-BR")}.`;
  if (t.includes("ajuda") || t.includes("o que você faz") || t.includes("o que voce faz"))
    return "Posso conversar por texto e voz, informar a hora e a data, abrir o YouTube, pesquisar na internet e abrir sites. Para conversas inteligentes, conecte um servidor de IA nas configurações.";
  if (t.includes("abacaxi")) return "Abacaxi detectado 🍍😄";
  return `Entendi! 💙 Ainda estou funcionando no modo demonstrativo, então não tenho um modelo de IA conectado. Você escreveu: “${text}”. Podemos conectar um servidor de IA nas configurações quando ele estiver pronto.`;
}

function runLocalCommand(text) {
  const commandText = text.replace(/^\s*abby[\s,:-]*/i, "").trim();
  const t = commandText.toLocaleLowerCase("pt-BR").trim();
  const native = window.AbbyNative;

  if (/^(que horas são|que horas sao|hora|qual é a hora|qual e a hora)\??$/.test(t)) {
    return `Agora são ${new Date().toLocaleTimeString("pt-BR", {hour:"2-digit", minute:"2-digit"})}.`;
  }
  if (/^(que dia é hoje|que dia e hoje|qual a data|data)\??$/.test(t)) {
    return `Hoje é ${new Date().toLocaleDateString("pt-BR", {weekday:"long", day:"2-digit", month:"long", year:"numeric"})}.`;
  }
  if (t.includes("abrir youtube") || t.includes("abre youtube")) {
    if (native && native.openUrl) { native.openUrl("https://www.youtube.com/"); return "Abrindo o YouTube no navegador."; }
    window.open("https://www.youtube.com/", "_blank", "noopener");
    return "Abrindo o YouTube.";
  }
  if (t.startsWith("pesquisar ") || t.startsWith("pesquise ") || t.startsWith("buscar ")) {
    const query = commandText.replace(/^(pesquisar|pesquise|buscar)\s+/i, "").trim();
    if (!query) return "Diga o que você quer pesquisar.";
    const url = "https://www.google.com/search?q=" + encodeURIComponent(query);
    if (native && native.openUrl) native.openUrl(url); else window.open(url, "_blank", "noopener");
    return `Pesquisando na internet por: ${query}.`;
  }
  if (t.startsWith("abrir site ") || t.startsWith("acessar site ")) {
    let address = commandText.replace(/^(abrir site|acessar site)\s+/i, "").trim();
    if (!address) return "Informe o endereço do site.";
    if (!/^https?:\/\//i.test(address)) address = "https://" + address;
    try {
      const parsed = new URL(address);
      if (!parsed.hostname || !["http:", "https:"].includes(parsed.protocol)) return "Esse endereço não parece válido.";
      if (native && native.openUrl) native.openUrl(parsed.href); else window.open(parsed.href, "_blank", "noopener");
      return `Abrindo ${parsed.hostname}.`;
    } catch (_) { return "Não consegui reconhecer esse endereço. Confira e tente novamente."; }
  }
  return null;
}

async function getReply(text) {
  const localCommand = runLocalCommand(text);
  if (localCommand !== null) return localCommand;
  const endpoint = localStorage.getItem("abbyApiUrl");
  if (endpoint) {
    try {
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify({message:text, conversation: []})
      });
      if (!response.ok) throw new Error("Servidor respondeu com erro");
      const data = await response.json();
      return data.reply || data.response || data.message || "Recebi uma resposta vazia do servidor.";
    } catch (err) {
      return "Não consegui conectar ao servidor de IA. Confira o endereço e se o servidor permite requisições deste aplicativo. Por enquanto, posso continuar no modo demonstrativo.";
    }
  }
  return localReply(text);
}

function speak(text) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "pt-BR";
  utterance.rate = 1;
  window.speechSynthesis.speak(utterance);
}

async function sendMessage(textOverride) {
  const text = (textOverride ?? input.value).trim();
  if (!text) return;
  addMessage(text, "user");
  input.value = "";
  input.style.height = "auto";
  statusEl.textContent = "ABBY ESTÁ RESPONDENDO";
  $("sendBtn").disabled = true;
  const reply = await getReply(text);
  addMessage(reply, "assistant");
  statusEl.textContent = "SISTEMA PRONTO";
  $("sendBtn").disabled = false;
  speak(reply);
}

$("sendBtn").addEventListener("click", () => sendMessage());
input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); sendMessage(); }
});
input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight,110) + "px"; });

function setupRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    $("hint").textContent = "Este navegador não oferece reconhecimento de voz. Experimente abrir o app no Chrome para Android e permitir o microfone.";
    voiceBtn.addEventListener("click", () => addMessage("O reconhecimento de voz não está disponível neste navegador. Você ainda pode digitar mensagens.", "assistant"), {once:true});
    return;
  }
  recognition = new SpeechRecognition();
  recognition.lang = "pt-BR";
  recognition.interimResults = false;
  recognition.continuous = false;
  recognition.onstart = () => {
    isListening = true;
    voiceBtn.classList.add("active");
    voiceLabel.textContent = "ESTOU OUVINDO...";
    orb.classList.add("listening");
    statusEl.textContent = "OUVINDO SUA VOZ";
  };
  recognition.onend = () => {
    isListening = false;
    voiceBtn.classList.remove("active");
    voiceLabel.textContent = "CONVERSAR POR VOZ";
    orb.classList.remove("listening");
    statusEl.textContent = "SISTEMA PRONTO";
  };
  recognition.onerror = (event) => {
    $("hint").textContent = event.error === "not-allowed" ? "Permita o uso do microfone nas configurações do navegador." : "Não consegui ouvir dessa vez. Tente novamente ou digite sua mensagem.";
  };
  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    sendMessage(transcript);
  };
}
voiceBtn.addEventListener("click", () => {
  if (!recognition) {
    addMessage("O reconhecimento de voz não está disponível aqui. Tente usar o Chrome no Android e confira a permissão do microfone.", "assistant");
    return;
  }
  if (isListening) recognition.stop();
  else { try { recognition.start(); } catch (_) {} }
});
$("clearBtn").addEventListener("click", () => {
  messages.replaceChildren();
  addMessage(`Conversa limpa! Oi, sou a ${getName()}. Como posso ajudar?`, "assistant");
});
$("settingsBtn").addEventListener("click", () => {
  $("assistantName").value = getName();
  $("apiUrl").value = localStorage.getItem("abbyApiUrl") || "";
  $("modelName").value = localStorage.getItem("abbyModel") || "OpenAI";
  dialog.showModal();
});
$("saveSettings").addEventListener("click", (event) => {
  event.preventDefault();
  const name = $("assistantName").value.trim() || "Abby";
  const endpoint = $("apiUrl").value.trim();
  localStorage.setItem("abbyModel", $("modelName").value);
  localStorage.setItem("abbyName", name);
  if (endpoint) localStorage.setItem("abbyApiUrl", endpoint);
  else localStorage.removeItem("abbyApiUrl");
  dialog.close();
  addMessage(`Configurações salvas. Pode me chamar de ${name}.`, "assistant");
});
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
setupRecognition();

// Atalhos do painel inicial.
document.querySelectorAll("[data-command]").forEach(button => {
  button.addEventListener("click", () => {
    const command = button.getAttribute("data-command");
    if (command === "configuracoes") { $("settingsBtn").click(); return; }
    if (command === "voz") { $("voiceBtn").click(); return; }
    if (command === "conversar") { input.focus(); document.querySelector(".chat").scrollIntoView({behavior:"smooth"}); return; }
    sendMessage(command);
    document.querySelector(".chat").scrollIntoView({behavior:"smooth"});
  });
});

if ("serviceWorker" in navigator && (location.protocol==="https:" || location.hostname==="localhost")) { window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{})); }
