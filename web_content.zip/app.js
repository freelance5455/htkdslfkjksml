// FirasX Rent — single-page frontend. All data comes from /api (Netlify Server + Netlify Database).

const $ = (s, el = document) => el.querySelector(s)
const $$ = (s, el = document) => [...el.querySelectorAll(s)]
const app = $('#app')

const esc = (v) =>
  String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c])
const rupiah = (n) => 'Rp' + Number(n || 0).toLocaleString('id-ID')
const fmtDate = (d, withTime = false) => {
  if (!d) return '—'
  const dt = new Date(d)
  if (isNaN(dt)) return '—'
  return dt.toLocaleString('id-ID', withTime ? { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' } : { day: 'numeric', month: 'short', year: 'numeric' })
}
const todayISO = () => {
  const d = new Date()
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10)
}
const ago = (d) => {
  const s = Math.max(0, Math.floor((Date.now() - new Date(d).getTime()) / 1000))
  if (s < 60) return `${s} detik lalu`
  if (s < 3600) return `${Math.floor(s / 60)} menit lalu`
  if (s < 86400) return `${Math.floor(s / 3600)} jam lalu`
  return `${Math.floor(s / 86400)} hari lalu`
}
const left = (d) => {
  let s = Math.max(0, Math.floor((new Date(d).getTime() - Date.now()) / 1000))
  const h = Math.floor(s / 3600)
  s -= h * 3600
  const m = Math.floor(s / 60)
  s -= m * 60
  const p = (x) => String(x).padStart(2, '0')
  return h >= 24 ? `${Math.floor(h / 24)}h ${p(h % 24)}:${p(m)}:${p(s)}` : `${p(h)}:${p(m)}:${p(s)}`
}

// ------------------------------------------------------------------ state

const state = {
  me: null,
  pub: { settings: { storeName: 'FirasX Rent', pricePerDay: 4000, maxDays: 7 }, payments: [] },
  stock: null,
  stockFilter: 'all',
  devTab: 'orders',
  dev: null,
  orderFilter: 'pending',
}
let timers = []
const every = (fn, ms) => timers.push(setInterval(() => { if (!document.hidden) fn() }, ms))
const clearTimers = () => { timers.forEach(clearInterval); timers = [] }

// ------------------------------------------------------------------ api

async function api(path, opts = {}) {
  const init = { method: opts.method || 'GET', credentials: 'same-origin', headers: { Accept: 'application/json' }, cache: 'no-store' }
  if (opts.body !== undefined) {
    init.headers['Content-Type'] = 'application/json'
    init.body = JSON.stringify(opts.body)
  }
  let res
  try {
    res = await fetch(path, init)
  } catch {
    throw new Error('Tidak ada koneksi internet / server tidak terjangkau.')
  }
  let data = {}
  try { data = await res.json() } catch {}
  if (!res.ok) {
    const err = new Error(data.error || `Gagal (${res.status})`)
    err.status = res.status
    throw err
  }
  return data
}

// ------------------------------------------------------------------ ui helpers

function toast(msg, type = '') {
  const el = document.createElement('div')
  el.className = `toast ${type}`
  el.textContent = msg
  $('#toasts').appendChild(el)
  setTimeout(() => el.remove(), 4200)
}

function modal(html, { wide = false, onClose } = {}) {
  const root = $('#modalRoot')
  root.innerHTML = `<div class="modal-bg"><div class="card modal ${wide ? 'wide' : ''}">${html}</div></div>`
  const bg = $('.modal-bg', root)
  const close = () => { root.innerHTML = ''; onClose?.() }
  bg.addEventListener('mousedown', (e) => { if (e.target === bg) close() })
  $$('[data-close]', root).forEach((b) => b.addEventListener('click', close))
  return { el: $('.modal', root), close }
}
const modalOpen = () => !!$('#modalRoot').children.length

async function busy(btn, fn) {
  const label = btn.innerHTML
  btn.disabled = true
  btn.innerHTML = `<span class="spinner"></span> ${label}`
  try { return await fn() } finally { btn.disabled = false; btn.innerHTML = label }
}

async function copy(text) {
  try {
    await navigator.clipboard.writeText(text)
  } catch {
    const t = document.createElement('textarea')
    t.value = text
    document.body.appendChild(t)
    t.select()
    document.execCommand('copy')
    t.remove()
  }
  toast('Disalin ✓', 'ok')
}
document.addEventListener('click', (e) => {
  const c = e.target.closest('[data-copy]')
  if (c) copy(c.dataset.copy)
})

function readImage(file, maxSide = 1200, quality = 0.85) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve(null)
    if (!file.type.startsWith('image/')) return reject(new Error('File harus berupa gambar.'))
    const fr = new FileReader()
    fr.onerror = () => reject(new Error('Gagal membaca gambar.'))
    fr.onload = () => {
      const img = new Image()
      img.onerror = () => reject(new Error('Gambar tidak valid.'))
      img.onload = () => {
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height))
        const cv = document.createElement('canvas')
        cv.width = Math.round(img.width * scale)
        cv.height = Math.round(img.height * scale)
        const ctx = cv.getContext('2d')
        ctx.fillStyle = '#fff'
        ctx.fillRect(0, 0, cv.width, cv.height)
        ctx.drawImage(img, 0, 0, cv.width, cv.height)
        resolve(cv.toDataURL('image/jpeg', quality))
      }
      img.src = fr.result
    }
    fr.readAsDataURL(file)
  })
}

const roleChip = (u) =>
  !u ? '<span class="role-chip role-guest">Pengunjung</span>'
  : u.role === 'dev' ? '<span class="role-chip role-dev">Developer</span>'
  : u.role === 'co' ? '<span class="role-chip role-co">Co Developer</span>'
  : '<span class="role-chip role-user">Member</span>'

// local order memory (works for visitors without login)
const myLocalOrders = () => { try { return JSON.parse(localStorage.getItem('fx_orders') || '[]') } catch { return [] } }
const rememberOrder = (code, token) => {
  const list = myLocalOrders().filter((o) => o.code !== code)
  list.unshift({ code, token, at: Date.now() })
  localStorage.setItem('fx_orders', JSON.stringify(list.slice(0, 30)))
}

// ------------------------------------------------------------------ header + auth

function renderNav() {
  const u = state.me
  const r = location.hash.replace(/^#/, '') || '/'
  const link = (href, label) => `<a class="link ${r === href || (href !== '/' && r.startsWith(href)) ? 'active' : ''}" href="#${href}">${label}</a>`
  $('#nav').innerHTML = `
    ${link('/', 'Beranda')}
    ${link('/stok', 'Daftar Stok')}
    ${link('/sewa', 'Sewa Akun')}
    ${link('/pesananku', 'Pesananku')}
    ${u?.role === 'dev' ? link('/dev', '⚙ Panel Developer') : ''}
    <div class="row" style="margin-left:8px">
      ${roleChip(u)}
      ${u ? `<span class="small muted">${esc(u.username)}</span><button class="btn sm" id="logoutBtn">Keluar</button>`
          : `<button class="btn sm gold" id="loginBtn">Masuk / Daftar</button>`}
    </div>`
  $('#loginBtn')?.addEventListener('click', () => openAuth('login'))
  $('#logoutBtn')?.addEventListener('click', async () => {
    await api('/api/auth/logout', { method: 'POST' }).catch(() => {})
    state.me = null
    state.dev = null
    toast('Kamu sudah keluar.')
    location.hash = '#/'
    route()
  })
  const name = state.pub.settings.storeName || 'FirasX Rent'
  $('#brandName').textContent = name
  $('#footName').textContent = name
}
$('#menuBtn').addEventListener('click', () => $('#nav').classList.toggle('open'))

function openAuth(tab = 'login') {
  const m = modal(`
    <div class="row between"><h3>Selamat datang 👋</h3><button class="btn sm ghost" data-close>✕</button></div>
    <p class="muted small">Masuk untuk menyimpan riwayat sewa, atau lanjut sebagai pengunjung — pengunjung tetap bisa menyewa akun.</p>
    <div class="tabs" style="margin:14px 0">
      <button class="tab ${tab === 'login' ? 'on' : ''}" data-t="login">Masuk</button>
      <button class="tab ${tab === 'register' ? 'on' : ''}" data-t="register">Daftar</button>
    </div>
    <form id="authForm" autocomplete="on">
      <div class="field"><label class="f">Username</label><input class="input" name="username" required autocomplete="username" /></div>
      <div class="field"><label class="f">Password</label><input class="input" name="password" type="password" required autocomplete="current-password" /></div>
      <div class="field reg ${tab === 'register' ? '' : 'hidden'}"><label class="f">No. WhatsApp (opsional)</label><input class="input" name="whatsapp" inputmode="tel" placeholder="08xxxxxxxxxx" /></div>
      <div id="authErr" class="notice n-err hidden" style="margin-top:12px"></div>
      <button class="btn gold block lg" style="margin-top:16px" id="authSubmit">${tab === 'login' ? 'Masuk' : 'Buat Akun'}</button>
    </form>
    <button class="btn block ghost" style="margin-top:10px" id="guestBtn">Lanjut sebagai Pengunjung →</button>
  `)
  let mode = tab
  $$('.tab', m.el).forEach((b) =>
    b.addEventListener('click', () => {
      mode = b.dataset.t
      $$('.tab', m.el).forEach((x) => x.classList.toggle('on', x === b))
      $('.reg', m.el).classList.toggle('hidden', mode !== 'register')
      $('#authSubmit').textContent = mode === 'login' ? 'Masuk' : 'Buat Akun'
      $('[name=password]', m.el).autocomplete = mode === 'login' ? 'current-password' : 'new-password'
    }),
  )
  $('#guestBtn').addEventListener('click', () => {
    localStorage.setItem('fx_mode', 'guest')
    m.close()
  })
  $('#authForm').addEventListener('submit', async (e) => {
    e.preventDefault()
    const f = new FormData(e.target)
    const btn = $('#authSubmit')
    const errEl = $('#authErr')
    errEl.classList.add('hidden')
    await busy(btn, async () => {
      try {
        const r = await api(`/api/auth/${mode}`, { method: 'POST', body: Object.fromEntries(f) })
        state.me = r.user
        localStorage.setItem('fx_mode', 'member')
        m.close()
        toast(`Halo ${r.user.username}!`, 'ok')
        if (r.user.role === 'dev') location.hash = '#/dev'
        route()
      } catch (err) {
        errEl.textContent = err.message
        errEl.classList.remove('hidden')
      }
    })
  })
}

// ------------------------------------------------------------------ stock rendering

const stateBadge = (a) => `<span class="badge b-${a.state}">${esc(a.stateLabel)}</span>`

function accCard(a, { showRent = true } = {}) {
  const pct = a.state === 'preparing' && a.readyDays ? Math.max(4, Math.min(100, Math.round(((a.readyDays - a.daysLeft) / a.readyDays) * 100))) : 0
  return `
  <div class="acc s-${a.state}">
    <div class="row between"><div class="name">${esc(a.label)}</div>${stateBadge(a)}</div>
    <div class="email">${esc(a.email)}</div>
    ${a.state === 'preparing' && a.daysLeft ? `<div><div class="progress"><i style="width:${pct}%"></i></div><div class="hint">Siap pada ${fmtDate(a.readyAt)}</div></div>` : ''}
    <dl class="kv">
      <dt>Match terakhir</dt><dd>${a.lastMatchAt ? fmtDate(a.lastMatchAt) : '—'}</dd>
      <dt>Masuk stok</dt><dd>${fmtDate(a.addedAt)}</dd>
      ${a.state === 'rented' && a.rentedUntil ? `<dt>Kosong lagi</dt><dd>${fmtDate(a.rentedUntil, true)}</dd>` : ''}
    </dl>
    ${a.note ? `<div class="small muted">${esc(a.note)}</div>` : ''}
    ${showRent ? (a.state === 'ready' ? `<a class="btn gold block" href="#/sewa?akun=${a.id}">Sewa akun ini</a>` : `<button class="btn block" disabled>${a.state === 'preparing' ? 'Belum siap' : 'Tidak tersedia'}</button>`) : ''}
  </div>`
}

async function loadStock() {
  state.stock = await api('/api/stock')
  return state.stock
}

function stockSection(limit) {
  const s = state.stock
  if (!s) return `<div class="empty"><span class="spinner"></span> Memuat stok…</div>`
  let list = s.accounts
  if (state.stockFilter !== 'all') list = list.filter((a) => (state.stockFilter === 'rented' ? a.state === 'rented' || a.state === 'reserved' : a.state === state.stockFilter))
  const order = { ready: 0, preparing: 1, reserved: 2, rented: 3 }
  list = [...list].sort((a, b) => (order[a.state] ?? 9) - (order[b.state] ?? 9) || a.id - b.id)
  const total = list.length
  if (limit) list = list.slice(0, limit)
  const chip = (k, label, n) => `<button class="chip ${state.stockFilter === k ? 'on' : ''}" data-filter="${k}">${label} · ${n}</button>`
  return `
    <div class="section-title">
      <div><h2>Daftar Stok Akun</h2><div class="live">Update otomatis · ${fmtDate(s.updatedAt, true)}</div></div>
      <div class="chips">
        ${chip('all', 'Semua', s.counts.total)}
        ${chip('ready', 'Siap dipakai', s.counts.ready || 0)}
        ${chip('preparing', 'Belum siap', s.counts.preparing || 0)}
        ${chip('rented', 'Disewa', (s.counts.rented || 0) + (s.counts.reserved || 0))}
      </div>
    </div>
    ${list.length ? `<div class="stock-grid">${list.map((a) => accCard(a)).join('')}</div>` : `<div class="empty">Belum ada akun di kategori ini.</div>`}
    ${limit && total > limit ? `<div style="text-align:center;margin-top:16px"><a class="btn" href="#/stok">Lihat semua ${total} akun →</a></div>` : ''}`
}

function bindStock(container, limit) {
  const rerender = () => {
    container.innerHTML = stockSection(limit)
    $$('[data-filter]', container).forEach((b) => b.addEventListener('click', () => { state.stockFilter = b.dataset.filter; rerender() }))
  }
  rerender()
  const refresh = async () => { try { await loadStock(); rerender(); updateStats() } catch {} }
  refresh()
  every(refresh, 8000)
  return rerender
}

function updateStats() {
  const s = state.stock
  const el = $('#heroStats')
  if (!s || !el) return
  el.innerHTML = `
    <div class="stat"><b style="color:var(--green)">${s.counts.ready || 0}</b><span>Siap dipakai</span></div>
    <div class="stat"><b style="color:var(--amber)">${s.counts.preparing || 0}</b><span>Belum siap</span></div>
    <div class="stat"><b style="color:#c6b5ff">${(s.counts.rented || 0) + (s.counts.reserved || 0)}</b><span>Sedang disewa</span></div>
    <div class="stat"><b>${s.counts.total || 0}</b><span>Total akun</span></div>`
}

// ------------------------------------------------------------------ pages

function pageHome() {
  const st = state.pub.settings
  app.innerHTML = `
  <section class="hero"><div class="wrap">
    <div>
      <div class="eyebrow">Rank vs Bot · Mobile Legends</div>
      <h1>Sewa akun ML siap <em>push rank vs bot</em>, tanpa ribet.</h1>
      <p class="lead">${esc(st.announcement || '')}</p>
      <div class="row" style="margin-top:22px">
        <a class="btn gold lg" href="#/sewa">Sewa Sekarang · ${rupiah(st.pricePerDay)}/hari</a>
        <a class="btn lg" href="#/stok">Cek stok</a>
      </div>
      <div class="stats" id="heroStats"></div>
    </div>
    <div class="price-card">
      <div class="eyebrow">Harga sewa</div>
      <div class="big" style="margin-top:10px">${rupiah(st.pricePerDay)} <small>/ akun / hari</small></div>
      <ul>
        <li>Akun khusus rank vs bot, siap main</li>
        <li>Kode OTP login muncul otomatis di halaman pesanan</li>
        <li>Bayar via ${state.pub.payments.map((p) => esc(p.name)).join(' / ') || 'DANA / QRIS'}</li>
        <li>Bisa sewa tanpa daftar akun</li>
      </ul>
      <a class="btn gold block" href="#/sewa">Pilih durasi →</a>
    </div>
  </div></section>

  <section class="block"><div class="wrap">
    <div class="section-title"><h2>Cara sewa</h2></div>
    <div class="grid g4 steps">
      <div class="card step"><h3>Pilih akun</h3><p class="muted small">Pilih akun berstatus <b>Siap dipakai</b> atau biarkan sistem memilihkan.</p></div>
      <div class="card step"><h3>Bayar</h3><p class="muted small">Transfer via DANA atau scan QRIS, lalu unggah bukti di halaman pesanan.</p></div>
      <div class="card step"><h3>Login di game</h3><p class="muted small">Email & password akun tampil setelah pembayaran dikonfirmasi.</p></div>
      <div class="card step"><h3>OTP otomatis</h3><p class="muted small">Minta kode di game — kode verifikasi Moonton langsung tampil di halaman pesanan.</p></div>
    </div>
  </div></section>

  <section class="block"><div class="wrap" id="stockBox"></div></section>`
  bindStock($('#stockBox'), 8)
  updateStats()
}

function pageStock() {
  app.innerHTML = `<section class="block"><div class="wrap">
    <p class="muted small" style="margin:0 0 14px">Semua akun ditampilkan transparan: status siap/belum siap, tanggal match terakhir, dan email yang disensor. Data berubah langsung saat Developer memperbarui stok.</p>
    <div id="stockBox"></div></div></section>`
  bindStock($('#stockBox'))
}

async function pageRent(params) {
  const st = state.pub.settings
  const u = state.me
  const free = u && (u.role === 'co' || u.role === 'dev')
  const wanted = params.get('akun')
  app.innerHTML = `<section class="block"><div class="wrap"><div class="empty"><span class="spinner"></span> Memuat…</div></div></section>`
  try { await loadStock() } catch (e) { app.innerHTML = `<section class="block"><div class="wrap"><div class="notice n-err">${esc(e.message)}</div></div></section>`; return }
  const ready = state.stock.accounts.filter((a) => a.state === 'ready')
  let selected = wanted && ready.find((a) => String(a.id) === wanted) ? Number(wanted) : null
  let days = 1
  let pm = state.pub.payments[0]?.id || null

  const draw = () => {
    const total = free ? 0 : days * st.pricePerDay
    app.innerHTML = `
    <section class="block"><div class="wrap">
      <div class="section-title"><div><div class="eyebrow">Pembelian</div><h2 style="margin-top:6px">Sewa Akun · ${rupiah(st.pricePerDay)}/hari/akun</h2></div></div>
      ${free ? `<div class="notice n-co" style="margin-bottom:16px">💜 Mode <b>${u.role === 'dev' ? 'Developer' : 'Co Developer'}</b> — kamu bisa mengambil akun <b>gratis</b> tanpa pembayaran.</div>` : ''}
      ${wanted && !selected ? `<div class="notice n-warn" style="margin-bottom:16px">Akun yang kamu pilih sudah tidak tersedia. Silakan pilih akun lain.</div>` : ''}
      <div class="grid" style="grid-template-columns:minmax(0,1.4fr) minmax(0,1fr);align-items:start" id="rentGrid">
        <div class="stack">
          <div class="card">
            <h3 style="font-size:1.1rem">1. Pilih akun</h3>
            <p class="muted small">${ready.length} akun siap dipakai.</p>
            ${ready.length ? `
            <div class="stack" style="margin-top:10px">
              <label class="pay-opt ${selected === null ? 'on' : ''}"><input type="radio" name="acc" value="" ${selected === null ? 'checked' : ''} hidden />
                <div class="ic ic-other">AUTO</div><div><b>Pilihkan otomatis</b><div class="small muted">Sistem memberi akun siap pakai pertama.</div></div></label>
              ${ready.map((a) => `
              <label class="pay-opt ${selected === a.id ? 'on' : ''}"><input type="radio" name="acc" value="${a.id}" ${selected === a.id ? 'checked' : ''} hidden />
                <div class="ic ic-other">#${a.id}</div>
                <div style="min-width:0"><b>${esc(a.label)}</b><div class="small muted mono" style="word-break:break-all">${esc(a.email)}</div>
                <div class="small muted">Match terakhir: ${a.lastMatchAt ? fmtDate(a.lastMatchAt) : '—'}</div></div></label>`).join('')}
            </div>` : `<div class="empty">Stok siap pakai sedang habis. Cek lagi nanti — halaman stok update otomatis.</div>`}
          </div>
          <div class="card">
            <h3 style="font-size:1.1rem">2. Durasi sewa</h3>
            <div class="row between" style="margin-top:10px">
              <div class="stepper"><button type="button" id="dMinus">−</button><span>${days} hari</span><button type="button" id="dPlus">+</button></div>
              <div class="small muted">Maks ${st.maxDays} hari</div>
            </div>
          </div>
          ${free ? '' : `
          <div class="card">
            <h3 style="font-size:1.1rem">3. Metode pembayaran</h3>
            ${state.pub.payments.length ? `<div class="stack" style="margin-top:10px">${state.pub.payments.map((p) => `
              <label class="pay-opt ${pm === p.id ? 'on' : ''}"><input type="radio" name="pm" value="${p.id}" ${pm === p.id ? 'checked' : ''} hidden />
                <div class="ic ic-${p.type}">${p.type === 'qris' ? 'QRIS' : p.type === 'dana' ? 'DANA' : 'BANK'}</div>
                <div><b>${esc(p.name)}</b><div class="small muted">${p.type === 'qris' ? 'Scan QR dari e-wallet/m-banking apa pun' : `${esc(p.accountNumber || '')}${p.holder ? ' a.n. ' + esc(p.holder) : ''}`}</div></div></label>`).join('')}</div>`
            : `<div class="notice n-warn" style="margin-top:10px">Metode pembayaran belum diatur oleh Developer. Hubungi admin.</div>`}
          </div>`}
        </div>
        <div class="card" style="position:sticky;top:84px">
          <h3 style="font-size:1.1rem">Ringkasan</h3>
          <form id="rentForm" style="margin-top:12px">
            <div class="field"><label class="f">Nama</label><input class="input" name="buyerName" required maxlength="60" value="${esc(u?.username || '')}" /></div>
            ${free ? '' : `<div class="field"><label class="f">No. WhatsApp</label><input class="input" name="buyerContact" required inputmode="tel" maxlength="30" placeholder="08xxxxxxxxxx" value="${esc(u?.whatsapp || '')}" /><div class="hint">Untuk konfirmasi bila ada kendala.</div></div>`}
            <dl class="kv" style="margin:16px 0">
              <dt>Harga</dt><dd>${rupiah(st.pricePerDay)} × ${days} hari</dd>
              ${free ? `<dt>Potongan Co Dev</dt><dd style="color:var(--green)">−${rupiah(days * st.pricePerDay)}</dd>` : ''}
              <dt style="font-weight:800;color:var(--text)">Total</dt><dd class="display" style="font-size:1.4rem;color:var(--gold2)">${rupiah(total)}</dd>
            </dl>
            <div id="rentErr" class="notice n-err hidden" style="margin-bottom:12px"></div>
            <button class="btn gold block lg" id="rentBtn" ${!ready.length || (!free && !state.pub.payments.length) ? 'disabled' : ''}>${free ? 'Ambil Akun Gratis' : 'Buat Pesanan'}</button>
            ${!u ? `<p class="hint" style="text-align:center">Kamu memesan sebagai pengunjung. Link pesanan tersimpan di perangkat ini.</p>` : ''}
          </form>
        </div>
      </div>
    </div></section>`
    if (window.innerWidth < 860) $('#rentGrid').style.gridTemplateColumns = '1fr'
    $$('input[name=acc]').forEach((r) => r.addEventListener('change', () => { selected = r.value ? Number(r.value) : null; keep(draw) }))
    $$('input[name=pm]').forEach((r) => r.addEventListener('change', () => { pm = Number(r.value); keep(draw) }))
    $('#dMinus').addEventListener('click', () => { days = Math.max(1, days - 1); keep(draw) })
    $('#dPlus').addEventListener('click', () => { days = Math.min(st.maxDays, days + 1); keep(draw) })
    $('#rentForm').addEventListener('submit', async (e) => {
      e.preventDefault()
      const f = Object.fromEntries(new FormData(e.target))
      const errEl = $('#rentErr')
      errEl.classList.add('hidden')
      await busy($('#rentBtn'), async () => {
        try {
          const r = await api('/api/orders', { method: 'POST', body: { ...f, days, accountId: selected, paymentMethodId: pm } })
          rememberOrder(r.code, r.token)
          location.hash = `#/pesanan/${r.code}/${r.token}`
        } catch (err) {
          errEl.textContent = err.message
          errEl.classList.remove('hidden')
        }
      })
    })
  }
  // keep typed values across re-render
  const keep = (fn) => {
    const vals = {}
    $$('#rentForm input').forEach((i) => (vals[i.name] = i.value))
    fn()
    $$('#rentForm input').forEach((i) => { if (vals[i.name] != null) i.value = vals[i.name] })
  }
  draw()
}

async function pageOrder(code, tok) {
  if (!tok) tok = myLocalOrders().find((o) => o.code === code)?.token || ''
  const q = tok ? `?t=${encodeURIComponent(tok)}` : ''
  app.innerHTML = `<section class="block"><div class="wrap" style="max-width:760px" id="orderBox"><div class="empty"><span class="spinner"></span> Memuat pesanan…</div></div></section>`
  const box = $('#orderBox')
  let order = null
  let otpState = { loading: false, data: null, lastCheck: null }
  let lastStatus = null

  const load = async () => {
    try {
      const r = await api(`/api/orders/${encodeURIComponent(code)}${q}`)
      order = r.order
      if (tok) rememberOrder(code, tok)
      if (order.status !== lastStatus) {
        if (lastStatus === 'pending' && order.status === 'active') toast('Pembayaran dikonfirmasi! Akun siap dipakai 🎉', 'ok')
        lastStatus = order.status
        draw()
        if (order.status === 'active' && !otpState.data) checkOtp()
      } else tick()
    } catch (e) {
      box.innerHTML = `<div class="notice n-err">${esc(e.message)}</div><p class="muted small">Pastikan kamu membuka link pesanan yang benar (link berisi kode akses). Pesanan dari perangkat ini tersimpan di <a href="#/pesananku">Pesananku</a>.</p>`
      clearTimers()
    }
  }

  const checkOtp = async (manual) => {
    if (!order || order.status !== 'active' || otpState.loading) return
    otpState.loading = true
    drawOtp()
    try {
      otpState.data = await api(`/api/orders/${encodeURIComponent(code)}/otp${q}`)
    } catch (e) {
      otpState.data = { ok: false, message: e.message }
    }
    otpState.loading = false
    otpState.lastCheck = Date.now()
    drawOtp()
    if (manual && otpState.data?.otp && !otpState.data.otp.expired) toast('Kode OTP ditemukan ✓', 'ok')
  }

  const drawOtp = () => {
    const el = $('#otpPanel')
    if (!el) return
    const d = otpState.data
    let body
    if (d?.otp) {
      const o = d.otp
      const expired = Date.now() - new Date(o.receivedAt).getTime() >= 10 * 60000
      body = `<div class="otp-box ${expired ? 'old' : ''}">
        <div class="small muted">${expired ? 'Kode terakhir (sudah kedaluwarsa — minta kode baru di game)' : 'Kode verifikasi Moonton'}</div>
        <div class="otp-code">${esc(o.code)}</div>
        <div class="small muted">Diterima ${ago(o.receivedAt)} · berlaku 10 menit</div>
        ${expired ? '' : `<button class="btn gold" style="margin-top:12px" data-copy="${esc(o.code)}">Salin kode</button>`}
      </div>`
    } else if (d && !d.ok) {
      body = `<div class="notice n-err">${esc(d.message)}</div>`
    } else if (d) {
      body = `<div class="otp-box old"><div class="otp-code" style="text-decoration:none;letter-spacing:.1em">— — —</div><div class="small muted">${esc(d.message)}</div></div>`
    } else body = `<div class="empty"><span class="spinner"></span> Mengecek OTP…</div>`
    el.innerHTML = `${body}
      <div class="row between" style="margin-top:12px">
        <span class="live">${otpState.loading ? 'Mengecek…' : `Cek otomatis tiap 10 detik${otpState.lastCheck ? ' · terakhir ' + ago(otpState.lastCheck) : ''}`}</span>
        <button class="btn sm" id="otpBtn" ${otpState.loading ? 'disabled' : ''}>Cek sekarang</button>
      </div>`
    $('#otpBtn')?.addEventListener('click', () => checkOtp(true))
  }

  const tick = () => {
    $$('[data-left]').forEach((el) => (el.textContent = left(el.dataset.left)))
  }

  const draw = () => {
    const o = order
    const st = state.pub.settings
    const badge = { pending: ['b-pending', 'Menunggu pembayaran'], active: ['b-active', 'Aktif'], expired: ['b-expired', 'Selesai'], cancelled: ['b-cancelled', 'Dibatalkan'] }[o.status] || ['b-pending', o.status]
    const link = `${location.origin}/#/pesanan/${o.code}/${tok}`
    let main = ''
    if (o.status === 'pending') {
      const p = o.payment
      const wa = st.whatsapp ? `https://wa.me/${st.whatsapp.replace(/^0/, '62').replace(/^\+/, '')}?text=${encodeURIComponent(`Halo admin, saya sudah bayar sewa akun.\nKode pesanan: ${o.code}\nTotal: ${rupiah(o.amount)}`)}` : null
      main = `
      <div class="card stack">
        <div class="row between"><h3 style="font-size:1.1rem">Bayar ${rupiah(o.amount)}</h3><div class="small muted">Sisa waktu <span class="countdown" style="font-size:1rem" data-left="${o.reservedUntil}">${left(o.reservedUntil)}</span></div></div>
        ${p ? (p.type === 'qris'
          ? `<div style="text-align:center"><img class="qris-img" alt="QRIS ${esc(p.name)}" src="/api/payments/${p.id}/qris" /><div class="small muted" style="margin-top:8px">Scan QRIS ${esc(p.name)} dan bayar tepat ${rupiah(o.amount)}</div></div>`
          : `<div class="cred"><div><div class="small muted">${esc(p.name)}${p.holder ? ' · a.n. ' + esc(p.holder) : ''}</div><div class="v" style="font-size:1.2rem">${esc(p.accountNumber || '')}</div></div><button class="btn sm" data-copy="${esc(p.accountNumber || '')}">Salin</button></div>
             <div class="cred"><div><div class="small muted">Nominal</div><div class="v" style="font-size:1.2rem">${o.amount}</div></div><button class="btn sm" data-copy="${o.amount}">Salin</button></div>`)
          : '<div class="notice n-warn">Metode pembayaran tidak ditemukan. Hubungi admin.</div>'}
        ${o.hasProof
          ? `<div class="notice n-ok">✓ Bukti pembayaran terkirim. Menunggu konfirmasi Developer — halaman ini akan berubah otomatis begitu dikonfirmasi.</div>`
          : `<div class="field"><label class="f">Unggah bukti transfer</label><input class="input" type="file" accept="image/*" id="proofFile" /></div>
             <button class="btn gold block" id="proofBtn">Kirim bukti pembayaran</button>`}
        ${wa ? `<a class="btn block" target="_blank" rel="noopener" href="${wa}">Konfirmasi via WhatsApp</a>` : ''}
        <button class="btn danger sm" id="cancelBtn" style="align-self:flex-start">Batalkan pesanan</button>
      </div>`
    } else if (o.status === 'active') {
      main = `
      <div class="card stack">
        <div class="row between"><h3 style="font-size:1.1rem">Data login akun</h3><div style="text-align:right"><div class="small muted">Sisa waktu sewa</div><div class="countdown" data-left="${o.expiresAt}">${left(o.expiresAt)}</div></div></div>
        <div class="cred"><div><div class="small muted">Email</div><div class="v">${esc(o.credentials?.email || '')}</div></div><button class="btn sm" data-copy="${esc(o.credentials?.email || '')}">Salin</button></div>
        ${o.credentials?.password ? `<div class="cred"><div><div class="small muted">Password</div><div class="v">${esc(o.credentials.password)}</div></div><button class="btn sm" data-copy="${esc(o.credentials.password)}">Salin</button></div>` : ''}
        <div class="small muted">Match terakhir akun: <b>${o.lastMatchAt ? fmtDate(o.lastMatchAt) : '—'}</b> · Berakhir ${fmtDate(o.expiresAt, true)}</div>
      </div>
      <div class="card">
        <h3 style="font-size:1.1rem;margin-bottom:6px">Kode OTP otomatis</h3>
        <ol class="small muted" style="margin:0 0 14px;padding-left:18px">
          <li>Di Mobile Legends pilih login dengan akun Moonton / Email.</li>
          <li>Masukkan email di atas lalu pilih <b>kirim kode verifikasi</b>.</li>
          <li>Kode muncul di bawah ini dalam beberapa detik — tidak perlu menunggu admin.</li>
        </ol>
        <div id="otpPanel"></div>
      </div>
      <div class="notice n-warn small">Dilarang mengganti email, password, atau bind akun. Akun otomatis kembali ke stok saat masa sewa habis.</div>`
    } else {
      main = `<div class="card"><p style="margin:0">${o.status === 'expired' ? 'Masa sewa sudah berakhir. Terima kasih sudah menyewa!' : `Pesanan dibatalkan${o.note ? ' — ' + esc(o.note) : ''}.`}</p><a class="btn gold" style="margin-top:14px" href="#/sewa">Sewa lagi</a></div>`
    }
    box.innerHTML = `
      <div class="section-title"><div><div class="eyebrow">Pesanan</div><h2 style="margin-top:6px" class="mono">${esc(o.code)}</h2></div><span class="badge ${badge[0]}">${badge[1]}</span></div>
      <div class="card" style="margin-bottom:16px">
        <dl class="kv">
          <dt>Akun</dt><dd>${esc(o.accountLabel || '—')} · <span class="mono">${esc(o.accountEmailMasked || '')}</span></dd>
          <dt>Durasi</dt><dd>${o.days} hari</dd>
          <dt>Total</dt><dd>${o.amount ? rupiah(o.amount) : 'Gratis'}</dd>
          <dt>Pemesan</dt><dd>${esc(o.buyerName)}</dd>
          <dt>Dibuat</dt><dd>${fmtDate(o.createdAt, true)}</dd>
        </dl>
        <div class="row" style="margin-top:12px"><button class="btn sm" data-copy="${esc(link)}">Salin link pesanan</button><span class="hint">Simpan link ini untuk membuka pesanan dari perangkat lain.</span></div>
      </div>
      <div class="stack">${main}</div>`
    $('#proofBtn')?.addEventListener('click', async (e) => {
      const file = $('#proofFile').files[0]
      if (!file) return toast('Pilih foto bukti transfer dulu.', 'err')
      await busy(e.currentTarget, async () => {
        try {
          const image = await readImage(file, 1400, 0.8)
          await api(`/api/orders/${encodeURIComponent(code)}/proof${q}`, { method: 'POST', body: { image } })
          toast('Bukti terkirim ✓', 'ok')
          lastStatus = null
          await load()
        } catch (err) { toast(err.message, 'err') }
      })
    })
    $('#cancelBtn')?.addEventListener('click', async () => {
      if (!confirm('Batalkan pesanan ini?')) return
      try { await api(`/api/orders/${encodeURIComponent(code)}/cancel${q}`, { method: 'POST' }); lastStatus = null; await load() } catch (err) { toast(err.message, 'err') }
    })
    drawOtp()
  }

  await load()
  every(tick, 1000)
  every(() => { if (order && ['pending', 'active'].includes(order.status)) load() }, 5000)
  every(() => checkOtp(), 10000)
}

async function pageMyOrders() {
  app.innerHTML = `<section class="block"><div class="wrap" style="max-width:820px" id="mo"><div class="empty"><span class="spinner"></span> Memuat…</div></div></section>`
  const box = $('#mo')
  let rows = []
  if (state.me) {
    try { rows = (await api('/api/my-orders')).orders } catch {}
  }
  const local = myLocalOrders()
  const known = new Set(rows.map((r) => r.code))
  const extra = local.filter((l) => !known.has(l.code))
  const badge = (s) => ({ pending: 'Menunggu bayar', active: 'Aktif', expired: 'Selesai', cancelled: 'Dibatalkan' })[s] || s
  box.innerHTML = `
    <div class="section-title"><h2>Pesananku</h2><a class="btn gold" href="#/sewa">+ Sewa akun</a></div>
    ${!state.me ? `<div class="notice n-info" style="margin-bottom:14px">Kamu dalam mode pengunjung — daftar ini diambil dari perangkat ini. <a href="#" id="loginLink">Masuk</a> agar riwayat tersimpan di akun.</div>` : ''}
    ${rows.length || extra.length ? `<div class="stack">
      ${rows.map((o) => `<a class="card row between" style="text-decoration:none;color:inherit;padding:16px" href="#/pesanan/${o.code}/${o.token}">
        <div><b class="mono">${esc(o.code)}</b><div class="small muted">${esc(o.accountLabel || '')} · ${o.days} hari · ${fmtDate(o.createdAt, true)}</div></div>
        <span class="badge b-${o.status}">${badge(o.status)}</span></a>`).join('')}
      ${extra.map((o) => `<a class="card row between" style="text-decoration:none;color:inherit;padding:16px" href="#/pesanan/${o.code}/${o.token}">
        <div><b class="mono">${esc(o.code)}</b><div class="small muted">Dibuat ${fmtDate(o.at, true)}</div></div><span class="small muted">Buka →</span></a>`).join('')}
    </div>` : `<div class="empty">Belum ada pesanan.</div>`}`
  $('#loginLink')?.addEventListener('click', (e) => { e.preventDefault(); openAuth('login') })
}

// ------------------------------------------------------------------ developer panel

const PARENT_STATUS = {
  empty: ['b-empty', 'Belum diisi'],
  unchecked: ['b-checking', 'Sedang dicek'],
  checking: ['b-checking', 'Sedang dicek'],
  ok: ['b-ok', 'Terhubung ✓'],
  app_password_required: ['b-error', 'Bukan App Password'],
  auth_failed: ['b-error', 'App Password salah'],
  imap_disabled: ['b-error', 'IMAP belum aktif'],
  web_login_required: ['b-error', 'Diblokir Google'],
  too_many_connections: ['b-error', 'Terlalu banyak koneksi'],
  network: ['b-error', 'Koneksi gagal'],
  not_gmail: ['b-error', 'Bukan Gmail'],
  unknown: ['b-error', 'Gagal'],
}
const parentBadge = (s) => {
  const [c, l] = PARENT_STATUS[s] || ['b-error', s || 'Gagal']
  return `<span class="badge ${c}">${l}</span>`
}

async function loadDev() {
  state.dev = await api('/api/dev/overview')
  return state.dev
}

async function pageDev() {
  if (state.me?.role !== 'dev') {
    app.innerHTML = `<section class="block"><div class="wrap" style="max-width:520px"><div class="card"><h3>Khusus Developer</h3><p class="muted">Halaman ini hanya untuk akun Developer.</p><button class="btn gold" id="lg">Masuk</button></div></div></section>`
    $('#lg').addEventListener('click', () => openAuth('login'))
    return
  }
  app.innerHTML = `<section class="block"><div class="wrap" id="devBox"><div class="empty"><span class="spinner"></span> Memuat panel…</div></div></section>`
  try { await loadDev() } catch (e) { $('#devBox').innerHTML = `<div class="notice n-err">${esc(e.message)}</div>`; return }
  drawDev()
  every(async () => {
    if (modalOpen() || state.devTab === 'settings' || document.activeElement?.matches('input,select,textarea')) return
    try { await loadDev(); drawDev() } catch {}
  }, 15000)
}

async function devRefresh() {
  await loadDev()
  drawDev()
}

async function devCall(path, method = 'POST', body) {
  try {
    const r = await api(`/api/dev${path}`, { method, body })
    await devRefresh()
    return r
  } catch (e) {
    toast(e.message, 'err')
    throw e
  }
}

function drawDev() {
  const d = state.dev
  const pending = d.orders.filter((o) => o.status === 'pending')
  const badParents = d.parents.filter((p) => p.status !== 'ok').length
  const tabs = [
    ['orders', `Pesanan${pending.length ? `<span class="dot">${pending.length}</span>` : ''}`],
    ['stock', `Stok Akun (${d.stock.length})`],
    ['gmail', `Gmail Induk${badParents ? `<span class="dot">!</span>` : ''}`],
    ['payments', 'Pembayaran'],
    ['settings', 'Harga & Pengaturan'],
    ['guide', 'Panduan Domain'],
  ]
  const ready = d.stock.filter((a) => a.state === 'ready').length
  const active = d.orders.filter((o) => o.status === 'active').length
  const box = $('#devBox')
  box.innerHTML = `
    <div class="section-title">
      <div><div class="eyebrow">Mode Developer</div><h2 style="margin-top:6px">Panel ${esc(d.settings.storeName)}</h2></div>
      <span class="live">Perubahan langsung tampil ke semua pengunjung</span>
    </div>
    <div class="stats" style="margin:0 0 20px">
      <div class="stat"><b style="color:var(--green)">${ready}</b><span>Stok siap</span></div>
      <div class="stat"><b style="color:var(--amber)">${pending.length}</b><span>Menunggu konfirmasi</span></div>
      <div class="stat"><b style="color:#c6b5ff">${active}</b><span>Sewa aktif</span></div>
      <div class="stat"><b>${rupiah(d.settings.pricePerDay)}</b><span>Harga / hari</span></div>
    </div>
    <div class="tabs">${tabs.map(([k, l]) => `<button class="tab ${state.devTab === k ? 'on' : ''}" data-tab="${k}">${l}</button>`).join('')}</div>
    <div id="devTab"></div>`
  $$('[data-tab]', box).forEach((b) => b.addEventListener('click', () => { state.devTab = b.dataset.tab; drawDev() }))
  const t = $('#devTab')
  ;({ orders: devOrders, stock: devStock, gmail: devGmail, payments: devPayments, settings: devSettings, guide: devGuide })[state.devTab](t, d)
}

// --- orders tab
function devOrders(t, d) {
  const f = state.orderFilter
  const list = d.orders.filter((o) => (f === 'pending' ? o.status === 'pending' : f === 'active' ? o.status === 'active' : !['pending', 'active'].includes(o.status)))
  const chip = (k, l) => `<button class="chip ${f === k ? 'on' : ''}" data-of="${k}">${l}</button>`
  const statusName = { pending: 'Menunggu', active: 'Aktif', expired: 'Selesai', cancelled: 'Batal' }
  t.innerHTML = `
    <div class="row between" style="margin-bottom:12px"><div class="chips">${chip('pending', 'Menunggu konfirmasi')}${chip('active', 'Sewa aktif')}${chip('done', 'Selesai / batal')}</div>
    <span class="small muted">${d.userCount} member terdaftar · webhook pembayaran ${d.webhookEnabled ? '<b style="color:var(--green)">aktif</b>' : 'belum aktif'}</span></div>
    ${list.length ? `<div class="table-wrap"><table>
      <thead><tr><th>Kode</th><th>Pemesan</th><th>Akun</th><th>Durasi</th><th>Total</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>${list.map((o) => `<tr>
        <td><b class="mono">${esc(o.code)}</b><div class="small muted">${fmtDate(o.createdAt, true)}</div></td>
        <td>${esc(o.buyerName)}${o.buyerContact ? `<div class="small"><a target="_blank" rel="noopener" href="https://wa.me/${esc(o.buyerContact.replace(/[^0-9]/g, '').replace(/^0/, '62'))}">${esc(o.buyerContact)}</a></div>` : ''}</td>
        <td>${esc(o.accountLabel || '—')}<div class="small muted mono">${esc(o.mlEmail || '')}</div></td>
        <td>${o.days} hari${o.status === 'active' ? `<div class="small muted">s/d ${fmtDate(o.expiresAt, true)}</div>` : ''}</td>
        <td>${o.amount ? rupiah(o.amount) : '<span style="color:#c6b5ff">Gratis</span>'}<div class="small muted">${esc(o.paymentName || '')}</div></td>
        <td><span class="badge b-${o.status}">${statusName[o.status] || o.status}</span>${o.note ? `<div class="small muted">${esc(o.note)}</div>` : ''}</td>
        <td><div class="row">
          ${o.hasProof ? `<button class="btn sm" data-proof="${o.id}">Lihat bukti</button>` : o.status === 'pending' ? '<span class="small muted">Belum ada bukti</span>' : ''}
          ${o.status === 'pending' || (o.status === 'cancelled' && o.hasProof) ? `<button class="btn sm gold" data-confirm="${o.id}">Konfirmasi lunas</button>` : ''}
          ${o.status === 'pending' ? `<button class="btn sm danger" data-cancel="${o.id}">Batalkan</button>` : ''}
          ${o.status === 'active' ? `<button class="btn sm" data-extend="${o.id}">+1 hari</button><button class="btn sm danger" data-end="${o.id}">Akhiri</button>` : ''}
        </div></td></tr>`).join('')}</tbody></table></div>` : `<div class="empty">Tidak ada pesanan di sini.</div>`}`
  $$('[data-of]', t).forEach((b) => b.addEventListener('click', () => { state.orderFilter = b.dataset.of; drawDev() }))
  $$('[data-proof]', t).forEach((b) => b.addEventListener('click', () => modal(`<div class="row between"><h3>Bukti pembayaran</h3><button class="btn sm ghost" data-close>✕</button></div><img src="/api/dev/orders/${b.dataset.proof}/proof?ts=${Date.now()}" style="width:100%;border-radius:12px;margin-top:12px" alt="Bukti" />`)))
  $$('[data-confirm]', t).forEach((b) => b.addEventListener('click', () => busy(b, () => devCall(`/orders/${b.dataset.confirm}/confirm`).then(() => toast('Pesanan aktif — pembeli langsung melihat data akun.', 'ok')).catch(() => {}))))
  $$('[data-cancel]', t).forEach((b) => b.addEventListener('click', () => confirm('Batalkan pesanan ini?') && devCall(`/orders/${b.dataset.cancel}/cancel`).catch(() => {})))
  $$('[data-end]', t).forEach((b) => b.addEventListener('click', () => confirm('Akhiri sewa sekarang? Akun kembali ke stok.') && devCall(`/orders/${b.dataset.end}/end`).catch(() => {})))
  $$('[data-extend]', t).forEach((b) => b.addEventListener('click', () => devCall(`/orders/${b.dataset.extend}/extend`, 'POST', { days: 1 }).then(() => toast('Diperpanjang 1 hari', 'ok')).catch(() => {})))
}

// --- stock tab
function devStock(t, d) {
  t.innerHTML = `
    <div class="row between" style="margin-bottom:12px">
      <p class="muted small" style="margin:0;max-width:620px">Tambah, ubah, atau hapus akun di sini — daftar stok untuk pembeli ikut berubah otomatis dalam hitungan detik. Akun baru berstatus <b>Belum siap</b> selama jumlah hari siap (default 14 hari), lalu otomatis menjadi <b>Siap dipakai</b>.</p>
      <button class="btn gold" id="addAcc">+ Tambah Stok Akun</button>
    </div>
    ${d.stock.length ? `<div class="table-wrap"><table>
      <thead><tr><th>Akun</th><th>Email & Gmail induk</th><th>Status</th><th>Siap</th><th>Match terakhir</th><th>Aksi</th></tr></thead>
      <tbody>${d.stock.map((a) => `<tr>
        <td><b>${esc(a.label)}</b><div class="small muted">#${a.id}${a.mlPassword ? ' · pw: <span class="mono">' + esc(a.mlPassword) + '</span>' : ''}</div></td>
        <td><span class="mono">${esc(a.mlEmail)}</span><div class="small">${a.parentEmail ? `<span class="muted">Induk: ${esc(a.parentEmail)}</span> ${parentBadge(a.parentStatus)}` : '<span style="color:var(--red)">⚠ Belum ada Gmail induk — OTP tidak bisa dibaca</span>'}</div></td>
        <td>${stateBadge(a)}<div class="small muted">${{ auto: 'Otomatis', ready: 'Paksa siap', not_ready: 'Paksa belum siap', disabled: 'Disembunyikan' }[a.manualStatus]}</div></td>
        <td>${a.readyDays} hari<div class="small muted">${fmtDate(a.readyAt)}</div></td>
        <td>${a.lastMatchAt ? fmtDate(a.lastMatchAt) : '—'}<div><button class="btn sm ghost" data-today="${a.id}" style="padding:2px 6px">Set hari ini</button></div></td>
        <td><div class="row"><button class="btn sm" data-otp="${a.id}">Cek OTP</button><button class="btn sm" data-edit="${a.id}">Edit</button><button class="btn sm danger" data-del="${a.id}">Hapus</button></div></td>
      </tr>`).join('')}</tbody></table></div>` : `<div class="empty">Belum ada stok. Klik <b>+ Tambah Stok Akun</b>.</div>`}`
  $('#addAcc').addEventListener('click', () => accountForm(d))
  $$('[data-edit]', t).forEach((b) => b.addEventListener('click', () => accountForm(d, d.stock.find((a) => a.id === Number(b.dataset.edit)))))
  $$('[data-del]', t).forEach((b) => b.addEventListener('click', () => {
    const a = d.stock.find((x) => x.id === Number(b.dataset.del))
    if (confirm(`Hapus ${a.label} (${a.mlEmail}) dari stok?`)) devCall(`/accounts/${a.id}`, 'DELETE').then(() => toast('Akun dihapus — stok pembeli sudah diperbarui.', 'ok')).catch(() => {})
  }))
  $$('[data-today]', t).forEach((b) => b.addEventListener('click', () => devCall(`/accounts/${b.dataset.today}`, 'PUT', { lastMatchAt: todayISO() }).then(() => toast('Tanggal match diperbarui', 'ok')).catch(() => {})))
  $$('[data-otp]', t).forEach((b) => b.addEventListener('click', () => otpModal(d.stock.find((a) => a.id === Number(b.dataset.otp)))))
}

function accountForm(d, a) {
  const usedEmails = new Set(d.stock.map((x) => x.mlEmail))
  const freeAliases = d.parents.flatMap((p) => p.aliases.filter((x) => !usedEmails.has(x.email) || x.email === a?.mlEmail).map((x) => x.email))
  const m = modal(`
    <div class="row between"><h3>${a ? 'Edit akun' : 'Tambah stok akun'}</h3><button class="btn sm ghost" data-close>✕</button></div>
    <form id="accForm" style="margin-top:14px">
      ${a ? '' : `<div class="tabs"><button type="button" class="tab on" data-m="one">Satu akun</button><button type="button" class="tab" data-m="bulk">Banyak sekaligus</button></div>`}
      <div class="one">
        <div class="field"><label class="f">Email akun ML (email bertitik)</label><input class="input mono" name="mlEmail" list="aliasList" value="${esc(a?.mlEmail || '')}" placeholder="h.ara.panindubapam@gmail.com" ${a ? 'required' : ''} />
          <datalist id="aliasList">${freeAliases.map((e) => `<option value="${esc(e)}"></option>`).join('')}</datalist>
          <div class="hint">Gmail induk dikenali otomatis dari email ini (titik diabaikan). ${freeAliases.length ? `${freeAliases.length} email bertitik siap dipakai.` : ''}</div></div>
        <div class="grid g2" style="margin-top:14px">
          <div><label class="f">Nama / label</label><input class="input" name="label" value="${esc(a?.label || '')}" placeholder="Akun Epic 01" /></div>
          <div><label class="f">Password akun ML</label><input class="input mono" name="mlPassword" value="${esc(a?.mlPassword || '')}" placeholder="opsional" /></div>
        </div>
      </div>
      <div class="bulk hidden">
        <div class="field"><label class="f">Daftar akun (satu per baris)</label><textarea class="input mono" name="bulk" placeholder="email@gmail.com|password|Label (opsional)&#10;e.mail@gmail.com|password"></textarea><div class="hint">Format: <code>email|password|label</code>. Password & label boleh kosong.</div></div>
      </div>
      <div class="grid g2" style="margin-top:14px">
        <div><label class="f">Jumlah hari sampai siap</label><input class="input" type="number" min="0" max="365" name="readyDays" value="${a?.readyDays ?? 14}" /><div class="hint">Dihitung dari tanggal masuk stok. Isi 0 bila langsung siap.</div></div>
        <div><label class="f">Tanggal masuk stok</label><input class="input" type="date" name="addedAt" value="${(a?.addedAt ? new Date(a.addedAt).toISOString() : new Date().toISOString()).slice(0, 10)}" /></div>
        <div><label class="f">Tanggal terakhir match</label><input class="input" type="date" name="lastMatchAt" value="${esc(a?.lastMatchAt ? String(a.lastMatchAt).slice(0, 10) : '')}" /><div class="hint">Terlihat oleh pembeli.</div></div>
        <div><label class="f">Status</label><select class="input" name="status">
          ${[['auto', 'Otomatis (ikut hitungan hari)'], ['ready', 'Siap dipakai (paksa)'], ['not_ready', 'Belum siap (paksa)'], ['disabled', 'Nonaktif / sembunyikan']].map(([v, l]) => `<option value="${v}" ${(a?.manualStatus || 'auto') === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select></div>
      </div>
      <div class="field" style="margin-top:14px"><label class="f">Catatan untuk pembeli (opsional)</label><input class="input" name="note" maxlength="200" value="${esc(a?.note || '')}" placeholder="Contoh: Hero lengkap, emblem max" /></div>
      <div id="accErr" class="notice n-err hidden" style="margin-top:12px"></div>
      <button class="btn gold block lg" style="margin-top:16px" id="accSave">${a ? 'Simpan perubahan' : 'Tambah ke stok'}</button>
    </form>`, { wide: true })
  let mode = 'one'
  $$('[data-m]', m.el).forEach((b) => b.addEventListener('click', () => {
    mode = b.dataset.m
    $$('[data-m]', m.el).forEach((x) => x.classList.toggle('on', x === b))
    $('.one', m.el).classList.toggle('hidden', mode !== 'one')
    $('.bulk', m.el).classList.toggle('hidden', mode !== 'bulk')
  }))
  $('#accForm').addEventListener('submit', async (e) => {
    e.preventDefault()
    const f = Object.fromEntries(new FormData(e.target))
    const err = $('#accErr')
    err.classList.add('hidden')
    const common = { readyDays: f.readyDays, addedAt: f.addedAt ? new Date(f.addedAt + 'T00:00:00').toISOString() : undefined, lastMatchAt: f.lastMatchAt || '', status: f.status, note: f.note }
    await busy($('#accSave'), async () => {
      try {
        if (a) {
          await api(`/api/dev/accounts/${a.id}`, { method: 'PUT', body: { ...common, mlEmail: f.mlEmail, mlPassword: f.mlPassword, label: f.label } })
          toast('Akun diperbarui — tampilan pembeli ikut berubah.', 'ok')
        } else if (mode === 'bulk') {
          const lines = String(f.bulk || '').split('\n').map((l) => l.trim()).filter(Boolean)
          if (!lines.length) throw new Error('Isi minimal satu baris.')
          let ok = 0
          const fails = []
          for (const line of lines) {
            const [mlEmail, mlPassword = '', label = ''] = line.split('|').map((x) => x.trim())
            try { await api('/api/dev/accounts', { method: 'POST', body: { ...common, mlEmail, mlPassword, label } }); ok++ } catch (x) { fails.push(`${mlEmail}: ${x.message}`) }
          }
          toast(`${ok} akun ditambahkan${fails.length ? `, ${fails.length} gagal` : ''}.`, fails.length ? 'err' : 'ok')
          if (fails.length) { err.innerHTML = fails.map(esc).join('<br>'); err.classList.remove('hidden'); await devRefresh(); return }
        } else {
          if (!f.mlEmail) throw new Error('Isi email akun.')
          const r = await api('/api/dev/accounts', { method: 'POST', body: { ...common, mlEmail: f.mlEmail, mlPassword: f.mlPassword, label: f.label } })
          toast(r.parentLinked ? 'Akun ditambahkan & terhubung ke Gmail induk ✓' : 'Akun ditambahkan. ⚠ Belum ada Gmail induk yang cocok.', r.parentLinked ? 'ok' : 'err')
        }
        m.close()
        await devRefresh()
      } catch (x) {
        err.textContent = x.message
        err.classList.remove('hidden')
      }
    })
  })
}

function otpModal(a) {
  const m = modal(`<div class="row between"><h3 style="font-size:1.05rem">OTP terbaru · <span class="mono">${esc(a.mlEmail)}</span></h3><button class="btn sm ghost" data-close>✕</button></div><div id="otpRes" style="margin-top:14px"><div class="empty"><span class="spinner"></span> Membaca Gmail induk lewat IMAP…</div></div>`, { wide: true })
  const run = async () => {
    const box = $('#otpRes', m.el)
    if (!box) return
    box.innerHTML = `<div class="empty"><span class="spinner"></span> Membaca Gmail induk lewat IMAP…</div>`
    let r
    try { r = await api(`/api/dev/accounts/${a.id}/otp`) } catch (e) { r = { ok: false, message: e.message } }
    const diag = r.diag ? `<details style="margin-top:12px"><summary class="small muted">Detail pemeriksaan</summary><div class="small muted" style="margin-top:6px">
      Folder dibaca: ${esc((r.diag.folders || []).join(', ') || '—')}<br>Email Moonton (3 hari): ${r.diag.moontonTotal} · dalam 24 jam: ${r.diag.inWindow}<br>
      ${r.diag.otherRecipients?.length ? `Dikirim ke alamat: <span class="mono">${esc(r.diag.otherRecipients.join(', '))}</span>` : ''}</div></details>` : ''
    if (r.otp) {
      box.innerHTML = `<div class="otp-box ${r.otp.expired ? 'old' : ''}"><div class="small muted">${r.otp.expired ? 'Kode terakhir (sudah lewat 10 menit)' : 'Kode verifikasi Moonton'}</div><div class="otp-code">${esc(r.otp.code)}</div><div class="small muted">Diterima ${fmtDate(r.otp.receivedAt, true)} (${ago(r.otp.receivedAt)})</div><button class="btn gold sm" style="margin-top:10px" data-copy="${esc(r.otp.code)}">Salin</button></div>
        ${r.history?.length > 1 ? `<div class="small muted" style="margin-top:10px">Riwayat: ${r.history.map((h) => `<span class="mono">${esc(h.code)}</span> (${ago(h.receivedAt)})`).join(' · ')}</div>` : ''}${diag}`
    } else {
      box.innerHTML = `<div class="notice ${r.ok ? 'n-warn' : 'n-err'}">${esc(r.message)}</div>${diag}`
    }
    box.insertAdjacentHTML('beforeend', `<button class="btn" style="margin-top:14px" id="otpAgain">Cek ulang</button>`)
    $('#otpAgain', m.el).addEventListener('click', run)
  }
  run()
}

// --- gmail tab
function dottedVariants(email, n = 5, exclude = new Set()) {
  const [local, domain] = email.split('@')
  const base = local.replace(/\./g, '')
  const out = new Set()
  let guard = 0
  const max = Math.pow(2, base.length - 1) - 1
  while (out.size < Math.min(n, max) && guard++ < 2000) {
    let s = base[0]
    for (let i = 1; i < base.length; i++) s += (Math.random() < 0.3 ? '.' : '') + base[i]
    const e = `${s}@${domain}`
    if (s !== base && !exclude.has(e)) out.add(e)
  }
  return [...out]
}

function devGmail(t, d) {
  t.innerHTML = `
    <div class="card" style="margin-bottom:16px">
      <div class="row between">
        <div><h3 style="font-size:1.2rem">📧 Gmail Induk Saya</h3>
          <p class="muted small" style="margin:6px 0 0;max-width:640px">Pasang Gmail + App Password. Website login ke Gmail lewat IMAP dan membaca email OTP Moonton yang dikirim ke setiap <b>email bertitik</b>, lalu menampilkannya otomatis ke pembeli yang sedang menyewa akun itu.</p></div>
        <div style="text-align:right"><div class="display" style="font-size:1.5rem">${d.parents.filter((p) => p.status === 'ok').length}/${d.parents.length}</div><div class="small muted">Terhubung</div></div>
      </div>
      <div class="row" style="margin-top:14px"><button class="btn gold" id="addParent">➕ Pasang Gmail Induk</button><button class="btn" id="addAlias" ${d.parents.length ? '' : 'disabled'}>🔵 Tambah email bertitik</button></div>
    </div>
    ${d.parents.length ? d.parents.map((p) => `
      <div class="card" style="margin-bottom:14px">
        <div class="row between">
          <div><b class="mono" style="font-size:1.05rem">${esc(p.email)}</b><div class="small muted">App Password: ${p.hasPassword ? `<span class="mono">${esc(p.passwordHint)}</span>` : 'belum diisi'} · dicek ${p.checkedAt ? ago(p.checkedAt) : '—'}</div></div>
          ${parentBadge(p.status)}
        </div>
        ${p.statusMessage ? `<div class="notice ${p.status === 'ok' ? 'n-ok' : p.status === 'empty' ? 'n-info' : 'n-err'}" style="margin-top:12px">${esc(p.statusMessage)}</div>` : ''}
        <div style="margin-top:14px"><div class="small muted" style="margin-bottom:6px">Email bertitik (${p.aliases.length})</div>
          <div class="chips">${p.aliases.map((x) => `<span class="chip" style="cursor:default">${esc(x.email)} ${x.used ? '<span style="color:var(--green)">• dipakai</span>' : ''} <button class="btn sm ghost" style="padding:0 4px" data-delalias="${x.id}" title="Hapus">✕</button></span>`).join('') || '<span class="small muted">Belum ada.</span>'}</div></div>
        <div class="row" style="margin-top:14px">
          <button class="btn sm" data-check="${p.id}">Cek ulang koneksi</button>
          <button class="btn sm" data-pw="${p.id}">${p.hasPassword ? 'Ganti' : 'Isi'} App Password</button>
          <button class="btn sm" data-alias="${p.id}">+ Email bertitik</button>
          <button class="btn sm danger" data-delparent="${p.id}">Hapus</button>
        </div>
      </div>`).join('') : `<div class="empty">Belum ada Gmail induk terpasang.</div>`}
    <div class="card guide small">
      <h3 style="font-size:1rem">Cara membuat App Password & mengaktifkan IMAP</h3>
      <ol class="muted">
        <li>Buka <a target="_blank" rel="noopener" href="https://myaccount.google.com/signinoptions/two-step-verification">Verifikasi 2 Langkah</a> dan aktifkan (wajib, tanpa ini App Password tidak tersedia).</li>
        <li>Buka <a target="_blank" rel="noopener" href="https://myaccount.google.com/apppasswords">myaccount.google.com/apppasswords</a>, buat nama misalnya <code>FirasX Rent</code>, salin 16 hurufnya.</li>
        <li>Di Gmail web: Setelan ⚙ → Lihat semua setelan → <b>Penerusan dan POP/IMAP</b> → <b>Aktifkan IMAP</b> → Simpan.</li>
        <li>Pasang di sini. Website langsung mengetes login sungguhan ke <code>imap.gmail.com</code> dan menampilkan hasilnya: terhubung, App Password salah, IMAP belum aktif, atau diblokir Google.</li>
        <li>Email bertitik (mis. <code>h.ara.panindubapam@gmail.com</code>) adalah alamat yang dipakai login akun ML. Semua masuk ke inbox Gmail induk yang sama, dan website membedakan OTP tiap akun dari alamat tujuan emailnya.</li>
      </ol>
    </div>`
  $('#addParent').addEventListener('click', () => parentForm())
  $('#addAlias').addEventListener('click', () => aliasForm(d))
  $$('[data-check]', t).forEach((b) => b.addEventListener('click', () => busy(b, async () => {
    try { const r = await devCall(`/parents/${b.dataset.check}/check`); toast(r.check.message, r.check.ok ? 'ok' : 'err') } catch {}
  })))
  $$('[data-pw]', t).forEach((b) => b.addEventListener('click', () => pwForm(d.parents.find((p) => p.id === Number(b.dataset.pw)))))
  $$('[data-alias]', t).forEach((b) => b.addEventListener('click', () => aliasForm(d, Number(b.dataset.alias))))
  $$('[data-delalias]', t).forEach((b) => b.addEventListener('click', () => devCall(`/aliases/${b.dataset.delalias}`, 'DELETE').catch(() => {})))
  $$('[data-delparent]', t).forEach((b) => b.addEventListener('click', () => confirm('Hapus Gmail induk ini? Akun stok yang memakainya tidak bisa menerima OTP otomatis.') && devCall(`/parents/${b.dataset.delparent}`, 'DELETE').catch(() => {})))
}

function checkResult(el, r) {
  el.className = `notice ${r.ok ? 'n-ok' : 'n-err'}`
  el.innerHTML = `<b>${r.ok ? '✓ Terhubung' : '✕ Gagal'}</b> — ${esc(r.message)}`
  el.classList.remove('hidden')
}

function parentForm() {
  const m = modal(`
    <div class="row between"><h3>Pasang Gmail Induk</h3><button class="btn sm ghost" data-close>✕</button></div>
    <form id="pf" style="margin-top:14px">
      <div class="field"><label class="f">Gmail induk</label><input class="input mono" name="email" type="email" required placeholder="harapanindubapam@gmail.com" /></div>
      <div class="field"><label class="f">App Password (16 huruf)</label><input class="input mono" name="appPassword" autocomplete="off" placeholder="abcd efgh ijkl mnop" /><div class="hint">Bukan sandi Gmail biasa. Spasi boleh, otomatis dihapus. Boleh dikosongkan dulu (status: Belum diisi).</div></div>
      <div class="field"><label class="f">Email bertitik (opsional, satu per baris)</label><textarea class="input mono" name="aliases" placeholder="h.arapanindubapam@gmail.com&#10;ha.ra.panindubapam@gmail.com"></textarea>
        <button type="button" class="btn sm" style="margin-top:8px" id="gen">Buat 5 variasi otomatis</button></div>
      <div id="pfRes" class="hidden" style="margin-top:12px"></div>
      <button class="btn gold block lg" style="margin-top:16px" id="pfBtn">Simpan & cek otomatis</button>
    </form>`)
  $('#gen').addEventListener('click', () => {
    const e = $('[name=email]', m.el).value.trim().toLowerCase()
    if (!/@gmail\.com$/.test(e)) return toast('Isi Gmail induk dulu.', 'err')
    const ta = $('[name=aliases]', m.el)
    const have = new Set(ta.value.split(/\s+/).filter(Boolean))
    ta.value = [...have, ...dottedVariants(e, 5, have)].join('\n')
  })
  $('#pf').addEventListener('submit', async (e) => {
    e.preventDefault()
    const f = Object.fromEntries(new FormData(e.target))
    const res = $('#pfRes')
    await busy($('#pfBtn'), async () => {
      try {
        const r = await api('/api/dev/parents', { method: 'POST', body: f })
        checkResult(res, r.check)
        if (r.added?.rejected?.length) res.insertAdjacentHTML('beforeend', `<div class="small" style="margin-top:6px">Email dilewati: ${r.added.rejected.map((x) => esc(x.email + ' (' + x.reason + ')')).join(', ')}</div>`)
        $('#pfBtn').textContent = 'Tutup'
        $('#pf').onsubmit = (ev) => { ev.preventDefault(); m.close() }
        await devRefresh()
      } catch (x) {
        res.className = 'notice n-err'
        res.textContent = x.message
      }
    })
  })
}

function pwForm(p) {
  const m = modal(`
    <div class="row between"><h3>App Password</h3><button class="btn sm ghost" data-close>✕</button></div>
    <p class="small muted mono">${esc(p.email)}</p>
    <form id="pwf"><div class="field"><label class="f">App Password baru</label><input class="input mono" name="appPassword" autocomplete="off" placeholder="abcd efgh ijkl mnop" /></div>
    <div id="pwRes" class="hidden" style="margin-top:12px"></div>
    <button class="btn gold block" style="margin-top:14px" id="pwBtn">Simpan & cek otomatis</button></form>`)
  $('#pwf').addEventListener('submit', async (e) => {
    e.preventDefault()
    await busy($('#pwBtn'), async () => {
      try {
        const r = await api(`/api/dev/parents/${p.id}`, { method: 'PUT', body: Object.fromEntries(new FormData(e.target)) })
        checkResult($('#pwRes'), r.check)
        await devRefresh()
      } catch (x) { toast(x.message, 'err') }
    })
  })
}

function aliasForm(d, parentId) {
  const m = modal(`
    <div class="row between"><h3>Tambah email bertitik</h3><button class="btn sm ghost" data-close>✕</button></div>
    <form id="af" style="margin-top:14px">
      <div class="field"><label class="f">Gmail induk</label><select class="input" name="parent">${d.parents.map((p) => `<option value="${p.id}" ${p.id === parentId ? 'selected' : ''}>${esc(p.email)}</option>`).join('')}</select></div>
      <div class="field"><label class="f">Email bertitik (satu per baris)</label><textarea class="input mono" name="aliases" placeholder="na.ma.kamu@gmail.com"></textarea>
      <button type="button" class="btn sm" style="margin-top:8px" id="gen2">Buat 5 variasi otomatis</button></div>
      <div id="afRes" class="hidden notice" style="margin-top:12px"></div>
      <button class="btn gold block" style="margin-top:14px" id="afBtn">Tambahkan</button>
    </form>`)
  $('#gen2').addEventListener('click', () => {
    const p = d.parents.find((x) => x.id === Number($('[name=parent]', m.el).value))
    const ta = $('[name=aliases]', m.el)
    const have = new Set([...ta.value.split(/\s+/).filter(Boolean), ...p.aliases.map((x) => x.email)])
    ta.value = [...ta.value.split(/\s+/).filter(Boolean), ...dottedVariants(p.email, 5, have)].join('\n')
  })
  $('#af').addEventListener('submit', async (e) => {
    e.preventDefault()
    const f = Object.fromEntries(new FormData(e.target))
    await busy($('#afBtn'), async () => {
      try {
        const r = await api(`/api/dev/parents/${f.parent}/aliases`, { method: 'POST', body: { aliases: f.aliases } })
        const res = $('#afRes')
        res.className = `notice ${r.rejected.length ? 'n-warn' : 'n-ok'}`
        res.innerHTML = `${r.added.length} email ditambahkan.${r.rejected.length ? '<br>Dilewati: ' + r.rejected.map((x) => esc(`${x.email} (${x.reason})`)).join(', ') : ''}`
        await devRefresh()
        if (!r.rejected.length) setTimeout(m.close, 700)
      } catch (x) { toast(x.message, 'err') }
    })
  })
}

// --- payments tab
function devPayments(t, d) {
  t.innerHTML = `
    <div class="row between" style="margin-bottom:12px"><p class="muted small" style="margin:0">Metode yang aktif langsung tampil di halaman pembelian.</p><button class="btn gold" id="addPm">+ Tambah pembayaran</button></div>
    ${d.payments.length ? `<div class="grid g3">${d.payments.map((p) => `
      <div class="card stack">
        <div class="row between"><div class="row"><div class="pay-opt" style="padding:0;border:0;background:none"><div class="ic ic-${p.type}">${p.type === 'qris' ? 'QRIS' : p.type === 'dana' ? 'DANA' : 'BANK'}</div></div><b>${esc(p.name)}</b></div>
          <span class="badge ${p.active ? 'b-ok' : 'b-disabled'}">${p.active ? 'Aktif' : 'Nonaktif'}</span></div>
        ${p.type === 'qris' && p.hasQris ? `<img class="qris-img" style="max-width:180px" src="/api/payments/${p.id}/qris?ts=${Date.now()}" alt="QRIS" onerror="this.style.display='none'" />` : ''}
        ${p.accountNumber ? `<div class="mono">${esc(p.accountNumber)}</div>` : ''}${p.holder ? `<div class="small muted">a.n. ${esc(p.holder)}</div>` : ''}
        <div class="row"><button class="btn sm" data-pmedit="${p.id}">Edit</button><button class="btn sm" data-pmtoggle="${p.id}">${p.active ? 'Nonaktifkan' : 'Aktifkan'}</button><button class="btn sm danger" data-pmdel="${p.id}">Hapus</button></div>
      </div>`).join('')}</div>` : `<div class="empty">Belum ada metode pembayaran. Tambahkan DANA atau QRIS agar pengunjung bisa membayar.</div>`}`
  $('#addPm').addEventListener('click', () => pmForm())
  $$('[data-pmedit]', t).forEach((b) => b.addEventListener('click', () => pmForm(d.payments.find((p) => p.id === Number(b.dataset.pmedit)))))
  $$('[data-pmtoggle]', t).forEach((b) => b.addEventListener('click', () => {
    const p = d.payments.find((x) => x.id === Number(b.dataset.pmtoggle))
    devCall(`/payments/${p.id}`, 'PUT', { active: !p.active }).catch(() => {})
  }))
  $$('[data-pmdel]', t).forEach((b) => b.addEventListener('click', () => confirm('Hapus metode pembayaran ini?') && devCall(`/payments/${b.dataset.pmdel}`, 'DELETE').catch(() => {})))
}

function pmForm(p) {
  const m = modal(`
    <div class="row between"><h3>${p ? 'Edit' : 'Tambah'} pembayaran</h3><button class="btn sm ghost" data-close>✕</button></div>
    <form id="pmf" style="margin-top:14px">
      <div class="field"><label class="f">Jenis</label><select class="input" name="type">
        ${[['dana', 'DANA'], ['qris', 'QRIS'], ['other', 'Lainnya (bank / e-wallet)']].map(([v, l]) => `<option value="${v}" ${(p?.type || 'dana') === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div class="field"><label class="f">Nama tampilan</label><input class="input" name="name" value="${esc(p?.name || '')}" placeholder="DANA / QRIS FirasX" /></div>
      <div class="field nonqris"><label class="f">Nomor</label><input class="input mono" name="accountNumber" value="${esc(p?.accountNumber || '')}" inputmode="numeric" placeholder="08xxxxxxxxxx" /></div>
      <div class="field"><label class="f">Atas nama</label><input class="input" name="holder" value="${esc(p?.holder || '')}" /></div>
      <div class="field isqris"><label class="f">Gambar QRIS</label><input class="input" type="file" accept="image/*" id="qrisFile" /><div class="hint">${p?.hasQris ? 'Kosongkan jika tidak ingin mengganti gambar.' : 'Unggah screenshot/foto QRIS kamu.'}</div><img id="qrisPrev" class="qris-img hidden" style="margin-top:10px;max-width:200px" alt="" /></div>
      <button class="btn gold block" style="margin-top:16px" id="pmBtn">Simpan</button>
    </form>`)
  const sync = () => {
    const isQ = $('[name=type]', m.el).value === 'qris'
    $('.isqris', m.el).classList.toggle('hidden', !isQ)
    $('.nonqris', m.el).classList.toggle('hidden', isQ)
  }
  sync()
  $('[name=type]', m.el).addEventListener('change', sync)
  let qris = null
  $('#qrisFile').addEventListener('change', async (e) => {
    try {
      qris = await readImage(e.target.files[0], 1000, 0.92)
      $('#qrisPrev').src = qris
      $('#qrisPrev').classList.remove('hidden')
    } catch (x) { toast(x.message, 'err') }
  })
  $('#pmf').addEventListener('submit', async (e) => {
    e.preventDefault()
    const f = Object.fromEntries(new FormData(e.target))
    await busy($('#pmBtn'), async () => {
      try {
        await api(p ? `/api/dev/payments/${p.id}` : '/api/dev/payments', { method: p ? 'PUT' : 'POST', body: { ...f, qrisImage: qris } })
        toast('Pembayaran disimpan ✓', 'ok')
        m.close()
        await refreshPublic()
        await devRefresh()
      } catch (x) { toast(x.message, 'err') }
    })
  })
}

// --- settings tab
function devSettings(t, d) {
  const s = d.settings
  t.innerHTML = `
    <form class="card" id="sf" style="max-width:720px">
      <div class="grid g2">
        <div><label class="f">Nama toko</label><input class="input" name="storeName" value="${esc(s.storeName)}" /></div>
        <div><label class="f">Harga sewa per hari / akun (Rp)</label><input class="input" type="number" min="0" name="pricePerDay" value="${s.pricePerDay}" /></div>
        <div><label class="f">Maksimal hari per pesanan</label><input class="input" type="number" min="1" max="60" name="maxDays" value="${s.maxDays}" /></div>
        <div><label class="f">Batas waktu bayar (menit)</label><input class="input" type="number" min="5" max="1440" name="reserveMinutes" value="${s.reserveMinutes}" /><div class="hint">Akun ditahan selama ini sambil menunggu bukti bayar.</div></div>
        <div><label class="f">WhatsApp admin</label><input class="input" name="whatsapp" value="${esc(s.whatsapp || '')}" placeholder="628xxxxxxxxxx" /></div>
      </div>
      <div class="field" style="margin-top:14px"><label class="f">Teks pengumuman di beranda</label><textarea class="input" name="announcement" maxlength="400">${esc(s.announcement || '')}</textarea></div>
      <button class="btn gold" style="margin-top:16px" id="sfBtn">Simpan pengaturan</button>
    </form>`
  $('#sf').addEventListener('submit', async (e) => {
    e.preventDefault()
    await busy($('#sfBtn'), async () => {
      try {
        await api('/api/dev/settings', { method: 'PUT', body: Object.fromEntries(new FormData(e.target)) })
        await refreshPublic()
        await devRefresh()
        toast('Pengaturan tersimpan — langsung berlaku untuk semua pengunjung.', 'ok')
      } catch (x) { toast(x.message, 'err') }
    })
  })
}

// --- guide tab
function devGuide(t, d) {
  const host = location.host
  t.innerHTML = `
    <div class="grid g2 guide">
      <div class="card small">
        <h3 style="font-size:1.05rem">Memasang domain sendiri</h3>
        <ol class="muted">
          <li>Beli domain (mis. <code>firasxrent.com</code>) di Niagahoster, Domainesia, Namecheap, dll.</li>
          <li>Buka dashboard Netlify → project ini → <b>Domain management</b> → <b>Add a domain</b>, masukkan domain kamu.</li>
          <li>Pilih salah satu:
            <ul><li><b>Netlify DNS</b> (paling mudah): ganti nameserver di tempat beli domain menjadi nameserver yang ditampilkan Netlify.</li>
            <li><b>DNS luar</b>: buat record <code>CNAME www → ${esc(host)}</code> dan record <code>A @ → 75.2.60.5</code>.</li></ul></li>
          <li>Tunggu propagasi DNS (biasanya 5 menit – 24 jam). HTTPS/SSL aktif otomatis.</li>
          <li>Semua fitur (login, stok, OTP, pembayaran) langsung jalan di domain baru — tidak ada yang perlu diubah.</li>
        </ol>
      </div>
      <div class="card small">
        <h3 style="font-size:1.05rem">Webhook pembayaran otomatis ${d.webhookEnabled ? '<span class="badge b-ok">Aktif</span>' : '<span class="badge b-disabled">Belum aktif</span>'}</h3>
        <p class="muted">Tanpa webhook, kamu cukup menekan <b>Konfirmasi lunas</b> di tab Pesanan. Untuk konfirmasi otomatis dari payment gateway (Tripay, Midtrans, Xendit, dll.):</p>
        <ol class="muted">
          <li>Di Netlify → Project configuration → Environment variables, tambahkan <code>PAYMENT_WEBHOOK_SECRET</code> berisi kata sandi acak yang panjang.</li>
          <li>Set URL callback di gateway: <code>https://${esc(host)}/api/webhook/payment</code></li>
          <li>Body JSON: <code>{"code":"KODEPESANAN","status":"paid","amount":4000}</code> dengan header <code>X-Signature</code> = HMAC-SHA256(body, secret) dalam hex.</li>
          <li>Pesanan langsung aktif dan pembeli melihat data akun + OTP tanpa menunggu kamu.</li>
        </ol>
      </div>
      <div class="card small">
        <h3 style="font-size:1.05rem">Akun khusus</h3>
        <ul class="muted">
          <li><b>Developer</b> — mengatur harga, stok, status akun, Gmail induk, pembayaran, dan konfirmasi pesanan.</li>
          <li><b>Co Developer</b> — bisa mengambil akun sewa gratis tanpa bayar. Tidak bisa membuka panel ini.</li>
          <li><b>Member & pengunjung</b> — menyewa dengan bayar. Fitur Developer/Co Developer tidak ditampilkan.</li>
        </ul>
      </div>
      <div class="card small">
        <h3 style="font-size:1.05rem">Alur OTP otomatis</h3>
        <ol class="muted">
          <li>Pembeli meminta kode di game ke email bertitik akun.</li>
          <li>Moonton mengirim email ke inbox Gmail induk.</li>
          <li>Halaman pesanan pembeli mengecek Gmail induk via IMAP tiap 10 detik dan menampilkan kode untuk alamat itu saja.</li>
          <li>Kalau ada masalah (App Password salah, IMAP mati, diblokir Google), statusnya muncul di tab Gmail Induk.</li>
        </ol>
      </div>
    </div>`
}

// ------------------------------------------------------------------ router

async function refreshPublic() {
  try {
    state.pub = await api('/api/public')
    renderNav()
  } catch {}
}

async function route() {
  clearTimers()
  $('#nav').classList.remove('open')
  const raw = location.hash.replace(/^#/, '') || '/'
  const [path, qs = ''] = raw.split('?')
  const params = new URLSearchParams(qs)
  const parts = path.split('/').filter(Boolean)
  renderNav()
  window.scrollTo(0, 0)
  if (!parts.length) return pageHome()
  if (parts[0] === 'stok') return pageStock()
  if (parts[0] === 'sewa') return pageRent(params)
  if (parts[0] === 'pesanan' && parts[1]) return pageOrder(decodeURIComponent(parts[1]).toUpperCase(), parts[2] ? decodeURIComponent(parts[2]) : '')
  if (parts[0] === 'pesananku') return pageMyOrders()
  if (parts[0] === 'dev') return pageDev()
  if (parts[0] === 'masuk') { openAuth('login'); location.hash = '#/'; return }
  pageHome()
}

window.addEventListener('hashchange', route)
document.addEventListener('visibilitychange', () => { if (!document.hidden && state.stock) loadStock().catch(() => {}) })

;(async function init() {
  $('#year').textContent = new Date().getFullYear()
  const [me] = await Promise.all([api('/api/auth/me').catch(() => ({ user: null })), refreshPublic()])
  state.me = me.user
  await route()
  if (!state.me && !localStorage.getItem('fx_mode') && !location.hash.startsWith('#/pesanan')) openAuth('login')
})()
