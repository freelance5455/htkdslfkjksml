const $ = id => document.getElementById(id);
const esc = x => String(x ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

let mem = JSON.parse(localStorage.getItem("pai3") || '{"r":[],"h":0,"t":[]}');
function save(){ localStorage.setItem("pai3", JSON.stringify(mem)); ui(); }
function ui(){
  $("rc").textContent = mem.r.length;
  $("hc").textContent = mem.h;
  $("tc").textContent = [...new Set(mem.t)].length;
  $("saved").innerHTML = mem.r.slice().reverse().map(x => `<div class="card"><h3>${esc(x.t)}</h3><p>${esc(x.d)}</p><a target="_blank" rel="noopener" href="${x.u}">Read source ↗</a></div>`).join("") || `<div class="box">No saved research yet.</div>`;
}

// Tabs
document.querySelectorAll(".tab").forEach(b => b.onclick = () => {
  document.querySelectorAll(".tab,.panel").forEach(x => x.classList.remove("on"));
  b.classList.add("on"); $(b.dataset.p).classList.add("on");
});
function msg(s,c){ const d=document.createElement("div"); d.className="msg "+c; d.textContent=s; $("chatbox").appendChild(d); $("chatbox").scrollTop=$("chatbox").scrollHeight; }

// Offline reasoning layer: combines exact matches, synonyms, spelling similarity and
// topic descriptions so short, long, or misspelled questions can still find the
// closest physics concepts without needing an internet connection.
const STOP=new Set("a an and are as at be by can could did do does for from how i in is it me of on or please tell that the this to was what when where which who why with would you your explain about give show something someone want wants need needs into than then them they we will would work works using use used".split(/\s+/));
const SYN={
  "push":"force","pull":"force","speeding":"acceleration","slowing":"acceleration","slow":"acceleration",
  "fall":"gravity","falling":"gravity","drop":"gravity","dropped":"gravity","weight":"gravity",
  "moving":"motion","movement":"motion","travel":"motion","travelling":"motion","traveling":"motion",
  "heat":"thermal","hot":"thermal","cold":"thermal","warming":"thermal","cooling":"thermal",
  "electricity":"electric","electrical":"electric","current":"electric current","voltage":"potential difference",
  "light":"optics","lens":"optics","lenses":"optics","mirror":"optics","mirrors":"optics",
  "soundwave":"sound","soundwaves":"sound","vibration":"oscillation","vibrations":"oscillation",
  "spin":"rotation","spinning":"rotation","turning":"torque","twisting":"torque",
  "springy":"spring","stretch":"elastic","stretching":"elastic","bouncy":"elastic",
  "floating":"buoyancy","float":"buoyancy","sink":"buoyancy",
  "space":"astrophysics","planet":"astrophysics","planets":"astrophysics","star":"astrophysics","stars":"astrophysics",
  "atom":"atomic physics","atoms":"atomic physics","electron":"electricity","electrons":"electricity",
  "nucleus":"nuclear physics","nuclei":"nuclear physics","radioactive":"radioactivity","radiation":"radiation",
  "quantum":"quantum mechanics","relativity":"relativity","einstein":"relativity",
  "machine":"mechanics","machines":"mechanics","engine":"thermodynamics","engines":"thermodynamics",
  "water":"fluid","air":"fluid","pressure":"pressure","density":"density"
};
const SPELL={
  "gravitty":"gravity","gravty":"gravity","gravitiy":"gravity","accelaration":"acceleration","accleration":"acceleration",
  "velosity":"velocity","velecity":"velocity","forse":"force","newtonian":"newton","mommentum":"momentum",
  "energey":"energy","kineticc":"kinetic","potencial":"potential","pressur":"pressure","denssity":"density",
  "fricton":"friction","frictionn":"friction","pendullum":"pendulum","oscilation":"oscillation",
  "frequncy":"frequency","wavelenght":"wavelength","wavelenth":"wavelength","electromagnetismm":"electromagnetism",
  "magnetisim":"magnetism","electricty":"electricity","electrcity":"electricity","resistence":"resistance",
  "temprature":"temperature","thermodynamcs":"thermodynamics","entrophy":"entropy","optcs":"optics",
  "quantam":"quantum","relativty":"relativity","nucelar":"nuclear","photn":"photon","phooton":"photon"
};
function norm(s){return String(s||"").toLowerCase().replace(/[^a-z0-9μλ²³°]+/g," ").replace(/\s+/g," ").trim();}
function words(s){return norm(s).split(" ").filter(w=>w && w.length>1 && !STOP.has(w));}
function lev(a,b){
  a=String(a);b=String(b); if(a===b)return 0; if(!a)return b.length;if(!b)return a.length;
  let prev=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=0;i<a.length;i++){
    const cur=[i+1];
    for(let j=0;j<b.length;j++) cur[j+1]=Math.min(cur[j]+1,prev[j+1]+1,prev[j]+(a[i]===b[j]?0:1));
    prev=cur;
  }
  return prev[b.length];
}
function sim(a,b){
  a=norm(a);b=norm(b); if(!a||!b)return 0; if(a===b)return 1;
  if(a.includes(b)||b.includes(a))return Math.min(a.length,b.length)/Math.max(a.length,b.length)*0.95;
  return 1-lev(a,b)/Math.max(a.length,b.length);
}
function expandToken(w){return SPELL[w]||SYN[w]||w;}
function conceptTerms(p){return [p[0],...(p[1]||[]),p[2],p[3]].join(" ");}
function scoreTopics(q){
  const raw=String(q||""); const s=norm(raw); const ws=words(s); const expanded=ws.map(expandToken);
  const wanted=$("levelFilter")?.value||"All";
  return P.map(p=>{
    if(wanted!=="All"&&p[5]!==wanted)return {p,score:-1,matches:[],corrections:[]};
    const title=norm(p[0]), kws=(p[1]||[]).map(norm), desc=norm(p[3]);
    let score=0; const matches=new Set(); const corrections=[];
    if(title && s.includes(title)){score+=20;matches.add(p[0]);}
    kws.forEach(k=>{if(s.includes(k)){score+=10;matches.add(k);}});
    for(let i=0;i<ws.length;i++){
      const w=ws[i], e=expanded[i];
      if(SPELL[w]){corrections.push(`${w} → ${SPELL[w]}`);score+=4;}
      const candidates=[title,...kws];
      let best=0,bestTerm="";
      for(const c of candidates){const z=sim(w,c);if(z>best){best=z;bestTerm=c;}}
      if(best>=0.84 && w.length>=4){score+=7;matches.add(bestTerm);}
      if(e!==w){for(const c of candidates){const z=sim(e,c);if(z>=0.72){score+=5;matches.add(c);break;}}}
      if(desc.includes(w))score+=2;
      if(desc.includes(e)&&e!==w)score+=2;
    }
    // Multi-word semantic overlap: useful for descriptions rather than keywords only.
    const pws=new Set(words(conceptTerms(p)));
    const overlap=[...new Set(expanded)].filter(w=>pws.has(w)).length;
    score+=Math.min(overlap*1.5,9);
    return {p,score,matches:[...matches].slice(0,8),corrections:[...new Set(corrections)]};
  }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
}
function inferIntent(q){
  const s=norm(q);
  if(/\b(compare|difference|different|versus|vs)\b/.test(s))return "compare";
  if(/\b(calculate|calculate|find|compute|work out|solve|how much|value of)\b/.test(s))return "calculate";
  if(/\b(why|reason|cause)\b/.test(s))return "why";
  if(/\b(how|work|works|happen|process|mechanism)\b/.test(s))return "how";
  if(/\b(formula|equation|equations|law|relationship)\b/.test(s))return "formula";
  if(/\b(example|example of|give me an example|application|used for|use of)\b/.test(s))return "example";
  return "explain";
}
function buildOfflineAnswer(q,top){
  const p=top.p, intent=inferIntent(q), related=scoreTopics(q).slice(1,5).map(x=>x.p);
  let body;
  if(intent==="why") body=`Why it matters: ${p[3]} The relationship ${p[2]} is useful because it connects the measurable quantities involved.`;
  else if(intent==="how") body=`How it works: ${p[3]} Start with the model ${p[2]}, identify the quantities you know, keep the units consistent, and then test whether the observed behavior agrees with the model.`;
  else if(intent==="formula") body=`The main relationship is ${p[2]}. Use it only when its assumptions fit the situation; check the units of every quantity before calculating.`;
  else if(intent==="calculate") body=`For a numerical problem, the relevant relationship is ${p[2]}. Identify the known values and unknown, convert to compatible SI units, substitute carefully, and check whether the final unit makes physical sense. The Solver tab can perform supported calculations.`;
  else if(intent==="example") body=`Example/application: ${p[3]} A useful way to study it is to change one controllable variable, measure the response, repeat trials, and compare the pattern with ${p[2]}.`;
  else if(intent==="compare"&&related.length) body=`The closest related concept in the offline library is ${related[0][0]}. ${p[3]} Compared with ${related[0][0]}, the key distinction is that they use different physical quantities or assumptions; see both descriptions below.`;
  else body=p[3];
  const corr=top.corrections.length?`\n\nPossible spelling correction: ${top.corrections.join(", ")}.`:"";
  const rel=related.length?`\n\nRelated concepts I found: ${related.map(x=>x[0]).join(", ")}.`:"";
  return `I think you mean: ${p[0]} (${p[5]}).${corr}\n\nCurrent description:\n${p[3]}\n\nAnswer:\n${body}\n\nKey relationship:\n${p[2]}\n\nTypical SI/unit information: ${p[4]}.${rel}\n\nOffline reasoning note: I matched your wording against topic names, keywords, descriptions, synonyms and approximate spelling, then combined the closest physics concepts. If the interpretation is not what you meant, add one more detail and I will rematch it.`;
}
function answer(q){
  const scored=scoreTopics(q);
  if(!scored.length)return "I couldn't find a reliable offline match yet. Try describing the situation in ordinary words—for example, 'why does a ball slow down on grass?'—and I will search the offline physics concepts by meaning and approximate spelling. You can also use Research when online.";
  const top=scored[0];
  mem.t.push(...scored.slice(0,4).map(x=>x.p[0])); save();
  return buildOfflineAnswer(q,top);
}
function chat(){ const q=$("chatin").value.trim(); if(!q)return; msg(q,"user"); $("chatin").value=""; msg(answer(q),"bot"); }
$("send").onclick=chat; $("chatin").onkeydown=e=>{if(e.key==="Enter")chat()};
document.querySelectorAll("[data-q]").forEach(b=>b.onclick=()=>{$("chatin").value=b.dataset.q;chat()});
$("up").onclick=()=>{mem.h++;save();msg("Thanks! Helpful feedback was saved locally.","bot")};
$("down").onclick=()=>msg("Thanks. Try adding a short description of what you mean; the offline matcher can use similar words and approximate spelling.","bot");

// Online research: Wikimedia/Wikipedia plus curated scientific sources.
const SOURCES=[
  {name:"NIST Physics Reference",url:"https://physics.nist.gov/cuu/",desc:"SI units, physical constants and measurement uncertainty."},
  {name:"OpenStax University Physics",url:"https://openstax.org/details/books/university-physics-volume-1",desc:"Free university-level physics textbook covering mechanics, waves, thermodynamics, electromagnetism, optics and modern physics."},
  {name:"NASA Science",url:"https://science.nasa.gov/",desc:"Space, astrophysics, Earth and planetary science information."},
  {name:"Wikipedia Physics",url:"https://en.wikipedia.org/wiki/Physics",desc:"Broad reference articles for physics concepts and history."}
];
function sourceCards(){
  return `<h3>Scientific source library</h3>${SOURCES.map(s=>`<div class="card"><h3>${esc(s.name)}</h3><p>${esc(s.desc)}</p><a target="_blank" rel="noopener" href="${s.url}">Open source ↗</a></div>`).join("")}`;
}
async function research(){
  const q=$("rq").value.trim(); if(!q)return;
  $("results").innerHTML="<div class=box>Searching public physics sources…</div>"; $("status").textContent="● Online research";
  try{
    const url="https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch="+encodeURIComponent(q)+"&gsrlimit=8&prop=extracts|info&exintro=1&explaintext=1&inprop=url&format=json&origin=*";
    const r=await fetch(url); if(!r.ok)throw new Error("network"); const d=await r.json();
    const pages=Object.values(d.query?.pages||{}).sort((a,b)=>(a.index||0)-(b.index||0));
    const cards=pages.map(p=>`<div class="card"><h3>${esc(p.title||"")}</h3><p>${esc(p.extract||"No summary returned.")}</p><button class="secondary save" data-t="${esc(p.title||"")}" data-d="${esc(p.extract||"")}" data-u="${esc(p.fullurl||("https://en.wikipedia.org/wiki/"+encodeURIComponent((p.title||"").replace(/ /g,"_"))))}">Save to learning</button> <a target="_blank" rel="noopener" href="${esc(p.fullurl||"")}">Read source ↗</a></div>`).join("");
    $("results").innerHTML=(cards||"<div class=box>No Wikipedia results.</div>")+sourceCards();
    document.querySelectorAll(".save").forEach(b=>b.onclick=()=>{if(!mem.r.some(x=>x.t===b.dataset.t))mem.r.push({t:b.dataset.t,d:b.dataset.d,u:b.dataset.u});mem.t.push(b.dataset.t);save();b.textContent="✓ Saved"});
    mem.t.push(q); save(); $("status").textContent="● Online research ready";
  }catch(e){ $("results").innerHTML="<div class=box>Online search could not connect. Check the internet. Your offline physics library still works.</div>"+sourceCards(); $("status").textContent="● Offline core ready"; }
}
$("researchBtn").onclick=research; $("rq").onkeydown=e=>{if(e.key==="Enter")research()};
$("sourceLibrary").innerHTML=sourceCards();

// Solver
F.forEach((f,i)=>$("formula").add(new Option(f[0],i)));
function fin(){ const f=F[$("formula").value]; $("inputs").innerHTML=f[1].map(x=>`<label>${esc(x[1])}<input id="v${x[0]}" type="number" step="any"></label>`).join(""); }
$("formula").onchange=fin; fin();
$("solve").onclick=()=>{ const f=F[$("formula").value],v={}; let ok=true; f[1].forEach(x=>{v[x[0]]=Number($("v"+x[0]).value);if(!Number.isFinite(v[x[0]]))ok=false}); $("answer").innerHTML=ok?`<b>${esc(f[3])}</b><br>${Number(f[2](v).toFixed(10)).toLocaleString()}`:"Enter all values."; };

// Units
function units(){ const a=Object.keys(U[$("ctype").value]); $("cf").innerHTML=a.map(x=>`<option>${x}</option>`).join(""); $("ct").innerHTML=a.map(x=>`<option>${x}</option>`).join(""); }
$("ctype").onchange=units; units();
$("convert").onclick=()=>{ const ty=$("ctype").value,v=Number($("cv").value),a=$("cf").value,b=$("ct").value;if(!Number.isFinite(v))return $("cans").textContent="Enter a value.";let r;if(ty==="temperature"){let c=a==="C"?v:a==="K"?v-273.15:(v-32)*5/9;r=b==="C"?c:b==="K"?c+273.15:c*9/5+32}else r=v*U[ty][a]/U[ty][b];$("cans").innerHTML=`<b>${v} ${esc(a)} = ${Number(r.toFixed(10))} ${esc(b)}</b>`; };

// Library
function renderLibrary(){
  const raw=$("librarySearch").value.trim(), q=norm(raw), lv=$("libraryLevel").value;
  let rows=P.filter(p=>lv==="All"||p[5]===lv);
  if(q){
    rows=rows.map(p=>{
      let score=0; const title=norm(p[0]), text=norm(conceptTerms(p));
      if(text.includes(q)) score+=15;
      for(const w of words(q)){
        const e=expandToken(w);
        if(text.includes(w)||text.includes(e)) score+=5;
        const best=Math.max(sim(w,title),...((p[1]||[]).map(k=>sim(e,k))));
        if(best>=0.82) score+=4;
      }
      return {p,score};
    }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).map(x=>x.p);
  }
  rows=rows.slice(0,200);
  $("libraryCount").textContent=`Showing ${rows.length} of ${P.length} topics`;
  $("library").innerHTML=rows.map(p=>`<div class="card topic"><div><span class="pill">${esc(p[5])}</span><h3>${esc(p[0])}</h3><p>${esc(p[3])}</p></div><div><b>${esc(p[2])}</b><br><small>${esc(p[4])}</small></div></div>`).join("")||"<div class=box>No matching topics. Try a simpler description or a different spelling.</div>";
}
$("librarySearch").oninput=renderLibrary; $("libraryLevel").onchange=renderLibrary; renderLibrary();

// Project builder
const PROJECTS=[
 {keys:["pendulum","gravity","g"],title:"Investigate how pendulum length affects period",level:"Secondary",objective:"Determine how the period of a simple pendulum changes as its length changes.",question:"How does pendulum length affect the time for one oscillation?",hyp:"Increasing length increases period.",vars:["Independent: pendulum length L","Dependent: period T","Controls: release angle, bob, timing method, number of oscillations"],formula:"T = 2π√(L/g)",materials:["String","Small dense bob","Retort stand or secure support","Ruler/tape measure","Stopwatch or phone timer","Data sheet"],steps:["Set a small release angle and keep it the same for all trials.","Measure the pendulum length from pivot to the bob's center.","Time a fixed number of oscillations, preferably many cycles, and divide by that number to estimate T.","Repeat each length several times and calculate an average.","Repeat for several lengths."],analysis:"Plot T² against L. A roughly straight-line relationship supports the model T² = (4π²/g)L.",safety:"Use a secure support and a small release angle; keep the bob away from faces and fragile objects."},
 {keys:["spring","hooke","elastic"],title:"Test Hooke's law for a spring",level:"Secondary",objective:"Measure how extension changes with applied load within the elastic region.",question:"Is extension proportional to applied force for the chosen spring?",hyp:"A straight-line graph of force against extension indicates proportional behavior within the elastic limit.",vars:["Independent: applied force/load","Dependent: extension","Controls: same spring, reference length, measurement method"],formula:"F = kx",materials:["Spring","Masses or known loads","Stand and clamp","Ruler","Pointer or marker"],steps:["Measure the spring's unloaded length.","Add small loads one at a time.","Record the new length and calculate extension.","Repeat measurements and avoid stretching beyond the safe elastic region.","Calculate force from load mass and g."],analysis:"Plot force F against extension x. The gradient is the spring constant k in the linear region.",safety:"Use small loads and a secure stand; stop if the spring is permanently stretched or damaged."},
 {keys:["solar","panel","sun","photovoltaic","solar panel"],title:"Investigate solar-panel output versus light angle",level:"Secondary",objective:"Explore how the orientation of a small solar panel changes its electrical output.",question:"How does panel angle relative to a light source affect measured voltage or power?",hyp:"Output generally changes with the angle between the panel normal and incoming light, though real panels and light sources introduce other effects.",vars:["Independent: panel angle","Dependent: voltage, current or calculated power","Controls: light source distance/intensity, load, panel, measurement time"],formula:"P = VI",materials:["Small low-voltage solar panel","Multimeter if available","Small low-voltage load","Protractor","Ruler/stand"],steps:["Set up a stable light source or use outdoor sunlight without staring at the Sun.","Choose several panel angles.","Measure the same electrical quantity at each angle.","Repeat measurements and calculate averages.","Compare the pattern with the geometry of incident light."],analysis:"Graph output power or voltage against angle and identify the angle range giving the largest measured output under your conditions.",safety:"Use only low-voltage educational equipment; do not connect experimental wiring to mains electricity."},
 {keys:["friction","surface","rough","coefficient"],title:"Investigate friction on different surfaces",level:"Secondary",objective:"Compare frictional behavior for a block moving across different surfaces.",question:"How does surface type affect the force needed to start or maintain motion?",hyp:"Different surface materials produce different friction forces.",vars:["Independent: surface type","Dependent: measured pulling force","Controls: block mass, contact area where appropriate, pulling speed and method"],formula:"f ≈ μN",materials:["Small block","Spring balance or force sensor","Several safe surfaces","Masses if needed","Ruler"],steps:["Keep the block mass constant.","Place the block on one surface.","Measure the force needed to start motion and, if possible, the force during steady motion.","Repeat several trials.","Repeat for each surface."],analysis:"Compare average forces and, if normal force is known, estimate μ = f/N.",safety:"Keep loads small and work on a stable table."},
 {keys:["wave","string","frequency","wavelength"],title:"Investigate wave speed on a string",level:"Secondary",objective:"Explore the relationship between frequency, wavelength and wave speed.",question:"How are frequency, wavelength and wave speed related?",hyp:"For a given setup, v is approximately fλ.",vars:["Independent: frequency or tension, depending on equipment","Dependent: wavelength or wave speed","Controls: string type and length where appropriate"],formula:"v = fλ",materials:["String","Safe vibration source or manual driver","Meter ruler","Support points"],steps:["Set up a straight string with a secure support.","Create a repeatable wave pattern.","Measure wavelength and estimate frequency if possible.","Repeat under changed conditions.","Calculate wave speed from fλ."],analysis:"Compare calculated wave speed across trials and discuss sources of uncertainty such as identifying nodes and measuring wavelength.",safety:"Keep tension low and supports secure; avoid snapping or whipping the string."},
 {keys:["heat","water","temperature","cooling"],title:"Investigate heating or cooling",level:"Secondary",objective:"Measure temperature change over time under controlled conditions.",question:"How does temperature change with time for a chosen heating or cooling setup?",hyp:"Temperature changes rapidly at first and the rate changes as the system approaches its surroundings or a steady state.",vars:["Independent: time","Dependent: temperature","Controls: container, starting temperature, environment and measurement method"],formula:"Q = mcΔT",materials:["Container","Water","Thermometer","Stopwatch","Safe low-energy heat source or room-temperature cooling setup"],steps:["Measure the starting temperature.","Record temperature at regular time intervals.","Keep the setup consistent.","Repeat if possible.","Plot temperature against time."],analysis:"Describe the curve, calculate temperature changes, and discuss heat loss and measurement uncertainty.",safety:"Use warm—not dangerously hot—water and a suitable thermometer; avoid open flames and mains electrical heating in a student project."}
];
function projectMatch(q){
  const s=norm(q);
  return PROJECTS.map(p=>{
    let score=0;
    for(const k of p.keys){
      const nk=norm(k);
      if(s.includes(nk)) score+=8;
      for(const w of words(s)){
        const e=expandToken(w);
        const z=Math.max(sim(w,nk),sim(e,nk));
        if(z>=0.82) score+=4;
      }
    }
    return {p,score};
  }).sort((a,b)=>b.score-a.score)[0];
}
function buildProject(){
  const q=$("project").value.trim(); if(!q){$("projectOut").innerHTML="<div class=box>Describe the project you want to build.</div>";return;}
  const best=projectMatch(q); const scored=scoreTopics(q).slice(0,8);
  const concepts=scored.length?scored.map(x=>x.p):P.filter(p=>{
    const t=norm(conceptTerms(p));
    return words(q).some(w=>{const e=expandToken(w);return t.includes(w)||t.includes(e)||t.split(/\s+/).some(x=>sim(e,x)>=0.84);});
  }).slice(0,8);
  let plan=best.score?best.p:null;
  if(!plan){
    const primary=concepts[0]||P[0];
    plan={title:`${primary[0]} investigation project`,level:primary[5],objective:`Investigate a measurable relationship involving ${primary[0].toLowerCase()}.`,question:`How does a controllable variable affect ${primary[0].toLowerCase()}?`,hyp:`A measurable relationship should be observed and compared with the model ${primary[2]}.`,vars:["Independent: the variable you deliberately change","Dependent: the quantity you measure","Controls: quantities kept as constant as practical"],formula:primary[2],materials:["Ruler or measuring tool","Timer","Data sheet","Suitable low-energy apparatus or simulation"],steps:["Define the research question and choose one variable to change.","Choose a measurable response and keep important controls constant.","Make a safe setup and perform a pilot trial.","Collect repeated measurements across several values of the independent variable.","Calculate averages and record units.","Graph the data and compare it with the physics model."],analysis:"Use a graph that tests the expected relationship, calculate gradients or ratios where appropriate, and discuss uncertainty and limitations.",safety:"Use low-energy equipment or a simulation. Do not use mains electricity, flames, hazardous chemicals, dangerous pressure or other hazardous setups."};
  }
  const conceptHtml=concepts.map(p=>`<li><b>${esc(p[0])}</b> <span class="pill">${esc(p[5])}</span><br>${esc(p[3])}<br><small>Relationship: ${esc(p[2])}</small></li>`).join("");
  const materials=plan.materials.map(x=>`<li>${esc(x)}</li>`).join("");
  const steps=plan.steps.map((x,i)=>`<li><b>Step ${i+1}:</b> ${esc(x)}</li>`).join("");
  const vars=plan.vars.map(x=>`<li>${esc(x)}</li>`).join("");
  $("projectOut").innerHTML=`
  <div class="projectHeader"><h2>${esc(plan.title)}</h2><span class="pill">${esc(plan.level)}</span></div>
  <h3>1. Project overview</h3><p><b>Objective:</b> ${esc(plan.objective)}</p><p><b>Research question:</b> ${esc(plan.question)}</p><p><b>Hypothesis/prediction:</b> ${esc(plan.hyp)}</p>
  <h3>2. Physics knowledge used</h3><ul>${conceptHtml}</ul>
  <h3>3. Variables</h3><ul>${vars}</ul>
  <h3>4. Theory and equations</h3><div class="formulaBox"><b>${esc(plan.formula)}</b></div><p>Use consistent SI units where practical. State any assumptions before using the equation.</p>
  <h3>5. Materials and apparatus</h3><ul>${materials}</ul>
  <h3>6. Full method</h3><ol>${steps}</ol>
  <h3>7. Data collection</h3><div class="tableWrap"><table><tr><th>Trial</th><th>Independent variable</th><th>Measured value</th><th>Units</th><th>Notes</th></tr>${[1,2,3,4,5].map(i=>`<tr><td>${i}</td><td></td><td></td><td></td><td></td></tr>`).join("")}</table></div>
  <h3>8. Calculations</h3><p>Show one complete sample calculation with substituted values and units, then apply the same method to the remaining trials. Keep appropriate significant figures.</p>
  <h3>9. Graph and analysis</h3><p>${esc(plan.analysis)}</p><p>Label both axes with quantities and units, plot measured points clearly, and describe the trend rather than only saying it is “good” or “bad.”</p>
  <h3>10. Results</h3><p>State the main numerical pattern, compare it with the prediction, and mention whether the data support the chosen model within uncertainty.</p>
  <h3>11. Errors and uncertainty</h3><ul><li>Identify random variation and possible systematic effects.</li><li>Repeat measurements and use averages where appropriate.</li><li>Report measurement resolution and uncertainty when known.</li><li>Explain how uncertainty affects the conclusion.</li></ul>
  <h3>12. Conclusion</h3><p>Answer the research question directly, quote the main evidence, and connect the result to the physics relationship.</p>
  <h3>13. Improvements and extensions</h3><ul><li>Increase the number of trials or data points.</li><li>Use a more precise measuring instrument.</li><li>Test a wider but safe range of the independent variable.</li><li>Compare experimental results with a simulation or reference source.</li></ul>
  <h3>14. Safety</h3><p>${esc(plan.safety)}</p>`;
  mem.t.push(...concepts.map(p=>p[0])); save();
}
$("build").onclick=buildProject;

$("clear").onclick=()=>{mem={r:[],h:0,t:[]};save()};
ui();
msg("Hi! I'm Physics AI V3. I can use the expanded offline library, search public online sources, calculate formulas, and turn a project idea into a complete project plan.","bot");
