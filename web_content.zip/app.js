const shipments = JSON.parse(localStorage.getItem('col_shipments') || '[]');

function save(){localStorage.setItem('col_shipments', JSON.stringify(shipments)); updateStats();}
function updateStats(){
  document.getElementById('shipmentCount').textContent=shipments.length;
  document.getElementById('activeCount').textContent=shipments.filter(x=>x.status==='in_transit').length;
  document.getElementById('deliveredCount').textContent=shipments.filter(x=>x.status==='delivered').length;
}
function showPanel(type){
  const p=document.getElementById('panel'); p.classList.remove('hidden');
  const panels={
    shipment:`<h2>📦 نوی بار ثبتول</h2>
      <div class="field"><label>د مشتری نوم</label><input id="cname" placeholder="نوم"></div>
      <div class="field"><label>د مشتری موبایل</label><input id="phone" placeholder="07xxxxxxxxx"></div>
      <div class="field"><label>مقصد</label><input id="dest" placeholder="لکه کابل"></div>
      <div class="field"><label>وزن (ټن)</label><input id="weight" type="number" min="1" max="40" value="1"></div>
      <button class="primary" onclick="addShipment()">ثبتول</button>`,
    tracking:`<h2>🔎 بار تعقیب</h2><div class="field"><input id="track" placeholder="د بار شمېره لکه COL-2026-000001"></div><button class="primary" onclick="trackShipment()">لټون</button><div id="trackResult"></div>`,
    rate:`<h2>💰 د کرایې حساب</h2><div class="field"><label>نرخ په هر ټن (AFN)</label><input id="rateInput" type="number" value="1000"></div><div class="field"><label>وزن (ټن)</label><input id="weightInput" type="number" value="1"></div><button class="primary" onclick="calcRate()">حساب</button><p id="rateResult"></p>`,
    customers:`<h2>👥 مشتریان</h2><p>مشتریان د ثبت شوو بارونو له معلوماتو څخه ښودل کېږي.</p><div id="customerList"></div>`,
    receipt:`<h2>🧾 وروستی رسید</h2><p>وروستی ثبت شوی بار دلته ښکاري.</p><div id="receiptBox"></div><button class="primary" onclick="window.print()">چاپ</button>`,
    rates:`<h2>📋 د ولایتونو نرخونه</h2><p>د MVP نسخه کې نرخونه د مدیر له خوا وروسته د تنظیماتو له لارې بدلولای شو.</p>`,
    status:`<h2>🚚 د بار حالتونه</h2><p>Registered → In Transit → Delivered</p>`,
    settings:`<h2>⚙️ تنظیمات</h2><p>شرکت: ترانسپورتي او باربري افق لشکرگاه</p><p>ژبې: پښتو، دري، English</p><p>واحد: AFN</p>`
  };
  p.innerHTML=panels[type]||'';
  if(type==='customers') renderCustomers();
  if(type==='receipt') renderReceipt();
  p.scrollIntoView({behavior:'smooth'});
}
function addShipment(){
  const id='COL-2026-'+String(shipments.length+1).padStart(6,'0');
  shipments.push({id,name:document.getElementById('cname').value,phone:document.getElementById('phone').value,dest:document.getElementById('dest').value,weight:Number(document.getElementById('weight').value),status:'registered',created:new Date().toLocaleString()});
  save(); alert('بار ثبت شو: '+id); renderReceipt();
}
function trackShipment(){
  const id=document.getElementById('track').value.trim(); const s=shipments.find(x=>x.id===id);
  document.getElementById('trackResult').innerHTML=s?`<p><b>${s.id}</b><br>مقصد: ${s.dest}<br>وزن: ${s.weight} ټن<br>حالت: ${s.status}</p>`:'بار پیدا نه شو.';
}
function calcRate(){const r=Number(document.getElementById('rateInput').value),w=Number(document.getElementById('weightInput').value);document.getElementById('rateResult').textContent='ټوله کرایه: '+(r*w).toLocaleString()+' AFN';}
function renderCustomers(){const names=[...new Set(shipments.map(x=>x.name).filter(Boolean))];document.getElementById('customerList').innerHTML=names.length?names.map(n=>`<p>👤 ${n}</p>`).join(''):'تر اوسه مشتری نشته.'}
function renderReceipt(){const s=shipments[shipments.length-1];document.getElementById('receiptBox').innerHTML=s?`<p><b>${s.id}</b><br>مشتری: ${s.name}<br>موبایل: ${s.phone}<br>مقصد: ${s.dest}<br>وزن: ${s.weight} ټن<br>نېټه: ${s.created}</p>`:'تر اوسه بار نه دی ثبت شوی.'}
updateStats();
