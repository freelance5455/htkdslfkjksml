(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const pages = ["homePage","botsPage","runPage","savedPage","packagesPage","aboutPage"];
  let currentFile = null;
  let toastTimer = null;
  let bots = load("tbot_web_bots", []);
  let saved = load("tbot_web_saved", []);

  function load(key, fallback) {
    try { const v = JSON.parse(localStorage.getItem(key)); return Array.isArray(v) ? v : fallback; }
    catch (_) { return fallback; }
  }
  function persist() {
    try {
      localStorage.setItem("tbot_web_bots", JSON.stringify(bots));
      localStorage.setItem("tbot_web_saved", JSON.stringify(saved));
    } catch (_) { toast("Brauzer xotirasiga saqlab bo‘lmadi."); }
  }
  function toast(message) {
    const el = $("toast"); el.textContent = message; el.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
  }
  function showPage(id) {
    pages.forEach(p => $(p).classList.toggle("active", p === id));
    document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.page === id));
    if (id === "botsPage") renderBots();
    if (id === "savedPage") renderSaved();
    window.scrollTo({top:0, behavior:"smooth"});
  }
  document.querySelectorAll("[data-page]").forEach(btn => btn.addEventListener("click", () => showPage(btn.dataset.page)));
  $("aboutBtn").addEventListener("click", () => showPage("aboutPage"));
  $("addBotHome").addEventListener("click", openPicker);
  $("addBot").addEventListener("click", openPicker);
  $("addAnotherBtn").addEventListener("click", openPicker);
  $("filePicker").addEventListener("change", event => {
    const chosen = Array.from(event.target.files || []);
    if (!chosen.length) return;
    chosen.forEach(file => {
      const ext = file.name.split(".").pop().toLowerCase();
      if (!["py","zip"].includes(ext)) { toast("Faqat .py yoki .zip fayl tanlang."); return; }
      if (!bots.some(b => b.name === file.name && b.size === file.size)) {
        bots.push({id: makeId(), name:file.name, size:file.size, type:ext, added:new Date().toISOString()});
      }
    });
    persist(); renderBots(); toast("Fayl ro‘yxatga qo‘shildi."); event.target.value = "";
    showPage("botsPage");
  });
  function openPicker() { $("filePicker").click(); }
  function makeId() { return Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  function sizeText(n) { if (!n) return "Hajmi noma’lum"; return n < 1024 ? n+" B" : n < 1048576 ? (n/1024).toFixed(1)+" KB" : (n/1048576).toFixed(2)+" MB"; }
  function empty(text) { return `<div class="empty-state"><div class="empty-symbol">⌁</div>${text}</div>`; }
  function renderBots() {
    const list = $("botList");
    if (!bots.length) { list.innerHTML = empty("Bot fayllari yo‘q.<br>“Yangi bot tanlash” tugmasini bosing."); return; }
    list.innerHTML = bots.map(b => `<div class="file-card"><div class="file-icon">${b.type.toUpperCase()}</div><div class="file-info"><b>${escapeHtml(b.name)}</b><small>${sizeText(b.size)} · ${b.type === "py" ? "Python fayli" : "ZIP arxiv"}</small></div><button data-run="${b.id}">RUN OCHISH</button></div>`).join("");
    list.querySelectorAll("[data-run]").forEach(btn => btn.addEventListener("click", () => openRun(bots.find(b => b.id === btn.dataset.run))));
  }
  function openRun(bot) {
    if (!bot) return;
    currentFile = bot; $("runTitle").textContent = bot.name;
    $("terminalBody").innerHTML = `<p class="terminal-line"><span>$</span> ${escapeHtml(bot.name)}</p><p class="terminal-line">Fayl RUN oynasiga tanlandi.</p><p class="terminal-line">Muhit: HTML/JavaScript brauzer.</p><p class="terminal-line error">Python interpreter topilmadi — bu web sahifa Python kodini bajara olmaydi.</p>`;
    showPage("runPage");
  }
  $("runBtn").addEventListener("click", () => {
    addTerminal("ERROR: brauzer ichida Python botini ishga tushirib bo‘lmaydi. Asl Android ilovasidagi Python/Chaquopy bajaruvchisi kerak.", true);
    toast("RUN uchun asl Android/Python muhiti kerak.");
  });
  $("stopBtn").addEventListener("click", () => {
    addTerminal("STOP so‘rovi: web-versiyada ishga tushgan Python jarayoni mavjud emas.", true);
    toast("To‘xtatiladigan Python jarayoni yo‘q.");
  });
  function addTerminal(message, error) {
    const p = document.createElement("p"); p.className = "terminal-line" + (error ? " error" : "");
    p.textContent = message; $("terminalBody").appendChild(p);
  }
  $("saveRunBtn").addEventListener("click", () => {
    if (!currentFile) return toast("Avval bot faylini tanlang.");
    const entry = {id:currentFile.id, name:currentFile.name, size:currentFile.size, type:currentFile.type, savedAt:new Date().toISOString()};
    saved = [entry, ...saved.filter(s => s.id !== entry.id)]; persist(); toast("RUN oynasi SAVERUN ro‘yxatiga saqlandi.");
  });
  function renderSaved() {
    const list = $("savedList");
    if (!saved.length) { list.innerHTML = empty("Hali saqlangan RUN oynasi yo‘q.<br>Botni ochib SAVE tugmasini bosing."); return; }
    list.innerHTML = saved.map(s => `<div class="file-card"><div class="file-icon">${escapeHtml(s.type.toUpperCase())}</div><div class="file-info"><b>${escapeHtml(s.name)}</b><small>Saqlangan RUN yozuvi</small></div><button data-open="${s.id}">OCHISH</button><button data-delete="${s.id}" aria-label="O‘chirish">×</button></div>`).join("");
    list.querySelectorAll("[data-open]").forEach(btn => btn.addEventListener("click", () => {
      const s = saved.find(x => x.id === btn.dataset.open); if (!s) return;
      const original = bots.find(b => b.id === s.id);
      openRun(original || s);
    }));
    list.querySelectorAll("[data-delete]").forEach(btn => btn.addEventListener("click", () => {
      saved = saved.filter(s => s.id !== btn.dataset.delete); persist(); renderSaved(); toast("Saqlangan yozuv o‘chirildi.");
    }));
  }
  // A web page cannot install Python packages. Keep the original menu informational.
  renderBots();
  renderSaved();
})();