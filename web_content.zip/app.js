const display = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');

let currentInput = '0';
let isEvaluated = false;

// Web Audio API: Browser bina kisi audio file ke khud click sound generate karta hai
let audioCtx = null;
function playSound(frequency = 700, duration = 0.04) {
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.type = 'triangle'; // Smooth tick sound
    osc.frequency.setValueAtTime(frequency, audioCtx.currentTime);

    gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (err) {
    console.error("Audio error: ", err);
  }
}

function updateScreen() {
  display.textContent = currentInput;
}

function appendInput(val) {
  playSound(650, 0.03); // Button click sound

  const isOperator = ['+', '-', '*', '/', '%'].includes(val);

  if (isEvaluated && !isOperator) {
    currentInput = val === '.' ? '0.' : val;
    isEvaluated = false;
  } else {
    if (isEvaluated && isOperator) {
      isEvaluated = false;
    }

    if (currentInput === '0' && val !== '.') {
      currentInput = val;
    } else {
      const lastChar = currentInput.slice(-1);
      // Agar lagataar do operators dabayein toh pichla replace ho jaye
      if (isOperator && ['+', '-', '*', '/', '%'].includes(lastChar)) {
        currentInput = currentInput.slice(0, -1) + val;
      } else {
        currentInput += val;
      }
    }
  }
  updateScreen();
}

function clearDisplay() {
  playSound(450, 0.05); // Clear ke liye thoda deep sound
  currentInput = '0';
  isEvaluated = false;
  updateScreen();
}

function deleteLast() {
  playSound(520, 0.03);
  if (isEvaluated) {
    currentInput = '0';
    isEvaluated = false;
  } else {
    currentInput = currentInput.slice(0, -1);
    if (currentInput === '' || currentInput === '-') {
      currentInput = '0';
    }
  }
  updateScreen();
}

function calculateResult() {
  playSound(900, 0.06); // Result aane par chime sound
  try {
    const sanitized = currentInput.replace(/%/g, '/100');
    const result = Function('"use strict"; return (' + sanitized + ')')();

    if (!isFinite(result) || isNaN(result)) {
      currentInput = 'Error';
    } else {
      currentInput = String(Number(result.toFixed(8)));
    }
  } catch (e) {
    currentInput = 'Error';
  }
  isEvaluated = true;
  updateScreen();
}

// Button click events
buttons.forEach(button => {
  button.addEventListener('click', () => {
    const value = button.getAttribute('data-value');
    const action = button.getAttribute('data-action');

    if (value) {
      appendInput(value);
    } else if (action === 'clear') {
      clearDisplay();
    } else if (action === 'delete') {
      deleteLast();
    } else if (action === 'calculate') {
      calculateResult();
    }
  });
});

// Keyboard support
window.addEventListener('keydown', (e) => {
  if ((e.key >= '0' && e.key <= '9') || ['+', '-', '*', '/', '.', '%'].includes(e.key)) {
    appendInput(e.key);
  } else if (e.key === 'Enter' || e.key === '=') {
    e.preventDefault();
    calculateResult();
  } else if (e.key === 'Backspace') {
    deleteLast();
  } else if (e.key === 'Escape') {
    clearDisplay();
  }
});
