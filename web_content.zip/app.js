/* School Routine Manager
 * Offline-first routine planner. Data is stored in localStorage on this device.
 */
(() => {
  "use strict";

  const DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
  const STORAGE_KEY = "schoolRoutineManager.v1";
  const $ = (id) => document.getElementById(id);
  const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));

  const emptyState = () => ({ school: { name: "", year: "" }, periods: [] });
  let state = loadState();
  let selectedDay = "Monday";

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return emptyState();
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.periods)) return emptyState();
      return {
        school: {
          name: String(parsed.school?.name || ""),
          year: String(parsed.school?.year || "")
        },
        periods: parsed.periods.filter((p) => p && p.id && DAYS.includes(p.day))
      };
    } catch (error) {
      console.warn("Could not load saved routine:", error);
      return emptyState();
    }
  }

  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      render();
      return true;
    } catch (error) {
      alert("Could not save. Your browser storage may be full or disabled. Export a backup and try again.");
      console.error(error);
      return false;
    }
  }

  function timeToMinutes(time) {
    if (!/^\d{2}:\d{2}$/.test(time || "")) return -1;
    const [hours, minutes] = time.split(":").map(Number);
    return hours * 60 + minutes;
  }

  function sortedPeriods(day) {
    return state.periods
      .filter((p) => p.day === day)
      .sort((a, b) => timeToMinutes(a.start) - timeToMinutes(b.start));
  }

  function renderTabs() {
    $("dayTabs").innerHTML = DAYS.map((day) =>
      `<button class="tab ${day === selectedDay ? "active" : ""}" data-day="${day}" aria-pressed="${day === selectedDay}">${day.slice(0, 3)}</button>`
    ).join("");
    $("dayTabs").querySelectorAll("[data-day]").forEach((button) => {
      button.addEventListener("click", () => {
        selectedDay = button.dataset.day;
        render();
      });
    });
  }

  function renderRoutine() {
    $("selectedDayTitle").textContent = selectedDay;
    const periods = sortedPeriods(selectedDay);
    $("daySummary").textContent = `${periods.length} period${periods.length === 1 ? "" : "s"} planned`;
    const container = $("routineList");

    if (!periods.length) {
      container.innerHTML = `<div class="empty">No periods added for ${escapeHTML(selectedDay)} yet.<br>Tap “Add period” to build your timetable.</div>`;
      return;
    }

    container.innerHTML = periods.map((p) => {
      const typeLabel = p.type === "break" ? "Break / assembly" : p.type === "meeting" ? "Meeting / other" : "Lesson";
      const details = [p.teacher, p.room ? `Room: ${p.room}` : "", p.notes].filter(Boolean).map(escapeHTML).join(" · ");
      return `<article class="period ${p.type === "break" ? "break" : ""}">
        <div class="time">${escapeHTML(p.start)}<br><span style="color:#8b98aa;font-weight:500">to</span><br>${escapeHTML(p.end)}</div>
        <div><div class="subject">${escapeHTML(p.subject)}</div><div class="meta">${escapeHTML(p.className)} · ${typeLabel}</div>${details ? `<div class="meta">${details}</div>` : ""}</div>
        <div class="actions"><button class="secondary" data-edit="${escapeHTML(p.id)}" aria-label="Edit ${escapeHTML(p.subject)}">Edit</button><button class="secondary danger" data-delete="${escapeHTML(p.id)}" aria-label="Delete ${escapeHTML(p.subject)}">Delete</button></div>
      </article>`;
    }).join("");

    container.querySelectorAll("[data-edit]").forEach((button) =>
      button.addEventListener("click", () => openPeriodDialog(button.dataset.edit)));
    container.querySelectorAll("[data-delete]").forEach((button) =>
      button.addEventListener("click", () => deletePeriod(button.dataset.delete)));
  }

  function renderStats() {
    $("statPeriods").textContent = state.periods.length;
    $("statClasses").textContent = new Set(state.periods.map((p) => p.className.trim()).filter(Boolean)).size;
    $("statSubjects").textContent = new Set(state.periods.map((p) => p.subject.trim().toLowerCase()).filter(Boolean)).size;
  }

  function renderSchool() {
    const { name, year } = state.school;
    $("schoolDetails").textContent = name || year
      ? `${name || "School name not set"}${year ? ` · Academic year ${year}` : ""}`
      : "Add your school name and academic year to personalise the routine.";
  }

  function render() {
    renderTabs();
    renderRoutine();
    renderStats();
    renderSchool();
  }

  function populateDaySelect() {
    $("periodDay").innerHTML = DAYS.map((day) =>
      `<option value="${day}">${day}</option>`
    ).join("");
  }

  function openPeriodDialog(id = "") {
    $("periodForm").reset();
    $("periodId").value = "";
    $("periodDialogTitle").textContent = id ? "Edit period" : "Add a period";
    $("formMessage").textContent = "";
    const period = state.periods.find((p) => p.id === id);
    if (period) {
      $("periodId").value = period.id;
      $("periodDay").value = period.day;
      $("periodClass").value = period.className;
      $("periodSubject").value = period.subject;
      $("periodTeacher").value = period.teacher || "";
      $("periodStart").value = period.start;
      $("periodEnd").value = period.end;
      $("periodRoom").value = period.room || "";
      $("periodType").value = period.type || "lesson";
      $("periodNotes").value = period.notes || "";
    } else {
      $("periodDay").value = selectedDay;
      $("periodStart").value = "09:00";
      $("periodEnd").value = "09:40";
    }
    $("periodDialog").showModal();
  }

  function closePeriodDialog() {
    $("periodDialog").close();
  }

  function overlaps(day, start, end, ignoreId = "") {
    const startMin = timeToMinutes(start);
    const endMin = timeToMinutes(end);
    return state.periods.find((p) => {
      if (p.day !== day || p.id === ignoreId) return false;
      return startMin < timeToMinutes(p.end) && endMin > timeToMinutes(p.start);
    });
  }

  function handlePeriodSubmit(event) {
    event.preventDefault();
    const id = $("periodId").value || (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
    const period = {
      id,
      day: $("periodDay").value,
      className: $("periodClass").value.trim(),
      subject: $("periodSubject").value.trim(),
      teacher: $("periodTeacher").value.trim(),
      start: $("periodStart").value,
      end: $("periodEnd").value,
      room: $("periodRoom").value.trim(),
      type: $("periodType").value,
      notes: $("periodNotes").value.trim()
    };

    if (!period.className || !period.subject || !period.start || !period.end) {
      $("formMessage").textContent = "Please fill in class, subject, start time and end time.";
      return;
    }
    if (timeToMinutes(period.end) <= timeToMinutes(period.start)) {
      $("formMessage").textContent = "End time must be later than start time.";
      return;
    }
    const conflict = overlaps(period.day, period.start, period.end, $("periodId").value);
    if (conflict) {
      $("formMessage").textContent = `Time conflict: overlaps with ${conflict.subject} (${conflict.start}–${conflict.end}) on ${period.day}.`;
      return;
    }

    const existingIndex = state.periods.findIndex((p) => p.id === id);
    if (existingIndex >= 0) state.periods[existingIndex] = period;
    else state.periods.push(period);

    selectedDay = period.day;
    if (saveState()) closePeriodDialog();
  }

  function deletePeriod(id) {
    const period = state.periods.find((p) => p.id === id);
    if (!period) return;
    if (!confirm(`Delete "${period.subject}" for ${period.className} on ${period.day}?`)) return;
    state.periods = state.periods.filter((p) => p.id !== id);
    saveState();
  }

  function openSchoolDialog() {
    $("schoolName").value = state.school.name;
    $("academicYear").value = state.school.year;
    $("schoolDialog").showModal();
  }

  function exportCSV() {
    const rows = [["Day", "Start", "End", "Class / Section", "Subject", "Teacher", "Room", "Type", "Notes"]];
    const periods = sortedPeriods(selectedDay);
    periods.forEach((p) => rows.push([p.day, p.start, p.end, p.className, p.subject, p.teacher, p.room, p.type, p.notes]));
    const csv = rows.map((row) => row.map((value) => `"${String(value ?? "").replace(/"/g, '""')}"`).join(",")).join("\r\n");
    downloadBlob(csv, `routine-${selectedDay.toLowerCase()}.csv`, "text/csv;charset=utf-8;");
  }

  function downloadBlob(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  }

  function backupJSON() {
    downloadBlob(JSON.stringify(state, null, 2), "school-routine-backup.json", "application/json");
  }

  function restoreJSON(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        if (!parsed || !Array.isArray(parsed.periods)) throw new Error("Invalid backup format");
        const restored = {
          school: { name: String(parsed.school?.name || ""), year: String(parsed.school?.year || "") },
          periods: parsed.periods.map((p) => {
            if (!DAYS.includes(p.day) || !p.start || !p.end || !p.subject || !p.className) {
              throw new Error("Backup contains an invalid period");
            }
            return {
              id: String(p.id || `${Date.now()}-${Math.random()}`),
              day: p.day, start: String(p.start), end: String(p.end),
              className: String(p.className), subject: String(p.subject),
              teacher: String(p.teacher || ""), room: String(p.room || ""),
              type: ["lesson", "break", "meeting"].includes(p.type) ? p.type : "lesson",
              notes: String(p.notes || "")
            };
          })
        };
        state = restored;
        if (saveState()) alert("Routine backup imported successfully.");
      } catch (error) {
        alert(`Could not import backup: ${error.message}`);
      }
      $("restoreFile").value = "";
    };
    reader.readAsText(file);
  }

  $("addBtn").addEventListener("click", () => openPeriodDialog());
  $("closePeriod").addEventListener("click", closePeriodDialog);
  $("cancelPeriod").addEventListener("click", closePeriodDialog);
  $("periodForm").addEventListener("submit", handlePeriodSubmit);
  $("editSchoolBtn").addEventListener("click", openSchoolDialog);
  $("closeSchool").addEventListener("click", () => $("schoolDialog").close());
  $("cancelSchool").addEventListener("click", () => $("schoolDialog").close());
  $("schoolForm").addEventListener("submit", (event) => {
    event.preventDefault();
    state.school.name = $("schoolName").value.trim();
    state.school.year = $("academicYear").value.trim();
    if (saveState()) $("schoolDialog").close();
  });
  $("exportBtn").addEventListener("click", exportCSV);
  $("backupBtn").addEventListener("click", backupJSON);
  $("restoreBtn").addEventListener("click", () => $("restoreFile").click());
  $("restoreFile").addEventListener("change", (event) => {
    const file = event.target.files?.[0];
    if (file) restoreJSON(file);
  });
  $("clearBtn").addEventListener("click", () => {
    if (!state.periods.length) return alert("There are no periods to clear.");
    if (!confirm("Delete all periods? School details will be kept. Export a backup first if needed.")) return;
    state.periods = [];
    saveState();
  });

  populateDaySelect();
  render();
})();
