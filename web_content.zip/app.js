/**
 * LENNIX X7 - version web (v1.4.4)
 * Solo muestra datos que el navegador expone de verdad. Lo demas se marca como no disponible.
 */
const LennixApp = {
    state: { page: 'page-dashboard', modalOpen: false, modalCallback: null, liveTimer: null },
    el: {},
    battery: null,

    init() {
        const $ = id => document.getElementById(id);
        this.el = {
            back: $('btn-back'), live: $('live-toggle'), ping: $('btn-ping'),
            modal: $('lennix-modal'), mTitle: $('modal-title'), mMsg: $('modal-message'), mClose: $('modal-close'),
            pages: document.querySelectorAll('.page'),
            navs: document.querySelectorAll('[data-nav]'),
            acts: document.querySelectorAll('[data-action]')
        };
        this.bind();
        history.replaceState({ page: 'page-dashboard' }, '');
        this.initBattery().then(() => this.refreshMetrics());
        this.refreshMetrics();
    },

    bind() {
        this.el.back.addEventListener('click', () => this.back());
        this.el.mClose.addEventListener('click', () => this.closeModal(true));
        this.el.ping.addEventListener('click', () => this.measurePing());
        this.el.live.addEventListener('change', () => this.updateLive());
        document.addEventListener('visibilitychange', () => this.updateLive());

        const activate = (node, fn) => {
            node.addEventListener('click', fn);
            node.addEventListener('keydown', e => {
                if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fn(); }
            });
        };
        this.el.navs.forEach(n => activate(n, () => this.navigate(n.getAttribute('data-nav'))));
        this.el.acts.forEach(n => activate(n, () => this.action(n.getAttribute('data-action'))));

        window.addEventListener('popstate', e => {
            if (this.state.modalOpen) { this.closeModal(false); return; }
            if (e.state && e.state.modal) return;
            this.show(e.state && e.state.page ? e.state.page : 'page-dashboard');
        });
    },

    navigate(page) {
        if (this.state.page === page) return;
        history.pushState({ page }, '');
        this.show(page);
    },

    show(page) {
        this.el.pages.forEach(p => p.classList.toggle('active', p.id === page));
        this.state.page = page;
        this.el.back.classList.toggle('visible', page !== 'page-dashboard');
        if (page === 'page-monitor') this.refreshMetrics();
        this.updateLive();
    },

    back() {
        if (this.state.modalOpen) this.closeModal(true);
        else if (this.state.page !== 'page-dashboard') history.back();
    },

    action(name) {
        if (name === 'native') {
            this.showModal('App nativa',
                'La app instalable (Kotlin) incluye:\n' +
                '- Panel flotante sobre tus juegos\n' +
                '- Deteccion automatica de juegos\n' +
                '- Historial de sesiones\n' +
                '- Temperatura de bateria y estado termico\n' +
                '- Perfiles con brillo y No molestar (reversibles)\n' +
                '- Limpieza de miniaturas con confirmacion\n\n' +
                'No usa root ni promete FPS que no se puedan medir.');
        } else if (name === 'info') {
            this.showModal('Acerca de', 'LENNIX X7 v1.4.4 (version web).\nSolo lectura: muestra lo que tu navegador permite y marca el resto como no disponible.');
        }
    },

    /* ---------- Metricas ---------- */
    async initBattery() {
        if (!navigator.getBattery) return;
        try {
            this.battery = await navigator.getBattery();
            this.battery.addEventListener('levelchange', () => this.refreshMetrics());
            this.battery.addEventListener('chargingchange', () => this.refreshMetrics());
        } catch (e) { /* no disponible */ }
    },

    refreshMetrics() {
        const set = (id, v) => { const n = document.getElementById(id); if (n) n.textContent = v; };
        const b = this.battery;
        set('m-bat', b ? Math.round(b.level * 100) + '%' + (b.charging ? ' (carga)' : '') : 'No disponible');
        set('m-ram', navigator.deviceMemory ? '~' + navigator.deviceMemory + ' GB' : 'No disponible');
        set('m-cpu', navigator.hardwareConcurrency ? String(navigator.hardwareConcurrency) : 'No disponible');
        set('m-scr', screen.width + 'x' + screen.height);
        const c = navigator.connection;
        set('m-net', c && c.effectiveType ? c.effectiveType.toUpperCase() : (navigator.onLine ? 'En linea' : 'Sin red'));
    },

    updateLive() {
        const want = this.el.live.checked && this.state.page === 'page-monitor' && !document.hidden;
        if (want && !this.state.liveTimer) {
            this.state.liveTimer = setInterval(() => this.refreshMetrics(), 5000);
        } else if (!want && this.state.liveTimer) {
            clearInterval(this.state.liveTimer);
            this.state.liveTimer = null;
        }
    },

    async measurePing() {
        const out = document.getElementById('m-ping');
        out.textContent = '...';
        const ctl = new AbortController();
        const timeout = setTimeout(() => ctl.abort(), 4000);
        const start = performance.now();
        try {
            await fetch('https://www.gstatic.com/generate_204?' + Date.now(),
                { mode: 'no-cors', cache: 'no-store', signal: ctl.signal });
            out.textContent = Math.round(performance.now() - start) + ' ms';
        } catch (e) {
            out.textContent = 'No disponible';
        } finally {
            clearTimeout(timeout);
        }
    },

    /* ---------- Modal ---------- */
    showModal(title, message, callback) {
        this.el.mTitle.textContent = title;
        this.el.mMsg.textContent = message;
        this.state.modalCallback = typeof callback === 'function' ? callback : null;
        if (!this.state.modalOpen) {
            this.state.modalOpen = true;
            history.pushState({ modal: true }, '');
            this.el.modal.classList.add('active');
            this.el.mClose.focus();
        }
    },

    closeModal(fromUi) {
        if (!this.state.modalOpen) return;
        this.state.modalOpen = false;
        this.el.modal.classList.remove('active');
        const cb = this.state.modalCallback;
        this.state.modalCallback = null;
        if (cb) { try { cb(); } catch (e) { console.error(e); } }
        if (fromUi) history.back();
    }
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => LennixApp.init());
} else {
    LennixApp.init();
}
