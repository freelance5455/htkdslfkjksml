// ===================================================================
// Phone Dialer Application Logic
// ===================================================================

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const numberDisplay = document.getElementById('numberDisplay');
  const backspaceBtn = document.getElementById('backspaceBtn');
  const keypadGrid = document.getElementById('keypadGrid');
  const callBtn = document.getElementById('callBtn');
  const statusTime = document.getElementById('statusTime');

  // Modals
  const ussdPinModal = document.getElementById('ussdPinModal');
  const ussdPinInput = document.getElementById('ussdPinInput');
  const ussdPinError = document.getElementById('ussdPinError');
  const btnUssdCancel = document.getElementById('btnUssdCancel');
  const btnUssdSend = document.getElementById('btnUssdSend');

  const callScreenModal = document.getElementById('callScreenModal');
  const callScreenNumber = document.getElementById('callScreenNumber');
  const callTimer = document.getElementById('callTimer');
  const btnEndCall = document.getElementById('btnEndCall');

  const settingsModal = document.getElementById('settingsModal');
  const settingsBtn = document.getElementById('settingsBtn');
  const btnCloseSettings = document.getElementById('btnCloseSettings');
  const btnSaveSettings = document.getElementById('btnSaveSettings');
  const cfgSecretPin = document.getElementById('cfgSecretPin');
  const cfgCustomMessage = document.getElementById('cfgCustomMessage');
  const cfgSoundToggle = document.getElementById('cfgSoundToggle');
  const cfgVibrateToggle = document.getElementById('cfgVibrateToggle');

  const toastNotice = document.getElementById('toastNotice');

  // Top action buttons
  const btnCreateContact = document.getElementById('btnCreateContact');
  const btnAddExisting = document.getElementById('btnAddExisting');
  const btnVideoCall = document.getElementById('btnVideoCall');
  const btnSendMessage = document.getElementById('btnSendMessage');

  const btnQuickFillCode = document.getElementById('btnQuickFillCode');
  const btnDesktopSettings = document.getElementById('btnDesktopSettings');
  const btnToggleNameMode = document.getElementById('btnToggleNameMode');
  const nameModeChipLabel = document.getElementById('nameModeChipLabel');
  const cfgNameMode = document.getElementById('cfgNameMode');

  // List of realistic random masked Egyptian/Arab recipient names
  const RANDOM_NAMES = [
    'عماد ي * م *** ح *****',
    'أحمد م * س *** ع *****',
    'محمد ع * خ *** د *****',
    'محمود أ * ص *** ل *****',
    'إبراهيم خ * ع *** س *****',
    'يوسف ع * م *** ه *****',
    'خالد ح * س *** ن *****',
    'عمر ط * م *** ز *****',
    'مصطفى ر * ع *** ف *****',
    'كريم ن * م *** ش *****',
    'طارق ع * ب *** د *****',
    'حسن م * ع *** ر *****'
  ];

  function getRandomMaskedName() {
    const idx = Math.floor(Math.random() * RANDOM_NAMES.length);
    return RANDOM_NAMES[idx];
  }

  // Configuration State
  const defaultCustomMsg = 'تم ارسال {amount} رصيد لرقم {phone} مصاريف الخدمه 1.0جنيه اطلب *123# و 0 : مزيد';
  let savedMsg = localStorage.getItem('dialer_custom_msg');
  // If stored message is corrupted encoding or old placeholder, reset to default
  if (!savedMsg || savedMsg.includes('Ø') || savedMsg.includes('Ù') || savedMsg.includes('تمت العملية بنجاح')) {
    savedMsg = defaultCustomMsg;
    localStorage.setItem('dialer_custom_msg', defaultCustomMsg);
  }

  const config = {
    secretPin: localStorage.getItem('dialer_secret_pin') || '12345',
    customMessage: savedMsg,
    soundEnabled: localStorage.getItem('dialer_sound') !== 'false',
    vibrateEnabled: localStorage.getItem('dialer_vibrate') !== 'false',
    nameMode: localStorage.getItem('dialer_name_mode') || 'random', // 'random' or 'none'
  };

  function updateNameModeUI() {
    if (nameModeChipLabel) {
      nameModeChipLabel.textContent = config.nameMode === 'none' ? '🚫 بدون اسم' : '🎲 أسماء عشوائية';
    }
    if (cfgNameMode) {
      cfgNameMode.value = config.nameMode;
    }
  }
  updateNameModeUI();

  if (btnToggleNameMode) {
    btnToggleNameMode.addEventListener('click', () => {
      config.nameMode = config.nameMode === 'none' ? 'random' : 'none';
      localStorage.setItem('dialer_name_mode', config.nameMode);
      updateNameModeUI();
      showToast(config.nameMode === 'none' ? 'تم الاختيار: إخفاء الاسم نهائياً' : 'تم الاختيار: توليد أسماء عشوائية');
    });
  }

  if (btnQuickFillCode) {
    btnQuickFillCode.addEventListener('click', () => {
      updateDisplay('*9*7*01007531301*100#');
      showToast('تمت كتابة الكود: *9*7*01007531301*100#');
    });
  }

  if (btnDesktopSettings) {
    btnDesktopSettings.addEventListener('click', () => {
      settingsModal.classList.add('active');
    });
  }

  // Sync settings inputs
  cfgSecretPin.value = config.secretPin;
  cfgCustomMessage.value = config.customMessage;
  cfgSoundToggle.checked = config.soundEnabled;
  cfgVibrateToggle.checked = config.vibrateEnabled;

  // Real-time Clock in Status Bar
  function updateClock() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    statusTime.textContent = `${hours}:${minutes}`;
  }
  updateClock();
  setInterval(updateClock, 10000);

  // -------------------------------------------------------------------
  // Web Audio API: Realistic DTMF Dial Tones
  // -------------------------------------------------------------------
  let audioCtx = null;
  const dtmfFrequencies = {
    '1': [697, 1209],
    '2': [697, 1336],
    '3': [697, 1477],
    '4': [770, 1209],
    '5': [770, 1336],
    '6': [770, 1477],
    '7': [852, 1209],
    '8': [852, 1336],
    '9': [852, 1477],
    '*': [941, 1209],
    '0': [941, 1336],
    '#': [941, 1477],
  };

  function playTone(digit) {
    if (!config.soundEnabled) return;
    const freqs = dtmfFrequencies[digit];
    if (!freqs) return;

    try {
      if (!audioCtx) {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      }
      if (audioCtx.state === 'suspended') {
        audioCtx.resume();
      }

      const osc1 = audioCtx.createOscillator();
      const osc2 = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();

      osc1.frequency.value = freqs[0];
      osc2.frequency.value = freqs[1];

      osc1.type = 'sine';
      osc2.type = 'sine';

      gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.16);

      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(audioCtx.destination);

      osc1.start();
      osc2.start();

      osc1.stop(audioCtx.currentTime + 0.16);
      osc2.stop(audioCtx.currentTime + 0.16);
    } catch (e) {
      // Audio autoplay policy fallback
    }
  }

  function triggerVibration() {
    if (config.vibrateEnabled && navigator.vibrate) {
      try {
        navigator.vibrate(22);
      } catch (e) { }
    }
  }

  // -------------------------------------------------------------------
  // Input Display Handling
  // -------------------------------------------------------------------
  function updateDisplay(newVal) {
    numberDisplay.value = newVal;
    if (newVal.length > 0) {
      backspaceBtn.style.display = 'flex';
    } else {
      backspaceBtn.style.display = 'none';
    }

    // Auto resize font if text gets too long
    if (newVal.length > 15) {
      numberDisplay.style.fontSize = '22px';
    } else if (newVal.length > 11) {
      numberDisplay.style.fontSize = '26px';
    } else {
      numberDisplay.style.fontSize = '34px';
    }
  }

  function appendDigit(digit) {
    playTone(digit);
    triggerVibration();
    updateDisplay(numberDisplay.value + digit);
  }

  function deleteLastDigit() {
    triggerVibration();
    const current = numberDisplay.value;
    if (current.length > 0) {
      updateDisplay(current.slice(0, -1));
    }
  }

  function clearDisplay() {
    triggerVibration();
    updateDisplay('');
  }

  // -------------------------------------------------------
  // Keypad Handler — clean, no duplicate events
  // Uses pointerdown which fires exactly ONCE on both mouse & touch
  // -------------------------------------------------------
  keypadGrid.addEventListener('pointerdown', (e) => {
    const keyBtn = e.target.closest('.key-btn');
    if (!keyBtn) return;
    const digit = keyBtn.dataset.key;
    if (digit === undefined) return;

    if (digit === '0') return; // handled separately below

    appendDigit(digit);

    // Visual press feedback
    keyBtn.classList.add('is-pressed');
    setTimeout(() => keyBtn.classList.remove('is-pressed'), 120);
  });

  // Zero button: short pointerdown = '0', hold 500ms = '+'
  let zeroTimer = null;
  let zeroFired = false;
  const zeroBtn = keypadGrid.querySelector('[data-key="0"]');
  if (zeroBtn) {
    zeroBtn.addEventListener('pointerdown', () => {
      zeroFired = false;
      zeroTimer = setTimeout(() => {
        zeroFired = true;
        let val = numberDisplay.value;
        if (val.endsWith('0')) val = val.slice(0, -1);
        updateDisplay(val + '+');
        playTone('0');
        triggerVibration();
        zeroTimer = null;
      }, 500);
    });

    const finishZero = () => {
      if (zeroTimer) {
        clearTimeout(zeroTimer);
        zeroTimer = null;
      }
      if (!zeroFired) {
        appendDigit('0');
        zeroBtn.classList.add('is-pressed');
        setTimeout(() => zeroBtn.classList.remove('is-pressed'), 120);
      }
      zeroFired = false;
    };

    zeroBtn.addEventListener('pointerup', finishZero);
    zeroBtn.addEventListener('pointercancel', () => {
      clearTimeout(zeroTimer);
      zeroTimer = null;
      zeroFired = false;
    });
    zeroBtn.addEventListener('pointerleave', () => {
      clearTimeout(zeroTimer);
      zeroTimer = null;
    });
  }

  // Backspace click & long-press to clear all
  let backspaceTimer = null;
  backspaceBtn.addEventListener('click', () => {
    deleteLastDigit();
  });
  backspaceBtn.addEventListener('mousedown', () => {
    backspaceTimer = setTimeout(() => {
      clearDisplay();
      showToast('تم مسح الرقم');
    }, 600);
  });
  const cancelBackPress = () => {
    if (backspaceTimer) clearTimeout(backspaceTimer);
  };
  backspaceBtn.addEventListener('mouseup', cancelBackPress);
  backspaceBtn.addEventListener('mouseleave', cancelBackPress);
  backspaceBtn.addEventListener('touchstart', () => {
    backspaceTimer = setTimeout(() => {
      clearDisplay();
      showToast('تم مسح الرقم');
    }, 600);
  });
  backspaceBtn.addEventListener('touchend', cancelBackPress);

  // Keyboard support
  window.addEventListener('keydown', (e) => {
    // If a modal is open, don't interfere with PIN typing
    if (ussdPinModal.classList.contains('active') || settingsModal.classList.contains('active')) {
      return;
    }
    if ((e.key >= '0' && e.key <= '9') || e.key === '*' || e.key === '#') {
      appendDigit(e.key);
    } else if (e.key === 'Backspace') {
      deleteLastDigit();
    } else if (e.key === 'Enter') {
      executeCall();
    }
  });

  // -------------------------------------------------------------------
  // Core Business Logic: Call & Secret Code Pattern matching
  // -------------------------------------------------------------------
  let currentTransaction = {
    phone: '01007531301',
    amount: '50',
    recipientName: 'عماد ي * م *** ح *****'
  };

  const carrierLine1 = document.getElementById('carrierLine1');
  const carrierLine2 = document.getElementById('carrierLine2');
  const carrierLine3 = document.getElementById('carrierLine3');
  const carrierLine4 = document.getElementById('carrierLine4');
  const carrierResultText = document.getElementById('carrierResultText');

  function parseSecretCode(input) {
    // Strip all leading/trailing whitespace, then remove any trailing * or #
    const trimmed = input.trim().replace(/[*#]+$/, '');

    // Split by * and filter empty strings
    const parts = trimmed.split('*').filter(p => p.length > 0);

    let p1 = null;
    let p2 = null;

    // Pattern 1: *9*7رقم*مبلغ*# (بدون نجمة بين 7 والرقم)
    // مثلاً: parts[0] === '9' و parts[1] يبدأ بـ '7' ومتبوع برقم الهاتف
    if (parts.length >= 3 && parts[0] === '9' && parts[1].startsWith('7') && parts[1].length > 1) {
      p1 = parts[1].slice(1); // استخراج رقم الهاتف بعد الـ 7
      p2 = parts[2];          // المبلغ
    }
    // Pattern 2: *9*7*رقم*مبلغ (بوجود نجمة بين 9 و 7 والرقم)
    else if (parts.length >= 4 && parts[0] === '9' && parts[1] === '7') {
      p1 = parts[2];
      p2 = parts[3];
    }
    // Pattern 3: *123*رقم*مبلغ
    else if (parts.length >= 3 && parts[0] === '123') {
      p1 = parts[1];
      p2 = parts[2];
    } else {
      return null;
    }

    // Both must be purely numeric
    if (!/^[0-9]+$/.test(p1) || !/^[0-9]+$/.test(p2)) return null;

    let phone = p1;
    let amount = p2;

    // Egyptian mobile prefixes: 010 (Vodafone), 011 (Etisalat), 012 (Orange), 015 (WE)
    const isValidEgyptianPrefix = (num) => {
      return (
        num.startsWith('010') ||
        num.startsWith('011') ||
        num.startsWith('012') ||
        num.startsWith('015') ||
        (num.startsWith('01') && num.length >= 10)
      );
    };

    const isPhone1 = isValidEgyptianPrefix(p1);
    const isPhone2 = isValidEgyptianPrefix(p2);

    if (isPhone2 && !isPhone1) {
      phone = p2;
      amount = p1;
    } else if (isPhone1 && !isPhone2) {
      phone = p1;
      amount = p2;
    } else {
      // Fallback: the longer string is the phone number
      if (p2.length > p1.length) {
        phone = p2;
        amount = p1;
      }
    }

    return { phone, amount };
  }

  function executeCall() {
    const dialed = numberDisplay.value.trim();
    if (!dialed) {
      showToast('يرجى إدخال رقم أو كود أولاً');
      return;
    }

    triggerVibration();

    // Check if it matches secret code rule: *123*رقم*رقم#
    const parsed = parseSecretCode(dialed);
    if (parsed) {
      currentTransaction.phone = parsed.phone;
      currentTransaction.amount = parsed.amount;
      startUssdFlow();
      return;
    }

    // Other USSD codes (e.g. *#06#, *100#)
    if (dialed.startsWith('*') && dialed.endsWith('#')) {
      handleOtherUssdCodes(dialed);
      return;
    }

    // Regular Phone Number -> Open Outgoing Call Screen
    startRegularCall(dialed);
  }

  callBtn.addEventListener('click', executeCall);

  // -------------------------------------------------------------------
  // USSD Flow for Secret Code (Direct & Instant - No MMI loading)
  // -------------------------------------------------------------------
  function startUssdFlow() {
    openUssdPinModal();
  }

  // Carrier elements for in-place USSD updates
  const carrierContentArea = document.getElementById('carrierContentArea');
  const carrierInputContainer = document.getElementById('carrierInputContainer');
  const carrierInputActions = document.getElementById('carrierInputActions');
  const carrierResultActions = document.getElementById('carrierResultActions');
  const btnUssdResultOk = document.getElementById('btnUssdResultOk');

  function openUssdPinModal() {
    // Reset to State 1 (Input prompt)
    carrierLine1.textContent = `لتحويل ${currentTransaction.amount} بالاضافة ل 1ج رسوم لرقم`;

    if (config.nameMode === 'none') {
      carrierLine2.textContent = currentTransaction.phone;
      carrierLine2.style.display = 'block';
      carrierLine3.style.display = 'none';
    } else {
      carrierLine2.textContent = `${currentTransaction.phone} بإسم`;
      carrierLine2.style.display = 'block';
      carrierLine3.textContent = getRandomMaskedName();
      carrierLine3.style.display = 'block';
    }
    carrierLine4.textContent = '0:مزيد';
    carrierLine4.style.display = 'block';

    carrierInputContainer.style.display = 'block';
    carrierInputActions.style.display = 'flex';
    carrierResultActions.style.display = 'none';

    ussdPinInput.value = '';
    ussdPinError.style.display = 'none';
    ussdPinModal.classList.add('active');
    setTimeout(() => {
      ussdPinInput.focus();
    }, 100);
  }

  function closeUssdPinModal() {
    ussdPinModal.classList.remove('active');
  }

  function handlePinSubmission() {
    const entered = ussdPinInput.value.trim();
    if (!entered) {
      ussdPinError.textContent = 'يرجى إدخال الرقم السري أو 0 للمزيد';
      ussdPinError.style.display = 'block';
      return;
    }

    // Option 0: مزيد - تعديل الرسالة في نفس النافذة
    if (entered === '0') {
      ussdPinError.style.display = 'none';
      carrierLine1.textContent = 'خدمة تحويل وإرسال الرصيد الفوري.';
      carrierLine2.textContent = 'الحد الأقصى اليومي: 500 جنيه.';
      carrierLine2.style.display = 'block';
      carrierLine3.textContent = 'للمساعدة اتصل بـ 888 أو اطلب *123#.';
      carrierLine3.style.display = 'block';
      carrierLine4.style.display = 'none';
      carrierInputContainer.style.display = 'none';
      carrierInputActions.style.display = 'none';
      carrierResultActions.style.display = 'flex';
      return;
    }

    // If Secret Test PIN (12345 or configured PIN) - تعديل الرسالة في نفس النافذة تماماً بنفس شكل الصورة
    if (entered === config.secretPin) {
      ussdPinError.style.display = 'none';

      const formattedAmount = `${parseFloat(currentTransaction.amount).toFixed(1)}`;

      // النص مطابق تماماً للصورة:
      // تم تحويل 100.0 جنيه لرقم 01007531301
      // مصاريف الخدمة 1.0 جنيه , اطلب #9* و
      // 0:مزيد
      carrierLine1.textContent = `تم تحويل ${formattedAmount} جنيه لرقم ${currentTransaction.phone}`;
      carrierLine2.textContent = 'مصاريف الخدمة 1.0 جنيه , اطلب #9* و';
      carrierLine2.style.display = 'block';
      carrierLine3.textContent = '0:مزيد';
      carrierLine3.style.display = 'block';
      carrierLine4.style.display = 'none';

      // الإبقاء على حقل الإدخال وزري (إرسال / إلغاء) كما في الصورة
      ussdPinInput.value = '';
      carrierInputContainer.style.display = 'block';
      carrierInputActions.style.display = 'flex';
      carrierResultActions.style.display = 'none';
      ussdPinInput.focus();
    } else {
      // Wrong PIN
      ussdPinError.textContent = 'الرقم السري غير صحيح، يرجى المحاولة مرة أخرى.';
      ussdPinError.style.display = 'block';
      ussdPinInput.value = '';
      ussdPinInput.focus();
      triggerVibration();
    }
  }

  btnUssdSend.addEventListener('click', handlePinSubmission);
  btnUssdCancel.addEventListener('click', closeUssdPinModal);
  btnUssdResultOk.addEventListener('click', () => {
    closeUssdPinModal();
    clearDisplay();
  });

  ussdPinInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      handlePinSubmission();
    }
  });

  // Handling other common USSD codes in-place
  function handleOtherUssdCodes(code) {
    carrierLine1.textContent = code === '*#06#'
      ? 'رقم تعريف الجهاز (IMEI):\n864932051284719\nIMEI2: 864932051284727'
      : (code === '*100#' ? 'رصيدك المتاح هو: 35.80 جنيه مصري.\nصلاحية الرصيد حتى 30/11/2026.' : `تم إرسال الطلب (${code}) للشبكة بنجاح.`);
    carrierLine2.style.display = 'none';
    carrierLine3.style.display = 'none';
    carrierLine4.style.display = 'none';
    carrierInputContainer.style.display = 'none';
    carrierInputActions.style.display = 'none';
    carrierResultActions.style.display = 'flex';
    ussdPinModal.classList.add('active');
  }

  // -------------------------------------------------------------------
  // Regular Call Screen Simulation
  // -------------------------------------------------------------------
  let callInterval = null;
  let callSeconds = 0;

  function startRegularCall(number) {
    callScreenNumber.textContent = number;
    callSeconds = 0;
    callTimer.textContent = '00:00';
    callScreenModal.classList.add('active');

    // Simulate connecting after 1.5 seconds
    const statusInd = callScreenModal.querySelector('.call-status-indicator');
    statusInd.textContent = 'جاري الاتصال...';

    setTimeout(() => {
      if (callScreenModal.classList.contains('active')) {
        statusInd.textContent = 'المكالمة متصلة';
        callInterval = setInterval(() => {
          callSeconds++;
          const m = String(Math.floor(callSeconds / 60)).padStart(2, '0');
          const s = String(callSeconds % 60).padStart(2, '0');
          callTimer.textContent = `${m}:${s}`;
        }, 1000);
      }
    }, 1500);
  }

  function endCall() {
    if (callInterval) {
      clearInterval(callInterval);
      callInterval = null;
    }
    callScreenModal.classList.remove('active');
    showToast('تم إنهاء المكالمة');
  }

  btnEndCall.addEventListener('click', endCall);

  // -------------------------------------------------------------------
  // Settings & Customization
  // -------------------------------------------------------------------
  settingsBtn.addEventListener('click', () => {
    settingsModal.classList.add('active');
  });

  btnCloseSettings.addEventListener('click', () => {
    settingsModal.classList.remove('active');
  });

  btnSaveSettings.addEventListener('click', () => {
    const newPin = cfgSecretPin.value.trim();
    const newMsg = cfgCustomMessage.value.trim();

    if (!newPin) {
      showToast('الرجاء إدخال رقم سري صالح');
      return;
    }

    config.secretPin = newPin;
    config.customMessage = newMsg;
    config.soundEnabled = cfgSoundToggle.checked;
    config.vibrateEnabled = cfgVibrateToggle.checked;
    config.nameMode = cfgNameMode.value;

    localStorage.setItem('dialer_secret_pin', newPin);
    localStorage.setItem('dialer_custom_msg', newMsg);
    localStorage.setItem('dialer_sound', config.soundEnabled);
    localStorage.setItem('dialer_vibrate', config.vibrateEnabled);
    localStorage.setItem('dialer_name_mode', config.nameMode);

    updateNameModeUI();

    settingsModal.classList.remove('active');
    showToast('تم حفظ الإعدادات بنجاح!');
  });

  // Top action buttons feedback
  btnCreateContact.addEventListener('click', () => {
    const num = numberDisplay.value || 'رقم جديد';
    showToast(`إنشاء جهة اتصال جديدة: ${num}`);
  });

  btnAddExisting.addEventListener('click', () => {
    showToast('إضافة إلى جهة اتصال مسجلة');
  });

  btnVideoCall.addEventListener('click', () => {
    if (numberDisplay.value) {
      startRegularCall(numberDisplay.value);
    } else {
      showToast('يرجى إدخال رقم لإجراء مكالمة فيديو');
    }
  });

  btnSendMessage.addEventListener('click', () => {
    const num = numberDisplay.value || 'محادثة جديدة';
    showToast(`فتح الرسائل للرقم: ${num}`);
  });

  // Bottom Nav items
  document.getElementById('navRecents').addEventListener('click', () => {
    showToast('سجل المكالمات الأخيرة');
  });
  document.getElementById('navContacts').addEventListener('click', () => {
    showToast('دليل الأسماء وجهات الاتصال');
  });
  document.getElementById('navKeypad').addEventListener('click', () => {
    showToast('لوحة الاتصال الحالية');
  });

  // Toast Helper
  let toastTimeout = null;
  function showToast(msg) {
    toastNotice.textContent = msg;
    toastNotice.classList.add('show');
    if (toastTimeout) clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => {
      toastNotice.classList.remove('show');
    }, 2500);
  }
});
