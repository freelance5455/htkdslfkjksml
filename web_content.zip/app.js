(() => {
  "use strict";
  const topics = [
    {id:"abc", emoji:"🔤", hi:"अंग्रेज़ी अक्षर", en:"ABC Letters", sub:"A to Z", items:[["🍎","A","ए फॉर एप्पल"],["⚽","B","बी फॉर बॉल"],["🐱","C","सी फॉर कैट"],["🐶","D","डी फॉर डॉग"]]},
    {id:"hindi", emoji:"अ", hi:"हिंदी वर्णमाला", en:"Hindi Letters", sub:"अ से ज्ञ", items:[["🍇","अ","अनार"],["🥭","आ","आम"],["🐦","इ","इमली"],["🦉","ई","ईख"]]},
    {id:"numbers", emoji:"🔢", hi:"गिनती", en:"Numbers", sub:"1 से 20", items:[["☝️","1","एक"],["✌️","2","दो"],["🤟","3","तीन"],["🖐️","5","पाँच"]]},
    {id:"colors", emoji:"🎨", hi:"रंग", en:"Colours", sub:"रंग पहचानो", items:[["❤️","लाल","Red"],["💙","नीला","Blue"],["💛","पीला","Yellow"],["💚","हरा","Green"]]},
    {id:"shapes", emoji:"🔺", hi:"आकार", en:"Shapes", sub:"आकार पहचानो", items:[["⚪","गोला","Circle"],["🟥","वर्ग","Square"],["🔺","त्रिकोण","Triangle"],["⭐","तारा","Star"]]},
    {id:"animals", emoji:"🐘", hi:"जानवर", en:"Animals", sub:"जानवरों के नाम", items:[["🐘","हाथी","Elephant"],["🦁","शेर","Lion"],["🐒","बंदर","Monkey"],["🐰","खरगोश","Rabbit"]]},
    {id:"fruits", emoji:"🍎", hi:"फल", en:"Fruits", sub:"फलों के नाम", items:[["🍎","सेब","Apple"],["🍌","केला","Banana"],["🍇","अंगूर","Grapes"],["🥭","आम","Mango"]]},
    {id:"quiz", emoji:"🧩", hi:"छोटी क्विज़", en:"Mini Quiz", sub:"सीखो और बताओ", items:[["🐱","बिल्ली","Cat"],["🌞","सूरज","Sun"],["🍓","स्ट्रॉबेरी","Strawberry"],["🚗","गाड़ी","Car"]]}
  ];
  let english = false, currentTopic = null, itemIndex = 0, completed = new Set();
  const $ = (id) => document.getElementById(id);
  function renderTopics() {
    const container = $("topics");
    container.innerHTML = "";
    topics.forEach((topic) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "topic";
      const title = english ? topic.en : topic.hi;
      button.innerHTML = `<span class="emoji">${topic.emoji}</span><strong>${title}</strong><small>${topic.sub}</small>`;
      button.addEventListener("click", () => openTopic(topic));
      container.appendChild(button);
    });
  }
  function updateLanguage() {
    document.documentElement.lang = english ? "en" : "hi";
    $("languageBtn").textContent = english ? "English / हिंदी" : "हिंदी / EN";
    $("eyebrow").textContent = english ? "Learn through play" : "खेल-खेल में सीखें";
    $("welcomeTitle").textContent = english ? "Let's learn!" : "चलो सीखें!";
    $("welcomeText").textContent = english ? "What shall we discover today?" : "आज कौन-सी नई बात सीखेंगे?";
    $("progressTitle").textContent = english ? "My learning journey" : "मेरी सीखने की यात्रा";
    $("progressHint").textContent = english ? "Open a topic to get started." : "एक विषय खोलकर शुरुआत करो।";
    $("topicsTitle").textContent = english ? "Learning topics" : "सीखने के विषय";
    $("parentsTitle").textContent = english ? "For Parents" : "Parents / माता-पिता";
    $("parentsText").textContent = english ? "This is an early demo. No child data or progress is sent to a server." : "यह शुरुआती demo है। बच्चे का डेटा या progress किसी सर्वर पर नहीं भेजा जाता।";
    $("parentsNote").textContent = english ? "Sit with your child and keep sessions short: 5–10 minutes." : "बच्चे के साथ बैठकर 5–10 मिनट के छोटे सत्र रखें।";
    renderTopics();
    updateProgress();
    if (currentTopic) showItem();
  }
  function updateProgress() {
    $("progressCount").textContent = `${completed.size} / ${topics.length}`;
    $("progressBar").style.width = `${completed.size / topics.length * 100}%`;
  }
  function openTopic(topic) {
    currentTopic = topic; itemIndex = 0;
    $("lesson").classList.remove("hidden");
    showItem();
    $("lesson").scrollIntoView({behavior:"smooth", block:"nearest"});
  }
  function showItem() {
    const item = currentTopic.items[itemIndex % currentTopic.items.length];
    $("lessonEyebrow").textContent = english ? "Let's learn" : "चलो सीखें";
    $("lessonTitle").textContent = english ? currentTopic.en : currentTopic.hi;
    $("lessonEmoji").textContent = item[0];
    $("lessonItem").textContent = english ? item[2] : item[1];
    $("listenBtn").textContent = english ? "🔊 Listen" : "🔊 सुनें / Listen";
    $("nextBtn").textContent = english ? "Next ➜" : "अगला / Next ➜";
  }
  function speak() {
    if (!currentTopic) return;
    const item = currentTopic.items[itemIndex % currentTopic.items.length];
    const text = english ? item[2] : item[1];
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = english ? "en-IN" : "hi-IN";
      window.speechSynthesis.speak(utterance);
    } else {
      alert(english ? "Speech is not supported in this browser." : "इस browser में आवाज़ की सुविधा उपलब्ध नहीं है।");
    }
  }
  $("languageBtn").addEventListener("click", () => { english = !english; updateLanguage(); });
  $("closeLesson").addEventListener("click", () => {
    $("lesson").classList.add("hidden");
    if (currentTopic) completed.add(currentTopic.id);
    currentTopic = null; updateProgress();
  });
  $("nextBtn").addEventListener("click", () => {
    if (!currentTopic) return;
    itemIndex++;
    if (itemIndex >= currentTopic.items.length) {
      completed.add(currentTopic.id);
      updateProgress();
      itemIndex = 0;
    }
    showItem();
  });
  $("listenBtn").addEventListener("click", speak);
  updateLanguage();
})();
