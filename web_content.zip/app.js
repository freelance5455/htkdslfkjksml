let map;
let markers = {};
let aircraftData = [];
let isFetching = false;
let lastUpdateTimestamp = null;
let activeInterval = null;

// Initialize Web application
document.addEventListener("DOMContentLoaded", () => {
    initMap();
    initEventListeners();
    startDataPolling();
    fetchLiveAircraft();
});

function initMap() {
    map = L.map("flight-map").setView(CONFIG.INITIAL_COORDS, CONFIG.INITIAL_ZOOM);

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19
    }).addTo(map);
}

function initEventListeners() {
    document.getElementById("refresh-btn").addEventListener("click", () => {
        if (!isFetching) fetchLiveAircraft();
    });

    document.getElementById("search-btn").addEventListener("click", performSearch);
    document.getElementById("search-input").addEventListener("keypress", (e) => {
        if (e.key === 'Enter') performSearch();
    });

    document.getElementById("category-filter").addEventListener("change", applyFiltersAndRender);
}

function startDataPolling() {
    if (activeInterval) clearInterval(activeInterval);
    activeInterval = setInterval(fetchLiveAircraft, CONFIG.POLL_INTERVAL_MS);
    
    // Check for stale state periodically
    setInterval(checkDataFreshness, 5000);
}

async function fetchLiveAircraft() {
    if (isFetching) return;
    isFetching = true;

    try {
        const response = await fetch(`${CONFIG.API_BASE_URL}/api/aircraft`);
        if (!response.ok) {
            throw new Error(`API error: Status ${response.status}`);
        }
        
        const data = await response.json();
        aircraftData = data.aircraft || [];
        lastUpdateTimestamp = Date.now();
        
        updateStatusIndicator("live");
        showToast(null); // Clear errors
        applyFiltersAndRender();
    } catch (error) {
        console.error("Fetch failure:", error);
        updateStatusIndicator("offline");
        showToast(`Data Error: Unable to reach telemetry server.`);
    } finally {
        isFetching = false;
        document.getElementById("last-updated").innerText = new Date().toLocaleTimeString();
    }
}

function checkDataFreshness() {
    if (!lastUpdateTimestamp) return;
    const diff = Date.now() - lastUpdateTimestamp;
    if (diff > CONFIG.STALE_THRESHOLD_MS) {
        updateStatusIndicator("stale");
    }
}

function updateStatusIndicator(status) {
    const el = document.getElementById("data-status");
    el.className = `status-indicator ${status}`;
    el.innerText = status.toUpperCase();
}

function applyFiltersAndRender() {
    const filterValue = document.getElementById("category-filter").value;
    const searchQuery = document.getElementById("search-input").value.trim().toUpperCase();

    let filtered = aircraftData.filter(ac => {
        // Category Filter
        if (filterValue !== "all" && ac.classification !== filterValue) return false;
        
        // Search filter
        if (searchQuery) {
            const matchCallsign = ac.callsign && ac.callsign.toUpperCase().includes(searchQuery);
            const matchIcao = ac.icao24 && ac.icao24.toUpperCase().includes(searchQuery);
            return matchCallsign || matchIcao;
        }
        return true;
    });

    document.getElementById("aircraft-count").innerText = `Aircraft: ${filtered.length}`;
    renderMarkers(filtered);
}

function renderMarkers(aircraftList) {
    // Keep track of active current IDs
    const activeIds = new Set();

    aircraftList.forEach(ac => {
        if (!Number.isFinite(ac.latitude) || !Number.isFinite(ac.longitude)) return;
        
        activeIds.add(ac.icao24);
        const position = [ac.latitude, ac.longitude];

        if (markers[ac.icao24]) {
            // Update existing marker coordinate dynamically
            markers[ac.icao24].setLatLng(position);
        } else {
            // Create a custom styled marker representation
            const markerOptions = {};
            
            // Adjust marker color paradigm dynamically based on classification rules
            if (ac.classification === 'military') {
                markerOptions.title = `MIL: ${ac.callsign || ac.icao24}`;
            }

            const marker = L.marker(position, markerOptions);
            
            marker.bindPopup(`
                <div class="map-popup">
                    <strong>${escapeHtml(ac.callsign || "UNKNOWN")}</strong><br>
                    <span>ICAO: ${escapeHtml(ac.icao24)}</span><br>
                    <span>Alt: ${Math.round(ac.altitude_m * 3.28084)} ft</span><br>
                    <span>Spd: ${Math.round(ac.ground_speed_ms * 1.94384)} kts</span>
                </div>
            `);

            marker.on('click', () => displayAircraftDetails(ac));
            marker.addTo(map);
            markers[ac.icao24] = marker;
        }
    });

    // Remove markers that are no longer part of active filtered collection
    Object.keys(markers).forEach(id => {
        if (!activeIds.has(id)) {
            map.removeLayer(markers[id]);
            delete markers[id];
        }
    });
}

function displayAircraftDetails(ac) {
    const container = document.getElementById("details-content");
    const placeholder = document.querySelector(".placeholder-text");
    
    placeholder.classList.add("hidden");
    container.classList.remove("hidden");

    container.innerHTML = `
        <div class="detail-row"><span>Callsign</span><strong>${escapeHtml(ac.callsign || "N/A")}</strong></div>
        <div class="detail-row"><span>ICAO Address</span><span>${escapeHtml(ac.icao24)}</span></div>
        <div class="detail-row"><span>Category</span><span class="badge">${escapeHtml(ac.classification.toUpperCase())}</span></div>
        <div class="detail-row"><span>Altitude</span><span>${Math.round(ac.altitude_m)} m (${Math.round(ac.altitude_m * 3.28084)} ft)</span></div>
        <div class="detail-row"><span>Ground Speed</span><span>${Math.round(ac.ground_speed_ms)} m/s (${Math.round(ac.ground_speed_ms * 1.94384)} kts)</span></div>
        <div class="detail-row"><span>Heading</span><span>${ac.heading_deg}&deg;</span></div>
        <div class="detail-row"><span>Vertical Rate</span><span>${ac.vertical_rate_ms} m/s</span></div>
        <div class="detail-row"><span>Data Source</span><span>${escapeHtml(ac.source)}</span></div>
    `;
}

function performSearch() {
    applyFiltersAndRender();
    const searchQuery = document.getElementById("search-input").value.trim().toUpperCase();
    
    if (searchQuery) {
        const found = aircraftData.find(ac => 
            (ac.callsign && ac.callsign.toUpperCase().includes(searchQuery)) || 
            (ac.icao24 && ac.icao24.toUpperCase().includes(searchQuery))
        );

        if (found && Number.isFinite(found.latitude)) {
            map.setView([found.latitude, found.longitude], 9);
            if (markers[found.icao24]) {
                markers[found.icao24].openPopup();
                displayAircraftDetails(found);
            }
        } else {
            showToast("No active matching aircraft located.");
        }
    }
}

function showToast(msg) {
    const toast = document.getElementById("error-toast");
    if (!msg) {
        toast.classList.add("hidden");
    } else {
        toast.innerText = msg;
        toast.classList.remove("hidden");
    }
}

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, "&amp;")
              .replace(/</g, "&lt;")
              .replace(/>/g, "&gt;")
              .replace(/"/g, "&quot;")
              .replace(/'/g, "&#039;");
}
