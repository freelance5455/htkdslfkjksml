const $ = id => document.getElementById(id);
let animals = JSON.parse(localStorage.getItem("pashuAnimals") || "[]");

function toast(msg){
  const el=$("toast"); el.textContent=msg; el.classList.add("show");
  clearTimeout(window.__toast); window.__toast=setTimeout(()=>el.classList.remove("show"),2200);
}
function emojiFor(type){ return type==="गाय"?"🐄":type==="भैंस"?"🐃":type==="बकरी"?"🐐":type==="भेड़"?"🐑":"🐔"; }

$("sendOtp").onclick=()=>{
  const p=$("phone").value.replace(/\D/g,"");
  if(p.length!==10){toast("कृपया 10 अंकों का मोबाइल नंबर डालें");return}
  $("phoneStep").classList.add("hidden"); $("otpStep").classList.remove("hidden"); $("otp").focus();
  toast("Demo OTP भेजा गया: 123456");
};
$("verifyOtp").onclick=()=>{
  if($("otp").value!=="123456"){toast("OTP गलत है। Demo OTP 123456 है");return}
  localStorage.setItem("pashuLoggedIn","1");
  $("loginScreen").classList.add("hidden"); $("mainScreen").classList.remove("hidden"); render();
};
$("changeNumber").onclick=()=>{$("otpStep").classList.add("hidden");$("phoneStep").classList.remove("hidden");$("otp").value=""};

function render(){
  $("animalCount").textContent=animals.length;
  const milk=animals.reduce((s,a)=>s+(Number(a.milk)||0),0);
  $("milkTotal").textContent=milk.toFixed(1)+" L";
  const upcoming=animals.filter(a=>a.vacc && new Date(a.vacc)>=new Date()).length;
  $("vaccCount").textContent=upcoming;
  const list=$("animalList");
  if(!animals.length){
    list.innerHTML='<div class="empty">अभी कोई पशु नहीं जोड़ा गया।<br><b>+ पशु जोड़ें</b> दबाकर शुरुआत करें।</div>';
    return;
  }
  list.innerHTML=animals.map((a,i)=>`
    <div class="animal-card" onclick="showAnimal(${i})">
      <div class="animal-avatar">${emojiFor(a.type)}</div>
      <div class="animal-info"><b>${escapeHtml(a.name)}</b><span>${escapeHtml(a.type)} • ${escapeHtml(a.breed||"नस्ल दर्ज नहीं")} • ${a.age||0} वर्ष • ${a.milk||0} L/दिन</span></div>
      <div class="animal-arrow">›</div>
    </div>`).join("");
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
window.showAnimal=(i)=>{
  const a=animals[i];
  alert(`पशु विवरण\n\nनाम: ${a.name}\nप्रकार: ${a.type}\nनस्ल: ${a.breed||"-"}\nउम्र: ${a.age||"-"} वर्ष\nलिंग: ${a.gender||"-"}\nरंग: ${a.color||"-"}\nदूध: ${a.milk||0} L/दिन\nअगला टीका: ${a.vacc||"-"}\nब्रीडिंग/चेकअप: ${a.breedDate||"-"}\nनोट: ${a.note||"-"}`);
};
$("addAnimalBtn").onclick=()=>$("animalModal").classList.remove("hidden");
$("closeModal").onclick=()=>$("animalModal").classList.add("hidden");
$("saveAnimal").onclick=()=>{
  const name=$("aName").value.trim();
  if(!name){toast("पशु का नाम डालें");return}
  animals.push({name,type:$("aType").value,breed:$("aBreed").value.trim(),age:$("aAge").value,gender:$("aGender").value,color:$("aColor").value.trim(),milk:$("aMilk").value,vacc:$("aVacc").value,breedDate:$("aBreedDate").value,note:$("aNote").value.trim()});
  localStorage.setItem("pashuAnimals",JSON.stringify(animals));
  document.querySelectorAll("#animalModal input,#animalModal textarea").forEach(x=>x.value="");
  $("animalModal").classList.add("hidden"); render(); toast("पशु सफलतापूर्वक सेव हो गया");
};
window.scrollToAnimals=()=>document.querySelector(".animal-list").scrollIntoView({behavior:"smooth",block:"center"});
if(localStorage.getItem("pashuLoggedIn")==="1"){$("loginScreen").classList.add("hidden");$("mainScreen").classList.remove("hidden");render()}
if("serviceWorker" in navigator) window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js"));
