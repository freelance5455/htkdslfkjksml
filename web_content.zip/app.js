// आपका Firebase कॉन्फ़िगरेशन
const firebaseConfig = {
  apiKey: "AIzaSyBdbhSYO-nDqQ5tIehcraBq8g4RgNIciLI",
  authDomain: "ultra-calling.firebaseapp.com",
  projectId: "ultra-calling",
  storageBucket: "ultra-calling.firebasestorage.app",
  messagingSenderId: "487761265796",
  appId: "1:487761265796:web:a855a927c43aa490deaed1"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Global WebRTC Configuration (STUN Servers for connection)
const servers = {
    iceServers: [
        { urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'] }
    ],
    iceCandidatePoolSize: 10,
};

let pc = new RTCPeerConnection(servers);
let localStream = null;
let remoteStream = null;

// DOM Elements
const webcamBtn = document.getElementById('webcamBtn');
const createBtn = document.getElementById('createBtn');
const joinBtn = document.getElementById('joinBtn');
const roomIdInput = document.getElementById('roomIdInput');
const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');

// 1. कैमरा और माइक चालू करना
webcamBtn.onclick = async () => {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    remoteStream = new MediaStream();

    // लोकल वीडियो स्क्रीन पर दिखाएं
    localStream.getTracks().forEach((track) => {
        pc.addTrack(track, localStream);
    });
    localVideo.srcObject = localStream;

    // सामने वाले का वीडियो आने पर उसे सेट करें
    pc.ontrack = (event) => {
        event.streams.getTracks().forEach((track) => {
            remoteStream.addTrack(track);
        });
    };
    remoteVideo.srcObject = remoteStream;

    // बटन्स इनेबल करें
    createBtn.disabled = false;
    joinBtn.disabled = false;
    webcamBtn.disabled = true;
};

// 2. Room Create करना (कॉल करने वाला)
createBtn.onclick = async () => {
    const roomId = roomIdInput.value.trim();
    if (!roomId) return alert("Please enter a Room ID first!");

    const roomRef = db.collection('rooms').doc(roomId);
    const callerCandidatesCollection = roomRef.collection('callerCandidates');
    const calleeCandidatesCollection = roomRef.collection('calleeCandidates');

    pc.onicecandidate = (event) => {
        event.candidate && callerCandidatesCollection.add(event.candidate.toJSON());
    };

    // Offer (कॉल आमंत्रण) तैयार करें
    const offerDescription = await pc.createOffer();
    await pc.setLocalDescription(offerDescription);

    const offer = {
        sdp: offerDescription.sdp,
        type: offerDescription.type,
    };

    await roomRef.set({ offer });

    // सामने वाले के Answer (जवाब) का इंतज़ार करें
    roomRef.onSnapshot((snapshot) => {
        const data = snapshot.data();
        if (!pc.currentRemoteDescription && data?.answer) {
            const answerDescription = new RTCSessionDescription(data.answer);
            pc.setRemoteDescription(answerDescription);
        }
    });

    // सामने वाले के ICE Candidates को जोड़ें
    calleeCandidatesCollection.onSnapshot((snapshot) => {
        snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
                let data = change.doc.data();
                pc.addIceCandidate(new RTCIceCandidate(data));
            }
        });
    });

    alert("Room Created! Ask the other person to join using ID: " + roomId);
};

// 3. Room Join करना (कॉल उठाने वाला)
joinBtn.onclick = async () => {
    const roomId = roomIdInput.value.trim();
    if (!roomId) return alert("Please enter a Room ID to join!");

    const roomRef = db.collection('rooms').doc(roomId);
    const roomSnapshot = await roomRef.get();

    if (!roomSnapshot.exists) {
        return alert("Room not found! Check the Room ID.");
    }

    const calleeCandidatesCollection = roomRef.collection('calleeCandidates');
    const callerCandidatesCollection = roomRef.collection('callerCandidates');

    pc.onicecandidate = (event) => {
        event.candidate && calleeCandidatesCollection.add(event.candidate.toJSON());
    };

    const roomData = roomSnapshot.data();
    const offerDescription = roomData.offer;
    await pc.setRemoteDescription(new RTCSessionDescription(offerDescription));

    // Answer (जवाब) तैयार करें
    const answerDescription = await pc.createAnswer();
    await pc.setLocalDescription(answerDescription);

    const answer = {
        type: answerDescription.type,
        sdp: answerDescription.sdp,
    };

    await roomRef.update({ answer });

    // कॉलर के ICE Candidates को जोड़ें
    callerCandidatesCollection.onSnapshot((snapshot) => {
        snapshot.docChanges().forEach((change) => {
            if (change.type === 'added') {
                let data = change.doc.data();
                pc.addIceCandidate(new RTCIceCandidate(data));
            }
        });
    });
};