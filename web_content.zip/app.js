const $ = s => document.querySelector(s);
const messages = $('#messages'), promptBox = $('#prompt'), welcome = $('#welcome');
function addMessage(text, who='bot') {
  welcome.classList.add('hidden');
  const row = document.createElement('div'); row.className = `message ${who === 'user' ? 'user' : ''}`;
  const avatar = document.createElement('div'); avatar.className = 'msg-avatar'; avatar.textContent = who === 'user' ? 'Tu' : 'B';
  const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = text;
  row.append(avatar,bubble); messages.append(row); messages.scrollTop = messages.scrollHeight;
}
function localReply(input) {
  const t = input.toLowerCase();
  if (/(olá|ola|oi|bom dia|boa tarde|boa noite|hey)/.test(t)) return 'Olá! 👋 Sou a Banpy, a tua assistente digital. Diz-me o que gostarias de fazer hoje e vamos trabalhar nisso juntos.';
  if (/(quem és|quem es|banpy)/.test(t)) return 'Sou a Banpy AI, uma assistente digital em versão demonstrativa. Posso ajudar-te a estruturar ideias, estudar, escrever textos e planear projectos. Para conversar com um modelo de IA real, esta aplicação precisa de ser ligada a um serviço de IA através de um servidor seguro.';
  if (/(negócio|negocio|vender|dinheiro|empreendedor)/.test(t)) return 'Vamos organizar a tua ideia de negócio em passos simples:\n\n1. Escolhe um problema real que possas resolver.\n2. Define quem precisa da solução.\n3. Cria uma versão simples do produto ou serviço.\n4. Testa com algumas pessoas e recolhe opiniões.\n5. Calcula custos, preço e forma de divulgação.\n\nConta-me a tua ideia e ajudo-te a desenvolver o plano.';
  if (/(estudar|estudo|escola|aprender|explica)/.test(t)) return 'Claro! Posso ajudar-te a aprender passo a passo. Primeiro, diz-me qual é o assunto e o teu nível de conhecimento. Vou procurar explicar com palavras simples, exemplos práticos e um pequeno exercício para confirmares o que aprendeste.';
  if (/(currículo|curriculo|cv|emprego|trabalho)/.test(t)) return 'Para preparar um currículo, organiza estas informações: nome e contactos, objectivo profissional, formação, experiência (se tiveres), competências e idiomas. Não precisas de partilhar dados sensíveis aqui. Diz-me a área em que procuras trabalho e preparo um modelo para preencheres.';
  if (/(história|historia|escrever|texto|mensagem|poema)/.test(t)) return 'Vamos criar isso juntos. Para eu estruturar melhor, pensa em três coisas: qual é o objectivo do texto, para quem é e que estilo preferes (formal, descontraído, romântico ou emocionante). Posso começar com uma primeira versão e depois ajustamos.';
  if (/(plano|organizar|rotina|dias)/.test(t)) return 'Uma boa forma de começar é dividir o objectivo em pequenas tarefas. Define o resultado que queres, escolhe uma tarefa prioritária por dia e reserva um momento para rever o progresso. Se me disseres o teu objectivo e o prazo, preparo um plano mais concreto.';
  return 'Obrigado por partilhares isso comigo. Nesta versão de demonstração, ainda não estou ligada a um modelo de IA online, por isso as minhas respostas são limitadas. A interface já está preparada para ser personalizada e ligada a uma API de IA através de um servidor seguro. Posso, entretanto, ajudar com ideias, textos, estudos e planeamento usando os atalhos disponíveis.';
}
function send(text) {
  const value = (text ?? promptBox.value).trim(); if (!value) return;
  addMessage(value,'user'); promptBox.value=''; promptBox.style.height='auto';
  setTimeout(() => addMessage(localReply(value)), 350);
}
$('#chatForm').addEventListener('submit', e => { e.preventDefault(); send(); });
promptBox.addEventListener('input', () => { promptBox.style.height='auto'; promptBox.style.height=Math.min(promptBox.scrollHeight,140)+'px'; });
promptBox.addEventListener('keydown', e => { if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();} });
document.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>{ const p=b.dataset.prompt; showView('chat'); send(p); }));
$('#newChat').addEventListener('click',()=>{messages.innerHTML='';welcome.classList.remove('hidden');showView('chat');promptBox.focus();closeSidebar();});
$('#clearChat').addEventListener('click',()=>{messages.innerHTML='';welcome.classList.remove('hidden');});
$('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));
function closeSidebar(){ $('#sidebar').classList.remove('open'); }
function showView(view){
  ['chat','ideas','about'].forEach(v=>$('#'+v+'View').classList.toggle('hidden',v!==view));
  document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  closeSidebar();
}
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
