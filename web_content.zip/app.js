(() => {
const localHosts = new Set(['localhost', '127.0.0.1', '[::1]']);
const rawBase = window.__API_BASE__ || '';
const unresolved = rawBase.startsWith('__PORT_');
if (unresolved && !localHosts.has(location.hostname)) document.body.innerHTML = '<p style="padding:40px">Backend is not connected.</p>';
const API = unresolved ? 'http://localhost:8000' : rawBase.replace(/\/$/, '');

const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const icons = () => window.lucide && lucide.createIcons();
const TB = 1024 ** 4;

const state = { view: 'drive', folder: null, q: '', layout: 'grid', items: [], selected: null, dark: matchMedia('(prefers-color-scheme: dark)').matches };

function fmt(b) {
  if (!b) return '0 B';
  const u = ['B','KB','MB','GB','TB']; let i = 0;
  while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
  return (b >= 100 || i === 0 ? Math.round(b) : b.toFixed(b >= 10 ? 1 : 2)) + ' ' + u[i];
}
function fmtDate(t) {
  const d = new Date(t * 1000), now = new Date();
  return d.toDateString() === now.toDateString() ? d.toLocaleTimeString([], {hour:'numeric', minute:'2-digit'}) : d.toLocaleDateString([], {month:'short', day:'numeric', year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric'});
}
function kind(it) {
  if (it.kind === 'folder') return { ic: 'folder', cls: 'ic-folder' };
  const m = it.mime || '';
  if (m.startsWith('image/')) return { ic: 'image', cls: 'ic-image', t: 'image' };
  if (m.startsWith('video/')) return { ic: 'film', cls: 'ic-video', t: 'video' };
  if (m.startsWith('audio/')) return { ic: 'music', cls: 'ic-audio', t: 'audio' };
  if (m.includes('pdf')) return { ic: 'file-text', cls: 'ic-pdf', t: 'pdf' };
  if (m.startsWith('text/') || /json|javascript|xml|csv/.test(m)) return { ic: 'file-code', cls: 'ic-doc', t: 'text' };
  if (/zip|compressed|tar|rar|7z/.test(m)) return { ic: 'file-archive', cls: 'ic-other' };
  if (/sheet|excel/.test(m)) return { ic: 'sheet', cls: 'ic-doc' };
  if (/document|word|presentation|powerpoint/.test(m)) return { ic: 'file-text', cls: 'ic-doc' };
  return { ic: 'file', cls: 'ic-other' };
}
const rawUrl = (id, dl) => `${API}/api/files/${id}/raw${dl ? '?download=1' : ''}`;

async function api(path, opts = {}) {
  const res = await fetch(API + path, { credentials: 'same-origin', ...opts, headers: { 'Content-Type': 'application/json', ...(opts.headers || {}) } });
  if (!res.ok) { let m = res.statusText; try { m = (await res.json()).detail || m; } catch {} throw new Error(m); }
  return res.json();
}

/* ---------- toast ---------- */
let toastT;
function toast(msg, action) {
  const t = $('#toast'); t.innerHTML = `<span>${esc(msg)}</span>`;
  if (action) { const b = document.createElement('button'); b.textContent = action.label; b.onclick = () => { action.fn(); t.hidden = true; }; t.append(b); }
  t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, 4200);
}

/* ---------- usage ---------- */
let usageData = null;
async function loadUsage() {
  try {
    usageData = await api('/api/usage');
    const pct = usageData.used / usageData.quota * 100;
    $('#meterFill').style.width = Math.min(100, pct) + '%';
    $('#meter').setAttribute('aria-valuenow', pct.toFixed(2));
    $('#storageText').textContent = `${fmt(usageData.used)} of 1 TB used`;
  } catch { $('#storageText').textContent = 'Storage unavailable'; }
}

/* ---------- render ---------- */
const VIEW_TITLES = { drive: 'My Drive', recent: 'Recent', starred: 'Starred', trash: 'Trash' };
async function renderCrumbs() {
  const c = $('#crumbs');
  if (state.q) { c.innerHTML = `<button data-testid="text-title">Search results for “${esc(state.q)}”</button>`; return; }
  if (state.view !== 'drive' || !state.folder) { c.innerHTML = `<button data-testid="text-title" data-crumb="">${VIEW_TITLES[state.view]}</button>`; }
  else {
    let path = [];
    try { path = await api('/api/path/' + state.folder); } catch {}
    c.innerHTML = `<button data-crumb="" data-testid="crumb-root">My Drive</button>` + path.map(p => `<span class="sep"><i data-lucide="chevron-right"></i></span><button data-crumb="${p.id}" data-testid="crumb-${p.id}">${esc(p.name)}</button>`).join('');
  }
  c.querySelectorAll('[data-crumb]').forEach(b => b.onclick = () => { state.folder = b.dataset.crumb || null; load(); });
  const ha = $('#headActions');
  ha.innerHTML = state.view === 'trash' && !state.q ? `<button class="btn btn-ghost" id="emptyTrash" data-testid="button-empty-trash"><i data-lucide="trash"></i>Empty trash</button>` : '';
  const et = $('#emptyTrash'); if (et) et.onclick = confirmEmptyTrash;
  icons();
}

function emptyState() {
  const map = {
    drive: ['upload-cloud', state.folder ? 'This folder is empty' : 'Your 1 TB drive is ready', 'Drag files here or use the New button to upload photos, videos, documents and more.', true],
    recent: ['clock', 'No recent files', 'Files you upload or change will show up here.'],
    starred: ['star', 'Nothing starred yet', 'Star files and folders you want to find quickly.'],
    trash: ['trash-2', 'Trash is empty', 'Items you delete go here. You can restore them or delete them forever.'],
  };
  const [ic, h, p, cta] = state.q ? ['search-x', 'No matches', `Nothing in your drive matches “${esc(state.q)}”.`] : map[state.view];
  return `<div class="empty" data-testid="state-empty"><div class="empty-ic"><i data-lucide="${ic}"></i></div><h2>${h}</h2><p>${p}</p>${cta ? '<button class="btn btn-primary" id="emptyUpload" data-testid="button-empty-upload"><i data-lucide="file-up"></i>Upload files</button>' : ''}</div>`;
}

function thumb(it, k) {
  if (k.t === 'image') return `<div class="thumb"><img loading="lazy" src="${rawUrl(it.id)}" alt="" onerror="this.replaceWith(Object.assign(document.createElement('span'),{innerHTML:'<i data-lucide=&quot;image&quot; class=&quot;ic-image&quot;></i>'}));lucide.createIcons()"></div>`;
  if (k.t === 'video') return `<div class="thumb"><video preload="metadata" muted src="${rawUrl(it.id)}#t=0.5"></video></div>`;
  return `<div class="thumb"><i data-lucide="${k.ic}" class="${k.cls}"></i></div>`;
}

function render() {
  const el = $('#items'); const items = state.items;
  el.className = 'items ' + state.layout;
  if (!items.length) { el.innerHTML = emptyState(); const b = $('#emptyUpload'); if (b) b.onclick = () => $('#fileInput').click(); icons(); return; }
  const star = it => it.starred && state.view !== 'trash' ? '<span class="star-badge" aria-label="Starred"><i data-lucide="star"></i></span>' : '';
  if (state.layout === 'grid') {
    const folders = items.filter(i => i.kind === 'folder'), files = items.filter(i => i.kind === 'file');
    let h = '';
    if (folders.length) h += `<div class="section-label">Folders</div>` + folders.map(it => `<div class="card folder" tabindex="0" data-id="${it.id}" data-testid="card-folder-${it.id}"><div class="card-top"><i data-lucide="folder" class="ic-folder"></i><span class="card-name" title="${esc(it.name)}">${esc(it.name)}</span>${star(it)}</div><button class="more" data-more="${it.id}" aria-label="More actions for ${esc(it.name)}" data-testid="button-more-${it.id}"><i data-lucide="more-vertical"></i></button></div>`).join('');
    if (files.length) h += `<div class="section-label">Files</div>` + files.map(it => { const k = kind(it); return `<div class="card" tabindex="0" data-id="${it.id}" data-testid="card-file-${it.id}"><div class="card-top"><i data-lucide="${k.ic}" class="${k.cls}"></i><span class="card-name" title="${esc(it.name)}">${esc(it.name)}</span>${star(it)}<button class="more" data-more="${it.id}" aria-label="More actions for ${esc(it.name)}" data-testid="button-more-${it.id}"><i data-lucide="more-vertical"></i></button></div>${thumb(it, k)}</div>`; }).join('');
    el.innerHTML = h;
  } else {
    el.innerHTML = `<div class="list-head"><span>Name</span><span class="c-date">${state.view === 'trash' ? 'Deleted' : 'Modified'}</span><span>Size</span><span></span></div>` +
      items.map(it => { const k = kind(it); return `<div class="row" tabindex="0" data-id="${it.id}" data-testid="row-item-${it.id}"><div class="row-name"><i data-lucide="${k.ic}" class="${k.cls}"></i><span title="${esc(it.name)}">${esc(it.name)}</span>${star(it)}</div><span class="meta c-date">${fmtDate(it.updated_at)}</span><span class="meta">${it.kind === 'folder' ? '—' : fmt(it.size)}</span><button class="more" data-more="${it.id}" aria-label="More actions for ${esc(it.name)}" data-testid="button-more-${it.id}"><i data-lucide="more-vertical"></i></button></div>`; }).join('');
  }
  el.querySelectorAll('[data-id]').forEach(n => {
    const it = items.find(i => i.id === n.dataset.id);
    n.onclick = e => { if (e.target.closest('[data-more]')) return; select(it.id); };
    n.ondblclick = () => openItem(it);
    n.onkeydown = e => { if (e.key === 'Enter') openItem(it); };
    n.oncontextmenu = e => { e.preventDefault(); select(it.id); showCtx(it, e.clientX, e.clientY); };
  });
  el.querySelectorAll('[data-more]').forEach(b => b.onclick = e => { e.stopPropagation(); const it = items.find(i => i.id === b.dataset.more); select(it.id); const r = b.getBoundingClientRect(); showCtx(it, r.left, r.bottom + 4); });
  icons();
}
function select(id) {
  state.selected = id;
  document.querySelectorAll('[data-id]').forEach(n => n.classList.toggle('selected', n.dataset.id === id));
}

async function load() {
  const el = $('#items');
  el.className = 'items grid';
  el.innerHTML = Array.from({length: 6}, () => '<div class="skeleton"></div>').join('');
  renderCrumbs();
  const p = new URLSearchParams({ view: state.view });
  if (state.folder && state.view === 'drive') p.set('parent', state.folder);
  if (state.q) p.set('q', state.q);
  try { state.items = await api('/api/items?' + p); render(); }
  catch (e) { el.innerHTML = `<div class="empty"><div class="empty-ic"><i data-lucide="wifi-off"></i></div><h2>Couldn't load your drive</h2><p>${esc(e.message)}</p><button class="btn btn-primary" id="retry">Try again</button></div>`; $('#retry').onclick = load; icons(); }
  loadUsage();
}

/* ---------- open / preview ---------- */
function openItem(it) {
  if (it.kind === 'folder') {
    if (state.view === 'trash') return toast('Restore this folder to open it');
    state.view = 'drive'; state.folder = it.id; state.q = ''; $('#search').value = ''; setNav(); load(); return;
  }
  const k = kind(it), body = $('#previewBody'), u = rawUrl(it.id);
  $('#previewTitle').innerHTML = `<i data-lucide="${k.ic}" class="${k.cls}"></i><span>${esc(it.name)}</span>`;
  $('#previewDownload').href = rawUrl(it.id, true);
  if (k.t === 'image') body.innerHTML = `<img src="${u}" alt="${esc(it.name)}">`;
  else if (k.t === 'video') body.innerHTML = `<video src="${u}" controls autoplay></video>`;
  else if (k.t === 'audio') body.innerHTML = `<div class="no-preview"><i data-lucide="music"></i><audio src="${u}" controls autoplay></audio></div>`;
  else if (k.t === 'pdf') body.innerHTML = `<iframe src="${u}" title="${esc(it.name)}"></iframe>`;
  else if (k.t === 'text' && it.size < 2e6) { body.innerHTML = '<pre>Loading…</pre>'; fetch(u).then(r => r.text()).then(t => body.innerHTML = `<pre>${esc(t)}</pre>`).catch(() => body.innerHTML = '<pre>Preview unavailable</pre>'); }
  else body.innerHTML = `<div class="no-preview"><i data-lucide="${k.ic}"></i><p>No preview available for this file type</p><p style="color:#9aa3b2">${fmt(it.size)}</p><a class="btn btn-primary" href="${rawUrl(it.id, true)}" target="_blank" rel="noopener"><i data-lucide="download"></i>Download</a></div>`;
  $('#preview').hidden = false; icons();
}
function closePreview() { $('#preview').hidden = true; $('#previewBody').innerHTML = ''; }
$('#previewClose').onclick = closePreview;

/* ---------- context menu ---------- */
function showCtx(it, x, y) {
  const c = $('#ctx'); const trash = state.view === 'trash';
  const opts = trash ? [
    ['rotate-ccw', 'Restore', () => patch(it, { trashed: false }, `Restored “${it.name}”`), 'restore'],
    null,
    ['trash', 'Delete forever', () => confirmDelete(it), 'delete', 'danger'],
  ] : [
    [it.kind === 'folder' ? 'folder-open' : 'eye', it.kind === 'folder' ? 'Open' : 'Preview', () => openItem(it), 'open'],
    ...(it.kind === 'file' ? [['download', 'Download', () => window.open(rawUrl(it.id, true), '_blank', 'noopener'), 'download']] : []),
    null,
    ['pencil', 'Rename', () => renameDialog(it), 'rename'],
    ['folder-input', 'Move to…', () => moveDialog(it), 'move'],
    ['star', it.starred ? 'Remove from Starred' : 'Add to Starred', () => patch(it, { starred: !it.starred }, it.starred ? 'Removed from Starred' : 'Added to Starred'), 'star'],
    ['info', 'Details', () => detailsDialog(it), 'details'],
    null,
    ['trash-2', 'Move to trash', () => patch(it, { trashed: true }, `“${it.name}” moved to trash`, { label: 'Undo', fn: () => patch(it, { trashed: false }) }), 'trash', 'danger'],
  ];
  c.innerHTML = '';
  opts.forEach(o => {
    if (!o) return c.append(document.createElement('hr'));
    const b = document.createElement('button'); b.setAttribute('role', 'menuitem'); b.dataset.testid = `menu-${o[3]}`;
    if (o[4]) b.className = o[4];
    b.innerHTML = `<i data-lucide="${o[0]}"></i>${o[1]}`; b.onclick = () => { hideCtx(); o[2](); }; c.append(b);
  });
  c.hidden = false; icons();
  const r = c.getBoundingClientRect();
  c.style.left = Math.max(8, Math.min(x, innerWidth - r.width - 8)) + 'px';
  c.style.top = Math.max(8, Math.min(y, innerHeight - r.height - 8)) + 'px';
}
function hideCtx() { $('#ctx').hidden = true; }

async function patch(it, body, msg, action) {
  try { await api('/api/items/' + it.id, { method: 'PATCH', body: JSON.stringify(body) }); if (msg) toast(msg, action); load(); }
  catch (e) { toast(e.message); }
}

/* ---------- dialogs ---------- */
function modal(html, onReady) {
  $('#modalCard').innerHTML = html; $('#modal').hidden = false; icons();
  onReady && onReady($('#modalCard'));
}
function closeModal() { $('#modal').hidden = true; }
$('#modal').addEventListener('mousedown', e => { if (e.target.id === 'modal') closeModal(); });

function textDialog(title, value, okLabel, onOk) {
  modal(`<h2>${title}</h2><form id="mf"><input class="field" id="mfIn" value="${esc(value)}" maxlength="240" required data-testid="input-dialog-name" autocomplete="off"><div class="modal-actions"><button type="button" class="btn btn-ghost" id="mfCancel" data-testid="button-dialog-cancel">Cancel</button><button class="btn btn-primary" data-testid="button-dialog-ok">${okLabel}</button></div></form>`, card => {
    const inp = $('#mfIn', card); inp.focus();
    const dot = value.lastIndexOf('.'); inp.setSelectionRange(0, dot > 0 ? dot : value.length);
    $('#mfCancel', card).onclick = closeModal;
    $('#mf', card).onsubmit = async e => { e.preventDefault(); const v = inp.value.trim(); if (!v) return; closeModal(); await onOk(v); };
  });
}
function newFolder() {
  textDialog('New folder', 'Untitled folder', 'Create', async name => {
    try { await api('/api/folders', { method: 'POST', body: JSON.stringify({ name, parent_id: state.view === 'drive' ? state.folder : null }) }); toast(`Folder “${name}” created`); if (state.view !== 'drive') { state.view = 'drive'; state.folder = null; setNav(); } load(); }
    catch (e) { toast(e.message); }
  });
}
function renameDialog(it) { textDialog('Rename', it.name, 'Save', name => patch(it, { name }, 'Renamed')); }

async function moveDialog(it) {
  let folders = [];
  try { folders = await api('/api/folders'); } catch {}
  const byParent = {}; folders.forEach(f => (byParent[f.parent_id || ''] ||= []).push(f));
  const rows = []; const walk = (pid, depth) => (byParent[pid] || []).forEach(f => { if (f.id === it.id) return; rows.push({ ...f, depth }); walk(f.id, depth + 1); });
  walk('', 1);
  let sel = it.parent_id || '';
  modal(`<h2>Move “${esc(it.name)}”</h2><div class="folder-pick" id="fp"><button data-fid="" data-testid="pick-root"><i data-lucide="hard-drive"></i>My Drive</button>${rows.map(f => `<button data-fid="${f.id}" style="padding-left:${10 + f.depth * 16}px" data-testid="pick-${f.id}"><i data-lucide="folder"></i>${esc(f.name)}</button>`).join('')}</div><div class="modal-actions"><button class="btn btn-ghost" id="mvCancel">Cancel</button><button class="btn btn-primary" id="mvOk" data-testid="button-move-confirm">Move here</button></div>`, card => {
    const mark = () => card.querySelectorAll('[data-fid]').forEach(b => b.classList.toggle('sel', b.dataset.fid === sel));
    card.querySelectorAll('[data-fid]').forEach(b => b.onclick = () => { sel = b.dataset.fid; mark(); }); mark();
    $('#mvCancel', card).onclick = closeModal;
    $('#mvOk', card).onclick = () => { closeModal(); patch(it, { move: true, parent_id: sel || null }, 'Moved'); };
  });
}
function detailsDialog(it) {
  const k = kind(it);
  modal(`<h2>Details</h2><ul class="bd-list"><li><i data-lucide="${k.ic}" class="${k.cls}"></i><strong style="overflow-wrap:anywhere">${esc(it.name)}</strong></li><li>Type<span class="v">${it.kind === 'folder' ? 'Folder' : esc(it.mime)}</span></li>${it.kind === 'file' ? `<li>Size<span class="v">${fmt(it.size)} (${it.size.toLocaleString()} bytes)</span></li>` : ''}<li>Created<span class="v">${new Date(it.created_at * 1000).toLocaleString()}</span></li><li>Modified<span class="v">${new Date(it.updated_at * 1000).toLocaleString()}</span></li></ul><div class="modal-actions"><button class="btn btn-ghost" id="dClose">Close</button></div>`, c => $('#dClose', c).onclick = closeModal);
}
function confirmDelete(it) {
  modal(`<h2>Delete forever?</h2><p>“${esc(it.name)}” will be deleted forever and you won't be able to restore it.</p><div class="modal-actions"><button class="btn btn-ghost" id="cdNo">Cancel</button><button class="btn btn-danger" id="cdYes" data-testid="button-confirm-delete">Delete forever</button></div>`, c => {
    $('#cdNo', c).onclick = closeModal;
    $('#cdYes', c).onclick = async () => { closeModal(); try { await api('/api/items/' + it.id, { method: 'DELETE' }); toast('Deleted forever'); load(); } catch (e) { toast(e.message); } };
  });
}
function confirmEmptyTrash() {
  if (!state.items.length) return toast('Trash is already empty');
  modal(`<h2>Empty trash?</h2><p>All ${state.items.length} item${state.items.length > 1 ? 's' : ''} in the trash will be deleted forever.</p><div class="modal-actions"><button class="btn btn-ghost" id="etNo">Cancel</button><button class="btn btn-danger" id="etYes" data-testid="button-confirm-empty">Empty trash</button></div>`, c => {
    $('#etNo', c).onclick = closeModal;
    $('#etYes', c).onclick = async () => { closeModal(); try { await api('/api/trash', { method: 'DELETE' }); toast('Trash emptied'); load(); } catch (e) { toast(e.message); } };
  });
}
async function storageDialog() {
  await loadUsage(); const u = usageData; if (!u) return;
  const cats = [['images', 'Images', 'var(--c-img)'], ['videos', 'Videos', 'var(--c-vid)'], ['audio', 'Audio', 'var(--c-aud)'], ['documents', 'Documents', 'var(--c-doc)'], ['other', 'Other', 'var(--c-oth)']];
  modal(`<h2>Storage</h2><div class="big-num" data-testid="text-storage-used">${fmt(u.used)} <small>of 1 TB used</small></div><p style="margin:4px 0 0">${fmt(u.quota - u.used)} available · ${u.files} file${u.files === 1 ? '' : 's'}</p><div class="bd-bar">${cats.map(([k, , c]) => u.categories[k] ? `<span style="width:${Math.max(0.6, u.categories[k] / u.quota * 100)}%;background:${c}"></span>` : '').join('')}</div><ul class="bd-list">${cats.map(([k, l, c]) => `<li><span class="dot" style="background:${c}"></span>${l}<span class="v">${fmt(u.categories[k])}</span></li>`).join('')}<li><span class="dot" style="background:var(--border)"></span>In trash<span class="v">${fmt(u.trash)}</span></li></ul><div class="modal-actions"><button class="btn btn-ghost" id="sClose">Close</button></div>`, c => $('#sClose', c).onclick = closeModal);
}

/* ---------- uploads ---------- */
let active = 0;
function uploadFiles(files) {
  files = [...files]; if (!files.length) return;
  const total = files.reduce((s, f) => s + f.size, 0);
  if (usageData && usageData.used + total > TB) return toast('Not enough space in your 1 TB drive');
  const parent = state.view === 'drive' ? state.folder : null;
  $('#uploads').hidden = false;
  files.forEach(f => {
    const li = document.createElement('li');
    const k = kind({ kind: 'file', mime: f.type });
    li.innerHTML = `<i data-lucide="${k.ic}" class="${k.cls}"></i><span class="nm" title="${esc(f.name)}">${esc(f.name)}</span><span class="st">0%</span><div class="bar"><span></span></div>`;
    $('#uploadList').prepend(li); icons();
    active++; updTitle();
    const p = new URLSearchParams({ name: f.name }); if (parent) p.set('parent', parent); if (f.type) p.set('mime', f.type);
    const x = new XMLHttpRequest(); x.open('PUT', `${API}/api/upload?${p}`);
    x.upload.onprogress = e => { if (e.lengthComputable) { const pc = Math.round(e.loaded / e.total * 100); li.querySelector('.bar span').style.width = pc + '%'; li.querySelector('.st').textContent = pc + '%'; } };
    x.onload = () => {
      active--; updTitle();
      if (x.status >= 200 && x.status < 300) { li.classList.add('done'); li.querySelector('.st').textContent = fmt(f.size); li.querySelector('.bar span').style.width = '100%'; }
      else { li.classList.add('err'); let m = 'Failed'; try { m = JSON.parse(x.responseText).detail || m; } catch {} li.querySelector('.st').textContent = m; }
      if (state.view === 'drive' && state.folder === parent && !state.q) load(); else loadUsage();
    };
    x.onerror = () => { active--; updTitle(); li.classList.add('err'); li.querySelector('.st').textContent = 'Network error'; };
    x.send(f);
  });
}
function updTitle() { $('#uploadsTitle').textContent = active ? `Uploading ${active} item${active > 1 ? 's' : ''}` : 'Uploads complete'; }
$('#uploadsClose').onclick = () => { $('#uploads').hidden = true; if (!active) $('#uploadList').innerHTML = ''; };
$('#fileInput').onchange = e => { uploadFiles(e.target.files); e.target.value = ''; };

const dz = $('#dropzone'); let dragN = 0;
dz.addEventListener('dragenter', e => { if (![...e.dataTransfer.types].includes('Files')) return; e.preventDefault(); dragN++; $('#dropOverlay').hidden = false; });
dz.addEventListener('dragover', e => { if ([...e.dataTransfer.types].includes('Files')) e.preventDefault(); });
dz.addEventListener('dragleave', () => { if (--dragN <= 0) { dragN = 0; $('#dropOverlay').hidden = true; } });
dz.addEventListener('drop', e => { e.preventDefault(); dragN = 0; $('#dropOverlay').hidden = true; if (state.view === 'trash') { state.view = 'drive'; state.folder = null; setNav(); } uploadFiles(e.dataTransfer.files); });

/* ---------- chrome ---------- */
function setNav() { document.querySelectorAll('.nav-item').forEach(n => n.classList.toggle('active', n.dataset.view === state.view && !state.q)); }
document.querySelectorAll('.nav-item').forEach(n => n.onclick = () => { state.view = n.dataset.view; state.folder = null; state.q = ''; $('#search').value = ''; setNav(); closeSidebar(); load(); });

const newMenu = $('#newMenu');
$('#newBtn').onclick = e => { e.stopPropagation(); newMenu.hidden = !newMenu.hidden; };
newMenu.querySelectorAll('button').forEach(b => b.onclick = () => { newMenu.hidden = true; closeSidebar(); b.dataset.act === 'upload' ? $('#fileInput').click() : newFolder(); });
$('#storageDetails').onclick = () => { closeSidebar(); storageDialog(); };

document.addEventListener('click', e => { if (!e.target.closest('#ctx')) hideCtx(); if (!e.target.closest('#newMenu,#newBtn')) newMenu.hidden = true; });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { hideCtx(); closeModal(); closePreview(); newMenu.hidden = true; closeSidebar(); }
  if (e.key === 'Delete' && state.selected && !e.target.closest('input') && $('#modal').hidden) {
    const it = state.items.find(i => i.id === state.selected); if (!it) return;
    state.view === 'trash' ? confirmDelete(it) : patch(it, { trashed: true }, `“${it.name}” moved to trash`, { label: 'Undo', fn: () => patch(it, { trashed: false }) });
  }
});
$('#content, .content') && $('.content').addEventListener('click', e => { if (!e.target.closest('[data-id]')) select(null); });
window.addEventListener('scroll', hideCtx, true);

let st; $('#search').addEventListener('input', e => { clearTimeout(st); st = setTimeout(() => { state.q = e.target.value.trim(); setNav(); load(); }, 250); });

$('#viewToggle').onclick = () => {
  state.layout = state.layout === 'grid' ? 'list' : 'grid';
  $('#viewToggle').innerHTML = `<i data-lucide="${state.layout === 'grid' ? 'list' : 'layout-grid'}"></i>`;
  $('#viewToggle').setAttribute('aria-label', state.layout === 'grid' ? 'Switch to list view' : 'Switch to grid view');
  render();
};
function applyTheme() { document.documentElement.classList.toggle('dark', state.dark); $('#themeToggle').innerHTML = `<i data-lucide="${state.dark ? 'sun' : 'moon'}"></i>`; icons(); }
$('#themeToggle').onclick = () => { state.dark = !state.dark; applyTheme(); };

function closeSidebar() { $('#sidebar').classList.remove('open'); $('#scrim').hidden = true; }
$('#menuToggle').onclick = () => { $('#sidebar').classList.add('open'); $('#scrim').hidden = false; };
$('#scrim').onclick = closeSidebar;

applyTheme(); load();
})();
