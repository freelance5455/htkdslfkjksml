/* Cross-device chat sync.
   If firebase-config.js is filled in, chats are mirrored through Firebase Realtime Database.
   Otherwise the app falls back to localStorage.
*/
let firebaseReady=false, firebaseDB=null;
const firebaseLoaded = new Promise((resolve)=>{
  const cfg=window.HALLWAY_FIREBASE_CONFIG||{};
  if(!cfg.apiKey || !cfg.databaseURL){ resolve(false); return; }
  const s1=document.createElement('script'); s1.src='https://www.gstatic.com/firebasejs/10.12.5/firebase-app-compat.js';
  s1.onload=()=>{const s2=document.createElement('script'); s2.src='https://www.gstatic.com/firebasejs/10.12.5/firebase-database-compat.js'; s2.onload=()=>{try{firebase.initializeApp(cfg);firebaseDB=firebase.database();firebaseReady=true;resolve(true)}catch(e){console.error(e);resolve(false)}}; s2.onerror=()=>resolve(false); document.head.appendChild(s2)};
  s1.onerror=()=>resolve(false); document.head.appendChild(s1);
});
async function initCloudChats(){
  await firebaseLoaded;
  if(!firebaseReady) return;
  const school=current.schoolCode;
  const ref=firebaseDB.ref('hallwayDrama/chats/'+school);
  const snap=await ref.once('value');
  const data=snap.val()||{};
  if(Object.keys(data).length===0 && chats.length){
    const updates={}; chats.forEach(c=>updates[c.id]=c); await ref.update(updates);
  }
  ref.on('value',snap=>{
    const data=snap.val()||{};
    chats=Object.values(data);
    if(!chats.some(c=>c.id===schoolGroupId)){
      const welcome={id:schoolGroupId,name:'School Group · '+school,type:'school',schoolCode:school,messages:[{user:'Hallway Drama',text:'Welcome to the school group chat! Be respectful and have fun.'}]};
      firebaseDB.ref('hallwayDrama/chats/'+school+'/'+schoolGroupId).set(welcome);
      return;
    }
    if(document.getElementById('chatView')?.classList.contains('active')){renderChats();renderMessages();}
  });
}
function cloudWriteChats(){
  if(!firebaseReady) { write('chats',chats); return; }
  const updates={};
  chats.forEach(c=>{updates[c.id]=c});
  firebaseDB.ref('hallwayDrama/chats/'+current.schoolCode).update(updates).catch(e=>console.error(e));
}

const current=JSON.parse(localStorage.getItem('hallwayDramaCurrentUser')||'null');
if(current && !current.schoolCode) current.schoolCode='21511';
if(!current) location.replace('index.html');
const key=(x)=>'hallwayDrama_'+x;
function read(k,f){try{return JSON.parse(localStorage.getItem(key(k)))??f}catch{return f}}
function write(k,v){localStorage.setItem(key(k),JSON.stringify(v))}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
let posts=read('posts',[]).filter(p=>p.mediaType!=='video');
if(!posts.length){posts=[{id:'welcome',user:'Hallway Drama',school:current.schoolCode,text:'Welcome to Hallway Drama! Keep it fun, respect your classmates, and share what is happening around school.',time:'Just now',likes:0,likedBy:[],comments:[]}];write('posts',posts)}
let chats=read('chats',[]);
const schoolGroupId='school-group-'+current.schoolCode;
if(!chats.some(c=>c.id===schoolGroupId)){
 chats.unshift({
  id:schoolGroupId,
  name:'School Group · '+current.schoolCode,
  type:'school',
  schoolCode:current.schoolCode,
  messages:[{user:'Hallway Drama',text:'Welcome to the school group chat! Be respectful and have fun.'}]
 });
 cloudWriteChats();
}
let activeChat=schoolGroupId, selectedFilter='normal', pendingMedia=null;
initCloudChats();
const feed=document.getElementById('feed');
let commentPostId=null;
function openComments(postId){
 commentPostId=postId;
 const p=posts.find(x=>x.id===postId); if(!p)return;
 const list=document.getElementById('commentsList');
 list.innerHTML=(p.comments||[]).length ? p.comments.map(c=>`<div class="comment-item"><div class="avatar">${esc((c.user||'?')[0].toUpperCase())}</div><div><b>${esc(c.user)}</b><p>${esc(c.text)}</p></div></div>`).join('') : '<p class="empty-comments">No comments yet. Be the first!</p>';
 document.getElementById('commentInput').value='';
 document.getElementById('commentsModal').classList.add('show');
 setTimeout(()=>document.getElementById('commentInput').focus(),50);
}
function submitComment(){
 const input=document.getElementById('commentInput'), txt=input.value.trim();
 const p=posts.find(x=>x.id===commentPostId);
 if(!p||!txt)return;
 p.comments=p.comments||[]; p.comments.push({user:current.username,text:txt});
 write('posts',posts); renderFeed(); openComments(commentPostId);
}


function renderFeed(){
 feed.innerHTML=posts.map(p=>{
  const liked=(p.likedBy||[]).includes(current.username);
  const media=p.media?`<div class="media-wrap"><img class="filter-${esc(p.filter||'normal')}" alt="Post media" src="${p.media}"></div>`:'';
  return `<article class="post ${p.media?'media-post':''}" data-id="${esc(p.id)}"><div class="posthead"><div class="avatar">${esc((p.user||'?')[0].toUpperCase())}</div><div><b>${esc(p.user)}</b><small>${esc(p.time)} · School ${esc(p.school||current.schoolCode)}</small></div></div>${media}<div class="post-content"><p>${esc(p.text)}</p></div><div class="actions"><button class="like ${liked?'liked':''}" data-like="${esc(p.id)}">${liked?'♥':'♡'} ${(p.likedBy||[]).length}</button><button data-comment="${esc(p.id)}">💬 ${(p.comments||[]).length}</button><button data-share="${esc(p.id)}">↗ Share</button></div></article>`
 }).join('');
}
renderFeed();
document.getElementById('welcomeName').textContent=`Welcome, ${current.username}`;
document.getElementById('schoolLabel').textContent=`School ${current.schoolCode}`;
document.getElementById('logoutBtn').onclick=()=>{localStorage.removeItem('hallwayDramaCurrentUser');location.replace('index.html')};

function showView(id){
 document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
 document.getElementById(id).classList.add('active');
 document.querySelectorAll('.bottomnav span').forEach(x=>x.classList.toggle('selected',x.dataset.view===id));
  if(id==='activityView')renderActivity();
 if(id==='chatView')renderChats();
 if(id==='usersView')renderUsers();
 if(id==='profileView')renderProfile();
}
document.querySelectorAll('.bottomnav span').forEach(x=>x.onclick=()=>showView(x.dataset.view));

document.getElementById('newPostBtn').onclick=()=>document.getElementById('composer').classList.toggle('hidden');
document.getElementById('cancelPost').onclick=()=>{document.getElementById('composer').classList.add('hidden');pendingMedia=null;document.getElementById('mediaPreview').innerHTML=''};
document.querySelectorAll('.filters button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filters button').forEach(x=>x.classList.remove('active'));b.classList.add('active');selectedFilter=b.dataset.filter;previewMedia()});
document.getElementById('mediaFile').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>4*1024*1024){alert('For this offline build, keep media under 4 MB.');e.target.value='';return}const r=new FileReader();r.onload=()=>{pendingMedia={data:r.result,type:'image'};previewMedia()};r.readAsDataURL(f)};
function previewMedia(){const el=document.getElementById('mediaPreview');if(!pendingMedia){el.innerHTML='';return}el.innerHTML=`<img style="width:100%;max-height:300px;object-fit:cover;border-radius:12px" class="filter-${selectedFilter}" src="${pendingMedia.data}">`};
document.getElementById('refreshBtn').onclick=()=>{posts=read('posts',[]).filter(p=>p.mediaType!=='video');renderFeed()};

feed.onclick=e=>{
 const like=e.target.closest('[data-like]');
 if(like){const p=posts.find(x=>x.id===like.dataset.like);if(p){p.likedBy=p.likedBy||[];const i=p.likedBy.indexOf(current.username);if(i<0)p.likedBy.push(current.username);else p.likedBy.splice(i,1);write('posts',posts);renderFeed()}}
 const c=e.target.closest('[data-comment]');
 if(c){openComments(c.dataset.comment)}
 const s=e.target.closest('[data-share]');
 if(s){navigator.clipboard?.writeText(location.href);alert('Post link copied.')}
};

function renderActivity(){
 const mine=posts.filter(p=>(p.likedBy||[]).includes(current.username)|| (p.comments||[]).some(c=>c.user===current.username));
 document.getElementById('activityList').innerHTML=mine.length?mine.map(p=>`<div class="list-item"><div class="avatar">${esc((p.user||'?')[0])}</div><div class="grow"><b>${esc(p.user)}</b><small>${(p.likedBy||[]).includes(current.username)?'You liked this post.':''} ${(p.comments||[]).some(c=>c.user===current.username)?'You commented on this post.':''}</small></div></div>`).join(''):'<div class="card">No activity yet.</div>';
}

function getUsers(){try{return JSON.parse(localStorage.getItem('hallwayDramaUsers')||'[]')}catch{return []}}
function renderUsers(){
 const list=document.getElementById('usersList'); if(!list)return;
 const users=getUsers().filter(u=>String(u.schoolCode||current.schoolCode)===String(current.schoolCode));
 list.innerHTML=users.length?users.map(u=>`<button class="user-card" data-user-id="${esc(u.id)}"><div class="avatar">${esc((u.username||'?')[0].toUpperCase())}</div><div><b>${esc(u.username)}</b><small>School ${esc(u.schoolCode||current.schoolCode)}</small></div><span>💬</span></button>`).join(''):'<div class="card">No other users found on this device yet.</div>';
 list.querySelectorAll('[data-user-id]').forEach(b=>b.onclick=()=>{
   const u=users.find(x=>x.id===b.dataset.userId); if(!u||u.id===current.id)return;
   const existing=chats.find(c=>c.type==='private' && ((c.userA===current.id&&c.userB===u.id)||(c.userA===u.id&&c.userB===current.id)));
   if(existing) activeChat=existing.id;
   else {const id=crypto.randomUUID?crypto.randomUUID():String(Date.now()); const c={id,name:u.username,type:'private',userA:current.id,userB:u.id,messages:[]}; chats.push(c); write('chats',chats); activeChat=id;}
   showView('chatView'); renderChats(); renderMessages();
 });
}
function renderChats(){
 const list=document.getElementById('chatList');
 if(!chats.length)list.innerHTML='<div style="padding:15px;color:#9fb9dc">No chats yet.</div>';
 else list.innerHTML=chats.map(c=>`<button class="chat-choice ${activeChat===c.id?'active':''}" data-chat="${c.id}">💬 <b>${esc(c.name)}</b><small>${c.type==='private'?'Private':c.type==='school'?'School-wide group':'Group chat'}</small></button>`).join('');
 list.querySelectorAll('[data-chat]').forEach(b=>b.onclick=()=>{activeChat=b.dataset.chat;renderChats();renderMessages()});
}
function renderMessages(){
 const c=chats.find(x=>x.id===activeChat);
 document.getElementById('chatTitle').textContent=c?`${c.name} · ${c.type==='private'?'Private':c.type==='school'?'School-wide':'Group'}`:'Select a chat';
 document.getElementById('messages').innerHTML=c?(c.messages||[]).map(m=>`<div class="bubble ${m.user===current.username?'me':''}">${esc(m.text)}<small>${esc(m.user)}</small></div>`).join(''):'';
 const box=document.getElementById('messages');box.scrollTop=box.scrollHeight;
}
document.getElementById('sendMessage').onclick=sendMessage;
document.getElementById('chatInput').onkeydown=e=>{if(e.key==='Enter')sendMessage()};
function sendMessage(){const inp=document.getElementById('chatInput'),t=inp.value.trim(),c=chats.find(x=>x.id===activeChat);if(!c||!t)return;c.messages=c.messages||[];c.messages.push({user:current.username,text:t});cloudWriteChats();inp.value='';renderMessages();renderChats()}
document.getElementById('newChatBtn').onclick=()=>document.getElementById('chatModal').classList.add('show');
document.getElementById('createChat').onclick=()=>{const name=document.getElementById('chatName').value.trim();if(!name)return;chats.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),name,type:document.getElementById('chatType').value,messages:[]});write('chats',chats);document.getElementById('chatName').value='';document.getElementById('chatModal').classList.remove('show');activeChat=chats.at(-1).id;renderChats();renderMessages()};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>document.getElementById(b.dataset.close).classList.remove('show'));

function renderProfile(){
 document.getElementById('profileName').textContent=current.username;
 document.getElementById('profileSchool').textContent='School '+current.schoolCode;
 document.getElementById('bigAvatar').textContent=current.username[0].toUpperCase();
 const mine=posts.filter(p=>p.user===current.username);
 document.getElementById('postCount').textContent=mine.length;
 document.getElementById('likeCount').textContent=mine.reduce((n,p)=>n+(p.likedBy||[]).length,0);
}
document.getElementById('editProfile').onclick=()=>{document.getElementById('editUsername').value=current.username;document.getElementById('editModal').classList.add('show')};
document.getElementById('saveProfile').onclick=()=>{const n=document.getElementById('editUsername').value.trim();if(!n)return;current.username=n;localStorage.setItem('hallwayDramaCurrentUser',JSON.stringify(current));const users=JSON.parse(localStorage.getItem('hallwayDramaUsers')||'[]');const u=users.find(x=>x.id===current.id);if(u)u.username=n;localStorage.setItem('hallwayDramaUsers',JSON.stringify(users));document.getElementById('editModal').classList.remove('show');document.getElementById('welcomeName').textContent='Welcome, '+n;renderProfile()};


document.getElementById('sendComment')?.addEventListener('click',submitComment);
document.getElementById('commentInput')?.addEventListener('keydown',e=>{if(e.key==='Enter')submitComment()});
