/* Stockly v1 — ELITES CAFÉ offline PWA */
const KEY = 'stockly_elites_v1';

const DEFAULT_MENU = [
  // Ingredients / raw
  { name: 'Bread loaf', cat: 'Ingredients', type: 'Ingredient', cost: 18, sell: 0, unit: 'loaf', stock: 8, low: 2, supplier: 'Bakery' },
  { name: 'Polony', cat: 'Ingredients', type: 'Ingredient', cost: 1, sell: 1, unit: 'slice', stock: 120, low: 20, supplier: 'ABC Foods' },
  { name: 'Russian', cat: 'Ingredients', type: 'Ingredient', cost: 8, sell: 10, unit: 'unit', stock: 40, low: 10, supplier: 'ABC Foods' },
  { name: 'Vienna', cat: 'Ingredients', type: 'Ingredient', cost: 5, sell: 0, unit: 'unit', stock: 35, low: 8, supplier: 'ABC Foods' },
  { name: 'Cheese', cat: 'Ingredients', type: 'Ingredient', cost: 2.5, sell: 3, unit: 'slice', stock: 80, low: 15, supplier: 'ABC Foods' },
  { name: 'Atchaar', cat: 'Ingredients', type: 'Ingredient', cost: 0.8, sell: 0, unit: 'portion', stock: 60, low: 12, supplier: 'Local' },
  { name: 'Chakalaka', cat: 'Ingredients', type: 'Ingredient', cost: 0.9, sell: 0, unit: 'portion', stock: 50, low: 12, supplier: 'Local' },
  { name: 'Chicken pattie', cat: 'Ingredients', type: 'Ingredient', cost: 12, sell: 0, unit: 'unit', stock: 25, low: 8, supplier: 'Butcher' },
  { name: 'Beef pattie', cat: 'Ingredients', type: 'Ingredient', cost: 14, sell: 0, unit: 'unit', stock: 20, low: 6, supplier: 'Butcher' },
  { name: 'Bun', cat: 'Ingredients', type: 'Ingredient', cost: 3, sell: 0, unit: 'unit', stock: 40, low: 10, supplier: 'Bakery' },
  { name: 'Lettuce', cat: 'Ingredients', type: 'Ingredient', cost: 0.5, sell: 0, unit: 'portion', stock: 40, low: 10, supplier: 'Market' },
  { name: 'Tomato', cat: 'Ingredients', type: 'Ingredient', cost: 0.4, sell: 0, unit: 'slice', stock: 80, low: 20, supplier: 'Market' },
  { name: 'Onion', cat: 'Ingredients', type: 'Ingredient', cost: 0.3, sell: 0, unit: 'portion', stock: 50, low: 12, supplier: 'Market' },
  { name: 'Potatoes', cat: 'Ingredients', type: 'Ingredient', cost: 0.02, sell: 0, unit: 'g', stock: 12000, low: 2000, supplier: 'Market' },
  { name: 'Oil', cat: 'Ingredients', type: 'Ingredient', cost: 0.01, sell: 0, unit: 'ml', stock: 5000, low: 800, supplier: 'Wholesale' },
  { name: 'Packaging', cat: 'Packaging', type: 'Packaging', cost: 1.2, sell: 0, unit: 'unit', stock: 100, low: 20, supplier: 'PackCo' },
  // Menu products
  { name: 'Kota R15', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 15, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Kota R20', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Kota R25', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 25, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Kota R30', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 30, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Kota R35', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Kota R40', cat: 'Kota', type: 'Menu Product', cost: 0, sell: 40, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Plain Hotdog', cat: 'Hotdogs', type: 'Menu Product', cost: 0, sell: 10, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Hotdog Lettuce & Cheese', cat: 'Hotdogs', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Chips Small', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 20, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Chips Medium', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 30, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Chips Large', cat: 'Chips', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Chicken Burger', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Beef Burger', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 40, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Chicken Burger + Chips', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 50, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Beef Burger + Chips', cat: 'Burgers', type: 'Menu Product', cost: 0, sell: 55, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Club Sandwich', cat: 'Sandwiches', type: 'Menu Product', cost: 0, sell: 35, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  // Extras (sold as add-ons)
  { name: 'Extra Polony', cat: 'Extras', type: 'Other', cost: 1, sell: 1, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Extra Special', cat: 'Extras', type: 'Other', cost: 1.5, sell: 2, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Extra Cheese', cat: 'Extras', type: 'Other', cost: 2.5, sell: 3, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
  { name: 'Extra Russian', cat: 'Extras', type: 'Other', cost: 8, sell: 10, unit: 'unit', stock: 0, low: 0, supplier: '', recipe: true },
];

// Recipes keyed by product name → [{ing, qty}]
const DEFAULT_RECIPES = {
  'Kota R15': [['Bread loaf', 0.15], ['Polony', 2], ['Atchaar', 1], ['Packaging', 1]],
  'Kota R20': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Vienna', 1], ['Packaging', 1]],
  'Kota R25': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Russian', 1], ['Packaging', 1]],
  'Kota R30': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Packaging', 1]],
  'Kota R35': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Vienna', 1], ['Packaging', 1]],
  'Kota R40': [['Bread loaf', 0.2], ['Polony', 2], ['Atchaar', 1], ['Cheese', 1], ['Russian', 1], ['Chicken pattie', 1], ['Vienna', 1], ['Packaging', 1]],
  'Plain Hotdog': [['Bun', 1], ['Vienna', 1], ['Packaging', 1]],
  'Hotdog Lettuce & Cheese': [['Bun', 1], ['Vienna', 1], ['Lettuce', 1], ['Cheese', 1], ['Packaging', 1]],
  'Chips Small': [['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Chips Medium': [['Potatoes', 250], ['Oil', 30], ['Packaging', 1]],
  'Chips Large': [['Potatoes', 350], ['Oil', 40], ['Packaging', 1]],
  'Chicken Burger': [['Bun', 1], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Packaging', 1]],
  'Beef Burger': [['Bun', 1], ['Beef pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Packaging', 1]],
  'Chicken Burger + Chips': [['Bun', 1], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Beef Burger + Chips': [['Bun', 1], ['Beef pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Onion', 1], ['Potatoes', 150], ['Oil', 20], ['Packaging', 1]],
  'Club Sandwich': [['Bread loaf', 0.25], ['Chicken pattie', 1], ['Cheese', 1], ['Lettuce', 1], ['Tomato', 2], ['Packaging', 1]],
  'Extra Polony': [['Polony', 1]],
  'Extra Special': [['Polony', 1], ['Atchaar', 1]],
  'Extra Cheese': [['Cheese', 1]],
  'Extra Russian': [['Russian', 1]],
};

function uid(p = 'id') {
  return p + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
}

function seed() {
  const items = DEFAULT_MENU.map(m => ({
    id: uid('it'),
    name: m.name,
    cat: m.cat,
    type: m.type,
    cost: m.cost,
    sell: m.sell,
    unit: m.unit,
    stock: m.stock,
    low: m.low,
    supplier: m.supplier || '',
    notes: '',
    archived: false,
    costHistory: [{ date: iso(), cost: m.cost }],
  }));
  const byName = Object.fromEntries(items.map(i => [i.name, i.id]));
  const recipes = {};
  Object.entries(DEFAULT_RECIPES).forEach(([prod, lines]) => {
    const pid = byName[prod];
    if (!pid) return;
    recipes[pid] = lines.map(([n, q]) => ({ itemId: byName[n], qty: q })).filter(x => x.itemId);
  });
  // compute recipe costs
  items.forEach(it => {
    if (recipes[it.id]) it.cost = recipeCost(it.id, items, recipes);
  });
  return {
    settings: {
      cafe: 'ELITES CAFÉ',
      currency: 'ZAR',
      locale: 'en-ZA',
      dailyTarget: 1500,
      monthlyTarget: 30000,
      theme: 'Emerald',
      float: 300,
      fixedMonthly: 5500,
    },
    items,
    recipes,
    movements: [],
    sales: [],
    expenses: [],
    book: [],
    workers: [
      { id: uid('wk'), name: 'Worker 1', role: 'Kitchen', payType: 'Daily', rate: 120, active: true },
      { id: uid('wk'), name: 'Worker 2', role: 'Front', payType: 'Daily', rate: 100, active: true },
    ],
    attendance: {},
    payments: [],
    suppliers: [
      { id: uid('sp'), name: 'ABC Foods', contact: '', notes: '' },
      { id: uid('sp'), name: 'Bakery', contact: '', notes: '' },
    ],
    customers: [],
    waste: [],
    closings: [],
    goals: { monthlySales: 30000, monthlyProfit: 8000 },
    notes: [],
  };
}

let data = null;
try {
  data = JSON.parse(localStorage.getItem(KEY) || 'null');
} catch (_) {}
if (!data || !Array.isArray(data.items) || !data.items.length) {
  data = seed();
  save();
}

function save() {
  localStorage.setItem(KEY, JSON.stringify(data));
}

function today() { return new Date(); }
function iso(d = today()) {
  const y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, '0'), day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}
function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function M(n) {
  try {
    return new Intl.NumberFormat(data.settings.locale || 'en-ZA', {
      style: 'currency', currency: data.settings.currency || 'ZAR', maximumFractionDigits: 2
    }).format(Number(n) || 0);
  } catch {
    return 'R' + Number(n || 0).toLocaleString('en-ZA', { maximumFractionDigits: 2 });
  }
}
function toast(t) {
  const x = document.getElementById('toast');
  x.textContent = t;
  x.classList.add('show');
  setTimeout(() => x.classList.remove('show'), 1700);
}
function itemById(id) { return (data.items || []).find(i => i.id === id); }
function itemByName(name) { return (data.items || []).find(i => i.name === name && !i.archived); }

function recipeCost(productId, items = data.items, recipes = data.recipes) {
  const lines = recipes[productId] || [];
  return lines.reduce((s, l) => {
    const it = items.find(x => x.id === l.itemId);
    return s + (it ? Number(it.cost) * Number(l.qty) : 0);
  }, 0);
}

function refreshMenuCosts() {
  data.items.forEach(it => {
    if (data.recipes[it.id] && data.recipes[it.id].length) {
      it.cost = recipeCost(it.id);
    }
  });
}

function activeItems() {
  return (data.items || []).filter(i => !i.archived);
}

function stockValue() {
  return activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging' || i.type === 'Drink')
    .reduce((s, i) => s + Number(i.stock) * Number(i.cost), 0);
}

function lowStock() {
  return activeItems().filter(i => (i.type === 'Ingredient' || i.type === 'Packaging') && i.low > 0 && i.stock > 0 && i.stock <= i.low);
}
function outStock() {
  return activeItems().filter(i => (i.type === 'Ingredient' || i.type === 'Packaging') && i.stock <= 0);
}

function salesOn(date) {
  return (data.sales || []).filter(s => s.date === date && s.status === 'confirmed');
}

function dayTotals(date = iso()) {
  const list = salesOn(date);
  let revenue = 0, cogs = 0, items = 0;
  list.forEach(s => {
    revenue += Number(s.revenue || 0);
    cogs += Number(s.cogs || 0);
    items += (s.lines || []).reduce((n, l) => n + Number(l.qty || 0), 0);
  });
  const expenses = (data.expenses || []).filter(e => e.date === date).reduce((s, e) => s + Number(e.amount || 0), 0);
  const wasteCost = (data.waste || []).filter(w => w.date === date).reduce((s, w) => s + Number(w.cost || 0), 0);
  const gross = revenue - cogs;
  const net = gross - expenses - wasteCost;
  return { revenue, cogs, gross, expenses, wasteCost, net, items, count: list.length };
}

function addMovement(itemId, qty, reason, meta = {}) {
  const it = itemById(itemId);
  if (!it) return;
  it.stock = Number(it.stock || 0) + Number(qty);
  data.movements.unshift({
    id: uid('mv'), date: iso(), time: new Date().toISOString(),
    itemId, name: it.name, qty: Number(qty), reason, ...meta
  });
}

function bookEntry(type, category, amount, note, date = iso()) {
  data.book.unshift({
    id: uid('bk'), date, type, category, amount: Number(amount), note: note || ''
  });
}

function canFulfill(productId, qty) {
  const lines = data.recipes[productId] || [];
  if (!lines.length) return { ok: true, missing: [] };
  const missing = [];
  lines.forEach(l => {
    const it = itemById(l.itemId);
    const need = Number(l.qty) * Number(qty);
    if (!it || it.stock < need - 1e-9) {
      missing.push({ name: it?.name || 'Unknown', need, have: it?.stock || 0 });
    }
  });
  return { ok: missing.length === 0, missing };
}

function deductRecipe(productId, qty, reason = 'SALE') {
  const lines = data.recipes[productId] || [];
  lines.forEach(l => addMovement(l.itemId, -Number(l.qty) * Number(qty), reason, { productId }));
}

function sellLines(lines, payment = 'Cash', date = iso(), confirm = true) {
  // lines: [{itemId, qty, variation?}]
  let revenue = 0, cogs = 0;
  const detail = [];
  const missingAll = [];
  lines.forEach(l => {
    const it = itemById(l.itemId);
    if (!it || !l.qty) return;
    const check = canFulfill(l.itemId, l.qty);
    if (!check.ok) missingAll.push(...check.missing.map(m => ({ ...m, product: it.name })));
    const unitCost = data.recipes[it.id]?.length ? recipeCost(it.id) : Number(it.cost);
    const unitSell = Number(it.sell);
    revenue += unitSell * l.qty;
    cogs += unitCost * l.qty;
    detail.push({
      itemId: it.id, name: it.name, qty: l.qty,
      sell: unitSell, cost: unitCost, variation: l.variation || null
    });
  });
  if (missingAll.length && confirm) {
    return { ok: false, missing: missingAll };
  }
  const sale = {
    id: uid('sl'), date, payment, status: confirm ? 'confirmed' : 'draft',
    lines: detail, revenue, cogs, gross: revenue - cogs
  };
  if (confirm) {
    detail.forEach(l => {
      if (data.recipes[l.itemId]?.length) deductRecipe(l.itemId, l.qty, 'SALE');
      else if (l.qty) addMovement(l.itemId, -l.qty, 'SALE');
    });
    data.sales.unshift(sale);
    bookEntry('Income', 'Sales', revenue, 'Sale ' + sale.id, date);
    bookEntry('Cost of sales', 'COGS', cogs, 'COGS ' + sale.id, date);
    save();
  }
  return { ok: true, sale, missing: missingAll };
}

function healthScore() {
  const t = dayTotals();
  const target = Number(data.settings.dailyTarget) || 1500;
  const salesPart = Math.round(Math.min(1, t.revenue / Math.max(1, target)) * 25);
  const margin = t.revenue ? t.gross / t.revenue : 0;
  const profitPart = Math.round(Math.min(1, Math.max(0, margin) / 0.45) * 25);
  const low = lowStock().length, out = outStock().length;
  const stockPart = Math.round(Math.max(0, 25 - out * 8 - low * 2));
  const monthWaste = (data.waste || []).filter(w => w.date.slice(0, 7) === iso().slice(0, 7))
    .reduce((s, w) => s + Number(w.cost || 0), 0);
  const wastePart = Math.round(Math.max(0, 25 - Math.min(25, monthWaste / 40)));
  const total = salesPart + profitPart + stockPart + wastePart;
  return {
    total,
    parts: { sales: salesPart, profit: profitPart, stock: stockPart, waste: wastePart },
    label: total >= 80 ? 'Strong' : total >= 60 ? 'Healthy' : total >= 40 ? 'Fair' : 'Needs attention'
  };
}

function encouragement() {
  const t = dayTotals();
  const target = Number(data.settings.dailyTarget) || 1500;
  const low = lowStock().length, out = outStock().length;
  if (out > 0) return 'Stock warning: A sale you cannot fulfil is a missed opportunity. Check out-of-stock items.';
  if (low > 3) return 'Stock watch: Several items are running low. Restock before the rush.';
  if (t.revenue >= target) return 'Strong day: Sales are above target. Protect stock levels so tomorrow starts smoothly.';
  if (t.revenue > 0 && t.revenue < target * 0.4) return 'Slow day: One slow day does not define the business. Review which products moved.';
  const pool = [
    'A business grows through ordinary days handled well. Keep the records clean and the stock moving.',
    'Know your stock. Know your sales. Know your business.',
    'Small consistent margins beat guessing at the till.',
    'Confirm the day cleanly — tomorrow’s decisions depend on today’s numbers.'
  ];
  return pool[today().getDate() % pool.length];
}

function breakEven() {
  const fixed = Number(data.settings.fixedMonthly) || 5500;
  // average margin from last 30 confirmed sales or default 42%
  const recent = (data.sales || []).filter(s => s.status === 'confirmed').slice(0, 60);
  let rev = 0, cogs = 0;
  recent.forEach(s => { rev += s.revenue; cogs += s.cogs; });
  const margin = rev > 0 ? (rev - cogs) / rev : 0.42;
  const monthly = margin > 0 ? fixed / margin : 0;
  const daily = monthly / 30;
  return { fixed, margin, monthly, daily };
}

/* ---------- UI helpers ---------- */
function closeModal() {
  const m = document.getElementById('modal');
  if (m) m.remove();
}
function openModal(title, body, onSubmit) {
  closeModal();
  const el = document.createElement('div');
  el.id = 'modal';
  el.innerHTML = `
    <div class="modal-backdrop" data-x="1"></div>
    <div class="modal-card">
      <div class="modal-head">
        <strong>${esc(title)}</strong>
        <button type="button" class="btn" data-x="1" style="padding:8px 10px">Close</button>
      </div>
      <form id="modalForm" class="form">${body}
        ${onSubmit ? '<button type="submit" class="btn primary">Save</button>' : ''}
      </form>
    </div>`;
  document.body.appendChild(el);
  el.querySelectorAll('[data-x]').forEach(b => b.onclick = closeModal);
  if (onSubmit) {
    document.getElementById('modalForm').onsubmit = e => {
      e.preventDefault();
      if (onSubmit(e) !== false) closeModal();
    };
  }
}

let stockFilter = 'ALL';
let eodDraft = {};

/* ---------- SCREENS ---------- */
function home() {
  const t = dayTotals();
  const h = healthScore();
  const low = lowStock(), out = outStock();
  const target = Number(data.settings.dailyTarget) || 1500;
  const pct = Math.min(100, Math.round(t.revenue / Math.max(1, target) * 100));
  const be = breakEven();
  const d = today();
  document.getElementById('home').innerHTML = `
    <div class="title">${esc(data.settings.cafe || 'ELITES CAFÉ')}</div>
    <div class="quote">${esc(encouragement())}</div>
    <div class="card">
      <h2>TODAY</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Sales</div><div class="val green">${M(t.revenue)}</div></div>
        <div class="stat"><div class="lbl">Gross profit</div><div class="val accent">${M(t.gross)}</div></div>
        <div class="stat"><div class="lbl">Expenses</div><div class="val orange">${M(t.expenses)}</div></div>
        <div class="stat"><div class="lbl">Net profit</div><div class="val ${t.net >= 0 ? 'green' : 'red'}">${M(t.net)}</div></div>
      </div>
    </div>
    <div class="card">
      <h2>STOCK SNAPSHOT</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Stock value</div><div class="val">${M(stockValue())}</div></div>
        <div class="stat"><div class="lbl">Tracked items</div><div class="val">${activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging').length}</div></div>
        <div class="stat"><div class="lbl">Low stock</div><div class="val yellow">${low.length}</div></div>
        <div class="stat"><div class="lbl">Out of stock</div><div class="val red">${out.length}</div></div>
      </div>
    </div>
    <div class="card">
      <h2>TODAY'S TARGET · ${M(target)}</h2>
      <div class="med">${M(t.revenue)} <span class="small">(${pct}%)</span></div>
      <div class="progress"><i style="width:${pct}%"></i></div>
    </div>
    <div class="card">
      <h2>BUSINESS HEALTH · ${h.total}/100 · ${h.label}</h2>
      <div class="progress"><i style="width:${h.total}%"></i></div>
      <div class="small">Sales ${h.parts.sales}/25 · Profit ${h.parts.profit}/25 · Stock ${h.parts.stock}/25 · Waste ${h.parts.waste}/25</div>
    </div>
    <div class="card">
      <h2>BREAK-EVEN</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Daily break-even</div><div class="val">${M(be.daily)}</div></div>
        <div class="stat"><div class="lbl">Above / below</div><div class="val ${t.revenue >= be.daily ? 'green' : 'red'}">${M(t.revenue - be.daily)}</div></div>
      </div>
      <div class="small" style="margin-top:6px">Margin ≈ ${(be.margin * 100).toFixed(0)}% · Fixed monthly ${M(be.fixed)}</div>
    </div>
    <div class="card">
      <h2>ALERTS</h2>
      ${[
        low.length ? `<div class="item"><span>${low.length} low-stock items</span><span class="badge low">LOW</span></div>` : '',
        out.length ? `<div class="item"><span>${out.length} out of stock</span><span class="badge out">OUT</span></div>` : '',
        !low.length && !out.length ? '<div class="small">No critical stock alerts.</div>' : ''
      ].join('')}
      <div class="row" style="margin-top:8px">
        <button class="btn" data-go="stock">Open stock</button>
        <button class="btn primary" data-go="sales">Record sales</button>
      </div>
    </div>`;
}

function stock() {
  const filters = ['ALL', 'Ingredients', 'Menu', 'Low', 'Out', 'Moves', 'Waste'];
  let list = activeItems();
  if (stockFilter === 'Ingredients') list = list.filter(i => i.type === 'Ingredient' || i.type === 'Packaging');
  else if (stockFilter === 'Menu') list = list.filter(i => i.type === 'Menu Product' || i.cat === 'Extras');
  else if (stockFilter === 'Low') list = lowStock();
  else if (stockFilter === 'Out') list = outStock();

  let body = '';
  if (stockFilter === 'Moves') {
    body = (data.movements || []).slice(0, 40).map(m => `
      <div class="item">
        <div><b>${esc(m.name)}</b><div class="small">${esc(m.reason)} · ${esc(m.date)}</div></div>
        <b class="${m.qty >= 0 ? 'green' : 'orange'}">${m.qty >= 0 ? '+' : ''}${m.qty}</b>
      </div>`).join('') || '<div class="empty">No movements yet.</div>';
  } else if (stockFilter === 'Waste') {
    body = `
      <button class="btn primary" data-action="waste-add" style="margin-bottom:8px">Record waste</button>
      ${(data.waste || []).slice(0, 30).map(w => `
        <div class="item">
          <div><b>${esc(w.name)} × ${w.qty}</b><div class="small">${esc(w.reason)} · ${esc(w.date)}</div></div>
          <b class="red">${M(w.cost)}</b>
        </div>`).join('') || '<div class="empty">No waste recorded.</div>'}`;
  } else {
    body = list.map(i => {
      const isIng = i.type === 'Ingredient' || i.type === 'Packaging';
      const margin = i.sell > 0 ? ((i.sell - i.cost) / i.sell * 100) : null;
      let badge = '';
      if (isIng && i.stock <= 0) badge = '<span class="badge out">OUT</span>';
      else if (isIng && i.low > 0 && i.stock <= i.low) badge = '<span class="badge low">LOW</span>';
      return `
        <div class="item" style="flex-wrap:wrap">
          <div style="flex:1;min-width:140px">
            <b>${esc(i.name)}</b> ${badge}
            <div class="small">${esc(i.cat)} · ${esc(i.type)}
              ${isIng ? ` · stock ${i.stock} ${esc(i.unit)}` : ''}
              ${i.sell ? ` · sell ${M(i.sell)}` : ''}
              ${i.cost ? ` · cost ${M(i.cost)}` : ''}
              ${margin != null ? ` · ${margin.toFixed(0)}%` : ''}
            </div>
          </div>
          <div class="row" style="width:100%;margin-top:6px">
            <button class="btn" data-action="item-edit" data-id="${i.id}">Edit</button>
            ${isIng ? `<button class="btn" data-action="restock" data-id="${i.id}">Restock</button>` : ''}
            <button class="btn danger" data-action="item-del" data-id="${i.id}">Archive</button>
          </div>
        </div>`;
    }).join('') || '<div class="empty">No items in this view.</div>';
  }

  document.getElementById('stock').innerHTML = `
    <div class="title">Stock</div>
    <div class="chips">
      ${filters.map(f => `<button type="button" class="chip ${stockFilter === f ? 'on' : ''}" data-action="stock-filter" data-f="${f}">${f}</button>`).join('')}
    </div>
    <div class="row" style="margin-bottom:10px">
      <button class="btn primary" data-action="item-add">Add item</button>
      <button class="btn" data-action="stock-count">Stock count</button>
    </div>
    ${body}`;
}

function sales() {
  const menu = activeItems().filter(i => i.sell > 0 && (i.type === 'Menu Product' || i.cat === 'Extras'));
  const groups = {};
  menu.forEach(i => {
    groups[i.cat] = groups[i.cat] || [];
    groups[i.cat].push(i);
  });
  const t = dayTotals();
  document.getElementById('sales').innerHTML = `
    <div class="title">Sales</div>
    <div class="card">
      <h2>TODAY</h2>
      <div class="grid3">
        <div class="stat"><div class="lbl">Revenue</div><div class="val green">${M(t.revenue)}</div></div>
        <div class="stat"><div class="lbl">COGS</div><div class="val orange">${M(t.cogs)}</div></div>
        <div class="stat"><div class="lbl">Gross</div><div class="val accent">${M(t.gross)}</div></div>
      </div>
      <div class="small" style="margin-top:6px">${t.items} items · ${t.count} tickets</div>
    </div>
    <div class="card">
      <h2>QUICK SALE</h2>
      <form class="form" id="quickSale">
        <select id="qsItem">${menu.map(i => `<option value="${i.id}">${esc(i.name)} · ${M(i.sell)}</option>`).join('')}</select>
        <div class="row">
          <input id="qsQty" type="number" min="1" step="1" value="1" required>
          <select id="qsPay"><option>Cash</option><option>Card</option><option>EFT</option><option>Other</option></select>
        </div>
        <label class="small">Variation (e.g. Atchaar / Chakalaka)
          <select id="qsVar"><option value="">None</option><option>Atchaar</option><option>Chakalaka</option></select>
        </label>
        <button class="btn primary" type="submit">Sell now</button>
      </form>
    </div>
    <div class="card">
      <h2>END OF DAY</h2>
      <div class="small" style="margin-bottom:8px">Enter quantities sold, then calculate and confirm. Stock and books update together.</div>
      ${Object.entries(groups).map(([cat, items]) => `
        <div style="margin:10px 0 4px;font-size:12px;font-weight:800;color:var(--muted)">${esc(cat)}</div>
        ${items.map(i => `
          <div class="item">
            <div><b>${esc(i.name)}</b><div class="small">${M(i.sell)}</div></div>
            <div class="qty">
              <button type="button" data-action="eod-dec" data-id="${i.id}">−</button>
              <input type="number" min="0" step="1" value="${eodDraft[i.id] || 0}" data-eod="${i.id}" style="width:52px;text-align:center;padding:8px">
              <button type="button" data-action="eod-inc" data-id="${i.id}">+</button>
            </div>
          </div>`).join('')}
      `).join('')}
      <div class="row" style="margin-top:10px">
        <button class="btn" data-action="eod-calc">Calculate day</button>
        <button class="btn primary" data-action="eod-confirm">Confirm day</button>
      </div>
      <div id="eodPreview" class="small" style="margin-top:8px"></div>
    </div>
    <div class="card">
      <h2>RECENT SALES</h2>
      ${(data.sales || []).slice(0, 15).map(s => `
        <div class="item">
          <div><b>${M(s.revenue)}</b><div class="small">${esc(s.date)} · ${esc(s.payment)} · ${(s.lines || []).length} lines</div></div>
          <span class="badge ok">OK</span>
        </div>`).join('') || '<div class="empty">No sales yet.</div>'}
    </div>`;

  const form = document.getElementById('quickSale');
  if (form) form.onsubmit = e => {
    e.preventDefault();
    const id = document.getElementById('qsItem').value;
    const qty = Number(document.getElementById('qsQty').value) || 0;
    const payment = document.getElementById('qsPay').value;
    const variation = document.getElementById('qsVar').value || null;
    const res = sellLines([{ itemId: id, qty, variation }], payment);
    if (!res.ok) {
      toast('Insufficient stock for recipe');
      openModal('Cannot complete sale', `<div class="warn">${res.missing.map(m => `${esc(m.name)}: need ${m.need}, have ${m.have}`).join('<br>')}</div>
        <button type="button" class="btn" data-x="1">Close</button>`, null);
      document.querySelectorAll('#modal [data-x]').forEach(b => b.onclick = closeModal);
      return;
    }
    toast('Sale recorded');
    sales(); home();
  };

  document.querySelectorAll('[data-eod]').forEach(inp => {
    inp.onchange = () => { eodDraft[inp.dataset.eod] = Number(inp.value) || 0; };
  });
}

function calcEod() {
  document.querySelectorAll('[data-eod]').forEach(inp => {
    eodDraft[inp.dataset.eod] = Number(inp.value) || 0;
  });
  const lines = Object.entries(eodDraft).filter(([, q]) => q > 0).map(([itemId, qty]) => ({ itemId, qty }));
  if (!lines.length) return null;
  let revenue = 0, cogs = 0, items = 0;
  const missing = [];
  lines.forEach(l => {
    const it = itemById(l.itemId);
    if (!it) return;
    const unitCost = data.recipes[it.id]?.length ? recipeCost(it.id) : Number(it.cost);
    revenue += Number(it.sell) * l.qty;
    cogs += unitCost * l.qty;
    items += l.qty;
    const c = canFulfill(l.itemId, l.qty);
    if (!c.ok) missing.push(...c.missing);
  });
  return { lines, revenue, cogs, gross: revenue - cogs, items, missing };
}

function book() {
  const t = dayTotals();
  const month = iso().slice(0, 7);
  const monthExp = (data.expenses || []).filter(e => e.date.startsWith(month)).reduce((s, e) => s + Number(e.amount), 0);
  const monthSales = (data.sales || []).filter(s => s.date.startsWith(month) && s.status === 'confirmed')
    .reduce((s, x) => ({ rev: s.rev + x.revenue, cogs: s.cogs + x.cogs }), { rev: 0, cogs: 0 });
  document.getElementById('book').innerHTML = `
    <div class="title">Book</div>
    <div class="card">
      <h2>THIS MONTH</h2>
      <div class="grid2">
        <div class="stat"><div class="lbl">Revenue</div><div class="val green">${M(monthSales.rev)}</div></div>
        <div class="stat"><div class="lbl">COGS</div><div class="val orange">${M(monthSales.cogs)}</div></div>
        <div class="stat"><div class="lbl">Gross</div><div class="val accent">${M(monthSales.rev - monthSales.cogs)}</div></div>
        <div class="stat"><div class="lbl">Expenses</div><div class="val">${M(monthExp)}</div></div>
      </div>
      <div class="med" style="margin-top:8px">Net ≈ ${M(monthSales.rev - monthSales.cogs - monthExp)}</div>
    </div>
    <div class="card">
      <h2>ADD EXPENSE</h2>
      <form class="form" id="expForm">
        <select id="exCat">
          <option>Rent</option><option>Electricity</option><option>Water</option><option>Transport</option>
          <option>Cleaning</option><option>Maintenance</option><option>Packaging</option>
          <option>Worker pay</option><option>Advertising</option><option>Other</option>
        </select>
        <div class="row">
          <input id="exAmt" type="number" min="0.01" step="0.01" placeholder="Amount" required>
          <select id="exPay"><option>Cash</option><option>Card</option><option>EFT</option></select>
        </div>
        <input id="exNote" placeholder="Description">
        <button class="btn primary" type="submit">Save expense</button>
      </form>
    </div>
    <div class="card">
      <h2>CASH (TODAY)</h2>
      <div class="small">Opening float ${M(data.settings.float || 0)} · Cash sales today included in revenue when payment is Cash.</div>
      <div class="grid2" style="margin-top:8px">
        <div class="stat"><div class="lbl">Today revenue</div><div class="val">${M(t.revenue)}</div></div>
        <div class="stat"><div class="lbl">Today expenses</div><div class="val">${M(t.expenses)}</div></div>
      </div>
    </div>
    <div class="card">
      <h2>LEDGER</h2>
      ${(data.book || []).slice(0, 40).map(b => `
        <div class="item">
          <div><b>${esc(b.category)}</b><div class="small">${esc(b.type)} · ${esc(b.date)} · ${esc(b.note || '')}</div></div>
          <b class="${b.type === 'Income' ? 'green' : 'orange'}">${M(b.amount)}</b>
        </div>`).join('') || '<div class="empty">No book entries yet.</div>'}
    </div>`;

  document.getElementById('expForm').onsubmit = e => {
    e.preventDefault();
    const amount = Number(document.getElementById('exAmt').value);
    const category = document.getElementById('exCat').value;
    const note = document.getElementById('exNote').value.trim();
    const pay = document.getElementById('exPay').value;
    data.expenses.unshift({ id: uid('ex'), date: iso(), amount, category, note, payment: pay });
    bookEntry('Expense', category, amount, note || pay);
    save(); toast('Expense saved'); book(); home();
  };
}

function more() {
  const be = breakEven();
  const month = iso().slice(0, 7);
  const productSales = {};
  (data.sales || []).filter(s => s.date.startsWith(month) && s.status === 'confirmed').forEach(s => {
    (s.lines || []).forEach(l => {
      const k = l.name;
      productSales[k] = productSales[k] || { qty: 0, rev: 0, cogs: 0 };
      productSales[k].qty += l.qty;
      productSales[k].rev += l.sell * l.qty;
      productSales[k].cogs += l.cost * l.qty;
    });
  });
  const ranked = Object.entries(productSales).map(([name, v]) => ({
    name, ...v, profit: v.rev - v.cogs
  })).sort((a, b) => b.qty - a.qty);

  // 3-month projection simple
  const avgDaily = (() => {
    const days = {};
    (data.sales || []).filter(s => s.status === 'confirmed').forEach(s => {
      days[s.date] = (days[s.date] || 0) + s.revenue;
    });
    const vals = Object.values(days);
    if (!vals.length) return Number(data.settings.dailyTarget) || 1500;
    return vals.reduce((a, b) => a + b, 0) / vals.length;
  })();
  const projMonths = [0, 1, 2].map(i => {
    const d = new Date(); d.setMonth(d.getMonth() + i);
    const rev = avgDaily * 26;
    const cogs = rev * (1 - be.margin);
    const exp = Number(data.settings.fixedMonthly) || 5500;
    return {
      label: d.toLocaleString('en', { month: 'short' }),
      rev, cogs, net: rev - cogs - exp
    };
  });

  document.getElementById('more').innerHTML = `
    <div class="title">More</div>
    <div class="card">
      <h2>WORKERS</h2>
      ${(data.workers || []).map(w => `
        <div class="item">
          <div><b>${esc(w.name)}</b><div class="small">${esc(w.role)} · ${esc(w.payType)} · ${M(w.rate)}</div></div>
          <span class="badge ${w.active ? 'ok' : 'out'}">${w.active ? 'Active' : 'Off'}</span>
        </div>`).join('')}
      <button class="btn" data-action="worker-pay" style="margin-top:8px">Record worker payment</button>
    </div>
    <div class="card">
      <h2>TOP PRODUCTS (THIS MONTH)</h2>
      ${ranked.slice(0, 8).map((p, i) => `
        <div class="item">
          <div><b>${i + 1}. ${esc(p.name)}</b><div class="small">Sold ${p.qty} · Rev ${M(p.rev)}</div></div>
          <b class="green">${M(p.profit)}</b>
        </div>`).join('') || '<div class="empty">Sell something to unlock rankings.</div>'}
    </div>
    <div class="card">
      <h2>PROJECTION (3 MONTHS) · ESTIMATED</h2>
      <div class="small" style="margin-bottom:8px">Based on average daily sales ${M(avgDaily)} × 26 days and current margin. Not a guarantee.</div>
      ${projMonths.map(p => `
        <div class="item">
          <div><b>${esc(p.label)}</b><div class="small">Rev ${M(p.rev)} · COGS ${M(p.cogs)}</div></div>
          <b class="${p.net >= 0 ? 'green' : 'red'}">${M(p.net)}</b>
        </div>`).join('')}
    </div>
    <div class="card">
      <h2>SETTINGS</h2>
      <form class="form" id="setForm">
        <label class="small">Café name<input id="setCafe" value="${esc(data.settings.cafe || '')}"></label>
        <label class="small">Daily sales target<input id="setTarget" type="number" value="${data.settings.dailyTarget || 1500}"></label>
        <label class="small">Fixed monthly costs<input id="setFixed" type="number" value="${data.settings.fixedMonthly || 5500}"></label>
        <label class="small">Opening float<input id="setFloat" type="number" value="${data.settings.float || 300}"></label>
        <button class="btn primary" type="submit">Save settings</button>
      </form>
    </div>
    <div class="card">
      <h2>BACKUP</h2>
      <div class="row">
        <button class="btn" data-action="export">Export JSON</button>
        <label class="btn">Import<input type="file" id="importFile" accept="application/json" hidden></label>
      </div>
      <button class="btn danger" style="margin-top:8px" data-action="reset">Reset demo data</button>
    </div>`;

  document.getElementById('setForm').onsubmit = e => {
    e.preventDefault();
    data.settings.cafe = document.getElementById('setCafe').value.trim() || 'ELITES CAFÉ';
    data.settings.dailyTarget = Number(document.getElementById('setTarget').value) || 1500;
    data.settings.fixedMonthly = Number(document.getElementById('setFixed').value) || 5500;
    data.settings.float = Number(document.getElementById('setFloat').value) || 0;
    save(); toast('Settings saved'); more(); home();
  };
  document.getElementById('importFile').onchange = e => {
    const f = e.target.files?.[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        data = JSON.parse(r.result);
        save(); location.reload();
      } catch { toast('Invalid backup'); }
    };
    r.readAsText(f);
  };
}

function openItemForm(existing) {
  const it = existing || {
    id: '', name: '', cat: 'Ingredients', type: 'Ingredient', cost: 0, sell: 0,
    unit: 'unit', stock: 0, low: 5, supplier: '', notes: ''
  };
  openModal(existing ? 'Edit item' : 'Add item', `
    <label class="small">Name<input id="i_name" required value="${esc(it.name)}"></label>
    <div class="row">
      <label class="small">Category<input id="i_cat" value="${esc(it.cat)}"></label>
      <label class="small">Type
        <select id="i_type">
          ${['Ingredient', 'Menu Product', 'Drink', 'Packaging', 'Other'].map(t =>
            `<option ${it.type === t ? 'selected' : ''}>${t}</option>`).join('')}
        </select>
      </label>
    </div>
    <div class="row">
      <label class="small">Cost / unit<input id="i_cost" type="number" min="0" step="0.01" value="${it.cost}"></label>
      <label class="small">Selling price<input id="i_sell" type="number" min="0" step="0.01" value="${it.sell}"></label>
    </div>
    <div id="profitPrev" class="small"></div>
    <div class="row">
      <label class="small">Unit<input id="i_unit" value="${esc(it.unit)}"></label>
      <label class="small">Stock<input id="i_stock" type="number" step="any" value="${it.stock}"></label>
    </div>
    <div class="row">
      <label class="small">Low stock level<input id="i_low" type="number" min="0" value="${it.low}"></label>
      <label class="small">Supplier<input id="i_sup" value="${esc(it.supplier || '')}"></label>
    </div>
    <label class="small">Notes<input id="i_notes" value="${esc(it.notes || '')}"></label>
  `, () => {
    const name = document.getElementById('i_name').value.trim();
    if (!name) { toast('Name required'); return false; }
    const cost = Number(document.getElementById('i_cost').value) || 0;
    const sell = Number(document.getElementById('i_sell').value) || 0;
    const row = {
      id: it.id || uid('it'),
      name, cat: document.getElementById('i_cat').value.trim() || 'Other',
      type: document.getElementById('i_type').value,
      cost, sell,
      unit: document.getElementById('i_unit').value.trim() || 'unit',
      stock: Number(document.getElementById('i_stock').value) || 0,
      low: Number(document.getElementById('i_low').value) || 0,
      supplier: document.getElementById('i_sup').value.trim(),
      notes: document.getElementById('i_notes').value.trim(),
      archived: false,
      costHistory: it.costHistory || []
    };
    if (existing && Number(existing.cost) !== cost) {
      row.costHistory = [...(existing.costHistory || []), { date: iso(), cost }];
    } else if (!existing) {
      row.costHistory = [{ date: iso(), cost }];
    }
    const idx = data.items.findIndex(x => x.id === row.id);
    if (idx >= 0) data.items[idx] = { ...data.items[idx], ...row };
    else data.items.push(row);
    if (!data.recipes[row.id]) data.recipes[row.id] = data.recipes[row.id] || [];
    refreshMenuCosts();
    save(); toast(existing ? 'Item updated' : 'Item added'); stock(); home();
    return true;
  });
  const updatePrev = () => {
    const c = Number(document.getElementById('i_cost').value) || 0;
    const s = Number(document.getElementById('i_sell').value) || 0;
    const el = document.getElementById('profitPrev');
    if (!el) return;
    if (s <= 0) { el.innerHTML = ''; return; }
    const p = s - c;
    if (p < 0) el.innerHTML = `<div class="warn">WARNING · Selling below cost · Loss ${M(-p)} per item</div>`;
    else el.innerHTML = `<div class="okbox">Profit ${M(p)} · Margin ${((p / s) * 100).toFixed(0)}%</div>`;
  };
  document.getElementById('i_cost').oninput = updatePrev;
  document.getElementById('i_sell').oninput = updatePrev;
  updatePrev();
}

function openRestock(id) {
  const it = itemById(id);
  if (!it) return;
  openModal('Restock · ' + it.name, `
    <div class="small">Current stock: <b>${it.stock} ${esc(it.unit)}</b></div>
    <label class="small">Quantity<input id="r_qty" type="number" min="0.01" step="any" required></label>
    <label class="small">Cost / unit<input id="r_cost" type="number" min="0" step="0.01" value="${it.cost}"></label>
    <label class="small">Supplier<input id="r_sup" value="${esc(it.supplier || '')}"></label>
    <div class="small" id="r_total"></div>
  `, () => {
    const qty = Number(document.getElementById('r_qty').value) || 0;
    const cost = Number(document.getElementById('r_cost').value) || 0;
    if (qty <= 0) { toast('Enter quantity'); return false; }
    if (cost !== Number(it.cost)) {
      it.costHistory = [...(it.costHistory || []), { date: iso(), cost }];
      it.cost = cost;
    }
    it.supplier = document.getElementById('r_sup').value.trim();
    addMovement(it.id, qty, 'PURCHASE', { cost, total: cost * qty });
    bookEntry('Cost of sales', 'Inventory purchase', cost * qty, 'Restock ' + it.name);
    refreshMenuCosts();
    save(); toast('Restocked'); stock(); home();
    return true;
  });
  const upd = () => {
    const q = Number(document.getElementById('r_qty').value) || 0;
    const c = Number(document.getElementById('r_cost').value) || 0;
    document.getElementById('r_total').textContent = 'Total ' + M(q * c);
  };
  document.getElementById('r_qty').oninput = upd;
  document.getElementById('r_cost').oninput = upd;
}

function openWaste() {
  const ings = activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging');
  openModal('Record waste', `
    <label class="small">Item
      <select id="w_item">${ings.map(i => `<option value="${i.id}">${esc(i.name)} (${i.stock})</option>`).join('')}</select>
    </label>
    <label class="small">Quantity<input id="w_qty" type="number" min="0.01" step="any" required></label>
    <label class="small">Reason
      <select id="w_reason">
        <option>Expired</option><option>Burnt</option><option>Damaged</option><option>Spoiled</option>
        <option>Preparation error</option><option>Staff consumption</option><option>Customer complaint</option><option>Other</option>
      </select>
    </label>
  `, () => {
    const id = document.getElementById('w_item').value;
    const qty = Number(document.getElementById('w_qty').value) || 0;
    const reason = document.getElementById('w_reason').value;
    const it = itemById(id);
    if (!it || qty <= 0) return false;
    const cost = qty * Number(it.cost);
    addMovement(id, -qty, 'WASTE', { reason });
    data.waste.unshift({ id: uid('ws'), date: iso(), itemId: id, name: it.name, qty, cost, reason });
    bookEntry('Adjustments', 'Waste', cost, reason + ' · ' + it.name);
    save(); toast('Waste recorded'); stock(); home();
    return true;
  });
}

function openStockCount() {
  const ings = activeItems().filter(i => i.type === 'Ingredient' || i.type === 'Packaging');
  openModal('Stock count', `
    <div class="small" style="margin-bottom:8px">Enter physical counts. Differences create adjustments.</div>
    ${ings.slice(0, 25).map(i => `
      <div class="item">
        <div><b>${esc(i.name)}</b><div class="small">System ${i.stock}</div></div>
        <input data-count="${i.id}" type="number" step="any" value="${i.stock}" style="width:80px;text-align:center">
      </div>`).join('')}
  `, () => {
    document.querySelectorAll('[data-count]').forEach(inp => {
      const it = itemById(inp.dataset.count);
      if (!it) return;
      const physical = Number(inp.value);
      if (isNaN(physical)) return;
      const diff = physical - Number(it.stock);
      if (Math.abs(diff) < 1e-9) return;
      addMovement(it.id, diff, 'ADJUSTMENT', { note: 'Stock count' });
    });
    save(); toast('Stock count saved'); stock(); home();
    return true;
  });
}

function show(id) {
  document.querySelectorAll('.screen').forEach(x => x.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  document.querySelectorAll('.nav button').forEach(x => x.classList.toggle('active', x.dataset.s === id));
  ({ home, stock, sales, book, more }[id] || home)();
}

document.addEventListener('click', e => {
  const go = e.target.closest('[data-go]');
  if (go) { show(go.dataset.go); return; }
  const t = e.target.closest('[data-action]');
  if (!t) return;
  const a = t.dataset.action;
  if (a === 'stock-filter') { stockFilter = t.dataset.f; stock(); }
  else if (a === 'item-add') openItemForm(null);
  else if (a === 'item-edit') openItemForm(itemById(t.dataset.id));
  else if (a === 'item-del') {
    const it = itemById(t.dataset.id);
    if (!it) return;
    if (!confirm('Archive “' + it.name + '”? History is kept.')) return;
    it.archived = true; save(); stock(); toast('Archived');
  }
  else if (a === 'restock') openRestock(t.dataset.id);
  else if (a === 'waste-add') openWaste();
  else if (a === 'stock-count') openStockCount();
  else if (a === 'eod-inc') {
    eodDraft[t.dataset.id] = (eodDraft[t.dataset.id] || 0) + 1;
    const inp = document.querySelector(`[data-eod="${t.dataset.id}"]`);
    if (inp) inp.value = eodDraft[t.dataset.id];
  }
  else if (a === 'eod-dec') {
    eodDraft[t.dataset.id] = Math.max(0, (eodDraft[t.dataset.id] || 0) - 1);
    const inp = document.querySelector(`[data-eod="${t.dataset.id}"]`);
    if (inp) inp.value = eodDraft[t.dataset.id];
  }
  else if (a === 'eod-calc') {
    const r = calcEod();
    const el = document.getElementById('eodPreview');
    if (!r) { el.innerHTML = 'Enter quantities first.'; return; }
    el.innerHTML = `
      <div class="okbox">
        Items ${r.items} · Revenue ${M(r.revenue)} · COGS ${M(r.cogs)} · Gross ${M(r.gross)}
        ${r.missing.length ? `<div class="warn" style="margin-top:6px">Stock shortfalls detected — confirm may fail for some lines.</div>` : ''}
      </div>`;
  }
  else if (a === 'eod-confirm') {
    const r = calcEod();
    if (!r) { toast('Nothing to confirm'); return; }
    if (!confirm(`Confirm day?\nRevenue ${M(r.revenue)}\nCOGS ${M(r.cogs)}\nGross ${M(r.gross)}`)) return;
    const res = sellLines(r.lines, 'Cash', iso(), true);
    if (!res.ok) {
      toast('Insufficient stock');
      return;
    }
    eodDraft = {};
    toast('Day confirmed');
    sales(); home(); book();
  }
  else if (a === 'worker-pay') {
    openModal('Worker payment', `
      <label class="small">Worker
        <select id="wp_w">${(data.workers || []).map(w => `<option value="${w.id}">${esc(w.name)}</option>`).join('')}</select>
      </label>
      <label class="small">Amount<input id="wp_a" type="number" min="0.01" step="0.01" required></label>
      <label class="small">Note<input id="wp_n" placeholder="Base / bonus / advance"></label>
    `, () => {
      const wid = document.getElementById('wp_w').value;
      const amount = Number(document.getElementById('wp_a').value) || 0;
      const note = document.getElementById('wp_n').value.trim();
      const w = (data.workers || []).find(x => x.id === wid);
      if (!w || amount <= 0) return false;
      data.payments.unshift({ id: uid('pay'), date: iso(), workerId: wid, name: w.name, amount, note });
      data.expenses.unshift({ id: uid('ex'), date: iso(), amount, category: 'Worker pay', note: w.name + ' · ' + note, payment: 'Cash' });
      bookEntry('Expense', 'Worker pay', amount, w.name + ' · ' + note);
      save(); toast('Payment recorded'); more(); book(); home();
      return true;
    });
  }
  else if (a === 'export') {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
    a.download = 'stockly-backup-' + iso() + '.json';
    a.click();
  }
  else if (a === 'reset') {
    if (!confirm('Reset all Stockly data and restore ELITES demo?')) return;
    localStorage.removeItem(KEY);
    location.reload();
  }
});

document.querySelectorAll('.nav button').forEach(b => b.onclick = () => show(b.dataset.s));
document.getElementById('todayMeta').textContent = today().toLocaleDateString('en-ZA', {
  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
});
document.getElementById('onlinePill').textContent = navigator.onLine ? 'ONLINE' : 'OFFLINE';
window.addEventListener('online', () => document.getElementById('onlinePill').textContent = 'ONLINE');
window.addEventListener('offline', () => document.getElementById('onlinePill').textContent = 'OFFLINE');

refreshMenuCosts();
home();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
