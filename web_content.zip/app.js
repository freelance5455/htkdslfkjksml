(() => {
const $ = id => document.getElementById(id);
const KEY_STORE='jarvis_omega_gemini_key_v2', MODEL_STORE='jarvis_omega_gemini_model_v2';
let apiKey='', model='gemini-3.8-flash', history=[], recognition=null, pendingTool=null, timerInterval=null, timerEnd=0, darkAlt=false;
const apps={
 youtube:{name:'YouTube',url:'https://www.youtube.com/',intent:'intent://www.youtube.com/#Intent;scheme=https;package=com.google.android.youtube;end'},
 whatsapp:{name:'WhatsApp',url:'https://wa.me/',intent:'intent://send/#Intent;scheme=whatsapp;package=com.whatsapp;end'},
 google:{name:'Google',url:'https://www.google.com/',intent:'intent://www.google.com/#Intent;scheme=https;package=com.android.chrome;end'},
 maps:{name:'Google Maps',url:'https://maps.google.com/',intent:'google.navigation:q=Brasil'},
 spotify:{name:'Spotify',url:'https://open.spotify.com/',intent:'spotify://'},
 gmail:{name:'Gmail',url:'https://mail.google.com/',intent:'intent://mail.google.com/#Intent;scheme=https;package=com.google.android.gm;end'},
 settings:{name:'Configurações',url:'https://support.google.com/android/answer/9083864',intent:'intent:#Intent;action=android.settings.SETTINGS;end'},
 camera:{name:'Câmera',url:'',intent:'intent:#Intent;action=android.media.action.IMAGE_CAPTURE;end'}
};
function setState(s){$('state').textContent=s;$('coreState').textContent=s==='STANDBY'?'AGUARDANDO COMANDO':s}
function addMessage(role,text){const wrap=document.createElement('div');wrap.className='msg '+role;const av=document.createElement('span');av.className='avatar';av.textContent=role==='user'?'U':'Ω';const box=document.createElement('div');const small=document.createElement('small');small.textContent=role==='user'?'VOCÊ':'JARVIS / '+(apiKey?'GEMINI':'SISTEMA');const p=document.createElement('p');p.textContent=text;box.append(small,p);wrap.append(av,box);$('chat').append(wrap);$('chat').scrollTop=$('chat').scrollHeight;return p}
function speak(t){if(!$('autoSpeak').checked||!('speechSynthesis'in window))return;try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='pt-BR';u.rate=1;u.pitch=.95;speechSynthesis.speak(u)}catch(e){}}
function reply(t,doSpeak=true){addMessage('ai',t);if(doSpeak)speak(t);setState('STANDBY')}
function setGemini(on){$('geminiBadge').textContent=on?'CONNECTED':'OFFLINE';$('geminiBadge').style.color=on?'#5affc4':'#ffbd69';$('modePill').textContent=on?'GEMINI AI MODE':'LOCAL MODE';$('connection').textContent=on?'GEMINI CONECTADO':'MODO LOCAL'}
function extractInteractionText(data){
 if(typeof data?.output_text==='string'&&data.output_text.trim())return data.output_text.trim();
 const chunks=[];
 const addContent=content=>{if(!Array.isArray(content))return;for(const item of content){if(item&&item.type==='text'&&typeof item.text==='string'&&item.text.trim())chunks.push(item.text.trim());}};
 if(Array.isArray(data?.steps)){for(const step of data.steps){if(step?.type==='model_output')addContent(step.content);}}
 if(Array.isArray(data?.output)){for(const item of data.output){if(typeof item?.text==='string')chunks.push(item.text.trim());addContent(item?.content);}}
 return chunks.filter(Boolean).join('\n').trim();
}
function openApp(k){const a=apps[k];if(!a){reply('Atalho não configurado.');return}reply('Tentando abrir '+a.name+'. O Android pode bloquear o atalho ou abrir a versão web.',false);if(a.intent){location.href=a.intent;setTimeout(()=>{if(a.url)location.href=a.url},850)}else if(a.url)window.open(a.url,'_blank','noopener')}
async function askGemini(text){
 if(!apiKey){reply('A IA ainda não está conectada. Abra ⚙ Configurações, cole sua chave do Google AI Studio e toque em Salvar. Os comandos locais continuam funcionando.');return}
 setState('PROCESSANDO');$('soundwave').classList.add('active');const started=performance.now();
 const transcript=history.slice(-12).map(h=>(h.role==='user'?'Usuário':'JARVIS')+': '+(h.parts||[]).map(p=>p.text||'').join(' ')).join('\n');
 try{
  const prompt='Você é JARVIS OMEGA, assistente pessoal em português brasileiro. Seja útil, honesto e objetivo. Não afirme que executou ações no dispositivo se apenas sugeriu. Você não tem controle direto do Android; comandos locais disponíveis são executados pelo aplicativo. Explique riscos e peça confirmação para ações importantes.\n\n'+(transcript?'Histórico recente:\n'+transcript+'\n\n':'')+'Usuário: '+text;
  const res=await fetch('https://generativelanguage.googleapis.com/v1beta/interactions',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':apiKey},body:JSON.stringify({model,input:prompt})});
  const data=await res.json();if(!res.ok){const msg=data?.error?.message||('HTTP '+res.status);throw new Error(msg)}
  const answer=extractInteractionText(data);
  if(!answer){const status=data?.status||'desconhecido';throw new Error('A API não trouxe texto (status: '+status+'). Confira o modelo selecionado e tente novamente.');}
  history.push({role:'user',parts:[{text}]},{role:'model',parts:[{text:answer}]});history=history.slice(-24);
  $('latency').textContent=Math.round(performance.now()-started)+' ms';reply(answer);
 }catch(e){reply('Falha na conexão Gemini: '+e.message+'\\nConfira a chave, o modelo, a conexão e os limites da API.',false)}
 finally{$('soundwave').classList.remove('active');setState('STANDBY')}
}
function executeLocal(raw){
 const c=raw.trim().toLocaleLowerCase('pt-BR');if(!c)return true;
 if(c==='ajuda'||c.includes('quais comandos')){reply('Comandos locais: “abrir YouTube/WhatsApp/Google/Maps/Spotify/Gmail/câmera/configurações”, “pesquisar [termo]”, “que horas são”, “que dia é hoje”, “status do sistema”, “falar [texto]”, “parar voz”, “nova nota”, “nova tarefa”, “temporizador 30 segundos”, “configurações Gemini”, “limpar chat”. Perguntas livres usam Gemini quando a chave estiver configurada.');return true}
 if(c.includes('que horas')){reply('Agora são '+new Date().toLocaleTimeString('pt-BR')+'.');return true}
 if(c.includes('que dia é hoje')){reply('Hoje é '+new Date().toLocaleDateString('pt-BR',{weekday:'long',day:'numeric',month:'long',year:'numeric'})+'.');return true}
 if(c.includes('status do sistema')||c==='status'){reply('Status local: HUD operacional. Rede: '+(navigator.onLine?'online segundo o navegador':'offline')+'. Plataforma: '+(/Android/i.test(navigator.userAgent)?'Android':'navegador web')+'. Gemini: '+(apiKey?'chave configurada':'não configurado')+'. O app não tem acesso irrestrito ao sistema.');return true}
 if(c.startsWith('pesquisar ')){const q=raw.slice(10).trim();if(q)window.open('https://www.google.com/search?q='+encodeURIComponent(q),'_blank','noopener');reply(q?'Abrindo pesquisa por: '+q:'Diga o que pesquisar.',false);return true}
 if(c.startsWith('abrir ')){const t=c.slice(6);const map=[['youtube','youtube'],['whatsapp','whatsapp'],['google','google'],['chrome','google'],['maps','maps'],['mapas','maps'],['spotify','spotify'],['gmail','gmail'],['email','gmail'],['câmera','camera'],['camera','camera'],['configurações','settings'],['configuracoes','settings']];const f=map.find(x=>t.includes(x[0]));if(f){openApp(f[1]);return true}}
 if(c.startsWith('falar ')){reply(raw.slice(6),true);return true}
 if(c.includes('parar voz')){if('speechSynthesis'in window)speechSynthesis.cancel();reply('Voz interrompida.',false);return true}
 if(c.includes('configurações gemini')||c.includes('configurar ia')){$('settingsModal').classList.remove('hidden');return true}
 if(c.includes('limpar chat')){if(confirm('Limpar a conversa visível?')){$('chat').replaceChildren();history=[];reply('Conversa limpa.',false)}return true}
 if(c==='nova nota'||c==='criar nota'){$('inputTitle').textContent='Nova nota';pendingTool='note';$('inputModal').classList.remove('hidden');return true}
 if(c==='nova tarefa'||c==='criar tarefa'){$('inputTitle').textContent='Nova tarefa';pendingTool='todo';$('inputModal').classList.remove('hidden');return true}
 const tm=c.match(/temporizador\s+(\d+)\s*(segundos?|seg|minutos?|min)?/);if(tm){const secs=Number(tm[1])*(tm[2]&&tm[2].startsWith('min')?60:1);if(secs>0&&secs<=86400){if(timerInterval)clearInterval(timerInterval);timerEnd=Date.now()+secs*1000;timerInterval=setInterval(()=>{const left=Math.max(0,Math.ceil((timerEnd-Date.now())/1000));$('toolResult').textContent='Temporizador: '+left+' s';if(left<=0){clearInterval(timerInterval);timerInterval=null;reply('Temporizador concluído!');if(navigator.vibrate)navigator.vibrate([200,100,200])}},250);reply('Temporizador iniciado para '+secs+' segundos.');return true}}
 if(c==='olá jarvis'||c==='ola jarvis'||c==='oi jarvis'){reply('Olá. JARVIS OMEGA operacional. Como posso ajudar?');return true}
 return false;
}
async function submit(){const text=$('prompt').value.trim();if(!text)return;$('prompt').value='';addMessage('user',text);if(executeLocal(text))return;await askGemini(text)}
$('send').addEventListener('click',submit);$('prompt').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();submit()}});
document.querySelectorAll('[data-cmd]').forEach(b=>b.addEventListener('click',()=>{$('prompt').value=b.dataset.cmd;submit()}));
document.querySelectorAll('[data-app]').forEach(b=>b.addEventListener('click',()=>openApp(b.dataset.app)));
$('settingsOpen').addEventListener('click',()=>{$('apiKey').value=apiKey;$('model').value=model;$('settingsModal').classList.remove('hidden')});
$('settingsClose').addEventListener('click',()=>$('settingsModal').classList.add('hidden'));
$('revealKey').addEventListener('click',()=>{$('apiKey').type=$('apiKey').type==='password'?'text':'password';$('revealKey').textContent=$('apiKey').type==='password'?'MOSTRAR':'OCULTAR'});
$('saveKey').addEventListener('click',()=>{apiKey=$('apiKey').value.trim();model=$('model').value;try{if($('rememberKey').checked){localStorage.setItem(KEY_STORE,apiKey);localStorage.setItem(MODEL_STORE,model)}else{localStorage.removeItem(KEY_STORE);localStorage.removeItem(MODEL_STORE)}}catch(e){}setGemini(Boolean(apiKey));$('keyStatus').textContent=apiKey?'Chave configurada nesta sessão'+($('rememberKey').checked?' e salva neste navegador.':' (não salva após fechar).'):'Nenhuma chave informada.';$('settingsModal').classList.add('hidden')});
$('testKey').addEventListener('click',async()=>{const k=$('apiKey').value.trim();const m=$('model').value;if(!k){$('keyStatus').textContent='Cole uma chave primeiro.';return}$('keyStatus').textContent='Testando conexão…';try{const r=await fetch('https://generativelanguage.googleapis.com/v1beta/interactions',{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':k},body:JSON.stringify({model:m,input:'Responda apenas: conexão OK'})});const d=await r.json();if(!r.ok)throw new Error(d?.error?.message||'HTTP '+r.status);const answer=extractInteractionText(d);if(!answer)throw new Error('Resposta sem texto (status: '+(d?.status||'desconhecido')+'). Confira o modelo e tente novamente.');$('keyStatus').textContent='Conexão OK! O modelo respondeu: '+answer.slice(0,90)+' Toque em Salvar para usar.'}catch(e){$('keyStatus').textContent='Erro: '+e.message}});
document.querySelectorAll('[data-tool]').forEach(b=>b.addEventListener('click',()=>{const t=b.dataset.tool;if(t==='note'||t==='todo'){pendingTool=t;$('inputTitle').textContent=t==='note'?'Nova nota':'Nova tarefa';$('toolInput').value='';$('inputModal').classList.remove('hidden')}else if(t==='theme'){darkAlt=!darkAlt;document.body.style.setProperty('--cyan',darkAlt?'#c09aff':'#4ce3ff');$('toolResult').textContent='Tema '+(darkAlt?'violeta':'ciano')+' ativado.'}else if(t==='clear'){if(confirm('Apagar mensagens visíveis?')){$('chat').replaceChildren();history=[];$('toolResult').textContent='Conversa limpa.'}}else if(t==='export'){const data={notes:JSON.parse(localStorage.getItem('jo_notes')||'[]'),tasks:JSON.parse(localStorage.getItem('jo_tasks')||'[]')};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='jarvis-dados.json';a.click();URL.revokeObjectURL(a.href);$('toolResult').textContent='Exportação solicitada.'}else if(t==='timer'){const s=prompt('Quantos segundos?','60');if(s&&Number(s)>0){$('prompt').value='temporizador '+Math.min(86400,Number(s))+' segundos';submit()}}}));
$('inputClose').addEventListener('click',()=>$('inputModal').classList.add('hidden'));$('toolCancel').addEventListener('click',()=>$('inputModal').classList.add('hidden'));
$('toolSave').addEventListener('click',()=>{const text=$('toolInput').value.trim();if(!text)return;const key=pendingTool==='note'?'jo_notes':'jo_tasks';const arr=JSON.parse(localStorage.getItem(key)||'[]');arr.push({id:Date.now(),text,createdAt:new Date().toISOString(),done:false});localStorage.setItem(key,JSON.stringify(arr));$('toolResult').textContent=(pendingTool==='note'?'Nota salva: ':'Tarefa adicionada: ')+text;$('inputModal').classList.add('hidden');reply((pendingTool==='note'?'Nota salva localmente.':'Tarefa adicionada à lista local.'),false)});
$('stopVoice').addEventListener('click',()=>{if('speechSynthesis'in window)speechSynthesis.cancel();if(recognition)try{recognition.stop()}catch(e){}$('soundwave').classList.remove('active');setState('STANDBY')});
$('mic').addEventListener('click',()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){reply('Reconhecimento de voz não está disponível neste navegador. Digite seu comando.',false);return}try{recognition=new SR();recognition.lang='pt-BR';recognition.interimResults=false;recognition.onstart=()=>{setState('OUVINDO');$('soundwave').classList.add('active')};recognition.onresult=e=>{$('prompt').value=e.results[0][0].transcript;submit()};recognition.onerror=e=>reply('Erro no microfone: '+e.error+'. Confira a permissão.',false);recognition.onend=()=>{$('soundwave').classList.remove('active');setState('STANDBY')};recognition.start()}catch(e){reply('Não foi possível iniciar o microfone.',false)}});
function updateTime(){$('clock').textContent=new Date().toLocaleTimeString('pt-BR',{hour12:false});$('diagTime').textContent=new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}
function refresh(){updateTime();$('diagNet').textContent=navigator.onLine?'ONLINE':'OFFLINE';$('netBar').style.width=navigator.onLine?'90%':'12%';$('diagPlatform').textContent=/Android/i.test(navigator.userAgent)?'ANDROID':'WEB';}
$('refreshStatus').addEventListener('click',refresh);window.addEventListener('online',refresh);window.addEventListener('offline',refresh);setInterval(updateTime,1000);refresh();
try{apiKey=sessionStorage.getItem(KEY_STORE)||'';const saved=localStorage.getItem(KEY_STORE);if(saved){apiKey=saved;$('rememberKey').checked=true}$('apiKey').value=apiKey;model=localStorage.getItem(MODEL_STORE)||model;$('model').value=model}catch(e){}
setGemini(Boolean(apiKey));
if(navigator.getBattery){navigator.getBattery().then(b=>{const draw=()=>{$('diagBattery').textContent=Math.round(b.level*100)+'%'+(b.charging?' / carregando':'');$('batBar').style.width=Math.round(b.level*100)+'%'};draw();b.addEventListener('levelchange',draw);b.addEventListener('chargingchange',draw)}).catch(()=>{})}
})();