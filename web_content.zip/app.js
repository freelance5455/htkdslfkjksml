const DB_KEY="ALDHALEA_HOSPITAL_PATIENTS_DB";
const AUTOSAVE_DRAFT_KEY="ALDHALEA_HOSPITAL_AUTOSAVE_DRAFT_V1";
let currentPatientId=null;
let autosaveDraftDirty=false;
let autosaveRestoring=false;
const tableSchemas={cvdTable:["date","bp","pulse","text","text","text","text"],strokeTable:["date","text","text","text"],htnTable:["date","bp","pulse","text","text"],dmTable:["date","text","text","text","text","text"],generalFollowTable:["date","text","text","text","date"]};
const basicFieldIds=["patientName","fileNo","visitDate","age","gender","clinic","referralSource","phone","address","emergencyContact","bpScreen","pulseScreen","tempScreen","spo2Screen","weight","height","waist","smoking","qat","shamma","personalHistoryDetails","familyHistory","physicalActivityLevel","physicalActivityFrequency","lifestyle","medsAllergy","cvdDuration","cvdChestPain","cvdDyspnea","cvdSymptoms","cvdExam","strokeDuration","strokeWeakness","strokeSpeechVision","strokeExam","strokeMeds","htnDuration","htnAdherence","htnRedFlags","dmDuration","dmTherapy","dmAdherence","dmFbs","dmHba1c","dmRbs","dmFoot","dmComplications","complaint","historyPresent","clinicalExam","medicalAssessment","diagnosis","treatmentPlan","recommendations","referral","rxInstructions","followupNotes","nextVisit","followWeight","followBP","followPulse"];
const checkboxIds=["riskHTN","riskDM","riskCVD","riskKidney","riskStroke","riskLipid","riskObesity","riskOther","personalSurgery","personalHospitalization","personalAllergy","personalTransfusion","personalChronic","personalOther","familyHistoryNone","familyHistoryUnknown","familyHistoryHTN","familyHistoryDM","familyHistoryCVD","familyHistoryStroke","familyHistoryKidney","familyHistoryLipid","familyHistoryCancer","familyHistoryEarlyDeath","familyHistoryOther","activityWalking","activityExercise","activityPhysicalWork","activitySedentary","activityOther","medicationNone","medicationHypertension","medicationDiabetes","medicationCardiac","medicationAnticoagulant","medicationLipids","medicationRespiratory","medicationGI","medicationOther","giAdviceHydration","giAdviceFiber","giAdviceMealTiming","giAdviceFoodDiary","giAdviceReferral","giAdviceTests","patientEducationGiven","patientEducationUnderstood","patientWrittenInstructions"];const radioNames=["cvdKnown","strokeKnown","htnKnown","dmKnown"];
const extraFieldIds=["clinicalStability","medicalPriority","comorbidDiagnoses","differentialDiagnosis","diagnosticCertainty","diagnosisCodeNotes","doctorNotes","notesDoctorName","notesDate","giSymptoms","giBowel","nutritionStatus","nutritionAppetite","foodIntolerance","dietaryRestrictions","recommendedFoods","foodsToAvoid","mealPlan","fluidsFiber","giFollowupPlan","giDietitianNotes","emergencyInstructions","patientMedicationAdvice","patientAvoidAdvice","patientFoodAdvice","patientLifestyleAdvice","patientSameDaySigns","patientFollowupTiming","patientFollowupInstructions","patientUnderstandingNotes"];

document.addEventListener("DOMContentLoaded",()=>{document.getElementById("visitDate").value=todayISO();normalizePatientNumbering();ensureCurrentFileNo();initializeTables();setupSectionToggles();updateHeaderSummaries();renderPatients();updateSummary();updateReports();refreshPatientFiles();initializeAutoDraft()});
function setupMutuallyExclusiveOptions(){document.querySelectorAll('[data-choice-none]').forEach(none=>none.addEventListener('change',()=>{if(!none.checked)return;const group=none.dataset.choiceNone;document.querySelectorAll(`[data-choice-option="${group}"]`).forEach(item=>item.checked=false);document.querySelectorAll(`[data-choice-none="${group}"]`).forEach(item=>{if(item!==none)item.checked=false});persistAutoDraft?.()}));document.querySelectorAll('[data-choice-option]').forEach(option=>option.addEventListener('change',()=>{if(!option.checked)return;const group=option.dataset.choiceOption;document.querySelectorAll(`[data-choice-none="${group}"]`).forEach(item=>item.checked=false);persistAutoDraft?.()}));}
document.addEventListener("DOMContentLoaded",setupMutuallyExclusiveOptions);
function todayISO(){const d=new Date(),off=d.getTimezoneOffset();return new Date(d.getTime()-off*60000).toISOString().slice(0,10)}
function val(id){const e=document.getElementById(id);return e?e.value:""}function setVal(id,v){const e=document.getElementById(id);if(!e)return;if(e.type==="checkbox")e.checked=!!v;else e.value=v??""}
function getRadio(n){const e=document.querySelector(`input[name="${n}"]:checked`);return e?e.value:""}function setRadio(n,v){document.querySelectorAll(`input[name="${n}"]`).forEach(r=>r.checked=r.value===v)}
function calculateBMI(){const w=parseFloat(val("weight")),hcm=parseFloat(val("height")),e=document.getElementById("bmi");if(w>0&&hcm>0)e.value=(w/((hcm/100)**2)).toFixed(1);else e.value=""}

function initializeTables(){Object.keys(tableSchemas).forEach(id=>{if(!document.querySelector(`#${id} tbody`).children.length)addRow(id,tableSchemas[id],true)});if(!document.querySelector("#labsTable tbody").children.length)addLab();if(!document.querySelector("#rxTable tbody").children.length)addPrescription();if(!document.querySelector("#diagnosticsTable tbody").children.length)addDiagnosticRow() }
function addRow(tableId,schema,silent=false,preset=[]){const tb=document.querySelector(`#${tableId} tbody`);if(!tb)return;const tr=document.createElement("tr");tr.appendChild(cellText(tb.children.length+1));schema.forEach((kind,i)=>{const td=document.createElement("td");let el;if(kind==="date"){el=document.createElement("input");el.type="date";el.value=preset[i]||todayISO()}else if(kind==="bp"){el=document.createElement("input");el.type="text";el.placeholder="130/80";el.value=preset[i]||""}else if(kind==="pulse"){el=document.createElement("input");el.type="text";el.placeholder="ض/د";el.value=preset[i]||""}else if(kind==="selectStage"){el=document.createElement("select");el.innerHTML='<option value="">اختر</option><option>المرحلة الأولى</option><option>المرحلة الثانية</option><option>المرحلة الثالثة</option><option>المرحلة الرابعة</option><option>المرحلة الخامسة</option>';el.value=preset[i]||""}else{el=document.createElement("input");el.type="text";el.value=preset[i]||""}td.appendChild(el);tr.appendChild(td)});const td=document.createElement("td");td.className="action-cell no-print";td.innerHTML='<button type="button" class="delete-row" onclick="removeRow(this)">حذف</button>';tr.appendChild(td);tb.appendChild(tr);renumberTable(tableId);if(!silent)updateSummary()}
function removeRow(btn){const tr=btn.closest("tr"),table=tr.closest("table");if(!tr||!table)return;const label=table.querySelector("thead th:nth-child(2)")?.textContent||"هذا الصف";if(!confirm(`تأكيد الحذف\nهل تريد حذف هذا الصف من جدول «${label}»؟ لا يمكن التراجع عن الحذف من النموذج الحالي قبل حفظه.`))return;tr.remove();renumberTable(table.id)}
function renumberTable(id){const tb=document.querySelector(`#${id} tbody`);if(!tb)return;[...tb.children].forEach((tr,i)=>tr.children[0].textContent=i+1)}
function getTableData(id){const t=document.getElementById(id);if(!t)return[];return[...t.tBodies[0].rows].map(tr=>[...tr.cells].slice(1,-1).map(td=>td.querySelector("input,select,textarea")?.value||""))}
function setTableData(id,rows,schema){const tb=document.querySelector(`#${id} tbody`);tb.innerHTML="";if(rows?.length)rows.forEach(r=>addRow(id,schema,true,r));else addRow(id,schema,true);renumberTable(id)}
function inputCell(v="",ph=""){const td=document.createElement("td"),i=document.createElement("input");i.type="text";i.value=v; i.placeholder=ph;td.appendChild(i);return td}
function cellText(t){const td=document.createElement("td");td.textContent=t;return td}
function addLab(type="",name=""){const tb=document.querySelector("#labsTable tbody"),tr=document.createElement("tr");tr.appendChild(cellText(tb.children.length+1));const st=document.createElement("td"),s=document.createElement("select");s.innerHTML='<option value="">اختر</option><option>مخبري</option><option>تصويري</option><option>وظيفي</option><option>منظار</option><option>نسيجي</option><option>آخر</option>';s.value=type;st.appendChild(s);tr.appendChild(st);tr.appendChild(inputCell(name,"اسم الفحص"));tr.appendChild(inputCell("","النتيجة"));tr.appendChild(inputCell("","الوحدة"));tr.appendChild(inputCell("","المعدل المرجعي"));const dt=document.createElement("td"),di=document.createElement("input");di.type="date";di.value=todayISO();dt.appendChild(di);tr.appendChild(dt);tr.appendChild(inputCell("","ملاحظات"));const a=document.createElement("td");a.className="action-cell no-print";a.innerHTML='<button type="button" class="delete-row" onclick="removeRow(this)">حذف</button>';tr.appendChild(a);tb.appendChild(tr);renumberTable("labsTable")}
function addLabPreset(ar,en){addLab("مخبري",`${ar} (${en})`)}
function addPrescription(){const tb=document.querySelector("#rxTable tbody"),tr=document.createElement("tr");tr.appendChild(cellText(tb.children.length+1));["اسم الدواء","الجرعة","التكرار","الطريق","المدة","الكمية","تعليمات الاستعمال"].forEach(p=>tr.appendChild(inputCell("",p)));const a=document.createElement("td");a.className="action-cell no-print";a.innerHTML='<button type="button" class="delete-row" onclick="removeRow(this)">حذف</button>';tr.appendChild(a);tb.appendChild(tr);renumberTable("rxTable")}
function getSimpleTable(id){return getTableData(id)}
function setSimpleTable(id,rows,maker){const tb=document.querySelector(`#${id} tbody`);tb.innerHTML="";(rows?.length?rows:[[]]).forEach(maker);renumberTable(id)}

function collectPatient(){const existing=currentPatientId?getDB().find(p=>p.id===currentPatientId):null;const d=existing?{...existing}:{};basicFieldIds.forEach(id=>d[id]=val(id));checkboxIds.forEach(id=>d[id]=document.getElementById(id).checked);radioNames.forEach(n=>d[n]=getRadio(n));extraFieldIds.forEach(id=>d[id]=val(id));["cvdTable","strokeTable","htnTable","dmTable","generalFollowTable"].forEach(id=>d[id]=getTableData(id));d.labsTable=getSimpleTable("labsTable");d.rxTable=getSimpleTable("rxTable");d.diagnosticsTable=getSimpleTable("diagnosticsTable");d.activeSections=getActiveSections();d.updatedAt=new Date().toISOString();return d}
function applyPatient(d){basicFieldIds.forEach(id=>setVal(id,d?.[id]??""));checkboxIds.forEach(id=>setVal(id,d?.[id]??false));radioNames.forEach(n=>setRadio(n,d?.[n]??""));extraFieldIds.forEach(id=>setVal(id,d?.[id]??""));calculateBMI();Object.keys(tableSchemas).forEach(id=>setTableData(id,d?.[id],tableSchemas[id]));setSimpleTable("labsTable",d?.labsTable,(r)=>{addLab(r?.[0]||"",r?.[1]||"");const e=document.querySelector("#labsTable tbody tr:last-child").querySelectorAll("input");e[1].value=r?.[2]||"";e[2].value=r?.[3]||"";e[3].value=r?.[4]||"";e[4].value=r?.[5]||"";e[5].value=r?.[6]||""});setSimpleTable("rxTable",d?.rxTable,(r)=>{addPrescription();[...document.querySelector("#rxTable tbody tr:last-child").querySelectorAll("input")].forEach((e,i)=>e.value=r?.[i]||"")});setSimpleTable("diagnosticsTable",d?.diagnosticsTable,(r)=>{addDiagnosticRow(r?.[0]||"",r?.[1]||"");const row=document.querySelector("#diagnosticsTable tbody tr:last-child");const els=row.querySelectorAll("input,select,textarea");[...els].forEach((e,i)=>e.value=r?.[i]||"")});setVal("serialNoDisplay",d?.serialNo??"");if(d?.activeSections)applyActiveSections(d.activeSections);updateHeaderSummaries();updateSummary();updateReports();updateCurrentRecord() }
function getDB(){try{return JSON.parse(localStorage.getItem(DB_KEY)||"[]")}catch{return[]}}function setDB(d){localStorage.setItem(DB_KEY,JSON.stringify(d))}
const FILE_SEQ_KEY="ALDHALEA_HOSPITAL_FILE_SEQUENCE";
function parseGeneratedFileNo(fileNo){const m=String(fileNo||"").trim().match(/^DHM-(\d+)$/i);return m?Number(m[1]):0}
function formatGeneratedFileNo(number){return "DHM-"+String(number).padStart(6,"0")}
function maxSavedSerial(db=getDB()){
  let max=Number(localStorage.getItem(FILE_SEQ_KEY))||0;
  (db||[]).forEach(p=>{const s=Number(p?.serialNo)||0;const f=parseGeneratedFileNo(p?.fileNo);if(Number.isInteger(s)&&s>max)max=s;if(f>max)max=f;});
  return max;
}
function reserveNextPatientNumber(db=getDB()){
  const usedFiles=new Set((db||[]).map(p=>String(p?.fileNo||"").trim().toLocaleUpperCase()).filter(Boolean));
  const usedSerials=new Set((db||[]).map(p=>Number(p?.serialNo)).filter(n=>Number.isInteger(n)&&n>0));
  let number=maxSavedSerial(db)+1;
  while(usedFiles.has(formatGeneratedFileNo(number).toLocaleUpperCase())||usedSerials.has(number))number++;
  // This is a preview only. Do not consume the sequence until the record is successfully saved.
  return {number,fileNo:formatGeneratedFileNo(number)};
}
function normalizePatientNumbering(){
  const db=getDB();if(!Array.isArray(db)||!db.length)return;
  let changed=false;
  // Preserve the first occurrence of every valid serial; reserve all first-occurrence serials before repairing duplicates.
  let max=Math.max(Number(localStorage.getItem(FILE_SEQ_KEY))||0,...db.map(p=>Number(p?.serialNo)||0),...db.map(p=>parseGeneratedFileNo(p?.fileNo)),0);
  const originalKeys=db.map(p=>String(p?.fileNo||'').trim().toLocaleUpperCase());
  const fileKeyCounts=new Map();originalKeys.forEach(k=>{if(k)fileKeyCounts.set(k,(fileKeyCounts.get(k)||0)+1)});
  const candidates=db.map(p=>{
    const serial=Number(p?.serialNo),fromFile=parseGeneratedFileNo(p?.fileNo);
    const n=Number.isInteger(serial)&&serial>0?serial:fromFile;
    return Number.isInteger(n)&&n>0?n:0;
  });
  const reservedSerials=new Set(),keepSerial=candidates.map(n=>{
    if(!n||reservedSerials.has(n))return false;
    reservedSerials.add(n);return true;
  });
  // If a serial is duplicated but its DHM file number is unique, prefer that file number's unused suffix.
  candidates.forEach((n,i)=>{
    if(keepSerial[i])return;
    const fileNo=parseGeneratedFileNo(db[i]?.fileNo),key=originalKeys[i];
    if(fileNo>0&&key&&(fileKeyCounts.get(key)===1)&&!reservedSerials.has(fileNo)){
      candidates[i]=fileNo;keepSerial[i]=true;reservedSerials.add(fileNo);
    }
  });
  const usedSerials=new Set(reservedSerials);
  db.forEach((p,i)=>{
    let n=candidates[i];
    if(!keepSerial[i]){
      do{max++;}while(usedSerials.has(max));
      n=max;usedSerials.add(n);
    }
    if(Number(p.serialNo)!==n){p.serialNo=n;changed=true;}
  });
  // Keep the first non-empty file number; reserve it case-insensitively before generating replacements.
  const reservedFileKeys=new Set();
  originalKeys.forEach(k=>{if(k)reservedFileKeys.add(k)});
  const keptFileKeys=new Set(),usedFileKeys=new Set();
  db.forEach((p,i)=>{
    const original=String(p?.fileNo||'').trim(),key=original.toLocaleUpperCase();
    if(original&&!keptFileKeys.has(key)){
      keptFileKeys.add(key);usedFileKeys.add(key);
      if(p.fileNo!==original){p.fileNo=original;changed=true;}
      return;
    }
    let fileNo=formatGeneratedFileNo(Number(p.serialNo)||1),fileKey=fileNo.toLocaleUpperCase();
    if(usedFileKeys.has(fileKey)||reservedFileKeys.has(fileKey)){
      do{max++;fileNo=formatGeneratedFileNo(max);fileKey=fileNo.toLocaleUpperCase();}
      while(usedSerials.has(max)||usedFileKeys.has(fileKey)||reservedFileKeys.has(fileKey));
      // Keep the visible serial and generated file number aligned for a repaired duplicate/blank file number.
      usedSerials.delete(Number(p.serialNo));p.serialNo=max;usedSerials.add(max);
    }
    if(p.fileNo!==fileNo){p.fileNo=fileNo;changed=true;}
    usedFileKeys.add(fileKey);
  });
  max=Math.max(max,...db.map(p=>Number(p?.serialNo)||0),...db.map(p=>parseGeneratedFileNo(p?.fileNo)),0);
  localStorage.setItem(FILE_SEQ_KEY,String(max));
  if(changed)setDB(db);
}
function ensureCurrentFileNo(){
  // Do not assign or consume a patient number while the form is only a draft.
  const field=document.getElementById("fileNo");
  if(!field)return;
  if(currentPatientId){const existing=getDB().find(p=>p.id===currentPatientId);if(existing)field.value=existing.fileNo||"";}
  updateHeaderSummaries();updateCurrentRecord();
}
function idGen(){return window.crypto?.randomUUID?.()||"p-"+Date.now()+"-"+Math.random().toString(16).slice(2)}
function savePatient(){
  const d=collectPatient();
  if(!d.patientName.trim()){alert("يرجى إدخال اسم المريض أولًا.");return;}
  const db=getDB();
  const index=currentPatientId?db.findIndex(x=>x.id===currentPatientId):-1;
  if(currentPatientId&&index<0){alert("تعذر العثور على السجل المفتوح. افتح السجل من مدير السجلات مرة أخرى قبل الحفظ حتى لا تُنشئ نسخة غير مقصودة.");return;}
  const isUpdate=index>=0;
  if(isUpdate){
    const existing=db[index];
    d.id=existing.id;
    d.serialNo=Number(existing.serialNo)||parseGeneratedFileNo(existing.fileNo);
    d.fileNo=existing.fileNo||formatGeneratedFileNo(d.serialNo||1);
    currentPatientId=existing.id;
  }else{
    const next=reserveNextPatientNumber(db);
    currentPatientId=idGen();
    d.id=currentPatientId;
    d.serialNo=next.number;
    d.fileNo=next.fileNo;
  }
  const savedId=currentPatientId;
  if(isUpdate)db[index]=d;else db.push(d);
  try{
    setDB(db);
    // Commit the sequence only after localStorage successfully accepted the patient record.
    const lastCommitted=Math.max(Number(localStorage.getItem(FILE_SEQ_KEY))||0,Number(d.serialNo)||0,parseGeneratedFileNo(d.fileNo));
    localStorage.setItem(FILE_SEQ_KEY,String(lastCommitted));
  }catch(err){
    console.error(err);
    if(!isUpdate)currentPatientId=null;
    alert("تعذر حفظ بيانات المريض في التخزين المحلي. تحقّق من مساحة التخزين ثم أعد المحاولة؛ لم يتم تأكيد الحفظ.");
    return;
  }
  normalizePatientNumbering();
  const saved=getDB().find(p=>p.id===savedId);
  if(saved){setVal("serialNoDisplay",saved.serialNo||"");setVal("fileNo",saved.fileNo||"");}
  renderPatients();updateReports();updateHeaderSummaries();updateCurrentRecord();refreshPatientFiles();
  clearAutosavedDraft(isUpdate?"تم حفظ تحديثات السجل":"تم حفظ السجل النهائي");
  alert(isUpdate?`تم تحديث سجل المريض بنجاح. رقم المريض: ${saved?.serialNo||d.serialNo} — رقم الملف: ${saved?.fileNo||d.fileNo}`:`تم حفظ بيانات المريض بنجاح. رقم المريض التسلسلي: ${saved?.serialNo||d.serialNo} — رقم الملف: ${saved?.fileNo||d.fileNo}`);
}
function loadPatient(id){
  const p=getDB().find(x=>x.id===id);
  if(!p){alert("لم يتم العثور على سجل المريض المطلوب.");return;}
  if(autosaveDraftDirty){
    const ok=confirm("توجد تغييرات محفوظة تلقائيًا كمسودة لم تُعتمد بعد. هل تريد تجاهل المسودة والانتقال إلى سجل آخر؟\nاضغط «إلغاء» للعودة إلى المسودة ومتابعة العمل.");
    if(!ok)return;
    clearAutosavedDraft("تم تجاهل المسودة السابقة");
  }
  currentPatientId=id;applyPatient(p);refreshPatientFiles();toggleManager(false);
  goToSection("patient");document.getElementById("patientName")?.focus({preventScroll:true});
  alert(`تم فتح سجل المريض في وضع التعديل. رقم المريض: ${p.serialNo||"—"} — رقم الملف: ${p.fileNo||"—"}. بعد التعديل اضغط «تحديث بيانات المريض».`);
}
function returnToEdit(){
  if(!currentPatientId||!getDB().some(p=>p.id===currentPatientId)){alert("افتح سجل مريض محفوظ من «السجلات» أولًا للعودة إلى تعديله.");return;}
  toggleManager(false);goToSection("patient");document.getElementById("patientName")?.focus({preventScroll:true});
}
async function deletePatientAttachments(patientId){
  const db=await openAttachmentDB();
  try{
    await new Promise((resolve,reject)=>{
      let tx;
      try{
        tx=db.transaction(ATTACH_STORE,"readwrite");
        const store=tx.objectStore(ATTACH_STORE);
        if(!store.indexNames.contains("patientId"))throw new Error("فهرس المريض غير موجود في مخزن المرفقات");
        const request=store.index("patientId").getAllKeys(patientId);
        request.onsuccess=()=>{try{(request.result||[]).forEach(key=>store.delete(key));}catch(err){reject(err);try{tx.abort()}catch{}}};
        request.onerror=()=>{reject(request.error||new Error("تعذر العثور على مرفقات المريض"));try{tx.abort()}catch{}};
        tx.oncomplete=resolve;
        tx.onerror=()=>reject(tx.error||new Error("فشلت معاملة حذف المرفقات"));
        tx.onabort=()=>reject(tx.error||new Error("أُلغيت معاملة حذف المرفقات"));
      }catch(err){reject(err);}
    });
  }finally{db.close();}
}
async function deletePatient(id){
  if(!confirm("تأكيد حذف سجل المريض\nسيُحذف السجل ومرفقاته المرتبطة من التخزين المحلي. هذا الإجراء لا يمكن التراجع عنه من داخل البرنامج."))return;
  const previous=getDB(),patient=previous.find(x=>x.id===id);
  if(!patient)return;
  const remaining=previous.filter(x=>x.id!==id);
  try{setDB(remaining);}catch(err){console.error(err);alert("تعذر تحديث مخزن السجلات؛ لم يكتمل الحذف.");return;}
  try{
    await deletePatientAttachments(id);
  }catch(err){
    console.error(err);
    try{
      setDB(previous);
      renderPatients();updateReports();updateCurrentRecord();await refreshPatientFiles();
      alert("تعذر حذف مرفقات المريض؛ أُعيد السجل إلى قائمة المرضى ولم يكتمل الحذف. افحص التخزين ثم أعد المحاولة.");
    }catch(rollbackError){
      console.error(rollbackError);
      alert("حدث خطأ أثناء حذف المرفقات وتعذر تأكيد استعادة السجل. لا تتابع تعديل البيانات؛ أعد تحميل البرنامج وافحص السجلات والنسخة الاحتياطية فورًا.");
    }
    return;
  }
  if(currentPatientId===id){clearAutosavedDraft("تم حذف السجل الحالي");newPatient(true);}
  renderPatients();updateReports();updateCurrentRecord();await refreshPatientFiles();
  alert("تم حذف سجل المريض ومرفقاته المرتبطة بنجاح.");
}
function newPatient(skipConfirm=false){if(!skipConfirm&&!confirm("تأكيد بدء سجل جديد\nسيتم تفريغ النموذج الحالي. ستُحذف المسودة المؤقتة من هذا الجهاز، لكن السجلات المحفوظة لن تُحذف. هل تريد المتابعة؟"))return;clearAutosavedDraft("تم بدء سجل جديد");currentPatientId=null;refreshPatientFiles();applyActiveSections(Object.keys(SECTION_LABELS));basicFieldIds.forEach(id=>setVal(id,""));checkboxIds.forEach(id=>setVal(id,false));radioNames.forEach(n=>setRadio(n,""));extraFieldIds.forEach(id=>setVal(id,""));setVal("serialNoDisplay","");ensureCurrentFileNo();document.getElementById("visitDate").value=todayISO();Object.keys(tableSchemas).forEach(id=>setTableData(id,[],tableSchemas[id]));setSimpleTable("labsTable",[],()=>addLab());setSimpleTable("rxTable",[],()=>addPrescription());setSimpleTable("diagnosticsTable",[],()=>addDiagnosticRow());calculateBMI();updateHeaderSummaries();updateSummary();updateCurrentRecord();toggleManager(false);scrollTo({top:0,behavior:"smooth"})}
function renderPatients(){const body=document.getElementById("patientsBody"),q=(document.getElementById("searchPatients")?.value||"").toLowerCase();body.innerHTML="";const db=getDB().filter(p=>(`${p.patientName||""} ${p.fileNo||""}`).toLowerCase().includes(q)).sort((a,b)=>String(b.updatedAt||"").localeCompare(String(a.updatedAt||"")));if(!db.length){body.innerHTML='<tr><td colspan="6" style="text-align:center;color:#708284">لا توجد سجلات محفوظة.</td></tr>';return}db.forEach(p=>{const tr=document.createElement("tr");tr.innerHTML=`<td>${esc(String(p.serialNo||"—"))}</td><td>${esc(p.patientName||"—")}</td><td>${esc(p.fileNo||"—")}</td><td>${esc(p.visitDate||"—")}</td><td>${esc(p.clinic||"—")}</td><td class="action-cell"><button class="btn btn-outline" onclick="loadPatient('${p.id}')">تعديل</button> <button class="delete-row" onclick="deletePatient('${p.id}')">حذف</button></td>`;body.appendChild(tr)})}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function toggleManager(force){const p=document.getElementById("managerPanel");p.classList.toggle("open",typeof force==="boolean"?force:!p.classList.contains("open"));p.setAttribute("aria-hidden",p.classList.contains("open")?"false":"true");if(p.classList.contains("open"))renderPatients()}
/* ===== Unified backup: all patient records + every patient attachment ===== */
function bytesToBase64(bytes){let binary="";const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));return btoa(binary)}
function base64ToBytes(base64){const binary=atob(base64);const bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return bytes}
async function exportDatabase(button){
  button=button||null; if(button){button.disabled=true;button.dataset.oldText=button.textContent;button.textContent="جارٍ تجهيز النسخة..."}
  try{
    const patients=getDB();let attachments=[];
    const db=await openAttachmentDB();
    try{attachments=await new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readonly"),req=tx.objectStore(ATTACH_STORE).getAll();req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error)})}finally{db.close()}
    const bundled=[];
    for(let i=0;i<attachments.length;i++){
      const f=attachments[i];let blob=f.blob;
      if(!(blob instanceof Blob)&&f.blob?.type!==undefined)blob=new Blob([f.blob],{type:f.type||"application/octet-stream"});
      if(!(blob instanceof Blob))throw new Error("تعذر قراءة المرفق: "+(f.name||"ملف بدون اسم"));
      const bytes=new Uint8Array(await blob.arrayBuffer());
      bundled.push({patientId:f.patientId,name:f.name||"ملف",relativePath:f.relativePath||f.name||"ملف",type:f.type||blob.type||"application/octet-stream",size:f.size??blob.size,lastModified:f.lastModified||0,addedAt:f.addedAt||new Date().toISOString(),dataBase64:bytesToBase64(bytes)});
      if(button&&i%5===0)button.textContent=`جارٍ تجهيز المرفقات ${i+1}/${attachments.length}...`;
    }
    const backup={format:"ALDHALEA_HOSPITAL_FULL_BACKUP",version:2,createdAt:new Date().toISOString(),app:"الدليل الطبي الإكلينيكي الموحد - مستشفى الضالع الحديث",counts:{patients:patients.length,attachments:bundled.length},patients,attachments:bundled};
    const blob=new Blob([JSON.stringify(backup)],{type:"application/json;charset=utf-8"}),filename=`نسخة_كاملة_مستشفى_الضالع_الحديث_${todayISO()}.json`;
    await downloadBlob(blob,filename,blob.type);
    alert(`تم تجهيز النسخة الاحتياطية الكاملة.\nالمرضى: ${patients.length}\nالمرفقات: ${bundled.length}\nإذا كنت تستخدم APK، تأكد من أن مكوّن Android للحفظ/التنزيل مفعّل وأن الملف ظهر في التنزيلات أو نافذة المشاركة.`);
  }catch(err){console.error(err);alert("تعذر إنشاء النسخة الاحتياطية الكاملة. قد تكون مساحة التخزين أو الذاكرة غير كافية، أو تعذرت قراءة أحد المرفقات.")}
  finally{if(button){button.disabled=false;button.textContent=button.dataset.oldText||"⬇️ تصدير نسخة احتياطية كاملة";delete button.dataset.oldText}}
}
async function importDatabase(e){
  const f=e.target.files?.[0];if(!f)return;
  try{
    const parsed=JSON.parse(await f.text());
    // Backward compatibility: old JSON files contained patients only.
    if(Array.isArray(parsed)){
      if(parsed.some(p=>!p||typeof p!=="object"||Array.isArray(p)))throw new Error("ملف قديم غير صالح");
      if(!confirm("هذا ملف بيانات المرضى القديم ولا يحتوي على المرفقات. سيتم دمج سجلاته مع السجلات الحالية، ولن تتغير المرفقات الحالية. هل تريد المتابعة؟"))return;
      const m=new Map(getDB().map(p=>[p.id,p]));parsed.forEach(p=>{const id=p.id||idGen();m.set(id,{...p,id})});setDB([...m.values()]);normalizePatientNumbering();
      renderPatients();updateReports();updateCurrentRecord();alert("تم استيراد بيانات المرضى. تذكير: هذا الملف القديم لا يحتوي على المرفقات.");return;
    }
    if(!parsed||parsed.format!=="ALDHALEA_HOSPITAL_FULL_BACKUP"||parsed.version!==2||!Array.isArray(parsed.patients)||!Array.isArray(parsed.attachments))throw new Error("تنسيق النسخة غير مدعوم");
    if(parsed.patients.some(p=>!p||typeof p!=="object"||Array.isArray(p))||parsed.attachments.some(a=>!a||typeof a.patientId!=="string"||typeof a.dataBase64!=="string"))throw new Error("محتويات النسخة غير صالحة");
    const summary=`المرضى: ${parsed.patients.length}\nالمرفقات: ${parsed.attachments.length}\n\nستحل هذه النسخة محل سجلات المرضى والمرفقات الموجودة حاليًا على هذا الجهاز. صدّر نسخة من الوضع الحالي أولًا إذا كنت تريد الاحتفاظ به.\n\nهل تريد المتابعة؟`;
    if(!confirm(summary))return;
    // Decode before modifying any stored data, so malformed files cannot erase current data.
    const decoded=parsed.attachments.map(a=>({patientId:a.patientId,name:a.name||"ملف",relativePath:a.relativePath||a.name||"ملف",type:a.type||"application/octet-stream",size:Number(a.size)||0,lastModified:Number(a.lastModified)||0,addedAt:a.addedAt||new Date().toISOString(),blob:new Blob([base64ToBytes(a.dataBase64)],{type:a.type||"application/octet-stream"})}));
    const oldPatients=getDB(),restoredPatients=parsed.patients.map(p=>({...p,id:p.id||idGen()}));
    // Save patient records first; if attachment restoration fails, roll records back.
    setDB(restoredPatients);
    try{
      const db=await openAttachmentDB();
      try{await new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readwrite"),store=tx.objectStore(ATTACH_STORE);store.clear();decoded.forEach(a=>store.add(a));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)})}finally{db.close()}
    }catch(restoreError){setDB(oldPatients);throw restoreError}
    normalizePatientNumbering();currentPatientId=null;clearAutosavedDraft("تم استيراد نسخة احتياطية");renderPatients();updateReports();updateCurrentRecord();await refreshPatientFiles();
    alert(`تمت استعادة النسخة الاحتياطية الكاملة بنجاح.\nالمرضى: ${parsed.patients.length}\nالمرفقات: ${decoded.length}`);
  }catch(err){console.error(err);alert("تعذر استيراد النسخة الاحتياطية. تأكد من اختيار ملف النسخة الكاملة الصحيح وتوفر مساحة تخزين كافية.")}
  finally{e.target.value=""}
}
function updateHeaderSummaries(){const n=val("patientName")||"................................................",f=val("fileNo")||"....................",d=val("visitDate")||"....................",a=val("age")||"........",g=val("gender")||"........",c=val("clinic")||"................................";document.getElementById("coverPatientName").textContent=n;document.getElementById("coverFileNo").textContent=f;document.getElementById("coverAge").textContent=a;document.getElementById("coverGender").textContent=g;document.getElementById("coverVisitDate").textContent=d;document.getElementById("coverClinic").textContent=c;document.getElementById("rxPatientName").textContent=n;document.getElementById("rxFileNo").textContent=f;document.getElementById("rxDate").textContent=d}
function updateSummary(){updateHeaderSummaries();const s=(id,t)=>document.getElementById(id).textContent=t||"—";s("summaryName",val("patientName"));s("summaryFile",val("fileNo"));s("summaryDate",val("visitDate"));s("summaryClinic",val("clinic"));s("summaryAssessment",val("medicalAssessment"));s("summaryDiagnosis",val("diagnosis"));s("summaryPlan",[val("treatmentPlan"),val("recommendations")].filter(Boolean).join("\n\n"));updateCurrentRecord()}
document.addEventListener("input",updateSummary);document.addEventListener("change",updateSummary);
function invokePrint(){if(window.AndroidBridge&&typeof window.AndroidBridge.printWebView==="function"){window.AndroidBridge.printWebView();return "android-bridge";}window.print();return "browser-print"}
function printDocument(){updateSummary();invokePrint();}
function printSection(name){const style=document.createElement("style");style.id="section-print-style";style.textContent=`@media print{body.printing-section .page{display:none!important}body.printing-section .page[data-section="${name}"]{display:block!important;break-after:auto!important;page-break-after:auto!important}}`;document.head.appendChild(style);document.body.classList.add("printing-section");updateSummary();setTimeout(()=>{invokePrint();setTimeout(()=>{document.body.classList.remove("printing-section");style.remove()},1500)},150)}


/* ===== Patient-specific files and folders (IndexedDB, offline) ===== */
const ATTACH_DB="ALDHALEA_PATIENT_ATTACHMENTS",ATTACH_STORE="files";
function openAttachmentDB(){return new Promise((resolve,reject)=>{if(!("indexedDB" in window)){reject(new Error("IndexedDB غير مدعوم"));return}const req=indexedDB.open(ATTACH_DB,1);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(ATTACH_STORE)){const st=db.createObjectStore(ATTACH_STORE,{keyPath:"id",autoIncrement:true});st.createIndex("patientId","patientId",{unique:false})}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function uploadPatientFiles(event){const input=event.target,files=[...(input.files||[])];if(!files.length)return;if(!currentPatientId||!getDB().some(p=>p.id===currentPatientId)){alert("يرجى فتح سجل المريض أو حفظ بياناته أولًا، ثم إضافة الملفات.");input.value="";return}try{const db=await openAttachmentDB();await new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readwrite"),store=tx.objectStore(ATTACH_STORE);files.forEach(file=>store.add({patientId:currentPatientId,name:file.name,relativePath:file.webkitRelativePath||file.name,type:file.type||"application/octet-stream",size:file.size,lastModified:file.lastModified,blob:file,addedAt:new Date().toISOString()}));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)});db.close();input.value="";await refreshPatientFiles();alert(`تم حفظ ${files.length} ملف/ملفات للمريض الحالي على هذا الجهاز.`)}catch(err){console.error(err);alert("تعذر حفظ الملفات. تحقق من مساحة التخزين المتاحة في الجهاز.");input.value=""}}
async function getPatientAttachments(patientId){const db=await openAttachmentDB();return new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readonly"),req=tx.objectStore(ATTACH_STORE).index("patientId").getAll(patientId);req.onsuccess=()=>{db.close();resolve(req.result||[])};req.onerror=()=>{db.close();reject(req.error)}})}
async function refreshPatientFiles(){const status=document.getElementById("patientFilesStatus"),list=document.getElementById("patientFilesList");if(!status||!list)return;list.innerHTML="";const patient=currentPatientId&&getDB().find(p=>p.id===currentPatientId);if(!patient){status.textContent="لا يوجد مريض محدد. افتح سجل المريض أو احفظه أولًا لإدارة مرفقاته.";return}status.textContent=`المريض الحالي: ${patient.patientName||"بدون اسم"} — رقم الملف: ${patient.fileNo||"غير محدد"}`;try{const files=await getPatientAttachments(currentPatientId);if(!files.length){list.innerHTML='<div class="manager-foot">لا توجد ملفات مرفقة بهذا المريض حتى الآن.</div>';return}files.sort((a,b)=>String(a.relativePath).localeCompare(String(b.relativePath)));files.forEach(f=>{const row=document.createElement("div");row.className="patient-file-row";const info=document.createElement("div");info.className="patient-file-info";const name=document.createElement("strong");name.textContent=f.relativePath||f.name;const meta=document.createElement("small");meta.textContent=`${formatFileSize(f.size)} · ${new Date(f.addedAt).toLocaleDateString()}`;info.append(name,meta);const actions=document.createElement("div");actions.className="patient-file-actions";const down=document.createElement("button");down.className="btn btn-outline";down.textContent="تنزيل";down.onclick=()=>downloadPatientAttachment(f);const del=document.createElement("button");del.className="delete-row";del.textContent="حذف";del.onclick=()=>deletePatientAttachment(f.id);actions.append(down,del);row.append(info,actions);list.appendChild(row)})}catch(err){console.error(err);status.textContent="تعذر الوصول إلى مخزن المرفقات في هذا المتصفح."}}
function formatFileSize(bytes){if(bytes<1024)return `${bytes} بايت`;if(bytes<1024*1024)return `${(bytes/1024).toFixed(1)} كيلوبايت`;return `${(bytes/1024/1024).toFixed(2)} ميغابايت`}
async function downloadPatientAttachment(file){try{await downloadBlob(file.blob,file.name||"patient-file",file.type||"application/octet-stream");}catch(err){console.error(err);alert("تعذر تنزيل المرفق. إذا كان البرنامج داخل APK فتحقق من إعداد جسر حفظ الملفات في دليل دمج Android.");}}
async function deletePatientAttachment(id){if(!confirm("هل تريد حذف هذا المرفق من سجل المريض؟"))return;try{const db=await openAttachmentDB();await new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readwrite");tx.objectStore(ATTACH_STORE).delete(id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});db.close();await refreshPatientFiles()}catch(err){console.error(err);alert("تعذر حذف المرفق.")}}

/* ===== Per-patient section activation ===== */
const SECTION_LABELS={patient:"بيانات المريض",screening:"المسح الصحي الأولي",cvd:"تقييم القلب والأوعية",stroke:"تقييم الجلطات الدماغية",htn:"ارتفاع ضغط الدم",dm:"السكري ومضاعفاته",labs:"الفحوصات المخبرية",diagnostics:"الفحوصات التشخيصية",assessment:"التقييم الطبي",diagnosis:"التشخيص",prescription:"الوصفة الطبية",plan:"الخطة العلاجية",recommendations:"التوصيات والإحالة",followup:"سجل المتابعة",notes:"ملاحظات الطبيب",nutrition:"التغذية وضبط الجهاز الهضمي",calculator:"الحاسبة الإكلينيكية",reports:"تقارير المرضى"};
function setupSectionToggles(){document.querySelectorAll(".section-nav .nav-tab").forEach(btn=>{const key=btn.dataset.target;if(!key||btn.dataset.toggleReady)return;btn.dataset.toggleReady="1";const wrap=document.createElement("div");wrap.className="nav-item";const check=document.createElement("input");check.type="checkbox";check.className="section-toggle";check.checked=true;check.dataset.sectionToggle=key;check.setAttribute("aria-label","تفعيل قسم "+(SECTION_LABELS[key]||key));check.addEventListener("change",()=>toggleSectionEnabled(key,check.checked));btn.parentNode.insertBefore(wrap,btn);wrap.appendChild(check);wrap.appendChild(btn);});applyActiveSections(getActiveSections());}
function getActiveSections(){return [...document.querySelectorAll(".section-toggle:checked")].map(e=>e.dataset.sectionToggle)}
function applyActiveSections(keys){const set=new Set(keys||Object.keys(SECTION_LABELS));document.querySelectorAll(".section-toggle").forEach(ch=>{ch.checked=set.has(ch.dataset.sectionToggle);const key=ch.dataset.sectionToggle;const page=document.querySelector(`[data-section="${key}"]`);if(page)page.classList.toggle("section-disabled",!ch.checked);const wrap=ch.closest(".nav-item");if(wrap)wrap.classList.toggle("section-disabled-nav",!ch.checked);});}
function toggleSectionEnabled(key,enabled){const page=document.querySelector(`[data-section="${key}"]`);if(page)page.classList.toggle("section-disabled",!enabled);const wrap=document.querySelector(`.section-toggle[data-section-toggle="${key}"]`)?.closest(".nav-item");if(wrap)wrap.classList.toggle("section-disabled-nav",!enabled);if(!enabled&&document.querySelector(`.nav-tab.active[data-target="${key}"]`)){const next=document.querySelector(".section-toggle:checked");if(next)goToSection(next.dataset.sectionToggle);} }

/* ===== Navigation and clinical workflow ===== */
function goToSection(key, button){
  const section=document.querySelector(`[data-section="${key}"]`)||document.getElementById(key);
  if(!section){console.warn("Section not found:",key);return false;}
  const toggle=document.querySelector(`.section-toggle[data-section-toggle="${key}"]`);if(toggle&&!toggle.checked){toggle.checked=true;toggleSectionEnabled(key,true);}
  document.querySelectorAll(".nav-tab").forEach(b=>b.classList.toggle("active",b.dataset.target===key));
  section.scrollIntoView({behavior:"smooth",block:"start"});
  if(key==="reports")updateReports();
  return true;
}
/* ===== Automatic draft saving and recovery ===== */
function setAutoDraftStatus(message, state="ready"){
  const el=document.getElementById("autosaveStatus");if(!el)return;
  el.textContent=message;el.dataset.state=state;
  el.title=state==="error"?"تعذر حفظ المسودة تلقائيًا؛ اضغط حفظ/تحديث يدويًا وتحقق من مساحة التخزين.":"تُحفظ المسودة محليًا على هذا الجهاز. يجب الضغط على حفظ/تحديث لاعتماد السجل النهائي.";
}
function collectCalculatorDraft(){
  return [...document.querySelectorAll("#calculator input[id],#calculator select[id],#calculator textarea[id]")].map(el=>({id:el.id,value:el.value,checked:(el.type==="checkbox"||el.type==="radio")?el.checked:undefined}));
}
function collectExtraDraftControls(){
  const nodes=[...document.querySelectorAll(".document-shell input,.document-shell select,.document-shell textarea")].filter(el=>!el.closest("table")&&!el.closest(".no-autosave")&&!/^(file|button|submit|reset)$/i.test(el.type||"")&&!['fileNo','serialNoDisplay','bmi'].includes(el.id));
  let anonymousIndex=0;
  return nodes.map(el=>({key:el.id?"id:"+el.id:"auto:"+(anonymousIndex++),id:el.id||"",name:el.name||"",value:el.value??"",checked:(el.type==="checkbox"||el.type==="radio")?el.checked:undefined}));
}
function applyExtraDraftControls(items){
  if(!Array.isArray(items))return;
  const nodes=[...document.querySelectorAll(".document-shell input,.document-shell select,.document-shell textarea")].filter(el=>!el.closest("table")&&!el.closest(".no-autosave")&&!/^(file|button|submit|reset)$/i.test(el.type||"")&&!['fileNo','serialNoDisplay','bmi'].includes(el.id));
  const byId=new Map(nodes.filter(el=>el.id).map(el=>["id:"+el.id,el]));
  items.forEach((item,index)=>{
    const el=item.id?byId.get("id:"+item.id):nodes.filter(node=>!node.id)[Number(String(item.key||"").replace("auto:",""))];
    if(!el)return;
    if(typeof item.checked==="boolean")el.checked=item.checked;
    else if("value" in item)el.value=item.value??"";
  });
}
function applyCalculatorDraft(items){
  if(!Array.isArray(items))return;
  items.forEach(item=>{const el=document.getElementById(item.id);if(!el||!el.closest("#calculator"))return;if(typeof item.checked==="boolean")el.checked=item.checked;else if("value" in item)el.value=item.value??"";});
}
function autosaveHasMeaningfulContent(patient,calculator,controls){
  const ignore=new Set(["fileNo","visitDate"]);
  if(basicFieldIds.some(id=>!ignore.has(id)&&String(patient?.[id]??"").trim()))return true;
  if(extraFieldIds.some(id=>String(patient?.[id]??"").trim()))return true;
  if(checkboxIds.some(id=>!!patient?.[id]))return true;
  if(radioNames.some(name=>!!patient?.[name]))return true;
  // Ignore default dates in blank table rows; detect actual entered values in non-date cells.
  for(const [tableId,schema] of Object.entries(tableSchemas)){
    const rows=patient?.[tableId]||[];
    if(rows.some(row=>schema.some((kind,i)=>kind!=="date"&&String(row?.[i]??"").trim())))return true;
  }
  if((patient?.labsTable||[]).some(row=>[0,1,2,3,4,6].some(i=>String(row?.[i]??"").trim())))return true;
  if((patient?.rxTable||[]).some(row=>row.some(v=>String(v??"").trim())))return true;
  if((patient?.diagnosticsTable||[]).some(row=>row.some(v=>String(v??"").trim())))return true;
  if((calculator||[]).some(item=>String(item.value??"").trim()!==""&&item.id!=="clinicalCalcText"))return true;
  if((controls||[]).some(item=>typeof item.checked==="boolean"?item.checked:(String(item.value??"").trim()!==""&&!['visitDate','fileNo','serialNoDisplay','bmi','clinicalCalcText'].includes(item.id))))return true;
  const allSections=Object.keys(SECTION_LABELS||{});
  if(Array.isArray(patient?.activeSections)&&allSections.length&&patient.activeSections.length!==allSections.length)return true;
  return false;
}
function persistAutoDraft(){
  if(autosaveRestoring)return false;
  try{
    const patient=collectPatient(),calculator=collectCalculatorDraft(),controls=collectExtraDraftControls();
    if(!autosaveHasMeaningfulContent(patient,calculator,controls)){
      localStorage.removeItem(AUTOSAVE_DRAFT_KEY);autosaveDraftDirty=false;
      setAutoDraftStatus("الحفظ التلقائي جاهز — لا توجد مسودة", "ready");return true;
    }
    const draft={format:"ALDHALEA_HOSPITAL_AUTOSAVE_DRAFT",version:1,savedAt:new Date().toISOString(),patientId:currentPatientId||null,patient,calculator,controls};
    localStorage.setItem(AUTOSAVE_DRAFT_KEY,JSON.stringify(draft));
    autosaveDraftDirty=true;
    setAutoDraftStatus("✓ حُفظت المسودة تلقائيًا · لم تُعتمد كسجل نهائي","saved");
    return true;
  }catch(err){
    console.error("Automatic draft save failed:",err);
    setAutoDraftStatus("تعذّر الحفظ التلقائي — اضغط حفظ/تحديث","error");
    return false;
  }
}
function clearAutosavedDraft(message="تم مسح المسودة المؤقتة"){
  try{localStorage.removeItem(AUTOSAVE_DRAFT_KEY);autosaveDraftDirty=false;setAutoDraftStatus(message,"ready");}
  catch(err){console.error(err);setAutoDraftStatus("تعذّر مسح حالة المسودة المؤقتة","error");}
}
function restoreAutosavedDraft(){
  let draft;
  try{const raw=localStorage.getItem(AUTOSAVE_DRAFT_KEY);if(!raw)return false;draft=JSON.parse(raw);}
  catch(err){console.error("Invalid autosaved draft:",err);alert("عُثر على مسودة تالفة لا يمكن قراءتها. لن تُستبدل سجلات المرضى المحفوظة. يمكنك تجاهل المسودة والبدء من جديد.");clearAutosavedDraft("لم توجد مسودة قابلة للاستعادة");return false;}
  if(!draft||draft.format!=="ALDHALEA_HOSPITAL_AUTOSAVE_DRAFT"||draft.version!==1||!draft.patient||typeof draft.patient!=="object"){
    clearAutosavedDraft("لم توجد مسودة قابلة للاستعادة");return false;
  }
  const stamp=draft.savedAt?new Date(draft.savedAt).toLocaleString():"وقت غير معروف";
  const patientName=String(draft.patient.patientName||"مسودة بدون اسم");
  const restore=confirm(`عُثر على عمل محفوظ تلقائيًا لم يُعتمد بعد.\nالمريض/المسودة: ${patientName}\nآخر حفظ تلقائي: ${stamp}\n\nاضغط «موافق» لاستعادة الحقول والجداول ومتابعة العمل.\nاضغط «إلغاء» لتجاهل المسودة وبدء نموذج فارغ.`);
  if(!restore){clearAutosavedDraft("تم تجاهل المسودة المحفوظة تلقائيًا");return false;}
  autosaveRestoring=true;
  try{
    const savedId=draft.patientId, exists=!!(savedId&&getDB().some(p=>p.id===savedId));
    currentPatientId=exists?savedId:null;
    const patient={...draft.patient};
    if(savedId&&!exists){delete patient.id;delete patient.serialNo;patient.fileNo="";}
    applyPatient(patient);
    applyCalculatorDraft(draft.calculator);
    applyExtraDraftControls(draft.controls);
    updateSummary();updateHeaderSummaries();updateCurrentRecord();
    autosaveDraftDirty=true;
    setAutoDraftStatus("✓ استُعيدت المسودة · احفظ/حدّث لاعتماد التغييرات","saved");
    refreshPatientFiles();
    return true;
  }catch(err){
    console.error("Draft restore failed:",err);
    setAutoDraftStatus("تعذرت استعادة المسودة؛ البيانات المحفوظة لم تُحذف","error");
    alert("تعذرت استعادة المسودة تلقائيًا. لم تُحذف السجلات المحفوظة. يمكنك فتح السجلات المحفوظة أو استعادة نسخة احتياطية.");
    return false;
  }finally{autosaveRestoring=false;}
}
function initializeAutoDraft(){
  // Offer recovery before listeners start writing, so an empty initial form cannot overwrite the old draft.
  restoreAutosavedDraft();
  const handleChange=event=>{
    if(autosaveRestoring)return;
    const target=event.target;
    if(!target||!target.closest)return;
    if(!target.closest(".document-shell")&&!target.matches(".section-toggle"))return;
    if(target.matches('input[type="file"],button,[type="submit"]'))return;
    persistAutoDraft();
  };
  // Bubble phase lets field-specific handlers (for example BMI recalculation) finish first.
  document.addEventListener("input",handleChange);
  document.addEventListener("change",handleChange);
  // Also snapshot after buttons that add/remove rows or fill preset values programmatically.
  document.addEventListener("click",event=>{
    const target=event.target;
    if(!target||!target.closest||!target.closest(".document-shell"))return;
    if(target.matches('input[type="file"]'))return;
    persistAutoDraft();
  });
  window.addEventListener("beforeunload",event=>{
    if(!autosaveDraftDirty)return;
    // The draft has already been persisted; this extra warning prevents accidental navigation.
    event.preventDefault();event.returnValue="";
  });
}

function updateCurrentRecord(){
  const name=val("patientName").trim()||"مريض جديد";
  const file=val("fileNo").trim()||"—";
  const date=val("visitDate")||"—";
  const patient=currentPatientId?getDB().find(p=>p.id===currentPatientId):null;
  const serial=patient?.serialNo||"";
  const n=document.getElementById("currentRecordName"),f=document.getElementById("currentRecordFile"),d=document.getElementById("currentRecordDate"),st=document.getElementById("recordStatus");
  const serialEl=document.getElementById("currentRecordSerial"),returnBtn=document.getElementById("returnToEditBtn"),saveBtn=document.getElementById("savePatientBtn");
  if(n)n.textContent=name;if(f)f.textContent=file;if(d)d.textContent=date;
  if(serialEl)serialEl.textContent=serial?String(serial):"يُخصص بعد الحفظ";
  if(st){st.textContent=patient?"سجل محفوظ · وضع التعديل":"مسودة جديدة · لم يُخصص رقم بعد";st.classList.toggle("saved",!!patient);}
  if(returnBtn)returnBtn.hidden=!patient;
  if(saveBtn)saveBtn.textContent=patient?"💾 تحديث بيانات المريض":"💾 حفظ المريض وتخصيص الرقم";
  const serialField=document.getElementById("serialNoDisplay");if(serialField)serialField.value=serial?String(serial):"";
}

/* ===== Diagnostic procedures table ===== */
function addDiagnosticRow(type="",name=""){
  const tb=document.querySelector("#diagnosticsTable tbody");if(!tb)return;
  const tr=document.createElement("tr");tr.appendChild(cellText(tb.children.length+1));
  const tdType=document.createElement("td"),sel=document.createElement("select");
  sel.innerHTML='<option value="">اختر النوع</option><option>وظيفي</option><option>تصويري</option><option>مخبري</option><option>منظار</option><option>نسيجي</option><option>آخر</option>';sel.value=type;tdType.appendChild(sel);tr.appendChild(tdType);
  tr.appendChild(inputCell(name,"اسم الفحص"));tr.appendChild(inputCell("","النتيجة / الوصف"));tr.appendChild(inputCell("","الانطباع التشخيصي"));
  const tdDate=document.createElement("td"),dt=document.createElement("input");dt.type="date";dt.value=todayISO();tdDate.appendChild(dt);tr.appendChild(tdDate);
  tr.appendChild(inputCell("","التوصية"));const action=document.createElement("td");action.className="action-cell no-print";action.innerHTML='<button type="button" class="delete-row" onclick="removeRow(this)">حذف</button>';tr.appendChild(action);tb.appendChild(tr);renumberTable("diagnosticsTable");
}
function addDiagnosticPreset(ar,en){let type="تصويري";if(/ECG|Echocardiography|Doppler/i.test(en))type="وظيفي";addDiagnosticRow(type,`${ar} (${en})`);}
function addSelectedProcedures(){const map={ecg:["وظيفي","تخطيط القلب الكهربائي (ECG)"],echo:["وظيفي","تخطيط صدى القلب (Echocardiography)"],xray:["تصويري","الأشعة السينية (X-Ray)"],ultrasound:["تصويري","الموجات فوق الصوتية (Ultrasound)"],ct:["تصويري","الأشعة المقطعية (CT)"],mri:["تصويري","الرنين المغناطيسي (MRI)"],doppler:["تصويري","دوبلر الأوعية (Doppler)"],gastroscopy:["منظار","منظار المعدة (Gastroscopy)"],colonoscopy:["منظار","منظار القولون (Colonoscopy)"]};const chosen=[...document.querySelectorAll(".procedure-choice:checked")];if(!chosen.length){alert("يرجى تحديد إجراء واحد على الأقل.");return;}chosen.forEach(ch=>{const item=map[ch.value];if(item)addDiagnosticRow(item[0],item[1]);ch.checked=false;});updateSummary();}
function clearProcedureChoices(){const checked=[...document.querySelectorAll(".procedure-choice")].some(ch=>ch.checked);if(!checked)return;if(!confirm("تأكيد مسح الاختيارات\nهل تريد إلغاء تحديد الإجراءات المختارة؟ لن تُحذف الإجراءات التي أُضيفت إلى الجدول."))return;document.querySelectorAll(".procedure-choice").forEach(ch=>ch.checked=false);}

/* ===== Clinical calculator: formula helpers ===== */
function num(id){const x=val(id).trim();if(x==="")return null;const n=Number(x);return Number.isFinite(n)?n:null;}
function fmt(n,d=1){return Number.isFinite(n)?n.toLocaleString("en-US",{maximumFractionDigits:d,minimumFractionDigits:d}):"—";}
function resultCard(label,value,unit="",note=""){return `<div class="calc-result-card"><span>${esc(label)}</span><strong>${esc(String(value))}${unit?` <small>${esc(unit)}</small>`:""}</strong>${note?`<small>${esc(note)}</small>`:""}</div>`;}
function calculateClinicalResults(){
  const age=num("ccAge"),sex=val("ccSex"),w=num("ccWeight"),h=num("ccHeight"),sbp=num("ccSBP"),dbp=num("ccDBP"),hr=num("ccHR"),qt=num("ccQT"),glu=num("ccGlucose"),a1c=num("ccA1c"),scr=num("ccCreatinine"),bun=num("ccBUN"),na=num("ccSodium"),k=num("ccPotassium"),cl=num("ccChloride"),hco=num("ccBicarb"),ca=num("ccCalcium"),alb=num("ccAlbumin");
  const out=[],lines=[];const add=(label,value,unit="",note="")=>{out.push(resultCard(label,value,unit,note));lines.push(`${label}: ${value}${unit?" "+unit:""}${note?" — "+note:""}`)};
  const adultAgeValid=Number.isInteger(age)&&age>=18&&age<=120;
  const validSex=sex==="male"||sex==="female";
  const validWeight=Number.isFinite(w)&&w>=1&&w<=400;
  const validCreatinine=Number.isFinite(scr)&&scr>=0.1&&scr<=30;

  if(w>0&&h>0){add("مؤشر كتلة الجسم (BMI)",fmt(w/((h/100)**2),1),"kg/m²");add("مساحة سطح الجسم (Mosteller)",fmt(Math.sqrt(w*h/3600),2),"m²");if(sex&&h>0){const inches=h/2.54,ibw=(sex==="male"?50:45.5)+2.3*(inches-60);add("الوزن المثالي التقديري (Devine)",fmt(Math.max(0,ibw),1),"kg","تقدير حسابي فقط");if(age>=18){const bmr=10*w+6.25*h-5*age+(sex==="male"?5:-161);add("الاحتياج الأساسي التقديري للطاقة (Mifflin–St Jeor)",fmt(bmr,0),"kcal/day","تقدير طاقة الراحة وليس وصفة غذائية");}}}
  if(sbp>0&&dbp>0&&sbp>=dbp){add("متوسط الضغط الشرياني (MAP)",fmt(dbp+(sbp-dbp)/3,1),"mmHg");add("ضغط النبض",fmt(sbp-dbp,1),"mmHg");if(hr>0)add("مؤشر الصدمة",fmt(hr/sbp,2),"","يفسر ضمن السياق السريري");}
  if(adultAgeValid&&validWeight&&validCreatinine&&validSex){const crcl=((140-age)*w)/(72*scr)*(sex==="female"?.85:1);if(Number.isFinite(crcl)&&crcl>0)add("تصفية الكرياتينين (Cockcroft–Gault)",fmt(crcl,1),"mL/min","تقدير يعتمد على الوزن والعمر والجنس");}
  if(adultAgeValid&&validCreatinine&&validSex){const kappa=sex==="female"?.7:.9,alpha=sex==="female"?-.241:-.302;const egfr=142*Math.pow(Math.min(scr/kappa,1),alpha)*Math.pow(Math.max(scr/kappa,1),-1.2)*Math.pow(.9938,age)*(sex==="female"?1.012:1);if(Number.isFinite(egfr)&&egfr>0)add("معدل الترشيح الكبيبي (CKD-EPI 2021)",fmt(egfr,1),"mL/min/1.73m²","لا يستخدم منفردًا لتشخيص مرض كلوي مزمن");}
  if(scr!==null&&scr>0&&!adultAgeValid)add("معادلات وظائف الكلى للبالغين","لم تُحسب","","تتطلب هذه المعادلات عمرًا صحيحًا من 18 إلى 120 سنة؛ لمن هم دون 18 عامًا يلزم استخدام مسار أطفال معتمد.");
  if(a1c>0)add("متوسط السكر التقديري (eAG)",fmt(28.7*a1c-46.7,1),"mg/dL");
  if(na>0&&glu!==null){const corrected=na+1.6*((glu-100)/100);add("الصوديوم المصحح للغلوكوز",fmt(corrected,1),"mmol/L","معادلة تقريبية؛ قد تختلف الطريقة بحسب مستوى الغلوكوز");}
  if(na>0&&bun!==null&&glu!==null){add("الأسمولالية المحسوبة",fmt(2*na+glu/18+bun/2.8,1),"mOsm/kg");}
  if(na>0&&cl!==null&&hco!==null){add("فجوة الأنيونات",fmt(na-cl-hco,1),"mmol/L","دون احتساب البوتاسيوم");}
  if(ca>0&&alb>0)add("الكالسيوم المصحح للألبومين",fmt(ca+.8*(4-alb),2),"mg/dL","صيغة تقديرية؛ يفضّل الكالسيوم المتأين عند الحاجة");
  if(qt>0&&hr>0){const qtc=qt/Math.sqrt(60/hr);add("QTc (Bazett)",fmt(qtc,0),"ms","تقريب؛ قد تقل دقة Bazett عند سرعات قلبية مرتفعة أو منخفضة");}
  if(k!==null)add("البوتاسيوم المدخل",fmt(k,1),"mmol/L","قارن بالمدى المرجعي للمختبر والسياق السريري");
  if(!out.length){document.getElementById("clinicalCalcResults").innerHTML='<div class="calc-empty">أدخل مجموعة واحدة أو أكثر من القيم المطلوبة ثم أعد الحساب.</div>';document.getElementById("clinicalCalcText").value="";return [];}
  const note="النتائج تقديرية للمساندة السريرية وليست تشخيصًا أو قرارًا علاجيًا مستقلًا.";document.getElementById("clinicalCalcResults").innerHTML=out.join("")+`<p class="calc-disclaimer">${esc(note)}</p>`;document.getElementById("clinicalCalcText").value=lines.join("\n")+"\n\n"+note;return lines;
}
function resetClinicalCalculator(){if(!confirm("تأكيد تصفير الحاسبة\nسيتم تصفير مدخلات الحاسبة ونتائجها فقط، ولن تُحذف بيانات المريض أو السجلات المحفوظة. هل تريد المتابعة؟"))return;document.querySelectorAll('#calculator input[type="number"]').forEach(e=>e.value="");document.querySelectorAll('#calculator select').forEach(e=>{if(e.id.startsWith("cc"))e.selectedIndex=0;});document.getElementById("clinicalCalcResults").innerHTML='<div class="calc-empty">أدخل القيم المتاحة ثم اضغط «حساب النتائج».</div>';document.getElementById("clinicalCalcText").value="";document.getElementById("clinicalRiskResults").innerHTML='<div class="calc-empty">أكمل عوامل الخطورة ذات الصلة ثم احسب الدرجات.</div>';}
async function copyClinicalResults(){const text=val("clinicalCalcText");if(!text){alert("احسب النتائج أولًا حتى يتوفر ملخص للنسخ.");return;}try{await navigator.clipboard.writeText(text);alert("تم نسخ ملخص النتائج.");}catch{const e=document.getElementById("clinicalCalcText");e.focus();e.select();const ok=document.execCommand("copy");alert(ok?"تم نسخ ملخص النتائج.":"تعذر النسخ التلقائي؛ تم تحديد النص لنسخه يدويًا.");}}
function calculateRiskScores(){
 const v=id=>Number(val(id)||0);const ch=v("ccHeartFailure")+v("ccHypertension")+v("ccDiabetes")+v("ccStrokeHistory")+v("ccVascular")+v("ccAgeScore")+v("ccSexScore");
 const hb=v("ccBleed")+v("ccRenalBleed")+v("ccLiverBleed")+v("ccStrokeBleed")+v("ccUncontrolledBP")+v("ccLabileINR")+v("ccAlcohol")+v("ccDrugs");
 const el=document.getElementById("clinicalRiskResults");el.innerHTML=resultCard("CHA₂DS₂-VASc",String(ch),"نقطة","درجة مساعدة لتقدير خطر السكتة عند مرضى الرجفان الأذيني المناسبين")+resultCard("HAS-BLED",String(hb),"نقطة","راجع تعريف كل بند وتداخلات العلاج ومخاطر النزف")+`<p class="calc-disclaimer">هذه الدرجات لا تحدد علاج مضاد التخثر وحدها؛ راجع الدليل السريري وتفضيلات المريض وعوامل الخطورة القابلة للتعديل.</p>`;return {chadsvasc:ch,hasbled:hb};
}
function syncClinicalCalculatorFromPatient(){
 const age=num("age"),weight=num("weight"),height=num("height"),pulse=num("pulseScreen"),a1c=num("dmHba1c"),glucose=num("dmFbs");if(age!==null)setVal("ccAge",age);if(weight!==null)setVal("ccWeight",weight);if(height!==null)setVal("ccHeight",height);if(pulse!==null)setVal("ccHR",pulse);
 const bp=val("bpScreen").match(/(\d+(?:\.\d+)?)\s*[/\\-]\s*(\d+(?:\.\d+)?)/);if(bp){setVal("ccSBP",bp[1]);setVal("ccDBP",bp[2]);}
 const g=val("gender");if(g){const lower=g.toLowerCase();setVal("ccSex",/أنث|female|امرأة|نساء/.test(lower)?"female":"male");}
 if(a1c!==null)setVal("ccA1c",a1c);if(glucose!==null)setVal("ccGlucose",glucose);
 const female=val("ccSex")==="female";setVal("ccSexScore",female?"1":"0");if(age!==null)setVal("ccAgeScore",age>=75?"2":age>=65?"1":"0");
 const map=[["riskHTN","ccHypertension","1"],["riskDM","ccDiabetes","1"],["riskKidney","ccRenalBleed","1"],["riskStroke","ccStrokeHistory","2"],["riskCVD","ccVascular","1"]];map.forEach(([source,target,yes])=>setVal(target,document.getElementById(source)?.checked?yes:"0"));
 calculateClinicalResults();calculateRiskScores();
}

/* ===== Patient education templates (editable, clinician-reviewed) ===== */
function loadPatientEducationTemplate(){
  const ids=["recommendations","emergencyInstructions","patientMedicationAdvice","patientAvoidAdvice","patientFoodAdvice","patientLifestyleAdvice","patientSameDaySigns","patientFollowupInstructions"];
  if(!confirm("إدراج نصوص توعوية مقترحة\nسيتم استبدال النص الموجود في حقول التوصيات والتوعية المحددة بقوالب عامة قابلة للتعديل. راجعها وعدّلها حسب حالة المريض قبل الطباعة أو الحفظ. هل تريد المتابعة؟"))return;
  const values={
    recommendations:"• التزم بخطة العلاج والمتابعة التي يحددها الطبيب.\n• أحضر قائمة أدويتك ونتائج الفحوصات في كل زيارة.\n• لا تعتمد على هذه الإرشادات العامة بدلًا من التشخيص أو الخطة الفردية؛ اسأل الطبيب عن أي تعليمات غير واضحة.",
    emergencyInstructions:"اذهب إلى الطوارئ فورًا ولا تنتظر موعدًا عند حدوث أي مما يلي: ألم أو ضغط شديد/مستمر في الصدر؛ ضيق نفس شديد أو مفاجئ؛ تدلّي مفاجئ في الوجه أو ضعف/خدر مفاجئ في طرف أو صعوبة الكلام أو الرؤية؛ فقدان الوعي أو ارتباك شديد أو تشنج جديد؛ نزيف شديد أو قيء دموي أو براز أسود مع دوخة/ضعف؛ تورم اللسان أو الحلق أو صعوبة التنفس بعد دواء أو طعام؛ ألم شديد مفاجئ أو تدهور سريع، أو هبوط/ارتفاع سكر مصحوب باضطراب الوعي. اطلب الإسعاف أو مساعدة شخص آخر ولا تقد السيارة بنفسك إذا كانت الأعراض شديدة.",
    patientMedicationAdvice:"تناول الأدوية التي وصفها الطبيب فقط، بالجرعة والوقت والطريقة المكتوبة. لا تبدأ دواءً أو مسكنًا أو مضادًا حيويًا أو عشبة/مكملًا من نفسك، ولا توقف الدواء أو تضاعف الجرعة دون مراجعة الطبيب. أخبر الفريق الطبي عن الحساسية وجميع الأدوية والمكملات التي تستخدمها. عند ظهور تفاعل شديد أو صعوبة تنفس أو تورم بالوجه/اللسان اطلب الطوارئ فورًا.",
    patientAvoidAdvice:"تجنب التدخين والتبغ والقات قدر الإمكان. لا تستخدم أدوية الآخرين أو الأدوية من دون وصفة. لا تستخدم مضادات الالتهاب المسكنة مثل الإيبوبروفين أو الديكلوفيناك أو النابروكسين إلا بعد سؤال الطبيب، خصوصًا مع أمراض القلب أو الكلى أو الضغط أو قرحة المعدة أو مميعات الدم. لا تغيّر حمية السوائل أو الملح تغييرًا شديدًا دون تعليمات تناسب حالتك.",
    patientFoodAdvice:"تناول غذاءً متوازنًا ومتنوّعًا وقلل الإفراط في الملح والسكر والدهون والأطعمة شديدة التصنيع. تُحدد القيود الغذائية وكمية السوائل وفق التشخيص والتحاليل والأدوية؛ لا تفرض على نفسك منع السوائل أو زيادتها بكميات كبيرة ما لم يوصِ الطبيب بذلك. سجّل الأطعمة التي تزيد الأعراض أو تسبب حساسية وأخبر الطبيب عنها.",
    patientLifestyleAdvice:"خذ قسطًا مناسبًا من الراحة وامشِ أو مارس النشاط الذي يسمح به الطبيب بحسب حالتك، وتجنب المجهود عند وجود أعراض مقلقة. راقب الضغط أو السكر أو الوزن فقط وفق الخطة المحددة لك، وسجّل الأعراض وتاريخ بدايتها. احتفظ بقائمة الأدوية ونتائج الفحوصات وأحضرها عند المراجعة، واطلب التوضيح إذا لم تفهم أي تعليمات.",
    patientSameDaySigns:"اطلب تقييمًا طبيًا اليوم أو خلال 24 ساعة إذا ظهرت أعراض جديدة أو ازدادت سوءًا دون علامات الطوارئ أعلاه، أو تكرر القيء أو تعذر الاحتفاظ بالسوائل، أو ظهرت حمى مع تدهور عام، أو قلّ البول بوضوح، أو ظهر تورم جديد/متزايد، أو حدث أثر جانبي دوائي جديد، أو استمرت قراءة منزلية غير معتادة مع أعراض. إذا كانت الأعراض شديدة أو تتفاقم سريعًا فتوجّه إلى الطوارئ فورًا. يُعدّل الطبيب هذه التعليمات وفق المرض والحالة.",
    patientFollowupInstructions:"• خلال 2–7 أيام: عند طلب الطبيب مراجعة قريبة لعرض مستمر أو نتيجة فحص أو بعد بدء/تغيير علاج، إذا كانت الحالة مستقرة ولا توجد علامات خطر.\n• خلال 2–4 أسابيع أو خلال الشهر: للمتابعة الروتينية للحالات المستقرة، ومراجعة الاستجابة للعلاج والفحوصات بحسب الخطة.\n• لا تنتظر أي موعد إذا ظهرت علامة خطر؛ اذهب إلى الطوارئ فورًا.\nيجب تحديد الموعد النهائي للمريض بحسب التشخيص وشدة الحالة ونتائج الفحوصات وقدرته على المتابعة."
  };
  Object.entries(values).forEach(([id,value])=>setVal(id,value));
  setVal("patientFollowupTiming","");
  updateSummary();
  alert("تم إدراج نصوص التوعية المقترحة. راجعها وعدّلها حسب حالة المريض، ثم احفظ السجل.");
}

/* ===== Patient reports ===== */
function reportDiagnosisText(p){return [p.diagnosis,p.comorbidDiagnoses,p.medicalAssessment,p.historyPresent,p.complaint].filter(Boolean).join(" ").toLowerCase();}
function reportHas(p,key){const txt=reportDiagnosisText(p);const cb={hypertension:["riskHTN",/ارتفاع\s*ضغط|ضغط\s*الدم|hypertension|\bhtn\b/],diabetes:["riskDM",/السكري|داء\s*السكر|diabetes|\bdm\b/],cardiovascular:["riskCVD",/القلب|شرايين|وعائي|coronary|cardiovascular|\bcvd\b|myocardial/],stroke:["riskStroke",/جلط[ةه]|سكت[ةه]|نقص\s*تروية|stroke|\btia\b/],kidney:["riskKidney",/الكلى|كلوي|كلية|renal|\bckd\b|creatinine/],lipids:["riskLipid",/دهون|كوليسترول|cholesterol|dyslipid|lipid/],obesity:["riskObesity",/سمنة|بدانة|زيادة\s*الوزن|obesity/],other:["riskOther",/عامل\s*خطورة\s*آخر/]};const item=cb[key];if(!item)return false;const checked=!!p[item[0]];const bmi=Number(p.weight)>0&&Number(p.height)>0?Number(p.weight)/Math.pow(Number(p.height)/100,2):0;return checked||item[1].test(txt)||(key==="obesity"&&bmi>=30);}
function reportConditionLabels(p){const conditions=[["hypertension","ارتفاع ضغط الدم"],["diabetes","داء السكري"],["cardiovascular","القلب والأوعية"],["stroke","الجلطات / السكتات"],["kidney","أمراض الكلى"],["lipids","اضطرابات الدهون"],["obesity","زيادة الوزن / السمنة"],["other","عوامل خطورة أخرى"]];return conditions.filter(([k])=>reportHas(p,k)).map(([,label])=>label).join("، ")||"غير محدد";}
function getReportRecords(){const db=getDB(),disease=val("reportDiseaseFilter")||"all",q=val("reportSearch").trim().toLowerCase(),from=val("reportDateFrom"),to=val("reportDateTo");return db.filter(p=>{const conditions=reportConditionLabels(p);const none=conditions==="غير محدد";if(disease==="unclassified"&&!none)return false;if(disease!=="all"&&disease!=="unclassified"&&!reportHas(p,disease))return false;if(q&&!`${p.patientName||""} ${p.fileNo||""} ${reportDiagnosisText(p)} ${conditions}`.toLowerCase().includes(q))return false;const date=p.visitDate||"";if(from&&(!date||date<from))return false;if(to&&(!date||date>to))return false;return true;}).sort((a,b)=>String(a.visitDate||"").localeCompare(String(b.visitDate||""))||String(a.patientName||"").localeCompare(String(b.patientName||""),"ar"));}
function updateReports(){const db=getDB(),records=getReportRecords(),body=document.getElementById("patientReportBody");if(!body)return;const disease=val("reportDiseaseFilter")||"all",labels={all:"جميع المرضى المسجلين",hypertension:"مرضى ارتفاع ضغط الدم",diabetes:"مرضى السكري",cardiovascular:"مرضى القلب والأوعية",stroke:"مرضى الجلطات والسكتات الدماغية",kidney:"مرضى الكلى",lipids:"مرضى اضطرابات الدهون والكوليسترول",obesity:"تقارير زيادة الوزن والسمنة",other:"تقارير عوامل الخطورة الأخرى",unclassified:"السجلات غير المصنفة"};const title=labels[disease]||labels.all;setText("reportHeading",title);setText("reportPrintTitle",title);setText("reportTotalCount",String(db.length));setText("reportFilteredCount",String(records.length));setText("reportGeneratedDate",todayISO());setText("reportPrintMeta",`السجلات المحفوظة محليًا: ${db.length} — السجلات المطابقة: ${records.length} — تاريخ التقرير: ${todayISO()}`);body.innerHTML="";if(!records.length){const tr=document.createElement("tr"),td=document.createElement("td");td.colSpan=8;td.className="report-empty";td.textContent="لا توجد سجلات تطابق معايير التقرير الحالية.";tr.appendChild(td);body.appendChild(tr);return records;}records.forEach((p,i)=>{const tr=document.createElement("tr"),vals=[String(i+1),p.patientName||"—",p.fileNo||"—",`${p.age||"—"} / ${p.gender||"—"}`,p.visitDate||"—",p.clinic||"—",p.diagnosis||p.medicalAssessment||"—",reportConditionLabels(p)];vals.forEach(v=>{const td=document.createElement("td");td.textContent=v;tr.appendChild(td)});body.appendChild(tr);});return records;}
function setText(id,text){const el=document.getElementById(id);if(el)el.textContent=text;}
function resetReportFilters(){if(!confirm("تأكيد إلغاء التصفية\nسيتم عرض جميع السجلات بدلًا من نتائج التصفية الحالية، ولن تُحذف أي بيانات. هل تريد المتابعة؟"))return;setVal("reportDiseaseFilter","all");setVal("reportSearch","");setVal("reportDateFrom","");setVal("reportDateTo","");updateReports();}
function printPatientReport(){updateReports();printSection("reports");}
async function exportPatientReportCSV(){const records=getReportRecords();const headers=["م","اسم المريض","رقم الملف","العمر","الجنس","تاريخ الزيارة","العيادة / القسم","التشخيص","الأمراض / الحالات المحددة","ضغط الدم","الوزن","الطول"];const rows=records.map((p,i)=>[i+1,p.patientName,p.fileNo,p.age,p.gender,p.visitDate,p.clinic,p.diagnosis||p.medicalAssessment,reportConditionLabels(p),p.bpScreen,p.weight,p.height]);const csv="\uFEFF"+[headers,...rows].map(row=>row.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\r\n");await downloadBlob(csv,`تقرير_مرضى_${val("reportDiseaseFilter")||"all"}_${todayISO()}.csv`,"text/csv;charset=utf-8");}
async function downloadBlob(content,name,type){
  const blob=content instanceof Blob?content:new Blob([content],{type});
  // Optional bridge for APK hosts: AndroidBridge.saveFileBase64(filename, mimeType, base64).
  // The APK must implement this bridge natively. Browser download remains the default fallback.
  if(window.AndroidBridge&&typeof window.AndroidBridge.saveFileBase64==="function"){
    const bytes=new Uint8Array(await blob.arrayBuffer());let binary="";for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));
    window.AndroidBridge.saveFileBase64(name,blob.type||type||"application/octet-stream",btoa(binary));return "android-bridge";
  }
  const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);return "browser-download";
}
