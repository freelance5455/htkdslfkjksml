const $=id=>document.getElementById(id);
let receipts=JSON.parse(localStorage.getItem('adhat_receipts')||'[]');
$('date').value=new Date().toISOString().slice(0,10);
$('receiptNo').value=nextNo();
['weight','rate','commissionPct','labor','transport','other'].forEach(id=>$(id).addEventListener('input',calc));
function money(n){return Number(n||0).toLocaleString('en-PK',{maximumFractionDigits:2})}
function nextNo(){return String((receipts.reduce((m,r)=>Math.max(m,Number(r.receiptNo)||0),0))+1).padStart(4,'0')}
function calc(){
 const gross=(+$('weight').value||0)*(+$('rate').value||0);
 const comm=gross*(+$('commissionPct').value||0)/100;
 const deductions=comm+(+$('labor').value||0)+(+$('transport').value||0)+(+$('other').value||0);
 const net=gross-deductions;
 $('gross').textContent=money(gross);$('commission').textContent=money(comm);$('deductions').textContent=money(deductions);$('net').textContent=money(net);
 return {gross,comm,deductions,net};
}
function data(){let t=calc();return {receiptNo:$('receiptNo').value,date:$('date').value,buyer:$('buyer').value,seller:$('seller').value,item:$('item').value,weight:+$('weight').value||0,unit:$('unit').value,rate:+$('rate').value||0,commissionPct:+$('commissionPct').value||0,labor:+$('labor').value||0,transport:+$('transport').value||0,other:+$('other').value||0,notes:$('notes').value,...t}}
function saveReceipt(){let r=data(); if(!r.buyer&&!r.seller){alert('خریدار یا فروخت کنندہ کا نام درج کریں');return} let i=receipts.findIndex(x=>x.receiptNo===r.receiptNo); if(i>=0)receipts[i]=r;else receipts.push(r);localStorage.setItem('adhat_receipts',JSON.stringify(receipts));alert('رسید محفوظ ہوگئی');render()}
function clearForm(){document.querySelectorAll('input,textarea').forEach(x=>{if(!['date','receiptNo'].includes(x.id))x.value=''});$('commissionPct').value=0;$('labor').value=0;$('transport').value=0;$('other').value=0;$('date').value=new Date().toISOString().slice(0,10);$('receiptNo').value=nextNo();calc()}
function loadReceipt(no){let r=receipts.find(x=>x.receiptNo===no);if(!r)return;Object.keys(r).forEach(k=>{if($(k))$(k).value=r[k]??''});calc();window.scrollTo({top:0,behavior:'smooth'})}
function deleteReceipt(no){if(confirm('یہ رسید حذف کریں؟')){receipts=receipts.filter(x=>x.receiptNo!==no);localStorage.setItem('adhat_receipts',JSON.stringify(receipts));render()}}
function render(){let q=$('search').value.trim().toLowerCase();let list=receipts.filter(r=>(r.receiptNo+' '+r.buyer+' '+r.seller+' '+r.item).toLowerCase().includes(q));$('rows').innerHTML=list.map(r=>`<tr><td>${r.receiptNo}</td><td>${r.date}</td><td>${r.buyer||''}</td><td>${r.seller||''}</td><td>${r.item||''}</td><td>${money(r.net)}</td><td><button class="smallbtn" onclick="loadReceipt('${r.receiptNo}')">کھولیں</button> <button class="smallbtn danger" onclick="deleteReceipt('${r.receiptNo}')">حذف</button></td></tr>`).join('')}
function printReceipt(){
 let r=data();
 $('printArea').innerHTML=`<div class="receipt"><h1>اڑھت رسید</h1><p><b>رسید نمبر:</b> ${r.receiptNo} &nbsp;&nbsp; <b>تاریخ:</b> ${r.date}</p><table><tr><th>خریدار</th><td>${r.buyer}</td><th>فروخت کنندہ</th><td>${r.seller}</td></tr><tr><th>جنس</th><td>${r.item}</td><th>وزن</th><td>${money(r.weight)} ${r.unit}</td></tr><tr><th>ریٹ</th><td>${money(r.rate)}</td><th>کل مال</th><td>${money(r.gross)} روپے</td></tr><tr><th>کمیشن</th><td>${money(r.comm)} روپے</td><th>مزدوری</th><td>${money(r.labor)} روپے</td></tr><tr><th>ٹرانسپورٹ</th><td>${money(r.transport)} روپے</td><th>دیگر کٹوتی</th><td>${money(r.other)} روپے</td></tr><tr><th colspan="2">خالص قابل ادائیگی</th><td colspan="2"><b>${money(r.net)} روپے</b></td></tr></table><p><b>نوٹ:</b> ${r.notes||''}</p><div class="sign"><span>دستخط خریدار: __________</span><span>دستخط اڑھتی: __________</span></div></div>`;window.print()}
function monthlyReport(){let m=$('reportMonth').value;if(!m){alert('مہینہ منتخب کریں');return}let a=receipts.filter(r=>r.date.startsWith(m));let gross=a.reduce((s,r)=>s+r.gross,0),comm=a.reduce((s,r)=>s+r.comm,0),net=a.reduce((s,r)=>s+r.net,0);$('report').innerHTML=`<div class="reportbox"><b>${m}</b><br>رسیدوں کی تعداد: ${a.length}<br>کل مال: ${money(gross)} روپے<br>کل کمیشن: ${money(comm)} روپے<br>کل خالص رقم: ${money(net)} روپے</div>`}
function exportData(){let blob=new Blob([JSON.stringify(receipts,null,2)],{type:'application/json'});let a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='adhat-backup.json';a.click();URL.revokeObjectURL(a.href)}
function importData(e){let f=e.target.files[0];if(!f)return;let rd=new FileReader();rd.onload=()=>{try{let x=JSON.parse(rd.result);if(!Array.isArray(x))throw 0;receipts=x;localStorage.setItem('adhat_receipts',JSON.stringify(receipts));render();alert('بیک اپ بحال ہوگیا')}catch{alert('غلط بیک اپ فائل')}};rd.readAsText(f)}
render();calc();