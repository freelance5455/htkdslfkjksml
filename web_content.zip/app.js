/**
 * Maa Annapurna Tiffin Service - Core Business Logic
 * Location: Kunwar Singh Nagar | Phone: +91 9311155593
 * 6-Digit Box QR Codes, Cash Collection & WhatsApp Payment QR Link
 */

// ==========================================
// STORAGE KEYS & GLOBAL STATE
// ==========================================
const STORAGE_KEYS = {
  CLIENTS: 'annapurna_clients_v2',
  LOGS: 'annapurna_logs_v2',
  BOX_STATE: 'annapurna_box_state_v2',
  SETTINGS: 'annapurna_settings_v2',
  WEEKLY_MENU: 'annapurna_weekly_menu_v2',
  CUSTOM_MENUS: 'annapurna_custom_menus_v2',
  EXTRA_ITEMS: 'annapurna_extra_items_v2',
  QR_DATABASE: 'annapurna_qr_db_v2',
  MENU_ITEMS: 'annapurna_menu_items_v2'
};

let clients = [];
let logs = [];
let boxStates = {}; 
let qrDatabase = [];
let menuItemsList = [
  {
    id: 'meal-1',
    name: 'Special Lunch Thali',
    price: 80,
    mealType: 'lunch',
    items: '1). Shahi Paneer\n2). Kali Masoor Daal Tadka\n3). 4 Tawa Roti with Desi Ghee\n4). Jeera Rice\n5). Fresh Salad & Achar',
    enabled: true
  },
  {
    id: 'meal-2',
    name: 'Deluxe Paneer Feast Thali',
    price: 120,
    mealType: 'both',
    items: '1). Kadhai Paneer\n2). Dal Makhani\n3). 4 Tawa Roti with Desi Ghee\n4). Matar Pulao\n5). Boondi Raita\n6). Gulab Jamun (2 Pcs)',
    enabled: true
  },
  {
    id: 'meal-3',
    name: 'Regular Dinner Thali',
    price: 80,
    mealType: 'dinner',
    items: '1). Seasonal Mix Veg Curry\n2). Arhar Daal Fry Tadka\n3). 4 Tawa Roti with Desi Ghee\n4). Steamed Rice\n5). Green Salad',
    enabled: true
  },
  {
    id: 'meal-4',
    name: 'Punjabi Dal Makhani Special',
    price: 90,
    mealType: 'lunch',
    items: '1). Punjabi Dal Makhani\n2). Aloo Gobhi Matar Masala\n3). 4 Tawa Roti with Desi Ghee\n4). Jeera Rice\n5). Papad & Achar',
    enabled: true
  },
  {
    id: 'meal-5',
    name: 'Mini Meal / Diet Thali',
    price: 60,
    mealType: 'both',
    items: '1). Yellow Moong Daal Tadka\n2). Jeera Aloo Sabzi\n3). 3 Tawa Roti\n4). Fresh Green Salad',
    enabled: true
  }
];
const QR_INITIAL_START_SERIAL = 81026; // Base numeric value for 6-digit serialized codes: 081026, 081027...

let settings = {
  bizName: 'Maa Annapurna Tiffin Service',
  bizPhone: '+91 9311155593',
  bizAddress: 'Kunwar Singh Nagar',
  bizEmail: 'annapurna.tiffin@gmail.com',
  defaultPrice: 2500,
  upiId: '9311155593@paytm',
  qrPrefix: '', // System uses pure 6-digit serialized codes starting at 081026
  customQrImage: null
};

// Weekly Menu (Monday to Saturday) - Lunch & Dinner
let weeklyMenu = {
  monday: {
    lunch: {
      title: 'Monday Special Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Shahi Paneer\n2). 🍲 Kali Masoor Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 🍋🟩 Achar/Chutney 🍀`
    },
    dinner: {
      title: 'Monday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Seasonal Mix Veg Curry\n2). 🍲 Arhar Daal Fry Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Basmati Rice\n5). 🥗 Fresh Green Salad\n6). 😋 Achar`
    }
  },
  tuesday: {
    lunch: {
      title: 'Tuesday Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Dal Makhani\n2). 🍲 Aloo Gobhi Matar Masala\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 🍋 Achar & Papad`
    },
    dinner: {
      title: 'Tuesday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Matar Paneer / Lauki Chana Daal\n2). 🍲 Moong Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Rice\n5). 🥗 Fresh Salad\n6). 😋 Achar`
    }
  },
  wednesday: {
    lunch: {
      title: 'Wednesday Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Special Kadi Pakoda\n2). 🍲 Mix Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 😋 Achar`
    },
    dinner: {
      title: 'Wednesday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Aloo Shimla Mirch / Baingan Bharta\n2). 🍲 Chana Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Rice\n5). 🥗 Fresh Salad\n6). 🍋 Achar`
    }
  },
  thursday: {
    lunch: {
      title: 'Thursday Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Rajma Masala\n2). 🍲 Bundi Raita Or Arhar Daal Tadka (any one of your choice 😋)\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 🍋🟩 Achar/Chutney 🍀`
    },
    dinner: {
      title: 'Thursday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Sev Tamatar Ki Sabzi / Paneer Bhurji\n2). 🍲 Yellow Moong Daal\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Rice\n5). 🥗 Fresh Salad\n6). 😋 Achar`
    }
  },
  friday: {
    lunch: {
      title: 'Friday Special Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 90,
      items: `1). 🥘 Paneer Butter Masala\n2). 🍲 Yellow Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 🍋 Achar & Chutney`
    },
    dinner: {
      title: 'Friday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Bhindi Masala Do Pyaza\n2). 🍲 Panchmel Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Rice\n5). 🥗 Fresh Salad\n6). 😋 Achar`
    }
  },
  saturday: {
    lunch: {
      title: 'Saturday Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Amritsari Chole Masala\n2). 🍲 Jeera Aloo\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Veg Pulao\n5). 🥗 Fresh Salad 🥒\n6). 😋 Achar/Chutney`
    },
    dinner: {
      title: 'Saturday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 85,
      items: `1). 🥘 Palak Paneer / Kadai Veg\n2). 🍲 Toor Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad\n6). 🍨 Gulab Jamun`
    }
  }
};

let customMenus = [
  {
    id: 'cmenu-1',
    title: 'Maa Annapurna Deluxe Thali',
    mealType: 'both',
    tagline: 'Special Occasion Feast',
    price: 130,
    items: `1). 🥘 Kadhai Paneer\n2). 🍲 Dal Makhani\n3). 🫓 4 Tawa Roti with Pure Desi Ghee\n4). 🍚 Matar Pulao\n5). 🥣 Boondi Raita\n6). 🍨 Gulab Jamun (2 Pcs)`
  }
];

let extraItemsCatalog = [
  { id: 'ext-1', name: 'Extra Tawa Roti with Desi Ghee', price: 10, unit: 'pc' },
  { id: 'ext-2', name: 'Boondi Raita / Fresh Curd', price: 20, unit: 'cup' },
  { id: 'ext-3', name: 'Sweet Dish (Gulab Jamun)', price: 20, unit: 'pc' },
  { id: 'ext-4', name: 'Extra Sabzi Portion', price: 35, unit: 'portion' },
  { id: 'ext-5', name: 'Masala Buttermilk (Chaas)', price: 15, unit: 'bottle' },
  { id: 'ext-6', name: 'Extra Jeera Rice', price: 25, unit: 'portion' }
];

let currentTab = 'dashboard';
let currentDate = new Date().toISOString().split('T')[0];
let currentSelectedMenuDay = 'monday';
let currentMenuMealType = 'lunch';
let scannerInstance = null;
let currentScanMode = 'dispatch';
let paymentFilter = 'all';
let deferredPrompt = null;
let upiQrCodeInstance = null;

// -------------------------------------------------------------------------
// DARK MODE THEME CONTROLLER
// -------------------------------------------------------------------------
function initTheme() {
  const savedTheme = localStorage.getItem('MAT_THEME');
  const isDark = savedTheme === 'dark' || (!savedTheme && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches);
  if (isDark) {
    document.documentElement.classList.add('dark');
    document.body.classList.add('dark');
  } else {
    document.documentElement.classList.remove('dark');
    document.body.classList.remove('dark');
  }
  updateThemeIcon(isDark);
}

function toggleDarkMode() {
  const isDark = document.body.classList.toggle('dark');
  if (isDark) {
    document.documentElement.classList.add('dark');
    localStorage.setItem('MAT_THEME', 'dark');
  } else {
    document.documentElement.classList.remove('dark');
    localStorage.setItem('MAT_THEME', 'light');
  }
  updateThemeIcon(isDark);
}

function updateThemeIcon(isDark) {
  const icon = document.getElementById('darkModeIcon');
  if (icon) {
    icon.setAttribute('data-lucide', isDark ? 'sun' : 'moon');
    if (window.lucide) lucide.createIcons();
  }
}

window.toggleDarkMode = toggleDarkMode;
window.initTheme = initTheme;

// Splash Screen Controller
function dismissSplashScreen() {
  const splash = document.getElementById('appSplashScreen');
  const bar = document.getElementById('splashProgressBar');
  const status = document.getElementById('splashStatusText');
  if (bar) bar.style.width = '100%';
  if (status) status.textContent = 'Ready!';

  setTimeout(() => {
    if (splash) {
      splash.classList.add('splash-hidden');
      setTimeout(() => {
        splash.style.display = 'none';
      }, 500);
    }
  }, 400);
}

// Initialize on Load
document.addEventListener('DOMContentLoaded', async () => {
  initTheme();
  setupDates();
  setInitialDayFromCurrentDate();

  // Progress animation on splash screen
  const bar = document.getElementById('splashProgressBar');
  if (bar) setTimeout(() => { bar.style.width = '70%'; }, 200);

  await initFirebaseSessionAndData();
  renderDashboard();
  renderMenuList();
  renderMenuPlanner();
  renderCustomMenusList();
  renderExtraItemsCatalog();
  renderClientList();
  renderReturnScreen();
  renderPaymentsList();
  renderSettings();
  renderQrDatabaseList();
  generate1InchQrLabels();
  generateQRStickers();
  if (window.lucide && typeof lucide.createIcons === 'function') {
    try { lucide.createIcons(); } catch(e){}
  }

  // Transition from Splash Screen
  setTimeout(() => {
    dismissSplashScreen();
    if (typeof FirebaseAuth !== 'undefined' && !FirebaseAuth.isAuthenticated()) {
      openFirebaseAuthScreen(true);
    }
  }, 1000);
});

function purgeLegacyLocalStorage() {
  Object.values(STORAGE_KEYS).forEach(k => {
    try { localStorage.removeItem(k); } catch (e) {}
  });
}

async function initFirebaseSessionAndData() {
  purgeLegacyLocalStorage();

  // 1. Initialize Firebase App, Auth, & Firestore (Pre-configured developer keys)
  if (typeof FirebaseAppManager !== 'undefined') {
    FirebaseAppManager.init();
  }

  // 2. Setup Firebase Auth Observer & Real-Time Sync
  if (typeof FirebaseAuth !== 'undefined') {
    FirebaseAuth.onAuthStateChanged(async (user) => {
      updateFirebaseAuthUi(user);

      if (user) {
        // User logged in: Listen for live cloud updates across phones & tablets
        if (typeof FirebaseSync !== 'undefined') {
          FirebaseSync.listenToRealtimeUpdates((newData) => {
            if (newData) {
              applyLoadedCloudData(newData);
              renderDashboard();
              renderMenuList();
              renderClientList();
              renderQrDatabaseList();
              renderPaymentsList();
              renderReturnScreen();
            }
          });
        }
      }
    });

    FirebaseAuth.initAuthObserver();
  }

  // 3. Fallback check for Cognito / legacy auth
  if (typeof CognitoAuth !== 'undefined') {
    try {
      const session = await CognitoAuth.checkSession();
      if (session.isAuthenticated) {
        updateAuthUi(session.user);
      }
    } catch (e) {}
  }

  await loadData();
}

function updateFirebaseAuthUi(user) {
  const displayEl = document.getElementById('firebaseUserEmailDisplay');
  const authDisplay = document.getElementById('authDisplayAccount');

  if (user) {
    const label = user.phoneNumber || user.email || user.displayName || 'Admin';
    if (displayEl) {
      displayEl.innerHTML = `<span class="truncate font-bold text-slate-800">${label}</span>`;
    }
    if (authDisplay) {
      authDisplay.textContent = label;
    }
  } else {
    if (displayEl) {
      displayEl.innerHTML = `<span class="text-orange-600 font-bold">Sign In / Register &rarr;</span>`;
    }
  }
  if (window.lucide) lucide.createIcons();
}

function applyLoadedCloudData(cloudData) {
  if (!cloudData) return;
  if (cloudData.clients) clients = cloudData.clients;
  if (cloudData.logs) logs = cloudData.logs;
  if (cloudData.boxStates) boxStates = cloudData.boxStates;
  if (cloudData.settings) settings = { ...settings, ...cloudData.settings };
  if (cloudData.weeklyMenu) {
    delete cloudData.weeklyMenu.sunday;
    weeklyMenu = { ...weeklyMenu, ...cloudData.weeklyMenu };
  }
  if (cloudData.customMenus) customMenus = cloudData.customMenus;
  if (cloudData.extraItemsCatalog) extraItemsCatalog = cloudData.extraItemsCatalog;
  if (cloudData.menuItemsList && Array.isArray(cloudData.menuItemsList) && cloudData.menuItemsList.length > 0) {
    menuItemsList = cloudData.menuItemsList;
  }
  if (cloudData.qrDatabase && Array.isArray(cloudData.qrDatabase) && cloudData.qrDatabase.length > 0) {
    qrDatabase = cloudData.qrDatabase;
  } else {
    ensureInitialQrDatabase();
  }
}

async function loadData() {
  try {
    let cloudData = null;

    // 1. Firebase Firestore Cloud Database (Primary Realtime Stack)
    if (typeof FirebaseSync !== 'undefined' && FirebaseSync.isConfigured()) {
      cloudData = await FirebaseSync.fetchUserData();

      // Listen for realtime cloud updates across phones & tablets
      FirebaseSync.listenToRealtimeUpdates((newData) => {
        if (newData) {
          applyLoadedCloudData(newData);
          renderDashboard();
          renderMenuList();
          renderClientList();
          renderQrDatabaseList();
          renderPaymentsList();
          renderReturnScreen();
        }
      });
    }
    // 2. Supabase Cloud Database (Secondary Fallback)
    else if (typeof SupabaseClient !== 'undefined' && SupabaseClient.isConfigured()) {
      cloudData = await SupabaseClient.fetchUserData();

      SupabaseClient.setupRealtimeSubscription((newData) => {
        if (newData) {
          applyLoadedCloudData(newData);
          renderDashboard();
          renderMenuList();
          renderClientList();
          renderQrDatabaseList();
          renderPaymentsList();
          renderReturnScreen();
        }
      });
    } 
    // 3. AWS DynamoDB
    else if (typeof DynamoClient !== 'undefined' && typeof AWS_CONFIG !== 'undefined' && AWS_CONFIG.isConfigured()) {
      cloudData = await DynamoClient.fetchUserData();
    } 
    // 4. Sandbox / Local Session Cloud
    else if (typeof FirebaseSync !== 'undefined') {
      cloudData = await FirebaseSync.fetchUserData();
    }

    if (cloudData) {
      applyLoadedCloudData(cloudData);
    } else {
      loadInitialDefaults();
      saveData(true);
    }
  } catch (err) {
    console.error('Error loading data from cloud:', err);
    loadInitialDefaults();
  }
}

function ensureInitialQrDatabase() {
  if (qrDatabase && qrDatabase.length > 0) return;

  const now = new Date();
  const time1 = new Date(now.getTime() - 3.5 * 3600 * 1000).toISOString();
  const time2 = new Date(now.getTime() - 25 * 3600 * 1000).toISOString();
  const genTime = new Date(now.getTime() - 72 * 3600 * 1000).toISOString();

  qrDatabase = [];

  // Generate initial batch starting strictly from 081026
  for (let i = 0; i < 25; i++) {
    const serial = String(QR_INITIAL_START_SERIAL + i).padStart(6, '0');
    let status = 'Available';
    let customerId = null;
    let customerName = null;
    let customerPhone = null;
    let customerAddress = null;
    let allotmentDate = null;
    let returnDate = null;
    let deliveryPartner = 'Kitchen Partner';
    let allotmentHistory = [];
    let returnHistory = [];

    if (i === 0) {
      // 081026 - Mr. Rahul Sharma (Allotted)
      status = 'Allotted';
      customerId = 'c-1';
      customerName = 'Mr. Rahul Sharma';
      customerPhone = '9823412345';
      customerAddress = 'House 42, Kunwar Singh Nagar';
      allotmentDate = time1;
      deliveryPartner = 'Ramesh';
      allotmentHistory.push({
        customerId: 'c-1',
        customerName: 'Mr. Rahul Sharma',
        customerPhone: '9823412345',
        allotmentDate: time1,
        deliveryPartner: 'Ramesh',
        mealCategory: 'Lunch',
        menuTitle: weeklyMenu.monday.lunch.title,
        price: 100,
        paymentMode: 'cash'
      });
    } else if (i === 3) {
      // 081029 - Mr. Sunil Mehta (Allotted)
      status = 'Allotted';
      customerId = 'c-4';
      customerName = 'Mr. Sunil Mehta';
      customerPhone = '9833445566';
      customerAddress = 'C-34, Industrial Area Phase 1';
      allotmentDate = time2;
      deliveryPartner = 'Suresh';
      allotmentHistory.push({
        customerId: 'c-4',
        customerName: 'Mr. Sunil Mehta',
        customerPhone: '9833445566',
        allotmentDate: time2,
        deliveryPartner: 'Suresh',
        mealCategory: 'Dinner',
        menuTitle: weeklyMenu.thursday.dinner.title,
        price: 80,
        paymentMode: 'due'
      });
    } else if (i === 1) {
      // 081027 - Mrs. Pooja Verma (Returned earlier today, now Available)
      status = 'Available';
      returnDate = time1;
      returnHistory.push({
        customerId: 'c-2',
        customerName: 'Mrs. Pooja Verma',
        returnDate: time1,
        collectedCash: false
      });
    }

    qrDatabase.push({
      qrNumber: serial,
      status,
      customerId,
      customerName,
      customerPhone,
      customerAddress,
      allotmentDate,
      returnDate,
      deliveryPartner,
      lastUpdated: now.toISOString(),
      generatedDate: genTime,
      allotmentHistory,
      returnHistory
    });

    if (status === 'Allotted') {
      boxStates[serial] = {
        status: 'with_client',
        clientId: customerId,
        clientName: customerName,
        clientPhone: customerPhone,
        clientAddress: customerAddress,
        dispatchedAt: allotmentDate,
        mealCategory: i === 0 ? 'Lunch' : 'Dinner',
        menuTitle: i === 0 ? weeklyMenu.monday.lunch.title : weeklyMenu.thursday.dinner.title,
        menuItems: i === 0 ? 'Shahi Paneer, Kali Masoor Daal Tadka, 4 Tawa Roti, Jeera Rice, Salad, Achar' : 'Sev Tamatar Ki Sabzi, Moong Daal, 4 Roti, Rice, Salad',
        extras: i === 0 ? '1x Sweet Dish (Gulab Jamun)' : 'None',
        price: i === 0 ? 100 : 80,
        paymentMode: i === 0 ? 'cash' : 'due'
      };
    } else {
      boxStates[serial] = {
        status: 'available',
        clientId: null,
        clientName: null,
        clientPhone: null,
        clientAddress: null,
        collectedAt: returnDate || now.toISOString()
      };
    }
  }
}

function loadInitialDefaults() {
  // Uses clean 6-digit serialized box codes starting strictly from 081026
  clients = [
    {
      id: 'c-1',
      name: 'Mr. Rahul Sharma',
      phone: '9823412345',
      address: 'House 42, Kunwar Singh Nagar',
      area: 'Kunwar Singh Nagar',
      boxId: '081026',
      mealType: 'Lunch',
      price: 2500,
      paymentStatus: 'pending',
      dueAmount: 2500,
      startDate: currentDate,
      status: 'active',
      clientType: 'subscriber'
    },
    {
      id: 'c-2',
      name: 'Mrs. Pooja Verma',
      phone: '9898765432',
      address: 'Shop No. 12, Main Market Road',
      area: 'Market Complex',
      boxId: '081027',
      mealType: 'Both',
      price: 4500,
      paymentStatus: 'paid',
      dueAmount: 0,
      startDate: currentDate,
      status: 'active',
      clientType: 'subscriber'
    },
    {
      id: 'c-3',
      name: 'Mr. Rohan Gupta',
      phone: '9711223344',
      address: 'Plot 55, Near Temple, Kunwar Singh Nagar',
      area: 'Kunwar Singh Nagar',
      boxId: '081028',
      mealType: 'Lunch',
      price: 2600,
      paymentStatus: 'paid',
      dueAmount: 0,
      startDate: currentDate,
      status: 'active',
      clientType: 'subscriber'
    },
    {
      id: 'c-4',
      name: 'Mr. Sunil Mehta',
      phone: '9833445566',
      address: 'C-34, Industrial Area Phase 1',
      area: 'Industrial Area',
      boxId: '081029',
      mealType: 'Dinner',
      price: 2500,
      paymentStatus: 'pending',
      dueAmount: 1800,
      startDate: currentDate,
      status: 'active',
      clientType: 'subscriber'
    },
    {
      id: 'c-5',
      name: 'Mr. Vikram Joshi (Guest Order)',
      phone: '9871100223',
      address: 'Flat 204, Shivam Tower, Kunwar Singh Nagar',
      area: 'Kunwar Singh Nagar',
      boxId: '081030',
      mealType: 'Lunch',
      price: 90,
      paymentStatus: 'paid',
      dueAmount: 0,
      startDate: currentDate,
      status: 'active',
      clientType: 'onetime'
    }
  ];

  ensureInitialQrDatabase();

  const now = new Date();
  const time1 = new Date(now.getTime() - 3.5 * 3600 * 1000).toISOString();
  const time2 = new Date(now.getTime() - 25 * 3600 * 1000).toISOString();

  logs = [
    {
      id: 'log-1',
      timestamp: time1,
      date: currentDate,
      boxId: '081026',
      clientId: 'c-1',
      clientName: 'Mr. Rahul Sharma',
      mealCategory: 'Lunch',
      menuTitle: weeklyMenu.monday.lunch.title,
      menuItems: 'Shahi Paneer, Kali Masoor Daal Tadka, 4 Roti, Jeera Rice, Salad, Achar',
      extras: '1x Sweet Dish (Gulab Jamun)',
      price: 100,
      paymentMode: 'cash',
      type: 'dispatch'
    },
    {
      id: 'log-2',
      timestamp: time2,
      date: new Date(Date.now() - 25 * 3600 * 1000).toISOString().split('T')[0],
      boxId: '081029',
      clientId: 'c-4',
      clientName: 'Mr. Sunil Mehta',
      mealCategory: 'Dinner',
      menuTitle: weeklyMenu.thursday.dinner.title,
      menuItems: 'Sev Tamatar Ki Sabzi, Moong Daal, 4 Roti, Rice, Salad',
      extras: 'None',
      price: 80,
      paymentMode: 'due',
      type: 'dispatch'
    }
  ];

  saveData();
}

function saveData(immediate = false) {
  const payload = {
    clients,
    logs,
    boxStates,
    settings,
    weeklyMenu,
    customMenus,
    extraItemsCatalog,
    qrDatabase,
    menuItemsList
  };

  // 1. Firebase Cloud Firestore (Primary Real-Time Sync & Auto Cloud Backup)
  if (typeof FirebaseSync !== 'undefined') {
    FirebaseSync.saveUserData(payload, immediate);
  }

  // 2. Supabase Cloud Database (Secondary)
  if (typeof SupabaseClient !== 'undefined' && SupabaseClient.isConfigured()) {
    SupabaseClient.saveUserData(payload, immediate);
  } 
  // 3. AWS DynamoDB / Sandbox Cloud
  else if (typeof DynamoClient !== 'undefined') {
    DynamoClient.saveUserData(payload, immediate);
  }
}

function setupDates() {
  const dateInput = document.getElementById('dashDateSelector');
  if (dateInput) dateInput.value = currentDate;
  
  const todayLabel = document.getElementById('todayDateStr');
  const d = new Date();
  const options = { weekday: 'short', day: 'numeric', month: 'short' };
  if (todayLabel) todayLabel.textContent = d.toLocaleDateString('en-US', options);

  const clientStartDate = document.getElementById('clientStartDate');
  if (clientStartDate) clientStartDate.value = currentDate;
}

function setInitialDayFromCurrentDate() {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const dayIndex = new Date().getDay();
  const todayName = days[dayIndex];

  if (todayName === 'sunday') {
    currentSelectedMenuDay = 'monday';
  } else {
    currentSelectedMenuDay = todayName;
  }
}

function changeDate(newDate) {
  currentDate = newDate;
  renderDashboard();
}

// ==========================================
// NAVIGATION & TABS
// ==========================================
function switchTab(tabId) {
  if (tabId === 'pending') tabId = 'return';
  currentTab = tabId;

  document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
  const activeContent = document.getElementById(`tab-${tabId}`);
  if (activeContent) activeContent.classList.remove('hidden');

  // Bottom floating nav styling
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('text-orange-600', 'font-semibold');
    btn.classList.add('text-slate-500');
  });

  const activeNavBtn = document.getElementById(`nav-${tabId}`);
  if (activeNavBtn) {
    activeNavBtn.classList.remove('text-slate-500');
    activeNavBtn.classList.add('text-orange-600', 'font-semibold');
  }

  // Top admin menu bar styling
  document.querySelectorAll('.admin-menu-btn').forEach(btn => {
    btn.classList.remove('bg-slate-900', 'text-white');
  });
  const activeAdminBtn = document.getElementById(`adminMenu-${tabId}`);
  if (activeAdminBtn) {
    activeAdminBtn.classList.add('bg-slate-900', 'text-white');
  }

  if (tabId === 'dashboard') renderDashboard();
  if (tabId === 'menu') {
    renderMenuList();
    renderMenuPlanner();
    renderCustomMenusList();
  }
  if (tabId === 'return') renderReturnScreen();
  if (tabId === 'clients') renderClientList();
  if (tabId === 'payments') renderPaymentsList();
  if (tabId === 'qrgenerator') {
    renderQrDatabaseList();
    generate1InchQrLabels();
    generateQRStickers();
  }
  if (tabId === 'settings') renderSettings();

  lucide.createIcons();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ==========================================
// AUDIO BEEP FEEDBACK
// ==========================================
function playBeepSound(type = 'success') {
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (type === 'success') {
      osc.frequency.setValueAtTime(850, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1350, audioCtx.currentTime + 0.14);
      gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.18);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.18);
    } else {
      osc.frequency.setValueAtTime(400, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(260, audioCtx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.28);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.28);
    }
  } catch (e) {}
}

// ==========================================
// DASHBOARD LOGIC (OPERATIONS & CASH VS UPI)
// ==========================================
function renderDashboard() {
  document.getElementById('headerBizName').textContent = settings.bizName;
  document.getElementById('headerSubtitle').textContent = `${settings.bizAddress} • ${settings.bizPhone}`;

  const dayLogs = logs.filter(l => l.date === currentDate);
  const dispatchedToday = dayLogs.filter(l => l.type === 'dispatch').length;
  
  // Real counts from qrDatabase
  const returnedToday = qrDatabase.filter(q => q.returnDate && q.returnDate.startsWith(currentDate)).length;
  const totalAllotted = qrDatabase.filter(q => q.status === 'Allotted').length;
  const pendingCount = totalAllotted;

  // 1. Total Clients
  const totalClients = clients.length;
  // 2. Active Monthly Subscribers
  const monthlySubscribers = clients.filter(c => (c.subscriptionType === 'monthly') || (c.clientType === 'subscriber' && c.subscriptionType !== 'daily')).length;
  // 3. Daily Customers
  const dailyCustomers = clients.filter(c => c.subscriptionType === 'daily' || c.clientType === 'onetime').length;
  // 4. Total Returns (Total returns in system / today)
  const totalReturnsCount = qrDatabase.filter(q => q.returnDate || (Array.isArray(q.returnHistory) && q.returnHistory.length > 0)).length;

  // Calculate Cash vs UPI today
  const cashToday = dayLogs.reduce((sum, l) => sum + (l.paymentMode === 'cash' ? (Number(l.price) || 0) : 0), 0);
  const upiToday = dayLogs.reduce((sum, l) => sum + (l.paymentMode === 'upi' ? (Number(l.price) || 0) : 0), 0);
  const todayCollection = cashToday + upiToday;

  // 7. Monthly Revenue: Sum of active monthly subscriptions + month daily collections
  const currentMonthStr = currentDate.slice(0, 7); // YYYY-MM
  const monthlySubSum = clients
    .filter(c => (c.subscriptionType === 'monthly') || (c.clientType === 'subscriber' && c.subscriptionType !== 'daily'))
    .reduce((sum, c) => sum + (Number(c.monthlyAmount) || Number(c.price) || 0), 0);
  const monthDailySum = logs
    .filter(l => l.date && l.date.startsWith(currentMonthStr) && (l.paymentMode === 'cash' || l.paymentMode === 'upi'))
    .reduce((sum, l) => sum + (Number(l.price) || 0), 0);
  const monthlyRevenue = monthlySubSum + monthDailySum;

  const totalDues = clients.reduce((sum, c) => sum + (c.paymentStatus === 'pending' ? (Number(c.dueAmount) || 0) : 0), 0);

  // Update the 7 Core Metrics Cards
  const elTotalClients = document.getElementById('statTotalClients');
  const elMonthlySubscribers = document.getElementById('statMonthlySubscribers');
  const elDailyCustomers = document.getElementById('statDailyCustomers');
  const elTotalAllotted = document.getElementById('statTotalAllotted');
  const elTotalReturns = document.getElementById('statTotalReturns');
  const elTodayCollection = document.getElementById('statTodayCollection');
  const elMonthlyRevenue = document.getElementById('statMonthlyRevenue');

  if (elTotalClients) elTotalClients.textContent = totalClients;
  if (elMonthlySubscribers) elMonthlySubscribers.textContent = monthlySubscribers;
  if (elDailyCustomers) elDailyCustomers.textContent = dailyCustomers;
  if (elTotalAllotted) elTotalAllotted.textContent = totalAllotted;
  if (elTotalReturns) elTotalReturns.textContent = returnedToday > 0 ? returnedToday : totalReturnsCount;
  if (elTodayCollection) elTodayCollection.textContent = `₹${todayCollection.toLocaleString('en-IN')}`;
  if (elMonthlyRevenue) elMonthlyRevenue.textContent = `₹${monthlyRevenue.toLocaleString('en-IN')}`;

  // Update sub-counters and backwards compatibility elements
  const elDispatched = document.getElementById('statDispatchedToday');
  const elCollected = document.getElementById('statCollectedToday');
  const elPending = document.getElementById('statPendingCount');
  const elDues = document.getElementById('statPendingPayments');
  const cashDisplay = document.getElementById('statCashToday');
  const upiDisplay = document.getElementById('statUpiToday');

  if (elDispatched) elDispatched.textContent = dispatchedToday;
  if (elCollected) elCollected.textContent = returnedToday;
  if (elPending) elPending.textContent = pendingCount;
  if (elDues) elDues.textContent = `₹${totalDues.toLocaleString('en-IN')}`;
  if (cashDisplay) cashDisplay.textContent = `₹${cashToday.toLocaleString('en-IN')}`;
  if (upiDisplay) upiDisplay.textContent = `₹${upiToday.toLocaleString('en-IN')}`;

  // Menu Preview
  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  document.getElementById('dashTodayDayName').textContent = `${capitalize(currentSelectedMenuDay)}'s Menus:`;

  const lunchFirst = daySchedule.lunch.items.split('\n')[0] || 'Special Lunch Thali';
  const dinnerFirst = daySchedule.dinner.items.split('\n')[0] || 'Special Dinner Thali';
  document.getElementById('quickLunchPreviewText').textContent = `${lunchFirst.replace(/^[0-9]\)\.\s*/, '')} (₹${daySchedule.lunch.price})`;
  document.getElementById('quickDinnerPreviewText').textContent = `${dinnerFirst.replace(/^[0-9]\)\.\s*/, '')} (₹${daySchedule.dinner.price})`;

  // Nav Badges
  const navBadge = document.getElementById('navPendingBadge');
  const navReturnBadge = document.getElementById('navReturnBadge');
  if (navBadge) {
    if (pendingCount > 0) {
      navBadge.textContent = pendingCount;
      navBadge.classList.remove('hidden');
    } else {
      navBadge.classList.add('hidden');
    }
  }
  if (navReturnBadge) {
    if (pendingCount > 0) {
      navReturnBadge.textContent = pendingCount;
      navReturnBadge.classList.remove('hidden');
    } else {
      navReturnBadge.classList.add('hidden');
    }
  }

  // Pending Alert Banner
  const alertBanner = document.getElementById('pendingAlertBanner');
  if (pendingCount > 0) {
    alertBanner.classList.remove('hidden');
    document.getElementById('bannerPendingTitle').textContent = `Action Required: ${pendingCount} Tiffin Containers Unreturned`;
  } else {
    alertBanner.classList.add('hidden');
  }

  // Recent Activity Log
  const activityList = document.getElementById('recentActivityList');
  const recentLogs = [...logs].reverse().slice(0, 10);
  document.getElementById('activityCount').textContent = `${logs.length} Entries`;

  if (recentLogs.length === 0) {
    activityList.innerHTML = `
      <div class="text-center py-6 text-slate-400 text-xs">
        No meal dispatches recorded for today yet. Tap "Dispatch Tiffin" to scan and deliver!
      </div>
    `;
  } else {
    activityList.innerHTML = recentLogs.map(log => {
      const isDispatch = log.type === 'dispatch';
      const timeStr = new Date(log.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
      return `
        <div class="py-2.5 flex items-start justify-between">
          <div class="flex items-start space-x-3">
            <div class="w-8 h-8 rounded-xl ${isDispatch ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'} flex items-center justify-center text-sm font-bold mt-0.5">
              ${isDispatch ? '↗️' : '↙️'}
            </div>
            <div>
              <div class="text-xs font-bold text-slate-900 flex items-center space-x-1.5">
                <span>${log.clientName || 'Client'}</span>
                <span class="box-code-badge text-[10px] py-0.5 px-2">${log.boxId}</span>
                ${log.mealCategory ? `<span class="badge-soft-orange px-1.5 py-0.2 text-[9px] font-bold rounded uppercase">${log.mealCategory}</span>` : ''}
                ${log.price ? `<span class="badge-soft-emerald px-1.5 py-0.2 text-[10px] font-bold rounded">₹${log.price}</span>` : ''}
                ${log.paymentMode === 'cash' ? `<span class="text-[9px] font-bold bg-amber-100 text-amber-800 px-1 py-0.2 rounded">💵 CASH</span>` : ''}
              </div>
              <div class="text-[11px] text-slate-500 mt-0.5">
                ${isDispatch ? (log.menuTitle || 'Meal Dispatched') : 'Empty Box Collected'}
                ${log.extras && log.extras !== 'None' ? `<span class="text-emerald-700 font-semibold block text-[10px]">+ Extras: ${log.extras}</span>` : ''}
              </div>
            </div>
          </div>
          <div class="text-right">
            <span class="text-[11px] font-semibold text-slate-500">${timeStr}</span>
          </div>
        </div>
      `;
    }).join('');
  }

  lucide.createIcons();
}

// ==========================================
// WEEKLY MENU (LUNCH vs DINNER)
// ==========================================
function selectMenuDay(dayKey) {
  currentSelectedMenuDay = dayKey;
  
  document.querySelectorAll('#weeklyDayPills .day-pill').forEach(btn => btn.classList.remove('active'));
  const daysArray = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const pillIndex = daysArray.indexOf(dayKey);
  const pill = document.querySelectorAll('#weeklyDayPills .day-pill')[pillIndex];
  if (pill) pill.classList.add('active');

  renderMenuPlanner();
}

function toggleMenuMealType(type) {
  currentMenuMealType = type;
  const btnLunch = document.getElementById('toggleLunchTabBtn');
  const btnDinner = document.getElementById('toggleDinnerTabBtn');

  if (type === 'lunch') {
    btnLunch.className = 'flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 bg-white text-orange-600 shadow-2xs';
    btnDinner.className = 'flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 text-slate-600';
  } else {
    btnDinner.className = 'flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 bg-white text-blue-600 shadow-2xs';
    btnLunch.className = 'flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 text-slate-600';
  }

  renderMenuPlanner();
}

function renderMenuPlanner() {
  const dayObj = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const mealObj = dayObj[currentMenuMealType] || dayObj.lunch;

  document.getElementById('currentDayMenuTitle').textContent = `${capitalize(currentSelectedMenuDay)} ${capitalize(currentMenuMealType)} Menu`;
  document.getElementById('currentDayTagline').textContent = mealObj.tagline || 'Fresh . Hygienic . Homemade . Delicious';
  document.getElementById('currentDayPrice').value = mealObj.price;
  document.getElementById('currentDayItems').value = mealObj.items;
}

function saveCurrentDayMenu() {
  const dayObj = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const mealObj = dayObj[currentMenuMealType] || dayObj.lunch;

  mealObj.price = Number(document.getElementById('currentDayPrice').value) || 80;
  mealObj.items = document.getElementById('currentDayItems').value.trim();

  saveData();
  renderDashboard();

  Swal.fire({
    icon: 'success',
    title: 'Menu Saved!',
    text: `${capitalize(currentSelectedMenuDay)} ${capitalize(currentMenuMealType)} menu updated.`,
    timer: 1500,
    showConfirmButton: false
  });
}

// Custom Menus
function renderCustomMenusList() {
  const container = document.getElementById('customMenusList');
  if (!container) return;

  if (customMenus.length === 0) {
    container.innerHTML = `
      <div class="p-3 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">
        No custom menus created yet. Tap "+ Create Menu" to add special thalis.
      </div>
    `;
    return;
  }

  container.innerHTML = customMenus.map(m => `
    <div class="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
      <div class="flex items-start justify-between">
        <div>
          <div class="flex items-center space-x-2">
            <h4 class="text-xs font-bold text-slate-900">${m.title}</h4>
            <span class="badge-soft-orange px-1.5 py-0.2 rounded text-[9px] font-bold uppercase">${m.mealType || 'Both'}</span>
          </div>
          <span class="text-[10px] text-slate-500">${m.tagline || 'Special Thali'}</span>
        </div>
        <div class="flex items-center space-x-1">
          <span class="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">₹${m.price}</span>
          <button onclick="editCustomMenu('${m.id}')" class="text-slate-400 hover:text-orange-600 p-1"><i data-lucide="edit-2" class="w-3.5 h-3.5"></i></button>
          <button onclick="deleteCustomMenu('${m.id}')" class="text-slate-400 hover:text-red-600 p-1"><i data-lucide="trash-2" class="w-3.5 h-3.5"></i></button>
        </div>
      </div>
      <p class="text-[11px] text-slate-600 font-mono whitespace-pre-line bg-white p-2 rounded-lg border border-slate-100">${m.items}</p>
    </div>
  `).join('');

  lucide.createIcons();
}

function openCreateMenuModal(menu = null) {
  const modal = document.getElementById('customMenuModal');
  const title = document.getElementById('customMenuModalTitle');
  const form = document.getElementById('customMenuForm');
  form.reset();

  if (menu) {
    title.textContent = 'Edit Menu';
    document.getElementById('customMenuId').value = menu.id;
    document.getElementById('customMenuTitle').value = menu.title;
    document.getElementById('customMenuMealType').value = menu.mealType || 'both';
    document.getElementById('customMenuTagline').value = menu.tagline || '';
    document.getElementById('customMenuPrice').value = menu.price;
    document.getElementById('customMenuItems').value = menu.items;
  } else {
    title.textContent = 'Create New Menu';
    document.getElementById('customMenuId').value = '';
    document.getElementById('customMenuPrice').value = 85;
    document.getElementById('customMenuMealType').value = 'lunch';
    document.getElementById('customMenuTagline').value = 'Fresh . Hygienic . Homemade';
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeCustomMenuModal() {
  document.getElementById('customMenuModal').classList.add('hidden');
}

function saveCustomMenu(event) {
  event.preventDefault();
  const id = document.getElementById('customMenuId').value;
  const title = document.getElementById('customMenuTitle').value.trim();
  const mealType = document.getElementById('customMenuMealType').value;
  const tagline = document.getElementById('customMenuTagline').value.trim();
  const price = Number(document.getElementById('customMenuPrice').value) || 85;
  const items = document.getElementById('customMenuItems').value.trim();

  if (id) {
    const idx = customMenus.findIndex(m => m.id === id);
    if (idx !== -1) customMenus[idx] = { id, title, mealType, tagline, price, items };
  } else {
    customMenus.push({
      id: 'cmenu-' + Date.now(),
      title,
      mealType,
      tagline,
      price,
      items
    });
  }

  saveData();
  closeCustomMenuModal();
  renderCustomMenusList();

  Swal.fire({ icon: 'success', title: 'Menu Saved!', timer: 1400, showConfirmButton: false });
}

function editCustomMenu(id) {
  const menu = customMenus.find(m => m.id === id);
  if (menu) openCreateMenuModal(menu);
}

function deleteCustomMenu(id) {
  Swal.fire({
    title: 'Delete Menu?',
    text: 'Do you want to remove this custom menu?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, Delete'
  }).then(res => {
    if (res.isConfirmed) {
      customMenus = customMenus.filter(m => m.id !== id);
      saveData();
      renderCustomMenusList();
    }
  });
}

// Extra Add-ons
function renderExtraItemsCatalog() {
  const container = document.getElementById('extraItemsCatalogList');
  if (!container) return;

  container.innerHTML = extraItemsCatalog.map(item => `
    <div class="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
      <div>
        <span class="font-bold text-slate-800">${item.name}</span>
        <span class="text-emerald-700 font-semibold block text-[11px]">₹${item.price} / ${item.unit}</span>
      </div>
      <button onclick="removeExtraItem('${item.id}')" class="text-slate-400 hover:text-red-600 p-1">
        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
      </button>
    </div>
  `).join('');

  lucide.createIcons();
}

function promptAddNewExtraItem() {
  Swal.fire({
    title: 'Add Extra Item',
    html: `
      <div class="text-left text-xs space-y-2.5">
        <div>
          <label class="block font-semibold text-slate-700 mb-1">Item Name:</label>
          <input type="text" id="newExtraName" placeholder="e.g. Extra Roti, Gulab Jamun, Papad" class="w-full p-2 border border-slate-300 rounded-xl text-xs">
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Price (₹):</label>
            <input type="number" id="newExtraPrice" value="15" class="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold">
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Unit:</label>
            <input type="text" id="newExtraUnit" value="pc" class="w-full p-2 border border-slate-300 rounded-xl text-xs">
          </div>
        </div>
      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#ea580c',
    confirmButtonText: 'Add Item',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      const name = document.getElementById('newExtraName').value.trim();
      const price = Number(document.getElementById('newExtraPrice').value) || 15;
      const unit = document.getElementById('newExtraUnit').value.trim() || 'pc';

      if (!name) return;

      extraItemsCatalog.push({ id: 'ext-' + Date.now(), name, price, unit });
      saveData();
      renderExtraItemsCatalog();
      Swal.fire({ icon: 'success', title: 'Extra item added!', timer: 1200, showConfirmButton: false });
    }
  });
}

function removeExtraItem(id) {
  extraItemsCatalog = extraItemsCatalog.filter(x => x.id !== id);
  saveData();
  renderExtraItemsCatalog();
}

// WhatsApp Broadcast for Today's Lunch & Dinner Menu
function shareTodayMenuWhatsApp() {
  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const dateFormatted = new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const extrasText = extraItemsCatalog.slice(0, 4).map(x => `• ${x.name} (+₹${x.price})`).join('\n');

  const text = `🍱 *${settings.bizName.toUpperCase()}* 🍱
📍 *Address*: ${settings.bizAddress}
📅 *${capitalize(currentSelectedMenuDay)}'s Daily Menu* | ${dateFormatted}

☀️ *LUNCH MENU (दोपहर का भोजन)*:
${daySchedule.lunch.items}
💰 Price: ₹${daySchedule.lunch.price}/- per Thali

🌙 *DINNER MENU (रात्रि का भोजन)*:
${daySchedule.dinner.items}
💰 Price: ₹${daySchedule.dinner.price}/- per Thali

⭐ *Available Add-ons / Extras*:
${extrasText}

💳 *Online Payment Options*:
• UPI ID: ${settings.upiId} (GPay/PhonePe/Paytm)
• Scan UPI QR Code: https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi%3A%2F%2Fpay%3Fpa%3D${encodeURIComponent(settings.upiId)}%26pn%3DMaa%20Annapurna%20Tiffin%26cu%3DINR

📞 *For bookings and home delivery, call*: ${settings.bizPhone}
_Pure . Fresh . Hygienic . Homemade Taste!_ 🙏`;

  const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

// ==========================================
// SEPARATE RETURN TIFFIN SCREEN
// ==========================================
let returnFilterMode = 'out'; // 'out' | 'today' | 'all'

function setReturnFilter(mode) {
  returnFilterMode = mode;
  const btnOut = document.getElementById('returnFilterOutBtn');
  const btnToday = document.getElementById('returnFilterTodayBtn');
  const btnAll = document.getElementById('returnFilterAllBtn');

  if (btnOut) btnOut.className = mode === 'out' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-900 text-white transition' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 transition';
  if (btnToday) btnToday.className = mode === 'today' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-900 text-white transition' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 transition';
  if (btnAll) btnAll.className = mode === 'all' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-900 text-white transition' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 transition';

  renderReturnScreen();
}

function renderReturnScreen() {
  const container = document.getElementById('returnListContainer');
  if (!container) return;

  const todayStr = currentDate || new Date().toISOString().split('T')[0];

  const outBoxes = qrDatabase.filter(q => q.status === 'Allotted');
  const returnedTodayBoxes = qrDatabase.filter(q => q.returnDate && q.returnDate.startsWith(todayStr));
  const inKitchenBoxes = qrDatabase.filter(q => q.status === 'Available');

  // Update hero & pill counters
  const statOut = document.getElementById('returnStatOutCount');
  const statRet = document.getElementById('returnStatReturnedToday');
  const statInKit = document.getElementById('returnStatInKitchen');
  const filterCountOut = document.getElementById('returnFilterCountOut');
  const filterCountToday = document.getElementById('returnFilterCountToday');
  const navReturnBadge = document.getElementById('navReturnBadge');

  if (statOut) statOut.textContent = outBoxes.length;
  if (statRet) statRet.textContent = returnedTodayBoxes.length;
  if (statInKit) statInKit.textContent = inKitchenBoxes.length;
  if (filterCountOut) filterCountOut.textContent = outBoxes.length;
  if (filterCountToday) filterCountToday.textContent = returnedTodayBoxes.length;

  if (navReturnBadge) {
    if (outBoxes.length > 0) {
      navReturnBadge.textContent = outBoxes.length;
      navReturnBadge.classList.remove('hidden');
    } else {
      navReturnBadge.classList.add('hidden');
    }
  }

  // Filter selection
  let list = [];
  if (returnFilterMode === 'out') {
    list = outBoxes;
  } else if (returnFilterMode === 'today') {
    list = returnedTodayBoxes;
  } else {
    list = qrDatabase;
  }

  // Manual Search Query: QR Number, Customer Name, Mobile Number
  const searchInput = document.getElementById('returnSearchInput');
  const q = searchInput ? searchInput.value.trim().toLowerCase() : '';
  if (q) {
    list = list.filter(item => {
      const matchQr = item.qrNumber && item.qrNumber.toLowerCase().includes(q);
      const matchName = item.customerName && item.customerName.toLowerCase().includes(q);
      const matchPhone = item.customerPhone && item.customerPhone.includes(q);
      const matchAddress = item.customerAddress && item.customerAddress.toLowerCase().includes(q);
      return matchQr || matchName || matchPhone || matchAddress;
    });
  }

  if (list.length === 0) {
    container.innerHTML = `
      <div class="aesthetic-card p-8 text-center space-y-2">
        <div class="text-3xl">🎉</div>
        <h3 class="text-sm font-bold text-slate-800">No Containers Matching Filter</h3>
        <p class="text-xs text-slate-500">${returnFilterMode === 'out' ? 'All dispatched tiffin boxes are safely returned to the kitchen!' : 'Try a different search keyword or filter.'}</p>
      </div>
    `;
    lucide.createIcons();
    return;
  }

  container.innerHTML = list.map(item => {
    const isAllotted = item.status === 'Allotted';
    const timeAgo = isAllotted ? getTimeAgoText(item.allotmentDate) : (item.returnDate ? 'Returned today' : 'In kitchen');
    const isOverdue = isAllotted && isOlderThan24Hours(item.allotmentDate);
    const boxState = boxStates[item.qrNumber] || {};
    const client = clients.find(c => c.id === item.customerId);
    const dueAmt = client && client.paymentStatus === 'pending' ? client.dueAmount : 0;

    return `
      <div class="aesthetic-card p-3.5 space-y-2.5 ${isOverdue ? 'border-red-300 bg-red-50/20' : ''}">
        <div class="flex items-start justify-between">
          <div class="flex items-start space-x-2.5">
            <!-- Scannable Container QR Thumbnail -->
            <div onclick="openQrEnlargeModal('${item.qrNumber}')" 
                 class="qr-db-thumb-box cursor-pointer group relative shrink-0" 
                 title="Click to Zoom / Download QR" style="width: 58px; height: 58px;">
              <div id="qr-return-thumb-${item.qrNumber}" class="w-full h-full flex items-center justify-center"></div>
              <div class="absolute inset-0 bg-slate-900/60 rounded-[10px] opacity-0 group-hover:opacity-100 flex items-center justify-center transition text-white text-[9px] font-bold">
                🔍 Zoom
              </div>
            </div>

            <div>
              <div class="flex items-center space-x-1.5 flex-wrap">
                <span class="qr-serial-badge text-xs px-2 py-0.5">${item.qrNumber}</span>
                <h4 class="text-xs font-bold text-slate-900">${item.customerName || (isAllotted ? 'Assigned Customer' : 'Ready in Kitchen')}</h4>
                ${isAllotted 
                  ? `<span class="badge-soft-amber px-1.5 py-0.2 rounded text-[9.5px] font-bold">WITH CLIENT</span>` 
                  : `<span class="badge-soft-emerald px-1.5 py-0.2 rounded text-[9.5px] font-bold">IN KITCHEN</span>`
                }
                ${dueAmt > 0 ? `<span class="badge-soft-red px-1.5 py-0.2 rounded text-[9.5px] font-bold">DUE: ₹${dueAmt}</span>` : ''}
              </div>
              <p class="text-[11px] text-slate-500 truncate max-w-[180px] sm:max-w-xs">${item.customerAddress || item.customerPhone || 'Kunwar Singh Nagar'}</p>
              
              ${boxState.menuTitle ? `
                <div class="mt-1 text-[11px] text-slate-600 bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg">
                  <span class="font-semibold text-orange-700">${boxState.menuTitle}:</span> 
                  ${boxState.menuItems ? `<span class="text-slate-500 block truncate max-w-xs">${boxState.menuItems}</span>` : ''}
                </div>
              ` : ''}
              
              <div class="mt-1 text-[10px] text-slate-400 flex items-center space-x-2">
                <span>Partner: <b>${item.deliveryPartner || 'Kitchen'}</b></span>
                <span>&bull;</span>
                <button onclick="openQrHistoryModal('${item.qrNumber}')" class="text-orange-600 hover:underline font-bold">View History</button>
              </div>
            </div>
          </div>
          <span class="text-[10px] font-bold ${isOverdue ? 'badge-soft-red' : (isAllotted ? 'badge-soft-orange' : 'badge-soft-emerald')} px-2 py-0.5 rounded-full whitespace-nowrap">
            ${timeAgo}
          </span>
        </div>

        ${isAllotted ? `
          <div class="grid grid-cols-3 gap-2 pt-1 border-t border-slate-100">
            <a href="tel:${item.customerPhone || ''}" class="flex items-center justify-center py-2 px-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold">
              <i data-lucide="phone" class="w-3.5 h-3.5 mr-1 text-slate-600"></i>
              <span>Call</span>
            </a>

            <button onclick="sendProfessionalReturnNotice('${item.customerPhone || ''}', '${item.customerName || 'Customer'}', '${item.qrNumber}', '${item.customerAddress || ''}')" class="flex items-center justify-center py-2 px-2 badge-soft-emerald hover:bg-emerald-100 rounded-xl text-xs font-bold">
              <i data-lucide="message-circle" class="w-3.5 h-3.5 mr-1 text-emerald-600"></i>
              <span>WhatsApp</span>
            </button>

            <button onclick="handleReturnScan('${item.qrNumber}')" class="flex items-center justify-center py-2 px-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs">
              <i data-lucide="check" class="w-3.5 h-3.5 mr-1"></i>
              <span>Return Box</span>
            </button>
          </div>
        ` : `
          <div class="flex items-center justify-between pt-1 border-t border-slate-100 text-[11px]">
            <span class="text-emerald-700 font-semibold">✓ Clean & Ready for Allotment</span>
            <button onclick="handleDispatchScan('${item.qrNumber}')" class="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-2xs">
              🍱 Allot to Client
            </button>
          </div>
        `}
      </div>
    `;
  }).join('');

  // Render QR image thumbnails for each container in return screen
  list.forEach(item => {
    const thumbEl = document.getElementById(`qr-return-thumb-${item.qrNumber}`);
    if (thumbEl) {
      renderQrCodeElement(thumbEl, item.qrNumber, 54);
    }
  });

  lucide.createIcons();
}

// Backward compatibility aliases
function renderPendingList(searchFilter = '') {
  renderReturnScreen();
}

function filterPendingList() {
  renderReturnScreen();
}

function getTimeAgoText(isoString) {
  if (!isoString) return 'Delivered Today';
  const diffHours = Math.floor((Date.now() - new Date(isoString).getTime()) / (1000 * 60 * 60));
  if (diffHours < 1) return 'Just now';
  if (diffHours < 12) return `${diffHours}h ago`;
  if (diffHours < 24) return 'Earlier today';
  const days = Math.floor(diffHours / 24);
  return `${days}d overdue ⚠️`;
}

function isOlderThan24Hours(isoString) {
  if (!isoString) return false;
  const diffHours = (Date.now() - new Date(isoString).getTime()) / (1000 * 60 * 60);
  return diffHours >= 20;
}

// Professional WhatsApp Box Return Notice
function sendProfessionalReturnNotice(phone, clientName, boxId, address) {
  if (!phone) {
    Swal.fire({ icon: 'warning', title: 'Phone number unavailable' });
    return;
  }
  let cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length === 10) cleanPhone = '91' + cleanPhone;

  const msg = `Dear ${clientName},

Greetings from *${settings.bizName}* (Kunwar Singh Nagar)! 🙏

This is a gentle reminder regarding the collection of your empty tiffin container:
🍱 *Tiffin Box ID*: ${boxId}
📍 *Pickup Location*: ${address || 'Registered Address'}

Our delivery partner will be arriving shortly. Kindly keep the empty tiffin container accessible for collection.

Thank you for your valuable cooperation!
Warm regards,
*${settings.bizName}*
📞 ${settings.bizPhone}`;

  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}

function notifyAllPendingWhatsApp() {
  const pendingBoxes = Object.entries(boxStates).filter(([_, state]) => state.status === 'with_client');
  if (pendingBoxes.length === 0) {
    Swal.fire({ icon: 'info', title: 'No pending boxes', text: 'All tiffin containers have been collected.' });
    return;
  }
  Swal.fire({
    title: 'Send Pickup Reminders?',
    text: `You have ${pendingBoxes.length} uncollected containers. You can trigger WhatsApp notices one-by-one from the list.`,
    icon: 'question',
    confirmButtonColor: '#10b981',
    confirmButtonText: 'View Pending List'
  });
}

// ==========================================
// QR SCANNER (DISPATCH & RETURN)
// ==========================================
let currentCameraId = null;
let availableCameraList = [];
let allotmentTargetBoxSlot = 0;

function openScannerModal(mode = 'dispatch') {
  if (mode === 'auto') mode = currentScanMode || 'dispatch';
  setScanMode(mode);

  const modal = document.getElementById('scannerModal');
  if (modal) modal.classList.remove('hidden');
  lucide.createIcons();

  startQrScanner();
}

function openScannerFromAllotment(slotIndex = 0) {
  allotmentTargetBoxSlot = slotIndex;
  openScannerModal('allotment');
}

async function closeScannerModal() {
  const modal = document.getElementById('scannerModal');
  if (modal) modal.classList.add('hidden');
  await stopQrScanner();
}

function setScanMode(mode) {
  currentScanMode = mode;
  const dispatchBtn = document.getElementById('scanModeDispatchBtn');
  const collectBtn = document.getElementById('scanModeCollectBtn');
  const modalTitle = document.getElementById('scannerModalTitle');

  if (mode === 'dispatch') {
    if (dispatchBtn) dispatchBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-emerald-600 text-white shadow-xs';
    if (collectBtn) collectBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-slate-200 text-slate-700';
    if (modalTitle) modalTitle.textContent = '1. Dispatch Tiffin (Scan 6-Digit Box)';
  } else if (mode === 'collect') {
    if (collectBtn) collectBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-blue-600 text-white shadow-xs';
    if (dispatchBtn) dispatchBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-slate-200 text-slate-700';
    if (modalTitle) modalTitle.textContent = '2. Return Tiffin (Scan 6-Digit Box)';
  } else if (mode === 'allotment') {
    if (dispatchBtn) dispatchBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-emerald-600 text-white shadow-xs';
    if (collectBtn) collectBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-slate-200 text-slate-700';
    if (modalTitle) modalTitle.textContent = `Allot Tiffin (Scan Box #${allotmentTargetBoxSlot + 1})`;
  }
  lucide.createIcons();
}

async function startQrScanner() {
  const readerElement = document.getElementById('reader');
  const loadingNotice = document.getElementById('scannerLoadingNotice');
  const loadingText = document.getElementById('scannerLoadingText');

  if (!readerElement) return;
  if (loadingNotice) loadingNotice.classList.remove('hidden');
  if (loadingText) loadingText.textContent = 'Requesting camera permissions...';

  // 1. Cleanly stop any existing scanner instance
  if (scannerInstance) {
    try {
      if (scannerInstance.isScanning) {
        await scannerInstance.stop();
      }
      await scannerInstance.clear();
    } catch (e) {
      console.warn('Error clearing previous scanner:', e);
    }
  }

  // 2. Check if browser has mediaDevices support (HTTPS or localhost)
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    if (loadingNotice) loadingNotice.classList.add('hidden');
    Swal.fire({
      icon: 'warning',
      title: 'Camera Inaccessible (HTTPS Required)',
      html: `Your browser requires a secure HTTPS connection or localhost to access the device camera.<br><br><b>Quick Alternative:</b> Enter the 6-digit Box ID manually below, or select a photo of the QR code.`,
      confirmButtonColor: '#ea580c'
    });
    return;
  }

  // 3. Create fresh scanner instance
  try {
    scannerInstance = new Html5Qrcode('reader');
  } catch (initErr) {
    console.warn('Html5Qrcode instance creation warning:', initErr);
  }

  const qrConfig = {
    fps: 15,
    qrbox: (viewfinderWidth, viewfinderHeight) => {
      const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
      const edge = Math.floor(minEdge * 0.72);
      return { width: Math.max(edge, 180), height: Math.max(edge, 180) };
    },
    aspectRatio: 1.0
  };

  // 4. Discover connected camera devices
  try {
    availableCameraList = await Html5Qrcode.getCameras();
  } catch (camErr) {
    console.warn('Html5Qrcode.getCameras warning:', camErr);
    availableCameraList = [];
  }

  // Prefer rear / environment camera
  let chosenCamera = { facingMode: 'environment' };
  if (availableCameraList && availableCameraList.length > 0) {
    const rearCam = availableCameraList.find(c => /back|rear|environment|primary/i.test(c.label));
    if (rearCam) {
      currentCameraId = rearCam.id;
      chosenCamera = rearCam.id;
    } else {
      currentCameraId = availableCameraList[availableCameraList.length - 1].id;
      chosenCamera = currentCameraId;
    }
  }

  // 5. Attempt start with cascade fallback
  async function attemptStart(camParam) {
    return scannerInstance.start(
      camParam,
      qrConfig,
      (decodedText) => {
        handleQrDecoded(decodedText);
      },
      (err) => {
        // Continuous frame analysis - silently pass frame misses
      }
    );
  }

  try {
    if (loadingText) loadingText.textContent = 'Opening camera feed...';
    await attemptStart(chosenCamera);
    if (loadingNotice) loadingNotice.classList.add('hidden');
  } catch (firstErr) {
    console.warn('First camera attempt failed, trying fallback environment facingMode...', firstErr);
    try {
      await attemptStart({ facingMode: 'environment' });
      if (loadingNotice) loadingNotice.classList.add('hidden');
    } catch (secondErr) {
      console.warn('Environment facingMode failed, trying user camera...', secondErr);
      try {
        await attemptStart({ facingMode: 'user' });
        if (loadingNotice) loadingNotice.classList.add('hidden');
      } catch (finalErr) {
        if (loadingNotice) loadingNotice.classList.add('hidden');
        console.error('All camera start attempts failed:', finalErr);
        handleCameraFailure(finalErr);
      }
    }
  }
}

function handleCameraFailure(err) {
  const errStr = String(err).toLowerCase();
  let title = 'Camera Not Opening';
  let message = 'Unable to access the camera on this device.';

  if (errStr.includes('notallowed') || errStr.includes('permission') || errStr.includes('denied')) {
    title = 'Camera Permission Denied';
    message = 'Camera permission was blocked. Please tap the lock/camera icon in your browser address bar and select <b>Allow</b> to scan container boxes directly.<br><br><b>Tip:</b> You can also type the 6-digit Box ID manually below.';
  } else if (errStr.includes('notfound') || errStr.includes('devicesnotfound') || errStr.includes('no camera')) {
    title = 'No Camera Detected';
    message = 'No functioning camera was detected on this device.<br><br>Please enter the 6-digit Box ID manually below or choose a photo of the QR code.';
  } else if (errStr.includes('in use') || errStr.includes('readable') || errStr.includes('trackstart')) {
    title = 'Camera In Use';
    message = 'Your camera is currently being used by another application or tab. Please close other camera apps and retry.';
  } else {
    message = `${err.message || 'Camera initialization error'}.<br><br>Please allow camera permissions or enter the 6-digit Box ID manually below.`;
  }

  Swal.fire({
    icon: 'error',
    title: title,
    html: message,
    confirmButtonColor: '#ea580c',
    confirmButtonText: 'Enter Manually'
  }).then(() => {
    const input = document.getElementById('manualQrInput');
    if (input) input.focus();
  });
}

async function stopQrScanner() {
  if (scannerInstance) {
    try {
      if (scannerInstance.isScanning) {
        await scannerInstance.stop();
      }
      await scannerInstance.clear();
    } catch (err) {
      console.warn('stopQrScanner warning:', err);
    }
  }
}

async function switchCameraDirection() {
  if (!availableCameraList || availableCameraList.length < 2) {
    Swal.fire({
      icon: 'info',
      title: 'Single Camera Detected',
      text: 'Only 1 camera is available on this device.',
      timer: 1500,
      showConfirmButton: false
    });
    return;
  }
  const currentIndex = availableCameraList.findIndex(c => c.id === currentCameraId);
  const nextIndex = (currentIndex + 1) % availableCameraList.length;
  currentCameraId = availableCameraList[nextIndex].id;

  if (scannerInstance && scannerInstance.isScanning) {
    await scannerInstance.stop();
  }
  startQrScanner();
}

async function handleQrFileScan(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  Swal.fire({
    title: 'Scanning QR Code Image...',
    didOpen: () => Swal.showLoading(),
    allowOutsideClick: false
  });

  try {
    const dummyEl = document.getElementById('qrFileScanDummy') || document.body;
    const tempScanner = new Html5Qrcode('qrFileScanDummy');
    const decodedText = await tempScanner.scanFile(file, true);
    Swal.close();
    handleQrDecoded(decodedText);
  } catch (err) {
    Swal.fire({
      icon: 'error',
      title: 'QR Code Not Found in Image',
      text: 'Could not detect a clear QR Code in this photo. Please ensure good lighting and clear focus.'
    });
  }
}

function validateSystemQrCode(rawCode) {
  if (!rawCode) return null;
  let code = String(rawCode).trim().toUpperCase();

  // Strip prefix or url wrappers
  if (code.includes('MAT_SYSTEM:')) {
    code = code.replace('MAT_SYSTEM:', '').trim();
  } else if (code.includes('?ID=')) {
    code = code.split('?ID=')[1].trim();
  } else if (code.includes('?id=')) {
    code = code.split('?id=')[1].trim();
  } else if (code.includes('/')) {
    code = code.split('/').pop().trim();
  }

  // Pure 6-digit match against active qrDatabase
  const matched = qrDatabase.find(q => 
    q.qrNumber.toUpperCase() === code || 
    q.qrNumber === code.padStart(6, '0')
  );

  // If deleted or foreign QR
  if (!matched) {
    playBeepSound('error');
    Swal.fire({
      icon: 'error',
      title: 'Invalid QR Code',
      text: 'Invalid QR Code. This QR Code does not belong to this system or has been deleted.',
      footer: '<span class="text-xs text-slate-500">Only active 6-digit containers starting from 081026 are recognized.</span>',
      confirmButtonColor: '#ea580c'
    }).then(() => {
      resumeScanner();
    });
    return null;
  }

  return matched;
}

function handleManualCodeSubmit() {
  const input = document.getElementById('manualQrInput');
  const code = input ? input.value.trim().toUpperCase() : '';
  if (!code) {
    Swal.fire({ icon: 'warning', title: 'Enter QR Serial', text: 'e.g. 081026' });
    return;
  }
  if (input) input.value = '';
  handleQrDecoded(code);
}

function handleQrDecoded(rawCode) {
  const qrRecord = validateSystemQrCode(rawCode);
  if (!qrRecord) {
    return;
  }

  playBeepSound('success');

  if (scannerInstance && scannerInstance.isScanning) {
    scannerInstance.pause();
  }

  // If scanning from the Allotment Modal directly
  if (currentScanMode === 'allotment') {
    if (qrRecord.status === 'Allotted') {
      Swal.fire({
        icon: 'warning',
        title: 'Container Already Out!',
        html: `Container <b>#${qrRecord.qrNumber}</b> is currently allotted to <b>${qrRecord.customerName || 'another customer'}</b>.<br>Do you want to re-allot this box?`,
        showCancelButton: true,
        confirmButtonText: 'Yes, Use Box',
        cancelButtonText: 'Cancel'
      }).then(res => {
        if (res.isConfirmed) {
          setScannedBoxInAllotment(qrRecord.qrNumber);
          closeScannerModal();
        } else {
          resumeScanner();
        }
      });
      return;
    }
    setScannedBoxInAllotment(qrRecord.qrNumber);
    closeScannerModal();
    return;
  }

  if (currentScanMode === 'dispatch') {
    handleDispatchScan(qrRecord.qrNumber);
  } else {
    handleReturnScan(qrRecord.qrNumber);
  }
}

function setScannedBoxInAllotment(boxId) {
  // Prevent duplicate container selection in multi-box allotment
  if (typeof currentAllotmentQty !== 'undefined') {
    for (let i = 0; i < currentAllotmentQty; i++) {
      if (i !== allotmentTargetBoxSlot) {
        const otherSlot = document.getElementById(`allotmentBoxId_${i}`);
        if (otherSlot && otherSlot.value === boxId) {
          Swal.fire({
            icon: 'warning',
            title: 'Already Selected',
            text: `Container #${boxId} is already assigned to Tiffin #${i + 1}. Please scan a different container.`
          });
          return;
        }
      }
    }
  }

  const slotEl = document.getElementById(`allotmentBoxId_${allotmentTargetBoxSlot}`);
  if (slotEl) {
    let exists = false;
    for (let i = 0; i < slotEl.options.length; i++) {
      if (slotEl.options[i].value === boxId) {
        exists = true;
        break;
      }
    }
    if (!exists) {
      const opt = document.createElement('option');
      opt.value = boxId;
      opt.textContent = `${boxId} (Scanned Container)`;
      slotEl.appendChild(opt);
    }
    slotEl.value = boxId;
    playBeepSound('success');
    Swal.fire({
      icon: 'success',
      title: 'Box Scanned! 🍱',
      html: `Container <b>#${boxId}</b> selected for Tiffin #${allotmentTargetBoxSlot + 1}.`,
      timer: 1600,
      showConfirmButton: false
    });
  }
}

// -------------------------------------------------------------------------
// DISPATCH SCAN: Searchable Client Selection + Lunch/Dinner + Cash Collection Option
// -------------------------------------------------------------------------
let swalSelectedClientId = null;
let swalDispatchMealCategory = 'lunch';
let swalDispatchPaymentMethod = 'cash'; // 'cash' | 'upi' | 'due'

function handleDispatchScan(boxId) {
  const qrRecord = qrDatabase.find(q => q.qrNumber === boxId);
  if (!qrRecord) {
    Swal.fire({
      icon: 'error',
      title: 'Invalid Box ID.',
      text: 'Invalid Box ID. This QR Code does not belong to this system.'
    }).then(() => resumeScanner());
    return;
  }

  if (qrRecord.status === 'Allotted') {
    const prevClient = qrRecord.customerName || (boxStates[boxId] && boxStates[boxId].clientName) || 'Registered Customer';
    Swal.fire({
      icon: 'warning',
      title: 'Container Already Out!',
      html: `Container <b>${boxId}</b> is currently allotted to <b>${prevClient}</b>.<br>Do you want to re-allot this box to another customer?`,
      showCancelButton: true,
      confirmButtonText: 'Yes, Re-allot',
      cancelButtonText: 'Cancel'
    }).then(res => {
      if (res.isConfirmed) {
        closeScannerModal();
        openAllotmentModal(boxId);
      } else {
        resumeScanner();
      }
    });
    return;
  }

  closeScannerModal();
  openAllotmentModal(boxId);
}

let swalExtraDishesSum = 0;
let swalCurrentDispatchClientMode = 'existing';

function showDispatchModalWithSearchableClients(boxId) {
  let preClient = clients.find(c => c.boxId && c.boxId.toUpperCase() === boxId.toUpperCase());
  swalSelectedClientId = preClient ? preClient.id : (clients[0] ? clients[0].id : null);
  swalDispatchMealCategory = 'lunch';
  swalDispatchPaymentMethod = 'cash';
  swalExtraDishesSum = 0;
  swalCurrentDispatchClientMode = 'existing';

  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const currentLunch = daySchedule.lunch;

  const extrasHtml = extraItemsCatalog.map(ext => `
    <label class="flex items-center justify-between p-1.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer text-[11px]">
      <div class="flex items-center space-x-2">
        <input type="checkbox" class="swal-extra-check" data-name="${ext.name}" data-price="${ext.price}" onchange="recalcDispatchTotal()">
        <span class="font-medium text-slate-800">${ext.name}</span>
      </div>
      <span class="font-bold text-emerald-700">+₹${ext.price}</span>
    </label>
  `).join('');

  Swal.fire({
    title: `Allot 6-Digit Tiffin: <span class="qr-serial-badge">${boxId}</span>`,
    html: `
      <div class="text-left text-xs space-y-3">
        
        <!-- Client Selection Tabs: Existing vs ⚡ One-Time Order vs + New Subscriber -->
        <div class="bg-slate-100 p-1 rounded-xl flex space-x-1">
          <button type="button" id="tabBtnSelectExisting" onclick="toggleDispatchClientMode('existing')" class="flex-1 py-1.5 font-bold rounded-lg text-xs bg-white text-slate-900 shadow-2xs">
            👥 Search Subscriber
          </button>
          <button type="button" id="tabBtnOneTime" onclick="toggleDispatchClientMode('onetime')" class="flex-1 py-1.5 font-bold rounded-lg text-xs text-amber-800">
            ⚡ One-Time Order
          </button>
          <button type="button" id="tabBtnAddNew" onclick="toggleDispatchClientMode('new')" class="flex-1 py-1.5 font-bold rounded-lg text-xs text-slate-600">
            ➕ New Subscriber
          </button>
        </div>

        <!-- 1. Searchable Registered Subscriber Section -->
        <div id="sectionSelectExisting" class="space-y-1.5">
          <div class="relative">
            <input type="text" id="swalClientSearchInput" oninput="filterSwalClientsList(this.value)" placeholder="🔍 Type subscriber name, phone or route..." class="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-1 focus:ring-orange-500 focus:outline-none">
          </div>
          
          <div id="swalClientsListContainer" class="space-y-1 max-h-32 overflow-y-auto border border-slate-200 p-1.5 rounded-xl bg-slate-50/70">
            <!-- Injected by filterSwalClientsList -->
          </div>
          <div class="text-[11px] text-slate-600" id="swalSelectedClientSummary">
            Selected: <b class="text-orange-700" id="swalSelectedClientNameDisplay">${preClient ? preClient.name : (clients[0] ? clients[0].name : 'None')}</b>
          </div>
        </div>

        <!-- 2. ⚡ One-Time / Occasional Customer Form -->
        <div id="sectionOneTimeClient" class="space-y-2 p-3 bg-amber-50/80 border border-amber-200 rounded-2xl hidden">
          <div class="flex items-center justify-between">
            <p class="font-bold text-amber-900 text-[11px]">⚡ One-Time Order (बिना सब्सक्रिप्शन वाला ग्राहक):</p>
            <span class="badge-soft-amber text-[9px] font-bold px-1.5 py-0.5 rounded">Trial / Occasional</span>
          </div>
          <div>
            <input type="text" id="swalOneTimeName" placeholder="Customer Name * (e.g. Vikas Singh)" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
          </div>
          <div class="grid grid-cols-2 gap-2">
            <input type="tel" id="swalOneTimePhone" placeholder="Mobile / WhatsApp *" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
            <input type="text" id="swalOneTimeArea" value="Kunwar Singh Nagar" placeholder="Area / Sector" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
          </div>
          <div>
            <textarea id="swalOneTimeAddress" rows="1" placeholder="Delivery Address / Flat / Room No. *" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white"></textarea>
          </div>
        </div>

        <!-- 3. Add Permanent Subscriber Form -->
        <div id="sectionAddNewClient" class="space-y-2 p-3 bg-orange-50/70 border border-orange-200 rounded-2xl hidden">
          <p class="font-bold text-orange-900 text-[11px]">Permanent Monthly Subscriber Registration:</p>
          <div>
            <input type="text" id="swalNewClientName" placeholder="Subscriber Full Name *" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
          </div>
          <div class="grid grid-cols-2 gap-2">
            <input type="tel" id="swalNewClientPhone" placeholder="Mobile / WhatsApp *" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
            <input type="text" id="swalNewClientArea" value="Kunwar Singh Nagar" placeholder="Route / Area" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
          </div>
          <div>
            <textarea id="swalNewClientAddress" rows="1" placeholder="Delivery Address & Landmark *" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white"></textarea>
          </div>
        </div>

        <!-- Meal Category Switcher (☀️ Lunch vs 🌙 Dinner) -->
        <div>
          <label class="block font-semibold text-slate-700 mb-1">Meal Service (Lunch vs Dinner):</label>
          <div class="grid grid-cols-2 gap-2">
            <button type="button" id="swalBtnLunch" onclick="switchSwalMealCategory('lunch')" class="py-2 text-xs font-bold rounded-xl bg-orange-600 text-white shadow-2xs flex items-center justify-center space-x-1">
              <span>☀️</span>
              <span>Lunch (दोपहर)</span>
            </button>
            <button type="button" id="swalBtnDinner" onclick="switchSwalMealCategory('dinner')" class="py-2 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center space-x-1">
              <span>🌙</span>
              <span>Dinner (रात)</span>
            </button>
          </div>
        </div>

        <!-- Dishes Included (Editable on the fly) -->
        <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200 space-y-2">
          <div class="flex items-center justify-between">
            <span class="font-bold text-slate-800 text-xs" id="swalActiveMenuTitle">${currentLunch.title}</span>
            <span class="font-mono font-bold text-emerald-700 text-xs" id="swalActiveMenuPrice">₹${currentLunch.price}</span>
          </div>
          
          <div>
            <div class="flex items-center justify-between mb-1">
              <label class="font-semibold text-slate-700 text-[11px]">Dishes in this Tiffin (Add / Edit on the fly):</label>
              <span class="text-[10px] text-orange-600 font-bold">Editable</span>
            </div>
            <textarea id="swalActiveMenuItems" rows="3" class="w-full text-xs font-mono p-2 border border-slate-300 rounded-xl bg-white focus:outline-none focus:ring-1 focus:ring-orange-500" placeholder="Dishes in this tiffin...">${currentLunch.items}</textarea>
          </div>

          <!-- Quick Dish Add Chips -->
          <div>
            <span class="block font-semibold text-slate-700 text-[10.5px] mb-1">1-Tap Quick Add Dishes / Extras:</span>
            <div class="flex flex-wrap gap-1.5">
              <button type="button" onclick="quickAddDishToActiveMenu('🫓 +2 Tawa Roti with Desi Ghee', 15)" class="dish-chip">+2 Roti (+₹15)</button>
              <button type="button" onclick="quickAddDishToActiveMenu('🍨 +Gulab Jamun (1 pc)', 20)" class="dish-chip">+Sweet (+₹20)</button>
              <button type="button" onclick="quickAddDishToActiveMenu('🥣 +Boondi Raita Bowl', 20)" class="dish-chip">+Raita (+₹20)</button>
              <button type="button" onclick="quickAddDishToActiveMenu('🥘 +Extra Shahi Paneer Portion', 35)" class="dish-chip">+Paneer (+₹35)</button>
              <button type="button" onclick="quickAddDishToActiveMenu('🍲 +Extra Daal Tadka Portion', 20)" class="dish-chip">+Daal (+₹20)</button>
              <button type="button" onclick="quickAddDishToActiveMenu('🥗 +Extra Salad & Achar', 10)" class="dish-chip">+Salad (+₹10)</button>
            </div>
          </div>

          <!-- Custom Dish Input Row -->
          <div class="pt-1 border-t border-slate-200">
            <span class="block font-semibold text-slate-700 text-[10.5px] mb-1">Add Custom Dish / Special Item:</span>
            <div class="flex space-x-1.5">
              <input type="text" id="swalCustomDishNameInput" placeholder="Dish name (e.g. Papad, Chhaachh, Jain Daal)" class="flex-1 px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg">
              <input type="number" id="swalCustomDishPriceInput" placeholder="₹ Extra" class="w-16 px-2 py-1.5 text-xs bg-white border border-slate-300 rounded-lg font-bold">
              <button type="button" onclick="addCustomDishFromInputs()" class="px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-lg shadow-2xs transition">+ Add</button>
            </div>
          </div>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Base Price (₹):</label>
          <input type="number" id="swalBasePrice" value="${currentLunch.price}" class="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold" onchange="recalcDispatchTotal()">
        </div>

        <!-- Add-ons / Extras Checklist -->
        <div>
          <div class="flex items-center justify-between mb-1">
            <label class="font-semibold text-slate-700">Add-ons / Extras Requested:</label>
            <span class="text-[10px] text-slate-400">Optional</span>
          </div>
          <div class="space-y-1 max-h-24 overflow-y-auto">
            ${extrasHtml}
          </div>
        </div>

        <!-- Payment Collection Mode (Cash vs UPI vs Due) -->
        <div class="pt-1">
          <label class="block font-bold text-slate-800 mb-1">Payment Method / Collection:</label>
          <div class="grid grid-cols-3 gap-1.5">
            <button type="button" id="swalPayModeCash" onclick="switchSwalPaymentMode('cash')" class="pay-mode-card selected text-center py-2 px-1">
              <span class="block text-sm">💵</span>
              <span class="block font-bold text-[10.5px] text-emerald-800">Cash Received</span>
            </button>
            <button type="button" id="swalPayModeUpi" onclick="switchSwalPaymentMode('upi')" class="pay-mode-card text-center py-2 px-1">
              <span class="block text-sm">📱</span>
              <span class="block font-bold text-[10.5px] text-slate-700">UPI / QR Pay</span>
            </button>
            <button type="button" id="swalPayModeDue" onclick="switchSwalPaymentMode('due')" class="pay-mode-card text-center py-2 px-1">
              <span class="block text-sm">⏳</span>
              <span class="block font-bold text-[10.5px] text-slate-700">Pay Later / Due</span>
            </button>
          </div>
        </div>

        <!-- Total Display -->
        <div class="bg-slate-100 p-2.5 rounded-xl flex items-center justify-between border border-slate-200">
          <span class="font-bold text-slate-800 text-xs">Total Billable Amount:</span>
          <span class="text-sm font-extrabold text-emerald-700" id="swalTotalDisplay">₹${currentLunch.price}</span>
        </div>

      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#059669',
    confirmButtonText: 'Confirm & Dispatch',
    cancelButtonText: 'Cancel',
    didOpen: () => {
      filterSwalClientsList('');
    }
  }).then(res => {
    if (res.isConfirmed) {
      processDispatchSubmission(boxId);
    } else {
      resumeScanner();
    }
  });

  if (clients.length === 0) {
    toggleDispatchClientMode('new');
  }
}

// Window helpers for SweetAlert modal
window.toggleDispatchClientMode = function(mode) {
  swalCurrentDispatchClientMode = mode;
  const tabExisting = document.getElementById('tabBtnSelectExisting');
  const tabOneTime = document.getElementById('tabBtnOneTime');
  const tabNew = document.getElementById('tabBtnAddNew');
  const secExisting = document.getElementById('sectionSelectExisting');
  const secOneTime = document.getElementById('sectionOneTimeClient');
  const secNew = document.getElementById('sectionAddNewClient');

  [tabExisting, tabOneTime, tabNew].forEach(t => {
    if (t) t.className = 'flex-1 py-1.5 font-bold rounded-lg text-xs text-slate-600';
  });
  [secExisting, secOneTime, secNew].forEach(s => {
    if (s) s.classList.add('hidden');
  });

  if (mode === 'existing') {
    tabExisting.className = 'flex-1 py-1.5 font-bold rounded-lg text-xs bg-white text-slate-900 shadow-2xs';
    secExisting.classList.remove('hidden');
  } else if (mode === 'onetime') {
    tabOneTime.className = 'flex-1 py-1.5 font-bold rounded-lg text-xs bg-white text-amber-900 shadow-2xs';
    secOneTime.classList.remove('hidden');
  } else {
    tabNew.className = 'flex-1 py-1.5 font-bold rounded-lg text-xs bg-white text-slate-900 shadow-2xs';
    secNew.classList.remove('hidden');
  }
};

window.quickAddDishToActiveMenu = function(dishName, price) {
  const textarea = document.getElementById('swalActiveMenuItems');
  if (textarea) {
    textarea.value = textarea.value.trim() + '\n• ' + dishName;
  }
  swalExtraDishesSum += Number(price || 0);
  window.recalcDispatchTotal();
};

window.addCustomDishFromInputs = function() {
  const nameInput = document.getElementById('swalCustomDishNameInput');
  const priceInput = document.getElementById('swalCustomDishPriceInput');
  const name = nameInput?.value.trim();
  const price = Number(priceInput?.value) || 0;

  if (!name) {
    return;
  }

  const textarea = document.getElementById('swalActiveMenuItems');
  if (textarea) {
    textarea.value = textarea.value.trim() + `\n• ${name}` + (price > 0 ? ` (+₹${price})` : '');
  }
  swalExtraDishesSum += price;
  nameInput.value = '';
  priceInput.value = '';
  window.recalcDispatchTotal();
};

window.filterSwalClientsList = function(searchTerm) {
  const container = document.getElementById('swalClientsListContainer');
  if (!container) return;

  const q = searchTerm.toLowerCase().trim();
  let matches = clients;
  if (q) {
    matches = clients.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.phone.includes(q) || 
      (c.area && c.area.toLowerCase().includes(q))
    );
  }

  if (matches.length === 0) {
    container.innerHTML = `<div class="p-2 text-center text-[11px] text-slate-400">No matching clients found. Use "+ Add New Client" above.</div>`;
    return;
  }

  container.innerHTML = matches.map(c => `
    <div onclick="selectSwalClient('${c.id}', '${c.name.replace(/'/g, "\\'")}')" class="client-search-item ${c.id === swalSelectedClientId ? 'selected' : ''}">
      <div class="flex items-center justify-between">
        <span class="font-bold text-slate-900 text-xs">${c.name}</span>
        <span class="text-[10.5px] text-slate-500 font-mono">${c.phone}</span>
      </div>
      <div class="text-[10px] text-slate-500 truncate">${c.address || ''} &bull; ${c.area || 'Direct'}</div>
    </div>
  `).join('');
};

window.selectSwalClient = function(clientId, clientName) {
  swalSelectedClientId = clientId;
  const nameDisplay = document.getElementById('swalSelectedClientNameDisplay');
  if (nameDisplay) nameDisplay.textContent = clientName;

  document.querySelectorAll('#swalClientsListContainer .client-search-item').forEach(el => el.classList.remove('selected'));
  const currentSearch = document.getElementById('swalClientSearchInput')?.value || '';
  filterSwalClientsList(currentSearch);
};

window.switchSwalMealCategory = function(category) {
  swalDispatchMealCategory = category;
  const btnL = document.getElementById('swalBtnLunch');
  const btnD = document.getElementById('swalBtnDinner');

  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const selectedMeal = category === 'lunch' ? daySchedule.lunch : daySchedule.dinner;

  if (category === 'lunch') {
    btnL.className = 'py-2 text-xs font-bold rounded-xl bg-orange-600 text-white shadow-2xs flex items-center justify-center space-x-1';
    btnD.className = 'py-2 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center space-x-1';
  } else {
    btnD.className = 'py-2 text-xs font-bold rounded-xl bg-blue-600 text-white shadow-2xs flex items-center justify-center space-x-1';
    btnL.className = 'py-2 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center space-x-1';
  }

  document.getElementById('swalActiveMenuTitle').textContent = selectedMeal.title;
  document.getElementById('swalActiveMenuPrice').textContent = `₹${selectedMeal.price}`;
  document.getElementById('swalActiveMenuItems').value = selectedMeal.items;
  document.getElementById('swalBasePrice').value = selectedMeal.price;
  swalExtraDishesSum = 0;

  window.recalcDispatchTotal();
};

window.switchSwalPaymentMode = function(mode) {
  swalDispatchPaymentMethod = mode;
  const btnCash = document.getElementById('swalPayModeCash');
  const btnUpi = document.getElementById('swalPayModeUpi');
  const btnDue = document.getElementById('swalPayModeDue');

  [btnCash, btnUpi, btnDue].forEach(b => b.classList.remove('selected'));
  if (mode === 'cash') btnCash.classList.add('selected');
  else if (mode === 'upi') btnUpi.classList.add('selected');
  else if (mode === 'due') btnDue.classList.add('selected');
};

window.recalcDispatchTotal = function() {
  const basePrice = Number(document.getElementById('swalBasePrice')?.value) || 0;
  const checkedBoxes = Array.from(document.querySelectorAll('.swal-extra-check:checked'));
  const extrasTotal = checkedBoxes.reduce((sum, cb) => sum + Number(cb.getAttribute('data-price') || 0), 0);
  const total = basePrice + extrasTotal + swalExtraDishesSum;
  const display = document.getElementById('swalTotalDisplay');
  if (display) display.textContent = `₹${total}`;
};

// Process final dispatch
function processDispatchSubmission(boxId) {
  let targetClient = null;

  if (swalCurrentDispatchClientMode === 'onetime') {
    const oneName = document.getElementById('swalOneTimeName')?.value.trim();
    const onePhone = document.getElementById('swalOneTimePhone')?.value.trim();
    const oneAddress = document.getElementById('swalOneTimeAddress')?.value.trim();
    const oneArea = document.getElementById('swalOneTimeArea')?.value.trim() || 'Kunwar Singh Nagar';

    if (!oneName || !onePhone) {
      Swal.fire({ icon: 'warning', title: 'Missing Info', text: 'Customer Name and Mobile Number are required for One-Time Order.' });
      resumeScanner();
      return;
    }

    let existingClient = clients.find(c => c.phone === onePhone);
    if (existingClient) {
      targetClient = existingClient;
      targetClient.name = oneName;
      targetClient.address = oneAddress || targetClient.address;
      targetClient.area = oneArea;
    } else {
      targetClient = {
        id: 'c-' + Date.now(),
        name: oneName,
        phone: onePhone,
        address: oneAddress || 'Kunwar Singh Nagar',
        area: oneArea,
        boxId: boxId,
        mealType: swalDispatchMealCategory === 'lunch' ? 'Lunch' : 'Dinner',
        price: 0,
        paymentStatus: swalDispatchPaymentMethod === 'cash' ? 'paid' : 'pending',
        dueAmount: 0,
        startDate: currentDate,
        status: 'active',
        clientType: 'onetime'
      };
      clients.push(targetClient);
    }
  } else if (swalCurrentDispatchClientMode === 'new') {
    const newName = document.getElementById('swalNewClientName')?.value.trim();
    const newPhone = document.getElementById('swalNewClientPhone')?.value.trim();
    const newAddress = document.getElementById('swalNewClientAddress')?.value.trim();
    const newArea = document.getElementById('swalNewClientArea')?.value.trim();

    if (!newName || !newPhone) {
      Swal.fire({ icon: 'warning', title: 'Missing Client Info', text: 'Name and Phone Number are required.' });
      resumeScanner();
      return;
    }

    targetClient = {
      id: 'c-' + Date.now(),
      name: newName,
      phone: newPhone,
      address: newAddress || 'Kunwar Singh Nagar',
      area: newArea || 'Kunwar Singh Nagar',
      boxId: boxId,
      mealType: swalDispatchMealCategory === 'lunch' ? 'Lunch' : 'Dinner',
      price: settings.defaultPrice,
      paymentStatus: swalDispatchPaymentMethod === 'cash' ? 'paid' : 'pending',
      dueAmount: swalDispatchPaymentMethod === 'cash' ? 0 : settings.defaultPrice,
      startDate: currentDate,
      status: 'active',
      clientType: 'subscriber'
    };

    clients.push(targetClient);
  } else {
    targetClient = clients.find(c => c.id === swalSelectedClientId);

    if (!targetClient) {
      Swal.fire({ icon: 'warning', title: 'No Client Selected', text: 'Please search and select a client.' });
      resumeScanner();
      return;
    }
  }

  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const mealObj = swalDispatchMealCategory === 'lunch' ? daySchedule.lunch : daySchedule.dinner;
  const menuTitle = mealObj.title;
  const menuItems = document.getElementById('swalActiveMenuItems')?.value.trim() || mealObj.items;

  const basePrice = Number(document.getElementById('swalBasePrice')?.value) || mealObj.price;
  const checkedBoxes = Array.from(document.querySelectorAll('.swal-extra-check:checked'));
  const extrasArray = checkedBoxes.map(cb => cb.getAttribute('data-name'));
  const extrasTotal = checkedBoxes.reduce((sum, cb) => sum + Number(cb.getAttribute('data-price') || 0), 0);
  const totalAmount = basePrice + extrasTotal + swalExtraDishesSum;
  const extrasSummary = extrasArray.length > 0 ? extrasArray.join(', ') : (swalExtraDishesSum > 0 ? 'Custom Dishes Added' : 'None');

  if (targetClient.clientType === 'onetime') {
    targetClient.price = totalAmount;
    targetClient.paymentStatus = swalDispatchPaymentMethod === 'cash' ? 'paid' : 'pending';
    targetClient.dueAmount = swalDispatchPaymentMethod === 'cash' ? 0 : totalAmount;
  } else if (swalDispatchPaymentMethod === 'cash') {
    targetClient.paymentStatus = 'paid';
    targetClient.dueAmount = Math.max(0, (targetClient.dueAmount || 0) - totalAmount);
  }

  saveData();
  renderClientList();

  completeDispatch(boxId, targetClient, swalDispatchMealCategory, menuTitle, menuItems, extrasSummary, totalAmount, swalDispatchPaymentMethod);
}

function completeDispatch(boxId, client, mealCategory, menuTitle, menuItems, extras, price, paymentMode) {
  const now = new Date();
  const timestamp = now.toISOString();
  const todayStr = timestamp.split('T')[0];

  // Update qrDatabase record
  let qrRecord = qrDatabase.find(q => q.qrNumber === boxId);
  if (qrRecord) {
    qrRecord.status = 'Allotted';
    qrRecord.customerId = client.id;
    qrRecord.customerName = client.name;
    qrRecord.customerPhone = client.phone;
    qrRecord.customerAddress = client.address;
    qrRecord.allotmentDate = timestamp;
    qrRecord.returnDate = null;
    qrRecord.lastUpdated = timestamp;
    if (!qrRecord.allotmentHistory) qrRecord.allotmentHistory = [];
    qrRecord.allotmentHistory.push({
      customerId: client.id,
      customerName: client.name,
      customerPhone: client.phone,
      allotmentDate: timestamp,
      deliveryPartner: qrRecord.deliveryPartner || 'Kitchen Partner',
      mealCategory: capitalize(mealCategory),
      menuTitle,
      price,
      paymentMode
    });
  }

  boxStates[boxId] = {
    status: 'with_client',
    clientId: client.id,
    clientName: client.name,
    clientPhone: client.phone,
    clientAddress: client.address,
    dispatchedAt: timestamp,
    mealCategory: capitalize(mealCategory),
    menuTitle,
    menuItems,
    extras,
    price,
    paymentMode
  };

  logs.push({
    id: 'log-' + Date.now(),
    timestamp,
    date: todayStr,
    boxId,
    clientId: client.id,
    clientName: client.name,
    mealCategory: capitalize(mealCategory),
    menuTitle,
    menuItems,
    extras,
    price,
    paymentMode,
    type: 'dispatch'
  });

  saveData();
  renderDashboard();
  renderReturnScreen();
  renderQrDatabaseList();
  renderPaymentsList();

  const isCash = paymentMode === 'cash';

  Swal.fire({
    icon: 'success',
    title: 'Tiffin Allotted Successfully! ✅',
    html: `QR <b>${boxId}</b> assigned to <b>${client.name}</b> (${capitalize(mealCategory)}).<br><b>Status:</b> <span class="badge-soft-emerald px-1.5 py-0.5 rounded text-xs font-bold">Allotted</span><br><b>Total Amount:</b> ₹${price} ${isCash ? '<span class="badge-soft-emerald px-1.5 py-0.5 rounded text-xs font-bold ml-1">💵 Cash Received</span>' : ''}`,
    showCancelButton: true,
    confirmButtonColor: '#10b981',
    confirmButtonText: 'Send WhatsApp Slip',
    cancelButtonText: 'Done'
  }).then((res) => {
    if (res.isConfirmed) {
      sendProfessionalDeliverySlip(client.phone, client.name, boxId, capitalize(mealCategory), menuTitle, menuItems, extras, price, paymentMode);
    }
    resumeScanner();
  });
}

// -------------------------------------------------------------------------
// RETURN SCAN (With Cash Collection Option)
// -------------------------------------------------------------------------
function handleReturnScan(boxId) {
  let qrRecord = qrDatabase.find(q => q.qrNumber === boxId);
  if (!qrRecord) {
    playBeepSound('error');
    Swal.fire({
      icon: 'error',
      title: 'Invalid QR Code',
      text: 'Invalid QR Code. This QR Code does not belong to this system.'
    }).then(() => resumeScanner());
    return;
  }

  const isBoxAllotted = qrRecord.status === 'Allotted' || (boxStates[boxId] && boxStates[boxId].status === 'with_client');

  if (!isBoxAllotted) {
    Swal.fire({
      icon: 'info',
      title: `Container ${boxId}`,
      html: `This container is already marked as <b>${qrRecord.status}</b> in kitchen.<br>Mark as returned again?`,
      showCancelButton: true,
      confirmButtonText: 'Yes, Return Box',
      cancelButtonText: 'Cancel'
    }).then(res => {
      if (res.isConfirmed) {
        completeCollect(boxId, qrRecord.customerName || 'Direct Customer', qrRecord.customerId, false);
      } else {
        resumeScanner();
      }
    });
    return;
  }

  const clientName = qrRecord.customerName || (boxStates[boxId] && boxStates[boxId].clientName) || 'Customer';
  const clientId = qrRecord.customerId || (boxStates[boxId] && boxStates[boxId].clientId);
  const client = clients.find(c => c.id === clientId);
  const isDue = client && client.paymentStatus === 'pending';
  const dueAmt = client ? client.dueAmount : 0;
  const dispatchedAt = qrRecord.allotmentDate || (boxStates[boxId] && boxStates[boxId].dispatchedAt);

  Swal.fire({
    title: `Return Tiffin: <span class="qr-serial-badge">${boxId}</span>`,
    html: `
      <div class="text-left text-xs space-y-2.5">
        <div class="bg-blue-50 p-3 rounded-2xl border border-blue-200">
          <p class="font-bold text-slate-900 text-sm">${clientName}</p>
          <p class="text-[11px] text-slate-500">${qrRecord.customerPhone || ''} &bull; ${qrRecord.customerAddress || ''}</p>
          <p class="text-[11px] text-blue-700 mt-1">Dispatched: ${getTimeAgoText(dispatchedAt)}</p>
        </div>

        ${isDue ? `
          <div class="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-amber-900">Pending Amount:</span>
              <span class="text-sm font-extrabold text-red-600">₹${dueAmt}</span>
            </div>
            <label class="flex items-center space-x-2 text-xs font-bold text-slate-800 cursor-pointer bg-white p-2 rounded-lg border border-amber-200">
              <input type="checkbox" id="swalCollectCashReturn" checked class="w-4 h-4 text-emerald-600">
              <span>💵 Collect Cash Now (₹${dueAmt})</span>
            </label>
          </div>
        ` : `
          <div class="p-2 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 font-semibold text-[11px] text-center">
            ✓ Subscription Payment Cleared (Paid)
          </div>
        `}
      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#2563eb',
    confirmButtonText: 'Confirm Box Returned',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      const collectedCash = document.getElementById('swalCollectCashReturn')?.checked;
      if (collectedCash && client) {
        client.paymentStatus = 'paid';
        client.dueAmount = 0;
      }
      completeCollect(boxId, clientName, clientId, collectedCash);
    } else {
      resumeScanner();
    }
  });
}

function completeCollect(boxId, clientName, clientId, collectedCash = false) {
  const now = new Date();
  const timestamp = now.toISOString();
  const todayStr = timestamp.split('T')[0];

  let qrRecord = qrDatabase.find(q => q.qrNumber === boxId);
  if (qrRecord) {
    if (!qrRecord.returnHistory) qrRecord.returnHistory = [];
    qrRecord.returnHistory.push({
      customerId: clientId || qrRecord.customerId,
      customerName: clientName || qrRecord.customerName,
      returnDate: timestamp,
      collectedCash: !!collectedCash
    });

    // Mark as Returned, clear customer assignment, make Available again for future allotment
    qrRecord.status = 'Available';
    qrRecord.returnDate = timestamp;
    qrRecord.customerId = null;
    qrRecord.customerName = null;
    qrRecord.customerPhone = null;
    qrRecord.customerAddress = null;
    qrRecord.lastUpdated = timestamp;
  }

  boxStates[boxId] = {
    status: 'available',
    clientId: null,
    clientName: null,
    clientPhone: null,
    clientAddress: null,
    collectedAt: timestamp
  };

  logs.push({
    id: 'log-' + Date.now(),
    timestamp,
    date: todayStr,
    boxId,
    clientId,
    clientName,
    paymentMode: collectedCash ? 'cash' : 'none',
    type: 'collect'
  });

  saveData();
  renderDashboard();
  renderReturnScreen();
  renderQrDatabaseList();
  renderPaymentsList();

  Swal.fire({
    icon: 'success',
    title: 'Container Returned to Kitchen! 🍱',
    html: `QR <b>${boxId}</b> received back from <b>${clientName}</b>.<br>Container is now <b class="text-emerald-700">Available</b> for future allotment.${collectedCash ? '<br><b class="text-emerald-700">💵 Cash Payment Cleared!</b>' : ''}`,
    timer: 2000,
    showConfirmButton: false
  }).then(() => {
    resumeScanner();
  });
}

function markBoxReturned(boxId) {
  handleReturnScan(boxId);
}

function resumeScanner() {
  if (scannerInstance && scannerInstance.isScanning) {
    try {
      scannerInstance.resume();
    } catch (e) {}
  }
}

// -------------------------------------------------------------------------
// UNIVERSAL WHATSAPP DISPATCHER (Fixes "Web page not available" / ERR_UNKNOWN_URL_SCHEME)
// -------------------------------------------------------------------------
function openWhatsAppDirect({ phone, text, customerName = 'Customer', title = 'WhatsApp Slip' }) {
  let cleanPhone = phone ? String(phone).replace(/[^0-9]/g, '') : '';
  if (cleanPhone.length === 10) cleanPhone = '91' + cleanPhone;
  else if (cleanPhone.startsWith('0') && cleanPhone.length === 11) cleanPhone = '91' + cleanPhone.substring(1);

  const encodedText = encodeURIComponent(text || '');

  // 1. Standard HTTPS API link (Never crashes Android WebViews with net::ERR_UNKNOWN_URL_SCHEME)
  const apiWebUrl = cleanPhone 
    ? `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`
    : `https://api.whatsapp.com/send?text=${encodedText}`;

  // 2. Direct mobile app scheme (for devices where WhatsApp app is registered)
  const appSchemeUrl = cleanPhone
    ? `whatsapp://send?phone=${cleanPhone}&text=${encodedText}`
    : `whatsapp://send?text=${encodedText}`;

  // Show comprehensive dispatch popup with 1-click fallback & message copy
  Swal.fire({
    title: `Send WhatsApp Slip 💬`,
    html: `
      <div class="text-left text-xs space-y-3">
        <div class="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between">
          <div>
            <span class="text-slate-500 font-semibold block text-[10px]">RECIPIENT:</span>
            <span class="font-bold text-slate-800 text-xs">${customerName ? customerName + ' &bull; ' : ''}${cleanPhone ? '+' + cleanPhone : 'Direct WhatsApp'}</span>
          </div>
          <span class="badge-soft-emerald px-2 py-0.5 rounded-full text-[10px] font-bold">Ready to Send</span>
        </div>

        <div>
          <label class="block font-bold text-slate-700 mb-1">Message Preview:</label>
          <textarea id="swalWhatsAppPreview" readonly class="w-full h-32 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-sans leading-relaxed resize-none focus:outline-none select-all">${text}</textarea>
        </div>

        <div class="grid grid-cols-2 gap-2 pt-1">
          <!-- Primary: Safe HTTPS WhatsApp Web/App Trigger -->
          <a id="btnLaunchWhatsAppSafe" href="${apiWebUrl}" target="_blank" rel="noopener noreferrer" class="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 shadow-xs transition no-underline">
            <span>🚀 Open WhatsApp</span>
          </a>
          <!-- Copy Message fallback -->
          <button type="button" onclick="copyWhatsAppSlipToClipboard()" class="py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 border border-slate-200 transition">
            <span>📋 Copy Message</span>
          </button>
        </div>

        <div class="text-center pt-1">
          <a href="${appSchemeUrl}" class="text-[11px] text-emerald-700 underline font-semibold hover:text-emerald-900">
            📱 Tap here if WhatsApp App doesn't open automatically
          </a>
        </div>
      </div>
    `,
    showConfirmButton: false,
    showCancelButton: true,
    cancelButtonText: 'Done / Close'
  });

  window.copyWhatsAppSlipToClipboard = function() {
    const previewEl = document.getElementById('swalWhatsAppPreview');
    const msgToCopy = previewEl ? previewEl.value : text;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(msgToCopy).then(() => {
        Swal.fire({ icon: 'success', title: 'Copied to Clipboard! 📋', text: 'Ab WhatsApp par jakar paste kar dijiye.', timer: 1500, showConfirmButton: false });
      }).catch(() => fallbackCopyMsg(msgToCopy));
    } else {
      fallbackCopyMsg(msgToCopy);
    }
  };

  function fallbackCopyMsg(str) {
    const tempInput = document.createElement('textarea');
    tempInput.value = str;
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand('copy');
    document.body.removeChild(tempInput);
    Swal.fire({ icon: 'success', title: 'Copied! 📋', timer: 1300, showConfirmButton: false });
  }
}

// -------------------------------------------------------------------------
// WHATSAPP DELIVERY SLIP WITH LIVE UPI PAYMENT LINK & QR CODE LINK
// -------------------------------------------------------------------------
function sendProfessionalDeliverySlip(phone, clientName, boxId, mealCategory, menuTitle, menuItems, extras, price, paymentMode) {
  if (!phone) return;

  const isCash = paymentMode === 'cash';
  const upiId = settings.upiId || '9311155593@paytm';

  // Live scannable QR Code image URL generated via public API
  const upiRawString = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=Maa%20Annapurna%20Tiffin&am=${price}&cu=INR`;
  const upiQrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(upiRawString)}`;

  let paymentText = '';
  if (isCash) {
    paymentText = `💳 *Payment Status*: ✅ PAID VIA CASH (₹${price}/- Received by Delivery Partner)`;
  } else {
    paymentText = `💳 *QUICK PAYMENT OPTIONS*:
• Bill Amount: ₹${price}/-
• Status: ${paymentMode === 'upi' ? '✅ Paid Online via UPI' : '⏳ Payment Due / Pay Later'}
• UPI ID: ${upiId} (GPay / PhonePe / Paytm / BHIM)
• Direct UPI Pay Link:
  ${upiRawString}
• Scan Payment QR Code Online:
  ${upiQrImageUrl}`;
  }

  const msg = `Dear ${clientName},

Greetings from *${settings.bizName}* (Kunwar Singh Nagar)! 🙏

Your ${mealCategory} meal has been safely delivered:
🍱 *Tiffin Container*: ${boxId}
🍛 *Service*: ${mealCategory} (${menuTitle})
📋 *Dishes Included*:
${menuItems}
➕ *Add-ons / Extras*: ${extras}
💰 *Total Amount*: ₹${price}/-

${paymentText}

We hope you relish your meal! Kindly keep the container ready for collection later today.

Warm regards,
*${settings.bizName}*
📍 Kunwar Singh Nagar • 📞 ${settings.bizPhone}`;

  openWhatsAppDirect({ phone, text: msg, customerName: clientName, title: 'Delivery Slip' });
}

// -------------------------------------------------------------------------
// DYNAMIC LIVE UPI PAYMENT QR CODE MODAL
// -------------------------------------------------------------------------
function openUpiQrModal(amount = null) {
  const modal = document.getElementById('upiPaymentQrModal');
  const holder = document.getElementById('dynamicUpiQrCodeHolder');
  const amountDisp = document.getElementById('upiModalAmountDisplay');
  const vpaDisp = document.getElementById('upiModalVpaDisplay');

  holder.innerHTML = '';
  vpaDisp.textContent = settings.upiId || '9311155593@paytm';

  let upiString = `upi://pay?pa=${settings.upiId || '9311155593@paytm'}&pn=Maa%20Annapurna%20Tiffin%20Service&cu=INR`;
  if (amount) {
    upiString += `&am=${amount}`;
    amountDisp.textContent = `Amount: ₹${amount}/-`;
  } else {
    amountDisp.textContent = `Amount: Custom / Subscription`;
  }

  if (settings.customQrImage) {
    holder.innerHTML = `
      <div class="flex flex-col items-center">
        <img src="${settings.customQrImage}" alt="Payment Standee QR" class="w-48 h-48 object-contain rounded-xl shadow-2xs border border-slate-200">
        <span class="text-[10px] text-emerald-700 font-bold mt-1">Official Merchant QR Standee</span>
      </div>
    `;
  } else {
    try {
      upiQrCodeInstance = new QRCode(holder, {
        text: upiString,
        width: 180,
        height: 180,
        colorDark: '#0f172a',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
      });
    } catch (e) {
      console.error(e);
    }
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeUpiQrModal() {
  document.getElementById('upiPaymentQrModal').classList.add('hidden');
}

function shareUpiLinkWhatsApp() {
  const upiId = settings.upiId || '9311155593@paytm';
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi%3A%2F%2Fpay%3Fpa%3D${encodeURIComponent(upiId)}%26pn%3DMaa%20Annapurna%20Tiffin%26cu%3DINR`;
  
  const text = `🍱 *Maa Annapurna Tiffin Service - Online Payment QR* 🍱
📍 Kunwar Singh Nagar | 📞 ${settings.bizPhone}

Scan this UPI QR Code or pay via:
• UPI ID: ${upiId}
• GPay / PhonePe / Paytm: ${settings.bizPhone}
• Payment QR Code Link: ${qrUrl}

Thank you for choosing pure homemade food! 🙏`;

  const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

// ==========================================
// EMAIL DATA SYNC SYSTEM
// ==========================================
function triggerEmailDataSync() {
  const email = settings.bizEmail || 'annapurna.tiffin@gmail.com';
  const phone = settings.bizPhone || '+91 9311155593';
  const dayLogs = logs.filter(l => l.date === currentDate);
  const dispatchedToday = dayLogs.filter(l => l.type === 'dispatch').length;
  const collectedToday = qrDatabase.filter(q => q.returnDate && q.returnDate.startsWith(currentDate)).length;
  const cashToday = dayLogs.reduce((sum, l) => sum + (l.paymentMode === 'cash' ? (Number(l.price) || 0) : 0), 0);
  const pendingBoxes = qrDatabase.filter(q => q.status === 'Allotted');
  const inKitchen = qrDatabase.filter(q => q.status === 'Available').length;
  const totalDues = clients.reduce((sum, c) => sum + (c.paymentStatus === 'pending' ? (Number(c.dueAmount) || 0) : 0), 0);

  const pendingListSummary = pendingBoxes.map(q => `${q.qrNumber}: ${q.customerName || 'Customer'} (${q.customerPhone || 'Direct'})`).join('; ') || 'None';

  const subject = encodeURIComponent(`${settings.bizName} - Daily Ledger Report (${currentDate})`);
  const bodyText = encodeURIComponent(`MAA ANNAPURNA TIFFIN SERVICE
Address: Kunwar Singh Nagar | Phone: ${phone}
Date: ${currentDate}

=============================
DAILY OPERATIONS & QR INVENTORY:
=============================
• Total System 6-Digit QRs: ${qrDatabase.length} (Starts 081026)
• Containers Currently Out: ${pendingBoxes.length}
• Clean Containers in Kitchen: ${inKitchen}
• Tiffins Returned Today: ${collectedToday}
• Total Active Registered Clients: ${clients.length}
• Cash Collected Today: ₹${cashToday}
• Pending Containers List: ${pendingListSummary}

=============================
FINANCIAL LEDGER:
=============================
• Total Outstanding Dues: ₹${totalDues}

(This automated report is synced from your TiffinTrack Pro system.)`);

  exportDataJSON();

  const mailtoUrl = `mailto:${email}?subject=${subject}&body=${bodyText}`;
  window.location.href = mailtoUrl;

  Swal.fire({
    icon: 'success',
    title: 'Backup & Email Report Prepared! ✉️',
    html: `Database backup downloaded and email report prepared for <b>${email}</b>.<br>Your data is safe and synchronized!`,
    confirmButtonColor: '#ea580c'
  });
}

// ==========================================
// PAYMENTS & SUBSCRIPTION LEDGER
// ==========================================
function renderPaymentsList() {
  const container = document.getElementById('paymentsListContainer');
  if (!container) return;

  const totalCollected = clients.reduce((sum, c) => sum + (c.paymentStatus === 'paid' ? (Number(c.price) || 0) : 0), 0);
  const totalDues = clients.reduce((sum, c) => sum + (c.paymentStatus === 'pending' ? (Number(c.dueAmount) || 0) : 0), 0);

  document.getElementById('payStatCollected').textContent = `₹${totalCollected.toLocaleString('en-IN')}`;
  document.getElementById('payStatDues').textContent = `₹${totalDues.toLocaleString('en-IN')}`;

  let filtered = clients;
  if (paymentFilter === 'due') {
    filtered = clients.filter(c => c.paymentStatus === 'pending');
  } else if (paymentFilter === 'paid') {
    filtered = clients.filter(c => c.paymentStatus === 'paid');
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="aesthetic-card p-8 text-center text-xs text-slate-400">
        No records match the selected payment filter.
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(c => {
    const isPaid = c.paymentStatus === 'paid';
    return `
      <div class="aesthetic-card p-3.5 space-y-2.5">
        <div class="flex items-start justify-between">
          <div>
            <h4 class="text-xs font-bold text-slate-900">${c.name}</h4>
            <p class="text-[11px] text-slate-500">${c.phone} &bull; ${c.area || 'Kunwar Singh Nagar'}</p>
          </div>
          <div class="text-right">
            ${isPaid 
              ? `<span class="badge-soft-emerald px-2 py-0.5 rounded-full text-[10px] font-bold">PAID</span>`
              : `<span class="badge-soft-red px-2 py-0.5 rounded-full text-[10px] font-bold">DUE: ₹${c.dueAmount}</span>`
            }
          </div>
        </div>

        <div class="flex items-center justify-between text-[11px] text-slate-600 border-t border-slate-100 pt-2">
          <span>Monthly Plan: <b>₹${c.price}</b></span>

          <div class="flex items-center space-x-2">
            ${!isPaid ? `
              <button onclick="sendProfessionalPaymentReminder('${c.phone}', '${c.name}', '${c.dueAmount}')" class="badge-soft-emerald hover:bg-emerald-100 text-[11px] font-bold px-2 py-1 rounded-lg flex items-center">
                <i data-lucide="message-circle" class="w-3 h-3 mr-1"></i>
                Reminder
              </button>
            ` : ''}
            
            <button onclick="openCollectPaymentModal('${c.id}')" class="bg-slate-900 hover:bg-black text-white text-[11px] font-bold px-2.5 py-1 rounded-lg shadow-2xs">
              ${isPaid ? 'Update' : 'Record Payment'}
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  lucide.createIcons();
}

function filterPaymentList(type) {
  paymentFilter = type;
  document.getElementById('payFilterAll').className = type === 'all' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-900 text-white' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-slate-700';
  document.getElementById('payFilterDue').className = type === 'due' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-red-600 text-white' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-red-600';
  document.getElementById('payFilterPaid').className = type === 'paid' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-emerald-600 text-white' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-emerald-600';
  renderPaymentsList();
}

function openCollectPaymentModal(clientId) {
  const client = clients.find(c => c.id === clientId);
  if (!client) return;

  Swal.fire({
    title: `Record Payment: ${client.name}`,
    html: `
      <div class="text-left text-xs space-y-3">
        <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
          <p class="text-slate-600">Current Due: <b class="text-red-600">₹${client.dueAmount || client.price}</b></p>
          <p class="text-slate-600">Subscription Plan: <b>₹${client.price}/month</b></p>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Payment Status:</label>
          <select id="swalPayStatus" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
            <option value="paid">Full Payment Received (Cleared)</option>
            <option value="partial">Partial Payment Received</option>
            <option value="pending">Unpaid (Payment Due)</option>
          </select>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Remaining Due Amount (₹):</label>
          <input type="number" id="swalPayRemaining" value="0" class="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold">
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Payment Method:</label>
          <select id="swalPayMethod" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
            <option value="cash">💵 Cash Received</option>
            <option value="upi">📱 UPI / PhonePe / GPay (${settings.upiId})</option>
            <option value="bank">🏦 Bank Transfer</option>
          </select>
        </div>
      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#059669',
    confirmButtonText: 'Save Payment',
    cancelButtonText: 'Cancel',
    didOpen: () => {
      const select = document.getElementById('swalPayStatus');
      select.addEventListener('change', (e) => {
        const remainingInput = document.getElementById('swalPayRemaining');
        if (e.target.value === 'paid') remainingInput.value = '0';
        else if (e.target.value === 'pending') remainingInput.value = client.price;
      });
    }
  }).then(res => {
    if (res.isConfirmed) {
      const status = document.getElementById('swalPayStatus').value;
      const remaining = Number(document.getElementById('swalPayRemaining').value) || 0;
      const method = document.getElementById('swalPayMethod').value;

      client.paymentStatus = (status === 'paid' && remaining === 0) ? 'paid' : 'pending';
      client.dueAmount = remaining;

      saveData();
      renderPaymentsList();
      renderClientList();
      renderDashboard();

      Swal.fire({ icon: 'success', title: `Payment Saved (${method.toUpperCase()})`, timer: 1400, showConfirmButton: false });
    }
  });
}

function sendProfessionalPaymentReminder(phone, clientName, dueAmount) {
  if (!phone) return;
  let cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length === 10) cleanPhone = '91' + cleanPhone;

  const upiId = settings.upiId || '9311155593@paytm';
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi%3A%2F%2Fpay%3Fpa%3D${encodeURIComponent(upiId)}%26pn%3DMaa%20Annapurna%20Tiffin%26am%3D${dueAmount}%26cu%3DINR`;

  const msg = `Dear ${clientName},

Greetings from *${settings.bizName}* (Kunwar Singh Nagar)! 🙏

We hope you are enjoying our homemade meals. This is a gentle reminder that your tiffin subscription payment of *₹${dueAmount}* is currently pending.

💳 *PAYMENT OPTIONS*:
• UPI ID / GPay / PhonePe: ${upiId}
• Scan UPI QR Code: ${qrUrl}
• Direct Phone Contact: ${settings.bizPhone}
• Or pay in Cash to our delivery partner

Kindly complete the payment at your earliest convenience. If you have already transferred the amount, please disregard this notice.

Thank you for your valued patronage!
Warm regards,
*${settings.bizName}*`;

  openWhatsAppDirect({ phone, text: msg, customerName: clientName, title: 'Payment Reminder' });
}

// ==========================================
// CLIENT DIRECTORY
// ==========================================
let clientTypeFilter = 'all';

function filterClientByType(type) {
  clientTypeFilter = type;
  const btnAll = document.getElementById('clientTypeFilterAll');
  const btnSub = document.getElementById('clientTypeFilterSub');
  const btnOne = document.getElementById('clientTypeFilterOneTime');

  if (btnAll) btnAll.className = type === 'all' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-white text-slate-900 shadow-2xs' : 'flex-1 py-1.5 text-xs font-bold rounded-xl text-slate-600';
  if (btnSub) btnSub.className = type === 'subscriber' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-white text-slate-900 shadow-2xs' : 'flex-1 py-1.5 text-xs font-bold rounded-xl text-slate-600';
  if (btnOne) btnOne.className = type === 'onetime' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-white text-amber-900 shadow-2xs' : 'flex-1 py-1.5 text-xs font-bold rounded-xl text-amber-800';

  filterClientList();
}

function renderClientList(search = '', areaFilter = '') {
  const container = document.getElementById('clientListContainer');
  const areaSelect = document.getElementById('clientAreaFilter');

  const countAll = clients.length;
  const countSub = clients.filter(c => (c.clientType || 'subscriber') === 'subscriber').length;
  const countOne = clients.filter(c => c.clientType === 'onetime').length;

  const countAllEl = document.getElementById('countFilterAll');
  const countSubEl = document.getElementById('countFilterSub');
  const countOneEl = document.getElementById('countFilterOneTime');
  if (countAllEl) countAllEl.textContent = countAll;
  if (countSubEl) countSubEl.textContent = countSub;
  if (countOneEl) countOneEl.textContent = countOne;

  const uniqueAreas = Array.from(new Set(clients.map(c => c.area).filter(Boolean)));
  if (areaSelect) {
    const currentVal = areaSelect.value;
    areaSelect.innerHTML = `<option value="">All Delivery Routes (${clients.length})</option>` +
      uniqueAreas.map(a => `<option value="${a}" ${currentVal === a ? 'selected' : ''}>${a}</option>`).join('');
  }

  let filtered = clients;

  if (clientTypeFilter === 'subscriber') {
    filtered = filtered.filter(c => (c.clientType || 'subscriber') === 'subscriber');
  } else if (clientTypeFilter === 'onetime') {
    filtered = filtered.filter(c => c.clientType === 'onetime');
  }

  if (search.trim()) {
    const q = search.toLowerCase();
    filtered = filtered.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.phone.includes(q) || 
      (c.boxId && c.boxId.toLowerCase().includes(q))
    );
  }
  if (areaFilter) {
    filtered = filtered.filter(c => c.area === areaFilter);
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="aesthetic-card p-8 text-center">
        <p class="text-xs text-slate-400">No clients found matching the selected filters.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(c => {
    const hasPendingBox = Object.entries(boxStates).find(([boxId, st]) => st.status === 'with_client' && st.clientId === c.id);
    const isPaid = c.paymentStatus === 'paid';
    const isOneTime = c.clientType === 'onetime';

    return `
      <div class="aesthetic-card p-3.5 space-y-2">
        <div class="flex items-start justify-between">
          <div>
            <div class="flex items-center space-x-1.5 flex-wrap gap-y-1">
              <h4 class="text-xs font-bold text-slate-900">${c.name}</h4>
              ${isOneTime 
                ? `<span class="badge-soft-amber text-[9.5px] font-bold px-2 py-0.5 rounded-full">⚡ ONE-TIME ORDER</span>` 
                : `<span class="badge-soft-blue text-[9.5px] font-semibold px-2 py-0.5 rounded-full">📅 Monthly</span>`
              }
              <span class="badge-soft-orange text-[9.5px] font-semibold px-1.5 py-0.5 rounded-full">${c.mealType || 'Meal'}</span>
              ${hasPendingBox ? `<span class="badge-soft-red text-[9.5px] font-bold px-1.5 py-0.5 rounded-full animate-pulse">Box Out (${hasPendingBox[0]})</span>` : ''}
              ${isPaid 
                ? `<span class="badge-soft-emerald text-[9px] font-bold px-1.5 py-0.2 rounded-full">PAID</span>`
                : `<span class="badge-soft-red text-[9px] font-bold px-1.5 py-0.2 rounded-full">DUE: ₹${c.dueAmount}</span>`
              }
            </div>
            <p class="text-[11px] text-slate-500 mt-0.5">${c.address}</p>
          </div>
          <div class="text-right">
            <span class="text-xs font-black text-slate-800">₹${c.price || settings.defaultPrice}</span>
            <span class="block text-[9.5px] text-slate-400">${isOneTime ? '/order' : '/month'}</span>
          </div>
        </div>

        <div class="flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-100 pt-2">
          <div class="flex items-center space-x-2">
            <span>📞 ${c.phone}</span>
            ${c.boxId ? `<span class="box-code-badge text-[10px] py-0.5 px-2">${c.boxId}</span>` : ''}
          </div>
          
          <div class="flex items-center space-x-1.5">
            ${isOneTime ? `
              <button onclick="convertToOneTimeSubscriber('${c.id}')" class="text-emerald-700 bg-emerald-50 hover:bg-emerald-100 font-bold px-2 py-1 rounded-lg text-[10.5px]">
                Make Monthly
              </button>
            ` : ''}
            <button onclick="viewClientHistory('${c.id}')" class="text-orange-600 hover:text-orange-700 font-semibold px-2 py-1 bg-orange-50 hover:bg-orange-100 rounded-lg text-[11px] flex items-center">
              <i data-lucide="history" class="w-3.5 h-3.5 mr-1"></i>
              History
            </button>
            <button onclick="editClient('${c.id}')" class="text-slate-500 hover:text-orange-600 p-1">
              <i data-lucide="edit-2" class="w-3.5 h-3.5"></i>
            </button>
            <button onclick="deleteClient('${c.id}', '${c.name}')" class="text-slate-400 hover:text-red-600 p-1">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
            </button>
            <a href="tel:${c.phone}" class="text-emerald-600 p-1">
              <i data-lucide="phone" class="w-3.5 h-3.5"></i>
            </a>
          </div>
        </div>
      </div>
    `;
  }).join('');

  lucide.createIcons();
}

function convertToOneTimeSubscriber(clientId) {
  const client = clients.find(c => c.id === clientId);
  if (!client) return;

  Swal.fire({
    title: `Upgrade to Monthly Plan`,
    html: `
      <div class="text-left text-xs space-y-2 text-slate-700">
        <p>Convert <b>${client.name}</b> from one-time orders to regular Monthly Subscription:</p>
        <div>
          <label class="block font-semibold mb-1">Monthly Plan Fee (₹):</label>
          <input type="number" id="swalConvertPrice" value="${settings.defaultPrice}" class="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold">
        </div>
      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#059669',
    confirmButtonText: 'Convert to Monthly'
  }).then(res => {
    if (res.isConfirmed) {
      const price = Number(document.getElementById('swalConvertPrice').value) || settings.defaultPrice;
      client.clientType = 'subscriber';
      client.price = price;
      saveData();
      renderClientList();
      renderPaymentsList();
      Swal.fire({ icon: 'success', title: 'Converted to Monthly Subscriber! 🎉', timer: 1500, showConfirmButton: false });
    }
  });
}

function filterClientList() {
  const search = document.getElementById('clientSearchInput').value;
  const area = document.getElementById('clientAreaFilter').value;
  renderClientList(search, area);
}

function viewClientHistory(clientId) {
  const client = clients.find(c => c.id === clientId);
  if (!client) return;

  const clientLogs = logs.filter(l => l.clientId === clientId).reverse();
  const modal = document.getElementById('clientHistoryModal');
  const title = document.getElementById('clientHistoryTitle');
  const content = document.getElementById('clientHistoryContent');

  title.textContent = `${client.name} - Meal & Delivery History`;

  let historyHtml = `
    <div class="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-xs space-y-1">
      <p class="font-bold text-slate-800">Phone: <span class="font-normal">${client.phone}</span></p>
      <p class="font-bold text-slate-800">Address: <span class="font-normal">${client.address}</span></p>
      <p class="font-bold text-slate-800">Subscription: <span class="font-bold text-emerald-700">₹${client.price}/month</span> &bull; Status: <span class="uppercase font-bold ${client.paymentStatus === 'paid' ? 'text-emerald-600' : 'text-red-600'}">${client.paymentStatus}</span></p>
    </div>

    <h4 class="text-xs font-bold text-slate-900 uppercase tracking-wider pt-2">Past Delivery Log:</h4>
  `;

  if (clientLogs.length === 0) {
    historyHtml += `
      <div class="text-center py-6 text-slate-400 text-xs">
        No delivery history recorded for this client yet.
      </div>
    `;
  } else {
    historyHtml += `<div class="space-y-2">` + clientLogs.map(l => {
      const isDispatch = l.type === 'dispatch';
      const timeStr = new Date(l.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
      return `
        <div class="p-3 bg-white border border-slate-200 rounded-xl space-y-1 shadow-2xs">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold ${isDispatch ? 'text-emerald-700' : 'text-blue-700'}">
              ${isDispatch ? `↗️ Dispatched (${l.mealCategory || 'Meal'})` : '↙️ Empty Box Collected'}
            </span>
            <span class="text-[11px] text-slate-400 font-medium">${l.date} &bull; ${timeStr}</span>
          </div>

          <div class="text-xs text-slate-700 flex items-center justify-between">
            <span class="box-code-badge text-[10px] py-0.5 px-2">${l.boxId}</span>
            <div class="flex items-center space-x-1">
              ${l.price ? `<span class="badge-soft-emerald px-1.5 py-0.5 rounded text-[11px] font-bold">₹${l.price}</span>` : ''}
              ${l.paymentMode === 'cash' ? `<span class="badge-soft-orange px-1.5 py-0.5 rounded text-[10px] font-bold">💵 Cash</span>` : ''}
            </div>
          </div>

          ${l.menuTitle ? `
            <div class="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-lg mt-1 border border-slate-100">
              <span class="font-semibold text-orange-800">${l.menuTitle}:</span>
              ${l.menuItems ? `<span class="text-slate-500 block">${l.menuItems}</span>` : ''}
              ${l.extras && l.extras !== 'None' ? `<span class="text-emerald-700 font-semibold block mt-0.5">+ Extras: ${l.extras}</span>` : ''}
            </div>
          ` : ''}
        </div>
      `;
    }).join('') + `</div>`;
  }

  content.innerHTML = historyHtml;
  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeClientHistoryModal() {
  document.getElementById('clientHistoryModal').classList.add('hidden');
}

function toggleClientSubscriptionFields(type) {
  const wrapper = document.getElementById('monthlyAmountWrapper');
  const amountInput = document.getElementById('clientMonthlyAmount');
  if (!wrapper || !amountInput) return;
  if (type === 'monthly') {
    wrapper.style.display = 'block';
    amountInput.required = true;
    if (!amountInput.value || Number(amountInput.value) <= 0) {
      amountInput.value = settings.defaultPrice || 2500;
    }
  } else {
    wrapper.style.display = 'none';
    amountInput.required = false;
  }
}

function openClientModal(client = null) {
  const modal = document.getElementById('clientModal');
  const title = document.getElementById('clientModalTitle');
  const form = document.getElementById('clientForm');

  form.reset();

  const subTypeEl = document.getElementById('clientSubscriptionType');
  const monthlyAmtEl = document.getElementById('clientMonthlyAmount');

  if (client) {
    title.textContent = 'Edit Client Information';
    document.getElementById('clientId').value = client.id;
    document.getElementById('clientName').value = client.name || '';
    document.getElementById('clientPhone').value = client.phone || '';
    document.getElementById('clientAddress').value = client.address || '';
    document.getElementById('clientArea').value = client.area || '';
    document.getElementById('clientBoxId').value = client.boxId || '';
    document.getElementById('clientMealType').value = client.mealType || 'Lunch';
    document.getElementById('clientPaymentStatus').value = client.paymentStatus || 'paid';
    document.getElementById('clientDueAmount').value = client.dueAmount || 0;
    document.getElementById('clientStartDate').value = client.startDate || currentDate;

    const subType = client.subscriptionType || (client.clientType === 'onetime' ? 'daily' : 'monthly');
    if (subTypeEl) subTypeEl.value = subType;
    if (monthlyAmtEl) monthlyAmtEl.value = client.monthlyAmount || client.price || settings.defaultPrice;
    toggleClientSubscriptionFields(subType);
  } else {
    title.textContent = 'Add New Client';
    document.getElementById('clientId').value = '';
    document.getElementById('clientArea').value = 'Kunwar Singh Nagar';
    document.getElementById('clientBoxId').value = `MAT${String(clients.length + 1).padStart(3, '0')}`;
    document.getElementById('clientPaymentStatus').value = 'paid';
    document.getElementById('clientDueAmount').value = 0;
    document.getElementById('clientStartDate').value = currentDate;

    if (subTypeEl) subTypeEl.value = 'monthly';
    if (monthlyAmtEl) monthlyAmtEl.value = settings.defaultPrice || 2500;
    toggleClientSubscriptionFields('monthly');
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeClientModal() {
  document.getElementById('clientModal').classList.add('hidden');
}

function saveClient(event) {
  event.preventDefault();
  const id = document.getElementById('clientId').value;
  const name = document.getElementById('clientName').value.trim();
  const phone = document.getElementById('clientPhone').value.trim();
  const address = document.getElementById('clientAddress').value.trim();
  const area = document.getElementById('clientArea').value.trim();
  const boxId = document.getElementById('clientBoxId').value.trim().toUpperCase();
  const mealType = document.getElementById('clientMealType').value;
  const subscriptionType = document.getElementById('clientSubscriptionType')?.value || 'monthly';
  const monthlyAmount = subscriptionType === 'monthly' 
    ? (Number(document.getElementById('clientMonthlyAmount')?.value) || settings.defaultPrice || 2500)
    : 0;
  const price = subscriptionType === 'monthly' ? monthlyAmount : 0;
  const clientType = subscriptionType === 'monthly' ? 'subscriber' : 'onetime';
  const paymentStatus = document.getElementById('clientPaymentStatus').value;
  const dueAmount = Number(document.getElementById('clientDueAmount').value) || 0;
  const startDate = document.getElementById('clientStartDate').value || currentDate;

  if (id) {
    const index = clients.findIndex(c => c.id === id);
    if (index !== -1) {
      clients[index] = { 
        ...clients[index], 
        name, 
        phone, 
        address, 
        area, 
        boxId, 
        mealType, 
        subscriptionType, 
        monthlyAmount, 
        price, 
        clientType, 
        paymentStatus, 
        dueAmount, 
        startDate 
      };
    }
  } else {
    clients.push({
      id: 'c-' + Date.now(),
      name,
      phone,
      address,
      area: area || 'Kunwar Singh Nagar',
      boxId: boxId || ('MAT' + String(clients.length + 1).padStart(3, '0')),
      mealType,
      subscriptionType,
      monthlyAmount,
      price,
      clientType,
      paymentStatus,
      dueAmount,
      startDate,
      status: 'active'
    });
  }

  saveData();
  closeClientModal();
  renderClientList();
  renderPaymentsList();
  renderDashboard();

  Swal.fire({
    icon: 'success',
    title: 'Client Saved Successfully',
    timer: 1500,
    showConfirmButton: false
  });
}

function editClient(id) {
  const client = clients.find(c => c.id === id);
  if (client) openClientModal(client);
}

function deleteClient(id, name) {
  Swal.fire({
    title: 'Delete Client?',
    text: `Are you sure you want to remove ${name} from your client ledger?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#ef4444',
    confirmButtonText: 'Yes, Delete',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      clients = clients.filter(c => c.id !== id);
      saveData();
      renderClientList();
      renderPaymentsList();
      renderDashboard();
    }
  });
}

// ==========================================
// QR CODE GENERATOR & CLOUD DATABASE SYSTEM
// ==========================================

// Universal Scannable QR Code Renderer with High-Res Image Fallback
function renderQrCodeElement(elem, text, size = 64, colorDark = '#0f172a', colorLight = '#ffffff') {
  if (!elem) return;
  elem.innerHTML = '';

  const cleanText = String(text || '').trim();
  if (!cleanText) return;

  try {
    if (typeof QRCode !== 'undefined') {
      new QRCode(elem, {
        text: cleanText,
        width: size,
        height: size,
        colorDark: colorDark,
        colorLight: colorLight,
        correctLevel: QRCode.CorrectLevel.M
      });
      return;
    }
  } catch (err) {
    console.warn('QRCode library error, using fallback image:', err);
  }

  // Fallback img tag if QRCode instance encountered an issue
  const img = document.createElement('img');
  img.src = `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(cleanText)}`;
  img.alt = `QR ${cleanText}`;
  img.className = 'w-full h-full object-contain';
  elem.appendChild(img);
}

function getNextAvailableQrSerial() {
  if (!qrDatabase || qrDatabase.length === 0) {
    return '081026';
  }
  let maxNum = QR_INITIAL_START_SERIAL - 1;
  qrDatabase.forEach(item => {
    const raw = String(item.qrNumber || '').replace(/[^0-9]/g, '');
    const num = parseInt(raw, 10);
    if (!isNaN(num) && num > maxNum) {
      maxNum = num;
    }
  });
  return String(maxNum + 1).padStart(6, '0');
}

function updateNextSerialDisplay() {
  const badge = document.getElementById('nextSerialBadge');
  if (badge) {
    badge.textContent = getNextAvailableQrSerial();
  }
}

window.setAdminGenCount = function(count) {
  const input = document.getElementById('adminQrGenCount');
  if (input) input.value = count;
};

function generateSystemQrCodes(count = 1, initialStatus = 'Available', deliveryPartner = '') {
  count = parseInt(count, 10);
  if (isNaN(count) || count < 1) count = 1;
  if (count > 500) count = 500;

  Swal.fire({
    title: 'Generating Serialized QR Codes...',
    html: `Creating <b>${count}</b> unique 6-digit container QR(s) and syncing to cloud database...`,
    allowOutsideClick: false,
    didOpen: () => {
      Swal.showLoading();
    }
  });

  setTimeout(() => {
    const now = new Date().toISOString();
    let nextNum = parseInt(getNextAvailableQrSerial(), 10);
    let createdCount = 0;
    const createdSerials = [];

    for (let i = 0; i < count; i++) {
      const serial = String(nextNum).padStart(6, '0');
      // Prevent duplicate serial generation
      if (!qrDatabase.some(q => q.qrNumber === serial)) {
        qrDatabase.push({
          qrNumber: serial,
          status: initialStatus || 'Available',
          customerId: null,
          customerName: null,
          customerPhone: null,
          customerAddress: null,
          allotmentDate: null,
          returnDate: null,
          deliveryPartner: (deliveryPartner && deliveryPartner.trim()) ? deliveryPartner.trim() : 'Kitchen Partner',
          lastUpdated: now,
          generatedDate: now,
          allotmentHistory: [],
          returnHistory: []
        });

        boxStates[serial] = {
          status: 'available',
          clientId: null,
          clientName: null,
          clientPhone: null,
          clientAddress: null
        };

        createdSerials.push(serial);
        createdCount++;
      }
      nextNum++;
    }

    saveData(true);
    updateNextSerialDisplay();
    renderQrDatabaseList();
    renderReturnScreen();
    generateQRStickers();

    const first = createdSerials[0] || '081026';
    const last = createdSerials[createdSerials.length - 1] || first;

    playBeepSound('success');
    Swal.fire({
      icon: 'success',
      title: 'QR Codes Generated & Cloud Synced! 🏷️',
      html: `Successfully registered <b>${createdCount}</b> serialized 6-digit container QR(s):<br><span class="qr-serial-badge text-base mt-2 inline-block">${first} ${last !== first ? 'to ' + last : ''}</span><br><p class="text-xs text-slate-500 mt-2">Permanently saved to Cloud & DynamoDB database.</p>`,
      confirmButtonColor: '#ea580c'
    });
  }, 100);
}

window.handleAdminGenerateQrSubmit = function() {
  const countInput = document.getElementById('adminQrGenCount');
  const statusInput = document.getElementById('adminQrGenInitialStatus');
  const partnerInput = document.getElementById('adminQrGenDeliveryPartner');

  const count = parseInt(countInput?.value || 1, 10);
  const status = statusInput?.value || 'Available';
  const partner = partnerInput?.value || '';

  generateSystemQrCodes(count, status, partner);
};

// -------------------------------------------------------------------------
// QR DATABASE DIRECTORY & SEARCH
// -------------------------------------------------------------------------
let qrDbFilterMode = 'all'; // 'all' | 'available' | 'allotted' | 'returned' | 'lost'

function setQrDbFilter(mode) {
  qrDbFilterMode = mode;
  const modes = ['all', 'available', 'allotted', 'returned', 'lost'];
  modes.forEach(m => {
    const btn = document.getElementById(`qrDbFilter${capitalize(m)}Btn`);
    if (btn) {
      if (m === mode) {
        btn.className = 'py-1 px-3 text-xs font-bold rounded-xl bg-slate-900 text-white shrink-0 transition';
      } else {
        btn.className = 'py-1 px-3 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 shrink-0 transition';
      }
    }
  });
  renderQrDatabaseList();
}

// -------------------------------------------------------------------------
// ENLARGE & DOWNLOAD SERIALIZED QR CODE MODAL
// -------------------------------------------------------------------------
let currentEnlargeQrNumber = null;

function openQrEnlargeModal(qrNumber) {
  const modal = document.getElementById('qrEnlargeModal');
  const title = document.getElementById('qrEnlargeModalTitle');
  const serialBadge = document.getElementById('enlargeQrSerialBadge');
  const statusBadge = document.getElementById('enlargeQrStatusBadge');
  const clientMeta = document.getElementById('enlargeQrClientMeta');
  const holder = document.getElementById('enlargeQrHolder');
  const historyBtn = document.getElementById('enlargeQrHistoryBtn');

  if (!modal || !holder) return;

  currentEnlargeQrNumber = qrNumber;

  const qrRecord = qrDatabase.find(q => q.qrNumber === qrNumber) || {
    qrNumber: qrNumber,
    status: 'Available',
    customerName: null,
    deliveryPartner: 'Kitchen Partner'
  };

  const bizNameEl = document.getElementById('enlargeQrBizName');
  if (bizNameEl) bizNameEl.textContent = settings.bizName || 'Maa Annapurna Tiffin Service';
  if (title) title.textContent = `Container QR #${qrRecord.qrNumber}`;
  if (serialBadge) serialBadge.textContent = 'ID: ' + qrRecord.qrNumber;

  if (statusBadge) {
    if (qrRecord.status === 'Allotted') {
      statusBadge.className = 'badge-soft-amber px-2.5 py-0.5 rounded-full text-[11px] font-bold';
      statusBadge.textContent = 'Allotted (With Client)';
    } else if (qrRecord.status === 'Lost') {
      statusBadge.className = 'badge-soft-red px-2.5 py-0.5 rounded-full text-[11px] font-bold';
      statusBadge.textContent = 'Lost / Missing';
    } else {
      statusBadge.className = 'badge-soft-emerald px-2.5 py-0.5 rounded-full text-[11px] font-bold';
      statusBadge.textContent = 'Available in Kitchen';
    }
  }

  if (clientMeta) {
    if (qrRecord.status === 'Allotted') {
      clientMeta.innerHTML = `
        <span class="text-slate-900 font-bold">Assigned to: ${qrRecord.customerName || 'Registered Customer'}</span>
        ${qrRecord.customerPhone ? `&bull; <span class="text-slate-500 font-mono">${qrRecord.customerPhone}</span>` : ''}
      `;
    } else {
      clientMeta.innerHTML = `
        <span class="text-emerald-700 font-bold">✓ Ready for Allotment in Kitchen</span>
      `;
    }
  }

  // Render high-resolution scannable QR Code in center of square sticker (144x144)
  renderQrCodeElement(holder, qrRecord.qrNumber, 144);

  if (historyBtn) {
    historyBtn.onclick = () => {
      closeQrEnlargeModal();
      openQrHistoryModal(qrRecord.qrNumber);
    };
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeQrEnlargeModal() {
  const modal = document.getElementById('qrEnlargeModal');
  if (modal) modal.classList.add('hidden');
  currentEnlargeQrNumber = null;
}

function downloadQrImage(qrNum = null) {
  const code = qrNum || currentEnlargeQrNumber;
  if (!code) return;

  const holder = document.getElementById('enlargeQrHolder');
  let dataUrl = null;

  if (holder) {
    const canvas = holder.querySelector('canvas');
    if (canvas) {
      dataUrl = canvas.toDataURL('image/png');
    } else {
      const img = holder.querySelector('img');
      if (img && img.src && img.src.startsWith('data:')) {
        dataUrl = img.src;
      }
    }
  }

  if (!dataUrl) {
    const tempDiv = document.createElement('div');
    try {
      new QRCode(tempDiv, {
        text: code,
        width: 320,
        height: 320,
        colorDark: '#0f172a',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.H
      });
      const c = tempDiv.querySelector('canvas');
      if (c) dataUrl = c.toDataURL('image/png');
    } catch (e) {}
  }

  if (dataUrl) {
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `tiffin-qr-${code}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    Swal.fire({
      icon: 'success',
      title: 'QR Code Downloaded! 📥',
      html: `Container <b>#${code}</b> QR code image saved to your device.`,
      timer: 1600,
      showConfirmButton: false
    });
  } else {
    window.open(`https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=${encodeURIComponent(code)}`, '_blank');
  }
}

function printSingleQrSticker(qrNum = null) {
  const code = qrNum || currentEnlargeQrNumber;
  if (!code) return;

  const cardHtml = `
    <div style="font-family: Arial, sans-serif; text-align: center; border: 2.5px solid #000; width: 65mm; height: 65mm; box-sizing: border-box; padding: 6mm 4mm; margin: 20px auto; border-radius: 8px; background: #fff; display: flex; flex-direction: column; align-items: center; justify-content: space-between;">
      <div style="font-size: 10pt; font-weight: 800; text-transform: uppercase; color: #000; line-height: 1.15; letter-spacing: -0.2px;">${settings.bizName || 'Maa Annapurna Tiffin Service'}</div>
      <div style="margin: auto 0; width: 40mm; height: 40mm; display: flex; align-items: center; justify-content: center;">
        <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(code)}" width="150" height="150" style="display:block;margin:0 auto;" />
      </div>
      <div style="font-family: 'Courier New', monospace; font-size: 13pt; font-weight: 900; letter-spacing: 1.5px; color: #000;">ID: ${code}</div>
    </div>
  `;

  const printWindow = window.open('', '_blank', 'width=380,height=440');
  if (printWindow) {
    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Print Sticker - ${code}</title>
          <style>
            @page { size: auto; margin: 5mm; }
            body { margin: 0; padding: 10px; font-family: sans-serif; display: flex; align-items: center; justify-content: center; }
          </style>
        </head>
        <body onload="window.print();window.close();">
          ${cardHtml}
        </body>
      </html>
    `);
    printWindow.document.close();
  }
}

function shareQrImageWhatsApp(qrNum = null) {
  const code = qrNum || currentEnlargeQrNumber;
  if (!code) return;

  const qrRecord = qrDatabase.find(q => q.qrNumber === code);
  const status = qrRecord ? qrRecord.status : 'Available';
  const qrImgUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(code)}`;

  const text = `🍱 *Maa Annapurna Tiffin Service - Container QR Code* 🍱
Container ID: *#${code}*
Status: ${status}
Kitchen Location: ${settings.bizAddress}
Contact: ${settings.bizPhone}

Scan or View Container QR Sticker:
${qrImgUrl}

(Unique 6-digit serialized box tracking system)`;

  openWhatsAppDirect({ phone: '', text, title: `Container QR #${code}` });
}

// Expose modal functions to window for onclick bindings
window.openQrEnlargeModal = openQrEnlargeModal;
window.closeQrEnlargeModal = closeQrEnlargeModal;
window.downloadQrImage = downloadQrImage;
window.printSingleQrSticker = printSingleQrSticker;
window.shareQrImageWhatsApp = shareQrImageWhatsApp;

// -------------------------------------------------------------------------
// QR CODE DELETION MANAGEMENT
// -------------------------------------------------------------------------
function confirmDeleteQrCode(boxId) {
  if (!boxId) return;

  const qrRecord = qrDatabase.find(q => q.qrNumber === boxId);
  if (!qrRecord) {
    Swal.fire({ icon: 'error', title: 'Not Found', text: 'QR Code does not exist in database.' });
    return;
  }

  const isAllotted = qrRecord.status === 'Allotted';

  Swal.fire({
    title: `Delete QR Code #${boxId}?`,
    html: `
      <div class="text-left text-xs space-y-2 text-slate-700">
        <p>Are you sure you want to <b>permanently delete</b> Container QR Code <span class="qr-serial-badge text-sm">${boxId}</span>?</p>
        ${isAllotted ? `<p class="p-2 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg font-bold">⚠️ Warning: This container is currently marked as ALLOTTED to ${qrRecord.customerName || 'a customer'}.</p>` : ''}
        <p class="text-slate-500">Once deleted:</p>
        <ul class="list-disc pl-5 text-slate-500 space-y-1">
          <li>It will be removed permanently from cloud database and inventory.</li>
          <li>Scanning this QR code in the future will display <b class="text-rose-600">"Invalid QR Code"</b>.</li>
          <li>This action cannot be undone.</li>
        </ul>
      </div>
    `,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#e11d48',
    cancelButtonColor: '#64748b',
    confirmButtonText: 'Yes, Delete Permanently',
    cancelButtonText: 'Cancel'
  }).then((result) => {
    if (result.isConfirmed) {
      deleteQrCode(boxId);
    }
  });
}

function deleteQrCode(boxId) {
  const index = qrDatabase.findIndex(q => q.qrNumber === boxId);
  if (index === -1) {
    Swal.fire({ icon: 'error', title: 'Error', text: 'QR Code not found in database.' });
    return;
  }

  // Remove from database and state
  qrDatabase.splice(index, 1);
  if (boxStates[boxId]) {
    delete boxStates[boxId];
  }

  // Close modals if currently viewing this QR
  if (currentEnlargeQrNumber === boxId) {
    closeQrEnlargeModal();
  }

  // Save to persistent storage and cloud
  saveData(true);

  // Re-render UI components
  renderQrDatabaseList();
  renderReturnScreen();
  renderDashboard();
  updateNextSerialDisplay();

  playBeepSound('success');
  Swal.fire({
    icon: 'success',
    title: 'QR Code Deleted! 🗑️',
    html: `Container QR <b>#${boxId}</b> has been permanently removed from the system.<br><span class="text-xs text-slate-500">Scanning this QR will now show "Invalid QR Code".</span>`,
    timer: 2300,
    showConfirmButton: false
  });
}

window.confirmDeleteQrCode = confirmDeleteQrCode;
window.deleteQrCode = deleteQrCode;

function renderQrDatabaseList() {
  const container = document.getElementById('qrDatabaseListContainer');
  if (!container) return;

  const todayStr = currentDate || new Date().toISOString().split('T')[0];

  const countTotal = qrDatabase.length;
  const countAvailable = qrDatabase.filter(q => q.status === 'Available').length;
  const countAllotted = qrDatabase.filter(q => q.status === 'Allotted').length;
  const countReturned = qrDatabase.filter(q => q.returnDate && q.returnDate.startsWith(todayStr)).length;
  const countLost = qrDatabase.filter(q => q.status === 'Lost').length;

  // Header and Hero counts
  const elTotal = document.getElementById('qrStatTotalCount');
  const elAvail = document.getElementById('qrStatAvailableCount');
  const elAllot = document.getElementById('qrStatAllottedCount');
  const elRet = document.getElementById('qrStatReturnedCount');
  const elShowing = document.getElementById('qrDbShowingCount');

  if (elTotal) elTotal.textContent = countTotal;
  if (elAvail) elAvail.textContent = countAvailable;
  if (elAllot) elAllot.textContent = countAllotted;
  if (elRet) elRet.textContent = countReturned;

  // Filter button count spans
  const cAll = document.getElementById('qrDbCountAll');
  const cAvail = document.getElementById('qrDbCountAvailable');
  const cAllot = document.getElementById('qrDbCountAllotted');
  const cRet = document.getElementById('qrDbCountReturned');
  const cLost = document.getElementById('qrDbCountLost');

  if (cAll) cAll.textContent = countTotal;
  if (cAvail) cAvail.textContent = countAvailable;
  if (cAllot) cAllot.textContent = countAllotted;
  if (cRet) cRet.textContent = countReturned;
  if (cLost) cLost.textContent = countLost;

  updateNextSerialDisplay();

  // Filter
  let list = qrDatabase;
  if (qrDbFilterMode === 'available') {
    list = qrDatabase.filter(q => q.status === 'Available');
  } else if (qrDbFilterMode === 'allotted') {
    list = qrDatabase.filter(q => q.status === 'Allotted');
  } else if (qrDbFilterMode === 'returned') {
    list = qrDatabase.filter(q => q.returnDate && q.returnDate.startsWith(todayStr));
  } else if (qrDbFilterMode === 'lost') {
    list = qrDatabase.filter(q => q.status === 'Lost');
  }

  // Manual Search Query: QR Number, Customer Name, Mobile Number
  const searchInput = document.getElementById('qrDbSearchInput');
  const q = searchInput ? searchInput.value.trim().toLowerCase() : '';
  if (q) {
    list = list.filter(item => {
      const matchQr = item.qrNumber && item.qrNumber.toLowerCase().includes(q);
      const matchName = item.customerName && item.customerName.toLowerCase().includes(q);
      const matchPhone = item.customerPhone && item.customerPhone.includes(q);
      const matchAddress = item.customerAddress && item.customerAddress.toLowerCase().includes(q);
      return matchQr || matchName || matchPhone || matchAddress;
    });
  }

  if (elShowing) elShowing.textContent = `Showing ${list.length} of ${countTotal} Containers`;

  if (list.length === 0) {
    container.innerHTML = `
      <div class="aesthetic-card p-6 text-center text-xs text-slate-400">
        No containers found matching your search or filter.
      </div>
    `;
    lucide.createIcons();
    return;
  }

  container.innerHTML = list.map(item => {
    let statusBadge = '';
    if (item.status === 'Available') {
      statusBadge = '<span class="badge-soft-emerald px-2 py-0.5 rounded-full text-[10px] font-bold">Available</span>';
    } else if (item.status === 'Allotted') {
      statusBadge = '<span class="badge-soft-amber px-2 py-0.5 rounded-full text-[10px] font-bold">Allotted</span>';
    } else if (item.status === 'Lost') {
      statusBadge = '<span class="badge-soft-red px-2 py-0.5 rounded-full text-[10px] font-bold">Lost</span>';
    } else {
      statusBadge = '<span class="badge-soft-blue px-2 py-0.5 rounded-full text-[10px] font-bold">Returned</span>';
    }

    const allotCount = (item.allotmentHistory && item.allotmentHistory.length) || 0;
    const returnCount = (item.returnHistory && item.returnHistory.length) || 0;

    return `
      <div class="aesthetic-card p-3.5 space-y-2.5">
        <div class="flex items-start space-x-3">
          
          <!-- Scannable Serial QR Code Thumbnail -->
          <div class="flex flex-col items-center shrink-0">
            <div onclick="openQrEnlargeModal('${item.qrNumber}')" 
                 class="qr-db-thumb-box cursor-pointer group relative" 
                 title="Click to Zoom / Download QR">
              <div id="qr-db-thumb-${item.qrNumber}" class="w-full h-full flex items-center justify-center"></div>
              <div class="absolute inset-0 bg-slate-900/60 rounded-[10px] opacity-0 group-hover:opacity-100 flex items-center justify-center transition text-white text-[10px] font-bold">
                🔍 Enlarge
              </div>
            </div>
            <span class="text-[9px] text-slate-400 font-mono mt-0.5">Click to Zoom</span>
          </div>

          <!-- Container Details -->
          <div class="flex-1 min-w-0 space-y-1">
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-1.5 flex-wrap">
                <span class="qr-serial-badge text-xs font-mono font-bold">${item.qrNumber}</span>
                ${statusBadge}
              </div>
              <button onclick="openQrHistoryModal('${item.qrNumber}')" class="text-xs text-orange-600 hover:text-orange-700 font-bold flex items-center space-x-1 shrink-0 ml-1">
                <i data-lucide="history" class="w-3.5 h-3.5"></i>
                <span>History (${allotCount})</span>
              </button>
            </div>

            <div class="text-xs text-slate-600">
              ${item.status === 'Allotted' 
                ? `<div><b>Assigned to:</b> <span class="text-slate-900 font-bold">${item.customerName || 'Customer'}</span> <span class="text-slate-500">(${item.customerPhone || 'No Phone'})</span></div>
                   <div class="text-[11px] text-slate-500">Allotted: ${new Date(item.allotmentDate).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</div>`
                : `<div class="text-slate-500">Location: <b>Kitchen Inventory</b> (Clean & Available)</div>`
              }
              <div class="text-[11px] text-slate-400 mt-0.5">
                Partner: <b>${item.deliveryPartner || 'Kitchen'}</b> &bull; Cycles: <b>${allotCount}</b> &bull; Returns: <b>${returnCount}</b>
              </div>
            </div>
          </div>
        </div>

        <!-- Card Footer Actions -->
        <div class="flex items-center justify-between pt-1.5 border-t border-slate-100">
          <button onclick="openQrEnlargeModal('${item.qrNumber}')" class="px-2.5 py-1 text-xs text-slate-700 bg-slate-100 hover:bg-slate-200 font-semibold rounded-xl flex items-center space-x-1 transition">
            <i data-lucide="qr-code" class="w-3.5 h-3.5 text-orange-600"></i>
            <span>View / Download QR</span>
          </button>

          <div class="flex items-center space-x-1.5">
            ${item.status === 'Allotted' 
              ? `<button onclick="handleReturnScan('${item.qrNumber}')" class="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-2xs flex items-center space-x-1">
                   <span>🔄 Return Tiffin</span>
                 </button>`
              : `<button onclick="handleDispatchScan('${item.qrNumber}')" class="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-2xs flex items-center space-x-1">
                   <span>🍱 Allot Tiffin</span>
                 </button>`
            }
            <button onclick="confirmDeleteQrCode('${item.qrNumber}')" title="Delete QR Code Permanently" class="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-xl transition active:scale-95" aria-label="Delete QR Code">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  // Render QR Code image thumbnails for each container in database list
  list.forEach(item => {
    const thumbEl = document.getElementById(`qr-db-thumb-${item.qrNumber}`);
    if (thumbEl) {
      renderQrCodeElement(thumbEl, item.qrNumber, 60);
    }
  });

  lucide.createIcons();
}

// -------------------------------------------------------------------------
// QR CODE LIFECYCLE AUDIT HISTORY MODAL
// -------------------------------------------------------------------------
function openQrHistoryModal(qrNumber) {
  const modal = document.getElementById('qrHistoryModal');
  const title = document.getElementById('qrHistoryModalTitle');
  const body = document.getElementById('qrHistoryModalBody');
  if (!modal || !body) return;

  const qrRecord = qrDatabase.find(q => q.qrNumber === qrNumber);
  if (!qrRecord) {
    Swal.fire({ icon: 'error', title: 'Not Found', text: 'QR Code not found in database.' });
    return;
  }

  if (title) title.textContent = `Container History: QR #${qrRecord.qrNumber}`;

  const allotList = qrRecord.allotmentHistory || [];
  const retList = qrRecord.returnHistory || [];

  const timelineEvents = [];

  if (qrRecord.generatedDate) {
    timelineEvents.push({
      type: 'generated',
      timestamp: qrRecord.generatedDate,
      title: 'QR Code Created & Registered',
      description: `Generated by Admin with initial status: Available. 6-Digit Serial: ${qrRecord.qrNumber}`
    });
  }

  allotList.forEach(a => {
    timelineEvents.push({
      type: 'allot',
      timestamp: a.allotmentDate,
      title: `Allotted to ${a.customerName || 'Customer'}`,
      description: `${a.mealCategory || 'Meal'} (${a.menuTitle || 'Special Thali'}) &bull; Price: ₹${a.price || 0} (${a.paymentMode ? a.paymentMode.toUpperCase() : 'PENDING'}) &bull; Partner: ${a.deliveryPartner || 'Kitchen'}`
    });
  });

  retList.forEach(r => {
    timelineEvents.push({
      type: 'return',
      timestamp: r.returnDate,
      title: `Returned by ${r.customerName || 'Customer'}`,
      description: `Container returned to kitchen. ${r.collectedCash ? '💵 Cash collected upon return.' : 'Payment cleared previously.'}`
    });
  });

  // Sort newest first
  timelineEvents.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

  body.innerHTML = `
    <!-- Top Summary Card with Scannable QR Code Image -->
    <div class="aesthetic-card p-3 bg-slate-50 border border-slate-200 flex items-center space-x-3 text-xs">
      <div onclick="openQrEnlargeModal('${qrRecord.qrNumber}')" class="qr-history-thumb cursor-pointer group relative" title="Click to zoom / download QR">
        <div id="qr-history-thumb-${qrRecord.qrNumber}" class="w-full h-full flex items-center justify-center"></div>
        <div class="absolute inset-0 bg-slate-900/60 rounded-[10px] opacity-0 group-hover:opacity-100 flex items-center justify-center transition text-white text-[9px] font-bold">
          🔍 Zoom
        </div>
      </div>
      <div class="flex-1 min-w-0 space-y-1">
        <div class="flex items-center justify-between">
          <span class="qr-serial-badge text-sm font-mono font-bold">${qrRecord.qrNumber}</span>
          <span class="badge-soft-${qrRecord.status === 'Allotted' ? 'amber' : 'emerald'} font-bold px-2 py-0.5 rounded-full uppercase text-[10px]">${qrRecord.status}</span>
        </div>
        <div><b>Partner:</b> ${qrRecord.deliveryPartner || 'Kitchen'}</div>
        <div class="truncate"><b>Status:</b> ${qrRecord.customerName ? `With ${qrRecord.customerName}` : 'Available in Kitchen'}</div>
        <div class="text-slate-400 text-[10px]">Updated: ${new Date(qrRecord.lastUpdated || Date.now()).toLocaleString('en-IN')}</div>
      </div>
    </div>

    <div class="space-y-1">
      <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider">Complete Lifecycle History:</h4>
      
      <div class="space-y-3 pt-2">
        ${timelineEvents.map(evt => {
          let dotClass = 'timeline-dot-gen';
          let icon = '🏷️';
          if (evt.type === 'allot') {
            dotClass = 'timeline-dot-allot';
            icon = '↗️';
          } else if (evt.type === 'return') {
            dotClass = 'timeline-dot-return';
            icon = '↙️';
          }

          const dateStr = new Date(evt.timestamp).toLocaleString('en-IN', {
            day: 'numeric',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          });

          return `
            <div class="timeline-item pl-6 relative">
              <div class="timeline-dot ${dotClass}"></div>
              <div class="text-xs font-bold text-slate-900 flex items-center space-x-1">
                <span>${icon}</span>
                <span>${evt.title}</span>
              </div>
              <div class="text-[11px] text-slate-500">${evt.description}</div>
              <div class="text-[10px] text-slate-400 font-mono mt-0.5">${dateStr}</div>
            </div>
          `;
        }).join('')}
      </div>
    </div>
  `;

  // Render QR Code image inside history modal
  renderQrCodeElement(document.getElementById(`qr-history-thumb-${qrRecord.qrNumber}`), qrRecord.qrNumber, 68);

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeQrHistoryModal() {
  const modal = document.getElementById('qrHistoryModal');
  if (modal) modal.classList.add('hidden');
}

window.openQrHistoryModal = openQrHistoryModal;
window.closeQrHistoryModal = closeQrHistoryModal;

// -------------------------------------------------------------------------
// PRINTABLE SERIALIZED QR STICKERS SHEET (Starts 081026)
// -------------------------------------------------------------------------
let isGeneratingQRs = false;

// Single sheet print utility for printing a specific A4 page
window.printSpecificA4Sheet = function(pageNum) {
  const allPages = document.querySelectorAll('.a4-print-page');
  if (!allPages.length) {
    window.print();
    return;
  }

  document.body.classList.add('print-single-sheet-mode');
  allPages.forEach(p => {
    if (p.getAttribute('data-page') == String(pageNum)) {
      p.classList.remove('print-sheet-hide');
    } else {
      p.classList.add('print-sheet-hide');
    }
  });

  window.print();

  setTimeout(() => {
    document.body.classList.remove('print-single-sheet-mode');
    allPages.forEach(p => p.classList.remove('print-sheet-hide'));
  }, 1000);
};

function generateQRStickers() {
  if (isGeneratingQRs) return;

  const grid = document.getElementById('stickersGrid');
  const countInfo = document.getElementById('generatedCountInfo');
  const sheetBizName = document.getElementById('printSheetBizName');
  const sheetBizAddress = document.getElementById('printSheetBizAddress');

  if (sheetBizName) sheetBizName.textContent = settings.bizName || 'Maa Annapurna Tiffin Service';
  if (sheetBizAddress) sheetBizAddress.textContent = `${settings.bizAddress} • Phone: ${settings.bizPhone}`;

  if (!grid) return;
  grid.innerHTML = '';

  let stickersList = qrDatabase.map(q => q.qrNumber);
  if (stickersList.length === 0) {
    // Default to 1 full A4 sheet (12 stickers) starting from 081026
    for (let i = 0; i < 12; i++) {
      stickersList.push(String(QR_INITIAL_START_SERIAL + i).padStart(6, '0'));
    }
  }

  const count = stickersList.length;
  const firstCode = stickersList[0];
  const lastCode = stickersList[stickersList.length - 1];
  const STICKERS_PER_A4 = 12; // Strictly 12 QR codes per A4 paper (3 cols x 4 rows)
  const totalSheets = Math.ceil(count / STICKERS_PER_A4);

  if (countInfo) {
    countInfo.textContent = `Preparing ${count} Stickers across ${totalSheets} A4 Sheet(s) (12 per page)...`;
  }

  isGeneratingQRs = true;

  // Chunk stickers into exact groups of 12 for A4 pages
  const pages = [];
  for (let i = 0; i < count; i += STICKERS_PER_A4) {
    pages.push(stickersList.slice(i, i + STICKERS_PER_A4));
  }

  let currentPageIdx = 0;

  function renderPageBatch() {
    if (currentPageIdx >= pages.length) {
      isGeneratingQRs = false;
      if (countInfo) {
        countInfo.textContent = `✅ ${count} Stickers Ready (${totalSheets} A4 Sheet${totalSheets > 1 ? 's' : ''} • Strictly 12 per A4 Paper • ${firstCode} to ${lastCode})`;
      }
      lucide.createIcons();
      return;
    }

    const pageNum = currentPageIdx + 1;
    const pageItems = pages[currentPageIdx];

    const pageContainer = document.createElement('div');
    pageContainer.className = 'a4-print-page';
    pageContainer.setAttribute('data-page', pageNum);

    // Screen-only header showing A4 sheet number & direct print button
    const screenHeader = document.createElement('div');
    screenHeader.className = 'a4-sheet-screen-header print:hidden flex flex-col sm:flex-row sm:items-center sm:justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl mb-3 gap-2';
    screenHeader.innerHTML = `
      <div class="flex items-center space-x-2">
        <span class="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-orange-600 text-white font-extrabold text-xs shadow-2xs">
          ${pageNum}
        </span>
        <div>
          <span class="text-xs font-extrabold text-slate-800">A4 Paper Sheet ${pageNum} of ${totalSheets}</span>
          <span class="text-[11px] text-slate-500 ml-1.5 font-medium">(Strictly 12 QR Codes: <span class="font-mono text-orange-600 font-bold">${pageItems[0]}</span> to <span class="font-mono text-orange-600 font-bold">${pageItems[pageItems.length - 1]}</span>)</span>
        </div>
      </div>
      <div class="flex items-center space-x-2">
        <span class="badge-soft-emerald px-2 py-0.5 rounded-full text-[10.5px] font-bold">${pageItems.length} / 12 Stickers</span>
        <button type="button" onclick="printSpecificA4Sheet(${pageNum})" class="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-800 text-xs font-bold rounded-lg border border-slate-200 shadow-2xs flex items-center space-x-1 transition active:scale-95">
          <i data-lucide="printer" class="w-3 h-3 text-orange-600"></i>
          <span>Print Sheet ${pageNum}</span>
        </button>
      </div>
    `;
    pageContainer.appendChild(screenHeader);

    // Grid container with 12 stickers (3 cols x 4 rows)
    const stickersGrid = document.createElement('div');
    stickersGrid.className = 'a4-stickers-grid';

    pageItems.forEach(boxId => {
      const cardId = `qr-card-${boxId}`;
      const card = document.createElement('div');
      card.className = 'qr-square-sticker shadow-2xs';
      card.innerHTML = `
        <div class="sticker-name">${settings.bizName || 'Maa Annapurna Tiffin Service'}</div>
        <div id="${cardId}" class="sticker-qr-holder"></div>
        <div class="sticker-id">ID: ${boxId}</div>
      `;
      stickersGrid.appendChild(card);
    });

    pageContainer.appendChild(stickersGrid);
    grid.appendChild(pageContainer);

    // Render high-res scannable QR Code image for each container box
    pageItems.forEach(boxId => {
      const cardId = `qr-card-${boxId}`;
      try {
        renderQrCodeElement(document.getElementById(cardId), boxId, 104);
      } catch (e) {
        console.error('QR render error:', e);
      }
    });

    currentPageIdx++;
    setTimeout(renderPageBatch, 20);
  }

  renderPageBatch();
}

// ==========================================
// 1" × 1" QR CODE LABELS (70 LABELS PER A4 SHEET)
// ==========================================
let isGenerating1InchLabels = false;

function generate1InchQrLabels() {
  if (isGenerating1InchLabels) return;

  const container = document.getElementById('stickers1InchContainer');
  const countInfo = document.getElementById('generatedCountInfo');
  const sheetBizName = document.getElementById('printSheetBizName');

  if (sheetBizName) sheetBizName.textContent = settings.bizName || 'Maa Annapurna Tiffin Service';
  if (!container) return;
  container.innerHTML = '';

  let stickersList = qrDatabase.map(q => q.qrNumber);
  if (stickersList.length === 0) {
    // Generate full A4 sheet (70 labels) starting from 081026
    for (let i = 0; i < 70; i++) {
      stickersList.push(String(QR_INITIAL_START_SERIAL + i).padStart(6, '0'));
    }
  }

  const count = stickersList.length;
  const firstCode = stickersList[0];
  const lastCode = stickersList[stickersList.length - 1];
  const LABELS_PER_A4 = 70; // 7 columns x 10 rows = 70 labels per A4 page
  const totalSheets = Math.ceil(count / LABELS_PER_A4);

  if (countInfo) {
    countInfo.textContent = `Preparing ${count} 1"×1" Labels across ${totalSheets} A4 Sheet(s) (70 per sheet)...`;
  }

  isGenerating1InchLabels = true;

  // Chunk stickers into exact groups of 70 for A4 pages
  const pages = [];
  for (let i = 0; i < count; i += LABELS_PER_A4) {
    pages.push(stickersList.slice(i, i + LABELS_PER_A4));
  }

  let currentPageIdx = 0;

  function renderPageBatch() {
    if (currentPageIdx >= pages.length) {
      isGenerating1InchLabels = false;
      if (countInfo) {
        countInfo.textContent = `✅ ${count} 1"×1" Labels Ready (${totalSheets} A4 Sheet${totalSheets > 1 ? 's' : ''} • Exactly 70 per A4 Page • ${firstCode} to ${lastCode})`;
      }
      lucide.createIcons();
      return;
    }

    const pageNum = currentPageIdx + 1;
    const pageItems = pages[currentPageIdx];

    const pageContainer = document.createElement('div');
    pageContainer.className = 'a4-1inch-page';
    pageContainer.setAttribute('data-sheet', pageNum);

    // Screen-only header showing A4 sheet number & direct print button
    const screenHeader = document.createElement('div');
    screenHeader.className = 'print:hidden flex flex-col sm:flex-row sm:items-center sm:justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl mb-3 gap-2';
    screenHeader.innerHTML = `
      <div class="flex items-center space-x-2">
        <span class="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-orange-600 text-white font-extrabold text-xs shadow-2xs">
          ${pageNum}
        </span>
        <div>
          <span class="text-xs font-extrabold text-slate-800">A4 Label Sheet ${pageNum} of ${totalSheets}</span>
          <span class="text-[11px] text-slate-500 ml-1.5 font-medium">(1" × 1" Square Labels: <span class="font-mono text-orange-600 font-bold">${pageItems[0]}</span> to <span class="font-mono text-orange-600 font-bold">${pageItems[pageItems.length - 1]}</span>)</span>
        </div>
      </div>
      <div class="flex items-center space-x-2">
        <span class="badge-soft-emerald px-2 py-0.5 rounded-full text-[10.5px] font-bold">${pageItems.length} / 70 Labels</span>
        <button type="button" onclick="printSpecific1InchSheet(${pageNum})" class="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-800 text-xs font-bold rounded-lg border border-slate-200 shadow-2xs flex items-center space-x-1 transition active:scale-95">
          <i data-lucide="printer" class="w-3 h-3 text-orange-600"></i>
          <span>Print Sheet ${pageNum}</span>
        </button>
      </div>
    `;
    pageContainer.appendChild(screenHeader);

    // Grid container with 70 labels (7 cols x 10 rows)
    const stickersGrid = document.createElement('div');
    stickersGrid.className = 'a4-1inch-grid';

    pageItems.forEach(boxId => {
      const cardId = `qr-1inch-canvas-${boxId}`;
      const card = document.createElement('div');
      card.className = 'qr-label-1inch';
      card.onclick = () => openQrEnlargeModal(boxId);
      card.title = `Click to zoom / print single label for Box ${boxId}`;
      card.innerHTML = `
        <div class="qr-label-biz">${settings.bizName || 'Maa Annapurna Tiffin Service'}</div>
        <div id="${cardId}" class="qr-label-canvas"></div>
        <div class="qr-label-boxid">Box ID: ${boxId}</div>
      `;
      stickersGrid.appendChild(card);
    });

    pageContainer.appendChild(stickersGrid);
    container.appendChild(pageContainer);

    // Render high-res scannable QR Code image for each container box
    pageItems.forEach(boxId => {
      const cardId = `qr-1inch-canvas-${boxId}`;
      try {
        renderQrCodeElement(document.getElementById(cardId), boxId, 54);
      } catch (e) {
        console.error('QR 1-inch render error:', e);
      }
    });

    currentPageIdx++;
    setTimeout(renderPageBatch, 20);
  }

  renderPageBatch();
}

function printA4QrLabels() {
  const container = document.getElementById('stickers1InchContainer');
  if (!container || !container.children.length) {
    generate1InchQrLabels();
    setTimeout(() => window.print(), 400);
  } else {
    window.print();
  }
}

function printSpecific1InchSheet(sheetNum) {
  const allPages = document.querySelectorAll('.a4-1inch-page');
  if (!allPages.length) {
    window.print();
    return;
  }

  document.body.classList.add('print-single-sheet-mode');
  allPages.forEach(p => {
    if (p.getAttribute('data-sheet') == String(sheetNum)) {
      p.classList.remove('print-sheet-hide');
    } else {
      p.classList.add('print-sheet-hide');
    }
  });

  window.print();

  setTimeout(() => {
    document.body.classList.remove('print-single-sheet-mode');
    allPages.forEach(p => p.classList.remove('print-sheet-hide'));
  }, 1000);
}

// ==========================================
// MENU MANAGEMENT (ADD, EDIT, DELETE, TOGGLE MEALS)
// ==========================================
function renderMenuList() {
  const container = document.getElementById('menuListContainer');
  const countTotalEl = document.getElementById('menuCountTotal');
  const countActiveEl = document.getElementById('menuCountActive');
  const countDisabledEl = document.getElementById('menuCountDisabled');

  if (countTotalEl) countTotalEl.textContent = menuItemsList.length;
  if (countActiveEl) countActiveEl.textContent = menuItemsList.filter(m => m.enabled !== false).length;
  if (countDisabledEl) countDisabledEl.textContent = menuItemsList.filter(m => m.enabled === false).length;

  if (!container) return;

  if (menuItemsList.length === 0) {
    container.innerHTML = `
      <div class="aesthetic-card p-8 text-center text-slate-400 text-xs">
        No meals added yet. Tap "+ Add Meal" to create your first delicious offering.
      </div>
    `;
    return;
  }

  container.innerHTML = menuItemsList.map(m => {
    const isEnabled = m.enabled !== false;
    const typeLabel = m.mealType === 'lunch' ? '☀️ Lunch' : (m.mealType === 'dinner' ? '🌙 Dinner' : '☀️🌙 Lunch & Dinner');
    return `
      <div class="aesthetic-card p-4 space-y-3 transition ${isEnabled ? 'bg-white border-slate-200' : 'bg-slate-50/80 border-slate-200 opacity-70'}">
        <div class="flex items-start justify-between gap-2">
          <div class="space-y-1">
            <div class="flex items-center space-x-2 flex-wrap gap-y-1">
              <h3 class="text-sm font-bold text-slate-900">${m.name}</h3>
              <span class="badge-soft-orange text-[9.5px] font-bold px-2 py-0.5 rounded-full">${typeLabel}</span>
              ${isEnabled 
                ? `<span class="badge-soft-emerald text-[9.5px] font-bold px-2 py-0.5 rounded-full">✓ Active</span>`
                : `<span class="badge-soft-red text-[9.5px] font-bold px-2 py-0.5 rounded-full">✕ Inactive / Off</span>`
              }
            </div>
            <p class="text-xs font-mono text-slate-600 whitespace-pre-line bg-slate-50 p-2.5 rounded-xl border border-slate-100">${m.items}</p>
          </div>
          <div class="text-right shrink-0">
            <span class="text-base font-black text-emerald-700">₹${m.price}</span>
            <span class="block text-[10px] text-slate-400">per Thali</span>
          </div>
        </div>

        <div class="flex items-center justify-between border-t border-slate-100 pt-2.5 text-xs">
          <button type="button" onclick="toggleMealStatus('${m.id}')" class="px-2.5 py-1 font-bold rounded-lg transition text-[11px] flex items-center space-x-1 ${isEnabled ? 'bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200' : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200'}">
            <span>${isEnabled ? '⏸ Disable Meal' : '▶ Enable Meal'}</span>
          </button>
          <div class="flex items-center space-x-1.5">
            <button type="button" onclick="openMealModal('${m.id}')" class="px-2.5 py-1 bg-slate-100 hover:bg-orange-50 text-slate-700 hover:text-orange-700 font-semibold rounded-lg text-[11px] flex items-center space-x-1 transition">
              <i data-lucide="edit-2" class="w-3.5 h-3.5"></i>
              <span>Edit</span>
            </button>
            <button type="button" onclick="deleteMeal('${m.id}')" class="px-2 py-1 bg-red-50 hover:bg-red-100 text-red-600 font-semibold rounded-lg text-[11px] transition" title="Delete Meal">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  lucide.createIcons();
}

function openMealModal(mealId = null) {
  const modal = document.getElementById('mealModal');
  const title = document.getElementById('mealModalTitle');
  const form = document.getElementById('mealForm');

  form.reset();

  if (mealId) {
    const meal = menuItemsList.find(m => m.id === mealId);
    if (!meal) return;
    title.textContent = 'Edit Meal';
    document.getElementById('mealId').value = meal.id;
    document.getElementById('mealNameInput').value = meal.name;
    document.getElementById('mealPriceInput').value = meal.price;
    document.getElementById('mealTypeSelect').value = meal.mealType || 'lunch';
    document.getElementById('mealItemsInput').value = meal.items;
    document.getElementById('mealStatusSelect').value = meal.enabled !== false ? 'enabled' : 'disabled';
  } else {
    title.textContent = 'Add New Meal';
    document.getElementById('mealId').value = '';
    document.getElementById('mealPriceInput').value = 80;
    document.getElementById('mealTypeSelect').value = 'lunch';
    document.getElementById('mealStatusSelect').value = 'enabled';
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeMealModal() {
  document.getElementById('mealModal').classList.add('hidden');
}

function saveMeal(event) {
  event.preventDefault();
  const id = document.getElementById('mealId').value;
  const name = document.getElementById('mealNameInput').value.trim();
  const price = Number(document.getElementById('mealPriceInput').value);
  const mealType = document.getElementById('mealTypeSelect').value;
  const items = document.getElementById('mealItemsInput').value.trim();
  const enabled = document.getElementById('mealStatusSelect').value === 'enabled';

  if (!name || isNaN(price) || price <= 0 || !items) {
    Swal.fire({
      icon: 'warning',
      title: 'Missing Fields',
      text: 'Please provide valid meal name, price, and dishes list.'
    });
    return;
  }

  if (id) {
    const index = menuItemsList.findIndex(m => m.id === id);
    if (index !== -1) {
      menuItemsList[index] = { ...menuItemsList[index], name, price, mealType, items, enabled };
    }
  } else {
    menuItemsList.push({
      id: 'meal-' + Date.now(),
      name,
      price,
      mealType,
      items,
      enabled
    });
  }

  saveData();
  closeMealModal();
  renderMenuList();
  renderDashboard();

  Swal.fire({
    icon: 'success',
    title: 'Meal Saved! 🍲',
    text: `${name} (₹${price}) has been saved to the database.`,
    timer: 1500,
    showConfirmButton: false
  });
}

function deleteMeal(mealId) {
  const meal = menuItemsList.find(m => m.id === mealId);
  if (!meal) return;

  Swal.fire({
    title: `Delete "${meal.name}"?`,
    text: 'Do you want to remove this meal from the menu database?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#ef4444',
    confirmButtonText: 'Yes, Delete',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      menuItemsList = menuItemsList.filter(m => m.id !== mealId);
      saveData();
      renderMenuList();
      renderDashboard();
      Swal.fire({ icon: 'success', title: 'Meal Deleted', timer: 1200, showConfirmButton: false });
    }
  });
}

function toggleMealStatus(mealId) {
  const meal = menuItemsList.find(m => m.id === mealId);
  if (!meal) return;

  meal.enabled = !meal.enabled;
  saveData();
  renderMenuList();
  renderDashboard();

  Swal.fire({
    icon: 'info',
    title: meal.enabled ? 'Meal Activated ✓' : 'Meal Disabled ⏸',
    text: `"${meal.name}" is now ${meal.enabled ? 'available for allotment' : 'temporarily hidden'}.`,
    timer: 1300,
    showConfirmButton: false
  });
}

// ==========================================
// TIFFIN ALLOTMENT (SEARCH CLIENT, MULTI-TIFFIN QUANTITY, BOX ID & REAL-TIME AUTO PRICE)
// ==========================================
let currentAllotmentQty = 1;

function openAllotmentModal(preSelectedBoxId = null) {
  const modal = document.getElementById('allotmentModal');
  const form = document.getElementById('allotmentForm');
  const qtyInput = document.getElementById('allotmentQuantity');
  const searchInput = document.getElementById('allotmentClientSearchInput');
  const mealSelect = document.getElementById('allotmentMealId');

  if (form) form.reset();

  currentAllotmentQty = 1;
  if (qtyInput) qtyInput.value = 1;

  // Clear selected client state
  clearSelectedAllotmentClient();

  // Populate filterable clients list
  if (searchInput) searchInput.value = '';
  filterAllotmentClients('');

  // If a container was passed and already belongs to a client, pre-select client
  if (preSelectedBoxId) {
    const qrRec = qrDatabase.find(q => q.qrNumber === preSelectedBoxId);
    if (qrRec && qrRec.customerId) {
      selectAllotmentClient(qrRec.customerId);
    }
  }

  // Populate Meals from menuItemsList
  if (mealSelect) {
    const activeMeals = menuItemsList.filter(m => m.enabled !== false);
    const displayMeals = activeMeals.length > 0 ? activeMeals : menuItemsList;

    if (displayMeals.length === 0) {
      mealSelect.innerHTML = `<option value="">No meals in menu - please add a meal first</option>`;
    } else {
      mealSelect.innerHTML = `<option value="">-- Choose Meal --</option>` +
        displayMeals.map(m => `<option value="${m.id}">${m.name} (₹${m.price} - ${m.mealType || 'Meal'})</option>`).join('');

      mealSelect.value = displayMeals[0].id;
    }
  }

  // Render Box ID slots based on current quantity
  renderAllotmentBoxSelectors(preSelectedBoxId);

  // Recalculate auto price
  updateAllotmentPriceDisplay();

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeAllotmentModal() {
  const modal = document.getElementById('allotmentModal');
  if (modal) modal.classList.add('hidden');
}

// -------------------------------------------------------------------------
// CLIENT SEARCH IN ALLOTMENT MODAL (Search by Name, Mobile, Client ID)
// -------------------------------------------------------------------------
function filterAllotmentClients(searchTerm = '') {
  const q = String(searchTerm).trim().toLowerCase();
  let matches = clients;
  if (q) {
    matches = clients.filter(c => {
      const matchName = c.name && c.name.toLowerCase().includes(q);
      const matchPhone = c.phone && String(c.phone).includes(q);
      const matchId = c.id && String(c.id).toLowerCase().includes(q);
      const matchAddress = c.address && c.address.toLowerCase().includes(q);
      return matchName || matchPhone || matchId || matchAddress;
    });
  }
  renderAllotmentClientOptions(matches);
}

function renderAllotmentClientOptions(list) {
  const container = document.getElementById('allotmentClientListContainer');
  if (!container) return;

  if (!list || list.length === 0) {
    container.innerHTML = `
      <div class="p-3 text-center text-xs text-slate-400">
        No clients matching search. <button type="button" onclick="closeAllotmentModal(); openClientModal();" class="text-orange-600 font-bold underline ml-1">+ Add New Client</button>
      </div>
    `;
    return;
  }

  const currentSelectedId = document.getElementById('allotmentClientId')?.value;

  container.innerHTML = list.map(c => {
    const isSelected = c.id === currentSelectedId;
    const typeStr = c.subscriptionType === 'daily' || c.clientType === 'onetime' ? 'Daily Pay' : 'Monthly';
    const typeBadgeClass = typeStr === 'Daily Pay' ? 'badge-soft-amber' : 'badge-soft-emerald';

    return `
      <div onclick="selectAllotmentClient('${c.id}')" class="p-2 rounded-xl border ${isSelected ? 'border-emerald-500 bg-emerald-50/90 shadow-2xs' : 'border-slate-200 bg-white hover:bg-slate-50'} cursor-pointer flex items-center justify-between transition text-xs">
        <div class="min-w-0 pr-2">
          <div class="flex items-center space-x-1.5">
            <span class="font-bold text-slate-900 truncate">${c.name}</span>
            <span class="${typeBadgeClass} text-[9.5px] font-bold px-1.5 py-0.2 rounded-full">${typeStr}</span>
          </div>
          <div class="text-[11px] text-slate-500 mt-0.5 flex items-center space-x-1 font-mono">
            <span>📞 ${c.phone}</span>
            <span>&bull;</span>
            <span class="text-slate-400">ID: #${c.id}</span>
          </div>
        </div>
        <button type="button" class="px-2.5 py-1 ${isSelected ? 'bg-emerald-600 text-white' : 'bg-slate-100 hover:bg-emerald-600 hover:text-white text-slate-700'} font-bold text-[11px] rounded-lg transition shrink-0">
          ${isSelected ? '✓ Selected' : 'Select'}
        </button>
      </div>
    `;
  }).join('');
}

function selectAllotmentClient(clientId) {
  const client = clients.find(c => c.id === clientId);
  if (!client) return;

  const hiddenInput = document.getElementById('allotmentClientId');
  if (hiddenInput) hiddenInput.value = client.id;

  const card = document.getElementById('allotmentSelectedClientCard');
  const nameEl = document.getElementById('allotmentSelectedClientName');
  const badgeEl = document.getElementById('allotmentSelectedClientTypeBadge');
  const metaEl = document.getElementById('allotmentSelectedClientMeta');

  const typeStr = client.subscriptionType === 'daily' || client.clientType === 'onetime' ? 'Daily Pay' : 'Monthly';

  if (nameEl) nameEl.textContent = client.name;
  if (badgeEl) {
    badgeEl.textContent = typeStr;
    badgeEl.className = `${typeStr === 'Daily Pay' ? 'badge-soft-amber' : 'badge-soft-emerald'} text-[9px] font-bold px-1.5 py-0.2 rounded-full`;
  }
  if (metaEl) metaEl.innerHTML = `📞 ${client.phone} &bull; ID: #${client.id} &bull; ${client.address || 'Address registered'}`;
  if (card) card.classList.remove('hidden');

  // Refresh client cards styling
  const searchInput = document.getElementById('allotmentClientSearchInput');
  filterAllotmentClients(searchInput ? searchInput.value : '');
}

function clearSelectedAllotmentClient() {
  const hiddenInput = document.getElementById('allotmentClientId');
  if (hiddenInput) hiddenInput.value = '';

  const card = document.getElementById('allotmentSelectedClientCard');
  if (card) card.classList.add('hidden');

  const searchInput = document.getElementById('allotmentClientSearchInput');
  if (searchInput) {
    searchInput.value = '';
  }
  filterAllotmentClients('');
}

// -------------------------------------------------------------------------
// MULTIPLE TIFFIN QUANTITY & DYNAMIC BOX SELECTORS
// -------------------------------------------------------------------------
function adjustAllotmentQty(delta) {
  const qtyInput = document.getElementById('allotmentQuantity');
  let currentVal = parseInt(qtyInput ? qtyInput.value : currentAllotmentQty, 10) || 1;
  currentVal = Math.max(1, Math.min(25, currentVal + delta));
  if (qtyInput) qtyInput.value = currentVal;
  onAllotmentQtyChange(currentVal);
}

function onAllotmentQtyChange(val) {
  let qty = parseInt(val, 10);
  if (isNaN(qty) || qty < 1) qty = 1;
  if (qty > 25) qty = 25;
  currentAllotmentQty = qty;

  const qtyInput = document.getElementById('allotmentQuantity');
  if (qtyInput) qtyInput.value = qty;

  renderAllotmentBoxSelectors();
  updateAllotmentPriceDisplay();
}

function renderAllotmentBoxSelectors(preSelectedBoxId = null) {
  const container = document.getElementById('allotmentBoxesContainer');
  const countEl = document.getElementById('allotmentAvailableBoxesCount');
  if (!container) return;

  const availableBoxes = qrDatabase.filter(q => q.status === 'Available');
  if (countEl) {
    countEl.textContent = `${availableBoxes.length} in kitchen`;
  }

  // Preserve any currently chosen values in existing slots
  const currentSlotValues = [];
  for (let i = 0; i < currentAllotmentQty; i++) {
    const existingSelect = document.getElementById(`allotmentBoxId_${i}`);
    if (existingSelect && existingSelect.value) {
      currentSlotValues[i] = existingSelect.value;
    } else if (i === 0 && preSelectedBoxId) {
      currentSlotValues[0] = preSelectedBoxId;
    }
  }

  let html = '';
  for (let i = 0; i < currentAllotmentQty; i++) {
    const slotVal = currentSlotValues[i] || '';
    html += `
      <div class="flex items-center space-x-2 bg-white p-2 rounded-xl border border-emerald-200 shadow-2xs">
        <span class="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-emerald-700 text-white font-extrabold text-[11px] shrink-0">
          #${i + 1}
        </span>
        <div class="flex-1 min-w-0">
          <select id="allotmentBoxId_${i}" required class="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-mono font-bold bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none">
            <option value="">-- Choose Container #${i + 1} --</option>
            ${slotVal && !availableBoxes.some(q => q.qrNumber === slotVal) ? `<option value="${slotVal}" selected>${slotVal} (Selected Container)</option>` : ''}
            ${availableBoxes.map(q => `<option value="${q.qrNumber}" ${q.qrNumber === slotVal ? 'selected' : ''}>${q.qrNumber} (Available)</option>`).join('')}
          </select>
        </div>
        <button type="button" onclick="openScannerFromAllotment(${i})" title="Scan QR Code for Box #${i + 1}" class="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-lg shadow-2xs flex items-center space-x-1 shrink-0 transition active:scale-95">
          <i data-lucide="camera" class="w-3.5 h-3.5"></i>
          <span>Scan</span>
        </button>
      </div>
    `;
  }

  container.innerHTML = html;
  lucide.createIcons();
}

function openScannerFromAllotment(slotIndex = 0) {
  allotmentTargetBoxSlot = slotIndex;
  openScannerModal('allotment');
}

// -------------------------------------------------------------------------
// REAL-TIME AUTO PRICING (UNIT MEAL PRICE × QUANTITY)
// -------------------------------------------------------------------------
function onAllotmentMealChange(mealId) {
  updateAllotmentPriceDisplay();
}

function updateAllotmentPriceDisplay() {
  const mealSelect = document.getElementById('allotmentMealId');
  const priceInput = document.getElementById('allotmentMealPrice');
  const hintEl = document.getElementById('allotmentMealHint');
  const badgeEl = document.getElementById('allotmentPricingBadge');
  if (!priceInput) return;

  const mealId = mealSelect ? mealSelect.value : '';
  const meal = menuItemsList.find(m => m.id === mealId);

  if (meal) {
    const unitPrice = Number(meal.price) || 0;
    const qty = currentAllotmentQty || 1;
    const totalPrice = unitPrice * qty;
    priceInput.value = totalPrice;
    if (badgeEl) badgeEl.textContent = `₹${unitPrice} × ${qty} Tiffin${qty > 1 ? 's' : ''}`;
    if (hintEl) {
      hintEl.textContent = `Auto-calculated: ${meal.name} (₹${unitPrice}) × ${qty} box(es) = ₹${totalPrice} Total.`;
    }
  } else {
    priceInput.value = '';
    if (badgeEl) badgeEl.textContent = 'Auto-Priced';
    if (hintEl) {
      hintEl.textContent = 'Price updates automatically as soon as a meal and quantity are selected.';
    }
  }
}

// -------------------------------------------------------------------------
// MULTI-BOX ALLOTMENT SUBMIT HANDLER
// -------------------------------------------------------------------------
function handleAllotmentSubmit(event) {
  event.preventDefault();
  const clientId = document.getElementById('allotmentClientId')?.value;
  const mealId = document.getElementById('allotmentMealId')?.value;
  const mealPriceTotal = Number(document.getElementById('allotmentMealPrice')?.value);
  const deliveryPartner = document.getElementById('allotmentDeliveryPartner')?.value.trim() || 'Kitchen Self';
  const paymentMode = document.getElementById('allotmentPaymentMode')?.value || 'subscription';

  // 1. Validate Client
  if (!clientId) {
    Swal.fire({
      icon: 'warning',
      title: 'No Client Selected',
      text: 'Please select a registered client from the list or search by Name / Mobile / ID.'
    });
    return;
  }

  const client = clients.find(c => c.id === clientId);
  if (!client) {
    Swal.fire({ icon: 'error', title: 'Client Not Found', text: 'Selected client is not found in database.' });
    return;
  }

  // 2. Validate Meal
  const meal = menuItemsList.find(m => m.id === mealId);
  if (!meal || isNaN(mealPriceTotal) || mealPriceTotal <= 0) {
    Swal.fire({
      icon: 'warning',
      title: 'Choose Meal',
      text: 'Please select an active meal from the menu before confirming.'
    });
    return;
  }

  // 3. Collect and validate Box IDs for all slots (1 to currentAllotmentQty)
  const selectedBoxIds = [];
  for (let i = 0; i < currentAllotmentQty; i++) {
    const boxSelect = document.getElementById(`allotmentBoxId_${i}`);
    const boxVal = boxSelect ? boxSelect.value.trim().toUpperCase() : '';
    if (!boxVal) {
      Swal.fire({
        icon: 'warning',
        title: `Container #${i + 1} Missing`,
        text: `Please choose or scan a 6-digit Box ID for Tiffin #${i + 1}.`
      });
      return;
    }
    selectedBoxIds.push(boxVal);
  }

  // 4. Validate duplicate Box IDs within this allotment
  const uniqueBoxes = new Set(selectedBoxIds);
  if (uniqueBoxes.size !== selectedBoxIds.length) {
    Swal.fire({
      icon: 'error',
      title: 'Duplicate Box Selected',
      text: 'You cannot allot the same Container ID more than once. Every tiffin box must have a unique QR code.'
    });
    return;
  }

  // 5. Validate Box IDs exist in qrDatabase and are registered system containers
  const qrRecords = [];
  for (const rawBoxId of selectedBoxIds) {
    const qrRecord = qrDatabase.find(q => 
      q.qrNumber.toUpperCase() === rawBoxId || 
      q.qrNumber === rawBoxId.padStart(6, '0')
    );

    if (!qrRecord) {
      Swal.fire({
        icon: 'error',
        title: 'Invalid Box ID.',
        text: `Invalid Box ID: "${rawBoxId}". This QR Code does not belong to this system or has been deleted.`,
        footer: '<span class="text-xs text-slate-500">Only system-generated 6-digit containers starting from 081026 are accepted.</span>',
        confirmButtonColor: '#ea580c'
      });
      return;
    }

    if (qrRecord.status === 'Allotted') {
      Swal.fire({
        icon: 'warning',
        title: `Container #${qrRecord.qrNumber} Already Out`,
        text: `Container #${qrRecord.qrNumber} is currently allotted to ${qrRecord.customerName || 'another customer'}. Please return it first or choose another available container.`
      });
      return;
    }

    qrRecords.push(qrRecord);
  }

  const timestamp = new Date().toISOString();
  const todayStr = currentDate || timestamp.split('T')[0];
  const unitMealPrice = Number(meal.price) || Math.round(mealPriceTotal / currentAllotmentQty);

  // 6. Update all containers in qrDatabase & boxStates
  qrRecords.forEach(qrRecord => {
    qrRecord.status = 'Allotted';
    qrRecord.customerId = client.id;
    qrRecord.customerName = client.name;
    qrRecord.customerPhone = client.phone;
    qrRecord.customerAddress = client.address;
    qrRecord.mealId = meal.id;
    qrRecord.mealName = meal.name;
    qrRecord.mealPrice = unitMealPrice;
    qrRecord.deliveryPartner = deliveryPartner;
    qrRecord.allotmentDate = timestamp;
    qrRecord.lastUpdated = timestamp;

    if (!qrRecord.allotmentHistory) qrRecord.allotmentHistory = [];
    qrRecord.allotmentHistory.push({
      customerId: client.id,
      customerName: client.name,
      customerPhone: client.phone,
      mealName: qrRecord.mealName,
      mealPrice: unitMealPrice,
      deliveryPartner,
      allotmentDate: timestamp,
      paymentMode
    });

    boxStates[qrRecord.qrNumber] = {
      status: 'with_client',
      clientId: client.id,
      clientName: client.name,
      clientPhone: client.phone,
      clientAddress: client.address,
      mealName: qrRecord.mealName,
      mealPrice: unitMealPrice,
      dispatchedAt: timestamp
    };

    logs.push({
      id: 'log-' + Date.now() + '-' + qrRecord.qrNumber,
      timestamp,
      date: todayStr,
      boxId: qrRecord.qrNumber,
      clientId: client.id,
      clientName: client.name,
      menuTitle: qrRecord.mealName,
      price: unitMealPrice,
      mealCategory: meal.mealType || 'Meal',
      paymentMode,
      deliveryPartner,
      type: 'dispatch'
    });
  });

  // 7. Update Client Payment Status
  if (paymentMode === 'cash' || paymentMode === 'upi') {
    client.paymentStatus = 'paid';
    client.dueAmount = 0;
  } else if (paymentMode === 'due') {
    client.paymentStatus = 'pending';
    client.dueAmount = (Number(client.dueAmount) || 0) + mealPriceTotal;
  }

  // 8. Save Data & Sync to Cloud
  saveData(true);
  closeAllotmentModal();
  renderDashboard();
  renderReturnScreen();
  renderQrDatabaseList();
  renderPaymentsList();

  const assignedBoxesPills = selectedBoxIds.map(b => `<span class="qr-serial-badge">${b}</span>`).join(' ');
  Swal.fire({
    icon: 'success',
    title: `${selectedBoxIds.length} Tiffin${selectedBoxIds.length > 1 ? 's' : ''} Allotted Successfully! 🍱`,
    html: `
      <div class="text-left text-xs space-y-2">
        <div><b>Assigned to:</b> <span class="text-slate-900 font-bold">${client.name}</span> (${client.phone})</div>
        <div><b>Container(s):</b> ${assignedBoxesPills}</div>
        <div><b>Meal:</b> ${meal.name} (₹${unitMealPrice} × ${selectedBoxIds.length} = <b>₹${mealPriceTotal}</b>)</div>
        <div><b>Partner:</b> ${deliveryPartner} &bull; <b>Mode:</b> ${paymentMode.toUpperCase()}</div>
      </div>
    `,
    confirmButtonColor: '#059669',
    confirmButtonText: 'Done'
  });
}

// Expose Allotment Modal functions to window
window.openAllotmentModal = openAllotmentModal;
window.closeAllotmentModal = closeAllotmentModal;
window.filterAllotmentClients = filterAllotmentClients;
window.renderAllotmentClientOptions = renderAllotmentClientOptions;
window.selectAllotmentClient = selectAllotmentClient;
window.clearSelectedAllotmentClient = clearSelectedAllotmentClient;
window.adjustAllotmentQty = adjustAllotmentQty;
window.onAllotmentQtyChange = onAllotmentQtyChange;
window.renderAllotmentBoxSelectors = renderAllotmentBoxSelectors;
window.openScannerFromAllotment = openScannerFromAllotment;
window.onAllotmentMealChange = onAllotmentMealChange;
window.updateAllotmentPriceDisplay = updateAllotmentPriceDisplay;
window.handleAllotmentSubmit = handleAllotmentSubmit;

// ==========================================
// SETTINGS & BACKUP
// ==========================================
function renderSettings() {
  const bizNameInput = document.getElementById('settingBizName');
  const bizAddressInput = document.getElementById('settingBizAddress');
  const bizPhoneInput = document.getElementById('settingBizPhone');
  const defaultPriceInput = document.getElementById('settingDefaultPrice');
  const upiIdInput = document.getElementById('settingUpiId');
  const authPhoneInput = document.getElementById('settingAuthPhone');
  const authEmailInput = document.getElementById('settingAuthEmail');
  const authDisplay = document.getElementById('authDisplayAccount');

  if (bizNameInput) bizNameInput.value = settings.bizName;
  if (bizAddressInput) bizAddressInput.value = settings.bizAddress;
  if (bizPhoneInput) bizPhoneInput.value = settings.bizPhone;
  if (defaultPriceInput) defaultPriceInput.value = settings.defaultPrice;
  if (upiIdInput) upiIdInput.value = settings.upiId || '9311155593@paytm';
  if (authPhoneInput) authPhoneInput.value = settings.bizPhone;
  if (authEmailInput) authEmailInput.value = settings.bizEmail || 'annapurna.tiffin@gmail.com';
  if (authDisplay) authDisplay.textContent = `${settings.bizAddress} (${settings.bizPhone})`;

  const cognitoSubEl = document.getElementById('settingCognitoSub');
  const backendLabelEl = document.getElementById('settingBackendLabel');
  if (cognitoSubEl) cognitoSubEl.textContent = CognitoAuth.getCurrentUserId() || 'cognito-sub-...';
  if (backendLabelEl) {
    if (typeof SupabaseClient !== 'undefined' && SupabaseClient.isConfigured()) {
      backendLabelEl.innerHTML = '<i data-lucide="database" class="w-3 h-3 mr-1 text-emerald-600"></i> Supabase Cloud (Live Connected)';
    } else if (AWS_CONFIG.isConfigured()) {
      backendLabelEl.innerHTML = '<i data-lucide="database" class="w-3 h-3 mr-1 text-emerald-600"></i> AWS DynamoDB (Live Connected)';
    } else {
      backendLabelEl.innerHTML = '<i data-lucide="cloud" class="w-3 h-3 mr-1 text-purple-600"></i> Cloud Store (Sandbox Mode)';
    }
  }

  if (typeof updateSupabaseUi === 'function') updateSupabaseUi();
  renderCustomQrPreview();
}

function handleCustomQrUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    settings.customQrImage = e.target.result;
    saveData();
    renderCustomQrPreview();
    Swal.fire({
      icon: 'success',
      title: 'QR Code Photo Saved! 🖼️',
      text: 'Yeh photo WhatsApp receipts me aur on-screen QR popup me dikhega.',
      timer: 1800,
      showConfirmButton: false
    });
  };
  reader.readAsDataURL(file);
}

function removeCustomQr() {
  settings.customQrImage = null;
  saveData();
  renderCustomQrPreview();
  const fileInput = document.getElementById('settingCustomQrFile');
  if (fileInput) fileInput.value = '';
  Swal.fire({
    icon: 'info',
    title: 'Photo Removed',
    text: 'Ab dynamic UPI QR generator use hoga.',
    timer: 1400,
    showConfirmButton: false
  });
}

function renderCustomQrPreview() {
  const holder = document.getElementById('customQrPreviewHolder');
  const removeBtn = document.getElementById('btnRemoveCustomQr');
  if (!holder) return;

  if (settings.customQrImage) {
    holder.innerHTML = `<img src="${settings.customQrImage}" alt="Custom QR" class="w-full h-full object-contain">`;
    if (removeBtn) removeBtn.classList.remove('hidden');
  } else {
    holder.innerHTML = `<span class="text-[10px] text-slate-400 text-center p-2 leading-tight">No custom QR photo</span>`;
    if (removeBtn) removeBtn.classList.add('hidden');
  }
}

// -------------------------------------------------------------------------
// RESET FUNCTIONS: DAILY OPERATIONS RESET, CLEAR LOGS, FACTORY RESET
// -------------------------------------------------------------------------
function resetTodayDispatches() {
  const pendingBoxes = qrDatabase.filter(q => q.status === 'Allotted');

  Swal.fire({
    title: 'Start New Day?',
    html: `
      <div class="text-left text-xs space-y-2 text-slate-600">
        <p>This action marks <b>${pendingBoxes.length}</b> container(s) currently out with clients as returned to kitchen and available for allotment.</p>
        <p class="text-emerald-700 font-semibold">✓ Registered customer profiles, phone numbers, and payment ledger remain 100% intact.</p>
      </div>
    `,
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#d97706',
    confirmButtonText: 'Yes, Start New Day',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      const now = new Date().toISOString();
      qrDatabase.forEach(q => {
        if (q.status === 'Allotted') {
          if (!q.returnHistory) q.returnHistory = [];
          q.returnHistory.push({
            customerId: q.customerId,
            customerName: q.customerName,
            returnDate: now,
            collectedCash: false
          });
          q.status = 'Available';
          q.returnDate = now;
          q.customerId = null;
          q.customerName = null;
          q.customerPhone = null;
          q.customerAddress = null;
          q.lastUpdated = now;
        }
      });

      Object.keys(boxStates).forEach(boxId => {
        boxStates[boxId] = {
          status: 'available',
          clientId: null,
          clientName: null,
          collectedAt: now
        };
      });

      saveData();
      renderDashboard();
      renderReturnScreen();
      renderQrDatabaseList();

      Swal.fire({
        icon: 'success',
        title: 'New Day Started! ☀️',
        text: 'All 6-digit tiffin containers are ready in kitchen.',
        timer: 1800,
        showConfirmButton: false
      });
    }
  });
}

function clearTodayActivityLogs() {
  Swal.fire({
    title: 'Clear Today\'s Activity Log?',
    text: 'Dashboard se aaj ke delivery aur collection logs hatt jayenge.',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#1e293b',
    confirmButtonText: 'Yes, Clear Log',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      logs = logs.filter(l => l.date !== currentDate);
      saveData();
      renderDashboard();
      Swal.fire({ icon: 'success', title: 'Activity Log Cleared', timer: 1200, showConfirmButton: false });
    }
  });
}

function factoryResetData() {
  Swal.fire({
    title: '⚠️ Complete Factory Reset',
    html: `
      <div class="text-left text-xs space-y-2 text-red-700">
        <p><b>Savdhani!</b> Kya aap sara test data delete karke 100% clean account shuru karna chahte hain?</p>
        <p class="text-slate-600">Isse sabhi sample clients aur dummy logs delete ho jayenge taaki aap apna asli business data daal sakein.</p>
      </div>
    `,
    icon: 'warning',
    showDenyButton: true,
    showCancelButton: true,
    confirmButtonColor: '#dc2626',
    denyButtonColor: '#2563eb',
    confirmButtonText: 'Wipe All (0 Records)',
    denyButtonText: 'Reload Demo Data',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      // 100% Clean slate
      clients = [];
      logs = [];
      boxStates = {};
      qrDatabase = [];
      saveData();
      location.reload();
    } else if (res.isDenied) {
      // Reload fresh sample demo
      loadInitialDefaults();
      logs = [];
      saveData();
      location.reload();
    }
  });
}

function saveSettings() {
  settings.bizName = document.getElementById('settingBizName').value.trim() || 'Maa Annapurna Tiffin Service';
  settings.bizAddress = document.getElementById('settingBizAddress').value.trim() || 'Kunwar Singh Nagar';
  settings.bizPhone = document.getElementById('settingBizPhone').value.trim() || '+91 9311155593';
  settings.defaultPrice = Number(document.getElementById('settingDefaultPrice').value) || 2500;
  settings.upiId = document.getElementById('settingUpiId').value.trim() || '9311155593@paytm';
  settings.bizEmail = document.getElementById('settingAuthEmail').value.trim() || 'annapurna.tiffin@gmail.com';

  saveData();
  renderDashboard();
  renderSettings();

  Swal.fire({
    icon: 'success',
    title: 'Company Profile & Settings Saved',
    timer: 1500,
    showConfirmButton: false
  });
}

function exportDataJSON() {
  const data = { clients, logs, boxStates, settings, weeklyMenu, customMenus, extraItemsCatalog, qrDatabase, exportedAt: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `maa-annapurna-tiffin-backup-${currentDate}.json`;
  a.click();
}

function exportDataCSV() {
  let csv = 'ID,Name,Phone,Address,Area,BoxID,MonthlyPrice,PaymentStatus,DueAmount\n';
  clients.forEach(c => {
    csv += `"${c.id}","${c.name}","${c.phone}","${c.address}","${c.area || ''}","${c.boxId || ''}",${c.price},"${c.paymentStatus}",${c.dueAmount || 0}\n`;
  });
  
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `maa-annapurna-clients-${currentDate}.csv`;
  a.click();
}

function importDataJSON(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (data.clients) clients = data.clients;
      if (data.logs) logs = data.logs;
      if (data.boxStates) boxStates = data.boxStates;
      if (data.settings) settings = data.settings;
      if (data.weeklyMenu) {
        delete data.weeklyMenu.sunday;
        weeklyMenu = data.weeklyMenu;
      }
      if (data.customMenus) customMenus = data.customMenus;
      if (data.extraItemsCatalog) extraItemsCatalog = data.extraItemsCatalog;
      if (data.qrDatabase && Array.isArray(data.qrDatabase)) qrDatabase = data.qrDatabase;

      saveData();
      renderDashboard();
      renderMenuPlanner();
      renderCustomMenusList();
      renderExtraItemsCatalog();
      renderClientList();
      renderReturnScreen();
      renderQrDatabaseList();
      renderPaymentsList();

      Swal.fire({ icon: 'success', title: 'Data Restored Successfully!' });
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Error', text: 'Backup file is corrupted or invalid.' });
    }
  };
  reader.readAsText(file);
}

function capitalize(s) {
  if (!s) return '';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// ==========================================
// PWA INSTALLATION
// ==========================================
function setupPwa() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').then(() => {
      console.log('ServiceWorker registered');
    }).catch(err => console.log('SW error:', err));
  }

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const installBtn = document.getElementById('pwaInstallBtn');
    if (installBtn) installBtn.classList.remove('hidden');
  });
}

function triggerPwaInstall() {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult) => {
      deferredPrompt = null;
    });
  } else {
    Swal.fire({
      title: 'Mobile App Installation',
      html: `
        <div class="text-left text-xs space-y-2 text-slate-700">
          <p>1. Open Google Chrome on your Android phone.</p>
          <p>2. Tap the <b>3 dots (&vellip;)</b> in the top-right corner.</p>
          <p>3. Tap <b>"Install app"</b> or <b>"Add to Home Screen"</b>.</p>
          <p>4. Maa Annapurna Tiffin Service icon will install directly on your phone!</p>
        </div>
      `,
      icon: 'info',
      confirmButtonText: 'Got It'
    });
  }
}

// ==========================================
// AWS COGNITO AUTHENTICATION & CLOUD SYNC UI
// ==========================================

function updateAuthUi(user) {
  const displayAccount = document.getElementById('authDisplayAccount');
  const authHeaderBtnText = document.getElementById('authHeaderBtnText');
  const tabBtnAuthProfile = document.getElementById('tabBtnAuthProfile');
  const profileName = document.getElementById('profileName');
  const profileEmail = document.getElementById('profileEmail');
  const profilePhone = document.getElementById('profilePhone');
  const profileUserId = document.getElementById('profileUserId');
  const profileBackendMode = document.getElementById('profileBackendMode');
  const profileAuthBadge = document.getElementById('profileAuthBadge');
  const settingCognitoSub = document.getElementById('settingCognitoSub');

  if (user && user.email) {
    if (displayAccount) displayAccount.textContent = `${user.email} (${user.phone || '+91 9311155593'})`;
    if (authHeaderBtnText) authHeaderBtnText.textContent = 'Account';
    if (tabBtnAuthProfile) tabBtnAuthProfile.classList.remove('hidden');

    if (profileName) profileName.textContent = user.name || 'Maa Annapurna Admin';
    if (profileEmail) profileEmail.textContent = user.email;
    if (profilePhone) profilePhone.textContent = user.phone || '+91 9311155593';
    if (profileUserId) profileUserId.textContent = user.id || CognitoAuth.getCurrentUserId() || 'cognito-sub-...';
    if (settingCognitoSub) settingCognitoSub.textContent = user.id || CognitoAuth.getCurrentUserId() || 'cognito-sub-...';

    const isAws = AWS_CONFIG.isConfigured();
    if (profileBackendMode) {
      profileBackendMode.textContent = isAws ? 'AWS DynamoDB (Live Connected)' : 'DynamoDB Cloud Store (Sandbox Mode)';
    }
    if (profileAuthBadge) {
      profileAuthBadge.textContent = isAws ? 'AWS Live' : 'Sandbox Active';
      profileAuthBadge.className = isAws ? 'badge-soft-emerald px-2 py-0.5 rounded-full font-bold text-[10px]' : 'badge-soft-purple px-2 py-0.5 rounded-full font-bold text-[10px]';
    }
  } else {
    if (displayAccount) displayAccount.textContent = 'Guest / Sign In';
    if (authHeaderBtnText) authHeaderBtnText.textContent = 'Sign In';
    if (tabBtnAuthProfile) tabBtnAuthProfile.classList.add('hidden');
    if (settingCognitoSub) settingCognitoSub.textContent = 'Not Signed In';
  }

  lucide.createIcons();
}

function openCognitoAuthModal() {
  const modal = document.getElementById('cognitoAuthModal');
  if (!modal) return;
  modal.classList.remove('hidden');

  if (CognitoAuth.isAuthenticated()) {
    switchAuthTab('profile');
    const user = {
      id: CognitoAuth.getCurrentUserId(),
      email: CognitoAuth.getCurrentUserEmail(),
      name: CognitoAuth.getCurrentUserName(),
      phone: localStorage.getItem('cognito_user_phone') || '+91 9311155593'
    };
    updateAuthUi(user);
  } else {
    switchAuthTab('login');
  }
  lucide.createIcons();
}

function closeCognitoAuthModal() {
  const modal = document.getElementById('cognitoAuthModal');
  if (modal) modal.classList.add('hidden');
}

function switchAuthTab(tab) {
  const tabs = ['login', 'signup', 'verify', 'forgot', 'profile'];
  tabs.forEach(t => {
    const btn = document.getElementById('tabBtnAuth' + capitalize(t));
    const panel = document.getElementById('authPanel' + capitalize(t));
    if (btn) {
      if (t === tab) btn.classList.add('active');
      else btn.classList.remove('active');
    }
    if (panel) {
      if (t === tab) panel.classList.remove('hidden');
      else panel.classList.add('hidden');
    }
  });
  lucide.createIcons();
}

async function handleAuthSignIn() {
  const emailInput = document.getElementById('authLoginEmail');
  const passwordInput = document.getElementById('authLoginPassword');

  const email = emailInput?.value.trim();
  const password = passwordInput?.value;

  if (!email || !password) {
    Swal.fire({ icon: 'warning', title: 'Input Required', text: 'Please enter both email and password.' });
    return;
  }

  Swal.fire({
    title: 'Signing In...',
    text: 'Connecting to AWS Cognito...',
    allowOutsideClick: false,
    didOpen: () => Swal.showLoading()
  });

  try {
    const result = await CognitoAuth.signIn(email, password);
    updateAuthUi(result);

    Swal.fire({
      title: 'Loading Your Cloud Data...',
      text: 'Partitioning by Cognito User ID in DynamoDB...',
      allowOutsideClick: false,
      didOpen: () => Swal.showLoading()
    });

    await loadData();

    renderDashboard();
    renderClientList();
    renderPendingList();
    renderPaymentsList();
    renderSettings();
    renderMenuPlanner();
    renderCustomMenusList();
    renderExtraItemsCatalog();

    closeCognitoAuthModal();

    Swal.fire({
      icon: 'success',
      title: 'Logged In Successfully! ☁️',
      text: `Welcome back! Loaded data for ${result.email} from AWS cloud.`,
      timer: 2000,
      showConfirmButton: false
    });
  } catch (err) {
    console.error('Sign In Error:', err);
    Swal.fire({
      icon: 'error',
      title: 'Sign In Failed',
      text: err.message || 'Incorrect credentials or user not found.'
    });
  }
}

async function handleAuthSignUp() {
  const name = document.getElementById('authSignUpName')?.value.trim();
  const phone = document.getElementById('authSignUpPhone')?.value.trim();
  const email = document.getElementById('authSignUpEmail')?.value.trim();
  const password = document.getElementById('authSignUpPassword')?.value;

  if (!name || !phone || !email || !password) {
    Swal.fire({ icon: 'warning', title: 'Missing Information', text: 'Please fill in all registration fields.' });
    return;
  }

  if (password.length < 8) {
    Swal.fire({ icon: 'warning', title: 'Weak Password', text: 'Password must be at least 8 characters long.' });
    return;
  }

  Swal.fire({
    title: 'Registering Account...',
    text: 'Creating user in AWS Cognito User Pool...',
    allowOutsideClick: false,
    didOpen: () => Swal.showLoading()
  });

  try {
    const result = await CognitoAuth.signUp({ name, phone, email, password });
    const verifyEmailInput = document.getElementById('authVerifyEmail');
    if (verifyEmailInput) verifyEmailInput.value = email;

    switchAuthTab('verify');

    const demoNotice = result.mode === 'sandbox' ? '<br><span class="badge-soft-emerald px-2 py-0.5 rounded text-xs mt-2 inline-block font-mono">Sandbox Demo Code: 123456</span>' : '';

    Swal.fire({
      icon: 'info',
      title: 'Verification Code Sent! 📩',
      html: `A 6-digit verification code was dispatched to <b>${email}</b>.${demoNotice}`,
      confirmButtonText: 'Enter Code'
    });
  } catch (err) {
    console.error('Sign Up Error:', err);
    Swal.fire({
      icon: 'error',
      title: 'Registration Error',
      text: err.message || 'Could not register user.'
    });
  }
}

async function handleAuthVerifyOtp() {
  const email = document.getElementById('authVerifyEmail')?.value.trim();
  const code = document.getElementById('authVerifyCode')?.value.trim();

  if (!email || !code) {
    Swal.fire({ icon: 'warning', title: 'Input Required', text: 'Please enter your email and 6-digit verification code.' });
    return;
  }

  Swal.fire({
    title: 'Verifying OTP...',
    text: 'Confirming user with AWS Cognito...',
    allowOutsideClick: false,
    didOpen: () => Swal.showLoading()
  });

  try {
    await CognitoAuth.confirmSignUp(email, code);
    const loginEmailInput = document.getElementById('authLoginEmail');
    if (loginEmailInput) loginEmailInput.value = email;

    switchAuthTab('login');

    Swal.fire({
      icon: 'success',
      title: 'Account Verified! ✅',
      text: 'Your Cognito cloud account is active. Please sign in now.',
      confirmButtonText: 'Sign In'
    });
  } catch (err) {
    console.error('OTP Verification Error:', err);
    Swal.fire({
      icon: 'error',
      title: 'Verification Failed',
      text: err.message || 'Invalid or expired verification code.'
    });
  }
}

async function handleAuthResendCode() {
  const email = document.getElementById('authVerifyEmail')?.value.trim();
  if (!email) {
    Swal.fire({ icon: 'warning', title: 'Email Required', text: 'Please enter your email address to resend the code.' });
    return;
  }

  try {
    const res = await CognitoAuth.resendConfirmationCode(email);
    const demoNotice = res.sandboxDemoCode ? ` (Demo Code: ${res.sandboxDemoCode})` : '';
    Swal.fire({
      icon: 'success',
      title: 'Code Sent',
      text: `A new verification code has been sent to ${email}.${demoNotice}`
    });
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Failed to Resend', text: err.message });
  }
}

async function handleAuthForgotRequest() {
  const email = document.getElementById('authForgotEmail')?.value.trim();
  if (!email) {
    Swal.fire({ icon: 'warning', title: 'Email Required', text: 'Please enter your registered email.' });
    return;
  }

  try {
    const res = await CognitoAuth.forgotPassword(email);
    const demoNotice = res.sandboxDemoCode ? ` (Demo Code: ${res.sandboxDemoCode})` : '';
    Swal.fire({
      icon: 'info',
      title: 'Reset Code Sent',
      text: `A password reset code has been sent to ${email}.${demoNotice}`
    });
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Request Failed', text: err.message });
  }
}

async function handleAuthForgotConfirm() {
  const email = document.getElementById('authForgotEmail')?.value.trim();
  const code = document.getElementById('authForgotCode')?.value.trim();
  const newPassword = document.getElementById('authForgotNewPassword')?.value;

  if (!email || !code || !newPassword) {
    Swal.fire({ icon: 'warning', title: 'Missing Fields', text: 'Please enter your email, reset code, and new password.' });
    return;
  }

  try {
    await CognitoAuth.confirmForgotPassword(email, code, newPassword);
    const loginEmailInput = document.getElementById('authLoginEmail');
    if (loginEmailInput) loginEmailInput.value = email;
    switchAuthTab('login');
    Swal.fire({
      icon: 'success',
      title: 'Password Changed!',
      text: 'You can now sign in with your new password.',
      confirmButtonText: 'Sign In'
    });
  } catch (err) {
    Swal.fire({ icon: 'error', title: 'Password Reset Failed', text: err.message });
  }
}

function handleAuthSignOut() {
  Swal.fire({
    title: 'Sign Out?',
    text: 'You will need to sign in again to sync your cloud data on this device.',
    icon: 'question',
    showCancelButton: true,
    confirmButtonColor: '#ea580c',
    confirmButtonText: 'Sign Out',
    cancelButtonText: 'Cancel'
  }).then((res) => {
    if (res.isConfirmed) {
      CognitoAuth.signOut();
      updateAuthUi(null);
      closeCognitoAuthModal();

      Swal.fire({
        icon: 'success',
        title: 'Signed Out',
        text: 'Session cleared from this device.',
        timer: 1500,
        showConfirmButton: false
      });
    }
  });
}

// ------------------------------------------------------------------------
// AWS CLOUD SETTINGS MODAL HANDLERS
// ------------------------------------------------------------------------
function openAwsConfigModal() {
  const modal = document.getElementById('awsConfigModal');
  if (!modal) return;

  const regionInput = document.getElementById('awsRegionInput');
  const userPoolInput = document.getElementById('awsUserPoolIdInput');
  const clientIdInput = document.getElementById('awsClientIdInput');
  const apiGatewayInput = document.getElementById('awsApiGatewayInput');
  const tableNameInput = document.getElementById('awsTableNameInput');
  const statusLabel = document.getElementById('awsStatusLabel');

  if (regionInput) regionInput.value = AWS_CONFIG.region || 'ap-south-1';
  if (userPoolInput) userPoolInput.value = AWS_CONFIG.userPoolId || '';
  if (clientIdInput) clientIdInput.value = AWS_CONFIG.clientId || '';
  if (apiGatewayInput) apiGatewayInput.value = AWS_CONFIG.apiGatewayUrl || '';
  if (tableNameInput) tableNameInput.value = AWS_CONFIG.tableName || 'TiffinTrackerData';

  if (statusLabel) {
    if (AWS_CONFIG.isConfigured()) {
      statusLabel.textContent = 'Live AWS Connected';
      statusLabel.className = 'badge-soft-emerald px-2 py-0.5 rounded-full text-[10px]';
    } else {
      statusLabel.textContent = 'Sandbox Mode Active';
      statusLabel.className = 'badge-soft-purple px-2 py-0.5 rounded-full text-[10px]';
    }
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeAwsConfigModal() {
  const modal = document.getElementById('awsConfigModal');
  if (modal) modal.classList.add('hidden');
}

async function handleSaveAwsConfig(event) {
  event.preventDefault();

  const region = document.getElementById('awsRegionInput')?.value;
  const userPoolId = document.getElementById('awsUserPoolIdInput')?.value;
  const clientId = document.getElementById('awsClientIdInput')?.value;
  const apiGatewayUrl = document.getElementById('awsApiGatewayInput')?.value;
  const tableName = document.getElementById('awsTableNameInput')?.value;

  const saved = saveAwsConfigToStorage({ region, userPoolId, clientId, apiGatewayUrl, tableName });

  if (saved) {
    closeAwsConfigModal();
    renderSettings();

    Swal.fire({
      icon: 'success',
      title: 'AWS Settings Saved! ☁️',
      text: AWS_CONFIG.isConfigured() ? 'Connected to live AWS Cognito & DynamoDB!' : 'Saved in Sandbox mode.',
      timer: 2000,
      showConfirmButton: false
    });

    if (CognitoAuth.isAuthenticated()) {
      await loadData();
    }
  }
}

function handleResetAwsConfig() {
  resetAwsConfigStorage();
  closeAwsConfigModal();
  renderSettings();
  Swal.fire({
    icon: 'info',
    title: 'Reset to Sandbox',
    text: 'App is running in zero-setup developer Sandbox mode.',
    timer: 1800,
    showConfirmButton: false
  });
}

async function forceManualCloudSync() {
  DynamoClient.updateIndicator('syncing');
  const success = await DynamoClient.saveUserData({
    clients,
    logs,
    boxStates,
    settings,
    weeklyMenu,
    customMenus,
    extraItemsCatalog,
    qrDatabase
  }, true);

    if (success) {
    Swal.fire({
      icon: 'success',
      title: 'Cloud Synced! ☁️',
      text: 'All Maa Annapurna customer records, 6-digit serialized QRs, and box states are saved in the cloud.',
      timer: 1800,
      showConfirmButton: false
    });
  } else {
    Swal.fire({
      icon: 'warning',
      title: 'Sync Offline',
      text: 'Could not connect to cloud API. Data is safely kept in browser session.'
    });
  }
}

// -------------------------------------------------------------------------
// SUPABASE CLOUD SETTINGS MODAL & REACTION HANDLERS
// -------------------------------------------------------------------------
function updateSupabaseUi() {
  const isSupabase = typeof SupabaseClient !== 'undefined' && SupabaseClient.isConfigured();
  
  const settingBadge = document.getElementById('settingSupabaseBadge');
  const settingText = document.getElementById('settingSupabaseStatusText');
  const modalBadge = document.getElementById('supabaseModalStatusBadge');

  if (isSupabase) {
    const projName = SUPABASE_CONFIG.url.replace(/^https:\/\//, '').split('.')[0];
    if (settingBadge) {
      settingBadge.textContent = '⚡ Supabase Live Connected';
      settingBadge.className = 'badge-soft-emerald text-[10px] font-bold px-2 py-0.5 rounded-full';
    }
    if (settingText) {
      settingText.textContent = `🟢 Live Connected (${projName}.supabase.co)`;
      settingText.className = 'font-bold text-emerald-700';
    }
    if (modalBadge) {
      modalBadge.textContent = '🟢 Live Connected';
      modalBadge.className = 'badge-soft-emerald px-2 py-0.5 rounded-full text-[10px] font-bold';
    }
  } else {
    if (settingBadge) {
      settingBadge.textContent = 'Sandbox Mode Active';
      settingBadge.className = 'badge-soft-purple text-[10px] font-bold px-2 py-0.5 rounded-full';
    }
    if (settingText) {
      settingText.textContent = '🟣 Sandbox / Local Session (Not Connected)';
      settingText.className = 'font-bold text-purple-700';
    }
    if (modalBadge) {
      modalBadge.textContent = '🟣 Sandbox Mode';
      modalBadge.className = 'badge-soft-purple px-2 py-0.5 rounded-full text-[10px] font-bold';
    }
  }
}

function openSupabaseConfigModal() {
  const modal = document.getElementById('supabaseConfigModal');
  if (!modal) return;

  const urlInput = document.getElementById('supabaseUrlInput');
  const keyInput = document.getElementById('supabaseAnonKeyInput');
  const tableInput = document.getElementById('supabaseTableInput');

  if (urlInput) urlInput.value = SUPABASE_CONFIG.url || '';
  if (keyInput) keyInput.value = SUPABASE_CONFIG.anonKey || '';
  if (tableInput) tableInput.value = SUPABASE_CONFIG.tableName || 'tiffin_records';

  updateSupabaseUi();
  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeSupabaseConfigModal() {
  const modal = document.getElementById('supabaseConfigModal');
  if (modal) modal.classList.add('hidden');
}

async function handleSaveSupabaseConfig(event) {
  event.preventDefault();

  const url = document.getElementById('supabaseUrlInput')?.value.trim();
  const anonKey = document.getElementById('supabaseAnonKeyInput')?.value.trim();
  const tableName = document.getElementById('supabaseTableInput')?.value.trim();

  if (!url || !anonKey) {
    Swal.fire({ icon: 'warning', title: 'Missing Info', text: 'Supabase Project URL and Anon Key are required.' });
    return;
  }

  const saved = saveSupabaseConfigToStorage({ url, anonKey, tableName });
  if (saved) {
    updateSupabaseUi();
    closeSupabaseConfigModal();

    Swal.fire({
      title: 'Connecting to Supabase...',
      text: 'Testing connection to your PostgreSQL database...',
      allowOutsideClick: false,
      didOpen: () => Swal.showLoading()
    });

    const test = await SupabaseClient.testConnection();

    if (test.success) {
      // Hydrate from Supabase and push current state
      await loadData();
      await SupabaseClient.saveUserData({
        clients, logs, boxStates, settings, weeklyMenu, customMenus, extraItemsCatalog, qrDatabase
      }, true);

      renderSettings();
      renderDashboard();

      Swal.fire({
        icon: 'success',
        title: 'Supabase Connected! ⚡',
        html: `Successfully connected to <b>${url}</b>!<br>All data is synced live to table <code>${SUPABASE_CONFIG.tableName}</code>.`,
        timer: 2500,
        showConfirmButton: false
      });
    } else if (test.tableMissing) {
      Swal.fire({
        icon: 'info',
        title: 'Table Setup Required 📋',
        html: `Connected to Supabase, but table <code>${SUPABASE_CONFIG.tableName}</code> was not found.<br><br>Click below to copy the SQL script, then run it in your <b>Supabase SQL Editor</b>.`,
        confirmButtonText: 'Copy SQL Script',
        showCancelButton: true,
        cancelButtonText: 'I Will Do It Later'
      }).then((res) => {
        if (res.isConfirmed) {
          handleCopySupabaseSql();
        }
      });
    } else {
      Swal.fire({
        icon: 'warning',
        title: 'Connection Notice',
        text: test.error || 'Could not verify Supabase connection. Check your URL and anon key.'
      });
    }
  }
}

async function handleTestSupabaseConnection() {
  const url = document.getElementById('supabaseUrlInput')?.value.trim();
  const anonKey = document.getElementById('supabaseAnonKeyInput')?.value.trim();
  const tableName = document.getElementById('supabaseTableInput')?.value.trim();

  if (!url || !anonKey) {
    Swal.fire({ icon: 'warning', title: 'Enter Credentials First', text: 'Please fill in your Supabase Project URL and Anon Key to test.' });
    return;
  }

  saveSupabaseConfigToStorage({ url, anonKey, tableName });

  Swal.fire({
    title: 'Testing Supabase Connection...',
    allowOutsideClick: false,
    didOpen: () => Swal.showLoading()
  });

  const res = await SupabaseClient.testConnection();
  if (res.success) {
    Swal.fire({ icon: 'success', title: 'Connection Successful! ⚡', text: 'Supabase responded with HTTP 200. Ready to sync!', timer: 2000, showConfirmButton: false });
  } else if (res.tableMissing) {
    Swal.fire({
      icon: 'info',
      title: 'Table Not Created Yet',
      html: `Connection to Supabase works, but table <code>${tableName}</code> is missing.<br>Please copy the SQL Script and run it in Supabase SQL Editor.`,
      confirmButtonText: 'Copy SQL Script'
    }).then(() => handleCopySupabaseSql());
  } else {
    Swal.fire({ icon: 'error', title: 'Connection Failed', text: res.error });
  }
}

function handleCopySupabaseSql() {
  const sql = SupabaseClient.getSqlSetupScript();
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(sql).then(() => {
      Swal.fire({
        icon: 'success',
        title: 'SQL Script Copied! 📋',
        html: `1. Open <a href="https://supabase.com/dashboard" target="_blank" class="text-emerald-700 underline font-bold">Supabase Dashboard</a> &rarr; <b>SQL Editor</b>.<br>2. Paste the script and click <b>RUN</b>.<br>Table <code>${SUPABASE_CONFIG.tableName}</code> will be created in 5 seconds!`,
        confirmButtonText: 'Got It'
      });
    }).catch(() => fallbackCopySql(sql));
  } else {
    fallbackCopySql(sql);
  }

  function fallbackCopySql(str) {
    const t = document.createElement('textarea');
    t.value = str;
    document.body.appendChild(t);
    t.select();
    document.execCommand('copy');
    document.body.removeChild(t);
    Swal.fire({ icon: 'success', title: 'SQL Script Copied! 📋', text: 'Supabase SQL Editor me paste karein.', timer: 1800, showConfirmButton: false });
  }
}

function handleResetSupabaseConfig() {
  resetSupabaseConfigStorage();
  updateSupabaseUi();
  closeSupabaseConfigModal();
  renderSettings();
  Swal.fire({
    icon: 'info',
    title: 'Reset to Sandbox',
    text: 'App is running in zero-setup developer Sandbox mode.',
    timer: 1500,
    showConfirmButton: false
  });
}

// Expose Supabase functions to window
window.openSupabaseConfigModal = openSupabaseConfigModal;
window.closeSupabaseConfigModal = closeSupabaseConfigModal;
window.handleSaveSupabaseConfig = handleSaveSupabaseConfig;
window.handleTestSupabaseConnection = handleTestSupabaseConnection;
window.handleCopySupabaseSql = handleCopySupabaseSql;
window.handleResetSupabaseConfig = handleResetSupabaseConfig;
window.updateSupabaseUi = updateSupabaseUi;
window.openWhatsAppDirect = openWhatsAppDirect;

// Expose QR Labels, Menu Management, Client & Allotment functions
window.generate1InchQrLabels = generate1InchQrLabels;
window.printA4QrLabels = printA4QrLabels;
window.printSpecific1InchSheet = printSpecific1InchSheet;
window.renderMenuList = renderMenuList;
window.openMealModal = openMealModal;
window.closeMealModal = closeMealModal;
window.saveMeal = saveMeal;
window.deleteMeal = deleteMeal;
window.toggleMealStatus = toggleMealStatus;
window.openAllotmentModal = openAllotmentModal;
window.closeAllotmentModal = closeAllotmentModal;
window.filterAllotmentClients = filterAllotmentClients;
window.renderAllotmentClientOptions = renderAllotmentClientOptions;
window.selectAllotmentClient = selectAllotmentClient;
window.clearSelectedAllotmentClient = clearSelectedAllotmentClient;
window.adjustAllotmentQty = adjustAllotmentQty;
window.onAllotmentQtyChange = onAllotmentQtyChange;
window.renderAllotmentBoxSelectors = renderAllotmentBoxSelectors;
window.openScannerFromAllotment = openScannerFromAllotment;
window.onAllotmentMealChange = onAllotmentMealChange;
window.updateAllotmentPriceDisplay = updateAllotmentPriceDisplay;
window.handleAllotmentSubmit = handleAllotmentSubmit;
window.toggleClientSubscriptionFields = toggleClientSubscriptionFields;
window.switchCameraDirection = switchCameraDirection;
window.handleQrFileScan = handleQrFileScan;
window.confirmDeleteQrCode = confirmDeleteQrCode;
window.deleteQrCode = deleteQrCode;




