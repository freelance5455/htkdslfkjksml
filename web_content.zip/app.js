import { getPiper } from "./piper-adapter.js";

const $ = (s) => document.querySelector(s);
const audio = $("#audio");
const statusEl = $("#status");
const progress = $("#progress");
const logEl = $("#log"); // optional, may be absent

let run = 0;
let urls = [];
let chunks = [];
let index = 0;
let paused = false;
let bookChapters = [];

const BOOKMARK_KEY = "vorlese-bookmark-v1";

function saveBookmark() {
  const text = $("#text").value;
  if (!text) return;
  const data = {
    text,
    index,
    voice: $("#voice").value,
    rate: $("#rate").value,
    savedAt: Date.now(),
  };
  localStorage.setItem(BOOKMARK_KEY, JSON.stringify(data));
  setStatus("Lesezeichen gesetzt bei Abschnitt " + (index + 1) + ".");
  log("Bookmark saved at index " + index);
}

function loadBookmark() {
  const raw = localStorage.getItem(BOOKMARK_KEY);
  if (!raw) {
    setStatus("Kein Lesezeichen gespeichert.");
    return;
  }
  try {
    const data = JSON.parse(raw);
    $("#text").value = data.text || "";
    if (data.voice) $("#voice").value = data.voice;
    if (data.rate) {
      $("#rate").value = data.rate;
      $("#rateOut").value = (+data.rate).toFixed(1).replace(".", ",") + "×";
    }
    chunks = split(data.text || "");
    index = Math.min(data.index || 0, Math.max(0, chunks.length - 1));
    progress.value = chunks.length ? (index / chunks.length) * 100 : 0;
    setStatus("Lesezeichen geladen – Abschnitt " + (index + 1) + "/" + chunks.length + ". Drücke Start zum Weiterlesen.");
    log("Bookmark loaded index=" + index);
  } catch (e) {
    setStatus("Lesezeichen konnte nicht geladen werden.");
  }
}



function log(msg) {
  console.log(msg);
  // Debug-Kasten bleibt unsichtbar
}

function setStatus(t) {
  statusEl.textContent = t;
}

const setState = (s) => {
  const busy = s !== "idle";
  $("#start").disabled = busy;
  $("#pause").disabled = !busy;
  $("#stop").disabled = !busy;
  $("#pause").textContent = paused ? "▶ Weiter" : "Ⅱ Pause";
};

function split(t, n = 1400) {
  const a = [];
  t = t.trim().replace(/\r\n/g, "\n").replace(/\s+\n/g, "\n");
  while (t) {
    let c = Math.min(n, t.length);
    if (c < t.length) {
      const p = Math.max(
        t.lastIndexOf(". ", c),
        t.lastIndexOf("! ", c),
        t.lastIndexOf("? ", c),
        t.lastIndexOf("\n", c),
        t.lastIndexOf(" ", c)
      );
      if (p > n * 0.35) c = p + 1;
    }
    a.push(t.slice(0, c).trim());
    t = t.slice(c).trim();
  }
  return a.filter(Boolean);
}

function cleanup() {
  audio.pause();
  audio.removeAttribute("src");
  audio.load();
  audio.hidden = true;
  urls.forEach((u) => URL.revokeObjectURL(u));
  urls = [];
}

function done(msg = "Fertig, mein Schatz.") {
  cleanup();
  paused = false;
  setState("idle");
  progress.value = 100;
  setStatus(msg);
}

function applyRate() {
  const rate = +$("#rate").value;
  audio.playbackRate = rate;
  return rate;
}
function applyVolume() {
  const el = $("#volume");
  if (el) audio.volume = +el.value;
}

function currentVoiceId() {
  const v = $("#voice").value;
  if (v.startsWith("piper:")) return v.slice(6);
  return null;
}

function isPiper() {
  return $("#voice").value.startsWith("piper:");
}

/* ---------- File loaders: TXT / EPUB / PDF ---------- */

function htmlToText(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  doc.querySelectorAll("script, style, nav, header, footer").forEach((n) => n.remove());
  const text = doc.body?.textContent || "";
  return text.replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
}

async function loadJSZip() {
  if (globalThis.JSZip) return globalThis.JSZip;
  await new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js";
    s.onload = resolve;
    s.onerror = () => reject(new Error("JSZip konnte nicht geladen werden"));
    document.head.appendChild(s);
  });
  return globalThis.JSZip;
}

async function readEpub(file) {
  setStatus("EPUB wird gelesen …");
  const JSZip = await loadJSZip();
  const zip = await JSZip.loadAsync(await file.arrayBuffer());

  let opfPath = "content.opf";
  const container = zip.file("META-INF/container.xml");
  if (container) {
    const xml = await container.async("string");
    const m = xml.match(/full-path\s*=\s*["']([^"']+)["']/i);
    if (m) opfPath = m[1];
  }

  const opfFile = zip.file(opfPath);
  if (!opfFile) throw new Error("EPUB: content.opf nicht gefunden");
  const opf = await opfFile.async("string");
  const opfDir = opfPath.includes("/") ? opfPath.replace(/\/[^/]+$/, "/") : "";

  const idToHref = {};
  const idToTitle = {};
  const itemRe = /<item\b[^>]*>/gi;
  let im;
  while ((im = itemRe.exec(opf))) {
    const tag = im[0];
    const id = (tag.match(/\bid\s*=\s*["']([^"']+)["']/i) || [])[1];
    const href = (tag.match(/\bhref\s*=\s*["']([^"']+)["']/i) || [])[1];
    if (id && href) idToHref[id] = href;
  }

  // Nav / NCX titles (best effort)
  const navMap = {}; // href -> title
  try {
    const ncxName = Object.keys(zip.files).find((n) => /\.ncx$/i.test(n) && !zip.files[n].dir);
    if (ncxName) {
      const ncx = await zip.file(ncxName).async("string");
      const navRe = /<navPoint\b[\s\S]*?<\/navPoint>/gi;
      let nm;
      while ((nm = navRe.exec(ncx))) {
        const block = nm[0];
        const label = (block.match(/<text[^>]*>([^<]+)<\/text>/i) || [])[1];
        const src = (block.match(/<content[^>]+src\s*=\s*["']([^"'#]+)/i) || [])[1];
        if (label && src) {
          const base = ncxName.includes("/") ? ncxName.replace(/\/[^/]+$/, "/") : "";
          navMap[(base + src).replace(/^\.\//, "")] = label.trim();
          navMap[src.replace(/^\.\//, "")] = label.trim();
        }
      }
    }
    const navHtml = Object.keys(zip.files).find(
      (n) => /nav\.(x?html?)$/i.test(n) && !zip.files[n].dir
    );
    if (navHtml) {
      const raw = await zip.file(navHtml).async("string");
      const aRe = /<a\b[^>]*href\s*=\s*["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
      let am;
      while ((am = aRe.exec(raw))) {
        const href = am[1].trim();
        const title = am[2].replace(/<[^>]+>/g, "").trim();
        if (href && title) {
          const base = navHtml.includes("/") ? navHtml.replace(/\/[^/]+$/, "/") : "";
          navMap[(base + href).replace(/^\.\//, "")] = title;
          navMap[href.replace(/^\.\//, "")] = title;
        }
      }
    }
  } catch (e) {
    console.warn("Nav parse:", e);
  }

  const spineIds = [];
  const itemrefRe = /<itemref\b[^>]*>/gi;
  let sm;
  while ((sm = itemrefRe.exec(opf))) {
    const idref = (sm[0].match(/\bidref\s*=\s*["']([^"']+)["']/i) || [])[1];
    if (idref) spineIds.push(idref);
  }

  const chapters = [];
  for (let i = 0; i < spineIds.length; i++) {
    const id = spineIds[i];
    const href = idToHref[id];
    if (!href) continue;
    const path = opfDir + href;
    const f = zip.file(path) || zip.file(decodeURIComponent(path));
    if (!f) continue;
    const raw = await f.async("string");
    const t = htmlToText(raw);
    if (!t || t.length < 20) continue;

    let title =
      navMap[path] ||
      navMap[href] ||
      navMap[path.replace(/^\.\//, "")] ||
      null;
    if (!title) {
      const h = raw.match(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/i);
      if (h) title = h[1].replace(/<[^>]+>/g, "").trim();
    }
    if (!title) title = "Kapitel " + (chapters.length + 1);
    if (title.length > 80) title = title.slice(0, 77) + "…";

    chapters.push({ title, text: t });
  }

  if (!chapters.length) {
    const names = Object.keys(zip.files).filter(
      (n) => /\.(x?html?)$/i.test(n) && !zip.files[n].dir
    );
    for (const n of names.sort()) {
      const t = htmlToText(await zip.file(n).async("string"));
      if (t && t.length >= 20) chapters.push({ title: n.split("/").pop(), text: t });
    }
  }

  if (!chapters.length) throw new Error("EPUB enthält keinen lesbaren Text");

  // Global chapter store
  bookChapters = chapters;
  fillChapterSelect();
  return chapters.map((ch) => ch.text).join("\n\n");
}

async function loadPdfJs() {
  if (globalThis.pdfjsLib) return globalThis.pdfjsLib;
  await new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/pdfjs-dist@4.4.168/build/pdf.min.mjs";
    s.type = "module";
    // pdf.js 4 as classic script alternative:
    s.onerror = () => {};
    document.head.appendChild(s);
  }).catch(() => {});

  // Prefer UMD build for simpler loading
  if (!globalThis.pdfjsLib) {
    await new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js";
      s.onload = resolve;
      s.onerror = () => reject(new Error("pdf.js konnte nicht geladen werden"));
      document.head.appendChild(s);
    });
  }
  const lib = globalThis.pdfjsLib;
  lib.GlobalWorkerOptions.workerSrc =
    "https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js";
  return lib;
}

async function readPdf(file) {
  bookChapters = [];
  fillChapterSelect();
  setStatus("PDF wird gelesen …");
  const pdfjsLib = await loadPdfJs();
  const data = new Uint8Array(await file.arrayBuffer());
  const doc = await pdfjsLib.getDocument({ data }).promise;
  const parts = [];
  for (let i = 1; i <= doc.numPages; i++) {
    setStatus(`PDF Seite ${i} von ${doc.numPages} …`);
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const line = content.items.map((it) => it.str).join(" ");
    if (line.trim()) parts.push(line.trim());
  }
  const text = parts.join("\n\n").trim();
  if (!text) throw new Error("PDF enthält keinen extrahierbaren Text (evtl. nur Bilder/Scan)");
  return text;
}


function fillChapterSelect() {
  const wrap = $("#chapterWrap");
  const sel = $("#chapter");
  if (!wrap || !sel) return;
  sel.innerHTML = "";
  if (!bookChapters.length) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  bookChapters.forEach((ch, i) => {
    sel.add(new Option(ch.title, String(i)));
  });
  sel.onchange = () => {
    const i = +sel.value;
    if (!bookChapters[i]) return;
    // Text ab gewähltem Kapitel bis Ende
    const from = bookChapters.slice(i).map((c) => c.text).join("\n\n");
    $("#text").value = from;
    setStatus("Kapitel: " + bookChapters[i].title + " – bereit zum Vorlesen.");
    progress.value = 0;
  };
  // Show full book by default
  $("#text").value = bookChapters.map((c) => c.text).join("\n\n");
}

async function readFile(file) {
  const name = (file.name || "").toLowerCase();
  const type = (file.type || "").toLowerCase();

  if (name.endsWith(".epub") || type.includes("epub")) {
    return readEpub(file);
  }
  if (name.endsWith(".pdf") || type === "application/pdf") {
    return readPdf(file);
  }
  // TXT / plain
  bookChapters = [];
  fillChapterSelect();
  return file.text();
}

/* ---------- Playback ---------- */

async function playPiper(myRun) {
  const voiceId = currentVoiceId();
  setStatus("Lade Stimme …");
  log("getPiper() …");
  const piper = await getPiper();
  if (myRun !== run) return;
  log("Piper bereit, Stimme: " + voiceId);

  // Prefetch-Puffer: nächsten Abschnitt schon erzeugen, während der aktuelle spielt
  let nextBlobPromise = null;

  async function synthesize(i) {
    setStatus(`Erzeuge Abschnitt ${i + 1}/${chunks.length} …`);
    log(`predict #${i + 1}: ${chunks[i].slice(0, 50)}…`);
    const blob = await piper.predict(
      { text: chunks[i], voiceId },
      (p) => {
        if (p?.total) {
          const pct = Math.round((p.loaded * 100) / p.total);
          setStatus(`Modell-Download: ${pct} % (${Math.round(p.loaded / 1e6)} / ${Math.round(p.total / 1e6)} MB)`);
        }
      }
    );
    if (!blob || !(blob instanceof Blob) || blob.size < 100) {
      throw new Error("Leerer Audio-Blob (size=" + (blob?.size ?? 0) + ")");
    }
    return blob;
  }

  async function playIndex(i) {
    if (myRun !== run) return;
    if (i >= chunks.length) return done();

    index = i;
    progress.value = (i / chunks.length) * 100;

    let blob;
    try {
      if (nextBlobPromise) {
        blob = await nextBlobPromise;
        nextBlobPromise = null;
        if (!blob) blob = await synthesize(i);
      } else {
        blob = await synthesize(i);
      }
    } catch (e) {
      log("predict Fehler: " + (e?.message || e));
      throw e;
    }
    if (myRun !== run) return;

    // Sofort nächsten Abschnitt im Hintergrund starten
    if (i + 1 < chunks.length) {
      nextBlobPromise = synthesize(i + 1).catch((e) => {
        log("prefetch Fehler: " + (e?.message || e));
        return null;
      });
    }

    const u = URL.createObjectURL(blob);
    urls.push(u);
    audio.src = u;
    audio.hidden = false;
    applyRate();
    applyVolume();

    await new Promise((resolve, reject) => {
      audio.onended = () => resolve();
      audio.onerror = () => reject(new Error("Audio konnte nicht abgespielt werden"));
      audio.play().catch(reject);
    });

    if (myRun !== run) return;
    setStatus(`Liest Abschnitt ${i + 1}/${chunks.length} …`);
    await playIndex(i + 1);
  }

  setStatus(`Liest Abschnitt ${index + 1}/${chunks.length} …`);
  await playIndex(index);
}

function deviceSpeak(myRun) {
  const synth = speechSynthesis;
  function next() {
    if (myRun !== run) return;
    if (index >= chunks.length) return done();

    const u = new SpeechSynthesisUtterance(chunks[index]);
    const val = $("#voice").value;
    if (val.startsWith("device:")) {
      const name = val.slice(7);
      u.voice = synth.getVoices().find((v) => v.name === name) || null;
    }
    u.lang = u.voice?.lang || "de-DE";
    u.rate = +$("#rate").value;

    u.onend = () => {
      index++;
      progress.value = (index / chunks.length) * 100;
      next();
    };
    u.onerror = (e) => fail(new Error(e.error || "Gerätestimme fehlgeschlagen"));

    synth.speak(u);
    setStatus(`Liest Abschnitt ${index + 1}/${chunks.length} …`);
  }
  next();
}

function fail(e) {
  console.error(e);
  const msg = e?.message || String(e);
  log("FAIL: " + msg);

  // Nach Phonem-Fix sollten OrtRun-Fehler selten sein.
  // Falls doch: diesen Abschnitt überspringen und weiterlesen (nur Piper).
  if (isPiper() && (msg.includes("OrtRun") || msg.includes("out of data bounds") || msg.includes("Gather"))) {
    log("Abschnitt übersprungen, versuche nächsten …");
    index++;
    progress.value = chunks.length ? (index / chunks.length) * 100 : 0;
    if (index < chunks.length) {
      setStatus("Ein Abschnitt war problematisch – lese weiter …");
      playPiper(run).catch(fail);
      return;
    }
  }
  done("Fehler: " + msg);
}


async function start() {
  const text = $("#text").value.trim();
  if (!text) {
    setStatus("Bitte ein Buch öffnen oder Text einfügen, mein Schatz.");
    return;
  }
  if (logEl) logEl.textContent = "";
  if (logEl) logEl.hidden = true;
  run++;
  cleanup();
  // Größere Abschnitte bei Gerätestimme = weniger abgehackt
  const chunkSize = isPiper() ? 1400 : 2500;
  chunks = split(text, chunkSize);
  index = 0;
  progress.value = 0;
  paused = false;
  setState("playing");
  log("Start: " + chunks.length + " Abschnitte, Stimme=" + $("#voice").value);
  try {
    if (isPiper()) await playPiper(run);
    else deviceSpeak(run);
  } catch (e) {
    fail(e);
  }
}

function stop() {
  run++;
  speechSynthesis.cancel();
  done("Angehalten.");
  progress.value = 0;
}

function pause() {
  if (isPiper()) {
    if (audio.paused) {
      applyRate();
      audio.play();
      paused = false;
      setStatus("Weiter geht’s …");
    } else {
      audio.pause();
      paused = true;
      setStatus("Pausiert.");
    }
  } else {
    if (speechSynthesis.paused) {
      speechSynthesis.resume();
      paused = false;
      setStatus("Weiter geht’s …");
    } else {
      speechSynthesis.pause();
      paused = true;
      setStatus("Pausiert.");
    }
  }
  setState("playing");
}

function voices() {
  // Nur Piper – keine Gerätestimmen (Wunsch)
  const cur = $("#voice").value;
  if ([...$("#voice").options].some((o) => o.value === cur)) {
    $("#voice").value = cur;
  }
}

async function diagnose() {
  /* log hidden */
  if (logEl) logEl.textContent = "=== Diagnose ===\n";
  log("Browser: " + navigator.userAgent.slice(0, 120));
  log("crossOriginIsolated: " + self.crossOriginIsolated);

  const testUrl = "/piper-model/de/de_DE/thorsten/medium/de_DE-thorsten-medium.onnx.json";
  log("Proxy-Test: " + testUrl);
  try {
    const t0 = performance.now();
    const res = await fetch(testUrl, { cache: "no-store" });
    const ms = Math.round(performance.now() - t0);
    log(`HTTP ${res.status} (${ms} ms), CT=${res.headers.get("content-type") || ""}`);
    if (!res.ok) {
      log("Body: " + (await res.text()).slice(0, 160));
      log("Netlify-Proxy 404 → CORS-Fallback wird genutzt");
    } else {
      const json = await res.json();
      log("JSON OK sample_rate=" + json?.audio?.sample_rate);
    }
  } catch (e) {
    log("Proxy-Fehler: " + e.message);
  }

  try {
    log("Lade Piper …");
    const piper = await getPiper();
    log("Piper OK: " + Object.keys(piper).slice(0, 10).join(", "));
    setStatus("Diagnose fertig – siehe Log. Piper-Modul ist geladen.");
  } catch (e) {
    log("Piper-Fehler: " + e.message);
    setStatus("Piper-Modul Fehler – nutze eine Gerät-Stimme.");
  }
}

voices();
speechSynthesis.onvoiceschanged = voices;

$("#start").onclick = start;
$("#stop").onclick = stop;
$("#pause").onclick = pause;
$("#diagnose").onclick = saveBookmark;
$("#loadmark").onclick = loadBookmark;

if (localStorage.getItem(BOOKMARK_KEY)) {
  setStatus("Lesezeichen vorhanden – tippe auf ↩ Weiterlesen.");
}


$("#rate").oninput = (e) => {
  $("#rateOut").value = (+e.target.value).toFixed(1).replace(".", ",") + "×";
  if (isPiper() && !audio.paused) applyRate();
};
$("#volume") && ($("#volume").oninput = (e) => {
  const v = +e.target.value;
  $("#volOut").value = Math.round(v * 100) + " %";
  audio.volume = v;
});


function startFromCaret() {
  const ta = $("#text");
  const full = ta.value || "";
  if (!full.trim()) {
    setStatus("Kein Text vorhanden.");
    return;
  }
  let pos = typeof ta.selectionStart === "number" ? ta.selectionStart : 0;
  // Wenn nichts markiert, Cursor-Position; sonst Anfang der Markierung
  if (ta.selectionEnd > ta.selectionStart) pos = ta.selectionStart;

  let start = pos;
  // Zum Satzanfang zurück (oder Zeilenanfang)
  while (start > 0 && !/[.!?\n]/.test(full[start - 1])) start--;
  while (start < full.length && /\s/.test(full[start])) start++;

  const fromHere = full.slice(start).trim();
  if (!fromHere) {
    setStatus("Keine Textstelle ab hier.");
    return;
  }

  run++;
  cleanup();
  const before = full.slice(0, start);
  const chunkSize = isPiper() ? 1400 : 2500;
  const beforeChunks = split(before, chunkSize);
  chunks = split(full, chunkSize);
  index = Math.min(beforeChunks.length, Math.max(0, chunks.length - 1));
  // Wenn before genau an Chunk-Grenze endet, ok; sonst ggf. einen zurück
  progress.value = chunks.length ? (index / chunks.length) * 100 : 0;
  paused = false;
  setState("playing");
  setStatus("Weiter ab gewählter Stelle (Abschnitt " + (index + 1) + ") …");
  (async () => {
    try {
      if (isPiper()) await playPiper(run);
      else deviceSpeak(run);
    } catch (e) {
      fail(e);
    }
  })();
}

$("#text").ondblclick = startFromCaret;
$("#fromHere") && ($("#fromHere").onclick = startFromCaret);


$("#file").onchange = async (e) => {
  const f = e.target.files?.[0];
  if (!f) return;
  try {
    setStatus(`Lade „${f.name}“ …`);
    const text = await readFile(f);
    $("#text").value = text;
    setStatus(`„${f.name}“ geladen (${text.length.toLocaleString("de-DE")} Zeichen). Bereit zum Vorlesen.`);
  } catch (err) {
    console.error(err);
    setStatus("Datei konnte nicht gelesen werden: " + (err?.message || err));
  }
};

setState("idle");

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () =>
    navigator.serviceWorker.register("./sw.js").catch((err) => console.warn("SW:", err))
  );
}
