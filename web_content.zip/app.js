const prayers=[
  {name:"الفجر",time:"05:12",icon:"🌙"},
  {name:"الشروق",time:"06:42",icon:"🌅"},
  {name:"الظهر",time:"13:18",icon:"☀️"},
  {name:"العصر",time:"16:48",icon:"🌤️"},
  {name:"المغرب",time:"19:54",icon:"🌇"},
  {name:"العشاء",time:"21:24",icon:"🌃"}
];

const $=id=>document.getElementById(id);
function renderPrayers(){
  $("prayers").innerHTML=prayers.map((p,i)=>`<div class="prayer" id="p${i}"><div class="emoji">${p.icon}</div><b>${p.name}</b><small>${p.time}</small></div>`).join("");
}
function getNext(){
  const now=new Date(), mins=now.getHours()*60+now.getMinutes()+now.getSeconds()/60;
  for(let i=0;i<prayers.length;i++){
    const [h,m]=prayers[i].time.split(":").map(Number), t=h*60+m;
    if(t>mins) return {i,t,remain:(t-mins)*60};
  }
  return {i:0,t:prayers[0].time.split(":").map(Number).reduce((a,v,i)=>a+v*[60,1][i],0)+1440,remain:(1440-mins+311)*60};
}
function update(){
  const n=getNext();
  document.querySelectorAll(".prayer").forEach(x=>x.classList.remove("active"));
  $("p"+n.i).classList.add("active");
  $("nextPrayer").textContent=prayers[n.i].name;
  let s=Math.max(0,Math.floor(n.remain)), h=Math.floor(s/3600), m=Math.floor((s%3600)/60), sec=s%60;
  $("countdown").textContent=`بعد ${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
  $("progressBar").style.width=Math.min(100,100-(n.remain/7200*100))+"%";
}
function dateText(){
 const d=new Date();
 $("dateText").textContent=d.toLocaleDateString("ar",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
}
function locationText(){
 if(!navigator.geolocation){$("locationText").textContent="الموقع غير متاح";return}
 navigator.geolocation.getCurrentPosition(
  pos=>$("locationText").textContent=`${pos.coords.latitude.toFixed(2)}°، ${pos.coords.longitude.toFixed(2)}°`,
  ()=>$("locationText").textContent="الموقع اليدوي"
 );
}
function showFeature(name){
 $("modalTitle").textContent=name;
 const bodies={
  "القبلة":"🧭<p>في النسخة القادمة سيتم تفعيل بوصلة القبلة باستخدام مستشعر الهاتف وحساب الاتجاه إلى مكة.</p>",
  "الأذكار":"📿<p>أذكار الصباح والمساء وبعد الصلاة، مع عدّاد تكرار وحفظ التقدم.</p>",
  "القرآن":"📖<p>قارئ قرآن، بحث، علامات مرجعية، وآخر موضع قراءة.</p>",
  "التنبيهات":"🔔<p>تنبيهات قبل الصلاة وأذان عند دخول الوقت، مع إعدادات مستقلة لكل صلاة.</p>",
  "المزيد":"⚙️<p>الإعدادات، طريقة الحساب، المذهب، اللغة، والمظهر.</p>"
 };
 $("modalBody").innerHTML=bodies[name]||"<p>قريبًا.</p>";
 $("modal").classList.remove("hidden");
}
function closeModal(){$("modal").classList.add("hidden")}
$("themeBtn").onclick=()=>document.body.classList.toggle("dark");
$("refreshBtn").onclick=()=>{locationText();update()};
renderPrayers();dateText();locationText();update();setInterval(update,1000);
