const categories = [
  ["Lokomotywy elektryczne","Lokomotywy zasilane napięciem elektrycznym."],
  ["Elektryczne zespoły trakcyjne","Elektryczne zespoły trakcyjne."],
  ["Lokomotywy spalinowe","Lokomotywy napędzane silnikiem spalinowym."],
  ["Spalinowe zespoły trakcyjne","Spalinowe zespoły trakcyjne."],
  ["Pojazdy dwutrakcyjne","Pojazdy wykorzystujące dwa rodzaje napędu."],
  ["Drezyny, pojazdy robocze","Drezyny, pojazdy robocze i specjalne."],
  ["Lokomotywy parowe","Lokomotywy napędzane siłą pary."],
  ["Wagon motorowy","Wagony silnikowe."]
];
let photos = JSON.parse(localStorage.getItem("ilostan_photos") || "[]");

const $ = s => document.querySelector(s);
const categoriesEl = $("#categories"), select = $("#category"), gallery = $("#gallery");

categories.forEach(([name,desc])=>{
  const opt=document.createElement("option"); opt.value=name; opt.textContent=name; select.appendChild(opt);
  const row=document.createElement("div"); row.className="cat";
  row.innerHTML=`<div class="cat-name">${name}<small>${desc}</small></div><div class="count" data-cat="${name}">0</div><button class="dark" data-filter="${name}">Otwórz</button>`;
  categoriesEl.appendChild(row);
});
function save(){localStorage.setItem("ilostan_photos",JSON.stringify(photos)); render();}
function render(){
  $("#photoCount").textContent=photos.length;
  document.querySelectorAll("[data-cat]").forEach(el=>el.textContent=photos.filter(p=>p.category===el.dataset.cat).length);
  const q=$("#search").value.trim().toLowerCase();
  const list=photos.filter(p=>[p.number,p.series,p.railway,p.place,p.category,p.description].join(" ").toLowerCase().includes(q));
  gallery.innerHTML="";
  if(!list.length){gallery.innerHTML=`<div class="empty">${photos.length?"Brak wyników wyszukiwania.":"Nie dodano jeszcze żadnych zdjęć."}</div>`;return;}
  list.slice().reverse().forEach(p=>{
    const card=document.createElement("article");card.className="card";
    card.innerHTML=`<img src="${p.image}" alt="${esc(p.number)}"><div class="card-body">
      <h3>${esc(p.number)}</h3>
      <div class="meta">${esc(p.series||"Brak serii")} · ${esc(p.category)}<br>${esc(p.railway||"Brak linii")} · ${esc(p.place||"Brak miejsca")} · ${esc(p.date||"Brak daty")}</div>
      ${p.description?`<div class="desc">${esc(p.description)}</div>`:""}
      <div class="card-actions"><button class="dark" data-view="${p.id}">Pokaż zdjęcie</button><button class="delete" data-delete="${p.id}">Usuń</button></div>
    </div>`;
    gallery.appendChild(card);
  });
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

$("#photo").addEventListener("change",e=>{
  const f=e.target.files[0]; if(!f)return;
  const r=new FileReader(); r.onload=()=>$("#preview").innerHTML=`<img src="${r.result}" alt="Podgląd">`; r.readAsDataURL(f);
});
$("#photoForm").addEventListener("submit",e=>{
  e.preventDefault(); const f=$("#photo").files[0]; if(!f)return;
  const r=new FileReader(); r.onload=()=>{
    photos.push({id:Date.now().toString(),image:r.result,description:$("#description").value,railway:$("#railway").value,number:$("#number").value,series:$("#series").value,category:$("#category").value,place:$("#place").value,date:$("#date").value});
    save(); e.target.reset(); $("#preview").textContent="Podgląd zdjęcia pojawi się tutaj";
  }; r.readAsDataURL(f);
});
$("#search").addEventListener("input",render);
categoriesEl.addEventListener("click",e=>{if(e.target.dataset.filter){$("#search").value=e.target.dataset.filter;render();window.scrollTo({top:document.body.scrollHeight,behavior:"smooth"});}});
gallery.addEventListener("click",e=>{
  const id=e.target.dataset.view||e.target.dataset.delete;if(!id)return;
  if(e.target.dataset.view){const p=photos.find(x=>x.id===id);const w=window.open();w.document.write(`<title>${esc(p.number)}</title><body style="margin:0;background:#000;display:grid;place-items:center"><img src="${p.image}" style="max-width:100%;max-height:100vh"></body>`);}
  if(e.target.dataset.delete && confirm("Usunąć to zdjęcie?")){photos=photos.filter(p=>p.id!==id);save();}
});
$("#resetForm").addEventListener("click",()=>setTimeout(()=>$("#preview").textContent="Podgląd zdjęcia pojawi się tutaj",0));
$("#clearAll").addEventListener("click",()=>{if(confirm("Usunąć wszystkie zapisane pojazdy i zdjęcia?")){photos=[];save();}});
$("#exportData").addEventListener("click",()=>{
  const blob=new Blob([JSON.stringify(photos)],{type:"application/json"}),a=document.createElement("a");
  a.href=URL.createObjectURL(blob);a.download="ilostan-kopia.json";a.click();URL.revokeObjectURL(a.href);
});
$("#importData").addEventListener("change",e=>{
  const f=e.target.files[0];if(!f)return;const r=new FileReader();
  r.onload=()=>{try{const x=JSON.parse(r.result);if(!Array.isArray(x))throw 0;photos=x;save();alert("Kopia została wczytana.");}catch{alert("Nieprawidłowy plik kopii.");}};
  r.readAsText(f);
});
render();