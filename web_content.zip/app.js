const feed=document.getElementById('feed');
const videoSources=[
 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
 'https://storage.googleapis.com/coverr-main/mp4/Mt_Baker.mp4',
 'https://storage.googleapis.com/coverr-main/mp4/Footboys.mp4'
];
const users=['glinkuser','zeynep_34','alperen_06','melissx','kaan.58','deniz.06','esmaaa'];
const captions=['Bağlantıların yeni adresi ✨','Harika bir gün! ❤️','Bu manzara çok güzel 😍','Yeni videom sizlerle!','Gece başka bir dünya... 🌙'];
// 1000 feed records are generated locally from sample video sources.
// Replace these with real uploaded media after Firebase Storage is connected.
const items=Array.from({length:1000},(_,i)=>({
  src:videoSources[i%videoSources.length],
  user:users[i%users.length],
  caption:captions[i%captions.length],
  likes:(1200+i*37).toLocaleString('tr-TR'),
  comments:(12+i%800).toString()
}));
items.forEach((x,i)=>{
 const card=document.createElement('article'); card.className='card';
 card.innerHTML=`<video src="${x.src}" playsinline loop muted preload="metadata"></video>
 <div class="shade"></div><div class="info"><div class="user">@${x.user}</div><div class="caption">${x.caption}</div><div class="music">♫ Original Ses</div></div>
 <div class="actions"><button class="like">♡</button><span>${x.likes}</span><button class="comment">💬</button><span>${x.comments}</span><button>↗</button><span>Paylaş</span></div>`;
 const v=card.querySelector('video');
 card.addEventListener('click',e=>{if(e.target===v){v.paused?v.play():v.pause()}});
 card.querySelector('.like').onclick=()=>{const b=card.querySelector('.like');b.textContent=b.textContent==='♡'?'♥':'♡'};
 card.querySelector('.comment').onclick=()=>openMessages();
 feed.appendChild(card);
});
const observer=new IntersectionObserver(es=>es.forEach(e=>{
 const v=e.target.querySelector('video'); if(e.isIntersecting){v.play().catch(()=>{})} else v.pause();
}),{threshold:.7});
document.querySelectorAll('.card').forEach(c=>observer.observe(c));

function openMessages(){document.getElementById('messages').classList.remove('hidden');renderChats()}
function renderChats(){
 const list=document.getElementById('chatList');
 const chats=JSON.parse(localStorage.getItem('glink_chats')||'[]');
 list.innerHTML=['Mert','Zeynep','Emre','Selin','Arda','Melisa'].map((n,i)=>`<div class="chat"><b>${n}</b><p>${chats[i]||'Mesajlaşmaya başla...'}</p></div>`).join('');
}
document.getElementById('messagesBtn').onclick=openMessages;
document.getElementById('closeMessages').onclick=()=>document.getElementById('messages').classList.add('hidden');
document.getElementById('sendMsg').onclick=()=>{
 const inp=document.getElementById('msgInput'); if(!inp.value.trim())return;
 const chats=JSON.parse(localStorage.getItem('glink_chats')||'[]'); chats[0]=inp.value.trim(); localStorage.setItem('glink_chats',JSON.stringify(chats)); inp.value=''; renderChats();
};
document.getElementById('uploadBtn').onclick=()=>alert('Gerçek video yükleme için Firebase Storage bağlantısı gerekiyor.');
document.getElementById('searchBtn').onclick=()=>alert('Arama ekranı: Firebase bağlantısı yapıldığında gerçek kullanıcı ve içerik araması açılacak.');
