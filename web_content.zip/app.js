const baseQuotes=[
"Comece pequeno, mas comece com coragem.",
"Você não precisa ter tudo resolvido para dar o próximo passo.",
"Um dia difícil não define a sua história.",
"Faça hoje algo pelo qual o seu eu de amanhã agradecerá.",
"Persistência transforma passos pequenos em grandes conquistas.",
"Confie no processo e continue avançando.",
"Seu esforço de hoje constrói oportunidades para amanhã.",
"Não espere a motivação chegar: dê o primeiro passo.",
"Há força em continuar mesmo quando ninguém está vendo.",
"Cada manhã é uma nova oportunidade de recomeçar.",
"Você é capaz de aprender aquilo que ainda não sabe.",
"Quando o caminho mudar, adapte os passos, não o propósito.",
"Tenha paciência com o seu crescimento.",
"Grandes mudanças começam com decisões simples.",
"Não compare capítulos diferentes da vida.",
"Faça o melhor que puder com o dia que recebeu.",
"A constância vale mais do que a pressa.",
"Seu futuro é construído nas escolhas que você faz agora.",
"Erros podem virar aprendizado quando você decide continuar.",
"Um passo de cada vez também é progresso.",
"Cuide dos seus sonhos com a mesma dedicação que você dá aos seus planos.",
"Não deixe um momento ruim convencer você de que tudo está perdido.",
"Coragem também é tentar de novo.",
"Acredite na possibilidade de um começo melhor.",
"Hoje pode ser o dia em que uma pequena atitude muda muita coisa.",
"Valorize cada avanço, mesmo aquele que parece pequeno.",
"Você não precisa ser perfeito para fazer algo incrível.",
"Continue: às vezes, a próxima tentativa é a que abre o caminho.",
"Tenha fé no amanhã e atitude no hoje.",
"Seu ritmo é seu; o importante é não parar de crescer."
];

let quotes=JSON.parse(localStorage.getItem("frasesPlusQuotes")||"null")||[...baseQuotes];
let favorites=JSON.parse(localStorage.getItem("frasesPlusFavorites")||"[]");
let currentIndex=-1;

const $=id=>document.getElementById(id);
function save(){localStorage.setItem("frasesPlusQuotes",JSON.stringify(quotes));localStorage.setItem("frasesPlusFavorites",JSON.stringify(favorites))}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2300)}
function showQuote(i){currentIndex=i;$("quote").textContent=quotes[i];$("quoteNumber").textContent=`Frase ${i+1} de ${quotes.length}`;updateFavoriteButton()}
function randomQuote(){if(quotes.length<2)return showQuote(0);let i;do{i=Math.floor(Math.random()*quotes.length)}while(i===currentIndex);showQuote(i)}
function updateFavoriteButton(){if(currentIndex<0)return;$("favoriteBtn").textContent=favorites.includes(quotes[currentIndex])?"★ Favoritada":"☆ Favoritar"}
function renderFavorites(){const box=$("favorites");$("favoriteCount").textContent=favorites.length;if(!favorites.length){box.innerHTML='<div class="empty">Você ainda não favoritou nenhuma frase.</div>';return}box.innerHTML=favorites.map((q,i)=>`<div class="fav"><p>${escapeHtml(q)}</p><button onclick="removeFavorite(${i})">✕</button></div>`).join("")}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function removeFavorite(i){favorites.splice(i,1);save();renderFavorites();updateFavoriteButton();toast("Frase removida dos favoritos.")}
$("randomBtn").onclick=randomQuote;
$("favoriteBtn").onclick=()=>{if(currentIndex<0)return toast("Sorteie uma frase primeiro.");const q=quotes[currentIndex];const i=favorites.indexOf(q);if(i>=0){favorites.splice(i,1);toast("Removida dos favoritos.")}else{favorites.push(q);toast("Adicionada aos favoritos ⭐")}save();renderFavorites();updateFavoriteButton()};
function speak(text){if(!("speechSynthesis" in window))return toast("A narração não é suportada neste navegador.");speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang="pt-BR";u.rate=.92;speechSynthesis.speak(u)}
$("speakBtn").onclick=()=>currentIndex>=0&&speak(quotes[currentIndex]);
$("addBtn").onclick=()=>{const v=$("newQuote").value.trim();if(!v)return toast("Digite uma frase primeiro.");quotes.push(v);$("newQuote").value="";save();showQuote(quotes.length-1);toast("Sua frase foi adicionada! ✨")};
$("customSpeakBtn").onclick=()=>{const v=$("newQuote").value.trim();if(v)speak(v);else toast("Digite uma frase para ouvir.")};

function next0500(){const now=new Date(), next=new Date(now);next.setHours(5,30,0,0);if(now>=next)next.setDate(next.getDate()+1);return next}
function updateCountdown(){const enabled=localStorage.getItem("frasesPlusMorning")==="1";if(!enabled){$("countdown").textContent="05:30:00";$("morningStatus").textContent="Ative para receber uma frase às 05:30.";return}const diff=next0500()-new Date();let s=Math.max(0,Math.floor(diff/1000));const h=String(Math.floor(s/3600)).padStart(2,"0");s%=3600;const m=String(Math.floor(s/60)).padStart(2,"0");const sec=String(s%60).padStart(2,"0");$("countdown").textContent=`${h}:${m}:${sec}`;$("morningStatus").textContent="Frase das 05:30 ativada.";if(diff<=1000)morningAlert()}
let lastMorning="";
function morningAlert(){const day=new Date().toDateString();if(lastMorning===day)return;lastMorning=day;randomQuote();const q=quotes[currentIndex];if(Notification.permission==="granted"){
  try{
    new Notification("✨ Frases+",{body:q,silent:true,tag:"frases-plus-manha",renotify:false});
  }catch(e){}
}}
$("morningToggle").checked=localStorage.getItem("frasesPlusMorning")==="1";
$("morningToggle").onchange=async e=>{if(e.target.checked){if("Notification"in window&&Notification.permission==="default")await Notification.requestPermission();localStorage.setItem("frasesPlusMorning","1");toast("Frase das 05:30 ativada.")}else{localStorage.setItem("frasesPlusMorning","0");toast("Frase das 05:00 cancelada.")}updateCountdown()};
$("cancelBtn").onclick=()=>{$("morningToggle").checked=false;localStorage.setItem("frasesPlusMorning","0");updateCountdown();toast("A frase das 05:30 foi cancelada.")};
setInterval(updateCountdown,1000);
showQuote(Math.floor(Math.random()*quotes.length));renderFavorites();updateCountdown();
