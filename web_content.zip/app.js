import { hasFirebaseConfig, initializeFirebase } from './firebase-client.js';
import { LedgerStore } from './ledger-store.js';
import { localDateKey, currentMonthRange, pakistanDateOptions } from './date-utils.js';
import { registerAndroidBackHandler, saveOrShareFile, shareOrPrintStatement, signInWithNativeAuth } from './native-adapters.js';

const $ = selector => document.querySelector(selector);
const esc = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[character]));
const money = value => `Rs ${Number(value || 0).toLocaleString('en-PK', { maximumFractionDigits: 2 })}`;
const createId = () => globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
const chargeTypes = new Set(['tractor', 'motor', 'spray', 'fertilizer', 'motorBill', 'solar', 'wapda']);
const store = new LedgerStore();
const filters = currentMonthRange();
const initialPage = location.hash.slice(1) || 'home';
let page = initialPage === 'entry' ? 'home' : initialPage;
let editingEntryId = null;
let editingCustomerId = null;
let editingWorkerId = null;
let lastDeleted = null;
let language = localStorage.getItem('kmt-lang') || 'en';
let cloudAuth = null;
let authSdk = null;
let routeDepth = 0;
let cloudStarting = false;
let cloudStatusTranslation = null;
let entryModalOpen = initialPage === 'entry';
let entryModalReturnPage = page === 'entry' ? 'home' : page;
let reportFilters = { farmerId: '', workerId: '' };

const words = {
  en: {
    app: 'Kisan Motor & Tractor Ledger', tag: 'Simple • Offline • Your Khata',
    namePlaceholder: 'e.g., Ahmed Khan', noCustomers: 'No farmers yet.',
    noEntries: 'No entries yet.', noRecords: 'No records found for this date range.',
    noWorkers: 'No workers yet.', closingBalance: 'Closing balance',
    address: 'Address / remarks', balance: 'Balance', selectOption: 'Select…',
    worker: 'Worker', debit: 'Debit', credit: 'Credit', recentlyDeleted: 'Recently deleted',
    cloudCollectionFailed: 'Cloud sync failed. Local changes are safe.',
    cloudSettingsFailed: 'Cloud settings sync failed. Local changes are safe.',
    cloudMigrationFailed: 'Legacy cloud migration failed. Check the connection and retry.',
    cloudMigrationDone: 'Legacy cloud ledger migrated to real-time collections.',
    signedInAs: 'Signed in as',
    deleteConfirm: 'Delete this entry?', deletedMessage: 'Entry deleted. It can be restored.',
    restoreConfirm: 'Restore replaces the local ledger. Continue?',
    invalidBackup: 'The backup does not contain valid ledger collections.',
    restoreFailed: 'Restore failed', enterName: 'Enter a name.',
    enterDetails: 'Enter work details.', validAmount: 'Enter a valid non-negative amount.',
    invalidDateRange: 'The start date must be before the end date.',
    cloudSetup: 'Firebase setup required. Local ledger is available.',
    firebaseNotConnected: 'Firebase is not connected.',
    cloudMissing: 'Setup required: configure Firebase. Local data remains available.',
    cloudOffline: 'Offline — local ledger active. Cloud sync will start when online.',
    cloudInitFailed: 'Firebase could not load. Local ledger is available; retry when online.',
    cloudCacheMemory: 'Persistent offline cache is unavailable; using temporary cache.',
    signedOutOffline: 'Offline — local ledger active.',
    cloudSyncActive: 'Cloud sync active', cloudQueued: 'Offline — changes queued safely',
    signInFailed: 'Sign-in failed', signOutFailed: 'Sign-out failed',
    signIn: 'Sign in with Google', signOut: 'Sign out',
    signOutLocal: 'Signed out — local ledger active.',
    cloudConnect: 'Connecting real-time cloud sync…',
    cloudSaveError: 'Cloud sync delayed — local changes remain queued.',
    onlineSync: 'Online — syncing queued changes…',
    offlineSaved: 'Offline — changes are saved on this device.',
    home: 'Home', customers: 'Farmers', farmer: 'Farmer', entry: 'New Entry', workers: 'Workers',
    reports: 'Reports', settings: 'Settings', dashboard: 'Dashboard',
    save: 'Save', cancel: 'Cancel', name: 'Name', mobile: 'Mobile',
    opening: 'Opening balance', customer: 'Farmer', type: 'Entry type',
    date: 'Date', detail: 'Details', quantity: 'Quantity / hours / units',
    rate: 'Rate (Rs)', amount: 'Amount (Rs)', notes: 'Notes',
    due: 'Farmer balance due', payable: 'Worker payable', charges: 'Work charges',
    cash: 'Cash received', from: 'From', to: 'To', apply: 'Apply dates',
    addCustomer: 'Add farmer', addWorker: 'Add worker', recent: 'Recent entries',
    statement: 'Statement', edit: 'Edit', delete: 'Delete', undo: 'Undo delete',
    print: 'Print / Share statement', export: 'Export', backup: 'Export Backup',
    restore: 'Restore Backup', tractor: 'Tractor work', motor: 'Field work',
    solar: 'Solar', wapda: 'WAPDA', motorBill: 'Motor Bill', fieldWork: 'Field work',
    customCategory: 'New / Custom Category', customCategoryPrompt: 'Enter a name for the new category:',
    categoryName: 'Category name', addCategory: 'Add category',
    categoryExists: 'That category already exists.', spray: 'Spraying', fertilizer: 'Fertilizer',
    adjust: 'Labor adjustment',
    workerWage: 'Worker wage', workerPayment: 'Worker payment', method: 'Wage method',
    daily: 'Daily', monthly: 'Monthly', salary: 'Monthly salary',
    noCustomer: 'Add a farmer before recording an entry.',
    duplicateName: 'A record with this name already exists.',
    deleteFarmerConfirm: 'Delete this farmer? Existing ledger entries will be retained.',
    deleteWorkerConfirm: 'Delete this worker? Existing attendance and payments will be retained.',
    deletedRecord: 'Record deleted. You can undo this action.',
    reportFarmer: 'Farmer filter', reportWorker: 'Worker filter', allRecords: 'All records',
    attendance: 'Attendance', attendanceStatus: 'Attendance status',
    present: 'Present', halfDay: 'Half-day', shortDay: 'Short-day', absent: 'Absent',
    attendancePay: 'Attendance pay', payment: 'Worker payment',
    initialRate: 'Initial rate / salary', close: 'Close',
    motorBillSource: 'Motor bill source', attendanceSaved: 'Attendance saved.'
  },
  roman: {
    app: 'Kisan Motor & Tractor Ledger', tag: 'Simple • Offline • Aap ka Khata',
    namePlaceholder: 'Misal: Ahmed Khan', noCustomers: 'Abhi koi kisaan nahi.',
    noEntries: 'Abhi koi entry nahi.', noRecords: 'Is tareekh mein koi record nahi mila.',
    noWorkers: 'Abhi koi worker nahi.', closingBalance: 'Aakhri baqaya',
    address: 'Pata / remarks', balance: 'Baqaya', selectOption: 'Select karein…',
    worker: 'Mazdoor', debit: 'Jama', credit: 'Wasooli', recentlyDeleted: 'Haliya delete entries',
    cloudCollectionFailed: 'Cloud sync nakaam. Local changes mehfooz hain.',
    cloudSettingsFailed: 'Cloud settings sync nakaam. Local changes mehfooz hain.',
    cloudMigrationFailed: 'Purana cloud ledger migrate nahi hua. Connection check karein.',
    cloudMigrationDone: 'Purana cloud ledger real-time collections mein migrate ho gaya.',
    signedInAs: 'Sign in:',
    deleteConfirm: 'Yeh entry delete karein?', deletedMessage: 'Entry delete ho gayi. Wapas ki ja sakti hai.',
    restoreConfirm: 'Restore se local ledger replace hoga. Continue?', invalidBackup: 'Backup mein ledger data durust nahi.',
    restoreFailed: 'Restore nakaam', enterName: 'Naam likhein.', enterDetails: 'Kaam ki tafseel likhein.',
    validAmount: 'Durust zero ya us se zyada raqam likhein.',
    invalidDateRange: 'Shuru ki tareekh aakhri tareekh se pehle honi chahiye.',
    cloudSetup: 'Firebase setup darkar hai. Local ledger available hai.',
    firebaseNotConnected: 'Firebase connected nahi hai.',
    cloudMissing: 'Firebase configure karein. Local data available hai.',
    cloudOffline: 'Offline — cloud sync online honay par shuru hogi.',
    cloudInitFailed: 'Firebase load nahi hua. Local ledger available hai.',
    cloudCacheMemory: 'Persistent offline cache available nahi; temporary cache istemal ho raha hai.',
    signedOutOffline: 'Offline — local ledger active.',
    cloudSyncActive: 'Cloud sync active', cloudQueued: 'Offline — changes queue mein mehfooz hain',
    signInFailed: 'Sign in nakaam', signOutFailed: 'Sign out nakaam',
    signIn: 'Google se sign in', signOut: 'Sign out',
    signOutLocal: 'Sign out — local ledger active.',
    cloudConnect: 'Real-time cloud sync se rabta ho raha hai…',
    cloudSaveError: 'Cloud sync ruk gayi — local changes queue mein hain.',
    onlineSync: 'Online — queued changes sync ho rahi hain…',
    offlineSaved: 'Offline — changes device par save hain.',
    home: 'Home', customers: 'Kisaan', farmer: 'Kisaan', entry: 'Nayi Entry', workers: 'Mazdoor',
    reports: 'Reports', settings: 'Settings', dashboard: 'Khulasa',
    save: 'Save Karein', cancel: 'Cancel', name: 'Poora naam', mobile: 'Mobile',
    opening: 'Shuru ka baqaya', customer: 'Kisaan', type: 'Entry ki qisam',
    date: 'Tareekh', detail: 'Tafseel', quantity: 'Quantity / ghantay / units',
    rate: 'Rate (Rs)', amount: 'Raqam (Rs)', notes: 'Mazeed tafseel',
    due: 'Kisaan ka baqaya', payable: 'Mazdoor payable', charges: 'Kaam ki raqam',
    cash: 'Wasool cash', from: 'Shuru', to: 'Aakhir', apply: 'Tareekh lagayen',
    addCustomer: 'Kisaan add karein', addWorker: 'Mazdoor add karein',
    recent: 'Haliya entries', statement: 'Khata', edit: 'Tabdeel', delete: 'Delete',
    undo: 'Wapas karein', print: 'Print / Share khata', export: 'Export',
    backup: 'Backup download', restore: 'Backup restore',
    tractor: 'Tractor ka kaam', motor: 'Field work', solar: 'Solar', wapda: 'WAPDA',
    motorBill: 'Motor Bill', fieldWork: 'Field work', customCategory: 'Nayi / custom category',
    customCategoryPrompt: 'Nayi category ka naam likhein:', categoryExists: 'Yeh category pehle se mojood hai.',
    categoryName: 'Category ka naam', addCategory: 'Category add karein',
    spray: 'Spray', fertilizer: 'Khaad', adjust: 'Mazdoori adjustment',
    workerWage: 'Mazdoor dihari', workerPayment: 'Mazdoor payment',
    method: 'Tankhwa ka tareeqa', daily: 'Rozana', monthly: 'Mahawarana',
    salary: 'Mahawarana tankhwa',     noCustomer: 'Entry se pehle kisaan add karein.',
    duplicateName: 'Is naam ka record pehle se mojood hai.',
    deleteFarmerConfirm: 'Kya is kisaan ko delete karna hai? Purani ledger entries mehfooz rahengi.',
    deleteWorkerConfirm: 'Kya is worker ko delete karna hai? Purani hazri aur payments mehfooz rahengi.',
    deletedRecord: 'Record delete ho gaya. Aap isay wapas la sakte hain.',
    reportFarmer: 'Kisaan filter', reportWorker: 'Mazdoor filter', allRecords: 'Tamam records',
    attendance: 'Hazri', attendanceStatus: 'Hazri ki halat',
    present: 'Hazir', halfDay: 'Aadhi dihari', shortDay: 'Do tihai dihari', absent: 'Ghair hazir',
    attendancePay: 'Hazri ki ujrat', payment: 'Mazdoor payment',
    initialRate: 'Ibtidai rate / tankhwa', close: 'Band karein',
    motorBillSource: 'Motor bill ka zariya', attendanceSaved: 'Hazri save ho gayi.'
  },
  ur: {
    app: 'کسان موٹر اینڈ ٹریکٹر کھاتہ', tag: 'آسان • آف لائن • آپ کا کھاتہ',
    namePlaceholder: 'مثال: احمد خان', noCustomers: 'ابھی تک کوئی کسان موجود نہیں ہے۔',
    noEntries: 'ابھی تک کوئی اندراج موجود نہیں ہے۔',
    noRecords: 'اس تاریخ کی حد میں کوئی ریکارڈ نہیں ملا۔',
    noWorkers: 'ابھی تک کوئی ورکر موجود نہیں ہے۔', closingBalance: 'اختتامی بقایا',
    address: 'پتہ / تفصیل', balance: 'بقایا', selectOption: 'منتخب کریں…',
    worker: 'ورکر', debit: 'جمع', credit: 'وصولی', recentlyDeleted: 'حال ہی میں حذف شدہ',
    cloudCollectionFailed: 'کلاؤڈ سنک ناکام۔ مقامی تبدیلیاں محفوظ ہیں۔',
    cloudSettingsFailed: 'کلاؤڈ ترتیبات سنک ناکام۔ مقامی تبدیلیاں محفوظ ہیں۔',
    cloudMigrationFailed: 'پرانا کلاؤڈ کھاتہ منتقل نہیں ہوا۔ انٹرنیٹ چیک کرکے دوبارہ کوشش کریں۔',
    cloudMigrationDone: 'پرانا کلاؤڈ کھاتہ ریئل ٹائم کلیکشنز میں منتقل ہوگیا۔',
    signedInAs: 'سائن اِن:',
    deleteConfirm: 'کیا یہ اندراج حذف کریں؟',
    deletedMessage: 'اندراج حذف ہوگیا۔ اسے واپس بحال کیا جاسکتا ہے۔',
    restoreConfirm: 'بحالی سے مقامی کھاتہ تبدیل ہوگا۔ کیا جاری رکھیں؟',
    invalidBackup: 'بیک اپ میں کھاتے کا درست ڈیٹا موجود نہیں۔',
    restoreFailed: 'بحالی ناکام', enterName: 'نام درج کریں۔',
    enterDetails: 'کام کی تفصیل درج کریں۔',
    validAmount: 'صفر یا اس سے زیادہ درست رقم درج کریں۔',
    invalidDateRange: 'شروع کی تاریخ آخری تاریخ سے پہلے ہونی چاہیے۔',
    cloudSetup: 'فائر بیس سیٹ اپ درکار ہے۔ مقامی کھاتہ دستیاب ہے۔',
    firebaseNotConnected: 'فائر بیس منسلک نہیں ہے۔',
    cloudMissing: 'فائر بیس ترتیب دیں۔ مقامی ڈیٹا دستیاب ہے۔',
    cloudOffline: 'آف لائن — انٹرنیٹ ملنے پر کلاؤڈ سنک شروع ہوگی۔',
    cloudInitFailed: 'فائر بیس لوڈ نہیں ہوا۔ مقامی کھاتہ دستیاب ہے۔',
    cloudCacheMemory: 'مستقل آف لائن کیش دستیاب نہیں؛ عارضی کیش استعمال ہو رہی ہے۔',
    signedOutOffline: 'آف لائن — مقامی کھاتہ فعال ہے۔',
    cloudSyncActive: 'کلاؤڈ سنک فعال ہے',
    cloudQueued: 'آف لائن — تبدیلیاں محفوظ قطار میں ہیں',
    signInFailed: 'سائن اِن ناکام', signOutFailed: 'سائن آؤٹ ناکام',
    signIn: 'گوگل سے سائن اِن', signOut: 'سائن آؤٹ',
    signOutLocal: 'سائن آؤٹ — مقامی کھاتہ فعال ہے۔',
    cloudConnect: 'ریئل ٹائم کلاؤڈ سنک سے رابطہ ہو رہا ہے…',
    cloudSaveError: 'کلاؤڈ سنک میں تاخیر — مقامی تبدیلیاں قطار میں محفوظ ہیں۔',
    onlineSync: 'آن لائن — محفوظ تبدیلیاں سنک ہو رہی ہیں…',
    offlineSaved: 'آف لائن — تبدیلیاں اس ڈیوائس پر محفوظ ہیں۔',
    home: 'ہوم', customers: 'کسان', farmer: 'کسان', entry: 'نئی انٹری',
    workers: 'ورکرز', reports: 'رپورٹس', settings: 'ترتیبات',
    dashboard: 'خلاصہ', save: 'محفوظ کریں', cancel: 'منسوخ',
    name: 'پورا نام', mobile: 'موبائل', opening: 'ابتدائی بقایا',
    customer: 'کسان', type: 'اندراج کی قسم', date: 'تاریخ',
    detail: 'تفصیل', quantity: 'مقدار / گھنٹے / یونٹس',
    rate: 'ریٹ (روپے)', amount: 'رقم (روپے)', notes: 'مزید تفصیل',
    due: 'کسان کا بقایا', payable: 'مزدور کی رقم', charges: 'کام کی رقم',
    cash: 'وصول نقد', from: 'شروع', to: 'اختتام', apply: 'تاریخیں لگائیں',
    addCustomer: 'کسان شامل کریں', addWorker: 'ورکر شامل کریں',
    recent: 'حالیہ اندراجات', statement: 'کھاتہ', edit: 'ترمیم',
    delete: 'حذف', undo: 'واپس کریں', print: 'کھاتہ پرنٹ / شیئر',
    export: 'ایکسپورٹ', backup: 'بیک اپ برآمد کریں',
    restore: 'بیک اپ بحال کریں', tractor: 'ٹریکٹر کا کام',
    motor: 'فیلڈ ورک', solar: 'سولر', wapda: 'واپڈا', motorBill: 'موٹر بل',
    fieldWork: 'فیلڈ ورک', customCategory: 'نئی / حسب ضرورت کیٹیگری',
    customCategoryPrompt: 'نئی کیٹیگری کا نام درج کریں:', categoryExists: 'یہ کیٹیگری پہلے سے موجود ہے۔',
    categoryName: 'کیٹیگری کا نام', addCategory: 'کیٹیگری شامل کریں',
    spray: 'اسپرے', fertilizer: 'کھاد',
    adjust: 'مزدوری ایڈجسٹمنٹ', workerWage: 'مزدور اجرت',
    workerPayment: 'مزدور ادائیگی', method: 'اجرت کا طریقہ',
    daily: 'روزانہ', monthly: 'ماہانہ', salary: 'ماہانہ تنخواہ',
    noCustomer: 'اندراج سے پہلے کسان شامل کریں۔',
    duplicateName: 'اس نام کا ریکارڈ پہلے سے موجود ہے۔',
    deleteFarmerConfirm: 'کیا اس کسان کو حذف کرنا ہے؟ پرانے کھاتے کے اندراج محفوظ رہیں گے۔',
    deleteWorkerConfirm: 'کیا اس ورکر کو حذف کرنا ہے؟ پرانی حاضری اور ادائیگیاں محفوظ رہیں گی۔',
    deletedRecord: 'ریکارڈ حذف ہوگیا۔ آپ اسے واپس بحال کرسکتے ہیں۔',
    reportFarmer: 'کسان فلٹر', reportWorker: 'ورکر فلٹر', allRecords: 'تمام ریکارڈ',
    attendance: 'حاضری', attendanceStatus: 'حاضری کی کیفیت',
    present: 'حاضر', halfDay: 'آدھا دن', shortDay: 'دو تہائی دن', absent: 'غیر حاضر',
    attendancePay: 'حاضری کی اجرت', payment: 'ورکر کی ادائیگی',
    initialRate: 'ابتدائی ریٹ / تنخواہ', close: 'بند کریں',
    motorBillSource: 'موٹر بل کا ذریعہ', attendanceSaved: 'حاضری محفوظ ہوگئی۔'
  }
};
const t = key => words[language]?.[key] || words.en[key] || key;
let data = store.snapshot;

function records(kind) {
  return data[kind].filter(record => !record.deleted);
}

function customerBalance(customer) {
  return Number(customer.opening || 0) + records('entries')
    .filter(entry => entry.customerId === customer.id)
    .reduce((total, entry) => total + (['cash', 'adjust'].includes(entry.type) ? -Number(entry.amount || 0) : isChargeType(entry) ? Number(entry.amount || 0) : 0), 0);
}

function workerBalance(worker) {
  return Number(worker.opening || 0) + records('entries')
    .filter(entry => entry.workerId === worker.id)
    .reduce((total, entry) => total + (entry.type === 'workerPayment' ? -Number(entry.amount || 0) : ['workerWage', 'attendance'].includes(entry.type) ? Number(entry.amount || 0) : 0), 0);
}

function isChargeType(entry) {
  return chargeTypes.has(entry.type) || entry.type.startsWith('custom-');
}

function categoryLabel(type) {
  const category = data.settings.customCategories?.find(item => `custom-${item.id}` === type);
  return category?.name || t(type);
}

function entryTypeLabel(entry) {
  if (entry.type === 'solar' || entry.type === 'wapda') return `${t('motorBill')} · ${t(entry.type)}`;
  if (entry.type === 'attendance') return t('attendance');
  return categoryLabel(entry.type);
}

function attendanceFactor(status) {
  return ({ present: 1, halfDay: 0.5, shortDay: 2 / 3, absent: 0 })[status] ?? 0;
}

function attendanceAmount(worker, date, status) {
  const rate = Number(worker?.salary || 0);
  const [year, month] = date.split('-').map(Number);
  const daysInMonth = new Date(year, month, 0).getDate();
  const dailyRate = worker?.method === 'monthly' ? rate / daysInMonth : rate;
  return Math.round(dailyRate * attendanceFactor(status) * 100) / 100;
}

function filteredEntries() {
  return records('entries').filter(entry =>
    (!filters.from || entry.date >= filters.from) && (!filters.to || entry.date <= filters.to)
  ).sort((a, b) => b.date.localeCompare(a.date));
}

function navigate(next, replace = false) {
  if (next === 'entry') {
    if (entryModalOpen) return;
    entryModalReturnPage = page;
    entryModalOpen = true;
    routeDepth += 1;
    history.pushState({ page: 'entry', returnPage: entryModalReturnPage, modal: true, depth: routeDepth }, '', '#entry');
    render(true);
    return;
  }
  if (entryModalOpen) {
    entryModalOpen = false;
    page = next;
    history.replaceState({ page, depth: routeDepth }, '', `#${encodeURIComponent(next)}`);
    render(true);
    return;
  }
  if (next === page && !replace) return;
  page = next;
  const url = `#${encodeURIComponent(next)}`;
  if (!replace) {
    routeDepth += 1;
    history.pushState({ page, depth: routeDepth }, '', url);
  } else history.replaceState({ page, depth: routeDepth }, '', url);
  render(true);
}

function closeEntryModalRoute() {
  if (!entryModalOpen) return;
  if (routeDepth > 0) {
    history.back();
    return;
  }
  entryModalOpen = false;
  page = entryModalReturnPage || 'home';
  history.replaceState({ page, depth: 0 }, '', `#${encodeURIComponent(page)}`);
  render(true);
}

function filterControls() {
  return `<div class="card" style="margin:12px 0"><div class="row">
    <div class="field"><label>${t('from')}</label><input type="date" id="filterFrom" value="${esc(filters.from)}"></div>
    <div class="field"><label>${t('to')}</label><input type="date" id="filterTo" value="${esc(filters.to)}"></div>
    </div><button class="btn" id="applyFilters">${t('apply')}</button></div>`;
}

function entryRows(entries, includeCustomer = false) {
  if (!entries.length) {
    const message = records('entries').length ? t('noRecords') : t('noEntries');
    return `<div class="empty">${message}</div>`;
  }
  return `<div class="list">${entries.map(entry => {
    const customer = records('customers').find(item => item.id === entry.customerId);
    const worker = records('workers').find(item => item.id === entry.workerId);
    const defaultPaymentDetails = [words.en.payment, words.roman.payment, words.ur.payment, words.en.workerPayment, words.roman.workerPayment, words.ur.workerPayment];
    const detail = entry.type === 'attendance'
      ? t(entry.status)
      : entry.type === 'workerPayment' && defaultPaymentDetails.includes(entry.detail)
        ? ''
        : entry.detail;
    const metadata = [entry.date, detail, entryTypeLabel(entry), includeCustomer && customer ? customer.name : ''].filter(Boolean).map(esc).join(' · ');
    return `<div class="item"><div class="avatar">${entry.workerId ? '⚒' : entry.type === 'cash' ? '₨' : '🚜'}</div>
      <div class="itemmain"><div class="itemtitle">${esc(worker?.name || customer?.name || '—')}</div>
      <div class="itemmeta">${metadata}</div></div>
      <div class="amount">${money(entry.amount)}<div class="actions">
      <button class="btn secondary small" data-edit-entry="${esc(entry.id)}">${t('edit')}</button>
      <button class="btn danger small" data-delete-entry="${esc(entry.id)}">${t('delete')}</button></div></div></div>`;
  }).join('')}</div>`;
}

function summaryCards(entries) {
  const chargeTotal = entries.filter(isChargeType).reduce((total, entry) => total + Number(entry.amount || 0), 0);
  const sum = type => entries.filter(entry => entry.type === type).reduce((total, entry) => total + Number(entry.amount || 0), 0);
  return `<div class="stats"><div class="stat green"><div class="label">${t('charges')}</div><div class="num">${money(chargeTotal)}</div></div>
    <div class="stat"><div class="label">${t('cash')}</div><div class="num">${money(sum('cash'))}</div></div>
    <div class="stat orange"><div class="label">${t('due')}</div><div class="num">${money(records('customers').reduce((total, customer) => total + customerBalance(customer), 0))}</div></div>
    <div class="stat"><div class="label">${t('payable')}</div><div class="num">${money(records('workers').reduce((total, worker) => total + Math.max(0, workerBalance(worker)), 0))}</div></div></div>`;
}

function homePage() {
  const entries = filteredEntries();
  return `<div class="title">${t('dashboard')}</div>${filterControls()}${summaryCards(entries)}
    <div class="quick" style="margin-top:12px"><button data-nav="customers">👥 ${t('customers')}</button><button data-nav="entry">＋ ${t('entry')}</button>
    <button data-nav="workers">⚒ ${t('workers')}</button><button data-nav="settings">⚙ ${t('settings')}</button></div>
    <div class="section">${t('recent')} <button class="btn secondary small" data-nav="reports">${t('reports')}</button></div>
    ${entryRows(entries.slice(0, 8), true)}`;
}

function customersPage() {
  const customer = records('customers').find(item => item.id === editingCustomerId);
  return `<div class="title">${t('customers')}</div><div class="card"><form id="customerForm" novalidate>
    <div class="field"><label>${t('name')} *</label><input name="name" required maxlength="120" data-placeholder="namePlaceholder" placeholder="${t('namePlaceholder')}" value="${esc(customer?.name || '')}"></div>
    <div class="row"><div class="field"><label>${t('mobile')}</label><input name="mobile" inputmode="tel" maxlength="40" value="${esc(customer?.mobile || '')}"></div>
    <div class="field"><label>${t('opening')} (Rs)</label><input name="opening" type="number" min="0" step=".01" value="${esc(customer?.opening ?? 0)}"></div></div>
    <div class="field"><label>${t('address')}</label><input name="address" maxlength="300" value="${esc(customer?.address || '')}"></div>
    <div class="actions"><button class="btn">${t('save')}</button>${customer ? `<button type="button" class="btn secondary" data-cancel-customer>${t('cancel')}</button>` : ''}</div>
    </form></div><div class="list">${records('customers').map(item => `<div class="item"><div class="avatar">${esc(item.name.slice(0, 1))}</div>
      <div class="itemmain"><div class="itemtitle">${esc(item.name)}</div><div class="itemmeta">${esc(item.mobile || '')} · ${t('balance')} ${money(customerBalance(item))}</div></div>
      <div class="actions"><button class="btn secondary small" data-ledger="${esc(item.id)}">${t('statement')}</button>
      <button class="btn secondary small" data-edit-customer="${esc(item.id)}">${t('edit')}</button>
      <button class="btn danger small" data-delete-customer="${esc(item.id)}">${t('delete')}</button></div></div>`).join('') || `<div class="empty">${t('noCustomers')}</div>`}</div>`;
}

function entryPage(showTitle = true) {
  const current = records('entries').find(item => item.id === editingEntryId);
  if (!current?.workerId && !records('customers').length) return `<div class="notice">${t('noCustomer')} <button class="btn small" data-nav="customers">${t('addCustomer')}</button></div>`;
  const selectedEntryType = current?.type === 'solar' || current?.type === 'wapda' ? 'motorBill' : current?.type || 'tractor';
  const customTypes = (data.settings.customCategories || []).map(category => `custom-${category.id}`);
  const options = current?.workerId
    ? `<option value="workerPayment" ${current.type === 'workerPayment' ? 'selected' : ''}>${t('workerPayment')}</option>
      <option value="attendance" ${current.type === 'attendance' ? 'selected' : ''}>${t('attendance')}</option>
      ${current.type === 'workerWage' ? `<option value="workerWage" selected>${t('workerWage')}</option>` : ''}`
    : `<option value="tractor" ${selectedEntryType === 'tractor' ? 'selected' : ''}>${t('tractor')}</option>
      <option value="motor" ${selectedEntryType === 'motor' ? 'selected' : ''}>${t('fieldWork')}</option>
    <option value="spray" ${selectedEntryType === 'spray' ? 'selected' : ''}>${t('spray')}</option>
    <option value="fertilizer" ${selectedEntryType === 'fertilizer' ? 'selected' : ''}>${t('fertilizer')}</option>
      <option value="motorBill" ${selectedEntryType === 'motorBill' ? 'selected' : ''}>${t('motorBill')}</option>
      <option value="cash" ${selectedEntryType === 'cash' ? 'selected' : ''}>${t('cash')}</option>
      <option value="adjust" ${selectedEntryType === 'adjust' ? 'selected' : ''}>${t('adjust')}</option>
      ${customTypes.map(type => `<option value="${esc(type)}" ${selectedEntryType === type ? 'selected' : ''}>${esc(categoryLabel(type))}</option>`).join('')}`
    ;
  const source = current?.type === 'solar' || current?.type === 'wapda' ? current.type : current?.billSource || 'solar';
  return `${showTitle ? `<div class="title">${current ? `${t('edit')} ${t('entry')}` : t('entry')}</div>` : ''}<div class="card"><form id="entryForm">
    <div class="field"><label>${current?.workerId ? t('worker') : t('customer')} *</label>
      <select name="${current?.workerId ? 'workerId' : 'customerId'}" required>
      <option value="">${t('selectOption')}</option>${(current?.workerId ? records('workers') : records('customers')).map(person => `<option value="${esc(person.id)}" ${person.id === (current?.workerId || current?.customerId) ? 'selected' : ''}>${esc(person.name)}</option>`).join('')}</select></div>
    <div class="field"><label>${t('type')}</label><select name="type" id="entryType">${options}</select></div>
    <div class="field ${selectedEntryType === 'motorBill' ? '' : 'hidden'}" id="motorBillFields"><label>${t('motorBillSource')}</label>
      <select name="billSource" id="billSource"><option value="solar" ${source === 'solar' ? 'selected' : ''}>${t('solar')}</option><option value="wapda" ${source === 'wapda' ? 'selected' : ''}>${t('wapda')}</option></select></div>
    ${!current?.workerId ? `<button type="button" class="btn secondary small" id="addCategory">${t('customCategory')}</button>
      <div class="row hidden" id="newCategoryFields"><div class="field"><label>${t('categoryName')}</label><input id="newCategoryName" name="categoryName" maxlength="80"></div>
      <div class="field"><label>&nbsp;</label><button type="button" class="btn" id="saveCategory">${t('addCategory')}</button></div></div>` : ''}
    <div class="field"><label>${t('date')}</label><input type="date" name="date" id="entryDate" required value="${esc(current?.date || localDateKey())}"></div>
    ${current?.workerId ? `<div class="field ${current.type === 'attendance' ? '' : 'hidden'}" id="editAttendanceFields"><label>${t('attendanceStatus')}</label><select name="status" id="editAttendanceStatus">
      ${['present', 'halfDay', 'shortDay', 'absent'].map(status => `<option value="${status}" ${current.status === status ? 'selected' : ''}>${t(status)}</option>`).join('')}</select></div>` : ''}
    <div class="field" id="entryDetailField"><label>${t('detail')} *</label><input name="detail" required maxlength="240" value="${esc(current?.detail || '')}"></div>
    <div class="row" id="quantityFields"><div class="field"><label>${t('quantity')}</label><input id="quantity" name="qty" type="number" min="0" step=".01" value="${esc(current?.qty ?? 1)}"></div>
    <div class="field"><label>${t('rate')}</label><input id="rate" name="rate" type="number" min="0" step=".01" value="${esc(current?.rate ?? rateFor(current?.type || 'tractor', source))}"></div></div>
    <div class="field" id="entryAmountField"><label>${t('amount')} *</label><input id="amount" name="amount" type="number" min="0" step=".01" required value="${esc(current?.amount ?? '')}"></div>
    <div class="actions"><button class="btn">${t('save')}</button>${current ? `<button type="button" class="btn secondary" data-cancel-entry>${t('cancel')}</button>` : ''}</div>
    </form></div>`;
}

function entryModalMarkup() {
  return `<div class="kmt-entry-modal" id="entryModal"><section class="kmt-entry-dialog" role="dialog" aria-modal="true" aria-labelledby="entryModalTitle">
    <div class="section"><span id="entryModalTitle">${editingEntryId ? `${t('edit')} ${t('entry')}` : t('entry')}</span>
    <button type="button" class="btn secondary small" id="closeEntryModal">${t('close')}</button></div>${entryPage(false)}</section></div>`;
}

function rateFor(type, billSource = 'solar') {
  if (type === 'motorBill') return Number(data.settings[`${billSource}Rate`] || 0);
  if (['motor', 'spray', 'fertilizer'].includes(type)) return Number(data.settings.motorRate || 0);
  const category = data.settings.customCategories?.find(item => `custom-${item.id}` === type);
  return Number(category?.rate ?? data.settings[`${type}Rate`] ?? 0);
}

function workersPage() {
  const worker = records('workers').find(item => item.id === editingWorkerId);
  return `<div class="title">${t('workers')}</div><div class="card"><form id="workerForm">
    <div class="field"><label>${t('name')} *</label><input name="name" required maxlength="120" data-placeholder="namePlaceholder" placeholder="${t('namePlaceholder')}" value="${esc(worker?.name || '')}"></div>
    <div class="row"><div class="field"><label>${t('mobile')}</label><input name="mobile" maxlength="40" value="${esc(worker?.mobile || '')}"></div>
    <div class="field"><label>${t('opening')} (Rs)</label><input name="opening" type="number" min="0" step=".01" value="${esc(worker?.opening ?? 0)}"></div></div>
    <div class="field"><label>${t('method')}</label><select name="method"><option value="daily" ${worker?.method !== 'monthly' ? 'selected' : ''}>${t('daily')}</option><option value="monthly" ${worker?.method === 'monthly' ? 'selected' : ''}>${t('monthly')}</option></select></div>
    <div class="field"><label>${t('initialRate')} (Rs)</label><input name="salary" type="number" min="0" step=".01" value="${esc(worker?.salary ?? 0)}"></div>
    <div class="actions"><button class="btn">${t('save')}</button>${worker ? `<button type="button" class="btn secondary" data-cancel-worker>${t('cancel')}</button>` : ''}</div></form></div>
    <div class="section">${t('workers')}</div><div class="list">${records('workers').map(item => `<div class="item"><div class="avatar">⚒</div><div class="itemmain">
    <div class="itemtitle">${esc(item.name)}</div><div class="itemmeta">${esc(item.mobile || '')} · ${t(item.method || 'daily')} · ${money(workerBalance(item))}</div></div>
    <div class="actions"><button class="btn secondary small" data-edit-worker="${esc(item.id)}">${t('edit')}</button>
    <button class="btn danger small" data-delete-worker="${esc(item.id)}">${t('delete')}</button></div></div>`).join('') || `<div class="empty">${t('noWorkers')}</div>`}</div>
    <div class="section">${t('attendance')}</div><div class="card"><form id="attendanceForm">
    <div class="field"><label>${t('worker')} *</label><select name="workerId" required><option value="">${t('selectOption')}</option>${records('workers').map(item => `<option value="${esc(item.id)}">${esc(item.name)}</option>`).join('')}</select></div>
    <div class="field"><label>${t('date')}</label><input name="date" id="attendanceDate" type="date" value="${localDateKey()}" required></div>
    <div class="field"><label>${t('attendanceStatus')}</label><select name="status" id="attendanceStatus"><option value="present">${t('present')}</option><option value="halfDay">${t('halfDay')}</option><option value="shortDay">${t('shortDay')}</option><option value="absent">${t('absent')}</option></select></div>
    <div class="muted" id="attendancePreview">${t('attendancePay')}: ${money(0)}</div>
    <button class="btn full">${t('save')}</button></form></div>
    <div class="section">${t('payment')}</div><div class="card"><form id="workerPaymentForm">
    <div class="field"><label>${t('worker')} *</label><select name="workerId" required><option value="">${t('selectOption')}</option>${records('workers').map(item => `<option value="${esc(item.id)}">${esc(item.name)}</option>`).join('')}</select></div>
    <div class="field"><label>${t('date')}</label><input name="date" type="date" value="${localDateKey()}" required></div>
    <div class="field"><label>${t('amount')} *</label><input name="amount" type="number" min="0.01" step=".01" required></div>
    <div class="field"><label>${t('detail')}</label><input name="detail" maxlength="240"></div>
    <button class="btn full">${t('save')}</button></form></div>`;
}

function reportsPage() {
  const entries = filteredEntries().filter(entry =>
    (!reportFilters.farmerId || entry.customerId === reportFilters.farmerId) &&
    (!reportFilters.workerId || entry.workerId === reportFilters.workerId)
  );
  const total = type => entries.filter(entry => entry.type === type).reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  return `<div class="title">${t('reports')}</div>${filterControls()}
    <div class="card"><div class="row"><div class="field"><label>${t('reportFarmer')}</label><select id="reportFarmer"><option value="">${t('allRecords')}</option>${records('customers').map(item => `<option value="${esc(item.id)}" ${reportFilters.farmerId === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select></div>
    <div class="field"><label>${t('reportWorker')}</label><select id="reportWorker"><option value="">${t('allRecords')}</option>${records('workers').map(item => `<option value="${esc(item.id)}" ${reportFilters.workerId === item.id ? 'selected' : ''}>${esc(item.name)}</option>`).join('')}</select></div></div></div>
    ${summaryCards(entries)}
    <div class="stats" style="margin-top:10px"><div class="stat"><div class="label">${t('solar')}</div><div class="num">${money(total('solar'))}</div></div>
    <div class="stat"><div class="label">${t('wapda')}</div><div class="num">${money(total('wapda'))}</div></div></div>
    <div class="actions"><button class="btn secondary" data-export-csv>${t('export')} CSV</button></div>${entryRows(entries, true)}`;
}

function statementPage() {
  const customer = records('customers').find(item => item.id === sessionStorage.getItem('kmt-selected'));
  if (!customer) return customersPage();
  const entries = records('entries').filter(entry => entry.customerId === customer.id).sort((a, b) => a.date.localeCompare(b.date));
  let balance = Number(customer.opening || 0);
  const rows = entries.map(entry => {
    const debit = isChargeType(entry) ? Number(entry.amount) : 0;
    const credit = ['cash', 'adjust'].includes(entry.type) ? Number(entry.amount) : 0;
    balance += debit - credit;
    return `<tr><td>${esc(entry.date)}</td><td>${esc(entry.detail)} · ${esc(entryTypeLabel(entry))}</td><td>${debit ? money(debit) : '—'}</td><td>${credit ? money(credit) : '—'}</td><td>${money(balance)}</td></tr>`;
  }).join('');
  return `<div class="actions noprint"><button class="btn secondary" data-nav="customers">← ${t('customers')}</button>
    <button class="btn" data-statement>${t('print')}</button><button class="btn secondary" data-new-for="${esc(customer.id)}">${t('entry')}</button></div>
    <div id="statementContent"><div class="title">${t('statement')} — ${esc(customer.name)}</div>
    <div class="card">${esc(customer.mobile || '')} · ${t('closingBalance')}: <b>${money(customerBalance(customer))}</b></div>
    <div class="tablewrap"><table><thead><tr><th>${t('date')}</th><th>${t('detail')}</th><th>${t('debit')}</th><th>${t('credit')}</th><th>${t('balance')}</th></tr></thead>
    <tbody><tr><td>—</td><td>${t('opening')}</td><td>—</td><td>—</td><td>${money(customer.opening)}</td></tr>${rows || `<tr><td colspan="5">${t('noEntries')}</td></tr>`}</tbody></table></div></div>`;
}

function settingsPage() {
  const deleted = data.entries.filter(entry => entry.deleted);
  return `<div class="title">${t('settings')}</div><div class="card"><form id="settingsForm">
    ${[['tractorRate', t('tractor')], ['motorRate', t('motor')], ['solarRate', t('solar')], ['wapdaRate', t('wapda')]].map(([key, label]) => `<div class="field"><label>${label} ${t('rate')}</label><input name="${key}" type="number" min="0" step=".01" value="${esc(data.settings[key] || 0)}"></div>`).join('')}
    <button class="btn full">${t('save')}</button></form><div class="section">${t('backup')}</div><button class="btn" data-backup>${t('backup')}</button>
    <label class="btn secondary" for="restoreFile">${t('restore')}</label><input class="hidden" type="file" id="restoreFile" accept=".json,application/json"></div>
    ${deleted.length ? `<div class="section">${t('recentlyDeleted')}</div><div class="list">${deleted.map(entry => `<div class="item"><div class="itemmain">${esc(entry.detail)} · ${esc(entry.date)}</div><button class="btn secondary small" data-undo="${esc(entry.id)}">${t('undo')}</button></div>`).join('')}</div>` : ''}`;
}

function render(force = false) {
  document.documentElement.lang = language;
  document.documentElement.dir = language === 'ur' ? 'rtl' : 'ltr';
  $('#app').classList.toggle('rtl', language === 'ur');
  $('#lang').value = language;
  document.querySelectorAll('[data-t="app"], [data-t="tag"]').forEach(element => {
    element.textContent = t(element.dataset.t);
  });
  $('#googleLogin').textContent = t('signIn');
  $('#googleLogout').textContent = t('signOut');
  document.querySelectorAll('[data-placeholder]').forEach(element => {
    element.placeholder = t(element.dataset.placeholder);
  });
  $('#today').textContent = new Intl.DateTimeFormat(language === 'ur' ? 'ur-PK' : 'en-PK', pakistanDateOptions({
    weekday: 'long', year: 'numeric', month: 'short', day: 'numeric'
  })).format(new Date());
  const navigationLabels = { home: 'home', customers: 'customers', entry: 'entry', workers: 'workers', reports: 'reports' };
  document.querySelectorAll('[data-page]').forEach(button => {
    const label = button.querySelector('span:not(.ni)');
    if (label) label.textContent = t(navigationLabels[button.dataset.page]);
  });
  const activeForm = $('#screen form[data-dirty="true"], #entryModal form[data-dirty="true"]');
  if (activeForm && !force) return;
  const pages = { home: homePage, customers: customersPage, entry: entryPage, workers: workersPage, reports: reportsPage, ledger: statementPage, settings: settingsPage };
  $('#entryModal')?.remove();
  $('#screen').innerHTML = (pages[page] || homePage)();
  if (entryModalOpen) $('#app').insertAdjacentHTML('beforeend', entryModalMarkup());
  document.querySelectorAll('[data-page]').forEach(button => button.classList.toggle('active', button.dataset.page === page));
  bind();
}

function notify(message, action) {
  let toast = $('#appToast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'appToast';
    toast.className = 'notice';
    toast.style.cssText = 'position:fixed;left:12px;right:12px;bottom:78px;z-index:10;max-width:780px;margin:auto';
    $('#app').append(toast);
  }
  toast.innerHTML = `${esc(message)} ${action ? `<button class="btn secondary small" id="toastAction">${esc(action.label)}</button>` : ''}`;
  if (action) $('#toastAction').onclick = action.run;
  window.setTimeout(() => toast.remove(), 6000);
}

function bind() {
  document.querySelectorAll('[data-nav]').forEach(button => button.onclick = () => navigate(button.dataset.nav));
  document.querySelectorAll('[data-page]').forEach(button => button.onclick = () => navigate(button.dataset.page));
  const modalCloseButton = $('#closeEntryModal');
  if (modalCloseButton) modalCloseButton.onclick = closeEntryModalRoute;
  document.querySelectorAll('[data-edit-customer]').forEach(button => button.onclick = () => {
    editingCustomerId = button.dataset.editCustomer;
    page = 'customers';
    render(true);
  });
  document.querySelectorAll('[data-delete-customer]').forEach(button => button.onclick = () => {
    const customer = records('customers').find(item => item.id === button.dataset.deleteCustomer);
    if (!customer || !confirm(t('deleteFarmerConfirm'))) return;
    store.setDeleted('customers', customer.id, true);
    if (editingCustomerId === customer.id) editingCustomerId = null;
    notify(t('deletedRecord'), {
      label: t('undo'),
      run: () => store.setDeleted('customers', customer.id, false)
    });
  });
  document.querySelectorAll('[data-cancel-customer]').forEach(button => button.onclick = () => { editingCustomerId = null; render(); });
  document.querySelectorAll('[data-ledger]').forEach(button => button.onclick = () => {
    sessionStorage.setItem('kmt-selected', button.dataset.ledger);
    navigate('ledger');
  });
  document.querySelectorAll('[data-edit-entry]').forEach(button => button.onclick = () => {
    editingEntryId = button.dataset.editEntry;
    navigate('entry');
  });
  document.querySelectorAll('[data-cancel-entry]').forEach(button => button.onclick = () => { editingEntryId = null; render(); });
  document.querySelectorAll('[data-delete-entry]').forEach(button => button.onclick = () => {
    const entry = records('entries').find(item => item.id === button.dataset.deleteEntry);
    if (!entry || !confirm(t('deleteConfirm'))) return;
    store.setDeleted('entries', entry.id, true);
    lastDeleted = entry.id;
    notify(t('deletedMessage'), { label: t('undo'), run: () => store.setDeleted('entries', lastDeleted, false) });
  });
  document.querySelectorAll('[data-undo]').forEach(button => button.onclick = () => store.setDeleted('entries', button.dataset.undo, false));
  document.querySelectorAll('[data-edit-worker]').forEach(button => button.onclick = () => {
    editingWorkerId = button.dataset.editWorker;
    render(true);
  });
  document.querySelectorAll('[data-delete-worker]').forEach(button => button.onclick = () => {
    const worker = records('workers').find(item => item.id === button.dataset.deleteWorker);
    if (!worker || !confirm(t('deleteWorkerConfirm'))) return;
    store.setDeleted('workers', worker.id, true);
    if (editingWorkerId === worker.id) editingWorkerId = null;
    notify(t('deletedRecord'), {
      label: t('undo'),
      run: () => store.setDeleted('workers', worker.id, false)
    });
  });
  document.querySelectorAll('[data-cancel-worker]').forEach(button => button.onclick = () => { editingWorkerId = null; render(); });
  document.querySelectorAll('[data-new-for]').forEach(button => {
    button.onclick = () => {
      sessionStorage.setItem('kmt-preselect-customer', button.dataset.newFor);
      navigate('entry');
    };
  });

  const customerForm = $('#customerForm');
  if (customerForm) customerForm.onsubmit = event => {
    event.preventDefault();
    if (!customerForm.reportValidity()) return;
    const form = new FormData(customerForm);
    const name = String(form.get('name')).trim();
    if (!name) {
      customerForm.elements.name.setCustomValidity(t('enterName'));
      customerForm.reportValidity();
      customerForm.elements.name.setCustomValidity('');
      return;
    }
    const duplicate = records('customers').find(item =>
      item.id !== editingCustomerId && item.name.trim().toLocaleLowerCase() === name.toLocaleLowerCase()
    );
    if (duplicate) {
      customerForm.elements.name.setCustomValidity(t('duplicateName'));
      customerForm.reportValidity();
      customerForm.elements.name.setCustomValidity('');
      return;
    }
    store.upsert('customers', {
      id: editingCustomerId || createId(),
      name,
      mobile: String(form.get('mobile')).trim(),
      opening: Number(form.get('opening') || 0),
      address: String(form.get('address')).trim(),
      deleted: false
    });
    editingCustomerId = null;
    render();
  };

  const entryForm = $('#entryForm');
  if (entryForm) {
    const typeSelect = $('#entryType');
    const quantity = $('#quantity');
    const rate = $('#rate');
    const amount = $('#amount');
    const billSource = $('#billSource');
    const quantityFields = $('#quantityFields');
    const motorBillFields = $('#motorBillFields');
    const editAttendanceFields = $('#editAttendanceFields');
    const entryDetailField = $('#entryDetailField');
    const entryAmountField = $('#entryAmountField');
    const entryWorker = entryForm.elements.workerId;
    const entryDate = $('#entryDate');
    const editAttendanceStatus = $('#editAttendanceStatus');
    const updateAmount = () => {
      const selectedType = typeSelect.value;
      if (chargeTypes.has(selectedType) || selectedType.startsWith('custom-')) {
        amount.value = (Number(quantity.value || 0) * Number(rate.value || 0)).toFixed(2);
      }
    };
    if (quantity) quantity.oninput = updateAmount;
    if (rate) rate.oninput = updateAmount;
    typeSelect.onchange = () => {
      const type = typeSelect.value;
      const source = type === 'motorBill' ? billSource.value : type;
      const attendance = type === 'attendance';
      motorBillFields?.classList.toggle('hidden', type !== 'motorBill');
      editAttendanceFields?.classList.toggle('hidden', !attendance);
      quantityFields.classList.toggle('hidden', !(chargeTypes.has(type) || type.startsWith('custom-')));
      entryDetailField.classList.toggle('hidden', attendance);
      entryAmountField.classList.toggle('hidden', attendance);
      entryForm.elements.detail.required = !attendance;
      amount.required = !attendance;
      if (chargeTypes.has(type) || type.startsWith('custom-')) {
        rate.value = rateFor(type, source);
        updateAmount();
      }
    };
    const updateEditedAttendanceAmount = () => {
      if (typeSelect.value !== 'attendance') return;
      const worker = records('workers').find(item => item.id === entryWorker.value);
      amount.value = attendanceAmount(worker, entryDate.value, editAttendanceStatus?.value || 'absent').toFixed(2);
    };
    if (entryWorker) entryWorker.onchange = updateEditedAttendanceAmount;
    if (editAttendanceStatus) editAttendanceStatus.onchange = updateEditedAttendanceAmount;
    entryDate.onchange = updateEditedAttendanceAmount;
    if (billSource) billSource.onchange = () => {
      rate.value = rateFor('motorBill', billSource.value);
      updateAmount();
    };
    typeSelect.onchange();
    const addCategory = $('#addCategory');
    const newCategoryFields = $('#newCategoryFields');
    const newCategoryName = $('#newCategoryName');
    const saveCategory = $('#saveCategory');
    if (addCategory) addCategory.onclick = () => {
      const isVisible = !newCategoryFields.classList.contains('hidden');
      newCategoryFields.classList.toggle('hidden', isVisible);
      newCategoryName.required = !isVisible;
      if (!isVisible) newCategoryName.focus();
    };
    if (saveCategory) saveCategory.onclick = () => {
      const normalizedName = newCategoryName.value.trim();
      if (!normalizedName) return;
      const categories = data.settings.customCategories || [];
      const builtInNames = Object.values(words).flatMap(dictionary =>
        ['tractor', 'motor', 'spray', 'fertilizer', 'motorBill', 'solar', 'wapda', 'cash', 'adjust']
          .map(key => dictionary[key].toLocaleLowerCase())
      );
      const candidate = normalizedName.toLocaleLowerCase();
      if (categories.some(item => item.name.toLocaleLowerCase() === candidate) || builtInNames.includes(candidate)) {
        notify(t('categoryExists'));
        return;
      }
      const category = { id: createId(), name: normalizedName, rate: 0 };
      entryForm.dataset.dirty = 'true';
      store.updateSettings({ customCategories: [...categories, category] });
      const option = document.createElement('option');
      option.value = `custom-${category.id}`;
      option.textContent = category.name;
      typeSelect.append(option);
      typeSelect.value = option.value;
      typeSelect.onchange();
      newCategoryName.value = '';
      newCategoryName.required = false;
      newCategoryFields.classList.add('hidden');
    };
    if (sessionStorage.getItem('kmt-preselect-customer')) {
      entryForm.elements.customerId.value = sessionStorage.getItem('kmt-preselect-customer');
      sessionStorage.removeItem('kmt-preselect-customer');
    }
    entryForm.onsubmit = event => {
      event.preventDefault();
      if (!entryForm.reportValidity()) return;
      const form = new FormData(entryForm);
      const selectedType = String(form.get('type'));
      const billSourceValue = String(form.get('billSource') || 'solar');
      const type = selectedType === 'motorBill' ? billSourceValue : selectedType;
      const status = String(form.get('status') || '');
      const attendanceWorker = records('workers').find(item => item.id === String(form.get('workerId') || ''));
      const amountValue = selectedType === 'attendance'
        ? attendanceAmount(attendanceWorker, String(form.get('date')), status)
        : Number(form.get('amount'));
      const detail = selectedType === 'attendance' ? t(status) : String(form.get('detail')).trim();
      if (selectedType !== 'attendance' && !detail) {
        entryForm.elements.detail.setCustomValidity(t('enterDetails'));
        entryForm.reportValidity();
        entryForm.elements.detail.setCustomValidity('');
        return;
      }
      if (!Number.isFinite(amountValue) || amountValue < 0) {
        entryForm.elements.amount.setCustomValidity(t('validAmount'));
        entryForm.reportValidity();
        entryForm.elements.amount.setCustomValidity('');
        return;
      }
      const record = {
        id: editingEntryId || createId(),
        customerId: String(form.get('customerId') || ''),
        workerId: String(form.get('workerId') || ''),
        type,
        status: selectedType === 'attendance' ? status : '',
        billSource: selectedType === 'motorBill' ? billSourceValue : '',
        date: String(form.get('date')),
        detail,
        qty: Number(form.get('qty') || 0),
        rate: Number(form.get('rate') || 0),
        amount: amountValue,
        deleted: false
      };
      const customerId = record.customerId;
      store.upsert('entries', record);
      editingEntryId = null;
      if (customerId) {
        sessionStorage.setItem('kmt-selected', customerId);
        navigate('ledger');
      } else navigate('workers');
    };
  }

  const workerForm = $('#workerForm');
  if (workerForm) workerForm.onsubmit = event => {
    event.preventDefault();
    if (!workerForm.reportValidity()) return;
    const form = new FormData(workerForm);
    const name = String(form.get('name')).trim();
    if (!name) {
      workerForm.elements.name.setCustomValidity(t('enterName'));
      workerForm.reportValidity();
      workerForm.elements.name.setCustomValidity('');
      return;
    }
    const duplicate = records('workers').find(item =>
      item.id !== editingWorkerId && item.name.trim().toLocaleLowerCase() === name.toLocaleLowerCase()
    );
    if (duplicate) {
      workerForm.elements.name.setCustomValidity(t('duplicateName'));
      workerForm.reportValidity();
      workerForm.elements.name.setCustomValidity('');
      return;
    }
    store.upsert('workers', {
      id: editingWorkerId || createId(),
      name,
      mobile: String(form.get('mobile')).trim(),
      opening: Number(form.get('opening') || 0),
      method: String(form.get('method')),
      salary: Number(form.get('salary') || 0),
      deleted: false
    });
    editingWorkerId = null;
    render();
  };

  const attendanceForm = $('#attendanceForm');
  if (attendanceForm) {
    const attendanceWorker = attendanceForm.elements.workerId;
    const attendanceDate = attendanceForm.elements.date;
    const attendanceStatus = attendanceForm.elements.status;
    const updateAttendancePreview = () => {
      const worker = records('workers').find(item => item.id === attendanceWorker.value);
      $('#attendancePreview').textContent = `${t('attendancePay')}: ${money(attendanceAmount(worker, attendanceDate.value, attendanceStatus.value))}`;
    };
    attendanceWorker.onchange = updateAttendancePreview;
    attendanceDate.onchange = updateAttendancePreview;
    attendanceStatus.onchange = updateAttendancePreview;
    attendanceForm.onsubmit = event => {
    event.preventDefault();
    if (!attendanceForm.reportValidity()) return;
    const form = new FormData(attendanceForm);
    const workerId = String(form.get('workerId'));
    const date = String(form.get('date'));
    const status = String(form.get('status'));
    const existing = records('entries').find(entry => entry.type === 'attendance' && entry.workerId === workerId && entry.date === date);
    const worker = records('workers').find(item => item.id === workerId);
    store.upsert('entries', {
      id: existing?.id || createId(), workerId, type: 'attendance',
      date, status, detail: t(status), amount: attendanceAmount(worker, date, status),
      qty: attendanceFactor(status), rate: Number(worker?.salary || 0), deleted: false
    });
    notify(t('attendanceSaved'));
  };
  }

  const workerPaymentForm = $('#workerPaymentForm');
  if (workerPaymentForm) workerPaymentForm.onsubmit = event => {
    event.preventDefault();
    if (!workerPaymentForm.reportValidity()) return;
    const form = new FormData(workerPaymentForm);
    store.upsert('entries', {
      id: createId(), workerId: String(form.get('workerId')), type: 'workerPayment',
      date: String(form.get('date')), detail: String(form.get('detail') || '').trim(),
      amount: Number(form.get('amount')), qty: 0, rate: 0, deleted: false
    });
    render(true);
  };

  document.querySelectorAll('#applyFilters').forEach(button => button.onclick = () => {
    const from = $('#filterFrom').value;
    const to = $('#filterTo').value;
    if (from && to && from > to) {
      notify(t('invalidDateRange'));
      return;
    }
    filters.from = from;
    filters.to = to;
    render();
  });
  const reportFarmer = $('#reportFarmer');
  if (reportFarmer) reportFarmer.onchange = () => {
    reportFilters.farmerId = reportFarmer.value;
    render(true);
  };
  const reportWorker = $('#reportWorker');
  if (reportWorker) reportWorker.onchange = () => {
    reportFilters.workerId = reportWorker.value;
    render(true);
  };
  const settingsForm = $('#settingsForm');
  if (settingsForm) settingsForm.onsubmit = event => {
    event.preventDefault();
    if (!settingsForm.reportValidity()) return;
    const form = new FormData(settingsForm);
    store.updateSettings(Object.fromEntries(['tractorRate', 'motorRate', 'solarRate', 'wapdaRate'].map(key => [key, Number(form.get(key) || 0)])));
    render();
  };
  document.querySelectorAll('[data-backup]').forEach(button => button.onclick = () => {
    exportBackup().catch(error => notify(`Backup export failed: ${error.message}`));
  });
  document.querySelectorAll('[data-export-csv]').forEach(button => button.onclick = () => {
    exportCsv().catch(error => notify(`CSV export failed: ${error.message}`));
  });
  const restoreInput = $('#restoreFile');
  if (restoreInput) restoreInput.onchange = restoreBackup;
  const statementButton = $('[data-statement]');
  if (statementButton) statementButton.onclick = () => {
    exportStatement().catch(error => notify(`Statement export failed: ${error.message}`));
  };
}

function listenForDirtyForms() {
  document.addEventListener('input', event => {
    const form = event.target.closest('form');
    if (form) form.dataset.dirty = 'true';
  });
  document.addEventListener('submit', event => {
    event.target.dataset.dirty = 'false';
  }, true);
}

async function exportBackup() {
  await saveOrShareFile({
    filename: `Kisan_Ledger_Backup_${localDateKey()}.json`,
    content: JSON.stringify(data, null, 2),
    mimeType: 'application/json'
  });
}

async function exportCsv() {
  const rows = [['Date', 'Farmer/Worker', 'Type', 'Detail', 'Quantity', 'Rate', 'Amount', 'Notes']];
  for (const entry of records('entries')) {
    const person = records('customers').find(item => item.id === entry.customerId) || records('workers').find(item => item.id === entry.workerId);
    rows.push([entry.date, person?.name || '', entryTypeLabel(entry), entry.detail, entry.qty, entry.rate, entry.amount, entry.notes || '']);
  }
  const csv = rows.map(row => row.map(value => `"${String(value ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
  await saveOrShareFile({
    filename: `Kisan_Ledger_${localDateKey()}.csv`,
    content: `\ufeff${csv}`,
    mimeType: 'text/csv;charset=utf-8'
  });
}

async function exportStatement() {
  const content = $('#statementContent');
  const style = '<style>body{font:14px Arial;padding:20px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #bbb;padding:8px;text-align:left}</style>';
  await shareOrPrintStatement(`<!doctype html><html><head>${style}</head><body>${content.innerHTML}</body></html>`, `Kisan_Statement_${localDateKey()}.html`);
}

async function restoreBackup(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  try {
    const backup = JSON.parse(await file.text());
    if (!Array.isArray(backup.customers) || !Array.isArray(backup.workers) || !Array.isArray(backup.entries)) {
      throw new Error(t('invalidBackup'));
    }
    if (!confirm(t('restoreConfirm'))) return;
    store.replaceData(backup);
    render();
  } catch (error) {
    console.error('Backup restore failed.', error);
    notify(`${t('restoreFailed')}: ${error.message}`);
  } finally {
    event.target.value = '';
  }
}

function updateCloudStatus(message) {
  const key = Object.keys(words[language]).find(candidate => words[language][candidate] === message);
  cloudStatusTranslation = key ? { key } : null;
  $('#cloudStatus').textContent = message;
}

function refreshCloudStatus() {
  if (!cloudStatusTranslation) return;
  const { key, detail } = cloudStatusTranslation;
  if (key === 'signedInAs') {
    $('#cloudStatus').textContent = `${t(key)} ${detail || 'Google user'} — ${t('cloudSyncActive')}`;
  } else {
    $('#cloudStatus').textContent = `${t(key)}${detail || ''}`;
  }
}

$('#lang').onchange = event => {
  const formValues = [...document.querySelectorAll('#screen form, #entryModal form')].map(form => ({
    id: form.id,
    values: [...form.elements].filter(control => control.name).map(control => ({
      name: control.name,
      value: control.value,
      checked: control.checked
    }))
  }));
  language = event.target.value;
  localStorage.setItem('kmt-lang', language);
  render(true);
  for (const savedForm of formValues) {
    const form = document.getElementById(savedForm.id);
    if (!form) continue;
    for (const savedControl of savedForm.values) {
      const control = form.elements.namedItem(savedControl.name);
      if (!control) continue;
      control.value = savedControl.value;
      if ('checked' in control) control.checked = savedControl.checked;
    }
    form.dataset.dirty = 'true';
  }
  refreshCloudStatus();
};
window.addEventListener('popstate', event => {
  const state = event.state;
  entryModalOpen = Boolean(state?.modal);
  page = entryModalOpen
    ? (state.returnPage || entryModalReturnPage)
    : decodeURIComponent(location.hash.slice(1)) || state?.page || 'home';
  routeDepth = Math.max(0, state?.depth ?? routeDepth - 1);
  render(true);
});
window.addEventListener('online', () => updateCloudStatus(t('onlineSync')));
window.addEventListener('offline', () => updateCloudStatus(t('offlineSaved')));
store.addEventListener('change', event => {
  data = event.detail;
  render();
});
store.addEventListener('sync-error', () => updateCloudStatus(t('cloudSaveError')));
listenForDirtyForms();
registerAndroidBackHandler(() => {
  if (entryModalOpen) closeEntryModalRoute();
  else if (routeDepth > 0) window.history.back();
  else window.Capacitor?.Plugins?.App?.exitApp?.();
});

$('#googleLogin').onclick = async () => {
  if (!cloudAuth || !authSdk) {
    updateCloudStatus(t('cloudSetup'));
    return;
  }
  try {
    await signInWithNativeAuth(cloudAuth, new authSdk.GoogleAuthProvider());
  } catch (error) {
    console.error('Sign-in failed.', error);
    cloudStatusTranslation = { key: 'signInFailed', detail: `: ${error.code || error.message}` };
    refreshCloudStatus();
  }
};
$('#googleLogout').onclick = async () => {
  try {
    if (!cloudAuth || !authSdk) throw new Error(t('firebaseNotConnected'));
    await authSdk.signOut(cloudAuth);
  } catch (error) {
    console.error('Sign-out failed.', error);
    cloudStatusTranslation = { key: 'signOutFailed', detail: `: ${error.code || error.message}` };
    refreshCloudStatus();
  }
};

async function startCloudSync() {
  if (cloudAuth || cloudStarting) return;
  if (!hasFirebaseConfig()) {
    $('#googleLogin').disabled = true;
    updateCloudStatus(t('cloudMissing'));
    return;
  }
  if (!navigator.onLine) {
    updateCloudStatus(t('cloudOffline'));
    return;
  }
  try {
    const cloud = await initializeFirebase();
    if (!cloud) return;
    cloudAuth = cloud.auth;
    authSdk = cloud.authSdk;
    store.setCloudClient(cloud);
    if (cloud.persistence !== 'persistent') console.warn(t('cloudCacheMemory'));
    authSdk.onAuthStateChanged(cloudAuth, user => {
      store.setUser(user?.uid || null);
      $('#googleLogin').hidden = Boolean(user);
      $('#googleLogout').hidden = !user;
      if (user) {
        cloudStatusTranslation = { key: 'signedInAs', detail: user.email || 'Google user' };
        refreshCloudStatus();
        store.connectRemote(updateCloudStatus, t);
      } else {
        updateCloudStatus(navigator.onLine ? t('signOutLocal') : t('signedOutOffline'));
      }
    });
  } catch (error) {
    console.error('Firebase initialization failed.', error);
    updateCloudStatus(t('cloudInitFailed'));
  } finally {
    cloudStarting = false;
  }
}

if (!hasFirebaseConfig()) {
  $('#googleLogin').disabled = true;
  updateCloudStatus(t('cloudMissing'));
} else {
  startCloudSync();
  window.addEventListener('online', startCloudSync);
}

if (entryModalOpen) {
  history.replaceState({ page: 'entry', returnPage: page, modal: true, depth: 0 }, '', '#entry');
} else {
  history.replaceState({ page, depth: 0 }, '', `#${encodeURIComponent(page)}`);
}
render();
