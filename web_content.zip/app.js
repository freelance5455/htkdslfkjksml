const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const sections=[
 ['home','ہوم'],['normal','۱ نارمل'],['bright','۲ شوخ'],['luxury','۳ لگژری'],['velvet','۴ ویلویٹ'],['shades','۵ شیڈز'],['spectrum','۶ اسپیکٹرم'],['combo','۷ کمبینیشن'],['science','۸ سائنس'],['game','۹ گیم'],['extra','۱۰ رنگ لیب']
];
const normal=[
 ['#FF0000','سرخ','Red'],['#00A651','سبز','Green'],['#0000FF','نیلا','Blue'],['#FFFF00','زرد','Yellow'],['#FFA500','نارنجی','Orange'],['#800080','جامنی','Purple'],['#FFC0CB','گلابی','Pink'],['#A52A2A','بھورا','Brown'],['#000000','کالا','Black'],['#FFFFFF','سفید','White'],['#808080','سرمئی','Gray'],['#00FFFF','آسمانی فیروزی','Cyan'],['#008080','نیلا سبز','Teal'],['#000080','بحری نیلا','Navy'],['#F5F5DC','کریم','Beige'],['#FFD700','سنہری','Gold']
];
const bright=[
 ['#FF1744','چمکدار سرخ','Bright Red'],['#FFEA00','چمکدار زرد','Bright Yellow'],['#00E676','چمکدار سبز','Bright Green'],['#00B0FF','چمکدار نیلا','Bright Blue'],['#D500F9','چمکدار جامنی','Bright Purple'],['#FF6D00','چمکدار نارنجی','Bright Orange'],['#FF00A8','ہاٹ پنک','Hot Pink'],['#00FFFF','برقی فیروزی','Electric Cyan'],['#7CFF00','نیون سبز','Neon Green'],['#FF073A','نیون سرخ','Neon Red'],['#FEFF00','نیون زرد','Neon Yellow'],['#39FF14','نیون لائم','Neon Lime']
];
const luxury=[
 ['#0B0B0B','آبنوسی کالا','Ebony'],['#1C1C2E','شاہی نیلا کالا','Midnight'],['#0F3D3E','گہرا زمرد','Deep Emerald'],['#064E3B','زمردی سبز','Emerald'],['#4C1D95','شاہی جامنی','Royal Purple'],['#581C87','امیتھسٹ','Amethyst'],['#7F1D1D','شرابی سرخ','Burgundy'],['#991B1B','روبی','Ruby'],['#92400E','عنبر','Amber'],['#B45309','کانسی سنہری','Bronze Gold'],['#C9A227','شاہی سنہرا','Royal Gold'],['#F5E6C8','شیمپین','Champagne'],['#D4AF37','میٹلک گولڈ','Metallic Gold'],['#C0C0C0','چاندی','Silver']
];
const velvet=[
 ['#3B0A45','ویلویٹ جامنی','Velvet Purple'],['#4A0E2E','ویلویٹ برگنڈی','Velvet Burgundy'],['#6D071A','ویلویٹ سرخ','Velvet Red'],['#062E2E','ویلویٹ سبز','Velvet Green'],['#082F49','ویلویٹ نیلا','Velvet Blue'],['#172554','آدھی رات نیلا','Midnight Blue'],['#2E1065','گہرا بنفشی','Deep Violet'],['#3F1D38','پلَم','Plum'],['#5B2333','مولبری','Mulberry'],['#123524','گہرا سبز','Forest Velvet'],['#4B3621','چاکلیٹی بھورا','Chocolate'],['#3A2A1F','کافی','Coffee']
];
const families={
 'سرخ':['#FFE4E6','#FDA4AF','#FB7185','#F43F5E','#E11D48','#BE123C','#9F1239','#881337','#4C0519'],
 'نارنجی':['#FFF7ED','#FED7AA','#FDBA74','#FB923C','#F97316','#EA580C','#C2410C','#9A3412','#431407'],
 'زرد':['#FEFCE8','#FEF9C3','#FEF08A','#FDE047','#FACC15','#EAB308','#CA8A04','#A16207','#713F12'],
 'سبز':['#F0FDF4','#DCFCE7','#BBF7D0','#86EFAC','#4ADE80','#22C55E','#16A34A','#15803D','#14532D'],
 'فیروزی':['#ECFEFF','#CFFAFE','#A5F3FC','#67E8F9','#22D3EE','#06B6D4','#0891B2','#0E7490','#164E63'],
 'نیلا':['#EFF6FF','#DBEAFE','#BFDBFE','#93C5FD','#60A5FA','#3B82F6','#2563EB','#1D4ED8','#1E3A8A'],
 'جامنی':['#FAF5FF','#F3E8FF','#E9D5FF','#D8B4FE','#C084FC','#A855F7','#9333EA','#7E22CE','#581C87'],
 'گلابی':['#FFF1F2','#FFE4E6','#FECDD3','#FDA4AF','#FB7185','#F43F5E','#E11D48','#BE123C','#881337'],
 'بھورا':['#FAFAF9','#E7E5E4','#D6D3D1','#A8A29E','#78716C','#57534E','#44403C','#292524','#1C1917'],
 'سرمئی':['#FFFFFF','#F3F4F6','#E5E7EB','#D1D5DB','#9CA3AF','#6B7280','#4B5563','#374151','#111827']
};
const shadeNames=['انتہائی ہلکا','ہلکا','ہلکا درمیانہ','درمیانہ','درمیانہ شوخ','شوخ','گہرا','بہت گہرا','انتہائی گہرا'];

function luminance(hex){let c=hex.slice(1).match(/../g).map(x=>parseInt(x,16)/255);c=c.map(v=>v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4));return .2126*c[0]+.7152*c[1]+.0722*c[2]}
function textColor(hex){return luminance(hex)>.55?'#111827':'#fff'}
function card(c, compact=false){
 const [hex,ur,en]=c;
 return `<div class="${compact?'mini-card':'color-card'}"><div class="swatch" style="background:${hex};color:${textColor(hex)}"><span class="hex">${hex}</span></div><div class="${compact?'mini-name':'color-info'}"><div class="urdu-name">${ur}</div>${!compact?`<div class="en-name">${en}</div>`:''}</div></div>`;
}
function renderGrid(id,data){$(id).innerHTML=data.map(x=>card(x)).join('')}
renderGrid('#normalGrid',normal);renderGrid('#brightGrid',bright);renderGrid('#luxuryGrid',luxury);renderGrid('#velvetGrid',velvet);

let spectrum=[];
Object.entries(families).forEach(([fam,arr])=>arr.forEach((hex,i)=>spectrum.push([hex,`${fam} — ${shadeNames[i]}`,fam])));
function renderSpectrum(){
 const q=($('#colorSearch').value||'').toLowerCase(), f=$('#familyFilter').value;
 const data=spectrum.filter(x=>(!f||x[2]===f)&&(!q||x[0].toLowerCase().includes(q)||x[1].toLowerCase().includes(q)));
 $('#spectrumGrid').innerHTML=data.map(x=>card([x[0],x[1],x[2]])).join('');
}
Object.keys(families).forEach(f=>$('#familyFilter').insertAdjacentHTML('beforeend',`<option>${f}</option>`));
$('#colorSearch').addEventListener('input',renderSpectrum);$('#familyFilter').addEventListener('change',renderSpectrum);renderSpectrum();

$('#shadeGroups').innerHTML=Object.entries(families).map(([fam,arr])=>`
<div class="shade-group"><h3>${fam} کے شیڈز</h3><div class="shade-row">${arr.map((hex,i)=>card([hex,shadeNames[i],fam],true)).join('')}</div></div>`).join('');

const sectionsInfo=[
['home','تعارف','رنگوں کی دنیا کا ہوم پیج','#ff3d81,#7c4dff'],
['normal','نارمل رنگ','بنیادی اور روزمرہ رنگ','#ef4444,#3b82f6'],
['bright','شوخ رنگ','نیون اور تیز رنگ','#ff1744,#39ff14'],
['luxury','لگژری رنگ','شاہانہ اور نفیس رنگ','#111827,#d4af37'],
['velvet','ویلویٹ رنگ','گہرے اور بھرپور شیڈز','#3b0a45,#082f49'],
['shades','شیڈز','ایک رنگ کے کئی درجات','#fecdd3,#881337'],
['spectrum','وسیع اسپیکٹرم','ہلکے سے گہرے تک رنگ','#e0f2fe,#312e81'],
['combo','کمبینیشن','دو اور تین رنگوں کے ڈیزائن','#0f172a,#f8fafc'],
['science','رنگوں کی سائنس','آئی کیچی اور بصری اثرات','#ff1744,#00e676'],
['game','مکسنگ گیم','رنگ ملا کر نتیجہ معلوم کریں','#ff0000,#0000ff'],
['extra','رنگ لیب','اپنی پیلیٹ بنائیں','#6c5ce7,#00cec9']
];
$('#sectionCards').innerHTML=sectionsInfo.slice(1).map(s=>`<div class="section-card" data-go="${s[0]}"><div class="bar" style="background:linear-gradient(120deg,${s[3].split(',')[0]},${s[3].split(',')[1]})"></div><b>${s[0]==='normal'?'۱۔ ':s[0]==='bright'?'۲۔ ':s[0]==='luxury'?'۳۔ ':s[0]==='velvet'?'۴۔ ':s[0]==='shades'?'۵۔ ':s[0]==='spectrum'?'۶۔ ':s[0]==='combo'?'۷۔ ':s[0]==='science'?'۸۔ ':s[0]==='game'?'۹۔ ':'۱۰۔ '}${s[1]}</b><p>${s[2]}</p></div>`).join('');
function show(id){$$('.page').forEach(p=>p.classList.toggle('active',p.id===id));$$('.tabs button').forEach(b=>b.classList.toggle('active',b.dataset.go===id));window.scrollTo({top:0,behavior:'smooth'})}
$('#sectionCards').addEventListener('click',e=>{const x=e.target.closest('[data-go]');if(x)show(x.dataset.go)});
$('#tabs').innerHTML=sections.map(s=>`<button data-go="${s[0]}">${s[1]}</button>`).join('');
$('#tabs').addEventListener('click',e=>{if(e.target.dataset.go)show(e.target.dataset.go)});show('home');

const two=[
 ['#111827','#FDE68A','کالا + سنہری','شاہانہ اور واضح'],
 ['#0F172A','#FFFFFF','بحری نیلا + سفید','صاف اور پڑھنے میں آسان'],
 ['#1E3A8A','#F8FAFC','گہرا نیلا + آف وائٹ','پرسکون اور پروفیشنل'],
 ['#064E3B','#F5E6C8','زمرد + کریم','نفیس اور گرم'],
 ['#581C87','#FDF2F8','جامنی + بہت ہلکا گلابی','ڈرامائی مگر نرم'],
 ['#7F1D1D','#FEF3C7','برگنڈی + کریم','لگژری انداز']
];
$('#twoCombos').innerHTML=two.map(x=>`<div class="combo"><div class="combo-visual" style="background:${x[0]};color:${x[1]}">${x[2]}</div><p>${x[3]}</p></div>`).join('');
const three=[
 ['#0F172A','#F8FAFC','#D4AF37','نیوی بیک گراؤنڈ + آف وائٹ متن + سنہری ایکسنٹ'],
 ['#064E3B','#ECFDF5','#F59E0B','زمرد بیک گراؤنڈ + ہلکا متن + عنبری ایکسنٹ'],
 ['#4C1D95','#FAF5FF','#F472B6','جامنی بیک گراؤنڈ + ہلکا متن + پنک ایکسنٹ'],
 ['#7F1D1D','#FFF7ED','#FBBF24','برگنڈی بیک گراؤنڈ + کریم متن + گولڈ ایکسنٹ'],
 ['#F8FAFC','#111827','#2563EB','ہلکا بیک گراؤنڈ + گہرا متن + نیلا ایکسنٹ'],
 ['#111827','#F9FAFB','#22C55E','گہرا بیک گراؤنڈ + سفید متن + سبز ایکسنٹ']
];
$('#threeCombos').innerHTML=three.map(x=>`<div class="combo"><div class="combo-visual" style="background:${x[0]};color:${x[1]}"><span style="text-shadow:0 0 0 transparent;border-bottom:4px solid ${x[2]}">تین رنگی ڈیزائن</span></div><p>${x[3]}</p></div>`).join('');

$('#colorCount').textContent=spectrum.length+normal.length+bright.length+luxury.length+velvet.length;

function rgbMix(a,b){const A=a.slice(1).match(/../g).map(x=>parseInt(x,16)),B=b.slice(1).match(/../g).map(x=>parseInt(x,16));return '#'+A.map((v,i)=>Math.round((v+B[i])/2).toString(16).padStart(2,'0')).join('')}
function nearestName(hex){let best=null,d=1e9;[...normal,...bright,...luxury,...velvet,...spectrum.map(x=>[x[0],x[1],x[2]])].forEach(c=>{const h=c[0],a=h.slice(1).match(/../g).map(x=>parseInt(x,16)),b=hex.slice(1).match(/../g).map(x=>parseInt(x,16));const z=(a[0]-b[0])**2+(a[1]-b[1])**2+(a[2]-b[2])**2;if(z<d){d=z;best=c[1]}});return best||'نیا شیڈ'}
function updateMix(){const a=$('#mix1').value,b=$('#mix2').value,r=rgbMix(a,b);$('#mixResult').style.background=r;$('#mixHex').textContent=r.toUpperCase();$('#mixResultName').textContent=nearestName(r);$('#mix1Name').textContent=nearestName(a);$('#mix2Name').textContent=nearestName(b)}
$('#mixBtn').addEventListener('click',updateMix);$('#mix1').addEventListener('input',updateMix);$('#mix2').addEventListener('input',updateMix);updateMix();

let score=0;
function randomQuiz(){const a=normal[Math.floor(Math.random()*normal.length)][0],b=normal[Math.floor(Math.random()*normal.length)][0];$('#mix1').value=a;$('#mix2').value=b;$('#quizQuestion').textContent=`اگر ${nearestName(a)} اور ${nearestName(b)} کو برابر مقدار میں ملائیں تو نتیجہ دیکھیں۔`;updateMix()}
$('#mixBtn').addEventListener('dblclick',()=>{score++;$('#score').textContent=score;randomQuiz()});

let saved=JSON.parse(localStorage.getItem('rangSaved')||'[]');
function renderSaved(){$('#savedGrid').innerHTML=saved.length?saved.map(h=>card([h,nearestName(h),'My Palette'])).join(''):'<p>ابھی کوئی رنگ محفوظ نہیں کیا گیا۔</p>'}
function setLab(h){if(/^#[0-9a-fA-F]{6}$/.test(h)){$('#customColor').value=h;$('#customHex').value=h.toUpperCase();$('#labPreview').style.background=h;$('#labPreview').querySelector('span').textContent=h.toUpperCase()}}
$('#customColor').addEventListener('input',e=>setLab(e.target.value));
$('#customHex').addEventListener('input',e=>{let h=e.target.value;if(/^#[0-9a-fA-F]{6}$/.test(h))setLab(h)});
$('#saveColor').addEventListener('click',()=>{const h=$('#customHex').value.toUpperCase();if(/^#[0-9A-F]{6}$/.test(h)){if(!saved.includes(h))saved.push(h);localStorage.setItem('rangSaved',JSON.stringify(saved));renderSaved();toast('رنگ آپ کی پیلیٹ میں محفوظ ہوگیا')}})
function adjust(f){const h=$('#customHex').value,A=h.slice(1).match(/../g).map(x=>parseInt(x,16));const n=A.map(v=>f(v));setLab('#'+n.map(v=>v.toString(16).padStart(2,'0')).join(''))}
$('#lighten').addEventListener('click',()=>adjust(v=>Math.min(255,Math.round(v+(255-v)*.2))));
$('#darken').addEventListener('click',()=>adjust(v=>Math.max(0,Math.round(v*.8))));
$('#copyHex').addEventListener('click',async()=>{await navigator.clipboard?.writeText($('#customHex').value);toast('HEX کوڈ کاپی ہوگیا')});
function toast(t){const x=$('#toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),1800)}
setLab('#6C5CE7');renderSaved();

$('#themeBtn').addEventListener('click',()=>{document.body.classList.toggle('dark');$('#themeBtn').textContent=document.body.classList.contains('dark')?'☀':'☾';localStorage.setItem('dark',document.body.classList.contains('dark'))});
if(localStorage.getItem('dark')==='true'){document.body.classList.add('dark');$('#themeBtn').textContent='☀'}
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
