(() => {
  const $ = id => document.getElementById(id);
  const messages = $('messages');
  const hero = document.querySelector('.hero');
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let voices = [];
  const state = {
    speak: localStorage.getItem('jarvisSpeak') !== 'false',
    name: localStorage.getItem('jarvisName') || '',
    voice: localStorage.getItem('jarvisVoice') || ''
  };

  function addMessage(role, text) {
    const item = document.createElement('div');
    item.className = `message ${role}`;
    const avatar = document.createElement('div'); avatar.className = 'avatar'; avatar.textContent = role === 'assistant' ? 'J' : 'Y';
    const bubble = document.createElement('div'); bubble.className = 'bubble';
    const label = document.createElement('small'); label.textContent = `${role === 'assistant' ? 'JARVIS' : 'YOU'} · ${new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}`;
    const p = document.createElement('p'); p.textContent = text;
    bubble.append(label,p); item.append(avatar,bubble); messages.append(item); messages.scrollTop = messages.scrollHeight;
  }
  function say(text) {
    if (!state.speak || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    const voice = voices.find(v => v.name === state.voice);
    if (voice) utterance.voice = voice;
    utterance.rate = 0.96; utterance.pitch = 0.92;
    window.speechSynthesis.speak(utterance);
  }
  function reply(text) { addMessage('assistant', text); say(text); $('statusText').textContent = 'RESPONSE DELIVERED'; }
  function processCommand(raw) {
    const text = raw.trim(); if (!text) return;
    addMessage('user', text); $('messageInput').value = '';
    const q = text.toLowerCase();
    let answer;
    if (/\b(hello|hi|hey|good morning|good afternoon|good evening)\b/.test(q)) {
      answer = `Hello${state.name ? ' '+state.name : ''}. JARVIS is online and ready to assist.`;
    } else if (q.includes('time')) {
      answer = `The current time is ${new Date().toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}.`;
    } else if (q.includes('date') || q.includes('day is it')) {
      answer = `Today is ${new Date().toLocaleDateString([], {weekday:'long',year:'numeric',month:'long',day:'numeric'})}.`;
    } else if (q.includes('your name') || q.includes('who are you')) {
      answer = 'I am JARVIS, your personal assistant interface. My systems are ready.';
    } else if (q.includes('help') || q.includes('what can you do') || q.includes('commands')) {
      answer = 'I can tell you the time and date, greet you, remember your preferred name on this device, speak responses, and open useful websites. This starter build does not yet have a connected general-purpose AI brain. We can add that in a later version using a secure AI service.';
    } else if (q.includes('remember my name is')) {
      const name = text.split(/remember my name is/i).pop().trim().replace(/[.!?]+$/,'').slice(0,32);
      if (name) { state.name = name; localStorage.setItem('jarvisName', name); answer = `Understood. I will address you as ${name} on this device.`; }
      else answer = 'Please tell me the name you would like me to remember.';
    } else if (q.includes('open youtube')) {
      answer = 'Opening YouTube in your browser.'; window.open('https://www.youtube.com/', '_blank');
    } else if (q.includes('open google') || q.includes('search the web')) {
      answer = 'Opening Google in your browser.'; window.open('https://www.google.com/', '_blank');
    } else if (q.includes('how are you')) {
      answer = 'All systems are operating within normal parameters. Thank you for asking.';
    } else if (q.includes('thank')) {
      answer = 'You are most welcome. Always happy to help.';
    } else {
      answer = `I have received your message${state.name ? ', '+state.name : ''}. My basic offline mode can handle commands such as time, date, help, and opening websites. To answer general questions intelligently, this app will need a secure connection to an AI service.`;
    }
    window.setTimeout(() => reply(answer), 180);
  }
  $('sendBtn').addEventListener('click', () => processCommand($('messageInput').value));
  $('messageInput').addEventListener('keydown', e => { if (e.key === 'Enter') processCommand($('messageInput').value); });
  document.querySelectorAll('.quick-card').forEach(btn => btn.addEventListener('click', () => processCommand(btn.dataset.command)));
  $('clearBtn').addEventListener('click', () => { messages.replaceChildren(); reply('Conversation cleared. I am ready for your next command.'); });

  function setListening(on) {
    $('micBtn').classList.toggle('active', on); hero.classList.toggle('listening', on);
    $('micLabel').textContent = on ? 'LISTENING… TAP TO STOP' : 'TAP TO SPEAK';
    $('statusText').textContent = on ? 'VOICE INPUT ACTIVE' : 'AWAITING YOUR COMMAND';
  }
  $('micBtn').addEventListener('click', () => {
    if (!SpeechRecognition) { reply('Voice recognition is not supported by this browser. Try Chrome on Android, allow microphone access, or type your command instead.'); return; }
    if (recognition) { recognition.stop(); return; }
    recognition = new SpeechRecognition(); recognition.lang = 'en-US'; recognition.interimResults = false; recognition.maxAlternatives = 1;
    recognition.onstart = () => setListening(true);
    recognition.onresult = e => processCommand(e.results[0][0].transcript);
    recognition.onerror = e => { setListening(false); reply(e.error === 'not-allowed' ? 'Microphone permission was denied. Please allow microphone access in your browser or app settings.' : `Voice input encountered an issue: ${e.error}. You can type your command instead.`); };
    recognition.onend = () => { recognition = null; setListening(false); };
    try { recognition.start(); } catch (_) { recognition = null; setListening(false); }
  });

  function loadVoices() {
    if (!('speechSynthesis' in window)) return;
    voices = window.speechSynthesis.getVoices();
    const select = $('voiceSelect'); select.replaceChildren(new Option('Default device voice',''));
    voices.filter(v => /^en/i.test(v.lang)).forEach(v => select.add(new Option(`${v.name} (${v.lang})`,v.name)));
    select.value = state.voice;
  }
  $('settingsBtn').addEventListener('click', () => { $('settingsModal').classList.remove('hidden'); $('speechToggle').checked = state.speak; $('userName').value = state.name; loadVoices(); });
  $('closeSettings').addEventListener('click', () => $('settingsModal').classList.add('hidden'));
  $('settingsModal').addEventListener('click', e => { if (e.target === $('settingsModal')) $('settingsModal').classList.add('hidden'); });
  $('saveSettings').addEventListener('click', () => {
    state.speak = $('speechToggle').checked; state.name = $('userName').value.trim().slice(0,32); state.voice = $('voiceSelect').value;
    localStorage.setItem('jarvisSpeak', state.speak); localStorage.setItem('jarvisName', state.name); localStorage.setItem('jarvisVoice', state.voice);
    $('settingsModal').classList.add('hidden'); reply('Settings saved on this device.');
  });
  if ('speechSynthesis' in window) { loadVoices(); window.speechSynthesis.onvoiceschanged = loadVoices; }
  if (!SpeechRecognition) $('micLabel').textContent = 'VOICE INPUT MAY NOT BE AVAILABLE';
})();