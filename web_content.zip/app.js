(function () {
'use strict';
var $ = function (s) { return document.querySelector(s); };
var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
var app = $('#app'), scr = $('#screens'), au = new Audio();
au.preload = 'metadata';

/* ---------- icons ---------- */
var P = {
home:'<path d="M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z"/>',
search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
lib:'<path d="M4 4v16M9 4v16M14 6l6 14"/>',
heart:'<path d="M12 20s-8-5-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 9c0 6-8 11-8 11z"/>',
play:'<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>',
pause:'<rect x="6" y="4.5" width="4" height="15" rx="1" fill="currentColor"/><rect x="14" y="4.5" width="4" height="15" rx="1" fill="currentColor"/>',
next:'<path d="M6 5v14l10-7z" fill="currentColor"/><path d="M19 5v14"/>',
prev:'<path d="M18 5v14L8 12z" fill="currentColor"/><path d="M5 5v14"/>',
shuffle:'<path d="M3 7h3c4 0 5 10 9 10h6M3 17h3c1.5 0 2.5-1.5 3.5-3M14.5 10C15.5 8.5 16.5 7 18 7h3M18 4l3 3-3 3M18 14l3 3-3 3"/>',
repeat:'<path d="M4 11V9a3 3 0 0 1 3-3h13M17 3l3 3-3 3M20 13v2a3 3 0 0 1-3 3H4M7 21l-3-3 3-3"/>',
down:'<path d="m6 9 6 6 6-6"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
back:'<path d="m15 5-7 7 7 7"/>',
trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
star:'<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
note:'<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>'
};
function ico(n) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + P[n] + '</svg>'; }
function paint(r) { (r || document).querySelectorAll('[data-i]').forEach(function (e) { e.innerHTML = ico(e.dataset.i); }); }
function put(el, h) { el.innerHTML = h; paint(el); }
function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
function hash(s) { var a = 7; for (var i = 0; i < s.length; i++) a = (a * 31 + s.charCodeAt(i)) >>> 0; return a % 360; }
function grad(h) { return 'linear-gradient(135deg,hsl(' + h + ',55%,48%),hsl(' + ((h + 50) % 360) + ',60%,26%))'; }
function fmt(s) { return isFinite(s) ? Math.floor(s / 60) + ':' + ('0' + Math.floor(s % 60)).slice(-2) : '0:00'; }
function cnt(n) { return n + (n === 1 ? ' song' : ' songs'); }

/* ---------- storage: IndexedDB untuk file lagu ---------- */
var persist = true;
var DB = {
  db: null,
  open: function () {
    var self = this;
    return new Promise(function (ok, no) {
      if (!window.indexedDB) return no(new Error('no idb'));
      var r = indexedDB.open('nada', 1);
      r.onupgradeneeded = function () { r.result.createObjectStore('songs', {keyPath: 'id'}); };
      r.onsuccess = function () { self.db = r.result; ok(); };
      r.onerror = function () { no(r.error); };
    });
  },
  tx: function (mode, fn) {
    var self = this;
    return new Promise(function (ok, no) {
      var t = self.db.transaction('songs', mode), req = fn(t.objectStore('songs'));
      t.oncomplete = function () { ok(req && req.result); };
      t.onerror = t.onabort = function () { no(t.error); };
    });
  },
  put: function (v) { return this.tx('readwrite', function (s) { return s.put(v); }); },
  del: function (id) { return this.tx('readwrite', function (s) { return s.delete(id); }); },
  all: function () { return this.tx('readonly', function (s) { return s.getAll(); }); }
};

/* ---------- data ---------- */
var T = {}, ORDER = [];
function addT(t) { T[t.id] = t; ORDER.push(t.id); }

var liked = new Set(), recent = [];
try { liked = new Set(JSON.parse(localStorage.getItem('nada-liked') || '[]')); recent = JSON.parse(localStorage.getItem('nada-recent') || '[]'); } catch (_) {}
function save() {
  try {
    localStorage.setItem('nada-liked', JSON.stringify(Array.from(liked).filter(function (i) { return T[i]; })));
    localStorage.setItem('nada-recent', JSON.stringify(recent.filter(function (i) { return T[i]; })));
  } catch (_) {}
}

/* ---------- state ---------- */
var queue = [], qi = -1, cur = null, shuffle = false, rep = 0, drag = false;
var curList = null, prevS = 'home', qIds = [], npOpen = false, skipPop = false;

function lists() {
  return [
    {id: 'liked', name: 'Liked Songs', ids: ORDER.filter(function (i) { return liked.has(i); })},
    {id: 'all', name: 'All Songs', ids: ORDER.slice()}
  ];
}
function findList(id) { return lists().filter(function (l) { return l.id === id; })[0]; }
function ctxIds(c) {
  if (c === 'all') return ORDER.slice();
  if (c === 'rec') return recent.filter(function (i) { return T[i]; });
  if (c === 'q') return qIds;
  var l = findList(c); return l ? l.ids : [];
}
function cov(l, cls) {
  cls = cls || '';
  return l.id === 'liked'
    ? '<span class="cv ' + cls + '" style="background:linear-gradient(135deg,#5b4cf0,#9b8cff)"><span class="ci fill" data-i="heart"></span></span>'
    : '<span class="cv ' + cls + '" style="background:' + grad(hash(l.id)) + '"><span class="ci" data-i="note"></span></span>';
}
function tcov(t) { return '<span class="cv" style="background:' + grad(t.hue) + '"><span class="ci" data-i="note"></span></span>'; }
function row(id, ctx) {
  var t = T[id];
  return '<div class="tr' + (cur === id ? ' now' : '') + '" data-play="' + id + '" data-ctx="' + ctx + '" role="button" tabindex="0">' + tcov(t) +
    '<div class="tx"><b>' + esc(t.title) + '</b><small>' + esc(t.artist) + '</small></div>' +
    (ctx === 'all' ? '<button class="ib" data-del="' + id + '" data-i="trash" aria-label="Remove song"></button>' : '') +
    '<button class="ib lk' + (liked.has(id) ? ' on' : '') + '" data-like="' + id + '" data-i="heart" aria-label="Like"></button></div>';
}

/* ---------- helpers ---------- */
var tT;
function toast(t) { var e = $('#toast'); e.textContent = t; e.classList.add('show'); clearTimeout(tT); tT = setTimeout(function () { e.classList.remove('show'); }, 3000); }
function shuf(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), x = a[i]; a[i] = a[j]; a[j] = x; } return a; }

/* ---------- render ---------- */
function renderHome() {
  var L = lists();
  put($('#quick'), L.map(function (l) { return '<button class="qt" data-open="' + l.id + '">' + cov(l) + '<span>' + esc(l.name) + '</span></button>'; }).join(''));
  var r = recent.filter(function (i) { return T[i]; }).slice(0, 5);
  $('#recW').hidden = !r.length;
  put($('#rec'), r.map(function (i) { return row(i, 'rec'); }).join(''));
  put($('#hs'), !ORDER.length ? '<p class="empty" style="width:100%">No songs yet.<br>Tap + to add music from your device.</p>' : ORDER.map(function (i) { return '<button class="hc" data-play="' + i + '" data-ctx="all">' + tcov(T[i]) + '<b>' + esc(T[i].title) + '</b><small>' + esc(T[i].artist) + '</small></button>'; }).join(''));
}
function renderSearch() {
  var raw = $('#q').value.trim(), q = raw.toLowerCase();
  if (!q) {
    qIds = [];
    put($('#sres'), '<h2 style="margin-top:4px">Browse all</h2><div class="bt-g">' + lists().map(function (l) {
      return '<button class="bt" data-open="' + l.id + '" style="background:' + (l.id === 'liked' ? 'linear-gradient(135deg,#5b4cf0,#9b8cff)' : grad(hash(l.id))) + '">' + esc(l.name) + '</button>';
    }).join('') + '</div>');
    return;
  }
  qIds = ORDER.filter(function (i) { return (T[i].title + ' ' + T[i].artist).toLowerCase().indexOf(q) > -1; });
  put($('#sres'), qIds.length ? qIds.map(function (i) { return row(i, 'q'); }).join('') : '<p class="empty">No results for “' + esc(raw) + '”.</p>');
}
function renderLib() {
  put($('#lib'), lists().map(function (l) {
    return '<button class="tr lib" data-open="' + l.id + '">' + cov(l) + '<div class="tx"><b>' + esc(l.name) + '</b><small>Playlist · ' + cnt(l.ids.length) + '</small></div></button>';
  }).join('') + '<button class="tr lib" data-act="addfiles"><span class="cv" style="background:var(--surf2)"><span class="ci fill" data-i="plus"></span></span><div class="tx"><b>Add songs</b><small>From this device</small></div></button>');
}
function renderDetail() {
  var l = findList(curList);
  if (!l) { curList = null; if (app.dataset.s === 'detail') go(prevS); return; }
  put($('#dh'), cov(l, 'xl') + '<h2>' + esc(l.name) + '</h2><div class="da"><span>' + cnt(l.ids.length) + '</span><span><button class="ib sf' + (shuffle ? ' on' : '') + '" data-i="shuffle" data-act="shufplay" aria-label="Shuffle play"></button><button class="pbig" data-i="play" data-act="playlist" aria-label="Play"></button></span></div>');
  put($('#dl'), l.ids.length ? l.ids.map(function (i) { return row(i, l.id); }).join('') : '<p class="empty">' + (l.id === 'liked' ? 'Tap the heart on any song to save it here.' : 'No songs yet. Tap + on Home or Library to add some.') + '</p>');
}
function renderAll() { renderHome(); renderSearch(); renderLib(); if (curList) renderDetail(); ui(); }

/* ---------- navigation ---------- */
function go(n) {
  app.dataset.s = n;
  $$('.screen').forEach(function (s) { s.classList.toggle('on', s.id === n); });
  var hl = n === 'detail' ? prevS : n;
  $$('.nv').forEach(function (b) { b.classList.toggle('on', b.dataset.go === hl); });
  scr.scrollTop = 0;
}
function openList(id) {
  if (app.dataset.s !== 'detail') prevS = app.dataset.s;
  curList = id; renderDetail();
  if (app.dataset.s !== 'detail') { go('detail'); try { history.pushState({d: 1}, ''); } catch (_) {} }
}
function openNp() { if (npOpen || !cur) return; npOpen = true; $('#np').classList.add('open'); try { history.pushState({np: 1}, ''); } catch (_) {} }
function closeNp(fromPop) {
  if (!npOpen) return;
  npOpen = false; $('#np').classList.remove('open');
  if (!fromPop) { skipPop = true; try { history.back(); } catch (_) { skipPop = false; } }
}
window.addEventListener('popstate', function () {
  if (skipPop) { skipPop = false; return; }
  if (npOpen) closeNp(true);
  else if (app.dataset.s === 'detail') go(prevS);
});

/* ---------- player ---------- */
function playList(ids, id, forceShuffle) {
  if (!ids.length) return;
  if (forceShuffle) shuffle = true;
  var q = ids.slice();
  if (shuffle) { q = shuf(q); if (id) { q = q.filter(function (x) { return x !== id; }); q.unshift(id); } }
  queue = q; qi = id ? q.indexOf(id) : 0;
  load(true);
}
function load(play) {
  cur = queue[qi];
  au.src = T[cur].url;
  if (play) { var p = au.play(); if (p && p.catch) p.catch(function () {}); }
  recent = [cur].concat(recent.filter(function (x) { return x !== cur; })).slice(0, 20); save();
  if (app.dataset.s === 'home') renderHome();
  ui(); media();
}
function next(auto) {
  if (!queue.length) return;
  if (qi < queue.length - 1) qi++;
  else if (rep === 1 || !auto) qi = 0;
  else { au.pause(); au.currentTime = 0; return; }
  load(true);
}
function prev() {
  if (!queue.length) return;
  if (au.currentTime > 3 || qi === 0) { au.currentTime = 0; return; }
  qi--; load(true);
}
function toggle() {
  if (!cur) return;
  if (au.paused) { var p = au.play(); if (p && p.catch) p.catch(function () { toast('Could not play this song.'); }); } else au.pause();
}
function setShuffle() {
  shuffle = !shuffle;
  if (shuffle && cur) { queue = [cur].concat(shuf(queue.filter(function (x) { return x !== cur; }))); qi = 0; }
  ui(); if (curList) renderDetail();
}
function like(id) { if (liked.has(id)) liked['delete'](id); else liked.add(id); save(); renderAll(); }

function ui() {
  var t = cur && T[cur];
  $('#mini').hidden = !t;
  $('#shuf').classList.toggle('on', shuffle);
  $('#rep').classList.toggle('on', rep > 0);
  $('#rep').dataset.r = rep;
  $$('.tr').forEach(function (r) { r.classList.toggle('now', r.dataset.play === cur); });
  pp();
  if (!t) { if (npOpen) closeNp(); return; }
  $('#np').style.setProperty('--h', t.hue); $('#mini').style.setProperty('--h', t.hue);
  $('#mT').textContent = $('#npT').textContent = t.title;
  $('#mA').textContent = $('#npA').textContent = t.artist;
  $('#mCv').style.background = $('#npCv').style.background = grad(t.hue);
  var nx = queue[qi + 1] || (rep === 1 ? queue[0] : null);
  $('#upN').textContent = nx && T[nx] ? T[nx].title : 'End of queue';
  $('#npLike').classList.toggle('on', liked.has(cur));
}
function pp() {
  $$('.pp').forEach(function (b) { b.innerHTML = ico(au.paused ? 'play' : 'pause'); b.setAttribute('aria-label', au.paused ? 'Play' : 'Pause'); });
  var on = !au.paused && !!cur;
  $('#mini').classList.toggle('playing', on); $('#np').classList.toggle('playing', on);
  if ('mediaSession' in navigator) { try { navigator.mediaSession.playbackState = !cur ? 'none' : au.paused ? 'paused' : 'playing'; } catch (_) {} }
}
function tick() {
  var d = au.duration, ok = isFinite(d) && d > 0, v = ok ? au.currentTime / d * 1000 : 0;
  if (!drag) { $('#seek').value = v; $('#seek').style.setProperty('--p', v / 10 + '%'); $('#t1').textContent = fmt(au.currentTime); }
  $('#t2').textContent = ok ? fmt(d) : '0:00';
  $('#mini').style.setProperty('--pp', (v / 10) + '%');
  if (ok && 'mediaSession' in navigator && navigator.mediaSession.setPositionState) {
    try { navigator.mediaSession.setPositionState({duration: d, position: Math.min(au.currentTime, d), playbackRate: 1}); } catch (_) {}
  }
}
au.addEventListener('timeupdate', tick);
au.addEventListener('loadedmetadata', tick);
au.addEventListener('play', pp);
au.addEventListener('pause', pp);
au.addEventListener('ended', function () { if (rep === 2) { au.currentTime = 0; au.play(); } else next(true); });
au.addEventListener('error', function () { if (cur) { toast('This song could not be loaded. Check your connection or file.'); pp(); } });

var sk = $('#seek');
sk.addEventListener('input', function () {
  drag = true; sk.style.setProperty('--p', sk.value / 10 + '%');
  if (isFinite(au.duration)) $('#t1').textContent = fmt(sk.value / 1000 * au.duration);
});
sk.addEventListener('change', function () {
  if (isFinite(au.duration)) au.currentTime = sk.value / 1000 * au.duration;
  drag = false;
});
['pointerup', 'touchend', 'mouseup'].forEach(function (ev) { sk.addEventListener(ev, function () { setTimeout(function () { drag = false; }, 80); }); });

function media() {
  if (!('mediaSession' in navigator) || !cur) return;
  try { navigator.mediaSession.metadata = new MediaMetadata({title: T[cur].title, artist: T[cur].artist}); } catch (_) {}
}
if ('mediaSession' in navigator) {
  var h = function (a, f) { try { navigator.mediaSession.setActionHandler(a, f); } catch (_) {} };
  h('play', toggle); h('pause', toggle); h('previoustrack', prev); h('nexttrack', function () { next(false); });
  h('seekto', function (d) { if (d && isFinite(d.seekTime)) au.currentTime = d.seekTime; });
}

/* ---------- files ---------- */
$('#fAudio').onchange = async function (e) {
  var fs = Array.prototype.slice.call(e.target.files).filter(function (f) { return f.type.indexOf('audio/') === 0 || /\.(mp3|m4a|wav|ogg|flac|aac|opus)$/i.test(f.name); });
  e.target.value = '';
  if (!fs.length) return toast('Choose audio files (mp3, m4a, wav, ogg).');
  var n = 0;
  for (var k = 0; k < fs.length; k++) {
    var f = fs[k], base = f.name.replace(/\.[^.]+$/, ''), m = base.match(/^(.+?)\s+-\s+(.+)$/);
    var t = {id: 'l' + Date.now().toString(36) + (n++), title: m ? m[2] : base, artist: m ? m[1] : 'On this device', url: URL.createObjectURL(f), local: true};
    t.hue = hash(t.title); addT(t);
    if (persist) { try { await DB.put({id: t.id, title: t.title, artist: t.artist, blob: f, added: Date.now() + n}); } catch (_) { persist = false; } }
  }
  renderAll();
  toast(persist ? cnt(fs.length) + ' added and saved.' : cnt(fs.length) + ' added, but storage is unavailable, so they will be lost on reload.');
};
async function removeSong(id) {
  var t = T[id]; if (!t) return;
  if (cur === id) { cur = null; queue = []; qi = -1; au.pause(); au.removeAttribute('src'); au.load(); }
  else { queue = queue.filter(function (x) { return x !== id; }); qi = cur ? queue.indexOf(cur) : -1; }
  try { URL.revokeObjectURL(t.url); } catch (_) {}
  delete T[id]; ORDER.splice(ORDER.indexOf(id), 1); liked['delete'](id); recent = recent.filter(function (x) { return x !== id; });
  try { await DB.del(id); } catch (_) {}
  save(); renderAll(); toast('Song removed.');
}

/* ---------- events ---------- */
var A = {
  pp: toggle, next: function () { next(false); }, prev: prev,
  shuffle: setShuffle,
  repeat: function () { rep = (rep + 1) % 3; ui(); },
  likecur: function () { if (cur) like(cur); },
  opennp: openNp, closenp: function () { closeNp(false); },
  addfiles: function () { $('#fAudio').click(); },
  editname: editName,
  back: function () { try { history.back(); } catch (_) { go(prevS); } },
  playlist: function () { var l = findList(curList); if (l) playList(l.ids); },
  shufplay: function () { var l = findList(curList); if (l) playList(l.ids, null, true); renderDetail(); }
};
document.addEventListener('click', function (e) {
  var t = e.target, x;
  if ((x = t.closest('[data-del]'))) { removeSong(x.dataset.del); return; }
  if ((x = t.closest('[data-like]'))) { like(x.dataset.like); return; }
  if ((x = t.closest('[data-act]')) && A[x.dataset.act]) { A[x.dataset.act](x); return; }
  if ((x = t.closest('[data-go]'))) { go(x.dataset.go); return; }
  if ((x = t.closest('[data-open]'))) { openList(x.dataset.open); return; }
  if ((x = t.closest('[data-play]'))) playList(ctxIds(x.dataset.ctx), x.dataset.play);
});
document.addEventListener('keydown', function (e) {
  var r = e.target.getAttribute && e.target.getAttribute('role');
  if ((e.key === 'Enter' || e.key === ' ') && r === 'button') { e.preventDefault(); e.target.click(); }
  if (e.key === 'Escape') closeNp(false);
});
$('#q').addEventListener('input', renderSearch);

/* ---------- init ---------- */
var uname = '';
try { uname = localStorage.getItem('nada-name') || ''; } catch (_) {}
function greetText() {
  var h = new Date().getHours();
  var g = h >= 5 && h < 11 ? 'Selamat pagi' : h >= 11 && h < 15 ? 'Selamat siang' : h >= 15 && h < 18 ? 'Selamat sore' : 'Selamat malam';
  return uname ? g + ', ' + uname : g;
}
function setGreet() { $('#greet').textContent = greetText(); if ($('#nameIn').hidden) $('#ghint').hidden = !!uname; }
function editName() {
  var i = $('#nameIn');
  $('#greetBtn').hidden = true; $('#ghint').hidden = true;
  i.hidden = false; i.value = uname; i.focus(); i.select();
}
function commitName() {
  var i = $('#nameIn'); if (i.hidden) return;
  uname = i.value.trim().slice(0, 20);
  try { localStorage.setItem('nada-name', uname); } catch (_) {}
  i.hidden = true; $('#greetBtn').hidden = false; setGreet();
}
$('#nameIn').addEventListener('keydown', function (e) {
  if (e.key === 'Enter') { e.preventDefault(); e.target.blur(); }
  if (e.key === 'Escape') { e.target.value = uname; e.target.blur(); }
});
$('#nameIn').addEventListener('blur', commitName);
setGreet(); setInterval(setGreet, 60000);
document.addEventListener('visibilitychange', setGreet);
paint(); renderAll(); go('home');
(async function () {
  try {
    await DB.open();
    var rows = (await DB.all()).sort(function (a, b) { return a.added - b.added; });
    rows.forEach(function (r) { addT({id: r.id, title: r.title, artist: r.artist, url: URL.createObjectURL(r.blob), hue: hash(r.title), local: true}); });
    if (navigator.storage && navigator.storage.persist) navigator.storage.persist();
  } catch (_) { persist = false; }
  renderAll();
})();
})();
