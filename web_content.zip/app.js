const $ = s => document.querySelector(s);
const today = new Date().toISOString().slice(0,10);
let goals = JSON.parse(localStorage.getItem("ma3an_goals") || "null") || [
  {id:1,title:"شرب 6 أكواب ماء",priority:"high",done:false},
  {id:2,title:"قراءة 20 صفحة",priority:"medium",done:false},
  {id:3,title:"المشي لمدة 15 دقيقة",priority:"low",done:true}
];
let points = Number(localStorage.getItem("ma3an_points") || 120);

const labels={high:"عالية",medium:"متوسطة",low:"منخفضة"};
function save(){localStorage.setItem("ma3an_goals",JSON.stringify(goals));localStorage.setItem("ma3an_points",points)}
function render(){
  const box=$("#goals"); box.innerHTML="";
  goals.forEach(g=>{
    const el=document.createElement("div"); el.className="goal "+(g.done?"done":"");
    el.innerHTML=`<button class="check" aria-label="تغيير الحالة">${g.done?"✓":""}</button>
      <div class="goal-title">${escapeHtml(g.title)}</div>
      <span class="priority ${g.priority}">${labels[g.priority]}</span>
      <button class="delete" aria-label="حذف">×</button>`;
    el.querySelector(".check").onclick=()=>{g.done=!g.done;points+=g.done?10:-10;save();render();toast(g.done?"أحسنت! +10 نقاط":"تم إرجاع الهدف");};
    el.querySelector(".delete").onclick=()=>{goals=goals.filter(x=>x.id!==g.id);save();render();toast("تم حذف الهدف")};
    box.appendChild(el);
  });
  const done=goals.filter(g=>g.done).length, pct=goals.length?Math.round(done/goals.length*100):0;
  $("#totalGoals").textContent=goals.length; $("#doneToday").textContent=done; $("#points").textContent=Math.max(0,points);
  $("#heroPercent").textContent=pct+"%"; $("#streak").textContent=done?3:0;
  $("#date").textContent=new Intl.DateTimeFormat("ar",{weekday:"long",day:"numeric",month:"long"}).format(new Date());
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function add(title,priority){
  title=title.trim(); if(!title)return;
  goals.unshift({id:Date.now(),title,priority,done:false});save();render();toast("تمت إضافة الهدف 🎯");
}
$("#quickAdd").onclick=()=>{add($("#goalInput").value,$("#priority").value);$("#goalInput").value=""};
$("#addGoalBtn").onclick=()=>$("#goalDialog").showModal();
$("#goalForm").addEventListener("submit",e=>{e.preventDefault();add($("#dialogInput").value,$("#dialogPriority").value);$("#dialogInput").value="";$("#goalDialog").close()});
$("#themeBtn").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("ma3an_dark",document.body.classList.contains("dark"))};
if(localStorage.getItem("ma3an_dark")==="true")document.body.classList.add("dark");
function toast(t){const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
render();
