const API_KEY='grapevine_api_url';
const DEFAULT={settings:{name:'GRAPEVINE',motto:'Code Today. Build Tomorrow. Inspire Forever.',description:'A software engineering group built around collaboration, innovation and practical technology.',email:'grapevine@example.com',phone:'+256 700 000 000',location:'Uganda'},members:Array.from({length:11},(_,i)=>({id:'m'+(i+1),name:'Member '+(i+1),role:'Software Engineering Team',bio:'GRAPEVINE member profile. Update this profile from the admin dashboard.',skills:['Programming','Teamwork'],verified:false,photo:''})),projects:[{id:'p1',title:'Project One',description:'Project description and results.',tags:['Web','Software']},{id:'p2',title:'Project Two',description:'Database and systems project.',tags:['Database','Systems']},{id:'p3',title:'Project Three',description:'Mobile innovation project.',tags:['Mobile','Innovation']}],skills:[{id:'s1',title:'Web Development',description:'HTML, CSS, JavaScript, PHP and responsive interfaces.'},{id:'s2',title:'Programming',description:'Algorithms, OOP and software design.'},{id:'s3',title:'Databases',description:'MySQL, database design and data management.'},{id:'s4',title:'UI / UX',description:'Wireframes, usability and interface design.'}],gallery:[{id:'g1',title:'Our identity',image:'assets/grapevine-logo.jpg'}]};
let state=load(); let route='home'; let localAdmin=localStorage.getItem('gv_local_admin')||''; let adminSession=false; let syncTimer=null;
function load(){try{return JSON.parse(localStorage.getItem('gv_state'))||structuredClone(DEFAULT)}catch{return structuredClone(DEFAULT)}}
function save(){localStorage.setItem('gv_state',JSON.stringify(state))}
function online(){return navigator.onLine}
function apiUrl(){return localStorage.getItem(API_KEY)||''}
async function api(path,opts={}){if(!apiUrl())throw Error('No server URL configured');const r=await fetch(apiUrl().replace(/\/$/,'')+path,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{}),...(adminToken?{Authorization:'Bearer '+adminToken}:{})}});if(!r.ok)throw Error(await r.text());return r.status===204?null:r.json()}
async function sync(){if(!online()||!apiUrl())return;try{const remote=await api('/api/state');if(remote&&remote.updatedAt){state=remote.data;save();render()}}catch(e){} }
window.addEventListener('online',()=>{sync();toast('Back online')}); window.addEventListener('offline',()=>toast('Offline mode: cached data remains available'));
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function render(){document.getElementById('app').innerHTML=`<div class="shell"><header class="top"><div class="brand"><img src="assets/grapevine-logo.jpg"><div><b>${esc(state.settings.name)}</b><small>Software Engineering Group</small></div></div><span class="status ${online()?'online':'offline'}">${online()?'ONLINE':'OFFLINE'}</span></header><main class="content">${view()}</main>${bottom()}</div>`}
function bottom(){return `<nav class="bottom">${[['home','⌂','Home'],['members','♙','Members'],['projects','▣','Projects'],['gallery','▧','Gallery'],['admin','⚙','Admin']].map(x=>`<button class="${route===x[0]?'active':''}" onclick="go('${x[0]}')"><span>${x[1]}</span>${x[2]}</button>`).join('')}</nav>`}
function view(){
if(route==='members')return members();
if(route==='projects')return projects();
if(route==='gallery')return gallery();
if(route==='admin'||route.startsWith('admin-'))return admin();
return home()
}
function home(){return `<section class="hero"><img src="assets/grapevine-logo.jpg"><div class="eyebrow">SOFTWARE ENGINEERING • CREATIVITY • TEAMWORK</div><h1>We Code. We Build. We Inspire.</h1><p>${esc(state.settings.description)}</p><p><b>${esc(state.settings.motto)}</b></p><div class="actions"><button class="btn gold" onclick="go('members')">Meet Members</button><button class="btn light" onclick="go('projects')">Explore Work</button></div></section><h2>GRAPEVINE at a glance</h2><div class="grid"><div class="card"><div class="stat">${state.members.length}</div><p>Members</p></div><div class="card"><div class="stat">${state.projects.length}</div><p>Projects</p></div><div class="card"><div class="stat">${state.skills.length}</div><p>Skills</p></div><div class="card"><div class="stat">${state.gallery.length}</div><p>Gallery items</p></div></div><div class="card" style="margin-top:14px"><div class="eyebrow">CONTACT</div><h3>${esc(state.settings.email)}</h3><p>${esc(state.settings.phone)} • ${esc(state.settings.location)}</p></div>`}
function members(){return `<div class="admin-head"><div><div class="eyebrow">THE TEAM</div><h2>Members</h2></div></div><div class="search"><input placeholder="Search members" oninput="filterMembers(this.value)"></div><div id="memberList">${memberCards(state.members)}</div>`}
function verificationBadge(compact=false){return `<span class="verification-badge${compact?' compact':''}" title="Verified GRAPEVINE member" aria-label="Verified GRAPEVINE member"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.5l2.2 1.1 2.45-.1 1.25 2.1 2.1 1.25-.1 2.45L21 11.5l-1.1 2.2.1 2.45-2.1 1.25-1.25 2.1-2.45-.1L12 20.5l-2.2-1.1-2.45.1-1.25-2.1L4 16.15l.1-2.45L3 11.5l1.1-2.2L4 6.85l2.1-1.25 1.25-2.1 2.45.1L12 2.5z"></path><path class="check" d="M8.1 12.2l2.5 2.5 5.3-5.4"></path></svg>${compact?'':'<span>Verified</span>'}</span>`}
function memberCards(arr){return arr.map(m=>`<article class="card member"><img class="photo" src="${esc(m.photo||'assets/grapevine-logo.jpg')}"><div class="member-main"><div class="member-name"><h3 style="margin:0">${esc(m.name)}</h3>${m.verified?verificationBadge(true):''}</div><div class="small">${esc(m.role)}</div><p>${esc(m.bio)}</p><div>${(m.skills||[]).map(s=>`<span class="tag">${esc(s)}</span>`).join('')}</div></div></article>`).join('')||'<div class="empty">No members found.</div>'}
function filterMembers(q){const x=q.toLowerCase();document.getElementById('memberList').innerHTML=memberCards(state.members.filter(m=>(m.name+' '+m.role).toLowerCase().includes(x)))}
function projects(){return `<div class="eyebrow">OUR WORK</div><h2>Projects</h2><div class="grid">${state.projects.map(p=>`<article class="card"><div class="eyebrow">PROJECT</div><h3>${esc(p.title)}</h3><p>${esc(p.description)}</p>${(p.tags||[]).map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</article>`).join('')}</div>`}
function gallery(){return `<div class="eyebrow">MEMORIES</div><h2>Gallery</h2><div class="grid">${state.gallery.map(g=>`<article class="card"><img style="width:100%;aspect-ratio:1.2;object-fit:cover;border-radius:12px" src="${esc(g.image||'assets/grapevine-logo.jpg')}"><h3>${esc(g.title)}</h3></article>`).join('')}</div>`}
function admin(){if(!localAdmin)return `<section class="card"><div class="eyebrow">DEVICE ADMIN</div><h2>Admin Dashboard</h2><p>This standalone version has no server. Create an administrator PIN on this device. Your changes are saved locally and can be exported for manual distribution to other phones.</p><div class="field"><label>Create admin PIN</label><input id="newpin" type="password" inputmode="numeric" minlength="4" placeholder="At least 4 digits"></div><div class="field"><label>Confirm PIN</label><input id="newpin2" type="password" inputmode="numeric" minlength="4"></div><button class="btn primary" onclick="setupAdmin()">Create Admin</button></section>`;return adminSession?adminPanel():`<section class="card"><div class="eyebrow">DEVICE ADMIN</div><h2>Administrator sign in</h2><div class="field"><label>Admin PIN</label><input id="loginpin" type="password" inputmode="numeric"></div><button class="btn primary" onclick="localLogin()">Sign in</button></section>`}
function adminPanel(){return `<div class="admin-head"><div><div class="eyebrow">DEVICE CONTROL CENTER</div><h2>Admin Dashboard</h2></div><button class="btn light" onclick="logout()">Sign out</button></div><div class="admin-tabs">${['members','projects','skills','gallery','settings','data'].map(t=>`<button class="btn ${route==='admin-'+t?'primary':'light'}" onclick="adminSection('${t}')">${t}</button>`).join('')}</div>${route==='admin-members'?adminMembers():route==='admin-projects'?adminCollection('projects','Project'):route==='admin-skills'?adminCollection('skills','Skill'):route==='admin-gallery'?adminCollection('gallery','Gallery item'):route==='admin-data'?adminData():adminSettings()}`}
function adminMembers(){
const total=state.members.length;
const verified=state.members.filter(m=>m.verified).length;
const unverified=total-verified;
return `<section class="member-control">
<div class="control-hero">
<div><div class="eyebrow">ADMIN • MEMBER MANAGEMENT</div><h2>Member Control Centre</h2><p>Add, remove, rename and manage verification badges for every GRAPEVINE member.</p></div>
<button class="btn gold big" onclick="editMember()">＋ Add Member</button>
</div>
<div class="member-stats">
<div class="stat-card"><strong>${total}</strong><span>Total Members</span></div>
<div class="stat-card"><strong>${verified}</strong><span>Verified</span></div>
<div class="stat-card"><strong>${unverified}</strong><span>Unverified</span></div>
</div>
<div class="member-toolbar"><input id="memberSearchAdmin" placeholder="Search by member name or role" oninput="filterAdminMembers(this.value)"></div>
<div id="adminMemberList">${adminMemberRows(state.members)}</div>
</section>`
}
function adminMemberRows(arr){
return arr.map(m=>`<article class="admin-member-card">
<div class="admin-member-info">
<img class="admin-avatar" src="${esc(m.photo||'assets/grapevine-logo.jpg')}">
<div><div class="admin-member-name">${esc(m.name||'Unnamed Member')} ${m.verified?verificationBadge(false):'<span class="unverified">Not verified</span>'}</div>
<div class="small">${esc(m.role||'No role assigned')}</div></div>
</div>
<div class="admin-member-actions">
<button class="btn ${m.verified?'light':'gold'}" onclick="verifyMember('${m.id}',${!m.verified})">${m.verified?'Remove Badge':'Give Verification Badge'}</button>
<button class="btn light" onclick="editMember('${m.id}')">Edit Member</button>
<button class="btn danger" onclick="removeMember('${m.id}')">Remove Member</button>
</div>
</article>`).join('')||'<div class="empty">No members found.</div>'
}
function filterAdminMembers(q){
const x=(q||'').toLowerCase();
const el=document.getElementById('adminMemberList');
if(el)el.innerHTML=adminMemberRows(state.members.filter(m=>(m.name+' '+m.role).toLowerCase().includes(x)));
}
function adminCollection(key,label){return `<div class="actions"><button class="btn gold" onclick="editCollection('${key}')">+ Add ${label}</button></div><div>${state[key].map(x=>`<div class="row"><div><b>${esc(x.title)}</b><div class="small">${esc(x.description||x.image||'')}</div></div><div class="actions"><button class="btn light" onclick="editCollection('${key}','${x.id}')">Edit</button><button class="btn danger" onclick="removeItem('${key}','${x.id}')">Remove</button></div></div>`).join('')}</div>`}
function adminSettings(){const s=state.settings;return `<div class="card"><h3>App-wide settings</h3>${['name','motto','description','email','phone','location'].map(k=>`<div class="field"><label>${k}</label><input id="set-${k}" value="${esc(s[k]||'')}"></div>`).join('')}<button class="btn primary" onclick="saveSettings()">Save changes</button></div>`}
function adminData(){return `<div class="card"><div class="eyebrow">MANUAL DISTRIBUTION</div><h3>Move your latest data to another phone</h3><p>Export your current members, verification badges and content as a JSON file. Send that file to another user, then use Import on their copy of GRAPEVINE.</p><div class="actions"><button class="btn gold" onclick="exportData()">Export data</button><label class="btn light" for="importFile">Import data</label><input id="importFile" type="file" accept="application/json,.json" style="display:none" onchange="importData(this.files[0])"></div><div class="notice">This is a fully offline workflow. No data is uploaded anywhere.</div></div><div class="card"><h3>Administrator PIN</h3><p>Change the local administrator PIN for this device.</p><div class="field"><label>New PIN</label><input id="changePin" type="password" inputmode="numeric" minlength="4"></div><button class="btn primary" onclick="changePin()">Change PIN</button></div>`}
function localLogin(){const p=document.getElementById('loginpin').value;if(p===localAdmin){adminSession=true;route='admin-members';render()}else toast('Incorrect PIN')}
function setupAdmin(){const a=document.getElementById('newpin').value,b=document.getElementById('newpin2').value;if(a.length<4||a!==b){toast('PIN must match and contain at least 4 characters');return}localAdmin=a;localStorage.setItem('gv_local_admin',localAdmin);route='admin-members';render()}
function verifyAdmin(){const p=prompt('Enter admin PIN');if(p===localAdmin){route='admin-members';render()}else toast('Incorrect PIN')}
function logout(){adminSession=false;route='admin';render()}
function adminSection(k){if(!localAdmin||!adminSession){route='admin';render();return}route='admin-'+k;render()}
async function push(){save();toast('Saved on this device')}
async function syncNow(){save();toast('Saved locally')}
async function verifyMember(id,v){const m=state.members.find(x=>x.id===id);if(!m)return;m.verified=!!v;m.verifiedAt=v?new Date().toISOString():null;await push();render()}
async function removeItem(key,id){if(!confirm('Remove this item?'))return;state[key]=state[key].filter(x=>x.id!==id);await push();render()}
async function removeMember(id){
const m=state.members.find(x=>x.id===id);
if(!m)return;
if(!confirm('Remove '+(m.name||'this member')+' from GRAPEVINE?'))return;
state.members=state.members.filter(x=>x.id!==id);
await push();
render();
}
function editMember(id){
const m=id?state.members.find(x=>x.id===id):{id:'m'+Date.now(),name:'',role:'Software Engineering Team',bio:'',skills:[],verified:false,verifiedAt:null,photo:''};
openForm(id?'Edit Member':'Add New Member',m,async x=>{if(id)Object.assign(m,x);else state.members.push(x);await push();render()})
}
function editCollection(key,id){const item=id?state[key].find(x=>x.id===id):{id:key[0]+Date.now(),title:'',description:'',tags:[],image:''};openForm('Edit '+key.slice(0,-1),item,async x=>{if(id)Object.assign(item,x);else state[key].push(x);await push();render()})}
function openForm(title,item,done){const isMember=Object.prototype.hasOwnProperty.call(item,'name');document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="modal"><div class="sheet"><h2>${title}</h2>${isMember?`<div class="field"><label>Name</label><input id="f-name" value="${esc(item.name)}"></div><div class="field"><label>Role</label><input id="f-role" value="${esc(item.role)}"></div><div class="field"><label>Bio</label><textarea id="f-bio">${esc(item.bio)}</textarea></div><div class="field"><label>Skills (comma separated)</label><input id="f-skills" value="${esc((item.skills||[]).join(', '))}"></div><div class="field"><label>Photo URL (optional)</label><input id="f-photo" value="${esc(item.photo||'')}"></div><div class="field"><label>Verification Badge</label><select id="f-verified"><option value="false" ${!item.verified?'selected':''}>Not Verified</option><option value="true" ${item.verified?'selected':''}>Verified ✓ — Give Badge</option></select></div>`:`<div class="field"><label>Title</label><input id="f-title" value="${esc(item.title)}"></div><div class="field"><label>Description</label><textarea id="f-description">${esc(item.description||'')}</textarea></div><div class="field"><label>Tags (comma separated)</label><input id="f-tags" value="${esc((item.tags||[]).join(', '))}"></div>${item.image!==undefined?`<div class="field"><label>Image path</label><input id="f-image" value="${esc(item.image||'')}"></div>`:''}`}<div class="actions"><button class="btn light" onclick="document.getElementById('modal').remove()">Cancel</button><button class="btn primary" onclick="submitForm()">Save</button></div></div></div>`);window._form={item,isMember,done}}
async function submitForm(){const {item,isMember,done}=window._form;if(isMember){item.name=document.getElementById('f-name').value.trim();item.role=document.getElementById('f-role').value.trim();item.bio=document.getElementById('f-bio').value.trim();item.skills=document.getElementById('f-skills').value.split(',').map(x=>x.trim()).filter(Boolean);item.photo=document.getElementById('f-photo').value.trim();item.verified=document.getElementById('f-verified').value==='true';item.verifiedAt=item.verified?(item.verifiedAt||new Date().toISOString()):null}else{item.title=document.getElementById('f-title').value.trim();item.description=document.getElementById('f-description').value.trim();item.tags=document.getElementById('f-tags').value.split(',').map(x=>x.trim()).filter(Boolean);if(document.getElementById('f-image'))item.image=document.getElementById('f-image').value.trim()}document.getElementById('modal').remove();await done(item)}
async function saveSettings(){for(const k of Object.keys(state.settings)){const el=document.getElementById('set-'+k);if(el)state.settings[k]=el.value.trim()}await push();render()}
function exportData(){const blob=new Blob([JSON.stringify({format:'GRAPEVINE-OFFLINE-DATA',version:1,data:state},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='grapevine-data.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);toast('Data export created')}
async function importData(file){if(!file)return;try{const x=JSON.parse(await file.text());if(x.format!=='GRAPEVINE-OFFLINE-DATA'||!x.data?.members)throw Error('Invalid GRAPEVINE data file');state=x.data;save();render();toast('Data imported successfully')}catch(e){toast('Import failed: '+e.message)}}
function changePin(){const p=document.getElementById('changePin').value;if(p.length<4){toast('PIN must be at least 4 characters');return}localAdmin=p;localStorage.setItem('gv_local_admin',p);toast('PIN changed')}
function toast(msg){let t=document.getElementById('toast');if(!t){t=document.createElement('div');t.id='toast';Object.assign(t.style,{position:'fixed',left:'16px',right:'16px',bottom:'82px',zIndex:50,background:'#111827',color:'#fff',padding:'12px 14px',borderRadius:'12px',textAlign:'center'});document.body.appendChild(t)}t.textContent=msg;setTimeout(()=>t.remove(),2600)}

function go(r){if(r==='admin'){route='admin';render();return}route=r;render()} render();