let currentUser = null;
let currentRole = null;
let currentScreen = 'tasks';
let tasks = [];
let archive = [];
let brigadiers = [
  { id: 1, name: 'Иванов Сергей Петрович', active: true },
  { id: 2, name: 'Сидоров Алексей Николаевич', active: true },
  { id: 3, name: 'Петров Дмитрий Андреевич', active: true }
];
let workers = [
  { id: 1, name: 'Кузнецов Иван', active: true },
  { id: 2, name: 'Морозов Олег', active: true },
  { id: 3, name: 'Васильев Роман', active: true },
  { id: 4, name: 'Соколов Артём', active: true }
];
let adminPassword = '4963';
let reports = {};
let selectedBrigadeForTask = null;
let currentTaskId = null;
let photos = {};

// Sample data
function initSampleData() {
  tasks = [
    {
      id: 1001,
      title: 'Утечка газа на ул. Ленина',
      address: 'г. Ногинск, ул. Ленина, 45, кв. 12',
      description: 'Запах газа в подъезде. Жильцы эвакуированы.',
      priority: 'высокий',
      time: '14:30',
      date: '2025-01-28',
      status: 'new',
      assignedTo: null,
      acceptedBy: null
    },
    {
      id: 1002,
      title: 'Проверка оборудования',
      address: 'г. Ногинск, ул. Рабочая, 17',
      description: 'Плановый осмотр газового котла в ТЦ «Глобус»',
      priority: 'средний',
      time: '09:00',
      date: '2025-01-28',
      status: 'inprogress',
      assignedTo: 1,
      acceptedBy: 'Иванов Сергей Петрович'
    },
    {
      id: 1003,
      title: 'Замена счетчика',
      address: 'г. Ногинск, ул. 3-го Интернационала, 8, кв. 64',
      description: 'По заявке собственника. Старый счетчик вышел из строя.',
      priority: 'низкий',
      time: '11:15',
      date: '2025-01-29',
      status: 'new',
      assignedTo: null,
      acceptedBy: null
    }
  ];

  archive = [
    {
      id: 987,
      title: 'Ремонт утечки на ул. Советская',
      address: 'г. Ногинск, ул. Советская, 22',
      report: 'Утечка устранена. Заменён участок трубы 40 см.',
      photos: ['https://picsum.photos/id/1015/600/600','https://picsum.photos/id/160/600/600'],
      brigade: ['Иванов Сергей Петрович', 'Кузнецов Иван', 'Морозов Олег'],
      car: 'Газель А723МР 150',
      startTime: '09:15',
      endTime: '11:40',
      duration: '2ч 25мин',
      date: '2025-01-25'
    }
  ];

  reports = {
    1002: {
      text: 'Котёл в рабочем состоянии. Проведена диагностика, заменён фильтр.',
      car: 'Газель А723МР 150',
      workers: ['Кузнецов Иван', 'Васильев Роман'],
      photos: []
    }
  };
}

function saveToLocal() {
  localStorage.setItem('bgs_tasks', JSON.stringify(tasks));
  localStorage.setItem('bgs_archive', JSON.stringify(archive));
  localStorage.setItem('bgs_reports', JSON.stringify(reports));
}

function loadFromLocal() {
  const savedTasks = localStorage.getItem('bgs_tasks');
  if (savedTasks) tasks = JSON.parse(savedTasks);
  const savedArchive = localStorage.getItem('bgs_archive');
  if (savedArchive) archive = JSON.parse(savedArchive);
  const savedReports = localStorage.getItem('bgs_reports');
  if (savedReports) reports = JSON.parse(savedReports);
}

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2500);
}

function navigateTo(screen) {
  currentScreen = screen;
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.id === `nav-${screen}`);
  });
  renderCurrentScreen();
}

function renderCurrentScreen() {
  const main = document.getElementById('main-content');
  main.innerHTML = '';

  if (!currentUser) {
    renderLoginScreen(main);
    return;
  }

  if (currentScreen === 'tasks') {
    renderTasksScreen(main);
  } else if (currentScreen === 'archive') {
    renderArchiveScreen(main);
  } else if (currentScreen === 'brigade') {
    renderBrigadeScreen(main);
  } else if (currentScreen === 'profile') {
    renderProfileScreen(main);
  }
}

function renderLoginScreen(container) {
  let html = `
    <div class="screen active" style="padding-top:60px">
      <div style="text-align:center;margin-bottom:40px">
        <div style="width:96px;height:96px;background:linear-gradient(135deg,#0052cc,#00aaff);border-radius:24px;margin:0 auto 20px;display:flex;align-items:center;justify-content:center;color:white;font-size:48px;font-weight:700;box-shadow:0 8px 25px -6px rgb(0 82 204)">БГС</div>
        <h1 style="font-size:28px;margin:0 0 8px">Богородская Газовая Служба</h1>
        <p style="color:#4a5c6a;margin:0">Единая система выездов</p>
      </div>
      
      <div class="card" style="padding:24px">
        <div onclick="loginAsBrigadier()" style="padding:20px 0;border-bottom:1px solid #d0d7e0;display:flex;align-items:center;justify-content:space-between;cursor:pointer">
          <div>
            <div style="font-weight:600;font-size:17px">Войти как бригадир</div>
            <div style="color:#4a5c6a;font-size:14px;margin-top:4px">Выберите ФИО из списка</div>
          </div>
          <div style="font-size:32px">→</div>
        </div>
        
        <div onclick="showAdminLogin()" style="padding:20px 0;display:flex;align-items:center;justify-content:space-between;cursor:pointer">
          <div>
            <div style="font-weight:600;font-size:17px">Войти как администратор</div>
            <div style="color:#4a5c6a;font-size:14px;margin-top:4px">По служебному паролю</div>
          </div>
          <div style="font-size:32px">→</div>
        </div>
      </div>
      
      <div style="text-align:center;margin-top:60px;font-size:12px;color:#7e8a98">
        Московское время • Синхронизация активна
      </div>
    </div>
  `;
  container.innerHTML = html;
}

function showAdminLogin() {
  const modal = document.getElementById('modal');
  const content = document.getElementById('modal-content');
  content.innerHTML = `
    <div style="padding:24px">
      <h2 style="margin-top:0">Вход для администратора</h2>
      <div class="label">Служебный пароль</div>
      <input type="password" id="admin-pass" class="input" placeholder="••••" maxlength="4">
      <button onclick="attemptAdminLogin()" class="btn btn-primary">Войти</button>
      <button onclick="closeModal()" class="btn btn-secondary">Отмена</button>
    </div>
  `;
  modal.classList.add('active');
  setTimeout(() => document.getElementById('admin-pass').focus(), 400);
}

function attemptAdminLogin() {
  const pass = document.getElementById('admin-pass').value;
  if (pass === adminPassword) {
    currentRole = 'admin';
    currentUser = { name: 'Администратор', role: 'admin' };
    closeModal();
    navigateTo('tasks');
    showToast('Добро пожаловать, администратор');
  } else {
    showToast('Неверный пароль');
  }
}

function loginAsBrigadier() {
  const modal = document.getElementById('modal');
  const content = document.getElementById('modal-content');
  let html = `<div style="padding:24px"><h2 style="margin-top:10px;margin-bottom:20px">Выберите бригадира</h2>`;
  brigadiers.forEach(b => {
    if (!b.active) return;
    html += `
      <div onclick="selectBrigadier(${b.id})" style="padding:16px 20px;background:#f8f9fc;border-radius:12px;margin-bottom:12px;cursor:pointer">
        <div style="font-weight:600">${b.name}</div>
      </div>
    `;
  });
  html += `<button onclick="closeModal()" class="btn btn-secondary">Отмена</button></div>`;
  content.innerHTML = html;
  modal.classList.add('active');
}

function selectBrigadier(id) {
  const brig = brigadiers.find(b => b.id === id);
  currentUser = { name: brig.name, role: 'brigadier', id: id };
  currentRole = 'brigadier';
  closeModal();
  navigateTo('tasks');
  showToast(`Добро пожаловать, ${brig.name.split(' ')[1]}`);
}

function logout() {
  if (confirm('Выйти из аккаунта?')) {
    currentUser = null;
    currentRole = null;
    renderCurrentScreen();
  }
}

function closeModal() {
  document.getElementById('modal').classList.remove('active');
}

function renderTasksScreen(container) {
  let html = `<div class="screen active">
    <div class="header">
      <div class="screen-title">Задания</div>
      ${currentRole === 'admin' ? `<button onclick="createNewTask()" class="btn btn-primary" style="width:auto;padding:0 20px;margin:0;height:42px">+ Новое</button>` : ''}
    </div>`;

  // filter chips
  html += `<div class="filter-chips">
    <div onclick="filterTasks(this)" class="chip active" data-filter="all">Все</div>
    <div onclick="filterTasks(this)" class="chip" data-filter="new">Новые</div>
    <div onclick="filterTasks(this)" class="chip" data-filter="inprogress">В работе</div>
  </div>`;

  const filtered = tasks.filter(t => {
    if (currentRole === 'brigadier') {
      return !t.acceptedBy || t.acceptedBy === currentUser.name;
    }
    return true;
  });

  if (filtered.length === 0) {
    html += `<div class="empty-state">
      <p>Нет заданий</p>
    </div>`;
  } else {
    filtered.forEach(task => {
      const isMine = task.acceptedBy === (currentUser ? currentUser.name : '');
      html += `<div class="card" onclick="openTaskDetail(${task.id})">
        <div class="list-item">
          <div style="flex:1">
            <div style="font-weight:600;font-size:16px;margin-bottom:6px">${task.title}</div>
            <div style="font-size:13px;color:var(--color-text-secondary);line-height:1.3">${task.address}</div>
            <div class="task-meta">
              <span>${task.date} • ${task.time}</span>
              <span class="status-badge status-${task.status === 'new' ? 'new' : task.status === 'inprogress' ? 'inprogress' : 'done'}">${task.status === 'new' ? 'Новое' : task.status === 'inprogress' ? 'В работе' : 'Выполнено'}</span>
            </div>
          </div>
          ${isMine ? `<div style="background:#0052cc;color:white;width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px">✓</div>` : ''}
        </div>
      </div>`;
    });
  }
  html += `</div>`;
  container.innerHTML = html;
}

function filterTasks(el) {
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  el.classList.add('active');
  // re-render for demo
  renderCurrentScreen();
}

function openTaskDetail(id) {
  currentTaskId = id;
  const task = tasks.find(t => t.id === id);
  if (!task) return;

  const modal = document.getElementById('modal');
  const content = document.getElementById('modal-content');
  let html = `<div style="padding:24px 24px 40px">
    <div style="display:flex;justify-content:space-between;align-items:flex-start">
      <div>
        <div class="status-badge status-${task.status}" style="margin-bottom:12px">${task.status === 'new' ? 'Новое' : 'В работе'}</div>
        <h2 style="margin:0 0 6px;font-size:22px">${task.title}</h2>
        <div style="color:#4a5c6a;font-size:15px">${task.address}</div>
      </div>
      <button onclick="closeModal()" style="background:none;border:none;font-size:32px;line-height:1;color:#999">×</button>
    </div>
    <div style="margin:24px 0 20px;background:#f8f9fc;border-radius:12px;padding:16px;font-size:14px">
      ${task.description}
    </div>
    <div style="display:flex;gap:12px;align-items:center;margin-bottom:24px">
      <div style="flex:1">
        <div class="label">Приоритет</div>
        <div style="font-weight:700;color:${task.priority==='высокий'?'#e02d2d':'#0052cc'}">${task.priority}</div>
      </div>
      <div style="flex:1">
        <div class="label">Время выезда</div>
        <div style="font-weight:700">${task.time}</div>
      </div>
    </div>`;

  if (currentRole === 'brigadier' && task.status === 'new' && !task.acceptedBy) {
    html += `<button onclick="acceptTask(${id});closeModal()" class="btn btn-primary">Принять задание</button>`;
  } else if (currentRole === 'brigadier' && task.acceptedBy === currentUser.name && task.status === 'inprogress') {
    html += `<button onclick="finishTaskModal()" class="btn btn-primary">Завершить выезд</button>`;
  } else if (currentRole === 'admin') {
    html += `<button onclick="editTask(${id});closeModal()" class="btn btn-secondary" style="margin-bottom:8px">Редактировать</button>`;
    html += `<button onclick="cancelTask(${id});closeModal()" class="btn btn-danger">Отменить задание</button>`;
  }

  html += `</div>`;
  content.innerHTML = html;
  modal.classList.add('active');
}

function acceptTask(id) {
  const task = tasks.find(t => t.id === id);
  if (task) {
    task.status = 'inprogress';
    task.acceptedBy = currentUser.name;
    task.assignedTo = currentUser.id;
    saveToLocal();
    showToast('Задание принято в работу');
    renderCurrentScreen();
  }
}

function finishTaskModal() {
  closeModal();
  const task = tasks.find(t => t.id === currentTaskId);
  if (!task) return;

  const modal = document.getElementById('modal');
  const content = document.getElementById('modal-content');
  content.innerHTML = `
    <div style="padding:20px 24px 30px">
      <h2 style="margin-top:8px">Завершение выезда</h2>
      <div class="label">Автомобиль</div>
      <input id="finish-car" class="input" value="Газель А723МР 150" placeholder="Номер автомобиля">
      
      <div class="label">Состав бригады</div>
      <div id="worker-list" style="margin-bottom:16px"></div>
      
      <div class="label">Отчёт (обязательно)</div>
      <textarea id="finish-report" class="input" rows="5" style="height:120px;resize:none" placeholder="Опишите выполненные работы...">Утечка устранена. Заменён кран. Проведён инструктаж жильцов.</textarea>
      
      <div class="label">Фотографии</div>
      <button onclick="addPhotoDemo()" class="btn btn-secondary" style="margin-bottom:20px">📸 Добавить фото</button>
      <div id="photo-preview-area" class="photo-grid"></div>
      
      <button onclick="completeTask()" class="btn btn-primary">Завершить и отправить отчёт</button>
      <button onclick="closeModal()" class="btn btn-secondary">Отмена</button>
    </div>
  `;
  modal.classList.add('active');
  renderWorkerCheckboxes();
}

function renderWorkerCheckboxes() {
  const container = document.getElementById('worker-list');
  if (!container) return;
  let str = '';
  workers.forEach(w => {
    str += `<label style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid #eee">
      <input type="checkbox" checked> <span>${w.name}</span>
    </label>`;
  });
  container.innerHTML = str;
}

function addPhotoDemo() {
  if (!photos[currentTaskId]) photos[currentTaskId] = [];
  photos[currentTaskId].push(`https://picsum.photos/id/${100 + Math.floor(Math.random()*80)}/600/600`);
  renderCurrentPhotos();
}

function renderCurrentPhotos() {
  const container = document.getElementById('photo-preview-area');
  if (!container) return;
  container.innerHTML = '';
  if (!photos[currentTaskId]) return;
  photos[currentTaskId].forEach((url, i) => {
    const div = document.createElement('div');
    div.className = 'photo-preview';
    div.style.backgroundImage = `url('${url}')`;
    container.appendChild(div);
  });
}

function completeTask() {
  const task = tasks.find(t => t.id === currentTaskId);
  if (!task) return;

  const reportText = document.getElementById('finish-report').value.trim();
  if (!reportText) {
    showToast('Отчёт обязателен');
    return;
  }

  task.status = 'done';

  const finishedTask = {
    id: task.id,
    title: task.title,
    address: task.address,
    report: reportText,
    photos: photos[currentTaskId] || [],
    brigade: ['Иванов Сергей Петрович', 'Кузнецов Иван'],
    car: document.getElementById('finish-car').value || 'Газель А723МР 150',
    startTime: '10:05',
    endTime: '12:45',
    duration: '2ч 40мин',
    date: '2025-01-28'
  };

  archive.unshift(finishedTask);
  reports[task.id] = { text: reportText, car: finishedTask.car, workers: finishedTask.brigade, photos: finishedTask.photos };

  tasks = tasks.filter(t => t.id !== currentTaskId);
  saveToLocal();
  closeModal();
  showToast('Выезд успешно завершён');
  navigateTo('archive');
}

function createNewTask() {
  const modal = document.getElementById('modal');
  const content = document.getElementById('modal-content');
  content.innerHTML = `
    <div style="padding:24px">
      <h2 style="margin:0 0 20px">Новое задание</h2>
      <div class="label">Адрес</div>
      <input id="new-address" class="input" value="г. Ногинск, ул. Индустриальная, 12">
      <div class="label">Описание</div>
      <textarea id="new-desc" class="input" rows="3">Провести диагностику газопровода после жалобы жильцов</textarea>
      <div class="label">Приоритет</div>
      <select id="new-priority" class="input">
        <option value="высокий">Высокий</option>
        <option value="средний" selected>Средний</option>
        <option value="низкий">Низкий</option>
      </select>
      <div style="display:flex;gap:16px">
        <div style="flex:1">
          <div class="label">Дата</div>
          <input type="date" id="new-date" class="input" value="2025-01-29">
        </div>
        <div style="flex:1">
          <div class="label">Время</div>
          <input type="time" id="new-time" class="input" value="15:00">
        </div>
      </div>
      <button onclick="saveNewTask()" class="btn btn-primary">Создать задание</button>
      <button onclick="closeModal()" class="btn btn-secondary">Отмена</button>
    </div>
  `;
  modal.classList.add('active');
}

function saveNewTask() {
  const address = document.getElementById('new-address').value;
  const desc = document.getElementById('new-desc').value;
  const priority = document.getElementById('new-priority').value;
  const date = document.getElementById('new-date').value;
  const time = document.getElementById('new-time').value;

  const newTask = {
    id: Date.now(),
    title: desc.substring(0, 28) + '...',
    address: address,
    description: desc,
    priority: priority,
    time: time,
    date: date,
    status: 'new',
    assignedTo: null,
    acceptedBy: null
  };

  tasks.unshift(newTask);
  saveToLocal();
  closeModal();
  showToast('Задание создано');
  renderCurrentScreen();
}

function editTask(id) {
  showToast('Редактирование задания (демо)');
}

function cancelTask(id) {
  if (!confirm('Отменить задание?')) return;
  tasks = tasks.filter(t => t.id !== id);
  saveToLocal();
  showToast('Задание отменено');
  renderCurrentScreen();
}

function renderArchiveScreen(container) {
  let html = `<div class="screen active">
    <div class="screen-title">Архив выездов</div>
    <input type="text" id="archive-search" placeholder="Поиск по адресу или бригадиру" class="input" onkeyup="if(event.key==='Enter') renderArchiveScreen(document.getElementById('main-content'))">
  `;

  const searchTerm = document.getElementById('archive-search') ? document.getElementById('archive-search').value.toLowerCase() : '';

  const filteredArchive = archive.filter(item => {
    return !searchTerm || 
           item.address.toLowerCase().includes(searchTerm) || 
           item.brigade.some(b => b.toLowerCase().includes(searchTerm));
  });

  if (filteredArchive.length === 0) {
    html += `<div class="empty-state"><p>Архив пуст</p></div>`;
  } else {
    filteredArchive.forEach(item => {
      html += `<div class="card" onclick="showArchiveDetail(${item.id})">
        <div style="padding:16px 20px">
          <div style="display:flex;justify-content:space-between">
            <div style="font-weight:600">${item.title}</div>
            <div style="font-size:12px;color:#7e8a98">${item.date}</div>
          </div>
          <div style="margin-top:8px;font-size:13px;color:var(--color-text-secondary)">${item.address}</div>
          <div style="margin-top:12px;font-size:13px;display:flex;gap:12px;flex-wrap:wrap">
            <div style="background:#f0f4f9;padding:2px 10px;border-radius:4px">${item.car}</div>
            <div style="background:#f0f4f9;padding:2px 10px;border-radius:4px">${item.duration}</div>
          </div>
        </div>
      </div>`;
    });
  }
  html += `</div>`;
  container.innerHTML = html;
}

function showArchiveDetail(id) {
  const item = archive.find(a => a.id === id);
  if (!item) return;

  const modal = document.getElementById('modal');
  const content = document.getElementById('modal-content');
  let html = `<div style="padding:24px">
    <h2>${item.title}</h2>
    <p style="color:#4a5c6a;margin:4px 0 16px">${item.address}</p>
    <div style="background:#f8f9fc;border-radius:12px;padding:16px;margin-bottom:20px">
      <strong>Отчёт:</strong><br>
      ${item.report}
    </div>
    <div style="margin-bottom:14px"><strong>Автомобиль:</strong> ${item.car}</div>
    <div style="margin-bottom:14px"><strong>Бригада:</strong> ${item.brigade.join(', ')}</div>
    <div style="margin-bottom:14px"><strong>Время:</strong> ${item.startTime} – ${item.endTime} (${item.duration})</div>
    
    <div class="label">Фотоотчёт</div>
    <div class="photo-grid">`;

  item.photos.forEach(ph => {
    html += `<div onclick="viewFullPhoto('${ph}')" class="photo-preview" style="background-image:url('${ph}')"></div>`;
  });

  html += `</div>
    <button onclick="closeModal()" class="btn btn-secondary">Закрыть</button>
  </div>`;
  content.innerHTML = html;
  modal.classList.add('active');
}

function viewFullPhoto(url) {
  showToast('Открытие фото в полном размере (демо)');
}

function renderBrigadeScreen(container) {
  let html = `<div class="screen active">
    <div class="screen-title">Моя бригада</div>
    <div class="card">
      <div style="padding:18px 22px;border-bottom:1px solid #eee;font-weight:600">Активные работники</div>`;

  workers.forEach(w => {
    html += `<div class="list-item">
      <div style="display:flex;align-items:center;gap:14px">
        <div style="width:34px;height:34px;background:#e6f0ff;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#0052cc;font-size:15px">👷</div>
        <div>${w.name}</div>
      </div>
      <div class="status-badge status-done">активен</div>
    </div>`;
  });

  html += `</div>
    <div onclick="manageBrigadiers()" style="margin-top:30px;padding:16px;background:white;border-radius:12px;box-shadow:var(--shadow);text-align:center;color:var(--color-primary);font-weight:600;cursor:pointer">Управление бригадирами (админ)</div>
  </div>`;
  container.innerHTML = html;
}

function manageBrigadiers() {
  if (currentRole !== 'admin') {
    showToast('Доступно только администратору');
    return;
  }
  const modal = document.getElementById('modal');
  const content = document.getElementById('modal-content');
  let html = `<div style="padding:24px">
    <h2>Бригадиры</h2>`;
  brigadiers.forEach((b, index) => {
    html += `<div style="display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid #eee">
      <span>${b.name}</span>
      <button onclick="toggleBrigadierActive(${index});closeModal();manageBrigadiers()" style="padding:4px 14px;border-radius:20px;background:${b.active?'#00b36b':'#ccc'};color:white;border:none;font-size:13px">${b.active?'активен':'отключён'}</button>
    </div>`;
  });
  html += `<button onclick="closeModal()" class="btn btn-secondary" style="margin-top:30px">Закрыть</button></div>`;
  content.innerHTML = html;
  modal.classList.add('active');
}

function toggleBrigadierActive(index) {
  brigadiers[index].active = !brigadiers[index].active;
  saveToLocal();
}

function renderProfileScreen(container) {
  let html = `<div class="screen active" style="padding-top:30px">
    <div style="text-align:center">
      <div style="width:88px;height:88px;background:linear-gradient(#0052cc,#00aaff);color:white;border-radius:50%;margin:0 auto 16px;display:flex;align-items:center;justify-content:center;font-size:36px;box-shadow:0 6px 20px -4px rgb(0 82 204 / 40%)">👷‍♂️</div>
      <div style="font-size:21px;font-weight:700">${currentUser.name}</div>
      <div style="color:var(--color-success);margin-top:4px;font-weight:500">${currentRole === 'admin' ? 'Администратор' : 'Бригадир'}</div>
    </div>

    <div class="card" style="margin-top:40px">
      <div class="list-item" onclick="changeAdminPassword()">
        <span>Сменить пароль администратора</span>
        <span style="color:#999">→</span>
      </div>
      <div class="list-item" onclick="showToast('Синхронизация с сервером выполнена')">
        <span>Синхронизировать данные</span>
        <span style="color:var(--color-success)">✓</span>
      </div>
      <div class="list-item" onclick="showToast('Московское время: ' + new Date().toLocaleTimeString('ru-RU'))">
        <span>Текущее время</span>
        <span style="color:#4a5c6a">МСК</span>
      </div>
    </div>

    <div onclick="logout()" class="btn btn-danger" style="margin-top:60px">Выйти из аккаунта</div>
  </div>`;
  container.innerHTML = html;
}

function changeAdminPassword() {
  if (currentRole !== 'admin') {
    showToast('Только администратор может менять пароль');
    return;
  }
  const newPass = prompt('Введите новый 4-значный пароль:');
  if (newPass && newPass.length === 4 && !isNaN(newPass)) {
    adminPassword = newPass;
    showToast('Пароль успешно изменён');
  } else if (newPass) {
    showToast('Пароль должен состоять из 4 цифр');
  }
}

// Boot the app
function initializeApp() {
  initSampleData();
  loadFromLocal();
  // default logged in as brigadier for demo
  currentUser = { name: 'Иванов Сергей Петрович', role: 'brigadier', id: 1 };
  currentRole = 'brigadier';
  renderCurrentScreen();
  navigateTo('tasks');
  // demo toast
  setTimeout(() => {
    if (document.getElementById('toast')) showToast('Все данные синхронизированы');
  }, 1400);
}

window.onload = initializeApp;

// expose some functions to onclick handlers
window.navigateTo = navigateTo;
window.logout = logout;
window.showAdminLogin = showAdminLogin;
window.attemptAdminLogin = attemptAdminLogin;
window.loginAsBrigadier = loginAsBrigadier;
window.selectBrigadier = selectBrigadier;
window.closeModal = closeModal;
window.openTaskDetail = openTaskDetail;
window.acceptTask = acceptTask;
window.finishTaskModal = finishTaskModal;
window.completeTask = completeTask;
window.createNewTask = createNewTask;
window.saveNewTask = saveNewTask;
window.editTask = editTask;
window.cancelTask = cancelTask;
window.renderArchiveScreen = renderArchiveScreen;
window.showArchiveDetail = showArchiveDetail;
window.manageBrigadiers = manageBrigadiers;
window.toggleBrigadierActive = toggleBrigadierActive;
window.changeAdminPassword = changeAdminPassword;
window.addPhotoDemo = addPhotoDemo;
window.viewFullPhoto = viewFullPhoto;
window.filterTasks = filterTasks;