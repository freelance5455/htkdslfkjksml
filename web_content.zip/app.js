const $=id=>document.getElementById(id);
const today=new Date();let selected=new Date(today.getFullYear(),today.getMonth(),today.getDate());
let viewMonth=new Date(today.getFullYear(),today.getMonth(),1);
let data=JSON.parse(localStorage.getItem('jb_data')||'{"sales":[],"expenses":[]}');
let account=JSON.parse(localStorage.getItem('jb_account')||'null');
const money=n=>new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}).format(n||0)+' FC';
const dateKey=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const save=()=>localStorage.setItem('jb_data',JSON.stringify(data));
const total=(arr,key)=>arr.filter(x=>x.date===key).reduce((s,x)=>s+x.amount,0);
const monthTotal=(arr,y,m)=>arr.filter(x=>{let d=new Date(x.date+'T00:00:00');return d.getFullYear()===y&&d.getMonth()===m}).reduce((s,x)=>s+x.amount,0);
function setScreen(id){document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active-screen',s.id===id));document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.screen===id));window.scrollTo({top:0,behavior:'instant'});renderAll();}
document.querySelectorAll('.bottom-nav button').forEach(b=>b.addEventListener('click',()=>setScreen(b.dataset.screen)));
function showApp(){ $('auth').classList.add('hidden');$('app').classList.remove('hidden');$('welcomeName').textContent=account.name;$('profilePageName').textContent=account.name;setScreen('home-screen'); }
function auth(){const name=$('accountName').value.trim(),pass=$('accountPassword').value;if(!name||pass.length<4){$('authMessage').textContent='Entre ton nom et un mot de passe de 4 caractères minimum.';return}
 if(account){if(name!==account.name||pass!==account.pass){$('authMessage').textContent='Nom ou mot de passe incorrect.';return}}
 else{account={name,pass};localStorage.setItem('jb_account',JSON.stringify(account));}
 showApp();}
$('authButton').addEventListener('click',auth);$('accountPassword').addEventListener('keydown',e=>{if(e.key==='Enter')auth()});
if(account)$('accountName').value=account.name;
$('logoutBtn').onclick=()=>{$('app').classList.add('hidden');$('auth').classList.remove('hidden');$('accountPassword').value=''};
function renderCalendar(){ $('monthLabel').textContent=viewMonth.toLocaleDateString('fr-FR',{month:'long',year:'numeric'});const first=new Date(viewMonth.getFullYear(),viewMonth.getMonth(),1),start=(first.getDay()+6)%7,days=new Date(viewMonth.getFullYear(),viewMonth.getMonth()+1,0).getDate();let out='';for(let i=0;i<42;i++){let n=i-start+1;if(n<1||n>days){out+='<div class="day muted-day"></div>';continue}let d=new Date(viewMonth.getFullYear(),viewMonth.getMonth(),n),key=dateKey(d),has=data.sales.some(x=>x.date===key);out+=`<button class="day ${key===dateKey(selected)?'selected':''} ${has?'has-sales':''}" data-date="${key}">${n}</button>`}$('calendar').innerHTML=out;document.querySelectorAll('.day[data-date]').forEach(b=>b.onclick=()=>{selected=new Date(b.dataset.date+'T00:00:00');renderAll()});}
$('prevMonth').onclick=()=>{viewMonth.setMonth(viewMonth.getMonth()-1);renderCalendar()};$('nextMonth').onclick=()=>{viewMonth.setMonth(viewMonth.getMonth()+1);renderCalendar()};
function renderDay(){
 const key=dateKey(selected),gross=total(data.sales,key),expense=total(data.expenses,key),net=gross-expense;
 $('selectedDateTitle').textContent=selected.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 $('selectedNet').textContent=money(net);$('selectedExpenses').textContent=money(expense);$('selectedGross').textContent=money(gross);
 $('salesList').innerHTML=data.sales.filter(x=>x.date===key).map(x=>`<div class="record"><span>${esc(x.product)} × ${x.qty}</span><b>${money(x.amount)}</b></div>`).join('')||'Aucune vente pour cette date.';
 $('expensesList').innerHTML=data.expenses.filter(x=>x.date===key).map(x=>`<div class="record"><span>${esc(x.label)}</span><b>${money(x.amount)}</b></div>`).join('')||'Aucune dépense pour cette date.';
 $('salesList').classList.toggle('empty',!data.sales.some(x=>x.date===key));$('expensesList').classList.toggle('empty',!data.expenses.some(x=>x.date===key));
 const tk=dateKey(today),todayGross=total(data.sales,tk),todayExpense=total(data.expenses,tk);
 $('todayNet').textContent=money(todayGross-todayExpense);$('todayExpenses').textContent=money(todayExpense);$('todayGross').textContent=money(todayGross);
}
function renderHistory(){
 const y=viewMonth.getFullYear(),m=viewMonth.getMonth(),gross=monthTotal(data.sales,y,m),expense=monthTotal(data.expenses,y,m);
 $('monthNet').textContent=money(gross-expense);$('monthExpenses').textContent=money(expense);$('monthGross').textContent=money(gross);
 let all=[...data.sales.map(x=>({...x,type:'Vente',label:x.product})),...data.expenses.map(x=>({...x,type:'Dépense',label:x.label}))].sort((a,b)=>b.date.localeCompare(a.date));
 $('historyList').innerHTML=all.map(x=>`<div class="record"><span>${x.date} · ${x.type} · ${esc(x.label)}</span><b>${money(x.amount)}</b></div>`).join('')||'Aucune opération enregistrée.';
 $('historyList').classList.toggle('empty',!all.length);
}
function renderAll(){renderCalendar();renderDay();renderHistory();}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function preview(){let q=Number($('productQty').value)||0,p=Number($('productPrice').value)||0;$('salePreview').textContent=money(q*p)}
$('productQty').oninput=preview;$('productPrice').oninput=preview;
$('saleForm').onsubmit=e=>{e.preventDefault();let qty=Number($('productQty').value),price=Number($('productPrice').value);if(qty<1||price<0)return;data.sales.push({date:dateKey(selected),product:$('productName').value.trim(),qty,amount:qty*price});save();$('saleForm').reset();$('productQty').value=1;preview();renderAll()};
$('expenseForm').onsubmit=e=>{e.preventDefault();let amount=Number($('expenseAmount').value);if(amount<0)return;data.expenses.push({date:dateKey(selected),label:$('expenseName').value.trim(),amount});save();$('expenseForm').reset();renderAll()};
$('clearHistoryBtn').addEventListener('click',()=>{
 $('clearHistoryMessage').textContent='';
 const entered=window.prompt('Pour supprimer toutes les ventes et dépenses, saisis le mot de passe de ton profil :');
 if(entered===null)return;
 if(!account || entered!==account.pass){$('clearHistoryMessage').textContent='Mot de passe incorrect. Aucun historique n’a été supprimé.';return;}
 const confirmDelete=window.confirm('Confirmer la suppression de toutes les ventes, dépenses et de tous les totaux du mois ? Cette action est définitive.');
 if(!confirmDelete)return;
 data={sales:[],expenses:[]};save();$('clearHistoryMessage').textContent='Tout l’historique a été supprimé. Les totaux sont remis à zéro.';renderAll();
});
if(account)showApp();else $('auth').classList.remove('hidden');
