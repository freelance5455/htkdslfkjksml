// 寒冰 Control Panel - Interaction Logic

// Toast helper
function showToast(message) {
  let toast = document.querySelector('.toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.className = 'toast';
    document.querySelector('.phone-frame').appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2000);
}

// Game selection
document.querySelectorAll('.game-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.game-item').forEach(g => g.classList.remove('selected'));
    item.classList.add('selected');
    
    const gameName = item.querySelector('.game-name').textContent.replace(/\n/g, ' ').trim();
    showToast(`已选择：${gameName}`);
    
    // Update activated card description
    const desc = document.querySelector('.status-desc');
    if (desc) {
      desc.textContent = `寒冰 - ${gameName.split(' ')[0]}`;
    }
  });
});

// App launch items
document.querySelectorAll('.app-item').forEach(item => {
  item.addEventListener('click', () => {
    const name = item.querySelector('.app-name').textContent;
    showToast(`正在启动 ${name}...`);
  });
});

// FAB button
document.getElementById('fab').addEventListener('click', () => {
  const selected = document.querySelector('.game-item.selected');
  const game = selected ? selected.querySelector('.game-name').textContent.replace(/\n/g, ' ').trim() : '目标游戏';
  showToast(`寒冰已启动 · ${game}`);
});

// Bottom navigation
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    
    const page = btn.dataset.page;
    if (page === 'home') {
      showToast('控制面板');
    } else if (page === 'apps') {
      showToast('应用列表');
    } else if (page === 'settings') {
      showToast('设置');
    }
  });
});

// Prevent overscroll bounce on iOS-like feel
document.body.addEventListener('touchmove', (e) => {
  if (e.target.closest('.main-content') === null) {
    e.preventDefault();
  }
}, { passive: false });
