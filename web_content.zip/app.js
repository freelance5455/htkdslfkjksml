const DB_NAME = "MyWardrobeDB";
const STORE = "items";
let db, items = [], selectedDetail = null, selectedPhoto = null, currentLang = "ar";
const $ = id => document.getElementById(id);
const categories = ["top","bottom","shoes","bag"];
const categoryIcons = {top:"♧",bottom:"▤",shoes:"◒",bag:"▣"};
const translations = {
 ar:{appName:"خزانتي",tagline:"إطلالتك تبدأ من هنا",offlineLabel:"خزانة خاصة • دون إنترنت",heroTitle:"كل ملابسك،<br>بإطلالة أذكى.",heroText:"احفظ قطعك مرة واحدة، ودع خزانتي تساعدك في تنسيقها كلما أردت الخروج.",generate:"نسّق لي إطلالة",myWardrobe:"خزانتي",outfits:"التنسيقات",manual:"يدوي",collection:"مجموعتك",wardrobeTitle:"خزانة ملابسك",addPiece:"إضافة قطعة",allPieces:"كل القطع",allCategories:"كل الفئات",tops:"كنزات",bottoms:"بناطيل",shoes:"أحذية",bags:"حقائب",emptyTitle:"خزانتك تنتظرك",emptyText:"أضف صور ملابسك الآن. ستبقى محفوظة على هذا الجهاز ولن تحتاج إلى تصويرها مرة أخرى.",addFirst:"أضف أول قطعة",styleStudio:"استوديو التنسيق",outfitTitle:"إطلالة اليوم",readyTitle:"جاهز لإطلالة جديدة؟",readyText:"سنختار قطعاً من خزانتك ونوازن ألوانها معاً.",newOutfit:"اقترح تنسيقاً",outfitPlaceholder:"سيظهر تنسيقك هنا",matchingNote:"التنسيق محلي ويعتمد على الألوان التي يستخرجها التطبيق من صورك، وليس على خدمة ذكاء اصطناعي عبر الإنترنت.",yourChoice:"اختيارك أنت",manualTitle:"نسّق بنفسك",manualHint:"اختر قطعة من كل فئة لتكوين إطلالتك. يمكنك ترك أي فئة فارغة.",manualPreviewText:"اختياراتك ستظهر هنا",privateFooter:"صورك تبقى على جهازك",newItem:"قطعة جديدة",addToWardrobe:"أضف إلى خزانتك",choosePhoto:"اختر صورة القطعة",photoHint:"من الكاميرا أو معرض الصور",pieceName:"اسم القطعة (اختياري)",category:"الفئة",colorOptional:"اللون (اختياري لتعديل اقتراح التطبيق)",autoColor:"اكتشاف تلقائي من الصورة",black:"أسود",white:"أبيض",gray:"رمادي",navy:"كحلي",blue:"أزرق",red:"أحمر",green:"أخضر",beige:"بيج",brown:"بني",pink:"وردي",yellow:"أصفر",purple:"بنفسجي",savePiece:"حفظ القطعة",deletePiece:"حذف القطعة",piece:"قطعة",pieces:"قطع",noItems:"لا توجد قطع في هذه الفئة بعد.",needItems:"أضف بعض الملابس أولاً حتى أستطيع اقتراح تنسيق.",generated:"تم اختيار تنسيق من خزانتك.",manualEmpty:"أضف قطعاً من الفئات التي تريدها.",colorHarmony:"تناسق الألوان",saved:"تم حفظ القطعة في خزانتك.",deleted:"تم حذف القطعة.",confirmDelete:"هل تريد حذف هذه القطعة؟",selectPhoto:"اختر صورة أولاً.",cameraError:"تعذر فتح الصورة. جرّب صورة أخرى.",top:"كنزة",bottom:"بنطال",bag:"حقيبة",item:"قطعة",lookTitle:"اقتراح من خزانتك",emptyCategory:"لا توجد قطعة",deleteFailed:"تعذر حذف القطعة."},
 en:{appName:"My Wardrobe",tagline:"Your style starts here",offlineLabel:"PRIVATE CLOSET • OFFLINE",heroTitle:"Your clothes,<br>a smarter look.",heroText:"Save your pieces once, then let My Wardrobe help style them whenever you go out.",generate:"Style an outfit",myWardrobe:"Wardrobe",outfits:"Outfits",manual:"Manual",collection:"YOUR COLLECTION",wardrobeTitle:"Your wardrobe",addPiece:"Add item",allPieces:"All pieces",allCategories:"All categories",tops:"Tops",bottoms:"Bottoms",shoes:"Shoes",bags:"Bags",emptyTitle:"Your closet is waiting",emptyText:"Add photos of your clothes. They stay saved on this device, so you won't need to photograph them again.",addFirst:"Add your first item",styleStudio:"STYLE STUDIO",outfitTitle:"Today's outfit",readyTitle:"Ready for a fresh look?",readyText:"We'll pick pieces from your closet and balance their colors.",newOutfit:"Suggest an outfit",outfitPlaceholder:"Your outfit will appear here",matchingNote:"Matching runs locally using colors estimated from your photos, not an online AI service.",yourChoice:"YOUR CHOICE",manualTitle:"Style it yourself",manualHint:"Choose one item from each category. You can leave any category empty.",manualPreviewText:"Your selections will appear here",privateFooter:"Your photos stay on your device",newItem:"NEW ITEM",addToWardrobe:"Add to wardrobe",choosePhoto:"Choose an item photo",photoHint:"Camera or photo gallery",pieceName:"Item name (optional)",category:"Category",colorOptional:"Color (optional override)",autoColor:"Auto-detect from photo",black:"Black",white:"White",gray:"Gray",navy:"Navy",blue:"Blue",red:"Red",green:"Green",beige:"Beige",brown:"Brown",pink:"Pink",yellow:"Yellow",purple:"Purple",savePiece:"Save item",deletePiece:"Delete item",piece:"item",pieces:"items",noItems:"No items in this category yet.",needItems:"Add some clothes first so I can suggest an outfit.",generated:"An outfit was selected from your wardrobe.",manualEmpty:"Add items from the categories you want.",colorHarmony:"Color harmony",saved:"Item saved to your wardrobe.",deleted:"Item deleted.",confirmDelete:"Delete this item?",selectPhoto:"Please choose a photo first.",cameraError:"Could not read that image. Try another photo.",top:"Top",bottom:"Bottom",bag:"Bag",item:"Item",lookTitle:"A look from your wardrobe",emptyCategory:"No item",deleteFailed:"Could not delete the item."}
};
const colorNames = ["black","white","gray","navy","blue","red","green","beige","brown","pink","yellow","purple"];
function t(key){return translations[currentLang][key] || key;}
function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE,{keyPath:"id",autoIncrement:true});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
function tx(mode="readonly"){return db.transaction(STORE,mode).objectStore(STORE);}
function getAll(){return new Promise((resolve,reject)=>{const r=tx().getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
function saveItem(item){return new Promise((resolve,reject)=>{const r=tx("readwrite").add(item);r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
function removeItem(id){return new Promise((resolve,reject)=>{const r=tx("readwrite").delete(id);r.onsuccess=resolve;r.onerror=()=>reject(r.error);});}
function applyLanguage(){
 document.documentElement.lang=currentLang;document.documentElement.dir=currentLang==="ar"?"rtl":"ltr";
 document.querySelectorAll("[data-i18n]").forEach(el=>{const key=el.dataset.i18n;if(translations[currentLang][key])el.innerHTML=translations[currentLang][key];});
 $("langBtn").textContent=currentLang==="ar"?"EN":"عربي";
 renderAll();
}
function categoryName(c){return t(c==="top"?"tops":c==="bottom"?"bottoms":c==="shoes"?"shoes":"bags");}
function countText(n){return `${n} ${currentLang==="ar"?(n===1?t("piece"):t("pieces")):t("pieces")}`;}
function renderCategories(){
 const counts=Object.fromEntries(categories.map(c=>[c,items.filter(i=>i.category===c).length]));
 $("categoryGrid").innerHTML=categories.map(c=>`<div class="category-card"><div class="category-icon">${categoryIcons[c]}</div><strong>${categoryName(c)}</strong><small>${counts[c]} ${currentLang==="ar"?"قطع": "items"}</small></div>`).join("");
}
function renderItems(){
 const filter=$("filterSelect").value;
 const shown=items.filter(i=>filter==="all"||i.category===filter).slice().reverse();
 $("pieceCount").textContent=countText(items.length);
 $("itemsGrid").innerHTML=shown.map(i=>`<article class="item-card" data-id="${i.id}"><img src="${i.image}" alt=""><div class="item-info"><strong>${escapeHtml(i.name||categoryName(i.category))}</strong><small>${categoryName(i.category)}</small></div></article>`).join("");
 $("itemsGrid").querySelectorAll(".item-card").forEach(card=>card.addEventListener("click",()=>showDetail(Number(card.dataset.id))));
 $("emptyState").style.display=items.length?"none":"block";
}
function renderAll(){renderCategories();renderItems();renderManual();}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function showToast(message){const el=$("toast");el.textContent=message;el.classList.add("show");clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>el.classList.remove("show"),2300);}
function addDialog(){selectedPhoto=null;$("photoInput").value="";$("photoPreview").hidden=true;$("photoPreview").src="";$("itemName").value="";$("itemCategory").value="top";$("itemColor").value="auto";$("addDialog").showModal();}
function readFile(file){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file);});}
function compressImage(dataUrl,max=1000,quality=.82){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>{const scale=Math.min(1,max/Math.max(img.width,img.height));const canvas=document.createElement("canvas");canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);canvas.getContext("2d").drawImage(img,0,0,canvas.width,canvas.height);resolve(canvas.toDataURL("image/jpeg",quality));};img.onerror=reject;img.src=dataUrl;});}
function detectColor(dataUrl){return new Promise(resolve=>{const img=new Image();img.onload=()=>{const c=document.createElement("canvas");c.width=24;c.height=24;const ctx=c.getContext("2d",{willReadFrequently:true});ctx.drawImage(img,0,0,24,24);const d=ctx.getImageData(0,0,24,24).data;let r=0,g=0,b=0,n=0;for(let p=0;p<d.length;p+=16){if(d[p+3]<180)continue;r+=d[p];g+=d[p+1];b+=d[p+2];n++;}if(!n){resolve("gray");return;}r/=n;g/=n;b/=n;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx?((mx-mn)/mx):0,hue=rgbHue(r,g,b);let color;if(mx<55)color="black";else if(mx>218&&sat<.16)color="white";else if(sat<.18)color="gray";else if(hue<15||hue>=345)color=mx<125?"brown":"red";else if(hue<42)color=mx<155?"brown":"yellow";else if(hue<75)color="yellow";else if(hue<165)color="green";else if(hue<205)color="blue";else if(hue<255)color="navy";else if(hue<290)color="purple";else color="pink";resolve(color);};img.onerror=()=>resolve("gray");img.src=dataUrl;});}
function rgbHue(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;if(d===0)return 0;if(mx===r)h=((g-b)/d)%6;else if(mx===g)h=(b-r)/d+2;else h=(r-g)/d+4;return h*60;}
$("photoInput").addEventListener("change",async e=>{const f=e.target.files[0];if(!f)return;try{const raw=await readFile(f);selectedPhoto=await compressImage(raw);$("photoPreview").src=selectedPhoto;$("photoPreview").hidden=false;}catch{showToast(t("cameraError"));}});
$("addForm").addEventListener("submit",async e=>{e.preventDefault();if(!selectedPhoto){showToast(t("selectPhoto"));return;}const chosen=$("itemColor").value;const color=chosen==="auto"?await detectColor(selectedPhoto):chosen;try{await saveItem({name:$("itemName").value.trim(),category:$("itemCategory").value,color,image:selectedPhoto,createdAt:Date.now()});items=await getAll();$("addDialog").close();renderAll();showToast(t("saved"));}catch(err){showToast("Storage error: "+(err.message||""));}});
function showDetail(id){selectedDetail=items.find(i=>i.id===id);if(!selectedDetail)return;$("detailImage").src=selectedDetail.image;$("detailName").textContent=selectedDetail.name||categoryName(selectedDetail.category);$("detailMeta").textContent=categoryName(selectedDetail.category)+" • "+t(selectedDetail.color||"gray");$("itemDialog").showModal();}
$("deleteItemBtn").addEventListener("click",async()=>{if(!selectedDetail||!confirm(t("confirmDelete")))return;try{await removeItem(selectedDetail.id);items=await getAll();$("itemDialog").close();renderAll();showToast(t("deleted"));}catch{showToast(t("deleteFailed"));}});
function colorDistance(a,b){const palette={black:[25,25,25],white:[240,240,235],gray:[130,130,130],navy:[30,45,85],blue:[50,105,190],red:[190,55,55],green:[65,125,80],beige:[205,185,145],brown:[115,75,45],pink:[220,145,165],yellow:[220,190,60],purple:[130,80,160]};const x=palette[a]||palette.gray,y=palette[b]||palette.gray;return Math.sqrt((x[0]-y[0])**2+(x[1]-y[1])**2+(x[2]-y[2])**2);}
function harmony(a,b){if(!a||!b)return 0;if(a===b)return 5;const neutrals=["black","white","gray","navy","beige"];if(neutrals.includes(a)||neutrals.includes(b))return 10;const d=colorDistance(a,b);return Math.max(0,10-d/24);}
function scoreLook(look){const colors=look.map(i=>i.color||"gray");let score=0,pairs=0;for(let i=0;i<colors.length;i++)for(let j=i+1;j<colors.length;j++){score+=harmony(colors[i],colors[j]);pairs++;}return pairs?score/pairs:5;}
function generateLook(){
 if(!items.length){showToast(t("needItems"));return;}
 const groups=categories.map(c=>items.filter(i=>i.category===c));
 let best=null,bestScore=-1;
 // Sample combinations to avoid a huge nested search on large closets.
 const pools=groups.map(g=>g.length?g.slice().sort(()=>Math.random()-.5).slice(0,Math.min(g.length,7)):[null]);
 for(const a of pools[0])for(const b of pools[1])for(const c of pools[2])for(const d of pools[3]){
  const look=[a,b,c,d].filter(Boolean);if(!look.length)continue;
  const s=scoreLook(look)+(look.length===4?1.5:0)+(Math.random()*.25);
  if(s>bestScore){best=look;bestScore=s;}
 }
 $("outfitResult").innerHTML=`<h3>${t("lookTitle")}</h3><div class="look-grid">${best.map(i=>`<div class="look-piece"><img src="${i.image}" alt=""><div><strong>${escapeHtml(i.name||categoryName(i.category))}</strong><small>${categoryName(i.category)} · ${t(i.color||"gray")}</small></div></div>`).join("")}</div><div class="look-score">✦ ${t("colorHarmony")}</div>`;
 document.querySelector('[data-tab="outfit"]').click();
 showToast(t("generated"));
}
function renderManual(){
 const slots=categories.map(c=>{const options=items.filter(i=>i.category===c);return `<div class="manual-slot"><div class="slot-label"><span>${categoryIcons[c]}</span>${categoryName(c)}</div><select data-manual="${c}"><option value="">— ${t("emptyCategory")} —</option>${options.map(i=>`<option value="${i.id}">${escapeHtml(i.name||categoryName(c)+" #"+i.id)}</option>`).join("")}</select></div>`;}).join("");
 $("manualSlots").innerHTML=slots;
 $("manualSlots").querySelectorAll("select").forEach(s=>s.addEventListener("change",renderManualPreview));
 renderManualPreview();
}
function renderManualPreview(){
 const chosen=[...$("manualSlots").querySelectorAll("select")].map(s=>items.find(i=>i.id===Number(s.value))).filter(Boolean);
 if(!chosen.length){$("manualPreview").innerHTML=`<span>✧</span><p>${t("manualPreviewText")}</p>`;return;}
 $("manualPreview").innerHTML=`<div class="look-grid">${chosen.map(i=>`<div class="look-piece"><img src="${i.image}" alt=""><div><strong>${escapeHtml(i.name||categoryName(i.category))}</strong><small>${categoryName(i.category)} · ${t(i.color||"gray")}</small></div></div>`).join("")}</div>`;
}
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));$(btn.dataset.tab+"Page").classList.add("active");}));
$("generateBtn").addEventListener("click",generateLook);$("outfitGenerateBtn").addEventListener("click",generateLook);
$("addBtn").addEventListener("click",addDialog);$("emptyAddBtn").addEventListener("click",addDialog);$("closeDialog").addEventListener("click",()=>$("addDialog").close());$("closeItemDialog").addEventListener("click",()=>$("itemDialog").close());
$("filterSelect").addEventListener("change",renderItems);
$("langBtn").addEventListener("click",()=>{currentLang=currentLang==="ar"?"en":"ar";applyLanguage();});
(async()=>{try{db=await openDB();items=await getAll();applyLanguage();}catch(e){showToast("تعذر تشغيل قاعدة البيانات المحلية.");console.error(e);}})();
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
