const K='checklist:v1',$=id=>document.getElementById(id),uid=()=>Date.now()+Math.random();

/* ---- rich text: sanitiser + helpers (item html is stored in o.h, plain text stays in o.t) ---- */
const RC=/^(#[0-9a-f]{3,8}|rgba?\(\s*[\d.]+\s*(,\s*[\d.]+\s*){2,3}\))$/i;
function clean(html){const d=new DOMParser().parseFromString('<body>'+html,'text/html').body,out=document.createElement('div'),mk=g=>document.createElement(g);
const walk=(src,dst)=>{for(const n of [...src.childNodes]){if(n.nodeType===3){dst.append(n.textContent);continue}if(n.nodeType!==1)continue;
const g=n.tagName.toLowerCase();let e=null;
if(/^(script|style|iframe|object|embed|noscript|template|textarea|svg|math)$/.test(g))continue;
if(g==='b'||g==='strong')e=mk('b');else if(g==='i'||g==='em')e=mk('i');else if(g==='u')e=mk('u');else if(g==='s'||g==='strike'||g==='del')e=mk('s');
else if(g==='ul'||g==='ol'||g==='li')e=mk(g);else if(g==='br'){dst.append(mk('br'));continue}
else if(g==='font'||g==='span'){const c=n.getAttribute('color')||n.style.color,bg=n.style.backgroundColor,sz=+n.getAttribute('size')||0;let inner=null;
if(g==='font'&&sz>=1&&sz<=7&&sz!==3){e=mk('font');e.setAttribute('size',Math.max(2,Math.min(5,sz)))}
if((c&&RC.test(c))||(bg&&RC.test(bg))){const sp=mk('span');if(c&&RC.test(c))sp.style.color=c;if(bg&&RC.test(bg))sp.style.backgroundColor=bg;if(e)e.append(sp);else e=sp;inner=sp}
if(!e){walk(n,dst);continue}walk(n,inner||e);dst.append(e);continue}
else if(g==='div'||g==='p'){walk(n,dst);if(dst.lastChild&&dst.lastChild.nodeName!=='BR')dst.append(mk('br'));continue}
else{walk(n,dst);continue}
walk(n,e);dst.append(e)}};
walk(d,out);const h=out.innerHTML.replace(/(<br>)+$/,'');return h.includes('<')?h:''}
const plain=t=>t.innerText.replace(/\s*\n+\s*/g,' ').trim();
function setBody(t,o){if(o.h)t.innerHTML=o.h;else t.textContent=o.t}
const fa=n=>S.lang==='fa'?(+n).toLocaleString('fa-IR',{useGrouping:false}):String(n);
let S=JSON.parse(localStorage.getItem(K)||'null')||{lists:[{id:1,name:'کارهای من',items:[]}],cur:1,theme:'light',lang:'fa',dir:'auto'};S.lang=S.lang||'fa';S.dir=S.dir||'auto';
const norm=a=>a.filter(n=>n.t).map(n=>(n.p=n.p>0?1:0,n.g=n.g===1||n.g===2?n.g:0,n.one=!!n.one,n.new=false,n.locked=!!n.locked,n.h=clean(typeof n.h==='string'?n.h:'')||undefined,n.d=n.d==='rtl'||n.d==='ltr'?n.d:undefined,n.subs=norm(n.subs||[]),n));S.lists.forEach(l=>{l.items=norm(l.items);l.locked=!!l.locked});
let filter='all',tt,focus=null,quiet=false,landed=null,sel=null,enter=true;const save=()=>localStorage.setItem(K,JSON.stringify(S)),cur=()=>S.lists.find(l=>l.id===S.cur)||S.lists[0];
function toast(msg,undo){const t=$('toast');t.textContent=msg;if(undo){const b=document.createElement('button');b.textContent=L('undo');b.onclick=()=>{undo();save();render();t.classList.remove('on')};t.append(b)}
t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),4500)}
function side(){$('lists').innerHTML='';S.lists.forEach(x=>{const li=document.createElement('li');li.className=x.id===cur().id?'on':'';li.title=x.name;li.innerHTML='<span class="nm"></span><small></small>';
li.firstChild.dir=S.dir;li.firstChild.textContent=x.name;li.lastChild.textContent=fa(x.items.filter(i=>i.done).length)+'/'+fa(x.items.length);li.onclick=()=>{S.cur=x.id;save();enter=true;render()};if(x.locked){const k=document.createElement('span');k.className='sl';k.innerHTML=IC.lock;li.append(k)}else li.append(xb(e=>{e.stopPropagation();delL(x)}));$('lists').append(li)})}
const RM=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;
function burst(x,y,n,cols,spread,grav){if(RM())return;for(let k=0;k<n;k++){const e=document.createElement('i'),a=Math.random()*Math.PI*2,r=spread*(.45+Math.random()*.55);e.className='sp';
e.style.cssText=`--x:${x}px;--y:${y}px;--dx:${Math.cos(a)*r}px;--dy:${Math.sin(a)*r}px;--g:${grav}px;--r:${Math.round(Math.random()*540-270)}deg;background:${cols[k%cols.length]};width:${5+Math.random()*5}px;height:${5+Math.random()*5}px;border-radius:${Math.random()<.5?'50%':'2px'};animation-delay:${Math.round(Math.random()*60)}ms`;document.body.append(e);setTimeout(()=>e.remove(),1200)}}
let pv=0,pp=null,ppl=null,raf2=0;
function tweenPct(to){const el=$('pct'),from=pv,sg=S.lang==='fa'?'٪':'%';cancelAnimationFrame(raf2);if(RM()||from===to){pv=to;el.textContent=fa(to)+sg;return}const t0=performance.now();
const step=t=>{const k=Math.min(1,(t-t0)/450);pv=from+(to-from)*(1-Math.pow(1-k,3));el.textContent=fa(Math.round(pv))+sg;if(k<1)raf2=requestAnimationFrame(step);else pv=to};raf2=requestAnimationFrame(step)}
function celebrate(){const r=document.querySelector('.bar').getBoundingClientRect(),c=['#157A75','#4F5FD0','#C2477A','#B7791F','#4E8F2E','#F2C14E'];burst(r.left+r.width*.3,r.top+4,34,c,180,120);burst(r.left+r.width*.7,r.top+4,34,c,180,120)}
function stats(){const l=cur(),n=l.items.length,d=l.items.filter(i=>i.done).length,p=n?Math.round(d/n*100):0,all=n>0&&p===100;$('fill').style.width=p+'%';tweenPct(p);document.querySelector('.prog').classList.toggle('all',all);
$('stat').textContent=n?(all?L('allDone'):T[S.lang].stat(fa(d),fa(n))):L('none');if(ppl===l.id&&pp!==null&&pp<100&&all)celebrate();pp=p;ppl=l.id;side()}
const ck=(on,fn)=>{const b=document.createElement('button');b.className='ck'+(on?' on':'');b.setAttribute('role','checkbox');b.setAttribute('aria-checked',on);b.innerHTML='<svg viewBox="0 0 24 24"><path d="M6 12.5l4 4 8-9"/></svg>';
b.sync=v=>{on=v;b.classList.toggle('on',v);b.setAttribute('aria-checked',v)};b.onclick=()=>{on=!on;b.classList.toggle('on',on);b.setAttribute('aria-checked',on);fn(on);if(on){b.classList.remove('pop');void b.offsetWidth;b.classList.add('pop');const r=b.getBoundingClientRect(),c=getComputedStyle(b).getPropertyValue('--c').trim()||'#157A75';burst(r.left+r.width/2,r.top+r.height/2,9,[c,'#F2C14E',c],36,18)}};return b};
const chip=(cls,txt,fn)=>{const b=document.createElement('button');b.className='chip '+cls;b.textContent=txt;b.onclick=fn;return b};
const xb=fn=>{const b=document.createElement('button');b.className='x';b.textContent='✕';b.title=L('del');b.setAttribute('aria-label',L('del'));b.onclick=fn;return b};
const IC={lock:'<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2.6"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle class="fl" cx="12" cy="16" r="1.3"/></svg>',
open:'<svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2.6"/><path d="M8 11V8a4 4 0 0 1 7.6-1.7"/><circle class="fl" cx="12" cy="16" r="1.3"/></svg>',
copy:'<svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2.6"/><path d="M15 9V6.6A2.6 2.6 0 0 0 12.4 4H6.6A2.6 2.6 0 0 0 4 6.6v5.8A2.6 2.6 0 0 0 6.6 15H9"/></svg>',
one:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><circle class="fl" cx="12" cy="12" r="3.4"/></svg>',
grip:'<svg viewBox="0 0 24 24"><circle cx="9" cy="6" r="1.7"/><circle cx="15" cy="6" r="1.7"/><circle cx="9" cy="12" r="1.7"/><circle cx="15" cy="12" r="1.7"/><circle cx="9" cy="18" r="1.7"/><circle cx="15" cy="18" r="1.7"/></svg>'};
const lockBtn=(own,inh,fn)=>{const b=document.createElement('button'),on=own||inh;b.className='lk'+(own&&!inh?' on':'')+(inh?' inh':'');b.innerHTML=IC[on?'lock':'open'];
const t=L(inh?'lockedBy':own?'unlock':'lock');b.title=t;b.setAttribute('aria-label',t);b.setAttribute('aria-pressed',on);b.disabled=inh;b.onclick=fn;return b};
const gripBtn=(lk,fn)=>{const b=document.createElement('button');b.className='gr'+(lk?' gone':'');b.innerHTML=IC.grip;b.title=L('move');b.setAttribute('aria-label',L('move'));b.disabled=lk;b.onpointerdown=fn;return b};
const clone=n=>({...n,id:uid(),done:false,locked:false,new:false,subs:n.subs.map(clone)});
const dupBtn=(off,fn)=>{const b=document.createElement('button');b.className='dp'+(off?' gone':'');b.innerHTML=IC.copy;b.title=L('dup');b.setAttribute('aria-label',L('dup'));b.disabled=off;b.onclick=fn;return b};
/* drag & drop: move a check anywhere — reorder, change level, or move into another check */
function drag(e,li,arr){if(e.button>0||!e.isPrimary)return;const h=e.currentTarget,M=document.querySelector('main'),I=$('items'),rtl=getComputedStyle(document.documentElement).direction==='rtl',
vis=z=>{for(let p=z.parentElement.closest('.nd');p;p=p.parentElement.closest('.nd'))if(!p.classList.contains('open'))return false;return true},
rows=[...I.querySelectorAll('.nd')].filter(z=>!li.contains(z)&&vis(z)),top=z=>z.firstElementChild.getBoundingClientRect();
if(!rows.length)return;e.preventDefault();
const tr=top(li),g=document.createElement('div'),dz=document.createElement('div'),x0=e.clientX,y0=e.clientY;
g.className='nd dragghost '+[...li.classList].filter(c=>/^(h\d|d0|dn)$/.test(c)).join(' ');g.style.cssText=`left:${tr.left}px;top:${tr.top}px;width:${tr.width}px`;g.append(li.firstElementChild.cloneNode(true));dz.id='dz';document.body.append(g,dz);
li.classList.add('ghosted');document.body.classList.add('grabbing');
let x=x0,y=y0,t=null,raf=0,done=false,inEl=null;try{h.setPointerCapture(e.pointerId)}catch{}
const pick=()=>{const lr=li.getBoundingClientRect();if(y>=lr.top&&y<=lr.bottom)return null;
if(y>top(rows[rows.length-1]).bottom)return{k:'end'};
let b=null,br=null,bd=1e9;for(const z of rows){const r=top(z),d=y<r.top?r.top-y:y>r.bottom?y-r.bottom:0;if(d<bd){bd=d;b=z;br=r}}
const f=Math.max(0,Math.min(1,(y-br.top)/br.height)),canIn=!b._lk,canSib=!b._plk;
if(f<.3)return canSib?{k:'before',x:b}:null;
if(b._o.subs.length&&b.classList.contains('open'))return canIn?{k:'first',x:b}:null;
if(f>.7||!canIn)return canSib?{k:f<.5?'before':'after',x:b}:null;
return{k:'in',x:b}};
const show=t=>{if(inEl){inEl.classList.remove('dz-in');inEl=null}dz.style.display='none';if(!t)return;
if(t.k==='in'){inEl=t.x;inEl.classList.add('dz-in');return}
let r,ind=0,ty;if(t.k==='end'){r=I.getBoundingClientRect();ty=top(rows[rows.length-1]).bottom+3}
else{r=top(t.x);ty=t.k==='before'?r.top-5:r.bottom+3;if(t.k==='first')ind=30}
dz.style.cssText=`display:block;top:${ty}px;left:${rtl?r.left:r.left+ind}px;width:${r.width-ind}px`};
const upd=()=>{g.style.transform=`translate(${x-x0}px,${y-y0}px)`;t=pick();show(t)};
const auto=()=>{const r=M.getBoundingClientRect(),z=70;let v=0;if(y<r.top+z)v=-(r.top+z-y)/4;else if(y>r.bottom-z)v=(y-(r.bottom-z))/4;if(v){M.scrollTop+=Math.max(-18,Math.min(18,v));upd()}raf=requestAnimationFrame(auto)};
const end=ok=>{if(done)return;done=true;cancelAnimationFrame(raf);h.onpointermove=h.onpointerup=h.onpointercancel=null;document.removeEventListener('keydown',key);try{h.releasePointerCapture(e.pointerId)}catch{}
const tg=t;show(null);g.remove();dz.remove();li.classList.remove('ghosted');document.body.classList.remove('grabbing');if(ok&&tg)place(li,tg)};
const key=k=>{if(k.key==='Escape')end(false)};document.addEventListener('keydown',key);
h.onpointermove=ev=>{x=ev.clientX;y=ev.clientY;upd()};h.onpointerup=()=>end(true);h.onpointercancel=()=>end(false);raf=requestAnimationFrame(auto)}
function place(li,t){const o=li._o,src=li._arr,si=src.indexOf(o);let dst,idx;src.splice(si,1);
if(t.k==='end'){dst=cur().items;idx=dst.length}
else if(t.k==='in'||t.k==='first'){const p=t.x._o;dst=p.subs;idx=t.k==='first'?0:dst.length;p.open=true}
else{dst=t.x._arr;idx=dst.indexOf(t.x._o)+(t.k==='after'?1:0)}
if(dst===src&&idx===si)return src.splice(si,0,o);
dst.splice(idx,0,o);const pj=t.k==='end'?null:(t.k==='in'||t.k==='first')?t.x._o:t.x._po;if(pj&&pj.one&&o.done)pj.subs.forEach(x=>{if(x!==o)x.done=false});landed=o;save();quiet=true;render()}
function editable(o,arr,lk){const t=document.createElement('div');t.className='t';t.dir=o.d||S.dir;t.dataset.ph=L('write');t.contentEditable=!lk;setBody(t,o);t.dataset.id=o.id;t._o=o;
t.onblur=()=>{if(!t.isConnected)return;const v=plain(t);if(v){o.t=v;const h=clean(t.innerHTML);o.h=h||undefined;o.new=false;save();if(h)t.innerHTML=h}else if(o.new||!o.t){arr.splice(arr.indexOf(o),1);save();render()}else setBody(t,o)};
t.onpaste=e=>{e.preventDefault();document.execCommand('insertText',false,(e.clipboardData||window.clipboardData).getData('text/plain').replace(/\s*\r?\n+\s*/g,' '))};
t.onkeydown=e=>{if(e.key==='Enter'){if(e.ctrlKey||e.metaKey){e.preventDefault();t.blur();return}if(e.shiftKey){e.preventDefault();document.execCommand('insertLineBreak');return}
const a=getSelection().anchorNode,el=a&&(a.nodeType===1?a:a.parentElement);if(el&&t.contains(el)&&el.closest('li'))return;e.preventDefault();t.blur()}
if(e.key==='Escape'){if(o.new)t.textContent='';else setBody(t,o);t.blur()}};return t}
function node(arr,o,d,pc,plk,po){const lk=!!plk||!!o.locked,li=document.createElement('div'),top=document.createElement('div'),main=document.createElement('div'),meta=document.createElement('div');li._o=o;li._arr=arr;li._po=po;li._plk=!!plk;li._lk=lk;
li.className='nd h'+d%5+' '+(d?'dn':'d0')+(o.open?' open':'')+(o.done?' done':'')+(lk?' lkd':'')+(o===landed?' landed':'')+(o===sel?' sel':'')+(o.new?' born':'');top.className='top';main.className='main';meta.className='meta';
const cnt=()=>{tg.textContent=fa(o.subs.filter(s=>s.done).length)+'/'+fa(o.subs.length);tg.hidden=!o.subs.length};
const tg=chip('tg','',()=>{o.open=!o.open;li.classList.toggle('open',o.open);save()});cnt();
const lv=chip('lv c'+o.p,o.p?L('imp'):L('normal'),()=>{if(lk)return;o.p=o.p?0:1;lv.className='chip lv c'+o.p;lv.textContent=o.p?L('imp'):L('normal');save()});lv.disabled=lk;
const ad=chip('ad','+',()=>{const s={id:uid(),t:'',done:false,p:0,subs:[],new:true,locked:false};o.subs.push(s);o.open=true;focus=s.id;render()});ad.title=L('sub');ad.setAttribute('aria-label',L('sub'));
const gl=g=>g===1?L('good'):g===2?L('bad'):L('neutral');
const gd=chip('lv gd g'+(o.g||0),gl(o.g),()=>{if(lk)return;o.g=((o.g||0)+1)%3;gd.className='chip lv gd g'+o.g;gd.textContent=gl(o.g);save()});gd.disabled=lk;gd.title=L('gdTip');
const one=document.createElement('button');one.className='one'+(o.one?' on':'');one.innerHTML=IC.one;one.title=L(o.one?'oneOn':'oneOff');one.setAttribute('aria-label',one.title);one.setAttribute('aria-pressed',!!o.one);
one.onclick=()=>{o.one=!o.one;let undo=null;if(o.one){const t=o.subs.filter(s=>s.done);if(t.length>1){const rest=t.slice(1);rest.forEach(s=>s.done=false);undo=()=>{rest.forEach(s=>s.done=true);o.one=false}}}save();quiet=true;render();if(undo)toast(L('oneKept'),undo)};
meta.append(lv);meta.append(gd);if(!lk){meta.append(ad);meta.append(one)}meta.append(tg);main.append(editable(o,arr,lk),meta);
const del=xb(()=>{const k=arr.indexOf(o);arr.splice(k,1);save();render();toast(L('deleted'),()=>arr.splice(k,0,o))});if(lk){del.classList.add('gone');del.disabled=true}
const cb=ck(o.done,v=>{o.done=v;li.classList.toggle('done',v);if(o.subs.length){o.open=v;li.classList.toggle('open',v)}
if(v&&po&&po.one)[...li.parentElement.children].forEach(el=>{const x=el._o;if(x&&x!==o&&x.done){x.done=false;el.classList.remove('done');if(x.subs.length){x.open=false;el.classList.remove('open')}const b=el.querySelector(':scope>.top>.ck');if(b)b.sync(false)}});
save();pc?pc():stats()});if(po&&po.one){cb.classList.add('rd');cb.setAttribute('role','radio')}
top.append(gripBtn(lk,e=>drag(e,li,arr)),cb,main,
dupBtn(!!plk,()=>{const c=clone(o);arr.splice(arr.indexOf(o)+1,0,c);landed=c;save();quiet=true;render();toast(L('duped'),()=>{const k=arr.indexOf(c);if(k>-1)arr.splice(k,1)})}),lockBtn(!!o.locked,!!plk,()=>{o.locked=!o.locked;save();quiet=true;render()}),del,Object.assign(document.createElement('i'),{className:'rp'}));
const sw=document.createElement('div'),inn=document.createElement('div');sw.className='subs';o.subs.forEach(s=>inn.append(node(o.subs,s,d+1,cnt,lk,o)));sw.append(inn);li.append(top,sw);return li}
function row(l,i){return node(l.items,i,0,null,l.locked)}
function render(){applyLang();const l=cur();S.cur=l.id;document.documentElement.dataset.theme=S.theme;if($('title')!==document.activeElement)$('title').value=l.name;$('title').dir=S.dir;$('title').readOnly=!!l.locked;$('delList').disabled=!!l.locked;$('add').classList.toggle('off',!!l.locked);
const lb=$('lockList');lb.className='lkl'+(l.locked?' on':'');lb.innerHTML=IC[l.locked?'lock':'open']+'<span>'+L(l.locked?'listOn':'lockList')+'</span>';lb.title=L(l.locked?'listOnTip':'lockListTip');lb.setAttribute('aria-pressed',!!l.locked);stats();
const q=$('q').value.trim().toLowerCase(),has=x=>x.t.toLowerCase().includes(q)||x.subs.some(has);$('items').classList.toggle('still',quiet||!enter);quiet=false;enter=false;$('items').innerHTML='';
const list=l.items.filter(i=>(filter==='all'||(filter==='done')===i.done)&&has(i));
list.forEach((i,k)=>{const e=row(l,i);e.style.setProperty('--i',Math.min(k,14));$('items').append(e)});if(!list.length)$('items').innerHTML='<div class="empty">'+(l.items.length?L('nf'):L('hint'))+'</div>';
if(focus){const e=document.querySelector(`[data-id="${focus}"]`);if(e)e.focus();focus=null}
const hs=!!$('items').querySelector('.sel');if(!hs)sel=null;$('items').classList.toggle('focusing',hs);
const ld=$('items').querySelector('.landed');if(ld)ld.scrollIntoView({block:'nearest'});landed=null;if(typeof tbCheck==='function'&&B.bold)tbCheck()}
const T={fa:{app:'فهرست',newList:'+ لیست جدید',theme:'تم',export:'خروجی',import:'ورودی',settings:'تنظیمات',listName:'نام لیست',delList:'حذف لیست',search:'جست‌وجو…',all:'همه',todo:'مانده',done:'انجام‌شده',newItem:'کار جدید',write:'چیزی بنویس…',sub:'زیرچک',del:'حذف',normal:'عادی',imp:'★ مهم',myList:'کارهای من',newListName:'لیست جدید',noName:'بدون نام',stat:(d,n)=>`${d} از ${n} انجام شد`,none:'هنوز کاری اضافه نشده',hint:'با دکمه‌ی + اولین کار را اضافه کن',nf:'چیزی پیدا نشد',deleted:'حذف شد',listDeleted:'لیست حذف شد',undo:'بازگردانی',bad:'فایل معتبر نیست',replace:'همه‌ی لیست‌های فعلی با این فایل جایگزین شود؟',lang:'زبان برنامه',dir:'جهت متن',dauto:'خودکار',drtl:'راست‌به‌چپ',dltr:'چپ‌به‌راست',close:'بستن',dirHint:'جهت نوشتار متن کارها و نام لیست‌ها',light:'روشن',dark:'تیره',title:'فهرست — چک‌لیست',move:'جابه‌جایی (بکش)',allDone:'همه‌ی کارها انجام شد 🎉',dup:'کپی کردن',duped:'کپی ساخته شد',good:'خوب',bad:'بد',neutral:'خنثی',gdTip:'خوب / بد / خنثی',oneOff:'فقط یکی از زیرچک‌ها قابل تیک باشد',oneOn:'حالت تک‌انتخابی روشن است — برای خاموش کردن بزن',oneKept:'فقط اولین تیک نگه داشته شد',lock:'قفل کارت',unlock:'باز کردن قفل',lockedBy:'قفل شده از سطح بالاتر',lockList:'قفل لیست',listOn:'لیست قفل است',lockListTip:'قفل همه‌ی چک‌ها — فقط تیک زدن ممکن می‌شود',listOnTip:'باز کردن قفل لیست',listLocked:'لیست قفل است — فقط می‌توانی تیک بزنی'},
en:{app:'Checklist',newList:'+ New list',theme:'Theme',export:'Export',import:'Import',settings:'Settings',listName:'List name',delList:'Delete list',search:'Search…',all:'All',todo:'Open',done:'Done',newItem:'New item',write:'Type something…',sub:'Add sub-item',del:'Delete',normal:'Normal',imp:'★ Important',myList:'My tasks',newListName:'New list',noName:'Untitled',stat:(d,n)=>`${d} of ${n} done`,none:'Nothing here yet',hint:'Tap + to add your first item',nf:'Nothing found',deleted:'Deleted',listDeleted:'List deleted',undo:'Undo',bad:'Invalid file',replace:'Replace all current lists with this file?',lang:'App language',dir:'Text direction',dauto:'Auto',drtl:'Right-to-left',dltr:'Left-to-right',close:'Close',dirHint:'Direction of item text and list names',light:'Light',dark:'Dark',title:'Checklist',move:'Drag to reorder',allDone:'All done 🎉',dup:'Duplicate',duped:'Duplicated',good:'Good',bad:'Bad',neutral:'Neutral',gdTip:'Good / bad / neutral',oneOff:'Allow only one sub-item to be ticked',oneOn:'Single-choice is on — click to turn off',oneKept:'Kept only the first ticked item',lock:'Lock card',unlock:'Unlock',lockedBy:'Locked by a parent or the list',lockList:'Lock list',listOn:'List locked',lockListTip:'Lock every item — ticking only',listOnTip:'Unlock list',listLocked:'List is locked — you can only tick items'}};
const L=k=>T[S.lang][k];
function applyLang(){const h=document.documentElement;h.lang=S.lang;h.dir=S.lang==='fa'?'rtl':'ltr';document.title=L('title');
document.querySelectorAll('[data-i18n]').forEach(e=>e.textContent=L(e.dataset.i18n));
$('q').placeholder=L('search');$('q').dir=S.dir;$('title').setAttribute('aria-label',L('listName'));$('add').setAttribute('aria-label',L('newItem'));if(typeof tbLang==='function'&&B.bold)tbLang()}
function openSettings(){const ov=document.createElement('div');ov.className='ov';document.body.append(ov);
const seg=(k,o)=>'<div class="seg">'+o.map(([v,l])=>`<button data-k="${k}" data-v="${v}" class="${S[k]===v?'on':''}">${l}</button>`).join('')+'</div>';
const draw=()=>{ov.innerHTML=`<div class="mp"><h2>${L('settings')}</h2><h3>${L('lang')}</h3>${seg('lang',[['fa','فارسی'],['en','English']])}<h3>${L('dir')}</h3>${seg('dir',[['auto',L('dauto')],['rtl',L('drtl')],['ltr',L('dltr')]])}<small>${L('dirHint')}</small><h3>${L('theme')}</h3>${seg('theme',[['light',L('light')],['dark',L('dark')]])}<button class="cl" data-close>${L('close')}</button></div>`};
ov.onclick=e=>{const b=e.target.closest('button');if(e.target===ov||(b&&b.dataset.close!==undefined))return ov.remove();if(b&&b.dataset.k){S[b.dataset.k]=b.dataset.v;save();render();draw()}};draw()}
$('settings').onclick=openSettings;
function setFilter(f){filter=f;document.querySelectorAll('[data-f]').forEach(x=>x.classList.toggle('on',x.dataset.f===f))}
$('add').onclick=()=>{if(cur().locked)return toast(L('listLocked'));setFilter('all');$('q').value='';const i={id:uid(),t:'',done:false,p:0,subs:[],new:true};cur().items.unshift(i);focus=i.id;render()};
$('title').oninput=e=>{cur().name=e.target.value||L('noName');save();side()};
$('addList').onclick=()=>{const l={id:uid(),name:L('newListName'),items:[]};S.lists.push(l);S.cur=l.id;save();enter=true;render();$('title').focus();$('title').select()};
function delL(l){const k=S.lists.indexOf(l);let fresh=null;S.lists.splice(k,1);if(!S.lists.length){fresh={id:uid(),name:L('myList'),items:[]};S.lists.push(fresh)}if(S.cur===l.id)S.cur=S.lists[0].id;save();enter=true;render();
toast(L('listDeleted'),()=>{if(fresh)S.lists.splice(S.lists.indexOf(fresh),1);S.lists.splice(k,0,l);S.cur=l.id})}
$('delList').onclick=()=>{if(!cur().locked)delL(cur())};
$('lockList').onclick=()=>{const l=cur();l.locked=!l.locked;save();quiet=true;render()};
document.querySelectorAll('[data-f]').forEach(b=>b.onclick=()=>{setFilter(b.dataset.f);enter=true;render()});$('q').oninput=render;
$('export').onclick=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(S,null,2)],{type:'application/json'}));a.download='checklist-backup.json';a.click()};
$('import').onclick=()=>$('file').click();
$('file').onchange=async e=>{try{const j=JSON.parse(await e.target.files[0].text());if(!Array.isArray(j.lists)||!j.lists.length)throw 0;if(confirm(L('replace'))){j.lists.forEach(l=>{l.items=norm(l.items||[]);l.locked=!!l.locked});S=j;save();enter=true;render()}}catch{toast(L('bad'))}e.target.value=''};
/* working-on-a-card state: click a card to focus it, click elsewhere / Esc to release */
const unsel=()=>document.querySelectorAll('#items .sel').forEach(x=>x.classList.remove('sel'));
const clearSel=()=>{sel=null;unsel();$('items').classList.remove('focusing')};
const setSel=li=>{if(sel===li._o)return;unsel();sel=li._o;li.classList.add('sel');$('items').classList.add('focusing')};
function ripple(top,e){const r=top.getBoundingClientRect(),b=document.createElement('b'),rp=top.querySelector('.rp');if(!rp)return;b.className='rpl';b.style.cssText=`left:${e.clientX-r.left}px;top:${e.clientY-r.top}px`;rp.append(b);setTimeout(()=>b.remove(),750)}
document.addEventListener('pointerdown',e=>{const top=e.target.closest&&e.target.closest('#items .nd>.top');
if(top){if(e.target.closest('button'))return;setSel(top.parentElement);ripple(top,e);return}
if(e.target.closest&&e.target.closest('.ov,#toast,.fab,.rtb'))return;clearSel()});
$('items').addEventListener('focusin',e=>{const t=e.target.closest&&e.target.closest('.t');if(t){const li=t.closest('.nd');if(li)setSel(li)}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&sel&&!document.querySelector('.ov')&&!document.body.classList.contains('grabbing'))clearSel()});

/* ---- floating rich-text toolbar: shows only while a card's text is being edited; drag the grip to move it ---- */
Object.assign(T.fa,{rBold:'پررنگ (Ctrl+B)',rItalic:'کج (Ctrl+I)',rUnder:'زیرخط (Ctrl+U)',rStrike:'خط‌خورده',rFore:'رنگ متن',rBack:'هایلایت',rSm:'کوچک‌تر',rLg:'بزرگ‌تر',rUl:'فهرست نقطه‌ای',rOl:'فهرست شماره‌دار',rDir:'جهت متن این کار',rClear:'پاک کردن قالب‌بندی',rUndo:'واگرد',rRedo:'بازگشت',rDone:'تمام (Ctrl+Enter)',rMove:'جابه‌جایی نوار (بکش — دوبار کلیک: جای اول)',rNone:'بدون رنگ',rBar:'قالب‌بندی متن'});
Object.assign(T.en,{rBold:'Bold (Ctrl+B)',rItalic:'Italic (Ctrl+I)',rUnder:'Underline (Ctrl+U)',rStrike:'Strikethrough',rFore:'Text color',rBack:'Highlight',rSm:'Smaller',rLg:'Larger',rUl:'Bulleted list',rOl:'Numbered list',rDir:'Text direction of this item',rClear:'Clear formatting',rUndo:'Undo',rRedo:'Redo',rDone:'Done (Ctrl+Enter)',rMove:'Move toolbar (drag — double-click to reset)',rNone:'No color',rBar:'Text formatting'});
const TB=document.createElement('div'),TBK='checklist:tb',B={};let tbp=null,pop=null,tbTimer=0;try{tbp=JSON.parse(localStorage.getItem(TBK)||'null')}catch{}
TB.className='rtb';TB.dir='ltr';TB.setAttribute('role','toolbar');
const ED=()=>{const a=document.activeElement;return a&&a.classList&&a.classList.contains('t')&&a.isContentEditable&&$('items').contains(a)?a:null};
const sv=p=>`<svg viewBox="0 0 24 24">${p}</svg>`;
const mkb=(id,html,tip,fn)=>{const b=document.createElement('button');b.type='button';b.tabIndex=-1;b.className='rb '+id;b.innerHTML=html;b.dataset.tip=tip;b.onclick=fn;B[id]=b;return b};
const grp=(...b)=>{const g=document.createElement('div');g.className='rg';g.append(...b);return g};
const run=(c,v)=>{if(!ED())return;document.execCommand(c,false,v);sync()};
const size=d=>{if(!ED())return;const s=+document.queryCommandValue('fontSize')||3;run('fontSize',Math.max(2,Math.min(5,s+d)))};
const FORE=['#E5484D','#F76B15','#D9A400','#2FA84F','#0FA5A0','#4F7CFF','#B45AE0','#8B8B8B'],BACK=['rgba(242,193,78,.5)','rgba(80,200,140,.4)','rgba(90,150,255,.35)','rgba(240,110,170,.35)','rgba(255,140,60,.38)','transparent'];
function openPop(kind,btn){if(pop===kind){closePop();return}pop=kind;const P=TB.querySelector('.rpop');P.innerHTML='';
(kind==='fore'?FORE:BACK).forEach(c=>{const w=document.createElement('button');w.type='button';w.tabIndex=-1;w.className='sw'+(c==='transparent'?' none':'');w.style.background=c==='transparent'?'':c;w.title=c==='transparent'?L('rNone'):'';
w.onclick=()=>{if(!ED())return closePop();if(kind==='back')document.execCommand('styleWithCSS',false,true);document.execCommand(kind==='fore'?'foreColor':'hiliteColor',false,c);document.execCommand('styleWithCSS',false,false);if(kind==='fore')B.fore.style.setProperty('--cc',c);closePop();sync()};P.append(w)});
const vh=window.visualViewport?visualViewport.height:innerHeight,r=TB.getBoundingClientRect();P.className='rpop on '+(r.top+r.height/2>vh/2?'up':'dn');P.style.left=Math.max(0,Math.min(btn.offsetLeft+btn.parentElement.offsetLeft,TB.offsetWidth-P.offsetWidth))+'px';B.fore.classList.toggle('open',kind==='fore');B.back.classList.toggle('open',kind==='back')}
function closePop(){pop=null;const P=TB.querySelector('.rpop');if(P){P.className='rpop';P.innerHTML=''}B.fore&&B.fore.classList.remove('open');B.back&&B.back.classList.remove('open')}
const toggleDir=()=>{const t=ED();if(!t)return;const cd=t.dir==='auto'||!t.dir?getComputedStyle(t).direction:t.dir,nd=cd==='rtl'?'ltr':'rtl';t.dir=nd;t._o.d=nd;save();sync()};
TB.append(
 (()=>{const h=mkb('hd',IC.grip,'rMove',()=>{});h.onclick=null;return h})(),
 grp(mkb('bold','<b>B</b>','rBold',()=>run('bold')),mkb('italic','<i>I</i>','rItalic',()=>run('italic')),mkb('underline','<u>U</u>','rUnder',()=>run('underline')),mkb('strikeThrough','<s>S</s>','rStrike',()=>run('strikeThrough'))),
 grp(mkb('fore','A','rFore',e=>openPop('fore',e.currentTarget)),mkb('back','<span>ab</span>','rBack',e=>openPop('back',e.currentTarget))),
 grp(mkb('sm','A<small>−</small>','rSm',()=>size(-1)),mkb('lg','A<small>+</small>','rLg',()=>size(1))),
 grp(mkb('insertUnorderedList',sv('<circle cx="5" cy="7" r="1.2"/><circle cx="5" cy="12" r="1.2"/><circle cx="5" cy="17" r="1.2"/><path d="M10 7h10M10 12h10M10 17h10"/>'),'rUl',()=>run('insertUnorderedList')),
     mkb('insertOrderedList',sv('<text x="2" y="9">1</text><text x="2" y="14">2</text><text x="2" y="19">3</text><path d="M10 7h10M10 12h10M10 17h10"/>'),'rOl',()=>run('insertOrderedList'))),
 grp(mkb('dir','LTR','rDir',toggleDir),mkb('clear',sv('<path d="M5 5h11M10.5 5v13M14 14l6 6M20 14l-6 6"/>'),'rClear',()=>run('removeFormat'))),
 grp(mkb('undo',sv('<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>'),'rUndo',()=>run('undo')),mkb('redo',sv('<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>'),'rRedo',()=>run('redo'))),
 mkb('ok',sv('<path d="M5 12.5l4.5 4.5L19 7"/>'),'rDone',()=>{const t=ED();if(t)t.blur()}),
 Object.assign(document.createElement('div'),{className:'rpop'}));
document.body.append(TB);
/* keep the editor focused: toolbar clicks must never steal focus / selection */
['pointerdown','mousedown'].forEach(ev=>TB.addEventListener(ev,e=>e.preventDefault()));
function sync(){const t=ED();if(!t)return;const done=!!(t.closest('.nd')&&t.closest('.nd').classList.contains('done'));
['bold','italic','underline','strikeThrough','insertUnorderedList','insertOrderedList'].forEach(c=>{let v=false;try{v=document.queryCommandState(c)}catch{}B[c].classList.toggle('on',v&&!(done&&c==='strikeThrough'))});
B.dir.textContent=(t.dir==='auto'||!t.dir?getComputedStyle(t).direction:t.dir).toUpperCase()}
document.addEventListener('selectionchange',sync);
function tbLang(){TB.querySelectorAll('[data-tip]').forEach(b=>{b.title=L(b.dataset.tip);b.setAttribute('aria-label',b.title)});TB.setAttribute('aria-label',L('rBar'))}
/* position: ratios inside the visible viewport, so it survives resize / keyboard / rotation */
function tbPlace(){const v=window.visualViewport,vw=v?v.width:innerWidth,vh=v?v.height:innerHeight,ox=v?v.offsetLeft:0,oy=v?v.offsetTop:0,w=TB.offsetWidth,h=TB.offsetHeight,m=8,mx=Math.max(m,vw-w-m),my=Math.max(m,vh-h-m);
let x,y;if(tbp){x=m+(mx-m)*tbp.fx;y=m+(my-m)*tbp.fy}else{x=(vw-w)/2;y=vh-h-96}
x=Math.max(m,Math.min(mx,x));y=Math.max(m,Math.min(my,y));TB.style.left=ox+x+'px';TB.style.top=oy+y+'px'}
function tbCheck(){clearTimeout(tbTimer);tbTimer=setTimeout(()=>{const t=ED();if(t){tbPlace();TB.classList.add('on');sync()}else{TB.classList.remove('on');closePop()}},0)}
$('items').addEventListener('focusin',tbCheck);$('items').addEventListener('focusout',tbCheck);
addEventListener('resize',()=>TB.classList.contains('on')&&tbPlace());if(window.visualViewport){visualViewport.addEventListener('resize',()=>TB.classList.contains('on')&&tbPlace());visualViewport.addEventListener('scroll',()=>TB.classList.contains('on')&&tbPlace())}
/* drag by the grip */
(()=>{const h=B.hd;let sx,sy,x0,y0,go=false;h.onpointerdown=e=>{if(e.button>0)return;go=true;sx=e.clientX;sy=e.clientY;x0=parseFloat(TB.style.left)||0;y0=parseFloat(TB.style.top)||0;try{h.setPointerCapture(e.pointerId)}catch{}TB.classList.add('drag');closePop()};
h.onpointermove=e=>{if(!go)return;const v=window.visualViewport,vw=v?v.width:innerWidth,vh=v?v.height:innerHeight,ox=v?v.offsetLeft:0,oy=v?v.offsetTop:0,m=8,w=TB.offsetWidth,ht=TB.offsetHeight;
const x=Math.max(ox+m,Math.min(ox+vw-w-m,x0+e.clientX-sx)),y=Math.max(oy+m,Math.min(oy+vh-ht-m,y0+e.clientY-sy));TB.style.left=x+'px';TB.style.top=y+'px'};
const end=()=>{if(!go)return;go=false;TB.classList.remove('drag');const v=window.visualViewport,vw=v?v.width:innerWidth,vh=v?v.height:innerHeight,ox=v?v.offsetLeft:0,oy=v?v.offsetTop:0,m=8,mx=Math.max(m+1,vw-TB.offsetWidth-m),my=Math.max(m+1,vh-TB.offsetHeight-m);
const fx=Math.max(0,Math.min(1,(parseFloat(TB.style.left)-ox-m)/(mx-m))),fy=Math.max(0,Math.min(1,(parseFloat(TB.style.top)-oy-m)/(my-m)));tbp={fx,fy};try{localStorage.setItem(TBK,JSON.stringify(tbp))}catch{}};
h.onpointerup=end;h.onpointercancel=end;h.ondblclick=()=>{tbp=null;try{localStorage.removeItem(TBK)}catch{}tbPlace()}})();
if('serviceWorker'in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('sw.js').catch(()=>{});
render();
