// ==================== GÖREV TAKİP UYGULAMASI ====================
const STORAGE_KEY = 'gorevTakip_v3';

// Varsayılan kategoriler
const DEFAULT_CATEGORIES = [
  { id: 'cat1', name: 'Zikirler', color: '#10b981' },
  { id: 'cat2', name: 'Dersler', color: '#3b82f6' },
  { id: 'cat3', name: 'Namazlar', color: '#8b5cf6' }
];

let state = {
  tasks: [],
  categories: [...DEFAULT_CATEGORIES],
  theme: 'dark',
  selectedPriority: 'medium',
  selectedColor: '#3b82f6'
};

// ==================== YARDIMCI FONKSİYONLAR ====================
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function formatDateTR(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  const days = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  return `${d.getDate()} ${months[d.getMonth()]} ${days[d.getDay()]}`;
}

function getDayOfWeek(dateStr) {
  return new Date(dateStr + 'T00:00:00').getDay(); // 0=Pazar
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    tasks: state.tasks,
    categories: state.categories,
    theme: state.theme
  }));
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      state.tasks = data.tasks || [];
      state.categories = data.categories || [...DEFAULT_CATEGORIES];
      state.theme = data.theme || 'dark';
    }
  } catch (e) {
    console.error('State yüklenemedi', e);
  }
  applyTheme();
}

function applyTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  const icon = document.querySelector('#theme-toggle i');
  if (icon) {
    icon.className = state.theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
  }
}

function showToast(msg, duration = 2200) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), duration);
}

// ==================== GÖREV MANTIGI ====================
// Tekrarlayan görevlerde tamamlanma GÜNLÜKTÜR.
// Her gün yeniden listede çıkar, dünün tamamlanması bugünü etkilemez.

function isRecurring(task) {
  return task.recurrence && (task.recurrence.type === 'daily' || task.recurrence.type === 'custom');
}

function isTaskForToday(task) {
  const today = todayStr();
  const day = getDayOfWeek(today);

  if (!task.recurrence || task.recurrence.type === 'none') {
    // Tek seferlik: sadece dueDate bugünse VEYA tarih yoksa ve henüz tamamlanmamışsa
    if (task.dueDate) return task.dueDate === today;
    return !isOneTimeCompleted(task);
  }

  if (task.recurrence.type === 'daily') return true;

  if (task.recurrence.type === 'custom') {
    return (task.recurrence.days || []).includes(day);
  }

  return false;
}

function isOneTimeCompleted(task) {
  // Tek seferlik görevlerde kalıcı tamamlanma
  if (task.completed) return true;
  if (task.completionHistory && task.completionHistory.some(h => h.completed)) return true;
  return false;
}

function getTodayHistory(task) {
  const today = todayStr();
  if (!task.completionHistory) task.completionHistory = [];
  let entry = task.completionHistory.find(h => h.date === today);
  if (!entry) {
    entry = { date: today, completed: false, subtasks: {} };
    task.completionHistory.push(entry);
  }
  if (!entry.subtasks) entry.subtasks = {};
  return entry;
}

function isTaskCompletedToday(task) {
  if (isRecurring(task)) {
    const entry = getTodayHistory(task);
    if (task.subtasks && task.subtasks.length > 0) {
      // Tüm alt görevler bugün tamamlandı mı?
      return task.subtasks.every(s => entry.subtasks[s.id] === true);
    }
    return entry.completed === true;
  }
  // Tek seferlik
  return isOneTimeCompleted(task);
}

function getSubtaskProgress(task) {
  if (isRecurring(task)) {
    const entry = getTodayHistory(task);
    if (!task.subtasks || task.subtasks.length === 0) {
      const done = entry.completed ? 1 : 0;
      return { done, total: 1, percent: entry.completed ? 100 : 0 };
    }
    const done = task.subtasks.filter(s => entry.subtasks[s.id] === true).length;
    const total = task.subtasks.length;
    return { done, total, percent: total ? Math.round((done / total) * 100) : 0 };
  }

  // Tek seferlik
  if (!task.subtasks || task.subtasks.length === 0) {
    const done = task.completed ? 1 : 0;
    return { done, total: 1, percent: task.completed ? 100 : 0 };
  }
  const done = task.subtasks.filter(s => s.completed).length;
  const total = task.subtasks.length;
  return { done, total, percent: Math.round((done / total) * 100) };
}

function isSubtaskDoneToday(task, subId) {
  if (isRecurring(task)) {
    const entry = getTodayHistory(task);
    return entry.subtasks[subId] === true;
  }
  const sub = (task.subtasks || []).find(s => s.id === subId);
  return sub ? sub.completed : false;
}

function logCompletion(task, completed) {
  const entry = getTodayHistory(task);
  entry.completed = completed;

  // Tek seferlikte kalıcı bayrağı da güncelle
  if (!isRecurring(task)) {
    task.completed = completed;
    task.completedAt = completed ? new Date().toISOString() : null;
  }

  // Son 90 gün tut
  if (task.completionHistory.length > 90) {
    task.completionHistory = task.completionHistory.slice(-90);
  }
}

function toggleTaskComplete(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  const currentlyDone = isTaskCompletedToday(task);

  if (task.subtasks && task.subtasks.length > 0) {
    // Tüm alt görevleri bugün için tamamla / geri al
    if (isRecurring(task)) {
      const entry = getTodayHistory(task);
      task.subtasks.forEach(s => {
        entry.subtasks[s.id] = !currentlyDone;
      });
      entry.completed = !currentlyDone;
    } else {
      task.subtasks.forEach(s => s.completed = !currentlyDone);
      task.completed = !currentlyDone;
      task.completedAt = task.completed ? new Date().toISOString() : null;
      logCompletion(task, task.completed);
    }
  } else {
    if (isRecurring(task)) {
      logCompletion(task, !currentlyDone);
    } else {
      task.completed = !currentlyDone;
      task.completedAt = task.completed ? new Date().toISOString() : null;
      logCompletion(task, task.completed);
    }
  }

  saveState();
  renderAll();
  if (!currentlyDone) showToast('Görev tamamlandı! 🎉');
}

function toggleSubtask(taskId, subId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  if (isRecurring(task)) {
    const entry = getTodayHistory(task);
    entry.subtasks[subId] = !entry.subtasks[subId];
    // Ana tamamlanma: tüm alt görevler bugün bittiyse
    entry.completed = task.subtasks.every(s => entry.subtasks[s.id] === true);
  } else {
    const sub = task.subtasks.find(s => s.id === subId);
    if (!sub) return;
    sub.completed = !sub.completed;
    task.completed = task.subtasks.every(s => s.completed);
    task.completedAt = task.completed ? new Date().toISOString() : null;
    logCompletion(task, task.completed);
  }

  saveState();
  renderAll();
  if (isTaskCompletedToday(task)) showToast('Tüm alt görevler tamamlandı! 🎉');
}

// ==================== RENDER ====================
function renderAll() {
  renderToday();
  renderAllTasks();
  renderCategories();
  renderStats();
  updateHeader();
  populateCategorySelects();
}

function updateHeader() {
  const now = new Date();
  const days = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  document.getElementById('date-display').textContent =
    `${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}, ${days[now.getDay()]}`;

  const todayTasks = state.tasks.filter(isTaskForToday);
  const completed = todayTasks.filter(t => isTaskCompletedToday(t)).length;

  const total = todayTasks.length;
  const percent = total ? Math.round((completed / total) * 100) : 0;

  document.getElementById('today-progress').style.width = percent + '%';
  document.getElementById('progress-text').textContent = `${completed} / ${total} tamamlandı (${percent}%)`;
  document.getElementById('today-count').textContent = total;
}

function createTaskCard(task, showDate = false) {
  const cat = state.categories.find(c => c.id === task.categoryId);
  const progress = getSubtaskProgress(task);
  const isCompleted = isTaskCompletedToday(task);

  const card = document.createElement('div');
  card.className = `task-card priority-${task.priority || 'medium'} ${isCompleted ? 'completed' : ''}`;
  card.dataset.id = task.id;

  let metaHtml = '';
  if (cat) {
    metaHtml += `<span class="category-tag" style="color:${cat.color}">${cat.name}</span>`;
  }
  if (task.dueTime) {
    metaHtml += `<span><i class="far fa-clock"></i> ${task.dueTime}</span>`;
  }
  if (showDate && task.dueDate && !isRecurring(task)) {
    metaHtml += `<span><i class="far fa-calendar"></i> ${formatDateTR(task.dueDate)}</span>`;
  }
  if (task.recurrence && task.recurrence.type === 'daily') {
    metaHtml += `<span><i class="fas fa-redo"></i> Her gün</span>`;
  } else if (task.recurrence && task.recurrence.type === 'custom') {
    const dayNames = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
    const days = (task.recurrence.days || []).map(d => dayNames[d]).join(', ');
    metaHtml += `<span><i class="fas fa-redo"></i> ${days}</span>`;
  }

  let subtasksHtml = '';
  if (task.subtasks && task.subtasks.length > 0) {
    subtasksHtml = `<div class="subtasks">`;
    task.subtasks.forEach(sub => {
      const subDone = isSubtaskDoneToday(task, sub.id);
      const mark = subDone ? '✓' : '✗';
      const markClass = subDone ? 'done' : 'pending';
      subtasksHtml += `
        <div class="subtask-item ${subDone ? 'completed' : ''}">
          <span class="task-status-mark ${markClass}" style="font-size:1rem;width:22px;">${mark}</span>
          <button class="subtask-check ${subDone ? 'checked' : ''}" data-task="${task.id}" data-sub="${sub.id}">
            <i class="fas fa-check"></i>
          </button>
          <span>${escapeHtml(sub.title)}</span>
        </div>`;
    });
    subtasksHtml += `</div>
      <div class="task-progress">
        <div class="task-progress-bar">
          <div class="task-progress-fill" style="width:${progress.percent}%"></div>
        </div>
        <div class="task-progress-text">${progress.done}/${progress.total} alt görev (${progress.percent}%)</div>
      </div>`;
  }

  const statusMark = isCompleted
    ? '<span class="task-status-mark done">✓</span>'
    : '<span class="task-status-mark pending">✗</span>';

  card.innerHTML = `
    <div class="task-header">
      ${statusMark}
      <button class="task-check ${isCompleted ? 'checked' : ''}" data-id="${task.id}">
        <i class="fas fa-check"></i>
      </button>
      <div class="task-info">
        <div class="task-title">${escapeHtml(task.title)}</div>
        <div class="task-meta">${metaHtml}</div>
      </div>
    </div>
    ${subtasksHtml}
  `;

  // Events
  card.querySelector('.task-check').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleTaskComplete(task.id);
  });

  card.querySelectorAll('.subtask-check').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleSubtask(btn.dataset.task, btn.dataset.sub);
    });
  });

  card.addEventListener('click', (e) => {
    if (e.target.closest('.task-check') || e.target.closest('.subtask-check')) return;
    openTaskModal(task.id);
  });

  return card;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function renderToday() {
  const container = document.getElementById('today-tasks');
  const empty = document.getElementById('empty-today');
  container.innerHTML = '';

  const todayTasks = state.tasks
    .filter(isTaskForToday)
    .sort((a, b) => {
      // Önce tamamlanmayanlar, sonra öncelik, sonra saat
      const aDone = isTaskCompletedToday(a);
      const bDone = isTaskCompletedToday(b);
      if (aDone !== bDone) return aDone ? 1 : -1;
      const prio = { high: 0, medium: 1, low: 2 };
      if ((prio[a.priority] || 1) !== (prio[b.priority] || 1)) return (prio[a.priority] || 1) - (prio[b.priority] || 1);
      return (a.dueTime || '99:99').localeCompare(b.dueTime || '99:99');
    });

  if (todayTasks.length === 0) {
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    todayTasks.forEach(t => container.appendChild(createTaskCard(t)));
  }
}

function renderAllTasks() {
  const container = document.getElementById('all-tasks');
  const empty = document.getElementById('empty-all');
  const search = document.getElementById('search-input').value.toLowerCase();
  const catFilter = document.getElementById('category-filter').value;

  container.innerHTML = '';

  let tasks = [...state.tasks];

  if (search) {
    tasks = tasks.filter(t =>
      t.title.toLowerCase().includes(search) ||
      (t.subtasks || []).some(s => s.title.toLowerCase().includes(search))
    );
  }
  if (catFilter !== 'all') {
    tasks = tasks.filter(t => t.categoryId === catFilter);
  }

  tasks.sort((a, b) => {
    const aDone = isTaskCompletedToday(a);
    const bDone = isTaskCompletedToday(b);
    if (aDone !== bDone) return aDone ? 1 : -1;
    return (b.createdAt || '').localeCompare(a.createdAt || '');
  });

  if (tasks.length === 0) {
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    tasks.forEach(t => container.appendChild(createTaskCard(t, true)));
  }
}

function renderCategories() {
  const container = document.getElementById('categories-list');
  container.innerHTML = '';

  state.categories.forEach(cat => {
    const count = state.tasks.filter(t => t.categoryId === cat.id).length;
    const card = document.createElement('div');
    card.className = 'category-card';
    card.innerHTML = `
      <div class="color-dot" style="background:${cat.color}"></div>
      <h3>${escapeHtml(cat.name)}</h3>
      <div class="count">${count} görev</div>
    `;
    card.addEventListener('click', () => {
      document.querySelector('[data-view="all"]').click();
      document.getElementById('category-filter').value = cat.id;
      renderAllTasks();
    });
    container.appendChild(card);
  });
}

function wasTaskCompletedOnDate(task, dateStr) {
  const hist = (task.completionHistory || []).find(h => h.date === dateStr);
  if (!hist) return false;
  if (task.subtasks && task.subtasks.length > 0) {
    // Alt görevler varsa hepsinin o gün tamamlanmış olması lazım
    return task.subtasks.every(s => hist.subtasks && hist.subtasks[s.id] === true);
  }
  return hist.completed === true;
}

function doesTaskApplyOnDate(task, dateStr) {
  const day = getDayOfWeek(dateStr);
  if (!task.recurrence || task.recurrence.type === 'none') {
    return task.dueDate === dateStr;
  }
  if (task.recurrence.type === 'daily') return true;
  if (task.recurrence.type === 'custom') {
    return (task.recurrence.days || []).includes(day);
  }
  return false;
}

function renderStats() {
  const today = todayStr();
  const todayTasks = state.tasks.filter(isTaskForToday);
  const todayDone = todayTasks.filter(t => isTaskCompletedToday(t)).length;
  const todayRate = todayTasks.length ? Math.round((todayDone / todayTasks.length) * 100) : 0;
  document.getElementById('stat-today-rate').textContent = todayRate + '%';

  // Haftalık
  const weekRates = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.toISOString().slice(0, 10);

    let total = 0, done = 0;
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });
    weekRates.push({ date: ds, day: getDayOfWeek(ds), total, done, rate: total ? Math.round((done / total) * 100) : 0 });
  }

  const weekAvg = weekRates.length
    ? Math.round(weekRates.reduce((s, r) => s + r.rate, 0) / weekRates.length)
    : 0;
  document.getElementById('stat-week-rate').textContent = weekAvg + '%';

  // Aylık (son 30 gün)
  let monthTotal = 0, monthDone = 0;
  for (let i = 0; i < 30; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.toISOString().slice(0, 10);
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        monthTotal++;
        if (wasTaskCompletedOnDate(task, ds)) monthDone++;
      }
    });
  }
  const monthRate = monthTotal ? Math.round((monthDone / monthTotal) * 100) : 0;
  document.getElementById('stat-month-rate').textContent = monthRate + '%';

  // Streak (ardışık tam başarı günleri)
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.toISOString().slice(0, 10);

    let total = 0, done = 0;
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });
    if (total === 0) {
      // O gün görev yoksa streak bozulmaz, devam et
      continue;
    }
    if (done === total) {
      streak++;
    } else {
      break;
    }
  }
  document.getElementById('stat-streak').textContent = streak;

  // Haftalık chart
  const chart = document.getElementById('weekly-chart');
  chart.innerHTML = '';
  const dayNames = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
  weekRates.forEach(r => {
    const wrap = document.createElement('div');
    wrap.className = 'chart-bar-wrapper';
    const height = Math.max(r.rate, 4);
    wrap.innerHTML = `
      <div class="chart-bar" style="height:${height}%"></div>
      <div class="chart-label">${dayNames[r.day]}</div>
    `;
    chart.appendChild(wrap);
  });

  // History list
  const histList = document.getElementById('history-list');
  histList.innerHTML = '';
  weekRates.slice().reverse().forEach(r => {
    const item = document.createElement('div');
    item.className = 'history-item';
    item.innerHTML = `
      <div>
        <strong>${formatDateTR(r.date)}</strong>
        <div style="font-size:0.8rem;color:var(--text-muted)">${r.done}/${r.total} görev</div>
      </div>
      <div class="rate">${r.rate}%</div>
    `;
    histList.appendChild(item);
  });

  // Kategori istatistik (bugün için)
  const catStats = document.getElementById('category-stats');
  catStats.innerHTML = '';
  const catCounts = {};
  state.tasks.filter(isTaskForToday).forEach(t => {
    if (!catCounts[t.categoryId]) catCounts[t.categoryId] = { total: 0, done: 0 };
    catCounts[t.categoryId].total++;
    if (isTaskCompletedToday(t)) catCounts[t.categoryId].done++;
  });

  state.categories.forEach(cat => {
    const c = catCounts[cat.id] || { total: 0, done: 0 };
    if (c.total === 0) return;
    const percent = Math.round((c.done / c.total) * 100);
    const item = document.createElement('div');
    item.className = 'cat-stat-item';
    item.innerHTML = `
      <div class="dot" style="background:${cat.color}"></div>
      <div style="min-width:70px">${escapeHtml(cat.name)}</div>
      <div class="bar-bg"><div class="bar-fill" style="width:${percent}%;background:${cat.color}"></div></div>
      <div style="min-width:40px;text-align:right;font-size:0.85rem">${percent}%</div>
    `;
    catStats.appendChild(item);
  });
}

function populateCategorySelects() {
  const selects = [document.getElementById('task-category'), document.getElementById('category-filter')];
  selects.forEach((sel, idx) => {
    if (!sel) return;
    const current = sel.value;
    if (idx === 1) {
      sel.innerHTML = '<option value="all">Tüm Kategoriler</option>';
    } else {
      sel.innerHTML = '';
    }
    state.categories.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.name;
      sel.appendChild(opt);
    });
    if (current) sel.value = current;
  });
}

// ==================== MODAL & FORM ====================
function openTaskModal(taskId = null) {
  const modal = document.getElementById('task-modal');
  const form = document.getElementById('task-form');
  form.reset();
  document.getElementById('subtasks-container').innerHTML = '';
  document.getElementById('days-selector').classList.add('hidden');
  document.getElementById('delete-task-btn').classList.add('hidden');
  document.getElementById('copy-task-btn').classList.add('hidden');
  state.selectedPriority = 'medium';
  updatePriorityButtons();

  if (taskId) {
    const task = state.tasks.find(t => t.id === taskId);
    if (!task) return;
    document.getElementById('modal-title').textContent = 'Görevi Düzenle';
    document.getElementById('task-id').value = task.id;
    document.getElementById('task-title').value = task.title;
    document.getElementById('task-category').value = task.categoryId || '';
    document.getElementById('task-date').value = task.dueDate || '';
    document.getElementById('task-time').value = task.dueTime || '';
    document.getElementById('task-recurrence').value = task.recurrence.type;
    state.selectedPriority = task.priority || 'medium';
    updatePriorityButtons();

    // Tarih alanını tekrarlayan görevlerde gizle
    const dateGroup = document.getElementById('task-date').closest('.form-group');
    if (dateGroup) {
      dateGroup.style.display = (task.recurrence.type === 'daily' || task.recurrence.type === 'custom') ? 'none' : '';
    }

    if (task.recurrence.type === 'custom') {
      document.getElementById('days-selector').classList.remove('hidden');
      document.querySelectorAll('#days-selector input').forEach(cb => {
        cb.checked = (task.recurrence.days || []).includes(parseInt(cb.value));
      });
    } else {
      document.getElementById('days-selector').classList.add('hidden');
    }

    (task.subtasks || []).forEach(sub => addSubtaskInput(sub.title, sub.id));
    document.getElementById('delete-task-btn').classList.remove('hidden');
    document.getElementById('copy-task-btn').classList.remove('hidden');
  } else {
    document.getElementById('modal-title').textContent = 'Yeni Görev';
    document.getElementById('task-id').value = '';
    document.getElementById('task-date').value = todayStr();
    document.getElementById('days-selector').classList.add('hidden');
    const dateGroup = document.getElementById('task-date').closest('.form-group');
    if (dateGroup) dateGroup.style.display = '';
  }

  modal.classList.remove('hidden');
  document.getElementById('task-title').focus();
}

function closeTaskModal() {
  document.getElementById('task-modal').classList.add('hidden');
}

function addSubtaskInput(value = '', id = null) {
  const container = document.getElementById('subtasks-container');
  const row = document.createElement('div');
  row.className = 'subtask-input-row';
  row.innerHTML = `
    <input type="text" placeholder="Alt görev..." value="${escapeHtml(value)}" data-id="${id || ''}">
    <button type="button" class="remove-sub"><i class="fas fa-times"></i></button>
  `;
  row.querySelector('.remove-sub').addEventListener('click', () => row.remove());
  container.appendChild(row);
}

function updatePriorityButtons() {
  document.querySelectorAll('.priority-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.priority === state.selectedPriority);
  });
}

function handleTaskSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('task-id').value;
  const title = document.getElementById('task-title').value.trim();
  if (!title) return;

  const recurrenceType = document.getElementById('task-recurrence').value;
  let days = [];
  if (recurrenceType === 'custom') {
    document.querySelectorAll('#days-selector input:checked').forEach(cb => {
      days.push(parseInt(cb.value));
    });
    if (days.length === 0) {
      showToast('En az bir gün seçmelisin');
      return;
    }
  }

  const subtasks = [];
  document.querySelectorAll('#subtasks-container input').forEach(input => {
    const t = input.value.trim();
    if (t) {
      subtasks.push({
        id: input.dataset.id || generateId(),
        title: t,
        completed: false
      });
    }
  });

  // Mevcut alt görev tamamlanma durumlarını koru
  if (id) {
    const oldTask = state.tasks.find(t => t.id === id);
    if (oldTask && oldTask.subtasks) {
      subtasks.forEach(s => {
        const old = oldTask.subtasks.find(os => os.id === s.id);
        if (old) s.completed = old.completed;
      });
    }
  }

  // Tekrarlayan görevlerde tarih gerekmez
  const dueDate = (recurrenceType === 'daily' || recurrenceType === 'custom')
    ? null
    : (document.getElementById('task-date').value || null);

  const oldTask = id ? state.tasks.find(t => t.id === id) : null;

  const taskData = {
    id: id || generateId(),
    title,
    categoryId: document.getElementById('task-category').value || state.categories[0]?.id,
    dueDate,
    dueTime: document.getElementById('task-time').value || null,
    priority: state.selectedPriority,
    recurrence: { type: recurrenceType, days },
    subtasks,
    completed: oldTask ? oldTask.completed : false,
    completedAt: oldTask ? oldTask.completedAt : null,
    createdAt: oldTask ? oldTask.createdAt : new Date().toISOString(),
    completionHistory: oldTask ? (oldTask.completionHistory || []) : []
  };

  if (id) {
    const idx = state.tasks.findIndex(t => t.id === id);
    state.tasks[idx] = taskData;
    showToast('Görev güncellendi');
  } else {
    state.tasks.unshift(taskData);
    showToast('Görev eklendi ✨');
  }

  saveState();
  closeTaskModal();
  renderAll();
}

function deleteTask() {
  const id = document.getElementById('task-id').value;
  if (!id || !confirm('Bu görevi silmek istediğine emin misin?')) return;
  state.tasks = state.tasks.filter(t => t.id !== id);
  saveState();
  closeTaskModal();
  renderAll();
  showToast('Görev silindi');
}

function copyTask() {
  // Mevcut formu "yeni görev" moduna çevir — id temizlenir, geçmiş sıfırlanır
  document.getElementById('task-id').value = '';
  document.getElementById('modal-title').textContent = 'Görevi Kopyala (Yeni)';
  document.getElementById('delete-task-btn').classList.add('hidden');
  document.getElementById('copy-task-btn').classList.add('hidden');

  // Başlığa "(kopya)" ekle ki ayırt edilebilsin
  const titleInput = document.getElementById('task-title');
  if (titleInput.value && !titleInput.value.includes('(kopya)')) {
    titleInput.value = titleInput.value + ' (kopya)';
  }

  // Alt görev id'lerini temizle (yeni id üretilsin)
  document.querySelectorAll('#subtasks-container input').forEach(input => {
    input.dataset.id = '';
  });

  showToast('Görev kopyalandı — istediğini değiştirip Kaydet\'e bas');
  titleInput.focus();
  titleInput.select();
}

// ==================== EXCEL RAPOR ====================
function generateExcelReport(period) {
  if (typeof XLSX === 'undefined') {
    showToast('Excel kütüphanesi yüklenemedi');
    return;
  }

  const today = new Date();
  let startDate, endDate, title, periodLabel;

  if (period === 'week') {
    const day = today.getDay();
    const diff = day === 0 ? 6 : day - 1;
    startDate = new Date(today);
    startDate.setDate(today.getDate() - diff);
    endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 6);
    title = 'Haftalık Rapor';
    periodLabel = 'haftalik';
  } else if (period === 'month') {
    startDate = new Date(today.getFullYear(), today.getMonth(), 1);
    endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    title = 'Aylık Rapor';
    periodLabel = 'aylik';
  } else {
    startDate = new Date(today.getFullYear(), 0, 1);
    endDate = new Date(today.getFullYear(), 11, 31);
    title = 'Yıllık Rapor';
    periodLabel = 'yillik';
  }

  const startStr = startDate.toISOString().slice(0, 10);
  const endStr = endDate.toISOString().slice(0, 10);
  const dayNamesFull = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const dayNamesShort = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];

  // ===== Sayfa 1: Günlük Detay =====
  const dailyRows = [];
  dailyRows.push(['Görev Takip - ' + title]);
  dailyRows.push(['Dönem', formatDateTR(startStr) + '  →  ' + formatDateTR(endStr)]);
  dailyRows.push(['Oluşturulma', new Date().toLocaleString('tr-TR')]);
  dailyRows.push([]);
  dailyRows.push(['Tarih', 'Gün', 'Görev', 'Kategori', 'Durum', 'Alt Görevler', 'Tekrar']);

  let current = new Date(startDate);
  while (current <= endDate) {
    const ds = current.toISOString().slice(0, 10);
    const day = current.getDay();

    state.tasks.forEach(task => {
      if (!doesTaskApplyOnDate(task, ds)) return;

      const cat = state.categories.find(c => c.id === task.categoryId);
      const done = wasTaskCompletedOnDate(task, ds);
      const status = done ? '✓ Yapıldı' : '✗ Yapılmadı';

      let subText = '-';
      if (task.subtasks && task.subtasks.length > 0) {
        const hist = (task.completionHistory || []).find(h => h.date === ds);
        subText = task.subtasks.map(s => {
          const sDone = hist && hist.subtasks && hist.subtasks[s.id];
          return (sDone ? '✓ ' : '✗ ') + s.title;
        }).join(' | ');
      }

      let tekrar = 'Tek seferlik';
      if (task.recurrence.type === 'daily') tekrar = 'Her gün';
      else if (task.recurrence.type === 'custom') {
        tekrar = (task.recurrence.days || []).map(d => dayNamesShort[d]).join(', ');
      }

      dailyRows.push([
        ds,
        dayNamesFull[day],
        task.title,
        cat ? cat.name : '-',
        status,
        subText,
        tekrar
      ]);
    });

    current.setDate(current.getDate() + 1);
  }

  // ===== Sayfa 2: Günlük Özet =====
  const summaryRows = [];
  summaryRows.push(['Günlük Özet - ' + title]);
  summaryRows.push([]);
  summaryRows.push(['Tarih', 'Gün', 'Toplam Görev', 'Tamamlanan', 'Eksik', 'Oran %']);

  current = new Date(startDate);
  let grandTotal = 0, grandDone = 0;
  while (current <= endDate) {
    const ds = current.toISOString().slice(0, 10);
    const day = current.getDay();
    let total = 0, done = 0;

    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });

    const rate = total ? Math.round((done / total) * 100) : 0;
    summaryRows.push([ds, dayNamesFull[day], total, done, total - done, rate]);
    grandTotal += total;
    grandDone += done;
    current.setDate(current.getDate() + 1);
  }

  summaryRows.push([]);
  summaryRows.push(['TOPLAM', '', grandTotal, grandDone, grandTotal - grandDone,
    grandTotal ? Math.round((grandDone / grandTotal) * 100) : 0]);

  // ===== Sayfa 3: Görev Bazlı Özet =====
  const taskRows = [];
  taskRows.push(['Görev Bazlı Başarı - ' + title]);
  taskRows.push([]);
  taskRows.push(['Görev', 'Kategori', 'Tekrar', 'Uygulandığı Gün', 'Yapıldığı Gün', 'Başarı %']);

  state.tasks.forEach(task => {
    const cat = state.categories.find(c => c.id === task.categoryId);
    let tekrar = 'Tek seferlik';
    if (task.recurrence.type === 'daily') tekrar = 'Her gün';
    else if (task.recurrence.type === 'custom') {
      tekrar = (task.recurrence.days || []).map(d => dayNamesShort[d]).join(', ');
    }

    let applied = 0, completed = 0;
    let d = new Date(startDate);
    while (d <= endDate) {
      const ds = d.toISOString().slice(0, 10);
      if (doesTaskApplyOnDate(task, ds)) {
        applied++;
        if (wasTaskCompletedOnDate(task, ds)) completed++;
      }
      d.setDate(d.getDate() + 1);
    }

    if (applied > 0) {
      taskRows.push([
        task.title,
        cat ? cat.name : '-',
        tekrar,
        applied,
        completed,
        Math.round((completed / applied) * 100) + '%'
      ]);
    }
  });

  // Workbook
  const wb = XLSX.utils.book_new();

  const ws1 = XLSX.utils.aoa_to_sheet(dailyRows);
  ws1['!cols'] = [{ wch: 12 }, { wch: 12 }, { wch: 28 }, { wch: 12 }, { wch: 12 }, { wch: 40 }, { wch: 14 }];
  XLSX.utils.book_append_sheet(wb, ws1, 'Günlük Detay');

  const ws2 = XLSX.utils.aoa_to_sheet(summaryRows);
  ws2['!cols'] = [{ wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 12 }, { wch: 10 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, ws2, 'Günlük Özet');

  const ws3 = XLSX.utils.aoa_to_sheet(taskRows);
  ws3['!cols'] = [{ wch: 28 }, { wch: 12 }, { wch: 16 }, { wch: 14 }, { wch: 14 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, ws3, 'Görev Bazlı');

  const fileName = `Gorev_Raporu_${periodLabel}_${todayStr()}.xlsx`;
  XLSX.writeFile(wb, fileName);
  showToast('Excel raporu indirildi! 📊');
}

// ==================== KATEGORİ ====================
function openCategoryModal() {
  document.getElementById('category-form').reset();
  state.selectedColor = '#3b82f6';
  document.querySelectorAll('.color-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.color === state.selectedColor);
  });
  document.getElementById('category-modal').classList.remove('hidden');
}

function closeCategoryModal() {
  document.getElementById('category-modal').classList.add('hidden');
}

function handleCategorySubmit(e) {
  e.preventDefault();
  const name = document.getElementById('category-name').value.trim();
  if (!name) return;
  state.categories.push({
    id: generateId(),
    name,
    color: state.selectedColor
  });
  saveState();
  closeCategoryModal();
  renderAll();
  showToast('Kategori eklendi');
}

// ==================== NAVİGASYON ====================
function switchView(viewName) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const view = document.getElementById(viewName + '-view');
  if (view) view.classList.add('active');

  const nav = document.querySelector(`.nav-item[data-view="${viewName}"]`);
  if (nav) nav.classList.add('active');

  const titles = {
    today: 'Bugün',
    all: 'Tüm Görevler',
    categories: 'Kategoriler',
    stats: 'İstatistikler'
  };
  document.getElementById('page-title').textContent = titles[viewName] || 'Görev Takip';

  // Progress sadece bugün görünümünde
  document.querySelector('.progress-summary').style.display = viewName === 'today' ? 'block' : 'none';
}

// ==================== INIT ====================
function init() {
  loadState();
  renderAll();

  // Navigation
  document.querySelectorAll('.nav-item[data-view]').forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });

  // FAB
  document.getElementById('add-task-btn').addEventListener('click', () => openTaskModal());

  // Theme
  document.getElementById('theme-toggle').addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    saveState();
  });

  // Stats shortcut
  document.getElementById('stats-btn').addEventListener('click', () => switchView('stats'));

  // Modal
  document.getElementById('close-modal').addEventListener('click', closeTaskModal);
  document.getElementById('task-modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('task-modal')) closeTaskModal();
  });
  document.getElementById('task-form').addEventListener('submit', handleTaskSubmit);
  document.getElementById('delete-task-btn').addEventListener('click', deleteTask);
  document.getElementById('copy-task-btn').addEventListener('click', copyTask);
  document.getElementById('add-subtask-btn').addEventListener('click', () => addSubtaskInput());

  // Recurrence
  document.getElementById('task-recurrence').addEventListener('change', (e) => {
    const val = e.target.value;
    document.getElementById('days-selector').classList.toggle('hidden', val !== 'custom');
    // Her gün veya belirli günler seçilince tarih alanını gizle
    const dateGroup = document.getElementById('task-date').closest('.form-group');
    if (dateGroup) {
      dateGroup.style.display = (val === 'daily' || val === 'custom') ? 'none' : '';
    }
    if (val === 'daily' || val === 'custom') {
      document.getElementById('task-date').value = '';
    }
  });

  // Priority
  document.querySelectorAll('.priority-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedPriority = btn.dataset.priority;
      updatePriorityButtons();
    });
  });

  // Category modal
  document.getElementById('add-category-btn').addEventListener('click', openCategoryModal);
  document.getElementById('close-category-modal').addEventListener('click', closeCategoryModal);
  document.getElementById('category-modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('category-modal')) closeCategoryModal();
  });
  document.getElementById('category-form').addEventListener('submit', handleCategorySubmit);

  document.querySelectorAll('.color-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedColor = btn.dataset.color;
      document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Search & filter
  document.getElementById('search-input').addEventListener('input', renderAllTasks);
  document.getElementById('category-filter').addEventListener('change', renderAllTasks);

  // Excel Rapor butonları
  document.querySelectorAll('.btn-report').forEach(btn => {
    btn.addEventListener('click', () => {
      generateExcelReport(btn.dataset.period);
    });
  });

  // Service Worker for PWA
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
}

document.addEventListener('DOMContentLoaded', init);
