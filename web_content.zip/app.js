const s=document.getElementById("screen");
function home(){s.innerHTML=`<section class="page"><div class="logo"><h1>ECO GALAXY</h1><p>Powered by Android</p></div><div class="clock" id="clock"></div><div class="grid">
${item("📞","Phone","phone()")}${item("💬","Messages","messages()")}${item("⚙️","Settings","settings()")}${item("🧮","Calculator","calculator()")}
${item("📁","Files","files()")}${item("📷","Camera","camera()")}${item("🌐","Browser","browser()")}${item("ℹ️","About","about()")}</div><div class="dock">${item("☎","Call","phone()")}${item("▦","Apps","apps()")}${item("⚙","Settings","settings()")}</div></section>`;tick()}
function item(i,t,fn){return `<button class="icon" onclick="${fn}"><div class="bubble">${i}</div>${t}</button>`}
function tick(){const e=document.getElementById("clock"); if(e)e.textContent=new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}
function apps(){s.innerHTML=`<section class="page"><button class="back" onclick="home()">‹</button><h1>All Apps</h1><div class="grid">${item("📞","Phone","phone()")}${item("💬","Messages","messages()")}${item("⚙️","Settings","settings()")}${item("🧮","Calculator","calculator()")}${item("📁","Files","files()")}${item("📷","Camera","camera()")}${item("🌐","Browser","browser()")}${item("ℹ️","About","about()")}</div></section>`}
function settings(){s.innerHTML=`<section class="page"><button class="back" onclick="home()">‹</button><h1>Settings</h1><div class="card"><div class="row">📶 Wi‑Fi <span class="green">Connected</span></div><div class="row">🟦 Bluetooth <span>On</span></div><div class="row">🔔 Notifications <span>›</span></div><div class="row">🎨 Display <span>›</span></div><div class="row">🔒 Security <span>›</span></div><div class="row">🔋 Battery <span>87%</span></div><div class="row" onclick="about()">📱 About Eco Galaxy <span>›</span></div></div></section>`}
function about(){s.innerHTML=`<section class="page"><button class="back" onclick="settings()">‹</button><div class="logo"><h1>ECO GALAXY</h1><p>Powered by Android</p></div><div class="card"><div class="row">OS Version <b>Eco Galaxy OS 1.0</b></div><div class="row">Prototype <b>v1.0</b></div><div class="row">Base <b>Android</b></div><div class="row">Company <b>Eco Galaxy</b></div></div></section>`}
function phone(){simple("📞","Phone","Dialer Prototype")}
function messages(){simple("💬","Messages","No conversations yet")}
function calculator(){simple("🧮","Calculator","Calculator interface — Prototype")}
function files(){simple("📁","Files","Internal Storage • 0 files")}
function camera(){simple("📷","Camera","Camera Preview • Prototype")}
function browser(){simple("🌐","Browser","Eco Browser • Prototype")}
function simple(i,t,d){s.innerHTML=`<section class="page"><button class="back" onclick="home()">‹</button><h1>${i} ${t}</h1><div class="card big">${d}</div><button class="pill" onclick="home()">Back to Home</button></section>`}
function back(){home()} home(); setInterval(tick,1000);