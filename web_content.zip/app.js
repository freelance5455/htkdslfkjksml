// V7: classic-script Firebase compatibility layer; avoids ES-module loading failures on Netlify/mobile Chrome.
const firebaseConfig = {
  apiKey: "AIzaSyBKTnrYb67r-FkWHtzLxVIujEgMo2iz06A",
  authDomain: "al-insaf-460a5.firebaseapp.com",
  projectId: "al-insaf-460a5",
  storageBucket: "al-insaf-460a5.firebasestorage.app",
  messagingSenderId: "417118259448",
  appId: "1:417118259448:web:cfa3a6f12bdfb3ef20930d",
  measurementId: "G-Y29K18NTY6"
};
function initializeApp(config,name){return name ? firebase.initializeApp(config,name) : (firebase.apps.length ? firebase.app() : firebase.initializeApp(config));}
function getAuth(app){return firebase.auth(app);}
function signInWithEmailAndPassword(auth,email,password){return auth.signInWithEmailAndPassword(email,password);}
function onAuthStateChanged(auth,cb){return auth.onAuthStateChanged(cb);}
function signOut(auth){return auth.signOut();}
function createUserWithEmailAndPassword(auth,email,password){return auth.createUserWithEmailAndPassword(email,password);}
function getFirestore(app){return firebase.firestore(app);}
function collection(db,name){return db.collection(name);}
function addDoc(col,data){return col.add(data);}
function getDocs(col){return col.get();}
function updateDoc(ref,data){return ref.update(data);}
function deleteDoc(ref){return ref.delete();}
function doc(db,col,id){return db.collection(col).doc(id);}
function setDoc(ref,data,opts){return opts ? ref.set(data,opts) : ref.set(data);}
function getDoc(ref){return ref.get();}
function serverTimestamp(){return firebase.firestore.FieldValue.serverTimestamp();}

const fb=initializeApp(firebaseConfig),auth=getAuth(fb),db=getFirestore(fb);
const $=s=>document.querySelector(s);const esc=x=>String(x==null?"":x).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const money=x=>"৳"+Number(x||0).toLocaleString("bn-BD");
const months=["জানুয়ারি","ফেব্রুয়ারি","মার্চ","এপ্রিল","মে","জুন","জুলাই","আগস্ট","সেপ্টেম্বর","অক্টোবর","নভেম্বর","ডিসেম্বর"];
let data={members:[],dues:[],beneficiaries:[],finance:[],assistance:[],activities:[]},view="dashboard",editing=null,currentRole="admin",appSettings={};

const startup=document.querySelector("#startupMsg");
const loginButton=document.querySelector("#loginBtn");
if(loginButton){loginButton.dataset.ready="1";}
if(startup){startup.textContent="";}

$("#loginBtn").onclick=async()=>{
  const email=$("#email").value.trim(), password=$("#password").value;
  $("#loginMsg").className="login-msg";
  if(!email||!password){$("#loginMsg").textContent="ইমেইল ও পাসওয়ার্ড দুটিই দিন।";return}
  const btn=$("#loginBtn"); btn.dataset.ready="1"; btn.disabled=true; btn.textContent="⏳ লগইন হচ্ছে...";
  try{
    await signInWithEmailAndPassword(auth,email,password);
    $("#loginMsg").textContent="";
  }catch(e){
    console.error("Firebase Login Error:",e);
    const code=e&&e.code||"unknown";
    const tips={
      "auth/invalid-credential":"ইমেইল বা পাসওয়ার্ড সঠিক নয়। Firebase Authentication-এর Password ব্যবহার করুন।",
      "auth/invalid-login-credentials":"ইমেইল বা পাসওয়ার্ড সঠিক নয়।",
      "auth/user-not-found":"এই ইমেইল Firebase Authentication-এ পাওয়া যায়নি।",
      "auth/wrong-password":"পাসওয়ার্ড ভুল। Firebase Authentication-এ নতুন Password সেট করুন।",
      "auth/invalid-email":"ইমেইল ঠিকানা সঠিক নয়।",
      "auth/user-disabled":"এই Firebase User নিষ্ক্রিয় করা হয়েছে।",
      "auth/too-many-requests":"অনেকবার চেষ্টা হয়েছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।",
      "auth/network-request-failed":"ইন্টারনেট সংযোগ বা Firebase সংযোগে সমস্যা হয়েছে।",
      "auth/operation-not-allowed":"Firebase → Authentication → Sign-in method → Email/Password চালু করুন।",
      "auth/unauthorized-domain":"এই Netlify ডোমেইন Firebase Authentication-এর Authorized domains-এ যোগ করতে হবে।",
      "auth/api-key-not-valid":"Firebase API Key/Config সঠিক নয়।",
      "auth/app-not-authorized":"এই ওয়েব অ্যাপটি Firebase Project-এর সাথে অনুমোদিত নয়।"
    };
    $("#loginMsg").innerHTML=`${esc(tips[code]||"Firebase Login Error: "+(e&&e.message||"অজানা সমস্যা"))}<br><small>কোড: ${esc(code)}</small>`;
  }finally{
    btn.disabled=false; btn.textContent="🔐 লগইন";
  }
};
$("#logout").onclick=()=>signOut(auth);$("#menu").onclick=()=>{$("#side").classList.add("open");$("#shade").classList.remove("hidden")};$("#shade").onclick=closeSide;$("#close").onclick=closeModal;
document.addEventListener("click",e=>{let v=e.target.closest("[data-view]");if(v){view=v.dataset.view;render();closeSide()}let a=e.target.closest("[data-action]");if(a)action(a.dataset.action,a.dataset.id)});

onAuthStateChanged(auth,async u=>{
  if(u){
    $("#loginScreen").classList.add("hidden");
    $("#app").classList.remove("hidden");
    try{
      await loadRole(u);
      await load();
      applyTheme(appSettings.theme||"green");
      render();
    }catch(e){
      console.error("App startup error:",e);
      $("#main").innerHTML=`<div class="page"><div class="card neo"><h2>অ্যাপ চালু হতে সমস্যা হয়েছে</h2><p>${esc(e&&e.message||"অজানা সমস্যা")}</p><p><small>Firebase সংযোগ ও Firestore Rules পরীক্ষা করুন।</small></p></div></div>`;
    }
  }else{
    $("#app").classList.add("hidden");
    $("#loginScreen").classList.remove("hidden");
  }
});

async function loadRole(u){
  try{
    const a=await getDoc(doc(db,"admins",u.uid));
    if(a.exists()){currentRole="admin";return}
    let r=await getDoc(doc(db,"roles",u.uid));
    if(!r.exists()) r=await getDoc(doc(db,"moderators",u.uid));
    currentRole=r.exists()?(r.data().role||"moderator"):"viewer";
  }catch(e){currentRole="viewer";console.error("Role load error",e)}
}
function isAdmin(){return currentRole==="admin"}
function applyTheme(name){
  const themes={green:{primary:"#286b4b",dark:"#1e543a",accent:"#4d8d6a"},blue:{primary:"#2563eb",dark:"#1d4ed8",accent:"#4f83f1"},purple:{primary:"#7c3aed",dark:"#6d28d9",accent:"#9b6cf3"},orange:{primary:"#ea7b18",dark:"#c65f08",accent:"#f29a4b"},teal:{primary:"#0f766e",dark:"#115e59",accent:"#2ca39a"},red:{primary:"#c24141",dark:"#a33131",accent:"#dc6666"},slate:{primary:"#475569",dark:"#334155",accent:"#64748b"}};
  const t=themes[name]||themes.green; document.documentElement.style.setProperty("--primary",t.primary);document.documentElement.style.setProperty("--primary-dark",t.dark);document.documentElement.style.setProperty("--accent",t.accent);document.querySelector('meta[name="theme-color"]')?.setAttribute("content",t.primary); document.body.dataset.theme=name||"green";
}
function themeOptions(sel){return Object.entries({green:"🟢 সবুজ",blue:"🔵 নীল",purple:"🟣 বেগুনি",orange:"🟠 কমলা",teal:"🔷 টিল",red:"🔴 লাল",slate:"⚫ স্লেট"}).map(([k,v])=>`<option value="${k}" ${k===sel?"selected":""}>${v}</option>`).join("")}
function roleLabel(){return currentRole==="admin"?"প্রধান অ্যাডমিন":"মডারেটর"}
function totalDuesIncome(){return data.dues.reduce((s,x)=>s+Number(x.amount||0),0)}
function totalIncome(){return sum("income")+totalDuesIncome()}
function totalExpense(){return sum("expense")}
function currentBalance(){return totalIncome()-totalExpense()}

async function load(){
  for(let n of Object.keys(data)){
    try{
      let s=await getDocs(collection(db,n));
      data[n]=s.docs.map(d=>({id:d.id,...d.data()}));
    }catch(e){
      console.error("Firestore load error:",n,e);
      if(e&&e.code==="permission-denied"){
        toast("Firestore অনুমতি নেই। admins UID ও Rules পরীক্ষা করুন।");
      }else{
        toast("Firestore সংযোগে সমস্যা: "+(e&&e.code||"unknown"));
      }
      data[n]=[];
    }
  }
  try{const s=await getDoc(doc(db,"settings","main"));if(s.exists())appSettings={...s.data()};}catch(e){console.warn("Settings load",e)}
}
function closeSide(){$("#side").classList.remove("open");$("#shade").classList.add("hidden")}
function closeModal(){$("#modal").classList.add("hidden");editing=null}
function toast(t){$("#toast").textContent=t;$("#toast").classList.add("show");setTimeout(()=>$("#toast").classList.remove("show"),2200)}
function date(x){if(!x)return"-";return new Date(x).toLocaleDateString("bn-BD")}
function years(){let y=new Date().getFullYear();return Array.from({length:7},(_,i)=>`<option>${y-i}</option>`).join("")}
function monthOptions(sel=""){return months.map((m,i)=>`<option value="${i+1}" ${String(sel)==String(i+1)?"selected":""}>${m}</option>`).join("")}
function head(t,p,button=""){return `<div class="head"><div><h2>${t}</h2><p>${p}</p></div>${button}</div>`}
function page(t,p,b){return `<div class="page">${head(t,p)}${b}</div>`}
function stat(i,l,v,c=""){return `<div class="card neo stat"><div>${i}</div><small>${l}</small><strong class="${c}">${v}</strong></div>`}
function memberOpts(sel=""){return data.members.map(m=>`<option value="${m.id}" ${m.id===sel?"selected":""}>${esc(m.name)}</option>`).join("")}
function benOpts(sel=""){return data.beneficiaries.map(m=>`<option value="${m.id}" ${m.id===sel?"selected":""}>${esc(m.name)}</option>`).join("")}

function render(){document.querySelectorAll("#nav button").forEach(b=>b.classList.toggle("active",b.dataset.view===view));let f={dashboard, members, dues, beneficiaries, finance, assistance, activities, reports, settings};$("#main").innerHTML=f[view]()}
function dashboard(){
 let inc=totalIncome(),out=totalExpense(),dues=totalDuesIncome(),bal=inc-out;
 let now=new Date(),m=now.getMonth()+1,y=now.getFullYear(),md=data.dues.filter(x=>Number(x.month)==m&&Number(x.year)==y),paid=md.reduce((s,x)=>s+Number(x.amount||0),0),exp=md.reduce((s,x)=>s+Number(x.expected||0),0);
 return page("ড্যাশবোর্ড","সংগঠনের স্বয়ংক্রিয় হিসাব",`<div class="grid dashboard-stats">
 ${stat("👥","মোট সদস্য",data.members.length,"blue")}${stat("🤝","সেবাগ্রহীতা",data.beneficiaries.length,"purple")}${stat("💳","মোট চাঁদা",money(dues),"orange")}${stat("📥","মোট আয়",money(inc),"green")}${stat("📤","মোট ব্যয়",money(out),"red")}${stat("💵","বর্তমান ব্যালেন্স",money(bal),"teal")}
 </div><div class="section"><div class="section-title">দ্রুত কাজ</div><div class="quick"><div class="card neo quick-blue" data-view="members">👥<br><b>সদস্য যোগ</b></div><div class="card neo quick-orange" data-view="dues">💳<br><b>চাঁদা জমা</b></div><div class="card neo quick-green" data-view="finance">💰<br><b>আয়/ব্যয়</b></div><div class="card neo quick-purple" data-view="beneficiaries">🤝<br><b>সেবাগ্রহীতা</b></div><div class="card neo quick-teal" data-view="reports">📊<br><b>রিপোর্ট</b></div><div class="card neo quick-slate" data-view="settings">⚙️<br><b>সেটিংস</b></div></div></div>
 <div class="section card neo"><div class="section-title">চলতি মাসের চাঁদা</div><div class="summary"><span>নির্ধারিত</span><b>${money(exp)}</b></div><div class="summary"><span>জমা</span><b class="green">${money(paid)}</b></div><div class="summary"><span>বকেয়া</span><b class="red">${money(Math.max(0,exp-paid))}</b></div></div>`);
}
function sum(t){return data.finance.filter(x=>x.type===t).reduce((s,x)=>s+Number(x.amount||0),0)}
function members(){
 return page("সদস্য","সদস্যের ব্যক্তিগত তথ্য",`<div class="toolbar"><input id="msearch" placeholder="নাম/মোবাইল দিয়ে খুঁজুন"><button class="primary" data-action="new-member">＋ নতুন সদস্য</button></div><div class="card neo tablebox" id="memberTable">${memberTable(data.members)}</div>`);
}
function memberTable(a){if(!a.length)return`<div class="empty">কোনো সদস্য নেই।</div>`;return`<table class="table"><tr><th>নাম</th><th>মোবাইল</th><th>যোগদান</th><th>অবস্থা</th><th>কাজ</th></tr>${a.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone||"-")}</td><td>${date(x.joinDate)}</td><td><span class="badge ${x.status==="active"?"paid":"due"}">${x.status==="active"?"সক্রিয়":"নিষ্ক্রিয়"}</span></td><td class="actions"><button class="mini" data-action="history" data-id="${x.id}">📊</button><button class="mini" data-action="edit-member" data-id="${x.id}">✏️</button><button class="mini" data-action="delete-members" data-id="${x.id}">🗑️</button></td></tr>`).join("")}</table>`}

function dues(){
 let inc=data.dues.reduce((s,x)=>s+Number(x.amount||0),0),exp=data.dues.reduce((s,x)=>s+Number(x.expected||0),0);
 return page("মাসিক চাঁদা","মাস ও বছর অনুযায়ী চাঁদা উত্তোলন ও বকেয়া",`<div class="card neo filter-card"><select id="dmonth">${monthOptions(new Date().getMonth()+1)}</select><select id="dyear">${years()}</select><button class="secondary" data-action="filter-dues">🔎 দেখুন</button><button class="primary" data-action="new-due">＋ চাঁদা জমা</button></div>
 <div class="grid section">${stat("💳","মোট রেকর্ড",data.dues.length)}${stat("📌","নির্ধারিত",money(exp))}${stat("✅","মোট জমা",money(inc),"green")}${stat("⚠️","মোট বকেয়া",money(Math.max(0,exp-inc)),"red")}</div>
 <div class="section card neo tablebox" id="dueTable">${dueTable(data.dues)}</div>`);
}
function dueTable(a){if(!a.length)return`<div class="empty">এই মাস/বছরের কোনো চাঁদার রেকর্ড নেই।</div>`;return`<table class="table"><tr><th>সদস্য</th><th>মাস</th><th>নির্ধারিত</th><th>জমা</th><th>বকেয়া</th><th>অবস্থা</th><th>কাজ</th></tr>${a.map(x=>{let b=Math.max(0,Number(x.expected||0)-Number(x.amount||0)),c=b===0?"paid":Number(x.amount)>0?"partial":"due";return`<tr><td>${esc(x.memberName)}</td><td>${esc(x.monthName)} ${x.year}</td><td>${money(x.expected)}</td><td>${money(x.amount)}</td><td>${money(b)}</td><td><span class="badge ${c}">${c==="paid"?"পরিশোধ":c==="partial"?"আংশিক":"বাকি"}</span></td><td><button class="mini" data-action="edit-due" data-id="${x.id}">✏️</button><button class="mini" data-action="delete-dues" data-id="${x.id}">🗑️</button></td></tr>`}).join("")}</table>`}

function beneficiaries(){return page("সেবাগ্রহীতা","যাদের সহায়তা প্রয়োজন তাদের ব্যক্তিগত হিসাব",`<div class="toolbar"><input id="bsearch" placeholder="নাম/NID/মোবাইল দিয়ে খুঁজুন"><button class="secondary" data-action="pdf-beneficiaries">📄 সকল সেবাগ্রহীতার PDF</button><button class="primary" data-action="new-beneficiary">＋ নতুন</button></div><div class="card neo tablebox" id="benTable">${benTable(data.beneficiaries)}</div>`)}
function benTable(a){if(!a.length)return`<div class="empty">কোনো সেবাগ্রহীতা নেই।</div>`;return`<table class="table"><tr><th>নাম</th><th>NID</th><th>মোবাইল</th><th>ঠিকানা</th><th>প্রয়োজন</th><th>কাজ</th></tr>${a.map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.nid||"-")}</td><td>${esc(x.phone||"-")}</td><td>${esc(x.address||"-")}</td><td>${esc(x.need||"-")}</td><td><button class="mini" data-action="edit-beneficiary" data-id="${x.id}">✏️</button><button class="mini" data-action="delete-beneficiaries" data-id="${x.id}">🗑️</button></td></tr>`).join("")}</table>`}
function finance(){let i=totalIncome(),o=totalExpense(),d=totalDuesIncome();return page("আয়-ব্যয়","চাঁদা ও অন্যান্য আয় স্বয়ংক্রিয়ভাবে ব্যালেন্সে যোগ হবে; ব্যয় যোগ করলে ব্যালেন্স থেকে কমবে",`<div class="grid dashboard-stats">${stat("💳","চাঁদা থেকে আয়",money(d),"orange")}${stat("📥","অন্যান্য আয়",money(sum("income")),"green")}${stat("📤","মোট ব্যয়",money(o),"red")}${stat("💵","বর্তমান ব্যালেন্স",money(i-o),"teal")}</div><div class="toolbar section"><button class="primary" data-action="new-finance">＋ আয়/ব্যয় যোগ</button></div><div class="card neo tablebox">${financeTable(data.finance)}</div>`)}
function financeTable(a){if(!a.length)return`<div class="empty">কোনো আয়-ব্যয়ের রেকর্ড নেই।</div>`;return`<table class="table"><tr><th>তারিখ</th><th>ধরন</th><th>খাত</th><th>পরিমাণ</th><th>বিবরণ</th><th>কাজ</th></tr>${a.map(x=>`<tr><td>${date(x.date)}</td><td><span class="badge ${x.type==="income"?"paid":"due"}">${x.type==="income"?"আয়":"ব্যয়"}</span></td><td>${esc(x.category)}</td><td>${money(x.amount)}</td><td>${esc(x.note||"-")}</td><td><button class="mini" data-action="edit-finance" data-id="${x.id}">✏️</button><button class="mini" data-action="delete-finance" data-id="${x.id}">🗑️</button></td></tr>`).join("")}</table>`}
function assistance(){return page("সহায়তা","প্রদান করা সহায়তার হিসাব",`<div class="toolbar"><button class="primary" data-action="new-assistance">＋ সহায়তা যোগ</button></div><div class="card neo tablebox">${simple(data.assistance,["beneficiaryName","type","amount","date"],"সহায়তার রেকর্ড নেই।","assistance")}</div>`)}
function activities(){return page("কার্যক্রম","সংগঠনের কার্যক্রমের রেকর্ড",`<div class="toolbar"><button class="primary" data-action="new-activity">＋ কার্যক্রম যোগ</button></div><div class="card neo tablebox">${simple(data.activities,["title","date","description"],"কোনো কার্যক্রম নেই।","activity")}</div>`)}
function simple(a,cols,empty,type){if(!a.length)return`<div class="empty">${empty}</div>`;let lab={beneficiaryName:"সেবাগ্রহীতা",type:"ধরন",amount:"পরিমাণ",date:"তারিখ",title:"শিরোনাম",description:"বিবরণ"};return`<table class="table"><tr>${cols.map(c=>`<th>${lab[c]}</th>`).join("")}<th>কাজ</th></tr>${a.map(x=>`<tr>${cols.map(c=>`<td>${c==="amount"?money(x[c]):c==="date"?date(x[c]):esc(x[c]||"-")}</td>`).join("")}<td><button class="mini" data-action="delete-${type==="activity"?"activities":"assistance"}" data-id="${x.id}">🗑️</button></td></tr>`).join("")}</table>`}
function reports(){let y=new Date().getFullYear(),m=new Date().getMonth()+1;return page("রিপোর্ট","মাসভিত্তিক ও সামগ্রিক রিপোর্ট",`<div class="card neo filter-card"><select id="rmonth">${monthOptions(m)}</select><select id="ryear">${years()}</select><button class="primary" data-action="monthly-report">📊 মাসিক রিপোর্ট</button><button class="secondary" data-action="pdf-all">📄 সকল রিপোর্ট PDF</button><button class="secondary" data-action="pdf-members">👥 সদস্য PDF</button><button class="secondary" data-action="pdf-dues">💳 চাঁদা PDF</button><button class="secondary" data-action="pdf-finance">💰 আয়-ব্যয় PDF</button></div><div id="reportOut" class="section card neo"><div class="summary"><span>মোট সদস্য</span><b>${data.members.length}</b></div><div class="summary"><span>মোট সেবাগ্রহীতা</span><b>${data.beneficiaries.length}</b></div><div class="summary"><span>মোট আয়</span><b class="green">${money(totalIncome())}</b></div><div class="summary"><span>মোট ব্যয়</span><b class="red">${money(sum("expense"))}</b></div></div>`)}
function settings(){
 const theme=appSettings.theme||"green";
 let modSection=isAdmin()?`<div class="card neo settings-block"><div class="section-title">👤 মডারেটর ব্যবস্থাপনা</div><p class="muted">বিশ্বস্ত কর্মীকে আলাদা Moderator অ্যাকাউন্ট দিন। তারা মূল তথ্য পরিচালনা করতে পারবে, কিন্তু Admin/Moderator ব্যবস্থাপনা করতে পারবে না।</p><div class="toolbar"><button class="primary" data-action="new-moderator">＋ মডারেটর যোগ করুন</button></div><div class="moderator-list">${appSettings.moderatorsList||""}</div></div>`:"";
 return page("সেটিংস","সংগঠনের তথ্য, Theme Color ও অ্যাক্সেস ব্যবস্থাপনা",`<div class="card neo"><div class="formgrid"><div class="form"><label>সংগঠনের নাম</label><input id="sn" value="${esc(appSettings.name||"আল-ইনসাফ মানব কল্যাণ ফাউন্ডেশন")}"></div><div class="form"><label>মোবাইল</label><input id="sp" value="${esc(appSettings.phone||"০১৯১৫৯১০৮০০")}"></div><div class="form full"><label>ঠিকানা</label><input id="sa" value="${esc(appSettings.address||"মালতিপুর, পাথালিয়া, মুক্তাগাছা, ময়মনসিংহ")}"></div><div class="form full"><label>স্লোগান</label><input id="ss" value="${esc(appSettings.slogan||"মানব কল্যাণে অঙ্গীকার, সবার জন্য সঠিক ইনসাফ")}"></div><div class="form"><label>🎨 Theme Color</label><select id="themeSelect">${themeOptions(theme)}</select></div><div class="form"><label>বর্তমান ভূমিকা</label><input value="${roleLabel()}" disabled></div></div><div class="theme-preview"><span class="theme-dot green"></span><span class="theme-dot blue"></span><span class="theme-dot purple"></span><span class="theme-dot orange"></span><span class="theme-dot teal"></span><span class="theme-dot red"></span><span class="theme-dot slate"></span><span>রঙ পরিবর্তন করলে পুরো অ্যাপের মূল রঙ অটোমেটিক বদলাবে।</span></div><div class="modal-actions"><button class="primary" data-action="save-settings">💾 সংরক্ষণ</button></div></div>${modSection}`)}
function open(title,body,save){$("#modalBody").innerHTML=`<h3>${title}</h3>${body}<div class="modal-actions"><button class="secondary" id="cancel">বাতিল</button><button class="primary" id="save">সংরক্ষণ</button></div>`;$("#modal").classList.remove("hidden");$("#cancel").onclick=closeModal;$("#save").onclick=save}
function V(id){const el=$("#"+id);return el?String(el.value||"").trim():""}
function dateInput(id,v=""){return`<input id="${id}" type="date" value="${v||new Date().toISOString().slice(0,10)}">`}

function newItem(t,x=null){editing=x;
 if(t==="member"){let d=x||{};open(x?"সদস্য সম্পাদনা":"নতুন সদস্য",`<div class="formgrid"><div class="form"><label>নাম *</label><input id="n" value="${esc(d.name)}"></div><div class="form"><label>মোবাইল</label><input id="p" value="${esc(d.phone)}"></div><div class="form"><label>যোগদানের তারিখ</label>${dateInput("jd",d.joinDate)}</div><div class="form"><label>অবস্থা</label><select id="st"><option value="active" ${d.status!=="inactive"?"selected":""}>সক্রিয়</option><option value="inactive" ${d.status==="inactive"?"selected":""}>নিষ্ক্রিয়</option></select></div><div class="form full"><label>ঠিকানা</label><input id="ad" value="${esc(d.address)}"></div><div class="form full"><label>মন্তব্য</label><textarea id="no">${esc(d.note)}</textarea></div></div>`,()=>save("members",(x&&x.id),{name:V("n"),phone:V("p"),joinDate:V("jd"),status:V("st"),address:V("ad"),note:V("no")}))}
 if(t==="due"){let d=x||{},now=new Date();open(x?"চাঁদা সম্পাদনা":"মাসিক চাঁদা জমা",`<div class="formgrid"><div class="form"><label>সদস্য</label><select id="mi">${memberOpts(d.memberId)}</select></div><div class="form"><label>মাস</label><select id="mo">${monthOptions(d.month||now.getMonth()+1)}</select></div><div class="form"><label>বছর</label><select id="yr">${years()}</select></div><div class="form"><label>নির্ধারিত চাঁদা</label><input id="ex" type="number" value="${d.expected||0}"></div><div class="form"><label>জমা</label><input id="am" type="number" value="${d.amount||0}"></div><div class="form"><label>তারিখ</label>${dateInput("dt",d.date)}</div><div class="form full"><label>মন্তব্য</label><textarea id="dn">${esc(d.note)}</textarea></div></div>`,()=>{let m=data.members.find(z=>z.id===V("mi"));return save("dues",(x&&x.id),{memberId:V("mi"),memberName:m&&m.name||"",month:Number(V("mo")),monthName:months[Number(V("mo"))-1],year:Number(V("yr")),expected:Number(V("ex")||0),amount:Number(V("am")||0),date:V("dt"),note:V("dn")})});if(d.year)$("#yr").value=d.year}
 if(t==="beneficiary"){let d=x||{};open(x?"সেবাগ্রহীতা সম্পাদনা":"নতুন সেবাগ্রহীতা",`<div class="formgrid"><div class="form"><label>নাম *</label><input id="n" value="${esc(d.name)}"></div><div class="form"><label>NID নম্বর</label><input id="nid" inputmode="numeric" placeholder="জাতীয় পরিচয়পত্র নম্বর" value="${esc(d.nid)}"></div><div class="form"><label>মোবাইল</label><input id="p" value="${esc(d.phone)}"></div><div class="form full"><label>ঠিকানা</label><input id="ad" value="${esc(d.address)}"></div><div class="form full"><label>প্রয়োজন</label><input id="ne" value="${esc(d.need)}"></div><div class="form full"><label>মন্তব্য</label><textarea id="no">${esc(d.note)}</textarea></div></div>`,()=>save("beneficiaries",(x&&x.id),{name:V("n"),nid:V("nid"),phone:V("p"),address:V("ad"),need:V("ne"),note:V("no")}))}
 if(t==="finance"){let d=x||{};open(x?"আয়/ব্যয় সম্পাদনা":"আয় / ব্যয়",`<div class="formgrid"><div class="form"><label>ধরন</label><select id="ty"><option value="income" ${d.type!=="expense"?"selected":""}>আয়</option><option value="expense" ${d.type==="expense"?"selected":""}>ব্যয়</option></select></div><div class="form"><label>পরিমাণ</label><input id="am" type="number" value="${d.amount||0}"></div><div class="form"><label>তারিখ</label>${dateInput("dt",d.date)}</div><div class="form"><label>খাত</label><input id="ca" value="${esc(d.category)}"></div><div class="form full"><label>বিবরণ</label><textarea id="no">${esc(d.note)}</textarea></div></div>`,()=>save("finance",(x&&x.id),{type:V("ty"),amount:Number(V("am")||0),date:V("dt"),category:V("ca"),note:V("no")}))}
 if(t==="assistance"){open("সহায়তা যোগ",`<div class="formgrid"><div class="form"><label>সেবাগ্রহীতা</label><select id="bi">${benOpts()}</select></div><div class="form"><label>ধরন</label><input id="ty"></div><div class="form"><label>পরিমাণ</label><input id="am" type="number"></div><div class="form"><label>তারিখ</label>${dateInput("dt")}</div><div class="form full"><label>বিবরণ</label><textarea id="no"></textarea></div></div>`,()=>{let b=data.beneficiaries.find(z=>z.id===V("bi"));return save("assistance",null,{beneficiaryId:V("bi"),beneficiaryName:(b&&b.name)||"",type:V("ty"),amount:Number(V("am")||0),date:V("dt"),note:V("no")})})}
 if(t==="activity"){open("কার্যক্রম যোগ",`<div class="formgrid"><div class="form"><label>শিরোনাম</label><input id="ti"></div><div class="form"><label>তারিখ</label>${dateInput("dt")}</div><div class="form full"><label>বিবরণ</label><textarea id="de"></textarea></div></div>`,()=>save("activities",null,{title:V("ti"),date:V("dt"),description:V("de")}))}
}
async function save(col,id,obj){try{if(id)await updateDoc(doc(db,col,id),{...obj,updatedAt:serverTimestamp()});else await addDoc(collection(db,col),{...obj,createdAt:serverTimestamp()});await load();closeModal();render();toast("তথ্য সংরক্ষণ হয়েছে")}catch(e){alert("সংরক্ষণ হয়নি। Firebase config ও Rules যাচাই করুন।")}}
async function remove(col,id){if(!confirm("তথ্যটি মুছে ফেলবেন?"))return;try{await deleteDoc(doc(db,col,id));await load();render();toast("মুছে ফেলা হয়েছে")}catch(e){alert("মুছে ফেলা যায়নি")}}
function action(a,id){
 if(a==="new-member")newItem("member");else if(a==="new-due")newItem("due");else if(a==="new-beneficiary")newItem("beneficiary");else if(a==="new-finance")newItem("finance");else if(a==="new-assistance")newItem("assistance");else if(a==="new-activity")newItem("activity");
 else if(a==="edit-member")newItem("member",data.members.find(x=>x.id===id));else if(a==="edit-due")newItem("due",data.dues.find(x=>x.id===id));else if(a==="edit-beneficiary")newItem("beneficiary",data.beneficiaries.find(x=>x.id===id));else if(a==="edit-finance")newItem("finance",data.finance.find(x=>x.id===id));
 else if(a.startsWith("delete-"))remove(a.replace("delete-",""),id);else if(a==="history")history(id);else if(a==="filter-dues")filterDues();else if(a==="monthly-report")monthlyReport();else if(a==="pdf-beneficiaries")printBeneficiaries();else if(a==="pdf-all")printAllReports();else if(a==="pdf-members")printMembers();else if(a==="pdf-dues")printDues();else if(a==="pdf-finance")printFinance();else if(a==="pdf-monthly")printMonthly();else if(a==="save-settings")saveSettings();else if(a==="new-moderator")newModerator()
}
function history(id){let m=data.members.find(x=>x.id===id),d=data.dues.filter(x=>x.memberId===id).sort((a,b)=>Number(b.year)-Number(a.year)||Number(b.month)-Number(a.month));open("চাঁদা ইতিহাস — "+esc(m&&m.name||""),`<div class="history">${d.length?d.map(x=>`<div class="history-item"><span>${x.monthName} ${x.year}<br><small>${x.amount? "জমা: "+money(x.amount):"বাকি"}</small></span><b>${Math.max(0,Number(x.expected||0)-Number(x.amount||0))?money(Math.max(0,Number(x.expected||0)-Number(x.amount||0))):"পরিশোধ"}</b></div>`).join(""):"<div class='empty'>কোনো চাঁদার ইতিহাস নেই।</div>"}</div>`,closeModal)}
function filterDues(){let m=Number(V("dmonth")),y=Number(V("dyear"));$("#dueTable").innerHTML=dueTable(data.dues.filter(x=>Number(x.month)===m&&Number(x.year)===y))}
function monthlyReport(){let m=Number(V("rmonth")),y=Number(V("ryear")),a=data.dues.filter(x=>Number(x.month)===m&&Number(x.year)===y),ex=a.reduce((s,x)=>s+Number(x.expected||0),0),pa=a.reduce((s,x)=>s+Number(x.amount||0),0);$("#reportOut").innerHTML=`<div class="section-title">${months[m-1]} ${y} — চাঁদা রিপোর্ট <button class="secondary" data-action="pdf-monthly" style="float:right">📄 PDF</button></div><div class="summary"><span>চাঁদার রেকর্ড</span><b>${a.length}</b></div><div class="summary"><span>নির্ধারিত</span><b>${money(ex)}</b></div><div class="summary"><span>জমা</span><b class="green">${money(pa)}</b></div><div class="summary"><span>বকেয়া</span><b class="red">${money(Math.max(0,ex-pa))}</b></div><div class="summary"><span>পরিশোধ করেছেন</span><b>${a.filter(x=>Number(x.amount)>=Number(x.expected)).length} জন</b></div><div class="summary"><span>বাকি/আংশিক</span><b>${a.filter(x=>Number(x.amount)<Number(x.expected)).length} জন</b></div>`}

function printHtml(title,content){
 const w=window.open("","_blank","width=900,height=700");
 if(!w){toast("PDF/প্রিন্ট উইন্ডো খুলতে ব্রাউজারের অনুমতি দিন");return}
 const org=esc(appSettings.name||"আল-ইনসাফ মানব কল্যাণ ফাউন্ডেশন");
 w.document.write(`<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title><link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet"><style>body{font-family:'Hind Siliguri',Arial,sans-serif;padding:24px;color:#172033}h1{font-size:22px;margin:0 0 4px}h2{font-size:18px;margin:18px 0 8px}.sub{color:#5f6b7a;margin-bottom:16px}.meta{display:flex;gap:25px;flex-wrap:wrap;margin:10px 0 18px}.meta b{font-size:18px}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #cbd5e1;padding:7px;text-align:left;font-size:12px}th{background:#eef2f7}tfoot td{font-weight:700}@media print{body{padding:0}button{display:none!important}@page{size:A4;margin:12mm}}</style></head><body><h1>${org}</h1><div class="sub">${esc(title)}</div>${content}<script>window.onload=function(){setTimeout(function(){window.print()},500)};<\/script></body></html>`);
 w.document.close();
}
function rows(headers,items,mapper){return `<table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody>${items.map((x,i)=>`<tr>${mapper(x,i).map(v=>`<td>${esc(v)}</td>`).join("")}</tr>`).join("")}</tbody></table>`}
function printBeneficiaries(){
 const total=data.beneficiaries.length;
 const body=`<div class="meta"><div>মোট সেবাগ্রহীতা: <b>${total}</b> জন</div><div>তারিখ: <b>${esc(new Date().toLocaleDateString("bn-BD"))}</b></div></div>`+rows(["ক্রম","নাম","NID","মোবাইল","ঠিকানা","প্রয়োজন"],data.beneficiaries,(x,i)=>[i+1,x.name||"-",x.nid||"-",x.phone||"-",x.address||"-",x.need||"-"]);
 printHtml("সকল সেবাগ্রহীতার তালিকা",body);
}
function printMembers(){printHtml("সকল সদস্যের তালিকা",rows(["ক্রম","নাম","মোবাইল","যোগদানের তারিখ","অবস্থা"],data.members,(x,i)=>[i+1,x.name||"-",x.phone||"-",date(x.joinDate),x.status==="active"?"সক্রিয়":"নিষ্ক্রিয়"]));}
function printDues(){let ex=data.dues.reduce((s,x)=>s+Number(x.expected||0),0),pa=data.dues.reduce((s,x)=>s+Number(x.amount||0),0);printHtml("সকল চাঁদার রিপোর্ট",`<div class="meta"><div>নির্ধারিত: <b>${money(ex)}</b></div><div>জমা: <b>${money(pa)}</b></div><div>বকেয়া: <b>${money(Math.max(0,ex-pa))}</b></div></div>`+rows(["ক্রম","সদস্য","মাস","নির্ধারিত","জমা","বকেয়া","তারিখ"],data.dues,(x,i)=>[i+1,x.memberName||"-",`${x.monthName||"-"} ${x.year||""}`,money(x.expected),money(x.amount),money(Math.max(0,Number(x.expected||0)-Number(x.amount||0))),date(x.date)]));}
function printFinance(){let inc=totalIncome(),out=totalExpense();printHtml("আয়-ব্যয় ও ব্যালেন্স রিপোর্ট",`<div class="meta"><div>মোট আয়: <b>${money(inc)}</b></div><div>মোট ব্যয়: <b>${money(out)}</b></div><div>বর্তমান ব্যালেন্স: <b>${money(inc-out)}</b></div></div>`+rows(["ক্রম","তারিখ","ধরন","খাত","পরিমাণ","বিবরণ"],data.finance,(x,i)=>[i+1,date(x.date),x.type==="income"?"আয়":"ব্যয়",x.category||"-",money(x.amount),x.note||"-"]));}
function printMonthly(){let m=Number(V("rmonth")),y=Number(V("ryear")),a=data.dues.filter(x=>Number(x.month)===m&&Number(x.year)===y),ex=a.reduce((s,x)=>s+Number(x.expected||0),0),pa=a.reduce((s,x)=>s+Number(x.amount||0),0);printHtml(`${months[m-1]} ${y} — মাসিক চাঁদা রিপোর্ট`,`<div class="meta"><div>নির্ধারিত: <b>${money(ex)}</b></div><div>জমা: <b>${money(pa)}</b></div><div>বকেয়া: <b>${money(Math.max(0,ex-pa))}</b></div></div>`+rows(["ক্রম","সদস্য","নির্ধারিত","জমা","বকেয়া","অবস্থা"],a,(x,i)=>{let b=Math.max(0,Number(x.expected||0)-Number(x.amount||0));return[i+1,x.memberName||"-",money(x.expected),money(x.amount),money(b),b===0?"পরিশোধ":Number(x.amount)>0?"আংশিক":"বাকি"]}));}
function printAllReports(){
 const income=totalIncome(),expense=totalExpense();
 let html=`<h2>সারসংক্ষেপ</h2><div class="meta"><div>সদস্য: <b>${data.members.length}</b></div><div>সেবাগ্রহীতা: <b>${data.beneficiaries.length}</b></div><div>মোট আয়: <b>${money(income)}</b></div><div>মোট ব্যয়: <b>${money(expense)}</b></div><div>বর্তমান ব্যালেন্স: <b>${money(income-expense)}</b></div></div>`;
 html+=`<h2>সদস্য</h2>`+rows(["ক্রম","নাম","মোবাইল","যোগদানের তারিখ","অবস্থা"],data.members,(x,i)=>[i+1,x.name||"-",x.phone||"-",date(x.joinDate),x.status==="active"?"সক্রিয়":"নিষ্ক্রিয়"]);
 html+=`<h2>সকল সেবাগ্রহীতা</h2>`+rows(["ক্রম","নাম","NID","মোবাইল","ঠিকানা","প্রয়োজন"],data.beneficiaries,(x,i)=>[i+1,x.name||"-",x.nid||"-",x.phone||"-",x.address||"-",x.need||"-"]);
 html+=`<h2>চাঁদা</h2>`+rows(["ক্রম","সদস্য","মাস","নির্ধারিত","জমা","বকেয়া"],data.dues,(x,i)=>[i+1,x.memberName||"-",`${x.monthName||"-"} ${x.year||""}`,money(x.expected),money(x.amount),money(Math.max(0,Number(x.expected||0)-Number(x.amount||0)))]);
 html+=`<h2>আয়-ব্যয়</h2>`+rows(["ক্রম","তারিখ","ধরন","খাত","পরিমাণ","বিবরণ"],data.finance,(x,i)=>[i+1,date(x.date),x.type==="income"?"আয়":"ব্যয়",x.category||"-",money(x.amount),x.note||"-"]);
 html+=`<h2>সহায়তা</h2>`+rows(["ক্রম","সেবাগ্রহীতা","ধরন","পরিমাণ","তারিখ"],data.assistance,(x,i)=>[i+1,x.beneficiaryName||"-",x.type||"-",money(x.amount),date(x.date)]);
 html+=`<h2>কার্যক্রম</h2>`+rows(["ক্রম","শিরোনাম","তারিখ","বিবরণ"],data.activities,(x,i)=>[i+1,x.title||"-",date(x.date),x.description||"-"]);
 printHtml("আল-ইনসাফ — পূর্ণাঙ্গ রিপোর্ট",html);
}
async function saveSettings(){try{const theme=V("themeSelect")||"green";await setDoc(doc(db,"settings","main"),{name:V("sn"),phone:V("sp"),address:V("sa"),slogan:V("ss"),theme},{merge:true});appSettings={...appSettings,name:V("sn"),phone:V("sp"),address:V("sa"),slogan:V("ss"),theme};applyTheme(theme);toast("সেটিংস সংরক্ষণ হয়েছে");render()}catch(e){console.error(e);alert("সেটিংস সংরক্ষণ হয়নি")}}
async function newModerator(){if(!isAdmin()){toast("শুধু Admin মডারেটর যোগ করতে পারবেন");return}open("নতুন মডারেটর",`<div class="formgrid"><div class="form"><label>নাম *</label><input id="mn" placeholder="মডারেটরের নাম"></div><div class="form"><label>ইমেইল *</label><input id="me" type="email" placeholder="example@email.com"></div><div class="form full"><label>পাসওয়ার্ড *</label><input id="mp" type="password" placeholder="কমপক্ষে ৬ অক্ষর"></div><div class="form full"><label>অনুমতি</label><div class="permission-box"><label><input type="checkbox" id="pmMembers" checked> সদস্য</label><label><input type="checkbox" id="pmDues" checked> চাঁদা</label><label><input type="checkbox" id="pmBeneficiaries" checked> সেবাগ্রহীতা</label><label><input type="checkbox" id="pmFinance"> আয়-ব্যয়</label><label><input type="checkbox" id="pmReports" checked> রিপোর্ট</label></div></div></div>`,async()=>{const name=V("mn"),email=V("me"),password=V("mp");if(!name||!email||password.length<6){toast("নাম, ইমেইল ও কমপক্ষে ৬ অক্ষরের Password দিন");return}try{const secondary=initializeApp(firebaseConfig,"moderator-"+Date.now());const secAuth=getAuth(secondary);const cred=await createUserWithEmailAndPassword(secAuth,email,password);const permissions={members:!!$("#pmMembers")?.checked,dues:!!$("#pmDues")?.checked,beneficiaries:!!$("#pmBeneficiaries")?.checked,finance:!!$("#pmFinance")?.checked,reports:!!$("#pmReports")?.checked};await setDoc(doc(db,"roles",cred.user.uid),{role:"moderator",name,email,permissions,createdAt:serverTimestamp()});toast("মডারেটর তৈরি হয়েছে");await load();closeModal();render();try{await signOut(secAuth)}catch(e){} }catch(e){console.error(e);alert("মডারেটর তৈরি হয়নি: "+(e&&e.message||"Firebase Error"))}})}
document.addEventListener("input",e=>{if(e.target.id==="msearch")$("#memberTable").innerHTML=memberTable(data.members.filter(x=>(x.name||"").includes(e.target.value)||(x.phone||"").includes(e.target.value)));if(e.target.id==="bsearch"){let q=e.target.value.toLowerCase();$("#benTable").innerHTML=benTable(data.beneficiaries.filter(x=>(x.name||"").toLowerCase().includes(q)||(x.phone||"").toLowerCase().includes(q)||(x.nid||"").toLowerCase().includes(q)))}});