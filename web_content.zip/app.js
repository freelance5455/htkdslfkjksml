/* Filet de sécurité : si le script principal échoue au démarrage, on affiche l'erreur
   au lieu de laisser l'écran « Chargement… » bloqué indéfiniment. */
window.addEventListener('error',function(e){
  if(window.__appReady) return;
  var sp=document.getElementById('splash'); if(sp) sp.style.display='none';
  var d=document.createElement('div');
  d.setAttribute('role','alert');
  d.style.cssText='position:fixed;top:0;right:0;bottom:0;left:0;z-index:9000;display:flex;align-items:center;justify-content:center;padding:24px;text-align:center;background:#0a1628;color:#fff;font:16px/1.5 system-ui,sans-serif';
  d.textContent='Une erreur empêche le chargement de l\u2019application (' + (e.message||'erreur inconnue') + '). Rechargez la page ; si le problème persiste, contactez le développeur.';
  document.body.appendChild(d);
});
/* ============================================================
   DONNÉES PRINCIPALES
   ============================================================ */
const P = {
  /* ============================================================
     PÉRIODE 1 : TEXTE EXPLICATIF
     ============================================================ */
  p1:{id:'p1',titre:'Texte Explicatif',desc:'Reportage, guide de voyage',sem:8,c:'#4361ee',cd:'#2a3eb1',cb:'rgba(67,97,238,.1)',themes:[
    /* THÈME 1.1 : L'ARTISANAT */
    {id:'artisanat',titre:"L'Artisanat",desc:"Reportage sur les formes d'artisanat à Madagascar",type:'Explicatif : reportage',v:'Persévérance, rigueur',
      semaines:[
        {code:'S1',titre:'Découverte et Compréhension',desc:"Découvrir le texte de base et comprendre le sens global",objectif:'Compréhension globale du texte',
          lecon:{intro:"L'artisanat malgache est riche et varié. Il comprend la vannerie, la poterie, la broderie, le tissage en raphia, le taillage et le polissage, la sculpture et la fonte. Chaque région de Madagascar possède ses propres spécialités. Par exemple, la vannerie est très développée dans les hautes terres, tandis que la poterie est plus présente dans le sud. Cependant, les artisans malgaches rencontrent de nombreux problèmes : concurrence des produits industriels, manque de ressources, difficulté à trouver des débouchés. Malgré ces difficultés, l'artisanat reste une activité importante pour l'économie malgache.",
            points:["L'artisanat malgache comprend plusieurs formes : vannerie, poterie, broderie, tissage, sculpture, fonte","Chaque région a ses spécialités : vannerie dans les hautes terres, poterie dans le sud","Les artisans font face à la concurrence des produits industriels","Ils manquent de ressources pour acheter des matières premières de qualité","Ils ont du mal à trouver des débouchés commerciaux","L'artisanat reste important pour l'économie malgache"],
            ms:"Le présent de l'indicatif est utilisé pour décrire les faits. Les connecteurs spatiaux situent les lieux et les objets.",
            lex:["Vannerie, poterie, broderie, tissage, sculpture, fonte","Concurrence, ressources, matières premières, débouchés","Savoir-faire, économie, emplois"]},
          exosOuverts:[
            {titre:"Associez chaque mot à sa définition",type:"tableau",tag:"LEXIQUE",
              consigne:"Reliez chaque mot de la colonne A à sa définition dans la colonne B.",
              entetes:["N°","Colonne A (Mot)","Colonne B (Définition)","Réponse"],
              lignes:[
                ["1","Vannerie","A. Art de modeler l'argile pour créer des objets",""],
                ["2","Poterie","B. Art de tresser des fibres végétales",""],
                ["3","Broderie","C. Art de décorer un tissu avec des fils",""],
                ["4","Sculpture","D. Art de tailler la pierre ou le bois",""],
                ["5","Tissage","E. Art de fabriquer des tissus",""],
                ["6","Fonte","F. Art de couler un métal en fusion",""],
                ["7","Polissage","G. Action de rendre une surface lisse et brillante",""]
              ],
              corrige:["1 → B (Vannerie = Art de tresser des fibres végétales)","2 → A (Poterie = Art de modeler l'argile)","3 → C (Broderie = Art de décorer un tissu avec des fils)","4 → D (Sculpture = Art de tailler la pierre ou le bois)","5 → E (Tissage = Art de fabriquer des tissus)","6 → F (Fonte = Art de couler un métal en fusion)","7 → G (Polissage = Action de rendre une surface lisse et brillante)"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : concurrence, ressources, débouchés, savoir-faire, matières premières, économie, emplois.",
              phrases:[
                "Les artisans malgaches font face à une forte ___. (concurrence)",
                "Ils manquent de ___ pour acheter des ___ de qualité. (ressources / matières premières)",
                "Beaucoup d'artisans ont du mal à trouver des ___ pour vendre leurs produits. (débouchés)",
                "L'artisanat permet de préserver des ___ traditionnels. (savoir-faire)",
                "L'artisanat reste une activité importante pour l'___ malgache. (économie)",
                "Grâce à l'artisanat, de nombreux ___ sont créés chaque année. (emplois)"
              ]},
            {titre:"Complétez avec un connecteur spatial",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec un connecteur spatial choisi parmi : devant, derrière, à côté de, dans, près de, sous, sur, entre, vers, au-dessus de.",
              phrases:[
                "Les paniers en raphia sont posés ___ la table. (sur)",
                "L'artisan travaille ___ son établi. (devant)",
                "Les produits sont rangés ___ l'armoire. (dans)",
                "Le four se trouve ___ l'atelier. (dans / près de)",
                "Le marché se trouve ___ la boutique. (à côté de / près de)",
                "Les outils sont suspendus ___ le mur. (au-dessus de / sur)",
                "La cliente attend ___ la porte. (devant)"
              ]},
            {titre:"Décrivez l'atelier avec des connecteurs spatiaux",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez 5 phrases pour décrire l'organisation d'un atelier artisanal. Utilisez au moins 5 connecteurs spatiaux différents parmi : devant, derrière, à côté de, près de, au-dessus de, sous, dans, sur, entre, parmi, vers, à gauche, à droite.",
              lignes:5,
              exemple:"Le four se trouve à côté de l'établi.",
              corrige:"Réponses libres. Vérifier l'utilisation correcte d'au moins 5 connecteurs spatiaux différents."}
          ],
          exos:[
            {q:"Quelle est la spécialité artisanale des hautes terres de Madagascar ?",o:["La poterie","La vannerie","La fonte","La sculpture"],c:1,e:"D'après le texte, la vannerie est très développée dans les hautes terres."},
            {q:"Pourquoi les artisans malgaches font-ils face à une concurrence accrue ?",o:["Les produits industriels sont moins chers","Les produits artisanaux sont trop beaux","Il y a trop de clients","Les artisans refusent de travailler"],c:0,e:"Les produits industriels sont souvent moins chers et plus faciles à trouver."},
            {q:"De quoi les artisans manquent-ils pour acheter des matières premières de qualité ?",o:["De clients","De ressources","D'outils","De temps"],c:1,e:"Les artisans manquent de ressources financières pour acheter des matières premières de qualité."},
            {q:"Quels sont les deux avantages de l'artisanat pour l'économie malgache ?",o:["Préserver les savoir-faire et créer des emplois","Augmenter les impôts et réduire les salaires","Importer des produits et exporter des matières","Réduire les coûts et augmenter les prix"],c:0,e:"L'artisanat permet de préserver des savoir-faire traditionnels et de créer des emplois."},
            {q:"Que signifie « Vannerie » ?",o:["Art de modeler l'argile","Art de tresser des fibres végétales","Art de décorer un tissu","Art de tailler la pierre"],c:1,e:"La vannerie est l'art de tresser des fibres végétales."}
          ]},
        {code:'S2',titre:'Approfondissement Lexical',desc:"Approfondir le lexique des problèmes, outils et matériaux",objectif:'Maîtriser le lexique des problèmes et des outils',
          lecon:{intro:"Les artisans malgaches font face à de nombreux défis. La concurrence des produits industriels est le premier problème. Ces produits sont souvent moins chers et plus faciles à trouver. Ensuite, le manque de ressources est un obstacle majeur. Les artisans ont du mal à trouver des matières premières de qualité à des prix raisonnables. Enfin, le manque de visibilité nuit à la commercialisation. Beaucoup d'artisans ne savent pas comment promouvoir leurs produits.",
            points:["Les problèmes économiques : concurrence, manque de ressources, manque de débouchés","Les problèmes culturels : perte de savoir-faire traditionnels","Les problèmes administratifs : complexité administrative","Les outils : marteau, ciseau, aiguille, pinceau","Les matériaux : argile, raphia, bois, métal","Les conséquences : abandon du métier, menace culturelle"],
            ms:"Les connecteurs logiques organisent les idées : d'abord, ensuite, enfin. Ils expriment la cause (parce que), la conséquence (donc), l'opposition (mais).",
            lex:["Concurrence, ressources, débouchés, savoir-faire, matières premières","Pression financière, visibilité, complexité administrative","Outils, matériaux, argile, raphia, bois, métal"]},
          exosOuverts:[
            {titre:"Classez les problèmes de l'artisanat",type:"tableau",tag:"LEXIQUE",
              consigne:"Pour chaque problème, indiquez la catégorie qui lui correspond : économique, culturel ou administratif.",
              entetes:["N°","Problème de l'artisanat","Catégorie"],
              lignes:[
                ["1","Concurrence des produits industriels","Économique"],
                ["2","Perte de savoir-faire traditionnels","Culturel"],
                ["3","Manque de visibilité sur le marché","Économique"],
                ["4","Complexité administrative","Administratif"],
                ["5","Pression financière sur les artisans","Économique"],
                ["6","Manque de ressources pour acheter les matières premières","Économique"],
                ["7","Difficulté à trouver des débouchés commerciaux","Économique"]
              ],
              corrige:["1 → Économique","2 → Culturel","3 → Économique","4 → Administratif","5 → Économique","6 → Économique","7 → Économique"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : concurrence, ressources, débouchés, savoir-faire, matières premières, pression financière, visibilité.",
              phrases:[
                "Les artisans malgaches font face à une forte ___. (concurrence)",
                "Le manque de ___ empêche les artisans d'acheter des ___ de qualité. (ressources / matières premières)",
                "La ___ pousse certains artisans à abandonner leur métier. (pression financière)",
                "Sans ___, les artisans ont du mal à vendre leurs produits. (visibilité)",
                "La perte de ___ traditionnels menace la culture malgache. (savoir-faire)",
                "Les artisans ont besoin de ___ pour écouler leurs produits. (débouchés)"
              ]},
            {titre:"Trouvez l'intrus",type:"production",tag:"LEXIQUE",
              consigne:"Pour chaque liste, identifiez et justifiez l'intrus.",
              lignes:3,
              exemple:"Vannerie – Poterie – Broderie – Ordinateur → L'intrus est « Ordinateur » car ce n'est pas une forme d'artisanat.",
              phrases:[
                "Vannerie – Poterie – Broderie – Ordinateur",
                "Raphia – Argile – Bois – Plastique",
                "Artisan – Ouvrier – Employé – Client"
              ],
              corrige:["1. Ordinateur (ce n'est pas une forme d'artisanat)","2. Plastique (ce n'est pas une matière première naturelle)","3. Client (ce n'est pas un métier)"]},
            {titre:"Identifiez les connecteurs logiques",type:"tableau",tag:"SYNTAXE",
              consigne:"Soulignez le connecteur logique dans chaque phrase, puis indiquez s'il exprime une cause, une conséquence, une opposition ou une organisation.",
              entetes:["N°","Phrase","Connecteur","Rôle"],
              lignes:[
                ["1","D'abord, les artisans manquent de matières premières.","D'abord","Organisation"],
                ["2","Ensuite, ils ont du mal à vendre leurs produits.","Ensuite","Organisation"],
                ["3","Les artisans travaillent dur, mais les revenus sont faibles.","mais","Opposition"],
                ["4","Parce que les produits industriels sont moins chers, les clients les préfèrent.","Parce que","Cause"],
                ["5","La concurrence est forte, donc les ventes diminuent.","donc","Conséquence"],
                ["6","Enfin, la complexité administrative décourage les jeunes.","Enfin","Organisation"],
                ["7","Les artisans ont besoin de soutien, or ils ne reçoivent pas d'aide.","or","Opposition"]
              ],
              corrige:["1. D'abord → Organisation","2. Ensuite → Organisation","3. mais → Opposition","4. Parce que → Cause","5. donc → Conséquence","6. Enfin → Organisation","7. or → Opposition"]},
            {titre:"Transformez les phrases avec les connecteurs indiqués",type:"transformation",tag:"SYNTAXE",
              consigne:"Réécrivez chaque phrase en utilisant le connecteur logique indiqué entre parenthèses.",
              phrases:[
                "Les artisans manquent de ressources. Ils ne peuvent pas acheter de bonnes matières premières. (parce que)",
                "La concurrence est forte. Les ventes diminuent. (donc)",
                "Les produits artisanaux sont beaux. Ils sont chers. (mais)",
                "Les artisans travaillent beaucoup. Ils gagnent peu. (bien que)",
                "Le savoir-faire traditionnel est précieux. Il faut le préserver. (car)",
                "La pression financière est forte. Certains artisans abandonnent leur métier. (c'est pourquoi)",
                "Les jeunes sont découragés. La complexité administrative est grande. (à cause de)"
              ],
              corrige:[
                "1. Les artisans ne peuvent pas acheter de bonnes matières premières parce qu'ils manquent de ressources.",
                "2. La concurrence est forte, donc les ventes diminuent.",
                "3. Les produits artisanaux sont beaux, mais ils sont chers.",
                "4. Bien que les artisans travaillent beaucoup, ils gagnent peu.",
                "5. Il faut préserver le savoir-faire traditionnel car il est précieux.",
                "6. La pression financière est forte, c'est pourquoi certains artisans abandonnent leur métier.",
                "7. Les jeunes sont découragés à cause de la complexité administrative."
              ]},
            {titre:"Rédigez un paragraphe explicatif sur un problème de l'artisanat",type:"production",tag:"SYNTAXE",
              consigne:"Choisissez un problème de l'artisanat malgache. Rédigez un paragraphe explicatif de 5 à 6 phrases en respectant la structure : phrase 1 (annonce du problème), phrases 2-3 (causes), phrases 4-5 (conséquences), phrase 6 (conclusion ou piste de solution). Utilisez au moins 3 connecteurs logiques.",
              lignes:6,
              exemple:"La concurrence des produits industriels est un problème majeur pour les artisans malgaches. D'abord, les produits industriels sont souvent moins chers, parce que leur fabrication est mécanisée. Ensuite, ils sont plus faciles à trouver dans les commerces. Par conséquent, les clients préfèrent les acheter au lieu des produits artisanaux.",
              corrige:"Réponses libres. Vérifier : choix d'un problème clair, structure en 5-6 phrases, utilisation d'au moins 3 connecteurs logiques, cohérence et correction grammaticale."}
          ],
          exos:[
            {q:"Dans quelle catégorie classer « Concurrence des produits industriels » ?",o:["Culturel","Économique","Administratif","Social"],c:1,e:"C'est un problème économique."},
            {q:"Dans quelle catégorie classer « Perte de savoir-faire traditionnels » ?",o:["Économique","Culturel","Administratif","Politique"],c:1,e:"C'est un problème culturel."},
            {q:"Dans quelle catégorie classer « Complexité administrative » ?",o:["Économique","Culturel","Administratif","Social"],c:2,e:"C'est un problème administratif."},
            {q:"Quel connecteur exprime la cause ?",o:["Mais","Donc","Parce que","Ensuite"],c:2,e:"« Parce que » exprime la cause."},
            {q:"Quel connecteur exprime la conséquence ?",o:["Parce que","Donc","Mais","Ensuite"],c:1,e:"« Donc » exprime la conséquence."}
          ]},
        {code:'S3',titre:'Structuration et Production',desc:"Maîtriser la structure du texte explicatif et produire",objectif:'Produire un texte explicatif complet',
          lecon:{intro:"Le texte explicatif suit une structure claire : introduction (présentation du sujet et problématique), développement (explications, causes, conséquences, exemples) et conclusion (synthèse et ouverture). Pour enrichir sa production, il faut utiliser un lexique précis, des connecteurs logiques et spatiaux, et varier la structure des phrases.",
            points:["Introduction : présentation du sujet + problématique","Développement : explications, causes, conséquences, exemples","Conclusion : synthèse + ouverture","Enrichir ses phrases avec des synonymes précis","Utiliser les connecteurs logiques et spatiaux","Maîtriser les phrases simples, juxtaposées, coordonnées, subordonnées","Transformer les phrases actives en passives et vice-versa"],
            ms:"La voix passive se forme avec l'auxiliaire « être » + participe passé. Le COD de la phrase active devient sujet de la phrase passive. Exemple : L'artisan fabrique un panier → Le panier est fabriqué par l'artisan.",
            lex:["Synonymes précis : essentiel, primordial, capital","Familles de mots : artisan/artisanat/artisanal","Connecteurs logiques et spatiaux","Phrases simples, juxtaposées, coordonnées, subordonnées"]},
          exosOuverts:[
            {titre:"Enrichissez vos phrases",type:"transformation",tag:"LEXIQUE",
              consigne:"Remplacez le mot souligné par un synonyme plus précis et plus expressif.",
              phrases:[
                "L'artisanat est important pour l'économie malgache. → essentiel / primordial / capital",
                "Les artisans ont des problèmes. → des difficultés / des obstacles / des défis",
                "Les produits artisanaux sont beaux. → magnifiques / splendides / remarquables",
                "Le travail artisanal est difficile. → exigeant / laborieux / pénible",
                "Les savoir-faire traditionnels sont importants à préserver. → précieux / fondamentaux / capitaux",
                "Les clients trouvent ces produits bien. → excellents / remarquables / satisfaisants",
                "L'atelier est grand et bien organisé. → spacieux / vaste / imposant"
              ],
              corrige:["1. essentiel / primordial / capital","2. des difficultés / des obstacles / des défis","3. magnifiques / splendides / remarquables","4. exigeant / laborieux / pénible","5. précieux / fondamentaux / capitaux","6. excellents / remarquables / satisfaisants","7. spacieux / vaste / imposant"]},
            {titre:"Créez des familles de mots",type:"tableau",tag:"LEXIQUE",
              consigne:"Complétez le tableau avec le verbe et l'adjectif correspondant à chaque nom.",
              entetes:["Nom","Verbe","Adjectif"],
              lignes:[
                ["Artisan","exercer un artisanat","artisanal"],
                ["Production","produire","productif"],
                ["Création","créer","créatif"],
                ["Fabrication","fabriquer","fabriqué / fabricable"]
              ],
              corrige:["Artisan → exercer un artisanat / artisanal","Production → produire / productif","Création → créer / créatif","Fabrication → fabriquer / fabriqué"]},
            {titre:"Transformez les phrases passives en actives et vice-versa",type:"transformation",tag:"SYNTAXE",
              consigne:"Réécrivez chaque phrase en changeant la voix (passive → active ou active → passive).",
              phrases:[
                "Les paniers sont fabriqués par les artisans. → Les artisans fabriquent les paniers.",
                "Les artisans vendent leurs produits au marché. → Les produits sont vendus par les artisans au marché.",
                "Les matières premières sont achetées par les artisans. → Les artisans achètent les matières premières.",
                "La potière modèle l'argile. → L'argile est modelée par la potière.",
                "Le raphia est tissé par les vanniers. → Les vanniers tissent le raphia.",
                "Les clients apprécient les produits artisanaux. → Les produits artisanaux sont appréciés par les clients.",
                "Les savoir-faire traditionnels sont transmis par les anciens. → Les anciens transmettent les savoir-faire traditionnels."
              ],
              corrige:["1. Les artisans fabriquent les paniers.","2. Les produits sont vendus par les artisans au marché.","3. Les artisans achètent les matières premières.","4. L'argile est modelée par la potière.","5. Les vanniers tissent le raphia.","6. Les produits artisanaux sont appréciés par les clients.","7. Les anciens transmettent les savoir-faire traditionnels."]},
            {titre:"Décrivez l'atelier avec des connecteurs spatiaux",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez 5 phrases pour décrire l'organisation d'un atelier artisanal. Utilisez au moins 5 connecteurs spatiaux différents.",
              lignes:5,
              exemple:"Le four se trouve à côté de l'établi.",
              corrige:"Réponses libres. Exemple : Le four se trouve à côté de l'établi. Les outils sont suspendus au-dessus de l'établi. Les paniers sont posés sur la table. Le sac de raphia est rangé sous le comptoir. Les clients attendent devant la boutique."},
            {titre:"Analysez la structure des phrases",type:"tableau",tag:"SYNTAXE",
              consigne:"Indiquez si chaque phrase est simple, juxtaposée, coordonnée ou subordonnée.",
              entetes:["N°","Phrase","Type"],
              lignes:[
                ["1","Les artisans travaillent dur et ils espèrent réussir.","Coordonnée"],
                ["2","Les produits sont beaux, les clients sont satisfaits.","Juxtaposée"],
                ["3","Parce que la concurrence est forte, les ventes diminuent.","Subordonnée"],
                ["4","L'artisanat est une richesse.","Simple"],
                ["5","Les artisans créent des objets, ils les vendent au marché.","Juxtaposée"],
                ["6","Le savoir-faire est précieux mais il est menacé.","Coordonnée"],
                ["7","Je pense que l'artisanat doit être soutenu.","Subordonnée"]
              ],
              corrige:["1. Coordonnée (et)","2. Juxtaposée (virgule)","3. Subordonnée (parce que)","4. Simple","5. Juxtaposée (virgule)","6. Coordonnée (mais)","7. Subordonnée (que)"]},
            {titre:"Rédigez un texte explicatif complet sur l'artisanat",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un texte explicatif complet sur l'artisanat malgache. Structure : Introduction (présentation + problématique), Développement (formes, problèmes, conséquences), Conclusion (synthèse + ouverture). Utilisez au moins 3 connecteurs logiques et 2 connecteurs spatiaux.",
              lignes:8,
              corrige:"Réponses libres. Vérifier : présence des 3 parties, au moins 3 connecteurs logiques, au moins 2 connecteurs spatiaux, lexique de l'artisanat, cohérence et correction."}
          ],
          exos:[
            {q:"Quel est l'adjectif dérivé du nom « artisan » ?",o:["Artisanal","Artisien","Artisanique","Artisanel"],c:0,e:"L'adjectif est « artisanal » (le nom « artisan » n'a pas de verbe dérivé ; on dit « exercer un artisanat »)."},
            {q:"Quelle phrase est coordonnée ?",o:["Les artisans travaillent dur et ils espèrent réussir","Les produits sont beaux, les clients sont satisfaits","Parce que la concurrence est forte, les ventes diminuent","L'artisanat est une richesse"],c:0,e:"« Et » est une conjonction de coordination."},
            {q:"Quelle phrase est subordonnée ?",o:["Les artisans travaillent dur et ils espèrent réussir","Les produits sont beaux, les clients sont satisfaits","Parce que la concurrence est forte, les ventes diminuent","L'artisanat est une richesse"],c:2,e:"« Parce que » introduit une subordonnée."}
          ]},
        {code:'S4',titre:'Évaluation et Consolidation',desc:"Évaluer les acquis lexicaux et syntaxiques",objectif:'Évaluation des compétences',
          lecon:{intro:"Cette semaine est consacrée à l'évaluation et à la consolidation des acquis. Nous révisons le lexique de l'artisanat, les connecteurs logiques et spatiaux, les types de phrases et la production écrite.",
            points:["Révision du lexique de l'artisanat","Révision des connecteurs logiques et spatiaux","Révision des types de phrases","Révision de la voix passive et active","Consolidation de la production écrite","Préparation à l'évaluation finale"],
            ms:"Révision globale : présent de l'indicatif, connecteurs, voix passive/active, types de phrases.",
            lex:["Tout le lexique de l'artisanat","Outils et matériaux","Problèmes : concurrence, ressources, débouchés, savoir-faire"]},
          exosOuverts:[
            {titre:"Mots croisés de l'artisanat",type:"tableau",tag:"LEXIQUE",
              consigne:"Retrouvez le mot correspondant à chaque définition.",
              entetes:["N°","Définition","Mot à trouver"],
              lignes:[
                ["1","Art de tresser des fibres végétales",""],
                ["2","Art de modeler l'argile",""],
                ["3","Art de décorer un tissu avec des fils",""],
                ["4","Matière première du potier",""],
                ["5","Matière première du vannier",""],
                ["6","Problème lié aux produits industriels",""],
                ["7","Compétence technique transmise par les anciens",""]
              ],
              corrige:["1. Vannerie","2. Poterie","3. Broderie","4. Argile","5. Raphia","6. Concurrence","7. Savoir-faire"]},
            {titre:"QCM – Choisissez la bonne réponse",type:"qcm-ouvert",tag:"LEXIQUE",
              consigne:"Entourez la bonne réponse.",
              questions:[
                {q:"Lequel n'est pas une forme d'artisanat ?",o:["Vannerie","Poterie","Informatique","Broderie"],c:2},
                {q:"Quel est le problème principal de l'artisanat ?",o:["Trop de clients","Concurrence des produits industriels","Trop de matières premières","Trop d'employés"],c:1},
                {q:"Quel connecteur logique exprime la conséquence ?",o:["D'abord","Ensuite","Donc","Enfin"],c:2},
                {q:"Que signifie « savoir-faire » ?",o:["Connaissance théorique","Compétence technique","Diplôme universitaire","Salaire élevé"],c:1},
                {q:"Quelle est la matière première du tissage ?",o:["L'argile","Le raphia","La pierre","Le métal"],c:1},
                {q:"Que signifie « valoriser » l'artisanat ?",o:["L'abandonner","Le surestimer","Le mettre en valeur","Le critiquer"],c:2}
              ],
              corrige:["1. c) Informatique","2. b) Concurrence des produits industriels","3. c) Donc","4. b) Compétence technique","5. b) Le raphia","6. b) Rivalité","7. c) Le mettre en valeur"]},
            {titre:"Complétez avec le connecteur qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec le connecteur logique approprié choisi parmi : d'abord, ensuite, enfin, mais, parce que, donc, car.",
              phrases:[
                "___, les artisans achètent les matières premières. (D'abord)",
                "___, ils fabriquent les produits artisanaux. (Ensuite)",
                "___, ils les vendent au marché. (Enfin)",
                "Les produits artisanaux sont beaux, ___ ils sont chers. (mais)",
                "___ la concurrence est forte, les artisans doivent s'adapter. (Parce que)",
                "La pression financière est intense, ___ certains abandonnent. (donc)",
                "Il faut préserver le savoir-faire ___ il est précieux. (car)"
              ]},
            {titre:"Transformez selon le modèle",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase active en phrase passive (ou inversement).",
              phrases:[
                "L'artisan tisse le raphia. → Le raphia est tissé par l'artisan.",
                "La potière modèle l'argile. → L'argile est modelée par la potière.",
                "Les artisans vendent les produits. → Les produits sont vendus par les artisans.",
                "Les paniers sont fabriqués par les vanniers. → Les vanniers fabriquent les paniers.",
                "Le savoir-faire est transmis par les anciens. → Les anciens transmettent le savoir-faire.",
                "Les clients apprécient les produits artisanaux. → Les produits artisanaux sont appréciés par les clients.",
                "Les matières premières sont achetées par les artisans. → Les artisans achètent les matières premières."
              ],
              corrige:["1. Le raphia est tissé par l'artisan.","2. L'argile est modelée par la potière.","3. Les produits sont vendus par les artisans.","4. Les vanniers fabriquent les paniers.","5. Les anciens transmettent le savoir-faire.","6. Les produits artisanaux sont appréciés par les clients.","7. Les artisans achètent les matières premières."]},
            {titre:"Analysez la structure des phrases",type:"tableau",tag:"SYNTAXE",
              consigne:"Indiquez si chaque phrase est simple, juxtaposée, coordonnée ou subordonnée.",
              entetes:["N°","Phrase","Type"],
              lignes:[
                ["1","L'artisanat est une richesse.","Simple"],
                ["2","Les artisans travaillent dur et ils espèrent réussir.","Coordonnée"],
                ["3","Les produits sont beaux, les clients sont satisfaits.","Juxtaposée"],
                ["4","Parce que la concurrence est forte, les ventes diminuent.","Subordonnée"],
                ["5","Le savoir-faire est précieux mais il est menacé.","Coordonnée"],
                ["6","Je pense que l'artisanat doit être soutenu.","Subordonnée"],
                ["7","Les artisans créent, ils vendent, ils prospèrent.","Juxtaposée"]
              ],
              corrige:["1. Simple","2. Coordonnée (et)","3. Juxtaposée (virgule)","4. Subordonnée (parce que)","5. Coordonnée (mais)","6. Subordonnée (que)","7. Juxtaposée (virgules)"]},
            {titre:"Rédigez un paragraphe explicatif final",type:"production",tag:"EVAL",
              consigne:"Rédigez un paragraphe explicatif de 6 à 8 phrases sur le sujet : « Pourquoi l'artisanat est-il important pour Madagascar ? ». Utilisez au moins 3 connecteurs logiques et 2 connecteurs spatiaux.",
              lignes:8,
              corrige:"Réponses libres. Vérifier : structure (idée principale + arguments + exemple), au moins 3 connecteurs logiques, au moins 2 connecteurs spatiaux, lexique de l'artisanat, cohérence et correction."}
          ],
          exos:[
            {q:"Que signifie « Vannerie » ?",o:["Art de tresser des fibres végétales","Art de modeler l'argile","Art de décorer un tissu","Art de tailler la pierre"],c:0,e:"La vannerie est l'art de tresser des fibres végétales."},
            {q:"Quel est le problème principal de l'artisanat ?",o:["Trop de clients","Concurrence des produits industriels","Trop de matières premières","Trop d'employés"],c:1,e:"La concurrence des produits industriels."},
            {q:"Quel connecteur logique exprime la conséquence ?",o:["D'abord","Ensuite","Donc","Enfin"],c:2,e:"« Donc » exprime la conséquence."},
            {q:"Quelle phrase est subordonnée ?",o:["Les artisans travaillent dur et ils espèrent réussir","Je pense que l'artisanat doit être soutenu","Les produits sont beaux, les clients sont satisfaits","L'artisanat est une richesse"],c:1,e:"« Que » introduit une subordonnée."}
          ]},
        {code:'S5',titre:'Synthèse finale',desc:"Révision générale et auto-évaluation du thème",objectif:'Consolider tous les acquis du thème',
          lecon:{intro:"Cette dernière semaine est consacrée à la synthèse générale du thème de l'artisanat. Nous révisons l'ensemble des acquis : le lexique, les problèmes et leurs conséquences, les connecteurs logiques et spatiaux, les types de phrases, la voix passive et active, et la production écrite.",
            points:["Le lexique de l'artisanat : formes, outils, matériaux, problèmes","Les problèmes : concurrence, ressources, débouchés, savoir-faire","Les connecteurs logiques : d'abord, ensuite, enfin, parce que, donc, mais, car","Les connecteurs spatiaux : devant, derrière, à côté de, près de, sur, dans","Les types de phrases : simple, juxtaposée, coordonnée, subordonnée","La voix passive et active","La structure du texte explicatif"],
            ms:"Révision globale de toutes les notions du thème.",
            lex:["Vannerie, poterie, broderie, tissage, sculpture, fonte","Concurrence, ressources, débouchés, savoir-faire","Connecteurs logiques et spatiaux"]},
          exosOuverts:[
            {titre:"Rédigez une synthèse finale sur l'artisanat",type:"production",tag:"EVAL",
              consigne:"Rédigez un texte complet (introduction + développement + conclusion) sur l'artisanat malgache. Mobilisez tout le lexique appris, les connecteurs logiques et spatiaux, et variez la structure des phrases.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : présence des 3 parties, lexique riche, connecteurs variés, types de phrases variés, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle est la spécialité artisanale des hautes terres de Madagascar ?",o:["La poterie","La vannerie","La fonte","La sculpture"],c:1,e:"La vannerie est très développée dans les hautes terres."},
            {q:"Quel est le problème principal de l'artisanat malgache ?",o:["Trop de clients","Concurrence des produits industriels","Trop de matières premières","Trop d'employés"],c:1,e:"La concurrence des produits industriels."},
            {q:"Que signifie « savoir-faire » ?",o:["Connaissance théorique","Compétence technique","Diplôme universitaire","Salaire élevé"],c:1,e:"Le savoir-faire est une compétence technique."},
            {q:"Quel connecteur logique exprime la cause ?",o:["Mais","Donc","Parce que","Ensuite"],c:2,e:"« Parce que » exprime la cause."},
            {q:"Quelle est la structure du texte explicatif ?",o:["Titre – Chapeau – Développement – Conclusion","Introduction – Développement – Conclusion","Situation initiale – Péripéties – Dénouement","En-tête – Corps – Signature"],c:1,e:"Introduction, développement, conclusion."}
          ]}
      ],
      texte:{titre:"L'artisanat malgache : une richesse à protéger",
        contenu:[
          "L'artisanat malgache est riche et varié. Il comprend la vannerie, la poterie, la broderie, le tissage en raphia, le taillage et le polissage, la sculpture et la fonte. Chaque région de Madagascar possède ses propres spécialités. Par exemple, la vannerie est très développée dans les hautes terres, tandis que la poterie est plus présente dans le sud.",
          "Cependant, les artisans malgaches rencontrent de nombreux problèmes. D'abord, ils font face à une concurrence accrue des produits industriels, souvent moins chers. Ensuite, ils manquent de ressources pour acheter des matières premières de qualité. Enfin, ils ont du mal à promouvoir leur travail et à trouver des débouchés.",
          "Malgré ces difficultés, l'artisanat reste une activité importante pour l'économie malgache. Il permet de préserver des savoir-faire traditionnels et de créer des emplois."
        ]},
      questions:[
        {q:"Quelles sont les différentes formes d'artisanat citées dans le texte ?",o:["Vannerie, poterie, broderie, tissage, sculpture, fonte","Peinture, dessin, musique","Cuisine, jardinage","Sport, danse"],c:0,e:"Le texte cite : vannerie, poterie, broderie, tissage en raphia, taillage et polissage, sculpture et fonte."},
        {q:"Quelle est la spécialité artisanale des hautes terres de Madagascar ?",o:["La poterie","La vannerie","La fonte","La sculpture"],c:1,e:"« La vannerie est très développée dans les hautes terres »."},
        {q:"Pourquoi les artisans malgaches font-ils face à une concurrence accrue ?",o:["Les produits industriels sont moins chers","Les produits artisanaux sont trop beaux","Il y a trop de clients","Les artisans refusent de travailler"],c:0,e:"« une concurrence accrue des produits industriels, souvent moins chers »."},
        {q:"De quoi les artisans manquent-ils pour acheter des matières premières de qualité ?",o:["De clients","De ressources","D'outils","De temps"],c:1,e:"« ils manquent de ressources pour acheter des matières premières de qualité »."},
        {q:"Quels sont les deux avantages de l'artisanat pour l'économie malgache ?",o:["Préserver les savoir-faire et créer des emplois","Augmenter les impôts et réduire les salaires","Importer et exporter","Réduire les coûts"],c:0,e:"« préserver des savoir-faire traditionnels et de créer des emplois »."}
      ],
      lecon:{intro:"Le reportage est un texte explicatif qui informe sur un sujet en présentant des faits observés.",
        structure:[{t:'Le titre',d:"Annonce le sujet du reportage."},{t:'Le chapeau',d:"Résume l'essentiel : où, quand, qui, quoi, comment."},{t:'Le développement',d:"Présente les informations : description, témoignages, chiffres."},{t:'La conclusion',d:"Fait la synthèse et ouvre sur une perspective."}],
        ex:"Dans les ateliers d'Antananarivo, les artisans potiers perpétuent un savoir-faire transmis de génération en génération.",
        ms:"Les connecteurs spatiaux situent les lieux et objets : là-bas, devant, derrière, à côté de, près de, loin de, au-dessus, entre…"},
      lexique:["Les formes d'artisanat : poterie, bijouterie, couture, menuiserie, verrerie","Les outils et matériaux : tissus, bois, céramique, pierres précieuses","L'avenir de l'artisanat à Madagascar"],
      ms:["Les connecteurs spatiaux : là-bas, devant, derrière, à côté de, près de…"],
      exos:[
        {q:"Quelle est la structure correcte d'un reportage ?",o:["Titre – Chapeau – Développement – Conclusion","Introduction – Pied – Corps – Fin","Titre – Corps – Signature","Chapeau – Titre – Conclusion"],c:0,e:"Titre, chapeau, développement, conclusion."},
        {q:"Quel connecteur spatial indique la proximité ?",o:["Loin de","Près de","Au-dessus","Parmi"],c:1,e:"« Près de »."},
        {q:"Quelle est la fonction du chapeau ?",o:["Décrire les détails techniques","Résumer l'essentiel","Donner l'opinion du journaliste","Conclure"],c:1,e:"Résumer l'essentiel."},
        {q:"Laquelle utilise un connecteur spatial ?",o:["Il travaille ensuite.","Il travaille à côté du four.","Il travaille parce qu'il aime.","Il travaille mais fatigué."],c:1,e:"« À côté de »."},
        {q:"Objectif principal d'un reportage ?",o:["Convaincre d'acheter","Raconter une fiction","Informer objectivement","Critiquer"],c:2,e:"Informer objectivement."}
      ]},
    /* THÈME 1.2 : LES PAYS */
    {id:'pays',titre:"Les Pays",desc:"Guide de voyage sur les pays du monde",type:'Explicatif : guide de voyage',v:'Maîtrise de soi, autonomie',
      semaines:[
        {code:'S1',titre:'Découverte et Compréhension',desc:"Découvrir les textes de base sur les pays et le lexique des capitales",objectif:'Compréhension globale des textes',
          lecon:{intro:"La France est un pays situé en Europe de l'Ouest. Elle compte environ 68 millions d'habitants et sa capitale est Paris. La France est bordée par l'océan Atlantique à l'ouest, la mer Méditerranée au sud et les Alpes à l'est. Elle partage ses frontières avec la Belgique, le Luxembourg, l'Allemagne, la Suisse, l'Italie et l'Espagne. La France est célèbre pour son patrimoine culturel exceptionnel : la tour Eiffel, le château de Versailles et la cathédrale Notre-Dame de Paris. Sa gastronomie (fromage, vin, baguette) est mondialement reconnue. Le Japon est un pays insulaire d'Asie de l'Est composé de plus de 6 800 îles. Sa capitale est Tokyo. Le pays mêle tradition (temples, sanctuaires) et modernité (mangas, animés). Madagascar est une grande île de l'océan Indien, célèbre pour sa biodiversité unique (lémuriens, baobabs). Le Brésil est le plus grand pays d'Amérique du Sud, connu pour l'Amazonie, le carnaval et la statue du Christ Rédempteur.",
            points:["La France : Paris, 68 millions d'habitants, patrimoine et gastronomie","Le Japon : Tokyo, 6 800 îles, tradition et modernité","Madagascar : Antananarivo, 28 millions d'habitants, biodiversité unique","Le Brésil : Brasilia, 215 millions d'habitants, Amazonie et carnaval","Les capitales : Paris, Tokyo, Antananarivo, Brasilia, Rome, Madrid, Pékin","Les indicateurs chronologiques : d'abord, ensuite, puis, enfin"],
            ms:"Le présent de l'indicatif est utilisé pour décrire les pays. Les indicateurs chronologiques organisent les informations dans le temps : d'abord, ensuite, puis, enfin, finalement.",
            lex:["Pays, capitale, habitants, frontière","Patrimoine, monument, gastronomie, culture","Biodiversité, lémuriens, baobabs, ethnies","Tourisme, destination, spécificités"]},
          exosOuverts:[
            {titre:"Associez chaque pays à sa capitale",type:"tableau",tag:"LEXIQUE",
              consigne:"Reliez chaque pays de la colonne A à sa capitale dans la colonne B.",
              entetes:["N°","Colonne A (Pays)","Colonne B (Capitale)","Réponse"],
              lignes:[
                ["1","La France","A. Antananarivo",""],
                ["2","Le Japon","B. Paris",""],
                ["3","Madagascar","C. Brasilia",""],
                ["4","Le Brésil","D. Tokyo",""],
                ["5","L'Italie","E. Rome",""],
                ["6","L'Espagne","F. Madrid",""],
                ["7","La Chine","G. Pékin",""]
              ],
              corrige:["1 → B (Paris)","2 → D (Tokyo)","3 → A (Antananarivo)","4 → C (Brasilia)","5 → E (Rome)","6 → F (Madrid)","7 → G (Pékin)"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : drapeau, monument, gastronomie, culture, tourisme, patrimoine, capitale.",
              phrases:[
                "Le ___ français est bleu, blanc et rouge. (drapeau)",
                "La tour Eiffel est un ___ célèbre de Paris. (monument)",
                "La ___ japonaise est appréciée dans le monde entier. (gastronomie)",
                "Chaque pays possède sa propre ___ et ses traditions. (culture)",
                "Le ___ est une activité importante pour l'économie de nombreux pays. (tourisme)",
                "L'UNESCO protège le ___ mondial. (patrimoine)",
                "Tokyo est la ___ du Japon. (capitale)"
              ]},
            {titre:"Complétez avec l'indicateur chronologique qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec l'indicateur chronologique approprié choisi parmi : d'abord, ensuite, puis, enfin, finalement, après, tout d'abord.",
              phrases:[
                "___, la France possède de nombreux monuments historiques. (D'abord)",
                "___, elle est reconnue pour sa gastronomie. (Ensuite)",
                "___, ses paysages variés attirent les touristes. (Puis)",
                "___, sa culture fascine le monde entier. (Enfin)",
                "___, la France reste l'une des destinations les plus visitées. (Finalement)",
                "___ la visite des monuments, on découvre les musées. (Après)",
                "___ toutes ces richesses, la France mérite d'être visitée. (Tout d'abord)"
              ]},
            {titre:"Rédigez un court texte pour présenter un pays",type:"production",tag:"SYNTAXE",
              consigne:"Choisissez un pays parmi la France, le Japon, Madagascar ou le Brésil. Rédigez un court texte de 4 à 5 phrases pour le présenter. Utilisez au moins 3 indicateurs chronologiques (d'abord, ensuite, puis, enfin...).",
              lignes:5,
              exemple:"Madagascar est une grande île de l'océan Indien. D'abord, elle possède une biodiversité unique au monde avec les lémuriens et les baobabs. Ensuite, ses paysages sont variés : hautes terres, côtes tropicales et forêts humides. Puis, sa culture riche compte 18 ethnies et de nombreuses traditions. Enfin, son artisanat et sa gastronomie à base de riz font sa renommée.",
              corrige:"Réponses libres. Vérifier : choix d'un pays, présence d'au moins 3 indicateurs chronologiques, cohérence du texte (4 à 5 phrases), mobilisation du lexique des pays."}
          ],
          exos:[
            {q:"Où se situe la France ?",o:["En Europe de l'Ouest","En Asie","En Afrique","En Amérique"],c:0,e:"La France est en Europe de l'Ouest."},
            {q:"Quelle est la capitale du Japon ?",o:["Kyoto","Tokyo","Osaka","Hiroshima"],c:1,e:"Tokyo est la capitale du Japon."},
            {q:"Quelle est la capitale de Madagascar ?",o:["Toamasina","Antananarivo","Fianarantsoa","Mahajanga"],c:1,e:"Antananarivo."},
            {q:"Quel pays abrite l'Amazonie ?",o:["Le Brésil","Le Japon","La France","Madagascar"],c:0,e:"L'Amazonie se trouve au Brésil."},
            {q:"Quel indicateur chronologique marque le début d'une énumération ?",o:["Enfin","D'abord","Après","Finalement"],c:1,e:"« D'abord » commence une énumération."}
          ]},
        {code:'S2',titre:'Approfondissement Lexical',desc:"Approfondir le lexique des pays et des spécificités culturelles",objectif:'Maîtriser le lexique des pays et voyages',
          lecon:{intro:"Chaque pays possède des spécificités qui le rendent unique : sa capitale, ses habitants, sa frontière, son patrimoine, sa gastronomie, ses monuments et ses paysages. La France est bordée par l'océan Atlantique et partage une frontière avec six pays européens. Tokyo est la capitale du Japon et compte plus de 37 millions d'habitants. Madagascar compte environ 28 millions d'habitants et 18 ethnies. Le Brésil est connu pour sa gastronomie vibrante : la samba et la feijoada. Les monuments historiques français (tour Eiffel, château de Versailles) attirent des millions de touristes. Le Japon possède des paysages naturels variés : cerisiers en fleurs, mont Fuji et sources thermales.",
            points:["La capitale est la ville principale d'un pays","Les habitants désignent la population d'un pays","La frontière sépare deux pays","Le patrimoine est l'ensemble des biens culturels","La gastronomie est la cuisine typique d'un pays","Les monuments sont des édifices remarquables","Les paysages sont les aspects naturels d'un pays"],
            ms:"Les indicateurs chronologiques organisent un texte explicatif. Ils peuvent être placés en début de phrase ou en milieu de phrase.",
            lex:["Capitale, habitants, frontière, patrimoine","Gastronomie, monuments, paysages, tourisme","Biodiversité, lémuriens, baobabs, ethnies"]},
          exosOuverts:[
            {titre:"Associez chaque pays à sa capitale",type:"tableau",tag:"LEXIQUE",
              consigne:"Reliez chaque pays de la colonne A à sa capitale dans la colonne B.",
              entetes:["N°","Colonne A (Pays)","Colonne B (Capitale)","Réponse"],
              lignes:[
                ["1","La France","A. Antananarivo",""],
                ["2","Le Japon","B. Paris",""],
                ["3","Madagascar","C. Brasilia",""],
                ["4","Le Brésil","D. Tokyo",""],
                ["5","L'Italie","E. Rome",""],
                ["6","L'Espagne","F. Madrid",""],
                ["7","La Chine","G. Pékin",""]
              ],
              corrige:["1 → B","2 → D","3 → A","4 → C","5 → E","6 → F","7 → G"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : capitale, habitants, frontière, patrimoine, gastronomie, monuments, paysages.",
              phrases:[
                "La France est bordée par l'océan Atlantique et partage une ___ avec six pays européens. (frontière)",
                "Tokyo est la ___ du Japon et compte plus de 37 millions d'habitants. (capitale)",
                "Madagascar compte environ 28 millions d'___. (habitants)",
                "La France est célèbre pour son ___ culturel exceptionnel. (patrimoine)",
                "Le Brésil est connu pour sa ___ vibrante : la samba et la feijoada. (gastronomie)",
                "La tour Eiffel et le château de Versailles sont des ___ historiques français. (monuments)",
                "Le Japon possède des ___ naturels variés : cerisiers en fleurs, mont Fuji et sources thermales. (paysages)"
              ]},
            {titre:"Reconstituez le texte à l'aide des indicateurs chronologiques",type:"transformation",tag:"SYNTAXE",
              consigne:"Les phrases du texte ci-dessous ont été mélangées. En vous aidant des indicateurs chronologiques (d'abord, ensuite, puis, enfin), remettez-les dans le bon ordre.",
              phrases:[
                "A. Enfin, son artisanat et sa gastronomie à base de riz font sa renommée dans le monde entier.",
                "B. Madagascar est une grande île de l'océan Indien riche en biodiversité.",
                "C. D'abord, elle possède des espèces uniques au monde comme les lémuriens et les baobabs.",
                "D. Puis, ses paysages variés attirent de nombreux visiteurs : hautes terres, côtes tropicales et forêts humides.",
                "E. Ensuite, sa culture riche compte 18 ethnies et de nombreuses traditions ancestrales."
              ],
              corrige:[
                "Ordre correct : B → C → E → D → A",
                "Texte reconstitué : Madagascar est une grande île de l'océan Indien riche en biodiversité. D'abord, elle possède des espèces uniques au monde comme les lémuriens et les baobabs. Ensuite, sa culture riche compte 18 ethnies et de nombreuses traditions ancestrales. Puis, ses paysages variés attirent de nombreux visiteurs : hautes terres, côtes tropicales et forêts humides. Enfin, son artisanat et sa gastronomie à base de riz font sa renommée dans le monde entier."
              ]},
            {titre:"Complétez le paragraphe avec les indicateurs chronologiques",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez le paragraphe suivant avec les indicateurs chronologiques : d'abord, ensuite, puis, enfin, finalement.",
              phrases:[
                "Madagascar est une île riche en biodiversité. ___, elle abrite des espèces uniques comme les lémuriens et les baobabs. (D'abord)",
                "___, ses paysages variés attirent les touristes : hautes terres, côtes tropicales et forêts humides. (Ensuite)",
                "___, sa culture compte 18 ethnies aux traditions ancestrales. (Puis)",
                "___, son artisanat et sa gastronomie font sa renommée. (Enfin)",
                "___, Madagascar reste une destination touristique de plus en plus prisée. (Finalement)"
              ]},
            {titre:"Rédigez un court paragraphe avec des indicateurs chronologiques",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un court paragraphe explicatif de 4 à 5 phrases pour présenter Madagascar et ses spécificités (biodiversité, paysages, culture, artisanat, gastronomie). Utilisez au moins 3 indicateurs chronologiques.",
              lignes:5,
              exemple:"Madagascar est une grande île de l'océan Indien. D'abord, elle possède une biodiversité unique au monde avec les lémuriens et les baobabs. Ensuite, ses paysages sont variés : hautes terres, côtes tropicales et forêts humides. Puis, sa culture riche compte 18 ethnies et de nombreuses traditions comme le famadihana. Enfin, son artisanat et sa gastronomie à base de riz font sa renommée.",
              corrige:"Réponses libres. Vérifier : présence d'au moins 3 indicateurs chronologiques, cohérence du paragraphe (4 à 5 phrases), mobilisation du lexique de Madagascar."}
          ],
          exos:[
            {q:"Quelle est la capitale de la France ?",o:["Lyon","Paris","Marseille","Nice"],c:1,e:"Paris."},
            {q:"Combien d'ethnies compte Madagascar ?",o:["6","12","18","24"],c:2,e:"18 ethnies."},
            {q:"Quel indicateur chronologique marque la continuité ?",o:["Puis","Mais","Donc","Parce que"],c:0,e:"« Puis »."},
            {q:"Que signifie « patrimoine » ?",o:["Biens culturels d'un pays","Population d'un pays","Capitale d'un pays","Frontière d'un pays"],c:0,e:"Le patrimoine regroupe les biens culturels."},
            {q:"Quelle est la particularité du Japon ?",o:["Pays insulaire","Pays désertique","Pays d'Afrique","Pays d'Amérique"],c:0,e:"Le Japon est un pays insulaire."}
          ]},
        {code:'S3',titre:'Structuration et Production',desc:"Maîtriser la structure du guide de voyage et produire un texte complet",objectif:'Produire un texte explicatif complet',
          lecon:{intro:"Le guide de voyage est un texte explicatif qui présente un pays : sa présentation générale (situation géographique, capitale, population), son histoire et sa culture, son climat, ses sites à visiter et sa gastronomie. Pour enrichir sa production, il faut utiliser un lexique précis et varié, des indicateurs chronologiques (d'abord, ensuite, puis, enfin) et des connecteurs spatiaux (dans, sur, près de, au sud de). La voix passive permet de mettre en valeur l'action : Les lémuriens sont protégés par les parcs nationaux. Les phrases peuvent être simples, juxtaposées, coordonnées ou subordonnées.",
            points:["Structure du guide : présentation, histoire, culture, climat, sites, gastronomie","Enrichir ses phrases avec des synonymes précis","Utiliser les indicateurs chronologiques et les connecteurs spatiaux","Maîtriser les phrases simples, juxtaposées, coordonnées, subordonnées","Transformer les phrases actives en passives et vice-versa","Produire un texte explicatif complet sur un pays"],
            ms:"La voix passive se forme avec l'auxiliaire « être » + participe passé. Le COD de la phrase active devient sujet de la phrase passive. Les indicateurs chronologiques organisent les idées dans le temps.",
            lex:["Synonymes précis : vaste, immense, exceptionnel","Familles de mots : pays/paysage, touriste/tourisme","Connecteurs chronologiques et spatiaux","Phrases simples, juxtaposées, coordonnées, subordonnées"]},
          exosOuverts:[
            {titre:"Enrichissez vos phrases",type:"transformation",tag:"LEXIQUE",
              consigne:"Remplacez le mot souligné par un synonyme plus précis et plus expressif.",
              phrases:[
                "Madagascar est une île grande de l'océan Indien. → vaste / immense / gigantesque",
                "Sa biodiversité est importante. → exceptionnelle / remarquable / précieuse",
                "Les paysages malgaches sont beaux. → magnifiques / splendides / spectaculaires",
                "Le famadihana est une tradition intéressante. → fascinante / captivante / ancestrale",
                "L'artisanat malgache est bien connu dans le monde. → largement / mondialement / universellement",
                "La gastronomie malgache est bonne. → délicieuse / savoureuse / exquise",
                "Les lémuriens sont des animaux rares. → uniques / exceptionnels / endémiques"
              ],
              corrige:["1. vaste / immense / gigantesque","2. exceptionnelle / remarquable / précieuse","3. magnifiques / splendides / spectaculaires","4. fascinante / captivante / ancestrale","5. largement / mondialement / universellement","6. délicieuse / savoureuse / exquise","7. uniques / exceptionnels / endémiques"]},
            {titre:"Utilisez le lexique approprié",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : biodiversité, lémuriens, baobabs, ethnies, artisanat, gastronomie, tourisme, patrimoine.",
              phrases:[
                "Madagascar possède une ___ unique au monde. (biodiversité)",
                "Les ___ sont des primates endémiques de l'île. (lémuriens)",
                "L'Allée des ___ est un site emblématique de Madagascar. (baobabs)",
                "Le pays compte 18 ___ aux cultures riches et variées. (ethnies)",
                "L'___ malgache est renommé pour sa vannerie et sa broderie. (artisanat)",
                "La ___ malgache est à base de riz et de romazava. (gastronomie)",
                "Le ___ à Madagascar se développe de plus en plus grâce à ses sites naturels. (tourisme)"
              ]},
            {titre:"Transformez les phrases passives en actives et vice-versa",type:"transformation",tag:"SYNTAXE",
              consigne:"Réécrivez chaque phrase en changeant la voix (passive → active ou active → passive).",
              phrases:[
                "Les lémuriens sont protégés par les parcs nationaux. → Les parcs nationaux protègent les lémuriens.",
                "Les touristes visitent l'Allée des Baobabs. → L'Allée des Baobabs est visitée par les touristes.",
                "Le riz est cultivé par les paysans malgaches. → Les paysans malgaches cultivent le riz.",
                "Les artisans fabriquent des paniers en raphia. → Des paniers en raphia sont fabriqués par les artisans.",
                "Le famadihana est célébré par les familles malgaches. → Les familles malgaches célèbrent le famadihana.",
                "Les 18 ethnies composent la population malgache. → La population malgache est composée de 18 ethnies.",
                "Le romazava est préparé par les cuisiniers malgaches. → Les cuisiniers malgaches préparent le romazava."
              ],
              corrige:["1. Les parcs nationaux protègent les lémuriens.","2. L'Allée des Baobabs est visitée par les touristes.","3. Les paysans malgaches cultivent le riz.","4. Des paniers en raphia sont fabriqués par les artisans.","5. Les familles malgaches célèbrent le famadihana.","6. La population malgache est composée de 18 ethnies.","7. Les cuisiniers malgaches préparent le romazava."]},
            {titre:"Analysez la structure des phrases",type:"tableau",tag:"SYNTAXE",
              consigne:"Indiquez si chaque phrase est simple, juxtaposée, coordonnée ou subordonnée.",
              entetes:["N°","Phrase","Type"],
              lignes:[
                ["1","Madagascar est une île riche en biodiversité.","Simple"],
                ["2","Les lémuriens sont rares et ils sont protégés.","Coordonnée"],
                ["3","Les paysages sont variés, les touristes sont émerveillés.","Juxtaposée"],
                ["4","Parce que Madagascar est isolée, sa faune est unique.","Subordonnée"],
                ["5","L'artisanat malgache est précieux mais il est menacé.","Coordonnée"],
                ["6","Je pense que Madagascar mérite d'être visitée.","Subordonnée"],
                ["7","Les baobabs sont majestueux, ils impressionnent les visiteurs.","Juxtaposée"]
              ],
              corrige:["1. Simple","2. Coordonnée (et)","3. Juxtaposée (virgule)","4. Subordonnée (parce que)","5. Coordonnée (mais)","6. Subordonnée (que)","7. Juxtaposée (virgule)"]},
            {titre:"Rédigez un texte explicatif complet sur Madagascar",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un texte explicatif complet sur Madagascar. Structure : Introduction (présentation + problématique), Développement (biodiversité, paysages, culture, artisanat), Conclusion (synthèse + ouverture). Utilisez au moins 3 indicateurs chronologiques et 2 connecteurs spatiaux.",
              lignes:8,
              exemple:"Madagascar est une grande île de l'océan Indien, célèbre pour sa biodiversité exceptionnelle. Pourquoi cette île est-elle unique au monde ? D'abord, Madagascar abrite des espèces endémiques comme les lémuriens et les baobabs qui ne vivent nulle part ailleurs. Ensuite, dans les hautes terres centrales et sur les côtes tropicales, ses paysages variés attirent de nombreux visiteurs. Puis, sa culture riche compte 18 ethnies et des traditions ancestrales comme le famadihana. Enfin, son artisanat et sa gastronomie à base de riz et de romazava font sa renommée. Pour conclure, Madagascar mérite d'être protégée et valorisée pour les générations futures.",
              corrige:"Réponses libres. Vérifier : présence des 3 parties (introduction, développement, conclusion), au moins 3 indicateurs chronologiques, au moins 2 connecteurs spatiaux, mobilisation du lexique de Madagascar, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle phrase est juxtaposée ?",o:["Les baobabs sont majestueux, ils impressionnent","Les lémuriens sont rares et protégés","Parce que Madagascar est isolée, sa faune est unique","Madagascar est une île"],c:0,e:"La virgule est un signe de juxtaposition."},
            {q:"Quel est l'adjectif du nom « tourisme » ?",o:["Touristique","Touriste","Tourner","Tournée"],c:0,e:"« Touristique » est l'adjectif."},
            {q:"Quelle phrase est subordonnée ?",o:["Je pense que Madagascar mérite d'être visitée","Les lémuriens sont rares, ils sont protégés","Le famadihana est célébré","Madagascar est belle"],c:0,e:"« Que » introduit une subordonnée."}
          ]},
        {code:'S4',titre:'Évaluation et Consolidation',desc:"Évaluer les acquis lexicaux et syntaxiques sur les pays",objectif:'Évaluation des compétences',
          lecon:{intro:"Cette semaine est consacrée à l'évaluation et à la consolidation des acquis sur le thème des pays. Nous révisons le lexique (capitales, habitants, patrimoine, biodiversité), les indicateurs chronologiques, les transformations passives/actives, les phrases simples et complexes, et la reformulation.",
            points:["Révision du lexique des pays et de Madagascar","Révision des indicateurs chronologiques","Révision de la voix passive et active","Révision des phrases simples et complexes","Reformulation en phrases simples","Préparation à l'évaluation finale"],
            ms:"Révision globale : présent de l'indicatif, indicateurs chronologiques, voix passive/active, types de phrases.",
            lex:["Capitales, habitants, frontière, patrimoine","Biodiversité, lémuriens, baobabs, ethnies","Gastronomie, artisanat, tourisme, monuments"]},
          exosOuverts:[
            {titre:"Complétez la grille de mots croisés",type:"tableau",tag:"LEXIQUE",
              consigne:"Retrouvez le mot correspondant à chaque définition.",
              entetes:["N°","Définition","Mot à trouver"],
              lignes:[
                ["1","Capitale de Madagascar",""],
                ["2","Primates endémiques de Madagascar",""],
                ["3","Arbres emblématiques de l'Allée célèbre de Madagascar",""],
                ["4","Nombre d'ethnies à Madagascar",""],
                ["5","Plat malgache à base de riz et de romazava",""],
                ["6","Fête traditionnelle malgache en l'honneur des ancêtres",""],
                ["7","Forme d'artisanat malgache utilisant des fibres végétales",""]
              ],
              corrige:["1. Antananarivo","2. Lémuriens","3. Baobabs","4. 18 (dix-huit)","5. Romazava","6. Famadihana","7. Vannerie"]},
            {titre:"QCM – Choisissez la bonne réponse",type:"qcm-ouvert",tag:"LEXIQUE",
              consigne:"Entourez la bonne réponse.",
              questions:[
                {q:"Où se situe Madagascar ?",o:["Dans l'océan Atlantique","Dans l'océan Indien","Dans la mer Méditerranée","Dans l'océan Pacifique"],c:1},
                {q:"Quelle est la capitale de Madagascar ?",o:["Toamasina","Antananarivo","Antsirabe","Mahajanga"],c:1},
                {q:"Quel animal est endémique de Madagascar ?",o:["Le lion","Le lémurien","L'éléphant","Le kangourou"],c:1},
                {q:"Que signifie « biodiversité » ?",o:["La variété des espèces vivantes","La variété des climats","La variété des langues","La variété des paysages"],c:0},
                {q:"Quel indicateur chronologique marque la fin d'une énumération ?",o:["D'abord","Ensuite","Enfin","Puis"],c:2},
                {q:"Quel site touristique est célèbre à Madagascar ?",o:["La tour Eiffel","L'Allée des Baobabs","Le Colisée","Le Taj Mahal"],c:1}
              ],
              corrige:["1. b) Dans l'océan Indien","2. b) Antananarivo","3. b) Le lémurien","4. a) La variété des espèces vivantes","5. c) Enfin","6. b) Coutume","7. b) L'Allée des Baobabs"]},
            {titre:"Complétez avec l'indicateur chronologique qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec l'indicateur chronologique approprié choisi parmi : d'abord, ensuite, puis, enfin, finalement, tout d'abord, après.",
              phrases:[
                "___, Madagascar est une île de l'océan Indien. (Tout d'abord)",
                "___, elle possède une biodiversité unique au monde. (D'abord)",
                "___, ses paysages variés attirent de nombreux visiteurs. (Ensuite)",
                "___, sa culture compte 18 ethnies aux traditions ancestrales. (Puis)",
                "___, son artisanat et sa gastronomie font sa renommée. (Enfin)",
                "___, le tourisme se développe dans le pays. (Après)",
                "___, toutes ces richesses, Madagascar mérite d'être protégée. (Finalement)"
              ]},
            {titre:"Transformez les phrases passives en actives et vice-versa",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase active en phrase passive (ou inversement). Les verbes utilisés appartiennent aux 2e et 3e groupes.",
              phrases:[
                "Les parcs nationaux protègent les lémuriens. → Les lémuriens sont protégés par les parcs nationaux.",
                "Le riz est produit par les paysans malgaches. → Les paysans malgaches produisent le riz.",
                "Les artisans finissent leurs paniers en raphia avant la saison des pluies. → Les paniers en raphia sont finis par les artisans avant la saison des pluies.",
                "Le famadihana est célébré par les familles malgaches. → Les familles malgaches célèbrent le famadihana.",
                "Les 18 ethnies composent la population malgache. → La population malgache est composée de 18 ethnies.",
                "Le romazava est préparé par les cuisiniers malgaches. → Les cuisiniers malgaches préparent le romazava.",
                "Les touristes apprécient les paysages malgaches. → Les paysages malgaches sont appréciés par les touristes."
              ],
              corrige:["1. Les lémuriens sont protégés par les parcs nationaux.","2. Les paysans malgaches produisent le riz.","3. Les paniers en raphia sont finis par les artisans avant la saison des pluies.","4. Les familles malgaches célèbrent le famadihana.","5. La population malgache est composée de 18 ethnies.","6. Les cuisiniers malgaches préparent le romazava.","7. Les paysages malgaches sont appréciés par les touristes."]},
            {titre:"Reformulez les phrases complexes en phrases simples",type:"transformation",tag:"SYNTAXE",
              consigne:"Chaque phrase ci-dessous contient plusieurs propositions. Reformulez-la en plusieurs phrases simples (une seule proposition par phrase, un seul verbe conjugué).",
              phrases:[
                "Les paysages sont variés, les touristes sont émerveillés. → Les paysages sont variés. Les touristes sont émerveillés.",
                "Parce que Madagascar est isolée, sa faune est unique. → Madagascar est isolée. Sa faune est unique.",
                "L'artisanat malgache est précieux mais il est menacé. → L'artisanat malgache est précieux. Il est menacé.",
                "Je pense que Madagascar mérite d'être visitée. → Madagascar mérite d'être visitée.",
                "Les baobabs sont majestueux, ils impressionnent les visiteurs. → Les baobabs sont majestueux. Ils impressionnent les visiteurs.",
                "Le famadihana est une tradition ancienne et les Malgaches la respectent. → Le famadihana est une tradition ancienne. Les Malgaches la respectent.",
                "Quand la saison des pluies arrive, les routes deviennent difficiles. → La saison des pluies arrive. Les routes deviennent difficiles."
              ],
              corrige:["1. Les paysages sont variés. Les touristes sont émerveillés.","2. Madagascar est isolée. Sa faune est unique.","3. L'artisanat malgache est précieux. Il est menacé.","4. Madagascar mérite d'être visitée.","5. Les baobabs sont majestueux. Ils impressionnent les visiteurs.","6. Le famadihana est une tradition ancienne. Les Malgaches la respectent.","7. La saison des pluies arrive. Les routes deviennent difficiles."]},
            {titre:"Rédigez un paragraphe explicatif final",type:"production",tag:"EVAL",
              consigne:"Rédigez un paragraphe explicatif de 6 à 8 phrases sur le sujet : « Pourquoi Madagascar est-elle une destination touristique unique ? ». Utilisez au moins 3 indicateurs chronologiques et 2 connecteurs spatiaux.",
              lignes:8,
              corrige:"Réponses libres. Vérifier : structure (idée principale + arguments + exemple), au moins 3 indicateurs chronologiques, au moins 2 connecteurs spatiaux, lexique de Madagascar, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle est la capitale de Madagascar ?",o:["Antananarivo","Toamasina","Antsirabe","Mahajanga"],c:0,e:"Antananarivo."},
            {q:"Où se situe Madagascar ?",o:["Océan Indien","Océan Atlantique","Mer Méditerranée","Océan Pacifique"],c:0,e:"Dans l'océan Indien."},
            {q:"Quel indicateur marque la fin d'une énumération ?",o:["D'abord","Ensuite","Enfin","Puis"],c:2,e:"« Enfin »."},
            {q:"Quel animal est endémique de Madagascar ?",o:["Le lion","Le lémurien","L'éléphant","Le kangourou"],c:1,e:"Le lémurien."}
          ]},
        {code:'S5',titre:'Synthèse finale',desc:"Révision générale et auto-évaluation du thème",objectif:'Consolider tous les acquis du thème',
          lecon:{intro:"Cette dernière semaine est consacrée à la synthèse générale du thème des pays. Nous révisons l'ensemble des acquis : le lexique des pays et des capitales, les spécificités culturelles, les indicateurs chronologiques, les transformations passives/actives, les types de phrases, la reformulation et la production écrite. L'objectif est de consolider les connaissances et de préparer l'évaluation finale.",
            points:["Le lexique des pays : capitales, habitants, patrimoine, biodiversité","Les spécificités culturelles : monuments, gastronomie, paysages","Les indicateurs chronologiques : d'abord, ensuite, puis, enfin, finalement","La voix passive et active","Les types de phrases : simple, juxtaposée, coordonnée, subordonnée","La reformulation en phrases simples","La structure du guide de voyage"],
            ms:"Révision globale de toutes les notions du thème : présent de l'indicatif, indicateurs chronologiques, voix passive/active, types de phrases, reformulation.",
            lex:["Capitales : Paris, Tokyo, Antananarivo, Brasilia, Rome, Madrid, Pékin","Patrimoine, monuments, gastronomie, biodiversité","Indicateurs chronologiques : d'abord, ensuite, puis, enfin"]},
          exosOuverts:[
            {titre:"Rédigez une synthèse finale sur un pays",type:"production",tag:"EVAL",
              consigne:"Rédigez un texte complet (introduction + développement + conclusion) sur un pays de votre choix parmi la France, le Japon, Madagascar ou le Brésil. Mobilisez tout le lexique appris, les indicateurs chronologiques et les connecteurs spatiaux. Variez la structure des phrases.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : présence des 3 parties, lexique riche, indicateurs chronologiques variés, connecteurs spatiaux, types de phrases variés, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle est la capitale du Japon ?",o:["Kyoto","Tokyo","Osaka","Hiroshima"],c:1,e:"Tokyo."},
            {q:"Quel pays abrite l'Amazonie ?",o:["Le Brésil","Le Japon","La France","Madagascar"],c:0,e:"L'Amazonie se trouve au Brésil."},
            {q:"Combien d'ethnies compte Madagascar ?",o:["6","12","18","24"],c:2,e:"18 ethnies."},
            {q:"Quel indicateur chronologique marque le début ?",o:["Enfin","D'abord","Après","Finalement"],c:1,e:"« D'abord »."},
            {q:"Quelle est la structure du guide de voyage ?",o:["Présentation, histoire, culture, climat, sites, gastronomie","Titre – Chapeau","Situation initiale – Péripéties","En-tête – Corps"],c:0,e:"Présentation, histoire, culture, climat, sites, gastronomie."}
          ]}
      ],
      texte:{titre:"Voyage à travers les pays du monde",
        contenu:[
          "La France est un pays situé en Europe de l'Ouest. Elle compte environ 68 millions d'habitants et sa capitale est Paris. La France est célèbre pour son patrimoine culturel exceptionnel (tour Eiffel, château de Versailles, cathédrale Notre-Dame) et pour sa gastronomie (fromage, vin, baguette).",
          "Le Japon est un pays insulaire d'Asie de l'Est composé de plus de 6 800 îles. Sa capitale est Tokyo. Le pays mêle tradition (temples, sanctuaires) et modernité (mangas, animés). Sa gastronomie (sushis, ramen) est appréciée dans le monde entier.",
          "Madagascar est une grande île de l'océan Indien, célèbre pour sa biodiversité unique (lémuriens, baobabs). Sa capitale est Antananarivo. Le pays compte 18 ethnies et des traditions ancestrales comme le famadihana. Son artisanat (vannerie, broderie) et sa gastronomie (riz, romazava) font sa renommée.",
          "Le Brésil est le plus grand pays d'Amérique du Sud, connu pour l'Amazonie, le carnaval de Rio et la statue du Christ Rédempteur. Sa capitale est Brasilia. Sa cuisine, avec la feijoada et le café, reflète la diversité culturelle du pays."
        ]},
      questions:[
        {q:"Où se situe la France et quelle est sa capitale ?",o:["En Europe de l'Ouest, Paris","En Asie, Tokyo","En Afrique, Antananarivo","En Amérique, Brasilia"],c:0,e:"La France est en Europe de l'Ouest, sa capitale est Paris."},
        {q:"Quelle est la capitale du Japon ?",o:["Kyoto","Tokyo","Osaka","Hiroshima"],c:1,e:"Tokyo."},
        {q:"Quel pays abrite l'Amazonie ?",o:["Le Brésil","Le Japon","La France","Madagascar"],c:0,e:"L'Amazonie se trouve au Brésil."},
        {q:"Combien d'ethnies compte Madagascar ?",o:["6","12","18","24"],c:2,e:"18 ethnies."},
        {q:"Quel indicateur chronologique marque la fin d'une énumération ?",o:["D'abord","Ensuite","Enfin","Puis"],c:2,e:"« Enfin »."}
      ],
      lecon:{intro:"Le guide de voyage est un texte explicatif qui présente un pays.",
        structure:[{t:'Présentation générale',d:"Situation géographique, capitale, population, langue."},{t:'Histoire et culture',d:"Événements marquants, traditions, festivals."},{t:'Climat',d:"Saisons, températures, meilleure période."},{t:'Sites à visiter',d:"Monuments, parcs, plages, musées."},{t:'Gastronomie',d:"Plats typiques, spécialités locales."}],
        ex:"Madagascar, la Grande Île, abrite une biodiversité unique au monde.",
        ms:"Les indicateurs chronologiques organisent les informations : d'abord, ensuite, puis, après, enfin…"},
      lexique:["Les noms des pays : Madagascar, Afrique du Sud, États-Unis, Argentine, Chine, France","Les pays les plus visités au monde","Les sept merveilles du monde et leurs pays"],
      ms:["Les indicateurs chronologiques : d'abord, ensuite, enfin…"],
      exos:[
        {q:"Objectif d'un guide de voyage ?",o:["Raconter une histoire","Informer sur un pays","Convaincre de ne pas voyager","Vendre des billets"],c:1,e:"Informer sur un pays."},
        {q:"Où se trouvent les jardins suspendus ?",o:["Égypte","Grèce","Irak","Turquie"],c:2,e:"En Irak."},
        {q:"Quel est un indicateur chronologique ?",o:["Près de","Derrière","Ensuite","À côté de"],c:2,e:"« Ensuite »."},
        {q:"Combien de merveilles du monde antique ?",o:["5","6","7","10"],c:2,e:"Sept."},
        {q:"Capitale de Madagascar ?",o:["Toamasina","Antananarivo","Fianarantsoa","Mahajanga"],c:1,e:"Antananarivo."}
      ]}
  ]},
  /* ============================================================
     PÉRIODE 2 : TEXTE NARRATIF
     ============================================================ */
  p2:{id:'p2',titre:'Texte Narratif',desc:'Récit de voyage',sem:8,c:'#f72585',cd:'#c41e6a',cb:'rgba(247,37,133,.1)',themes:[
    /* THÈME 2.1 : LE TOURISME */
    {id:'tourisme',titre:"Le Tourisme",desc:"Récit de voyage et schéma actanciel",type:'Narratif : récit de voyage',v:"Respect d'autrui, responsabilité",
      semaines:[
        {code:'S1',titre:'Découverte et Compréhension',desc:"Découvrir les récits de voyage et le lexique du tourisme",objectif:'Compréhension globale des récits',
          lecon:{intro:"Le récit de voyage est un texte narratif qui raconte une expérience vécue lors d'un déplacement. Le narrateur (le héros) partage ses découvertes, ses émotions et les obstacles rencontrés. Pour bien comprendre un récit de voyage, il faut identifier : le héros (le voyageur), son objectif (ce qu'il veut accomplir), l'opposant (ce qui l'empêche), l'adjuvant (ce qui l'aide) et le dénouement (la résolution). Les destinations touristiques de Madagascar sont nombreuses : Nosy Be (nord), l'île Sainte-Marie (est), le parc national de l'Isalo (sud), les Tsingy de Bemaraha (ouest) et l'Allée des Baobabs (ouest).",
            points:["Le récit de voyage raconte une expérience vécue","Il suit le schéma actanciel : héros, objectif, opposant, adjuvant, dénouement","Il décrit des lieux, des émotions et des rencontres","Le passé composé ou le présent de narration dominent","Les destinations malgaches : Nosy Be, Sainte-Marie, Isalo, Tsingy, Allée des Baobabs","Le lexique du tourisme : tourisme, voyage, destination, hébergement, excursion, guide"],
            ms:"Le présent de l'indicatif peut être utilisé comme présent de narration pour rendre le récit plus vivant. Les connecteurs logiques (d'abord, ensuite, puis, enfin) organisent les étapes du voyage.",
            lex:["Tourisme, voyage, destination, hébergement","Excursion, randonnée, plongée, guide","Nosy Be, Sainte-Marie, Isalo, Tsingy, Baobabs"]},
          exosOuverts:[
            {titre:"Associez chaque mot du tourisme à sa définition",type:"tableau",tag:"LEXIQUE",
              consigne:"Reliez chaque mot de la colonne A à sa définition dans la colonne B.",
              entetes:["N°","Colonne A (Mot)","Colonne B (Définition)","Réponse"],
              lignes:[
                ["1","Tourisme","A. Lieu où l'on séjourne pendant un voyage",""],
                ["2","Destination","B. Activité de voyager pour le plaisir",""],
                ["3","Hébergement","C. Endroit que l'on souhaite visiter",""],
                ["4","Excursion","D. Voyage organisé vers un lieu précis",""],
                ["5","Randonnée","E. Longue marche en pleine nature",""],
                ["6","Paysage","F. Vue d'ensemble d'un lieu naturel",""],
                ["7","Guide","G. Personne qui accompagne et renseigne les touristes",""]
              ],
              corrige:["1 → B","2 → C","3 → A","4 → D","5 → E","6 → F","7 → G"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : Nosy Be, Sainte-Marie, Isalo, Tsingy, lémuriens, baleines, baobabs.",
              phrases:[
                "___ est une île du nord de Madagascar, célèbre pour ses plages. (Nosy Be)",
                "L'île ___ est réputée pour l'observation des baleines à bosse. (Sainte-Marie)",
                "Le parc national de l'___ se trouve dans le sud de Madagascar. (Isalo)",
                "Les ___ de Bemaraha sont classés au patrimoine mondial de l'UNESCO. (Tsingy)",
                "Les ___ sont des primates endémiques de Madagascar. (lémuriens)",
                "Les ___ à bosse viennent dans les eaux de Sainte-Marie pour se reproduire. (baleines)",
                "L'Allée des ___ est un site touristique emblématique de l'ouest. (baobabs)"
              ]},
            {titre:"Complétez avec le connecteur logique qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec le connecteur approprié choisi parmi : d'abord, ensuite, puis, mais, donc, parce que, enfin.",
              phrases:[
                "___, j'ai décidé de partir à Nosy Be. (D'abord)",
                "___, j'ai pris le bus jusqu'à Antsiranana. (Ensuite)",
                "___, j'ai embarqué sur une pirogue pour rejoindre l'île. (Puis)",
                "J'ai voulu plonger, ___ la mer était agitée. (mais)",
                "Une tempête a éclaté, ___ nous avons reporté l'excursion. (donc)",
                "Nous avons marché longtemps ___ la chaleur était intense. (parce que)",
                "___, ce voyage restera inoubliable. (Enfin)"
              ]},
            {titre:"Rédigez un court récit de voyage",type:"production",tag:"SYNTAXE",
              consigne:"Choisissez une destination parmi Nosy Be, l'île Sainte-Marie, l'Isalo ou les Tsingy de Bemaraha. Rédigez un court récit de voyage de 4 à 5 phrases. Utilisez au moins 3 connecteurs logiques (d'abord, ensuite, puis, mais, donc, enfin...).",
              lignes:5,
              exemple:"L'année dernière, j'ai décidé de partir à la découverte de Nosy Be. D'abord, j'ai pris le bus jusqu'à Antsiranana, un trajet de deux jours. Ensuite, j'ai embarqué sur une pirogue pour rejoindre l'île. Puis, j'ai visité les plantations d'ylang-ylang et goûté aux plats locaux. Enfin, ce voyage restera inoubliable.",
              corrige:"Réponses libres. Vérifier : choix d'une destination, présence d'au moins 3 connecteurs logiques, cohérence du récit (4 à 5 phrases), mobilisation du lexique du tourisme."}
          ],
          exos:[
            {q:"Que signifie « itinéraire » ?",o:["Lieu d'hébergement","Chemin suivi pour aller d'un lieu à un autre","Type de transport","Prix du voyage"],c:1,e:"Un itinéraire est le chemin suivi."},
            {q:"Où se trouve l'Allée des Baobabs ?",o:["Dans l'est","Dans l'ouest","Dans le nord","Dans les hautes terres"],c:1,e:"Dans l'ouest."},
            {q:"Quel animal observe-t-on à l'île Sainte-Marie ?",o:["Le lémurien","Le caméléon","La baleine à bosse","Le fossa"],c:2,e:"La baleine à bosse."},
            {q:"Quel connecteur logique exprime la conséquence ?",o:["D'abord","Donc","Mais","Car"],c:1,e:"« Donc »."},
            {q:"Quel site touristique est classé au patrimoine mondial de l'UNESCO ?",o:["Nosy Be","Rova Manjakamiadana","Tsingy de Bemaraha","Allée des Baobabs"],c:2,e:"Tsingy de Bemaraha."}
          ]},
        {code:'S2',titre:'Approfondissement Lexical',desc:"Approfondir le lexique des destinations et du schéma actanciel",objectif:'Maîtriser le lexique du tourisme',
          lecon:{intro:"Chaque destination malgache possède des spécificités : Nosy Be (nord) est célèbre pour ses plages et ses plantations d'ylang-ylang ; l'île Sainte-Marie (est) est le lieu d'observation des baleines à bosse ; le parc national de l'Isalo (sud) offre des canyons et des piscines naturelles ; les Tsingy de Bemaraha (ouest) sont des formations calcaires classées au patrimoine mondial ; l'Allée des Baobabs (ouest) est célèbre pour ses arbres géants ; le parc de Ranomafana (est) abrite une forêt tropicale humide. Le schéma actanciel repose sur 5 éléments : le héros, l'objectif, l'opposant, l'adjuvant et le dénouement.",
            points:["Nosy Be : plages, ylang-ylang, plongée","Sainte-Marie : baleines à bosse, cimetière des pirates","Isalo : canyons, piscines naturelles, lémuriens","Tsingy : formations calcaires, patrimoine UNESCO","Baobabs : arbres géants, coucher de soleil","Ranomafana : forêt tropicale, biodiversité","Schéma actanciel : héros, objectif, opposant, adjuvant, dénouement"],
            ms:"Les connecteurs logiques organisent un récit de voyage. Ils expriment la chronologie (d'abord, ensuite, puis, enfin), la cause (parce que, car), la conséquence (donc) et l'opposition (mais).",
            lex:["Randonnée, plongée, excursion, hébergement","Itinéraire, guide, paysages, attraction touristique","Héros, objectif, opposant, adjuvant, dénouement"]},
          exosOuverts:[
            {titre:"Classez et justifiez : destinations et spécificités",type:"tableau",tag:"LEXIQUE",
              consigne:"Pour chaque destination, indiquez sa région et justifiez votre réponse en citant une spécificité (faune, flore, relief, activité touristique).",
              entetes:["N°","Destination","Région","Spécificité"],
              lignes:[
                ["1","Nosy Be","Nord",""],
                ["2","Île Sainte-Marie","Est",""],
                ["3","Parc national de l'Isalo","Sud",""],
                ["4","Tsingy de Bemaraha","Ouest",""],
                ["5","Allée des Baobabs","Ouest",""],
                ["6","Parc national de Ranomafana","Est",""],
                ["7","Rova Manjakamiadana","Hautes terres",""]
              ],
              corrige:["1 → Nord : plages de sable blanc, ylang-ylang, plongée","2 → Est : observation des baleines à bosse, cimetière des pirates","3 → Sud : canyons, piscines naturelles, paysages arides","4 → Ouest : formations calcaires acérées, patrimoine UNESCO","5 → Ouest : baobabs géants, coucher de soleil spectaculaire","6 → Est : forêt tropicale humide, lémuriens, biodiversité","7 → Hautes terres : palais royal, patrimoine historique d'Antananarivo"]},
            {titre:"Complétez et transformez les phrases",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : randonnée, plongée, excursion, hébergement, itinéraire, guide, paysages.",
              phrases:[
                "Dans le parc de l'Isalo, nous avons fait une longue ___ de trois jours. (randonnée)",
                "À Nosy Be, la ___ sous-marine permet d'admirer les fonds marins. (plongée)",
                "Une ___ en mer est organisée chaque matin pour observer les baleines. (excursion)",
                "Nous avons réservé notre ___ dans un petit hôtel au bord de la plage. (hébergement)",
                "Notre ___ de voyage comprenait Nosy Be, l'Isalo et les Tsingy. (itinéraire)",
                "Un ___ local nous a fait découvrir la faune et la flore du parc. (guide)",
                "Les ___ de Madagascar sont variés et spectaculaires. (paysages)"
              ]},
            {titre:"Reconstituez le texte et justifiez l'ordre des connecteurs",type:"transformation",tag:"SYNTAXE",
              consigne:"Les phrases du texte ci-dessous ont été mélangées. Remettez-les dans le bon ordre en vous aidant des connecteurs logiques, puis réécrivez le paragraphe reconstitué.",
              phrases:[
                "A. Enfin, ce voyage m'a appris à apprécier l'instant présent.",
                "B. Il y a deux ans, j'ai réalisé un rêve : visiter l'île Sainte-Marie.",
                "C. D'abord, j'ai pris un vol jusqu'à Toamasina, puis un bateau pour rejoindre l'île.",
                "D. Mais une tempête a failli annuler ma sortie en mer et j'ai perdu mon appareil photo.",
                "E. Ensuite, j'ai observé les baleines à bosse, un moment magique.",
                "F. Puis, j'ai visité le cimetière des pirates et les plantations de girofle."
              ],
              corrige:[
                "Ordre correct : B → C → E → F → D → A",
                "Texte reconstitué : Il y a deux ans, j'ai réalisé un rêve : visiter l'île Sainte-Marie. D'abord, j'ai pris un vol jusqu'à Toamasina, puis un bateau pour rejoindre l'île. Ensuite, j'ai observé les baleines à bosse, un moment magique. Puis, j'ai visité le cimetière des pirates et les plantations de girofle. Mais une tempête a failli annuler ma sortie en mer et j'ai perdu mon appareil photo. Enfin, ce voyage m'a appris à apprécier l'instant présent."
              ]},
            {titre:"Transformez les phrases avec les connecteurs logiques",type:"transformation",tag:"SYNTAXE",
              consigne:"Réécrivez chaque phrase en utilisant le connecteur logique indiqué entre parenthèses.",
              phrases:[
                "Nous avons visité Nosy Be. Nous avons découvert la réserve de Lokobe. (d'abord / ensuite)",
                "Une tempête a éclaté. Nous avons reporté notre excursion. (donc)",
                "Le voyage a été mouvementé. Il restera inoubliable. (mais)",
                "La saison des pluies était terminée. Le temps s'est calmé. (parce que)",
                "Nous avons observé les baleines. Nous avons pris beaucoup de photos. (puis)",
                "L'île Sainte-Marie est magnifique. Elle attire de nombreux touristes. (c'est pourquoi)",
                "Nous avons marché longtemps. La chaleur était intense. (car)"
              ],
              corrige:[
                "1. D'abord, nous avons visité Nosy Be. Ensuite, nous avons découvert la réserve de Lokobe.",
                "2. Une tempête a éclaté, donc nous avons reporté notre excursion.",
                "3. Le voyage a été mouvementé, mais il restera inoubliable.",
                "4. Le temps s'est calmé parce que la saison des pluies était terminée.",
                "5. Nous avons observé les baleines, puis nous avons pris beaucoup de photos.",
                "6. L'île Sainte-Marie est magnifique, c'est pourquoi elle attire de nombreux touristes.",
                "7. Nous avons marché longtemps car la chaleur était intense."
              ]},
            {titre:"Rédigez un paragraphe narratif enrichi",type:"production",tag:"SYNTAXE",
              consigne:"Choisissez une destination parmi Nosy Be, l'île Sainte-Marie, l'Isalo ou les Tsingy de Bemaraha. Rédigez un paragraphe narratif de 6 à 8 phrases. Utilisez au moins 4 connecteurs logiques différents, 1 connecteur de cause, 1 de conséquence, et 3 mots du lexique touristique.",
              lignes:8,
              exemple:"L'année dernière, j'ai décidé de partir à la découverte de Nosy Be, une île magnifique du nord de Madagascar. Mon objectif était clair : me reposer et explorer les fonds marins. D'abord, j'ai pris le bus jusqu'à Antsiranana, un trajet éprouvant de deux jours. Ensuite, j'ai embarqué sur une pirogue pour rejoindre l'île. Puis, j'ai fait de la plongée et découvert des poissons multicolores. Malheureusement, une tempête a éclaté et a retardé mon excursion vers les îles Mitsio. Heureusement, un pêcheur local m'a servi de guide et m'a fait découvrir des coins secrets. Enfin, grâce à sa gentillesse, j'ai pu observer des baleines à bosse. Ce voyage m'a appris que les plus belles rencontres naissent souvent des imprévus.",
              corrige:"Réponses libres. Vérifier : schéma actanciel complet, au moins 4 connecteurs logiques, 1 de cause, 1 de conséquence, 3 mots du lexique touristique, dimension réflexive (leçon de vie)."}
          ],
          exos:[
            {q:"Quelle est la spécificité de Nosy Be ?",o:["Les canyons","Les plages et l'ylang-ylang","Les baleines","Les Tsingy"],c:1,e:"Les plages et l'ylang-ylang."},
            {q:"Quel animal observe-t-on à Sainte-Marie ?",o:["Le lémurien","Le caméléon","La baleine à bosse","Le fossa"],c:2,e:"La baleine à bosse."},
            {q:"Que signifie « schéma actanciel » ?",o:["La structure d'un poème","Les éléments d'un récit","La liste des personnages","Les figures de style"],c:1,e:"Les éléments d'un récit."},
            {q:"Quel connecteur exprime la conséquence ?",o:["D'abord","Donc","Mais","Car"],c:1,e:"« Donc »."},
          ]},
        {code:'S3',titre:'Structuration et Production',desc:"Maîtriser la structure du récit et produire un texte complet",objectif:'Produire un récit de voyage complet',
          lecon:{intro:"Le récit de voyage suit la structure du schéma actanciel : situation initiale (héros + objectif), élément déclencheur (départ), péripéties (étapes, obstacles), dénouement (résolution), situation finale (leçon de vie). Pour enrichir un récit, il faut utiliser un lexique précis et varié, des connecteurs logiques et spatiaux, et varier la structure des phrases. La voix passive permet de mettre en valeur l'action : Les baleines sont observées par les touristes.",
            points:["Structure du récit : situation initiale, péripéties, dénouement","Schéma actanciel : héros, objectif, opposant, adjuvant, dénouement","Enrichir ses phrases avec des synonymes précis","Utiliser les connecteurs logiques et spatiaux","Maîtriser les phrases simples, juxtaposées, coordonnées, subordonnées","Transformer les phrases actives en passives et vice-versa","Produire un récit de voyage complet"],
            ms:"La voix passive se forme avec l'auxiliaire « être » + participe passé. Le COD de la phrase active devient sujet de la phrase passive.",
            lex:["Synonymes précis : vaste, magnifique, éprouvant","Familles de mots : touriste/tourisme, voyage/voyageur","Connecteurs logiques et spatiaux","Phrases simples, juxtaposées, coordonnées, subordonnées"]},
          exosOuverts:[
            {titre:"Enrichissez vos phrases",type:"transformation",tag:"LEXIQUE",
              consigne:"Remplacez le mot souligné par un synonyme plus précis et plus expressif.",
              phrases:[
                "Nosy Be est une île grande de l'océan Indien. → vaste / immense / gigantesque",
                "Les paysages de l'Isalo sont beaux. → magnifiques / spectaculaires / grandioses",
                "Le voyage à Sainte-Marie a été bien. → réussi / inoubliable / mémorable",
                "Les baleines à bosse sont des animaux rares. → exceptionnels / uniques / fascinants",
                "La randonnée dans les Tsingy a été difficile. → éprouvante / exigeante / ardue",
                "Les habitants de Nosy Be sont gentils avec les touristes. → accueillants / chaleureux / hospitaliers",
                "Le coucher de soleil sur l'Allée des Baobabs est impressionnant. → saisissant / époustouflant / féerique"
              ],
              corrige:["1. vaste / immense / gigantesque","2. magnifiques / spectaculaires / grandioses","3. réussi / inoubliable / mémorable","4. exceptionnels / uniques / fascinants","5. éprouvante / exigeante / ardue","6. accueillants / chaleureux / hospitaliers","7. saisissant / époustouflant / féerique"]},
            {titre:"Utilisez le lexique du schéma actanciel",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : héros, objectif, opposant, adjuvant, dénouement, quête, péripétie.",
              phrases:[
                "Dans mon récit de voyage, le ___ est le narrateur lui-même. (héros)",
                "Son ___ était de découvrir les baleines à bosse. (objectif)",
                "La tempête a joué le rôle d'___ en empêchant la sortie en mer. (opposant)",
                "Le guide local a été un précieux ___ pour le voyageur. (adjuvant)",
                "Chaque ___ du voyage a renforcé la détermination du héros. (péripétie)",
                "Le ___ du récit est marqué par le retour du voyageur chez lui. (dénouement)",
                "La ___ du héros était semée d'embûches mais pleine de découvertes. (quête)"
              ]},
            {titre:"Transformez les phrases passives en actives et vice-versa",type:"transformation",tag:"SYNTAXE",
              consigne:"Réécrivez chaque phrase en changeant la voix (passive → active ou active → passive).",
              phrases:[
                "Les baleines à bosse sont observées par les touristes à Sainte-Marie. → Les touristes observent les baleines à bosse à Sainte-Marie.",
                "Les guides locaux accompagnent les visiteurs dans le parc de l'Isalo. → Les visiteurs sont accompagnés par les guides locaux dans le parc de l'Isalo.",
                "Les Tsingy de Bemaraha sont classés au patrimoine mondial par l'UNESCO. → L'UNESCO a classé les Tsingy de Bemaraha au patrimoine mondial.",
                "Les artisans malgaches fabriquent des souvenirs pour les touristes. → Des souvenirs sont fabriqués par les artisans malgaches pour les touristes.",
                "Le coucher de soleil sur l'Allée des Baobabs est admiré par les photographes. → Les photographes admirent le coucher de soleil sur l'Allée des Baobabs.",
                "Les voyageurs découvrent la faune et la flore de Ranomafana. → La faune et la flore de Ranomafana sont découvertes par les voyageurs.",
                "Les traditions malgaches sont transmises par les anciens. → Les anciens transmettent les traditions malgaches."
              ],
              corrige:["1. Les touristes observent les baleines à bosse à Sainte-Marie.","2. Les visiteurs sont accompagnés par les guides locaux dans le parc de l'Isalo.","3. L'UNESCO a classé les Tsingy de Bemaraha au patrimoine mondial.","4. Des souvenirs sont fabriqués par les artisans malgaches pour les touristes.","5. Les photographes admirent le coucher de soleil sur l'Allée des Baobabs.","6. La faune et la flore de Ranomafana sont découvertes par les voyageurs.","7. Les anciens transmettent les traditions malgaches."]},
            {titre:"Analysez la structure des phrases",type:"tableau",tag:"SYNTAXE",
              consigne:"Indiquez si chaque phrase est simple, juxtaposée, coordonnée ou subordonnée.",
              entetes:["N°","Phrase","Type"],
              lignes:[
                ["1","Nosy Be est une île magnifique.","Simple"],
                ["2","Les baleines sont majestueuses et elles fascinent les visiteurs.","Coordonnée"],
                ["3","Les paysages sont variés, les touristes sont émerveillés.","Juxtaposée"],
                ["4","Parce que la saison des pluies était terminée, le temps s'est calmé.","Subordonnée"],
                ["5","Le voyage a été mouvementé mais il restera inoubliable.","Coordonnée"],
                ["6","Je pense que l'île Sainte-Marie mérite d'être visitée.","Subordonnée"],
                ["7","Les baobabs sont majestueux, ils impressionnent les voyageurs.","Juxtaposée"]
              ],
              corrige:["1. Simple","2. Coordonnée (et)","3. Juxtaposée (virgule)","4. Subordonnée (parce que)","5. Coordonnée (mais)","6. Subordonnée (que)","7. Juxtaposée (virgule)"]},
            {titre:"Rédigez un récit de voyage complet sur Madagascar",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un récit de voyage complet de 8 à 10 phrases. Respectez le schéma actanciel (héros, objectif, opposant, adjuvant, dénouement). Utilisez au moins 4 connecteurs logiques et 2 connecteurs spatiaux. Terminez par une leçon de vie.",
              lignes:10,
              exemple:"L'année dernière, j'ai réalisé un rêve : découvrir l'île Sainte-Marie, au nord-est de Madagascar. Mon objectif était d'observer les baleines à bosse. D'abord, j'ai pris un vol jusqu'à Toamasina, puis un bateau pour rejoindre l'île. Ensuite, j'ai embarqué sur une pirogue avec un pêcheur local. Puis, j'ai eu la chance d'apercevoir plusieurs baleines sauter près de notre embarcation. Mais une tempête a éclaté et j'ai perdu mon appareil photo. Heureusement, grâce à la gentillesse du pêcheur, j'ai pu garder des souvenirs gravés dans ma mémoire. Enfin, ce voyage m'a appris que les plus belles expériences ne se capturent pas avec un appareil, mais se vivent pleinement.",
              corrige:"Réponses libres. Vérifier : schéma actanciel complet, au moins 4 connecteurs logiques, 2 connecteurs spatiaux, lexique du tourisme, leçon de vie finale, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle phrase est juxtaposée ?",o:["Les baobabs sont majestueux, ils impressionnent","Les baleines sont rares et protégées","Parce qu'il pleut, je reste","Nosy Be est belle"],c:0,e:"La virgule est un signe de juxtaposition."},
            {q:"Quel est l'adjectif du nom « tourisme » ?",o:["Touristique","Touriste","Tourner","Tournée"],c:0,e:"« Touristique »."},
            {q:"Quelle phrase est subordonnée ?",o:["Je pense que Sainte-Marie mérite d'être visitée","Les baleines sont rares, elles sont protégées","Le voyage est fini","Nosy Be est belle"],c:0,e:"« Que » introduit une subordonnée."}
          ]},
        {code:'S4',titre:'Évaluation et Consolidation',desc:"Évaluer les acquis lexicaux et syntaxiques sur le tourisme",objectif:'Évaluation des compétences',
          lecon:{intro:"Cette semaine est consacrée à l'évaluation et à la consolidation des acquis sur le thème du tourisme. Nous révisons le lexique des destinations malgaches, les connecteurs logiques, les transformations passives/actives, les phrases simples et complexes, et la production écrite d'un récit de voyage.",
            points:["Révision du lexique du tourisme et des destinations","Révision des connecteurs logiques","Révision de la voix passive et active","Révision des phrases simples et complexes","Reformulation en phrases simples","Préparation à l'évaluation finale"],
            ms:"Révision globale : présent de narration, connecteurs logiques, voix passive/active, types de phrases.",
            lex:["Destinations : Nosy Be, Sainte-Marie, Isalo, Tsingy, Baobabs","Vocabulaire du tourisme : excursion, randonnée, plongée","Schéma actanciel : héros, objectif, opposant, adjuvant, dénouement"]},
          exosOuverts:[
            {titre:"Complétez la grille de mots croisés",type:"tableau",tag:"LEXIQUE",
              consigne:"Retrouvez le mot correspondant à chaque définition.",
              entetes:["N°","Définition","Mot à trouver"],
              lignes:[
                ["1","Île célèbre du nord de Madagascar, réputée pour ses plages",""],
                ["2","Île de l'est où l'on observe les baleines à bosse",""],
                ["3","Parc national du sud aux canyons spectaculaires",""],
                ["4","Formations calcaires classées au patrimoine mondial",""],
                ["5","Site de l'ouest célèbre pour ses baobabs géants",""],
                ["6","Personne qui accompagne et renseigne les touristes",""],
                ["7","Sortie organisée vers un site particulier",""]
              ],
              corrige:["1. Nosy Be","2. Île Sainte-Marie","3. Parc national de l'Isalo","4. Tsingy de Bemaraha","5. Allée des Baobabs","6. Guide","7. Excursion"]},
            {titre:"QCM – Choisissez la bonne réponse",type:"qcm-ouvert",tag:"LEXIQUE",
              consigne:"Entourez la bonne réponse.",
              questions:[
                {q:"Que signifie « itinéraire » ?",o:["Lieu d'hébergement","Chemin suivi pour aller d'un lieu à un autre","Type de transport","Prix du voyage"],c:1},
                {q:"Où se trouve l'Allée des Baobabs ?",o:["Dans l'est","Dans l'ouest","Dans le nord","Dans les hautes terres"],c:1},
                {q:"Quel animal observe-t-on à l'île Sainte-Marie ?",o:["Le lémurien","Le caméléon","La baleine à bosse","Le fossa"],c:2},
                {q:"Que signifie « schéma actanciel » ?",o:["La structure d'un poème","Les éléments d'un récit (héros, objectif, opposant…)","La liste des personnages","Les figures de style"],c:1},
                {q:"Quel connecteur logique exprime la conséquence ?",o:["D'abord","Donc","Mais","Car"],c:1},
                {q:"Quel site touristique est classé au patrimoine mondial de l'UNESCO à Madagascar ?",o:["Nosy Be","Rova Manjakamiadana","Tsingy de Bemaraha","Allée des Baobabs"],c:2}
              ],
              corrige:["1. b) Chemin suivi pour aller d'un lieu à un autre","2. b) Dans l'ouest","3. c) La baleine à bosse","4. b) Les éléments d'un récit","5. b) Donc","6. a) Panorama","7. c) Tsingy de Bemaraha"]},
            {titre:"Complétez avec le connecteur logique qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec le connecteur logique approprié choisi parmi : d'abord, ensuite, puis, mais, donc, car, enfin.",
              phrases:[
                "___, j'ai décidé de partir à Nosy Be. (D'abord)",
                "___, j'ai pris le bus jusqu'à Antsiranana. (Ensuite)",
                "___, j'ai embarqué sur une pirogue pour rejoindre l'île. (Puis)",
                "J'ai voulu plonger, ___ la mer était agitée. (mais)",
                "Une tempête a éclaté, ___ nous avons reporté l'excursion. (donc)",
                "Nous avons marché longtemps ___ la chaleur était intense. (car)",
                "___, ce voyage restera inoubliable. (Enfin)"
              ]},
            {titre:"Transformez selon le modèle",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase active en phrase passive (ou inversement).",
              phrases:[
                "Les guides accompagnent les visiteurs dans le parc. → Les visiteurs sont accompagnés par les guides dans le parc.",
                "Les baleines sont observées par les touristes à Sainte-Marie. → Les touristes observent les baleines à Sainte-Marie.",
                "Les artisans fabriquent des souvenirs pour les voyageurs. → Des souvenirs sont fabriqués par les artisans pour les voyageurs.",
                "Les Tsingy sont classés au patrimoine mondial par l'UNESCO. → L'UNESCO a classé les Tsingy au patrimoine mondial.",
                "Les photographes admirent le coucher de soleil. → Le coucher de soleil est admiré par les photographes.",
                "Les traditions malgaches sont transmises par les anciens. → Les anciens transmettent les traditions malgaches.",
                "Les voyageurs découvrent la faune de Ranomafana. → La faune de Ranomafana est découverte par les voyageurs."
              ],
              corrige:["1. Les visiteurs sont accompagnés par les guides dans le parc.","2. Les touristes observent les baleines à Sainte-Marie.","3. Des souvenirs sont fabriqués par les artisans pour les voyageurs.","4. L'UNESCO a classé les Tsingy au patrimoine mondial.","5. Le coucher de soleil est admiré par les photographes.","6. Les anciens transmettent les traditions malgaches.","7. La faune de Ranomafana est découverte par les voyageurs."]},
            {titre:"Reformulez les phrases complexes en phrases simples",type:"transformation",tag:"SYNTAXE",
              consigne:"Chaque phrase ci-dessous contient plusieurs propositions. Reformulez-la en plusieurs phrases simples.",
              phrases:[
                "Les paysages sont variés, les touristes sont émerveillés. → Les paysages sont variés. Les touristes sont émerveillés.",
                "Parce que la saison des pluies était terminée, le temps s'est calmé. → La saison des pluies était terminée. Le temps s'est calmé.",
                "Le voyage a été mouvementé mais il restera inoubliable. → Le voyage a été mouvementé. Il restera inoubliable.",
                "Je pense que l'île Sainte-Marie mérite d'être visitée. → L'île Sainte-Marie mérite d'être visitée.",
                "Les baobabs sont majestueux, ils impressionnent les voyageurs. → Les baobabs sont majestueux. Ils impressionnent les voyageurs.",
                "Le guide connaissait bien la région et il nous a fait découvrir des coins secrets. → Le guide connaissait bien la région. Il nous a fait découvrir des coins secrets.",
                "Quand la tempête est arrivée, nous avons dû annuler notre excursion. → La tempête est arrivée. Nous avons dû annuler notre excursion."
              ],
              corrige:["1. Les paysages sont variés. Les touristes sont émerveillés.","2. La saison des pluies était terminée. Le temps s'est calmé.","3. Le voyage a été mouvementé. Il restera inoubliable.","4. L'île Sainte-Marie mérite d'être visitée.","5. Les baobabs sont majestueux. Ils impressionnent les voyageurs.","6. Le guide connaissait bien la région. Il nous a fait découvrir des coins secrets.","7. La tempête est arrivée. Nous avons dû annuler notre excursion."]},
            {titre:"Rédigez un récit de voyage final",type:"production",tag:"EVAL",
              consigne:"Rédigez un récit de voyage de 8 à 10 phrases sur le sujet : « Un voyage inoubliable à Madagascar ». Respectez le schéma actanciel, utilisez au moins 4 connecteurs logiques et 2 connecteurs spatiaux.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : schéma actanciel complet, au moins 4 connecteurs logiques, 2 connecteurs spatiaux, lexique du tourisme, leçon de vie finale, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle est la spécificité de Nosy Be ?",o:["Les canyons","Les plages et l'ylang-ylang","Les baleines","Les Tsingy"],c:1,e:"Les plages et l'ylang-ylang."},
            {q:"Où observe-t-on les baleines à bosse ?",o:["Nosy Be","Île Sainte-Marie","Isalo","Tsingy"],c:1,e:"À l'île Sainte-Marie."},
            {q:"Que signifie « héros » dans un récit ?",o:["Le méchant","Le personnage principal","Le narrateur secondaire","L'objet"],c:1,e:"Le personnage principal."},
            {q:"Quel connecteur marque la fin d'une énumération ?",o:["D'abord","Ensuite","Enfin","Puis"],c:2,e:"« Enfin »."}
          ]},
        {code:'S5',titre:'Synthèse finale',desc:"Révision générale et auto-évaluation du thème",objectif:'Consolider tous les acquis du thème',
          lecon:{intro:"Cette dernière semaine est consacrée à la synthèse générale du thème du tourisme. Nous révisons l'ensemble des acquis : le lexique des destinations malgaches, le schéma actanciel, les connecteurs logiques, les types de phrases, la voix passive/active, la reformulation et la production écrite. L'objectif est de consolider les connaissances et de préparer l'évaluation finale.",
            points:["Le lexique du tourisme : voyage, destination, hébergement, excursion","Les destinations malgaches : Nosy Be, Sainte-Marie, Isalo, Tsingy, Baobabs","Le schéma actanciel : héros, objectif, opposant, adjuvant, dénouement","Les connecteurs logiques : d'abord, ensuite, puis, enfin, mais, donc, car","Les connecteurs spatiaux : dans, sur, près de, au nord de","La voix passive et active","Les types de phrases : simple, juxtaposée, coordonnée, subordonnée","La structure du récit de voyage"],
            ms:"Révision globale de toutes les notions du thème.",
            lex:["Tourisme, voyage, destination, hébergement, excursion","Nosy Be, Sainte-Marie, Isalo, Tsingy, Baobabs","Héros, objectif, opposant, adjuvant, dénouement"]},
          exosOuverts:[
            {titre:"Rédigez une synthèse finale sur le tourisme",type:"production",tag:"EVAL",
              consigne:"Rédigez un récit de voyage complet (situation initiale + péripéties + dénouement + situation finale) sur une destination malgache de votre choix. Mobilisez tout le lexique appris, les connecteurs logiques et spatiaux, et variez la structure des phrases.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : schéma actanciel complet, lexique riche, connecteurs variés, types de phrases variés, leçon de vie finale, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle est la spécificité de Sainte-Marie ?",o:["Les baobabs","Les baleines à bosse","Les canyons","Les Tsingy"],c:1,e:"Les baleines à bosse."},
            {q:"Quel animal est endémique de Madagascar ?",o:["Le lion","Le lémurien","L'éléphant","Le kangourou"],c:1,e:"Le lémurien."},
            {q:"Quel site est classé au patrimoine mondial de l'UNESCO ?",o:["Nosy Be","Isalo","Tsingy de Bemaraha","Sainte-Marie"],c:2,e:"Tsingy de Bemaraha."},
            {q:"Quel est l'objectif du héros dans un récit ?",o:["Ce qu'il veut accomplir","Ce qui l'empêche","Ce qui l'aide","Le dénouement"],c:0,e:"Ce qu'il veut accomplir."},
            {q:"Quelle est la structure du récit de voyage ?",o:["Situation initiale – Péripéties – Dénouement – Situation finale","Titre – Chapeau – Développement – Conclusion","Introduction – Thèse – Conclusion","En-tête – Corps – Signature"],c:0,e:"Schéma narratif classique."}
          ]}
      ],
      texte:{titre:"Voyages inoubliables à Madagascar",
        contenu:[
          "L'année dernière, j'ai décidé de découvrir Nosy Be, la célèbre île du nord de Madagascar. Mon objectif était de me reposer et d'explorer les merveilles naturelles de cette destination paradisiaque. J'ai été émerveillé par la beauté des plages de sable blanc et des eaux turquoise. Chaque matin, je me promenais le long de la mer, puis je découvrais les fonds marins en faisant de la plongée.",
          "Il y a deux ans, j'ai réalisé un rêve : visiter l'île Sainte-Marie, au nord-est de Madagascar. Mon but était d'observer les baleines à bosse, qui viennent chaque année dans ces eaux chaudes pour se reproduire. Pendant la traversée, j'ai rencontré un pêcheur expérimenté qui m'a raconté l'histoire des pirates. Arrivé à Sainte-Marie, j'ai loué une petite pirogue pour aller observer les baleines.",
          "L'année dernière, pendant les vacances de Pâques, j'ai décidé de partir à la découverte du parc national de l'Isalo, dans le sud de Madagascar. Mon ambition était de faire une randonnée de trois jours à travers ses paysages spectaculaires. Chaque jour, nous marchions plusieurs heures sous un soleil de plomb. Nous avons découvert des canyons, des piscines naturelles et des formations rocheuses aux formes étranges.",
          "Il y a trois ans, j'ai entrepris un voyage inoubliable vers les Tsingy de Bemaraha, dans l'ouest de Madagascar. Mon objectif était de gravir ces formations rocheuses acérées, classées au patrimoine mondial de l'UNESCO. Dès notre arrivée, nous avons entamé l'ascension des Tsingy. La vue du sommet était à couper le souffle."
        ]},
      questions:[
        {q:"Quelle destination le narrateur a-t-il choisie pour ses vacances d'été ?",o:["Nosy Be","Sainte-Marie","Isalo","Tsingy"],c:0,e:"Nosy Be."},
        {q:"Quel animal observe-t-on à l'île Sainte-Marie ?",o:["Le lémurien","La baleine à bosse","Le caméléon","Le fossa"],c:1,e:"La baleine à bosse."},
        {q:"Où se trouve le parc national de l'Isalo ?",o:["Dans le nord","Dans le sud","Dans l'est","Dans l'ouest"],c:1,e:"Dans le sud."},
        {q:"Quel site est classé au patrimoine mondial de l'UNESCO ?",o:["Nosy Be","Sainte-Marie","Tsingy de Bemaraha","Allée des Baobabs"],c:2,e:"Tsingy de Bemaraha."},
        {q:"Quelle est la structure du récit de voyage ?",o:["Situation initiale – Péripéties – Dénouement – Situation finale","Titre – Chapeau – Développement – Conclusion","Introduction – Thèse – Conclusion","En-tête – Corps – Signature"],c:0,e:"Schéma narratif."}
      ],
      lecon:{intro:"Le récit de voyage raconte une expérience vécue lors d'un déplacement.",
        structure:[{t:'Situation initiale',d:"Héros, lieu, moment, objectif."},{t:'Élément déclencheur',d:"Le départ en voyage."},{t:'Péripéties',d:"Étapes du voyage, obstacles rencontrés."},{t:'Dénouement',d:"Résolution du problème."},{t:'Situation finale',d:"Retour du héros, leçon de vie."}],
        ex:"Un jour, je décidai de partir à Nosy Be. Dès mon arrivée, l'odeur du ylang-ylang embaumait l'air.",
        ms:"Connecteurs logiques : mais, donc, alors, parce que. Phrases juxtaposées, coordonnées, subordonnées."},
      lexique:["Le tourisme : voyage, destination, hébergement, attraction touristique","Destinations populaires à Madagascar : Nosy Be, Isalo, Antananarivo, Île Sainte-Marie","Activités touristiques : randonnée, plongée, excursion, observation des baleines"],
      ms:["Les valeurs du temps présent","Les connecteurs logiques : mais, donc, alors, parce que","Les phrases juxtaposées, coordonnées, subordonnées"],
      exos:[
        {q:"Les 5 étapes du schéma narratif ?",o:["Intro – Corps – Fin","Situation initiale – Élément déclencheur – Péripéties – Dénouement – Situation finale","Titre – Chapeau – Dev – Conclusion","Début – Milieu – Fin"],c:1,e:"Schéma narratif classique."},
        {q:"Qui est l'adjuvant ?",o:["Celui qui s'oppose","Celui qui aide le héros","Le héros","L'objectif"],c:1,e:"Aide le héros."},
        {q:"Quel connecteur exprime la cause ?",o:["Mais","Donc","Parce que","Alors"],c:2,e:"« Parce que »."},
        {q:"Parc national à Madagascar ?",o:["Nosy Be","Île Sainte-Marie","Isalo","Antananarivo"],c:2,e:"Isalo."},
        {q:"« Il pleut, je reste » est une phrase :",o:["Coordonnée","Juxtaposée","Subordonnée","Complexe"],c:1,e:"Juxtaposée."}
      ]}
  ]},
  /* ============================================================
     PÉRIODE 3 : TEXTE ARGUMENTATIF
     ============================================================ */
  p3:{id:'p3',titre:'Texte Argumentatif',desc:"Article d'opinion, nutrition",sem:8,c:'#0b8a68',cd:'#066b51',cb:'rgba(11,138,104,.1)',themes:[
    /* THÈME 3.1 : LA CORRUPTION */
    {id:'corruption',titre:"La Corruption",desc:"Article d'opinion sur la corruption",type:"Argumentatif : article d'opinion",v:'Autonomie, responsabilité',
      semaines:[
        {code:'S1',titre:'Découverte et Compréhension',desc:"Découvrir l'article d'opinion et le lexique de base de la corruption",objectif:'Compréhension globale du texte',
          lecon:{intro:"La corruption est un phénomène qui touche de nombreux pays dans le monde. À Madagascar, elle constitue un véritable fléau qui freine le développement économique et social. Chaque année, des milliards d'ariary sont détournés, privant ainsi l'État des ressources nécessaires pour financer les écoles, les hôpitaux et les infrastructures. Selon les observateurs, la corruption se manifeste sous différentes formes : pots-de-vin, détournement de fonds publics, favoritisme, trafic d'influence. Ces pratiques nuisent gravement à la confiance des citoyens envers leurs institutions.",
            points:["La corruption est un fléau qui freine le développement","Elle se manifeste par : pots-de-vin, détournement, favoritisme, trafic d'influence","Les secteurs affectés : foncier (106 cas), justice (41 cas), CTD","Les institutions de contrôle : BIANCO, Pôle Anti-Corruption (PAC)","Les citoyens n'osent pas dénoncer les abus","La lutte est l'affaire de tous"],
            ms:"L'article d'opinion utilise le présent de l'indicatif pour exprimer l'opinion. Les phrases exprimant la cause (parce que, car), la conséquence (donc, par conséquent), le but (pour que, afin que) et la condition (si) organisent l'argumentation.",
            lex:["Corruption, pot-de-vin, détournement, favoritisme","Fraude, éthique, transparence, intégrité","BIANCO, Pôle Anti-Corruption, citoyen, magistrat"]},
          exosOuverts:[
            {titre:"Associez chaque mot à sa définition",type:"tableau",tag:"LEXIQUE",
              consigne:"Reliez chaque mot de la colonne A à sa définition dans la colonne B.",
              entetes:["N°","Colonne A (Mot)","Colonne B (Définition)","Réponse"],
              lignes:[
                ["1","Corruption","A. Somme d'argent donnée pour obtenir un avantage",""],
                ["2","Pot-de-vin","B. Action de détourner des fonds publics",""],
                ["3","Détournement","C. Fait d'utiliser son pouvoir pour un profit personnel",""],
                ["4","Favoritisme","D. Privilégier une personne au détriment des autres",""],
                ["5","Fraude","E. Tricherie pour obtenir un avantage illégal",""],
                ["6","Éthique","F. Ensemble des valeurs morales",""],
                ["7","Transparence","G. Fait d'agir de façon claire et honnête",""]
              ],
              corrige:["1 → C","2 → A","3 → B","4 → D","5 → E","6 → F","7 → G"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : citoyen, magistrat, fonctionnaire, BIANCO, loi, justice, honnêteté.",
              phrases:[
                "Un ___ est une personne qui vit dans un pays et qui a des droits et des devoirs. (citoyen)",
                "Le ___ rend la justice dans un tribunal. (magistrat)",
                "Un ___ travaille pour l'État et doit servir l'intérêt général. (fonctionnaire)",
                "Le ___ est l'institution qui enquête sur les cas de corruption à Madagascar. (BIANCO)",
                "La ___ est une règle obligatoire que tout le monde doit respecter. (loi)",
                "La ___ permet de punir les coupables et de protéger les innocents. (justice)",
                "L'___ est une qualité morale qui consiste à dire la vérité et à respecter autrui. (honnêteté)"
              ]},
            {titre:"Complétez avec le connecteur qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec le connecteur approprié choisi parmi : parce que, donc, pour que, si, car, alors, afin que.",
              phrases:[
                "La corruption freine le développement ___ elle détourne les ressources publiques. (parce qu')",
                "Les fonds publics sont détournés, ___ les écoles manquent de matériel. (donc)",
                "L'État doit renforcer les institutions ___ les coupables soient punis. (pour que)",
                "___ la justice est corrompue, les citoyens perdent confiance. (Si)",
                "Les citoyens ne dénoncent pas les abus ___ ils ont peur des représailles. (car)",
                "Le magistrat a accepté un pot-de-vin, ___ il a été suspendu. (alors)",
                "Il faut sensibiliser les jeunes ___ ils apprennent l'éthique dès l'école. (afin qu')"
              ]},
            {titre:"Complétez chaque phrase par une proposition personnelle",type:"production",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase par une proposition personnelle en respectant le type de connecteur indiqué.",
              lignes:7,
              exemple:"La corruption est un fléau parce qu'elle détruit la confiance des citoyens.",
              phrases:[
                "La corruption est un fléau parce que...",
                "Les fonds publics sont détournés donc...",
                "Il faut sensibiliser les citoyens pour qu'...",
                "Si la justice est corrompue,...",
                "Les citoyens ne dénoncent pas les abus car...",
                "Le pays souffre de la corruption alors...",
                "L'école doit éduquer les jeunes afin qu'..."
              ],
              corrige:"Réponses libres. Vérifier : cohérence avec le connecteur, respect du type (cause, conséquence, but, condition), correction grammaticale."}
          ],
          exos:[
            {q:"Qu'est-ce que la corruption ?",o:["Un acte légal","Un abus de pouvoir pour un profit personnel","Une loi","Une tradition"],c:1,e:"La corruption est un abus de pouvoir."},
            {q:"Quelle institution enquête sur la corruption à Madagascar ?",o:["L'UNESCO","Le BIANCO","L'ONU","La Croix-Rouge"],c:1,e:"Le BIANCO."},
            {q:"Quel est le connecteur qui exprime la cause ?",o:["Donc","Parce que","Mais","Pour que"],c:1,e:"« Parce que »."},
            {q:"Quel secteur est le plus touché par la corruption ?",o:["Le tourisme","Le foncier","L'artisanat","Le sport"],c:1,e:"Le foncier (106 cas)."},
            {q:"Quelle est la thèse défendue par l'auteur ?",o:["La corruption est inévitable","La corruption est un fléau à combattre","La corruption aide le développement","La corruption est légale"],c:1,e:"Fléau à combattre."}
          ]},
        {code:'S2',titre:'Approfondissement Lexical',desc:"Approfondir le lexique (causes, conséquences) et les connecteurs de conséquence et de but",objectif:'Maîtriser les connecteurs de conséquence et de but',
          lecon:{intro:"La corruption a des causes multiples : pauvreté, impunité, faiblesse des institutions, absence d'éducation à l'éthique. Ses conséquences sont graves : détournement des fonds publics, inégalités croissantes, perte de confiance des citoyens, frein au développement. Pour lutter efficacement, il faut renforcer les institutions (BIANCO, PAC), éduquer les citoyens à l'éthique, et appliquer des sanctions exemplaires. Les connecteurs de conséquence (donc, par conséquent, c'est pourquoi, si bien que) et de but (pour que, afin que + subjonctif) sont essentiels pour exprimer ces relations logiques.",
            points:["Causes de la corruption : pauvreté, impunité, faiblesse institutionnelle","Conséquences : détournement, inégalités, perte de confiance","Mesures : renforcer BIANCO et PAC, éduquer, sanctionner","Les connecteurs de conséquence : donc, par conséquent, c'est pourquoi, si bien que","Les connecteurs de but : pour que, afin que + subjonctif","Le subjonctif après « pour que »"],
            ms:"Les connecteurs de conséquence (donc, par conséquent, c'est pourquoi, si bien que) relient une cause à son effet. Les connecteurs de but (pour que, afin que) sont suivis du subjonctif.",
            lex:["Prévarication, concussion, népotisme, impunité","Intégrité, éthique, transparence, responsabilité","Sanction, contrôle, sensibilisation"]},
          exosOuverts:[
            {titre:"Classez les mots selon leur catégorie",type:"tableau",tag:"LEXIQUE",
              consigne:"Classez chaque mot dans la bonne colonne : acteur, acte, valeur ou institution.",
              entetes:["N°","Mot","Catégorie"],
              lignes:[
                ["1","Magistrat","Acteur"],
                ["2","Concussion","Acte"],
                ["3","Intégrité","Valeur"],
                ["4","BIANCO","Institution"],
                ["5","Prévarication","Acte"],
                ["6","Fonctionnaire","Acteur"],
                ["7","Responsabilité","Valeur"]
              ],
              corrige:["1 → Acteur","2 → Acte","3 → Valeur","4 → Institution","5 → Acte","6 → Acteur","7 → Valeur"]},
            {titre:"Complétez et transformez les phrases",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : prévarication, intégrité, concussion, impunité, éthique, transparence, favoritisme.",
              phrases:[
                "La ___ est le fait pour un fonctionnaire de détourner des fonds publics. (prévarication)",
                "L'___ est une qualité essentielle chez un magistrat. (intégrité)",
                "La ___ est un délit qui consiste à exiger des sommes indues. (concussion)",
                "L'___ fait que les coupables ne sont pas punis. (impunité)",
                "L'___ professionnelle est la base de la confiance. (éthique)",
                "La ___ dans la gestion publique est exigée par les citoyens. (transparence)",
                "Le ___ consiste à privilégier ses proches. (favoritisme)"
              ]},
            {titre:"Complétez avec le connecteur de conséquence qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec donc, par conséquent, c'est pourquoi ou si bien que.",
              phrases:[
                "La corruption est partout, ___ les citoyens ont perdu confiance. (donc)",
                "Les fonds ont été détournés, ___ les écoles n'ont plus de matériel. (par conséquent)",
                "La justice est corrompue, ___ les coupables restent impunis. (c'est pourquoi)",
                "Le magistrat a accepté un pot-de-vin, ___ il a été suspendu. (si bien qu')",
                "Le fonctionnaire a exigé une somme indue, ___ il a été arrêté. (par conséquent)",
                "Les jeunes sont découragés, ___ ils émigrent. (si bien qu')",
                "Le pays souffre, ___ il faut agir rapidement. (c'est pourquoi)"
              ]},
            {titre:"Transformez les phrases avec « pour que » ou « afin que »",type:"transformation",tag:"SYNTAXE",
              consigne:"Reliez les deux phrases en une seule en utilisant « pour que » ou « afin que » + subjonctif.",
              phrases:[
                "L'État doit renforcer les institutions. Les coupables sont punis. → L'État doit renforcer les institutions pour que les coupables soient punis.",
                "Il faut sensibiliser les jeunes. Ils apprennent l'éthique. → Il faut sensibiliser les jeunes pour qu'ils apprennent l'éthique.",
                "Les citoyens doivent dénoncer. La justice peut agir. → Les citoyens doivent dénoncer pour que la justice puisse agir.",
                "L'école doit éduquer. Les enfants deviennent intègres. → L'école doit éduquer pour que les enfants deviennent intègres.",
                "Le gouvernement doit agir. Le pays se développe. → Le gouvernement doit agir pour que le pays se développe.",
                "Les médias doivent informer. La population est consciente. → Les médias doivent informer pour que la population soit consciente.",
                "Chacun doit respecter la loi. La société est juste. → Chacun doit respecter la loi pour que la société soit juste."
              ],
              corrige:["1. L'État doit renforcer les institutions pour que les coupables soient punis.","2. Il faut sensibiliser les jeunes pour qu'ils apprennent l'éthique.","3. Les citoyens doivent dénoncer pour que la justice puisse agir.","4. L'école doit éduquer pour que les enfants deviennent intègres.","5. Le gouvernement doit agir pour que le pays se développe.","6. Les médias doivent informer pour que la population soit consciente.","7. Chacun doit respecter la loi pour que la société soit juste."]},
            {titre:"Rédigez un paragraphe argumentatif",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un paragraphe argumentatif de 6 à 8 phrases pour défendre l'idée suivante : « La lutte contre la corruption est l'affaire de tous ». Utilisez au moins 3 connecteurs logiques et donnez 2 arguments avec exemples.",
              lignes:8,
              exemple:"La lutte contre la corruption est l'affaire de tous, car ce fléau touche chaque citoyen. D'abord, lorsque les fonds publics sont détournés, ce sont les écoles et les hôpitaux qui en souffrent. Par conséquent, il est essentiel que chacun dénonce les actes de corruption, même les plus petits. Ensuite, l'éducation joue un rôle fondamental : si les enfants apprennent l'éthique dès le plus jeune âge, ils deviendront des citoyens responsables. C'est pourquoi les parents et les enseignants doivent montrer l'exemple. Enfin, pour que la justice règne, il faut que les sanctions soient appliquées à tous, sans distinction. En conclusion, seule une mobilisation collective permettra de vaincre la corruption.",
              corrige:"Réponses libres. Vérifier : au moins 3 connecteurs logiques, 2 arguments avec exemples, conclusion personnelle, cohérence et correction."}
          ],
          exos:[
            {q:"Quel connecteur exprime le but ?",o:["Parce que","Donc","Pour que","Mais"],c:2,e:"« Pour que »."},
            {q:"Quel mode suit « pour que » ?",o:["Indicatif","Subjonctif","Infinitif","Participe"],c:1,e:"Le subjonctif."},
            {q:"Que signifie « impunité » ?",o:["Absence de sanction","Justice","Punition","Sanction"],c:0,e:"Absence de sanction."}
          ]},
        {code:'S3',titre:'Structuration et Production',desc:"Maîtriser l'opposition et la structure du texte argumentatif",objectif:'Produire un texte argumentatif complet',
          lecon:{intro:"Le texte argumentatif suit une structure claire : introduction (présentation du sujet + thèse), développement (2-3 arguments avec exemples + réfutation d'un contre-argument), conclusion (synthèse + ouverture). Pour enrichir sa production, il faut utiliser un lexique précis, des connecteurs variés (cause, conséquence, but, opposition) et varier la structure des phrases. Les connecteurs d'opposition (mais, cependant, bien que, malgré) permettent de nuancer le propos.",
            points:["Structure : introduction, développement, conclusion","Introduction : sujet + thèse","Développement : arguments + exemples + réfutation","Conclusion : synthèse + ouverture","Les connecteurs d'opposition : mais, cependant, bien que, malgré","Enrichir ses phrases avec des synonymes précis","Varier la structure des phrases"],
            ms:"Les connecteurs d'opposition : mais, cependant, toutefois, néanmoins, bien que + subjonctif, malgré + nom. Le texte argumentatif utilise le présent de l'indicatif pour exprimer l'opinion.",
            lex:["Synonymes précis : majeur, crucial, exaspéré","Familles de mots : corruption/corrompu/corruptible","Connecteurs d'opposition","Structure du texte argumentatif"]},
          exosOuverts:[
            {titre:"Enrichissez vos phrases",type:"transformation",tag:"LEXIQUE",
              consigne:"Remplacez le mot souligné par un synonyme plus précis et plus expressif.",
              phrases:[
                "La corruption est un grand problème pour Madagascar. → majeur / considérable / crucial",
                "Les fonctionnaires malhonnêtes doivent être punis. → corrompus / véreux",
                "Le BIANCO mène des enquêtes sérieuses. → approfondies / rigoureuses",
                "Les citoyens sont fatigués de la corruption. → exaspérés / lassés",
                "La justice est lente dans ce pays. → inefficace / défaillante",
                "Le détournement de fonds est un acte mauvais. → répréhensible / condamnable",
                "La société civile joue un rôle important. → essentiel / primordial"
              ],
              corrige:["1. majeur / considérable / crucial","2. corrompus / véreux","3. approfondies / rigoureuses","4. exaspérés / lassés","5. inefficace / défaillante","6. répréhensible / condamnable","7. essentiel / primordial"]},
            {titre:"Complétez avec le lexique approprié",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : impunité, concussion, prévarication, népotisme, intégrité, sanction, transparence.",
              phrases:[
                "L'___ permet aux corrompus d'échapper à la justice. (impunité)",
                "La ___ est le fait d'exiger des sommes indues. (concussion)",
                "La ___ est le détournement de fonds par un fonctionnaire. (prévarication)",
                "Le ___ est le favoritisme envers sa famille. (népotisme)",
                "L'___ est indispensable chez les magistrats. (intégrité)",
                "La ___ doit être exemplaire et appliquée à tous. (sanction)",
                "La ___ dans la gestion publique est exigée. (transparence)"
              ]},
            {titre:"Exprimez l'opposition",type:"transformation",tag:"SYNTAXE",
              consigne:"Réécrivez chaque phrase en exprimant l'opposition avec bien que, malgré ou cependant.",
              phrases:[
                "La corruption est illégale. Elle est encore pratiquée. → Bien que la corruption soit illégale, elle est encore pratiquée.",
                "Le BIANCO enquête. Les résultats restent insuffisants. → Malgré les enquêtes du BIANCO, les résultats restent insuffisants.",
                "Les lois existent. Elles ne sont pas appliquées. → Les lois existent, cependant elles ne sont pas appliquées.",
                "Les citoyens connaissent leurs droits. Ils n'osent pas dénoncer. → Les citoyens connaissent leurs droits, cependant ils n'osent pas dénoncer.",
                "Le pays est riche en ressources. Il reste pauvre. → Bien que le pays soit riche en ressources, il reste pauvre.",
                "Les efforts sont entrepris. La corruption persiste. → Malgré les efforts entrepris, la corruption persiste.",
                "Il est honnête. Il est entouré de personnes corrompues. → Il est honnête, cependant il est entouré de personnes corrompues."
              ],
              corrige:["1. Bien que la corruption soit illégale, elle est encore pratiquée.","2. Malgré les enquêtes du BIANCO, les résultats restent insuffisants.","3. Les lois existent, cependant elles ne sont pas appliquées.","4. Les citoyens connaissent leurs droits, cependant ils n'osent pas dénoncer.","5. Bien que le pays soit riche en ressources, il reste pauvre.","6. Malgré les efforts entrepris, la corruption persiste.","7. Il est honnête, cependant il est entouré de personnes corrompues."]},
            {titre:"Analysez la structure des phrases",type:"tableau",tag:"SYNTAXE",
              consigne:"Indiquez si chaque phrase est simple, juxtaposée, coordonnée ou subordonnée.",
              entetes:["N°","Phrase","Type"],
              lignes:[
                ["1","La corruption est un fléau.","Simple"],
                ["2","La corruption est un fléau et elle freine le développement.","Coordonnée"],
                ["3","La corruption est un fléau, elle freine le développement.","Juxtaposée"],
                ["4","Parce que la corruption est partout, les citoyens sont méfiants.","Subordonnée"],
                ["5","Je pense que la lutte doit être collective.","Subordonnée"],
                ["6","Les fonds sont détournés mais les coupables restent impunis.","Coordonnée"],
                ["7","Le BIANCO enquête, les dossiers s'accumulent, les coupables fuient.","Juxtaposée"]
              ],
              corrige:["1. Simple","2. Coordonnée (et)","3. Juxtaposée (virgule)","4. Subordonnée (parce que)","5. Subordonnée (que)","6. Coordonnée (mais)","7. Juxtaposée (virgules)"]},
            {titre:"Rédigez un texte argumentatif complet",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un texte argumentatif de 8 à 10 phrases sur la corruption à Madagascar. Structure : Introduction (sujet + thèse), Développement (2 arguments avec exemples + 1 contre-argument réfuté), Conclusion (synthèse + ouverture). Utilisez au moins 4 connecteurs logiques.",
              lignes:10,
              exemple:"La corruption est un fléau qui ronge la société malgache depuis des décennies. D'abord, elle freine le développement économique, car les fonds publics détournés ne profitent pas à la population. Par exemple, de nombreuses écoles manquent de matériel alors que des milliards d'ariary disparaissent chaque année. Ensuite, la corruption détruit la confiance des citoyens envers leurs institutions. Par conséquent, beaucoup préfèrent se taire plutôt que de dénoncer les abus. Certains prétendent qu'il est inutile de lutter, cependant cette idée est dangereuse. En effet, des pays ont réussi à réduire la corruption grâce à une mobilisation collective. Pour conclure, la lutte contre ce fléau doit être l'affaire de tous.",
              corrige:"Réponses libres. Vérifier : structure argumentative complète, 2 arguments + exemples, 1 contre-argument réfuté, au moins 4 connecteurs logiques, lexique riche, cohérence et correction."}
          ],
          exos:[
            {q:"Transformez : La corruption est illégale. Elle est encore pratiquée.",o:["Bien que la corruption soit illégale, elle est encore pratiquée","La corruption est illégale et pratiquée","La corruption est légale","Aucune"],c:0,e:"« Bien que » + subjonctif."},
            {q:"Quelle phrase est juxtaposée ?",o:["La corruption est un fléau, elle freine le développement","La corruption est un fléau et elle freine","Parce que la corruption est partout, les citoyens sont méfiants","La corruption est un fléau"],c:0,e:"La virgule est un signe de juxtaposition."},
            {q:"Quel connecteur exprime l'opposition ?",o:["Bien que","Car","Alors","Puisque"],c:0,e:"« Bien que »."}
          ]},
        {code:'S4',titre:'Évaluation et Consolidation',desc:"Évaluer les acquis lexicaux et syntaxiques sur la corruption",objectif:'Évaluation des compétences',
          lecon:{intro:"Cette semaine est consacrée à l'évaluation et à la consolidation des acquis sur le thème de la corruption. Nous révisons le lexique (mots de base, actes, institutions, valeurs), les connecteurs logiques (cause, conséquence, but, opposition), les transformations passives/actives, les types de phrases et la production écrite.",
            points:["Révision du lexique de la corruption","Révision des connecteurs logiques","Révision de la voix passive et active","Révision des phrases simples et complexes","Reformulation en phrases simples","Préparation à l'évaluation finale"],
            ms:"Révision globale : présent de l'indicatif, connecteurs logiques, voix passive/active, types de phrases.",
            lex:["Corruption, pot-de-vin, prévarication, concussion","BIANCO, PAC, citoyen, magistrat","Intégrité, éthique, transparence, responsabilité"]},
          exosOuverts:[
            {titre:"Complétez la grille de mots croisés",type:"tableau",tag:"LEXIQUE",
              consigne:"Retrouvez le mot correspondant à chaque définition.",
              entetes:["N°","Définition","Mot à trouver"],
              lignes:[
                ["1","Somme d'argent donnée pour obtenir un avantage",""],
                ["2","Détournement de fonds par un fonctionnaire",""],
                ["3","Favoritisme envers sa famille",""],
                ["4","Qualité morale d'une personne honnête",""],
                ["5","Fait d'agir de façon claire et honnête",""],
                ["6","Institution anti-corruption de Madagascar",""],
                ["7","Absence de sanction pour les coupables",""]
              ],
              corrige:["1. Pot-de-vin","2. Prévarication","3. Népotisme","4. Intégrité","5. Transparence","6. BIANCO","7. Impunité"]},
            {titre:"QCM – Choisissez la bonne réponse",type:"qcm-ouvert",tag:"LEXIQUE",
              consigne:"Entourez la bonne réponse.",
              questions:[
                {q:"Que signifie « prévarication » ?",o:["Vol simple","Détournement de fonds publics","Favoritisme","Mensonge"],c:1},
                {q:"Quel est le contraire de « corruption » ?",o:["Fraude","Intégrité","Impunité","Népotisme"],c:1},
                {q:"Que signifie le sigle BIANCO ?",o:["Bureau Indépendant Anti-Corruption","Bureau International Anti-Corruption","Bureau d'Investigation Anti-Nationale","Bureau Inter-Africain de Contrôle"],c:0},
                {q:"Quel est l'acte qui consiste à exiger des sommes indues ?",o:["Concussion","Favoritisme","Fraude","Détournement"],c:0},
                {q:"Quel connecteur exprime la cause ?",o:["Donc","Parce que","Mais","Bien que"],c:1},
                {q:"Quel connecteur exprime le but ?",o:["Parce que","Donc","Pour que","Cependant"],c:2},
                {q:"Quel connecteur exprime l'opposition ?",o:["Bien que","Car","Alors","Puisque"],c:0}
              ],
              corrige:["1. b) Détournement de fonds publics","2. b) Intégrité","3. a) Bureau Indépendant Anti-Corruption","4. a) Concussion","5. b) Parce que","6. c) Pour que","7. a) Bien que"]},
            {titre:"Complétez avec le connecteur qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec un connecteur logique approprié (cause, conséquence, but, opposition).",
              phrases:[
                "La corruption est illégale, ___ elle est encore pratiquée. (mais / cependant)",
                "Les fonds sont détournés, ___ les écoles manquent de matériel. (donc / c'est pourquoi)",
                "Il faut sensibiliser les jeunes ___ ils apprennent l'éthique. (pour qu')",
                "Les citoyens ne dénoncent pas ___ ils ont peur. (parce qu')",
                "___ les efforts, la corruption persiste. (Malgré)",
                "Le BIANCO enquête ___ plusieurs dossiers. (car)",
                "La justice doit être équitable ___ la société soit juste. (pour que)"
              ]},
            {titre:"Transformez les phrases",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase selon l'indication donnée.",
              phrases:[
                "Les fonctionnaires corrompus sont punis. (forme passive) → Les fonctionnaires corrompus sont punis par la justice.",
                "La corruption freine le développement. (avec « parce que ») → La corruption freine le développement parce qu'elle détourne les fonds publics.",
                "Le magistrat a été suspendu. Il a accepté un pot-de-vin. (avec « donc ») → Le magistrat a accepté un pot-de-vin, donc il a été suspendu.",
                "Les citoyens protestent. La justice est corrompue. (avec « pour que ») → Les citoyens protestent pour que la justice ne soit plus corrompue.",
                "Le pays est riche. Il reste pauvre. (avec « bien que ») → Bien que le pays soit riche, il reste pauvre.",
                "La corruption est un fléau et elle freine le développement. (deux phrases simples) → La corruption est un fléau. Elle freine le développement.",
                "Parce que la corruption est partout, les citoyens sont méfiants. (phrase simple) → La corruption est partout. Les citoyens sont méfiants."
              ],
              corrige:["1. Les fonctionnaires corrompus sont punis par la justice.","2. La corruption freine le développement parce qu'elle détourne les fonds publics.","3. Le magistrat a accepté un pot-de-vin, donc il a été suspendu.","4. Les citoyens protestent pour que la justice ne soit plus corrompue.","5. Bien que le pays soit riche, il reste pauvre.","6. La corruption est un fléau. Elle freine le développement.","7. La corruption est partout. Les citoyens sont méfiants."]},
            {titre:"Rédigez un texte argumentatif final",type:"production",tag:"EVAL",
              consigne:"Rédigez un texte argumentatif de 8 à 10 phrases sur le sujet : « La corruption est-elle un obstacle au développement de Madagascar ? ». Utilisez au moins 4 connecteurs logiques, 2 arguments avec exemples, 1 contre-argument réfuté, et terminez par une conclusion personnelle.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : structure complète, 4 connecteurs, 2 arguments + exemples, 1 contre-argument réfuté, conclusion personnelle, cohérence et correction."}
          ],
          exos:[
            {q:"Que signifie « prévarication » ?",o:["Vol simple","Détournement de fonds publics","Favoritisme","Mensonge"],c:1,e:"Détournement de fonds publics."},
            {q:"Quel est le contraire de « corruption » ?",o:["Fraude","Intégrité","Impunité","Népotisme"],c:1,e:"Intégrité."},
            {q:"Que signifie le sigle BIANCO ?",o:["Bureau Indépendant Anti-Corruption","Bureau International Anti-Corruption","Bureau d'Investigation","Bureau Inter-Africain"],c:0,e:"Bureau Indépendant Anti-Corruption."},
            {q:"Quel connecteur exprime le but ?",o:["Parce que","Donc","Pour que","Cependant"],c:2,e:"« Pour que »."},
            {q:"Quel connecteur exprime l'opposition ?",o:["Bien que","Car","Alors","Puisque"],c:0,e:"« Bien que »."}
          ]},
        {code:'S5',titre:'Synthèse finale',desc:"Révision générale et auto-évaluation du thème",objectif:'Consolider tous les acquis du thème',
          lecon:{intro:"Cette dernière semaine est consacrée à la synthèse générale du thème de la corruption. Nous révisons l'ensemble des acquis : le lexique, les actes de corruption, les institutions, les valeurs, les connecteurs logiques, les types de phrases, la voix passive/active, la reformulation et la production écrite. L'objectif est de consolider les connaissances et de préparer l'évaluation finale.",
            points:["Le lexique : corruption, pot-de-vin, prévarication, concussion","Les institutions : BIANCO, PAC, Cour de Cassation","Les valeurs : intégrité, éthique, transparence, responsabilité","Les connecteurs : cause, conséquence, but, opposition","Les types de phrases : simple, juxtaposée, coordonnée, subordonnée","La structure du texte argumentatif","La voix passive et active"],
            ms:"Révision globale de toutes les notions du thème : présent de l'indicatif, connecteurs logiques, voix passive/active, types de phrases.",
            lex:["Corruption, pot-de-vin, prévarication, concussion, népotisme","BIANCO, PAC, citoyen, magistrat, fonctionnaire","Intégrité, éthique, transparence, responsabilité"]},
          exosOuverts:[
            {titre:"Rédigez une synthèse finale sur la corruption",type:"production",tag:"EVAL",
              consigne:"Rédigez un texte argumentatif complet (introduction + développement + conclusion) sur la corruption à Madagascar. Mobilisez tout le lexique appris, les connecteurs logiques, et variez la structure des phrases.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : structure complète, lexique riche, connecteurs variés, types de phrases variés, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle institution enquête sur la corruption à Madagascar ?",o:["L'UNESCO","Le BIANCO","L'ONU","La Croix-Rouge"],c:1,e:"Le BIANCO."},
            {q:"Quel connecteur exprime la conséquence ?",o:["Parce que","Donc","Mais","Bien que"],c:1,e:"« Donc »."},
            {q:"Quel mode suit « pour que » ?",o:["Indicatif","Subjonctif","Infinitif","Participe"],c:1,e:"Le subjonctif."},
            {q:"Quelle est la structure du texte argumentatif ?",o:["Introduction – Développement – Conclusion","Titre – Chapeau – Dev – Conclusion","Situation initiale – Péripéties – Dénouement","En-tête – Corps – Signature"],c:0,e:"Introduction, développement, conclusion."}
          ]}
      ],
      texte:{titre:"La corruption : un obstacle au développement de Madagascar",
        contenu:[
          "La corruption est un phénomène qui touche de nombreux pays dans le monde. À Madagascar, elle constitue un véritable fléau qui freine le développement économique et social. Chaque année, des milliards d'ariary sont détournés, privant ainsi l'État des ressources nécessaires pour financer les écoles, les hôpitaux et les infrastructures.",
          "Selon les observateurs, la corruption se manifeste sous différentes formes : pots-de-vin, détournement de fonds publics, favoritisme, trafic d'influence. Ces pratiques nuisent gravement à la confiance des citoyens envers leurs institutions. En effet, lorsque la justice est corrompue, les citoyens ne croient plus en l'égalité devant la loi.",
          "Cependant, il existe des moyens de lutter contre ce fléau. D'abord, il faut renforcer les institutions de contrôle comme le BIANCO et le Pôle Anti-Corruption. Ensuite, il est essentiel de sensibiliser les citoyens dès le plus jeune âge à l'éthique et à la responsabilité. Enfin, la société civile doit jouer un rôle actif en dénonçant les cas de corruption.",
          "En conclusion, la lutte contre la corruption est l'affaire de tous. Seule une mobilisation collective permettra de construire une société plus juste et plus prospère pour les générations futures."
        ]},
      questions:[
        {q:"Quel est le thème principal du texte ?",o:["La corruption à Madagascar","Le tourisme","L'artisanat","L'alimentation"],c:0,e:"La corruption à Madagascar."},
        {q:"Quelles sont les conséquences de la corruption sur le développement ?",o:["Elle freine le développement économique et social","Elle aide le développement","Elle n'a aucun effet","Elle augmente les salaires"],c:0,e:"Elle freine le développement."},
        {q:"Quelles institutions de contrôle sont citées ?",o:["BIANCO et PAC","UNESCO et ONU","Croix-Rouge","Aucune"],c:0,e:"BIANCO et Pôle Anti-Corruption."},
        {q:"Quel rôle doit jouer la société civile ?",o:["Dénoncer les cas de corruption","Se taire","Ignorer les abus","Soutenir la corruption"],c:0,e:"Dénoncer les cas de corruption."},
        {q:"Quelle est la thèse défendue par l'auteur ?",o:["La corruption est inévitable","La corruption est un fléau à combattre","La corruption aide le développement","La corruption est légale"],c:1,e:"Fléau à combattre."}
      ],
      lecon:{intro:"L'article d'opinion défend un point de vue sur un sujet, appuyé par des arguments et des exemples.",
        structure:[{t:'Introduction',d:"Sujet, problématique, thèse."},{t:'Développement',d:"2-3 arguments + exemples/preuves."},{t:'Conclusion',d:"Reformulation + ouverture/appel."}],
        ex:"La corruption freine le développement économique en détournant les fonds publics.",
        ms:"Phrases de cause, conséquence, but, condition, opposition. Temps : passé composé, imparfait, conditionnel, subjonctif."},
      lexique:["Fraude, pot-de-vin, transparence, éthique, responsabilité","Conséquences sur la société et l'économie","Mesures de lutte contre la corruption"],
      ms:["Les phrases exprimant la cause, la conséquence, le but, la condition, l'opposition","Le passé composé, l'imparfait, le conditionnel, le subjonctif"],
      exos:[
        {q:"Structure d'un article d'opinion ?",o:["Titre – Chapeau – Dev – Conclusion","Introduction – Développement (arguments) – Conclusion","Situation initiale – Péripéties – Dénouement","En-tête – Corps – Signature"],c:1,e:"Intro + Dev + Conclusion."},
        {q:"Quelle phrase exprime la conséquence ?",o:["Il travaille parce qu'il a besoin.","Il travaille pour réussir.","Il travaille donc il réussit.","Il travaille bien que fatigué."],c:2,e:"« Donc »."},
        {q:"Synonyme de « corruption » ?",o:["Honnêteté","Fraude","Transparence","Éthique"],c:1,e:"Fraude."},
        {q:"Mode exprimant une recommandation ?",o:["Indicatif","Impératif","Infinitif","Participe"],c:1,e:"Impératif."},
        {q:"Quelle phrase exprime l'opposition ?",o:["Il est riche donc il aide.","Il est riche parce qu'il travaille.","Il est riche mais pas heureux.","Il est riche pour aider."],c:2,e:"« Mais »."}
      ]},
    /* THÈME 3.2 : ALIMENTATION & SANTÉ */
    {id:'alimentation',titre:"Alimentation & Santé",desc:"Article de nutrition",type:"Argumentatif : article de nutrition",v:'Maîtrise de soi, responsabilité',
      semaines:[
        {code:'S1',titre:'Découverte et Compréhension',desc:"Découvrir l'article de nutrition et le lexique de base de l'alimentation",objectif:'Compréhension globale du texte',
          lecon:{intro:"Une alimentation variée et équilibrée est bien plus qu'une simple habitude : c'est un véritable investissement pour la santé. Les études scientifiques montrent qu'une nutrition adaptée prévient de nombreuses maladies chroniques. Chaque organe de notre corps a besoin d'aliments spécifiques pour bien fonctionner. Pour le cerveau, il faut privilégier le saumon, le thon, la sardine et les noix, riches en oméga-3. Pour les yeux, les œufs, le maïs et les carottes, qui contiennent de la vitamine A. Pour les muscles, les bananes, la viande rouge, le poisson et les œufs. Pour la peau, les myrtilles, le saumon et le thé vert. Une alimentation équilibrée est la clé d'une bonne santé : il ne suffit pas de manger, il faut bien manger.",
            points:["Une alimentation variée et équilibrée prévient les maladies","Les oméga-3 (saumon, noix) améliorent la mémoire et la concentration","La vitamine A (carottes, œufs) est bonne pour les yeux","Les protéines (viande, poisson, œufs) construisent les muscles","Le calcium (lait, fromage) renforce les os","Les féculents (riz, manioc) fournissent de l'énergie","5 fruits et légumes par jour sont recommandés"],
            ms:"L'article de nutrition utilise le présent de l'indicatif pour exprimer les vérités générales. Les pronoms indéfinis (tout, certains, quelques-uns, personne, plusieurs) remplacent les noms et évitent les répétitions.",
            lex:["Nutriments : protéines, glucides, lipides, vitamines, minéraux","Aliments : riz, légumes, fruits, viande, poisson, lait, œufs","Santé : obésité, diabète, malnutrition, carence"]},
          exosOuverts:[
            {titre:"Classez chaque aliment dans la bonne catégorie",type:"tableau",tag:"LEXIQUE",
              consigne:"Classez chaque aliment dans la bonne catégorie : fruits, légumes, féculents, produits laitiers ou protéines.",
              entetes:["N°","Aliment","Catégorie"],
              lignes:[
                ["1","Banane","Fruits"],
                ["2","Carotte","Légumes"],
                ["3","Riz","Féculents"],
                ["4","Yaourt","Produits laitiers"],
                ["5","Poisson","Protéines"],
                ["6","Manioc","Féculents"],
                ["7","Fromage","Produits laitiers"]
              ],
              corrige:["1 → Fruits","2 → Légumes","3 → Féculents","4 → Produits laitiers","5 → Protéines","6 → Féculents","7 → Produits laitiers"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : vitamines, protéines, oméga-3, calcium, féculents, équilibrée, hydratation.",
              phrases:[
                "Les carottes contiennent des ___ bonnes pour les yeux. (vitamines)",
                "La viande et le poisson sont riches en ___. (protéines)",
                "Le saumon contient des ___ bons pour le cerveau. (oméga-3)",
                "Le lait et le fromage apportent du ___ aux os. (calcium)",
                "Le riz et le manioc sont des ___ énergétiques. (féculents)",
                "Une alimentation ___ est la clé d'une bonne santé. (équilibrée)",
                "L'___ est essentielle : il faut boire beaucoup d'eau. (hydratation)"
              ]},
            {titre:"Complétez avec le pronom indéfini qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec le pronom indéfini approprié choisi parmi : tout, certains, certaines, quelqu'un, quelques-uns, personne, plusieurs.",
              phrases:[
                "___ les aliments ne sont pas bons pour la santé. (Tous)",
                "___ aiment les légumes verts, d'autres préfèrent les fruits. (Certains)",
                "___ des aliments contiennent des vitamines essentielles. (Quelques-uns)",
                "___ n'est à l'abri des maladies s'il ne mange pas équilibré. (Personne)",
                "___ des fruits sont plus sucrés que d'autres. (Plusieurs)",
                "___ doit boire beaucoup d'eau chaque jour. (Chacun)",
                "___ des personnes sont intolérantes au lactose. (Certaines)"
              ]},
            {titre:"Rédigez un court texte sur une alimentation saine",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un court texte de 4 à 5 phrases pour expliquer ce qu'est une alimentation équilibrée. Utilisez au moins 3 pronoms indéfinis (tout, certains, quelques-uns, personne, plusieurs, chacun...).",
              lignes:5,
              exemple:"Une alimentation équilibrée est essentielle pour la santé. Chacun doit manger de tout un peu : des fruits, des légumes, des féculents et des protéines. Certains pensent qu'il suffit de manger à sa faim, mais ce n'est pas vrai. Quelques-uns ignorent que les vitamines et les oméga-3 sont indispensables. Personne ne devrait négliger son alimentation.",
              corrige:"Réponses libres. Vérifier : présence d'au moins 3 pronoms indéfinis, cohérence du texte (4 à 5 phrases), mobilisation du lexique de l'alimentation."}
          ],
          exos:[
            {q:"Quels aliments sont bons pour le cerveau ?",o:["Saumon, thon, noix","Riz, manioc","Bonbons, sodas","Pain, pâtes"],c:0,e:"Le saumon, le thon et les noix sont riches en oméga-3."},
            {q:"Quels aliments sont bons pour les yeux ?",o:["Carottes, œufs, maïs","Viande rouge","Fromage","Sucre"],c:0,e:"Les carottes, les œufs et le maïs contiennent de la vitamine A."},
            {q:"Qu'est-ce qu'un pronom indéfini ?",o:["Un mot qui remplace un nom de manière indéterminée","Un adjectif","Un verbe","Une conjonction"],c:0,e:"Un pronom indéfini remplace un nom de manière indéterminée."},
            {q:"Quel pronom signifie « aucun » ?",o:["Tout","Certains","Personne","Plusieurs"],c:2,e:"« Personne »."},
            {q:"Qu'est-ce qu'une alimentation équilibrée ?",o:["Manger seulement des fruits","Manger varié et en quantité adaptée","Sauter des repas","Manger seulement le soir"],c:1,e:"Manger varié et en quantité adaptée."}
          ]},
        {code:'S2',titre:'Approfondissement Lexical',desc:"Approfondir le lexique des nutriments et les pronoms indéfinis complexes",objectif:'Maîtriser les pronoms indéfinis complexes',
          lecon:{intro:"Chaque nutriment joue un rôle précis dans le corps humain. Les protéines construisent et réparent les muscles. Les vitamines protègent contre les maladies. Le calcium renforce les os et les dents. Les oméga-3 améliorent la mémoire et la concentration. Le fer transporte l'oxygène dans le sang. Les fibres facilitent la digestion. Les glucides fournissent de l'énergie au corps. Une alimentation équilibrée doit contenir tous ces nutriments en quantité adaptée. Les carences alimentaires peuvent causer des maladies graves comme l'anémie, le rachitisme ou la malnutrition.",
            points:["Protéines : construire et réparer les muscles","Vitamines : protéger contre les maladies","Calcium : renforcer les os et les dents","Oméga-3 : améliorer la mémoire et la concentration","Fer : transporter l'oxygène dans le sang","Fibres : faciliter la digestion","Glucides : fournir de l'énergie","Carences : anémie, rachitisme, malnutrition"],
            ms:"Les pronoms indéfinis s'accordent en genre et en nombre avec le nom qu'ils remplacent. Certains sont variables (tout/tous/toute/toutes, certain/certains/certaine/certaines), d'autres sont invariables (personne, rien, quelqu'un, plusieurs, chacun).",
            lex:["Nutriments : protéines, vitamines, calcium, oméga-3, fer, fibres","Maladies : anémie, rachitisme, malnutrition, obésité, diabète","Pronoms indéfinis : tout, certains, quelques-uns, personne, plusieurs"]},
          exosOuverts:[
            {titre:"Associez chaque nutriment à son rôle",type:"tableau",tag:"LEXIQUE",
              consigne:"Associez chaque nutriment à son rôle principal dans le corps humain.",
              entetes:["N°","Nutriment","Rôle"],
              lignes:[
                ["1","Protéines","Construire et réparer les muscles"],
                ["2","Vitamines","Protéger contre les maladies"],
                ["3","Calcium","Renforcer les os et les dents"],
                ["4","Oméga-3","Améliorer la mémoire et la concentration"],
                ["5","Fer","Transporter l'oxygène dans le sang"],
                ["6","Fibres","Faciliter la digestion"],
                ["7","Glucides","Fournir de l'énergie au corps"]
              ],
              corrige:["1 → Construire et réparer les muscles","2 → Protéger contre les maladies","3 → Renforcer les os et les dents","4 → Améliorer la mémoire et la concentration","5 → Transporter l'oxygène dans le sang","6 → Faciliter la digestion","7 → Fournir de l'énergie au corps"]},
            {titre:"Complétez et transformez les phrases",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : carence, obésité, malnutrition, équilibre, hydratation, diversification, allergie.",
              phrases:[
                "La ___ en vitamines peut causer des maladies. (carence)",
                "L'___ est un problème de santé croissant à Madagascar. (obésité)",
                "La ___ touche les enfants qui ne mangent pas assez. (malnutrition)",
                "L'___ alimentaire est la base d'une bonne santé. (équilibre)",
                "Une bonne ___ est essentielle pendant le sport. (hydratation)",
                "La ___ alimentaire consiste à varier les aliments. (diversification)",
                "L'___ au lactose touche de nombreuses personnes. (allergie)"
              ]},
            {titre:"Complétez avec le pronom indéfini qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec le pronom indéfini approprié choisi parmi : tout, certains, certaines, quelqu'un, quelques-uns, quelques-unes, personne, plusieurs, chacun.",
              phrases:[
                "___ les enfants doivent apprendre à bien manger. (Tous)",
                "___ des aliments sont plus nutritifs que d'autres. (Certains)",
                "___ ne connaît tous les bienfaits des oméga-3. (Personne)",
                "___ des personnes sont allergiques aux arachides. (Quelques-unes)",
                "___ doit boire au moins 1,5 litre d'eau par jour. (Chacun)",
                "___ des légumes contiennent plus de fibres que les fruits. (Quelques-uns)",
                "___ a déjà goûté au romazava. (Quelqu'un)"
              ]},
            {titre:"Rédigez un paragraphe argumentatif sur l'alimentation",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un paragraphe argumentatif de 6 à 8 phrases pour défendre l'idée suivante : « Une alimentation équilibrée est essentielle pour la santé ». Utilisez au moins 3 pronoms indéfinis et donnez 2 arguments avec un exemple chacun.",
              lignes:8,
              exemple:"Une alimentation équilibrée est essentielle pour la santé. D'abord, chacun doit consommer des fruits et des légumes, car ils apportent des vitamines indispensables. Par exemple, les carottes protègent la vue. Ensuite, plusieurs personnes ignorent que les oméga-3 améliorent la mémoire et la concentration. Quelques-uns pensent qu'il suffit de manger à sa faim, mais ce n'est pas vrai. Personne ne devrait négliger l'importance d'une bonne hydratation. En conclusion, tout le monde doit prendre soin de son alimentation pour préserver sa santé.",
              corrige:"Réponses libres. Vérifier : au moins 3 pronoms indéfinis, 2 arguments avec exemples, conclusion personnelle, cohérence et correction."}
          ],
          exos:[
            {q:"Quel nutriment renforce les os ?",o:["Le calcium","Le fer","Les fibres","Les glucides"],c:0,e:"Le calcium renforce les os et les dents."},
            {q:"Quel nutriment transporte l'oxygène dans le sang ?",o:["Le fer","Le calcium","Les protéines","Les vitamines"],c:0,e:"Le fer transporte l'oxygène dans le sang."},
            {q:"Quel pronom signifie « un petit nombre » ?",o:["Quelques-uns","Tout","Personne","Plusieurs"],c:0,e:"« Quelques-uns »."},
            {q:"Que signifie « malnutrition » ?",o:["Trop manger","Manque d'aliments essentiels","Bien manger","Manger varié"],c:1,e:"Manque d'aliments essentiels."},
            {q:"Quel pronom indéfini est invariable ?",o:["Tout","Certains","Personne","Toutes"],c:2,e:"« Personne » est invariable."}
          ]},
        {code:'S3',titre:'Structuration et Production',desc:"Maîtriser la structure du texte argumentatif et produire un texte complet",objectif:'Produire un texte argumentatif complet',
          lecon:{intro:"Le texte argumentatif suit une structure claire : introduction (présentation du sujet + thèse), développement (2-3 arguments avec exemples + réfutation d'un contre-argument), conclusion (synthèse + ouverture). Pour enrichir sa production, il faut utiliser un lexique précis (nutriments, aliments, santé), des connecteurs logiques (d'abord, ensuite, enfin, parce que, donc, mais) et varier la structure des phrases. Les pronoms indéfinis permettent d'éviter les répétitions et de généraliser le propos.",
            points:["Structure : introduction, développement, conclusion","Introduction : sujet + thèse","Développement : arguments + exemples + réfutation","Conclusion : synthèse + ouverture","Utiliser des pronoms indéfinis pour éviter les répétitions","Enrichir ses phrases avec des synonymes précis","Varier la structure des phrases"],
            ms:"Les pronoms indéfinis : tout, tous, toute, toutes, certain, certains, certaine, certaines, quelqu'un, quelques-uns, quelques-unes, personne, plusieurs, chacun, rien. Ils s'accordent en genre et en nombre.",
            lex:["Synonymes précis : essentiel, primordial, capital","Familles de mots : aliment/alimentation/alimentaire","Connecteurs logiques","Structure du texte argumentatif"]},
          exosOuverts:[
            {titre:"Enrichissez vos phrases",type:"transformation",tag:"LEXIQUE",
              consigne:"Remplacez le mot souligné par un synonyme plus précis et plus expressif.",
              phrases:[
                "Une alimentation équilibrée est importante pour la santé. → essentielle / primordiale / capitale",
                "Les fruits sont bons pour le corps. → bénéfiques / salutaires",
                "Les légumes sont riches en vitamines. → regorgent de / abondent en",
                "Le sucre est mauvais pour la santé. → néfaste / nocif",
                "L'eau est indispensable à la vie. → vitale / fondamentale",
                "Les sodas sont dangereux pour les enfants. → risqués / préjudiciables",
                "Une bonne alimentation prévient les maladies. → protège contre / évite"
              ],
              corrige:["1. essentielle / primordiale / capitale","2. bénéfiques / salutaires","3. regorgent de / abondent en","4. néfaste / nocif","5. vitale / fondamentale","6. risqués / préjudiciables","7. protège contre / évite"]},
            {titre:"Complétez avec le lexique approprié",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : carence, obésité, malnutrition, équilibre, hydratation, diversification, allergie.",
              phrases:[
                "La ___ en fer provoque l'anémie. (carence)",
                "L'___ est causée par une alimentation trop riche en sucre. (obésité)",
                "La ___ touche les populations qui manquent de nourriture. (malnutrition)",
                "L'___ alimentaire repose sur la variété des aliments. (équilibre)",
                "Une bonne ___ est essentielle pendant l'effort physique. (hydratation)",
                "La ___ alimentaire permet d'éviter les carences. (diversification)",
                "L'___ aux fruits de mer est fréquente. (allergie)"
              ]},
            {titre:"Analysez la structure des phrases",type:"tableau",tag:"SYNTAXE",
              consigne:"Indiquez si chaque phrase est simple, juxtaposée, coordonnée ou subordonnée.",
              entetes:["N°","Phrase","Type"],
              lignes:[
                ["1","Une alimentation équilibrée est essentielle.","Simple"],
                ["2","Les fruits sont bons et ils apportent des vitamines.","Coordonnée"],
                ["3","Les légumes sont riches, ils protègent la santé.","Juxtaposée"],
                ["4","Parce que le sucre est mauvais, il faut le limiter.","Subordonnée"],
                ["5","Je pense qu'une bonne alimentation prévient les maladies.","Subordonnée"],
                ["6","Le calcium renforce les os mais le fer transporte l'oxygène.","Coordonnée"],
                ["7","Les fruits sont sucrés, les légumes sont riches en fibres, l'eau est vitale.","Juxtaposée"]
              ],
              corrige:["1. Simple","2. Coordonnée (et)","3. Juxtaposée (virgule)","4. Subordonnée (parce que)","5. Subordonnée (que)","6. Coordonnée (mais)","7. Juxtaposée (virgules)"]},
            {titre:"Rédigez un texte argumentatif complet",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un texte argumentatif de 8 à 10 phrases sur l'alimentation et la santé. Structure : Introduction (sujet + thèse), Développement (2 arguments avec exemples + 1 contre-argument réfuté), Conclusion (synthèse + ouverture). Utilisez au moins 4 pronoms indéfinis.",
              lignes:10,
              exemple:"Une alimentation équilibrée est un véritable investissement pour la santé. D'abord, certains aliments apportent des nutriments indispensables au corps. Par exemple, plusieurs fruits et légumes sont riches en vitamines. Ensuite, tous les repas doivent contenir des féculents, des protéines et des fibres. Cependant, quelques-uns négligent leur alimentation et consomment trop de sucre. Par conséquent, certains développent des maladies comme l'obésité ou le diabète. Enfin, personne ne devrait ignorer l'importance d'une bonne hygiène de vie. Pour conclure, chacun doit prendre soin de sa santé en mangeant varié et équilibré.",
              corrige:"Réponses libres. Vérifier : structure argumentative complète, 2 arguments + exemples, 1 contre-argument réfuté, au moins 4 pronoms indéfinis, lexique riche, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle phrase est juxtaposée ?",o:["Les légumes sont riches, ils protègent la santé","Les fruits sont bons et ils apportent des vitamines","Parce que le sucre est mauvais, il faut le limiter","Une alimentation équilibrée est essentielle"],c:0,e:"La virgule est un signe de juxtaposition."},
            {q:"Quel est l'adjectif du nom « alimentation » ?",o:["Alimentaire","Alimenté","Alimentant","Alimentation"],c:0,e:"« Alimentaire »."},
            {q:"Quelle phrase est subordonnée ?",o:["Je pense qu'une bonne alimentation prévient les maladies","Les fruits sont bons et ils apportent des vitamines","Les légumes sont riches, ils protègent","Une alimentation équilibrée est essentielle"],c:0,e:"« Que » introduit une subordonnée."},
            {q:"Quel pronom indéfini signifie « la totalité » ?",o:["Tout","Certains","Quelques-uns","Personne"],c:0,e:"« Tout »."}
          ]},
        {code:'S4',titre:'Évaluation et Consolidation',desc:"Évaluer les acquis lexicaux et syntaxiques sur l'alimentation",objectif:'Évaluation des compétences',
          lecon:{intro:"Cette semaine est consacrée à l'évaluation et à la consolidation des acquis sur le thème de l'alimentation et de la santé. Nous révisons le lexique (nutriments, aliments, maladies), les pronoms indéfinis, les connecteurs logiques, les types de phrases et la production écrite d'un texte argumentatif.",
            points:["Révision du lexique de la nutrition","Révision des pronoms indéfinis","Révision des connecteurs logiques","Révision des phrases simples et complexes","Reformulation en phrases simples","Préparation à l'évaluation finale"],
            ms:"Révision globale : présent de l'indicatif, pronoms indéfinis, connecteurs logiques, types de phrases.",
            lex:["Nutriments : protéines, glucides, lipides, vitamines, minéraux","Aliments : riz, légumes, fruits, viande, poisson, lait, œufs","Maladies : obésité, diabète, malnutrition, carence, anémie"]},
          exosOuverts:[
            {titre:"Complétez la grille de mots croisés",type:"tableau",tag:"LEXIQUE",
              consigne:"Retrouvez le mot correspondant à chaque définition.",
              entetes:["N°","Définition","Mot à trouver"],
              lignes:[
                ["1","Substance nutritive essentielle au corps",""],
                ["2","Aliment riche en énergie (riz, pain, pomme de terre)",""],
                ["3","Boisson essentielle à la vie",""],
                ["4","Repas du matin",""],
                ["5","Habitude de vie saine (manger, bouger…)",""],
                ["6","Manque d'aliments dans l'organisme",""],
                ["7","Excès de poids dû à une mauvaise alimentation",""]
              ],
              corrige:["1. Nutriment","2. Féculent","3. Eau","4. Petit déjeuner","5. Hygiène de vie","6. Malnutrition","7. Obésité"]},
            {titre:"QCM – Choisissez la bonne réponse",type:"qcm-ouvert",tag:"LEXIQUE",
              consigne:"Entourez la bonne réponse.",
              questions:[
                {q:"Quel aliment est riche en protéines ?",o:["Le riz","Le poisson","Le sucre","L'huile"],c:1},
                {q:"Combien de repas équilibrés faut-il par jour ?",o:["1","2","3","5"],c:2},
                {q:"Que signifie « alimentation équilibrée » ?",o:["Manger seulement des fruits","Manger varié et en quantité adaptée","Sauter des repas","Manger seulement le soir"],c:1},
                {q:"Quelle boisson est la meilleure pour la santé ?",o:["Le soda","L'eau","Le café","Le jus sucré"],c:1},
                {q:"Quel est un pronom indéfini ?",o:["Je","Certains","Le mien","Celui"],c:1},
                {q:"Que signifie « malnutrition » ?",o:["Trop manger","Manque d'aliments essentiels","Bien manger","Manger varié"],c:1},
                {q:"Quel est un avantage d'une alimentation variée ?",o:["Être fatigué","Tomber malade","Rester en bonne santé","Prendre du poids"],c:2}
              ],
              corrige:["1. b) Le poisson","2. c) 3","3. b) Manger varié et en quantité adaptée","4. b) L'eau","5. b) Certains","6. b) Manque d'aliments essentiels","7. c) Rester en bonne santé"]},
            {titre:"Complétez avec le pronom indéfini qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec le pronom indéfini approprié choisi parmi : tout, certains, certaines, quelqu'un, quelques-uns, personne, plusieurs.",
              phrases:[
                "___ disent que le petit déjeuner est le repas le plus important. (Certains)",
                "___ les élèves doivent manger équilibré. (Tous)",
                "___ ne respecte pas les règles d'hygiène alimentaire. (Personne)",
                "___ fruits sont riches en vitamines. (Certains)",
                "___ a déjà mangé trop de sucre. (Quelqu'un)",
                "___ légumes sont recommandés chaque jour. (Plusieurs)",
                "___ de mes amis font du sport chaque matin. (Quelques-uns)"
              ]},
            {titre:"Transformez les phrases avec un pronom indéfini",type:"transformation",tag:"SYNTAXE",
              consigne:"Réécrivez chaque phrase en remplaçant le groupe nominal souligné par un pronom indéfini.",
              phrases:[
                "Certains élèves mangent trop de sucre. → Certains mangent trop de sucre.",
                "Plusieurs aliments contiennent des vitamines. → Plusieurs contiennent des vitamines.",
                "Aucune personne ne devrait sauter le petit déjeuner. → Personne ne devrait sauter le petit déjeuner.",
                "Tous les enfants doivent boire de l'eau. → Tous doivent boire de l'eau.",
                "Quelques-uns de mes camarades font du sport. → Quelques-uns font du sport.",
                "Chaque personne doit manger équilibré. → Chacun doit manger équilibré.",
                "Rien n'est plus important que la santé. → Rien n'est plus important que la santé."
              ],
              corrige:["1. Certains mangent trop de sucre.","2. Plusieurs contiennent des vitamines.","3. Personne ne devrait sauter le petit déjeuner.","4. Tous doivent boire de l'eau.","5. Quelques-uns font du sport.","6. Chacun doit manger équilibré.","7. Rien n'est plus important que la santé."]},
            {titre:"Rédigez un texte argumentatif final",type:"production",tag:"EVAL",
              consigne:"Rédigez un texte argumentatif de 8 à 10 phrases sur le sujet : « Pourquoi faut-il adopter une alimentation variée et équilibrée ? ». Utilisez au moins 4 pronoms indéfinis, 2 arguments avec exemples, et terminez par une conclusion personnelle.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : structure complète, 4 pronoms indéfinis, 2 arguments + exemples, conclusion personnelle, cohérence et correction."}
          ],
          exos:[
            {q:"Quel aliment est riche en protéines ?",o:["Le riz","Le poisson","Le sucre","L'huile"],c:1,e:"Le poisson."},
            {q:"Que signifie « malnutrition » ?",o:["Trop manger","Manque d'aliments essentiels","Bien manger","Manger varié"],c:1,e:"Manque d'aliments essentiels."},
            {q:"Quel est un pronom indéfini ?",o:["Je","Certains","Le mien","Celui"],c:1,e:"« Certains »."},
            {q:"Combien de repas équilibrés par jour ?",o:["1","2","3","5"],c:2,e:"3 repas."},
            {q:"Quelle boisson est la meilleure pour la santé ?",o:["Le soda","L'eau","Le café","Le jus sucré"],c:1,e:"L'eau."}
          ]},
        {code:'S5',titre:'Synthèse finale',desc:"Révision générale et auto-évaluation du thème",objectif:'Consolider tous les acquis du thème',
          lecon:{intro:"Cette dernière semaine est consacrée à la synthèse générale du thème de l'alimentation et de la santé. Nous révisons l'ensemble des acquis : le lexique des nutriments et des aliments, les pronoms indéfinis, les connecteurs logiques, les types de phrases, la production écrite d'un texte argumentatif. L'objectif est de consolider les connaissances et de préparer l'évaluation finale.",
            points:["Le lexique : nutriments, aliments, maladies","Les pronoms indéfinis : tout, certains, quelques-uns, personne, plusieurs","Les connecteurs logiques : d'abord, ensuite, enfin, parce que, donc, mais","Les types de phrases : simple, juxtaposée, coordonnée, subordonnée","La structure du texte argumentatif","Les habitudes saines : manger équilibré, bouger, s'hydrater"],
            ms:"Révision globale de toutes les notions du thème.",
            lex:["Protéines, glucides, lipides, vitamines, minéraux","Riz, légumes, fruits, viande, poisson, lait, œufs","Obésité, diabète, malnutrition, carence, anémie"]},
          exosOuverts:[
            {titre:"Rédigez une synthèse finale sur l'alimentation",type:"production",tag:"EVAL",
              consigne:"Rédigez un texte argumentatif complet (introduction + développement + conclusion) sur l'alimentation et la santé. Mobilisez tout le lexique appris, les pronoms indéfinis, et variez la structure des phrases.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : structure complète, lexique riche, pronoms indéfinis variés, types de phrases variés, cohérence et correction."}
          ],
          exos:[
            {q:"Quel nutriment renforce les os ?",o:["Le calcium","Le fer","Les fibres","Les glucides"],c:0,e:"Le calcium."},
            {q:"Quel pronom signifie « aucun » ?",o:["Tout","Certains","Personne","Plusieurs"],c:2,e:"« Personne »."},
            {q:"Quel pronom indéfini est invariable ?",o:["Tout","Certains","Personne","Toutes"],c:2,e:"« Personne »."},
            {q:"Quelle est la structure du texte argumentatif ?",o:["Introduction – Développement – Conclusion","Titre – Chapeau – Dev – Conclusion","Situation initiale – Péripéties – Dénouement","En-tête – Corps – Signature"],c:0,e:"Introduction, développement, conclusion."}
          ]}
      ],
      texte:{titre:"Manger équilibré : un investissement pour la vie",
        contenu:[
          "Une alimentation variée et équilibrée est bien plus qu'une simple habitude : c'est un véritable investissement pour la santé. Les études scientifiques montrent qu'une nutrition adaptée prévient de nombreuses maladies chroniques. Chaque organe de notre corps a besoin d'aliments spécifiques pour bien fonctionner. Pour le cerveau, il faut privilégier le saumon, le thon, la sardine et les noix, riches en oméga-3. Pour les yeux, les œufs, le maïs et les carottes, qui contiennent de la vitamine A.",
          "D'abord, une alimentation riche en fruits et légumes apporte les vitamines et minéraux essentiels au bon fonctionnement de l'organisme. Certains nutriments renforcent le système immunitaire et protègent contre les infections. Ensuite, limiter les sucres ajoutés et les graisses saturées réduit considérablement les risques de diabète de type 2 et de maladies cardiovasculaires. Plusieurs études ont démontré qu'une consommation excessive de sucre est directement liée à l'obésité.",
          "Enfin, adopter une alimentation équilibrée ne signifie pas se priver, mais faire des choix éclairés. Quelques personnes pensent qu'il faut des régimes stricts ; en réalité, la modération et la variété suffisent. Pour rester en bonne santé, il ne suffit pas de manger à sa faim : il faut aussi respecter certains besoins nutritionnels. Au petit déjeuner, les Malgaches prennent souvent de l'« ankera » (restes de la veille) ou des tubercules bouillis. Au déjeuner, le riz accompagne le « romazava », un bouillon de feuilles diverses.",
          "En conclusion, une bonne organisation et une alimentation équilibrée sont les deux piliers de la santé. Personne ne devrait négliger son alimentation, car la santé est notre bien le plus précieux."
        ]},
      questions:[
        {q:"Quelle est la thèse de l'auteur ?",o:["Manger équilibré est une perte de temps","Manger équilibré est un investissement pour la vie","Il faut se priver","Les régimes stricts sont recommandés"],c:1,e:"Investissement pour la vie."},
        {q:"Quel est le premier argument ?",o:["Limiter les sucres","Apport en vitamines et minéraux","Faire des choix éclairés","Éviter les régimes stricts"],c:1,e:"Vitamines et minéraux."},
        {q:"Quel pronom indéfini apparaît ?",o:["Personne","Plusieurs","Quelqu'un","Aucun"],c:1,e:"« Plusieurs »."},
        {q:"Quelle maladie est liée au sucre ?",o:["Rhume","Obésité","Asthme","Allergie"],c:1,e:"Obésité."},
        {q:"Quel connecteur marque la conclusion ?",o:["D'abord","Ensuite","Enfin","Cependant"],c:2,e:"« Enfin »."}
      ],
      lecon:{intro:"L'article de nutrition défend un point de vue sur l'alimentation.",
        structure:[{t:'Introduction',d:"Sujet + thèse."},{t:'Arguments scientifiques',d:"Études, chiffres, experts."},{t:'Exemples concrets',d:"Cas de malnutrition, bienfaits."},{t:'Conclusion',d:"Résumé + encouragement."}],
        ex:"Une alimentation variée prévient le diabète et l'obésité. Certains nutriments renforcent le système immunitaire.",
        ms:"Les pronoms indéfinis remplacent les noms : tout, certains, quelques-uns, personne, plusieurs."},
      lexique:["Nutriments : glucides, lipides, protéines, vitamines, minéraux","Besoins nutritionnels quotidiens","Avantages d'une alimentation équilibrée"],
      ms:["Les pronoms indéfinis : tout, certains, quelques-uns, personne, plusieurs"],
      exos:[
        {q:"Principaux nutriments essentiels ?",o:["Glucides, lipides, protéines, vitamines, minéraux","Sucres, graisses, sel","Eau, fibres, air","Protéines uniquement"],c:0,e:"5 nutriments essentiels."},
        {q:"« ____ personnes préfèrent manger équilibré. »",o:["Tout","Certaines","Quelqu'un","Personne"],c:1,e:"« Certaines »."},
        {q:"Fruits et légumes recommandés par jour ?",o:["1-2","3-4","5","10"],c:2,e:"5 par jour."},
        {q:"Pronom indéfini signifiant « aucun » ?",o:["Tout","Plusieurs","Personne","Quelqu'un"],c:2,e:"« Personne »."},
        {q:"Maladie liée à mauvaise alimentation ?",o:["Rhume","Diabète","Asthme","Allergie"],c:1,e:"Diabète."}
      ]}
  ]},
  /* ============================================================
     PÉRIODE 4 : TEXTE ADMINISTRATIF
     ============================================================ */
  p4:{id:'p4',titre:'Texte Administratif',desc:"Compte rendu, offre d'emploi, CV",sem:10,c:'#a86a00',cd:'#7d4e00',cb:'rgba(168,106,0,.12)',themes:[
    /* THÈME 4.1 : MÉDIAS & TECHNOLOGIES */
    {id:'medias',titre:"Médias & Technologies",desc:"Compte rendu, sécurité en ligne",type:'Administratif : compte rendu',v:"Respect d'autrui, autonomie",
      semaines:[
        {code:'S1',titre:'Découverte et Compréhension',desc:"Découvrir le lexique des médias et les phrases impersonnelles",objectif:'Compréhension globale et lexique de base',
          lecon:{intro:"Les médias jouent un rôle essentiel dans notre société moderne. Ils nous informent, nous divertissent et nous permettent de communiquer. Les principaux types de médias sont : la presse écrite, la radio, la télévision et les médias en ligne. Les nouvelles technologies de l'information et de la communication (NTIC) ont bouleversé nos modes de vie : smartphones, tablettes, ordinateurs connectés, Internet. Les phrases impersonnelles (il faut, il est important, il est essentiel, il est nécessaire) permettent de donner des conseils ou des recommandations de manière objective, sans désigner une personne en particulier.",
            points:["Les types de médias : presse écrite, radio, télévision, médias en ligne","Les NTIC : Internet, smartphones, tablettes, ordinateurs","Le lexique numérique : mot de passe, télécharger, naviguer, partager","Les phrases impersonnelles : il faut, il est important, il est essentiel","Le pronom impersonnel « il » ne représente personne","Les risques : cyberharcèlement, arnaque, désinformation"],
            ms:"Le pronom impersonnel « il » ne représente personne. Il est utilisé dans des expressions comme : il faut, il est important, il est essentiel, il est nécessaire, il est possible, il est utile, il est recommandé. Ces expressions permettent de donner des conseils de manière neutre et objective.",
            lex:["Médias : presse écrite, radio, télévision, médias en ligne","NTIC : Internet, smartphone, tablette, ordinateur","Numérique : mot de passe, télécharger, naviguer, partager"]},
          exosOuverts:[
            {titre:"Associez chaque mot à sa définition",type:"tableau",tag:"LEXIQUE",
              consigne:"Reliez chaque mot de la colonne A à sa définition dans la colonne B.",
              entetes:["N°","Colonne A (Mot)","Colonne B (Définition)","Réponse"],
              lignes:[
                ["1","Presse écrite","A. Émission d'informations à la radio",""],
                ["2","Télévision","B. Ensemble des journaux et magazines",""],
                ["3","Radio","C. Moyen de communication diffusant des images et des sons",""],
                ["4","Internet","D. Réseau mondial d'information",""],
                ["5","Réseaux sociaux","E. Plateformes d'échange en ligne",""],
                ["6","Journaliste","F. Personne qui collecte et présente les informations",""],
                ["7","Information","G. Nouvelle transmise au public",""]
              ],
              corrige:["1 → B","2 → C","3 → A","4 → D","5 → E","6 → F","7 → G"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : ordinateur, téléphone portable, tablette, mot de passe, cyberharcèlement, arnaque, informations personnelles.",
              phrases:[
                "Un ___ est un appareil électronique qui permet de traiter des données. (ordinateur)",
                "Le ___ est un appareil de communication mobile très utilisé. (téléphone portable)",
                "Une ___ est un appareil tactile plus grand qu'un téléphone. (tablette)",
                "Il faut choisir un ___ solide pour protéger ses comptes en ligne. (mot de passe)",
                "Le ___ est une forme de violence en ligne. (cyberharcèlement)",
                "Une ___ en ligne est une tentative de tromperie sur Internet. (arnaque)",
                "Il ne faut jamais partager ses ___ avec des inconnus. (informations personnelles)"
              ]},
            {titre:"Complétez avec la forme impersonnelle qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec la forme impersonnelle appropriée choisie parmi : il faut, il est important, il est essentiel, il est nécessaire, il est possible, il est utile, il est recommandé.",
              phrases:[
                "___ de protéger ses informations personnelles en ligne. (Il est important)",
                "___ sensibiliser les jeunes aux dangers d'Internet. (Il faut)",
                "___ de vérifier la source des informations avant de les partager. (Il est essentiel)",
                "___ d'utiliser des mots de passe solides. (Il est nécessaire)",
                "___ de signaler les contenus suspects. (Il est recommandé)",
                "___ d'apprendre à utiliser les nouvelles technologies. (Il est utile)",
                "___ de respecter les autres sur les réseaux sociaux. (Il est essentiel)"
              ]},
            {titre:"Rédigez un court compte rendu de réunion",type:"production",tag:"SYNTAXE",
              consigne:"Imaginez que vous avez participé à une réunion sur la sécurité en ligne. Rédigez un court compte rendu de 4 à 5 phrases. Utilisez au moins 3 formes impersonnelles.",
              lignes:5,
              exemple:"Hier, j'ai participé à une réunion sur la sécurité en ligne. Il est important de sensibiliser les élèves aux dangers d'Internet. Il faut protéger ses informations personnelles et utiliser des mots de passe solides. Il est recommandé de signaler tout contenu suspect. Enfin, il est essentiel de respecter les autres sur les réseaux sociaux.",
              corrige:"Réponses libres. Vérifier : présence d'au moins 3 formes impersonnelles, cohérence du compte rendu (4 à 5 phrases), mobilisation du lexique des médias et NTIC."}
          ],
          exos:[
            {q:"Quel est un type de média ?",o:["Presse écrite","Cuisine","Voyage","Sport"],c:0,e:"La presse écrite est un type de média."},
            {q:"Qu'est-ce qu'une phrase impersonnelle ?",o:["Une phrase avec « il » qui ne représente personne","Une phrase avec « je »","Une phrase avec « tu »","Une phrase interrogative"],c:0,e:"Le pronom « il » impersonnel ne représente personne."},
            {q:"Que signifie « cyberharcèlement » ?",o:["Harcèlement en ligne","Harcèlement à l'école","Harcèlement au travail","Harcèlement de rue"],c:0,e:"Le cyberharcèlement est un harcèlement en ligne."},
            {q:"Que faut-il faire pour protéger ses comptes ?",o:["Choisir un mot de passe solide","Partager son mot de passe","Utiliser le même mot de passe partout","Ne pas mettre de mot de passe"],c:0,e:"Il faut choisir un mot de passe solide."},
            {q:"Que signifie « NTIC » ?",o:["Nouvelles Technologies de l'Information et de la Communication","Nouvelles Techniques Informatiques Courantes","Numérique et Technologies","Aucune"],c:0,e:"Nouvelles Technologies de l'Information et de la Communication."}
          ]},
        {code:'S2',titre:'Approfondissement Lexical',desc:"Approfondir le lexique des risques numériques et la forme passive",objectif:'Maîtriser la forme passive',
          lecon:{intro:"Les médias et les NTIC présentent aussi des risques. La cybercriminalité, les arnaques en ligne, le cyberharcèlement et la désinformation menacent les utilisateurs. Les fake news, ou fausses informations, se propagent rapidement sur les réseaux sociaux. Les jeunes sont particulièrement exposés à l'addiction aux écrans et aux contenus inappropriés. La forme passive permet de mettre en valeur l'action ou le résultat plutôt que l'agent. Elle se forme avec l'auxiliaire « être » + participe passé. Exemple : Les informations sont diffusées par les journalistes. Le COD de la phrase active devient sujet de la phrase passive.",
            points:["Les risques : cybercriminalité, arnaque, cyberharcèlement, désinformation","Les fake news se propagent sur les réseaux sociaux","L'addiction aux écrans chez les jeunes","La forme passive : être + participe passé","Le COD de l'active devient sujet de la passive","L'agent est introduit par « par »"],
            ms:"La forme passive se forme avec l'auxiliaire « être » + participe passé. Le COD de la phrase active devient sujet. L'agent (celui qui fait l'action) est introduit par « par ». Exemple : Les journalistes diffusent les informations → Les informations sont diffusées par les journalistes.",
            lex:["Risques : cybercriminalité, arnaque, cyberharcèlement","Désinformation, fake news, addiction","Confidentialité, protection, influence"]},
          exosOuverts:[
            {titre:"Classez les mots selon leur catégorie",type:"tableau",tag:"LEXIQUE",
              consigne:"Classez chaque mot dans la bonne colonne : outil, action, risque ou usage.",
              entetes:["N°","Mot","Catégorie"],
              lignes:[
                ["1","Smartphone","Outil"],
                ["2","Télécharger","Action"],
                ["3","Cyberharcèlement","Risque"],
                ["4","Naviguer","Action"],
                ["5","Arnaque en ligne","Risque"],
                ["6","Partager","Action"],
                ["7","Réseau social","Usage"]
              ],
              corrige:["1 → Outil","2 → Action","3 → Risque","4 → Action","5 → Risque","6 → Action","7 → Usage"]},
            {titre:"Complétez et transformez les phrases",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : cybercriminalité, addiction, désinformation, confidentialité, influence, contenus inappropriés, protection.",
              phrases:[
                "La ___ est un fléau qui touche les utilisateurs d'Internet. (cybercriminalité)",
                "L'___ aux écrans est un problème chez les jeunes. (addiction)",
                "La ___ consiste à diffuser de fausses informations. (désinformation)",
                "La ___ des données personnelles est essentielle. (confidentialité)",
                "Les influenceurs ont une grande ___ sur les jeunes. (influence)",
                "Les ___ peuvent nuire aux enfants. (contenus inappropriés)",
                "La ___ des mineurs en ligne est une priorité. (protection)"
              ]},
            {titre:"Transformez les phrases actives en phrases passives",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase active en phrase passive.",
              phrases:[
                "Les journalistes diffusent les informations. → Les informations sont diffusées par les journalistes.",
                "Les entreprises développent de nouvelles applications. → De nouvelles applications sont développées par les entreprises.",
                "Les parents contrôlent l'usage d'Internet. → L'usage d'Internet est contrôlé par les parents.",
                "Les élèves consultent les sites éducatifs. → Les sites éducatifs sont consultés par les élèves.",
                "Les pirates informatiques attaquent les serveurs. → Les serveurs sont attaqués par les pirates informatiques.",
                "Les gouvernements protègent les données des citoyens. → Les données des citoyens sont protégées par les gouvernements.",
                "Les utilisateurs partagent des informations personnelles. → Des informations personnelles sont partagées par les utilisateurs."
              ],
              corrige:["1. Les informations sont diffusées par les journalistes.","2. De nouvelles applications sont développées par les entreprises.","3. L'usage d'Internet est contrôlé par les parents.","4. Les sites éducatifs sont consultés par les élèves.","5. Les serveurs sont attaqués par les pirates informatiques.","6. Les données des citoyens sont protégées par les gouvernements.","7. Des informations personnelles sont partagées par les utilisateurs."]},
            {titre:"Complétez chaque phrase par une proposition de votre choix",type:"production",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase par une proposition personnelle en respectant la structure passive ou impersonnelle indiquée.",
              lignes:9,
              exemple:"Les informations sont diffusées par les journalistes. / Il est important de vérifier la source des informations.",
              phrases:[
                "Les informations sont diffusées...",
                "Les données personnelles doivent être protégées...",
                "Il est important de...",
                "Les réseaux sociaux sont utilisés...",
                "Il faut...",
                "Les contenus inappropriés sont signalés...",
                "Il est essentiel de...",
                "Les élèves sont sensibilisés...",
                "Il est recommandé de..."
              ],
              corrige:"Réponses libres. Vérifier : cohérence avec la structure indiquée (passive ou impersonnelle), correction grammaticale et orthographique."},
            {titre:"Rédigez un paragraphe argumentatif sur les NTIC",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un paragraphe argumentatif de 6 à 8 phrases pour défendre l'idée suivante : « Les nouvelles technologies présentent autant d'avantages que d'inconvénients ». Utilisez au moins 3 phrases passives et 2 formes impersonnelles.",
              lignes:8,
              exemple:"Les nouvelles technologies présentent autant d'avantages que d'inconvénients. D'abord, la communication est facilitée par Internet : les messages sont envoyés en quelques secondes. Ensuite, les informations sont partagées rapidement sur les réseaux sociaux. Cependant, il faut protéger ses données personnelles car des arnaques sont régulièrement signalées. Il est également important de limiter le temps passé devant les écrans. Enfin, il est essentiel d'éduquer les jeunes à un usage responsable du numérique. Pour conclure, il est recommandé d'utiliser les technologies avec prudence.",
              corrige:"Réponses libres. Vérifier : au moins 3 phrases passives, 2 formes impersonnelles, 2 arguments avec exemples, conclusion personnelle."}
          ],
          exos:[
            {q:"Quel est un risque d'Internet ?",o:["Apprendre","Communiquer","Arnaque en ligne","Se cultiver"],c:2,e:"L'arnaque en ligne est un risque."},
            {q:"Comment se forme la voix passive ?",o:["Être + participe passé","Avoir + participe passé","Être + infinitif","Avoir + infinitif"],c:0,e:"Être + participe passé."},
            {q:"Que signifie « fake news » ?",o:["Bonne nouvelle","Fausse information","Publicité","Journal officiel"],c:1,e:"Fausse information."},
            {q:"Qu'est-ce que la désinformation ?",o:["Diffusion de fausses informations","Information vraie","Publicité","Journalisme"],c:0,e:"La diffusion de fausses informations."},
            {q:"Quelle phrase est à la forme passive ?",o:["Les jeunes utilisent Internet","Internet est utilisé par les jeunes","Utilise Internet","Internet, c'est utile"],c:1,e:"« Internet est utilisé par les jeunes. »"}
          ]},
        {code:'S3',titre:'Structuration et Production',desc:"Maîtriser la structure du compte rendu et produire un texte complet",objectif:'Produire un compte rendu complet',
          lecon:{intro:"Le compte rendu est un texte administratif qui rapporte objectivement les informations d'une réunion. Il suit une structure claire : en-tête (date, lieu, participants, objet), déroulement (résumé des discussions), décisions prises (mesures adoptées), conclusion (synthèse et engagement). Pour enrichir sa production, il faut utiliser un lexique précis, des phrases impersonnelles et passives, et varier la structure des phrases.",
            points:["Structure : en-tête, déroulement, décisions, conclusion","En-tête : date, lieu, participants, objet","Déroulement : résumé des discussions","Décisions : mesures adoptées","Conclusion : synthèse + engagement","Utiliser les phrases impersonnelles et passives","Enrichir ses phrases avec des synonymes précis"],
            ms:"Le compte rendu est objectif et neutre. Il utilise des phrases impersonnelles (il faut, il est important) et des phrases passives (les décisions ont été prises). Les synonymes précis (considérable, majeur, profond) enrichissent le texte.",
            lex:["Synonymes précis : considérable, majeur, profond","Familles de mots : média/médiatique, numérique/numérisation","Connecteurs logiques","Structure du compte rendu"]},
          exosOuverts:[
            {titre:"Enrichissez vos phrases",type:"transformation",tag:"LEXIQUE",
              consigne:"Remplacez le mot souligné par un synonyme plus précis et plus expressif.",
              phrases:[
                "Internet est un outil utile pour les élèves. → précieux / indispensable / essentiel",
                "Les réseaux sociaux ont un impact important sur les jeunes. → considérable / majeur / profond",
                "Les fake news sont dangereuses pour la société. → nuisibles / préjudiciables / néfastes",
                "Les informations diffusées sont rapides. → instantanées / immédiates",
                "Les smartphones sont chers pour certains ménages. → onéreux / coûteux",
                "Les jeux vidéo peuvent être mauvais pour la santé. → nuisibles / néfastes",
                "L'usage des écrans est fréquent chez les adolescents. → récurrent / habituel"
              ],
              corrige:["1. précieux / indispensable / essentiel","2. considérable / majeur / profond","3. nuisibles / préjudiciables / néfastes","4. instantanées / immédiates","5. onéreux / coûteux","6. nuisibles / néfastes","7. récurrent / habituel"]},
            {titre:"Complétez avec le lexique approprié",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : cybercriminalité, addiction, désinformation, confidentialité, influence, contenus inappropriés, protection.",
              phrases:[
                "La ___ est un fléau qui touche les utilisateurs d'Internet. (cybercriminalité)",
                "L'___ aux écrans est un problème chez les jeunes. (addiction)",
                "La ___ consiste à diffuser de fausses informations. (désinformation)",
                "La ___ des données personnelles est essentielle. (confidentialité)",
                "Les influenceurs ont une grande ___ sur les jeunes. (influence)",
                "Les ___ peuvent nuire aux enfants. (contenus inappropriés)",
                "La ___ des mineurs en ligne est une priorité. (protection)"
              ]},
            {titre:"Transformez les phrases (passif ↔ actif)",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase active en phrase passive (ou inversement).",
              phrases:[
                "Les journalistes diffusent les informations. → Les informations sont diffusées par les journalistes.",
                "Les applications sont développées par les entreprises. → Les entreprises développent les applications.",
                "Les parents contrôlent l'usage d'Internet. → L'usage d'Internet est contrôlé par les parents.",
                "Les sites éducatifs sont consultés par les élèves. → Les élèves consultent les sites éducatifs.",
                "Les pirates informatiques attaquent les serveurs. → Les serveurs sont attaqués par les pirates informatiques.",
                "Les données des citoyens sont protégées par les gouvernements. → Les gouvernements protègent les données des citoyens.",
                "Les utilisateurs partagent des informations personnelles. → Des informations personnelles sont partagées par les utilisateurs."
              ],
              corrige:["1. Les informations sont diffusées par les journalistes.","2. Les entreprises développent les applications.","3. L'usage d'Internet est contrôlé par les parents.","4. Les élèves consultent les sites éducatifs.","5. Les serveurs sont attaqués par les pirates informatiques.","6. Les gouvernements protègent les données des citoyens.","7. Des informations personnelles sont partagées par les utilisateurs."]},
            {titre:"Analysez la structure des phrases",type:"tableau",tag:"SYNTAXE",
              consigne:"Indiquez si chaque phrase est simple, juxtaposée, coordonnée ou subordonnée.",
              entetes:["N°","Phrase","Type"],
              lignes:[
                ["1","Internet est un outil puissant.","Simple"],
                ["2","Les jeunes utilisent Internet et ils partagent des informations.","Coordonnée"],
                ["3","Les réseaux sociaux attirent, les utilisateurs se connectent.","Juxtaposée"],
                ["4","Parce que les fake news circulent, les citoyens sont méfiants.","Subordonnée"],
                ["5","Les technologies sont utiles mais elles présentent des risques.","Coordonnée"],
                ["6","Je pense que la sensibilisation est essentielle.","Subordonnée"],
                ["7","Les élèves consultent, ils apprennent, ils partagent.","Juxtaposée"]
              ],
              corrige:["1. Simple","2. Coordonnée (et)","3. Juxtaposée (virgule)","4. Subordonnée (parce que)","5. Coordonnée (mais)","6. Subordonnée (que)","7. Juxtaposée (virgules)"]},
            {titre:"Rédigez un compte rendu complet",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un compte rendu de 8 à 10 phrases sur une réunion qui s'est tenue dans votre établissement pour discuter des avantages et inconvénients des réseaux sociaux. Respectez la structure : en-tête, déroulement, décisions, conclusion. Utilisez au moins 3 formes impersonnelles et 2 phrases passives.",
              lignes:10,
              exemple:"Compte rendu de la réunion sur les réseaux sociaux. Date : 15 avril 2024. Lieu : salle polyvalente. Participants : élèves de T9, enseignants, administration. Objet : discuter des avantages et inconvénients des réseaux sociaux. La réunion a débuté par une présentation des usages des réseaux sociaux. Il a été souligné que ces plateformes facilitent la communication. Cependant, des risques ont été identifiés : cyberharcèlement, addiction, désinformation. Il est important de sensibiliser les jeunes à un usage responsable. Il faut protéger les données personnelles. Il a été décidé de créer un atelier mensuel sur la sécurité numérique. Un règlement d'utilisation sera proposé par les enseignants. En conclusion, il est essentiel d'éduquer les élèves aux bonnes pratiques numériques.",
              corrige:"Réponses libres. Vérifier : présence des 4 parties (en-tête, déroulement, décisions, conclusion), au moins 3 formes impersonnelles, au moins 2 phrases passives, cohérence et correction."}
          ],
          exos:[
            {q:"Quelle est la structure du compte rendu ?",o:["En-tête, déroulement, décisions, conclusion","Introduction, développement, conclusion","Titre, chapeau, corps","Situation initiale, péripéties"],c:0,e:"En-tête, déroulement, décisions, conclusion."},
            {q:"Quelle phrase est coordonnée ?",o:["Les technologies sont utiles mais elles présentent des risques","Les élèves consultent, ils apprennent","Parce que les fake news circulent, les citoyens sont méfiants","Internet est un outil"],c:0,e:"« Mais » est une conjonction de coordination."},
            {q:"Quel est l'adjectif du nom « média » ?",o:["Médiatique","Médian","Médiateur","Médiocre"],c:0,e:"« Médiatique »."},
            {q:"Quelle phrase est subordonnée ?",o:["Je pense que la sensibilisation est essentielle","Les jeunes utilisent Internet et ils partagent","Les élèves consultent, ils apprennent","Internet est un outil"],c:0,e:"« Que » introduit une subordonnée."}
          ]},
        {code:'S4',titre:'Évaluation et Consolidation',desc:"Évaluer les acquis lexicaux et syntaxiques sur les médias et NTIC",objectif:'Évaluation des compétences',
          lecon:{intro:"Cette semaine est consacrée à l'évaluation et à la consolidation des acquis sur le thème des médias et des NTIC. Nous révisons le lexique (types de médias, termes numériques, risques), les formes impersonnelles, la voix passive/active, les types de phrases, la transformation et la production écrite d'un compte rendu.",
            points:["Révision du lexique des médias et NTIC","Révision des formes impersonnelles","Révision de la voix passive et active","Révision des types de phrases","Reformulation en phrases simples","Préparation à l'évaluation finale"],
            ms:"Révision globale : présent de l'indicatif, formes impersonnelles, voix passive/active, types de phrases.",
            lex:["Médias : presse, radio, télévision, réseaux sociaux","NTIC : Internet, smartphone, tablette, ordinateur","Risques : cybercriminalité, arnaque, cyberharcèlement, désinformation"]},
          exosOuverts:[
            {titre:"Complétez la grille de mots croisés",type:"tableau",tag:"LEXIQUE",
              consigne:"Retrouvez le mot correspondant à chaque définition.",
              entetes:["N°","Définition","Mot à trouver"],
              lignes:[
                ["1","Réseau mondial d'information",""],
                ["2","Plateforme d'échange en ligne",""],
                ["3","Forme de violence en ligne",""],
                ["4","Fausse information diffusée sur Internet",""],
                ["5","Dépendance aux écrans",""],
                ["6","Protection des données personnelles",""],
                ["7","Personne qui collecte les informations",""]
              ],
              corrige:["1. Internet","2. Réseau social","3. Cyberharcèlement","4. Fake news / Désinformation","5. Addiction","6. Confidentialité","7. Journaliste"]},
            {titre:"QCM – Choisissez la bonne réponse",type:"qcm-ouvert",tag:"LEXIQUE",
              consigne:"Entourez la bonne réponse.",
              questions:[
                {q:"Que signifie « fake news » ?",o:["Bonne nouvelle","Fausse information","Journal officiel","Publicité"],c:1},
                {q:"Quel est un réseau social ?",o:["Le Figaro","Facebook","Le Monde","RFI"],c:1},
                {q:"Que signifie « cyberharcèlement » ?",o:["Harcèlement en ligne","Harcèlement à l'école","Harcèlement au travail","Harcèlement de rue"],c:0},
                {q:"Quel est un pronom impersonnel ?",o:["Je","Il (dans « il faut »)","Celui","Le mien"],c:1},
                {q:"Quelle phrase est à la forme passive ?",o:["Les jeunes utilisent Internet","Internet est utilisé par les jeunes","Utilise Internet !","Internet, c'est utile"],c:1},
                {q:"Que signifie « désinformation » ?",o:["Information vraie","Diffusion de fausses informations","Publicité","Journalisme"],c:1},
                {q:"Quel est un danger d'Internet ?",o:["Apprendre","Communiquer","Arnaque en ligne","Se cultiver"],c:2}
              ],
              corrige:["1. b) Fausse information","2. b) Facebook","3. a) Harcèlement en ligne","4. b) Il (dans « il faut »)","5. b) Internet est utilisé par les jeunes.","6. b) Diffusion de fausses informations","7. c) Arnaque en ligne"]},
            {titre:"Complétez avec la forme impersonnelle ou passive qui convient",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase avec la forme appropriée.",
              phrases:[
                "___ de protéger ses données personnelles. (Il faut)",
                "Les informations ___ par les journalistes. (sont diffusées)",
                "___ de sensibiliser les jeunes aux dangers d'Internet. (Il est important)",
                "Les réseaux sociaux ___ par des millions d'utilisateurs. (sont utilisés)",
                "___ de vérifier la source des informations. (Il est essentiel)",
                "Les contenus inappropriés ___ par les modérateurs. (sont signalés)",
                "___ de limiter le temps passé devant les écrans. (Il est recommandé)"
              ]},
            {titre:"Transformez les phrases",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase selon l'indication donnée.",
              phrases:[
                "Les élèves consultent les sites éducatifs. (forme passive) → Les sites éducatifs sont consultés par les élèves.",
                "Les fake news sont diffusées par les internautes. (forme active) → Les internautes diffusent les fake news.",
                "Il faut protéger les mineurs en ligne. (reformuler avec « il est essentiel ») → Il est essentiel de protéger les mineurs en ligne.",
                "Les parents contrôlent l'usage d'Internet. (forme passive) → L'usage d'Internet est contrôlé par les parents.",
                "Les données sont protégées par les gouvernements. (forme active) → Les gouvernements protègent les données.",
                "Il est important de respecter les autres en ligne. (reformuler avec « il faut ») → Il faut respecter les autres en ligne.",
                "Les utilisateurs partagent des informations personnelles. (forme passive) → Des informations personnelles sont partagées par les utilisateurs."
              ],
              corrige:["1. Les sites éducatifs sont consultés par les élèves.","2. Les internautes diffusent les fake news.","3. Il est essentiel de protéger les mineurs en ligne.","4. L'usage d'Internet est contrôlé par les parents.","5. Les gouvernements protègent les données.","6. Il faut respecter les autres en ligne.","7. Des informations personnelles sont partagées par les utilisateurs."]},
            {titre:"Rédigez un compte rendu final",type:"production",tag:"EVAL",
              consigne:"Rédigez un compte rendu de 8 à 10 phrases sur le sujet : « Réunion sur l'usage responsable des réseaux sociaux ». Respectez la structure du compte rendu, utilisez au moins 3 formes impersonnelles et 2 phrases passives.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : structure complète, 3 formes impersonnelles, 2 phrases passives, lexique des médias, cohérence et correction."}
          ],
          exos:[
            {q:"Que signifie « fake news » ?",o:["Bonne nouvelle","Fausse information","Journal officiel","Publicité"],c:1,e:"Fausse information."},
            {q:"Que signifie « cyberharcèlement » ?",o:["Harcèlement en ligne","Harcèlement à l'école","Harcèlement au travail","Harcèlement de rue"],c:0,e:"Harcèlement en ligne."},
            {q:"Quel est un pronom impersonnel ?",o:["Je","Il (dans « il faut »)","Celui","Le mien"],c:1,e:"Le pronom impersonnel « il »."},
            {q:"Quelle phrase est à la forme passive ?",o:["Les jeunes utilisent Internet","Internet est utilisé par les jeunes","Utilise Internet !","Internet, c'est utile"],c:1,e:"« Internet est utilisé par les jeunes. »"},
            {q:"Que signifie « désinformation » ?",o:["Information vraie","Diffusion de fausses informations","Publicité","Journalisme"],c:1,e:"Diffusion de fausses informations."}
          ]},
        {code:'S5',titre:'Synthèse finale',desc:"Révision générale et auto-évaluation du thème",objectif:'Consolider tous les acquis du thème',
          lecon:{intro:"Cette dernière semaine est consacrée à la synthèse générale du thème des médias et des NTIC. Nous révisons l'ensemble des acquis : le lexique des médias et du numérique, les risques liés à Internet, les formes impersonnelles, la voix passive/active, les types de phrases et la production écrite d'un compte rendu. L'objectif est de consolider les connaissances et de préparer l'évaluation finale.",
            points:["Le lexique : médias, NTIC, risques numériques","Les formes impersonnelles : il faut, il est important","La voix passive et active","Les types de phrases : simple, juxtaposée, coordonnée, subordonnée","La structure du compte rendu","La citoyenneté numérique responsable"],
            ms:"Révision globale de toutes les notions du thème.",
            lex:["Médias : presse, radio, télévision, réseaux sociaux","NTIC : Internet, smartphone, tablette","Risques : cybercriminalité, arnaque, cyberharcèlement"]},
          exosOuverts:[
            {titre:"Rédigez une synthèse finale sur les médias",type:"production",tag:"EVAL",
              consigne:"Rédigez un compte rendu complet (en-tête + déroulement + décisions + conclusion) sur les médias et les NTIC. Mobilisez tout le lexique appris, les formes impersonnelles et la voix passive.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : structure complète, lexique riche, formes impersonnelles variées, voix passive, cohérence et correction."}
          ],
          exos:[
            {q:"Quel est un type de média ?",o:["Presse écrite","Cuisine","Voyage","Sport"],c:0,e:"Presse écrite."},
            {q:"Quel est un danger d'Internet ?",o:["Apprendre","Communiquer","Arnaque en ligne","Se cultiver"],c:2,e:"Arnaque en ligne."},
            {q:"Comment se forme la voix passive ?",o:["Être + participe passé","Avoir + participe passé","Être + infinitif","Avoir + infinitif"],c:0,e:"Être + participe passé."},
            {q:"Quelle est la structure du compte rendu ?",o:["En-tête, déroulement, décisions, conclusion","Introduction, développement, conclusion","Titre, chapeau, corps","Situation initiale, péripéties"],c:0,e:"En-tête, déroulement, décisions, conclusion."},
            {q:"Que signifie « NTIC » ?",o:["Nouvelles Technologies de l'Information et de la Communication","Nouvelles Techniques Informatiques","Numérique et Technologies","Aucune"],c:0,e:"Nouvelles Technologies de l'Information et de la Communication."}
          ]}
      ],
      texte:{titre:"Les médias et les nouvelles technologies : entre opportunités et risques",
        contenu:[
          "Les médias jouent un rôle essentiel dans notre société moderne. Ils nous informent sur les événements locaux et internationaux, nous divertissent et nous permettent de communiquer. La presse écrite, la radio, la télévision et les médias en ligne sont les principaux types de médias. Chacun a ses spécificités : la presse écrite est plus détaillée, la radio est plus réactive, la télévision est plus visuelle, et les médias en ligne sont plus interactifs. Aujourd'hui, Internet et les réseaux sociaux transforment profondément notre rapport à l'information.",
          "Les nouvelles technologies de l'information et de la communication (NTIC) ont bouleversé nos modes de vie. Les smartphones, les tablettes et les ordinateurs connectés permettent de rester en contact avec le monde entier. Les élèves utilisent Internet pour apprendre, les familles pour communiquer, les entreprises pour se développer. En 2024, plus de 5 milliards de personnes dans le monde utilisent Internet, et ce chiffre ne cesse de croître.",
          "Cependant, les médias et les NTIC présentent aussi des risques. La cybercriminalité, les arnaques en ligne, le cyberharcèlement et la désinformation menacent les utilisateurs. Les fake news, ou fausses informations, se propagent rapidement sur les réseaux sociaux. Les jeunes sont particulièrement exposés à l'addiction aux écrans et aux contenus inappropriés. Il faut donc apprendre à utiliser ces outils de manière responsable.",
          "Pour protéger les utilisateurs, plusieurs mesures sont mises en place. Il est important de ne jamais partager ses informations personnelles avec des inconnus. Il faut choisir des mots de passe solides et éviter de cliquer sur des liens suspects. Il est également essentiel de vérifier la source des informations avant de les partager. Les parents doivent contrôler l'usage d'Internet par leurs enfants, et les enseignants sensibiliser les élèves aux dangers du numérique.",
          "En conclusion, les médias et les nouvelles technologies sont à la fois des opportunités et des défis. Il ne suffit pas de les utiliser : il faut apprendre à s'en servir intelligemment. Une éducation aux médias et au numérique est indispensable pour former des citoyens responsables et critiques."
        ]},
      questions:[
        {q:"Quels sont les principaux types de médias ?",o:["Presse écrite, radio, télévision, médias en ligne","Facebook, Instagram, Twitter","Livres, revues, magazines","Blogs, forums, wikis"],c:0,e:"La presse écrite, la radio, la télévision et les médias en ligne."},
        {q:"Quels appareils connectés utilisent les NTIC ?",o:["Smartphones, tablettes, ordinateurs","Téléphones fixes, fax","Radios, téléviseurs","Aucun appareil"],c:0,e:"Smartphones, tablettes, ordinateurs."},
        {q:"Quels sont les risques liés aux médias et aux NTIC ?",o:["Cybercriminalité, arnaques, cyberharcèlement, désinformation","Apprendre, communiquer, se divertir","Lire, écrire, compter","Se reposer, dormir, rêver"],c:0,e:"Cybercriminalité, arnaques, cyberharcèlement, désinformation."},
        {q:"Que faut-il faire pour protéger ses données personnelles ?",o:["Partager ses mots de passe avec des amis","Utiliser des mots de passe solides et éviter les liens suspects","Cliquer sur tous les liens reçus","Donner son numéro à tous les inconnus"],c:1,e:"Utiliser des mots de passe solides et éviter les liens suspects."},
        {q:"Quelle est la conclusion du texte ?",o:["Les NTIC sont inutiles","Les NTIC sont à la fois des opportunités et des défis","Les NTIC sont dangereuses et doivent être interdites","Les NTIC ne concernent que les adultes"],c:1,e:"Les NTIC sont à la fois des opportunités et des défis."}
      ],
      lecon:{intro:"Le compte rendu est un texte administratif qui rapporte objectivement les informations d'une réunion.",
        structure:[{t:'En-tête',d:"Date, lieu, participants, objet."},{t:'Déroulement',d:"Résumé des discussions."},{t:'Décisions',d:"Mesures adoptées."},{t:'Conclusion',d:"Synthèse et engagement."}],
        ex:"Compte rendu de la réunion sur la sécurité en ligne — 15 mars 2025.",
        ms:"Phrases impersonnelles (il faut, il est nécessaire) et phrases passives (le document a été signé)."},
      lexique:["Types de médias : presse écrite, radio, télévision, réseaux sociaux","Nouvelles technologies : Internet, smartphones, tablettes","Sécurité en ligne : cybercriminalité, arnaque, désinformation"],
      ms:["Les pronoms impersonnels sujet « il »","Les phrases impersonnelles","Les phrases passives, actives"],
      exos:[
        {q:"Ton d'un compte rendu ?",o:["Subjectif","Objectif et neutre","Humoristique","Poétique"],c:1,e:"Objectif et neutre."},
        {q:"Quelle phrase est impersonnelle ?",o:["Je pense qu'il faut étudier","Il faut protéger ses données","Nous devons être prudents","Tu dois vérifier"],c:1,e:"« Il faut »."},
        {q:"Voix passive de « Le journaliste rédige l'article » ?",o:["L'article est rédigé par le journaliste","L'article rédige le journaliste","Le journaliste est rédigé","L'article a rédigé"],c:0,e:"COD devient sujet."},
        {q:"Cybercriminalité ?",o:["Crime dans la rue","Crime via Internet","Crime politique","Crime passionnel"],c:1,e:"Via Internet."},
        {q:"Que ne contient PAS un compte rendu ?",o:["En-tête","Développement","Opinion personnelle","Signature"],c:2,e:"Opinion personnelle."}
      ]},
    /* THÈME 4.2 : MÉTIERS & PROFESSIONS */
    {id:'metiers',titre:"Métiers & Professions",desc:"Offre d'emploi, CV, lettre de motivation",type:"Administratif : offre d'emploi, CV, lettre",v:"Maîtrise de soi, respect d'autrui",
      semaines:[
        {code:'S1',titre:'Découverte et Compréhension',desc:"Découvrir les métiers et les documents administratifs",objectif:'Découverte du lexique et des verbes du 3e groupe',
          lecon:{intro:"Le monde professionnel compte de nombreux métiers : infirmière, cuisinier, pilote, steward, luthier, journaliste, artisan, ouvrier, employé, cadre, fonctionnaire. Chaque métier possède ses propres qualités requises : rigueur, ponctualité, responsabilité, esprit d'équipe, autonomie, créativité. Pour postuler à un emploi, il faut préparer un CV, une lettre de motivation et parfois passer un entretien d'embauche. Les verbes du 3e groupe (prendre, faire, dire, plaire, refaire) sont irréguliers et doivent être maîtrisés.",
            points:["Les métiers : infirmière, cuisinier, pilote, steward, luthier, journaliste","Les qualités : rigueur, ponctualité, responsabilité, esprit d'équipe","Les documents : CV, lettre de motivation, offre d'emploi","Le processus d'embauche : candidature, entretien, recrutement, salaire","Les verbes du 3e groupe : prendre, faire, dire, plaire","Conjugaison : je prends, tu prends, il prend, nous prenons, vous prenez, ils prennent"],
            ms:"Les verbes du 3e groupe sont irréguliers. Exemples : prendre → je prends, nous prenons, ils prennent. Faire → je fais, nous faisons, ils font. Dire → je dis, nous disons, ils disent. Plaire → je plais, il plaît, ils plaisent.",
            lex:["Métiers : infirmière, cuisinier, pilote, steward, luthier, journaliste","Qualités : rigueur, ponctualité, responsabilité, esprit d'équipe","Documents : CV, lettre de motivation, offre d'emploi"]},
          exosOuverts:[
            {titre:"Associez chaque métier à sa définition",type:"tableau",tag:"LEXIQUE",
              consigne:"Reliez chaque métier de la colonne A à sa définition dans la colonne B.",
              entetes:["N°","Colonne A (Métier)","Colonne B (Définition)","Réponse"],
              lignes:[
                ["1","Infirmière","A. Personne qui prépare les plats dans un restaurant",""],
                ["2","Cuisinier","B. Personne qui soigne les malades",""],
                ["3","Pilote","C. Personne qui conduit un avion",""],
                ["4","Steward","D. Personne qui présente les règles de sécurité dans l'avion",""],
                ["5","Luthier","E. Personne qui crée et répare les instruments à cordes",""],
                ["6","Accordeur","F. Personne qui accorde les pianos",""],
                ["7","Journaliste","G. Personne qui collecte et présente les informations",""]
              ],
              corrige:["1 → B","2 → A","3 → C","4 → D","5 → E","6 → F","7 → G"]},
            {titre:"Complétez les phrases avec le mot qui convient",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot approprié choisi parmi : rigueur, expérience, compétence, formation, responsabilité, esprit d'équipe, ponctualité.",
              phrases:[
                "Une infirmière doit faire preuve de ___ dans son travail. (rigueur)",
                "Pour être pilote, il faut avoir une solide ___. (formation)",
                "La ___ est essentielle dans le métier de cuisinier. (ponctualité)",
                "Un bon steward doit avoir le sens de la ___. (responsabilité)",
                "Le luthier possède une grande ___ manuelle. (compétence)",
                "Le travail en brigade exige un fort ___. (esprit d'équipe)",
                "La ___ est une qualité indispensable dans tous les métiers. (expérience)"
              ]},
            {titre:"Conjuguez les verbes du 3e groupe au présent",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase en conjuguant le verbe entre parenthèses au présent de l'indicatif.",
              phrases:[
                "Le cuisinier ___ (prendre) son tablier avant de commencer. (prend)",
                "L'infirmière ___ (faire) le tour des chambres chaque matin. (fait)",
                "Le pilote ___ (dire) aux passagers de boucler leur ceinture. (dit)",
                "Nous ___ (prendre) l'avion pour Antananarivo. (prenons)",
                "Les musiciens ___ (plaire) au public par leur talent. (plaisent)",
                "Le luthier ___ (refaire) un violon. (refait)",
                "Vous ___ (faire) un excellent travail. (faites)"
              ]},
            {titre:"Rédigez un court texte sur un métier",type:"production",tag:"SYNTAXE",
              consigne:"Choisissez un métier parmi ceux étudiés (infirmière, cuisinier, pilote, steward, luthier...). Rédigez un court texte de 4 à 5 phrases pour le présenter. Utilisez au moins 3 verbes du 3e groupe (prendre, faire, dire, plaire...).",
              lignes:5,
              exemple:"L'infirmière prend soin des malades chaque jour. Elle fait le tour des chambres pour vérifier leur état. Elle dit aux patients de rester calmes et de bien se reposer. Elle prend aussi leurs constantes. Ce métier plaît à ceux qui aiment aider les autres.",
              corrige:"Réponses libres. Vérifier : choix d'un métier, présence d'au moins 3 verbes du 3e groupe, cohérence du texte (4 à 5 phrases), mobilisation du lexique des métiers."}
          ],
          exos:[
            {q:"Quel métier soigne les malades ?",o:["Le cuisinier","L'infirmière","Le pilote","Le steward"],c:1,e:"L'infirmière."},
            {q:"Quel est un verbe du 3e groupe ?",o:["Parler","Finir","Prendre","Chanter"],c:2,e:"« Prendre »."},
            {q:"Que signifie « CV » ?",o:["Curriculum Vitae","Carte Vitale","Certificat de Vie","Contrat de Vente"],c:0,e:"Curriculum Vitae."},
            {q:"Quelle qualité est indispensable pour un cuisinier ?",o:["Ponctualité","Paresse","Négligence","Désordre"],c:0,e:"La ponctualité."},
            {q:"Qui dirige la brigade dans un restaurant ?",o:["Le commis","Le plongeur","Le chef de cuisine","Le serveur"],c:2,e:"Le chef de cuisine."}
          ]},
        {code:'S2',titre:'Approfondissement Lexical',desc:"Approfondir l'accord du participe passé et les pronoms possessifs",objectif:"Maîtriser l'accord du participe passé avec avoir",
          lecon:{intro:"L'accord du participe passé avec l'auxiliaire « avoir » obéit à une règle précise : le participe passé s'accorde en genre et en nombre avec le complément d'objet direct (COD) lorsque celui-ci précède le verbe. Exemple : Les lettres que j'ai écrites (COD « que » = les lettres, féminin pluriel → écrites). Les pronoms possessifs remplacent un nom précédé d'un adjectif possessif : le mien, la mienne, le tien, la tienne, le sien, la sienne, le nôtre, la vôtre, les leurs.",
            points:["Accord du participe passé avec avoir : le COD doit précéder le verbe","Exemple : Les lettres que j'ai écrites","Pronoms possessifs : le mien, la mienne, le tien, la tienne","Pronoms possessifs : le sien, la sienne, le nôtre, la vôtre, les leurs","Lexique : candidature, entretien, recrutement, salaire, diplôme, qualification"],
            ms:"L'accord du participe passé avec « avoir » : le participe passé s'accorde avec le COD si celui-ci est placé avant le verbe. Sinon, il reste invariable. Les pronoms possessifs s'accordent en genre et en nombre avec le nom qu'ils remplacent.",
            lex:["Diplôme, qualification, expérience, candidature","Entretien, recrutement, salaire","Pronoms possessifs : le mien, le tien, le sien, le nôtre, le vôtre, le leur"]},
          exosOuverts:[
            {titre:"Classez les métiers selon leur domaine",type:"tableau",tag:"LEXIQUE",
              consigne:"Classez chaque métier dans la bonne colonne : santé, transport, art, gastronomie ou administration.",
              entetes:["N°","Métier","Domaine"],
              lignes:[
                ["1","Médecin","Santé"],
                ["2","Contrôleur aérien","Transport"],
                ["3","Luthier","Art"],
                ["4","Chef cuisinier","Gastronomie"],
                ["5","Fonctionnaire","Administration"],
                ["6","Infirmière","Santé"],
                ["7","Ingénieur du son","Art"]
              ],
              corrige:["1 → Santé","2 → Transport","3 → Art","4 → Gastronomie","5 → Administration","6 → Santé","7 → Art"]},
            {titre:"Complétez et transformez les phrases",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le mot qui convient choisi parmi : diplôme, qualification, expérience, candidature, entretien, recrutement, salaire.",
              phrases:[
                "Pour postuler à un emploi, il faut préparer une ___. (candidature)",
                "Le ___ est une étape importante avant l'embauche. (entretien)",
                "Le ___ est une rémunération versée chaque mois. (salaire)",
                "Le ___ permet d'accéder à certains postes. (diplôme)",
                "La ___ professionnelle est valorisée par les employeurs. (expérience)",
                "Le ___ désigne l'ensemble du processus d'embauche. (recrutement)",
                "La ___ est une compétence reconnue par un titre. (qualification)"
              ]},
            {titre:"Accordez le participe passé avec « avoir »",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase en accordant correctement le participe passé avec « avoir » lorsque le COD précède le verbe.",
              phrases:[
                "Les candidatures que nous avons ___ (recevoir) sont nombreuses. (reçues)",
                "La lettre de motivation qu'il a ___ (écrire) est convaincante. (écrite)",
                "Les entretiens qu'elles ont ___ (passer) se sont bien déroulés. (passés)",
                "L'expérience qu'elle a ___ (acquérir) est précieuse. (acquise)",
                "Les diplômes que j'ai ___ (obtenir) sont reconnus. (obtenus)",
                "La formation qu'ils ont ___ (suivre) a duré deux ans. (suivie)",
                "Les compétences que vous avez ___ (développer) sont utiles. (développées)"
              ]},
            {titre:"Rédigez une lettre de motivation",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez une lettre de motivation de 6 à 8 phrases pour postuler à un emploi de votre choix. Structure : introduction (objet + raison), développement (formation, expérience, compétences), conclusion (disponibilité + formule de politesse). Utilisez au moins 3 verbes du 3e groupe et 2 pronoms possessifs.",
              lignes:8,
              exemple:"Objet : Candidature au poste d'infirmière. Madame, Monsieur, je prends la liberté de vous adresser ma candidature au poste d'infirmière dans votre établissement. J'ai obtenu mon diplôme il y a deux ans et j'ai acquis une solide expérience dans un hôpital public. Les compétences que j'ai développées me permettent de prendre soin des patients avec rigueur. Je fais preuve d'écoute et de responsabilité. Mes qualités sont les miennes, mais je saurai aussi adopter les vôtres pour m'intégrer à votre équipe. Je reste disponible pour un entretien. Veuillez agréer, Madame, Monsieur, mes salutations respectueuses.",
              corrige:"Réponses libres. Vérifier : structure de la lettre, au moins 3 verbes du 3e groupe, 2 pronoms possessifs, lexique des métiers, cohérence et correction."}
          ],
          exos:[
            {q:"Quel est un métier de la santé ?",o:["Médecin","Contrôleur aérien","Luthier","Cuisinier"],c:0,e:"Médecin."},
            {q:"Quel est un verbe du 3e groupe ?",o:["Parler","Faire","Finir","Chanter"],c:1,e:"« Faire »."},
            {q:"Quand le participe passé s'accorde-t-il avec « avoir » ?",o:["Quand le COD est avant le verbe","Quand le COD est après le verbe","Jamais","Toujours"],c:0,e:"Quand le COD est avant le verbe."},
            {q:"Quel est le pronom possessif de « mon CV » ?",o:["Le mien","Le tien","Le sien","Le vôtre"],c:0,e:"« Le mien »."},
            {q:"Que signifie « entretien d'embauche » ?",o:["Réunion de travail","Rencontre avec un employeur","Discussion entre collègues","Cours de formation"],c:1,e:"Rencontre avec un employeur."}
          ]},
        {code:'S3',titre:'Structuration et Production',desc:"Maîtriser la structure du CV et de la lettre de motivation",objectif:'Produire un CV et une lettre de motivation',
          lecon:{intro:"Le CV et la lettre de motivation sont deux documents essentiels pour une candidature. Le CV présente le parcours professionnel : en-tête (nom, adresse, contact), objectif professionnel, formation, expérience professionnelle, compétences, centres d'intérêt. La lettre de motivation accompagne le CV et exprime les motivations du candidat : en-tête, objet, introduction, développement, conclusion, salutation. Pour enrichir ces documents, il faut utiliser un lexique précis, des verbes du 3e groupe, l'accord du participe passé et des pronoms possessifs.",
            points:["Structure du CV : en-tête, objectif, formation, expérience, compétences","Structure de la lettre : en-tête, objet, développement, conclusion","Enrichir avec des synonymes précis : passionnant, qualifiée, efficace","Verbes du 3e groupe : prendre, faire, dire, plaire","Accord du participe passé avec avoir","Pronoms possessifs : le mien, la vôtre"],
            ms:"Le CV est un document synthétique et organisé. La lettre de motivation est rédigée à la première personne (je) et utilise un ton formel et courtois. Les verbes du 3e groupe sont irréguliers et doivent être maîtrisés.",
            lex:["Synonymes : passionnant, qualifiée, efficace, serein","Familles de mots : métier/profession/professionnel","Structure du CV et de la lettre de motivation"]},
          exosOuverts:[
            {titre:"Enrichissez vos phrases",type:"transformation",tag:"LEXIQUE",
              consigne:"Remplacez le mot souligné par un synonyme plus précis et plus expressif.",
              phrases:[
                "Ce métier est intéressant. → passionnant / captivant",
                "L'infirmière est compétente. → qualifiée / expérimentée",
                "Le cuisinier est rapide. → efficace / vif",
                "Le pilote est calme. → serein / maître de soi",
                "Le luthier est habile. → adroit / talentueux",
                "Le journaliste est curieux. → investigateur / avide de savoir",
                "Ce travail est difficile. → exigeant / complexe"
              ],
              corrige:["1. passionnant / captivant","2. qualifiée / expérimentée","3. efficace / vif","4. serein / maître de soi","5. adroit / talentueux","6. investigateur / avide de savoir","7. exigeant / complexe"]},
            {titre:"Complétez avec les pronoms possessifs",type:"completion",tag:"LEXIQUE",
              consigne:"Complétez chaque phrase avec le pronom possessif qui convient : le mien, la mienne, le tien, la tienne, le sien, la sienne, le nôtre, la vôtre, les leurs.",
              phrases:[
                "Mon diplôme est reconnu, mais ___ aussi. (le tien)",
                "Ta formation est différente de ___. (la mienne)",
                "Son expérience est précieuse, mais ___ l'est également. (la vôtre)",
                "Nos compétences sont reconnues, mais ___ sont également appréciées. (les vôtres)",
                "Votre candidature est solide, mais ___ est excellente. (la mienne)",
                "Leurs entretiens se sont bien passés, mais ___ aussi. (les miens)",
                "Mon salaire est correct, mais ___ est meilleur. (le sien)"
              ]},
            {titre:"Transformez les phrases (passif ↔ actif)",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase en changeant la voix.",
              phrases:[
                "Le directeur recrute les candidats. → Les candidats sont recrutés par le directeur.",
                "Les lettres de motivation sont rédigées par les postulants. → Les postulants rédigent les lettres de motivation.",
                "L'infirmière soigne les patients. → Les patients sont soignés par l'infirmière.",
                "Les plats sont préparés par le chef cuisinier. → Le chef cuisinier prépare les plats.",
                "Le luthier répare les instruments. → Les instruments sont réparés par le luthier.",
                "Les avions sont pilotés par des commandants de bord. → Des commandants de bord pilotent les avions.",
                "Les journalistes diffusent les informations. → Les informations sont diffusées par les journalistes."
              ],
              corrige:["1. Les candidats sont recrutés par le directeur.","2. Les postulants rédigent les lettres de motivation.","3. Les patients sont soignés par l'infirmière.","4. Le chef cuisinier prépare les plats.","5. Les instruments sont réparés par le luthier.","6. Des commandants de bord pilotent les avions.","7. Les informations sont diffusées par les journalistes."]},
            {titre:"Analysez la structure des phrases",type:"tableau",tag:"SYNTAXE",
              consigne:"Indiquez si chaque phrase est simple, juxtaposée, coordonnée ou subordonnée.",
              entetes:["N°","Phrase","Type"],
              lignes:[
                ["1","L'infirmière soigne les malades.","Simple"],
                ["2","Le cuisinier prépare les plats et il les sert.","Coordonnée"],
                ["3","Le pilote pilote, le copilote surveille.","Juxtaposée"],
                ["4","Parce que le luthier est habile, il répare les violons.","Subordonnée"],
                ["5","Le journaliste est curieux mais il reste objectif.","Coordonnée"],
                ["6","Je pense que ce métier est passionnant.","Subordonnée"],
                ["7","Le steward accueille, il informe, il sert.","Juxtaposée"]
              ],
              corrige:["1. Simple","2. Coordonnée (et)","3. Juxtaposée (virgule)","4. Subordonnée (parce que)","5. Coordonnée (mais)","6. Subordonnée (que)","7. Juxtaposée (virgules)"]},
            {titre:"Rédigez un CV et une lettre de motivation",type:"production",tag:"SYNTAXE",
              consigne:"Rédigez un CV (5-6 lignes) et une lettre de motivation (6-8 phrases) pour postuler à un emploi de votre choix. Le CV doit contenir : en-tête, formation, expérience, compétences, centres d'intérêt. Utilisez au moins 3 pronoms possessifs dans la lettre.",
              lignes:10,
              exemple:"CV — Nom : RAKOTO Jean. Adresse : Antananarivo. Contact : jean.rakoto@email.mg. Formation : Bac +2 en gestion. Expérience : Assistant administratif (2 ans). Compétences : bureautique, organisation. Centres d'intérêt : lecture, sport. / Lettre — Objet : Candidature au poste d'assistant administratif. Madame, Monsieur, je prends la liberté de vous adresser ma candidature. J'ai obtenu mon diplôme il y a deux ans et j'ai acquis une solide expérience. Les compétences que j'ai développées sont les miennes, mais je saurai aussi adopter les vôtres. Je reste disponible pour un entretien. Veuillez agréer mes salutations respectueuses.",
              corrige:"Réponses libres. Vérifier : structure du CV (en-tête, formation, expérience, compétences), structure de la lettre (objet, développement, conclusion), 3 pronoms possessifs, correction."}
          ],
          exos:[
            {q:"Quel est le pronom possessif de « mon CV » ?",o:["Le mien","Le tien","Le sien","Le vôtre"],c:0,e:"« Le mien »."},
            {q:"Quelle phrase est juxtaposée ?",o:["Le pilote pilote, le copilote surveille","Le cuisinier prépare et il sert","Parce que le luthier est habile, il répare","L'infirmière soigne"],c:0,e:"La virgule est un signe de juxtaposition."},
            {q:"Quelle est la structure du CV ?",o:["En-tête, objectif, formation, expérience, compétences","Introduction, développement, conclusion","Titre, chapeau, corps","Situation initiale, péripéties"],c:0,e:"En-tête, objectif, formation, expérience, compétences."},
            {q:"Quelle phrase est subordonnée ?",o:["Je pense que ce métier est passionnant","Le steward accueille, il informe","Le journaliste est curieux mais objectif","L'infirmière soigne"],c:0,e:"« Que » introduit une subordonnée."}
          ]},
        {code:'S4',titre:'Évaluation et Consolidation',desc:"Évaluer les acquis lexicaux et syntaxiques sur les métiers",objectif:'Évaluation des compétences',
          lecon:{intro:"Cette semaine est consacrée à l'évaluation et à la consolidation des acquis sur le thème des métiers et professions. Nous révisons le lexique (métiers, qualités, documents), les verbes du 3e groupe, l'accord du participe passé avec « avoir », les pronoms possessifs et la production écrite d'un CV et d'une lettre de motivation.",
            points:["Révision du lexique des métiers","Révision des verbes du 3e groupe","Révision de l'accord du participe passé","Révision des pronoms possessifs","Révision de la structure du CV et de la lettre","Préparation à l'évaluation finale"],
            ms:"Révision globale : verbes du 3e groupe, accord du participe passé avec avoir, pronoms possessifs, structure des documents administratifs.",
            lex:["Métiers : infirmière, cuisinier, pilote, luthier, journaliste","Qualités : rigueur, ponctualité, responsabilité, esprit d'équipe","Documents : CV, lettre de motivation, offre d'emploi"]},
          exosOuverts:[
            {titre:"Complétez la grille de mots croisés",type:"tableau",tag:"LEXIQUE",
              consigne:"Retrouvez le mot correspondant à chaque définition.",
              entetes:["N°","Définition","Mot à trouver"],
              lignes:[
                ["1","Personne qui soigne les malades",""],
                ["2","Personne qui prépare les plats dans un restaurant",""],
                ["3","Personne qui conduit un avion",""],
                ["4","Personne qui crée et répare les instruments à cordes",""],
                ["5","Document détaillant le parcours professionnel",""],
                ["6","Document accompagnant une candidature",""],
                ["7","Rémunération mensuelle d'un employé",""]
              ],
              corrige:["1. Infirmière","2. Cuisinier","3. Pilote","4. Luthier","5. CV","6. Lettre de motivation","7. Salaire"]},
            {titre:"QCM – Choisissez la bonne réponse",type:"qcm-ouvert",tag:"LEXIQUE",
              consigne:"Entourez la bonne réponse.",
              questions:[
                {q:"Quel document présente le parcours professionnel ?",o:["La lettre de motivation","Le CV","Le contrat","Le diplôme"],c:1},
                {q:"Que signifie « entretien d'embauche » ?",o:["Réunion de travail","Rencontre avec un employeur","Discussion entre collègues","Cours de formation"],c:1},
                {q:"Quel est un verbe du 3e groupe ?",o:["Parler","Finir","Prendre","Chanter"],c:2},
                {q:"Quel est un pronom possessif ?",o:["Le mien","Celui","Chacun","Personne"],c:0},
                {q:"Que signifie « compétence » ?",o:["Salaire","Aptitude professionnelle","Diplôme","Contrat"],c:1},
                {q:"Quelle est la qualité principale d'une infirmière ?",o:["Rapidité","Rigueur","Créativité","Force physique"],c:1},
                {q:"Que signifie « recrutement » ?",o:["Licenciement","Embauche","Démission","Retraite"],c:1}
              ],
              corrige:["1. b) Le CV","2. b) Rencontre avec un employeur","3. c) Prendre","4. a) Le mien","5. b) Aptitude professionnelle","6. b) Rigueur","7. b) Embauche"]},
            {titre:"Conjuguez et accordez",type:"completion",tag:"SYNTAXE",
              consigne:"Complétez chaque phrase en conjuguant le verbe ou en accordant le participe passé.",
              phrases:[
                "L'infirmière ___ (prendre) soin des patients chaque jour. (prend)",
                "Les candidatures que nous avons ___ (recevoir) sont nombreuses. (reçues)",
                "Le cuisinier ___ (faire) la cuisine avec passion. (fait)",
                "La lettre de motivation qu'il a ___ (écrire) est convaincante. (écrite)",
                "Les musiciens ___ (plaire) au public par leur talent. (plaisent)",
                "Les entretiens qu'elles ont ___ (passer) se sont bien déroulés. (passés)",
                "Nous ___ (dire) toujours la vérité. (disons)"
              ]},
            {titre:"Transformez les phrases",type:"transformation",tag:"SYNTAXE",
              consigne:"Transformez chaque phrase selon l'indication donnée.",
              phrases:[
                "Le directeur recrute les candidats. → (forme passive)",
                "Les plats sont préparés par le chef cuisinier. → (forme active)",
                "Mon diplôme est reconnu, mais le tien aussi. → (remplacer par « le vôtre »)",
                "Les instruments sont réparés par le luthier. → (forme active)",
                "L'infirmière soigne les malades. → (forme passive)",
                "Le journaliste est curieux mais il reste objectif. → (deux phrases simples)",
                "Les lettres que j'ai écrites. → (reformuler avec « la lettre »)"
              ],
              corrige:["1. Les candidats sont recrutés par le directeur.","2. Le chef cuisinier prépare les plats.","3. Mon diplôme est reconnu, mais le vôtre aussi.","4. Le luthier répare les instruments.","5. Les malades sont soignés par l'infirmière.","6. Le journaliste est curieux. Il reste objectif.","7. La lettre que j'ai écrite."]},
            {titre:"Rédigez une lettre de motivation finale",type:"production",tag:"EVAL",
              consigne:"Rédigez une lettre de motivation de 8 à 10 phrases pour postuler à un emploi de votre choix. Respectez la structure de la lettre (objet, développement, conclusion), utilisez au moins 3 verbes du 3e groupe et 2 pronoms possessifs.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : structure de la lettre, 3 verbes du 3e groupe, 2 pronoms possessifs, lexique des métiers, cohérence et correction."}
          ],
          exos:[
            {q:"Quel document présente le parcours professionnel ?",o:["La lettre de motivation","Le CV","Le contrat","Le diplôme"],c:1,e:"Le CV."},
            {q:"Quel est un verbe du 3e groupe ?",o:["Parler","Finir","Prendre","Chanter"],c:2,e:"« Prendre »."},
            {q:"Quel est un pronom possessif ?",o:["Le mien","Celui","Chacun","Personne"],c:0,e:"« Le mien »."},
            {q:"Que signifie « compétence » ?",o:["Salaire","Aptitude professionnelle","Diplôme","Contrat"],c:1,e:"Aptitude professionnelle."},
            {q:"Que signifie « recrutement » ?",o:["Licenciement","Embauche","Démission","Retraite"],c:1,e:"Embauche."}
          ]},
        {code:'S5',titre:'Synthèse finale',desc:"Révision générale et auto-évaluation du thème",objectif:'Consolider tous les acquis du thème',
          lecon:{intro:"Cette dernière semaine est consacrée à la synthèse générale du thème des métiers et professions. Nous révisons l'ensemble des acquis : le lexique des métiers, les qualités et compétences, les documents administratifs (CV, lettre de motivation, offre d'emploi), les verbes du 3e groupe, l'accord du participe passé avec « avoir », les pronoms possessifs et la production écrite. L'objectif est de consolider les connaissances et de préparer l'évaluation finale.",
            points:["Le lexique : métiers, qualités, documents","Les verbes du 3e groupe : prendre, faire, dire, plaire","L'accord du participe passé avec avoir","Les pronoms possessifs : le mien, le tien, le sien","La structure du CV et de la lettre de motivation","Le processus d'embauche"],
            ms:"Révision globale de toutes les notions du thème.",
            lex:["Métiers : infirmière, cuisinier, pilote, luthier, journaliste","Documents : CV, lettre de motivation, offre d'emploi","Qualités : rigueur, ponctualité, responsabilité, esprit d'équipe"]},
          exosOuverts:[
            {titre:"Rédigez une synthèse finale sur les métiers",type:"production",tag:"EVAL",
              consigne:"Rédigez un texte complet (CV + lettre de motivation) pour postuler à un emploi de votre choix. Mobilisez tout le lexique appris, les verbes du 3e groupe et les pronoms possessifs.",
              lignes:10,
              corrige:"Réponses libres. Vérifier : structure du CV et de la lettre, lexique riche, verbes du 3e groupe, pronoms possessifs, cohérence et correction."}
          ],
          exos:[
            {q:"Quel métier soigne les malades ?",o:["Le cuisinier","L'infirmière","Le pilote","Le steward"],c:1,e:"L'infirmière."},
            {q:"Quel est un verbe du 3e groupe ?",o:["Parler","Finir","Prendre","Chanter"],c:2,e:"« Prendre »."},
            {q:"Quand le participe passé s'accorde-t-il avec « avoir » ?",o:["Quand le COD est avant le verbe","Quand le COD est après le verbe","Jamais","Toujours"],c:0,e:"Quand le COD est avant le verbe."},
            {q:"Quel est le pronom possessif de « mon CV » ?",o:["Le mien","Le tien","Le sien","Le vôtre"],c:0,e:"« Le mien »."},
            {q:"Quelle est la structure du CV ?",o:["En-tête, objectif, formation, expérience, compétences","Introduction, développement, conclusion","Titre, chapeau, corps","Situation initiale, péripéties"],c:0,e:"En-tête, objectif, formation, expérience, compétences."}
          ]}
      ],
      texte:{titre:"Les métiers et professions : des parcours variés",
        contenu:[
          "L'infirmière soigne les malades et veille à leur bien-être. Ce métier à haute responsabilité exige rigueur, vigilance et expérience. L'infirmière effectue des soins de nature préventive, curative ou palliative pour améliorer, maintenir et restaurer la santé. Elle collabore avec toute l'équipe soignante et participe au projet global de soin. Tenue au secret professionnel, elle assure avec l'aide-soignant les soins d'hygiène, de confort et de sécurité du patient.",
          "Dans tous les restaurants, le chef de cuisine est à la tête d'une brigade. Il décide des aliments à acheter, des menus à préparer et des prix. Il choisit aussi le personnel qui travaillera avec lui : cuisiniers qui préparent les plats, commis qui épluchent les légumes et rangent la nourriture, plongeurs qui font la vaisselle. Le matériel est indispensable : couteaux, casseroles et planches à découper sont les outils essentiels du cuisinier.",
          "À l'aéroport, de nombreux métiers collaborent pour assurer la sécurité et le confort des passagers. Le préparateur de vol prépare le trajet d'un avion en fonction de la géographie, de la météo et des réserves de carburant. L'agent de sécurité contrôle les papiers des passagers et les fouille avant l'embarquement. Le commandant de bord pilote les avions, aidé par un copilote. Le contrôleur aérien coordonne les mouvements des avions sur l'aéroport. Le steward présente les règles de sécurité et sert à boire et à manger aux passagers.",
          "Les métiers de la musique sont également variés. Le chef d'orchestre dirige les musiciens. Le chanteur chante, donne des concerts. Le luthier crée et répare les instruments à cordes frottées et pincées. L'accordeur accorde les pianos. Le producteur de disques repère les bons chanteurs. L'ingénieur du son règle le matériel pour que le son soit le meilleur possible.",
          "En conclusion, chaque métier possède ses spécificités, ses qualités requises et ses outils. Pour bien s'orienter, il faut connaître ses compétences, ses goûts et ses ambitions. Les documents administratifs (CV, lettre de motivation, offre d'emploi) permettent de postuler à un emploi et de présenter son parcours professionnel."
        ]},
      questions:[
        {q:"Quel est le rôle principal d'une infirmière ?",o:["Soigner les malades","Préparer les plats","Piloter les avions","Réparer les instruments"],c:0,e:"L'infirmière soigne les malades et veille à leur bien-être."},
        {q:"Qui dirige la brigade dans un restaurant ?",o:["Le commis","Le plongeur","Le chef de cuisine","Le serveur"],c:2,e:"Le chef de cuisine."},
        {q:"Quel est le rôle du contrôleur aérien ?",o:["Piloter les avions","Coordonner les mouvements des avions","Contrôler les papiers","Réparer les instruments"],c:1,e:"Coordonner les mouvements des avions sur l'aéroport."},
        {q:"Quelle est la mission du luthier ?",o:["Créer et réparer les instruments à cordes","Accorder les pianos","Diriger un orchestre","Chanter"],c:0,e:"Créer et réparer les instruments à cordes."},
        {q:"Quelle est la structure du CV ?",o:["En-tête, objectif, formation, expérience, compétences","Introduction, développement, conclusion","Titre, chapeau, corps","Situation initiale, péripéties"],c:0,e:"En-tête, objectif, formation, expérience, compétences."}
      ],
      lecon:{intro:"Les textes administratifs liés à l'emploi suivent des règles précises.",
        structure:[{t:"Offre d'emploi",d:"Titre du poste, missions, profil, conditions."},{t:'CV',d:"En-tête, objectif, formation, expérience, compétences."},{t:'Lettre de motivation',d:"En-tête, objet, intro, développement, conclusion."}],
        ex:"« Nous recherchons un(e) assistant(e) administratif(ve) pour notre agence d'Antananarivo. »",
        ms:"Verbes du 3e groupe (prendre, plaire). Accord du participe passé avec « avoir » si COD avant. Pronoms possessifs."},
      lexique:["Métiers : artisan, ouvrier, employé, cadre, fonctionnaire","Qualités et compétences sur le marché du travail","CV : en-tête, objectif, formation, expérience"],
      ms:["Conjugaison des verbes du 3e groupe (prendre, plaire)","L'accord du participe passé avec « avoir »","Les pronoms possessifs : la mienne, la vôtre"],
      exos:[
        {q:"Que ne contient PAS un CV ?",o:["Formation","Expérience","Salaire souhaité","Centres d'intérêt"],c:2,e:"Salaire souhaité."},
        {q:"« Prendre » à la 1re pers. sing. présent ?",o:["Je prends","Je prend","Je prende","Je prens"],c:0,e:"Je prends."},
        {q:"« Les lettres que j'ai ____ »",o:["écrit","écrits","écrites","écrite"],c:2,e:"Écrites."},
        {q:"Rôle de la lettre de motivation ?",o:["Remplacer le CV","Présenter ses motivations et convaincre","Raconter sa vie","Donner ses notes"],c:1,e:"Présenter ses motivations."},
        {q:"Pronom possessif de « mon CV » ?",o:["Le mien","Le tien","Le sien","Le vôtre"],c:0,e:"« Le mien »."}
      ]}
  ]}
};
/* ============================================================
   NORMALISATION DES DONNÉES
   ============================================================ */
/* Exercices « à compléter » : la réponse était écrite entre parenthèses en fin de phrase,
   donc visible AVANT que l'élève réponde, et aucun corrigé n'était proposé.
   On retire cette dernière parenthèse de l'énoncé (l'indice « (passer) » reste) et on
   construit le corrigé à partir de ces réponses. */
Object.values(P).forEach(p=>p.themes.forEach(t=>(t.semaines||[]).forEach(s=>(s.exosOuverts||[]).forEach(e=>{
  if(e.type!=='completion'||e.corrige||!Array.isArray(e.phrases)) return;
  const rep=[];
  e.phrases=e.phrases.map(ph=>{
    const m=ph.match(/\s*\(([^()]*)\)\s*$/);
    if(!m){ rep.push('—'); return ph; }
    rep.push(m[1].trim());
    return ph.slice(0,m.index);
  });
  e.corrige=rep;
}))));
/* ============================================================
   MÉLANGE DES EXERCICES
   - QCM : les propositions A/B/C/D sont mélangées à chaque nouvelle tentative.
     La bonne réponse n'est donc pas toujours A, B, C ou D.
   - À trous : les phrases sont également mélangées à chaque nouvelle tentative.
   ============================================================ */
function shuffleQ(q){
  if(!q||!Array.isArray(q.o)||q.o.length<2) return q;
  const idx=q.o.map((_,i)=>i);
  for(let i=idx.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [idx[i],idx[j]]=[idx[j],idx[i]];
  }
  return {...q,o:idx.map(i=>q.o[i]),c:idx.indexOf(q.c)};
}
function shuffleItems(list){
  const a=Array.isArray(list)?list.slice():[];
  for(let i=a.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [a[i],a[j]]=[a[j],a[i]];
  }
  return a;
}
/* Mélange également l'ordre des questions.
   Exemple : l'ancienne Q7 peut devenir Q1, l'ancienne Q1 peut devenir Q6, etc.
   Le mélange est créé UNE fois au démarrage de chaque exercice, puis conservé pendant
   toute la tentative afin que le bouton « Question suivante » ne change pas l'ordre. */
function shuffleOrder(n){
  const a=Array.from({length:n},(_,i)=>i);
  for(let i=a.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [a[i],a[j]]=[a[j],a[i]];
  }
  return a;
}
/* ============================================================
   DONNÉES PERSONNALISÉES — stockage local
   ============================================================ */
const EDITOR_KEY='f3_programme_personnalise_v1';
function cloneData(o){ return JSON.parse(JSON.stringify(o)); }
function loadEditorData(){
  try{
    const raw=localStorage.getItem(EDITOR_KEY);
    if(!raw) return;
    const saved=JSON.parse(raw);
    Object.keys(saved||{}).forEach(pid=>{
      if(!P[pid]) P[pid]=saved[pid];
      else P[pid]=saved[pid];
    });
  }catch(e){ console.warn('Données personnalisées non chargées',e); }
}
function saveEditorData(){
  try{
    const copy=cloneData(P);
    localStorage.setItem(EDITOR_KEY,JSON.stringify(copy));
    return true;
  }catch(e){
    console.error(e);
    return false;
  }
}
function resetEditorData(){
  try{ localStorage.removeItem(EDITOR_KEY); location.reload(); }
  catch(e){ alert('Impossible de réinitialiser les données.'); }
}
loadEditorData();
/* Toutes les questions sont désormais des questions ouvertes : aucune proposition A/B/C/D.
   Les anciennes données QCM sont automatiquement converties en question + réponse attendue. */
function convertQuestionsToOpen(){
  Object.values(P).forEach(p=> (p.themes||[]).forEach(t=>{
    if(Array.isArray(t.questions)) t.questions=t.questions.map(q=>{
      if(q && Array.isArray(q.o)){ return {q:q.q||"", corrige:(q.e||q.o[q.c]||"").trim()}; }
      return {q:q?.q||"", corrige:q?.corrige||q?.e||""};
    });
    (t.semaines||[]).forEach(s=>{
      if(Array.isArray(s.exos)) {
        const anciens=s.exos;
        s.exosOuverts=s.exosOuverts||[];
        anciens.forEach(q=>{
          if(q && q.q){
            s.exosOuverts.push({titre:q.q,type:"question",tag:"EXERCICE",consigne:"Répondez par une phrase complète.",questions:[{q:q.q,corrige:(q.e||q.o?.[q.c]||"").trim()}],corrige:[]});
          }
        });
        s.exos=[];
      }
      s.exosOuverts=(s.exosOuverts||[]).map(e=>{
        if(e.type==='qcm-ouvert' && Array.isArray(e.questions)) e.type='question';
        if(e.type==='question' && Array.isArray(e.questions)) return e;
        return e;
      });
    });
  }));
}
/* QCM conservés : les exercices à choix multiples restent interactifs.
   Leur ordre est mélangé à chaque nouvelle tentative via shuffleOrder(). */
// convertQuestionsToOpen();
/* ============================================================
   ÉDITEUR : thèmes, leçons et exercices
   ============================================================ */
let editorTab='theme';
function openEditor(tab){
  editorTab=tab||'theme';
  $('#editorModal').classList.add('on');
  renderEditor();
}
function closeEditor(){ $('#editorModal').classList.remove('on'); }
function editorPeriodOptions(selected){
  return Object.values(P).map(p=>`<option value="${p.id}" ${p.id===selected?'selected':''}>${esc(p.titre)}</option>`).join('');
}
function editorThemeOptions(pid,selected){
  const p=P[pid];
  return (p&&p.themes||[]).map(t=>`<option value="${t.id}" ${t.id===selected?'selected':''}>${esc(t.titre)}</option>`).join('');
}
function editorWeekOptions(pid,tid,selected){
  const p=P[pid], t=p&&p.themes.find(x=>x.id===tid);
  return (t&&t.semaines||[]).map((s,i)=>`<option value="${i}" ${String(i)===String(selected)?'selected':''}>${esc(s.code)} — ${esc(s.titre)}</option>`).join('');
}
function editorInput(label,id,value,ph){
  return `<div class="editor-field"><label for="${id}">${label}</label><input id="${id}" value="${esc(value||'')}" placeholder="${esc(ph||'')}"></div>`;
}
function editorArea(label,id,value,ph){
  return `<div class="editor-field"><label for="${id}">${label}</label><textarea id="${id}" placeholder="${esc(ph||'')}">${esc(value||'')}</textarea></div>`;
}
function renderEditor(){
  $$('.editor-tab').forEach(b=>b.classList.toggle('active',b.dataset.editorTab===editorTab));
  const box=$('#editorForm');
  if(editorTab==='sujet') renderEditorSujet(box);
  else renderEditorTheme(box);
}
function editorConfirm(msg){ return window.confirm(msg); }
function editorRows(list, label, prefix, type='input'){
  const arr=Array.isArray(list)&&list.length?list:[''];
  return `<div class="editor-list" data-list="${prefix}">${arr.map((v,i)=>`
    <div class="editor-list-row" data-row="${i}">
      <span class="editor-num">${i+1}</span>
      ${type==='textarea'?`<textarea class="${prefix}-item" placeholder="${esc(label)}">${esc(v||'')}</textarea>`:`<input class="${prefix}-item" value="${esc(v||'')}" placeholder="${esc(label)}">`}
      <button type="button" class="mini plus" data-add="${prefix}" title="Ajouter">＋</button>
      <button type="button" class="mini minus" data-del="${prefix}" title="Supprimer">−</button>
    </div>`).join('')}</div>`;
}
function bindSimpleRows(prefix){
  const box=document.querySelector(`[data-list="${prefix}"]`); if(!box)return;
  box.addEventListener('click',e=>{
    const add=e.target.closest('[data-add]'),del=e.target.closest('[data-del]');
    if(add){
      const row=add.closest('.editor-list-row');
      const n=[...box.querySelectorAll('.editor-list-row')].length;
      const el=document.createElement('div'); el.className='editor-list-row'; el.dataset.row=n;
      el.innerHTML=`<span class="editor-num">${n+1}</span><input class="${prefix}-item" placeholder="Nouvel élément"><button type="button" class="mini plus" data-add="${prefix}">＋</button><button type="button" class="mini minus" data-del="${prefix}">−</button>`;
      row.after(el); renumberRows(box);
    }else if(del){
      const rows=box.querySelectorAll('.editor-list-row');
      if(rows.length<=1){ rows[0].querySelector(`.${prefix}-item`).value=''; return; }
      if(editorConfirm('Supprimer cet élément ?')){ del.closest('.editor-list-row').remove(); renumberRows(box); }
    }
  });
}
function renumberRows(box){ [...box.querySelectorAll('.editor-list-row')].forEach((r,i)=>{r.dataset.row=i;r.querySelector('.editor-num').textContent=i+1;}); }
function readRows(prefix){ return [...document.querySelectorAll(`[data-list="${prefix}"] .${prefix}-item`)].map(x=>x.value.trim()).filter(Boolean); }
function questionRows(list,prefix){
  const arr=Array.isArray(list)&&list.length?list:[{q:'',corrige:''}];
  return `<div class="q-list" data-q-list="${prefix}">${arr.map((q,i)=>`
    <div class="q-card" data-q-row="${i}">
      <div class="q-head"><b>Question ${i+1}</b><div><button type="button" class="mini plus" data-q-add="${prefix}">＋</button><button type="button" class="mini minus" data-q-del="${prefix}">−</button></div></div>
      <textarea class="q-q" placeholder="Écrivez la question ouverte">${esc(q.q||'')}</textarea>
      <textarea class="q-a" placeholder="Réponse attendue / correction">${esc(q.corrige||q.e||'')}</textarea>
    </div>`).join('')}</div>`;
}
function bindQuestionRows(prefix){
  const box=document.querySelector(`[data-q-list="${prefix}"]`); if(!box)return;
  box.addEventListener('click',e=>{
    const add=e.target.closest('[data-q-add]'),del=e.target.closest('[data-q-del]');
    if(add){
      const card=add.closest('.q-card'); const n=box.querySelectorAll('.q-card').length;
      const el=document.createElement('div');el.className='q-card';
      el.innerHTML=`<div class="q-head"><b>Question ${n+1}</b><div><button type="button" class="mini plus" data-q-add="${prefix}">＋</button><button type="button" class="mini minus" data-q-del="${prefix}">−</button></div></div><textarea class="q-q" placeholder="Écrivez la question ouverte"></textarea><textarea class="q-a" placeholder="Réponse attendue / correction"></textarea>`;
      card.after(el); renumberQuestions(box);
    }else if(del){
      const cards=box.querySelectorAll('.q-card');
      if(cards.length<=1){ alert('Il faut conserver au moins une question.'); return; }
      if(editorConfirm('Supprimer cette question et sa correction ?')){del.closest('.q-card').remove();renumberQuestions(box);}
    }
  });
}
function renumberQuestions(box){[...box.querySelectorAll('.q-card')].forEach((c,i)=>c.querySelector('.q-head b').textContent='Question '+(i+1));}
function readQuestions(prefix){
  return [...document.querySelectorAll(`[data-q-list="${prefix}"] .q-card`)].map(c=>({q:c.querySelector('.q-q').value.trim(),corrige:c.querySelector('.q-a').value.trim()})).filter(x=>x.q);
}
function renderEditorTheme(box){
  const pid=Object.keys(P)[0],tid=P[pid]?.themes?.[0]?.id||'';
  box.innerHTML=`<div class="editor-form">
    <div class="editor-row"><div class="editor-field"><label>Période</label><select id="edPid">${editorPeriodOptions(pid)}</select></div><div class="editor-field"><label>Thème</label><select id="edTid"><option value="__new">＋ Nouveau thème</option>${editorThemeOptions(pid,tid)}</select></div></div>
    <div id="themeFields"></div>
    <div class="editor-status" id="edStatus"></div></div>`;
  const update=()=>{
    const p=$('#edPid').value, isNew=$('#edTid').value==='__new', t=P[p].themes.find(x=>x.id===$('#edTid').value), blank={titre:'Nouveau thème',type:'Explicatif',desc:'',v:'',texte:{titre:'Texte de base',contenu:['']},questions:[]};
    const x=isNew?blank:t||blank, tx=x.texte||{titre:'Texte de base',contenu:[]};
    $('#themeFields').innerHTML=`
      ${editorInput('Titre du thème','edTitle',x.titre,'Ex. L’Artisanat à Madagascar')}
      <div class="editor-row">${editorInput('Type','edType',x.type,'Ex. Explicatif : reportage')}${editorInput('Compétence / valeur','edValue',x.v,'Compétence visée')}</div>
      ${editorInput('Description','edDesc',x.desc,'Courte présentation')}
      <div class="editor-actions"><button class="btn btn-p" id="edSaveTheme">${isNew?'＋ Ajouter le thème':'💾 Enregistrer le thème'}</button>${!isNew?'<button class="btn btn-s editor-danger" id="edDeleteTheme">− Supprimer le thème</button>':''}<button class="btn btn-s" id="edReset">Réinitialiser</button></div>`;
    $('#edSaveTheme').onclick=saveThemeEditor;
    if(!isNew)$('#edDeleteTheme').onclick=deleteThemeEditor;
    $('#edReset').onclick=()=>{if(editorConfirm('Supprimer toutes les modifications enregistrées sur cet appareil ?'))resetEditorData();};
  };
  $('#edPid').onchange=()=>{$('#edTid').innerHTML='<option value="__new">＋ Nouveau thème</option>'+editorThemeOptions($('#edPid').value,'');update();};
  $('#edTid').onchange=update;
  update();
}
function copyToClipboard(text,btn){
  const done=ok=>{ if(!btn)return; const old=btn.textContent; btn.textContent=ok?'✓ Copié !':'⚠️ Échec'; btn.classList.toggle('copy-ok',ok); setTimeout(()=>{btn.textContent=old;btn.classList.remove('copy-ok');},1600); };
  const legacyCopy=()=>{
    try{
      const ta=document.createElement('textarea'); ta.value=text; ta.setAttribute('readonly','');
      ta.style.position='fixed'; ta.style.top='-9999px'; ta.style.left='-9999px';
      document.body.appendChild(ta); ta.focus(); ta.select(); ta.setSelectionRange(0,text.length);
      const ok=document.execCommand('copy'); document.body.removeChild(ta); done(ok); return ok;
    }catch(e){ done(false); return false; }
  };
  if(navigator.clipboard && navigator.clipboard.writeText && window.isSecureContext){
    navigator.clipboard.writeText(text).then(()=>done(true)).catch(()=>legacyCopy());
  }else{
    legacyCopy();
  }
}
const PROMPT_TEMPLATES={
  theme:`Vous êtes le concepteur de contenu de l’application « FRANÇAIS COLLÈGE 3ème ». Créez UN FICHIER HTML COMPLET, autonome et prêt à être copié dans Acode puis utilisé hors ligne dans le WebViewer Android.
EXIGENCES IMPÉRATIVES :
- Respectez exactement l’esprit du design existant : bleu nuit #101b36, bleu secondaire #17264a, jaune #f5c400, fond clair #f8f9fc, cartes propres, coins arrondis, ombres discrètes, typographie lisible, aspect application Android premium.
- Aucun CDN, aucune bibliothèque externe, aucune dépendance Internet.
- HTML + CSS + JavaScript dans le même fichier.
- Responsive téléphone Android.
- Footer exact : « @2026 Titan création ».
- Ne créez pas une page web générique : le résultat doit ressembler à une page de notre application.
- Ne fournissez NI JSON, NI Markdown, NI explication autour du code. Retournez uniquement le code HTML complet.
- Le fichier doit fonctionner même sans Internet.
- Le contenu doit correspondre au niveau Français Collège 3ème et au type de thème demandé.
- Pour S1 : texte de base puis exactement 6 questions de compréhension avec leurs corrections ; ne dupliquez pas le texte de base.
- Les activités doivent rester pédagogiques, progressives et formulées à la 2e personne du pluriel lorsque l’élève est directement sollicité.
STRUCTURE DE RECONNAISSANCE OBLIGATOIRE DANS LE HTML :
<meta name="app-kind" content="theme">
<h1 data-editor-field="theme-title">Titre du thème</h1>
<section data-editor-field="theme-description">Description du thème</section>
<section data-editor-field="theme-type">Type de texte</section>
<section data-editor-field="theme-content">Contenu du thème</section>
Si une leçon est présente, utilisez :
<section data-editor-field="lesson-title">Titre de la leçon</section>
<section data-editor-field="lesson-intro">Introduction</section>
<section data-editor-field="morphosyntaxe-title">Titre morphosyntaxe</section>
<section data-editor-field="morphosyntaxe-content">Règle + explications + exemples</section>
<section data-editor-field="lexique-title">Titre lexique</section>
<section data-editor-field="lexique-content">Mots, expressions, définitions</section>
Demande précise à traiter : [ÉCRIVEZ ICI LE THÈME, LA SEMAINE, LE NIVEAU DE DÉTAIL ET LES EXIGENCES PARTICULIÈRES].`,
  lesson:`Vous êtes le concepteur pédagogique de l’application « FRANÇAIS COLLÈGE 3ème ». Créez UN FICHIER HTML COMPLET, autonome, hors ligne et prêt à copier dans Acode pour une LEÇON.
Le fichier doit respecter notre design : bleu nuit #101b36, bleu #17264a, jaune #f5c400, fond #f8f9fc, cartes premium, interface Android, responsive, animations très discrètes, sans CDN ni ressource externe. Footer exact : « @2026 Titan création ».
ADAPTEZ LE CONTENU À LA CATÉGORIE DEMANDÉE :
1. MORPHOSYNTAXE : titre précis de la notion, définition/règle, explications progressives, exemples corrects, remarques utiles au niveau 3ème.
2. LEXIQUE : titre, notion/champ lexical ou sémantique, vocabulaire, définitions claires, exemples contextualisés et distinctions utiles.
3. LEÇON LIÉE AU THÈME : contenu directement cohérent avec le texte, la période et la compétence travaillée.
STRUCTURE DE RECONNAISSANCE OBLIGATOIRE :
<meta name="app-kind" content="lesson">
<h1 data-editor-field="lesson-title">Titre de la leçon</h1>
<section data-editor-field="lesson-intro">Introduction pédagogique</section>
<section data-editor-field="morphosyntaxe-title">Titre de la morphosyntaxe</section>
<section data-editor-field="morphosyntaxe-content">Contenu complet de la leçon de morphosyntaxe</section>
<section data-editor-field="lexique-title">Titre du lexique</section>
<section data-editor-field="lexique-content">Contenu complet du lexique</section>
IMPORTANT : si la demande concerne uniquement la morphosyntaxe, complétez réellement le titre et le contenu de morphosyntaxe ; si elle concerne uniquement le lexique, complétez réellement le titre et le contenu du lexique. Ne laissez pas de cadre vide.
Retournez UNIQUEMENT le code HTML complet, sans JSON et sans Markdown.
Demande précise : [ÉCRIVEZ ICI LA NOTION, LA SEMAINE, LES OBJECTIFS ET LES EXIGENCES].`,
  exo:`Vous êtes le concepteur d’exercices de l’application « FRANÇAIS COLLÈGE 3ème ». Créez UN FICHIER HTML COMPLET, autonome, hors ligne et prêt à copier dans Acode pour UN EXERCICE.
DESIGN OBLIGATOIRE : bleu nuit #101b36, bleu #17264a, jaune #f5c400, fond #f8f9fc, cartes premium, boutons sobres, affichage Android responsive, sans CDN ni bibliothèque externe, JavaScript local uniquement. Footer exact : « @2026 Titan création ».
ADAPTEZ L’EXERCICE À LA CATÉGORIE DEMANDÉE : Morphosyntaxe, Lexique, compréhension, production, texte et questions, à compléter, relier, tableau, classement, transformation, justification, etc.
Pour la morphosyntaxe : vérifiez la règle et construisez des exercices progressifs avec corrections.
Pour le lexique : travaillez le sens, les familles de mots, champs lexicaux/sémantiques, synonymes/antonymes ou emploi en contexte selon la demande.
Pour « texte et questions » : le texte est affiché une seule fois et les questions sont ouvertes ; ne transformez pas automatiquement ces questions en QCM.
Les consignes adressées à l’élève utilisent la 2e personne du pluriel.
STRUCTURE DE RECONNAISSANCE OBLIGATOIRE :
<meta name="app-kind" content="exercise">
<h1 data-editor-field="exercise-title">Titre de l’exercice</h1>
<section data-editor-field="exercise-type">Type d’exercice</section>
<section data-editor-field="exercise-tag">Morphosyntaxe ou Lexique</section>
<section data-editor-field="exercise-instruction">Consigne</section>
<section data-editor-field="exercise-content">Questions, tableaux, éléments à relier ou activités</section>
<section data-editor-field="exercise-correction">Correction complète</section>
Organisez les activités dans des cadres distincts et lisibles. Pour un exercice « relier », utilisez une présentation claire avec éléments gauche/droite et flèches ou zones de liaison. Pour un tableau, utilisez un vrai tableau responsive. Pour « à compléter », utilisez des espaces/champs visuels adaptés.
Retournez UNIQUEMENT le code HTML complet, sans JSON et sans Markdown.
Demande précise : [ÉCRIVEZ ICI LA SEMAINE, LA NOTION, LE TYPE D’EXERCICE, LE NOMBRE DE QUESTIONS ET LES EXIGENCES].`
};
function promptCard(kind,label,icon){
  return `<div class="editor-prompt-card" data-prompt-kind="${kind}">
    <div class="editor-prompt-head"><span>${icon}</span> ${label}</div>
    <p class="editor-help">Copiez le prompt, ajoutez votre demande précise, puis utilisez le fichier HTML généré pour remplir automatiquement les cadres correspondants de l’éditeur.</p>
    <button type="button" class="btn btn-s editor-copy-btn" data-copy-prompt="${kind}">📋 Copier le prompt puissant</button>
  </div>`;
}
function editorPromptKind(){
  const card=document.querySelector('.editor-prompt-card[data-prompt-kind]');
  return card?.dataset.promptKind||'lesson';
}
function cleanGeneratedFile(raw){
  let s=String(raw||'').trim();
  s=s.replace(/^```(?:html)?\s*/i,'').replace(/\s*```$/,'').trim();
  return s;
}
function generatedFileName(kind){
  const title=$('#edTitle')?.value||$('#edLTitle')?.value||$('#edOTitre')?.value||'';
  const base=slugify(title)||('contenu_'+kind+'_'+Date.now());
  return base+'.html';
}
function htmlText(doc,selector){
  const el=doc.querySelector(selector); return el?String(el.innerText||el.textContent||'').trim():'';
}
function fillEditorFramesFromGeneratedHTML(kind,raw){
  const clean=cleanGeneratedFile(raw);
  if(!/^<!doctype html|<html[\s>]/i.test(clean)) throw new Error('Le résultat ne ressemble pas à un fichier HTML complet.');
  const parser=new DOMParser();
  const doc=parser.parseFromString(clean,'text/html');
  if(doc.querySelector('parsererror')) throw new Error('HTML invalide.');
  const val=(id,v)=>{const el=document.getElementById(id);if(el&&v)el.value=v;};
  if(kind==='theme'){
    val('edTitle',htmlText(doc,'[data-editor-field="theme-title"]')||doc.querySelector('h1')?.textContent||doc.title);
    val('edDesc',htmlText(doc,'[data-editor-field="theme-description"]'));
    val('edType',htmlText(doc,'[data-editor-field="theme-type"]'));
  }else if(kind==='lesson'){
    val('edLTitle',htmlText(doc,'[data-editor-field="lesson-title"]')||doc.querySelector('h1')?.textContent||doc.title);
    val('edLIntro',htmlText(doc,'[data-editor-field="lesson-intro"]'));
    val('edLMsTitle',htmlText(doc,'[data-editor-field="morphosyntaxe-title"]'));
    val('edLMs',htmlText(doc,'[data-editor-field="morphosyntaxe-content"]'));
    val('edLLexTitle',htmlText(doc,'[data-editor-field="lexique-title"]'));
    const lex=htmlText(doc,'[data-editor-field="lexique-content"]');
    if(lex){const box=document.querySelector('[data-list="llex"]');if(box){box.innerHTML='';lex.split(/\n+/).map(x=>x.trim()).filter(Boolean).forEach((x,i)=>{const row=document.createElement('div');row.className='editor-list-row';row.innerHTML=`<span class="editor-num">${i+1}</span><input class="llex-item" value="${esc(x).replace(/"/g,'&quot;')}"><button type="button" class="mini plus" data-add="llex">＋</button><button type="button" class="mini minus" data-del="llex">−</button>`;box.appendChild(row);});bindSimpleRows('llex');}}
  }else{
    val('edOTitre',htmlText(doc,'[data-editor-field="exercise-title"]')||doc.querySelector('h1')?.textContent||doc.title);
    val('edOType',htmlText(doc,'[data-editor-field="exercise-type"]'));
    val('edOCat',htmlText(doc,'[data-editor-field="exercise-tag"]'));
    val('edOConsigne',htmlText(doc,'[data-editor-field="exercise-instruction"]'));
    val('edOCorrige',htmlText(doc,'[data-editor-field="exercise-correction"]'));
    const qBox=document.getElementById('exoquestions'), qEls=[...doc.querySelectorAll('[data-editor-question]')];
    if(qBox&&qEls.length){qBox.innerHTML='';qEls.forEach((q,i)=>{const card=document.createElement('div');card.className='q-card';const qc=q.getAttribute('data-editor-correction')||'';card.innerHTML=`<div class="q-head"><b>Question ${i+1}</b><div><button type="button" class="mini plus" data-q-add="exoquestions">＋</button><button type="button" class="mini minus" data-q-del="exoquestions">−</button></div></div><textarea class="q-q" placeholder="Écrivez la question ouverte">${esc(q.textContent.trim())}</textarea><textarea class="q-a" placeholder="Réponse attendue / correction">${esc(qc)}</textarea>`;qBox.appendChild(card);});renumberQuestions(qBox);bindQuestionRows('exoquestions');}
  }
  return clean;
}
function renderPromptTools(){
  const box=$('#promptTools'); if(!box)return;
  box.innerHTML=`<div class="editor-section editor-prompt-tools">
    <h3>🤖 Générer des fichiers HTML adaptés à notre application</h3>
    <div class="editor-prompt-grid">
      ${promptCard('theme','Thème','📚')}
      ${promptCard('lesson','Leçon / semaine','📖')}
      ${promptCard('exo','Exercice','✏️')}
    </div>
    <div class="editor-section">
      <h4>📄 Fichier HTML généré</h4>
      <div class="editor-help">Le résultat attendu est un vrai fichier <b>.html</b>, sans JSON. Après génération, collez le code complet ci-dessous : le bouton remplira aussi les cadres de l’éditeur reconnus dans le fichier.</div>
      <div class="editor-file-output">
        <div class="editor-file-head"><span class="editor-file-name" id="edGeneratedFileName">contenu.html</span><span>HTML</span></div>
        <textarea id="edPromptResult" rows="14" placeholder="Collez ici le fichier HTML complet généré par l’assistant IA…"></textarea>
        <div class="editor-file-actions">
          <button class="btn btn-p" id="edGenerateCode">⚡ Générer ce code et compléter les cadres</button>
          <button class="btn btn-s" id="edDownloadHtml">💾 Enregistrer .html</button>
          <button class="btn btn-s" id="edClearPrompt">Vider</button>
        </div>
        <div class="editor-status" id="edPromptStatus"></div>
      </div>
    </div>
  </div>`;
  $$('.editor-prompt-card').forEach(card=>card.onclick=()=>{window.__activePromptKind=card.dataset.promptKind;const n=$('#edGeneratedFileName');if(n)n.textContent=generatedFileName(window.__activePromptKind);});
  $$('[data-copy-prompt]').forEach(btn=>{
    btn.onclick=e=>{e.stopPropagation();window.__activePromptKind=btn.dataset.copyPrompt;const n=$('#edGeneratedFileName');if(n)n.textContent=generatedFileName(window.__activePromptKind);copyToClipboard(PROMPT_TEMPLATES[btn.dataset.copyPrompt]||'',btn);};
  });
  $('#edGenerateCode').onclick=()=>{
    const raw=$('#edPromptResult').value.trim(),kind=window.__activePromptKind||editorPromptKind();
    if(!raw){promptStatus('Collez d’abord le fichier HTML généré.',false);return;}
    try{
      const clean=fillEditorFramesFromGeneratedHTML(kind,raw);
      $('#edPromptResult').value=clean;
      $('#edGeneratedFileName').textContent=generatedFileName(kind);
      promptStatus('✓ Code HTML généré et cadres correspondants complétés : '+(kind==='lesson'?'titre / contenu de leçon / morphosyntaxe / lexique':kind==='exo'?'titre / consigne / exercice':'titre / type / description')+'.',true);
    }catch(e){promptStatus('⚠️ '+e.message,false);}
  };
  $('#edDownloadHtml').onclick=()=>{
    const raw=cleanGeneratedFile($('#edPromptResult').value);if(!raw){promptStatus('Aucun fichier HTML à enregistrer.',false);return;}
    const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([raw],{type:'text/html;charset=utf-8'}));a.download=$('#edGeneratedFileName').textContent||'contenu.html';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),1000);promptStatus('✓ Fichier HTML prêt à utiliser dans Acode.',true);
  };
  $('#edClearPrompt').onclick=()=>{$('#edPromptResult').value='';const st=$('#edPromptStatus');if(st){st.textContent='';st.className='editor-status';}};
  window.__activePromptKind='lesson';
  $('#edGeneratedFileName').textContent=generatedFileName('lesson');
}
function promptStatus(msg,ok){const el=$('#edPromptStatus');if(!el)return;el.textContent=msg;el.className='editor-status on '+(ok?'ok':'err');}
function applyGeneratedResult(){
  const raw=$('#edPromptResult').value.trim();
  if(!raw){promptStatus('Collez d’abord un résultat JSON.',false);return;}
  let data;
  try{
    const m=raw.match(/\{[\s\S]*\}/);
    data=JSON.parse(m?m[0]:raw);
  }catch(e){promptStatus('⚠️ JSON invalide : '+e.message,false);return;}
  const pid=$('#edPid').value,p=P[pid];
  try{
    if(Array.isArray(data.semaines)){
      // Thème complet
      const title=String(data.titre||'Nouveau thème').trim();
      let tid=$('#edTid').value;
      let t;
      if(tid==='__new'||!p.themes.some(x=>x.id===tid)){
        let base=slugify(title)||('theme_'+Date.now()),id=base,n=2;while(p.themes.some(x=>x.id===id))id=base+'_'+n++;
        t={id,titre:title,desc:data.desc||'',type:data.type||'Français',v:data.v||'',semaines:[],texte:data.texte||{titre:'Texte de base',contenu:[]},questions:data.questions||[],exos:[]};
        p.themes.push(t); tid=id;
      }else{
        t=p.themes.find(x=>x.id===tid);
        t.titre=title; t.desc=data.desc||t.desc; t.type=data.type||t.type; t.v=data.v||t.v;
        t.texte=data.texte||t.texte; t.questions=data.questions||t.questions;
      }
      t.semaines=data.semaines.map((s,i)=>({code:s.code||'S'+(i+1),titre:s.titre||'Semaine '+(i+1),desc:s.desc||'',objectif:s.objectif||'',lecon:{intro:s.lecon?.intro||'',points:s.lecon?.points||[],msTitre:s.lecon?.msTitre||'Leçon de morphosyntaxe',ms:s.lecon?.ms||'',lexTitre:s.lecon?.lexTitre||'Leçon de lexique',lex:s.lecon?.lex||[],voirGrammaire:true},exosOuverts:(s.exosOuverts||[]).map(e=>({titre:e.titre||'Exercice',type:e.type||'question',tag:e.tag||'Morphosyntaxe',consigne:e.consigne||'',questions:e.questions||[],corrige:e.corrige||[],lignes:e.lignes})),exos:[]}));
      if(saveEditorData()){
        promptStatus('✓ Thème généré : '+t.semaines.length+' semaine(s) créée(s)/mises à jour.',true);
        $('#edTid').innerHTML='<option value="__new">＋ Nouveau thème</option>'+editorThemeOptions(pid,tid);
        $('#edTid').value=tid;
        update_theme_after_prompt(tid);
      }
    }else if(data.code||data.lecon){
      // Leçon / semaine seule -> ajoutée au thème actuellement sélectionné
      const tid=$('#edTid').value; const t=p.themes.find(x=>x.id===tid);
      if(!t){promptStatus('Choisissez d’abord un thème existant pour y ajouter cette leçon.',false);return;}
      const s={code:data.code||'S'+(t.semaines.length+1),titre:data.titre||'Nouvelle semaine',desc:data.desc||'',objectif:data.objectif||'',lecon:{intro:data.lecon?.intro||'',points:data.lecon?.points||[],msTitre:data.lecon?.msTitre||'Leçon de morphosyntaxe',ms:data.lecon?.ms||'',lexTitre:data.lecon?.lexTitre||'Leçon de lexique',lex:data.lecon?.lex||[],voirGrammaire:true},exosOuverts:[],exos:[]};
      t.semaines.push(s);
      if(saveEditorData()){
        promptStatus('✓ Leçon « '+esc(s.titre)+' » ajoutée ('+s.code+').',true);
        $('#edLSi').innerHTML='<option value="__new">＋ Nouvelle semaine + leçon</option>'+editorWeekOptions(pid,tid,String(t.semaines.length-1));
        $('#edLSi').value=String(t.semaines.length-1);
        renderEditorLesson();
      }
    }else if(Array.isArray(data.questions)){
      // Exercice seul -> ajouté à la semaine actuellement sélectionnée
      const tid=$('#edTid').value; const t=p.themes.find(x=>x.id===tid);
      const si=+($('#edLSi').value==='__new'?-1:$('#edLSi').value);
      const s=t&&t.semaines?.[si];
      if(!s){promptStatus('Choisissez d’abord une semaine enregistrée pour y ajouter cet exercice.',false);return;}
      s.exosOuverts=s.exosOuverts||[];
      s.exosOuverts.push({titre:data.titre||'Exercice',type:data.type||'question',tag:data.tag||'Morphosyntaxe',consigne:data.consigne||'',questions:data.questions||[],corrige:data.corrige||[],lignes:data.lignes});
      s.exos=[];
      if(saveEditorData()){
        promptStatus('✓ Exercice « '+esc(data.titre||'Exercice')+' » ajouté.',true);
        refreshExoList();
      }
    }else{
      promptStatus('⚠️ Format non reconnu (ni thème, ni leçon, ni exercice).',false);
    }
  }catch(e){ promptStatus('⚠️ Erreur : '+e.message,false); }
}
function update_theme_after_prompt(tid){
  // Re-rend l'onglet Thème pour que le thème généré affiche directement son interface (leçon + exercices).
  renderEditor();
  setTimeout(()=>refreshCurrentView(),200);
}
function saveThemeEditor(){
  if(!editorConfirm('Enregistrer les modifications de ce thème ? Le texte et les questions sont gérés dans Éditeur → Leçons.')) return;
  const pid=$('#edPid').value,p=P[pid],selected=$('#edTid').value,title=$('#edTitle').value.trim();if(!title){setEditorStatus('Le titre du thème est obligatoire.',false);return;}
  if(selected==='__new'){let base=slugify(title)||('theme_'+Date.now()),id=base,n=2;while(p.themes.some(t=>t.id===id))id=base+'_'+n++;p.themes.push({id,titre:title,desc:$('#edDesc').value.trim(),type:$('#edType').value.trim()||'Français',v:$('#edValue').value.trim()||'',semaines:[newWeek(1,title)],texte:{titre:'Texte de base',contenu:[]},questions:[],exos:[]});}
  else{const t=p.themes.find(x=>x.id===selected);if(!t)return;t.titre=title;t.desc=$('#edDesc').value.trim();t.type=$('#edType').value.trim();t.v=$('#edValue').value.trim();}
  if(saveEditorData()){setEditorStatus('✓ Thème enregistré. Le texte et les questions restent dans Éditeur → Leçons.',true);setTimeout(()=>{closeEditor();refreshCurrentView();},400);}
}
function deleteThemeEditor(){const pid=$('#edPid').value,tid=$('#edTid').value,p=P[pid];if(!editorConfirm('⚠️ Supprimer ce thème, son texte, ses questions, ses leçons et ses exercices ? Cette action est irréversible.'))return;p.themes=p.themes.filter(t=>t.id!==tid);saveEditorData();closeEditor();viewLecons();}
function newWeek(n,title){return{code:'S'+n,titre:'Nouvelle semaine',desc:'Description de la semaine',objectif:'Objectif d’apprentissage',lecon:{intro:'',points:[],ms:'',lex:[]},exosOuverts:[],exos:[]};}
function slugify(s){return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'').slice(0,40);}
function setEditorStatus(msg,ok){const el=$('#edStatus');if(!el)return;el.textContent=msg;el.className='editor-status on '+(ok?'ok':'err');}
function lessonImportPanel(){
  return `<div class="editor-section editor-import-universal lesson-import-panel">
    <h3>📥 Importer une leçon — analyse automatique</h3>
    <div class="editor-help">Importez un fichier de cours. L’éditeur tente de détecter automatiquement le titre, le texte, les questions, les réponses/corrections et les parties Morphosyntaxe / Lexique. Si plusieurs leçons sont clairement détectées, elles sont ajoutées aux semaines correspondantes.</div>
    <label class="import-file-btn">📂 Choisir un fichier<input id="edLessonFile" type="file" accept="*/*"></label>
    <div id="edLessonFileList" class="editor-import-list"></div>
    <textarea id="edLessonImportedText" rows="10" placeholder="Le contenu extrait apparaîtra ici. Vous pouvez aussi coller directement le contenu du fichier…"></textarea>
    <div class="editor-actions">
      <button type="button" class="btn btn-p" id="edLessonAnalyze">⚡ Analyser et remplir la leçon</button>
      <button type="button" class="btn btn-s" id="edLessonCopyExtract">📋 Copier le contenu extrait</button>
    </div>
    <div class="editor-status" id="edLessonImportStatus"></div>
  </div>`;
}
function normalizeLessonText(v){return String(v||'').replace(/\r/g,'').replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim();}
function detectLessonParts(raw){
  const text=normalizeLessonText(raw);
  let title='', body=text, questions=[], answers=[];
  const htmlLike=/<(?:html|body|h[1-6]|p|section|article|div|ol|ul|li|table)\b/i.test(text);
  if(htmlLike){
    const d=new DOMParser().parseFromString(text,'text/html');
    const clean=x=>normalizeLessonText(x?.textContent||'');
    const hs=[...d.querySelectorAll('h1,h2,h3')];
    title=clean(hs.find(h=>/^\s*(leçon|lesson|cours|titre)\b/i.test(clean(h)))||hs[0]);
    const qNodes=[...d.querySelectorAll('[data-question], .question, .questions li, ol li, li')];
    qNodes.forEach(n=>{const q=clean(n);if(q && q.length>8 && /[?]$/.test(q))questions.push({q,corrige:''});});
    const corrNodes=[...d.querySelectorAll('[data-correction], .correction, .reponse, .réponse, .answer')];
    answers=corrNodes.map(clean).filter(Boolean);
    body=clean(d.body)||text;
  }
  if(!title){
    const lines=text.split('\n').map(x=>x.trim()).filter(Boolean);
    title=(lines.find(x=>/^(leçon|cours|lesson)\b/i.test(x))||lines[0]||'Nouvelle leçon').replace(/^(leçon|cours|lesson)\s*[:\-–—]?\s*/i,'').trim();
  }
  const qSection=body.split(/\n\s*(?:questions?|compréhension|activités?|exercices?)\s*[:\-]?\s*\n?/i);
  if(qSection.length>1){
    const qtxt=qSection.slice(1).join('\n');
    const lines=qtxt.split('\n').map(x=>x.trim()).filter(Boolean);
    questions=lines.filter(x=>/[?]$/.test(x)).map(q=>({q:q.replace(/^\d+[.)-]\s*/,''),corrige:''}));
  }
  const ansMatch=body.match(/(?:réponses?|corrigé|corrections?)\s*[:\-]?\s*([\s\S]*)$/i);
  if(ansMatch){answers=ansMatch[1].split('\n').map(x=>x.trim()).filter(Boolean);}
  questions=questions.slice(0,30);
  questions.forEach((x,i)=>x.corrige=answers[i]||'');
  const morph=/\b(morphosyntaxe|grammaire|conjugaison|syntaxe)\b/i.test(body);
  const lex=/\b(lexique|vocabulaire|champ lexical|champ sémantique|synonyme|antonyme)\b/i.test(body);
  let type=morph&&lex?'Morphosyntaxe + Lexique':morph?'Morphosyntaxe':lex?'Lexique':'';
  const sections={};
  if(morph){const m=body.match(/(?:morphosyntaxe|grammaire|conjugaison|syntaxe)[\s\S]{0,1200}/i);sections.ms=normalizeLessonText(m?.[0]||'');}
  if(lex){const m=body.match(/(?:lexique|vocabulaire|champ lexical|champ sémantique)[\s\S]{0,1200}/i);sections.lex=normalizeLessonText(m?.[0]||'');}
  return {title,body,questions,type,sections};
}
function detectMultipleLessons(raw){
  const d=new DOMParser().parseFromString(String(raw||''),'text/html');
  const heads=[...d.querySelectorAll('h1,h2,h3')].map(h=>({el:h,text:normalizeLessonText(h.textContent)})).filter(x=>x.text);
  const candidates=heads.filter(x=>/^(leçon|lesson|cours)\s*\d*\b/i.test(x.text)||/^(S\d+|semaine\s*\d+)\b/i.test(x.text));
  if(candidates.length<2)return [];
  return candidates.map((h,i)=>{
    const next=candidates[i+1]?.el;
    let node=h.el.nextElementSibling, parts=[h.text];
    while(node && node!==next){parts.push(node.outerHTML||node.textContent||'');node=node.nextElementSibling;}
    return detectLessonParts(parts.join('\n'));
  }).filter(x=>x.title||x.body);
}
function bindLessonImporter(){
  const input=$('#edLessonFile'), out=$('#edLessonImportedText'), list=$('#edLessonFileList'), status=$('#edLessonImportStatus');
  const setStatus=(m,ok=true)=>{if(status){status.textContent=m;status.className='editor-status on '+(ok?'ok':'err');}};
  if(input)input.onchange=async()=>{const f=input.files?.[0];if(!f)return;list.innerHTML=`<div class="editor-import-file"><b>${esc(f.name)}</b><span>${esc(f.type||'format inconnu')} · ${(f.size/1024).toFixed(1)} Ko</span></div>`;try{out.value=await f.text();setStatus('✓ Fichier chargé. Cliquez sur « Analyser et remplir la leçon ».');}catch(e){out.value='';setStatus('⚠️ Ce format ne peut pas être lu directement hors ligne. Utilisez son contenu copié depuis votre lecteur.',false);}};
  $('#edLessonCopyExtract')?.addEventListener('click',()=>copyToClipboard(out?.value||'',$('#edLessonCopyExtract')));
  $('#edLessonAnalyze')?.addEventListener('click',()=>{
    const raw=out?.value?.trim()||'';if(!raw){setStatus('⚠️ Importez ou collez d’abord un contenu.',false);return;}
    try{
      const many=detectMultipleLessons(raw), one=detectLessonParts(raw), data=many.length?many[0]:one;
      if($('#edLTitle'))$('#edLTitle').value=data.title||$('#edLTitle').value;
      if($('#edTextTitle')&&data.title)$('#edTextTitle').value=data.title;
      if($('#edTextGlobal'))$('#edTextGlobal').value=data.body||'';
      if($('#edLMs')&&data.sections.ms)$('#edLMs').value=data.sections.ms;
      if($('#edLLexTitle')&&data.type==='Lexique')$('#edLLexTitle').value='Leçon de lexique';
      if($('#edLMsTitle')&&data.type==='Morphosyntaxe')$('#edLMsTitle').value='Leçon de morphosyntaxe';
      if($('#textquestions')){const qs=data.questions||[];$('#textquestions').innerHTML=questionRows(qs,'textquestions');bindQuestionRows('textquestions');}
      if(many.length>1){
        const pid=$('#edLPid').value,tid=$('#edLTid').value,t=P[pid]?.themes.find(x=>x.id===tid),current=+$('#edLSi').value;
        if(t){many.forEach((item,i)=>{if(i===0)return;const base=newWeek((t.semaines?.length||0)+1,t.titre||'');base.code='S'+((t.semaines?.length||0)+1);base.titre=item.title||'Nouvelle leçon';base.lecon.intro=item.body||'';base.lecon.ms=item.sections.ms||'';base.lecon.lex=item.sections.lex?[item.sections.lex]:[];base.lecon.msTitre=item.type?.includes('Morpho')?'Leçon de morphosyntaxe':'Leçon de morphosyntaxe';base.lecon.lexTitre=item.type?.includes('Lexique')?'Leçon de lexique':'Leçon de lexique';base.questions=item.questions||[];t.semaines.push(base);});saveEditorData();refreshCurrentView();}
      }
      setStatus(`✓ Détection terminée : ${many.length||1} leçon(s) détectée(s)${many.length>1?' et ajoutée(s) automatiquement':''}.`,true);
    }catch(e){setStatus('⚠️ Analyse impossible : '+e.message,false);}
  });
}
function renderEditorLesson(box){
  const p=$('#edLPid').value,tid=$('#edLTid').value,t=P[p]?.themes.find(x=>x.id===tid);
  if(!t){$('#lessonFields').innerHTML='';return;}
  const isNew=$('#edLSi').value==='__new',si=isNew?(t.semaines?.length||0):+$('#edLSi').value,s=isNew?newWeek((t?.semaines?.length||0)+1,t?.titre||''):t?.semaines?.[si];
  const isTextWeek=si===0||si===1;
  $('#lessonFields').innerHTML=`<div class="editor-row">${editorInput('Code','edLCode',isNew?'S'+((t?.semaines?.length||0)+1):s?.code,'S1')}${editorInput('Titre de la semaine','edLTitle',s?.titre,'Ex. Les temps du récit')}</div>${editorInput('Description','edLDesc',s?.desc,'Résumé de la semaine')}${editorInput('Objectif','edLObjectif',s?.objectif,'Compétence visée')}${isTextWeek?`<div class="editor-section"><h3>📄 Titre du texte et texte de base — ${esc(s?.code||'S1')}</h3><div class="editor-help">Affiché directement (sans « mise en situation ») : titre du texte s’il existe, puis le texte de base. Ce texte est commun à S1 et S2.</div>${editorInput('Titre du texte','edTextTitle',t?.texte?.titre||'Texte de base','Titre du texte')}${editorArea('Texte global','edTextGlobal',(t?.texte?.contenu||[]).join('\n\n'),'Saisissez ici le texte complet…')}<div class="editor-section"><h4>❓ Questions de compréhension du texte</h4><div class="editor-help">Affichées juste après le texte de base.</div>${questionRows(t?.questions||[],'textquestions')}</div></div>`:`<div class="editor-section"><h3>📝 Introduction pédagogique de la leçon</h3><div class="editor-help">Présentez brièvement la notion à apprendre (affiché à partir de S3, sans texte de base).</div>${editorArea('Introduction de la leçon','edLIntro',s?.lecon?.intro,'Présentez la notion, son intérêt et ce que l’élève va apprendre…')}</div>`}<div class="editor-section"><h3>🔗 Navigation de la leçon</h3><label style="display:flex;align-items:center;gap:9px;font-size:.75rem;font-weight:800;color:var(--text)"><input id="edLGrammar" type="checkbox" ${s?.lecon?.voirGrammaire!==false?'checked':''}> Afficher « Voir la Grammaire » et l’ouvrir directement dans Grammaire</label></div><div class="editor-section"><h3>📌 Points clés</h3>${editorRows(s?.lecon?.points||[],'Point clé','lpoints','textarea')}</div><div class="editor-section"><h3>📘 Leçon(s) de morphosyntaxe</h3><div class="editor-help">Titre et contenu de la leçon de morphosyntaxe pour cette semaine.</div>${editorInput('Titre','edLMsTitle',s?.lecon?.msTitre||'Leçon de morphosyntaxe','Ex. Les connecteurs spatiaux')} ${editorArea('Contenu de la morphosyntaxe','edLMs',s?.lecon?.ms,'Règle / notion + exemples')}</div><div class="editor-section"><h3>📚 Leçon de lexique</h3>${editorInput('Titre','edLLexTitle',s?.lecon?.lexTitre||'Leçon de lexique','Ex. Le vocabulaire de l’artisanat')}<div class="editor-help">Ajoutez ici les mots, expressions, définitions ou catégories lexicales exigés par le tableau du thème.</div>${editorRows(s?.lecon?.lex||[],'Mot / expression / définition','llex')}</div><div class="editor-actions"><button class="btn btn-p" id="edSaveLesson">${isNew?'＋ Ajouter la leçon':'💾 Enregistrer la leçon'}</button><button class="btn btn-s" id="edInitLesson">↺ Initialiser</button>${!isNew?'<button class="btn btn-s editor-danger" id="edDeleteLesson">− Supprimer la leçon</button>':''}</div>`;
  bindSimpleRows('lpoints');bindSimpleRows('llex');
  if(isTextWeek){bindQuestionRows('textquestions');}
  $('#edSaveLesson').onclick=saveLessonEditor;$('#edInitLesson').onclick=()=>{if(editorConfirm('Initialiser les champs de cette leçon avec les données actuellement enregistrées ?')) renderEditorLesson();};if(!isNew)$('#edDeleteLesson').onclick=deleteLessonEditor;
  // scope exercices to the same week being edited
  $('#edEPid').value=p; $('#edETid').value=tid; $('#edESi').value=isNew?'__pending':String(si);
  refreshExoList();
}
function saveLessonEditor(){
  if(!editorConfirm('Enregistrer cette leçon et ses modifications ?')) return;
  const pid=$('#edLPid').value,tid=$('#edLTid').value,t=P[pid].themes.find(x=>x.id===tid);
  if(!t){setEditorStatus('Choisissez un thème.',false);return;}
  const val=id=>$('#'+id)?.value.trim()||'',isNew=$('#edLSi').value==='__new',si=isNew?t.semaines.length:+$('#edLSi').value;
  const s={code:val('edLCode')||'S'+(t.semaines.length+1),titre:val('edLTitle')||'Nouvelle semaine',desc:val('edLDesc'),objectif:val('edLObjectif'),lecon:{intro:val('edLIntro'),points:readRows('lpoints'),msTitre:val('edLMsTitle')||'Leçon de morphosyntaxe',ms:val('edLMs'),lexTitre:val('edLLexTitle')||'Leçon de lexique',lex:readRows('llex'),voirGrammaire:$('#edLGrammar').checked},exosOuverts:[],exos:[]};
  if(isNew)t.semaines.push(s);else{const old=t.semaines[si];s.exos=old.exos||[];s.exosOuverts=old.exosOuverts||[];t.semaines[si]=Object.assign(old,s);}
  if(si===0||si===1){
    t.texte=t.texte||{titre:'Texte de base',contenu:[]};
    t.texte.titre=val('edTextTitle')||t.texte.titre||'Texte de base';
    t.texte.contenu=[val('edTextGlobal')].filter(Boolean);
    t.questions=readQuestions('textquestions');
  }
  if(saveEditorData()){
    setEditorStatus('✓ Leçon enregistrée.',true);
    $('#edLSi').innerHTML='<option value="__new">＋ Nouvelle semaine + leçon</option>'+editorWeekOptions(pid,tid,String(si));
    $('#edLSi').value=String(si);
    renderEditorLesson();
    setTimeout(()=>{closeEditor();refreshCurrentView();},400);
  }
}
function deleteLessonEditor(){const pid=$('#edLPid').value,tid=$('#edLTid').value,si=+$('#edLSi').value,t=P[pid].themes.find(x=>x.id===tid);if(!editorConfirm('⚠️ Supprimer cette leçon/semaine et tous ses exercices ?'))return;t.semaines.splice(si,1);saveEditorData();closeEditor();goTheme(pid,tid);}
function exoCategoryLabel(tag){const t=String(tag||'').toLowerCase();if(t.startsWith('lex'))return'Lexique';return'Morphosyntaxe';}
function refreshExoList(){
  const p=P[$('#edEPid').value],t=p&&p.themes.find(x=>x.id===$('#edETid').value),si=$('#edESi').value;
  if(!t||si==='__pending'){$('#edEi').innerHTML='<option value="__new_morphosyntaxe">＋ Nouvel exercice — Morphosyntaxe</option><option value="__new_lexique">＋ Nouvel exercice — Lexique</option>';renderEditorExo();return;}
  const s=t.semaines?.[+si],arr=s?.exosOuverts||[];
  const ms=arr.map((e,i)=>({e,i})).filter(x=>exoCategoryLabel(x.e.tag)==='Morphosyntaxe');
  const lex=arr.map((e,i)=>({e,i})).filter(x=>exoCategoryLabel(x.e.tag)==='Lexique');
  $('#edEi').innerHTML=`<optgroup label="📘 Exercices de morphosyntaxe">
      <option value="__new_morphosyntaxe">＋ Nouvel exercice</option>
      ${ms.map(x=>`<option value="${x.i}">${x.i+1}. ${esc(x.e.titre||x.e.questions?.[0]?.q||'Exercice')}</option>`).join('')}
    </optgroup>
    <optgroup label="📚 Exercices de lexique">
      <option value="__new_lexique">＋ Nouvel exercice</option>
      ${lex.map(x=>`<option value="${x.i}">${x.i+1}. ${esc(x.e.titre||x.e.questions?.[0]?.q||'Exercice')}</option>`).join('')}
    </optgroup>`;
  renderEditorExo();
}
function renderEditorExo(box){
  const p=P[$('#edEPid').value],t=p&&p.themes.find(x=>x.id===$('#edETid').value),si=$('#edESi').value;
  if(!t||si==='__pending'){$('#exoFields').innerHTML='<div class="editor-help">Enregistrez d’abord la semaine (leçon) ci-dessus pour pouvoir ajouter ses exercices.</div>';return;}
  const s=t.semaines?.[+si],idx=$('#edEi').value,arr=s?.exosOuverts||[];const isNew=idx==='__new_morphosyntaxe'||idx==='__new_lexique';const e=isNew?null:arr?.[+idx];
  const defaultCat=idx==='__new_lexique'?'Lexique':(e?exoCategoryLabel(e.tag):'Morphosyntaxe');
  const DEFAULT_NEW_EXO_COUNT=3;
  const questions=e?.questions||(isNew?Array.from({length:DEFAULT_NEW_EXO_COUNT},()=>({q:'',corrige:''})):[]);
  const modeBanner=isNew
    ?`<div class="exo-mode-banner exo-mode-new"><span class="exo-mode-icon">＋</span><div><b>Nouvel exercice</b><span>Remplissez les cadres ci-dessous — ${DEFAULT_NEW_EXO_COUNT} questions sont prêtes par défaut, ajoutez-en ou retirez-en librement.</span></div></div>`
    :`<div class="exo-mode-banner exo-mode-edit"><span class="exo-mode-icon">✏️</span><div><b>Modification de l’exercice</b><span>« ${esc(e?.titre||'Exercice')} » — les champs ci-dessous sont pré-remplis avec les données enregistrées.</span></div></div>`;
  $('#exoFields').innerHTML=`<div class="exo-editor-card ${isNew?'exo-editor-new':'exo-editor-edit'}">${modeBanner}<div class="editor-section"><h3>1️⃣ Informations de l’exercice</h3><div class="editor-row">${editorInput('Titre','edOTitre',e?.titre,'Titre de l’exercice')}<div class="editor-field"><label>Catégorie</label><select id="edOCat"><option value="Morphosyntaxe" ${defaultCat==='Morphosyntaxe'?'selected':''}>Morphosyntaxe</option><option value="Lexique" ${defaultCat==='Lexique'?'selected':''}>Lexique</option></select></div></div>${editorInput('Type interne','edOType',e?.type||'question','question, completion, transformation, production, tableau…')}${editorArea('Consigne (2ᵉ personne du pluriel)','edOConsigne',e?.consigne||'Répondez par une phrase complète.','Consigne')}</div><div class="editor-section"><h3>2️⃣ ❓ Questions et réponses</h3>${questionRows(questions,'exoquestions')}</div>${editorArea('Correction générale','edOCorrige',Array.isArray(e?.corrige)?e.corrige.join('\n'):(e?.corrige||''),'Correction supplémentaire')}${editorInput('Nombre de lignes','edOLignes',e?.lignes||'','Pour une production écrite')}<div class="editor-actions"><button class="btn btn-p" id="edSaveExo">${e?'💾 Modifier l’exercice':'＋ Ajouter l’exercice'}</button>${e?'<button class="btn btn-s editor-danger" id="edDeleteExo">− Supprimer l’exercice</button>':''}</div></div>`;
  bindQuestionRows('exoquestions');$('#edSaveExo').onclick=saveExoEditor;if(e)$('#edDeleteExo').onclick=deleteExoEditor;
}
function saveExoEditor(){
  if(!editorConfirm('Enregistrer cet exercice et toutes ses questions/corrections ?')) return;
  const pid=$('#edEPid').value,tid=$('#edETid').value,si=+$('#edESi').value,t=P[pid].themes.find(x=>x.id===tid),s=t?.semaines?.[si];if(!s){setEditorStatus('Enregistrez d’abord la semaine (leçon).',false);return;}
  const idx=$('#edEi').value,questions=readQuestions('exoquestions');
  if(!questions.length){setEditorStatus('Ajoutez au moins une consigne/question ouverte.',false);return;}
  const e={titre:$('#edOTitre').value.trim()||'Nouvel exercice',type:$('#edOType').value.trim()||'question',tag:$('#edOCat').value||'Morphosyntaxe',consigne:$('#edOConsigne').value.trim(),questions,corrige:$('#edOCorrige').value.split(/\n+/).map(x=>x.trim()).filter(Boolean)};
  const l=$('#edOLignes').value.trim();if(l)e.lignes=+l;
  s.exosOuverts=s.exosOuverts||[];if(idx==='__new_morphosyntaxe'||idx==='__new_lexique')s.exosOuverts.push(e);else s.exosOuverts[+idx]=e;s.exos=[];
  if(saveEditorData()){setEditorStatus('✓ Exercice enregistré.',true);refreshExoList();setTimeout(()=>{closeEditor();refreshCurrentView();},400);}
}
function deleteExoEditor(){const pid=$('#edEPid').value,tid=$('#edETid').value,si=+$('#edESi').value,idx=+$('#edEi').value,t=P[pid].themes.find(x=>x.id===tid),s=t.semaines[si],arr=s.exosOuverts||[];if(!editorConfirm('⚠️ Supprimer cet exercice, toutes ses questions et ses corrections ?'))return;arr.splice(idx,1);saveEditorData();refreshExoList();setTimeout(()=>{closeEditor();goSemaine(pid,tid,si);},300);}
/* ============================================================
   SUJETS TYPES — éditeur local hors ligne
   ============================================================ */
const SUJETS_KEY='f3_sujets_types_v1';
const SUJETS_DEFAULT=[
 {id:'recit',titre:'Raconter une expérience',cat:'Narration',consigne:'Racontez une expérience personnelle ou imaginaire en organisant clairement les événements.',aide:'Utilisez les temps du récit et des connecteurs chronologiques.'},
 {id:'description',titre:'Décrire un lieu ou une personne',cat:'Description',consigne:'Décrivez précisément le lieu ou la personne indiquée afin de permettre au lecteur de se la représenter.',aide:'Organisez la description et utilisez des expansions du nom.'},
 {id:'argumentation',titre:'Donner son point de vue',cat:'Argumentation',consigne:'Exprimez votre opinion sur le sujet proposé et justifiez-la par au moins deux arguments et un exemple.',aide:'Utilisez des connecteurs logiques.'},
 {id:'lettre',titre:'Rédiger une lettre',cat:'Écrit fonctionnel',consigne:'Rédigez une lettre adaptée au destinataire, à la situation et à l’objectif indiqués.',aide:'Respectez la présentation et les formules de politesse.'},
 {id:'compte_rendu',titre:'Faire un compte rendu',cat:'Écrit fonctionnel',consigne:'Rédigez un compte rendu clair et chronologique à partir des informations données.',aide:'Gardez uniquement les informations essentielles.'}
];
let SUJETS=[];
try{SUJETS=JSON.parse(localStorage.getItem(SUJETS_KEY)||'null')||cloneData(SUJETS_DEFAULT);}catch(e){SUJETS=cloneData(SUJETS_DEFAULT);}
SUJETS=SUJETS.map(x=>({...x,typeTexte:x.typeTexte||x.cat||'Narratif',texte:x.texte||'',questions:Array.isArray(x.questions)?x.questions:[],cat:x.cat||x.typeTexte||'Sujet type'}));
const TYPE_MAP={Descriptif:'Explicatif',Injonctif:'Administratif',Dialogue:'Narratif',Lettre:'Administratif','Article de presse':'Argumentatif',Narration:'Narratif',Description:'Explicatif','Écrit fonctionnel':'Administratif',Argumentation:'Argumentatif'};
const EXEMPLES_SUJETS={
 Explicatif:{titre:'Pourquoi protéger l’environnement ?',texte:`L’environnement fournit à l’être humain l’eau, l’air et les ressources nécessaires à la vie. Pourtant, les déchets, la déforestation et la pollution menacent cet équilibre. Protéger la nature consiste notamment à réduire les déchets, économiser l’eau et préserver les arbres. Ces gestes simples contribuent à maintenir un cadre de vie sain pour les générations futures.`,questions:[{question:'Quel est le thème principal du texte ?',correction:'La protection de l’environnement.'},{question:'Citez deux menaces présentées dans le texte.',correction:'Les déchets et la déforestation, par exemple.'}],consigne:'Expliquez pourquoi chaque élève peut contribuer à la protection de son environnement.',aide:'Organisez vos idées et utilisez des connecteurs logiques.'},
 Narratif:{titre:'Une journée que je n’oublierai jamais',texte:`Ce matin-là, je partis très tôt pour rejoindre mes amis. Le ciel était encore gris lorsque nous entendîmes un bruit étrange près du chemin. Nous nous arrêtâmes, puis découvrîmes un petit chien perdu. Après quelques recherches, nous retrouvâmes son propriétaire dans le village voisin. Le soir, je rentrai chez moi heureux d’avoir participé à cette aventure.`,questions:[{question:'À quel moment commence le récit ?',correction:'Le récit commence le matin, très tôt.'},{question:'Quel événement déclenche l’aventure ?',correction:'La découverte d’un petit chien perdu.'}],consigne:'Racontez une aventure qui vous a particulièrement marqué.',aide:'Utilisez les temps du récit et des connecteurs chronologiques.'},
 Argumentatif:{titre:'Faut-il protéger les espaces publics ?',texte:`Les espaces publics appartiennent à toute la communauté. Les protéger est donc une responsabilité collective. Un espace propre et bien entretenu permet à chacun de circuler, de se détendre et de vivre dans un environnement agréable. À l’inverse, les dégradations et les déchets rendent ces lieux moins accueillants. Chaque citoyen peut agir en respectant les équipements et en évitant de jeter ses déchets.`,questions:[{question:'Quelle opinion le texte défend-il ?',correction:'Il faut protéger les espaces publics.'},{question:'Donnez un argument utilisé par l’auteur.',correction:'Ils permettent à chacun de vivre dans un environnement agréable.'}],consigne:'Donnez votre point de vue sur le respect des lieux publics et justifiez-le par deux arguments.',aide:'Présentez votre opinion, deux arguments et un exemple.'},
 Administratif:{titre:'Demande d’autorisation',texte:`Antananarivo, le 25 septembre 2026\n\nObjet : Demande d’autorisation pour organiser une activité scolaire\n\nMadame la Directrice,\nNous avons l’honneur de solliciter votre autorisation pour organiser une activité de lecture au sein de notre établissement. Cette activité aura pour objectif d’encourager les élèves à lire davantage et à partager leurs découvertes. Elle se déroulera dans la salle de classe, sous la responsabilité de notre enseignant.\n\nNous vous remercions de l’attention portée à notre demande.`,questions:[{question:'Quel est l’objet de cette lettre ?',correction:'Demander l’autorisation d’organiser une activité scolaire.'},{question:'Quel est l’objectif de l’activité ?',correction:'Encourager les élèves à lire et à partager leurs découvertes.'}],consigne:'Rédigez une demande administrative adaptée à une situation scolaire.',aide:'Respectez la présentation, l’objet, les formules d’appel et de politesse.'}
};
function addDefaultExamples(){
 const existing=new Set(SUJETS.map(x=>x.typeTexte));
 Object.keys(EXEMPLES_SUJETS).forEach(type=>{if(!existing.has(type)){const e=EXEMPLES_SUJETS[type];SUJETS.push({id:'exemple_'+type.toLowerCase(),typeTexte:type,titre:e.titre,texte:e.texte,questions:e.questions,consigne:e.consigne,aide:e.aide,cat:type});}});
 saveSujets();
}
addDefaultExamples();
function normalizeSujetRecord(x,i=0){const raw=String(x?.typeTexte||x?.cat||'Narratif').trim();const type=TYPE_MAP[raw]||(['Explicatif','Narratif','Argumentatif','Administratif','Autre'].includes(raw)?raw:'Narratif');const title=String(x?.titre||'Sujet sans titre').trim()||'Sujet sans titre';let id=String(x?.id||'').trim()||('sujet_'+Date.now()+'_'+i);return {...x,id,titre:title,typeTexte:type,cat:type,texte:String(x?.texte||''),questions:Array.isArray(x?.questions)?x.questions.map(q=>({question:String(q?.question||''),correction:String(q?.correction||'')})).filter(q=>q.question.trim()):[],consigne:String(x?.consigne||''),aide:String(x?.aide||'')};}
SUJETS=SUJETS.map(normalizeSujetRecord);
function saveSujets(){try{SUJETS=SUJETS.map(normalizeSujetRecord);localStorage.setItem(SUJETS_KEY,JSON.stringify(SUJETS));return true;}catch(e){console.error('Sujets types:',e);return false;}}
saveSujets();
function renderEditorSujet(box){
 const first=SUJETS[0]?.id||'';
 box.innerHTML=`<div class="editor-form">
   <div class="editor-field"><label>Sujet type</label><select id="edSujId"><option value="__new">＋ Nouveau sujet type</option>${SUJETS.map(x=>`<option value="${esc(x.id)}">${esc(x.titre)}</option>`).join('')}</select></div>
   <div class="file-io-grid">
   <div class="import-sujet-card"><div class="import-sujet-icon">📥</div><div class="import-sujet-body"><strong>Fichiers importés</strong><p>Importez un PDF, HTML ou DOCX. Le texte et les questions sont détectés puis placés dans l’éditeur.</p><label class="import-file-btn">📂 Importer un fichier<input id="importSujetFile" type="file" accept=".pdf,.html,.htm,.docx,application/pdf,text/html,application/vnd.openxmlformats-officedocument.wordprocessingml.document"></label><div id="importSujetStatus" class="import-sujet-status"></div></div></div>
 </div>
   <div class="editor-field"><label>1. Type de texte</label><select id="edSType">
    ${['Explicatif','Narratif','Argumentatif','Administratif','Autre'].map(x=>`<option>${x}</option>`).join('')}
   </select></div>
   <div class="editor-field"><label>Titre du sujet</label><input id="edSTitre" placeholder="Titre du sujet"></div>
   <div class="editor-section"><h3>📄 2. Texte</h3><p class="editor-help">Saisissez ici le texte support du sujet.</p><textarea id="edSTexte" rows="9" placeholder="Écrivez ou collez le texte…"></textarea></div>
   <div class="editor-section"><h3>❓ 3. Questions</h3><p class="editor-help">Ajoutez les questions qui accompagnent le texte.</p><div id="sujetQuestions"></div><button class="btn btn-s" id="addSujetQuestion">＋ Ajouter une question</button></div>
   <div class="editor-section"><h3>✍️ Consigne de production</h3><textarea id="edSConsigne" rows="4" placeholder="Consigne donnée à l'élève…"></textarea></div>
   <div class="editor-section"><h3>💡 Aide / critères</h3><textarea id="edSAide" rows="4" placeholder="Aide, critères de réussite ou éléments de correction…"></textarea></div>
   <div class="export-sujet-card export-bottom"><div class="import-sujet-icon">📤</div><div class="import-sujet-body"><strong>Fichiers exportés</strong><p>Exportez uniquement un sujet déjà enregistré.</p><div class="export-file-actions"><button type="button" class="pdf-btn" id="exportCurrentPdf">📄 PDF</button><button type="button" class="pdf-btn" id="exportCurrentCopy">📋 Copier</button></div></div></div>
   <div class="editor-actions"><button class="btn btn-p" id="edSaveSujet">💾 Enregistrer le sujet</button><button class="btn btn-s editor-danger" id="edDeleteSujet">− Supprimer</button></div>
   <div class="editor-status" id="edStatus"></div>
 </div>`;
 const update=()=>{
   const id=$('#edSujId').value,isNew=id==='__new',x=SUJETS.find(s=>s.id===id)||{titre:'Nouveau sujet type',typeTexte:'Narratif',texte:'',questions:[],consigne:'',aide:''};
   $('#edSType').value=x.typeTexte||'Narratif';$('#edSTitre').value=x.titre||'';$('#edSTexte').value=x.texte||'';$('#edSConsigne').value=x.consigne||'';$('#edSAide').value=x.aide||'';
   renderSujetQuestions(x.questions||[]);
   $('#edSaveSujet').textContent=isNew?'＋ Ajouter le sujet':'💾 Enregistrer le sujet';$('#edDeleteSujet').style.display=isNew?'none':'inline-flex';
 };
 $('#edSujId').onchange=update;$('#importSujetFile').onchange=importSujetFile;$('#exportCurrentPdf').onclick=()=>exportSujetPDF($('#edSujId').value);$('#exportCurrentCopy').onclick=()=>copySujet($('#edSujId').value);$('#edSaveSujet').onclick=saveSujetEditor;$('#edDeleteSujet').onclick=deleteSujetEditor;$('#addSujetQuestion').onclick=()=>{addQuestionEditor();};
 $('#edSujId').value=first;update();
}
function renderSujetQuestions(qs){
 const box=$('#sujetQuestions');box.innerHTML='';
 (qs.length?qs:[{question:'',correction:''}]).forEach(q=>addQuestionEditor(q));
}
function addQuestionEditor(q={question:'',correction:''}){
 const box=$('#sujetQuestions'),i=box.children.length;
 const el=document.createElement('div');el.className='sujet-q-editor';el.innerHTML=`<div class="editor-q-head"><b>Question ${i+1}</b><button type="button" class="mini-del">−</button></div><textarea class="sq-question" rows="2" placeholder="Question…">${esc(q.question||'')}</textarea><textarea class="sq-correction" rows="2" placeholder="Correction / réponse attendue…">${esc(q.correction||'')}</textarea>`;
 el.querySelector('.mini-del').onclick=()=>{el.remove();renumberSujetQuestions();};box.appendChild(el);renumberSujetQuestions();
}
function renumberSujetQuestions(){$$('#sujetQuestions .sujet-q-editor').forEach((el,i)=>el.querySelector('.editor-q-head b').textContent='Question '+(i+1));}
function collectSujetQuestions(){return Array.from($$('#sujetQuestions .sujet-q-editor')).map(el=>({question:$('.sq-question',el).value.trim(),correction:$('.sq-correction',el).value.trim()})).filter(q=>q.question);}
async function importSujetFile(e){
 const file=e.target.files?.[0];if(!file)return;
 const st=$('#importSujetStatus');st.className='import-sujet-status';st.textContent='⏳ Lecture et détection du texte…';
 try{
   const ext=(file.name.split('.').pop()||'').toLowerCase();let raw='';
   if(ext==='html'||ext==='htm') raw=await readHtmlSujet(file);
   else if(ext==='docx') raw=await readDocxSujet(file);
   else if(ext==='pdf') raw=await readPdfSujet(file);
   else throw new Error('Format non pris en charge.');
   if(!raw.trim()) throw new Error(ext==='pdf'?'Aucun texte exploitable. Si le PDF est scanné comme une image, une OCR est nécessaire.':'Aucun texte exploitable trouvé.');
   const parsed=detectSujetParts(raw);
   $('#edSujId').value='__new';
   ['edSTitre','edSTexte','edSConsigne','edSAide'].forEach(id=>{const el=$('#'+id);if(el)el.value='';});
   renderSujetQuestions([]);
   $('#edSTitre').value=parsed.titre||file.name.replace(/\.[^.]+$/,'');
   $('#edSType').value=parsed.typeTexte;
   $('#edSTexte').value=parsed.texte;
   renderSujetQuestions(parsed.questions.length?parsed.questions:[{question:'',correction:''}]);
   $('#edSConsigne').value=parsed.consigne||'';$('#edSAide').value='Importé depuis '+file.name;
   st.className='import-sujet-status ok';st.textContent=`✓ Import réussi : ${parsed.texte? 'texte détecté':''}${parsed.questions.length?' + '+parsed.questions.length+' question(s) détectée(s)':''}. Vérifiez avant d’enregistrer.`;
 }catch(err){st.className='import-sujet-status err';st.textContent='⚠️ '+(err.message||'Impossible de lire le fichier.');}
 e.target.value='';
}
async function readHtmlSujet(file){const html=await file.text();const doc=new DOMParser().parseFromString(html,'text/html');doc.querySelectorAll('script,style,noscript').forEach(x=>x.remove());return doc.body?.innerText||doc.documentElement.innerText||'';}
async function readDocxSujet(file){
 const b=new Uint8Array(await file.arrayBuffer()), dv=new DataView(b.buffer);
 let eocd=-1; for(let i=b.length-22;i>=Math.max(0,b.length-65557);i--){if(dv.getUint32(i,true)===0x06054b50){eocd=i;break;}}
 if(eocd<0) throw new Error('DOCX invalide : archive ZIP introuvable.');
 const cdSize=dv.getUint32(eocd+12,true),cdOff=dv.getUint32(eocd+16,true); let pos=cdOff, target=null;
 while(pos<cdOff+cdSize){if(dv.getUint32(pos,true)!==0x02014b50){pos++;continue;}const method=dv.getUint16(pos+10,true),cs=dv.getUint32(pos+20,true),us=dv.getUint32(pos+24,true),fn=dv.getUint16(pos+28,true),ex=dv.getUint16(pos+30,true),cm=dv.getUint16(pos+32,true),lh=dv.getUint32(pos+42,true);const name=new TextDecoder().decode(b.slice(pos+46,pos+46+fn));if(name==='word/document.xml'){target={method,cs,us,lh};break;}pos+=46+fn+ex+cm;}
 if(!target) throw new Error('DOCX : word/document.xml introuvable.');
 const lf=target.lh;if(dv.getUint32(lf,true)!==0x04034b50)throw new Error('DOCX : en-tête invalide.');const fn=dv.getUint16(lf+26,true),ex=dv.getUint16(lf+28,true),data=b.slice(lf+30+fn+ex,lf+30+fn+ex+target.cs);
 let xml;if(target.method===0)xml=new TextDecoder().decode(data);else if(target.method===8&&'DecompressionStream' in window){const ds=new DecompressionStream('deflate-raw');xml=new TextDecoder().decode(await new Response(new Blob([data]).stream().pipeThrough(ds)).arrayBuffer());}else throw new Error('DOCX compressé : décompression hors ligne non disponible sur cet appareil.');
 const doc=new DOMParser().parseFromString(xml,'application/xml');return Array.from(doc.getElementsByTagName('w:p')).map(p=>Array.from(p.getElementsByTagName('w:t')).map(t=>t.textContent).join('')).filter(Boolean).join('\n');
}
async function readPdfSujet(file){
 const bytes=new Uint8Array(await file.arrayBuffer()); let raw=''; for(let i=0;i<bytes.length;i++)raw+=String.fromCharCode(bytes[i]);
 const out=[]; const tj=/\((?:\\.|[^\\)])*\)\s*Tj/g; let m; while((m=tj.exec(raw)))out.push(pdfDecodeString(m[0].replace(/\s*Tj$/,'')));
 const tjArr=/\[((?:.|\n)*?)\]\s*TJ/g; while((m=tjArr.exec(raw))){const parts=m[1].match(/\((?:\\.|[^\\)])*\)/g)||[];out.push(parts.map(x=>pdfDecodeString(x)).join(''));}
 const text=out.join('\n').replace(/\u0000/g,'').replace(/ +/g,' ').trim();
 if(!text)throw new Error('PDF sans texte lisible. Un PDF scanné (image) nécessite une OCR.'); return text;
}
function pdfDecodeString(x){x=x.replace(/^\(|\)$/g,'');return x.replace(/\\([\\()])/g,'$1').replace(/\\n/g,'\n').replace(/\\r/g,'').replace(/\\t/g,'\t').replace(/\\([0-7]{1,3})/g,(m,o)=>String.fromCharCode(parseInt(o,8)));}
function detectSujetParts(raw){
 let lines=raw.replace(/\r/g,'').split('\n').map(x=>x.replace(/[\t ]+/g,' ').trim()).filter(Boolean);
 lines=lines.filter(x=>!/^page\s*\d+$/i.test(x));
 const typeText=lines.join(' ').toLowerCase();let typeTexte='Narratif';if(/administratif|lettre|demande|courrier|autorisation/.test(typeText))typeTexte='Administratif';else if(/argumentatif|argument|opinion|convaincre|pour ou contre/.test(typeText))typeTexte='Argumentatif';else if(/explicatif|expliquer|documentaire|pourquoi|comment fonctionne/.test(typeText))typeTexte='Explicatif';
 const qRe=/^(?:question\s*)?\d{1,2}[.)-]\s+|^(?:q\d+|question\s*\d+)\s*[:.)-]\s*/i;let qi=lines.findIndex(x=>qRe.test(x));if(qi<0)qi=lines.findIndex(x=>/[?？]$/.test(x));
 let title=(lines.find(x=>! /^(sujet|texte|questions?|questionnaire|français|francais|type de texte)\s*[:\-]?$/i.test(x))||lines[0]||'Sujet importé');let textLines=qi>0?lines.slice(1,qi):lines.slice(1);let qs=[];
 if(qi>=0){const qLines=lines.slice(qi);let current='';for(const l of qLines){if(qRe.test(l)){if(current)qs.push({question:current.replace(qRe,'').trim(),correction:''});current=l;}else if(/[?？]$/.test(l)&&current){current+=' '+l;qs.push({question:current.replace(qRe,'').trim(),correction:''});current='';}else if(current)current+=' '+l;}if(current)qs.push({question:current.replace(qRe,'').trim(),correction:''});}
 textLines=textLines.filter(x=>x!==title&&!qRe.test(x));return {titre:title,typeTexte,texte:textLines.join('\n\n'),questions:qs,consigne:''};
}
function saveSujetEditor(){
 if(!editorConfirm('Enregistrer ce sujet type ?'))return;
 const id=$('#edSujId').value,title=$('#edSTitre').value.trim();if(!title){setEditorStatus('Le titre du sujet est obligatoire.',false);return;}
 const typeTexte=$('#edSType').value||'Narratif';
 const d=normalizeSujetRecord({id:id==='__new'?(slugify(title)||('sujet_'+Date.now())):id,titre:title,typeTexte:typeTexte,cat:typeTexte,texte:$('#edSTexte').value.trim(),questions:collectSujetQuestions(),consigne:$('#edSConsigne').value.trim(),aide:$('#edSAide').value.trim()},SUJETS.length);
 if(id==='__new'){const base=d.id;let n=2;while(SUJETS.some(x=>x.id===d.id))d.id=base+'_'+n++;SUJETS.push(d);}else{const i=SUJETS.findIndex(x=>x.id===id);if(i>=0)SUJETS[i]=d;}
 if(saveSujets()){setEditorStatus('✓ Sujet type enregistré.',true);setTimeout(()=>{closeEditor();viewAutres();},350);}
}
function deleteSujetEditor(){const id=$('#edSujId').value;if(id==='__new')return;if(!editorConfirm('Supprimer ce sujet type ?'))return;SUJETS=SUJETS.filter(x=>x.id!==id);saveSujets();renderEditorSujet($('#editorForm'));}
/* ============================================================
   AUTRES — sujets types + détente
   ============================================================ */
function viewAutres(){S.view='autres';setPageMode();nav('autres');$('#app').innerHTML=`<div class="view"><button class="back" onclick="goBack()">← Retour</button><div class="d-hdr"><h2>Autres</h2><p>Ressources complémentaires et jeux hors ligne.</p></div><div class="autres-grid"><div class="autres-card" id="openSujets"><div class="a-ico">📝</div><h3>Sujets types</h3><p>Consignes de production prêtes à utiliser.</p></div><div class="autres-card" id="openDetente"><div class="a-ico">🎮</div><h3>Détente</h3><p>Petits jeux pour faire une pause.</p></div></div><div id="autresContent"></div></div>`;$('#openSujets').onclick=renderSujets;$('#openDetente').onclick=renderDetente;renderSujets();}
function viewThemesEtudies(){
 S.view='themes-etudies'; S.hist=[{v:'themes-etudies'}]; setPageMode(); nav('autres');
 const periods=Object.values(P);
 $('#autresContent') && ($('#autresContent').innerHTML='');
 $('#app').innerHTML=`<div class="view"><button class="back" id="themesBack">← Autres</button><div class="d-hdr"><h2>📚 Thèmes étudiés</h2><p>Les vrais thèmes du programme de Français 3ème.</p></div>${periods.map(p=>`<div class="autres-section"><h3>${esc(p.titre)}</h3>${p.themes.map(t=>`<div class="sujet-card theme-real-card" data-pid="${esc(p.id)}" data-tid="${esc(t.id)}"><span class="sujet-cat">${esc((t.type||'').split(':')[0]||'Français')}</span><h4>${esc(t.titre)}</h4><p>${esc(t.desc||'')}</p></div>`).join('')}</div>`).join('')}<div class="sujets-link-card" id="backToSujets"><div><h3>📝 Sujets types</h3><p>Revenir aux sujets types.</p></div><span class="sujets-link-arrow">→</span></div><div class="safe-bottom"></div></div>`;
 $('#themesBack').onclick=renderSujets; $('#backToSujets').onclick=renderSujets;
 $$('.theme-real-card').forEach(el=>el.onclick=()=>goTheme(el.dataset.pid,el.dataset.tid));
}
function renderSujets(){
 nav('autres');
 const types=['Tous','Explicatif','Narratif','Argumentatif','Administratif'];
 $('#autresContent').innerHTML=`<div class="autres-section"><h3>📝 Sujets types</h3><p style="font-size:.68rem;color:var(--text2);line-height:1.5">Chaque catégorie contient des sujets enregistrés. Les sujets peuvent être copiés directement ou préparés pour impression / PDF.</p><div class="sujet-type-filters">${types.map((t,i)=>`<button class="sujet-type-filter ${i===0?'active':''}" data-type="${t}">${t}</button>`).join('')}</div><div id="sujetsList"></div><div class="sujets-link-card themes-link-card" id="themesEtudiesLink"><div><h3>📚 Thèmes étudiés</h3><p>Retourner aux périodes et aux thèmes du programme.</p></div><span class="sujets-link-arrow">→</span></div></div>`;
 $('#themesEtudiesLink').onclick=viewThemesEtudies;
 const paint=(type='Tous')=>{$('#sujetsList').innerHTML=SUJETS.map(normalizeSujetRecord).filter(x=>type==='Tous'||x.typeTexte.toLowerCase()===type.toLowerCase()).map((x,i)=>`<div class="sujet-card"><span class="sujet-cat">${esc(x.typeTexte||'Autre')}</span><h4>${esc(x.titre)}</h4>${x.texte?`<div class="sujet-support"><strong>📄 Texte</strong><p>${esc(x.texte)}</p></div>`:''}${(x.questions||[]).length?`<div class="sujet-questions"><strong>❓ Questions</strong>${x.questions.map((q,n)=>`<div class="sujet-question"><b>${n+1}.</b> ${esc(q.question)}<div class="sujet-detail"><b>Correction :</b> ${esc(q.correction||'À compléter.')}</div></div>`).join('')}</div>`:''}<p><strong>Consigne :</strong> ${esc(x.consigne||'')}</p><div class="sujet-detail"><b>💡 Aide :</b> ${esc(x.aide||'Aucune aide supplémentaire.')}</div><div class="sujet-actions"><button class="pdf-btn" data-pdf="${esc(x.id)}">📄 Imprimer / PDF</button><button class="pdf-btn" data-copy="${esc(x.id)}">📋 Copier</button></div></div>`).join('')||'<p style="font-size:.7rem;color:var(--text2)">Aucun sujet dans cette catégorie.</p>';
   $$('.pdf-btn').forEach(b=>b.onclick=e=>{e.stopPropagation();if(b.dataset.pdf)exportSujetPDF(b.dataset.pdf);else copySujet(b.dataset.copy);});
 };
 $$('.sujet-type-filter').forEach(b=>b.onclick=()=>{$$('.sujet-type-filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');paint(b.dataset.type);}); paint();
}
function sujetToText(x){let t=`FRANÇAIS COLLÈGE 3ème\n\nTYPE DE TEXTE : ${x.typeTexte||'Autre'}\nTITRE : ${x.titre||''}\n\nTEXTE\n${x.texte||''}\n\nQUESTIONS\n`; (x.questions||[]).forEach((q,i)=>{t+=`${i+1}. ${q.question}\nCorrection : ${q.correction||''}\n\n`;}); t+=`CONSIGNE\n${x.consigne||''}\n\nAIDE / CRITÈRES\n${x.aide||''}`;return t;}
function copySujet(id){if(!id||id==='__new'){alert('Enregistrez d’abord le sujet avant de le copier.');return;}const x=SUJETS.find(s=>s.id===id);if(!x)return;const t=sujetToText(x);copyToClipboard(t);toast?.('✓ Sujet copié');}
function buildSujetPrintHTML(x){return `<h1>FRANÇAIS COLLÈGE 3ème</h1><p><b>Type de texte :</b> ${esc(x.typeTexte||'Autre')}</p><h2>${esc(x.titre)}</h2>${x.texte?`<h2>Texte</h2><p>${esc(x.texte)}</p>`:''}${(x.questions||[]).length?`<h2>Questions</h2>${x.questions.map((q,n)=>`<div class="q"><b>${n+1}. ${esc(q.question)}</b>${q.correction?`<div class="corr">Correction : ${esc(q.correction)}</div>`:''}</div>`).join('')}`:''}${x.consigne?`<h2>Consigne / Travail de rédaction</h2><p>${esc(x.consigne)}</p>`:''}${x.redaction?`<h2>Travail de rédaction</h2><p>${esc(x.redaction)}</p>`:''}${x.aide?`<h2>Aide / critères</h2><p>${esc(x.aide)}</p>`:''}`;}
function closeSujetPrintPreview(){const o=document.getElementById('printPreviewOverlay');if(o)o.remove();}
function previewSujetPDF(id){
 if(!id||id==='__new'){alert('Enregistrez d’abord le sujet avant de l’imprimer.');return;} const x=SUJETS.find(s=>s.id===id);if(!x)return;
 closeSujetPrintPreview();
 const o=document.createElement('div');o.id='printPreviewOverlay';o.innerHTML=`<div class="print-preview-wrap"><div class="print-preview-toolbar"><strong style="font-size:.78rem">🖨️ Aperçu avant impression</strong><label>Haut <input id="pmTop" type="number" min="5" max="40" value="18"> mm</label><label>Droite <input id="pmRight" type="number" min="5" max="40" value="18"> mm</label><label>Bas <input id="pmBottom" type="number" min="5" max="40" value="18"> mm</label><label>Gauche <input id="pmLeft" type="number" min="5" max="40" value="18"> mm</label><button class="btn btn-p" id="pmPrint">🖨️ Imprimer</button><button class="btn btn-s print-preview-close" id="pmClose">✕ Fermer</button></div><div class="print-preview-page" id="printPreviewPage">${buildSujetPrintHTML(x)}</div></div>`;
 document.body.appendChild(o);o.style.display='block';
 const page=o.querySelector('#printPreviewPage');
 const apply=()=>{page.style.setProperty('--pm-top',(o.querySelector('#pmTop').value||18)+'mm');page.style.setProperty('--pm-right',(o.querySelector('#pmRight').value||18)+'mm');page.style.setProperty('--pm-bottom',(o.querySelector('#pmBottom').value||18)+'mm');page.style.setProperty('--pm-left',(o.querySelector('#pmLeft').value||18)+'mm');};
 o.querySelectorAll('input').forEach(i=>i.oninput=apply);apply();
 o.querySelector('#pmClose').onclick=closeSujetPrintPreview;
 o.querySelector('#pmPrint').onclick=()=>{const area=document.getElementById('pdfPrintArea')||document.createElement('div');area.id='pdfPrintArea';area.innerHTML=buildSujetPrintHTML(x);area.style.setProperty('--print-margin-top',(o.querySelector('#pmTop').value||18)+'mm');area.style.setProperty('--print-margin-right',(o.querySelector('#pmRight').value||18)+'mm');area.style.setProperty('--print-margin-bottom',(o.querySelector('#pmBottom').value||18)+'mm');area.style.setProperty('--print-margin-left',(o.querySelector('#pmLeft').value||18)+'mm');if(!area.parentNode)document.body.appendChild(area);const old=document.title;document.title='Sujet - '+x.titre;window.print();document.title=old;};
}
function exportSujetPDF(id){previewSujetPDF(id);}
function renderDetente(){nav('autres');$('#autresContent').innerHTML=`<div class="autres-section"><h3>🎮 Détente — jeux hors ligne</h3><div class="game-grid"><button class="game-btn" id="gameEmoji"><span class="game-ico">🧩</span>Puzzle emoji<small>Devinez le mot</small></button><button class="game-btn" id="gameMemory"><span class="game-ico">🧠</span>Mémoire<small>Trouvez les paires</small></button><button class="game-btn" id="gameAnagram"><span class="game-ico">🔤</span>Anagramme<small>Remettez le mot</small></button><button class="game-btn" id="gameQuick"><span class="game-ico">⚡</span>Défi rapide<small>Question surprise</small></button></div><div class="game-panel" id="gamePanel"><div class="game-title">Choisissez un jeu</div><p style="font-size:.7rem;color:var(--text2)">Tout fonctionne sans Internet.</p></div></div>`;$('#gameEmoji').onclick=gameEmoji;$('#gameMemory').onclick=gameMemory;$('#gameAnagram').onclick=gameAnagram;$('#gameQuick').onclick=gameQuick;}
const EMOJI_GAMES=[['🍎🍌','FRUITS'],['📚✏️','ECOLE'],['⚽🏆','SPORT'],['🐟🌊','MER'],['🚲🛣️','VOYAGE'],['🌧️☀️','METEO']];
function gameEmoji(){const x=EMOJI_GAMES[Math.floor(Math.random()*EMOJI_GAMES.length)];$('#gamePanel').innerHTML=`<div class="game-title">🧩 Quel mot est représenté ?</div><div class="emoji-puzzle">${x[0]}</div><input class="game-input" id="gInput" placeholder="Votre réponse"><button class="btn btn-p" id="gCheck">Vérifier</button><div class="game-msg" id="gMsg"></div>`;$('#gCheck').onclick=()=>{const ok=$('#gInput').value.trim().toUpperCase()===x[1];$('#gMsg').innerHTML=(ok?'✅ Bravo !':'❌ Essayez encore.')+' <button class="btn btn-s" id="gAgain" style="margin-left:6px;padding:5px 10px;font-size:.62rem">↻ Rejouer</button>';$('#gAgain').onclick=gameEmoji;};}
function gameMemory(){
  const EMO=['🍎','🐱','🚗','⭐','🌙','🎈','🍕','🐬'];
  const PAIRS=6;
  const vals=shuffleItems(EMO).slice(0,PAIRS),cards=shuffleItems(vals.concat(vals));
  $('#gamePanel').innerHTML=`<div class="game-title">🧠 Trouvez les ${PAIRS} paires</div><p style="font-size:.66rem;color:var(--text2);margin-bottom:6px">Coups joués : <b id="memMoves">0</b></p><div id="memoryGrid" style="display:grid;grid-template-columns:repeat(4,1fr);gap:7px">${cards.map((_,i)=>`<button class="game-btn mem" data-i="${i}" style="font-size:1.35rem;min-height:55px">❓</button>`).join('')}</div><div class="game-msg" id="memMsg"></div>`;
  let open=[],done=0,lock=false,moves=0;
  $$('.mem').forEach((b,i)=>b.onclick=()=>{
    if(lock||b.dataset.done==='1'||open.some(x=>x.i===i))return;
    b.textContent=cards[i];open.push({i,v:cards[i]});
    if(open.length===2){
      moves++;$('#memMoves').textContent=moves;lock=true;
      setTimeout(()=>{
        if(open[0].v===open[1].v){open.forEach(x=>{$$('.mem')[x.i].dataset.done='1';$$('.mem')[x.i].style.opacity='.5'});done++;}
        else open.forEach(x=>$$('.mem')[x.i].textContent='❓');
        open=[];lock=false;
        if(done===PAIRS)$('#memMsg').innerHTML=`🏆 Toutes les paires trouvées en ${moves} coups !<br><button class="btn btn-p" id="memAgain" style="margin-top:6px">↻ Rejouer</button>`,document.getElementById('memAgain').onclick=gameMemory;
      },450);
    }
  });
}
function gameAnagram(){const words=['ARTISANAT','MADAGASCAR','FRANCAIS','LECTURE','ECRITURE','ARGUMENT','VOCABULAIRE','GRAMMAIRE'];const word=words[Math.floor(Math.random()*words.length)],mix=shuffleItems(word.split('')).join('');$('#gamePanel').innerHTML=`<div class="game-title">🔤 Remettez les lettres dans l'ordre</div><div class="emoji-puzzle" style="font-size:1.3rem">${mix}</div><input class="game-input" id="gInput" placeholder="Mot trouvé"><button class="btn btn-p" id="gCheck">Vérifier</button><div class="game-msg" id="gMsg"></div>`;$('#gCheck').onclick=()=>{const ok=$('#gInput').value.trim().toUpperCase()===word;$('#gMsg').innerHTML=(ok?'✅ Exact !':'❌ Pas encore.')+' <button class="btn btn-s" id="gAgain" style="margin-left:6px;padding:5px 10px;font-size:.62rem">↻ Rejouer</button>';$('#gAgain').onclick=gameAnagram;};}
function gameQuick(){const bank=[['Quel est le contraire de « difficile » ?','FACILE'],['Combien de lettres dans « français » ?','8'],['Quel est le pluriel de « cheval » ?','CHEVAUX'],['Quel est le verbe dans « Vous lisez » ?','LISEZ'],['Synonyme de « content » ?','HEUREUX'],['Contraire de « rapide » ?','LENT']];const q=bank[Math.floor(Math.random()*bank.length)];$('#gamePanel').innerHTML=`<div class="game-title">⚡ Défi rapide</div><p style="font-size:.78rem;font-weight:800">${q[0]}</p><input class="game-input" id="gInput" placeholder="Réponse"><button class="btn btn-p" id="gCheck">Vérifier</button><div class="game-msg" id="gMsg"></div>`;$('#gCheck').onclick=()=>{const ok=$('#gInput').value.trim().toUpperCase()===q[1];$('#gMsg').innerHTML=(ok?'✅ Bonne réponse !':'❌ À revoir.')+' <button class="btn btn-s" id="gAgain" style="margin-left:6px;padding:5px 10px;font-size:.62rem">↻ Rejouer</button>';$('#gAgain').onclick=gameQuick;};}
function refreshCurrentView(){
  const v=S.view;
  if(v==='home')viewHome();
  else if(v==='langs')viewLecons();
  else if(v==='exos')viewExos();
  else if(v==='autres')viewAutres();
  else if(v==='period')goPeriod(S.hist[S.hist.length-1]?.id||Object.keys(P)[0]);
  else if(v==='theme'){const h=S.hist[S.hist.length-1];h?goTheme(h.pid,h.tid):viewLecons();}
  else if(v==='semaine'){const h=S.hist[S.hist.length-1];h?goSemaine(h.pid,h.tid,h.si):viewLecons();}
  else if(v==='semaine-lecon'){const h=S.hist[S.hist.length-1];h?goSemaineLecon(h.pid,h.tid,h.si):viewLecons();}
  else if(v==='semaine-exos-ouverts'){const h=S.hist[S.hist.length-1];h?goSemaineExosOuverts(h.pid,h.tid,h.si):viewLecons();}
  else viewHome();
}
/* ============================================================
   LEÇONS DE LANGUE
   ============================================================ */
const LANG = {
  grammaire:{titre:'Grammaire',ico:'G',c:'#4361ee',cb:'rgba(67,97,238,.1)',desc:'Leçons de langue',items:[]},
  conjugaison:{titre:'Conjugaison',ico:'C',c:'#d8a800',cb:'rgba(216,168,0,.1)',desc:'Leçons de langue',items:[]},
  orthographe:{titre:'Orthographe',ico:'O',c:'#2e7d62',cb:'rgba(46,125,98,.1)',desc:'Leçons de langue',items:[]},
  vocabulaire:{titre:'Vocabulaire',ico:'V',c:'#17324d',cb:'rgba(23,50,77,.1)',desc:'Leçons de langue',items:[]}
};
const LANG_WEEKS=[];
Object.values(P).forEach(p=>p.themes.forEach(t=>{
  (t.semaines||[]).forEach((s,si)=>LANG_WEEKS.push({
    titre:s.titre,code:s.code,desc:s.desc,thematique:t.titre,type:p.titre,
    periodId:p.id,themeId:t.id,si
  }));
}));
LANG_WEEKS.forEach(it=>{
  const text=(it.titre+' '+it.desc).toLowerCase();
  let cat='grammaire';
  if(/verbe|temps|conjug|participe|présent|passé|imparfait|futur|conditionnel|subjonctif|impératif/.test(text)) cat='conjugaison';
  else if(/accord|orthograph|écri|lettre|ponctuation/.test(text)) cat='orthographe';
  else if(/lexique|vocab|mot|synonyme|antonyme/.test(text)) cat='vocabulaire';
  LANG[cat].items.push({...it,cat});
});
/* ============================================================
   STATE
   ============================================================ */
const S = {
  view:'home',
  hist:[],
  visited:[],
  notifTab:'all',
  search:'',
  langCat:null,
  exercise:null,
  exoAnswered:false,
  texteAnswered:{},
  texteQs:[]
};
try{ const v=localStorage.getItem('vis'); if(v) S.visited=JSON.parse(v); }catch(e){}
/* Historique : revenir à une vue déjà présente TRONQUE la pile au lieu de la dupliquer
   (sinon le bouton « Retour » tournait en boucle sur la même page). */
function pushHist(e){
  const k=JSON.stringify(e), i=S.hist.findIndex(h=>JSON.stringify(h)===k);
  if(i>=0) S.hist.length=i+1; else S.hist.push(e);
}
try{ if(localStorage.getItem('dark')==='true'){ document.documentElement.setAttribute('data-theme','dark'); document.getElementById('themeBtn').textContent='☀️'; } }catch(e){}
/* ============================================================
   NOTIFICATIONS
   ============================================================ */
const NOTIFS = [
  {id:1,titre:'Nouvelle leçon disponible',msg:"Le chapitre sur l'Artisanat a été mis à jour.",t:'Il y a 5 min',unread:true,type:'lecon'},
  {id:2,titre:'Exercice recommandé',msg:'Pratiquez la corruption (argumentatif).',t:'Il y a 1 heure',unread:true,type:'exercice'},
  {id:3,titre:'Félicitations !',msg:'Vous avez complété 80% du programme explicatif.',t:'Il y a 3 heures',unread:true,type:'lecon'},
  {id:4,titre:'Rappel',msg:'Révisez les connecteurs spatiaux.',t:'Hier',unread:false,type:'lecon'}
];
try{ const rd=JSON.parse(localStorage.getItem('nread')||'[]'); NOTIFS.forEach(n=>{ if(rd.includes(n.id)) n.unread=false; }); }catch(e){}
/* ============================================================
   HELPERS
   ============================================================ */
const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const esc = s => String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function setHomeMode(){ document.body.classList.remove('page-mode'); document.body.classList.add('home-mode'); }
function setPageMode(){ document.body.classList.remove('home-mode'); document.body.classList.add('page-mode'); }
function isThemeVisited(pid,tid){return !!S.visited.find(v=>v.type==='theme'&&v.id===`${pid}-${tid}`);}
function saveVisit(type,id,titre,desc,go){
  if(S.visited.find(v=>v.id===id&&v.type===type)) return;
  S.visited.unshift({id,type,titre,desc,go:go||null,ts:Date.now(),new:true});
  if(S.visited.length>20) S.visited.length=20;
  try{ localStorage.setItem('vis',JSON.stringify(S.visited)); }catch(e){}
  updateBadge();
}
function timeAgo(ts){
  const m=Math.floor((Date.now()-ts)/60000);
  if(m<1) return "À l'instant";
  if(m<60) return `Il y a ${m} min`;
  const h=Math.floor(m/60);
  if(h<24) return `Il y a ${h} h`;
  return `Il y a ${Math.floor(h/24)} j`;
}
function updateBadge(){
  const unread = NOTIFS.filter(n=>n.unread).length + S.visited.filter(v=>v.new).length;
  const b = $('#badge');
  if(unread>0){ b.textContent = unread>9?'9+':unread; b.style.display='flex'; }
  else b.style.display='none';
}
function nav(active){
  $$('.n-btn').forEach(b=>b.classList.remove('on'));
  const b = document.querySelector(`[data-nav="${active}"]`);
  if(b) b.classList.add('on');
}
/* ============================================================
   VUE ACCUEIL
   ============================================================ */
function viewHome(){
  S.view='home'; S.hist=[]; setHomeMode();
  $('#app').innerHTML = `
    <div class="home-view">
      <div class="home-smoke" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
      <div class="home-hdr"><h2>Programme 3ème</h2><p>Choisissez une période d'apprentissage</p></div>
      <div class="grid">
        ${Object.values(P).map(p=>`
          <div class="p-card" data-p="${p.id}" style="--pc:${p.c};--pb:${p.cb}">
            <div class="p-week">${p.sem} semaines</div>
            <h3>${p.titre}</h3>
            <p>${p.desc}</p>
            <div class="p-foot">
              <span class="p-count">${p.themes.length} thème${p.themes.length>1?'s':''}</span>
              <span class="p-arrow">→</span>
            </div>
          </div>`).join('')}
      </div>
    </div>`;
  $$('.p-card').forEach(c=>c.onclick=()=>goPeriod(c.dataset.p));
  nav('home');
}
/* ============================================================
   VUE PÉRIODE
   ============================================================ */
function goPeriod(id){
  const p = P[id]; if(!p) return;
  S.view='period'; pushHist({v:'period',id}); setPageMode();
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← Accueil</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}">
        <h2>${p.titre}</h2><p>${p.desc}</p>
        <div class="d-meta">
          <span>${p.sem} semaines</span>
          <span>${p.themes.length} thème${p.themes.length>1?'s':''}</span>
          <span>Niveau 3ème</span>
        </div>
      </div>
      ${p.themes.map(t=>`
        <div class="t-item ${isThemeVisited(id,t.id)?'theme-seen theme-seen-pulse':''}" data-t="${t.id}" style="--tc:${p.c};--tb:${p.cb}">
          <h4>${t.titre}<i>→</i></h4><p>${t.desc}</p>
          <div class="tags">
            <span class="tag" style="background:${p.cb};color:${p.c}">${t.type.split(':')[0]}</span>
            <span class="tag" style="background:rgba(6,214,160,.1);color:var(--ok-t)">${t.semaines?t.semaines.length:0} semaines</span>
          </div>
        </div>`).join('')}
      <div class="sujets-link-card" id="periodSujetsLink"><div><h3>📝 Sujets types</h3><p>Retrouver les sujets d'exercices et de production liés aux types de textes.</p></div><span class="sujets-link-arrow">→</span></div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = viewHome;
  $('#periodSujetsLink').onclick = viewAutres;
  $$('.t-item').forEach(el=>el.onclick=()=>goTheme(id,el.dataset.t));
  nav('lecons');
  window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   VUE THÈME
   ============================================================ */
function goTheme(pid,tid){
  const p = P[pid], t = p.themes.find(x=>x.id===tid); if(!t) return;
  saveVisit('lecon',`${pid}-${tid}`,t.titre,`Thème : ${t.type}`,{v:'theme',pid,tid});
  S.view='theme'; pushHist({v:'theme',pid,tid}); setPageMode();
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${p.titre}</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}">
        <h2>${t.titre}</h2><p>${t.type}</p>
        <div class="d-meta"><span>${t.v}</span><span>${t.semaines?t.semaines.length:0} semaines</span></div>
      </div>
      <div class="theme-actions">
        <button class="btn btn-p" id="themeAllLessons">📖 Voir toutes les leçons</button>
        <button class="btn btn-s" id="themeAllExos">✎ Voir tous les exercices</button>
      </div>
      ${t.semaines ? `
        <div class="semaines-block" style="--tcc:${p.c};--tcc-d:${p.cd};--tcb:${p.cb};">
          <div class="semaines-titre"><i>S</i> Programme hebdomadaire (${t.semaines.length} semaines)</div>
          ${t.semaines.map((s,i)=>`
            <div class="semaine-item clickable" data-si="${i}" style="animation-delay:${i*0.04}s;--tcc:${p.c};--tcb:${p.cb};">
              <span class="semaine-code" style="background:linear-gradient(135deg,${p.c},${p.cd});">${s.code}</span>
              <div class="semaine-content">
                <h5>${esc(s.titre)}</h5>
                <p>${esc(s.desc)}</p>
                <span class="semaine-objectif">${esc(s.objectif)}</span>
              </div>
            </div>`).join('')}
        </div>
      ` : ''}
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = ()=>goPeriod(pid);
  $('#themeAllLessons').onclick=()=>goThemeLessons(pid,tid);
  $('#themeAllExos').onclick=()=>goThemeExos(pid,tid);
  $$('.semaine-item.clickable').forEach(el=>el.onclick=()=>goSemaine(pid,tid,parseInt(el.dataset.si)));
  nav('lecons');
  window.scrollTo({top:0,behavior:'smooth'});
}
function goThemeLessons(pid,tid){
  const p=P[pid],t=p.themes.find(x=>x.id===tid); if(!t)return;
  S.view='theme-lessons'; pushHist({v:'theme-lessons',pid,tid}); setPageMode();
  $('#app').innerHTML=`<div class="view theme-resource-view"><button class="back" id="bk">← ${esc(t.titre)}</button><div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}"><h2>Leçons — ${esc(t.titre)}</h2><p>Toutes les leçons du thème</p></div><div class="theme-resource-list">${(t.semaines||[]).map((s,i)=>`<button class="theme-resource-item" data-i="${i}"><span>${esc(s.code)}</span><b>${esc(s.titre)}</b><i>→</i></button>`).join('')}</div><div class="safe-bottom"></div></div>`;
  $('#bk').onclick=()=>goTheme(pid,tid); $$('.theme-resource-item').forEach(e=>e.onclick=()=>goSemaineLecon(pid,tid,+e.dataset.i)); nav('lecons'); window.scrollTo({top:0,behavior:'smooth'});
}
function goThemeExos(pid,tid){
  const p=P[pid],t=p.themes.find(x=>x.id===tid); if(!t)return;
  S.view='theme-exos'; pushHist({v:'theme-exos',pid,tid}); setPageMode();
  /* Chaque semaine doit disposer d'exercices directement liés à sa leçon.
     On ne fabrique rien lorsque les exercices existent déjà ; un secours très léger
     est ajouté uniquement si une semaine est réellement vide. */
  (t.semaines||[]).forEach(s=>{
    s.exosOuverts=s.exosOuverts||[];
    if(!s.exosOuverts.length && !(s.exos&&s.exos.length)){
      const focus=(s.lecon?.ms||s.lecon?.lex?.[0]?.mot||s.titre||'la leçon').trim();
      s.exosOuverts.push({
        titre:'Exercice de consolidation', type:'question', tag:'EXERCICE',
        consigne:`Réutilisez la notion étudiée dans la leçon « ${focus} » et rédigez une réponse complète.`,
        questions:[{q:`À partir de la leçon « ${focus} », rédigez une phrase correcte qui montre que vous maîtrisez la notion étudiée.`,corrige:'Réponse personnelle correcte et cohérente avec la notion étudiée.'}],
        corrige:['Réponse personnelle correcte et cohérente avec la notion étudiée.']
      });
    }
  });
  const items=[];(t.semaines||[]).forEach((s,si)=>{
    (s.exosOuverts||[]).forEach((e,ei)=>items.push({s,si,e,ei}));
  });
  $('#app').innerHTML=`<div class="view theme-resource-view"><button class="back" id="bk">← ${esc(t.titre)}</button><div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}"><h2>Exercices — ${esc(t.titre)}</h2><p>Consignes de tous les exercices du thème</p><div class="d-meta"><span>${items.length} exercices</span></div></div>${items.length?`<div class="theme-resource-list">${items.map((x,i)=>`<button class="theme-resource-item theme-exo-direct" data-i="${i}"><b>${esc(x.e.titre||'Exercice')}</b><small>${esc(x.e.consigne||'Consigne : réalisez l’exercice avec soin.')}</small><i>→</i></button>`).join('')}</div>`:`<div class="empty"><span class="em">✎</span><p>Aucun exercice disponible pour ce thème.</p></div>`}<div class="safe-bottom"></div></div>`;
  $('#bk').onclick=()=>goTheme(pid,tid); $$('.theme-resource-item').forEach(e=>e.onclick=()=>{const x=items[+e.dataset.i];goSemaineExosOuverts(pid,tid,x.si)}); nav('exos'); window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   VUE SEMAINE
   ============================================================ */
function goSemaine(pid,tid,si){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  const s = t.semaines[si];
  S.view='semaine'; pushHist({v:'semaine',pid,tid,si}); setPageMode();
  const hasOuverts = s.exosOuverts && s.exosOuverts.length > 0;
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${t.titre}</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}">
        <h2>${s.code} — ${esc(s.titre)}</h2>
        <p>${esc(s.desc)}</p>
        <div class="d-meta"><span>${esc(s.objectif)}</span><span>${hasOuverts ? s.exosOuverts.length+' exercices' : (s.exos?s.exos.length:0)+' QCM'}</span></div>
      </div>
      <p style="font-size:.78rem;color:var(--text2);font-weight:600;margin-bottom:12px">Choisissez une ressource pour cette semaine :</p>
      <div class="semaine-menu">
        <div class="semaine-menu-card" id="smLecon" style="--smc:${p.c};--smb:${p.cb};">
          <div class="smc-ico">L</div><h4>Leçon</h4><p>Lexique & morphosyntaxe</p>
        </div>
        <div class="semaine-menu-card" id="smExos" style="--smc:#f72585;--smb:rgba(247,37,133,.1);">
          <div class="smc-ico">E</div><h4>${hasOuverts?'Exercices':'Exercices'}</h4><p>${hasOuverts?'Exercices variés':'QCM interactifs'}</p>
          <span class="count">${hasOuverts ? s.exosOuverts.length+' exercices' : (s.exos?s.exos.length:0)+' QCM'}</span>
        </div>
      </div>
      <div class="sec">
        <h3><i style="--sb:${p.cb};--sc:${p.c};">${s.code}</i> Objectif de la semaine</h3>
        <div class="lesson"><p>${esc(s.objectif)}</p></div>
      </div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = ()=>goTheme(pid,tid);
  $('#smLecon').onclick = ()=>goSemaineLecon(pid,tid,si);
  $('#smExos').onclick = ()=>{
    if(hasOuverts) goSemaineExosOuverts(pid,tid,si);
    else goSemaineExo(pid,tid,si);
  };
  nav('lecons');
  window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   VUE LEÇON DE SEMAINE
   ============================================================ */
function goSemaineLecon(pid,tid,si){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  const s = t.semaines[si], L = s.lecon;
  S.view='semaine-lecon'; pushHist({v:'semaine-lecon',pid,tid,si}); setPageMode();
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${s.code}</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}">
        <h2>${s.code} — Leçon</h2>
        <p>${esc(s.titre)}</p>
        <div class="d-meta"><span>${esc(s.objectif)}</span></div>
      </div>
      ${(si===0||si===1) ? '' : `
      <div class="sec"><h3><i>I</i> Introduction</h3><div class="lesson"><p>${esc(L.intro)}</p></div></div>`}
      ${(si===0||si===1) && t.texte && Array.isArray(t.texte.contenu) && t.texte.contenu.length ? `
      <div class="sec">
        <h3><i>T</i> ${esc(t.texte.titre||'Texte de base')}</h3>
        <div class="texte-block" style="--tcc:${p.c};--tcb:${p.cb}">
          <div class="texte-titre"><i>T</i> ${esc(t.texte.titre||'Texte de base')}</div>
          <div class="texte-content">${t.texte.contenu.map((par,idx)=>`<p><span class="s-tag" style="background:${p.c}">§</span>${esc(par)}</p>`).join('')}</div>
        </div>
      </div>
      ${Array.isArray(t.questions) && t.questions.length ? `
      <div class="q-block open-text-questions" id="lessonTextQuestions" style="--sb:${p.cb};--sc:${p.c}">
        <h3><i>Q</i> Questions de compréhension (${t.questions.length})</h3>
        ${t.questions.map((q,i)=>`
          <div class="q-item q-open-item" data-i="${i}">
            <div class="q-question"><span class="q-num">Q${i+1}.</span> ${esc(q.q||'')}</div>
            <textarea class="q-open-input" data-q="lesson-${i}" placeholder="Écrivez votre réponse complète…"></textarea>
            <button class="q-open-check" data-q="lesson-${i}">Correction</button>
            <div class="q-exp q-open-correction" id="lesson-exp-${i}"><strong>Réponse attendue :</strong> ${esc(q.corrige||q.e||'')}</div>
          </div>`).join('')}
      </div>` : ''}` : ''}
      <div class="sec"><h3><i style="--sb:rgba(247,37,133,.1);--sc:#f72585">P</i> Points clés</h3><ul>${L.points.map(pt=>`<li>${esc(pt)}</li>`).join('')}</ul></div>
      <div class="sec">
        <h3><i style="--sb:rgba(255,209,102,.15);--sc:#9a6400">M</i> ${esc(L.msTitre||'Leçon de morphosyntaxe')}</h3>
        <div class="lesson"><p>${esc(L.ms)}</p></div>
        <div class="lesson-links">
          ${L.voirGrammaire!==false?'<button class="lesson-link ms" id="goMS"><i>G</i> Voir la Grammaire</button>':''}
          <button class="lesson-link ms" id="goConj"><i>C</i> Voir la Conjugaison</button>
        </div>
      </div>
      <div class="sec">
        <h3><i>L</i> ${esc(L.lexTitre||'Leçon de lexique')}</h3>
        <ul>${L.lex.map(l=>`<li>${esc(l)}</li>`).join('')}</ul>
        <div class="lesson-links">
          <button class="lesson-link lex" id="goLex"><i>V</i> Voir le Vocabulaire</button>
        </div>
      </div>
      <div class="btn-g">
        <button class="btn btn-p" id="toExo">Passer aux exercices →</button>
        <button class="btn btn-s" id="bk2">Retour</button>
      </div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = $('#bk2').onclick = ()=>goSemaine(pid,tid,si);
  $('#toExo').onclick = ()=>{
    if(s.exosOuverts && s.exosOuverts.length) goSemaineExosOuverts(pid,tid,si);
    else goSemaineExo(pid,tid,si);
  };
  if($('#goMS')) $('#goMS').onclick = ()=>goSemaineExosOuverts(pid,tid,si);
  $('#goConj').onclick = ()=>goSemaineExosOuverts(pid,tid,si);
  $('#goLex').onclick = ()=>{ const lex=t.lexique[0]; const f=LANG.vocabulaire.items.find(x=>x.titre===lex); if(f) goLangItem('vocabulaire',f); else goLangCat('vocabulaire'); };
  $$('#lessonTextQuestions .q-open-check').forEach(btn=>btn.onclick=()=>{
    const key=btn.dataset.q, input=document.querySelector(`.q-open-input[data-q=\"${key}\"]`), exp=document.getElementById(`lesson-exp-${key.replace('lesson-','')}`);
    if(!input || !input.value.trim()){ if(input) input.focus(); return; }
    if(exp) exp.classList.add('on');
    btn.textContent='Correction affichée'; btn.classList.add('done');
  });
  nav('lecons');
  window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   EXERCICES OUVERTS
   ============================================================ */
function goSemaineExosOuverts(pid,tid,si){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  const s = t.semaines[si];
  S.view='semaine-exos-ouverts'; pushHist({v:'semaine-exos-ouverts',pid,tid,si}); setPageMode();
  renderExosOuverts(pid,tid,si);
}
function renderExosOuverts(pid,tid,si){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  const s = t.semaines[si];
  const exercices = s.exosOuverts || [];
  setPageMode();
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${s.code}</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}">
        <h2>${s.code} — Exercices</h2>
        <p>${esc(s.titre)}</p>
        <div class="d-meta"><span>${exercices.length} exercices</span><span>${esc(s.objectif)}</span></div>
      </div>
      <div class="lesson-links" style="margin-bottom:12px;padding:12px;background:var(--card);border-radius:var(--r);border:1px solid var(--border);display:flex;flex-wrap:wrap;gap:8px;">
        <button class="lesson-link ms" id="sxGoLecon"><i>📖</i> Revoir la leçon ${s.code}</button>
      </div>
      <div class="exos-ouverts">
        ${exercices.map((exo,i)=>renderExoOuvert(exo,i,p)).join('')}
      </div>
      <div class="btn-g">
        <button class="btn btn-s" id="bk2">← Retour à la semaine</button>
      </div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = $('#bk2').onclick = ()=>goSemaine(pid,tid,si);
  $('#sxGoLecon').onclick = ()=>goSemaineLecon(pid,tid,si);
  $$('.btn-correction-exo').forEach(btn=>{
    btn.onclick = ()=>{
      const id = btn.dataset.cible;
      const corr = document.getElementById(id);
      if(corr.classList.contains('on')){
        corr.classList.remove('on');
        btn.classList.remove('on');
        btn.innerHTML = '<span>👁️</span><span>Afficher la correction</span>';
      } else {
        corr.classList.add('on');
        btn.classList.add('on');
        btn.innerHTML = '<span>🙈</span><span>Masquer la correction</span>';
        setTimeout(()=>corr.scrollIntoView({behavior:'smooth',block:'start'}),100);
      }
    };
  });
  window.scrollTo({top:0,behavior:'smooth'});
}
function renderExoOuvert(exo,index,p){
  const num = index+1;
  const tagClass = exo.tag === 'LEXIQUE' ? 'tag-lex' : exo.tag === 'SYNTAXE' ? 'tag-syn' : exo.tag === 'EVAL' ? 'tag-eval' : '';
  const tagLabel = exo.tag || 'EXERCICE';
  let corps = '';
  let completionOrder = null;
  let completionCorrByPhrase = null;
  if(exo.type === 'tableau'){
    corps = `
      <div class="exo-table-wrap"><table class="exo-tableau">
        <thead><tr>${exo.entetes.map(h=>`<th>${esc(h)}</th>`).join('')}</tr></thead>
        <tbody>
          ${exo.lignes.map(l=>`<tr>${l.map(cell=>`<td>${esc(cell)||'<span class="exo-rep-courte"></span>'}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table></div>`;
  } else if(exo.type === 'completion'){
    /* À TROUS : l'ordre des phrases est mélangé à chaque affichage.
       La correction suit exactement le même mélange grâce à l'association
       phrase → réponse. Une ancienne phrase n°7 peut donc devenir n°1,
       sans perdre sa bonne réponse. */
    completionOrder = shuffleItems(exo.phrases || []);
    const corr = Array.isArray(exo.corrige) ? exo.corrige : [];
    completionCorrByPhrase = new Map((exo.phrases || []).map((ph,i)=>[ph, corr[i]]));
    corps = `
      <ol class="exo-ol">
        ${completionOrder.map((ph,i)=>`<li data-original-index="${(exo.phrases || []).indexOf(ph)}">${esc(ph).replace(/___/g,'<span class="exo-rep-courte"></span>')}</li>`).join('')}
      </ol>`;
  } else if(exo.type === 'transformation'){
    corps = `
      <ol class="exo-ol">
        ${exo.phrases.map(ph=>`<li>${esc(ph)}<div class="exo-rep-ligne"></div></li>`).join('')}
      </ol>`;
  } else if(exo.type === 'production'){
    corps = exo.phrases ? `
      <ol class="exo-ol">
        ${exo.phrases.map(ph=>`<li>${esc(ph)}<div class="exo-rep-ligne"></div></li>`).join('')}
      </ol>` : `
      <p style="font-size:.78rem;color:var(--text2);font-style:italic;margin-bottom:8px">Rédigez votre réponse ci-dessous :</p>
      ${Array(exo.lignes||5).fill('<div class="exo-rep-ligne"></div>').join('')}`;
  } else if(exo.type === 'question' || exo.type === 'qcm-ouvert'){
    corps = `
      <ol class="exo-ol">
        ${(exo.questions||[]).map(q=>`
          <li><strong>${esc(q.q)}</strong><div class="exo-rep-ligne"></div></li>`).join('')}
      </ol>`;
  }
  const exId = `corr-exo-${index}`;
  return `
    <div class="exo-ouvert" style="--tcc:${p.c};--tcd:${p.cd};--tcb:${p.cb};animation-delay:${index*0.05}s">
      <div class="exo-ouvert-titre">
        <span class="exo-num">${num}</span>
        ${esc(exo.titre)}
        <span class="exo-tag ${tagClass}">${tagLabel}</span>
      </div>
      ${exo.consigne ? `<div class="exo-consigne"><strong>Consigne :</strong> ${esc(exo.consigne)}</div>` : ''}
      ${exo.exemple ? `<div class="exo-consigne" style="background:rgba(6,214,160,.06);border-left-color:var(--ok-t)"><strong>Exemple :</strong> ${esc(exo.exemple)}</div>` : ''}
      ${corps}
      ${exo.corrige ? `
        <button class="btn-correction-exo" data-cible="${exId}">
          <span>👁️</span><span>Afficher la correction</span>
        </button>
        <div class="exo-correction" id="${exId}">
          <h5>✅ Corrigé</h5>
          ${Array.isArray(exo.corrige)
            ? `<ol>${(exo.type==='completion'
                ? (completionOrder || exo.phrases || []).map(ph=>completionCorrByPhrase ? completionCorrByPhrase.get(ph) : '')
                : exo.corrige
              ).map(c=>`<li>${esc(c==null?'':c)}</li>`).join('')}</ol>`
            : `<p>${esc(exo.corrige)}</p>`}
        </div>
      ` : ''}
    </div>`;
}
/* ============================================================
   ANCIEN : QCM DE SEMAINE
   ============================================================ */
function goSemaineExo(pid,tid,si){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  S.exercise = {pid,tid,si,q:0,answers:[],order:shuffleOrder((t.semaines[si].exos||[]).length),mode:'semaine'}; S.exoAnswered = false;
  S.view='semaine-exo'; pushHist({v:'semaine-exo',pid,tid,si});
  renderSemaineExo(pid,tid,si);
  nav('exos');
}
function renderSemaineExo(pid,tid,si){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  const s = t.semaines[si], cur = S.exercise, q = shuffleQ(s.exos[cur.order[cur.q]]);
  const prog = (cur.q / s.exos.length) * 100;
  setPageMode();
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${s.code}</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}">
        <h2>${s.code} — Exercices</h2>
        <p>Question ${cur.q+1} sur ${s.exos.length}</p>
        <div class="prog"><i style="width:${prog}%"></i></div>
      </div>
      <div class="lesson-links" style="margin-bottom:12px;padding:12px;background:var(--card);border-radius:var(--r);border:1px solid var(--border);display:flex;flex-wrap:wrap;gap:8px;">
        <button class="lesson-link ms" id="sxGoLecon"><i>📖</i> Revoir la leçon ${s.code}</button>
        <button class="lesson-link ms" id="sxGoMS"><i>G</i> Grammaire</button>
        <button class="lesson-link lex" id="sxGoLex"><i>V</i> Vocabulaire</button>
      </div>
      <div class="q-card">
        <div class="q-num">Q${cur.q+1}</div>
        <div class="q-txt">${esc(q.q)}</div>
        <div class="opts" id="opts">
          ${q.o.map((o,i)=>`<div class="opt" data-i="${i}"><i>${String.fromCharCode(65+i)}</i><span>${esc(o)}</span></div>`).join('')}
        </div>
      </div>
      <div id="fb"></div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = ()=>goSemaine(pid,tid,si);
  $$('.opt').forEach(el=>el.onclick=()=>pickSemaineAnswer(parseInt(el.dataset.i),q,s,si));
  $('#sxGoLecon').onclick = ()=>goSemaineLecon(pid,tid,si);
  $('#sxGoMS').onclick = ()=>{ const ms=t.ms[0]; const f=LANG.grammaire.items.find(x=>x.titre===ms); if(f) goLangItem('grammaire',f); else goLangCat('grammaire'); };
  $('#sxGoLex').onclick = ()=>{ const lex=t.lexique[0]; const f=LANG.vocabulaire.items.find(x=>x.titre===lex); if(f) goLangItem('vocabulaire',f); else goLangCat('vocabulaire'); };
  window.scrollTo({top:0,behavior:'smooth'});
}
function pickSemaineAnswer(i,q,s,si){
  if(S.exoAnswered) return;
  S.exoAnswered = true;
  const ok = i===q.c;
  S.exercise.answers.push({q:q.q,i,c:q.c,ok,e:q.e,mine:q.o[i],right:q.o[q.c]});
  $$('.opt').forEach((el,idx)=>{
    el.classList.add('dis');
    if(idx===q.c) el.classList.add('ok');
    if(idx===i && !ok) el.classList.add('ko');
  });
  const isLast = S.exercise.q+1 >= s.exos.length;
  $('#fb').innerHTML = `
    <div class="sec" style="border-left:4px solid ${ok?'var(--ok-t)':'var(--ko-t)'}">
      <h3 style="color:${ok?'var(--ok-t)':'var(--ko-t)'};border-bottom-color:transparent">
        <i style="--sb:${ok?'rgba(6,214,160,.1)':'rgba(239,71,111,.1)'};--sc:${ok?'var(--ok-t)':'var(--ko-t)'}">${ok?'✓':'✗'}</i>
        ${ok?'Bonne réponse !':'Réponse incorrecte'}
      </h3>
      <div class="lesson"><p><strong>Explication :</strong> ${esc(q.e)}</p></div>
    </div>
    <div class="btn-g">
      ${!isLast ? `<button class="btn btn-p" id="next">Question suivante →</button>` : `<button class="btn btn-p" id="res">Voir mon résultat →</button>`}
      <button class="btn btn-s" id="quit">Quitter</button>
    </div>`;
  if(!isLast){
    $('#next').onclick = ()=>{ S.exercise.q++; S.exoAnswered=false; renderSemaineExo(S.exercise.pid,S.exercise.tid,S.exercise.si); };
  } else {
    $('#res').onclick = ()=>showSemaineResult(S.exercise.pid,S.exercise.tid,S.exercise.si);
  }
  $('#quit').onclick = ()=>goSemaine(S.exercise.pid,S.exercise.tid,S.exercise.si);
}
function showSemaineResult(pid,tid,si){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  const s = t.semaines[si];
  const ans = S.exercise.answers, total = s.exos.length;
  const correct = ans.filter(a=>a.ok).length;
  const pct = Math.round(correct/total*100);
  saveVisit('exercice',`sem-${pid}-${tid}-${si}-${Date.now()}`,`${s.code} : ${s.titre}`,`Score : ${correct}/${total} (${pct}%)`,{v:'semaine',pid,tid,si});
  setPageMode();
  let msg='',em='';
  if(pct>=80){msg='Excellent travail !';em='🏆';}
  else if(pct>=60){msg='Bien joué !';em='👏';}
  else if(pct>=40){msg='Peut mieux faire.';em='💪';}
  else {msg='Continuez à vous entraîner.';em='📚';}
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${s.code}</button>
      <div class="res"><h3>${em} ${msg}</h3><div class="sc">${correct}/${total}</div><p>Score : ${pct}%</p></div>
      <div class="sec">
        <h3><i>R</i> Récapitulatif ${s.code}</h3>
        ${ans.map((a,i)=>`
          <div style="padding:10px 0;border-bottom:1px solid var(--border2)">
            <p style="font-weight:700;font-size:.78rem;color:var(--text);margin-bottom:5px">${a.ok?'✓':'✗'} Q${i+1}. ${esc(a.q)}</p>
            <p style="font-size:.73rem;color:${a.ok?'var(--ok-t)':'var(--ko-t)'}">Votre réponse : ${esc(a.mine)}</p>
            ${!a.ok?`<p style="font-size:.73rem;color:var(--ok-t)">Bonne réponse : ${esc(a.right)}</p>`:''}
          </div>`).join('')}
      </div>
      <div class="btn-g">
        <button class="btn btn-p" id="retry">Recommencer</button>
        <button class="btn btn-s" id="bk2">Retour</button>
      </div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = $('#bk2').onclick = ()=>goSemaine(pid,tid,si);
  $('#retry').onclick = ()=>goSemaineExo(pid,tid,si);
  window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   VUE TEXTE + QUESTIONS
   ============================================================ */
function goTexte(pid,tid){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  S.view='texte'; pushHist({v:'texte',pid,tid}); S.texteAnswered = {}; S.texteQs = (t.questions||[]); setPageMode();
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${t.titre}</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}"><h2>Texte & Questions</h2><p>${t.titre} • ${t.type}</p></div>
      <div class="texte-block" style="--tcc:${p.c};--tcb:${p.cb}">
        <div class="texte-titre"><i>T</i> ${esc(t.texte.titre)}</div>
        <div class="texte-content">
          ${t.texte.contenu.map((par,idx)=>`<p><span class="s-tag" style="background:${p.c}">S${Math.min(idx+1, t.semaines ? t.semaines.length : 1)}</span>${esc(par)}</p>`).join('')}
        </div>
      </div>
      <div class="q-block open-text-questions" id="qblock" style="--sb:${p.cb};--sc:${p.c}">
        <h3><i>Q</i> Questions ouvertes (${S.texteQs.length})</h3>
        ${S.texteQs.map((q,i)=>`
          <div class="q-item q-open-item" data-i="${i}">
            <div class="q-question"><span class="q-num">Q${i+1}.</span> ${esc(q.q)}</div>
            <textarea class="q-open-input" data-q="${i}" placeholder="Écrivez votre réponse complète…"></textarea>
            <button class="q-open-check" data-q="${i}">Correction</button>
            <div class="q-exp q-open-correction" id="exp-${i}"><strong>Réponse attendue :</strong> ${esc(q.corrige||q.e||'')}</div>
          </div>`).join('')}
      </div>
      <div class="btn-g">
        <button class="btn btn-p" id="toLecon">Voir la leçon →</button>
        <button class="btn btn-s" id="bk2">Retour</button>
      </div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = $('#bk2').onclick = ()=>goTheme(pid,tid);
  $('#toLecon').onclick = ()=>goLecon(pid,tid);
  $$('.q-open-check').forEach(btn=>btn.onclick=()=>{
    const i=+btn.dataset.q, input=document.querySelector(`.q-open-input[data-q="${i}"]`), exp=document.getElementById(`exp-${i}`);
    if(!input.value.trim()){ input.focus(); return; }
    exp.classList.add('on'); btn.textContent='Correction affichée'; btn.classList.add('done');
  });
  nav('lecons');
  window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   VUE LEÇON GLOBALE
   ============================================================ */
function goLecon(pid,tid){
  const p = P[pid], t = p.themes.find(x=>x.id===tid), L = t.lecon;
  S.view='lecon'; pushHist({v:'lecon',pid,tid}); setPageMode();
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${t.titre}</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}"><h2>Leçon : ${t.titre}</h2><p>${t.type}</p></div>
      <div class="sec"><h3><i>I</i> Introduction</h3><div class="lesson"><p>${esc(L.intro)}</p></div></div>
      <div class="sec"><h3><i style="--sb:rgba(247,37,133,.1);--sc:#f72585">S</i> Structure</h3>
        <div class="lesson">${L.structure.map(s=>`<h4>${esc(s.t)}</h4><p>${esc(s.d)}</p>`).join('')}</div>
      </div>
      <div class="sec"><h3><i style="--sb:rgba(6,214,160,.1);--sc:var(--ok-t)">E</i> Exemple</h3>
        <div class="lesson"><div class="ex-box">${esc(L.ex)}</div></div>
      </div>
      <div class="sec"><h3><i style="--sb:rgba(255,209,102,.15);--sc:#9a6400">M</i> ${esc(L.msTitre||'Leçon de morphosyntaxe')}</h3>
        <div class="lesson"><p>${esc(L.ms)}</p></div>
        <div class="lesson-links">
          <button class="lesson-link ms" data-target="grammaire"><i>G</i> Voir la Grammaire</button>
          <button class="lesson-link ms" data-target="conjugaison"><i>C</i> Voir la Conjugaison</button>
        </div>
      </div>
      <div class="sec"><h3><i>L</i> ${esc(L.lexTitre||'Leçon de lexique')}</h3>
        <ul>${t.lexique.map(l=>`<li>${esc(l)}</li>`).join('')}</ul>
        <div class="lesson-links">
          <button class="lesson-link lex" data-target="vocabulaire"><i>V</i> Voir le Vocabulaire</button>
          <button class="lesson-link ms" data-target="orthographe"><i>O</i> Voir l'Orthographe</button>
        </div>
      </div>
      <div class="btn-g">
        <button class="btn btn-p" id="toExo">Passer aux exercices →</button>
        <button class="btn btn-s" id="bk2">Retour</button>
      </div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = $('#bk2').onclick = ()=>goTheme(pid,tid);
  $('#toExo').onclick = ()=>goExo(pid,tid);
  $$('.lesson-link').forEach(btn=>{
    btn.onclick = ()=>{
      const target = btn.dataset.target;
      if(target === 'vocabulaire'){
        const lex = t.lexique[0];
        const f = LANG.vocabulaire.items.find(x=>x.titre===lex);
        if(f) goLangItem('vocabulaire', f); else goLangCat('vocabulaire');
      } else if(target === 'grammaire' || target === 'conjugaison'){
        const idx = Math.max(0, (t.semaines||[]).findIndex(w=>w.lecon && w.lecon.ms));
        goSemaineExosOuverts(pid,tid,idx);
      } else {
        const ms = t.ms[0];
        const f = LANG[target].items.find(x=>x.titre===ms);
        if(f) goLangItem(target, f); else goLangCat(target);
      }
    };
  });
  nav('lecons');
  window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   EXERCICES GLOBAUX (QCM)
   ============================================================ */
function goExo(pid,tid){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  S.exercise = {pid,tid,q:0,answers:[],order:shuffleOrder(t.exos.length)}; S.exoAnswered=false;
  S.view='exo'; pushHist({v:'exo',pid,tid});
  renderExo(pid,tid);
  nav('exos');
}
function renderExo(pid,tid){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  const cur = S.exercise, q = shuffleQ(t.exos[cur.order[cur.q]]);
  const prog = (cur.q / t.exos.length) * 100;
  setPageMode();
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${t.titre}</button>
      <div class="d-hdr" style="--dc:${p.c};--dcd:${p.cd}">
        <h2>Exercices : ${t.titre}</h2><p>Question ${cur.q+1} sur ${t.exos.length}</p>
        <div class="prog"><i style="width:${prog}%"></i></div>
      </div>
      <div class="lesson-links" style="margin-bottom:12px;padding:12px;background:var(--card);border-radius:var(--r);border:1px solid var(--border);display:flex;flex-wrap:wrap;gap:8px;">
        <button class="lesson-link ms" id="exGoLecon"><i>📖</i> Revoir la leçon</button>
        <button class="lesson-link ms" id="exGoMS"><i>G</i> Grammaire</button>
        <button class="lesson-link ms" id="exGoConj"><i>C</i> Conjugaison</button>
        <button class="lesson-link lex" id="exGoLex"><i>V</i> Vocabulaire</button>
      </div>
      <div class="q-card">
        <div class="q-num">Q${cur.q+1}</div>
        <div class="q-txt">${esc(q.q)}</div>
        <div class="opts" id="opts">
          ${q.o.map((o,i)=>`<div class="opt" data-i="${i}"><i>${String.fromCharCode(65+i)}</i><span>${esc(o)}</span></div>`).join('')}
        </div>
      </div>
      <div id="fb"></div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = ()=>goTheme(pid,tid);
  $$('.opt').forEach(el=>el.onclick=()=>pickAnswer(parseInt(el.dataset.i),q,t));
  $('#exGoLecon').onclick = ()=>goLecon(pid,tid);
  $('#exGoMS').onclick = ()=>{ const ms=t.ms[0]; const f=LANG.grammaire.items.find(x=>x.titre===ms); if(f) goLangItem('grammaire',f); else goLangCat('grammaire'); };
  $('#exGoConj').onclick = ()=>{ const ms=t.ms[0]; const f=LANG.conjugaison.items.find(x=>x.titre===ms); if(f) goLangItem('conjugaison',f); else goLangCat('conjugaison'); };
  $('#exGoLex').onclick = ()=>{ const lex=t.lexique[0]; const f=LANG.vocabulaire.items.find(x=>x.titre===lex); if(f) goLangItem('vocabulaire',f); else goLangCat('vocabulaire'); };
  window.scrollTo({top:0,behavior:'smooth'});
}
function pickAnswer(i,q,t){
  if(S.exoAnswered) return;
  S.exoAnswered = true;
  const ok = i===q.c;
  S.exercise.answers.push({q:q.q,i,c:q.c,ok,e:q.e,mine:q.o[i],right:q.o[q.c]});
  $$('.opt').forEach((el,idx)=>{
    el.classList.add('dis');
    if(idx===q.c) el.classList.add('ok');
    if(idx===i && !ok) el.classList.add('ko');
  });
  const isLast = S.exercise.q+1 >= t.exos.length;
  $('#fb').innerHTML = `
    <div class="sec" style="border-left:4px solid ${ok?'var(--ok-t)':'var(--ko-t)'}">
      <h3 style="color:${ok?'var(--ok-t)':'var(--ko-t)'};border-bottom-color:transparent">
        <i style="--sb:${ok?'rgba(6,214,160,.1)':'rgba(239,71,111,.1)'};--sc:${ok?'var(--ok-t)':'var(--ko-t)'}">${ok?'✓':'✗'}</i>
        ${ok?'Bonne réponse !':'Réponse incorrecte'}
      </h3>
      <div class="lesson"><p><strong>Explication :</strong> ${esc(q.e)}</p></div>
    </div>
    <div class="btn-g">
      ${!isLast ? `<button class="btn btn-p" id="next">Question suivante →</button>` : `<button class="btn btn-p" id="res">Voir mon résultat →</button>`}
      <button class="btn btn-s" id="quit">Quitter</button>
    </div>`;
  if(!isLast){
    $('#next').onclick = ()=>{ S.exercise.q++; S.exoAnswered=false; renderExo(S.exercise.pid,S.exercise.tid); };
  } else {
    $('#res').onclick = ()=>showResult(S.exercise.pid,S.exercise.tid);
  }
  $('#quit').onclick = ()=>goTheme(S.exercise.pid,S.exercise.tid);
}
function showResult(pid,tid){
  const p = P[pid], t = p.themes.find(x=>x.id===tid);
  const ans = S.exercise.answers, total = t.exos.length;
  const correct = ans.filter(a=>a.ok).length;
  const pct = Math.round(correct/total*100);
  saveVisit('exercice',`ex-${pid}-${tid}-${Date.now()}`,`Exercice : ${t.titre}`,`Score : ${correct}/${total} (${pct}%)`,{v:'theme',pid,tid});
  setPageMode();
  let msg='',em='';
  if(pct>=80){msg='Excellent travail !';em='🏆';}
  else if(pct>=60){msg='Bien joué !';em='👏';}
  else if(pct>=40){msg='Peut mieux faire.';em='💪';}
  else {msg='Continuez à vous entraîner.';em='📚';}
  $('#app').innerHTML = `
    <div class="view">
      <button class="back" id="bk">← ${t.titre}</button>
      <div class="res"><h3>${em} ${msg}</h3><div class="sc">${correct}/${total}</div><p>Score : ${pct}%</p></div>
      <div class="sec">
        <h3><i>R</i> Récapitulatif</h3>
        ${ans.map((a,i)=>`
          <div style="padding:10px 0;border-bottom:1px solid var(--border2)">
            <p style="font-weight:700;font-size:.78rem;color:var(--text);margin-bottom:5px">${a.ok?'✓':'✗'} Q${i+1}. ${esc(a.q)}</p>
            <p style="font-size:.73rem;color:${a.ok?'var(--ok-t)':'var(--ko-t)'}">Votre réponse : ${esc(a.mine)}</p>
            ${!a.ok?`<p style="font-size:.73rem;color:var(--ok-t)">Bonne réponse : ${esc(a.right)}</p>`:''}
          </div>`).join('')}
      </div>
      <div class="btn-g">
        <button class="btn btn-p" id="retry">Recommencer</button>
        <button class="btn btn-s" id="bk2">Retour</button>
      </div>
      <div class="safe-bottom"></div>
    </div>`;
  $('#bk').onclick = $('#bk2').onclick = ()=>goTheme(pid,tid);
  $('#retry').onclick = ()=>goExo(pid,tid);
  window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   LEÇONS DE LANGUE (liste)
   ============================================================ */
function viewLecons(){
  S.view='langs'; S.hist=[{v:'langs'}]; setPageMode();
  const list=LANG_WEEKS;
  $('#app').innerHTML = `
    <div class="view">
      <h2 class="home-hdr" style="text-align:left;font-size:1.5rem">📖 Leçons de langue</h2>
      <p style="font-size:.78rem;color:var(--text2);margin-bottom:16px;font-weight:500">${list.length} leçons hebdomadaires</p>
      <div class="search-box">
        <span class="s-ico">🔍</span>
        <input type="search" id="searchInput" placeholder="Rechercher une leçon…" autocomplete="off">
        <button class="s-clear" id="searchClear">✕</button>
      </div>
      <div id="langList">
        ${list.map((it,i)=>`
          <div class="t-item" data-i="${i}" style="--tc:var(--primary);--tb:rgba(23,50,77,.08)">
            <h4>${esc(it.code)} — ${esc(it.titre)}<i>→</i></h4>
            <p>${esc(it.thematique)} • ${esc(it.type)}</p>
          </div>`).join('')}
      </div>
      <div id="searchResults"></div>
      <div class="safe-bottom"></div>
    </div>`;
  $$('.t-item').forEach(el=>el.onclick=()=>{const it=list[+el.dataset.i];goSemaineLecon(it.periodId,it.themeId,it.si);});
  const inp=$('#searchInput'); inp.oninput=e=>doSearch(e.target.value);
  $('#searchClear').onclick=()=>{inp.value='';doSearch('');inp.focus();};
  nav('lecons'); window.scrollTo({top:0,behavior:'smooth'});
}
function doSearch(q){
  q=q.trim().toLowerCase();
  const list=$('#langList'),res=$('#searchResults'),clear=$('#searchClear');
  if(!q){list.style.display='block';res.innerHTML='';clear.classList.remove('on');return;}
  clear.classList.add('on');list.style.display='none';
  const results=LANG_WEEKS.filter(it=>(it.titre+' '+it.desc+' '+it.thematique+' '+it.type+' '+it.code).toLowerCase().includes(q));
  if(!results.length){res.innerHTML=`<div class="empty"><span class="em">🔍</span><p>Aucun résultat pour « ${esc(q)} »</p></div>`;return;}
  res.innerHTML=`<p style="font-size:.75rem;color:var(--text3);font-weight:600;margin-bottom:10px">${results.length} résultat${results.length>1?'s':''}</p>`+results.map((r,i)=>`
    <div class="sr-item" data-i="${i}">
      <h5>${esc(r.code)} — ${esc(r.titre)}</h5>
      <p>${esc(r.thematique)} • ${esc(r.type)}</p>
    </div>`).join('');
  $$('.sr-item').forEach(el=>el.onclick=()=>{const r=results[+el.dataset.i];goSemaineLecon(r.periodId,r.themeId,r.si);});
}
function goLangCat(cat){
  const data=LANG[cat]; if(!data){viewLecons();return;}
  S.view='langs'; S.langCat=cat; setPageMode(); nav('lecons');
  const items=data.items||[];
  $('#app').innerHTML=`<div class="view"><button class="back" id="bkLang">← Leçons</button><div class="d-hdr" style="--dc:${data.c};--dcd:${data.c}"><h2>${esc(data.titre)}</h2><p>${esc(data.desc)}</p><div class="d-meta"><span>${items.length} notions</span></div></div><div class="lang-grid">${items.map((it,i)=>`<button class="lang-card" data-i="${i}"><span class="lang-ico">${esc(it.code||data.ico)}</span><span><b>${esc(it.code||'')}</b> ${esc(it.titre)}</span></button>`).join('')}</div><div class="safe-bottom"></div></div>`;
  $('#bkLang').onclick=viewLecons;
  $$('.lang-card').forEach(el=>el.onclick=()=>goLangItem(cat,items[+el.dataset.i]));
  window.scrollTo({top:0,behavior:'smooth'});
}
function goLangItem(cat,it){
  if(it&&it.periodId!=null&&it.themeId!=null&&it.si!=null) goSemaineLecon(it.periodId,it.themeId,it.si);
  else viewLecons();
}
/* ============================================================
   EXERCICES (liste globale)
   ============================================================ */
function viewExos(){
  S.view='exos'; S.hist=[{v:'exos'}]; setPageMode();
  const list=[];
  Object.values(P).forEach(p=>{
    (p.themes||[]).forEach(t=>{
      (t.semaines||[]).forEach((s,si)=>{
        (s.exos||[]).forEach((e,ei)=>{
          list.push({pid:p.id,tid:t.id,si,ei,code:s.code,titre:s.titre,q:e.q,c:p.c,cb:p.cb,type:'qcm'});
        });
        (s.exosOuverts||[]).forEach((e,ei)=>{
          list.push({pid:p.id,tid:t.id,si,ei,code:s.code,titre:s.titre,q:e.titre,c:p.c,cb:p.cb,type:'ouvert'});
        });
      });
    });
  });
  $('#app').innerHTML=`
    <div class="view">
      <h2 class="home-hdr" style="text-align:left;font-size:1.5rem">✏️ Exercices</h2>
      <p style="font-size:.78rem;color:var(--text2);margin-bottom:16px;font-weight:500">${list.length} exercices disponibles</p>
      <div class="search-box">
        <span class="s-ico">🔍</span>
        <input type="search" id="exoSearch" placeholder="Rechercher un exercice…" autocomplete="off">
        <button class="s-clear" id="exoClear">✕</button>
      </div>
      <div id="exoList">${list.map((x,i)=>`
        <div class="t-item exo-link" data-i="${i}" style="--tc:${x.c};--tb:${x.cb}">
          <h4>${esc(x.code)} — ${x.type==='ouvert'?'Exercice':'QCM'} ${x.ei+1}<i>→</i></h4>
          <p>${esc(x.q)}</p>
        </div>`).join('')}</div>
      <div class="safe-bottom"></div>
    </div>`;
  const bind=()=>$$('.exo-link').forEach(el=>el.onclick=()=>{
    const x=list[+el.dataset.i];
    if(x.type==='ouvert') goSemaineExosOuverts(x.pid,x.tid,x.si);
    else goSemaineExo(x.pid,x.tid,x.si);
  });
  bind();
  const render=q=>{
    q=q.trim().toLowerCase(); const box=$('#exoList');
    box.innerHTML=list.filter(x=>(x.q+' '+x.code+' exercice '+(x.ei+1)+' '+x.titre).toLowerCase().includes(q)).map((x)=>`
      <div class="t-item exo-link" data-i="${list.indexOf(x)}" style="--tc:${x.c};--tb:${x.cb}">
        <h4>${esc(x.code)} — ${x.type==='ouvert'?'Exercice':'QCM'} ${x.ei+1}<i>→</i></h4><p>${esc(x.q)}</p>
      </div>`).join('')||`<div class="empty"><span class="em">🔍</span><p>Aucun exercice trouvé</p></div>`;
    bind();
  };
  const inp=$('#exoSearch'); inp.oninput=e=>{ $('#exoClear').classList.toggle('on',!!e.target.value);render(e.target.value); };
  $('#exoClear').onclick=()=>{inp.value='';render('');$('#exoClear').classList.remove('on');inp.focus();};
  nav('exos'); window.scrollTo({top:0,behavior:'smooth'});
}
/* ============================================================
   NAVIGATION RETOUR
   ============================================================ */
function goBack(){
  if(S.hist.length<=1){ viewHome(); return; }
  S.hist.pop();
  const prev = S.hist[S.hist.length-1];
  if(!prev) { viewHome(); return; }
  if(prev.v==='langs') viewLecons();
  else if(prev.v==='exos') viewExos();
  else if(prev.v==='period') goPeriod(prev.id);
  else if(prev.v==='theme') goTheme(prev.pid,prev.tid);
  else if(prev.v==='texte') goTexte(prev.pid,prev.tid);
  else if(prev.v==='lecon') goLecon(prev.pid,prev.tid);
  else if(prev.v==='exo'){ S.exercise={pid:prev.pid,tid:prev.tid,q:0,answers:[]}; S.exoAnswered=false; renderExo(prev.pid,prev.tid); }
  else if(prev.v==='semaine') goSemaine(prev.pid,prev.tid,prev.si);
  else if(prev.v==='semaine-lecon') goSemaineLecon(prev.pid,prev.tid,prev.si);
  else if(prev.v==='semaine-exo'){ S.exercise={pid:prev.pid,tid:prev.tid,si:prev.si,q:0,answers:[],mode:'semaine'}; S.exoAnswered=false; renderSemaineExo(prev.pid,prev.tid,prev.si); }
  else if(prev.v==='semaine-exos-ouverts') goSemaineExosOuverts(prev.pid,prev.tid,prev.si);
  else viewHome();
}
/* ============================================================
   NOTIFICATIONS
   ============================================================ */
function renderNotifs(){
  const items = S.visited.map(v=>({...v,unread:!!v.new,t:v.ts?timeAgo(v.ts):(v.t||'')}));
  if(S.notifTab==='all') NOTIFS.forEach(n=>items.push({id:n.id,titre:n.titre,desc:n.msg,t:n.t,unread:n.unread,type:n.type}));
  if(!items.length){ $('#notifList').innerHTML = `<div class="empty"><span class="em">—</span><p>Aucune activité récente</p></div>`; return; }
  $('#notifList').innerHTML = items.map((n,i)=>`
    <div class="n-item ${n.unread?'unread':''}" style="animation-delay:${i*0.04}s" data-i="${i}">
      <h4>${esc(n.titre)}</h4><p>${esc(n.desc)}</p><time>${esc(n.t)}</time>
    </div>`).join('');
  $$('.n-item').forEach(el=>{
    el.onclick = ()=>{
      const n = items[+el.dataset.i]; closeNotif();
      let go = n.go;
      if(!go && n.type==='lecon' && typeof n.id==='string'){   /* anciennes entrées : « pid-tid » */
        const k=n.id.indexOf('-'); if(k>0) go={v:'theme',pid:n.id.slice(0,k),tid:n.id.slice(k+1)};
      }
      if(!go || !P[go.pid]) return;
      if(go.v==='theme') goTheme(go.pid,go.tid);
      else if(go.v==='semaine') goSemaine(go.pid,go.tid,go.si);
    };
  });
}
function clearNotifications(){
  S.visited = [];
  try{ localStorage.removeItem('vis'); }catch(e){}
  markNotifsRead(); renderNotifs();
  const btn = $('#notifClear');
  if(btn){
    const old = btn.innerHTML;
    btn.innerHTML = '✓ Effacé'; btn.style.background = 'var(--success)'; btn.style.color = '#fff';
    setTimeout(()=>{ btn.innerHTML = old; btn.style.background = ''; btn.style.color = ''; }, 1200);
  }
}
function openNotif(){ $('#notifPanel').classList.add('on'); $('#ov').classList.add('on'); renderNotifs(); }
function markNotifsRead(){
  NOTIFS.forEach(n=>n.unread=false); S.visited.forEach(v=>v.new=false);
  try{ localStorage.setItem('nread',JSON.stringify(NOTIFS.map(n=>n.id))); localStorage.setItem('vis',JSON.stringify(S.visited)); }catch(e){}
  updateBadge();
}
function closeNotif(){
  const was=$('#notifPanel').classList.contains('on');
  $('#notifPanel').classList.remove('on'); $('#ov').classList.remove('on');
  if(was) markNotifsRead();   /* le badge se remet à zéro quand on referme le panneau */
}
/* ============================================================
   MODAL QUITTER
   ============================================================ */
function openQuit(){ $('#quitModal').classList.add('on'); }
function closeQuit(){ $('#quitModal').classList.remove('on'); }
function confirmQuit(){
  closeQuit();
  try { if (window.Android && typeof window.Android.closeApp === 'function') { window.Android.closeApp(); return; } } catch(e) {}
  try { window.open('', '_self', ''); window.close(); } catch(e) {}
  setTimeout(() => {
    document.body.innerHTML = `
      <div style="position:fixed;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:20px;background:linear-gradient(160deg,#0a1628,#0d1f3a 50%,#1a2942);color:#fff;font-family:'Poppins',sans-serif;text-align:center;padding:30px;z-index:9999;">
        <div style="width:100px;height:100px;border-radius:50%;background:linear-gradient(145deg,#fff,#e8edf5);display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 8px rgba(255,214,10,.15),0 20px 60px rgba(0,0,0,.4);font-size:2.6rem;font-weight:900;color:#0a1628;letter-spacing:-3px;">F3</div>
        <h2 style="font-size:1.4rem;font-weight:800;letter-spacing:2px">MERCI !</h2>
        <p style="font-size:.85rem;color:rgba(255,255,255,.7);max-width:280px;line-height:1.6">Vous pouvez fermer cet onglet ou rouvrir l'application à tout moment.</p>
        <button onclick="location.reload()" style="margin-top:10px;padding:12px 28px;border-radius:30px;border:none;background:linear-gradient(135deg,#ffd60a,#ffb703);color:#0a1628;font-weight:800;font-size:.85rem;cursor:pointer;font-family:inherit;box-shadow:0 12px 32px rgba(255,214,10,.4);letter-spacing:1px;">Rouvrir</button>
      </div>`;
  }, 300);
}
/* ============================================================
   INITIALISATION AU CHARGEMENT DU DOM
   ============================================================ */
document.addEventListener('DOMContentLoaded', ()=>{
  window.__appReady = true;
  /* 1. SPLASH SCREEN : disparaît après 1 seconde */
  setTimeout(()=>{
    $('#splash').classList.add('hide');
    setTimeout(()=>{
      $('#splash').style.display='none';
      viewHome();
    },450);
  },1000);
  /* 2. NAVIGATION BASSE */
  $('#navHome').onclick = viewHome;
  $('#navLecons').onclick = viewLecons;
  $('#navExos').onclick = viewExos;
  $('#navAutres').onclick = viewAutres;
  $('#navBack').onclick = goBack;
  /* 3. BOUTON THÈME (clair / sombre) */
  $('#themeBtn').onclick = ()=>{
    const dark = document.documentElement.getAttribute('data-theme')==='dark';
    document.documentElement.setAttribute('data-theme', dark?'light':'dark');
    $('#themeBtn').textContent = dark?'🌙':'☀️';
    try{ localStorage.setItem('dark',!dark); }catch(e){}
  };
  /* 4. ÉDITEUR : ajouter / modifier le contenu */
  $('#editBtn').onclick=()=>openEditor('theme');
  $('#editorClose').onclick=closeEditor;
  $('#editorModal').addEventListener('click',e=>{if(e.target===$('#editorModal'))closeEditor();});
  document.querySelectorAll('.editor-tab').forEach(tab=>{
    tab.onclick=()=>openEditor(tab.dataset.editorTab);
  });
    /* 4. PANNEAU NOTIFICATIONS */
  $('#notifBtn').onclick = openNotif;
  $('#notifX').onclick = closeNotif;
  $('#ov').onclick = closeNotif;
  $('#notifClear').onclick = clearNotifications;
  document.querySelectorAll('.notif-tab').forEach(tab=>{
    tab.onclick = ()=>{
      document.querySelectorAll('.notif-tab').forEach(t=>t.classList.remove('active'));
      tab.classList.add('active');
      S.notifTab = tab.dataset.tab;
      renderNotifs();
    };
  });
  /* 5. MODAL QUITTER */
  $('#quitBtn').onclick = openQuit;
  $('#quitCancel').onclick = closeQuit;
  $('#quitConfirm').onclick = confirmQuit;
  $('#quitModal').addEventListener('click', e=>{
    if(e.target === $('#quitModal')) closeQuit();
  });
  /* 6. BADGE NOTIFICATIONS */
  updateBadge();
  /* 7. RACCOURCI CLAVIER : Échap ferme les modales */
  document.addEventListener('keydown', e=>{
    if(e.key==='Escape'){
      if($('#quitModal').classList.contains('on')) closeQuit();
      else closeNotif();
    }
  });
  /* 8. BOUTON RETOUR DU TÉLÉPHONE / NAVIGATEUR
        Une entrée « sentinelle » est ajoutée à l'historique ; chaque appui la consomme,
        on navigue dans l'application puis on la remet. Sur l'accueil, on laisse sortir. */
  try{ history.replaceState({app:1},''); history.pushState({app:1},''); }catch(e){}
  window.addEventListener('popstate', ()=>{
    if($('#quitModal').classList.contains('on')) closeQuit();
    else if($('#notifPanel').classList.contains('on')) closeNotif();
    else if(S.view!=='home') goBack();
    else { try{ history.back(); }catch(e){} return; }
    try{ history.pushState({app:1},''); }catch(e){}
  });
  /* 9. ACCESSIBILITÉ CLAVIER : cartes et réponses focalisables, Entrée / Espace = clic */
  const CLICKABLE='.p-card,.t-item,.semaine-item.clickable,.theme-card,.semaine-menu-card,.opt,.q-opt,.n-item,.sr-item';
  const makeFocusable=()=>$$(CLICKABLE).forEach(el=>{ if(!el.hasAttribute('tabindex')){ el.setAttribute('tabindex','0'); el.setAttribute('role','button'); } });
  new MutationObserver(makeFocusable).observe(document.body,{childList:true,subtree:true});
  makeFocusable();
  document.addEventListener('keydown',e=>{
    if((e.key==='Enter'||e.key===' ') && e.target.matches && e.target.matches(CLICKABLE)){ e.preventDefault(); e.target.click(); }
  });
});
/* ===== Petites améliorations de manipulation de l'éditeur ===== */
(function(){
  const modal=document.getElementById('editorModal');
  if(!modal)return;
  document.addEventListener('keydown',function(e){
    if(e.key==='Escape' && modal.classList.contains('on')) closeEditor();
  });
  /* Empêche le clic accidentel sur l'arrière-plan de fermer l'éditeur. */
  modal.addEventListener('click',function(e){
    if(e.target===modal) e.stopPropagation();
  });
  /* Remonte automatiquement au début quand on change d'onglet. */
  const oldOpen=openEditor;
  window.openEditor=function(tab){oldOpen(tab);setTimeout(function(){
    const b=modal.querySelector('.editor-body');if(b)b.scrollTop=0;
  },30)};
})();
(function(){
  function ready(){document.body.classList.add('app-ready')}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',ready,{once:true}); else ready();
  document.addEventListener('click',function(e){
    const a=e.target.closest('a[href]');
    if(!a) return;
    const href=a.getAttribute('href');
    if(!href || href.startsWith('#') || href.startsWith('javascript:') || a.target==='_blank') return;
    try{if(new URL(href,location.href).origin!==location.origin)return;}catch(_){return;}
    e.preventDefault();
    document.body.classList.remove('app-ready');
    document.body.classList.add('app-leaving');
    setTimeout(function(){location.href=href},280);
  },true);
})();
/* ============================================================
   AJOUT CIBLÉ — IMPORT SUJETS + DÉTENTE PROGRESSIVE
   Ne remplace pas les données, la navigation, le stockage ou
   les autres éditeurs existants.
   ============================================================ */
(function(){
  const DEFAULT_SUJET_QUESTIONS = 5;
  function sujetQuestionSlots(qs){
    const src=Array.isArray(qs)?qs.filter(q=>String(q?.question||'').trim()):[];
    const n=Math.max(DEFAULT_SUJET_QUESTIONS,src.length);
    return Array.from({length:n},(_,i)=>src[i]||{question:'',correction:''});
  }
  /* Détection plus tolérante : numéros, Q1/Question 1, lignes finissant
     par ?, et questions réparties sur plusieurs lignes. */
  window.detectSujetParts=function(raw){
    let lines=String(raw||'').replace(/\r/g,'\n')
      .split('\n')
      .map(x=>x.replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').trim())
      .filter(Boolean)
      .filter(x=>!/^page\s*\d+(?:\s*\/\s*\d+)?$/i.test(x));
    const all=lines.join(' ').toLowerCase();
    let typeTexte='Narratif';
    if(/texte\s*(?:de\s*)?(?:type\s*)?argumentatif|argumentatif|argumenter|opinion|convaincre|persuader|pour\s+ou\s+contre/.test(all)) typeTexte='Argumentatif';
    else if(/texte\s*(?:de\s*)?(?:type\s*)?explicatif|explicatif|expliquer|documentaire|article\s+informatif|pourquoi|comment\s+fonctionne/.test(all)) typeTexte='Explicatif';
    else if(/texte\s*(?:de\s*)?(?:type\s*)?administratif|administratif|lettre|demande|courrier|autorisation|compte\s*rendu/.test(all)) typeTexte='Administratif';
    const isQStart=x=>/^(?:(?:question|q)\s*)?\d{1,3}\s*[\)\].:\-]\s+/i.test(x)
      || /^(?:q|question)\s*\d{1,3}\s*[:.)\-]\s*/i.test(x);
    const isQuestionHeading=x=>/^(?:questions?|compréhension|questionnaire)\s*:?\s*$/i.test(x);
    const isQuestionLine=x=>/[?？]\s*$/.test(x);
    let qStart=-1;
    for(let i=0;i<lines.length;i++){
      if(isQuestionHeading(lines[i])){qStart=i+1;break;}
      if(isQStart(lines[i])){qStart=i;break;}
    }
    /* Si aucune numérotation n'existe, rechercher le premier bloc de
       questions consécutives ; cela évite de prendre tout le texte. */
    if(qStart<0){
      let run=0,start=-1;
      for(let i=0;i<lines.length;i++){
        if(isQuestionLine(lines[i])){ if(run===0) start=i; run++; }
        else if(run){ if(run>=2){qStart=start;break;} run=0; }
      }
      if(qStart<0 && run>=2) qStart=start;
    }
    let title=(lines.find(x=>/^(?:titre|sujet)\s*[:\-]/i.test(x))||'').replace(/^(?:titre|sujet)\s*[:\-]\s*/i,'').trim();
    if(!title){
      title=lines.find(x=>x.length>3 && !isQuestionHeading(x) && !isQStart(x) &&
        !/^(?:français|francais|texte|questions?|questionnaire|consigne|correction)\s*:?$/i.test(x))
        ||'Sujet importé';
    }
    let textLines=[];
    let qLines=[];
    if(qStart>=0){
      textLines=lines.slice(0,qStart);
      if(isQuestionHeading(lines[qStart-1]||'')) qLines=lines.slice(qStart);
      else qLines=lines.slice(qStart);
    }else{
      textLines=lines.slice();
    }
    /* Retire le titre et les étiquettes de section du texte support. */
    textLines=textLines.filter(x=>x!==title &&
      !/^(?:titre|sujet|texte|questions?|questionnaire)\s*[:\-]?\s*$/i.test(x));
    const questions=[];
    let current='';
    const pushCurrent=()=>{
      const q=current.replace(/^(?:(?:question|q)\s*)?\d{1,3}\s*[\)\].:\-]\s*/i,'').trim();
      if(q) questions.push({question:q,correction:''});
      current='';
    };
    for(const line of qLines){
      if(isQuestionHeading(line)) continue;
      if(isQStart(line)){
        if(current) pushCurrent();
        current=line;
      }else if(isQuestionLine(line)){
        if(current){ current+=(current.endsWith(' ')?' ':' ')+line; pushCurrent(); }
        else questions.push({question:line,correction:''});
      }else if(current){
        current+=' '+line;
      }
    }
    if(current) pushCurrent();
    /* Déduplication légère, sans modifier le contenu utile. */
    const seen=new Set();
    const uniqueQuestions=questions.filter(q=>{
      const k=q.question.replace(/\s+/g,' ').trim().toLowerCase();
      if(!k || seen.has(k)) return false;
      seen.add(k); return true;
    });
    /* Consigne et aide sont conservées lorsqu'elles sont explicitement
       identifiables, sans déplacer les autres données. */
    let consigne='';
    const ci=lines.findIndex(x=>/^consigne\s*[:\-]/i.test(x));
    if(ci>=0) consigne=lines[ci].replace(/^consigne\s*[:\-]\s*/i,'').trim();
    return {
      titre:title,
      typeTexte,
      texte:textLines.join('\n\n').trim(),
      questions:uniqueQuestions,
      consigne
    };
  };
  /* Import : conserve PDF/HTML/DOCX existants et ajoute les champs
     nécessaires si le document contient plus de questions que le nombre
     initial prévu. */
  window.importSujetFile=async function(e){
    const file=e.target.files?.[0]; if(!file)return;
    const st=$('#importSujetStatus');
    if(st){st.className='import-sujet-status';st.textContent='⏳ Lecture + détection automatique du texte et de toutes les questions…';}
    try{
      const ext=(file.name.split('.').pop()||'').toLowerCase();
      let raw='';
      if(ext==='html'||ext==='htm') raw=await readHtmlSujet(file);
      else if(ext==='docx') raw=await readDocxSujet(file);
      else if(ext==='pdf') raw=await readPdfSujet(file);
      else throw new Error('Format non pris en charge.');
      if(!raw.trim()) throw new Error('Aucun texte exploitable trouvé.');
      const parsed=detectSujetParts(raw);
      $('#edSTitre').value=parsed.titre||file.name.replace(/\.[^.]+$/,'');
      $('#edSType').value=parsed.typeTexte;
      $('#edSTexte').value=parsed.texte||'';
      /* IMPORTANT : le nombre de cartes/questions suit le document.
         Si le document en contient 8, 8 champs sont créés, même si le
         nombre par défaut est 5. S'il en contient 3, 5 champs sont proposés. */
      renderSujetQuestions(sujetQuestionSlots(parsed.questions));
      $('#edSConsigne').value=parsed.consigne||'';
      $('#edSAide').value='Importé depuis '+file.name+' — vérifiez les éléments détectés avant enregistrement.';
      if(st){
        st.className='import-sujet-status ok';
        st.textContent=`✓ Détection terminée : texte ${parsed.texte?'détecté':'non détecté'} • ${parsed.questions.length} question(s) détectée(s) • ${Math.max(DEFAULT_SUJET_QUESTIONS,parsed.questions.length)} champ(s) disponible(s).`;
      }
    }catch(err){
      if(st){st.className='import-sujet-status err';st.textContent='⚠️ '+(err.message||'Impossible de lire le fichier.');}
    }
    e.target.value='';
  };
  /* Éditeur Sujet type : même structure existante, mais les questions
     sont toujours extensibles et l'import reste en haut. */
  window.renderEditorSujet=function(box){
    box.innerHTML=`<div class="editor-form">
      <div class="editor-field"><label>Sujet type</label>
        <select id="edSujId"><option value="__new">＋ Nouveau sujet type</option>${SUJETS.map(x=>`<option value="${esc(x.id)}">${esc(x.titre)}</option>`).join('')}</select>
      </div>
      <div class="file-io-grid">
        <div class="import-sujet-card"><div class="import-sujet-icon">📥</div><div class="import-sujet-body">
          <strong>Fichiers importés</strong>
          <p>PDF, HTML ou DOCX : détection automatique du texte, du titre et de toutes les questions.</p>
          <label class="import-file-btn">📂 Importer un fichier
            <input id="importSujetFile" type="file" accept=".pdf,.html,.htm,.docx,application/pdf,text/html,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
          </label>
          <div id="importSujetStatus" class="import-sujet-status"></div>
        </div></div>
      </div>
      <div class="editor-field"><label>1. Type de texte</label><select id="edSType">
        ${['Explicatif','Narratif','Argumentatif','Administratif','Autre'].map(x=>`<option>${x}</option>`).join('')}
      </select></div>
      <div class="editor-field"><label>Titre du sujet</label><input id="edSTitre" placeholder="Titre du sujet"></div>
      <div class="editor-section"><h3>📄 2. Texte</h3><p class="editor-help">Le texte détecté est placé ici automatiquement. Vous pouvez le corriger.</p>
        <textarea id="edSTexte" rows="9" placeholder="Écrivez ou collez le texte…"></textarea>
      </div>
      <div class="editor-section"><h3>❓ 3. Toutes les questions</h3>
        <p class="editor-help">Les questions détectées sont toutes ajoutées. Le nombre de champs augmente automatiquement si le fichier contient plus de questions que le nombre par défaut (${DEFAULT_SUJET_QUESTIONS}).</p>
        <div id="sujetQuestions"></div>
        <button class="btn btn-s" id="addSujetQuestion">＋ Ajouter une question</button>
      </div>
      <div class="editor-section"><h3>✍️ Consigne de production</h3><textarea id="edSConsigne" rows="4" placeholder="Consigne donnée à l'élève…"></textarea></div>
      <div class="editor-section"><h3>💡 Aide / critères</h3><textarea id="edSAide" rows="4" placeholder="Aide, critères de réussite ou éléments de correction…"></textarea></div>
      <div class="export-sujet-card export-bottom"><div class="import-sujet-icon">📤</div><div class="import-sujet-body">
        <strong>Fichiers exportés</strong><p>Exportez uniquement un sujet déjà enregistré.</p>
        <div class="export-file-actions"><button type="button" class="pdf-btn" id="exportCurrentPdf">📄 PDF</button><button type="button" class="pdf-btn" id="exportCurrentCopy">📋 Copier</button></div>
      </div></div>
      <div class="editor-actions"><button class="btn btn-p" id="edSaveSujet">💾 Enregistrer le sujet</button><button class="btn btn-s editor-danger" id="edDeleteSujet">− Supprimer</button></div>
      <div class="editor-status" id="edStatus"></div>
    </div>`;
    const update=()=>{
      const id=$('#edSujId').value,isNew=id==='__new';
      const x=SUJETS.find(s=>s.id===id)||{titre:'Nouveau sujet type',typeTexte:'Narratif',texte:'',questions:[],consigne:'',aide:''};
      $('#edSType').value=x.typeTexte||'Narratif';
      $('#edSTitre').value=x.titre||'';
      $('#edSTexte').value=x.texte||'';
      $('#edSConsigne').value=x.consigne||'';
      $('#edSAide').value=x.aide||'';
      renderSujetQuestions(sujetQuestionSlots(x.questions||[]));
      $('#edSaveSujet').textContent=isNew?'＋ Ajouter le sujet':'💾 Enregistrer le sujet';
      $('#edDeleteSujet').style.display=isNew?'none':'inline-flex';
    };
    $('#edSujId').onchange=update;
    $('#importSujetFile').onchange=importSujetFile;
    $('#exportCurrentPdf').onclick=()=>exportSujetPDF($('#edSujId').value);
    $('#exportCurrentCopy').onclick=()=>copySujet($('#edSujId').value);
    $('#edSaveSujet').onclick=saveSujetEditor;
    $('#edDeleteSujet').onclick=deleteSujetEditor;
    $('#addSujetQuestion').onclick=()=>addQuestionEditor();
    $('#edSujId').value='__new';
    update();
  };
  /* Détente : ajout de jeux progressifs, sans retirer les 4 jeux existants. */
  const oldRenderDetente=window.renderDetente;
  window.renderDetente=function(){
    if(typeof oldRenderDetente==='function') oldRenderDetente();
    const grid=document.querySelector('#autresContent .game-grid');
    const panel=document.getElementById('gamePanel');
    if(!grid||!panel)return;
    if(!document.getElementById('gameProgress')) grid.insertAdjacentHTML('beforeend',
      `<button class="game-btn" id="gameProgress"><span class="game-ico">📈</span>Progression<small>3 niveaux</small></button>
       <button class="game-btn" id="gameVraiFaux"><span class="game-ico">🎯</span>Vrai / Faux<small>De plus en plus difficile</small></button>
       <button class="game-btn" id="gameMystere"><span class="game-ico">🔎</span>Mot mystère<small>3 niveaux</small></button>
       <button class="game-btn" id="gameRapidite"><span class="game-ico">⏱️</span>Défi série<small>Gagnez des points</small></button>
       <button class="game-btn" id="gameWheel"><span class="game-ico">🎡</span>Roue de la chance<small>Tentez votre coup</small></button>`);
    document.getElementById('gameProgress').onclick=gameProgress;
    document.getElementById('gameVraiFaux').onclick=gameVraiFaux;
    document.getElementById('gameMystere').onclick=gameMystere;
    document.getElementById('gameRapidite').onclick=gameRapidite;
    document.getElementById('gameWheel').onclick=gameWheel;
  };
  function gameProgress(){
    const levels=[
      {n:1,t:'Facile',q:[['Synonyme de « heureux » ?','JOYEUX'],['Contraire de « grand » ?','PETIT'],['Pluriel de « journal » ?','JOURNAUX']]},
      {n:2,t:'Intermédiaire',q:[['Quel est le verbe dans « Vous écrivez » ?','ECRIVEZ'],['Nom dérivé de « courageux » ?','COURAGE'],['Contraire de « ancien » ?','NOUVEAU']]},
      {n:3,t:'Expert',q:[['Quel connecteur marque la conséquence ?','DONC'],['Temps de « nous avions lu » ?','PLUS-QUE-PARFAIT'],['Fonction de « à Madagascar » dans « Je voyage à Madagascar » ?','COMPLEMENT CIRCONSTANCIEL DE LIEU']]}
    ];
    let level=0,score=0,index=0;
    const draw=()=>{
      const L=levels[level],item=L.q[index];
      $('#gamePanel').innerHTML=`<div class="game-title">📈 Niveau ${L.n} — ${L.t}</div><p style="font-size:.78rem;font-weight:800">${index+1}/${L.q.length} — ${item[0]}</p><input class="game-input" id="gInput" placeholder="Votre réponse"><button class="btn btn-p" id="gCheck">Vérifier</button><div class="game-msg" id="gMsg"></div>`;
      $('#gCheck').onclick=()=>{
        const ok=$('#gInput').value.trim().toUpperCase()===item[1];
        if(ok)score++;
        $('#gMsg').textContent=ok?'✅ Correct !':'❌ Réponse attendue : '+item[1];
        $('#gCheck').disabled=true;
        setTimeout(()=>{
          index++;
          if(index>=L.q.length){
            if(level<levels.length-1){level++;index=0;draw();}
            else {$('#gamePanel').innerHTML=`<div class="game-title">🏆 Progression terminée</div><p style="font-size:.8rem;font-weight:800">Score : ${score}/${levels.reduce((a,x)=>a+x.q.length,0)}</p><button class="btn btn-p" id="gRestart">↻ Rejouer</button>`;$('#gRestart').onclick=gameProgress;}
          }else draw();
        },650);
      };
    };
    draw();
  }
  function gameVraiFaux(){
    const levels=[
      [['Un nom désigne une personne, un animal, une chose ou une idée.',true],['« Mais » est une conjonction de coordination.',true],['L’imparfait sert souvent à exprimer une action ponctuelle terminée.',false]],
      [['« Donc » marque généralement la conséquence.',true],['Une phrase interrogative sert à donner un ordre.',false],['Dans « Les élèves lisent », « lisent » est un verbe.',true]],
      [['« Bien que » introduit une relation de concession.',true],['Le plus-que-parfait est un temps simple.',false],['Dans « La lettre est écrite par Paul », la phrase est à la voix passive.',true]]
    ];
    let level=0,i=0,score=0;
    const draw=()=>{
      const it=levels[level][i];
      $('#gamePanel').innerHTML=`<div class="game-title">🎯 Niveau ${level+1}/3</div><p style="font-size:.8rem;font-weight:800">${it[0]}</p><div class="game-grid"><button class="btn btn-p" id="vfTrue">VRAI</button><button class="btn btn-s" id="vfFalse">FAUX</button></div><div class="game-msg" id="gMsg"></div>`;
      const answer=v=>{const ok=v===it[1];if(ok)score++;$('#gMsg').textContent=ok?'✅ Correct !':'❌ Incorrect.';setTimeout(()=>{i++;if(i>=levels[level].length){if(level<2){level++;i=0;draw();}else {$('#gamePanel').innerHTML=`<div class="game-title">🏆 Fin du défi</div><p style="font-size:.8rem;font-weight:800">Score : ${score}/${levels.flat().length}</p><button class="btn btn-p" id="gRestartVF">↻ Rejouer</button>`;$('#gRestartVF').onclick=gameVraiFaux;}}else draw();},550);};
      $('#vfTrue').onclick=()=>answer(true);$('#vfFalse').onclick=()=>answer(false);
    };
    draw();
  }
  function gameMystere(){
    const levels=[
      {word:'LIVRE',hint:'On le lit.',n:1},
      {word:'ARGUMENT',hint:'Il sert à justifier une opinion.',n:2},
      {word:'CONNECTEUR',hint:'Il relie les idées et organise le texte.',n:3}
    ];
    let level=0,tries=0;
    const draw=()=>{
      const L=levels[level];
      const mask=L.word.split('').map((c,i)=>i%2?'_':c).join(' ');
      $('#gamePanel').innerHTML=`<div class="game-title">🔎 Niveau ${L.n}/3 — Mot mystère</div><div class="emoji-puzzle" style="font-size:1.2rem">${mask}</div><p style="font-size:.72rem;color:var(--text2)">Indice : ${L.hint}</p><input class="game-input" id="gInput" placeholder="Mot complet"><button class="btn btn-p" id="gCheck">Vérifier</button><div class="game-msg" id="gMsg"></div>`;
      $('#gCheck').onclick=()=>{tries++;const ok=$('#gInput').value.trim().toUpperCase()===L.word;$('#gMsg').textContent=ok?'✅ Trouvé !':'❌ Encore un essai.';if(ok){setTimeout(()=>{level++;tries=0;if(level<levels.length)draw();else {$('#gamePanel').innerHTML=`<div class="game-title">🏆 3 niveaux réussis !</div><button class="btn btn-p" id="gRestartM">↻ Rejouer</button>`;$('#gRestartM').onclick=gameMystere;}},500);}};
    };
    draw();
  }
  function gameRapidite(){
    const qs=[
      ['Antonyme de « rapide » ?','LENT'],['Participe passé de « écrire » ?','ECRIT'],['Pluriel de « cheval » ?','CHEVAUX'],['Infinitif de « nous lisons » ?','LIRE'],['Connecteur de conclusion ?','ENFIN']
    ];
    let i=0,score=0,started=Date.now(),timer;
    const draw=()=>{
      const elapsed=Math.floor((Date.now()-started)/1000);
      if(elapsed>=30||i>=qs.length){clearInterval(timer);$('#gamePanel').innerHTML=`<div class="game-title">⏱️ Série terminée</div><p style="font-size:.8rem;font-weight:800">Score : ${score}/${qs.length}</p><button class="btn btn-p" id="gRestartR">↻ Rejouer</button>`;$('#gRestartR').onclick=gameRapidite;return;}
      const q=qs[i];
      $('#gamePanel').innerHTML=`<div class="game-title">⏱️ Défi série — ${30-elapsed}s</div><p style="font-size:.78rem;font-weight:800">${i+1}. ${q[0]}</p><input class="game-input" id="gInput" placeholder="Réponse"><button class="btn btn-p" id="gCheck">Valider</button><div class="game-msg" id="gMsg"></div>`;
      $('#gCheck').onclick=()=>{if($('#gInput').value.trim().toUpperCase()===q[1])score++;i++;draw();};
    };
    draw();timer=setInterval(draw,1000);
  }
  function gameWheel(){
    const slots=[
      {e:'⭐',t:'+3 points bonus',ok:true},
      {e:'📖',t:'Relisez une leçon avant de continuer',ok:false},
      {e:'🏆',t:'Bravo, tour gagnant !',ok:true},
      {e:'🔁',t:'Rejouez un mini-jeu au choix',ok:false},
      {e:'🎯',t:'Défi réussi automatiquement',ok:true},
      {e:'💤',t:'Pas de chance, à vous de rejouer',ok:false},
      {e:'🍀',t:'Chance totale, +5 points',ok:true},
      {e:'📚',t:'Révisez le lexique de la semaine',ok:false}
    ];
    const n=slots.length,seg=360/n;
    const wheelHtml=`<div class="wheel-wrap">
      <div class="wheel-ptr">▼</div>
      <div class="wheel" id="wheelEl" style="background:conic-gradient(${slots.map((_,i)=>`${i%2?'#17264a':'#f5c400'} ${i*seg}deg ${(i+1)*seg}deg`).join(',')})">
        ${slots.map((s,i)=>`<span class="wheel-slot" style="transform:rotate(${i*seg+seg/2}deg)"><i style="transform:rotate(90deg)">${s.e}</i></span>`).join('')}
      </div>
    </div>`;
    $('#gamePanel').innerHTML=`<div class="game-title">🎡 Roue de la chance</div><p style="font-size:.72rem;color:var(--text2)">Appuyez sur « Lancer » et découvrez votre résultat.</p>${wheelHtml}<button class="btn btn-p" id="gSpin" style="margin-top:10px">🎡 Lancer la roue</button><div class="game-msg" id="gMsg"></div>`;
    let spinning=false,rotation=0;
    $('#gSpin').onclick=()=>{
      if(spinning)return;spinning=true;$('#gMsg').textContent='';
      const idx=Math.floor(Math.random()*n);
      const target=360*5+(360-(idx*seg+seg/2));
      rotation+=target;
      const el=$('#wheelEl');
      el.style.transition='transform 3.2s cubic-bezier(.17,.67,.16,1)';
      el.style.transform=`rotate(${rotation}deg)`;
      setTimeout(()=>{
        spinning=false;
        const s=slots[idx];
        $('#gMsg').innerHTML=`${s.ok?'✅':'ℹ️'} <b>${s.e} ${s.t}</b>`;
      },3300);
    };
  }
})();
/* AJOUT CIBLÉ — détection complète des questions + travail de rédaction.
   Ne remplace pas les autres données/fonctions de l'application. */
(function(){
  const oldDetect=window.detectSujetParts;
  window.detectSujetParts=function(raw){
    const base=oldDetect?oldDetect(raw):{titre:'Sujet importé',typeTexte:'Narratif',texte:'',questions:[],consigne:''};
    const lines=String(raw||'').replace(/\r/g,'\n').split('\n')
      .map(x=>x.replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').trim()).filter(Boolean)
      .filter(x=>!/^page\s*\d+(?:\s*\/\s*\d+)?$/i.test(x));
    const redStart=/^(?:travail\s+de\s+r[ée]daction|travail\s+[àa]\s+faire|production\s+[ée]crite|production\s+ecrite|sujet\s+de\s+r[ée]daction|r[ée]daction|expression\s+[ée]crite|consigne\s+de\s+production)\b/i;
    const redWords=/(?:r[ée]digez|r[ée]diger|r[ée]dige|[ée]crivez|[ée]crire|composez|compose|produisez|racontez|imaginez|argumentez|expliquez|pr[ée]sentez|donnez\s+votre\s+avis|vous\s+allez\s+produire)/i;
    const section=/^(?:correction|corrig[ée]|aide|crit[èe]res?|bar[èe]me|questions?|compr[ée]hension|questionnaire|lexique|grammaire|conjugaison)\b/i;
    const num=/^(?:(?:question|q)\s*)?\d{1,3}\s*[\)\].:\-]\s+/i;
    let redaction='';
    for(let i=0;i<lines.length;i++){
      const line=lines[i];
      if(redStart.test(line) || (redWords.test(line) && line.length>15)){
        const parts=[line];
        for(let j=i+1;j<lines.length;j++){
          const n=lines[j];
          if(section.test(n) || num.test(n) || redStart.test(n)) break;
          /* Une nouvelle question explicite termine la consigne. */
          if(/[?？]\s*$/.test(n)) break;
          parts.push(n);
          if(parts.join(' ').length>1200) break;
        }
        redaction=parts.join('\n').trim();
        break;
      }
    }
    /* Les questions numérotées, même sans « ? », sont conservées. Ajout
       des formulations interrogatives/consignes courtes oubliées par le
       détecteur initial, sans dupliquer les questions déjà trouvées. */
    const existing=(base.questions||[]).map(q=>String(q.question||'').trim()).filter(Boolean);
    const keys=new Set(existing.map(q=>q.replace(/\s+/g,' ').toLowerCase()));
    const extras=[];
    let inQuestions=false;
    for(const line of lines){
      if(/^(?:questions?|questionnaire|compr[ée]hension)\s*:?.*$/i.test(line)){inQuestions=true;continue;}
      if(redStart.test(line)) {inQuestions=false;continue;}
      if(!inQuestions) continue;
      let q=line.replace(/^(?:(?:question|q)\s*)?\d{1,3}\s*[\)\].:\-]\s*/i,'').trim();
      const looksLike= num.test(line) || /^(?:pourquoi|comment|quand|o[uù]|qui|que|qu'|quel|quelle|quels|quelles|expliquez|justifiez|relevez|identifiez|pr[ée]cisez|donnez|indiquez|montrez|classez|transformez|soulignez|rep[ée]rez|citez)\b/i.test(q);
      if(looksLike && q && !redWords.test(q)){
        const k=q.replace(/\s+/g,' ').toLowerCase();
        if(!keys.has(k)){keys.add(k);extras.push({question:q,correction:''});}
      }
    }
    const questions=[...(base.questions||[]),...extras];
    return {...base,questions,consigne:(redaction||base.consigne||'').trim(),redaction:redaction.trim()};
  };
  const oldImport=window.importSujetFile;
  window.importSujetFile=async function(e){
    await oldImport(e);
    /* L'import existant remplit déjà le texte et les questions. On relance
       uniquement la détection de la rédaction à partir du texte importé
       afin de l'afficher explicitement, sans toucher aux autres champs. */
    try{
      const text=$('#edSTexte')?.value||'';
      const full=(text+'\n'+($('#edSConsigne')?.value||'')).trim();
      const d=window.detectSujetParts(full);
      if($('#edSRedaction')) $('#edSRedaction').value=d.redaction||$('#edSConsigne').value||'';
      if(d.redaction && $('#edSConsigne')) $('#edSConsigne').value=d.redaction;
      if($('#importSujetStatus') && d.redaction){
        $('#importSujetStatus').textContent+=' • ✍️ travail de rédaction détecté';
      }
    }catch(_){/* conserver l'import existant en cas de format particulier */}
  };
  const oldRender=window.renderEditorSujet;
  window.renderEditorSujet=function(box){
    oldRender(box);
    const sec=document.createElement('div');
    sec.className='editor-section';
    sec.innerHTML='<h3>✍️ Travail de rédaction détecté</h3><p class="editor-help">La consigne de rédaction détectée dans le document est affichée ici. Vous pouvez la modifier avant d’enregistrer.</p><textarea id="edSRedaction" rows="6" placeholder="Travail de rédaction / production écrite…"></textarea>';
    const cons=document.getElementById('edSConsigne');
    if(cons && cons.parentElement) cons.parentElement.after(sec); else box.appendChild(sec);
    const id=document.getElementById('edSujId')?.value;
    const x=window.SUJETS?.find?.(s=>s.id===id);
    if(x) document.getElementById('edSRedaction').value=x.redaction||x.consigne||'';
    const save=document.getElementById('edSaveSujet');
    if(save){
      const old=save.onclick;
      save.onclick=function(){
        const r=document.getElementById('edSRedaction')?.value.trim()||'';
        const c=document.getElementById('edSConsigne');
        if(c && r) c.value=r;
        return old?.call(this);
      };
    }
    const importInput=document.getElementById('importSujetFile');
    if(importInput){
      const oldHandler=importInput.onchange;
      importInput.onchange=async function(ev){
        await oldHandler?.call(this,ev);
        const r=document.getElementById('edSRedaction');
        if(r){
          const d=window.detectSujetParts((document.getElementById('edSTexte')?.value||'')+'\n'+(document.getElementById('edSConsigne')?.value||''));
          r.value=d.redaction||document.getElementById('edSConsigne')?.value||'';
        }
      };
    }
  };
})();
/* AJOUT CIBLÉ — formes variées de questions + bouton ANNULER.
   Aucun autre fonctionnement n'est remplacé. */
(function(){
  const previousDetect=window.detectSujetParts;
  window.detectSujetParts=function(raw){
    const d=previousDetect?previousDetect(raw):{titre:'Sujet importé',typeTexte:'Narratif',texte:'',questions:[],consigne:''};
    const lines=String(raw||'').replace(/\r/g,'\n').split('\n')
      .map(x=>x.replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').trim()).filter(Boolean)
      .filter(x=>!/^page\s*\d+(?:\s*\/\s*\d+)?$/i.test(x));
    const key=s=>String(s||'').replace(/\s+/g,' ').trim().toLowerCase();
    const seen=new Set((d.questions||[]).map(q=>key(q.question||q.q||q.texte||'')));
    const found=[];
    /* Toutes les formes courantes rencontrées dans les sujets scolaires. */
    const prefixes=[
      /^(?:item|item\s*)\s*\d{1,3}\s*[\)\].:\-]?\s*/i,
      /^(?:question|quest|q)\s*\d{1,3}\s*[\)\].:\-]?\s*/i,
      /^\d{1,3}\s*[\)\].:\-]\s*/,
      /^\d{1,3}\s+[-–—:]\s*/,
      /^[a-z]\s*[\)\].:\-]\s*/i,
      /^(?:i{1,3}|iv|v|vi|vii|viii|ix|x)\s*[\)\].:\-]\s*/i
    ];
    const instruction=/^(?:expliquez|justifiez|relevez|identifiez|pr[ée]cisez|indiquez|donnez|montrez|classez|transformez|soulignez|rep[ée]rez|citez|compl[ée]tez|comparez|d[ée]crivez|analysez|caract[ée]risez|n[ée]cessitez|dites|r[ée]pondez|observez|reformulez|conjuguez|accordez|remplacez|associez|reliez|entourez|choisissez|r[ée]digez|[ée]crivez|racontez|composez|argumentez)\b/i;
    const interrogative=/^(?:pourquoi|comment|quand|o[uù]|qui|que|qu'|quel|quelle|quels|quelles|combien|lequel|laquelle|lesquels|lesquelles)\b/i;
    let questionMode=false;
    for(let i=0;i<lines.length;i++){
      const line=lines[i];
      if(/^(?:questions?|questionnaire|compr[ée]hension|activit[ée]s?|travail\s+sur\s+le\s+texte)\b/i.test(line)){
        questionMode=true; continue;
      }
      if(/^(?:travail\s+de\s+r[ée]daction|production\s+[ée]crite|sujet\s+de\s+r[ée]daction|expression\s+[ée]crite)\b/i.test(line)){
        questionMode=false; continue;
      }
      let q=line, matched=false;
      for(const re of prefixes){
        if(re.test(line)){ q=line.replace(re,'').trim(); matched=true; break; }
      }
      /* Une question peut être explicitement formulée sans numéro. */
      if(!matched && (interrogative.test(q)||instruction.test(q)||/[?？]\s*$/.test(q))) matched=true;
      if(!matched || !q) continue;
      /* Ne pas prendre comme questions les simples titres de rubriques. */
      if(/^(?:correction|corrig[ée]|aide|crit[èe]res?|bar[èe]me|lexique|grammaire|conjugaison|vocabulaire|r[ée]daction)$/i.test(q)) continue;
      if(q.length<3) continue;
      /* Récupère les lignes suivantes lorsqu'une question est coupée sur
         plusieurs lignes, jusqu'à la prochaine question identifiable. */
      let full=q;
      for(let j=i+1;j<lines.length;j++){
        const n=lines[j];
        let next=false;
        for(const re of prefixes){ if(re.test(n)){next=true;break;} }
        if(next || /^(?:questions?|questionnaire|correction|corrig[ée]|travail\s+de\s+r[ée]daction|production\s+[ée]crite)\b/i.test(n)) break;
        if(/[?？]\s*$/.test(full)) break;
        if(instruction.test(n)||interrogative.test(n)){ break; }
        full+=' '+n;
        if(full.length>900) break;
      }
      full=full.trim();
      const k=key(full);
      if(!seen.has(k)){
        seen.add(k); found.push({question:full,correction:''});
      }
    }
    /* Si la détection précédente a raté les items, les nouveaux sont ajoutés. */
    return {...d,questions:[...(d.questions||[]),...found]};
  };
  const oldRender=window.renderEditorSujet;
  window.renderEditorSujet=function(box){
    oldRender(box);
    const exportCard=document.querySelector('.export-file-actions');
    if(exportCard && !document.getElementById('previewCurrentPdf')){
      const pb=document.createElement('button');pb.type='button';pb.className='pdf-btn';pb.id='previewCurrentPdf';pb.textContent='👁️ Aperçu avant impression';
      exportCard.insertBefore(pb,exportCard.firstChild);
      pb.onclick=()=>previewSujetPDF(document.getElementById('edSujId')?.value);
    }
    /* Bouton ANNULER : restaure les données du sujet sélectionné sans
       enregistrer les modifications en cours. Pour un nouveau sujet,
       il vide le formulaire et revient à l'état initial. */
    const actions=document.getElementById('edSaveSujet')?.parentElement;
    if(actions && !document.getElementById('edCancelSujet')){
      const b=document.createElement('button');
      b.type='button'; b.id='edCancelSujet'; b.className='btn btn-s'; b.textContent='↩ Annuler';
      const save=document.getElementById('edSaveSujet');
      if(save) actions.insertBefore(b,save.nextSibling);
      else actions.appendChild(b);
      b.onclick=function(){
        const box=document.getElementById('editorForm');
        const id=document.getElementById('edSujId')?.value;
        /* Recrée réellement le formulaire depuis les données enregistrées.
           L'ancien bouton ne faisait que réécrire les champs et pouvait donc
           conserver une partie des ajouts/modifications DOM. */
        if(box && typeof oldRender==='function'){
          oldRender(box);
          const sel=document.getElementById('edSujId');
          if(sel && id){
            sel.value=id;
            sel.dispatchEvent(new Event('change'));
          }
          const st=document.getElementById('edStatus');
          if(st){st.textContent='↩ Modifications annulées : retour aux données enregistrées.';st.className='editor-status';}
          return;
        }
        if(id && id!=='__new' && window.SUJETS){
          const sujet=window.SUJETS.find(x=>x.id===id);
          if(sujet){
            const q=window.sujetQuestionSlots?sujetQuestionSlots(sujet.questions||[]):(sujet.questions||[]);
            if(document.getElementById('edSTitre')) document.getElementById('edSTitre').value=sujet.titre||'';
            if(document.getElementById('edSType')) document.getElementById('edSType').value=sujet.typeTexte||sujet.type||'Narratif';
            if(document.getElementById('edSTexte')) document.getElementById('edSTexte').value=sujet.texte||'';
            if(document.getElementById('edSConsigne')) document.getElementById('edSConsigne').value=sujet.consigne||'';
            if(document.getElementById('edSRedaction')) document.getElementById('edSRedaction').value=sujet.redaction||sujet.consigne||'';
            if(typeof renderSujetQuestions==='function') renderSujetQuestions(q);
            if(document.getElementById('edSAide')) document.getElementById('edSAide').value=sujet.aide||'';
            const st=document.getElementById('edStatus'); if(st){st.textContent='↩ Modifications annulées.';st.className='editor-status';}
            return;
          }
        }
        ['edSTitre','edSTexte','edSConsigne','edSRedaction','edSAide'].forEach(id=>{const e=document.getElementById(id);if(e)e.value='';});
        if(typeof renderSujetQuestions==='function') renderSujetQuestions(sujetQuestionSlots([]));
        const st=document.getElementById('edStatus'); if(st){st.textContent='↩ Saisie annulée.';st.className='editor-status';}
      };
    }
  };
})();
(function(){
'use strict';
const __oldTheme=window.renderEditorTheme;
const __oldLesson=window.renderEditorLesson;
const __oldExo=window.renderEditorExo;
function eicHTML(kind){
 const label=kind==='theme'?'Thème':kind==='lesson'?'Leçon':'Exercice';
 return `<div class="editor-import-card" id="editorImport_${kind}">
   <div class="eic-head"><span>📥</span> Importer dans ${label}</div>
   <p>Choisissez un fichier. Le texte est extrait automatiquement et les questions sont recherchées sous plusieurs formes : <b>1.</b>, <b>1)</b>, <b>Item 1</b>, <b>Item1</b>, <b>Q1</b>, <b>Question 1</b>, lettres <b>a)</b>, ou questions terminées par <b>?</b>.</p>
   <div class="editor-import-actions">
    <label class="editor-import-btn">📕 PDF<input type="file" data-editor-import="${kind}" accept=".pdf,application/pdf"></label>
    <label class="editor-import-btn">📘 DOCX<input type="file" data-editor-import="${kind}" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document"></label>
    <label class="editor-import-btn">🌐 HTML<input type="file" data-editor-import="${kind}" accept=".html,.htm,text/html"></label>
    <label class="editor-import-btn">⚙️ JS<input type="file" data-editor-import="${kind}" accept=".js,text/javascript,application/javascript"></label>
   </div><div class="editor-import-status" data-import-status="${kind}"></div>
 </div>`;
}
function mountImport(kind){
 const root=document.querySelector('.editor-form'); if(!root||root.querySelector('#editorImport_'+kind))return;
 const el=document.createElement('div');el.innerHTML=eicHTML(kind);const card=el.firstElementChild;
 const anchor=kind==='lesson'?document.getElementById('lessonFields'):kind==='exo'?document.getElementById('exoFields'):null;
 if(anchor&&anchor.parentElement) anchor.parentElement.insertBefore(card,anchor);
 else root.insertBefore(card,root.firstElementChild?.nextSibling||root.firstChild);
 card.querySelectorAll('input[type=file]').forEach(inp=>inp.addEventListener('change',e=>handleImport(kind,e)));
}
async function readAnyEditorFile(file){
 const ext=(file.name.split('.').pop()||'').toLowerCase();
 if(ext==='html'||ext==='htm')return await readHtmlSujet(file);
 if(ext==='docx')return await readDocxSujet(file);
 if(ext==='pdf')return await readPdfSujet(file);
 if(ext==='js')return await file.text();
 throw new Error('Format non pris en charge.');
}
function cleanImportedSource(raw,ext){
 let s=String(raw||'').replace(/\r/g,'');
 if(ext==='js'){
   s=s.replace(/\/\*[\s\S]*?\*\//g,'\n').replace(/(^|\s)\/\/.*$/gm,'$1');
   const strings=[];const re=/(?:`(?:\\.|[^`])*`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/g;let m;
   while((m=re.exec(s)))strings.push(m[0].slice(1,-1).replace(/\\n/g,'\n').replace(/\\(["'`\\])/g,'$1'));
   if(strings.length)s=strings.join('\n');
 }
 return s.replace(/[ \t]+/g,' ').replace(/\n{3,}/g,'\n\n').trim();
}
function questionPrefixMatch(line){
 return /^(?:(?:item|question|quest|q)\s*\d{1,3}\s*[:.)-]?|\d{1,3}\s*[.)-]|[a-zàâçéèêëîïôûùüÿñæœ]\s*[.)-])\s*/i.test(line);
}
function questionPrefixStrip(line){
 return line.replace(/^(?:(?:item|question|quest|q)\s*\d{1,3}\s*[:.)-]?|\d{1,3}\s*[.)-]|[a-zàâçéèêëîïôûùüÿñæœ]\s*[.)-])\s*/i,'').trim();
}
function directQuestionLine(line){
 return /^(?:qui|que|qu'|quoi|quel(?:le|s)?|où|quand|comment|pourquoi|combien|lequel|laquelle|lesquels|lesquelles|citez|citer|relevez|relever|identifiez|identifier|expliquez|expliquer|justifiez|justifier|donnez|donner|indiquez|indiquer|précisez|préciser|montrez|montrer|transformez|transformer|complétez|compléter|classez|classer|relevez|relever|dites|dire|comparez|comparer|analysez|analyser|caractérisez|caractériser|repérez|repérer|relevez|relever)\b/i.test(line);
}
function normalizeQText(s){return String(s||'').replace(/^[-•–—]\s*/,'').replace(/\s+/g,' ').trim();}
function detectQuestionsAdvanced(raw){
 const lines=String(raw||'').replace(/\r/g,'').split('\n').map(x=>x.trim()).filter(Boolean).filter(x=>!/^page\s*\d+(?:\s*\/\s*\d+)?$/i.test(x));
 const qs=[];let current='';let mode=false;let sawExplicit=false;
 const push=()=>{let q=normalizeQText(current);q=questionPrefixStrip(q);if(q&&q.length>=3&&!/^questions?\s*[:\-]?$/i.test(q)){if(!qs.some(x=>x.toLowerCase()===q.toLowerCase()))qs.push(q);}current='';};
 for(let i=0;i<lines.length;i++){
   let l=lines[i];
   const heading=/^(?:questions?|questionnaire|compréhension|comprehension|activités?|activites?)\s*[:\-]?$/.test(l.toLowerCase());
   if(heading){push();mode=true;sawExplicit=true;continue;}
   const explicit=questionPrefixMatch(l);
   const direct=directQuestionLine(l);
   const endsQ=/[?？]\s*$/.test(l);
   if(explicit){push();current=l;mode=true;sawExplicit=true;if(endsQ)push();continue;}
   if(mode){
     if(endsQ){current+=(current?' ':'')+l;push();}
     else if(current){current+=' '+l;}
     else if(direct){current=l;if(endsQ)push();}
     else if(/^(?:consigne|travail|production|rédaction|redaction)\s*[:\-]/i.test(l)){push();mode=false;}
     continue;
   }
   if(endsQ&& (direct || sawExplicit)){push();current=l;push();}
 }
 push();
 // Deux lignes successives finissant par ? restent des questions même sans titre « Questions ».
 if(qs.length<2){
   const fallback=[];for(const l of lines){if(/[?？]\s*$/.test(l)&&l.length>8)fallback.push(normalizeQText(l));}
   fallback.forEach(q=>{if(!qs.some(x=>x.toLowerCase()===q.toLowerCase()))qs.push(q);});
 }
 return qs;
}
function splitImportedContent(raw){
 const lines=String(raw||'').replace(/\r/g,'').split('\n').map(x=>x.trim()).filter(Boolean);
 const qs=detectQuestionsAdvanced(raw);
 const qSet=new Set(qs.map(q=>q.toLowerCase()));
 const body=lines.filter(l=>!qSet.has(normalizeQText(l).toLowerCase())&&!questionPrefixMatch(l)&&!/^(?:questions?|questionnaire|compréhension|comprehension)\s*[:\-]?$/i.test(l));
 let title=body.find(l=>l.length>3&&l.length<140)||'Document importé';
 const text=body.filter(l=>l!==title).join('\n\n');
 let type='Narratif';const all=String(raw).toLowerCase();if(/argument|opinion|convaincre|pour ou contre/.test(all))type='Argumentatif';else if(/explic|documentaire|pourquoi|comment fonctionne/.test(all))type='Explicatif';else if(/lettre|demande|courrier|autorisation/.test(all))type='Administratif';
 const cons=(lines.find(l=>/^(?:consigne|travail de rédaction|production écrite|production)\s*[:\-]/i.test(l))||'').replace(/^(?:consigne|travail de rédaction|production écrite|production)\s*[:\-]\s*/i,'').trim();
 return {titre:title,typeTexte:type,texte:text,questions:qs,consigne:cons};
}
function setVal(id,v){const el=document.getElementById(id);if(el&&v!=null)el.value=v;}
function setStatus(kind,msg,ok){const el=document.querySelector(`[data-import-status="${kind}"]`);if(!el)return;el.className='editor-import-status '+(ok?'ok':'err');el.textContent=msg;}
function applyQuestionsToEditor(prefix,qs){
 const holder=document.getElementById(prefix);if(!holder)return;
 holder.innerHTML='';
 const arr=qs.length?qs:[{q:'',corrige:''}];
 arr.forEach(q=>{
   if(typeof q==='string')q={q,corrige:''};
   const wrap=document.createElement('div');wrap.className='q-card';wrap.innerHTML=`<div class="q-head"><b>Question</b><button type="button" class="mini-del">−</button></div><textarea class="q-q" rows="2" placeholder="Question…">${esc(q.q||'')}</textarea><textarea class="q-a" rows="2" placeholder="Correction / réponse attendue…">${esc(q.corrige||'')}</textarea>`;
   wrap.querySelector('.mini-del').onclick=()=>{wrap.remove();renumberQuestions(holder);};holder.appendChild(wrap);
 });
 renumberQuestions(holder);
}
async function handleImport(kind,e){
 const file=e.target.files?.[0];if(!file)return;e.target.value='';setStatus(kind,'⏳ Lecture du fichier et détection des questions…',false);
 try{
   const ext=(file.name.split('.').pop()||'').toLowerCase();const raw=cleanImportedSource(await readAnyEditorFile(file),ext);if(!raw)throw new Error('Aucun texte exploitable trouvé.');
   const d=splitImportedContent(raw);
   if(kind==='theme'){
     setVal('edTitle',d.titre.replace(/^titre\s*[:\-]\s*/i,''));setVal('edType',d.typeTexte);setVal('edDesc',d.texte.slice(0,700));
     const root=document.querySelector('.editor-form');
     if(root){root.dataset.importedThemePayload=JSON.stringify({titre:d.titre,texte:d.texte,questions:d.questions});}
     setStatus(kind,`✓ ${file.name} importé : texte détecté${d.questions.length?' + '+d.questions.length+' question(s) détectée(s)':''}. Le contenu est prêt à être enregistré dans S1.`,true);
   }else if(kind==='lesson'){
     setVal('edLTitle',d.titre);setVal('edLIntro',d.texte||'');
     if(document.getElementById('edTextGlobal')){setVal('edTextTitle',d.titre);setVal('edTextGlobal',d.texte);applyQuestionsToEditor('textquestions',d.questions.map(q=>({q,corrige:''})))}
     if(d.consigne)setVal('edLDesc',d.consigne);
     setStatus(kind,`✓ ${file.name} importé : ${d.texte?'texte détecté':''}${d.questions.length?' + '+d.questions.length+' question(s) détectée(s)':''}.`,true);
   }else{
     setVal('edOTitre',d.titre);setVal('edOConsigne',d.consigne||'Répondez aux questions suivantes.');applyQuestionsToEditor('exoquestions',d.questions.map(q=>({q,corrige:''})));
     if(!d.questions.length)applyQuestionsToEditor('exoquestions',[{q:d.texte?d.texte:'Question à compléter',corrige:''}]);
     setStatus(kind,`✓ ${file.name} importé : ${d.texte?'texte détecté':''}${d.questions.length?' + '+d.questions.length+' question(s) détectée(s)':''}.`,true);
   }
 }catch(err){setStatus(kind,'⚠️ '+(err.message||'Impossible de lire ce fichier.'),false);}
}
const __oldSaveTheme=window.saveThemeEditor;
window.saveThemeEditor=function(){
 const root=document.querySelector('.editor-form');let payload=null;try{payload=root?.dataset.importedThemePayload?JSON.parse(root.dataset.importedThemePayload):null;}catch(e){}
 if(!payload){return __oldSaveTheme.apply(this,arguments);}
 const pid=$('#edPid')?.value, selected=$('#edTid')?.value;
 // Pour un nouveau thème, créer d'abord le thème avec les données importées sans toucher aux autres fonctions.
 if(selected==='__new'){
   if(!editorConfirm('Enregistrer les modifications de ce thème avec le contenu importé ?'))return;
   const p=P[pid],title=$('#edTitle').value.trim();if(!p||!title){setEditorStatus('Le titre du thème est obligatoire.',false);return;}
   let base=slugify(title)||('theme_'+Date.now()),id=base,n=2;while(p.themes.some(t=>t.id===id))id=base+'_'+n++;
   const t={id,titre:title,desc:$('#edDesc').value.trim(),type:$('#edType').value.trim()||'Français',v:$('#edValue').value.trim()||'',semaines:[newWeek(1,title)],texte:{titre:payload.titre||'Texte de base',contenu:payload.texte?[payload.texte]:[]},questions:(payload.questions||[]).map(q=>({q,corrige:''})),exos:[]};
   p.themes.push(t);
   if(saveEditorData()){setEditorStatus('✓ Thème et contenu importé enregistrés dans S1.',true);setTimeout(()=>{closeEditor();refreshCurrentView();},400);}
   return;
 }
 const p=P[pid],t=p?.themes?.find(x=>x.id===selected);
 if(t){t.texte=t.texte||{titre:'Texte de base',contenu:[]};t.texte.titre=payload.titre||t.texte.titre||'Texte de base';t.texte.contenu=payload.texte?[payload.texte]:[];t.questions=(payload.questions||[]).map(q=>({q,corrige:''}));}
 return __oldSaveTheme.apply(this,arguments);
};
function installEditorImport(kind,oldFn){
 return function(box){oldFn.call(this,box);mountImport(kind);};
}
if(typeof __oldTheme==='function')window.renderEditorTheme=installEditorImport('theme',__oldTheme);
if(typeof __oldLesson==='function')window.renderEditorLesson=installEditorImport('lesson',__oldLesson);
if(typeof __oldExo==='function')window.renderEditorExo=installEditorImport('exo',__oldExo);
// Détection améliorée des sujets types : réutilisée aussi pour les imports généraux.
const __oldDetect=window.detectSujetParts;
window.detectSujetParts=function(raw){
 const d=splitImportedContent(raw);
 return {titre:d.titre,typeTexte:d.typeTexte,texte:d.texte,questions:d.questions.map(q=>({question:q,correction:''})),consigne:d.consigne||''};
};
})();
(function(){
'use strict';
function v9Norm(s){return String(s||'').replace(/\r/g,'').replace(/[ \t]+/g,' ').trim();}
function v9Lines(raw){return String(raw||'').replace(/\r/g,'').split('\n').map(v9Norm).filter(Boolean).filter(x=>!/^page\s*\d+(?:\s*\/\s*\d+)?$/i.test(x));}
function v9IsTitle(l){return /^(?:titre|title)\s*[:\-]/i.test(l)||/^[A-ZÀÂÇÉÈÊËÎÏÔÛÙÜŸ][^.!?]{2,100}$/.test(l)&&l.length<110;}
function v9IsSub(l){return /^(?:sous[- ]?titre|sous[- ]?titre|chapitre|partie|section|I{1,4}[.)]|[A-Z]\.)\s*/i.test(l)||/^\d{1,2}[.)]\s+[^?]{3,100}$/.test(l);}
function v9IsExample(l){return /^(?:exemple|exemples|ex\.|illustration|cas concret|modèle|modele)\s*[:\-]/i.test(l)||/\b(?:par exemple|ainsi|exemple)\s*:/i.test(l);}
function v9StripLabel(l,re){return l.replace(re,'').trim();}
function v9DetectLesson(raw){
 const lines=v9Lines(raw);let title='',subs=[],examples=[],body=[];
 for(let i=0;i<lines.length;i++){
  const l=lines[i];
  if(!title && /^(?:titre|title)\s*[:\-]/i.test(l)){title=v9StripLabel(l,/^(?:titre|title)\s*[:\-]\s*/i);continue;}
  if(!title && v9IsTitle(l)&&!v9IsSub(l)&&!v9IsExample(l)&&!/[?？]$/.test(l)){title=l;continue;}
  if(v9IsExample(l)){let ex=v9StripLabel(l,/^(?:exemple|exemples|ex\.|illustration|cas concret|modèle|modele)\s*[:\-]?\s*/i);if(ex)examples.push(ex);continue;}
  if(v9IsSub(l)){let x=v9StripLabel(l,/^(?:sous[- ]?titre|chapitre|partie|section)\s*[:\-]?\s*/i);if(x)subs.push(x);continue;}
  body.push(l);
 }
 // Une ligne courte en tête peut être un sous-titre plutôt qu'un paragraphe.
 if(title && body.length && body[0].length<90 && !/[.!?]$/.test(body[0])) subs.unshift(body.shift());
 subs=[...new Set(subs)];examples=[...new Set(examples)];
 return {title:title||'Leçon importée',subtitles:subs,examples,body:body.join('\n\n')};
}
function v9AnswerLabel(l){return /^(?:réponse|reponse|corrigé|corrige|correction|solution|réponses|reponses)\s*[:\-]/i.test(l);}
function v9QuestionStart(l){return /^(?:(?:item|question|quest|q)\s*\d{0,3}\s*[:.)-]?|\d{1,3}\s*[.)-]|[a-zàâçéèêëîïôûùüÿñæœ]\s*[.)-])\s*/i.test(l)||/^(?:qui|que|qu'|quoi|quel(?:le|s)?|où|quand|comment|pourquoi|combien|lequel|laquelle|lesquels|lesquelles|citez|relevez|identifiez|expliquez|justifiez|donnez|indiquez|précisez|montrez|transformez|complétez|classez|dites|comparez|analysez|caractérisez|repérez)\b/i.test(l)||/[?？]\s*$/.test(l);}
function v9StripQ(l){return l.replace(/^(?:(?:item|question|quest|q)\s*\d{0,3}\s*[:.)-]?|\d{1,3}\s*[.)-]|[a-zàâçéèêëîïôûùüÿñæœ]\s*[.)-])\s*/i,'').trim();}
function v9DetectExercises(raw){
 const lines=v9Lines(raw),out=[];let q=null,answerMode=false;
 const push=()=>{if(q&&q.q){q.q=v9Norm(q.q);q.corrige=v9Norm(q.corrige||'');if(!out.some(x=>x.q.toLowerCase()===q.q.toLowerCase()))out.push(q);}q=null;answerMode=false;};
 for(const l of lines){
  if(v9AnswerLabel(l)){if(q){const a=l.replace(/^(?:réponse|reponse|corrigé|corrige|correction|solution|réponses|reponses)\s*[:\-]\s*/i,'').trim();if(a)q.corrige=a;answerMode=true;}continue;}
  if(v9QuestionStart(l)){
   const stripped=v9StripQ(l);
   // Une ligne se terminant par ? est une question; un numéro peut aussi introduire une question.
   if(q && (/[?？]$/.test(q.q)||answerMode)) push();
   if(!q) q={q:stripped,corrige:''};
   else if(!answerMode) q.q+=' '+stripped;
   continue;
  }
  if(q){if(answerMode)q.corrige+=' '+l;else if(/[?？]$/.test(q.q))q.corrige+=' '+l;else q.q+=' '+l;}
 }
 push();
 // Deuxième passe : blocs "Question :" puis "Réponse :" et corrections numérotées.
 if(!out.length){
  let cur=null;for(const l of lines){
   if(/^(?:question|q)\s*[:\-]/i.test(l)){if(cur)out.push(cur);cur={q:l.replace(/^(?:question|q)\s*[:\-]\s*/i,''),corrige:''};}
   else if(cur&&v9AnswerLabel(l))cur.corrige=l.replace(/^(?:réponse|reponse|corrigé|corrige|correction|solution|réponses|reponses)\s*[:\-]\s*/i,'');
   else if(cur)cur.corrige+=(cur.corrige?' ':'')+l;
  }if(cur)out.push(cur);
 }
 return out;
}
function v9ShowLessonDetected(d){
 const old=document.getElementById('v9LessonDetected');if(old)old.remove();
 const target=document.getElementById('lessonFields');if(!target)return;
 const card=document.createElement('div');card.id='v9LessonDetected';card.className='editor-detect-card';
 card.innerHTML='<h4>🔎 Éléments détectés automatiquement</h4><div class="editor-detect-grid"><div class="editor-detect-item"><b>Titre</b>'+esc(d.title)+'</div><div class="editor-detect-item"><b>Sous-titres</b>'+(d.subtitles.length?d.subtitles.map(esc).join(' • '):'Aucun détecté')+'</div><div class="editor-detect-item"><b>Exemples</b>'+(d.examples.length?d.examples.map(esc).join(' • '):'Aucun libellé « Exemple » détecté')+'</div></div><div class="editor-detect-actions"><button type="button" class="editor-detect-btn" id="v9ApplyLessonDetected">✓ Appliquer au formulaire</button></div>';
 target.insertBefore(card,target.firstChild);
 document.getElementById('v9ApplyLessonDetected').onclick=()=>{
   setVal('edLTitle',d.title);
   if(d.body)setVal('edLIntro',d.body);
   const list=document.getElementById('lpoints');if(list){list.innerHTML='';d.subtitles.forEach(x=>{const row=document.createElement('div');row.className='simple-row';row.innerHTML='<textarea rows="2" placeholder="Point clé…">'+esc(x)+'</textarea><button type="button" class="mini-del">−</button>';list.appendChild(row);});if(typeof bindSimpleRows==='function')bindSimpleRows('lpoints');}
   if(d.examples.length){const ex='Exemples :\n'+d.examples.map(x=>'• '+x).join('\n');const cur=document.getElementById('edLMs');if(cur)cur.value=(cur.value?cur.value+'\n\n':'')+ex;}
 };
}
// Remplace seulement le lecteur d'import V8 : les autres fonctions restent intactes.
const oldHandleImport=window.handleImport;
window.handleImport=async function(kind,e){
 const file=e.target.files?.[0];if(!file)return;e.target.value='';setStatus(kind,'⏳ Analyse du fichier…',false);
 try{
  const ext=(file.name.split('.').pop()||'').toLowerCase();const raw=cleanImportedSource(await readAnyEditorFile(file),ext);if(!raw)throw new Error('Aucun texte exploitable trouvé.');
  if(kind==='lesson'){
   const d=v9DetectLesson(raw);setVal('edLTitle',d.title);if(d.body)setVal('edLIntro',d.body);
   if(document.getElementById('edTextGlobal')){setVal('edTextTitle',d.title);setVal('edTextGlobal',d.body);const qs=detectQuestionsAdvanced(raw).map(q=>({q,corrige:''}));applyQuestionsToEditor('textquestions',qs);}
   v9ShowLessonDetected(d);setStatus(kind,`✓ ${file.name} : titre + ${d.subtitles.length} sous-titre(s) + ${d.examples.length} exemple(s) détectés.`,true);return;
  }
  if(kind==='exo'){
   const d=splitImportedContent(raw),qs=v9DetectExercises(raw);setVal('edOTitre',d.titre);setVal('edOConsigne',d.consigne||'Répondez aux questions suivantes.');applyQuestionsToEditor('exoquestions',qs.length?qs:d.questions.map(q=>({q,corrige:''})));setStatus(kind,`✓ ${file.name} : ${qs.length||d.questions.length} question(s) avec réponses/corrections détectées.`,true);return;
  }
  return oldHandleImport.call(this,kind,{target:{files:[file]}});
 }catch(err){setStatus(kind,'⚠️ '+(err.message||'Impossible de lire ce fichier.'),false);}
};
// Ajoute un bouton Enregistrer à chaque question importée/ajoutée, sans supprimer le bouton Supprimer.
const oldApply=window.applyQuestionsToEditor;
window.applyQuestionsToEditor=function(prefix,qs){
 oldApply(prefix,qs);const holder=document.getElementById(prefix);if(!holder)return;
 holder.querySelectorAll('.q-card').forEach(card=>{
  const del=card.querySelector('.mini-del');if(!del||card.querySelector('.mini-save'))return;
  const b=document.createElement('button');b.type='button';b.className='mini-save';b.textContent='✓ Enregistrer';
  b.onclick=()=>{const q=card.querySelector('.q-q')?.value.trim(),a=card.querySelector('.q-a')?.value.trim();if(!q){card.querySelector('.q-q')?.focus();return;}card.classList.add('q-saved');setTimeout(()=>card.classList.remove('q-saved'),700);if(a)card.dataset.correction=a;};
  del.parentElement.insertBefore(b,del);
 });
};
})();
(function(){
  const oldRenderEditorTheme=window.renderEditorTheme;
  function contextDefaults(){
    const pid=Object.keys(P)[0]||''; const tid=P[pid]?.themes?.[0]?.id||''; return {pid,tid,si:0};
  }
  function renderStandaloneLesson(box){
    const d=contextDefaults();
    box.innerHTML=`<div class="editor-form"><div class="editor-standalone-head">
      <div class="editor-field"><label>Période</label><select id="edLPid2">${editorPeriodOptions(d.pid)}</select></div>
      <div class="editor-field"><label>Thème</label><select id="edLTid2">${editorThemeOptions(d.pid,d.tid)}</select></div>
      <div class="editor-field"><label>Leçon / semaine</label><select id="edLSi2"><option value="__new">＋ Nouvelle leçon</option></select></div>
    </div><input type="hidden" id="edLPid"><input type="hidden" id="edLTid"><select id="edLSi" style="display:none"></select><div id="lessonFields"></div><div class="editor-status" id="edStatus"></div></div>`;
    const syncWeeks=()=>{const pid=$('#edLPid2').value,tid=$('#edLTid2').value,t=P[pid]?.themes.find(x=>x.id===tid);$('#edLPid').value=pid;$('#edLTid').value=tid;$('#edLSi2').innerHTML='<option value="__new">＋ Nouvelle leçon</option>'+editorWeekOptions(pid,tid,'0');$('#edLSi').innerHTML=$('#edLSi2').innerHTML;$('#edLSi').value=$('#edLSi2').value;renderEditorLesson($('#editorForm'))};
    $('#edLPid2').onchange=()=>{$('#edLTid2').innerHTML=editorThemeOptions($('#edLPid2').value,'');syncWeeks()};
    $('#edLTid2').onchange=syncWeeks;$('#edLSi2').onchange=()=>{$('#edLSi').value=$('#edLSi2').value;renderEditorLesson($('#editorForm'))};syncWeeks();
  }
  function renderStandaloneExo(box){
    const d=contextDefaults();
    box.innerHTML=`<div class="editor-form"><div class="editor-standalone-head">
      <div class="editor-field"><label>Période</label><select id="edEPid2">${editorPeriodOptions(d.pid)}</select></div>
      <div class="editor-field"><label>Thème</label><select id="edETid2">${editorThemeOptions(d.pid,d.tid)}</select></div>
      <div class="editor-field"><label>Semaine</label><select id="edESi2"></select></div>
      <div class="editor-field"><label>Exercice</label><select id="edEi2"></select></div>
    </div><input type="hidden" id="edEPid"><input type="hidden" id="edETid"><input type="hidden" id="edESi"><select id="edEi" style="display:none"></select><div id="exoFields"></div><div class="editor-status" id="edStatus"></div></div>`;
    const syncWeeks=()=>{const pid=$('#edEPid2').value,tid=$('#edETid2').value,t=P[pid]?.themes.find(x=>x.id===tid);$('#edEPid').value=pid;$('#edETid').value=tid;$('#edESi2').innerHTML=editorWeekOptions(pid,tid,'0');$('#edESi').value=$('#edESi2').value;$('#edEi2').innerHTML='';refreshExoList();$('#edEi2').innerHTML=$('#edEi').innerHTML;$('#edEi2').value=$('#edEi').value;renderEditorExo($('#editorForm'))};
    $('#edEPid2').onchange=()=>{$('#edETid2').innerHTML=editorThemeOptions($('#edEPid2').value,'');syncWeeks()};$('#edETid2').onchange=syncWeeks;
    $('#edESi2').onchange=()=>{$('#edESi').value=$('#edESi2').value;refreshExoList();$('#edEi2').innerHTML=$('#edEi').innerHTML;$('#edEi2').value=$('#edEi').value;renderEditorExo($('#editorForm'))};
    $('#edEi2').onchange=()=>{$('#edEi').value=$('#edEi2').value;renderEditorExo($('#editorForm'))};syncWeeks();
  }
  window.renderEditor=function(){
    $$('.editor-tab').forEach(b=>b.classList.toggle('active',b.dataset.editorTab===editorTab));
    const box=$('#editorForm');
    if(editorTab==='sujet')return renderEditorSujet(box);
    if(editorTab==='lesson')return renderStandaloneLesson(box);
    if(editorTab==='exo')return renderStandaloneExo(box);
    oldRenderEditorTheme(box);
  };
  // When the theme tab changes, keep only theme-level editing visible.
})();
(function(){'use strict';
function openDirect(tab){if(typeof window.openEditor==='function'){window.openEditor(tab);}}
function install(){
 let plus=document.getElementById('targetFloatPlus')||document.getElementById('ctxAdd')||document.getElementById('globalAddContent');
 if(!plus)return;
 plus.onclick=function(){
  let old=document.getElementById('pageAddMenu');if(old){old.remove();return;}
  let m=document.createElement('div');m.id='pageAddMenu';m.style.display='flex';
  [['theme','＋ Ajouter thème','theme'],['week','＋ Ajouter semaine','lesson'],['lesson','＋ Ajouter leçon','lesson'],['exo','＋ Ajouter exercice','exo']].forEach(function(a){
   let b=document.createElement('button');b.type='button';b.textContent=a[1];b.onclick=function(){m.remove();openDirect(a[2]);};m.appendChild(b);
  });
  document.body.appendChild(m);
 };
}
window.addEventListener('load',function(){setTimeout(install,200)});
})();
(function(){
'use strict';
function f3EnsureFloating(){
  if(document.getElementById('f3FloatingAdd'))return;
  const b=document.createElement('button');b.id='f3FloatingAdd';b.type='button';b.textContent='＋';b.title='Ajouter';b.setAttribute('aria-label','Ajouter');
  const m=document.createElement('div');m.id='f3FloatingChoices';
  document.body.appendChild(m);document.body.appendChild(b);
  b.addEventListener('click',function(e){e.stopPropagation();m.classList.toggle('on');f3RenderChoices();});
  document.addEventListener('click',function(e){if(!m.contains(e.target)&&e.target!==b)m.classList.remove('on');});
}
function f3RenderChoices(){
  const m=document.getElementById('f3FloatingChoices');if(!m)return;
  m.innerHTML='';
  const choices=[
    ['theme','📚  Ajouter un thème'],
    ['week','📅  Ajouter une semaine'],
    ['lesson','📖  Ajouter une leçon'],
    ['exo','✏️  Ajouter un exercice']
  ];
  choices.forEach(function(item){
    const x=document.createElement('button');x.type='button';x.textContent=item[1];
    x.addEventListener('click',function(e){e.stopPropagation();m.classList.remove('on');f3OpenAdd(item[0]);});m.appendChild(x);
  });
}
function f3OpenAdd(type){
  if(typeof openEditor!=='function')return;
  if(type==='theme')openEditor('theme');
  else if(type==='lesson')openEditor('lesson');
  else if(type==='exo')openEditor('exo');
  else if(type==='week'){
    openEditor('lesson');
    setTimeout(function(){
      const s=document.getElementById('edLSi2')||document.getElementById('edLSi');
      if(s){s.value='__new';s.dispatchEvent(new Event('change'));}
    },80);
  }
}
function f3RefreshFloating(){
  f3EnsureFloating();
  const b=document.getElementById('f3FloatingAdd');
  if(b)b.style.display=(window.S&&S.view==='editor')?'none':'block';
}
window.addEventListener('load',function(){setTimeout(f3RefreshFloating,250);});
document.addEventListener('DOMContentLoaded',function(){setTimeout(f3RefreshFloating,250);});
})();
(function(){'use strict';
function lastContext(){
  const h=(window.S&&Array.isArray(S.hist)&&S.hist.length)?S.hist[S.hist.length-1]:{};
  return {v:h.v||'',pid:h.pid||'',tid:h.tid||'',si:(h.si!==undefined?h.si:null)};
}
function selectValue(id,value){
  const el=document.getElementById(id);if(!el||value===null||value===undefined||value==='')return false;
  el.value=String(value);el.dispatchEvent(new Event('change',{bubbles:true}));return true;
}
function focusExact(type){
  const c=lastContext();
  if(typeof window.openEditor!=='function')return;
  const tab=type==='theme'?'theme':'lesson';
  window.openEditor(tab);
  setTimeout(function(){
    if(type==='theme'){
      selectValue('edPid',c.pid);
      setTimeout(function(){selectValue('edTid',c.tid)},30);
      return;
    }
    // Une semaine/une leçon doit être créée ou modifiée dans LE THÈME ET LA SEMAINE consultés.
    selectValue('edLPid',c.pid);
    setTimeout(function(){
      selectValue('edLTid',c.tid);
      setTimeout(function(){
        if(c.si!==null){selectValue('edLSi',c.si);}
        else selectValue('edLSi','__new');
        setTimeout(function(){
          if(typeof window.renderEditorLesson==='function')window.renderEditorLesson();
        },30);
      },30);
    },30);
  },60);
}
function focusExactExercise(){
  const c=lastContext();if(typeof window.openEditor!=='function')return;
  window.openEditor('exo');
  setTimeout(function(){
    selectValue('edEPid',c.pid);
    setTimeout(function(){
      selectValue('edETid',c.tid);
      setTimeout(function(){
        if(c.si!==null)selectValue('edESi',c.si);
        setTimeout(function(){
          const ei=document.getElementById('edEi');
          if(ei){
            // Toujours positionner sur « Nouvel exercice » dans la semaine exacte consultée.
            ei.value='__new_morphosyntaxe';
            ei.dispatchEvent(new Event('change',{bubbles:true}));
          }
          if(typeof window.renderEditorExo==='function')window.renderEditorExo();
        },50);
      },40);
    },40);
  },60);
}
function openExact(type){
  if(type==='exo'){focusExactExercise();return;}
  if(type==='week'){
    // « Ajouter semaine » = onglet Leçon, nouvelle semaine dans le thème actuellement consulté.
    const c=lastContext();
    if(typeof window.openEditor!=='function')return;
    window.openEditor('lesson');
    setTimeout(function(){
      selectValue('edLPid',c.pid);
      setTimeout(function(){
        selectValue('edLTid',c.tid);
        setTimeout(function(){
          selectValue('edLSi','__new');
          if(typeof window.renderEditorLesson==='function')window.renderEditorLesson();
        },40);
      },40);
    },60);
    return;
  }
  focusExact(type);
}
function installExactMenu(){
  let plus=document.getElementById('f3FloatingAdd')||document.getElementById('ctxAdd')||document.getElementById('contextualAddBtn')||document.getElementById('globalAddContent');
  if(!plus||plus.__exactPoint)return;
  plus.__exactPoint=true;
  plus.onclick=function(e){
    e.preventDefault();e.stopPropagation();
    let old=document.getElementById('exactAddMenu');
    if(old){old.remove();return;}
    const m=document.createElement('div');m.id='exactAddMenu';m.style.display='flex';
    const c=lastContext();
    const title=c.tid?' dans le thème sélectionné':'';
    [['theme','📚 Ajouter un thème','theme'],['week','📅 Ajouter une semaine'+title,'week'],['lesson','📖 Ajouter une leçon'+(c.si!==null?' dans cette semaine':''),'lesson'],['exo','✏️ Ajouter un exercice'+(c.si!==null?' dans cette semaine':''),'exo']].forEach(function(a){
      const b=document.createElement('button');b.type='button';b.textContent=a[1];b.onclick=function(ev){ev.preventDefault();ev.stopPropagation();m.remove();openExact(a[2]);};m.appendChild(b);
    });
    document.body.appendChild(m);
  };
}
window.addEventListener('load',function(){setTimeout(installExactMenu,500)});
document.addEventListener('click',function(e){const m=document.getElementById('exactAddMenu');if(m&&!m.contains(e.target)&&!e.target.closest('#f3FloatingAdd,#ctxAdd,#contextualAddBtn,#globalAddContent'))m.remove()});
})();
(function(){
'use strict';
function v10Esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function v10BasePrompt(kind){
 const base=(PROMPT_TEMPLATES&&PROMPT_TEMPLATES[kind])?PROMPT_TEMPLATES[kind]:'';
 return String(base).replace(/\[ÉCRIVEZ ICI[\s\S]*?\]/gi,'').replace(/\[ÉCRIVEZ ICI LA NOTION[\s\S]*?\]/gi,'').trim();
}
function v10Options(kind){
 if(kind==='theme')return `
  <div class="editor-field"><label>Type de thème</label><select data-v10="type"><option>Explicatif</option><option>Narratif</option><option>Argumentatif</option><option>Administratif</option></select></div>
  <div class="editor-field"><label>Nombre de semaines</label><select data-v10="weeks"><option>1</option><option>2</option><option selected>3</option><option>4</option></select></div>
  <div class="editor-field"><label>Support principal</label><select data-v10="support"><option>Texte documentaire</option><option>Récit</option><option>Article d’opinion</option><option>Reportage</option><option>Autre</option></select></div>
  <div class="editor-field"><label>Exigence</label><select data-v10="detail"><option>Simple et clair</option><option selected>Complet et progressif</option><option>Très détaillé</option></select></div>`;
 if(kind==='lesson')return `
  <div class="editor-field"><label>Catégorie</label><select data-v10="category"><option selected>Morphosyntaxe</option><option>Lexique</option></select></div>
  <div class="editor-field"><label>Nombre de leçons</label><select data-v10="count"><option>1</option><option>2</option><option selected>3</option></select></div>
  <div class="editor-field"><label>Niveau</label><select data-v10="level"><option>Révision</option><option selected>3ème collège</option><option>Approfondissement</option></select></div>
  <div class="editor-field"><label>Présentation</label><select data-v10="presentation"><option selected>Règle + exemples + remarques</option><option>Cours très synthétique</option><option>Cours détaillé et progressif</option></select></div>`;
 return `
  <div class="editor-field"><label>Catégorie</label><select data-v10="category"><option selected>Morphosyntaxe</option><option>Lexique</option></select></div>
  <div class="editor-field"><label>Type d’exercice</label><select data-v10="exercise"><option>Questions ouvertes</option><option>À compléter</option><option>Relier</option><option>Tableau</option><option>Classement</option><option>Transformation</option><option>Justification</option><option>QCM</option></select></div>
  <div class="editor-field"><label>Nombre de questions</label><select data-v10="number"><option>5</option><option selected>10</option><option>15</option><option>20</option></select></div>
  <div class="editor-field"><label>Difficulté</label><select data-v10="difficulty"><option>Progressive</option><option selected>Progressive : facile → moyen → difficile</option><option>Approfondissement</option></select></div>
  <div class="editor-field"><label>Correction</label><select data-v10="correction"><option selected>Correction complète</option><option>Réponse attendue courte</option><option>Correction détaillée et expliquée</option></select></div>
  <div class="editor-field"><label>Consignes</label><select data-v10="instruction"><option selected>2ème personne du pluriel</option><option>Consignes courtes</option><option>Consignes détaillées</option></select></div>
  <div class="editor-field"><label>Semaine</label><select data-v10="week"><option>Semaine actuelle</option></select></div>`;
}
function v10BuildPrompt(kind,root){
 const get=k=>root.querySelector(`[data-v10="${k}"]`)?.value||'';
 const title=kind==='theme'?($('#edTitle')?.value||'Nouveau thème'):kind==='lesson'?($('#edLTitle')?.value||'Nouvelle leçon'):($('#edOTitre')?.value||'Nouvel exercice');
 const context=kind==='theme'?`THÈME : ${title}\nType : ${get('type')}\nSemaines : ${get('weeks')}\nSupport : ${get('support')}\nNiveau de détail : ${get('detail')}`:
   kind==='lesson'?`LEÇON : ${title}\nCatégorie : ${get('category')}\nNombre de leçons à détecter/créer si nécessaire : ${get('count')}\nNiveau : ${get('level')}\nPrésentation : ${get('presentation')}`:
   `EXERCICE : ${title}\nSemaine : ${get('week')||'Semaine actuelle'}\nCatégorie : ${get('category')}\nType : ${get('exercise')}\nNombre de questions : ${get('number')}\nDifficulté : ${get('difficulty')}\nCorrection : ${get('correction')}\nConsignes : ${get('instruction')}`;
 const extra=root.querySelector('[data-v10="extra"]')?.value||'';
 return v10BasePrompt(kind)+'\n\n================ DEMANDE À TRAITER ================\n'+context+'\nExigences supplémentaires : '+(extra||'Respectez toutes les exigences de l’application.')+'\n\nRetournez uniquement le fichier HTML complet.';
}
function v10Html(kind){
 const labels={theme:['📚','HTML du thème','Ajouter un nouveau thème'],lesson:['📖','HTML de la leçon','Ajouter une nouvelle leçon'],exo:['✏️','HTML de l’exercice','Ajouter un nouvel exercice']}[kind];
 return `<div class="v10-prompt-card" data-v10-root="${kind}">
   <div class="v10-prompt-head"><span class="v10-icon">${labels[0]}</span> Assistant IA — prompt prêt à copier</div>
   <p class="v10-help">Choisissez les exigences dans les menus. Le prompt ci-dessous est construit automatiquement pour être copié dans ChatGPT, DeepSeek ou un autre assistant.</p>
   <div class="v10-grid">${v10Options(kind)}</div>
   <div class="editor-field" style="margin-top:8px"><label>${kind==='lesson'?'Exigences de la leçon':'Exigences supplémentaires'}</label><textarea data-v10="extra" class="v10-prompt-text" style="min-height:75px" placeholder="${kind==='lesson'?'Ex. objectif de la semaine, points clés à couvrir, niveau de difficulté, lien avec le texte de base, etc.':'Ex. adapter au thème, éviter les répétitions, ajouter des exemples, respecter S1, etc.'}"></textarea></div>
   <textarea class="v10-prompt-text" data-v10="prompt" readonly></textarea>
   <div class="v10-actions"><button type="button" class="v10-copy" data-v10-action="copy">📋 Copier le prompt</button></div>
   <div class="v10-html-box">
     <div class="v10-html-title">📥 Code HTML généré par ChatGPT / DeepSeek</div>
     <div class="v10-html-help">Collez ici le code HTML complet obtenu ailleurs. Le bouton ci-dessous détecte les cadres reconnus et complète l’éditeur.</div>
     <textarea data-v10="html" placeholder="<!DOCTYPE html>\nCollez ici le code HTML complet…"></textarea>
     <div class="v10-actions">
       <button type="button" class="v10-add" data-v10-action="generate">⚡ Générer les cadres</button>
       <button type="button" class="v10-add" data-v10-action="add">＋ ${labels[2]}</button>
       <button type="button" class="v10-clear" data-v10-action="clear">Vider</button>
     </div>
     <div class="v10-status" data-v10="status"></div>
   </div>
 </div>`;
}
function v10Mount(kind,container){
 if(!container||container.querySelector(`[data-v10-root="${kind}"]`))return;
 const wrap=document.createElement('div');wrap.innerHTML=v10Html(kind);const node=wrap.firstElementChild;container.insertBefore(node,container.firstChild);
 if(kind==='exo'){
   const weekSel=node.querySelector('[data-v10="week"]');
   if(weekSel){
     const pid=$('#edEPid')?.value,tid=$('#edETid')?.value,si=$('#edESi')?.value;
     const opts=(pid&&tid&&si!==undefined&&si!=='__pending')?editorWeekOptions(pid,tid,si):'';
     weekSel.innerHTML=opts||'<option>Semaine actuelle</option>';
   }
 }
 const refresh=()=>{node.querySelector('[data-v10="prompt"]').value=v10BuildPrompt(kind,node);};
 node.querySelectorAll('select,[data-v10="extra"]').forEach(el=>el.addEventListener('input',refresh));
 node.querySelector('[data-v10-action="copy"]').onclick=()=>copyToClipboard(node.querySelector('[data-v10="prompt"]').value,node.querySelector('[data-v10-action="copy"]'));
 node.querySelector('[data-v10-action="generate"]').onclick=()=>{
   const raw=node.querySelector('[data-v10="html"]').value.trim();const st=node.querySelector('[data-v10="status"]');
   if(!raw){st.textContent='⚠️ Collez d’abord le code HTML généré.';st.className='v10-status err';return;}
   try{if(typeof fillEditorFramesFromGeneratedHTML!=='function')throw new Error('Le moteur de détection HTML est indisponible.');fillEditorFramesFromGeneratedHTML(kind,raw);st.textContent='✓ Les cadres reconnus ont été complétés automatiquement.';st.className='v10-status ok';}
   catch(e){st.textContent='⚠️ '+e.message;st.className='v10-status err';}
 };
 node.querySelector('[data-v10-action="clear"]').onclick=()=>{node.querySelector('[data-v10="html"]').value='';node.querySelector('[data-v10="status"]').textContent='';};
 node.querySelector('[data-v10-action="add"]').onclick=()=>v10Add(kind);
 refresh();
}
function v10Add(kind){
 try{
   if(kind==='theme'){
     const s=document.querySelector('#edTid');if(s){s.value='__new';s.dispatchEvent(new Event('change',{bubbles:true}));return;}
   }
   if(kind==='lesson'){
     const s=document.querySelector('#edLSi2')||document.querySelector('#edLSi');if(s){s.value='__new';s.dispatchEvent(new Event('change',{bubbles:true}));return;}
   }
   if(kind==='exo'){
     const s=document.querySelector('#edEi2')||document.querySelector('#edEi');if(s){s.value='__new_morphosyntaxe';s.dispatchEvent(new Event('change',{bubbles:true}));return;}
   }
 }catch(e){console.warn('Ajout V10:',e);}
}
function v10Wrap(kind,name,selector){
 const old=window[name];if(typeof old!=='function'||old.__v10Wrapped)return;
 function wrapped(box){old.call(this,box);const c=document.querySelector(selector);v10Mount(kind,c);}
 wrapped.__v10Wrapped=true;window[name]=wrapped;
}
function v10Install(){
 v10Wrap('theme','renderEditorTheme','#themeFields');
 v10Wrap('lesson','renderEditorLesson','#lessonFields');
 v10Wrap('exo','renderEditorExo','#exoFields');
 // Les éditeurs sont parfois rendus avant ce patch : monter aussi immédiatement si présents.
 v10Mount('theme',document.querySelector('#themeFields'));
 v10Mount('lesson',document.querySelector('#lessonFields'));
 v10Mount('exo',document.querySelector('#exoFields'));
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>setTimeout(v10Install,50));else setTimeout(v10Install,50);
window.addEventListener('load',()=>setTimeout(v10Install,100));
})();
