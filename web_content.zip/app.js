(() => {
  const STORAGE_KEY = "japan-quiz-save-v1";
  const AVATARS = ["🦊", "🐱", "🐼", "🐰", "🐯", "🐸", "🐻", "🐲"];
  const MODE_INFO = {
    classic: { title: "Classic", icon: "🎴", short: "10 questions. Build your streak.", count: 10 },
    endless: { title: "Endless", icon: "♾️", short: "Keep going. One mistake ends it.", count: 300 },
    time: { title: "Time Attack", icon: "⏱️", short: "How many can you answer in 60 sec?", count: 300 },
    daily: { title: "Daily Challenge", icon: "🌸", short: "A fresh set, every single day.", count: 10 },
    category: { title: "Category Challenge", icon: "🏮", short: "Go deep on a topic you love.", count: 10 },
    survival: { title: "Survival", icon: "🔥", short: "The questions get harder as you go.", count: 20 },
    mixed: { title: "Mixed Challenge", icon: "🎌", short: "A little bit of everything Japan.", count: 15 }
  };
  const ACHIEVEMENTS = [
    ["first-victory", "First Steps", "🎌", "Answer your first question correctly.", s => s.totalCorrect >= 1],
    ["curious-mind", "Curious Mind", "🧠", "Answer 25 questions correctly.", s => s.totalCorrect >= 25],
    ["century-club", "Century Club", "💯", "Answer 100 questions correctly.", s => s.totalCorrect >= 100],
    ["quiz-scholar", "Quiz Scholar", "📚", "Answer 300 questions correctly.", s => s.totalCorrect >= 300],
    ["japan-explorer", "Japan Explorer", "🗾", "Explore all 12 categories.", s => s.categoriesExplored.length >= 12],
    ["history-master", "History Master", "⛩️", "Get 20 Japanese history questions right.", s => (s.categoryCorrect.history || 0) >= 20],
    ["food-expert", "Food Expert", "🍜", "Get 20 Japanese food questions right.", s => (s.categoryCorrect.food || 0) >= 20],
    ["tech-pioneer", "Tech Pioneer", "🤖", "Get 20 technology questions right.", s => (s.categoryCorrect.technology || 0) >= 20],
    ["language-lover", "Language Lover", "あ", "Get 20 language questions right.", s => (s.categoryCorrect.language || 0) >= 20],
    ["place-collector", "Place Collector", "🗻", "Get 20 famous places questions right.", s => (s.categoryCorrect.places || 0) >= 20],
    ["culture-keeper", "Culture Keeper", "🎎", "Get 20 culture questions right.", s => (s.categoryCorrect.culture || 0) >= 20],
    ["festival-fan", "Festival Fan", "🏮", "Get 20 festival questions right.", s => (s.categoryCorrect.festivals || 0) >= 20],
    ["perfect-round", "Perfect Ten", "✨", "Finish a 10-question round with no mistakes.", s => s.perfectRounds >= 1],
    ["perfect-three", "Flawless Trio", "🌟", "Complete three perfect rounds.", s => s.perfectRounds >= 3],
    ["endless-champion", "Endless Champion", "♾️", "Answer 10 questions in Endless mode.", s => s.endlessBest >= 10],
    ["daily-devotee", "Daily Devotee", "🌅", "Complete 3 daily challenges.", s => s.dailyChallenges >= 3],
    ["week-of-wonders", "Week of Wonders", "📆", "Complete 7 daily challenges.", s => s.dailyChallenges >= 7],
    ["on-a-roll", "On a Roll", "🔥", "Reach a correct-answer streak of 5.", s => s.bestStreak >= 5],
    ["unstoppable", "Unstoppable", "⚡", "Reach a correct-answer streak of 10.", s => s.bestStreak >= 10],
    ["level-five", "Rising Sun", "🌄", "Reach level 5.", s => s.xp >= 2000],
    ["level-ten", "Tenno", "👑", "Reach level 10.", s => s.xp >= 4500],
    ["coin-purse", "Coin Purse", "🪙", "Collect 500 coins.", s => s.coins >= 500],
    ["game-night", "Game Night", "🎮", "Finish 10 games.", s => s.gamesPlayed >= 10],
    ["speed-demon", "Quick Thinker", "⏱️", "Answer 10 correctly in Time Attack.", s => s.timeAttackBest >= 10],
    ["last-one-standing", "Last One Standing", "🛡️", "Answer 15 correctly in Survival.", s => s.survivalBest >= 15],
    ["samurai-spirit", "Samurai Spirit", "⚔️", "Finish a game with a 10-answer streak.", s => s.gameStreakBest >= 10],
    ["tradition-bearer", "Tradition Bearer", "🎐", "Get 20 traditions questions right.", s => (s.categoryCorrect.traditions || 0) >= 20],
    ["sports-fan", "Sports Fan", "🥋", "Get 20 sports questions right.", s => (s.categoryCorrect.sports || 0) >= 20],
    ["anime-ace", "Anime Ace", "🎴", "Get 20 anime & manga questions right.", s => (s.categoryCorrect.anime || 0) >= 20],
    ["inventor", "Bright Idea", "💡", "Get 20 inventions questions right.", s => (s.categoryCorrect.inventions || 0) >= 20]
  ].map(([id, name, icon, description, unlocked]) => ({ id, name, icon, description, unlocked }));

  const DEFAULT_STATE = {
    username: "Sakura",
    avatar: AVATARS[0],
    xp: 0,
    coins: 120,
    streakDays: 0,
    lastVisit: "",
    lastDailyDate: "",
    totalAnswered: 0,
    totalCorrect: 0,
    gamesPlayed: 0,
    bestStreak: 0,
    categoriesExplored: [],
    categoryCorrect: {},
    unlockedAchievements: [],
    perfectRounds: 0,
    dailyChallenges: 0,
    endlessBest: 0,
    timeAttackBest: 0,
    survivalBest: 0,
    gameStreakBest: 0,
    bestScores: {},
    records: [],
    settings: { sound: true, music: false, dark: false, language: "en" }
  };

  function loadState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (!saved || typeof saved !== "object") return structuredClone(DEFAULT_STATE);
      return {
        ...structuredClone(DEFAULT_STATE),
        ...saved,
        settings: { ...DEFAULT_STATE.settings, ...(saved.settings || {}) },
        categoryCorrect: saved.categoryCorrect || {},
        categoriesExplored: Array.isArray(saved.categoriesExplored) ? saved.categoriesExplored : [],
        unlockedAchievements: Array.isArray(saved.unlockedAchievements) ? saved.unlockedAchievements : [],
        records: Array.isArray(saved.records) ? saved.records : [],
        bestScores: saved.bestScores || {}
      };
    } catch (error) {
      console.error("Could not read the saved Japan Quiz progress.", error);
      return structuredClone(DEFAULT_STATE);
    }
  }

  let state = loadState();
  let page = "home";
  let game = null;
  let timer = null;
  let leaderboardTab = "weekly";
  let audioContext = null;
  let musicNodes = [];
  let modal = "";
  const app = document.getElementById("app");
  const toastRegion = document.getElementById("toast-region");

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (error) {
      console.error("Could not save Japan Quiz progress.", error);
      showToast("Progress could not be saved. Check your device storage.");
    }
  }

  function todayKey() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
  }

  function visitReward() {
    const today = todayKey();
    if (state.lastVisit === today) return;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayKey = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(2, "0")}-${String(yesterday.getDate()).padStart(2, "0")}`;
    state.streakDays = state.lastVisit === yesterdayKey ? state.streakDays + 1 : 1;
    state.coins += 5;
    state.lastVisit = today;
    persist();
  }

  function level() { return Math.floor(state.xp / 500) + 1; }
  function xpInLevel() { return state.xp % 500; }
  function accuracy() { return state.totalAnswered ? Math.round((state.totalCorrect / state.totalAnswered) * 100) : 0; }
  function escapeHtml(text) {
    return String(text).replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
  }
  function shuffle(items) {
    const result = [...items];
    for (let i = result.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }
  function seededShuffle(items, seed) {
    let value = 0;
    for (const char of seed) value = (value * 31 + char.charCodeAt(0)) >>> 0;
    const result = [...items];
    for (let i = result.length - 1; i > 0; i--) {
      value = (value * 1664525 + 1013904223) >>> 0;
      const j = value % (i + 1);
      [result[i], result[j]] = [result[j], result[i]];
    }
    return result;
  }
  function showToast(message) {
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;
    toastRegion.appendChild(toast);
    window.setTimeout(() => toast.remove(), 2900);
  }
  function sound(correct) {
    if (!state.settings.sound) return;
    try {
      audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = "sine";
      oscillator.frequency.value = correct ? 660 : 190;
      gain.gain.setValueAtTime(0.0001, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(.12, audioContext.currentTime + .025);
      gain.gain.exponentialRampToValueAtTime(.0001, audioContext.currentTime + .23);
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start();
      oscillator.stop(audioContext.currentTime + .24);
    } catch (error) {
      console.warn("Audio playback is unavailable.", error);
    }
  }
  function toggleMusic(enabled) {
    state.settings.music = enabled;
    if (enabled) {
      try {
        audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
        const gain = audioContext.createGain();
        const oscA = audioContext.createOscillator();
        const oscB = audioContext.createOscillator();
        gain.gain.value = .008;
        oscA.type = "sine";
        oscB.type = "sine";
        oscA.frequency.value = 110;
        oscB.frequency.value = 164.81;
        oscA.connect(gain);
        oscB.connect(gain);
        gain.connect(audioContext.destination);
        oscA.start();
        oscB.start();
        musicNodes = [oscA, oscB, gain];
      } catch (error) {
        state.settings.music = false;
        console.error("Could not start background audio.", error);
        showToast("Background audio is unavailable on this device.");
      }
    } else {
      musicNodes.forEach(node => {
        try { node.stop?.(); } catch (error) { console.warn("Audio node was already stopped.", error); }
      });
      musicNodes = [];
    }
    persist();
    render();
  }
  function burst() {
    const symbols = ["🌸", "✦", "🌸", "✨", "🌸", "✦"];
    symbols.forEach(symbol => {
      const item = document.createElement("span");
      item.className = "petal-burst";
      item.textContent = symbol;
      item.style.left = `${42 + Math.random() * 18}%`;
      item.style.top = "48%";
      item.style.setProperty("--x", `${Math.random() * 210 - 105}px`);
      item.style.setProperty("--y", `${Math.random() * -200 - 30}px`);
      document.body.appendChild(item);
      window.setTimeout(() => item.remove(), 1300);
    });
  }
  function checkAchievements() {
    let unlockedNow = [];
    ACHIEVEMENTS.forEach(item => {
      if (!state.unlockedAchievements.includes(item.id) && item.unlocked(state)) {
        state.unlockedAchievements.push(item.id);
        unlockedNow.push(item);
      }
    });
    if (unlockedNow.length) {
      persist();
      unlockedNow.forEach((item, index) => window.setTimeout(() => {
        showToast(`${item.icon} Achievement unlocked: ${item.name}`);
        burst();
      }, index * 450));
    }
  }

  function topbar() {
    return `<header class="topbar">
      <div class="brand"><div class="brand-mark">🗻</div><div>JAPAN QUIZ<small>DISCOVER · LEARN · PLAY</small></div></div>
      <div class="top-actions"><div class="coin-pill">🪙 ${state.coins}</div><button class="icon-button" data-action="settings" aria-label="Settings">⚙️</button></div>
    </header>`;
  }
  const NAV = [
    ["home", "⌂", "Home"], ["categories", "🗾", "Explore"], ["challenges", "⚡", "Play"], ["achievements", "🏆", "Awards"], ["profile", "👤", "Profile"]
  ];
  function bottomNav() {
    return `<nav class="bottom-nav" aria-label="Main navigation">${NAV.map(([id, icon, label]) =>
      `<button class="nav-item ${page === id ? "active" : ""}" data-action="navigate" data-page="${id}"><span class="nav-icon">${icon}</span><span>${label}</span></button>`
    ).join("")}</nav>`;
  }
  function shell(content, options = {}) {
    return `<main class="screen">${topbar()}${content}</main>${options.noNav ? "" : bottomNav()}${modal ? modalHtml() : ""}`;
  }

  function mountFuji() {
    return `<svg class="hero-art" viewBox="0 0 360 225" aria-hidden="true">
      <circle cx="266" cy="70" r="32" fill="#fff7eb" opacity=".8"/>
      <path d="M25 214 159 48l19 24 11-13 147 155z" fill="#38415b"/>
      <path d="m125 89 34-41 19 24 11-13 34 39-34-18-11 13-21-19-20 23z" fill="#fff9f5"/>
      <path d="M13 212c40-10 57 8 96 0 38-9 68 8 104 0 45-10 77 9 132-2v15H13z" fill="#f3a5ae" opacity=".77"/>
      <path d="M0 224c51-13 82 7 125 0 44-7 93 9 137 0 38-8 71 4 98 0v11H0z" fill="#d98691" opacity=".55"/>
      <g fill="#c56a77"><circle cx="44" cy="122" r="4"/><circle cx="53" cy="116" r="3"/><circle cx="48" cy="109" r="3"/><circle cx="310" cy="125" r="4"/><circle cx="320" cy="118" r="3"/><circle cx="302" cy="116" r="3"/></g>
      <g stroke="#815f51" stroke-width="2"><path d="M47 135v36"/><path d="M311 139v29"/></g>
      <g fill="#eaa0aa"><circle cx="38" cy="135" r="13"/><circle cx="48" cy="126" r="15"/><circle cx="58" cy="136" r="13"/><circle cx="303" cy="139" r="13"/><circle cx="313" cy="130" r="14"/><circle cx="322" cy="139" r="12"/></g>
    </svg>`;
  }

  function homePage() {
    const xpPercent = (xpInLevel() / 500) * 100;
    const dailyDone = state.lastDailyDate === todayKey();
    return `<div class="home-intro"><div class="eyebrow">Konnichiwa, ${escapeHtml(state.username)} ${state.avatar}</div><p class="subtle">A little discovery goes a long way.</p></div>
      <section class="hero">
        <span class="petal"></span><span class="petal"></span><span class="petal"></span>
        <div class="hero-copy"><div class="hero-flag">🇯🇵 &nbsp; YOUR JAPAN JOURNEY</div><h1>Discover Japan.<br>One question at a time.</h1><p class="subtle">Explore the stories, flavors and traditions that make Japan unforgettable.</p><button class="btn" data-action="start" data-mode="classic">Continue playing <span>→</span></button></div>
        ${mountFuji()}
      </section>
      <div class="xp-card"><div class="level-badge">${level()}</div><div class="xp-copy"><strong>Level ${level()} · Rising Sun</strong><span>${xpInLevel()} / 500 XP to level ${level() + 1}</span><div class="progress-track"><div class="progress-fill" style="width:${xpPercent}%"></div></div></div><div style="font-size:21px">🌅</div></div>
      <div class="stats-row">
        <div class="stat-card"><div class="stat-icon">🔥</div><div class="stat-value">${state.streakDays}</div><div class="stat-label">DAY STREAK</div></div>
        <div class="stat-card"><div class="stat-icon">🎯</div><div class="stat-value">${accuracy()}%</div><div class="stat-label">ACCURACY</div></div>
        <div class="stat-card"><div class="stat-icon">🧠</div><div class="stat-value">${state.totalAnswered}</div><div class="stat-label">ANSWERED</div></div>
      </div>
      <div class="section-heading"><h2>Today’s discovery</h2><button class="text-button" data-action="navigate" data-page="challenges">All modes →</button></div>
      <section class="challenge-card"><div class="eyebrow">DAILY CHALLENGE ${dailyDone ? "· COMPLETE ✓" : "· +100 XP"}</div><h3>${dailyDone ? "Beautiful work today!" : "A new little adventure awaits."}</h3><p>${dailyDone ? "Your daily reward has been collected. Come back tomorrow for a fresh set." : "10 hand-picked questions, one special reward. Ready to explore?"}</p><button class="btn gold" data-action="start" data-mode="daily">${dailyDone ? "Play again" : "Start today’s challenge"} →</button></section>
      <div class="section-heading"><h2>Pick up & play</h2><button class="text-button" data-action="navigate" data-page="categories">Explore all →</button></div>
      <div class="mode-grid">
        ${modeCard("mixed", true)}${modeCard("time")}
      </div>`;
  }

  function modeCard(mode, featured = false) {
    const item = MODE_INFO[mode];
    return `<button class="mode-card ${featured ? "featured" : ""}" data-action="start" data-mode="${mode}"><div class="mode-icon">${item.icon}</div><strong>${item.title}</strong><span>${item.short}</span></button>`;
  }
  function titleBlock(title, subtitle) {
    return `<div class="screen-title"><div class="eyebrow">JAPAN QUIZ · ${title.toUpperCase()}</div><h1>${title}</h1><p class="subtle">${subtitle}</p></div>`;
  }
  function categoriesPage() {
    return `${titleBlock("Explore Japan", "Twelve fascinating paths. 300 questions. Where will you wander?")}
      <div class="daily-banner" style="margin-bottom:14px"><div class="category-icon">🗻</div><div><strong style="font-size:12px">Every category has 25 questions</strong><p>Learn a new fact with every answer.</p></div></div>
      <div class="category-list">${JAPAN_CATEGORIES.map(category => {
        const done = Math.min(25, state.categoryCorrect[category.id] || 0);
        return `<button class="category-card" data-action="category" data-category="${category.id}"><span class="category-icon ${category.tone}">${category.icon}</span><span class="category-meta"><strong>${category.name}</strong><span>${category.description}</span></span><span class="category-count">${done}/25 ✓ &nbsp;→</span></button>`;
      }).join("")}</div>`;
  }
  function challengesPage() {
    return `${titleBlock("Choose your adventure", "Seven ways to play. Pick the challenge that feels right.")}
      <div class="challenge-card" style="margin-bottom:15px"><div class="eyebrow">DAILY SPECIAL · REWARDS INSIDE</div><h3>${state.lastDailyDate === todayKey() ? "Your daily challenge is complete" : "A fresh challenge, every day."}</h3><p>Ten questions selected just for today. Earn bonus XP and coins when you finish.</p><button class="btn gold" data-action="start" data-mode="daily">Play daily challenge →</button></div>
      <div class="mode-grid">${Object.keys(MODE_INFO).filter(mode => mode !== "daily").map((mode, index) => modeCard(mode, index === 0)).join("")}</div>
      <div class="section-heading"><h2>Compete with yourself</h2><button class="text-button" data-action="leaderboard">Local scores →</button></div>
      <p class="subtle">Your leaderboard is saved on this device. No account or internet required.</p>`;
  }
  function achievementsPage() {
    const unlocked = state.unlockedAchievements.length;
    return `${titleBlock("Little victories", `${unlocked} of ${ACHIEVEMENTS.length} badges earned. Every new fact brings you closer.`)}
      <div class="xp-card" style="margin-bottom:14px"><div class="level-badge">🏆</div><div class="xp-copy"><strong>Your collection</strong><span>${unlocked} badges unlocked · ${ACHIEVEMENTS.length - unlocked} still to discover</span><div class="progress-track"><div class="progress-fill" style="width:${unlocked / ACHIEVEMENTS.length * 100}%"></div></div></div></div>
      <div class="achievement-grid">${ACHIEVEMENTS.map(item => {
        const has = state.unlockedAchievements.includes(item.id);
        return `<article class="achievement-card ${has ? "unlocked" : ""}"><span class="achievement-state">${has ? "EARNED ✓" : "LOCKED"}</span><div class="achievement-icon">${item.icon}</div><strong>${item.name}</strong><p>${item.description}</p></article>`;
      }).join("")}</div>`;
  }
  function profilePage() {
    const unlockedAvatars = Math.min(AVATARS.length, Math.max(2, Math.floor(level() / 2) + 2));
    const favorite = Object.entries(state.categoryCorrect).sort((a, b) => b[1] - a[1])[0];
    return `${titleBlock("Your journey", "Every answer is a little more of Japan to take with you.")}
      <section class="profile-hero"><div class="avatar">${state.avatar}</div><h2 style="margin:0 0 3px">${escapeHtml(state.username)}</h2><p class="subtle" style="margin-bottom:0">Level ${level()} · ${state.xp} total XP</p>
        <div class="avatar-options">${AVATARS.map((avatar, index) => `<button class="avatar-option ${state.avatar === avatar ? "selected" : ""} ${index >= unlockedAvatars ? "locked" : ""}" data-action="avatar" data-avatar="${avatar}" ${index >= unlockedAvatars ? "disabled title=\"Reach a higher level to unlock\"" : ""}>${index >= unlockedAvatars ? "🔒" : avatar}</button>`).join("")}</div>
        <button class="text-button" data-action="rename">Change username</button>
      </section>
      <div class="profile-stats">
        <div class="profile-stat"><strong>${state.coins} 🪙</strong><span>Coins collected</span></div>
        <div class="profile-stat"><strong>${state.gamesPlayed}</strong><span>Games completed</span></div>
        <div class="profile-stat"><strong>${state.totalAnswered}</strong><span>Questions answered</span></div>
        <div class="profile-stat"><strong>${accuracy()}%</strong><span>Answer accuracy</span></div>
      </div>
      <div class="panel"><h3>Player statistics</h3><div class="panel-row"><span>Correct answers</span><strong>${state.totalCorrect}</strong></div><div class="panel-row"><span>Best answer streak</span><strong>🔥 ${state.bestStreak}</strong></div><div class="panel-row"><span>Daily challenges</span><strong>${state.dailyChallenges}</strong></div><div class="panel-row"><span>Favorite category</span><strong>${favorite ? JAPAN_CATEGORIES.find(category => category.id === favorite[0])?.name || "—" : "Not yet discovered"}</strong></div><div class="panel-row"><span>Achievements</span><strong>${state.unlockedAchievements.length} / ${ACHIEVEMENTS.length}</strong></div></div>
      <button class="btn secondary full" data-action="leaderboard">🏅 &nbsp; View local leaderboard</button>
      <button class="btn secondary full" style="margin-top:9px" data-action="settings">⚙️ &nbsp; Settings</button>`;
  }
  function leaderboardPage() {
    const tabs = [["weekly", "This week"], ["monthly", "This month"], ["xp", "Total XP"], ["scores", "Best scores"]];
    let rows = [];
    if (leaderboardTab === "xp") {
      rows = state.xp ? [{ label: "Total experience", value: `${state.xp} XP`, detail: `Level ${level()}` }] : [];
    } else if (leaderboardTab === "scores") {
      rows = Object.entries(state.bestScores).map(([mode, score]) => ({ label: MODE_INFO[mode]?.title || mode, value: `${score} pts`, detail: "Personal best" })).sort((a, b) => parseInt(b.value, 10) - parseInt(a.value, 10));
    } else {
      const cutoff = new Date();
      if (leaderboardTab === "weekly") cutoff.setDate(cutoff.getDate() - 7);
      else cutoff.setDate(cutoff.getDate() - 30);
      rows = state.records.filter(record => new Date(record.date) >= cutoff)
        .sort((a, b) => b.score - a.score)
        .slice(0, 20)
        .map(record => ({ label: MODE_INFO[record.mode]?.title || "Quiz", value: `${record.score} pts`, detail: `${record.correct}/${record.answered} correct · ${new Date(record.date).toLocaleDateString()}` }));
    }
    return `${titleBlock("Your leaderboard", "Personal rankings saved locally on this device. No global or online scores.")}
      <div class="leader-tabs">${tabs.map(([id, label]) => `<button class="leader-tab ${leaderboardTab === id ? "active" : ""}" data-action="leader-tab" data-tab="${id}">${label}</button>`).join("")}</div>
      <section class="panel"><div style="display:flex;align-items:center;gap:8px;margin-bottom:5px"><span style="font-size:19px">🏅</span><strong style="font-size:13px">LOCAL RANKINGS</strong></div>
      ${rows.length ? rows.map((row, index) => `<div class="leader-row"><div class="rank">#${index + 1}</div><div class="leader-avatar">${state.avatar}</div><div class="leader-copy"><strong>${escapeHtml(row.label)}</strong><span>${escapeHtml(row.detail)}</span></div><div class="leader-score">${escapeHtml(row.value)}</div></div>`).join("") : `<div class="empty-state">No scores in this period yet.<br>Play a round and your local records will appear here.</div>`}
      </section><p class="subtle" style="font-size:10px">Rankings are private to this device. Connect no account, share no data.</p>
      <button class="btn secondary full" data-action="back-profile">← &nbsp; Back to profile</button>`;
  }
  function settingsPage() {
    return `${titleBlock("Settings", "Make your Japan Quiz feel like yours.")}
      <section class="panel">
        ${settingSwitch("sound", "Sound effects", "Answer tones and little celebrations.", state.settings.sound)}
        ${settingSwitch("music", "Ambient music", "A soft, optional electronic soundscape.", state.settings.music)}
        ${settingSwitch("dark", "Dark mode", "A softer look for evening play.", state.settings.dark)}
        <div class="setting-row"><div><strong>Language preference</strong><span>Saved on this device; the interface and quiz content are currently in English.</span></div><select class="select" data-action="language"><option value="en" ${state.settings.language === "en" ? "selected" : ""}>English</option><option value="ja" ${state.settings.language === "ja" ? "selected" : ""}>日本語</option></select></div>
      </section>
      <section class="panel"><h3>About Japan Quiz</h3><p class="subtle" style="font-size:11px;margin:0">Discover Japan. Learn. Play. Master. A free, offline-ready learning game with 300 original quiz prompts across 12 topics. Your progress lives on this device.</p></section>
      <section class="panel"><h3>Data & privacy</h3><p class="subtle" style="font-size:11px;margin:0 0 11px">No account, tracking, or network connection is needed. Quiz progress and settings are stored locally in this browser.</p><button class="btn ghost small" data-action="reset">Reset all progress</button></section>
      <button class="btn secondary full" data-action="navigate" data-page="profile">← &nbsp; Back to profile</button>`;
  }
  function settingSwitch(key, title, description, enabled) {
    return `<div class="setting-row"><div><strong>${title}</strong><span>${description}</span></div><button class="switch ${enabled ? "on" : ""}" role="switch" aria-checked="${enabled}" aria-label="${title}" data-action="setting" data-setting="${key}"></button></div>`;
  }

  function gamePage() {
    if (!game) return "";
    if (game.finished) return resultPage();
    const question = game.questions[game.index];
    if (!question) return "";
    const answered = game.selected !== null;
    const options = game.options || [];
    const currentLabel = game.mode === "endless" || game.mode === "time" ? `${game.index + 1}` : `${game.index + 1} / ${game.questions.length}`;
    const percent = game.mode === "endless" || game.mode === "time" ? Math.min(100, game.index / 20 * 100) : ((game.index + (answered ? 1 : 0)) / game.questions.length) * 100;
    const correctSelected = game.selected === question.answer;
    const terminate = answered && !correctSelected && ["endless", "survival"].includes(game.mode);
    const nextText = terminate ? "See your results" : game.index + 1 >= game.questions.length ? "Finish round" : "Next question";
    return `<div class="back-row"><button class="icon-button" data-action="leave-game" aria-label="Leave game">←</button><div style="flex:1"><strong style="font-size:12px">${MODE_INFO[game.mode].icon} &nbsp;${MODE_INFO[game.mode].title}${game.mode === "category" ? ` · ${game.categoryName}` : ""}</strong><div class="subtle" style="font-size:9px;margin-top:3px">${game.mode === "survival" ? `Difficulty ${question.difficulty} of 3` : "Keep discovering Japan"}</div></div><div class="coin-pill">🪙 ${state.coins}</div></div>
      <div class="game-progress"><div class="game-progress-top"><span>QUESTION ${currentLabel}</span><span>${game.mode === "time" ? `<span class="timer-ring" id="timer-display">00:${String(game.timeLeft).padStart(2, "0")}</span>` : `✦ ${game.correct} correct`}</span></div><div class="progress-track"><div class="progress-fill" style="width:${percent}%"></div></div></div>
      <span class="question-tag">${question.category} &nbsp;·&nbsp; ${["Easy", "Curious", "Expert"][question.difficulty - 1]}</span>
      <h1 class="question-title">${escapeHtml(question.prompt)}</h1>
      <div class="answer-list">${options.map((option, index) => {
        const isCorrect = option === question.answer;
        const isSelected = option === game.selected;
        const classNames = answered ? `disabled ${isCorrect ? "correct" : isSelected ? "wrong" : ""}` : "";
        return `<button class="answer ${classNames}" data-action="answer" data-answer="${encodeURIComponent(option)}" ${answered ? "disabled" : ""}><span class="answer-letter">${"ABCD"[index]}</span><span>${escapeHtml(option)}</span></button>`;
      }).join("")}</div>
      ${answered ? `<div class="answer-feedback"><strong>${correctSelected ? "✨ That’s right!" : "🌱 Not quite — every answer is a chance to learn."}</strong><p>${escapeHtml(question.explanation)}</p></div><div class="game-footer"><button class="btn full" data-action="next">${nextText} →</button></div>` : `<div class="game-footer"><p class="subtle" style="font-size:10px;text-align:center">${game.mode === "time" ? "Choose quickly — the clock is ticking!" : "Trust your curiosity. You’ve got this."}</p></div>`}`;
  }

  function resultPage() {
    const score = game.correct * 100 + Math.max(0, game.maxStreak - 1) * 15;
    const percent = game.answered ? Math.round(game.correct / game.answered * 100) : 0;
    const headline = game.mode === "daily" && game.dailyReward ? "Daily discovery complete!" : game.mode === "endless" && game.endedByMistake ? "A lovely run!" : percent >= 80 ? "Brilliantly done!" : "Every answer teaches you.";
    return `<div class="back-row"><button class="icon-button" data-action="navigate" data-page="home" aria-label="Home">⌂</button><strong style="font-size:12px">ROUND COMPLETE</strong></div>
      <div class="result-card"><div class="result-emoji">${percent >= 80 ? "🌸" : "🗻"}</div><div class="eyebrow">${MODE_INFO[game.mode].title.toUpperCase()}</div><h1 style="font-size:28px">${headline}</h1><p class="subtle">You’re one step closer to knowing Japan by heart.</p>
        <div class="result-score">${score}</div><div class="subtle" style="font-size:10px">POINTS EARNED</div>
        <div class="result-grid"><div><strong>${game.correct}/${game.answered}</strong><span>CORRECT</span></div><div><strong>+${game.xpEarned}</strong><span>XP EARNED</span></div><div><strong>+${game.coinsEarned}</strong><span>COINS</span></div></div>
      </div>
      ${game.dailyReward ? `<div class="daily-banner"><div class="category-icon">🎁</div><div><strong style="font-size:12px">Daily reward collected!</strong><p>Bonus XP and coins added to your collection.</p></div></div>` : ""}
      <button class="btn full" data-action="start" data-mode="${game.mode}" ${game.mode === "category" ? `data-category="${game.categoryId}"` : ""} style="margin-top:14px">Play again ↻</button>
      <button class="btn secondary full" data-action="navigate" data-page="challenges" style="margin-top:9px">Choose another mode</button>
      <button class="text-button" style="width:100%;margin-top:9px" data-action="navigate" data-page="home">Back to home</button>`;
  }

  function modalHtml() {
    if (modal === "reset") return `<div class="modal-backdrop" data-action="dismiss-modal"><section class="modal" role="dialog" aria-modal="true"><div class="result-emoji">🌸</div><h2>Begin a fresh journey?</h2><p>This permanently removes your locally saved XP, coins, records, settings, and achievements from this device. There’s no undo.</p><div class="modal-actions"><button class="btn secondary" data-action="cancel-reset">Keep progress</button><button class="btn" data-action="confirm-reset">Reset everything</button></div></section></div>`;
    if (modal === "leave") return `<div class="modal-backdrop" data-action="dismiss-modal"><section class="modal" role="dialog" aria-modal="true"><h2>Pause your journey?</h2><p>You can leave this round now. Answers already given have been saved; unanswered questions will not count as a finished game.</p><div class="modal-actions"><button class="btn secondary" data-action="cancel-leave">Keep playing</button><button class="btn" data-action="confirm-leave">Leave round</button></div></section></div>`;
    return "";
  }

  function render() {
    document.body.classList.toggle("dark", state.settings.dark);
    document.documentElement.lang = state.settings.language;
    if (page === "game") {
      app.innerHTML = shell(gamePage(), { noNav: true });
    } else {
      const views = { home: homePage, categories: categoriesPage, challenges: challengesPage, achievements: achievementsPage, profile: profilePage, settings: settingsPage, leaderboard: leaderboardPage };
      app.innerHTML = shell((views[page] || homePage)());
    }
  }

  function makeDailyQuestions() {
    const ordered = seededShuffle(JAPAN_QUESTIONS, todayKey());
    return ordered.slice(0, MODE_INFO.daily.count);
  }
  function startGame(mode, categoryId) {
    clearInterval(timer);
    let pool = mode === "category" ? JAPAN_QUESTIONS.filter(question => question.categoryId === categoryId) : [...JAPAN_QUESTIONS];
    if (mode === "daily") pool = makeDailyQuestions();
    else if (mode === "survival") {
      const byDifficulty = [1, 2, 3].flatMap(difficulty => shuffle(pool.filter(question => question.difficulty === difficulty)));
      pool = byDifficulty;
    } else pool = shuffle(pool);
    const count = Math.min(MODE_INFO[mode]?.count || 10, pool.length);
    const questions = pool.slice(0, count);
    const categoryName = JAPAN_CATEGORIES.find(item => item.id === categoryId)?.name || "";
    game = {
      mode, categoryId, categoryName, questions, index: 0, selected: null, options: [],
      correct: 0, answered: 0, streak: 0, maxStreak: 0, xpEarned: 0, coinsEarned: 0,
      finished: false, endedByMistake: false, timeLeft: 60, dailyReward: false
    };
    page = "game";
    prepareQuestion();
    render();
    if (mode === "time") {
      timer = window.setInterval(() => {
        if (!game || game.finished || page !== "game") return;
        game.timeLeft -= 1;
        const timerText = document.getElementById("timer-display");
        if (timerText) timerText.textContent = `00:${String(Math.max(0, game.timeLeft)).padStart(2, "0")}`;
        if (game.timeLeft <= 0) finishGame();
      }, 1000);
    }
  }
  function prepareQuestion() {
    const question = game?.questions[game.index];
    if (!question) return;
    const candidates = JAPAN_QUESTIONS.filter(item => item.id !== question.id && item.answer !== question.answer);
    const unique = [...new Map(candidates.map(item => [item.answer, item])).values()];
    game.options = shuffle([question.answer, ...shuffle(unique).slice(0, 3).map(item => item.answer)]);
    game.selected = null;
  }
  function recordAnswer(answer) {
    if (!game || game.finished || game.selected !== null) return;
    const question = game.questions[game.index];
    if (!question) return;
    game.selected = answer;
    game.answered += 1;
    state.totalAnswered += 1;
    if (!state.categoriesExplored.includes(question.categoryId)) state.categoriesExplored.push(question.categoryId);
    if (answer === question.answer) {
      const previousLevel = level();
      game.correct += 1;
      game.streak += 1;
      game.maxStreak = Math.max(game.maxStreak, game.streak);
      state.totalCorrect += 1;
      state.categoryCorrect[question.categoryId] = (state.categoryCorrect[question.categoryId] || 0) + 1;
      state.bestStreak = Math.max(state.bestStreak, game.streak);
      const earned = 15 + question.difficulty * 5 + Math.min(game.streak, 5) * 2;
      state.xp += earned;
      state.coins += 2;
      game.xpEarned += earned;
      game.coinsEarned += 2;
      sound(true);
      burst();
      if (level() > previousLevel) {
        showToast(`🌅 Level up! You’re now level ${level()}.`);
        burst();
      }
    } else {
      game.streak = 0;
      sound(false);
    }
    checkAchievements();
    persist();
    render();
  }
  function nextQuestion() {
    if (!game || game.selected === null) return;
    const current = game.questions[game.index];
    if (game.selected !== current.answer && ["endless", "survival"].includes(game.mode)) {
      game.endedByMistake = true;
      finishGame();
      return;
    }
    game.index += 1;
    if (game.index >= game.questions.length) {
      finishGame();
      return;
    }
    prepareQuestion();
    render();
  }
  function finishGame() {
    if (!game || game.finished) return;
    clearInterval(timer);
    game.finished = true;
    const previousLevel = level();
    state.gamesPlayed += 1;
    state.gameStreakBest = Math.max(state.gameStreakBest, game.maxStreak);
    const score = game.correct * 100 + Math.max(0, game.maxStreak - 1) * 15;
    state.bestScores[game.mode] = Math.max(state.bestScores[game.mode] || 0, score);
    if (game.mode === "endless") state.endlessBest = Math.max(state.endlessBest, game.correct);
    if (game.mode === "time") state.timeAttackBest = Math.max(state.timeAttackBest, game.correct);
    if (game.mode === "survival") state.survivalBest = Math.max(state.survivalBest, game.correct);
    const perfect = game.answered === 10 && game.correct === 10;
    if (perfect && ["classic", "daily", "category"].includes(game.mode)) {
      state.perfectRounds += 1;
      const bonus = 50;
      state.xp += bonus;
      game.xpEarned += bonus;
    }
    if (game.mode === "daily" && state.lastDailyDate !== todayKey()) {
      game.dailyReward = true;
      state.lastDailyDate = todayKey();
      state.dailyChallenges += 1;
      state.xp += 100;
      state.coins += 30;
      game.xpEarned += 100;
      game.coinsEarned += 30;
    }
    state.records.unshift({ mode: game.mode, date: new Date().toISOString(), score, correct: game.correct, answered: game.answered });
    state.records = state.records.slice(0, 200);
    checkAchievements();
    persist();
    if (level() > previousLevel) {
      showToast(`🌅 Level up! You’re now level ${level()}.`);
      burst();
    }
    page = "game";
    render();
  }

  function navigate(nextPage) {
    clearInterval(timer);
    page = nextPage;
    modal = "";
    render();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function handleAction(button, event) {
    const action = button.dataset.action;
    if (action === "navigate") navigate(button.dataset.page);
    else if (action === "settings") navigate("settings");
    else if (action === "leaderboard") navigate("leaderboard");
    else if (action === "back-profile") navigate("profile");
    else if (action === "start") startGame(button.dataset.mode, button.dataset.category);
    else if (action === "category") startGame("category", button.dataset.category);
    else if (action === "answer") recordAnswer(decodeURIComponent(button.dataset.answer));
    else if (action === "next") nextQuestion();
    else if (action === "leave-game") { modal = "leave"; render(); }
    else if (action === "confirm-leave") { modal = ""; clearInterval(timer); game = null; navigate("challenges"); }
    else if (action === "cancel-leave") { modal = ""; render(); }
    else if (action === "reset") { modal = "reset"; render(); }
    else if (action === "cancel-reset") { modal = ""; render(); }
    else if (action === "confirm-reset") {
      clearInterval(timer);
      localStorage.removeItem(STORAGE_KEY);
      state = structuredClone(DEFAULT_STATE);
      game = null;
      page = "home";
      modal = "";
      showToast("Your fresh journey begins now.");
      render();
    } else if (action === "dismiss-modal" && event.target === button) { modal = ""; render(); }
    else if (action === "avatar") {
      const index = AVATARS.indexOf(button.dataset.avatar);
      const unlocked = Math.min(AVATARS.length, Math.max(2, Math.floor(level() / 2) + 2));
      if (index >= 0 && index < unlocked) {
        state.avatar = AVATARS[index];
        persist();
        render();
      }
    } else if (action === "rename") {
      const name = window.prompt("Choose a player name (up to 18 characters):", state.username);
      if (name !== null) {
        const cleanName = name.trim().slice(0, 18);
        if (!cleanName) showToast("Your name can’t be empty.");
        else { state.username = cleanName; persist(); render(); }
      }
    } else if (action === "setting") {
      const key = button.dataset.setting;
      if (key === "music") { toggleMusic(!state.settings.music); return; }
      state.settings[key] = !state.settings[key];
      persist();
      render();
    } else if (action === "leader-tab") {
      leaderboardTab = button.dataset.tab;
      render();
    }
  }

  app.addEventListener("click", event => {
    const button = event.target.closest("[data-action]");
    if (!button || button.disabled) return;
    handleAction(button, event);
  });
  app.addEventListener("change", event => {
    if (event.target.matches('[data-action="language"]')) {
      state.settings.language = event.target.value;
      persist();
      document.documentElement.lang = event.target.value;
      showToast(event.target.value === "ja" ? "日本語の優先設定を保存しました。画面とクイズは英語です。" : "Language preference set to English.");
    }
  });
  document.addEventListener("visibilitychange", () => {
    if (document.hidden && state.settings.music) toggleMusic(false);
  });

  visitReward();
  render();
  if ("serviceWorker" in navigator && location.protocol !== "file:") {
    navigator.serviceWorker.register("./service-worker.js").catch(error => {
      console.error("Offline support could not be enabled.", error);
    });
  }
})();
