function pourcentage(jeu, categorie) {
  const c = compter(jeu, categorie);
  if (!c || c.total === 0) return null;
  return (c.obtenus / c.total) * 100;
}

function completion(jeu) {
  const valeurs = [pourcentage(jeu, "trophees"), pourcentage(jeu, "collectibles")]
    .filter(v => v !== null);
  if (valeurs.length === 0) return 0;
  const somme = valeurs.reduce((a, b) => a + b, 0);
  return Math.round((somme / valeurs.length) * 10) / 10;
}

function afficher(liste) {
  const grille = document.getElementById("bibliotheque");
  grille.innerHTML = "";

  if (liste.length === 0) {
    grille.innerHTML =
      '<p class="vide">Aucun jeu à afficher. Utilise « + Ajouter un jeu » pour commencer.</p>';
    return;
  }

  liste.forEach(jeu => {
    const taux = completion(jeu);
    const carte = document.createElement("a");
    carte.className = "carte";
    carte.href = "jeu.html?id=" + encodeURIComponent(jeu.id);

    const visuel = jeu.cover
      ? balisesImage(jeu.cover, jeu.titre)
      : `<div class="sans-cover">${jeu.titre}</div>`;

    carte.innerHTML = `
      <div class="jaquette">
        ${visuel}
        <span class="badge">${taux}%</span>
      </div>
      <div class="infos">
        <div class="titre">${jeu.titre}</div>
        <div class="plateforme">${jeu.plateformes.join(" · ")}</div>
        <div class="barre"><div class="barre-remplie" style="width:${taux}%"></div></div>
      </div>`;
    grille.appendChild(carte);
  });
    resoudreImages(grille);
}

const champRecherche = document.getElementById("recherche");
if (champRecherche) {
  champRecherche.addEventListener("input", e => {
    const terme = e.target.value.toLowerCase();
    afficher(tousLesJeux().filter(j => j.titre.toLowerCase().includes(terme)));
  });
  afficher(tousLesJeux());
}