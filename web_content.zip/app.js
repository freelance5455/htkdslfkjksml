const $ = (selector) => document.querySelector(selector);
const root = document.documentElement;
const sidebar = $("#sidebar");
const overlay = $("#mobileOverlay");
const input = $("#messageInput");
const form = $("#chatForm");
const sendButton = $("#sendButton");
const messagesEl = $("#messages");
const welcome = $("#welcome");
const historyList = $("#historyList");
const toast = $("#toast");

let conversations = [];
let activeId = null;
let busy = false;
let toastTimer;

function id() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3200);
}
function activeConversation() {
  return conversations.find(c => c.id === activeId);
}
function createConversation() {
  const conversation = { id: id(), title: "Nova conversa", messages: [] };
  conversations.unshift(conversation);
  activeId = conversation.id;
  renderHistory();
  renderMessages();
  closeSidebar();
  input.focus();
}
function titleFrom(text) {
  const clean = text.replace(/\s+/g, " ").trim();
  return clean.length > 34 ? clean.slice(0, 34) + "…" : clean || "Nova conversa";
}
function renderHistory() {
  historyList.replaceChildren();
  if (!conversations.length) {
    const empty = document.createElement("div");
    empty.className = "history-empty";
    empty.textContent = "Suas novas conversas aparecerão aqui.";
    historyList.append(empty);
    return;
  }
  for (const c of conversations) {
    const button = document.createElement("button");
    button.className = "history-item" + (c.id === activeId ? " active" : "");
    button.type = "button";
    const glyph = document.createElement("span");
    glyph.textContent = "▢";
    glyph.setAttribute("aria-hidden", "true");
    const title = document.createElement("span");
    title.textContent = c.title;
    button.append(glyph, title);
    button.addEventListener("click", () => {
      activeId = c.id;
      renderHistory();
      renderMessages();
      closeSidebar();
    });
    historyList.append(button);
  }
}
function renderMessages() {
  messagesEl.replaceChildren();
  const conversation = activeConversation();
  const hasMessages = Boolean(conversation?.messages.length);
  welcome.hidden = hasMessages;
  if (!conversation) return;
  for (const msg of conversation.messages) {
    if (msg.pending) continue;
    appendMessage(msg.role, msg.content, false);
  }
  scrollToBottom();
}
function appendMessage(role, content, save = true) {
  const row = document.createElement("article");
  row.className = `message ${role === "user" ? "user" : "assistant"}`;
  if (role !== "user") {
    const avatar = document.createElement("div");
    avatar.className = "message-avatar";
    avatar.textContent = "V1";
    avatar.setAttribute("aria-hidden", "true");
    row.append(avatar);
  }
  const body = document.createElement("div");
  body.className = "message-body";
  if (role === "assistant") {
    const contentEl = document.createElement("div");
    contentEl.className = "message-content";
    contentEl.innerHTML = basicMarkdown(content);
    body.append(contentEl);
    const actions = document.createElement("div");
    actions.className = "message-actions";
    const copy = document.createElement("button");
    copy.type = "button";
    copy.textContent = "Copiar";
    copy.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(content);
        showToast("Resposta copiada.");
      } catch {
        showToast("Não foi possível copiar automaticamente.");
      }
    });
    actions.append(copy);
    body.append(actions);
  } else {
    body.textContent = content;
  }
  row.append(body);
  messagesEl.append(row);
  if (save) scrollToBottom();
  return row;
}
// Escape HTML first; only then apply a small, safe Markdown subset.
function basicMarkdown(text) {
  const escapeHtml = (s) => s.replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[ch]);
  let safe = escapeHtml(text);
  const codeBlocks = [];
  safe = safe.replace(/```([a-zA-Z0-9_-]*)\n?([\s\S]*?)```/g, (_match, lang, code) => {
    const token = `@@CODE${codeBlocks.length}@@`;
    codeBlocks.push(`<pre><code>${code.trim()}</code></pre>`);
    return token;
  });
  safe = safe.replace(/`([^`\n]+)`/g, "<code>$1</code>");
  safe = safe.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  safe = safe.replace(/\*(.+?)\*/g, "<em>$1</em>");
  safe = safe.split(/\n{2,}/).map(part => {
    if (/^@@CODE\d+@@$/.test(part)) return part;
    return `<p>${part.replace(/\n/g, "<br>")}</p>`;
  }).join("");
  safe = safe.replace(/@@CODE(\d+)@@/g, (_m, n) => codeBlocks[Number(n)] || "");
  return safe;
}
function scrollToBottom() {
  requestAnimationFrame(() => {
    const scroller = $("#chatScroll");
    scroller.scrollTop = scroller.scrollHeight;
  });
}
function showTyping() {
  const row = document.createElement("article");
  row.className = "message assistant";
  row.id = "typingIndicator";
  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = "V1";
  const body = document.createElement("div");
  body.className = "message-body";
  const typing = document.createElement("div");
  typing.className = "typing";
  typing.innerHTML = "<i></i><i></i><i></i>";
  typing.setAttribute("aria-label", "V1 IA está pensando");
  body.append(typing);
  row.append(avatar, body);
  messagesEl.append(row);
  scrollToBottom();
}
function closeSidebar() {
  sidebar.classList.remove("open");
  overlay.classList.remove("show");
}
function openSidebar() {
  sidebar.classList.add("open");
  overlay.classList.add("show");
}
async function sendMessage(text) {
  const trimmed = text.trim();
  if (!trimmed || busy) return;
  if (!activeConversation()) createConversation();
  const conversation = activeConversation();
  conversation.messages.push({ role: "user", content: trimmed });
  if (conversation.messages.filter(m => m.role === "user").length === 1) {
    conversation.title = titleFrom(trimmed);
  }
  renderHistory();
  welcome.hidden = true;
  appendMessage("user", trimmed);
  input.value = "";
  resizeInput();
  busy = true;
  sendButton.disabled = true;
  input.disabled = true;
  showTyping();
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: conversation.messages
          .filter(m => !m.pending)
          .slice(-30)
          .map(m => ({ role: m.role, content: m.content }))
      })
    });
    const data = await response.json().catch(() => ({}));
    $("#typingIndicator")?.remove();
    if (!response.ok) throw new Error(data.error || "Não foi possível obter uma resposta.");
    conversation.messages.push({ role: "assistant", content: data.answer });
    appendMessage("assistant", data.answer);
  } catch (error) {
    $("#typingIndicator")?.remove();
    const message = error instanceof TypeError
      ? "Não consegui acessar o servidor. Inicie a V1 IA pelo comando npm start e tente novamente."
      : error.message;
    appendMessage("assistant", `**Ops!** ${message}`);
  } finally {
    busy = false;
    sendButton.disabled = false;
    input.disabled = false;
    input.focus();
    renderHistory();
  }
}
function resizeInput() {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
}
form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage(input.value);
});
input.addEventListener("input", resizeInput);
input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});
$("#newChat").addEventListener("click", createConversation);
$("#openSidebar").addEventListener("click", openSidebar);
$("#closeSidebar").addEventListener("click", closeSidebar);
overlay.addEventListener("click", closeSidebar);
$("#clearHistory").addEventListener("click", () => {
  if (!conversations.length) {
    showToast("Ainda não há conversas para limpar.");
    return;
  }
  if (confirm("Limpar todas as conversas desta sessão?")) {
    conversations = [];
    activeId = null;
    renderHistory();
    renderMessages();
    showToast("Conversas removidas desta sessão.");
  }
});
$("#themeToggle").addEventListener("click", () => {
  root.classList.toggle("light");
});
document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => sendMessage(button.dataset.prompt));
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeSidebar();
});
renderHistory();
renderMessages();
