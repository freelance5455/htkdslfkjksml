const prayers=[
 ["Fajr","الفجر"],["Sunrise","الشروق"],["Dhuhr","الظهر"],["Asr","العصر"],["Maghrib","المغرب"],["Isha","العشاء"]
];
let times={}, nextKey=null, timer=null, coords=null;

const $=id=>document.getElementById(id);
function toast(t){$("toast").textContent=t;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",3000)}
function today(){const d=new Date();return String(d.getDate()).padStart(2,"0")+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+d.getFullYear()}
function fmt(t){return t?.split(" ")[0]||"--:--"}
function minutes(t){const [h,m]=fmt(t).split(":").map(Number);return h*60+m}
function nowMin(){const d=new Date();return d.getHours()*60+d.getMinutes()+d.getSeconds()/60}
function render(data){
 times=data.timings||{}; 
 $("date").textContent=(data.date?.gregorian?.weekday?.ar||"اليوم")+" • "+(data.date?.readable||"")+" • "+(data.date?.hijri?.day||"")+" "+(data.date?.hijri?.month?.ar||"")+" "+(data.date?.hijri?.year||"")+" هـ";
 const current=nowMin();
 let candidate=prayers.find(([k])=>["Fajr","Dhuhr","Asr","Maghrib","Isha"].includes(k)&&minutes(times[k])>current);
 if(!candidate) candidate=["Fajr","الفجر"];
 nextKey=candidate[0];
 $("nextName").textContent=candidate[1];
 $("prayers").innerHTML=prayers.map(([k,n])=>`<div class="prayer ${k===nextKey?'next':''}"><div class="pname">${n}</div><div class="ptime">${fmt(times[k])}</div></div>`).join("");
 updateCountdown();
 clearInterval(timer);timer=setInterval(updateCountdown,1000);
}
function updateCountdown(){
 if(!nextKey||!times[nextKey])return;
 let diff=minutes(times[nextKey])-nowMin();
 if(diff<0) diff+=1440;
 const s=Math.floor(diff*60), h=Math.floor(s/3600), m=Math.floor(s%3600/60), sec=s%60;
 $("count").textContent=`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(sec).padStart(2,"0")}`;
}
async function load(){
 $("nextName").textContent="جاري الحساب...";
 try{
  let url;
  if(coords){
   const d=today(); url=`https://api.aladhan.com/v1/timings/${d}?latitude=${coords.lat}&longitude=${coords.lon}&method=5`;
  }else{
   url=`https://api.aladhan.com/v1/timingsByCity/${today()}?city=Cairo&country=Egypt&method=5`;
  }
  const r=await fetch(url); if(!r.ok) throw new Error("API");
  const j=await r.json(); render(j.data);
  localStorage.setItem("salah-cache",JSON.stringify(j.data));
 }catch(e){
  const c=localStorage.getItem("salah-cache"); if(c)render(JSON.parse(c)); else {$("nextName").textContent="تعذر تحميل المواقيت";toast("تحقق من اتصال الإنترنت");}
 }
}
$("refresh").onclick=load;
$("geo").onclick=()=>{
 navigator.geolocation?.getCurrentPosition(p=>{coords={lat:p.coords.latitude,lon:p.coords.longitude};$("location").textContent="استخدام موقع الجهاز • طريقة الحساب: الهيئة المصرية العامة للمساحة";load()},()=>toast("لم نتمكن من الوصول للموقع"));
};
$("notify").onclick=async()=>{
 if(!("Notification"in window)){toast("التنبيهات غير مدعومة في هذا المتصفح");return}
 const p=await Notification.requestPermission();
 toast(p==="granted"?"تم تفعيل إذن التنبيهات":"لم يتم منح إذن التنبيهات");
};
if("serviceWorker"in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
load();