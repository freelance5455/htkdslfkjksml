const $=s=>document.querySelector(s);
let points=+localStorage.points||0; $("#points").textContent=points;
function toast(t){const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1800)}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab,.panel").forEach(x=>x.classList.remove("active"));b.classList.add("active");$("#"+b.dataset.tab).classList.add("active")});
document.querySelectorAll(".subject").forEach(b=>b.onclick=()=>{toast("تم اختيار "+b.dataset.name+" 📖");document.querySelector('[data-tab="tasks"]').click();});
let tasks=JSON.parse(localStorage.tasks||"[]");
function render(){const ul=$("#taskList");ul.innerHTML="";tasks.forEach((t,i)=>{const li=document.createElement("li");li.className="task "+(t.done?"done":"");li.innerHTML=`<span>${t.text}</span><div><button class="ok">✓</button> <button class="del">حذف</button></div>`;li.querySelector(".ok").onclick=()=>{if(!t.done){points+=5;localStorage.points=points;$("#points").textContent=points;toast("+5 نقاط 🎉")}t.done=!t.done;save()};li.querySelector(".del").onclick=()=>{tasks.splice(i,1);save()};ul.appendChild(li)})}
function save(){localStorage.tasks=JSON.stringify(tasks);render()}
$("#addBtn").onclick=()=>{let v=$("#taskInput").value.trim();if(!v)return;tasks.push({text:v,done:false});$("#taskInput").value="";save();toast("تمت إضافة المهمة")};
$("#taskInput").onkeydown=e=>{if(e.key==="Enter")$("#addBtn").click()};render();

$("#themeBtn").onclick=()=>{document.body.classList.toggle("dark");localStorage.dark=document.body.classList.contains("dark")};if(localStorage.dark==="true")document.body.classList.add("dark");

let seconds=1500, interval=null;
function clock(){let m=String(Math.floor(seconds/60)).padStart(2,"0"),s=String(seconds%60).padStart(2,"0");$("#timerDisplay").textContent=`${m}:${s}`}
$("#start").onclick=()=>{if(interval)return;interval=setInterval(()=>{seconds--;clock();if(seconds<=0){clearInterval(interval);interval=null;points+=10;localStorage.points=points;$("#points").textContent=points;toast("أحسنت! +10 نقاط 🎉");seconds=1500;clock()}},1000)};
$("#pause").onclick=()=>{clearInterval(interval);interval=null};$("#reset").onclick=()=>{clearInterval(interval);interval=null;seconds=1500;clock()};clock();
