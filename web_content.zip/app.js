const $ = (id) => document.getElementById(id);
const state = { view: "chat", gender: "feminine", voice: 1, attachments: [], camera: null, avatarUrl: null };
const views = ["chat","avatar","voices","live"];
const titles = {chat:"AI Chat",avatar:"Avatar Studio",voices:"Voice Studio",live:"Live camera"};

function showView(name){
  state.view=name;
  document.querySelectorAll(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${name}`));
  document.querySelectorAll(".nav-item").forEach(v=>v.classList.toggle("active",v.dataset.view===name));
  $("pageTitle").textContent=titles[name];
  $("sidebar").classList.remove("open");
}
document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$("menuBtn").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
$("newChat").addEventListener("click",()=>{$("messages").innerHTML="";addMessage("assistant","Assalam-o-alaikum! Nayi conversation shuru ho gayi. Aap kya poochna chahte hain?");showView("chat")});
function addMessage(role,text){
  const row=document.createElement("div");row.className=`message ${role==="user"?"user-message":""}`;
  const avatar=document.createElement("div");avatar.className="msg-avatar";avatar.textContent=role==="user"?"You":"✦";
  const bubble=document.createElement("div");bubble.className="bubble";
  if(role!=="user"){const name=document.createElement("span");name.className="msg-name";name.textContent="TALK YOUR AI";bubble.appendChild(name)}
  bubble.appendChild(document.createTextNode(text));row.append(avatar,bubble);$("messages").appendChild(row);$("messages").scrollTop=$("messages").scrollHeight;
}
function demoReply(message){
 const m=message.toLowerCase();
 if(/salam|assalam|hello|hi\b/.test(m))return "Wa-alaikum-assalam! Main yahan hoon. Aap kis topic par baat karna chahenge?";
 if(/free fire|gaming/.test(m))return "Free Fire ke liye main settings, gameplay tips aur content ideas mein madad kar sakta hoon. Aap kis cheez par focus karna chahte hain?";
 if(/urdu|translate|meaning/.test(m))return "Zaroor! Apna text bhej dein. Main uska matlab ya translation Urdu/Roman Urdu mein samjha sakta hoon.";
 if(/image|photo|picture/.test(m))return "Aap image attach kar sakte hain. Is prototype mein upload preview available hai; image understanding ke liye AI vision backend connect karna hoga.";
 return "Aapka message receive ho gaya. Yeh abhi local prototype hai, isliye yeh sample reply hai. Real intelligent answers ke liye secure server par AI model/API connect karna hoga.";
}
$("chatForm").addEventListener("submit",e=>{
 e.preventDefault();const value=$("chatInput").value.trim();if(!value&&!state.attachments.length)return;
 if(value)addMessage("user",value);
 if(state.attachments.length)addMessage("user","Attached: "+state.attachments.map(f=>f.name).join(", "));
 $("chatInput").value="";state.attachments=[];$("attachmentPreview").innerHTML="";
 setTimeout(()=>addMessage("assistant",demoReply(value)),350);
});
$("chatInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();$("chatForm").requestSubmit()}});
$("fileInput").addEventListener("change",e=>{
 state.attachments=[...state.attachments,...e.target.files];
 $("attachmentPreview").innerHTML="";
 state.attachments.forEach(f=>{const chip=document.createElement("span");chip.className="file-chip";chip.textContent="📎 "+f.name;$("attachmentPreview").appendChild(chip)});
 e.target.value="";
});
$("micBtn").addEventListener("click",()=>{
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){addMessage("assistant","Is browser mein speech-to-text available nahi. Aap keyboard ka microphone use kar sakte hain.");return}
 const rec=new SR();rec.lang="ur-PK";rec.onresult=e=>$("chatInput").value=e.results[0][0].transcript;rec.onerror=()=>addMessage("assistant","Microphone input start nahi ho saka. Browser permission check karein.");rec.start();
});

function renderVoices(){
 const grid=$("voiceGrid");grid.innerHTML="";
 for(let i=1;i<=20;i++){
  const b=document.createElement("button");b.className="voice-card"+(state.voice===i?" selected":"");
  b.innerHTML=`<b>${state.gender==="feminine"?"Nova":"Atlas"} ${String(i).padStart(2,"0")}</b><small>${state.gender==="feminine"?"Feminine":"Masculine"} preset · ${["Soft","Clear","Warm","Bright","Calm"][i%5]}</small>`;
  b.addEventListener("click",()=>{state.voice=i;renderVoices()});grid.appendChild(b);
 }
}
document.querySelectorAll("[data-gender]").forEach(b=>b.addEventListener("click",()=>{state.gender=b.dataset.gender;state.voice=1;document.querySelectorAll("[data-gender]").forEach(x=>x.classList.toggle("selected",x===b));renderVoices()}));
$("voiceRate").addEventListener("input",e=>$("rateValue").textContent=Number(e.target.value).toFixed(1)+"×");
$("voicePitch").addEventListener("input",e=>$("pitchValue").textContent=Number(e.target.value).toFixed(1));
$("previewVoice").addEventListener("click",()=>{
 if(!("speechSynthesis" in window)){ $("voiceStatus").textContent="Speech preview is not supported in this browser.";return}
 speechSynthesis.cancel();const u=new SpeechSynthesisUtterance("Assalam-o-alaikum! Main TALK YOUR AI hoon. Aap kaise hain?");
 u.lang="ur-PK";u.rate=Number($("voiceRate").value);u.pitch=Number($("voicePitch").value);
 const available=speechSynthesis.getVoices();if(available.length){const preferred=available.find(v=>v.lang.toLowerCase().startsWith("ur"))||available.find(v=>v.lang.toLowerCase().startsWith("en"));if(preferred)u.voice=preferred}
 speechSynthesis.speak(u);$("voiceStatus").textContent="Preview uses a voice installed on your device; preset labels are prototype profiles.";
});
$("voiceFile").addEventListener("change",e=>{
 const f=e.target.files[0];if(!f)return;const audio=$("voiceAudio");audio.src=URL.createObjectURL(f);audio.hidden=false;audio.load();$("voiceStatus").textContent="Recording loaded locally. It is not uploaded or cloned.";e.target.value="";
});

$("avatarFile").addEventListener("change",e=>{
 const f=e.target.files[0];if(!f)return;if(state.avatarUrl)URL.revokeObjectURL(state.avatarUrl);state.avatarUrl=URL.createObjectURL(f);
 $("avatarStage").innerHTML="";const img=document.createElement("img");img.src=state.avatarUrl;img.alt="Uploaded avatar reference";$("avatarStage").appendChild(img);$("topAvatar").textContent="✦";$("avatarStatus").textContent="Reference image preview loaded locally.";e.target.value="";
});
$("saveAvatar").addEventListener("click",()=>{$("avatarStatus").textContent=`Settings saved in this session: ${$("avatarName").value||"Nova"} · ${$("avatarStyle").value} · ${$("avatarMood").value}.`});

$("startCamera").addEventListener("click",async()=>{
 if(!navigator.mediaDevices?.getUserMedia){$("cameraStatus").textContent="Camera preview needs a supported browser and secure HTTPS connection.";return}
 try{state.camera=await navigator.mediaDevices.getUserMedia({video:true,audio:false});$("cameraVideo").srcObject=state.camera;$("cameraPlaceholder").hidden=true;$("startCamera").disabled=true;$("stopCamera").disabled=false;$("cameraStatus").textContent="Camera preview is active on this device only."}
 catch(err){$("cameraStatus").textContent="Camera permission was not granted or the camera is unavailable."}
});
$("stopCamera").addEventListener("click",stopCamera);
function stopCamera(){if(state.camera){state.camera.getTracks().forEach(t=>t.stop());state.camera=null}$("cameraVideo").srcObject=null;$("cameraPlaceholder").hidden=false;$("startCamera").disabled=false;$("stopCamera").disabled=true;$("cameraStatus").textContent="Camera stopped."}
window.addEventListener("beforeunload",stopCamera);
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
renderVoices();
