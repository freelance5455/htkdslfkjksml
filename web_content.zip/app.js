// app.js - लॉजिक और वॉइस कंट्रोल (Smart NLP + English/Hinglish Support)

const chatContainer = document.getElementById('chat-container');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const micBtn = document.getElementById('mic-btn');

function addMessage(text, sender) {
    const msgDiv = document.createElement('div');
    msgDiv.className = `msg ${sender === 'user' ? 'user-msg' : 'ai-msg'}`;
    msgDiv.innerText = text;
    chatContainer.appendChild(msgDiv);
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

// एडवांस हाइब्रिड ऑफलाइन डेटाबेस सर्च
function getOfflineResponse(text) {
    let lowerText = text.toLowerCase();

    // 1. हिंगलिश/इंग्लिश डिक्शनरी - यह अंग्रेजी शब्दों को हिंदी कीवर्ड्स में बदल देगा
    const engToHindi = {
        "what": "क्या", "who": "कौन", "where": "कहाँ", "how": "कैसे", "when": "कब",
        "full form": "फुल फॉर्म", "computer": "कंप्यूटर", "father": "पिता", "mother": "माता",
        "capital": "राजधानी", "country": "देश", "president": "राष्ट्रपति",
        "prime minister": "प्रधानमंत्री", "science": "विज्ञान", "taj mahal": "ताजमहल",
        "ram": "रैम", "rom": "रोम", "cpu": "सीपीयू", "apple": "एप्पल", "google": "गूगल",
        "microsoft": "माइक्रोसॉफ्ट", "founder": "संस्थापक", "inventor": "आविष्कारक",
        "invention": "आविष्कार", "first": "पहला", "biggest": "सबसे बड़ा", "smallest": "सबसे छोटा",
        "sp": "एसपी", "dgp": "डीजीपी", "ig": "आईजी", "collector": "कलेक्टर", "bike": "बाइक",
        "engine": "इंजन", "moon": "चाँद", "sun": "सूर्य", "earth": "पृथ्वी"
    };

    // अगर यूजर के टेक्स्ट में इंग्लिश शब्द है, तो उसका हिंदी अर्थ भी सर्च स्ट्रिंग में जुड़ जाएगा
    for (const [eng, hin] of Object.entries(engToHindi)) {
        if (lowerText.includes(eng)) {
            lowerText += " " + hin; 
        }
    }

    let bestMatch = null;
    let maxScore = 0;

    // 2. फालतू शब्दों (Stop Words) की लिस्ट (हिंदी और इंग्लिश दोनों)
    const stopWords = [
        "है", "क्या", "कौन", "कहाँ", "का", "की", "के", "में", "से", "और", "को", "एक", "मुझे", "बताओ", "जानकारी", "दो", "होता", "होती", "करते", "कैसे",
        "is", "are", "am", "the", "a", "an", "of", "in", "to", "tell", "me", "about", "what", "who", "where", "how"
    ];

    for (const key in megaDatabase) {
        let lowerKey = key.toLowerCase();

        // डायरेक्ट मैच 
        if (lowerText.includes(lowerKey)) {
            return megaDatabase[key];
        }

        // शब्दों को तोड़कर स्मार्ट मैचिंग
        let keyWords = lowerKey.split(" ").filter(word => !stopWords.includes(word) && word.trim() !== "");
        let score = 0;

        for (let word of keyWords) {
            if (lowerText.includes(word)) {
                score++;
            }
        }

        // सबसे ज्यादा मैच होने वाले सवाल को चुनना
        if (score > maxScore) {
            maxScore = score;
            bestMatch = megaDatabase[key];
        }
    }

    if (maxScore > 0) {
        return bestMatch;
    }

    return "माफ़ करना, यह जानकारी अभी मेरे ऑफलाइन डेटाबेस में नहीं है।";
}

function speakText(text) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'hi-IN';
    utterance.rate = 1.0;
    window.speechSynthesis.speak(utterance);
}

function handleSend() {
    const text = userInput.value.trim();
    if (text) {
        addMessage(text, 'user');
        userInput.value = '';
        
        setTimeout(() => {
            const response = getOfflineResponse(text);
            addMessage(response, 'ai');
            speakText(response);
        }, 400); 
    }
}

sendBtn.addEventListener('click', handleSend);
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleSend();
});

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
    // माइक की भाषा को भी स्मार्ट बना दिया है ताकि यह दोनों समझ सके
    const recognition = new SpeechRecognition();
    recognition.lang = 'hi-IN'; 
    recognition.interimResults = false;

    micBtn.addEventListener('click', () => {
        micBtn.classList.add('active'); 
        recognition.start();
    });

    recognition.onresult = (event) => {
        userInput.value = event.results[0][0].transcript;
        handleSend();
    };

    recognition.onend = () => micBtn.classList.remove('active');
    recognition.onerror = () => micBtn.classList.remove('active');
} else {
    micBtn.style.display = 'none'; 
}
