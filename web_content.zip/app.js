
const current=JSON.parse(localStorage.getItem('hallwayDramaCurrentUser')||'null');
if(current && !current.schoolCode) current.schoolCode='21511';
if(!current) location.replace('index.html');
const key=(x)=>'hallwayDrama_'+x;
function read(k,f){try{return JSON.parse(localStorage.getItem(key(k)))??f}catch{return f}}
function write(k,v){localStorage.setItem(key(k),JSON.stringify(v))}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
let posts=read('posts',[]);
if(!posts.length){posts=[{id:'welcome',user:'Hallway Drama',school:current.schoolCode,text:'Welcome to Hallway Drama! Keep it fun, respect your classmates, and share what is happening around school.',time:'Just now',likes:0,likedBy:[],comments:[]}];write('posts',posts)}
let chats=read('chats',[]);
const schoolGroupId='school-group-'+current.schoolCode;
if(!chats.some(c=>c.id===schoolGroupId)){
 chats.unshift({
  id:schoolGroupId,
  name:'School Group · '+current.schoolCode,
  type:'school',
  schoolCode:current.schoolCode,
  messages:[{user:'Hallway Drama',text:'Welcome to the school group chat! Be respectful and have fun.'}]
 });
 write('chats',chats);
}
let activeChat=schoolGroupId, selectedFilter='normal', pendingMedia=null;
const feed=document.getElementById('feed');

function renderFeed(){
 feed.innerHTML=posts.map(p=>{
  const liked=(p.likedBy||[]).includes(current.username);
  const media=p.media?`<div class="media-wrap"><${p.mediaType==='video'?'video controls':'img'} class="filter-${esc(p.filter||'normal')}" ${p.mediaType==='video'?'':'alt="Post media"'} src="${p.media}"></${p.mediaType==='video'?'video':'img'}></div>`:'';
  return `<article class="post ${p.media?'media-post':''}" data-id="${esc(p.id)}"><div class="posthead"><div class="avatar">${esc((p.user||'?')[0].toUpperCase())}</div><div><b>${esc(p.user)}</b><small>${esc(p.time)} · School ${esc(p.school||current.schoolCode)}</small></div></div>${media}<div class="post-content"><p>${esc(p.text)}</p></div><div class="actions"><button class="like ${liked?'liked':''}" data-like="${esc(p.id)}">${liked?'♥':'♡'} ${(p.likedBy||[]).length}</button><button data-comment="${esc(p.id)}">💬 ${(p.comments||[]).length}</button><button data-share="${esc(p.id)}">↗ Share</button></div></article>`
 }).join('');
}
renderFeed();
// TikTok-style vertical feed controls: one post at a time, swipe or wheel to move.
let feedBusy=false;
function feedPosts(){return Array.from(feed.querySelectorAll('.post'))}
function goToFeedPost(direction){
 const items=feedPosts(); if(!items.length || feedBusy) return;
 const currentIndex=Math.max(0,items.findIndex(x=>{
   const r=x.getBoundingClientRect(); return r.top>=feed.getBoundingClientRect().top-40;
 }));
 const next=Math.min(items.length-1,Math.max(0,currentIndex+direction));
 if(next===currentIndex && direction<0){
   feed.scrollTo({top:0,behavior:'smooth'}); return;
 }
 if(next===currentIndex) return;
 feedBusy=true;
 items[next].scrollIntoView({behavior:'smooth',block:'start'});
 setTimeout(()=>feedBusy=false,420);
}
let touchStartY=null;
feed.addEventListener('touchstart',e=>{
 if(e.touches.length===1) touchStartY=e.touches[0].clientY;
},{passive:true});
feed.addEventListener('touchend',e=>{
 if(touchStartY===null)return;
 const dy=e.changedTouches[0].clientY-touchStartY;
 touchStartY=null;
 if(Math.abs(dy)>45) goToFeedPost(dy<0?1:-1);
},{passive:true});
feed.addEventListener('wheel',e=>{
 if(Math.abs(e.deltaY)<25)return;
 e.preventDefault();
 goToFeedPost(e.deltaY>0?1:-1);
},{passive:false});


document.getElementById('welcomeName').textContent=`Welcome, ${current.username}`;
document.getElementById('schoolLabel').textContent=`School ${current.schoolCode}`;
document.getElementById('logoutBtn').onclick=()=>{localStorage.removeItem('hallwayDramaCurrentUser');location.replace('index.html')};

const scrollFeed=document.getElementById('scrollFeed');
function schoolVideos(){
 return posts.filter(p=>p.mediaType==='video' && p.media && String(p.school||current.schoolCode)===String(current.schoolCode));
}
function renderScroll(){
 if(!scrollFeed)return;
 const videos=schoolVideos();
 scrollFeed.innerHTML=videos.length ? videos.map(p=>{
   const liked=(p.likedBy||[]).includes(current.username);
   return `<article class="scroll-video" data-scroll-id="${esc(p.id)}">
     <video class="scroll-video-media filter-${esc(p.filter||'normal')}" src="${p.media}" playsinline muted loop preload="metadata"></video>
     <div class="scroll-shade"></div>
     <div class="scroll-info">
       <div class="scroll-user"><div class="avatar">${esc((p.user||'?')[0].toUpperCase())}</div><div><b>@${esc(p.user)}</b><small>School ${esc(p.school||current.schoolCode)}</small></div></div>
       ${p.text?`<p>${esc(p.text)}</p>`:''}
       <div class="scroll-actions">
         <button class="scroll-action ${liked?'liked':''}" data-scroll-like="${esc(p.id)}">${liked?'♥':'♡'}<small>${(p.likedBy||[]).length}</small></button>
         <button class="scroll-action" data-scroll-comment="${esc(p.id)}">💬<small>${(p.comments||[]).length}</small></button>
         <button class="scroll-action" data-scroll-share="${esc(p.id)}">↗<small>Share</small></button>
       </div>
     </div>
     <div class="scroll-play">▶</div>
   </article>`;
 }).join('') : `<div class="scroll-empty"><div class="scroll-empty-icon">▶</div><h3>No school videos yet</h3><p>Post a video from Home and it will appear here for students in School ${esc(current.schoolCode)}.</p></div>`;
 observeScrollVideos();
}
let scrollObserver;
function observeScrollVideos(){
 if(scrollObserver)scrollObserver.disconnect();
 const vids=scrollFeed?.querySelectorAll('.scroll-video-media')||[];
 if(!vids.length)return;
 scrollObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{
   const v=entry.target;
   if(entry.isIntersecting && entry.intersectionRatio>=0.65){
     vids.forEach(x=>{if(x!==v){x.pause();x.currentTime=x.currentTime;}});
     v.play().catch(()=>{});
     v.closest('.scroll-video')?.classList.add('playing');
   }else{v.pause();v.closest('.scroll-video')?.classList.remove('playing');}
 }),{root:scrollFeed,threshold:[0,.65,1]});
 vids.forEach(v=>scrollObserver.observe(v));
}
if(scrollFeed){
 scrollFeed.addEventListener('click',e=>{
   const video=e.target.closest('.scroll-video');
   if(!video)return;
   const like=e.target.closest('[data-scroll-like]');
   if(like){const p=posts.find(x=>x.id===like.dataset.scrollLike);if(p){p.likedBy=p.likedBy||[];const i=p.likedBy.indexOf(current.username);if(i<0)p.likedBy.push(current.username);else p.likedBy.splice(i,1);write('posts',posts);renderScroll();}return;}
   const comment=e.target.closest('[data-scroll-comment]');
   if(comment){const p=posts.find(x=>x.id===comment.dataset.scrollComment);const txt=prompt('Comment:');if(p&&txt?.trim()){p.comments=p.comments||[];p.comments.push({user:current.username,text:txt.trim()});write('posts',posts);renderScroll();}return;}
   const share=e.target.closest('[data-scroll-share]');
   if(share){navigator.clipboard?.writeText(location.href);alert('Video link copied.');return;}
   const v=video.querySelector('video');
   if(v){if(v.paused)v.play().catch(()=>{});else v.pause();video.classList.toggle('playing',!v.paused);}
 });
 scrollFeed.addEventListener('scroll',()=>{
   const first=scrollFeed.querySelector('.scroll-video-media');
   if(first && !scrollFeed.closest('.view')?.classList.contains('active'))return;
 });
}
const scrollRefresh=document.getElementById('scrollRefresh');
if(scrollRefresh)scrollRefresh.onclick=()=>{posts=read('posts',[]);renderScroll();};

function showView(id){
 document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
 document.getElementById(id).classList.add('active');
 document.querySelectorAll('.bottomnav span').forEach(x=>x.classList.toggle('selected',x.dataset.view===id));
 if(id==='scrollView'){posts=read('posts',[]);renderScroll();}
 if(id==='activityView')renderActivity();
 if(id==='chatView')renderChats();
 if(id==='profileView')renderProfile();
}
document.querySelectorAll('.bottomnav span').forEach(x=>x.onclick=()=>showView(x.dataset.view));

document.getElementById('newPostBtn').onclick=()=>document.getElementById('composer').classList.toggle('hidden');
document.getElementById('cancelPost').onclick=()=>{document.getElementById('composer').classList.add('hidden');pendingMedia=null;document.getElementById('mediaPreview').innerHTML=''};
document.querySelectorAll('.filters button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filters button').forEach(x=>x.classList.remove('active'));b.classList.add('active');selectedFilter=b.dataset.filter;previewMedia()});
document.getElementById('mediaFile').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>4*1024*1024){alert('For this offline build, keep media under 4 MB.');e.target.value='';return}const r=new FileReader();r.onload=()=>{pendingMedia={data:r.result,type:f.type.startsWith('video')?'video':'image'};previewMedia()};r.readAsDataURL(f)};
function previewMedia(){const el=document.getElementById('mediaPreview');if(!pendingMedia){el.innerHTML='';return}el.innerHTML=pendingMedia.type==='video'?`<video controls style="width:100%;max-height:300px" class="filter-${selectedFilter}" src="${pendingMedia.data}"></video>`:`<img style="width:100%;max-height:300px;object-fit:cover;border-radius:12px" class="filter-${selectedFilter}" src="${pendingMedia.data}">`}
document.getElementById('publishPost').onclick=()=>{
 const text=document.getElementById('postText').value.trim();
 if(!text&&!pendingMedia)return alert('Add a message or photo/video first.');
 posts.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),user:current.username,school:current.schoolCode,text,time:'Just now',likedBy:[],comments:[],media:pendingMedia?.data||'',mediaType:pendingMedia?.type||'',filter:selectedFilter});
 write('posts',posts);document.getElementById('postText').value='';document.getElementById('mediaFile').value='';pendingMedia=null;document.getElementById('mediaPreview').innerHTML='';document.getElementById('composer').classList.add('hidden');renderFeed();
};
document.getElementById('refreshBtn').onclick=()=>{posts=read('posts',[]);renderFeed()};

feed.onclick=e=>{
 const like=e.target.closest('[data-like]');
 if(like){const p=posts.find(x=>x.id===like.dataset.like);if(p){p.likedBy=p.likedBy||[];const i=p.likedBy.indexOf(current.username);if(i<0)p.likedBy.push(current.username);else p.likedBy.splice(i,1);write('posts',posts);renderFeed()}}
 const c=e.target.closest('[data-comment]');
 if(c){const p=posts.find(x=>x.id===c.dataset.comment);const txt=prompt('Comment:');if(p&&txt?.trim()){p.comments=p.comments||[];p.comments.push({user:current.username,text:txt.trim()});write('posts',posts);renderFeed()}}
 const s=e.target.closest('[data-share]');
 if(s){navigator.clipboard?.writeText(location.href);alert('Post link copied.')}
};

function renderActivity(){
 const mine=posts.filter(p=>(p.likedBy||[]).includes(current.username)|| (p.comments||[]).some(c=>c.user===current.username));
 document.getElementById('activityList').innerHTML=mine.length?mine.map(p=>`<div class="list-item"><div class="avatar">${esc((p.user||'?')[0])}</div><div class="grow"><b>${esc(p.user)}</b><small>${(p.likedBy||[]).includes(current.username)?'You liked this post.':''} ${(p.comments||[]).some(c=>c.user===current.username)?'You commented on this post.':''}</small></div></div>`).join(''):'<div class="card">No activity yet.</div>';
}

function renderChats(){
 const list=document.getElementById('chatList');
 if(!chats.length)list.innerHTML='<div style="padding:15px;color:#9fb9dc">No chats yet.</div>';
 else list.innerHTML=chats.map(c=>`<button class="chat-choice ${activeChat===c.id?'active':''}" data-chat="${c.id}">💬 <b>${esc(c.name)}</b><small>${c.type==='private'?'Private':c.type==='school'?'School-wide group':'Group chat'}</small></button>`).join('');
 list.querySelectorAll('[data-chat]').forEach(b=>b.onclick=()=>{activeChat=b.dataset.chat;renderChats();renderMessages()});
}
function renderMessages(){
 const c=chats.find(x=>x.id===activeChat);
 document.getElementById('chatTitle').textContent=c?`${c.name} · ${c.type==='private'?'Private':c.type==='school'?'School-wide':'Group'}`:'Select a chat';
 document.getElementById('messages').innerHTML=c?(c.messages||[]).map(m=>`<div class="bubble ${m.user===current.username?'me':''}">${esc(m.text)}<small>${esc(m.user)}</small></div>`).join(''):'';
 const box=document.getElementById('messages');box.scrollTop=box.scrollHeight;
}
document.getElementById('sendMessage').onclick=sendMessage;
document.getElementById('chatInput').onkeydown=e=>{if(e.key==='Enter')sendMessage()};
function sendMessage(){const inp=document.getElementById('chatInput'),t=inp.value.trim(),c=chats.find(x=>x.id===activeChat);if(!c||!t)return;c.messages=c.messages||[];c.messages.push({user:current.username,text:t});write('chats',chats);inp.value='';renderMessages();renderChats()}
document.getElementById('newChatBtn').onclick=()=>document.getElementById('chatModal').classList.add('show');
document.getElementById('createChat').onclick=()=>{const name=document.getElementById('chatName').value.trim();if(!name)return;chats.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),name,type:document.getElementById('chatType').value,messages:[]});write('chats',chats);document.getElementById('chatName').value='';document.getElementById('chatModal').classList.remove('show');activeChat=chats.at(-1).id;renderChats();renderMessages()};
document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>document.getElementById(b.dataset.close).classList.remove('show'));

function renderProfile(){
 document.getElementById('profileName').textContent=current.username;
 document.getElementById('profileSchool').textContent='School '+current.schoolCode;
 document.getElementById('bigAvatar').textContent=current.username[0].toUpperCase();
 const mine=posts.filter(p=>p.user===current.username);
 document.getElementById('postCount').textContent=mine.length;
 document.getElementById('likeCount').textContent=mine.reduce((n,p)=>n+(p.likedBy||[]).length,0);
}
document.getElementById('editProfile').onclick=()=>{document.getElementById('editUsername').value=current.username;document.getElementById('editModal').classList.add('show')};
document.getElementById('saveProfile').onclick=()=>{const n=document.getElementById('editUsername').value.trim();if(!n)return;current.username=n;localStorage.setItem('hallwayDramaCurrentUser',JSON.stringify(current));const users=JSON.parse(localStorage.getItem('hallwayDramaUsers')||'[]');const u=users.find(x=>x.id===current.id);if(u)u.username=n;localStorage.setItem('hallwayDramaUsers',JSON.stringify(users));document.getElementById('editModal').classList.remove('show');document.getElementById('welcomeName').textContent='Welcome, '+n;renderProfile()};


// Video Create: record or upload a video, choose Plain or a filter, preview, then post.
const createVideoBtn=document.getElementById('createVideoBtn');
const videoCreateModal=document.getElementById('videoCreateModal');
const startCameraBtn=document.getElementById('startCameraBtn');
const uploadVideoBtn=document.getElementById('uploadVideoBtn');
const createVideoFile=document.getElementById('createVideoFile');
const cameraFallbackFile=document.getElementById('cameraFallbackFile');
const cameraPreview=document.getElementById('cameraPreview');
const recordedPreview=document.getElementById('recordedPreview');
const videoPlaceholder=document.getElementById('videoPlaceholder');
const postCreatedVideo=document.getElementById('postCreatedVideo');
const videoCaption=document.getElementById('videoCaption');
let createStream=null, mediaRecorder=null, recordedChunks=[], createdVideoData='', createdVideoUrl='', createFilter='normal';

function showCreateVideo(){ videoCreateModal.classList.add('show'); resetVideoCreate(); }
function stopCreateCamera(){
  if(createStream){createStream.getTracks().forEach(t=>t.stop());createStream=null;}
  if(mediaRecorder && mediaRecorder.state!=='inactive') mediaRecorder.stop();
  mediaRecorder=null; cameraPreview.srcObject=null;
}
function resetVideoCreate(){
  stopCreateCamera(); recordedChunks=[]; createdVideoData='';
  if(createdVideoUrl){URL.revokeObjectURL(createdVideoUrl);createdVideoUrl='';}
  cameraPreview.classList.add('hidden'); recordedPreview.classList.add('hidden'); videoPlaceholder.classList.remove('hidden');
  recordedPreview.removeAttribute('src'); if(createVideoFile)createVideoFile.value=''; if(cameraFallbackFile)cameraFallbackFile.value=''; videoCaption.value='';
  postCreatedVideo.disabled=true; startCameraBtn.textContent='📷 Record'; startCameraBtn.disabled=false;
  createFilter='normal'; document.querySelectorAll('[data-create-filter]').forEach(b=>b.classList.toggle('active',b.dataset.createFilter==='normal')); applyCreateFilter();
}
function applyCreateFilter(){
  const cls='filter-'+createFilter;
  cameraPreview.className='camera-preview '+(cameraPreview.classList.contains('hidden')?'hidden ':'')+cls;
  recordedPreview.className='recorded-preview '+(recordedPreview.classList.contains('hidden')?'hidden ':'')+cls;
}
function handleCreateVideoFile(f){
  if(!f)return;
  if(f.size>4*1024*1024){alert('For this offline build, keep videos under 4 MB.'); if(createVideoFile)createVideoFile.value=''; if(cameraFallbackFile)cameraFallbackFile.value=''; return;}
  const r=new FileReader();
  r.onload=()=>{createdVideoData=r.result; recordedPreview.src=createdVideoData; recordedPreview.classList.remove('hidden'); cameraPreview.classList.add('hidden'); videoPlaceholder.classList.add('hidden'); postCreatedVideo.disabled=false; applyCreateFilter();};
  r.readAsDataURL(f);
}
createVideoBtn?.addEventListener('click',showCreateVideo);
document.querySelectorAll('[data-create-filter]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-create-filter]').forEach(x=>x.classList.remove('active'));b.classList.add('active');createFilter=b.dataset.createFilter;applyCreateFilter();});

startCameraBtn?.addEventListener('click',async()=>{
  if(mediaRecorder && mediaRecorder.state==='recording'){mediaRecorder.stop();startCameraBtn.textContent='📷 Record';return;}
  // Native browser camera fallback. This is especially important for Android previews/file:// pages,
  // where getUserMedia can be unavailable because the page is not a secure origin.
  if(!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder){
    if(cameraFallbackFile){cameraFallbackFile.click();return;}
    alert('Camera recording is not available in this preview.'); return;
  }
  try{
    createStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'},audio:true});
    cameraPreview.srcObject=createStream; cameraPreview.classList.remove('hidden'); videoPlaceholder.classList.add('hidden'); applyCreateFilter();
    recordedChunks=[];
    const options=MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')?{mimeType:'video/webm;codecs=vp9,opus'}:{};
    mediaRecorder=new MediaRecorder(createStream,options);
    mediaRecorder.ondataavailable=e=>{if(e.data?.size)recordedChunks.push(e.data)};
    mediaRecorder.onstop=()=>{
      const blob=new Blob(recordedChunks,{type:mediaRecorder.mimeType||'video/webm'});
      if(blob.size>4*1024*1024){alert('That recording is over 4 MB. Please make a shorter video.');resetVideoCreate();return;}
      createdVideoUrl=URL.createObjectURL(blob);recordedPreview.src=createdVideoUrl;cameraPreview.classList.add('hidden');recordedPreview.classList.remove('hidden');videoPlaceholder.classList.add('hidden');stopCreateCamera();postCreatedVideo.disabled=false;applyCreateFilter();
    };
    mediaRecorder.start(); startCameraBtn.textContent='⏹ Stop';
  }catch(err){
    // If permission is unavailable/blocked, immediately offer the native Android camera instead of doing nothing.
    if(err?.name==='NotAllowedError' || err?.name==='SecurityError' || err?.name==='NotSupportedError' || !window.isSecureContext){
      if(cameraFallbackFile){cameraFallbackFile.click();return;}
    }
    alert('Camera permission is required to record a video. Please allow Camera and Microphone access, then try again.');
  }
});

// Upload opens the native file picker directly from the button click.
uploadVideoBtn?.addEventListener('click',()=>{ if(createVideoFile) createVideoFile.click(); });
createVideoFile?.addEventListener('change',e=>handleCreateVideoFile(e.target.files?.[0]));
cameraFallbackFile?.addEventListener('change',e=>handleCreateVideoFile(e.target.files?.[0]));

postCreatedVideo?.addEventListener('click',()=>{
  const saveVideo=(data)=>{
    posts=read('posts',[]);
    posts.unshift({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),user:current.username,school:current.schoolCode,text:videoCaption.value.trim(),time:'Just now',likedBy:[],comments:[],media:data,mediaType:'video',filter:createFilter});
    write('posts',posts);renderFeed();renderScroll();videoCreateModal.classList.remove('show');resetVideoCreate();
  };
  if(createdVideoData){saveVideo(createdVideoData);return;}
  if(createdVideoUrl){fetch(createdVideoUrl).then(r=>r.blob()).then(blob=>{if(blob.size>4*1024*1024){alert('That recording is over 4 MB.');return;}const reader=new FileReader();reader.onload=()=>saveVideo(reader.result);reader.readAsDataURL(blob);});}
});
document.getElementById('cancelVideoCreate')?.addEventListener('click',()=>{videoCreateModal.classList.remove('show');resetVideoCreate();});
document.querySelector('[data-close="videoCreateModal"]')?.addEventListener('click',()=>{videoCreateModal.classList.remove('show');resetVideoCreate();});
