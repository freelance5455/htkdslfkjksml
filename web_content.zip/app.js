/* =========================================================================
   THARIPP CLIENT APPLICATION ENGINE
   ========================================================================= */

// Audio Controller with Web Audio API Fallback Synthesizer
class SoundController {
  constructor() {
    this.musicEnabled = true;
    this.sfxEnabled = true;
    this.volume = 0.7;

    this.audioElements = {
      intro: document.getElementById('audio-intro'),
      menu: document.getElementById('audio-menu'),
      start: document.getElementById('audio-start'),
      game: document.getElementById('audio-game'),
      victory: document.getElementById('audio-victory'),
      defeat: document.getElementById('audio-defeat')
    };

    this.currentTrack = null;
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    this.ctx = AudioContext ? new AudioContext() : null;
  }

  unlock() {
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playTrack(trackName) {
    if (!this.musicEnabled) return;
    this.stopTrack();

    const audio = this.audioElements[trackName];
    if (audio) {
      audio.volume = this.volume;
      audio.currentTime = 0;
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch(() => {});
      }
      this.currentTrack = audio;
    }
  }

  stopTrack() {
    if (this.currentTrack) {
      this.currentTrack.pause();
      this.currentTrack.currentTime = 0;
      this.currentTrack = null;
    }
  }

  setVolume(vol) {
    this.volume = Math.max(0, Math.min(1, vol));
    for (const key in this.audioElements) {
      if (this.audioElements[key]) {
        this.audioElements[key].volume = this.volume;
      }
    }
  }

  playSfx(type) {
    if (!this.sfxEnabled || !this.ctx) return;
    this.unlock();

    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    gain.connect(this.ctx.destination);
    osc.connect(gain);

    if (type === 'click') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, t);
      osc.frequency.exponentialRampToValueAtTime(880, t + 0.08);
      gain.gain.setValueAtTime(this.volume * 0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.08);
      osc.start(t);
      osc.stop(t + 0.08);
    } else if (type === 'capture') {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, t);
      osc.frequency.exponentialRampToValueAtTime(640, t + 0.18);
      gain.gain.setValueAtTime(this.volume * 0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.18);
      osc.start(t);
      osc.stop(t + 0.18);
    } else if (type === 'eliminate') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, t);
      osc.frequency.exponentialRampToValueAtTime(80, t + 0.28);
      gain.gain.setValueAtTime(this.volume * 0.6, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.28);
      osc.start(t);
      osc.stop(t + 0.28);
    }
  }
}

const audioCtrl = new SoundController();
const socket = io();

// State Variables
let localPlayer = {
  id: null,
  name: localStorage.getItem('tharipp_player_name') || '',
  character: 'p2'
};

const MALAYALAM_NAMES = {
  p2: 'പൂക്കി കരടി',
  p3: 'കണ്മണി',
  p4: 'മണിയൻ'
};

let currentRoomData = null;
let currentGameState = null;
let currentTheme = { bg: '#0d1117', grid: '#161b22', border: '#58a6ff' };
let spectatingPlayerIndex = 0;
let lanAddress = 'http://localhost:3000';
let gridSize = 90;

const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');

// Preload Character Images with exact lowercase filenames
const charImages = {
  p1: new Image(),
  p2: new Image(),
  p3: new Image(),
  p4: new Image()
};
charImages.p1.src = 'assets/images/p1.png';
charImages.p2.src = 'assets/images/p2.png';
charImages.p3.src = 'assets/images/p3.png';
charImages.p4.src = 'assets/images/p4.png';

function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach((s) => s.classList.remove('active'));
  const target = document.getElementById(screenId);
  if (target) target.classList.add('active');
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}

// -----------------------------------------------------------------------------
// 1. INTRO SCREEN
// -----------------------------------------------------------------------------
const introProgress = document.getElementById('intro-progress');
const btnEnter = document.getElementById('btn-enter');

let loadVal = 0;
const loadInterval = setInterval(() => {
  loadVal += 10;
  if (introProgress) introProgress.style.width = `${loadVal}%`;
  if (loadVal >= 100) {
    clearInterval(loadInterval);
    if (btnEnter) btnEnter.style.display = 'inline-block';
  }
}, 70);

btnEnter.addEventListener('click', () => {
  audioCtrl.unlock();
  audioCtrl.playSfx('click');
  audioCtrl.playTrack('menu');

  if (!localPlayer.name) {
    document.getElementById('modal-name').classList.add('active');
  } else {
    updateNameDisplay();
    showScreen('screen-main-menu');
  }
});

// -----------------------------------------------------------------------------
// 2. PLAYER NAME HANDLING
// -----------------------------------------------------------------------------
const modalName = document.getElementById('modal-name');
const inputPlayerName = document.getElementById('player-name-input');
const btnSaveName = document.getElementById('btn-save-name');
const displayName = document.getElementById('display-name');
const btnEditName = document.getElementById('btn-edit-name');

function savePlayerName() {
  const name = inputPlayerName.value.trim().substring(0, 10);
  if (!name) {
    showToast('Please enter a name!');
    return;
  }
  localPlayer.name = name;
  localStorage.setItem('tharipp_player_name', name);
  updateNameDisplay();
  modalName.classList.remove('active');
  showScreen('screen-main-menu');
}

btnSaveName.addEventListener('click', savePlayerName);
inputPlayerName.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') savePlayerName();
});

btnEditName.addEventListener('click', () => {
  inputPlayerName.value = localPlayer.name;
  modalName.classList.add('active');
});

function updateNameDisplay() {
  displayName.textContent = localPlayer.name || 'Player';
}

// -----------------------------------------------------------------------------
// 3. MAIN MENU NAVIGATION
// -----------------------------------------------------------------------------
document.getElementById('btn-quick-play').addEventListener('click', () => {
  audioCtrl.playSfx('click');
  socket.emit('quick_join', { name: localPlayer.name });
});

const modalOnline = document.getElementById('modal-online');
document.getElementById('btn-open-online').addEventListener('click', () => {
  audioCtrl.playSfx('click');
  modalOnline.classList.add('active');
});

document.getElementById('btn-close-online').addEventListener('click', () => {
  modalOnline.classList.remove('active');
});

const tabCreate = document.getElementById('tab-create');
const tabJoin = document.getElementById('tab-join');
const tabContentCreate = document.getElementById('tab-content-create');
const tabContentJoin = document.getElementById('tab-content-join');

tabCreate.addEventListener('click', () => {
  tabCreate.classList.add('active');
  tabJoin.classList.remove('active');
  tabContentCreate.classList.add('active');
  tabContentJoin.classList.remove('active');
});

tabJoin.addEventListener('click', () => {
  tabJoin.classList.add('active');
  tabCreate.classList.remove('active');
  tabContentJoin.classList.add('active');
  tabContentCreate.classList.remove('active');
});

document.getElementById('btn-action-create').addEventListener('click', () => {
  audioCtrl.playSfx('click');
  modalOnline.classList.remove('active');
  socket.emit('create_room', { name: localPlayer.name, isPrivate: false });
});

document.getElementById('btn-action-join').addEventListener('click', () => {
  const code = document.getElementById('input-room-code').value.trim();
  if (code.length < 3) {
    return showToast('Enter a valid room code!');
  }
  audioCtrl.playSfx('click');
  modalOnline.classList.remove('active');
  socket.emit('join_room', { code, name: localPlayer.name });
});

const modalLan = document.getElementById('modal-lan');
document.getElementById('btn-open-lan').addEventListener('click', () => {
  audioCtrl.playSfx('click');
  modalLan.classList.add('active');
});

document.getElementById('btn-close-lan').addEventListener('click', () => {
  modalLan.classList.remove('active');
});

document.getElementById('btn-lan-create').addEventListener('click', () => {
  modalLan.classList.remove('active');
  socket.emit('create_room', { name: localPlayer.name, isPrivate: false });
});

document.getElementById('btn-lan-join-direct').addEventListener('click', () => {
  modalLan.classList.remove('active');
  modalOnline.classList.add('active');
  tabJoin.click();
});

document.getElementById('btn-copy-lan').addEventListener('click', () => {
  const copyVal = document.getElementById('lan-url-display').value;
  navigator.clipboard.writeText(copyVal).then(() => {
    showToast('LAN Wi-Fi address copied!');
  });
});

const modalHow = document.getElementById('modal-how');
document.getElementById('btn-open-how').addEventListener('click', () => modalHow.classList.add('active'));
document.getElementById('btn-close-how').addEventListener('click', () => modalHow.classList.remove('active'));

const modalSettings = document.getElementById('modal-settings');
document.getElementById('btn-open-settings').addEventListener('click', () => modalSettings.classList.add('active'));
document.getElementById('btn-close-settings').addEventListener('click', () => modalSettings.classList.remove('active'));

document.getElementById('btn-exit-game').addEventListener('click', () => {
  if (confirm('Exit THARIPP?')) {
    window.location.reload();
  }
});

document.getElementById('toggle-music').addEventListener('change', (e) => {
  audioCtrl.musicEnabled = e.target.checked;
  if (!audioCtrl.musicEnabled) audioCtrl.stopTrack();
  else audioCtrl.playTrack('menu');
});

document.getElementById('toggle-sfx').addEventListener('change', (e) => {
  audioCtrl.sfxEnabled = e.target.checked;
});

document.getElementById('slider-volume').addEventListener('input', (e) => {
  audioCtrl.setVolume(parseFloat(e.target.value));
});

// -----------------------------------------------------------------------------
// 4. LOBBY HANDLING
// -----------------------------------------------------------------------------
const lobbySlotsContainer = document.getElementById('lobby-slots-container');
const lobbyCodeDisplay = document.getElementById('lobby-code-display');
const btnHostStart = document.getElementById('btn-host-start');
const lobbyInstruction = document.getElementById('lobby-instruction');

document.getElementById('btn-leave-lobby').addEventListener('click', () => {
  window.location.reload();
});

function renderLobby(room) {
  currentRoomData = room;
  lobbyCodeDisplay.textContent = room.code;

  lobbySlotsContainer.innerHTML = '';
  for (let i = 0; i < 6; i++) {
    const slotPlayer = room.players[i];
    const slotDiv = document.createElement('div');

    if (slotPlayer) {
      slotDiv.className = 'lobby-slot occupied';
      const isHost = slotPlayer.id === room.hostId;
      const charKey = (slotPlayer.character || 'p2').toLowerCase();
      slotDiv.innerHTML = `
        ${isHost ? '<span class="slot-host-badge">HOST</span>' : ''}
        <div class="slot-avatar" style="background:${slotPlayer.color.light}; border-color:${slotPlayer.color.main};">
          <img src="assets/images/${charKey}.png" alt="${slotPlayer.character}" onerror="this.style.display='none'">
        </div>
        <div class="slot-name">${escapeHtml(slotPlayer.name)}</div>
      `;
    } else {
      slotDiv.className = 'lobby-slot';
      slotDiv.innerHTML = `
        <div class="slot-avatar" style="background:#1a1c29; border-color:#333;">?</div>
        <div class="slot-empty">Empty Slot</div>
      `;
    }
    lobbySlotsContainer.appendChild(slotDiv);
  }

  const isLocalHost = room.hostId === socket.id;
  if (isLocalHost) {
    btnHostStart.classList.remove('hidden');
    lobbyInstruction.textContent = 'You are the Host. Press START GAME to advance!';
  } else {
    btnHostStart.classList.add('hidden');
    lobbyInstruction.textContent = 'Waiting for host to press START GAME...';
  }
}

btnHostStart.addEventListener('click', () => {
  audioCtrl.playSfx('click');
  socket.emit('host_start_game');
});

// -----------------------------------------------------------------------------
// 5. CHARACTER SELECTION SCREEN
// -----------------------------------------------------------------------------
const charCards = document.querySelectorAll('.char-card');
const btnToggleReady = document.getElementById('btn-toggle-ready');
const readyStatusList = document.getElementById('ready-status-list');

charCards.forEach((card) => {
  card.addEventListener('click', () => {
    audioCtrl.playSfx('click');
    charCards.forEach((c) => c.classList.remove('active'));
    card.classList.add('active');

    const selectedChar = card.getAttribute('data-char').toLowerCase();
    localPlayer.character = selectedChar;
    socket.emit('select_character', { character: selectedChar });
  });
});

btnToggleReady.addEventListener('click', () => {
  audioCtrl.playSfx('click');
  socket.emit('toggle_ready');
});

function renderSelectionScreen(room) {
  readyStatusList.innerHTML = '';
  let localIsReady = false;

  room.players.forEach((p) => {
    if (p.id === socket.id) {
      localIsReady = p.ready;
    }
    const pill = document.createElement('div');
    pill.className = `ready-pill ${p.ready ? 'is-ready' : ''}`;
    pill.textContent = `${p.name}: ${p.ready ? 'READY ✓' : 'NOT READY'}`;
    readyStatusList.appendChild(pill);
  });

  if (localIsReady) {
    btnToggleReady.textContent = 'CANCEL READY';
    btnToggleReady.classList.remove('btn-primary');
    btnToggleReady.classList.add('btn-danger');
  } else {
    btnToggleReady.textContent = 'READY';
    btnToggleReady.classList.remove('btn-danger');
    btnToggleReady.classList.add('btn-primary');
  }
}

// -----------------------------------------------------------------------------
// 6. GAMEPLAY & CANVAS RENDERING ENGINE
// -----------------------------------------------------------------------------
function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

function sendDirection(dir) {
  socket.emit('player_input', { dir });
}

window.addEventListener('keydown', (e) => {
  const key = e.key.toLowerCase();
  if (['arrowup', 'w'].includes(key)) sendDirection('UP');
  else if (['arrowdown', 's'].includes(key)) sendDirection('DOWN');
  else if (['arrowleft', 'a'].includes(key)) sendDirection('LEFT');
  else if (['arrowright', 'd'].includes(key)) sendDirection('RIGHT');
});

document.getElementById('ctrl-up').addEventListener('touchstart', (e) => { e.preventDefault(); sendDirection('UP'); });
document.getElementById('ctrl-down').addEventListener('touchstart', (e) => { e.preventDefault(); sendDirection('DOWN'); });
document.getElementById('ctrl-left').addEventListener('touchstart', (e) => { e.preventDefault(); sendDirection('LEFT'); });
document.getElementById('ctrl-right').addEventListener('touchstart', (e) => { e.preventDefault(); sendDirection('RIGHT'); });

document.getElementById('ctrl-up').addEventListener('click', () => sendDirection('UP'));
document.getElementById('ctrl-down').addEventListener('click', () => sendDirection('DOWN'));
document.getElementById('ctrl-left').addEventListener('click', () => sendDirection('LEFT'));
document.getElementById('ctrl-right').addEventListener('click', () => sendDirection('RIGHT'));

let touchStartX = 0;
let touchStartY = 0;
canvas.addEventListener('touchstart', (e) => {
  touchStartX = e.touches[0].clientX;
  touchStartY = e.touches[0].clientY;
}, { passive: true });

canvas.addEventListener('touchend', (e) => {
  const dx = e.changedTouches[0].clientX - touchStartX;
  const dy = e.changedTouches[0].clientY - touchStartY;
  if (Math.hypot(dx, dy) < 25) return;

  if (Math.abs(dx) > Math.abs(dy)) {
    sendDirection(dx > 0 ? 'RIGHT' : 'LEFT');
  } else {
    sendDirection(dy > 0 ? 'DOWN' : 'UP');
  }
}, { passive: true });

const spectatorBanner = document.getElementById('spectator-banner');
const spectatingName = document.getElementById('spectating-name');
document.getElementById('btn-prev-spectate').addEventListener('click', () => cycleSpectator(-1));
document.getElementById('btn-next-spectate').addEventListener('click', () => cycleSpectator(1));

function cycleSpectator(step) {
  if (!currentGameState) return;
  const living = currentGameState.players.filter((p) => p.isAlive);
  if (living.length === 0) return;
  spectatingPlayerIndex = (spectatingPlayerIndex + step + living.length) % living.length;
}

const hudTerritoryVal = document.getElementById('hud-territory-val');
const hudKillsVal = document.getElementById('hud-kills-val');
const leaderboardList = document.getElementById('leaderboard-list');

function renderGame() {
  requestAnimationFrame(renderGame);
  if (!currentGameState) return;

  const width = canvas.width;
  const height = canvas.height;
  const tileSize = 28;

  const me = currentGameState.players.find((p) => p.id === socket.id);
  const living = currentGameState.players.filter((p) => p.isAlive);

  let target = me && me.isAlive ? me : null;
  if (!target && living.length > 0) {
    if (spectatingPlayerIndex >= living.length) spectatingPlayerIndex = 0;
    target = living[spectatingPlayerIndex];
    spectatorBanner.classList.remove('hidden');
    spectatingName.textContent = target.name;
  } else if (me && me.isAlive) {
    spectatorBanner.classList.add('hidden');
  }

  const camX = target ? target.x * tileSize + tileSize / 2 : (gridSize * tileSize) / 2;
  const camY = target ? target.y * tileSize + tileSize / 2 : (gridSize * tileSize) / 2;

  const offsetX = width / 2 - camX;
  const offsetY = height / 2 - camY;

  ctx.fillStyle = currentTheme.bg;
  ctx.fillRect(0, 0, width, height);

  ctx.save();
  ctx.translate(offsetX, offsetY);

  // Grid
  ctx.strokeStyle = currentTheme.grid;
  ctx.lineWidth = 1;
  const mapPixelWidth = gridSize * tileSize;
  const mapPixelHeight = gridSize * tileSize;

  for (let x = 0; x <= gridSize; x += 2) {
    ctx.beginPath();
    ctx.moveTo(x * tileSize, 0);
    ctx.lineTo(x * tileSize, mapPixelHeight);
    ctx.stroke();
  }
  for (let y = 0; y <= gridSize; y += 2) {
    ctx.beginPath();
    ctx.moveTo(0, y * tileSize);
    ctx.lineTo(mapPixelWidth, y * tileSize);
    ctx.stroke();
  }

  // Border
  ctx.strokeStyle = currentTheme.border;
  ctx.lineWidth = 4;
  ctx.strokeRect(0, 0, mapPixelWidth, mapPixelHeight);

  // Territory
  const grid = currentGameState.grid;
  for (let y = 0; y < gridSize; y++) {
    for (let x = 0; x < gridSize; x++) {
      const ownerIdx = grid[y * gridSize + x];
      if (ownerIdx >= 0) {
        const ownerPlayer = currentGameState.players.find((p) => p.colorIndex === ownerIdx);
        if (ownerPlayer) {
          ctx.fillStyle = ownerPlayer.color.light;
          ctx.fillRect(x * tileSize, y * tileSize, tileSize, tileSize);
        }
      }
    }
  }

  // Trails
  for (const player of currentGameState.players) {
    if (!player.isAlive || player.trail.length === 0) continue;
    ctx.fillStyle = player.color.trail;
    for (const pt of player.trail) {
      ctx.fillRect(pt.x * tileSize + 3, pt.y * tileSize + 3, tileSize - 6, tileSize - 6);
    }
  }

  // Heads & Images
  for (const player of currentGameState.players) {
    if (!player.isAlive) continue;

    const px = player.x * tileSize;
    const py = player.y * tileSize;

    ctx.beginPath();
    ctx.arc(px + tileSize / 2, py + tileSize / 2, tileSize / 1.1, 0, Math.PI * 2);
    ctx.fillStyle = player.color.main;
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 2;
    ctx.stroke();

    const charKey = (player.character || 'p2').toLowerCase();
    const img = charImages[charKey];
    if (img && img.complete && img.naturalWidth > 0) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(px + tileSize / 2, py + tileSize / 2, tileSize / 1.25, 0, Math.PI * 2);
      ctx.closePath();
      ctx.clip();
      ctx.drawImage(img, px - 2, py - 2, tileSize + 4, tileSize + 4);
      ctx.restore();
    } else {
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(charKey.toUpperCase(), px + tileSize / 2, py + tileSize / 2);
    }

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 11px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(player.name, px + tileSize / 2, py - 6);
  }

  ctx.restore();

  if (me) {
    hudTerritoryVal.textContent = `${me.score}%`;
    hudKillsVal.textContent = me.kills;
  }

  const sorted = [...currentGameState.players].sort(
    (a, b) => parseFloat(b.score) - parseFloat(a.score)
  );

  leaderboardList.innerHTML = '';
  sorted.forEach((p) => {
    const li = document.createElement('li');
    li.className = 'leaderboard-row';
    li.style.color = p.color.main;
    li.innerHTML = `
      <span class="lb-name" style="${!p.isAlive ? 'text-decoration:line-through;opacity:0.6;' : ''}">
        ${escapeHtml(p.name)}
      </span>
      <span>${p.score}%</span>
    `;
    leaderboardList.appendChild(li);
  });
}
requestAnimationFrame(renderGame);

// -----------------------------------------------------------------------------
// 7. RESULTS
// -----------------------------------------------------------------------------
const resultsHeadline = document.getElementById('results-headline');
const resultsWinnerName = document.getElementById('results-winner-name');
const resultsWinnerAvatar = document.getElementById('results-winner-avatar');
const resultsRankingsTbody = document.getElementById('results-rankings-tbody');

document.getElementById('btn-results-again').addEventListener('click', () => {
  audioCtrl.playSfx('click');
  socket.emit('play_again');
});

document.getElementById('btn-results-menu').addEventListener('click', () => {
  window.location.reload();
});

function displayResults(data) {
  showScreen('screen-results');

  const amIWinner = data.winner && data.winner.id === socket.id;
  if (amIWinner) {
    audioCtrl.playTrack('victory');
    resultsHeadline.textContent = 'VICTORY!';
    resultsHeadline.style.color = '#fffa65';
  } else {
    audioCtrl.playTrack('defeat');
    resultsHeadline.textContent = 'MATCH FINISHED';
    resultsHeadline.style.color = '#00f2fe';
  }

  if (data.winner) {
    const winnerKey = (data.winner.character || 'p2').toLowerCase();
    resultsWinnerName.textContent = data.winner.name;
    resultsWinnerAvatar.textContent = MALAYALAM_NAMES[winnerKey] || winnerKey.toUpperCase();
  } else {
    resultsWinnerName.textContent = 'None';
    resultsWinnerAvatar.textContent = '—';
  }

  resultsRankingsTbody.innerHTML = '';
  data.rankings.forEach((r) => {
    const tr = document.createElement('tr');
    const rKey = (r.character || 'p2').toLowerCase();
    const heroName = MALAYALAM_NAMES[rKey] || rKey.toUpperCase();
    tr.innerHTML = `
      <td><strong>#${r.rank}</strong></td>
      <td style="color:${r.color.main}; font-weight:700;">${escapeHtml(r.name)}</td>
      <td>${heroName}</td>
      <td>${r.score}%</td>
      <td>${r.kills}</td>
    `;
    resultsRankingsTbody.appendChild(tr);
  });
}

// -----------------------------------------------------------------------------
// 8. SOCKET.IO EVENTS
// -----------------------------------------------------------------------------
socket.on('lan_info', ({ ip, port }) => {
  lanAddress = `http://${ip}:${port}`;
  const lanInput = document.getElementById('lan-url-display');
  if (lanInput) lanInput.value = lanAddress;
});

socket.on('error_message', (msg) => {
  showToast(msg);
});

socket.on('joined_room', ({ player, room, gridSize: gs }) => {
  localPlayer.id = player.id;
  gridSize = gs;
  renderLobby(room);
  showScreen('screen-lobby');
});

socket.on('lobby_updated', (room) => {
  currentRoomData = room;
  if (room.status === 'LOBBY') {
    renderLobby(room);
  } else if (room.status === 'SELECTING') {
    renderSelectionScreen(room);
  }
});

socket.on('start_selection_screen', (room) => {
  audioCtrl.playSfx('click');
  renderSelectionScreen(room);
  showScreen('screen-character-select');
});

socket.on('match_starting', ({ theme }) => {
  currentTheme = theme;
  audioCtrl.stopTrack();
  audioCtrl.playTrack('start');
  showToast('Match starting now! Claim your territory!');
  setTimeout(() => {
    audioCtrl.playTrack('game');
    showScreen('screen-gameplay');
  }, 1400);
});

socket.on('game_state', (state) => {
  currentGameState = state;

  if (state.events && state.events.length > 0) {
    for (const ev of state.events) {
      if (ev.type === 'captured') {
        if (ev.playerId === socket.id) audioCtrl.playSfx('capture');
      } else if (ev.type === 'eliminated') {
        audioCtrl.playSfx('eliminate');
        if (ev.victimId === socket.id) {
          showToast('You were eliminated!');
        }
      }
    }
  }
});

socket.on('match_ended', (data) => {
  displayResults(data);
});

socket.on('return_to_lobby', (room) => {
  audioCtrl.playTrack('menu');
  renderLobby(room);
  showScreen('screen-lobby');
});

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}