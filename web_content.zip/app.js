const K="vetdb";let d=JSON.parse(localStorage.getItem(K)||'{"e":[],"p":[],"r":[]}');
const save=()=>localStorage.setItem(K,JSON.stringify(d)),id=()=>Date.now().toString(36);
function page(x){["e","p","r"].forEach(a=>document.getElementById(a).hidden=a!==x)}
function closeForm(){document.getElementById("modal").hidden=true}
function openForm(t){document.getElementById("modal").hidden=false;let h='';
if(t==="e")h=`<h2>Nouvel éleveur</h2><form onsubmit="add(event,'e')"><input name="nom" required placeholder="Nom de l'éleveur / exploitation"><input name="tel" placeholder="Téléphone"><input name="loc" placeholder="Localité"><select name="esp"><option>Bovin</option><option>Ovin</option><option>Caprin</option><option>Mixte</option></select><input name="tetes" type="number" placeholder="Nombre de têtes"><input name="trait" placeholder="Traitement / diagnostic"><input name="duree" type="number" placeholder="Durée (jours)"><input name="rappel" type="date"><textarea name="notes" placeholder="Observations"></textarea><button>Enregistrer</button></form>`;
if(t==="p")h=`<h2>Nouveau produit</h2><form onsubmit="add(event,'p')"><input name="nom" required placeholder="Nom du produit"><input name="cat" placeholder="Catégorie"><input name="actif" placeholder="Principe actif"><input name="lot" placeholder="N° de lot"><input name="stock" type="number" step=".01" placeholder="Stock"><input name="seuil" type="number" step=".01" placeholder="Seuil d'alerte"><input name="achat" type="number" step=".01" placeholder="Prix achat"><input name="vente" type="number" step=".01" placeholder="Prix vente"><input name="exp" type="date"><input name="fourn" placeholder="Fournisseur"><textarea name="notes" placeholder="Observations"></textarea><button>Enregistrer</button></form>`;
if(t==="r")h=`<h2>Nouveau rendez-vous</h2><form onsubmit="add(event,'r')"><input name="date" required type="date"><input name="heure" type="time"><input name="nom" required placeholder="Éleveur / client"><input name="tel" placeholder="Téléphone"><input name="loc" placeholder="Localité"><select name="motif"><option>Consultation</option><option>Échographie</option><option>Vaccination</option><option>Traitement</option><option>Visite d'élevage</option><option>Autre</option></select><input name="animal" placeholder="Animal / espèce"><select name="urg"><option>Normale</option><option>Urgente</option><option>Très urgente</option></select><textarea name="notes" placeholder="Motif / observations"></textarea><button>Enregistrer</button></form>`;
document.getElementById("form").innerHTML=h}
function add(ev,t){ev.preventDefault();let o={id:id()};new FormData(ev.target).forEach((v,k)=>o[k]=v);d[t].unshift(o);save();closeForm();render()}
function del(t,i){if(confirm("Supprimer ?")){d[t]=d[t].filter(x=>x.id!==i);save();render()}}
function esc(x){return String(x||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function dateObj(s){return s?new Date(s+"T00:00:00"):null}
function daysUntil(s){let d=dateObj(s);if(!d)return null;return Math.ceil((d-new Date(new Date().toDateString()))/86400000)}
function treatmentEnd(x){if(!x.start||!x.duree)return "";let d=dateObj(x.start);d.setDate(d.getDate()+Number(x.duree));return d.toISOString().slice(0,10)}
function renderAlerts(){
 let a=[];
 const add=(kind,title,text)=>a.push(`<div class="alert ${kind}"><div class="alert-title">${title}</div><div>${text}</div></div>`);
 d.p.forEach(x=>{
   if(x.seuil!=="" && Number(x.stock)<=Number(x.seuil)) add("red","📦 Stock faible",`${esc(x.nom)} — stock ${esc(x.stock)}, seuil ${esc(x.seuil)}`);
   if(x.exp){let n=daysUntil(x.exp);if(n<0)add("red","⚠️ Produit périmé",`${esc(x.nom)} — ${esc(x.exp)}`);else if(n<=30)add("","⏳ Péremption proche",`${esc(x.nom)} — dans ${n} jour(s) (${esc(x.exp)})`)}
 });
 d.e.forEach(x=>{
   if(x.trait && x.start && x.duree){
     let end=treatmentEnd(x), n=daysUntil(end);
     if(n<0)add("red","💊 Traitement dépassé",`${esc(x.nom)} — fin prévue ${end}`);
     else if(n<=2)add("","💊 Fin de traitement proche",`${esc(x.nom)} — fin prévue ${end}`);
   }
   if(x.rappel){let n=daysUntil(x.rappel);if(n<0)add("red","🔔 Rappel en retard",`${esc(x.nom)} — ${esc(x.rappel)}`);else if(n<=3)add("","🔔 Rappel proche",`${esc(x.nom)} — ${esc(x.rappel)}`)}
 });
 d.r.forEach(x=>{
   if(x.date){let n=daysUntil(x.date);if(n<0)return;if(n<=1)add(x.urg==="Très urgente"?"red":"","📅 Rendez-vous proche",`${esc(x.date)} ${esc(x.heure)} — ${esc(x.nom)} — ${esc(x.motif)}`)}
 });
 alerts.innerHTML=a.length?`<div class="alert-grid">${a.join("")}</div>`:`<div class="alert green">✅ Aucune alerte pour le moment.</div>`;
}
function render(){
 let q=(document.getElementById("eq").value||"").toLowerCase();
 el.innerHTML=d.e.filter(x=>(x.nom+" "+x.tel+" "+x.loc+" "+x.esp+" "+x.trait).toLowerCase().includes(q)).map(x=>`<div class=card><b>🐄 ${esc(x.nom)}</b><br>${esc(x.esp)} · ${esc(x.tetes)} têtes<br>📞 ${esc(x.tel)} · ${esc(x.loc)}<br>💊 ${esc(x.trait)} ${x.duree?`· ${esc(x.duree)} jours`:``}${x.start?`<br>Début: ${esc(x.start)}${x.duree?` · Fin: ${treatmentEnd(x)}`:""}`:""}${x.rappel?`<br>🔔 Rappel: ${esc(x.rappel)}`:``}<br><button class=danger onclick="del('e','${x.id}')">Supprimer</button></div>`).join("")||"<div class=card>Aucun éleveur.</div>";
 let pq=(document.getElementById("pq").value||"").toLowerCase();
 pl.innerHTML=d.p.filter(x=>(x.nom+" "+x.cat+" "+x.actif+" "+x.lot).toLowerCase().includes(pq)).map(x=>`<div class=card><b>💊 ${esc(x.nom)}</b><br>Stock: ${esc(x.stock)} · Seuil: ${esc(x.seuil)} · Achat: ${esc(x.achat)} · Vente: ${esc(x.vente)}<br>Lot: ${esc(x.lot)} · Péremption: ${esc(x.exp||"—")}<br>${x.actif?`Actif: ${esc(x.actif)}<br>`:""}<button class=danger onclick="del('p','${x.id}')">Supprimer</button></div>`).join("")||"<div class=card>Aucun produit.</div>";
 let rq=(document.getElementById("rq").value||"").toLowerCase();
 rl.innerHTML=d.r.filter(x=>(x.nom+" "+x.tel+" "+x.motif+" "+x.animal).toLowerCase().includes(rq)).sort((a,b)=>(a.date+a.heure).localeCompare(b.date+b.heure)).map(x=>`<div class=card><b>📅 ${esc(x.date)} ${esc(x.heure)}</b><br>${esc(x.nom)} · 📞 ${esc(x.tel)}<br>Motif: ${esc(x.motif)} · ${esc(x.animal)}<br>Urgence: ${esc(x.urg)}<br><button onclick="location.href='tel:${esc(x.tel)}'">📞 Appeler</button><button class=danger onclick="del('r','${x.id}')">Supprimer</button></div>`).join("")||"<div class=card>Aucun rendez-vous.</div>";
 renderAlerts();
}
function reportTable(title,rows){
 return `<h2>${title}</h2><table><thead><tr>${rows[0].map(x=>`<th>${x}</th>`).join("")}</tr></thead><tbody>${rows.slice(1).map(r=>`<tr>${r.map(x=>`<td>${esc(x)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
}
function printReport(){
 let w=window.open("","_blank");
 if(!w){alert("Autorise les fenêtres pop-up pour imprimer.");return}
 let alertsCopy=document.getElementById("alerts").innerHTML;
 let html=`<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Bilan — Clinique vétérinaire</title>
 <style>body{font-family:Arial;padding:25px;color:#17232b}h1{color:#1677a8}h2{margin-top:25px;border-bottom:1px solid #999;padding-bottom:5px}table{width:100%;border-collapse:collapse;margin:8px 0 18px}th,td{border:1px solid #bbb;padding:6px;text-align:left;font-size:11px}th{background:#eee}.alert{padding:8px;margin:5px 0;border-left:4px solid #d99a00;background:#fff0c8}.red{border-left-color:#c33;background:#ffe7e7}.green{border-left-color:#299653;background:#e8f7ed}.date{text-align:right;font-size:11px}</style></head><body>
 <h1>🐾 Bilan — Clinique Vétérinaire</h1><div class=date>${new Date().toLocaleDateString("fr-FR")}</div><h2>🔔 Alertes</h2>${alertsCopy}
 ${reportTable("Éleveurs / Élevages",[["Nom","Téléphone","Espèce","Têtes","Traitement","Fin traitement","Rappel"],...d.e.map(x=>[x.nom,x.tel,x.esp,x.tetes,x.trait,treatmentEnd(x),x.rappel])])}
 ${reportTable("Médicaments / Produits",[["Produit","Stock","Seuil","Prix achat","Prix vente","Lot","Péremption"],...d.p.map(x=>[x.nom,x.stock,x.seuil,x.achat,x.vente,x.lot,x.exp])])}
 ${reportTable("Rendez-vous",[["Date","Heure","Client","Téléphone","Motif","Animal","Urgence"],...d.r.map(x=>[x.date,x.heure,x.nom,x.tel,x.motif,x.animal,x.urg])])}
 <script>window.onload=()=>window.print()<\/script></body></html>`;
 w.document.write(html);w.document.close();
}
function printSection(t){
 let title=t==="e"?"Éleveurs / Élevages":t==="p"?"Médicaments / Produits":"Rendez-vous";
 let arr=d[t], rows=[];
 if(t==="e"){rows=[["Nom","Téléphone","Espèce","Têtes","Traitement","Fin","Rappel"],...arr.map(x=>[x.nom,x.tel,x.esp,x.tetes,x.trait,treatmentEnd(x),x.rappel])]}
 if(t==="p"){rows=[["Produit","Stock","Seuil","Achat","Vente","Lot","Péremption"],...arr.map(x=>[x.nom,x.stock,x.seuil,x.achat,x.vente,x.lot,x.exp])]}
 if(t==="r"){rows=[["Date","Heure","Client","Téléphone","Motif","Animal","Urgence"],...arr.map(x=>[x.date,x.heure,x.nom,x.tel,x.motif,x.animal,x.urg])]}
 let w=window.open("","_blank");if(!w){alert("Autorise les fenêtres pop-up pour imprimer.");return}
 w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><style>body{font-family:Arial;padding:25px}h1{color:#1677a8}table{width:100%;border-collapse:collapse}th,td{border:1px solid #999;padding:7px;font-size:12px}th{background:#eee}</style></head><body><h1>🐾 ${title}</h1><p>${new Date().toLocaleDateString("fr-FR")}</p>${reportTable(title,rows)}<script>window.onload=()=>window.print()<\/script></body></html>`);
 w.document.close();
}

function backup(){let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([JSON.stringify(d,null,2)],{type:"application/json"}));a.download="sauvegarde_clinique.json";a.click()}
render()