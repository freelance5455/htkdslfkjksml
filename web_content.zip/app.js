const file=document.getElementById('file'),preview=document.getElementById('preview'),result=document.getElementById('result'),prompt=document.getElementById('prompt'),status=document.getElementById('status'),loader=document.getElementById('loader'),download=document.getElementById('download'),buttons=[half,full];
let selected;
file.onchange=()=>{selected=file.files[0];if(!selected)return;preview.src=URL.createObjectURL(selected);preview.hidden=false;result.hidden=true;download.hidden=true;status.textContent='Photo ready.'};
async function run(mode){
 if(!selected)return status.textContent='Choose a photo first.';
 if(!prompt.value.trim())return status.textContent='Describe the replacement outfit first.';
 buttons.forEach(b=>b.disabled=true);loader.hidden=false;status.textContent='';
 try{
  const fd=new FormData();fd.append('image',selected);fd.append('mode',mode);fd.append('prompt',prompt.value.trim());
  const r=await fetch('/api/outfit-edit',{method:'POST',body:fd});
  if(!r.ok)throw new Error('HTTP '+r.status);
  const data=await r.json();if(!data.image_url)throw new Error('No image returned');
  result.src=data.image_url;result.hidden=false;download.href=data.image_url;download.hidden=false;status.textContent='Done.';
 }catch(e){console.error(e);status.textContent='The AI backend is not connected or returned an error.'}
 finally{buttons.forEach(b=>b.disabled=false);loader.hidden=true}
}
half.onclick=()=>run('half');full.onclick=()=>run('full');
