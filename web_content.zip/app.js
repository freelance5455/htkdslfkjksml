const news=[
 {cat:"বাংলাদেশ",title:"দেশের সর্বশেষ গুরুত্বপূর্ণ খবর এখানে দেখুন",desc:"আপনার নিউজ পোর্টালের জন্য এই ডেমো খবরটি ব্যবহার করা হয়েছে। পরে নিজের খবর দিয়ে পরিবর্তন করুন।",img:"https://images.unsplash.com/photo-1521295121783-8a321d551ad2?auto=format&fit=crop&w=900&q=80"},
 {cat:"আন্তর্জাতিক",title:"বিশ্বের বিভিন্ন প্রান্তের সর্বশেষ সংবাদ",desc:"আন্তর্জাতিক খবরের সংক্ষিপ্ত বিবরণ এখানে দেখানো হবে।",img:"https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?auto=format&fit=crop&w=900&q=80"},
 {cat:"খেলাধুলা",title:"খেলার মাঠের সর্বশেষ আপডেট",desc:"ক্রিকেট, ফুটবলসহ বিভিন্ন খেলার খবর এখানে প্রকাশ করুন।",img:"https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=900&q=80"},
 {cat:"ব্যবসা",title:"ব্যবসা ও অর্থনীতির গুরুত্বপূর্ণ সংবাদ",desc:"বাজার, ব্যবসা ও অর্থনীতির খবর সহজভাবে পাঠকদের কাছে পৌঁছে দিন।",img:"https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=900&q=80"}
];

const list=document.getElementById("newsList");
const searchBox=document.getElementById("searchBox");
const input=document.getElementById("searchInput");

function render(category="সব", query=""){
 const q=query.trim().toLowerCase();
 list.innerHTML="";
 news.filter(n=>(category==="সব"||n.cat===category)&&(!q||n.title.toLowerCase().includes(q)||n.desc.toLowerCase().includes(q)))
 .forEach(n=>{
   const card=document.createElement("article");
   card.className="card";
   card.innerHTML=`<img src="${n.img}" alt=""><div class="content"><div class="tag">${n.cat}</div><div class="title">${n.title}</div><div class="desc">${n.desc}</div><div class="date">আজ</div></div>`;
   list.appendChild(card);
 });
 if(!list.children.length) list.innerHTML="<p style='text-align:center;padding:30px'>কোনো খবর পাওয়া যায়নি।</p>";
}
document.querySelectorAll(".categories button").forEach(btn=>btn.onclick=()=>{
 document.querySelectorAll(".categories button").forEach(b=>b.classList.remove("active"));
 btn.classList.add("active"); render(btn.dataset.cat,input.value);
});
document.getElementById("searchBtn").onclick=()=>{
 searchBox.classList.toggle("hidden");
 if(!searchBox.classList.contains("hidden")) input.focus();
};
input.oninput=()=>render(document.querySelector(".categories .active").dataset.cat,input.value);
render();
