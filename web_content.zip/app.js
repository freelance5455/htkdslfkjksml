const KEY="EHM21_STATE_V1";

const MODULES = {
  dailyIncome:{label:"Ingreso del día", icon:"💰", type:"money", desc:"Carga manual del ingreso de hoy."},
  totalAccumulated:{label:"Total acumulado", icon:"📊", type:"computed", desc:"Suma de los ingresos registrados."},
  day21Goal:{label:"Objetivo para el día 21", icon:"📅", type:"money", desc:"Monto que querés alcanzar para el día 21."},
  rent:{label:"Alquiler", icon:"🏠", type:"money", desc:"Monto reservado para alquiler."},
  card:{label:"Tarjeta", icon:"💳", type:"money", desc:"Monto reservado para tarjeta."},
  monotributo:{label:"Monotributo", icon:"🧾", type:"money", desc:"Monto reservado para monotributo."},
  fuel:{label:"Combustible", icon:"⛽", type:"money", desc:"Presupuesto de combustible."},
  food:{label:"Comida", icon:"🍔", type:"money", desc:"Presupuesto de comida."},
  savings:{label:"Ahorro", icon:"🏦", type:"money", desc:"Monto destinado a ahorro."},
  available:{label:"Dinero disponible", icon:"💵", type:"computed", desc:"Acumulado menos reservas configuradas."},
  progress:{label:"Progreso hacia el objetivo", icon:"📈", type:"computed", desc:"Porcentaje del objetivo del día 21 alcanzado."},
  access:{label:"Pantalla de acceso", icon:"🔐", type:"feature", desc:"Protege la apertura de EHM21 con PIN."},
  darkDesign:{label:"Diseño oscuro moderno", icon:"💚", type:"feature", desc:"Activa el tema oscuro con detalles modernos."}
};

const defaults = {
  values:{dailyIncome:0, day21Goal:0, rent:0, card:0, monotributo:0, fuel:0, food:0, savings:0},
  enabled:{dailyIncome:true,totalAccumulated:true,day21Goal:true,rent:true,card:true,monotributo:true,fuel:true,food:true,savings:true,available:true,progress:true,access:false,darkDesign:true},
  settings:{currency:"ARS", pin:"", authenticated:false, appName:"EHM21"},
  history:[]
};

function load(){
  try{
    const s=JSON.parse(localStorage.getItem(KEY)||"null");
    return {...structuredClone(defaults),...s,values:{...defaults.values,...(s?.values||{})},enabled:{...defaults.enabled,...(s?.enabled||{})},settings:{...defaults.settings,...(s?.settings||{})},history:Array.isArray(s?.history)?s.history:[]};
  }catch{return structuredClone(defaults)}
}
let state=load();

function save(){localStorage.setItem(KEY,JSON.stringify(state));}
function money(n){return new Intl.NumberFormat("es-AR",{style:"currency",currency:state.settings.currency||"ARS",maximumFractionDigits:0}).format(Number(n)||0)}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function toast(msg){const d=document.createElement("div");d.className="toast";d.textContent=msg;document.body.appendChild(d);setTimeout(()=>d.remove(),1800)}
function total(){return state.history.reduce((a,x)=>a+Number(x.amount||0),0)}
function reserved(){return ["rent","card","monotributo","fuel","food","savings"].reduce((a,k)=>a+(state.enabled[k]?Number(state.values[k]||0):0),0)}
function progress(){const goal=Number(state.values.day21Goal||0); return goal?Math.min(100,Math.max(0,total()/goal*100)):0}
function setTheme(){
  document.body.classList.toggle("light",!state.enabled.darkDesign);
}
function visibleCards(){
  return Object.keys(MODULES).filter(k=>state.enabled[k] && !["access","darkDesign"].includes(k));
}

function render(){
  setTheme();
  if(state.enabled.access && state.settings.pin && !state.settings.authenticated){renderLogin();return}
  renderHome();
}
function renderLogin(){
  document.getElementById("app").innerHTML=`<div class="screen"><div class="login">
    <div class="eyebrow">Control financiero</div><h1>EHM<span>21</span></h1>
    <p>Ingresá tu PIN para acceder a tu cuenta.</p>
    <div class="field"><label>PIN</label><input id="pinInput" type="password" inputmode="numeric" maxlength="12" placeholder="Tu PIN"></div>
    <button class="primary" onclick="login()">Entrar</button>
    <button class="secondary" onclick="openSettings()">Configuración</button>
  </div></div>`;
}
function login(){
  const v=document.getElementById("pinInput").value;
  if(v===state.settings.pin){state.settings.authenticated=true;save();render()}else toast("PIN incorrecto");
}
function renderHome(){
  const cards=visibleCards();
  let html=`<div class="shell"><div class="topbar"><div class="brand">EHM<span>21</span></div><div class="top-actions">
    <button class="icon-btn" onclick="openSettings()" aria-label="Configuración">⚙️</button>
    <button class="icon-btn" onclick="confirmReset()" aria-label="Resetear cuenta">↻</button>
  </div></div>`;
  const mainValue=state.enabled.totalAccumulated?money(total()):money(state.values.dailyIncome);
  html+=`<section class="hero"><div class="eyebrow">Dinero registrado</div><div class="hero-value">${mainValue}</div><div class="hero-sub">${state.enabled.totalAccumulated?"Total de ingresos acumulados":"Ingreso del día"}</div></section>`;
  if(!cards.length) html+=`<div class="empty">No hay módulos visibles. Abrí ⚙️ Configuración para agregar los datos que quieras.</div>`;
  else {
    html+=`<div class="grid">`;
    for(const k of cards){
      const m=MODULES[k];
      if(k==="totalAccumulated") html+=computedCard(k,m,money(total()),"Ingresos registrados");
      else if(k==="available") html+=computedCard(k,m,money(total()-reserved()),"Acumulado − reservas");
      else if(k==="progress") html+=progressCard();
      else if(k==="dailyIncome") html+=inputCard(k,m,state.values[k]);
      else html+=inputCard(k,m,state.values[k]);
    }
    html+=`</div>`;
  }
  html+=`<div class="section-title">Actividad</div>`;
  html+=`<div class="card full"><div class="card-head"><span class="card-label">Últimos ingresos</span><span class="card-label">${state.history.length}</span></div>`;
  if(!state.history.length) html+=`<p class="note">Todavía no registraste ingresos.</p>`;
  else html+=state.history.slice(-5).reverse().map((x,i)=>`<div class="setting"><div><strong>${money(x.amount)}</strong><span>${esc(x.date)}</span></div><button class="small-btn" onclick="removeIncome(${state.history.length-1-i})">×</button></div>`).join("");
  html+=`</div><p class="note" style="margin-top:14px">Tus datos se guardan localmente en este dispositivo. El botón ↻ devuelve los valores y registros a cero.</p></div>`;
  document.getElementById("app").innerHTML=html;
}
function inputCard(k,m,val){
  return `<div class="card"><div class="card-head"><span class="card-label">${m.icon} ${m.label}</span></div>
    <div class="card-value">${money(val)}</div><div class="card-edit"><input class="money-input" id="in-${k}" type="number" min="0" step="1" value="${Number(val)||0}" aria-label="${m.label}">
    <button class="small-btn" onclick="updateValue('${k}')">OK</button></div></div>`;
}
function computedCard(k,m,val,sub){return `<div class="card"><div class="card-head"><span class="card-label">${m.icon} ${m.label}</span></div><div class="card-value">${val}</div><div class="note">${sub}</div></div>`}
function progressCard(){
  const p=progress();
  return `<div class="card full"><div class="card-head"><span class="card-label">📈 Progreso hacia el objetivo</span><strong>${p.toFixed(0)}%</strong></div><div class="progress"><div style="width:${p}%"></div></div><div class="note" style="margin-top:8px">${money(total())} de ${money(state.values.day21Goal)} registrados</div></div>`;
}
function updateValue(k){
  const el=document.getElementById("in-"+k); const v=Math.max(0,Number(el.value)||0);
  if(k==="dailyIncome"){
    state.values.dailyIncome=v;
    if(v>0){
      state.history.push({amount:v,date:new Date().toLocaleString("es-AR")});
    }
  }else state.values[k]=v;
  save();toast("Guardado");render();
}
function removeIncome(i){state.history.splice(i,1);save();render()}
function confirmReset(){
  if(confirm("¿Resetear la cuenta? Se pondrán en 0 los valores agregados y se borrará el historial de ingresos.")){
    for(const k of Object.keys(state.values)) state.values[k]=0;
    state.history=[]; state.settings.authenticated=false; save();toast("Cuenta reseteada");render();
  }
}
function openSettings(){
  document.body.insertAdjacentHTML("beforeend",`<div class="modal-back" id="modal"><div class="modal">
    <div class="modal-top"><h2>⚙️ Configuración</h2><button class="icon-btn" onclick="closeSettings()">×</button></div>
    <div class="section-title">Datos y módulos</div>
    ${Object.entries(MODULES).map(([k,m])=>`<div class="setting"><div><strong>${m.icon} ${m.label}</strong><span>${m.desc}</span></div><button class="switch ${state.enabled[k]?"on":""}" onclick="toggleModule('${k}',this)"><i></i></button></div>`).join("")}
    <div class="section-title">Aplicación</div>
    <div class="field"><label>Nombre de la aplicación</label><input id="appName" value="${esc(state.settings.appName)}" maxlength="30"></div>
    <div class="field"><label>Moneda</label><select id="currency"><option value="ARS" ${state.settings.currency==="ARS"?"selected":""}>ARS — Peso argentino</option><option value="USD" ${state.settings.currency==="USD"?"selected":""}>USD — Dólar estadounidense</option><option value="CLP" ${state.settings.currency==="CLP"?"selected":""}>CLP — Peso chileno</option></select></div>
    <div class="section-title">Acceso</div>
    <div class="field"><label>PIN de acceso (dejalo vacío para no usar PIN)</label><input id="pin" type="password" inputmode="numeric" maxlength="12" value="${esc(state.settings.pin)}" placeholder="Opcional"></div>
    <div class="row"><button class="secondary" onclick="saveSettings()">Guardar cambios</button><button class="secondary danger" onclick="logout()">Bloquear</button></div>
    <p class="note" style="margin-top:14px">Si activás “Pantalla de acceso” pero no configurás un PIN, EHM21 no bloqueará la entrada hasta que establezcas uno.</p>
  </div></div>`);
}
function closeSettings(){document.getElementById("modal")?.remove()}
function toggleModule(k,btn){state.enabled[k]=!state.enabled[k];btn.classList.toggle("on",state.enabled[k]);btn.querySelector("i").style.transform=state.enabled[k]?"translateX(20px)":"";save();setTheme();render();openSettings()}
function saveSettings(){
  state.settings.appName=document.getElementById("appName").value.trim()||"EHM21";
  state.settings.currency=document.getElementById("currency").value;
  state.settings.pin=document.getElementById("pin").value.trim();
  state.settings.authenticated=!(state.enabled.access && state.settings.pin);
  save();closeSettings();toast("Configuración guardada");render();
}
function logout(){state.settings.authenticated=false;save();closeSettings();render()}
render();
