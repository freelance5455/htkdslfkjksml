
const K='mon_temps_v2',NAG=10,$=id=>document.getElementById(id),pad=n=>String(n).padStart(2,'0');
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const dk=(d=new Date())=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const mins=h=>{const[a,b]=(h||'0:0').split(':').map(Number);return a*60+b},hm=m=>pad(Math.floor(m/60)%24)+':'+pad(m%60);
const nowM=()=>{const d=new Date();return d.getHours()*60+d.getMinutes()};
const sdt=t=>new Date(t.date+'T'+(t.time||'00:00')),fd=s=>new Date(s+'T12:00').toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long'});
const addD=(s,n)=>{const d=new Date(s+'T12:00');d.setDate(d.getDate()+n);return dk(d)};
const def=()=>({name:'',photo:'',sleep:{s:'22:30',e:'06:30'},snd:true,tasks:[],goals:[]});
function norm(x){x=x||{};return{...def(),name:x.name||x.profile?.name||'',photo:x.photo||x.profile?.photo||'',sleep:{s:x.sleep?.s||x.sleep?.start||'22:30',e:x.sleep?.e||x.sleep?.end||'06:30'},snd:x.snd!==false,
tasks:(x.tasks||[]).map(t=>({id:t.id||uid(),title:String(t.title||'Sans titre'),date:t.date||dk(),time:t.time||'',dur:+(t.dur||t.duration)||30,pri:t.pri||t.priority||'normal',cat:t.cat||t.category||'Personnel',rep:t.rep||t.repeat||'none',remind:+t.remind||0,persist:t.persist!==false&&t.persistent!==false,type:t.type||'task',done:!!t.done,cancelled:!!t.cancelled,goal:t.goal||'',doneAt:t.doneAt||t.completedAt||0,al:0,startedAt:0})),
goals:(x.goals||[]).map(g=>({id:g.id||uid(),title:String(g.title||''),deadline:g.deadline||'',progress:+g.progress||0,step:g.step||g.monthly||''}))}}
let D;try{D=norm(JSON.parse(localStorage.getItem(K)||localStorage.getItem('mon_temps_v1')||'null'))}catch(e){D=def()}
let snap=null,pd=new Date(),mf='u',page='today',lastM=-1;
function save(){try{localStorage.setItem(K,JSON.stringify(D))}catch(e){toast('Stockage plein : exporte tes données.')}}
function act(fn,msg){snap=JSON.stringify(D);fn();save();render();toast(msg,true)}
function undo(){if(snap){D=norm(JSON.parse(snap));snap=null;save();render();toast('Action annulée')}}
let tmr;function toast(m,u){$('tm').textContent=m;$('tu').style.display=u?'':'none';$('toast').classList.add('show');clearTimeout(tmr);tmr=setTimeout(()=>$('toast').classList.remove('show'),u?5000:2400)}
const late=t=>!t.done&&!t.cancelled&&new Date(t.date+'T'+(t.time||'23:59'))<new Date();
const active=t=>!t.done&&!t.cancelled;
const byPri=(a,b)=>({critical:0,important:1,normal:2,low:3}[a.pri]-{critical:0,important:1,normal:2,low:3}[b.pri]);
const byTime=(a,b)=>(a.date+(a.time||'99:99')).localeCompare(b.date+(b.time||'99:99'));
const bedM=()=>{let b=mins(D.sleep.s);if(b<mins(D.sleep.e))b+=1440;return b};
/* ---- actions ---- */
const T=id=>D.tasks.find(t=>t.id===id);
function nextRep(t){let n=t.date,tod=dk();for(let i=0;i<400;i++){const d=new Date(n+'T12:00');if(t.rep==='daily')d.setDate(d.getDate()+1);else if(t.rep==='weekly')d.setDate(d.getDate()+7);else d.setMonth(d.getMonth()+1);n=dk(d);if(n>=tod)break}return n}
function done(id){closeA();act(()=>{const t=T(id);t.done=true;t.doneAt=Date.now();if(t.rep!=='none')D.tasks.push({...t,id:uid(),date:nextRep(t),done:false,doneAt:0,al:0,startedAt:0})},'Terminé ✓')}
function reopen(id){act(()=>{const t=T(id);t.done=false;t.doneAt=0},'Remis à faire')}
function snooze(id,m){closeA();act(()=>{const t=T(id),d=new Date(Date.now()+m*6e4);t.date=dk(d);t.time=hm(d.getHours()*60+d.getMinutes());t.al=0},'Reporté de '+m+' min')}
function cancel(id){closeA();closeM();act(()=>{T(id).cancelled=true},'Annulé')}
function del(id){closeM();act(()=>{D.tasks=D.tasks.filter(t=>t.id!==id)},'Supprimé')}
function start(id){act(()=>{T(id).startedAt=Date.now()},'C’est parti')}
/* ---- alerts ---- */
let AC;function beep(){if(!D.snd)return;try{AC=AC||new(window.AudioContext||webkitAudioContext)();[0,.3,.6].forEach((o,i)=>{const s=AC.createOscillator(),g=AC.createGain(),t0=AC.currentTime+o;s.frequency.value=i==1?880:660;s.connect(g);g.connect(AC.destination);g.gain.setValueAtTime(.25,t0);g.gain.exponentialRampToValueAtTime(.001,t0+.22);s.start(t0);s.stop(t0+.24)})}catch(e){}}
function sysNotif(t,body){try{if(Notification.permission!=='granted')return;const o={body,tag:t.id,renotify:true,vibrate:[200,100,200]};navigator.serviceWorker?.getRegistration().then(r=>r?r.showNotification(t.title,o):new Notification(t.title,o)).catch(()=>{})}catch(e){}}
function ring(t){const d=Math.round((sdt(t)-Date.now())/6e4),w=d>0?'Commence dans '+d+' min':d===0?'C’est maintenant':'En retard de '+(-d)+' min';
$('ash').innerHTML=`<h2>🔔 ${esc(t.title)}</h2><p>${w} · ${t.time}</p><p class="sm">Je te relance toutes les ${NAG} min tant que tu n’as pas répondu.</p><div class="ac"><button class="b p" onclick="done('${t.id}')">✓ Fait</button><button class="b w" onclick="snooze('${t.id}',10)">+10 min</button><button class="b w" onclick="snooze('${t.id}',30)">+30 min</button><button class="b w" onclick="pickSnooze('${t.id}')">Reporter…</button><button class="b" onclick="advance('${t.id}')">⏩ Plus tôt</button><button class="b x" onclick="cancel('${t.id}')">Annuler</button></div>`;
$('alert').classList.add('show');beep();try{navigator.vibrate?.([300,150,300])}catch(e){}sysNotif(t,w)}
const closeA=()=>$('alert').classList.remove('show');
function check(){if(!$('alert').classList.contains('show')){const n=Date.now();for(const t of D.tasks){if(!active(t)||!t.time)continue;if(n>=sdt(t)-t.remind*6e4&&(!t.al||(t.persist&&n-t.al>=NAG*6e4))){t.al=n;save();ring(t);break}}}tick()}
/* ---- modals ---- */
const closeM=()=>$('mod').classList.remove('show');function openM(h){$('sh').innerHTML=h;$('mod').classList.add('show')}
const opts=(l,v)=>l.map(([k,n])=>`<option value="${k}" ${String(v)===String(k)?'selected':''}>${n}</option>`).join('');
function openT(type,id,goal){const t=id?T(id):{title:'',date:dk(),time:'',dur:30,pri:'normal',cat:'Personnel',rep:'none',remind:15,persist:true,type,goal:goal||''};
openM(`<h2>${id?'Modifier':'Nouveau'}</h2><form onsubmit="event.preventDefault();saveT('${id||''}')">
<label>Type</label><select id="fy">${opts([['task','Tâche'],['reminder','Rappel'],['note','Note à retenir']],t.type)}</select>
<label>Titre</label><input id="ft" required value="${esc(t.title)}" placeholder="Ex. Appeler le professeur">
<div class="g2"><div><label>Date</label><input id="fd" type="date" required value="${t.date}"></div><div><label>Heure (facultatif)</label><input id="fh" type="time" value="${t.time}"></div></div>
<div class="g2"><div><label>Durée (min)</label><input id="fu" type="number" min="1" value="${t.dur}"></div><div><label>Me prévenir</label><select id="fr">${opts([[0,'À l’heure'],[5,'5 min avant'],[15,'15 min avant'],[30,'30 min avant'],[60,'1 h avant'],[1440,'1 jour avant']],t.remind)}</select></div></div>
<div class="g2"><div><label>Priorité</label><select id="fp">${opts([['low','Faible'],['normal','Normale'],['important','Importante'],['critical','Critique']],t.pri)}</select></div><div><label>Répéter</label><select id="fe">${opts([['none','Jamais'],['daily','Chaque jour'],['weekly','Chaque semaine'],['monthly','Chaque mois']],t.rep)}</select></div></div>
<div class="g2"><div><label>Catégorie</label><input id="fc" value="${esc(t.cat)}"></div><div><label>Objectif lié</label><select id="fg">${opts([['','Aucun'],...D.goals.map(g=>[g.id,g.title])],t.goal)}</select></div></div>
<label>Relance</label><select id="fs">${opts([['1','Insister jusqu’à ma réponse'],['0','Un seul rappel']],t.persist?1:0)}</select>
<div class="ac"><button class="b p" type="submit">Enregistrer</button>${id?`<button class="b x" type="button" onclick="del('${id}')">Supprimer</button>`:''}<button class="b" type="button" onclick="closeM()">Fermer</button></div></form>`)}
function saveT(id){const v=i=>$(i).value;act(()=>{const t=id?T(id):{id:uid(),done:false,cancelled:false,doneAt:0};Object.assign(t,{type:v('fy'),title:v('ft').trim(),date:v('fd'),time:v('fh'),dur:+v('fu')||30,remind:+v('fr'),pri:v('fp'),rep:v('fe'),cat:v('fc').trim()||'Personnel',goal:v('fg'),persist:v('fs')==='1',al:0});if(!id)D.tasks.push(t)},'Enregistré');closeM()}
function openG(id){const g=id?D.goals.find(x=>x.id===id):{title:'',deadline:'',progress:0,step:''};
openM(`<h2>${id?'Modifier':'Nouvel'} objectif</h2><form onsubmit="event.preventDefault();saveG('${id||''}')"><label>Objectif</label><input id="gt" required value="${esc(g.title)}" placeholder="Ex. Parler anglais couramment"><label>Échéance</label><input id="gd" type="date" value="${g.deadline}"><label>Prochaine étape</label><input id="gs" value="${esc(g.step)}"><label>Progression manuelle (%) — utilisée tant qu’aucune action n’est liée</label><input id="gp" type="number" min="0" max="100" value="${g.progress}"><div class="ac"><button class="b p" type="submit">Enregistrer</button>${id?`<button class="b x" type="button" onclick="delG('${id}')">Supprimer</button>`:''}</div></form>`)}
function saveG(id){act(()=>{const g=id?D.goals.find(x=>x.id===id):{id:uid()};Object.assign(g,{title:$('gt').value.trim(),deadline:$('gd').value,step:$('gs').value,progress:Math.min(100,+$('gp').value||0)});if(!id)D.goals.push(g)},'Objectif enregistré');closeM()}
function delG(id){closeM();act(()=>{D.goals=D.goals.filter(g=>g.id!==id);D.tasks.forEach(t=>{if(t.goal===id)t.goal=''})},'Objectif supprimé')}
/* ---- views ---- */
function card(t){const l=late(t);return`<div class="c ${l?'late ':''}${t.pri} ${t.done?'dn':''}"><div class="tl"><button class="ck" aria-label="${t.done?'Rouvrir':'Terminer'}" onclick="${t.done?'reopen':'done'}('${t.id}')">${t.done?'✓':''}</button><div style="flex:1" onclick="openT('${t.type}','${t.id}')"><div class="tt">${esc(t.title)}</div><div class="sm">${t.date===dk()?'Aujourd’hui':fd(t.date)} · ${t.time||'sans heure'}${t.type==='note'?'':' · '+t.dur+' min'} · ${esc(t.cat)}${t.rep!=='none'?' · 🔁':''} ${l?'<span class="tag l">en retard</span>':''}</div></div></div>${active(t)?`<div class="ac"><button class="b p" onclick="done('${t.id}')">Fait</button><button class="b w" onclick="snooze('${t.id}',30)">+30 min</button><button class="b w" onclick="pickSnooze('${t.id}')">Reporter…</button><button class="b" onclick="advance('${t.id}')">⏩ Plus tôt</button><button class="b x" onclick="cancel('${t.id}')">Annuler</button></div>`:''}</div>`}
const gp=g=>{const l=D.tasks.filter(t=>t.goal===g.id&&!t.cancelled);return l.length?Math.round(l.filter(t=>t.done).length/l.length*100):g.progress};
function vToday(){const k=dk(),td=D.tasks.filter(t=>t.date===k&&!t.cancelled).sort(byTime),lt=D.tasks.filter(late).length,n=nowM();
const cur=D.tasks.filter(t=>active(t)&&t.date===k&&t.time&&t.type!=='note').sort(byTime).find(t=>mins(t.time)+t.dur>n);
let nowH;if(cur){const s=mins(cur.time),in_=s-n,run=in_<=0;nowH=`<div class="now"><span class="sm">${run?'EN COURS':'À SUIVRE'} · ${cur.time}</span><h3>${esc(cur.title)}</h3><div class="sm">${run?'Il reste '+(s+cur.dur-n)+' min':'Dans '+in_+' min'} · ${cur.dur} min${cur.startedAt?' · <span id="el"></span>':''}</div><div class="ac">${cur.startedAt?'':`<button class="b" onclick="start('${cur.id}')">▶ Commencer</button>`}<button class="b p" onclick="done('${cur.id}')">✓ Fait</button></div></div>`}
else nowH=`<div class="now"><span class="sm">LIBRE</span><h3>Rien de prévu pour l’instant</h3><div class="sm">Ajoute une tâche avec le bouton +.</div></div>`;
const gs=D.goals.slice(0,3).map(g=>`<div class="c"><div class="r"><b>${esc(g.title)}</b><b>${gp(g)}%</b></div><div class="bar"><i style="width:${gp(g)}%"></i></div></div>`).join('');
$('p-today').innerHTML=nowH+(lt?`<div class="c late" style="margin-top:10px" onclick="go('memo')"><b>${lt} élément${lt>1?'s':''} en retard</b><div class="sm">Touche pour les traiter dans Mémoire.</div></div>`:'')+`<h3>Aujourd’hui · ${td.filter(t=>t.done).length}/${td.length}</h3>`+(td.map(card).join('')||'<div class="em">Journée vide. Ajoute ce que tu ne dois pas oublier.</div>')+(gs?'<h3>Objectifs</h3>'+gs:'')}
function vPlan(){const k=dk(pd),td=D.tasks.filter(t=>t.date===k&&!t.cancelled),tm=td.filter(t=>t.time).sort(byTime),un=td.filter(t=>!t.time);
$('p-plan').innerHTML=`<div class="r"><button class="b" onclick="pd.setDate(pd.getDate()-1);render()">‹</button><b>${fd(k)}</b><button class="b" onclick="pd.setDate(pd.getDate()+1);render()">›</button></div>
<div class="c" style="margin-top:10px"><div class="slot"><div class="tm">${D.sleep.e}</div><div>🌅 Réveil</div></div>${tm.map(t=>`<div class="slot" onclick="openT('${t.type}','${t.id}')"><div class="tm">${t.time}</div><div style="flex:1"><div class="tt">${t.done?'✓ ':''}${esc(t.title)}</div><div class="sm">${t.dur} min · jusqu’à ${hm(mins(t.time)+t.dur)}</div></div></div>`).join('')||'<div class="em">Aucune tâche horaire.</div>'}<div class="slot" style="border:0"><div class="tm">${D.sleep.s}</div><div>🌙 Coucher</div></div></div>
${un.length?'<h3>À placer ('+un.length+')</h3>'+un.map(card).join(''):''}
<button class="b p" style="width:100%" onclick="autoPlan()">Placer mes tâches dans les créneaux libres</button><p class="sm">Utilise tes vrais horaires de sommeil et évite les tâches déjà planifiées.</p>`}
function autoPlan(){act(()=>{const k=dk(pd),b=bedM(),busy=D.tasks.filter(t=>t.date===k&&t.time&&!t.cancelled).map(t=>[mins(t.time),mins(t.time)+t.dur]);
const cur=Math.max(mins(D.sleep.e),k===dk()?Math.ceil(nowM()/5)*5:0);let n=0;
for(const t of D.tasks.filter(t=>t.date===k&&!t.time&&active(t)&&t.type!=='note').sort(byPri)){let s=cur,mv=true;while(mv){mv=false;for(const[x,y]of busy)if(s<y&&s+t.dur>x){s=y+5;mv=true}}if(s+t.dur<=b){t.time=hm(s);t.al=0;busy.push([s,s+t.dur]);n++}}
$('tm').dataset.n=n},'Planning organisé')}
function vGoals(){const a=D.goals.length?Math.round(D.goals.reduce((s,g)=>s+gp(g),0)/D.goals.length):0;
$('p-goals').innerHTML=`<div class="r"><h2>Objectifs</h2><button class="b p" onclick="openG()">+ Nouveau</button></div><div class="c"><div class="r"><b>Progression globale</b><b>${a}%</b></div><div class="bar"><i style="width:${a}%"></i></div></div>`+(D.goals.map(g=>{const l=D.tasks.filter(t=>t.goal===g.id&&!t.cancelled);return`<div class="c"><div class="r"><b>${esc(g.title)}</b><span class="tag">${gp(g)}%</span></div><div class="bar"><i style="width:${gp(g)}%"></i></div><div class="sm">${g.deadline?'Échéance : '+fd(g.deadline)+' · ':''}${l.filter(t=>t.done).length}/${l.length} actions${g.step?' · Prochaine étape : '+esc(g.step):''}</div><div class="ac"><button class="b" onclick="openG('${g.id}')">Modifier</button><button class="b p" onclick="openT('task','','${g.id}')">+ Action</button></div></div>`}).join('')||'<div class="em">Un objectif devient réel quand il a des actions. Crée le premier.</div>')}
function vMemo(){const lt=D.tasks.filter(late).sort(byTime),k=dk(),f=D.tasks.filter(t=>active(t)&&!late(t)&&(mf==='u'?t.date===k:mf==='t'?t.date===addD(k,1):t.date>k&&t.date<=addD(k,7))).sort(byTime);
$('p-memo').innerHTML=`<h2>À ne pas oublier</h2>${lt.length?`<h3 style="color:var(--bad)">En retard — rien ne disparaît tant que ce n’est pas réglé</h3>`+lt.map(card).join(''):''}
<div class="ac" style="margin:12px 0">${[['u','Aujourd’hui'],['t','Demain'],['w','7 jours']].map(([x,n])=>`<button class="b ${mf===x?'p':''}" onclick="mf='${x}';render()">${n}</button>`).join('')}</div>${f.map(card).join('')||'<div class="em">Rien à retenir sur cette période.</div>'}`}
function vStats(){const k=dk(),days=[...Array(7)].map((_,i)=>addD(k,i-6)),dn=D.tasks.filter(t=>t.done&&t.doneAt),cnt=days.map(d=>dn.filter(t=>dk(new Date(t.doneAt))===d).length),mx=Math.max(1,...cnt);
const due=D.tasks.filter(t=>t.type!=='note'&&!t.cancelled&&t.date>=days[0]&&(t.date<k||t.done||late(t))),disc=due.length?Math.round(due.filter(t=>t.done).length/due.length*100):0;
let st=0;for(let i=0;i<365;i++){const d=addD(k,-i);if(dn.some(t=>dk(new Date(t.doneAt))===d))st++;else if(i>0)break;else continue}
const cats={};D.tasks.filter(t=>t.done&&t.type!=='note').forEach(t=>cats[t.cat]=(cats[t.cat]||0)+t.dur);const tot=Object.values(cats).reduce((a,b)=>a+b,0)||1;
$('p-stats').innerHTML=`<h2>Bilan</h2><div class="g2"><div class="c"><div class="big">${disc}%</div><div class="sm">Discipline sur 7 jours<br>(seulement ce qui était dû)</div></div><div class="c"><div class="big">${st} j</div><div class="sm">Série de jours avec au moins une tâche faite</div></div><div class="c"><div class="big">${D.tasks.filter(late).length}</div><div class="sm">En retard</div></div><div class="c"><div class="big">${Math.round(Object.values(cats).reduce((a,b)=>a+b,0)/6)/10} h</div><div class="sm">Temps réellement accompli</div></div></div>
<h3>Tâches terminées, 7 derniers jours</h3><div class="c"><div class="bars">${cnt.map((c,i)=>`<div><i style="height:${c/mx*70}px"></i>${new Date(days[i]+'T12:00').toLocaleDateString('fr-FR',{weekday:'narrow'})}</div>`).join('')}</div></div>
<h3>Temps accompli par catégorie</h3><div class="c">${Object.entries(cats).map(([c,v])=>`<div><div class="r"><span>${esc(c)}</span><b>${Math.round(v/6)/10} h</b></div><div class="bar"><i style="width:${v/tot*100}%"></i></div></div>`).join('')||'<div class="em">Termine une tâche pour voir ton bilan.</div>'}</div>`}
function vSet(){$('p-set').innerHTML=`<h2>Réglages</h2><div class="c"><label>Prénom</label><input id="sn" value="${esc(D.name)}" onchange="D.name=this.value.trim();save();render()"><label>Photo</label><input type="file" accept="image/*" onchange="photo(this)"></div>
<div class="c"><b>Sommeil</b><div class="g2"><div><label>Coucher</label><input type="time" value="${D.sleep.s}" onchange="D.sleep.s=this.value;save();render()"></div><div><label>Réveil</label><input type="time" value="${D.sleep.e}" onchange="D.sleep.e=this.value;save();render()"></div></div><p class="sm">Le temps libre et le planning automatique s’appuient sur ces horaires.</p></div>
<div class="c"><b>Rappels</b><label>Son d’alerte</label><select onchange="D.snd=this.value==='1';save()">${opts([['1','Activé'],['0','Coupé']],D.snd?1:0)}</select><div class="ac"><button class="b p" onclick="Notification.requestPermission().then(p=>toast(p==='granted'?'Notifications activées':'Notifications refusées'))">Activer les notifications</button><button class="b" onclick="ring({id:'test',title:'Test de rappel',time:hm(nowM()),date:dk(),remind:0})">Tester l’alerte</button></div><p class="sm">Les alertes plein écran fonctionnent app ouverte. Elles se rattrapent à chaque réouverture.</p></div>
<div class="c"><b>Thème</b><div class="ac">${[['auto','Auto'],['light','Clair'],['dark','Sombre']].map(([x,n])=>`<button class="b" onclick="theme('${x}')">${n}</button>`).join('')}</div></div>
<div class="c"><b>Données</b><div class="ac"><button class="b p" onclick="exp()">Exporter</button></div><label>Importer une sauvegarde (v1 ou v2)</label><input type="file" accept="application/json" onchange="imp(this)"><div class="ac"><button class="b x" onclick="if(confirm('Tout supprimer ?')){D=def();save();render()}">Tout effacer</button></div></div>`}
function theme(x){if(x==='auto')document.documentElement.removeAttribute('data-theme');else document.documentElement.dataset.theme=x;try{localStorage.setItem(K+'t',x)}catch(e){}}
function photo(i){const f=i.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=c.height=128;const m=Math.min(im.width,im.height);c.getContext('2d').drawImage(im,(im.width-m)/2,(im.height-m)/2,m,m,0,0,128,128);D.photo=c.toDataURL('image/jpeg',.8);save();render()};im.src=r.result};r.readAsDataURL(f)}
function exp(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(D,null,1)],{type:'application/json'}));a.download='mon-temps-'+dk()+'.json';a.click()}
function imp(i){const f=i.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const j=JSON.parse(r.result);if(!Array.isArray(j.tasks))throw 0;snap=JSON.stringify(D);D=norm(j);save();render();toast('Sauvegarde restaurée',true)}catch(e){toast('Fichier invalide : il doit venir de Mon Temps.')}};r.readAsText(f)}
/* ---- shell ---- */
const NAVS=[['today','Aujourd’hui','◉'],['plan','Planning','▦'],['goals','Objectifs','◎'],['memo','Mémoire','✦'],['stats','Bilan','▥'],['set','Réglages','⚙']];
$('nav').innerHTML=NAVS.map(([p,n,i])=>`<button data-p="${p}" onclick="go('${p}')"><b>${i}</b>${n}</button>`).join('');
function go(p){page=p;render();scrollTo(0,0)}
function head(){const w=mins(D.sleep.e),b=bedM(),n=Math.max(w,Math.min(b,nowM())),pc=m=>Math.max(0,Math.min(100,(m-w)/(b-w)*100));
$('rail').innerHTML=D.tasks.filter(t=>t.date===dk()&&t.time&&!t.cancelled).map(t=>`<i class="${t.done?'d':late(t)?'l':''}" style="left:${pc(mins(t.time))}%"></i>`).join('')+`<b style="left:${pc(n)}%"></b>`;
const rem=Math.max(0,b-Math.max(nowM(),w)),use=D.tasks.filter(t=>t.date===dk()&&active(t)&&t.type!=='note').reduce((s,t)=>s+t.dur,0),fr=Math.max(0,rem-use);
$('free').textContent=Math.floor(fr/60)+' h '+pad(fr%60)+' libres';$('wk').textContent='🌅 '+D.sleep.e;$('bd').textContent=D.sleep.s+' 🌙';
$('hi').textContent='Bonjour'+(D.name?' '+D.name:'');$('dt').textContent=fd(dk());
$('av').outerHTML=D.photo?`<img id="av" class="av" src="${D.photo}" alt="">`:`<div id="av" class="av">${esc((D.name||'M')[0].toUpperCase())}</div>`}
function render(){document.querySelectorAll('.pg').forEach(e=>e.classList.toggle('on',e.id==='p-'+page));document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.p===page));
({today:vToday,plan:vPlan,goals:vGoals,memo:vMemo,stats:vStats,set:vSet})[page]();head()}
function tick(){const d=new Date();$('clk').textContent=pad(d.getHours())+':'+pad(d.getMinutes());if(d.getMinutes()!==lastM&&!$('mod').classList.contains('show')){lastM=d.getMinutes();render()}
const c=D.tasks.find(t=>t.startedAt&&active(t)),e=$('el');if(c&&e){const s=Math.floor((Date.now()-c.startedAt)/1000);e.textContent='⏱ '+pad(Math.floor(s/60))+':'+pad(s%60)}}
try{const th=localStorage.getItem(K+'t');if(th)theme(th)}catch(e){}
setInterval(check,15000);setInterval(tick,1000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)check()});
render();check();
if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
