'use strict';
const $ = id => document.getElementById(id);
const stage = $('stage'), source = $('source'), overlay = $('overlay'), direct = $('direct');
const octx = overlay.getContext('2d');
const eyes = [...direct.querySelectorAll('.eye')];

/* ---------- Sozlamalar ---------- */
const DEFAULTS = {
  mode: 'lens', quality: '720', camera: '',
  size: 0.82, aspect: 0.95, dist: 0.48, offY: 0, corner: 0.12, zoom: 1.0,
  k1: 0.20, k2: 0.08, ca: 0, sharp: 0.25, bright: 1.0, render: 1.0, grid: false, lowlat: false,
  camZoom: null, torch: false, expMode: 'auto', expTime: null, iso: null,
  ar: false, fov: 70, stats: true, cross: false
};
const STORE = 'vrarkamera.v1';
let S = Object.assign({}, DEFAULTS);
try { Object.assign(S, JSON.parse(localStorage.getItem(STORE) || '{}')); } catch (e) {}
let saveTimer = 0;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => { try { localStorage.setItem(STORE, JSON.stringify(S)); } catch (e) {} }, 250);
}

const QUALITY = {
  '540':  { w: 960,  h: 540,  label: 'Eng tez (960×540)' },
  '720':  { w: 1280, h: 720,  label: 'Muvozanat (1280×720)' },
  '1080': { w: 1920, h: 1080, label: 'Eng tiniq (1920×1080)' }
};

let stream = null, track = null, running = false, devices = [];
let W = 0, H = 0, DPR = 1;

function toast(msg, ms = 2600) {
  const t = $('toast');
  t.textContent = msg; t.hidden = false;
  clearTimeout(t._t); t._t = setTimeout(() => t.hidden = true, ms);
}

/* ---------- Kamera ---------- */
function stopCamera() {
  if (track) track.onended = null;
  if (stream) stream.getTracks().forEach(t => t.stop());
  stream = track = null;
  source.srcObject = null;
  direct.querySelectorAll('video').forEach(v => v.srcObject = null);
}

function errorText(e) {
  const n = e && e.name;
  if (n === 'NoApi') return 'Bu APK/brauzer kameraga yoʻl bermayapti. APK builderda Camera ruxsatini yoqib, qayta yigʻing.';
  if (n === 'NotAllowedError' || n === 'SecurityError') return 'Kameraga ruxsat berilmadi. Telefon: Sozlamalar → Ilovalar → shu ilova → Ruxsatlar → Kamera → Ruxsat berish. APK builderda ham Camera yoqilgan boʻlsin.';
  if (n === 'NotReadableError') return 'Kamera band. Boshqa kamera ilovalarini yoping va qayta urinib koʻring.';
  if (n === 'NotFoundError') return 'Kamera topilmadi.';
  return 'Kamera xatosi: ' + (n || '') + ' ' + ((e && e.message) || '');
}

let camJob = Promise.resolve();
function startCamera() {          // ketma-ket ishlaydi: ikkita kamera birdan ochilmaydi
  const job = camJob.then(openCamera);
  camJob = job.catch(() => {});
  return job;
}

async function openCamera() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw { name: 'NoApi' };
  stopCamera();
  const q = QUALITY[S.quality] || QUALITY['720'];
  const base = { width: { ideal: q.w }, height: { ideal: q.h }, frameRate: { ideal: 60 } };
  const attempts = [];
  if (S.camera) attempts.push(Object.assign({ deviceId: { exact: S.camera } }, base));
  attempts.push(Object.assign({ facingMode: { ideal: 'environment' } }, base));
  attempts.push({ facingMode: { ideal: 'environment' } });
  attempts.push(true);
  let lastErr;
  for (const video of attempts) {
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: false, video }); break; }
    catch (e) {
      lastErr = e;
      if (e.name === 'NotAllowedError' || e.name === 'SecurityError') break;
    }
  }
  if (!stream) throw lastErr;
  if (!running || document.hidden) { stopCamera(); return; }
  track = stream.getVideoTracks()[0];
  try { track.contentHint = 'motion'; } catch (e) {}
  track.onended = () => { if (running) { toast('Kamera uzildi, qayta ulanmoqda…'); setTimeout(restartCamera, 600); } };
  for (const v of [source, ...direct.querySelectorAll('video')]) {
    v.muted = true; v.srcObject = stream;
    v.play().catch(() => {});
  }
  await applyCameraControls();
  try { devices = (await navigator.mediaDevices.enumerateDevices()).filter(d => d.kind === 'videoinput'); } catch (e) {}
  if (!$('panel').hidden) buildRows();
  startFrameLoop();
}

async function restartCamera() {
  if (!running) return;
  try { await startCamera(); } catch (e) { exitView(errorText(e)); }
}

function caps() { try { return (track && track.getCapabilities && track.getCapabilities()) || {}; } catch (e) { return {}; } }

async function constrain(c) {
  if (!track) return;
  try { await track.applyConstraints({ advanced: [c] }); } catch (e) {}
}

async function applyCameraControls() {
  const c = caps();
  if (c.focusMode && c.focusMode.includes('continuous')) await constrain({ focusMode: 'continuous' });
  if (c.zoom && S.camZoom != null) await constrain({ zoom: clamp(S.camZoom, c.zoom.min, c.zoom.max) });
  if (c.torch) await constrain({ torch: !!S.torch });
  if (c.exposureMode) {
    if (S.expMode === 'manual' && c.exposureMode.includes('manual') && c.exposureTime) {
      const m = { exposureMode: 'manual' };
      m.exposureTime = clamp(S.expTime ?? Math.min(80, c.exposureTime.max), c.exposureTime.min, c.exposureTime.max);
      if (c.iso) m.iso = clamp(S.iso ?? Math.min(800, c.iso.max), c.iso.min, c.iso.max);
      await constrain(m);
    } else if (c.exposureMode.includes('continuous')) await constrain({ exposureMode: 'continuous' });
  }
}

/* ---------- Oʻlchamlar ---------- */
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

// Bitta koʻz oynasi (CSS pikselda). i = 0 chap, 1 oʻng
function eyeRect(i) {
  const h = H * S.size;
  const w = Math.min(h * S.aspect, W);
  const cx = W / 2 + (i ? 1 : -1) * W * S.dist / 2;
  const cy = H / 2 + H * S.offY;
  const vw = source.videoWidth || 1280, vh = source.videoHeight || 720;
  const s = Math.max(w / vw, h / vh) * S.zoom;
  return { cx, cy, w, h, iw: vw * s, ih: vh * s, radius: Math.min(w, h) * S.corner };
}

function resize() {
  W = stage.clientWidth || innerWidth; H = stage.clientHeight || innerHeight;
  DPR = Math.min(window.devicePixelRatio || 1, 3);
  const cw = Math.round(W * DPR * S.render), ch = Math.round(H * DPR * S.render);
  if (glc && (glc.width !== cw || glc.height !== ch)) { glc.width = cw; glc.height = ch; }
  const od = Math.min(DPR, 2);
  overlay.width = Math.round(W * od); overlay.height = Math.round(H * od);
  octx.setTransform(od, 0, 0, od, 0, 0);
  layout();
  $('rotate').hidden = !(running && innerHeight > innerWidth && !rotateDismissed);
}

function layout() {
  if (!running) return;
  if (S.mode === 'direct') {
    eyes.forEach((el, i) => {
      const r = eyeRect(i), x0 = i * W / 2;
      Object.assign(el.style, { left: (r.cx - r.w / 2 - x0) + 'px', top: (r.cy - r.h / 2) + 'px', width: r.w + 'px', height: r.h + 'px', borderRadius: r.radius + 'px', filter: S.bright === 1 ? 'none' : `brightness(${S.bright})` });
      Object.assign(el.firstElementChild.style, { width: r.iw + 'px', height: r.ih + 'px', left: (r.w - r.iw) / 2 + 'px', top: (r.h - r.ih) / 2 + 'px' });
    });
  } else drawGL();
  drawOverlay();
}

/* ---------- WebGL (linza tuzatishli rejim) ---------- */
let glc = $('gl'), gl = null, U = {}, tex = null;

const VS = 'attribute vec2 a;void main(){gl_Position=vec4(a,0.,1.);}';
const FS = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTex;
uniform vec2 uCenter,uHalf,uImg,uTexel;
uniform float uK1,uK2,uCa,uSharp,uBright,uRadius,uGrid;
vec2 toUv(vec2 q){return vec2(0.5+q.x/uImg.x,0.5-q.y/uImg.y);}
void main(){
  vec2 p=gl_FragCoord.xy-uCenter;
  vec2 d=abs(p)-uHalf+uRadius;
  float edge=length(max(d,0.))+min(max(d.x,d.y),0.)-uRadius;
  if(edge>0.){gl_FragColor=vec4(0.,0.,0.,1.);return;}
  vec2 n=p/min(uHalf.x,uHalf.y);
  float r2=dot(n,n);
  vec2 q=p*(1.+uK1*r2+uK2*r2*r2);
  vec2 uv=toUv(q);
  vec3 c=vec3(0.);
  if(uv.x>=0.&&uv.x<=1.&&uv.y>=0.&&uv.y<=1.){
    c=texture2D(uTex,uv).rgb;
    if(uSharp>0.){
      vec3 s=texture2D(uTex,uv+vec2(uTexel.x,0.)).rgb+texture2D(uTex,uv-vec2(uTexel.x,0.)).rgb
            +texture2D(uTex,uv+vec2(0.,uTexel.y)).rgb+texture2D(uTex,uv-vec2(0.,uTexel.y)).rgb;
      c+=(c*4.-s)*uSharp*0.35;
    }
    if(uCa!=0.){
      vec3 base=texture2D(uTex,uv).rgb;
      c.r+=texture2D(uTex,toUv(q*(1.-uCa*r2))).r-base.r;
      c.b+=texture2D(uTex,toUv(q*(1.+uCa*r2))).b-base.b;
    }
    c*=uBright;
  }
  if(uGrid>0.5){
    float step=min(uHalf.x,uHalf.y)/4.;
    vec2 g=abs(mod(q+step*0.5,step)-step*0.5);
    c*=0.45;
    if(min(g.x,g.y)<1.5)c=vec3(0.2,1.,0.6);
  }
  gl_FragColor=vec4(c,1.);
}`;

function initGL() {
  const opt = { alpha: false, antialias: false, depth: false, stencil: false, preserveDrawingBuffer: false, powerPreference: 'high-performance', desynchronized: !!S.lowlat };
  gl = glc.getContext('webgl', opt);
  if (!gl) return false;
  if (!glc._bound) {
    glc._bound = true;
    glc.addEventListener('webglcontextlost', e => { if (e.target !== glc) return; e.preventDefault(); gl = null; });
    glc.addEventListener('webglcontextrestored', e => { if (e.target === glc && initGL()) layout(); });
  }
  const sh = (type, src) => {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) console.error(gl.getShaderInfoLog(s));
    return s;
  };
  const pr = gl.createProgram();
  gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS));
  gl.linkProgram(pr);
  if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) { console.error(gl.getProgramInfoLog(pr)); gl = null; return false; }
  gl.useProgram(pr);
  const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  const a = gl.getAttribLocation(pr, 'a');
  gl.enableVertexAttribArray(a); gl.vertexAttribPointer(a, 2, gl.FLOAT, false, 0, 0);
  ['uCenter', 'uHalf', 'uImg', 'uTexel', 'uK1', 'uK2', 'uCa', 'uSharp', 'uBright', 'uRadius', 'uGrid'].forEach(n => U[n] = gl.getUniformLocation(pr, n));
  tex = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tex);
  for (const [k, v] of [[gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE], [gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE], [gl.TEXTURE_MIN_FILTER, gl.LINEAR], [gl.TEXTURE_MAG_FILTER, gl.LINEAR]]) gl.texParameteri(gl.TEXTURE_2D, k, v);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, 1, 1, 0, gl.RGB, gl.UNSIGNED_BYTE, new Uint8Array(3));
  hasFrame = false;
  return true;
}

// "Past kechikish" almashsa, canvas qayta yaratiladi
function rebuildGL() {
  const n = glc.cloneNode(false);
  const old = gl && gl.getExtension('WEBGL_lose_context');
  glc.replaceWith(n); glc = n;
  if (old) old.loseContext();
  gl = null;
  setMode();
}

let hasFrame = false;
function upload() {
  if (!gl || source.readyState < 2 || !source.videoWidth) return;
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, source);
  hasFrame = true;
}

function drawGL() {
  if (!gl || S.mode !== 'lens') return;
  const cw = glc.width, ch = glc.height, k = cw / W;
  gl.disable(gl.SCISSOR_TEST);
  gl.viewport(0, 0, cw, ch); gl.clearColor(0, 0, 0, 1); gl.clear(gl.COLOR_BUFFER_BIT);
  if (!hasFrame) return;
  gl.enable(gl.SCISSOR_TEST);
  for (let i = 0; i < 2; i++) {
    const r = eyeRect(i);
    const half = Math.floor(cw / 2);
    gl.scissor(i ? half : 0, 0, i ? cw - half : half, ch);
    gl.uniform2f(U.uCenter, r.cx * k, ch - r.cy * k);
    gl.uniform2f(U.uHalf, r.w * k / 2, r.h * k / 2);
    gl.uniform2f(U.uImg, r.iw * k, r.ih * k);
    gl.uniform2f(U.uTexel, 1 / (source.videoWidth || 1), 1 / (source.videoHeight || 1));
    gl.uniform1f(U.uK1, S.k1); gl.uniform1f(U.uK2, S.k2); gl.uniform1f(U.uCa, S.ca);
    gl.uniform1f(U.uSharp, S.sharp); gl.uniform1f(U.uBright, S.bright);
    gl.uniform1f(U.uRadius, r.radius * k); gl.uniform1f(U.uGrid, S.grid ? 1 : 0);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }
}

function setMode() {
  const lens = S.mode === 'lens';
  if (lens && !gl && !initGL()) { S.mode = 'direct'; toast('WebGL ishlamadi, “Eng tez” rejimga oʻtildi'); }
  glc.hidden = S.mode !== 'lens';
  direct.hidden = S.mode !== 'direct';
  if (running) direct.querySelectorAll('video').forEach(v => v.play().catch(() => {}));
  resize();
}

/* ---------- Kadrlar sikli: faqat yangi kadr kelganda chiziladi ---------- */
let loopId = 0, frames = 0, fps = 0, latency = null, fpsT = performance.now(), lastCb = 0, sizeKey = '';

function onFrame(meta, now) {
  frames++;
  if (meta && meta.captureTime && meta.expectedDisplayTime) {
    const l = meta.expectedDisplayTime - meta.captureTime;
    if (l > 0 && l < 2000) latency = latency == null ? l : latency * 0.9 + l * 0.1;
  }
  const key = source.videoWidth + 'x' + source.videoHeight;
  if (key !== sizeKey) { sizeKey = key; layout(); }
  if (S.mode === 'lens') {
    try { upload(); drawGL(); }
    catch (e) { console.error(e); S.mode = 'direct'; setMode(); toast('Linza rejimi bu telefonda ishlamadi, “Eng tez” rejim yoqildi'); }
  }
}

function startFrameLoop() {
  const id = ++loopId;
  frames = 0; latency = null; sizeKey = ''; fpsT = performance.now(); lastCb = 0;
  const hasRVFC = 'requestVideoFrameCallback' in HTMLVideoElement.prototype;
  if (hasRVFC) {
    const cb = (now, meta) => {
      if (id !== loopId) return;
      lastCb = performance.now();
      onFrame(meta, now);
      source.requestVideoFrameCallback(cb);
    };
    source.requestVideoFrameCallback(cb);
  }
  let lastTime = -1;
  const tick = now => {
    if (id !== loopId) return;
    // zaxira yoʻl: rVFC yoʻq yoki 500 ms jim boʻlsa
    if ((!hasRVFC || now - lastCb > 500) && source.currentTime !== lastTime) { lastTime = source.currentTime; onFrame(null, now); }
    if (now - fpsT >= 1000) { fps = Math.round(frames * 1000 / (now - fpsT)); frames = 0; fpsT = now; if (!S.ar) drawOverlay(); }
    if (S.ar) drawOverlay();
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

/* ---------- AR: giroskop bilan fazoda turadigan kub ---------- */
let R = null, anchor = null, orientationSeen = false;

function rotationMatrix(a, b, g) {           // qurilma -> dunyo (Z tepaga)
  const d = Math.PI / 180;
  const cA = Math.cos(a * d), sA = Math.sin(a * d), cB = Math.cos(b * d), sB = Math.sin(b * d), cG = Math.cos(g * d), sG = Math.sin(g * d);
  return [
    [cA * cG - sA * sB * sG, -sA * cB, cA * sG + sA * sB * cG],
    [sA * cG + cA * sB * sG,  cA * cB, sA * sG - cA * sB * cG],
    [-cB * sG,                sB,      cB * cG]
  ];
}
const mul = (M, v) => [0, 1, 2].map(i => M[i][0] * v[0] + M[i][1] * v[1] + M[i][2] * v[2]);
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

addEventListener('deviceorientation', e => {
  if (e.alpha == null || e.beta == null || e.gamma == null) return;
  R = rotationMatrix(e.alpha, e.beta, e.gamma); orientationSeen = true;
});

function cameraBasis() {
  const ang = ((screen.orientation && screen.orientation.angle) ?? window.orientation ?? 0) * Math.PI / 180;
  return {
    right: mul(R, [Math.cos(ang), -Math.sin(ang), 0]),
    up: mul(R, [Math.sin(ang), Math.cos(ang), 0]),
    fwd: mul(R, [0, 0, -1])
  };
}

function placeCube() {
  if (!R) { anchor = null; return; }
  const f = cameraBasis().fwd;
  const len = Math.hypot(f[0], f[1]);
  anchor = len > 0.25 ? [f[0] / len * 2, f[1] / len * 2, f[2] / len * 2] : [f[0] * 2, f[1] * 2, f[2] * 2];
}

// tasvir koordinatasi -> ekran koordinatasi (shader buzilishining teskarisi)
function distort(x, y, r) {
  if (S.mode !== 'lens') return [x, y];
  const n = Math.min(r.w, r.h) / 2, rq = Math.hypot(x, y) / n;
  if (rq < 1e-6) return [x, y];
  let t = Math.min(rq, 1.5);
  for (let i = 0; i < 8; i++) {
    const t2 = t * t;
    t -= (t * (1 + S.k1 * t2 + S.k2 * t2 * t2) - rq) / (1 + 3 * S.k1 * t2 + 5 * S.k2 * t2 * t2);
  }
  return [x * t / rq, y * t / rq];
}

const CUBE_V = [], CUBE_E = [];
for (let i = 0; i < 8; i++) CUBE_V.push([i & 1 ? 1 : -1, i & 2 ? 1 : -1, i & 4 ? 1 : -1]);
for (let i = 0; i < 8; i++) for (const bit of [1, 2, 4]) if (!(i & bit)) CUBE_E.push([i, i | bit, bit]);

function drawCube(r) {
  const B = cameraBasis(), f = r.iw / (2 * Math.tan(S.fov * Math.PI / 360));
  const t = performance.now() / 1600, c = Math.cos(t), s = Math.sin(t), sz = 0.22;
  const pts = CUBE_V.map(v => [anchor[0] + (v[0] * c - v[1] * s) * sz, anchor[1] + (v[0] * s + v[1] * c) * sz, anchor[2] + v[2] * sz]);
  octx.lineWidth = 3; octx.lineCap = 'round';
  for (const [a, b, bit] of CUBE_E) {
    octx.strokeStyle = bit === 1 ? '#ff5470' : bit === 2 ? '#35f0a0' : '#4da3ff';
    octx.beginPath();
    let pen = false;
    for (let k = 0; k <= 10; k++) {
      const u = k / 10, P = [0, 1, 2].map(j => pts[a][j] + (pts[b][j] - pts[a][j]) * u);
      const z = dot(P, B.fwd);
      if (z < 0.15) { pen = false; continue; }
      const q = [dot(P, B.right) / z * f, dot(P, B.up) / z * f];
      if (Math.hypot(q[0], q[1]) > Math.max(r.w, r.h) * 1.6) { pen = false; continue; }
      const p = distort(q[0], q[1], r);
      pen ? octx.lineTo(r.cx + p[0], r.cy - p[1]) : octx.moveTo(r.cx + p[0], r.cy - p[1]);
      pen = true;
    }
    octx.stroke();
  }
}

function drawOverlay() {
  octx.clearRect(0, 0, W, H);
  if (!running) return;
  if (S.ar && R && !anchor) placeCube();
  const stats = `${source.videoWidth || '–'}×${source.videoHeight || '–'}  ${fps} fps  ${latency == null ? '' : '≈' + Math.round(latency) + ' ms'}`;
  for (let i = 0; i < 2; i++) {
    const r = eyeRect(i);
    octx.save();
    octx.beginPath(); octx.rect(i * W / 2, 0, W / 2, H); octx.clip();
    octx.beginPath(); octx.rect(r.cx - r.w / 2, r.cy - r.h / 2, r.w, r.h); octx.clip();
    if (S.cross || !$('panel').hidden) {
      octx.strokeStyle = 'rgba(255,255,255,.8)'; octx.lineWidth = 1.5;
      octx.beginPath(); octx.moveTo(r.cx - 12, r.cy); octx.lineTo(r.cx + 12, r.cy); octx.moveTo(r.cx, r.cy - 12); octx.lineTo(r.cx, r.cy + 12); octx.stroke();
    }
    if (S.ar) {
      if (anchor && R) drawCube(r);
      else text('Giroskop signali yoʻq', r.cx, r.cy + 30);
    }
    if (S.stats) text(stats, r.cx, r.cy + r.h * 0.3);
    octx.restore();
  }
}
function text(s, x, y) {
  octx.font = '12px system-ui'; octx.textAlign = 'center';
  octx.lineWidth = 3; octx.strokeStyle = '#000'; octx.strokeText(s, x, y);
  octx.fillStyle = '#9dffd0'; octx.fillText(s, x, y);
}

/* ---------- Sozlash paneli ---------- */
const TABS = ['Ekran', 'Tasvir', 'Kamera', 'AR'];
let tab = 0;
const pct = v => Math.round(v * 100) + '%';

function slider(label, min, max, step, value, fmt, on) {
  const row = document.createElement('div'); row.className = 'row';
  row.innerHTML = '<span></span><button>−</button><input type="range"><button>+</button><output></output>';
  const [name, minus, input, plus, out] = row.children;
  name.textContent = label;
  Object.assign(input, { min, max, step }); input.value = value;
  const show = () => out.textContent = fmt(+input.value);
  const apply = () => { show(); on(+input.value); };
  input.oninput = apply;
  minus.onclick = () => { input.value = +input.value - step; apply(); };
  plus.onclick = () => { input.value = +input.value + step; apply(); };
  show(); $('rows').appendChild(row);
}
const set = key => v => { S[key] = v; save(); layout(); };
const sl = (label, key, min, max, step, fmt) => slider(label, min, max, step, S[key], fmt, set(key));

function wide(label, el) {
  const row = document.createElement('div'); row.className = 'row wide';
  const s = document.createElement('span'); s.textContent = label;
  row.append(s, el); $('rows').appendChild(row);
}
function select(label, options, value, on) {
  const el = document.createElement('select');
  for (const [v, t] of options) el.add(new Option(t, v));
  el.value = value; el.onchange = () => on(el.value);
  wide(label, el);
}
function toggle(label, value, on) {
  const el = document.createElement('button');
  const show = v => { el.textContent = v ? 'Yoqilgan' : 'Oʻchirilgan'; el.classList.toggle('on', v); };
  show(value);
  el.onclick = () => { value = !value; show(value); on(value); };
  wide(label, el);
}
function button(label, text, on) { const el = document.createElement('button'); el.textContent = text; el.onclick = on; wide(label, el); }
function note(t) { const p = document.createElement('p'); p.className = 'note'; p.textContent = t; $('rows').appendChild(p); }

function buildRows() {
  $('tabs').innerHTML = '';
  TABS.forEach((t, i) => {
    const b = document.createElement('button'); b.textContent = t; b.className = i === tab ? 'on' : '';
    b.onclick = () => { tab = i; buildRows(); $('rows').scrollTop = 0; };
    $('tabs').appendChild(b);
  });
  const x = document.createElement('button'); x.textContent = '✔ Tayyor'; x.className = 'primary'; x.onclick = closePanel; $('tabs').appendChild(x);
  const y = $('rows').scrollTop;
  $('rows').innerHTML = '';
  if (tab === 0) {
    note('Rasm ustida: ikki barmoq = oʻlcham, yonga surish = koʻzlar orasi, tepa-pastga surish = balandlik.');
    sl('Oʻlcham', 'size', 0.35, 1.2, 0.01, pct);
    sl('Koʻzlar orasi', 'dist', 0.25, 0.7, 0.005, v => (v * 100).toFixed(1) + '%');
    sl('Balandlik', 'offY', -0.3, 0.3, 0.005, v => (v * 100).toFixed(1));
    sl('Eni', 'aspect', 0.6, 1.5, 0.01, pct);
    sl('Burchak yumaloqligi', 'corner', 0, 0.5, 0.01, pct);
    sl('Tasvir zumi', 'zoom', 0.5, 2, 0.01, pct);
    button('Hammasi', 'Boshlangʻich holatga qaytarish', () => { S = Object.assign({}, DEFAULTS); save(); rebuildGL(); buildRows(); restartCamera(); });
  } else if (tab === 1) {
    select('Rejim', [['lens', 'Linza tuzatishli'], ['direct', 'Eng tez (tuzatishsiz)']], S.mode, v => { S.mode = v; save(); setMode(); buildRows(); });
    sl('Yorugʻlik', 'bright', 0.5, 1.6, 0.05, pct);
    if (S.mode === 'lens') {
      toggle('Toʻr (linzani sozlash)', S.grid, v => set('grid')(v));
      sl('Linza egriligi 1', 'k1', 0, 0.6, 0.01, v => v.toFixed(2));
      sl('Linza egriligi 2', 'k2', 0, 0.4, 0.01, v => v.toFixed(2));
      sl('Rangli chetlar', 'ca', -0.03, 0.03, 0.001, v => v.toFixed(3));
      sl('Keskinlik', 'sharp', 0, 1, 0.05, pct);
      slider('Chizish sifati', 0.5, 1, 0.05, S.render, pct, v => { S.render = v; save(); resize(); });
      toggle('Past kechikish (sinov)', S.lowlat, v => { S.lowlat = v; save(); rebuildGL(); });
      note('“Past kechikish” hamma telefonda ishlamaydi. Miltillash yoki qora ekran boʻlsa, oʻchiring.');
    } else note('Bu rejimda video toʻgʻridan-toʻgʻri koʻrsatiladi: kechikish va quvvat sarfi kamroq, lekin linza egriligi tuzatilmaydi.');
  } else if (tab === 2) {
    select('Sifat', Object.entries(QUALITY).map(([k, q]) => [k, q.label]), S.quality, v => { S.quality = v; save(); restartCamera(); });
    if (devices.length > 1) {
      const opts = [['', 'Avto (orqa kamera)'], ...devices.map((d, i) => [d.deviceId, d.label || 'Kamera ' + (i + 1)])];
      select('Kamera', opts, devices.some(d => d.deviceId === S.camera) ? S.camera : '', v => { S.camera = v; S.camZoom = S.expTime = S.iso = null; S.torch = false; S.expMode = 'auto'; save(); restartCamera(); });
    }
    const c = caps(), now = (track && track.getSettings && track.getSettings()) || {};
    const cam = key => v => { S[key] = v; save(); applyCameraControls(); };
    if (c.zoom) slider('Kamera zumi', c.zoom.min, c.zoom.max, c.zoom.step || 0.1, S.camZoom ?? now.zoom ?? c.zoom.min, v => v.toFixed(1) + '×', cam('camZoom'));
    if (c.torch) toggle('Chiroq', S.torch, cam('torch'));
    if (c.exposureMode && c.exposureMode.includes('manual') && c.exposureTime) {
      select('Ekspozitsiya', [['auto', 'Avto'], ['manual', 'Qoʻlda (kam xiralik)']], S.expMode, v => { cam('expMode')(v); buildRows(); });
      if (S.expMode === 'manual') {
        slider('Vaqt (kichik = tiniq)', c.exposureTime.min, Math.min(c.exposureTime.max, 333), c.exposureTime.step || 1, S.expTime ?? Math.min(80, c.exposureTime.max), v => (v / 10).toFixed(1) + ' ms', cam('expTime'));
        if (c.iso) slider('ISO (yorugʻlik)', c.iso.min, c.iso.max, c.iso.step || 1, S.iso ?? Math.min(800, c.iso.max), v => String(Math.round(v)), cam('iso'));
      }
    }
    note('Xona yorugʻ boʻlsa tasvir tiniqroq va silliqroq boʻladi: qorongʻida kamera ekspozitsiyani uzaytiradi, natijada xiralik va kechikish oshadi.');
  } else {
    toggle('AR kub', S.ar, v => { S.ar = v; save(); anchor = null; drawOverlay(); if (v && !orientationSeen) toast('Telefonni biroz qimirlating (giroskop)'); });
    button('Kub joyi', 'Qarshimga qoʻyish', () => { placeCube(); drawOverlay(); });
    sl('Kamera burchagi', 'fov', 40, 120, 1, v => v + '°');
    toggle('Statistika', S.stats, set('stats'));
    toggle('Markaz belgisi', S.cross, set('cross'));
    note('Boshni burganda kub joyidan siljisa, “Kamera burchagi”ni oʻzgartiring. Kub faqat burilishni kuzatadi: yaqinlashsangiz kattalashmaydi.');
  }
  $('rows').scrollTop = y;
}

function openPanel() { $('panel').hidden = false; $('bar').hidden = true; clearTimeout(barTimer); buildRows(); drawOverlay(); }
function closePanel() { $('panel').hidden = true; if (S.grid) { S.grid = false; save(); } layout(); showBar(); }

let barTimer = 0;
function showBar() {
  if (!running || !$('panel').hidden) return;
  $('bar').hidden = false;
  clearTimeout(barTimer); barTimer = setTimeout(() => $('bar').hidden = true, 3500);
}

/* ---------- Barmoq ishoralari ---------- */
const pointers = new Map();
let gesture = null, multi = false;   // multi: ikki barmoqdan keyin bitta barmoq surilmasin
function beginGesture() {
  const p = [...pointers.values()];
  if (!p.length) { gesture = null; return; }
  gesture = {
    n: p.length, x: p[0].x, y: p[0].y, size: S.size, dist: S.dist, offY: S.offY,
    side: p[0].x < W / 2 ? -1 : 1, axis: null,
    gap: p.length > 1 ? Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y) : 0
  };
}
stage.addEventListener('pointerdown', e => {
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  try { stage.setPointerCapture(e.pointerId); } catch (err) {}
  beginGesture();
});
stage.addEventListener('pointermove', e => {
  if (!pointers.has(e.pointerId)) return;
  pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if ($('panel').hidden || !gesture) return;
  const p = [...pointers.values()];
  if (gesture.n >= 2 && p.length >= 2) {
    const gap = Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y);
    if (gesture.gap > 20) S.size = clamp(gesture.size * gap / gesture.gap, 0.35, 1.2);
  } else if (gesture.n === 1 && !multi) {
    const dx = p[0].x - gesture.x, dy = p[0].y - gesture.y;
    if (!gesture.axis && Math.hypot(dx, dy) > 12) gesture.axis = Math.abs(dx) > Math.abs(dy) ? 'x' : 'y';
    if (gesture.axis === 'x') S.dist = clamp(gesture.dist + gesture.side * dx * 2 / W, 0.25, 0.7);
    if (gesture.axis === 'y') S.offY = clamp(gesture.offY + dy / H, -0.3, 0.3);
  }
  if (gesture.n >= 2) multi = true;
  save(); layout();
});
function endPointer(e) {
  if (!pointers.delete(e.pointerId)) return;
  if (!pointers.size) {
    multi = false; gesture = null;
    if ($('panel').hidden) showBar(); else buildRows();
  } else beginGesture();
}
stage.addEventListener('pointerup', endPointer);
stage.addEventListener('pointercancel', endPointer);

/* ---------- Ekran, uygʻoqlik, ishga tushirish ---------- */
let wakeLock = null, rotateDismissed = false;
async function keepAwake() {
  try { wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {}
}
async function goFullscreen() {
  try { await document.documentElement.requestFullscreen({ navigationUI: 'hide' }); } catch (e) {}
  try { await screen.orientation.lock('landscape'); } catch (e) {}
}

async function enterView(calibrate) {
  if (running) return;
  running = true; rotateDismissed = false; anchor = null;
  $('error').hidden = true; $('menu').hidden = true; stage.hidden = false;
  goFullscreen(); keepAwake(); setMode();
  try {
    await startCamera();
    if (!running) return;
    setMode();
    if (calibrate) { tab = 0; openPanel(); } else { showBar(); toast('Sozlash uchun ekranga bir marta bosing'); }
  } catch (e) { exitView(errorText(e)); }
}

function exitView(message) {
  running = false; loopId++; hasFrame = false;
  stopCamera();
  if (S.grid) { S.grid = false; save(); }
  stage.hidden = true; $('bar').hidden = true; $('panel').hidden = true; $('rotate').hidden = true; $('menu').hidden = false;
  if (typeof message === 'string') { $('error').textContent = message; $('error').hidden = false; }
  if (wakeLock) { wakeLock.release().catch(() => {}); wakeLock = null; }
  try { screen.orientation.unlock(); } catch (e) {}
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
}

$('btnStart').onclick = () => enterView(false);
$('btnCalib').onclick = () => enterView(true);
$('btnMenu').onclick = () => exitView();
$('btnSettings').onclick = openPanel;
$('rotate').onclick = () => { rotateDismissed = true; $('rotate').hidden = true; };
addEventListener('resize', () => { if (running) resize(); });
document.addEventListener('visibilitychange', () => {
  if (!running) return;
  if (document.hidden) { loopId++; camJob = camJob.then(stopCamera); }
  else { keepAwake(); restartCamera(); }
});
