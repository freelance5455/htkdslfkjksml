"use strict";

// ========================================
// 1. بيانات البرنامج وحماية البيانات
// ========================================
const seed = {
  currency: "ل.س",
  id: 10,
  devices: [
    { id: 1, name: "كمبيوتر 1", type: "كمبيوتر", rate: 0 },
    { id: 2, name: "كمبيوتر 2", type: "كمبيوتر", rate: 0 },
    { id: 3, name: "بلايستيشن 4", type: "PS4", rate: 0 }
  ],
  items: [],
  history: [],
  expenses: [],
  hourlyRates: {
    "كمبيوتر": 0,
    "بلايستيشن": 0,
    "فيشة": 0,
    "بلياردو": 0,
    "أخرى": 0
  },
  settings: {
    appName: "Game Lounge",
    textColor: "#edf4ff",
    accentColor: "#52d8e7",
    backgroundColor: "#0b1222",
    fontSize: 15
  }
};

let db;

try {
  db = JSON.parse(localStorage.getItem("game-lounge-demo")) ||
       JSON.parse(JSON.stringify(seed));
} catch (e) {
  db = JSON.parse(JSON.stringify(seed));
}

db.devices = Array.isArray(db.devices) ? db.devices : [];
db.items = Array.isArray(db.items) ? db.items : [];
db.history = Array.isArray(db.history) ? db.history : [];
db.expenses = Array.isArray(db.expenses) ? db.expenses : [];

db.hourlyRates = Object.assign(
  {},
  seed.hourlyRates,
  db.hourlyRates || {}
);

db.settings = Object.assign(
  {},
  seed.settings,
  db.settings || {}
);

// إصلاح المعرّفات المكررة دون حذف السجلات أو الأسعار.
{
  const seen = new Set();
  let next = Math.max(
    Number(db.id) || 1,
    ...db.devices.map(d => Number(d.id) || 0),
    ...db.items.map(p => Number(p.id) || 0),
    ...db.expenses.map(e => Number(e.id) || 0)
  ) + 1;

  db.devices.forEach(d => {
    if (seen.has(String(d.id))) d.id = next++;
    seen.add(String(d.id));
  });

  db.id = Math.max(Number(db.id) || 1, next);
}

let current = "home";
let target = 0;
let deviceCategoryFilter = "الكل";
let reportMode = "daily";
let reportDate = localDate();
let reportMonth = localMonth();

// ========================================
// 2. الأدوات والحفظ
// ========================================
function localDate(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function localMonth(d = new Date()) {
  return localDate(d).slice(0, 7);
}

function save() {
  localStorage.setItem("game-lounge-demo", JSON.stringify(db));
}

function cash(n) {
  return Math.round(Number(n) || 0).toLocaleString("en-US") +
    " " + (db.currency || "ل.س");
}

function priceText(n) {
  return Number(n) > 0 ? cash(n) : "لم يُحدّد السعر بعد";
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"]/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;"
  }[c]));
}

function time(ms) {
  const x = Math.max(0, Math.floor(ms / 1000));
  return [
    Math.floor(x / 3600),
    Math.floor(x % 3600 / 60),
    x % 60
  ].map(n => String(n).padStart(2, "0")).join(":");
}

function sum(s) {
  return (s?.orders || []).reduce(
    (a, o) => a + (Number(o.price) || 0) * (Number(o.qty) || 0),
    0
  );
}

function notify(message) {
  const el = document.getElementById("toast");
  if (!el) {
    alert(message);
    return;
  }

  el.textContent = message;
  el.classList.add("show");

  setTimeout(() => el.classList.remove("show"), 2500);
}

function page(p, button) {
  const previous = current;
  current = p;

  if (p === "devices") deviceCategoryFilter = "الكل";

  document.querySelectorAll(".nav button").forEach(b => {
    b.classList.toggle("active", b === button || (p === "home" && b.textContent.includes("الرئيسية")));
  });

  // كل قسم يُعرض بوضع مستقل، مع حفظ الرجوع بزر الهاتف.
  document.body.classList.toggle("section-mode", p !== "home");
  if (p !== previous && !window.__handlingSectionPop) {
    try { history.pushState({ gameLoungePage: p }, "", "#" + p); } catch (_) {}
  }
  render();
}

function backToHome() {
  if (location.hash && location.hash !== "#home" && history.state && history.state.gameLoungePage) {
    history.back();
    return;
  }
  window.__handlingSectionPop = true;
  page("home", document.querySelector('.nav button'));
  window.__handlingSectionPop = false;
}

window.addEventListener("popstate", function () {
  window.__handlingSectionPop = true;
  const section = (location.hash || "#home").slice(1);
  const allowed = ["home", "devices", "items", "expenses", "reports", "settings"];
  const target = allowed.includes(section) ? section : "home";
  current = target;
  document.body.classList.toggle("section-mode", target !== "home");
  document.querySelectorAll(".nav button").forEach(b => b.classList.toggle("active", b.getAttribute("onclick")?.includes("'" + target + "'")));
  render();
  window.__handlingSectionPop = false;
});

const deviceGroups = [
  { key: "كمبيوتر", title: "🖥️ أجهزة الكمبيوتر" },
  { key: "بلايستيشن", title: "🎮 أجهزة البلايستيشن" },
  { key: "فيشة", title: "⚽ طاولات الفيشة" },
  { key: "بلياردو", title: "🎱 طاولات البلياردو" },
  { key: "أخرى", title: "🎯 أجهزة أخرى" }
];

function categoryOf(d) {
  const type = String(d.type || "").trim();

  if (type === "كمبيوتر") return "كمبيوتر";

  if (["PS5", "PS4", "PS3", "بلايستيشن"].includes(type)) {
    return "بلايستيشن";
  }

  if (type === "فيشة") return "فيشة";
  if (type === "بلياردو") return "بلياردو";

  return "أخرى";
}

function deviceCategory(name) {
  deviceCategoryFilter = name;
  render();
}

function openDeviceCategory(name) {
  current = "devices";
  deviceCategoryFilter = name;

  document.querySelectorAll(".nav button").forEach((b, i) => {
    b.classList.toggle("active", i === 2);
  });

  render();
}

function categoryMenuHtml() {
  return `<div class="category-tiles">
    ${deviceGroups.filter(g => g.key !== "أخرى").map(g => {
      const count = db.devices.filter(d => categoryOf(d) === g.key).length;

      return `<button class="category-tile"
        onclick="openDeviceCategory('${g.key}')">
        <span class="category-icon">${g.title.split(" ")[0]}</span>
        <span class="category-name">${g.title.replace(/^.*? /, "")}</span>
        <span class="category-total">${count} عنصر</span>
        <span class="category-open">فتح القائمة ←</span>
      </button>`;
    }).join("")}
  </div>`;
}

function deviceSort(a, b) {
  const number = d => {
    const m = String(d.name).match(/\d+/);
    return m ? Number(m[0]) : Number.MAX_SAFE_INTEGER;
  };

  return number(a) - number(b) ||
    String(a.name).localeCompare(String(b.name), "ar");
}

function deviceGroupHtml(key, title) {
  const list = db.devices
    .filter(d => categoryOf(d) === key)
    .sort(deviceSort);

  return `<section class="device-group">
    <h3>${title} <span class="group-count">${list.length}</span></h3>
    ${list.length
      ? `<div class="devices">${list.map(card).join("")}</div>`
      : `<p class="muted empty-group">لا توجد عناصر في هذا القسم حالياً.</p>`
    }
  </section>`;
}

function renderHomePage(c) {
  const income = (db.history || []).reduce((sum, h) => sum + (Number(h.total) || Number(h.game) || 0) + (Number(h.orderTotal) || 0), 0);
  const expenses = (db.expenses || []).reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
  const balance = income - expenses;
  const name = String((db.settings && db.settings.appName) || localStorage.getItem("gameLoungeAppName") || "Game Lounge");
  const nameEl = document.getElementById("appNameDisplay");
  if (nameEl) nameEl.textContent = name;
  c.innerHTML = `<section class="home-only">
    <div class="cash-box"><span>💰 المبلغ الموجود في الصندوق</span><strong>${cash(balance)}</strong><small>إيرادات الجلسات − المصروفات</small></div>
  </section>`;
}
function updateHomeClock() {
  const d = new Date();
  const dateEl = document.getElementById("homeDate");
  const timeEl = document.getElementById("homeTime");
  if (dateEl) dateEl.textContent = d.toLocaleDateString("ar", {year:"numeric",month:"long",day:"numeric"});
  if (timeEl) timeEl.textContent = d.toLocaleTimeString("en-GB", {hour12:false});
  const nameEl = document.getElementById("appNameDisplay");
  const name = (db && db.settings && db.settings.appName) || localStorage.getItem("gameLoungeAppName") || "Game Lounge";
  if (nameEl) nameEl.textContent = name;
}
setInterval(updateHomeClock, 1000);
document.addEventListener("DOMContentLoaded", updateHomeClock);

// ========================================
// 3. عرض الصفحات
// ========================================
function render() {
  const c = document.getElementById("content");
  if (!c) return;

  if (current === "home") {
    renderHomePage(c);
  } else if (current === "devices") {
    renderDevicesPage(c);
  } else if (current === "items") {
    renderItemsPage(c);
  } else if (current === "expenses") {
    renderExpensesPage(c);
  } else if (current === "reports") {
    renderReports(c);
  } else if (current === "settings") {
    renderSettings(c);
  }

  // زر رجوع مستقل يظهر داخل الأقسام فقط.
  const oldBack = c.querySelector(":scope > .section-back-row");
  if (oldBack) oldBack.remove();
  if (current !== "home") {
    const row = document.createElement("div");
    row.className = "section-back-row";
    row.innerHTML = '<button type="button" class="section-back-button" onclick="backToHome()">← رجوع للرئيسية</button>';
    c.prepend(row);
  }
}

