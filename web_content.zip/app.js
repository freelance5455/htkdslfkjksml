/* =========================================================
   PENGGILAS BaZi
   APP SHELL / ROUTER / DATA BRIDGE
========================================================= */

let currentScreenId = "screen-welcome";
let userInput = null;
let masterResult = null;
let calculationQueue = Promise.resolve();
let activeCalculationKey = null;
const pendingCalculationKeys = new Set();

function getScreen(screenId) {
    return document.getElementById(screenId);
}

function getBottomNav() {
    return document.getElementById("bottom-nav");
}

function setActiveNav(screenId, clickedElement = null) {
    document.querySelectorAll(".nav-item").forEach(function (item) {
        item.classList.remove("active");
    });

    const target =
        clickedElement ||
        document.querySelector(
            '.nav-item[data-screen="' + screenId + '"]'
        );

    if (target) {
        target.classList.add("active");
    }
}

function broadcastData() {
    if (!userInput) return;

    document.querySelectorAll(".module-frame").forEach(function (frame) {
        if (frame.contentWindow) {
            frame.contentWindow.postMessage(
                {
                    type: "BAZI_USER_DATA",
                    payload: userInput
                },
                "*"
            );
        }
    });
}


/* =========================================================
   MASTER RESULT BRIDGE
========================================================= */

function broadcastMasterResult(targetWindow = null) {

    if (!masterResult) return;

    if (targetWindow) {

        targetWindow.postMessage(
            {
                type: "BAZI_MASTER_RESULT",
                payload: masterResult
            },
            "*"
        );

        return;
    }

    document.querySelectorAll(".module-frame").forEach(function (frame) {

        if (frame.contentWindow) {

            frame.contentWindow.postMessage(
                {
                    type: "BAZI_MASTER_RESULT",
                    payload: masterResult
                },
                "*"
            );

        }

    });
}


/* =========================================================
   SCREEN ROUTER
========================================================= */

function resetScreenContentScroll(frame) {
    if (!frame) return;

    const content = frame.closest(".screen-content");
    if (content) {
        content.scrollTop = 0;
        content.scrollLeft = 0;
    }
}

function restoreReportFrame() {
    const reportFrame = document.getElementById("report-frame");
    if (!reportFrame) return;

    resetScreenContentScroll(reportFrame);

    let currentPath = "";
    try {
        currentPath = reportFrame.contentDocument && reportFrame.contentDocument.location
            ? reportFrame.contentDocument.location.pathname
            : "";
    } catch (error) {
        currentPath = "";
    }

    // Report and Preview share one iframe by design. Only restore the Report
    // document when the iframe is currently showing the full template.
    if (!/\/template\/result-template\.html$/i.test(currentPath)) {
        resetFrameScroll(reportFrame);
        return;
    }

    const reportSrc = "ui/report/report.html?v=20261008-v126";

    // Never collapse the iframe to 1px during navigation. Reuse the last
    // measured Report height as a safe provisional layout until report.html
    // finishes loading and is measured again.
    const cachedHeight = Number(reportFrame.dataset.reportHeight);
    reportFrame.style.height = (cachedHeight > 0 ? cachedHeight : 420) + "px";

    reportFrame.src = reportSrc;
    resetFrameScroll(reportFrame);
}

function resetFrameScroll(frame) {
    if (!frame) return;
    try {
        if (frame.contentWindow) frame.contentWindow.scrollTo(0, 0);
        if (frame.contentDocument) {
            frame.contentDocument.documentElement.scrollTop = 0;
            if (frame.contentDocument.body) frame.contentDocument.body.scrollTop = 0;
        }
    } catch (error) {
        console.warn("[app.js] Frame scroll reset skipped:", error);
    }
}

function notifyCalculationError(error) {
    const message = error && error.message ? String(error.message) : "BaZi calculation failed.";
    const inputFrame = document.getElementById("input-frame");
    if (inputFrame && inputFrame.contentWindow) {
        inputFrame.contentWindow.postMessage({
            type: "BAZI_CALCULATION_ERROR",
            payload: { message: message }
        }, "*");
    }
}

function goToScreen(screenId, clickedElement = null) {
    const target = getScreen(screenId);

    if (!target) {
        console.warn("Screen belum tersedia:", screenId);
        return;
    }

    document.querySelectorAll(".screen").forEach(function (screen) {
        screen.classList.remove("active");
    });

    target.classList.add("active");
    currentScreenId = screenId;

    const bottomNav = getBottomNav();

    const hideNav =
        screenId === "screen-welcome" ||
        screenId === "screen-input";

    if (bottomNav) {
        bottomNav.classList.toggle("hidden", hideNav);
    }

    setActiveNav(screenId, clickedElement);

    const targetFrame = target.querySelector(".module-frame");
    if (targetFrame) {
        resetScreenContentScroll(targetFrame);
    }

    if (screenId === "screen-report") {
        restoreReportFrame();
    }

    broadcastData();
    broadcastMasterResult();
}

function receiveInputData(payload) {
    userInput = payload || null;

    window.BAZI_USER_INPUT = userInput;

    broadcastData();

    return triggerCalculation(userInput);
}


/* =========================================================
   KABEL 3 (BARU)

   userInput (lengkap)
     ↓
   core/coreA.js  (PenggilasCoreA.calculate)
     ↓
   BAZI_MASTER_RESULT_READY (CustomEvent)
     ↓
   listener di bawah -> masterResult -> broadcastMasterResult()
========================================================= */

function calculationKey(payload) {
    return JSON.stringify({
        name: payload && payload.name || "",
        gender: payload && payload.gender || "",
        birthDate: payload && payload.birthDate || "",
        birthTime: payload && payload.birthTime || "",
        birthPlace: payload && payload.birthPlace && payload.birthPlace.query || ""
    });
}

function runCalculationPipeline(payload) {
    const asOf = new Date();

    return window.PenggilasCoreA.calculate(payload)
        .then(function () {
            // Core B, Determination, and Core C are strictly downstream of Core A.
            if (window.PenggilasCoreB && typeof window.PenggilasCoreB.calculate === "function") {
                window.PenggilasCoreB.calculate();
            } else {
                throw new Error("[app.js] PenggilasCoreB belum termuat — pipeline dihentikan.");
            }

            if (window.PenggilasDetermination && typeof window.PenggilasDetermination.calculate === "function") {
                window.PenggilasDetermination.calculate();
            } else {
                throw new Error("[app.js] PenggilasDetermination belum termuat — pipeline dihentikan.");
            }

            if (window.PenggilasCoreC && typeof window.PenggilasCoreC.calculate === "function") {
                window.PenggilasCoreC.calculate(asOf);
            } else {
                throw new Error("[app.js] PenggilasCoreC belum termuat — pipeline dihentikan.");
            }

            window.dispatchEvent(
                new CustomEvent("BAZI_MASTER_RESULT_READY", { detail: window.masterResult })
            );

            if (!window.masterResult) {
                throw new Error("BaZi Master Result tidak tersedia setelah pipeline.");
            }

            return window.masterResult;
        });
}

function triggerCalculation(payload) {
    const hasCompleteInput =
        payload &&
        payload.birthDate &&
        payload.birthTime &&
        payload.birthPlace &&
        payload.birthPlace.query;

    if (!hasCompleteInput) return;

    if (!window.PenggilasCoreA || typeof window.PenggilasCoreA.calculate !== "function") {
        console.warn("[app.js] PenggilasCoreA belum termuat — kalkulasi dilewati.");
        return;
    }

    const key = calculationKey(payload);

    // Protect against duplicate cables/double-clicks for the same active input.
    if (pendingCalculationKeys.has(key)) {
        console.warn("[app.js] Duplicate calculation request ignored for the pending input.");
        return;
    }

    pendingCalculationKeys.add(key);
    activeCalculationKey = key;

    // Serialize the full A→B→Determination→C pipeline so asynchronous
    // geocoding cannot overlap two calculations or leave a stale result last.
    calculationQueue = calculationQueue
        .catch(function () {
            // Keep the queue usable after a failed calculation.
        })
        .then(function () {
            return runCalculationPipeline(payload);
        })
        .catch(function (err) {
            console.error("[app.js] Gagal menghitung BaZi:", err);
            notifyCalculationError(err);
            throw err;
        })
        .finally(function () {
            pendingCalculationKeys.delete(key);
            if (activeCalculationKey === key) {
                activeCalculationKey = null;
            }
        });

    return calculationQueue;
}

function calculateChart(payload) {
    if (payload) {
        return receiveInputData(payload)
            .then(function () {
                goToScreen("screen-chart");
            })
            .catch(function () {
                goToScreen("screen-input");
            });
    }

    goToScreen("screen-chart");
}

window.goToScreen = goToScreen;
window.receiveInputData = receiveInputData;
window.calculateChart = calculateChart;


/* =========================================================
   MESSAGE BRIDGE
========================================================= */

window.addEventListener("message", function (event) {

    const data = event.data;

    if (!data) return;


    /* =====================================================
       KABEL 1

       INPUT
       ↓
       BAZI_INPUT_DATA
       ↓
       app.js
       ↓
       userInput
       ↓
       ENGINE / MODULE
    ===================================================== */

    if (data.type === "BAZI_INPUT_RESIZE") {

        const inputFrame = document.getElementById("input-frame");
        if (inputFrame) syncModuleFrameHeight(inputFrame);

        return;
    }

    if (data.type === "BAZI_INPUT_DATA") {

        receiveInputData(data.payload);

        return;
    }


    /* =====================================================
       KABEL 2

       INPUT
       ↓
       BAZI_NAVIGATE + payload
       ↓
       app.js
       ↓
       userInput
       ↓
       screen-chart
    ===================================================== */

    if (data.type === "BAZI_NAVIGATE") {

        if (data.payload) {
            receiveInputData(data.payload)
                .then(function () {
                    goToScreen(data.screenId);
                })
                .catch(function () {
                    // Fail closed: do not display an empty chart as if it were a result.
                    goToScreen("screen-input");
                });
        } else {
            goToScreen(data.screenId);
        }

        return;
    }


    /* =====================================================
       CHART REQUEST DATA

       Chart
       ↓
       REQUEST_BAZI_USER_DATA
       ↓
       app.js
       ↓
       BAZI_USER_DATA
       ↓
       Chart Profile Card
    ===================================================== */

    if (data.type === "REQUEST_BAZI_USER_DATA") {

        if (event.source && userInput) {

            event.source.postMessage(
                {
                    type: "BAZI_USER_DATA",
                    payload: userInput
                },
                "*"
            );

        }

        return;
    }


    /* =====================================================
       MODULE REQUEST MASTER RESULT

       Module
       ↓
       REQUEST_BAZI_MASTER_RESULT
       ↓
       app.js
       ↓
       BAZI_MASTER_RESULT
       ↓
       Module
    ===================================================== */

    if (data.type === "BAZI_RETURN_TO_REPORT") {
        goToScreen("screen-report");
        return;
    }

        if (data.type === "REQUEST_BAZI_MASTER_RESULT") {

        if (event.source && masterResult) {
            broadcastMasterResult(event.source);
        }

        return;
    }

});


/* =========================================================
   MASTER RESULT READY
========================================================= */

window.addEventListener(
    "BAZI_MASTER_RESULT_READY",
    function (event) {

        masterResult = event.detail || null;

        window.BAZI_MASTER_RESULT = masterResult;

        broadcastMasterResult();

    }
);


/* =========================================================
   IFRAME HEIGHT SYNC
   The shell owns scrolling. Each module iframe expands to
   its document height so .screen-content remains the only
   scrolling layer.
========================================================= */

function syncModuleFrameHeight(frame) {
    if (!frame || !frame.contentDocument) return;

    const doc = frame.contentDocument;
    const body = doc.body;
    const html = doc.documentElement;

    if (!body || !html) return;

    const height = Math.max(
        body.scrollHeight,
        body.offsetHeight,
        html.scrollHeight,
        html.offsetHeight,
        html.clientHeight
    );

    const finalHeight = Math.max(height, 1);
    frame.style.height = finalHeight + "px";

    if (frame.id === "report-frame" && /report\.html$/i.test(doc.location.pathname)) {
        frame.dataset.reportHeight = String(finalHeight);
    }
}

function attachFrameContentObservers(frame) {
    if (!frame || !frame.contentDocument) return;

    const doc = frame.contentDocument;
    const root = doc.documentElement;
    if (!root) return;

    if (frame._moduleResizeObserver) frame._moduleResizeObserver.disconnect();
    if (frame._moduleMutationObserver) frame._moduleMutationObserver.disconnect();

    if (typeof ResizeObserver !== "undefined") {
        frame._moduleResizeObserver = new ResizeObserver(function () {
            syncModuleFrameHeight(frame);
        });
        frame._moduleResizeObserver.observe(root);
        if (doc.body) frame._moduleResizeObserver.observe(doc.body);
    }

    if (typeof MutationObserver !== "undefined") {
        frame._moduleMutationObserver = new MutationObserver(function () {
            syncModuleFrameHeight(frame);
        });
        frame._moduleMutationObserver.observe(root, {
            childList: true,
            subtree: true,
            attributes: true
        });
    }

    // Intrinsic image dimensions may settle after iframe load. Listen for the
    // image event explicitly so visual modules do not require a refresh.
    Array.from(doc.images || []).forEach(function (image) {
        image.addEventListener("load", function () {
            syncModuleFrameHeight(frame);
        });
        if (image.complete) syncModuleFrameHeight(frame);
    });
}

function setupModuleFrame(frame) {
    if (!frame || frame._moduleSetup) return;
    frame._moduleSetup = true;

    frame.addEventListener("load", function () {
        syncModuleFrameHeight(frame);
        attachFrameContentObservers(frame);

        if (frame.id === "report-frame") {
            resetScreenContentScroll(frame);
            resetFrameScroll(frame);
        }

        broadcastData();
        broadcastMasterResult();
    });

    // Install synchronously because input-frame is eager. If it already
    // completed before this handler was attached, measure it immediately.
    try {
        if (frame.contentDocument && frame.contentDocument.readyState === "complete") {
            syncModuleFrameHeight(frame);
            attachFrameContentObservers(frame);
        }
    } catch (error) {
        console.warn("[app.js] Initial frame measurement skipped:", error);
    }
}

// The script is loaded at the end of index.html. Install frame listeners now,
// not on DOMContentLoaded, to avoid losing the eager Input iframe's load event.
document.querySelectorAll(".module-frame").forEach(function (frame) {
    setupModuleFrame(frame);
});
