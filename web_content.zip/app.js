const $=id=>document.getElementById(id);
let category="All", note=localStorage.getItem("ci_notes")||"";
let data=JSON.parse(localStorage.getItem("ci_data")||"null")||{
name:"Chetan Gopal Patil",youtube:"xcp3900",instagram:"x_c_p_3900",
gaming:"chetan_patil_geming",discord:"https://discord.gg/w5gYjdUgG",
whatsapp:"8149570553",email:"chetangopalpatil3900@gmail.com"
};
const cats=["All","Calculator","Converter","Text","Date & Time","Finance","Photography","Gaming","Minecraft","Device","Internet","Student","Creator","Developer","Utility","Productivity"];
const seeds={
"Calculator":["Basic Calculator","Percentage Calculator","Average Calculator","Age Calculator","Discount Calculator"],
"Converter":["Length Converter","Weight Converter","Temperature Converter","Speed Converter","Time Converter","Data Converter"],
"Text":["Word Counter","Character Counter","Uppercase / Lowercase","Text Cleaner","Line Counter"],
"Date & Time":["Days Between Dates","Countdown Helper","Age in Years","Time Zone Helper"],
"Finance":["Simple Interest","Discount Helper","Split Bill","Tax Helper","Savings Helper"],
"Photography":["ISO Notes","Aperture Notes","Shutter Speed Notes","Photo Shot List","Exposure Notes"],
"Gaming":["FPS Notes","Game Settings","Sensitivity Notes","Gaming Checklist","Ping Notes"],
"Minecraft":["Minecraft Commands Notes","Seed Notes","Server Notes","Build Planner","SMP Rules"],
"Device":["Storage Notes","Battery Notes","RAM Notes","Screen Info","Device Checklist"],
"Internet":["URL Notes","Password Hint Notes","Network Notes","Browser Notes"],
"Student":["Study Timer Notes","Homework Notes","Exam Planner","Subject Notes","Revision List"],
"Creator":["Content Ideas","Caption Notes","Hashtag Notes","Video Ideas","Thumbnail Ideas"],
"Developer":["Code Notes","Bug Notes","Project Checklist","HTML Notes","JavaScript Notes"],
"Utility":["Quick Notes","Random Number","Checklist","Reminder Notes","Daily Log"],
"Productivity":["Today Tasks","Goals","Weekly Plan","Project Notes","Focus Notes"]
};
let tools=[];
Object.keys(seeds).forEach(c=>seeds[c].forEach(n=>tools.push({n,c,d:n})));
let i=0;
while(tools.length<520){let c=cats[1+(i% (cats.length-1))];tools.push({n:(seeds[c][i%seeds[c].length])+" "+(Math.floor(i/seeds[c].length)+2),c,d:"Quick "+c+" tool"});i++}

window.addEventListener("load",()=>setTimeout(()=>{$("splash").classList.add("hide");$("app").classList.remove("hide");init()},2000));
function init(){renderCats();renderTools()}
function renderCats(){$("cats").innerHTML=cats.map(c=>`<button class="chip ${c==category?"active":""}" onclick="setCat('${c.replaceAll("'","\\'")}')">${c}</button>`).join("")}
function setCat(c){category=c;renderCats();renderTools()}
function renderTools(){
 let q=$("search").value.toLowerCase(), a=tools.filter(t=>(category=="All"||t.c==category)&&t.n.toLowerCase().includes(q)).slice(0,80);
 $("tools").innerHTML=a.map((t)=>`<div class="card"><h3>${esc(t.n)}</h3><div class="muted">${esc(t.c)} • ${esc(t.d)}</div><button onclick="openTool(${tools.indexOf(t)})">Open Tool</button></div>`).join("")||'<div class="card">No tools found.</div>';
}
function openTool(idx){
 let t=tools[idx];
 if(t.c==="Calculator") return calculator(t.n);
 if(t.n==="Word Counter"||t.n==="Character Counter") return textTool(t.n);
 if(t.n==="Random Number") return randomTool();
 genericTool(t);
}
function calculator(title){showModal(`<h2>${esc(title)}</h2><input id="a" type="number" placeholder="First number"><select id="op"><option>+</option><option>-</option><option>×</option><option>÷</option><option>%</option></select><input id="b" type="number" placeholder="Second number"><button class="primary" onclick="doCalc()">Calculate</button><div id="result" class="card"></div>`)}
function doCalc(){let a=+$("a").value,b=+$("b").value,o=$("op").value,r=o=="+"?a+b:o=="-"?a-b:o=="×"?a*b:o=="÷"?(b? a/b:"Cannot divide by zero"):a%b;$("result").textContent="Result: "+r}
function textTool(title){showModal(`<h2>${esc(title)}</h2><textarea id="txt" rows="8" placeholder="Type or paste text..."></textarea><button class="primary" onclick="countText()">Count</button><div id="result" class="card"></div>`)}
function countText(){let x=$("txt").value;$("result").textContent=`Words: ${(x.trim().match(/\\S+/g)||[]).length} | Characters: ${x.length} | Lines: ${x?x.split("\\n").length:0}`}
function randomTool(){showModal(`<h2>Random Number</h2><div class="row"><input id="min" type="number" value="1"><input id="max" type="number" value="100"></div><button class="primary" onclick="rand()">Generate</button><div id="result" class="card"></div>`)}
function rand(){let a=+$("min").value,b=+$("max").value;$("result").textContent="Random: "+Math.floor(Math.random()*(b-a+1))+a}
function genericTool(t){showModal(`<h2>${esc(t.n)}</h2><div class="muted">Use this space for your ${esc(t.c.toLowerCase())} information.</div><textarea id="generic" rows="8" placeholder="Write here..."></textarea><button class="primary" onclick="saveGeneric()">Save Locally</button><div id="result" class="small"></div>`)}
function saveGeneric(){$("result").textContent="Saved on this device."}
function openMenu(){$("menu").style.display="flex"}function closeMenu(e){if(e.target==$("menu"))$("menu").style.display="none"}
function showModal(x){$("modalBox").innerHTML=x;$("modal").style.display="flex"}function closeModal(e){if(e.target==$("modal"))$("modal").style.display="none"}
function endModal(){$("modal").style.display="none"}
function showInfo(){openMenuClose();showModal(`<h2>My Information</h2><div class="card"><h3>${esc(data.name)}</h3><div class="muted">Photographer • Gamer • Content Creator • Minecraft Server Creator</div></div><p>Creator of Chetan Info and a digital creator focused on photography, gaming and Minecraft.</p><p>WhatsApp: ${esc(data.whatsapp)}</p><button class="primary" onclick="window.open('https://wa.me/${data.whatsapp}','_blank')">WhatsApp</button><button class="secondary" onclick="window.open('${esc(data.discord)}','_blank')">Join Discord Community</button>`)}
function showSocial(){openMenuClose();showModal(`<h2>Social Media</h2><button class="primary" onclick="window.open('https://youtube.com/@${encodeURIComponent(data.youtube)}','_blank')">YouTube: ${esc(data.youtube)}</button><button class="primary" onclick="window.open('https://instagram.com/${encodeURIComponent(data.instagram)}','_blank')">Instagram: @${esc(data.instagram)}</button><button class="primary" onclick="window.open('https://instagram.com/${encodeURIComponent(data.gaming)}','_blank')">Gaming Instagram</button><button class="primary" onclick="window.open('${esc(data.discord)}','_blank')">Discord</button>`)}
function showSupport(){openMenuClose();showModal(`<h2>Help & Support</h2><input id="sn" placeholder="Your name"><input id="se" type="email" placeholder="Your email"><textarea id="sp" rows="5" placeholder="Problem / complaint"></textarea><button class="primary" onclick="sendWA()">Send on WhatsApp</button><button class="secondary" onclick="sendMail()">Send Email</button>`)}
function sendWA(){let m=`Chetan Info Support\\nName: ${$("sn").value}\\nEmail: ${$("se").value}\\nProblem: ${$("sp").value}`;window.open(`https://wa.me/${data.whatsapp}?text=${encodeURIComponent(m)}`,"_blank")}
function sendMail(){let b=`Name: ${$("sn").value}\\nEmail: ${$("se").value}\\nProblem: ${$("sp").value}`;window.location.href=`mailto:${data.email}?subject=Chetan Info Support&body=${encodeURIComponent(b)}`}
function showNotes(){openMenuClose();showModal(`<h2>My Notes</h2><textarea id="notes" rows="12">${esc(note)}</textarea><button class="primary" onclick="saveNotes()">Save Notes</button><button class="secondary" onclick="clearNotes()">Clear</button>`)}
function saveNotes(){note=$("notes").value;localStorage.setItem("ci_notes",note);$("notes").value=note}
function clearNotes(){note="";localStorage.removeItem("ci_notes");$("notes").value=""}
function showSettings(){openMenuClose();showModal(`<h2>Settings</h2><div class="card">Tools available: 520+</div><div class="card">Local data is stored only on this device.</div><button class="secondary" onclick="localStorage.clear();location.reload()">Reset Local Data</button>`)}
function showAbout(){openMenuClose();showModal(`<h2>About Chetan Info</h2><p><b>Chetan Info</b></p><p>Created by Chetan Gopal Patil</p><p>Photography • Gaming • Creator • 500+ Useful Tools</p>`)}
function showAdmin(){openMenuClose();showModal(`<h2>Admin / Edit App</h2><input id="pw" type="password" placeholder="Admin password"><button class="primary" onclick="adminLogin()">Continue</button>`)}
function adminLogin(){if($("pw").value!=="xcp3900@chetanpatil")return alert("Wrong password");showModal(`<h2>Edit App</h2>${field("name","Name",data.name)}${field("youtube","YouTube",data.youtube)}${field("instagram","Instagram",data.instagram)}${field("gaming","Gaming Instagram",data.gaming)}${field("discord","Discord",data.discord)}${field("whatsapp","WhatsApp",data.whatsapp)}${field("email","Support Email",data.email)}<button class="primary" onclick="saveAdmin()">Save Changes</button>`)}
function field(id,l,v){return `<label>${l}</label><input id="${id}" value="${esc(v)}">`}
function saveAdmin(){["name","youtube","instagram","gaming","discord","whatsapp","email"].forEach(k=>data[k]=$(k).value);localStorage.setItem("ci_data",JSON.stringify(data));alert("Saved");endModal()}
function logout(){openMenuClose();alert("This demo keeps app data locally.")}
function openMenuClose(){$("menu").style.display="none"}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
