const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const roster=[["Valério","GR",81],["Paulo Langa","DEF",80],["Abel","DEF",80],["Ercílio","DEF",81],["Stélio David","DEF",83],["Ronaldo","MED",83],["João Chilaves","MED",87],["Justino Chavane","MED",84],["Nelson Sitoe","AVA",84],["Micas","AVA",86],["Titos Sitoe","AVA",81],["Fernando","GR",81],["Idelson","SUP",82],["Egas","MED",80],["Anderson","AVA",79],["Joel","MED",83],["Edu Chavane","DEF",82]];
const clubs=["WJ FC","PSG","Barcelona","Real Madrid","Manchester City","Liverpool","Arsenal","Bayern","Juventus"];
let data=JSON.parse(localStorage.getItem("w5data")||'{"coins":0,"wins":0,"streak":0,"matches":0,"losses":0}');
function save(){localStorage.setItem("w5data",JSON.stringify(data));$("#coins").textContent=data.coins;$("#streakText").textContent=`${data.streak} de 5 vitórias`;$("#progressBar").style.width=(data.streak*20)+"%"}
function screen(id){$$(".screen").forEach(x=>x.classList.remove("active"));$("#"+id).classList.add("active");if(id==="match")resize()}
$$("[data-screen]").forEach(b=>b.addEventListener("click",()=>screen(b.dataset.screen)));
$("#roster").innerHTML=roster.map((p,i)=>`<div class="player-row"><span><b>${p[0]}</b><br><small>${i<11?"Titular":p[1]==="SUP"?"Suplente":p[1]}</small></span><b>${p[2]}</b></div>`).join("");
$("#clubList").innerHTML=clubs.map(c=>`<div class="club-row">${c}<span>⚽</span></div>`).join("");
save();
let match=null,raf=0,last=0,elapsed=0,score=[0,0],players=[],ball={x:0,z:0,vx:0,vz:0},joy={x:0,y:0},keys={};
const canvas=$("#game"),ctx=canvas.getContext("2d");
function resize(){const r=canvas.getBoundingClientRect();canvas.width=Math.max(320,Math.floor(r.width*devicePixelRatio));canvas.height=Math.max(260,Math.floor(r.height*devicePixelRatio))}
function start(){
 const home=$("#homeClub").value,away=$("#awayClub").value;if(home===away){alert("Escolhe duas equipas diferentes.");return}
 const diff=$('input[name="difficulty"]:checked').value;
 match={home,away,diff,abandoned:false,done:false};score=[0,0];elapsed=0;ball={x:0,z:0,vx:0,vz:0};
 players=[];
 for(let team=0;team<2;team++)for(let i=0;i<11;i++){let row=i<1?0:i<5?1:i<8?2:3;let col=i===0?0:(i-(row===1?1:row===2?5:8));let x=(team===0?-1:1)*(row===0?8:row===1?5:row===2?1:0);let z=(col-((row===1?3:row===2?2:row===3?2:0)))*3.2;players.push({team,x,z,homeX:x,homeZ:z,speed:diff==="veryhard"?2.5:diff==="hard"?2.2:1.8})}
 $("#matchNames").textContent=`${home}  0 - 0  ${away}`;$("#matchDifficulty").textContent=({easy:"FÁCIL",normal:"NORMAL",hard:"DIFÍCIL",veryhard:"MUITO DIFÍCIL"})[diff];
 screen("match");last=performance.now();cancelAnimationFrame(raf);raf=requestAnimationFrame(loop)
}
$("#startMatch").addEventListener("click",start);
function project(x,z){const w=canvas.width,h=canvas.height;return{x:w/2+x*w/34,y:h*.53+z*h/48+x*h*.12,scale:Math.max(.55,1-z/55)}}
function draw(){
 const w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);
 // pitch perspective
 let top=h*.12,bottom=h*.91,left=w*.12,right=w*.88;
 ctx.fillStyle="#174c2e";ctx.fillRect(0,0,w,h);
 ctx.beginPath();ctx.moveTo(w*.25,top);ctx.lineTo(w*.75,top);ctx.lineTo(right,bottom);ctx.lineTo(left,bottom);ctx.closePath();ctx.fillStyle="#287a40";ctx.fill();
 for(let i=0;i<10;i++){let t=i/10;ctx.beginPath();ctx.moveTo(w*(.25-t*.13),top+(bottom-top)*t);ctx.lineTo(w*(.75+t*.13),top+(bottom-top)*t);ctx.strokeStyle=i%2?"#ffffff08":"#0000000b";ctx.lineWidth=5;ctx.stroke()}
 ctx.strokeStyle="#e8f4df";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(w*.25,top);ctx.lineTo(w*.75,top);ctx.lineTo(right,bottom);ctx.lineTo(left,bottom);ctx.closePath();ctx.stroke();
 ctx.beginPath();ctx.moveTo(w*.5,top+(bottom-top)*.5);ctx.lineTo(w*.5,bottom-(bottom-top)*.5);ctx.stroke();
 ctx.beginPath();ctx.ellipse(w*.5,h*.53,w*.09,h*.055,0,0,Math.PI*2);ctx.stroke();
 // goals
 ctx.strokeRect(w*.43,h*.12,w*.14,h*.045);ctx.strokeRect(w*.40,h*.87,w*.20,h*.055);
 // players sorted by depth
 [...players].sort((a,b)=>a.z-b.z).forEach(p=>{let q=project(p.x,p.z),r=6*q.scale*devicePixelRatio;ctx.fillStyle=p.team===0?"#e8e9ed":"#efb52c";ctx.beginPath();ctx.arc(q.x,q.y,r,0,Math.PI*2);ctx.fill();ctx.fillStyle="#f0c7a4";ctx.beginPath();ctx.arc(q.x,q.y-r*.85,r*.48,0,Math.PI*2);ctx.fill();});
 let bp=project(ball.x,ball.z);ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(bp.x,bp.y,4*devicePixelRatio,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#222";ctx.stroke();
}
function loop(now){if(!match||match.done)return;let dt=Math.min(.04,(now-last)/1000);last=now;elapsed+=dt; // accelerated match clock: 90 game minutes in 6 real minutes
 let mins=Math.min(90,Math.floor(elapsed/4));$("#clock").textContent=String(mins).padStart(2,"0")+":00";
 const controlled=players[7];if(controlled){controlled.x=Math.max(-12,Math.min(12,controlled.x+joy.x*controlled.speed*dt));controlled.z=Math.max(-18,Math.min(18,controlled.z+joy.y*controlled.speed*dt));}
 players.forEach(p=>{if(p.team===1){let aggression=match.diff==="easy"?.55:match.diff==="normal"?.8:match.diff==="hard"?1.05:1.25;let dx=ball.x-p.x,dz=ball.z-p.z,d=Math.hypot(dx,dz);if(d>0.5){p.x+=dx/d*aggression*dt;p.z+=dz/d*aggression*dt}}});
 ball.x+=ball.vx*dt;ball.z+=ball.vz*dt;ball.vx*=.985;ball.vz*=.985;
 if(Math.abs(ball.x)>14){score[ball.x>0?0:1]++;ball.x=0;ball.z=0;ball.vx=ball.vz=0}
 if(Math.abs(ball.z)>20){ball.z=Math.sign(ball.z)*20;ball.vz*=-.4}
 $("#matchNames").textContent=`${match.home}  ${score[0]} - ${score[1]}  ${match.away}`;
 draw();if(mins>=90){finish(false);return}raf=requestAnimationFrame(loop)
}
function nearest(){let p=players[7];return p}
$("#passBtn").onclick=()=>{let p=nearest();ball.x=p.x+(match?2:0);ball.z=p.z;ball.vx=7;ball.vz=-2};
$("#shootBtn").onclick=()=>{let p=nearest();ball.x=p.x;ball.z=p.z;ball.vx=match?13:0;ball.vz=-3};
$("#sprintBtn").onpointerdown=()=>{if(players[7])players[7].speed=3.6};$("#sprintBtn").onpointerup=()=>{if(players[7])players[7].speed=2};
const joyEl=$("#joystick"),stick=joyEl.querySelector(".stick");
function joyMove(e){let r=joyEl.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,dx=e.clientX-cx,dy=e.clientY-cy,len=Math.hypot(dx,dy),max=32;let k=len>max?max/len:1;joy.x=dx*k/max;joy.y=dy*k/max;stick.style.transform=`translate(${dx*k}px,${dy*k}px)`}
joyEl.onpointerdown=e=>{joyEl.setPointerCapture(e.pointerId);joyMove(e)};joyEl.onpointermove=e=>{if(e.buttons)joyMove(e)};joyEl.onpointerup=joyEl.onpointercancel=()=>{joy.x=joy.y=0;stick.style.transform=""};
function finish(abandoned){
 if(!match||match.done)return;match.done=true;cancelAnimationFrame(raf);let won=!abandoned&&score[0]>score[1];let coins=0;
 if(abandoned){score=[0,3];data.losses++;data.streak=0}
 else {data.matches++;if(won){data.wins++;data.streak++;coins=({easy:45,normal:90,hard:135,veryhard:180})[match.diff];if(data.streak===5){coins+=500;data.streak=0;$("#resultMessage").textContent="Vitória! Também completaste 5 vitórias e recebeste 500 moedas de bónus."}else $("#resultMessage").textContent="Partida concluída!";data.coins+=coins}else{data.losses++;data.streak=0;$("#resultMessage").textContent="A partida terminou. Continua a tentar!"}}
 $("#resultTitle").textContent=abandoned?"DERROTA POR ABANDONO":won?"VITÓRIA":score[0]===score[1]?"EMPATE":"DERROTA";
 $("#finalScore").textContent=`${score[0]} - ${score[1]}`;if(abandoned)$("#resultMessage").textContent="Partida cancelada: derrota automática por 0–3. Sem moedas.";
 $("#rewardEarned").textContent=coins?`+${coins} moedas${won&&data.streak===0?" (inclui bónus de 500)":""}`:"0 moedas";save();screen("result");match=null
}
$("#exitMatch").onclick=()=>{if(confirm("Queres abandonar? O resultado será derrota por 0–3 e não receberás moedas."))finish(true)};
window.addEventListener("resize",()=>{if($("#match").classList.contains("active"))resize()});
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
