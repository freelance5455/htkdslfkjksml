window.App = {
    init() {
        try {
            if (window.UI && typeof UI.log === 'function') UI.log('المحرك جاهز للاستخدام.', 'info');
            if (window.FileHandler && typeof FileHandler.init === 'function') FileHandler.init();
            
            this.initAutoPatchSystem();
        } catch (err) {
            console.error('Init Error:', err);
        }
    },

    initAutoPatchSystem() {
        const mainDashboard = document.getElementById('main-dashboard');
        const autoPatchPage = document.getElementById('auto-patch-page');
        const autoPatchBtn = document.getElementById('auto-patch-btn');
        const backToMainBtn = document.getElementById('back-to-main-btn');
        
        const autoChooseBtn = document.getElementById('auto-choose-btn');
        const autoFileInput = document.getElementById('auto-file-input');
        const autoPatchCard = document.querySelector('.auto-patch-card');
        
        const autoProgressContainer = document.getElementById('auto-progress-container');
        const autoProgressText = document.getElementById('auto-progress-text');
        const autoResultCard = document.getElementById('auto-result-card');
        const autoFileDetails = document.getElementById('auto-file-details');
        const downloadPatchedBtn = document.getElementById('download-patched-btn');

        if (autoPatchBtn && autoPatchPage && mainDashboard) {
            autoPatchBtn.addEventListener('click', () => {
                mainDashboard.style.display = 'none';
                autoPatchPage.style.display = 'block';
                if (window.UI && typeof UI.log === 'function') {
                    UI.log('⚡ تم الانتقال إلى واجهة التعديل التلقائي والحقن الذكي.', 'info');
                }
            });
        }

        if (backToMainBtn && autoPatchPage && mainDashboard) {
            backToMainBtn.addEventListener('click', () => {
                autoPatchPage.style.display = 'none';
                mainDashboard.style.display = 'flex';
            });
        }

        // دالة اختيار الملفات المدعومة بالطريقة الحديثة والآمنة (مثل المتصفح)
        const triggerFileSelect = async () => {
            // محاولة استخدام واجهة النظام الحديثة لفتح الملفات بدون أذونات تطبيق معقدة
            if (window.showOpenFilePicker) {
                try {
                    const handles = await window.showOpenFilePicker({
                        types: [{
                            description: 'APK Packages',
                            accept: { 'application/vnd.android.package-archive': ['.apk', '.zip'] }
                        }],
                        multiple: false
                    });
                    if (handles && handles.length > 0) {
                        const file = await handles[0].getFile();
                        const dataTransfer = new DataTransfer();
                        dataTransfer.items.add(file);
                        autoFileInput.files = dataTransfer.files;
                        autoFileInput.dispatchEvent(new Event('change', { bubbles: true }));
                        return;
                    }
                } catch (err) {
                    console.log('Picker dismissed or not fully supported, falling back...');
                }
            }

            // الطريقة التقليدية الاحتياطية
            if (autoFileInput) {
                autoFileInput.style.display = 'block';
                autoFileInput.click();
                setTimeout(() => { autoFileInput.style.display = 'none'; }, 1000);
            }
        };

        if (autoChooseBtn) {
            autoChooseBtn.addEventListener('click', triggerFileSelect);
        }

        if (autoPatchCard) {
            autoPatchCard.addEventListener('click', (e) => {
                if (e.target.tagName !== 'BUTTON' && e.target.tagName !== 'A') {
                    triggerFileSelect();
                }
            });
        }

        if (autoFileInput) {
            autoFileInput.addEventListener('change', async (event) => {
                const file = event.target.files[0];
                if (!file) return;

                if (autoProgressContainer) autoProgressContainer.style.display = 'block';
                if (autoResultCard) autoResultCard.style.display = 'none';
                if (autoProgressText) autoProgressText.innerText = `جاري التعديل الذكي وإصلاح الهيدر وإعادة التوقيع لـ ${file.name}...`;

                try {
                    const patchedBlob = await this.processAndPatchAPK(file);
                    const patchedUrl = URL.createObjectURL(patchedBlob);

                    if (downloadPatchedBtn) {
                        downloadPatchedBtn.href = patchedUrl;
                        downloadPatchedBtn.download = `patched_${file.name}`;
                    }

                    if (autoFileDetails) {
                        autoFileDetails.innerText = `الملف المعدل: patched_${file.name} | الحجم: ${(patchedBlob.size / (1024 * 1024)).toFixed(2)} MB`;
                    }

                    if (autoProgressContainer) autoProgressContainer.style.display = 'none';
                    if (autoResultCard) autoResultCard.style.display = 'block';

                } catch (error) {
                    if (autoProgressContainer) autoProgressContainer.style.display = 'none';
                    alert('⚠️ خطأ أثناء التعديل التلقائي: ' + error.message);
                }
            });
        }
    },

    async processAndPatchAPK(file) {
        if (typeof JSZip === 'undefined') {
            throw new Error("مكتبة JSZip غير مثبتة أو لم يتم تحميلها بشكل صحيح!");
        }

        let zip = new JSZip();
        zip = await zip.loadAsync(file);

        const dexFiles = Object.keys(zip.files).filter(name => name.endsWith('.dex'));

        if (dexFiles.length === 0) {
            throw new Error("لم يتم العثور على أي ملفات DEX داخل الـ APK!");
        }

        // 1. معالجة وحقن وإصلاح هيدر ملفات الـ DEX باستخدام المحرك المطور
        for (let dexName of dexFiles) {
            let dexData = await zip.files[dexName].async("uint8array");
            
            // تطبيق الباتشات الذكية بالأنماط المفتوحة Wildcards
            let patchedData = this.applyPatternPatches(dexData);
            
            // إصلاح Checksum و SHA-1
            let fixedDexData = await this.fixDexHeader(patchedData);

            zip.file(dexName, fixedDexData);
        }

        // 2. تطبيق التوقيع الرقمي تلقائياً عبر محرك APKSigner
        if (window.APKSigner && typeof APKSigner.signAPK === 'function') {
            zip = await window.APKSigner.signAPK(zip);
        } else {
            Object.keys(zip.files).forEach(filename => {
                if (filename.startsWith('META-INF/')) {
                    zip.remove(filename);
                }
            });
        }

        return await zip.generateAsync({ 
            type: "blob", 
            mimeType: "application/vnd.android.package-archive",
            compression: "DEFLATE"
        });
    },

    applyPatternPatches(dexBuffer) {
        let patched = new Uint8Array(dexBuffer);

        // قواعد التعديل الذكي مع دعم الأنماط المتغيرة (Wildcards عبر '??' أو null)
        const patchRules = [
            {
                name: "Bypass Conditional Branch (if-eqz)",
                target:      [0x38, '??', '??', '??'], 
                replacement: [0x28, '??', '??', 0x00]  
            },
            {
                name: "Force Const Return True",
                target:      [0x12, '??', 0x0f, 0x00], 
                replacement: [0x12, 0x10, 0x0f, 0x00] 
            }
        ];

        patchRules.forEach(rule => {
            patched = this.replaceHexPattern(patched, rule.target, rule.replacement);
        });

        return patched;
    },

    replaceHexPattern(buffer, targetPattern, replacementPattern) {
        if (targetPattern.length !== replacementPattern.length) return buffer;

        const targetLength = targetPattern.length;
        for (let i = 0; i <= buffer.length - targetLength; i++) {
            let match = true;

            for (let j = 0; j < targetLength; j++) {
                const expected = targetPattern[j];
                if (expected !== '??' && expected !== null && buffer[i + j] !== expected) {
                    match = false;
                    break;
                }
            }

            if (match) {
                for (let j = 0; j < targetLength; j++) {
                    const rep = replacementPattern[j];
                    if (rep !== '??' && rep !== null) {
                        buffer[i + j] = rep;
                    }
                }
                i += targetLength - 1;
            }
        }
        return buffer;
    },

    async fixDexHeader(bytes) {
        const bodyForSha1 = bytes.subarray(32);
        const sha1Buffer = await crypto.subtle.digest('SHA-1', bodyForSha1);
        const sha1Array = new Uint8Array(sha1Buffer);
        
        bytes.set(sha1Array, 12);

        const bodyForAdler = bytes.subarray(12);
        const checksum = this.calculateAdler32(bodyForAdler);

        const view = new DataView(bytes.buffer);
        view.setUint32(8, checksum, true);

        return bytes;
    },

    calculateAdler32(data) {
        let a = 1;
        let b = 0;
        const MOD_ADLER = 65521;

        for (let i = 0; i < data.length; i++) {
            a = (a + data[i]) % MOD_ADLER;
            b = (b + a) % MOD_ADLER;
        }

        return (b << 16) | a;
    },

    async startAnalysis() {
        try {
            const fileName = AppState.file.name.toLowerCase();

            if (fileName.endsWith('.apk') || fileName.endsWith('.zip')) {
                if (window.UI) UI.updateProgress(50, 'جاري فك APK واستخراج ملفات DEX...');
                const dexList = await ZipHandler.extractDexFiles(AppState.fileBuffer);
                AppState.dexFiles = dexList;
            } else {
                if (window.UI) UI.updateProgress(50, 'جاري قراءة ملف DEX المباشر...');
                AppState.dexFiles = [{
                    name: AppState.file.name,
                    buffer: AppState.fileBuffer
                }];
            }

            if (window.UI) UI.updateProgress(80, 'جاري تفكيك بايتات الـ DEX وجداوله...');
            await new Promise(r => setTimeout(r, 50));

            if (window.Analysis) Analysis.processDexFiles(AppState.dexFiles);

            if (window.UI) {
                UI.updateProgress(100, 'اكتمل التحليل بنجاح!');
                UI.log('تم فك الشفرة واستخراج البيانات بنجاح.', 'success');
            }

        } catch (error) {
            console.error(error);
            if (window.UI) {
                UI.log(`فشل في تحليل الملف: ${error.message}`, 'error');
                UI.hideProgress();
            }
            alert('خطأ أثناء تحليل المحتوى: ' + error.message);
        }
    }
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => window.App.init());
} else {
    window.App.init();
}
