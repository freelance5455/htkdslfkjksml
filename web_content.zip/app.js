let balance=250000, txs=[];
const modal=document.getElementById('modal'), content=document.getElementById('modalContent');
function show(html){content.innerHTML=html;modal.classList.remove('hidden')}
function close(){modal.classList.add('hidden')}
document.getElementById('close').onclick=close;
modal.addEventListener('click',e=>{if(e.target===modal)close()});
function money(n){return n.toLocaleString('en-US')+' ل.س'}
function render(){document.getElementById('balance').textContent=money(balance);const box=document.getElementById('transactions');box.innerHTML=txs.length?txs.slice(0,4).map(t=>`<div class="tx"><div>${t.title}<small>${t.date}</small></div><b>${t.amount}</b></div>`).join(''):'<p class="muted">لا توجد عمليات بعد.</p>'}
function history(){show('<h2>سجل الحركات</h2><p class="muted">هذه حركات تجريبية محفوظة على هذا الجهاز فقط.</p>'+(txs.length?txs.map(t=>`<div class="tx"><div>${t.title}<small>${t.date}</small></div><b>${t.amount}</b></div>`).join(''):'<p>لا توجد عمليات بعد.</p>'))}
function addTx(title,amount){txs.unshift({title,amount,date:new Date().toLocaleString('ar')});render()}
function action(a){
 if(a==='send')show('<h2>إرسال تجريبي</h2><div class="notice">لن يتم إرسال أموال حقيقية. هذه محاكاة محلية فقط.</div><input id="recipient" class="field" placeholder="اسم أو رقم المستلم"><input id="amount" class="field" type="number" min="1" placeholder="المبلغ بالليرة السورية"><button class="primary" id="confirm">تأكيد تجريبي</button>');
 if(a==='receive')show('<h2>استقبال الأموال</h2><p>رمز الاستقبال التجريبي الخاص بك:</p><h2 style="color:#0b6b50;letter-spacing:4px">SHAM-2048</h2><div class="notice">هذا الرمز للعرض فقط ولا يستقبل حوالات فعلية.</div>');
 if(a==='topup')show('<h2>شحن الرصيد التجريبي</h2><input id="amount" class="field" type="number" min="1" placeholder="المبلغ"><button class="primary" id="confirm">إضافة رصيد تجريبي</button>');
 if(a==='history')history();
 document.getElementById('confirm')?.addEventListener('click',()=>{let n=Number(document.getElementById('amount').value);if(!Number.isFinite(n)||n<=0){alert('أدخل مبلغاً صحيحاً');return}if(a==='send'&&n>balance){alert('الرصيد التجريبي غير كافٍ');return}if(a==='send'){let r=document.getElementById('recipient').value.trim();if(!r){alert('أدخل اسم المستلم');return}balance-=n;addTx('إرسال إلى '+r,'− '+money(n))}else{balance+=n;addTx('شحن تجريبي','+ '+money(n))}close();render()});
}
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>action(b.dataset.action)));
document.getElementById('allHistory').onclick=history;
document.getElementById('profileBtn').onclick=()=>show('<h2>حسابي</h2><div class="profileline">الاسم: مستخدم تجريبي</div><div class="profileline">رقم المحفظة: SH-0002048</div><div class="notice" style="margin-top:14px">لا يوجد تسجيل دخول أو تحقق هوية في هذه النسخة.</div>');
document.getElementById('helpBtn').onclick=()=>show('<h2>المساعدة</h2><p>شام سوريا — نموذج أولي لمحفظة إلكترونية.</p><div class="notice">لا تدخل بيانات مصرفية أو كلمات مرور حقيقية. لا توجد تحويلات مالية فعلية أو ربط بمصارف أو شركات دفع.</div>');
render();
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(()=>{});
