(function () {
    'use strict';

    // ===== State =====
    let current = '0';
    let previous = '';
    let operator = null;
    let shouldReset = false;
    let memory = 0;

    // ===== DOM =====
    const display = document.getElementById('display');
    const expression = document.getElementById('expression');
    const copyBtn = document.getElementById('copyBtn');
    const toast = document.getElementById('toast');
    const memoryButtons = document.querySelectorAll('.btn.memory');

    // ===== Helpers =====
    function formatNumber(numStr) {
        if (numStr === 'خطا') return numStr;
        const num = parseFloat(numStr);
        if (isNaN(num)) return '۰';

        // محدودیت نمایش برای جلوگیری از overflow
        if (Math.abs(num) > 1e12 || (Math.abs(num) < 1e-8 && num !== 0)) {
            return num.toExponential(6);
        }

        // جداکننده هزارگان با حفظ اعشار
        const parts = numStr.split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        return parts.join('.');
    }

    function toPersianDigits(str) {
        const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        return str.replace(/\d/g, d => persian[d]);
    }

    function fromPersianDigits(str) {
        const persian = {'۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9'};
        return str.replace(/[۰-۹]/g, d => persian[d]);
    }

    function updateDisplay() {
        let displayValue = current;
        if (displayValue.length > 12) {
            display.classList.add('error');
            display.style.fontSize = '2.2rem';
        } else {
            display.classList.remove('error');
            display.style.fontSize = '';
        }

        display.textContent = toPersianDigits(formatNumber(current));
        
        // ساخت عبارت
        let expr = '';
        if (previous !== '') {
            expr = formatNumber(previous) + ' ' + (operator || '');
        }
        expression.textContent = toPersianDigits(expr);

        // وضعیت دکمه‌های حافظه
        memoryButtons.forEach(btn => {
            if (btn.dataset.action === 'mr' || btn.dataset.action === 'mc') {
                btn.classList.toggle('active', memory !== 0);
            }
        });
    }

    function showToast(message) {
        toast.textContent = message;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 1800);
    }

    function vibrate(ms = 12) {
        if (navigator.vibrate) {
            navigator.vibrate(ms);
        }
    }

    // ===== Core Logic =====
    function inputNumber(num) {
        if (shouldReset) {
            current = num;
            shouldReset = false;
        } else {
            if (current === '0' && num !== '.') {
                current = num;
            } else if (num === '.' && current.includes('.')) {
                return;
            } else {
                if (current.replace('.', '').length >= 12) return;
                current += num;
            }
        }
        updateDisplay();
        vibrate(8);
    }

    function inputOperator(op) {
        if (operator && !shouldReset) {
            calculate();
        }
        previous = current;
        operator = op;
        shouldReset = true;
        updateDisplay();
        vibrate(10);
    }

    function calculate() {
        if (operator === null || shouldReset) return;

        const prev = parseFloat(previous);
        const curr = parseFloat(current);
        let result;

        switch (operator) {
            case '+':
                result = prev + curr;
                break;
            case '−':
                result = prev - curr;
                break;
            case '×':
                result = prev * curr;
                break;
            case '÷':
                if (curr === 0) {
                    current = 'خطا';
                    previous = '';
                    operator = null;
                    shouldReset = true;
                    updateDisplay();
                    vibrate([30, 40, 30]);
                    showToast('تقسیم بر صفر مجاز نیست');
                    return;
                }
                result = prev / curr;
                break;
            default:
                return;
        }

        // گرد کردن برای جلوگیری از خطاهای اعشاری
        result = parseFloat(result.toPrecision(12));
        current = String(result);
        previous = '';
        operator = null;
        shouldReset = true;
        updateDisplay();
        vibrate(15);
    }

    function clearAll() {
        current = '0';
        previous = '';
        operator = null;
        shouldReset = false;
        updateDisplay();
        vibrate(20);
    }

    function backspace() {
        if (shouldReset) return;
        if (current.length === 1 || (current.length === 2 && current.startsWith('-'))) {
            current = '0';
        } else {
            current = current.slice(0, -1);
        }
        updateDisplay();
        vibrate(8);
    }

    function toggleSign() {
        if (current === '0' || current === 'خطا') return;
        current = current.startsWith('-') ? current.slice(1) : '-' + current;
        updateDisplay();
        vibrate(10);
    }

    function percent() {
        const num = parseFloat(current);
        current = String(num / 100);
        updateDisplay();
        vibrate(10);
    }

    // ===== Memory Functions =====
    function memoryClear() {
        memory = 0;
        localStorage.setItem('calc_memory', '0');
        updateDisplay();
        showToast('حافظه پاک شد');
        vibrate(15);
    }

    function memoryRecall() {
        current = String(memory);
        shouldReset = true;
        updateDisplay();
        vibrate(10);
    }

    function memoryAdd() {
        memory += parseFloat(current) || 0;
        localStorage.setItem('calc_memory', String(memory));
        showToast('به حافظه اضافه شد');
        vibrate(12);
        updateDisplay();
    }

    function memorySubtract() {
        memory -= parseFloat(current) || 0;
        localStorage.setItem('calc_memory', String(memory));
        showToast('از حافظه کم شد');
        vibrate(12);
        updateDisplay();
    }

    // ===== Copy =====
    function copyResult() {
        const text = current === 'خطا' ? '' : current;
        if (!text) return;

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(() => {
                showToast('نتیجه کپی شد');
                vibrate(15);
            }).catch(() => {
                fallbackCopy(text);
            });
        } else {
            fallbackCopy(text);
        }
    }

    function fallbackCopy(text) {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        try {
            document.execCommand('copy');
            showToast('نتیجه کپی شد');
            vibrate(15);
        } catch (e) {
            showToast('کپی پشتیبانی نمی‌شود');
        }
        document.body.removeChild(textarea);
    }

    // ===== Event Listeners =====
    document.querySelectorAll('.btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const value = btn.dataset.value;
            const action = btn.dataset.action;

            if (value !== undefined) {
                if (['+', '−', '×', '÷'].includes(value)) {
                    inputOperator(value);
                } else {
                    inputNumber(value);
                }
            } else if (action) {
                switch (action) {
                    case 'clear': clearAll(); break;
                    case 'backspace': backspace(); break;
                    case 'equals': calculate(); break;
                    case 'sign': toggleSign(); break;
                    case 'percent': percent(); break;
                    case 'mc': memoryClear(); break;
                    case 'mr': memoryRecall(); break;
                    case 'm+': memoryAdd(); break;
                    case 'm-': memorySubtract(); break;
                }
            }
        });
    });

    copyBtn.addEventListener('click', copyResult);

    // پشتیبانی از کیبورد
    document.addEventListener('keydown', (e) => {
        const key = e.key;

        if (/^[0-9.]$/.test(key)) {
            e.preventDefault();
            inputNumber(key);
        } else if (key === '+' || key === '-') {
            e.preventDefault();
            inputOperator(key === '-' ? '−' : '+');
        } else if (key === '*' || key === 'x') {
            e.preventDefault();
            inputOperator('×');
        } else if (key === '/') {
            e.preventDefault();
            inputOperator('÷');
        } else if (key === 'Enter' || key === '=') {
            e.preventDefault();
            calculate();
        } else if (key === 'Escape' || key === 'c' || key === 'C') {
            e.preventDefault();
            clearAll();
        } else if (key === 'Backspace') {
            e.preventDefault();
            backspace();
        } else if (key === '%') {
            e.preventDefault();
            percent();
        }
    });

    // بارگذاری حافظه از localStorage
    const savedMemory = localStorage.getItem('calc_memory');
    if (savedMemory !== null) {
        memory = parseFloat(savedMemory) || 0;
    }

    // شروع
    updateDisplay();
})();
