const $=id=>document.getElementById(id);
const chat=$('chat'); let apiKey='', voices=[];
function say(text){if(!('speechSynthesis'in window))return; speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);const v=voices.find(x=>x.name===$('voiceSelect').value);if(v)u.voice=v;u.rate=1;u.pitch=1; speechSynthesis.speak(u)}
function add(text,who='bot'){const d=document.createElement('div');d.className='bubble '+who;d.textContent=text;chat.appendChild(d);chat.scrollTop=chat.scrollHeight}
function setStatus(s){$('status').textContent=s}
function localCommand(q){const s=q.toLowerCase().trim();
 if(/^(hi|hello|hey hermes)\b/.test(s))return "Hello. Hermes is ready.";
 if(s.includes('time'))return "The time is "+new Date().toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})+".";
 if(s.includes('date')||s.includes('today'))return "Today is "+new Date().toLocaleDateString(undefined,{weekday:'long',year:'numeric',month:'long',day:'numeric'})+".";
 if(s.includes('open youtube')){window.open('https://m.youtube.com','_blank');return "Opening YouTube."}
 if(s.includes('open google')){window.open('https://google.com','_blank');return "Opening Google."}
 if(s.includes('search')){let term=q.replace(/search (the web )?(for )?/i,'').replace(/^(web )/i,'');window.open('https://www.google.com/search?q='+encodeURIComponent(term),'_blank');return "Searching the web for "+term+"."}
 if(s.includes('joke'))return "Why did the computer get cold? It left its Windows open.";
 if(s.includes('fun fact'))return "A day on Venus is longer than its year.";
 if(s.includes('help'))return "I can tell the time and date, open YouTube or Google, search the web, tell a joke, and answer questions using an API key.";
 return null;
}
async function ask(q){if(!q.trim())return;add(q,'user');$('message').value='';setStatus('THINKING');$('subtitle').textContent='Processing your request…';
 const local=localCommand(q);if(local){add(local);say(local);setStatus('SYSTEM READY');$('subtitle').textContent='At your service.';return}
 if(!apiKey){const m="Online AI is not configured. Open Settings and paste a valid OpenRouter API key. Local commands still work.";add(m);say(m);setStatus('OFFLINE COMMAND MODE');return}
 try{const r=await fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{'Authorization':'Bearer '+apiKey,'Content-Type':'application/json','X-Title':'Hermes Android Assistant'},body:JSON.stringify({model:'openrouter/free',messages:[{role:'system',content:'You are Hermes, a concise, helpful voice assistant. Keep spoken answers natural and clear.'},{role:'user',content:q}]})});
 const data=await r.json();if(!r.ok)throw new Error(data.error?.message||'API request failed');const answer=data.choices?.[0]?.message?.content||'I could not generate a response.';add(answer);say(answer);setStatus('SYSTEM READY');
 }catch(e){add('Online AI error: '+e.message);setStatus('CONNECTION ERROR')} $('subtitle').textContent='At your service.';
}
$('send').onclick=()=>ask($('message').value);$('message').addEventListener('keydown',e=>{if(e.key==='Enter')ask($('message').value)});
document.querySelectorAll('[data-cmd]').forEach(b=>b.onclick=()=>ask(b.dataset.cmd));
$('micBtn').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){add('Voice recognition is not supported in this browser. Try Chrome on Android.');return}
 const rec=new SR();rec.lang=navigator.language||'en-IN';rec.interimResults=false;rec.maxAlternatives=1;rec.onstart=()=>{$('core').classList.add('listening');setStatus('LISTENING')};rec.onend=()=>{$('core').classList.remove('listening');if($('status').textContent==='LISTENING')setStatus('SYSTEM READY')};rec.onerror=e=>add('Microphone error: '+e.error);rec.onresult=e=>ask(e.results[0][0].transcript);rec.start()};
$('settingsBtn').onclick=()=>$('settings').showModal();$('closeSettings').onclick=()=>$('settings').close();$('saveSettings').onclick=()=>{apiKey=$('apiKey').value.trim();$('settings').close();add(apiKey?'API key set for this session.':'API key cleared.');};
function loadVoices(){voices=speechSynthesis.getVoices();const sel=$('voiceSelect');const current=sel.value;sel.innerHTML='<option value="">System default</option>';voices.forEach(v=>{const o=document.createElement('option');o.value=v.name;o.textContent=v.name+' ('+v.lang+')';sel.appendChild(o)});sel.value=current}
if('speechSynthesis'in window){loadVoices();speechSynthesis.onvoiceschanged=loadVoices}
$('greeting').textContent=new Date().getHours()<12?'Good morning.':new Date().getHours()<18?'Good afternoon.':'Good evening.';
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
