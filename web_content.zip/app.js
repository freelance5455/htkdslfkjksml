const form=document.getElementById('chatForm'), input=document.getElementById('prompt'), messages=document.getElementById('messages'), welcome=document.getElementById('welcome');
const drawer=document.getElementById('drawer'), historyBox=document.getElementById('history');
let chatCount=0;
function addMessage(text,who){const row=document.createElement('div');row.className='message '+who;if(who==='assistant'){const av=document.createElement('div');av.className='avatar';av.textContent='✳';row.appendChild(av)}const b=document.createElement('div');b.className='bubble';b.textContent=text;row.appendChild(b);messages.appendChild(row);document.querySelector('main').scrollTop=document.querySelector('main').scrollHeight;return b}
function send(text){text=(text||'').trim();if(!text)return;welcome.style.display='none';addMessage(text,'user');input.value='';input.style.height='auto';const wait=addMessage('Это демонстрационный интерфейс. Чтобы получать настоящие ответы Claude, приложение нужно подключить к официальному API через защищённый сервер. Не вставляйте секретный API-ключ прямо в APK.','assistant');}
form.addEventListener('submit',e=>{e.preventDefault();send(input.value)});
input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,130)+'px'});
document.querySelectorAll('.suggestion').forEach(b=>b.addEventListener('click',()=>send(b.dataset.prompt)));
document.getElementById('menuBtn').onclick=()=>drawer.classList.add('open');
document.getElementById('closeDrawer').onclick=()=>drawer.classList.remove('open');
function newChat(){messages.innerHTML='';welcome.style.display='block';drawer.classList.remove('open');chatCount++;const item=document.createElement('div');item.className='history-item';item.textContent='Новый разговор '+chatCount;historyBox.prepend(item)}
document.getElementById('newBtn').onclick=newChat;document.getElementById('drawerNew').onclick=newChat;
document.getElementById('attachBtn').onclick=()=>document.getElementById('fileInput').click();
document.getElementById('fileInput').onchange=e=>{if(e.target.files[0])addMessage('Выбран файл: '+e.target.files[0].name,'user')};
