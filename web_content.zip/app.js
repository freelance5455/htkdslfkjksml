// FAZ3A STORE — Firebase web starter.
// 1) Create a Firebase project and enable Email/Password Authentication, Firestore, and Storage.
// 2) Paste your Firebase web config below.
// 3) After signing in, copy your Firebase Auth UID into ADMIN_UID below AND into the security rules.
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore, collection, addDoc, query, where, orderBy, onSnapshot, doc, updateDoc, deleteDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyArp6kGM8e-vs2kGRC7kH7eeT9ODkrB2XM",
  authDomain: "faz3a-store.firebaseapp.com",
  projectId: "faz3a-store",
  storageBucket: "faz3a-store.firebasestorage.app",
  messagingSenderId: "886173326756",
  appId: "1:886173326756:web:8e7391404942951269b531",
  measurementId: "G-NPKZ6KCDJN"
};
const ADMIN_UID = "PASTE_YOUR_ADMIN_UID";
const MAX_APK_BYTES = 1024 * 1024 * 1024; // 1 GiB per APK. Storage quota/billing may impose lower limits.

const $ = id => document.getElementById(id);
const app = initializeApp(firebaseConfig), auth = getAuth(app), db = getFirestore(app), storage = getStorage(app);
let currentUser = null, unsubscribeStore = null, unsubscribeMine = null, unsubscribePending = null;

function notify(message, error=false){const n=$("notice");n.textContent=message;n.className="notice show"+(error?" error":"");setTimeout(()=>n.classList.remove("show"),5000)}
function safeText(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function show(id,yes){$(id).classList.toggle("hidden",!yes)}
function requireConfig(){
  if(firebaseConfig.apiKey.startsWith("PASTE_")||firebaseConfig.projectId.startsWith("PASTE_")){notify("أكمل إعداد Firebase داخل ملف app.js أولًا.",true);return false}
  return true;
}
function niceDate(ts){try{return ts?.toDate().toLocaleDateString("ar-EG")||"حديثًا"}catch{return"حديثًا"}}
function cardHtml(a,id,admin=false,mine=false){
 const icon=a.iconURL?`<img class="app-icon" src="${safeText(a.iconURL)}" alt="">`:`<div class="app-icon">APK</div>`;
 let buttons="";
 if(admin) buttons=`<div class="admin-actions"><button class="approve" data-action="approve" data-id="${id}">موافقة</button><button class="reject" data-action="reject" data-id="${id}">رفض وحذف</button></div>`;
 else if(a.status==="approved") buttons=`<button data-action="download" data-url="${safeText(a.downloadURL||"")}" data-name="${safeText(a.name)}">تنزيل APK</button>`;
 return `<article class="app-card"><div class="app-head">${icon}<div><h3>${safeText(a.name)}</h3><span class="tag">${a.status==="approved"?"معتمد":a.status==="pending"?"قيد المراجعة":"مرفوض"}</span></div></div><p>${safeText(a.description||"لا يوجد وصف")}</p><p>بواسطة: ${safeText(a.ownerEmail||"مستخدم")} • ${niceDate(a.createdAt)}</p>${buttons}</article>`;
}
function renderEmpty(el,msg){$(el).innerHTML=`<div class="empty">${msg}</div>`}
function watchStore(){
 if(unsubscribeStore)unsubscribeStore();
 unsubscribeStore=onSnapshot(query(collection(db,"apps"),where("status","==","approved")),snap=>{
   const list=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));
   $("storeApps").innerHTML=list.length?list.map(a=>cardHtml(a,a.id)).join(""):"";
   if(!list.length)renderEmpty("storeApps","لا توجد تطبيقات معتمدة حتى الآن.");
 },e=>notify("تعذر تحميل المتجر: "+e.message,true));
}
function watchMine(){
 if(unsubscribeMine)unsubscribeMine();
 unsubscribeMine=onSnapshot(query(collection(db,"apps"),where("ownerUid","==",currentUser.uid)),snap=>{
   const list=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.createdAt?.seconds||0)-(a.createdAt?.seconds||0));
   $("myApps").innerHTML="<h3 style='margin-top:22px'>تطبيقاتي</h3>"+(list.length?`<div class="app-grid">${list.map(a=>cardHtml(a,a.id,false,true)).join("")}</div>`:"<p class='muted'>لم ترسل أي تطبيق بعد.</p>");
 },e=>notify("تعذر تحميل تطبيقاتك: "+e.message,true));
}
function watchPending(){
 if(unsubscribePending)unsubscribePending();
 unsubscribePending=onSnapshot(query(collection(db,"apps"),where("status","==","pending")),snap=>{
   const list=snap.docs.map(d=>({id:d.id,...d.data()}));
   $("pendingApps").innerHTML=list.length?`<div class="app-grid">${list.map(a=>cardHtml(a,a.id,true)).join("")}</div>`:"<div class='empty'>لا توجد طلبات تنتظر المراجعة.</div>";
 },e=>notify("تعذر تحميل الطلبات: "+e.message,true));
}
$("signupBtn").onclick=async()=>{if(!requireConfig())return;try{await createUserWithEmailAndPassword(auth,$("email").value.trim(),$("password").value);notify("تم إنشاء الحساب.");}catch(e){notify(e.message,true)}};
$("loginBtn").onclick=async()=>{if(!requireConfig())return;try{await signInWithEmailAndPassword(auth,$("email").value.trim(),$("password").value);notify("تم تسجيل الدخول.");}catch(e){notify(e.message,true)}};
$("logoutBtn").onclick=()=>signOut(auth).catch(e=>notify(e.message,true));
$("refreshBtn").onclick=()=>{watchStore();notify("تم تحديث قائمة المتجر.")};
$("uploadBtn").onclick=async()=>{
 if(!currentUser)return notify("سجّل الدخول أولًا.",true);
 const name=$("appName").value.trim(),description=$("appDescription").value.trim(),apk=$("apkFile").files[0],icon=$("appIcon").files[0];
 if(!name||!apk)return notify("اكتب اسم التطبيق واختر ملف APK.",true);
 if(!apk.name.toLowerCase().endsWith(".apk"))return notify("اختر ملفًا بامتداد APK.",true);
 if(apk.size>MAX_APK_BYTES)return notify("حجم الملف أكبر من 1 جيجابايت.",true);
 if(apk.size===0)return notify("الملف فارغ.",true);
 const btn=$("uploadBtn");btn.disabled=true;btn.textContent="جارٍ الرفع…";
 try{
   const appRef=await addDoc(collection(db,"apps"),{name,description,status:"pending",ownerUid:currentUser.uid,ownerEmail:currentUser.email||"",fileName:apk.name,fileSize:apk.size,createdAt:serverTimestamp(),downloadURL:"",iconURL:"",storagePath:"",iconPath:""});
   const apkPath=`uploads/${currentUser.uid}/${appRef.id}/app.apk`;
   await uploadBytes(ref(storage,apkPath),apk,{contentType:"application/vnd.android.package-archive"});
   const patch={storagePath:apkPath};
   if(icon){if(!/^image\/(png|jpeg|webp)$/.test(icon.type))throw new Error("صيغة صورة الأيقونة غير مدعومة.");const iconPath=`uploads/${currentUser.uid}/${appRef.id}/icon`;await uploadBytes(ref(storage,iconPath),icon);patch.iconPath=iconPath;patch.iconURL=await getDownloadURL(ref(storage,iconPath))}
   await updateDoc(doc(db,"apps",appRef.id),patch);
   $("appName").value="";$("appDescription").value="";$("apkFile").value="";$("appIcon").value="";
   notify("تم رفع التطبيق وإرساله للمراجعة.");
 }catch(e){notify("فشل الرفع: "+e.message,true)}finally{btn.disabled=false;btn.textContent="إرسال للمراجعة"}
};
document.addEventListener("click",async e=>{
 const b=e.target.closest("button[data-action]");if(!b)return;
 const action=b.dataset.action;
 if(action==="download"){if(!b.dataset.url)return notify("رابط التنزيل غير جاهز.",true);const a=document.createElement("a");a.href=b.dataset.url;a.download=(b.dataset.name||"app")+".apk";a.target="_blank";a.rel="noopener";a.click();return}
 if(!currentUser||currentUser.uid!==ADMIN_UID)return notify("هذه العملية للمشرف فقط.",true);
 const id=b.dataset.id;b.disabled=true;
 try{
  const snapDoc=doc(db,"apps",id);
  if(action==="approve"){
   const {getDoc}=await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js");
   const s=await getDoc(snapDoc);if(!s.exists())throw new Error("الطلب غير موجود");
   const data=s.data();if(!data.storagePath)throw new Error("ملف APK غير موجود");
   const url=await getDownloadURL(ref(storage,data.storagePath));
   await updateDoc(snapDoc,{status:"approved",downloadURL:url,reviewedAt:serverTimestamp()});
   notify("تمت الموافقة وأصبح التطبيق ظاهرًا في المتجر.");
  }else if(action==="reject"){
   const {getDoc}=await import("https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js");
   const s=await getDoc(snapDoc);if(!s.exists())throw new Error("الطلب غير موجود");
   const data=s.data();
   await deleteDoc(snapDoc);
   if(data.storagePath)await deleteObject(ref(storage,data.storagePath)).catch(()=>{});
   if(data.iconPath)await deleteObject(ref(storage,data.iconPath)).catch(()=>{});
   notify("تم رفض الطلب وحذفه.");
  }
 }catch(err){notify("تعذر تنفيذ العملية: "+err.message,true)}finally{b.disabled=false}
});
onAuthStateChanged(auth,user=>{
 currentUser=user;show("authPanel",!user);show("userPanel",!!user);show("logoutBtn",!!user);show("adminPanel",!!user&&user.uid===ADMIN_UID);
 if(unsubscribeMine)unsubscribeMine();if(unsubscribePending)unsubscribePending();
 if(user){watchMine();if(user.uid===ADMIN_UID)watchPending()}watchStore();
});
