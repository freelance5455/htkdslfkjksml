window.App = {
    init() {
        try {
            if (window.UI) UI.log('المحرك جاهز للاستخدام.', 'info');
            if (window.FileHandler) FileHandler.init();
        } catch (err) {
            console.error('Init Error:', err);
        }
    },

    async startAnalysis() {
        try {
            const fileName = AppState.file.name.toLowerCase();

            if (fileName.endsWith('.apk') || fileName.endsWith('.zip')) {
                if (window.UI) UI.updateProgress(50, 'جاري فك APK واستخراج ملفات DEX...');
                const dexList = await ZipHandler.extractDexFiles(AppState.fileBuffer);
                AppState.dexFiles = dexList;
            } else {
                if (window.UI) UI.updateProgress(50, 'جاري قراءة ملف DEX المباشر...');
                AppState.dexFiles = [{
                    name: AppState.file.name,
                    buffer: AppState.fileBuffer
                }];
            }

            if (window.UI) UI.updateProgress(80, 'جاري تفكيك بايتات الـ DEX وجداوله...');
            await new Promise(r => setTimeout(r, 50));

            if (window.Analysis) Analysis.processDexFiles(AppState.dexFiles);

            if (window.UI) {
                UI.updateProgress(100, 'اكتمل التحليل بنجاح!');
                UI.log('تم فك الشفرة واستخراج البيانات بنجاح.', 'success');
            }

        } catch (error) {
            console.error(error);
            if (window.UI) {
                UI.log(`فشل في تحليل الملف: ${error.message}`, 'error');
                UI.hideProgress();
            }
            alert('خطأ أثناء تحليل المحتوى: ' + error.message);
        }
    }
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => window.App.init());
} else {
    window.App.init();
}
