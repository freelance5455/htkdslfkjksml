const views=[...document.querySelectorAll(".view")];
const drawer=document.getElementById("drawer");
const menuBtn=document.getElementById("menuBtn");
const installBtn=document.getElementById("installBtn");
let deferredPrompt=null;

function showView(id){
  views.forEach(v=>v.classList.toggle("active",v.id===id));
  drawer.classList.remove("open");
  drawer.setAttribute("aria-hidden","true");
  window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll("[data-view]").forEach(el=>el.addEventListener("click",()=>showView(el.dataset.view)));
menuBtn.addEventListener("click",()=>{
  const open=drawer.classList.toggle("open");
  drawer.setAttribute("aria-hidden",String(!open));
});

const lightbox=document.getElementById("lightbox");
document.getElementById("zoomBtn").onclick=()=>lightbox.classList.add("open");
document.getElementById("closeLightbox").onclick=()=>lightbox.classList.remove("open");
lightbox.addEventListener("click",e=>{if(e.target===lightbox)lightbox.classList.remove("open")});

const topics={
  "Malaria":"Revision focus: assess fever and danger signs, confirm diagnosis according to local protocol, administer prescribed antimalarial treatment safely, monitor response, hydration and complications, and provide prevention education.",
  "Stroke":"Revision focus: treat stroke as an emergency. Prioritise airway, breathing and circulation, rapid neurological assessment, blood glucose, vital signs, urgent referral/imaging and prevention of aspiration and complications.",
  "Paediatrics":"Revision focus: assess the child systematically, identify danger signs early, monitor respiratory rate, temperature, hydration, feeding and consciousness, and escalate deterioration promptly.",
  "Maternal Health":"Revision focus: monitor mother and fetus, identify danger signs, provide respectful care, administer prescribed medicines safely, document findings and escalate abnormal observations."
};
document.querySelectorAll(".study-card").forEach(card=>{
  card.addEventListener("click",()=>{
    const topic=card.dataset.topic;
    document.getElementById("studyOutput").innerHTML=`<strong>${topic}</strong><br>${topics[topic]}<br><small>Educational revision only — follow your clinical guidelines and facility protocols.</small>`;
  });
});

window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault(); deferredPrompt=e; installBtn.hidden=false;
});
installBtn?.addEventListener("click",async()=>{
  if(!deferredPrompt)return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt=null; installBtn.hidden=true;
});

if("serviceWorker" in navigator){
  window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js"));
}