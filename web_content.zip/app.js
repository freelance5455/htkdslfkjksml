var D=window.DATA,$=function(i){return document.getElementById(i)};
function lookup(t,v,label,errs){
 if(v===""||v===null||isNaN(v)||v<=0)return 0;            // قاعدة الصفر
 for(var i=0;i<t.length;i++)if(v>=t[i].min&&v<=t[i].max)return t[i].index;
 errs.push(label+": القيمة "+v+" خارج الجدول (الحد الأقصى "+t[t.length-1].max+")");return 0}
function paxLookup(t,v,label,errs){ // جداول الركاب: ركاب -> مؤشر
 if(v===""||isNaN(v)||v<=0)return 0;
 for(var i=0;i<t.length;i++)if(v>=t[i].min&&v<=t[i].max)return t[i].index;
 errs.push(label+": عدد الركاب "+v+" خارج الجدول (الحد الأقصى "+t[t.length-1].max+")");return 0}
function r1(x){return Math.round(x*10)/10}
function sg(n){return n>0?"+"+n:""+n}
function compute(inp){
 var e=[],c=D.crew.filter(function(x){return x.crew===inp.crew})[0];
 if(!c){return{errors:["اختر الطاقم"]}}
 var k={};["CPT1","CPT2","CPT3","CPT4"].forEach(function(n){k[n]=lookup(D.cargo[n],inp[n],n,e)});
 var p={};["0A","0B","0C","0D"].forEach(function(n){p[n]=paxLookup(D.pax[n],inp[n],n,e)});
 var f=lookup(D.fuel,inp.fuel,"Fuel",e);
 var dli=r1(c.doi+k.CPT1+k.CPT2+k.CPT3+k.CPT4);
 var zfw=r1(dli+p["0A"]+p["0B"]+p["0C"]+p["0D"]);
 var tow=r1(zfw+f);
 return{errors:e,DOW:c.dow,DOI:c.doi,k:k,p:p,FuelIndex:f,DLI:dli,LI_ZFW:zfw,LI_TOW:tow}}
function row(a,b,cls){return'<div class="'+(cls||"")+'"><span>'+a+'</span><b>'+b+'</b></div>'}
function setBoxes(z,t){$("bZFW").innerHTML=z;$("bTOW").innerHTML=t}
function show(r){
 var h="";setBoxes("--","--");
 if(r.errors&&r.errors.length)h+='<div class="err">'+r.errors.join("<br>")+'</div>';
 if(r.DLI===undefined){$("out").innerHTML=h;return}
 if(!(r.errors&&r.errors.length))setBoxes(r.LI_ZFW,r.LI_TOW);
 h+=row("DOW",r.DOW+" kg")+row("DOI",r.DOI);
 for(var n in r.k)h+=row(n,sg(r.k[n]));
 h+=row("DLI",r.DLI,"big");
 for(var n in r.p)h+=row(n,sg(r.p[n]));
 h+=row("LI ZFW",r.LI_ZFW,"big")+row("Fuel Index",sg(r.FuelIndex))+row("LI TOW",r.LI_TOW,"big");
 $("out").innerHTML=h}
function val(id){var v=$(id).value;return v===""?0:parseFloat(v)}
function read(){return{crew:$("crew").value,CPT1:val("CPT1"),CPT2:val("CPT2"),CPT3:val("CPT3"),CPT4:val("CPT4"),
 "0A":val("0A"),"0B":val("0B"),"0C":val("0C"),"0D":val("0D"),fuel:val("fuel")}}
function init(){
 $("crew").innerHTML=D.crew.map(function(c){return'<option>'+c.crew+'</option>'}).join("");
 $("crew").value="3/3";
 $("calc").onclick=function(){show(compute(read()))};
 $("reset").onclick=function(){
  ["CPT1","CPT2","CPT3","CPT4","0A","0B","0C","0D","fuel"].forEach(function(i){$(i).value=""});
  $("out").innerHTML="أدخل البيانات ثم اضغط احسب";setBoxes("--","--")};}
init();
