let currentUser = null;
let currentScreen = 'login';
let currentRole = null;
let tasks = [];
let brigadiers = [];
let workers = [];
let archive = [];
let nextTaskId = 1001;
let adminPassword = '4963';
let photos = [];

// Sample data
const sampleBrigadiers = [
  { id: 1, name: 'Иванов Сергей Петрович', active: true },
  { id: 2, name: 'Сидоров Алексей Иванович', active: true },
  { id: 3, name: 'Кузнецова Ольга Михайловна', active: false }
];

const sampleWorkers = [
  { id: 1, name: 'Петров Дмитрий Александрович' },
  { id: 2, name: 'Васильев Николай Сергеевич' },
  { id: 3, name: 'Морозова Анна Викторовна' },
  { id: 4, name: 'Смирнов Павел Игоревич' }
];

const sampleTasks = [
  {
    id: 1001,
    status: 'new',
    address: 'ул. Ленина, 45, кв. 12',
    description: 'Замена газового счетчика',
    priority: 'high',
    departureTime: '2025-04-05 09:00',
    assignedTo: null,
    acceptedBy: null
  },
  {
    id: 1002,
    status: 'inwork',
    address: 'пр. Мира, 17, кв. 83',
    description: 'Устранение утечки газа в подъезде',
    priority: 'high',
    departureTime: '2025-04-04 14:30',
    assignedTo: 1,
    acceptedBy: 1,
    car: 'А123ВС 150',
    brigade: [1, 2],
    startTime: '2025-04-04 14:45',
    report: 'Утечка устранена. Заменён вентиль.',
    photos: ['https://picsum.photos/id/1015/600/800']
  },
  {
    id: 1003,
    status: 'done',
    address: 'ул. Советская, 8',
    description: 'Проверка газового оборудования',
    priority: 'medium',
    departureTime: '2025-04-03 11:00',
    assignedTo: 2,
    acceptedBy: 2,
    car: 'В456ГД 150',
    brigade: [2, 4],
    startTime: '2025-04-03 11:10',
    endTime: '2025-04-03 12:05',
    report: 'Все приборы в норме.',
    photos: ['https://picsum.photos/id/160/600/800', 'https://picsum.photos/id/201/600/800']
  }
];

const sampleArchive = [
  {
    id: 987,
    address: 'ул. Гагарина, 22, кв. 5',
    description: 'Монтаж нового газопровода',
    report: 'Работы завершены успешно. Бригада: Сидоров А.И., Петров Д.А. Авто: А789КЛ 150. Время: 2ч 15м.',
    photos: ['https://picsum.photos/id/29/600/800'],
    brigadeNames: 'Сидоров А.И., Петров Д.А.',
    car: 'А789КЛ 150',
    startTime: '2025-03-28 10:00',
    endTime: '2025-03-28 12:15',
    duration: '2ч 15м',
    brigadier: 'Сидоров Алексей Иванович'
  }
];

function saveData() {
  localStorage.setItem('bgs_tasks', JSON.stringify(tasks));
  localStorage.setItem('bgs_brigadiers', JSON.stringify(brigadiers));
  localStorage.setItem('bgs_workers', JSON.stringify(workers));
  localStorage.setItem('bgs_archive', JSON.stringify(archive));
  localStorage.setItem('bgs_admin_password', adminPassword);
}

function loadData() {
  if (localStorage.getItem('bgs_tasks')) {
    tasks = JSON.parse(localStorage.getItem('bgs_tasks'));
    nextTaskId = Math.max(...tasks.map(t => t.id)) + 1;
  } else {
    tasks = [...sampleTasks];
  }
  if (localStorage.getItem('bgs_brigadiers')) {
    brigadiers = JSON.parse(localStorage.getItem('bgs_brigadiers'));
  } else {
    brigadiers = [...sampleBrigadiers];
  }
  if (localStorage.getItem('bgs_workers')) {
    workers = JSON.parse(localStorage.getItem('bgs_workers'));
  } else {
    workers = [...sampleWorkers];
  }
  if (localStorage.getItem('bgs_archive')) {
    archive = JSON.parse(localStorage.getItem('bgs_archive'));
  } else {
    archive = [...sampleArchive];
  }
  if (localStorage.getItem('bgs_admin_password')) {
    adminPassword = localStorage.getItem('bgs_admin_password');
  }
}

function showToast(message) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.getElementById('app').appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 2500);
}

function renderHeader(title, showBack = false) {
  return `
    <header>
      ${showBack ? `<div onclick="navigate('back')" class="back">←</div>` : `<div style="width:32px"></div>`}
      <div>${title}</div>
      <div style="width:32px"></div>
    </header>
  `;
}

function renderLogin() {
  return `
    <div style="flex:1;display:flex;align-items:center;justify-content:center;flex-direction:column;padding:40px 20px;background:linear-gradient(180deg, #0052cc 0%, #003399 100%);color:white;">
      <div style="width:92px;height:92px;background:white;border-radius:50%;display:flex;align-items:center;justify-content:center;margin-bottom:24px;box-shadow:0 8px 20px rgba(0,0,0,0.2);"><span style="font-size:42px">🔧</span></div>
      <h1 style="font-size:28px;margin:0 0 8px">БГС</h1>
      <p style="margin:0 0 60px;opacity:0.9;font-size:15px">Богородская Газовая Служба</p>
      
      <div onclick="switchRole('admin')" style="background:white;color:#003399;width:100%;max-width:280px;padding:18px;border-radius:16px;margin-bottom:16px;text-align:center;font-weight:600;cursor:pointer;box-shadow:0 6px 16px rgba(0,0,0,0.15)">Войти как Администратор</div>
      <div onclick="switchRole('brigadier')" style="background:rgba(255,255,255,0.2);width:100%;max-width:280px;padding:18px;border-radius:16px;text-align:center;font-weight:600;cursor:pointer">Войти как Бригадир</div>
    </div>
  `;
}

function switchRole(role) {
  currentRole = role;
  if (role === 'admin') {
    currentScreen = 'admin-login';
  } else {
    currentScreen = 'brigadier-select';
  }
  render();
}

function renderAdminLogin() {
  return `
    ${renderHeader('Вход администратора')}
    <div class="screen-content" style="padding-top:60px">
      <div class="card">
        <div class="input-group">
          <label>Пароль</label>
          <input type="password" id="admin-pass" placeholder="Введите пароль" onkeypress="if(event.key==='Enter') adminLogin()">
        </div>
        <button onclick="adminLogin()" class="btn btn-primary">Войти</button>
      </div>
      <div style="text-align:center;margin-top:30px;font-size:13px;color:#666">Начальный пароль: 4963</div>
    </div>
  `;
}

function adminLogin() {
  const passInput = document.getElementById('admin-pass');
  if (!passInput) return;
  if (passInput.value === adminPassword) {
    currentUser = { role: 'admin', name: 'Администратор' };
    currentScreen = 'admin-main';
    render();
  } else {
    showToast('Неверный пароль');
  }
}

function renderBrigadierSelect() {
  let html = renderHeader('Выберите бригадира');
  html += `<div class="screen-content">`;
  brigadiers.filter(b => b.active).forEach(brig => {
    html += `
      <div onclick="loginAsBrigadier(${brig.id})" class="list-item" style="margin-bottom:12px;border-radius:12px;box-shadow:var(--shadow-sm)">
        <div>
          <div style="font-weight:600">${brig.name}</div>
          <div class="role-badge">Бригадир</div>
        </div>
        <div style="font-size:28px">→</div>
      </div>
    `;
  });
  html += `</div>`;
  return html;
}

function loginAsBrigadier(id) {
  const brig = brigadiers.find(b => b.id === id);
  if (!brig) return;
  currentUser = { role: 'brigadier', id: brig.id, name: brig.name };
  currentScreen = 'brigadier-main';
  render();
}

function renderAdminMain() {
  return `
    ${renderHeader('Панель администратора')}
    <div class="screen-content">
      <div style="display:flex;gap:12px;margin-bottom:24px">
        <div onclick="setAdminScreen('tasks')" style="flex:1;background:white;padding:18px 12px;text-align:center;border-radius:12px;box-shadow:var(--shadow-sm);font-weight:600;cursor:pointer">Задания</div>
        <div onclick="setAdminScreen('brigadiers')" style="flex:1;background:white;padding:18px 12px;text-align:center;border-radius:12px;box-shadow:var(--shadow-sm);font-weight:600;cursor:pointer">Бригадиры</div>
        <div onclick="setAdminScreen('workers')" style="flex:1;background:white;padding:18px 12px;text-align:center;border-radius:12px;box-shadow:var(--shadow-sm);font-weight:600;cursor:pointer">Сотрудники</div>
      </div>
      <div onclick="setAdminScreen('archive')" class="btn btn-secondary" style="margin-bottom:20px">Архив выездов</div>
      <div onclick="showSettings()" class="btn btn-secondary">Настройки</div>
    </div>
  `;
}

function setAdminScreen(screen) {
  if (screen === 'tasks') currentScreen = 'admin-tasks';
  else if (screen === 'brigadiers') currentScreen = 'admin-brigadiers';
  else if (screen === 'workers') currentScreen = 'admin-workers';
  else if (screen === 'archive') currentScreen = 'admin-archive';
  render();
}

function renderAdminTasks() {
  let html = renderHeader('Задания', true);
  html += `<div class="screen-content">
    <div onclick="showNewTaskModal()" class="btn btn-primary" style="margin-bottom:20px">+ Новое задание</div>
  `;
  if (tasks.length === 0) {
    html += `<div class="empty-state"><div>Нет заданий</div></div>`;
  } else {
    tasks.forEach(task => {
      const prio = task.priority === 'high' ? '🔴' : '🟠';
      html += `
        <div class="card" onclick="viewTask(${task.id})">
          <div style="display:flex;justify-content:space-between;align-items:start">
            <div>
              <div style="font-size:15px;font-weight:700">${task.address}</div>
              <div style="font-size:13px;color:var(--color-text-secondary);margin-top:4px">${task.description}</div>
            </div>
            <div style="text-align:right">
              <div class="status status-${task.status}">${task.status === 'new' ? 'Новое' : task.status === 'inwork' ? 'В работе' : task.status === 'done' ? 'Выполнено' : 'Отменено'}</div>
            </div>
          </div>
          <div style="margin-top:12px;font-size:13px;display:flex;gap:12px;align-items:center">
            <span>${prio}</span>
            <span style="color:#666">${task.departureTime}</span>
            ${task.acceptedBy ? `<span class="role-badge">Принято</span>` : ''}
          </div>
        </div>
      `;
    });
  }
  html += `</div>`;
  return html;
}

function showNewTaskModal() {
  const modalHTML = `
    <div class="modal show" id="new-task-modal">
      <div class="modal-content">
        <div class="modal-header">
          <div>Новое задание</div>
          <div onclick="hideModal('new-task-modal')" style="font-size:28px;line-height:1;cursor:pointer">×</div>
        </div>
        <div style="padding:20px;overflow-y:auto;flex:1">
          <div class="input-group">
            <label>Адрес</label>
            <input id="new-address" value="ул. Центральная, 56, кв. 9">
          </div>
          <div class="input-group">
            <label>Описание</label>
            <textarea id="new-desc" rows="3">Провести диагностику газового котла</textarea>
          </div>
          <div class="input-group">
            <label>Приоритет</label>
            <select id="new-priority">
              <option value="high">Высокий</option>
              <option value="medium" selected>Средний</option>
            </select>
          </div>
          <div class="input-group">
            <label>Время выезда</label>
            <input type="text" id="new-time" value="2025-04-06 10:30">
          </div>
          <div class="input-group">
            <label>Назначить бригадиру</label>
            <select id="new-assignee">
              <option value="">Всем</option>
              ${brigadiers.filter(b=>b.active).map(b => `<option value="${b.id}">${b.name}</option>`).join('')}
            </select>
          </div>
        </div>
        <div style="padding:16px;border-top:1px solid #ddd">
          <button onclick="createNewTask()" class="btn btn-primary">Создать задание</button>
        </div>
      </div>
    </div>
  `;
  const app = document.getElementById('app');
  app.insertAdjacentHTML('beforeend', modalHTML);
}

function hideModal(id) {
  const modal = document.getElementById(id);
  if (modal) modal.remove();
}

function createNewTask() {
  const address = document.getElementById('new-address').value || 'Новый адрес';
  const desc = document.getElementById('new-desc').value || 'Нет описания';
  const prio = document.getElementById('new-priority').value;
  const time = document.getElementById('new-time').value;
  const assignee = document.getElementById('new-assignee').value ? parseInt(document.getElementById('new-assignee').value) : null;

  const newTask = {
    id: nextTaskId++,
    status: 'new',
    address: address,
    description: desc,
    priority: prio,
    departureTime: time,
    assignedTo: assignee,
    acceptedBy: null
  };
  tasks.unshift(newTask);
  saveData();
  hideModal('new-task-modal');
  showToast('Задание создано');
  render();
}

function viewTask(id) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;
  currentScreen = 'task-detail';
  window.viewingTaskId = id;
  render();
}

function renderTaskDetail() {
  const task = tasks.find(t => t.id === window.viewingTaskId);
  if (!task) return '<div>Задание не найдено</div>';

  let html = renderHeader('Детали задания', true);
  html += `<div class="screen-content">
    <div class="card">
      <div style="font-size:17px;font-weight:700;margin-bottom:6px">${task.address}</div>
      <div style="color:var(--color-text-secondary)">${task.description}</div>
      <div style="margin-top:16px;display:flex;align-items:center;justify-content:space-between">
        <div><span class="status status-${task.status}">${task.status === 'new' ? 'Новое' : task.status === 'inwork' ? 'В работе' : task.status === 'done' ? 'Выполнено' : 'Отменено'}</span></div>
        <div style="text-align:right;font-size:13px">${task.departureTime}</div>
      </div>
    </div>
  `;

  if (currentUser.role === 'admin') {
    html += `
      <div style="margin:24px 0 12px;font-size:13px;color:var(--color-text-muted);font-weight:600">УПРАВЛЕНИЕ</div>
      <button onclick="editTask()" class="btn btn-secondary" style="margin-bottom:12px">Редактировать</button>
      ${task.status === 'new' ? `<button onclick="cancelTask()" class="btn btn-danger">Отменить задание</button>` : ''}
    `;
  } else if (currentUser.role === 'brigadier' && task.status === 'new' && (!task.assignedTo || task.assignedTo === currentUser.id)) {
    html += `<button onclick="acceptTask(${task.id})" class="btn btn-primary" style="margin-top:20px">Принять задание</button>`;
  }

  if (task.report) {
    html += `
      <div class="card" style="margin-top:24px">
        <div style="font-weight:600;margin-bottom:8px">Отчёт</div>
        <div style="font-size:15px;line-height:1.5">${task.report}</div>
      </div>
    `;
  }
  if (task.photos && task.photos.length) {
    html += `<div style="margin-top:20px"><div style="font-size:13px;margin-bottom:8px;color:#555">Фото</div><div class="photo-grid">`;
    task.photos.forEach(p => {
      html += `<div onclick="viewPhoto('${p}')" class="photo-preview" style="background-image:url('${p}')"></div>`;
    });
    html += `</div></div>`;
  }
  html += `</div>`;
  return html;
}

function acceptTask(id) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;
  task.status = 'inwork';
  task.acceptedBy = currentUser.id;
  task.startTime = '2025-04-05 09:15';
  task.car = 'А555МР 150';
  task.brigade = [currentUser.id, 1];
  saveData();
  showToast('Задание принято в работу');
  currentScreen = 'brigadier-main';
  render();
}

function cancelTask() {
  if (!confirm('Отменить задание?')) return;
  const task = tasks.find(t => t.id === window.viewingTaskId);
  if (task) task.status = 'cancel';
  saveData();
  showToast('Задание отменено');
  currentScreen = 'admin-tasks';
  render();
}

function editTask() {
  showToast('Редактирование задания (демо)');
}

function renderBrigadierMain() {
  const myTasks = tasks.filter(t => (t.acceptedBy === currentUser.id) || (!t.acceptedBy && t.status === 'new'));
  let html = renderHeader('Мои задания');
  html += `<div class="screen-content">
    <div style="background:#fff;border-radius:12px;padding:4px;margin-bottom:20px;display:flex">
      <div onclick="filterBrigadierTasks(0)" class="tab-btn active" id="tab-all" style="flex:1;padding:10px;text-align:center;border-radius:10px">Все</div>
      <div onclick="filterBrigadierTasks(1)" class="tab-btn" id="tab-mine" style="flex:1;padding:10px;text-align:center;border-radius:10px">Мои</div>
    </div>
  `;

  if (myTasks.length === 0) {
    html += `<div class="empty-state"><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="#999"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2" /></svg><div>Нет активных заданий</div></div>`;
  } else {
    myTasks.forEach(task => {
      html += `
        <div onclick="openBrigadierTask(${task.id})" class="card">
          <div style="display:flex;justify-content:space-between">
            <div style="max-width:70%">
              <div style="font-weight:700">${task.address}</div>
              <div style="font-size:13px;color:#555;margin-top:4px">${task.description.substring(0,45)}...</div>
            </div>
            <div>
              <span class="status status-${task.status}">${task.status === 'new' ? 'Новое' : 'В работе'}</span>
            </div>
          </div>
          <div style="margin-top:14px;font-size:12px;color:#888">Выезд: ${task.departureTime}</div>
        </div>
      `;
    });
  }
  html += `<div onclick="showBrigadierArchive()" style="margin-top:30px;color:var(--color-primary);text-align:center;font-size:15px">Открыть архив →</div>`;
  html += `</div>`;
  return html;
}

function filterBrigadierTasks(mode) {
  showToast(mode === 0 ? 'Показаны все' : 'Только мои');
}

function openBrigadierTask(id) {
  const task = tasks.find(t => t.id === id);
  if (!task) return;
  window.viewingTaskId = id;
  if (task.status === 'inwork' && task.acceptedBy === currentUser.id) {
    currentScreen = 'brigadier-complete';
  } else {
    currentScreen = 'task-detail';
  }
  render();
}

function renderBrigadierComplete() {
  const task = tasks.find(t => t.id === window.viewingTaskId);
  if (!task) return '';
  let html = renderHeader('Завершение задания', true);
  html += `<div class="screen-content">
    <div class="card">
      <div style="font-size:15px;font-weight:600">${task.address}</div>
    </div>
    <div class="input-group">
      <label>Автомобиль</label>
      <input id="complete-car" value="А555МР 150" />
    </div>
    <div class="input-group">
      <label>Состав бригады</label>
      <div style="display:flex;flex-wrap:wrap;gap:6px">
        ${workers.map(w => `<div onclick="this.classList.toggle('selected-worker')" style="padding:6px 14px;background:#f0f0f0;border-radius:9999px;font-size:13px">${w.name.split(' ')[0]}</div>`).join('')}
      </div>
    </div>
    <div class="input-group">
      <label>Отчёт <span style="color:#c00">*</span></label>
      <textarea id="complete-report" rows="5">Газовый котёл проверен. Заменён фильтр. Утечек не обнаружено.</textarea>
    </div>
    <div style="margin:24px 0 8px;font-size:14px;color:#333">Фото с места</div>
    <div onclick="addPhoto()" style="border:2px dashed #aaa;height:120px;border-radius:12px;display:flex;align-items:center;justify-content:center;color:#888;flex-direction:column;cursor:pointer">
      📸<br><span style="font-size:13px">Добавить фото</span>
    </div>
    <div id="photos-preview" class="photo-grid" style="margin-top:16px"></div>
    <button onclick="finishTask()" class="btn btn-primary" style="margin-top:30px">Завершить и отправить отчёт</button>
  </div>`;
  return html;
}

function addPhoto() {
  // demo photo
  photos.push('https://picsum.photos/id/201/600/800');
  const container = document.getElementById('photos-preview');
  if (container) {
    container.innerHTML += `<div class="photo-preview" style="background-image:url('https://picsum.photos/id/201/600/800')"></div>`;
  }
  showToast('Фото добавлено (демо)');
}

function finishTask() {
  const task = tasks.find(t => t.id === window.viewingTaskId);
  if (!task) return;
  const report = document.getElementById('complete-report') ? document.getElementById('complete-report').value : 'Отчёт принят';
  task.status = 'done';
  task.report = report;
  task.endTime = '2025-04-05 11:40';
  task.photos = photos.length ? [...photos] : ['https://picsum.photos/id/201/600/800'];
  archive.unshift({
    id: task.id,
    address: task.address,
    description: task.description,
    report: task.report,
    photos: task.photos,
    brigadeNames: 'Иванов С.П., Петров Д.А.',
    car: document.getElementById('complete-car') ? document.getElementById('complete-car').value : 'А555МР 150',
    startTime: task.startTime || '2025-04-05 09:15',
    endTime: task.endTime,
    duration: '2ч 25м',
    brigadier: currentUser.name
  });
  tasks = tasks.filter(t => t.id !== task.id);
  saveData();
  photos = [];
  showToast('Задание выполнено и отправлено в архив');
  currentScreen = 'brigadier-main';
  render();
}

function showBrigadierArchive() {
  currentScreen = 'brigadier-archive';
  render();
}

function renderBrigadierArchive() {
  let html = renderHeader('Архив', true);
  html += `<div class="screen-content">`;
  archive.forEach(item => {
    html += `
      <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:flex-start">
          <div style="font-weight:600;font-size:15px">${item.address}</div>
          <div style="font-size:12px;background:#e0f2e9;color:#006d3f;padding:2px 9px;border-radius:12px">Выполнено</div>
        </div>
        <div style="margin-top:10px;font-size:13px;line-height:1.4;color:#444">${item.report}</div>
        <div style="margin-top:16px;font-size:12px;color:#777">Бригадир: ${item.brigadier}<br>Авто: ${item.car}<br>Длительность: ${item.duration}</div>
        ${item.photos && item.photos.length ? `<div style="margin-top:12px;height:68px;background:url('${item.photos[0]}');background-size:cover;border-radius:8px"></div>` : ''}
      </div>
    `;
  });
  html += `</div>`;
  return html;
}

function renderAdminBrigadiers() {
  let html = renderHeader('Бригадиры', true);
  html += `<div class="screen-content">
    <div onclick="addBrigadier()" class="btn btn-primary" style="margin-bottom:18px">Добавить бригадира</div>
  `;
  brigadiers.forEach((brig, index) => {
    html += `
      <div class="list-item">
        <div>
          <div style="font-weight:500">${brig.name}</div>
          <div class="role-badge">${brig.active ? 'Активен' : 'Отключён'}</div>
        </div>
        <label class="switch" style="position:relative">
          <input type="checkbox" ${brig.active ? 'checked' : ''} onchange="toggleBrigadier(${index})">
          <span style="position:absolute;right:0;top:4px;width:42px;height:22px;background:#ccc;border-radius:20px;transition:.3s"></span>
        </label>
      </div>
    `;
  });
  html += `</div>`;
  return html;
}

function toggleBrigadier(i) {
  brigadiers[i].active = !brigadiers[i].active;
  saveData();
  render();
}

function addBrigadier() {
  const name = prompt('ФИО нового бригадира:','Новый Бригадир');
  if (name) {
    brigadiers.push({ id: Date.now(), name, active: true });
    saveData();
    render();
  }
}

function renderAdminWorkers() {
  let html = renderHeader('Работники', true);
  html += `<div class="screen-content">
    <div onclick="addWorker()" class="btn btn-primary" style="margin-bottom:18px">Добавить работника</div>
  `;
  workers.forEach(w => {
    html += `<div class="list-item"><div>${w.name}</div></div>`;
  });
  html += `</div>`;
  return html;
}

function addWorker() {
  const name = prompt('ФИО нового работника:','Новый сотрудник');
  if (name) {
    workers.push({ id: Date.now(), name });
    saveData();
    render();
  }
}

function renderAdminArchive() {
  let html = renderHeader('Архив выездов', true);
  html += `<div class="screen-content">
    <input type="text" placeholder="Поиск по адресу или бригадиру" onkeyup="if(event.key==='Enter')filterArchive(this.value)" style="margin-bottom:16px">
  `;
  archive.forEach(item => {
    html += `
      <div class="card">
        <div style="font-weight:600">${item.address}</div>
        <div style="font-size:13px;color:var(--color-text-secondary)">${item.brigadier} • ${item.duration}</div>
        <div style="margin-top:12px;font-size:13px">${item.report.substring(0, 65)}...</div>
      </div>
    `;
  });
  html += `</div>`;
  return html;
}

function filterArchive(query) {
  showToast('Поиск: ' + query);
}

function showSettings() {
  const modalHTML = `
    <div class="modal show" id="settings-modal">
      <div class="modal-content">
        <div class="modal-header">
          <div>Настройки</div>
          <div onclick="hideModal('settings-modal')" style="font-size:28px;cursor:pointer">×</div>
        </div>
        <div style="padding:20px">
          <div class="input-group">
            <label>Текущий пароль администратора</label>
            <input type="text" id="new-admin-pass" value="${adminPassword}" maxlength="4">
          </div>
          <button onclick="changeAdminPassword()" class="btn btn-primary">Сменить пароль</button>
          <div style="margin-top:40px;font-size:13px;color:#888;text-align:center">Московское время: ${new Date().toLocaleString('ru-RU',{timeZone:'Europe/Moscow'})}</div>
        </div>
      </div>
    </div>
  `;
  document.getElementById('app').insertAdjacentHTML('beforeend', modalHTML);
}

function changeAdminPassword() {
  const newPass = document.getElementById('new-admin-pass').value.trim();
  if (newPass.length > 3) {
    adminPassword = newPass;
    saveData();
    hideModal('settings-modal');
    showToast('Пароль обновлён');
  }
}

function navigate(action) {
  if (action === 'back') {
    if (currentScreen === 'task-detail' || currentScreen === 'brigadier-complete') {
      currentScreen = currentRole === 'admin' ? 'admin-tasks' : 'brigadier-main';
    } else if (currentScreen.includes('admin-')) {
      currentScreen = 'admin-main';
    } else if (currentScreen === 'brigadier-archive') {
      currentScreen = 'brigadier-main';
    }
    render();
  }
}

function render() {
  const app = document.getElementById('app');
  let html = '';

  if (currentScreen === 'login') {
    html = renderLogin();
  } else if (currentScreen === 'admin-login') {
    html = renderAdminLogin();
  } else if (currentScreen === 'brigadier-select') {
    html = renderBrigadierSelect();
  } else if (currentScreen === 'admin-main') {
    html = renderAdminMain();
  } else if (currentScreen === 'admin-tasks') {
    html = renderAdminTasks();
  } else if (currentScreen === 'task-detail') {
    html = renderTaskDetail();
  } else if (currentScreen === 'brigadier-main') {
    html = renderBrigadierMain();
  } else if (currentScreen === 'brigadier-complete') {
    html = renderBrigadierComplete();
  } else if (currentScreen === 'brigadier-archive') {
    html = renderBrigadierArchive();
  } else if (currentScreen === 'admin-brigadiers') {
    html = renderAdminBrigadiers();
  } else if (currentScreen === 'admin-workers') {
    html = renderAdminWorkers();
  } else if (currentScreen === 'admin-archive') {
    html = renderAdminArchive();
  }

  app.innerHTML = html;

  // add bottom tab bar for brigadier
  if (currentUser && currentUser.role === 'brigadier' && (currentScreen === 'brigadier-main' || currentScreen === 'brigadier-archive')) {
    const tabHTML = `
      <div class="tab-bar">
        <div onclick="currentScreen='brigadier-main';render()" class="tab ${currentScreen==='brigadier-main'?'active':''}">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1v-5m10-10l2 2m-2-2v10a1 1 0 01-1 1v-5m-6 0a1 1 0 001-1v5" /></svg>
          Задания
        </div>
        <div onclick="currentScreen='brigadier-archive';render()" class="tab ${currentScreen==='brigadier-archive'?'active':''}">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2" /></svg>
          Архив
        </div>
      </div>
    `;
    app.insertAdjacentHTML('beforeend', tabHTML);
  }
}

// Boot the app
window.onload = function() {
  loadData();
  render();
};

// Global helpers for inline onclicks
window.switchRole = switchRole;
window.adminLogin = adminLogin;
window.loginAsBrigadier = loginAsBrigadier;
window.setAdminScreen = setAdminScreen;
window.showNewTaskModal = showNewTaskModal;
window.hideModal = hideModal;
window.createNewTask = createNewTask;
window.viewTask = viewTask;
window.acceptTask = acceptTask;
window.cancelTask = cancelTask;
window.editTask = editTask;
window.navigate = navigate;
window.showSettings = showSettings;
window.changeAdminPassword = changeAdminPassword;
window.addPhoto = addPhoto;
window.finishTask = finishTask;
window.showBrigadierArchive = showBrigadierArchive;
window.filterBrigadierTasks = filterBrigadierTasks;
window.openBrigadierTask = openBrigadierTask;
window.addBrigadier = addBrigadier;
window.toggleBrigadier = toggleBrigadier;
window.addWorker = addWorker;
window.filterArchive = filterArchive;
window.viewPhoto = function(url) { showToast('Открытие фото...'); };