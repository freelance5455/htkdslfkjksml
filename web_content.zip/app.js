const $ = id => document.getElementById(id);
const daysEl = $("days");
const monthEl = $("month");
const pad = n => String(n).padStart(2,"0");

function mins(s){
  const m = /^(\d{1,2}):(\d{2})$/.exec((s||"").trim());
  if(!m) return null;
  const h=+m[1], mm=+m[2];
  if(h>23||mm>59) return null;
  return h*60+mm;
}
function hm(v){
  v=((v%1440)+1440)%1440;
  return pad(Math.floor(v/60))+":"+pad(v%60);
}
function rebuild(){
  daysEl.innerHTML="";
  const val=monthEl.value;
  if(!val) return;
  const [y,mo]=val.split("-").map(Number);
  const count=new Date(y,mo,0).getDate();
  const wd=["So","Mo","Di","Mi","Do","Fr","Sa"];
  for(let d=1;d<=count;d++){
    const date=new Date(y,mo-1,d);
    const w=date.getDay();
    const work=w!==0 && w!==6;
    const el=document.createElement("div");
    el.className="day"+(work?"":" off");
    el.dataset.day=d;
    el.innerHTML=`
      <div class="dayhead"><span>${pad(d)}.${pad(mo)}.${y} — ${wd[w]}</span><span>${work?"Arbeitstag":"Wochenende"}</span></div>
      ${work?`<div class="daygrid">
        <label>Start<input class="start" placeholder="08:00" inputmode="numeric"></label>
        <label>Netto Fahrzeit<input class="drive" placeholder="07:30" inputmode="numeric"></label>
      </div>
      <div class="calc">Netto Arb.Zeit: <b class="work">—</b> · Pause: <b>1:00</b> · Ende: <b class="end">—</b> · Spesen: <b>${(w===1||w===5)?14:28}</b> · Zeit: <b>24</b></div>`
      :`<div class="calc">Keine Arbeitsdaten — Wochenende</div>`}`;
    daysEl.appendChild(el);
    if(work){
      const s=el.querySelector(".start"), dr=el.querySelector(".drive");
      const update=()=>{
        const sm=mins(s.value), dm=mins(dr.value);
        el.querySelector(".work").textContent=dm==null?"—":hm(dm+60);
        el.querySelector(".end").textContent=(sm==null||dm==null)?"—":hm(sm+dm+120);
      };
      s.addEventListener("input",update); dr.addEventListener("input",update);
    }
  }
}
monthEl.addEventListener("change",rebuild);
const now=new Date(); monthEl.value=`${now.getFullYear()}-${pad(now.getMonth()+1)}`; rebuild();

function escPdf(s){
  return String(s??"").replace(/\\/g,"\\\\").replace(/\(/g,"\\(").replace(/\)/g,"\\)");
}

/* Creates a simple PDF containing the rendered 1800x2400 form as one JPEG page.
   This keeps the original template visually intact while allowing Unicode text
   to be drawn by the browser before embedding it in the PDF. */
function makePdf(jpegBytes,width,height){
  const objects=[];
  const add=o=>{objects.push(o);return objects.length};
  const imgObj=add(null);
  const contentObj=add(null);
  const fontObj=add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  const pageObj=add(null);
  const pagesObj=add(null);
  const catalogObj=add(null);

  const content=`q\n${width} 0 0 ${height} 0 0 cm\n/Im0 Do\nQ\n`;
  objects[contentObj-1]=`<< /Length ${content.length} >>\nstream\n${content}endstream`;
  objects[imgObj-1]=`<< /Type /XObject /Subtype /Image /Width ${width} /Height ${height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.length} >>\nstream\n${bytesToBinary(jpegBytes)}\nendstream`;
  objects[pagesObj-1]=`<< /Type /Pages /Kids [${pageObj} 0 R] /Count 1 >>`;
  objects[pageObj-1]=`<< /Type /Page /Parent ${pagesObj} 0 R /MediaBox [0 0 ${width} ${height}] /Resources << /XObject << /Im0 ${imgObj} 0 R >> /Font << /F1 ${fontObj} 0 R >> >> /Contents ${contentObj} 0 R >>`;
  objects[catalogObj-1]=`<< /Type /Catalog /Pages ${pagesObj} 0 R >>`;

  let pdf="%PDF-1.4\n%\xFF\xFF\xFF\xFF\n";
  const offsets=[0];
  for(let i=0;i<objects.length;i++){
    offsets.push(pdf.length);
    pdf+=`${i+1} 0 obj\n${objects[i]}\nendobj\n`;
  }
  const xref=pdf.length;
  pdf+=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;
  for(let i=1;i<offsets.length;i++) pdf+=String(offsets[i]).padStart(10,"0")+" 00000 n \n";
  pdf+=`trailer\n<< /Size ${objects.length+1} /Root ${catalogObj} 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new TextEncoder().encode(pdf);
}
function bytesToBinary(bytes){
  let s="";
  const chunk=0x8000;
  for(let i=0;i<bytes.length;i+=chunk) s+=String.fromCharCode(...bytes.subarray(i,i+chunk));
  return s;
}
function dataUrlToBytes(dataUrl){
  const b64=dataUrl.split(",")[1];
  const bin=atob(b64); const out=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i);
  return out;
}

$("makePdf").addEventListener("click", async ()=>{
  const status=$("status");
  status.textContent="Готовлю PDF…";
  try{
    const img=new Image();
    img.src="spesen_template.jpg";
    await new Promise((res,rej)=>{img.onload=res;img.onerror=rej});
    const canvas=document.createElement("canvas");
    canvas.width=1800; canvas.height=2400;
    const c=canvas.getContext("2d");
    c.drawImage(img,0,0,1800,2400);
    c.fillStyle="#222"; c.font="30px Arial";
    c.fillText($("name").value||"",95,166);
    c.fillText($("number").value||"",850,166);
    c.fillText($("dateNote").value||$("month").value||"",1505,166);

    const rows=[...document.querySelectorAll(".day")];
    const y0=550, rh=66;
    rows.forEach((row)=>{
      const day=+row.dataset.day;
      if(row.classList.contains("off")) return;
      const start=row.querySelector(".start")?.value.trim()||"";
      const drive=row.querySelector(".drive")?.value.trim()||"";
      const sm=mins(start), dm=mins(drive);
      if(sm==null || dm==null) return;
      const y=y0+(day-1)*rh+45;
      c.font="27px Arial";
      c.fillText(pad(day),105,y);
      c.fillText(hm(sm),225,y);
      c.fillText(hm(sm+dm+120),330,y);
      c.fillText("24",440,y);
      c.fillText((new Date($("month").value+"-"+pad(day)).getDay()===1 || new Date($("month").value+"-"+pad(day)).getDay()===5)?"14":"28",545,y);
      c.fillText(start,1295,y);
      c.fillText("1",1410,y);
      c.fillText(hm(sm+dm+120),1508,y);
      c.fillText(hm(dm+60),1645,y);
      c.fillText(drive,1760,y);
    });

    const jpeg=canvas.toDataURL("image/jpeg",0.94);
    const pdf=makePdf(dataUrlToBytes(jpeg),1800,2400);
    const blob=new Blob([pdf],{type:"application/pdf"});
    const a=document.createElement("a");
    a.href=URL.createObjectURL(blob);
    a.download="Spesen_Arbeitszeiten.pdf";
    a.click();
    setTimeout(()=>URL.revokeObjectURL(a.href),5000);
    status.textContent="PDF создан. Если сервис-обёртка не показывает загрузку, используйте кнопку «Создать PDF» внутри приложения.";
  }catch(e){
    console.error(e); status.textContent="Ошибка: "+e.message;
  }
});
