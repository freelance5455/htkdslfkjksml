const codeInput=document.getElementById("code");
const unlock=document.getElementById("unlock");
const msg=document.getElementById("msg");
const panel=document.getElementById("panel");
const panelTitle=document.getElementById("panelTitle");

unlock.onclick=()=>{
  const code=codeInput.value.trim();
  if(!code){msg.textContent="اكتب الكود أولاً.";return;}
  msg.textContent="تم قبول الكود التجريبي.";
  document.querySelectorAll(".feature").forEach(x=>x.style.opacity="1");
};

document.querySelectorAll(".feature").forEach(btn=>{
  btn.onclick=()=>{
    panelTitle.textContent=btn.dataset.name;
    panel.classList.remove("hidden");
    panel.scrollIntoView({behavior:"smooth",block:"center"});
  };
});