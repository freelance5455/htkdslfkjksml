const $ = (id) => document.getElementById(id);

const state = {
  messages: JSON.parse(localStorage.getItem("sanskar_messages") || "[]"),
  interactionId: localStorage.getItem("sanskar_interaction_id") || "",
  apiKey: localStorage.getItem("sanskar_api_key") || "",
  model: localStorage.getItem("sanskar_model") || SSANSKAR_CONFIG.defaultModel,
  aiName: localStorage.getItem("sanskar_ai_name") || "S Sanskar AI",
  userName: localStorage.getItem("sanskar_user_name") || "Aryan",
  personality: localStorage.getItem("sanskar_personality") ||
    "Be intelligent, calm, practical and concise. Act as my private personal assistant. Never claim an action happened unless it actually happened."
};

const chat = $("chat");
const welcome = $("welcome");
const input = $("input");
const settings = $("settings");
const overlay = $("overlay");
const statusBox = $("status");

function saveState(){
  localStorage.setItem("sanskar_messages", JSON.stringify(state.messages.slice(-100)));
  localStorage.setItem("sanskar_interaction_id", state.interactionId);
}

function escapeHtml(s){
  return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function render(){
  welcome.classList.toggle("hidden", state.messages.length > 0);
  chat.innerHTML = state.messages.map(m => `
    <div class="message ${m.role === "user" ? "user" : "ai"}">
      <div>
        <div class="bubble">${escapeHtml(m.text)}</div>
        <div class="meta">${m.role === "user" ? "You" : state.aiName}</div>
      </div>
    </div>
  `).join("");
  chat.scrollTop = chat.scrollHeight;
}

function setStatus(text){
  statusBox.textContent = text;
  statusBox.classList.toggle("hidden", !text);
}

function addMessage(role,text){
  state.messages.push({role,text,time:Date.now()});
  saveState();
  render();
}

function systemInstruction(){
  return `${state.personality}
You are ${state.aiName}, a private AI assistant for ${state.userName}.
Brand: ${state.aiName} — Created by Aryan Renacia.
You are running inside a smartphone web-app wrapper.
You can answer, reason, write code, analyze user-provided images when supported, and propose actions.
Never claim that you opened an app, changed a phone setting, sent a message, or completed an external action unless the app actually executed it.
If asked to perform a phone action that this web app cannot execute, explain that Android wrapper/native permissions are required.
Keep responses useful and reasonably concise.`;
}

async function geminiInteraction(text){
  if(!state.apiKey.trim()) throw new Error("Gemini API key missing. Open Settings and add your key.");

  const body = {
    model: state.model,
    input: text,
    system_instruction: systemInstruction(),
    store: true
  };

  if(state.interactionId) body.previous_interaction_id = state.interactionId;

  const res = await fetch("https://generativelanguage.googleapis.com/v1beta/interactions",{
    method:"POST",
    headers:{
      "Content-Type":"application/json",
      "x-goog-api-key":state.apiKey.trim()
    },
    body:JSON.stringify(body)
  });

  const data = await res.json();
  if(!res.ok) throw new Error(data?.error?.message || `Gemini error ${res.status}`);

  state.interactionId = data.id || state.interactionId;
  saveState();

  if(data.output_text) return data.output_text;

  const steps = data.steps || [];
  const output = [...steps].reverse().find(s => s.type === "model_output");
  return output?.content?.map(x => x.text || "").join("") || "I received an empty response.";
}

async function analyzeImage(file){
  if(!state.apiKey.trim()) throw new Error("Add your Gemini API key in Settings first.");
  const dataUrl = await new Promise((resolve,reject)=>{
    const r = new FileReader();
    r.onload=()=>resolve(r.result);
    r.onerror=reject;
    r.readAsDataURL(file);
  });
  const [head,b64] = dataUrl.split(",");
  const mime = (head.match(/data:(.*?);base64/)||[])[1] || "image/jpeg";

  const body = {
    contents:[{
      role:"user",
      parts:[
        {text:"Analyze this image carefully. Describe what is visible and answer as my personal AI assistant. Do not invent details."},
        {inline_data:{mime_type:mime,data:b64}}
      ]
    }],
    systemInstruction:{parts:[{text:systemInstruction()}]}
  };

  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(state.model)}:generateContent`,{
    method:"POST",
    headers:{"Content-Type":"application/json","x-goog-api-key":state.apiKey.trim()},
    body:JSON.stringify(body)
  });
  const data = await res.json();
  if(!res.ok) throw new Error(data?.error?.message || `Vision error ${res.status}`);
  return data?.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("") || "I couldn't read the image.";
}

async function send(){
  const text = input.value.trim();
  if(!text) return;
  input.value="";
  input.style.height="auto";
  addMessage("user",text);
  setStatus("S Sanskar AI is thinking…");
  $("sendBtn").disabled = true;

  try{
    const answer = await geminiInteraction(text);
    addMessage("model",answer);
    speak(answer);
    maybeOfferAndroidAction(text,answer);
  }catch(e){
    addMessage("model",`I couldn't complete that request.\n\n${e.message}`);
  }finally{
    $("sendBtn").disabled=false;
    setStatus("");
  }
}

function speak(text){
  if(!("speechSynthesis" in window)) return;
  const clean=text.replace(/```[\s\S]*?```/g," code omitted ");
  const u=new SpeechSynthesisUtterance(clean.slice(0,1200));
  u.rate=.98;
  u.pitch=1;
  speechSynthesis.cancel();
  speechSynthesis.speak(u);
}

function startVoice(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){ setStatus("Voice recognition is not supported by this WebView."); return; }
  const r=new SR();
  r.lang="en-IN";
  r.interimResults=false;
  $("micBtn").classList.add("listening");
  setStatus("Listening…");
  r.onresult=e=>{
    input.value=e.results[0][0].transcript;
    input.dispatchEvent(new Event("input"));
  };
  r.onerror=()=>setStatus("Voice input failed.");
  r.onend=()=>{
    $("micBtn").classList.remove("listening");
    setTimeout(()=>setStatus(""),800);
    if(input.value.trim()) send();
  };
  r.start();
}

function maybeOfferAndroidAction(userText, answer){
  const t=userText.toLowerCase();
  let label="", href="";
  if(/\bopen youtube\b/.test(t)){label="Open YouTube";href="https://www.youtube.com/";}
  else if(/\bopen chrome\b/.test(t)){label="Open browser";href="https://www.google.com/";}
  else if(/\bopen whatsapp\b/.test(t)){label="Open WhatsApp";href="https://wa.me/";}
  if(!label)return;

  const div=document.createElement("div");
  div.className="action-card";
  div.innerHTML=`<div>${escapeHtml(label)} was requested.</div><button>${escapeHtml(label)}</button>`;
  div.querySelector("button").onclick=()=>window.location.href=href;
  chat.appendChild(div);
  chat.scrollTop=chat.scrollHeight;
}

function openSettings(){
  $("apiKey").value=state.apiKey;
  $("model").value=state.model;
  $("aiName").value=state.aiName;
  $("userName").value=state.userName;
  $("personality").value=state.personality;
  settings.classList.add("open");overlay.classList.add("open");
}
function closeSettings(){
  settings.classList.remove("open");overlay.classList.remove("open");
}

$("sendBtn").onclick=send;
$("micBtn").onclick=startVoice;
$("settingsBtn").onclick=openSettings;
$("closeSettings").onclick=closeSettings;
overlay.onclick=closeSettings;

input.addEventListener("input",()=>{
  input.style.height="auto";
  input.style.height=Math.min(input.scrollHeight,120)+"px";
});
input.addEventListener("keydown",e=>{
  if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}
});

document.querySelectorAll(".quick-grid button[data-prompt]").forEach(b=>{
  b.onclick=()=>{input.value=b.dataset.prompt;send();}
});

$("visionBtn").onclick=()=>$("imageInput").click();
$("attachBtn").onclick=()=>$("imageInput").click();
$("imageInput").onchange=async e=>{
  const file=e.target.files?.[0];
  if(!file)return;
  addMessage("user",`[Image] ${file.name}`);
  setStatus("Analyzing image…");
  try{
    const answer=await analyzeImage(file);
    addMessage("model",answer);
    speak(answer);
  }catch(err){addMessage("model",`Image analysis failed.\n\n${err.message}`);}
  finally{setStatus("");e.target.value="";}
};

$("saveSettings").onclick=()=>{
  state.apiKey=$("apiKey").value.trim();
  state.model=$("model").value;
  state.aiName=$("aiName").value.trim()||"S Sanskar AI";
  state.userName=$("userName").value.trim()||"Aryan";
  state.personality=$("personality").value.trim();
  localStorage.setItem("sanskar_api_key",state.apiKey);
  localStorage.setItem("sanskar_model",state.model);
  localStorage.setItem("sanskar_ai_name",state.aiName);
  localStorage.setItem("sanskar_user_name",state.userName);
  localStorage.setItem("sanskar_personality",state.personality);
  closeSettings();render();setStatus("Settings saved");setTimeout(()=>setStatus(""),1200);
};

$("clearMemory").onclick=()=>{
  if(confirm("Clear local conversation memory and reset Gemini conversation state?")){
    state.messages=[];state.interactionId="";saveState();render();closeSettings();
  }
};

$("openAccessibility").onclick=()=>{
  // Some APK wrappers expose this through a native bridge.
  if(window.AndroidBridge?.openAccessibilitySettings){
    window.AndroidBridge.openAccessibilitySettings();
  }else{
    alert("This HTML build cannot directly open Android Accessibility settings unless your ZIP-to-APK wrapper exposes a native bridge.");
  }
};

render();
