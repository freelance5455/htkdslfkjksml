/**
 * ATC Aviation Weather — Web Application Engine (ES6 Vanilla)
 * Real OPMET Data Integration, Aviation Parsers, and Controller Dashboard
 */

// Airport Database (Iranian and Global)
const AIRPORTS = [
  // --- IRAN (Priority) ---
  { icao: "OIIE", iata: "IKA", nameEn: "Tehran Imam Khomeini Intl", nameFa: "فرودگاه بین‌المللی امام خمینی", cityFa: "تهران", countryFa: "ایران", lat: 35.416, lon: 51.152, elev: 3305, fir: "OIIX" },
  { icao: "OIII", iata: "THR", nameEn: "Tehran Mehrabad Intl", nameFa: "فرودگاه بین‌المللی مهرآباد", cityFa: "تهران", countryFa: "ایران", lat: 35.689, lon: 51.313, elev: 3962, fir: "OIIX" },
  { icao: "OIMM", iata: "MHD", nameEn: "Mashhad Shahid Hashemi Nejad", nameFa: "فرودگاه بین‌المللی شهید هاشمی‌نژاد مشهد", cityFa: "مشهد", countryFa: "ایران", lat: 36.235, lon: 59.641, elev: 3263, fir: "OIIX" },
  { icao: "OISS", iata: "SYZ", nameEn: "Shiraz Shahid Dastghaib", nameFa: "فرودگاه بین‌المللی شهید دستغیب شیراز", cityFa: "شیراز", countryFa: "ایران", lat: 29.539, lon: 52.589, elev: 4921, fir: "OIIX" },
  { icao: "OIFM", iata: "IFN", nameEn: "Isfahan Shahid Beheshti", nameFa: "فرودگاه بین‌المللی شهید بهشتی اصفهان", cityFa: "اصفهان", countryFa: "ایران", lat: 32.751, lon: 51.861, elev: 5059, fir: "OIIX" },
  { icao: "OITT", iata: "TBZ", nameEn: "Tabriz Shahid Madani", nameFa: "فرودگاه بین‌المللی شهید مدنی تبریز", cityFa: "تبریز", countryFa: "ایران", lat: 38.133, lon: 46.235, elev: 4459, fir: "OIIX" },
  { icao: "OIKB", iata: "BND", nameEn: "Bandar Abbas Intl", nameFa: "فرودگاه بین‌المللی بندرعباس", cityFa: "بندرعباس", countryFa: "ایران", lat: 27.218, lon: 56.378, elev: 22, fir: "OIIX" },
  { icao: "OIAW", iata: "AWZ", nameEn: "Ahvaz General Soleimani", nameFa: "فرودگاه بین‌المللی شهید سلیمانی اهواز", cityFa: "اهواز", countryFa: "ایران", lat: 31.337, lon: 48.762, elev: 66, fir: "OIIX" },
  { icao: "OIBK", iata: "KIH", nameEn: "Kish Island Intl", nameFa: "فرودگاه بین‌المللی کیش", cityFa: "کیش", countryFa: "ایران", lat: 26.526, lon: 53.980, elev: 101, fir: "OIIX" },
  { icao: "OIZH", iata: "ZAH", nameEn: "Zahedan Intl", nameFa: "فرودگاه بین‌المللی زاهدان", cityFa: "زاهدان", countryFa: "ایران", lat: 29.476, lon: 60.906, elev: 4525, fir: "OIIX" },
  { icao: "OIBB", iata: "BUZ", nameEn: "Bushehr Intl", nameFa: "فرودگاه بین‌المللی بوشهر", cityFa: "بوشهر", countryFa: "ایران", lat: 28.945, lon: 50.835, elev: 68, fir: "OIIX" },
  { icao: "OIKK", iata: "KER", nameEn: "Kerman Ayatollah Hashemi", nameFa: "فرودگاه بین‌المللی کرمان", cityFa: "کرمان", countryFa: "ایران", lat: 30.274, lon: 56.964, elev: 5741, fir: "OIIX" },
  { icao: "OIGG", iata: "RAS", nameEn: "Rasht Sardar Jangal", nameFa: "فرودگاه سردار جنگل رشت", cityFa: "رشت", countryFa: "ایران", lat: 37.325, lon: 49.626, elev: -40, fir: "OIIX" },
  { icao: "OINZ", iata: "SRY", nameEn: "Sari Dasht-e Naz", nameFa: "فرودگاه دشت ناز ساری", cityFa: "ساری", countryFa: "ایران", lat: 36.665, lon: 53.193, elev: 35, fir: "OIIX" },
  { icao: "OITY", iata: "AZD", nameEn: "Yazd Shahid Sadooghi", nameFa: "فرودگاه بین‌المللی شهید صدوقی یزد", cityFa: "یزد", countryFa: "ایران", lat: 31.905, lon: 54.276, elev: 4055, fir: "OIIX" },

  // --- INTERNATIONAL HUBS ---
  { icao: "OMDB", iata: "DXB", nameEn: "Dubai International", nameFa: "فرودگاه بین‌المللی دبی", cityFa: "دبی", countryFa: "امارات", lat: 25.253, lon: 55.365, elev: 62, fir: "OMAE" },
  { icao: "OTHH", iata: "DOH", nameEn: "Hamad International", nameFa: "فرودگاه بین‌المللی حمد دوحه", cityFa: "دوحه", countryFa: "قطر", lat: 25.273, lon: 51.608, elev: 13, fir: "OTBD" },
  { icao: "OKBK", iata: "KWI", nameEn: "Kuwait International", nameFa: "فرودگاه بین‌المللی کویت", cityFa: "کویت", countryFa: "کویت", lat: 29.227, lon: 47.979, elev: 206, fir: "OKAC" },
  { icao: "LTFM", iata: "IST", nameEn: "Istanbul Airport", nameFa: "فرودگاه بین‌المللی استانبول", cityFa: "استانبول", countryFa: "ترکیه", lat: 41.275, lon: 28.751, elev: 325, fir: "LTBB" },
  { icao: "EGLL", iata: "LHR", nameEn: "London Heathrow", nameFa: "فرودگاه هیترو لندن", cityFa: "لندن", countryFa: "بریتانیا", lat: 51.470, lon: -0.454, elev: 83, fir: "EGTT" },
  { icao: "KJFK", iata: "JFK", nameEn: "John F. Kennedy Intl", nameFa: "فرودگاه جان اف کندی نیویورک", cityFa: "نیویورک", countryFa: "ایالات متحده", lat: 40.639, lon: -73.778, elev: 13, fir: "KZNY" }
];

// App State
let currentAirport = AIRPORTS[0]; // OIIE
let activePage = 'home';
let currentMetar = null;
let currentTaf = null;
let activeSigmets = [];
let currentWindReport = null;
let storedSnowtams = [];
let isOffline = false;

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
  initUtcClock();
  initStorage();
  renderAirportChips();
  setupEventListeners();
  loadAllDataForAirport(currentAirport.icao);
  loadGlobalSigmets();
});

// UTC Clock with Real-time Tick
function initUtcClock() {
  function tick() {
    const now = new Date();
    const str = now.toUTCString().split(' ')[4] + ' UTC';
    const clockEl = document.getElementById('utc-clock');
    if (clockEl) clockEl.textContent = str;
  }
  tick();
  setInterval(tick, 1000);
}

// Local Storage for Favorites & SNOWTAM History
function initStorage() {
  try {
    const rawSnow = localStorage.getItem('atc_stored_snowtams');
    if (rawSnow) {
      storedSnowtams = JSON.parse(rawSnow);
    } else {
      // Seed default ICAO Doc 10066 sample
      seedDefaultSampleSnowtam();
    }
  } catch (e) {
    console.warn('Storage init failed', e);
  }
}

function seedDefaultSampleSnowtam() {
  const sample = parseSnowtam(
    `SWIR0001 OIIE 12050020\n(SNOWTAM 0001\nOIIE\n12050020 29R 5/5/5 100/100/100 03/03/03 WET SNOW/WET SNOW/WET SNOW\nRWY 29R FICON 5/5/5 100/100/100 03/03/03 WET SNOW/WET SNOW/WET SNOW)`,
    "OIIE"
  );
  storedSnowtams = [sample];
  saveStoredSnowtams();
}

function saveStoredSnowtams() {
  localStorage.setItem('atc_stored_snowtams', JSON.stringify(storedSnowtams));
}

// Navigation Router
function navigateTo(pageId) {
  activePage = pageId;
  document.querySelectorAll('.page-section').forEach(sec => sec.classList.add('d-none'));
  const target = document.getElementById(`page-${pageId}`);
  if (target) target.classList.remove('d-none');

  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.toggle('active', link.dataset.page === pageId);
  });

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Airport Chips Render
function renderAirportChips() {
  const container = document.getElementById('quick-airports-container');
  if (!container) return;
  container.innerHTML = '';

  AIRPORTS.forEach(apt => {
    const chip = document.createElement('div');
    chip.className = `airport-chip ${apt.icao === currentAirport.icao ? 'active' : ''}`;
    chip.innerHTML = `<strong>${apt.icao}</strong> <small class="text-muted">(${apt.iata || apt.cityFa})</small>`;
    chip.onclick = () => selectAirport(apt);
    container.appendChild(chip);
  });
}

function selectAirport(apt) {
  currentAirport = apt;
  renderAirportChips();
  updateAirportHeader();
  loadAllDataForAirport(apt.icao);
}

function updateAirportHeader() {
  const headerIcao = document.getElementById('current-icao-header');
  const headerName = document.getElementById('current-name-header');
  if (headerIcao) headerIcao.textContent = `${currentAirport.icao} / ${currentAirport.iata}`;
  if (headerName) headerName.textContent = `${currentAirport.nameFa} (${currentAirport.cityFa}، ${currentAirport.countryFa})`;
}

// Real OPMET Data Fetchers
async function loadAllDataForAirport(icao) {
  updateStatusBanner('در حال دریافت اطلاعات هواشناسی OPMET از سرورهای جهانی...', 'info');

  try {
    // 1. Fetch METAR
    const metarUrl = `https://aviationweather.gov/api/data/metar?ids=${icao}&format=json`;
    const metarRes = await fetch(metarUrl);
    if (metarRes.ok) {
      const metarJson = await metarRes.json();
      if (metarJson && metarJson.length > 0) {
        currentMetar = parseMetar(metarJson[0].rawOb || `METAR ${icao} NO RAW`, icao);
        currentMetar.source = "AviationWeather.gov (NOAA/NWS)";
        localStorage.setItem(`metar_${icao}`, JSON.stringify(currentMetar));
        isOffline = false;
      } else {
        fallbackCachedMetar(icao);
      }
    } else {
      fallbackCachedMetar(icao);
    }
  } catch (e) {
    fallbackCachedMetar(icao);
  }

  try {
    // 2. Fetch TAF
    const tafUrl = `https://aviationweather.gov/api/data/taf?ids=${icao}&format=json`;
    const tafRes = await fetch(tafUrl);
    if (tafRes.ok) {
      const tafJson = await tafRes.json();
      if (tafJson && tafJson.length > 0) {
        currentTaf = parseTaf(tafJson[0].rawTAF || `TAF ${icao}`, icao);
        localStorage.setItem(`taf_${icao}`, JSON.stringify(currentTaf));
      } else {
        fallbackCachedTaf(icao);
      }
    } else {
      fallbackCachedTaf(icao);
    }
  } catch (e) {
    fallbackCachedTaf(icao);
  }

  try {
    // 3. Fetch Upper-Air Wind Aloft (Open-Meteo GFS)
    const windUrl = `https://api.open-meteo.com/v1/forecast?latitude=${currentAirport.lat}&longitude=${currentAirport.lon}&hourly=wind_speed_1000hPa,wind_direction_1000hPa,temperature_1000hPa,wind_speed_850hPa,wind_direction_850hPa,temperature_850hPa,wind_speed_700hPa,wind_direction_700hPa,temperature_700hPa,wind_speed_500hPa,wind_direction_500hPa,temperature_500hPa,wind_speed_300hPa,wind_direction_300hPa,temperature_300hPa,wind_speed_250hPa,wind_direction_250hPa,temperature_250hPa,wind_speed_200hPa,wind_direction_200hPa,temperature_200hPa&wind_speed_unit=kn&forecast_days=1`;
    const windRes = await fetch(windUrl);
    if (windRes.ok) {
      const windJson = await windRes.json();
      currentWindReport = processUpperAir(windJson);
    }
  } catch (e) {
    console.warn('Wind aloft fetch error', e);
  }

  renderAllViews();
}

function fallbackCachedMetar(icao) {
  const cached = localStorage.getItem(`metar_${icao}`);
  if (cached) {
    currentMetar = JSON.parse(cached);
    isOffline = true;
  } else {
    currentMetar = null;
  }
}

function fallbackCachedTaf(icao) {
  const cached = localStorage.getItem(`taf_${icao}`);
  if (cached) {
    currentTaf = JSON.parse(cached);
  } else {
    currentTaf = null;
  }
}

// Global SIGMET Fetcher
async function loadGlobalSigmets() {
  try {
    const res = await fetch('https://aviationweather.gov/api/data/sigmet?format=json');
    if (res.ok) {
      const list = await res.json();
      activeSigmets = list || [];
      renderSigmetView();
    }
  } catch (e) {
    console.warn('SIGMET fetch error', e);
  }
}

// METAR Parser (ES6)
function parseMetar(raw, icaoFallback) {
  const clean = raw.trim().replace(/\s+/g, ' ');
  const isSpeci = clean.startsWith('SPECI') || clean.includes(' SPECI ');

  // Wind
  const windMatch = clean.match(/\b(\d{3}|VRB)(\d{2,3})(?:G(\d{2,3}))?KT\b/);
  let windDir = null, windSpd = null, windGust = null, isCalm = false;
  if (windMatch) {
    windDir = windMatch[1] === 'VRB' ? 'VRB' : parseInt(windMatch[1], 10);
    windSpd = parseInt(windMatch[2], 10);
    if (windSpd === 0) isCalm = true;
    if (windMatch[3]) windGust = parseInt(windMatch[3], 10);
  }

  // Cavok & Visibility
  const isCavok = clean.includes('CAVOK');
  let visMeters = null;
  if (isCavok) {
    visMeters = 9999;
  } else {
    const visMatch = clean.match(/\b(\d{4})\b/);
    if (visMatch && !clean.includes('Q' + visMatch[1])) {
      visMeters = parseInt(visMatch[1], 10);
    }
  }

  // Temperature & Dewpoint
  const tdMatch = clean.match(/\b(M?\d{2})\/(M?\d{2})\b/);
  let temp = null, dewp = null;
  if (tdMatch) {
    temp = parseSignedTemp(tdMatch[1]);
    dewp = parseSignedTemp(tdMatch[2]);
  }

  // Altimeter QNH
  const qnhMatch = clean.match(/\bQ(\d{4})\b/);
  let altHpa = qnhMatch ? parseInt(qnhMatch[1], 10) : null;
  const inHgMatch = clean.match(/\bA(\d{4})\b/);
  let altInHg = inHgMatch ? parseFloat((parseInt(inHgMatch[1], 10) / 100).toFixed(2)) : null;

  // Flight Category
  let category = 'VFR';
  const effVis = visMeters || 10000;
  if (effVis < 1600) category = 'LIFR';
  else if (effVis < 5000) category = 'IFR';
  else if (effVis <= 8000) category = 'MVFR';
  else category = 'VFR';

  return {
    icao: icaoFallback,
    rawMetar: raw,
    isSpeci,
    windDir,
    windSpd,
    windGust,
    isCalm,
    isCavok,
    visMeters,
    temp,
    dewp,
    altHpa,
    altInHg,
    category,
    obsTimeUtc: clean.match(/\b\d{6}Z\b/)?.[0] || '1200Z',
    trend: clean.includes('NOSIG') ? 'NOSIG' : clean.includes('BECMG') ? 'BECMG' : clean.includes('TEMPO') ? 'TEMPO' : 'NONE'
  };
}

function parseSignedTemp(str) {
  if (str.startsWith('M')) return -parseInt(str.substring(1), 10);
  return parseInt(str, 10);
}

// TAF Parser (ES6)
function parseTaf(raw, icaoFallback) {
  const clean = raw.trim().replace(/\s+/g, ' ');
  const timeMatch = clean.match(/\b(\d{6}Z)\s+(\d{4}\/\d{4})\b/);
  return {
    icao: icaoFallback,
    rawTaf: raw,
    issueTime: timeMatch ? timeMatch[1] : '',
    validPeriod: timeMatch ? timeMatch[2] : '',
    source: "AviationWeather.gov / WIFS OPMET"
  };
}

// SNOWTAM Parser (ICAO Doc 10066 & GRF 2021)
function parseSnowtam(raw, icaoFallback) {
  const clean = raw.trim().replace(/\r\n/g, '\n');
  const upper = clean.toUpperCase();

  const serialMatch = clean.match(/(?:SNOWTAM|SW[A-Z]{2})\s*(\d{4})/i);
  const serial = serialMatch ? serialMatch[1] : "0001";

  // Runway designator
  let rwy = "29R";
  const rwyBeforeRwycc = clean.match(/\b(0[1-9]|[12][0-9]|3[0-6])[LCR]?\b(?=\s+[0-6]\/[0-6]\/[0-6])/);
  if (rwyBeforeRwycc) {
    rwy = rwyBeforeRwycc[0];
  } else {
    const explicitRwy = clean.match(/(?:RWY|RUNWAY)\s*([0-3][0-9][LCR]?)/i);
    if (explicitRwy) rwy = explicitRwy[1];
  }

  // RWYCC 3 Thirds
  const rwyccMatch = clean.match(/\b([0-6])\/([0-6])\/([0-6])\b/);
  let rwycc1 = null, rwycc2 = null, rwycc3 = null, lowestRwycc = null;
  if (rwyccMatch) {
    rwycc1 = parseInt(rwyccMatch[1], 10);
    rwycc2 = parseInt(rwyccMatch[2], 10);
    rwycc3 = parseInt(rwyccMatch[3], 10);
    lowestRwycc = Math.min(rwycc1, rwycc2, rwycc3);
  }

  // Contaminant
  const contaminants = ["DRY SNOW", "WET SNOW", "COMPACTED SNOW", "SLUSH", "ICE", "FROST", "WET", "STANDING WATER"];
  let contaminant = "DRY";
  for (const c of contaminants) {
    if (upper.includes(c)) { contaminant = c; break; }
  }

  return {
    id: Date.now(),
    icao: icaoFallback,
    serial,
    rwy,
    rwycc1,
    rwycc2,
    rwycc3,
    lowestRwycc,
    contaminant,
    rawSnowtam: raw,
    issueTime: new Date().toISOString().substring(11, 16) + 'Z',
    source: "ICAO GRF / Doc 10066"
  };
}

// Process Upper Air Forecast
function processUpperAir(json) {
  if (!json || !json.hourly) return null;
  const h = json.hourly;
  const idx = 0; // Current hour

  const levels = [
    { name: "Surface (1000 hPa)", alt: "300 FT", spd: h.wind_speed_1000hPa?.[idx], dir: h.wind_direction_1000hPa?.[idx], temp: h.temperature_1000hPa?.[idx] },
    { name: "FL050 (850 hPa)", alt: "5,000 FT", spd: h.wind_speed_850hPa?.[idx], dir: h.wind_direction_850hPa?.[idx], temp: h.temperature_850hPa?.[idx] },
    { name: "FL100 (700 hPa)", alt: "10,000 FT", spd: h.wind_speed_700hPa?.[idx], dir: h.wind_direction_700hPa?.[idx], temp: h.temperature_700hPa?.[idx] },
    { name: "FL180 (500 hPa)", alt: "18,000 FT", spd: h.wind_speed_500hPa?.[idx], dir: h.wind_direction_500hPa?.[idx], temp: h.temperature_500hPa?.[idx] },
    { name: "FL300 (300 hPa)", alt: "30,000 FT", spd: h.wind_speed_300hPa?.[idx], dir: h.wind_direction_300hPa?.[idx], temp: h.temperature_300hPa?.[idx] },
    { name: "FL340 (250 hPa)", alt: "34,000 FT", spd: h.wind_speed_250hPa?.[idx], dir: h.wind_direction_250hPa?.[idx], temp: h.temperature_250hPa?.[idx] },
    { name: "FL390 (200 hPa)", alt: "39,000 FT", spd: h.wind_speed_200hPa?.[idx], dir: h.wind_direction_200hPa?.[idx], temp: h.temperature_200hPa?.[idx] }
  ];

  return { levels, time: h.time?.[idx] || 'Now UTC' };
}

// Render All Views
function renderAllViews() {
  renderHomeView();
  renderMetarView();
  renderTafView();
  renderWindView();
  renderSnowtamView();
  renderBoardView();
  updateStatusBanner(isOffline ? 'OFFLINE — نمایش داده‌های ذخیره شده محلی' : 'داده‌های زنده با موفقیت به‌روزرسانی شد.', isOffline ? 'warning' : 'success');
}

function renderHomeView() {
  const container = document.getElementById('home-metar-summary');
  if (!container) return;

  if (currentMetar) {
    container.innerHTML = `
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
          <span class="badge-cat ${currentMetar.category.toLowerCase()}">${currentMetar.category}</span>
          ${currentMetar.isSpeci ? '<span class="badge bg-danger ms-2">SPECI ویژه</span>' : ''}
        </div>
        <div class="text-muted small">رصد: ${currentMetar.obsTimeUtc}</div>
      </div>
      <div class="row g-2 text-center">
        <div class="col-4">
          <div class="p-2 border rounded">
            <small class="text-muted d-block">باد سطحی</small>
            <strong class="text-primary fs-5">${currentMetar.windDir}°/${currentMetar.windSpd} KT</strong>
          </div>
        </div>
        <div class="col-4">
          <div class="p-2 border rounded">
            <small class="text-muted d-block">دما / شبنم</small>
            <strong class="text-danger fs-5">${currentMetar.temp}°C / ${currentMetar.dewp}°C</strong>
          </div>
        </div>
        <div class="col-4">
          <div class="p-2 border rounded">
            <small class="text-muted d-block">فشار QNH</small>
            <strong class="text-info fs-5">Q${currentMetar.altHpa || '--'}</strong>
          </div>
        </div>
      </div>
      <div class="mt-3">
        <div class="raw-msg-box">${currentMetar.rawMetar}</div>
      </div>
    `;
  } else {
    container.innerHTML = `<div class="alert alert-warning">هیچ داده‌ای برای فرودگاه انتخاب شده دریافت نشد. (NO CURRENT DATA)</div>`;
  }
}

function renderMetarView() {
  const rawBox = document.getElementById('metar-raw-box');
  const detailsBox = document.getElementById('metar-decoded-details');
  if (rawBox && currentMetar) {
    rawBox.textContent = currentMetar.rawMetar;
  }
  if (detailsBox && currentMetar) {
    detailsBox.innerHTML = `
      <div class="row g-3">
        <div class="col-md-3"><strong>دسته‌بندی پرواز:</strong> <span class="badge-cat ${currentMetar.category.toLowerCase()}">${currentMetar.category}</span></div>
        <div class="col-md-3"><strong>سمت و سرعت باد:</strong> ${currentMetar.windDir}° / ${currentMetar.windSpd} KT</div>
        <div class="col-md-3"><strong>دید افقی:</strong> ${currentMetar.isCavok ? 'CAVOK (>10km)' : (currentMetar.visMeters + ' متر')}</div>
        <div class="col-md-3"><strong>فشار فرودگاه:</strong> Q${currentMetar.altHpa || '--'} hPa</div>
        <div class="col-md-3"><strong>دما / نقطه شبنم:</strong> ${currentMetar.temp}°C / ${currentMetar.dewp}°C</div>
        <div class="col-md-3"><strong>روند ۲ ساعته:</strong> ${currentMetar.trend}</div>
        <div class="col-md-6"><strong>منبع داده:</strong> ${currentMetar.source || 'AviationWeather.gov'}</div>
      </div>
    `;
  }
}

function renderTafView() {
  const rawBox = document.getElementById('taf-raw-box');
  const detailsBox = document.getElementById('taf-decoded-details');
  if (rawBox && currentTaf) rawBox.textContent = currentTaf.rawTaf;
  if (detailsBox && currentTaf) {
    detailsBox.innerHTML = `
      <div class="row g-2">
        <div class="col-md-6"><strong>زمان صدور:</strong> ${currentTaf.issueTime}</div>
        <div class="col-md-6"><strong>دوره اعتبار:</strong> ${currentTaf.validPeriod}</div>
        <div class="col-12 mt-2"><strong>منبع:</strong> ${currentTaf.source}</div>
      </div>
    `;
  }
}

function renderWindView() {
  const tableBody = document.getElementById('wind-levels-table');
  if (!tableBody || !currentWindReport) return;
  tableBody.innerHTML = '';

  currentWindReport.levels.forEach(lvl => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${lvl.name}</strong></td>
      <td>${lvl.alt}</td>
      <td><span class="text-primary fw-bold">${lvl.dir}° / ${lvl.spd} KT</span></td>
      <td>${lvl.temp}°C</td>
    `;
    tableBody.appendChild(tr);
  });
}

function renderSnowtamView() {
  const container = document.getElementById('snowtam-container');
  if (!container) return;

  if (storedSnowtams.length > 0) {
    const latest = storedSnowtams[0];
    const rwyccColor = (code) => {
      switch (code) {
        case 6: return 'var(--rwycc-6)';
        case 5: return 'var(--rwycc-5)';
        case 4: return 'var(--rwycc-4)';
        case 3: return 'var(--rwycc-3)';
        case 2: return 'var(--rwycc-2)';
        case 1: return 'var(--rwycc-1)';
        case 0: return 'var(--rwycc-0)';
        default: return '#64748B';
      }
    };

    container.innerHTML = `
      <div class="atc-card">
        <div class="d-flex justify-content-between align-items-center">
          <h5>وضعیت بخش‌های سه‌گانه باند ${latest.rwy} (ICAO GRF)</h5>
          <span class="badge" style="background-color: ${rwyccColor(latest.lowestRwycc)}; font-size: 1rem;">
            کمترین RWYCC: ${latest.lowestRwycc}
          </span>
        </div>
        <div class="rwy-thirds-box">
          <div class="rwy-third" style="background: ${rwyccColor(latest.rwycc1)}33;">
            <div class="title">THIRD 1 (ابتدای باند)</div>
            <div class="code" style="color: ${rwyccColor(latest.rwycc1)}">RWYCC ${latest.rwycc1}</div>
          </div>
          <div class="rwy-third" style="background: ${rwyccColor(latest.rwycc2)}33;">
            <div class="title">THIRD 2 (میانه باند)</div>
            <div class="code" style="color: ${rwyccColor(latest.rwycc2)}">RWYCC ${latest.rwycc2}</div>
          </div>
          <div class="rwy-third" style="background: ${rwyccColor(latest.rwycc3)}33;">
            <div class="title">THIRD 3 (انتهای باند)</div>
            <div class="code" style="color: ${rwyccColor(latest.rwycc3)}">RWYCC ${latest.rwycc3}</div>
          </div>
        </div>
        <div class="small mt-2"><strong>نوع آلاینده:</strong> ${latest.contaminant}</div>
        <div class="mt-3">
          <label class="form-label small text-muted">پیام خام اسنوتام (RAW SNOWTAM):</label>
          <div class="raw-msg-box">${latest.rawSnowtam}</div>
        </div>
      </div>
    `;
  } else {
    container.innerHTML = `
      <div class="alert alert-warning">
        <h5>SNOWTAM SOURCE NOT CONFIGURED</h5>
        <p>فید زنده مستقیم اسنوتام برای فرودگاه متصل نیست. می‌توانید نمونه رسمی ایکائو را بارگذاری نمایید.</p>
        <button class="btn btn-outline-primary btn-sm" onclick="seedDefaultSampleSnowtam(); renderSnowtamView();">بارگذاری نمونه استاندارد Doc 10066</button>
      </div>
    `;
  }
}

function renderSigmetView() {
  const container = document.getElementById('sigmet-list-container');
  if (!container) return;

  if (activeSigmets.length === 0) {
    container.innerHTML = `<div class="alert alert-success">هیچ پیام SIGMET فعالی در سیستم ثبت نشده است.</div>`;
    return;
  }

  container.innerHTML = '';
  activeSigmets.slice(0, 10).forEach(sig => {
    const card = document.createElement('div');
    card.className = 'atc-card';
    card.innerHTML = `
      <div class="d-flex justify-content-between">
        <h6><span class="badge bg-danger me-2">${sig.firId || 'FIR'}</span> ${sig.firName || 'منطقه پروازی'}</h6>
        <span class="badge bg-warning text-dark">${sig.hazard || 'WX'}</span>
      </div>
      <div class="small text-muted mb-2">اعتبار: ${sig.validTimeFrom || ''} تا ${sig.validTimeTo || ''}</div>
      <div class="raw-msg-box">${sig.rawSigmet || 'NO RAW SIGMET'}</div>
    `;
    container.appendChild(card);
  });
}

function renderBoardView() {
  const tbody = document.getElementById('atc-board-tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  AIRPORTS.slice(0, 8).forEach(apt => {
    const tr = document.createElement('tr');
    tr.style.cursor = 'pointer';
    tr.onclick = () => selectAirport(apt);

    const isCurrent = apt.icao === currentAirport.icao;
    const cat = isCurrent && currentMetar ? currentMetar.category : 'VFR';

    tr.innerHTML = `
      <td><strong>${apt.icao}</strong> (${apt.iata})</td>
      <td>${apt.nameFa}</td>
      <td><span class="badge-cat ${cat.toLowerCase()}">${cat}</span></td>
      <td>${isCurrent && currentMetar ? `${currentMetar.windDir}°/${currentMetar.windSpd}KT` : '--'}</td>
      <td>${isCurrent && currentMetar ? `Q${currentMetar.altHpa}` : '--'}</td>
      <td><span class="badge bg-success">METAR OK</span></td>
    `;
    tbody.appendChild(tr);
  });
}

function updateStatusBanner(msg, type = 'info') {
  const banner = document.getElementById('status-banner');
  if (!banner) return;
  banner.className = `alert alert-${type} py-2 mb-3`;
  banner.textContent = msg;
}

// Event Listeners & Search
function setupEventListeners() {
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(link.dataset.page);
    });
  });

  const searchInput = document.getElementById('airport-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase().trim();
      const resultsContainer = document.getElementById('search-results-list');
      if (!resultsContainer) return;
      resultsContainer.innerHTML = '';

      if (!q) return;

      const filtered = AIRPORTS.filter(a =>
        a.icao.toLowerCase().includes(q) ||
        a.iata.toLowerCase().includes(q) ||
        a.nameFa.toLowerCase().includes(q) ||
        a.nameEn.toLowerCase().includes(q)
      );

      filtered.forEach(a => {
        const item = document.createElement('div');
        item.className = 'p-2 border-bottom cursor-pointer';
        item.style.cursor = 'pointer';
        item.innerHTML = `<strong>${a.icao}</strong> - ${a.nameFa} <span class="text-muted">(${a.cityFa})</span>`;
        item.onclick = () => {
          selectAirport(a);
          searchInput.value = '';
          resultsContainer.innerHTML = '';
          const modal = bootstrap.Modal.getInstance(document.getElementById('searchModal'));
          if (modal) modal.hide();
        };
        resultsContainer.appendChild(item);
      });
    });
  }
}
