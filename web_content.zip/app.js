const $ = id => document.getElementById(id);
const money = n => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(Number(n)||0);
let products = JSON.parse(localStorage.getItem('warmate_products') || '[]');
let target = localStorage.getItem('warmate_target') || '2026-12-12T00:00';
$('targetDate').value = target;

function saveProducts(){localStorage.setItem('warmate_products',JSON.stringify(products));renderProducts();}
function renderProducts(){
  $('productList').innerHTML='';
  $('empty').style.display=products.length?'none':'block';
  products.forEach((p,i)=>{
    const card=document.createElement('article');card.className='product';
    const info=document.createElement('div');
    const title=document.createElement('h3');title.textContent=p.name;
    const prices=document.createElement('div');prices.className='prices';
    prices.innerHTML=`Normal: ${money(p.normal)}<br>Target: <strong>${money(p.target)}</strong>`;
    info.append(title,prices);
    const actions=document.createElement('div');actions.className='actions';
    const link=document.createElement('a');link.href=p.url;link.target='_blank';link.rel='noopener noreferrer';link.textContent='Buka produk';
    const del=document.createElement('button');del.className='delete';del.textContent='Hapus';del.onclick=()=>{products.splice(i,1);saveProducts();};
    actions.append(link,del);card.append(info,actions);$('productList').append(card);
  });
  $('productCount').textContent=products.length;
  $('listCounter').textContent=products.length+' produk';
  $('totalPrice').textContent=money(products.reduce((s,p)=>s+(Number(p.target)||0),0));
}
$('productForm').addEventListener('submit',e=>{
  e.preventDefault();
  const name=$('name').value.trim(),url=$('url').value.trim();
  try{
    const parsed=new URL(url);
    const host=parsed.hostname.toLowerCase();
    const isShopeeDomain =
      host === 'shopee.co.id' ||
      host.endsWith('.shopee.co.id') ||
      host === 'shope.ee' ||
      host === 'id.shp.ee' ||
      host === 'shp.ee';
    if(parsed.protocol !== 'https:' || !isShopeeDomain){
      alert('Masukkan link produk dari domain Shopee.');
      return;
    }
  }catch{alert('Link produk belum valid.');return;}
  products.push({name,url,normal:$('normalPrice').value,target:$('targetPrice').value});
  saveProducts();e.target.reset();
});
$('saveDate').onclick=()=>{
  target=$('targetDate').value;
  if(!target){alert('Pilih tanggal dan waktu terlebih dahulu.');return;}
  localStorage.setItem('warmate_target',target);tick();alert('Waktu countdown berhasil diatur.');
};
function tick(){
  const diff=new Date(target).getTime()-Date.now();
  if(!Number.isFinite(diff)){return;}
  const d=Math.max(0,diff);
  $('days').textContent=Math.floor(d/86400000);
  $('hours').textContent=String(Math.floor(d%86400000/3600000)).padStart(2,'0');
  $('minutes').textContent=String(Math.floor(d%3600000/60000)).padStart(2,'0');
  $('seconds').textContent=String(Math.floor(d%60000/1000)).padStart(2,'0');
  if(diff<=0)$('timer').setAttribute('aria-label','Waktu promo telah tiba');
}
const checks=[...$('checklist').querySelectorAll('input')];
function updateChecks(){
  const done=checks.filter(c=>c.checked).length;
  $('checkProgress').textContent=done+'/5';
  $('progressBar').style.width=(done/5*100)+'%';
  localStorage.setItem('warmate_checks',JSON.stringify(checks.map(c=>c.checked)));
}
try{const saved=JSON.parse(localStorage.getItem('warmate_checks')||'[]');checks.forEach((c,i)=>c.checked=!!saved[i]);}catch{}
checks.forEach(c=>c.addEventListener('change',updateChecks));
updateChecks();renderProducts();tick();setInterval(tick,1000);
