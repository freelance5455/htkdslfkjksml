// MoodMind: personal assistant. Bina API key ke, poori tarah phone ke andar chalta hai.
const $ = id => document.getElementById(id);
const store = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } };
const put = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
let mem = store("mm_mem", []), evo = store("mm_evo", {learned: 0, good: 0, bad: 0, boost: {}}), last = [], lastQ = "";
const STOP = new Set("the a an is are of to in and kya hai ka ki ke ko se me mein hota hoti what how why who which for on mujhe batao bata".split(" "));
const tok = s => s.toLowerCase().replace(/[^a-z0-9\u0900-\u097f\s]/g, " ").split(/\s+/).filter(Boolean);
function sync() { put("mm_mem", mem); put("mm_evo", evo); $("lvl").textContent = "Evolution level " + (1 + Math.floor((evo.learned * 2 + evo.good + evo.bad) / 5)) + " · " + mem.length + " topic yaad"; }

/* ---- Chat UI ---- */
const msgs = $("msgs");
function say(text, who) { const d = document.createElement("div"); d.className = "m " + (who || "bot"); d.textContent = text; msgs.appendChild(d); msgs.scrollTop = msgs.scrollHeight; return d; }
function buttons(d, labels, cb) { const r = document.createElement("div"); r.className = "btns"; labels.forEach((l, i) => { const b = document.createElement("button"); b.textContent = l; b.onclick = () => { r.remove(); cb(i); }; r.appendChild(b); }); d.appendChild(r); msgs.scrollTop = msgs.scrollHeight; }
const choice = (t, labels) => new Promise(res => buttons(say(t), labels, res));
const ask = t => choice(t, ["Haan, allow", "Nahi"]).then(i => i === 0);

/* ---- Chhota neural network (mood samajhne ke liye) ---- */
const D = [["ye app bahut badhiya hai",1],["mujhe ye bahut pasand aaya",1],["kya mast kaam kiya",1],["great product love it",1],["amazing experience very happy",1],["bahut acha aur fast hai",1],["best game ever maza aa gaya",1],["superb quality paisa vasool",1],["awesome work thank you",1],["ekdum zabardast hai",1],["i love this it is fantastic",1],["bahut sundar design hai",1],["bahut mast hai maza aaya",1],["bahut badiya service hai",1],["good job well done",1],["nice app very useful",1],["kaafi helpful aur easy hai",1],["mujhe bahut khushi hui",1],
["ye bakwas hai bilkul bekar",0],["worst app ever hate it",0],["bahut kharab experience tha",0],["bad quality waste of money",0],["mujhe bilkul pasand nahi aaya",0],["slow aur boring hai",0],["terrible service very angry",0],["paisa barbad ho gaya",0],["ye game ghatiya hai",0],["i hate this it is awful",0],["bahut bura laga",0],["not good very disappointing",0],["bahut bekar hai",0],["bahut bakwas service hai",0],["bahut ghatiya quality hai",0],["poor service bad app",0],["kaafi slow aur hang hota hai",0],["mujhe bahut gussa aaya",0]];
const H = 8; let V, ix, W1, b1, W2, b2;
const vec = s => { const x = Array(V.length).fill(0); tok(s).forEach(w => { if (ix.has(w)) x[ix.get(w)] = 1; }); return x; };
function fw(x) { const h = W1.map((r, j) => { let s = b1[j]; x.forEach((v, i) => { if (v) s += r[i]; }); return Math.tanh(s); }); let z = b2; h.forEach((v, j) => z += v * W2[j]); return {h, o: 1 / (1 + Math.exp(-z))}; }
function trainNet() {
  V = [...new Set(D.flatMap(d => tok(d[0])))]; ix = new Map(V.map((w, i) => [w, i]));
  const r = () => Math.random() * 0.6 - 0.3; W1 = Array.from({length: H}, () => V.map(r)); b1 = Array(H).fill(0); W2 = Array.from({length: H}, r); b2 = 0;
  for (let e = 0; e < 300; e++) D.forEach(([s, y]) => { const x = vec(s), {h, o} = fw(x), er = o - y;
    for (let j = 0; j < H; j++) { const dh = er * W2[j] * (1 - h[j] * h[j]); W2[j] -= 0.15 * er * h[j]; b1[j] -= 0.15 * dh; x.forEach((v, i) => { if (v) W1[j][i] -= 0.15 * dh; }); } b2 -= 0.15 * er; });
}
function mood(t) {
  if (!tok(t).some(w => ix.has(w))) return "Ye shabd mujhe mood ke liye nahi aate. Koi aur sentence try karo.";
  const p = fw(vec(t)).o, pos = p >= 0.5, c = (pos ? p : 1 - p) * 100;
  return (pos ? "Positive 😊" : "Negative 😞") + " (" + c.toFixed(0) + "% yakeen)";
}

/* ---- Seekhna ---- */
async function wiki(topic, lang, off) {
  const u = "https://" + lang + ".wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=" + encodeURIComponent(topic) + "&gsroffset=" + (off || 0) + "&gsrlimit=1&prop=extracts&exintro=1&explaintext=1&format=json&origin=*";
  const ac = new AbortController(), tm = setTimeout(() => ac.abort(), 12000);
  let r; try { r = await (await fetch(u, {signal: ac.signal})).json(); } finally { clearTimeout(tm); }
  const p = r.query && Object.values(r.query.pages)[0]; return p && p.extract ? p : null;
}
async function learn(topic, off, approved) {
  if (!topic) return false;
  if (!approved && !await ask("Main \"" + topic + "\" ke baare mein internet (Wikipedia) se padhna chahta hoon. Allow?")) { say("Theek hai, nahi seekhunga."); return false; }
  const h = say("Padh raha hoon…");
  try {
    const a = /[\u0900-\u097f]/.test(topic) ? "hi" : "en", p = await wiki(topic, a, off) || await wiki(topic, a === "en" ? "hi" : "en", off);
    if (!p) { h.textContent = "Is topic par kuch nahi mila. Doosra naam try karo."; return false; }
    const key = topic + (off ? " #2" : ""); mem = mem.filter(m => m.topic.toLowerCase() !== key.toLowerCase());
    mem.push({topic: key, title: p.title, text: p.extract.slice(0, 3000)}); evo.learned++; sync();
    h.textContent = "Seekh liya: " + p.title + ". Ab mujhse iske baare mein pooch sakte ho."; return true;
  } catch (e) { h.textContent = "Internet se connect nahi ho paya. Connection check karo."; return false; }
}
function remember(text) {
  let m = mem.find(x => x.topic === "Meri baatein"); if (!m) { m = {topic: "Meri baatein", title: "Meri baatein", text: ""}; mem.push(m); }
  m.text += (m.text ? " " : "") + text.replace(/[.!?।]*$/, ".");
  evo.learned++; sync();
}
function search(q) {
  const out = [];
  mem.forEach(m => { const tm = tok(m.topic + " " + m.title).some(w => q.includes(w));
    (m.text.match(/[^.!?।]+[.!?।]*/g) || []).map(s => s.trim()).filter(Boolean).forEach((s, i) => { const t = new Set(tok(s)), hit = q.filter(w => t.has(w)).length;
      if (hit || (tm && i === 0)) out.push({s, sc: hit + (tm ? 0.5 : 0) + (tm && i === 0 ? 1 : 0) + (evo.boost[s] || 0)}); }); });
  return out.sort((a, b) => b.sc - a.sc).filter(x => x.sc > 0.6);
}
function show(best) {
  last = best.slice(0, 2); const d = say(last.map(b => b.s).join(" "));
  buttons(d, ["Sahi", "Galat"], async i => {
    if (i === 0) { last.forEach(b => evo.boost[b.s] = (evo.boost[b.s] || 0) + 1); evo.good++; sync(); say("Shukriya, aise jawab aage rakhunga."); }
    else { last.forEach(b => evo.boost[b.s] = (evo.boost[b.s] || 0) - 2); evo.bad++; sync(); if (await learn(lastQ, 1)) { const b = search(tok(lastQ).filter(w => !STOP.has(w))); if (b.length) show(b); } }
  });
}

/* ---- Phone ke kaam: har kaam se pehle permission ---- */
const acts = {
  location: () => new Promise(ok => navigator.geolocation.getCurrentPosition(p => ok("Location: " + p.coords.latitude.toFixed(4) + ", " + p.coords.longitude.toFixed(4)), e => ok("Location nahi mili: " + e.message))),
  vibrate: async () => navigator.vibrate ? (navigator.vibrate([200, 100, 200]), "Vibrate kiya") : "Is phone/browser mein vibrate support nahi",
  battery: async () => { const b = await navigator.getBattery(); return "Battery " + Math.round(b.level * 100) + "%" + (b.charging ? " (charge ho rahi hai)" : ""); },
  notification: async () => { if (await Notification.requestPermission() !== "granted") return "Notification permission nahi mili"; new Notification("MoodMind", {body: "Ye tumhari permission se bheji gayi notification hai."}); return "Notification bheji"; },
  copy: async () => { await navigator.clipboard.writeText(last.length ? last.map(b => b.s).join(" ") : "MoodMind"); return "Clipboard mein copy ho gaya"; },
  share: async () => { await navigator.share({title: "MoodMind", text: last.length ? last.map(b => b.s).join(" ") : "MoodMind try karo"}); return "Share sheet khuli"; },
  camera: async () => { const s = await navigator.mediaDevices.getUserMedia({video: true}); setTimeout(() => s.getTracks().forEach(t => t.stop()), 3000); return "Camera 3 second chala aur band ho gaya"; }
};
async function phone(name) {
  if (!await ask("Main ye karna chahta hoon: \"" + name + "\". Allow karte ho?")) { say("Theek hai, nahi kiya."); return; }
  try { say(await acts[name]()); } catch (e) { say("Nahi ho paya: " + (e.message || "ye phone ise support nahi karta")); }
}

/* ---- Message samajhna ---- */
async function reply(t) {
  let m;
  if ((m = t.match(/^(?:seekho|sikho|learn)\s*[:\-]?\s*(.+)$/i) || t.match(/^(.+?)\s+(?:seekho|sikho|learn)$/i))) return void await learn(m[1].trim());
  if ((m = t.match(/^(?:yaad rakho|remember)\s*[:\-]?\s*(.+)$/i))) { remember(m[1]); return say("Yaad rakh liya. Kabhi bhi pooch lena."); }
  if ((m = t.match(/^mood\s*[:\-]?\s*(.+)$/i))) return say(mood(m[1]));
  if (/^(bhool jao|sab bhool jao|forget all)$/i.test(t)) return void await wipe();
  if (/(kya seekha|kya kya pata|yaadasht)/i.test(t)) return say(mem.length ? "Mujhe in topics ka pata hai: " + mem.map(x => x.topic).join(", ") : "Abhi tak kuch nahi seekha. Bolo: \"black hole seekho\".");
  if ((m = t.toLowerCase().match(/^(?:phone\s+)?(location|vibrate|battery|notification|copy|share|camera)(?:\s+(?:batao|karo|dikhao|bhejo|dekho|chalu karo|kar do))?$/))) return void await phone(m[1]);
  if (/^(hi|hello|hey|namaste|hii)\b/i.test(t)) return say("Namaste! Main tumhara personal assistant hoon. Mujhe kuch bhi seekhne ko bolo, jaise \"black hole seekho\", ya poochho \"mera naam kya hai\".");
  const q = tok(t).filter(w => !STOP.has(w)); lastQ = q.join(" ");
  if (!q.length) return say("Thoda aur batao, main samjha nahi.");
  let best = search(q);
  if (!best.length) {
    if (!await ask("Mujhe ye abhi nahi pata. Kya main internet (Wikipedia) se \"" + lastQ + "\" seekh loon?")) return say("Theek hai. Jab seekhna ho to bolo: \"" + lastQ + " seekho\".");
    if (await learn(lastQ, 0, true)) best = search(q);
  }
  if (best.length) show(best); else say("Phir bhi jawab nahi mila. Sawal ko doosre shabdon mein pooch kar dekho.");
}
async function wipe() { if (await ask("Saari seekhi hui cheezein delete kar doon?")) { mem = []; evo = {learned: 0, good: 0, bad: 0, boost: {}}; sync(); renderMem(); say("Sab bhool gaya. Ab fir se shuru."); } }
function renderMem() {
  const l = $("memList"); l.innerHTML = mem.length ? "" : "<small>Abhi kuch nahi seekha.</small>";
  mem.forEach((m, i) => { const d = document.createElement("div"); d.className = "item"; d.innerHTML = "<span></span><button>Hatao</button>"; d.firstChild.textContent = m.topic; d.lastChild.onclick = () => { mem.splice(i, 1); sync(); renderMem(); }; l.appendChild(d); });
}

/* ---- Start ---- */
$("f").onsubmit = e => { e.preventDefault(); const t = $("inp").value.trim(); if (!t) return; $("inp").value = ""; say(t, "me"); reply(t); };
$("memBtn").onclick = () => { renderMem(); $("mem").hidden = false; };
$("memClose").onclick = () => $("mem").hidden = true;
$("forget").onclick = () => { $("mem").hidden = true; wipe(); };
["Black hole seekho", "Yaad rakho: mera naam Rahul hai", "Mood: ye app mast hai", "Battery dekho", "Location batao", "Kya seekha"].forEach(c => { const b = document.createElement("button"); b.textContent = c; b.onclick = () => { $("inp").value = c; $("inp").focus(); }; $("chips").appendChild(b); });
trainNet(); sync();
say("Namaste! Main MoodMind hoon, tumhara personal assistant. Mujhe kuch bhi seekhne ko bolo, jaise \"Taj Mahal seekho\", aur main internet se padhkar yaad kar lunga. Har kaam se pehle main tumse permission poochunga.");
