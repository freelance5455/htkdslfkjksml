let balance=250000, txs=[];
const auth=document.getElementById('authScreen'), app=document.getElementById('appScreen');
const modal=document.getElementById('modal'), content=document.getElementById('modalContent');
function show(html){content.innerHTML=html;modal.classList.remove('hidden')}
function close(){modal.classList.add('hidden')}
document.getElementById('close').onclick=close;
modal.addEventListener('click',e=>{if(e.target===modal)close()});
function money(n){return n.toLocaleString('en-US')+' ل.س'}
function render(){document.getElementById('balance').textContent=money(balance);const box=document.getElementById('transactions');box.innerHTML=txs.length?txs.slice(0,4).map(t=>`<div class="tx"><div>${t.title}<small>${t.date}</small></div><b>${t.amount}</b></div>`).join(''):'<p class="muted">لا توجد عمليات بعد.</p>'}
function history(){show('<h2>سجل الحركات</h2><p class="muted">هذه حركات تجريبية محفوظة في هذه الجلسة فقط.</p>'+(txs.length?txs.map(t=>`<div class="tx"><div>${t.title}<small>${t.date}</small></div><b>${t.amount}</b></div>`).join(''):'<p>لا توجد عمليات بعد.</p>'))}
function addTx(title,amount){txs.unshift({title,amount,date:new Date().toLocaleString('ar')});render()}
document.getElementById('registerForm').addEventListener('submit',e=>{
 e.preventDefault();const name=document.getElementById('fullName').value.trim(), phone=document.getElementById('phone').value.trim(), country=document.getElementById('country').value;
 if(!name||!phone){alert('أكمل الاسم ورقم الهاتف');return}
 // Demo only: no password is stored and no account is created on a server.
 document.getElementById('hello').textContent='أهلاً '+name+' 👋';
 auth.classList.add('hidden');app.classList.remove('hidden');render();
});
function action(a){
 if(a==='send')show('<h2>إرسال تجريبي بالرقم</h2><div class="notice">هذه محاكاة فقط. لن تصل أموال إلى أي شخص.</div><input id="recipient" class="field" placeholder="رقم هاتف المستلم مع رمز الدولة"><input id="amount" class="field" type="number" min="1" placeholder="المبلغ بالليرة السورية"><button class="primary" id="confirm">تأكيد تجريبي</button>');
 if(a==='scan')show('<h2>مسح رمز QR</h2><div class="qr-demo">▦<br><small>QR تجريبي</small></div><div class="notice">الكاميرا وربط رموز QR غير مفعّلين بعد. لن يتم تنفيذ أي تحويل حقيقي.</div>');
 if(a==='receive')show('<h2>استقبال تجريبي</h2><p>رمز محفظتك التجريبي:</p><h2 style="color:#0b6b50;letter-spacing:2px">SHAM-DEMO-2048</h2><div class="notice">هذا الرمز للعرض فقط ولا يستقبل حوالات فعلية.</div>');
 if(a==='history')history();
 document.getElementById('confirm')?.addEventListener('click',()=>{let n=Number(document.getElementById('amount').value),r=document.getElementById('recipient').value.trim();if(!Number.isFinite(n)||n<=0){alert('أدخل مبلغاً صحيحاً');return}if(n>balance){alert('الرصيد التجريبي غير كافٍ');return}if(!r){alert('أدخل رقم المستلم');return}balance-=n;addTx('إرسال تجريبي إلى '+r,'− '+money(n));close()});
}
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>action(b.dataset.action)));
document.getElementById('allHistory').onclick=history;
document.getElementById('profileBtn').onclick=()=>show('<h2>حسابي التجريبي</h2><div class="notice">الملف الشخصي للتجربة فقط. لا يوجد حساب خادمي أو تحقق رقم أو هوية بعد.</div>');
document.getElementById('helpBtn').onclick=()=>show('<h2>المساعدة</h2><p>شام سوريا — نموذج أولي لتجربة واجهات التسجيل والمحفظة.</p><div class="notice">لا تدخل بيانات مصرفية أو كلمة مرور حقيقية أو صور هوية. لا توجد تحويلات مالية فعلية.</div>');
