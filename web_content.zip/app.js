const $=id=>document.getElementById(id);
const messages=$('messages'), input=$('messageInput'), toast=$('toast');
let selectedImage=null;
function notify(msg){toast.textContent=msg;toast.classList.add('show');setTimeout(()=>toast.classList.remove('show'),2400)}
function addMessage(text,who='bot',imageUrl=null){
 const row=document.createElement('div');row.className='message-row '+(who==='user'?'user-row':'bot-row');
 if(who==='bot'){const av=document.createElement('div');av.className='avatar';av.textContent='∞';row.appendChild(av)}
 const bubble=document.createElement('div');bubble.className='bubble '+(who==='user'?'user-bubble':'bot-bubble');bubble.textContent=text;
 if(imageUrl){const img=document.createElement('img');img.src=imageUrl;img.alt='Selected image';bubble.appendChild(img)}
 row.appendChild(bubble);messages.appendChild(row);messages.scrollTop=messages.scrollHeight;
 try{const history=JSON.parse(localStorage.getItem('metaCloneHistory')||'[]');history.push({text,who,time:Date.now()});localStorage.setItem('metaCloneHistory',JSON.stringify(history.slice(-80)))}catch(e){}
}
function demoReply(text){
 const t=text.toLowerCase();
 if(/hello|hi\b|hey/.test(t))return 'Hello! 👋 What would you like to explore today?';
 if(/science|study|homework|math|ગુજરાતી|gujarati/.test(t))return 'I can help explain a topic, solve a study question, or make revision notes. This preview is running in demo mode; connect a secure AI backend for real answers.';
 if(/image|photo|picture|draw|create/.test(t))return 'Image creation needs an image-generation service. Your image tool button is ready as a UI entry point.';
 if(/voice|speak/.test(t))return 'Voice controls are available in this browser when speech recognition is supported.';
 return 'Thanks for your message! This is a working interface demo, not a live AI connection. Connect your own AI API through a secure backend to get real AI responses.';
}
function send(){
 const text=input.value.trim();if(!text&&!selectedImage)return;
 addMessage(text||'Please help me understand this image.', 'user',selectedImage);
 input.value='';input.style.height='auto';
 const reply=demoReply(text||'image');
 setTimeout(()=>addMessage(reply,'bot'),350);
 selectedImage=null;$('attachmentPreview').hidden=true;
}
$('sendBtn').addEventListener('click',send);
input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
input.addEventListener('input',()=>{input.style.height='auto';input.style.height=Math.min(input.scrollHeight,85)+'px'});
document.querySelectorAll('[data-prompt]').forEach(b=>b.addEventListener('click',()=>{input.value=b.dataset.prompt;input.focus()}));
function chooseImage(file){if(!file)return;if(!file.type.startsWith('image/')){notify('Please choose an image file.');return}selectedImage=URL.createObjectURL(file);$('attachmentPreview').hidden=false;$('attachmentPreview').textContent='📎 Image selected — send a message to attach it.';notify('Image attached to your message.')}
$('attachBtn').onclick=()=>$('imageInput').click();$('imageBtn').onclick=()=>$('imageInput').click();$('cameraBtn').onclick=()=>$('cameraInput').click();
$('imageInput').onchange=e=>chooseImage(e.target.files[0]);$('cameraInput').onchange=e=>chooseImage(e.target.files[0]);
$('voiceBtn').onclick=()=>{
 const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
 if(!SR){notify('Speech recognition is not supported in this browser.');return}
 const rec=new SR();rec.lang=navigator.language||'en-US';rec.interimResults=false;
 rec.onstart=()=>notify('Listening… speak now');rec.onerror=()=>notify('Could not start voice input. Check microphone permission.');
 rec.onresult=e=>{input.value=e.results[0][0].transcript;input.focus()};rec.start();
};
$('themeBtn').onclick=()=>document.body.classList.toggle('light');
$('clearBtn').onclick=()=>{messages.innerHTML='';addMessage('Conversation cleared. What would you like to ask?');};
$('historyBtn').onclick=()=>{let h=[];try{h=JSON.parse(localStorage.getItem('metaCloneHistory')||'[]')}catch(e){};notify(h.length?`Saved locally: ${h.length} message entries.`:'No saved chat history yet.')};
$('profileBtn').onclick=()=>notify('Meta AI Clone · Personal demo profile');
$('menuBtn').onclick=()=>notify('Menu · Chat · Image · Voice · Settings');
