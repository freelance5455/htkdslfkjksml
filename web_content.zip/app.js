(() => {
  const STORAGE_KEY = 'bhagyalaxmi-delivery-challans-v1';
  const TRANSPORT_KEY = 'bhagyalaxmi-transport-names-v1';
  const RECIPIENT_KEY = 'bhagyalaxmi-saved-recipients-v1';
  const COMPANY_NAME = 'Shree Bhagyalaxmi Industries';
  const DEFAULT_TRANSPORTS = ['Porter', 'Rajasthan Roadways'];
  const DEFAULT_ROWS = 6;
  const STORAGE_ERROR = 'Could not save on this device. The browser or app storage may be full or blocked. Your changes were NOT saved.';
  const PRINT_NOTE = 'Print requested. If no print dialog appeared, this app wrapper does not support printing. Use "Share on WhatsApp" instead, or open the app in Chrome to print or save as PDF.';
  const PRINT_UNSUPPORTED = 'Printing is not available in this app. Use "Share on WhatsApp" instead, or open the app in Chrome to print or save as PDF.';
  const $ = (selector) => document.querySelector(selector);
  const els = {
    date: $('#challanDate'), number: $('#challanNumber'), recipient: $('#recipient'), vehicle: $('#vehicleNumber'),
    transport: $('#transportName'), customTransport: $('#customTransport'), savedRecipient: $('#savedRecipient'), itemInputs: $('#itemInputs'), history: $('#historyList'),
    search: $('#searchChallans'), saveStatus: $('#saveStatus'), printDate: $('#printDate'), printNumber: $('#printNumber'),
    printRecipient: $('#printRecipient'), printTransport: $('#printTransport'), printVehicle: $('#printVehicle'),
    printItems: $('#printItems'), printTotal: $('#printTotal'), editor: $('.editor'), shareBox: $('#shareBox'), shareText: $('#shareText')
  };
  let activeId = null;
  let rowCount = DEFAULT_ROWS;

  const newId = () => {
    try {
      if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
    } catch (error) { /* fall through */ }
    return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  };

  // Storage helpers never throw. Missing or malformed data falls back safely.
  const readJson = (key, fallback, isValid = Array.isArray) => {
    try {
      const value = JSON.parse(localStorage.getItem(key));
      return isValid(value) ? value : fallback;
    } catch (error) {
      return fallback;
    }
  };
  const writeJson = (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error('Storage write failed', error);
      return false;
    }
  };
  const isRecord = (item) => item && typeof item === 'object' && typeof item.id === 'string' && item.id !== '';
  const records = () => readJson(STORAGE_KEY, []).filter(isRecord);
  const transports = () => [...new Set([...DEFAULT_TRANSPORTS, ...readJson(TRANSPORT_KEY, []).filter(name => typeof name === 'string' && name.trim())])];
  const recipients = () => readJson(RECIPIENT_KEY, []).filter(item => item && typeof item.id === 'string' && typeof item.address === 'string' && item.address.trim());

  const escapeHtml = (value) => String(value === undefined || value === null ? '' : value).replace(/[&<>'"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
  const hasValue = (value) => value !== '' && value !== null && value !== undefined;
  const showStatus = (message) => { els.saveStatus.textContent = message; };

  const setTransportOptions = (selected = '') => {
    const names = transports();
    // Keep a challan's transport selectable even if it is no longer in the saved list.
    if (selected && !names.includes(selected)) names.push(selected);
    els.transport.innerHTML = '<option value="">Select transport</option>' + names.map(name => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join('');
    els.transport.value = selected;
  };
  const setRecipientOptions = (selected = '') => {
    els.savedRecipient.innerHTML = '<option value="">Select a saved recipient</option>' + recipients().map(recipient => `<option value="${escapeHtml(recipient.id)}">${escapeHtml(recipient.label || recipient.address)}</option>`).join('');
    els.savedRecipient.value = selected;
  };
  const displayDate = (value) => {
    if (!value) return '–';
    const [year, month, day] = String(value).split('-');
    return year && month && day ? `${day}/${month}/${year}` : '–';
  };
  const formatAmount = (value) => {
    if (!hasValue(value)) return '–';
    const number = Number(value);
    return Number.isNaN(number) ? '–' : number.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };
  const getMode = () => document.querySelector('input[name="numberMode"]:checked').value;
  const getNextNumber = () => {
    const nums = records().map(r => String(r.number || '').match(/(\d+)\s*$/)).filter(Boolean).map(match => Number(match[1]));
    return `DC-${String((nums.length ? Math.max(...nums) : 0) + 1).padStart(4, '0')}`;
  };
  const setNumberMode = () => {
    const automatic = getMode() === 'auto';
    els.number.disabled = automatic;
    if (automatic) els.number.value = getNextNumber();
    renderPreview();
  };
  const itemRow = (item = {}, index) => `<tr>
    <td class="sr">${index + 1}</td>
    <td class="description"><input data-field="description" value="${escapeHtml(item.description || '')}" placeholder="Item description"></td>
    <td class="small"><input data-field="hsn" value="${escapeHtml(item.hsn || '')}" placeholder="HSN"></td>
    <td class="small"><input data-field="nos" inputmode="decimal" value="${escapeHtml(item.nos || '')}" placeholder="–"></td>
    <td class="small"><input data-field="set" inputmode="decimal" value="${escapeHtml(item.set || '')}" placeholder="–"></td>
    <td class="amount"><input data-field="amount" type="number" min="0" step="0.01" value="${escapeHtml(hasValue(item.amount) ? item.amount : '')}" placeholder="–"></td>
    <td><button class="remove-item" type="button" aria-label="Remove item ${index + 1}">×</button></td></tr>`;
  const makeItems = (items = []) => {
    rowCount = Math.max(DEFAULT_ROWS, items.length);
    els.itemInputs.innerHTML = Array.from({ length: rowCount }, (_, index) => itemRow(items[index], index)).join('');
  };
  const getItems = () => [...els.itemInputs.querySelectorAll('tr')].map(row => ({
    description: row.querySelector('[data-field="description"]').value.trim(), hsn: row.querySelector('[data-field="hsn"]').value.trim(),
    nos: row.querySelector('[data-field="nos"]').value.trim(), set: row.querySelector('[data-field="set"]').value.trim(),
    amount: row.querySelector('[data-field="amount"]').value.trim()
  })).filter(item => Object.values(item).some(Boolean));
  const currentRecord = () => ({
    id: activeId || newId(), number: els.number.value.trim(), date: els.date.value,
    recipient: els.recipient.value.trim(), vehicle: els.vehicle.value.trim(), transport: els.transport.value, items: getItems(), updatedAt: Date.now()
  });
  const totals = (items) => {
    const priced = items.filter(item => hasValue(item.amount));
    return { hasAmounts: priced.length > 0, total: priced.reduce((sum, item) => sum + (Number(item.amount) || 0), 0) };
  };
  // Returns an error message, or '' when the challan can be saved or shared.
  const validateRecord = (record) => {
    if (!record.number) return 'Enter a challan number before saving or sharing.';
    if (!record.recipient && record.items.length === 0) return 'Add a recipient or at least one item before saving or sharing.';
    return '';
  };
  const renderPreview = () => {
    const record = currentRecord();
    els.printDate.textContent = displayDate(record.date);
    els.printNumber.textContent = record.number || '–';
    els.printRecipient.textContent = record.recipient || '–';
    els.printTransport.textContent = record.transport || '–';
    els.printVehicle.textContent = record.vehicle || '–';
    const visibleItems = [...record.items]; while (visibleItems.length < DEFAULT_ROWS) visibleItems.push({});
    els.printItems.innerHTML = visibleItems.map((item, index) => {
      const hasItem = Object.values(item).some(hasValue);
      return `<tr><td>${hasItem ? index + 1 : ''}</td><td>${escapeHtml(item.description || '')}</td><td>${escapeHtml(item.hsn || '')}</td><td>${escapeHtml(item.nos || '–')}</td><td>${escapeHtml(item.set || '–')}</td><td>${formatAmount(item.amount)}</td></tr>`;
    }).join('');
    const { hasAmounts, total } = totals(record.items);
    els.printTotal.textContent = hasAmounts ? formatAmount(total) : '–';
  };
  const renderHistory = () => {
    const query = els.search.value.trim().toLowerCase();
    const matching = records()
      .filter(record => [record.number, record.recipient, record.date, record.transport].join(' ').toLowerCase().includes(query))
      .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    els.history.innerHTML = matching.length ? matching.map(record => `<button class="history-entry" type="button" data-id="${escapeHtml(record.id)}"><strong>${escapeHtml(record.number || 'Unnumbered challan')}</strong><span>${escapeHtml(record.recipient || 'No recipient')} · ${displayDate(record.date)}</span></button>`).join('') : '<p class="history-empty">No saved challans found.</p>';
  };
  const resetForm = () => {
    activeId = null; rowCount = DEFAULT_ROWS; els.date.value = new Date().toISOString().slice(0, 10); els.recipient.value = ''; els.vehicle.value = ''; els.customTransport.value = '';
    document.querySelector('input[name="numberMode"][value="auto"]').checked = true; setTransportOptions(); setRecipientOptions(); makeItems(); setNumberMode(); els.shareBox.hidden = true; showStatus('New challan');
  };
  const loadRecord = (id) => {
    const record = records().find(item => item.id === id);
    if (!record) { showStatus('That challan could not be found. It may have been removed.'); renderHistory(); return; }
    activeId = record.id; els.date.value = record.date || ''; els.recipient.value = record.recipient || ''; els.vehicle.value = record.vehicle || ''; els.customTransport.value = '';
    const mode = /^DC-\d+$/.test(record.number || '') ? 'auto' : 'manual';
    document.querySelector(`input[name="numberMode"][value="${mode}"]`).checked = true;
    setTransportOptions(record.transport || ''); setRecipientOptions(); els.number.value = record.number || ''; els.number.disabled = mode === 'auto';
    makeItems(Array.isArray(record.items) ? record.items : []); els.shareBox.hidden = true;
    renderPreview();
    showStatus(`Loaded ${record.number || 'challan'} for editing. Change it and press Save challan to update it.`);
    els.editor.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  const save = () => {
    const record = currentRecord();
    const problem = validateRecord(record);
    if (problem) { showStatus(problem); return; }
    const all = records();
    const duplicate = all.find(item => item.id !== record.id && String(item.number || '').toLowerCase() === record.number.toLowerCase());
    if (duplicate) { showStatus(`Challan number ${record.number} is already used by another saved challan. Choose a different number.`); return; }
    const index = all.findIndex(item => item.id === record.id);
    if (index >= 0) all[index] = record; else all.push(record);
    if (!writeJson(STORAGE_KEY, all)) { showStatus(STORAGE_ERROR); return; }
    activeId = record.id; showStatus(`Saved ${record.number}`); renderHistory();
  };

  // ---- WhatsApp sharing -------------------------------------------------
  const buildShareText = (record) => {
    const lines = [
      `*${COMPANY_NAME}*`,
      '*DELIVERY CHALLAN*',
      '',
      `Challan No: ${record.number || '–'}`,
      `Date: ${displayDate(record.date)}`,
      '',
      'To:',
      record.recipient || '–',
      '',
      `Transport: ${record.transport || '–'}`,
      `Vehicle No: ${record.vehicle || '–'}`,
      '',
      'Items:'
    ];
    if (record.items.length === 0) lines.push('(no items entered)');
    record.items.forEach((item, index) => {
      const quantity = [item.nos ? `NOS: ${item.nos}` : '', item.set ? `SET: ${item.set}` : ''].filter(Boolean).join(' | ') || 'Qty: –';
      const amount = hasValue(item.amount) ? ` | Amount: ₹${formatAmount(item.amount)}` : '';
      lines.push(`${index + 1}. ${item.description || '–'}${item.hsn ? ` (HSN ${item.hsn})` : ''}`);
      lines.push(`   ${quantity}${amount}`);
    });
    const { hasAmounts, total } = totals(record.items);
    lines.push('', hasAmounts ? `*Total: ₹${formatAmount(total)}*` : 'Total: –');
    return lines.join('\n');
  };
  // Returns true when WhatsApp was opened, false when the wrapper or browser blocked it.
  const openWhatsApp = (text) => {
    // Optional native bridge a wrapper can provide (see README). Not required.
    if (window.ChallanNative && typeof window.ChallanNative.shareWhatsApp === 'function') {
      try { window.ChallanNative.shareWhatsApp(text); return true; } catch (error) { console.error(error); }
    }
    try {
      // wa.me opens WhatsApp's contact/group picker with the text pre-filled. Nothing is sent automatically.
      const opened = window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
      return Boolean(opened);
    } catch (error) {
      return false;
    }
  };
  const shareWhatsApp = () => {
    const record = currentRecord();
    const problem = validateRecord(record);
    if (problem) { showStatus(problem); return; }
    const text = buildShareText(record);
    els.shareText.value = text;
    els.shareBox.hidden = false;
    const opened = openWhatsApp(text);
    showStatus(opened
      ? 'Opening WhatsApp. Choose a contact or group, check the message, then press send yourself.'
      : 'WhatsApp did not open from this app. Use "Copy message" below and paste it into WhatsApp.');
  };
  const copyShareText = () => {
    const text = els.shareText.value;
    const fallbackCopy = () => {
      els.shareText.focus(); els.shareText.select();
      let copied = false;
      try { copied = document.execCommand('copy'); } catch (error) { copied = false; }
      showStatus(copied ? 'Message copied. Paste it into WhatsApp.' : 'Could not copy automatically. Press and hold the message box, then choose Copy.');
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text)
        .then(() => showStatus('Message copied. Paste it into WhatsApp.'))
        .catch(fallbackCopy);
    } else {
      fallbackCopy();
    }
  };

  // ---- Printing ---------------------------------------------------------
  const printChallan = () => {
    renderPreview();
    if (window.ChallanNative && typeof window.ChallanNative.printChallan === 'function') {
      try { window.ChallanNative.printChallan(); showStatus('Sent to the print service.'); return; } catch (error) { console.error(error); }
    }
    if (typeof window.print !== 'function') { showStatus(PRINT_UNSUPPORTED); return; }
    const originalTitle = document.title;
    document.title = `Delivery Challan ${els.number.value.trim() || 'Draft'}`;
    try {
      window.print();
      showStatus(PRINT_NOTE);
    } catch (error) {
      showStatus(PRINT_UNSUPPORTED);
    } finally {
      document.title = originalTitle;
    }
  };

  // ---- Event wiring -----------------------------------------------------
  document.addEventListener('input', event => {
    if (!event.target.closest('.editor')) return;
    const field = event.target.dataset.field;
    if (field === 'nos' && event.target.value.trim()) event.target.closest('tr').querySelector('[data-field="set"]').value = '';
    if (field === 'set' && event.target.value.trim()) event.target.closest('tr').querySelector('[data-field="nos"]').value = '';
    renderPreview();
  });
  document.addEventListener('change', event => { if (event.target.name === 'numberMode') setNumberMode(); else if (event.target.closest('.editor')) renderPreview(); });
  $('#newChallan').addEventListener('click', resetForm);
  $('#saveChallan').addEventListener('click', save);
  $('#shareWhatsapp').addEventListener('click', shareWhatsApp);
  $('#copyShare').addEventListener('click', copyShareText);
  $('#printPdf').addEventListener('click', printChallan);
  $('#addItem').addEventListener('click', () => {
    const count = els.itemInputs.querySelectorAll('tr').length;
    els.itemInputs.insertAdjacentHTML('beforeend', itemRow({}, count));
    rowCount = count + 1;
    renderPreview();
  });
  els.itemInputs.addEventListener('click', event => {
    const remove = event.target.closest('.remove-item');
    if (!remove) return;
    const rows = els.itemInputs.querySelectorAll('tr');
    if (rows.length <= DEFAULT_ROWS) { remove.closest('tr').querySelectorAll('input').forEach(input => { input.value = ''; }); }
    else remove.closest('tr').remove();
    [...els.itemInputs.querySelectorAll('tr')].forEach((row, index) => { row.querySelector('.sr').textContent = index + 1; });
    rowCount = els.itemInputs.querySelectorAll('tr').length;
    renderPreview();
  });
  $('#saveTransport').addEventListener('click', () => {
    const typed = els.customTransport.value.trim();
    if (!typed) { showStatus('Type a transport name first.'); return; }
    const saved = transports();
    // Reuse the existing spelling when the name matches one already saved (for example "porter" for "Porter").
    const existing = saved.find(item => item.toLowerCase() === typed.toLowerCase());
    const name = existing || typed;
    if (!existing && !writeJson(TRANSPORT_KEY, [...readJson(TRANSPORT_KEY, []).filter(item => typeof item === 'string'), name])) { showStatus(STORAGE_ERROR); return; }
    setTransportOptions(name); els.customTransport.value = ''; renderPreview();
    showStatus(existing ? `Using saved transport "${name}".` : `Transport "${name}" saved for reuse.`);
  });
  $('#saveRecipient').addEventListener('click', () => {
    const address = els.recipient.value.trim();
    if (!address) { showStatus('Enter the recipient details before saving.'); return; }
    const saved = recipients();
    const existing = saved.find(recipient => recipient.address.trim().toLowerCase() === address.toLowerCase());
    if (existing) { setRecipientOptions(existing.id); showStatus('Recipient already saved.'); return; }
    const recipient = { id: newId(), label: address.replace(/\n/g, ', ').slice(0, 70), address };
    if (!writeJson(RECIPIENT_KEY, [...saved, recipient])) { showStatus(STORAGE_ERROR); return; }
    setRecipientOptions(recipient.id); showStatus('Recipient saved for reuse.');
  });
  els.savedRecipient.addEventListener('change', () => {
    const recipient = recipients().find(item => item.id === els.savedRecipient.value);
    if (recipient) { els.recipient.value = recipient.address; renderPreview(); }
  });
  els.search.addEventListener('input', renderHistory);
  // One delegated handler works for every saved entry, including ones rendered later.
  els.history.addEventListener('click', event => {
    const entry = event.target.closest('.history-entry');
    if (entry) loadRecord(entry.getAttribute('data-id'));
  });

  setTransportOptions(); setRecipientOptions(); resetForm(); renderHistory();
})();
