
const SUPABASE_URL = "https://maztcaldlmjsgftoejku.supabase.co";
const SUPABASE_KEY = "sb_publishable_g1FkJ_45yJG26sepMBN-uA_ngerEMMz";
const db = window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
let user=null, household=null, items=[], shopping=[], prices=[], preparedness=[], activeTab="dashboard", editing=null, currentProductImage=null, currentProductData=null;

const categoryGroups={
  "🍎 Lebensmittel":["Obst & Gemüse","Fleisch & Wurst","Fisch & Meeresfrüchte","Milch, Eier & Käse","Brot & Backwaren","Nudeln, Reis & Getreide","Hülsenfrüchte","Konserven","Tiefkühl","Kühlung","Frühstück","Getränke","Süßes & Snacks","Gewürze & Kräuter","Saucen & Aufstriche","Backzutaten","Fertiggerichte"],
  "🧻 Haushalt":["Papierwaren","Waschmittel","Reinigung","Spülmittel & Küche","Müll & Entsorgung","Folien, Beutel & Backpapier","Haushaltsbedarf","Batterien & Leuchtmittel"],
  "🧴 Körperpflege":["Körperpflege","Haarpflege","Zahnpflege","Toilettenartikel","Damenhygiene","Rasur & Bartpflege"],
  "🐶 Tier":["Tiernahrung","Tierstreu","Tierpflege","Tierbedarf"],
  "👶 Baby & Kinder":["Babynahrung","Windeln","Babypflege","Baby & Kinder"],
  "💊 Gesundheit":["Gesundheit & Apotheke","Erste Hilfe"],
  "📦 Sonstiges":["Sonstiges"]
};
const cats=Object.values(categoryGroups).flat();
const categoryKeywords={
  "Obst & Gemüse":["apfel","birne","banane","orange","zitrone","tomate","gurke","paprika","salat","kartoffel","möhre","karotte","zwiebel","knoblauch","brokkoli","zucchini","obst","gemüse"],
  "Fleisch & Wurst":["fleisch","hähnchen","huhn","pute","truthahn","rind","schwein","hackfleisch","hack","wurst","salami","schinken","speck","schnitzel"],
  "Fisch & Meeresfrüchte":["fisch","lachs","thunfisch","forelle","garnelen","krabben","muscheln","meerestiere"],
  "Milch, Eier & Käse":["milch","joghurt","quark","sahne","butter","käse","mozzarella","parmesan","ei","eier"],
  "Brot & Backwaren":["brot","brötchen","toast","baguette","breze","croissant","backware"],
  "Nudeln, Reis & Getreide":["nudel","spaghetti","penne","reis","couscous","bulgur","haferflocken","müsli","getreide"],
  "Hülsenfrüchte":["bohnen","linsen","kichererbsen","erbse"],
  "Konserven":["dose","konserve","dosentomaten","mais","erbsen dose"],
  "Tiefkühl":["tk ","tiefkühl","tiefkuehl","gefroren","frost"],
  "Getränke":["cola","limonade","wasser","saft","bier","wein","kaffee","espresso","tee","energy","getränk"],
  "Süßes & Snacks":["chips","schokolade","keks","kekse","gummibär","bonbon","snack","nüsse","popcorn"],
  "Gewürze & Kräuter":["salz","pfeffer","paprika gewürz","curry","oregano","basilikum","kräuter","gewürz"],
  "Saucen & Aufstriche":["ketchup","mayonnaise","senf","sauce","soße","aufstrich","marmelade","nutella","pesto"],
  "Backzutaten":["mehl","zucker","hefe","backpulver","vanillezucker","kakao","backzut"],
  "Papierwaren":["klopapier","toilettenpapier","küchenrolle","küchenpapier","taschentuch","serviette","papierhandtuch"],
  "Waschmittel":["waschmittel","weichspüler","waschpulver","pods","waschkapsel"],
  "Reinigung":["reiniger","putzmittel","glasreiniger","badreiniger","allzweckreiniger","desinfektion","scheuermilch"],
  "Spülmittel & Küche":["spülmittel","geschirrspüler","spültab","spülmaschinen","tabs","schwamm","spülschwamm"],
  "Müll & Entsorgung":["müllbeutel","müllsack","abfallbeutel","müll","kompostbeutel"],
  "Folien, Beutel & Backpapier":["frischhaltefolie","alufolie","backpapier","gefrierbeutel","zipbeutel","beutel"],
  "Körperpflege":["duschgel","seife","deo","deodorant","körperlotion","creme","bodylotion"],
  "Haarpflege":["shampoo","haarspülung","conditioner","haarkur","haargel","haar"],
  "Zahnpflege":["zahnpasta","zahnbürste","mundspülung","zahnseide"],
  "Toilettenartikel":["rasierer","toilettenartikel","wattestäbchen","wattepad"],
  "Damenhygiene":["tampon","binde","menstruation","perioden"],
  "Rasur & Bartpflege":["rasierer","rasiergel","rasierklinge","bartöl","bart"],
  "Tiernahrung":["hundefutter","katzenfutter","tierfutter","hundefutter","katzenfutter","kaninchenfutter","vogelfutter","nassfutter","trockenfutter","leckerli","snack für hund","snack für katz"],
  "Tierstreu":["katzenstreu","streu","einstreu","holzstreu"],
  "Tierpflege":["hundeshampoo","katzenshampoo","fellpflege","zeckenschutz","tierpflege"],
  "Tierbedarf":["halsband","leine","napf","katzenklo","kratzbaum","spielzeug hund","spielzeug katze","tierbedarf"],
  "Babynahrung":["babynahrung","babybrei","pre nahrung","folgemilch","babymilch"],
  "Windeln":["windel","windeln","feuchttücher","feuchttuch"],
  "Babypflege":["babyöl","babycreme","wundschutz","babyshampoo"],
  "Gesundheit & Apotheke":["vitamin","schmerzmittel","medikament","nasenspray","hustensaft","salbe","apotheke"],
  "Erste Hilfe":["pflaster","verband","kompresse","erste hilfe","desinfektionsspray"]
};
function categoryOptions(selected=""){return Object.entries(categoryGroups).map(([group,list])=>`<optgroup label="${esc(group)}">${list.map(c=>`<option value="${esc(c)}" ${selected===c?'selected':''}>${esc(c)}</option>`).join("")}</optgroup>`).join("");}
function suggestCategory(name){const n=String(name||"").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,"");for(const [cat,words] of Object.entries(categoryKeywords)){if(words.some(w=>n.includes(w.normalize("NFD").replace(/[\u0300-\u036f]/g,""))))return cat;}return "";}
const units=["Stk.","g","kg","mg","ml","l","cl","Packung","Pack","Beutel","Dose","Glas","Flasche","Karton","Schachtel","Becher","Tube","Portion","Bund","Rolle","Meter","Paar","Tablette"];
const places=["Vorratsregal","Kühlschrank","Gefrierfach","Keller","Getränkelager","Bad","Putzschrank","Tierbedarf","Haushaltslager","Sonstiges"];

function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function daysTo(d){if(!d)return null;const a=new Date();a.setHours(0,0,0,0);const b=new Date(d+"T00:00:00");return Math.round((b-a)/86400000)}
function mhdClass(d){const x=daysTo(d);return x!==null&&x<0?"expired":x!==null&&x<=7?"soon":""}
function mhdText(d){const x=daysTo(d);if(x===null)return "kein MHD";if(x<0)return `abgelaufen · ${Math.abs(x)} T.`;if(x===0)return "heute";if(x===1)return "morgen";return `in ${x} Tagen`}
function flash(msg,type="error"){const el=document.getElementById("flash");if(el){el.className=type;el.textContent=msg;el.classList.remove("hidden");setTimeout(()=>el.classList.add("hidden"),5000)}}

async function init(){
  const {data:{session}}=await db.auth.getSession();
  if(session){user=session.user;await loadHousehold();} else renderAuth();
  db.auth.onAuthStateChange(async (_e,s)=>{user=s?.user||null;if(user){await loadHousehold()}else{household=null;renderAuth()}});
}
function renderAuth(){
document.getElementById("app").innerHTML=`<main class="auth"><div class="auth-stage"><section class="card auth-card">
<p class="auth-kicker">Euer digitaler Vorrat</p>
<img class="auth-logo-img" src="app-icon.png" alt="Unser Vorrat">
<h1>Unser Vorrat</h1>
<p class="auth-sub">Gemeinsam lagern. Gemeinsam planen. Einfach Vorrat.</p>
<div class="auth-divider"></div>
<div id="flash" class="hidden"></div>
<label>E-Mail</label><input id="email" type="email" autocomplete="email" placeholder="deine@email.de">
<label>Passwort</label><input id="pw" type="password" autocomplete="current-password" placeholder="••••••••">
<div class="row auth-actions"><button onclick="login()">Einloggen</button><button class="secondary" onclick="signup()">Konto anlegen</button></div>
<p class="auth-note">Mit demselben Konto kannst du später auf Handy, Tablet und PC zugreifen.</p>
<p class="auth-vibe"><span>✦</span> Gothic · Beats · Vorrat <span>✦</span></p>
</section></div></main>`;
}
async function login(){
 try{
  const email=document.getElementById("email").value.trim(), password=document.getElementById("pw").value;
  if(!email||!password)return flash("Bitte E-Mail und Passwort eingeben.");
  const {error}=await db.auth.signInWithPassword({email,password});
  if(error)throw error;
 }catch(e){flash(e.message||"Login fehlgeschlagen.");}
}
async function signup(){
 try{
  const email=document.getElementById("email").value.trim(), password=document.getElementById("pw").value;
  if(!email||password.length<6)return flash("Bitte E-Mail eingeben und ein Passwort mit mindestens 6 Zeichen wählen.");
  const {data,error}=await db.auth.signUp({email,password});
  if(error)throw error;
  if(data.session) {flash("Konto erstellt. Du wirst angemeldet.","ok");}
  else flash("Konto erstellt. Bitte bestätige ggf. deine E-Mail und logge dich danach ein.","ok");
 }catch(e){flash(e.message||"Konto konnte nicht erstellt werden.");}
}
async function loadHousehold(){
 const {data,error}=await db.from("household_members").select("household_id").eq("user_id",user.id);
 if(error){renderError(error.message);return}
 if(!data?.length){renderSetup();return}
 const {data:h,error:he}=await db.from("households").select("*").eq("id",data[0].household_id).single();
 if(he){renderError(he.message);return}
 household=h;await loadData();renderApp();subscribe();
}
function renderSetup(){
document.getElementById("app").innerHTML=`<main class="auth"><section class="card">
<img class="auth-logo-img" src="app-icon.png" alt="Unser Vorrat"><h1>Unser Vorrat</h1><p class="sub">Fast geschafft! Richte euren gemeinsamen Haushalt ein.</p>
<div id="flash" class="hidden"></div>
<h3>Neuen Haushalt erstellen</h3><label>Name</label><input id="hname" value="Unser Vorrat">
<button style="margin-top:12px;width:100%" onclick="createHousehold()">Haushalt erstellen</button>
<div style="height:1px;background:var(--line);margin:22px 0"></div>
<h3>Oder beitreten</h3><label>Einladungscode</label><input id="invite" placeholder="z.B. A1B2C3D4">
<button class="secondary" style="margin-top:12px;width:100%" onclick="joinHousehold()">Mit Code beitreten</button>
</section></main>`;
}
async function createHousehold(){
 try{const {data,error}=await db.rpc("create_household",{household_name:document.getElementById("hname").value.trim()||"Unser Vorrat"});if(error)throw error;household=data?.[0];alert("Haushalt erstellt. Einladungscode: "+household.invite_code);await loadData();renderApp();subscribe();}catch(e){flash(e.message)}
}
async function joinHousehold(){
 try{const {data,error}=await db.rpc("join_household",{code:document.getElementById("invite").value});if(error)throw error;household=data?.[0];await loadData();renderApp();subscribe();}catch(e){flash(e.message)}
}
async function loadData(){
 const [a,b,p,r]=await Promise.all([
  db.from("inventory_items").select("*").eq("household_id",household.id).order("mhd",{ascending:true,nullsFirst:false}).order("name"),
  db.from("shopping_items").select("*").eq("household_id",household.id).order("checked").order("name"),
  db.from("product_prices").select("*").eq("household_id",household.id).order("recorded_at",{ascending:false}),
  db.from("preparedness_items").select("*").eq("household_id",household.id).order("category").order("priority",{ascending:false}).order("name")
 ]);
 if(a.error)throw a.error;if(b.error)throw b.error;
 items=a.data||[];shopping=b.data||[];prices=p.error?[]:(p.data||[]);preparedness=r.error?[]:(r.data||[]);
}
let channel;
function subscribe(){
 if(channel)db.removeChannel(channel);
 channel=db.channel("vorrat-"+household.id).on("postgres_changes",{event:"*",schema:"public",table:"inventory_items",filter:"household_id=eq."+household.id},async()=>{await loadData();renderApp()}).on("postgres_changes",{event:"*",schema:"public",table:"shopping_items",filter:"household_id=eq."+household.id},async()=>{await loadData();renderApp()}).subscribe();
}
function renderError(msg){document.getElementById("app").innerHTML=`<main class="auth"><section class="card"><h2>Ups 😕</h2><p>${esc(msg)}</p><button onclick="location.reload()">Neu laden</button></section></main>`}
function renderApp(){
 document.getElementById("app").innerHTML=`<div class="uv-app"><div class="uv-main">${heroHeader()}<div id="flash" class="hidden"></div>${activeTab==='dashboard'?dashboardView():activeTab==='vorrat'?inventoryView():activeTab==='einkauf'?shoppingView():activeTab==='rezepte'?recipeView():activeTab==='vorsorge'?preparednessView():pricesView()}</div>${bottomNav()}</div>`;
 if(activeTab==='rezepte') setTimeout(renderSmartRecipes,0);
 if(activeTab==='vorrat') setTimeout(()=>applyInventorySearch(window._q||''),0);
}
function heroHeader(){
 return `<header class="uv-hero">
   <div class="uv-hero-bg"></div>
   <button class="uv-hero-settings" aria-label="Einstellungen" onclick="openSettings()"></button>
   <div class="uv-code">${esc(household?.name||'Unser Vorrat')} · Code <b>${esc(household?.invite_code||'')}</b></div>
 </header>`;
}
function openSettings(){
 const modal=document.getElementById("modal")||document.body.appendChild(Object.assign(document.createElement("div"),{id:"modal"}));
 modal.innerHTML=`<div class="modal"><section class="card settings-card">
 <div class="dash-head"><div><span class="dash-kicker">APP-EINSTELLUNGEN</span><h2 style="margin:4px 0 0">⚙ Einstellungen</h2></div><button class="secondary" onclick="closeSettings()">✕</button></div>
 <div class="settings-info"><div><small>Haushalt</small><b>${esc(household?.name||"–")}</b></div><div><small>Einladungscode</small><b>${esc(household?.invite_code||"–")}</b></div><div><small>Angemeldet als</small><b>${esc(user?.email||"–")}</b></div></div>
 <div class="household-profile">
   <div class="dash-head"><div><span class="dash-kicker">HAUSHALTSPROFIL</span><h3 style="margin:3px 0 0">👨‍👩‍👧‍👦 Euer Bedarf</h3></div><span class="profile-summary">${householdProfile().people} Pers. · ${householdProfile().pets} Tiere</span></div>
   <p class="muted">Diese Angaben werden künftig für Vorsorge-Berechnungen und weitere Haushaltsfunktionen verwendet.</p>
   <div class="profile-fields"><label><span>Personen im Haushalt</span><input id="profilePeople" type="number" min="1" max="50" value="${householdProfile().people}"></label><label><span>Haustiere</span><input id="profilePets" type="number" min="0" max="30" value="${householdProfile().pets}"></label></div>
   <button onclick="saveHouseholdProfile()">💾 Haushaltsprofil speichern</button>
 </div>
 <div class="settings-actions"><button onclick="copyInviteCode()">📋 Einladungscode kopieren</button><button class="secondary" onclick="location.reload()">↻ App neu laden</button><button class="danger" onclick="logoutFromSettings()">↪ Abmelden</button></div>
 <p class="muted" style="margin:12px 0 0">Das Zahnrad öffnet nur diese Einstellungen. Abmelden passiert ausschließlich über den roten Abmelden-Button.</p>
 </section></div>`;
}
function closeSettings(){const m=document.getElementById("modal");if(m)m.innerHTML="";}
async function copyInviteCode(){const code=household?.invite_code||"";try{await navigator.clipboard.writeText(code);flash("Einladungscode kopiert.","ok")}catch(e){prompt("Einladungscode",code)}}
async function logoutFromSettings(){if(confirm("Wirklich abmelden?")) await logout();}
function goTab(tab){activeTab=tab;renderApp();window.scrollTo({top:0,behavior:"smooth"});}
function bottomNav(){
 return `<nav class="uv-bottom-nav uv-nav-6">
 <button class="uv-nav ${activeTab==='dashboard'?'active red':''}" onclick="goTab('dashboard')"><span>⌂</span><small>Übersicht</small></button>
 <button class="uv-nav ${activeTab==='vorrat'?'active red':''}" onclick="goTab('vorrat')"><span>▣</span><small>Vorrat</small></button>
 <button class="uv-nav ${activeTab==='einkauf'?'active blue':''}" onclick="goTab('einkauf')"><span>🛒</span><small>Einkauf</small></button>
 <button class="uv-nav ${activeTab==='rezepte'?'active purple':''}" onclick="goTab('rezepte')"><span>🍳</span><small>Rezepte</small></button>
 <button class="uv-nav ${activeTab==='vorsorge'?'active green':''}" onclick="goTab('vorsorge')"><span>🛡</span><small>Vorsorge</small></button>
 <button class="uv-nav ${activeTab==='preise'?'active gold':''}" onclick="goTab('preise')"><span>€</span><small>Preise</small></button>
 </nav>`;
}
function quickGo(kind){
 if(kind==='shopping'){goTab('einkauf');return;}
 activeTab='vorrat'; window._q=''; window._cat=''; window._place=''; window._status=kind; quickFilter=kind; renderApp(); setTimeout(()=>document.getElementById('uv-results')?.scrollIntoView({behavior:'smooth',block:'start'}),50);
}

function money(v){const n=Number(v);return Number.isFinite(n)&&n>0?n.toLocaleString("de-DE",{style:"currency",currency:"EUR"}):"–";}
function currentPriceFor(x){
 const direct=Number(x.current_price); if(Number.isFinite(direct)&&direct>0)return direct;
 const hit=prices.find(p=>(x.barcode&&p.ean===x.barcode)||p.product_name?.toLowerCase()===String(x.name||"").toLowerCase());
 return hit?Number(hit.price)||0:0;
}
function inventoryValue(){return items.reduce((s,x)=>s+(Number(x.qty)||0)*currentPriceFor(x),0);}
function lowItems(){return items.filter(x=>Number(x.min_qty)>0&&Number(x.qty)<Number(x.min_qty));}
async function addLowStockToShopping(){
  const low=lowItems();
  if(!low.length){flash("Aktuell liegt kein Artikel unter dem Mindestbestand.","ok");return;}
  let added=0,updated=0;
  for(const x of low){
    const needed=Math.max(0,Number(x.min_qty||0)-Number(x.qty||0));
    if(!needed) continue;
    const existing=shopping.find(s=>!s.checked&&String(s.name||'').trim().toLowerCase()===String(x.name||'').trim().toLowerCase());
    if(existing){
      const {error}=await db.from('shopping_items').update({qty:Number(existing.qty||0)+needed,unit:x.unit||existing.unit||'Stk.'}).eq('id',existing.id);
      if(!error) updated++;
    }else{
      const {error}=await db.from('shopping_items').insert({household_id:household.id,user_id:user.id,name:x.name,qty:needed,unit:x.unit||'Stk.',unit_price:currentPriceFor(x)||null});
      if(!error) added++;
    }
  }
  await loadData();renderApp();
  flash(`${added} Artikel ergänzt${updated?` · ${updated} vorhandene Mengen erhöht`:''}.`,"ok");
}

function soonItems(){return items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d>=0&&d<=7}).sort((a,b)=>daysTo(a.mhd)-daysTo(b.mhd));}
function compassMetrics(){
 const n=items.length;
 const low=lowItems().length, soon=soonItems().length;
 const priced=items.filter(x=>currentPriceFor(x)>0).length;
 const cats=new Set(items.map(x=>String(x.category||"").trim().toLowerCase()).filter(Boolean)).size;
 if(!n) return {n,low,soon,priced,cats,coverage:0,diversity:0,priceBonus:0,penalties:0,score:0};
 const coverage=70*(1-Math.exp(-n/60));
 const diversity=20*(1-Math.exp(-cats/8));
 const priceBonus=10*(priced/n);
 const penalties=(low/n)*25+(soon/n)*20;
 const score=Math.max(0,Math.min(100,Math.round(coverage+diversity+priceBonus-penalties)));
 return {n,low,soon,priced,cats,coverage,diversity,priceBonus,penalties,score};
}
function compassScore(){ return compassMetrics().score; }
function openCompass(){
 const m=compassMetrics();
 const modal=document.getElementById("modal")||document.body.appendChild(Object.assign(document.createElement("div"),{id:"modal"}));
 const status=m.score>=80?'Sehr gut':m.score>=60?'Gut':m.score>=40?'Ausbaufähig':m.score>=20?'Noch Luft nach oben':'Aufbau starten';
 const tips=[];
 if(m.n<10) tips.push('Mehr unterschiedliche Vorratsartikel anlegen – der Kompass bewertet echte Vorratsbreite.');
 if(m.cats<4) tips.push('Mehrere Kategorien abdecken, damit der Vorrat nicht nur aus einer Produktgruppe besteht.');
 if(m.low) tips.push(`${m.low} ${m.low===1?'Artikel liegt':'Artikel liegen'} unter dem hinterlegten Mindestbestand.`);
 if(m.soon) tips.push(`${m.soon} ${m.soon===1?'Artikel':'Artikel'} hat ein MHD innerhalb der nächsten 7 Tage.`);
 if(m.priced<m.n) tips.push('Bei mehr Artikeln Preise hinterlegen, wenn der Bestandswert mitbewertet werden soll.');
 if(!tips.length) tips.push('Der Vorrat ist breit aufgestellt und aktuell gut gepflegt.');
 modal.innerHTML=`<div class="modal"><section class="card compass-modal-card">
 <div class="dash-head"><div><span class="dash-kicker">VORRATSKOMPASS</span><h2 style="margin:4px 0 0">🧭 Warum ${m.score}/100?</h2></div><button class="secondary" onclick="closeCompass()">✕</button></div>
 <div class="compass-modal-score"><div class="compass-ring"><b>${m.score}</b><small>/100</small></div><div><strong>${status}</strong><p>Der Kompass ist eine interne Orientierung für die Qualität eures erfassten Vorrats – <b>kein offizieller BBK-Notfallscore</b>.</p></div></div>
 <div class="compass-breakdown">
  <div><span>📦 Vorratsbreite</span><b>+${Math.round(m.coverage)}/70</b><small>${m.n} Artikel erfasst</small></div>
  <div><span>🗂 Kategorien</span><b>+${Math.round(m.diversity)}/20</b><small>${m.cats} Kategorien vertreten</small></div>
  <div><span>💶 Pflege/Preise</span><b>+${Math.round(m.priceBonus)}/10</b><small>${m.priced} von ${m.n} mit Preis</small></div>
  <div class="negative"><span>⚠️ Abzüge</span><b>−${Math.round(m.penalties)}</b><small>${m.low} unter Mindestbestand · ${m.soon} bald fällig</small></div>
 </div>
 <div class="compass-tips"><h3>Was bringt euch nach oben?</h3>${tips.map((t,i)=>`<div><i>${i+1}</i><span>${esc(t)}</span></div>`).join('')}</div>
 <div class="compass-modal-actions"><button onclick="closeCompass();goTab('vorrat')">▣ Vorrat öffnen</button><button class="secondary" onclick="closeCompass()">Verstanden</button></div>
 </section></div>`;
}
function closeCompass(){const m=document.getElementById('modal');if(m)m.innerHTML='';}
function shoppingEstimate(){return shopping.filter(x=>!x.checked).reduce((s,x)=>s+(Number(x.qty)||1)*(Number(x.unit_price)||0),0);}
function rescueRecipeData(){
 try{
  if(typeof findRecipeMatches!=='function' || typeof normRecipeText!=='function') return [];
  const urgent=soonItems().filter(x=>Number(x.qty||0)>0); if(!urgent.length)return [];
  const names=urgent.map(x=>normRecipeText(x.name||''));
  return findRecipeMatches().map((r,idx)=>{
   const urgentCount=(r.reqs||[]).filter(req=>names.some(n=>{const q=normRecipeText(req);return n.includes(q)||q.includes(n)})).length;
   return {...r,id:idx,urgentCount};
  }).filter(r=>r.urgentCount>0).sort((a,b)=>b.urgentCount-a.urgentCount||b.pct-a.pct||a.missing.length-b.missing.length);
 }catch(e){return []}
}
function smartCookRecipes(limit=3){
 try{
  const matches=findRecipeMatches();
  const urgentNames=soonItems().map(x=>normRecipeText(x.name||''));
  return matches.map(r=>{
   const urgentCount=(r.reqs||[]).filter(req=>urgentNames.some(n=>{const q=normRecipeText(req);return n.includes(q)||q.includes(n)})).length;
   const score=(r.missing.length===0?100:Math.max(0,70-r.missing.length*12))+r.pct*.25+urgentCount*18;
   return {...r,urgentCount,smartScore:score};
  }).sort((a,b)=>b.smartScore-a.smartScore||b.pct-a.pct).slice(0,limit);
 }catch(e){return []}
}
async function addRecipeMissingToShopping(recipeName){
 const r=findRecipeMatches().find(x=>x.n===recipeName); if(!r||!r.missing?.length){flash('Dieses Rezept ist bereits vollständig im Vorrat.');return;}
 let added=0;
 for(const name of r.missing){
  const existing=shopping.find(x=>!x.checked&&normRecipeText(x.name)===normRecipeText(name));
  if(existing){await db.from('shopping_items').update({qty:(Number(existing.qty)||1)+1}).eq('id',existing.id);}
  else{const {error}=await db.from('shopping_items').insert({household_id:household.id,user_id:user.id,name,qty:1,unit:'Stk.',unit_price:null});if(!error)added++;}
 }
 await loadData(); renderApp(); flash(`🛒 ${added||r.missing.length} fehlende Rezept-Zutat${r.missing.length===1?'':'en'} zum Einkauf ergänzt.`);
}
async function applySmartShopping(recipeName){
 const low=lowItems();
 for(const x of low){
  const need=Math.max(0,Number(x.min_qty||0)-Number(x.qty||0)); if(!need)continue;
  const existing=shopping.find(y=>!y.checked&&normRecipeText(y.name)===normRecipeText(x.name));
  if(existing) await db.from('shopping_items').update({qty:(Number(existing.qty)||1)+need}).eq('id',existing.id);
  else await db.from('shopping_items').insert({household_id:household.id,user_id:user.id,name:x.name,qty:need,unit:x.unit||'Stk.',unit_price:Number(x.price)||null});
 }
 if(recipeName){
  const r=findRecipeMatches().find(x=>x.n===recipeName);
  for(const name of (r?.missing||[])){
   const existing=shopping.find(x=>!x.checked&&normRecipeText(x.name)===normRecipeText(name));
   if(existing) await db.from('shopping_items').update({qty:(Number(existing.qty)||1)+1}).eq('id',existing.id);
   else await db.from('shopping_items').insert({household_id:household.id,user_id:user.id,name,qty:1,unit:'Stk.',unit_price:null});
  }
 }
 await loadData(); renderApp(); flash('🛒 Einkauf wurde intelligent vorbereitet.');
}
function openSmartShopping(){
 const low=lowItems(); const cook=smartCookRecipes(1)[0]; const missing=cook?.missing||[];
 const unique=[...new Set([...low.map(x=>x.name),...missing])];
 const modal=document.getElementById('modal')||document.body.appendChild(Object.assign(document.createElement('div'),{id:'modal'}));
 modal.innerHTML=`<div class="modal"><section class="card smart-shop-modal"><div class="dash-head"><div><span class="dash-kicker">EINKAUF-ASSISTENT</span><h2>🧠 Einkauf vorbereiten</h2></div><button class="secondary" onclick="document.getElementById('modal').innerHTML=''">✕</button></div>
 <p class="muted">Die App bündelt automatisch Dinge, die gerade wirklich sinnvoll sind.</p>
 ${low.length?`<div class="smart-shop-group"><h3>🟠 Mindestbestand</h3>${low.slice(0,8).map(x=>`<div class="smart-shop-row"><span>${esc(x.name)}</span><b>${Math.max(0,Number(x.min_qty||0)-Number(x.qty||0))} ${esc(x.unit||'Stk.')}</b></div>`).join('')}</div>`:''}
 ${cook?.missing?.length?`<div class="smart-shop-group"><h3>🍳 Passend zum Vorrat: ${esc(cook.n)}</h3>${cook.missing.slice(0,8).map(x=>`<div class="smart-shop-row"><span>${esc(x)}</span><b>1 Stk.</b></div>`).join('')}</div>`:''}
 ${!unique.length?`<div class="uv-empty">Aktuell gibt es keine sinnvollen Ergänzungen. 🎉</div>`:''}
 <div class="compass-modal-actions"><button onclick="applySmartShopping(${cook?.missing?.length?JSON.stringify(cook.n):'null'});document.getElementById('modal').innerHTML=''">🛒 Alles in Einkauf übernehmen</button><button class="secondary" onclick="document.getElementById('modal').innerHTML=''">Schließen</button></div>
 </section></div>`;
}

function recipeSearchTermForItem(item){
 const name=String(item?.name||'').trim(), n=typeof normRecipeText==='function'?normRecipeText(name):name.toLowerCase();
 const kws=Object.values(categoryKeywords||{}).flat();
 const hit=kws.find(k=>{const q=typeof normRecipeText==='function'?normRecipeText(k):String(k).toLowerCase();return q.length>=4&&n.includes(q)});
 return hit||name.split(/\s+/)[0]||name;
}
function openRescueRecipes(){
 const urgent=soonItems().find(x=>Number(x.qty||0)>0); activeTab='rezepte'; renderApp();
 setTimeout(()=>{const term=recipeSearchTermForItem(urgent),inp=document.getElementById('recipeSearch');if(inp&&term){inp.value=term;recipeLiveSearch(term);}},50);
}
function openRescueRecipe(id){
 const r=rescueRecipeData().find(x=>x.id===id)||rescueRecipeData()[0]; if(!r)return openRescueRecipes();
 const urgent=soonItems().find(x=>Number(x.qty||0)>0&&(r.reqs||[]).some(req=>{const q=normRecipeText(req),n=normRecipeText(x.name||'');return n.includes(q)||q.includes(n)}));
 activeTab='rezepte';renderApp();
 setTimeout(()=>{const term=recipeSearchTermForItem(urgent),inp=document.getElementById('recipeSearch');if(inp&&term){inp.value=term;recipeLiveSearch(term);}},50);
}

function dashboardView(){
 const low=lowItems(),soon=soonItems(),open=shopping.filter(x=>!x.checked),score=compassScore(),value=inventoryValue();
 const urgent=[...soon].sort((a,b)=>daysTo(a.mhd)-daysTo(b.mhd));
 const rescue=rescueRecipeData();
 const status=soon.length||low.length?'attention':'ok';
 const statusLabel=status==='ok'?'Alles ruhig':'Aufmerksamkeit erforderlich';
 const statusIcon=status==='ok'?'🟢':'🟡';
 const rec=[];
 if(soon.length) rec.push({icon:'🔴',text:`${soon.length} ${soon.length===1?'Artikel':'Artikel'} zuerst verbrauchen`,action:`quickGo('0')`,label:'Ansehen'});
 if(low.length) rec.push({icon:'🟠',text:`${low.length} ${low.length===1?'Artikel':'Artikel'} unter Mindestbestand`,action:`window._status='low';goTab('vorrat')`,label:'Prüfen'});
 if(open.length) rec.push({icon:'🛒',text:`${open.length} offene Einkaufsposition${open.length===1?'':'en'}`,action:`goTab('einkauf')`,label:'Einkauf'});
 if(!items.length) rec.push({icon:'➕',text:'Noch kein Vorrat erfasst',action:`openItem()`,label:'Artikel anlegen'});
 if(!rec.length) rec.push({icon:'✨',text:'Aktuell keine dringende Baustelle',action:`goTab('vorrat')`,label:'Vorrat öffnen'});
 return `<main class="uv-content dashboard-page">
 <section class="dash-welcome"><div><span class="dash-kicker">HAUSHALTS-ZENTRALE</span><h1>Alles im Blick.</h1><p>Vorrat, Einkauf, Rezepte und Vorsorge – kompakt an einem Ort.</p></div><button class="compass" onclick="openCompass()" aria-label="Vorratskompass erklären"><div class="compass-ring"><b>${score}</b><small>/100</small></div><span>Vorratskompass · Warum?</span></button></section>
 <section class="house-status ${status}"><div class="house-status-main"><span class="house-status-icon">${statusIcon}</span><div><small>HAUSHALTSSTATUS</small><b>${statusLabel}</b></div></div><span class="house-status-detail">${soon.length+low.length} offene Priorität${soon.length+low.length===1?'':'en'}</span></section>
 <section class="dash-grid">
 <button class="dash-card" onclick="goTab('vorrat')"><b>${items.length}</b><span>Artikel im Vorrat</span><em>▣</em></button>
 <button class="dash-card danger-card" onclick="quickGo('0')"><b>${soon.length}</b><span>Bald ablaufend</span><em>🔴</em></button>
 <button class="dash-card warn-card" onclick="window._status='low';goTab('vorrat')"><b>${low.length}</b><span>Mindestbestand</span><em>🟠</em></button>
 <button class="dash-card price-card" onclick="goTab('preise')"><b>${money(value)}</b><span>Bestandswert</span><em>€</em></button></section>
 <section class="dash-panel priority-panel"><div class="dash-head"><div><span class="dash-kicker">SMARTER HAUSHALT</span><h3>🧠 Was ist jetzt wichtig?</h3></div></div>${rec.map(x=>`<div class="priority-row"><span class="priority-icon">${x.icon}</span><div><b>${x.text}</b></div><button class="secondary" onclick="${x.action}">${x.label} ›</button></div>`).join("")}</section>
 ${prepGapAnalysis().length?`<section class="dash-panel prep-gap-mini"><div class="dash-head"><div><h3>🛡 Vorsorge-Lücken</h3><small class="muted">Automatisch aus eurem Bestand erkannt.</small></div><button class="secondary" onclick="goTab('vorsorge')">Prüfen ›</button></div><div class="prep-gap-mini-list">${prepGapAnalysis().slice(0,4).map(g=>`<span>${g.icon} ${esc(g.title)}${g.qty?` · ${g.qty.toLocaleString('de-DE')} ${esc(g.unit)}`:' · prüfen'}</span>`).join('')}</div></section>`:``}
 ${urgent.length?`<section class="dash-panel consume-panel"><div class="dash-head"><div><h3>🍅 Zuerst verbrauchen</h3><small class="muted">Lebensmittel mit dem nächsten MHD zuerst nutzen.</small></div><button class="secondary" onclick="quickGo('0')">Alle ›</button></div><div class="consume-list">${urgent.slice(0,5).map(x=>{const d=daysTo(x.mhd);const label=d===0?'heute':d===1?'morgen':`in ${d} Tagen`;return `<button class="consume-row" onclick="openItem(${x.id})"><span class="consume-day">${d===0?'HEUTE':d===1?'MORGEN':label.toUpperCase()}</span><b>${esc(x.name)}</b><span>›</span></button>`}).join('')}</div></section>`:''}
 ${rescue.length?`<section class="dash-panel rescue-panel"><div class="dash-head"><div><h3>🍳 MHD-Retter</h3><small class="muted">Gerichte, mit denen ihr bald fällige Zutaten verbrauchen könnt.</small></div><button class="secondary" onclick="openRescueRecipes()">Mehr ›</button></div><div class="rescue-grid">${rescue.slice(0,3).map(r=>`<button class="rescue-card" onclick="openRescueRecipe(${r.id})"><span class="rescue-badge">${r.urgentCount} × MHD</span><b>${esc(r.n)}</b><small>${r.missing.length?`${r.missing.length} Zutaten fehlen`:'✓ Alles vorhanden'}</small></button>`).join('')}</div></section>`:''}
 ${smartCookRecipes(3).length?`<section class="dash-panel cook-panel"><div class="dash-head"><div><h3>🍳 Was könnt ihr heute kochen?</h3><small class="muted">Vorrat + MHD bestimmen die Reihenfolge.</small></div><button class="secondary" onclick="goTab('rezepte')">Alle ›</button></div><div class="cook-grid">${smartCookRecipes(3).map(r=>`<button class="cook-card" onclick="goTab('rezepte')"><b>${esc(r.n)}</b><span>${r.missing.length?`🛒 ${r.missing.length} fehlen`:'✓ alles vorhanden'}${r.urgentCount?` · 🔴 ${r.urgentCount} MHD`:''}</span></button>`).join('')}</div></section>`:''}
 <section class="dash-panel"><div class="dash-head"><h3>🛒 Einkauf</h3><div class="dash-head-actions"><button class="secondary" onclick="openSmartShopping()">🧠 Vorbereiten</button><button onclick="goTab('einkauf')">Öffnen ›</button></div></div><div class="dash-big">${open.length}<small>offene Positionen</small></div><p>Geschätzt <b>${money(shoppingEstimate())}</b></p></section>
 <section class="dash-actions"><button onclick="goTab('vorsorge')">🛡 Vorsorge komplett</button><button onclick="goTab('rezepte')">🍳 Aus Bestand kochen</button><button onclick="openItem()">＋ Artikel</button></section>
 ${low.length?`<section class="dash-panel low-stock-panel"><div class="dash-head"><h3>⚠️ Unter Mindestbestand</h3><button class="secondary" onclick="addLowStockToShopping()">🛒 Einkauf ergänzen</button></div><p class="muted">${low.length} ${low.length===1?'Artikel liegt':'Artikel liegen'} unter eurem Mindestbestand. Die fehlende Menge wird automatisch berechnet.</p><div class="low-stock-chips">${low.slice(0,8).map(x=>`<span>${esc(x.name)} · ${Math.max(0,Number(x.min_qty||0)-Number(x.qty||0))} ${esc(x.unit||'Stk.')}</span>`).join('')}${low.length>8?`<span>+${low.length-8} weitere</span>`:''}</div></section>`:''}
 </main>`;
}
function parsePackageSize(text){
  const raw=String(text||'').trim().toLowerCase().replace(',', '.');
  if(!raw) return null;
  const m=raw.match(/(\d+(?:\.\d+)?)\s*(kg|g|mg|l|ml|cl|stück|stk\.?|rollen?|packungen?|pack|beutel|dosen?|gläser?|flaschen?|kartons?|schachteln?|becher|tuben?|portionen?|bund|meter|paar|tabletten?)/i);
  if(!m)return null;
  let q=Number(m[1]),u=m[2].toLowerCase().replace(/[.]/g,'');
  const map={kg:['g',1000],g:['g',1],mg:['g',0.001],l:['ml',1000],ml:['ml',1],cl:['ml',10],stück:['Stk.',1],stk:['Stk.',1],rollen:['Rolle',1],rolle:['Rolle',1],packungen:['Packung',1],packung:['Packung',1],pack:['Pack',1],beutel:['Beutel',1],dosen:['Dose',1],dose:['Dose',1],gläser:['Glas',1],glas:['Glas',1],flaschen:['Flasche',1],flasche:['Flasche',1],kartons:['Karton',1],karton:['Karton',1],schachteln:['Schachtel',1],schachtel:['Schachtel',1],becher:['Becher',1],tuben:['Tube',1],tube:['Tube',1],portionen:['Portion',1],portion:['Portion',1],bund:['Bund',1],meter:['Meter',1],paar:['Paar',1],tabletten:['Tablette',1],tablette:['Tablette',1]};
  const hit=map[u]; if(!hit)return null;
  return {quantity:q*hit[1],unit:hit[0]};
}
function normalizedPrice(price,quantity,unit){
  const p=Number(price)||0,q=Number(quantity)||0;if(!p||!q)return null;
  if(unit==='g')return {value:p/q*1000,label:'€/kg'};
  if(unit==='ml')return {value:p/q*1000,label:'€/l'};
  return {value:p/q,label:'€/'+unit};
}
function priceMatches(x,p){
  const key=normalizeProductKey(x?.name,x?.brand,x?.variant);
  return (x?.barcode&&p.ean===x.barcode) || (key&&p.product_key===key) || (p.product_name?.toLowerCase()===String(x?.name||'').toLowerCase() && (!x?.variant || !p.variant || p.variant.toLowerCase()===String(x.variant).toLowerCase()));
}
function pricesView(){
 const valued=items.filter(x=>currentPriceFor(x)>0);
 return `<main class="uv-content prices-page"><section class="section-hero"><span class="dash-kicker">PREISE & EINKAUF</span><h2>💰 Preise im Griff</h2><p class="muted">Nicht nur Packungspreise: Wir vergleichen auch automatisch pro kg, Liter, Stück oder Rolle.</p></section>
 <section class="price-summary"><div><b>${money(inventoryValue())}</b><span>Vorratswert</span></div><div><b>${money(shoppingEstimate())}</b><span>Einkauf geschätzt</span></div><div><b>${valued.length}</b><span>bewertet</span></div></section>
 <section class="dash-panel"><div class="dash-head"><h3>Artikelpreise</h3><button onclick="openPriceEntry()">＋ Preis</button></div>${items.map(priceItemHtml).join("")||'<div class="uv-empty">Noch keine Artikel.</div>'}</section>
 <section class="dash-panel"><div class="dash-head"><h3>Preisverlauf & Vergleich</h3></div>${prices.length?prices.slice(0,40).map(p=>{const np=normalizedPrice(p.price,p.quantity,p.quantity_unit);return `<div class="history-row"><span><b>${esc(p.product_name||p.ean||"Produkt")}</b><small>${[p.variant,p.source].filter(Boolean).join(' · ')}</small></span><b>${money(p.price)}${np?`<small>${money(np.value)} ${np.label}</small>`:''}</b><small>${p.recorded_at?new Date(p.recorded_at).toLocaleDateString("de-DE"):""}</small></div>`}).join(""):'<div class="uv-empty">Noch kein Preisverlauf.</div>'}</section>
 <section class="dash-panel"><div class="dash-head"><h3>🛒 Einkaufsbudget</h3><button onclick="setBudget()">Budget setzen</button></div><div class="budget-line"><b>${money(Number(localStorage.getItem("uv_budget_"+household.id)||0))}</b><span>aktuelles Budget</span></div></section></main>`;
}
function priceItemHtml(x){
 const hist=prices.filter(p=>priceMatches(x,p));
 const avg=hist.length?hist.reduce((s,p)=>s+Number(p.price||0),0)/hist.length:0,min=hist.length?Math.min(...hist.map(p=>Number(p.price)||Infinity)):0,latest=hist[0]?.price;
 const normalized=hist.filter(p=>p.normalized_unit_price>0);
 const normAvg=normalized.length?normalized.reduce((s,p)=>s+Number(p.normalized_unit_price||0),0)/normalized.length:0;
 const normMin=normalized.length?Math.min(...normalized.map(p=>Number(p.normalized_unit_price)||Infinity)):0;
 const unusual=latest&&avg&&latest>avg*1.2;
 return `<div class="price-item"><div><b>${esc(x.name)}</b><small>${[x.brand,x.package_size,x.variant].filter(Boolean).join(' · ')||'Ohne Variante'} · ${hist.length} Aufzeichnungen${unusual?" · 🔥 ungewöhnlich hoch":""}</small></div><div class="price-numbers"><b>${currentPriceFor(x)?money(currentPriceFor(x)):"kein Preis"}</b><small>${avg?`Ø ${money(avg)} · günstig ${money(min)}`:""}${normAvg?`<br>📏 Ø ${money(normAvg)} · günstig ${money(normMin)} pro Einheit`:''}</small></div><button class="secondary" onclick="openPriceEntry(${x.id})">✎</button></div>`;
}
async function openPriceEntry(itemId=null){
 const x=itemId?items.find(i=>i.id===itemId):null, modal=document.getElementById("modal")||document.body.appendChild(Object.assign(document.createElement("div"),{id:"modal"}));
 const old=prices.find(p=>x&&priceMatches(x,p));
 const pack=x?.package_size||'';
 modal.innerHTML=`<div class="modal"><section class="card"><h2>💰 Preis speichern</h2><label>Artikel</label><input id="priceName" value="${esc(x?.name||"")}"><label>Marke / Variante</label><input id="priceVariant" value="${esc([x?.brand,x?.variant].filter(Boolean).join(' · '))}" placeholder="z. B. Coca-Cola · Zero"><label>EAN</label><input id="priceEan" value="${esc(x?.barcode||"")}" inputmode="numeric"><label>Packungsinhalt</label><input id="pricePack" value="${esc(pack)}" placeholder="z. B. 500 g, 1,5 l, 6 Rollen"><label>Preis in €</label><input id="priceValue" type="number" min="0" step="0.01" value="${esc(x?.current_price??old?.price??"")}" oninput="previewNormalizedPrice()"><div id="priceNormalized" class="editor-suggestion"></div><label>Quelle / Händler</label><input id="priceSource" placeholder="z. B. Lidl, REWE, Amazon"><div class="row" style="margin-top:16px"><button onclick="savePrice(${itemId||"null"})">💾 Speichern</button><button class="secondary" onclick="document.getElementById('modal').innerHTML=''">Abbrechen</button></div></section></div>`;
 previewNormalizedPrice();
}
function previewNormalizedPrice(){
 const box=document.getElementById('priceNormalized'),pack=document.getElementById('pricePack')?.value,price=Number(document.getElementById('priceValue')?.value||0),parsed=parsePackageSize(pack),np=parsed&&price?normalizedPrice(price,parsed.quantity,parsed.unit):null;
 if(box)box.innerHTML=np?`📏 Vergleichspreis: <b>${money(np.value)} ${np.label}</b>`:'<span class="muted">Packungsgröße wird für den Vergleich benötigt.</span>';
}
async function savePrice(itemId=null){
 const name=document.getElementById("priceName").value.trim(),ean=document.getElementById("priceEan").value.trim()||null,price=Number(document.getElementById("priceValue").value),source=document.getElementById("priceSource").value.trim()||null,pack=document.getElementById('pricePack')?.value.trim()||null;
 const x=itemId?items.find(i=>i.id===itemId):null;
 if(!name||!Number.isFinite(price)||price<0)return alert("Bitte Artikel und gültigen Preis eingeben.");
 const variantText=document.getElementById('priceVariant')?.value.trim()||null;
 const variant=variantText?.includes(' · ')?variantText.split(' · ').slice(1).join(' · '):variantText;
 const brand=variantText?.includes(' · ')?variantText.split(' · ')[0]:x?.brand||null;
 const parsed=parsePackageSize(pack),np=parsed?normalizedPrice(price,parsed.quantity,parsed.unit):null;
 const payload={household_id:household.id,user_id:user.id,ean,product_name:name,price,source,brand,variant:variant||x?.variant||null,product_key:normalizeProductKey(name,brand||x?.brand,variant||x?.variant),quantity:parsed?.quantity||null,quantity_unit:parsed?.unit||null,normalized_unit_price:np?.value||null,normalized_unit:np?.label||null};
 const {error}=await db.from("product_prices").insert(payload);
 if(error)return alert(error.message+"\n\nBitte zuerst migration_preisvergleich.sql in Supabase ausführen.");
 if(itemId)await db.from("inventory_items").update({current_price:price}).eq("id",itemId);
 document.getElementById("modal").innerHTML="";await loadData();renderApp();
}
function setBudget(){const cur=Number(localStorage.getItem("uv_budget_"+household.id)||0),v=prompt("Einkaufsbudget in €",cur||"");if(v!==null){localStorage.setItem("uv_budget_"+household.id,String(Math.max(0,Number(v)||0)));renderApp();}}
function prepStoreKey(){return "uv_bbkpref_"+(household?.id||"local")}
function householdProfileKey(){return "uv_household_profile_"+(household?.id||"local")}
function prepCalcKey(){return "uv_prepcacl_"+(household?.id||"local")}
function householdProfile(){
 try{
  const x=JSON.parse(localStorage.getItem(householdProfileKey())||"{}");
  return {people:Math.min(50,Math.max(1,Number(x.people)||1)),pets:Math.min(30,Math.max(0,Number(x.pets)||0))};
 }catch(e){return {people:1,pets:0}}
}
function saveHouseholdProfile(){
 const people=Math.min(50,Math.max(1,Number(document.getElementById("profilePeople")?.value)||1));
 const pets=Math.min(30,Math.max(0,Number(document.getElementById("profilePets")?.value)||0));
 localStorage.setItem(householdProfileKey(),JSON.stringify({people,pets}));
 const calc=prepCalc();
 localStorage.setItem(prepCalcKey(),JSON.stringify({people,days:calc.days}));
 flash("Haushaltsprofil gespeichert.","ok");
 renderApp();
}
function prepCalc(){
 try{
  const x=JSON.parse(localStorage.getItem(prepCalcKey())||"{}");
  const profile=householdProfile();
  return {people:Math.min(50,Math.max(1,Number(x.people)||profile.people)),days:[3,5,7,10].includes(Number(x.days))?Number(x.days):10};
 }catch(e){return {people:householdProfile().people,days:10}}
}
function savePrepCalc(){
 const people=Math.min(50,Math.max(1,Number(document.getElementById("prepPeople")?.value)||1));
 const days=[3,5,7,10].includes(Number(document.getElementById("prepDays")?.value))?Number(document.getElementById("prepDays").value):10;
 localStorage.setItem(prepCalcKey(),JSON.stringify({people,days}));
 localStorage.setItem(householdProfileKey(),JSON.stringify({...householdProfile(),people}));
 renderApp();
}
function prepWaterStock(){
  let liters=0,matched=[];
  for(const x of items){
    const name=String(x.name||'').toLowerCase();
    const cat=String(x.category||'').toLowerCase();
    if(!/(wasser|trinkwasser|mineralwasser|quellwasser|tafelwasser)/i.test(name) && !/(wasser)/i.test(cat)) continue;
    const qty=Math.max(0,Number(x.qty)||0);
    if(!qty) continue;
    let per=0;
    const unit=String(x.unit||'').toLowerCase();
    if(unit==='l') per=1;
    else if(unit==='ml') per=0.001;
    else {
      const p=parsePackageSize(x.package_size);
      if(p?.unit==='ml') per=p.quantity/1000;
      else if(p?.unit==='l') per=p.quantity;
    }
    if(per>0){ liters += qty*per; matched.push(x); }
  }
  return {liters,matched};
}
function prepInventoryCoverage(){
  const c=prepCalc(), target=c.people*c.days*2, water=prepWaterStock();
  const missing=Math.max(0,target-water.liters);
  const food=items.filter(x=>{const cat=String(x.category||'').toLowerCase(); return /obst|gemüse|fleisch|wurst|fisch|milch|eier|käse|brot|back|nudel|reis|getreide|hülsen|konserven|tiefkühl|kühlung|frühstück|getränke|süß|snack|gewürz|sauce|aufstrich|backzutat|fertig/.test(cat)});
  const hygiene=items.filter(x=>/papier|wasch|reinigung|spül|müll|haushalt|körperpflege|haarpflege|zahnpflege|toiletten|hygiene|rasur/.test(String(x.category||'').toLowerCase()));
  const light=items.filter(x=>/batter|leucht|licht/.test(String(x.category||'').toLowerCase()) || /(taschenlampe|laterne|batterie|powerbank|radio)/i.test(String(x.name||'')));
  return {target,water,missing,food,hygiene,light};
}
async function addPrepWaterToShopping(missing){
  const qty=Math.max(0,Number(missing)||0); if(qty<0.01)return;
  const existing=shopping.find(x=>!x.checked && /trinkwasser|wasser/i.test(String(x.name||'')) && String(x.unit||'').toLowerCase()==='l');
  if(existing){
    const {error}=await db.from('shopping_items').update({qty:Number(existing.qty||0)+qty}).eq('id',existing.id);
    if(error){flash(error.message);return;}
  }else{
    const {error}=await db.from('shopping_items').insert({household_id:household.id,user_id:user.id,name:'Trinkwasser',qty:Math.round(qty*10)/10,unit:'l',unit_price:null});
    if(error){flash(error.message);return;}
  }
  await loadData(); goTab('einkauf');
}
function prepGapAnalysis(){
 const c=prepCalc(), cov=prepInventoryCoverage(), gaps=[];
 const has=(rx,catRx='')=>items.some(x=>rx.test(String(x.name||'')) || (catRx && catRx.test(String(x.category||''))));
 if(cov.missing>0) gaps.push({id:'water',icon:'💧',title:'Trinkwasser',detail:`${cov.missing.toLocaleString('de-DE',{maximumFractionDigits:1})} L fehlen bis zu eurem gewählten Ziel`,qty:Math.round(cov.missing*10)/10,unit:'l',priority:3,name:'Trinkwasser'});
 const checks=[
  ['toilet','🧻','Toilettenpapier',/toilettenpapier|toiletten\s*papier/i,/papier|toilettenartikel/i],
  ['soap','🧼','Seife / Handhygiene',/seife|handseife|desinfektionsmittel/i,/körperpflege|hygiene/i],
  ['bags','🗑️','Müllbeutel',/müllbeutel|müllsack|abfallsack/i,/müll|entsorgung/i],
  ['light','🔦','Taschenlampe / Notlicht',/taschenlampe|stirnlampe|notlicht|campinglampe/i,/leuchtmittel/i],
  ['battery','🔋','Ersatzbatterien',/batterie|batterien|akkus?/i,/batterien|leuchtmittel/i],
  ['radio','📻','Radio für Warninformationen',/radio|kurbelradio/i,''],
  ['power','🔌','Geladene Powerbank',/powerbank|akku-pack/i,''],
  ['firstaid','🩹','Verbandsmaterial / Erste Hilfe',/verband|pflaster|erste\s*hilfe/i,/gesundheit|erste\s*hilfe/i],
  ['warm','🧣','Warme Decken',/decke|wolldecke|notfalldecke/i,/wärme/i]
 ];
 for(const [id,icon,title,rx,catRx] of checks){ if(!has(rx,catRx)) gaps.push({id,icon,title,detail:'Im erfassten Vorrat nicht eindeutig gefunden',qty:1,unit:'Stk.',priority:2,name:title.replace(' / Erste Hilfe','').replace(' / Notlicht','')}); }
 if(c.pets>0 && !has(/tierfutter|hundefutter|katzenfutter|tierfutter|heu|stroh/i,/tier/i)) gaps.push({id:'petfood',icon:'🐾',title:'Tierfutter',detail:`Für ${c.pets} Haustier${c.pets===1?'':'e'} ist kein passender Vorrat erkannt`,qty:1,unit:'Stk.',priority:3,name:'Tierfutter'});
 const st=prepState();
 const docDone=['Dokumentenmappe_0','Dokumentenmappe_1','Notgepäck_0'].every(k=>st[k]);
 if(!docDone) gaps.push({id:'docs',icon:'📁',title:'Dokumente & Notgepäck',detail:'Mindestens ein Vorsorgepunkt ist noch offen – das lässt sich nicht zuverlässig aus dem Warenbestand erkennen',qty:0,unit:'',priority:2,name:''});
 return gaps.sort((a,b)=>b.priority-a.priority);
}
async function addPrepGapsToShopping(){
 const gaps=prepGapAnalysis().filter(x=>x.qty>0&&x.name);
 if(!gaps.length){flash('Keine direkt einkaufbaren Vorsorge-Lücken gefunden.','ok');return;}
 for(const g of gaps){
  const existing=shopping.find(x=>!x.checked&&String(x.name||'').trim().toLowerCase()===g.name.trim().toLowerCase()&&String(x.unit||'Stk.')===g.unit);
  if(existing){await db.from('shopping_items').update({qty:Number(existing.qty||0)+Number(g.qty||0)}).eq('id',existing.id);}
  else await db.from('shopping_items').insert({household_id:household.id,user_id:user.id,name:g.name,qty:g.qty,unit:g.unit,unit_price:null});
 }
 await loadData(); goTab('einkauf');
}
function prepGapsHtml(){
 const gaps=prepGapAnalysis();
 const critical=gaps.filter(x=>x.priority===3).length;
 return `<section class="prep-gaps-panel ${gaps.length?'has-gaps':'all-good'}">
  <div class="dash-head"><div><span class="dash-kicker">AUTOMATISCHER CHECK</span><h3>🧭 Vorsorge-Lücken</h3><small class="muted">Vorrat + Haushaltsprofil + Vorsorgeplan</small></div>${gaps.some(x=>x.qty>0)?`<button class="secondary" onclick="addPrepGapsToShopping()">🛒 Einkauf ergänzen</button>`:''}</div>
  ${!gaps.length?`<div class="prep-gap-ok">🟢 <b>Aktuell keine offensichtliche Lücke erkannt.</b><span>Das ersetzt keine persönliche Prüfung – besonders Dokumente, Medikamente und individuelle Bedarfe bleiben manuell.</span></div>`:`<div class="prep-gap-summary"><b>${gaps.length} Hinweis${gaps.length===1?'':'e'}</b><span>${critical?`🔴 ${critical} dringend · `:''}der Rest sind empfohlene Basis-Checks</span></div><div class="prep-gap-list">${gaps.slice(0,10).map(g=>`<div class="prep-gap-row"><span class="prep-gap-icon">${g.icon}</span><div><b>${esc(g.title)}</b><small>${esc(g.detail)}</small></div>${g.qty?`<strong>${g.qty.toLocaleString('de-DE')} ${esc(g.unit)}</strong>`:'<em>prüfen</em>'}</div>`).join('')}</div>${gaps.length>10?`<small class="prep-gap-more">+ ${gaps.length-10} weitere Hinweise</small>`:''}`}
  <small class="prep-gap-note">ℹ️ Die App erkennt nur Dinge, die sich aus euren erfassten Artikeln ableiten lassen. Mengen außer Trinkwasser sind bewusst keine pauschalen offiziellen Sollwerte.</small>
 </section>`;
}

function prepCalcHtml(){
 const c=prepCalc(),personDays=c.people*c.days,waterTarget=c.people*c.days*2,coverage=prepInventoryCoverage(),have=coverage.water.liters,missing=coverage.missing;
 const pct=waterTarget?Math.min(100,Math.round(have/waterTarget*100)):0;
 return `<section class="prep-calculator">
   <div class="prep-calc-head"><div><span class="dash-kicker">MENGENRECHNER</span><h3>👨‍👩‍👧‍👦 Euren Bedarf berechnen</h3></div><span class="prep-calc-days">${personDays} Personentage</span></div>
   <p class="muted">Die App rechnet die Mengen automatisch für euren Haushalt und gleicht den berechenbaren Bedarf direkt mit eurem Vorrat ab.</p>
   <div class="prep-calc-fields">
     <label><span>Personen im Haushalt</span><input id="prepPeople" type="number" min="1" max="50" step="1" value="${c.people}" onchange="savePrepCalc()"></label>
     <label><span>Versorgungstage</span><select id="prepDays" onchange="savePrepCalc()"><option value="3" ${c.days===3?'selected':''}>3 Tage – Einstieg</option><option value="5" ${c.days===5?'selected':''}>5 Tage</option><option value="7" ${c.days===7?'selected':''}>7 Tage</option><option value="10" ${c.days===10?'selected':''}>10 Tage – Ziel</option></select></label>
   </div>
   <div class="prep-calc-results">
     <div class="prep-result-water"><span>💧 Trinkwasser</span><b>${waterTarget.toLocaleString('de-DE')} Liter</b><small>${c.people} × ${c.days} × 2 L</small><div class="prep-stockbar"><i style="width:${pct}%"></i></div><small><b>${have.toLocaleString('de-DE',{maximumFractionDigits:1})} L vorhanden</b> · ${missing>0?`<strong>${missing.toLocaleString('de-DE',{maximumFractionDigits:1})} L fehlen</strong>`:'Ziel erreicht 🎉'}</small>${missing>0?`<button type="button" class="prep-buy-btn" onclick="addPrepWaterToShopping(${missing})">🛒 Fehlmenge zur Einkaufsliste</button>`:''}</div>
     <div><span>🥫 Lebensmittel</span><b>${personDays} Personentage</b><small>${coverage.food.length} passende Lebensmittelartikel im Vorrat · Menge individuell</small></div>
     <div><span>🧼 Hygiene</span><b>${coverage.hygiene.length} Artikel</b><small>Bestand erkannt – konkrete Zielmenge hängt vom Haushalt ab.</small></div>
     <div><span>🔦 Licht & Energie</span><b>${coverage.light.length} Artikel</b><small>Batterien, Licht, Radio/Powerbank soweit im Vorrat erkennbar.</small></div>
     <div><span>🐾 Haustiere</span><b>${c.days} Tage je Tier</b><small>Futtermenge nach Tierart und Herstellerangabe</small></div>
   </div>
   <small class="prep-calc-note">ℹ️ Exakt berechenbar ist vor allem Wasser. Lebensmittel, Hygiene und Tierbedarf werden nicht pauschal in Stückzahlen umgerechnet, weil Bedarf und Verbrauch stark vom Haushalt abhängen.</small>
 </section>`;
}
const BBK_PLAN=[
 {cat:"Grundversorgung",icon:"💧",title:"Trinkwasser",text:"Für möglichst 10 Tage vorsorgen. Das BBK nennt 2 Liter Flüssigkeit pro Person und Tag als Richtwert für die Vorsorge.",items:["Trinkwasser für mehrere Tage vorhanden","Wasser auch für Haustiere eingeplant","Wasser so gelagert, dass es im Notfall erreichbar ist"]},
 {cat:"Grundversorgung",icon:"🥫",title:"Lebensmittel",text:"Haltbare Lebensmittel bevorraten, die ihr auch im Alltag esst. Vorrat regelmäßig verbrauchen und wieder auffüllen.",items:["Haltbare Lebensmittel vorhanden","Lebensmittel auch ohne Kühlung teilweise nutzbar","Vorrat wird regelmäßig kontrolliert und erneuert"]},
 {cat:"Grundversorgung",icon:"🧼",title:"Hygiene & Haushalt",text:"Hygieneartikel, Toilettenpapier, Müllbeutel und persönliche Bedarfsartikel für eine Unterbrechung der Versorgung bereithalten.",items:["Toilettenpapier/Hygiene vorhanden","Seife und Reinigungsmittel vorhanden","Persönliche Hygieneartikel vorhanden"]},
 {cat:"Kommunikation",icon:"📻",title:"Information & Warnung",text:"Warnungen müssen auch bei Strom-, Internet- oder Mobilfunkausfall erreichbar sein.",items:["Warn-App NINA eingerichtet","Batterie-/Kurbelradio vorhanden","Wichtige Telefonnummern zusätzlich auf Papier vorhanden","Powerbank geladen"]},
 {cat:"Licht & Energie",icon:"🔦",title:"Stromausfall",text:"Licht, geladene Akkus, Bargeld und eine sichere Möglichkeit zur Information vorbereiten. Grill oder Campingkocher niemals in Innenräumen benutzen.",items:["Taschenlampen/Lampen vorhanden","Ersatzbatterien vorhanden","Powerbanks geladen","Etwas Bargeld vorhanden"]},
 {cat:"Gesundheit",icon:"🩹",title:"Hausapotheke & Erste Hilfe",text:"Hausapotheke und Verbandsmaterial nach eurem persönlichen Bedarf zusammenstellen.",items:["Hausapotheke geprüft","Verbandsmaterial vorhanden","Persönlich benötigte Medikamente vorhanden"]},
 {cat:"Dokumente",icon:"📁",title:"Dokumentenmappe",text:"Wichtige Dokumente griffbereit und zusätzlich gesichert aufbewahren.",items:["Ausweise/Urkunden griffbereit","Versicherungs- und Vertragsunterlagen gesichert","Digitale Sicherung wichtiger Dokumente vorhanden"]},
 {cat:"Wärme",icon:"🧣",title:"Heizungsausfall",text:"Warme Kleidung und Decken bereithalten. Bei alternativen Heizquellen unbedingt die Sicherheitshinweise beachten.",items:["Warme Decken vorhanden","Warme Kleidung vorhanden","Sicherer Aufenthaltsraum festgelegt"]},
 {cat:"Tiere",icon:"🐾",title:"Haustiere",text:"Futter, Wasser und notwendige Tiermedikamente bzw. Zubehör mit einplanen.",items:["Tierfuttervorrat vorhanden","Wasser für Tiere eingeplant","Tiermedikamente/Zubehör geprüft"]},
 {cat:"Evakuierung",icon:"🎒",title:"Notgepäck",text:"Wenn eine Wohnung schnell verlassen werden muss, sollten die wichtigsten Dinge griffbereit sein.",items:["Notgepäck vorbereitet","Dokumente und Medikamente schnell greifbar","Schlüssel, Ladegerät und Taschenlampe dabei"]}
];
const EMERGENCY_SCENARIOS=[
 {icon:"⚡",title:"Stromausfall",steps:["Ruhe bewahren und prüfen, ob nur die eigene Wohnung oder die Umgebung betroffen ist.","Taschenlampe statt offener Flamme bevorzugen; Radio/Powerbank bereithalten.","Kühlschrank und Gefriergerät möglichst geschlossen halten.","Bargeld und wichtige Telefonnummern bereithalten.","Behördliche Informationen über Radio bzw. Warnkanäle verfolgen."]},
 {icon:"🌊",title:"Hochwasser / Starkregen",steps:["Warnungen und Anweisungen der Behörden beachten.","Höher gelegene Bereiche aufsuchen; Keller, Tiefgaragen und Unterführungen meiden.","Nicht durch überflutete Bereiche fahren oder laufen.","Bei Evakuierung Notgepäck mitnehmen und Anweisungen folgen."]},
 {icon:"🔥",title:"Brand / Evakuierung",steps:["Bei akuter Gefahr Gebäude verlassen und 112 rufen.","Keine Aufzüge benutzen, Fluchtwege nutzen.","Nur helfen, wenn es ohne Eigengefährdung möglich ist.","Notgepäck und wichtige Unterlagen griffbereit halten."]},
 {icon:"☣️",title:"Gefahrstoff / Rauchwolke",steps:["Warnmeldung beachten und zunächst Schutz im Gebäude suchen, wenn dies angeordnet wird.","Fenster und Türen schließen; Lüftung/Klimaanlage ausschalten.","Geschützten Innenraum aufsuchen und Radio/Warnkanäle verfolgen.","Gebäude erst nach Entwarnung oder behördlicher Anweisung verlassen."]},
 {icon:"💥",title:"Explosion / akute Gefahrenlage",steps:["Behördliche Warnungen und Anweisungen befolgen.","Abstand zu Fenstern und Glasflächen gewinnen.","Wenn Schutz im Gebäude erforderlich ist: möglichst innenliegender Raum ohne Fenster bzw. Keller aufsuchen.","Dachgeschoss und Bereiche mit viel Glas meiden."]},
 {icon:"📡",title:"Internet / Mobilfunk ausgefallen",steps:["Radio einschalten – besonders Batterie-, Kurbel- oder Autoradio.","Wichtige Kontakte auf Papier nutzen.","Behördliche Anlaufstellen bzw. Notfalltreffpunkte kennen.","Notrufnummern nicht unnötig blockieren; bei Ausfall zu Polizei/Feuerwehr bzw. Krankenhaus gehen, wenn möglich."]}
];
function prepState(){try{return JSON.parse(localStorage.getItem(prepStoreKey())||"{}")}catch(e){return {}}}
function savePrepState(st){localStorage.setItem(prepStoreKey(),JSON.stringify(st))}
function togglePlanItem(key){const st=prepState();st[key]=!st[key];savePrepState(st);renderApp()}
function prepModeKey(){return "uv_prep_mode_"+(household?.id||"local")}
function prepMode(){return localStorage.getItem(prepModeKey())||"plan"}
function setPrepMode(mode){localStorage.setItem(prepModeKey(),mode);renderApp();window.scrollTo({top:0,behavior:"smooth"})}
function preparednessView(){
 const mode=prepMode();
 const st=prepState();
 const total=BBK_PLAN.reduce((n,x)=>n+x.items.length,0),done=BBK_PLAN.reduce((n,x)=>n+x.items.filter((_,i)=>st[x.title+"_"+i]).length,0),pct=total?Math.round(done/total*100):0;
 const dbDone=preparedness.filter(x=>Number(x.current_qty)>=Number(x.target_qty)).length;
 const switcher=`<div class="prep-mode-switch" role="tablist" aria-label="Vorsorge und Notfall">
   <button class="prep-mode-btn ${mode==='plan'?'active plan':''}" onclick="setPrepMode('plan')" role="tab" aria-selected="${mode==='plan'}">🛡 Vorsorgeplan</button>
   <button class="prep-mode-btn ${mode==='emergency'?'active emergency':''}" onclick="setPrepMode('emergency')" role="tab" aria-selected="${mode==='emergency'}">🚨 Notfall</button>
 </div>`;
 if(mode==='emergency') return `<main class="uv-content preparedness-page emergency-page">
   <section class="section-hero emergency-hero"><span class="dash-kicker">NOTFALL · HANDLUNGSHILFEN</span><h2>🚨 Notfallbereich</h2><p class="muted">Hier findest du getrennt vom Vorsorgeplan kurze Handlungshilfen für verschiedene Notlagen. Im akuten Ereignis gelten immer die aktuellen Warnungen und Anweisungen der Behörden.</p></section>
   ${switcher}
   <section class="emergency-intro"><b>Erst Sicherheit, dann handeln.</b><span>Bei unmittelbarer Lebensgefahr: <strong>112</strong>. Warnungen über NINA, Cell Broadcast, Radio und offizielle Stellen beachten.</span></section>
   <div class="emergency-grid emergency-grid-main">${EMERGENCY_SCENARIOS.map((x,i)=>`<details class="emergency-card" ${i===0?'open':''}><summary><span>${x.icon}</span><b>${esc(x.title)}</b><i>⌄</i></summary><div class="emergency-steps">${x.steps.map((step,n)=>`<div><strong>${n+1}</strong><span>${esc(step)}</span></div>`).join("")}</div></details>`).join("")}</div>
   <section class="prep-legal"><b>Wichtig:</b> Diese Übersicht ersetzt keine amtliche Warnung oder Einsatzanweisung. Im Ereignisfall immer die aktuellen Informationen von Behörden und Rettungsdiensten beachten.</section>
 </main>`;
 return `<main class="uv-content preparedness-page">
   <section class="section-hero prep-hero"><span class="dash-kicker">VORSORGE · BBK-ORIENTIERT</span><h2>🛡 Vorsorge-Zentrale</h2><p class="muted">Ein praktischer Vorsorgeplan für euren Haushalt. Der Notfallbereich ist bewusst separat gehalten.</p><div class="prep-progress"><b>${pct}%</b><div><span style="width:${pct}%"></span></div><small>${done} von ${total} Vorsorgepunkten erledigt</small></div></section>
   ${switcher}
   ${prepCalcHtml()}
   ${prepGapsHtml()}
   <section class="prep-source"><b>🇩🇪 Grundlage: BBK</b><span>Grundsätzlich möglichst 10 Tage selbst versorgen können – 3 Tage sind ein sinnvoller Anfang.</span><a href="https://www.bbk.bund.de/DE/Warnung-Vorsorge/Vorsorge/Ratgeber-Checkliste/ratgeber-checkliste_node.html" target="_blank" rel="noopener">Offiziellen BBK-Ratgeber öffnen ↗</a></section>
   <section class="prep-section-head"><div><span class="dash-kicker">DEIN VORSORGEPLAN</span><h3>Schritt für Schritt</h3></div><span class="prep-count">${done}/${total}</span></section>
   <div class="prep-plan-grid">${BBK_PLAN.map(x=>`<section class="prep-plan-card"><div class="prep-plan-title"><span>${x.icon}</span><div><b>${esc(x.title)}</b><small>${esc(x.cat)}</small></div></div><p>${esc(x.text)}</p><div class="prep-checks">${x.items.map((it,i)=>{const k=x.title+"_"+i;return `<label class="prep-check ${st[k]?'done':''}"><input type="checkbox" ${st[k]?'checked':''} onchange="togglePlanItem(${JSON.stringify(k)})"><span>${esc(it)}</span></label>`}).join("")}</div></section>`).join("")}</div>
   <section class="dash-panel"><div class="dash-head"><h3>🧭 Verbindung zum Vorrat</h3></div><p>${compassScore()>=75?"Sehr ordentlich: Euer normaler Vorrat unterstützt die Vorsorge bereits gut.":compassScore()>=45?"Solide Basis: Einige Vorratsartikel können die Vorsorge unterstützen.":"Hier gibt es noch Luft – der normale Vorrat kann den Vorsorgeplan Schritt für Schritt ergänzen."}</p><div class="prep-db-link">${dbDone} von ${preparedness.length} separat erfassten Vorsorgeartikeln erfüllen aktuell ihre Zielmenge.</div></section>
   <section class="prep-legal"><b>Wichtig:</b> Der Vorsorgeplan ist eine praktische Zusammenfassung offizieller Empfehlungen und ersetzt keine aktuellen Warnungen oder Anweisungen von Behörden.</section>
 </main>`;
}
function prepItemHtml(x){const pct=Math.min(100,Math.round(Number(x.current_qty||0)/Math.max(1,Number(x.target_qty||1))*100));return `<div class="prep-item"><div><b>${esc(x.name)}</b><small>${esc(x.current_qty)} / ${esc(x.target_qty)} ${esc(x.unit||"")}</small></div><div class="prep-bar"><span style="width:${pct}%"></span></div><button class="secondary" onclick="editPrep(${x.id})">✎</button></div>`;}
async function addPrep(category){const name=prompt("Was soll in "+category+" ergänzt werden?");if(!name)return;const target=Math.max(1,Number(prompt("Zielmenge",1)||1)),unit=prompt("Einheit","Stk.")||"Stk.";const {error}=await db.from("preparedness_items").insert({household_id:household.id,user_id:user.id,category,name,target_qty:target,current_qty:0,unit,priority:1});if(error)alert(error.message);else{await loadData();renderApp();}}
async function editPrep(id){const x=preparedness.find(p=>p.id===id);if(!x)return;const q=prompt("Aktuelle Menge für "+x.name,x.current_qty);if(q===null)return;const {error}=await db.from("preparedness_items").update({current_qty:Math.max(0,Number(q)||0)}).eq("id",id);if(error)alert(error.message);else{await loadData();renderApp();}}
function inventoryView(){
 const q=window._q||"",cat=window._cat||"",place=window._place||"",status=window._status||"";
 const under3=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d>=0&&d<=3}).length;
 const days47=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d>=4&&d<=7}).length;
 const lowCount=items.filter(x=>Number(x.min_qty)>0&&Number(x.qty||0)<Number(x.min_qty)).length;
 const valued=items.filter(x=>currentPriceFor(x)>0);
 const value=inventoryValue();
 let arr=items.filter(x=>(!cat||x.category===cat)&&(!place||x.place===place)&&(!status||statusMatch(x,status)));
 arr.sort((a,b)=>{let da=daysTo(a.mhd),db=daysTo(b.mhd);if(da===null&&db===null)return String(a.name).localeCompare(String(b.name),'de');if(da===null)return 1;if(db===null)return -1;return da-db});
 const urgent=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d<=7}).sort((a,b)=>daysTo(a.mhd)-daysTo(b.mhd)).slice(0,6);
 const catsList=cats.map(c=>`<option value="${esc(c)}" ${cat===c?'selected':''}>${esc(c)}</option>`).join('');
 const placesList=places.map(p=>`<option value="${esc(p)}" ${place===p?'selected':''}>${esc(p)}</option>`).join('');
 const activeFilters=(cat?1:0)+(place?1:0)+(status?1:0)+(q?1:0);
 return `<main class="uv-content inventory-page" id="uv-results">
   <section class="inventory-head">
     <div><span class="dash-kicker">VORRAT · EURE BESTÄNDE</span><h1>📦 Unser Vorrat</h1><p>Alles, was da ist – schnell finden, verwalten und rechtzeitig verbrauchen.</p></div>
     <div class="inventory-mini"><b>${items.length}</b><span>Artikel</span><small>${cats.length} Kategorien · ${valued.length} bewertet</small></div>
   </section>
   <section class="inventory-stats inventory-stats-compact" aria-label="Vorratsstatus">
     <button class="inv-stat blue" onclick="quickGo('')"><span>📦</span><b>${items.length}</b><small>gesamt</small></button>
     <button class="inv-stat red" onclick="quickGo('0')"><span>⏱</span><b>${under3}</b><small>≤ 3 Tage</small></button>
     <button class="inv-stat orange" onclick="quickGo('4')"><span>◷</span><b>${days47}</b><small>4–7 Tage</small></button>
     <button class="inv-stat yellow" onclick="quickGo('low')"><span>!</span><b>${lowCount}</b><small>unter Minimum</small></button>
   </section>
   <div class="inventory-helper-row"><span>💡 Tippen = filtern</span><span>${cats.length} Kategorien · ${places.length} Lagerorte</span></div>
   <section class="uv-search-area inventory-search-card">
     <div class="uv-search-row"><div class="uv-search"><span>⌕</span><input id="inventorySearch" autocomplete="off" inputmode="search" placeholder="Artikel, Kategorie oder Marke suchen …" value="${esc(q)}" oninput="window._q=this.value;applyInventorySearch(this.value)"></div><button class="uv-scan" type="button" aria-label="Artikel hinzufügen" onclick="openItem()">＋</button></div>
     <div class="uv-filters"><select aria-label="Kategorie" onchange="window._cat=this.value;renderApp()"><option value="">Alle Kategorien</option>${catsList}</select><select aria-label="Lagerort" onchange="window._place=this.value;renderApp()"><option value="">Alle Lagerorte</option>${placesList}</select><select aria-label="Sortierung" onchange="window._status=this.value;renderApp()"><option value="">Alle anzeigen</option><option value="0" ${status==='0'?'selected':''}>⏱ 0–3 Tage</option><option value="4" ${status==='4'?'selected':''}>🕒 4–7 Tage</option><option value="8" ${status==='8'?'selected':''}>📅 8–30 Tage</option><option value="expired" ${status==='expired'?'selected':''}>🔴 Abgelaufen</option><option value="low" ${status==='low'?'selected':''}>⚠️ Unter Mindestbestand</option></select></div>
     ${activeFilters?`<div class="inventory-filter-state"><span>${activeFilters} Filter aktiv</span><button onclick="window._q='';window._cat='';window._place='';window._status='';renderApp()">Zurücksetzen</button></div>`:''}
   </section>
   <section class="uv-urgent">
      <div class="uv-urgent-head"><div class="uv-urgent-art"></div><div><h3>Zuerst verbrauchen</h3><small>${urgent.length?`${urgent.length} Artikel mit nahendem MHD`: 'Alles entspannt – nichts dringend'}</small></div><button onclick="window._status='';renderApp()">Alle anzeigen ›</button></div>
      ${urgent.map(itemHtml).join('')||'<div class="uv-empty compact-empty">✨ Aktuell nichts Dringendes. Der Vorrat ist entspannt.</div>'}
   </section>
   <div class="inventory-section-head"><div><span>BESTAND</span><h2>Alle Artikel <em id="inventoryVisibleCount">${arr.length}</em></h2></div><button class="inventory-add-mini" onclick="openItem()">＋ Neuer Artikel</button></div>
   <section class="uv-all"><div id="inventoryAllItems">${arr.map(itemHtml).join('')||'<div class="uv-empty">Noch keine Artikel vorhanden. Legt euren ersten Artikel an. 📦</div>'}</div><div id="inventorySearchEmpty" class="uv-empty" style="display:none">Keine passenden Artikel gefunden.</div></section>
   <button class="uv-add inventory-add-bottom" onclick="openItem()"><span>＋</span>Artikel hinzufügen <b>›</b></button>
   <section class="inventory-footnote"><span>💡</span><div><b>Profi-Tipp</b><small>Pflegt Mindestbestand und MHD – dann kann die App automatisch warnen und zuerst die richtigen Artikel anzeigen.</small></div></section>
   <div id="modal"></div>
 </main>`;
}
function applyInventorySearch(value=""){
 const q=String(value||"").trim().toLowerCase();
 const terms=q.split(/\s+/).filter(Boolean);
 const nodes=document.querySelectorAll("#uv-results .uv-item");
 let visible=0;
 nodes.forEach(el=>{
   const text=(el.getAttribute("data-search")||"").toLowerCase();
   const ok=!terms.length||terms.every(t=>text.includes(t));
   el.style.display=ok?"":"none";
   if(ok && el.closest(".uv-all")) visible++;
 });
 const count=document.getElementById("inventoryVisibleCount"); if(count) count.textContent=visible;
 const empty=document.getElementById("inventorySearchEmpty"); if(empty) empty.style.display=(q && visible===0)?"block":"none";
}
function statusMatch(x,s){let d=daysTo(x.mhd);if(s==="expired")return d!==null&&d<0;if(s==="0")return d!==null&&d>=0&&d<=3;if(s==="4")return d!==null&&d>=4&&d<=7;if(s==="8")return d!==null&&d>=8&&d<=30;if(s==="low")return Number(x.min_qty)>0&&Number(x.qty||0)<Number(x.min_qty);return true}
function itemHtml(x){
 const d=daysTo(x.mhd); const cls=mhdClass(x.mhd); const daysLabel=d===null?'kein MHD':d<0?'abgelaufen':d===0?'heute':d===1?'noch 1 Tag':`noch ${d} Tage`;
 const tone=d!==null&&d<=3?'red':d!==null&&d<=7?'orange':'blue';
 const low=Number(x.min_qty)>0&&Number(x.qty||0)<Number(x.min_qty);
 const qty=Number(x.qty||0);
 const searchText=[x.name,x.brand,x.package_size,x.variant,x.barcode,x.note,x.category,x.place].filter(Boolean).join(" ").toLowerCase();
 const mhdBadge=x.mhd?`<span class="inv-badge ${tone}">◷ ${new Date(x.mhd+'T00:00:00').toLocaleDateString('de-DE')} · ${daysLabel}</span>`:`<span class="inv-badge neutral">◷ kein MHD</span>`;
 return `<article class="uv-item ${cls} ${low?'below-min':''}" data-search="${esc(searchText)}" onclick="openItem(${x.id})" role="button" tabindex="0" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();openItem(${x.id})}">
   ${x.product_image_url?`<img class="uv-item-img" src="${esc(x.product_image_url)}" alt="" onerror="this.style.display='none'">`:`<div class="uv-item-img uv-no-img">🥫</div>`}
   <div class="uv-item-main"><div class="uv-item-name">${esc(x.name)}</div>${x.brand||x.package_size||x.variant?`<div class="uv-item-product"><b>${esc(x.brand||'')}</b>${x.brand&&x.package_size?' · ':''}${esc(x.package_size||'')}${(x.brand||x.package_size)&&x.variant?' · ':''}${esc(x.variant||'')}</div>`:''}<div class="uv-item-meta"><span>${esc(x.category||'Sonstiges')}</span><i>·</i><span>${esc(x.place||'Vorratsregal')}</span></div><div class="uv-item-badges">${mhdBadge}${low?'<span class="inv-badge low">⚠ unter Minimum</span>':''}${x.pending_mhd?'<span class="inv-badge pending">🟡 neu eingekauft</span>':''}</div></div>
   <div class="uv-item-actions"><div class="uv-stock"><small>Bestand</small><div><button onclick="event.stopPropagation();changeQty(${x.id},-1)" aria-label="Menge verringern">−</button><b>${esc(qty)}</b><button onclick="event.stopPropagation();changeQty(${x.id},1)" aria-label="Menge erhöhen">＋</button></div><em>${esc(x.unit||'Stk.')}</em></div><div class="uv-edit"><button onclick="event.stopPropagation();openItem(${x.id})" aria-label="Artikel bearbeiten">✎</button><button onclick="event.stopPropagation();removeItem(${x.id})" aria-label="Artikel löschen">🗑</button></div></div>
   <span class="uv-item-arrow">›</span>
 </article>`;
}
function shoppingView(){
 const open=shopping.filter(x=>!x.checked),done=shopping.filter(x=>x.checked);
 return `<main class="uv-content"><section class="section-hero shopping-hero"><span class="dash-kicker">EINKAUF</span><h2>🛒 Einkaufsliste</h2><p class="muted">Mengen, Preise und geschätzte Gesamtkosten.</p><div class="shop-total">${money(shoppingEstimate())}<small>geschätzte offene Einkaufssumme</small></div><button class="smart-shopping-hero" onclick="openSmartShopping()">🧠 Einkauf vorbereiten</button></section>
 <section class="shopping-add shop-add-compact"><div class="shop-add-grid"><input id="newShop" class="shop-name-input" placeholder="Was fehlt?" autocomplete="off"><input id="newShopQty" class="shop-qty-input" type="number" min="0.01" step="0.01" value="1" aria-label="Menge"><select id="newShopUnit" class="shop-unit-select" aria-label="Einheit">${units.map(u=>`<option ${u==="Stk."?"selected":""}>${u}</option>`).join("")}</select><button class="shop-add-btn" onclick="addShopping()"><span>＋</span> Hinzufügen</button></div></section>
 <section class="shopping-list"><h3>Offen <em>${open.length}</em></h3>${open.map(shopItemHtml).join("")||'<div class="uv-empty">Einkaufsliste ist leer 🎉</div>'}</section>
 ${done.length?`<section class="shopping-list"><h3>Erledigt <em>${done.length}</em></h3>${done.map(shopItemHtml).join("")}</section>`:""}</main>`;
}
function shopItemHtml(x){const p=Number(x.unit_price)||0;return `<div class="item shop-row"><div class="shop-main"><label><input type="checkbox" class="shop-check" ${x.checked?"checked":""} onchange="toggleShopping(${x.id},this.checked)"> ${x.checked?"<s>":""}<b>${esc(x.name)}</b>${x.checked?"</s>":""}</label><div class="row shop-fields"><input type="number" min="0.01" step="0.01" value="${esc(x.qty??1)}" aria-label="Menge" onchange="updateShoppingQty(${x.id},this.value)"><select aria-label="Einheit" onchange="updateShoppingUnit(${x.id},this.value)">${units.map(u=>`<option ${((x.unit||"Stk.")===u)?"selected":""}>${u}</option>`).join("")}</select><input type="number" min="0" step="0.01" placeholder="Preis/Einheit" value="${p?p:""}" aria-label="Preis pro Einheit" onchange="updateShoppingPrice(${x.id},this.value)"></div></div><b class="shop-line-total">${p?money(p*(Number(x.qty)||1)):"–"}</b><button class="danger shop-delete" onclick="deleteShopping(${x.id})" aria-label="Löschen">🗑</button></div>`;}

function recipeView(){return `<section id="recipeList" class="card" style="margin-top:18px"><h2>🍳 Was kochen wir heute?</h2><p class="muted">Die Vorschläge passen sich eurem aktuellen Vorrat an. Von 🇮🇹 Italienisch über 🇯🇵 Japanisch und 🇰🇷 Koreanisch bis 🇬🇷 Griechisch und mehr.</p><div class="muted">Rezepte werden geladen …</div></section>`}
function renderSmartRecipes(){
 const list=document.getElementById("recipeList");if(!list)return;
 const have=items.map(x=>String(x.name||"").toLowerCase());
 const recipes=[
  ["Reis-Gemüse-Pfanne",["reis","gemüse"],"schnell · Resteverwertung"],
  ["Tomaten-Nudelpfanne",["nudel","tomate"],"einfach · Vorratsklassiker"],
  ["Chili aus dem Vorrat",["bohne","mais","tomate"],"sättigend · haltbar"],
  ["Kartoffel-Ei-Pfanne",["kartoffel","ei"],"günstig · schnell"],
  ["Curry mit Reis",["curry","reis"],"würzig · flexibel"]];
 const scored=recipes.map(r=>({...r,score:r[1].filter(n=>have.some(h=>h.includes(n))).length})).sort((a,b)=>b.score-a.score);
 list.innerHTML=`<section class="recipe-results"><h2>🍳 Was passt zu eurem Vorrat?</h2><p class="muted">Einfache Vorschläge auf Basis eurer Artikelnamen.</p>${scored.map(r=>`<article class="recipe-card"><div><h3>${r[0]}</h3><p>${r[2]}</p></div><b>${r.score}/${r[1].length}</b></article>`).join("")}</section>`;
}
function openDatePicker(el){
  if(!el) return;
  try{
    if(typeof el.showPicker === "function"){ el.showPicker(); return; }
  }catch(e){}
  el.focus();
  try{ el.click(); }catch(e){}
}
let _editorStep=1;
function normalizeProductKey(name,brand,variant){
  return [name,brand,variant].filter(Boolean).join(' ').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim().replace(/\s+/g,'-').slice(0,180);
}
async function findCatalogVariants(){
  const name=document.getElementById('iname')?.value.trim();
  const brand=document.getElementById('ibrand')?.value.trim();
  const variant=document.getElementById('ivariant')?.value.trim();
  const box=document.getElementById('variantHint');
  if(!box||!name)return;
  const key=normalizeProductKey(name,brand,variant);
  try{
    const {data,error}=await db.from('products').select('name,brand,quantity,unit,ean').eq('household_id',household.id).eq('product_key',key).limit(8);
    if(error)throw error;
    if(data?.length){
      box.innerHTML='🔗 <b>Produktfamilie erkannt:</b> '+data.map(x=>[x.quantity,x.unit,x.ean].filter(Boolean).join(' · ')).map(esc).join(' &nbsp;|&nbsp; ');
    }else box.textContent='';
  }catch(e){box.textContent='';}
}
function openItem(id=null){
 let modalHost=document.getElementById("modal");
 if(!modalHost){ modalHost=document.createElement("div"); modalHost.id="modal"; document.body.appendChild(modalHost); }
 editing=id?items.find(x=>x.id===id):null;
 currentProductImage=editing?.product_image_url||null;
 currentProductData=null;
 _editorStep=1;
 const unitList=editing?.unit&&!units.includes(editing.unit)?[editing.unit,...units]:units;
 const firstQty=editing?.qty??1;
 const firstMhd=editing?.mhd||'';
 modalHost.innerHTML=`<div class="modal inventory-modal"><section class="card item-editor">
  <header class="editor-head">
    <div><span class="editor-kicker">${editing?'VORRAT · BEARBEITEN':'VORRAT · NEU'}</span><h2>${editing?'Artikel bearbeiten':'Artikel hinzufügen'}</h2><p>${editing?'Bestand, MHD und Produktdaten sauber verwalten.':'In drei klaren Schritten schnell und sauber erfassen.'}</p></div>
    <button type="button" class="editor-close" aria-label="Schließen" onclick="document.getElementById('modal').innerHTML=''">×</button>
  </header>
  <div class="editor-progress" aria-label="Fortschritt">
    <button type="button" class="editor-step active" data-step="1" onclick="setEditorStep(1)"><span>1</span><b>Produkt</b></button><i></i>
    <button type="button" class="editor-step" data-step="2" onclick="setEditorStep(2)"><span>2</span><b>Bestand</b></button><i></i>
    <button type="button" class="editor-step" data-step="3" onclick="setEditorStep(3)"><span>3</span><b>Extras</b></button>
  </div>
  <div id="mflash" class="hidden"></div>
  <div class="editor-scroll">
    <section class="editor-section editor-step-panel" data-panel="1">
      <div class="section-title"><span>🏷️</span><div><b>Produkt</b><small>Was möchtest du einlagern?</small></div></div>
      <div class="editor-grid">
        <div class="field-wide"><label>Artikelname</label><input id="iname" autocomplete="off" autofocus value="${esc(editing?.name)}" placeholder="z. B. Cola, Reis, Shampoo, Katzenfutter …" oninput="autoSuggestCategory(this.value)"></div>
        <div><label>Marke <span class="optional-label">optional</span></label><input id="ibrand" autocomplete="organization" value="${esc(editing?.brand||'')}" placeholder="z. B. Coca-Cola, Whiskas …"></div>
        <div><label>Packungsgröße <span class="optional-label">optional</span></label><input id="ipack" value="${esc(editing?.package_size||'')}" placeholder="z. B. 1,5 l · 800 g · 6 Rollen" oninput="findCatalogVariants()"></div>
        <div><label>Variante / Sorte <span class="optional-label">optional</span></label><input id="ivariant" autocomplete="off" value="${esc(editing?.variant||'')}" placeholder="z. B. Zero, Classic, Sensitive, XL" oninput="findCatalogVariants()"></div>
        <div id="variantHint" class="editor-suggestion field-wide"></div>
        <div><label>Einheit</label><select id="iunit" aria-label="Einheit"><option value="">Einheit wählen …</option>${unitList.map(u=>`<option value="${esc(u)}" ${editing?.unit===u||( !editing?.unit && u==="Stk.")?"selected":""}>${esc(u)}</option>`).join("")}</select></div>
        <div><label>Kategorie <span class="optional-label">optional</span></label><select id="icat" onchange="window._categoryTouched=true"><option value="">Kategorie wählen …</option>${categoryOptions(editing?.category||"")}</select><small id="categorySuggest" class="editor-suggestion"></small></div>
        <div><label>Lagerort <span class="optional-label">optional</span></label><select id="iplace"><option value="">Lagerort wählen …</option>${places.map(p=>`<option ${editing?.place===p?'selected':''}>${p}</option>`).join("")}</select></div>
      </div>
      <div class="editor-hint">💡 Kategorie und Lagerort kannst du später jederzeit ergänzen. Nichts wird heimlich vorausgewählt.</div>
    </section>

    <section class="editor-section editor-step-panel" data-panel="2" hidden>
      <div class="section-title"><span>📦</span><div><b>Bestand</b><small>Wie viel liegt tatsächlich da?</small></div></div>
      <div id="chargeRows"></div>
      <button type="button" class="secondary add-charge" onclick="addChargeRow()">＋ Weitere Charge / anderes MHD</button>
      <div class="editor-grid compact-grid">
        <div><label>Mindestbestand <span class="optional-label">optional</span></label><input id="imin" type="number" min="0" step="0.01" value="${editing?.min_qty??0}" placeholder="0"></div>
        <div><label>Preis / Einheit (€) <span class="optional-label">optional</span></label><input id="icurrentprice" type="number" min="0" step="0.01" value="${esc(editing?.current_price??'')}" placeholder="z. B. 1,99"></div>
      </div>
      <div class="editor-hint">📅 Kein MHD? Kein Problem. Bei haltbaren Produkten kannst du „kein MHD“ wählen.</div>
    </section>

    <section class="editor-section editor-step-panel" data-panel="3" hidden>
      <div class="section-title"><span>✨</span><div><b>Extras & Prüfung</b><small>Optional – nur was ihr wirklich braucht</small></div></div>
      <div class="product-lookup editor-barcode"><label>EAN / Barcode <span class="optional-label">optional</span></label><input id="ibar" inputmode="numeric" autocomplete="off" value="${esc(editing?.barcode)}" placeholder="Barcode eingeben oder scannen"></div>
      <div class="editor-actions-row"><button type="button" class="secondary" onclick="startBarcodeScanner()">📷 Barcode scannen</button><button type="button" class="secondary" onclick="lookupProductByEAN()">🔎 Produkt suchen</button></div>
      <div id="productLookupResult">${editing?.product_image_url?`<div class="product-preview"><img src="${esc(editing.product_image_url)}" alt="Produktbild"><div class="product-info"><div class="product-name">Gespeichertes Produktbild</div><div class="lookup-status">Produktdaten aus eurer Produktdatenbank.</div></div></div>`:''}</div>

      <div class="extras-divider"></div>
      <div class="section-title compact-title"><span>🖼️</span><div><b>Produktfoto</b><small>Optional</small></div></div>
      <div class="product-photo-actions"><button type="button" class="secondary photo-btn" onclick="openPhotoCamera()">📷 Kamera</button><button type="button" class="secondary photo-btn" onclick="openPhotoGallery()">🖼️ Galerie</button></div>
      <input id="photoCamera" type="file" accept="image/*" capture="environment" style="display:none" onchange="handleProductPhoto(this.files?.[0])">
      <input id="photoGallery" type="file" accept="image/*" style="display:none" onchange="handleProductPhoto(this.files?.[0])">
      <div id="photoPreview">${editing?.product_image_url?`<div class="photo-current"><img src="${esc(editing.product_image_url)}" alt="Aktuelles Produktfoto"><button type="button" class="danger" onclick="removeProductPhoto()">🗑 Foto entfernen</button></div>`:`<div class="photo-empty">Noch kein Foto – optional.</div>`}</div>
      <label class="remember-product"><input id="isaveproduct" type="checkbox" ${editing?.barcode?'checked':''}> <span><b>Produkt für später merken</b><small>EAN, Name, Kategorie, Einheit und Foto für euren Haushalt speichern.</small></span></label>

      <div class="extras-divider"></div>
      <div class="section-title compact-title"><span>📝</span><div><b>Notiz</b><small>Nur wenn ihr etwas ergänzen wollt</small></div></div>
      <textarea id="inote" rows="3" placeholder="z. B. Angebrochen, Lieblingsmarke, Regal 2 …">${esc(editing?.note)}</textarea>
      <div class="editor-review" id="editorReview"></div>
    </section>
  </div>
  <footer class="editor-footer"><button type="button" class="secondary editor-cancel" onclick="document.getElementById('modal').innerHTML=''">Abbrechen</button><button type="button" class="secondary editor-back" onclick="setEditorStep(_editorStep-1)" hidden>← Zurück</button><button type="button" class="editor-next" onclick="nextEditorStep()">Weiter →</button><button type="button" class="editor-save" onclick="saveItem()" hidden>💾 ${editing?'Änderungen speichern':'Artikel speichern'}</button></footer>
 </section></div>`;
 addChargeRow(firstQty,firstMhd);
 setTimeout(()=>document.getElementById('iname')?.focus(),80);
 updateEditorUI();
}
function autoSuggestCategory(name){const sel=document.getElementById("icat"),hint=document.getElementById("categorySuggest");if(!sel||window._categoryTouched)return;const suggestion=suggestCategory(name);if(suggestion){sel.value=suggestion;if(hint)hint.textContent="✨ Kategorie automatisch erkannt – du kannst sie jederzeit ändern.";}else if(hint)hint.textContent="";}

function validateEditorStep(step){
 const flash=document.getElementById('mflash');
 if(flash){flash.className='hidden';flash.textContent='';}
 if(step===1){
   const name=document.getElementById('iname')?.value.trim();
   if(!name){showEditorStepError('Bitte zuerst einen Artikelnamen eingeben.');document.getElementById('iname')?.focus();return false;}
 }
 if(step===2){
   const rows=[...document.querySelectorAll('#chargeRows .charge-row')];
   if(!rows.length){showEditorStepError('Bitte mindestens eine Charge anlegen.');return false;}
   if(rows.some(r=>Number(r.querySelector('.charge-qty')?.value||0)<=0)){showEditorStepError('Die Menge muss größer als 0 sein.');return false;}
 }
 return true;
}
function showEditorStepError(msg){const f=document.getElementById('mflash');if(f){f.className='editor-error';f.textContent='⚠️ '+msg;f.scrollIntoView({block:'nearest'});}}
function nextEditorStep(){if(!validateEditorStep(_editorStep))return;if(_editorStep<3)setEditorStep(_editorStep+1);else saveItem();}
function setEditorStep(step){step=Math.max(1,Math.min(3,Number(step)||1));if(step>_editorStep&&!validateEditorStep(_editorStep))return;_editorStep=step;updateEditorUI();}
function updateEditorUI(){
 document.querySelectorAll('.editor-step-panel').forEach(p=>p.hidden=Number(p.dataset.panel)!==_editorStep);
 document.querySelectorAll('.editor-step').forEach((b,i)=>{const n=i+1;b.classList.toggle('active',n===_editorStep);b.classList.toggle('done',n<_editorStep);});
 const back=document.querySelector('.editor-back'), next=document.querySelector('.editor-next'), save=document.querySelector('.editor-save');
 if(back)back.hidden=_editorStep===1;
 if(next)next.hidden=_editorStep===3;
 if(save)save.hidden=_editorStep!==3;
 const cancel=document.querySelector('.editor-cancel'); if(cancel)cancel.hidden=_editorStep>1;
 if(_editorStep===3){
   const name=document.getElementById('iname')?.value.trim()||'—';
   const unit=document.getElementById('iunit')?.value||'Stk.';
   const brand=document.getElementById('ibrand')?.value.trim()||'';
   const pack=document.getElementById('ipack')?.value.trim()||'';
   const cat=document.getElementById('icat')?.value||'Keine Kategorie';
   const place=document.getElementById('iplace')?.value||'Kein Lagerort';
   const rows=[...document.querySelectorAll('#chargeRows .charge-row')];
   const qty=rows.reduce((a,r)=>a+Number(r.querySelector('.charge-qty')?.value||0),0);
   const unitText=esc(unit);
   const review=document.getElementById('editorReview');
   if(review)review.innerHTML=`<div class="review-title">🔎 Kurz prüfen</div><div class="review-grid"><div><small>Produkt</small><b>${esc(name)}</b>${brand?`<small>${esc(brand)}</small>`:''}${pack?`<small>${esc(pack)}</small>`:''}</div><div><small>Bestand</small><b>${qty||0} ${unitText}</b></div><div><small>Kategorie</small><b>${esc(cat)}</b></div><div><small>Lagerort</small><b>${esc(place)}</b></div></div>`;
 }
 const scroll=document.querySelector('.editor-scroll'); if(scroll)scroll.scrollTop=0;
}
function addChargeRow(qty=1,mhd=''){
 const wrap=document.getElementById('chargeRows'); if(!wrap)return;
 const row=document.createElement('div'); row.className='charge-row';
 const index=wrap.children.length+1;
 row.innerHTML=`<div class="charge-main"><div><label>Menge</label><input class="charge-qty" type="number" min="0.01" step="0.01" value="${esc(qty)}"></div><div><label>MHD</label><div class="date-wrap"><input class="charge-mhd" type="date" value="${esc(mhd)}"><button type="button" class="secondary date-btn" onclick="openDatePicker(this.parentElement.querySelector('.charge-mhd'))">📅</button></div></div></div><div class="charge-quick"><button type="button" class="secondary" onclick="setChargeMhd(this,7)">+7 Tage</button><button type="button" class="secondary" onclick="setChargeMhd(this,30)">+30</button><button type="button" class="secondary" onclick="setChargeMhd(this,90)">+90</button><button type="button" class="secondary" onclick="clearChargeMhd(this)">kein MHD</button></div><button type="button" class="danger charge-remove" aria-label="Charge entfernen" onclick="this.closest('.charge-row').remove();renumberChargeRows()">×</button><small class="charge-label">Charge ${index}</small>`;
 wrap.appendChild(row);
}
function setChargeMhd(btn,days){const input=btn.closest('.charge-row')?.querySelector('.charge-mhd');if(!input)return;const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()+days);input.value=d.toISOString().slice(0,10);}
function clearChargeMhd(btn){const input=btn.closest('.charge-row')?.querySelector('.charge-mhd');if(input)input.value='';}
function renumberChargeRows(){document.querySelectorAll('#chargeRows .charge-row').forEach((row,i)=>{const l=row.querySelector('.charge-label');if(l)l.textContent=`Charge ${i+1}`;});}

function openPhotoCamera(){ document.getElementById('photoCamera')?.click(); }
function openPhotoGallery(){ document.getElementById('photoGallery')?.click(); }
function removeProductPhoto(){ currentProductImage=null; const p=document.getElementById('photoPreview'); if(p)p.innerHTML='<div class="photo-empty">Produktfoto entfernt.</div>'; }
async function handleProductPhoto(file){
  if(!file)return;
  if(!file.type.startsWith('image/')){ alert('Bitte eine Bilddatei auswählen.'); return; }
  try{
    const dataUrl=await compressProductPhoto(file,900,0.78);
    currentProductImage=dataUrl;
    const p=document.getElementById('photoPreview');
    if(p)p.innerHTML=`<div class="photo-current"><img src="${esc(dataUrl)}" alt="Produktfoto"><button type="button" class="danger" onclick="removeProductPhoto()">🗑 Foto entfernen</button></div>`;
  }catch(e){ alert('Das Foto konnte nicht verarbeitet werden.'); }
}
function compressProductPhoto(file,maxSide=900,quality=0.78){
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onerror=()=>reject(reader.error||new Error('Datei konnte nicht gelesen werden'));
    reader.onload=()=>{
      const img=new Image();
      img.onerror=()=>reject(new Error('Bild konnte nicht geöffnet werden'));
      img.onload=()=>{
        const scale=Math.min(1,maxSide/Math.max(img.naturalWidth,img.naturalHeight));
        const canvas=document.createElement('canvas');
        canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));
        canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
        const ctx=canvas.getContext('2d');
        ctx.drawImage(img,0,0,canvas.width,canvas.height);
        resolve(canvas.toDataURL('image/jpeg',quality));
      };
      img.src=reader.result;
    };
    reader.readAsDataURL(file);
  });
}

let barcodeScanner=null;
let barcodeScannerRunning=false;
let barcodeStream=null;
let nativeBarcodeDetector=null;
let nativeScanTimer=null;

function stopCameraStream(){
  if(nativeScanTimer){ clearInterval(nativeScanTimer); nativeScanTimer=null; }
  if(barcodeStream){
    barcodeStream.getTracks().forEach(t=>t.stop());
    barcodeStream=null;
  }
  const video=document.getElementById("barcode-video");
  if(video){ try{video.pause();}catch(e){} video.srcObject=null; }
}

function closeBarcodeScanner(){
  stopCameraStream();
  if(barcodeScanner && barcodeScannerRunning){
    barcodeScanner.stop().catch(()=>{}).finally(()=>{
      try{barcodeScanner.clear()}catch(e){}
      barcodeScanner=null;
      barcodeScannerRunning=false;
    });
  }else{
    try{if(barcodeScanner) barcodeScanner.clear()}catch(e){}
    barcodeScanner=null;
    barcodeScannerRunning=false;
  }
  const modal=document.getElementById("barcodeModal");
  if(modal) modal.remove();
}

function scannerErrorMessage(err){
  const n=err?.name||"";
  if(n==="NotAllowedError" || n==="PermissionDeniedError")
    return "Chrome hat den Kamerazugriff verweigert. Bitte die Kamera-Berechtigung für diese Website erlauben.";
  if(n==="NotFoundError")
    return "Keine Kamera gefunden.";
  if(n==="NotReadableError")
    return "Die Kamera wird gerade von einer anderen App verwendet.";
  if(n==="SecurityError")
    return "Der Kamerazugriff wurde aus Sicherheitsgründen blockiert. Öffne die App über die HTTPS-Netlify-Adresse.";
  return "Kamera konnte nicht gestartet werden.";
}

async function startNativeBarcodeCamera(){
  const video=document.getElementById("barcode-video");
  const status=document.getElementById("barcode-status");
  if(!video) throw new Error("Kameraansicht nicht gefunden.");

  // Ask for the camera directly from the user's Scan button.
  // No geolocation request is made anywhere in the scanner.
  if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
    throw new Error("Dieser Browser unterstützt keinen direkten Kamerazugriff.");
  }

  barcodeStream=await navigator.mediaDevices.getUserMedia({
    audio:false,
    video:{facingMode:{ideal:"environment"}, width:{ideal:1280}, height:{ideal:720}}
  });

  video.srcObject=barcodeStream;
  await video.play();

  if(!("BarcodeDetector" in window)){
    status.textContent="Kamera läuft. Automatische Erkennung wird von diesem Browser nicht unterstützt. Bitte EAN unten eingeben.";
    return;
  }

  let formats=["ean_13","ean_8","upc_a","upc_e","code_128","code_39"];
  try{
    const supported=await BarcodeDetector.getSupportedFormats();
    formats=formats.filter(f=>supported.includes(f));
  }catch(e){}
  if(!formats.length){
    status.textContent="Kamera läuft. Dieser Browser unterstützt die benötigten Barcode-Formate nicht.";
    return;
  }

  nativeBarcodeDetector=new BarcodeDetector({formats});
  status.textContent="Kamera läuft – Barcode vor die Kamera halten …";

  nativeScanTimer=setInterval(async()=>{
    if(!video.videoWidth || !video.videoHeight || !nativeBarcodeDetector) return;
    try{
      const codes=await nativeBarcodeDetector.detect(video);
      if(codes && codes.length){
        const value=codes[0].rawValue;
        if(value){
          const input=document.getElementById("ibar");
          if(input) input.value=value;
          status.textContent="Barcode erkannt: "+value;
          setTimeout(closeBarcodeScanner,250);
        }
      }
    }catch(e){}
  },180);
}

async function startBarcodeScanner(){
  if(document.getElementById("barcodeModal")) return;

  const modal=document.createElement("div");
  modal.id="barcodeModal";
  modal.className="modal";
  modal.innerHTML=`<div class="card">
    <h2>Barcode scannen</h2>
    <div class="scanner-box"><video id="barcode-video" autoplay playsinline muted></video></div>
    <div id="barcode-status" class="scan-hint">Kamera wird gestartet …</div>
    <div class="scan-hint">Halte den EAN-Strichcode in den Rahmen.</div>
    <div class="row" style="margin-top:14px">
      <button type="button" class="secondary" onclick="closeBarcodeScanner()">Abbrechen</button>
    </div>
  </div>`;
  document.body.appendChild(modal);

  try{
    // Native getUserMedia is intentionally used first. This avoids the
    // html5-qrcode permission/device-enumeration flow that caused the
    // Android/Chrome permission dialog in the previous build.
    await startNativeBarcodeCamera();
  }catch(err){
    console.error("Barcode camera error:",err);
    stopCameraStream();
    const status=document.getElementById("barcode-status");
    if(status){
      status.innerHTML=`<div class="error">${esc(scannerErrorMessage(err))}<br><small>${esc(err?.message||"")}</small></div>`;
    }
  }
}

function normalizeBarcode(v){return String(v||'').replace(/\D/g,'');}
function deriveUnitFromQuantity(q){
  const t=String(q||'').toLowerCase().replace(',', '.');
  if(/\bkg\b/.test(t)) return 'kg';
  if(/\bg\b/.test(t)) return 'g';
  if(/\bl\b/.test(t)) return 'l';
  if(/\bml\b/.test(t)) return 'ml';
  if(/\bcl\b/.test(t)) return 'cl';
  if(/\d+\s*(stk|stück|pieces|pcs)\b/.test(t)) return 'Stk.';
  return null;
}
function mapCatalogCategory(raw){
  const t=String(raw||'').toLowerCase();
  // Haushalt & Alltag zuerst: diese Produkte sollen nicht versehentlich als Lebensmittel landen.
  if(/tierfutter|tierfuttermittel|hundefutter|katzenfutter|hund|katze|welpenfutter|katzennahrung|hundenahrung|nagerfutter|vogelfutter|fischfutter|pet food/.test(t)) return 'Tiernahrung';
  if(/katzenstreu|hundekotbeutel|leckerli.*tier|tierbedarf|hundebedarf|katzenbedarf/.test(t)) return 'Tierbedarf';
  if(/toilettenpapier|klopapier|toilettenrolle|küchenrolle|küchenpapier|taschentuch|serviette|papierhandtuch/.test(t)) return 'Papierwaren';
  if(/shampoo|conditioner|haarkur|haarpflege|duschgel|deo|deodorant|bodylotion|creme|rasierer|rasiergel/.test(t)) return 'Haarpflege';
  if(/zahnpasta|zahnbürste|mundspül|zahnseide/.test(t)) return 'Zahnpflege';
  if(/seife|handseife|handwasch|toilettenartikel|tampon|binde|windel|feuchttuch/.test(t)) return 'Toilettenartikel';
  if(/waschmittel|weichspüler|pods|wasch.*caps|fleckenentferner/.test(t)) return 'Waschmittel';
  if(/spülmittel|geschirrspül|reiniger|putzmittel|wc-reiniger|toilettenreiniger|glasreiniger|allzweckreiniger|desinfektion|müllbeutel|müllsack/.test(t)) return 'Reinigung';
  if(/batterie|glühbirne|lampe|schwamm|bürste|alufolie|frischhaltefolie|backpapier|zewa|haushalt/.test(t)) return 'Haushaltsbedarf';
  if(/vitamin|tablette|medizin|salbe|pflaster|apotheke|schmerzmittel/.test(t)) return 'Gesundheit & Apotheke';
  if(/baby|babynahrung|milchpulver|babybrei/.test(t)) return 'Baby & Kinder';
  // Lebensmittel.
  if(/obst|gemüse|apfel|banane|kartoffel|tomate|gurke|zwiebel|karotte/.test(t)) return 'Obst & Gemüse';
  if(/wurst|fleisch|meat|sausage|schinken|ham|salami|würst/.test(t)) return 'Fleisch & Wurst';
  if(/fisch|lachs|thunfisch|garnele|shrimp|seafood/.test(t)) return 'Fisch & Meeresfrüchte';
  if(/tiefkühl|frozen/.test(t)) return 'Tiefkühl';
  if(/milch|käse|joghurt|quark|dairy|cheese|yogurt/.test(t)) return 'Kühlung';
  if(/getränk|beverage|drink|wasser|saft|cola|bier|wein/.test(t)) return 'Getränke';
  if(/nudel|pasta|reis|rice/.test(t)) return 'Nudeln & Reis';
  if(/linse|linsen|bohne|bohnen|kichererbse|erbsen/.test(t)) return 'Hülsenfrüchte';
  if(/konserve|canned|canning|dose/.test(t)) return 'Konserven';
  if(/süß|schokolade|keks|cookie|snack|candy|chocolate/.test(t)) return 'Süßes & Snacks';
  if(/gewürz|spice|herb/.test(t)) return 'Gewürze & Kräuter';
  if(/back|mehl|flour|baking/.test(t)) return 'Backen';
  if(/sauce|soße|ketchup|senf|marmelade|honig|aufstrich|nutella/.test(t)) return 'Saucen & Aufstriche';
  if(/cornflakes|müsli|haferflocken|frühstück/.test(t)) return 'Frühstück';
  if(/fertiggericht|pizza|suppe.*instant|instant/.test(t)) return 'Fertiggerichte';
  return 'Sonstiges';
}
function showProductPreview(product,imageUrl,source='Eure Produktdatenbank',statusText='Produkt gefunden'){
  const box=document.getElementById('productLookupResult');
  if(!box)return;
  const brand=product.brand?` · ${esc(product.brand)}`:(product.brands?` · ${esc(product.brands)}`:'');
  const qty=product.quantity?` · ${esc(product.quantity)}`:'';
  box.innerHTML=`<div class="product-preview">${imageUrl?`<img src="${esc(imageUrl)}" alt="Produktbild" onerror="this.style.display='none'">`:''}<div class="product-info"><div class="product-name">${esc(product.name||product.product_name||'Produkt gefunden')}${brand}</div><div class="lookup-status">${esc(statusText)} · ${esc(source)}${qty}</div></div></div>`;
}
async function lookupProductByEAN(){
  const input=document.getElementById('ibar');
  const statusBox=document.getElementById('productLookupResult');
  const code=normalizeBarcode(input?.value);
  if(!code){ alert('Bitte zuerst eine EAN eingeben.'); return; }
  if(input) input.value=code;
  if(statusBox) statusBox.innerHTML='<div class="lookup-status">🔎 Eure Produktdatenbank wird durchsucht …</div>';
  currentProductImage=null;
  currentProductData=null;
  try{
    const {data,error}=await db.from('products').select('ean,name,brand,variant,product_key,category,unit,quantity,image_url').eq('household_id',household.id).eq('ean',code).maybeSingle();
    if(error)throw error;
    if(data){
      currentProductData=data;
      currentProductImage=data.image_url||null;
      document.getElementById('iname').value=data.name||'';
      if(document.getElementById('ibrand')) document.getElementById('ibrand').value=data.brand||'';
      if(document.getElementById('ipack')) document.getElementById('ipack').value=data.quantity||'';
      if(document.getElementById('ivariant')) document.getElementById('ivariant').value=data.variant||'';
      if(data.unit && document.getElementById('iunit')) document.getElementById('iunit').value=data.unit;
      if(data.category && document.getElementById('icat')) document.getElementById('icat').value=data.category;
      const cb=document.getElementById('isaveproduct'); if(cb) cb.checked=true;
      showProductPreview(data,data.image_url,'Eure Produktdatenbank','✓ Produkt automatisch gefunden');
      return;
    }
    const cb=document.getElementById('isaveproduct'); if(cb) cb.checked=true;
    if(statusBox) statusBox.innerHTML='<div class="lookup-status">🆕 Diese EAN ist bei euch noch nicht gespeichert. Nach dem Ausfüllen wird sie automatisch in eurer Produktdatenbank gemerkt.</div>';
  }catch(err){
    console.warn('Eigene Produktdatenbank lookup failed',err);
    if(statusBox) statusBox.innerHTML='<div class="error">❌ Die Produktdatenbank konnte nicht abgefragt werden. Bitte Supabase-Migration und Verbindung prüfen.</div>';
  }
}
async function saveProductToCatalog(base){
  const cb=document.getElementById('isaveproduct');
  const ean=normalizeBarcode(base.barcode||'');
  if(!cb?.checked || !ean || !base.name) return;
  const payload={household_id:household.id,ean,name:base.name,brand:base.brand||currentProductData?.brand||null,variant:base.variant||currentProductData?.variant||null,product_key:normalizeProductKey(base.name,base.brand||currentProductData?.brand,base.variant||currentProductData?.variant),category:base.category||null,unit:base.unit||null,quantity:base.package_size||currentProductData?.quantity||null,image_url:currentProductImage||null,created_by:user.id};
  const {error}=await db.from('products').upsert(payload,{onConflict:'household_id,ean'});
  if(error){ console.warn('Produkt konnte nicht im Katalog gespeichert werden',error); flash('Produkt-Merkfunktion: '+error.message); }
}

async function saveItem(){
 const saveBtn=document.querySelector('.editor-save');
 const flash=document.getElementById('mflash');
 const showEditorError=(msg)=>{if(flash){flash.className='editor-error';flash.textContent='⚠️ '+msg;flash.scrollIntoView({block:'nearest'});}else alert(msg);};
 try{
  if(saveBtn){saveBtn.disabled=true;saveBtn.dataset.old=saveBtn.textContent;saveBtn.textContent='⏳ Wird gespeichert …';}
  if(!household?.id) throw Error('Haushalt noch nicht geladen. Bitte kurz warten und erneut speichern.');
  if(!user?.id) throw Error('Benutzer noch nicht geladen. Bitte erneut anmelden.');
  const name=document.getElementById("iname").value.trim();
  if(!name)throw Error("Name fehlt.");
  const rows=[...document.querySelectorAll('#chargeRows .charge-row')];
  if(!rows.length)throw Error("Mindestens eine Charge anlegen.");
  const base={household_id:household.id,user_id:user.id,name,brand:document.getElementById("ibrand")?.value.trim()||null,variant:document.getElementById("ivariant")?.value.trim()||null,package_size:document.getElementById("ipack")?.value.trim()||null,product_key:normalizeProductKey(name,document.getElementById("ibrand")?.value.trim()||null,document.getElementById("ivariant")?.value.trim()||null),unit:document.getElementById("iunit").value.trim()||"Stk.",category:document.getElementById("icat").value,place:document.getElementById("iplace").value,min_qty:Number(document.getElementById("imin").value||0),barcode:document.getElementById("ibar").value.trim()||null,product_image_url:currentProductImage||null,current_price:Number(document.getElementById("icurrentprice")?.value||0)||null,note:document.getElementById("inote").value.trim()||null};
  const charges=rows.map(row=>({qty:Number(row.querySelector('.charge-qty').value||0),mhd:row.querySelector('.charge-mhd').value||null}));
  if(charges.some(c=>c.qty<=0))throw Error("Die Menge muss größer als 0 sein.");
  if(editing){
    const first=charges[0];
    const obj={...base,...first};
    if(editing.pending_mhd && obj.mhd){obj.pending_mhd=false;if(obj.note==='🟡 Neu eingekauft – MHD eintragen')obj.note=null;}
    let r=await db.from("inventory_items").update(obj).eq("id",editing.id);if(r.error)throw r.error;
    if(charges.length>1){
      const extras=charges.slice(1).map(c=>({...base,...c,pending_mhd:false}));
      const r2=await db.from("inventory_items").insert(extras);if(r2.error)throw r2.error;
    }
  }else{
    const records=charges.map(c=>({...base,...c,pending_mhd:false}));
    const r=await db.from("inventory_items").insert(records);if(r.error)throw r.error;
  }
  await saveProductToCatalog(base);
  document.getElementById("modal").innerHTML="";await loadData();renderApp()
 }catch(e){
  console.error(e);
  showEditorError(e.message||'Speichern fehlgeschlagen.');
  if(saveBtn){saveBtn.disabled=false;saveBtn.textContent=saveBtn.dataset.old||'💾 Speichern';}
 }
}
async function changeQty(id,delta){const x=items.find(i=>i.id===id);if(!x)return;const qty=Math.max(0,Number(x.qty)+delta);if(qty===0){await removeItem(id);return}const {error}=await db.from("inventory_items").update({qty}).eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function removeItem(id){if(!confirm("Artikel wirklich löschen?"))return;const {error}=await db.from("inventory_items").delete().eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function addShopping(){const el=document.getElementById("newShop"),name=el.value.trim();if(!name)return;const qty=Math.max(0.01,Number(document.getElementById("newShopQty")?.value||1));const unit=document.getElementById("newShopUnit")?.value||"Stk.";const {error}=await db.from("shopping_items").insert({household_id:household.id,user_id:user.id,name,qty,unit,unit_price:null});if(error)flash(error.message);else{el.value="";document.getElementById("newShopQty").value=1;await loadData();renderApp()}}
async function updateShoppingQty(id,value){const qty=Math.max(0.01,Number(value||1));const {error}=await db.from("shopping_items").update({qty}).eq("id",id);if(error)flash(error.message);else await loadData()}
async function updateShoppingUnit(id,unit){const {error}=await db.from("shopping_items").update({unit}).eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function updateShoppingPrice(id,value){const price=Math.max(0,Number(value)||0);const {error}=await db.from("shopping_items").update({unit_price:price||null}).eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function toggleShopping(id,checked){
 const shop=shopping.find(x=>x.id===id);
 if(!shop)return;
 if(!checked){
   if(shop.inventory_item_id){
     const linked=items.find(x=>x.id===shop.inventory_item_id);
     if(linked && linked.pending_mhd && !linked.mhd){
       const {error:delError}=await db.from("inventory_items").delete().eq("id",shop.inventory_item_id);
       if(delError){flash(delError.message);return;}
     }
   }
   const {error}=await db.from("shopping_items").update({checked:false,inventory_item_id:null}).eq("id",id);
   if(error)flash(error.message);else{await loadData();renderApp()}
   return;
 }
 // Erst beim Abhaken wird der Einkauf als vorläufiger Bestand übernommen.
 const qty=Math.max(0.01,Number(shop.qty||1));
 const unit=shop.unit||"Stk.";
 const {data:inv,error:invError}=await db.from("inventory_items").insert({
   household_id:household.id,user_id:user.id,name:shop.name,qty,unit,mhd:null,
   category:"Sonstiges",place:"Vorratsregal",min_qty:0,barcode:null,
   note:"🟡 Neu eingekauft – MHD eintragen",pending_mhd:true
 }).select("id").single();
 if(invError){flash(invError.message);return;}
 const {error}=await db.from("shopping_items").update({checked:true,inventory_item_id:inv.id}).eq("id",id);
 if(error){
   await db.from("inventory_items").delete().eq("id",inv.id);
   flash(error.message);
 }else{await loadData();renderApp()}
}
async function deleteShopping(id){const {error}=await db.from("shopping_items").delete().eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function logout(){await db.auth.signOut()}
init();
