// PokeChile HTML prototype. FX values are illustrative; update before publishing.
const API_BASE='https://api.pkmnprices.com/v1';
const USD_CLP=950, EUR_CLP=1030;
let language='English',cards=[],saved=JSON.parse(localStorage.getItem('pokechile_saved')||'[]');
const $=id=>document.getElementById(id);
const key=()=>localStorage.getItem('pokechile_api_key')||'';
function updateSavedCount(){$('savedCount').textContent=saved.length}
function setStatus(message){const el=$('status');el.textContent=message;el.classList.toggle('hidden',!message)}
function showTab(tab){
 document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
 $('explorePanel').classList.toggle('hidden',tab!=='explore');
 $('collectionPanel').classList.toggle('hidden',tab!=='collection');
 $('settingsPanel').classList.toggle('hidden',tab!=='settings');
 $('resultsTitle').parentElement.parentElement.classList.toggle('hidden',tab!=='explore');
 $('results').classList.toggle('hidden',tab!=='explore');
 $('emptyHint').classList.toggle('hidden',tab!=='explore'||cards.length>0);
 if(tab==='collection')renderCollection();
 if(tab==='settings')$('apiKey').value=key();
}
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
$('settingsBtn').addEventListener('click',()=>showTab('settings'));
document.querySelectorAll('.language').forEach(b=>b.addEventListener('click',()=>{
 language=b.dataset.lang;document.querySelectorAll('.language').forEach(x=>{x.classList.toggle('selected',x===b);x.querySelector('span').textContent=x===b?'✓':''});
}));
document.querySelectorAll('[data-query]').forEach(b=>b.addEventListener('click',()=>{$('query').value=b.dataset.query;searchCards()}));
$('searchForm').addEventListener('submit',e=>{e.preventDefault();searchCards()});
$('apiForm').addEventListener('submit',e=>{e.preventDefault();const v=$('apiKey').value.trim();if(v)localStorage.setItem('pokechile_api_key',v);else localStorage.removeItem('pokechile_api_key');alert('Configuración guardada en este navegador.');showTab('explore')});
async function searchCards(){
 const q=$('query').value.trim();if(!q)return;
 if(!key()){setStatus('Conecta tu API key desde Ajustes para consultar PkmnPrices.');$('emptyHint').classList.add('hidden');return}
 setStatus('Buscando cartas…');$('results').innerHTML='';$('emptyHint').classList.add('hidden');
 try{
  const r=await fetch(`${API_BASE}/cards?name=${encodeURIComponent(q)}&language=${encodeURIComponent(language)}&per_page=24`,{headers:{'X-API-Key':key()}});
  if(!r.ok)throw new Error(r.status===401||r.status===403?'La API key no fue aceptada. Revisa tu clave y plan.':`La API respondió ${r.status}.`);
  const d=await r.json();cards=Array.isArray(d)?d:(d.data||d.cards||d.results||[]);
  if(!cards.length){setStatus('No encontramos cartas. Prueba otro nombre o idioma.');return}
  setStatus('');$('resultsTitle').textContent='Resultados';$('resultsSub').textContent=`${cards.length} cartas · ${language==='English'?'Inglés':'Español'}`;
  renderCards(cards,$('results'));$('emptyHint').classList.add('hidden');
 }catch(e){setStatus(`${e.message} Comprueba la documentación de tu plan y la conexión.`)}
}
function renderCards(list,container){
 container.innerHTML='';
 list.forEach(c=>{
  const card=document.createElement('article');card.className='card';
  const art=document.createElement('div');art.className='card-art';
  if(c.image_url){const img=document.createElement('img');img.src=c.image_url;img.alt=c.name||'Carta Pokémon';img.loading='lazy';art.append(img)}
  else art.innerHTML='<span style="color:#95a4bc">Pokémon TCG</span>';
  const save=document.createElement('button');save.className='save';save.textContent=saved.some(x=>x.id===c.id)?'★':'＋';save.setAttribute('aria-label','Guardar carta');
  save.addEventListener('click',()=>toggleSave(c));art.append(save);
  const title=document.createElement('h3');title.textContent=c.name||'Carta Pokémon';
  const meta=document.createElement('div');meta.className='card-meta';meta.textContent=`${c.set?.name||'Pokémon TCG'} · #${c.number||'—'}`;
  const price=document.createElement('button');price.className='price-btn';price.textContent='♢  Ver precio CLP';price.addEventListener('click',()=>getPrice(c));
  card.append(art,title,meta,price);container.append(card);
 });
}
function toggleSave(c){
 const i=saved.findIndex(x=>x.id===c.id);if(i>=0)saved.splice(i,1);else saved.push(c);
 localStorage.setItem('pokechile_saved',JSON.stringify(saved));updateSavedCount();renderCards(cards,$('results'));renderCollection();
}
function renderCollection(){
 $('collectionGrid').innerHTML='';$('collectionEmpty').classList.toggle('hidden',saved.length>0);
 renderCards(saved,$('collectionGrid'));
}
async function getPrice(c){
 if(!key()){alert('Primero conecta tu API key en Ajustes.');return}
 try{
  const r=await fetch(`${API_BASE}/cards/${encodeURIComponent(c.id)}`,{headers:{'X-API-Key':key()}});
  if(!r.ok)throw new Error(`No se pudo obtener el precio (${r.status}).`);
  const d=await r.json(),card=d.data||d.card||d,prices=card.prices||[];
  let lines=prices.map(p=>{const rate=p.currency==='EUR'?EUR_CLP:USD_CLP;const n=typeof p.market_price==='number'?Math.round(p.market_price*rate):null;return `${p.source||'Mercado'} · ${p.variant||'Normal'}\\n${n===null?'Sin precio disponible':n.toLocaleString('es-CL',{style:'currency',currency:'CLP',maximumFractionDigits:0})} CLP · ${p.condition||'Condición no indicada'}`}).join('\\n\\n');
  $('modalTitle').textContent=card.name||c.name;$('modalBody').textContent=`${card.set?.name||'Pokémon TCG'} · #${card.number||'—'}\\n\\n${lines||'La API no entregó precios para esta carta.'}\\n\\nConversión orientativa de mercados internacionales; no es una cotización local chilena.`;
  $('priceModal').classList.remove('hidden');
 }catch(e){alert(`${e.message}\\nRevisa los endpoints y los campos documentados para tu plan de PkmnPrices.`)}
}
$('closeModal').addEventListener('click',()=>$('priceModal').classList.add('hidden'));
$('priceModal').addEventListener('click',e=>{if(e.target===$('priceModal'))$('priceModal').classList.add('hidden')});
updateSavedCount();