const ROBLOX_SHARE_URL = "https://www.roblox.com/share?code=a0908808519f704e906d1f175ec06cc9&type=ExperienceDetails&stamp=1794911175507";
const STORAGE = {
  name: "evergreen.playerName",
  news: "evergreen.customNews",
  motion: "evergreen.reducedMotion"
};

const $ = (id) => document.getElementById(id);

function readNews() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE.news) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function renderNews() {
  const container = $("newsList");
  const items = readNews();
  const defaults = [{
    title: "Bienvenue dans EVERGREEN",
    body: "Ton espace compagnon est prêt. Les prochaines annonces apparaîtront ici.",
    date: "ANNONCE"
  }];
  const all = [...items].reverse().concat(defaults);
  container.replaceChildren();

  all.forEach((item) => {
    const card = document.createElement("article");
    card.className = "news-card";

    const tag = document.createElement("span");
    tag.className = "news-tag";
    tag.textContent = "EVERGREEN";

    const title = document.createElement("h3");
    title.textContent = item.title;

    const body = document.createElement("p");
    body.textContent = item.body;

    const date = document.createElement("small");
    date.className = "news-date";
    date.textContent = item.date || "ANNONCE";

    card.append(tag, title, body, date);
    container.append(card);
  });
}

function initProfile() {
  const input = $("playerName");
  input.value = localStorage.getItem(STORAGE.name) || "";
  $("saveProfile").addEventListener("click", () => {
    const name = input.value.trim();
    localStorage.setItem(STORAGE.name, name);
    $("profileMessage").textContent = name ? "Profil enregistré sur cet appareil." : "Pseudo effacé.";
  });
}

function initSettings() {
  const motion = $("reducedMotion");
  motion.checked = localStorage.getItem(STORAGE.motion) === "true";
  motion.addEventListener("change", () => {
    localStorage.setItem(STORAGE.motion, String(motion.checked));
    document.documentElement.classList.toggle("reduce-motion", motion.checked);
  });

  $("manageNews").addEventListener("click", () => {
    const editor = $("newsEditor");
    editor.hidden = !editor.hidden;
  });

  $("addNews").addEventListener("click", () => {
    const title = $("newsTitle").value.trim();
    const body = $("newsBody").value.trim();
    if (!title || !body) {
      alert("Ajoute un titre et un contenu avant de publier.");
      return;
    }
    const items = readNews();
    items.push({ title, body, date: new Date().toLocaleDateString("fr-FR") });
    localStorage.setItem(STORAGE.news, JSON.stringify(items.slice(-30)));
    $("newsTitle").value = "";
    $("newsBody").value = "";
    $("newsEditor").hidden = true;
    renderNews();
    alert("Annonce enregistrée sur cet appareil.");
  });

  $("resetApp").addEventListener("click", () => {
    if (!confirm("Effacer le profil, les actualités et les préférences enregistrés sur cet appareil ?")) return;
    Object.values(STORAGE).forEach((key) => localStorage.removeItem(key));
    location.reload();
  });
}

function initNavigation() {
  const toggle = $("menuToggle");
  const drawer = $("drawer");
  toggle.addEventListener("click", () => {
    const open = drawer.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  drawer.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      drawer.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
    });
  });
}

function init() {
  $("robloxButton").href = ROBLOX_SHARE_URL;
  renderNews();
  initProfile();
  initSettings();
  initNavigation();
}

document.addEventListener("DOMContentLoaded", init);
