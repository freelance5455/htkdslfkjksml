const P=[["Fajr","الفجر"],["Sunrise","الشروق"],["Dhuhr","الظهر"],["Asr","العصر"],["Maghrib","المغرب"],["Isha","العشاء"]];
let times={},nextKey=null,timer,coords=null,notified={};const $=x=>document.getElementById(x);
const azkar=[
["سُبْحَانَ اللهِ وَبِحَمْدِهِ، سُبْحَانَ اللهِ الْعَظِيمِ","10 مرات"],
["أَسْتَغْفِرُ اللهَ وَأَتُوبُ إِلَيْهِ","100 مرة"],
["لَا إِلٰهَ إِلَّا اللهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ","10 مرات"],
["اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَىٰ نَبِيِّنَا مُحَمَّدٍ","10 مرات"],
["حَسْبِيَ اللهُ لَا إِلٰهَ إِلَّا هُوَ، عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ","7 مرات"],
["آيَةُ الْكُرْسِيِّ","مرة واحدة"]
];
$("azkarList").innerHTML=azkar.map(x=>`<div class="card"><div class="arabic">${x[0]}</div><div class="meta">${x[1]}</div></div>`).join("");
function toast(t){$("toast").textContent=t;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",3000)}
function dateStr(){let d=new Date();return `${String(d.getDate()).padStart(2,"0")}-${String(d.getMonth()+1).padStart(2,"0")}-${d.getFullYear()}`}
function mins(t){let [h,m]=t.split(" ")[0].split(":").map(Number);return h*60+m}
function now(){let d=new Date();return d.getHours()*60+d.getMinutes()+d.getSeconds()/60}
function render(d){times=d.timings;let n=now();let cand=P.find(([k])=>["Fajr","Dhuhr","Asr","Maghrib","Isha"].includes(k)&&mins(times[k])>n)||P[0];nextKey=cand[0];
$("date").textContent=`${d.date.gregorian.weekday.ar} • ${d.date.readable} • ${d.date.hijri.day} ${d.date.hijri.month.ar} ${d.date.hijri.year} هـ`;
$("next").textContent=cand[1];$("times").innerHTML=P.map(([k,n])=>`<div class="p ${k===nextKey?"on":""}"><div class="pn">${n}</div><div class="pt">${times[k]}</div></div>`).join("");update();clearInterval(timer);timer=setInterval(update,1000)}
function update(){if(!times[nextKey])return;let diff=mins(times[nextKey])-now();if(diff<0)diff+=1440;let s=Math.floor(diff*60);$("count").textContent=`${String(Math.floor(s/3600)).padStart(2,"0")}:${String(Math.floor(s%3600/60)).padStart(2,"0")}:${String(s%60).padStart(2,"0")}`;checkAlerts()}
function alertKey(){return new Date().toISOString().slice(0,10)}
function checkAlerts(){if(!times.Fajr)return;let d=new Date(),key=alertKey()+"-"+d.getHours()+":"+d.getMinutes();let current=Math.floor(now());for(let [k,n] of P){if(k==="Sunrise")continue;let delta=current-mins(times[k]);let before=localStorage.getItem("before")!=="off";if((delta===0)||(before&&delta===-10)){let id=key+"-"+k+"-"+delta;if(!notified[id]){notified[id]=1;notify(n,delta===0)}}}}
function notify(name,atTime){if(Notification.permission==="granted")new Notification(atTime?"🕌 حان وقت صلاة "+name:"⏰ بعد 10 دقائق: صلاة "+name,{body:"صلاتك تناديك ❤️"});if(atTime&&navigator.vibrate)navigator.vibrate([300,150,300])}
async function load(){try{let u=coords?`https://api.aladhan.com/v1/timings/${dateStr()}?latitude=${coords.lat}&longitude=${coords.lon}&method=5`: `https://api.aladhan.com/v1/timingsByCity/${dateStr()}?city=Cairo&country=Egypt&method=5`;let r=await fetch(u);let j=await r.json();render(j.data);localStorage.setItem("cache",JSON.stringify(j.data))}catch(e){let c=localStorage.getItem("cache");if(c)render(JSON.parse(c));else toast("تحقق من الإنترنت")}}
function show(id){document.querySelectorAll(".panel").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.p===id))}
document.querySelectorAll(".nav").forEach(b=>b.onclick=()=>show(b.dataset.p));$("refresh").onclick=load;
$("notify").onclick=async()=>{if(!("Notification"in window))return toast("التنبيهات غير مدعومة هنا");let p=await Notification.requestPermission();localStorage.setItem("notify",p==="granted"?"on":"off");toast(p==="granted"?"تم تفعيل التنبيهات":"لم يتم السماح بالتنبيهات");$("swNotify").classList.toggle("on",p==="granted")};
$("useLoc").onclick=()=>navigator.geolocation.getCurrentPosition(p=>{coords={lat:p.coords.latitude,lon:p.coords.longitude};$("loc").textContent="استخدام موقع الجهاز • طريقة الحساب: الهيئة المصرية العامة للمساحة";load()},()=>toast("تعذر الوصول للموقع"));
let tn=+localStorage.getItem("tas")||0;$("tasNum").textContent=tn;$("tasBtn").onclick=()=>{$("tasNum").textContent=++tn;localStorage.setItem("tas",tn)};$("resetTas").onclick=()=>{tn=0;$("tasNum").textContent=0;localStorage.setItem("tas",0)};
function sw(id,key,def=true){let on=localStorage.getItem(key)!=="off"&&def;$(id).classList.toggle("on",on);$(id).onclick=()=>{on=!on;localStorage.setItem(key,on?"on":"off");$(id).classList.toggle("on",on)}}
sw("swNotify","notify",false);sw("swBefore","before",true);
let userLat=30.0444,userLon=31.2357;
function bearing(lat1,lon1,lat2,lon2){let r=Math.PI/180,a=Math.sin((lon2-lon1)*r)*Math.cos(lat2*r),b=Math.cos(lat1*r)*Math.sin(lat2*r)-Math.sin(lat1*r)*Math.cos(lat2*r)*Math.cos((lon2-lon1)*r);return (Math.atan2(a,b)/r+360)%360}
function compass(){let lat=coords?.lat||userLat,lon=coords?.lon||userLon;let b=bearing(lat,lon,21.4225,39.8262);$("qdeg").textContent=Math.round(b)+"° من الشمال";return b}
$("startCompass").onclick=async()=>{if(typeof DeviceOrientationEvent!=="undefined"&&DeviceOrientationEvent.requestPermission){try{let p=await DeviceOrientationEvent.requestPermission();if(p!=="granted")return toast("لم يتم السماح بالبوصلة")}catch(e){}}let b=compass();window.addEventListener("deviceorientationabsolute",e=>{let h=e.alpha??0;$("needle").style.transform=`rotate(${b-h}deg)`});toast("تم تفعيل البوصلة")};
if("serviceWorker"in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{});load();