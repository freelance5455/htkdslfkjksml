const app=document.getElementById('app');
const state={page:'Home',user:localStorage.getItem('mj_user')||'MrJinwoo',chat:JSON.parse(localStorage.getItem('mj_chat')||'[]'),connections:JSON.parse(localStorage.getItem('mj_connections')||'[]')};

const pages=['Home','Profile','Connect','Chats','Account','Settings'];
function save(){localStorage.setItem('mj_chat',JSON.stringify(state.chat));localStorage.setItem('mj_connections',JSON.stringify(state.connections));localStorage.setItem('mj_user',state.user)}
function layout(content){
app.innerHTML=`<div class="shell"><aside class="sidebar"><div class="brand">⛏️ <span>MrJinwoo</span></div><nav class="nav">${pages.map((p,i)=>`<button class="${state.page===p?'active':''}" onclick="go('${p}')">${['🏠','👤','🔗','💬','🪪','⚙️'][i]} ${p}</button>`).join('')}</nav></aside><main class="main">${content}</main></div>`;
}
function header(title,sub=''){return `<div class="top"><div><h2>${title}</h2><div class="muted">${sub}</div></div><span class="badge">● Online</span></div>`}
function go(p){state.page=p;render()}
function render(){
const p=state.page;
if(p==='Home') layout(header('Minecraft Gamer Hub','Welcome back, '+state.user+'!')+`
<section class="hero"><h1>🎮 MrJinwoo App</h1><p class="muted">Connect with gamers, chat with friends and build your Minecraft community.</p><div class="actions"><button class="primary" onclick="go('Connect')">Find Gamers</button><button class="secondary" onclick="go('Chats')">Open Chats</button></div></section>
<div class="grid"><div class="card"><div class="muted">Connections</div><div class="stat">${state.connections.length}</div></div><div class="card"><div class="muted">Messages</div><div class="stat">${state.chat.length}</div></div><div class="card"><div class="muted">Minecraft Status</div><div class="stat">Online</div></div></div>
<div class="card" style="margin-top:16px"><h3>📢 Ad Account</h3><p class="muted">Manage your promotional account from the Account screen.</p><button class="secondary" onclick="go('Account')">Manage Account</button></div>`);
else if(p==='Profile') layout(header('Profile','Your gamer identity')+`<div class="card"><div class="profile"><div class="avatar">⛏️</div><div><h2>@${esc(state.user)}</h2><div class="muted">Minecraft Gamer</div></div></div><hr><p>Connections: <b>${state.connections.length}</b></p><button class="primary" onclick="go('Account')">Edit username</button></div>`);
else if(p==='Connect') layout(header('Connect','Find and connect with gamers')+`<div class="card"><div class="form"><input id="find" placeholder="Enter gamer username"><button class="primary" onclick="connect()">Connect</button></div></div><div class="card" style="margin-top:16px"><h3>Your connections</h3>${state.connections.length?state.connections.map(x=>`<div class="row"><span>🟢 @${esc(x)}</span><button class="secondary" onclick="chatWith('${esc(x)}')">Chat</button></div>`).join(''):'<p class="muted">No connections yet.</p>'}</div>`);
else if(p==='Chats') layout(header('Chats','Send messages to your gamer friends')+`<div class="card"><div class="chatbox" id="chat">${state.chat.length?state.chat.map(m=>`<div class="msg ${m.me?'mine':'theirs'}"><b>${esc(m.name)}</b><br>${esc(m.text)}</div>`).join(''):'<p class="muted">No messages yet. Send a message below.</p>'}</div><div class="compose"><input id="message" placeholder="Type a message..." onkeydown="if(event.key==='Enter')send()"><button class="primary" onclick="send()">Send</button></div><div class="actions" style="margin-top:10px"><button class="secondary" onclick="callUser()">📞 Call</button></div></div>`);
else if(p==='Account') layout(header('Account','Username and ad account')+`<div class="card"><div class="form"><label>Username</label><input id="username" value="${esc(state.user)}"><button class="primary" onclick="updateUser()">Save username</button></div><hr><h3>📢 Ad Account</h3><p class="muted">Demo account controls for your app.</p><div class="row"><span>Ad account</span><b>Connected</b></div><div class="row"><span>Campaign status</span><b>Ready</b></div><button class="secondary" onclick="alert('Ad account connection flow opened in demo mode.')">Connect ad account</button></div>`);
else layout(header('Settings','App preferences')+`<div class="card"><div class="row"><span>Notifications</span><button class="secondary" onclick="alert('Notifications toggled')">Toggle</button></div><div class="row"><span>Theme</span><span class="badge">Dark gamer</span></div><div class="row"><span>Data</span><button class="danger" onclick="resetData()">Reset demo data</button></div></div>`);
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]))}
function connect(){let x=document.getElementById('find').value.trim().replace(/^@/,'');if(!x)return alert('Enter a username');if(x===state.user)return alert('You cannot connect to yourself');if(!state.connections.includes(x)){state.connections.push(x);save();render()}else alert('Already connected.')}
function chatWith(x){state.chat.push({name:'System',text:'Chat opened with @'+x,me:false});save();go('Chats')}
function send(){const i=document.getElementById('message'),t=i.value.trim();if(!t)return;state.chat.push({name:state.user,text:t,me:true});save();i.value='';render()}
function callUser(){alert('Call interface opened. Connect a voice/video calling service to enable real calls.')}
function updateUser(){let x=document.getElementById('username').value.trim().replace(/^@/,'');if(!x)return alert('Username cannot be empty');state.user=x;save();render()}
function resetData(){if(confirm('Reset demo data?')){state.chat=[];state.connections=[];save();render()}}
render();