(function () {
  "use strict";

  const STORAGE_KEYS = {
    KEYS: "matyka_cheats_keys_v1",
    HISTORY: "matyka_cheats_history_v1",
    SELECTED_PRODUCT: "matyka_cheats_selected_product_v1",
    MEDIA: "matyka_cheats_media_slots_v1"
  };

  const PRODUCTS = [
    {
      id: "flourite-ios",
      name: "Flourite IOS",
      platform: "iOS",
      subtitle: "Módulo dedicado para dispositivos Apple iOS",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="2" width="12" height="20" rx="3"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>`
    },
    {
      id: "painel-emulador",
      name: "Painel Emulador",
      platform: "PC / EMU",
      subtitle: "Controle otimizado para ambientes emulados",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`
    },
    {
      id: "matyka-cheats-apk-mod",
      name: "Matyka Cheats Apk Mod",
      platform: "ANDROID APK",
      subtitle: "Pacote modificado integrado de alta performance",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5 12 2"/><circle cx="12" cy="12" r="3"/></svg>`
    },
    {
      id: "proxy-android",
      name: "Proxy Android",
      platform: "REDE / ANDROID",
      subtitle: "Roteamento e filtragem avançada de conexão",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`
    },
    {
      id: "external-ipa",
      name: "External IPA",
      platform: "iOS EXTERNAL",
      subtitle: "Assinatura e execução externa para iPhone/iPad",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="7.5 4.21 12 6.81 16.5 4.21"/><polyline points="7.5 19.79 7.5 14.6 3 12"/><polyline points="21 12 16.5 14.6 16.5 19.79"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`
    },
    {
      id: "painel-android",
      name: "Painel Android",
      platform: "ANDROID",
      subtitle: "Interface flutuante padrão sem acesso root",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="9" y1="6" x2="15" y2="6"/><line x1="9" y1="10" x2="15" y2="10"/><line x1="9" y1="14" x2="13" y2="14"/></svg>`
    },
    {
      id: "painel-root",
      name: "Painel Root",
      platform: "SUPERUSER",
      subtitle: "Acesso privilegiado em nível de sistema Android",
      icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>`
    }
  ];

  const DURATION_MAP = {
    "1h": { label: "1 hora", ms: 1 * 3600 * 1000 },
    "6h": { label: "6 horas", ms: 6 * 3600 * 1000 },
    "12h": { label: "12 horas", ms: 12 * 3600 * 1000 },
    "24h": { label: "24 horas", ms: 24 * 3600 * 1000 },
    "3d": { label: "3 dias", ms: 3 * 86400 * 1000 },
    "7d": { label: "7 dias", ms: 7 * 86400 * 1000 },
    "15d": { label: "15 dias", ms: 15 * 86400 * 1000 },
    "30d": { label: "30 dias", ms: 30 * 86400 * 1000 },
    "90d": { label: "90 dias", ms: 90 * 86400 * 1000 },
    "perm": { label: "Permanente", ms: null }
  };

  let state = {
    keys: loadJSON(STORAGE_KEYS.KEYS, []),
    history: loadJSON(STORAGE_KEYS.HISTORY, []),
    selectedProductId: localStorage.getItem(STORAGE_KEYS.SELECTED_PRODUCT) || "",
    media: loadJSON(STORAGE_KEYS.MEDIA, {}),
    latestBatch: []
  };

  function loadJSON(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function saveState() {
    localStorage.setItem(STORAGE_KEYS.KEYS, JSON.stringify(state.keys));
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(state.history));
    localStorage.setItem(STORAGE_KEYS.SELECTED_PRODUCT, state.selectedProductId);
    try {
      localStorage.setItem(STORAGE_KEYS.MEDIA, JSON.stringify(state.media));
    } catch (e) {
      showToast("Imagem muito pesada para o armazenamento local.");
    }
  }

  function showToast(message) {
    const container = document.getElementById("toastContainer");
    if (!container) return;
    const toast = document.createElement("div");
    toast.className = "toast";
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(-6px)";
      setTimeout(() => toast.remove(), 220);
    }, 2600);
  }

  function addActivity(title, detail) {
    state.history.unshift({
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      title,
      detail,
      timestamp: Date.now()
    });
    if (state.history.length > 150) {
      state.history = state.history.slice(0, 150);
    }
    saveState();
    renderHistory();
  }

  function formatDateTime(ts) {
    const d = new Date(ts);
    return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" }) +
      " " +
      d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
  }

  function getProductById(id) {
    return PRODUCTS.find((p) => p.id === id) || null;
  }

  function getKeyEffectiveStatus(keyObj) {
    if (keyObj.status === "paused") return "paused";
    if (keyObj.expiresAt && Date.now() > keyObj.expiresAt) return "expired";
    return "active";
  }

  function formatRemaining(keyObj) {
    if (!keyObj.expiresAt) return "Vitalícia";
    const diff = keyObj.expiresAt - Date.now();
    if (diff <= 0) return "Expirada";
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}m restantes`;
    const hours = Math.floor(mins / 60);
    if (hours < 48) return `${hours}h restantes`;
    const days = Math.floor(hours / 24);
    return `${days}d restantes`;
  }

  function switchTab(tabId) {
    document.querySelectorAll(".tab-panel").forEach((el) => {
      el.classList.toggle("active", el.id === `tab-${tabId}`);
    });
    document.querySelectorAll(".nav-btn, .m-nav-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.tab === tabId);
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function selectProduct(productId, shouldNotify = true) {
    const prod = getProductById(productId);
    if (!prod) return;
    state.selectedProductId = prod.id;
    saveState();
    syncSelectedProductUI();
    if (shouldNotify) {
      addActivity("Produto selecionado", prod.name);
      showToast(`Produto ativo: ${prod.name}`);
    }
  }

  function syncSelectedProductUI() {
    const prod = getProductById(state.selectedProductId);
    const labelText = prod ? prod.name : "Nenhum produto";
    const headerChip = document.getElementById("headerSelectedProduct");
    const productLabel = document.getElementById("productTabSelectedLabel");
    if (headerChip) headerChip.textContent = labelText;
    if (productLabel) {
      productLabel.innerHTML = `Selecionado: <strong>${prod ? prod.name : "Nenhum"}</strong>`;
    }

    const genSelect = document.getElementById("genProductSelect");
    if (genSelect && prod) {
      genSelect.value = prod.id;
    }

    document.querySelectorAll(".product-card").forEach((card) => {
      const isSelected = card.dataset.productId === state.selectedProductId;
      card.classList.toggle("selected", isSelected);
      const btn = card.querySelector(".product-select-btn");
      if (btn) {
        btn.textContent = isSelected ? "Produto Selecionado ✓" : "Selecionar Produto";
        btn.className = isSelected
          ? "btn btn-primary product-select-btn"
          : "btn btn-outline product-select-btn";
      }
    });
  }

  function renderProducts() {
    const grid = document.getElementById("productsGrid");
    const genSelect = document.getElementById("genProductSelect");
    const filterSelect = document.getElementById("filterProductSelect");
    if (!grid) return;

    grid.innerHTML = "";
    if (genSelect) genSelect.innerHTML = `<option value="">-- Selecione um produto antes de gerar --</option>`;
    if (filterSelect) filterSelect.innerHTML = `<option value="ALL">Todos os Produtos</option>`;

    PRODUCTS.forEach((prod) => {
      if (genSelect) {
        const opt1 = document.createElement("option");
        opt1.value = prod.id;
        opt1.textContent = prod.name;
        genSelect.appendChild(opt1);
      }
      if (filterSelect) {
        const opt2 = document.createElement("option");
        opt2.value = prod.id;
        opt2.textContent = prod.name;
        filterSelect.appendChild(opt2);
      }

      const customImg = state.media[`prod_${prod.id}`];
      const card = document.createElement("article");
      card.className = "product-card";
      card.dataset.productId = prod.id;

      card.innerHTML = `
        <div class="product-media-slot" data-image-slot="produto-${prod.id}" style="${customImg ? `background-image:url('${customImg}')` : ""}">
          <span class="product-platform-tag">${prod.platform}</span>
          ${!customImg ? `<div class="product-icon-emblem">${prod.icon}</div>` : ""}
          <label class="product-upload-mini" title="Definir capa personalizada">
            + Imagem
            <input type="file" accept="image/*" data-product-img="${prod.id}" hidden />
          </label>
        </div>
        <div class="product-body">
          <div>
            <h3 class="product-title">${prod.name}</h3>
            <p class="product-meta">${prod.subtitle}</p>
          </div>
          <button type="button" class="btn btn-outline product-select-btn" data-select-product="${prod.id}">
            Selecionar Produto
          </button>
        </div>
      `;
      grid.appendChild(card);
    });

    syncSelectedProductUI();
  }

  function generateRandomBlock(length = 4) {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let result = "";
    const array = new Uint32Array(length);
    if (window.crypto && window.crypto.getRandomValues) {
      window.crypto.getRandomValues(array);
      for (let i = 0; i < length; i++) {
        result += chars[array[i] % chars.length];
      }
    } else {
      for (let i = 0; i < length; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];
      }
    }
    return result;
  }

  function buildKeyString(prefix) {
    const cleanPrefix = (prefix || "MATYKA")
      .toUpperCase()
      .replace(/[^A-Z0-9_-]/g, "")
      .slice(0, 16) || "MATYKA";
    return `${cleanPrefix}-${generateRandomBlock(4)}-${generateRandomBlock(4)}-${generateRandomBlock(4)}`;
  }

  function updatePrefixPreview() {
    const prefixInput = document.getElementById("genPrefix");
    const previewCode = document.getElementById("keyFormatPreview");
    if (!prefixInput || !previewCode) return;
    const raw = prefixInput.value;
    const clean = (raw || "MATYKA")
      .toUpperCase()
      .replace(/[^A-Z0-9_-]/g, "")
      .slice(0, 16) || "MATYKA";
    previewCode.textContent = `${clean}-XXXX-XXXX-XXXX`;
  }

  function handleGenerateKeys(e) {
    e.preventDefault();
    const productSelect = document.getElementById("genProductSelect");
    if (!productSelect) return;
    const productId = productSelect.value;
    const prod = getProductById(productId);

    if (!prod) {
      showToast("Escolha um produto antes de gerar uma Key.");
      switchTab("produtos");
      return;
    }

    if (state.selectedProductId !== prod.id) {
      selectProduct(prod.id, false);
    }

    const durationKey = document.getElementById("genDuration").value;
    const durationInfo = DURATION_MAP[durationKey] || DURATION_MAP["24h"];
    const quantity = Math.min(100, Math.max(1, parseInt(document.getElementById("genQuantity").value, 10) || 1));
    const prefix = document.getElementById("genPrefix").value;
    const note = document.getElementById("genNote").value.trim();

    const now = Date.now();
    const createdBatch = [];

    for (let i = 0; i < quantity; i++) {
      const code = buildKeyString(prefix);
      const entry = {
        id: `${now}-${i}-${generateRandomBlock(3)}`,
        code,
        productId: prod.id,
        productName: prod.name,
        durationKey,
        durationLabel: durationInfo.label,
        createdAt: now,
        expiresAt: durationInfo.ms ? now + durationInfo.ms : null,
        status: "active",
        note
      };
      state.keys.unshift(entry);
      createdBatch.push(entry);
    }

    state.latestBatch = createdBatch;
    saveState();
    addActivity(
      `${quantity} ${quantity > 1 ? "Keys geradas" : "Key gerada"}`,
      `${prod.name} • Validade: ${durationInfo.label}`
    );

    renderLatestBatch();
    renderKeysList();
    renderDashboard();
    showToast(`${quantity} ${quantity > 1 ? "keys criadas" : "key criada"} para ${prod.name}!`);
  }

  function renderLatestBatch() {
    const container = document.getElementById("latestBatchList");
    const copyAllBtn = document.getElementById("copyBatchBtn");
    if (!container || !copyAllBtn) return;

    if (!state.latestBatch.length) {
      copyAllBtn.disabled = true;
      container.innerHTML = `<div class="empty-state"><p>Escolha um produto e clique em <strong>Gerar Keys Agora</strong> para emitir novas chaves.</p></div>`;
      return;
    }

    copyAllBtn.disabled = false;
    container.innerHTML = state.latestBatch
      .map(
        (item) => `
        <div class="batch-key-row">
          <div>
            <div class="batch-key-code">${item.code}</div>
            <small style="color:var(--text-secondary);font-size:0.72rem;">${item.productName} • ${item.durationLabel}</small>
          </div>
          <button type="button" class="btn btn-outline btn-sm" data-copy-code="${item.code}">Copiar</button>
        </div>
      `
      )
      .join("");
  }

  function getFilteredKeys() {
    const searchInput = document.getElementById("keySearchInput");
    const prodSelect = document.getElementById("filterProductSelect");
    const statusSelect = document.getElementById("filterStatusSelect");

    const query = searchInput ? searchInput.value.trim().toLowerCase() : "";
    const prodFilter = prodSelect ? prodSelect.value : "ALL";
    const statusFilter = statusSelect ? statusSelect.value : "ALL";

    return state.keys.filter((k) => {
      const effStatus = getKeyEffectiveStatus(k);
      if (prodFilter !== "ALL" && k.productId !== prodFilter) return false;
      if (statusFilter !== "ALL" && effStatus !== statusFilter) return false;
      if (query) {
        const hay = `${k.code} ${k.productName} ${k.note || ""}`.toLowerCase();
        if (!hay.includes(query)) return false;
      }
      return true;
    });
  }

  function renderKeysList() {
    const container = document.getElementById("keysListContainer");
    const navKeysCount = document.getElementById("navKeysCount");
    if (!container) return;

    const filtered = getFilteredKeys();
    if (navKeysCount) navKeysCount.textContent = state.keys.length;

    if (!filtered.length) {
      container.innerHTML = `<div class="panel-card empty-state" style="grid-column:1/-1;">Nenhuma key encontrada com os filtros atuais.</div>`;
      return;
    }

    container.innerHTML = filtered
      .map((k) => {
        const status = getKeyEffectiveStatus(k);
        const statusLabel = status === "active" ? "Ativa" : status === "paused" ? "Pausada" : "Expirada";
        return `
          <div class="key-card">
            <div class="key-card-top">
              <span class="key-product-badge">${k.productName}</span>
              <span class="status-badge ${status}">${statusLabel}</span>
            </div>
            <div class="key-code-box">
              <code>${k.code}</code>
              <button type="button" class="btn btn-outline btn-sm" data-copy-code="${k.code}">Copiar</button>
            </div>
            <div class="key-details-row">
              <span>Plano: <strong>${k.durationLabel}</strong></span>
              <span>${formatRemaining(k)}</span>
            </div>
            ${k.note ? `<div class="key-details-row"><span>Obs: ${escapeHTML(k.note)}</span></div>` : ""}
            <div class="key-actions-row">
              <button type="button" class="btn btn-outline btn-sm" data-toggle-key="${k.id}">
                ${k.status === "paused" ? "Ativar" : "Pausar"}
              </button>
              <button type="button" class="btn btn-outline btn-sm" data-renew-key="${k.id}">
                Renovar
              </button>
              <button type="button" class="btn btn-danger-outline btn-sm" data-delete-key="${k.id}">
                Excluir
              </button>
            </div>
          </div>
        `;
      })
      .join("");
  }

  function escapeHTML(str) {
    return str.replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  }

  function renderDashboard() {
    const total = state.keys.length;
    let active = 0;
    let inactive = 0;

    const countsByProduct = {};
    PRODUCTS.forEach((p) => (countsByProduct[p.id] = 0));

    state.keys.forEach((k) => {
      const st = getKeyEffectiveStatus(k);
      if (st === "active") active++;
      else inactive++;
      if (countsByProduct[k.productId] !== undefined) {
        countsByProduct[k.productId]++;
      }
    });

    const statTotal = document.getElementById("statTotalKeys");
    const statActive = document.getElementById("statActiveKeys");
    const statInactive = document.getElementById("statInactiveKeys");
    const navKeysCount = document.getElementById("navKeysCount");

    if (statTotal) statTotal.textContent = total;
    if (statActive) statActive.textContent = active;
    if (statInactive) statInactive.textContent = inactive;
    if (navKeysCount) navKeysCount.textContent = total;

    const distContainer = document.getElementById("productDistributionList");
    if (distContainer) {
      distContainer.innerHTML = PRODUCTS.map((p) => {
        const count = countsByProduct[p.id] || 0;
        const pct = total > 0 ? Math.round((count / total) * 100) : 0;
        return `
          <div>
            <div class="dist-item-head">
              <span>${p.name}</span>
              <strong>${count} (${pct}%)</strong>
            </div>
            <div class="dist-bar-bg">
              <div class="dist-bar-fill" style="width:${pct}%"></div>
            </div>
          </div>
        `;
      }).join("");
    }
  }

  function renderHistory() {
    const fullList = document.getElementById("fullActivityList");
    const recentList = document.getElementById("dashboardRecentActivity");
    if (!fullList || !recentList) return;

    if (!state.history.length) {
      const emptyHTML = `<div class="empty-state">Nenhuma atividade registrada até o momento.</div>`;
      fullList.innerHTML = emptyHTML;
      recentList.innerHTML = emptyHTML;
      return;
    }

    const buildItems = (items) =>
      items
        .map(
          (item) => `
          <div class="activity-item">
            <div class="activity-main">
              <span class="activity-dot"></span>
              <div>
                <div class="activity-title">${escapeHTML(item.title)}</div>
                <div class="activity-sub">${escapeHTML(item.detail || "")}</div>
              </div>
            </div>
            <span class="activity-time">${formatDateTime(item.timestamp)}</span>
          </div>
        `
        )
        .join("");

    fullList.innerHTML = buildItems(state.history);
    recentList.innerHTML = buildItems(state.history.slice(0, 5));
  }

  async function copyText(text, label = "Key copiada!") {
    try {
      await navigator.clipboard.writeText(text);
    } catch (e) {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    showToast(label);
  }

  function applySavedMedia() {
    const bgLayer = document.getElementById("customBgLayer");
    const bannerSlot = document.getElementById("dashboardBannerSlot");
    const logoSlot = document.getElementById("brandLogoSlot");

    if (bgLayer) {
      if (state.media.bgMain) {
        bgLayer.style.backgroundImage = `url('${state.media.bgMain}')`;
        bgLayer.style.opacity = "0.42";
      } else {
        bgLayer.style.backgroundImage = "";
        bgLayer.style.opacity = "0.28";
      }
    }

    if (bannerSlot) {
      if (state.media.bannerDash) {
        bannerSlot.style.backgroundImage = `url('${state.media.bannerDash}')`;
      } else {
        bannerSlot.style.backgroundImage = "";
      }
    }

    if (logoSlot) {
      if (state.media.brandLogo) {
        logoSlot.style.backgroundImage = `url('${state.media.brandLogo}')`;
        logoSlot.classList.add("has-custom-img");
      } else {
        logoSlot.style.backgroundImage = "";
        logoSlot.classList.remove("has-custom-img");
      }
    }
  }

  function handleImageUpload(file, slotKey, isProduct = false) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (ev) {
      state.media[slotKey] = ev.target.result;
      saveState();
      if (isProduct) {
        renderProducts();
      } else {
        applySavedMedia();
      }
      addActivity("Imagem atualizada", `Slot personalizado: ${slotKey}`);
      showToast("Imagem aplicada com sucesso!");
    };
    reader.readAsDataURL(file);
  }

  function bindEvents() {
    document.addEventListener("click", (e) => {
      const tabBtn = e.target.closest("[data-tab]");
      if (tabBtn) {
        switchTab(tabBtn.dataset.tab);
        return;
      }

      const navTarget = e.target.closest("[data-nav-target]");
      if (navTarget) {
        switchTab(navTarget.dataset.navTarget);
        return;
      }

      const selectProdBtn = e.target.closest("[data-select-product]");
      if (selectProdBtn) {
        selectProduct(selectProdBtn.dataset.selectProduct, true);
        return;
      }

      const copyBtn = e.target.closest("[data-copy-code]");
      if (copyBtn) {
        const code = copyBtn.dataset.copyCode;
        copyText(code, `Key ${code} copiada!`);
        addActivity("Key copiada", code);
        return;
      }

      const toggleBtn = e.target.closest("[data-toggle-key]");
      if (toggleBtn) {
        const item = state.keys.find((k) => k.id === toggleBtn.dataset.toggleKey);
        if (item) {
          item.status = item.status === "paused" ? "active" : "paused";
          saveState();
          renderKeysList();
          renderDashboard();
          addActivity(
            item.status === "paused" ? "Key pausada" : "Key reativada",
            `${item.code} (${item.productName})`
          );
          showToast(item.status === "paused" ? "Key pausada." : "Key ativada.");
        }
        return;
      }

      const renewBtn = e.target.closest("[data-renew-key]");
      if (renewBtn) {
        const item = state.keys.find((k) => k.id === renewBtn.dataset.renewKey);
        if (item) {
          const dur = DURATION_MAP[item.durationKey];
          item.expiresAt = dur && dur.ms ? Date.now() + dur.ms : null;
          item.status = "active";
          saveState();
          renderKeysList();
          renderDashboard();
          addActivity("Key renovada", `${item.code} (+${item.durationLabel})`);
          showToast(`Validade renovada (${item.durationLabel}).`);
        }
        return;
      }

      const deleteBtn = e.target.closest("[data-delete-key]");
      if (deleteBtn) {
        const idx = state.keys.findIndex((k) => k.id === deleteBtn.dataset.deleteKey);
        if (idx !== -1) {
          const removed = state.keys.splice(idx, 1)[0];
          saveState();
          renderKeysList();
          renderDashboard();
          addActivity("Key removida", `${removed.code} (${removed.productName})`);
          showToast("Key excluída.");
        }
        return;
      }

      const resetSlotBtn = e.target.closest("[data-reset-slot]");
      if (resetSlotBtn) {
        const slot = resetSlotBtn.dataset.resetSlot;
        delete state.media[slot];
        saveState();
        applySavedMedia();
        showToast("Imagem removida do slot.");
        return;
      }
    });

    document.addEventListener("change", (e) => {
      if (e.target.matches("[data-upload-slot]")) {
        handleImageUpload(e.target.files[0], e.target.dataset.uploadSlot, false);
      } else if (e.target.matches("[data-product-img]")) {
        handleImageUpload(e.target.files[0], `prod_${e.target.dataset.productImg}`, true);
      } else if (e.target.id === "genProductSelect") {
        if (e.target.value) selectProduct(e.target.value, false);
      }
    });

    const prefixInput = document.getElementById("genPrefix");
    if (prefixInput) prefixInput.addEventListener("input", updatePrefixPreview);

    const form = document.getElementById("keyGeneratorForm");
    if (form) form.addEventListener("submit", handleGenerateKeys);

    const copyBatchBtn = document.getElementById("copyBatchBtn");
    if (copyBatchBtn) {
      copyBatchBtn.addEventListener("click", () => {
        if (!state.latestBatch.length) return;
        const all = state.latestBatch.map((k) => k.code).join("\n");
        copyText(all, `${state.latestBatch.length} keys copiadas!`);
        addActivity("Lote copiado", `${state.latestBatch.length} chaves copiadas`);
      });
    }

    const copyAllFilteredBtn = document.getElementById("copyAllFilteredBtn");
    if (copyAllFilteredBtn) {
      copyAllFilteredBtn.addEventListener("click", () => {
        const list = getFilteredKeys();
        if (!list.length) {
          showToast("Nenhuma key disponível para copiar.");
          return;
        }
        copyText(list.map((k) => k.code).join("\n"), `${list.length} keys copiadas!`);
      });
    }

    const searchInput = document.getElementById("keySearchInput");
    if (searchInput) searchInput.addEventListener("input", renderKeysList);

    const filterProd = document.getElementById("filterProductSelect");
    if (filterProd) filterProd.addEventListener("change", renderKeysList);

    const filterStatus = document.getElementById("filterStatusSelect");
    if (filterStatus) filterStatus.addEventListener("change", renderKeysList);

    const clearHistoryBtn = document.getElementById("clearHistoryBtn");
    if (clearHistoryBtn) {
      clearHistoryBtn.addEventListener("click", () => {
        state.history = [];
        saveState();
        renderHistory();
        showToast("Histórico limpo.");
      });
    }

    const exportDataBtn = document.getElementById("exportDataBtn");
    if (exportDataBtn) {
      exportDataBtn.addEventListener("click", () => {
        const payload = JSON.stringify({ keys: state.keys, history: state.history }, null, 2);
        const blob = new Blob([payload], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `matyka-cheats-backup-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
        addActivity("Backup exportado", `${state.keys.length} keys salvas em JSON`);
        showToast("Arquivo de backup baixado.");
      });
    }

    const resetAllDataBtn = document.getElementById("resetAllDataBtn");
    if (resetAllDataBtn) {
      resetAllDataBtn.addEventListener("click", () => {
        state.keys = [];
        state.history = [];
        state.latestBatch = [];
        state.selectedProductId = "";
        saveState();
        renderProducts();
        renderLatestBatch();
        renderKeysList();
        renderDashboard();
        renderHistory();
        showToast("Todos os dados locais foram zerados.");
      });
    }
  }

  function init() {
    applySavedMedia();
    renderProducts();
    updatePrefixPreview();
    renderLatestBatch();
    renderKeysList();
    renderDashboard();
    renderHistory();
    bindEvents();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
