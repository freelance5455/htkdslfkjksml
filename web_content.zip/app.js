const statusText = document.getElementById('status');

function leaveApp(choice) {
  statusText.textContent = `Elegiste ${choice}. Cerrando esta maravilla…`;

  // En una APK con WebView, el puente Android puede cerrar la actividad.
  if (window.Android && typeof window.Android.closeApp === 'function') {
    window.Android.closeApp();
    return;
  }

  // En algunos navegadores solo se pueden cerrar ventanas abiertas por script.
  window.close();

  // Si el navegador bloquea el cierre, mostramos una indicación en vez de
  // redirigir a una web externa o dejar al usuario en una página inesperada.
  setTimeout(() => {
    statusText.textContent = 'El navegador no permite cerrarme. Cierra esta pestaña manualmente. 😭';
  }, 300);
}

document.getElementById('yes').addEventListener('click', () => leaveApp('SÍ'));
document.getElementById('no').addEventListener('click', () => leaveApp('NO'));
