/* Kichik Tolib — bitta LocalStorage bazasi bilan o‘yin + admin panel */

const STORAGE_KEYS = {
  cards: "kichik_tolib_cards_v1",
  stars: "kichik_tolib_stars_v1",
  coins: "kichik_tolib_coins_v1"
};

const ADMIN_PASSWORD = "tolib2026";

const DEFAULT_CARDS = [
  {
    id: "default-1",
    category: "Islom asoslari",
    question: "Islomning nechta ustuni bor?",
    options: ["3 ta", "4 ta", "5 ta", "6 ta"],
    correctIndex: 2,
    fact: "Islomning besh ustuni: shahodat, namoz, zakot, ro‘za va haj."
  },
  {
    id: "default-2",
    category: "Namoz",
    question: "Bir kunda farz namozlari necha mahal?",
    options: ["3 mahal", "4 mahal", "5 mahal", "6 mahal"],
    correctIndex: 2,
    fact: "Musulmonlar uchun bir kunda besh mahal farz namoz bor: Bomdod, Peshin, Asr, Shom va Xufton."
  },
  {
    id: "default-3",
    category: "Qur’on",
    question: "Qur’onda nechta sura bor?",
    options: ["99 ta", "100 ta", "114 ta", "120 ta"],
    correctIndex: 2,
    fact: "Qur’oni Karim 114 ta suradan iborat."
  }
];

function getCards() {
  const saved = localStorage.getItem(STORAGE_KEYS.cards);
  if (!saved) {
    localStorage.setItem(STORAGE_KEYS.cards, JSON.stringify(DEFAULT_CARDS));
    return [...DEFAULT_CARDS];
  }
  try {
    const parsed = JSON.parse(saved);
    return Array.isArray(parsed) && parsed.length ? parsed : [...DEFAULT_CARDS];
  } catch {
    localStorage.setItem(STORAGE_KEYS.cards, JSON.stringify(DEFAULT_CARDS));
    return [...DEFAULT_CARDS];
  }
}

function saveCards(cards) {
  localStorage.setItem(STORAGE_KEYS.cards, JSON.stringify(cards));
}

function getNumber(key) {
  return Number(localStorage.getItem(key) || 0);
}

function setNumber(key, value) {
  localStorage.setItem(key, String(Math.max(0, value)));
}

function addRewards(stars, coins) {
  setNumber(STORAGE_KEYS.stars, getNumber(STORAGE_KEYS.stars) + stars);
  setNumber(STORAGE_KEYS.coins, getNumber(STORAGE_KEYS.coins) + coins);
  updateStats();
}

function updateStats() {
  const stars = document.getElementById("stars");
  const coins = document.getElementById("coins");
  if (stars) stars.textContent = getNumber(STORAGE_KEYS.stars);
  if (coins) coins.textContent = getNumber(STORAGE_KEYS.coins);
}

/* ---------------- O‘YIN ---------------- */

let gameCards = [];
let currentIndex = 0;
let answered = false;

function initGame() {
  gameCards = getCards();
  currentIndex = 0;
  answered = false;

  updateStats();
  renderCard();

  const nextBtn = document.getElementById("nextBtn");
  const restartBtn = document.getElementById("restartBtn");

  if (nextBtn) nextBtn.addEventListener("click", nextCard);
  if (restartBtn) restartBtn.addEventListener("click", restartGame);
}

function renderCard() {
  const card = gameCards[currentIndex];
  if (!card) return;

  answered = false;
  const quizCard = document.getElementById("quizCard");
  const wrong = document.getElementById("wrongMessage");
  const restart = document.getElementById("restartBtn");

  quizCard.classList.remove("flipped");
  wrong.textContent = "";
  restart.classList.add("hidden");

  document.getElementById("category").textContent = card.category;
  document.getElementById("question").textContent = card.question;
  document.getElementById("currentNumber").textContent = currentIndex + 1;
  document.getElementById("totalNumber").textContent = gameCards.length;

  const progress = ((currentIndex + 1) / gameCards.length) * 100;
  document.getElementById("progressBar").style.width = progress + "%";

  const options = document.getElementById("options");
  options.innerHTML = "";

  card.options.forEach((option, index) => {
    const btn = document.createElement("button");
    btn.className = "option-btn";
    btn.type = "button";
    btn.textContent = `${index + 1}. ${option}`;
    btn.addEventListener("click", () => checkAnswer(index, btn));
    options.appendChild(btn);
  });
}

function checkAnswer(selectedIndex, clickedButton) {
  if (answered) return;

  const card = gameCards[currentIndex];
  const allButtons = [...document.querySelectorAll(".option-btn")];

  if (selectedIndex === Number(card.correctIndex)) {
    answered = true;
    clickedButton.classList.add("correct");
    allButtons.forEach(btn => btn.disabled = true);

    addRewards(3, 10);

    document.getElementById("resultTitle").textContent = "Barakalla! 🎉";
    document.getElementById("resultText").textContent = "+3 ⭐ va +10 🪙";
    document.getElementById("fact").textContent = card.fact;

    setTimeout(() => {
      document.getElementById("quizCard").classList.add("flipped");
    }, 350);
  } else {
    clickedButton.classList.add("wrong");
    document.getElementById("wrongMessage").textContent = "😊 Bu safar xato. Yana bir bor urinib ko‘ring!";
    setTimeout(() => clickedButton.classList.remove("wrong"), 650);
  }
}

function nextCard() {
  if (!answered) return;

  if (currentIndex < gameCards.length - 1) {
    currentIndex++;
    renderCard();
  } else {
    document.getElementById("resultTitle").textContent = "O‘yin tugadi! 🏆";
    document.getElementById("resultText").textContent = "Barcha kartochkalarni tugatdingiz!";
    document.getElementById("fact").textContent = "Bilim olishda davom eting. Yangi kartochkalar admin paneldan qo‘shilishi mumkin.";
    document.getElementById("nextBtn").textContent = "🔄 Qaytadan o‘ynash";
    document.getElementById("nextBtn").onclick = restartGame;
    document.getElementById("quizCard").classList.add("flipped");
    document.getElementById("restartBtn").classList.remove("hidden");
  }
}

function restartGame() {
  gameCards = getCards();
  currentIndex = 0;
  document.getElementById("nextBtn").textContent = "Keyingi kartochka →";
  document.getElementById("nextBtn").onclick = nextCard;
  renderCard();
}

/* ---------------- ADMIN ---------------- */

function initAdmin() {
  const loginModal = document.getElementById("loginModal");
  if (!loginModal) return;

  const adminContent = document.getElementById("adminContent");
  const loginForm = document.getElementById("loginForm");
  const passwordInput = document.getElementById("adminPassword");
  const loginError = document.getElementById("loginError");

  loginForm.addEventListener("submit", (event) => {
    event.preventDefault();

    if (passwordInput.value === ADMIN_PASSWORD) {
      loginModal.classList.add("hidden");
      adminContent.classList.remove("hidden");
      renderAdminCards();
    } else {
      loginError.textContent = "❌ Parol noto‘g‘ri!";
      passwordInput.value = "";
      passwordInput.focus();
    }
  });

  document.getElementById("logoutBtn").addEventListener("click", () => {
    adminContent.classList.add("hidden");
    loginModal.classList.remove("hidden");
    passwordInput.value = "";
    loginError.textContent = "";
  });

  document.getElementById("cardForm").addEventListener("submit", addNewCard);
}

function addNewCard(event) {
  event.preventDefault();

  const newCard = {
    id: "card-" + Date.now(),
    category: document.getElementById("formCategory").value.trim(),
    question: document.getElementById("formQuestion").value.trim(),
    options: [
      document.getElementById("formOption1").value.trim(),
      document.getElementById("formOption2").value.trim(),
      document.getElementById("formOption3").value.trim(),
      document.getElementById("formOption4").value.trim()
    ],
    correctIndex: Number(document.getElementById("formCorrect").value),
    fact: document.getElementById("formFact").value.trim()
  };

  if (!newCard.category || !newCard.question || newCard.options.some(x => !x) || !newCard.fact) {
    showFormMessage("Barcha maydonlarni to‘ldiring.");
    return;
  }

  const cards = getCards();
  cards.push(newCard);
  saveCards(cards);

  event.target.reset();
  showFormMessage("✅ Kartochka saqlandi va o‘yinga qo‘shildi!");
  renderAdminCards();
}

function showFormMessage(message) {
  const el = document.getElementById("formMessage");
  el.textContent = message;
  setTimeout(() => { el.textContent = ""; }, 3000);
}

function deleteCard(id) {
  const cards = getCards();

  if (cards.length <= 1) {
    alert("Kamida bitta kartochka qolishi kerak.");
    return;
  }

  const filtered = cards.filter(card => card.id !== id);
  saveCards(filtered);
  renderAdminCards();
}

function renderAdminCards() {
  const container = document.getElementById("adminCards");
  if (!container) return;

  const cards = getCards();
  document.getElementById("cardCount").textContent = cards.length;
  container.innerHTML = "";

  cards.forEach((card, index) => {
    const item = document.createElement("article");
    item.className = "admin-card";

    const top = document.createElement("div");
    top.className = "admin-card-top";

    const content = document.createElement("div");
    const title = document.createElement("h4");
    title.textContent = `${index + 1}. ${card.category}`;
    const question = document.createElement("p");
    question.textContent = card.question;

    content.append(title, question);

    const del = document.createElement("button");
    del.className = "delete-btn";
    del.type = "button";
    del.textContent = "🗑️ O‘chirish";
    del.addEventListener("click", () => {
      if (confirm("Ushbu kartochkani o‘chirishni xohlaysizmi?")) deleteCard(card.id);
    });

    top.append(content, del);

    const small = document.createElement("small");
    small.textContent = `To‘g‘ri javob: ${Number(card.correctIndex) + 1}-variant`;

    item.append(top, small);
    container.appendChild(item);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  updateStats();
  if (document.getElementById("quizCard")) initGame();
  if (document.getElementById("loginModal")) initAdmin();
});
