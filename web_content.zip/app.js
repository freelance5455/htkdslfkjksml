let points=Number(localStorage.getItem('points')||0);const p=document.getElementById('points');p.textContent=points;
function add(n,msg){points+=n;localStorage.setItem('points',points);p.textContent=points;alert(msg+'\nYour demo points: '+points)}
function checkin(){let d=localStorage.getItem('checkin');let today=new Date().toDateString();if(d===today){alert('You already checked in today.')}else{localStorage.setItem('checkin',today);document.getElementById('checkin').disabled=true;add(10,'Daily check-in complete!')}}
function task(){add(25,'Demo task completed!')}
function wallet(){alert('Wallet\n\nBalance: '+points+' demo points\n\nReal-money withdrawal is not enabled in this demo.')}
function profile(){alert('Easy Earning\nVersion 1.0\n\nDemo app')}
if(localStorage.getItem('checkin')===new Date().toDateString())document.getElementById('checkin').disabled=true;