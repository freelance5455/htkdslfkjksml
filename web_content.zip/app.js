const $ = (selector) => document.querySelector(selector);
const storageKey = 'carnblox:v1';
const state = { me: null, profile: null, friends: [], followedNames: new Set(), loved: new Set(), comments: [], toastTimer: null };

function readSaved() {
  try { return JSON.parse(localStorage.getItem(storageKey) || '{}'); } catch { return {}; }
}
function save() {
  localStorage.setItem(storageKey, JSON.stringify({ friends: state.friends, loved: [...state.loved] }));
}
function avatarUrl(user) {
  return user?.avatar_url || (user?.username ? 'https://images.websim.com/avatar/' + encodeURIComponent(user.username) : '');
}
function safeText(value, fallback = '') { return typeof value === 'string' && value.trim() ? value.trim() : fallback; }
function toast(message) {
  const node = $('#toast'); node.textContent = message; node.classList.add('show');
  clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => node.classList.remove('show'), 2400);
}
function profileShape(payload, username) {
  const value = payload?.user || payload?.data?.user || payload?.data || payload;
  if (!value || typeof value !== 'object') return null;
  const name = value.username || value.user?.username || username;
  return { ...value, username: name, avatar_url: value.avatar_url || value.user?.avatar_url || null };
}
function unwrapComment(item) { return item?.comment || item; }
function setProfile(user) {
  state.profile = user;
  $('#profile-name').textContent = safeText(user.display_name || user.name, user.username);
  $('#profile-handle').textContent = '@' + user.username;
  $('#profile-avatar').src = avatarUrl(user);
  $('#profile-avatar').alt = user.username + ' avatar';
  $('#profile-note').textContent = user.username === state.me?.username ? `Hips on the car. Don't give a bar.` : 'A little corner of the Carnblox neighborhood.';
  const isSelf = user.username.toLowerCase() === state.me?.username?.toLowerCase();
  const isFriend = state.followedNames.has(user.username.toLowerCase());
  $('#add-friend').classList.toggle('is-added', isFriend);
  $('#add-friend').innerHTML = isSelf ? 'Your profile' : isFriend ? '<span aria-hidden="true">✓</span> Friends' : '<span aria-hidden="true">＋</span> Add friend';
  $('#add-friend').disabled = isSelf || isFriend;
  $('#profile-status').textContent = '';
  renderProjects();
}
async function api(path, options) {
  const response = await fetch(path, options);
  if (!response.ok) throw new Error('Websim returned ' + response.status);
  return response.json();
}
async function loadUser(username) {
  const cleaned = username.trim().replace(/^@/, '');
  if (!cleaned || !/^[a-zA-Z0-9_.-]{1,40}$/.test(cleaned)) { toast('Enter a Websim username.'); return; }
  $('#profile-status').textContent = 'Looking for @' + cleaned + '...';
  try {
    const payload = await api('/api/v1/users/' + encodeURIComponent(cleaned));
    const user = profileShape(payload, cleaned);
    if (!user?.username) throw new Error('Player not found');
    setProfile(user);
  } catch (error) {
    $('#profile-status').textContent = 'Could not find @' + cleaned + ' right now.';
    toast('That player could not be found. Check the username and try again.');
  }
}
function renderProjects() {
  const projects = [
    { id: 'test', title: 'test', href: 'test.html', image: 'img/test-thumbnail.webp', alt: 'Colorful pretend DNA and a little pixel character' },
    { id: 'carn-lover', title: 'carn lover', href: 'carn-lover.html', image: 'img/carn-lover-thumbnail.webp', alt: 'Carn Lover hand-drawn purple cover with hearts' },
    { id: 'carn-baldi', title: 'Carn Baldi', href: 'carn-baldi.html', image: 'img/carn-baldi-thumbnail.webp', alt: 'Hand-drawn Carn Baldi cover art' },
    { id: 'carn-drawing', title: 'Carn Drawing', href: 'carn-drawing.html', image: 'img/carn-drawing-thumbnail.webp', alt: 'Hand-drawn Carn Drawing cover art' }
  ];
  $('#project-count').textContent = projects.length + ' games';
  $('#project-grid').innerHTML = projects.map(project => {
    const loved = state.loved.has(project.id);
    return '<article class="project-card"><a class="project-image-link" href="' + project.href + '" aria-label="Play ' + project.title + '"><img class="project-image" src="' + project.image + '" alt="' + project.alt + '" loading="lazy"><span class="project-overlay">PLAY ' + project.title.toUpperCase() + ' ↗</span></a><div class="project-info"><a class="project-title" href="' + project.href + '">' + project.title + '</a><div class="project-meta"><span>by Carnblox</span><span class="project-stats"><button class="heart-button ' + (loved ? 'is-loved' : '') + '" type="button" data-love="' + project.id + '" aria-pressed="' + loved + '" aria-label="' + (loved ? 'Unheart' : 'Heart') + ' ' + project.title + '"><b>♥</b> <span>' + (loved ? 1 : 0) + '</span></button><span class="project-stat" title="Play the game">◉ play</span></span></div></div></article>';
  }).join('');
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, char => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[char])); }
function escapeAttr(value) { return escapeHtml(value); }
function formatCount(value) { return value > 999 ? (value / 1000).toFixed(value > 9999 ? 0 : 1) + 'k' : String(value); }
function unpackFriends(payload) {
  const entries = payload?.following?.data || payload?.following || payload?.data?.following?.data || [];
  return (Array.isArray(entries) ? entries : []).map(entry => entry?.follow?.user || entry?.follow || entry?.user || entry).filter(user => user?.username);
}
function renderFriends() {
  const root = $('#friends-list');
  const friends = new Map(state.friends.map(friend => [friend.username.toLowerCase(), friend]));
  for (const friend of state.followedNames) if (!friends.has(friend.toLowerCase())) friends.set(friend.toLowerCase(), { username: friend });
  if (!friends.size) { root.innerHTML = '<span class="friends-empty">Your crew is waiting to meet you.</span>'; return; }
  root.innerHTML = [...friends.values()].map(friend => '<a class="friend-chip" href="#profile" data-user="' + escapeAttr(friend.username) + '"><img src="' + escapeAttr(avatarUrl(friend)) + '" alt="" loading="lazy"><span>@' + escapeHtml(friend.username) + '</span></a>').join('');
}
async function loadFriends() {
  const saved = readSaved();
  state.friends = Array.isArray(saved.friends) ? saved.friends : [];
  state.loved = new Set(Array.isArray(saved.loved) ? saved.loved.map(String) : []);
  if (state.me?.username) {
    try {
      const payload = await api('/api/v1/users/' + encodeURIComponent(state.me.username) + '/following');
      const remote = unpackFriends(payload);
      for (const friend of remote) state.followedNames.add(friend.username.toLowerCase());
      state.friends = [...new Map([...remote, ...state.friends].map(friend => [friend.username.toLowerCase(), friend])).values()];
    } catch { /* Local Carnblox friends stay available if following is private. */ }
  }
  renderFriends();
}
async function addFriend() {
  const user = state.profile;
  if (!user || user.username.toLowerCase() === state.me?.username?.toLowerCase()) return;
  const key = user.username.toLowerCase();
  if (state.followedNames.has(key)) { toast('@' + user.username + ' is already in your crew.'); return; }
  const friend = { username: user.username, avatar_url: user.avatar_url };
  state.followedNames.add(key);
  state.friends = [...state.friends.filter(item => item.username.toLowerCase() !== key), friend];
  save(); renderFriends(); setProfile(user);
  let synced = false;
  if (state.me?.username) {
    try {
      await api('/api/v1/users/' + encodeURIComponent(state.me.username) + '/following', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: user.username }) });
      synced = true;
    } catch { /* The local crew list is still useful if following writes are unavailable. */ }
  }
  toast(synced ? '@' + user.username + ' added to your Websim friends.' : '@' + user.username + ' added to your Carnblox crew.');
}
function renderMessages() {
  const box = $('#messages');
  const comments = state.comments.filter(comment => !comment.deleted && !comment.parent_comment_id);
  $('#chat-count').textContent = comments.length + (comments.length === 1 ? ' NOTE' : ' NOTES');
  if (!comments.length) { box.innerHTML = '<div class="chat-loading">It is quiet in here. Say hey.</div>'; return; }
  box.innerHTML = comments.map(comment => {
    const author = comment.author || { username: 'player' };
    const reaction = (comment.reactions || []).find(item => item.emoji?.name === 'heart');
    const count = reaction?.count || 0;
    const mine = !!reaction?.me;
    const date = comment.created_at ? new Date(comment.created_at) : null;
    const time = date && !Number.isNaN(date.valueOf()) ? date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }) : '';
    return '<article class="message" data-comment="' + escapeAttr(comment.id || '') + '"><img class="message-avatar" src="' + escapeAttr(avatarUrl(author)) + '" alt="" loading="lazy"><div class="message-content"><div class="message-top"><a class="message-name" href="#profile" data-user="' + escapeAttr(author.username || '') + '">@' + escapeHtml(author.username || 'player') + '</a><time class="message-time">' + escapeHtml(time) + '</time></div><p class="message-text">' + escapeHtml(comment.raw_content || '') + '</p><div class="message-actions"><button class="message-heart" type="button" data-comment-heart="' + escapeAttr(comment.id || '') + '" aria-pressed="' + mine + '" aria-label="Heart message"><b>♥</b> <em>' + count + '</em></button></div></div></article>';
  }).join('');
  box.scrollTop = box.scrollHeight;
}
async function loadChat() {
  try {
    const page = await window.websim.getComments({ first: 40 });
    state.comments = (page.comments || []).map(unwrapComment).reverse();
    renderMessages();
  } catch {
    $('#messages').innerHTML = '<div class="chat-loading">Lobby chat is unavailable right now.</div>';
    $('#chat-count').textContent = 'OFFLINE';
  }
}
async function sendMessage(event) {
  event.preventDefault();
  const input = $('#chat-input'); const content = input.value.trim();
  if (!content) return;
  input.disabled = true;
  try {
    const result = await window.websim.postComment({ content });
    if (result?.error) throw new Error(result.error);
    if (result?.comment) { state.comments.push(unwrapComment(result.comment)); renderMessages(); }
    input.value = '';
  } catch (error) { toast(error.message || 'Could not send that message.'); }
  finally { input.disabled = false; input.focus(); }
}
async function heartMessage(id) {
  const comment = state.comments.find(item => item.id === id);
  if (!comment || !window.websim.reactToComment) { toast('Hearts are unavailable right now.'); return; }
  const already = (comment.reactions || []).some(item => item.emoji?.name === 'heart' && item.me);
  try {
    const result = await window.websim.reactToComment({ comment_id: id, emoji: 'heart', remove: already });
    if (result?.error) { toast(result.error); return; }
    const updated = unwrapComment(result.comment);
    state.comments = state.comments.map(item => item.id === id ? updated : item);
    renderMessages();
  } catch (error) { toast(error.message || 'Could not heart that message.'); }
}

$('#search-form').addEventListener('submit', event => { event.preventDefault(); loadUser($('#search-input').value); });
$('#credit-button').addEventListener('click', async () => {
  try {
    const result = await window.websim.postComment({ content: 'Thanks for supporting Carnblox!', credits: 10 });
    if (result?.error) toast(result.error);
    else toast('Confirm your credit tip in the Websim composer.');
  } catch (error) { toast(error.message || 'The credit composer is unavailable right now.'); }
});
$('#add-friend').addEventListener('click', addFriend);
$('#add-friend-shortcut').addEventListener('click', () => { $('#search-input').focus(); $('#search-input').placeholder = 'Type a username, then press enter'; });
$('#me-chip').addEventListener('click', () => state.me && setProfile(state.me));
$('#share-profile').addEventListener('click', async () => {
  if (!state.profile) return;
  const link = 'https://websim.com/@' + state.profile.username;
  try { await navigator.clipboard.writeText(link); toast('Profile link copied.'); }
  catch { toast(link); }
});
$('#project-grid').addEventListener('click', event => {
  const button = event.target.closest('[data-love]'); if (!button) return;
  const id = button.dataset.love;
  state.loved.has(id) ? state.loved.delete(id) : state.loved.add(id);
  save(); renderProjects();
});
$('#friends-list').addEventListener('click', event => {
  const link = event.target.closest('[data-user]'); if (link) { event.preventDefault(); loadUser(link.dataset.user); }
});
$('#messages').addEventListener('click', event => {
  const heart = event.target.closest('[data-comment-heart]'); if (heart) heartMessage(heart.dataset.commentHeart);
  const user = event.target.closest('[data-user]'); if (user) { event.preventDefault(); loadUser(user.dataset.user); }
});
$('#chat-form').addEventListener('submit', sendMessage);
if (window.websim?.addEventListener) {
  window.websim.addEventListener('comment:created', event => {
    const comment = unwrapComment(event?.comment || event?.detail?.comment);
    if (comment?.id && !state.comments.some(item => item.id === comment.id)) { state.comments.push(comment); renderMessages(); }
  });
}

async function start() {
  const saved = readSaved();
  state.friends = Array.isArray(saved.friends) ? saved.friends : [];
  state.loved = new Set(Array.isArray(saved.loved) ? saved.loved.map(String) : []);
  try { state.me = await window.websim.getUser(); } catch { state.me = null; }
  const signedIn = !!(state.me?.username && state.me.username !== 'anonymous');
  $('#sign-in-link').hidden = signedIn;
  $('#me-chip').hidden = !signedIn;
  if (signedIn) {
    $('#me-name').textContent = '@' + state.me.username;
    $('#me-avatar').src = avatarUrl(state.me);
    setProfile(state.me);
    loadFriends();
  } else {
    $('#me-name').textContent = 'Websim player';
    $('#welcome-copy').textContent = 'WELCOME TO YOUR LITTLE CORNER';
    $('#profile-status').textContent = 'Sign in to Websim to load your player profile.';
    renderFriends();
  }
  await loadChat();
}
start();
