
let products=JSON.parse(localStorage.getItem('products')||'[]');
function addProduct(){
 let f=document.getElementById('img').files[0];
 if(!f){alert('اختر صورة');return;}
 let r=new FileReader();
 r.onload=()=>{products.push({img:r.result,name:name.value,price:price.value});
 localStorage.setItem('products',JSON.stringify(products));show();}
 r.readAsDataURL(f);
}
function show(){
 document.getElementById('products').innerHTML=products.map(p=>`
 <div class="card"><img src="${p.img}"><h3>${p.name}</h3><p>${p.price}</p><button>طلب</button></div>`).join('');
}
show();
