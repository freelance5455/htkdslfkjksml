const chat=document.getElementById('chat');
const input=document.getElementById('command');
const form=document.getElementById('commandForm');
const historyKey='smart_activity';

function add(text,who='bot'){
  const el=document.createElement('div');
  el.className='msg '+who;
  el.textContent=text;
  chat.appendChild(el);
  chat.scrollTop=chat.scrollHeight;
  if(who==='user'){
    const h=JSON.parse(localStorage.getItem(historyKey)||'[]');
    h.push({time:new Date().toISOString(),command:text});
    localStorage.setItem(historyKey,JSON.stringify(h.slice(-100)));
  }
}
function respond(raw){
  const c=raw.toLowerCase().trim();
  if(!c)return;
  if(c.includes('help')){
    add('Try commands such as:\n• Open settings\n• Open my apps\n• Show activity\n• Check permissions\n• What can you do?');
  }else if(c.includes('permission')){
    add('Smart needs Android permissions for advanced phone actions. This web package can explain and prepare the action, but Android system permissions must be granted by you.');
  }else if(c.includes('setting')){
    add('Open your Android Settings and grant Smart the permissions requested by the native Smart version. This browser package cannot grant Android permissions itself.');
  }else if(c.includes('activity')||c.includes('history')){
    const h=JSON.parse(localStorage.getItem(historyKey)||'[]');
    add(h.length?('Recent commands:\n'+h.slice(-8).map(x=>'• '+x.command).join('\n')):'No activity yet.');
  }else if(c.includes('app')){
    add('Smart can be extended to launch installed apps in the native Android version. A web-only APK wrapper cannot directly launch arbitrary Android apps.');
  }else{
    add('I understood: “'+raw+'”. The web version is ready for your command, but direct phone control requires the native Android Accessibility/permission layer.');
  }
}
form.addEventListener('submit',e=>{e.preventDefault();const v=input.value.trim();if(!v)return;add(v,'user');input.value='';setTimeout(()=>respond(v),250)});
document.querySelectorAll('[data-command]').forEach(b=>b.addEventListener('click',()=>{const v=b.dataset.command;add(v,'user');setTimeout(()=>respond(v),200)}));
