/* BFF – ortak uygulama çekirdeği.
   Veriler tarayıcıda (localStorage) tutulur; backend gerekmez.
   Aynı tarayıcıdaki iki hesap (iki sekme) birbirine gerçekten mesaj atabilir. */
(function () {
  'use strict';

  var DB_KEY = 'bff.db.v1';
  var SESS_KEY = 'bff.session';

  /* ---------- yardımcılar ---------- */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function rid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function slug(s) {
    var map = { 'ç': 'c', 'ğ': 'g', 'ı': 'i', 'ö': 'o', 'ş': 's', 'ü': 'u', 'Ç': 'c', 'Ğ': 'g', 'İ': 'i', 'I': 'i', 'Ö': 'o', 'Ş': 's', 'Ü': 'u' };
    return String(s).replace(/[çğıöşüÇĞİIÖŞÜ]/g, function (c) { return map[c]; }).toLowerCase().replace(/[^a-z0-9_.]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 20) || 'kisi';
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmtTime(ts) { var d = new Date(ts); return pad(d.getHours()) + ':' + pad(d.getMinutes()); }
  function dayStart(ts) { var d = new Date(ts); d.setHours(0, 0, 0, 0); return d.getTime(); }
  var MONTHS = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  var DAYS = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
  function fmtDay(ts) {
    var diff = Math.round((dayStart(Date.now()) - dayStart(ts)) / 86400000);
    if (diff <= 0) return 'Bugün';
    if (diff === 1) return 'Dün';
    var d = new Date(ts);
    return d.getDate() + ' ' + MONTHS[d.getMonth()] + (d.getFullYear() !== new Date().getFullYear() ? ' ' + d.getFullYear() : '');
  }
  function fmtListTime(ts) {
    var diff = Math.round((dayStart(Date.now()) - dayStart(ts)) / 86400000);
    if (diff <= 0) return fmtTime(ts);
    if (diff === 1) return 'Dün';
    if (diff < 7) return DAYS[new Date(ts).getDay()];
    var d = new Date(ts);
    return pad(d.getDate()) + '.' + pad(d.getMonth() + 1);
  }
  function fmtRel(ts) {
    var diff = Math.round((dayStart(Date.now()) - dayStart(ts)) / 86400000);
    if (diff <= 0) return 'bugün ' + fmtTime(ts);
    if (diff === 1) return 'dün ' + fmtTime(ts);
    return fmtDay(ts);
  }
  function fmtDur(sec) { sec = Math.max(0, Math.round(sec)); return Math.floor(sec / 60) + ':' + pad(sec % 60); }
  function fmtSize(b) { return b < 1024 ? b + ' B' : b < 1048576 ? Math.round(b / 1024) + ' KB' : (b / 1048576).toFixed(1) + ' MB'; }

  /* ---------- veri katmanı ---------- */
  function emptyDB() { return { users: {}, friends: {}, convs: {}, notifs: {}, shares: {} }; }
  function load() {
    try {
      var d = JSON.parse(localStorage.getItem(DB_KEY));
      if (d && d.users) {
        ['friends', 'convs', 'notifs', 'shares'].forEach(function (k) { if (!d[k]) d[k] = {}; });
        return d;
      }
    } catch (e) {}
    return emptyDB();
  }
  var db = load();
  var listeners = [];
  var lastOk = true;
  function emit() { listeners.slice().forEach(function (fn) { try { fn(); } catch (e) { console.error(e); } }); }
  function storageOk() {
    try { localStorage.setItem('__bff_t', '1'); localStorage.removeItem('__bff_t'); return true; } catch (e) { return false; }
  }
  function persisted(id) {
    try { var d = JSON.parse(localStorage.getItem(DB_KEY)); return !!(d && d.users && d.users[id]); } catch (e) { return false; }
  }
  function envWarning() {
    if (!storageOk()) return 'Tarayıcın veri depolamasını engelliyor (gizli sekme veya çerez/site verisi kapalı olabilir). Hesap oluşturmak için bunu açman ya da normal bir sekmede denemen gerekiyor.';
    if (location.protocol === 'file:' && !window.chrome) return 'Bu sayfayı dosya olarak açtın. Bu tarayıcıda sayfalar birbirinin verisini göremeyebilir; baslat.bat / baslat.sh ile açman veya Chrome kullanman önerilir.';
    return null;
  }
  function save() {
    try { localStorage.setItem(DB_KEY, JSON.stringify(db)); return true; }
    catch (e) {
      toast(storageOk() ? 'Depolama alanı dolu. Eski medya mesajlarını silmeyi dene.' : 'Tarayıcı veri depolamasını engelliyor, kaydedilemedi.', 'error');
      return false;
    }
  }
  function tx(fn) {
    db = load();
    var r;
    try { r = fn(db); } catch (e) { db = load(); throw e; }
    lastOk = save();
    if (!lastOk) db = load();
    emit();
    return r;
  }
  window.addEventListener('storage', function (e) {
    if (e.key === DB_KEY) { db = load(); emit(); }
  });

  /* ---------- oturum ---------- */
  function readSid() {
    try { return sessionStorage.getItem(SESS_KEY) || localStorage.getItem(SESS_KEY); } catch (e) { return null; }
  }
  var SID = readSid();
  function setSession(id, remember) {
    try { sessionStorage.removeItem(SESS_KEY); localStorage.removeItem(SESS_KEY); } catch (e) {}
    var ok = false;
    try { (remember ? localStorage : sessionStorage).setItem(SESS_KEY, id); ok = true; } catch (e) {}
    if (!ok) { try { sessionStorage.setItem(SESS_KEY, id); ok = true; } catch (e) {} }
    SID = id;
    return ok && readSid() === id;
  }
  function logout() {
    try { sessionStorage.removeItem(SESS_KEY); localStorage.removeItem(SESS_KEY); } catch (e) {}
    SID = null;
    window.location.href = 'login.html';
  }
  function me() { return SID && db.users[SID] ? db.users[SID] : null; }

  /* ---------- şifre / TOTP ---------- */
  function cyrb(s) {
    var h1 = 0xdeadbeef, h2 = 0x41c6ce57, ch;
    for (var i = 0; i < s.length; i++) {
      ch = s.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
  }
  function hashPw(pw, salt) {
    var data = salt + ':' + pw;
    if (window.crypto && crypto.subtle) {
      return crypto.subtle.digest('SHA-256', new TextEncoder().encode(data)).then(function (b) {
        return 's:' + Array.prototype.map.call(new Uint8Array(b), function (x) { return pad2(x.toString(16)); }).join('');
      }, function () { return 'c:' + cyrb(data); });
    }
    return Promise.resolve('c:' + cyrb(data));
  }
  function pad2(h) { return h.length < 2 ? '0' + h : h; }
  var B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  function b32dec(s) {
    var bits = '', out = [], i;
    s = s.replace(/=+$/, '').toUpperCase();
    for (i = 0; i < s.length; i++) { var v = B32.indexOf(s[i]); if (v >= 0) bits += ('00000' + v.toString(2)).slice(-5); }
    for (i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2));
    return new Uint8Array(out);
  }
  function newSecret() {
    var a = new Uint8Array(16), s = '', i;
    (window.crypto || {}).getRandomValues ? crypto.getRandomValues(a) : a.forEach(function (_, k) { a[k] = Math.floor(Math.random() * 256); });
    for (i = 0; i < 16; i++) s += B32[a[i] % 32];
    return s;
  }
  function totp(secret, t) {
    var counter = Math.floor((t || Date.now()) / 30000);
    var buf = new ArrayBuffer(8), dv = new DataView(buf);
    dv.setUint32(0, Math.floor(counter / 4294967296)); dv.setUint32(4, counter >>> 0);
    return crypto.subtle.importKey('raw', b32dec(secret), { name: 'HMAC', hash: 'SHA-1' }, false, ['sign'])
      .then(function (k) { return crypto.subtle.sign('HMAC', k, buf); })
      .then(function (sig) {
        var h = new Uint8Array(sig), o = h[19] & 15;
        var code = (((h[o] & 0x7f) << 24) | (h[o + 1] << 16) | (h[o + 2] << 8) | h[o + 3]) % 1000000;
        return ('000000' + code).slice(-6);
      });
  }
  function verifyTotp(secret, code) {
    if (!(window.crypto && crypto.subtle)) return Promise.resolve(false);
    code = String(code).replace(/\s/g, '');
    var now = Date.now();
    return Promise.all([-1, 0, 1].map(function (d) { return totp(secret, now + d * 30000); }))
      .then(function (codes) { return codes.indexOf(code) >= 0; });
  }
  function totpSupported() { return !!(window.crypto && crypto.subtle); }

  /* ---------- hesap işlemleri ---------- */
  function usernameValid(u) { return /^[a-z0-9_.]{3,20}$/i.test(u); }
  function usernameAvailable(u, exceptId) {
    u = String(u || '').trim().toLowerCase();
    if (!usernameValid(u)) return false;
    return !Object.keys(db.users).some(function (id) { return id !== exceptId && db.users[id].username === u; });
  }
  function signup(d) {
    var salt = rid();
    return hashPw(d.password, salt).then(function (h) {
      return tx(function (db) {
        var un = d.username.trim().toLowerCase(), em = d.email.trim().toLowerCase();
        Object.keys(db.users).forEach(function (id) {
          if (db.users[id].username === un) throw new Error('Bu kullanıcı adı alınmış.');
          if (db.users[id].email === em) throw new Error('Bu e-posta ile zaten bir hesap var.');
        });
        var id = 'u_' + rid();
        db.users[id] = {
          id: id, name: d.name.trim(), username: un, email: em, salt: salt, hash: h,
          avatar: null, bio: '', joined: Date.now(), privacy: 'best', twofa: null, lastSeen: Date.now()
        };
        db.friends[id] = [];
        pushNotif(db, id, { type: 'welcome', text: 'Aramıza hoş geldin! Arkadaş ekleyerek başlayabilirsin.' });
        return id;
      });
    }).then(function (id) {
      if (!lastOk || !persisted(id)) throw new Error('Hesap kaydedilemedi: tarayıcı veri depolamasına izin vermiyor. Gizli sekmede değilsen site verilerine izin ver ve tekrar dene.');
      return id;
    });
  }
  function checkLogin(identifier, pw) {
    var q = identifier.trim().replace(/^@/, '').toLowerCase();
    var u = null;
    Object.keys(db.users).forEach(function (id) {
      if (db.users[id].username === q || db.users[id].email === q) u = db.users[id];
    });
    if (!u) return Promise.reject(new Error('Kullanıcı adı/e-posta veya şifre hatalı.'));
    return hashPw(pw, u.salt).then(function (h) {
      if (h !== u.hash) throw new Error('Kullanıcı adı/e-posta veya şifre hatalı.');
      return u;
    });
  }
  function resetPassword(email, newPw) {
    var salt = rid();
    return hashPw(newPw, salt).then(function (h) {
      return tx(function (db) {
        var q = email.trim().toLowerCase(), found = null;
        Object.keys(db.users).forEach(function (id) { if (db.users[id].email === q) found = db.users[id]; });
        if (!found) throw new Error('Bu e-posta ile kayıtlı hesap bulunamadı.');
        found.salt = salt; found.hash = h;
      });
    });
  }
  function changePassword(oldPw, newPw) {
    var u = me();
    return hashPw(oldPw, u.salt).then(function (h) {
      if (h !== u.hash) throw new Error('Mevcut şifre yanlış.');
      var salt = rid();
      return hashPw(newPw, salt).then(function (nh) {
        tx(function (db) { var x = db.users[SID]; x.salt = salt; x.hash = nh; });
      });
    });
  }
  function updateProfile(patch) {
    return tx(function (db) {
      var u = db.users[SID];
      if (patch.username != null) {
        var un = patch.username.trim().toLowerCase();
        if (!usernameValid(un)) throw new Error('Kullanıcı adı 3-20 karakter olmalı (harf, rakam, _ ve .).');
        Object.keys(db.users).forEach(function (id) { if (id !== SID && db.users[id].username === un) throw new Error('Bu kullanıcı adı alınmış.'); });
        u.username = un;
      }
      if (patch.name != null) { if (patch.name.trim().length < 2) throw new Error('Ad en az 2 karakter olmalı.'); u.name = patch.name.trim(); }
      ['bio', 'avatar', 'privacy', 'twofa'].forEach(function (k) { if (k in patch) u[k] = patch[k]; });
    });
  }
  function touch() {
    var d = load();
    if (SID && d.users[SID]) { d.users[SID].lastSeen = Date.now(); db = d; save(); }
  }

  /* ---------- avatar ---------- */
  var PALETTE = ['#F26A4F', '#E8A800', '#2F8F69', '#7C5CE0', '#E0705A', '#3B82C4'];
  function avatar(ent) {
    if (ent && ent.avatar) return ent.avatar;
    var name = (ent && ent.name) || '?';
    var key = (ent && (ent.id || ent.name)) || name, h = 0, i;
    for (i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
    var parts = name.trim().split(/\s+/);
    var ini = ((parts[0] || '?')[0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toLocaleUpperCase('tr-TR');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" fill="' + PALETTE[h % PALETTE.length] + '"/><text x="48" y="50" text-anchor="middle" dominant-baseline="central" font-family="Nunito,Arial,sans-serif" font-weight="800" font-size="38" fill="#fff">' + esc(ini) + '</text></svg>';
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
  }
  function resizeImage(file, max, quality) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onerror = function () { reject(new Error('Dosya okunamadı.')); };
      fr.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error('Görsel açılamadı.')); };
        img.onload = function () {
          var s = Math.min(1, max / Math.max(img.width, img.height));
          var c = document.createElement('canvas');
          c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
          c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', quality || 0.75));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }
  function cropSquare(file, size) {
    return new Promise(function (resolve, reject) {
      var fr = new FileReader();
      fr.onerror = function () { reject(new Error('Dosya okunamadı.')); };
      fr.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error('Görsel açılamadı.')); };
        img.onload = function () {
          var s = Math.min(img.width, img.height);
          var c = document.createElement('canvas'); c.width = c.height = size;
          c.getContext('2d').drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
          resolve(c.toDataURL('image/jpeg', 0.85));
        };
        img.src = fr.result;
      };
      fr.readAsDataURL(file);
    });
  }

  /* ---------- arkadaşlar ---------- */
  function rawFriends() { return db.friends[SID] || []; }
  function friendView(f) {
    var u = f.linked ? db.users[f.id] : null;
    var name = u ? u.name : f.name, username = u ? u.username : f.username, av = u ? u.avatar : f.avatar;
    var online = !!u && Date.now() - (u.lastSeen || 0) < 25000;
    var status = !f.linked ? 'Kayıtlı kullanıcı değil' : !u ? 'Hesap silinmiş' : online ? 'Çevrimiçi' : (u.lastSeen ? 'Son görülme ' + fmtRel(u.lastSeen) : 'Çevrimdışı');
    return { id: f.id, linked: !!u, name: name, username: username, avatar: av, online: online, status: status, best: !!f.best, addedAt: f.addedAt };
  }
  function friends() { return rawFriends().map(friendView); }
  function friendById(id) {
    var f = rawFriends().filter(function (x) { return x.id === id; })[0];
    return f ? friendView(f) : null;
  }
  function findUser(d, q) {
    q = q.trim().replace(/^@/, '').toLowerCase();
    var found = null;
    Object.keys(d.users).forEach(function (id) { if (d.users[id].username === q || d.users[id].email === q) found = d.users[id]; });
    return found;
  }
  function pushNotif(d, uid, n) {
    var list = d.notifs[uid] = d.notifs[uid] || [];
    n.id = rid(); n.ts = Date.now(); n.read = false;
    list.unshift(n);
    if (list.length > 40) list.length = 40;
  }
  function addFriend(raw, opts) {
    raw = (raw || '').trim();
    if (!raw) throw new Error('Bir kullanıcı adı veya isim yaz.');
    return tx(function (d) {
      var list = d.friends[SID] = d.friends[SID] || [];
      var u = findUser(d, raw);
      if (u) {
        if (u.id === SID) throw new Error('Kendini arkadaş olarak ekleyemezsin.');
        if (list.some(function (f) { return f.id === u.id; })) throw new Error(u.name + ' zaten arkadaş listende.');
        list.push({ id: u.id, linked: true, best: false, addedAt: Date.now() });
        var other = d.friends[u.id] = d.friends[u.id] || [];
        if (!other.some(function (f) { return f.id === SID; })) other.push({ id: SID, linked: true, best: false, addedAt: Date.now() });
        pushNotif(d, u.id, { type: 'friend', from: SID, text: d.users[SID].name + ' seni arkadaş olarak ekledi.' });
        return { id: u.id, linked: true, name: u.name };
      }
      if (!opts || !opts.local) { var e = new Error('NOT_FOUND'); e.code = 'NOT_FOUND'; throw e; }
      var name = raw.replace(/^@/, '');
      if (list.some(function (f) { return !f.linked && f.name.toLowerCase() === name.toLowerCase(); })) throw new Error(name + ' zaten arkadaş listende.');
      var c = { id: 'c_' + rid(), linked: false, name: name, username: slug(name), best: false, addedAt: Date.now() };
      list.push(c);
      return { id: c.id, linked: false, name: name };
    });
  }
  function removeFriend(id) {
    tx(function (d) {
      d.friends[SID] = (d.friends[SID] || []).filter(function (f) { return f.id !== id; });
      if (id.indexOf('c_') !== 0) {
        d.friends[id] = (d.friends[id] || []).filter(function (f) { return f.id !== SID; });
      }
      delete d.convs[convId(id)];
    });
  }
  function toggleBest(id) {
    tx(function (d) {
      (d.friends[SID] || []).forEach(function (f) { if (f.id === id) f.best = !f.best; });
    });
  }

  /* ---------- sohbet ---------- */
  function convId(fid) { return fid.indexOf('c_') === 0 ? 'l~' + SID + '~' + fid : [SID, fid].sort().join('~'); }
  function msgs(fid) { return db.convs[convId(fid)] || []; }
  function lastMsg(fid) { var m = msgs(fid); return m.length ? m[m.length - 1] : null; }
  function unread(fid) {
    return msgs(fid).filter(function (m) { return m.from !== SID && !m.read; }).length;
  }
  function totalUnread() {
    return rawFriends().reduce(function (n, f) { return n + (unread(f.id) ? 1 : 0); }, 0);
  }
  function sendMsg(fid, m) {
    if (!friendById(fid)) return null;
    m.id = rid(); m.from = SID; m.ts = Date.now(); m.read = (m.type === 'call');
    tx(function (d) { var id = convId(fid); (d.convs[id] = d.convs[id] || []).push(m); });
    return lastOk ? m : null;
  }
  function markRead(fid) {
    if (!unread(fid)) return;
    tx(function (d) {
      (d.convs[convId(fid)] || []).forEach(function (m) { if (m.from !== SID) m.read = true; });
    });
  }
  function deleteMsg(fid, id) {
    tx(function (d) {
      var k = convId(fid);
      d.convs[k] = (d.convs[k] || []).filter(function (m) { return !(m.id === id && m.from === SID); });
    });
  }
  function clearChat(fid) { tx(function (d) { delete d.convs[convId(fid)]; }); }

  /* ---------- bildirimler ---------- */
  function notifs() { return db.notifs[SID] || []; }
  function unreadNotifCount() {
    return notifs().filter(function (n) { return !n.read; }).length + totalUnread();
  }
  function markNotifsRead() {
    if (!notifs().some(function (n) { return !n.read; })) return;
    tx(function (d) { (d.notifs[SID] || []).forEach(function (n) { n.read = true; }); });
  }

  /* ---------- canlı konum ---------- */
  function myShare() { var s = db.shares[SID]; return s && s.until > Date.now() ? s : null; }
  function shareOf(uid) { var s = db.shares[uid]; return s && s.until > Date.now() ? s : null; }
  function canSee(viewerId, sharerId) {
    var u = db.users[sharerId];
    if (!u || u.privacy === 'ghost') return false;
    var f = (db.friends[sharerId] || []).filter(function (x) { return x.id === viewerId; })[0];
    if (!f) return false;
    return u.privacy === 'all' ? true : !!f.best;
  }
  function getPosition() {
    return new Promise(function (resolve, reject) {
      if (!navigator.geolocation) return reject(new Error('Bu cihaz konumu desteklemiyor.'));
      navigator.geolocation.getCurrentPosition(function (p) {
        resolve({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy });
      }, function (err) {
        reject(new Error(err.code === 1 ? 'Konum izni verilmedi. Tarayıcı ayarlarından izin ver.' : err.code === 3 ? 'Konum alınamadı (zaman aşımı).' : 'Konum alınamadı.'));
      }, { enableHighAccuracy: true, timeout: 12000, maximumAge: 20000 });
    });
  }
  function startShare(minutes, pos) {
    tx(function (d) {
      d.shares[SID] = { until: Date.now() + minutes * 60000, lat: pos.lat, lng: pos.lng, updated: Date.now(), started: Date.now() };
    });
    watchStart();
  }
  function stopShare() {
    tx(function (d) {
      delete d.shares[SID];
      Object.keys(d.convs).forEach(function (k) {
        d.convs[k].forEach(function (m) { if (m.type === 'location' && m.from === SID) m.ended = true; });
      });
    });
    watchStop();
  }
  var watchId = null;
  function watchStart() {
    if (watchId != null || !navigator.geolocation || !myShare()) return;
    watchId = navigator.geolocation.watchPosition(function (p) {
      var d = load(), s = d.shares[SID];
      if (!s || s.until <= Date.now()) return;
      s.lat = p.coords.latitude; s.lng = p.coords.longitude; s.updated = Date.now();
      db = d; save();
    }, function () {}, { enableHighAccuracy: true, maximumAge: 15000 });
  }
  function watchStop() { if (watchId != null && navigator.geolocation) navigator.geolocation.clearWatch(watchId); watchId = null; }
  function distance(a, b) {
    var R = 6371000, r = Math.PI / 180;
    var dLat = (b.lat - a.lat) * r, dLng = (b.lng - a.lng) * r;
    var x = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return 2 * R * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  }
  function fmtDist(m) { return m < 1000 ? Math.round(m) + ' m' : (m / 1000).toFixed(1) + ' km'; }
  function osmEmbed(lat, lng, d) {
    d = d || 0.006;
    return 'https://www.openstreetmap.org/export/embed.html?bbox=' + [lng - d, lat - d, lng + d, lat + d].join('%2C') + '&layer=mapnik&marker=' + lat + '%2C' + lng;
  }
  function osmLink(lat, lng) { return 'https://www.openstreetmap.org/?mlat=' + lat + '&mlon=' + lng + '#map=17/' + lat + '/' + lng; }

  /* ---------- arayüz parçaları ---------- */
  var toastTimer;
  function toast(msg, type) {
    var el = $('#app-toast');
    if (!el) {
      el = document.createElement('div'); el.id = 'app-toast';
      el.className = 'fixed top-4 left-1/2 -translate-x-1/2 z-[80] max-w-[92vw] px-4 py-2.5 rounded-2xl text-sm font-bold shadow-lg border transition-opacity';
      el.setAttribute('role', 'status');
      document.body.appendChild(el);
    }
    el.className = el.className.replace(/ ?(bg-\S+|text-\S+|border-\S+)/g, '').trim() + ' ' +
      (type === 'error' ? 'bg-destructive text-primary-foreground border-destructive' : 'bg-foreground text-background border-foreground');
    el.textContent = msg; el.style.opacity = '1'; el.style.pointerEvents = 'none';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.style.opacity = '0'; }, 2600);
  }
  function sheet(html, opts) {
    opts = opts || {};
    var root = document.createElement('div');
    root.className = 'fixed inset-0 z-50 flex items-end sm:items-center justify-center';
    root.innerHTML = '<div data-close class="absolute inset-0 bg-black/50"></div>' +
      '<div class="relative w-full ' + (opts.wide ? 'max-w-lg' : 'max-w-md') + ' bg-card text-card-foreground rounded-t-3xl sm:rounded-3xl border border-border p-5 pb-6 max-h-[88vh] overflow-y-auto shadow-xl">' + html + '</div>';
    document.body.appendChild(root);
    function onKey(e) { if (e.key === 'Escape') close(); }
    function close() { document.removeEventListener('keydown', onKey); if (root.parentNode) root.parentNode.removeChild(root); if (opts.onClose) opts.onClose(); }
    document.addEventListener('keydown', onKey);
    root.addEventListener('click', function (e) { if (e.target.closest('[data-close]')) close(); });
    var first = $('input,textarea,button[data-autofocus]', root); if (first && !opts.noFocus) setTimeout(function () { first.focus(); }, 30);
    return { el: root, close: close, $: function (s) { return $(s, root); } };
  }
  function sheetHeader(title, sub) {
    return '<div class="flex items-start justify-between gap-3 mb-4"><div><h3 class="font-heading text-lg font-extrabold leading-tight">' + esc(title) + '</h3>' +
      (sub ? '<p class="text-xs text-muted-foreground font-semibold mt-0.5">' + sub + '</p>' : '') +
      '</div><button type="button" data-close class="size-9 shrink-0 rounded-full bg-input border border-border flex items-center justify-center" aria-label="Kapat"><iconify-icon icon="solar:close-circle-bold" width="20" height="20"></iconify-icon></button></div>';
  }
  function confirmDialog(title, text, okLabel, danger) {
    return new Promise(function (resolve) {
      var done = false;
      var s = sheet(sheetHeader(title) + '<p class="text-sm text-muted-foreground mb-5">' + esc(text) + '</p>' +
        '<div class="grid grid-cols-2 gap-3"><button type="button" data-close class="h-12 rounded-2xl bg-input border border-border font-extrabold text-sm">Vazgeç</button>' +
        '<button type="button" data-ok class="h-12 rounded-2xl ' + (danger ? 'bg-destructive' : 'bg-primary') + ' text-primary-foreground font-extrabold text-sm">' + esc(okLabel || 'Tamam') + '</button></div>',
        { noFocus: true, onClose: function () { if (!done) { done = true; resolve(false); } } });
      s.$('[data-ok]').addEventListener('click', function () { done = true; s.close(); resolve(true); });
    });
  }
  function actionSheet(title, items) {
    var html = sheetHeader(title) + '<div class="space-y-2">' + items.map(function (it, i) {
      return '<button type="button" data-act="' + i + '" class="w-full h-12 rounded-2xl bg-input border border-border px-4 flex items-center gap-3 text-sm font-extrabold ' + (it.danger ? 'text-destructive' : '') + '"><iconify-icon icon="' + it.icon + '" width="20" height="20"></iconify-icon>' + esc(it.label) + '</button>';
    }).join('') + '</div>';
    var s = sheet(html, { noFocus: true });
    s.el.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]'); if (!b) return;
      s.close(); items[+b.getAttribute('data-act')].run();
    });
    return s;
  }
  function infoSheet(title, html) {
    return sheet(sheetHeader(title) + '<div class="text-sm text-muted-foreground space-y-3 leading-relaxed">' + html + '</div>', { noFocus: true });
  }

  /* kişi ekle */
  function openAddFriend(onDone) {
    var u = me();
    var s = sheet(sheetHeader('Arkadaş ekle', 'Kullanıcı adı veya e-posta ile ara') +
      '<form id="af-form" class="space-y-3" novalidate>' +
      '<div class="relative"><iconify-icon icon="solar:user-plus-bold" class="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" width="20" height="20"></iconify-icon>' +
      '<input id="af-input" type="text" autocomplete="off" autocapitalize="none" placeholder="@kullanici_adi" class="w-full h-13 rounded-2xl bg-input border border-border pl-12 pr-4 text-sm font-semibold outline-none focus:ring-2 focus:ring-ring" /></div>' +
      '<p id="af-err" class="hidden text-xs font-bold text-destructive"></p>' +
      '<div id="af-local" class="hidden rounded-2xl bg-secondary/30 border border-border p-3 space-y-2"><p class="text-xs font-semibold" id="af-local-text"></p>' +
      '<button type="button" id="af-local-btn" class="w-full h-10 rounded-xl bg-secondary text-secondary-foreground text-xs font-extrabold">Yine de kişi olarak ekle</button></div>' +
      '<button type="submit" class="w-full h-13 rounded-2xl bg-primary text-primary-foreground font-extrabold flex items-center justify-center gap-2"><iconify-icon icon="solar:user-plus-bold" width="20" height="20"></iconify-icon>Ekle</button>' +
      '</form>' +
      '<div class="mt-4 flex items-center justify-between rounded-2xl bg-input border border-border px-3.5 py-2.5"><div><p class="text-[11px] font-bold text-muted-foreground">Senin kullanıcı adın</p><p class="text-sm font-extrabold">@' + esc(u.username) + '</p></div>' +
      '<button type="button" id="af-copy" class="h-9 px-3 rounded-xl bg-card border border-border text-xs font-extrabold">Kopyala</button></div>');
    var input = s.$('#af-input'), err = s.$('#af-err'), local = s.$('#af-local');
    function showErr(m) { err.textContent = m; err.classList.toggle('hidden', !m); }
    function finish(r) {
      s.close(); toast(r.name + ' arkadaş listene eklendi 🎉');
      if (onDone) onDone(r);
    }
    s.$('#af-form').addEventListener('submit', function (e) {
      e.preventDefault(); showErr(''); local.classList.add('hidden');
      var raw = input.value.trim();
      try { finish(addFriend(raw)); }
      catch (ex) {
        if (ex.code === 'NOT_FOUND') {
          s.$('#af-local-text').textContent = '“' + raw + '” adıyla kayıtlı bir kullanıcı bulunamadı. Kişi olarak ekleyebilirsin; ancak kayıtlı olmadığı için mesajların ona ulaşmaz.';
          local.classList.remove('hidden');
        } else showErr(ex.message);
      }
    });
    s.$('#af-local-btn').addEventListener('click', function () {
      try { finish(addFriend(input.value.trim(), { local: true })); } catch (ex) { showErr(ex.message); }
    });
    s.$('#af-copy').addEventListener('click', function () { copyText('@' + u.username).then(function () { toast('Kullanıcı adın kopyalandı'); }); });
  }
  function copyText(t) {
    if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(t).catch(function () { return legacyCopy(t); });
    return legacyCopy(t);
  }
  function legacyCopy(t) {
    return new Promise(function (res) {
      var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      ta.remove(); res();
    });
  }
  function openFriendPicker(title) {
    var list = friends();
    if (!list.length) { openAddFriend(function (r) { location.href = 'chat.html?id=' + encodeURIComponent(r.id); }); return; }
    var html = sheetHeader(title || 'Kiminle sohbet edelim?') + '<div class="space-y-2">' + list.map(function (f) {
      return '<a href="chat.html?id=' + encodeURIComponent(f.id) + '" class="flex items-center gap-3 p-2.5 rounded-2xl bg-input border border-border"><img src="' + avatar(f) + '" class="size-11 rounded-full object-cover" alt="" />' +
        '<div class="min-w-0 flex-1"><p class="font-heading font-extrabold text-sm truncate">' + esc(f.name) + '</p><p class="text-[11px] text-muted-foreground font-semibold truncate">' + esc(f.status) + '</p></div></a>';
    }).join('') + '</div><button type="button" id="fp-add" class="w-full h-11 mt-3 rounded-2xl bg-secondary text-secondary-foreground text-sm font-extrabold">+ Yeni arkadaş ekle</button>';
    var s = sheet(html, { noFocus: true });
    s.$('#fp-add').addEventListener('click', function () { s.close(); openAddFriend(function (r) { location.href = 'chat.html?id=' + encodeURIComponent(r.id); }); });
  }

  /* bildirim paneli */
  function openNotifs() {
    var items = [];
    rawFriends().forEach(function (f) {
      var n = unread(f.id); if (!n) return;
      var v = friendView(f), lm = lastMsg(f.id);
      items.push({ ts: lm ? lm.ts : 0, href: 'chat.html?id=' + encodeURIComponent(f.id), icon: 'solar:chat-round-dots-bold', title: v.name, text: n + ' okunmamış mesaj', av: avatar(v) });
    });
    notifs().forEach(function (n) {
      var f = n.from ? db.users[n.from] : null;
      items.push({ ts: n.ts, href: n.type === 'friend' && f ? 'chat.html?id=' + encodeURIComponent(n.from) : null, icon: n.type === 'friend' ? 'solar:user-plus-bold' : 'solar:bell-bing-bold-duotone', title: n.type === 'welcome' ? 'BFF' : (f ? f.name : 'Bildirim'), text: n.text, av: f ? avatar(f) : null, fresh: !n.read });
    });
    items.sort(function (a, b) { return b.ts - a.ts; });
    var body = items.length ? '<div class="space-y-2">' + items.map(function (it) {
      var inner = (it.av ? '<img src="' + it.av + '" class="size-10 rounded-full object-cover shrink-0" alt="" />' : '<div class="size-10 rounded-full bg-primary/15 text-primary flex items-center justify-center shrink-0"><iconify-icon icon="' + it.icon + '" width="20" height="20"></iconify-icon></div>') +
        '<div class="min-w-0 flex-1"><p class="text-sm font-extrabold truncate">' + esc(it.title) + '</p><p class="text-xs text-muted-foreground font-semibold">' + esc(it.text) + '</p></div>' +
        '<span class="text-[10px] font-bold text-muted-foreground shrink-0">' + (it.ts ? fmtListTime(it.ts) : '') + '</span>';
      var cls = 'flex items-center gap-3 p-2.5 rounded-2xl border ' + (it.fresh ? 'bg-primary/10 border-primary/30' : 'bg-input border-border');
      return it.href ? '<a href="' + it.href + '" class="' + cls + '">' + inner + '</a>' : '<div class="' + cls + '">' + inner + '</div>';
    }).join('') + '</div>' : '<div class="text-center py-8"><div class="size-14 rounded-full bg-input mx-auto flex items-center justify-center mb-3"><iconify-icon icon="solar:bell-bing-bold-duotone" width="26" height="26" class="text-muted-foreground"></iconify-icon></div><p class="text-sm font-extrabold">Hiç bildirimin yok</p><p class="text-xs text-muted-foreground font-semibold mt-1">Yeni olaylar burada görünecek.</p></div>';
    sheet(sheetHeader('Bildirimler') + body, { noFocus: true, onClose: function () { markNotifsRead(); } });
  }

  /* alt gezinme */
  function renderNav(active) {
    var el = $('#app-nav'); if (!el) return;
    var items = [
      ['home', 'home.html', 'solar:chat-round-dots-bold', 'Sohbetler'],
      ['friends', 'friends.html', 'solar:users-group-rounded-linear', 'Arkadaşlar'],
      ['map', 'map.html', 'solar:map-point-wave-linear', 'Harita'],
      ['profile', 'profile.html', 'solar:settings-linear', 'Ayarlar']
    ];
    el.className = 'fixed bottom-4 left-4 right-4 max-w-md mx-auto h-[70px] rounded-[24px] bg-card/95 backdrop-blur-md border border-border shadow-sm flex items-center justify-around px-2 z-20';
    function paint() {
      var un = totalUnread();
      el.innerHTML = items.map(function (it) {
        var on = it[0] === active;
        return '<a href="' + it[1] + '" class="relative flex-1 flex flex-col items-center gap-1 ' + (on ? 'text-primary' : 'text-muted-foreground') + '"' + (on ? ' aria-current="page"' : '') + '>' +
          '<iconify-icon icon="' + it[2] + '" width="24" height="24"></iconify-icon><span class="text-[10px] ' + (on ? 'font-extrabold' : 'font-bold') + '">' + it[3] + '</span>' +
          (it[0] === 'home' && un ? '<span class="absolute top-0 left-1/2 ml-2 min-w-4 h-4 px-1 rounded-full bg-primary text-primary-foreground text-[9px] font-extrabold flex items-center justify-center">' + un + '</span>' : '') + '</a>';
      }).join('');
    }
    paint(); onChange(paint);
  }
  function bindBell(btn, badge) {
    function paint() {
      var n = unreadNotifCount();
      badge.textContent = n > 9 ? '9+' : n; badge.style.display = n ? '' : 'none';
    }
    btn.addEventListener('click', openNotifs);
    paint(); onChange(paint);
  }

  function onChange(fn) { listeners.push(fn); }
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }

  /* ---------- sayfa başlatma ---------- */
  function requireAuth() {
    if (!me()) { location.replace('login.html'); return false; }
    return true;
  }
  function redirectIfAuth() {
    if (me()) { location.replace('home.html'); return true; }
    return false;
  }
  function init(opts) {
    opts = opts || {};
    if (opts.auth !== false) {
      if (!requireAuth()) return false;
      touch();
      setInterval(touch, 8000);
      document.addEventListener('visibilitychange', function () { if (!document.hidden) touch(); });
      watchStart();
      setInterval(function () {
        var s = db.shares[SID];
        if (s && s.until <= Date.now()) stopShare();
      }, 15000);
      setInterval(emit, 20000); /* çevrimiçi/son görülme metinlerini tazele */
      if (opts.nav) renderNav(opts.nav);
    }
    return true;
  }

  window.App = {
    $: $, $$: $$, esc: esc, rid: rid, fmtTime: fmtTime, fmtDay: fmtDay, fmtListTime: fmtListTime, fmtRel: fmtRel, fmtDur: fmtDur, fmtSize: fmtSize, dayStart: dayStart,
    init: init, envWarning: envWarning, requireAuth: requireAuth, redirectIfAuth: redirectIfAuth, onChange: onChange, debounce: debounce,
    me: me, setSession: setSession, logout: logout,
    signup: signup, checkLogin: checkLogin, resetPassword: resetPassword, changePassword: changePassword, updateProfile: updateProfile,
    usernameAvailable: usernameAvailable, usernameValid: usernameValid,
    newSecret: newSecret, verifyTotp: verifyTotp, totpSupported: totpSupported,
    avatar: avatar, cropSquare: cropSquare, resizeImage: resizeImage,
    friends: friends, friendById: friendById, addFriend: addFriend, removeFriend: removeFriend, toggleBest: toggleBest,
    msgs: msgs, lastMsg: lastMsg, unread: unread, totalUnread: totalUnread, sendMsg: sendMsg, markRead: markRead, deleteMsg: deleteMsg, clearChat: clearChat,
    notifs: notifs, unreadNotifCount: unreadNotifCount,
    myShare: myShare, shareOf: shareOf, canSee: canSee, getPosition: getPosition, startShare: startShare, stopShare: stopShare,
    distance: distance, fmtDist: fmtDist, osmEmbed: osmEmbed, osmLink: osmLink,
    user: function (id) { return db.users[id] || null; },
    toast: toast, sheet: sheet, sheetHeader: sheetHeader, confirm: confirmDialog, actionSheet: actionSheet, infoSheet: infoSheet,
    openAddFriend: openAddFriend, openFriendPicker: openFriendPicker, openNotifs: openNotifs, bindBell: bindBell, renderNav: renderNav,
    copyText: copyText, db: function () { return db; }
  };
})();
