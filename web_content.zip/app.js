const CATEGORIES = [
 {name:"Granulados", icon:"✦", products:["Pink","Estrela","Red","Juju","Meio amargo","Amendoim","Côco","Cacau em pó"]},
 {name:"Chocolates", icon:"▰", products:["Ao leite para donuts","Ao leite para pipoca","Meio amargo para donuts","Meio amargo para pipoca","Branco para donuts","Branco para pipoca"]},
 {name:"Corantes", icon:"✿", products:["Azul","Rosa","Verde","Roxo","Vermelho"]},
 {name:"Para massa", icon:"♧", products:["Fermento","Açúcar","Manteiga","Ovo"]},
 {name:"Recheios", icon:"♡", products:["Nutella","Doce de leite","Geleia","Açúcar gelado"]},
 {name:"Embalagens", icon:"▤", products:["Copos","Embalagem quadrada","Embalagem duo","Embalagem recheadinho","Embalagem churros"]},
 {name:"Sacolas", icon:"♧", products:["Sacola pequena","Sacola média","Sacola keeta","Sacola 99"]},
 {name:"Utilitários", icon:"✧", products:["Saco de confeiteiro","Saquinho para pipoca","Saquinho para brinde","Saquinho para mini donuts","Saquinho para donuts grande","Fita para brinde"]}
];
const STORAGE_KEY = "doce-estoque-v1";
const allProducts = CATEGORIES.flatMap((cat, ci) => cat.products.map((name, pi) => ({
 id: `${ci}-${pi}`, name, category:cat.name, icon:cat.icon
})));
let quantities = loadQuantities();
let selectedCategory = "Todos";
let editingId = null;
let toastTimer;

function loadQuantities(){
 try { const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}"); return Object.fromEntries(allProducts.map(p => [p.id, Number.isFinite(saved[p.id]) && saved[p.id] >= 0 ? Math.floor(saved[p.id]) : 0])); }
 catch { return Object.fromEntries(allProducts.map(p => [p.id, 0])); }
}
function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(quantities)); }
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderNav(){
 const nav=document.getElementById("categoryNav");
 const names=["Todos",...CATEGORIES.map(c=>c.name)];
 nav.innerHTML=names.map(name=>`<button class="category-chip ${name===selectedCategory?"active":""}" data-category="${escapeHtml(name)}">${name==="Todos"?"Todos os itens":name}</button>`).join("");
 nav.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{selectedCategory=b.dataset.category;renderNav();renderProducts();}));
}
function renderProducts(){
 const query=document.getElementById("search").value.trim().toLocaleLowerCase("pt-BR");
 const products=allProducts.filter(p=>(selectedCategory==="Todos"||p.category===selectedCategory)&&(`${p.name} ${p.category}`).toLocaleLowerCase("pt-BR").includes(query));
 document.getElementById("categoryTitle").textContent=selectedCategory==="Todos"?"Todos os produtos":selectedCategory;
 document.getElementById("itemCount").textContent=`${products.length} ${products.length===1?"item":"itens"}`;
 const list=document.getElementById("productList");
 if(!products.length){list.innerHTML='<div class="empty-state"><strong>Nenhum produto encontrado</strong>Tente outro termo de busca.</div>';return;}
 list.innerHTML=products.map(p=>`<article class="product-card"><div class="product-dot" aria-hidden="true">${p.icon}</div><div class="product-info"><div class="product-name">${escapeHtml(p.name)}</div><div class="product-category">${escapeHtml(p.category)}</div></div><div class="quantity-controls"><button class="step-button" data-action="minus" data-id="${p.id}" aria-label="Diminuir ${escapeHtml(p.name)}">−</button><button class="quantity-value" data-action="edit" data-id="${p.id}" aria-label="Editar quantidade de ${escapeHtml(p.name)}">${quantities[p.id]}</button><button class="step-button plus" data-action="plus" data-id="${p.id}" aria-label="Aumentar ${escapeHtml(p.name)}">+</button></div></article>`).join("");
 list.querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>act(b.dataset.action,b.dataset.id)));
 const total=allProducts.reduce((sum,p)=>sum+quantities[p.id],0);
 const withStock=allProducts.filter(p=>quantities[p.id]>0).length;
 document.getElementById("summary").textContent=`${allProducts.length} produtos · ${withStock} com estoque · ${total} unidades registradas`;
}
function act(action,id){
 if(action==="edit"){openEditor(id);return;}
 const current=quantities[id]||0;
 if(action==="minus"&&current===0){showToast("A quantidade já está em zero.");return;}
 quantities[id]=action==="plus"?current+1:Math.max(0,current-1);
 save();renderProducts();
}
function openEditor(id){
 editingId=id;const p=allProducts.find(x=>x.id===id);
 document.getElementById("dialogTitle").textContent=p.name;
 document.getElementById("quantityInput").value=quantities[id];
 document.getElementById("editDialog").hidden=false;
 setTimeout(()=>{const input=document.getElementById("quantityInput");input.focus();input.select();},30);
}
function closeEditor(){document.getElementById("editDialog").hidden=true;editingId=null;}
function saveEditor(){
 const input=document.getElementById("quantityInput");
 const n=Number(input.value);
 if(input.value.trim()===""||!Number.isFinite(n)||n<0||!Number.isInteger(n)){showToast("Digite um número inteiro igual ou maior que zero.");input.focus();return;}
 quantities[editingId]=n;save();closeEditor();renderProducts();showToast("Quantidade salva.");
}
function showToast(message){
 const t=document.getElementById("toast");t.textContent=message;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),2300);
}
document.getElementById("search").addEventListener("input",renderProducts);
document.getElementById("closeDialog").addEventListener("click",closeEditor);
document.getElementById("cancelEdit").addEventListener("click",closeEditor);
document.getElementById("saveEdit").addEventListener("click",saveEditor);
document.getElementById("quantityInput").addEventListener("keydown",e=>{if(e.key==="Enter")saveEditor();if(e.key==="Escape")closeEditor();});
document.getElementById("editDialog").addEventListener("click",e=>{if(e.target.id==="editDialog")closeEditor();});
document.getElementById("exportBtn").addEventListener("click",()=>{
 const data={exportadoEm:new Date().toISOString(),estoque:allProducts.map(p=>({categoria:p.category,produto:p.name,quantidade:quantities[p.id]}))};
 const blob=new Blob(["\ufeff"+["Categoria;Produto;Quantidade",...data.estoque.map(p=>`${p.categoria};${p.produto};${p.quantidade}`)].join("\n")],{type:"text/csv;charset=utf-8;"});
 const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download="estoque-confeitaria.csv";a.click();URL.revokeObjectURL(url);showToast("Arquivo de estoque exportado.");
});
document.getElementById("resetBtn").addEventListener("click",()=>{
 if(!confirm("Tem certeza de que deseja zerar as quantidades de todos os produtos? Esta ação não pode ser desfeita."))return;
 quantities=Object.fromEntries(allProducts.map(p=>[p.id,0]));save();renderProducts();showToast("Estoque zerado.");
});
if("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
renderNav();renderProducts();