(() => {
'use strict';
const LK = window.LivekitClient, RE = LK.RoomEvent;
const EMOJI = ['🦊','🐼','🐯','🦁','🐸','🐵','🦄','🐲','🤖','👾','🎮','🚀'];
const COLORS = ['#7c3aed','#ff3d9a','#06b6d4','#f59e0b','#10b981','#ef4444','#3b82f6','#a3e635'];

const T = {
  en: { tag:'Talk. Play. Connect.', user:'Username', pass:'Password (min 8)', login:'Log in', register:'Sign up',
    hello:'Hello,', logout:'Log out', avatar:'Your avatar', create:'Create Voice Room', or:'or', code:'Room code',
    join:'Join Room', roomcode:'Room code', share:'Share code', members:'Players', you:'You', host:'Host',
    mute:'Mute', unmute:'Unmute', leave:'Leave', copied:'Code copied!', connecting:'Connecting…', live:'🟢 Live voice chat',
    err_bad_credentials:'Wrong username or password', err_username_taken:'Username already taken',
    err_invalid_input:'Please check your input (username 3-16 letters/numbers/_, password 8+)',
    err_room_not_found:'Room not found or expired', err_room_full:'Room is full', err_rate_limited:'Too many tries, wait a minute',
    err_generic:'Something went wrong. Try again.', err_mic:'Microphone blocked. Allow mic permission.', err_drop:'Disconnected from room' },
  hi: { tag:'बात करो। खेलो। जुड़ो।', user:'यूज़रनेम', pass:'पासवर्ड (कम से कम 8)', login:'लॉग इन', register:'साइन अप',
    hello:'नमस्ते,', logout:'लॉग आउट', avatar:'अपना अवतार चुनो', create:'वॉइस रूम बनाओ', or:'या', code:'रूम कोड',
    join:'रूम जॉइन करो', roomcode:'रूम कोड', share:'कोड शेयर करो', members:'खिलाड़ी', you:'आप', host:'होस्ट',
    mute:'म्यूट', unmute:'अनम्यूट', leave:'बाहर निकलो', copied:'कोड कॉपी हो गया!', connecting:'कनेक्ट हो रहा है…', live:'🟢 लाइव वॉइस चैट',
    err_bad_credentials:'यूज़रनेम या पासवर्ड गलत है', err_username_taken:'यह यूज़रनेम पहले से लिया जा चुका है',
    err_invalid_input:'इनपुट जाँचें (यूज़रनेम 3-16 अक्षर/अंक/_, पासवर्ड 8+)',
    err_room_not_found:'रूम नहीं मिला या खत्म हो गया', err_room_full:'रूम भरा हुआ है', err_rate_limited:'बहुत कोशिशें, एक मिनट रुकें',
    err_generic:'कुछ गड़बड़ हुई। फिर कोशिश करें।', err_mic:'माइक बंद है। माइक की अनुमति दें।', err_drop:'रूम से कनेक्शन टूट गया' }
};

const $ = (s) => document.querySelector(s);
const el = (tag, cls) => { const e = document.createElement(tag); if (cls) e.className = cls; return e; };
const store = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); v === null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch (e) { return null; } };
let lang = store('pm_lang') || ((navigator.language || '').startsWith('hi') ? 'hi' : 'en');
let token = store('pm_token'), me = null, room = null, mode = 'login', hostId = null;
const t = (k) => T[lang][k] || T.en[k] || k;

function applyLang() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i]').forEach((e) => { e.textContent = t(e.dataset.i); });
  $('#a-pass').placeholder = t('pass');
  $('#lang').textContent = lang === 'en' ? 'हिन्दी' : 'English';
  if (room) { renderMembers(); updateMic(); }
}
function show(id) { ['auth', 'home', 'room'].forEach((s) => $('#s-' + s).classList.toggle('hidden', s !== id)); }
let tt; function toast(msg) { const x = $('#toast'); x.textContent = msg; x.classList.add('show'); clearTimeout(tt); tt = setTimeout(() => x.classList.remove('show'), 2800); }
const errText = (e) => t('err_' + e.message) !== 'err_' + e.message ? t('err_' + e.message) : t('err_generic');

async function api(path, method, body) {
  const r = await fetch('/api' + path, {
    method: method || 'GET',
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) { if (r.status === 401 && token) logout(); throw new Error(d.error || 'generic'); }
  return d;
}

/* ---------- auth ---------- */
document.querySelectorAll('.tab').forEach((b) => b.addEventListener('click', () => {
  mode = b.dataset.mode;
  document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x === b));
  $('#auth-go').dataset.i = mode; $('#a-err').textContent = '';
  $('#a-pass').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  applyLang();
}));
$('#auth-form').addEventListener('submit', async (ev) => {
  ev.preventDefault();
  const btn = $('#auth-go'); btn.disabled = true; $('#a-err').textContent = '';
  try {
    const d = await api('/' + mode, 'POST', { username: $('#a-user').value.trim(), password: $('#a-pass').value });
    token = d.token; store('pm_token', token); me = d.user; $('#a-pass').value = ''; goHome();
  } catch (e) { $('#a-err').textContent = errText(e); }
  btn.disabled = false;
});
function logout() { token = null; me = null; store('pm_token', null); leaveRoom(true); show('auth'); }
$('#logout').addEventListener('click', logout);

/* ---------- home & profile ---------- */
function paintAvatar(node, av) { node.textContent = av.emoji; node.style.setProperty('--c', av.color); }
function goHome() {
  $('#h-name').textContent = me.username; paintAvatar($('#h-avatar'), me.avatar); $('#h-err').textContent = '';
  const ep = $('#emojis'), cp = $('#colors'); ep.textContent = ''; cp.textContent = '';
  EMOJI.forEach((em) => { const b = el('button', 'pick' + (em === me.avatar.emoji ? ' sel' : '')); b.type = 'button'; b.textContent = em; b.onclick = () => saveAvatar(em, me.avatar.color); ep.appendChild(b); });
  COLORS.forEach((c) => { const b = el('button', 'swatch' + (c === me.avatar.color ? ' sel' : '')); b.type = 'button'; b.style.background = c; b.onclick = () => saveAvatar(me.avatar.emoji, c); cp.appendChild(b); });
  show('home');
}
async function saveAvatar(emoji, color) {
  try { me = (await api('/me', 'PUT', { emoji, color })).user; goHome(); } catch (e) { toast(errText(e)); }
}
$('#create').addEventListener('click', async () => {
  $('#create').disabled = true;
  try { await enter(await api('/rooms', 'POST')); } catch (e) { $('#h-err').textContent = errText(e); }
  $('#create').disabled = false;
});
$('#join').addEventListener('click', async () => {
  $('#join').disabled = true; $('#h-err').textContent = '';
  try { await enter(await api('/rooms/join', 'POST', { code: $('#code').value })); } catch (e) { $('#h-err').textContent = errText(e); }
  $('#join').disabled = false;
});
$('#code').addEventListener('input', (e) => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); });

/* ---------- LiveKit voice room ---------- */
async function enter(d) {
  leaveRoom(true);
  $('#r-code').textContent = d.code; $('#r-status').textContent = t('connecting'); $('#members').textContent = '';
  show('room');
  const r = new LK.Room({
    audioCaptureDefaults: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    publishDefaults: { dtx: true }
  });
  room = r;
  r.on(RE.TrackSubscribed, (tr) => { if (tr.kind === 'audio') $('#audio-box').appendChild(tr.attach()); })
   .on(RE.TrackUnsubscribed, (tr) => tr.detach().forEach((n) => n.remove()))
   .on(RE.ParticipantConnected, renderMembers)
   .on(RE.ParticipantDisconnected, renderMembers)
   .on(RE.ActiveSpeakersChanged, renderMembers)
   .on(RE.TrackMuted, () => { renderMembers(); updateMic(); })
   .on(RE.TrackUnmuted, () => { renderMembers(); updateMic(); })
   .on(RE.LocalTrackPublished, () => { renderMembers(); updateMic(); })
   .on(RE.MediaDevicesError, () => toast(t('err_mic')))
   .on(RE.Disconnected, () => { if (room === r) { toast(t('err_drop')); leaveRoom(true); goHome(); } });
  try {
    await r.connect(d.url, d.token);
    try { hostId = JSON.parse(r.metadata || '{}').host; } catch (e) { hostId = null; }
    await r.startAudio().catch(() => {});                 // unlock audio playback (inside user gesture)
    $('#r-status').textContent = t('live');
    try { await r.localParticipant.setMicrophoneEnabled(true); } catch (e) { toast(t('err_mic')); }
    renderMembers(); updateMic();
  } catch (e) { leaveRoom(true); goHome(); $('#h-err').textContent = t('err_generic'); }
}

function renderMembers() {
  if (!room) return;
  const box = $('#members'); box.textContent = '';
  const list = [room.localParticipant].concat(Array.from(room.remoteParticipants.values()));
  $('#r-count').textContent = list.length;
  list.forEach((p) => {
    let av = {}; try { av = JSON.parse(p.metadata || '{}'); } catch (e) { /* ignore */ }
    const local = p === room.localParticipant, muted = !p.isMicrophoneEnabled;
    const card = el('div', 'member' + (p.isSpeaking && !muted ? ' speaking' : ''));
    const a = el('div', 'avatar'); paintAvatar(a, { emoji: av.emoji || '🎮', color: av.color || '#7c3aed' });
    const n = el('div', 'mname'); n.textContent = p.name || p.identity;       // textContent => XSS-safe
    const g = el('div', 'mtag'); g.textContent = [local ? t('you') : '', p.identity === hostId ? '👑 ' + t('host') : ''].filter(Boolean).join(' · ');
    card.append(a, n, g);
    if (muted) { const b = el('span', 'mbadge'); b.textContent = '🔇'; card.appendChild(b); }
    box.appendChild(card);
  });
}
function updateMic() {
  const on = !!(room && room.localParticipant.isMicrophoneEnabled);
  $('#mic').classList.toggle('off', !on);
  $('#mic-ico').textContent = on ? '🎙️' : '🔇';
  $('#mic-lbl').textContent = t(on ? 'mute' : 'unmute');
}
$('#mic').addEventListener('click', async () => {
  if (!room) return;
  try { await room.localParticipant.setMicrophoneEnabled(!room.localParticipant.isMicrophoneEnabled); } catch (e) { toast(t('err_mic')); }
  updateMic(); renderMembers();
});
function leaveRoom(silent) {
  const r = room; room = null;
  if (r) r.disconnect();
  $('#audio-box').textContent = '';
  if (!silent) goHome();
}
$('#leave').addEventListener('click', () => leaveRoom(false));
window.addEventListener('pagehide', () => leaveRoom(true));
$('#share').addEventListener('click', async () => {
  const code = $('#r-code').textContent, text = 'PlayMitra: ' + code;
  try { if (navigator.share) { await navigator.share({ text }); return; } } catch (e) { /* fall through */ }
  try { await navigator.clipboard.writeText(code); toast(t('copied')); }
  catch (e) { const i = el('input'); i.value = code; document.body.appendChild(i); i.select(); document.execCommand('copy'); i.remove(); toast(t('copied')); }
});
$('#lang').addEventListener('click', () => { lang = lang === 'en' ? 'hi' : 'en'; store('pm_lang', lang); applyLang(); });

/* ---------- boot ---------- */
(async () => {
  applyLang();
  if (!token) return show('auth');
  try { me = (await api('/me')).user; goHome(); } catch (e) { show('auth'); }
})();
})();
