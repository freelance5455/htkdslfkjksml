(() => {
  const STORAGE_KEY = 'bhagyalaxmi-delivery-challans-v1';
  const TRANSPORT_KEY = 'bhagyalaxmi-transport-names-v1';
  const RECIPIENT_KEY = 'bhagyalaxmi-saved-recipients-v1';
  const DEFAULT_TRANSPORTS = ['Porter', 'Rajasthan Roadways'];
  const DEFAULT_ROWS = 6;
  const $ = (selector) => document.querySelector(selector);
  const els = {
    date: $('#challanDate'), number: $('#challanNumber'), recipient: $('#recipient'), vehicle: $('#vehicleNumber'),
    transport: $('#transportName'), customTransport: $('#customTransport'), savedRecipient: $('#savedRecipient'), itemInputs: $('#itemInputs'), history: $('#historyList'),
    search: $('#searchChallans'), saveStatus: $('#saveStatus'), printDate: $('#printDate'), printNumber: $('#printNumber'),
    printRecipient: $('#printRecipient'), printTransport: $('#printTransport'), printVehicle: $('#printVehicle'),
    printItems: $('#printItems'), printTotal: $('#printTotal')
  };
  let activeId = null;
  let rowCount = DEFAULT_ROWS;

  const readJson = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch { return fallback; } };
  const records = () => readJson(STORAGE_KEY, []);
  const transports = () => [...new Set([...DEFAULT_TRANSPORTS, ...readJson(TRANSPORT_KEY, [])])];
  const recipients = () => readJson(RECIPIENT_KEY, []);
  const setTransportOptions = (selected = '') => {
    els.transport.innerHTML = '<option value="">Select transport</option>' + transports().map(name => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join('');
    els.transport.value = selected;
  };
  const setRecipientOptions = (selected = '') => {
    els.savedRecipient.innerHTML = '<option value="">Select a saved recipient</option>' + recipients().map(recipient => `<option value="${escapeHtml(recipient.id)}">${escapeHtml(recipient.label)}</option>`).join('');
    els.savedRecipient.value = selected;
  };
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>'"]/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  const displayDate = (value) => {
    if (!value) return '–';
    const [year, month, day] = value.split('-'); return `${day}/${month}/${year}`;
  };
  const formatAmount = (value) => value === '' || value === null || value === undefined ? '–' : Number(value).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const getMode = () => document.querySelector('input[name="numberMode"]:checked').value;
  const getNextNumber = () => {
    const nums = records().map(r => String(r.number || '').match(/(\d+)\s*$/)).filter(Boolean).map(match => Number(match[1]));
    return `DC-${String((nums.length ? Math.max(...nums) : 0) + 1).padStart(4, '0')}`;
  };
  const setNumberMode = () => {
    const automatic = getMode() === 'auto';
    els.number.disabled = automatic;
    if (automatic) els.number.value = getNextNumber();
    renderPreview();
  };
  const itemRow = (item = {}, index) => `<tr>
    <td class="sr">${index + 1}</td>
    <td class="description"><input data-field="description" value="${escapeHtml(item.description || '')}" placeholder="Item description"></td>
    <td class="small"><input data-field="hsn" value="${escapeHtml(item.hsn || '')}" placeholder="HSN"></td>
    <td class="small"><input data-field="nos" inputmode="decimal" value="${escapeHtml(item.nos || '')}" placeholder="–"></td>
    <td class="small"><input data-field="set" inputmode="decimal" value="${escapeHtml(item.set || '')}" placeholder="–"></td>
    <td class="amount"><input data-field="amount" type="number" min="0" step="0.01" value="${escapeHtml(item.amount ?? '')}" placeholder="–"></td>
    <td><button class="remove-item" type="button" aria-label="Remove item ${index + 1}">×</button></td></tr>`;
  const makeItems = (items = []) => {
    rowCount = Math.max(DEFAULT_ROWS, items.length);
    els.itemInputs.innerHTML = Array.from({ length: rowCount }, (_, index) => itemRow(items[index], index)).join('');
  };
  const getItems = () => [...els.itemInputs.querySelectorAll('tr')].map(row => ({
    description: row.querySelector('[data-field="description"]').value.trim(), hsn: row.querySelector('[data-field="hsn"]').value.trim(),
    nos: row.querySelector('[data-field="nos"]').value.trim(), set: row.querySelector('[data-field="set"]').value.trim(),
    amount: row.querySelector('[data-field="amount"]').value.trim()
  })).filter(item => Object.values(item).some(Boolean));
  const currentRecord = () => ({
    id: activeId || (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`), number: els.number.value.trim(), date: els.date.value,
    recipient: els.recipient.value.trim(), vehicle: els.vehicle.value.trim(), transport: els.transport.value, items: getItems(), updatedAt: Date.now()
  });
  const renderPreview = () => {
    const record = currentRecord();
    els.printDate.textContent = displayDate(record.date);
    els.printNumber.textContent = record.number || '–';
    els.printRecipient.textContent = record.recipient || '–';
    els.printTransport.textContent = record.transport || '–';
    els.printVehicle.textContent = record.vehicle || '–';
    const visibleItems = [...record.items]; while (visibleItems.length < DEFAULT_ROWS) visibleItems.push({});
    els.printItems.innerHTML = visibleItems.map((item, index) => {
      const hasItem = Object.values(item).some(value => value !== '' && value !== null && value !== undefined);
      return `<tr><td>${hasItem ? index + 1 : ''}</td><td>${escapeHtml(item.description || '')}</td><td>${escapeHtml(item.hsn || '')}</td><td>${escapeHtml(item.nos || '–')}</td><td>${escapeHtml(item.set || '–')}</td><td>${formatAmount(item.amount)}</td></tr>`;
    }).join('');
    const total = record.items.reduce((sum, item) => item.amount === '' ? sum : sum + (Number(item.amount) || 0), 0);
    const hasAmounts = record.items.some(item => item.amount !== '');
    els.printTotal.textContent = hasAmounts ? formatAmount(total) : '–';
  };
  const renderHistory = () => {
    const query = els.search.value.trim().toLowerCase();
    const matching = records().filter(record => [record.number, record.recipient, record.date, record.transport].join(' ').toLowerCase().includes(query));
    els.history.innerHTML = matching.length ? matching.sort((a,b) => b.updatedAt - a.updatedAt).map(record => `<button class="history-entry" type="button" data-id="${escapeHtml(record.id)}"><strong>${escapeHtml(record.number || 'Unnumbered challan')}</strong><span>${escapeHtml(record.recipient || 'No recipient')} · ${displayDate(record.date)}</span></button>`).join('') : '<p class="history-empty">No saved challans found.</p>';
    // Attach click handlers directly to each entry for Android WebView compatibility.
    els.history.querySelectorAll('.history-entry').forEach(button => {
      button.addEventListener('click', () => loadRecord(button.getAttribute('data-id')));
      button.addEventListener('touchend', () => loadRecord(button.getAttribute('data-id')), { passive: true, once: true });
    });
  };
  const resetForm = () => {
    activeId = null; rowCount = DEFAULT_ROWS; els.date.value = new Date().toISOString().slice(0, 10); els.recipient.value = ''; els.vehicle.value = ''; els.customTransport.value = '';
    document.querySelector('input[name="numberMode"][value="auto"]').checked = true; setTransportOptions(); setRecipientOptions(); makeItems(); setNumberMode(); els.saveStatus.textContent = 'New challan';
  };
  const loadRecord = (id) => {
    const record = records().find(item => item.id === id); if (!record) return;
    activeId = record.id; els.date.value = record.date || ''; els.recipient.value = record.recipient || ''; els.vehicle.value = record.vehicle || ''; els.customTransport.value = '';
    const mode = /^DC-\d+$/.test(record.number || '') ? 'auto' : 'manual'; document.querySelector(`input[name="numberMode"][value="${mode}"]`).checked = true;
    setTransportOptions(record.transport || ''); setRecipientOptions(); els.number.value = record.number || ''; els.number.disabled = mode === 'auto'; makeItems(record.items || []); els.saveStatus.textContent = `Editing ${record.number || 'challan'}`; renderPreview(); window.scrollTo({top:0, behavior:'smooth'});
  };
  const save = () => {
    const record = currentRecord();
    if (!record.number) { els.saveStatus.textContent = 'Enter a challan number before saving.'; return; }
    const all = records(); const index = all.findIndex(item => item.id === record.id); if (index >= 0) all[index] = record; else all.push(record);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(all)); activeId = record.id; els.saveStatus.textContent = `Saved ${record.number}`; renderHistory();
  };
  document.addEventListener('input', event => {
    if (!event.target.closest('.editor')) return;
    const field = event.target.dataset.field;
    if (field === 'nos' && event.target.value.trim()) event.target.closest('tr').querySelector('[data-field="set"]').value = '';
    if (field === 'set' && event.target.value.trim()) event.target.closest('tr').querySelector('[data-field="nos"]').value = '';
    renderPreview();
  });
  document.addEventListener('change', event => { if (event.target.name === 'numberMode') setNumberMode(); else if (event.target.closest('.editor')) renderPreview(); });
  $('#newChallan').addEventListener('click', resetForm); $('#saveChallan').addEventListener('click', save); $('#printPdf').addEventListener('click', () => {
    renderPreview();
    const originalTitle = document.title;
    document.title = `Delivery Challan ${els.number.value.trim() || 'Draft'}`;
    window.addEventListener('afterprint', () => { document.title = originalTitle; }, { once: true });
    // Try the wrapper's current WebView first.
    try { window.print(); } catch (error) { /* use the printable-window fallback below */ }
    // Some APK wrappers do not implement WebView printing. Offer a separate
    // print-only page, which works if the wrapper allows opening a new window.
    window.setTimeout(() => {
      const printButton = $('#printPdf');
      if (document.visibilityState === 'visible' && !window.matchMedia('print').matches) {
        els.saveStatus.textContent = 'If no print dialog appeared, this APK wrapper does not support printing. Open this app in Chrome to print or save as PDF.';
      }
    }, 900);
  });
  $('#addItem').addEventListener('click', () => { rowCount += 1; els.itemInputs.insertAdjacentHTML('beforeend', itemRow({}, rowCount - 1)); renderPreview(); });
  els.itemInputs.addEventListener('click', event => { const remove = event.target.closest('.remove-item'); if (!remove) return; const rows = els.itemInputs.querySelectorAll('tr'); if (rows.length <= DEFAULT_ROWS) { const row = remove.closest('tr'); row.querySelectorAll('input').forEach(input => input.value = ''); } else remove.closest('tr').remove(); [...els.itemInputs.querySelectorAll('tr')].forEach((row, index) => row.querySelector('.sr').textContent = index + 1); renderPreview(); });
  $('#saveTransport').addEventListener('click', () => { const name = els.customTransport.value.trim(); if (!name) return; const saved = transports(); if (!saved.some(item => item.toLowerCase() === name.toLowerCase())) localStorage.setItem(TRANSPORT_KEY, JSON.stringify([...readJson(TRANSPORT_KEY, []), name])); setTransportOptions(name); els.customTransport.value = ''; renderPreview(); });
  $('#saveRecipient').addEventListener('click', () => {
    const address = els.recipient.value.trim();
    if (!address) { els.saveStatus.textContent = 'Enter the recipient details before saving.'; return; }
    const saved = recipients();
    const existing = saved.find(recipient => recipient.address.toLowerCase() === address.toLowerCase());
    const recipient = existing || { id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`, label: address.replace(/\n/g, ', ').slice(0, 70), address };
    if (!existing) localStorage.setItem(RECIPIENT_KEY, JSON.stringify([...saved, recipient]));
    setRecipientOptions(recipient.id); els.saveStatus.textContent = existing ? 'Recipient already saved.' : 'Recipient saved for reuse.';
  });
  els.savedRecipient.addEventListener('change', () => {
    const recipient = recipients().find(item => item.id === els.savedRecipient.value);
    if (recipient) { els.recipient.value = recipient.address; renderPreview(); }
  });
  els.search.addEventListener('input', renderHistory); els.history.addEventListener('click', event => { const button = event.target.closest('[data-id]'); if (button) loadRecord(button.dataset.id); });
  setTransportOptions(); setRecipientOptions(); resetForm(); renderHistory();
})();
