/* =========================================
   رفيق الصلاة
   التطبيق الكامل
========================================= */


/* =========================================
   إعدادات الإعلان
========================================= */

const AD_KEY =
    "0785a1cf1b7cc9c5607a7193ebd51c66";

const AD_URL =
    "https://www.highrevenueformat.com/" +
    AD_KEY +
    "/invoke.js";


/* =========================================
   إنشاء إعلان
========================================= */

function createAd(container, number) {

    const slot =
        document.createElement("div");

    slot.className = "ad-slot";

    slot.id =
        "ad-" + number;


    const iframe =
        document.createElement("iframe");


    iframe.width = "320";

    iframe.height = "50";

    iframe.frameBorder = "0";

    iframe.scrolling = "no";

    iframe.setAttribute(
        "title",
        "Advertisement"
    );


    iframe.srcdoc = `
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<style>

html,
body {

    margin: 0;
    padding: 0;

    width: 320px;
    height: 50px;

    overflow: hidden;

    background: transparent;
}

</style>

</head>

<body>


<script>

var atOptions = {

    'key' :
    '${AD_KEY}',

    'format' :
    'iframe',

    'height' :
    50,

    'width' :
    320,

    'params' :
    {}

};

<\/script>


<script
src="${AD_URL}">
<\/script>


</body>

</html>
`;


    slot.appendChild(iframe);

    container.appendChild(slot);

}


/* =========================================
   تحميل الإعلانات
========================================= */

function loadAds(
    containerId,
    count,
    startNumber
) {

    const container =
        document.getElementById(
            containerId
        );


    if (!container) {
        return;
    }


    for (
        let i = 0;
        i < count;
        i++
    ) {

        createAd(
            container,
            startNumber + i
        );

    }

}


/* =========================================
   تحميل 30 إعلان
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        /*
         * الرئيسية
         * 3 فوق + 3 تحت
         */

        loadAds(
            "homeTop",
            3,
            1
        );

        loadAds(
            "homeBottom",
            3,
            4
        );


        /*
         * الصلاة
         * 5 فوق + 5 تحت
         */

        loadAds(
            "prayerTop",
            5,
            7
        );

        loadAds(
            "prayerBottom",
            5,
            12
        );


        /*
         * القبلة
         * 3 فوق + 4 تحت
         */

        loadAds(
            "qiblaTop",
            3,
            17
        );

        loadAds(
            "qiblaBottom",
            4,
            20
        );


        /*
         * الإعدادات
         * 4 فوق + 3 تحت
         */

        loadAds(
            "settingsTop",
            4,
            24
        );

        loadAds(
            "settingsBottom",
            3,
            28
        );


        /*
         * تشغيل مواقيت الصلاة
         */

        if (
            document.getElementById("fajr")
        ) {

            getPrayerTimes();

        }

    }
);


/* =========================================
   الكعبة
========================================= */

const KAABA_LAT =
    21.422487;

const KAABA_LON =
    39.826206;


/* =========================================
   بيانات الصلاة
========================================= */

let prayerData = null;

let countdownTimer = null;


/* =========================================
   تحديد الموقع
========================================= */

function getLocation() {

    return new Promise(
        function (resolve, reject) {

            if (
                !navigator.geolocation
            ) {

                reject(
                    "جهازك لا يدعم تحديد الموقع"
                );

                return;
            }


            navigator.geolocation.getCurrentPosition(

                function (position) {

                    resolve({

                        lat:
                            position.coords.latitude,

                        lon:
                            position.coords.longitude

                    });

                },


                function (error) {

                    let message =
                        "تعذر تحديد موقعك";


                    if (
                        error.code === 1
                    ) {

                        message =
                            "يجب السماح للتطبيق باستخدام الموقع";

                    }


                    reject(message);

                },


                {

                    enableHighAccuracy:
                        true,

                    timeout:
                        15000,

                    maximumAge:
                        60000

                }

            );

        }
    );

}


/* =========================================
   مواقيت الصلاة
========================================= */

async function getPrayerTimes() {

    const location =
        document.getElementById(
            "location"
        );


    if (location) {

        location.textContent =
            "جاري تحديد موقعك...";

    }


    try {

        const position =
            await getLocation();


        /*
         * طريقة الحساب الأساسية
         * بدون اختيار حنفي/شافعي
         */

        const url =
            "https://api.aladhan.com/v1/timings" +
            "?latitude=" +
            position.lat +
            "&longitude=" +
            position.lon +
            "&method=5";


        const response =
            await fetch(url);


        if (!response.ok) {

            throw new Error(
                "فشل الاتصال بخدمة مواقيت الصلاة"
            );

        }


        const data =
            await response.json();


        if (!data.data) {

            throw new Error(
                "لم تصل بيانات الصلاة"
            );

        }


        prayerData =
            data.data;


        displayPrayerTimes(
            prayerData,
            position
        );


    }
    catch (error) {

        console.error(error);


        if (location) {

            location.textContent =
                error.message ||
                error;

        }

    }

}


/* =========================================
   عرض مواقيت الصلاة
========================================= */

function displayPrayerTimes(
    data,
    position
) {

    const timings =
        data.timings;

    const date =
        data.date;


    setText(
        "location",

        position.lat.toFixed(4) +
        " ، " +
        position.lon.toFixed(4)
    );


    setText(
        "gregorian",

        date.gregorian.date
    );


    setText(
        "hijri",

        date.hijri.day +
        " " +
        date.hijri.month.ar +
        " " +
        date.hijri.year +
        " هـ"
    );


    setText(
        "fajr",
        cleanTime(timings.Fajr)
    );


    setText(
        "sunrise",
        cleanTime(timings.Sunrise)
    );


    setText(
        "dhuhr",
        cleanTime(timings.Dhuhr)
    );


    setText(
        "asr",
        cleanTime(timings.Asr)
    );


    setText(
        "maghrib",
        cleanTime(timings.Maghrib)
    );


    setText(
        "isha",
        cleanTime(timings.Isha)
    );


    calculateNextPrayer(
        timings
    );

}


/* =========================================
   تنظيف الوقت
========================================= */

function cleanTime(time) {

    if (!time) {

        return "--:--";

    }


    return time
        .split(" ")[0];

}


/* =========================================
   الصلاة القادمة
========================================= */

function calculateNextPrayer(
    timings
) {

    const prayers = [

        {
            name: "الفجر",
            time:
                cleanTime(
                    timings.Fajr
                )
        },

        {
            name: "الظهر",
            time:
                cleanTime(
                    timings.Dhuhr
                )
        },

        {
            name: "العصر",
            time:
                cleanTime(
                    timings.Asr
                )
        },

        {
            name: "المغرب",
            time:
                cleanTime(
                    timings.Maghrib
                )
        },

        {
            name: "العشاء",
            time:
                cleanTime(
                    timings.Isha
                )
        }

    ];


    const now =
        new Date();


    let next = null;


    for (
        let prayer of prayers
    ) {

        const parts =
            prayer.time.split(":");


        const prayerDate =
            new Date();


        prayerDate.setHours(

            parseInt(parts[0]),

            parseInt(parts[1]),

            0,

            0

        );


        if (
            prayerDate > now
        ) {

            next = {

                name:
                    prayer.name,

                time:
                    prayer.time,

                date:
                    prayerDate

            };


            break;

        }

    }


    /*
     * إذا انتهت جميع الصلوات
     * فالصلاة القادمة فجر الغد
     */

    if (!next) {

        const parts =
            prayers[0]
                .time
                .split(":");


        const tomorrow =
            new Date();


        tomorrow.setDate(
            tomorrow.getDate() + 1
        );


        tomorrow.setHours(

            parseInt(parts[0]),

            parseInt(parts[1]),

            0,

            0

        );


        next = {

            name:
                prayers[0].name,

            time:
                prayers[0].time,

            date:
                tomorrow

        };

    }


    setText(
        "nextName",
        next.name
    );


    setText(
        "nextTime",
        next.time
    );


    startCountdown(
        next.date
    );

}


/* =========================================
   العد التنازلي
========================================= */

function startCountdown(
    targetDate
) {

    if (
        countdownTimer
    ) {

        clearInterval(
            countdownTimer
        );

    }


    function update() {

        const now =
            new Date();


        let difference =
            targetDate.getTime() -
            now.getTime();


        if (
            difference < 0
        ) {

            difference = 0;

        }


        const totalSeconds =
            Math.floor(
                difference / 1000
            );


        const hours =
            Math.floor(
                totalSeconds / 3600
            );


        const minutes =
            Math.floor(
                (totalSeconds % 3600) / 60
            );


        const seconds =
            totalSeconds % 60;


        const result =

            String(hours)
                .padStart(2, "0")

            + ":" +

            String(minutes)
                .padStart(2, "0")

            + ":" +

            String(seconds)
                .padStart(2, "0");


        setText(
            "countdown",
            result
        );

    }


    update();


    countdownTimer =
        setInterval(
            update,
            1000
        );

}


/* =========================================
   القبلة
========================================= */

let qiblaBearing = 0;


/* =========================================
   تحويل درجات إلى راديان
========================================= */

function toRadians(
    value
) {

    return value *
        Math.PI / 180;

}


/* =========================================
   تحويل راديان إلى درجات
========================================= */

function toDegrees(
    value
) {

    return value *
        180 / Math.PI;

}


/* =========================================
   حساب اتجاه القبلة
========================================= */

function calculateQibla(
    lat,
    lon
) {

    const lat1 =
        toRadians(lat);


    const lat2 =
        toRadians(
            KAABA_LAT
        );


    const difference =
        toRadians(
            KAABA_LON - lon
        );


    const y =
        Math.sin(
            difference
        ) *
        Math.cos(
            lat2
        );


    const x =

        Math.cos(lat1) *
        Math.sin(lat2)

        -

        Math.sin(lat1) *
        Math.cos(lat2) *
        Math.cos(difference);


    let bearing =
        Math.atan2(
            y,
            x
        );


    bearing =
        toDegrees(
            bearing
        );


    bearing =
        (bearing + 360) % 360;


    return bearing;

}


/* =========================================
   تشغيل البوصلة
========================================= */

async function startQibla() {

    const status =
        document.getElementById(
            "qiblaStatus"
        );


    try {

        if (status) {

            status.textContent =
                "جاري تحديد موقعك...";

        }


        const position =
            await getLocation();


        qiblaBearing =
            calculateQibla(

                position.lat,

                position.lon

            );


        setText(

            "qiblaDegree",

            Math.round(
                qiblaBearing
            ) + "°"

        );


        if (status) {

            status.textContent =
                "حرّك الهاتف حتى يشير السهم نحو القبلة";

        }


        enableOrientation();


    }
    catch (error) {

        if (status) {

            status.textContent =
                error.message ||
                error;

        }

    }

}


/* =========================================
   حساس اتجاه الهاتف
========================================= */

async function enableOrientation() {

    /*
     * بعض الأجهزة تحتاج طلب إذن
     */

    if (

        typeof DeviceOrientationEvent !==
        "undefined"

        &&

        typeof
        DeviceOrientationEvent
            .requestPermission ===
        "function"

    ) {

        try {

            const permission =
                await
                DeviceOrientationEvent
                    .requestPermission();


            if (
                permission !==
                "granted"
            ) {

                setText(

                    "qiblaStatus",

                    "يجب السماح باستخدام حساس الاتجاه"

                );


                return;

            }

        }
        catch (error) {

            console.error(
                error
            );

        }

    }


    window.addEventListener(

        "deviceorientation",

        handleOrientation,

        true

    );

}


/* =========================================
   تحريك سهم القبلة
========================================= */

function handleOrientation(
    event
) {

    let heading = null;


    /*
     * Android
     */

    if (

        typeof
        event.webkitCompassHeading ===
        "undefined"

        &&

        event.alpha !== null

    ) {

        heading =
            360 -
            event.alpha;

    }


    /*
     * iPhone / iPad
     */

    if (

        typeof
        event.webkitCompassHeading !==
        "undefined"

    ) {

        heading =
            event.webkitCompassHeading;

    }


    if (
        heading === null
    ) {

        return;

    }


    heading =
        (heading + 360) % 360;


    const rotation =
        qiblaBearing -
        heading;


    const arrow =
        document.getElementById(
            "arrow"
        );


    if (arrow) {

        arrow.style.transform =

            "translate(-50%, -70%) " +

            "rotate(" +
            rotation +
            "deg)";

    }

}


/* =========================================
   تفعيل الموقع
========================================= */

function requestLocation() {

    if (
        !navigator.geolocation
    ) {

        alert(
            "جهازك لا يدعم تحديد الموقع"
        );

        return;

    }


    navigator.geolocation.getCurrentPosition(

        function () {

            alert(
                "تم تفعيل الموقع بنجاح"
            );

        },


        function () {

            alert(
                "لم يتم السماح باستخدام الموقع"
            );

        }

    );

}


/* =========================================
   الإشعارات
========================================= */

function requestNotifications() {

    if (
        !("Notification" in window)
    ) {

        alert(
            "الإشعارات غير مدعومة في هذه البيئة"
        );

        return;

    }


    Notification
        .requestPermission()
        .then(
            function (permission) {

                if (
                    permission ===
                    "granted"
                ) {

                    alert(
                        "تم السماح بالإشعارات"
                    );

                }
                else {

                    alert(
                        "لم يتم السماح بالإشعارات"
                    );

                }

            }
        );

}


/* =========================================
   دالة مساعدة
========================================= */

function setText(
    id,
    value
) {

    const element =
        document.getElementById(
            id
        );


    if (element) {

        element.textContent =
            value;

    }

}