const screen=document.getElementById('screen');
let page='home', historyStack=[], audioCtx=null, metroTimer=null, metroOn=false, beat=0;
const $=s=>document.querySelector(s);
const chordData={
 C:{fa:'دو ماژور',notes:[261.63,329.63,392,523.25],fingers:['x','3','2','0','1','0'],tips:'انگشت اشاره: سیم دوم، فرت اول؛ انگشت میانی: سیم چهارم، فرت دوم؛ انگشت حلقه: سیم پنجم، فرت سوم.'},
 G:{fa:'سل ماژور',notes:[196,246.94,293.66,392,493.88],fingers:['3','2','0','0','0','3'],tips:'انگشت میانی روی سیم پنجم فرت دوم؛ اشاره روی سیم ششم فرت سوم؛ انگشت کوچک یا حلقه روی سیم اول فرت سوم.'},
 D:{fa:'ر ماژور',notes:[146.83,220,293.66,369.99],fingers:['x','x','0','2','3','2'],tips:'سه انگشت را نزدیک فرت‌ها قرار بده؛ سیم پنجم و ششم را در این شکل نزن.'},
 Em:{fa:'می مینور',notes:[82.41,123.47,164.81,196,246.94,329.63],fingers:['0','2','2','0','0','0'],tips:'دو انگشت روی سیم پنجم و چهارم، هر دو فرت دوم قرار می‌گیرند.'},
 Am:{fa:'لا مینور',notes:[110,164.81,220,261.63,329.63],fingers:['x','0','2','2','1','0'],tips:'اشاره روی سیم دوم فرت اول، میانی روی سیم چهارم فرت دوم و حلقه روی سیم سوم فرت دوم.'},
 Bm:{fa:'سی مینور',notes:[123.47,146.83,196,246.94,293.66],fingers:['x','2','4','4','3','2'],tips:'این آکورد باره دارد؛ فعلاً با فشار ملایم و بدون درد تمرین کن.'}
};
const scales={};
const scaleDefs=[
['C Major','دو ماژور',60,[0,2,4,5,7,9,11,12]],['G Major','سل ماژور',55,[0,2,4,5,7,9,11,12]],['D Major','ر ماژور',50,[0,2,4,5,7,9,11,12]],['A Major','لا ماژور',45,[0,2,4,5,7,9,11,12]],['E Major','می ماژور',40,[0,2,4,5,7,9,11,12]],['F Major','فا ماژور',53,[0,2,4,5,7,9,11,12]],['Bb Major','سی بمل ماژور',58,[0,2,4,5,7,9,11,12]],['Eb Major','می بمل ماژور',63,[0,2,4,5,7,9,11,12]],
['A Natural Minor','لا مینور طبیعی',57,[0,2,3,5,7,8,10,12]],['E Natural Minor','می مینور طبیعی',52,[0,2,3,5,7,8,10,12]],['D Natural Minor','ر مینور طبیعی',50,[0,2,3,5,7,8,10,12]],['A Harmonic Minor','لا مینور هارمونیک',57,[0,2,3,5,7,8,11,12]],['E Harmonic Minor','می مینور هارمونیک',52,[0,2,3,5,7,8,11,12]],['D Harmonic Minor','ر مینور هارمونیک',50,[0,2,3,5,7,8,11,12]],['A Melodic Minor','لا مینور ملودیک',57,[0,2,3,5,7,9,11,12]],['C Major Pentatonic','پنتاتونیک دو ماژور',60,[0,2,4,7,9,12]],['A Minor Pentatonic','پنتاتونیک لا مینور',57,[0,3,5,7,10,12]],['C Chromatic','کروماتیک دو',60,[0,1,2,3,4,5,6,7,8,9,10,11,12]],['G Major 2nd Position','سل ماژور، پوزیسیون دوم',55,[0,2,4,5,7,9,11,12]],['C Major 5th Position','دو ماژور، پوزیسیون پنجم',60,[0,2,4,5,7,9,11,12]]
];
const noteNamesFa=['دو','دو دیز','ر','ر دیز','می','فا','فا دیز','سل','سل دیز','لا','لا دیز','سی'];
scaleDefs.forEach(([k,fa,root,steps])=>{const base=440*Math.pow(2,(root-69)/12);scales[k]={fa,notes:steps.map(n=>base*Math.pow(2,n/12)),names:steps.map(n=>noteNamesFa[(root+n)%12])}});
const lessons=[
['۱','آشنایی با گیتار و طرز نشستن','ساز را راحت روی پای راست یا چپ قرار بده و شانه‌ها را رها کن.','https://www.youtube.com/results?search_query=classical+guitar+posture+beginner'],
['۲','نام سیم‌های آزاد','از سیم ضخیم تا نازک: می، لا، ر، سل، سی، می (E A D G B E).','https://www.youtube.com/results?search_query=classical+guitar+open+strings+beginner'],
['۳','تمرین انگشت‌های دست راست','با p-i-m-a آرام و جداگانه سیم‌ها را بنواز.','https://www.youtube.com/results?search_query=classical+guitar+right+hand+pima+beginner'],
['۴','نت‌خوانی مقدماتی','نت‌های می، فا، سل و جای آن‌ها روی خطوط حامل را یاد بگیر.','https://www.youtube.com/results?search_query=classical+guitar+reading+music+lesson+1'],
['۵','اولین ملودی: سرود شادی','ملودی را آرام گوش کن و سپس با ساز تکرار کن.','https://www.youtube.com/results?search_query=Ode+to+Joy+classical+guitar+beginner+tutorial'],
['۶','تمرین ریتم و مترونوم','با سرعت ۶۰ ضرب در دقیقه، چهار ضرب یکنواخت بزن.','https://www.youtube.com/results?search_query=classical+guitar+metronome+beginner']
];
function layout(html){screen.innerHTML='<div class="content">'+html+'</div>';document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.page===page));}
function toast(s){const t=$('#toast');t.textContent=s;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('show'),2600);}
function go(p){if(page!==p)historyStack.push(page);page=p;render();}
function back(){if(historyStack.length){page=historyStack.pop();render()}else{page='home';render()}}
function audio(){const AC=window.AudioContext||window.webkitAudioContext;if(!AC){toast('مرورگر این گوشی پخش صوت را پشتیبانی نمی‌کند.');return null}if(!audioCtx)audioCtx=new AC();if(audioCtx.state==='suspended')audioCtx.resume();return audioCtx}
function tone(freq,duration=.45,when=0,type='plucked',vol=.18){
  const c=audio();if(!c)return;
  const sampleRate=c.sampleRate,length=Math.max(256,Math.floor(sampleRate*Math.min(duration+.12,2.2))),buffer=c.createBuffer(1,length,sampleRate),data=buffer.getChannelData(0),period=Math.max(2,Math.round(sampleRate/freq)),ring=new Float32Array(period);
  for(let i=0;i<period;i++)ring[i]=Math.random()*2-1;let idx=0;for(let i=0;i<length;i++){const next=(idx+1)%period,v=(ring[idx]+ring[next])*.497;data[i]=v;ring[idx]=v;idx=next}for(let i=0;i<length;i++)data[i]*=Math.exp(-(i/sampleRate)*(2.2+freq/220));
  const src=c.createBufferSource(),g=c.createGain(),lp=c.createBiquadFilter();src.buffer=buffer;lp.type='lowpass';lp.frequency.value=Math.min(6500,Math.max(1300,freq*12));g.gain.setValueAtTime(.0001,c.currentTime+when);g.gain.linearRampToValueAtTime(vol,c.currentTime+when+.008);g.gain.setValueAtTime(vol,c.currentTime+when+Math.min(duration*.7,.45));g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+when+duration);src.connect(lp);lp.connect(g);g.connect(c.destination);src.start(c.currentTime+when);src.stop(c.currentTime+when+duration+.03);
}
function playNotes(notes,step=.42){notes.forEach((n,i)=>tone(n,.42,i*step,'plucked',.17))}
let progressMem={};function saved(){return progressMem}
function saveLesson(id,checked){const s=saved();s[id]=checked;toast(checked?'علامت زده شد':'علامت درس برداشته شد')}
function home(){page='home';const s=saved(),done=lessons.filter(x=>s['lesson'+x[0]]).length;layout(`<div class="welcome"><div class="guitar"><img class="home-guitar-icon classical-guitar-icon" src="media/guitar-icon.svg" alt="گیتار کلاسیک"></div><h1>به دنیای گیتار خوش آمدی</h1><p class="muted">آموزش گیتار کلاسیک، قدم‌به‌قدم</p></div>
<button class="btn secondary" onclick="go('plan90')">ورود به فهرست آموزش دویست آهنگ</button><p class="muted">هر روز ۲۰ تا ۳۰ دقیقه تمرین آرام و منظم؛ درد یا فشار زیاد نشانه توقف است.</p></div>
<div class="grid">
<button class="card blue" onclick="openGuitarTypes()">🎸 <b>شناخت انواع گیتار</b><small>تصویر، تفاوت صدا، سیم‌ها و کاربرد هر نوع</small></button>
<button class="card blue" onclick="go('strings')">🎼<b>سیم‌ها و نت‌ها</b><small>نام فارسی، حرف لاتین و فرت‌های ۰ تا ۱۲</small></button>
<button class="card purple" onclick="go('fingers')">🖐<b>انگشتان دو دست</b><small>نام‌گذاری دست چپ و راست</small></button>
<button class="card blue" onclick="go('scales')">♫<b>گام‌ها</b><small>شنیدن و تمرین گام‌ها</small></button>
<button class="card orange" onclick="go('technique')">🎯<b>تیراندو و آپویاندو</b><small>آموزش مرحله‌به‌مرحله و فیلم</small></button>
<button class="card" onclick="go('practice')">♩<b>تمرین و مترونوم</b><small>تمرین روزانه و ضرب</small></button>
<button class="card green" onclick="go('chords')">🎓<b>۱۸ آکورد پرکاربرد</b><small>عکس واقعی و راهنمای انگشت‌گذاری</small></button>
<button class="card" onclick="go('settings')">⚙️ <b>تنظیمات و راهنما</b><small>نکات استفاده و پیشرفت</small></button></div>`)}
/* ===== بخش ۱۸ آکورد — بازنویسی کامل V25 =====
   این بخش عمداً مستقل از chordData/features.js است.
   هر کارت یک button واقعی است و listener مستقیماً روی همان کارت ثبت می‌شود.
*/
const chordBookV25 = {
  C:{fa:'دو ماژور',f:['x',3,2,0,1,0],img:'C.jpg',tips:'اشاره روی سیم ۲ فرت ۱، میانی روی سیم ۴ فرت ۲ و حلقه روی سیم ۵ فرت ۳. سیم ۶ نواخته نشود.'},
  G:{fa:'سل ماژور',f:[3,2,0,0,0,3],img:'G.jpg',tips:'اشاره روی سیم ۵ فرت ۲، میانی روی سیم ۶ فرت ۳ و حلقه یا کوچک روی سیم ۱ فرت ۳.'},
  D:{fa:'ر ماژور',f:['x','x',0,2,3,2],img:'D.jpg',tips:'سه انگشت را روی سیم‌های ۳، ۲ و ۱ قرار بده و فقط چهار سیم زیرین را بنواز.'},
  A:{fa:'لا ماژور',f:['x',0,2,2,2,0],img:'A.jpg',tips:'سه انگشت را کنار هم روی فرت دوم سیم‌های ۴، ۳ و ۲ قرار بده.'},
  E:{fa:'می ماژور',f:[0,2,2,1,0,0],img:'E.jpg',tips:'اشاره روی سیم ۳ فرت ۱، میانی روی سیم ۵ فرت ۲ و حلقه روی سیم ۴ فرت ۲.'},
  Am:{fa:'لا مینور',f:['x',0,2,2,1,0],img:'Am.jpg',tips:'اشاره روی سیم ۲ فرت ۱، میانی روی سیم ۴ فرت ۲ و حلقه روی سیم ۳ فرت ۲.'},
  Em:{fa:'می مینور',f:[0,2,2,0,0,0],img:'Em.jpg',tips:'میانی و حلقه را روی سیم‌های ۵ و ۴، فرت دوم قرار بده.'},
  Dm:{fa:'ر مینور',f:['x','x',0,2,3,1],img:'Dm.jpg',tips:'اشاره روی سیم ۱ فرت ۱، میانی روی سیم ۳ فرت ۲ و حلقه روی سیم ۲ فرت ۳.'},
  F:{fa:'فا ماژور',f:[1,3,3,2,1,1],img:'F.jpg',tips:'برای شکل باره‌ای، اشاره را روی فرت اول نگه دار و فشار دست را حداقل لازم قرار بده.'},
  Bm:{fa:'سی مینور',f:['x',2,4,4,3,2],img:'Bm.jpg',tips:'این آکورد باره دارد؛ مچ را صاف نگه دار و انگشت اشاره را روی فرت دوم نگه دار.'},
  B7:{fa:'سی هفت',f:['x',2,1,2,0,2],img:'B7.jpg',tips:'اشاره روی سیم ۵ فرت ۲، میانی روی سیم ۳ فرت ۲ و انگشتان دیگر را مطابق شکل قرار بده.'},
  A7:{fa:'لا هفت',f:['x',0,2,0,2,0],img:'A7.jpg',tips:'انگشتان روی سیم‌های ۴ و ۲ فرت دوم قرار می‌گیرند؛ سیم ۵ آزاد است.'},
  E7:{fa:'می هفت',f:[0,2,0,1,0,0],img:'E7.jpg',tips:'اشاره روی سیم ۳ فرت ۱ و میانی و حلقه روی سیم‌های ۵ و ۴ فرت دوم.'},
  D7:{fa:'ر هفت',f:['x','x',0,2,1,2],img:'D7.jpg',tips:'سه انگشت روی سیم‌های ۳، ۲ و ۱ قرار می‌گیرند؛ دو سیم بم نواخته نشوند.'},
  C7:{fa:'دو هفت',f:['x',3,2,3,1,0],img:'C7.jpg',tips:'شکل دو ماژور را با تغییر انگشت روی سیم ۴ فرت ۳ اجرا کن.'},
  G7:{fa:'سل هفت',f:[3,2,0,0,0,1],img:'G7.jpg',tips:'شکل سل را بگیر و انگشت کوچک را روی سیم ۱ فرت ۱ اضافه کن.'},
  Em7:{fa:'می مینور هفت',f:[0,2,0,0,0,0],img:'Em7.jpg',tips:'فقط انگشت میانی روی سیم ۵ فرت ۲؛ بقیه سیم‌ها آزاد هستند.'},
  Fmaj7:{fa:'فا ماژور هفت',f:['x','x',3,2,1,0],img:'Fmaj7.jpg',tips:'سه انگشت را روی سیم‌های ۴، ۳ و ۲ قرار بده؛ سیم ۱ آزاد است.'},
};

function chordPhotoV25(c,k){return 'media/chords/'+(c.img||'chords-real-reference.png');}
function chordNotesV25(f){
  const midi=[40,45,50,55,59,64];
  return f.map((v,i)=>v==='x'?null:440*Math.pow(2,((midi[i]+Number(v))-69)/12)).filter(Boolean);
}
function chords(){
  page='chords';
  const keys=Object.keys(chordBookV25);
  layout(`<h2>۱۸ آکورد پرکاربرد</h2>
    <p class="muted">هر کارت را لمس کن تا عکس واقعی، نحوهٔ انگشت‌گذاری و صدای همان آکورد باز شود.</p>
    <div id="chordBookV25" class="chord-grid" aria-label="۱۸ آکورد پرکاربرد">
      ${keys.map(k=>{const c=chordBookV25[k];return `<button type="button" class="chord-card" data-v25-chord="${k}">
        <img src="${chordPhotoV25(c,k)}" alt="تصویر واقعی آکورد ${k}" loading="eager">
        <div class="chord-card-info"><b>${k}</b><span>${c.fa}</span></div>
      </button>`}).join('')}
    </div>`);
  document.querySelectorAll('[data-v25-chord]').forEach(btn=>{
    btn.addEventListener('click',function(ev){
      ev.preventDefault(); ev.stopPropagation();
      const k=this.getAttribute('data-v25-chord');
      detail(k);
    });
  });
}
function detail(k){
  const c=chordBookV25[k];
  if(!c){toast('آکورد پیدا نشد.');return;}
  page='chordDetail'; window.currentChord=k; window.currentChordV25=k;
  const fingerLabels=c.f.map((v,i)=>v==='x'?'×':v==='0'?'○':v).join('  ');
  layout(`<h2>آکورد ${k} — ${c.fa}</h2>
    <div class="panel chord-photo real-chord-panel">
      <h3>تصویر واقعی دستهٔ گیتار و انگشت‌گذاری</h3>
      <img class="real-chord-photo" src="${chordPhotoV25(c,k)}" alt="تصویر واقعی نحوه انگشت گذاری آکورد ${k}">
      <div class="chord-legend"><span>سیم‌ها: ۶ ← ۱</span><span>فرت: ${fingerLabels}</span></div>
    </div>
    <div class="panel"><h3>نحوهٔ انگشت‌گذاری</h3><p>${c.tips}</p>
      <div class="panel"><b>شمارهٔ انگشت‌ها:</b><p class="muted">۱ اشاره، ۲ میانی، ۳ حلقه، ۴ کوچک. سیم‌های × نواخته نمی‌شوند و ○ آزاد هستند.</p></div>
      <button type="button" class="btn" id="v25PlayChord">▶ شنیدن آکورد</button>
      <button type="button" class="btn secondary" id="v25StopChord">■ توقف صدا</button>
    </div>
    <button type="button" class="btn secondary" id="v25BackChords">بازگشت به ۱۸ آکورد</button>`);
  document.getElementById('v25PlayChord').addEventListener('click',()=>playChord(k));
  document.getElementById('v25StopChord').addEventListener('click',stopSound);
  document.getElementById('v25BackChords').addEventListener('click',chords);
}
/* V25 navigation bridge: مسیر مستقیم و مستقل برای ورود به بخش آکوردها */
window.openChordsV25=function(){ chords(); };
window.openChordDetailV25=function(k){ detail(k); };
function playChord(k){
  const c=chordBookV25[k]; if(!c)return;
  chordNotesV25(c.f).forEach((n,i)=>tone(n,1.15,i*.035,'plucked',.12));
}
function stopSound(){if(audioCtx){audioCtx.close();audioCtx=null}toast('پخش صدا متوقف شد.')}
function scalesPage(){page='scales';layout(`<h2>گام‌ها</h2><p class="muted">روی هر گام بزن و نت‌ها را به ترتیب بشنو.</p><div class="list">${Object.entries(scales).map(([k,v])=>`<div class="row" onclick="scaleDetail('${k}')"><div class="left"><div class="dot">${k[0]}</div><div><b>${k}</b><br><small>گام ${v.fa}</small></div></div><span>‹</span></div>`).join('')}</div>`)}
function scaleDetail(k){const s=scales[k];page='scaleDetail';layout(`<h2>${k} — ${s.fa}</h2><div class="panel"><h3>نت‌های گام</h3><div class="note-pills">${s.names.map((n,i)=>`<span class="pill">${n}</span>`).join('')}</div><button class="btn" onclick="playScale('${k}')">▶ پخش گام</button><button class="btn secondary" onclick="playScale('${k}',.65)">🐢 پخش آهسته</button><button class="btn secondary" onclick="playScale('${k}',.32,true)">↘ پخش نزولی</button></div><p class="muted">ابتدا به صدا گوش کن، سپس نت‌ها را روی گیتار پیدا کن. برای اجرای واقعی، از یک مدرس یا فیلم آموزشی کمک بگیر.</p><button class="btn secondary" onclick="go('scales')">بازگشت</button>`)}
function playScale(k,step=.32,descending=false){const ns=descending?[...scales[k].notes].reverse():scales[k].notes;playNotes(ns,step)}
function practice(){page='practice';layout(`<h2>تمرین روزانه</h2><div class="panel"><h3>۱. مترونوم</h3><p class="muted">سرعت را انتخاب کن و شروع بزن. با هر ضرب صدای کوتاه می‌شنوی.</p><label for="bpm">سرعت: <b id="bpmLabel">60</b> BPM</label><input class="field" id="bpm" type="range" min="40" max="160" value="60" oninput="$('#bpmLabel').textContent=this.value"><div class="meter-number" id="beatNum">—</div><button class="btn" id="metroBtn" onclick="toggleMetro()">▶ شروع مترونوم</button></div><div class="panel"><h3>۲. برنامه ۲۰ دقیقه‌ای</h3><label class="check"><input type="checkbox" onchange="savePractice('warmup',this.checked)"> ۵ دقیقه: گرم‌کردن انگشت‌ها</label><label class="check"><input type="checkbox" onchange="savePractice('chords',this.checked)"> ۵ دقیقه: تعویض آکوردها</label><label class="check"><input type="checkbox" onchange="savePractice('notes',this.checked)"> ۵ دقیقه: نت‌خوانی و ملودی</label><label class="check"><input type="checkbox" onchange="savePractice('song',this.checked)"> ۵ دقیقه: آهنگ دلخواه</label></div>`);if(metroOn){stopMetro()}}
function savePractice(k,v){const s=saved();s['practice_'+k]=v;toast(v?'علامت زده شد':'علامت برداشته شد')}
function toggleMetro(){if(metroOn){stopMetro();return}const c=audio();if(!c)return;metroOn=true;beat=0;$('#metroBtn').textContent='■ توقف مترونوم';const tick=()=>{if(!metroOn)return;const bpm=Number($('#bpm')?.value||60);tone(beat%4===0?1000:750,.07,0,'square',.12);beat++;const el=$('#beatNum');if(el)el.textContent=String((beat-1)%4+1);metroTimer=setTimeout(tick,60000/bpm)};tick()}
function stopMetro(){metroOn=false;clearTimeout(metroTimer);metroTimer=null;const b=$('#metroBtn');if(b)b.textContent='▶ شروع مترونوم';const n=$('#beatNum');if(n)n.textContent='—'}
function songs(){page='songs';layout(`<h2>آهنگ‌های تمرینی</h2><p class="muted">ملودی‌های ساده برای گوش دادن و تمرین. صداها با مدل آفلاینِ سیم زخمه‌ای ساخته می‌شوند.</p><div class="panel"><h3>سرود شادی (Ode to Joy)</h3><p>می، می، فا، سل — سل، فا، می، ر — دو، دو، ر، می — می، ر، ر</p><button class="btn" onclick="playNotes([329.63,329.63,349.23,392,392,349.23,329.63,293.66,261.63,261.63,293.66,329.63,329.63,293.66,293.66],.42)">▶ پخش ملودی</button></div><div class="panel"><h3>تولدت مبارک</h3><p>ملودی نمونه برای آشنایی با تغییر نت‌ها.</p><button class="btn" onclick="playNotes([261.63,261.63,293.66,261.63,349.23,329.63,261.63,261.63,293.66,261.63,392,349.23],.36)">▶ پخش ملودی</button></div><div class="panel"><h3>تمرین نت‌های آزاد</h3><p>سیم‌های آزاد از بم به زیر: می، لا، ر، سل، سی، می.</p><button class="btn" onclick="playNotes([82.41,110,146.83,196,246.94,329.63],.55)">▶ پخش شش سیم</button></div>`)}
function lessonsPage(){page='lessons';const s=saved();layout(`<h2>مسیر یادگیری از صفر</h2><p class="muted">هر درس را مطالعه کن، تمرین کن و پس از انجام تیک بزن.</p>${lessons.map(l=>`<div class="panel"><h3>درس ${l[0]}: ${l[1]}</h3><p>${l[2]}</p><label class="check"><input type="checkbox" ${s['lesson'+l[0]]?'checked':''} onchange="saveLesson('${l[0]}',this.checked)"> این درس را انجام دادم</label><a href="${l[3]}" target="_blank" rel="noopener">ویدئوهای کمکی این درس ↗</a></div>`).join('')}`)}
function settings(){page='settings';layout(`<h2>تنظیمات و راهنما</h2><div class="panel"><h3>درباره نسخه</h3><p>همهٔ صداهای این برنامه روی خود دستگاه ساخته می‌شوند و برای پخش آن‌ها به اینترنت یا میکروفون نیازی نیست. لینک‌های آموزشی (یوتیوب و منابع) فقط وقتی روی آن‌ها بزنی در مرورگر باز می‌شوند.</p><p class="muted">برای پخش صدا یک بار روی دکمه پخش بزن.</p></div><div class="panel"><h3>پیشرفت درس‌ها</h3><p class="muted">تیک درس‌ها و تمرین‌ها فقط تا زمانی که برنامه باز است نگه داشته می‌شود و روی دستگاه ذخیره نمی‌شود.</p><button class="btn danger" onclick="if(confirm('همهٔ تیک‌ها پاک شود؟')){Object.keys(saved()).forEach(k=>delete saved()[k]);toast('تیک‌ها پاک شد');settings()}">پاک کردن تیک‌ها</button></div>`)}
function render(){if(page==='home')home();else if(page==='chords')chords();else if(page==='scales')scalesPage();else if(page==='practice')practice();else if(page==='songs')songs();else if(page==='videos')videos();else if(page==='lessons')lessonsPage();else if(page==='settings')settings();else if(page==='chordDetail')detail(window.currentChord||'C');else if(page==='scaleDetail')scaleDetail(window.currentScale||'C Major');}
const _detail=detail;detail=function(k){window.currentChord=k;_detail(k)};const _scaleDetail=scaleDetail;scaleDetail=function(k){window.currentScale=k;_scaleDetail(k)};
document.querySelectorAll('nav button').forEach(b=>b.onclick=()=>go(b.dataset.page));
$('#back').onclick=back;$('#settings').onclick=()=>go('settings');
window.addEventListener('beforeunload',()=>{stopMetro()});
home();