const KEY="qr_smart_data_v1", PASS="qr_smart_pass_v1";
let data=JSON.parse(localStorage.getItem(KEY)||"[]"), password=localStorage.getItem(PASS)||"0000", current=null, fields=[];

function $(id){return document.getElementById(id)}
function saveStore(){localStorage.setItem(KEY,JSON.stringify(data))}
function login(){if($("loginPass").value===password){$("login").classList.add("hidden");$("app").classList.remove("hidden");refresh()}else{$("loginError").textContent="كلمة المرور غير صحيحة";}}
$("loginPass").addEventListener("keydown",e=>{if(e.key==="Enter")login()});

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>go(b.dataset.page));
function go(page){document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));$(page).classList.remove("hidden");document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.page===page));refresh()}
function lockApp(){$("app").classList.add("hidden");$("login").classList.remove("hidden");$("loginPass").value=""}
function refresh(){updateStats();renderRecent();renderCodes();updateStatsPage()}
function status(x){if(x.disabled)return ["متوقف","off"];if(!x.expires)return ["فعال","ok"];let d=Math.ceil((new Date(x.expires)-new Date())/86400000);if(d<0)return ["منتهي","expired"];if(d<=30)return [`${d} يوم`,`soon`];return ["فعال","ok"]}
function updateStats(){let a=data.filter(x=>status(x)[1]=="ok").length,s=data.filter(x=>status(x)[1]=="soon").length,e=data.filter(x=>status(x)[1]=="expired").length;$("countActive").textContent=a;$("countSoon").textContent=s;$("countExpired").textContent=e;$("countAll").textContent=data.length}
function updateStatsPage(){ $("statTotal").textContent=data.length;$("statScans").textContent=data.reduce((n,x)=>n+(x.scans||0),0);$("statActive").textContent=data.filter(x=>status(x)[1]=="ok").length;$("statDisabled").textContent=data.filter(x=>x.disabled).length}
function item(x){let [st,cl]=status(x);return `<div class="item"><div><h4>${esc(x.name)}</h4><div class="muted">${new Date(x.created).toLocaleDateString("ar-IQ")} • ${x.dynamic?"ذكي":"ثابت"} • ${x.fields.length} محتوى</div></div><div style="display:flex;align-items:center;gap:8px"><span class="badge ${cl}">${st}</span><div class="item-actions"><button onclick="viewQR('${x.id}')">عرض</button><button onclick="toggleQR('${x.id}')">${x.disabled?"تفعيل":"إيقاف"}</button><button onclick="deleteQR('${x.id}')">حذف</button></div></div></div>`}
function renderRecent(){$("recentList").innerHTML=data.slice().sort((a,b)=>b.created-a.created).slice(0,5).map(item).join("")||'<div class="info-card">لا توجد أكواد بعد. ابدأ بإنشاء أول QR.</div>'}
function renderCodes(){let q=($("search")?.value||"").toLowerCase();$("codesList").innerHTML=data.filter(x=>x.name.toLowerCase().includes(q)).sort((a,b)=>b.created-a.created).map(item).join("")||'<div class="info-card">لا توجد نتائج.</div>'}
function openCreator(){fields=[];$("qrName").value="";$("expiry").value="365";$("customDate").classList.add("hidden");$("dynamic").checked=true;$("fields").innerHTML="";$("qrPreview").innerHTML="";$("creatorMsg").textContent="";$("creator").classList.remove("hidden")}
function closeCreator(){$("creator").classList.add("hidden")}
function addField(type){let id=Date.now()+Math.random();fields.push({id,type,value:""});renderFields()}
function renderFields(){let names={phone:"رقم الهاتف",text:"النص",url:"الرابط",email:"البريد الإلكتروني",location:"الموقع",image:"رابط الصورة"};$("fields").innerHTML=fields.map((f,i)=>`<div class="field"><div class="field-head"><span>${names[f.type]}</span><button onclick="removeField('${f.id}')">حذف</button></div>${f.type=="text"?`<textarea data-id="${f.id}" oninput="fieldInput('${f.id}',this.value)"></textarea>`:`<input data-id="${f.id}" value="${esc(f.value)}" placeholder="${names[f.type]}" oninput="fieldInput('${f.id}',this.value)">`}</div>`).join("")}
function fieldInput(id,v){let f=fields.find(x=>String(x.id)==String(id));if(f)f.value=v;preview()}
function removeField(id){fields=fields.filter(x=>String(x.id)!=String(id));renderFields();preview()}
$("expiry").onchange=()=>{$("customDate").classList.toggle("hidden",$("expiry").value!=="custom")}
function payload(){return fields.map(f=>{let label={phone:"هاتف",text:"نص",url:"رابط",email:"بريد",location:"موقع",image:"صورة"}[f.type];return `${label}: ${f.value}`}).join("\n")}
function preview(){let el=$("qrPreview");el.innerHTML="";let p=payload();if(p&&window.QRCode)new QRCode(el,{text:p,width:170,height:170,correctLevel:QRCode.CorrectLevel.M});}
function saveQR(){let name=$("qrName").value.trim();if(!name||!fields.some(f=>f.value.trim())){$("creatorMsg").textContent="أدخل اسم الكود ومحتوى واحد على الأقل.";return}let ex=$("expiry").value,expires=null;if(ex==="custom"){expires=$("customDate").value?new Date($("customDate").value+"T23:59:59").toISOString():null}else if(ex!=="0"){expires=new Date(Date.now()+Number(ex)*86400000).toISOString()}let x={id:crypto.randomUUID(),name,fields:JSON.parse(JSON.stringify(fields)),created:Date.now(),expires,dynamic:$("dynamic").checked,disabled:false,scans:0};data.push(x);saveStore();closeCreator();refresh();viewQR(x.id)}
function viewQR(id){current=data.find(x=>x.id===id);if(!current)return;$("viewTitle").textContent=current.name;$("viewQR").innerHTML="";new QRCode($("viewQR"),{text:payloadFor(current),width:220,height:220});let [st,cl]=status(current);$("viewData").innerHTML=`<div class="info-card"><b>الحالة:</b> <span class="badge ${cl}">${st}</span><p><b>النوع:</b> ${current.dynamic?"QR ذكي":"QR ثابت"}</p><p><b>الصلاحية:</b> ${current.expires?new Date(current.expires).toLocaleDateString("ar-IQ"):"بدون انتهاء"}</p><p><b>المحتوى:</b><br>${current.fields.map(f=>esc(f.value)).join("<br>")}</p></div>`;$("viewer").classList.remove("hidden")}
function payloadFor(x){return x.fields.map(f=>`${{phone:"هاتف",text:"نص",url:"رابط",email:"بريد",location:"موقع",image:"صورة"}[f.type]}: ${f.value}`).join("\n")}
function closeViewer(){$("viewer").classList.add("hidden")}
function toggleQR(id){let x=data.find(x=>x.id===id);if(x){x.disabled=!x.disabled;saveStore();refresh()}}
function deleteQR(id){if(confirm("هل تريد حذف هذا الكود؟")){data=data.filter(x=>x.id!==id);saveStore();refresh()}}
function downloadQR(){let img=$("viewQR").querySelector("img");if(!img)return;let a=document.createElement("a");a.href=img.src;a.download=(current?.name||"qr")+".png";a.click()}
async function shareQR(){if(!current)return;if(navigator.share){navigator.share({title:current.name,text:payloadFor(current)}).catch(()=>{})}else alert("المشاركة المباشرة غير مدعومة في هذا المتصفح. استخدم تنزيل PNG.")}
function changePassword(){let o=$("oldPass").value,n=$("newPass").value,c=$("confirmPass").value;if(o!==password)return msg("كلمة المرور الحالية غير صحيحة");if(n.length<4)return msg("كلمة المرور يجب أن تكون 4 أحرف/أرقام على الأقل");if(n!==c)return msg("تأكيد كلمة المرور غير مطابق");password=n;localStorage.setItem(PASS,password);msg("تم تغيير كلمة المرور بنجاح","green");$("oldPass").value=$("newPass").value=$("confirmPass").value=""}
function msg(t,c){$("passMsg").textContent=t;$("passMsg").style.color=c||"#b91c1c"}
function exportData(){let blob=new Blob([JSON.stringify({version:1,data,password},null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="qr-smart-backup.json";a.click()}
function importData(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(Array.isArray(x.data)){data=x.data;saveStore();if(x.password){password=x.password;localStorage.setItem(PASS,password)}refresh();alert("تم الاستيراد بنجاح")}else throw 0}catch(_){alert("ملف النسخة الاحتياطية غير صالح")}};r.readAsText(f)}
function clearAll(){if(confirm("سيتم حذف جميع الأكواد من هذا الجهاز. هل أنت متأكد؟")){data=[];saveStore();refresh()}}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
