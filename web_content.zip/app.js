// CLIPTOK Web V1 - Appwrite authentication and video storage starter
const { Client, Account, Storage, ID, Query } = Appwrite;
const ENDPOINT = "https://nyc.cloud.appwrite.io/v1";
const PROJECT_ID = "6b029f4f0010fd7beca2";
const BUCKET_ID = "cliptok_videos";
const client = new Client().setEndpoint(ENDPOINT).setProject(PROJECT_ID);
const account = new Account(client);
const storage = new Storage(client);
const $ = id => document.getElementById(id);
let currentUser = null;

function message(id, text){ $(id).textContent = text; }
function showApp(user){
 currentUser=user; $("auth").hidden=true; $("app").hidden=false;
 $("userLabel").textContent=user.email || "Creator";
 loadFeed();
}
async function checkSession(){
 try { const user=await account.get(); showApp(user); }
 catch(e){ $("auth").hidden=false; $("app").hidden=true; }
}
$("register").onclick=async()=>{
 const email=$("email").value.trim(), password=$("password").value;
 if(!email || password.length<8){message("authMsg","Enter an email and password of at least 8 characters.");return;}
 try { await account.create(ID.unique(),email,password); await account.createEmailPasswordSession(email,password); showApp(await account.get()); }
 catch(e){message("authMsg",e.message);}
};
$("login").onclick=async()=>{
 const email=$("email").value.trim(), password=$("password").value;
 try { await account.createEmailPasswordSession(email,password); showApp(await account.get()); }
 catch(e){message("authMsg",e.message);}
};
$("logout").onclick=async()=>{try{await account.deleteSession("current");}catch(e){} currentUser=null;showGuest();};
$("upload").onclick=async()=>{
 const file=$("videoFile").files[0];
 if(!file){message("uploadMsg","Choose a video first.");return;}
 if(!currentUser){message("uploadMsg","Please sign in first using the button at the top.");$("auth").hidden=false;window.scrollTo({top:0,behavior:"smooth"});return;}
 message("uploadMsg","Uploading… keep this page open.");
 try{
  const result=await storage.createFile(BUCKET_ID,ID.unique(),file);
  const caption=$("caption").value.trim();
  const url=storage.getFileView(BUCKET_ID,result.$id);
  addClip(url,caption,currentUser.email);
  $("caption").value="";$("videoFile").value="";
  message("uploadMsg","Upload complete. The clip is shown below.");
 }catch(e){message("uploadMsg","Upload failed: "+e.message+" Check the bucket permissions in Appwrite.");}
};
function addClip(url,caption,creator){
 const card=document.createElement("article");card.className="clip";
 const video=document.createElement("video");video.controls=true;video.playsInline=true;video.src=url;
 const text=document.createElement("div");text.className="caption";text.textContent=caption||"";
 const by=document.createElement("small");by.textContent="Posted by "+(creator||"CLIPTOK creator");
 card.append(video,text,by);$("feed").prepend(card);
}
async function loadFeed(){
 // V1 lists public files in the configured Appwrite Storage bucket.
 try{
  const result=await storage.listFiles(BUCKET_ID,[Query.limit(30),Query.orderDesc("$createdAt")]);
  $("feed").innerHTML="";
  if(!result.files.length){$("feed").innerHTML='<p class="message">No clips yet. Be the first to upload!</p>';return;}
  for(const f of result.files){
   const url=storage.getFileView(BUCKET_ID,f.$id);
   addClip(url,f.name,currentUser?.email||"CLIPTOK creator");
  }
 }catch(e){$("feed").innerHTML='<p class="message">Could not load clips. Check that file read permissions allow the signed-in user.</p>';}
}
if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));}
checkSession();
