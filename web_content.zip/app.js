const KEY='zgamesStaffV1';
let db=JSON.parse(localStorage.getItem(KEY)||'{"active":null,"shifts":[]}');
const idEl=document.getElementById('staffId'), action=document.getElementById('action');
function save(){localStorage.setItem(KEY,JSON.stringify(db))}
function fmt(t){return new Date(t).toLocaleString()}
function render(){
 document.getElementById('active').innerHTML=db.active?`<div class="active">Logged in: <b>${db.active.id}</b><br>Since: ${fmt(db.active.login)}</div>`:'';
 action.textContent=db.active?'LOGOUT':'LOGIN';
 const h=document.getElementById('history');
 if(!db.shifts.length){h.innerHTML='<div class="empty">No attendance records yet.</div>';return}
 h.innerHTML=[...db.shifts].reverse().map(s=>{let m=Math.round((s.logout-s.login)/60000);
 return `<div class="row"><b>${s.id}</b><div class="muted">Login: ${fmt(s.login)}<br>Logout: ${fmt(s.logout)}<br>Duration: ${Math.floor(m/60)}h ${m%60}m</div></div>`}).join('')
}
action.onclick=()=>{
 if(!db.active){
  let id=idEl.value.trim();
  if(!/^\d{4}$/.test(id)){alert('Enter exactly 4 digits');return}
  db.active={id,login:Date.now()}
 }else{db.shifts.push({...db.active,logout:Date.now()});db.active=null}
 idEl.value='';save();render()
};
document.getElementById('export').onclick=()=>{
 let csv='Staff ID,Login Time,Logout Time,Duration Minutes\n'+db.shifts.map(s=>`${s.id},"${fmt(s.login)}","${fmt(s.logout)}",${Math.round((s.logout-s.login)/60000)}`).join('\n');
 let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='ZgamesStaff_Attendance.csv';a.click()
};
render();