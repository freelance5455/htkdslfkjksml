const KEY="id_library_v12";
let state=JSON.parse(localStorage.getItem(KEY)||'{"items":[]}');
let page="library", searchText="";

const $=s=>document.querySelector(s);
const save=()=>localStorage.setItem(KEY,JSON.stringify(state));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const countChars=s=>Array.from(s).length;
const fmt=d=>{
  const x=new Date(d);
  return x.toLocaleString("zh-CN",{
    month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false
  }).replaceAll("/","-");
};

function toast(t){
  const e=$("#toast");
  e.textContent=t;
  e.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer=setTimeout(()=>e.classList.remove("show"),1600);
}

function addItems(text){
  const arr=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
  if(!arr.length){ toast("请输入 ID"); return; }
  const now=Date.now();
  arr.forEach((text,i)=>state.items.push({
    id:uid(), text, len:countChars(text), time:now+i, fav:false
  }));
  save();
  closeModal();
  render();
  toast(`已保存 ${arr.length} 条`);
}

function openModal(){
  $("#inputText").value="";
  $("#modal").classList.remove("hidden");
  setTimeout(()=>$("#inputText").focus(),50);
}
function closeModal(){$("#modal").classList.add("hidden");}

function toggleFav(id){
  const x=state.items.find(a=>a.id===id);
  if(x){x.fav=!x.fav;save();render();}
}
function remove(id){
  state.items=state.items.filter(x=>x.id!==id);
  save();render();toast("已删除");
}
function editItem(id){
  const x=state.items.find(a=>a.id===id);
  if(!x)return;
  $("#inputText").value=x.text;
  $("#modal").classList.remove("hidden");
  $("#saveBtn").onclick=()=>{
    const v=$("#inputText").value.trim().split(/\r?\n/)[0]||"";
    if(!v){toast("请输入 ID");return;}
    x.text=v;x.len=countChars(v);
    save();closeModal();bindSave();render();toast("已修改");
  };
  setTimeout(()=>$("#inputText").focus(),50);
}
function bindSave(){
  $("#saveBtn").onclick=()=>addItems($("#inputText").value);
}
function copyText(t){
  if(navigator.clipboard && window.isSecureContext){
    navigator.clipboard.writeText(t).then(()=>toast("已复制")).catch(()=>fallbackCopy(t));
  }else fallbackCopy(t);
}
function fallbackCopy(t){
  const ta=document.createElement("textarea");
  ta.value=t;document.body.appendChild(ta);ta.select();
  try{document.execCommand("copy");toast("已复制")}catch{toast("复制失败")}
  ta.remove();
}
function esc(s){
  return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]));
}
function rows(items){
  return items.slice().sort((a,b)=>b.time-a.time).map(x=>`
    <div class="item">
      <div class="idtext" onclick="copyText(${JSON.stringify(x.text)})">
        ${esc(x.text)}
        <div class="time">${fmt(x.time)}</div>
      </div>
      <button class="star ${x.fav?'on':''}" onclick="toggleFav('${x.id}')" aria-label="收藏">★</button>
      <button class="more-action" onclick="editItem('${x.id}')" aria-label="编辑">⋯</button>
    </div>`).join("");
}
function library(items){
  const filtered=items.filter(x=>!searchText||x.text.toLowerCase().includes(searchText.toLowerCase()));
  const groups={};
  filtered.forEach(x=>(groups[x.len]??=[]).push(x));
  const keys=Object.keys(groups).sort((a,b)=>+a-+b);
  return `<div class="content">
    <input id="searchBox" class="search" placeholder="搜索 ID" value="${esc(searchText)}">
    ${keys.length ? keys.map(k=>`
      <section class="group">
        <div class="group-title">${k} 个字符</div>
        ${rows(groups[k])}
      </section>`).join("")
    : `<div class="empty">还没有 ID<br><span>点击底部中间的＋开始记录</span></div>`}
  </div>`;
}
function favorites(items){
  const fav=items.filter(x=>x.fav);
  return `<div class="content">
    <div class="section-title">收藏 · ${fav.length}</div>
    ${fav.length ? rows(fav) : '<div class="empty">暂无收藏</div>'}
  </div>`;
}
function exportData(){
  download("ID灵感库备份.json",JSON.stringify(state,null,2),"application/json");
}
function exportTxt(){
  download("ID灵感库.txt",state.items.slice().sort((a,b)=>b.time-a.time).map(x=>x.text).join("\n"),"text/plain");
}
function exportCsv(){
  const q=v=>`"${String(v).replaceAll('"','""')}"`;
  const out=["ID,字符数,创建时间,收藏",...state.items.map(x=>[
    q(x.text),x.len,q(new Date(x.time).toLocaleString("zh-CN")),x.fav?1:0
  ].join(","))].join("\n");
  download("ID灵感库.csv",out,"text/csv");
}
function download(name,content,type){
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([content],{type}));
  a.download=name;a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),600);
}
function restoreData(e){
  const f=e.target.files[0];
  if(!f)return;
  const r=new FileReader();
  r.onload=()=>{
    try{
      const x=JSON.parse(r.result);
      if(!Array.isArray(x.items))throw new Error();
      state=x;save();render();toast("恢复成功");
    }catch{toast("备份文件无效");}
    e.target.value="";
  };
  r.readAsText(f);
}
function morePage(){
  return `<div class="content">
    <div class="section-title">数据</div>
    <button class="list-btn" onclick="exportData()">导出 JSON 备份</button>
    <button class="list-btn" onclick="exportTxt()">导出 TXT</button>
    <button class="list-btn" onclick="exportCsv()">导出 CSV</button>
    <button class="list-btn" onclick="document.getElementById('restore').click()">恢复 JSON 备份</button>
    <input id="restore" type="file" accept=".json" hidden onchange="restoreData(event)">
    <div class="section-title">关于</div>
    <div class="small">共保存 ${state.items.length} 个 ID。数据默认只保存在本机。</div>
  </div>`;
}

function render(){
  const main=$("#main");
  main.innerHTML=page==="library" ? library(state.items)
    : page==="favorites" ? favorites(state.items)
    : morePage();

  document.querySelectorAll(".nav button").forEach(b=>{
    b.classList.toggle("active",b.dataset.page===page);
  });

  const sb=$("#searchBox");
  if(sb){
    sb.addEventListener("input",e=>{searchText=e.target.value;render();});
  }
}

$("#floatingAdd").onclick=openModal;
$("#closeModal").onclick=()=>{closeModal();bindSave();};
$("#saveBtn").onclick=()=>addItems($("#inputText").value);
document.querySelectorAll(".nav button").forEach(b=>b.onclick=()=>{
  page=b.dataset.page;render();
});

bindSave();
render();

if("serviceWorker" in navigator){
  navigator.serviceWorker.register("service-worker.js").catch(()=>{});
}
