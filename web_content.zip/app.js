const $=id=>document.getElementById(id);
const today=new Date();
let selected=new Date(today.getFullYear(),today.getMonth(),today.getDate());
let viewMonth=new Date(today.getFullYear(),today.getMonth(),1);
let data=JSON.parse(localStorage.getItem('jb_data')||'{"sales":[],"expenses":[]}');
let account=JSON.parse(localStorage.getItem('jb_account')||'null');
let selectedHistory=new Set();
let pendingDelete=null;
const money=n=>new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}).format(n||0)+' FC';
const dateKey=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const save=()=>localStorage.setItem('jb_data',JSON.stringify(data));
const total=(arr,key)=>arr.filter(x=>x.date===key).reduce((s,x)=>s+Number(x.amount||0),0);
const monthTotal=(arr,y,m)=>arr.filter(x=>{let d=new Date(x.date+'T00:00:00');return d.getFullYear()===y&&d.getMonth()===m}).reduce((s,x)=>s+Number(x.amount||0),0);
function setScreen(id){document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active-screen',s.id===id));document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.screen===id));window.scrollTo({top:0,behavior:'instant'});renderAll();}
document.querySelectorAll('.bottom-nav button').forEach(b=>b.addEventListener('click',()=>setScreen(b.dataset.screen)));
function showApp(){ $('auth').classList.add('hidden');$('app').classList.remove('hidden');$('welcomeName').textContent=account.name;$('profilePageName').textContent=account.name;setScreen('home-screen'); }
function auth(){const name=$('accountName').value.trim(),pass=$('accountPassword').value;if(!name||pass.length<4){$('authMessage').textContent='Entre ton nom et un mot de passe de 4 caractères minimum.';return}
 if(account){if(name!==account.name||pass!==account.pass){$('authMessage').textContent='Nom ou mot de passe incorrect.';return}}
 else{account={name,pass};localStorage.setItem('jb_account',JSON.stringify(account));}
 showApp();}
$('authButton').addEventListener('click',auth);$('accountPassword').addEventListener('keydown',e=>{if(e.key==='Enter')auth()});
if(account)$('accountName').value=account.name;
$('logoutBtn').onclick=()=>{$('app').classList.add('hidden');$('auth').classList.remove('hidden');$('accountPassword').value=''};
function renderCalendar(){ $('monthLabel').textContent=viewMonth.toLocaleDateString('fr-FR',{month:'long',year:'numeric'});const first=new Date(viewMonth.getFullYear(),viewMonth.getMonth(),1),start=(first.getDay()+6)%7,days=new Date(viewMonth.getFullYear(),viewMonth.getMonth()+1,0).getDate();let out='';for(let i=0;i<42;i++){let n=i-start+1;if(n<1||n>days){out+='<div class="day muted-day"></div>';continue}let d=new Date(viewMonth.getFullYear(),viewMonth.getMonth(),n),key=dateKey(d),has=data.sales.some(x=>x.date===key);out+=`<button class="day ${key===dateKey(selected)?'selected':''} ${has?'has-sales':''}" data-date="${key}">${n}</button>`}$('calendar').innerHTML=out;document.querySelectorAll('.day[data-date]').forEach(b=>b.onclick=()=>{selected=new Date(b.dataset.date+'T00:00:00');renderAll()});}
$('prevMonth').onclick=()=>{viewMonth.setMonth(viewMonth.getMonth()-1);renderAll()};$('nextMonth').onclick=()=>{viewMonth.setMonth(viewMonth.getMonth()+1);renderAll()};
function renderDay(){const key=dateKey(selected),s=total(data.sales,key),e=total(data.expenses,key),net=s-e;$('selectedDateTitle').textContent=selected.toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'});$('selectedSales').textContent=money(s);$('selectedExpenses').textContent=money(e);$('selectedProfit').textContent=money(net);$('salesList').innerHTML=data.sales.filter(x=>x.date===key).map(x=>`<div class="record"><span>${esc(x.product)} × ${x.qty}</span><b>${money(x.amount)}</b></div>`).join('')||'Aucune vente pour cette date.';$('expensesList').innerHTML=data.expenses.filter(x=>x.date===key).map(x=>`<div class="record"><span>${esc(x.label)}</span><b>${money(x.amount)}</b></div>`).join('')||'Aucune dépense pour cette date.';$('salesList').classList.toggle('empty',!data.sales.some(x=>x.date===key));$('expensesList').classList.toggle('empty',!data.expenses.some(x=>x.date===key));const tk=dateKey(today),ts=total(data.sales,tk),te=total(data.expenses,tk);$('todaySales').textContent=money(ts);$('todayExpenses').textContent=money(te);$('todayProfit').textContent=money(ts-te);}
function historyKey(type,index){return type+':'+index;}
function renderHistory(){
 const y=viewMonth.getFullYear(),m=viewMonth.getMonth(),gross=monthTotal(data.sales,y,m),expenses=monthTotal(data.expenses,y,m);
 $('monthSales').textContent=money(gross);$('monthExpenses').textContent=money(expenses);$('monthProfit').textContent=money(gross-expenses);
 const byDate={};
 data.sales.forEach((x,i)=>{(byDate[x.date]??=[]).push({type:'sale',index:i,label:x.product,qty:x.qty,amount:Number(x.amount||0)});});
 data.expenses.forEach((x,i)=>{(byDate[x.date]??=[]).push({type:'expense',index:i,label:x.label,qty:null,amount:Number(x.amount||0)});});
 const dates=Object.keys(byDate).sort((a,b)=>b.localeCompare(a));
 if(!dates.length){$('historyList').innerHTML='Aucune opération enregistrée.';$('historyList').classList.add('empty');}
 else{
  $('historyList').classList.remove('empty');
  $('historyList').innerHTML=dates.map(date=>{
   const entries=byDate[date].sort((a,b)=>a.type.localeCompare(b.type));
   const daySales=entries.filter(x=>x.type==='sale').reduce((s,x)=>s+x.amount,0);
   const dayExpenses=entries.filter(x=>x.type==='expense').reduce((s,x)=>s+x.amount,0);
   const dayNet=daySales-dayExpenses;
   const dayKeys=entries.map(x=>historyKey(x.type,x.index));
   const allChecked=dayKeys.length&&dayKeys.every(k=>selectedHistory.has(k));
   const items=entries.map(x=>{
    const key=historyKey(x.type,x.index),checked=selectedHistory.has(key);
    return `<label class="history-item"><input type="checkbox" class="history-check" data-key="${key}" ${checked?'checked':''}><span class="history-item-main"><b>${x.type==='sale'?'Vente':'Dépense'} · ${esc(x.label||'Sans nom')}</b><small>${x.type==='sale'?'Quantité : '+x.qty:'Dépense'}</small></span><strong class="${x.type==='expense'?'expense-value':''}">${money(x.amount)}</strong></label>`;
   }).join('');
   return `<details class="history-day" open><summary><label class="day-select" onclick="event.stopPropagation()"><input type="checkbox" class="day-check" data-day="${date}" ${allChecked?'checked':''}></label><span class="history-date">${new Date(date+'T00:00:00').toLocaleDateString('fr-FR',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}</span><span class="history-day-net">${money(dayNet)}</span></summary><div class="history-day-summary"><span>Ventes : <b>${money(daySales)}</b></span><span>Dépenses : <b>${money(dayExpenses)}</b></span><span>Total net : <b>${money(dayNet)}</b></span></div><div class="history-items">${items}</div></details>`;
  }).join('');
 }
 updateSelectionControls();
}
function updateSelectionControls(){
 const count=selectedHistory.size;$('selectedCount').textContent=count;$('deleteSelectedBtn').disabled=count===0;
 const allKeys=[];data.sales.forEach((_,i)=>allKeys.push(historyKey('sale',i)));data.expenses.forEach((_,i)=>allKeys.push(historyKey('expense',i)));
 $('selectAllHistory').checked=allKeys.length>0&&allKeys.every(k=>selectedHistory.has(k));$('selectAllHistory').indeterminate=count>0&&!$('selectAllHistory').checked;
}
$('historyList').addEventListener('change',e=>{
 if(e.target.classList.contains('history-check')){const k=e.target.dataset.key;e.target.checked?selectedHistory.add(k):selectedHistory.delete(k);updateSelectionControls();const details=e.target.closest('.history-day');const day=details.querySelector('.day-check');const boxes=[...details.querySelectorAll('.history-check')];day.checked=boxes.length>0&&boxes.every(b=>b.checked);}
 if(e.target.classList.contains('day-check')){const date=e.target.dataset.day;const dayItems=[...$('historyList').querySelectorAll('.history-day')].find(d=>d.querySelector('.day-check')===e.target);dayItems.querySelectorAll('.history-check').forEach(box=>{box.checked=e.target.checked;e.target.checked?selectedHistory.add(box.dataset.key):selectedHistory.delete(box.dataset.key)});updateSelectionControls();}
});
$('selectAllHistory').onchange=e=>{selectedHistory.clear();if(e.target.checked){data.sales.forEach((_,i)=>selectedHistory.add(historyKey('sale',i)));data.expenses.forEach((_,i)=>selectedHistory.add(historyKey('expense',i)));}renderHistory();};
function renderAll(){renderCalendar();renderDay();renderHistory();}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function preview(){let q=Number($('productQty').value)||0,p=Number($('productPrice').value)||0;$('salePreview').textContent=money(q*p)}
$('productQty').oninput=preview;$('productPrice').oninput=preview;
$('saleForm').onsubmit=e=>{e.preventDefault();let qty=Number($('productQty').value),price=Number($('productPrice').value);if(qty<1||price<0)return;data.sales.push({date:dateKey(selected),product:$('productName').value.trim(),qty,amount:qty*price});save();$('saleForm').reset();$('productQty').value=1;preview();renderAll()};
$('expenseForm').onsubmit=e=>{e.preventDefault();let amount=Number($('expenseAmount').value);if(amount<0)return;data.expenses.push({date:dateKey(selected),label:$('expenseName').value.trim(),amount});save();$('expenseForm').reset();renderAll()};
function openDeleteModal(){if(!selectedHistory.size)return;pendingDelete=new Set(selectedHistory);$('deleteModalText').textContent=`Tu vas supprimer ${pendingDelete.size} opération(s). Entre le mot de passe de ton profil pour confirmer.`;$('deletePassword').value='';$('deleteError').textContent='';$('deleteModal').classList.remove('hidden');$('deletePassword').focus();}
function closeDeleteModal(){$('deleteModal').classList.add('hidden');$('deletePassword').value='';pendingDelete=null;}
$('deleteSelectedBtn').onclick=openDeleteModal;$('cancelDeleteBtn').onclick=closeDeleteModal;
$('confirmDeleteBtn').onclick=()=>{
 if(!$('deletePassword').value){$('deleteError').textContent='Entre ton mot de passe.';return;}
 if(!account||$('deletePassword').value!==account.pass){$('deleteError').textContent='Mot de passe incorrect. Aucune opération supprimée.';return;}
 const saleIndexes=new Set(),expenseIndexes=new Set();
 pendingDelete.forEach(key=>{const [type,index]=key.split(':');(type==='sale'?saleIndexes:expenseIndexes).add(Number(index));});
 data.sales=data.sales.filter((_,i)=>!saleIndexes.has(i));data.expenses=data.expenses.filter((_,i)=>!expenseIndexes.has(i));
 try{save();selectedHistory.clear();closeDeleteModal();renderAll();}catch(err){$('deleteError').textContent='Impossible d’enregistrer la modification. Vérifie l’espace disponible.';}
};
$('deletePassword').addEventListener('keydown',e=>{if(e.key==='Enter')$('confirmDeleteBtn').click();});
if(account)showApp();else $('auth').classList.remove('hidden');
