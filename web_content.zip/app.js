(() => {
  'use strict';

  const DATA = {
    1: { title: 'Voyelles', subtitle: 'Les sons de base', items: ['a','e','é','è','ê','ë','i','î','ï','o','ô','u','û','ü','y'] },
    2: { title: 'Syllabes simples', subtitle: 'Consonne + voyelle', items: cv(['b','c','d','f','g','j','l','m','n','p','r','s','t','v'], ['a','e','i','o','u','y']) },
    3: { title: 'Sons fréquents', subtitle: 'ou, oi, ai, ei, au, eau, eu…', items: unique(['ou','oi','ai','ei','au','eau','eu','œu','ui','oin','ion','ien','ien','oin','oin','qu','gu','ch','ph','gn','ill', ...cv(['b','c','d','f','j','l','m','n','p','r','s','t','v'], ['ou','oi','ai','ei','au','eu','ui'])]) },
    4: { title: 'Groupes consonantiques', subtitle: 'Deux consonnes + voyelle', items: cv(['bl','br','cl','cr','dr','fl','fr','gl','gr','pl','pr','tr','vr'], ['a','e','i','o','u','ou','oi']) },
    5: { title: 'Sons nasaux', subtitle: 'an, en, on, in, un…', items: unique(['an','am','en','em','on','om','in','im','yn','ym','un','um','ain','ein','aim','eim','ien','oin', ...cv(['b','c','d','f','g','j','l','m','p','r','s','t','v'], ['an','en','on','in','un','ain','ein'])]) },
    6: { title: 'Sons et écritures', subtitle: 'ch, j, gn, ill, qu, gu…', items: unique(['ch','j','ge','gi','g(e)','g(i)','gu','qu','k','ph','th','gn','ill','tion','sion','ss','ç','c(e)','c(i)','c(y)','s(e)','s(i)','s(y)','x','ks','z']) },
    7: { title: 'Mélange', subtitle: 'Tout réviser', items: [] }
  };

  DATA[7].items = unique(Object.values(DATA).flatMap(x => x.items));

  const WORDS = {
    'ba':['bateau','ballon','banane'],'be':['bébé','beurre'],'bi':['biberon','biche'],'bo':['bol','botte'],'bu':['bus','bulletin'],
    'ca':['cadeau','cabane','canard'],'co':['coq','colis'],'cu':['cube','culotte'],'da':['dame','danse'],'de':['deux','dent'],
    'di':['dinosaure','dix'],'do':['domino','dodo'],'du':['dur','dune'],'fa':['famille','farine'],'fi':['fille','ficelle'],
    'fo':['forêt','fourmi'],'fu':['fumée','fusée'],'la':['lapin','lama'],'le':['lettre','léon'],'li':['livre','lit'],
    'lo':['loto','loup'],'lu':['lune','lumière'],'ma':['maman','maison'],'me':['melon','mer'],'mi':['mimi','miel'],
    'mo':['moto','mouton'],'mu':['musique','mur'],'na':['nager','navire'],'ne':['nez','neige'],'ni':['nid','niveau'],
    'no':['noël','note'],'nu':['nuage','nuit'],'pa':['papa','pantalon'],'pe':['petit','peinture'],'pi':['pied','pirate'],
    'po':['pomme','poisson'],'pu':['poule','pull'],'ra':['radio','rat'],'re':['renard','repas'],'ri':['riz','rivière'],
    'ro':['robot','rose'],'ru':['rue','ruban'],'sa':['sac','salade'],'se':['serpent','semaine'],'si':['singe','sifflet'],
    'so':['soleil','souris'],'su':['sucre','super'],'ta':['table','tasse'],'te':['téléphone','terre'],'ti':['tigre','tissu'],
    'to':['tomate','tortue'],'tu':['tulipe','tuyau'],'va':['vache','valise'],'ve':['vélo','vent'],'vi':['ville','vis'],
    'vo':['voiture','volcan'],'vu':['vue','vulgaire'],'ou':['ours','ouistiti'],'oi':['oiseau','poisson'],'ai':['aigle','aide'],
    'au':['auto','autruche'],'eau':['eau','bateau'],'eu':['feu','deux'],'ch':['chat','chapeau'],'gn':['montagne','agneau'],
    'ph':['photo','phare'],'qu':['quatre','queue'],'ill':['fille','quille'],'an':['ange','orange'],'on':['onze','bonbon'],
    'in':['lapin','matin'],'un':['un','parfum'],'ain':['pain','main'],'ein':['plein','peinture']
  };


  // Banque de mots illustrés : les emojis servent d'images locales, donc
  // l'application fonctionne sans Internet dans Termux.
  const PICTURE_WORDS = [
    ['chat','🐱','ch'], ['chien','🐶','chi'], ['moto','🏍️','mo'], ['vélo','🚲','vé'],
    ['banane','🍌','ba'], ['pomme','🍎','po'], ['poisson','🐟','poi'], ['oiseau','🐦','oi'],
    ['lapin','🐰','la'], ['lion','🦁','li'], ['singe','🐵','si'], ['tigre','🐯','ti'],
    ['vache','🐄','va'], ['poule','🐔','pou'], ['mouton','🐑','mou'], ['cheval','🐴','che'],
    ['maison','🏠','mai'], ['école','🏫','é'], ['livre','📖','li'], ['stylo','🖊️','sty'],
    ['ballon','⚽','ba'], ['fleur','🌸','fleur'], ['soleil','☀️','so'], ['lune','🌙','lu'],
    ['étoile','⭐','é'], ['arbre','🌳','ar'], ['eau','💧','eau'], ['feu','🔥','feu'],
    ['maman','👩','ma'], ['papa','👨','pa'], ['bébé','👶','bé'], ['bébé','🍼','bé'],
    ['table','🪑','ta'], ['tomate','🍅','to'], ['orange','🍊','or'], ['carotte','🥕','ca'],
    ['gâteau','🍰','gâ'], ['pain','🍞','pa'], ['fromage','🧀','fro'], ['photo','📷','pho']
  ].map(([word, emoji, syllable]) => ({word, emoji, syllable}));

  const WORDS_PER_LEVEL = {
    1: PICTURE_WORDS.filter(x => ['école','étoile','eau','feu','orange'].includes(x.word)),
    2: PICTURE_WORDS.filter(x => ['chat','chien','moto','vélo','banane','pomme','lapin','lion','vache','papa','maman','bébé','table','tomate','pain'].includes(x.word)),
    3: PICTURE_WORDS.filter(x => ['poisson','oiseau','maison','soleil','lune','fleur','fromage','photo','gâteau','carotte'].includes(x.word)),
    4: PICTURE_WORDS.filter(x => ['tigre','singe','cheval','mouton','arbre','stylo','ballon'].includes(x.word)),
    5: PICTURE_WORDS.filter(x => ['pain','orange','bonbon','maman','maison','soleil'].includes(x.word)),
    6: PICTURE_WORDS,
    7: PICTURE_WORDS
  };

  // Comptes utilisateurs : chaque nom possède sa propre progression sur l'appareil.
  const USERS_KEY = 'syllabe_users_v1';
  const ACTIVE_USER_KEY = 'syllabe_active_user_v1';
  const LEGACY_KEYS = ['syllabes_score','syllabes_completed','syllabe_level_correct','syllabe_word_correct','syllabe_unlocked_level'];
  const DEFAULT_PROFILE = () => ({ score: 0, completed: {}, levelCorrect: {}, wordCorrect: {}, unlockedLevel: 1 });
  // Sécurité locale : aucune donnée utilisateur n'est interprétée comme du HTML/JS.
  // Les anciennes données corrompues ou invalides sont ignorées au lieu de faire planter l'app.
  function safeJSON(value, fallback) {
    try { return value ? JSON.parse(value) : fallback; } catch (_) { return fallback; }
  }
  function safeStorageGet(key, fallback = '') {
    try { return localStorage.getItem(key) ?? fallback; } catch (_) { return fallback; }
  }
  let parsedUsers = safeJSON(safeStorageGet(USERS_KEY, '{}'), {});
  let users = (parsedUsers && typeof parsedUsers === 'object' && !Array.isArray(parsedUsers)) ? parsedUsers : {};
  let activeUser = safeStorageGet(ACTIVE_USER_KEY, '');

  function cleanName(name) {
    return String(name || '').replace(/[\u0000-\u001F\u007F]/g, '').trim().replace(/\s+/g, ' ').slice(0, 30);
  }
  function slugName(name) { return cleanName(name).toLocaleLowerCase('fr-FR'); }
  function saveUsers() {
    try {
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      return true;
    } catch (_) {
      if (typeof message !== 'undefined' && message) message.textContent = '⚠️ Impossible d’enregistrer la progression sur cet appareil.';
      return false;
    }
  }
  function profileFor(name) {
    const key = slugName(name);
    if (!users[key]) users[key] = { name: cleanName(name), ...DEFAULT_PROFILE() };
    users[key].name = cleanName(name);
    users[key].completed = users[key].completed || {};
    users[key].levelCorrect = users[key].levelCorrect || {};
    users[key].wordCorrect = users[key].wordCorrect || {};
    users[key].score = Number(users[key].score || 0);
    users[key].unlockedLevel = Math.min(7, Math.max(1, Number(users[key].unlockedLevel || 1)));
    return users[key];
  }

  // Migration transparente de la progression V3.2 vers le premier compte.
  if (!Object.keys(users).length) {
    const legacyScore = Number(localStorage.getItem('syllabes_score') || 0);
    const legacyCompleted = safeJSON(safeStorageGet('syllabes_completed', '{}'), {});
    const legacyLevelCorrect = safeJSON(safeStorageGet('syllabe_level_correct', '{}'), {});
    const legacyWordCorrect = safeJSON(safeStorageGet('syllabe_word_correct', '{}'), {});
    const legacyUnlocked = Math.min(7, Math.max(1, Number(localStorage.getItem('syllabe_unlocked_level') || 1)));
    if (legacyScore || Object.keys(legacyCompleted).length || Object.keys(legacyLevelCorrect).length || Object.keys(legacyWordCorrect).length || legacyUnlocked > 1) {
      const migrated = profileFor('Utilisateur');
      Object.assign(migrated, { score: legacyScore, completed: legacyCompleted, levelCorrect: legacyLevelCorrect, wordCorrect: legacyWordCorrect, unlockedLevel: legacyUnlocked });
      activeUser = slugName('Utilisateur');
      saveUsers();
    }
  }

  let profile = activeUser && users[activeUser] ? profileFor(users[activeUser].name) : null;
  if (profile) activeUser = slugName(profile.name);

  let wordQuizAnswered = false;
  let wordAnswer = null;

  function updateWordCounter() {
    const lvl = Number(levelEl.value);
    const correct = Math.min(QUESTIONS_TO_UNLOCK, Number(wordCorrect[lvl] || 0));
    wordCounter.textContent = `${correct} / ${QUESTIONS_TO_UNLOCK}`;
    wordProgress.style.width = Math.round(correct / QUESTIONS_TO_UNLOCK * 100) + '%';
  }

  function showWordQuiz() {
    wordQuiz.classList.remove('hidden');
    newWordQuiz();
  }

  function newWordQuiz() {
    wordQuizAnswered = false;
    const lvl = Number(levelEl.value);
    const pool = WORDS_PER_LEVEL[lvl] && WORDS_PER_LEVEL[lvl].length ? WORDS_PER_LEVEL[lvl] : PICTURE_WORDS;
    wordAnswer = pool[Math.floor(Math.random() * pool.length)];
    const choices = new Set([wordAnswer.word]);
    while (choices.size < Math.min(4, pool.length)) choices.add(pool[Math.floor(Math.random() * pool.length)].word);
    const arr = [...choices].sort(() => Math.random() - 0.5);
    wordImage.textContent = wordAnswer.emoji;
    wordQuestion.textContent = 'Quel est le mot ?';
    wordResult.textContent = '';
    wordChoices.innerHTML = '';
    arr.forEach(word => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'wordChoice'; b.textContent = word;
      b.addEventListener('click', () => answerWord(word, b));
      wordChoices.appendChild(b);
    });
  }

  function answerWord(word, button) {
    if (wordQuizAnswered) return;
    if (word === wordAnswer.word) {
      wordQuizAnswered = true;
      const lvl = Number(levelEl.value);
      wordCorrect[lvl] = Math.min(QUESTIONS_TO_UNLOCK, Number(wordCorrect[lvl] || 0) + 1);
      saveProfile();
      addScore(10);
      wordResult.textContent = '🌟 Bravo ! Bonne réponse.';
      button.classList.add('correct');
      wordText.textContent = wordAnswer.word;
      wordHint.textContent = `Mot avec « ${wordAnswer.syllable} »`;
      wordCard.classList.remove('hidden');
      current.textContent = wordAnswer.word;
      speak(wordAnswer.word, {silent:true});
      [...wordChoices.querySelectorAll('button')].forEach(x => x.disabled = true);
      updateWordCounter();
    } else {
      button.classList.add('wrong');
      wordResult.textContent = '💡 Essaie encore !';
      speak(wordAnswer.word, {silent:true});
    }
  }

  const levelEl = document.getElementById('level');
  const rateEl = document.getElementById('rate');
  const grid = document.getElementById('grid');
  const current = document.getElementById('current');
  const message = document.getElementById('message');
  const selectedList = document.getElementById('selectedList');
  const count = document.getElementById('count');
  const levelTitle = document.getElementById('levelTitle');
  const levelSubtitle = document.getElementById('levelSubtitle');
  const progress = document.getElementById('progress');
  const progressText = document.getElementById('progressText');
  const scoreEls = [document.getElementById('homeScore'), document.getElementById('progressScore')].filter(Boolean);
  function setScoreDisplay(value) { scoreEls.forEach(el => { el.textContent = value; }); }
  const quiz = document.getElementById('quiz');
  const quizQuestion = document.getElementById('quizQuestion');
  const quizChoices = document.getElementById('quizChoices');
  const quizResult = document.getElementById('quizResult');
  const quizCounter = document.getElementById('quizCounter');
  const quizProgress = document.getElementById('quizProgress');
  const wordCard = document.getElementById('wordCard');
  const wordText = document.getElementById('wordText');
  const wordHint = document.getElementById('wordHint');
  const wordQuiz = document.getElementById('wordQuiz');
  const wordImage = document.getElementById('wordImage');
  const wordQuestion = document.getElementById('wordQuestion');
  const wordChoices = document.getElementById('wordChoices');
  const wordResult = document.getElementById('wordResult');
  const wordCounter = document.getElementById('wordCounter');
  const wordProgress = document.getElementById('wordProgress');

  let selected = [];
  let lastText = '';
  let quizAnswer = '';
  let score = profile ? profile.score : 0;
  let completed = profile ? profile.completed : {};
  let levelCorrect = profile ? profile.levelCorrect : {};
  let wordCorrect = profile ? profile.wordCorrect : {};
  let unlockedLevel = profile ? profile.unlockedLevel : 1;
  let quizAnswered = false;
  let voices = [];

  const QUESTIONS_TO_UNLOCK = 200;

  function saveProfile() {
    if (!profile) return;
    profile.name = cleanName(profile.name);
    profile.score = score;
    profile.completed = completed;
    profile.levelCorrect = levelCorrect;
    profile.wordCorrect = wordCorrect;
    profile.unlockedLevel = unlockedLevel;
    users[activeUser] = profile;
    saveUsers();
    try { localStorage.setItem(ACTIVE_USER_KEY, activeUser); } catch (_) { /* stockage indisponible */ }
  }

  function refreshUserUI() {
    const name = profile ? profile.name : 'Utilisateur';
    const wb = document.querySelector('#userBadge span');
    const wu = document.getElementById('welcomeUser');
    if (wb) wb.textContent = name;
    if (wu) wu.textContent = name;
  }

  function openUserModal() {
    const modal = document.getElementById('userModal');
    const input = document.getElementById('userNameInput');
    if (!modal) return;
    renderUserList();
    input.value = '';
    modal.classList.remove('hidden');
    setTimeout(() => input.focus(), 50);
  }

  function closeUserModal() { document.getElementById('userModal')?.classList.add('hidden'); }

  function renderUserList() {
    const list = document.getElementById('userList');
    if (!list) return;
    list.innerHTML = '';
    Object.entries(users).sort((a,b) => a[1].name.localeCompare(b[1].name, 'fr')).forEach(([key, u]) => {
      const row = document.createElement('div');
      row.className = 'userItem' + (key === activeUser ? ' active' : '');
      const label = document.createElement('strong'); label.textContent = '👤 ' + u.name;
      const btn = document.createElement('button'); btn.type = 'button'; btn.textContent = key === activeUser ? 'Actif' : 'Utiliser'; btn.disabled = key === activeUser;
      btn.addEventListener('click', () => switchUser(key));
      row.append(label, btn); list.appendChild(row);
    });
  }

  function switchUser(key) {
    if (!users[key]) return;
    saveProfile();
    activeUser = key;
    profile = profileFor(users[key].name);
    score = profile.score; completed = profile.completed; levelCorrect = profile.levelCorrect; wordCorrect = profile.wordCorrect; unlockedLevel = profile.unlockedLevel;
    selected = []; quizAnswered = false; wordQuizAnswered = false;
    try { localStorage.setItem(ACTIVE_USER_KEY, activeUser); } catch (_) { /* stockage indisponible */ }
    setScoreDisplay(score); updateLevelLocks(); levelEl.value = String(Math.min(unlockedLevel, 7)); render(); updateWordCounter(); updateHomeStats(); refreshUserUI();
    closeUserModal();
  }

  function createUserFromInput() {
    const input = document.getElementById('userNameInput');
    const name = cleanName(input?.value);
    if (!name) { input?.focus(); return; }
    const key = slugName(name);
    if (!users[key]) users[key] = { name, ...DEFAULT_PROFILE() };
    switchUser(key);
  }

  setScoreDisplay(score);
  refreshUserUI();

  function unique(arr) { return [...new Set(arr)]; }
  function cv(cs, vs) { return cs.flatMap(c => vs.map(v => c + v)); }

  function loadVoices() {
    if ('speechSynthesis' in window) voices = speechSynthesis.getVoices();
  }
  loadVoices();
  if ('speechSynthesis' in window) speechSynthesis.onvoiceschanged = loadVoices;

  enableTapReading();

  function chooseVoice() {
    return voices.find(v => /^fr(-|_)/i.test(v.lang) && /Google|Microsoft|français|French/i.test(v.name))
      || voices.find(v => /^fr(-|_)/i.test(v.lang)) || null;
  }

  // Certaines graphies isolées (ë, ê, æ, ny, etc.) sont mal interprétées
  // par les voix Android. On les fait entendre avec une courte formulation
  // française stable, tout en gardant la graphie originale affichée à l'enfant.
  const PRONUNCIATION_GUIDE = {
    'a': 'a', 'e': 'e', 'é': 'é', 'è': 'è', 'ê': 'ê', 'ë': 'e tréma',
    'i': 'i', 'î': 'i accent circonflexe', 'ï': 'i tréma',
    'o': 'o', 'ô': 'o accent circonflexe', 'u': 'u', 'û': 'u accent circonflexe',
    'ü': 'u tréma', 'y': 'i grec', 'ÿ': 'i grec tréma',
    'ä': 'a tréma', 'ö': 'o tréma', 'æ': 'a e', 'œ': 'eu',
    'ë': 'e tréma', 'ė': 'e accent',
    'ny': 'gn, comme dans agneau', 'gn': 'gn, comme dans agneau',
    'ill': 'ill, comme dans fille', 'ph': 'f, comme dans photo',
    'th': 't, comme dans théâtre', 'qu': 'k, comme dans quatre',
    'gu': 'g dur, comme dans guitare', 'ch': 'ch, comme dans chat',
    'ç': 'cédille', 'c(e)': 's, comme dans ceci', 'c(i)': 's, comme dans cinéma', 'c(y)': 's, comme dans cycle',
    's(e)': 's, comme dans semaine', 's(i)': 's, comme dans si', 's(y)': 's, comme dans symbole',
    'ks': 'ks, comme dans taxi', 'x': 'iks', 'z': 'zède',
    'tion': 'sion, comme dans attention', 'sion': 'sion, comme dans vision'
  };

  function speechText(text) {
    const key = String(text).trim().toLowerCase();
    return PRONUNCIATION_GUIDE[key] || text;
  }

  function speak(text, options = {}) {
    if (!('speechSynthesis' in window)) {
      message.textContent = 'La voix n’est pas disponible sur cet appareil.';
      return;
    }
    speechSynthesis.cancel();
    const spoken = speechText(text);
    const u = new SpeechSynthesisUtterance(spoken);
    u.lang = 'fr-FR';
    u.rate = options.rate ?? Number(rateEl.value);
    u.pitch = options.pitch ?? 1;
    u.volume = 1;
    const voice = chooseVoice();
    if (voice) u.voice = voice;
    lastText = text;
    if (!options.silent) message.textContent = '🔊 Écoute : ' + text;
    u.onend = () => { if (lastText === text) message.textContent = 'Bravo, tu peux répéter !'; };
    speechSynthesis.speak(u);
  }

  function markCompleted(s) {
    completed[s] = true;
    saveProfile();
    updateProgress();
  }

  function updateQuizCounter() {
    const lvl = Number(levelEl.value);
    const correct = Math.min(QUESTIONS_TO_UNLOCK, Number(levelCorrect[lvl] || 0));
    quizCounter.textContent = `${correct} / ${QUESTIONS_TO_UNLOCK}`;
    quizProgress.style.width = Math.round(correct / QUESTIONS_TO_UNLOCK * 100) + '%';
  }

  function updateProgress() {
    const lvl = Number(levelEl.value);
    const correct = Math.min(QUESTIONS_TO_UNLOCK, Number(levelCorrect[lvl] || 0));
    const pct = Math.round(correct / QUESTIONS_TO_UNLOCK * 100);
    progress.style.width = pct + '%';
    progressText.textContent = `${correct}/${QUESTIONS_TO_UNLOCK} bonnes réponses`;
    if (lvl < 7 && correct >= QUESTIONS_TO_UNLOCK) {
      progressText.textContent = `Niveau terminé ! ${QUESTIONS_TO_UNLOCK}/${QUESTIONS_TO_UNLOCK}`;
    }
    updateQuizCounter();
  }

  function updateLevelLocks() {
    [...levelEl.options].forEach(opt => {
      const n = Number(opt.value);
      opt.disabled = n > unlockedLevel;
      opt.textContent = opt.textContent.replace(/ 🔒| 🔓/g, '') + (n > unlockedLevel ? ' 🔒' : '');
    });
    if (Number(levelEl.value) > unlockedLevel) levelEl.value = String(unlockedLevel);
  }

  function registerCorrectAnswer() {
    const lvl = Number(levelEl.value);
    levelCorrect[lvl] = Number(levelCorrect[lvl] || 0) + 1;
    saveProfile();
    if (levelCorrect[lvl] >= QUESTIONS_TO_UNLOCK && lvl < 7 && unlockedLevel === lvl) {
      unlockedLevel = lvl + 1;
      saveProfile();
      updateLevelLocks();
      message.textContent = `🎉 Niveau ${lvl} terminé ! Le niveau ${unlockedLevel} est débloqué !`;
    }
    updateProgress();
    updateHomeStats();
  }

  window.SyllabeGo = function(name) {
    const target = document.getElementById('page-' + name);
    if (!target) return;
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    target.classList.add('active');
    document.querySelectorAll('.navBtn').forEach(b => b.classList.toggle('active', b.dataset.page === name));
    updateHomeStats();
    window.scrollTo(0, 0);
  };

  function showPage(name) { window.SyllabeGo(name); }

  function updateHomeStats() {
    const hs=document.getElementById('homeScore'), hl=document.getElementById('homeLevel'), hc=document.getElementById('homeCorrect'), hsy=document.getElementById('homeSyllables');
    if(hs) hs.textContent=score;
    if(hl) hl.textContent=unlockedLevel;
    if(hc) hc.textContent=Object.values(levelCorrect).reduce((a,b)=>a+Number(b||0),0);
    if(hsy) hsy.textContent=Object.values(completed).filter(Boolean).length;
    const ps=document.getElementById('progressScore'), pl=document.getElementById('progressLevel');
    if(ps) ps.textContent=score; if(pl) pl.textContent=unlockedLevel;
  }

  document.querySelectorAll('.navBtn').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
  document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.go)));
  updateLevelLocks();

  // Lecture orale au toucher : seuls les éléments pédagogiques marqués
  // comme prononçables sont lus. Les boutons de navigation, exercices,
  // paramètres et autres commandes restent silencieux.
  function enableTapReading() {
    document.addEventListener('click', (event) => {
      const target = event.target.closest('[data-speak-tap]');
      if (!target) return;
      const text = target.getAttribute('data-speak-tap');
      if (text) speak(text);
    });
  }

  function render() {
    const level = DATA[levelEl.value];
    levelTitle.textContent = level.title;
    levelSubtitle.textContent = level.subtitle;
    grid.innerHTML = '';
    unique(level.items).forEach(s => {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'syllable' + (selected.includes(s) ? ' selected' : '') + (completed[s] ? ' learned' : '');
      b.textContent = s;
      b.setAttribute('aria-label', 'Écouter ' + s);
      b.setAttribute('data-speak-tap', s);
      b.addEventListener('click', () => {
        current.textContent = s;
        markCompleted(s);
        toggleSelected(s, b);
        showWord(s);
      });
      grid.appendChild(b);
    });
    renderSelection();
    updateProgress();
  }

  function toggleSelected(s, b) {
    const i = selected.indexOf(s);
    if (i === -1) { selected.push(s); b.classList.add('selected'); }
    else { selected.splice(i, 1); b.classList.remove('selected'); }
    renderSelection();
  }

  function renderSelection() {
    count.textContent = selected.length;
    selectedList.innerHTML = '';
    if (!selected.length) { selectedList.textContent = 'Aucune syllabe sélectionnée.'; return; }
    selected.forEach(s => {
      const span = document.createElement('button');
      span.type = 'button'; span.className = 'chip'; span.textContent = s;
      span.setAttribute('data-speak-tap', s);
      span.title = 'Retirer ' + s;
      span.addEventListener('click', () => { selected = selected.filter(x => x !== s); render(); });
      selectedList.appendChild(span);
    });
  }

  function showWord(s) {
    const words = WORDS[s];
    if (!words) { wordCard.classList.add('hidden'); return; }
    const word = words[Math.floor(Math.random() * words.length)];
    wordText.textContent = word;
    wordHint.textContent = `Le son « ${s} » se trouve dans ce mot.`;
    wordCard.classList.remove('hidden');
  }

  function playSelected() {
    if (!selected.length) { message.textContent = 'Choisis une ou plusieurs syllabes.'; return; }
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    let i = 0;
    const next = () => {
      if (i >= selected.length) { message.textContent = '🎉 Lecture terminée !'; return; }
      const s = selected[i++]; current.textContent = s; showWord(s);
      const u = new SpeechSynthesisUtterance(speechText(s)); u.lang = 'fr-FR'; u.rate = Number(rateEl.value); u.pitch = 1;
      const voice = chooseVoice(); if (voice) u.voice = voice;
      u.onend = () => setTimeout(next, 250); speechSynthesis.speak(u);
    };
    message.textContent = '🔊 Lecture de la sélection…'; next();
  }

  function addScore(points) {
    score += points; setScoreDisplay(score); saveProfile(); updateHomeStats();
  }

  function newQuiz() {
    quizAnswered = false;
    const uniqueItems = unique(DATA[levelEl.value].items);
    if (!uniqueItems.length) return;
    quizAnswer = uniqueItems[Math.floor(Math.random() * uniqueItems.length)];
    const choices = new Set([quizAnswer]);
    while (choices.size < Math.min(4, uniqueItems.length)) choices.add(uniqueItems[Math.floor(Math.random() * uniqueItems.length)]);
    const arr = [...choices].sort(() => Math.random() - 0.5);
    quizQuestion.textContent = '👂 Écoute puis trouve la syllabe';
    quizChoices.innerHTML = ''; quizResult.textContent = '';
    arr.forEach(s => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'quizChoice'; b.textContent = s;
      b.addEventListener('click', () => {
        if (quizAnswered) return;
        if (s === quizAnswer) {
          quizAnswered = true;
          registerCorrectAnswer();
          quizResult.textContent = levelCorrect[Number(levelEl.value)] >= QUESTIONS_TO_UNLOCK ? '🏆 Niveau terminé !' : '🌟 Bravo ! +10 points';
          addScore(10); current.textContent = s; markCompleted(s); showWord(s);
          [...quizChoices.querySelectorAll('button')].forEach(x => x.disabled = true);
        } else {
          quizResult.textContent = '💡 Pas encore. Réécoute et essaie.';
          speak(quizAnswer, {silent:true});
        }
      });
      quizChoices.appendChild(b);
    });
    setTimeout(() => speak(quizAnswer), 150);
  }

  document.getElementById('playBtn').addEventListener('click', playSelected);
  document.getElementById('repeatBtn').addEventListener('click', () => {
    if (selected.length) speak(selected.join(' '));
    else if (current.textContent !== '—') speak(current.textContent);
    else message.textContent = 'Rien à répéter.';
  });
  document.getElementById('clearBtn').addEventListener('click', () => { selected = []; render(); message.textContent = 'Sélection effacée.'; });
  document.getElementById('stopBtn').addEventListener('click', () => { if ('speechSynthesis' in window) speechSynthesis.cancel(); message.textContent = 'Lecture arrêtée.'; });
  document.getElementById('quizBtn').addEventListener('click', () => { showPage('exercices'); quiz.classList.remove('hidden'); newQuiz(); });
  document.getElementById('nextQuizBtn').addEventListener('click', newQuiz);
  document.getElementById('closeQuizBtn').addEventListener('click', () => quiz.classList.add('hidden'));
  document.getElementById('speakWordBtn').addEventListener('click', () => wordText.textContent !== '—' && speak(wordText.textContent));
  document.getElementById('wordQuizBtn').addEventListener('click', () => { showPage('mots'); showWordQuiz(); });
  document.getElementById('nextWordBtn').addEventListener('click', newWordQuiz);
  document.getElementById('closeWordQuizBtn').addEventListener('click', () => wordQuiz.classList.add('hidden'));
  document.getElementById('userBtn').addEventListener('click', openUserModal);
  document.getElementById('switchUserBtn').addEventListener('click', openUserModal);
  document.getElementById('closeUserModal').addEventListener('click', closeUserModal);
  document.getElementById('saveUserBtn').addEventListener('click', createUserFromInput);
  document.getElementById('userNameInput').addEventListener('keydown', e => { if (e.key === 'Enter') createUserFromInput(); });
  document.getElementById('userModal').addEventListener('click', e => { if (e.target.id === 'userModal') closeUserModal(); });

  document.getElementById('resetBtn').addEventListener('click', () => {
    if (!confirm('Effacer la progression et le score ?')) return;
    score = 0; completed = {}; levelCorrect = {}; wordCorrect = {}; unlockedLevel = 1; quizAnswered = false; wordQuizAnswered = false; saveProfile(); setScoreDisplay(0); updateHomeStats(); updateLevelLocks(); levelEl.value = '1'; render(); updateWordCounter();
  });
  levelEl.addEventListener('change', () => { selected = []; quiz.classList.add('hidden'); wordQuiz.classList.add('hidden'); render(); updateWordCounter(); });

  levelEl.value = String(Math.min(unlockedLevel, 7));
  render();
  updateWordCounter();
  updateHomeStats();
  if (!profile) openUserModal();
})();
