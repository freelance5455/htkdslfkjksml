let file=null,style="sleep",text="",speaking=false,utter=null,voices=[];
const $=id=>document.getElementById(id);

$("pdf").onchange=e=>{file=e.target.files[0];$("fileName").textContent=file?file.name:"لم يتم اختيار ملف";$("create").disabled=!file};
document.querySelectorAll(".opt").forEach(b=>b.onclick=()=>{document.querySelectorAll(".opt").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");style=b.dataset.style});

function loadVoices(){voices=speechSynthesis.getVoices();let sel=$("voiceSelect");if(sel.dataset.loaded)return;sel.dataset.loaded="1";}
speechSynthesis.onvoiceschanged=loadVoices;loadVoices();

function chooseVoice(mode){
 voices=speechSynthesis.getVoices();
 if(mode==="egypt-female"){
   return voices.find(v=>/ar[-_]EG/i.test(v.lang)&&/female|zira|maged|salam|laila|layla|naay/i.test(v.name))
       || voices.find(v=>/ar[-_]EG/i.test(v.lang))
       || voices.find(v=>/^ar/i.test(v.lang));
 }
 if(mode==="arabic-female") return voices.find(v=>/^ar/i.test(v.lang)&&/female|zira|laila|layla/i.test(v.name))||voices.find(v=>/^ar/i.test(v.lang));
 if(mode==="arabic-male") return voices.find(v=>/^ar/i.test(v.lang)&&/male/i.test(v.name))||voices.find(v=>/^ar/i.test(v.lang));
 return voices.find(v=>/ar[-_]EG/i.test(v.lang))||voices.find(v=>/^ar/i.test(v.lang));
}

async function extractPDF(f){
  try{
    const pdfjs=await import("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.4.168/pdf.min.mjs");
    const data=new Uint8Array(await f.arrayBuffer());
    const pdf=await pdfjs.getDocument({data}).promise;
    let out="";
    for(let i=1;i<=pdf.numPages;i++){
      const page=await pdf.getPage(i), c=await page.getTextContent();
      out+=c.items.map(x=>x.str).join(" ")+"\\n";
      $("bar").style.width=Math.min(80,20+i/pdf.numPages*60)+"%";
    }
    return out.trim();
  }catch(e){console.error(e);return "";}
}

function storyTransform(raw){
  let clean=raw.replace(/\\s+/g," ").trim();
  if(style==="summary") return "دي نسخة مختصرة من الحكاية. "+clean.slice(0,9000);
  if(style==="dramatic") return "اسمع الحكاية بهدوء... "+clean.slice(0,12000);
  if(style==="sleep") return "خلينا نحكي الحكاية بهدوء... "+clean.slice(0,12000);
  return clean.slice(0,12000);
}

$("create").onclick=async()=>{
 if(!file)return;
 $("status").classList.add("show");$("player").classList.remove("show");
 $("statusText").textContent="جاري قراءة صفحات الـPDF...";$("statusDetail").textContent="الملف يظل على جهازك.";
 $("bar").style.width="10%";
 text=await extractPDF(file);
 if(!text){
   $("statusText").textContent="تعذر استخراج النص من هذا الـPDF";
   $("statusDetail").textContent="قد يكون الملف صورًا ممسوحة ضوئيًا. سنضيف OCR في النسخة القادمة.";
   return;
 }
 $("bar").style.width="90%";$("statusText").textContent="تم استخراج النص وتجهيز الحكاية...";
 await new Promise(r=>setTimeout(r,400));
 $("bar").style.width="100%";$("statusText").textContent="الحكاية جاهزة 🎧";
 $("storyTitle").textContent=file.name.replace(/\\.pdf$/i,"");
 $("playerInfo").textContent=`${text.length.toLocaleString("ar-EG")} حرف • ${$("duration").value==="full"?"بدون تحديد":$("duration").value+" دقيقة"}`;
 $("player").classList.add("show");
};

$("play").onclick=()=>{
 if(!text){alert("اختار PDF صالح أولًا.");return;}
 if(speaking){speechSynthesis.cancel();speaking=false;$("play").textContent="▶";$("voiceInfo").textContent="تم الإيقاف";return;}
 const mode=$("voiceSelect").value, v=chooseVoice(mode);
 const out=storyTransform(text);
 utter=new SpeechSynthesisUtterance(out);
 utter.lang=v?.lang || (mode==="egypt-female"?"ar-EG":"ar-SA");
 if(v) utter.voice=v;
 utter.rate=mode==="egypt-female"?.88:.82;
 utter.pitch=mode==="egypt-female"?1.08:.98;
 speaking=true;$("play").textContent="⏸";
 $("voiceInfo").textContent=v?`الصوت: ${v.name} (${v.lang})`:"لم يتم العثور على صوت مصري مثبت — تم استخدام أقرب صوت عربي متاح.";
 speechSynthesis.speak(utter);
 utter.onend=()=>{speaking=false;$("play").textContent="▶";$("voiceInfo").textContent="انتهى المقطع";};
};

if("serviceWorker"in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{});
