(() => {
  'use strict';

  const canvas = document.getElementById('scene');
  const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
  const widgetLayer = document.getElementById('widget-layer');

  let W = 0, H = 0, DPR = 1, cx = 0, cy = 0, unit = 1;
  let t = 0, last = performance.now();
  let state = 'idle';
  let listening = false;
  let currentWidget = null;
  let widgetTimer = null;
  let audioCtx = null;
  let pointerDown = false;
  let currentScene = { type: 'idle', parts: [], highlight: new Set() };
  let lastPartId = null;
  let globeUntil = 0;
  let globeSpin = 0;
  let touchPartId = null;

  const C = { cyan:[77,247,255], white:[225,255,255], dim:[13,105,120], yellow:[255,232,68] };
  const TAU = Math.PI * 2;
  const clamp = (v,a,b) => Math.max(a,Math.min(b,v));
  const rgba = (c,a) => `rgba(${c[0]},${c[1]},${c[2]},${a})`;
  const hash = s => { let h=2166136261; for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);} return h>>>0; };
  const seeded = n => { const x=Math.sin(n*12.9898+78.233)*43758.5453; return x-Math.floor(x); };

  function resize() {
    DPR = Math.min(window.devicePixelRatio || 1, 2.25);
    W = innerWidth; H = innerHeight; cx = W*.5; cy = H*.49; unit = Math.min(W,H)/760;
    canvas.width = Math.max(1, Math.floor(W*DPR)); canvas.height = Math.max(1, Math.floor(H*DPR));
    canvas.style.width = W+'px'; canvas.style.height = H+'px';
    ctx.setTransform(DPR,0,0,DPR,0,0);
  }
  addEventListener('resize', resize, {passive:true}); resize();

  function background() {
    ctx.fillStyle='#000506'; ctx.fillRect(0,0,W,H);
    const g=ctx.createRadialGradient(cx,cy,0,cx,cy,Math.max(W,H)*.68);
    g.addColorStop(0,'rgba(0,68,75,.18)'); g.addColorStop(.36,'rgba(0,25,29,.10)'); g.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=g; ctx.fillRect(0,0,W,H);
    // Extremely subtle technical field: no lines or UI, just depth.
    ctx.save(); ctx.globalAlpha=.045; ctx.strokeStyle=rgba(C.cyan,1); ctx.lineWidth=.55;
    const step=34*unit;
    for(let r=step;r<Math.max(W,H);r+=step*1.75){ctx.beginPath();ctx.arc(cx,cy,r,0,TAU);ctx.stroke();}
    ctx.restore();
  }

  function ring(r, width, alpha, rotation, segments=120, gap=.08, jitter=0) {
    ctx.save(); ctx.translate(cx,cy); ctx.rotate(rotation);
    ctx.lineCap='round'; ctx.lineWidth=Math.max(.65,width*unit); ctx.shadowBlur=20*unit; ctx.shadowColor=rgba(C.cyan,alpha*.7);
    for(let i=0;i<segments;i++){
      const a=i/segments*TAU, b=a+(TAU/segments)*(1-gap);
      const j=jitter ? Math.sin(i*4.71+t*1.7)*jitter*unit : 0;
      ctx.strokeStyle=rgba(C.cyan,alpha*(.28+.72*((i%9)/9)));
      ctx.beginPath(); ctx.arc(0,0,r*unit+j,a,b); ctx.stroke();
    }
    ctx.restore();
  }

  function ribbon(r, wobble, alpha, direction=1) {
    ctx.save(); ctx.translate(cx,cy); ctx.rotate(direction*t*.075);
    for(let layer=0;layer<5;layer++){
      ctx.beginPath();
      for(let i=0;i<=300;i++){
        const a=i/300*TAU;
        const rr=(r + Math.sin(a*3+t*1.12+layer*.7)*wobble + Math.sin(a*7-t*.63)*wobble*.24 + layer*1.15)*unit;
        const x=Math.cos(a)*rr, y=Math.sin(a)*rr*(.94+.01*layer);
        i?ctx.lineTo(x,y):ctx.moveTo(x,y);
      }
      ctx.strokeStyle=rgba(C.cyan,alpha/(layer+1)); ctx.lineWidth=(1.25-layer*.13)*unit; ctx.shadowBlur=14*unit; ctx.shadowColor=rgba(C.cyan,.38); ctx.stroke();
    }
    ctx.restore();
  }

  function core(intensity) {
    const r=86*unit;
    const g=ctx.createRadialGradient(cx,cy,0,cx,cy,r*1.9);
    g.addColorStop(0,rgba(C.white,.98)); g.addColorStop(.045,rgba(C.cyan,.92)); g.addColorStop(.26,rgba(C.cyan,.25*intensity)); g.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=g; ctx.beginPath(); ctx.arc(cx,cy,r*1.9,0,TAU); ctx.fill();
    ctx.save(); ctx.translate(cx,cy); ctx.rotate(t*.11);
    ctx.strokeStyle=rgba(C.cyan,.7*intensity); ctx.shadowBlur=20*unit; ctx.shadowColor=rgba(C.cyan,.75); ctx.lineWidth=1.25*unit;
    for(let j=0;j<9;j++){
      ctx.beginPath();
      for(let i=0;i<=84;i++){const a=i/84*TAU, rr=r*(.70+.034*Math.sin(a*5+t*.9+j));const x=Math.cos(a)*rr,y=Math.sin(a)*rr;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);} ctx.stroke();
    }
    for(let i=0;i<16;i++){const a=i/16*TAU;ctx.beginPath();ctx.moveTo(Math.cos(a)*r*.1,Math.sin(a)*r*.1);ctx.lineTo(Math.cos(a)*r*.94,Math.sin(a)*r*.94);ctx.strokeStyle=rgba(C.cyan,.11*intensity);ctx.stroke();}
    ctx.restore();
  }

  function drawIdle(intensity=1) {
    const breathe=Math.sin(t*1.28)*2.8*unit;
    const base=200*unit+breathe;
    ctx.save(); ctx.globalAlpha=.92;
    const glow=ctx.createRadialGradient(cx,cy,base*.82,cx,cy,base*1.18);
    glow.addColorStop(0,'rgba(0,0,0,0)'); glow.addColorStop(.78,rgba(C.cyan,.055*intensity)); glow.addColorStop(1,'rgba(0,0,0,0)');
    ctx.fillStyle=glow; ctx.beginPath();ctx.arc(cx,cy,base*1.25,0,TAU);ctx.fill();ctx.restore();
    ring(185,3.0,.62*intensity,t*.022,104,.18,1.4);
    ring(207,1.0,.23*intensity,-t*.017,144,.07,.5);
    ring(164,1.25,.52*intensity,t*.038,110,.22,.7);
    ribbon(197,6.5+intensity*3.5,.27*intensity,1);
    ring(130,4.4,.43*intensity,-t*.05,84,.25,.4);
    core(intensity);
    ctx.save(); ctx.translate(cx,cy); ctx.rotate(-t*.08);
    for(let i=0;i<44;i++){const a=i/44*TAU+t*.025;const rr=(226+Math.sin(i*2.8+t)*7)*unit;const x=Math.cos(a)*rr,y=Math.sin(a)*rr;const s=(i%5===0?1.8:1)*unit;ctx.fillStyle=rgba(C.cyan,.10+.10*Math.max(0,Math.sin(t+i)));ctx.beginPath();ctx.arc(x,y,s,0,TAU);ctx.fill();}
    ctx.restore();
  }

  function drawListening() {
    ring(225,2.2,.66,t*.12,92,.14,1); ring(246,1,.25,-t*.08,140,.06,.5);
    const pulse=(Math.sin(t*8)+1)*.5; ring(272,1.2,.11+pulse*.12,t*.04,160,.03,1);
  }
  function drawThinking() {
    for(let i=0;i<4;i++) ring(150+i*24,1.4,.23,t*(.16+i*.065)*(i%2?-1:1),86,.29,.7);
    ribbon(216,9,.20,-1);
  }
  function drawSpeaking() {
    ribbon(214,10,.34,1); ring(222,2,.42,-t*.12,96,.12,1.4);
    for(let i=0;i<18;i++){const a=i/18*TAU+t*.4;const rr=(238+Math.sin(t*4+i)*8)*unit;ctx.fillStyle=rgba(C.cyan,.22);ctx.beginPath();ctx.arc(cx+Math.cos(a)*rr,cy+Math.sin(a)*rr,1.4*unit,0,TAU);ctx.fill();}
  }

  function drawGlobe() {
    if(t>=globeUntil) return;
    const elapsed=t-(globeUntil-9.5), fadeIn=clamp(elapsed/1.0,0,1), fadeOut=clamp((globeUntil-t)/1.15,0,1), a=fadeIn*fadeOut;
    globeSpin+=.22*(1/60);
    ctx.save(); ctx.translate(cx,cy); ctx.globalAlpha=a; ctx.rotate(globeSpin);
    const r=142*unit;
    const g=ctx.createRadialGradient(-r*.3,-r*.25,0,0,0,r*1.3);g.addColorStop(0,rgba(C.cyan,.16));g.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(0,0,r*1.25,0,TAU);ctx.fill();
    ctx.strokeStyle=rgba(C.cyan,.72);ctx.shadowBlur=18*unit;ctx.shadowColor=rgba(C.cyan,.58);ctx.lineWidth=1.15*unit;
    for(let lat=-60;lat<=60;lat+=30){const ry=r*Math.cos(lat*Math.PI/180);ctx.beginPath();ctx.ellipse(0,0,r,ry,0,0,TAU);ctx.stroke();}
    for(let lon=-75;lon<180;lon+=30){const rx=r*Math.abs(Math.cos((lon+globeSpin*30)*Math.PI/180));ctx.beginPath();ctx.ellipse(0,0,rx,r,0,0,TAU);ctx.stroke();}
    ctx.restore();
  }

  function drawPart(part, index) {
    const x=cx + (part.x||0)*unit, y=cy + (part.y||0)*unit, s=(part.scale||1)*unit;
    const rot=(part.rotation||0)+t*(part.spin||0);
    const selected=currentScene.highlight.has(part.id);
    ctx.save(); ctx.translate(x,y); ctx.rotate(rot); ctx.globalAlpha=part.opacity ?? 1;
    if(selected){ctx.shadowBlur=35*unit;ctx.shadowColor=rgba(C.yellow,.95);}
    const col=selected?C.yellow:C.cyan;
    if(part.kind==='drive') drawDrive(s,col);
    else if(part.kind==='gpu') drawGpu(s,col);
    else if(part.kind==='disc') drawDisc(s,col);
    else if(part.kind==='chip') drawChip(s,col);
    else if(part.kind==='gear') drawGear(s,col);
    else drawModule(s,col);
    if(part.beam){drawBeam(s,col,part.beamPhase||0);}
    if(part.pulse){drawDataPulse(s,col,part.pulsePhase||0);}
    if(part.heat){drawHeat(s,col);}
    if(selected){ctx.strokeStyle=rgba(C.yellow,.45);ctx.lineWidth=1.2*unit;ctx.beginPath();ctx.arc(0,0,64*s,0,TAU);ctx.stroke();}
    ctx.restore();
  }

  function line(points,col,w=.9,a=.65){ctx.strokeStyle=rgba(col,a);ctx.lineWidth=Math.max(.6,w*unit);ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(p[0],p[1]):ctx.moveTo(p[0],p[1]));ctx.stroke();}
  function drawDrive(s,col){const w=108*s,h=62*s;ctx.shadowBlur=16*unit;ctx.shadowColor=rgba(col,.55);ctx.strokeStyle=rgba(col,.8);ctx.lineWidth=1.1*unit;ctx.strokeRect(-w/2,-h/2,w,h);ctx.strokeRect(-w*.39,-h*.25,w*.78,h*.5);ctx.beginPath();ctx.arc(0,0,14*s,0,TAU);ctx.stroke();line([[-w*.42,-h*.38],[w*.42,-h*.38]],col,.8,.55);line([[-w*.35,h*.38],[w*.35,h*.38]],col,.8,.42);}
  function drawGpu(s,col){const w=126*s,h=70*s;ctx.shadowBlur=18*unit;ctx.shadowColor=rgba(col,.5);ctx.strokeStyle=rgba(col,.8);ctx.lineWidth=1.1*unit;ctx.strokeRect(-w/2,-h/2,w,h);for(let i=-1;i<=1;i++){ctx.beginPath();ctx.arc(i*30*s,0,18*s,0,TAU);ctx.stroke();}line([[-w*.48,-h*.34],[-w*.32,-h*.34]],col,1,.75);line([[w*.48,h*.34],[w*.25,h*.34]],col,1,.55);}
  function drawDisc(s,col){const r=44*s;ctx.shadowBlur=17*unit;ctx.shadowColor=rgba(col,.58);ctx.strokeStyle=rgba(col,.86);ctx.lineWidth=1.15*unit;ctx.beginPath();ctx.arc(0,0,r,0,TAU);ctx.stroke();ctx.beginPath();ctx.arc(0,0,r*.2,0,TAU);ctx.stroke();for(let i=0;i<8;i++){const a=i/8*TAU+t*.03;line([[Math.cos(a)*r*.2,Math.sin(a)*r*.2],[Math.cos(a)*r*.92,Math.sin(a)*r*.92]],col,.55,.25);}}
  function drawChip(s,col){const w=78*s,h=78*s;ctx.strokeStyle=rgba(col,.82);ctx.lineWidth=1.05*unit;ctx.strokeRect(-w/2,-h/2,w,h);for(let i=-3;i<=3;i++){line([[-w*.64,i*9*s],[-w*.5,i*9*s]],col,.8,.55);line([[w*.5,i*9*s],[w*.64,i*9*s]],col,.8,.55);line([[i*9*s,-h*.64],[i*9*s,-h*.5]],col,.8,.55);line([[i*9*s,h*.5],[i*9*s,h*.64]],col,.8,.55);}ctx.strokeRect(-w*.25,-h*.25,w*.5,h*.5);}
  function drawGear(s,col){const r=40*s;ctx.strokeStyle=rgba(col,.82);ctx.lineWidth=1.1*unit;ctx.beginPath();for(let i=0;i<32;i++){const a=i/32*TAU;const rr=i%2?r:r*1.16;const p=[Math.cos(a)*rr,Math.sin(a)*rr];i?ctx.lineTo(...p):ctx.moveTo(...p);}ctx.closePath();ctx.stroke();ctx.beginPath();ctx.arc(0,0,r*.35,0,TAU);ctx.stroke();}
  function drawModule(s,col){const w=88*s,h=76*s;ctx.strokeStyle=rgba(col,.78);ctx.lineWidth=1.1*unit;ctx.strokeRect(-w/2,-h/2,w,h);line([[-w*.35,-h*.28],[w*.2,-h*.28],[w*.34,h*.18],[-w*.18,h*.18],[-w*.35,-h*.28]],col,.8,.65);}
  function drawBeam(s,col,phase){const x=-70*s+((t*40+phase*100)%140)*s/1;ctx.save();ctx.globalAlpha=.5;ctx.strokeStyle=rgba(col,.72);ctx.shadowBlur=16*unit;ctx.shadowColor=rgba(col,.65);ctx.lineWidth=1.2*unit;ctx.beginPath();ctx.moveTo(x,-45*s);ctx.lineTo(x,45*s);ctx.stroke();ctx.restore();}
  function drawDataPulse(s,col,phase){for(let i=0;i<4;i++){const p=((t*1.5+i*.24+phase)%1);const x=-55*s+p*110*s;ctx.fillStyle=rgba(col,.75*(1-p));ctx.shadowBlur=14*unit;ctx.shadowColor=rgba(col,.8);ctx.beginPath();ctx.arc(x,0,2.2*s,0,TAU);ctx.fill();}}
  function drawHeat(s,col){for(let i=0;i<4;i++){const p=Math.sin(t*2+i*.8)*.5+.5;ctx.strokeStyle=rgba(col,.13+p*.18);ctx.lineWidth=.8*unit;ctx.beginPath();ctx.arc(0,0,(58+i*7)*s,-Math.PI*.7,-Math.PI*.3);ctx.stroke();}}

  function drawParts(){
    currentScene.parts.forEach((p,i)=>drawPart(p,i));
    // Assembly links: only when the user has asked to combine parts.
    if(currentScene.type==='assembly' && currentScene.parts.length>1){
      ctx.save();ctx.strokeStyle=rgba(C.cyan,.28);ctx.shadowBlur=12*unit;ctx.shadowColor=rgba(C.cyan,.45);ctx.lineWidth=.8*unit;ctx.setLineDash([3*unit,7*unit]);
      for(let i=1;i<currentScene.parts.length;i++){const a=currentScene.parts[i-1],b=currentScene.parts[i];ctx.beginPath();ctx.moveTo(cx+(a.x||0)*unit,cy+(a.y||0)*unit);ctx.lineTo(cx+(b.x||0)*unit,cy+(b.y||0)*unit);ctx.stroke();}ctx.restore();
    }
  }

  function frame(now){
    const dt=Math.min(.05,(now-last)/1000); last=now; t+=dt;
    background();
    const intensity=state==='listening'?1.18:state==='thinking'?.86:state==='speaking'?.74:.52;
    drawIdle(intensity);
    if(state==='listening')drawListening(); if(state==='thinking')drawThinking(); if(state==='speaking')drawSpeaking();
    drawParts(); drawGlobe();
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  function beep(freq=520,dur=.07){try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.value=freq;g.gain.setValueAtTime(.0001,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.045,audioCtx.currentTime+.01);g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+dur);o.connect(g).connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+dur+.02);}catch{}}
  function setState(s){state=s;}

  function library(){try{return JSON.parse(localStorage.getItem('jarvis_part_library')||'{}')}catch{return {}}}
  function savePart(part){
    const lib=library(); lib[part.id]={...part,savedAt:Date.now(),source:part.source||'procedural/offline'}; localStorage.setItem('jarvis_part_library',JSON.stringify(lib)); lastPartId=part.id;
  }
  function forgetPart(part){const lib=library();delete lib[part.id];localStorage.setItem('jarvis_part_library',JSON.stringify(lib));}
  function keepPart(part){const lib=library();if(lib[part.id]){lib[part.id].protected=true;localStorage.setItem('jarvis_part_library',JSON.stringify(lib));}}

  const catalog=[
    {match:/blu.?ray|disc drive|optical drive/i,id:'bluray-drive',kind:'drive',source:'procedural placeholder'},
    {match:/graphics card|gpu|video card/i,id:'graphics-card',kind:'gpu',source:'procedural placeholder'},
    {match:/disc|blu.?ray disc/i,id:'disc',kind:'disc',source:'procedural placeholder'},
    {match:/chip|processor|cpu/i,id:'processor',kind:'chip',source:'procedural placeholder'},
    {match:/gear|motor/i,id:'gear',kind:'gear',source:'procedural placeholder'}
  ];
  function findPart(text){return catalog.find(x=>x.match.test(text))||null;}
  function makePart(def, index=0){
    const seed=hash(def.id+':'+index+':'+Date.now().toString(36));
    return {id:def.id,kind:def.kind,source:def.source,x:(seeded(seed)-.5)*210,y:(seeded(seed+1)-.5)*150,scale:.86+seeded(seed+2)*.3,rotation:(seeded(seed+3)-.5)*.4,spin:(seeded(seed+4)-.5)*.11,beam:seeded(seed+5)>.45,pulse:seeded(seed+6)>.35,heat:seeded(seed+7)>.7,opacity:1};
  }

  function clearScene(){currentScene={type:'idle',parts:[],highlight:new Set()};touchPartId=null;}
  function bringPart(def){
    const p=makePart(def,currentScene.parts.length); p.x=0; p.y=0; p.scale=1.0; p.rotation=-.05; p.spin=.035;
    currentScene={type:'part',parts:[p],highlight:new Set()}; savePart(p); lastPartId=p.id; beep(650,.08);
  }
  function addPart(def){
    const p=makePart(def,currentScene.parts.length);p.x=currentScene.parts.length%2?-105:105;p.y=(currentScene.parts.length-1)*48;p.scale=.78;p.spin=.025;
    currentScene.parts.push(p); currentScene.type='assembly'; savePart(p); lastPartId=p.id; beep(710,.08);
  }
  function assemble(){if(currentScene.parts.length<2)return false;currentScene.type='assembly';currentScene.parts.forEach((p,i)=>{p.x=(i-(currentScene.parts.length-1)/2)*94;p.y=Math.sin(i*1.4)*28;p.rotation=0;p.spin=.04;});beep(820,.11);setTimeout(()=>beep(1040,.12),80);return true;}
  function highlightPart(){
    let id=touchPartId||lastPartId||currentScene.parts[0]?.id;if(!id)return;
    const p=currentScene.parts.find(x=>x.id===id);if(!p)return;currentScene.highlight.add(id);savePart(p);beep(940,.06);
  }
  function clearHighlight(){currentScene.highlight.clear();beep(420,.06);}

  function clearWidget(){if(widgetTimer)clearTimeout(widgetTimer);widgetTimer=null;currentWidget?.remove?.();currentWidget=null;}
  function showClock(){clearWidget();const el=document.createElement('div');el.className='widget clock';const d=document.createElement('div');d.className='digits';el.appendChild(d);widgetLayer.appendChild(el);requestAnimationFrame(()=>el.classList.add('visible'));currentWidget=el;const update=()=>{d.textContent=new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});};update();el._timer=setInterval(update,1000);}
  function showCalendar(){clearWidget();const el=document.createElement('div');el.className='widget calendar';const n=new Date();el.innerHTML=`<div class="month">${n.toLocaleString([], {month:'long'}).toUpperCase()}</div><div class="day">${n.getDate()}</div><div class="year">${n.getFullYear()}</div>`;widgetLayer.appendChild(el);requestAnimationFrame(()=>el.classList.add('visible'));currentWidget=el;}
  function showGlobe(){clearWidget();globeUntil=t+9.5;globeSpin=0;beep(540,.09);}

  function offlineCommand(text){
    const s=text.toLowerCase().trim();
    if(/\b(clock|time)\b/.test(s)){showClock();return true;}
    if(/\b(calendar|date|day)\b/.test(s) && /show|bring|open|calendar|date/.test(s)){showCalendar();return true;}
    if(/\b(globe|earth|world)\b/.test(s)){showGlobe();return true;}
    if(/\b(close|hide|clear|dismiss)\b.*\b(widget|clock|calendar|globe|screen)\b/.test(s)){clearWidget();globeUntil=0;return true;}
    if(/\b(minimal|home|idle)\b/.test(s)){clearWidget();globeUntil=0;clearScene();setState('idle');return true;}

    if(/\bremove the highlight|clear highlight|unhighlight\b/.test(s)){clearHighlight();return true;}
    if(/\bhighlight\b/.test(s)){highlightPart();return true;}
    if(/\bkeep that one|keep this one\b/.test(s)){const p=currentScene.parts.find(x=>x.id===(touchPartId||lastPartId));if(p)keepPart(p);return true;}
    if(/\bforget that part|forget this part\b/.test(s)){const p=currentScene.parts.find(x=>x.id===(touchPartId||lastPartId));if(p)forgetPart(p);return true;}

    if(/\bput (them|those|it) together|assemble|combine\b/.test(s)){return assemble();}
    if(/\b(save|store) (this )?(build|assembly)\b/.test(s)){currentScene.parts.forEach(savePart);return true;}
    if(/\b(take|remove) (the )?graphics card out\b/.test(s)){currentScene.parts=currentScene.parts.filter(p=>p.id!=='graphics-card');return true;}
    if(/\b(swap|replace).*graphics card.*ps5\b/.test(s)){currentScene.parts=currentScene.parts.filter(p=>p.id!=='graphics-card');addPart({id:'ps5-gpu',kind:'gpu',source:'procedural placeholder',match:/x/});return true;}

    const def=findPart(s);
    if(def && /\b(show|bring|open|display|highlight|that part)\b/.test(s)){bringPart(def);if(/\bhighlight\b/.test(s))highlightPart();return true;}
    return false;
  }

  function applyVisualScript(v){
    if(!v||typeof v!=='object')return;
    if(v.clear)clearScene();
    if(v.globe)showGlobe();
    if(v.widget==='clock')showClock(); else if(v.widget==='calendar')showCalendar();
    if(Array.isArray(v.parts)){
      currentScene.parts=[];
      v.parts.slice(0,6).forEach((raw,i)=>{const def=catalog.find(d=>d.id===raw.id)||catalog.find(d=>d.kind===raw.kind)||{id:raw.id||`part-${i}`,kind:raw.kind||'module',source:raw.source||'remote'};const p=makePart(def,i);Object.assign(p,raw);savePart(p);currentScene.parts.push(p);});
      currentScene.type=v.assembly?'assembly':'part';
    }
    if(Array.isArray(v.highlight)) currentScene.highlight=new Set(v.highlight);
  }

  function speak(text){
    if(!text)return;setState('speaking');
    if(window.JarvisAndroid?.speak){window.JarvisAndroid.speak(String(text));setTimeout(()=>{if(state==='speaking')setState('idle')},Math.max(900,Math.min(10000,String(text).length*40)));return;}
    if(!('speechSynthesis' in window)){setState('idle');return;}
    speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=.96;u.pitch=.9;u.volume=.9;u.onend=()=>setState('idle');speechSynthesis.speak(u);
  }

  async function askBrain(text){
    setState('thinking');
    try{
      const hub=(localStorage.getItem('jarvis_hub_url')||'http://127.0.0.1:8765').replace(/\/$/,'');
      const res=await fetch(hub+'/v1/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,serious:false})});
      if(!res.ok)throw new Error('brain '+res.status);
      const data=await res.json();
      applyVisualScript(data.visual);
      speak(data.text||'Understood.');
    }catch(e){
      setState('idle');beep(220,.12);
      if(/\b(hello|hi|hey)\b/i.test(text))speak('Good to hear you, sir.');
      else if(/\bwho are you\b/i.test(text))speak('I am JARVIS. The local interface is online.');
      else speak('The remote brain is offline. My local controls are still available.');
    }
  }

  function handleSpeech(text){
    if(!text)return;
    if(offlineCommand(text))return;
    askBrain(text);
  }

  function startListening(){
    if(listening)return;
    if(window.JarvisAndroid?.startListening){listening=true;setState('listening');beep(760,.06);window.JarvisAndroid.startListening();return;}
    if(recognition){try{audioCtx?.resume();listening=true;setState('listening');beep(760,.06);recognition.start();}catch{}}
  }

  let recognition=null;
  function setupBrowserSpeech(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return;recognition=new SR();recognition.lang=navigator.language||'en-US';recognition.interimResults=false;recognition.continuous=false;recognition.onresult=e=>{listening=false;setState('idle');handleSpeech(e.results[0][0].transcript)};recognition.onerror=()=>{listening=false;setState('idle')};recognition.onend=()=>{listening=false;if(state==='listening')setState('idle')};}

  // The orb itself is the only permanent interaction surface.
  canvas.addEventListener('pointerdown',()=>{pointerDown=true},{passive:true});
  canvas.addEventListener('pointerup',e=>{pointerDown=false;startListening();},{passive:true});
  canvas.addEventListener('pointercancel',()=>{pointerDown=false},{passive:true});
  setupBrowserSpeech();

  // Exposed only for the native shell and automated UI tests.
  window.JARVIS = {handleSpeech,offlineCommand,applyVisualScript,library:()=>library(),scene:()=>currentScene};
})();
