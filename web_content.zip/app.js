let selectedMonth = new Date().toISOString().slice(0, 7);

let attendanceData =
    JSON.parse(localStorage.getItem("attendanceData")) || {};

let pmData =
    JSON.parse(localStorage.getItem("pmData")) || {};


/* =========================
   MONTH SELECTOR
========================= */

function createMonthSelector() {

    const selector = document.getElementById("monthSelector");

    selector.innerHTML = "";

    const year = new Date().getFullYear();

    for (let month = 0; month < 12; month++) {

        const value =
            year + "-" + String(month + 1).padStart(2, "0");

        const option = document.createElement("option");

        option.value = value;

        option.textContent =
            new Date(year, month, 1).toLocaleString(
                "en-US",
                { month: "long" }
            ) + " " + year;

        if (value === selectedMonth) {
            option.selected = true;
        }

        selector.appendChild(option);
    }
}


/* =========================
   CHANGE MONTH
========================= */

function changeMonth() {

    selectedMonth =
        document.getElementById("monthSelector").value;

    updateSummary();
}


/* =========================
   MONTH NAME
========================= */

function getMonthName(monthValue) {

    const parts = monthValue.split("-");

    const date =
        new Date(
            Number(parts[0]),
            Number(parts[1]) - 1,
            1
        );

    return date.toLocaleString(
        "en-US",
        { month: "long" }
    );
}


/* =========================
   SCREEN CONTROL
========================= */

function openAttendance() {

    document.getElementById("homeScreen")
        .classList.add("hidden");

    document.getElementById("pmScreen")
        .classList.add("hidden");

    document.getElementById("reportScreen")
        .classList.add("hidden");

    document.getElementById("attendanceScreen")
        .classList.remove("hidden");

    history.pushState(
        { screen: "attendance" },
        "",
        "#attendance"
    );

    loadAttendance();
}


function openPM() {

    document.getElementById("homeScreen")
        .classList.add("hidden");

    document.getElementById("attendanceScreen")
        .classList.add("hidden");

    document.getElementById("reportScreen")
        .classList.add("hidden");

    document.getElementById("pmScreen")
        .classList.remove("hidden");

    history.pushState(
        { screen: "pm" },
        "",
        "#pm"
    );

    loadPM();
}


function goHome() {

    document.getElementById("attendanceScreen")
        .classList.add("hidden");

    document.getElementById("pmScreen")
        .classList.add("hidden");

    document.getElementById("reportScreen")
        .classList.add("hidden");

    document.getElementById("homeScreen")
        .classList.remove("hidden");

    updateSummary();
}


/* =========================
   PHONE BACK BUTTON
========================= */

window.addEventListener("popstate", function () {

    const attendanceScreen =
        document.getElementById("attendanceScreen");

    const pmScreen =
        document.getElementById("pmScreen");

    const reportScreen =
        document.getElementById("reportScreen");

    const homeScreen =
        document.getElementById("homeScreen");


    if (!attendanceScreen.classList.contains("hidden")) {

        goHome();

        return;
    }


    if (!pmScreen.classList.contains("hidden")) {

        goHome();

        return;
    }

    if (!reportScreen.classList.contains("hidden")) {

        goHome();

        return;
    }

});


/* =========================
   DATE KEY
========================= */

function makeDateKey(day) {

    return selectedMonth +
        "-" +
        String(day).padStart(2, "0");
}


/* =========================
   LOAD ATTENDANCE
========================= */

function loadAttendance() {

    const list =
        document.getElementById("attendanceList");

    list.innerHTML = "";

    const [year, month] =
        selectedMonth.split("-").map(Number);

    const daysInMonth =
        new Date(year, month, 0).getDate();


    for (let day = 1; day <= daysInMonth; day++) {

        const dateKey = makeDateKey(day);

        if (!attendanceData[dateKey]) {

            attendanceData[dateKey] = {
                status: null,
                ot: false,
                shift: "First Shift"
            };
        }

        const data =
            attendanceData[dateKey];

        const dateObject =
            new Date(year, month - 1, day);

        const dayName =
            dateObject.toLocaleString(
                "en-US",
                { weekday: "short" }
            );


        const card =
            document.createElement("div");

        card.className = "day-card";


        let statusText = "";

        if (!data.status) {

            statusText =
                `<div class="pending">⏳ Pending</div>`;
        }


        card.innerHTML = `

            <div class="day-header">

                <div class="day-number">
                    Day ${day}
                </div>

                <div class="day-date">
                    ${dayName}, ${day}
                    ${getMonthName(selectedMonth)}
                </div>

            </div>


            <div class="shift-row">
                <span class="shift-label">🕐 Shift</span>
                <select onchange="changeShift('${dateKey}', this.value)">
                    <option value="First Shift" ${(!data.shift || data.shift === "First Shift") ? "selected" : ""}>First Shift (7 AM – 3 PM)</option>
                    <option value="Second Shift" ${data.shift === "Second Shift" ? "selected" : ""}>Second Shift (3 PM – 11 PM)</option>
                </select>
            </div>


            <div class="status-buttons">

                <button
                    class="${data.status === "Present"
                        ? "active-present" : ""}"
                    onclick="setStatus('${dateKey}', 'Present')">

                    Present

                </button>


                <button
                    class="${data.status === "Absent"
                        ? "active-absent" : ""}"
                    onclick="setStatus('${dateKey}', 'Absent')">

                    Absent

                </button>


                <button
                    class="${data.status === "Leave"
                        ? "active-leave" : ""}"
                    onclick="setStatus('${dateKey}', 'Leave')">

                    Leave

                </button>

            </div>


            ${statusText}


            <div class="ot-row">

                <span class="ot-label">
                    🟡 OT
                </span>


                <label class="switch">

                    <input
                        type="checkbox"
                        ${data.ot ? "checked" : ""}
                        onchange="changeOT('${dateKey}', this.checked)"
                    >

                    <span class="slider"></span>

                </label>

            </div>
        `;


        list.appendChild(card);
    }
}


/* =========================
   SHIFT
========================= */

function changeShift(dateKey, value) {

    if (!attendanceData[dateKey]) {
        attendanceData[dateKey] = {
            status: null,
            ot: false,
            shift: "First Shift"
        };
    }

    attendanceData[dateKey].shift = value;

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );
}


/* =========================
   SET STATUS
========================= */

function setStatus(dateKey, status) {

    if (!attendanceData[dateKey]) {

        attendanceData[dateKey] = {
            status: null,
            ot: false,
            shift: "First Shift"
        };
    }

    attendanceData[dateKey].status = status;

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    loadAttendance();

    updateSummary();
}


/* =========================
   OT
========================= */

function changeOT(dateKey, value) {

    if (!attendanceData[dateKey]) {

        attendanceData[dateKey] = {
            status: null,
            ot: false,
            shift: "First Shift"
        };
    }

    attendanceData[dateKey].ot = value;

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    updateSummary();
}


/* =========================
   SAVE ATTENDANCE
========================= */

function saveAttendance() {

    localStorage.setItem(
        "attendanceData",
        JSON.stringify(attendanceData)
    );

    alert("Attendance saved successfully! ✅");
}


/* =========================
   SUMMARY
========================= */

function updateSummary() {

    let present = 0;
    let absent = 0;
    let otDays = 0;


    Object.keys(attendanceData).forEach(key => {

        if (!key.startsWith(selectedMonth)) {
            return;
        }

        const data = attendanceData[key];


        if (data.status === "Present") {
            present++;
        }


        if (data.status === "Absent") {
            absent++;
        }


        if (data.ot === true) {
            otDays++;
        }

    });


    document.getElementById("presentCount")
        .textContent = present;

    document.getElementById("absentCount")
        .textContent = absent;

    document.getElementById("otDays")
        .textContent = otDays;
}


/* =========================
   PM TRACKER
========================= */

function loadPM() {

    const data =
        pmData[selectedMonth] || {};

    document.getElementById("pm1").value =
        data.pm1 || "";

    document.getElementById("pm2").value =
        data.pm2 || "";

    document.getElementById("pm3").value =
        data.pm3 || "";

    document.getElementById("pm4").value =
        data.pm4 || "";

    document.getElementById("pm5").value =
        data.pm5 || "";

    document.getElementById("monthlyPM").value =
        data.monthlyPM || "";
}


/* =========================
   SAVE PM
========================= */

function savePM() {

    pmData[selectedMonth] = {

        pm1: document.getElementById("pm1").value,

        pm2: document.getElementById("pm2").value,

        pm3: document.getElementById("pm3").value,

        pm4: document.getElementById("pm4").value,

        pm5: document.getElementById("pm5").value,

        monthlyPM:
            document.getElementById("monthlyPM").value
    };


    localStorage.setItem(
        "pmData",
        JSON.stringify(pmData)
    );


    alert("PM details saved successfully! ✅");
}


/* =========================
   MONTHLY REPORT
========================= */

let reportMonth = selectedMonth;

function createReportMonthSelector() {

    const selector = document.getElementById("reportMonthSelector");
    selector.innerHTML = "";

    const year = new Date().getFullYear();

    for (let month = 0; month < 12; month++) {
        const value = year + "-" + String(month + 1).padStart(2, "0");
        const option = document.createElement("option");
        option.value = value;
        option.textContent = new Date(year, month, 1).toLocaleString("en-US", {month:"long"}) + " " + year;
        if (value === reportMonth) option.selected = true;
        selector.appendChild(option);
    }
}

function openReport() {
    document.getElementById("homeScreen").classList.add("hidden");
    document.getElementById("attendanceScreen").classList.add("hidden");
    document.getElementById("pmScreen").classList.add("hidden");
    document.getElementById("reportScreen").classList.remove("hidden");
    history.pushState({screen:"report"}, "", "#report");
    reportMonth = document.getElementById("reportMonthSelector").value || selectedMonth;
    previewReport();
}

function changeReportMonth() {
    reportMonth = document.getElementById("reportMonthSelector").value;
    previewReport();
}

function getReportData(monthValue) {
    const [year, month] = monthValue.split("-").map(Number);
    const totalDays = new Date(year, month, 0).getDate();
    const rows = [];
    let present=0, absent=0, leave=0, pending=0, ot=0;

    for (let day=1; day<=totalDays; day++) {
        const dateKey = monthValue + "-" + String(day).padStart(2,"0");
        const d = attendanceData[dateKey] || {status:null, ot:false, shift:"First Shift"};
        const dateObj = new Date(year, month-1, day);
        const dayName = dateObj.toLocaleString("en-US", {weekday:"short"});
        const status = d.status || "Pending";
        if(status === "Present") present++;
        else if(status === "Absent") absent++;
        else if(status === "Leave") leave++;
        else pending++;
        if(d.ot) ot++;
        rows.push({day, dayName, date: dateObj.toLocaleDateString("en-IN"), status, shift:d.shift || "First Shift", ot:d.ot ? "Yes" : "No"});
    }
    return {monthValue, monthName:getMonthName(monthValue), year, totalDays, present, absent, leave, pending, ot, rows, pm:pmData[monthValue] || {}};
}

function previewReport() {
    const report = getReportData(reportMonth);
    const preview = document.getElementById("reportPreview");
    const pm = report.pm;
    preview.innerHTML = `
        <div class="report-paper">
            <h1>Monthly Attendance Report</h1>
            <h2>${report.monthName} ${report.year}</h2>
            <div class="report-summary-grid">
                <div><b>Present</b><span>${report.present}</span></div>
                <div><b>Absent</b><span>${report.absent}</span></div>
                <div><b>Leave</b><span>${report.leave}</span></div>
                <div><b>Pending</b><span>${report.pending}</span></div>
                <div><b>OT Days</b><span>${report.ot}</span></div>
                <div><b>Total Days</b><span>${report.totalDays}</span></div>
            </div>
            <h3>Attendance Details</h3>
            <div class="report-table-wrap"><table class="report-table"><thead><tr><th>Date</th><th>Day</th><th>Status</th><th>Shift</th><th>OT</th></tr></thead><tbody>
                ${report.rows.map(r=>`<tr><td>${r.date}</td><td>${r.dayName}</td><td>${r.status}</td><td>${r.shift}</td><td>${r.ot}</td></tr>`).join("")}
            </tbody></table></div>
            <h3>PM Tracker</h3>
            <div class="pm-report-grid">
                <div>PM 1: <b>${pm.pm1 || "-"}</b></div><div>PM 2: <b>${pm.pm2 || "-"}</b></div>
                <div>PM 3: <b>${pm.pm3 || "-"}</b></div><div>PM 4: <b>${pm.pm4 || "-"}</b></div>
                <div>PM 5: <b>${pm.pm5 || "-"}</b></div><div>Monthly PM: <b>${pm.monthlyPM || "-"}</b></div>
            </div>
        </div>`;
}

function pdfEscape(text) {
    return String(text).replace(/\\/g,"\\\\").replace(/\(/g,"\\(").replace(/\)/g,"\\)");
}

function buildPDF(report) {
    const lines = [];
    lines.push("MONTHLY ATTENDANCE REPORT");
    lines.push(`${report.monthName} ${report.year}`);
    lines.push("");
    lines.push(`Present: ${report.present}   Absent: ${report.absent}   Leave: ${report.leave}`);
    lines.push(`Pending: ${report.pending}   OT Days: ${report.ot}   Total Days: ${report.totalDays}`);
    lines.push("");
    lines.push("DATE        DAY  STATUS    SHIFT          OT");
    lines.push("------------------------------------------------------");
    report.rows.forEach(r=>lines.push(`${r.date.padEnd(10)} ${r.dayName.padEnd(4)} ${r.status.padEnd(9)} ${r.shift === "Second Shift" ? "Second Shift" : "First Shift "} ${r.ot}`));
    lines.push("");
    lines.push("PM TRACKER");
    const pm=report.pm;
    lines.push(`PM 1: ${pm.pm1||"-"}   PM 2: ${pm.pm2||"-"}   PM 3: ${pm.pm3||"-"}`);
    lines.push(`PM 4: ${pm.pm4||"-"}   PM 5: ${pm.pm5||"-"}   Monthly PM: ${pm.monthlyPM||"-"}`);

    const pages=[]; let page=[];
    lines.forEach(line=>{ if(page.length>=45){pages.push(page);page=[];} page.push(line); });
    if(page.length) pages.push(page);

    const objects=[]; const pageIds=[]; const contentIds=[]; let id=1;
    function obj(body){objects.push({id,body});return id++;}
    const catalogId=id++; const pagesId=id++; const fontId=obj("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
    pages.forEach(pg=>{
        const stream=["BT","/F1 9 Tf","40 800 Td", "11 TL", ...pg.flatMap((line,i)=>[`(${pdfEscape(line)}) Tj`,`T*`]),"ET"].join("\n");
        const cid=obj(`<< /Length ${stream.length} >>\\nstream\\n${stream}\\nendstream`);
        contentIds.push(cid);
        const pid=obj(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${fontId} 0 R >> >> /Contents ${cid} 0 R >>`);
        pageIds.push(pid);
    });
    objects.push({id:pagesId,body:`<< /Type /Pages /Kids [${pageIds.map(x=>x+" 0 R").join(" ")}] /Count ${pageIds.length} >>`});
    objects.push({id:catalogId,body:`<< /Type /Catalog /Pages ${pagesId} 0 R >>`});
    objects.sort((a,b)=>a.id-b.id);
    let pdf="%PDF-1.4\n"; const offsets=[0];
    for(const o of objects){offsets[o.id]=pdf.length;pdf+=`${o.id} 0 obj\n${o.body}\nendobj\n`;}
    const xref=pdf.length; pdf+=`xref\n0 ${id}\n0000000000 65535 f \n`; for(let i=1;i<id;i++) pdf+=(String(offsets[i]||0).padStart(10,"0"))+" 00000 n \n";
    pdf+=`trailer\n<< /Size ${id} /Root ${catalogId} 0 R >>\nstartxref\n${xref}\n%%EOF`;
    return new Blob([pdf],{type:"application/pdf"});
}

function downloadPDF() {
    const report=getReportData(reportMonth);
    const blob=buildPDF(report);
    const url=URL.createObjectURL(blob);
    const a=document.createElement("a");
    a.href=url;
    a.download=`Attendance_Report_${report.monthValue}.pdf`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
}


/* =========================
   START APP
========================= */

createMonthSelector();
createReportMonthSelector();
updateSummary();