const WS_URL = "wss://ws.binaryws.com/websockets/v3";
const APP_ID = "1089";

let ws = null;
let reconnectTimer = null;
let reconnectDelay = 1000;
let markets = [];
let ticks = new Map();
let selectedTF = "M5";
let selectedSide = "ALL";
let selectedMarket = "ALL";
let reqId = 10;
let lastDataAt = 0;

const $ = id => document.getElementById(id);
function setStatus(live, text) {
  const el = $("status");
  el.className = "status " + (live ? "live" : "offline");
  el.innerHTML = `<span></span><b>${text}</b>`;
}
function send(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function connect() {
  clearTimeout(reconnectTimer);
  setStatus(false, "CONNECTING");
  $("message").textContent = "Connecting to Deriv market data...";
  try {
    ws = new WebSocket(`${WS_URL}?app_id=${APP_ID}`);
  } catch(e) { scheduleReconnect(); return; }

  ws.onopen = () => {
    reconnectDelay = 1000;
    $("message").textContent = "Loading live derived / synthetic markets...";
    send({active_symbols:"brief", product_type:"basic", req_id:++reqId});
  };

  ws.onmessage = ev => {
    let d;
    try { d = JSON.parse(ev.data); } catch { return; }

    if (d.error) {
      $("message").textContent = "Deriv API: " + (d.error.message || "request failed");
      if (d.error.code === "InputValidationFailed") {
        // Do not repeatedly send the invalid request.
        return;
      }
      return;
    }

    if (d.msg_type === "active_symbols") {
      const list = Array.isArray(d.active_symbols) ? d.active_symbols : [];
      markets = list.filter(isDerivedMarket);
      $("markets").textContent = markets.length;
      buildMarketSelect();
      subscribeAll();
      $("message").textContent = markets.length
        ? "Waiting for live ticks..."
        : "No derived / synthetic markets returned by Deriv.";
      return;
    }

    if (d.msg_type === "tick" && d.tick) {
      const t = d.tick;
      const symbol = t.symbol;
      const q = Number(t.quote);
      if (!symbol || !Number.isFinite(q)) return;
      lastDataAt = Date.now();
      ticks.set(symbol, {
        quote:q, epoch:Number(t.epoch)||0,
        digit:lastDigit(q, t.pip_size),
        prev:ticks.get(symbol)?.quote ?? null,
        history:[...(ticks.get(symbol)?.history||[]), q].slice(-30)
      });
      setStatus(true, "LIVE");
      render();
    }
  };

  ws.onerror = () => {
    setStatus(false, "OFFLINE");
    $("message").textContent = "Connection error — retrying...";
  };
  ws.onclose = () => {
    setStatus(false, "OFFLINE");
    $("message").textContent = "Disconnected — reconnecting...";
    scheduleReconnect();
  };
}
function scheduleReconnect() {
  clearTimeout(reconnectTimer);
  reconnectTimer = setTimeout(connect, reconnectDelay);
  reconnectDelay = Math.min(reconnectDelay * 2, 15000);
}
function isDerivedMarket(x) {
  const s = String(x.symbol || "");
  const g = String(x.market || "").toLowerCase();
  const sub = String(x.submarket || "").toLowerCase();
  const name = String(x.display_name || "").toLowerCase();
  return /synthetic|derived|random|volatility|boom|crash|jump|step|drift|range break/i.test(
    `${s} ${g} ${sub} ${name}`
  );
}
function subscribeAll() {
  // Correct Deriv request: ticks is the actual symbol and subscribe is numeric 1.
  for (const m of markets) {
    send({ticks:m.symbol, subscribe:1, req_id:++reqId});
  }
}
function lastDigit(q, pip) {
  if (pip !== undefined && pip !== null && Number.isFinite(Number(pip))) {
    const p = Math.max(0, Number(pip));
    return Math.abs(Math.round(q * Math.pow(10,p))) % 10;
  }
  const s = String(q);
  const digits = s.replace(/\D/g,"");
  return digits ? Number(digits[digits.length-1]) : 0;
}
function buildMarketSelect() {
  const sel = $("marketSelect");
  sel.innerHTML = '<option value="ALL">All Derived / Synthetic Markets</option>';
  markets.forEach(m => {
    const o = document.createElement("option");
    o.value = m.symbol;
    o.textContent = m.display_name || m.symbol;
    sel.appendChild(o);
  });
  sel.value = selectedMarket;
}
function signalFor(t) {
  if (!t || t.history.length < 5) return {side:"NEUTRAL", score:0};
  const h = t.history;
  const recent = h.slice(-5);
  const up = recent[recent.length-1] > recent[0];
  const moves = [];
  for(let i=1;i<recent.length;i++) moves.push(recent[i]-recent[i-1]);
  const pos = moves.filter(x=>x>0).length;
  const neg = moves.filter(x=>x<0).length;
  let score = Math.round(50 + Math.abs(pos-neg)*10);
  if (up && pos >= 3) return {side:"BUY",score};
  if (!up && neg >= 3) return {side:"SELL",score};
  return {side:"NEUTRAL",score:50};
}
function render() {
  const list = $("signalList");
  let rows = [];
  for (const m of markets) {
    if (selectedMarket !== "ALL" && m.symbol !== selectedMarket) continue;
    const t = ticks.get(m.symbol);
    if (!t) continue;
    const sig = signalFor(t);
    if (selectedSide !== "ALL" && sig.side !== selectedSide) continue;
    rows.push({m,t,sig});
  }
  rows.sort((a,b)=>b.sig.score-a.sig.score);
  $("buy").textContent = rows.filter(x=>x.sig.side==="BUY").length;
  $("sell").textContent = rows.filter(x=>x.sig.side==="SELL").length;

  if (!rows.length) {
    list.innerHTML = '<div class="empty">Waiting for live market ticks...</div>';
    return;
  }
  list.innerHTML = rows.map(({m,t,sig}) => `
    <article class="signal">
      <div class="row">
        <div>
          <div class="symbol">${esc(m.symbol)}</div>
          <div class="name">${esc(m.display_name || m.symbol)}</div>
        </div>
        <div class="price">${Number(t.quote).toFixed(3)}</div>
      </div>
      <div class="row" style="margin-top:12px">
        <span class="badge ${sig.side.toLowerCase()}">${sig.side}</span>
        <span class="${sig.side.toLowerCase()}">${sig.score}%</span>
      </div>
      <div class="meta"><span>Last digit: ${t.digit}</span><span>${time(t.epoch)}</span></div>
    </article>`).join("");
}
function time(e) {
  if (!e) return "--:--:--";
  return new Date(e*1000).toLocaleTimeString([], {hour12:false});
}
function esc(s) {
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

document.querySelectorAll("[data-tf]").forEach(b=>b.onclick=()=>{
  document.querySelectorAll("[data-tf]").forEach(x=>x.classList.remove("active"));
  b.classList.add("active"); selectedTF=b.dataset.tf; render();
});
document.querySelectorAll("[data-side]").forEach(b=>b.onclick=()=>{
  document.querySelectorAll("[data-side]").forEach(x=>x.classList.remove("active"));
  b.classList.add("active"); selectedSide=b.dataset.side; render();
});
$("marketSelect").onchange = e => { selectedMarket=e.target.value; render(); };

connect();
setInterval(()=>{
  if (Date.now()-lastDataAt > 20000 && ws?.readyState === WebSocket.OPEN) {
    setStatus(false,"OFFLINE");
  }
},5000);
