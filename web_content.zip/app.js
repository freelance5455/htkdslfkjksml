/**
 * TUS 50 ELITE TRACKER - CORE APPLICATION ENGINE
 * Tailored for Dr. Ali Ege (Aiming for Top 50 in Turkey)
 */

// ==========================================
// 1. DEFAULT DATA & STATE INITIALIZATION
// ==========================================

const DEFAULT_EXAM_DATE = '2025-08-17T09:30:00'; // Standard Upcoming TUS Target Date
const DAILY_TARGET_HOURS = 6.0;

// Dual Specialty Architecture Configurations
const SPECIALTY_CONFIGS = {
  ophthalmology: {
    id: 'ophthalmology',
    title: 'Göz Hastalıkları (Oftalmoloji)',
    shortTitle: 'Göz Hastalıkları',
    tagline: 'Kusursuz Cerrahi Hassasiyet & Mikro Manipülasyon',
    badgeText: 'GÖZ HASTALIKLARI UZMANLIĞI',
    icon: 'fa-eye',
    benchmarkNet: 172.0,
    benchmarkScore: '74.5+ TUS Puanı',
    targetRank: 'İlk 50 - 80',
    themeClass: 'theme-ophthalmology',
    brandHighlight: 'OPHTHALMO',
    focusSubjectIds: ['kucuk-stajlar', 'anatomi', 'patoloji'],
    focusSubjectLabel: 'Oftalmoloji Öncelikli',
    celebrationTitle: 'HARİKA BİR GÖZ CERRAHI GELİYOR,',
    celebrationQuote: '"Gözün milimetrik anatomisinde cerrahın el titremesine yer yoktur. Bugünün 6 saatlik disiplini, yarının kusursuz vitrektomi ve fako cerrahisidir."',
    mindsetTitle: '{name} İçin Mikrocerrahi Stratejisi',
    mindsetText: '"Zorlandığın anlarda vazgeçmeyen tek bir kişi var: Hedeflediğin Göz Hastalıkları kliniğinde operasyon mikroskobunun başına geçecek olan gelecekteki {shortName}. O gün bu masada geçen her dakikaya şükredeceksin."',
    chartColors: {
      totalBorder: '#00F2FE',
      totalBg: 'rgba(0, 242, 254, 0.12)',
      temelBorder: '#38BDF8',
      klinikBorder: '#06D6A0',
      benchmarkBorder: '#F59E0B'
    },
    quotes: [
      { text: "Göz cerrahisinde başarı; mikronluk doku hassasiyeti ve demir gibi bir odaklanmanın birleşimidir, {name}.", author: "Albrecht von Graefe" },
      { text: "Işığı yeniden kazandıran bir göz hekimi olmak, bugün bu masada geçen 6 saatlik sessiz iradeyle başlar.", author: "Oftalmoloji Vizyonu" },
      { text: "Orbita ve kranial sinirlerin her detayı, ameliyathanede hayat kurtaran bir rotadır. Masadan kalkma, {shortName}.", author: "Sir Stewart Duke-Elder" },
      { text: "İlk 50 tesadüf değildir; her gün tamamlanan 6 saatlik o sessiz odaklanmanın matematiksel sonucudur, {name}.", author: "TUS Derece Mentorluğu" },
      { text: "Göze dokunan eller, önce zihnini sarsılmaz bir disiplinle eğitmelidir.", author: "Mikrocerrahi İlkeleri" }
    ]
  },
  plastics: {
    id: 'plastics',
    title: 'Plastik, Rekonstrüktif ve Estetik Cerrahi',
    shortTitle: 'Plastik Cerrahi',
    tagline: 'Doku Mühendisliği, Rekonstrüksiyon ve Altın Oran Sanatı',
    badgeText: 'PLASTİK VE REKONSTRÜKTİF CERRAHİ',
    icon: 'fa-gem',
    benchmarkNet: 175.0,
    benchmarkScore: '76.0+ TUS Puanı',
    targetRank: 'Türkiye İlk 30 - 50',
    themeClass: 'theme-plastics',
    brandHighlight: 'PLASTIC',
    focusSubjectIds: ['genel-cerrahi', 'anatomi', 'farmakoloji'],
    focusSubjectLabel: 'Plastik Cerrahi Öncelikli',
    celebrationTitle: 'TÜRKİYE DERECE ADAYI PLASTİK CERRAH,',
    celebrationQuote: '"Plastik cerrahi sadece dokuları değil, bir insanın kaderini yeniden inşa etmektir. 6 saatlik bu çelik disiplin senin en keskin bistürindir."',
    mindsetTitle: '{name} İçin Rekonstrüktif Cerrahi Stratejisi',
    mindsetText: '"Zorlandığın anlarda vazgeçmeyen tek bir kişi var: Mikrovasküler flep cerrahisinde saatlerce anastomoz dikecek olan gelecekteki elit Plastik Cerrah {shortName}. O gün bu masada geçen her dakikaya şükredeceksin."',
    chartColors: {
      totalBorder: '#FF2E63',
      totalBg: 'rgba(255, 46, 99, 0.15)',
      temelBorder: '#F43F5E',
      klinikBorder: '#F59E0B',
      benchmarkBorder: '#FBBF24'
    },
    quotes: [
      { text: "Plastik cerrahi form ve fonksiyonun kutsal dengesidir; cerrahın zihni en az bistürisi kadar keskin olmalıdır, {name}.", author: "Sir Harold Gillies" },
      { text: "TUS Türkiye ilk 30'u, her gün tamamlanan o 6 saatlik amansız odaklanmanın hakkıdır. Azmet, {shortName}!", author: "Plastik Cerrahi Kürsüsü" },
      { text: "Doku yaşar, nefes alır ve saygı ister. Ameliyathanedeki sabır, çalışma masasındaki sabırdan doğar.", author: "Paul Tessier" },
      { text: "İlk 50 tesadüf değildir; her gün tamamlanan 6 saatlik o sessiz odaklanmanın matematiksel sonucudur, {name}.", author: "TUS Derece Mentorluğu" },
      { text: "Rekonstrüksiyon sanatı, en zor anatomik detayları kusursuz bilmekle başlar. Masadan kalkma, {shortName}.", author: "Cerrahi Sanatı" }
    ]
  }
};

const DEFAULT_SUBJECTS = [
  // Temel Tıp Bilimleri (TTBT)
  { id: 'anatomi', name: 'Anatomi', category: 'temel', stage: 2, notes: 'Pelvis, plexus brachialis ve kranial sinir spotları tekrarlandı.' },
  { id: 'fizyoloji', name: 'Fizyoloji & Histoloji & Embriyoloji', category: 'temel', stage: 2, notes: 'Solunum fizyolojisi ve akciğer hacimleri tamam.' },
  { id: 'biyokimya', name: 'Biyokimya', category: 'temel', stage: 3, notes: 'Metabolizma döngüleri ve vitamin koenzimleri soru bankası bitti.' },
  { id: 'mikrobiyoloji', name: 'Mikrobiyoloji & Parazitoloji', category: 'temel', stage: 3, notes: 'Viroloji ve antibiyogram mekanizmaları TTS tamamlandı.' },
  { id: 'patoloji', name: 'Patoloji', category: 'temel', stage: 3, notes: 'Tümör genetiği, Robbins tabloları ve neoplazi soru çözümleri yapıldı.' },
  { id: 'farmakoloji', name: 'Farmakoloji', category: 'temel', stage: 2, notes: 'Otonom sistem bitti, kemoterapötikler 2. tekrar yapılacak.' },
  
  // Klinik Tıp Bilimleri (KTBT)
  { id: 'dahiliye', name: 'Dahiliye', category: 'klinik', stage: 3, notes: 'Kardiyoloji & Nefroloji vaka soruları çözüldü, hematoloji spotları taze.' },
  { id: 'pediatri', name: 'Pediatri', category: 'klinik', stage: 2, notes: 'Büyüme-gelişme ve aşı takvimi ezberlendi. Genetik sendromlar kaldı.' },
  { id: 'genel-cerrahi', name: 'Genel Cerrahi', category: 'klinik', stage: 3, notes: 'Akut batın, tiroid kanserleri ve travma algoritmaları bitti.' },
  { id: 'kadin-dogum', name: 'Kadın Hastalıkları ve Doğum', category: 'klinik', stage: 2, notes: 'Obstetrik aciller ve jinekolojik onkoloji 2. turda.' },
  { id: 'kucuk-stajlar', name: 'Küçük Stajlar (Kardiyo/Nöro/KBB/Göz)', category: 'klinik', stage: 3, notes: 'Nöroloji inme protokolleri ve EKG yorumlama soruları çözüldü.' }
];

const DEFAULT_EXAMS = [
  { id: 1, name: 'Deneme 1 (Tusdata 1)', date: '2024-10-15', temel: 71.5, klinik: 74.0, total: 145.5, rank: '380 / 4800', notes: 'Biyokimya ve Pediatri eksik.' },
  { id: 2, name: 'Deneme 2 (Tustime 2)', date: '2024-11-01', temel: 76.25, klinik: 78.5, total: 154.75, rank: '185 / 5100', notes: 'Dahiliye netleri yükseldi.' },
  { id: 3, name: 'Deneme 3 (Tusworld 3)', date: '2024-11-20', temel: 79.5, klinik: 82.0, total: 161.5, rank: '94 / 5350', notes: 'İlk 100 barajı aşıldı.' },
  { id: 4, name: 'Deneme 4 (Mega Deneme)', date: '2024-12-08', temel: 82.5, klinik: 85.5, total: 168.0, rank: '58 / 5600', notes: 'Top 50 eşiğine ramak kaldı.' },
  { id: 5, name: 'Deneme 5 (ÖSYM Prova)', date: '2024-12-25', temel: 85.25, klinik: 88.0, total: 173.25, rank: '32 / 5900', notes: 'İLK 50 DERECESİ GERÇEKLEŞTİ!' }
];

const MOTIVATION_QUOTES = [
  { text: "İlk 50 tesadüf değildir; her gün tamamlanan 6 saatlik o sessiz odaklanmanın matematiksel sonucudur, {name}.", author: "TUS Derece Mentorluğu" },
  { text: "Tıp bir bilim değil, bir sanattır; ve sanat disiplinle taçlanır.", author: "Sir William Osler" },
  { text: "Bugün çalıştığın o zor Farmakoloji ve Patoloji spotu, yarın bir hastanın hayatını kurtaracak ve seni Türkiye derecesine taşıyacak, {name}.", author: "TUS 50 Vizyonu" },
  { text: "Bir hekimin en büyük sermayesi bilgisi ve yorulmayan zihnidir.", author: "İbn-i Sina (Avicenna)" },
  { text: "Başarı; her gün yorulmadan atılan o küçük adımların birikimidir. Masadan kalkma, {shortName}.", author: "Elit Hekim Disiplini" },
  { text: "TUS'ta ilk 50'ye girenler daha zeki olanlar değil; 6 saatlik ritmi bozmayanlardır.", author: "Derece Stratejisi" },
  { text: "Zorluklar seni tüketmez, seni şekillendirir. Bugünün emeği, yarının uzmanlık belgesidir, {name}.", author: "Marcus Aurelius" }
];

const BADGE_DEFINITIONS = [
  { id: 'first_step', icon: 'fa-stethoscope', name: 'Stajyer Doktor', desc: 'İlk çalışma seansını sisteme kaydet.', check: state => state.totalHoursLogged > 0 },
  { id: 'six_hours', icon: 'fa-bolt', name: '6 Saat Standardı', desc: 'Bir günde en az 6.0 saatlik elit hedefe ulaş.', check: state => state.todayHours >= 6.0 },
  { id: 'net_150', icon: 'fa-bullseye', name: '150 Net Barajı', desc: 'Herhangi bir denemede 150+ neti aş.', check: state => state.exams.some(e => e.total >= 150) },
  { id: 'top_50_net', icon: 'fa-crown', name: 'Top 50 Prova', desc: 'Bir denemede 170+ net ile derece eşiğini geç.', check: state => state.exams.some(e => e.total >= 170) },
  { id: 'streak_7', icon: 'fa-fire-flame-curved', name: 'Haftalık İrade', desc: '7 gün boyunca aralıksız çalışma kaydet.', check: state => state.streakDays >= 7 },
  { id: 'temel_master', icon: 'fa-dna', name: 'Temel Bilimler Üstadı', desc: 'Tüm Temel Tıp derslerinde en az 2. tekrara ulaş.', check: state => state.subjects.filter(s => s.category === 'temel').every(s => s.stage >= 2) },
  { id: 'klinik_master', icon: 'fa-hospital-user', name: 'Klinik Deha', desc: 'Tüm Klinik Tıp derslerinde Soru Bankasını (3. Aşama) bitir.', check: state => state.subjects.filter(s => s.category === 'klinik').every(s => s.stage >= 3) },
  { id: 'marathon_100', icon: 'fa-gauge-high', name: '100 Saat Maratonu', desc: 'Toplam çalışma süresinde 100 saati geride bırak.', check: state => state.totalHoursLogged >= 100 },
  { id: 'tus_legend', icon: 'fa-trophy', name: 'TUS Efsanesi', desc: 'Tüm 11 dersi "Derece Düzeyi (Aşama 4)"ne taşı.', check: state => state.subjects.every(s => s.stage === 4) }
];

// App State
let state = {
  userName: 'Dr. Ali Ege',
  userGoal: 'Türkiye İlk 50',
  specialty: 'ophthalmology',
  hasChosenSpecialty: false,
  examName: '2025 TUS 1. Dönem',
  examDate: DEFAULT_EXAM_DATE,
  todayDateStr: new Date().toISOString().split('T')[0],
  todayHours: 4.5,
  totalHoursLogged: 84.5,
  streakDays: 14,
  soundEnabled: true,
  hasCelebratedToday: false,
  todaySessions: [
    { id: 1, subject: 'Dahiliye', durationHours: 2.0, timeStr: '09:30' },
    { id: 2, subject: 'Patoloji', durationHours: 1.5, timeStr: '13:00' },
    { id: 3, subject: 'Biyokimya', durationHours: 1.0, timeStr: '16:15' }
  ],
  exams: [...DEFAULT_EXAMS],
  subjects: JSON.parse(JSON.stringify(DEFAULT_SUBJECTS)),
  unlockedBadgeIds: ['first_step', 'six_hours', 'net_150', 'top_50_net', 'streak_7', 'temel_master']
};

// Timer State
let timerMode = 'pomodoro'; // 'pomodoro' (50m), 'short-pomodoro' (25m), 'stopwatch'
let timerSecondsRemaining = 50 * 60;
let stopwatchSecondsElapsed = 0;
let timerInterval = null;
let isTimerRunning = false;
let chartInstance = null;
let currentQuoteIndex = 0;

// Web Audio API Synth for notifications
const AudioContextClass = window.AudioContext || window.webkitAudioContext;
let audioCtx = null;

function initAudio() {
  if (!audioCtx && AudioContextClass) {
    audioCtx = new AudioContextClass();
  }
}

function playTone(freq = 520, duration = 0.15, type = 'sine') {
  if (!state.soundEnabled) return;
  try {
    initAudio();
    if (!audioCtx) return;
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
    gain.gain.setValueAtTime(0.12, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + duration);
  } catch (e) {
    console.warn('Audio tone could not play', e);
  }
}

function playCelebrationFanfare() {
  if (!state.soundEnabled) return;
  const notes = [440, 554.37, 659.25, 880]; // A major chord
  notes.forEach((freq, idx) => {
    setTimeout(() => playTone(freq, 0.4, 'triangle'), idx * 140);
  });
}

// ==========================================
// 2. LOCALSTORAGE PERSISTENCE
// ==========================================

function loadState() {
  try {
    const saved = localStorage.getItem('tus_50_ali_ege_data');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Date roll-over check
      const currentDay = new Date().toISOString().split('T')[0];
      if (parsed.todayDateStr !== currentDay) {
        parsed.todayDateStr = currentDay;
        parsed.todayHours = 0;
        parsed.todaySessions = [];
        parsed.hasCelebratedToday = false;
      }
      state = Object.assign({}, state, parsed);
      if (!state.userName) state.userName = 'Dr. Ali Ege';
      if (!state.userGoal) state.userGoal = 'Türkiye İlk 50';
      if (!state.specialty || !SPECIALTY_CONFIGS[state.specialty]) {
        state.specialty = 'ophthalmology';
      }
      if (typeof state.hasChosenSpecialty === 'undefined') {
        state.hasChosenSpecialty = false;
      }
    }
  } catch (e) {
    console.error('Error loading state from localStorage:', e);
  }
}

function saveState() {
  try {
    localStorage.setItem('tus_50_ali_ege_data', JSON.stringify(state));
  } catch (e) {
    console.error('Error saving state:', e);
  }
}

// ==========================================
// 3. COUNTDOWN TO TUS
// ==========================================

function initCountdown() {
  const targetNameEl = document.getElementById('countdownTargetName');
  const cdDays = document.getElementById('cdDays');
  const cdHours = document.getElementById('cdHours');
  const cdMinutes = document.getElementById('cdMinutes');
  const cdSeconds = document.getElementById('cdSeconds');

  function update() {
    targetNameEl.textContent = state.examName || 'TUS Sınavı';
    const targetDate = new Date(state.examDate).getTime();
    const now = new Date().getTime();
    const diff = targetDate - now;

    if (diff <= 0) {
      cdDays.textContent = '00';
      cdHours.textContent = '00';
      cdMinutes.textContent = '00';
      cdSeconds.textContent = '00';
      return;
    }

    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    cdDays.textContent = String(days).padStart(2, '0');
    cdHours.textContent = String(hours).padStart(2, '0');
    cdMinutes.textContent = String(minutes).padStart(2, '0');
    cdSeconds.textContent = String(seconds).padStart(2, '0');
  }

  update();
  setInterval(update, 1000);
}

// ==========================================
// 4. METRIC CARDS & STATS
// ==========================================

function updateDashboardMetrics() {
  // 1. Today's Hours & Circular Ring
  const todayHours = Number(state.todayHours || 0);
  document.getElementById('statTodayHours').textContent = todayHours.toFixed(1);
  
  const pct = Math.min(Math.round((todayHours / DAILY_TARGET_HOURS) * 100), 100);
  document.getElementById('statTodayPercent').textContent = `${pct}%`;

  // Circular progress SVG
  const circle = document.getElementById('statTodayCircle');
  const circumference = 2 * Math.PI * 24; // 150.8
  const offset = circumference - (pct / 100) * circumference;
  circle.style.strokeDashoffset = offset;

  // Linear bar
  const linearBar = document.getElementById('statTodayBar');
  linearBar.style.width = `${Math.min((todayHours / DAILY_TARGET_HOURS) * 100, 100)}%`;

  // Status badge & hint
  const badge = document.getElementById('dailyGoalStatusBadge');
  const hint = document.getElementById('statTodayHint');
  if (todayHours >= DAILY_TARGET_HOURS) {
    badge.textContent = 'HEDEF TAMAMLANDI! 🎉';
    badge.className = 'metric-badge elite-badge';
    hint.innerHTML = `<span style="color: var(--accent-teal); font-weight: 700;"><i class="fa-solid fa-circle-check"></i> 6.0 saatlik elit baraj aşıldı! (+${(todayHours - DAILY_TARGET_HOURS).toFixed(1)}h)</span>`;
  } else {
    badge.textContent = `Hedef: Min ${DAILY_TARGET_HOURS} Saat`;
    badge.className = 'metric-badge';
    const remaining = (DAILY_TARGET_HOURS - todayHours).toFixed(1);
    hint.textContent = `Hedefe ulaşmak için ${remaining} saat kaldı.`;
  }

  // 2. Deneme Net Stats
  const exams = state.exams || [];
  if (exams.length > 0) {
    const latest = exams[exams.length - 1];
    document.getElementById('statLatestNet').textContent = latest.total.toFixed(2);
    document.getElementById('statLatestTemel').textContent = latest.temel.toFixed(1);
    document.getElementById('statLatestKlinik').textContent = latest.klinik.toFixed(1);

    const totalSum = exams.reduce((acc, curr) => acc + curr.total, 0);
    const avg = (totalSum / exams.length).toFixed(1);
    document.getElementById('statAvgNet').textContent = avg;
  } else {
    document.getElementById('statLatestNet').textContent = '--';
    document.getElementById('statLatestTemel').textContent = '--';
    document.getElementById('statLatestKlinik').textContent = '--';
    document.getElementById('statAvgNet').textContent = '--';
  }

  // 3. Streak & Days
  document.getElementById('statStreakDays').textContent = state.streakDays || 1;
  document.getElementById('statTotalStudyDays').textContent = state.streakDays || 1;

  // 4. Mastery Stats
  const totalStagesPossible = state.subjects.length * 4; // Max stage is 4 per subject
  const currentStagesAchieved = state.subjects.reduce((sum, s) => sum + (s.stage || 0), 0);
  const masteryPct = Math.round((currentStagesAchieved / totalStagesPossible) * 100);

  document.getElementById('statMasteryPercent').textContent = `${masteryPct}%`;
  document.getElementById('statMasteryBar').style.width = `${masteryPct}%`;

  const masteredSubjects = state.subjects.filter(s => s.stage === 4).length;
  document.getElementById('statMasteredCount').textContent = `${masteredSubjects}/${state.subjects.length}`;
  document.getElementById('statTotalHoursSum').textContent = (state.totalHoursLogged || 0).toFixed(0);

  // Check achievements after metrics update
  checkAndAwardBadges();
}

// Celebration Check
function triggerCelebrationIfDue() {
  if (state.todayHours >= DAILY_TARGET_HOURS && !state.hasCelebratedToday) {
    state.hasCelebratedToday = true;
    saveState();

    // Trigger Confetti
    if (typeof confetti === 'function') {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 }
      });
      setTimeout(() => {
        confetti({
          particleCount: 80,
          angle: 60,
          spread: 55,
          origin: { x: 0 }
        });
        confetti({
          particleCount: 80,
          angle: 120,
          spread: 55,
          origin: { x: 1 }
        });
      }, 350);
    }

    playCelebrationFanfare();

    // Show celebration modal
    const overlay = document.getElementById('celebrationOverlay');
    if (overlay) overlay.classList.add('active');
  }
}

// ==========================================
// 5. INTERACTIVE TIMER ENGINE
// ==========================================

function updateTimerDisplay() {
  const display = document.getElementById('timerDisplay');
  let mins, secs;

  if (timerMode === 'stopwatch') {
    mins = Math.floor(stopwatchSecondsElapsed / 60);
    secs = stopwatchSecondsElapsed % 60;
  } else {
    mins = Math.floor(timerSecondsRemaining / 60);
    secs = timerSecondsRemaining % 60;
  }

  display.textContent = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function setTimerMode(mode) {
  if (isTimerRunning) pauseTimer();
  timerMode = mode;

  const glowCircle = document.getElementById('timerGlowCircle');
  glowCircle.classList.remove('running');

  if (mode === 'pomodoro') {
    timerSecondsRemaining = 50 * 60;
    document.getElementById('timerStateLabel').textContent = '50 DK ODAK BLOKU';
  } else if (mode === 'short-pomodoro') {
    timerSecondsRemaining = 25 * 60;
    document.getElementById('timerStateLabel').textContent = '25 DK STANDART BLOK';
  } else if (mode === 'stopwatch') {
    stopwatchSecondsElapsed = 0;
    document.getElementById('timerStateLabel').textContent = 'SERBEST SÜRE SAYACI';
  }

  updateTimerDisplay();

  // Update tabs
  document.querySelectorAll('.mode-tab').forEach(tab => {
    tab.classList.toggle('active', tab.getAttribute('data-mode') === mode);
  });
}

function startTimer() {
  if (isTimerRunning) return;
  isTimerRunning = true;

  const btn = document.getElementById('timerStartPauseBtn');
  btn.innerHTML = `<i class="fa-solid fa-pause"></i> Duraklat`;
  btn.classList.add('btn-pause');

  const glowCircle = document.getElementById('timerGlowCircle');
  glowCircle.classList.add('running');

  document.getElementById('timerStateLabel').textContent = 'SEANS DEVAM EDİYOR';
  playTone(440, 0.1);

  timerInterval = setInterval(() => {
    if (timerMode === 'stopwatch') {
      stopwatchSecondsElapsed++;
      updateTimerDisplay();
    } else {
      if (timerSecondsRemaining > 0) {
        timerSecondsRemaining--;
        updateTimerDisplay();
      } else {
        // Pomodoro Completed
        clearInterval(timerInterval);
        isTimerRunning = false;
        btn.innerHTML = `<i class="fa-solid fa-play"></i> Başlat`;
        glowCircle.classList.remove('running');
        playCelebrationFanfare();
        document.getElementById('timerStateLabel').textContent = 'BLOK BİTTİ! DİNLEN YA DA KAYDET';

        // Auto log session prompt
        const sessionHours = timerMode === 'pomodoro' ? (50 / 60) : (25 / 60);
        logStudyHours(sessionHours, document.getElementById('timerSubjectSelect').value);
      }
    }
  }, 1000);
}

function pauseTimer() {
  if (!isTimerRunning) return;
  clearInterval(timerInterval);
  isTimerRunning = false;

  const btn = document.getElementById('timerStartPauseBtn');
  btn.innerHTML = `<i class="fa-solid fa-play"></i> Devam Et`;
  btn.classList.remove('btn-pause');

  const glowCircle = document.getElementById('timerGlowCircle');
  glowCircle.classList.remove('running');

  document.getElementById('timerStateLabel').textContent = 'DURAKLATILDI';
  playTone(330, 0.15);
}

function resetTimer() {
  if (isTimerRunning) pauseTimer();
  setTimerMode(timerMode);
  const btn = document.getElementById('timerStartPauseBtn');
  btn.innerHTML = `<i class="fa-solid fa-play"></i> Başlat`;
  playTone(280, 0.1);
}

function logStudyHours(hours, subjectName) {
  const numHours = parseFloat(hours);
  if (isNaN(numHours) || numHours <= 0) return;

  state.todayHours = parseFloat((state.todayHours + numHours).toFixed(2));
  state.totalHoursLogged = parseFloat((state.totalHoursLogged + numHours).toFixed(2));

  // Add to session logs
  const now = new Date();
  const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
  state.todaySessions.unshift({
    id: Date.now(),
    subject: subjectName || 'Çalışma Bloğu',
    durationHours: numHours,
    timeStr: timeStr
  });

  saveState();
  updateDashboardMetrics();
  renderTodaySessionsList();
  triggerCelebrationIfDue();
  playTone(660, 0.2);
}

function renderTodaySessionsList() {
  const container = document.getElementById('todaySessionList');
  const badge = document.getElementById('todaySessionsBadge');
  const sessionCountInfo = document.getElementById('timerSessionCount');

  badge.textContent = `${state.todaySessions.length} Oturum`;
  sessionCountInfo.textContent = `Bugün: ${state.todaySessions.length} Seans Tamamlandı`;

  if (state.todaySessions.length === 0) {
    container.innerHTML = `<div class="empty-state-hint">Henüz bugün için kaydedilmiş çalışma yok. Çalışmaya başla ve ilk seansını kaydet!</div>`;
    return;
  }

  container.innerHTML = state.todaySessions.map(session => `
    <div class="session-row-item">
      <div class="session-subject-tag">
        <i class="fa-solid fa-book-medical" style="color: var(--accent-cyan);"></i>
        <span>${session.subject}</span>
      </div>
      <div class="session-time-info">
        <span class="session-duration">+${session.durationHours >= 1 ? session.durationHours.toFixed(1) + ' Saat' : Math.round(session.durationHours * 60) + ' Dk'}</span>
        <span class="session-timestamp">${session.timeStr}</span>
        <button class="btn-del-session" onclick="deleteSession(${session.id})" title="Seansı Sil">
          <i class="fa-solid fa-trash-can"></i>
        </button>
      </div>
    </div>
  `).join('');
}

window.deleteSession = function(sessionId) {
  const sessionIndex = state.todaySessions.findIndex(s => s.id === sessionId);
  if (sessionIndex > -1) {
    const deleted = state.todaySessions[sessionIndex];
    state.todayHours = Math.max(0, parseFloat((state.todayHours - deleted.durationHours).toFixed(2)));
    state.totalHoursLogged = Math.max(0, parseFloat((state.totalHoursLogged - deleted.durationHours).toFixed(2)));
    state.todaySessions.splice(sessionIndex, 1);
    saveState();
    updateDashboardMetrics();
    renderTodaySessionsList();
  }
};

// ==========================================
// 6. MOCK EXAM ANALYTICS & TREND CHART
// ==========================================

function initTrendChart() {
  const ctx = document.getElementById('examTrendChart');
  if (!ctx) return;

  const specKey = state.specialty || 'ophthalmology';
  const config = SPECIALTY_CONFIGS[specKey] || SPECIALTY_CONFIGS.ophthalmology;
  const benchmarkVal = config.benchmarkNet;
  const chartColors = config.chartColors;

  const exams = state.exams || [];
  const labels = exams.map(e => e.name);
  const totalData = exams.map(e => e.total);
  const temelData = exams.map(e => e.temel);
  const klinikData = exams.map(e => e.klinik);
  const benchmarkData = exams.map(() => benchmarkVal);

  if (typeof Chart === 'undefined') {
    renderOfflineCanvasChart(ctx, labels, totalData, temelData, klinikData, benchmarkVal, chartColors);
    return;
  }

  if (chartInstance) {
    chartInstance.destroy();
  }

  chartInstance = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'Toplam Net',
          data: totalData,
          borderColor: chartColors.totalBorder,
          backgroundColor: chartColors.totalBg,
          borderWidth: 3,
          tension: 0.35,
          fill: true,
          pointBackgroundColor: chartColors.totalBorder,
          pointBorderColor: '#fff',
          pointHoverRadius: 7,
          pointRadius: 5
        },
        {
          label: 'Temel Bilimler',
          data: temelData,
          borderColor: chartColors.temelBorder,
          borderWidth: 2,
          borderDash: [4, 4],
          tension: 0.35,
          pointRadius: 3,
          fill: false
        },
        {
          label: 'Klinik Bilimler',
          data: klinikData,
          borderColor: chartColors.klinikBorder,
          borderWidth: 2,
          borderDash: [4, 4],
          tension: 0.35,
          pointRadius: 3,
          fill: false
        },
        {
          label: `${config.shortTitle} Eşiği (${benchmarkVal} Net)`,
          data: benchmarkData,
          borderColor: chartColors.benchmarkBorder,
          borderWidth: 2,
          borderDash: [8, 4],
          pointRadius: 0,
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        mode: 'index',
        intersect: false
      },
      plugins: {
        legend: {
          display: false // Using custom HTML legend above canvas
        },
        tooltip: {
          backgroundColor: 'rgba(9, 15, 29, 0.95)',
          titleColor: '#F8FAFC',
          bodyColor: '#CBD5E1',
          borderColor: 'rgba(0, 242, 254, 0.4)',
          borderWidth: 1,
          padding: 10,
          boxPadding: 4,
          callbacks: {
            label: function(context) {
              return ` ${context.dataset.label}: ${context.parsed.y.toFixed(2)} Net`;
            }
          }
        }
      },
      scales: {
        x: {
          grid: {
            color: 'rgba(255, 255, 255, 0.05)'
          },
          ticks: {
            color: '#94A3B8',
            font: { family: 'Outfit', size: 11 }
          }
        },
        y: {
          min: 100,
          max: 200,
          grid: {
            color: 'rgba(255, 255, 255, 0.06)'
          },
          ticks: {
            color: '#94A3B8',
            font: { family: 'JetBrains Mono', size: 11 },
            stepSize: 20
          }
        }
      }
    }
  });
}

function renderOfflineCanvasChart(canvas, labels, totalData, temelData, klinikData, benchmarkVal, colors) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  canvas.width = (rect.width || 400) * dpr;
  canvas.height = (rect.height || 220) * dpr;
  ctx.scale(dpr, dpr);
  const w = rect.width || 400;
  const h = rect.height || 220;

  ctx.clearRect(0, 0, w, h);

  // Background grid
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
  ctx.lineWidth = 1;
  for (let i = 1; i <= 4; i++) {
    const y = (h / 5) * i;
    ctx.beginPath();
    ctx.moveTo(35, y);
    ctx.lineTo(w - 10, y);
    ctx.stroke();
  }

  if (labels.length < 2) return;
  const padL = 35, padR = 15, padT = 15, padB = 25;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;
  const minVal = 100, maxVal = 200;

  function getY(val) {
    return padT + plotH - ((val - minVal) / (maxVal - minVal)) * plotH;
  }
  function getX(idx) {
    return padL + (idx / (labels.length - 1)) * plotW;
  }

  // Draw Benchmark line
  const benchY = getY(benchmarkVal);
  ctx.strokeStyle = colors.benchmarkBorder || '#F59E0B';
  ctx.setLineDash([6, 4]);
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(padL, benchY);
  ctx.lineTo(padL + plotW, benchY);
  ctx.stroke();
  ctx.setLineDash([]);

  // Series drawing helper
  function drawSeries(data, color, width) {
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.beginPath();
    data.forEach((val, idx) => {
      const x = getX(idx);
      const y = getY(val);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    ctx.fillStyle = color;
    data.forEach((val, idx) => {
      const x = getX(idx);
      const y = getY(val);
      ctx.beginPath();
      ctx.arc(x, y, 3.5, 0, Math.PI * 2);
      ctx.fill();
    });
  }

  drawSeries(temelData, colors.temelBorder || '#38BDF8', 2);
  drawSeries(klinikData, colors.klinikBorder || '#06D6A0', 2);
  drawSeries(totalData, colors.totalBorder || '#00F2FE', 3);
}

function renderExamsTable() {
  const tbody = document.getElementById('examsTableBody');
  if (!tbody) return;

  if (state.exams.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 1.5rem;">Henüz deneme kaydı girilmedi. Sağ üstteki "Yeni Deneme Ekle" butonuna basarak ilk denemeni kaydet!</td></tr>`;
    return;
  }

  tbody.innerHTML = state.exams.slice().reverse().map(exam => {
    const isElite = exam.total >= 170;
    return `
      <tr>
        <td><b>${exam.name}</b></td>
        <td style="color: var(--text-muted);">${exam.date}</td>
        <td><span style="color: #38BDF8; font-weight: 600;">${exam.temel.toFixed(2)}</span></td>
        <td><span style="color: #06D6A0; font-weight: 600;">${exam.klinik.toFixed(2)}</span></td>
        <td><span class="exam-total-badge ${isElite ? 'elite' : ''}">${exam.total.toFixed(2)} ${isElite ? '★' : ''}</span></td>
        <td>${exam.rank ? `<span style="font-family: var(--font-mono); color: var(--accent-amber);">${exam.rank}</span>` : '<span style="color: var(--text-muted);">-</span>'}</td>
        <td>
          <button class="btn-del-exam" onclick="deleteExam(${exam.id})" title="Denemeyi Sil">
            <i class="fa-solid fa-trash-can"></i>
          </button>
        </td>
      </tr>
    `;
  }).join('');
}

window.deleteExam = function(examId) {
  if (confirm('Bu deneme sınavı kaydını silmek istediğinize emin misiniz?')) {
    state.exams = state.exams.filter(e => e.id !== examId);
    saveState();
    updateDashboardMetrics();
    initTrendChart();
    renderExamsTable();
    playTone(300, 0.15);
  }
};

// ==========================================
// 7. SUBJECT-BASED MASTERY CHECKLIST
// ==========================================

const STAGE_LABELS = [
  '0: Başlanmadı',
  '1: 1. Tekrar (Konu)',
  '2: 2. Tekrar (Spot)',
  '3: Soru Bankası & TTS',
  '4: Derece Düzeyi'
];

function renderSubjectCards(filterCategory = 'all') {
  const container = document.getElementById('subjectCardsGrid');
  if (!container) return;

  const specKey = state.specialty || 'ophthalmology';
  const config = SPECIALTY_CONFIGS[specKey] || SPECIALTY_CONFIGS.ophthalmology;

  const filtered = state.subjects.filter(s => {
    if (filterCategory === 'all') return true;
    return s.category === filterCategory;
  });

  container.innerHTML = filtered.map(subj => {
    const currentStage = subj.stage || 0;
    const catLabel = subj.category === 'temel' ? 'Temel Tıp' : 'Klinik Tıp';
    const isFocus = config.focusSubjectIds.includes(subj.id);
    const badgeCls = specKey === 'plastics' ? 'plastics-badge' : 'ophthalmo-badge';
    const focusBadgeHtml = isFocus 
      ? `<span class="specialty-focus-badge ${badgeCls}"><i class="fa-solid ${config.icon}"></i> ${config.focusSubjectLabel}</span>` 
      : '';

    return `
      <div class="subject-card" data-id="${subj.id}">
        <div class="subject-card-top">
          <div class="subject-name-group">
            <span class="subject-category-badge">${catLabel}</span>
            <span class="subject-name">${subj.name}</span>
            ${focusBadgeHtml}
          </div>
          <select class="stage-select-dropdown" onchange="changeSubjectStage('${subj.id}', this.value)">
            ${STAGE_LABELS.map((lbl, idx) => `
              <option value="${idx}" ${idx === currentStage ? 'selected' : ''}>${lbl}</option>
            `).join('')}
          </select>
        </div>

        <div class="subject-steps-tracker">
          <div class="steps-track-line"></div>
          ${[0, 1, 2, 3, 4].map(stepNum => {
            let cls = '';
            if (stepNum < currentStage) cls = 'completed';
            else if (stepNum === currentStage && currentStage > 0) cls = 'active-stage';
            return `
              <div class="step-node ${cls}" onclick="changeSubjectStage('${subj.id}', ${stepNum})" title="Aşama ${stepNum}: ${STAGE_LABELS[stepNum]}">
                ${stepNum}
              </div>
            `;
          }).join('')}
        </div>

        <div class="subject-card-footer">
          <span class="subject-status-text">${STAGE_LABELS[currentStage]}</span>
          <button class="subject-btn-notes" onclick="openSubjectNotesPrompt('${subj.id}')" title="Not / Eksik Girişi">
            <i class="fa-regular fa-note-sticky"></i> Not (${subj.notes ? '1' : '0'})
          </button>
        </div>
      </div>
    `;
  }).join('');
}

window.changeSubjectStage = function(subjectId, newStageVal) {
  const stageNum = parseInt(newStageVal, 10);
  const subj = state.subjects.find(s => s.id === subjectId);
  if (subj) {
    subj.stage = stageNum;
    saveState();
    updateDashboardMetrics();
    renderSubjectCards(document.querySelector('.filter-btn.active')?.dataset.filter || 'all');
    playTone(480 + stageNum * 60, 0.12);
  }
};

window.openSubjectNotesPrompt = function(subjectId) {
  const subj = state.subjects.find(s => s.id === subjectId);
  if (!subj) return;
  const currentNote = subj.notes || '';
  const newNote = prompt(`"${subj.name}" için çalışma notunuz ve tespit ettiğiniz eksikler:`, currentNote);
  if (newNote !== null) {
    subj.notes = newNote.trim();
    saveState();
    renderSubjectCards(document.querySelector('.filter-btn.active')?.dataset.filter || 'all');
  }
};

// ==========================================
// 8. SPECIALTY SYSTEM & MOTIVATION TICKER
// ==========================================

function applySpecialty(specialtyKey, triggerVisual = true) {
  const config = SPECIALTY_CONFIGS[specialtyKey] || SPECIALTY_CONFIGS.ophthalmology;
  state.specialty = config.id;
  state.hasChosenSpecialty = true;

  // Body theme class
  document.body.className = `dark-mode ${config.themeClass}`;

  // Header Logo and Brand
  const mainLogoIcon = document.getElementById('mainLogoIcon');
  if (mainLogoIcon) mainLogoIcon.className = `fa-solid ${config.icon} pulse-icon`;

  const brandHighlightText = document.getElementById('brandHighlightText');
  if (brandHighlightText) brandHighlightText.textContent = config.brandHighlight;

  // Header Specialty Pill
  const specialtyPillIcon = document.getElementById('specialtyPillIcon');
  if (specialtyPillIcon) specialtyPillIcon.innerHTML = `<i class="fa-solid ${config.icon}"></i>`;

  const specialtyPillName = document.getElementById('specialtyPillName');
  if (specialtyPillName) specialtyPillName.textContent = config.shortTitle;

  // Benchmark Badge in Son Deneme Neti
  const statBenchmarkBadge = document.getElementById('statBenchmarkBadge');
  if (statBenchmarkBadge) statBenchmarkBadge.textContent = `Hedef: ${config.benchmarkNet}+ Net`;

  // Chart benchmark texts
  const chartLegendBenchmarkText = document.getElementById('chartLegendBenchmarkText');
  if (chartLegendBenchmarkText) chartLegendBenchmarkText.textContent = `${config.shortTitle} Eşiği (${config.benchmarkNet} Net)`;

  const chartBenchmarkPillText = document.getElementById('chartBenchmarkPillText');
  if (chartBenchmarkPillText) chartBenchmarkPillText.textContent = `${config.benchmarkNet}+ Net`;

  // Modal Card Active Selection styling
  document.querySelectorAll('.specialty-option-card').forEach(card => {
    card.classList.toggle('active-selection', card.getAttribute('data-specialty') === config.id);
  });

  saveState();
  updateUserProfileUI();
  initTrendChart();
  renderSubjectCards(document.querySelector('.filter-btn.active')?.dataset.filter || 'all');

  if (triggerVisual) {
    playTone(config.id === 'plastics' ? 620 : 540, 0.15);
  }
}

function updateUserProfileUI() {
  const userName = state.userName || 'Dr. Ali Ege';
  const userGoal = state.userGoal || 'Türkiye İlk 50';
  const shortName = userName.replace(/^Dr\.?\s*/i, '') || userName;
  const specKey = state.specialty || 'ophthalmology';
  const config = SPECIALTY_CONFIGS[specKey] || SPECIALTY_CONFIGS.ophthalmology;

  // Header Elements
  const displayUserNameEl = document.getElementById('displayUserName');
  if (displayUserNameEl) displayUserNameEl.textContent = userName;

  const displayUserGoalEl = document.getElementById('displayUserGoal');
  if (displayUserGoalEl) displayUserGoalEl.textContent = `Hedef: ${userGoal}`;

  // Document Title
  document.title = `TUS 50 Elite Tracker | ${config.shortTitle} | ${userName}`;

  // Celebration Modal
  const celebrationTitleEl = document.getElementById('celebrationTitle');
  if (celebrationTitleEl) celebrationTitleEl.textContent = `${config.celebrationTitle} ${userName.toUpperCase()}!`;

  const celebrationQuoteEl = document.getElementById('celebrationQuote');
  if (celebrationQuoteEl) celebrationQuoteEl.textContent = config.celebrationQuote;

  // Mindset Card
  const mindsetTitleEl = document.getElementById('mindsetCardTitle');
  if (mindsetTitleEl) mindsetTitleEl.textContent = config.mindsetTitle.replace('{name}', userName);

  const mindsetTextEl = document.getElementById('mindsetStrategyText');
  if (mindsetTextEl) {
    mindsetTextEl.textContent = config.mindsetText.replace('{shortName}', shortName);
  }

  // Footer Elements
  const footerUserEl = document.getElementById('footerUserName');
  if (footerUserEl) footerUserEl.textContent = userName;
  const footerGoalEl = document.getElementById('footerUserGoal');
  if (footerGoalEl) footerGoalEl.textContent = `${config.shortTitle} (${userGoal})`;

  updateQuoteTicker();
}

function updateQuoteTicker() {
  const specKey = state.specialty || 'ophthalmology';
  const config = SPECIALTY_CONFIGS[specKey] || SPECIALTY_CONFIGS.ophthalmology;
  const quotesList = config.quotes && config.quotes.length > 0 ? config.quotes : MOTIVATION_QUOTES;
  const quote = quotesList[currentQuoteIndex % quotesList.length];
  const quoteEl = document.getElementById('tickerQuote');
  const authorEl = document.getElementById('tickerAuthor');
  if (!quoteEl || !authorEl) return;

  const userName = state.userName || 'Dr. Ali Ege';
  const shortName = userName.replace(/^Dr\.?\s*/i, '') || userName;
  const renderedText = quote.text
    .replace(/\{name\}/g, userName)
    .replace(/\{shortName\}/g, shortName);

  quoteEl.style.opacity = 0;
  setTimeout(() => {
    quoteEl.textContent = `"${renderedText}"`;
    authorEl.textContent = `— ${quote.author}`;
    quoteEl.style.opacity = 1;
  }, 200);
}

function nextQuote() {
  currentQuoteIndex = (currentQuoteIndex + 1) % MOTIVATION_QUOTES.length;
  updateQuoteTicker();
  playTone(550, 0.08);
}

function checkAndAwardBadges() {
  let newlyUnlocked = false;

  BADGE_DEFINITIONS.forEach(b => {
    const isUnlocked = state.unlockedBadgeIds.includes(b.id);
    if (!isUnlocked && b.check(state)) {
      state.unlockedBadgeIds.push(b.id);
      newlyUnlocked = true;
    }
  });

  if (newlyUnlocked) {
    saveState();
    playCelebrationFanfare();
  }

  renderBadges();
}

function renderBadges() {
  const container = document.getElementById('badgesGrid');
  const countEl = document.getElementById('unlockedBadgesText');
  if (!container) return;

  const total = BADGE_DEFINITIONS.length;
  const unlockedCount = state.unlockedBadgeIds.length;
  countEl.textContent = `${unlockedCount} / ${total} Rozet Açık`;

  container.innerHTML = BADGE_DEFINITIONS.map(b => {
    const isUnlocked = state.unlockedBadgeIds.includes(b.id);
    return `
      <div class="badge-item-card ${isUnlocked ? 'unlocked' : ''}">
        <span class="badge-locked-overlay"><i class="fa-solid fa-lock"></i></span>
        <div class="badge-icon-wrap">
          <i class="fa-solid ${b.icon}"></i>
        </div>
        <div class="badge-name">${b.name}</div>
        <div class="badge-desc">${b.desc}</div>
      </div>
    `;
  }).join('');
}

// ==========================================
// 9. EVENT LISTENERS & MODAL CONTROLS
// ==========================================

function setupEventListeners() {
  // Specialty Selection Modal Controls
  const specialtyModal = document.getElementById('specialtyModalOverlay');
  const btnOpenSpecialtyModal = document.getElementById('btnOpenSpecialtyModal');
  const btnCloseSpecialtyModal = document.getElementById('btnCloseSpecialtyModal');

  function openSpecialtyModal() {
    if (specialtyModal) {
      specialtyModal.classList.add('active');
      document.querySelectorAll('.specialty-option-card').forEach(card => {
        card.classList.toggle('active-selection', card.getAttribute('data-specialty') === state.specialty);
      });
    }
  }

  if (btnOpenSpecialtyModal) btnOpenSpecialtyModal.addEventListener('click', openSpecialtyModal);
  if (btnCloseSpecialtyModal) btnCloseSpecialtyModal.addEventListener('click', () => specialtyModal.classList.remove('active'));

  // Specialty Cards & Buttons inside modal
  document.querySelectorAll('.btn-choose-specialty, .specialty-option-card').forEach(el => {
    el.addEventListener('click', e => {
      const spec = el.getAttribute('data-specialty') || el.closest('.specialty-option-card')?.getAttribute('data-specialty');
      if (spec) {
        applySpecialty(spec, true);
        if (specialtyModal) specialtyModal.classList.remove('active');
        if (typeof confetti === 'function') {
          confetti({ particleCount: 80, spread: 65, origin: { y: 0.6 } });
        }
      }
    });
  });

  // Profile (Name & Goal) Customization Modal
  const profileModal = document.getElementById('profileModalOverlay');
  const userNameInput = document.getElementById('userNameInput');
  const userGoalInput = document.getElementById('userGoalInput');

  function openProfileModal() {
    if (userNameInput) userNameInput.value = state.userName || 'Dr. Ali Ege';
    if (userGoalInput) userGoalInput.value = state.userGoal || 'Türkiye İlk 50';
    if (profileModal) {
      profileModal.classList.add('active');
      setTimeout(() => userNameInput && userNameInput.focus(), 150);
    }
  }

  const btnEditUserBadge = document.getElementById('btnEditUserBadge');
  if (btnEditUserBadge) btnEditUserBadge.addEventListener('click', openProfileModal);

  const btnEditGoalBadge = document.getElementById('btnEditGoalBadge');
  if (btnEditGoalBadge) btnEditGoalBadge.addEventListener('click', openProfileModal);

  const btnOpenProfileModal = document.getElementById('btnOpenProfileModal');
  if (btnOpenProfileModal) btnOpenProfileModal.addEventListener('click', openProfileModal);

  const btnCloseProfileModal = document.getElementById('btnCloseProfileModal');
  if (btnCloseProfileModal) btnCloseProfileModal.addEventListener('click', () => profileModal.classList.remove('active'));

  const btnCancelProfileModal = document.getElementById('btnCancelProfileModal');
  if (btnCancelProfileModal) btnCancelProfileModal.addEventListener('click', () => profileModal.classList.remove('active'));

  const profileForm = document.getElementById('profileForm');
  if (profileForm) {
    profileForm.addEventListener('submit', e => {
      e.preventDefault();
      const newName = userNameInput.value.trim();
      const newGoal = userGoalInput.value.trim();
      if (newName) state.userName = newName;
      if (newGoal) state.userGoal = newGoal;
      saveState();
      updateUserProfileUI();
      profileModal.classList.remove('active');
      playTone(560, 0.15);
    });
  }

  // Sound Toggle
  const soundBtn = document.getElementById('soundToggleBtn');
  const soundIcon = document.getElementById('soundIcon');
  soundBtn.addEventListener('click', () => {
    state.soundEnabled = !state.soundEnabled;
    soundIcon.className = state.soundEnabled ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark';
    saveState();
    if (state.soundEnabled) playTone(440, 0.15);
  });

  // Quote Refresh
  document.getElementById('btnNextQuote').addEventListener('click', nextQuote);

  // Timer Mode Tabs
  document.querySelectorAll('.mode-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      setTimerMode(tab.getAttribute('data-mode'));
    });
  });

  // Timer Controls
  document.getElementById('timerStartPauseBtn').addEventListener('click', () => {
    if (isTimerRunning) pauseTimer();
    else startTimer();
  });

  document.getElementById('timerResetBtn').addEventListener('click', resetTimer);

  document.getElementById('timerLogSessionBtn').addEventListener('click', () => {
    let sessionHours = 0;
    if (timerMode === 'stopwatch') {
      sessionHours = stopwatchSecondsElapsed / 3600;
      if (sessionHours < 0.05) {
        alert('Kaydedilecek kadar süre geçmedi (en az 3 dakika).');
        return;
      }
      resetTimer();
    } else {
      sessionHours = timerMode === 'pomodoro' ? (50 / 60) : (25 / 60);
    }
    const subj = document.getElementById('timerSubjectSelect').value;
    logStudyHours(sessionHours, subj);
  });

  // Quick Manual Hour Buttons
  document.querySelectorAll('.btn-quick').forEach(btn => {
    btn.addEventListener('click', () => {
      const addHours = parseFloat(btn.getAttribute('data-add'));
      const subj = document.getElementById('timerSubjectSelect').value;
      logStudyHours(addHours, subj);
    });
  });

  // Custom Time Modal
  const customModal = document.getElementById('customTimeModalOverlay');
  document.getElementById('btnCustomHourModal').addEventListener('click', () => {
    customModal.classList.add('active');
  });
  document.getElementById('btnCloseTimeModal').addEventListener('click', () => {
    customModal.classList.remove('active');
  });
  document.getElementById('btnCancelTimeModal').addEventListener('click', () => {
    customModal.classList.remove('active');
  });
  document.getElementById('customTimeForm').addEventListener('submit', e => {
    e.preventDefault();
    const hrs = parseFloat(document.getElementById('customHoursInput').value);
    const subj = document.getElementById('customSubjectInput').value;
    if (hrs > 0) {
      logStudyHours(hrs, subj);
      customModal.classList.remove('active');
      document.getElementById('customHoursInput').value = '';
    }
  });

  // Exam Date Edit Modal
  const dateModal = document.getElementById('examDateModalOverlay');
  document.getElementById('btnEditExamDate').addEventListener('click', () => {
    document.getElementById('targetExamNameInput').value = state.examName || '2025 TUS 1. Dönem';
    document.getElementById('targetExamDateInput').value = (state.examDate || '').split('T')[0];
    dateModal.classList.add('active');
  });
  document.getElementById('btnCloseDateModal').addEventListener('click', () => {
    dateModal.classList.remove('active');
  });
  document.getElementById('btnCancelDateModal').addEventListener('click', () => {
    dateModal.classList.remove('active');
  });
  document.getElementById('examDateForm').addEventListener('submit', e => {
    e.preventDefault();
    const newName = document.getElementById('targetExamNameInput').value.trim();
    const newDate = document.getElementById('targetExamDateInput').value;
    if (newDate) {
      state.examName = newName || 'TUS Sınavı';
      state.examDate = `${newDate}T09:30:00`;
      saveState();
      dateModal.classList.remove('active');
      playTone(550, 0.15);
    }
  });

  // Add Deneme (Mock Exam) Modal
  const examModal = document.getElementById('examModalOverlay');
  const temelInput = document.getElementById('temelNetInput');
  const klinikInput = document.getElementById('klinikNetInput');
  const calcDisplay = document.getElementById('calculatedTotalNetDisplay');

  function updateCalcDisplay() {
    const t = parseFloat(temelInput.value) || 0;
    const k = parseFloat(klinikInput.value) || 0;
    const tot = (t + k).toFixed(2);
    calcDisplay.textContent = tot;
    calcDisplay.style.color = tot >= 170 ? '#10B981' : '#00F2FE';
  }

  temelInput.addEventListener('input', updateCalcDisplay);
  klinikInput.addEventListener('input', updateCalcDisplay);

  document.getElementById('btnOpenAddExamModal').addEventListener('click', () => {
    document.getElementById('examDateInput').value = new Date().toISOString().split('T')[0];
    examModal.classList.add('active');
  });
  document.getElementById('btnCloseExamModal').addEventListener('click', () => {
    examModal.classList.remove('active');
  });
  document.getElementById('btnCancelExamModal').addEventListener('click', () => {
    examModal.classList.remove('active');
  });

  document.getElementById('addExamForm').addEventListener('submit', e => {
    e.preventDefault();
    const name = document.getElementById('examNameInput').value.trim();
    const date = document.getElementById('examDateInput').value;
    const temel = parseFloat(temelInput.value);
    const klinik = parseFloat(klinikInput.value);
    const rank = document.getElementById('examRankInput').value.trim();
    const notes = document.getElementById('examNotesInput').value.trim();

    if (isNaN(temel) || isNaN(klinik)) return;

    const total = parseFloat((temel + klinik).toFixed(2));
    const newExam = {
      id: Date.now(),
      name: name,
      date: date,
      temel: temel,
      klinik: klinik,
      total: total,
      rank: rank,
      notes: notes
    };

    state.exams.push(newExam);
    saveState();
    updateDashboardMetrics();
    initTrendChart();
    renderExamsTable();

    examModal.classList.remove('active');
    document.getElementById('addExamForm').reset();
    calcDisplay.textContent = '0.00';

    if (total >= 170) {
      if (typeof confetti === 'function') confetti({ particleCount: 100, spread: 70 });
      playCelebrationFanfare();
    } else {
      playTone(520, 0.2);
    }
  });

  // Subject Mastery Filter Tabs
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderSubjectCards(btn.getAttribute('data-filter'));
    });
  });

  // Celebration Modal Close
  const celebrationOverlay = document.getElementById('celebrationOverlay');
  document.getElementById('btnCloseCelebration').addEventListener('click', () => {
    celebrationOverlay.classList.remove('active');
  });
  celebrationOverlay.addEventListener('click', e => {
    if (e.target === celebrationOverlay) celebrationOverlay.classList.remove('active');
  });

  // Global Escape key to dismiss modals
  window.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-overlay.active, .celebration-overlay.active').forEach(el => {
        el.classList.remove('active');
      });
    }
  });

  // Export / Import / Reset Data
  document.getElementById('exportDataBtn').addEventListener('click', () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    const cleanName = (state.userName || 'Hekim').replace(/[^a-zA-Z0-9_\u00C0-\u017F]/g, '_');
    downloadAnchor.setAttribute('download', `TUS50_${cleanName}_Backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  });

  const fileInput = document.getElementById('importFileInput');
  document.getElementById('importDataBtn').addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const imported = JSON.parse(ev.target.result);
        if (imported && imported.subjects && imported.exams) {
          state = imported;
          saveState();
          initApp();
          alert('Tüm veriler başarıyla geri yüklendi!');
        } else {
          alert('Geçersiz yedek dosyası!');
        }
      } catch (err) {
        alert('Dosya okunurken hata oluştu!');
      }
    };
    reader.readAsText(file);
  });

  document.getElementById('resetDataBtn').addEventListener('click', () => {
    if (confirm('Tüm verileri varsayılan örnek verilere sıfırlamak istiyor musunuz?')) {
      localStorage.removeItem('tus_50_ali_ege_data');
      location.reload();
    }
  });
}

// ==========================================
// 10. INITIALIZATION
// ==========================================

function initApp() {
  loadState();
  applySpecialty(state.specialty || 'ophthalmology', false);
  updateUserProfileUI();
  initCountdown();
  updateDashboardMetrics();
  setTimerMode('pomodoro');
  renderTodaySessionsList();
  initTrendChart();
  renderExamsTable();
  renderSubjectCards('all');
  renderBadges();
  updateQuoteTicker();

  // Sound Icon state
  const soundIcon = document.getElementById('soundIcon');
  if (soundIcon) {
    soundIcon.className = state.soundEnabled ? 'fa-solid fa-volume-high' : 'fa-solid fa-volume-xmark';
  }

  // Automatic Prompt on first visit if specialty hasn't been chosen yet
  if (!state.hasChosenSpecialty) {
    setTimeout(() => {
      document.getElementById('specialtyModalOverlay')?.classList.add('active');
    }, 450);
  }
}

// Bootstrap when DOM ready
document.addEventListener('DOMContentLoaded', () => {
  initApp();
  setupEventListeners();

  // Register Service Worker for offline PWA & Android WebView APK
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch(err => {
      console.log('SW registration skipped:', err);
    });
  }
});
