/*
 * LU Maths Hub — mobile-first PWA.
 * The public Supabase URL/key below are the same browser-safe credentials used
 * by the existing class hub. Never put a Supabase service-role key in this app.
 */
const CONFIG = {
  supabaseUrl: 'https://qmuovtsrwbekwurghgsz.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFtdW92dHNyd2Jla3d1cmdoZ3N6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAwNzI5OTYsImV4cCI6MjEwNTY0ODk5Nn0.oKVszkNP5zmpZu0grcIiqgp3_zcwJ0yOCnqFN0QG4fs',
  mainWhatsapp: 'https://chat.whatsapp.com/GZtjJmoafXdJTytN1nljtt',
  helpUrl: 'https://wa.me/919555617652?text=I%20want%20some%20help%20regarding%20the%20website',
  webBaseUrl: 'https://rvs.mnopdf.com',
  typedPhrases: ['Notes, books and lectures', 'Graphs and math tools', 'Timetable and exam dates', 'Join the class WhatsApp group'],
  sections: {
    groups: { title: 'WhatsApp groups', eyebrow: 'CLASS COMMUNITY', lead: 'Choose a group and join it on WhatsApp.', table: 'groups', icon: '◉' },
    study: { title: 'Study', eyebrow: 'ACADEMICS', lead: 'Notes, books and recorded lectures.', table: 'study', icon: '▤' },
    playground: { title: 'Playground', eyebrow: 'ACADEMICS', lead: 'Tools to graph, calculate and experiment.', table: 'playground', icon: '⌁' },
    exams: { title: 'Exams', eyebrow: 'ACADEMICS', lead: 'Dates, admit cards, results and papers.', table: 'exams', icon: '◫' },
    timetable: { title: 'Timetable', eyebrow: 'ACADEMICS', lead: 'Your daily class schedule.', table: 'timetable', icon: '◷' },
    photos: { title: 'Photos', eyebrow: 'CAMPUS LIFE', lead: 'Albums and shared memories.', table: 'photos', icon: '◉' },
    participation: { title: 'Participation', eyebrow: 'CAMPUS LIFE', lead: 'Events, quizzes and forms.', table: 'participation', icon: '✦' },
  },
};

const CARDS = {
  academics: [
    { title: 'Students', description: 'Class list and contacts', icon: '♙', color: '#58c8ff', external: '/students', search: 'students class list contacts classmates' },
    { title: 'Study', description: 'Notes, books, lectures', icon: '▤', color: '#b99aff', action: 'study', search: 'study notes books lectures' },
    { title: 'Playground', description: 'Graphs and math tools', icon: '⌁', color: '#56e0be', action: 'playground', search: 'playground graphs math tools calculator' },
    { title: 'Teachers', description: 'Faculty and contacts', icon: '♜', color: '#ffad70', external: '/teachers', search: 'teachers faculty contacts professors' },
  ],
  campus: [
    { title: 'Life Lessons', description: 'Talks and advice', icon: '✺', color: '#f486cf', notice: 'Life Lessons', search: 'life lessons talks advice' },
    { title: 'WA Groups', description: 'Pick a group to join', icon: '◉', color: '#62db99', action: 'groups', search: 'whatsapp wa groups community' },
    { title: 'Music', description: 'Class playlists', icon: '♫', color: '#ff8195', external: '/music', search: 'music class playlists songs' },
    { title: 'Photos', description: 'Memories and albums', icon: '◉', color: '#ffd36b', action: 'photos', search: 'photos memories albums pictures' },
    { title: 'Timetable', description: 'Daily class schedule', icon: '◷', color: '#58c8ff', action: 'timetable', search: 'timetable schedule daily classes' },
    { title: 'Exams', description: 'Dates, results, papers', icon: '◫', color: '#b99aff', action: 'exams', search: 'exams dates results papers admit card' },
    { title: 'Participation', description: 'Events, quizzes, forms', icon: '✦', color: '#d0a0ff', action: 'participation', search: 'participation events quiz forms' },
    { title: 'Holidays', description: 'Term dates and breaks', icon: '☂', color: '#ffc16f', external: '/holidays', search: 'holidays term dates breaks vacation' },
  ],
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));
let installPrompt = null;
let toastTimeout = null;

function getSession() {
  try { return JSON.parse(localStorage.getItem('lu-mobile-session')); } catch { return null; }
}

function setSession(session) { localStorage.setItem('lu-mobile-session', JSON.stringify(session)); }
function clearSession() { localStorage.removeItem('lu-mobile-session'); }
function batchFor(roll) { return Number(roll) % 2 === 0 ? 'PR2' : 'PR1'; }
function isSafeHttpUrl(value) {
  try { const url = new URL(value); return url.protocol === 'https:' || url.protocol === 'http:'; } catch { return false; }
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('show'), 3200);
}

function openExternal(url) {
  if (!isSafeHttpUrl(url)) { showToast('That link is not available yet.'); return; }
  window.open(url, '_blank', 'noopener,noreferrer');
}

function setTheme(theme) {
  document.documentElement.dataset.theme = theme;
  document.querySelector('meta[name="theme-color"]').setAttribute('content', theme === 'light' ? '#f2f5ff' : '#0b1026');
  $('#themeButton').textContent = theme === 'light' ? '☾' : '☀';
  $('#themeButton').setAttribute('aria-label', theme === 'light' ? 'Switch to dark theme' : 'Switch to light theme');
  localStorage.setItem('lu-mobile-theme', theme);
}

function updateGreeting() {
  const session = getSession();
  $('#userGreeting').textContent = session ? `${session.name} · ${batchFor(session.roll)}` : 'MSc Mathematics';
  $('#profileButton').lastElementChild.textContent = session ? 'Profile' : 'Log in';
}

function createCard(card) {
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'hub-card';
  button.style.setProperty('--card-color', card.color);
  button.dataset.search = card.search;
  button.setAttribute('aria-label', `${card.title}: ${card.description}`);
  button.innerHTML = `<span class="card-icon" aria-hidden="true">${card.icon}</span><span class="card-arrow" aria-hidden="true">${card.external ? '↗' : '→'}</span><strong>${card.title}</strong><small>${card.description}</small>`;
  button.addEventListener('click', () => {
    if (card.action) openLinksDialog(card.action);
    else if (card.external) openExternal(`${CONFIG.webBaseUrl}${card.external}`);
    else showNotice(card.notice || card.title, 'This section will appear in the mobile hub as soon as the link is added.');
  });
  return button;
}

function renderCards() {
  CARDS.academics.forEach((card) => $('#academicGrid').append(createCard(card)));
  CARDS.campus.forEach((card) => $('#campusGrid').append(createCard(card)));
}

function filterCards(query) {
  const normalized = query.trim().toLowerCase();
  let visibleCount = 0;
  $$('.hub-card').forEach((card) => {
    const match = !normalized || card.dataset.search.includes(normalized);
    card.hidden = !match;
    if (match) visibleCount += 1;
  });
  $('#emptySearch').hidden = visibleCount !== 0;
  $('#clearSearchButton').hidden = !normalized;
  $('#searchResult').textContent = normalized ? `${visibleCount} section${visibleCount === 1 ? '' : 's'} found` : '';
}

async function supabaseFetch(path, options = {}) {
  const response = await fetch(`${CONFIG.supabaseUrl}${path}`, {
    ...options,
    headers: {
      apikey: CONFIG.supabaseAnonKey,
      Authorization: `Bearer ${CONFIG.supabaseAnonKey}`,
      'Content-Type': 'application/json',
      ...(options.headers || {}),
    },
  });
  if (!response.ok) throw new Error(`Supabase request failed (${response.status})`);
  return response.json();
}

function openDialog(dialog) {
  if (typeof dialog.showModal === 'function') dialog.showModal();
  else dialog.setAttribute('open', '');
}

function closeDialog(dialog) {
  if (dialog.open && typeof dialog.close === 'function') dialog.close();
  else dialog.removeAttribute('open');
}

function textNode(value) { return document.createTextNode(value || ''); }

function makeLinkRow(section, row) {
  const item = document.createElement('li');
  item.className = 'link-row';
  const icon = document.createElement('span');
  icon.className = 'link-row-icon';
  icon.textContent = section.icon;
  const content = document.createElement('div');
  const name = document.createElement('strong');
  name.append(textNode(row.name || 'Untitled'));
  const description = document.createElement('small');
  description.append(textNode(row.description || ''));
  content.append(name, description);
  const actions = document.createElement('div');
  const openButton = document.createElement('button');
  openButton.type = 'button';
  openButton.className = 'link-open';
  openButton.textContent = 'Open';
  openButton.addEventListener('click', () => openExternal(row.url));
  const copyButton = document.createElement('button');
  copyButton.type = 'button';
  copyButton.className = 'copy-link';
  copyButton.textContent = '⧉';
  copyButton.setAttribute('aria-label', `Copy ${row.name || 'link'}`);
  copyButton.addEventListener('click', () => copyText(row.url));
  actions.append(openButton, copyButton);
  item.append(icon, content, actions);
  return item;
}

async function copyText(value) {
  if (!isSafeHttpUrl(value)) { showToast('That link is not available yet.'); return; }
  try {
    await navigator.clipboard.writeText(value);
    showToast('Link copied');
  } catch {
    const input = document.createElement('textarea');
    input.value = value;
    input.style.cssText = 'position:fixed; opacity:0; pointer-events:none';
    document.body.append(input);
    input.select();
    document.execCommand('copy');
    input.remove();
    showToast('Link copied');
  }
}

async function openLinksDialog(key) {
  const section = CONFIG.sections[key];
  if (!section) return;
  $('#linksDialogEyebrow').textContent = section.eyebrow;
  $('#linksDialogTitle').textContent = section.title;
  $('#linksDialogLead').textContent = section.lead;
  $('#linksList').replaceChildren();
  $('#linksLoading').hidden = false;
  openDialog($('#linksDialog'));
  try {
    const rows = await supabaseFetch(`/rest/v1/${encodeURIComponent(section.table)}?select=name,description,url`);
    $('#linksLoading').hidden = true;
    if (!rows.length) {
      $('#linksLoading').textContent = 'Nothing has been added here yet. Check back soon.';
      $('#linksLoading').hidden = false;
      return;
    }
    rows.forEach((row) => $('#linksList').append(makeLinkRow(section, row)));
  } catch (error) {
    console.error(error);
    $('#linksLoading').textContent = 'Could not load this list. Check your connection and try again.';
  }
}

function renderProfile() {
  const session = getSession();
  const content = $('#profileDialogContent');
  content.replaceChildren();
  if (!session) {
    const intro = document.createElement('p');
    intro.className = 'profile-intro';
    intro.textContent = 'Enter the last 3 digits of your roll number and your 4-digit PIN to see your student profile.';
    const form = document.createElement('form');
    form.className = 'login-form';
    form.noValidate = true;
    form.innerHTML = `
      <div class="form-field"><label for="rollSuffix">Last 3 digits of roll number</label><input id="rollSuffix" inputmode="numeric" maxlength="3" autocomplete="off" required /></div>
      <div class="form-field"><label for="loginPin">4-digit PIN</label><input id="loginPin" type="password" inputmode="numeric" maxlength="4" autocomplete="off" required /></div>
      <p class="form-message" id="loginMessage" role="status"></p>
      <button class="primary-action login-submit" type="submit">Log in <span>→</span></button>`;
    form.addEventListener('submit', submitLogin);
    const help = document.createElement('button');
    help.type = 'button';
    help.className = 'secondary-action wide';
    help.textContent = 'Request your PIN on WhatsApp';
    help.addEventListener('click', () => openExternal(CONFIG.helpUrl));
    content.append(intro, form, help);
  } else {
    const intro = document.createElement('p');
    intro.className = 'profile-intro';
    intro.textContent = 'You are logged in on this device.';
    const details = document.createElement('dl');
    details.className = 'profile-data';
    [['Name', session.name], ['Batch', batchFor(session.roll)], ['Roll number', session.roll], ['Course', 'MSc Mathematics'], ['University', 'University of Lucknow'], ['Semester', 'Semester 1']].forEach(([label, value]) => {
      const row = document.createElement('div');
      const term = document.createElement('dt'); term.textContent = label;
      const description = document.createElement('dd'); description.textContent = value;
      row.append(term, description); details.append(row);
    });
    const actions = document.createElement('div');
    actions.className = 'profile-actions';
    const help = document.createElement('button');
    help.type = 'button'; help.className = 'secondary-action'; help.textContent = 'Get help';
    help.addEventListener('click', () => openExternal(CONFIG.helpUrl));
    const logout = document.createElement('button');
    logout.type = 'button'; logout.className = 'secondary-action'; logout.textContent = 'Log out';
    logout.addEventListener('click', () => { clearSession(); updateGreeting(); renderProfile(); showToast('Logged out'); });
    actions.append(help, logout);
    content.append(intro, details, actions);
  }
}

async function submitLogin(event) {
  event.preventDefault();
  const suffix = $('#rollSuffix').value.trim();
  const pin = $('#loginPin').value.trim();
  const message = $('#loginMessage');
  const submitButton = event.currentTarget.querySelector('button[type="submit"]');
  message.className = 'form-message';
  if (!/^\d{1,3}$/.test(suffix) || !/^\d{4}$/.test(pin)) {
    message.textContent = 'Enter the last 3 digits of your roll number and a 4-digit PIN.';
    message.classList.add('error');
    return;
  }
  submitButton.disabled = true;
  submitButton.textContent = 'Checking…';
  try {
    const rows = await supabaseFetch('/rest/v1/rpc/login_student', { method: 'POST', body: JSON.stringify({ p_suffix: Number(suffix), p_pin: pin }) });
    if (!rows || !rows.length) {
      message.textContent = 'No match. Check your roll number and PIN.';
      message.classList.add('error');
      return;
    }
    const student = rows[0];
    setSession({ roll: student.univ_roll_no, name: student.student_name });
    updateGreeting();
    renderProfile();
    showToast(`Welcome, ${student.student_name}!`);
  } catch (error) {
    console.error(error);
    message.textContent = 'Login could not be completed. Please try again or request your PIN.';
    message.classList.add('error');
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = 'Log in →';
  }
}

function showNotice(title, message) {
  $('#noticeDialogTitle').textContent = title;
  $('#noticeDialogText').textContent = message;
  openDialog($('#noticeDialog'));
}

function showProfile() { renderProfile(); openDialog($('#profileDialog')); }

async function promptInstall() {
  if (installPrompt) {
    installPrompt.prompt();
    const result = await installPrompt.userChoice;
    if (result.outcome === 'accepted') showToast('The app is being added to your home screen.');
    installPrompt = null;
    $('#installButton').hidden = true;
    return;
  }
  const isAppleMobile = /iphone|ipad|ipod/i.test(navigator.userAgent);
  showNotice('Install LU Maths Hub', isAppleMobile ? 'In Safari, tap Share, then choose “Add to Home Screen”.' : 'Use your browser menu and choose “Install app” or “Add to Home screen”.');
}

function setupTagline() {
  let index = 0;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  setInterval(() => {
    index = (index + 1) % CONFIG.typedPhrases.length;
    $('#rotatingTagline').textContent = CONFIG.typedPhrases[index];
  }, 2600);
}

function setupEvents() {
  $('#themeButton').addEventListener('click', () => setTheme(document.documentElement.dataset.theme === 'light' ? 'dark' : 'light'));
  $('#profileButton').addEventListener('click', showProfile);
  $('#homeButton').addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  $('#searchInput').addEventListener('input', (event) => filterCards(event.target.value));
  $('#clearSearchButton').addEventListener('click', () => { $('#searchInput').value = ''; filterCards(''); $('#searchInput').focus(); });
  $('[data-action="scroll-academics"]').addEventListener('click', () => $('#academics').scrollIntoView({ behavior: 'smooth', block: 'start' }));
  $('[data-action="main-whatsapp"]').addEventListener('click', () => openExternal(CONFIG.mainWhatsapp));
  $$('[data-close-dialog]').forEach((button) => button.addEventListener('click', () => closeDialog($(`#${button.dataset.closeDialog}`))));
  $$('.modal').forEach((dialog) => dialog.addEventListener('click', (event) => { if (event.target === dialog) closeDialog(dialog); }));
  $$('.bottom-nav .nav-item').forEach((button) => button.addEventListener('click', () => {
    $$('.bottom-nav .nav-item').forEach((item) => item.classList.toggle('active', item === button));
    const action = button.dataset.action;
    if (action === 'home') window.scrollTo({ top: 0, behavior: 'smooth' });
    else if (action === 'profile') showProfile();
    else openLinksDialog(action);
  }));
  $('#installButton').addEventListener('click', promptInstall);
  $('#installCardButton').addEventListener('click', promptInstall);
  window.addEventListener('beforeinstallprompt', (event) => { event.preventDefault(); installPrompt = event; $('#installButton').hidden = false; $('#installCardButton').hidden = false; });
  window.addEventListener('appinstalled', () => { showToast('LU Maths Hub is installed.'); $('#installButton').hidden = true; $('#installCard').hidden = true; });
}

function registerServiceWorker() {
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    navigator.serviceWorker.register('./service-worker.js').catch((error) => console.warn('Service worker registration failed', error));
  }
}

function init() {
  setTheme(localStorage.getItem('lu-mobile-theme') === 'light' ? 'light' : 'dark');
  renderCards();
  updateGreeting();
  setupEvents();
  setupTagline();
  registerServiceWorker();
}

document.addEventListener('DOMContentLoaded', init);
