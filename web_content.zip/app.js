const BLOOD_TYPES=["O+","O-","A+","A-","B+","B-","AB+","AB-"];
const $=id=>document.getElementById(id);
const get=(k,fallback=[])=>{try{return JSON.parse(localStorage.getItem(k))??fallback}catch{return fallback}};
const put=(k,v)=>localStorage.setItem(k,JSON.stringify(v));
function toast(msg){$("toast").textContent=msg;$("toast").classList.remove("hidden");setTimeout(()=>$("toast").classList.add("hidden"),3000)}
function fillTypes(id){$(id).innerHTML=BLOOD_TYPES.map(t=>`<option value="${t}">${t}</option>`).join("")}
["donorType","searchType","urgentType"].forEach(fillTypes);
function show(id){document.querySelectorAll(".view").forEach(v=>v.classList.add("hidden"));$(id).classList.remove("hidden");window.scrollTo({top:0,behavior:"smooth"});if(id==="urgentView")renderUrgent()}
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>show(b.dataset.go)));
$("showSignup").onclick=()=>show("signupView");
$("guestBtn").onclick=()=>{sessionStorage.setItem("qdl_guest","1");show("homeView")};
$("logoutBtn").onclick=()=>{sessionStorage.removeItem("qdl_guest");sessionStorage.removeItem("qdl_user");show("loginView")};
$("signupBtn").onclick=()=>{
 const name=$("signupName").value.trim(),phone=normalizePhone($("signupPhone").value),password=$("signupPassword").value;
 if(!name||!phone||password.length<6)return toast("أدخل الاسم ورقم الهاتف وكلمة مرور من 6 أحرف على الأقل.");
 const users=get("qdl_users",[]);
 if(users.some(u=>u.phone===phone))return toast("رقم الهاتف مسجل مسبقًا.");
 users.push({name,phone,password});put("qdl_users",users);sessionStorage.setItem("qdl_user",phone);toast("تم إنشاء الحساب التجريبي.");show("homeView");
};
$("loginBtn").onclick=()=>{
 const phone=normalizePhone($("loginPhone").value),password=$("loginPassword").value;
 const u=get("qdl_users",[]).find(u=>u.phone===phone&&u.password===password);
 if(!u)return toast("لم يتم العثور على حساب مطابق في هذه المعاينة. يمكنك إنشاء حساب أو الدخول كزائر.");
 sessionStorage.setItem("qdl_user",phone);show("homeView");
};
function normalizePhone(v){return (v||"").replace(/[^\d+]/g,"").replace(/^00/,"+")}
$("saveDonorBtn").onclick=()=>{
 const name=$("donorName").value.trim(),type=$("donorType").value,phone=normalizePhone($("donorPhone").value),location=$("donorLocation").value.trim();
 if(!name||!phone||!location)return toast("يرجى إكمال الاسم ورقم الهاتف والسكن.");
 if(!$("donorConsent").checked)return toast("يرجى الموافقة على استخدام بياناتك للتواصل بشأن التبرع.");
 const donors=get("qdl_donors",[]);
 if(donors.some(d=>d.phone===phone))return toast("هذا الرقم مسجل كمتبرع بالفعل.");
 donors.push({name,type,phone,location,createdAt:new Date().toISOString()});put("qdl_donors",donors);
 ["donorName","donorPhone","donorLocation"].forEach(id=>$(id).value="");$("donorConsent").checked=false;
 toast("حُفظ المتبرع في هذه المعاينة على الجهاز.");show("searchView");renderDonors();
};
$("searchBtn").onclick=renderDonors;$("searchType").onchange=renderDonors;$("searchText").oninput=renderDonors;
function renderDonors(){
 const type=$("searchType").value,q=$("searchText").value.trim().toLowerCase();
 const list=get("qdl_donors",[]).filter(d=>d.type===type&&(`${d.name} ${d.location}`).toLowerCase().includes(q));
 $("donorResults").innerHTML=list.length?list.map(d=>`<article class="result-card"><h3>${esc(d.name)} <span class="badge">${esc(d.type)}</span></h3><p>📍 السكن: ${esc(d.location)}</p><p>📞 ${esc(d.phone)}</p><a href="tel:${escAttr(d.phone)}">الاتصال بالمتبرع</a></article>`).join(""):`<div class="empty">لا توجد بيانات متبرعين بهذه الفصيلة في هذه المعاينة حتى الآن.</div>`;
}
$("addUrgentBtn").onclick=()=>{
 const type=$("urgentType").value,place=$("urgentPlace").value.trim(),phone=normalizePhone($("urgentPhone").value),details=$("urgentDetails").value.trim();
 if(!place||!phone||!details)return toast("أكمل مكان الحاجة ورقم التواصل والتفاصيل.");
 const requests=get("qdl_urgent",[]);requests.unshift({type,place,phone,details,createdAt:new Date().toISOString(),status:"مفتوح"});put("qdl_urgent",requests);
 $("urgentPlace").value=$("urgentPhone").value=$("urgentDetails").value="";toast("أضيف الطلب محليًا في هذه المعاينة.");renderUrgent();
};
function renderUrgent(){
 const list=get("qdl_urgent",[]);
 $("urgentResults").innerHTML=list.length?list.map((r,i)=>`<article class="result-card"><h3>طلب دم عاجل <span class="badge">${esc(r.type)}</span></h3><p>📍 ${esc(r.place)}</p><p>${esc(r.details)}</p><p>الحالة: ${esc(r.status)} • ${new Date(r.createdAt).toLocaleString("ar")}</p><a href="tel:${escAttr(r.phone)}">الاتصال: ${esc(r.phone)}</a> <button class="outline" onclick="closeRequest(${i})">تم توفير الدم</button></article>`).join(""):`<div class="empty">لا توجد طلبات عاجلة منشورة في هذه المعاينة.</div>`;
}
window.closeRequest=i=>{const r=get("qdl_urgent",[]);if(r[i])r[i].status="تم توفير الدم";put("qdl_urgent",r);renderUrgent();toast("تم تحديث حالة الطلب على هذا الجهاز.")};
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function escAttr(s){return esc(s).replace(/`/g,"&#96;")}
document.querySelectorAll(".back").forEach(b=>b.addEventListener("click",()=>show(b.dataset.go)));
if("serviceWorker" in navigator && location.protocol.startsWith("http"))window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
