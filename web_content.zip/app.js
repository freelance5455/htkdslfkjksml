import { parseCSV, syntheticData } from './data.js';
import { backtest, validateParams } from './engine.js';
import { runChecks } from './checks.js';
const $ = id => document.getElementById(id);
const fields = { balance: 'balance', risk: 'risk', lots: 'lots', point: 'point', pointValue: 'point-value', spread: 'spread', slippage: 'slippage', commission: 'commission', minStop: 'min-stop', minLot: 'min-lot', lotStep: 'lot-step', pivot: 'pivot', atr: 'atr', tolerance: 'tolerance', buffer: 'buffer', hold: 'hold', maxStop: 'max-stop' };
const state = { source: null, result: null, busy: false, cancelled: false, engineOkay: false, checks: [], settingsVersion: 0 };
const money = n => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const utc = t => new Date(t).toISOString().replace('T', ' ').slice(0, 16);
function status(text, error = false) { $('status').textContent = text; $('status').classList.toggle('error', error); }
function busy(value, cancellable = false) {
  state.busy = value;
  document.querySelectorAll('.setup input,.setup select,#demo,#self-test').forEach(el => { if (el.id || el.type === 'file') el.disabled = value; });
  $('run').disabled = value || !state.source || !state.engineOkay;
  $('cancel').hidden = !value || !cancellable;
  $('progress').hidden = !value; if (!value) $('progress').value = 0;
}
function params() {
  const p = {};
  for (const [key, id] of Object.entries(fields)) {
    if ($(id).value.trim() === '') throw new Error(`Enter a value for ${$(id).parentElement.firstChild.textContent.trim()}.`);
    p[key] = Number($(id).value);
  }
  return validateParams(p);
}
async function saveSettings(p) {
  try {
    if (window.gryphon?.storage) await window.gryphon.storage.set('crt-settings-v1', { version: 1, params: p, timestampMode: $('timestamp-mode').value });
  } catch { status(`${$('status').textContent} Settings could not be saved; this session still works.`, true); }
}
function dataInfo() {
  if (!state.source) return;
  const s = state.source;
  $('data-info').textContent = `${s.name} · ${s.bars.length.toLocaleString()} candles · ${utc(s.bars[0].t)} to ${utc(s.bars.at(-1).t)} UTC · ${s.gaps} gap(s).`;
  $('sample-banner').hidden = !s.synthetic;
}
async function loadFile() {
  const file = $('csv-file').files[0]; if (!file) return;
  busy(true); status('Validating candle history…');
  try {
    if (file.size > 35 * 1024 * 1024) throw new Error('File exceeds the 35 MB limit.');
    const result = await parseCSV(await file.text(), $('timestamp-mode').value, progress => { $('progress').value = progress; });
    state.source = { ...result, name: file.name, synthetic: false, timestampMode: $('timestamp-mode').value };
    dataInfo(); status('History loaded. Confirm the instrument settings, then run. Previous results remain until a new run completes.');
  } catch (error) { status(error.message, true); }
  finally { $('csv-file').value = ''; busy(false); }
}
async function loadDemo() {
  busy(true); status('Generating a reproducible synthetic sample…');
  try {
    const result = await syntheticData(progress => { $('progress').value = progress; });
    state.source = { ...result, name: 'Synthetic FX sample (28 days)', synthetic: true, timestampMode: 'generated-close' };
    dataInfo(); status('Synthetic sample ready. Run to explore the workflow; it is not market evidence.');
  } catch (error) { status(error.message, true); }
  finally { busy(false); }
}
async function run() {
  if (state.busy || !state.source || !state.engineOkay) return;
  let p; try { p = params(); } catch (error) { status(error.message, true); return; }
  busy(true, true); state.cancelled = false; status('Backtesting closed candles and next-open fills…');
  const source = state.source;
  try {
    const r = await backtest(source.bars, p, { cancelled: () => state.cancelled, progress: value => { $('progress').value = value; status(`Backtesting… ${Math.floor(value * 100)}%`); } });
    r.source = { name: source.name, synthetic: source.synthetic, gaps: source.gaps, timestampMode: source.timestampMode };
    r.checks = state.checks; r.executionModel = 'CRT browser backtester v1: next-open entry; stop-first; fixed spread; net profit sampled at M1 closes; three equal legs; no margin, swap or currency conversion.';
    state.result = r; renderResults();
    const warm = r.stats.h4Bars < Math.max(62, p.atr + 2);
    status(warm ? `Run complete, but only ${r.stats.h4Bars} complete H4 bars: insufficient warm-up. Import more history.` : `Run complete · ${r.trades.length} baskets · ${r.stats.triggers} triggers · ${Object.values(r.skips).reduce((a, b) => a + b, 0)} skipped entries.`);
    await saveSettings(p);
  } catch (error) { status(error.message, true); }
  finally { busy(false); }
}
function metric(id, value, signed = false) {
  const el = $(id); el.textContent = value;
  el.classList.remove('positive', 'negative');
  if (signed) el.classList.add(state.result.net >= 0 ? 'positive' : 'negative');
}
function renderResults() {
  const r = state.result; if (!r) return;
  metric('net', `${r.net > 0 ? '+' : ''}${money(r.net)}`, true);
  $('return').textContent = `${r.returnPercent >= 0 ? '+' : ''}${r.returnPercent.toFixed(2)}% total return`;
  metric('drawdown', `${r.drawdown.toFixed(2)}%`);
  metric('winrate', r.winRate === null ? '—' : `${r.winRate.toFixed(1)}%`);
  $('basket-count').textContent = `${r.trades.length} closed baskets · ${r.trades.length * 3} legs`;
  metric('pf', r.profitFactor === null ? '—' : r.profitFactor === 'Infinity' ? '∞' : r.profitFactor.toFixed(2));
  $('ending').textContent = `Ending balance: ${money(r.balance)}`;
  $('date-range').textContent = `${utc(r.start)} — ${utc(r.end)} UTC`;
  $('bars-count').textContent = `${r.barCount.toLocaleString()} M1 bars`;
  $('chart-empty').hidden = true; $('export').disabled = false;
  $('trade-count').textContent = r.trades.length;
  const tbody = $('trades'); tbody.replaceChildren();
  const visible = r.trades.slice(-500).reverse();
  if (!visible.length) { const tr = document.createElement('tr'); const td = document.createElement('td'); td.colSpan = 5; td.className = 'empty-cell'; td.textContent = 'No qualifying baskets. Review warm-up, decision logs and entry diagnostics.'; tr.append(td); tbody.append(tr); }
  for (const t of visible) {
    const tr = document.createElement('tr');
    const values = [utc(t.entryTime), `${t.side} · 3 × ${t.lots}`, `${t.entry.toFixed(5)} → ${t.exit.toFixed(5)}`, `${t.net > 0 ? '+' : ''}${money(t.net)}`, t.reason];
    values.forEach((value, i) => { const td = document.createElement('td'); td.textContent = value; if (i === 3) td.className = t.net >= 0 ? 'positive' : 'negative'; tr.append(td); });
    tr.title = `Signal: ${utc(t.signalTime)} UTC; exit: ${utc(t.exitTime)} UTC; SL: ${t.stop}; hold: ${t.holdMinutes} min; fees: ${money(t.fees)}; gross: ${money(t.gross)}`;
    tbody.append(tr);
  }
  $('diagnostics').textContent = `H4 bars: ${r.stats.h4Bars} · H4-aligned M1 bars: ${r.stats.h4Aligned} · M15-confirmed M1 bars: ${r.stats.m15Confirmed} · Triggers: ${r.stats.triggers} · Skips: risk ${r.skips.risk}, stop ${r.skips.stop}, gap ${r.skips.gap}, final-bar ${r.skips.lastBar}. ${r.trades.length > 500 ? 'Showing latest 500 baskets; export contains all.' : ''} Source: ${r.source.name}${r.source.synthetic ? ' [SYNTHETIC]' : ''}. Results use the settings captured at run time.`;
  $('logs').textContent = r.events.length ? r.events.map(e => `${utc(e.t)} UTC | ${e.event}\n${e.detail}`).join('\n\n') : 'No strategy events. More history or different market conditions may be required.';
  $('sample-banner').hidden = !r.source.synthetic;
  drawChart();
}
function drawChart() {
  const canvas = $('chart'); const rect = canvas.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return;
  const dpr = Math.min(window.devicePixelRatio || 1, 3);
  canvas.width = Math.round(rect.width * dpr); canvas.height = Math.round(rect.height * dpr);
  const ctx = canvas.getContext('2d'); if (!ctx) return;
  ctx.scale(dpr, dpr); const w = rect.width, h = rect.height;
  const left = 70, right = 16, top = 20, bottom = 35;
  const points = state.result?.curve || [];
  let lo = Infinity, hi = -Infinity;
  for (const pt of points) { lo = Math.min(lo, pt.equity); hi = Math.max(hi, pt.equity); }
  if (!points.length) { lo = 0; hi = 100; }
  const pad = Math.max((hi - lo) * 0.15, Math.abs(hi) * 0.001, 1); lo -= pad; hi += pad;
  const y = value => top + (hi - value) / (hi - lo) * (h - top - bottom);
  ctx.font = '9px ui-monospace,monospace';
  for (let i = 0; i <= 4; i++) {
    const value = lo + (hi - lo) * i / 4; const py = y(value);
    ctx.strokeStyle = '#233039'; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(left, py); ctx.lineTo(w - right, py); ctx.stroke();
    ctx.fillStyle = '#6e808e'; ctx.textAlign = 'right'; ctx.fillText(value.toLocaleString('en-US', { maximumFractionDigits: 0 }), left - 10, py + 3);
  }
  if (points.length < 2) return;
  const t0 = points[0].t, tn = points.at(-1).t;
  const x = t => left + (t - t0) / Math.max(1, tn - t0) * (w - left - right);
  // Preserve local extrema when reducing large curves to canvas pixel resolution.
  const step = Math.max(1, Math.floor(points.length / Math.max(10, (w - left - right) * 2)));
  const plot = [];
  for (let i = 0; i < points.length; i += step) {
    let minI = i, maxI = i;
    for (let j = i; j < Math.min(i + step, points.length); j++) { if (points[j].equity < points[minI].equity) minI = j; if (points[j].equity > points[maxI].equity) maxI = j; }
    for (const index of [...new Set([i, minI, maxI, Math.min(i + step - 1, points.length - 1)])].sort((a, b) => a - b)) plot.push(points[index]);
  }
  ctx.beginPath(); plot.forEach((pt, i) => { if (!i) ctx.moveTo(x(pt.t), y(pt.equity)); else ctx.lineTo(x(pt.t), y(pt.equity)); });
  ctx.lineWidth = 1.6; ctx.strokeStyle = '#b8ed78'; ctx.stroke();
  ctx.lineTo(x(plot.at(-1).t), h - bottom); ctx.lineTo(x(plot[0].t), h - bottom); ctx.closePath();
  const gradient = ctx.createLinearGradient(0, top, 0, h - bottom); gradient.addColorStop(0, '#b8ed7820'); gradient.addColorStop(1, '#b8ed7800'); ctx.fillStyle = gradient; ctx.fill();
  ctx.fillStyle = '#6e808e'; ctx.textAlign = 'left'; ctx.fillText(new Date(t0).toISOString().slice(0, 10), left, h - 12);
  ctx.textAlign = 'right'; ctx.fillText(new Date(tn).toISOString().slice(0, 10), w - right, h - 12);
}
function exportReport() {
  if (!state.result) return;
  const blob = new Blob([JSON.stringify({ schemaVersion: 1, exportedAt: new Date().toISOString(), ...state.result }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `crt-${state.result.source.synthetic ? 'synthetic-' : ''}backtest-report.json`; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 30000);
}
function selectTab(name) {
  for (const tab of ['trades', 'logs', 'method']) { $('tab-' + tab).classList.toggle('active', tab === name); $('tab-' + tab).setAttribute('aria-selected', String(tab === name)); $('view-' + tab).hidden = tab !== name; }
}
async function selfCheck() {
  busy(true); status('Checking parser, causal indicators and basket accounting…');
  try {
    state.checks = await runChecks();
    const passed = state.checks.filter(c => c.passed).length;
    state.engineOkay = passed === state.checks.length;
    $('test-results').textContent = state.checks.map(c => `${c.passed ? 'PASS' : 'FAIL'} · ${c.name}${c.error ? ': ' + c.error : ''}`).join('\n');
    status(state.engineOkay ? `${passed}/${state.checks.length} deterministic engine checks passed in this browser. ${state.source ? 'Ready to run.' : 'Load M1 history or try the synthetic sample.'}` : 'Engine checks failed. Backtesting is disabled; see Methodology for details.', !state.engineOkay);
  } catch (error) { state.engineOkay = false; $('test-results').textContent = error.message; status(`Self-check error: ${error.message}`, true); }
  finally { busy(false); }
}
$('csv-file').addEventListener('change', loadFile);
$('demo').addEventListener('click', loadDemo);
$('run').addEventListener('click', run);
$('cancel').addEventListener('click', () => { state.cancelled = true; status('Cancelling run…'); });
$('export').addEventListener('click', exportReport);
$('self-test').addEventListener('click', selfCheck);
for (const name of ['trades', 'logs', 'method']) {
  $('tab-' + name).addEventListener('click', () => selectTab(name));
  $('tab-' + name).addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault(); const names = ['trades', 'logs', 'method']; const index = (names.indexOf(name) + (event.key === 'ArrowRight' ? 1 : 2)) % 3;
    selectTab(names[index]); $('tab-' + names[index]).focus();
  });
}
for (const id of Object.values(fields)) {
  $(id).addEventListener('input', () => { state.settingsVersion++; status('Settings changed. Run again to update results.'); });
  $(id).addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); run(); } });
}
$('timestamp-mode').addEventListener('change', () => {
  if (state.source && !state.source.synthetic) { state.source = null; $('data-info').textContent = 'Timestamp interpretation changed. Re-import your CSV to apply it.'; $('run').disabled = true; }
  status('Timestamp interpretation updated. Existing results are unchanged.');
});
new ResizeObserver(drawChart).observe($('chart').parentElement);
async function initialize() {
  busy(true);
  let storageWarning = '';
  try {
    if (window.gryphon?.storage) {
      const saved = await window.gryphon.storage.get('crt-settings-v1');
      if (saved?.version === 1 && saved.params) {
        validateParams(saved.params);
        for (const [key, id] of Object.entries(fields)) if (Number.isFinite(saved.params[key])) $(id).value = saved.params[key];
        if (['open', 'close'].includes(saved.timestampMode)) $('timestamp-mode').value = saved.timestampMode;
      }
    }
  } catch { storageWarning = ' Saved settings unavailable; defaults loaded.'; }
  await selfCheck();
  if (storageWarning) status($('status').textContent + storageWarning, true);
  drawChart();
}
initialize().catch(error => { busy(false); status(`Initialization failed: ${error.message}`, true); });
