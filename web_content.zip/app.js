

const API_KEY = "AQ.Ab8RN6LXvwjJLJRMvuqAvDXVwl-OMNI8QhXWu1B-c9-_snOQWg";

const MODEL = "gemini-3.5-flash-lite";


let chat;

let history = [];

let memory =
localStorage.getItem("qisili_profile_memory") || "";



window.addEventListener("DOMContentLoaded",()=>{


chat=document.getElementById("chat");


if(!chat){

console.log("找不到聊天區");

return;

}



loadHistory();


createMemoryButton();


});




// =================
// 讀取聊天紀錄
// =================

function loadHistory(){

try{

const saved =
localStorage.getItem("qisili_memory");


if(saved){

history=JSON.parse(saved);

}


if(!Array.isArray(history)){

history=[];

}


}catch{

history=[];

}



history.forEach(msg=>{

renderMessage(
msg.role,
msg.text
);

});


}






// =================
// 顯示訊息
// =================

function renderMessage(role,text){


const bubble=document.createElement("div");


bubble.className =
role==="你"
?
"message user-message"
:
"message ai-message";



const name=document.createElement("div");

name.className="message-name";



name.textContent =
role==="你"
?
"你："
:
"齊司禮：";



const content=document.createElement("div");

content.className="message-text";

content.textContent=text;



if(role==="你"){

bubble.append(
content,
name
);


}else{


bubble.append(
name,
content
);


}



chat.appendChild(bubble);


chat.scrollTop =
chat.scrollHeight;



return {

content:content

};


}






// =================
// 長期記憶按鈕
// =================


function createMemoryButton(){


if(document.querySelector(".memory-area")){
    return;
}

const area=document.createElement("div");

area.className="memory-area";



const edit=document.createElement("button");

edit.textContent="🧠";


edit.onclick=function(){


const result=prompt(

"編輯齊司禮長期記憶：",

memory

);



if(result!==null){

memory=result.trim();


localStorage.setItem(

"qisili_profile_memory",

memory

);


}

};





const add=document.createElement("button");

add.textContent="+";


add.onclick=function(){


const fact=prompt(

"想讓齊司禮記住什麼？"

);



if(!fact || !fact.trim())return;



memory =
memory
?
memory+"\n"+fact.trim()
:
fact.trim();



localStorage.setItem(

"qisili_profile_memory",

memory

);


};



area.append(
edit,
add
);



const inputArea =
document.getElementById("input-area");



if(inputArea){

inputArea.appendChild(area);

}


}
// =================
// 傳送訊息
// =================

async function send(){


const input =
document.getElementById("message");


const text =
input.value.trim();



if(!text)return;



const oldHistory =
history.slice();



history.push({

role:"你",

text:text

});



renderMessage(
"你",
text
);



input.value="";



const loading =
renderMessage(

"齊司禮",

""

);



loading.content.innerHTML=

`
<div class="typing">

<span></span>
<span></span>
<span></span>

</div>
`;



try{


const conversation =

oldHistory

.slice(-20)

.map(x =>

`${x.role}：${x.text}`

)

.join("\n");





const promptText = `

你現在扮演《光與夜之戀》的齊司禮。


【性格】

- 冷靜
- 成熟
- 理性
- 外冷內熱
- 偶爾嘴硬
- 會默默關心對方
- 不像客服
- 回覆自然，像手機聊天


【長期記憶】

${memory || "沒有保存的記憶"}



【近期聊天】

${conversation || "沒有"}



【使用者訊息】

${text}



請直接以齊司禮身份回覆。

`;





const response = await fetch(

`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${API_KEY}`,

{

method:"POST",

headers:{

"Content-Type":"application/json"

},


body:JSON.stringify({

contents:[

{

parts:[

{

text:promptText

}

]

}

]

})

}

);





const data =
await response.json();





if(!response.ok){

throw new Error(

data.error?.message ||
"API錯誤"

);

}





const reply =

data.candidates
?.[0]
?.content
?.parts
?.[0]
?.text;





if(!reply){

throw new Error(
"AI沒有產生回覆"
);

}





loading.content.textContent =
reply;





history.push({

role:"齊司禮",

text:reply

});





localStorage.setItem(

"qisili_memory",

JSON.stringify(history)

);




}

catch(error){



loading.content.textContent =

"連線出了點問題：" + error.message;



console.log(error);



// 刪除失敗的使用者訊息

history.pop();



localStorage.setItem(

"qisili_memory",

JSON.stringify(history)

);



}


}