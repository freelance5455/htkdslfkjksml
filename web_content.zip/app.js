// DRIP AI // ULTRA KNOWLEDGE — client app.
// No API keys are stored in this file. Keys entered in Settings live in sessionStorage only.
(function () {
  "use strict";
  var LS = { chats: "drip.chats.v1", active: "drip.active.v1", shelf: "drip.shelf.v1", settings: "drip.settings.v1" };
  var SS_KEY = "drip.apikey";
  var MAX_FILE = 1024 * 1024;
  var NL = String.fromCharCode(10);
  var $ = function (id) { return document.getElementById(id); };
  var uid = function () { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); };

  function load(k, fb) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : fb; } catch (e) { return fb; } }
  function save(k, v) {
    try { localStorage.setItem(k, JSON.stringify(v)); }
    catch (e) { alert("Could not save: browser storage is full or blocked."); }
  }

  var chats = load(LS.chats, []);
  var activeId = load(LS.active, null);
  var shelf = load(LS.shelf, []);
  var settings = Object.assign({ mode: "proxy", proxyUrl: "", baseUrl: "https://api.openai.com/v1", model: "", useShelf: true, stream: true }, load(LS.settings, {}));
  var controller = null;

  function persistChats() { save(LS.chats, chats); save(LS.active, activeId); }
  function active() { return chats.find(function (c) { return c.id === activeId; }); }
  function newChat() { var c = { id: uid(), title: "New chat", created: Date.now(), messages: [] }; chats.unshift(c); activeId = c.id; persistChats(); return c; }
  if (!active()) { if (chats.length) activeId = chats[0].id; else newChat(); }

  // ---------- Tabs ----------
  var tabs = Array.prototype.slice.call(document.querySelectorAll("[data-tab]"));
  function showTab(name) {
    tabs.forEach(function (b) { var on = b.dataset.tab === name; b.setAttribute("aria-selected", String(on)); $(b.dataset.tab).hidden = !on; });
  }
  tabs.forEach(function (b, i) {
    b.addEventListener("click", function () { showTab(b.dataset.tab); });
    b.addEventListener("keydown", function (e) {
      if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
      var n = tabs[(i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length]; n.focus(); showTab(n.dataset.tab);
    });
  });

  // ---------- Status / offline ----------
  function configured() {
    if (!settings.model) return "Set a model in Settings.";
    if (settings.mode === "proxy") return settings.proxyUrl ? "" : "Set a proxy endpoint URL in Settings.";
    if (!settings.baseUrl) return "Set an API base URL in Settings.";
    if (!sessionStorage.getItem(SS_KEY)) return "Enter an API key in Settings (kept for this tab session only).";
    return "";
  }
  function renderStatus() {
    var online = navigator.onLine;
    $("offline").hidden = online;
    var miss = configured();
    $("conn").innerHTML = "";
    var s = document.createElement("span");
    if (!online) { s.className = "bad"; s.textContent = "Offline — AI unavailable"; }
    else if (miss) { s.className = "bad"; s.textContent = "AI not configured"; }
    else { s.className = "ok"; s.textContent = (settings.mode === "proxy" ? "Proxy" : "Direct") + " · " + settings.model; }
    $("conn").appendChild(s);
    $("send").disabled = !online || !!controller;
  }
  window.addEventListener("online", renderStatus);
  window.addEventListener("offline", renderStatus);

  // ---------- Chat rendering ----------
  function renderChatSelect() {
    var sel = $("chat-select"); sel.innerHTML = "";
    chats.forEach(function (c) { var o = document.createElement("option"); o.value = c.id; o.textContent = c.title; o.selected = c.id === activeId; sel.appendChild(o); });
  }
  function msgEl(m) {
    var li = document.createElement("li"); li.className = "msg " + m.role;
    var label = m.role === "user" ? "You" : m.role === "assistant" ? "DRIP AI" : "Error";
    li.setAttribute("aria-label", label);
    li.textContent = m.content; return li;
  }
  function renderMessages() {
    var ol = $("messages"); ol.innerHTML = "";
    var c = active();
    if (!c.messages.length) {
      var e = document.createElement("li"); e.className = "empty";
      e.textContent = configured() ? "No messages yet. " + configured() : "No messages yet. Ask something to start.";
      ol.appendChild(e); return;
    }
    c.messages.forEach(function (m) { ol.appendChild(msgEl(m)); });
    ol.lastChild.scrollIntoView({ block: "end" });
  }
  $("chat-select").addEventListener("change", function (e) { activeId = e.target.value; persistChats(); renderMessages(); });
  $("new-chat").addEventListener("click", function () { newChat(); renderChatSelect(); renderMessages(); $("prompt").focus(); });
  $("del-chat").addEventListener("click", function () {
    if (!confirm("Delete this conversation?")) return;
    chats = chats.filter(function (c) { return c.id !== activeId; });
    if (!chats.length) newChat(); else activeId = chats[0].id;
    persistChats(); renderChatSelect(); renderMessages();
  });

  // ---------- Knowledge context ----------
  function words(s) { return s.toLowerCase().split(/[^a-z0-9]+/).filter(function (w) { return w.length > 2; }); }
  function relevant(q) {
    var ws = words(q); if (!ws.length) return [];
    return shelf.map(function (it) {
      var hay = (it.title + " " + it.body).toLowerCase();
      return { it: it, s: ws.reduce(function (n, w) { return n + (hay.indexOf(w) >= 0 ? 1 : 0); }, 0) };
    }).filter(function (x) { return x.s > 0; }).sort(function (a, b) { return b.s - a.s; }).slice(0, 3).map(function (x) { return x.it; });
  }

  // ---------- API ----------
  function endpoint() {
    if (settings.mode === "proxy") return settings.proxyUrl;
    return settings.baseUrl.replace(/[/]+$/, "") + "/chat/completions";
  }
  function buildMessages(c) {
    var out = [];
    var last = c.messages[c.messages.length - 1];
    if (settings.useShelf && last) {
      var docs = relevant(last.content);
      if (docs.length) out.push({ role: "system", content: "Use these knowledge shelf notes if relevant:" + NL + NL + docs.map(function (d) { return "## " + d.title + NL + d.body.slice(0, 4000); }).join(NL + NL) });
    }
    c.messages.forEach(function (m) { if (m.role === "user" || m.role === "assistant") out.push({ role: m.role, content: m.content }); });
    return out;
  }
  function addError(c, text) { c.messages.push({ role: "error", content: text, ts: Date.now() }); persistChats(); renderMessages(); }

  async function send(text) {
    var c = active();
    c.messages.push({ role: "user", content: text, ts: Date.now() });
    if (c.title === "New chat") { c.title = text.slice(0, 40); renderChatSelect(); }
    persistChats(); renderMessages();
    if (!navigator.onLine) return addError(c, "You are offline. Your message was saved, but no AI reply can be generated until you reconnect.");
    var miss = configured(); if (miss) return addError(c, "AI not configured: " + miss);

    var headers = { "Content-Type": "application/json" };
    if (settings.mode === "direct") headers.Authorization = "Bearer " + sessionStorage.getItem(SS_KEY);
    var body = JSON.stringify({ model: settings.model, messages: buildMessages(c), stream: !!settings.stream });

    controller = new AbortController(); $("stop").hidden = false; renderStatus();
    var li = document.createElement("li"); li.className = "msg assistant pending"; li.setAttribute("aria-label", "DRIP AI (responding)");
    li.textContent = ""; $("messages").appendChild(li); li.scrollIntoView({ block: "end" });
    var acc = "";
    try {
      var res;
      try { res = await fetch(endpoint(), { method: "POST", headers: headers, body: body, signal: controller.signal }); }
      catch (e) { if (e.name === "AbortError") throw e; throw new Error("Network error: could not reach " + endpoint() + ". Check the URL, your connection, and that the server allows CORS from this origin."); }
      if (!res.ok) {
        var t = ""; try { t = (await res.text()).slice(0, 400); } catch (e) {}
        throw new Error("API error " + res.status + (res.status === 401 ? " (unauthorized — check API key / proxy auth)" : res.status === 404 ? " (not found — check URL and model)" : res.status === 429 ? " (rate limited or out of credits)" : "") + (t ? ":" + NL + t : ""));
      }
      var ct = res.headers.get("content-type") || "";
      if (ct.indexOf("text/event-stream") >= 0 && res.body) {
        var reader = res.body.getReader(), dec = new TextDecoder(), buf = "";
        while (true) {
          var r = await reader.read(); if (r.done) break;
          buf += dec.decode(r.value, { stream: true });
          var lines = buf.split(NL); buf = lines.pop();
          for (var i = 0; i < lines.length; i++) {
            var line = lines[i].trim();
            if (line.indexOf("data:") !== 0) continue;
            var data = line.slice(5).trim();
            if (data === "[DONE]") continue;
            var j; try { j = JSON.parse(data); } catch (e) { continue; }
            if (j.error) throw new Error("API error: " + (j.error.message || JSON.stringify(j.error)));
            var d = j.choices && j.choices[0] && j.choices[0].delta && j.choices[0].delta.content;
            if (d) { acc += d; li.textContent = acc; li.scrollIntoView({ block: "end" }); }
          }
        }
      } else {
        var json; try { json = await res.json(); } catch (e) { throw new Error("Invalid response: server did not return JSON or an event stream."); }
        acc = json && json.choices && json.choices[0] && json.choices[0].message && json.choices[0].message.content;
        if (typeof acc !== "string") throw new Error("Invalid response: no choices[0].message.content in reply.");
      }
      if (!acc) throw new Error("Invalid response: the API returned an empty answer.");
      c.messages.push({ role: "assistant", content: acc, ts: Date.now() });
      persistChats();
    } catch (e) {
      if (acc) c.messages.push({ role: "assistant", content: acc, ts: Date.now() });
      c.messages.push({ role: "error", content: e.name === "AbortError" ? "Stopped." : e.message, ts: Date.now() });
      persistChats();
    } finally {
      controller = null; $("stop").hidden = true; renderMessages(); renderStatus(); $("prompt").focus();
    }
  }
  $("stop").addEventListener("click", function () { if (controller) controller.abort(); });
  $("chat-form").addEventListener("submit", function (e) {
    e.preventDefault(); var q = $("prompt").value.trim(); if (!q || controller) return;
    $("prompt").value = ""; send(q);
  });
  $("prompt").addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey && !e.isComposing && window.matchMedia("(pointer:fine)").matches) { e.preventDefault(); $("chat-form").requestSubmit(); }
  });

  // ---------- Knowledge shelf ----------
  function persistShelf() { save(LS.shelf, shelf); }
  function resetNoteForm() { $("note-form").reset(); $("note-id").value = ""; $("note-heading").textContent = "Add knowledge"; $("note-cancel").hidden = true; }
  function renderShelf() {
    var q = $("search").value.trim().toLowerCase();
    var list = shelf.filter(function (it) { return !q || (it.title + " " + it.body).toLowerCase().indexOf(q) >= 0; });
    var ul = $("items"); ul.innerHTML = "";
    if (!list.length) {
      var e = document.createElement("li"); e.className = "empty";
      e.textContent = shelf.length ? "No items match your search." : "Your knowledge shelf is empty. Add a note or import a text file.";
      ul.appendChild(e); return;
    }
    list.forEach(function (it) {
      var li = document.createElement("li");
      var h = document.createElement("h3"); h.textContent = it.title;
      var p = document.createElement("p"); p.textContent = it.body.length > 280 ? it.body.slice(0, 280) + "…" : it.body;
      var row = document.createElement("div"); row.className = "row";
      var ed = document.createElement("button"); ed.type = "button"; ed.className = "ghost"; ed.textContent = "Edit"; ed.setAttribute("aria-label", "Edit " + it.title);
      ed.onclick = function () { $("note-id").value = it.id; $("note-title").value = it.title; $("note-body").value = it.body; $("note-heading").textContent = "Edit knowledge"; $("note-cancel").hidden = false; $("note-title").focus(); };
      var del = document.createElement("button"); del.type = "button"; del.className = "ghost danger"; del.textContent = "Delete"; del.setAttribute("aria-label", "Delete " + it.title);
      del.onclick = function () { if (!confirm("Delete \"" + it.title + "\"?")) return; shelf = shelf.filter(function (x) { return x.id !== it.id; }); persistShelf(); renderShelf(); };
      row.append(ed, del); li.append(h, p, row); ul.appendChild(li);
    });
  }
  $("search").addEventListener("input", renderShelf);
  $("note-cancel").addEventListener("click", resetNoteForm);
  $("note-form").addEventListener("submit", function (e) {
    e.preventDefault();
    var id = $("note-id").value, title = $("note-title").value.trim(), body = $("note-body").value.trim();
    if (!title || !body) return;
    var ex = id && shelf.find(function (x) { return x.id === id; });
    if (ex) { ex.title = title; ex.body = body; ex.updated = Date.now(); }
    else shelf.unshift({ id: uid(), title: title, body: body, updated: Date.now() });
    persistShelf(); resetNoteForm(); renderShelf();
  });
  $("file").addEventListener("change", function (e) {
    var files = Array.prototype.slice.call(e.target.files || []); var msgs = []; var pending = files.length;
    if (!pending) return;
    $("upload-msg").textContent = "Importing…";
    files.forEach(function (f) {
      var n = f.name.toLowerCase();
      var ok = /[.](txt|md|markdown)$/.test(n) || f.type === "text/plain" || f.type === "text/markdown";
      if (/[.]pdf$/.test(n) || f.type === "application/pdf") { msgs.push(f.name + ": PDF not supported — paste its text as a note"); return done(); }
      if (!ok) { msgs.push(f.name + ": rejected (only .txt / .md)"); return done(); }
      if (f.size > MAX_FILE) { msgs.push(f.name + ": rejected (over 1 MB)"); return done(); }
      var r = new FileReader();
      r.onload = function () { shelf.unshift({ id: uid(), title: f.name, body: String(r.result), updated: Date.now() }); msgs.push(f.name + ": imported"); done(); };
      r.onerror = function () { msgs.push(f.name + ": could not be read"); done(); };
      r.readAsText(f);
    });
    function done() { if (--pending === 0) { persistShelf(); $("upload-msg").textContent = msgs.join(" · "); e.target.value = ""; renderShelf(); } }
  });

  // ---------- Settings ----------
  function fillSettings() {
    document.querySelectorAll("input[name=mode]").forEach(function (r) { r.checked = r.value === settings.mode; });
    $("proxy-url").value = settings.proxyUrl; $("base-url").value = settings.baseUrl; $("model").value = settings.model;
    $("api-key").value = sessionStorage.getItem(SS_KEY) || "";
    $("use-shelf").checked = !!settings.useShelf; $("stream").checked = !!settings.stream;
    toggleMode();
  }
  function toggleMode() {
    var m = (document.querySelector("input[name=mode]:checked") || {}).value || "proxy";
    $("proxy-fields").hidden = m !== "proxy"; $("direct-fields").hidden = m !== "direct";
  }
  document.querySelectorAll("input[name=mode]").forEach(function (r) { r.addEventListener("change", toggleMode); });
  $("settings-form").addEventListener("submit", function (e) {
    e.preventDefault();
    settings.mode = (document.querySelector("input[name=mode]:checked") || {}).value || "proxy";
    settings.proxyUrl = $("proxy-url").value.trim(); settings.baseUrl = $("base-url").value.trim();
    settings.model = $("model").value.trim(); settings.useShelf = $("use-shelf").checked; settings.stream = $("stream").checked;
    save(LS.settings, settings);
    var key = $("api-key").value.trim();
    if (settings.mode === "direct" && key) sessionStorage.setItem(SS_KEY, key);
    else sessionStorage.removeItem(SS_KEY);
    if (settings.mode === "proxy") $("api-key").value = "";
    var miss = configured();
    $("settings-msg").textContent = miss ? "Saved, but incomplete: " + miss : "Saved. Ready to chat.";
    renderStatus(); renderMessages();
  });

  // ---------- Export / import ----------
  $("export").addEventListener("click", function () {
    var safe = { mode: settings.mode, proxyUrl: settings.proxyUrl, baseUrl: settings.baseUrl, model: settings.model, useShelf: settings.useShelf, stream: settings.stream };
    var data = { app: "drip-ai", version: 1, exportedAt: new Date().toISOString(), chats: chats, shelf: shelf, settings: safe };
    var blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    var a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "drip-ai-backup.json";
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 30000);
    $("data-msg").textContent = "Exported " + chats.length + " chats and " + shelf.length + " knowledge items.";
  });
  $("import").addEventListener("change", function (e) {
    var f = e.target.files && e.target.files[0]; if (!f) return;
    var r = new FileReader();
    r.onload = function () {
      try {
        var d = JSON.parse(String(r.result));
        if (!d || d.app !== "drip-ai" || !Array.isArray(d.chats) || !Array.isArray(d.shelf)) throw new Error("Not a DRIP AI backup file.");
        var okChat = d.chats.filter(function (c) { return c && typeof c.id === "string" && Array.isArray(c.messages); });
        var okShelf = d.shelf.filter(function (s) { return s && typeof s.title === "string" && typeof s.body === "string"; });
        if (!confirm("Replace current data with " + okChat.length + " chats and " + okShelf.length + " knowledge items?")) return;
        chats = okChat; shelf = okShelf.map(function (s) { return Object.assign({ id: uid(), updated: Date.now() }, s); });
        if (d.settings) { ["mode", "proxyUrl", "baseUrl", "model", "useShelf", "stream"].forEach(function (k) { if (k in d.settings) settings[k] = d.settings[k]; }); save(LS.settings, settings); }
        if (!chats.length) newChat(); activeId = chats[0].id;
        persistChats(); persistShelf(); fillSettings(); renderAll();
        $("data-msg").textContent = "Imported successfully.";
      } catch (err) { $("data-msg").textContent = "Import failed: " + err.message; }
      e.target.value = "";
    };
    r.onerror = function () { $("data-msg").textContent = "Import failed: file could not be read."; };
    r.readAsText(f);
  });

  function renderAll() { renderChatSelect(); renderMessages(); renderShelf(); renderStatus(); }
  fillSettings(); renderAll();

  if ("serviceWorker" in navigator && location.protocol === "https:" || location.hostname === "localhost") {
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(function () {});
  }
})();
