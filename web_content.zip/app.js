const $=id=>document.getElementById(id);
let days=1, series=[], currentAsset='bitcoin';
const names={bitcoin:'Bitcoin',ethereum:'Ethereum',solana:'Solana',dogecoin:'Dogecoin'};
const fmt=n=>Number(n).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:n<1?6:2});
function setStatus(ok,msg){$('status').textContent=msg;$('dot').style.background=ok?'#6ce0ad':'#e5ad49'}
async function load(){
 currentAsset=$('asset').value;setStatus(false,'ডেটা লোড হচ্ছে…');
 try{
  const r=await fetch(`https://api.coingecko.com/api/v3/coins/${currentAsset}/market_chart?vs_currency=usd&days=${days}`);
  if(!r.ok)throw new Error('API status '+r.status);
  const d=await r.json();series=(d.prices||[]).map(p=>({t:p[0],v:p[1]})).filter(p=>Number.isFinite(p.v));
  if(!series.length)throw new Error('ডেটা পাওয়া যায়নি');
  const last=series[series.length-1],first=series[0],chg=(last.v-first.v)/first.v*100;
  $('price').textContent='$'+fmt(last.v);$('change').textContent=(chg>=0?'+':'')+chg.toFixed(2)+'% এই সময়ের পরিবর্তন';
  $('change').style.color=chg>=0?'#6ce0ad':'#f17e8a';
  $('updated').textContent='সর্বশেষ পাওয়া: '+new Date(last.t).toLocaleString();
  $('points').textContent=series.length;$('high').textContent='$'+fmt(Math.max(...series.map(p=>p.v)));$('low').textContent='$'+fmt(Math.min(...series.map(p=>p.v)));
  $('tfLabel').textContent=days===1?'১ দিন':days+' দিন';
  draw();setStatus(true,'লাইভ API সংযুক্ত');
 }catch(e){setStatus(false,'ডেটা পাওয়া যায়নি');$('price').textContent='—';$('change').textContent='ইন্টারনেট/API সীমাবদ্ধতা পরীক্ষা করো';$('points').textContent='—';draw();}
}
function draw(){
 const c=$('chart'),ctx=c.getContext('2d'),rect=c.getBoundingClientRect(),dpr=window.devicePixelRatio||1;
 c.width=Math.max(300,rect.width*dpr);c.height=Math.max(180,rect.height*dpr);ctx.scale(dpr,dpr);
 const w=c.width/dpr,h=c.height/dpr;ctx.clearRect(0,0,w,h);
 ctx.strokeStyle='#26354a';ctx.lineWidth=1;
 for(let i=0;i<5;i++){let y=12+(h-28)*i/4;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
 if(series.length<2){ctx.fillStyle='#91a1b8';ctx.font='13px system-ui';ctx.fillText('চার্ট দেখাতে ইন্টারনেট ডেটা প্রয়োজন',12,h/2);return;}
 const vals=series.map(x=>x.v),min=Math.min(...vals),max=Math.max(...vals),pad=(max-min)*.12||1;
 const lo=min-pad,hi=max+pad;
 ctx.beginPath();series.forEach((p,i)=>{const x=i/(series.length-1)*(w-8)+4,y=h-18-(p.v-lo)/(hi-lo)*(h-34);i?ctx.lineTo(x,y):ctx.moveTo(x,y)});
 ctx.lineWidth=2.3;ctx.strokeStyle='#68a7ff';ctx.stroke();
 const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,'rgba(104,167,255,.22)');g.addColorStop(1,'rgba(104,167,255,0)');
 ctx.lineTo(w-4,h-18);ctx.lineTo(4,h-18);ctx.closePath();ctx.fillStyle=g;ctx.fill();
 ctx.fillStyle='#91a1b8';ctx.font='11px system-ui';ctx.fillText('$'+fmt(max),5,12);ctx.fillText('$'+fmt(min),5,h-3);
}
$('asset').addEventListener('change',load);$('refresh').addEventListener('click',load);
document.querySelectorAll('.range').forEach(b=>b.addEventListener('click',()=>{days=Number(b.dataset.days);document.querySelectorAll('.range').forEach(x=>x.classList.toggle('active',x===b));load()}));
window.addEventListener('resize',draw);
load();setInterval(load,60000);