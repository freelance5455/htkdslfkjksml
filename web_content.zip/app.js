const screens=[...document.querySelectorAll('.screen')];
function show(id){screens.forEach(s=>s.classList.toggle('active',s.id===id));document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.screen===id));window.scrollTo(0,0)}
document.querySelectorAll('[data-screen]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.screen)));
document.querySelectorAll('[data-search]').forEach(b=>b.addEventListener('click',()=>{document.getElementById('queryTitle').textContent=b.dataset.search;show('results')}));
document.getElementById('surprise').addEventListener('click',()=>show('results'));
document.querySelectorAll('.product').forEach(p=>p.addEventListener('click',()=>show('detail')));
