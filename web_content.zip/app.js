// --- SÉCURITÉ ANTI-PLANTAGE ---
const storage = (() => {
    try {
        localStorage.setItem('t', 't'); localStorage.removeItem('t');
        return localStorage;
    } catch (e) {
        return { getItem: () => null, setItem: () => {}, removeItem: () => {} };
    }
})();

// --- NAVIGATION ---
function changerOnglet(idOnglet, bouton) {
    document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.getElementById('tab-' + idOnglet).classList.add('active');
    bouton.classList.add('active');
    
    const btnFlottant = document.querySelector('.btn-flottant');
    if (btnFlottant) btnFlottant.style.display = (idOnglet === 'collection') ? 'flex' : 'none';
}

// --- COLLECTION ---
let maCollection = JSON.parse(storage.getItem('otakus_glass')) || [];

function afficherCollection(filtre = 'tout') {
    const grid = document.getElementById('maCollection');
    const homeRow = document.getElementById('homeCollection');
    grid.innerHTML = ''; homeRow.innerHTML = '';
    
    let items = maCollection;
    if (filtre !== 'tout') items = maCollection.filter(item => item.type === filtre);

    // Grille Collection
    if (items.length === 0) {
        grid.innerHTML = '<p style="grid-column: 1/-1; text-align:center; color:var(--text-dim);">Aucun média. Clique sur le bouton +</p>';
    } else {
        items.forEach(item => {
            let visuel = item.type === 'image' && item.data 
                ? `<img src="${item.data}">` 
                : `<div class="card-img ${item.type === 'video' ? 'bg-1' : 'bg-2'}" style="height:100px;">${item.type === 'video' ? '🎥' : '📁'}</div>`;
            
            let lien = item.url ? `<a href="${item.url}" target="_blank">▶ Ouvrir le lien</a>` : '';

            grid.innerHTML += `
                <div class="collection-item">
                    ${visuel}
                    <h4>${item.titre}</h4>
                    ${lien}
                    <button class="btn-supp" onclick="supprimerItem(${item.id})">Supprimer</button>
                </div>
            `;
        });
    }

    // Rangée Accueil
    if (maCollection.length === 0) {
        homeRow.innerHTML = '<p style="color:var(--text-dim); font-size:0.9rem; padding-left:5px;">Ajoute des médias pour les voir ici.</p>';
    } else {
        maCollection.slice(0, 5).forEach(item => {
            let visuel = item.type === 'image' && item.data 
                ? `<img src="${item.data}" class="card-img" style="object-fit:cover;">` 
                : `<div class="card-img bg-3">Média</div>`;
            homeRow.innerHTML += `
                <div class="media-card">
                    ${visuel}
                    <p>${item.titre}</p>
                </div>
            `;
        });
    }
}

// --- AJOUTER ---
document.getElementById('mediaForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const titre = document.getElementById('titre').value;
    const type = document.getElementById('type').value;
    const url = document.getElementById('mediaUrl').value;
    const file = document.getElementById('imageFile').files[0];

    const nouvelItem = { id: Date.now(), titre, type, url, data: null };

    if (file && type === 'image') {
        const reader = new FileReader();
        reader.onload = (evt) => {
            nouvelItem.data = evt.target.result;
            sauvegarderItem(nouvelItem);
        };
        reader.readAsDataURL(file);
    } else {
        sauvegarderItem(nouvelItem);
    }
});

function ajouterLien() {
    const nom = document.getElementById('lienNom').value;
    const url = document.getElementById('lienUrl').value;
    if(nom && url) {
        sauvegarderItem({ id: Date.now(), titre: nom, type: 'video', url: url, data: null });
        document.getElementById('lienNom').value = '';
        document.getElementById('lienUrl').value = '';
        alert("Lien ajouté dans ta Collection !");
    } else { alert("Remplis le nom et le lien."); }
}

function sauvegarderItem(item) {
    maCollection.push(item);
    storage.setItem('otakus_glass', JSON.stringify(maCollection));
    afficherCollection();
    fermerFormulaire();
}

function supprimerItem(id) {
    if(confirm("Supprimer définitivement ?")) {
        maCollection = maCollection.filter(i => i.id !== id);
        storage.setItem('otakus_glass', JSON.stringify(maCollection));
        afficherCollection();
    }
}

function filtrer(type, bouton) {
    document.querySelectorAll('.filtre-btn').forEach(btn => btn.classList.remove('active'));
    bouton.classList.add('active');
    afficherCollection(type);
}

// --- MODAL ---
function ouvrirFormulaire() { document.getElementById('modalForm').classList.remove('hidden'); }
function fermerFormulaire() { document.getElementById('modalForm').classList.add('hidden'); document.getElementById('mediaForm').reset(); }

// --- CHAT ---
function envoyerMessage() {
    const input = document.getElementById('chatMessage');
    const box = document.getElementById('chatBox');
    if(input.value.trim() !== "") {
        box.innerHTML += `<div style="background:var(--accent); color:white; padding:12px 15px; border-radius:15px 15px 0 15px; align-self:flex-end; max-width:80%; box-shadow: 0 4px 15px rgba(255,51,102,0.3);">${input.value}</div>`;
        input.value = '';
        box.scrollTop = box.scrollHeight;
    }
}

// --- THEME ---
document.getElementById('themeBtn').addEventListener('click', () => {
    document.body.classList.toggle('light');
    document.getElementById('themeBtn').textContent = document.body.classList.contains('light') ? '☀️' : '🌙';
});

// --- LANCEMENT ---
afficherCollection();
document.querySelector('.btn-flottant').style.display = 'none'; 
