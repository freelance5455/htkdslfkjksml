const SEEDS = [
  {id:'carrot',name:'Carrot',emoji:'🥕',seed:'🌱',rarity:'Common',cost:10,reward:10,grow:35,stock:8},
  {id:'tomato',name:'Tomato',emoji:'🍅',seed:'🍅',rarity:'Common',cost:16,reward:16,grow:55,stock:6},
  {id:'sunflower',name:'Sunflower',emoji:'🌻',seed:'🌻',rarity:'Uncommon',cost:1250,reward:1250,grow:75,stock:4},
  {id:'strawberry',name:'Strawberry',emoji:'🍓',seed:'🍓',rarity:'Common',cost:20,reward:20,grow:65,stock:5},
  {id:'tulip',name:'Tulip',emoji:'🌷',seed:'🌷',rarity:'Common',cost:14,reward:15,grow:48,stock:6},
  {id:'pumpkin',name:'Pumpkin',emoji:'🎃',seed:'🎃',rarity:'Uncommon',cost:1500,reward:1625,grow:90,stock:3},
  {id:'lettuce',name:'Lettuce',emoji:'🥬',seed:'🥬',rarity:'Common',cost:12,reward:13,grow:40,stock:7},
  {id:'radish',name:'Radish',emoji:'🫜',seed:'🫜',rarity:'Common',cost:14,reward:15,grow:44,stock:7},
  {id:'corn',name:'Corn',emoji:'🌽',seed:'🌽',rarity:'Uncommon',cost:1250,reward:1375,grow:68,stock:5},
  {id:'peas',name:'Peas',emoji:'🫛',seed:'🫛',rarity:'Uncommon',cost:1100,reward:1200,grow:60,stock:5},
  {id:'lavender',name:'Lavender',emoji:'🪻',seed:'🪻',rarity:'Uncommon',cost:1600,reward:1750,grow:76,stock:4},
  {id:'blueberry',name:'Blueberry',emoji:'🫐',seed:'🫐',rarity:'Rare',cost:140000,reward:160000,grow:88,stock:4},
  {id:'chili',name:'Chili Pepper',emoji:'🌶️',seed:'🌶️',rarity:'Rare',cost:130000,reward:145000,grow:82,stock:4},
  {id:'eggplant',name:'Eggplant',emoji:'🍆',seed:'🍆',rarity:'Rare',cost:160000,reward:180000,grow:94,stock:3},
  {id:'daisy',name:'Daisy',emoji:'🌼',seed:'🌼',rarity:'Rare',cost:144000,reward:165000,grow:86,stock:4},
  {id:'pineapple',name:'Pineapple',emoji:'🍍',seed:'🍍',rarity:'Epic',cost:3600000,reward:4200000,grow:108,stock:3},
  {id:'rose',name:'Rose',emoji:'🌹',seed:'🌹',rarity:'Epic',cost:4400000,reward:5000000,grow:115,stock:3},
  {id:'waterlily',name:'Water Lily',emoji:'🪷',seed:'🪷',rarity:'Epic',cost:4000000,reward:4600000,grow:110,stock:3},
  {id:'dragonfruit',name:'Dragon Fruit',emoji:'🐉',seed:'🐉',rarity:'Legendary',cost:104000000,reward:125000000,grow:132,stock:2},
  {id:'moonflower',name:'Moonflower',emoji:'🌙',seed:'🌙',rarity:'Legendary',cost:120000000,reward:145000000,grow:140,stock:2},
  {id:'bonsai',name:'Bonsai',emoji:'盆',seed:'🌳',rarity:'Legendary',cost:112000000,reward:135000000,grow:138,stock:2},
  {id:'ghost-orchid',name:'Ghost Orchid',emoji:'👻',seed:'👻',rarity:'Mythic',cost:2800000000,reward:3400000000,grow:158,stock:2},
  {id:'starfruit',name:'Starfruit',emoji:'⭐',seed:'⭐',rarity:'Mythic',cost:3100000000,reward:3800000000,grow:165,stock:2},
  {id:'golden-apple',name:'Golden Apple',emoji:'🍏',seed:'🍏',rarity:'Ancient',cost:38000000000,reward:47500000000,grow:185,stock:2},
  {id:'mandrake',name:'Mandrake',emoji:'🪴',seed:'🪴',rarity:'Ancient',cost:43000000000,reward:55000000000,grow:195,stock:2},
  {id:'cosmos',name:'Cosmos Bloom',emoji:'🌌',seed:'🌌',rarity:'Celestial',cost:240000000000,reward:300000000000,grow:220,stock:1},
  {id:'rainbow-bloom',name:'Rainbow Bloom',emoji:'🌈',seed:'🌈',rarity:'Prismatic',cost:1400000000000,reward:1800000000000,grow:250,stock:1},
  {id:'cucumber',name:'Cucumber',emoji:'🥒',seed:'🥒',rarity:'Common',cost:12,reward:13,grow:38,stock:7},
  {id:'onion',name:'Sweet Onion',emoji:'🧅',seed:'🧅',rarity:'Common',cost:14,reward:15,grow:43,stock:7},
  {id:'bell-pepper',name:'Bell Pepper',emoji:'🫑',seed:'🫑',rarity:'Common',cost:18,reward:19,grow:52,stock:6},
  {id:'garlic',name:'Garlic',emoji:'🧄',seed:'🧄',rarity:'Common',cost:16,reward:17,grow:48,stock:6},
  {id:'mint',name:'Mint',emoji:'🌿',seed:'🌿',rarity:'Uncommon',cost:1200,reward:1300,grow:62,stock:5},
  {id:'kiwi',name:'Kiwi',emoji:'🥝',seed:'🥝',rarity:'Uncommon',cost:1400,reward:1500,grow:70,stock:4},
  {id:'marigold',name:'Marigold',emoji:'🏵️',seed:'🏵️',rarity:'Uncommon',cost:1550,reward:1700,grow:74,stock:4},
  {id:'watercress',name:'Watercress',emoji:'🌱',seed:'🌱',rarity:'Uncommon',cost:1150,reward:1225,grow:59,stock:5},
  {id:'hibiscus',name:'Hibiscus',emoji:'🌺',seed:'🌺',rarity:'Rare',cost:136000,reward:155000,grow:84,stock:4},
  {id:'peony',name:'Peony',emoji:'🌸',seed:'🌸',rarity:'Rare',cost:156000,reward:175000,grow:92,stock:3},
  {id:'chrysanthemum',name:'Chrysanthemum',emoji:'💮',seed:'💮',rarity:'Rare',cost:148000,reward:168000,grow:89,stock:4},
  {id:'bluebell',name:'Bluebell',emoji:'🔔',seed:'🔔',rarity:'Rare',cost:164000,reward:185000,grow:96,stock:3},
  {id:'jasmine',name:'Jasmine',emoji:'🤍',seed:'🤍',rarity:'Epic',cost:3800000,reward:4400000,grow:109,stock:3},
  {id:'magnolia',name:'Magnolia',emoji:'🏵️',seed:'🏵️',rarity:'Epic',cost:4300000,reward:4900000,grow:117,stock:3},
  {id:'snapdragon',name:'Snapdragon',emoji:'🐲',seed:'🐲',rarity:'Epic',cost:4600000,reward:5250000,grow:120,stock:2},
  {id:'blue-orchid',name:'Blue Orchid',emoji:'💠',seed:'💠',rarity:'Epic',cost:4100000,reward:4750000,grow:113,stock:3},
  {id:'sapphire-bloom',name:'Sapphire Bloom',emoji:'🔷',seed:'🔷',rarity:'Legendary',cost:128000000,reward:155000000,grow:143,stock:2},
  {id:'ember-lily',name:'Ember Lily',emoji:'🔥',seed:'🔥',rarity:'Legendary',cost:136000000,reward:165000000,grow:148,stock:2},
  {id:'silver-vine',name:'Silver Vine',emoji:'🪙',seed:'🪙',rarity:'Legendary',cost:144000000,reward:178000000,grow:154,stock:2},
  {id:'crystal-rose',name:'Crystal Rose',emoji:'💎',seed:'💎',rarity:'Legendary',cost:140000000,reward:172000000,grow:151,stock:2},
  {id:'phoenix-flower',name:'Phoenix Flower',emoji:'🐦‍🔥',seed:'🐦‍🔥',rarity:'Mythic',cost:3500000000,reward:4300000000,grow:169,stock:2},
  {id:'stardust-fern',name:'Stardust Fern',emoji:'✨',seed:'✨',rarity:'Mythic',cost:3800000000,reward:4750000000,grow:174,stock:2},
  {id:'phantom-bellflower',name:'Phantom Bellflower',emoji:'👻',seed:'👻',rarity:'Mythic',cost:4100000000,reward:5100000000,grow:180,stock:2},
  {id:'dragon-bloom',name:'Dragon Bloom',emoji:'🐲',seed:'🐲',rarity:'Mythic',cost:3700000000,reward:4550000000,grow:172,stock:2},
  {id:'elderroot',name:'Elderroot',emoji:'🌳',seed:'🌳',rarity:'Ancient',cost:47000000000,reward:60000000000,grow:198,stock:2},
  {id:'amber-orchid',name:'Amber Orchid',emoji:'🟠',seed:'🟠',rarity:'Ancient',cost:50000000000,reward:65000000000,grow:203,stock:2},
  {id:'fossil-moss',name:'Fossil Moss',emoji:'🪨',seed:'🪨',rarity:'Ancient',cost:52000000000,reward:68750000000,grow:208,stock:2},
  {id:'primordial-fruit',name:'Primordial Fruit',emoji:'🍈',seed:'🍈',rarity:'Ancient',cost:55000000000,reward:72500000000,grow:215,stock:2},
  {id:'galaxy-orchid',name:'Galaxy Orchid',emoji:'🌌',seed:'🌌',rarity:'Celestial',cost:260000000000,reward:335000000000,grow:224,stock:1},
  {id:'comet-lily',name:'Comet Lily',emoji:'☄️',seed:'☄️',rarity:'Celestial',cost:276000000000,reward:365000000000,grow:230,stock:1},
  {id:'nebula-rose',name:'Nebula Rose',emoji:'🪐',seed:'🪐',rarity:'Celestial',cost:294000000000,reward:395000000000,grow:235,stock:1},
  {id:'starlight-vine',name:'Starlight Vine',emoji:'🌟',seed:'🌟',rarity:'Celestial',cost:310000000000,reward:420000000000,grow:240,stock:1},
  {id:'prism-poppy',name:'Prism Poppy',emoji:'🌈',seed:'🌈',rarity:'Prismatic',cost:1520000000000,reward:1960000000000,grow:255,stock:1},
  {id:'spectrum-fern',name:'Spectrum Fern',emoji:'🎨',seed:'🎨',rarity:'Prismatic',cost:1640000000000,reward:2160000000000,grow:262,stock:1},
  {id:'aurora-orchid',name:'Aurora Orchid',emoji:'🦚',seed:'🦚',rarity:'Prismatic',cost:1760000000000,reward:2360000000000,grow:270,stock:1},
  {id:'infinity-bloom',name:'Infinity Bloom',emoji:'♾️',seed:'♾️',rarity:'Prismatic',cost:1880000000000,reward:2600000000000,grow:280,stock:1},
  {id:'starlit-seed',name:'Starlit Seed',emoji:'🌠',seed:'✨',rarity:'Limited',cost:500_000_000_000_000,reward:575_000_000_000_000,grow:310,stock:2,limited:true},
  {id:'moonberry',name:'Moonberry',emoji:'🌙',seed:'🌙',rarity:'Limited',cost:500_000_000_000_000,reward:600_000_000_000_000,grow:320,stock:2,limited:true},
  {id:'rainbow-orchid',name:'Rainbow Orchid',emoji:'🌈',seed:'🌈',rarity:'Limited',cost:500_000_000_000_000,reward:625_000_000_000_000,grow:330,stock:2,limited:true},
  {id:'astral-berry',name:'Astral Berry',emoji:'🪐',seed:'🪐',rarity:'Astral',cost:1_000_000_000_000_000,reward:1_200_000_000_000_000,grow:290,stock:3},
  {id:'stardew-tulip',name:'Stardew Tulip',emoji:'🌠',seed:'🌠',rarity:'Astral',cost:2_000_000_000_000_000,reward:2_400_000_000_000_000,grow:300,stock:3},
  {id:'comet-cactus',name:'Comet Cactus',emoji:'🌵',seed:'🌵',rarity:'Astral',cost:3_000_000_000_000_000,reward:3_600_000_000_000_000,grow:310,stock:2},
  {id:'nebula-melon',name:'Nebula Melon',emoji:'🍈',seed:'🍈',rarity:'Astral',cost:5_000_000_000_000_000,reward:6_000_000_000_000_000,grow:320,stock:2},
  {id:'seraphic-rose',name:'Seraphic Rose',emoji:'🌹',seed:'🌹',rarity:'Divine',cost:1_000_000_000_000_000_000,reward:1_250_000_000_000_000_000,grow:325,stock:3},
  {id:'halo-lily',name:'Halo Lily',emoji:'🪽',seed:'🪽',rarity:'Divine',cost:2_000_000_000_000_000_000,reward:2_500_000_000_000_000_000,grow:335,stock:2},
  {id:'heavenly-peony',name:'Heavenly Peony',emoji:'💐',seed:'💐',rarity:'Divine',cost:3_000_000_000_000_000_000,reward:3_750_000_000_000_000_000,grow:345,stock:2},
  {id:'cherub-fruit',name:'Cherub Fruit',emoji:'🍑',seed:'🍑',rarity:'Divine',cost:5_000_000_000_000_000_000,reward:6_250_000_000_000_000_000,grow:355,stock:2},
  {id:'timebloom',name:'Timebloom',emoji:'⏳',seed:'⏳',rarity:'Transcendent',cost:1_000_000_000_000_000_000_000_000,reward:1_300_000_000_000_000_000_000_000,grow:360,stock:2},
  {id:'dream-orchid',name:'Dream Orchid',emoji:'💭',seed:'💭',rarity:'Transcendent',cost:2_000_000_000_000_000_000_000_000,reward:2_600_000_000_000_000_000_000_000,grow:370,stock:2},
  {id:'crystal-cosmos',name:'Crystal Cosmos',emoji:'🔮',seed:'🔮',rarity:'Transcendent',cost:3_000_000_000_000_000_000_000_000,reward:3_900_000_000_000_000_000_000_000,grow:380,stock:2},
  {id:'void-lotus',name:'Void Lotus',emoji:'🪷',seed:'🪷',rarity:'Transcendent',cost:5_000_000_000_000_000_000_000_000,reward:6_500_000_000_000_000_000_000_000,grow:390,stock:1},
  {id:'multiverse-mango',name:'Multiverse Mango',emoji:'🥭',seed:'🥭',rarity:'Omniversal',cost:1_000_000_000_000_000_000_000_000_000_000,reward:1_350_000_000_000_000_000_000_000_000_000,grow:395,stock:2},
  {id:'eternal-fern',name:'Eternal Fern',emoji:'🌿',seed:'🌿',rarity:'Omniversal',cost:2_000_000_000_000_000_000_000_000_000_000,reward:2_700_000_000_000_000_000_000_000_000_000,grow:405,stock:2},
  {id:'reality-root',name:'Reality Root',emoji:'🌳',seed:'🌳',rarity:'Omniversal',cost:3_000_000_000_000_000_000_000_000_000_000,reward:4_050_000_000_000_000_000_000_000_000_000,grow:415,stock:1},
  {id:'cosmic-apple',name:'Cosmic Apple',emoji:'🍎',seed:'🍎',rarity:'Omniversal',cost:5_000_000_000_000_000_000_000_000_000_000,reward:6_750_000_000_000_000_000_000_000_000_000,grow:425,stock:1},
  {id:'infinite-orchid',name:'Infinite Orchid',emoji:'♾️',seed:'♾️',rarity:'Infinite',cost:2.5e38,reward:3e38,grow:430,stock:1},
  {id:'endless-sunfruit',name:'Endless Sunfruit',emoji:'🌞',seed:'🌞',rarity:'Infinite',cost:5e38,reward:6e38,grow:440,stock:1},
  {id:'boundless-bloom',name:'Boundless Bloom',emoji:'🌺',seed:'🌺',rarity:'Infinite',cost:7.5e38,reward:9e38,grow:450,stock:1},
  {id:'omega-seed',name:'Omega Seed',emoji:'Ω',seed:'Ω',rarity:'Infinite',cost:1e39,reward:1.2e39,grow:460,stock:1},
  {id:'chive',name:'Chive Sprout',emoji:'🌱',seed:'🌱',rarity:'Common',cost:2e39,reward:2.333e39,grow:50,stock:7},
  {id:'pink-radish',name:'Pink Radish',emoji:'🫜',seed:'🫜',rarity:'Common',cost:3.471e39,reward:4.005e39,grow:57,stock:6},
  {id:'sugar-snap-pea',name:'Sugar Snap Pea',emoji:'🫛',seed:'🫛',rarity:'Common',cost:6.023e39,reward:7.313e39,grow:64,stock:7},
  {id:'golden-beet',name:'Golden Beet',emoji:'🟠',seed:'🟠',rarity:'Common',cost:1.045e40,reward:1.254e40,grow:71,stock:6},
  {id:'basil-bush',name:'Basil Bush',emoji:'🌿',seed:'🌿',rarity:'Common',cost:1.814e40,reward:2.027e40,grow:78,stock:7},
  {id:'baby-turnip',name:'Baby Turnip',emoji:'🥬',seed:'🥬',rarity:'Common',cost:3.147e40,reward:3.672e40,grow:85,stock:6},
  {id:'blue-carrot',name:'Blue Carrot',emoji:'🥕',seed:'🥕',rarity:'Common',cost:5.462e40,reward:6.324e40,grow:92,stock:7},
  {id:'honey-clover',name:'Honey Clover',emoji:'🍀',seed:'🍀',rarity:'Uncommon',cost:9.478e40,reward:1.118e41,grow:75,stock:5},
  {id:'cinnamon-basil',name:'Cinnamon Basil',emoji:'🌿',seed:'🌿',rarity:'Uncommon',cost:1.645e41,reward:1.94e41,grow:82,stock:4},
  {id:'lemon-balm',name:'Lemon Balm',emoji:'🍋',seed:'🍋',rarity:'Uncommon',cost:2.854e41,reward:3.367e41,grow:89,stock:5},
  {id:'dewdrop-dill',name:'Dewdrop Dill',emoji:'💧',seed:'💧',rarity:'Uncommon',cost:4.953e41,reward:5.842e41,grow:96,stock:4},
  {id:'cloverbell',name:'Cloverbell',emoji:'🪻',seed:'🪻',rarity:'Uncommon',cost:8.595e41,reward:1.014e42,grow:103,stock:5},
  {id:'peach-thyme',name:'Peach Thyme',emoji:'🍑',seed:'🍑',rarity:'Uncommon',cost:1.492e42,reward:1.76e42,grow:110,stock:4},
  {id:'amber-sage',name:'Amber Sage',emoji:'🌿',seed:'🌿',rarity:'Uncommon',cost:2.588e42,reward:3.054e42,grow:117,stock:5},
  {id:'frosted-pansy',name:'Frosted Pansy',emoji:'🌸',seed:'🌸',rarity:'Rare',cost:4.492e42,reward:5.39e42,grow:95,stock:4},
  {id:'coral-dahlia',name:'Coral Dahlia',emoji:'🌺',seed:'🌺',rarity:'Rare',cost:7.794e42,reward:9.353e42,grow:102,stock:3},
  {id:'velvet-iris',name:'Velvet Iris',emoji:'🪻',seed:'🪻',rarity:'Rare',cost:1.353e43,reward:1.623e43,grow:109,stock:4},
  {id:'silver-thyme',name:'Silver Thyme',emoji:'🌿',seed:'🌿',rarity:'Rare',cost:2.347e43,reward:2.817e43,grow:116,stock:3},
  {id:'cranberry-fern',name:'Cranberry Fern',emoji:'🍒',seed:'🍒',rarity:'Rare',cost:4.073e43,reward:4.888e43,grow:123,stock:4},
  {id:'twilight-poppy',name:'Twilight Poppy',emoji:'🌷',seed:'🌷',rarity:'Rare',cost:7.068e43,reward:8.482e43,grow:130,stock:3},
  {id:'glacier-bluebell',name:'Glacier Bluebell',emoji:'🔔',seed:'🔔',rarity:'Rare',cost:1.227e44,reward:1.472e44,grow:137,stock:4},
  {id:'sunset-snapdragon',name:'Sunset Snapdragon',emoji:'🐲',seed:'🐲',rarity:'Epic',cost:2.129e44,reward:2.554e44,grow:120,stock:3},
  {id:'glimmering-lotus',name:'Glimmering Lotus',emoji:'🪷',seed:'🪷',rarity:'Epic',cost:3.694e44,reward:4.433e44,grow:127,stock:2},
  {id:'opal-marigold',name:'Opal Marigold',emoji:'🏵️',seed:'🏵️',rarity:'Epic',cost:6.41e44,reward:7.692e44,grow:134,stock:3},
  {id:'velvet-camellia',name:'Velvet Camellia',emoji:'🌺',seed:'🌺',rarity:'Epic',cost:1.112e45,reward:1.335e45,grow:141,stock:2},
  {id:'crown-lily',name:'Crown Lily',emoji:'👑',seed:'👑',rarity:'Epic',cost:1.93e45,reward:2.316e45,grow:148,stock:3},
  {id:'firefly-hibiscus',name:'Firefly Hibiscus',emoji:'🌺',seed:'🌺',rarity:'Epic',cost:3.35e45,reward:4.02e45,grow:155,stock:2},
  {id:'pearl-peony',name:'Pearl Peony',emoji:'🌸',seed:'🌸',rarity:'Epic',cost:5.813e45,reward:6.975e45,grow:162,stock:3},
  {id:'solar-lotus',name:'Solar Lotus',emoji:'🪷',seed:'🪷',rarity:'Legendary',cost:1.009e46,reward:1.231e46,grow:150,stock:2},
  {id:'gilded-magnolia',name:'Gilded Magnolia',emoji:'🏵️',seed:'🏵️',rarity:'Legendary',cost:1.75e46,reward:2.136e46,grow:157,stock:1},
  {id:'thunder-orchid',name:'Thunder Orchid',emoji:'💠',seed:'💠',rarity:'Legendary',cost:3.038e46,reward:3.706e46,grow:164,stock:2},
  {id:'ruby-wisteria',name:'Ruby Wisteria',emoji:'🌺',seed:'🌺',rarity:'Legendary',cost:5.271e46,reward:6.431e46,grow:171,stock:1},
  {id:'cinder-tulip',name:'Cinder Tulip',emoji:'🌷',seed:'🌷',rarity:'Legendary',cost:9.148e46,reward:1.116e47,grow:178,stock:2},
  {id:'stormglass-rose',name:'Stormglass Rose',emoji:'🌹',seed:'🌹',rarity:'Legendary',cost:1.587e47,reward:1.937e47,grow:185,stock:1},
  {id:'dawnfire-bloom',name:'Dawnfire Bloom',emoji:'🌼',seed:'🌼',rarity:'Legendary',cost:2.755e47,reward:3.361e47,grow:192,stock:2},
  {id:'eclipse-bellflower',name:'Eclipse Bellflower',emoji:'🔔',seed:'🔔',rarity:'Mythic',cost:4.78e47,reward:5.88e47,grow:175,stock:2},
  {id:'wyrmroot',name:'Wyrmroot',emoji:'🌳',seed:'🌳',rarity:'Mythic',cost:8.295e47,reward:1.02e48,grow:182,stock:1},
  {id:'phantom-dahlia',name:'Phantom Dahlia',emoji:'🌸',seed:'🌸',rarity:'Mythic',cost:1.44e48,reward:1.771e48,grow:189,stock:2},
  {id:'starforge-fern',name:'Starforge Fern',emoji:'🌿',seed:'🌿',rarity:'Mythic',cost:2.498e48,reward:3.073e48,grow:196,stock:1},
  {id:'ashen-moonflower',name:'Ashen Moonflower',emoji:'🌙',seed:'🌙',rarity:'Mythic',cost:4.335e48,reward:5.332e48,grow:203,stock:2},
  {id:'whispering-yew',name:'Whispering Yew',emoji:'🌲',seed:'🌲',rarity:'Mythic',cost:7.523e48,reward:9.253e48,grow:210,stock:1},
  {id:'nightfire-poppy',name:'Nightfire Poppy',emoji:'🌺',seed:'🌺',rarity:'Mythic',cost:1.305e49,reward:1.606e49,grow:217,stock:2},
  {id:'amberwood-tree',name:'Amberwood Tree',emoji:'🌳',seed:'🌳',rarity:'Ancient',cost:2.265e49,reward:2.809e49,grow:205,stock:2},
  {id:'fossil-orchid',name:'Fossil Orchid',emoji:'🪷',seed:'🪷',rarity:'Ancient',cost:3.931e49,reward:4.875e49,grow:212,stock:1},
  {id:'titans-pomegranate',name:'Titan Pomegranate',emoji:'🍎',seed:'🍎',rarity:'Ancient',cost:6.822e49,reward:8.459e49,grow:219,stock:2},
  {id:'elderbloom-mushroom',name:'Elderbloom Mushroom',emoji:'🍄',seed:'🍄',rarity:'Ancient',cost:1.184e50,reward:1.468e50,grow:226,stock:1},
  {id:'primordial-lotus',name:'Primordial Lotus',emoji:'🪷',seed:'🪷',rarity:'Ancient',cost:2.054e50,reward:2.547e50,grow:233,stock:2},
  {id:'suncore-fruit',name:'Suncore Fruit',emoji:'🍊',seed:'🍊',rarity:'Ancient',cost:3.565e50,reward:4.421e50,grow:240,stock:1},
  {id:'stoneheart-succulent',name:'Stoneheart Succulent',emoji:'🪴',seed:'🪴',rarity:'Ancient',cost:6.186e50,reward:7.671e50,grow:247,stock:2},
  {id:'pulsar-blossom',name:'Pulsar Blossom',emoji:'✨',seed:'✨',rarity:'Celestial',cost:1.074e51,reward:1.342e51,grow:230,stock:1},
  {id:'lunar-crown',name:'Lunar Crown',emoji:'🌙',seed:'🌙',rarity:'Celestial',cost:1.863e51,reward:2.329e51,grow:237,stock:1},
  {id:'solaris-lily',name:'Solaris Lily',emoji:'🌼',seed:'🌼',rarity:'Celestial',cost:3.233e51,reward:4.041e51,grow:244,stock:1},
  {id:'quasar-fruit',name:'Quasar Fruit',emoji:'🪐',seed:'🪐',rarity:'Celestial',cost:5.61e51,reward:7.013e51,grow:251,stock:1},
  {id:'andromeda-vine',name:'Andromeda Vine',emoji:'🌌',seed:'🌌',rarity:'Celestial',cost:9.735e51,reward:1.217e52,grow:258,stock:1},
  {id:'stellar-chrysanthemum',name:'Stellar Chrysanthemum',emoji:'💮',seed:'💮',rarity:'Celestial',cost:1.689e52,reward:2.112e52,grow:265,stock:1},
  {id:'aurora-flame-lily',name:'Aurora Flame Lily',emoji:'🔥',seed:'🔥',rarity:'Celestial',cost:2.932e52,reward:3.665e52,grow:272,stock:1},
  {id:'kaleidoscope-iris',name:'Kaleidoscope Iris',emoji:'🌈',seed:'🌈',rarity:'Prismatic',cost:5.088e52,reward:6.512e52,grow:260,stock:1},
  {id:'chromatic-lotus',name:'Chromatic Lotus',emoji:'🪷',seed:'🪷',rarity:'Prismatic',cost:8.829e52,reward:1.13e53,grow:267,stock:1},
  {id:'spectrum-starfruit',name:'Spectrum Starfruit',emoji:'⭐',seed:'⭐',rarity:'Prismatic',cost:1.532e53,reward:1.961e53,grow:274,stock:1},
  {id:'opaline-rainbow-rose',name:'Opaline Rainbow Rose',emoji:'🌈',seed:'🌈',rarity:'Prismatic',cost:2.659e53,reward:3.403e53,grow:281,stock:1},
  {id:'prismfire-orchid',name:'Prismfire Orchid',emoji:'🦚',seed:'🦚',rarity:'Prismatic',cost:4.614e53,reward:5.905e53,grow:288,stock:1},
  {id:'mirage-poppy',name:'Mirage Poppy',emoji:'🌷',seed:'🌷',rarity:'Prismatic',cost:8.006e53,reward:1.025e54,grow:295,stock:1},
  {id:'iridescent-sunseed',name:'Iridescent Sunseed',emoji:'🌞',seed:'🌞',rarity:'Prismatic',cost:1.389e54,reward:1.778e54,grow:302,stock:1},
  {id:'snowglobe-camellia',name:'Snowglobe Camellia',emoji:'❄️',seed:'❄️',rarity:'Limited',cost:2.411e54,reward:3.014e54,grow:320,stock:1,limited:true},
  {id:'frostmoon-berry',name:'Frostmoon Berry',emoji:'🫐',seed:'🫐',rarity:'Limited',cost:4.184e54,reward:5.23e54,grow:327,stock:1,limited:true},
  {id:'jinglebell-jasmine',name:'Jinglebell Jasmine',emoji:'🔔',seed:'🔔',rarity:'Limited',cost:7.26e54,reward:9.075e54,grow:334,stock:1,limited:true},
  {id:'winter-solstice-rose',name:'Winter Solstice Rose',emoji:'🥀',seed:'🥀',rarity:'Limited',cost:1.26e55,reward:1.575e55,grow:341,stock:1,limited:true},
  {id:'aurora-giftbud',name:'Aurora Giftbud',emoji:'🎁',seed:'🎁',rarity:'Limited',cost:2.186e55,reward:2.733e55,grow:348,stock:1,limited:true},
  {id:'sugarplum-orchid',name:'Sugarplum Orchid',emoji:'🍬',seed:'🍬',rarity:'Limited',cost:3.794e55,reward:4.743e55,grow:355,stock:1,limited:true},
  {id:'comet-cocoa-pod',name:'Comet Cocoa Pod',emoji:'☕',seed:'☕',rarity:'Limited',cost:6.584e55,reward:8.23e55,grow:362,stock:1,limited:true},
  {id:'astral-lotus',name:'Astral Lotus',emoji:'🪷',seed:'🪷',rarity:'Astral',cost:1.143e56,reward:1.428e56,grow:300,stock:2},
  {id:'supernova-sunflower',name:'Supernova Sunflower',emoji:'🌻',seed:'🌻',rarity:'Astral',cost:1.983e56,reward:2.479e56,grow:307,stock:1},
  {id:'moonquake-berry',name:'Moonquake Berry',emoji:'🌙',seed:'🌙',rarity:'Astral',cost:3.441e56,reward:4.302e56,grow:314,stock:2},
  {id:'pulsar-pear',name:'Pulsar Pear',emoji:'🍐',seed:'🍐',rarity:'Astral',cost:5.971e56,reward:7.462e56,grow:321,stock:1},
  {id:'orbiting-orchid',name:'Orbiting Orchid',emoji:'🌺',seed:'🌺',rarity:'Astral',cost:1.036e57,reward:1.295e57,grow:328,stock:2},
  {id:'startrail-melon',name:'Startrail Melon',emoji:'🍈',seed:'🍈',rarity:'Astral',cost:1.798e57,reward:2.248e57,grow:335,stock:1},
  {id:'empyrean-bloom',name:'Empyrean Bloom',emoji:'💐',seed:'💐',rarity:'Divine',cost:3.12e57,reward:3.9e57,grow:330,stock:2},
  {id:'gracewing-lily',name:'Gracewing Lily',emoji:'🪽',seed:'🪽',rarity:'Divine',cost:5.415e57,reward:6.769e57,grow:337,stock:1},
  {id:'seraphim-crown',name:'Seraphim Crown',emoji:'👑',seed:'👑',rarity:'Divine',cost:9.396e57,reward:1.175e58,grow:344,stock:2},
  {id:'celestial-nectar',name:'Celestial Nectar',emoji:'🍯',seed:'🍯',rarity:'Divine',cost:1.631e58,reward:2.038e58,grow:351,stock:1},
  {id:'dawn-halo-rose',name:'Dawn Halo Rose',emoji:'🌹',seed:'🌹',rarity:'Divine',cost:2.83e58,reward:3.537e58,grow:358,stock:2},
  {id:'blessed-magnolia',name:'Blessed Magnolia',emoji:'🏵️',seed:'🏵️',rarity:'Divine',cost:4.91e58,reward:6.139e58,grow:365,stock:1},
  {id:'eonflower',name:'Eonflower',emoji:'⏳',seed:'⏳',rarity:'Transcendent',cost:8.521e58,reward:1.108e59,grow:370,stock:2},
  {id:'dreamweavers-bloom',name:'Dreamweavers Bloom',emoji:'🪷',seed:'🪷',rarity:'Transcendent',cost:1.479e59,reward:1.922e59,grow:377,stock:1},
  {id:'evernow-orchid',name:'Evernow Orchid',emoji:'💭',seed:'💭',rarity:'Transcendent',cost:2.566e59,reward:3.336e59,grow:384,stock:2},
  {id:'chrono-lily',name:'Chrono Lily',emoji:'⏲️',seed:'⏲️',rarity:'Transcendent',cost:4.453e59,reward:5.79e59,grow:391,stock:1},
  {id:'paradox-peony',name:'Paradox Peony',emoji:'🌀',seed:'🌀',rarity:'Transcendent',cost:7.727e59,reward:1.005e60,grow:398,stock:2},
  {id:'afterlight-lotus',name:'Afterlight Lotus',emoji:'🌅',seed:'🌅',rarity:'Transcendent',cost:1.341e60,reward:1.743e60,grow:405,stock:1},
  {id:'omniverse-orchid',name:'Omniverse Orchid',emoji:'🪐',seed:'🪐',rarity:'Omniversal',cost:2.327e60,reward:3.141e60,grow:410,stock:1},
  {id:'reality-weavers-bloom',name:'Reality Weavers Bloom',emoji:'🌌',seed:'🌌',rarity:'Omniversal',cost:4.038e60,reward:5.45e60,grow:417,stock:1},
  {id:'infinite-worlds-fruit',name:'Infinite Worlds Fruit',emoji:'🌎',seed:'🌎',rarity:'Omniversal',cost:7.007e60,reward:9.463e60,grow:424,stock:1},
  {id:'worldtree-blossom',name:'Worldtree Blossom',emoji:'🌳',seed:'🌳',rarity:'Omniversal',cost:1.216e61,reward:1.642e61,grow:431,stock:1},
  {id:'cosmic-gate-seed',name:'Cosmic Gate Seed',emoji:'🌀',seed:'🌀',rarity:'Omniversal',cost:2.11e61,reward:2.849e61,grow:438,stock:1},
  {id:'manyworlds-mango',name:'Manyworlds Mango',emoji:'🥭',seed:'🥭',rarity:'Omniversal',cost:3.662e61,reward:4.943e61,grow:445,stock:1},
  {id:'infinity-fern',name:'Infinity Fern',emoji:'♾️',seed:'♾️',rarity:'Infinite',cost:6.355e61,reward:7.625e61,grow:440,stock:1},
  {id:'eternal-sunflower',name:'Eternal Sunflower',emoji:'🌞',seed:'🌞',rarity:'Infinite',cost:1.103e62,reward:1.323e62,grow:447,stock:1},
  {id:'boundless-lotus',name:'Boundless Lotus',emoji:'🪷',seed:'🪷',rarity:'Infinite',cost:1.914e62,reward:2.297e62,grow:454,stock:1},
  {id:'omega-blossom',name:'Omega Blossom',emoji:'Ω',seed:'Ω',rarity:'Infinite',cost:3.321e62,reward:3.984e62,grow:461,stock:1},
  {id:'limitless-berry',name:'Limitless Berry',emoji:'🔵',seed:'🔵',rarity:'Infinite',cost:5.763e62,reward:6.914e62,grow:468,stock:1},
  {id:'endless-cosmos',name:'Endless Cosmos',emoji:'🌌',seed:'🌌',rarity:'Infinite',cost:1e63,reward:1.2e63,grow:475,stock:1}
];
const COSMETICS = [
  {id:'petal-path',name:'Petal Path',emoji:'🌸',rarity:'Common',cost:250,stock:3,description:'Soft pink garden edging'},
  {id:'mossy-magic',name:'Mossy Magic',emoji:'🍀',rarity:'Uncommon',cost:1200,stock:3,description:'A lush green glow'},
  {id:'moonlit-dew',name:'Moonlit Dew',emoji:'🌙',rarity:'Rare',cost:6500,stock:2,description:'A quiet silver shimmer'},
  {id:'firefly-dance',name:'Firefly Dance',emoji:'✨',rarity:'Epic',cost:28000,stock:2,description:'Golden lights at dusk'},
  {id:'rainbow-ribbon',name:'Rainbow Ribbon',emoji:'🌈',rarity:'Legendary',cost:120000,stock:1,description:'Prismatic garden trim'}
];
const GEARS = [
  {id:"watering-can",name:"Copper Watering Can",emoji:"🪣",rarity:"Common",cost:40,stock:6},
  {id:"hand-trowel",name:"Hand Trowel",emoji:"🪴",rarity:"Common",cost:65,stock:5},
  {id:"garden-gloves",name:"Garden Gloves",emoji:"🧤",rarity:"Common",cost:100,stock:5},
  {id:"pruning-shears",name:"Pruning Shears",emoji:"✂️",rarity:"Uncommon",cost:500,stock:4},
  {id:"compost-bag",name:"Rich Compost",emoji:"🪱",rarity:"Uncommon",cost:900,stock:4},
  {id:"sun-hat",name:"Sun Hat",emoji:"👒",rarity:"Rare",cost:2400,stock:3},
  {id:"rain-boots",name:"Rain Boots",emoji:"🥾",rarity:"Rare",cost:7500,stock:3},
  {id:"glass-cloche",name:"Glass Cloche",emoji:"🔔",rarity:"Epic",cost:50000,stock:2},
  {id:"moon-lantern",name:"Moon Lantern",emoji:"🏮",rarity:"Legendary",cost:180000,stock:2},
  {id:"garden-sprinkler",name:"Garden Sprinkler",emoji:"🚿",rarity:"Uncommon",cost:1250,stock:4},
  {id:"copper-sprinkler",name:"Copper Sprinkler",emoji:"💦",rarity:"Rare",cost:8000,stock:3},
  {id:"rainbow-sprinkler",name:"Rainbow Sprinkler",emoji:"🌈",rarity:"Epic",cost:80000,stock:2},
  {id:"garden-divider",name:"Garden Divider",emoji:"🪵",rarity:"Uncommon",cost:450,stock:3}
];
const GEAR_EFFECTS = {
  "watering-can":{text:"8% faster growth per copy · max 3",growth:.08},
  "hand-trowel":{text:"5% faster growth per copy · max 3",growth:.05},
  "garden-gloves":{text:"+10% harvest coins per copy · max 3",harvest:.10},
  "pruning-shears":{text:"+15% harvest coins per copy · max 3",harvest:.15},
  "compost-bag":{text:"12% faster growth per copy · max 3",growth:.12},
  "sun-hat":{text:"+5% harvest coins per copy · max 3",harvest:.05},
  "rain-boots":{text:"+10% mutation chance per copy · max 3",mutation:.10},
  "glass-cloche":{text:"15% faster growth per copy · max 3",growth:.15},
  "moon-lantern":{text:"+20% harvest coins per copy · max 3",harvest:.20},
  "garden-sprinkler":{text:"10% faster growth per copy · max 3",growth:.10},
  "copper-sprinkler":{text:"18% faster growth per copy · max 3",growth:.18},
  "rainbow-sprinkler":{text:"25% faster growth per copy · max 3",growth:.25},
  "garden-divider":{text:"Adds crosswise lines to organize beds into four sections"}
};
const RESTOCK_MS = 5 * 60 * 1000;
const COSMETIC_RESTOCK_MS = 20 * 60 * 1000;
const LIMITED_SEEDS_UNTIL = Date.UTC(2026,10,23,17,30,34,125);
const LIMITED_SEED_IDS = new Set(['starlit-seed','moonberry','rainbow-orchid','snowglobe-camellia','frostmoon-berry','jinglebell-jasmine','winter-solstice-rose','aurora-giftbud','sugarplum-orchid','comet-cocoa-pod']);
const MAX_PLOT_EXPANSIONS = 5;
const RARITY_GROW_MS = {Common:45000,Uncommon:180000,Rare:720000,Epic:1800000,Legendary:3600000,Mythic:7200000,Ancient:14400000,Celestial:21600000,Prismatic:28800000,Limited:36000000,Astral:43200000,Divine:54000000,Transcendent:64800000,Omniversal:75600000,Infinite:86400000};
const WEATHER_INTERVAL = 30 * 1000;
const WEATHER_DURATION = 20 * 1000;
const WEATHER_RUN_CHANCE = 0.30;
const MUTATION_CHANCE = 0.50;
const WEATHER_EVENTS = [
  {name:'Aurora Rain',icon:'🌌',mutation:'Aurora-Kissed'},
  {name:'Starfall Shower',icon:'☄️',mutation:'Starstruck'},
  {name:'Moonbow Mist',icon:'🌈',mutation:'Moonbow-Touched'},
  {name:'Meteor Pollen',icon:'✨',mutation:'Meteor-Dusted'},
  {name:'Comet Winds',icon:'💫',mutation:'Comet-Tailed'},
  {name:'Crystal Hail',icon:'💎',mutation:'Crystalized'},
  {name:'Solar Flare',icon:'☀️',mutation:'Sunflare'},
  {name:'Nebula Drizzle',icon:'🪐',mutation:'Nebulized'},
  {name:'Void Eclipse',icon:'🌑',mutation:'Void-Touched'},
  {name:'Rainbow Monsoon',icon:'🌦️',mutation:'Chromatic'},
  {name:'Firefly Blizzard',icon:'🪲',mutation:'Firefly-Glow'},
  {name:'Frostfire Snow',icon:'🔥',mutation:'Frostfire'},
  {name:'Singing Thunder',icon:'⚡',mutation:'Thunderstruck'},
  {name:'Jade Fog',icon:'🍃',mutation:'Jade-Veiled'},
  {name:'Mushroom Moonfall',icon:'🍄',mutation:'Fungal-Moonlit'},
  {name:'Cosmic Dew',icon:'🌠',mutation:'Cosmic-Dewed'},
  {name:'Glasswing Gale',icon:'🦋',mutation:'Glasswing'},
  {name:'Dreamseed Storm',icon:'💖',mutation:'Dreamseed'},
  {name:'Tidal Skyfall',icon:'🌊',mutation:'Tide-Touched'},
  {name:'Pink Comet Bloom',icon:'🌸',mutation:'Comet-Bloom'},
  {name:'Emerald Aurora',icon:'💚',mutation:'Emerald-Touched'},
  {name:'Amber Rain',icon:'🟠',mutation:'Amber-Dusted'},
  {name:'Silverwind Bloom',icon:'🪙',mutation:'Silver-Kissed'},
  {name:'Petal Cyclone',icon:'🌺',mutation:'Petal-Swept'},
  {name:'Honeydew Haze',icon:'🍈',mutation:'Honeydew-Glazed'},
  {name:'Thunder Blossom',icon:'🌩️',mutation:'Thunder-Bloomed'},
  {name:'Crystal Aurora',icon:'🔮',mutation:'Crystal-Kissed'},
  {name:'Sapphire Rain',icon:'🔷',mutation:'Sapphire-Drenched'},
  {name:'Cinderfall',icon:'🌋',mutation:'Cinder-Dusted'},
  {name:'Cloudberry Shower',icon:'☁️',mutation:'Cloudberry-Touched'},
  {name:'Prismatic Gale',icon:'🎨',mutation:'Prism-Swept'},
  {name:'Lavender Mist',icon:'🪻',mutation:'Lavender-Kissed'},
  {name:'Gilded Sunshower',icon:'🌦️',mutation:'Gilded'},
  {name:'Frostpetal Flurry',icon:'❄️',mutation:'Frostpetal'},
  {name:'Mothlight Night',icon:'🦋',mutation:'Mothlit'},
  {name:'Echoing Rain',icon:'🌧️',mutation:'Echo-Touched'},
  {name:'Verdant Comet',icon:'☄️',mutation:'Verdant-Tailed'},
  {name:'Orchid Tempest',icon:'🌪️',mutation:'Orchid-Stormed'},
  {name:'Glittering Tide',icon:'🌊',mutation:'Glitter-Drenched'},
  {name:'Dewdrop Parade',icon:'💧',mutation:'Dewdrop-Kissed'},
  {name:'Wildflower Whirl',icon:'🌼',mutation:'Wildflower-Swept'},
  {name:'Pearl Fog',icon:'🫧',mutation:'Pearl-Veiled'},
  {name:'Citrine Hail',icon:'🟡',mutation:'Citrine-Speckled'},
  {name:'Starlight Monsoon',icon:'🌠',mutation:'Starlit'},
  {name:'Rosegold Breeze',icon:'🌹',mutation:'Rosegold-Kissed'},
  {name:'Mosslight Drizzle',icon:'🌿',mutation:'Mosslit'},
  {name:'Firework Bloom',icon:'🎆',mutation:'Firework-Glowing'},
  {name:'Velvet Moonrise',icon:'🌙',mutation:'Velvet-Moonlit'},
  {name:'Dragonfly Squall',icon:'🦟',mutation:'Dragonfly-Winged'},
  {name:'Rainbow Petalfall',icon:'🌈',mutation:'Rainbow-Petaled'}
];
const $ = (s) => document.querySelector(s);
let state = loadState();
const freshGarden = !state.savedAt;
const PLOT_STYLES = new Set(['earth','moss','rose','moon']);
let selected = null;
let lockToolActive = false;
let instantGrowToolActive = false;
let toastTimer;
let activeWeather = [];
let activeWeatherUntil = 0;
let liveRoom = null;
let nextWeatherCheck = Date.now() + WEATHER_INTERVAL;
let limitedSeedSaleActive = Date.now() < LIMITED_SEEDS_UNTIL;

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem('little-garden-save'));
    if (saved && Array.isArray(saved.beds) && saved.beds.length >= 16 && saved.beds.length <= 256) return saved;
    if (saved && Array.isArray(saved.beds) && saved.beds.length === 4) {
      const beds=Array(16).fill(null);
      saved.beds.forEach((bed,section)=>{beds[Math.floor(section/2)*8+(section%2)*2]=bed;});
      return {...saved,beds};
    }
  } catch {}
  return {coins:24,inventory:{},beds:Array(16).fill(null),stock:null,restockAt:0,cosmeticInventory:[],equippedCosmetic:null,cosmeticStock:null,cosmeticRestockAt:0};
}
function save() {
  try {
    state.savedAt=Date.now();
    localStorage.setItem('little-garden-save',JSON.stringify({...state,saveVersion:1}));
    return true;
  } catch (error) {
    console.warn('Could not save garden progress:',error);
    return false;
  }
}
function getSeed(id) { return SEEDS.find(s => s.id === id); }
function gearCount(id) {return Math.min(3,Math.max(0,Number(state.gearInventory?.[id])||0));}
function gearStat(name) {return GEARS.reduce((total,gear)=>total+(GEAR_EFFECTS[gear.id]?.[name]||0)*gearCount(gear.id),0);}
function getGrowthDuration(seed) {return Math.max(1000,Math.round((RARITY_GROW_MS[seed.rarity]||seed.grow*1000)*(1-Math.min(.65,gearStat('growth')))));}
function formatGrowDuration(ms) {
  if (ms<60000) return Math.ceil(ms/1000)+' sec';
  if (ms<3600000) return Math.round(ms/60000)+' min';
  if (ms<86400000) return Number((ms/3600000).toFixed(1))+' hr';
  return '1 day';
}
function getMutationChance() {return Math.min(.9,MUTATION_CHANCE+gearStat('mutation'));}
function updatePlantGrowth() {
  let changed=false;
  for (const bed of state.beds) {
    if (!bed) continue;
    if (bed.sharedGrowth) continue;
    const seed=getSeed(bed.id);
    if (!seed) continue;
    const growMs=getGrowthDuration(seed);
    if (!Number.isFinite(bed.plantedAt)) {bed.plantedAt=Number.isFinite(bed.readyAt)?bed.readyAt-growMs:Date.now();changed=true;}
    if (Number.isFinite(bed.instantGrownAt)) {
      const readyAt=bed.instantGrownAt, plantedAt=readyAt-growMs;
      if (bed.growMs!==growMs||bed.readyAt!==readyAt||bed.plantedAt!==plantedAt) {bed.growMs=growMs;bed.readyAt=readyAt;bed.plantedAt=plantedAt;changed=true;}
      continue;
    }
    const readyAt=bed.plantedAt+growMs;
    if (bed.growMs!==growMs||bed.readyAt!==readyAt) {bed.growMs=growMs;bed.readyAt=readyAt;changed=true;}
  }
  return changed;
}
function getMutations(bed) {
  if (Array.isArray(bed?.mutations)) return bed.mutations.filter(m=>m&&typeof m.name==='string');
  return bed?.mutation&&typeof bed.mutation.name==='string'?[bed.mutation]:[];
}
function addMutation(bed, mutation) {
  const mutations=getMutations(bed);
  if (mutations.some(item=>item.event===mutation.event||item.name===mutation.name)) return false;
  bed.mutations=[...mutations,mutation];
  delete bed.mutation;
  return true;
}
const RESTOCK_CHANCE = {Common:1,Uncommon:.85,Rare:.65,Epic:.45,Legendary:.30,Mythic:.20,Ancient:.12,Celestial:.08,Prismatic:.05,Astral:.04,Divine:.03,Transcendent:.02,Omniversal:.01,Infinite:.005,Limited:1};
function freshStock() {
  const replacement={};
  for (const seed of SEEDS) {
    const restocks=Math.random()<(RESTOCK_CHANCE[seed.rarity]??.5);
    replacement[seed.id]=seed.limited&&Date.now()>=LIMITED_SEEDS_UNTIL?0:restocks?Math.max(1,seed.stock-Math.floor(Math.random()*3)):0;
  }
  state.stock=replacement;
  state.restockAt=Date.now()+RESTOCK_MS;
  save();
}
function freshGearStock() {
  const replacement={};
  for (const gear of GEARS) {
    const restocks=Math.random()<(RESTOCK_CHANCE[gear.rarity]??.5);
    replacement[gear.id]=restocks?Math.max(1,gear.stock-Math.floor(Math.random()*2)):0;
  }
  state.gearStock=replacement;
  state.gearRestockAt=Date.now()+RESTOCK_MS;
  save();
}
function freshCosmeticStock() {
  state.cosmeticStock=Object.fromEntries(COSMETICS.map(item=>[item.id,Math.max(1,item.stock-Math.floor(Math.random()*2))]));
  state.cosmeticRestockAt=Date.now()+COSMETIC_RESTOCK_MS;
  save();
}
function resolveWeatherEvents(input) {
  const entries=Array.isArray(input)?input:[input];
  const resolved=entries.map(entry=>{
    const name=typeof entry==='string'?entry:entry?.name;
    return WEATHER_EVENTS.find(event=>event.name===name);
  }).filter(Boolean);
  return [...new Map(resolved.map(event=>[event.name,event])).values()];
}
function updateWeatherDisplay(now=Date.now()) {
  const chip=$('#weather-chip');
  const events=now<activeWeatherUntil?resolveWeatherEvents(activeWeather):[];
  const running=events.length>0;
  chip.classList.toggle('active-weather',running);
  $('#weather-icon').textContent=running?events.slice(0,3).map(event=>event.icon).join('')+(events.length>3?'…':''):'☀';
  $('#weather').textContent=!running?'CALM SKIES':events.length===1?events[0].name.toUpperCase():events.length+' WEATHER EVENTS';
  chip.title=running?events.map(event=>event.name+' — '+event.mutation).join(', ')+' · active together; each may mutate plants.':'Weather rolls every 30 seconds: 30% chance to run; plants have a 50% base mutation chance. Rain boots improve it.';
}
function runWeatherEvents(events,now=Date.now(),source='weather',by='',duration=WEATHER_DURATION) {
  events=resolveWeatherEvents(events);
  if (!events.length) return;
  activeWeather=events;
  activeWeatherUntil=now+Math.max(0,Math.min(WEATHER_DURATION,Number(duration)||WEATHER_DURATION));
  let changed=0;
  const changedBeds=new Map();
  for (const event of events) state.beds.forEach((bed,index)=>{
    if (bed && Math.random()<getMutationChance() && addMutation(bed,{name:event.mutation,icon:event.icon,event:event.name})) {
      changed++;changedBeds.set(index,bed);
    }
  });
  if (changed) {
    save();renderBeds();
    sendGardenMessage({type:'garden-bed-updates',beds:[...changedBeds].map(([index,bed])=>({index,bed}))});
  }
  updateWeatherDisplay(now);
  const sourceLabel=source==='owner'?(by?'Owner @'+by+' started ':'Owner started '):'';
  const eventNames=events.length>3?events.slice(0,3).map(event=>event.name).join(' + ')+' + '+(events.length-3)+' more':events.map(event=>event.name).join(' + ');
  const eventIcons=events.slice(0,3).map(event=>event.icon).join(' ')+(events.length>3?' …':'');
  notify(sourceLabel+eventIcons+' '+eventNames+'! '+(changed?changed+' mutation'+(changed===1?'':'s')+' applied!':'No plants mutated this time.'));
}
function runWeatherEvent(event,now=Date.now(),source='weather',by='',duration=WEATHER_DURATION) {
  runWeatherEvents([event],now,source,by,duration);
}
function triggerWeather(now) {
  nextWeatherCheck=now+WEATHER_INTERVAL;
  if (Math.random()>=WEATHER_RUN_CHANCE) return;
  runWeatherEvent(WEATHER_EVENTS[Math.floor(Math.random()*WEATHER_EVENTS.length)],now);
}
function notify(message) {
  const el=$('#toast');el.textContent=message;el.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),5000);
}
function applySharedRestock(message) {
  if (!message.stocks || typeof message.stocks!=='object') return;
  state.stock=Object.fromEntries(SEEDS.map(seed=>[seed.id,Number.isFinite(message.stocks[seed.id])?message.stocks[seed.id]:(state.stock?.[seed.id]??seed.stock)]));
  const remaining=Math.max(0,Math.min(RESTOCK_MS,Number(message.remainingMs)||RESTOCK_MS));
  state.restockAt=Date.now()+remaining;
  save();renderShop();
  $('#countdown').textContent=String(Math.floor(remaining/60000)).padStart(2,'0')+':'+String(Math.floor((remaining%60000)/1000)).padStart(2,'0');
  notify((message.by?'@'+message.by:'The owner')+' restocked the seed cart!');
}
function applySharedSeedRestock(message) {
  if (!message.stocks || typeof message.stocks!=='object') return;
  const entries=Object.entries(message.stocks).filter(([id,amount])=>getSeed(id)&&Number.isInteger(amount)&&amount>=0&&amount<=1000);
  if (!entries.length) return;
  for (const [id,amount] of entries) state.stock[id]=amount;
  save();renderShop();
  const names=entries.map(([id])=>getSeed(id).name);
  notify((message.by?'@'+message.by:'The owner')+(entries.length>4?' restocked '+entries.length+' seed types!':' restocked '+names.join(', ')+'!'));
}
function applySharedGearRestock(message) {
  if (!message.stocks || typeof message.stocks!=='object') return;
  state.gearStock=Object.fromEntries(GEARS.map(gear=>[gear.id,Number.isFinite(message.stocks[gear.id])?message.stocks[gear.id]:(state.gearStock?.[gear.id]??gear.stock)]));
  const remaining=Math.max(0,Math.min(RESTOCK_MS,Number(message.remainingMs)||RESTOCK_MS));
  state.gearRestockAt=Date.now()+remaining;
  save();renderGearShop();
  $('#gear-countdown').textContent=String(Math.floor(remaining/60000)).padStart(2,'0')+':'+String(Math.floor((remaining%60000)/1000)).padStart(2,'0');
  notify((message.by?'@'+message.by:'The owner')+' restocked the gear cart!');
}
function applySharedGearItemRestock(message) {
  if (!message.stocks || typeof message.stocks!=='object') return;
  const entries=Object.entries(message.stocks).filter(([id,amount])=>GEARS.some(gear=>gear.id===id)&&Number.isInteger(amount)&&amount>=0&&amount<=1000);
  if (!entries.length) return;
  for (const [id,amount] of entries) state.gearStock[id]=amount;
  const remaining=Math.max(1,Math.min(RESTOCK_MS,Number(message.remainingMs)||RESTOCK_MS));
  state.gearRestockAt=Date.now()+remaining;
  save();renderGearShop();
  $('#gear-countdown').textContent=String(Math.floor(remaining/60000)).padStart(2,'0')+':'+String(Math.floor((remaining%60000)/1000)).padStart(2,'0');
  notify((message.by?'@'+message.by:'The owner')+' restocked selected gear.');
}
function applyBulkRestock(message) {
  if (!message.seedStocks||!SEEDS.every(seed=>Number.isFinite(message.seedStocks[seed.id]))||!message.gearStocks) return;
  const remaining=Math.max(0,Math.min(RESTOCK_MS,Number(message.remainingMs)||RESTOCK_MS));
  state.stock=message.seedStocks;
  state.restockAt=Date.now()+remaining;
  state.gearStock=Object.fromEntries(GEARS.map(gear=>[gear.id,Number.isFinite(message.gearStocks[gear.id])?message.gearStocks[gear.id]:(state.gearStock?.[gear.id]??gear.stock)]));
  state.gearRestockAt=Date.now()+remaining;
  save();renderShop();renderGearShop();
  const timer=String(Math.floor(remaining/60000)).padStart(2,'0')+':'+String(Math.floor((remaining%60000)/1000)).padStart(2,'0');
  $('#countdown').textContent=timer;$('#gear-countdown').textContent=timer;
  notify((message.by?'@'+message.by:'The owner')+' bulk-restocked seeds and gear!');
}
function escapeHtml(value) {
  return String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}
function applySharedGardenBeds(beds) {
  if (!Array.isArray(beds)||beds.length<16||beds.length>256) return;
  const length=Math.ceil(beds.length/16)*16;
  state.beds=Array.from({length},(_,index)=>{
    const bed=beds[index];
    if (!bed||!getSeed(bed.id)) return null;
    const copy={id:bed.id,plantedAt:Number(bed.plantedAt)||Date.now(),growMs:Number(bed.growMs)||45000,readyAt:Number(bed.readyAt)||Date.now()+45000,sharedGrowth:true};
    if (Number.isFinite(bed.x)) copy.x=bed.x;
    if (Number.isFinite(bed.y)) copy.y=bed.y;
    if (bed.locked) copy.locked=true;
    if (Number.isFinite(bed.instantGrownAt)) copy.instantGrownAt=bed.instantGrownAt;
    if (Array.isArray(bed.mutations)) copy.mutations=bed.mutations.filter(m=>m&&typeof m.name==='string').slice(0,8).map(m=>({name:m.name,icon:String(m.icon||''),event:String(m.event||'')}));
    return copy;
  });
  save();renderBeds();
}
function sendGardenMessage(message) {
  try {if (liveRoom) liveRoom.send(message);} catch(error) {console.warn('Could not sync garden action',error);}
}
function handleRoomMessage(message) {
  if (message.type==='garden-state-required') sendGardenMessage({type:'garden-join',initialBeds:state.beds});
  if (message.type==='garden-state'&&Array.isArray(message.beds)) applySharedGardenBeds(message.beds);
  if (message.type==='garden-bed-update'&&Number.isInteger(message.index)&&message.index>=0&&message.index<state.beds.length) {
    state.beds[message.index]=message.bed||null;save();renderBeds();
  }
  if (message.type==='garden-bed-updates'&&Array.isArray(message.beds)) {
    for (const item of message.beds) if (Number.isInteger(item.index)&&item.index>=0&&item.index<state.beds.length) state.beds[item.index]=item.bed||null;
    save();renderBeds();
  }
  if (message.type==='garden-bed-cleared'&&Number.isInteger(message.index)&&message.index>=0&&message.index<state.beds.length) {
    state.beds[message.index]=null;save();renderBeds();
  }
  if (message.type==='garden-action-rejected') {
    if (message.action==='plant'&&message.seedId) {state.inventory[message.seedId]=(state.inventory[message.seedId]||0)+1;selected=message.seedId;notify('Someone else planted there first; your seed was returned.');}
    if (message.action==='harvest') notify('That plant was already harvested or is protected.');
    if (Number.isInteger(message.index)&&message.index>=0&&message.index<state.beds.length) state.beds[message.index]=message.bed||null;
    save();render();
  }
  if (message.type==='garden-harvest-success') awardHarvest(message.bed,message.index);
  if (message.type==='manual-bulk-restock') applyBulkRestock(message);
  if (message.type==='manual-restock') applySharedRestock(message);
  if (message.type==='manual-seed-restock') applySharedSeedRestock(message);
  if (message.type==='manual-gear-restock') applySharedGearRestock(message);
  if (message.type==='manual-gear-item-restock') applySharedGearItemRestock(message);
  if (message.type==='weather-start') {
    const names=Array.isArray(message.names)?message.names:[message.name];
    const events=names.map(name=>WEATHER_EVENTS.find(item=>item.name===name)).filter(Boolean);
    if (!events.length) return;
    nextWeatherCheck=Date.now()+WEATHER_INTERVAL;
    runWeatherEvents(events,Date.now(),'owner',message.by||'',message.remainingMs);
  }
}
async function restoreSharedRestocks() {
  try {
    const response=await fetch('/api/garden-restocks');
    if (!response.ok) return;
    const saved=await response.json();
    if (Array.isArray(saved.sharedBeds)) applySharedGardenBeds(saved.sharedBeds);
    const now=Date.now();
    const remaining=(record,duration)=>record&&Number.isFinite(record.at)&&now-record.at<duration?Math.max(1,Math.min(duration,duration-(now-record.at))):0;
    if (saved.latestRestock&&remaining(saved.latestRestock,RESTOCK_MS)) {
      applySharedRestock({...saved.latestRestock,remainingMs:remaining(saved.latestRestock,RESTOCK_MS)});
    }
    const seedOverrides=Object.entries(saved.latestSeedRestocks||{}).filter(([,record])=>remaining(record,RESTOCK_MS));
    if (seedOverrides.length) applySharedSeedRestock({stocks:Object.fromEntries(seedOverrides.map(([id,record])=>[id,record.stock])),by:seedOverrides[seedOverrides.length-1][1].by||''});
    if (saved.latestGearRestock&&remaining(saved.latestGearRestock,RESTOCK_MS)) {
      applySharedGearRestock({...saved.latestGearRestock,remainingMs:remaining(saved.latestGearRestock,RESTOCK_MS)});
    }
    const gearOverrides=Object.entries(saved.latestGearItems||{}).filter(([,record])=>remaining(record,RESTOCK_MS));
    if (gearOverrides.length) applySharedGearItemRestock({stocks:Object.fromEntries(gearOverrides.map(([id,record])=>[id,record.stock])),remainingMs:Math.max(...gearOverrides.map(([,record])=>remaining(record,RESTOCK_MS))),by:gearOverrides[gearOverrides.length-1][1].by||''});
    if (saved.latestWeather&&remaining(saved.latestWeather,WEATHER_DURATION)) {
      const weather=saved.latestWeather;
      runWeatherEvents(weather.names||[weather.name].filter(Boolean),now,'owner',weather.by||'',remaining(weather,WEATHER_DURATION));
    }
  } catch {}
}
async function connectLiveRoom() {
  try {
    await restoreSharedRestocks();
    if (!window.WebsimSocket?.joinRoom) return;
    const room=await window.WebsimSocket.joinRoom();
    liveRoom=room;
    room.onmessage=event=>{
      try { handleRoomMessage(JSON.parse(event.data)); } catch(error) {console.warn('Could not apply shared garden update',error);}
    };
    const joinGarden=()=>room.send({type:'garden-join',initialBeds:state.beds});
    room.onreconnect=async()=>{liveRoom=room;await restoreSharedRestocks();joinGarden();};
    room.onclose=()=>{if(liveRoom===room)liveRoom=null;};
    joinGarden();
  } catch(error) {console.warn('Shared garden connection unavailable',error);}
}
async function setupCreatorMenu() {
  const toggle=$('#creator-toggle'), menu=$('#creator-menu');
  // Keep admin controls hidden unless we can positively identify the project creator.
  toggle.hidden=true;
  menu.hidden=true;
  try {
    if (!window.websim?.getCreator || !window.websim?.getUser) return;
    const [creator,user]=await Promise.all([window.websim.getCreator(),window.websim.getUser()]);
    const creatorName=String(creator?.username||'').trim().toLowerCase();
    const userName=String(user?.username||'').trim().toLowerCase();
    // IDs may collide with the anonymous placeholder account. Usernames are unique,
    // and anonymous sessions must never receive creator controls.
    if (!creatorName || !userName || userName==='anonymous' || creatorName!==userName) return;
    const select=$('#manual-weather');
    const seedPicker=$('#seed-picker'), restockSelected=$('#restock-selected');
    const gearPicker=$('#gear-picker'), restockGearSelected=$('#restock-gear-selected');
    select.innerHTML=WEATHER_EVENTS.map(event=>'<option value="'+event.name+'">'+event.icon+' '+event.name+'</option>').join('');
    seedPicker.innerHTML=SEEDS.filter(seed=>!seed.limited||Date.now()<LIMITED_SEEDS_UNTIL).map(seed=>'<label class="seed-pick"><input type="checkbox" value="'+seed.id+'"><span>'+seed.seed+' '+seed.name+'</span></label>').join('');
    const updateSeedSelection=()=>{
      const count=seedPicker.querySelectorAll('input:checked').length;
      restockSelected.disabled=count===0;
      restockSelected.textContent=count?'↻ Bulk restock '+count+' seed type'+(count===1?'':'s'):'Bulk restock selected seeds';
      $('#selected-seed-count').textContent=count+' selected';
    };
    seedPicker.addEventListener('change',updateSeedSelection);
    $('#select-all-seeds').addEventListener('click',()=>{seedPicker.querySelectorAll('input').forEach(input=>{input.checked=true;});updateSeedSelection();});
    $('#clear-seeds').addEventListener('click',()=>{seedPicker.querySelectorAll('input').forEach(input=>{input.checked=false;});updateSeedSelection();});
    gearPicker.innerHTML=GEARS.map(gear=>'<label class="seed-pick"><input type="checkbox" value="'+gear.id+'"><span>'+gear.emoji+' '+gear.name+'</span></label>').join('');
    gearPicker.addEventListener('change',()=>{restockGearSelected.disabled=!gearPicker.querySelector('input:checked');});
    toggle.hidden=false;
    const closeMenu=()=>{menu.hidden=true;toggle.setAttribute('aria-expanded','false');};
    toggle.addEventListener('click',()=>{menu.hidden=!menu.hidden;toggle.setAttribute('aria-expanded',String(!menu.hidden));});
    $('#creator-close').addEventListener('click',closeMenu);
    restockSelected.addEventListener('click',()=>{
      const ids=[...seedPicker.querySelectorAll('input:checked')].map(input=>input.value);
      if (!ids.length) return;
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-restock-seeds',ids});
      seedPicker.querySelectorAll('input:checked').forEach(input=>{input.checked=false;});
      updateSeedSelection();closeMenu();
    });
    $('#manual-restock-bulk').addEventListener('click',()=>{
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-restock-bulk'});closeMenu();
    });
    $('#manual-restock').addEventListener('click',()=>{
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-restock'});closeMenu();
    });
    $('#manual-restock-new-seeds').addEventListener('click',()=>{
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-restock-new-seeds'});closeMenu();
    });
    $('#manual-restock-gear').addEventListener('click',()=>{
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-restock-gear'});closeMenu();
    });
    $('#manual-restock-divider').addEventListener('click',()=>{
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-restock-gear-items',ids:['garden-divider']});
      closeMenu();
    });
    restockGearSelected.addEventListener('click',()=>{
      const ids=[...gearPicker.querySelectorAll('input:checked')].map(input=>input.value);
      if (!ids.length) return;
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-restock-gear-items',ids});
      gearPicker.querySelectorAll('input:checked').forEach(input=>{input.checked=false;});
      restockGearSelected.disabled=true;closeMenu();
    });
    $('#run-weather').addEventListener('click',()=>{
      const names=[...select.selectedOptions].map(option=>option.value);
      if (!names.length) {notify('Choose one or more weather events first.');return;}
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-weather',names});
      [...select.options].forEach(option=>{option.selected=false;});
      closeMenu();
    });
    $('#run-all-weather').addEventListener('click',()=>{
      if (!liveRoom) {notify('Connecting to the shared garden…');return;}
      liveRoom.send({type:'admin-weather',names:WEATHER_EVENTS.map(event=>event.name)});
      [...select.options].forEach(option=>{option.selected=false;});
      closeMenu();
    });
    document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!menu.hidden)closeMenu();});
  } catch {}
}
function rarityClass(seed) { return 'rarity-'+seed.rarity.toLowerCase(); }
function formatPrice(price) {
  const units=[[1e66,'unvigintillion'],[1e63,'vigintillion'],[1e60,'novemdecillion'],[1e57,'octodecillion'],[1e54,'septendecillion'],[1e51,'sexdecillion'],[1e48,'quindecillion'],[1e45,'quattuordecillion'],[1e42,'tredecillion'],[1e39,'duodecillion'],[1e36,'undecillion'],[1e33,'decillion'],[1e30,'nonillion'],[1e27,'octillion'],[1e24,'septillion'],[1e21,'sextillion'],[1e18,'quintillion'],[1e15,'quadrillion'],[1e12,'trillion'],[1e9,'billion'],[1e6,'million'],[1e3,'thousand']];
  const unit=units.find(([value])=>price>=value);
  if (!unit) return price.toLocaleString();
  const amount=Number((price/unit[0]).toFixed(1)).toLocaleString(undefined,{maximumFractionDigits:1});
  return amount+' '+unit[1];
}
function renderShop() {
  const list=$('#seed-list');
  const limitedAvailable=Date.now()<LIMITED_SEEDS_UNTIL;
  $('#limited-clock').hidden=!limitedAvailable;
  list.innerHTML=SEEDS.filter(seed=>!seed.limited||limitedAvailable).map(s=>{
    const amount=state.stock[s.id] ?? 0;
    const limitedBadge=s.limited?'<span class="limited-tag">LIMITED</span>':'';
    return '<article class="seed-card '+rarityClass(s)+'"><div class="seed-art">'+s.seed+'</div><div class="seed-info"><div class="seed-name">'+s.name+'</div><div class="seed-meta">'+amount+' left · '+formatGrowDuration(RARITY_GROW_MS[s.rarity]||s.grow*1000)+'</div><span class="rarity-tag">'+s.rarity+'</span>'+limitedBadge+'</div><button class="buy-btn" data-buy="'+s.id+'" '+(amount<=0||state.coins<s.cost?'disabled':'')+' title="'+s.cost.toLocaleString()+' coins">◉ '+formatPrice(s.cost)+'</button></article>';
  }).join('');
  list.querySelectorAll('[data-buy]').forEach(btn=>btn.addEventListener('click',()=>buy(btn.dataset.buy)));
  $('#coins').textContent=formatPrice(state.coins);
}
function renderGearShop() {
  const list=$('#gear-list');
  list.innerHTML=GEARS.map(gear=>{
    const amount=state.gearStock?.[gear.id]??0;
    const effect=GEAR_EFFECTS[gear.id]?.text||'Garden gear';
    const owned=Number(state.gearInventory?.[gear.id])||0, unique=gear.id==='garden-divider';
    return '<article class="seed-card gear-card '+rarityClass(gear)+'"><div class="seed-art">'+gear.emoji+'</div><div class="seed-info"><div class="seed-name">'+gear.name+'</div><div class="seed-meta">'+(unique&&owned?'Owned · '+amount+' in stock':amount+' in stock')+'</div><span class="rarity-tag">'+gear.rarity+'</span><div class="gear-effect">'+effect+'</div></div><button class="buy-btn" data-gear-buy="'+gear.id+'" '+(amount<=0||state.coins<gear.cost||(unique&&owned)?'disabled':'')+' title="'+(unique&&owned?'Already owned':gear.cost.toLocaleString()+' coins')+'">'+(unique&&owned?'✓ Owned':'◉ '+formatPrice(gear.cost))+'</button></article>';
  }).join('');
  list.querySelectorAll('[data-gear-buy]').forEach(btn=>btn.addEventListener('click',()=>buyGear(btn.dataset.gearBuy)));

}
function renderCosmeticShop() {
  const list=$('#cosmetic-list');
  list.innerHTML=COSMETICS.map(item=>{
    const amount=state.cosmeticStock?.[item.id]??0;
    const owned=state.cosmeticInventory.includes(item.id);
    const equipped=state.equippedCosmetic===item.id;
    const action=owned?(equipped?'✓ Equipped':'Equip'):'◉ '+formatPrice(item.cost);
    return '<article class="seed-card cosmetic-card '+rarityClass(item)+(equipped?' cosmetic-equipped':'')+'"><div class="seed-art">'+item.emoji+'</div><div class="seed-info"><div class="seed-name">'+item.name+'</div><div class="seed-meta">'+(owned?'Owned · '+item.description:amount+' in stock · '+item.description)+'</div><span class="rarity-tag">'+item.rarity+'</span></div><button class="buy-btn cosmetic-action" data-cosmetic="'+item.id+'" '+((owned&&equipped)||(!owned&&(amount<=0||state.coins<item.cost))?'disabled':'')+'>'+action+'</button></article>';
  }).join('');
  list.querySelectorAll('[data-cosmetic]').forEach(btn=>btn.addEventListener('click',()=>useCosmetic(btn.dataset.cosmetic)));
  $('#coins').textContent=formatPrice(state.coins);
}
function growthStage(progress, ready, seed) {
  if (ready) return {stage:3, emoji:seed.emoji};
  if (progress >= 60) return {stage:2, emoji:'🪴'};
  if (progress >= 25) return {stage:1, emoji:'🌿'};
  return {stage:0, emoji:'🌱'};
}
function renderBeds() {
  const plot=$('#plot');
  const plotStyle=PLOT_STYLES.has(state.plotStyle)?state.plotStyle:(state.plotStyle='earth');
  plot.dataset.style=plotStyle;
  document.querySelectorAll('[data-plot-style]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.plotStyle===plotStyle)));
  plot.setAttribute('aria-label',gearCount('garden-divider')?'Freestyle garden plot divided into four sections. Click any open spot to plant.':'Freestyle garden plot. Click any open spot to plant.');
  const columns=Math.ceil(Math.sqrt(state.beds.length)), rows=Math.ceil(state.beds.length/columns);
  const dividerMarkup=gearCount('garden-divider')?'<div class="garden-divider-lines" aria-hidden="true"></div>':'';
  plot.innerHTML=dividerMarkup+state.beds.map((bed,i)=>{
    if (!bed) return '';
    const number=String(i+1).padStart(2,'0');
    const x=Number.isFinite(bed.x)?bed.x:(8+((i%columns)+.5)*(84/columns));
    const y=Number.isFinite(bed.y)?bed.y:(8+(Math.floor(i/columns)+.5)*(84/rows));
    const s=getSeed(bed.id);
    if (!s) return '';
    const progress=Math.min(100,Math.max(0,(1-(bed.readyAt-Date.now())/(bed.growMs||getGrowthDuration(s)))*100));
    const ready=Date.now()>=bed.readyAt;
    const label=ready?'Ready to harvest!':'Growing · '+Math.max(1,Math.ceil((bed.readyAt-Date.now())/1000))+'s';
    const mutations=getMutations(bed), multiplier=2**mutations.length;
    const mutationBadge=mutations.length?'<span class="mutation-badge" title="'+escapeHtml(mutations.map(m=>m.name).join(', '))+' · '+multiplier+'× harvest value">'+mutations.slice(0,3).map(m=>escapeHtml(m.icon)).join('')+(mutations.length>3?' +'+(mutations.length-3):'')+(mutations.length>1?' ×'+mutations.length:'')+'</span>':'';
    const mutationLabel=mutations.length?', '+escapeHtml(mutations.map(m=>m.name).join(', '))+' mutation'+(mutations.length===1?'':'s')+', worth '+multiplier+'×':'';
    const locked=!!bed.locked;
    const lockBadge=locked?'<span class="lock-badge" title="Protected from harvesting">🔒</span>':'';
    const growth=growthStage(progress,ready,s);
    return '<button class="bed free-bed '+(ready?'ready':'planted')+(mutations.length?' mutated':'')+(locked?' locked':'')+'" style="left:'+x+'%;top:'+y+'%" data-harvest="'+i+'" aria-label="'+(locked?'Locked · ':'')+(ready?'Harvest':'Growing')+' '+s.name+mutationLabel+' in bed '+(i+1)+'"><span class="bed-number">'+number+'</span>'+mutationBadge+lockBadge+'<span class="plant-emoji growth-stage-'+growth.stage+'">'+growth.emoji+'</span><span class="bed-label">'+label+'</span><span class="bed-progress"><i style="width:'+progress+'%"></i></span></button>';
  }).join('');
  plot.querySelectorAll('[data-harvest]').forEach(btn=>btn.addEventListener('click',()=>{const index=Number(btn.dataset.harvest);if(lockToolActive)toggleBedLock(index);else if(instantGrowToolActive)instantGrow(index);else harvest(index);}));
  const expansions=Math.max(0,Math.ceil((state.beds.length-16)/16));
  plot.style.setProperty('--garden-extra-height',(expansions*100)+'px');
  plot.dataset.expansions=String(expansions);
  const expansionButton=$('#plot-expansion');
  expansionButton.disabled=state.coins<10_000_000||expansions>=MAX_PLOT_EXPANSIONS;
  expansionButton.textContent=expansions>=MAX_PLOT_EXPANSIONS?'✓ Plot expansion limit reached · '+MAX_PLOT_EXPANSIONS+'/'+MAX_PLOT_EXPANSIONS:'＋ Expand plot · 16 more planting spots · '+formatPrice(10_000_000)+' ◉ · '+expansions+'/'+MAX_PLOT_EXPANSIONS;
}
function toggleBedLock(index) {
  const bed=state.beds[index];
  if (!bed) {notify('Plant a seed before locking a bed.');return;}
  bed.locked=!bed.locked;
  if (bed.sharedGrowth) sendGardenMessage({type:'garden-bed-update',index,bed});
  save();renderBeds();
  notify(getSeed(bed.id).name+(bed.locked?' locked from harvesting.':' unlocked.'));
}
function setLockTool(active) {
  if (active&&instantGrowToolActive) setInstantGrowTool(false);
  lockToolActive=active;
  const button=$('#lock-tool');
  button.setAttribute('aria-pressed',String(active));
  button.classList.toggle('active',active);
  button.textContent=active?'🔒 Lock tool: ON':'🔓 Lock tool: OFF';
  $('#hint').textContent=active?'Lock tool on · tap a planted seed to lock or unlock it.':selected?'Tap any open spot to plant your '+getSeed(selected).name.toLowerCase()+' seed.':'Open the seed shop to choose seeds, then tap anywhere in the plot.';
}
function setInstantGrowTool(active) {
  if (active&&lockToolActive) setLockTool(false);
  instantGrowToolActive=active;
  const button=$('#instant-grow-tool');
  button.setAttribute('aria-pressed',String(active));
  button.classList.toggle('active',active);
  button.textContent=active?'⚡ Instant grow: ON':'⚡ Instant grow: OFF';
  $('#hint').textContent=active?'Instant grow on · tap a growing plant to finish it instantly.':selected?'Tap any open spot to plant your '+getSeed(selected).name.toLowerCase()+' seed.':'Open the seed shop to choose seeds, then tap anywhere in the plot.';
}
function instantGrow(index) {
  const bed=state.beds[index];
  if (!bed) return;
  if (Date.now()>=bed.readyAt) {notify('This plant is already fully grown.');return;}
  bed.instantGrownAt=Date.now();
  bed.readyAt=bed.instantGrownAt;
  if (!bed.sharedGrowth) updatePlantGrowth();
  if (bed.sharedGrowth) sendGardenMessage({type:'garden-bed-update',index,bed});
  save();renderBeds();
  notify(getSeed(bed.id).name+' grew instantly!');
}
function expandPlot() {
  const beds=Array.isArray(state.beds)?state.beds.slice():Array(16).fill(null);
  while (beds.length<16) beds.push(null);
  // Count partial/legacy saves safely and normalize them to a full set of spaces.
  const expansions=Math.max(0,Math.ceil((beds.length-16)/16));
  if (expansions>=MAX_PLOT_EXPANSIONS) {notify('You have reached the 5-expansion limit.');return;}
  if (!Number.isFinite(state.coins)||state.coins<10_000_000) {notify('You need 10 million coins to expand your plot.');return;}
  const nextLength=16*(expansions+2);
  while (beds.length<nextLength) beds.push(null);
  state.coins-=10_000_000;
  state.beds=beds;
  if (liveRoom) sendGardenMessage({type:'garden-expand',length:beds.length});
  save();
  render();
  notify('Plot expanded! You now have '+state.beds.length+' planting spaces.');
}
function renderInventory() {
  const seeds=Object.entries(state.inventory).filter(([,amount])=>amount>0).map(([id,amount])=>{
    const seed=getSeed(id);
    return '<span class="inv-seed inventory-seed '+rarityClass(seed)+' '+(selected===id?'selected':'')+'"><button data-select="'+id+'" aria-label="Select '+seed.name+' seeds, '+seed.rarity+' rarity">'+seed.seed+' '+seed.name+' <span class="inv-kind">SEED</span><span class="inv-count">×'+amount+'</span></button></span>';
  });
  const cosmeticItems=(state.cosmeticInventory||[]).map(id=>COSMETICS.find(item=>item.id===id)).filter(Boolean).map(item=>'<span class="inv-seed inventory-cosmetic ' +(state.equippedCosmetic===item.id?'is-equipped':'')+'" title="'+(state.equippedCosmetic===item.id?'Currently equipped':'Owned cosmetic')+'">'+item.emoji+' '+item.name+' <span class="inv-kind">'+(state.equippedCosmetic===item.id?'EQUIPPED':'COSMETIC')+'</span></span>');
  const gearItems=Object.entries(state.gearInventory||{}).filter(([,amount])=>amount>0).map(([id,amount])=>{
    const gear=GEARS.find(item=>item.id===id);
    if (!gear) return '';
    return '<span class="inv-seed inventory-gear '+rarityClass(gear)+'" title="Active: '+GEAR_EFFECTS[gear.id]?.text+'"><span>'+gear.emoji+' '+gear.name+'</span><span class="inv-kind">ACTIVE</span><span class="inv-count">×'+amount+'</span></span>';
  });
  const inventory=$('#inventory');
  const items=seeds.concat(gearItems,cosmeticItems);
  inventory.innerHTML=items.length?items.join(''):'<span class="inventory-empty">No items yet</span>';
  inventory.querySelectorAll('[data-select]').forEach(btn=>btn.addEventListener('click',()=>{
    selected=selected===btn.dataset.select?null:btn.dataset.select;
    $('#hint').textContent=lockToolActive?'Lock tool on · tap a planted seed to lock or unlock it.':instantGrowToolActive?'Instant grow on · tap a growing plant to finish it instantly.':selected?'Tap any open spot to plant your '+getSeed(selected).name.toLowerCase()+' seed.':'Open the seed shop to choose seeds, then tap anywhere in the plot.';
    render();
  }));
}
function render() {
  renderShop();renderGearShop();renderCosmeticShop();renderInventory();renderBeds();
  const plot=$('#plot');
  plot.dataset.cosmetic=state.equippedCosmetic||'none';
  plot.style.setProperty('--cosmetic-mark',JSON.stringify(COSMETICS.find(item=>item.id===state.equippedCosmetic)?.emoji||''));
}
function useCosmetic(id) {
  const item=COSMETICS.find(entry=>entry.id===id);
  if (!item) return;
  if (state.cosmeticInventory.includes(id)) {
    state.equippedCosmetic=state.equippedCosmetic===id?null:id;
  } else {
    if (state.coins<item.cost||(state.cosmeticStock?.[id]??0)<=0) return;
    state.coins-=item.cost;state.cosmeticStock[id]--;state.cosmeticInventory.push(id);state.equippedCosmetic=id;
    notify(item.name+' added to your collection!');
  }
  save();render();
}
function buyGear(id) {
  const gear=GEARS.find(item=>item.id===id);
  if (!gear||state.coins<gear.cost||(state.gearStock?.[id]??0)<=0||(id==='garden-divider'&&(state.gearInventory[id]||0)>0)) return;
  state.coins-=gear.cost;state.gearStock[id]--;state.gearInventory[id]=(state.gearInventory[id]||0)+1;
  updatePlantGrowth();save();render();notify(gear.name+' added to your gear pouch.');
}
function buy(id) {
  const s=getSeed(id);
  if (!s||(s.limited&&Date.now()>=LIMITED_SEEDS_UNTIL)||state.coins<s.cost||state.stock[id]<=0) return;
  state.coins-=s.cost;state.stock[id]--;state.inventory[id]=(state.inventory[id]||0)+1;
  save();render();notify(s.name+' seeds added to your pouch.');
}
function plant(index,position=null) {
  if (state.beds[index]) {
    const bed=state.beds[index];
    if (Date.now()>=bed.readyAt) harvest(index); else notify('This little plant is still growing.');
    return;
  }
  if (!selected||!state.inventory[selected]) {notify('Pick a seed from your pouch first.');return;}
  state.inventory[selected]--;
  const plantedAt=Date.now(),growMs=getGrowthDuration(getSeed(selected));
  state.beds[index]={id:selected,plantedAt,growMs,readyAt:plantedAt+growMs,sharedGrowth:!!liveRoom,...(position||{})};
  if (Date.now()<activeWeatherUntil) {
    for (const event of activeWeather) if (Math.random()<getMutationChance()) {
      addMutation(state.beds[index],{name:event.mutation,icon:event.icon,event:event.name});
    }
  }
  const name=getSeed(selected).name;
  const plantedIndex=index;
  const plantedBed=state.beds[index];
  if (!state.inventory[selected]) selected=null;
  if (liveRoom) sendGardenMessage({type:'garden-plant',index:plantedIndex,bed:plantedBed});
  save();render();notify(name+' planted. Give it a moment to grow!');
}
function awardHarvest(bed,index) {
  if (!bed) return;
  const s=getSeed(bed.id);
  if (!s) return;
  const mutations=getMutations(bed), mutationMultiplier=2**mutations.length, gearBonus=Math.min(1,gearStat('harvest'));
  const payout=Math.round(s.reward*mutationMultiplier*(1+gearBonus));state.coins+=payout;
  if (Number.isInteger(index)&&index>=0&&index<state.beds.length) state.beds[index]=null;
  save();render();
  notify(s.emoji+' '+s.name+(mutations.length?' · '+mutations.length+' mutation'+(mutations.length===1?'':'s')+' · '+mutationMultiplier+'× bonus':'')+' harvested · +'+formatPrice(payout)+' coins');
}
function harvest(index) {
  const bed=state.beds[index];
  if (!bed) return;
  if (bed.locked) {notify('This plant is locked. Turn on the lock tool to unlock it.');return;}
  if (Date.now()<bed.readyAt) return;
  if (liveRoom&&bed.sharedGrowth) {sendGardenMessage({type:'garden-harvest',index});return;}
  awardHarvest(bed,index);
}
function tick() {
  const now=Date.now();
  if (activeWeather.length && now>=activeWeatherUntil) {activeWeather=[];updateWeatherDisplay(now);}
  if (now>=nextWeatherCheck) triggerWeather(now);
  if (now>=state.restockAt) {freshStock();renderShop();}
  if (now>=state.gearRestockAt) {freshGearStock();renderGearShop();}
  if (now>=state.cosmeticRestockAt) {freshCosmeticStock();renderCosmeticShop();}
  const cosmeticLeft=Math.max(0,state.cosmeticRestockAt-now);
  $('#cosmetic-countdown').textContent=String(Math.floor(cosmeticLeft/60000)).padStart(2,'0')+':'+String(Math.floor((cosmeticLeft%60000)/1000)).padStart(2,'0');
  const limitedRemaining=Math.max(0,LIMITED_SEEDS_UNTIL-now);
  const days=Math.floor(limitedRemaining/86400000),hours=Math.floor((limitedRemaining%86400000)/3600000),minutes=Math.floor((limitedRemaining%3600000)/60000);
  $('#limited-countdown').textContent=days+'d '+String(hours).padStart(2,'0')+'h '+String(minutes).padStart(2,'0')+'m';
  if (limitedSeedSaleActive&&now>=LIMITED_SEEDS_UNTIL) {limitedSeedSaleActive=false;renderShop();notify('The limited seeds have left the shop.');}
  const gearLeft=Math.max(0,state.gearRestockAt-now);
  $('#gear-countdown').textContent=String(Math.floor(gearLeft/60000)).padStart(2,'0')+':'+String(Math.floor((gearLeft%60000)/1000)).padStart(2,'0');
  const left=Math.max(0,state.restockAt-now);
  $('#countdown').textContent=String(Math.floor(left/60000)).padStart(2,'0')+':'+String(Math.floor((left%60000)/1000)).padStart(2,'0');
  state.beds.forEach((bed,i)=>{
    if (!bed) return;
    const btn=$('#plot').querySelector('[data-harvest="'+i+'"]');if(!btn)return;
    const s=getSeed(bed.id),ready=now>=bed.readyAt;
    const progress=Math.min(100,Math.max(0,(1-(bed.readyAt-now)/(bed.growMs||getGrowthDuration(s)))*100));
    btn.classList.toggle('ready',ready);btn.classList.toggle('planted',!ready);
    const growth=growthStage(progress,ready,s), plant=btn.querySelector('.plant-emoji');
    plant.textContent=growth.emoji;
    plant.className='plant-emoji growth-stage-'+growth.stage;
    btn.querySelector('.bed-label').textContent=ready?'Ready to harvest!':'Growing · '+Math.max(1,Math.ceil((bed.readyAt-now)/1000))+'s';
    btn.querySelector('.bed-progress i').style.width=progress+'%';
    const mutations=getMutations(bed), multiplier=2**mutations.length;
    btn.setAttribute('aria-label',(ready?'Harvest':'Growing')+' '+s.name+(mutations.length?', '+mutations.map(m=>m.name).join(', ')+' mutation'+(mutations.length===1?'':'s')+', worth '+multiplier+'×':'')+' in bed '+(i+1));
  });
}
if (!state.gearInventory||typeof state.gearInventory!=='object') state.gearInventory={};
if (!Array.isArray(state.cosmeticInventory)) state.cosmeticInventory=[];
state.cosmeticInventory=state.cosmeticInventory.filter(id=>COSMETICS.some(item=>item.id===id));
if (!COSMETICS.some(item=>item.id===state.equippedCosmetic)||!state.cosmeticInventory.includes(state.equippedCosmetic)) state.equippedCosmetic=null;
if (updatePlantGrowth()) save();
if (!state.gearStock||typeof state.gearStock!=='object'||!state.gearRestockAt||Date.now()>=state.gearRestockAt) freshGearStock();
else {
  let addedGearStock=false;
  for (const gear of GEARS) if (!Number.isFinite(state.gearStock[gear.id])) {state.gearStock[gear.id]=gear.stock;addedGearStock=true;}
  if (addedGearStock) save();
}
if (!state.stock||typeof state.stock!=='object'||!state.restockAt||Date.now()>=state.restockAt) freshStock();
else {
  let addedStock=false;
  for (const seed of SEEDS) if (!Number.isFinite(state.stock[seed.id])) {state.stock[seed.id]=seed.stock;addedStock=true;}
  if (addedStock) save();
}
if (!state.cosmeticStock||typeof state.cosmeticStock!=='object'||!state.cosmeticRestockAt||Date.now()>=state.cosmeticRestockAt) freshCosmeticStock();
else {
  let addedCosmeticStock=false;
  for (const item of COSMETICS) if (!Number.isFinite(state.cosmeticStock[item.id])) {state.cosmeticStock[item.id]=item.stock;addedCosmeticStock=true;}
  if (addedCosmeticStock) save();
}
const shopModal=$('#shop-modal'), shopOpen=$('#seed-shop-open');
function closeSeedShop() {shopModal.hidden=true;shopOpen.setAttribute('aria-expanded','false');shopOpen.focus();}
shopOpen.addEventListener('click',()=>{shopModal.hidden=false;shopOpen.setAttribute('aria-expanded','true');$('#shop-close').focus();});
$('#shop-close').addEventListener('click',closeSeedShop);
shopModal.addEventListener('click',event=>{if(event.target===shopModal)closeSeedShop();});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!shopModal.hidden)closeSeedShop();});
const gearModal=$('#gear-modal'), gearOpen=$('#gear-shop-open');
function closeGearShop() {gearModal.hidden=true;gearOpen.setAttribute('aria-expanded','false');gearOpen.focus();}
gearOpen.addEventListener('click',()=>{gearModal.hidden=false;gearOpen.setAttribute('aria-expanded','true');$('#gear-close').focus();});
$('#gear-close').addEventListener('click',closeGearShop);
gearModal.addEventListener('click',event=>{if(event.target===gearModal)closeGearShop();});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!gearModal.hidden)closeGearShop();});
const cosmeticModal=$('#cosmetic-modal'), cosmeticOpen=$('#cosmetic-shop-open');
function closeCosmeticShop() {cosmeticModal.hidden=true;cosmeticOpen.setAttribute('aria-expanded','false');cosmeticOpen.focus();}
cosmeticOpen.addEventListener('click',()=>{cosmeticModal.hidden=false;cosmeticOpen.setAttribute('aria-expanded','true');$('#cosmetic-close').focus();});
$('#cosmetic-close').addEventListener('click',closeCosmeticShop);
cosmeticModal.addEventListener('click',event=>{if(event.target===cosmeticModal)closeCosmeticShop();});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!cosmeticModal.hidden)closeCosmeticShop();});
$('#plot').addEventListener('click',event=>{
  if (event.target.closest('.free-bed')) return;
  if (lockToolActive) {notify('Tap a planted seed to lock or unlock it.');return;}
  if (instantGrowToolActive) {notify('Tap a growing plant to finish it instantly.');return;}
  const index=state.beds.findIndex(bed=>!bed);
  if (index<0) {notify('Your plot is full. Expand it to add planting space.');return;}
  const rect=$('#plot').getBoundingClientRect();
  const x=Math.max(6,Math.min(94,(event.clientX-rect.left)/rect.width*100));
  const y=Math.max(8,Math.min(92,(event.clientY-rect.top)/rect.height*100));
  plant(index,{x,y});
});
$('#plot-expansion').addEventListener('click',expandPlot);
const customizeToggle=$('#plot-customize-toggle'), customizer=$('#plot-customizer');
customizeToggle.addEventListener('click',()=>{
  customizer.hidden=!customizer.hidden;
  customizeToggle.setAttribute('aria-expanded',String(!customizer.hidden));
});
customizer.querySelectorAll('[data-plot-style]').forEach(button=>button.addEventListener('click',()=>{
  state.plotStyle=button.dataset.plotStyle;
  save();renderBeds();
}));
$('#lock-tool').addEventListener('click',()=>setLockTool(!lockToolActive));
$('#instant-grow-tool').addEventListener('click',()=>setInstantGrowTool(!instantGrowToolActive));
const themeToggle=$('#theme-toggle'), themeMenu=$('#theme-menu');
const GARDEN_THEMES=new Set(['meadow','sakura','ocean','moonlight']);
function setTheme(theme,remember=false) {
  if (!GARDEN_THEMES.has(theme)) theme='meadow';
  document.body.dataset.theme=theme;
  document.body.classList.toggle('dark-mode',theme==='moonlight');
  document.querySelectorAll('[data-theme-choice]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.themeChoice===theme)));
  const themeColor={meadow:'#f4f1e7',sakura:'#fff3f5',ocean:'#edf7fb',moonlight:'#171d19'}[theme];
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content',themeColor);
  if (remember) {try {localStorage.setItem('little-garden-theme',theme);} catch {}}
}
let savedTheme='meadow';
try {savedTheme=localStorage.getItem('little-garden-theme')||'meadow';} catch {}
setTheme(savedTheme==='dark'?'moonlight':savedTheme);
themeToggle.addEventListener('click',()=>{
  themeMenu.hidden=!themeMenu.hidden;
  themeToggle.setAttribute('aria-expanded',String(!themeMenu.hidden));
});
themeMenu.querySelectorAll('[data-theme-choice]').forEach(button=>button.addEventListener('click',()=>{
  setTheme(button.dataset.themeChoice,true);
  themeMenu.hidden=true;
  themeToggle.setAttribute('aria-expanded','false');
}));
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!themeMenu.hidden){themeMenu.hidden=true;themeToggle.setAttribute('aria-expanded','false');themeToggle.focus();}});
document.addEventListener('click',event=>{
  if (!themeMenu.hidden&&!themeMenu.contains(event.target)&&event.target!==themeToggle) {
    themeMenu.hidden=true;themeToggle.setAttribute('aria-expanded','false');
  }
});
const tutorial=$('#tutorial'), tutorialOpen=$('#tutorial-open');
const tutorialSteps=[
  {art:'🌱',title:'Buy a seed',copy:'Open the Seed Shop and pick a seed. Carrot and tomato are easy starters.'},
  {art:'🪴',title:'Plant it',copy:'Tap your seed in the inventory below the plot, then tap an empty spot in the garden.'},
  {art:'🌻',title:'Harvest & grow',copy:'When your plant is ready, tap it to harvest coins. Use them to buy more seeds.'}
];
let tutorialStep=0;
function renderTutorialStep(){
  const step=tutorialSteps[tutorialStep];
  $('#tutorial-art').textContent=step.art;
  $('#tutorial-title').textContent=step.title;
  $('#tutorial-copy').textContent=step.copy;
  $('#tutorial-count').textContent=(tutorialStep+1)+' / '+tutorialSteps.length;
  $('#tutorial-back').disabled=tutorialStep===0;
  $('#tutorial-next').textContent=tutorialStep===tutorialSteps.length-1?'Let’s grow':'Next';
}
function openTutorial(){
  tutorialStep=0;renderTutorialStep();tutorial.hidden=false;
  $('#tutorial-next').focus();
}
function closeTutorial(){
  tutorial.hidden=true;
  try {localStorage.setItem('little-garden-tutorial-seen','yes');} catch {}
  tutorialOpen.focus();
}
tutorialOpen.addEventListener('click',openTutorial);
$('#tutorial-close').addEventListener('click',closeTutorial);
$('#tutorial-skip').addEventListener('click',closeTutorial);
$('#tutorial-back').addEventListener('click',()=>{if(tutorialStep>0){tutorialStep--;renderTutorialStep();}});
$('#tutorial-next').addEventListener('click',()=>{
  if(tutorialStep<tutorialSteps.length-1){tutorialStep++;renderTutorialStep();}
  else closeTutorial();
});
tutorial.addEventListener('click',event=>{if(event.target===tutorial)closeTutorial();});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!tutorial.hidden)closeTutorial();});
$('#save-progress').addEventListener('click',()=>{
  notify(save()?'Garden progress saved on this device.':'Could not save — check your browser storage.');
});
render();tick();setInterval(tick,1000);
try {if(freshGarden&&localStorage.getItem('little-garden-tutorial-seen')!=='yes')openTutorial();} catch {}
// Restore shared stock independently; don't hold up the room connection on a DB-backed fetch.
connectLiveRoom();setupCreatorMenu();
