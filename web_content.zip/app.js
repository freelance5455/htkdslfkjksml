const DB_KEY="ALDHALEA_HOSPITAL_PATIENTS_DB";
const AUTOSAVE_DRAFT_KEY="ALDHALEA_HOSPITAL_AUTOSAVE_DRAFT_V1";
let currentPatientId=null;
let autosaveDraftDirty=false;
let autosaveRestoring=false;
const tableSchemas={cvdTable:["date","bp","pulse","text","text","text","text"],strokeTable:["date","text","text","text"],htnTable:["date","bp","pulse","text","text"],dmTable:["date","text","text","text","text","text"],generalFollowTable:["date","text","text","text","date"]};
const basicFieldIds=["patientName","fileNo","visitDate","age","gender","clinic","referralSource","phone","address","emergencyContact","bpScreen","pulseScreen","tempScreen","spo2Screen","weight","height","waist","smoking","qat","shamma","personalHistoryDetails","familyHistory","physicalActivityLevel","physicalActivityFrequency","lifestyle","medsAllergy","cvdDuration","cvdChestPain","cvdDyspnea","cvdSymptoms","cvdExam","strokeDuration","strokeWeakness","strokeSpeechVision","strokeExam","strokeMeds","htnDuration","htnAdherence","htnRedFlags","dmDuration","dmTherapy","dmAdherence","dmFbs","dmHba1c","dmRbs","dmFoot","dmComplications","diagnosis","treatmentPlan","recommendations","referral","referralReason","rxInstructions","followupNotes","nextVisit","followWeight","followBP","followPulse"];
const checkboxIds=["riskHTN","riskDM","riskCVD","riskKidney","riskStroke","riskLipid","riskObesity","riskOther","personalSurgery","personalHospitalization","personalAllergy","personalTransfusion","personalChronic","personalOther","familyHistoryNone","familyHistoryUnknown","familyHistoryHTN","familyHistoryDM","familyHistoryCVD","familyHistoryStroke","familyHistoryKidney","familyHistoryLipid","familyHistoryCancer","familyHistoryEarlyDeath","familyHistoryOther","activityWalking","activityExercise","activityPhysicalWork","activitySedentary","activityOther","medicationNone","medicationHypertension","medicationDiabetes","medicationCardiac","medicationAnticoagulant","medicationLipids","medicationRespiratory","medicationGI","medicationOther","giAdviceHydration","giAdviceFiber","giAdviceMealTiming","giAdviceFoodDiary","giAdviceReferral","giAdviceTests","patientEducationGiven","patientEducationUnderstood","patientWrittenInstructions"];const radioNames=["cvdKnown","strokeKnown","htnKnown","dmKnown"];
const extraFieldIds=["conditionHTNStatus","conditionDMStatus","conditionCVDStatus","conditionStrokeStatus","comorbidDiagnoses","differentialDiagnosis","diagnosticCertainty","diagnosisCodeNotes","doctorNotes","notesDoctorName","notesDate","treatmentGoals","reassessmentPlan","drugPlan","nonDrugPlan","plannedInvestigations","giSymptoms","giBowel","nutritionStatus","nutritionAppetite","foodIntolerance","dietaryRestrictions","recommendedFoods","foodsToAvoid","mealPlan","fluidsFiber","giFollowupPlan","giDietitianNotes","emergencyInstructions","patientMedicationAdvice","patientAvoidAdvice","patientFoodAdvice","patientLifestyleAdvice","patientSameDaySigns","patientFollowupTiming","patientFollowupInstructions","patientUnderstandingNotes","patientCarePlanText","patientCareVisitItems","hospitalCarePlanText","hospitalCareNextVisitItems","hospitalCareAttachments","clinicalAssistantNotes"];

document.addEventListener("DOMContentLoaded",()=>{document.getElementById("visitDate").value=todayISO();normalizePatientNumbering();ensureCurrentFileNo();initializeTables();setupSectionToggles();initializeConditionWorkflow();updateHeaderSummaries();renderPatients();updateSummary();updateReports();refreshPatientFiles();initializeAutoDraft();initializeCatalogs();integrateCatalogToolsIntoRecords();initializeHeaderActionUI();initializeOtherDiseases();initializeCareToolsMenu();initializeCareReminders()});
function setupMutuallyExclusiveOptions(){document.querySelectorAll('[data-choice-none]').forEach(none=>none.addEventListener('change',()=>{if(!none.checked)return;const group=none.dataset.choiceNone;document.querySelectorAll(`[data-choice-option="${group}"]`).forEach(item=>item.checked=false);document.querySelectorAll(`[data-choice-none="${group}"]`).forEach(item=>{if(item!==none)item.checked=false});persistAutoDraft?.()}));document.querySelectorAll('[data-choice-option]').forEach(option=>option.addEventListener('change',()=>{if(!option.checked)return;const group=option.dataset.choiceOption;document.querySelectorAll(`[data-choice-none="${group}"]`).forEach(item=>item.checked=false);persistAutoDraft?.()}));}
document.addEventListener("DOMContentLoaded",setupMutuallyExclusiveOptions);
function todayISO(){const d=new Date(),off=d.getTimezoneOffset();return new Date(d.getTime()-off*60000).toISOString().slice(0,10)}
function val(id){const e=document.getElementById(id);return e?e.value:""}function setVal(id,v){const e=document.getElementById(id);if(!e)return;if(e.type==="checkbox")e.checked=!!v;else e.value=v??""}
function getRadio(n){const e=document.querySelector(`input[name="${n}"]:checked`);return e?e.value:""}function setRadio(n,v){document.querySelectorAll(`input[name="${n}"]`).forEach(r=>r.checked=r.value===v)}
function calculateBMI(){const w=parseFloat(val("weight")),hcm=parseFloat(val("height")),e=document.getElementById("bmi");if(w>0&&hcm>0)e.value=(w/((hcm/100)**2)).toFixed(1);else e.value=""}

/* ===== Searchable/importable laboratory and medication catalogues ===== */
const LAB_CATALOG_KEY="ALDHALEA_HOSPITAL_LAB_CATALOG_V1";
const MED_CATALOG_KEY="ALDHALEA_HOSPITAL_MEDICATION_CATALOG_V1";
function defaultLabCatalog(){return [
  {name:"صورة دم كاملة",code:"CBC",type:"مخبري",unit:"",reference:""},
  {name:"سكر صائم",code:"FBS",type:"مخبري",unit:"mg/dL",reference:""},
  {name:"الهيموغلوبين السكري",code:"HbA1c",type:"مخبري",unit:"%",reference:""},
  {name:"كرياتينين",code:"Creatinine",type:"مخبري",unit:"mg/dL",reference:""},
  {name:"دهون الدم",code:"Lipid Profile",type:"مخبري",unit:"",reference:""},
  {name:"إنزيمات الكبد",code:"LFT",type:"مخبري",unit:"",reference:""},
  {name:"تحليل بول",code:"Urinalysis",type:"مخبري",unit:"",reference:""}
]}
function catalogStorageKey(type){return type==="labs"?LAB_CATALOG_KEY:MED_CATALOG_KEY}
function readCatalog(type){
  const key=catalogStorageKey(type);
  try{const raw=localStorage.getItem(key);if(raw!==null){const parsed=JSON.parse(raw);return Array.isArray(parsed)?parsed.filter(x=>x&&typeof x.name==="string"):[];}}
  catch(err){console.error("Catalog read failed",err)}
  const seeded=type==="labs"?defaultLabCatalog():[];
  writeCatalog(type,seeded);return seeded;
}
function writeCatalog(type,items){localStorage.setItem(catalogStorageKey(type),JSON.stringify(items));return items}
function normalizeCatalogText(value){return String(value??"").trim()}
function catalogKey(item){const code=normalizeCatalogText(item.code).toLocaleLowerCase();return code?"code:"+code:"name:"+normalizeCatalogText(item.name).toLocaleLowerCase()}
function fieldFromObject(row,keys){
  if(!row||typeof row!=="object")return "";
  const keyNorm=k=>String(k).toLocaleLowerCase().replace(/[\s_\-./()]+/g,"");
  const normalized=new Map(Object.keys(row).map(k=>[keyNorm(k),row[k]]));
  for(const k of keys){const v=normalized.get(keyNorm(k));if(v!==undefined&&v!==null&&String(v).trim()!=="")return String(v).trim()}
  return "";
}
function normalizeCatalogItem(type,row){
  if(Array.isArray(row)){
    if(type==="labs")row={name:row[0],code:row[1],type:row[2],unit:row[3],reference:row[4]};
    else row={name:row[0],code:row[1],strength:row[2],dose:row[3],frequency:row[4],route:row[5],duration:row[6],quantity:row[7],instructions:row[8]};
  }
  const name=fieldFromObject(row,["name","اسم","اسم الصنف","اسم التحليل","اسم الفحص","اسم الخدمة","التحليل","الفحص","الخدمة","drug","medicine","medication","test","service","item","generic","generic name","اسم الدواء","الدواء","المادة الفعالة"]);
  if(!name)return null;
  if(type==="labs")return {
    name,code:fieldFromObject(row,["code","رمز","كود","رقم الخدمة","service code","test code","code id"]),
    type:fieldFromObject(row,["type","نوع","نوع الفحص","نوع الخدمة"])||"مخبري",
    unit:fieldFromObject(row,["unit","الوحدة","وحدة","result unit"]),
    reference:fieldFromObject(row,["reference","range","reference range","المعدل المرجعي","المدى المرجعي","المرجع"])
  };
  return {
    name,code:fieldFromObject(row,["code","رمز","كود","رقم الدواء","drug code"]),
    strength:fieldFromObject(row,["strength","التركيز","العيار","form","الشكل الصيدلاني"]),
    dose:fieldFromObject(row,["dose","الجرعة","الجرعة الافتراضية"]),
    frequency:fieldFromObject(row,["frequency","التكرار","عدد المرات"]),
    route:fieldFromObject(row,["route","الطريق","طريق الإعطاء"]),
    duration:fieldFromObject(row,["duration","المدة","مدة العلاج"]),
    quantity:fieldFromObject(row,["quantity","الكمية"]),
    instructions:fieldFromObject(row,["instructions","تعليمات","تعليمات الاستعمال","ملاحظات"])
  };
}
function mergeCatalog(type,imported){
  const current=readCatalog(type),map=new Map(current.map(item=>[catalogKey(item),item]));let added=0,updated=0;
  imported.forEach(raw=>{const item=normalizeCatalogItem(type,raw);if(!item)return;const key=catalogKey(item);if(map.has(key)){map.set(key,{...map.get(key),...Object.fromEntries(Object.entries(item).filter(([,v])=>normalizeCatalogText(v)!==""))});updated++}else{map.set(key,item);added++}});
  const merged=[...map.values()].sort((a,b)=>a.name.localeCompare(b.name,"ar"));writeCatalog(type,merged);return {items:merged,added,updated};
}
function catalogSearchText(item){return Object.values(item||{}).map(v=>String(v??"")).join(" ").toLocaleLowerCase()}
function renderCatalogOptions(type){
  const isLab=type==="labs",search=document.getElementById(isLab?"labCatalogSearch":"medCatalogSearch"),select=document.getElementById(isLab?"labCatalogSelect":"medCatalogSelect"),count=document.getElementById(isLab?"labCatalogCount":"medCatalogCount");
  if(!select)return;
  const all=readCatalog(type),q=normalizeCatalogText(search?.value).toLocaleLowerCase();const filtered=all.filter(item=>!q||catalogSearchText(item).includes(q));
  const previous=select.value;select.innerHTML="";
  const first=document.createElement("option");first.value="";first.textContent=filtered.length?(isLab?"اختر تحليلًا من القائمة":"اختر دواءً من القائمة"):(q?"لا توجد نتائج مطابقة":"القائمة فارغة — استورد ملفًا أو أضف صنفًا");select.appendChild(first);
  filtered.forEach(item=>{const option=document.createElement("option");option.value=catalogKey(item);option.textContent=[item.name,item.code,item.strength].filter(Boolean).join(" — ");select.appendChild(option)});
  if(previous&&filtered.some(item=>catalogKey(item)===previous))select.value=previous;
  if(count)count.textContent=isLab?`${all.length} تحليل محفوظ · ${filtered.length} نتيجة`:`${all.length} دواء محفوظ · ${filtered.length} نتيجة`;
  return filtered;
}
function renderLabCatalogOptions(){return renderCatalogOptions("labs")}
function renderMedicationCatalogOptions(){return renderCatalogOptions("medications")}
function initializeCatalogs(){
  readCatalog("labs");readCatalog("medications");renderLabCatalogOptions();renderMedicationCatalogOptions();
  // These catalogue files are independent from the patient form and are kept on this device.
}
function parseCatalogCSV(text){
  const firstLine=String(text).split(/\r?\n/,1)[0]||"";const commas=(firstLine.match(/,/g)||[]).length,semis=(firstLine.match(/;/g)||[]).length,tabs=(firstLine.match(/\t/g)||[]).length;const sep=tabs>commas&&tabs>semis?"\t":semis>commas?";":",";
  const rows=[];let row=[],cell="",quoted=false;const input=String(text).replace(/^\uFEFF/,"");
  for(let i=0;i<input.length;i++){const ch=input[i];if(ch==='"'){if(quoted&&input[i+1]==='"'){cell+='"';i++}else quoted=!quoted}else if(ch===sep&&!quoted){row.push(cell.trim());cell=""}else if((ch==="\n"||ch==="\r")&&!quoted){if(ch==="\r"&&input[i+1]==="\n")i++;row.push(cell.trim());if(row.some(v=>v!==""))rows.push(row);row=[];cell=""}else cell+=ch}
  row.push(cell.trim());if(row.some(v=>v!==""))rows.push(row);if(!rows.length)return [];
  const norm=s=>String(s).toLocaleLowerCase().replace(/[\s_\-./()]+/g,"");
  const headerAliases=new Set(["name","اسم","اسمالصنف","اسمالتحليل","اسمالفحص","اسمالخدمة","التحليل","الفحص","الخدمة","drug","medicine","medication","test","service","item","generic","genericname","اسمالدواء","الدواء","المادةالفعالة","code","رمز","كود","type","نوع","unit","الوحدة","reference","المعدل المرجعي","strength","التركيز","dose","الجرعة","frequency","التكرار","route","الطريق","duration","المدة","quantity","الكمية","instructions","تعليمات","تعليماتالاستعمال"]);
  const first=rows[0].map(norm),hasHeader=first.some(v=>headerAliases.has(v));const body=hasHeader?rows.slice(1):rows;return body.map(row=>{if(!hasHeader)return row;const obj={};first.forEach((k,i)=>{obj[k]=row[i]??""});return obj}).filter(row=>Array.isArray(row)?row.some(v=>String(v).trim()):Object.values(row).some(v=>String(v).trim()));
}
async function importCatalogFile(type,event){
  const input=event?.target||document.getElementById(type==="labs"?"labCatalogFile":"medCatalogFile"),file=input?.files?.[0];if(!file)return;
  try{
    const text=await file.text();let records;
    if(/\.json$/i.test(file.name)||/^\s*[\[{]/.test(text)){
      const parsed=JSON.parse(text);
      if(Array.isArray(parsed))records=parsed;
      else if(parsed&&typeof parsed==="object"){
        const possible=type==="labs"?["labs","laboratoryServices","laboratory","services","tests","items","catalog"]:["medications","medicines","drugs","items","catalog"];
        const key=possible.find(k=>Array.isArray(parsed[k]));records=key?parsed[key]:[];
      }else records=[];
    }else records=parseCatalogCSV(text);
    if(!Array.isArray(records)||!records.length)throw new Error("لم نعثر على أصناف قابلة للاستيراد. راجع تنسيق CSV أو JSON وقالب القائمة.");
    const valid=records.map(item=>normalizeCatalogItem(type,item)).filter(Boolean);
    if(!valid.length)throw new Error("لم تتضمن القائمة اسمًا واضحًا لأي صنف. استخدم عمود name أو اسم الصنف/الدواء.");
    const result=mergeCatalog(type,valid);if(type==="labs")renderLabCatalogOptions();else renderMedicationCatalogOptions();
    alert(`تم استيراد القائمة ودمجها بنجاح.\nالأصناف الجديدة: ${result.added}\nالأصناف الموجودة/المحدّثة: ${result.updated}\nالإجمالي في القائمة: ${result.items.length}`);
  }catch(err){console.error(err);alert("تعذر استيراد القائمة: "+(err?.message||"تنسيق ملف غير صالح"))}
  finally{if(input)input.value=""}
}
function addNewCatalogItem(type){
  let item;
  if(type==="labs")item={name:val("labCatalogNewName"),code:val("labCatalogNewCode"),type:val("labCatalogNewType")||"مخبري",unit:val("labCatalogNewUnit"),reference:val("labCatalogNewReference")};
  else item={name:val("medCatalogNewName"),code:val("medCatalogNewCode"),strength:val("medCatalogNewStrength"),dose:val("medCatalogNewDose"),frequency:val("medCatalogNewFrequency"),route:val("medCatalogNewRoute"),duration:val("medCatalogNewDuration"),instructions:val("medCatalogNewInstructions")};
  item=normalizeCatalogItem(type,item);if(!item){alert("أدخل اسم الصنف أولًا.");return false;}
  const result=mergeCatalog(type,[item]);
  if(type==="labs"){["labCatalogNewName","labCatalogNewCode","labCatalogNewUnit","labCatalogNewReference"].forEach(id=>setVal(id,""));renderLabCatalogOptions();document.getElementById("labCatalogSelect").value=catalogKey(item);}
  else{["medCatalogNewName","medCatalogNewCode","medCatalogNewStrength","medCatalogNewDose","medCatalogNewFrequency","medCatalogNewRoute","medCatalogNewDuration","medCatalogNewInstructions"].forEach(id=>setVal(id,""));renderMedicationCatalogOptions();document.getElementById("medCatalogSelect").value=catalogKey(item);}
  alert(result.added?"تم حفظ الصنف الجديد في القائمة المحلية.":"الصنف موجود مسبقًا؛ تم تحديث بياناته غير الفارغة.");return true;
}
function selectedCatalogItem(type){const select=document.getElementById(type==="labs"?"labCatalogSelect":"medCatalogSelect");if(!select?.value){alert("ابحث واختر صنفًا من القائمة أولًا.");return null;}return readCatalog(type).find(item=>catalogKey(item)===select.value)||null}
function addSelectedLabCatalogItem(){
  const item=selectedCatalogItem("labs");if(!item)return false;
  const displayName=item.name+(item.code&&!item.name.toLocaleLowerCase().includes(item.code.toLocaleLowerCase())?` (${item.code})`:"");addLab(item.type||"مخبري",displayName);
  const row=document.querySelector("#labsTable tbody tr:last-child"),inputs=row?.querySelectorAll("input")||[];if(inputs[2])inputs[2].value=item.unit||"";if(inputs[3])inputs[3].value=item.reference||"";
  if(inputs[5])inputs[5].value="أُضيف من قائمة المختبر المحفوظة";persistAutoDraft?.();return true;
}
function addSelectedMedicationCatalogItem(){
  const item=selectedCatalogItem("medications");if(!item)return false;
  addPrescription();const inputs=document.querySelector("#rxTable tbody tr:last-child")?.querySelectorAll("input,select,textarea")||[];
  const name=[item.name,item.strength].filter(Boolean).join(" ");const values=[name,item.dose||"",item.frequency||"",item.route||"",item.duration||"",item.quantity||"",item.instructions||""];
  values.forEach((value,i)=>{if(inputs[i])setControlValue(inputs[i],value)});persistAutoDraft?.();return true;
}
async function downloadCatalogTemplate(type){
  const labs=type==="labs";const headers=labs?["name","code","type","unit","reference"]:["name","code","strength","dose","frequency","route","duration","quantity","instructions"];
  const csv="\uFEFF"+headers.join(",")+"\r\n";await downloadBlob(csv,labs?"قالب_قائمة_المختبر.csv":"قالب_قائمة_الأدوية.csv","text/csv;charset=utf-8");
}
function saveCatalogsToBackup(){return {labs:readCatalog("labs"),medications:readCatalog("medications")}}
function restoreCatalogsFromBackup(catalogs){if(!catalogs||typeof catalogs!=="object")return false;if(Array.isArray(catalogs.labs))writeCatalog("labs",catalogs.labs.map(x=>normalizeCatalogItem("labs",x)).filter(Boolean));if(Array.isArray(catalogs.medications))writeCatalog("medications",catalogs.medications.map(x=>normalizeCatalogItem("medications",x)).filter(Boolean));renderLabCatalogOptions();renderMedicationCatalogOptions();return true}

function initializeTables(){Object.keys(tableSchemas).forEach(id=>{if(!document.querySelector(`#${id} tbody`).children.length)addRow(id,tableSchemas[id],true)});if(!document.querySelector("#diagnosticsTable tbody").children.length)addDiagnosticRow() }
function addRow(tableId,schema,silent=false,preset=[]){const tb=document.querySelector(`#${tableId} tbody`);if(!tb)return;const tr=document.createElement("tr");tr.appendChild(cellText(tb.children.length+1));schema.forEach((kind,i)=>{const td=document.createElement("td");let el;if(kind==="date"){el=document.createElement("input");el.type="date";el.value=preset[i]||todayISO()}else if(kind==="bp"){el=document.createElement("input");el.type="text";el.placeholder="130/80";el.value=preset[i]||""}else if(kind==="pulse"){el=document.createElement("input");el.type="text";el.placeholder="ض/د";el.value=preset[i]||""}else if(kind==="selectStage"){el=document.createElement("select");el.innerHTML='<option value="">اختر</option><option>المرحلة الأولى</option><option>المرحلة الثانية</option><option>المرحلة الثالثة</option><option>المرحلة الرابعة</option><option>المرحلة الخامسة</option>';el.value=preset[i]||""}else{el=document.createElement("input");el.type="text";el.value=preset[i]||""}td.appendChild(el);tr.appendChild(td)});const td=document.createElement("td");td.className="action-cell no-print";td.innerHTML='<button type="button" class="delete-row" onclick="removeRow(this)">حذف</button>';tr.appendChild(td);tb.appendChild(tr);renumberTable(tableId);if(!silent)updateSummary()}
function removeRow(btn){const tr=btn.closest("tr"),table=tr.closest("table");if(!tr||!table)return;const label=table.querySelector("thead th:nth-child(2)")?.textContent||"هذا الصف";if(!confirm(`تأكيد الحذف\nهل تريد حذف هذا الصف من جدول «${label}»؟ لا يمكن التراجع عن الحذف من النموذج الحالي قبل حفظه.`))return;tr.remove();renumberTable(table.id)}
function renumberTable(id){const tb=document.querySelector(`#${id} tbody`);if(!tb)return;[...tb.children].forEach((tr,i)=>tr.children[0].textContent=i+1)}
function getTableData(id){const t=document.getElementById(id);if(!t)return[];return[...t.tBodies[0].rows].map(tr=>[...tr.cells].slice(1,-1).map(td=>td.querySelector("input,select,textarea")?.value||""))}
function setTableData(id,rows,schema){const tb=document.querySelector(`#${id} tbody`);tb.innerHTML="";if(rows?.length)rows.forEach(r=>addRow(id,schema,true,r));else addRow(id,schema,true);renumberTable(id)}
function inputCell(v="",ph=""){const td=document.createElement("td"),i=document.createElement("input");i.type="text";i.value=v; i.placeholder=ph;td.appendChild(i);return td}
function cellText(t){const td=document.createElement("td");td.textContent=t;return td}
function addLab(type="",name=""){const tb=document.querySelector("#labsTable tbody"),tr=document.createElement("tr");tr.appendChild(cellText(tb.children.length+1));const st=document.createElement("td"),s=document.createElement("select");s.innerHTML='<option value="">اختر</option><option>مخبري</option><option>تصويري</option><option>وظيفي</option><option>منظار</option><option>نسيجي</option><option>آخر</option>';s.value=type;st.appendChild(s);tr.appendChild(st);tr.appendChild(inputCell(name,"اسم الفحص"));tr.appendChild(inputCell("","النتيجة"));tr.appendChild(inputCell("","الوحدة"));tr.appendChild(inputCell("","المعدل المرجعي"));const dt=document.createElement("td"),di=document.createElement("input");di.type="date";di.value=todayISO();dt.appendChild(di);tr.appendChild(dt);tr.appendChild(inputCell("","ملاحظات"));const a=document.createElement("td");a.className="action-cell no-print";a.innerHTML='<button type="button" class="delete-row" onclick="removeRow(this)">حذف</button>';tr.appendChild(a);tb.appendChild(tr);renumberTable("labsTable")}
function addLabPreset(ar,en){addLab("مخبري",`${ar} (${en})`)}
function prefillDiseaseFollowupRow(tableId){
  const row=document.querySelector(`#${tableId} tbody tr:last-child`);if(!row)return;
  const fields=row.querySelectorAll("input,select,textarea");
  const fill=(index,value)=>{if(fields[index]&&!String(fields[index].value||"").trim()&&String(value||"").trim())fields[index].value=value};
  if(tableId==="htnTable"){fill(1,val("bpScreen"));fill(2,val("pulseScreen"));fill(3,val("medsAllergy"));}
  if(tableId==="dmTable"){fill(1,val("dmFbs"));fill(2,val("dmHba1c"));fill(3,val("dmTherapy"));}
  if(tableId==="cvdTable"){fill(1,val("bpScreen"));fill(2,val("pulseScreen"));}
  if(tableId==="strokeTable"){fill(1,val("bpScreen"));fill(2,val("pulseScreen"));}
}
function prescriptionChoiceCell(placeholder,options){
  const td=document.createElement("td"),sel=document.createElement("select");
  const first=document.createElement("option");first.value="";first.textContent=placeholder;sel.appendChild(first);
  options.forEach(value=>{const opt=document.createElement("option");opt.value=value;opt.textContent=value;sel.appendChild(opt)});
  const custom=document.createElement("option");custom.value="__custom__";custom.textContent="قيمة مخصصة…";sel.appendChild(custom);
  sel.addEventListener("change",()=>{if(sel.value==="__custom__"){const v=prompt("أدخل القيمة التي حددها الطبيب:");if(v&&v.trim()){const opt=document.createElement("option");opt.value=v.trim();opt.textContent=v.trim();sel.insertBefore(opt,custom);sel.value=opt.value;}else sel.value="";}persistAutoDraft?.();});
  td.appendChild(sel);return td;
}
function setControlValue(control,value){const v=String(value??"");if(control.tagName==="SELECT"&&v&&!Array.from(control.options).some(o=>o.value===v)){const opt=document.createElement("option");opt.value=v;opt.textContent=v;control.add(opt);}control.value=v;}
function addPrescription(){
  const tb=document.querySelector("#rxTable tbody");if(!tb)return;
  const tr=document.createElement("tr");tr.appendChild(cellText(tb.children.length+1));
  tr.appendChild(inputCell("","اسم الدواء / المادة الفعالة"));
  tr.appendChild(prescriptionChoiceCell("اختر الجرعة",["¼ قرص","½ قرص","1 قرص","2 قرص","1 مل","2.5 مل","5 مل","10 مل","250 mg","500 mg","1 g","حسب الوزن","حسب الوصفة المعتمدة"]));
  tr.appendChild(prescriptionChoiceCell("اختر التكرار",["مرة يوميًا","مرتين يوميًا","3 مرات يوميًا","4 مرات يوميًا","كل 6 ساعات","كل 8 ساعات","كل 12 ساعة","أسبوعيًا","عند اللزوم وفق الوصفة","حسب الوصفة المعتمدة"]));
  tr.appendChild(prescriptionChoiceCell("اختر الطريق",["عن طريق الفم","وريدي","عضلي","تحت الجلد","موضعي","استنشاق","قطرات عين","قطرات أذن","شرجي","حسب الوصفة المعتمدة"]));
  ["المدة","الكمية","تعليمات الاستعمال"].forEach(p=>tr.appendChild(inputCell("",p)));
  const a=document.createElement("td");a.className="action-cell no-print";a.innerHTML='<button type="button" class="delete-row" onclick="removeRow(this)">حذف</button>';tr.appendChild(a);tb.appendChild(tr);renumberTable("rxTable");
}
function getSimpleTable(id){return getTableData(id)}
function setSimpleTable(id,rows,maker){const tb=document.querySelector(`#${id} tbody`);if(!tb)return;tb.innerHTML="";(rows||[]).forEach(maker);renumberTable(id)}

function clearClinicalCalculatorFields(){
  const root=document.getElementById("calculator");if(!root)return;
  root.querySelectorAll('input[type="number"]').forEach(el=>{el.value="";});
  root.querySelectorAll('select[id^="cc"]').forEach(el=>{el.selectedIndex=0;});
  const context=document.getElementById("ccPatientContext");if(context)context.value="";
  const results=document.getElementById("clinicalCalcResults");if(results)results.innerHTML='<div class="calc-empty">أدخل القيم المتاحة ثم اضغط «حساب النتائج».</div>';
  const text=document.getElementById("clinicalCalcText");if(text)text.value="";
  const risk=document.getElementById("clinicalRiskResults");if(risk)risk.innerHTML='<div class="calc-empty">أكمل عوامل الخطورة ذات الصلة ثم احسب الدرجات.</div>';
}
function collectPatient(){const existing=currentPatientId?getDB().find(p=>p.id===currentPatientId):null;const d=existing?{...existing}:{};basicFieldIds.forEach(id=>d[id]=val(id));checkboxIds.forEach(id=>d[id]=document.getElementById(id).checked);radioNames.forEach(n=>d[n]=getRadio(n));extraFieldIds.forEach(id=>d[id]=val(id));["cvdTable","strokeTable","htnTable","dmTable","generalFollowTable"].forEach(id=>d[id]=getTableData(id));d.labsTable=getSimpleTable("labsTable");d.rxTable=getSimpleTable("rxTable");d.diagnosticsTable=getSimpleTable("diagnosticsTable");d.otherDiseases=getOtherDiseases();d.clinicalCalculator=collectCalculatorDraft();d.activeSections=getActiveSections();d.updatedAt=new Date().toISOString();return d}
function applyPatient(d){basicFieldIds.forEach(id=>setVal(id,d?.[id]??""));checkboxIds.forEach(id=>setVal(id,d?.[id]??false));radioNames.forEach(n=>setRadio(n,d?.[n]??""));extraFieldIds.forEach(id=>setVal(id,d?.[id]??""));calculateBMI();Object.keys(tableSchemas).forEach(id=>setTableData(id,d?.[id],tableSchemas[id]));renderOtherDiseases(migrateLegacyDiseases(d));setSimpleTable("labsTable",d?.labsTable,(r)=>{addLab(r?.[0]||"",r?.[1]||"");const e=document.querySelector("#labsTable tbody tr:last-child").querySelectorAll("input");e[1].value=r?.[2]||"";e[2].value=r?.[3]||"";e[3].value=r?.[4]||"";e[4].value=r?.[5]||"";e[5].value=r?.[6]||""});setSimpleTable("rxTable",d?.rxTable,(r)=>{addPrescription();[...document.querySelector("#rxTable tbody tr:last-child").querySelectorAll("input,select,textarea")].forEach((e,i)=>setControlValue(e,r?.[i]||""))});setSimpleTable("diagnosticsTable",d?.diagnosticsTable,(r)=>{addDiagnosticRow(r?.[0]||"",r?.[1]||"");const row=document.querySelector("#diagnosticsTable tbody tr:last-child");const els=row.querySelectorAll("input,select,textarea");[...els].forEach((e,i)=>e.value=r?.[i]||"")});if(Array.isArray(d?.clinicalCalculator))applyCalculatorDraft(d.clinicalCalculator);else clearClinicalCalculatorFields();setVal("serialNoDisplay",d?.serialNo??"");if(d?.activeSections)applyActiveSections(d.activeSections);refreshConditionWorkflow({infer:true});updateHeaderSummaries();updateSummary();updateReports();updateCurrentRecord() }
function getDB(){try{return JSON.parse(localStorage.getItem(DB_KEY)||"[]")}catch{return[]}}function setDB(d){localStorage.setItem(DB_KEY,JSON.stringify(d))}
const FILE_SEQ_KEY="ALDHALEA_HOSPITAL_FILE_SEQUENCE";
function parseGeneratedFileNo(fileNo){const m=String(fileNo||"").trim().match(/^DHM-(\d+)$/i);return m?Number(m[1]):0}
function formatGeneratedFileNo(number){return "DHM-"+String(number).padStart(6,"0")}
function maxSavedSerial(db=getDB()){
  let max=Number(localStorage.getItem(FILE_SEQ_KEY))||0;
  (db||[]).forEach(p=>{const s=Number(p?.serialNo)||0;const f=parseGeneratedFileNo(p?.fileNo);if(Number.isInteger(s)&&s>max)max=s;if(f>max)max=f;});
  return max;
}
function reserveNextPatientNumber(db=getDB()){
  const usedFiles=new Set((db||[]).map(p=>String(p?.fileNo||"").trim().toLocaleUpperCase()).filter(Boolean));
  const usedSerials=new Set((db||[]).map(p=>Number(p?.serialNo)).filter(n=>Number.isInteger(n)&&n>0));
  let number=maxSavedSerial(db)+1;
  while(usedFiles.has(formatGeneratedFileNo(number).toLocaleUpperCase())||usedSerials.has(number))number++;
  // This is a preview only. Do not consume the sequence until the record is successfully saved.
  return {number,fileNo:formatGeneratedFileNo(number)};
}
function normalizePatientNumbering(){
  const db=getDB();if(!Array.isArray(db)||!db.length)return;
  let changed=false;
  // Preserve the first occurrence of every valid serial; reserve all first-occurrence serials before repairing duplicates.
  let max=Math.max(Number(localStorage.getItem(FILE_SEQ_KEY))||0,...db.map(p=>Number(p?.serialNo)||0),...db.map(p=>parseGeneratedFileNo(p?.fileNo)),0);
  const originalKeys=db.map(p=>String(p?.fileNo||'').trim().toLocaleUpperCase());
  const fileKeyCounts=new Map();originalKeys.forEach(k=>{if(k)fileKeyCounts.set(k,(fileKeyCounts.get(k)||0)+1)});
  const candidates=db.map(p=>{
    const serial=Number(p?.serialNo),fromFile=parseGeneratedFileNo(p?.fileNo);
    const n=Number.isInteger(serial)&&serial>0?serial:fromFile;
    return Number.isInteger(n)&&n>0?n:0;
  });
  const reservedSerials=new Set(),keepSerial=candidates.map(n=>{
    if(!n||reservedSerials.has(n))return false;
    reservedSerials.add(n);return true;
  });
  // If a serial is duplicated but its DHM file number is unique, prefer that file number's unused suffix.
  candidates.forEach((n,i)=>{
    if(keepSerial[i])return;
    const fileNo=parseGeneratedFileNo(db[i]?.fileNo),key=originalKeys[i];
    if(fileNo>0&&key&&(fileKeyCounts.get(key)===1)&&!reservedSerials.has(fileNo)){
      candidates[i]=fileNo;keepSerial[i]=true;reservedSerials.add(fileNo);
    }
  });
  const usedSerials=new Set(reservedSerials);
  db.forEach((p,i)=>{
    let n=candidates[i];
    if(!keepSerial[i]){
      do{max++;}while(usedSerials.has(max));
      n=max;usedSerials.add(n);
    }
    if(Number(p.serialNo)!==n){p.serialNo=n;changed=true;}
  });
  // Keep the first non-empty file number; reserve it case-insensitively before generating replacements.
  const reservedFileKeys=new Set();
  originalKeys.forEach(k=>{if(k)reservedFileKeys.add(k)});
  const keptFileKeys=new Set(),usedFileKeys=new Set();
  db.forEach((p,i)=>{
    const original=String(p?.fileNo||'').trim(),key=original.toLocaleUpperCase();
    if(original&&!keptFileKeys.has(key)){
      keptFileKeys.add(key);usedFileKeys.add(key);
      if(p.fileNo!==original){p.fileNo=original;changed=true;}
      return;
    }
    let fileNo=formatGeneratedFileNo(Number(p.serialNo)||1),fileKey=fileNo.toLocaleUpperCase();
    if(usedFileKeys.has(fileKey)||reservedFileKeys.has(fileKey)){
      do{max++;fileNo=formatGeneratedFileNo(max);fileKey=fileNo.toLocaleUpperCase();}
      while(usedSerials.has(max)||usedFileKeys.has(fileKey)||reservedFileKeys.has(fileKey));
      // Keep the visible serial and generated file number aligned for a repaired duplicate/blank file number.
      usedSerials.delete(Number(p.serialNo));p.serialNo=max;usedSerials.add(max);
    }
    if(p.fileNo!==fileNo){p.fileNo=fileNo;changed=true;}
    usedFileKeys.add(fileKey);
  });
  max=Math.max(max,...db.map(p=>Number(p?.serialNo)||0),...db.map(p=>parseGeneratedFileNo(p?.fileNo)),0);
  localStorage.setItem(FILE_SEQ_KEY,String(max));
  if(changed)setDB(db);
}
function ensureCurrentFileNo(){
  // Do not assign or consume a patient number while the form is only a draft.
  const field=document.getElementById("fileNo");
  if(!field)return;
  if(currentPatientId){const existing=getDB().find(p=>p.id===currentPatientId);if(existing)field.value=existing.fileNo||"";}
  updateHeaderSummaries();updateCurrentRecord();
}
function idGen(){return window.crypto?.randomUUID?.()||"p-"+Date.now()+"-"+Math.random().toString(16).slice(2)}
function savePatient(){
  const d=collectPatient();
  if(!d.patientName.trim()){alert("يرجى إدخال اسم المريض أولًا.");return false;}
  const db=getDB();
  const index=currentPatientId?db.findIndex(x=>x.id===currentPatientId):-1;
  if(currentPatientId&&index<0){alert("تعذر العثور على السجل المفتوح. افتح السجل من مدير السجلات مرة أخرى قبل الحفظ حتى لا تُنشئ نسخة غير مقصودة.");return false;}
  const isUpdate=index>=0;
  if(isUpdate){
    const existing=db[index];
    d.id=existing.id;
    d.serialNo=Number(existing.serialNo)||parseGeneratedFileNo(existing.fileNo);
    d.fileNo=existing.fileNo||formatGeneratedFileNo(d.serialNo||1);
    currentPatientId=existing.id;
  }else{
    const next=reserveNextPatientNumber(db);
    currentPatientId=idGen();
    d.id=currentPatientId;
    d.serialNo=next.number;
    d.fileNo=next.fileNo;
  }
  const savedId=currentPatientId;
  if(isUpdate)db[index]=d;else db.push(d);
  try{
    setDB(db);
    // Commit the sequence only after localStorage successfully accepted the patient record.
    const lastCommitted=Math.max(Number(localStorage.getItem(FILE_SEQ_KEY))||0,Number(d.serialNo)||0,parseGeneratedFileNo(d.fileNo));
    localStorage.setItem(FILE_SEQ_KEY,String(lastCommitted));
  }catch(err){
    console.error(err);
    if(!isUpdate)currentPatientId=null;
    alert("تعذر حفظ بيانات المريض في التخزين المحلي. تحقّق من مساحة التخزين ثم أعد المحاولة؛ لم يتم تأكيد الحفظ.");
    return false;
  }
  normalizePatientNumbering();
  const saved=getDB().find(p=>p.id===savedId);
  if(saved){setVal("serialNoDisplay",saved.serialNo||"");setVal("fileNo",saved.fileNo||"");}
  renderPatients();updateReports();updateHeaderSummaries();updateCurrentRecord();refreshPatientFiles();
  clearAutosavedDraft(isUpdate?"تم حفظ تحديثات السجل":"تم حفظ السجل النهائي");
  alert(isUpdate?`تم تحديث سجل المريض بنجاح. رقم المريض: ${saved?.serialNo||d.serialNo} — رقم الملف: ${saved?.fileNo||d.fileNo}`:`تم حفظ بيانات المريض بنجاح. رقم المريض التسلسلي: ${saved?.serialNo||d.serialNo} — رقم الملف: ${saved?.fileNo||d.fileNo}`);
  return true;
}
function loadPatient(id){
  const p=getDB().find(x=>x.id===id);
  if(!p){alert("لم يتم العثور على سجل المريض المطلوب.");return;}
  if(autosaveDraftDirty){
    const ok=confirm("توجد تغييرات محفوظة تلقائيًا كمسودة لم تُعتمد بعد. هل تريد تجاهل المسودة والانتقال إلى سجل آخر؟\nاضغط «إلغاء» للعودة إلى المسودة ومتابعة العمل.");
    if(!ok)return;
    clearAutosavedDraft("تم تجاهل المسودة السابقة");
  }
  currentPatientId=id;applyPatient(p);refreshPatientFiles();toggleManager(false);
  goToSection("patient");document.getElementById("patientName")?.focus({preventScroll:true});
  alert(`تم فتح سجل المريض في وضع التعديل. رقم المريض: ${p.serialNo||"—"} — رقم الملف: ${p.fileNo||"—"}. بعد التعديل اضغط «تحديث بيانات المريض».`);
}
function returnToEdit(){
  if(!currentPatientId||!getDB().some(p=>p.id===currentPatientId)){alert("افتح سجل مريض محفوظ من «السجلات» أولًا للعودة إلى تعديله.");return;}
  toggleManager(false);goToSection("patient");document.getElementById("patientName")?.focus({preventScroll:true});
}
async function deletePatientAttachments(patientId){
  const db=await openAttachmentDB();
  try{
    await new Promise((resolve,reject)=>{
      let tx;
      try{
        tx=db.transaction(ATTACH_STORE,"readwrite");
        const store=tx.objectStore(ATTACH_STORE);
        if(!store.indexNames.contains("patientId"))throw new Error("فهرس المريض غير موجود في مخزن المرفقات");
        const request=store.index("patientId").getAllKeys(patientId);
        request.onsuccess=()=>{try{(request.result||[]).forEach(key=>store.delete(key));}catch(err){reject(err);try{tx.abort()}catch{}}};
        request.onerror=()=>{reject(request.error||new Error("تعذر العثور على مرفقات المريض"));try{tx.abort()}catch{}};
        tx.oncomplete=resolve;
        tx.onerror=()=>reject(tx.error||new Error("فشلت معاملة حذف المرفقات"));
        tx.onabort=()=>reject(tx.error||new Error("أُلغيت معاملة حذف المرفقات"));
      }catch(err){reject(err);}
    });
  }finally{db.close();}
}
async function deletePatient(id){
  if(!confirm("تأكيد حذف سجل المريض\nسيُحذف السجل ومرفقاته المرتبطة من التخزين المحلي. هذا الإجراء لا يمكن التراجع عنه من داخل البرنامج."))return;
  const previous=getDB(),patient=previous.find(x=>x.id===id);
  if(!patient)return;
  const remaining=previous.filter(x=>x.id!==id);
  try{setDB(remaining);}catch(err){console.error(err);alert("تعذر تحديث مخزن السجلات؛ لم يكتمل الحذف.");return;}
  try{
    await deletePatientAttachments(id);
  }catch(err){
    console.error(err);
    try{
      setDB(previous);
      renderPatients();updateReports();updateCurrentRecord();await refreshPatientFiles();
      alert("تعذر حذف مرفقات المريض؛ أُعيد السجل إلى قائمة المرضى ولم يكتمل الحذف. افحص التخزين ثم أعد المحاولة.");
    }catch(rollbackError){
      console.error(rollbackError);
      alert("حدث خطأ أثناء حذف المرفقات وتعذر تأكيد استعادة السجل. لا تتابع تعديل البيانات؛ أعد تحميل البرنامج وافحص السجلات والنسخة الاحتياطية فورًا.");
    }
    return;
  }
  if(currentPatientId===id){clearAutosavedDraft("تم حذف السجل الحالي");newPatient(true);}
  renderPatients();updateReports();updateCurrentRecord();await refreshPatientFiles();
  alert("تم حذف سجل المريض ومرفقاته المرتبطة بنجاح.");
}
function newPatient(skipConfirm=false){if(!skipConfirm&&!confirm("تأكيد بدء سجل جديد\nسيتم تفريغ النموذج الحالي. ستُحذف المسودة المؤقتة من هذا الجهاز، لكن السجلات المحفوظة لن تُحذف. هل تريد المتابعة؟"))return;clearAutosavedDraft("تم بدء سجل جديد");currentPatientId=null;clearClinicalCalculatorFields();refreshPatientFiles();applyActiveSections(Object.keys(SECTION_LABELS));basicFieldIds.forEach(id=>setVal(id,""));checkboxIds.forEach(id=>setVal(id,false));radioNames.forEach(n=>setRadio(n,""));extraFieldIds.forEach(id=>setVal(id,""));setVal("serialNoDisplay","");ensureCurrentFileNo();document.getElementById("visitDate").value=todayISO();Object.keys(tableSchemas).forEach(id=>setTableData(id,[],tableSchemas[id]));setSimpleTable("labsTable",[],()=>addLab());setSimpleTable("rxTable",[],()=>addPrescription());renderOtherDiseases([]);setSimpleTable("diagnosticsTable",[],()=>addDiagnosticRow());calculateBMI();refreshConditionWorkflow({infer:true});updateHeaderSummaries();updateSummary();updateCurrentRecord();toggleManager(false);scrollTo({top:0,behavior:"smooth"})}
function renderPatients(){const body=document.getElementById("patientsBody"),q=(document.getElementById("searchPatients")?.value||"").toLowerCase();body.innerHTML="";const db=getDB().filter(p=>(`${p.patientName||""} ${p.fileNo||""}`).toLowerCase().includes(q)).sort((a,b)=>String(b.updatedAt||"").localeCompare(String(a.updatedAt||"")));if(!db.length){body.innerHTML='<tr><td colspan="6" style="text-align:center;color:#708284">لا توجد سجلات محفوظة.</td></tr>';return}db.forEach(p=>{const tr=document.createElement("tr");tr.innerHTML=`<td>${esc(String(p.serialNo||"—"))}</td><td>${esc(p.patientName||"—")}</td><td>${esc(p.fileNo||"—")}</td><td>${esc(p.visitDate||"—")}</td><td>${esc(p.clinic||"—")}</td><td class="action-cell"><button class="btn btn-outline" onclick="loadPatient('${p.id}')">تعديل</button> <button class="delete-row" onclick="deletePatient('${p.id}')">حذف</button></td>`;body.appendChild(tr)})}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function toggleManager(force){const p=document.getElementById("managerPanel");if(!p)return false;const opening=typeof force==="boolean"?force:!p.classList.contains("open");p.classList.toggle("open",opening);p.setAttribute("aria-hidden",opening?"false":"true");let backdrop=document.getElementById("managerBackdrop");if(opening){if(!backdrop){backdrop=document.createElement("div");backdrop.id="managerBackdrop";backdrop.className="manager-backdrop no-print";backdrop.addEventListener("click",()=>toggleManager(false));document.body.appendChild(backdrop);}renderPatients();}else{backdrop?.remove();document.getElementById("labCatalogPanel")?.classList.add("manager-catalog-hidden");document.getElementById("medicationCatalogPanel")?.classList.add("manager-catalog-hidden");}return opening;}
/* ===== Unified backup: all patient records + every patient attachment ===== */
function bytesToBase64(bytes){let binary="";const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));return btoa(binary)}
function base64ToBytes(base64){const binary=atob(base64);const bytes=new Uint8Array(binary.length);for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);return bytes}
async function exportDatabase(button){
  button=button||null; if(button){button.disabled=true;button.dataset.oldText=button.textContent;button.textContent="جارٍ تجهيز النسخة..."}
  try{
    const patients=getDB();let attachments=[];
    const db=await openAttachmentDB();
    try{attachments=await new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readonly"),req=tx.objectStore(ATTACH_STORE).getAll();req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error)})}finally{db.close()}
    const bundled=[];
    for(let i=0;i<attachments.length;i++){
      const f=attachments[i];let blob=f.blob;
      if(!(blob instanceof Blob)&&f.blob?.type!==undefined)blob=new Blob([f.blob],{type:f.type||"application/octet-stream"});
      if(!(blob instanceof Blob))throw new Error("تعذر قراءة المرفق: "+(f.name||"ملف بدون اسم"));
      const bytes=new Uint8Array(await blob.arrayBuffer());
      bundled.push({patientId:f.patientId,name:f.name||"ملف",relativePath:f.relativePath||f.name||"ملف",type:f.type||blob.type||"application/octet-stream",size:f.size??blob.size,lastModified:f.lastModified||0,addedAt:f.addedAt||new Date().toISOString(),dataBase64:bytesToBase64(bytes)});
      if(button&&i%5===0)button.textContent=`جارٍ تجهيز المرفقات ${i+1}/${attachments.length}...`;
    }
    const careReminders=getCareReminders();
    const backup={format:"ALDHALEA_HOSPITAL_FULL_BACKUP",version:2,createdAt:new Date().toISOString(),app:"الدليل الطبي الإكلينيكي الموحد - مستشفى الضالع الحديث",counts:{patients:patients.length,attachments:bundled.length,careReminders:careReminders.length},patients,attachments:bundled,careReminders,catalogs:saveCatalogsToBackup()};
    const blob=new Blob([JSON.stringify(backup)],{type:"application/json;charset=utf-8"}),filename=`نسخة_كاملة_مستشفى_الضالع_الحديث_${todayISO()}.json`;
    await downloadBlob(blob,filename,blob.type);
    alert(`تم تجهيز النسخة الاحتياطية الكاملة.\nالمرضى: ${patients.length}\nالمرفقات: ${bundled.length}\nتحقق من ظهور الملف في التنزيلات أو اختر مجلد حفظ معروفًا من نافذة المتصفح.`);
  }catch(err){console.error(err);alert("تعذر إنشاء النسخة الاحتياطية الكاملة. قد تكون مساحة التخزين أو الذاكرة غير كافية، أو تعذرت قراءة أحد المرفقات.")}
  finally{if(button){button.disabled=false;button.textContent=button.dataset.oldText||"⬇️ تصدير نسخة احتياطية كاملة";delete button.dataset.oldText}}
}
async function importDatabase(e){
  const f=e.target.files?.[0];if(!f)return;
  try{
    const parsed=JSON.parse(await f.text());
    // Backward compatibility: old JSON files contained patients only.
    if(Array.isArray(parsed)){
      if(parsed.some(p=>!p||typeof p!=="object"||Array.isArray(p)))throw new Error("ملف قديم غير صالح");
      if(!confirm("هذا ملف بيانات المرضى القديم ولا يحتوي على المرفقات. سيتم دمج سجلاته مع السجلات الحالية، ولن تتغير المرفقات الحالية. هل تريد المتابعة؟"))return;
      const m=new Map(getDB().map(p=>[p.id,p]));parsed.forEach(p=>{const id=p.id||idGen();m.set(id,{...p,id})});setDB([...m.values()]);normalizePatientNumbering();
      renderPatients();updateReports();updateCurrentRecord();alert("تم استيراد بيانات المرضى. تذكير: هذا الملف القديم لا يحتوي على المرفقات.");return;
    }
    if(!parsed||parsed.format!=="ALDHALEA_HOSPITAL_FULL_BACKUP"||parsed.version!==2||!Array.isArray(parsed.patients)||!Array.isArray(parsed.attachments))throw new Error("تنسيق النسخة غير مدعوم");
    if(parsed.patients.some(p=>!p||typeof p!=="object"||Array.isArray(p))||parsed.attachments.some(a=>!a||typeof a.patientId!=="string"||typeof a.dataBase64!=="string"))throw new Error("محتويات النسخة غير صالحة");
    if(parsed.careReminders!==undefined&&(!Array.isArray(parsed.careReminders)||parsed.careReminders.some(r=>!r||typeof r.id!=="string"||!r.dueAt||Number.isNaN(new Date(r.dueAt).getTime())||!['pending','alerted','done'].includes(r.status))))throw new Error("بيانات التذكير في النسخة غير صالحة");
    const summary=`المرضى: ${parsed.patients.length}\nالمرفقات: ${parsed.attachments.length}\n\nستحل هذه النسخة محل سجلات المرضى والمرفقات الموجودة حاليًا على هذا الجهاز. صدّر نسخة من الوضع الحالي أولًا إذا كنت تريد الاحتفاظ به.\n\nهل تريد المتابعة؟`;
    if(!confirm(summary))return;
    // Decode before modifying any stored data, so malformed files cannot erase current data.
    const decoded=parsed.attachments.map(a=>({patientId:a.patientId,name:a.name||"ملف",relativePath:a.relativePath||a.name||"ملف",type:a.type||"application/octet-stream",size:Number(a.size)||0,lastModified:Number(a.lastModified)||0,addedAt:a.addedAt||new Date().toISOString(),blob:new Blob([base64ToBytes(a.dataBase64)],{type:a.type||"application/octet-stream"})}));
    const oldPatients=getDB(),restoredPatients=parsed.patients.map(p=>({...p,id:p.id||idGen()}));
    // Save patient records first; if attachment restoration fails, roll records back.
    setDB(restoredPatients);
    try{
      const db=await openAttachmentDB();
      try{await new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readwrite"),store=tx.objectStore(ATTACH_STORE);store.clear();decoded.forEach(a=>store.add(a));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)})}finally{db.close()}
    }catch(restoreError){setDB(oldPatients);throw restoreError}
    normalizePatientNumbering();if(parsed.catalogs)restoreCatalogsFromBackup(parsed.catalogs);if(Array.isArray(parsed.careReminders))saveCareReminders(parsed.careReminders);currentPatientId=null;clearAutosavedDraft("تم استيراد نسخة احتياطية");renderPatients();updateReports();updateCurrentRecord();renderCareReminders();await refreshPatientFiles();
    alert(`تمت استعادة النسخة الاحتياطية الكاملة بنجاح.\nالمرضى: ${parsed.patients.length}\nالمرفقات: ${decoded.length}\nالتذكيرات: ${Array.isArray(parsed.careReminders)?parsed.careReminders.length:"لم تتضمن النسخة القديمة تذكيرات؛ أُبقيت التذكيرات المحلية الحالية"}`);
  }catch(err){console.error(err);alert("تعذر استيراد النسخة الاحتياطية. تأكد من اختيار ملف النسخة الكاملة الصحيح وتوفر مساحة تخزين كافية.")}
  finally{e.target.value=""}
}
function updateHeaderSummaries(){const n=val("patientName")||"................................................",f=val("fileNo")||"....................",d=val("visitDate")||"....................",a=val("age")||"........",g=val("gender")||"........",c=val("clinic")||"................................";document.getElementById("coverPatientName").textContent=n;document.getElementById("coverFileNo").textContent=f;document.getElementById("coverAge").textContent=a;document.getElementById("coverGender").textContent=g;document.getElementById("coverVisitDate").textContent=d;document.getElementById("coverClinic").textContent=c;document.getElementById("rxPatientName").textContent=n;document.getElementById("rxFileNo").textContent=f;document.getElementById("rxDate").textContent=d}
/* ===== Final care plan: patient copy + hospital copy ===== */
function joinFilled(lines){return lines.filter(x=>x&&String(x).trim()).join("\n\n");}
function medicationRowsForCare(){return getSimpleTable("rxTable").filter(row=>row.some(v=>String(v??"").trim())).map((row,i)=>`(${i+1}) ${["الدواء","الجرعة","التكرار","الطريق","المدة","الكمية","تعليمات الاستعمال"].map((label,j)=>row[j]?`${label}: ${row[j]}`:"").filter(Boolean).join("؛ ")}`).join("\n")||"لم تُسجّل أدوية في جدول الوصفة؛ راجع الطبيب ولا تستنتج أن المريض لا يستخدم أدوية.";}
function labRowsForCare(){return getSimpleTable("labsTable").filter(r=>r.some(v=>String(v??"").trim())).map((r,i)=>`${i+1}. ${r[1]||r[0]||"فحص"}: ${r[2]||"نتيجة غير مدخلة"}${r[3]?" "+r[3]:""}${r[4]?" (المرجع: "+r[4]+")":""}${r[5]?" — "+r[5]:""}${r[6]?" — "+r[6]:""}`).join("\n")||"لا توجد نتائج مخبرية مسجلة في الجدول.";}
function diagnosticRowsForCare(){return getSimpleTable("diagnosticsTable").filter(r=>r.some(v=>String(v??"").trim())).map((r,i)=>`${i+1}. ${[r[0],r[1],r[2],r[3],r[4],r[5]].filter(Boolean).join(" — ")}`).join("\n")||"لا توجد فحوصات تشخيصية مسجلة في الجدول.";}
function buildFinalCarePlanText(){
  const identity=`اسم المريض: ${val("patientName")||"—"} | رقم الملف: ${val("fileNo")||"—"} | رقم المريض: ${val("serialNoDisplay")||"—"} | تاريخ الزيارة: ${val("visitDate")||"—"}`;
  const meds=medicationRowsForCare(),labs=labRowsForCare(),diagnostics=diagnosticRowsForCare();
  const patientPlan=joinFilled([
    "خطة الرعاية الختامية — نسخة المريض",identity,
    val("diagnosis")?`ما تم تشخيصه: ${val("diagnosis")}`:"التشخيص: راجع الطبيب لمعرفة التشخيص المعتمد وتفسيره.",
    otherDiseasesPatientSummary()?`الأمراض الإضافية وخطوات التعامل معها:\n${otherDiseasesPatientSummary()}`:"",
    val("treatmentPlan")?`خطة العلاج: ${val("treatmentPlan")}`:"خطة العلاج: اتبع الخطة التي شرحها الطبيب؛ لم تُسجّل خطة رئيسية في النموذج بعد.",
    val("recommendations")?`التوصيات الطبية: ${val("recommendations")}`:"",
    val("referral")?`الإحالة أو الاستشارة المطلوبة: ${val("referral")}${val("referralReason")?" — السبب/الأولوية: "+val("referralReason"):""}`:"",
    val("patientMedicationAdvice")?`طريقة أخذ الأدوية: ${val("patientMedicationAdvice")}`:"الأدوية: التزم فقط بالوصفة المكتوبة. لا تبدأ أو توقف دواءً من نفسك.",
    `الأدوية المسجلة في الوصفة:\n${meds}`,
    val("nonDrugPlan")?`التعليمات غير الدوائية: ${val("nonDrugPlan")}`:"",
    [val("patientFoodAdvice"),val("recommendedFoods"),val("foodsToAvoid")].filter(Boolean).length?`الغذاء: ${[val("patientFoodAdvice"),val("recommendedFoods")?"أغذية موصى بها: "+val("recommendedFoods"):"",val("foodsToAvoid")?"أغذية يجب تجنبها/تقليلها: "+val("foodsToAvoid"):""].filter(Boolean).join("\n")}`:"",
    val("patientAvoidAdvice")?`الاحتياطات: ${val("patientAvoidAdvice")}`:"",
    val("patientLifestyleAdvice")?`المراقبة المنزلية: ${val("patientLifestyleAdvice")}`:"",
    val("emergencyInstructions")?`اذهب إلى الطوارئ فورًا عند: ${val("emergencyInstructions")}`:"علامات الخطر: اطلب الطوارئ فورًا عند ألم صدري شديد أو مفاجئ، ضيق نفس شديد، علامات سكتة مفاجئة، فقد الوعي، نزف شديد أو تدهور سريع.",
    val("patientSameDaySigns")?`مراجعة عاجلة اليوم/خلال 24 ساعة: ${val("patientSameDaySigns")}`:"",
    `موعد/توقيت المراجعة: ${[val("nextVisit"),val("patientFollowupTiming"),val("patientFollowupInstructions")].filter(Boolean).join(" — ")||"يحدده الطبيب قبل مغادرة المستشفى"}`,
    "هذه التعليمات تحتاج مراجعة الطبيب وتأكيد فهم المريض قبل التسليم. إذا ظهرت علامة طارئة فلا تنتظر الموعد."
  ]);
  const hospitalPlan=joinFilled([
    "خطة الرعاية الختامية — النسخة الداخلية للمستشفى",identity,
    `الأمراض الإضافية وإجراءاتها:\n${otherDiseasesSummary()||"لم تُسجّل أمراض إضافية"}`,
    `العلامات الحيوية: ضغط ${val("bpScreen")||"—"}؛ نبض ${val("pulseScreen")||"—"}؛ حرارة ${val("tempScreen")||"—"}؛ SpO₂ ${val("spo2Screen")||"—"}؛ وزن ${val("weight")||"—"} كجم؛ طول ${val("height")||"—"} سم؛ BMI ${val("bmi")||"—"}`,
    `التشخيص الرئيسي: ${val("diagnosis")||"غير مدخل"}`,
    `التشخيصات المصاحبة: ${val("comorbidDiagnoses")||"—"}`,
    `التشخيص التفريقي/درجة اليقين: ${[val("differentialDiagnosis"),val("diagnosticCertainty")].filter(Boolean).join(" — ")||"—"}`,
    `الخطة العلاجية: ${val("treatmentPlan")||"غير مدخلة"}`,
    `التدخلات الدوائية: ${val("drugPlan")||"—"}`,
    `التدخلات غير الدوائية: ${val("nonDrugPlan")||"—"}`,
    `الوصفة المسجلة:\n${meds}`,
    `الفحوصات المخبرية المسجلة:\n${labs}`,
    `الفحوصات التشخيصية المسجلة:\n${diagnostics}`,
    `الفحوصات المقررة لاحقًا: ${val("plannedInvestigations")||"—"}`,
    `الإحالة/سببها: ${[val("referral"),val("referralReason")].filter(Boolean).join(" — ")||"—"}`,
    `الإنذارات والتعليمات: ${[val("emergencyInstructions"),val("patientSameDaySigns")].filter(Boolean).join("\n")||"تُراجع وتُخصّص حسب الحالة"}`,
    `موعد المتابعة: ${[val("nextVisit"),val("patientFollowupTiming"),val("patientFollowupInstructions")].filter(Boolean).join(" — ")||"لم يحدد"}`,
    `ملاحظات الطبيب: ${val("doctorNotes")||"—"}`,
    "اعتماد الفريق المعالج: تُراجع كافة النتائج والأدوية والخطة والتوقيت من الطبيب المسؤول قبل إغلاق الزيارة."
  ]);
  const patientItems=joinFilled([
    "قائمة المريض للزيارة القادمة:",
    val("nextVisit")?`• الحضور في التاريخ المسجل: ${val("nextVisit")}`:"• تأكد من تثبيت موعد المراجعة وتاريخه قبل المغادرة.",
    "• إحضار قائمة الأدوية أو علبها مع الجرعات وأوقات الاستخدام، وذكر أي جرعة فائتة أو أثر جانبي.",
    val("plannedInvestigations")?`• إحضار نتائج الفحوصات المطلوبة: ${val("plannedInvestigations")}`:"• إحضار جميع نتائج التحاليل والتصوير وتقارير الإحالة المتاحة.",
    val("referral")?`• إحضار تقرير الإحالة ومراجعة الجهة المحددة: ${val("referral")}${val("referralReason")?" — "+val("referralReason"):""}`:"• إحضار أي تقرير إحالة أو استشارة سبق طلبها.",
    "• إحضار سجل الضغط/السكر أو القياسات المنزلية إذا طلب الطبيب ذلك.",
    "• تدوين الأعراض الجديدة أو المتفاقمة والأسئلة التي يريد المريض طرحها.",
    "• إحضار هذه الخطة والهوية/رقم الملف وأي تقارير أو وصفات سابقة."
  ]);
  const hospitalItems=joinFilled([
    "قائمة مراجعة الفريق في الزيارة القادمة:",
    "• التحقق من هوية المريض ورقم الملف والالتزام بالعلاج والتحمل والآثار الجانبية.",
    val("plannedInvestigations")?`• مراجعة نتائج الفحوصات المعلقة: ${val("plannedInvestigations")}`:"• التحقق من اكتمال الفحوصات المعلقة حسب الخطة.",
    val("treatmentGoals")?`• مقارنة الأهداف العلاجية: ${val("treatmentGoals")}`:"• إعادة تقييم الأعراض والعلامات الحيوية والمؤشرات المرتبطة بالتشخيص.",
    val("reassessmentPlan")?`• خطة إعادة التقييم: ${val("reassessmentPlan")}`:"• توثيق الاستجابة للعلاج وتعديل الخطة وفق النتائج والتقييم السريري.",
    val("referral")?`• متابعة الإحالة: ${val("referral")}`:"• متابعة الاستشارات أو الإحالات المطلوبة إن وجدت.",
    "• تحديث قائمة الأدوية والحساسية والتاريخ المرضي وأي تغيرات منذ الزيارة السابقة."
  ]);
  return {patientPlan,hospitalPlan,patientItems,hospitalItems};
}
function generateFinalCarePlans(force=true){
  if(force&&!confirm("سيتم إعداد أو تحديث نسختي خطة الرعاية من المعلومات الحالية في سجل المريض، بما في ذلك الوصفة والفحوصات والمتابعة. راجع النصين طبيًا قبل الطباعة أو تسليم نسخة المريض. هل تريد المتابعة؟"))return false;
  const plans=buildFinalCarePlanText();
  if(force||!val("patientCarePlanText").trim())setVal("patientCarePlanText",plans.patientPlan);
  else {
    let patientCopy=val("patientCarePlanText").trim();
    const recommendation=val("recommendations").trim(),referral=val("referral").trim(),referralReason=val("referralReason").trim();
    if(recommendation&&!patientCopy.includes(recommendation))patientCopy=joinFilled([patientCopy,`التوصيات الطبية: ${recommendation}`]);
    if(referral&&!patientCopy.includes(referral))patientCopy=joinFilled([patientCopy,`الإحالة أو الاستشارة المطلوبة: ${referral}${referralReason?" — السبب/الأولوية: "+referralReason:""}`]);
    else if(referralReason&&!patientCopy.includes(referralReason))patientCopy=joinFilled([patientCopy,`سبب الإحالة وأولويتها: ${referralReason}`]);
    if(patientCopy!==val("patientCarePlanText"))setVal("patientCarePlanText",patientCopy);
  }
  if(force||!val("hospitalCarePlanText").trim())setVal("hospitalCarePlanText",plans.hospitalPlan);
  if(force||!val("patientCareVisitItems").trim())setVal("patientCareVisitItems",plans.patientItems);
  else {
    let visitItems=val("patientCareVisitItems").trim();
    const referral=val("referral").trim(),referralReason=val("referralReason").trim();
    if(referral&&!visitItems.includes(referral))visitItems=joinFilled([visitItems,`مراجعة جهة الإحالة وإحضار التقرير: ${referral}${referralReason?" — السبب/الأولوية: "+referralReason:""}`]);
    else if(referralReason&&!visitItems.includes(referralReason))visitItems=joinFilled([visitItems,`سبب الإحالة وأولويتها: ${referralReason}`]);
    if(visitItems!==val("patientCareVisitItems"))setVal("patientCareVisitItems",visitItems);
  }
  if(force||!val("hospitalCareNextVisitItems").trim())setVal("hospitalCareNextVisitItems",plans.hospitalItems);
  updateSummary();persistAutoDraft?.();
  if(force)alert("تم تجهيز نسختي خطة الرعاية وقائمة الزيارة القادمة. راجع كل نسخة وعدّلها واعتمدها قبل الطباعة.");
  return true;
}
function printCareCopy(kind){generateFinalCarePlans(false);printSection(kind==="patient"?"patient-care-copy":"hospital-care-copy");}

/* ===== Local rule-based clinical assistant (offline; not generative AI) ===== */
function currentSelectedRisks(){const labels={riskHTN:"ارتفاع ضغط الدم",riskDM:"السكري",riskCVD:"مرض قلبي/وعائي",riskKidney:"عامل خطورة كلوي",riskStroke:"تاريخ سكتة/نقص تروية",riskLipid:"اضطراب الدهون",riskObesity:"زيادة الوزن/السمنة",personalSurgery:"عملية سابقة",personalHospitalization:"دخول مستشفى سابق",personalAllergy:"حساسية معروفة",personalChronic:"مرض مزمن آخر",familyHistoryHTN:"تاريخ عائلي لارتفاع الضغط",familyHistoryDM:"تاريخ عائلي للسكري",familyHistoryCVD:"تاريخ عائلي قلبي/وعائي",familyHistoryStroke:"تاريخ عائلي للسكتة",familyHistoryCancer:"تاريخ عائلي للسرطان"};return Object.entries(labels).filter(([id])=>document.getElementById(id)?.checked).map(([,name])=>name);}
function currentMedsSummary(){return medicationRowsForCare();}
function clinicalCompletenessItems(){const checks=[["اسم المريض",val("patientName")],["العمر",val("age")],["الجنس",val("gender")],["مرض/حالة إضافية موثقة",otherDiseasesSummary()],["العلامات الحيوية الأساسية (ضغط/نبض)",val("bpScreen")&&val("pulseScreen")],["الحساسية/الأدوية الثابتة (تأكيد أو توثيق)",val("medsAllergy")||document.getElementById("personalAllergy")?.checked||document.getElementById("medicationNone")?.checked],["التشخيص",val("diagnosis")],["الخطة العلاجية",val("treatmentPlan")],["توصيات أو علامات خطر",val("recommendations")||val("emergencyInstructions")],["موعد/خطة المتابعة",val("nextVisit")||val("patientFollowupTiming")||val("patientFollowupInstructions")]];return checks.filter(([,v])=>!v||String(v).trim()==="").map(([label])=>label);}
function buildCurrentPatientAssistantSummary(){const meds=currentMedsSummary(),labs=labRowsForCare(),diagnostics=diagnosticRowsForCare();return joinFilled([
`ملخص السجل الحالي — ${val("patientName")||"مريض غير محدد"} | الملف ${val("fileNo")||"—"} | التاريخ ${val("visitDate")||"—"}`,
`البيانات الأساسية: العمر ${val("age")||"—"}؛ الجنس ${val("gender")||"—"}؛ العيادة ${val("clinic")||"—"}`,
`الأمراض الإضافية وإجراءاتها:\n${otherDiseasesSummary()||"لم تُسجّل أمراض إضافية"}`,
`العلامات الحيوية: ضغط ${val("bpScreen")||"—"}؛ نبض ${val("pulseScreen")||"—"}؛ حرارة ${val("tempScreen")||"—"}؛ SpO₂ ${val("spo2Screen")||"—"}؛ الوزن ${val("weight")||"—"}؛ الطول ${val("height")||"—"}؛ BMI ${val("bmi")||"—"}`,
`التاريخ الشخصي: ${val("personalHistoryDetails")||"لا توجد تفاصيل نصية مدخلة"}`,
`عوامل الخطر المحددة: ${currentSelectedRisks().join("، ")||"لم تُحدد خيارات"}`,
`التاريخ العائلي: ${val("familyHistory")||"غير مدخل"}؛ النشاط: ${val("physicalActivityLevel")||"—"}/${val("physicalActivityFrequency")||"—"}`,
`الأمراض الإضافية وإجراءاتها: ${otherDiseasesSummary()||"لم تُسجّل أمراض إضافية"}`,
`التشخيص: ${val("diagnosis")||"غير مدخل"}؛ الحالات المصاحبة: ${val("comorbidDiagnoses")||"—"}`,
`الأدوية الثابتة والحساسية: ${val("medsAllergy")||"غير موثقة بالتفصيل"}`,
`الوصفة الحالية:\n${meds}`,
`التحاليل المسجلة:\n${labs}`,
`الفحوصات التشخيصية:\n${diagnostics}`,
`الخطة: ${val("treatmentPlan")||"غير مدخلة"}`,
`الفحوصات المقررة: ${val("plannedInvestigations")||"—"}`,
`المتابعة: ${[val("nextVisit"),val("patientFollowupTiming"),val("patientFollowupInstructions")].filter(Boolean).join(" — ")||"لم تُحدد"}`,
`ما يلزم في الزيارة القادمة:\n${val("patientCareVisitItems")||buildFinalCarePlanText().patientItems}`,
"ملاحظة: هذا تلخيص آلي لما هو مكتوب في السجل، وليس تشخيصًا أو توصية علاجية مستقلة. راجع المصدر الأصلي لكل نتيجة."
]);}
function runClinicalAssistant(mode="question"){
  let output="";
  if(mode==="summary")output=buildCurrentPatientAssistantSummary();
  else if(mode==="completeness"||mode==="completeness-return"){
    const missing=clinicalCompletenessItems();
    output=joinFilled(["مراجعة اكتمال التوثيق — لا تقيس هذه القائمة جودة التشخيص ولا تستبدل المراجعة السريرية.",missing.length?"حقول يُستحسن استكمالها أو توضيح سبب عدم انطباقها:\n"+missing.map((x,i)=>`${i+1}. ${x}`).join("\n"):"لم يظهر نقص في الحقول الأساسية التي فُحصت؛ راجع دقة المحتوى وملاءمته للحالة.","راجع أيضًا توثيق الحساسية، مراجعة الوصفة، النتائج غير الطبيعية، وخطة المتابعة قبل إغلاق الزيارة."]);
  }else if(mode==="followup"){
    const plans=buildFinalCarePlanText();output=joinFilled(["تحضير الزيارة القادمة",`الموعد الحالي: ${[val("nextVisit"),val("patientFollowupTiming"),val("patientFollowupInstructions")].filter(Boolean).join(" — ")||"لم يُحدد — يُرجى تحديده قبل تسليم الخطة"}`,val("plannedInvestigations")?`الفحوصات المطلوبة: ${val("plannedInvestigations")}`:"الفحوصات المطلوبة لم تُحدد في الحقل المخصص.",`قائمة المريض:\n${plans.patientItems}`,`قائمة الفريق:\n${plans.hospitalItems}`]);
  }else{
    const q=val("assistantQuestion").trim().toLowerCase();
    if(/ناقص|نقص|اكتمال|استكمال|مفقود/.test(q))output="فحص اكتمال السجل:\n"+runClinicalAssistant("completeness-return");
    else if(/متابعة|الزيارة القادمة|المراجعة|أحضر|احضر/.test(q))output=runClinicalAssistant("followup");
    else if(/طباعة|pdf|بي دي اف/.test(q))output="لطباعة ملف المريض كاملًا: استخدم «طباعة / حفظ PDF» في الشريط العلوي ثم اختر حجم الورق A4 أو «حفظ كملف PDF». لطباعة نسخة المريض أو نسخة المستشفى استخدم زر الطباعة داخل صفحة خطة الرعاية المقصودة. تم ضبط خط الطباعة على 17 نقطة، وتظهر الأقسام المفعلة والخيارات المحددة فقط؛ راجع معاينة الطباعة قبل الحفظ.";
    else if(/نسخة احتياطية|تصدير|استيراد|استعادة/.test(q))output="افتح «السجلات» ثم اختر «تصدير نسخة احتياطية كاملة» لإنشاء ملف JSON يشمل سجلات المرضى ومرفقاتهم. للاستعادة اختر «استعادة نسخة كاملة» وحدد الملف الذي سبق تصديره. CSV تقرير جدولي وليس نسخة احتياطية كاملة. تأكد من حفظ النسخ الاحتياطية في مكان آمن؛ فهي تحتوي على معلومات طبية حساسة.";
    else if(/حاسبة|الحسابات|احسب|حساب/.test(q))output="اذهب إلى القسم 18 — الحاسبة الإكلينيكية، واضغط «جلب كل بيانات المريض ذات الصلة بالحسابات». راجع الوحدات ومصدر كل قيمة ثم اضغط «حساب النتائج». هذه النتائج مساعدة ولا تستبدل المراجعة الطبية.";
    else if(/دواء|أدوية|الوصفة|علاج/.test(q))output="الأدوية المسجلة في الوصفة:\n"+currentMedsSummary()+"\n\nالأدوية الثابتة/الحساسية كما وثقت: "+(val("medsAllergy")||"غير مدخلة")+"\nراجع الطبيب/الصيدلي قبل تعديل الجرعات أو إيقاف الأدوية.";
    else output=buildCurrentPatientAssistantSummary();
  }
  if(mode==="completeness-return")return output;
  setVal("clinicalAssistantNotes",output);persistAutoDraft?.();
  const section=document.getElementById("clinicalAssistantNotes");if(section)section.scrollIntoView({behavior:"smooth",block:"center"});
  return output;
}
function copyAssistantToNotes(){const note=val("clinicalAssistantNotes").trim();if(!note){alert("أنشئ مخرجات للمساعد أولًا.");return;}if(val("doctorNotes").trim()&&!confirm("توجد ملاحظات طبيب حالية. هل تريد إضافة مخرجات المساعد أسفلها؟"))return;setVal("doctorNotes",joinFilled([val("doctorNotes"),"مخرجات المساعد المحلي — راجعها قبل الاعتماد:",note]));updateSummary();persistAutoDraft?.();alert("تم نسخ المخرجات إلى ملاحظات الطبيب. راجعها قبل حفظ السجل النهائي.");}

function updateSummary(){updateHeaderSummaries();const s=(id,t)=>{const e=document.getElementById(id);if(e)e.textContent=t||"—"};s("summaryName",val("patientName"));s("summaryFile",val("fileNo"));s("summaryDate",val("visitDate"));s("summaryClinic",val("clinic"));s("summaryOtherDiseases",otherDiseasesSummary());s("summaryDiagnosis",[val("diagnosis"),val("comorbidDiagnoses")].filter(Boolean).join("\n"));s("summaryPlan",[val("treatmentPlan"),val("drugPlan"),val("nonDrugPlan"),val("recommendations"),val("referral")?"الإحالة: "+val("referral")+ (val("referralReason")?" — "+val("referralReason"):""):"",val("nextVisit")?"موعد المتابعة: "+val("nextVisit"):""].filter(Boolean).join("\n\n"));setText("patientCareHeaderName","اسم المريض: "+(val("patientName")||"—"));setText("patientCareHeaderMeta",`رقم الملف: ${val("fileNo")||"—"} | تاريخ الزيارة: ${val("visitDate")||"—"}`);setText("hospitalCareHeaderName","اسم المريض: "+(val("patientName")||"—"));setText("hospitalCareHeaderMeta",`رقم الملف: ${val("fileNo")||"—"} | تاريخ الزيارة: ${val("visitDate")||"—"}`);updateCurrentRecord()}
document.addEventListener("input",updateSummary);document.addEventListener("change",updateSummary);
function invokePrint(){window.print();return "browser-print"}
function preparePrintTextareas(){
  const nodes=[...document.querySelectorAll(".document-shell textarea")];
  const previous=nodes.map(el=>({el,height:el.style.height,overflow:el.style.overflow,whiteSpace:el.style.whiteSpace,resize:el.style.resize}));
  nodes.forEach(el=>{el.style.height="auto";el.style.overflow="visible";el.style.whiteSpace="pre-wrap";el.style.resize="none";const minimum=Math.max(36,(Number(el.rows)||2)*16);el.style.height=Math.max(el.scrollHeight,minimum)+"px";});
  return ()=>previous.forEach(x=>{x.el.style.height=x.height;x.el.style.overflow=x.overflow;x.el.style.whiteSpace=x.whiteSpace;x.el.style.resize=x.resize;});
}

/* ===== Patient-state driven workflow and print selection ===== */
const CONDITION_RULES={
  htn:{label:"ارتفاع ضغط الدم",statusId:"conditionHTNStatus",riskId:"riskHTN",medId:"medicationHypertension",radio:"htnKnown",section:"htn",pattern:/ارتفاع\s*ضغط|ضغط\s*الدم|hypertension|\bhtn\b/i,fields:["htnDuration","htnAdherence","htnRedFlags"]},
  dm:{label:"داء السكري",statusId:"conditionDMStatus",riskId:"riskDM",medId:"medicationDiabetes",radio:"dmKnown",section:"dm",pattern:/السكري|داء\s*السكر|سكري|diabetes|\bdm\b/i,fields:["dmDuration","dmTherapy","dmAdherence","dmFbs","dmHba1c","dmRbs","dmFoot","dmComplications"]},
  cvd:{label:"مرض قلبي / وعائي",statusId:"conditionCVDStatus",riskId:"riskCVD",medId:"medicationCardiac",radio:"cvdKnown",section:"cvd",pattern:/مرض\s*قلبي|أمراض\s*القلب|القلب|الشرايين|وعائي|احتشاء|ذبحة|coronary|cardiovascular|\bcvd\b/i,fields:["cvdDuration","cvdChestPain","cvdDyspnea","cvdSymptoms","cvdExam"]},
  stroke:{label:"جلطة دماغية / نقص تروية",statusId:"conditionStrokeStatus",riskId:"riskStroke",medId:"medicationAnticoagulant",radio:"strokeKnown",section:"stroke",pattern:/جلط[ةه]\s*دماغ|سكت[ةه]|نقص\s*تروية|stroke|\btia\b/i,fields:["strokeDuration","strokeWeakness","strokeSpeechVision","strokeExam","strokeMeds"]}
};
const PRINT_EXTRA_LABELS={cover:"غلاف الملف",summary:"ملخص المريض", "patient-care-copy":"خطة الرعاية — نسخة المريض", "hospital-care-copy":"خطة الرعاية — نسخة المستشفى",reports:"تقارير المرضى"};
let pendingPrintPlan=null;
function conditionStatus(key){return val(CONDITION_RULES[key]?.statusId)||"unknown"}
function conditionDiagnosisEvidence(rule){return rule.pattern.test([val("diagnosis"),val("comorbidDiagnoses")].join(" "))}
function conditionPositiveEvidence(key){
  const rule=CONDITION_RULES[key];if(!rule)return false;
  if(document.getElementById(rule.riskId)?.checked||document.getElementById(rule.medId)?.checked||getRadio(rule.radio)==="نعم")return true;
  if(rule.fields.some(id=>String(val(id)||"").trim()))return true;
  if(conditionDiagnosisEvidence(rule))return true;
  const tableId={htn:"htnTable",dm:"dmTable",cvd:"cvdTable",stroke:"strokeTable"}[key];
  if(tableId){const rows=getTableData(tableId)||[];if(rows.some(row=>row.some((v,i)=>i!==0&&String(v||"").trim())))return true;}
  return false;
}
function conditionConflict(key){const status=conditionStatus(key),rule=CONDITION_RULES[key];if(status==="absent"||status==="unknown")return conditionPositiveEvidence(key);return getRadio(rule.radio)==="لا"}
function setConditionRadio(key,value){const rule=CONDITION_RULES[key];setRadio(rule.radio,value||"")}
function setDiseaseSectionEnabled(key,enabled){const rule=CONDITION_RULES[key];if(!rule)return;const check=document.querySelector(`.section-toggle[data-section-toggle="${rule.section}"]`);if(check&&check.checked!==enabled){check.checked=enabled;toggleSectionEnabled(rule.section,enabled);}else{const page=document.querySelector(`[data-section="${rule.section}"]`);if(page)page.classList.toggle("section-disabled",!enabled);const wrap=document.querySelector(`.section-toggle[data-section-toggle="${rule.section}"]`)?.closest(".nav-item");if(wrap)wrap.classList.toggle("section-disabled-nav",!enabled);}}
function updateConditionAlert(){
  const alertBox=document.getElementById("conditionStatusAlert");if(!alertBox)return;
  const messages=[];
  Object.entries(CONDITION_RULES).forEach(([key,rule])=>{
    const state=conditionStatus(key),evidence=conditionPositiveEvidence(key),radio=getRadio(rule.radio);
    if(state==="absent"&&evidence)messages.push(`حالة ${rule.label} محددة «غير موجود» لكن توجد بيانات أو دواء أو تشخيص مرتبط بها. راجع التعارض؛ أبقينا الإجراء متاحًا ولم نحذف أي معلومة.`);
    else if(state==="unknown"&&(evidence||radio==="لا"))messages.push(`حالة ${rule.label} غير محسومة رغم وجود مؤشرات في السجل. راجع حالة المرض قبل اعتماد النسخة المطبوعة.`);
    else if(state==="present"&&radio==="لا")messages.push(`هناك تعارض بين حالة ${rule.label} المختارة ونتيجة «لا» في التقييم التخصصي؛ راجع المدخلات.`);
  });
  alertBox.hidden=!messages.length;alertBox.textContent=messages.length?"تنبيه: "+messages.join(" "):"";
}
function applyConditionSelection(key,{fromStatus=false}={}){
  const rule=CONDITION_RULES[key];if(!rule)return;
  const select=document.getElementById(rule.statusId);let state=select?.value||"unknown";
  if(state==="present") {const risk=document.getElementById(rule.riskId);if(risk)risk.checked=true;setConditionRadio(key,"نعم");setDiseaseSectionEnabled(key,true);}
  else if(state==="absent") {const risk=document.getElementById(rule.riskId);if(risk)risk.checked=false;setConditionRadio(key,"لا");setDiseaseSectionEnabled(key,conditionPositiveEvidence(key));if(!conditionPositiveEvidence(key))setDiseaseSectionEnabled(key,false);}
  else if(fromStatus) {const risk=document.getElementById(rule.riskId);if(risk)risk.checked=false;setConditionRadio(key,"");setDiseaseSectionEnabled(key,conditionPositiveEvidence(key));}
  else {setDiseaseSectionEnabled(key,conditionPositiveEvidence(key));}
  updateConditionAlert();
}
function refreshConditionWorkflow({infer=true}={}){
  Object.entries(CONDITION_RULES).forEach(([key,rule])=>{
    const select=document.getElementById(rule.statusId);if(!select)return;
    if(infer&&!select.value){
      const radio=getRadio(rule.radio);
      if(radio==="نعم"||document.getElementById(rule.riskId)?.checked||conditionDiagnosisEvidence(rule)||rule.fields.some(id=>String(val(id)||"").trim()))select.value="present";
      else if(radio==="لا")select.value="absent";
      else if(document.getElementById(rule.medId)?.checked)select.value="present";
      else select.value="unknown";
    }
    applyConditionSelection(key,{fromStatus:false});
  });
  updateConditionAlert();
}
function initializeConditionWorkflow(){
  Object.entries(CONDITION_RULES).forEach(([key,rule])=>{
    const select=document.getElementById(rule.statusId);if(select&&!select.dataset.workflowReady){select.dataset.workflowReady="1";select.addEventListener("change",()=>{applyConditionSelection(key,{fromStatus:true});updateSummary();persistAutoDraft?.();});}
    const risk=document.getElementById(rule.riskId);if(risk&&!risk.dataset.workflowReady){risk.dataset.workflowReady="1";risk.addEventListener("change",()=>{if(risk.checked&&select)select.value="present";else if(!risk.checked&&select?.value==="present"&&getRadio(rule.radio)!=="نعم")select.value="unknown";applyConditionSelection(key,{fromStatus:false});persistAutoDraft?.();});}
    document.querySelectorAll(`input[name="${rule.radio}"]`).forEach(radio=>{if(radio.dataset.workflowReady)return;radio.dataset.workflowReady="1";radio.addEventListener("change",()=>{if(select)select.value=radio.value==="نعم"?"present":"absent";applyConditionSelection(key,{fromStatus:false});persistAutoDraft?.();});});
    const med=document.getElementById(rule.medId);if(med&&!med.dataset.workflowReady){med.dataset.workflowReady="1";med.addEventListener("change",()=>{if(med.checked&&select&&!select.value)select.value="present";applyConditionSelection(key,{fromStatus:false});persistAutoDraft?.();});}
  });
  ["diagnosis","comorbidDiagnoses"].forEach(id=>{const el=document.getElementById(id);if(el&&!el.dataset.conditionWatcher){el.dataset.conditionWatcher="1";el.addEventListener("input",()=>{Object.keys(CONDITION_RULES).forEach(key=>{const rule=CONDITION_RULES[key],select=document.getElementById(rule.statusId);if(select&&(select.value===""||select.value==="unknown")&&conditionDiagnosisEvidence(rule)){select.value="present";applyConditionSelection(key,{fromStatus:false});}else if(conditionConflict(key)){setDiseaseSectionEnabled(key,true);}});updateConditionAlert();});}});
  refreshConditionWorkflow({infer:true});
}
function hasMeaningfulSectionContent(page){
  if(!page)return false;
  const checkValue=el=>{if(el.disabled||el.type==="button"||el.type==="submit"||el.type==="file")return false;if(el.type==="checkbox"||el.type==="radio")return el.checked;if(el.type==="date")return false;if(el.id&&el.id.startsWith("condition")&&el.value==="unknown")return false;if(el.readOnly&&["fileNo","serialNoDisplay","bmi","hospitalCareAttachments"].includes(el.id))return false;return String(el.value||"").trim().length>0;};
  for(const el of page.querySelectorAll("input,select,textarea")){if(el.closest(".no-print"))continue;if(checkValue(el))return true;}
  for(const row of page.querySelectorAll(".clinical-table tbody tr")){const values=[...row.querySelectorAll("input,select,textarea")].filter(el=>el.type!=="date"&&!el.disabled).map(el=>String(el.value||"").trim());if(values.some(Boolean))return true;}
  const calculatorText=page.querySelector("#clinicalCalcText");if(calculatorText&&calculatorText.value.trim())return true;
  return false;
}
function printPageKey(page){return page.dataset.section||(page.classList.contains("cover-page")?"cover":page.id||"page")}
function printPageLabel(page){const key=printPageKey(page);if(PRINT_EXTRA_LABELS[key])return PRINT_EXTRA_LABELS[key];return SECTION_LABELS[key]||page.querySelector("h1")?.textContent?.trim()||key}
function buildPrintPlan(mode="full",specificSection=""){
  const pages=[...document.querySelectorAll(".document-shell .page")],active=new Set(getActiveSections()),included=new Set(),reasons=[],warnings=[];
  const extra=new Set(["summary","patient-care-copy","hospital-care-copy"]),core=new Set(["patient","screening","otherDiseases"]);
  if(mode==="section"){
    const target=pages.find(page=>printPageKey(page)===specificSection||page.id===specificSection);
    if(target)included.add(target.id);else warnings.push("لم يعثر البرنامج على الصفحة التي طلبت طباعتها.");
  }else if(mode==="summary")included.add("summary");
  else if(mode==="patient-care-copy")included.add("patientCareCopy");
  else if(mode==="hospital-care-copy")included.add("hospitalCareCopy");
  else if(mode==="clinical"||mode==="full"){
    if(mode==="full")included.add("coverPage");
    pages.forEach(page=>{
      const key=printPageKey(page);
      if(key==="cover"||key==="reports"||extra.has(key))return;
      if(CONDITION_RULES[key]){
        const state=conditionStatus(key),conflict=conditionConflict(key),evidence=conditionPositiveEvidence(key);
        if(state==="absent"&&!conflict){
          // Absence hides the follow-up by default; an explicit manual activation is a clinician override.
          if(!active.has(key)){reasons.push(`${printPageLabel(page)} — الحالة محددة «غير موجود» والقسم غير مفعّل`);return;}
          warnings.push(`تم تفعيل قسم ${CONDITION_RULES[key].label} يدويًا رغم أن الحالة محددة «غير موجود». راجع التوثيق قبل اعتماد الطباعة.`);
          included.add(page.id);return;
        }
        if(state==="present") {included.add(page.id);return;}
        if(conflict){warnings.push(`تعارض في حالة ${CONDITION_RULES[key].label}: راجع التشخيص والأدوية وبيانات التقييم قبل الاعتماد.`);included.add(page.id);return;}
        if(!active.has(key)){reasons.push(`${printPageLabel(page)} — غير مفعّل من اختيار الأقسام`);return;}
        if(state==="unknown"&&!evidence&&!hasMeaningfulSectionContent(page)){reasons.push(`${printPageLabel(page)} — الحالة غير معروفة ولا توجد بيانات تخصصية مدخلة`);return;}
        if(hasMeaningfulSectionContent(page)||evidence)included.add(page.id);else reasons.push(`${printPageLabel(page)} — لا توجد بيانات تخصصية في القسم`);
        return;
      }
      if(!active.has(key)) {reasons.push(`${printPageLabel(page)} — غير مفعّل من اختيار الأقسام`);return;}
      if(core.has(key)){included.add(page.id);return;}
      if(hasMeaningfulSectionContent(page))included.add(page.id);else reasons.push(`${printPageLabel(page)} — لا توجد بيانات أو إجراءات مسجلة في هذا القسم`);
    });
    if(mode==="full"){included.add("summary");included.add("patientCareCopy");included.add("hospitalCareCopy");}
  }
  const pageList=pages.filter(page=>included.has(page.id));
  const requiredByMode={
    full:[['patientName','اسم المريض'],['visitDate','تاريخ الزيارة'],['otherDiseasesSummary','الأمراض الإضافية المسجلة'],['diagnosis','التشخيص'],['treatmentPlan','الخطة العلاجية']],
    clinical:[['patientName','اسم المريض'],['visitDate','تاريخ الزيارة'],['otherDiseasesSummary','الأمراض الإضافية المسجلة'],['diagnosis','التشخيص'],['treatmentPlan','الخطة العلاجية']],
    summary:[['patientName','اسم المريض'],['visitDate','تاريخ الزيارة'],['otherDiseasesSummary','الأمراض الإضافية المسجلة'],['diagnosis','التشخيص'],['treatmentPlan','الخطة العلاجية']],
    'patient-care-copy':[['patientName','اسم المريض'],['patientCarePlanText','خطة الرعاية للمريض'],['patientCareVisitItems','متطلبات الزيارة القادمة للمريض']],
    'hospital-care-copy':[['patientName','اسم المريض'],['hospitalCarePlanText','الخطة الداخلية للمستشفى'],['hospitalCareNextVisitItems','مهام الزيارة القادمة داخل المستشفى']]
  };
  const required=requiredByMode[mode]||(mode==="section"?[["patientName","اسم المريض"]]:[]);
  const readRequired=id=>id==="otherDiseasesSummary"?otherDiseasesSummary():val(id);
  const absent=required.filter(([id])=>!String(readRequired(id)||"").trim()).map(([,label])=>label);
  if(absent.length)warnings.push("بيانات أساسية غير مدخلة وقد تظهر فارغة في المخرجات: "+absent.join("، "));
  if((mode==="full"||mode==="clinical")&&reasons.length)warnings.push("صفحات مستبعدة تلقائيًا: "+reasons.slice(0,8).map(x=>x.split(" — ")[0]).join("، ")+(reasons.length>8?`، و${reasons.length-8} أقسام أخرى`:""));
  // Print plans always include only document pages, never the patient registry report.
  const pageIds=pageList.map(page=>page.id);
  return {mode,specificSection,pageIds,labels:pageList.map(printPageLabel),warnings:[...new Set(warnings)],reasons,createdAt:new Date().toISOString()};
}
function openPrintPreviewFromCenter(mode="full"){closePrintCenter();openPrintPreview(mode);}
function openPrintPreview(mode="full",specificSection=""){
  (async()=>{
    updateSummary();
    if(mode==="full"||mode==="patient-care-copy"||mode==="hospital-care-copy"){generateFinalCarePlans(false);await refreshCareAttachmentIndex();}
    pendingPrintPlan=buildPrintPlan(mode,specificSection);
    const modal=document.getElementById("printPreviewModal");if(!modal)return;
    const title={full:"طباعة الملف الكامل",clinical:"طباعة النموذج السريري المحدد",summary:"طباعة ملخص المريض","patient-care-copy":"طباعة خطة الرعاية للمريض","hospital-care-copy":"طباعة خطة الرعاية للمستشفى",section:"طباعة القسم المحدد"}[mode]||"معاينة إعدادات الطباعة";
    document.getElementById("printPreviewTitle").textContent=title;
    document.getElementById("printPreviewSubtitle").textContent="راجع قائمة الصفحات والتنبيهات قبل فتح معاينة الطباعة في المتصفح.";
    document.getElementById("printPreviewPageCount").textContent=String(pendingPrintPlan.pageIds.length);
    document.getElementById("printPreviewWarningCount").textContent=String(pendingPrintPlan.warnings.length);
    const included=document.getElementById("printPreviewIncluded");included.replaceChildren();
    pendingPrintPlan.labels.forEach((label,i)=>{const li=document.createElement("li");li.textContent=`${i+1}. ${label}`;included.appendChild(li)});
    if(!pendingPrintPlan.labels.length){const li=document.createElement("li");li.textContent="لا توجد صفحات محددة للطباعة. فعّل قسمًا أو اختر نوع نسخة آخر.";included.appendChild(li)}
    const warnings=document.getElementById("printPreviewWarnings");warnings.replaceChildren();
    const combined=[...pendingPrintPlan.warnings];
    if(pendingPrintPlan.reasons.length){const shown=pendingPrintPlan.reasons.slice(0,12).map(x=>x);const hiddenCount=pendingPrintPlan.reasons.length-shown.length;combined.push("الأقسام التي لن تدخل في النسخة: "+shown.join("؛ ")+(hiddenCount>0?`؛ وهناك ${hiddenCount} أقسام إضافية`:""));}
    if(!combined.length)combined.push("لم يُكتشف تعارض واضح في حالة الأمراض أو بيانات الطباعة؛ راجع معاينة المتصفح النهائية قبل الاعتماد.");
    combined.forEach(message=>{const li=document.createElement("li");li.textContent=message;warnings.appendChild(li)});
    modal.hidden=false;document.body.classList.add("print-preview-open");document.getElementById("printPreviewModal")?.querySelector(".print-preview-close")?.focus();
  })().catch(err=>{console.error(err);alert("تعذر تجهيز معاينة الطباعة. راجع سجل المريض ثم حاول مرة أخرى.")});
}
function closePrintPreview(){const modal=document.getElementById("printPreviewModal");if(modal)modal.hidden=true;document.body.classList.remove("print-preview-open");pendingPrintPlan=null;}
function prepareFilteredPrint(plan=null){
  plan=plan||buildPrintPlan("full");
  const touched=[];const mark=(el,cls,yes)=>{if(!el)return;touched.push([el,cls,el.classList.contains(cls)]);el.classList.toggle(cls,!!yes)};
  document.querySelector(".print-selected-actions")?.remove();
  const includedIds=new Set(plan?.pageIds||[]);
  const allPages=[...document.querySelectorAll(".document-shell .page")];
  allPages.forEach(page=>{mark(page,"print-excluded",!includedIds.has(page.id));mark(page,"print-last-page",false);});
  const lastIncluded=[...allPages].reverse().find(page=>includedIds.has(page.id));if(lastIncluded)mark(lastIncluded,"print-last-page",true);
  // Hide unchecked boxes and radios in print; this is presentation only and never changes the stored value.
  document.querySelectorAll("label:has(input[type=checkbox]),label:has(input[type=radio])").forEach(label=>{const input=label.querySelector('input[type="checkbox"],input[type="radio"]');if(input)mark(label,"print-choice-hidden",!input.checked)});
  // Hide optional fields and fully empty table rows without deleting or clearing their values.
  document.querySelectorAll(".document-shell .page .field").forEach(field=>{
    const controls=[...field.querySelectorAll("input:not([type=checkbox]):not([type=radio]),select,textarea")].filter(e=>!e.disabled);
    if(controls.length&&controls.every(e=>!String(e.value||"").trim()))mark(field,"print-field-empty",true);
  });
  document.querySelectorAll(".document-shell .clinical-table tbody tr").forEach(row=>{
    const controls=[...row.querySelectorAll("input,select,textarea")].filter(e=>!e.classList.contains("delete-row")&&e.type!=="date");
    if(controls.length&&controls.every(e=>!String(e.value||"").trim()))mark(row,"print-row-empty",true);
  });
  const firstPage=document.querySelector(".document-shell .page:not(.print-excluded):not(.cover-page)")||document.querySelector(".document-shell .page:not(.print-excluded)");
  const banner=document.createElement("div");banner.className="print-selected-actions";banner.innerHTML="<strong>الإجراءات والأقسام المحددة للطباعة — الصفحات المضمنة في هذه النسخة:</strong> "+(plan.labels.length?plan.labels.map(x=>String(x).replace(/[&<>\"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]))).join("، "):"لا توجد صفحات محددة");
  if(firstPage){const header=firstPage.querySelector(".page-header");if(header)header.insertAdjacentElement("afterend",banner);else firstPage.prepend(banner);}
  return ()=>{for(const [el,cls,was] of touched)el.classList.toggle(cls,was);banner.remove()};
}
function confirmPrintPreview(){
  if(!pendingPrintPlan||!pendingPrintPlan.pageIds.length){alert("لم يتم تحديد أي صفحة للطباعة. فعّل قسمًا أو اختر نوع نسخة آخر.");return;}
  const plan=pendingPrintPlan;closePrintPreview();
  let cleaned=false,restore=()=>{};
  const cleanup=()=>{if(cleaned)return;cleaned=true;restore();document.body.classList.remove("printing-all-record","printing-filtered","printing-section");window.removeEventListener("afterprint",cleanup)};
  document.body.classList.add("printing-all-record","printing-filtered");
  window.addEventListener("afterprint",cleanup,{once:true});
  setTimeout(()=>{const filteredRestore=prepareFilteredPrint(plan);const textRestore=preparePrintTextareas();restore=()=>{textRestore();filteredRestore()};invokePrint()},150);
  setTimeout(cleanup,45000);
}
function printSection(name){openPrintPreview("section",name)}
async function printDocument(){openPrintPreview("full")}
async function refreshCareAttachmentIndex(){const field=document.getElementById("hospitalCareAttachments");if(!field)return;try{if(!currentPatientId){field.value="لا يوجد سجل محفوظ محدد؛ احفظ المريض أولًا لحفظ مرفقاته.";return;}const files=await getPatientAttachments(currentPatientId);field.value=files.length?files.map((f,i)=>`${i+1}. ${f.relativePath||f.name||"ملف"} — ${formatFileSize(f.size)}${f.addedAt?" — "+new Date(f.addedAt).toLocaleDateString():""}`).join("\n"):"لا توجد مرفقات محفوظة لهذا المريض.";}catch(err){console.error(err);field.value="تعذر قراءة فهرس المرفقات لهذا السجل."}}
/* ===== Patient-specific files and folders (IndexedDB, offline) ===== */
const ATTACH_DB="ALDHALEA_PATIENT_ATTACHMENTS",ATTACH_STORE="files";
function openAttachmentDB(){return new Promise((resolve,reject)=>{if(!("indexedDB" in window)){reject(new Error("IndexedDB غير مدعوم"));return}const req=indexedDB.open(ATTACH_DB,1);req.onupgradeneeded=()=>{const db=req.result;if(!db.objectStoreNames.contains(ATTACH_STORE)){const st=db.createObjectStore(ATTACH_STORE,{keyPath:"id",autoIncrement:true});st.createIndex("patientId","patientId",{unique:false})}};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function uploadPatientFiles(event){const input=event.target,files=[...(input.files||[])];if(!files.length)return;if(!currentPatientId||!getDB().some(p=>p.id===currentPatientId)){alert("يرجى فتح سجل المريض أو حفظ بياناته أولًا، ثم إضافة الملفات.");input.value="";return}try{const db=await openAttachmentDB();await new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readwrite"),store=tx.objectStore(ATTACH_STORE);files.forEach(file=>store.add({patientId:currentPatientId,name:file.name,relativePath:file.webkitRelativePath||file.name,type:file.type||"application/octet-stream",size:file.size,lastModified:file.lastModified,blob:file,addedAt:new Date().toISOString()}));tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error)});db.close();input.value="";await refreshPatientFiles();alert(`تم حفظ ${files.length} ملف/ملفات للمريض الحالي على هذا الجهاز.`)}catch(err){console.error(err);alert("تعذر حفظ الملفات. تحقق من مساحة التخزين المتاحة في الجهاز.");input.value=""}}
async function getPatientAttachments(patientId){const db=await openAttachmentDB();return new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readonly"),req=tx.objectStore(ATTACH_STORE).index("patientId").getAll(patientId);req.onsuccess=()=>{db.close();resolve(req.result||[])};req.onerror=()=>{db.close();reject(req.error)}})}
async function refreshPatientFiles(){const status=document.getElementById("patientFilesStatus"),list=document.getElementById("patientFilesList");if(!status||!list)return;list.innerHTML="";const patient=currentPatientId&&getDB().find(p=>p.id===currentPatientId);if(!patient){status.textContent="لا يوجد مريض محدد. افتح سجل المريض أو احفظه أولًا لإدارة مرفقاته.";return}status.textContent=`المريض الحالي: ${patient.patientName||"بدون اسم"} — رقم الملف: ${patient.fileNo||"غير محدد"}`;try{const files=await getPatientAttachments(currentPatientId);if(!files.length){list.innerHTML='<div class="manager-foot">لا توجد ملفات مرفقة بهذا المريض حتى الآن.</div>';return}files.sort((a,b)=>String(a.relativePath).localeCompare(String(b.relativePath)));files.forEach(f=>{const row=document.createElement("div");row.className="patient-file-row";const info=document.createElement("div");info.className="patient-file-info";const name=document.createElement("strong");name.textContent=f.relativePath||f.name;const meta=document.createElement("small");meta.textContent=`${formatFileSize(f.size)} · ${new Date(f.addedAt).toLocaleDateString()}`;info.append(name,meta);const actions=document.createElement("div");actions.className="patient-file-actions";const down=document.createElement("button");down.className="btn btn-outline";down.textContent="تنزيل";down.onclick=()=>downloadPatientAttachment(f);const del=document.createElement("button");del.className="delete-row";del.textContent="حذف";del.onclick=()=>deletePatientAttachment(f.id);actions.append(down,del);row.append(info,actions);list.appendChild(row)})}catch(err){console.error(err);status.textContent="تعذر الوصول إلى مخزن المرفقات في هذا المتصفح."}}
function formatFileSize(bytes){if(bytes<1024)return `${bytes} بايت`;if(bytes<1024*1024)return `${(bytes/1024).toFixed(1)} كيلوبايت`;return `${(bytes/1024/1024).toFixed(2)} ميغابايت`}
async function downloadPatientAttachment(file){try{await downloadBlob(file.blob,file.name||"patient-file",file.type||"application/octet-stream");}catch(err){console.error(err);alert("تعذر تنزيل المرفق. تحقق من أذونات التنزيل ومساحة التخزين، أو جرّب فتح البرنامج في متصفح يدعم تنزيل الملفات.");}}
async function deletePatientAttachment(id){if(!confirm("هل تريد حذف هذا المرفق من سجل المريض؟"))return;try{const db=await openAttachmentDB();await new Promise((resolve,reject)=>{const tx=db.transaction(ATTACH_STORE,"readwrite");tx.objectStore(ATTACH_STORE).delete(id);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error)});db.close();await refreshPatientFiles()}catch(err){console.error(err);alert("تعذر حذف المرفق.")}}

/* ===== Additional diseases: dynamic, patient-specific clinical workflow ===== */
const OTHER_DISEASE_FIELDS=[
  ["name","اسم المرض / الحالة","input"],
  ["symptoms","الأعراض والشكوى المتعلقة بهذا المرض","textarea"],
  ["history","القصة المرضية / مدة المرض / العلاجات السابقة","textarea"],
  ["exam","الفحص السريري والعلامات المرتبطة","textarea"],
  ["investigations","الفحوصات المطلوبة والنتائج والتفسير","textarea"],
  ["diagnosis","التشخيص والتقييم السريري","textarea"],
  ["treatment","الخطة العلاجية والإجراءات المطلوبة","textarea"],
  ["medicines","الأدوية المرتبطة بهذه الحالة (مع توثيقها أيضًا في جدول الوصفة)","textarea"],
  ["recommendations","التوصيات وتعليمات المريض","textarea"],
  ["referral","الإحالة / التخصص المطلوب وسببها وأولويتها","textarea"],
  ["followup","خطة المتابعة وموعد إعادة التقييم","textarea"],
  ["notes","ملاحظات إضافية","textarea"]
];
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function initializeOtherDiseases(){
  const list=document.getElementById("otherDiseasesList");if(!list)return;
  if(!list.children.length)renderOtherDiseases([]);
  list.addEventListener("input",()=>{updateOtherDiseaseCount();persistAutoDraft?.();updateSummary();});
  list.addEventListener("change",()=>{updateOtherDiseaseCount();persistAutoDraft?.();updateSummary();});
}
function addOtherDisease(data={},options={}){
  const list=document.getElementById("otherDiseasesList");if(!list)return;
  const card=document.createElement("article");card.className="other-disease-card";
  const header=document.createElement("div");header.className="other-disease-card-head";
  const title=document.createElement("h2");title.textContent="مرض / حالة إضافية";
  const remove=document.createElement("button");remove.type="button";remove.className="delete-row no-print";remove.textContent="حذف البطاقة";remove.addEventListener("click",()=>removeOtherDiseaseCard(remove));
  header.append(title,remove);card.appendChild(header);
  const grid=document.createElement("div");grid.className="other-disease-grid";
  OTHER_DISEASE_FIELDS.forEach(([key,label,type])=>{
    const wrap=document.createElement("div");wrap.className="field"+(key==="name"?" span-2":"");
    const lab=document.createElement("label");lab.textContent=label;
    const el=document.createElement(type);el.dataset.diseaseField=key;el.value=String(data?.[key]??"");
    if(type==="input"){el.placeholder="اكتب اسم المرض أو الحالة";el.type="text";}else{el.rows=key==="notes"?3:4;el.placeholder="وثّق المعلومات المتعلقة بهذه الحالة فقط";}
    wrap.append(lab,el);grid.appendChild(wrap);
  });
  card.appendChild(grid);list.appendChild(card);updateOtherDiseaseCount();if(options.persist!==false)persistAutoDraft?.();
  if(options.focus!==false)card.querySelector('[data-disease-field="name"]')?.focus({preventScroll:true});
}
function removeOtherDiseaseCard(button){const card=button?.closest(".other-disease-card");if(!card)return;if(!confirm("هل تريد حذف بطاقة هذا المرض من النموذج الحالي؟ سيبقى الحذف نهائيًا بعد حفظ التعديل."))return;card.remove();updateOtherDiseaseCount();persistAutoDraft?.();updateSummary();}
function getOtherDiseases(){return [...(document.querySelectorAll("#otherDiseasesList .other-disease-card"))].map(card=>{const item={};card.querySelectorAll("[data-disease-field]").forEach(el=>item[el.dataset.diseaseField]=String(el.value||"").trim());return item;}).filter(item=>Object.values(item).some(v=>String(v||"").trim()));}
function renderOtherDiseases(rows){const list=document.getElementById("otherDiseasesList");if(!list)return;list.innerHTML="";(Array.isArray(rows)?rows:[]).forEach(row=>addOtherDisease(row,{focus:false,persist:false}));updateOtherDiseaseCount();}
function updateOtherDiseaseCount(){const cards=[...document.querySelectorAll("#otherDiseasesList .other-disease-card")];const count=document.getElementById("otherDiseaseCount"),empty=document.getElementById("otherDiseasesEmpty");if(count)count.textContent=cards.length?`عدد الأمراض / الحالات: ${cards.length}`:"لا توجد أمراض إضافية مضافة";if(empty)empty.hidden=cards.length>0;cards.forEach((card,i)=>{const title=card.querySelector(".other-disease-card-head h2"),name=card.querySelector('[data-disease-field="name"]')?.value?.trim();if(title)title.textContent=`${i+1}. ${name||"مرض / حالة إضافية"}`;});}
function migrateLegacyDiseases(record){
  if(Array.isArray(record?.otherDiseases))return record.otherDiseases;
  const assessmentKeys=["complaint","historyPresent","clinicalExam","medicalAssessment","clinicalStability","medicalPriority"];
  const hasLegacyAssessment=assessmentKeys.some(key=>String(record?.[key]??"").trim());
  if(!hasLegacyAssessment)return [];
  const legacy={name:String(record?.diagnosis||"").trim(),symptoms:record?.complaint||"",history:record?.historyPresent||"",exam:record?.clinicalExam||"",investigations:"",diagnosis:record?.diagnosis||"",treatment:record?.treatmentPlan||"",medicines:"",recommendations:record?.recommendations||"",referral:[record?.referral,record?.referralReason].filter(Boolean).join(" — "),followup:record?.nextVisit||"",notes:record?.medicalAssessment||""};
  legacy.name=legacy.name||"حالة من سجل سابق";
  return [legacy];
}
function otherDiseaseSummaryForItem(item,patientSafe=false){
  const fields=patientSafe?[["التشخيص",item.diagnosis],["العلاج والإجراءات",item.treatment],["التوصيات",item.recommendations],["الإحالة",item.referral],["المتابعة",item.followup]]:[["الأعراض",item.symptoms],["القصة المرضية",item.history],["الفحص السريري",item.exam],["الفحوصات ونتائجها",item.investigations],["التشخيص",item.diagnosis],["العلاج والإجراءات",item.treatment],["الأدوية المرتبطة",item.medicines],["التوصيات",item.recommendations],["الإحالة/السبب والأولوية",item.referral],["المتابعة",item.followup],["ملاحظات",item.notes]];
  const body=fields.filter(([,v])=>String(v||"").trim()).map(([label,v])=>`${label}: ${String(v).trim()}`).join("\n");return `${item.name||"مرض / حالة إضافية"}${body?"\n"+body:""}`;
}
function otherDiseasesSummary(){return getOtherDiseases().map((item,i)=>`${i+1}. ${otherDiseaseSummaryForItem(item,false)}`).join("\n\n");}
function otherDiseasesPatientSummary(){return getOtherDiseases().map((item,i)=>`${i+1}. ${otherDiseaseSummaryForItem(item,true)}`).join("\n\n");}
function otherDiseasesTextFromRecord(record){
  const list=migrateLegacyDiseases(record);return (Array.isArray(list)?list:[]).map(item=>[item.name,item.diagnosis,item.symptoms,item.treatment,item.recommendations,item.referral].filter(Boolean).join(" ")).join(" ");
}

/* ===== Header actions: each top-level tool opens a closable panel ===== */
let activeHeaderOverlay=null;
function initializeHeaderActionUI(){
  const modal=document.getElementById("headerActionModal");if(modal)modal.hidden=true;
  const printPanel=document.querySelector(".easy-print-panel");if(printPanel){printPanel.classList.remove("header-overlay-open");printPanel.classList.add("header-panel-closed");}
  const manager=document.getElementById("managerPanel");if(manager){manager.classList.remove("open");manager.setAttribute("aria-hidden","true");}
  document.getElementById("managerBackdrop")?.remove();document.getElementById("headerOverlayBackdrop")?.remove();
  document.body.classList.remove("header-overlaying","header-action-dialog-open");activeHeaderOverlay=null;
  document.querySelectorAll(".manager-catalog-panel").forEach(panel=>panel.classList.add("manager-catalog-hidden"));
}
function ensureHeaderBackdrop(){let b=document.getElementById("headerOverlayBackdrop");if(!b){b=document.createElement("div");b.id="headerOverlayBackdrop";b.className="header-overlay-backdrop no-print";b.addEventListener("click",closeHeaderSectionOverlay);document.body.appendChild(b);}return b;}
function clearHeaderBackdrop(){document.getElementById("headerOverlayBackdrop")?.remove();document.body.classList.remove("header-overlaying");}
function openPrintCenter(){
  closeHeaderActionDialog();closeHeaderSectionOverlay();const panel=document.querySelector(".easy-print-panel");if(!panel)return;
  panel.classList.remove("header-panel-closed");panel.classList.add("header-overlay-open");activeHeaderOverlay={type:"print",node:panel};ensureHeaderBackdrop();document.body.classList.add("header-overlaying");
}
function closePrintCenter(){const panel=document.querySelector(".easy-print-panel");if(panel){panel.classList.remove("header-overlay-open");panel.classList.add("header-panel-closed");}if(activeHeaderOverlay?.type==="print")activeHeaderOverlay=null;clearHeaderBackdrop();}
function openHeaderSectionOverlay(key){
  closeHeaderActionDialog();closeHeaderSectionOverlay();closePrintCenter();
  const page=document.querySelector(`[data-section="${key}"]`)||document.getElementById(key);if(!page)return false;
  const snap={careHidden:page.classList.contains("care-tool-page-hidden"),sectionDisabled:page.classList.contains("section-disabled"),printExcluded:page.classList.contains("print-excluded"),activeKey:key};
  page.classList.remove("care-tool-page-hidden","section-disabled","print-excluded");page.classList.add("header-overlay-open");
  const head=page.querySelector(".page-header")||page.querySelector(".print-panel-heading");let closeBtn=null;
  if(head){closeBtn=document.createElement("button");closeBtn.type="button";closeBtn.className="header-overlay-close no-print";closeBtn.setAttribute("aria-label","إغلاق والعودة");closeBtn.textContent="×";closeBtn.addEventListener("click",closeHeaderSectionOverlay);head.appendChild(closeBtn);}
  activeHeaderOverlay={type:"page",node:page,snapshot:snap,closeBtn};ensureHeaderBackdrop();document.body.classList.add("header-overlaying");
  if(key==="reports")updateReports();
  const nav=document.querySelector(`.nav-tab[data-target="${key}"]`);if(nav){document.querySelectorAll(".nav-tab").forEach(n=>n.classList.toggle("active",n===nav));}
  return true;
}
function closeHeaderSectionOverlay(){
  if(activeHeaderOverlay?.type==="page"){
    const {node,snapshot,closeBtn}=activeHeaderOverlay;closeBtn?.remove();node.classList.remove("header-overlay-open");
    if(snapshot?.careHidden)node.classList.add("care-tool-page-hidden");if(snapshot?.sectionDisabled)node.classList.add("section-disabled");if(snapshot?.printExcluded)node.classList.add("print-excluded");
    activeHeaderOverlay=null;
  }else if(activeHeaderOverlay?.type==="print"){closePrintCenter();return;}
  clearHeaderBackdrop();
}
function openHeaderActionDialog(mode){
  closeHeaderSectionOverlay();closePrintCenter();const modal=document.getElementById("headerActionModal"),title=document.getElementById("headerActionTitle"),subtitle=document.getElementById("headerActionSubtitle"),body=document.getElementById("headerActionBody");if(!modal||!body)return;
  const button=(label,handler,variant="btn-primary")=>{const b=document.createElement("button");b.type="button";b.className="btn "+variant;b.textContent=label;b.addEventListener("click",handler);return b;};
  body.replaceChildren();
  if(mode==="save"){
    title.textContent="حفظ المريض وتخصيص الرقم";subtitle.textContent="احفظ البيانات المدخلة في سجل المريض المحلي على هذا الجهاز.";
    const note=document.createElement("p");note.textContent="تحقق من اسم المريض والبيانات المهمة قبل الحفظ. بعد النجاح سيُخصص رقم المريض ورقم الملف تلقائيًا.";note.className="header-action-note";body.appendChild(note);
    body.appendChild(button("حفظ / تحديث السجل",()=>{if(savePatient())closeHeaderActionDialog();}));
  }else if(mode==="new"){
    title.textContent="بدء سجل مريض جديد";subtitle.textContent="سيُفرَّغ النموذج الحالي بعد تأكيدك، ولن تُحذف السجلات المحفوظة.";
    const note=document.createElement("p");note.className="header-action-note";note.textContent="تأكد من حفظ أي تعديلات تريد الاحتفاظ بها قبل بدء سجل جديد.";body.appendChild(note);
    body.appendChild(button("بدء سجل جديد",()=>{newPatient(true);closeHeaderActionDialog();}));
  }else if(mode==="care"){
    title.textContent="أدوات الرعاية";subtitle.textContent="اختر الإجراء المطلوب، ثم أغلقه بعلامة × للعودة إلى النموذج.";
    const actions=[
      ["الملخص النهائي وخطة الرعاية","care-plan"],["خطة الرعاية — نسخة المريض","patient-care-copy"],["خطة الرعاية — نسخة المستشفى","hospital-care-copy"],["الحاسبة الإكلينيكية","calculator"],["المنبّه والتذكير","reminder"]
    ];
    const grid=document.createElement("div");grid.className="header-action-grid";
    actions.forEach(([label,key])=>grid.appendChild(button(label,()=>openCareTool(key),"btn-outline")));body.appendChild(grid);
  }
  modal.hidden=false;document.body.classList.add("header-action-dialog-open");modal.querySelector(".header-action-close")?.focus({preventScroll:true});
}
function closeHeaderActionDialog(){const modal=document.getElementById("headerActionModal");if(modal)modal.hidden=true;document.body.classList.remove("header-action-dialog-open");}
function closeHeaderActions(){closeHeaderActionDialog();closeHeaderSectionOverlay();closePrintCenter();toggleManager(false);}
function integrateCatalogToolsIntoRecords(){
  const manager=document.getElementById("managerPanel");if(!manager||manager.dataset.catalogToolsReady)return;manager.dataset.catalogToolsReady="1";
  const controls=manager.querySelector(".manager-controls");const area=document.createElement("section");area.id="managerEntryTools";area.className="manager-entry-tools";
  area.innerHTML='<div class="manager-entry-tools-head"><div><strong>أدوات المختبر والأدوية</strong><small>تظهر عند الطلب ولا تطبع ضمن ملف المريض</small></div></div><div class="manager-actions"><button type="button" class="btn btn-outline" onclick="toggleManagerCatalog(\'labs\')">🧪 أدوات المختبر</button><button type="button" class="btn btn-outline" onclick="toggleManagerCatalog(\'medications\')">💊 أدوات الأدوية</button></div>';
  controls?.insertAdjacentElement("afterend",area);
  const map=[["labCatalogPanel","labs","إدارة قائمة المختبر"],["medicationCatalogPanel","medications","إدارة قائمة الأدوية"]];
  map.forEach(([id,key,label])=>{const panel=document.getElementById(id);if(!panel)return;panel.classList.add("manager-catalog-panel","manager-catalog-hidden");const head=document.createElement("div");head.className="catalog-tools-head";const title=document.createElement("strong");title.textContent=label;const close=document.createElement("button");close.type="button";close.className="icon-btn";close.textContent="×";close.setAttribute("aria-label","إغلاق أدوات القائمة");close.addEventListener("click",()=>toggleManagerCatalog(key,false));head.append(title,close);panel.prepend(head);area.appendChild(panel);});
}
function toggleManagerCatalog(key,force){const id=key==="labs"?"labCatalogPanel":"medicationCatalogPanel",other=key==="labs"?"medicationCatalogPanel":"labCatalogPanel",panel=document.getElementById(id),otherPanel=document.getElementById(other);if(!panel)return false;const opening=typeof force==="boolean"?force:panel.classList.contains("manager-catalog-hidden");otherPanel?.classList.add("manager-catalog-hidden");panel.classList.toggle("manager-catalog-hidden",!opening);if(opening)panel.scrollIntoView({behavior:"smooth",block:"nearest"});return opening;}
/* ===== Per-patient section activation ===== */
const SECTION_LABELS={patient:"بيانات المريض",screening:"المسح الصحي الأولي",cvd:"تقييم القلب والأوعية",stroke:"تقييم الجلطات الدماغية",htn:"ارتفاع ضغط الدم",dm:"السكري ومضاعفاته",labs:"الفحوصات المخبرية",diagnostics:"الفحوصات التشخيصية",otherDiseases:"الأمراض الإضافية وإجراءاتها",diagnosis:"التشخيص",prescription:"الوصفة الطبية",plan:"الخطة العلاجية",recommendations:"التوصيات والإحالة",followup:"سجل المتابعة",notes:"ملاحظات الطبيب",nutrition:"التغذية وضبط الجهاز الهضمي",assistant:"المساعد السريري الذكي",calculator:"الحاسبة الإكلينيكية",reports:"تقارير المرضى"};
function setupSectionToggles(){document.querySelectorAll(".section-nav .nav-tab").forEach(btn=>{const key=btn.dataset.target;if(!key||btn.dataset.toggleReady)return;btn.dataset.toggleReady="1";const wrap=document.createElement("div");wrap.className="nav-item";const check=document.createElement("input");check.type="checkbox";check.className="section-toggle";check.checked=true;check.dataset.sectionToggle=key;check.setAttribute("aria-label","تفعيل قسم "+(SECTION_LABELS[key]||key));check.addEventListener("change",()=>toggleSectionEnabled(key,check.checked));btn.parentNode.insertBefore(wrap,btn);wrap.appendChild(check);wrap.appendChild(btn);});applyActiveSections(getActiveSections());}
function getActiveSections(){return [...document.querySelectorAll(".section-toggle:checked")].map(e=>e.dataset.sectionToggle)}
function applyActiveSections(keys){const set=new Set(keys||Object.keys(SECTION_LABELS));document.querySelectorAll(".section-toggle").forEach(ch=>{ch.checked=set.has(ch.dataset.sectionToggle);const key=ch.dataset.sectionToggle;const page=document.querySelector(`[data-section="${key}"]`);if(page)page.classList.toggle("section-disabled",!ch.checked);const wrap=ch.closest(".nav-item");if(wrap)wrap.classList.toggle("section-disabled-nav",!ch.checked);});}
function toggleSectionEnabled(key,enabled){const page=document.querySelector(`[data-section="${key}"]`);if(page)page.classList.toggle("section-disabled",!enabled);const wrap=document.querySelector(`.section-toggle[data-section-toggle="${key}"]`)?.closest(".nav-item");if(wrap)wrap.classList.toggle("section-disabled-nav",!enabled);if(!enabled&&document.querySelector(`.nav-tab.active[data-target="${key}"]`)){const next=document.querySelector(".section-toggle:checked");if(next)goToSection(next.dataset.sectionToggle);} }

/* ===== Navigation and clinical workflow ===== */
function goToSection(key, button){
  if(key==="reports")return openHeaderSectionOverlay("reports");
  const section=document.querySelector(`[data-section="${key}"]`)||document.getElementById(key);
  if(!section){console.warn("Section not found:",key);return false;}
  section.classList.remove("care-tool-page-hidden");
  const toggle=document.querySelector(`.section-toggle[data-section-toggle="${key}"]`);if(toggle&&!toggle.checked){toggle.checked=true;toggleSectionEnabled(key,true);}
  document.querySelectorAll(".nav-tab").forEach(b=>b.classList.toggle("active",b.dataset.target===key));
  // Carry over the same-visit screening values into the corresponding follow-up table only when empty.
  if(["htn","dm","cvd","stroke"].includes(key)){const tableId={htn:"htnTable",dm:"dmTable",cvd:"cvdTable",stroke:"strokeTable"}[key];prefillDiseaseFollowupRow(tableId);}
  section.scrollIntoView({behavior:"smooth",block:"start"});
  if(key==="reports")updateReports();
  return true;
}
/* ===== Care tools menu and local follow-up reminders ===== */
const CARE_REMINDERS_KEY="ALDHALEA_HOSPITAL_CARE_REMINDERS_V1";
let careReminderTimer=null;
function toggleCareToolsMenu(event){
  if(event){event.preventDefault();event.stopPropagation();}
  const panel=document.getElementById("careToolsPanel"),button=document.getElementById("careToolsToggle");
  if(!panel||!button)return false;
  const opening=panel.hidden;
  panel.hidden=!opening;button.setAttribute("aria-expanded",opening?"true":"false");
  if(opening){const first=panel.querySelector("[role='menuitem']");if(first)first.focus({preventScroll:true});}
  return opening;
}
function closeCareToolsMenu(){const panel=document.getElementById("careToolsPanel"),button=document.getElementById("careToolsToggle");if(panel)panel.hidden=true;if(button)button.setAttribute("aria-expanded","false");}
function showCareToolsMenu(event){if(event){event.preventDefault?.();event.stopPropagation?.();}return openHeaderActionDialog("care");}
function initializeCareToolsMenu(){
  const wrap=document.getElementById("careToolsWrap");if(wrap&&!wrap.dataset.initialized){wrap.dataset.initialized="1";document.addEventListener("click",event=>{if(!event.target.closest("#careToolsWrap"))closeCareToolsMenu();});}
  document.addEventListener("keydown",event=>{if(event.key==="Escape"){closeCareToolsMenu();closeHeaderActionDialog();closeHeaderSectionOverlay();closePrintCenter();toggleManager(false);}});
}
function openCareTool(key){
  closeCareToolsMenu();closeHeaderActionDialog();
  const map={"care-plan":"summary","patient-care-copy":"patient-care-copy","hospital-care-copy":"hospital-care-copy",calculator:"calculator",reminder:"reminder"};
  const section=map[key];if(!section)return false;
  if(key==="care-plan"){updateSummary();generateFinalCarePlans(false);return openHeaderSectionOverlay(section);}
  if(key==="patient-care-copy"){generateFinalCarePlans(false);return openHeaderSectionOverlay(section);}
  if(key==="hospital-care-copy"){generateFinalCarePlans(false);refreshCareAttachmentIndex();return openHeaderSectionOverlay(section);}
  if(key==="reminder"){refreshCareReminderPatient();renderCareReminders();}
  if(key==="calculator")syncClinicalCalculatorFromPatient();
  return openHeaderSectionOverlay(section);
}
function getCareReminders(){try{const data=JSON.parse(localStorage.getItem(CARE_REMINDERS_KEY)||"[]");return Array.isArray(data)?data:[]}catch(err){console.warn("تعذر قراءة التذكيرات المحفوظة",err);return [];}}
function saveCareReminders(items){try{localStorage.setItem(CARE_REMINDERS_KEY,JSON.stringify(items));return true;}catch(err){console.error(err);alert("تعذر حفظ التذكير على هذا الجهاز. تحقق من مساحة التخزين وإعدادات المتصفح.");return false;}}
function refreshCareReminderPatient(){const el=document.getElementById("careReminderPatientContext");if(!el)return;const name=val("patientName")||"مريض غير محدد",file=val("fileNo")||"رقم الملف غير متاح";el.textContent=`المريض الذي سيرتبط به أي تذكير جديد: ${name} — ${file}. تأكد من فتح سجل المريض الصحيح قبل حفظ التذكير.`;}
function initializeCareReminders(){
  const date=document.getElementById("careReminderDate");if(date&&!date.value)date.value=todayISO();
  refreshCareReminderPatient();renderCareReminders();checkDueCareReminders();
  if(careReminderTimer)clearInterval(careReminderTimer);careReminderTimer=setInterval(checkDueCareReminders,15000);
  document.addEventListener("visibilitychange",()=>{if(!document.hidden)checkDueCareReminders();});window.addEventListener("focus",checkDueCareReminders);
}
function addCareReminder(){
  const date=val("careReminderDate"),time=val("careReminderTime"),kind=val("careReminderKind")||"موعد مراجعة",message=val("careReminderMessage").trim();
  if(!date||!time){alert("حدد تاريخ الموعد ووقته أولًا.");return false;}
  const due=new Date(`${date}T${time}:00`);if(Number.isNaN(due.getTime())){alert("التاريخ أو الوقت غير صالح.");return false;}
  if(due.getTime()<=Date.now()){alert("اختر موعدًا في المستقبل حتى يعمل التذكير في وقته.");return false;}
  const item={id:`r-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,patientName:val("patientName")||"مريض غير محدد",fileNo:val("fileNo")||"",clinic:val("clinic")||"",kind,message:message||kind,dueAt:due.toISOString(),createdAt:new Date().toISOString(),status:"pending",notifiedAt:""};
  const items=getCareReminders();items.push(item);if(!saveCareReminders(items))return false;
  const text=document.getElementById("careReminderMessage");if(text)text.value="";refreshCareReminderPatient();renderCareReminders();alert("تم حفظ التذكير على هذا الجهاز. يجب إبقاء البرنامج مفتوحًا للحصول على التنبيه داخل التطبيق، ما لم تسمح إعدادات المتصفح بإشعارات موثوقة.");return true;
}
function formatCareReminderDate(value){const d=new Date(value);if(Number.isNaN(d.getTime()))return "موعد غير صالح";try{return d.toLocaleString("ar-YE",{dateStyle:"medium",timeStyle:"short"})}catch{return d.toLocaleString();}}
function renderCareReminders(){
  const root=document.getElementById("careReminderList"),count=document.getElementById("careReminderCount");if(!root)return;
  const items=getCareReminders().sort((a,b)=>new Date(a.dueAt)-new Date(b.dueAt));root.replaceChildren();
  const active=items.filter(x=>x.status==="pending"||x.status==="alerted").length;if(count)count.textContent=`${items.length} تذكير محفوظ · ${active} غير مكتمل`;
  if(!items.length){const empty=document.createElement("div");empty.className="care-reminder-empty";empty.textContent="لا توجد تذكيرات محفوظة بعد.";root.appendChild(empty);return;}
  items.forEach(item=>{
    const card=document.createElement("article");card.className=`care-reminder-card${item.status==="done"?" is-done":""}`;
    const info=document.createElement("div");info.className="care-reminder-info";
    const heading=document.createElement("strong");heading.textContent=`${item.kind||"تذكير"} — ${item.patientName||"مريض غير محدد"}`;
    const meta=document.createElement("small");meta.textContent=`${formatCareReminderDate(item.dueAt)}${item.fileNo?` · الملف: ${item.fileNo}`:""}${item.clinic?` · ${item.clinic}`:""}`;
    const detail=document.createElement("p");detail.textContent=item.message||item.kind||"تذكير متابعة";
    const status=document.createElement("span");status.className="care-reminder-status";status.textContent=item.status==="done"?"مكتمل":item.status==="alerted"?"تم التنبيه — بانتظار الإغلاق":"بانتظار الموعد";
    info.append(heading,meta,detail,status);
    const actions=document.createElement("div");actions.className="care-reminder-card-actions";
    if(item.status!=="done"){const done=document.createElement("button");done.type="button";done.className="btn btn-outline";done.textContent="تمت المتابعة";done.onclick=()=>completeCareReminder(item.id);actions.appendChild(done);}
    const del=document.createElement("button");del.type="button";del.className="delete-row";del.textContent="حذف";del.onclick=()=>deleteCareReminder(item.id);actions.appendChild(del);
    card.append(info,actions);root.appendChild(card);
  });
}
function completeCareReminder(id){const items=getCareReminders();const item=items.find(x=>x.id===id);if(!item)return;item.status="done";item.completedAt=new Date().toISOString();if(saveCareReminders(items))renderCareReminders();}
function deleteCareReminder(id){if(!confirm("هل تريد حذف هذا التذكير نهائيًا من هذا الجهاز؟"))return;const items=getCareReminders().filter(x=>x.id!==id);if(saveCareReminders(items))renderCareReminders();}
async function enableCareReminderNotifications(){
  if(!("Notification" in window)){alert("هذا المتصفح لا يدعم إشعارات النظام. سيظهر التنبيه داخل البرنامج عند فتحه.");return false;}
  try{const permission=Notification.permission==="default"?await Notification.requestPermission():Notification.permission;if(permission==="granted"){alert("تم السماح بإشعارات المتصفح. تظل موثوقية التنبيه مرتبطة بدعم المتصفح وإعدادات الجهاز وتشغيل البرنامج.");return true;}alert("لم تُمنح صلاحية الإشعارات. سيظهر التنبيه داخل البرنامج عندما يكون مفتوحًا ونشطًا.");return false;}catch(err){console.warn(err);alert("تعذر تفعيل إشعارات النظام في هذا السياق؛ سيبقى التذكير محفوظًا محليًا.");return false;}
}
function checkDueCareReminders(){
  const items=getCareReminders(),now=Date.now(),due=items.filter(x=>x.status==="pending"&&new Date(x.dueAt).getTime()<=now);if(!due.length)return;
  const delivered=[];for(const item of due){
    let notified=false,notificationFailed=false;
    if("Notification" in window&&Notification.permission==="granted"){
      try{const n=new Notification("تذكير رعاية — مستشفى الضالع الحديث",{body:`${item.patientName||"مريض غير محدد"}${item.fileNo?` · ${item.fileNo}`:""}\n${item.kind||"موعد متابعة"}: ${item.message||"حان موعد المتابعة"}`});n.onclick=()=>{window.focus();openCareTool("reminder");n.close?.();};notified=true;}catch(err){notificationFailed=true;console.warn("فشل إشعار النظام",err);}
    }
    if(notified||!document.hidden){item.status="alerted";item.notifiedAt=new Date().toISOString();if(notificationFailed)item.notificationFailed=true;delivered.push(item);}
  }
  if(delivered.length){saveCareReminders(items);renderCareReminders();delivered.forEach(item=>{if(item.notificationFailed||!(typeof Notification!=="undefined"&&Notification.permission==="granted")){alert(`حان موعد التذكير\nالمريض: ${item.patientName||"غير محدد"}\n${item.kind||"متابعة"}\n${item.message||""}`);}});}
}

/* ===== Automatic draft saving and recovery ===== */
function setAutoDraftStatus(message, state="ready"){
  const el=document.getElementById("autosaveStatus");if(!el)return;
  el.textContent=message;el.dataset.state=state;
  el.title=state==="error"?"تعذر حفظ المسودة تلقائيًا؛ اضغط حفظ/تحديث يدويًا وتحقق من مساحة التخزين.":"تُحفظ المسودة محليًا على هذا الجهاز. يجب الضغط على حفظ/تحديث لاعتماد السجل النهائي.";
}
function collectCalculatorDraft(){
  return [...document.querySelectorAll("#calculator input[id],#calculator select[id],#calculator textarea[id]")].map(el=>({id:el.id,value:el.value,checked:(el.type==="checkbox"||el.type==="radio")?el.checked:undefined}));
}
function collectExtraDraftControls(){
  const nodes=[...document.querySelectorAll(".document-shell input,.document-shell select,.document-shell textarea")].filter(el=>!el.closest("table")&&!el.closest(".no-autosave")&&!/^(file|button|submit|reset)$/i.test(el.type||"")&&!['fileNo','serialNoDisplay','bmi'].includes(el.id));
  let anonymousIndex=0;
  return nodes.map(el=>({key:el.id?"id:"+el.id:"auto:"+(anonymousIndex++),id:el.id||"",name:el.name||"",value:el.value??"",checked:(el.type==="checkbox"||el.type==="radio")?el.checked:undefined}));
}
function applyExtraDraftControls(items){
  if(!Array.isArray(items))return;
  const nodes=[...document.querySelectorAll(".document-shell input,.document-shell select,.document-shell textarea")].filter(el=>!el.closest("table")&&!el.closest(".no-autosave")&&!/^(file|button|submit|reset)$/i.test(el.type||"")&&!['fileNo','serialNoDisplay','bmi'].includes(el.id));
  const byId=new Map(nodes.filter(el=>el.id).map(el=>["id:"+el.id,el]));
  items.forEach((item,index)=>{
    const el=item.id?byId.get("id:"+item.id):nodes.filter(node=>!node.id)[Number(String(item.key||"").replace("auto:",""))];
    if(!el)return;
    if(typeof item.checked==="boolean")el.checked=item.checked;
    else if("value" in item)el.value=item.value??"";
  });
}
function applyCalculatorDraft(items){
  if(!Array.isArray(items))return;
  items.forEach(item=>{const el=document.getElementById(item.id);if(!el||!el.closest("#calculator"))return;if(typeof item.checked==="boolean")el.checked=item.checked;else if("value" in item)el.value=item.value??"";});
}
function autosaveHasMeaningfulContent(patient,calculator,controls){
  const ignore=new Set(["fileNo","visitDate"]);
  if(basicFieldIds.some(id=>!ignore.has(id)&&String(patient?.[id]??"").trim()))return true;
  if(extraFieldIds.some(id=>String(patient?.[id]??"").trim()))return true;
  if(checkboxIds.some(id=>!!patient?.[id]))return true;
  if(radioNames.some(name=>!!patient?.[name]))return true;
  // Ignore default dates in blank table rows; detect actual entered values in non-date cells.
  for(const [tableId,schema] of Object.entries(tableSchemas)){
    const rows=patient?.[tableId]||[];
    if(rows.some(row=>schema.some((kind,i)=>kind!=="date"&&String(row?.[i]??"").trim())))return true;
  }
  if((patient?.labsTable||[]).some(row=>[0,1,2,3,4,6].some(i=>String(row?.[i]??"").trim())))return true;
  if((patient?.rxTable||[]).some(row=>row.some(v=>String(v??"").trim())))return true;
  if((patient?.diagnosticsTable||[]).some(row=>row.some(v=>String(v??"").trim())))return true;
  if((calculator||[]).some(item=>String(item.value??"").trim()!==""&&item.id!=="clinicalCalcText"))return true;
  if((controls||[]).some(item=>typeof item.checked==="boolean"?item.checked:(String(item.value??"").trim()!==""&&!['visitDate','fileNo','serialNoDisplay','bmi','clinicalCalcText'].includes(item.id))))return true;
  const allSections=Object.keys(SECTION_LABELS||{});
  if(Array.isArray(patient?.activeSections)&&allSections.length&&patient.activeSections.length!==allSections.length)return true;
  return false;
}
function persistAutoDraft(){
  if(autosaveRestoring)return false;
  try{
    const patient=collectPatient(),calculator=collectCalculatorDraft(),controls=collectExtraDraftControls();
    if(!autosaveHasMeaningfulContent(patient,calculator,controls)){
      localStorage.removeItem(AUTOSAVE_DRAFT_KEY);autosaveDraftDirty=false;
      setAutoDraftStatus("الحفظ التلقائي جاهز — لا توجد مسودة", "ready");return true;
    }
    const draft={format:"ALDHALEA_HOSPITAL_AUTOSAVE_DRAFT",version:1,savedAt:new Date().toISOString(),patientId:currentPatientId||null,patient,calculator,controls};
    localStorage.setItem(AUTOSAVE_DRAFT_KEY,JSON.stringify(draft));
    autosaveDraftDirty=true;
    setAutoDraftStatus("✓ حُفظت المسودة تلقائيًا · لم تُعتمد كسجل نهائي","saved");
    return true;
  }catch(err){
    console.error("Automatic draft save failed:",err);
    setAutoDraftStatus("تعذّر الحفظ التلقائي — اضغط حفظ/تحديث","error");
    return false;
  }
}
function clearAutosavedDraft(message="تم مسح المسودة المؤقتة"){
  try{localStorage.removeItem(AUTOSAVE_DRAFT_KEY);autosaveDraftDirty=false;setAutoDraftStatus(message,"ready");}
  catch(err){console.error(err);setAutoDraftStatus("تعذّر مسح حالة المسودة المؤقتة","error");}
}
function restoreAutosavedDraft(){
  let draft;
  try{const raw=localStorage.getItem(AUTOSAVE_DRAFT_KEY);if(!raw)return false;draft=JSON.parse(raw);}
  catch(err){console.error("Invalid autosaved draft:",err);alert("عُثر على مسودة تالفة لا يمكن قراءتها. لن تُستبدل سجلات المرضى المحفوظة. يمكنك تجاهل المسودة والبدء من جديد.");clearAutosavedDraft("لم توجد مسودة قابلة للاستعادة");return false;}
  if(!draft||draft.format!=="ALDHALEA_HOSPITAL_AUTOSAVE_DRAFT"||draft.version!==1||!draft.patient||typeof draft.patient!=="object"){
    clearAutosavedDraft("لم توجد مسودة قابلة للاستعادة");return false;
  }
  const stamp=draft.savedAt?new Date(draft.savedAt).toLocaleString():"وقت غير معروف";
  const patientName=String(draft.patient.patientName||"مسودة بدون اسم");
  const restore=confirm(`عُثر على عمل محفوظ تلقائيًا لم يُعتمد بعد.\nالمريض/المسودة: ${patientName}\nآخر حفظ تلقائي: ${stamp}\n\nاضغط «موافق» لاستعادة الحقول والجداول ومتابعة العمل.\nاضغط «إلغاء» لتجاهل المسودة وبدء نموذج فارغ.`);
  if(!restore){clearAutosavedDraft("تم تجاهل المسودة المحفوظة تلقائيًا");return false;}
  autosaveRestoring=true;
  try{
    const savedId=draft.patientId, exists=!!(savedId&&getDB().some(p=>p.id===savedId));
    currentPatientId=exists?savedId:null;
    const patient={...draft.patient};
    if(savedId&&!exists){delete patient.id;delete patient.serialNo;patient.fileNo="";}
    applyPatient(patient);
    applyCalculatorDraft(draft.calculator);
    applyExtraDraftControls(draft.controls);
    updateSummary();updateHeaderSummaries();updateCurrentRecord();
    autosaveDraftDirty=true;
    setAutoDraftStatus("✓ استُعيدت المسودة · احفظ/حدّث لاعتماد التغييرات","saved");
    refreshPatientFiles();
    return true;
  }catch(err){
    console.error("Draft restore failed:",err);
    setAutoDraftStatus("تعذرت استعادة المسودة؛ البيانات المحفوظة لم تُحذف","error");
    alert("تعذرت استعادة المسودة تلقائيًا. لم تُحذف السجلات المحفوظة. يمكنك فتح السجلات المحفوظة أو استعادة نسخة احتياطية.");
    return false;
  }finally{autosaveRestoring=false;}
}
function initializeAutoDraft(){
  // Offer recovery before listeners start writing, so an empty initial form cannot overwrite the old draft.
  restoreAutosavedDraft();
  const handleChange=event=>{
    if(autosaveRestoring)return;
    const target=event.target;
    if(!target||!target.closest)return;
    if(!target.closest(".document-shell")&&!target.matches(".section-toggle"))return;
    if(target.matches('input[type="file"],button,[type="submit"]'))return;
    persistAutoDraft();
  };
  // Bubble phase lets field-specific handlers (for example BMI recalculation) finish first.
  document.addEventListener("input",handleChange);
  document.addEventListener("change",handleChange);
  // Also snapshot after buttons that add/remove rows or fill preset values programmatically.
  document.addEventListener("click",event=>{
    const target=event.target;
    if(!target||!target.closest||!target.closest(".document-shell"))return;
    if(target.matches('input[type="file"]'))return;
    persistAutoDraft();
  });
  window.addEventListener("beforeunload",event=>{
    if(!autosaveDraftDirty)return;
    // The draft has already been persisted; this extra warning prevents accidental navigation.
    event.preventDefault();event.returnValue="";
  });
}

function updateCurrentRecord(){
  const name=val("patientName").trim()||"مريض جديد";
  const file=val("fileNo").trim()||"—";
  const date=val("visitDate")||"—";
  const patient=currentPatientId?getDB().find(p=>p.id===currentPatientId):null;
  const serial=patient?.serialNo||"";
  const n=document.getElementById("currentRecordName"),f=document.getElementById("currentRecordFile"),d=document.getElementById("currentRecordDate"),st=document.getElementById("recordStatus");
  const serialEl=document.getElementById("currentRecordSerial"),returnBtn=document.getElementById("returnToEditBtn"),saveBtn=document.getElementById("savePatientBtn");
  if(n)n.textContent=name;if(f)f.textContent=file;if(d)d.textContent=date;
  if(serialEl)serialEl.textContent=serial?String(serial):"يُخصص بعد الحفظ";
  if(st){st.textContent=patient?"سجل محفوظ · وضع التعديل":"مسودة جديدة · لم يُخصص رقم بعد";st.classList.toggle("saved",!!patient);}
  if(returnBtn)returnBtn.hidden=!patient;
  if(saveBtn)saveBtn.textContent=patient?"💾 تحديث بيانات المريض":"💾 حفظ المريض وتخصيص الرقم";
  const serialField=document.getElementById("serialNoDisplay");if(serialField)serialField.value=serial?String(serial):"";
}

/* ===== Diagnostic procedures table ===== */
function addDiagnosticRow(type="",name=""){
  const tb=document.querySelector("#diagnosticsTable tbody");if(!tb)return;
  const tr=document.createElement("tr");tr.appendChild(cellText(tb.children.length+1));
  const tdType=document.createElement("td"),sel=document.createElement("select");
  sel.innerHTML='<option value="">اختر النوع</option><option>وظيفي</option><option>تصويري</option><option>مخبري</option><option>منظار</option><option>نسيجي</option><option>آخر</option>';sel.value=type;tdType.appendChild(sel);tr.appendChild(tdType);
  tr.appendChild(inputCell(name,"اسم الفحص"));tr.appendChild(inputCell("","النتيجة / الوصف"));tr.appendChild(inputCell("","الانطباع التشخيصي"));
  const tdDate=document.createElement("td"),dt=document.createElement("input");dt.type="date";dt.value=todayISO();tdDate.appendChild(dt);tr.appendChild(tdDate);
  tr.appendChild(inputCell("","التوصية"));const action=document.createElement("td");action.className="action-cell no-print";action.innerHTML='<button type="button" class="delete-row" onclick="removeRow(this)">حذف</button>';tr.appendChild(action);tb.appendChild(tr);renumberTable("diagnosticsTable");
}
function addDiagnosticPreset(ar,en){let type="تصويري";if(/ECG|Echocardiography|Doppler/i.test(en))type="وظيفي";addDiagnosticRow(type,`${ar} (${en})`);}
function addSelectedProcedures(){const map={ecg:["وظيفي","تخطيط القلب الكهربائي (ECG)"],echo:["وظيفي","تخطيط صدى القلب (Echocardiography)"],xray:["تصويري","الأشعة السينية (X-Ray)"],ultrasound:["تصويري","الموجات فوق الصوتية (Ultrasound)"],ct:["تصويري","الأشعة المقطعية (CT)"],mri:["تصويري","الرنين المغناطيسي (MRI)"],doppler:["تصويري","دوبلر الأوعية (Doppler)"],gastroscopy:["منظار","منظار المعدة (Gastroscopy)"],colonoscopy:["منظار","منظار القولون (Colonoscopy)"]};const chosen=[...document.querySelectorAll(".procedure-choice:checked")];if(!chosen.length){alert("يرجى تحديد إجراء واحد على الأقل.");return;}chosen.forEach(ch=>{const item=map[ch.value];if(item)addDiagnosticRow(item[0],item[1]);ch.checked=false;});updateSummary();}
function clearProcedureChoices(){const checked=[...document.querySelectorAll(".procedure-choice")].some(ch=>ch.checked);if(!checked)return;if(!confirm("تأكيد مسح الاختيارات\nهل تريد إلغاء تحديد الإجراءات المختارة؟ لن تُحذف الإجراءات التي أُضيفت إلى الجدول."))return;document.querySelectorAll(".procedure-choice").forEach(ch=>ch.checked=false);}

/* ===== Clinical calculator: formula helpers ===== */
function num(id){const x=val(id).trim();if(x==="")return null;const n=Number(x);return Number.isFinite(n)?n:null;}
function fmt(n,d=1){return Number.isFinite(n)?n.toLocaleString("en-US",{maximumFractionDigits:d,minimumFractionDigits:d}):"—";}
function resultCard(label,value,unit="",note=""){return `<div class="calc-result-card"><span>${esc(label)}</span><strong>${esc(String(value))}${unit?` <small>${esc(unit)}</small>`:""}</strong>${note?`<small>${esc(note)}</small>`:""}</div>`;}
function calculateClinicalResults(){
  const age=num("ccAge"),sex=val("ccSex");
  const invalidInputs=[];
  const bounded=(id,min,max,label,integer=false)=>{
    const value=num(id);if(value===null)return null;
    if(value<min||value>max||(integer&&!Number.isInteger(value))){invalidInputs.push(`${label}: القيمة ${value} خارج النطاق المدخل المقبول (${min}–${max}${integer?", عدد صحيح":""})؛ لم تدخل في الحساب.`);return null;}
    return value;
  };
  const w=bounded("ccWeight",1,400,"الوزن"),h=bounded("ccHeight",30,250,"الطول"),sbp=bounded("ccSBP",30,300,"الضغط الانقباضي"),dbp=bounded("ccDBP",20,200,"الضغط الانبساطي"),hr=bounded("ccHR",1,250,"النبض"),qt=bounded("ccQT",100,800,"QT"),glu=bounded("ccGlucose",1,1500,"الغلوكوز"),a1c=bounded("ccA1c",2,25,"HbA1c"),scr=bounded("ccCreatinine",0.1,30,"الكرياتينين"),bun=bounded("ccBUN",1,300,"BUN"),na=bounded("ccSodium",80,200,"الصوديوم"),k=bounded("ccPotassium",1,12,"البوتاسيوم"),cl=bounded("ccChloride",50,150,"الكلوريد"),hco=bounded("ccBicarb",1,60,"البيكربونات"),ca=bounded("ccCalcium",1,20,"الكالسيوم"),alb=bounded("ccAlbumin",0.1,8,"الألبومين");
  if(age!==null&&(age<0||age>120||!Number.isFinite(age)))invalidInputs.push(`العمر: القيمة ${age} خارج النطاق المقبول (0–120 سنة)؛ لن تستخدم في معادلات العمر.`);
  const out=[],lines=[];const add=(label,value,unit="",note="")=>{out.push(resultCard(label,value,unit,note));lines.push(`${label}: ${value}${unit?" "+unit:""}${note?" — "+note:""}`);};
  const adultAgeValid=Number.isInteger(age)&&age>=18&&age<=120;
  const validSex=sex==="male"||sex==="female";
  if(w!==null&&h!==null){add("مؤشر كتلة الجسم (BMI)",fmt(w/((h/100)**2),1),"kg/m²");add("مساحة سطح الجسم (Mosteller)",fmt(Math.sqrt(w*h/3600),2),"m²");if(validSex){const inches=h/2.54,ibw=(sex==="male"?50:45.5)+2.3*(inches-60);add("الوزن المثالي التقديري (Devine)",fmt(Math.max(0,ibw),1),"kg","تقدير حسابي فقط");if(adultAgeValid){const bmr=10*w+6.25*h-5*age+(sex==="male"?5:-161);add("الاحتياج الأساسي التقديري للطاقة (Mifflin–St Jeor)",fmt(bmr,0),"kcal/day","تقدير طاقة الراحة وليس وصفة غذائية");}}}
  if(sbp!==null&&dbp!==null&&sbp>=dbp){add("متوسط الضغط الشرياني (MAP)",fmt(dbp+(sbp-dbp)/3,1),"mmHg");add("ضغط النبض",fmt(sbp-dbp,1),"mmHg");if(hr!==null)add("مؤشر الصدمة",fmt(hr/sbp,2),"","يفسر ضمن السياق السريري");}
  else if(sbp!==null&&dbp!==null&&sbp<dbp)invalidInputs.push("ضغط الدم: الانقباضي أقل من الانبساطي؛ لم تحسب مؤشرات الضغط.");
  if(adultAgeValid&&w!==null&&scr!==null&&validSex){const crcl=((140-age)*w)/(72*scr)*(sex==="female"?.85:1);if(Number.isFinite(crcl)&&crcl>0)add("تصفية الكرياتينين (Cockcroft–Gault)",fmt(crcl,1),"mL/min","تقدير يعتمد على الوزن والعمر والجنس؛ راجع طريقة الوزن المناسبة سريريًا");}
  if(adultAgeValid&&scr!==null&&validSex){const kappa=sex==="female"?.7:.9,alpha=sex==="female"?-.241:-.302;const egfr=142*Math.pow(Math.min(scr/kappa,1),alpha)*Math.pow(Math.max(scr/kappa,1),-1.2)*Math.pow(.9938,age)*(sex==="female"?1.012:1);if(Number.isFinite(egfr)&&egfr>0)add("معدل الترشيح الكبيبي (CKD-EPI 2021)",fmt(egfr,1),"mL/min/1.73m²","معادلة البالغين دون معامل عرقي؛ لا تستخدم منفردة لتشخيص مرض كلوي مزمن");}
  if(scr!==null&&!adultAgeValid)add("معادلات وظائف الكلى للبالغين","لم تُحسب","","تتطلب العمر 18–120 سنة؛ لمن هم دون 18 عامًا استخدم معادلة أطفال معتمدة بحسب العمر والطول والجنس");
  if(a1c!==null)add("متوسط السكر التقديري (eAG)",fmt(28.7*a1c-46.7,1),"mg/dL","تحويل تقريبي من HbA1c وليس قياس غلوكوز مباشرًا");
  if(na!==null&&glu!==null){const corrected=na+1.6*((glu-100)/100);add("الصوديوم المصحح للغلوكوز",fmt(corrected,1),"mmol/L","معادلة تقريبية؛ قد تختلف الصيغة بحسب مستوى الغلوكوز");}
  if(na!==null&&bun!==null&&glu!==null){add("الأسمولالية المحسوبة",fmt(2*na+glu/18+bun/2.8,1),"mOsm/kg");}
  if(na!==null&&cl!==null&&hco!==null){add("فجوة الأنيونات",fmt(na-cl-hco,1),"mmol/L","دون احتساب البوتاسيوم");}
  if(ca!==null&&alb!==null){add("الكالسيوم المصحح للألبومين",fmt(ca+.8*(4-alb),2),"mg/dL","صيغة تقديرية؛ يفضّل الكالسيوم المتأين عند الحاجة");}
  if(qt!==null&&hr!==null){const qtc=qt/Math.sqrt(60/hr);add("QTc (Bazett)",fmt(qtc,0),"ms","تقريب؛ قد تقل دقة Bazett عند سرعات قلبية مرتفعة أو منخفضة");}
  if(k!==null)add("البوتاسيوم المدخل",fmt(k,1),"mmol/L","قارن بالمدى المرجعي للمختبر والسياق السريري");
  if(invalidInputs.length){out.push(`<div class="calc-result-card calc-warning"><span>مدخلات تحتاج إلى مراجعة</span><strong>${esc(String(invalidInputs.length))}</strong><small>${esc(invalidInputs.join("؛ "))}</small></div>`);lines.push("مدخلات لم تستخدم بسبب تجاوز النطاق أو تعارض المدخلات:\n- "+invalidInputs.join("\n- "));}
  if(!out.length){document.getElementById("clinicalCalcResults").innerHTML='<div class="calc-empty">أدخل مجموعة واحدة أو أكثر من القيم المطلوبة ثم أعد الحساب.</div>';document.getElementById("clinicalCalcText").value="";return [];}
  const note="النتائج تقديرية للمساندة السريرية وليست تشخيصًا أو قرارًا علاجيًا مستقلًا.";document.getElementById("clinicalCalcResults").innerHTML=out.join("")+`<p class="calc-disclaimer">${esc(note)}</p>`;document.getElementById("clinicalCalcText").value=lines.join("\n")+"\n\n"+note;return lines;
}
function resetClinicalCalculator(){if(!confirm("تأكيد تصفير الحاسبة\nسيتم تصفير مدخلات الحاسبة ونتائجها فقط، ولن تُحذف بيانات المريض أو السجلات المحفوظة. هل تريد المتابعة؟"))return;clearClinicalCalculatorFields();persistAutoDraft?.();}
async function copyClinicalResults(){const text=val("clinicalCalcText");if(!text){alert("احسب النتائج أولًا حتى يتوفر ملخص للنسخ.");return;}try{await navigator.clipboard.writeText(text);alert("تم نسخ ملخص النتائج.");}catch{const e=document.getElementById("clinicalCalcText");e.focus();e.select();const ok=document.execCommand("copy");alert(ok?"تم نسخ ملخص النتائج.":"تعذر النسخ التلقائي؛ تم تحديد النص لنسخه يدويًا.");}}
function calculateRiskScores(){
  const read=id=>{const raw=val(id);if(raw===""||raw===null||raw===undefined)return null;const n=Number(raw);return Number.isFinite(n)?n:null;};
  const chaItems=["ccHeartFailure","ccHypertension","ccDiabetes","ccStrokeHistory","ccVascular","ccAgeScore","ccSexScore"];
  const hasItems=["ccBleed","ccRenalBleed","ccLiverBleed","ccStrokeBleed","ccUncontrolledBP","ccLabileINR","ccAgeBleed","ccAlcohol","ccDrugs"];
  const score=(ids)=>{const missing=ids.filter(id=>read(id)===null);return missing.length?{value:null,missing}:{value:ids.reduce((sum,id)=>sum+read(id),0),missing:[]};};
  const cha=score(chaItems),has=score(hasItems),el=document.getElementById("clinicalRiskResults");
  const chaHtml=cha.value===null?resultCard("CHA₂DS₂-VASc","غير مكتملة","","أكمل أو أكّد البنود: "+cha.missing.map(id=>document.querySelector(`label[for="${id}"]`)?.textContent||id).join("، ")):resultCard("CHA₂DS₂-VASc",String(cha.value),"نقطة","درجة مساعدة لتقدير خطر السكتة عند مرضى الرجفان الأذيني المناسبين");
  const hasHtml=has.value===null?resultCard("HAS-BLED","غير مكتملة","","أكمل أو أكّد البنود: "+has.missing.map(id=>document.querySelector(`label[for="${id}"]`)?.textContent||id).join("، ")):resultCard("HAS-BLED",String(has.value),"نقطة","راجع تعريف كل بند وعوامل النزف القابلة للتعديل");
  el.innerHTML=chaHtml+hasHtml+`<p class="calc-disclaimer">لا تُفسَّر الدرجة قبل إدخال/تأكيد جميع البنود ذات الصلة. تُستخدم هذه المقاييس في سياق سريري مناسب فقط؛ لا تحدد بدء أو إيقاف مضاد التخثر بمفردها. راجع التعريف الرسمي لكل عامل، خصوصًا وظائف الكلى والكبد والضغط غير المضبوط وINR والأدوية المصاحبة.</p>`;
  return {chadsvasc:cha.value,hasbled:has.value,missing:{chadsvasc:cha.missing,hasbled:has.missing}};
}
function labNumericValue(row, expected){
  const raw=String(row?.[2]??"").trim().replace(/,/g,".");const m=raw.match(/-?\d+(?:\.\d+)?/);if(!m)return null;let value=Number(m[0]);if(!Number.isFinite(value))return null;
  let unit=String(row?.[3]??"").toLowerCase().replace(/[µμ]/g,"u").replace(/\s+/g,"").replace(/litre|liter/g,"l");
  if(expected==="glucose"){if(/mg\/?dl|mgdl|mg%/.test(unit))return value;if(/mmol\/?l|mmoll/.test(unit))return value*18.018;return null;}
  if(expected==="creatinine"){if(/mg\/?dl|mgdl/.test(unit))return value;if(/umol\/?l|umoll/.test(unit))return value/88.4;return null;}
  if(expected==="bun"){if(/mg\/?dl|mgdl/.test(unit))return value;return null;}
  if(expected==="a1c"){if(!unit||unit==="%"||unit==="pct"||unit==="percent")return value;return null;}
  if(expected==="albumin"){if(/g\/?dl|gdl/.test(unit))return value;if(/g\/?l|gl/.test(unit))return value/10;return null;}
  if(expected==="calcium"){if(/mg\/?dl|mgdl/.test(unit))return value;if(/mmol\/?l|mmoll/.test(unit))return value*4.008;return null;}
  if(expected==="electrolyte"){if(/mmol\/?l|mmoll|meq\/?l|meql/.test(unit))return value;return null;}
  return null;
}
function findLatestLabValue(pattern,expected){
  const rows=getSimpleTable("labsTable").map((row,index)=>({row,index})).filter(x=>x.row?.some(v=>String(v??"").trim()));
  rows.sort((a,b)=>String(b.row?.[5]||"").localeCompare(String(a.row?.[5]||""))||b.index-a.index);
  for(const item of rows){const name=String(item.row?.[1]||"").toLowerCase();if(!pattern.test(name))continue;const value=labNumericValue(item.row,expected);if(value!==null)return {value,unit:item.row?.[3]||"",name:item.row?.[1]||"",date:item.row?.[5]||"",source:"جدول الفحوصات المخبرية"};}
  return null;
}
function syncClinicalCalculatorFromPatient(){
  if(!val("patientName").trim()&&!currentPatientId){alert("أدخل بيانات المريض أو افتح سجلًا محفوظًا أولًا.");return;}
  const calcIds=["ccAge","ccSex","ccWeight","ccHeight","ccSBP","ccDBP","ccHR","ccQT","ccGlucose","ccA1c","ccCreatinine","ccBUN","ccSodium","ccPotassium","ccChloride","ccBicarb","ccCalcium","ccAlbumin"];
  const riskScoreIds=["ccHeartFailure","ccHypertension","ccDiabetes","ccStrokeHistory","ccVascular","ccAgeScore","ccSexScore","ccBleed","ccRenalBleed","ccLiverBleed","ccStrokeBleed","ccUncontrolledBP","ccLabileINR","ccAgeBleed","ccAlcohol","ccDrugs"];
  const hasCalcData=[...calcIds,...riskScoreIds].some(id=>val(id).trim()!=="");
  if(hasCalcData&&!confirm("سيتم تحديث مدخلات الحاسبة وعوامل درجات الخطورة من بيانات المريض المتاحة، وقد تُستبدل القيم المكتوبة يدويًا. ستبقى العوامل غير المعروفة فارغة حتى تؤكدها صراحة. هل تريد المتابعة؟"))return;
  [...calcIds,...riskScoreIds].forEach(id=>setVal(id,""));
  const age=num("age"),weight=num("weight"),height=num("height"),pulse=num("pulseScreen");
  if(age!==null)setVal("ccAge",age);if(weight!==null)setVal("ccWeight",weight);if(height!==null)setVal("ccHeight",height);if(pulse!==null)setVal("ccHR",pulse);
  const bp=val("bpScreen").match(/(\d+(?:\.\d+)?)\s*[/\-]\s*(\d+(?:\.\d+)?)/);if(bp){setVal("ccSBP",bp[1]);setVal("ccDBP",bp[2]);}
  const g=val("gender");if(g){const lower=g.toLowerCase();if(/أنث|female|امرأة|نساء/.test(lower))setVal("ccSex","female");else if(/ذكر|male|رجل/.test(lower))setVal("ccSex","male");}
  const warnings=[],sources=[];
  const mapLabs=[
    ["ccGlucose",/glucose|غلوكوز|جلوكوز|سكر\s*(صائم|عشوائي)?|fbs|rbs/i,"glucose"],
    ["ccA1c",/hba1c|a1c|هيموغلوبين\s*سكري|سكر\s*تراكمي/i,"a1c"],
    ["ccCreatinine",/creatinine|كرياتينين/i,"creatinine"],
    ["ccBUN",/\bbun\b|blood\s*urea\s*nitrogen|نيتروجين\s*اليوريا/i,"bun"],
    ["ccSodium",/sodium|\bna\b|صوديوم/i,"electrolyte"],
    ["ccPotassium",/potassium|\bk\b|بوتاسيوم/i,"electrolyte"],
    ["ccChloride",/chloride|\bcl\b|كلوريد/i,"electrolyte"],
    ["ccBicarb",/bicarbonate|hco.?3|بيكربونات/i,"electrolyte"],
    ["ccCalcium",/calcium|كالسيوم/i,"calcium"],
    ["ccAlbumin",/albumin|ألبومين/i,"albumin"]
  ];
  const fillLab=(id,pattern,unitType)=>{const lab=findLatestLabValue(pattern,unitType);if(lab){setVal(id,lab.value);sources.push(`${lab.name}: ${lab.value}${lab.unit?" "+lab.unit:""}${lab.date?" ("+lab.date+")":""}`);return true;}return false;};
  mapLabs.forEach(([id,pattern,unitType])=>fillLab(id,pattern,unitType));
  // Prefer the dedicated diabetes fields only as a flagged fallback because their input units are not specified in the form.
  if(!val("ccGlucose").trim()){
    const fallback=num("dmFbs")??num("dmRbs");
    if(fallback!==null){setVal("ccGlucose",fallback);warnings.push("تم نقل قيمة السكر من قسم السكري لكن الوحدة غير محددة في ذلك الحقل؛ تحقّق من أنها mg/dL قبل الحساب.");}
  }
  if(!val("ccA1c").trim()){const fallback=num("dmHba1c");if(fallback!==null){setVal("ccA1c",fallback);warnings.push("تم نقل HbA1c من قسم السكري؛ راجع أن القيمة بوحدة %.");}}
  const female=val("ccSex")==="female";const sexKnown=val("ccSex")==="male"||female;
  if(sexKnown)setVal("ccSexScore",female?"1":"0");else warnings.push("الجنس البيولوجي المطلوب لبعض المعادلات/الدرجات غير محدد؛ اختَره يدويًا إذا كان مناسبًا سريريًا.");
  if(Number.isInteger(age)&&age>=18&&age<=120){setVal("ccAgeScore",age>=75?"2":age>=65?"1":"0");setVal("ccAgeBleed",age>=65?"1":"0");}else if(age!==null)warnings.push("لم يتم تعبئة فئة العمر في درجات البالغين؛ يجب أن يكون العمر من 18 إلى 120 سنة.");
  const mapRisk=[['riskHTN','ccHypertension'],['riskDM','ccDiabetes'],['riskStroke','ccStrokeHistory'],['riskCVD','ccVascular'],['riskStroke','ccStrokeBleed']];
  mapRisk.forEach(([source,target])=>{const checked=document.getElementById(source)?.checked;if(checked)setVal(target,target==='ccStrokeHistory'?'2':'1');});
  // An unchecked box is not proof of absence; the clinician must select Yes or No explicitly. Age is only prefilled in the adult-valid range above.
  const clinical=collectPatient();
  const contextLines=[
    `المريض: ${val("patientName")||"—"} | رقم الملف: ${val("fileNo")||"—"} | العمر: ${val("age")||"—"} | الجنس: ${val("gender")||"—"}`,
    `الأمراض الإضافية وإجراءاتها:\n${otherDiseasesSummary()||"لم تُسجّل أمراض إضافية"}`,
    `التشخيص: ${[val("diagnosis"),val("comorbidDiagnoses")].filter(Boolean).join("؛ ")||"غير مدخل"}`,
    `القياسات: ضغط ${val("bpScreen")||"—"}، نبض ${val("pulseScreen")||"—"}، حرارة ${val("tempScreen")||"—"}، SpO₂ ${val("spo2Screen")||"—"}، وزن ${val("weight")||"—"} كجم، طول ${val("height")||"—"} سم، BMI ${val("bmi")||"—"}`,
    `التاريخ الشخصي: ${val("personalHistoryDetails")||"غير مفصل"} | عوامل الخطورة المحددة: ${[["riskHTN","ضغط الدم"],["riskDM","السكري"],["riskCVD","القلب/الأوعية"],["riskStroke","سكتة"],["riskKidney","الكلى"],["riskLipid","الدهون"],["riskObesity","السمنة"]].filter(([id])=>document.getElementById(id)?.checked).map(([,label])=>label).join("، ")||"لا توجد اختيارات محددة"}`,
    `التاريخ العائلي: ${val("familyHistory")||"غير مدخل"} | النشاط البدني: ${val("physicalActivityLevel")||"—"} / ${val("physicalActivityFrequency")||"—"}`,
    `الأدوية الثابتة/الحساسية: ${val("medsAllergy")||"غير مدخل"} | العلاج الحالي: ${val("dmTherapy")||"—"}`,
    `نتائج مختبرية نُقلت إلى الحاسبة: ${sources.join("؛ ")||"لم توجد نتائج ملائمة بوحدات واضحة في جدول المختبر"}`,
    `الفحوصات المطلوبة لاحقًا: ${val("plannedInvestigations")||"—"} | المتابعة: ${val("nextVisit")||val("patientFollowupTiming")||"—"}`,
    warnings.length?`تنبيهات نقل البيانات:\n- ${warnings.join("\n- ")}`:"تمت مراجعة مصادر القيم المدخلة؛ راجع الوحدة والتاريخ مع التقرير الأصلي قبل تفسير النتائج."
  ];
  setVal("ccPatientContext",contextLines.join("\n\n"));
  calculateClinicalResults();calculateRiskScores();
  persistAutoDraft?.();
  alert(`تم جلب القيم المتاحة من سجل المريض إلى الحاسبة.\nعدد نتائج المختبر التي نُقلت: ${sources.length}\n${warnings.length?"توجد ملاحظات على بعض الوحدات؛ راجع ملخص المصدر قبل اعتماد النتائج.":"راجع الوحدات والتواريخ قبل تفسير النتائج."}`);
}

/* ===== Patient education templates (editable, clinician-reviewed) ===== */
function loadPatientEducationTemplate(){
  const ids=["recommendations","emergencyInstructions","patientMedicationAdvice","patientAvoidAdvice","patientFoodAdvice","patientLifestyleAdvice","patientSameDaySigns","patientFollowupInstructions"];
  if(!confirm("إدراج نصوص توعوية مقترحة\nسيتم استبدال النص الموجود في حقول التوصيات والتوعية المحددة بقوالب عامة قابلة للتعديل. راجعها وعدّلها حسب حالة المريض قبل الطباعة أو الحفظ. هل تريد المتابعة؟"))return;
  const values={
    recommendations:"• التزم بخطة العلاج والمتابعة التي يحددها الطبيب.\n• أحضر قائمة أدويتك ونتائج الفحوصات في كل زيارة.\n• لا تعتمد على هذه الإرشادات العامة بدلًا من التشخيص أو الخطة الفردية؛ اسأل الطبيب عن أي تعليمات غير واضحة.",
    emergencyInstructions:"اذهب إلى الطوارئ فورًا ولا تنتظر موعدًا عند حدوث أي مما يلي: ألم أو ضغط شديد/مستمر في الصدر؛ ضيق نفس شديد أو مفاجئ؛ تدلّي مفاجئ في الوجه أو ضعف/خدر مفاجئ في طرف أو صعوبة الكلام أو الرؤية؛ فقدان الوعي أو ارتباك شديد أو تشنج جديد؛ نزيف شديد أو قيء دموي أو براز أسود مع دوخة/ضعف؛ تورم اللسان أو الحلق أو صعوبة التنفس بعد دواء أو طعام؛ ألم شديد مفاجئ أو تدهور سريع، أو هبوط/ارتفاع سكر مصحوب باضطراب الوعي. اطلب الإسعاف أو مساعدة شخص آخر ولا تقد السيارة بنفسك إذا كانت الأعراض شديدة.",
    patientMedicationAdvice:"تناول الأدوية التي وصفها الطبيب فقط، بالجرعة والوقت والطريقة المكتوبة. لا تبدأ دواءً أو مسكنًا أو مضادًا حيويًا أو عشبة/مكملًا من نفسك، ولا توقف الدواء أو تضاعف الجرعة دون مراجعة الطبيب. أخبر الفريق الطبي عن الحساسية وجميع الأدوية والمكملات التي تستخدمها. عند ظهور تفاعل شديد أو صعوبة تنفس أو تورم بالوجه/اللسان اطلب الطوارئ فورًا.",
    patientAvoidAdvice:"تجنب التدخين والتبغ والقات قدر الإمكان. لا تستخدم أدوية الآخرين أو الأدوية من دون وصفة. لا تستخدم مضادات الالتهاب المسكنة مثل الإيبوبروفين أو الديكلوفيناك أو النابروكسين إلا بعد سؤال الطبيب، خصوصًا مع أمراض القلب أو الكلى أو الضغط أو قرحة المعدة أو مميعات الدم. لا تغيّر حمية السوائل أو الملح تغييرًا شديدًا دون تعليمات تناسب حالتك.",
    patientFoodAdvice:"تناول غذاءً متوازنًا ومتنوّعًا وقلل الإفراط في الملح والسكر والدهون والأطعمة شديدة التصنيع. تُحدد القيود الغذائية وكمية السوائل وفق التشخيص والتحاليل والأدوية؛ لا تفرض على نفسك منع السوائل أو زيادتها بكميات كبيرة ما لم يوصِ الطبيب بذلك. سجّل الأطعمة التي تزيد الأعراض أو تسبب حساسية وأخبر الطبيب عنها.",
    patientLifestyleAdvice:"خذ قسطًا مناسبًا من الراحة وامشِ أو مارس النشاط الذي يسمح به الطبيب بحسب حالتك، وتجنب المجهود عند وجود أعراض مقلقة. راقب الضغط أو السكر أو الوزن فقط وفق الخطة المحددة لك، وسجّل الأعراض وتاريخ بدايتها. احتفظ بقائمة الأدوية ونتائج الفحوصات وأحضرها عند المراجعة، واطلب التوضيح إذا لم تفهم أي تعليمات.",
    patientSameDaySigns:"اطلب تقييمًا طبيًا اليوم أو خلال 24 ساعة إذا ظهرت أعراض جديدة أو ازدادت سوءًا دون علامات الطوارئ أعلاه، أو تكرر القيء أو تعذر الاحتفاظ بالسوائل، أو ظهرت حمى مع تدهور عام، أو قلّ البول بوضوح، أو ظهر تورم جديد/متزايد، أو حدث أثر جانبي دوائي جديد، أو استمرت قراءة منزلية غير معتادة مع أعراض. إذا كانت الأعراض شديدة أو تتفاقم سريعًا فتوجّه إلى الطوارئ فورًا. يُعدّل الطبيب هذه التعليمات وفق المرض والحالة.",
    patientFollowupInstructions:"• خلال 2–7 أيام: عند طلب الطبيب مراجعة قريبة لعرض مستمر أو نتيجة فحص أو بعد بدء/تغيير علاج، إذا كانت الحالة مستقرة ولا توجد علامات خطر.\n• خلال 2–4 أسابيع أو خلال الشهر: للمتابعة الروتينية للحالات المستقرة، ومراجعة الاستجابة للعلاج والفحوصات بحسب الخطة.\n• لا تنتظر أي موعد إذا ظهرت علامة خطر؛ اذهب إلى الطوارئ فورًا.\nيجب تحديد الموعد النهائي للمريض بحسب التشخيص وشدة الحالة ونتائج الفحوصات وقدرته على المتابعة."
  };
  Object.entries(values).forEach(([id,value])=>setVal(id,value));
  setVal("patientFollowupTiming","");
  updateSummary();
  alert("تم إدراج نصوص التوعية المقترحة. راجعها وعدّلها حسب حالة المريض، ثم احفظ السجل.");
}

/* ===== Patient reports ===== */
function reportDiagnosisText(p){return [p.diagnosis,p.comorbidDiagnoses,otherDiseasesTextFromRecord(p)].filter(Boolean).join(" ").toLowerCase();}
function reportHas(p,key){const txt=reportDiagnosisText(p);const cb={hypertension:["riskHTN",/ارتفاع\s*ضغط|ضغط\s*الدم|hypertension|\bhtn\b/],diabetes:["riskDM",/السكري|داء\s*السكر|diabetes|\bdm\b/],cardiovascular:["riskCVD",/القلب|شرايين|وعائي|coronary|cardiovascular|\bcvd\b|myocardial/],stroke:["riskStroke",/جلط[ةه]|سكت[ةه]|نقص\s*تروية|stroke|\btia\b/],kidney:["riskKidney",/الكلى|كلوي|كلية|renal|\bckd\b|creatinine/],lipids:["riskLipid",/دهون|كوليسترول|cholesterol|dyslipid|lipid/],obesity:["riskObesity",/سمنة|بدانة|زيادة\s*الوزن|obesity/],other:["riskOther",/عامل\s*خطورة\s*آخر/]};const item=cb[key];if(!item)return false;const checked=!!p[item[0]];const bmi=Number(p.weight)>0&&Number(p.height)>0?Number(p.weight)/Math.pow(Number(p.height)/100,2):0;return checked||item[1].test(txt)||(key==="obesity"&&bmi>=30);}
function reportConditionLabels(p){const conditions=[["hypertension","ارتفاع ضغط الدم"],["diabetes","داء السكري"],["cardiovascular","القلب والأوعية"],["stroke","الجلطات / السكتات"],["kidney","أمراض الكلى"],["lipids","اضطرابات الدهون"],["obesity","زيادة الوزن / السمنة"],["other","عوامل خطورة أخرى"]];return conditions.filter(([k])=>reportHas(p,k)).map(([,label])=>label).join("، ")||"غير محدد";}
function getReportRecords(){const db=getDB(),disease=val("reportDiseaseFilter")||"all",q=val("reportSearch").trim().toLowerCase(),from=val("reportDateFrom"),to=val("reportDateTo");return db.filter(p=>{const conditions=reportConditionLabels(p);const none=conditions==="غير محدد";if(disease==="unclassified"&&!none)return false;if(disease!=="all"&&disease!=="unclassified"&&!reportHas(p,disease))return false;if(q&&!`${p.patientName||""} ${p.fileNo||""} ${reportDiagnosisText(p)} ${conditions}`.toLowerCase().includes(q))return false;const date=p.visitDate||"";if(from&&(!date||date<from))return false;if(to&&(!date||date>to))return false;return true;}).sort((a,b)=>String(a.visitDate||"").localeCompare(String(b.visitDate||""))||String(a.patientName||"").localeCompare(String(b.patientName||""),"ar"));}
function updateReports(){const db=getDB(),records=getReportRecords(),body=document.getElementById("patientReportBody");if(!body)return;const disease=val("reportDiseaseFilter")||"all",labels={all:"جميع المرضى المسجلين",hypertension:"مرضى ارتفاع ضغط الدم",diabetes:"مرضى السكري",cardiovascular:"مرضى القلب والأوعية",stroke:"مرضى الجلطات والسكتات الدماغية",kidney:"مرضى الكلى",lipids:"مرضى اضطرابات الدهون والكوليسترول",obesity:"تقارير زيادة الوزن والسمنة",other:"تقارير عوامل الخطورة الأخرى",unclassified:"السجلات غير المصنفة"};const title=labels[disease]||labels.all;setText("reportHeading",title);setText("reportPrintTitle",title);setText("reportTotalCount",String(db.length));setText("reportFilteredCount",String(records.length));setText("reportGeneratedDate",todayISO());setText("reportPrintMeta",`السجلات المحفوظة محليًا: ${db.length} — السجلات المطابقة: ${records.length} — تاريخ التقرير: ${todayISO()}`);body.innerHTML="";if(!records.length){const tr=document.createElement("tr"),td=document.createElement("td");td.colSpan=8;td.className="report-empty";td.textContent="لا توجد سجلات تطابق معايير التقرير الحالية.";tr.appendChild(td);body.appendChild(tr);return records;}records.forEach((p,i)=>{const tr=document.createElement("tr"),vals=[String(i+1),p.patientName||"—",p.fileNo||"—",`${p.age||"—"} / ${p.gender||"—"}`,p.visitDate||"—",p.clinic||"—",p.diagnosis||otherDiseasesTextFromRecord(p)||"—",reportConditionLabels(p)];vals.forEach(v=>{const td=document.createElement("td");td.textContent=v;tr.appendChild(td)});body.appendChild(tr);});return records;}
function setText(id,text){const el=document.getElementById(id);if(el)el.textContent=text;}
function resetReportFilters(){if(!confirm("تأكيد إلغاء التصفية\nسيتم عرض جميع السجلات بدلًا من نتائج التصفية الحالية، ولن تُحذف أي بيانات. هل تريد المتابعة؟"))return;setVal("reportDiseaseFilter","all");setVal("reportSearch","");setVal("reportDateFrom","");setVal("reportDateTo","");updateReports();}
function printPatientReport(){updateReports();printSection("reports");}
async function exportPatientReportCSV(){const records=getReportRecords();const headers=["م","اسم المريض","رقم الملف","العمر","الجنس","تاريخ الزيارة","العيادة / القسم","التشخيص","الأمراض / الحالات المحددة","ضغط الدم","الوزن","الطول"];const rows=records.map((p,i)=>[i+1,p.patientName,p.fileNo,p.age,p.gender,p.visitDate,p.clinic,p.diagnosis||otherDiseasesTextFromRecord(p),reportConditionLabels(p),p.bpScreen,p.weight,p.height]);const csv="\uFEFF"+[headers,...rows].map(row=>row.map(v=>'"'+String(v??"").replace(/"/g,'""')+'"').join(",")).join("\r\n");await downloadBlob(csv,`تقرير_مرضى_${val("reportDiseaseFilter")||"all"}_${todayISO()}.csv`,"text/csv;charset=utf-8");}
async function downloadBlob(content,name,type){
  const blob=content instanceof Blob?content:new Blob([content],{type});
  const url=URL.createObjectURL(blob),a=document.createElement("a");a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);return "browser-download";
}
