// WISAL – app logic: auth, direct chats, groups, channels, media, settings
import {
  isConfigured, auth, db, storage,
  onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, deleteUser,
  doc, getDoc, setDoc, updateDoc, addDoc, collection, query, where, orderBy, limit,
  onSnapshot, writeBatch, serverTimestamp, getDocs, arrayUnion, arrayRemove
} from "./firebase.js";
import { ref as sRef, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

/* ---------- i18n ---------- */
const I18N = {
  ar: {
    tagline: "تواصل أقرب، رسائل أسرع", login: "تسجيل الدخول", register: "إنشاء حساب جديد",
    fullName: "الاسم الكامل", username: "اسم المستخدم", email: "البريد الإلكتروني", password: "كلمة المرور",
    photoOpt: "صورة شخصية (اختياري)", changePhoto: "تغيير الصورة",
    chats: "المحادثات", contacts: "جهات الاتصال", groups: "المجموعات", channels: "القنوات", settings: "الإعدادات",
    search: "بحث", searchChannels: "ابحث عن قناة", findUser: "ابحث باسم المستخدم",
    typeMsg: "اكتب رسالة",
    noChats: "لا توجد محادثات بعد. افتح «جهات الاتصال» وابحث عن اسم مستخدم لتبدأ.",
    noGroups: "لا توجد مجموعات. اضغط ＋ لإنشاء مجموعة.", noChannels: "لا توجد قنوات بعد. اضغط ＋ لإنشاء قناة.",
    findHint: "اكتب اسم المستخدم لتجد الأشخاص وتبدأ محادثة.", noResults: "لا يوجد مستخدم بهذا الاسم.",
    language: "اللغة", dark: "الوضع الليلي", hideStatus: "إخفاء حالة الاتصال", logout: "تسجيل الخروج",
    save: "حفظ", bio: "النبذة الشخصية", online: "متصل الآن", offline: "غير متصل",
    reply: "رد", del: "حذف الرسالة", cancel: "إلغاء", close: "إغلاق", share: "مشاركة", copied: "تم نسخ الرابط",
    haveAcc: "لديك حساب؟ سجّل الدخول", noAcc: "ليس لديك حساب؟ أنشئ حساباً", saved: "تم الحفظ",
    deleted: "تم حذف الرسالة", created: "تم الإنشاء",
    cfgHint: "ألصق إعدادات Firebase (firebaseConfig) هنا مرة واحدة:", cfgSave: "حفظ الإعدادات",
    eCfg: "لم أجد apiKey وprojectId وappId في النص. انسخ firebaseConfig كاملاً.",
    noCfg: "لم يتم إعداد Firebase بعد. الصق الإعدادات في المربع بالصفحة الأولى.",
    eName: "أدخل اسمك الكامل.", eUser: "اسم المستخدم: 3–20 حرفاً إنجليزياً صغيراً أو أرقاماً أو _ .",
    eUserTaken: "اسم المستخدم محجوز، اختر اسماً آخر.", eEmail: "البريد الإلكتروني غير صالح.",
    ePass: "كلمة المرور 6 أحرف على الأقل.", eFill: "أدخل البريد وكلمة المرور.",
    "auth/email-already-in-use": "هذا البريد مسجّل مسبقاً.", "auth/invalid-credential": "البريد أو كلمة المرور غير صحيحة.",
    "auth/wrong-password": "البريد أو كلمة المرور غير صحيحة.", "auth/user-not-found": "البريد أو كلمة المرور غير صحيحة.",
    "auth/network-request-failed": "تعذر الاتصال بالإنترنت. تحقق من الشبكة وأعد المحاولة.",
    "auth/too-many-requests": "محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة.", "auth/weak-password": "كلمة المرور ضعيفة.",
    "auth/operation-not-allowed": "فعّل Email/Password في Firebase Authentication.",
    "auth/invalid-api-key": "مفتاح Firebase غير صحيح.",
    "permission-denied": "لا تملك صلاحية لهذا الإجراء. تأكد من نشر قواعد الأمان.",
    eSend: "تعذر إرسال الرسالة. تحقق من الاتصال وأعد المحاولة.", eLoad: "تعذر تحميل البيانات. تحقق من الاتصال.",
    eGeneric: "حدث خطأ غير متوقع. أعد المحاولة.", you: "أنت", yesterday: "أمس",
    groupName: "اسم المجموعة", channelName: "اسم القناة", create: "إنشاء", eNameGrp: "أدخل اسماً من حرفين على الأقل.",
    members: "عضو", subscribers: "مشترك", admin: "مشرف", makeAdmin: "ترقية لمشرف", removeAdmin: "إزالة الإشراف",
    removeMember: "إزالة", addMember: "إضافة عضو", leave: "مغادرة المجموعة", subscribe: "اشتراك", unsubscribe: "إلغاء الاشتراك",
    subscribed: "مشترك", onlyAdmins: "المشرفون فقط يستطيعون النشر في هذه القناة",
    soleAdmin: "أنت المشرف الوحيد. رقِّ عضواً آخر قبل المغادرة.", gone: "لم تعد هذه المحادثة متاحة.",
    attach: "إرفاق", image: "صورة", file: "ملف", uploading: "جارٍ رفع الملف…",
    eBig: "الحد الأقصى للملف 20 ميغابايت.", eImg: "تعذر قراءة الصورة.", eImgBig: "الصورة كبيرة جداً.",
    eStorage: "تعذر رفع الملف. فعّل Firebase Storage وانشر storage.rules (قد يتطلب خطة Blaze)."
  },
  en: {
    tagline: "Closer conversations, faster messages", login: "Log in", register: "Create account",
    fullName: "Full name", username: "Username", email: "Email", password: "Password",
    photoOpt: "Profile photo (optional)", changePhoto: "Change photo",
    chats: "Chats", contacts: "Contacts", groups: "Groups", channels: "Channels", settings: "Settings",
    search: "Search", searchChannels: "Search channels", findUser: "Search by username",
    typeMsg: "Type a message",
    noChats: "No chats yet. Open Contacts and search a username to start.",
    noGroups: "No groups yet. Tap ＋ to create one.", noChannels: "No channels yet. Tap ＋ to create one.",
    findHint: "Type a username to find people and start a chat.", noResults: "No user with that username.",
    language: "Language", dark: "Dark mode", hideStatus: "Hide online status", logout: "Log out",
    save: "Save", bio: "Bio", online: "online", offline: "offline",
    reply: "Reply", del: "Delete message", cancel: "Cancel", close: "Close", share: "Share", copied: "Link copied",
    haveAcc: "Have an account? Log in", noAcc: "No account? Create one", saved: "Saved",
    deleted: "Message deleted", created: "Created",
    cfgHint: "Paste your Firebase config (firebaseConfig) here once:", cfgSave: "Save config",
    eCfg: "apiKey, projectId and appId not found. Copy the whole firebaseConfig.",
    noCfg: "Firebase is not set up yet. Paste the config in the box on the first page.",
    eName: "Enter your full name.", eUser: "Username: 3–20 lowercase letters, digits or _ .",
    eUserTaken: "That username is taken. Pick another.", eEmail: "Invalid email address.",
    ePass: "Password must be at least 6 characters.", eFill: "Enter your email and password.",
    "auth/email-already-in-use": "This email is already registered.", "auth/invalid-credential": "Wrong email or password.",
    "auth/wrong-password": "Wrong email or password.", "auth/user-not-found": "Wrong email or password.",
    "auth/network-request-failed": "Can't reach the network. Check your connection and retry.",
    "auth/too-many-requests": "Too many attempts. Wait a moment and retry.", "auth/weak-password": "Password is too weak.",
    "auth/operation-not-allowed": "Enable Email/Password in Firebase Authentication.",
    "auth/invalid-api-key": "Invalid Firebase API key.",
    "permission-denied": "Permission denied. Make sure the security rules are published.",
    eSend: "Message not sent. Check your connection and retry.", eLoad: "Couldn't load data. Check your connection.",
    eGeneric: "Something went wrong. Try again.", you: "You", yesterday: "Yesterday",
    groupName: "Group name", channelName: "Channel name", create: "Create", eNameGrp: "Enter a name (2+ characters).",
    members: "members", subscribers: "subscribers", admin: "Admin", makeAdmin: "Make admin", removeAdmin: "Remove admin",
    removeMember: "Remove", addMember: "Add member", leave: "Leave group", subscribe: "Subscribe", unsubscribe: "Unsubscribe",
    subscribed: "Subscribed", onlyAdmins: "Only admins can post in this channel",
    soleAdmin: "You're the only admin. Promote someone before leaving.", gone: "This conversation is no longer available.",
    attach: "Attach", image: "Photo", file: "File", uploading: "Uploading file…",
    eBig: "Max file size is 20 MB.", eImg: "Couldn't read the image.", eImgBig: "Image is too large.",
    eStorage: "Upload failed. Enable Firebase Storage and publish storage.rules (may require the Blaze plan)."
  }
};
let lang = localStorage.getItem("wisal_lang") || "ar";
const t = k => I18N[lang][k] || I18N.en[k] || k;
const errText = e => (e?.code && I18N[lang][e.code]) ? I18N[lang][e.code] : t("eGeneric");
const sendErr = e => e?.code === "permission-denied" ? t("permission-denied") : t("eSend");

/* ---------- helpers ---------- */
const $ = s => document.querySelector(s);
function h(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") e.className = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  for (const c of kids.flat(2)) if (c != null && c !== false) e.append(c);
  return e;
}
let toastTimer;
function toast(msg) {
  const el = $("#toast"); el.textContent = msg; el.classList.remove("hidden");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.add("hidden"), 3500);
}
const show = id => document.querySelectorAll(".screen").forEach(s => s.classList.toggle("hidden", s.id !== id));
const initial = n => (n || "?").trim().charAt(0).toUpperCase();
const chatIdOf = (a, b) => [a, b].sort().join("_");
const typeOf = c => (c && c.type) || "direct";
const fmtTime = d => d.toLocaleTimeString(lang, { hour: "2-digit", minute: "2-digit" });
function fmtListTime(d) {
  const now = new Date(), y = new Date(now - 864e5);
  if (d.toDateString() === now.toDateString()) return fmtTime(d);
  if (d.toDateString() === y.toDateString()) return t("yesterday");
  return d.toLocaleDateString(lang, { day: "numeric", month: "short" });
}
function setAvatar(el, name, photo) {
  el.replaceChildren(photo ? h("img", { src: photo, alt: "" }) : document.createTextNode(initial(name)));
}
function avatarEl(name, photo, cls = "") { const e = h("div", { class: "avatar " + cls }); setAvatar(e, name, photo); return e; }
const sizeStr = n => n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";

function pickFile(accept) {
  return new Promise(res => {
    const i = h("input", { type: "file", accept }); i.onchange = () => res(i.files[0] || null); i.click();
  });
}
async function toDataUrl(file, maxPx, q, square = false) {
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise((ok, no) => { const im = new Image(); im.onload = () => ok(im); im.onerror = no; im.src = url; });
    const c = document.createElement("canvas"), ctx = c.getContext("2d");
    if (square) {
      const s = Math.min(img.width, img.height); c.width = c.height = maxPx;
      ctx.drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, maxPx, maxPx);
    } else {
      const k = Math.min(1, maxPx / Math.max(img.width, img.height));
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      ctx.drawImage(img, 0, 0, c.width, c.height);
    }
    return c.toDataURL("image/jpeg", q);
  } finally { URL.revokeObjectURL(url); }
}

function applyLang() {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach(el => el.textContent = t(el.dataset.i18n));
  document.querySelectorAll("[data-i18n-ph]").forEach(el => el.placeholder = t(el.dataset.i18nPh));
  document.querySelectorAll(".langs button").forEach(b => b.classList.toggle("on", b.dataset.lang === lang));
  $("#langSel").value = lang;
  setAuthMode(authMode); setTab(curTab);
  if (me) { renderAll(); if (curChat) { paintHeader(); renderMessages(); } }
}
function setLang(l) { lang = l; localStorage.setItem("wisal_lang", l); applyLang(); }

/* ---------- state ---------- */
let me = null, profile = null, registering = false;
let authMode = "login", curTab = "chats";
let chats = [], channels = [], unsubChats = null, unsubChan = null, heartbeat = null;
const userCache = new Map();
let curChat = null, peer = null, unsubMsgs = null, unsubPeer = null, unsubChat = null, curMsgs = [], replyTo = null;
const marking = new Set();

function applyTheme() {
  const dark = localStorage.getItem("wisal_dark") === "1";
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  $("#darkSw").checked = dark;
}

/* ---------- welcome / auth ---------- */
function setAuthMode(m) {
  authMode = m; const reg = m === "register";
  document.querySelectorAll(".reg-only").forEach(el => el.classList.toggle("hidden", !reg));
  $("#authTitle").textContent = t(reg ? "register" : "login");
  $("#authSubmit").textContent = t(reg ? "register" : "login");
  $("#authSwitch").textContent = t(reg ? "haveAcc" : "noAcc");
  $("#fPass").autocomplete = reg ? "new-password" : "current-password";
  $("#authErr").textContent = "";
}
$("#goLogin").onclick = () => { setAuthMode("login"); show("auth"); };
$("#goRegister").onclick = () => { setAuthMode("register"); show("auth"); };
$("#authBack").onclick = () => show("welcome");
$("#authSwitch").onclick = () => setAuthMode(authMode === "login" ? "register" : "login");
document.querySelectorAll(".langs button").forEach(b => b.onclick = () => setLang(b.dataset.lang));

$("#cfgSave").onclick = () => {
  const txt = $("#cfgText").value, cfg = {};
  for (const k of ["apiKey", "authDomain", "projectId", "storageBucket", "messagingSenderId", "appId"]) {
    const m = txt.match(new RegExp(k + "[\"']?\\s*[:=]\\s*[\"']([^\"']+)[\"']"));
    if (m) cfg[k] = m[1];
  }
  if (!cfg.apiKey || !cfg.projectId || !cfg.appId) return toast(t("eCfg"));
  localStorage.setItem("wisal_fbcfg", JSON.stringify(cfg)); location.reload();
};

$("#authForm").addEventListener("submit", async e => {
  e.preventDefault();
  const err = m => { $("#authErr").textContent = m; };
  if (!isConfigured) return err(t("noCfg"));
  err("");
  const email = $("#fEmail").value.trim(), pass = $("#fPass").value;
  const btn = $("#authSubmit"); btn.disabled = true;
  try {
    if (authMode === "login") {
      if (!email || !pass) return err(t("eFill"));
      await signInWithEmailAndPassword(auth, email, pass);
    } else {
      const name = $("#fName").value.trim(), username = $("#fUser").value.trim().toLowerCase();
      if (name.length < 2) return err(t("eName"));
      if (!/^[a-z0-9_]{3,20}$/.test(username)) return err(t("eUser"));
      if (!/^\S+@\S+\.\S+$/.test(email)) return err(t("eEmail"));
      if (pass.length < 6) return err(t("ePass"));
      let photo = null; const pf = $("#fPhoto").files[0];
      if (pf) { try { photo = await toDataUrl(pf, 128, .7, true); } catch (_) { return err(t("eImg")); } }
      if ((await getDoc(doc(db, "usernames", username))).exists()) return err(t("eUserTaken"));
      registering = true; let cred = null;
      try {
        cred = await createUserWithEmailAndPassword(auth, email, pass);
        const b = writeBatch(db);
        b.set(doc(db, "usernames", username), { uid: cred.user.uid });
        b.set(doc(db, "users", cred.user.uid), {
          uid: cred.user.uid, name, username, bio: "", photo, hideStatus: false, online: true,
          lastSeen: serverTimestamp(), createdAt: serverTimestamp()
        });
        await b.commit();
      } catch (ex) {
        if (cred) { try { await deleteUser(cred.user); } catch (_) {} }
        registering = false;
        return err(ex.code === "permission-denied" ? t("eUserTaken") : errText(ex));
      }
      registering = false;
      await startApp(cred.user);
    }
  } catch (ex) { err(errText(ex)); }
  finally { btn.disabled = false; }
});

/* ---------- session ---------- */
function paintMe() {
  $("#myName").textContent = profile.name; $("#myUser").textContent = "@" + profile.username;
  setAvatar($("#myAvatar"), profile.name, profile.photo);
  $("#pName").value = profile.name; $("#pBio").value = profile.bio || ""; $("#hideSw").checked = !!profile.hideStatus;
}
async function startApp(user) {
  me = user;
  try {
    const snap = await getDoc(doc(db, "users", user.uid));
    if (!snap.exists()) throw new Error("no profile");
    profile = snap.data(); userCache.set(user.uid, profile);
  } catch (ex) { toast(t("eLoad")); await signOut(auth); return; }
  paintMe(); show("app"); setTab("chats");
  subscribeChats(); subscribeChannels(); startPresence();
}
function stopApp() {
  unsubChats?.(); unsubChan?.(); unsubChats = unsubChan = null; leaveView();
  clearInterval(heartbeat); heartbeat = null;
  chats = []; channels = []; userCache.clear(); me = null; profile = null;
  ["#chatList", "#userList", "#groupList", "#chanList"].forEach(s => $(s).replaceChildren());
}
if (isConfigured) {
  onAuthStateChanged(auth, user => {
    if (registering) return;
    if (user) startApp(user); else { if (me) stopApp(); show("welcome"); }
  });
} else $("#cfgBox").classList.remove("hidden");

$("#logoutBtn").onclick = async () => {
  try { await setPresence(false); await signOut(auth); } catch (ex) { toast(errText(ex)); }
};

/* ---------- presence ---------- */
async function setPresence(online) {
  if (!me || !profile) return;
  try { await updateDoc(doc(db, "users", me.uid), { online: profile.hideStatus ? false : online, lastSeen: serverTimestamp() }); } catch (_) {}
}
function startPresence() {
  setPresence(true); clearInterval(heartbeat);
  heartbeat = setInterval(() => document.visibilityState === "visible" && setPresence(true), 60000);
}
document.addEventListener("visibilitychange", () => me && setPresence(document.visibilityState === "visible"));

/* ---------- tabs ---------- */
function setTab(name) {
  curTab = name;
  document.querySelectorAll(".tab").forEach(el => el.classList.toggle("hidden", el.id !== "tab-" + name));
  document.querySelectorAll(".tabs button").forEach(b => b.classList.toggle("on", b.dataset.tab === name));
  $("#appTitle").textContent = t(name);
  $("#addBtn").classList.toggle("hidden", name !== "groups" && name !== "channels");
}
document.querySelectorAll(".tabs button").forEach(b => b.onclick = () => setTab(b.dataset.tab));
$("#addBtn").onclick = () => openCreate(curTab === "groups" ? "group" : "channel");

/* ---------- users ---------- */
async function getUser(uid) {
  if (userCache.has(uid)) return userCache.get(uid);
  try {
    const s = await getDoc(doc(db, "users", uid));
    const u = s.exists() ? s.data() : { uid, name: "?", username: "" };
    userCache.set(uid, u); return u;
  } catch (_) { return { uid, name: "?", username: "" }; }
}
async function searchUsers(q) {
  const snap = await getDocs(query(collection(db, "users"),
    where("username", ">=", q), where("username", "<=", q + "\uf8ff"), limit(20)));
  const users = snap.docs.map(d => d.data()).filter(u => u.uid !== me.uid);
  users.forEach(u => userCache.set(u.uid, u)); return users;
}
const userRow = (u, onclick) => h("li", { class: "item", onclick },
  avatarEl(u.name, u.photo), h("div", { class: "main" }, h("strong", {}, u.name), h("span", { class: "sub", dir: "ltr" }, "@" + u.username)));

let searchTimer;
$("#userSearch").oninput = e => {
  clearTimeout(searchTimer);
  const q = e.target.value.trim().toLowerCase().replace(/^@/, "");
  searchTimer = setTimeout(async () => {
    const list = $("#userList"), empty = $("#userEmpty");
    if (!q) { list.replaceChildren(); empty.textContent = t("findHint"); empty.classList.remove("hidden"); return; }
    try {
      const users = await searchUsers(q);
      list.replaceChildren(...users.map(u => userRow(u, () => openDirect(u))));
      empty.textContent = t("noResults"); empty.classList.toggle("hidden", users.length > 0);
    } catch (ex) { toast(errText(ex)); }
  }, 300);
};
function userSearchBox(onPick) {
  const ul = h("ul", { class: "list" }); let tm;
  const inp = h("input", { type: "search", placeholder: t("findUser"), dir: "auto", autocapitalize: "none",
    oninput: () => {
      clearTimeout(tm);
      tm = setTimeout(async () => {
        const q = inp.value.trim().toLowerCase().replace(/^@/, "");
        if (!q) return ul.replaceChildren();
        try {
          const us = await searchUsers(q);
          ul.replaceChildren(...us.map(u => userRow(u, () => { onPick(u); inp.value = ""; ul.replaceChildren(); })));
        } catch (ex) { toast(errText(ex)); }
      }, 300);
    } });
  return h("div", {}, inp, ul);
}

/* ---------- lists ---------- */
function subscribeChats() {
  unsubChats?.();
  unsubChats = onSnapshot(query(collection(db, "chats"), where("members", "array-contains", me.uid)),
    async snap => {
      chats = snap.docs.map(d => ({ id: d.id, ...d.data({ serverTimestamps: "estimate" }) }));
      await Promise.all(chats.filter(c => typeOf(c) === "direct").map(c => getUser(c.members.find(m => m !== me.uid))));
      renderAll();
    }, () => toast(t("eLoad")));
}
function subscribeChannels() {
  unsubChan?.();
  unsubChan = onSnapshot(query(collection(db, "chats"), where("type", "==", "channel"), limit(100)),
    snap => { channels = snap.docs.map(d => ({ id: d.id, ...d.data({ serverTimestamps: "estimate" }) })); renderChannels(); },
    () => toast(t("eLoad")));
}
const viewOf = c => {
  if (typeOf(c) === "direct") {
    const u = userCache.get(c.members.find(m => m !== me.uid));
    return u && { name: u.name, photo: u.photo, user: u.username, open: () => openDirect(u) };
  }
  return { name: c.name, photo: c.photo, open: () => openConv(c) };
};
function renderList(type, ul, empty, searchEl) {
  const q = searchEl.value.trim().toLowerCase();
  const all = chats.filter(c => typeOf(c) === type);
  const rows = all.map(c => ({ c, v: viewOf(c) }))
    .filter(({ c, v }) => v && (!q || (v.name + " " + (v.user || "") + " " + (c.lastText || "")).toLowerCase().includes(q)))
    .sort((a, b) => (b.c.lastAt?.toMillis?.() || 0) - (a.c.lastAt?.toMillis?.() || 0));
  ul.replaceChildren(...rows.map(({ c, v }) => h("li", { class: "item", onclick: v.open },
    avatarEl(v.name, v.photo),
    h("div", { class: "main" },
      h("div", { class: "top" }, h("strong", {}, v.name), c.lastAt ? h("time", {}, fmtListTime(c.lastAt.toDate())) : null),
      h("span", { class: "sub" }, (c.lastText && c.lastSender === me.uid ? t("you") + ": " : "") + (c.lastText || ""))))));
  empty.classList.toggle("hidden", all.length > 0);
}
function renderChannels() {
  const q = $("#chanSearch").value.trim().toLowerCase();
  const rows = channels.filter(c => !q || c.name.toLowerCase().includes(q))
    .sort((a, b) => (b.members.includes(me.uid) - a.members.includes(me.uid)) || a.name.localeCompare(b.name));
  $("#chanList").replaceChildren(...rows.map(c => h("li", { class: "item", onclick: () => openConv(c) },
    avatarEl(c.name, c.photo),
    h("div", { class: "main" },
      h("div", { class: "top" }, h("strong", {}, c.name), c.members.includes(me.uid) ? h("span", { class: "badge" }, t("subscribed")) : null),
      h("span", { class: "sub" }, c.lastText || c.members.length + " " + t("subscribers"))))));
  $("#chanEmpty").classList.toggle("hidden", channels.length > 0);
}
function renderAll() {
  renderList("direct", $("#chatList"), $("#chatEmpty"), $("#chatSearch"));
  renderList("group", $("#groupList"), $("#groupEmpty"), $("#groupSearch"));
  renderChannels();
}
["#chatSearch", "#groupSearch"].forEach(s => $(s).oninput = renderAll);
$("#chanSearch").oninput = renderChannels;

/* ---------- opening conversations ---------- */
function resetChatUI() { $("#msgs").replaceChildren(); $("#msgInput").value = ""; setReply(null); curMsgs = []; marking.clear(); }
function leaveView() {
  unsubMsgs?.(); unsubPeer?.(); unsubChat?.(); unsubMsgs = unsubPeer = unsubChat = null; peer = null; curChat = null;
}
function backToApp() { leaveView(); show("app"); }
$("#chatBack").onclick = backToApp;

function openDirect(u) {
  leaveView(); resetChatUI();
  peer = u; curChat = { id: chatIdOf(me.uid, u.uid), type: "direct", members: [me.uid, u.uid] };
  paintHeader(); show("chat");
  unsubPeer = onSnapshot(doc(db, "users", u.uid), s => {
    if (s.exists() && peer) { peer = s.data(); userCache.set(peer.uid, peer); paintHeader(); }
  });
  subscribeMsgs();
}
function openConv(c) {
  leaveView(); resetChatUI();
  curChat = { ...c }; paintHeader(); show("chat");
  const id = c.id;
  unsubChat = onSnapshot(doc(db, "chats", id), s => {
    if (!s.exists()) { toast(t("gone")); return backToApp(); }
    curChat = { id: s.id, ...s.data() };
    if (typeOf(curChat) === "group" && !curChat.members.includes(me.uid)) return backToApp();
    paintHeader();
  }, () => { toast(t("gone")); backToApp(); });
  subscribeMsgs();
}
function isOnline(u) { const ms = u?.lastSeen?.toMillis?.(); return !!u?.online && ms && Date.now() - ms < 150000; }
function paintHeader() {
  const c = curChat; if (!c) return;
  const ty = typeOf(c);
  if (ty === "direct") {
    setAvatar($("#peerAvatar"), peer.name, peer.photo); $("#peerName").textContent = peer.name;
    $("#peerStatus").textContent = peer.hideStatus ? "" : t(isOnline(peer) ? "online" : "offline");
  } else {
    setAvatar($("#peerAvatar"), c.name, c.photo); $("#peerName").textContent = c.name;
    $("#peerStatus").textContent = c.members.length + " " + t(ty === "group" ? "members" : "subscribers");
  }
  const canPost = ty !== "channel" || (c.admins || []).includes(me.uid);
  $("#composer").classList.toggle("hidden", !canPost);
  const ro = $("#roBar"); ro.classList.toggle("hidden", canPost);
  if (!canPost) ro.replaceChildren(c.members.includes(me.uid)
    ? h("span", {}, t("onlyAdmins")) : h("button", { class: "btn primary", onclick: toggleSub }, t("subscribe")));
}
async function toggleSub() {
  const c = curChat, mem = c.members.includes(me.uid);
  try { await updateDoc(doc(db, "chats", c.id), { members: mem ? arrayRemove(me.uid) : arrayUnion(me.uid) }); }
  catch (ex) { toast(errText(ex)); }
}

/* ---------- messages ---------- */
function subscribeMsgs() {
  const id = curChat.id;
  unsubMsgs = onSnapshot(query(collection(db, "chats", id, "messages"), orderBy("createdAt"), limit(300)),
    async snap => {
      const msgs = snap.docs.map(d => ({ id: d.id, ...d.data({ serverTimestamps: "estimate" }), _pending: d.metadata.hasPendingWrites }));
      await Promise.all([...new Set(msgs.map(m => m.senderId))].map(getUser));
      if (!curChat || curChat.id !== id) return;
      curMsgs = msgs; renderMessages(); markRead();
    }, () => toast(t("eLoad")));
}
function renderMessages() {
  const box = $("#msgs"), ty = typeOf(curChat);
  const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 140;
  const last = curMsgs[curMsgs.length - 1];
  const nodes = []; let lastDay = "";
  for (const m of curMsgs) {
    const d = m.createdAt?.toDate?.() || new Date();
    if (d.toDateString() !== lastDay) {
      lastDay = d.toDateString();
      nodes.push(h("div", { class: "day" }, d.toLocaleDateString(lang, { day: "numeric", month: "long" })));
    }
    const mine = m.senderId === me.uid;
    nodes.push(h("div", { class: "msg " + (mine ? "mine" : "theirs"), onclick: () => openActions(m) },
      ty !== "direct" && !mine ? h("div", { class: "sender" }, userCache.get(m.senderId)?.name || "") : null,
      m.replyTo ? h("div", { class: "quote" }, m.replyTo.text) : null,
      m.image ? h("img", { class: "pic", src: m.image, alt: "", onclick: ev => { ev.stopPropagation(); showPreview(m.image); } }) : null,
      m.file ? h("a", { class: "file", href: m.file.url, target: "_blank", rel: "noopener", onclick: ev => ev.stopPropagation() },
        "📎 ", h("span", {}, m.file.name + " · " + sizeStr(m.file.size))) : null,
      m.text ? h("div", { class: "txt" }, m.text) : null,
      h("div", { class: "meta" }, fmtTime(d),
        mine && ty === "direct" ? h("span", { class: "tick" + (m.readAt ? " read" : "") }, m._pending ? "…" : m.readAt ? "✓✓" : "✓") : null)));
  }
  box.replaceChildren(...nodes);
  if (nearBottom || last?.senderId === me.uid) box.scrollTop = box.scrollHeight;
}
async function markRead() {
  if (!curChat || typeOf(curChat) !== "direct" || document.visibilityState !== "visible") return;
  const id = curChat.id;
  const todo = curMsgs.filter(m => m.senderId !== me.uid && !m.readAt && !m._pending && !marking.has(m.id));
  if (!todo.length) return;
  todo.forEach(m => marking.add(m.id));
  try {
    const b = writeBatch(db);
    todo.forEach(m => b.update(doc(db, "chats", id, "messages", m.id), { readAt: serverTimestamp() }));
    await b.commit();
  } catch (_) { todo.forEach(m => marking.delete(m.id)); }
}
document.addEventListener("visibilitychange", markRead);

async function post(extra, preview) {
  const c = curChat, now = serverTimestamp();
  const b = writeBatch(db);
  if (typeOf(c) === "direct") {
    b.set(doc(db, "chats", c.id), { type: "direct", members: [me.uid, peer.uid], lastText: preview, lastSender: me.uid, lastAt: now }, { merge: true });
  } else {
    b.update(doc(db, "chats", c.id), { lastText: preview, lastSender: me.uid, lastAt: now });
  }
  b.set(doc(collection(db, "chats", c.id, "messages")), { senderId: me.uid, text: "", createdAt: now, readAt: null, ...extra });
  await b.commit();
}
const input = $("#msgInput");
input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 120) + "px"; });
input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 700) { e.preventDefault(); $("#composer").requestSubmit(); } });

$("#composer").addEventListener("submit", async e => {
  e.preventDefault();
  const text = input.value.trim(); if (!text || !curChat) return;
  const rep = replyTo;
  input.value = ""; input.style.height = "auto"; setReply(null);
  const extra = { text };
  if (rep) extra.replyTo = { id: rep.id, text: (rep.text || (rep.image ? "📷" : rep.file ? "📎 " + rep.file.name : "")).slice(0, 120) };
  try { await post(extra, text.slice(0, 120)); }
  catch (ex) { input.value = text; toast(sendErr(ex)); }
});

/* attachments */
$("#attachBtn").onclick = () => {
  const dlg = $("#sheet");
  $("#sheetBody").replaceChildren(
    h("button", { onclick: () => { dlg.close(); sendImage(); } }, "🖼  " + t("image")),
    h("button", { onclick: () => { dlg.close(); sendFile(); } }, "📎  " + t("file")),
    h("button", { onclick: () => dlg.close() }, t("cancel")));
  dlg.showModal();
};
async function sendImage() {
  const f = await pickFile("image/*"); if (!f || !curChat) return;
  try {
    let d = await toDataUrl(f, 1280, .7);
    if (d.length > 750000) d = await toDataUrl(f, 900, .5);
    if (d.length > 750000) return toast(t("eImgBig"));
    await post({ image: d }, "📷 " + t("image"));
  } catch (ex) { toast(ex.code ? sendErr(ex) : t("eImg")); }
}
async function sendFile() {
  const f = await pickFile("*/*"); if (!f || !curChat) return;
  if (f.size > 20 * 1024 * 1024) return toast(t("eBig"));
  toast(t("uploading"));
  try {
    const r = sRef(storage, `chats/${curChat.id}/${Date.now()}_${f.name.replace(/[^\w.\-]/g, "_")}`);
    await uploadBytes(r, f);
    const url = await getDownloadURL(r);
    await post({ file: { name: f.name, size: f.size, url, type: f.type || "" } }, "📎 " + f.name);
  } catch (ex) { toast(String(ex.code || "").startsWith("storage/") ? t("eStorage") : sendErr(ex)); }
}

/* preview + share */
let pvSrc = null;
function showPreview(src) { pvSrc = src; $("#pvImg").src = src; $("#preview").classList.remove("hidden"); }
$("#pvClose").onclick = () => $("#preview").classList.add("hidden");
$("#pvShare").onclick = () => shareMsg({ image: pvSrc });
async function shareMsg(m) {
  try {
    if (m.image) {
      const blob = await (await fetch(m.image)).blob();
      const f = new File([blob], "wisal.jpg", { type: "image/jpeg" });
      if (navigator.canShare?.({ files: [f] })) return await navigator.share({ files: [f] });
      return h("a", { href: m.image, download: "wisal.jpg" }).click();
    }
    const payload = m.file ? { title: m.file.name, url: m.file.url } : { text: m.text };
    if (navigator.share) return await navigator.share(payload);
    await navigator.clipboard.writeText(m.file ? m.file.url : m.text); toast(t("copied"));
  } catch (ex) { if (ex.name !== "AbortError") toast(t("eGeneric")); }
}

/* reply / delete */
function setReply(m) {
  replyTo = m; $("#replyBar").classList.toggle("hidden", !m);
  $("#replyText").textContent = m ? (m.text || (m.image ? "📷 " + t("image") : m.file ? "📎 " + m.file.name : "")) : "";
  if (m) input.focus();
}
$("#replyX").onclick = () => setReply(null);

function openActions(m) {
  const dlg = $("#sheet"), close = () => dlg.close();
  const canDel = m.senderId === me.uid || (typeOf(curChat) !== "direct" && (curChat.admins || []).includes(me.uid));
  const canReply = !$("#composer").classList.contains("hidden");
  $("#sheetBody").replaceChildren(
    canReply ? h("button", { onclick: () => { close(); setReply(m); } }, t("reply")) : null,
    h("button", { onclick: () => { close(); shareMsg(m); } }, t("share")),
    canDel ? h("button", { class: "del", onclick: () => { close(); deleteMessage(m); } }, t("del")) : null,
    h("button", { onclick: close }, t("cancel")));
  dlg.showModal();
}
$("#sheet").addEventListener("click", e => { if (e.target.id === "sheet") e.target.close(); });

async function deleteMessage(m) {
  try {
    const b = writeBatch(db);
    b.delete(doc(db, "chats", curChat.id, "messages", m.id));
    const idx = curMsgs.findIndex(x => x.id === m.id);
    if (idx === curMsgs.length - 1) {
      const prev = curMsgs[idx - 1];
      b.update(doc(db, "chats", curChat.id), {
        lastText: prev ? (prev.text || (prev.image ? "📷" : "📎")).slice(0, 120) : "", lastSender: prev ? prev.senderId : me.uid });
    }
    await b.commit(); toast(t("deleted"));
  } catch (ex) { toast(errText(ex)); }
}

/* ---------- create group / channel ---------- */
function openCreate(type) {
  const dlg = $("#sheet"); let photo = null; const picked = [];
  const prev = avatarEl("+", null, "big");
  const nameIn = h("input", { maxlength: "50", placeholder: t(type === "group" ? "groupName" : "channelName") });
  const chips = h("div", { class: "chips" });
  const draw = () => chips.replaceChildren(...picked.map(u => h("span", { class: "chip", onclick: () => { picked.splice(picked.indexOf(u), 1); draw(); } }, u.name + " ×")));
  const photoBtn = h("button", { class: "link", onclick: async () => {
    const f = await pickFile("image/*"); if (!f) return;
    try { photo = await toDataUrl(f, 128, .7, true); setAvatar(prev, "", photo); } catch (_) { toast(t("eImg")); }
  } }, t("changePhoto"));
  const go = h("button", { class: "btn primary", onclick: async () => {
    const name = nameIn.value.trim(); if (name.length < 2) return toast(t("eNameGrp"));
    go.disabled = true;
    const data = { type, name, nameLower: name.toLowerCase(), photo, members: [me.uid, ...picked.map(u => u.uid)],
      admins: [me.uid], ownerId: me.uid, lastText: "", lastSender: me.uid };
    try {
      const r = await addDoc(collection(db, "chats"), { ...data, lastAt: serverTimestamp(), createdAt: serverTimestamp() });
      dlg.close(); toast(t("created")); openConv({ id: r.id, ...data });
    } catch (ex) { toast(errText(ex)); go.disabled = false; }
  } }, t("create"));
  $("#sheetBody").replaceChildren(h("div", { class: "sheet-pad" },
    h("div", { class: "infohead" }, prev, photoBtn), nameIn,
    type === "group" ? [h("strong", {}, t("addMember")), chips, userSearchBox(u => { if (!picked.some(p => p.uid === u.uid)) { picked.push(u); draw(); } })] : null,
    go, h("button", { onclick: () => dlg.close() }, t("cancel"))));
  dlg.showModal();
}

/* ---------- info / admin tools ---------- */
$("#chatHead").onclick = () => curChat && openInfo();
async function patchChat(updates, local) {
  try { await updateDoc(doc(db, "chats", curChat.id), updates); Object.assign(curChat, local || updates); paintHeader(); renderInfo(); }
  catch (ex) { toast(errText(ex)); }
}
async function openInfo() {
  const dlg = $("#sheet");
  await renderInfo(); if (!dlg.open) dlg.showModal();
}
async function renderInfo() {
  const c = curChat, dlg = $("#sheet"), body = $("#sheetBody");
  if (!c || (!dlg.open && !c)) return;
  const ty = typeOf(c);
  if (ty === "direct") {
    return body.replaceChildren(h("div", { class: "infohead" }, avatarEl(peer.name, peer.photo, "big"), h("strong", {}, peer.name),
      h("span", { class: "muted", dir: "ltr" }, "@" + peer.username), h("p", {}, peer.bio || "")),
      h("button", { onclick: () => dlg.close() }, t("close")));
  }
  const admin = (c.admins || []).includes(me.uid), owner = c.ownerId === me.uid;
  const nameIn = h("input", { value: c.name, maxlength: "50" });
  const head = h("div", { class: "infohead" }, avatarEl(c.name, c.photo, "big"),
    admin ? h("button", { class: "link", onclick: async () => {
      const f = await pickFile("image/*"); if (!f) return;
      try { await patchChat({ photo: await toDataUrl(f, 128, .7, true) }); } catch (_) { toast(t("eImg")); }
    } }, t("changePhoto")) : null,
    admin ? [nameIn, h("button", { class: "link", onclick: () => { const n = nameIn.value.trim(); if (n.length >= 2) patchChat({ name: n, nameLower: n.toLowerCase() }); } }, t("save"))] : h("strong", {}, c.name),
    h("span", { class: "muted" }, c.members.length + " " + t(ty === "group" ? "members" : "subscribers")));
  const parts = [head];
  if (ty === "group") {
    const us = await Promise.all(c.members.map(getUser));
    parts.push(h("ul", { class: "list" }, us.map(u => {
      const isA = c.admins.includes(u.uid), locked = u.uid === me.uid || u.uid === c.ownerId;
      return h("li", { class: "item" }, avatarEl(u.name, u.photo),
        h("div", { class: "main" }, h("strong", {}, u.name + (u.uid === me.uid ? " (" + t("you") + ")" : "")), h("span", { class: "sub" }, isA ? t("admin") : "")),
        admin && !locked ? [
          h("button", { class: "link", onclick: () => isA
            ? patchChat({ admins: arrayRemove(u.uid) }, { admins: c.admins.filter(x => x !== u.uid) })
            : patchChat({ admins: arrayUnion(u.uid) }, { admins: [...c.admins, u.uid] }) }, t(isA ? "removeAdmin" : "makeAdmin")),
          h("button", { class: "link", onclick: () => patchChat({ members: arrayRemove(u.uid), admins: arrayRemove(u.uid) },
            { members: c.members.filter(x => x !== u.uid), admins: c.admins.filter(x => x !== u.uid) }) }, t("removeMember"))] : null);
    })));
    if (admin) parts.push(h("strong", {}, t("addMember")), userSearchBox(u => {
      if (!c.members.includes(u.uid)) patchChat({ members: arrayUnion(u.uid) }, { members: [...c.members, u.uid] });
    }));
    parts.push(h("button", { class: "del", onclick: async () => {
      if (admin && c.admins.length === 1 && c.members.length > 1) return toast(t("soleAdmin"));
      try {
        await updateDoc(doc(db, "chats", c.id), admin ? { members: arrayRemove(me.uid), admins: arrayRemove(me.uid) } : { members: arrayRemove(me.uid) });
        dlg.close(); backToApp();
      } catch (ex) { toast(errText(ex)); }
    } }, t("leave")));
  } else if (!owner) {
    const mem = c.members.includes(me.uid);
    parts.push(h("button", { class: mem ? "del" : "", onclick: async () => { await toggleSub(); dlg.close(); } }, t(mem ? "unsubscribe" : "subscribe")));
  }
  parts.push(h("button", { onclick: () => dlg.close() }, t("close")));
  body.replaceChildren(h("div", { class: "sheet-pad" }, parts));
}

/* ---------- settings ---------- */
$("#profileForm").addEventListener("submit", async e => {
  e.preventDefault();
  const name = $("#pName").value.trim(), bio = $("#pBio").value.trim();
  if (name.length < 2) return toast(t("eName"));
  try {
    await updateDoc(doc(db, "users", me.uid), { name, bio });
    profile = { ...profile, name, bio }; userCache.set(me.uid, profile); paintMe(); toast(t("saved"));
  } catch (ex) { toast(errText(ex)); }
});
$("#myPhotoBtn").onclick = async () => {
  const f = await pickFile("image/*"); if (!f) return;
  try {
    const photo = await toDataUrl(f, 128, .7, true);
    await updateDoc(doc(db, "users", me.uid), { photo });
    profile = { ...profile, photo }; userCache.set(me.uid, profile); paintMe(); toast(t("saved"));
  } catch (ex) { toast(ex.code ? errText(ex) : t("eImg")); }
};
$("#hideSw").onchange = async e => {
  try {
    await updateDoc(doc(db, "users", me.uid), { hideStatus: e.target.checked });
    profile.hideStatus = e.target.checked; setPresence(true);
  } catch (ex) { e.target.checked = !e.target.checked; toast(errText(ex)); }
};
$("#langSel").onchange = e => setLang(e.target.value);
$("#darkSw").onchange = e => { localStorage.setItem("wisal_dark", e.target.checked ? "1" : "0"); applyTheme(); };

/* ---------- init ---------- */
applyTheme(); applyLang(); show("welcome");
