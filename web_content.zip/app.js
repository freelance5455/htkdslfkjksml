const navItems=document.querySelectorAll(".nav-item");
const dashboard=document.getElementById("dashboardSection");
const page=document.getElementById("pageSection");
const pageTitle=document.getElementById("pageTitle");
const sidebar=document.getElementById("sidebar");
const toast=document.getElementById("toast");

function showToast(message){
  toast.textContent=message;
  toast.classList.add("show");
  setTimeout(()=>toast.classList.remove("show"),2200);
}
function showPage(title){
  dashboard.classList.add("hidden");
  page.classList.remove("hidden");
  pageTitle.textContent=title;
  sidebar.classList.remove("open");
}
navItems.forEach(item=>{
  item.addEventListener("click",()=>{
    navItems.forEach(n=>n.classList.remove("active"));
    item.classList.add("active");
    const section=item.dataset.section;
    if(section==="dashboard"){
      dashboard.classList.remove("hidden");
      page.classList.add("hidden");
    }else{
      showPage(item.querySelector("span").textContent);
    }
  });
});
document.getElementById("backDashboard").onclick=()=>{
  navItems.forEach(n=>n.classList.remove("active"));
  document.querySelector('[data-section="dashboard"]').classList.add("active");
  dashboard.classList.remove("hidden");
  page.classList.add("hidden");
};
document.getElementById("menuBtn").onclick=()=>sidebar.classList.toggle("open");
document.getElementById("quickAddBtn").onclick=()=>document.getElementById("quickModal").classList.remove("hidden");
document.getElementById("closeModal").onclick=()=>document.getElementById("quickModal").classList.add("hidden");
document.getElementById("quickModal").addEventListener("click",e=>{
  if(e.target.id==="quickModal") e.currentTarget.classList.add("hidden");
});
document.querySelectorAll("[data-action]").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.getElementById("quickModal").classList.add("hidden");
    showToast(`${btn.dataset.action} module selected`);
  });
});
document.getElementById("refreshBtn").onclick=()=>{
  showToast("Dashboard refreshed successfully");
  document.getElementById("studentCount").textContent="850";
  document.getElementById("teacherCount").textContent="42";
  document.getElementById("classCount").textContent="24";
};
document.getElementById("logoutBtn").onclick=()=>showToast("Logout will be connected to the secure login system.");
document.getElementById("globalSearch").addEventListener("input",e=>{
  const q=e.target.value.toLowerCase();
  document.querySelectorAll("#studentTable tr").forEach(row=>{
    row.style.display=row.textContent.toLowerCase().includes(q)?"":"none";
  });
});

new Chart(document.getElementById("attendanceChart"),{
  type:"line",
  data:{
    labels:["Sat","Sun","Mon","Tue","Wed","Thu","Fri"],
    datasets:[{label:"Present %",data:[92,95,93,97,94,96,94],borderWidth:2,tension:.35,fill:false}]
  },
  options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},scales:{y:{min:80,max:100,ticks:{callback:v=>v+"%"}},x:{grid:{display:false}}}}
});
new Chart(document.getElementById("feesChart"),{
  type:"doughnut",
  data:{labels:["Collected","Outstanding"],datasets:[{data:[12450,3280],borderWidth:0}]},
  options:{responsive:true,maintainAspectRatio:false,cutout:"72%",plugins:{legend:{display:false}}}
});
