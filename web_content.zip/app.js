const scene = new THREE.Scene();
scene.background = new THREE.Color(0x121212);

const world = new CANNON.World();
world.gravity.set(0, -15, 0);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 500);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

const light = new THREE.DirectionalLight(0xffffff, 1.2);
light.position.set(5, 10, 5);
scene.add(light);
scene.add(new THREE.AmbientLight(0x606060));

// Земля
const groundGeo = new THREE.PlaneGeometry(40, 40);
const groundMat = new THREE.MeshStandardMaterial({ color: 0x222226 });
const groundMesh = new THREE.Mesh(groundGeo, groundMat);
groundMesh.rotation.x = -Math.PI / 2;
scene.add(groundMesh);

const groundBody = new CANNON.Body({ mass: 0, shape: new CANNON.Plane() });
groundBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
world.addBody(groundBody);

// Игрок (Player)
const playerRadius = 0.6;
const playerMesh = new THREE.Mesh(
    new THREE.SphereGeometry(playerRadius, 16, 16),
    new THREE.MeshStandardMaterial({ color: 0x00ff88 })
);
scene.add(playerMesh);

const playerBody = new CANNON.Body({
    mass: 5,
    shape: new CANNON.Sphere(playerRadius),
    fixedRotation: true
});
playerBody.position.set(0, 3, 5);
world.addBody(playerBody);

const physicsPairs = [];

if (window.sceneData && window.sceneData.objects) {
    window.sceneData.objects.forEach(obj => {
        let geometry, shape;
        const sx = obj.scale[0], sy = obj.scale[1], sz = obj.scale[2];

        if (obj.shape === "sphere") {
            geometry = new THREE.SphereGeometry(0.6 * sx, 16, 16);
            shape = new CANNON.Sphere(0.6 * sx);
        } else if (obj.shape === "cylinder") {
            geometry = new THREE.CylinderGeometry(0.5 * sx, 0.5 * sx, 1 * sy, 16);
            shape = new CANNON.Cylinder(0.5 * sx, 0.5 * sx, 1 * sy, 8);
        } else if (obj.shape === "wall") {
            geometry = new THREE.BoxGeometry(3 * sx, 2 * sy, 0.4 * sz);
            shape = new CANNON.Box(new CANNON.Vec3((3 * sx) / 2, (2 * sy) / 2, (0.4 * sz) / 2));
        } else {
            geometry = new THREE.BoxGeometry(1 * sx, 1 * sy, 1 * sz);
            shape = new CANNON.Box(new CANNON.Vec3((1 * sx) / 2, (1 * sy) / 2, (1 * sz) / 2));
        }

        const material = new THREE.MeshStandardMaterial({ color: parseInt(obj.color) });
        const mesh = new THREE.Mesh(geometry, material);
        scene.add(mesh);

        const body = new CANNON.Body({ mass: 1, shape: shape });
        body.position.set(obj.position[0], obj.position[1], obj.position[2]);

        const qx = new CANNON.Quaternion(), qy = new CANNON.Quaternion(), qz = new CANNON.Quaternion();
        qx.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), obj.rotation[0] * Math.PI / 180);
        qy.setFromAxisAngle(new CANNON.Vec3(0, 1, 0), obj.rotation[1] * Math.PI / 180);
        qz.setFromAxisAngle(new CANNON.Vec3(0, 0, 1), obj.rotation[2] * Math.PI / 180);
        body.quaternion = qx.mult(qy).mult(qz);

        world.addBody(body);
        physicsPairs.push({ mesh, body, behavior: obj.behavior, initialY: obj.position[1] });
    });
}

// УПРАВЛЕНИЕ ДЖОЙСТИКОМ И МЫШЬЮ / ТАЧЕМ
let joystickDir = { x: 0, y: 0 };
const joystickZone = document.getElementById('joystickZone');
const joystickKnob = document.getElementById('joystickKnob');
const jumpBtn = document.getElementById('jumpBtn');

let isDragging = false;

function handlePointerMove(clientX, clientY) {
    const rect = joystickZone.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    let dx = clientX - centerX;
    let dy = clientY - centerY;
    const dist = Math.hypot(dx, dy);
    const maxDist = 40;

    if (dist > maxDist) {
        dx = (dx / dist) * maxDist;
        dy = (dy / dist) * maxDist;
    }

    joystickKnob.style.left = `${40 + dx}px`;
    joystickKnob.style.top = `${40 + dy}px`;

    joystickDir.x = dx / maxDist;
    joystickDir.y = dy / maxDist;
}

function resetJoystick() {
    isDragging = false;
    joystickDir = { x: 0, y: 0 };
    joystickKnob.style.left = '40px';
    joystickKnob.style.top = '40px';
}

// События для мыши (ПК)
joystickZone.addEventListener('mousedown', (e) => { isDragging = true; handlePointerMove(e.clientX, e.clientY); });
window.addEventListener('mousemove', (e) => { if (isDragging) handlePointerMove(e.clientX, e.clientY); });
window.addEventListener('mouseup', resetJoystick);

// События для Тача (Мобильные)
joystickZone.addEventListener('touchstart', (e) => { isDragging = true; handlePointerMove(e.touches[0].clientX, e.touches[0].clientY); }, { passive: false });
window.addEventListener('touchmove', (e) => { if (isDragging && e.touches.length > 0) handlePointerMove(e.touches[0].clientX, e.touches[0].clientY); }, { passive: false });
window.addEventListener('touchend', resetJoystick);

// Прыжок
function doJump() {
    if (Math.abs(playerBody.velocity.y) < 0.2) {
        playerBody.velocity.y = 8;
    }
}
jumpBtn.addEventListener('click', doJump);
jumpBtn.addEventListener('touchstart', (e) => { e.preventDefault(); doJump(); });

// Управление с клавиатуры WASD + Пробел для ПК
window.addEventListener('keydown', (e) => {
    if (e.code === 'KeyW' || e.code === 'ArrowUp') joystickDir.y = -1;
    if (e.code === 'KeyS' || e.code === 'ArrowDown') joystickDir.y = 1;
    if (e.code === 'KeyA' || e.code === 'ArrowLeft') joystickDir.x = -1;
    if (e.code === 'KeyD' || e.code === 'ArrowRight') joystickDir.x = 1;
    if (e.code === 'Space') doJump();
});

window.addEventListener('keyup', (e) => {
    if (['KeyW', 'KeyS', 'ArrowUp', 'ArrowDown'].includes(e.code)) joystickDir.y = 0;
    if (['KeyA', 'KeyD', 'ArrowLeft', 'ArrowRight'].includes(e.code)) joystickDir.x = 0;
});

// Анимационный цикл
let clock = new THREE.Clock();
const timeStep = 1 / 60;

function animate() {
    requestAnimationFrame(animate);
    world.step(timeStep);
    let elapsedTime = clock.getElapsedTime();

    // Скорость движения игрока
    const moveSpeed = 7;
    playerBody.velocity.x = joystickDir.x * moveSpeed;
    playerBody.velocity.z = joystickDir.y * moveSpeed;

    playerMesh.position.copy(playerBody.position);

    // Камера следит за игроком
    camera.position.set(playerBody.position.x, playerBody.position.y + 5, playerBody.position.z + 8);
    camera.lookAt(playerBody.position.x, playerBody.position.y, playerBody.position.z);

    physicsPairs.forEach(pair => {
        pair.mesh.position.copy(pair.body.position);
        pair.mesh.quaternion.copy(pair.body.quaternion);

        if (pair.behavior === "spin") {
            pair.body.quaternion.setFromAxisAngle(new CANNON.Vec3(0, 1, 0), elapsedTime * 2);
        } else if (pair.behavior === "bounce") {
            pair.body.position.y = pair.initialY + Math.sin(elapsedTime * 4) * 0.5;
        }
    });

    renderer.render(scene, camera);
}
animate();

window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});