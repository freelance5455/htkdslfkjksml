const questions = [
 {subject:"ELECTRICAL BASICS",q:"විදුලි ධාරාව මනින උපකරණය කුමක්ද?",options:["Voltmeter","Ammeter","Ohmmeter","Wattmeter"],answer:1,why:"Ammeter එකෙන් විදුලි ධාරාව මනිනවා. එහි ඒකකය ඇම්පියර් (A) වේ."},
 {subject:"ELECTRICAL BASICS",q:"Ohm නියමය නිවැරදිව දක්වන්නේ කුමන සම්බන්ධතාවයෙන්ද?",options:["V = I × R","P = V × I පමණයි","R = V × I","I = V × R"],answer:0,why:"Ohm නියමය අනුව V = I × R වේ."},
 {subject:"ELECTRICAL BASICS",q:"ප්‍රතිරෝධයේ SI ඒකකය කුමක්ද?",options:["Volt (V)","Ampere (A)","Ohm (Ω)","Watt (W)"],answer:2,why:"විද්‍යුත් ප්‍රතිරෝධය මනින SI ඒකකය Ohm (Ω) වේ."},
 {subject:"MECHANICS",q:"වේගයේ SI ඒකකය කුමක්ද?",options:["m/s","m/s²","kg","N"],answer:0,why:"වේගය = දුර / කාලය. එබැවින් SI ඒකකය m/s වේ."},
 {subject:"MECHANICS",q:"බලයේ SI ඒකකය කුමක්ද?",options:["Joule","Pascal","Newton","Watt"],answer:2,why:"බලයේ SI ඒකකය Newton (N) වේ."},
 {subject:"ELECTRICAL BASICS",q:"12 V විභව අන්තරයක් ඇති 4 Ω ප්‍රතිරෝධයක ධාරාව කොපමණද?",options:["2 A","3 A","4 A","48 A"],answer:1,why:"I = V/R = 12/4 = 3 A."},
 {subject:"ENERGY",q:"විද්‍යුත් බලය ගණනය කිරීමට භාවිත කළ හැකි සූත්‍රය කුමක්ද?",options:["P = V × I","P = V + I","P = R/I","P = m × g"],answer:0,why:"විද්‍යුත් බලය P = V × I වේ."},
 {subject:"MECHANICS",q:"ස්කන්ධයේ SI ඒකකය කුමක්ද?",options:["Newton","Kilogram","Joule","Metre"],answer:1,why:"ස්කන්ධයේ SI ඒකකය kilogram (kg) වේ."},
 {subject:"COMPUTING",q:"CPU යන්නෙන් අදහස් කරන්නේ කුමක්ද?",options:["Central Processing Unit","Computer Power Utility","Control Program User","Central Print Unit"],answer:0,why:"CPU යනු Central Processing Unit යන්නයි."},
 {subject:"MEASUREMENT",q:"දිග මැනීම සඳහා සාමාන්‍යයෙන් භාවිත කරන උපකරණයක් කුමක්ද?",options:["Ammeter","Thermometer","Ruler","Barometer"],answer:2,why:"සාමාන්‍ය දිග මැනීමට ruler හෝ metre rule භාවිත කරයි."}
];
const screens = ["home","learn","lesson","practice","profile"];
let currentQuestion=0, selectedAnswer=null, score=0, answered=false;
let attempts=Number(localStorage.getItem("etlab_attempts")||0);
let best=Number(localStorage.getItem("etlab_best")||0);
const $=s=>document.querySelector(s);
function go(name){
 screens.forEach(s=>$("#"+s+"Screen").classList.toggle("active",s===name));
 document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("selected",b.dataset.go===name));
 window.scrollTo({top:0,behavior:"smooth"});
 if(name==="profile")updateStats();
 if(name==="practice" && $("#quizResult").classList.contains("hidden") && currentQuestion===0 && !answered) renderQuestion();
}
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
document.querySelectorAll("[data-subject]").forEach(b=>b.addEventListener("click",()=>go("lesson")));
$("#profileBtn").addEventListener("click",()=>go("profile"));
function renderQuestion(){
 const q=questions[currentQuestion]; selectedAnswer=null;answered=false;
 $("#quizResult").classList.add("hidden");$("#quizCard").classList.remove("hidden");
 $("#questionSubject").textContent=q.subject;
 $("#questionText").textContent=q.q;
 $("#questionCount").textContent=String(currentQuestion+1).padStart(2,"0")+" / "+questions.length;
 $("#quizProgress").style.width=((currentQuestion+1)/questions.length*100)+"%";
 $("#feedback").textContent="";$("#feedback").className="feedback";
 $("#submitAnswer").disabled=false;$("#submitAnswer").innerHTML='පිළිතුර Submit කරන්න <span>→</span>';
 $("#options").innerHTML=q.options.map((o,i)=>`<button class="option" data-answer="${i}"><span class="radio"></span><span>${o}</span></button>`).join("");
 $("#options").querySelectorAll(".option").forEach(btn=>btn.addEventListener("click",()=>{
   if(answered)return;
   selectedAnswer=Number(btn.dataset.answer);
   $("#options").querySelectorAll(".option").forEach(b=>b.classList.toggle("selected",b===btn));
 }));
}
$("#submitAnswer").addEventListener("click",()=>{
 if(answered){
   if(currentQuestion<questions.length-1){currentQuestion++;renderQuestion();}
   else showResult();
   return;
 }
 if(selectedAnswer===null){$("#feedback").textContent="කරුණාකර පිළිතුරක් තෝරන්න.";$("#feedback").className="feedback bad";return;}
 answered=true;const q=questions[currentQuestion],correct=selectedAnswer===q.answer;
 if(correct)score++;
 $("#options").querySelectorAll(".option").forEach((btn,i)=>{if(i===q.answer)btn.classList.add("correct");if(i===selectedAnswer&&!correct)btn.classList.add("wrong");});
 $("#feedback").textContent=(correct?"නිවැරදියි! ":"තව ටිකක් පුහුණු වෙමු. ")+q.why;
 $("#feedback").className="feedback "+(correct?"good":"bad");
 $("#submitAnswer").innerHTML=currentQuestion===questions.length-1?'ප්‍රතිඵල බලන්න <span>→</span>':'ඊළඟ ප්‍රශ්නය <span>→</span>';
});
function showResult(){
 $("#quizCard").classList.add("hidden");$("#quizResult").classList.remove("hidden");
 const pct=Math.round(score/questions.length*100);
 $("#quizResult").innerHTML=`<span class="mini-label">QUIZ COMPLETED</span><h2>නියමයි! පුහුණුව අවසන්.</h2><div class="result-score">${score}/${questions.length}</div><p class="muted">ඔබ ලබාගත් ලකුණු: ${pct}%</p><p>${pct>=80?"විශිෂ්ටයි! මේ විදිහටම දිගටම කරගෙන යන්න.":pct>=50?"හොඳ ආරම්භයක්. වැරදුණු සංකල්ප නැවත බලන්න.":"කමක් නෑ. පාඩම නැවත කියවා තවත් වරක් උත්සාහ කරන්න."}</p><button id="retryQuiz" class="button button-primary full-button">නැවත Quiz කරන්න <span>↻</span></button><button id="homeAfterQuiz" class="button full-button" style="background:#edf3ec;color:#24543a">Home වෙත යන්න</button>`;
 attempts++;best=Math.max(best,score);localStorage.setItem("etlab_attempts",attempts);localStorage.setItem("etlab_best",best);
 $("#retryQuiz").addEventListener("click",startQuiz);$("#homeAfterQuiz").addEventListener("click",()=>go("home"));updateStats();
}
function startQuiz(){currentQuestion=0;score=0;selectedAnswer=null;answered=false;renderQuestion();go("practice");}
function updateStats(){$("#attemptStat").textContent=attempts;$("#bestStat").textContent=attempts?best+"/"+questions.length:"—";}
$("#streakNum").textContent="01";
renderQuestion();updateStats();
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
