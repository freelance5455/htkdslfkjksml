/**
 * NEXUS FINANCIAL OS — Core Application Engine
 * Argentine Pesos (ARS) Edition
 */

// ==========================================================================
// 1. Data Constants & Default Setup
// ==========================================================================
const STORAGE_KEYS = {
  TRANSACTIONS: 'nexus_transactions_v1',
  BUDGETS: 'nexus_budgets_v1',
  SETTINGS: 'nexus_settings_v1'
};

const CATEGORIES = {
  expense: [
    { id: 'supermercado', label: 'Supermercado', icon: '🛒', color: '#00F2FE' },
    { id: 'vivienda', label: 'Alquiler & Expensas', icon: '🏠', color: '#7F00FF' },
    { id: 'servicios', label: 'Luz, Gas, Internet', icon: '⚡', color: '#FFB800' },
    { id: 'transporte', label: 'Transporte & Nafta', icon: '🚗', color: '#00F5A0' },
    { id: 'salidas', label: 'Salidas & Ocio', icon: '🍸', color: '#FF3366' },
    { id: 'tecnologia', label: 'Tecnología & Subscrip.', icon: '💻', color: '#00D2FF' },
    { id: 'salud', label: 'Salud & Farmacia', icon: '🩺', color: '#FF5E7E' },
    { id: 'educacion', label: 'Cursos & Educación', icon: '📚', color: '#A355FF' },
    { id: 'otros_gastos', label: 'Otros Gastos', icon: '📦', color: '#8A99B5' }
  ],
  income: [
    { id: 'sueldo', label: 'Sueldo / Haberes', icon: '💼', color: '#00F5A0' },
    { id: 'freelance', label: 'Honorarios / Freelance', icon: '⚡', color: '#00F2FE' },
    { id: 'inversiones', label: 'Rendimientos / Plazo Fijo', icon: '📈', color: '#FFB800' },
    { id: 'ventas', label: 'Ventas / Comercio', icon: '🛍️', color: '#7F00FF' },
    { id: 'otros_ingresos', label: 'Otros Ingresos', icon: '💵', color: '#4ADE80' }
  ]
};

const DEFAULT_BUDGETS = {
  supermercado: 250000,
  vivienda: 450000,
  servicios: 75000,
  transporte: 60000,
  salidas: 90000,
  tecnologia: 40000
};

// Initial Demo Dataset (Argentine Pesos Context)
const DEMO_TRANSACTIONS = [
  {
    id: 'tx_demo_1',
    type: 'income',
    amount: 1450000,
    concept: 'Liquidación Sueldo Mensual',
    category: 'sueldo',
    date: getRelativeDateStr(-18),
    method: 'Transferencia / Banco',
    timestamp: Date.now() - 18 * 86400000
  },
  {
    id: 'tx_demo_2',
    type: 'expense',
    amount: 380000,
    concept: 'Pago Alquiler Departamento',
    category: 'vivienda',
    date: getRelativeDateStr(-16),
    method: 'Transferencia / Banco',
    timestamp: Date.now() - 16 * 86400000
  },
  {
    id: 'tx_demo_3',
    type: 'expense',
    amount: 142500,
    concept: 'Compra Coto Digital Quincenal',
    category: 'supermercado',
    date: getRelativeDateStr(-12),
    method: 'Mercado Pago',
    timestamp: Date.now() - 12 * 86400000
  },
  {
    id: 'tx_demo_4',
    type: 'expense',
    amount: 48900,
    concept: 'Fibertel / Personal Flow + Luz Edenor',
    category: 'servicios',
    date: getRelativeDateStr(-10),
    method: 'Mercado Pago',
    timestamp: Date.now() - 10 * 86400000
  },
  {
    id: 'tx_demo_5',
    type: 'income',
    amount: 320000,
    concept: 'Proyecto Desarrollo Web Freelance',
    category: 'freelance',
    date: getRelativeDateStr(-8),
    method: 'Transferencia / Banco',
    timestamp: Date.now() - 8 * 86400000
  },
  {
    id: 'tx_demo_6',
    type: 'expense',
    amount: 38500,
    concept: 'Carga Combustible YPF Infinia',
    category: 'transporte',
    date: getRelativeDateStr(-5),
    method: 'Tarjeta de Débito',
    timestamp: Date.now() - 5 * 86400000
  },
  {
    id: 'tx_demo_7',
    type: 'expense',
    amount: 42000,
    concept: 'Cena con Amigos Palermo',
    category: 'salidas',
    date: getRelativeDateStr(-2),
    method: 'Mercado Pago',
    timestamp: Date.now() - 2 * 86400000
  },
  {
    id: 'tx_demo_8',
    type: 'income',
    amount: 85400,
    concept: 'Rendimiento Inversión Mercado Fondo',
    category: 'inversiones',
    date: getRelativeDateStr(0),
    method: 'Mercado Pago',
    timestamp: Date.now()
  }
];

function getRelativeDateStr(offsetDays) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return d.toISOString().split('T')[0];
}

// ==========================================================================
// 2. Futuristic Web Audio Synthesizer (Zero External Dependencies)
// ==========================================================================
class FuturisticAudioEngine {
  constructor() {
    this.enabled = true;
    this.ctx = null;
  }

  init() {
    if (!this.ctx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        this.ctx = new AudioContext();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  playClick() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(350, this.ctx.currentTime + 0.04);
      gain.gain.setValueAtTime(0.04, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.04);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.04);
    } catch (e) {}
  }

  playIncomeSound() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    try {
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C-E-G-C ascending chord
      notes.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime + idx * 0.07);
        gain.gain.setValueAtTime(0, this.ctx.currentTime + idx * 0.07);
        gain.gain.linearRampToValueAtTime(0.06, this.ctx.currentTime + idx * 0.07 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + idx * 0.07 + 0.35);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(this.ctx.currentTime + idx * 0.07);
        osc.stop(this.ctx.currentTime + idx * 0.07 + 0.35);
      });
    } catch (e) {}
  }

  playExpenseSound() {
    if (!this.enabled) return;
    this.init();
    if (!this.ctx) return;
    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(140, this.ctx.currentTime + 0.18);
      gain.gain.setValueAtTime(0.06, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.18);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.18);
    } catch (e) {}
  }
}

const audio = new FuturisticAudioEngine();

// ==========================================================================
// 3. State Management
// ==========================================================================
const state = {
  transactions: [],
  budgets: { ...DEFAULT_BUDGETS },
  settings: { soundEnabled: true },
  filterType: 'all',
  filterCategory: 'all',
  searchQuery: '',
  chartRange: '30',
  currentDisplayBalance: 0
};

// ==========================================================================
// 4. Currency Formatter (Argentine Pesos ARS)
// ==========================================================================
function formatARS(amount, includeDecimals = true) {
  const num = Number(amount) || 0;
  return new Intl.NumberFormat('es-AR', {
    style: 'currency',
    currency: 'ARS',
    minimumFractionDigits: includeDecimals ? 2 : 0,
    maximumFractionDigits: includeDecimals ? 2 : 0
  }).format(num);
}

function formatDateDisplay(dateStr) {
  if (!dateStr) return '';
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2]}/${parts[1]}/${parts[0]}`;
  }
  return dateStr;
}

// ==========================================================================
// 5. App Initialization & Event Listeners
// ==========================================================================
document.addEventListener('DOMContentLoaded', () => {
  loadDataFromStorage();
  setupUI();
  setupCharts();
  renderAll();
});

function loadDataFromStorage() {
  try {
    const rawTx = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (rawTx) {
      state.transactions = JSON.parse(rawTx);
    } else {
      // First run: load initial demo data
      state.transactions = [...DEMO_TRANSACTIONS];
      saveTransactionsToStorage();
    }

    const rawBudgets = localStorage.getItem(STORAGE_KEYS.BUDGETS);
    if (rawBudgets) {
      state.budgets = { ...DEFAULT_BUDGETS, ...JSON.parse(rawBudgets) };
    }

    const rawSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (rawSettings) {
      state.settings = JSON.parse(rawSettings);
      audio.enabled = state.settings.soundEnabled;
    }
  } catch (e) {
    console.error('Error cargando datos de almacenamiento local:', e);
    state.transactions = [...DEMO_TRANSACTIONS];
  }
}

function saveTransactionsToStorage() {
  localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(state.transactions));
}

function saveBudgetsToStorage() {
  localStorage.setItem(STORAGE_KEYS.BUDGETS, JSON.stringify(state.budgets));
}

function saveSettingsToStorage() {
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(state.settings));
}

// ==========================================================================
// 6. UI Controls & Interactions
// ==========================================================================
function setupUI() {
  // Sound toggle button
  const soundBtn = document.getElementById('soundToggleBtn');
  updateSoundButtonUI();
  soundBtn.addEventListener('click', () => {
    state.settings.soundEnabled = !state.settings.soundEnabled;
    audio.enabled = state.settings.soundEnabled;
    saveSettingsToStorage();
    updateSoundButtonUI();
    if (audio.enabled) audio.playClick();
    showToast(audio.enabled ? 'Audio de telemetría activado' : 'Audio silenciado', 'info');
  });

  // Data Dropdown
  const dataMenuBtn = document.getElementById('dataMenuBtn');
  const dataDropdownMenu = document.getElementById('dataDropdownMenu');
  dataMenuBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    dataDropdownMenu.classList.toggle('show');
    audio.playClick();
  });

  document.addEventListener('click', () => {
    dataDropdownMenu.classList.remove('show');
  });

  // Backup actions
  document.getElementById('exportJsonBtn').addEventListener('click', exportBackupJSON);
  document.getElementById('exportCsvBtn').addEventListener('click', exportBackupCSV);
  document.getElementById('importJsonInput').addEventListener('change', handleImportJSON);
  document.getElementById('demoDataBtn').addEventListener('click', () => {
    state.transactions = [...DEMO_TRANSACTIONS];
    saveTransactionsToStorage();
    renderAll();
    showToast('Datos de demostración restablecidos en pesos ARS', 'success');
  });
  document.getElementById('clearDataBtn').addEventListener('click', () => {
    if (confirm('¿Estás seguro de reiniciar todo el registro? Se borrarán todas las transacciones almacenadas.')) {
      state.transactions = [];
      saveTransactionsToStorage();
      renderAll();
      showToast('Registro de transacciones vaciado', 'danger');
    }
  });

  // Modal: Nueva Transacción
  const txModal = document.getElementById('txModal');
  const openTxBtn = document.getElementById('openNewTxModalBtn');
  const closeTxBtn = document.getElementById('closeTxModalBtn');
  const cancelTxBtn = document.getElementById('cancelTxModalBtn');
  const txForm = document.getElementById('txForm');

  openTxBtn.addEventListener('click', () => openTransactionModal());
  closeTxBtn.addEventListener('click', () => closeTransactionModal());
  cancelTxBtn.addEventListener('click', () => closeTransactionModal());

  // Modal: Presupuestos
  const budgetModal = document.getElementById('budgetModal');
  const budgetModalBtn = document.getElementById('budgetModalBtn');
  const quickEditBudgetBtn = document.getElementById('quickEditBudgetBtn');
  const closeBudgetModalBtn = document.getElementById('closeBudgetModalBtn');
  const cancelBudgetModalBtn = document.getElementById('cancelBudgetModalBtn');
  const budgetForm = document.getElementById('budgetForm');

  budgetModalBtn.addEventListener('click', () => openBudgetModal());
  quickEditBudgetBtn.addEventListener('click', () => openBudgetModal());
  closeBudgetModalBtn.addEventListener('click', () => closeBudgetModal());
  cancelBudgetModalBtn.addEventListener('click', () => closeBudgetModal());

  // Close modals on Escape key or click outside
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeTransactionModal();
      closeBudgetModal();
    }
    // Ctrl + N shortcut
    if ((e.ctrlKey || e.metaKey) && (e.key === 'n' || e.key === 'N')) {
      e.preventDefault();
      openTransactionModal();
    }
  });

  [txModal, budgetModal].forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        modal.classList.remove('open');
      }
    });
  });

  // Form: Type switch listener (expense vs income)
  document.querySelectorAll('input[name="txType"]').forEach(radio => {
    radio.addEventListener('change', () => {
      renderCategoryChips(radio.value);
      audio.playClick();
    });
  });

  // Form submit
  txForm.addEventListener('submit', handleTransactionSubmit);
  budgetForm.addEventListener('submit', handleBudgetSubmit);

  // Search & Filter controls
  const searchInput = document.getElementById('txSearchInput');
  searchInput.addEventListener('input', (e) => {
    state.searchQuery = e.target.value.toLowerCase().trim();
    renderTransactionsTable();
  });

  document.querySelectorAll('.seg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.filterType = btn.dataset.filter;
      audio.playClick();
      renderTransactionsTable();
    });
  });

  const catFilterSelect = document.getElementById('categoryFilterSelect');
  catFilterSelect.addEventListener('change', (e) => {
    state.filterCategory = e.target.value;
    audio.playClick();
    renderTransactionsTable();
  });

  // Chart range filter buttons
  document.querySelectorAll('.filter-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.chartRange = btn.dataset.range;
      audio.playClick();
      drawCashflowChart();
    });
  });
}

function updateSoundButtonUI() {
  const btn = document.getElementById('soundToggleBtn');
  const label = btn.querySelector('.btn-label');
  if (state.settings.soundEnabled) {
    btn.style.color = 'var(--neon-cyan)';
    btn.style.borderColor = 'rgba(0, 242, 254, 0.4)';
    label.textContent = 'AUDIO ON';
  } else {
    btn.style.color = 'var(--text-dim)';
    btn.style.borderColor = 'var(--border-subtle)';
    label.textContent = 'MUTED';
  }
}

// ==========================================================================
// 7. Modal Handlers
// ==========================================================================
let selectedCategoryId = null;

function openTransactionModal() {
  audio.playClick();
  const modal = document.getElementById('txModal');
  const form = document.getElementById('txForm');
  form.reset();

  document.getElementById('typeExpense').checked = true;
  document.getElementById('txDateInput').value = new Date().toISOString().split('T')[0];
  renderCategoryChips('expense');

  modal.classList.add('open');
  setTimeout(() => document.getElementById('amountInput').focus(), 100);
}

function closeTransactionModal() {
  document.getElementById('txModal').classList.remove('open');
}

function renderCategoryChips(type) {
  const container = document.getElementById('categoryChipsGrid');
  container.innerHTML = '';
  const list = CATEGORIES[type] || [];

  selectedCategoryId = list.length > 0 ? list[0].id : null;

  list.forEach((cat, index) => {
    const chip = document.createElement('button');
    chip.type = 'button';
    chip.className = `category-chip-btn ${index === 0 ? 'active' : ''}`;
    chip.innerHTML = `<span>${cat.icon}</span> <span>${cat.label}</span>`;
    chip.dataset.id = cat.id;

    chip.addEventListener('click', () => {
      container.querySelectorAll('.category-chip-btn').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      selectedCategoryId = cat.id;
      audio.playClick();
    });

    container.appendChild(chip);
  });
}

function handleTransactionSubmit(e) {
  e.preventDefault();

  const amount = parseFloat(document.getElementById('amountInput').value);
  const concept = document.getElementById('conceptInput').value.trim();
  const type = document.querySelector('input[name="txType"]:checked').value;
  const date = document.getElementById('txDateInput').value;
  const method = document.getElementById('paymentMethodSelect').value;

  if (isNaN(amount) || amount <= 0) {
    showToast('Ingresa un monto válido en pesos', 'danger');
    return;
  }

  if (!concept) {
    showToast('Ingresa una descripción del movimiento', 'danger');
    return;
  }

  const newTx = {
    id: 'tx_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    type,
    amount,
    concept,
    category: selectedCategoryId || (type === 'income' ? 'otros_ingresos' : 'otros_gastos'),
    date,
    method,
    timestamp: new Date(date + 'T12:00:00').getTime() || Date.now()
  };

  state.transactions.unshift(newTx);
  saveTransactionsToStorage();

  closeTransactionModal();
  renderAll();

  if (type === 'income') {
    audio.playIncomeSound();
    showToast(`+ ${formatARS(amount)} ingresados al sistema`, 'success');
  } else {
    audio.playExpenseSound();
    showToast(`- ${formatARS(amount)} registrados en ${newTx.category}`, 'info');
  }
}

function openBudgetModal() {
  audio.playClick();
  const container = document.getElementById('budgetInputsList');
  container.innerHTML = '';

  CATEGORIES.expense.forEach(cat => {
    const currentVal = state.budgets[cat.id] || 0;
    const row = document.createElement('div');
    row.className = 'budget-input-row';
    row.innerHTML = `
      <div class="budget-cat-label">${cat.icon} ${cat.label}</div>
      <div class="budget-amount-wrapper">
        <span style="color: var(--neon-cyan); font-weight: bold;">$</span>
        <input type="number" step="1000" min="0" data-cat="${cat.id}" value="${currentVal}">
      </div>
    `;
    container.appendChild(row);
  });

  document.getElementById('budgetModal').classList.add('open');
}

function closeBudgetModal() {
  document.getElementById('budgetModal').classList.remove('open');
}

function handleBudgetSubmit(e) {
  e.preventDefault();
  const inputs = document.querySelectorAll('#budgetInputsList input');
  inputs.forEach(inp => {
    const catId = inp.dataset.cat;
    const val = parseFloat(inp.value) || 0;
    state.budgets[catId] = val;
  });

  saveBudgetsToStorage();
  closeBudgetModal();
  renderBudgets();
  audio.playClick();
  showToast('Límites de presupuesto guardados correctamente', 'success');
}

// ==========================================================================
// 8. Financial Calculations & Metrics Engine
// ==========================================================================
function computeFinancials() {
  let totalBalance = 0;
  let totalIncomeAll = 0;
  let totalExpenseAll = 0;

  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();

  let monthlyIncome = 0;
  let monthlyExpense = 0;
  let monthlyIncomeCount = 0;

  const categoryExpenses = {};
  CATEGORIES.expense.forEach(c => categoryExpenses[c.id] = 0);

  state.transactions.forEach(tx => {
    const amt = Number(tx.amount) || 0;
    const txDate = new Date(tx.date + 'T00:00:00');
    const isThisMonth = txDate.getFullYear() === currentYear && txDate.getMonth() === currentMonth;

    if (tx.type === 'income') {
      totalBalance += amt;
      totalIncomeAll += amt;
      if (isThisMonth) {
        monthlyIncome += amt;
        monthlyIncomeCount++;
      }
    } else {
      totalBalance -= amt;
      totalExpenseAll += amt;
      if (isThisMonth) {
        monthlyExpense += amt;
        if (categoryExpenses[tx.category] !== undefined) {
          categoryExpenses[tx.category] += amt;
        } else {
          categoryExpenses['otros_gastos'] = (categoryExpenses['otros_gastos'] || 0) + amt;
        }
      }
    }
  });

  // Savings rate
  const netMonthlyFlow = monthlyIncome - monthlyExpense;
  let savingsRate = 0;
  if (monthlyIncome > 0) {
    savingsRate = Math.max(0, Math.round((netMonthlyFlow / monthlyIncome) * 100));
  }

  const expenseRatio = monthlyIncome > 0 ? Math.round((monthlyExpense / monthlyIncome) * 100) : 0;

  return {
    totalBalance,
    totalIncomeAll,
    totalExpenseAll,
    monthlyIncome,
    monthlyExpense,
    monthlyIncomeCount,
    netMonthlyFlow,
    savingsRate,
    expenseRatio,
    categoryExpenses
  };
}

// ==========================================================================
// 9. Render HUD & UI Updates
// ==========================================================================
function renderAll() {
  const fin = computeFinancials();
  renderCounters(fin);
  renderCategoryFilterDropdown();
  renderTransactionsTable();
  renderBudgets(fin.categoryExpenses);
  drawCashflowChart();
  drawDonutChart(fin.categoryExpenses);
}

function renderCounters(fin) {
  // Animated Counter for Main Balance
  animateRollingBalance(fin.totalBalance);

  // Monthly Income & Expenses
  document.getElementById('monthlyIncomeVal').textContent = formatARS(fin.monthlyIncome);
  document.getElementById('incomeCountVal').textContent = `${fin.monthlyIncomeCount} entradas este mes`;

  document.getElementById('monthlyExpenseVal').textContent = formatARS(fin.monthlyExpense);
  document.getElementById('expenseRatioVal').textContent = `${fin.expenseRatio}% del ingreso consumido`;

  // Savings velocity meter
  const circle = document.getElementById('savingsCircleProgress');
  const percentText = document.getElementById('savingsPercentText');
  const netMonthlyFlowVal = document.getElementById('netMonthlyFlowVal');
  const savingsStatusTag = document.getElementById('savingsStatusTag');

  circle.setAttribute('stroke-dasharray', `${fin.savingsRate}, 100`);
  percentText.textContent = `${fin.savingsRate}%`;
  netMonthlyFlowVal.textContent = formatARS(fin.netMonthlyFlow);

  if (fin.netMonthlyFlow >= 0) {
    netMonthlyFlowVal.style.color = '#fff';
    savingsStatusTag.textContent = fin.savingsRate >= 30 ? 'ÓPTIMO (SUPERÁVIT)' : 'POSITIVO';
    savingsStatusTag.style.color = 'var(--neon-green)';
  } else {
    netMonthlyFlowVal.style.color = 'var(--neon-red)';
    savingsStatusTag.textContent = 'DÉFICIT MENSUAL';
    savingsStatusTag.style.color = 'var(--neon-red)';
  }

  // Trend tag
  const trendText = document.getElementById('balanceTrendText');
  const trendIcon = document.getElementById('balanceTrendIcon');
  if (state.transactions.length === 0) {
    trendText.textContent = 'Sin transacciones';
    trendIcon.style.display = 'none';
  } else {
    trendIcon.style.display = 'inline-block';
    if (fin.totalBalance >= 0) {
      trendText.textContent = 'Fondo positivo';
      trendText.style.color = 'var(--neon-green)';
      trendIcon.style.color = 'var(--neon-green)';
      trendIcon.style.transform = 'rotate(0deg)';
    } else {
      trendText.textContent = 'Balance negativo';
      trendText.style.color = 'var(--neon-red)';
      trendIcon.style.color = 'var(--neon-red)';
      trendIcon.style.transform = 'rotate(90deg)';
    }
  }
}

function animateRollingBalance(targetVal) {
  const elem = document.getElementById('totalBalanceVal');
  const startVal = state.currentDisplayBalance || 0;
  const duration = 600;
  const startTime = performance.now();

  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // Ease out expo
    const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
    const current = startVal + (targetVal - startVal) * ease;
    elem.textContent = formatARS(current);

    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      state.currentDisplayBalance = targetVal;
      elem.textContent = formatARS(targetVal);
    }
  }

  requestAnimationFrame(update);
}

// ==========================================================================
// 10. Budgets Render & Monitoring
// ==========================================================================
function renderBudgets(categoryExpenses) {
  if (!categoryExpenses) {
    categoryExpenses = computeFinancials().categoryExpenses;
  }

  const grid = document.getElementById('budgetBarsGrid');
  grid.innerHTML = '';

  const activeBudgetEntries = Object.entries(state.budgets).filter(([_, limit]) => limit > 0);

  if (activeBudgetEntries.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; color: var(--text-dim); padding: 18px;">
        No has configurado presupuestos aún. Haz clic en <strong>Configurar Límites</strong> para añadir metas de ahorro.
      </div>
    `;
    return;
  }

  activeBudgetEntries.forEach(([catId, limit]) => {
    const catObj = CATEGORIES.expense.find(c => c.id === catId) || { label: catId, icon: '🏷️' };
    const spent = categoryExpenses[catId] || 0;
    const pct = Math.min(Math.round((spent / limit) * 100), 100);

    let statusClass = 'fill-safe';
    let statusTextColor = 'var(--neon-cyan)';
    if (pct >= 90) {
      statusClass = 'fill-danger';
      statusTextColor = 'var(--neon-red)';
    } else if (pct >= 70) {
      statusClass = 'fill-warn';
      statusTextColor = 'var(--neon-amber)';
    }

    const card = document.createElement('div');
    card.className = 'budget-card';
    card.innerHTML = `
      <div class="budget-top">
        <span class="budget-name">${catObj.icon} ${catObj.label}</span>
        <span class="budget-pct" style="color: ${statusTextColor}">${pct}%</span>
      </div>
      <div class="progress-track">
        <div class="progress-fill ${statusClass}" style="width: ${pct}%"></div>
      </div>
      <div class="budget-amounts">
        <span>Gastado: ${formatARS(spent, false)}</span>
        <span>Límite: ${formatARS(limit, false)}</span>
      </div>
    `;
    grid.appendChild(card);
  });
}

// ==========================================================================
// 11. Transaction Table Matrix
// ==========================================================================
function renderCategoryFilterDropdown() {
  const select = document.getElementById('categoryFilterSelect');
  const currentVal = select.value;
  select.innerHTML = '<option value="all">Todas las Categorías</option>';

  const allCats = [...CATEGORIES.expense, ...CATEGORIES.income];
  allCats.forEach(cat => {
    const opt = document.createElement('option');
    opt.value = cat.id;
    opt.textContent = `${cat.icon} ${cat.label}`;
    select.appendChild(opt);
  });

  select.value = currentVal || 'all';
}

function renderTransactionsTable() {
  const tbody = document.getElementById('transactionTableBody');
  const emptyState = document.getElementById('emptyTableState');
  const counterBadge = document.getElementById('txCountBadge');

  tbody.innerHTML = '';

  // Filter pipeline
  let filtered = state.transactions.filter(tx => {
    // Type filter
    if (state.filterType !== 'all' && tx.type !== state.filterType) return false;
    // Category filter
    if (state.filterCategory !== 'all' && tx.category !== state.filterCategory) return false;
    // Search query
    if (state.searchQuery) {
      const q = state.searchQuery;
      const conceptMatch = (tx.concept || '').toLowerCase().includes(q);
      const catMatch = (tx.category || '').toLowerCase().includes(q);
      const methodMatch = (tx.method || '').toLowerCase().includes(q);
      if (!conceptMatch && !catMatch && !methodMatch) return false;
    }
    return true;
  });

  // Sort by date descending
  filtered.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

  counterBadge.textContent = `${filtered.length} REGISTROS`;

  if (filtered.length === 0) {
    emptyState.style.display = 'flex';
    return;
  } else {
    emptyState.style.display = 'none';
  }

  filtered.forEach(tx => {
    const isIncome = tx.type === 'income';
    const catObj = [...CATEGORIES.expense, ...CATEGORIES.income].find(c => c.id === tx.category) || {
      label: tx.category,
      icon: '🏷️'
    };

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="tx-date-cell">${formatDateDisplay(tx.date)}</td>
      <td class="tx-concept-cell">${escapeHtml(tx.concept)}</td>
      <td>
        <span class="tx-cat-badge">
          <span>${catObj.icon}</span>
          <span>${catObj.label}</span>
        </span>
      </td>
      <td>
        <span class="tx-method-badge">${tx.method || 'General'}</span>
      </td>
      <td class="tx-amount-cell ${isIncome ? 'income-color' : 'expense-color'}">
        ${isIncome ? '+' : '-'} ${formatARS(tx.amount)}
      </td>
      <td style="text-align: center;">
        <button class="tx-action-btn delete-tx-btn" data-id="${tx.id}" title="Eliminar registro">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
      </td>
    `;

    tr.querySelector('.delete-tx-btn').addEventListener('click', () => {
      deleteTransaction(tx.id);
    });

    tbody.appendChild(tr);
  });
}

function deleteTransaction(id) {
  audio.playClick();
  state.transactions = state.transactions.filter(t => t.id !== id);
  saveTransactionsToStorage();
  renderAll();
  showToast('Transacción eliminada del registro local', 'info');
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ==========================================================================
// 12. Dynamic Canvas Cashflow Chart (Interactive Bezier Wave)
// ==========================================================================
let canvasHoverIndex = -1;
let chartPointsCache = [];

function setupCharts() {
  const canvas = document.getElementById('cashflowCanvas');
  if (!canvas) return;

  // Mouse move on canvas for holographic tooltip
  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    let closest = -1;
    let minDist = 30;

    chartPointsCache.forEach((pt, idx) => {
      const dist = Math.hypot(pt.x - x, pt.y - y);
      if (dist < minDist) {
        minDist = dist;
        closest = idx;
      }
    });

    const tooltip = document.getElementById('chartTooltip');
    if (closest !== -1) {
      canvasHoverIndex = closest;
      const pt = chartPointsCache[closest];
      tooltip.style.left = `${pt.x + 12}px`;
      tooltip.style.top = `${pt.y - 30}px`;
      tooltip.style.opacity = '1';
      tooltip.innerHTML = `<strong>${pt.date}</strong><br>Balance: <span style="color:var(--neon-cyan)">${formatARS(pt.balance)}</span>`;
      drawCashflowChart();
    } else {
      if (canvasHoverIndex !== -1) {
        canvasHoverIndex = -1;
        tooltip.style.opacity = '0';
        drawCashflowChart();
      }
    }
  });

  canvas.addEventListener('mouseleave', () => {
    canvasHoverIndex = -1;
    const tooltip = document.getElementById('chartTooltip');
    if (tooltip) tooltip.style.opacity = '0';
    drawCashflowChart();
  });

  window.addEventListener('resize', () => {
    drawCashflowChart();
  });
}

function drawCashflowChart() {
  const canvas = document.getElementById('cashflowCanvas');
  if (!canvas) return;

  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();

  if (rect.width === 0 || rect.height === 0) return;

  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;

  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, rect.width, rect.height);

  // Group transactions by date
  const sorted = [...state.transactions].sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));

  // Determine date bounds
  const now = new Date();
  let daysLimit = 30;
  if (state.chartRange === '90') daysLimit = 90;
  if (state.chartRange === 'all') daysLimit = 365;

  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - daysLimit);

  const activeTx = sorted.filter(t => new Date(t.date + 'T00:00:00') >= cutoff);

  // Generate continuous timeline points
  const points = [];
  let runningBalance = 0;

  // Calculate base initial balance before cutoff
  sorted.filter(t => new Date(t.date + 'T00:00:00') < cutoff).forEach(t => {
    runningBalance += (t.type === 'income' ? t.amount : -t.amount);
  });

  if (activeTx.length === 0) {
    // Empty state chart
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.font = '12px JetBrains Mono';
    ctx.textAlign = 'center';
    ctx.fillText('Sin datos suficientes en este rango de fechas', rect.width / 2, rect.height / 2);
    return;
  }

  // Date map
  const dateMap = {};
  activeTx.forEach(t => {
    if (!dateMap[t.date]) dateMap[t.date] = 0;
    dateMap[t.date] += (t.type === 'income' ? t.amount : -t.amount);
  });

  const dates = Object.keys(dateMap).sort();
  dates.forEach(d => {
    runningBalance += dateMap[d];
    points.push({ date: formatDateDisplay(d), balance: runningBalance });
  });

  if (points.length === 1) {
    // Duplicate single point for line visibility
    points.unshift({ date: points[0].date, balance: points[0].balance });
  }

  const balances = points.map(p => p.balance);
  let minVal = Math.min(...balances);
  let maxVal = Math.max(...balances);

  if (minVal === maxVal) {
    minVal -= 10000;
    maxVal += 10000;
  }

  const padding = 35;
  const w = rect.width - padding * 2;
  const h = rect.height - padding * 2;

  // Compute coordinate pixels
  chartPointsCache = points.map((p, idx) => {
    const x = padding + (idx / (points.length - 1)) * w;
    const normY = (p.balance - minVal) / (maxVal - minVal);
    const y = rect.height - padding - normY * h;
    return { ...p, x, y };
  });

  // Background Grid Lines
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
  ctx.lineWidth = 1;
  const gridLines = 4;
  for (let i = 0; i <= gridLines; i++) {
    const y = padding + (i / gridLines) * h;
    ctx.beginPath();
    ctx.moveTo(padding, y);
    ctx.lineTo(rect.width - padding, y);
    ctx.stroke();

    const val = maxVal - (i / gridLines) * (maxVal - minVal);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
    ctx.font = '10px JetBrains Mono';
    ctx.textAlign = 'right';
    ctx.fillText(formatARS(val, false), padding - 8, y + 3);
  }

  // Draw Smooth Gradient Fill
  ctx.beginPath();
  ctx.moveTo(chartPointsCache[0].x, rect.height - padding);
  ctx.lineTo(chartPointsCache[0].x, chartPointsCache[0].y);

  for (let i = 0; i < chartPointsCache.length - 1; i++) {
    const p0 = chartPointsCache[i];
    const p1 = chartPointsCache[i + 1];
    const mx = (p0.x + p1.x) / 2;
    ctx.bezierCurveTo(mx, p0.y, mx, p1.y, p1.x, p1.y);
  }

  ctx.lineTo(chartPointsCache[chartPointsCache.length - 1].x, rect.height - padding);
  ctx.closePath();

  const fillGradient = ctx.createLinearGradient(0, padding, 0, rect.height - padding);
  fillGradient.addColorStop(0, 'rgba(0, 242, 254, 0.28)');
  fillGradient.addColorStop(0.6, 'rgba(127, 0, 255, 0.12)');
  fillGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
  ctx.fillStyle = fillGradient;
  ctx.fill();

  // Draw Glowing Neon Wave Line
  ctx.beginPath();
  ctx.moveTo(chartPointsCache[0].x, chartPointsCache[0].y);
  for (let i = 0; i < chartPointsCache.length - 1; i++) {
    const p0 = chartPointsCache[i];
    const p1 = chartPointsCache[i + 1];
    const mx = (p0.x + p1.x) / 2;
    ctx.bezierCurveTo(mx, p0.y, mx, p1.y, p1.x, p1.y);
  }

  ctx.strokeStyle = '#00F2FE';
  ctx.lineWidth = 2.5;
  ctx.shadowColor = 'rgba(0, 242, 254, 0.8)';
  ctx.shadowBlur = 12;
  ctx.stroke();
  ctx.shadowBlur = 0; // Reset shadow

  // Draw Nodes
  chartPointsCache.forEach((pt, idx) => {
    const isHovered = idx === canvasHoverIndex;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, isHovered ? 6 : 3, 0, Math.PI * 2);
    ctx.fillStyle = isHovered ? '#FFFFFF' : '#00F2FE';
    ctx.shadowColor = '#00F2FE';
    ctx.shadowBlur = isHovered ? 16 : 6;
    ctx.fill();
    ctx.shadowBlur = 0;
  });
}

// ==========================================================================
// 13. Dynamic Category Donut Chart (Canvas)
// ==========================================================================
function drawDonutChart(categoryExpenses) {
  const canvas = document.getElementById('categoryDonutCanvas');
  const breakdownList = document.getElementById('categoryBreakdownList');
  const totalBadge = document.getElementById('categoryTotalBadge');

  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const width = 180;
  const height = 180;

  canvas.width = width * dpr;
  canvas.height = height * dpr;
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, width, height);

  // Compute total expenses
  let total = 0;
  const slices = [];

  CATEGORIES.expense.forEach(cat => {
    const amt = categoryExpenses[cat.id] || 0;
    if (amt > 0) {
      total += amt;
      slices.push({ ...cat, amount: amt });
    }
  });

  totalBadge.textContent = formatARS(total);

  if (total === 0 || slices.length === 0) {
    // Empty donut circle
    ctx.beginPath();
    ctx.arc(width / 2, height / 2, 60, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 14;
    ctx.stroke();

    breakdownList.innerHTML = '<div class="empty-notice">Sin gastos registrados este mes</div>';
    return;
  }

  // Sort slices descending
  slices.sort((a, b) => b.amount - a.amount);

  // Draw segments
  let startAngle = -Math.PI / 2;
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = 62;

  slices.forEach(slice => {
    const sliceAngle = (slice.amount / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle);
    ctx.strokeStyle = slice.color;
    ctx.lineWidth = 14;
    ctx.stroke();
    startAngle += sliceAngle;
  });

  // Render breakdown list
  breakdownList.innerHTML = '';
  slices.forEach(s => {
    const pct = Math.round((s.amount / total) * 100);
    const row = document.createElement('div');
    row.className = 'cat-breakdown-row';
    row.innerHTML = `
      <div class="cat-info">
        <div class="cat-color-chip" style="background: ${s.color}; box-shadow: 0 0 6px ${s.color}"></div>
        <span>${s.icon} ${s.label}</span>
      </div>
      <div style="text-align: right;">
        <span class="cat-amount">${formatARS(s.amount, false)}</span>
        <span style="font-size: 0.72rem; color: var(--text-dim); margin-left: 6px;">(${pct}%)</span>
      </div>
    `;
    breakdownList.appendChild(row);
  });
}

// ==========================================================================
// 14. Data Backup & Export Systems (JSON / Excel CSV)
// ==========================================================================
function exportBackupJSON() {
  audio.playClick();
  const backupData = {
    version: '2.4',
    currency: 'ARS',
    exportDate: new Date().toISOString(),
    transactions: state.transactions,
    budgets: state.budgets
  };

  const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
  downloadFile(blob, `nexus_finanzas_ars_${getRelativeDateStr(0)}.json`);
  showToast('Copia de respaldo JSON exportada con éxito', 'success');
}

function exportBackupCSV() {
  audio.playClick();
  if (state.transactions.length === 0) {
    showToast('No hay transacciones para exportar', 'info');
    return;
  }

  let csvContent = '\uFEFF'; // UTF-8 BOM for Excel in Spanish
  csvContent += 'ID;Fecha;Tipo;Concepto;Categoria;Metodo;Monto_ARS\n';

  state.transactions.forEach(t => {
    const cleanConcept = (t.concept || '').replace(/;/g, ',');
    csvContent += `${t.id};${t.date};${t.type === 'income' ? 'Ingreso' : 'Gasto'};"${cleanConcept}";${t.category};${t.method || 'General'};${t.amount}\n`;
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  downloadFile(blob, `nexus_movimientos_ars_${getRelativeDateStr(0)}.csv`);
  showToast('Archivo CSV para Excel generado', 'success');
}

function handleImportJSON(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (evt) => {
    try {
      const data = JSON.parse(evt.target.result);
      if (Array.isArray(data.transactions)) {
        state.transactions = data.transactions;
        if (data.budgets) state.budgets = data.budgets;
        saveTransactionsToStorage();
        saveBudgetsToStorage();
        renderAll();
        audio.playIncomeSound();
        showToast(`Respaldo restaurado: ${data.transactions.length} registros cargados`, 'success');
      } else {
        showToast('Formato de archivo inválido: falta matriz de transacciones', 'danger');
      }
    } catch (err) {
      showToast('Error al leer el archivo JSON de respaldo', 'danger');
    }
    e.target.value = '';
  };
  reader.readAsText(file);
}

function downloadFile(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ==========================================================================
// 15. Holographic Toast Notifications
// ==========================================================================
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  let icon = `
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>
    </svg>
  `;
  if (type === 'success') {
    icon = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--neon-green)" stroke-width="2.5">
        <polyline points="20 6 9 17 4 12"/>
      </svg>
    `;
  } else if (type === 'danger') {
    icon = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--neon-red)" stroke-width="2.5">
        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
      </svg>
    `;
  }

  toast.innerHTML = `
    ${icon}
    <span>${message}</span>
  `;

  container.appendChild(toast);

  // Trigger smooth entrance
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  // Auto remove after 3.5s
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 3500);
}

// ==========================================================================
// 16. PWA Service Worker & Mobile Android Support
// ==========================================================================
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js')
      .then(() => console.log('NEXUS Service Worker activo'))
      .catch(err => console.log('SW registration skipped:', err));
  });
}

let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const mobileInstallBtn = document.getElementById('mobileInstallBtn');
  if (mobileInstallBtn) {
    mobileInstallBtn.style.display = 'flex';
  }
});

function triggerMobileInstall() {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult) => {
      if (choiceResult.outcome === 'accepted') {
        showToast('¡NEXUS Finance instalado en tu celular!', 'success');
      }
      deferredPrompt = null;
    });
  } else {
    showToast('Para instalar: abre las opciones de Chrome y pulsa "Instalar aplicación" o "Agregar a pantalla principal"', 'info');
  }
}

