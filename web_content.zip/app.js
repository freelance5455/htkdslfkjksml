const API="https://api.alquran.cloud/v1";
const pages={home:"الرئيسية",quran:"المصحف",bookmarks:"المفضلة",search:"البحث",settings:"الإعدادات",profile:"الملف الشخصي"};
const state={surahs:[],currentSurah:null,audio:null};

const title=document.getElementById("pageTitle");
const list=document.getElementById("surahList");

async function api(path){
  const res=await fetch(API+path);
  if(!res.ok) throw new Error("API "+res.status);
  const json=await res.json();
  return json.data;
}
function showPage(id){
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===id));
  document.querySelectorAll(".tab").forEach(t=>t.classList.toggle("active",t.dataset.page===id));
  title.textContent=pages[id]||"الرئيسية";
  window.scrollTo({top:0,behavior:"smooth"});
}
function toast(msg){
  const t=document.getElementById("toast"); t.textContent=msg; t.classList.add("show");
  clearTimeout(window.tt); window.tt=setTimeout(()=>t.classList.remove("show"),1800);
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

function renderSurahs(data){
  state.surahs=data;
  list.innerHTML=data.map(s=>`
    <button class="surah glass" data-action="surah" data-number="${s.number}">
      <span class="num">${s.number}</span>
      <div><b>${escapeHtml(s.name)}</b><small>${s.revelationType==="Meccan"?"مكية":"مدنية"} • ${s.numberOfAyahs} آية</small></div>
      <span class="arabic">${escapeHtml(s.englishName)}</span>
    </button>`).join("");
}
async function loadSurahs(){
  list.innerHTML='<div class="empty mini glass"><h3>جاري تحميل السور...</h3><p>يتم جلب البيانات من Al Quran Cloud.</p></div>';
  try{renderSurahs(await api("/surah"))}
  catch(e){list.innerHTML='<div class="empty mini glass"><h3>تعذر تحميل السور</h3><p>تحقق من اتصال الإنترنت ثم حاول مرة أخرى.</p></div>'}
}
async function openSurah(number){
  openModal('<h2>جاري التحميل…</h2><p>يتم جلب نص السورة.</p>');
  try{
    const s=await api(`/surah/${number}/quran-uthmani`);
    state.currentSurah=s;
    const ayahs=s.ayahs.map(a=>`<div class="ayah glass"><div class="ayah-meta">${a.numberInSurah}</div><div class="ayah-text">${escapeHtml(a.text)}</div></div>`).join("");
    document.getElementById("modalBody").innerHTML=`
      <h2>${escapeHtml(s.name)}</h2>
      <p>${s.revelationType==="Meccan"?"مكية":"مدنية"} • ${s.numberOfAyahs} آية</p>
      <div class="ayah-list">${ayahs}</div>
      <button class="primary" data-action="recite" data-number="${s.number}">▶ تشغيل التلاوة</button>`;
  }catch(e){document.getElementById("modalBody").innerHTML="<h2>حدث خطأ</h2><p>تعذر تحميل السورة.</p>"}
}
async function searchQuran(q){
  if(!q.trim()){document.getElementById("searchResults").innerHTML='<div class="empty mini"><h3>ابدأ البحث</h3><p>اكتب كلمة للبحث في القرآن.</p></div>';return}
  document.getElementById("searchResults").innerHTML='<div class="empty mini glass"><h3>جاري البحث…</h3></div>';
  try{
    const data=await api(`/search/${encodeURIComponent(q)}/all/quran-uthmani`);
    const matches=(data.ayahs||[]).slice(0,30);
    document.getElementById("searchResults").innerHTML=matches.length
      ? matches.map(a=>`<div class="result glass"><b>${escapeHtml(a.surah.name)} — ${a.numberInSurah}</b><p>${escapeHtml(a.text)}</p></div>`).join("")
      : '<div class="empty mini glass"><h3>لا توجد نتائج</h3><p>جرّب كلمة أخرى.</p></div>';
  }catch(e){document.getElementById("searchResults").innerHTML='<div class="empty mini glass"><h3>تعذر البحث</h3><p>تحقق من اتصال الإنترنت.</p></div>'}
}
async function playSurah(number){
  try{
    const s=await api(`/surah/${number}/ar.alafasy`);
    const first=s.ayahs?.[0];
    if(!first?.audio){toast("لا يوجد صوت متاح");return}
    if(state.audio){state.audio.pause();state.audio=null}
    state.audio=new Audio(first.audio);
    await state.audio.play();
    toast(`تشغيل تلاوة ${s.name} — الآية الأولى`);
  }catch(e){toast("تعذر تشغيل التلاوة")}
}
function openModal(html){document.getElementById("modalBody").innerHTML=html;document.getElementById("modal").classList.add("open")}
function closeModal(){document.getElementById("modal").classList.remove("open")}

document.addEventListener("click",async e=>{
  const page=e.target.closest("[data-page]");
  if(page){showPage(page.dataset.page);return}
  const a=e.target.closest("[data-action]"); if(!a)return;
  const act=a.dataset.action;
  if(act==="profile")showPage("profile");
  if(act==="continue")toast("سيتم استكمال القراءة لاحقًا");
  if(act==="play")toast("اختر سورة لتشغيل التلاوة");
  if(act==="all"){showPage("quran");loadSurahs()}
  if(act==="theme"){document.body.classList.toggle("dark");document.getElementById("themeSwitch").classList.toggle("on",document.body.classList.contains("dark"));toast(document.body.classList.contains("dark")?"الوضع الداكن":"الوضع الفاتح")}
  if(act==="surah")await openSurah(a.dataset.number);
  if(act==="recite")await playSurah(a.dataset.number);
  if(act==="close")closeModal();
});
document.querySelector(".searchbar")?.addEventListener("click",()=>showPage("search"));
document.getElementById("searchInput").addEventListener("input",e=>searchQuran(e.target.value));
loadSurahs();
