const APIS=['https://api.audius.co/v1','https://discoveryprovider.audius.co/v1'];
let activeAPI=0;
const APP='rhythm_music_web';
const audio=document.getElementById('audio');
const $=id=>document.getElementById(id);
let currentTrack=null, queue=[], queueIndex=-1, searchTimer=null, searchToken=0, playToken=0;
function safeLoad(key){try{const v=JSON.parse(localStorage.getItem(key)||'[]');return Array.isArray(v)?v:[]}catch{return []}}
let favorites=safeLoad('rhythm_favorites'), history=safeLoad('rhythm_history');
function persist(key,value){try{localStorage.setItem(key,JSON.stringify(value))}catch{toast('Penyimpanan perangkat penuh')}}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function cover(t){return t.provider==='youtube'?(t.snippet?.thumbnails?.high?.url||t.snippet?.thumbnails?.medium?.url||t.snippet?.thumbnails?.default?.url||'assets/cover-placeholder.svg'):(t.artwork?.['480x480']||t.artwork?.['150x150']||'assets/cover-placeholder.svg')}
function artist(t){return t.provider==='youtube'?(t.snippet?.channelTitle||'YouTube'): (t.user?.name||t.user?.handle||'Kreator independen')}
function duration(t){let n=Math.max(0,Math.floor(Number(t.duration)||0));return n?`${Math.floor(n/60)}:${String(n%60).padStart(2,'0')}`:''}
let youtubeKey=localStorage.getItem('rhythm_youtube_key')||'',ytPlayer=null,ytReady=false,lyricsRows=[],lyricsTimer=null;
function ytSearchUrl(q,pageToken=''){const u=new URL('https://www.googleapis.com/youtube/v3/search');u.searchParams.set('part','snippet');u.searchParams.set('type','video');u.searchParams.set('videoEmbeddable','true');u.searchParams.set('maxResults','25');u.searchParams.set('q',q);u.searchParams.set('regionCode','ID');u.searchParams.set('relevanceLanguage','id');u.searchParams.set('key',youtubeKey);if(pageToken)u.searchParams.set('pageToken',pageToken);return u.toString()}
function loadYouTubeAPI(){if(window.YT?.Player){ytReady=true;return}if(document.querySelector('script[data-yt-api]'))return;const s=document.createElement('script');s.src='https://www.youtube.com/iframe_api';s.dataset.ytApi='1';document.head.appendChild(s);window.onYouTubeIframeAPIReady=()=>{ytReady=true}}
function updateSourceStatus(){$('sourceStatus').textContent=youtubeKey?'Sumber: YouTube • Audius cadangan':'Sumber: Audius • Atur YouTube API untuk aktifkan YouTube'}
async function api(path,timeout=14000){
 let lastError;
 for(let n=0;n<APIS.length;n++){
  const idx=(activeAPI+n)%APIS.length,controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeout);
  try{
   const r=await fetch(`${APIS[idx]}${path}${path.includes('?')?'&':'?'}app_name=${APP}`,{signal:controller.signal,headers:{Accept:'application/json'}});
   if(!r.ok)throw Error('HTTP '+r.status);
   const j=await r.json();activeAPI=idx;return j.data??j;
  }catch(e){lastError=e}finally{clearTimeout(timer)}
 }
 throw lastError||Error('Server musik tidak tersedia');
}
function streamUrl(t){if(t.provider!=='audius')throw Error('Sumber ini tidak menyediakan pemutaran penuh');return `${APIS[activeAPI]}/tracks/${encodeURIComponent(t.id)}/stream?app_name=${APP}`}
function toast(msg){const el=$('toast');if(!el)return;el.textContent=msg;el.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.classList.remove('show'),2600)}
function setView(name){
 document.querySelectorAll('.view').forEach(v=>v.classList.add('hidden'));
 const target=$(name+'View');if(target)target.classList.remove('hidden');
 document.querySelectorAll('.nav[data-view],.mobile-nav [data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
 if(name==='library'){renderList('libraryResults',history);renderKeepListening()}
 if(name==='favorites')renderList('favoriteResults',favorites);
 window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>setView(b.dataset.view)));
document.querySelectorAll('[data-query]').forEach(b=>b.addEventListener('click',()=>{setView('search');$('searchInput').value=b.dataset.query;search(b.dataset.query)}));
let activeTab='all',searchOffset=0,lastQuery='',lastSearchTracks=[];
async function search(q,append=false){
 const token=++searchToken,box=$('searchResults');
 if(!q.trim()){box.innerHTML='<div class="empty-state"><div>⌕</div><h3>Temukan musik</h3><p>Cari judul, artis, atau genre favoritmu.</p></div>';$('searchHeading').textContent='Explore music';$('loadMoreBtn')?.classList.add('hidden');return}
 if(!append){searchOffset=0;lastQuery=q;lastSearchTracks=[];box.innerHTML='<div class="loading-card">Mencari katalog musik…</div>'}
 $('searchHeading').textContent='Songs & Videos';
 try{
  if(youtubeKey && (activeTab==='all'||activeTab==='songs'||activeTab==='videos')){
   const page=append?window.ytNextPageToken||'':'';
   const r=await fetch(ytSearchUrl(q,page));if(!r.ok){const err=await r.json().catch(()=>({}));throw Error(err.error?.message||'YouTube API error '+r.status)}
   const data=await r.json();if(token!==searchToken)return;
   const fresh=(data.items||[]).map(x=>({id:x.id.videoId,videoId:x.id.videoId,title:x.snippet.title,snippet:x.snippet,provider:'youtube',duration:0}));
   if(!append)lastSearchTracks=[];
   lastSearchTracks=[...lastSearchTracks,...fresh];window.ytNextPageToken=data.nextPageToken||'';
   if(!append)box.innerHTML='';
   const frag=document.createElement('div');
   frag.innerHTML=fresh.map((t,i)=>`<div class="track-row"><img src="${esc(cover(t))}" alt="" loading="lazy"><div class="track-info"><b>${esc(t.title)}</b><span>${esc(artist(t))} · YouTube</span></div><button class="row-play" data-search-play="${lastSearchTracks.length-fresh.length+i}" aria-label="Putar">▶</button><button class="row-like" data-search-like="${esc(t.id)}" aria-label="Sukai">♡</button></div>`).join('');
   box.append(...frag.children);
   box.querySelectorAll('[data-search-play]').forEach(b=>b.onclick=()=>playTrack(lastSearchTracks[+b.dataset.searchPlay],lastSearchTracks,+b.dataset.searchPlay));
   box.querySelectorAll('[data-search-like]').forEach(b=>b.onclick=()=>toggleFavorite(lastSearchTracks.find(t=>String(t.id)===b.dataset.searchLike),b));
   $('searchHeading').textContent=`${lastSearchTracks.length} hasil YouTube`;
   $('loadMoreBtn').classList.toggle('hidden',!window.ytNextPageToken);
   queue=lastSearchTracks;updateSourceStatus();
   if(!lastSearchTracks.length)box.innerHTML='<div class="empty-state">Tidak ada video yang cocok.</div>';
   return;
  }
  if(activeTab==='artists'){
   const artists=await api('/users/search?query='+encodeURIComponent(q)+'&limit=30&offset='+searchOffset);
   if(token!==searchToken)return;
   const list=Array.isArray(artists)?artists:[];
   box.innerHTML=list.map(u=>`<div class="artist-row"><img src="${esc(u.profile_picture?.['150x150']||u.profile_picture?.['480x480']||'assets/cover-placeholder.svg')}" alt=""><div><b>${esc(u.name||u.handle||'Artist')}</b><span>@${esc(u.handle||'')}</span></div></div>`).join('')||'<div class="empty-state">Artis tidak ditemukan.</div>';
   $('loadMoreBtn').classList.toggle('hidden',list.length<30);searchOffset+=list.length;return;
  }
  if(activeTab==='albums'){box.innerHTML='<div class="empty-state">Pencarian album Audius belum tersedia. Aktifkan YouTube API untuk mencari video musik.</div>';$('loadMoreBtn').classList.add('hidden');return}
  const tracks=await api('/tracks/search?query='+encodeURIComponent(q)+'&limit=30&offset='+searchOffset);
  if(token!==searchToken)return;
  const valid=(Array.isArray(tracks)?tracks:[]).filter(t=>t&&t.id&&Number(t.duration)>35&&t.is_streamable!==false).map(t=>({...t,provider:'audius'}));
  const seen=new Set(lastSearchTracks.map(t=>(t.title+'|'+artist(t)).toLowerCase()));
  const fresh=valid.filter(t=>{const k=(t.title+'|'+artist(t)).toLowerCase();if(seen.has(k))return false;seen.add(k);return true});
  if(!append)lastSearchTracks=[];
  lastSearchTracks=[...lastSearchTracks,...fresh];if(!append)box.innerHTML='';
  const frag=document.createElement('div');
  frag.innerHTML=fresh.map((t,i)=>`<div class="track-row"><img src="${esc(cover(t))}" alt="" loading="lazy"><div class="track-info"><b>${esc(t.title||'Untitled')}</b><span>${esc(artist(t))} · Audius</span></div><button class="row-play" data-search-play="${lastSearchTracks.length-fresh.length+i}" aria-label="Putar">▶</button><button class="row-like" data-search-like="${esc(t.id)}" aria-label="Sukai">♡</button></div>`).join('');
  box.append(...frag.children);
  box.querySelectorAll('[data-search-play]').forEach(b=>b.onclick=()=>playTrack(lastSearchTracks[+b.dataset.searchPlay],lastSearchTracks,+b.dataset.searchPlay));
  box.querySelectorAll('[data-search-like]').forEach(b=>b.onclick=()=>toggleFavorite(lastSearchTracks.find(t=>String(t.id)===b.dataset.searchLike),b));
  $('searchHeading').textContent=`${lastSearchTracks.length} lagu Audius`;
  $('loadMoreBtn').classList.toggle('hidden',!tracks||tracks.length<30);searchOffset+=tracks.length;queue=lastSearchTracks;
  if(!lastSearchTracks.length)box.innerHTML='<div class="empty-state">Lagu belum ditemukan. Coba judul atau nama artis lain.</div>';
 }catch(e){if(token!==searchToken)return;box.innerHTML=`<div class="empty-state"><div>!</div><h3>Pencarian gagal</h3><p>${esc(e.message||'Koneksi bermasalah')}. Periksa API key atau coba lagi.</p></div>`;console.warn(e)}
}
function renderList(id,tracks){
 const box=$(id);if(!box)return;
 if(!tracks?.length){box.innerHTML='<div class="empty-state"><div>♫</div><h3>Belum ada lagu</h3><p>Track yang kamu simpan akan muncul di sini.</p></div>';return}
 box.innerHTML=tracks.map((t,i)=>`<div class="track-row"><span class="number">${String(i+1).padStart(2,'0')}</span><img src="${esc(cover(t))}" alt="" loading="lazy"><div class="track-info"><b>${esc(t.title||'Untitled')}</b><span>${esc(artist(t))}</span></div><span class="track-duration">${duration(t)}</span><button class="row-play" data-play="${i}" data-list="${id}" aria-label="Putar">▶</button><button class="row-like" data-like="${esc(t.id)}" aria-label="Sukai">${favorites.some(x=>x.id===t.id)?'♥':'♡'}</button></div>`).join('');
 box.querySelectorAll('[data-play]').forEach(b=>b.onclick=()=>{const list=b.dataset.list==='searchResults'?queue:b.dataset.list==='favoriteResults'?favorites:b.dataset.list==='libraryResults'?history:queue;playTrack(list[+b.dataset.play],list,+b.dataset.play)});
 box.querySelectorAll('[data-like]').forEach(b=>b.onclick=()=>toggleFavorite(findTrack(b.dataset.like),b));
}
function findTrack(id){return [...queue,...favorites,...history].find(t=>String(t.id)===String(id))}
function toggleFavorite(t,button){if(!t)return;let idx=favorites.findIndex(x=>x.id===t.id);if(idx>=0)favorites.splice(idx,1);else favorites.unshift(t);persist('rhythm_favorites',favorites);if(button)button.textContent=idx>=0?'♡':'♥';if(!$('favoritesView').classList.contains('hidden'))renderList('favoriteResults',favorites);$('likeCurrent').textContent=currentTrack&&favorites.some(x=>x.id===currentTrack.id)?'♥':'♡'}
async function playTrack(track,list=queue,index=0){
 if(!track)return;const token=++playToken;queue=list;queueIndex=index;currentTrack=track;
 $('playerTitle').textContent=track.title||'Untitled';$('playerArtist').textContent=artist(track)+(track.provider==='youtube'?' · YouTube':' · Audius');$('playerArt').src=cover(track);$('likeCurrent').textContent=favorites.some(x=>x.id===track.id)?'♥':'♡';$('playBtn').textContent='…';
 try{
  if(track.provider==='youtube'){
   audio.pause();audio.removeAttribute('src');audio.load();loadYouTubeAPI();$('youtubeStage').classList.remove('hidden');$('stageTitle').textContent=track.title;
   const start=()=>{if(token!==playToken)return;if(ytPlayer){ytPlayer.loadVideoById(track.videoId);return}ytPlayer=new YT.Player('youtubePlayer',{videoId:track.videoId,width:'100%',height:'100%',playerVars:{playsinline:1,rel:0,cc_load_policy:1,cc_lang_pref:'id'},events:{onReady:e=>e.target.playVideo(),onStateChange:e=>{if(e.data===1)$('playBtn').textContent='Ⅱ';if(e.data===2)$('playBtn').textContent='▶';if(e.data===0)nextTrack()}}})};
   if(window.YT?.Player)start();else{const wait=setInterval(()=>{if(window.YT?.Player){clearInterval(wait);start()}},250);setTimeout(()=>clearInterval(wait),15000)}
  }else{
   $('youtubeStage').classList.add('hidden');if(ytPlayer){try{ytPlayer.stopVideo()}catch{}}
   audio.pause();audio.src=streamUrl(track);audio.load();await audio.play();
  }
  if(token!==playToken)return;
  $('playBtn').textContent='Ⅱ';history=[track,...history.filter(x=>x.id!==track.id)].slice(0,50);persist('rhythm_history',history);renderKeepListening();toast('Memutar: '+track.title);loadLyrics(track);
 }catch(e){if(token!==playToken)return;$('playBtn').textContent='▶';toast('Track tidak dapat diputar. Coba track lain.');console.warn(e)}
}
async function loadLyrics(track){
 $('lyricsTrackTitle').textContent=track.title||'Lirik lagu';
 $('lyricsTrackArtist').textContent=artist(track);
 if(track.provider==='youtube'){
  $('lyricsContent').innerHTML='Gunakan tombol <b>CC</b> pada pemutar YouTube untuk menampilkan subtitle atau lirik jika diunggah oleh pemilik video. Tidak semua video menyediakan lirik.';
 }else{
  $('lyricsContent').textContent='Lirik/subtitle tidak tersedia dari sumber Audius ini.';
 }
}
function syncLyrics(){}
$('searchInput').addEventListener('input',e=>{clearTimeout(searchTimer);$('clearSearch').style.visibility=e.target.value?'visible':'hidden';searchTimer=setTimeout(()=>search(e.target.value),500)});
$('backFromSearch')?.addEventListener('click',()=>setView('home'));
$('clearSearch').onclick=()=>{$('searchInput').value='';$('clearSearch').style.visibility='hidden';search('');$('searchInput').focus()};
$('playBtn').onclick=async()=>{try{if(currentTrack?.provider==='youtube'&&ytPlayer){const s=ytPlayer.getPlayerState();if(s===1)ytPlayer.pauseVideo();else ytPlayer.playVideo();return}if(!audio.src){toast('Cari dan pilih track terlebih dahulu');return}if(audio.paused)await audio.play();else audio.pause()}catch{toast('Pemutaran belum bisa dilanjutkan')}};
audio.onplay=()=>$('playBtn').textContent='Ⅱ';audio.onpause=()=>$('playBtn').textContent='▶';
audio.ontimeupdate=()=>{$('progress').value=audio.duration?audio.currentTime/audio.duration*100:0;$('currentTime').textContent=fmt(audio.currentTime);$('duration').textContent=fmt(audio.duration);syncLyrics()};
audio.onloadedmetadata=()=>{$('duration').textContent=fmt(audio.duration)};
audio.onerror=()=>{if(currentTrack)toast('Stream tidak tersedia untuk track ini. Pilih track lain.')};
audio.onended=()=>nextTrack();
function fmt(n){if(!Number.isFinite(n))return'0:00';return `${Math.floor(n/60)}:${String(Math.floor(n%60)).padStart(2,'0')}`}
$('progress').oninput=e=>{if(currentTrack?.provider==='youtube'&&ytPlayer?.seekTo){const d=ytPlayer.getDuration();if(d)ytPlayer.seekTo(d*e.target.value/100,true)}else if(audio.duration)audio.currentTime=audio.duration*e.target.value/100};$('volume').oninput=e=>audio.volume=+e.target.value;
function nextTrack(){if(queue.length){queueIndex=(queueIndex+1)%queue.length;playTrack(queue[queueIndex],queue,queueIndex)}}
function prevTrack(){if(audio.currentTime>3){audio.currentTime=0;return}if(queue.length){queueIndex=(queueIndex-1+queue.length)%queue.length;playTrack(queue[queueIndex],queue,queueIndex)}}
$('nextBtn').onclick=nextTrack;$('prevBtn').onclick=prevTrack;$('likeCurrent').onclick=()=>toggleFavorite(currentTrack);
function renderKeepListening(){
 const box=$('keepListening');if(!box)return;
 const items=history.slice(0,8);
 box.innerHTML=items.length?items.map((t,i)=>`<button class="keep-card" data-keep="${i}"><img src="${esc(cover(t))}" alt="" loading="lazy"><span>${esc(t.title||'Track')}</span><small>${esc(artist(t))}</small></button>`).join(''):'<div class="empty-state compact">Lagu yang kamu putar akan muncul di sini.</div>';
 box.querySelectorAll('[data-keep]').forEach(b=>b.onclick=()=>playTrack(items[+b.dataset.keep],items,+b.dataset.keep));
}
async function loadPopular(){
 const box=$('popularResults');
 try{
  let tracks=await api('/tracks/trending?time=week&limit=12');
  tracks=(Array.isArray(tracks)?tracks:[]).filter(t=>t&&t.id&&Number(t.duration)>35&&t.is_streamable!==false).map(t=>({...t,provider:'audius'}));
  if(!tracks.length)throw Error('No tracks');
  box.innerHTML=tracks.slice(0,8).map((t,i)=>`<button class="track-card" data-pop="${i}"><img src="${esc(cover(t))}" alt="" loading="lazy"><b>${esc(t.title)}</b><small>${esc(artist(t))}</small></button>`).join('');
  box.querySelectorAll('[data-pop]').forEach(el=>el.onclick=()=>playTrack(tracks[+el.dataset.pop],tracks,+el.dataset.pop));
 }catch(e){box.innerHTML='<div class="loading-card">Rekomendasi belum tersedia. Coba cari musik.</div>';console.warn(e)}
}
loadPopular();renderKeepListening();audio.volume=.8;
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>{
 document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x===b));
 activeTab=b.dataset.tab;searchOffset=0;search($('searchInput').value);
}));
$('loadMoreBtn')?.addEventListener('click',()=>search(lastQuery,true));
$('dismissNotice')?.addEventListener('click',()=>{$('noticeCard').remove()});
$('shuffleBtn')?.addEventListener('click',()=>{if(history.length){const list=[...history].sort(()=>Math.random()-.5);playTrack(list[0],list,0)}else{setView('search');toast('Putar beberapa lagu untuk mengaktifkan acak')}});

$('youtubeSettings').onclick=()=>{$('youtubeApiKey').value=youtubeKey;$('youtubeKeyModal').classList.remove('hidden')};
$('closeYoutubeSettings').onclick=()=>$('youtubeKeyModal').classList.add('hidden');
$('saveYoutubeKey').onclick=()=>{youtubeKey=$('youtubeApiKey').value.trim();if(youtubeKey)localStorage.setItem('rhythm_youtube_key',youtubeKey);else localStorage.removeItem('rhythm_youtube_key');$('youtubeKeyModal').classList.add('hidden');updateSourceStatus();toast(youtubeKey?'YouTube API aktif':'YouTube API key dikosongkan')};
$('clearYoutubeKey').onclick=()=>{$('youtubeApiKey').value='';youtubeKey='';localStorage.removeItem('rhythm_youtube_key');updateSourceStatus();toast('API key dihapus')};
$('lyricsToggle').onclick=()=>{if(!currentTrack){toast('Putar lagu terlebih dahulu');return}if(!$('lyricsContent').textContent||$('lyricsContent').textContent==='Pilih lagu untuk mencari lirik.')loadLyrics(currentTrack);$('lyricsModal').classList.remove('hidden');syncLyrics()};
$('closeLyrics').onclick=()=>$('lyricsModal').classList.add('hidden');
$('lyricsModal').addEventListener('click',e=>{if(e.target===$('lyricsModal'))$('lyricsModal').classList.add('hidden')});
$('videoToggle').onclick=()=>{if(currentTrack?.provider!=='youtube'){toast('Pilih hasil YouTube untuk menampilkan video');return}$('youtubeStage').classList.toggle('hidden')};
$('closeStage').onclick=()=>$('youtubeStage').classList.add('hidden');


function updateGreeting(){const h=new Date().getHours();$('greeting').textContent=h<12?'Good morning':h<18?'Good afternoon':'Good evening'}
updateGreeting();updateSourceStatus();
