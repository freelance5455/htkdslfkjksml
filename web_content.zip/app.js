const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const KEY = "gloryMilitaryPrototypeV1";
const initial = {
  news:[
    {title:"Pembukaan Masa Kadet",category:"RECRUITMENT",date:"COMING SOON",body:"Informasi pembukaan trainee/kadet akan diumumkan melalui pusat informasi."},
    {title:"I-CON Grammy Participation",category:"ANNOUNCEMENT",date:"01.12.26",body:"Gloria Leviana Ackerman berpartisipasi sebagai guest MC/host. Agenda I-CON Grammy berlangsung 9–10 Desember 2026."}
  ],
  events:[
    {title:"I-CON Grammy Awards",category:"PARTICIPATION",date:"09.12.26 – 10.12.26",body:"Partisipasi Glory Military dalam agenda I-CON Grammy Awards 2026."},
    {title:"Open Trainee",category:"RECRUITMENT",date:"COMING SOON",body:"Pembukaan masa kadet baru. Detail menyusul."},
    {title:"Command Meeting",category:"INTERNAL",date:"TO BE ANNOUNCED",body:"Rapat koordinasi dan pembagian tugas organisasi."}
  ],
  achievements:[{title:"Glory Military Established",category:"MILESTONE",date:"2026",body:"Awal perjalanan Glory Military."}],
  clips:[{title:"Clip Archive",category:"MEDIA",date:"ARCHIVE",body:"Tambahkan tautan video clip atau cover di sini."},{title:"Cover Archive",category:"MUSIC",date:"ARCHIVE",body:"Arsip cover vokal, rap, dance, dan performance."}],
  posters:[{title:"I-CON Grammy Participation",category:"EVENT POSTER",date:"2026",body:"Tambahkan tautan gambar poster melalui tombol Tambah poster."},{title:"Open Trainee",category:"RECRUITMENT POSTER",date:"COMING SOON",body:"Arsip poster pembukaan kadet."}],
  applications:[]
};
let data;
try { data = JSON.parse(localStorage.getItem(KEY)) || structuredClone(initial); } catch { data = JSON.parse(JSON.stringify(initial)); }
let activeKind = "";
const save = () => { localStorage.setItem(KEY, JSON.stringify(data)); renderAll(); };
const safe = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const toast = message => { const t=$("#toast"); t.textContent=message; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),2300); };
function go(page){ $$(".page").forEach(p=>p.classList.toggle("active-page",p.id===page)); $$(".nav").forEach(n=>n.classList.toggle("active",n.dataset.page===page)); const nav=$(`.nav[data-page="${page}"]`); $("#pageTitle").textContent=nav?.innerText.trim().replace(/^[^\w]+/,"") || page; $("#sidebar").classList.remove("open"); window.scrollTo({top:0,behavior:"smooth"}); }
$$(".nav").forEach(n=>n.addEventListener("click",()=>go(n.dataset.page)));
$$("[data-go]").forEach(b=>b.addEventListener("click",()=>go(b.dataset.go)));
$("#menuButton").addEventListener("click",()=>$("#sidebar").classList.toggle("open"));

function card(item,kind,index){
 const media = item.url ? `<p class="media-link"><a href="${safe(item.url)}" target="_blank" rel="noopener">BUKA TAUTAN ↗</a></p>` : "";
 const img = item.image ? `<a href="${safe(item.image)}" target="_blank" rel="noopener"><img class="card-image" src="${safe(item.image)}" alt="${safe(item.title)}" loading="lazy"></a>` : "";
 return `<article class="info-card">${img}<div class="card-meta"><span class="tag">${safe(item.category||kind.toUpperCase())}</span><span class="card-date">${safe(item.date||"—")}</span></div><h3>${safe(item.title)}</h3><p>${safe(item.body||"")}</p>${media}<div class="card-actions"><button class="mini-button" data-edit="${kind}:${index}">EDIT</button><button class="mini-button" data-delete="${kind}:${index}">HAPUS</button></div></article>`;
}
function listItem(item,kind,index){return `<div class="list-item"><div class="date-box">${safe(item.date||"—")}</div><div><h4>${safe(item.title)}</h4><p>${safe(item.body||"")}</p></div><span class="tag">${safe(item.category||kind.toUpperCase())}</span><div class="card-actions"><button class="mini-button" data-edit="${kind}:${index}">EDIT</button><button class="mini-button" data-delete="${kind}:${index}">HAPUS</button></div></div>`}
function renderAll(){
 $("#newsList").innerHTML=data.news.map((x,i)=>card(x,"news",i)).join("")||'<div class="empty-state">Belum ada informasi.</div>';
 $("#scheduleList").innerHTML=data.events.map((x,i)=>listItem(x,"events",i)).join("")||'<div class="empty-state">Belum ada jadwal.</div>';
 $("#eventList").innerHTML=data.events.map((x,i)=>card(x,"events",i)).join("")||'<div class="empty-state">Belum ada event.</div>';
 $("#achievementList").innerHTML=data.achievements.map((x,i)=>card(x,"achievements",i)).join("")||'<div class="empty-state">Belum ada pencapaian.</div>';
 $("#clipList").innerHTML=data.clips.map((x,i)=>card(x,"clips",i)).join("")||'<div class="empty-state">Belum ada media.</div>';
 $("#posterList").innerHTML=data.posters.map((x,i)=>card(x,"posters",i)).join("")||'<div class="empty-state">Belum ada poster.</div>';
 $("#applicationList").innerHTML=data.applications.map((x,i)=>card({title:x.name,category:x.division,date:"APPLICATION",body:`Usia: ${x.age}. ${x.experience||""}`},"applications",i)).join("");
 $("#latestNews").innerHTML=data.news.slice(0,3).map(x=>`<div class="list-item"><div class="date-box">INFO</div><div><h4>${safe(x.title)}</h4><p>${safe(x.body)}</p></div><span class="tag">${safe(x.date)}</span></div>`).join("");
 $("#nextEvents").innerHTML=data.events.slice(0,3).map(x=>`<div class="list-item"><div class="date-box">${safe(x.date)}</div><div><h4>${safe(x.title)}</h4><p>${safe(x.body)}</p></div><span class="tag">${safe(x.category)}</span></div>`).join("");
 $("#eventCount").textContent=String(data.events.length).padStart(2,"0");
 $("#newsCount").textContent=String(data.news.length).padStart(2,"0");
 $("#archiveCount").textContent=String(data.clips.length+data.posters.length).padStart(2,"0");
 $$("[data-edit]").forEach(b=>b.addEventListener("click",()=>{const [kind,i]=b.dataset.edit.split(":");openDialog(kind,Number(i));}));
 $$("[data-delete]").forEach(b=>b.addEventListener("click",()=>{const [kind,i]=b.dataset.delete.split(":");if(confirm("Hapus data ini?")){data[kind].splice(Number(i),1);save();toast("Data dihapus.");}}));
}
const fieldDefs={
 news:[["title","Judul","text",true],["category","Kategori","text",true],["date","Tanggal / status","text",true],["body","Isi informasi","textarea",true],["url","Tautan (opsional)","url",false]],
 events:[["title","Nama kegiatan","text",true],["category","Kategori","text",true],["date","Tanggal / status","text",true],["body","Deskripsi","textarea",true],["url","Tautan (opsional)","url",false]],
 achievements:[["title","Nama pencapaian","text",true],["category","Kategori","text",true],["date","Tanggal","text",true],["body","Keterangan","textarea",true],["url","Tautan (opsional)","url",false]],
 clips:[["title","Nama media","text",true],["category","Kategori","text",true],["date","Tanggal / status","text",true],["body","Keterangan","textarea",true],["url","Tautan media (opsional)","url",false],["image","URL thumbnail (opsional)","url",false]],
 posters:[["title","Nama poster","text",true],["category","Jenis poster","text",true],["date","Tanggal / status","text",true],["body","Keterangan","textarea",true],["image","URL gambar poster (opsional)","url",false],["url","Tautan poster (opsional)","url",false]],
 applications:[["name","Nama panggilan","text",true],["age","Usia","number",true],["division","Divisi","text",true],["experience","Pengalaman","textarea",false]]
};
function openDialog(kind,index=null){
 activeKind=kind; const editing=index!==null; const existing=editing?data[kind][index]:{};
 $("#dialogTitle").textContent=(editing?"Edit ":"Tambah ")+({news:"informasi",events:"jadwal/event",achievements:"pencapaian",clips:"media",posters:"poster",applications:"pendaftaran"}[kind]);
 $("#dialogFields").innerHTML=fieldDefs[kind].map(([name,label,type,required])=>`<label>${label}${type==="textarea"?`<textarea name="${name}" rows="3" ${required?"required":""}>${safe(existing[name]||"")}</textarea>`:`<input name="${name}" type="${type}" value="${safe(existing[name]||"")}" ${required?"required":""}>`}</label>`).join("");
 $("#itemDialog").dataset.index=editing?String(index):"";
 $("#itemDialog").showModal();
}
$("#addNews").onclick=()=>openDialog("news");$("#addEvent").onclick=()=>openDialog("events");$("#addMission").onclick=()=>openDialog("events");$("#addAchievement").onclick=()=>openDialog("achievements");$("#addClip").onclick=()=>openDialog("clips");$("#addPoster").onclick=()=>openDialog("posters");
$("#itemForm").addEventListener("submit",e=>{if(e.submitter?.value==="cancel")return;e.preventDefault();const form=new FormData(e.currentTarget);const item={};fieldDefs[activeKind].forEach(([name])=>item[name]=String(form.get(name)||"").trim());const idx=$("#itemDialog").dataset.index;if(idx!=="")data[activeKind][Number(idx)]=item;else data[activeKind].unshift(item);$("#itemDialog").close();save();toast("Data tersimpan di perangkat ini.");});
$("#recruitForm").addEventListener("submit",e=>{e.preventDefault();const f=new FormData(e.currentTarget);data.applications.unshift({name:f.get("name"),age:f.get("age"),division:f.get("division"),experience:f.get("experience")});save();e.currentTarget.reset();toast("Pendaftaran tersimpan di perangkat ini.");});
renderAll();