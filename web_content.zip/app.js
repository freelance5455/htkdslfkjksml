const KEY="clinic_system_v4";
const oldKeys=["clinic_system_v2"];
let state=JSON.parse(localStorage.getItem(KEY)||'null');
if(!state){for(const k of oldKeys){try{const x=JSON.parse(localStorage.getItem(k)||'null');if(x){state=x;break}}catch(e){}}}
state=state||{settings:{clinicName:"نظام العيادة",logo:"",examPrice:10,consultPrice:0,currency:"جنيه"},rates:[],bookings:[],periods:[],operations:[],expenses:[],waitlist:[],patients:[],undo:[]};
state.settings=Object.assign({clinicName:"نظام العيادة",logo:"",examPrice:10,consultPrice:0,currency:"جنيه"},state.settings||{});
state.rates=state.rates||[];state.bookings=state.bookings||[];state.periods=state.periods||[];state.operations=state.operations||[];state.expenses=state.expenses||[];state.waitlist=state.waitlist||[];state.patients=state.patients||[];state.undo=[];
const $=id=>document.getElementById(id); const today=()=>new Date().toISOString().slice(0,10);
const money=n=>Number(n||0).toLocaleString("ar-EG")+" "+(state.settings.currency||"جنيه");
const esc=s=>String(s??"").replace(/[&<>\"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const fmtDate=d=>d?new Date(d+"T00:00:00").toLocaleDateString("ar-EG",{year:"numeric",month:"short",day:"numeric"}):"";
function displayTime(t){if(!t)return"";const m=String(t).match(/^(\d{1,2}):(\d{2})$/);if(!m)return t;let h=+m[1],min=m[2],ap=h<12?"ص":"م";h=h%12||12;return `${h}:${min} ${ap}`}
function timeToMinutes(t){const [h,m]=String(t).split(":").map(Number);return h*60+m}
function snapshot(){const x=JSON.stringify({...state,undo:[]});state.undo=(state.undo||[]).slice(-9);state.undo.push(x)}
function save(){localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));renderAll()}
function commit(fn){snapshot();fn();save()}
function undoLast(){if(!state.undo?.length){alert("لا توجد عملية يمكن التراجع عنها.");return}const x=state.undo.pop();const restored=JSON.parse(x);restored.undo=state.undo;state=restored;localStorage.setItem(KEY,JSON.stringify({...state,undo:[]}));renderAll();alert("تم التراجع عن آخر عملية.")}
function typeName(t){return({exam:"كشف",consult:"استشارة",free_exam:"كشف مجاني",free_consult:"استشارة مجانية"})[t]||t||"-"}
function statusName(s){return({booked:"محجوز",confirmed:"مؤكد",attended:"حضر",noshow:"لم يحضر",canceled:"ألغى"})[s]||s}
function statusBadge(s){return `<span class="badge status-${s}">${statusName(s)}</span>`}
function getPriceForType(type){if(type==="free_exam"||type==="free_consult")return 0;if(type==="exam")return +state.settings.examPrice||0;if(type==="consult")return +state.settings.consultPrice||0;return 0}
function effectiveAmount(b){return Math.max(0,(+b.amount||0)-(+b.discount||0))}
function normalizePeriod(p){if(!p)return;p.slots=(p.slots||[]).map(x=>typeof x==="string"?{time:x,capacity:+p.capacity||5}:{time:x.time,capacity:+x.capacity||5}).filter(x=>x.time);return p}
state.periods.forEach(normalizePeriod);
state.bookings.forEach(b=>{if(!b.attendanceStatus)b.attendanceStatus=b.status==='attended'?'attended':b.status==='canceled'?'canceled':b.status==='noshow'?'noshow':'pending';});

document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
// Keep dynamically rendered action buttons reliable on mobile/WebView.
document.addEventListener('click',e=>{
  const btn=e.target.closest('[data-action]'); if(!btn) return;
  const id=btn.dataset.id||'';
  if(btn.dataset.action==='add') openBookingModal('', '', btn.dataset.period||'', btn.dataset.time||'');
  if(btn.dataset.action==='edit') openBookingModal(id);
  if(btn.dataset.action==='move') openMoveModal(id);
  if(btn.dataset.action==='receipt') receipt(id);
});
function showPage(p){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));document.querySelectorAll(".tab").forEach(x=>x.classList.remove("active"));$("page-"+p)?.classList.add("active");document.querySelector(`[data-page="${p}"]`)?.classList.add("active");renderAll()}
function calcRatePreview(){const a=+$('examCount').value||0,b=+$('examRate').value||0,c=+$('consultCount').value||0,d=+$('consultRate').value||0;$('examTotal').value=a*b;$('consultTotal').value=c*d;$('dayRateTotal').value=a*b+c*d}
function saveRateDay(){const date=$('rateDate').value||today();const rec={id:uid(),date,examCount:+$('examCount').value||0,examRate:+$('examRate').value||0,consultCount:+$('consultCount').value||0,consultRate:+$('consultRate').value||0};commit(()=>{const old=state.rates.find(x=>x.date===date);if(old)Object.assign(old,rec);else state.rates.push(rec)});alert("تم حفظ حساب اليوم.")}
function deleteRate(id){if(confirm("حذف حساب هذا اليوم؟"))commit(()=>state.rates=state.rates.filter(x=>x.id!==id))}
function clearRates(){if(confirm("مسح كل حسابات النسب؟"))commit(()=>state.rates=[])}
function renderRates(){const rs=state.rates;const examCount=rs.reduce((s,r)=>s+(+r.examCount||0),0);const consultCount=rs.reduce((s,r)=>s+(+r.consultCount||0),0);const examAmount=rs.reduce((s,r)=>s+(+r.examCount||0)*(+r.examRate||0),0);const consultAmount=rs.reduce((s,r)=>s+(+r.consultCount||0)*(+r.consultRate||0),0);const total=examAmount+consultAmount;const months=new Set(rs.map(r=>String(r.date||'').slice(0,7)).filter(Boolean)).size;$('rateDaysTotal').textContent=rs.length;$('rateMonthsTotal').textContent=months;$('rateExamCountTotal').textContent=examCount;$('rateExamAmountTotal').textContent=money(examAmount);$('rateConsultCountTotal').textContent=consultCount;$('rateConsultAmountTotal').textContent=money(consultAmount);$('rateGrandTotal').textContent=money(total);$('ratesTable').innerHTML=rs.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(r=>`<tr><td>${fmtDate(r.date)}</td><td>${r.examCount} × ${money(r.examRate)}</td><td>${r.consultCount} × ${money(r.consultRate)}</td><td><b>${money(r.examCount*r.examRate+r.consultCount*r.consultRate)}</b></td><td><button class="danger ghost" onclick="deleteRate('${r.id}')">حذف</button></td></tr>`).join("")||`<tr><td colspan="5" class="empty">لا توجد حسابات.</td></tr>`}

function periodHourOptions(selected="",start=null,end=null){const s=start||$("pStart")?.value||"08:00",e=end||$("pEnd")?.value||"12:00";if(!s||!e||timeToMinutes(s)>=timeToMinutes(e))return `<option value="">اختر الساعة</option>`;const out=[];for(let m=timeToMinutes(s);m<timeToMinutes(e);m+=60){const h=String(Math.floor(m/60)).padStart(2,"0"),mi=String(m%60).padStart(2,"0"),t=`${h}:${mi}`;out.push(`<option value="${t}" ${t===selected?'selected':''}>${displayTime(t)}</option>`)}return `<option value="">اختر الساعة</option>`+out.join("")}
function refreshSlotRows(slots){const box=$("slotRows");if(!box)return;box.innerHTML=(slots||[]).map(x=>`<div class="slot-edit-row"><select class="slot-time">${periodHourOptions(x.time)}</select><input class="slot-capacity" type="number" min="1" value="${+x.capacity||5}" placeholder="عدد الحالات"><button type="button" class="danger ghost" onclick="this.parentElement.remove()">حذف</button></div>`).join("")}
function addSlotRow(){const box=$("slotRows");if(!box)return;const used=new Set([...box.querySelectorAll('.slot-time')].map(x=>x.value).filter(Boolean));const s=$("pStart")?.value||"08:00",e=$("pEnd")?.value||"12:00";let first="";for(let m=timeToMinutes(s);m<timeToMinutes(e);m+=60){const t=`${String(Math.floor(m/60)).padStart(2,"0")}:${String(m%60).padStart(2,"0")}`;if(!used.has(t)){first=t;break}}const row=document.createElement("div");row.className="slot-edit-row";row.innerHTML=`<select class="slot-time">${periodHourOptions(first)}</select><input class="slot-capacity" type="number" min="1" value="5" placeholder="عدد الحالات"><button type="button" class="danger ghost" onclick="this.parentElement.remove()">حذف</button>`;box.appendChild(row)}
function refreshPeriodHourChoices(){document.querySelectorAll('#slotRows .slot-time').forEach(sel=>{const v=sel.value;sel.innerHTML=periodHourOptions(v);if([...sel.options].some(o=>o.value===v))sel.value=v;else sel.value=""})}
function openPeriodModal(id=null){const p=id?normalizePeriod(state.periods.find(x=>x.id===id)):null;$('modalTitle').textContent=p?"تعديل الفترة":"إضافة فترة";$('modalBody').innerHTML=`<div class="form-grid"><label>اسم الفترة<input id="pName" value="${esc(p?.name||"فترة صباحية")}"></label><label>من<input id="pStart" type="time" value="${p?.start||"08:00"}"></label><label>إلى<input id="pEnd" type="time" value="${p?.end||"12:00"}"></label><div class="full"><div class="section-title">الساعات وعدد الحالات</div><div class="muted">حدد الفترة من وإلى، ثم اختر كل ساعة تريد استقبال حالات فيها، وحدد عدد الحالات المسموح بها في هذه الساعة.</div></div><div id="slotRows" class="full"></div><button class="secondary full" onclick="addSlotRow()">＋ إضافة ساعة</button></div><div class="modal-actions"><button class="primary" onclick="savePeriod('${id||""}')">حفظ الفترة</button><button class="ghost" onclick="closeModal()">إلغاء</button>${p?`<button class="danger" onclick="deletePeriod('${p.id}')">حذف</button>`:""}</div>`;$('modal').classList.remove('hidden');refreshSlotRows(p?.slots||[{time:"08:00",capacity:5},{time:"09:00",capacity:5},{time:"10:00",capacity:5},{time:"11:00",capacity:5}]);$('pStart').onchange=refreshPeriodHourChoices;$('pEnd').onchange=refreshPeriodHourChoices}
function savePeriod(id){const name=$('pName').value.trim()||"فترة",start=$('pStart').value,end=$('pEnd').value,slots=[...document.querySelectorAll('#slotRows .slot-edit-row')].map(r=>({time:r.querySelector('.slot-time').value,capacity:Math.max(1,+r.querySelector('.slot-capacity').value||1)})).filter(x=>x.time);slots.sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time));if(!start||!end||!slots.length){alert("أدخل بيانات الفترة وأضف ساعة واحدة على الأقل.");return}if(timeToMinutes(start)>=timeToMinutes(end)){alert("وقت البداية يجب أن يكون قبل وقت النهاية.");return}const seen=new Set();for(const x of slots){if(timeToMinutes(x.time)<timeToMinutes(start)||timeToMinutes(x.time)>=timeToMinutes(end)){alert("كل ساعة يجب أن تكون داخل الفترة المحددة من وإلى.");return}if(seen.has(x.time)){alert("لا يمكن تكرار نفس الساعة.");return}seen.add(x.time)}commit(()=>{const obj={id:id||uid(),name,start,end,slots};if(id)Object.assign(state.periods.find(x=>x.id===id),obj);else state.periods.push(obj)});closeModal();alert("تم حفظ الفترة والساعات وعدد الحالات بنجاح.")}
function deletePeriod(id){if(confirm("حذف الفترة؟ الحجوزات القديمة لن تُحذف.")){commit(()=>state.periods=state.periods.filter(x=>x.id!==id));closeModal()}}
function periodBookings(date,pid,time){return state.bookings.filter(b=>!b.archived&&b.date===date&&b.periodId===pid&&b.time===time&&b.status!=="canceled")}
function getSlot(p,time){return normalizePeriod(p)?.slots.find(x=>x.time===time)}
function renderPeriods(){
  const d=$('bookingDate').value||today();
  const q=($('bookingSearch')?.value||'').trim().toLowerCase();
  const type=$('bookingTypeFilter')?.value||'';
  const status=$('bookingStatusFilter')?.value||'';
  const bookingSerialMap=bookingSerials(d);
  const serial=b=>bookingSerialMap.get(b.id)||'—';
  const actionButtons=b=>`<div class="small-actions"><button class="secondary" data-action="edit" data-id="${b.id}">تعديل</button><button class="ghost" data-action="move" data-id="${b.id}">نقل</button><button class="ghost" data-action="receipt" data-id="${b.id}">إيصال</button></div>`;
  const statusClass=b=>b.status==='attended'?'row-attended':b.status==='noshow'?'row-noshow':b.status==='canceled'?'row-canceled':'';
  const renderedIds=new Set();
  $('periodsList').innerHTML=state.periods.map(p=>{
    normalizePeriod(p);
    const hourSections=(p.slots||[]).map(slot=>{
      const all=state.bookings.filter(b=>!b.archived&&b.date===d&&b.periodId===p.id&&b.time===slot.time).slice().sort((a,b)=>a.createdAt-b.createdAt);
      all.forEach(b=>renderedIds.add(b.id));
      const rows=all.filter(b=>(!q||String(b.name||'').toLowerCase().includes(q)||String(b.phone||'').includes(q))&&(!type||b.type===type)&&(!status||b.status===status));
      const cap=+slot.capacity||0, left=Math.max(0,cap-all.length);
      const stateClass=all.length>=cap?'hour-full':all.length?'hour-busy':'hour-empty';
      const body=rows.map(b=>`<tr class="${statusClass(b)}"><td>${serial(b)}</td><td><strong>${esc(b.name)}</strong></td><td>${esc(b.phone)}</td><td>${typeName(b.type)}</td><td>${money(effectiveAmount(b))}</td><td>${statusBadge(b.status)}</td><td>${b.paid==='no'?'لم يدفع':b.paid==='paid'?'تم الدفع':'مجاني'}</td><td>${actionButtons(b)}</td></tr>`).join('') || `<tr><td colspan="8" class="empty">لا توجد حالات في الساعة ${displayTime(slot.time)}</td></tr>`;
      return `<section class="hour-table-section ${stateClass}">
        <div class="hour-table-head"><div><span class="hour-label">الساعة</span><h4>${displayTime(slot.time)}</h4></div><div class="hour-capacity-table"><b>${all.length} / ${cap}</b><span>${all.length>=cap?'ممتلئة':`متاح ${left} حالة`}</span></div><button class="primary" ${all.length>=cap?'disabled':''} data-action="add" data-period="${p.id}" data-time="${slot.time}">＋ إضافة مريض</button></div>
        <div class="table-wrap hour-table-wrap"><table class="separated-hour-table"><thead><tr><th>م</th><th>اسم المريض</th><th>رقم الهاتف</th><th>النوع</th><th>المبلغ</th><th>الحالة</th><th>الدفع</th><th>الإجراءات</th></tr></thead><tbody>${body}</tbody></table></div>
      </section>`;
    }).join('');
    return `<section class="booking-period-section"><div class="booking-period-head"><div><span class="period-label">فترة العمل</span><h3>${esc(p.name)}</h3><p>${displayTime(p.start)} → ${displayTime(p.end)} · ${p.slots.length} ساعات</p></div><div class="small-actions"><button class="secondary" onclick="openPeriodModal('${p.id}')">تعديل الفترة</button><button class="danger ghost" onclick="deletePeriod('${p.id}')">حذف</button></div></div><div class="booking-hours-stack">${hourSections||'<div class="empty">لا توجد ساعات مضافة لهذه الفترة.</div>'}</div></section>`;
  }).join('');
  // Safety net: never hide a saved booking from the bookings page, even if its period/hour was later edited or removed.
  const orphaned=state.bookings.filter(b=>!b.archived&&b.date===d&&!renderedIds.has(b.id));
  if(orphaned.length){
    const filtered=orphaned.filter(b=>(!q||String(b.name||'').toLowerCase().includes(q)||String(b.phone||'').includes(q))&&(!type||b.type===type)&&(!status||b.status===status));
    const body=filtered.map(b=>`<tr class="${statusClass(b)}"><td>${serial(b)}</td><td><strong>${esc(b.name)}</strong></td><td>${esc(b.phone)}</td><td>${typeName(b.type)}</td><td>${money(effectiveAmount(b))}</td><td>${statusBadge(b.status)}</td><td>${b.paid==='no'?'لم يدفع':b.paid==='paid'?'تم الدفع':'مجاني'}</td><td>${actionButtons(b)}</td></tr>`).join('')||`<tr><td colspan="8" class="empty">لا توجد حالات مطابقة للفلاتر.</td></tr>`;
    $('periodsList').insertAdjacentHTML('beforeend',`<section class="booking-period-section orphan-bookings-section"><div class="booking-period-head"><div><span class="period-label">حجوزات محفوظة</span><h3>حجوزات غير مرتبطة بساعة حالية</h3><p>هذه الحجوزات محفوظة ولن تختفي من سجل الحجوزات.</p></div></div><div class="table-wrap hour-table-wrap"><table class="separated-hour-table"><thead><tr><th>م</th><th>اسم المريض</th><th>رقم الهاتف</th><th>النوع</th><th>المبلغ</th><th>الحالة</th><th>الدفع</th><th>الإجراءات</th></tr></thead><tbody>${body}</tbody></table></div></section>`);
  }
  if(!$('periodsList').innerHTML.trim()) $('periodsList').innerHTML=`<div class="empty">لا توجد فترات. ابدأ بإضافة فترة.</div>`;
}
function updateBookingAmount(){const t=$('bType')?.value;if($('bAmount'))$('bAmount').value=getPriceForType(t);if($('bDiscount'))$('bFinal').textContent=money(Math.max(0,getPriceForType(t)- (+$('bDiscount').value||0)))}
function refreshBookingTimes(preselect=""){const p=state.periods.find(x=>x.id==$('bPeriod')?.value),sel=$('bTime');if(!sel)return;if(!p){sel.innerHTML='<option value="">اختر الفترة أولًا</option>';return}normalizePeriod(p);const date=$('bDate').value||today();sel.innerHTML=p.slots.map(slot=>{const n=periodBookings(date,p.id,slot.time).filter(x=>x.id!==window.editingBookingId).length;return `<option value="${slot.time}" ${slot.time===preselect?'selected':''} ${n>=slot.capacity?'disabled':''}>${displayTime(slot.time)} — ${n}/${slot.capacity}</option>`}).join('')}
function duplicateCheck(phone,date,id){return state.bookings.filter(x=>!x.archived&&x.phone&&phone&&x.phone===phone&&x.date===date&&x.id!==id&&x.status!=="canceled")}
function previousMissedBookings(phone,id){return state.bookings.filter(x=>!x.archived&&x.phone&&phone&&x.phone===phone&&x.id!==id&&(x.status==="noshow"||x.status==="canceled")).sort((a,b)=>b.date.localeCompare(a.date)||b.time.localeCompare(a.time))}
function latestAvailableSlotOnDate(date,excludeId){
  const candidates=[];
  state.periods.forEach(p=>{normalizePeriod(p);(p.slots||[]).forEach(slot=>{
    const used=periodBookings(date,p.id,slot.time).filter(x=>x.id!==excludeId).length;
    if(used<slot.capacity)candidates.push({date,periodId:p.id,time:slot.time});
  })});
  candidates.sort((a,b)=>timeToMinutes(b.time)-timeToMinutes(a.time));
  return candidates[0]||null;
}
function autoRebookSlot(excludeId){
  const t=today();
  return latestAvailableSlotOnDate(t,excludeId)||latestAvailableSlotOnDate(new Date(Date.now()+86400000).toISOString().slice(0,10),excludeId);
}

function openBookingModal(id="",unused="",pid="",time=""){const b=id?state.bookings.find(x=>x.id===id):null,date=b?.date||$('bookingDate').value||today(),periodId=b?.periodId||pid,tm=b?.time||time;window.editingBookingId=id||"";$('modalTitle').textContent=b?"تعديل الحالة":"تسجيل حالة جديدة";const periods=state.periods.map(p=>`<option value="${p.id}" ${p.id===periodId?'selected':''}>${esc(p.name)}</option>`).join('');$('modalBody').innerHTML=`<div class="form-grid"><label>يوم الحجز<input id="bDate" type="date" value="${date}" onchange="refreshBookingTimes()"></label><label>الفترة<select id="bPeriod" onchange="refreshBookingTimes()"><option value="">اختر الفترة</option>${periods}</select></label><label>الساعة<select id="bTime"></select></label><label>الاسم<input id="bName" value="${esc(b?.name||"")}"></label><label>رقم التليفون<input id="bPhone" type="tel" inputmode="tel" value="${esc(b?.phone||"")}" oninput="bookingDuplicateHint()"><span id="duplicateHint" class="hint"></span></label><label>النوع<select id="bType" onchange="updateBookingAmount()">${['exam','consult','free_exam','free_consult'].map(t=>`<option value="${t}" ${(b?.type||'exam')===t?'selected':''}>${typeName(t)}</option>`).join('')}</select></label><label>المبلغ<input id="bAmount" type="number" readonly></label><label>الخصم<input id="bDiscount" type="number" min="0" value="${+b?.discount||0}" oninput="updateBookingAmount()"></label><label>الصافي<div id="bFinal" class="amount-box"></div></label><label>حالة الحجز<select id="bStatus">${[['booked','محجوز'],['confirmed','مؤكد'],['attended','حضر'],['noshow','لم يحضر'],['canceled','ألغى']].map(x=>`<option value="${x[0]}" ${(b?.status||'booked')===x[0]?'selected':''}>${x[1]}</option>`).join('')}</select></label><label>الدفع<select id="bPaid"><option value="no" ${(b?.paid||'no')==='no'?'selected':''}>لم يدفع</option><option value="paid" ${b?.paid==='paid'||b?.paid==='cash'||b?.paid==='transfer'||b?.paid==='card'?'selected':''}>تم الدفع</option><option value="free" ${b?.paid==='free'?'selected':''}>مجاني</option></select></label><label class="full">سبب الإلغاء (اختياري)<input id="bCancelReason" value="${esc(b?.cancelReason||"")}"></label><label class="full">ملاحظات<textarea id="bNotes">${esc(b?.notes||"")}</textarea></label>${b?.history?.length?`<div class="full history"><div class="section-title">سجل نقل الموعد</div>${b.history.slice().reverse().map(h=>`<div class="history-row">${fmtDate(h.from.date)} ${displayTime(h.from.time)} ← ${fmtDate(h.to.date)} ${displayTime(h.to.time)}</div>`).join('')}</div>`:''}</div><div class="modal-actions"><button class="primary" onclick="saveBooking('${id}')">حفظ الحالة</button><button class="ghost" onclick="closeModal()">إلغاء</button>${b?`<button class="danger" onclick="archiveBooking('${b.id}')">أرشفة</button><button class="secondary" data-action="move" data-id="${b.id}">نقل الموعد</button><button class="secondary" data-action="receipt" data-id="${b.id}">إيصال</button>`:''}</div>`;$('modal').classList.remove('hidden');refreshBookingTimes(tm);updateBookingAmount();bookingDuplicateHint()}
function bookingDuplicateHint(){const el=$('duplicateHint');if(!el)return;const phone=$('bPhone').value.trim(),date=$('bDate').value,a=duplicateCheck(phone,date,window.editingBookingId),prev=previousMissedBookings(phone,window.editingBookingId);let msg=a.length?`⚠️ للمريض حجز آخر اليوم (${displayTime(a[0].time)})`:'';if(prev.length)msg+=(msg?' — ':'')+`⚠️ لديه حجز سابق لم يحضر/ألغاه (${fmtDate(prev[0].date)})`;el.textContent=msg}
function saveBooking(id){let date=$('bDate').value,periodId=$('bPeriod').value,time=$('bTime').value,name=$('bName').value.trim(),phone=$('bPhone').value.trim(),type=$('bType').value,status=$('bStatus').value,paid=$('bPaid').value,discount=Math.max(0,+$('bDiscount').value||0),notes=$('bNotes').value.trim(),cancelReason=$('bCancelReason').value.trim();if(!date||!periodId||!time||!name){alert('أكمل التاريخ والفترة والساعة والاسم.');return}const p=state.periods.find(x=>x.id===periodId);normalizePeriod(p);const slot=getSlot(p,time);if(!p||!slot){alert('الساعة غير مسجلة داخل الفترة.');return}const count=periodBookings(date,periodId,time).filter(x=>x.id!==id).length;if(status!=="canceled"&&count>=slot.capacity){alert('هذه الساعة مكتملة حسب السعة المحددة.');return}const old=id?state.bookings.find(x=>x.id===id):null;
  const normalizedPaid=(paid==='cash'||paid==='transfer'||paid==='card')?'paid':paid;
  const bookingNo=old?.bookingNo||(()=>{const nums=state.bookings.filter(x=>!x.archived&&x.date===date&&x.id!==id).map(x=>+x.bookingNo||0);return (nums.length?Math.max(...nums):0)+1})();
  const dup=duplicateCheck(phone,date,id);
  if(dup.length&&!confirm(`تنبيه: ${name} لديه حجز آخر اليوم الساعة ${displayTime(dup[0].time)}. هل تريد المتابعة؟`))return;
  if(!id){
    const previous=previousMissedBookings(phone,id);
    if(previous.length){
      const last=previous[0];
      const next=autoRebookSlot(id);
      const reason=last.status==='noshow'?'لم يحضر':'ألغى الحجز';
      if(next){
        alert(`⚠️ تنبيه: المريض ${name} سبق له الحجز بتاريخ ${fmtDate(last.date)} الساعة ${displayTime(last.time)} لكنه ${reason}.\n\nسيتم تحويل الحجز تلقائيًا إلى آخر ميعاد متاح في العيادة اليوم، وإذا لم يوجد مكان اليوم فإلى آخر ميعاد متاح غدًا.\n\nالموعد الجديد: ${fmtDate(next.date)} — ${displayTime(next.time)}`);
        date=next.date;periodId=next.periodId;time=next.time;
        $('bDate').value=date;$('bPeriod').value=periodId;refreshBookingTimes(time);$('bTime').value=time;
      }else{
        alert(`⚠️ تنبيه: المريض ${name} سبق له الحجز بتاريخ ${fmtDate(last.date)} لكنه ${reason}، ولا يوجد مكان متاح اليوم أو غدًا.`);
      }
    }
  }
  const p2=state.periods.find(x=>x.id===periodId);normalizePeriod(p2);const slot2=getSlot(p2,time);
  if(!slot2){alert('الساعة غير مسجلة داخل الفترة.');return}
  const count2=periodBookings(date,periodId,time).filter(x=>x.id!==id).length;
  if(status!=="canceled"&&count2>=slot2.capacity){alert('هذه الساعة مكتملة حسب السعة المحددة.');return}
  commit(()=>{const obj={id:id||uid(),date,periodId,time,name,phone,type,status,paid:normalizedPaid,amount:normalizedPaid==='free'?0:getPriceForType(type),discount,notes,cancelReason,history:old?.history||[],bookingNo,attendanceStatus:old?.attendanceStatus||(status==='attended'?'attended':'pending'),attendanceNo:old?.attendanceNo||null,createdAt:old?.createdAt||Date.now(),archived:false};if(old&&(old.date!==date||old.time!==time||old.periodId!==periodId))obj.history.push({at:Date.now(),from:{date:old.date,periodId:old.periodId,time:old.time},to:{date,periodId,time}});if(id)Object.assign(old,obj);else state.bookings.push(obj)});$('bookingDate').value=date;$('attendanceDate').value=date;closeModal();renderBookings();renderAttendance();renderHourlyAttendance();}
function archiveBooking(id){if(confirm('أرشفة الحالة بدل حذفها نهائيًا؟')){commit(()=>{const b=state.bookings.find(x=>x.id===id);if(b)b.archived=true});closeModal()}}
function restoreBooking(id){commit(()=>{const b=state.bookings.find(x=>x.id===id);if(b)b.archived=false})}
function deleteBookingPermanent(id){if(confirm('حذف نهائي؟ لا يمكن التراجع عنه إلا من النسخة الاحتياطية.'))commit(()=>state.bookings=state.bookings.filter(x=>x.id!==id))}
function openMoveModal(id){const b=state.bookings.find(x=>x.id===id);if(!b)return;$('modalTitle').textContent='نقل الموعد';$('modalBody').innerHTML=`<div class="form-grid"><label>اليوم الجديد<input id="mDate" type="date" value="${b.date}"></label><label>الفترة<select id="mPeriod">${state.periods.map(p=>`<option value="${p.id}" ${p.id===b.periodId?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label><label class="full">الساعة<select id="mTime"></select></label></div><div class="modal-actions"><button class="primary" onclick="saveMove('${id}')">تأكيد النقل</button><button class="ghost" onclick="closeModal()">إلغاء</button></div>`;$('modal').classList.remove('hidden');refreshMoveTimes(b.time);$('mDate').onchange=()=>refreshMoveTimes('');$('mPeriod').onchange=()=>refreshMoveTimes('')}
function refreshMoveTimes(pre){const p=state.periods.find(x=>x.id==$('mPeriod')?.value),sel=$('mTime');if(!p||!sel)return;const d=$('mDate').value;normalizePeriod(p);sel.innerHTML=p.slots.map(x=>{const n=periodBookings(d,p.id,x.time).filter(b=>b.id!==window.editingBookingId).length;return `<option value="${x.time}" ${x.time===pre?'selected':''} ${n>=x.capacity?'disabled':''}>${displayTime(x.time)} — ${n}/${x.capacity}</option>`}).join('')}
function saveMove(id){const b=state.bookings.find(x=>x.id===id),date=$('mDate').value,pid=$('mPeriod').value,time=$('mTime').value,p=state.periods.find(x=>x.id===pid),slot=getSlot(p,time);if(!b||!date||!pid||!time||!slot){alert('أكمل بيانات النقل.');return}if(periodBookings(date,pid,time).filter(x=>x.id!==id).length>=slot.capacity){alert('الساعة الجديدة مكتملة.');return}commit(()=>{b.history=b.history||[];b.history.push({at:Date.now(),from:{date:b.date,periodId:b.periodId,time:b.time},to:{date,periodId:pid,time}});b.date=date;b.periodId=pid;b.time=time});$('bookingDate').value=date;$('attendanceDate').value=date;closeModal();renderBookings();renderAttendance();renderHourlyAttendance();}
function bookingSerials(date){
  const rows=state.bookings.filter(b=>!b.archived&&b.date===date).slice().sort((a,b)=>{
    const an=+a.bookingNo||0,bn=+b.bookingNo||0;
    return (an&&bn)?an-bn:(an?-1:bn?1:(a.createdAt||0)-(b.createdAt||0));
  });
  const map=new Map();let next=1;
  rows.forEach(b=>{const n=+b.bookingNo||next;map.set(b.id,n);next=Math.max(next,n+1)});
  return map;
}
function attendanceSerials(date){
  const attended=state.bookings.filter(b=>!b.archived&&b.date===date&&b.attendanceStatus==='attended'&&b.attendanceNo!=null).slice().sort((a,b)=>(+a.attendanceNo||0)-(+b.attendanceNo||0));
  const map=new Map();attended.forEach(b=>map.set(b.id,+b.attendanceNo));return map;
}
function attendanceStatusSelect(b){
  const v=b.attendanceStatus||'pending';
  return `<select class="attendance-status-select status-${v}" onchange="setAttendanceStatus('${b.id}',this.value)">
    ${[['pending','في الانتظار'],['attended','حضر'],['noshow','لم يحضر'],['canceled','ألغى']].map(([x,label])=>`<option value="${x}" ${v===x?'selected':''}>${label}</option>`).join('')}
  </select>`;
}
function attendancePaymentSelect(b){
  const v=(b.paid==='cash'||b.paid==='transfer'||b.paid==='card')?'paid':(b.paid||'no');
  return `<select class="attendance-payment-select payment-${v}" onchange="setAttendancePayment('${b.id}',this.value)">
    ${[['no','لم يدفع'],['paid','تم الدفع'],['free','مجاني']].map(([x,label])=>`<option value="${x}" ${v===x?'selected':''}>${label}</option>`).join('')}
  </select>`;
}
function renderAttendance(){
  const d=$('attendanceDate')?.value||today();
  const bookings=state.bookings.filter(b=>!b.archived&&b.date===d).slice().sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time)||(a.createdAt||0)-(b.createdAt||0));
  const bookingSerialMap=bookingSerials(d);
  const serials=attendanceSerials(d);
  const attended=bookings.filter(b=>b.attendanceStatus==='attended');
  $('attBookings').textContent=bookings.length;
  $('attTotal').textContent=attended.length;
  const isFreeType=b=>b.type==='free_exam'||b.type==='free_consult';
  const isExam=b=>b.type==='exam'||b.type==='free_exam';
  const isConsult=b=>b.type==='consult'||b.type==='free_consult';
  const isFreeExam=b=>b.type==='free_exam';
  const isFreeConsult=b=>b.type==='free_consult';
  const required=attended.reduce((sum,b)=>sum+(isFreeType(b)||b.paid==='free'?0:effectiveAmount(b)),0);
  const paid=attended.filter(b=>b.paid==='paid').reduce((sum,b)=>sum+effectiveAmount(b),0);
  const remaining=Math.max(0,required-paid);
  const examAmount=attended.filter(b=>b.type==='exam').reduce((sum,b)=>sum+effectiveAmount(b),0);
  const consultAmount=attended.filter(b=>b.type==='consult').reduce((sum,b)=>sum+effectiveAmount(b),0);
  const freeExamAmount=attended.filter(isFreeExam).reduce((sum,b)=>sum+effectiveAmount(b),0);
  const freeConsultAmount=attended.filter(isFreeConsult).reduce((sum,b)=>sum+effectiveAmount(b),0);
  $('attRequired').textContent=money(required);
  $('attRemaining').textContent=money(remaining);
  $('attExamAmount').textContent=money(examAmount);
  $('attConsultAmount').textContent=money(consultAmount);
  $('attFreeExamAmount').textContent=money(freeExamAmount);
  $('attFreeConsultAmount').textContent=money(freeConsultAmount);
  $('attExam').textContent=attended.filter(isExam).length;
  $('attConsult').textContent=attended.filter(isConsult).length;
  $('attFreeExam').textContent=attended.filter(isFreeExam).length;
  $('attFreeConsult').textContent=attended.filter(isFreeConsult).length;
  const groups={};
  bookings.forEach(b=>(groups[b.time]??=[]).push(b));
  const html=Object.entries(groups).sort((a,b)=>timeToMinutes(a[0])-timeToMinutes(b[0])).map(([time,rows])=>{
    const attendedCount=rows.filter(b=>b.attendanceStatus==='attended').length;
    const body=rows.map(b=>{
      const cls=b.attendanceStatus==='attended'?'attendance-attended':b.attendanceStatus==='noshow'?'attendance-noshow':b.attendanceStatus==='canceled'?'attendance-canceled':'';
      return `<tr class="${cls}">
        <td class="booking-number">${bookingSerialMap.get(b.id)||'—'}</td>
        <td><strong>${esc(b.name)}</strong></td>
        <td>${esc(b.phone)}</td>
        <td class="attendance-number">${serials.get(b.id)||'—'}</td>
        <td>${typeName(b.type)}</td>
        <td>${money(effectiveAmount(b))}</td>
        <td>${attendanceStatusSelect(b)}</td>
        <td>${attendancePaymentSelect(b)}</td>
        <td><div class="small-actions"><button class="secondary" data-action="edit" data-id="${b.id}">تعديل</button><button class="ghost" data-action="receipt" data-id="${b.id}">إيصال</button></div></td>
      </tr>`;
    }).join('');
    return `<section class="attendance-hour-group"><div class="attendance-hour-head"><div><span class="hour-label">الساعة</span><h3>${displayTime(time)}</h3></div><strong>${attendedCount} حضر من ${rows.length}</strong></div><div class="table-wrap"><table class="attendance-hour-table"><thead><tr><th>مسلسل الحجز</th><th>اسم المريض</th><th>رقم الهاتف</th><th>مسلسل الحضور</th><th>النوع</th><th>المبلغ</th><th>الحضور</th><th>الدفع</th><th>إجراء</th></tr></thead><tbody>${body}</tbody></table></div></section>`;
  }).join('');
  $('attendanceGroups').innerHTML=html||`<div class="empty">لا توجد حجوزات لهذا اليوم.</div>`;
}
function setAttendanceStatus(id,v){
  const b=state.bookings.find(x=>x.id===id);if(!b)return;
  commit(()=>{
    const was=b.attendanceStatus;
    b.attendanceStatus=v;
    if(v==='attended' && was!=='attended'){
      const nums=state.bookings.filter(x=>!x.archived&&x.date===b.date&&x.attendanceStatus==='attended'&&x.id!==id).map(x=>+x.attendanceNo||0);
      b.attendanceNo=nums.length?Math.max(...nums)+1:1;
    }else if(v!=='attended'){ b.attendanceNo=null; }
  });
  renderAttendance();renderHourlyAttendance();renderBookings();
}
function setAttendancePayment(id,v){
  const b=state.bookings.find(x=>x.id===id);if(!b)return;
  commit(()=>{
    b.paid=v;
    if(v==='free') b.amount=0;
    else if((+b.amount||0)===0 && !String(b.type||'').startsWith('free_')) b.amount=getPriceForType(b.type);
  });
  renderAttendance();renderBookings();renderReports();
}
function printAttendance(){window.print()}
function renderHourlyAttendance(){
  const d=$('hourlyAttendanceDate')?.value||today(), filter=$('hourlyAttendancePeriod')?.value||'';
  const ps=state.periods||[];const sel=$('hourlyAttendancePeriod');
  if(sel){const old=sel.value;sel.innerHTML='<option value="">كل الفترات</option>'+ps.map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');if(ps.some(p=>p.id===old))sel.value=old;}
  const rows=[];
  ps.filter(p=>!filter||p.id===filter).forEach(p=>{normalizePeriod(p);(p.slots||[]).forEach(slot=>{
    const bs=periodBookings(d,p.id,slot.time);rows.push({time:slot.time,total:bs.length,att:bs.filter(b=>b.attendanceStatus==='attended').length,no:bs.filter(b=>b.attendanceStatus==='noshow').length,cancel:bs.filter(b=>b.attendanceStatus==='canceled').length});
  })});
  rows.sort((a,b)=>timeToMinutes(a.time)-timeToMinutes(b.time));
  $('hourlyAttendanceTable').innerHTML=rows.map(r=>`<tr><td>${displayTime(r.time)}</td><td>${r.total}</td><td>${r.att}</td><td>${r.no}</td><td>${r.cancel}</td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد بيانات.</td></tr>`;
  const totals=rows.reduce((a,r)=>({total:a.total+r.total,att:a.att+r.att,no:a.no+r.no,cancel:a.cancel+r.cancel}),{total:0,att:0,no:0,cancel:0});
  $('hourlyAttendanceFoot').innerHTML=rows.length?`<tr class="total-row"><th>الإجمالي</th><th>${totals.total}</th><th>${totals.att}</th><th>${totals.no}</th><th>${totals.cancel}</th></tr>`:'';
}
function printHourlyAttendance(){window.print()}

function renderBookings(){
  const d=$('bookingDate').value||today();
  const all=state.bookings.filter(x=>!x.archived&&x.date===d);
  $('dayBookings').textContent=all.length;
  $('dayAttended').textContent=all.filter(x=>x.status==='attended').length;
  $('dayNoShow').textContent=all.filter(x=>x.status==='noshow').length;
  $('dayCanceled').textContent=all.filter(x=>x.status==='canceled').length;
  $('dayRevenue').textContent=money(all.filter(x=>x.status==='attended').reduce((s,x)=>s+effectiveAmount(x),0));
  renderPeriods();
}

function renderWaitlist(){const d=$('bookingDate').value||today();$('waitlistTable').innerHTML=state.waitlist.filter(x=>x.date===d).map(w=>`<tr><td>${esc(w.name)}</td><td>${esc(w.phone)}</td><td>${typeName(w.type)}</td><td>${w.time?displayTime(w.time):'أي وقت'}</td><td><button class="primary" onclick="promoteWait('${w.id}')">تحويل لحجز</button><button class="danger ghost" onclick="deleteWait('${w.id}')">حذف</button></td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد قائمة انتظار.</td></tr>`}
function deleteWait(id){commit(()=>state.waitlist=state.waitlist.filter(x=>x.id!==id))}

function openOperationModal(){
 $('modalTitle').textContent='إضافة عملية';$('modalBody').innerHTML=`<div class="form-grid"><label>التاريخ<input id="oDate" type="date" value="${today()}"></label><label>النوع<select id="oType"><option>دخل</option><option>تحصيل</option><option>مرتجع</option><option>أخرى</option></select></label><label class="full">البيان<input id="oDesc"></label><label>المبلغ<input id="oAmount" type="number" min="0"></label></div><div class="modal-actions"><button class="primary" onclick="saveOperation()">حفظ</button><button class="ghost" onclick="closeModal()">إلغاء</button></div>`;$('modal').classList.remove('hidden')}
function saveOperation(){commit(()=>state.operations.push({id:uid(),date:$('oDate').value,type:$('oType').value,desc:$('oDesc').value,amount:+$('oAmount').value||0}));closeModal();alert('تم حفظ العملية.')}
function deleteOperation(id){commit(()=>state.operations=state.operations.filter(x=>x.id!==id))}
function renderOperations(){$('operationsTable').innerHTML=state.operations.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<tr><td>${fmtDate(x.date)}</td><td>${esc(x.type)}</td><td>${esc(x.desc)}</td><td>${money(x.amount)}</td><td><button class="danger ghost" onclick="deleteOperation('${x.id}')">حذف</button></td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد عمليات.</td></tr>`}
function openExpenseModal(){$('modalTitle').textContent='إضافة مصروف';$('modalBody').innerHTML=`<div class="form-grid"><label>التاريخ<input id="eDate" type="date" value="${today()}"></label><label>البند<input id="eItem"></label><label>المبلغ<input id="eAmount" type="number" min="0"></label><label>ملاحظات<input id="eNotes"></label></div><div class="modal-actions"><button class="primary" onclick="saveExpense()">حفظ</button><button class="ghost" onclick="closeModal()">إلغاء</button></div>`;$('modal').classList.remove('hidden')}
function saveExpense(){commit(()=>state.expenses.push({id:uid(),date:$('eDate').value,item:$('eItem').value,amount:+$('eAmount').value||0,notes:$('eNotes').value}));closeModal();alert('تم حفظ المصروف.')}
function deleteExpense(id){commit(()=>state.expenses=state.expenses.filter(x=>x.id!==id))}
function renderExpenses(){const t=state.expenses.reduce((s,x)=>s+x.amount,0);$('expensesTotal').textContent=money(t);$('expensesTable').innerHTML=state.expenses.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(x=>`<tr><td>${fmtDate(x.date)}</td><td>${esc(x.item)}</td><td>${money(x.amount)}</td><td>${esc(x.notes)}</td><td><button class="danger ghost" onclick="deleteExpense('${x.id}')">حذف</button></td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد مصروفات.</td></tr>`}

function renderReports(){const bs=state.bookings.filter(x=>!x.archived),att=bs.filter(x=>x.status==='attended'),rev=att.reduce((s,x)=>s+effectiveAmount(x),0),exp=state.expenses.reduce((s,x)=>s+x.amount,0),rates=state.rates.reduce((s,r)=>s+r.examCount*r.examRate+r.consultCount*r.consultRate,0),ops=state.operations.reduce((s,x)=>s+x.amount,0);$('reportBookings').textContent=bs.length;$('reportAttended').textContent=att.length;$('reportNoShow').textContent=bs.filter(x=>x.status==='noshow').length;$('reportCanceled').textContent=bs.filter(x=>x.status==='canceled').length;$('reportRevenue').textContent=money(rev);$('reportDues').textContent=money(att.filter(x=>x.paid==='no').reduce((s,x)=>s+effectiveAmount(x),0));$('reportRates').textContent=money(rates);$('reportExpenses').textContent=money(exp);$('reportNet').textContent=money(rev+ops-rates-exp);const dates=[...new Set([...bs.map(x=>x.date),...state.rates.map(x=>x.date),...state.expenses.map(x=>x.date)])].sort().reverse();$('dailyReportTable').innerHTML=dates.map(d=>{const a=bs.filter(x=>x.date===d),r=state.rates.find(x=>x.date===d),e=state.expenses.filter(x=>x.date===d).reduce((s,x)=>s+x.amount,0);return `<tr><td>${fmtDate(d)}</td><td>${a.length}</td><td>${a.filter(x=>x.status==='attended').length}</td><td>${a.filter(x=>x.status==='noshow').length}</td><td>${a.filter(x=>x.status==='canceled').length}</td><td>${money(a.filter(x=>x.status==='attended').reduce((s,x)=>s+effectiveAmount(x),0))}</td><td>${money(e)}</td><td>${r?money(r.examCount*r.examRate+r.consultCount*r.consultRate):'—'}</td></tr>`}).join('')||`<tr><td colspan="8" class="empty">لا توجد بيانات.</td></tr>`}

function renderDashboard(){}
function searchPatients(){const q=($('patientSearch').value||'').trim().toLowerCase();const bs=state.bookings.filter(x=>!x.archived&&(!q||x.name.toLowerCase().includes(q)||x.phone.includes(q)));$('patientsTable').innerHTML=bs.sort((a,b)=>b.date.localeCompare(a.date)).slice(0,100).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.phone)}</td><td>${fmtDate(x.date)}</td><td>${displayTime(x.time)}</td><td>${typeName(x.type)}</td><td>${statusBadge(x.status)}</td><td>${money(effectiveAmount(x))}</td><td><button class="secondary" onclick="openBookingModal('${x.id}')">فتح</button></td></tr>`).join('')||`<tr><td colspan="8" class="empty">لا توجد نتائج.</td></tr>`}

function openSettings(){ $('modalTitle').textContent='إعدادات العيادة';$('modalBody').innerHTML=`<div class="form-grid"><label class="full">اسم العيادة<input id="sName" value="${esc(state.settings.clinicName)}"></label><label>سعر الكشف<input id="sExamPrice" type="number" min="0" value="${+state.settings.examPrice||0}"></label><label>سعر الاستشارة<input id="sConsultPrice" type="number" min="0" value="${+state.settings.consultPrice||0}"></label><label>العملة<input id="sCurrency" value="${esc(state.settings.currency||'جنيه')}"></label><label class="full">صورة العيادة/الشعار<input id="sLogo" type="file" accept="image/*"></label></div>${state.settings.logo?`<img class="logo" src="${state.settings.logo}">`:''}<p class="muted">الأسعار تنعكس تلقائيًا في الحجز. المجاني = صفر.</p><div class="modal-actions"><button class="primary" onclick="saveSettings()">حفظ الإعدادات</button><button class="secondary" onclick="backup()">💾 نسخة احتياطية</button><button class="secondary" onclick="document.getElementById('restoreFile').click()">↥ استرجاع نسخة</button><button class="ghost" onclick="closeModal()">إلغاء</button></div>`;$('modal').classList.remove('hidden')}
function saveSettings(){state.settings.clinicName=$('sName').value.trim()||'نظام العيادة';state.settings.examPrice=Math.max(0,+$('sExamPrice').value||0);state.settings.consultPrice=Math.max(0,+$('sConsultPrice').value||0);state.settings.currency=$('sCurrency').value.trim()||'جنيه';const f=$('sLogo').files[0];if(f){const r=new FileReader();r.onload=()=>{commit(()=>state.settings.logo=r.result);closeModal()};r.readAsDataURL(f)}else{commit(()=>{});closeModal()}}
function closeModal(){$('modal').classList.add('hidden')}
function printAttendance(){window.print()}
function printReport(){showPage('reports');setTimeout(()=>window.print(),50)}
function receipt(id){const b=state.bookings.find(x=>x.id===id);if(!b)return;const p=state.periods.find(x=>x.id===b.periodId);const w=window.open('','_blank','width=420,height=600');w.document.write(`<html dir="rtl"><head><title>إيصال</title><style>body{font-family:Tahoma;padding:24px;text-align:center}hr{border:0;border-top:1px solid #ddd;margin:18px 0}.row{display:flex;justify-content:space-between;padding:7px 0}</style></head><body><h2>${esc(state.settings.clinicName)}</h2><h3>إيصال دفع</h3><hr><div class="row"><span>المريض</span><b>${esc(b.name)}</b></div><div class="row"><span>الخدمة</span><b>${typeName(b.type)}</b></div><div class="row"><span>التاريخ</span><b>${fmtDate(b.date)}</b></div><div class="row"><span>الساعة</span><b>${displayTime(b.time)}</b></div><div class="row"><span>الفترة</span><b>${esc(p?.name||'-')}</b></div><div class="row"><span>السعر</span><b>${money(b.amount)}</b></div><div class="row"><span>الخصم</span><b>${money(b.discount)}</b></div><div class="row"><span>الصافي</span><b>${money(effectiveAmount(b))}</b></div><hr><small>شكرًا لزيارتكم</small><script>window.print()</script></body></html>`);w.document.close()}
function exportCSV(){const rows=[['مسلسل','التاريخ','الاسم','الهاتف','الوقت','النوع','المبلغ','الخصم','الصافي','الحالة','الدفع'],...state.bookings.filter(x=>!x.archived).map((b,i)=>[i+1,b.date,b.name,b.phone,displayTime(b.time),typeName(b.type),b.amount,b.discount,effectiveAmount(b),statusName(b.status),b.paid])];const csv='\uFEFF'+rows.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));a.download='clinic-bookings.csv';a.click()}
function backup(){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify({...state,undo:[]},null,2)],{type:'application/json'}));a.download='clinic-backup.json';a.click()}
function restoreBackup(){const f=$('restoreFile').files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x.bookings||!x.periods){alert('ملف غير صالح.');return}if(confirm('استبدال بيانات التطبيق بالنسخة الاحتياطية؟')){state=x;state.undo=[];save();alert('تم الاسترجاع.')}}catch(e){alert('تعذر قراءة النسخة.')}};r.readAsText(f)}
function renderArchive(){const a=state.bookings.filter(x=>x.archived);$('archiveTable').innerHTML=a.map(b=>`<tr><td>${esc(b.name)}</td><td>${esc(b.phone)}</td><td>${fmtDate(b.date)}</td><td>${typeName(b.type)}</td><td><button class="secondary" onclick="restoreBooking('${b.id}')">استرجاع</button><button class="danger ghost" onclick="deleteBookingPermanent('${b.id}')">حذف نهائي</button></td></tr>`).join('')||`<tr><td colspan="5" class="empty">لا توجد حالات مؤرشفة.</td></tr>`}

const ZOOM_KEY='clinic_ui_zoom_v1';
let uiZoom=Number(localStorage.getItem(ZOOM_KEY)||100);
function applyZoom(){
  uiZoom=Math.max(70,Math.min(130,uiZoom));
  document.documentElement.style.setProperty('--ui-zoom',(uiZoom/100).toFixed(2));
  const el=$('zoomLevel'); if(el) el.textContent=uiZoom+'%';
  localStorage.setItem(ZOOM_KEY,String(uiZoom));
}
function changeZoom(delta){uiZoom+=delta;applyZoom()}
function resetZoom(){uiZoom=100;applyZoom()}

function renderAll(){$('clinicTitle').textContent=state.settings.clinicName||'نظام العيادة';['bookingDate','attendanceDate','hourlyAttendanceDate','rateDate'].forEach(id=>{if($(id)&&!$(id).value)$(id).value=today()});calcRatePreview();renderRates();renderBookings();renderWaitlist();renderAttendance();renderHourlyAttendance();renderOperations();renderExpenses();renderReports();renderArchive()}
$('bookingDate').value=today();$('attendanceDate').value=today();$('rateDate').value=today();applyZoom();renderAll();
