// ==================== GÖREV TAKİP UYGULAMASI ====================
const STORAGE_KEY = 'gorevTakip_v4';

// Varsayılan kategoriler
const DEFAULT_CATEGORIES = [
  { id: 'cat1', name: 'Zikirler', color: '#10b981' },
  { id: 'cat2', name: 'Dersler', color: '#3b82f6' },
  { id: 'cat3', name: 'Namazlar', color: '#8b5cf6' }
];

const XP_POINTS = { low: 5, medium: 10, high: 20 };
const LEVEL_NAMES = [
  'Başlangıç', 'Kararlı', 'Düzenli', 'Azimli', 'Disiplinli İnsan',
  'İstikrarlı', 'Kararlı Yolcu', 'Odak Ustası', 'Alışkanlık Mimarı', 'Zirve Yolcusu'
];

const BADGE_DEFS = [
  { id: 'streak7', name: 'İlk 7 günlük seri', icon: '🥉', check: (s) => s.bestStreak >= 7 },
  { id: 'streak30', name: '30 günlük seri', icon: '🥈', check: (s) => s.bestStreak >= 30 },
  { id: 'streak100', name: '100 günlük seri', icon: '🥇', check: (s) => s.bestStreak >= 100 },
  { id: 'tasks100', name: '100 görev tamamlama', icon: '🎯', check: (s) => s.totalCompletions >= 100 },
  { id: 'focus10h', name: '10 saat odaklanma', icon: '📚', check: (s) => s.totalFocusMin >= 600 },
  { id: 'perfectWeek', name: '%100 başarılı hafta', icon: '💯', check: (s) => s.perfectWeek },
  { id: 'habits7', name: '7 gün alışkanlık', icon: '🔥', check: (s) => s.habitStreak >= 7 }
];

let state = {
  tasks: [],
  categories: [...DEFAULT_CATEGORIES],
  habits: [],
  goals: [],
  dailyNotes: {},
  focusLog: [],
  unlockedBadges: [],
  theme: 'dark',
  selectedPriority: 'medium',
  selectedColor: '#3b82f6',
  selectedHistoryDate: null,
  pomodoro: { running: false, remaining: 25 * 60, mode: 'work', taskId: null, timerId: null }
};

// ==================== YARDIMCI FONKSİYONLAR ====================
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function todayStr() {
  // Yerel saate göre bugünün tarihi (UTC değil — TR'de gece 00:00'da gün değişsin)
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function dateToLocalStr(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function formatDateTR(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  const days = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  return `${d.getDate()} ${months[d.getMonth()]} ${days[d.getDay()]}`;
}

function getDayOfWeek(dateStr) {
  return new Date(dateStr + 'T00:00:00').getDay(); // 0=Pazar
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    tasks: state.tasks,
    categories: state.categories,
    habits: state.habits,
    goals: state.goals,
    dailyNotes: state.dailyNotes,
    focusLog: state.focusLog,
    unlockedBadges: state.unlockedBadges,
    theme: state.theme
  }));
}

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      state.tasks = data.tasks || [];
      state.categories = data.categories || [...DEFAULT_CATEGORIES];
      state.habits = data.habits || [];
      state.goals = data.goals || [];
      state.dailyNotes = data.dailyNotes || {};
      state.focusLog = data.focusLog || [];
      state.unlockedBadges = data.unlockedBadges || [];
      state.theme = data.theme || 'dark';
    }
  } catch (e) {
    console.error('State yüklenemedi', e);
  }
  applyTheme();
}

function applyTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  const icon = document.querySelector('#theme-toggle i');
  if (icon) {
    icon.className = state.theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
  }
}

function showToast(msg, duration = 2200) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), duration);
}

// ==================== XP / SERİ / ROZET ====================
function getTaskXp(task) {
  return XP_POINTS[task.priority] || XP_POINTS.medium;
}

function calcTotalXp() {
  let xp = 0;
  state.tasks.forEach(task => {
    const pts = getTaskXp(task);
    (task.completionHistory || []).forEach(h => {
      if (h.completed) xp += pts;
    });
    if (!isRecurring(task) && task.completed) xp += pts;
  });
  // Alışkanlık: her check-in +3
  state.habits.forEach(h => {
    xp += (h.history || []).filter(x => x.done).length * 3;
  });
  // Odak: her 5 dk +1
  state.focusLog.forEach(f => { xp += Math.floor((f.minutes || 0) / 5); });
  return xp;
}

function getLevelInfo(xp) {
  // Her seviye: 100, 200, 300... (kümülatif)
  let level = 1;
  let need = 100;
  let remaining = xp;
  while (remaining >= need) {
    remaining -= need;
    level++;
    need = level * 100;
  }
  const name = LEVEL_NAMES[Math.min(level - 1, LEVEL_NAMES.length - 1)] || `Seviye ${level}`;
  return { level, name, current: remaining, need, xp };
}

function getOverallStreak() {
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = dateToLocalStr(d);
    let total = 0, done = 0;
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds) && !isPostponedOn(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });
    if (total === 0) continue;
    if (done === total) streak++;
    else break;
  }
  return streak;
}

function getTaskStreak(task) {
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = dateToLocalStr(d);
    if (!doesTaskApplyOnDate(task, ds)) continue;
    if (wasTaskCompletedOnDate(task, ds)) streak++;
    else break;
  }
  return streak;
}

function isPostponedOn(task, dateStr) {
  return (task.postponedDates || []).includes(dateStr);
}

function postponeTask(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;
  const today = todayStr();
  if (!task.postponedDates) task.postponedDates = [];
  if (!task.postponedDates.includes(today)) {
    task.postponedDates.push(today);
    // Son 60 gün tut
    if (task.postponedDates.length > 60) task.postponedDates = task.postponedDates.slice(-60);
  }
  saveState();
  renderAll();
  showToast('Görev bugün için ertelendi');
}

function calcDisciplineScore() {
  const today = todayStr();
  // Görev % (40)
  const todayTasks = state.tasks.filter(t => doesTaskApplyOnDate(t, today) && !isPostponedOn(t, today));
  const taskRate = todayTasks.length
    ? todayTasks.filter(t => isTaskCompletedToday(t)).length / todayTasks.length
    : 1;
  // Alışkanlık % (20)
  const habits = state.habits;
  const habitRate = habits.length
    ? habits.filter(h => (h.history || []).some(x => x.date === today && x.done)).length / habits.length
    : 1;
  // Odak (15) — bugün 60dk = full
  const focusToday = state.focusLog
    .filter(f => f.date === today)
    .reduce((s, f) => s + (f.minutes || 0), 0);
  const focusRate = Math.min(focusToday / 60, 1);
  // Hedef (15) — basit: aktif hedef varsa ilerleme
  let goalRate = 1;
  if (state.goals.length) {
    const g = state.goals[0];
    goalRate = Math.min((g.progress || 0) / (g.target || 1), 1);
  }
  // Günlük değerlendirme (10)
  const note = state.dailyNotes[today];
  const eveningRate = note && note.eveningRating ? note.eveningRating / 10 : 0.5;

  const score = Math.round(
    taskRate * 40 + habitRate * 20 + focusRate * 15 + goalRate * 15 + eveningRate * 10
  );
  return Math.min(100, Math.max(0, score));
}

function checkBadges() {
  const stats = {
    bestStreak: getOverallStreak(),
    totalCompletions: 0,
    totalFocusMin: state.focusLog.reduce((s, f) => s + (f.minutes || 0), 0),
    perfectWeek: false,
    habitStreak: 0
  };
  state.tasks.forEach(t => {
    (t.completionHistory || []).forEach(h => { if (h.completed) stats.totalCompletions++; });
  });
  // Haftalık %100
  let weekOk = true;
  for (let i = 0; i < 7; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = dateToLocalStr(d);
    let total = 0, done = 0;
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });
    if (total > 0 && done < total) weekOk = false;
  }
  stats.perfectWeek = weekOk;

  BADGE_DEFS.forEach(b => {
    if (!state.unlockedBadges.includes(b.id) && b.check(stats)) {
      state.unlockedBadges.push(b.id);
      showToast(`${b.icon} Rozet kazandın: ${b.name}`);
    }
  });
}

// ==================== GÖREV MANTIGI ====================
// Tekrarlayan görevlerde tamamlanma GÜNLÜKTÜR.
// Her gün yeniden listede çıkar, dünün tamamlanması bugünü etkilemez.

function isRecurring(task) {
  return task.recurrence && (task.recurrence.type === 'daily' || task.recurrence.type === 'custom');
}

function isTaskForToday(task) {
  const today = todayStr();
  if (isPostponedOn(task, today)) return false;
  const day = getDayOfWeek(today);

  if (!task.recurrence || task.recurrence.type === 'none') {
    // Tek seferlik: sadece dueDate bugünse VEYA tarih yoksa ve henüz tamamlanmamışsa
    if (task.dueDate) return task.dueDate === today;
    return !isOneTimeCompleted(task);
  }

  if (task.recurrence.type === 'daily') return true;

  if (task.recurrence.type === 'custom') {
    return (task.recurrence.days || []).includes(day);
  }

  return false;
}

function isOneTimeCompleted(task) {
  // Tek seferlik görevlerde kalıcı tamamlanma
  if (task.completed) return true;
  if (task.completionHistory && task.completionHistory.some(h => h.completed)) return true;
  return false;
}

function getHistoryEntry(task, dateStr) {
  const date = dateStr || todayStr();
  if (!task.completionHistory) task.completionHistory = [];
  let entry = task.completionHistory.find(h => h.date === date);
  if (!entry) {
    // Sadece bugün için otomatik boş kayıt oluştur (geçmişe yazma)
    if (date === todayStr()) {
      entry = { date, completed: false, subtasks: {} };
      task.completionHistory.push(entry);
    } else {
      return { date, completed: false, subtasks: {} };
    }
  }
  if (!entry.subtasks) entry.subtasks = {};
  return entry;
}

function getTodayHistory(task) {
  return getHistoryEntry(task, todayStr());
}

function isTaskCompletedOnDate(task, dateStr) {
  const date = dateStr || todayStr();
  if (isRecurring(task)) {
    const entry = (task.completionHistory || []).find(h => h.date === date);
    if (!entry) return false;
    if (task.subtasks && task.subtasks.length > 0) {
      return task.subtasks.every(s => entry.subtasks && entry.subtasks[s.id] === true);
    }
    return entry.completed === true;
  }
  // Tek seferlik: dueDate o günse ve tamamlandıysa
  if (task.dueDate && task.dueDate !== date) return false;
  return isOneTimeCompleted(task);
}

function isTaskCompletedToday(task) {
  return isTaskCompletedOnDate(task, todayStr());
}

function getSubtaskProgress(task, dateStr) {
  const date = dateStr || todayStr();
  if (isRecurring(task)) {
    const entry = (task.completionHistory || []).find(h => h.date === date) || { completed: false, subtasks: {} };
    if (!task.subtasks || task.subtasks.length === 0) {
      const done = entry.completed ? 1 : 0;
      return { done, total: 1, percent: entry.completed ? 100 : 0 };
    }
    const subMap = entry.subtasks || {};
    const done = task.subtasks.filter(s => subMap[s.id] === true).length;
    const total = task.subtasks.length;
    return { done, total, percent: total ? Math.round((done / total) * 100) : 0 };
  }

  // Tek seferlik
  if (!task.subtasks || task.subtasks.length === 0) {
    const done = task.completed ? 1 : 0;
    return { done, total: 1, percent: task.completed ? 100 : 0 };
  }
  const done = task.subtasks.filter(s => s.completed).length;
  const total = task.subtasks.length;
  return { done, total, percent: Math.round((done / total) * 100) };
}

function isSubtaskDoneToday(task, subId) {
  return isSubtaskDoneOnDate(task, subId, todayStr());
}

function isSubtaskDoneOnDate(task, subId, dateStr) {
  if (isRecurring(task)) {
    const entry = (task.completionHistory || []).find(h => h.date === dateStr);
    return !!(entry && entry.subtasks && entry.subtasks[subId]);
  }
  const sub = (task.subtasks || []).find(s => s.id === subId);
  return sub ? sub.completed : false;
}

function logCompletion(task, completed) {
  const entry = getTodayHistory(task);
  entry.completed = completed;

  // Tek seferlikte kalıcı bayrağı da güncelle
  if (!isRecurring(task)) {
    task.completed = completed;
    task.completedAt = completed ? new Date().toISOString() : null;
  }

  // Son 90 gün tut
  if (task.completionHistory.length > 90) {
    task.completionHistory = task.completionHistory.slice(-90);
  }
}

function toggleTaskComplete(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  const currentlyDone = isTaskCompletedToday(task);

  if (task.subtasks && task.subtasks.length > 0) {
    // Tüm alt görevleri bugün için tamamla / geri al
    if (isRecurring(task)) {
      const entry = getTodayHistory(task);
      task.subtasks.forEach(s => {
        entry.subtasks[s.id] = !currentlyDone;
      });
      entry.completed = !currentlyDone;
    } else {
      task.subtasks.forEach(s => s.completed = !currentlyDone);
      task.completed = !currentlyDone;
      task.completedAt = task.completed ? new Date().toISOString() : null;
      logCompletion(task, task.completed);
    }
  } else {
    if (isRecurring(task)) {
      logCompletion(task, !currentlyDone);
    } else {
      task.completed = !currentlyDone;
      task.completedAt = task.completed ? new Date().toISOString() : null;
      logCompletion(task, task.completed);
    }
  }

  saveState();
  checkBadges();
  renderAll();
  if (!currentlyDone) {
    const pts = getTaskXp(task);
    showToast(`Görev tamamlandı! +${pts} XP 🎉`);
  }
}

function toggleSubtask(taskId, subId) {
  const task = state.tasks.find(t => t.id === taskId);
  if (!task) return;

  if (isRecurring(task)) {
    const entry = getTodayHistory(task);
    entry.subtasks[subId] = !entry.subtasks[subId];
    // Ana tamamlanma: tüm alt görevler bugün bittiyse
    entry.completed = task.subtasks.every(s => entry.subtasks[s.id] === true);
  } else {
    const sub = task.subtasks.find(s => s.id === subId);
    if (!sub) return;
    sub.completed = !sub.completed;
    task.completed = task.subtasks.every(s => s.completed);
    task.completedAt = task.completed ? new Date().toISOString() : null;
    logCompletion(task, task.completed);
  }

  saveState();
  renderAll();
  if (isTaskCompletedToday(task)) showToast('Tüm alt görevler tamamlandı! 🎉');
}

// ==================== RENDER ====================
function renderAll() {
  renderToday();
  renderAllTasks();
  renderHistory();
  renderCategories();
  renderStats();
  updateHeader();
  populateCategorySelects();
}

function createTaskCardForDate(task, dateStr) {
  // Seçilen tarihe göre tamamlanma durumunu gösteren kart
  const cat = state.categories.find(c => c.id === task.categoryId);
  const progress = getSubtaskProgress(task, dateStr);
  const isCompleted = isTaskCompletedOnDate(task, dateStr);

  const card = document.createElement('div');
  card.className = `task-card priority-${task.priority || 'medium'} ${isCompleted ? 'completed' : ''}`;
  card.dataset.id = task.id;

  let metaHtml = '';
  if (cat) {
    metaHtml += `<span class="category-tag" style="color:${cat.color}">${cat.name}</span>`;
  }
  if (task.dueTime) {
    metaHtml += `<span><i class="far fa-clock"></i> ${task.dueTime}</span>`;
  }
  if (task.recurrence && task.recurrence.type === 'daily') {
    metaHtml += `<span><i class="fas fa-redo"></i> Her gün</span>`;
  } else if (task.recurrence && task.recurrence.type === 'custom') {
    const dayNames = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
    const days = (task.recurrence.days || []).map(d => dayNames[d]).join(', ');
    metaHtml += `<span><i class="fas fa-redo"></i> ${days}</span>`;
  } else if (task.dueDate) {
    metaHtml += `<span><i class="far fa-calendar"></i> ${formatDateTR(task.dueDate)}</span>`;
  }

  let subtasksHtml = '';
  if (task.subtasks && task.subtasks.length > 0) {
    subtasksHtml = `<div class="subtasks">`;
    task.subtasks.forEach(sub => {
      const subDone = isSubtaskDoneOnDate(task, sub.id, dateStr);
      const mark = subDone ? '✓' : '✗';
      const markClass = subDone ? 'done' : 'pending';
      subtasksHtml += `
        <div class="subtask-item ${subDone ? 'completed' : ''}">
          <span class="task-status-mark ${markClass}" style="font-size:1rem;width:22px;">${mark}</span>
          <span>${escapeHtml(sub.title)}</span>
        </div>`;
    });
    subtasksHtml += `</div>
      <div class="task-progress">
        <div class="task-progress-bar">
          <div class="task-progress-fill" style="width:${progress.percent}%"></div>
        </div>
        <div class="task-progress-text">${progress.done}/${progress.total} alt görev (${progress.percent}%)</div>
      </div>`;
  }

  const statusMark = isCompleted
    ? '<span class="task-status-mark done">✓</span>'
    : '<span class="task-status-mark pending">✗</span>';

  card.innerHTML = `
    <div class="task-header">
      ${statusMark}
      <div class="task-info">
        <div class="task-title">${escapeHtml(task.title)}</div>
        <div class="task-meta">${metaHtml}</div>
      </div>
    </div>
    ${subtasksHtml}
  `;

  // Geçmiş tarihte tıklayınca yine düzenleme açılsın
  card.addEventListener('click', () => openTaskModal(task.id));
  return card;
}

function renderHistory() {
  const dateInput = document.getElementById('history-date');
  const container = document.getElementById('history-tasks');
  const empty = document.getElementById('empty-history');
  const summary = document.getElementById('history-day-text');
  if (!dateInput || !container) return;

  if (!state.selectedHistoryDate) {
    state.selectedHistoryDate = todayStr();
  }
  if (dateInput.value !== state.selectedHistoryDate) {
    dateInput.value = state.selectedHistoryDate;
  }

  const dateStr = state.selectedHistoryDate;
  const tasks = state.tasks
    .filter(t => doesTaskApplyOnDate(t, dateStr))
    .sort((a, b) => {
      const aDone = isTaskCompletedOnDate(a, dateStr);
      const bDone = isTaskCompletedOnDate(b, dateStr);
      if (aDone !== bDone) return aDone ? 1 : -1;
      return (a.title || '').localeCompare(b.title || '', 'tr');
    });

  container.innerHTML = '';
  const doneCount = tasks.filter(t => isTaskCompletedOnDate(t, dateStr)).length;
  const total = tasks.length;
  const percent = total ? Math.round((doneCount / total) * 100) : 0;

  if (summary) {
    summary.textContent = `${formatDateTR(dateStr)} — ${doneCount} / ${total} tamamlandı (${percent}%)`;
  }

  if (tasks.length === 0) {
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    tasks.forEach(t => container.appendChild(createTaskCardForDate(t, dateStr)));
  }

  // Odak süresi özeti
  const focusMin = state.focusLog.filter(f => f.date === dateStr).reduce((s, f) => s + (f.minutes || 0), 0);
  if (summary && focusMin > 0) {
    summary.textContent += ` · Odak: ${focusMin} dk`;
  }

  renderCalendar();
}

function renderCalendar() {
  const grid = document.getElementById('calendar-grid');
  if (!grid) return;
  grid.innerHTML = '';
  const selected = state.selectedHistoryDate || todayStr();
  const base = new Date(selected + 'T00:00:00');
  const year = base.getFullYear();
  const month = base.getMonth();
  const first = new Date(year, month, 1);
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  // Pazartesi başlangıç: (getDay()+6)%7
  const startPad = (first.getDay() + 6) % 7;

  ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'].forEach(h => {
    const el = document.createElement('div');
    el.className = 'cal-day head';
    el.textContent = h;
    grid.appendChild(el);
  });

  for (let i = 0; i < startPad; i++) {
    const el = document.createElement('div');
    el.className = 'cal-day empty';
    grid.appendChild(el);
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const ds = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    let total = 0, done = 0;
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });
    const el = document.createElement('div');
    let cls = 'cal-day';
    if (total > 0) {
      const rate = done / total;
      if (rate >= 0.99) cls += ' good';
      else if (rate >= 0.5) cls += ' mid';
      else cls += ' bad';
    }
    if (ds === selected) cls += ' selected';
    el.className = cls;
    el.innerHTML = `<span>${day}</span>`;
    el.addEventListener('click', () => {
      state.selectedHistoryDate = ds;
      renderHistory();
    });
    grid.appendChild(el);
  }
}

function updateHeader() {
  const now = new Date();
  const days = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
  document.getElementById('date-display').textContent =
    `${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}, ${days[now.getDay()]}`;

  const todayTasks = state.tasks.filter(isTaskForToday);
  const completed = todayTasks.filter(t => isTaskCompletedToday(t)).length;

  const total = todayTasks.length;
  const percent = total ? Math.round((completed / total) * 100) : 0;

  document.getElementById('today-progress').style.width = percent + '%';
  document.getElementById('progress-text').textContent = `${completed} / ${total} tamamlandı (${percent}%)`;
  document.getElementById('today-count').textContent = total;
}

function createTaskCard(task, showDate = false) {
  const cat = state.categories.find(c => c.id === task.categoryId);
  const progress = getSubtaskProgress(task);
  const isCompleted = isTaskCompletedToday(task);

  const card = document.createElement('div');
  card.className = `task-card priority-${task.priority || 'medium'} ${isCompleted ? 'completed' : ''}`;
  card.dataset.id = task.id;

  let metaHtml = '';
  if (cat) {
    metaHtml += `<span class="category-tag" style="color:${cat.color}">${cat.name}</span>`;
  }
  if (task.dueTime) {
    metaHtml += `<span><i class="far fa-clock"></i> ${task.dueTime}</span>`;
  }
  if (showDate && task.dueDate && !isRecurring(task)) {
    metaHtml += `<span><i class="far fa-calendar"></i> ${formatDateTR(task.dueDate)}</span>`;
  }
  if (task.recurrence && task.recurrence.type === 'daily') {
    metaHtml += `<span><i class="fas fa-redo"></i> Her gün</span>`;
  } else if (task.recurrence && task.recurrence.type === 'custom') {
    const dayNames = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
    const days = (task.recurrence.days || []).map(d => dayNames[d]).join(', ');
    metaHtml += `<span><i class="fas fa-redo"></i> ${days}</span>`;
  }

  let subtasksHtml = '';
  if (task.subtasks && task.subtasks.length > 0) {
    subtasksHtml = `<div class="subtasks">`;
    task.subtasks.forEach(sub => {
      const subDone = isSubtaskDoneToday(task, sub.id);
      const mark = subDone ? '✓' : '✗';
      const markClass = subDone ? 'done' : 'pending';
      subtasksHtml += `
        <div class="subtask-item ${subDone ? 'completed' : ''}">
          <span class="task-status-mark ${markClass}" style="font-size:1rem;width:22px;">${mark}</span>
          <button class="subtask-check ${subDone ? 'checked' : ''}" data-task="${task.id}" data-sub="${sub.id}">
            <i class="fas fa-check"></i>
          </button>
          <span>${escapeHtml(sub.title)}</span>
        </div>`;
    });
    subtasksHtml += `</div>
      <div class="task-progress">
        <div class="task-progress-bar">
          <div class="task-progress-fill" style="width:${progress.percent}%"></div>
        </div>
        <div class="task-progress-text">${progress.done}/${progress.total} alt görev (${progress.percent}%)</div>
      </div>`;
  }

  const statusMark = isCompleted
    ? '<span class="task-status-mark done">✓</span>'
    : '<span class="task-status-mark pending">✗</span>';

  card.innerHTML = `
    <div class="task-header">
      ${statusMark}
      <button class="task-check ${isCompleted ? 'checked' : ''}" data-id="${task.id}">
        <i class="fas fa-check"></i>
      </button>
      <div class="task-info">
        <div class="task-title">${escapeHtml(task.title)}</div>
        <div class="task-meta">${metaHtml}</div>
      </div>
    </div>
    ${subtasksHtml}
  `;

  // Events
  card.querySelector('.task-check').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleTaskComplete(task.id);
  });

  card.querySelectorAll('.subtask-check').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleSubtask(btn.dataset.task, btn.dataset.sub);
    });
  });

  card.addEventListener('click', (e) => {
    if (e.target.closest('.task-check') || e.target.closest('.subtask-check')) return;
    openTaskModal(task.id);
  });

  return card;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function renderToday() {
  const container = document.getElementById('today-tasks');
  const empty = document.getElementById('empty-today');
  container.innerHTML = '';

  const todayTasks = state.tasks
    .filter(isTaskForToday)
    .sort((a, b) => {
      // Önce tamamlanmayanlar, sonra öncelik, sonra saat
      const aDone = isTaskCompletedToday(a);
      const bDone = isTaskCompletedToday(b);
      if (aDone !== bDone) return aDone ? 1 : -1;
      const prio = { high: 0, medium: 1, low: 2 };
      if ((prio[a.priority] || 1) !== (prio[b.priority] || 1)) return (prio[a.priority] || 1) - (prio[b.priority] || 1);
      return (a.dueTime || '99:99').localeCompare(b.dueTime || '99:99');
    });

  if (todayTasks.length === 0) {
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    todayTasks.forEach(t => container.appendChild(createTaskCard(t)));
  }
  renderTodayExtras();
}

function renderTodayExtras() {
  // XP
  const xp = calcTotalXp();
  const info = getLevelInfo(xp);
  const xpLevel = document.getElementById('xp-level-text');
  const xpBar = document.getElementById('xp-bar');
  const xpSub = document.getElementById('xp-sub-text');
  if (xpLevel) xpLevel.textContent = `Seviye ${info.level} — ${info.name}`;
  if (xpBar) xpBar.style.width = Math.round((info.current / info.need) * 100) + '%';
  if (xpSub) xpSub.textContent = `${info.current} / ${info.need} XP (toplam ${xp})`;

  // Seri
  const streak = getOverallStreak();
  const banner = document.getElementById('streak-banner');
  if (banner) {
    if (streak > 0) {
      banner.classList.remove('hidden');
      banner.textContent = `🔥 ${streak} günlük seridesin. Bugün de tamamlarsan ${streak + 1} güne ulaşacaksın!`;
    } else {
      banner.textContent = 'Bugün tüm görevlerini tamamla, seriyi başlat!';
    }
  }

  // Disiplin
  const disc = document.getElementById('discipline-mini');
  if (disc) disc.textContent = `Disiplin skoru: ${calcDisciplineScore()} / 100`;

  // Odak
  const focusToday = state.focusLog.filter(f => f.date === todayStr()).reduce((s, f) => s + (f.minutes || 0), 0);
  const fs = document.getElementById('focus-summary');
  if (fs) {
    const h = Math.floor(focusToday / 60);
    const m = focusToday % 60;
    fs.textContent = h > 0 ? `Bugün odak: ${h}s ${m}dk` : `Bugün odak: ${m} dk`;
  }

  // Sabah / akşam notları
  const note = state.dailyNotes[todayStr()] || {};
  const g1 = document.getElementById('morning-g1');
  const g2 = document.getElementById('morning-g2');
  const g3 = document.getElementById('morning-g3');
  if (g1) g1.value = note.g1 || '';
  if (g2) g2.value = note.g2 || '';
  if (g3) g3.value = note.g3 || '';
  const er = document.getElementById('evening-rating');
  const eb = document.getElementById('evening-best');
  const ei = document.getElementById('evening-improve');
  if (er) er.value = note.eveningRating || '';
  if (eb) eb.value = note.eveningBest || '';
  if (ei) ei.value = note.eveningImprove || '';

  renderHabits();
}

function renderHabits() {
  const list = document.getElementById('habits-list');
  if (!list) return;
  list.innerHTML = '';
  const today = todayStr();
  if (!state.habits.length) {
    list.innerHTML = '<div style="color:var(--text-muted);font-size:0.85rem;">Henüz alışkanlık yok. + ile ekle.</div>';
    return;
  }
  state.habits.forEach(h => {
    const done = (h.history || []).some(x => x.date === today && x.done);
    const el = document.createElement('div');
    el.className = 'habit-item';
    el.innerHTML = `
      <button class="habit-check ${done ? 'done' : ''}" data-id="${h.id}"><i class="fas fa-check"></i></button>
      <div style="flex:1;">
        <div style="font-weight:600;">${escapeHtml(h.title)}</div>
        <div style="font-size:0.75rem;color:var(--text-muted);">Seri: ${getHabitStreak(h)} gün</div>
      </div>
      <button class="cat-del" data-del-habit="${h.id}" title="Sil">✕</button>
    `;
    el.querySelector('.habit-check').addEventListener('click', () => toggleHabit(h.id));
    el.querySelector('[data-del-habit]').addEventListener('click', (e) => {
      e.stopPropagation();
      if (confirm('Alışkanlığı sil?')) {
        state.habits = state.habits.filter(x => x.id !== h.id);
        saveState();
        renderHabits();
      }
    });
    list.appendChild(el);
  });
}

function getHabitStreak(h) {
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = dateToLocalStr(d);
    if ((h.history || []).some(x => x.date === ds && x.done)) streak++;
    else break;
  }
  return streak;
}

function toggleHabit(id) {
  const h = state.habits.find(x => x.id === id);
  if (!h) return;
  const today = todayStr();
  if (!h.history) h.history = [];
  const existing = h.history.find(x => x.date === today);
  if (existing) existing.done = !existing.done;
  else h.history.push({ date: today, done: true });
  saveState();
  checkBadges();
  renderTodayExtras();
  showToast('Alışkanlık güncellendi');
}

function renderAllTasks() {
  const container = document.getElementById('all-tasks');
  const empty = document.getElementById('empty-all');
  const search = document.getElementById('search-input').value.toLowerCase();
  const catFilter = document.getElementById('category-filter').value;

  container.innerHTML = '';

  let tasks = [...state.tasks];

  if (search) {
    tasks = tasks.filter(t =>
      t.title.toLowerCase().includes(search) ||
      (t.subtasks || []).some(s => s.title.toLowerCase().includes(search))
    );
  }
  if (catFilter !== 'all') {
    tasks = tasks.filter(t => t.categoryId === catFilter);
  }

  tasks.sort((a, b) => {
    const aDone = isTaskCompletedToday(a);
    const bDone = isTaskCompletedToday(b);
    if (aDone !== bDone) return aDone ? 1 : -1;
    return (b.createdAt || '').localeCompare(a.createdAt || '');
  });

  if (tasks.length === 0) {
    empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden');
    tasks.forEach(t => container.appendChild(createTaskCard(t, true)));
  }
}

function renderCategories() {
  const container = document.getElementById('categories-list');
  container.innerHTML = '';

  state.categories.forEach(cat => {
    const count = state.tasks.filter(t => t.categoryId === cat.id).length;
    const card = document.createElement('div');
    card.className = 'category-card';
    card.innerHTML = `
      <button class="cat-del" data-del="${cat.id}" title="Kategoriyi sil">✕</button>
      <div class="color-dot" style="background:${cat.color}"></div>
      <h3>${escapeHtml(cat.name)}</h3>
      <div class="count">${count} görev</div>
    `;
    card.querySelector('.cat-del').addEventListener('click', (e) => {
      e.stopPropagation();
      if (!confirm(`"${cat.name}" kategorisini sil? Görevler silinmez.`)) return;
      state.categories = state.categories.filter(c => c.id !== cat.id);
      saveState();
      renderAll();
      showToast('Kategori silindi');
    });
    card.addEventListener('click', () => {
      document.querySelector('[data-view="all"]').click();
      document.getElementById('category-filter').value = cat.id;
      renderAllTasks();
    });
    container.appendChild(card);
  });
}

function wasTaskCompletedOnDate(task, dateStr) {
  const hist = (task.completionHistory || []).find(h => h.date === dateStr);
  if (!hist) return false;
  if (task.subtasks && task.subtasks.length > 0) {
    // Alt görevler varsa hepsinin o gün tamamlanmış olması lazım
    return task.subtasks.every(s => hist.subtasks && hist.subtasks[s.id] === true);
  }
  return hist.completed === true;
}

function doesTaskApplyOnDate(task, dateStr) {
  const day = getDayOfWeek(dateStr);
  if (!task.recurrence || task.recurrence.type === 'none') {
    return task.dueDate === dateStr;
  }
  if (task.recurrence.type === 'daily') return true;
  if (task.recurrence.type === 'custom') {
    return (task.recurrence.days || []).includes(day);
  }
  return false;
}

function renderStats() {
  const today = todayStr();
  const todayTasks = state.tasks.filter(isTaskForToday);
  const todayDone = todayTasks.filter(t => isTaskCompletedToday(t)).length;
  const todayRate = todayTasks.length ? Math.round((todayDone / todayTasks.length) * 100) : 0;
  document.getElementById('stat-today-rate').textContent = todayRate + '%';

  // Haftalık
  const weekRates = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = dateToLocalStr(d);

    let total = 0, done = 0;
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });
    weekRates.push({ date: ds, day: getDayOfWeek(ds), total, done, rate: total ? Math.round((done / total) * 100) : 0 });
  }

  const weekAvg = weekRates.length
    ? Math.round(weekRates.reduce((s, r) => s + r.rate, 0) / weekRates.length)
    : 0;
  document.getElementById('stat-week-rate').textContent = weekAvg + '%';

  // Aylık (son 30 gün)
  let monthTotal = 0, monthDone = 0;
  for (let i = 0; i < 30; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = dateToLocalStr(d);
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        monthTotal++;
        if (wasTaskCompletedOnDate(task, ds)) monthDone++;
      }
    });
  }
  const monthRate = monthTotal ? Math.round((monthDone / monthTotal) * 100) : 0;
  document.getElementById('stat-month-rate').textContent = monthRate + '%';

  // Streak (ardışık tam başarı günleri)
  let streak = 0;
  for (let i = 0; i < 365; i++) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = dateToLocalStr(d);

    let total = 0, done = 0;
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });
    if (total === 0) {
      // O gün görev yoksa streak bozulmaz, devam et
      continue;
    }
    if (done === total) {
      streak++;
    } else {
      break;
    }
  }
  document.getElementById('stat-streak').textContent = streak;

  // Haftalık chart
  const chart = document.getElementById('weekly-chart');
  chart.innerHTML = '';
  const dayNames = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
  weekRates.forEach(r => {
    const wrap = document.createElement('div');
    wrap.className = 'chart-bar-wrapper';
    const height = Math.max(r.rate, 4);
    wrap.innerHTML = `
      <div class="chart-bar" style="height:${height}%"></div>
      <div class="chart-label">${dayNames[r.day]}</div>
    `;
    chart.appendChild(wrap);
  });

  // History list
  const histList = document.getElementById('history-list');
  histList.innerHTML = '';
  weekRates.slice().reverse().forEach(r => {
    const item = document.createElement('div');
    item.className = 'history-item';
    item.innerHTML = `
      <div>
        <strong>${formatDateTR(r.date)}</strong>
        <div style="font-size:0.8rem;color:var(--text-muted)">${r.done}/${r.total} görev</div>
      </div>
      <div class="rate">${r.rate}%</div>
    `;
    histList.appendChild(item);
  });

  // Kategori istatistik (bugün için)
  const catStats = document.getElementById('category-stats');
  catStats.innerHTML = '';
  const catCounts = {};
  state.tasks.filter(isTaskForToday).forEach(t => {
    if (!catCounts[t.categoryId]) catCounts[t.categoryId] = { total: 0, done: 0 };
    catCounts[t.categoryId].total++;
    if (isTaskCompletedToday(t)) catCounts[t.categoryId].done++;
  });

  state.categories.forEach(cat => {
    const c = catCounts[cat.id] || { total: 0, done: 0 };
    if (c.total === 0) return;
    const percent = Math.round((c.done / c.total) * 100);
    const item = document.createElement('div');
    item.className = 'cat-stat-item';
    item.innerHTML = `
      <div class="dot" style="background:${cat.color}"></div>
      <div style="min-width:70px">${escapeHtml(cat.name)}</div>
      <div class="bar-bg"><div class="bar-fill" style="width:${percent}%;background:${cat.color}"></div></div>
      <div style="min-width:40px;text-align:right;font-size:0.85rem">${percent}%</div>
    `;
    catStats.appendChild(item);
  });

  // Disiplin skoru
  const dsEl = document.getElementById('discipline-score');
  if (dsEl) dsEl.textContent = calcDisciplineScore();

  // Rozetler
  const badgesList = document.getElementById('badges-list');
  if (badgesList) {
    badgesList.innerHTML = '';
    BADGE_DEFS.forEach(b => {
      const unlocked = state.unlockedBadges.includes(b.id);
      const el = document.createElement('div');
      el.className = 'badge-item' + (unlocked ? ' unlocked' : '');
      el.innerHTML = `<span style="font-size:1.4rem;">${b.icon}</span><span>${escapeHtml(b.name)}${unlocked ? '' : ' (kilitli)'}</span>`;
      badgesList.appendChild(el);
    });
  }

  // Hedefler
  const goalsList = document.getElementById('goals-list');
  if (goalsList) {
    goalsList.innerHTML = '';
    if (!state.goals.length) {
      goalsList.innerHTML = '<div style="color:var(--text-muted);font-size:0.85rem;">Henüz hedef yok.</div>';
    } else {
      state.goals.forEach(g => {
        const pct = g.target ? Math.min(100, Math.round(((g.progress || 0) / g.target) * 100)) : 0;
        const el = document.createElement('div');
        el.className = 'goal-item';
        el.innerHTML = `
          <div style="flex:1;">
            <div style="font-weight:600;">${escapeHtml(g.title)}</div>
            <div class="task-progress-bar" style="margin-top:6px;"><div class="task-progress-fill" style="width:${pct}%"></div></div>
            <div style="font-size:0.75rem;color:var(--text-muted);margin-top:4px;">${g.progress || 0} / ${g.target || 0} (${pct}%)</div>
          </div>
          <button class="btn-small" data-goal-plus="${g.id}">+1</button>
          <button class="cat-del" data-goal-del="${g.id}">✕</button>
        `;
        el.querySelector('[data-goal-plus]').addEventListener('click', () => {
          g.progress = (g.progress || 0) + 1;
          saveState();
          renderStats();
        });
        el.querySelector('[data-goal-del]').addEventListener('click', () => {
          if (confirm('Hedefi sil?')) {
            state.goals = state.goals.filter(x => x.id !== g.id);
            saveState();
            renderStats();
          }
        });
        goalsList.appendChild(el);
      });
    }
  }
}

function populateCategorySelects() {
  const selects = [document.getElementById('task-category'), document.getElementById('category-filter')];
  selects.forEach((sel, idx) => {
    if (!sel) return;
    const current = sel.value;
    if (idx === 1) {
      sel.innerHTML = '<option value="all">Tüm Kategoriler</option>';
    } else {
      sel.innerHTML = '';
    }
    state.categories.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.name;
      sel.appendChild(opt);
    });
    if (current) sel.value = current;
  });
}

// ==================== MODAL & FORM ====================
function openTaskModal(taskId = null) {
  const modal = document.getElementById('task-modal');
  const form = document.getElementById('task-form');
  form.reset();
  document.getElementById('subtasks-container').innerHTML = '';
  document.getElementById('days-selector').classList.add('hidden');
  document.getElementById('delete-task-btn').classList.add('hidden');
  document.getElementById('copy-task-btn').classList.add('hidden');
  const postponeBtn = document.getElementById('postpone-task-btn');
  const pomoBtn = document.getElementById('pomodoro-btn');
  const histBlock = document.getElementById('task-history-block');
  if (postponeBtn) postponeBtn.classList.add('hidden');
  if (pomoBtn) pomoBtn.classList.add('hidden');
  if (histBlock) histBlock.classList.add('hidden');
  state.selectedPriority = 'medium';
  updatePriorityButtons();

  if (taskId) {
    const task = state.tasks.find(t => t.id === taskId);
    if (!task) return;
    document.getElementById('modal-title').textContent = 'Görevi Düzenle';
    document.getElementById('task-id').value = task.id;
    document.getElementById('task-title').value = task.title;
    document.getElementById('task-category').value = task.categoryId || '';
    document.getElementById('task-date').value = task.dueDate || '';
    document.getElementById('task-time').value = task.dueTime || '';
    document.getElementById('task-recurrence').value = task.recurrence.type;
    state.selectedPriority = task.priority || 'medium';
    updatePriorityButtons();

    // Tarih alanını tekrarlayan görevlerde gizle
    const dateGroup = document.getElementById('task-date').closest('.form-group');
    if (dateGroup) {
      dateGroup.style.display = (task.recurrence.type === 'daily' || task.recurrence.type === 'custom') ? 'none' : '';
    }

    if (task.recurrence.type === 'custom') {
      document.getElementById('days-selector').classList.remove('hidden');
      document.querySelectorAll('#days-selector input').forEach(cb => {
        cb.checked = (task.recurrence.days || []).includes(parseInt(cb.value));
      });
    } else {
      document.getElementById('days-selector').classList.add('hidden');
    }

    (task.subtasks || []).forEach(sub => addSubtaskInput(sub.title, sub.id));
    document.getElementById('delete-task-btn').classList.remove('hidden');
    document.getElementById('copy-task-btn').classList.remove('hidden');
    if (postponeBtn) postponeBtn.classList.remove('hidden');
    if (pomoBtn) pomoBtn.classList.remove('hidden');

    // Son 30 gün geçmişi
    if (histBlock) {
      histBlock.classList.remove('hidden');
      const bars = document.getElementById('task-history-bars');
      const hint = document.getElementById('task-streak-hint');
      let lines = [];
      let done30 = 0, total30 = 0;
      for (let i = 0; i < 30; i++) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const ds = dateToLocalStr(d);
        if (!doesTaskApplyOnDate(task, ds)) continue;
        total30++;
        const ok = wasTaskCompletedOnDate(task, ds);
        if (ok) done30++;
        lines.push(`${ds.slice(5)} ${ok ? '✓' : '✗'}`);
      }
      if (bars) bars.innerHTML = lines.length
        ? `<div style="margin-bottom:6px;">████ ${total30 ? Math.round(done30 / total30 * 100) : 0}%</div>` + lines.join('<br>')
        : 'Henüz geçmiş yok';
      const st = getTaskStreak(task);
      if (hint) {
        hint.textContent = st > 0
          ? `🔥 ${st} günlük seri. Bugün de yaparsan ${st + 1} güne ulaşacaksın.`
          : 'Bu görevde seri başlatmak için bugün tamamla.';
      }
    }
  } else {
    document.getElementById('modal-title').textContent = 'Yeni Görev';
    document.getElementById('task-id').value = '';
    document.getElementById('task-date').value = todayStr();
    document.getElementById('days-selector').classList.add('hidden');
    const dateGroup = document.getElementById('task-date').closest('.form-group');
    if (dateGroup) dateGroup.style.display = '';
  }

  modal.classList.remove('hidden');
  document.getElementById('task-title').focus();
}

function closeTaskModal() {
  document.getElementById('task-modal').classList.add('hidden');
}

function addSubtaskInput(value = '', id = null) {
  const container = document.getElementById('subtasks-container');
  const row = document.createElement('div');
  row.className = 'subtask-input-row';
  row.innerHTML = `
    <input type="text" placeholder="Alt görev..." value="${escapeHtml(value)}" data-id="${id || ''}">
    <button type="button" class="remove-sub"><i class="fas fa-times"></i></button>
  `;
  row.querySelector('.remove-sub').addEventListener('click', () => row.remove());
  container.appendChild(row);
}

function updatePriorityButtons() {
  document.querySelectorAll('.priority-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.priority === state.selectedPriority);
  });
}

function handleTaskSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('task-id').value;
  const title = document.getElementById('task-title').value.trim();
  if (!title) return;

  const recurrenceType = document.getElementById('task-recurrence').value;
  let days = [];
  if (recurrenceType === 'custom') {
    document.querySelectorAll('#days-selector input:checked').forEach(cb => {
      days.push(parseInt(cb.value));
    });
    if (days.length === 0) {
      showToast('En az bir gün seçmelisin');
      return;
    }
  }

  const subtasks = [];
  document.querySelectorAll('#subtasks-container input').forEach(input => {
    const t = input.value.trim();
    if (t) {
      subtasks.push({
        id: input.dataset.id || generateId(),
        title: t,
        completed: false
      });
    }
  });

  // Mevcut alt görev tamamlanma durumlarını koru
  if (id) {
    const oldTask = state.tasks.find(t => t.id === id);
    if (oldTask && oldTask.subtasks) {
      subtasks.forEach(s => {
        const old = oldTask.subtasks.find(os => os.id === s.id);
        if (old) s.completed = old.completed;
      });
    }
  }

  // Tekrarlayan görevlerde tarih gerekmez
  const dueDate = (recurrenceType === 'daily' || recurrenceType === 'custom')
    ? null
    : (document.getElementById('task-date').value || null);

  const oldTask = id ? state.tasks.find(t => t.id === id) : null;

  const taskData = {
    id: id || generateId(),
    title,
    categoryId: document.getElementById('task-category').value || state.categories[0]?.id,
    dueDate,
    dueTime: document.getElementById('task-time').value || null,
    priority: state.selectedPriority,
    recurrence: { type: recurrenceType, days },
    subtasks,
    completed: oldTask ? oldTask.completed : false,
    completedAt: oldTask ? oldTask.completedAt : null,
    createdAt: oldTask ? oldTask.createdAt : new Date().toISOString(),
    completionHistory: oldTask ? (oldTask.completionHistory || []) : []
  };

  if (id) {
    const idx = state.tasks.findIndex(t => t.id === id);
    state.tasks[idx] = taskData;
    showToast('Görev güncellendi');
  } else {
    state.tasks.unshift(taskData);
    showToast('Görev eklendi ✨');
  }

  saveState();
  closeTaskModal();
  renderAll();
}

function deleteTask() {
  const id = document.getElementById('task-id').value;
  if (!id || !confirm('Bu görevi silmek istediğine emin misin?')) return;
  state.tasks = state.tasks.filter(t => t.id !== id);
  saveState();
  closeTaskModal();
  renderAll();
  showToast('Görev silindi');
}

function copyTask() {
  // Mevcut formu "yeni görev" moduna çevir — id temizlenir, geçmiş sıfırlanır
  document.getElementById('task-id').value = '';
  document.getElementById('modal-title').textContent = 'Görevi Kopyala (Yeni)';
  document.getElementById('delete-task-btn').classList.add('hidden');
  document.getElementById('copy-task-btn').classList.add('hidden');

  // Başlığa "(kopya)" ekle ki ayırt edilebilsin
  const titleInput = document.getElementById('task-title');
  if (titleInput.value && !titleInput.value.includes('(kopya)')) {
    titleInput.value = titleInput.value + ' (kopya)';
  }

  // Alt görev id'lerini temizle (yeni id üretilsin)
  document.querySelectorAll('#subtasks-container input').forEach(input => {
    input.dataset.id = '';
  });

  showToast('Görev kopyalandı — istediğini değiştirip Kaydet\'e bas');
  titleInput.focus();
  titleInput.select();
}

// ==================== EXCEL RAPOR ====================
function generateExcelReport(period) {
  if (typeof XLSX === 'undefined') {
    showToast('Excel kütüphanesi yüklenemedi');
    return;
  }

  const today = new Date();
  let startDate, endDate, title, periodLabel;

  if (period === 'week') {
    const day = today.getDay();
    const diff = day === 0 ? 6 : day - 1;
    startDate = new Date(today);
    startDate.setDate(today.getDate() - diff);
    endDate = new Date(startDate);
    endDate.setDate(startDate.getDate() + 6);
    title = 'Haftalık Rapor';
    periodLabel = 'haftalik';
  } else if (period === 'month') {
    startDate = new Date(today.getFullYear(), today.getMonth(), 1);
    endDate = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    title = 'Aylık Rapor';
    periodLabel = 'aylik';
  } else {
    startDate = new Date(today.getFullYear(), 0, 1);
    endDate = new Date(today.getFullYear(), 11, 31);
    title = 'Yıllık Rapor';
    periodLabel = 'yillik';
  }

  const startStr = dateToLocalStr(startDate);
  const endStr = dateToLocalStr(endDate);
  const dayNamesFull = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
  const dayNamesShort = ['Paz', 'Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt'];
  const months = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];

  // ---------- yardımcılar ----------
  function dayStats(ds) {
    let total = 0, done = 0;
    state.tasks.forEach(task => {
      if (doesTaskApplyOnDate(task, ds)) {
        total++;
        if (wasTaskCompletedOnDate(task, ds)) done++;
      }
    });
    const focus = state.focusLog.filter(f => f.date === ds).reduce((s, f) => s + (f.minutes || 0), 0);
    const habitsTotal = state.habits.length;
    const habitsDone = state.habits.filter(h => (h.history || []).some(x => x.date === ds && x.done)).length;
    return { total, done, focus, habitsTotal, habitsDone, rate: total ? Math.round((done / total) * 100) : 0 };
  }

  function styleHeaderRow(ws, rowIndex, colCount) {
    if (!ws['!rows']) ws['!rows'] = [];
    ws['!rows'][rowIndex] = { hpt: 22 };
  }

  // ========== 1) ÖZET DASHBOARD ==========
  let grandTotal = 0, grandDone = 0, focusTotal = 0, activeDays = 0, perfectDays = 0;
  let current = new Date(startDate);
  while (current <= endDate) {
    const st = dayStats(dateToLocalStr(current));
    grandTotal += st.total;
    grandDone += st.done;
    focusTotal += st.focus;
    if (st.total > 0) {
      activeDays++;
      if (st.done === st.total) perfectDays++;
    }
    current.setDate(current.getDate() + 1);
  }
  const overallRate = grandTotal ? Math.round((grandDone / grandTotal) * 100) : 0;
  const focusH = Math.floor(focusTotal / 60);
  const focusM = focusTotal % 60;
  const xp = calcTotalXp();
  const level = getLevelInfo(xp);
  const discipline = calcDisciplineScore();
  const streak = getOverallStreak();

  const dash = [];
  dash.push(['GÖREV TAKİP — ' + title.toUpperCase()]);
  dash.push(['Dönem', formatDateTR(startStr) + '  →  ' + formatDateTR(endStr)]);
  dash.push(['Rapor tarihi', new Date().toLocaleString('tr-TR')]);
  dash.push([]);
  dash.push(['GENEL İSTATİSTİKLER']);
  dash.push(['Metrik', 'Değer']);
  dash.push(['Toplam görev kaydı', grandTotal]);
  dash.push(['Tamamlanan', grandDone]);
  dash.push(['Eksik', grandTotal - grandDone]);
  dash.push(['Başarı oranı', overallRate + ' %']);
  dash.push(['Aktif gün sayısı', activeDays]);
  dash.push(['Tam başarı günü (%100)', perfectDays]);
  dash.push(['Mevcut seri (gün)', streak]);
  dash.push(['Disiplin skoru (bugün)', discipline + ' / 100']);
  dash.push(['Toplam odak süresi', (focusH ? focusH + ' saat ' : '') + focusM + ' dk']);
  dash.push(['Seviye', level.level + ' — ' + level.name]);
  dash.push(['Toplam XP', xp]);
  dash.push([]);
  dash.push(['KATEGORİ BAZLI BAŞARI']);
  dash.push(['Kategori', 'Uygulanan', 'Tamamlanan', 'Başarı %']);

  state.categories.forEach(cat => {
    let t = 0, d = 0;
    let cur = new Date(startDate);
    while (cur <= endDate) {
      const ds = dateToLocalStr(cur);
      state.tasks.filter(task => task.categoryId === cat.id).forEach(task => {
        if (doesTaskApplyOnDate(task, ds)) {
          t++;
          if (wasTaskCompletedOnDate(task, ds)) d++;
        }
      });
      cur.setDate(cur.getDate() + 1);
    }
    if (t > 0) dash.push([cat.name, t, d, Math.round((d / t) * 100) + ' %']);
  });

  // ========== 2) GÜNLÜK ÖZET TABLOSU ==========
  const summaryRows = [];
  summaryRows.push(['GÜNLÜK ÖZET TABLOSU']);
  summaryRows.push([]);
  summaryRows.push([
    'Tarih', 'Gün', 'Toplam Görev', 'Tamamlanan', 'Eksik',
    'Başarı %', 'Odak (dk)', 'Alışkanlık', 'Not'
  ]);

  current = new Date(startDate);
  while (current <= endDate) {
    const ds = dateToLocalStr(current);
    const st = dayStats(ds);
    const note = state.dailyNotes[ds];
    const noteStr = note
      ? [
          note.eveningRating ? 'Puan:' + note.eveningRating : '',
          note.eveningBest || '',
          note.g1 || ''
        ].filter(Boolean).join(' · ')
      : '';
    const habitStr = st.habitsTotal
      ? st.habitsDone + '/' + st.habitsTotal
      : '-';
    summaryRows.push([
      ds,
      dayNamesFull[current.getDay()],
      st.total,
      st.done,
      Math.max(0, st.total - st.done),
      st.rate,
      st.focus,
      habitStr,
      noteStr
    ]);
    current.setDate(current.getDate() + 1);
  }
  summaryRows.push([]);
  summaryRows.push([
    'TOPLAM / ORTALAMA', '',
    grandTotal, grandDone, grandTotal - grandDone,
    overallRate, focusTotal, '', ''
  ]);

  // ========== 3) GÜNLÜK DETAY ==========
  const dailyRows = [];
  dailyRows.push(['GÜNLÜK GÖREV DETAYI']);
  dailyRows.push([]);
  dailyRows.push(['Tarih', 'Gün', 'Görev', 'Kategori', 'Durum', 'Öncelik', 'Saat', 'Tekrar', 'Alt Görevler']);

  current = new Date(startDate);
  while (current <= endDate) {
    const ds = dateToLocalStr(current);
    const day = current.getDay();
    state.tasks.forEach(task => {
      if (!doesTaskApplyOnDate(task, ds)) return;
      const cat = state.categories.find(c => c.id === task.categoryId);
      const done = wasTaskCompletedOnDate(task, ds);
      let subText = '';
      if (task.subtasks && task.subtasks.length) {
        const hist = (task.completionHistory || []).find(h => h.date === ds);
        subText = task.subtasks.map(s => {
          const sDone = hist && hist.subtasks && hist.subtasks[s.id];
          return (sDone ? '✓' : '✗') + ' ' + s.title;
        }).join(' · ');
      }
      let tekrar = 'Tek seferlik';
      if (task.recurrence.type === 'daily') tekrar = 'Her gün';
      else if (task.recurrence.type === 'custom') {
        tekrar = (task.recurrence.days || []).map(d => dayNamesShort[d]).join(', ');
      }
      const prioMap = { high: 'Yüksek', medium: 'Orta', low: 'Düşük' };
      dailyRows.push([
        ds,
        dayNamesFull[day],
        task.title,
        cat ? cat.name : '-',
        done ? '✓ Yapıldı' : '✗ Yapılmadı',
        prioMap[task.priority] || 'Orta',
        task.dueTime || '-',
        tekrar,
        subText || '-'
      ]);
    });
    current.setDate(current.getDate() + 1);
  }

  // ========== 4) GÖREV BAZLI ==========
  const taskRows = [];
  taskRows.push(['GÖREV BAZLI BAŞARI SIRALAMASI']);
  taskRows.push([]);
  taskRows.push(['Sıra', 'Görev', 'Kategori', 'Tekrar', 'Uygulanan Gün', 'Yapılan', 'Başarı %', 'Seri', 'XP/gün']);

  const taskStats = [];
  state.tasks.forEach(task => {
    const cat = state.categories.find(c => c.id === task.categoryId);
    let tekrar = 'Tek seferlik';
    if (task.recurrence.type === 'daily') tekrar = 'Her gün';
    else if (task.recurrence.type === 'custom') {
      tekrar = (task.recurrence.days || []).map(d => dayNamesShort[d]).join(', ');
    }
    let applied = 0, completed = 0;
    let d = new Date(startDate);
    while (d <= endDate) {
      const ds = dateToLocalStr(d);
      if (doesTaskApplyOnDate(task, ds)) {
        applied++;
        if (wasTaskCompletedOnDate(task, ds)) completed++;
      }
      d.setDate(d.getDate() + 1);
    }
    if (applied > 0) {
      taskStats.push({
        title: task.title,
        cat: cat ? cat.name : '-',
        tekrar,
        applied,
        completed,
        rate: Math.round((completed / applied) * 100),
        streak: getTaskStreak(task),
        xp: getTaskXp(task)
      });
    }
  });
  taskStats.sort((a, b) => b.rate - a.rate || b.completed - a.completed);
  taskStats.forEach((t, i) => {
    taskRows.push([i + 1, t.title, t.cat, t.tekrar, t.applied, t.completed, t.rate + ' %', t.streak, t.xp]);
  });

  // ========== 5) AYLIK KIRILIM (yıllık/aylık için) ==========
  const monthRows = [];
  monthRows.push(['AYLIK KIRILIM']);
  monthRows.push([]);
  monthRows.push(['Ay', 'Toplam', 'Tamamlanan', 'Başarı %', 'Odak (dk)', 'Tam gün']);

  if (period === 'year' || period === 'month') {
    const monthMap = {};
    current = new Date(startDate);
    while (current <= endDate) {
      const ds = dateToLocalStr(current);
      const key = ds.slice(0, 7);
      if (!monthMap[key]) monthMap[key] = { total: 0, done: 0, focus: 0, perfect: 0, days: 0 };
      const st = dayStats(ds);
      monthMap[key].total += st.total;
      monthMap[key].done += st.done;
      monthMap[key].focus += st.focus;
      if (st.total > 0) {
        monthMap[key].days++;
        if (st.done === st.total) monthMap[key].perfect++;
      }
      current.setDate(current.getDate() + 1);
    }
    Object.keys(monthMap).sort().forEach(key => {
      const m = monthMap[key];
      const [y, mo] = key.split('-');
      const label = months[parseInt(mo, 10) - 1] + ' ' + y;
      monthRows.push([
        label, m.total, m.done,
        m.total ? Math.round((m.done / m.total) * 100) + ' %' : '0 %',
        m.focus, m.perfect
      ]);
    });
  } else {
    monthRows.push(['(Haftalık raporda aylık kırılım yok)']);
  }

  // ========== Workbook ==========
  const wb = XLSX.utils.book_new();

  const wsDash = XLSX.utils.aoa_to_sheet(dash);
  wsDash['!cols'] = [{ wch: 28 }, { wch: 14 }, { wch: 14 }, { wch: 12 }];
  XLSX.utils.book_append_sheet(wb, wsDash, '1-Özet');

  const wsSum = XLSX.utils.aoa_to_sheet(summaryRows);
  wsSum['!cols'] = [
    { wch: 12 }, { wch: 12 }, { wch: 12 }, { wch: 12 },
    { wch: 8 }, { wch: 10 }, { wch: 10 }, { wch: 12 }, { wch: 36 }
  ];
  XLSX.utils.book_append_sheet(wb, wsSum, '2-Günlük Özet');

  const wsDaily = XLSX.utils.aoa_to_sheet(dailyRows);
  wsDaily['!cols'] = [
    { wch: 12 }, { wch: 11 }, { wch: 26 }, { wch: 12 },
    { wch: 12 }, { wch: 10 }, { wch: 8 }, { wch: 14 }, { wch: 40 }
  ];
  XLSX.utils.book_append_sheet(wb, wsDaily, '3-Görev Detay');

  const wsTask = XLSX.utils.aoa_to_sheet(taskRows);
  wsTask['!cols'] = [
    { wch: 6 }, { wch: 26 }, { wch: 12 }, { wch: 14 },
    { wch: 12 }, { wch: 10 }, { wch: 10 }, { wch: 8 }, { wch: 8 }
  ];
  XLSX.utils.book_append_sheet(wb, wsTask, '4-Görev Sıralama');

  const wsMonth = XLSX.utils.aoa_to_sheet(monthRows);
  wsMonth['!cols'] = [{ wch: 16 }, { wch: 10 }, { wch: 12 }, { wch: 10 }, { wch: 12 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, wsMonth, '5-Aylık Kırılım');

  const fileName = `Gorev_Raporu_${periodLabel}_${todayStr()}.xlsx`;
  XLSX.writeFile(wb, fileName);
  showToast('Detaylı rapor indirildi 📊');
}

// ==================== EXCEL İÇE AKTARMA ====================
function downloadImportTemplate() {
  if (typeof XLSX === 'undefined') {
    showToast('Excel kütüphanesi yüklenemedi');
    return;
  }

  // Ana şablon: her alt görev ayrı sütun (Alt1 ... Alt15)
  const altHeaders = [];
  for (let i = 1; i <= 15; i++) altHeaders.push('Alt' + i);

  const header = ['Görev', 'Kategori', 'Tekrar', 'Günler', 'Saat', 'Öncelik', 'Tarih', ...altHeaders];

  const example1 = [
    'Sabah zikri', 'Zikirler', 'Her gün', '', '06:30', 'Yüksek', '',
    'İstiğfar 100', 'Salavat 100', 'Tevhid', '', '', '', '', '', '', '', '', '', '', ''
  ];
  const example2 = [
    'Fıkıh dersi', 'Dersler', 'Belirli günler', 'Pzt, Per', '20:00', 'Orta', '',
    'Konu okuma', 'Not çıkarma', 'Soru çözümü', 'Tekrar', '', '', '', '', '', '', '', '', '', ''
  ];
  const example3 = [
    'Kur\'an tekrarı', 'Namazlar', 'Her gün', '', '05:30', 'Yüksek', '',
    'Sayfa 1-2', 'Sayfa 3-4', 'Sayfa 5-6', '', '', '', '', '', '', '', '', '', '', ''
  ];
  const example4 = [
    'Özel toplantı', 'Dersler', 'Tek seferlik', '', '14:00', 'Düşük', '2026-10-15',
    '', '', '', '', '', '', '', '', '', '', '', '', '', ''
  ];

  // Boş satırlar (kullanıcı doldursun)
  const emptyRows = [];
  for (let r = 0; r < 20; r++) {
    emptyRows.push(new Array(header.length).fill(''));
  }

  const dataSheet = [header, example1, example2, example3, example4, ...emptyRows];

  // Açıklama sayfası
  const guide = [
    ['GÖREV AKTARMA ŞABLONU — KULLANIM KILAVUZU'],
    [],
    ['Sütun', 'Zorunlu?', 'Açıklama', 'Örnek'],
    ['Görev', 'Evet', 'Görevin adı', 'Sabah zikri'],
    ['Kategori', 'Hayır', 'Yoksa otomatik oluşur', 'Zikirler / Dersler / Namazlar'],
    ['Tekrar', 'Hayır', 'Her gün / Belirli günler / Tek seferlik', 'Her gün'],
    ['Günler', 'Koşullu', 'Sadece Belirli günler için', 'Pzt, Sal, Çar'],
    ['Saat', 'Hayır', 'HH:MM formatı', '06:30'],
    ['Öncelik', 'Hayır', 'Yüksek / Orta / Düşük (XP: 20 / 10 / 5)', 'Yüksek'],
    ['Tarih', 'Koşullu', 'Sadece Tek seferlik için YYYY-MM-DD', '2026-10-15'],
    ['Alt1 … Alt15', 'Hayır', 'Her sütuna bir alt görev yazın', 'İstiğfar 100'],
    [],
    ['İPUÇLARI'],
    ['1. "Görevler" sayfasındaki örnek satırları silebilir veya değiştirebilirsiniz.'],
    ['2. Alt görevler için Alt1, Alt2, Alt3... sütunlarını kullanın (en fazla 15).'],
    ['3. Eski yöntem de çalışır: tek sütunda "a | b | c" yazmak.'],
    ['4. Günler: Pzt Sal Çar Per Cum Cmt Paz (virgülle ayırın).'],
    ['5. Dosyayı kaydedip uygulamada "Excel\'den Aktar" ile yükleyin.']
  ];

  const wb = XLSX.utils.book_new();

  const wsData = XLSX.utils.aoa_to_sheet(dataSheet);
  const cols = [
    { wch: 22 }, { wch: 12 }, { wch: 14 }, { wch: 14 },
    { wch: 8 }, { wch: 10 }, { wch: 12 }
  ];
  for (let i = 0; i < 15; i++) cols.push({ wch: 14 });
  wsData['!cols'] = cols;
  // dondurulmuş başlık satırı
  wsData['!freeze'] = { xSplit: 0, ySplit: 1 };
  XLSX.utils.book_append_sheet(wb, wsData, 'Görevler');

  const wsGuide = XLSX.utils.aoa_to_sheet(guide);
  wsGuide['!cols'] = [{ wch: 16 }, { wch: 10 }, { wch: 48 }, { wch: 22 }];
  XLSX.utils.book_append_sheet(wb, wsGuide, 'Kılavuz');

  XLSX.writeFile(wb, 'Gorev_Aktarma_Sablonu.xlsx');
  showToast('Şablon indirildi (Görevler + Kılavuz)');
}

function normalizeHeader(h) {
  return String(h || '')
    .toLowerCase()
    .trim()
    .replace(/ı/g, 'i')
    .replace(/ğ/g, 'g')
    .replace(/ü/g, 'u')
    .replace(/ş/g, 's')
    .replace(/ö/g, 'o')
    .replace(/ç/g, 'c')
    .replace(/\s+/g, '');
}

function parseRecurrence(tekrar, gunler) {
  const t = String(tekrar || '').toLowerCase().trim();
  if (t.includes('her gun') || t.includes('hergün') || t.includes('daily') || t === 'her gun') {
    return { type: 'daily', days: [] };
  }
  if (t.includes('belirli') || t.includes('custom') || t.includes('hafta')) {
    const dayMap = {
      paz: 0, pazar: 0,
      pzt: 1, pazartesi: 1,
      sal: 2, sali: 2,
      car: 3, carsamba: 3, çar: 3, çarşamba: 3,
      per: 4, persembe: 4, perşembe: 4,
      cum: 5, cuma: 5,
      cmt: 6, cumartesi: 6
    };
    const days = [];
    String(gunler || '').split(/[,;|/]/).forEach(part => {
      const key = normalizeHeader(part);
      if (key && dayMap[key] !== undefined && !days.includes(dayMap[key])) {
        days.push(dayMap[key]);
      }
    });
    return { type: 'custom', days: days.length ? days : [1, 2, 3, 4, 5] };
  }
  return { type: 'none', days: [] };
}

function parsePriority(p) {
  const s = String(p || '').toLowerCase().trim();
  if (s.includes('yuksek') || s.includes('high') || s === 'yüksek') return 'high';
  if (s.includes('dusuk') || s.includes('low') || s === 'düşük') return 'low';
  return 'medium';
}

function findOrCreateCategory(name) {
  const n = String(name || '').trim();
  if (!n) return state.categories[0]?.id;
  const existing = state.categories.find(c => c.name.toLowerCase() === n.toLowerCase());
  if (existing) return existing.id;
  const colors = ['#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899'];
  const cat = {
    id: generateId(),
    name: n,
    color: colors[state.categories.length % colors.length]
  };
  state.categories.push(cat);
  return cat.id;
}

function importTasksFromExcel(file) {
  if (typeof XLSX === 'undefined') {
    showToast('Excel kütüphanesi yüklenemedi (internet gerekir)');
    return;
  }

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target.result);
      const wb = XLSX.read(data, { type: 'array' });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(sheet, { defval: '' });

      if (!rows.length) {
        showToast('Excel boş görünüyor');
        return;
      }

      // Başlık eşleştirme
      const first = rows[0];
      const keys = Object.keys(first);
      const map = { altCols: [] };
      keys.forEach(k => {
        const nk = normalizeHeader(k);
        if (['gorev', 'baslik', 'title', 'ad', 'task'].includes(nk)) map.title = k;
        else if (['kategori', 'category', 'kat'].includes(nk)) map.category = k;
        else if (['tekrar', 'tekrarlama', 'recurrence', 'sikilik'].includes(nk)) map.recurrence = k;
        else if (['gunler', 'gun', 'days', 'haftaningunleri'].includes(nk)) map.days = k;
        else if (['saat', 'time', 'zaman'].includes(nk)) map.time = k;
        else if (['oncelik', 'priority', 'onem'].includes(nk)) map.priority = k;
        else if (['altgorevler', 'altgorev', 'subtasks'].includes(nk)) map.subtasks = k;
        else if (['tarih', 'date', 'gununtarihi'].includes(nk)) map.date = k;
        else if (/^alt\d+$/.test(nk) || /^sub\d+$/.test(nk) || /^altgorev\d+$/.test(nk)) {
          map.altCols.push(k);
        }
      });
      // Alt1, Alt2... sırasına koy
      map.altCols.sort((a, b) => {
        const na = parseInt(normalizeHeader(a).replace(/\D/g, ''), 10) || 0;
        const nb = parseInt(normalizeHeader(b).replace(/\D/g, ''), 10) || 0;
        return na - nb;
      });

      if (!map.title) {
        showToast('Excel\'de "Görev" sütunu bulunamadı');
        return;
      }

      let added = 0;
      let skipped = 0;

      rows.forEach(row => {
        const title = String(row[map.title] || '').trim();
        // Açıklama satırlarını atla
        if (!title || title.toUpperCase().startsWith('AÇIKLAMA') || title.toUpperCase().startsWith('ACIKLAMA')) {
          skipped++;
          return;
        }

        const categoryName = map.category ? row[map.category] : '';
        const recurrenceRaw = map.recurrence ? row[map.recurrence] : 'Tek seferlik';
        const daysRaw = map.days ? row[map.days] : '';
        const timeRaw = map.time ? String(row[map.time] || '').trim() : '';
        const priorityRaw = map.priority ? row[map.priority] : 'Orta';
        const subRaw = map.subtasks ? String(row[map.subtasks] || '') : '';
        let dateRaw = map.date ? row[map.date] : '';

        // Excel tarih numarası olabilir
        if (typeof dateRaw === 'number' && dateRaw > 30000) {
          const excelEpoch = new Date(1899, 11, 30);
          const d = new Date(excelEpoch.getTime() + dateRaw * 86400000);
          dateRaw = dateToLocalStr(d);
        } else {
          dateRaw = String(dateRaw || '').trim();
        }

        // Saat formatı (Excel ondalık saat)
        let dueTime = null;
        if (timeRaw) {
          if (typeof row[map.time] === 'number') {
            const totalMin = Math.round(row[map.time] * 24 * 60);
            const hh = String(Math.floor(totalMin / 60) % 24).padStart(2, '0');
            const mm = String(totalMin % 60).padStart(2, '0');
            dueTime = `${hh}:${mm}`;
          } else {
            const m = timeRaw.match(/(\d{1,2})[:\.](\d{2})/);
            if (m) dueTime = `${m[1].padStart(2, '0')}:${m[2]}`;
          }
        }

        const recurrence = parseRecurrence(recurrenceRaw, daysRaw);
        // Alt görevler: Alt1..Alt15 sütunları + eski "a | b" formatı
        const subTitles = [];
        (map.altCols || []).forEach(col => {
          const v = String(row[col] || '').trim();
          if (v) subTitles.push(v);
        });
        if (subRaw) {
          subRaw.split('|').map(s => s.trim()).filter(Boolean).forEach(s => {
            if (!subTitles.includes(s)) subTitles.push(s);
          });
        }
        const subtasks = subTitles.map(t => ({
          id: generateId(),
          title: t,
          completed: false
        }));

        const task = {
          id: generateId(),
          title,
          categoryId: findOrCreateCategory(categoryName),
          dueDate: recurrence.type === 'none' ? (dateRaw || null) : null,
          dueTime,
          priority: parsePriority(priorityRaw),
          recurrence,
          subtasks,
          completed: false,
          completedAt: null,
          createdAt: new Date().toISOString(),
          completionHistory: []
        };

        state.tasks.unshift(task);
        added++;
      });

      saveState();
      renderAll();
      showToast(`${added} görev aktarıldı${skipped ? `, ${skipped} satır atlandı` : ''}`);
    } catch (err) {
      console.error(err);
      showToast('Excel okunamadı. Şablonu kullanmayı dene');
    }
  };
  reader.readAsArrayBuffer(file);
}

// ==================== KATEGORİ ====================
function openCategoryModal() {
  document.getElementById('category-form').reset();
  state.selectedColor = '#3b82f6';
  document.querySelectorAll('.color-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.color === state.selectedColor);
  });
  document.getElementById('category-modal').classList.remove('hidden');
}

function closeCategoryModal() {
  document.getElementById('category-modal').classList.add('hidden');
}

function handleCategorySubmit(e) {
  e.preventDefault();
  const name = document.getElementById('category-name').value.trim();
  if (!name) return;
  state.categories.push({
    id: generateId(),
    name,
    color: state.selectedColor
  });
  saveState();
  closeCategoryModal();
  renderAll();
  showToast('Kategori eklendi');
}

// ==================== NAVİGASYON ====================
function switchView(viewName) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  const view = document.getElementById(viewName + '-view');
  if (view) view.classList.add('active');

  const nav = document.querySelector(`.nav-item[data-view="${viewName}"]`);
  if (nav) nav.classList.add('active');

  const titles = {
    today: 'Bugün',
    all: 'Tüm Görevler',
    history: 'Tarih',
    categories: 'Kategoriler',
    stats: 'İstatistikler'
  };
  document.getElementById('page-title').textContent = titles[viewName] || 'Görev Takip';

  // Progress sadece bugün görünümünde
  document.querySelector('.progress-summary').style.display = viewName === 'today' ? 'block' : 'none';

  if (viewName === 'history') {
    renderHistory();
  }
}

// ==================== INIT ====================
function init() {
  loadState();
  renderAll();

  // Navigation
  document.querySelectorAll('.nav-item[data-view]').forEach(btn => {
    btn.addEventListener('click', () => switchView(btn.dataset.view));
  });

  // FAB
  document.getElementById('add-task-btn').addEventListener('click', () => openTaskModal());

  // Theme
  document.getElementById('theme-toggle').addEventListener('click', () => {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme();
    saveState();
  });

  // Stats shortcut
  document.getElementById('stats-btn').addEventListener('click', () => switchView('stats'));

  // Modal
  document.getElementById('close-modal').addEventListener('click', closeTaskModal);
  document.getElementById('task-modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('task-modal')) closeTaskModal();
  });
  document.getElementById('task-form').addEventListener('submit', handleTaskSubmit);
  document.getElementById('delete-task-btn').addEventListener('click', deleteTask);
  document.getElementById('copy-task-btn').addEventListener('click', copyTask);
  document.getElementById('add-subtask-btn').addEventListener('click', () => addSubtaskInput());

  // Recurrence
  document.getElementById('task-recurrence').addEventListener('change', (e) => {
    const val = e.target.value;
    document.getElementById('days-selector').classList.toggle('hidden', val !== 'custom');
    // Her gün veya belirli günler seçilince tarih alanını gizle
    const dateGroup = document.getElementById('task-date').closest('.form-group');
    if (dateGroup) {
      dateGroup.style.display = (val === 'daily' || val === 'custom') ? 'none' : '';
    }
    if (val === 'daily' || val === 'custom') {
      document.getElementById('task-date').value = '';
    }
  });

  // Priority
  document.querySelectorAll('.priority-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedPriority = btn.dataset.priority;
      updatePriorityButtons();
    });
  });

  // Category modal
  document.getElementById('add-category-btn').addEventListener('click', openCategoryModal);
  document.getElementById('close-category-modal').addEventListener('click', closeCategoryModal);
  document.getElementById('category-modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('category-modal')) closeCategoryModal();
  });
  document.getElementById('category-form').addEventListener('submit', handleCategorySubmit);

  document.querySelectorAll('.color-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      state.selectedColor = btn.dataset.color;
      document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Search & filter
  document.getElementById('search-input').addEventListener('input', renderAllTasks);
  document.getElementById('category-filter').addEventListener('change', renderAllTasks);

  // Excel Rapor butonları
  document.querySelectorAll('.btn-report').forEach(btn => {
    btn.addEventListener('click', () => {
      generateExcelReport(btn.dataset.period);
    });
  });

  // Tarih sayfası
  state.selectedHistoryDate = todayStr();
  const historyDateInput = document.getElementById('history-date');
  if (historyDateInput) {
    historyDateInput.value = state.selectedHistoryDate;
    historyDateInput.addEventListener('change', () => {
      state.selectedHistoryDate = historyDateInput.value || todayStr();
      renderHistory();
    });
  }

  const prevDateBtn = document.getElementById('prev-date-btn');
  const nextDateBtn = document.getElementById('next-date-btn');
  if (prevDateBtn) {
    prevDateBtn.addEventListener('click', () => {
      const d = new Date((state.selectedHistoryDate || todayStr()) + 'T00:00:00');
      d.setDate(d.getDate() - 1);
      state.selectedHistoryDate = dateToLocalStr(d);
      renderHistory();
    });
  }
  if (nextDateBtn) {
    nextDateBtn.addEventListener('click', () => {
      const d = new Date((state.selectedHistoryDate || todayStr()) + 'T00:00:00');
      d.setDate(d.getDate() + 1);
      state.selectedHistoryDate = dateToLocalStr(d);
      renderHistory();
    });
  }

  const openCategoriesBtn = document.getElementById('open-categories-btn');
  if (openCategoriesBtn) {
    openCategoriesBtn.addEventListener('click', () => switchView('categories'));
  }

  // Excel şablon + içe aktarma
  const downloadTemplateBtn = document.getElementById('download-template-btn');
  const importExcelBtn = document.getElementById('import-excel-btn');
  const importExcelInput = document.getElementById('import-excel-input');
  if (downloadTemplateBtn) {
    downloadTemplateBtn.addEventListener('click', downloadImportTemplate);
  }
  if (importExcelBtn && importExcelInput) {
    importExcelBtn.addEventListener('click', () => importExcelInput.click());
    importExcelInput.addEventListener('change', () => {
      const file = importExcelInput.files && importExcelInput.files[0];
      if (file) {
        importTasksFromExcel(file);
        importExcelInput.value = '';
      }
    });
  }

  // Ertele / Pomodoro
  document.getElementById('postpone-task-btn')?.addEventListener('click', () => {
    const id = document.getElementById('task-id').value;
    if (id) { postponeTask(id); closeTaskModal(); }
  });
  document.getElementById('pomodoro-btn')?.addEventListener('click', () => {
    const id = document.getElementById('task-id').value;
    closeTaskModal();
    openPomodoro(id);
  });
  document.getElementById('close-pomodoro')?.addEventListener('click', () => {
    document.getElementById('pomodoro-modal').classList.add('hidden');
  });
  document.getElementById('pomo-start')?.addEventListener('click', startPomodoro);
  document.getElementById('pomo-pause')?.addEventListener('click', pausePomodoro);
  document.getElementById('pomo-reset')?.addEventListener('click', resetPomodoro);

  document.getElementById('add-habit-btn')?.addEventListener('click', () => {
    const title = prompt('Alışkanlık adı (örn: Sabah erken kalk)');
    if (!title || !title.trim()) return;
    state.habits.push({ id: generateId(), title: title.trim(), history: [] });
    saveState();
    renderHabits();
    showToast('Alışkanlık eklendi');
  });

  document.getElementById('add-goal-btn')?.addEventListener('click', () => {
    const title = prompt('Hedef (örn: 120 günde hafızlık tekrarı)');
    if (!title || !title.trim()) return;
    const target = parseInt(prompt('Hedef sayı (örn: 120)', '30'), 10) || 30;
    state.goals.push({ id: generateId(), title: title.trim(), target, progress: 0 });
    saveState();
    renderStats();
    showToast('Hedef eklendi');
  });

  document.getElementById('save-morning-btn')?.addEventListener('click', () => {
    const t = todayStr();
    if (!state.dailyNotes[t]) state.dailyNotes[t] = {};
    state.dailyNotes[t].g1 = document.getElementById('morning-g1').value.trim();
    state.dailyNotes[t].g2 = document.getElementById('morning-g2').value.trim();
    state.dailyNotes[t].g3 = document.getElementById('morning-g3').value.trim();
    saveState();
    showToast('Sabah hedefleri kaydedildi');
  });
  document.getElementById('save-evening-btn')?.addEventListener('click', () => {
    const t = todayStr();
    if (!state.dailyNotes[t]) state.dailyNotes[t] = {};
    state.dailyNotes[t].eveningRating = parseInt(document.getElementById('evening-rating').value, 10) || 0;
    state.dailyNotes[t].eveningBest = document.getElementById('evening-best').value.trim();
    state.dailyNotes[t].eveningImprove = document.getElementById('evening-improve').value.trim();
    saveState();
    renderTodayExtras();
    showToast('Akşam değerlendirmesi kaydedildi');
  });

  // Service Worker for PWA
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
}

// ==================== POMODORO ====================
function openPomodoro(taskId) {
  const task = state.tasks.find(t => t.id === taskId);
  state.pomodoro.taskId = taskId || null;
  state.pomodoro.mode = 'work';
  state.pomodoro.remaining = 25 * 60;
  state.pomodoro.running = false;
  if (state.pomodoro.timerId) {
    clearInterval(state.pomodoro.timerId);
    state.pomodoro.timerId = null;
  }
  const title = document.getElementById('pomo-title');
  if (title) title.textContent = task ? task.title : 'Odaklanma';
  updatePomoUI();
  document.getElementById('pomodoro-modal').classList.remove('hidden');
}

function updatePomoUI() {
  const m = Math.floor(state.pomodoro.remaining / 60);
  const s = state.pomodoro.remaining % 60;
  const el = document.getElementById('pomo-timer');
  if (el) el.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  const mode = document.getElementById('pomo-mode');
  if (mode) mode.textContent = state.pomodoro.mode === 'work' ? 'Çalışma (25 dk)' : 'Mola (5 dk)';
}

function startPomodoro() {
  if (state.pomodoro.running) return;
  state.pomodoro.running = true;
  state.pomodoro.timerId = setInterval(() => {
    if (state.pomodoro.remaining > 0) {
      state.pomodoro.remaining--;
      updatePomoUI();
    } else {
      clearInterval(state.pomodoro.timerId);
      state.pomodoro.timerId = null;
      state.pomodoro.running = false;
      if (state.pomodoro.mode === 'work') {
        state.focusLog.push({ date: todayStr(), minutes: 25, taskId: state.pomodoro.taskId });
        saveState();
        checkBadges();
        showToast('Pomodoro bitti! +25 dk odak');
        state.pomodoro.mode = 'break';
        state.pomodoro.remaining = 5 * 60;
        updatePomoUI();
        renderTodayExtras();
      } else {
        showToast('Mola bitti, devam!');
        state.pomodoro.mode = 'work';
        state.pomodoro.remaining = 25 * 60;
        updatePomoUI();
      }
    }
  }, 1000);
}

function pausePomodoro() {
  state.pomodoro.running = false;
  if (state.pomodoro.timerId) {
    clearInterval(state.pomodoro.timerId);
    state.pomodoro.timerId = null;
  }
}

function resetPomodoro() {
  pausePomodoro();
  state.pomodoro.mode = 'work';
  state.pomodoro.remaining = 25 * 60;
  updatePomoUI();
}

document.addEventListener('DOMContentLoaded', init);
