const DEFAULT_STATE = {
  profile: { name: "Apprenant(e)", level: "L2 Informatique", light: false },
  completedChapters: [],
  favorites: [],
  quizScores: {}
};

let state = loadState();
let currentTab = "home";
let viewStack = [];
let selectedCategory = "Toutes";
let searchQuery = "";
let quizSession = null;
let openSolutions = {};

function loadState() {
  try {
    const raw = localStorage.getItem("jostech_state_v2");
    return raw ? Object.assign({}, DEFAULT_STATE, JSON.parse(raw)) : JSON.parse(JSON.stringify(DEFAULT_STATE));
  } catch (e) {
    return JSON.parse(JSON.stringify(DEFAULT_STATE));
  }
}

function saveState() {
  try { localStorage.setItem("jostech_state_v2", JSON.stringify(state)); } catch (e) {}
}

function applyTheme() {
  document.body.classList.toggle("light", !!state.profile.light);
}

function switchTab(tab) {
  currentTab = tab;
  viewStack = [];
  document.querySelectorAll(".nav-item").forEach(btn => {
    btn.classList.toggle("active", btn.dataset.tab === tab);
  });
  render();
  window.scrollTo(0, 0);
}

function pushView(view) { viewStack.push(view); render(); window.scrollTo(0, 0); }
function goBack() { viewStack.pop(); quizSession = null; openSolutions = {}; render(); window.scrollTo(0, 0); }
function openAbout() { pushView({ type: "about" }); }

function getTotalChapters() {
  return COURSES.reduce((sum, c) => sum + c.chapters.length, 0);
}

function getCourseProgress(course) {
  const done = course.chapters.filter(ch => state.completedChapters.includes(ch.id)).length;
  return Math.round((done / course.chapters.length) * 100);
}

function render() {
  const app = document.getElementById("app");
  if (typeof COURSES === "undefined") {
    app.innerHTML = '<div class="card" style="color:#f87171;">Fichier <b>cours.js</b> manquant.</div>';
    return;
  }

  const backBtn = document.getElementById("backBtn");
  const topTitle = document.getElementById("topbarTitle");
  const bottomNav = document.getElementById("bottomNav");

  if (viewStack.length > 0) {
    backBtn.style.display = "inline-block";
    bottomNav.style.display = "none";
    const v = viewStack[viewStack.length - 1];
    if (v.type === "course") { topTitle.textContent = "Module"; app.innerHTML = renderCourseDetail(v.courseId); }
    else if (v.type === "lesson") { topTitle.textContent = "Cours"; app.innerHTML = renderLesson(v.courseId, v.chapterIndex); }
    else if (v.type === "exercises") { topTitle.textContent = "Exercices"; app.innerHTML = renderExercises(v.courseId); }
    else if (v.type === "quiz") { topTitle.textContent = "Quiz"; app.innerHTML = renderQuiz(v.courseId); }
    else if (v.type === "about") { topTitle.textContent = "À propos"; app.innerHTML = renderAbout(); }
    return;
  }

  backBtn.style.display = "none";
  bottomNav.style.display = "flex";
  topTitle.textContent = "JosTech";

  if (currentTab === "home") app.innerHTML = renderHome();
  else if (currentTab === "catalog") app.innerHTML = renderCatalog();
  else if (currentTab === "favorites") app.innerHTML = renderFavorites();
  else if (currentTab === "profile") app.innerHTML = renderProfile();
}

function renderHome() {
  const total = getTotalChapters();
  const done = state.completedChapters.length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  return `
    <div class="card hero">
      <h2>Bienvenue, ${escapeHtml(state.profile.name)} ✨</h2>
      <p>${escapeHtml(state.profile.level)} • Plateforme 100 % gratuite & hors-ligne</p>
      <div class="progress-wrap"><div class="progress-fill" style="width:${pct}%"></div></div>
      <div class="progress-text">Progression globale : ${done}/${total} chapitres (${pct}%)</div>
    </div>
    <div class="section-title">
      <span>Parcours de formation (${COURSES.length})</span>
      <button class="btn btn-sm btn-outline" onclick="switchTab('catalog')">Filtrer</button>
    </div>
    ${COURSES.map(courseCardHTML).join("")}
  `;
}

function renderCatalog() {
  const categories = ["Toutes", ...new Set(COURSES.map(c => c.category))];
  const filtered = COURSES.filter(c => {
    const matchCat = selectedCategory === "Toutes" || c.category === selectedCategory;
    const q = searchQuery.toLowerCase();
    const matchSearch = c.title.toLowerCase().includes(q) || c.description.toLowerCase().includes(q) || c.category.toLowerCase().includes(q);
    return matchCat && matchSearch;
  });
  return `
    <input class="search-input" type="text" placeholder="🔍 Chercher un cours (Python, Réseau, Cyber, Anglais...)" value="${escapeHtml(searchQuery)}" oninput="onSearch(this.value)" />
    <div class="chips">
      ${categories.map(cat => `<button class="chip ${selectedCategory === cat ? 'active' : ''}" onclick="setCategory('${cat}')">${cat}</button>`).join("")}
    </div>
    ${filtered.length ? filtered.map(courseCardHTML).join("") : `<div class="card"><p class="course-desc">Aucun cours trouvé.</p></div>`}
  `;
}

function renderFavorites() {
  const favs = COURSES.filter(c => state.favorites.includes(c.id));
  if (!favs.length) {
    return `<div class="card" style="text-align:center; padding:32px 16px;">
      <p style="font-size:34px; margin-bottom:8px;">⭐</p>
      <h3 style="margin-bottom:6px; color:var(--gold-light);">Aucun cours en favori</h3>
      <p class="course-desc">Touchez l'étoile d'un module pour l'épingler ici.</p>
      <button class="btn" onclick="switchTab('catalog')">Explorer les cours</button>
    </div>`;
  }
  return `<div class="section-title">Mes modules favoris (${favs.length})</div>` + favs.map(courseCardHTML).join("");
}

function renderProfile() {
  const vals = Object.values(state.quizScores);
  const avg = vals.length ? Math.round(vals.reduce((a,b) => a + b, 0) / vals.length) : 0;
  return `
    <div class="stats-grid">
      <div class="stat-box"><div class="stat-num">${state.completedChapters.length}</div><div class="stat-lbl">Chapitres terminés</div></div>
      <div class="stat-box"><div class="stat-num">${avg}%</div><div class="stat-lbl">Moyenne aux Quiz</div></div>
    </div>
    <div class="card">
      <h3 style="margin-bottom:12px; color:var(--gold-light);">Profil Apprenant</h3>
      <div class="form-group"><label>Prénom ou Nom</label><input id="profName" class="form-control" value="${escapeHtml(state.profile.name)}" /></div>
      <div class="form-group"><label>Niveau d'études</label>
        <select id="profLevel" class="form-control">
          ${["Intermédiaire", "L1 Informatique", "L2 Informatique", "L3 Informatique", "Master"].map(l => `<option value="${l}" ${state.profile.level === l ? "selected" : ""}>${l}</option>`).join("")}
        </select>
      </div>
      <button class="btn" onclick="saveProfileForm()">Enregistrer</button>
    </div>
    <div class="card" style="display:flex; justify-content:space-between; align-items:center;">
      <div><strong>Thème d'affichage</strong><div style="font-size:12px; color:var(--muted);">${state.profile.light ? "Mode Clair activé" : "Bleu de Nuit & Doré"}</div></div>
      <button class="btn btn-sm btn-outline" onclick="toggleThemeMode()">${state.profile.light ? "Passer Bleu Nuit 🌙" : "Passer Clair ☀️"}</button>
    </div>
    <div class="card">
      <button class="btn btn-blue" style="margin-bottom:10px;" onclick="openAbout()">ⓘ À propos de JosTech (M.R Jos)</button>
      <button class="btn btn-outline" style="border-color:var(--danger); color:var(--danger);" onclick="resetAll()">Réinitialiser ma progression</button>
    </div>
  `;
}

function renderAbout() {
  return `
    <div class="card founder-card" style="padding:26px 18px;">
      <svg viewBox="0 0 64 64" width="76" height="76" style="margin-bottom:10px;" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="goldBig" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#fde047"/>
            <stop offset="50%" stop-color="#eab308"/>
            <stop offset="100%" stop-color="#b45309"/>
          </linearGradient>
        </defs>
        <polygon points="32,3 58,18 58,46 32,61 6,46 6,18" fill="#071329" stroke="url(#goldBig)" stroke-width="3.5"/>
        <path d="M22 25 L15 32 L22 39 M42 25 L49 32 L42 39" fill="none" stroke="url(#goldBig)" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"/>
        <text x="32" y="38" text-anchor="middle" fill="url(#goldBig)" font-size="18" font-weight="900" font-family="sans-serif">JT</text>
      </svg>
      <h2 style="color:#fde047; font-size:24px; margin-bottom:4px;">JosTech</h2>
      <p style="font-size:13px; color:#cbd5e1; margin-bottom:14px;">Version 2.0 • Édition Bleu de Nuit & Or</p>
      <span class="tag" style="font-size:13px; padding:6px 14px;">Fondateur : M.R Jos</span>
    </div>

    <div class="card lesson-content">
      <h3>Notre Mission</h3>
      <p><strong>JosTech</strong> a été conçue par <strong>M.R Jos</strong> pour offrir aux étudiants universitaires et aux apprenants en informatique un accès <strong>100 % gratuit et hors connexion</strong> à des cours structurés, des exercices pratiques et des quiz.</p>
      <h3>Contenu de la plateforme</h3>
      <ul>
        <li>Informatique générale & Architecture</li>
        <li>Programmation (Algorithmique, Python, C)</li>
        <li>Réseaux & Systèmes informatiques</li>
        <li>Cybersécurité & Protection des données</li>
        <li>Anglais technique pour l'informatique</li>
      </ul>
      <p style="font-size:13px; color:var(--muted); margin-top:10px;">© JosTech — Créé avec passion par M.R Jos.</p>
    </div>
  `;
}

function courseCardHTML(course) {
  const pct = getCourseProgress(course);
  const isFav = state.favorites.includes(course.id);
  const exCount = (course.exercises || []).length;
  return `
    <div class="card course-card" onclick="openCourse('${course.id}')">
      <div class="course-top">
        <span class="tag">${course.category} • ${course.level}</span>
        <button class="fav-btn" onclick="event.stopPropagation(); toggleFav('${course.id}')">${isFav ? '⭐' : '☆'}</button>
      </div>
      <div class="course-title">${course.title}</div>
      <div class="course-desc">${course.description}</div>
      <div class="course-meta">
        <span>📖 ${course.chapters.length} chap. • 📝 ${exCount} exo. • ⏱️ ${course.duration}</span>
        <span style="color:var(--gold-light); font-weight:800;">${pct}%</span>
      </div>
    </div>
  `;
}

function renderCourseDetail(courseId) {
  const c = COURSES.find(x => x.id === courseId);
  const pct = getCourseProgress(c);
  const bestQuiz = state.quizScores[c.id];
  const exList = c.exercises || [];
  return `
    <div class="card">
      <span class="tag">${c.category} • ${c.level}</span>
      <h2 style="font-size:20px; margin-bottom:6px; color:var(--gold-light);">${c.title}</h2>
      <p class="course-desc">${c.description}</p>
      <div style="font-size:13px; font-weight:700; color:var(--gold-light);">Progression : ${pct}% ${bestQuiz !== undefined ? `• Meilleur Quiz : ${bestQuiz}%` : ""}</div>
    </div>

    <div class="section-title">Chapitres</div>
    ${c.chapters.map((ch, idx) => {
      const done = state.completedChapters.includes(ch.id);
      return `
        <div class="card course-card" onclick="openLesson('${c.id}', ${idx})" style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <div style="font-weight:700; font-size:15px;">${ch.title}</div>
            <div style="font-size:12px; color:var(--muted); margin-top:3px;">${done ? "✅ Terminé" : "Touchez pour étudier"}</div>
          </div>
          <span style="color:var(--gold-light); font-size:18px;">➔</span>
        </div>`;
    }).join("")}

    ${exList.length ? `<button class="btn btn-blue" style="margin-bottom:10px;" onclick="openExercises('${c.id}')">📝 Exercices pratiques (${exList.length})</button>` : ""}
    <button class="btn" onclick="startQuiz('${c.id}')">🎯 Passer le Quiz (${c.quiz.length} questions)</button>
  `;
}

function renderLesson(courseId, idx) {
  const c = COURSES.find(x => x.id === courseId);
  const ch = c.chapters[idx];
  const isDone = state.completedChapters.includes(ch.id);
  const hasNext = idx + 1 < c.chapters.length;
  return `
    <div class="card lesson-content">
      <span class="tag">${c.title}</span>
      <h2 style="font-size:19px; margin-bottom:12px; color:var(--gold-light);">${ch.title}</h2>
      ${ch.html}
    </div>
    <button class="btn ${isDone ? 'btn-outline' : 'btn-success'}" style="margin-bottom:10px;" onclick="markChapterDone('${ch.id}')">
      ${isDone ? "✅ Chapitre terminé" : "✔ Marquer comme terminé"}
    </button>
    ${hasNext
      ? `<button class="btn" onclick="openNextLesson('${c.id}', ${idx + 1})">Chapitre suivant ➔</button>`
      : ((c.exercises && c.exercises.length)
          ? `<button class="btn" onclick="openExercises('${c.id}')">📝 Passer aux Exercices</button>`
          : `<button class="btn" onclick="startQuiz('${c.id}')">🎯 Passer au Quiz</button>`)}
  `;
}

function renderExercises(courseId) {
  const c = COURSES.find(x => x.id === courseId);
  const exList = c.exercises || [];
  return `
    <div class="card">
      <span class="tag">Travaux Pratiques</span>
      <h2 style="font-size:18px; color:var(--gold-light);">Exercices : ${c.title}</h2>
      <p class="course-desc" style="margin-bottom:0;">Cherchez d'abord sur papier ou dans votre tête avant d'afficher la correction.</p>
    </div>
    ${exList.map((ex, i) => {
      const shown = !!openSolutions[i];
      return `
        <div class="card lesson-content">
          <h3 style="margin-top:0;">Exercice ${i + 1} : ${ex.title}</h3>
          <p>${ex.prompt}</p>
          <button class="btn btn-sm btn-outline" onclick="toggleSolution(${i})">
            ${shown ? "🙈 Masquer la correction" : "👁️ Voir la correction"}
          </button>
          ${shown ? `<div class="solution-box"><strong>Correction :</strong><br/>${ex.solution}</div>` : ""}
        </div>`;
    }).join("")}
    <button class="btn" onclick="startQuiz('${c.id}')">🎯 Tester mes acquis avec le Quiz</button>
  `;
}

function renderQuiz(courseId) {
  const c = COURSES.find(x => x.id === courseId);
  if (!quizSession) quizSession = { idx: 0, score: 0, selected: null };
  if (quizSession.idx >= c.quiz.length) {
    const pct = Math.round((quizSession.score / c.quiz.length) * 100);
    return `
      <div class="card" style="text-align:center; padding:26px 16px;">
        <div style="font-size:44px; margin-bottom:8px;">${pct >= 70 ? "🏆" : "📘"}</div>
        <h2 style="margin-bottom:6px; color:var(--gold-light);">Quiz terminé !</h2>
        <p style="font-size:16px; margin-bottom:14px;">Score : <strong>${quizSession.score} / ${c.quiz.length} (${pct}%)</strong></p>
        <button class="btn" onclick="restartQuiz('${c.id}')" style="margin-bottom:10px;">🔄 Recommencer</button>
        <button class="btn btn-outline" onclick="goBack()">Retour au module</button>
      </div>`;
  }
  const q = c.quiz[quizSession.idx];
  const answered = quizSession.selected !== null;
  return `
    <div class="card">
      <div style="font-size:12px; color:var(--gold-light); margin-bottom:8px; font-weight:700;">Question ${quizSession.idx + 1} / ${c.quiz.length}</div>
      <h3 style="font-size:16px; line-height:1.45; margin-bottom:14px;">${q.q}</h3>
      ${q.options.map((opt, i) => {
        let cls = "option-btn";
        if (answered) {
          if (i === q.answer) cls += " correct";
          else if (i === quizSession.selected) cls += " wrong";
        }
        return `<button class="${cls}" ${answered ? "disabled" : ""} onclick="answerQuiz('${c.id}', ${i})">${opt}</button>`;
      }).join("")}
      ${answered ? `
        <div class="explanation"><strong>${quizSession.selected === q.answer ? "✅ Exact !" : "❌ Incorrect."}</strong><br/>${q.explanation}</div>
        <button class="btn" onclick="nextQuestion('${c.id}')">${quizSession.idx + 1 < c.quiz.length ? "Suivant ➔" : "Voir mon score 🎯"}</button>
      ` : ""}
    </div>`;
}

function openCourse(id) { pushView({ type: "course", courseId: id }); }
function openLesson(id, idx) { pushView({ type: "lesson", courseId: id, chapterIndex: idx }); }
function openExercises(id) { openSolutions = {}; pushView({ type: "exercises", courseId: id }); }
function openNextLesson(id, idx) { viewStack[viewStack.length - 1] = { type: "lesson", courseId: id, chapterIndex: idx }; render(); window.scrollTo(0, 0); }
function toggleSolution(i) { openSolutions[i] = !openSolutions[i]; render(); }
function startQuiz(id) { quizSession = { idx: 0, score: 0, selected: null }; pushView({ type: "quiz", courseId: id }); }
function restartQuiz(id) { quizSession = { idx: 0, score: 0, selected: null }; render(); }

function answerQuiz(courseId, optionIdx) {
  const c = COURSES.find(x => x.id === courseId);
  quizSession.selected = optionIdx;
  if (optionIdx === c.quiz[quizSession.idx].answer) quizSession.score++;
  render();
}

function nextQuestion(courseId) {
  const c = COURSES.find(x => x.id === courseId);
  quizSession.idx++; quizSession.selected = null;
  if (quizSession.idx >= c.quiz.length) {
    const pct = Math.round((quizSession.score / c.quiz.length) * 100);
    if (pct >= (state.quizScores[c.id] || 0)) state.quizScores[c.id] = pct;
    saveState();
  }
  render();
}

function markChapterDone(chId) {
  if (!state.completedChapters.includes(chId)) { state.completedChapters.push(chId); saveState(); render(); }
}

function toggleFav(courseId) {
  const i = state.favorites.indexOf(courseId);
  if (i >= 0) state.favorites.splice(i, 1); else state.favorites.push(courseId);
  saveState(); render();
}

function setCategory(cat) { selectedCategory = cat; render(); }
function onSearch(val) { searchQuery = val; render(); }

function saveProfileForm() {
  const n = document.getElementById("profName").value.trim();
  const l = document.getElementById("profLevel").value;
  if (n) state.profile.name = n;
  state.profile.level = l;
  saveState();
  alert("Profil enregistré !");
}

function toggleThemeMode() { state.profile.light = !state.profile.light; applyTheme(); saveState(); render(); }

function resetAll() {
  if (confirm("Voulez-vous effacer toute votre progression ?")) {
    state = JSON.parse(JSON.stringify(DEFAULT_STATE));
    applyTheme(); saveState(); render();
  }
}

function copyCode(btn) {
  const text = btn.closest(".code-box").querySelector("pre").innerText;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      btn.textContent = "Copié !";
      setTimeout(() => btn.textContent = "Copier", 1500);
    });
  } else { btn.textContent = "Sélectionnez le texte"; }
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[s]));
}

applyTheme();
render();