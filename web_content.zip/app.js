let balance=0, txs=[];
const auth=document.getElementById('authScreen'), app=document.getElementById('appScreen');
const modal=document.getElementById('modal'), content=document.getElementById('modalContent');
function show(html){content.innerHTML=html;modal.classList.remove('hidden')}
function close(){modal.classList.add('hidden')}
document.getElementById('close').onclick=close;
modal.addEventListener('click',e=>{if(e.target===modal)close()});
function money(n){return n.toLocaleString('en-US')+' ل.س'}
function render(){document.getElementById('balance').textContent=money(balance);const box=document.getElementById('transactions');box.innerHTML=txs.length?txs.slice(0,4).map(t=>`<div class="tx"><div>${t.title}<small>${t.date}</small></div><b>${t.amount}</b></div>`).join(''):'<p class="muted">لا توجد عمليات بعد.</p>'}
function history(){show('<h2>سجل الحركات</h2><p class="muted">سجل عمليات محفظتك.</p>'+(txs.length?txs.map(t=>`<div class="tx"><div>${t.title}<small>${t.date}</small></div><b>${t.amount}</b></div>`).join(''):'<p>لا توجد عمليات بعد.</p>'))}
function addTx(title,amount){txs.unshift({title,amount,date:new Date().toLocaleString('ar')});render()}
document.getElementById('registerForm').addEventListener('submit',e=>{
 e.preventDefault();const name=document.getElementById('fullName').value.trim(), phone=document.getElementById('phone').value.trim(), country=document.getElementById('country').value;
 if(!name||!phone){alert('أكمل الاسم ورقم الهاتف');return}
 // Demo only: no password is stored and no account is created on a server.
 document.getElementById('hello').textContent='أهلاً '+name+' 👋';
 auth.classList.add('hidden');app.classList.remove('hidden');render();
});
function action(a){
 if(a==='send')show('<h2>إرسال بالرقم</h2><div class="notice">خدمة التحويل تُفعّل بعد ربط نظام الحوالات.</div><input id="recipient" class="field" placeholder="رقم هاتف المستلم مع رمز الدولة"><input id="amount" class="field" type="number" min="1" placeholder="المبلغ بالليرة السورية"><button class="primary" id="confirm">تأكيد تجريبي</button>');
 if(a==='scan')show('<h2>مسح رمز QR</h2><div class="qr-demo">▦<br><small>رمز QR</small></div><div class="notice">خدمة المسح والتحويل تُفعّل بعد ربط نظام الحوالات.</div>');
 if(a==='receive')show('<h2>استقبال حوالة</h2><p>سيظهر رقم محفظتك ورمز الاستقبال بعد تفعيل الحساب وربطه بنظام الحوالات.</p>');
 if(a==='topup')show('<h2>شحن المحفظة</h2><p>يمكنك شحن محفظتك من مكتب الحوالات بعد تفعيل الربط الإلكتروني.</p><div class="notice">خدمة الشحن غير مفعّلة بعد.</div>');\n if(a==='history')history();
 document.getElementById('confirm')?.addEventListener('click',()=>{let n=Number(document.getElementById('amount').value),r=document.getElementById('recipient').value.trim();if(!Number.isFinite(n)||n<=0){alert('أدخل مبلغاً صحيحاً');return}if(n>balance){alert('الرصيد التجريبي غير كافٍ');return}if(!r){alert('أدخل رقم المستلم');return}balance-=n;addTx('إرسال تجريبي إلى '+r,'− '+money(n));close()});
}
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>action(b.dataset.action)));
document.getElementById('allHistory').onclick=history;
document.getElementById('profileBtn').onclick=()=>show('<h2>حسابي</h2><div class="notice">إدارة بيانات الحساب.</div>');
document.getElementById('helpBtn').onclick=()=>show('<h2>المساعدة</h2><p>شام سوريا — محفظتك الرقمية.</p><div class="notice">خدمات الشحن والتحويل تُتاح بعد ربط النظام المالي.</div>');
