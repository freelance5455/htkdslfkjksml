const message = document.getElementById("message");

function setStatus(id, text) {
  document.getElementById(id).textContent = text;
}
function tell(text) {
  message.textContent = text;
}

async function testCamera() {
  if (!navigator.mediaDevices?.getUserMedia) {
    tell("Camera access is unavailable here. Use HTTPS and a supported Android WebView.");
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    stream.getTracks().forEach(track => track.stop());
    setStatus("camera-status", "Permission granted");
    tell("Camera permission granted. The camera was not recorded.");
  } catch (error) {
    setStatus("camera-status", error.name === "NotAllowedError" ? "Permission denied" : "Unavailable");
    tell(error.name === "NotAllowedError" ? "Camera permission was denied." : "Camera could not be opened.");
  }
}

async function testMicrophone() {
  if (!navigator.mediaDevices?.getUserMedia) {
    tell("Microphone access is unavailable here. Use HTTPS and a supported Android WebView.");
    return;
  }
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
    stream.getTracks().forEach(track => track.stop());
    setStatus("mic-status", "Permission granted");
    tell("Microphone permission granted. No audio was recorded or saved.");
  } catch (error) {
    setStatus("mic-status", error.name === "NotAllowedError" ? "Permission denied" : "Unavailable");
    tell(error.name === "NotAllowedError" ? "Microphone permission was denied." : "Microphone could not be opened.");
  }
}

function testLocation() {
  if (!("geolocation" in navigator)) {
    tell("Location access is unavailable in this browser or app.");
    return;
  }
  setStatus("location-status", "Waiting for permission…");
  navigator.geolocation.getCurrentPosition(
    () => {
      setStatus("location-status", "Permission granted");
      tell("Location permission granted. This demo does not save or send your location.");
    },
    error => {
      setStatus("location-status", error.code === 1 ? "Permission denied" : "Unavailable");
      tell(error.code === 1 ? "Location permission was denied." : "Location could not be checked. Check device location settings.");
    },
    { enableHighAccuracy: false, timeout: 10000, maximumAge: 0 }
  );
}

document.querySelectorAll("button[data-action]").forEach(button => {
  button.addEventListener("click", () => {
    const action = button.dataset.action;
    if (action === "camera") testCamera();
    if (action === "mic") testMicrophone();
    if (action === "location") testLocation();
  });
});
