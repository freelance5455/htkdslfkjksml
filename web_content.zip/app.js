/**
 * Maa Annapurna Tiffin Service - Core Business Logic
 * Location: Kunwar Singh Nagar | Phone: +91 9311155593
 * 6-Digit Box QR Codes, Cash Collection & WhatsApp Payment QR Link
 */

// ==========================================
// STORAGE KEYS & GLOBAL STATE
// ==========================================
const STORAGE_KEYS = {
  CLIENTS: 'annapurna_clients_v2',
  LOGS: 'annapurna_logs_v2',
  BOX_STATE: 'annapurna_box_state_v2',
  SETTINGS: 'annapurna_settings_v2',
  WEEKLY_MENU: 'annapurna_weekly_menu_v2',
  CUSTOM_MENUS: 'annapurna_custom_menus_v2',
  EXTRA_ITEMS: 'annapurna_extra_items_v2'
};

let clients = [];
let logs = [];
let boxStates = {}; 
let settings = {
  bizName: 'Maa Annapurna Tiffin Service',
  bizPhone: '+91 9311155593',
  bizAddress: 'Kunwar Singh Nagar',
  bizEmail: 'annapurna.tiffin@gmail.com',
  defaultPrice: 2500,
  upiId: '9311155593@paytm',
  qrPrefix: 'MAT' // 6-digit default: MAT001 to MAT150
};

// Weekly Menu (Monday to Saturday) - Lunch & Dinner
let weeklyMenu = {
  monday: {
    lunch: {
      title: 'Monday Special Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Shahi Paneer\n2). 🍲 Kali Masoor Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 🍋🟩 Achar/Chutney 🍀`
    },
    dinner: {
      title: 'Monday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Seasonal Mix Veg Curry\n2). 🍲 Arhar Daal Fry Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Basmati Rice\n5). 🥗 Fresh Green Salad\n6). 😋 Achar`
    }
  },
  tuesday: {
    lunch: {
      title: 'Tuesday Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Dal Makhani\n2). 🍲 Aloo Gobhi Matar Masala\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 🍋 Achar & Papad`
    },
    dinner: {
      title: 'Tuesday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Matar Paneer / Lauki Chana Daal\n2). 🍲 Moong Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Rice\n5). 🥗 Fresh Salad\n6). 😋 Achar`
    }
  },
  wednesday: {
    lunch: {
      title: 'Wednesday Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Special Kadi Pakoda\n2). 🍲 Mix Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 😋 Achar`
    },
    dinner: {
      title: 'Wednesday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Aloo Shimla Mirch / Baingan Bharta\n2). 🍲 Chana Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Rice\n5). 🥗 Fresh Salad\n6). 🍋 Achar`
    }
  },
  thursday: {
    lunch: {
      title: 'Thursday Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Rajma Masala\n2). 🍲 Bundi Raita Or Arhar Daal Tadka (any one of your choice 😋)\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 🍋🟩 Achar/Chutney 🍀`
    },
    dinner: {
      title: 'Thursday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Sev Tamatar Ki Sabzi / Paneer Bhurji\n2). 🍲 Yellow Moong Daal\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Rice\n5). 🥗 Fresh Salad\n6). 😋 Achar`
    }
  },
  friday: {
    lunch: {
      title: 'Friday Special Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 90,
      items: `1). 🥘 Paneer Butter Masala\n2). 🍲 Yellow Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad 🥒\n6). 🍋 Achar & Chutney`
    },
    dinner: {
      title: 'Friday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Bhindi Masala Do Pyaza\n2). 🍲 Panchmel Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Steamed Rice\n5). 🥗 Fresh Salad\n6). 😋 Achar`
    }
  },
  saturday: {
    lunch: {
      title: 'Saturday Lunch Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 80,
      items: `1). 🥘 Amritsari Chole Masala\n2). 🍲 Jeera Aloo\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Veg Pulao\n5). 🥗 Fresh Salad 🥒\n6). 😋 Achar/Chutney`
    },
    dinner: {
      title: 'Saturday Dinner Menu',
      tagline: 'Fresh . Hygienic . Homemade . Delicious',
      price: 85,
      items: `1). 🥘 Palak Paneer / Kadai Veg\n2). 🍲 Toor Daal Tadka\n3). 🫓 Fresh Tawa Roti with Desi Ghee\n4). 🍚 Jeera Rice\n5). 🥗 Fresh Salad\n6). 🍨 Gulab Jamun`
    }
  }
};

let customMenus = [
  {
    id: 'cmenu-1',
    title: 'Maa Annapurna Deluxe Thali',
    mealType: 'both',
    tagline: 'Special Occasion Feast',
    price: 130,
    items: `1). 🥘 Kadhai Paneer\n2). 🍲 Dal Makhani\n3). 🫓 4 Tawa Roti with Pure Desi Ghee\n4). 🍚 Matar Pulao\n5). 🥣 Boondi Raita\n6). 🍨 Gulab Jamun (2 Pcs)`
  }
];

let extraItemsCatalog = [
  { id: 'ext-1', name: 'Extra Tawa Roti with Desi Ghee', price: 10, unit: 'pc' },
  { id: 'ext-2', name: 'Boondi Raita / Fresh Curd', price: 20, unit: 'cup' },
  { id: 'ext-3', name: 'Sweet Dish (Gulab Jamun)', price: 20, unit: 'pc' },
  { id: 'ext-4', name: 'Extra Sabzi Portion', price: 35, unit: 'portion' },
  { id: 'ext-5', name: 'Masala Buttermilk (Chaas)', price: 15, unit: 'bottle' },
  { id: 'ext-6', name: 'Extra Jeera Rice', price: 25, unit: 'portion' }
];

let currentTab = 'dashboard';
let currentDate = new Date().toISOString().split('T')[0];
let currentSelectedMenuDay = 'monday';
let currentMenuMealType = 'lunch';
let scannerInstance = null;
let currentScanMode = 'dispatch';
let paymentFilter = 'all';
let deferredPrompt = null;
let upiQrCodeInstance = null;

// Initialize on Load
document.addEventListener('DOMContentLoaded', () => {
  loadData();
  setupDates();
  setInitialDayFromCurrentDate();
  renderDashboard();
  renderMenuPlanner();
  renderCustomMenusList();
  renderExtraItemsCatalog();
  renderClientList();
  renderPendingList();
  renderPaymentsList();
  renderSettings();
  generateQRStickers();
  setupPwa();
  lucide.createIcons();
});

function loadData() {
  try {
    const storedClients = localStorage.getItem(STORAGE_KEYS.CLIENTS);
    const storedLogs = localStorage.getItem(STORAGE_KEYS.LOGS);
    const storedBoxes = localStorage.getItem(STORAGE_KEYS.BOX_STATE);
    const storedSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    const storedWeeklyMenu = localStorage.getItem(STORAGE_KEYS.WEEKLY_MENU);
    const storedCustomMenus = localStorage.getItem(STORAGE_KEYS.CUSTOM_MENUS);
    const storedExtras = localStorage.getItem(STORAGE_KEYS.EXTRA_ITEMS);

    if (storedClients) clients = JSON.parse(storedClients);
    if (storedLogs) logs = JSON.parse(storedLogs);
    if (storedBoxes) boxStates = JSON.parse(storedBoxes);
    if (storedSettings) settings = { ...settings, ...JSON.parse(storedSettings) };
    if (storedWeeklyMenu) {
      const parsed = JSON.parse(storedWeeklyMenu);
      delete parsed.sunday;
      weeklyMenu = { ...weeklyMenu, ...parsed };
    }
    if (storedCustomMenus) customMenus = JSON.parse(storedCustomMenus);
    if (storedExtras) extraItemsCatalog = JSON.parse(storedExtras);

    if (clients.length === 0) {
      loadInitialDefaults();
    }
  } catch (err) {
    console.error('Error loading data:', err);
  }
}

function loadInitialDefaults() {
  // Uses clean 6-digit box codes: MAT001 to MAT004
  clients = [
    {
      id: 'c-1',
      name: 'Mr. Rahul Sharma',
      phone: '9823412345',
      address: 'House 42, Kunwar Singh Nagar',
      area: 'Kunwar Singh Nagar',
      boxId: 'MAT001',
      mealType: 'Lunch',
      price: 2500,
      paymentStatus: 'pending',
      dueAmount: 2500,
      startDate: currentDate,
      status: 'active'
    },
    {
      id: 'c-2',
      name: 'Mrs. Pooja Verma',
      phone: '9898765432',
      address: 'Shop No. 12, Main Market Road',
      area: 'Market Complex',
      boxId: 'MAT002',
      mealType: 'Both',
      price: 4500,
      paymentStatus: 'paid',
      dueAmount: 0,
      startDate: currentDate,
      status: 'active'
    },
    {
      id: 'c-3',
      name: 'Mr. Rohan Gupta',
      phone: '9711223344',
      address: 'Plot 55, Near Temple, Kunwar Singh Nagar',
      area: 'Kunwar Singh Nagar',
      boxId: 'MAT003',
      mealType: 'Lunch',
      price: 2600,
      paymentStatus: 'paid',
      dueAmount: 0,
      startDate: currentDate,
      status: 'active'
    },
    {
      id: 'c-4',
      name: 'Mr. Sunil Mehta',
      phone: '9833445566',
      address: 'C-34, Industrial Area Phase 1',
      area: 'Industrial Area',
      boxId: 'MAT004',
      mealType: 'Dinner',
      price: 2500,
      paymentStatus: 'pending',
      dueAmount: 1800,
      startDate: currentDate,
      status: 'active'
    }
  ];

  const now = new Date();
  const time1 = new Date(now.getTime() - 3.5 * 3600 * 1000).toISOString();
  const time2 = new Date(now.getTime() - 25 * 3600 * 1000).toISOString();

  boxStates['MAT001'] = {
    status: 'with_client',
    clientId: 'c-1',
    clientName: 'Mr. Rahul Sharma',
    clientPhone: '9823412345',
    clientAddress: 'House 42, Kunwar Singh Nagar',
    dispatchedAt: time1,
    mealCategory: 'Lunch',
    menuTitle: weeklyMenu.monday.lunch.title,
    menuItems: 'Shahi Paneer, Kali Masoor Daal Tadka, 4 Tawa Roti, Jeera Rice, Salad, Achar',
    extras: '1x Sweet Dish (Gulab Jamun)',
    price: 100,
    paymentMode: 'due'
  };

  boxStates['MAT004'] = {
    status: 'with_client',
    clientId: 'c-4',
    clientName: 'Mr. Sunil Mehta',
    clientPhone: '9833445566',
    clientAddress: 'C-34, Industrial Area',
    dispatchedAt: time2,
    mealCategory: 'Dinner',
    menuTitle: weeklyMenu.thursday.dinner.title,
    menuItems: 'Sev Tamatar Ki Sabzi, Moong Daal, 4 Roti, Rice, Salad',
    extras: 'None',
    price: 80,
    paymentMode: 'due'
  };

  logs = [
    {
      id: 'log-1',
      timestamp: time1,
      date: currentDate,
      boxId: 'MAT001',
      clientId: 'c-1',
      clientName: 'Mr. Rahul Sharma',
      mealCategory: 'Lunch',
      menuTitle: weeklyMenu.monday.lunch.title,
      menuItems: 'Shahi Paneer, Kali Masoor Daal Tadka, 4 Roti, Jeera Rice, Salad, Achar',
      extras: '1x Sweet Dish (Gulab Jamun)',
      price: 100,
      paymentMode: 'cash',
      type: 'dispatch'
    },
    {
      id: 'log-2',
      timestamp: time2,
      date: new Date(Date.now() - 25 * 3600 * 1000).toISOString().split('T')[0],
      boxId: 'MAT004',
      clientId: 'c-4',
      clientName: 'Mr. Sunil Mehta',
      mealCategory: 'Dinner',
      menuTitle: weeklyMenu.thursday.dinner.title,
      menuItems: 'Sev Tamatar Ki Sabzi, Moong Daal, 4 Roti, Rice, Salad',
      extras: 'None',
      price: 80,
      paymentMode: 'due',
      type: 'dispatch'
    }
  ];

  saveData();
}

function saveData() {
  localStorage.setItem(STORAGE_KEYS.CLIENTS, JSON.stringify(clients));
  localStorage.setItem(STORAGE_KEYS.LOGS, JSON.stringify(logs));
  localStorage.setItem(STORAGE_KEYS.BOX_STATE, JSON.stringify(boxStates));
  localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  localStorage.setItem(STORAGE_KEYS.WEEKLY_MENU, JSON.stringify(weeklyMenu));
  localStorage.setItem(STORAGE_KEYS.CUSTOM_MENUS, JSON.stringify(customMenus));
  localStorage.setItem(STORAGE_KEYS.EXTRA_ITEMS, JSON.stringify(extraItemsCatalog));
}

function setupDates() {
  const dateInput = document.getElementById('dashDateSelector');
  if (dateInput) dateInput.value = currentDate;
  
  const todayLabel = document.getElementById('todayDateStr');
  const d = new Date();
  const options = { weekday: 'short', day: 'numeric', month: 'short' };
  if (todayLabel) todayLabel.textContent = d.toLocaleDateString('en-US', options);

  const clientStartDate = document.getElementById('clientStartDate');
  if (clientStartDate) clientStartDate.value = currentDate;
}

function setInitialDayFromCurrentDate() {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const dayIndex = new Date().getDay();
  const todayName = days[dayIndex];

  if (todayName === 'sunday') {
    currentSelectedMenuDay = 'monday';
  } else {
    currentSelectedMenuDay = todayName;
  }
}

function changeDate(newDate) {
  currentDate = newDate;
  renderDashboard();
}

// ==========================================
// NAVIGATION & TABS
// ==========================================
function switchTab(tabId) {
  currentTab = tabId;
  document.querySelectorAll('.tab-content').forEach(el => el.classList.add('hidden'));
  const activeContent = document.getElementById(`tab-${tabId}`);
  if (activeContent) activeContent.classList.remove('hidden');

  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('text-orange-600', 'font-semibold');
    btn.classList.add('text-slate-500');
  });

  const activeNavBtn = document.getElementById(`nav-${tabId}`);
  if (activeNavBtn) {
    activeNavBtn.classList.remove('text-slate-500');
    activeNavBtn.classList.add('text-orange-600', 'font-semibold');
  }

  if (tabId === 'dashboard') renderDashboard();
  if (tabId === 'menu') {
    renderMenuPlanner();
    renderCustomMenusList();
  }
  if (tabId === 'pending') renderPendingList();
  if (tabId === 'clients') renderClientList();
  if (tabId === 'payments') renderPaymentsList();
  if (tabId === 'qrgenerator') generateQRStickers();
  if (tabId === 'settings') renderSettings();

  lucide.createIcons();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ==========================================
// AUDIO BEEP FEEDBACK
// ==========================================
function playBeepSound(type = 'success') {
  try {
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (type === 'success') {
      osc.frequency.setValueAtTime(850, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1350, audioCtx.currentTime + 0.14);
      gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.18);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.18);
    } else {
      osc.frequency.setValueAtTime(400, audioCtx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(260, audioCtx.currentTime + 0.25);
      gain.gain.setValueAtTime(0.25, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.28);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.28);
    }
  } catch (e) {}
}

// ==========================================
// DASHBOARD LOGIC (OPERATIONS & CASH VS UPI)
// ==========================================
function renderDashboard() {
  document.getElementById('headerBizName').textContent = settings.bizName;
  document.getElementById('headerSubtitle').textContent = `${settings.bizAddress} • ${settings.bizPhone}`;

  const dayLogs = logs.filter(l => l.date === currentDate);
  const dispatchedToday = dayLogs.filter(l => l.type === 'dispatch').length;
  const collectedToday = dayLogs.filter(l => l.type === 'collect').length;

  // Calculate Cash vs UPI today
  const cashToday = dayLogs.reduce((sum, l) => sum + (l.paymentMode === 'cash' ? (Number(l.price) || 0) : 0), 0);
  const upiToday = dayLogs.reduce((sum, l) => sum + (l.paymentMode === 'upi' ? (Number(l.price) || 0) : 0), 0);

  const pendingBoxes = Object.entries(boxStates).filter(([_, state]) => state.status === 'with_client');
  const pendingCount = pendingBoxes.length;

  const totalDues = clients.reduce((sum, c) => sum + (c.paymentStatus === 'pending' ? (Number(c.dueAmount) || 0) : 0), 0);

  document.getElementById('statDispatchedToday').textContent = dispatchedToday;
  document.getElementById('statCollectedToday').textContent = collectedToday;
  document.getElementById('statPendingCount').textContent = pendingCount;
  document.getElementById('statPendingPayments').textContent = `₹${totalDues.toLocaleString('en-IN')}`;
  
  const cashDisplay = document.getElementById('statCashToday');
  const upiDisplay = document.getElementById('statUpiToday');
  if (cashDisplay) cashDisplay.textContent = `₹${cashToday.toLocaleString('en-IN')}`;
  if (upiDisplay) upiDisplay.textContent = `₹${upiToday.toLocaleString('en-IN')}`;

  // Menu Preview
  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  document.getElementById('dashTodayDayName').textContent = `${capitalize(currentSelectedMenuDay)}'s Menus:`;

  const lunchFirst = daySchedule.lunch.items.split('\n')[0] || 'Special Lunch Thali';
  const dinnerFirst = daySchedule.dinner.items.split('\n')[0] || 'Special Dinner Thali';
  document.getElementById('quickLunchPreviewText').textContent = `${lunchFirst.replace(/^[0-9]\)\.\s*/, '')} (₹${daySchedule.lunch.price})`;
  document.getElementById('quickDinnerPreviewText').textContent = `${dinnerFirst.replace(/^[0-9]\)\.\s*/, '')} (₹${daySchedule.dinner.price})`;

  // Nav Pending Badge
  const navBadge = document.getElementById('navPendingBadge');
  if (pendingCount > 0) {
    navBadge.textContent = pendingCount;
    navBadge.classList.remove('hidden');
  } else {
    navBadge.classList.add('hidden');
  }

  // Pending Alert Banner
  const alertBanner = document.getElementById('pendingAlertBanner');
  if (pendingCount > 0) {
    alertBanner.classList.remove('hidden');
    document.getElementById('bannerPendingTitle').textContent = `Action Required: ${pendingCount} Tiffin Containers Unreturned`;
  } else {
    alertBanner.classList.add('hidden');
  }

  // Recent Activity Log
  const activityList = document.getElementById('recentActivityList');
  const recentLogs = [...logs].reverse().slice(0, 10);
  document.getElementById('activityCount').textContent = `${logs.length} Entries`;

  if (recentLogs.length === 0) {
    activityList.innerHTML = `
      <div class="text-center py-6 text-slate-400 text-xs">
        No meal dispatches recorded for today yet. Tap "Dispatch Tiffin" to scan and deliver!
      </div>
    `;
  } else {
    activityList.innerHTML = recentLogs.map(log => {
      const isDispatch = log.type === 'dispatch';
      const timeStr = new Date(log.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
      return `
        <div class="py-2.5 flex items-start justify-between">
          <div class="flex items-start space-x-3">
            <div class="w-8 h-8 rounded-xl ${isDispatch ? 'bg-emerald-100 text-emerald-700' : 'bg-blue-100 text-blue-700'} flex items-center justify-center text-sm font-bold mt-0.5">
              ${isDispatch ? '↗️' : '↙️'}
            </div>
            <div>
              <div class="text-xs font-bold text-slate-900 flex items-center space-x-1.5">
                <span>${log.clientName || 'Client'}</span>
                <span class="box-code-badge text-[10px] py-0.5 px-2">${log.boxId}</span>
                ${log.mealCategory ? `<span class="badge-soft-orange px-1.5 py-0.2 text-[9px] font-bold rounded uppercase">${log.mealCategory}</span>` : ''}
                ${log.price ? `<span class="badge-soft-emerald px-1.5 py-0.2 text-[10px] font-bold rounded">₹${log.price}</span>` : ''}
                ${log.paymentMode === 'cash' ? `<span class="text-[9px] font-bold bg-amber-100 text-amber-800 px-1 py-0.2 rounded">💵 CASH</span>` : ''}
              </div>
              <div class="text-[11px] text-slate-500 mt-0.5">
                ${isDispatch ? (log.menuTitle || 'Meal Dispatched') : 'Empty Box Collected'}
                ${log.extras && log.extras !== 'None' ? `<span class="text-emerald-700 font-semibold block text-[10px]">+ Extras: ${log.extras}</span>` : ''}
              </div>
            </div>
          </div>
          <div class="text-right">
            <span class="text-[11px] font-semibold text-slate-500">${timeStr}</span>
          </div>
        </div>
      `;
    }).join('');
  }

  lucide.createIcons();
}

// ==========================================
// WEEKLY MENU (LUNCH vs DINNER)
// ==========================================
function selectMenuDay(dayKey) {
  currentSelectedMenuDay = dayKey;
  
  document.querySelectorAll('#weeklyDayPills .day-pill').forEach(btn => btn.classList.remove('active'));
  const daysArray = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const pillIndex = daysArray.indexOf(dayKey);
  const pill = document.querySelectorAll('#weeklyDayPills .day-pill')[pillIndex];
  if (pill) pill.classList.add('active');

  renderMenuPlanner();
}

function toggleMenuMealType(type) {
  currentMenuMealType = type;
  const btnLunch = document.getElementById('toggleLunchTabBtn');
  const btnDinner = document.getElementById('toggleDinnerTabBtn');

  if (type === 'lunch') {
    btnLunch.className = 'flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 bg-white text-orange-600 shadow-2xs';
    btnDinner.className = 'flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 text-slate-600';
  } else {
    btnDinner.className = 'flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 bg-white text-blue-600 shadow-2xs';
    btnLunch.className = 'flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 text-slate-600';
  }

  renderMenuPlanner();
}

function renderMenuPlanner() {
  const dayObj = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const mealObj = dayObj[currentMenuMealType] || dayObj.lunch;

  document.getElementById('currentDayMenuTitle').textContent = `${capitalize(currentSelectedMenuDay)} ${capitalize(currentMenuMealType)} Menu`;
  document.getElementById('currentDayTagline').textContent = mealObj.tagline || 'Fresh . Hygienic . Homemade . Delicious';
  document.getElementById('currentDayPrice').value = mealObj.price;
  document.getElementById('currentDayItems').value = mealObj.items;
}

function saveCurrentDayMenu() {
  const dayObj = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const mealObj = dayObj[currentMenuMealType] || dayObj.lunch;

  mealObj.price = Number(document.getElementById('currentDayPrice').value) || 80;
  mealObj.items = document.getElementById('currentDayItems').value.trim();

  saveData();
  renderDashboard();

  Swal.fire({
    icon: 'success',
    title: 'Menu Saved!',
    text: `${capitalize(currentSelectedMenuDay)} ${capitalize(currentMenuMealType)} menu updated.`,
    timer: 1500,
    showConfirmButton: false
  });
}

// Custom Menus
function renderCustomMenusList() {
  const container = document.getElementById('customMenusList');
  if (!container) return;

  if (customMenus.length === 0) {
    container.innerHTML = `
      <div class="p-3 text-center text-xs text-slate-400 bg-slate-50 rounded-xl">
        No custom menus created yet. Tap "+ Create Menu" to add special thalis.
      </div>
    `;
    return;
  }

  container.innerHTML = customMenus.map(m => `
    <div class="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
      <div class="flex items-start justify-between">
        <div>
          <div class="flex items-center space-x-2">
            <h4 class="text-xs font-bold text-slate-900">${m.title}</h4>
            <span class="badge-soft-orange px-1.5 py-0.2 rounded text-[9px] font-bold uppercase">${m.mealType || 'Both'}</span>
          </div>
          <span class="text-[10px] text-slate-500">${m.tagline || 'Special Thali'}</span>
        </div>
        <div class="flex items-center space-x-1">
          <span class="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">₹${m.price}</span>
          <button onclick="editCustomMenu('${m.id}')" class="text-slate-400 hover:text-orange-600 p-1"><i data-lucide="edit-2" class="w-3.5 h-3.5"></i></button>
          <button onclick="deleteCustomMenu('${m.id}')" class="text-slate-400 hover:text-red-600 p-1"><i data-lucide="trash-2" class="w-3.5 h-3.5"></i></button>
        </div>
      </div>
      <p class="text-[11px] text-slate-600 font-mono whitespace-pre-line bg-white p-2 rounded-lg border border-slate-100">${m.items}</p>
    </div>
  `).join('');

  lucide.createIcons();
}

function openCreateMenuModal(menu = null) {
  const modal = document.getElementById('customMenuModal');
  const title = document.getElementById('customMenuModalTitle');
  const form = document.getElementById('customMenuForm');
  form.reset();

  if (menu) {
    title.textContent = 'Edit Menu';
    document.getElementById('customMenuId').value = menu.id;
    document.getElementById('customMenuTitle').value = menu.title;
    document.getElementById('customMenuMealType').value = menu.mealType || 'both';
    document.getElementById('customMenuTagline').value = menu.tagline || '';
    document.getElementById('customMenuPrice').value = menu.price;
    document.getElementById('customMenuItems').value = menu.items;
  } else {
    title.textContent = 'Create New Menu';
    document.getElementById('customMenuId').value = '';
    document.getElementById('customMenuPrice').value = 85;
    document.getElementById('customMenuMealType').value = 'lunch';
    document.getElementById('customMenuTagline').value = 'Fresh . Hygienic . Homemade';
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeCustomMenuModal() {
  document.getElementById('customMenuModal').classList.add('hidden');
}

function saveCustomMenu(event) {
  event.preventDefault();
  const id = document.getElementById('customMenuId').value;
  const title = document.getElementById('customMenuTitle').value.trim();
  const mealType = document.getElementById('customMenuMealType').value;
  const tagline = document.getElementById('customMenuTagline').value.trim();
  const price = Number(document.getElementById('customMenuPrice').value) || 85;
  const items = document.getElementById('customMenuItems').value.trim();

  if (id) {
    const idx = customMenus.findIndex(m => m.id === id);
    if (idx !== -1) customMenus[idx] = { id, title, mealType, tagline, price, items };
  } else {
    customMenus.push({
      id: 'cmenu-' + Date.now(),
      title,
      mealType,
      tagline,
      price,
      items
    });
  }

  saveData();
  closeCustomMenuModal();
  renderCustomMenusList();

  Swal.fire({ icon: 'success', title: 'Menu Saved!', timer: 1400, showConfirmButton: false });
}

function editCustomMenu(id) {
  const menu = customMenus.find(m => m.id === id);
  if (menu) openCreateMenuModal(menu);
}

function deleteCustomMenu(id) {
  Swal.fire({
    title: 'Delete Menu?',
    text: 'Do you want to remove this custom menu?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, Delete'
  }).then(res => {
    if (res.isConfirmed) {
      customMenus = customMenus.filter(m => m.id !== id);
      saveData();
      renderCustomMenusList();
    }
  });
}

// Extra Add-ons
function renderExtraItemsCatalog() {
  const container = document.getElementById('extraItemsCatalogList');
  if (!container) return;

  container.innerHTML = extraItemsCatalog.map(item => `
    <div class="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
      <div>
        <span class="font-bold text-slate-800">${item.name}</span>
        <span class="text-emerald-700 font-semibold block text-[11px]">₹${item.price} / ${item.unit}</span>
      </div>
      <button onclick="removeExtraItem('${item.id}')" class="text-slate-400 hover:text-red-600 p-1">
        <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
      </button>
    </div>
  `).join('');

  lucide.createIcons();
}

function promptAddNewExtraItem() {
  Swal.fire({
    title: 'Add Extra Item',
    html: `
      <div class="text-left text-xs space-y-2.5">
        <div>
          <label class="block font-semibold text-slate-700 mb-1">Item Name:</label>
          <input type="text" id="newExtraName" placeholder="e.g. Extra Roti, Gulab Jamun, Papad" class="w-full p-2 border border-slate-300 rounded-xl text-xs">
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Price (₹):</label>
            <input type="number" id="newExtraPrice" value="15" class="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold">
          </div>
          <div>
            <label class="block font-semibold text-slate-700 mb-1">Unit:</label>
            <input type="text" id="newExtraUnit" value="pc" class="w-full p-2 border border-slate-300 rounded-xl text-xs">
          </div>
        </div>
      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#ea580c',
    confirmButtonText: 'Add Item',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      const name = document.getElementById('newExtraName').value.trim();
      const price = Number(document.getElementById('newExtraPrice').value) || 15;
      const unit = document.getElementById('newExtraUnit').value.trim() || 'pc';

      if (!name) return;

      extraItemsCatalog.push({ id: 'ext-' + Date.now(), name, price, unit });
      saveData();
      renderExtraItemsCatalog();
      Swal.fire({ icon: 'success', title: 'Extra item added!', timer: 1200, showConfirmButton: false });
    }
  });
}

function removeExtraItem(id) {
  extraItemsCatalog = extraItemsCatalog.filter(x => x.id !== id);
  saveData();
  renderExtraItemsCatalog();
}

// WhatsApp Broadcast for Today's Lunch & Dinner Menu
function shareTodayMenuWhatsApp() {
  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const dateFormatted = new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const extrasText = extraItemsCatalog.slice(0, 4).map(x => `• ${x.name} (+₹${x.price})`).join('\n');

  const text = `🍱 *${settings.bizName.toUpperCase()}* 🍱
📍 *Address*: ${settings.bizAddress}
📅 *${capitalize(currentSelectedMenuDay)}'s Daily Menu* | ${dateFormatted}

☀️ *LUNCH MENU (दोपहर का भोजन)*:
${daySchedule.lunch.items}
💰 Price: ₹${daySchedule.lunch.price}/- per Thali

🌙 *DINNER MENU (रात्रि का भोजन)*:
${daySchedule.dinner.items}
💰 Price: ₹${daySchedule.dinner.price}/- per Thali

⭐ *Available Add-ons / Extras*:
${extrasText}

💳 *Online Payment Options*:
• UPI ID: ${settings.upiId} (GPay/PhonePe/Paytm)
• Scan UPI QR Code: https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi%3A%2F%2Fpay%3Fpa%3D${encodeURIComponent(settings.upiId)}%26pn%3DMaa%20Annapurna%20Tiffin%26cu%3DINR

📞 *For bookings and home delivery, call*: ${settings.bizPhone}
_Pure . Fresh . Hygienic . Homemade Taste!_ 🙏`;

  const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

// ==========================================
// PENDING TIFFINS (RETURN PICKUP TRACKER)
// ==========================================
function renderPendingList(searchFilter = '') {
  const container = document.getElementById('pendingListContainer');
  const pendingBoxes = Object.entries(boxStates)
    .filter(([_, state]) => state.status === 'with_client')
    .map(([boxId, state]) => ({ boxId, ...state }));

  let filtered = pendingBoxes;
  if (searchFilter.trim() !== '') {
    const q = searchFilter.toLowerCase();
    filtered = pendingBoxes.filter(item => 
      item.boxId.toLowerCase().includes(q) ||
      (item.clientName && item.clientName.toLowerCase().includes(q)) ||
      (item.clientAddress && item.clientAddress.toLowerCase().includes(q)) ||
      (item.clientPhone && item.clientPhone.includes(q))
    );
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="aesthetic-card p-8 text-center space-y-2">
        <div class="text-3xl">🎉</div>
        <h3 class="text-sm font-bold text-slate-800">All Tiffin Boxes Accounted For</h3>
        <p class="text-xs text-slate-500">Every dispatched 6-digit container has been returned safely.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(item => {
    const timeAgo = getTimeAgoText(item.dispatchedAt);
    const isOverdue = isOlderThan24Hours(item.dispatchedAt);

    return `
      <div class="aesthetic-card p-3.5 space-y-2.5 ${isOverdue ? 'border-red-300 bg-red-50/20' : ''}">
        <div class="flex items-start justify-between">
          <div class="flex items-start space-x-2.5">
            <span class="box-code-badge text-xs px-2.5 py-1">
              ${item.boxId}
            </span>
            <div>
              <div class="flex items-center space-x-1.5">
                <h4 class="text-xs font-bold text-slate-900">${item.clientName}</h4>
                ${item.mealCategory ? `<span class="badge-soft-orange px-1.5 py-0.2 rounded text-[9px] font-bold uppercase">${item.mealCategory}</span>` : ''}
              </div>
              <p class="text-[11px] text-slate-500 truncate max-w-[200px] sm:max-w-xs">${item.clientAddress || 'Address not listed'}</p>
              
              <div class="mt-1 text-[11px] text-slate-600 bg-slate-50 border border-slate-100 px-2 py-1 rounded-lg">
                <span class="font-semibold text-orange-700">${item.menuTitle || 'Special Thali'}:</span> 
                ${item.menuItems ? `<span class="text-slate-500 block truncate max-w-xs">${item.menuItems}</span>` : ''}
                ${item.extras && item.extras !== 'None' ? `<span class="text-emerald-700 font-semibold block text-[10.5px]">+ Extras: ${item.extras}</span>` : ''}
              </div>
            </div>
          </div>
          <span class="text-[10px] font-bold ${isOverdue ? 'badge-soft-red' : 'badge-soft-orange'} px-2 py-0.5 rounded-full whitespace-nowrap">
            ${timeAgo}
          </span>
        </div>

        <div class="grid grid-cols-3 gap-2 pt-1 border-t border-slate-100">
          <a href="tel:${item.clientPhone}" class="flex items-center justify-center py-2 px-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold">
            <i data-lucide="phone" class="w-3.5 h-3.5 mr-1 text-slate-600"></i>
            <span>Call</span>
          </a>

          <button onclick="sendProfessionalReturnNotice('${item.clientPhone}', '${item.clientName}', '${item.boxId}', '${item.clientAddress || ''}')" class="flex items-center justify-center py-2 px-2 badge-soft-emerald hover:bg-emerald-100 rounded-xl text-xs font-bold">
            <i data-lucide="message-circle" class="w-3.5 h-3.5 mr-1 text-emerald-600"></i>
            <span>WhatsApp</span>
          </button>

          <button onclick="markBoxReturned('${item.boxId}')" class="flex items-center justify-center py-2 px-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs">
            <i data-lucide="check" class="w-3.5 h-3.5 mr-1"></i>
            <span>Collect Box</span>
          </button>
        </div>
      </div>
    `;
  }).join('');

  lucide.createIcons();
}

function filterPendingList() {
  const query = document.getElementById('pendingSearchInput').value;
  renderPendingList(query);
}

function getTimeAgoText(isoString) {
  if (!isoString) return 'Delivered Today';
  const diffHours = Math.floor((Date.now() - new Date(isoString).getTime()) / (1000 * 60 * 60));
  if (diffHours < 1) return 'Just now';
  if (diffHours < 12) return `${diffHours}h ago`;
  if (diffHours < 24) return 'Earlier today';
  const days = Math.floor(diffHours / 24);
  return `${days}d overdue ⚠️`;
}

function isOlderThan24Hours(isoString) {
  if (!isoString) return false;
  const diffHours = (Date.now() - new Date(isoString).getTime()) / (1000 * 60 * 60);
  return diffHours >= 20;
}

// Professional WhatsApp Box Return Notice
function sendProfessionalReturnNotice(phone, clientName, boxId, address) {
  if (!phone) {
    Swal.fire({ icon: 'warning', title: 'Phone number unavailable' });
    return;
  }
  let cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length === 10) cleanPhone = '91' + cleanPhone;

  const msg = `Dear ${clientName},

Greetings from *${settings.bizName}* (Kunwar Singh Nagar)! 🙏

This is a gentle reminder regarding the collection of your empty tiffin container:
🍱 *Tiffin Box ID*: ${boxId}
📍 *Pickup Location*: ${address || 'Registered Address'}

Our delivery partner will be arriving shortly. Kindly keep the empty tiffin container accessible for collection.

Thank you for your valuable cooperation!
Warm regards,
*${settings.bizName}*
📞 ${settings.bizPhone}`;

  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}

function notifyAllPendingWhatsApp() {
  const pendingBoxes = Object.entries(boxStates).filter(([_, state]) => state.status === 'with_client');
  if (pendingBoxes.length === 0) {
    Swal.fire({ icon: 'info', title: 'No pending boxes', text: 'All tiffin containers have been collected.' });
    return;
  }
  Swal.fire({
    title: 'Send Pickup Reminders?',
    text: `You have ${pendingBoxes.length} uncollected containers. You can trigger WhatsApp notices one-by-one from the list.`,
    icon: 'question',
    confirmButtonColor: '#10b981',
    confirmButtonText: 'View Pending List'
  });
}

// ==========================================
// QR SCANNER (DISPATCH & RETURN)
// ==========================================
function openScannerModal(mode = 'dispatch') {
  if (mode === 'auto') mode = currentScanMode || 'dispatch';
  setScanMode(mode);

  const modal = document.getElementById('scannerModal');
  modal.classList.remove('hidden');
  lucide.createIcons();

  startQrScanner();
}

function closeScannerModal() {
  const modal = document.getElementById('scannerModal');
  modal.classList.add('hidden');
  stopQrScanner();
}

function setScanMode(mode) {
  currentScanMode = mode;
  const dispatchBtn = document.getElementById('scanModeDispatchBtn');
  const collectBtn = document.getElementById('scanModeCollectBtn');
  const modalTitle = document.getElementById('scannerModalTitle');

  if (mode === 'dispatch') {
    dispatchBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-emerald-600 text-white shadow-xs';
    collectBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-slate-200 text-slate-700';
    modalTitle.textContent = '1. Dispatch Tiffin (Scan 6-Digit Box)';
  } else {
    collectBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-blue-600 text-white shadow-xs';
    dispatchBtn.className = 'flex-1 py-2 text-xs font-bold rounded-2xl transition flex items-center justify-center bg-slate-200 text-slate-700';
    modalTitle.textContent = '2. Return Tiffin (Scan 6-Digit Box)';
  }
  lucide.createIcons();
}

function startQrScanner() {
  const readerElement = document.getElementById('reader');
  if (!readerElement) return;

  if (!scannerInstance) {
    scannerInstance = new Html5Qrcode('reader');
  }

  const config = {
    fps: 10,
    qrbox: { width: 220, height: 220 },
    aspectRatio: 1.0
  };

  scannerInstance.start(
    { facingMode: 'environment' },
    config,
    (decodedText) => {
      handleQrDecoded(decodedText);
    },
    (errorMessage) => {}
  ).catch(err => {
    console.warn('Camera error:', err);
  });
}

function stopQrScanner() {
  if (scannerInstance && scannerInstance.isScanning) {
    scannerInstance.stop().then(() => {}).catch(err => console.error(err));
  }
}

function handleManualCodeSubmit() {
  const input = document.getElementById('manualQrInput');
  const code = input.value.trim().toUpperCase();
  if (!code) {
    Swal.fire({ icon: 'warning', title: 'Enter Box ID', text: 'e.g. MAT001 or 100001' });
    return;
  }
  input.value = '';
  handleQrDecoded(code);
}

function handleQrDecoded(rawCode) {
  let boxId = rawCode.trim().toUpperCase();
  if (boxId.includes('?id=')) {
    boxId = boxId.split('?id=')[1];
  } else if (boxId.includes('/')) {
    boxId = boxId.split('/').pop();
  }

  playBeepSound('success');

  if (scannerInstance && scannerInstance.isScanning) {
    scannerInstance.pause();
  }

  if (currentScanMode === 'dispatch') {
    handleDispatchScan(boxId);
  } else {
    handleReturnScan(boxId);
  }
}

// -------------------------------------------------------------------------
// DISPATCH SCAN: Searchable Client Selection + Lunch/Dinner + Cash Collection Option
// -------------------------------------------------------------------------
let swalSelectedClientId = null;
let swalDispatchMealCategory = 'lunch';
let swalDispatchPaymentMethod = 'cash'; // 'cash' | 'upi' | 'due'

function handleDispatchScan(boxId) {
  if (boxStates[boxId] && boxStates[boxId].status === 'with_client') {
    const prevClient = boxStates[boxId].clientName;
    Swal.fire({
      icon: 'warning',
      title: 'Container Already Out!',
      html: `Box <b>${boxId}</b> is currently registered with <b>${prevClient}</b>.<br>Do you want to re-dispatch this box?`,
      showCancelButton: true,
      confirmButtonText: 'Yes, Re-dispatch',
      cancelButtonText: 'Cancel'
    }).then(res => {
      if (res.isConfirmed) {
        showDispatchModalWithSearchableClients(boxId);
      } else {
        resumeScanner();
      }
    });
    return;
  }

  showDispatchModalWithSearchableClients(boxId);
}

function showDispatchModalWithSearchableClients(boxId) {
  let preClient = clients.find(c => c.boxId && c.boxId.toUpperCase() === boxId.toUpperCase());
  swalSelectedClientId = preClient ? preClient.id : (clients[0] ? clients[0].id : null);
  swalDispatchMealCategory = 'lunch';
  swalDispatchPaymentMethod = 'cash';

  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const currentLunch = daySchedule.lunch;

  const extrasHtml = extraItemsCatalog.map(ext => `
    <label class="flex items-center justify-between p-1.5 bg-slate-50 border border-slate-200 rounded-lg cursor-pointer text-[11px]">
      <div class="flex items-center space-x-2">
        <input type="checkbox" class="swal-extra-check" data-name="${ext.name}" data-price="${ext.price}" onchange="recalcDispatchTotal()">
        <span class="font-medium text-slate-800">${ext.name}</span>
      </div>
      <span class="font-bold text-emerald-700">+₹${ext.price}</span>
    </label>
  `).join('');

  Swal.fire({
    title: `Dispatch Tiffin: <span class="box-code-badge">${boxId}</span>`,
    html: `
      <div class="text-left text-xs space-y-3">
        
        <!-- Client Selection Tabs: Existing (Searchable) vs + New Client -->
        <div class="bg-slate-100 p-1 rounded-xl flex space-x-1">
          <button type="button" id="tabBtnSelectExisting" onclick="toggleDispatchClientMode('existing')" class="flex-1 py-1.5 font-bold rounded-lg text-xs bg-white text-slate-900 shadow-2xs">
            Search Registered Client
          </button>
          <button type="button" id="tabBtnAddNew" onclick="toggleDispatchClientMode('new')" class="flex-1 py-1.5 font-bold rounded-lg text-xs text-slate-600">
            + Add New Client
          </button>
        </div>

        <!-- 1. Searchable Registered Client Section -->
        <div id="sectionSelectExisting" class="space-y-1.5">
          <div class="relative">
            <input type="text" id="swalClientSearchInput" oninput="filterSwalClientsList(this.value)" placeholder="🔍 Type name, phone or route to search..." class="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl text-xs font-medium focus:ring-1 focus:ring-orange-500 focus:outline-none">
          </div>
          
          <div id="swalClientsListContainer" class="space-y-1 max-h-32 overflow-y-auto border border-slate-200 p-1.5 rounded-xl bg-slate-50/70">
            <!-- Injected by filterSwalClientsList -->
          </div>
          <div class="text-[11px] text-slate-600" id="swalSelectedClientSummary">
            Selected: <b class="text-orange-700" id="swalSelectedClientNameDisplay">${preClient ? preClient.name : (clients[0] ? clients[0].name : 'None')}</b>
          </div>
        </div>

        <!-- 2. Add New Client Inline Form -->
        <div id="sectionAddNewClient" class="space-y-2 p-3 bg-orange-50/70 border border-orange-200 rounded-2xl hidden">
          <p class="font-bold text-orange-900 text-[11px]">Quick Client Registration:</p>
          <div>
            <input type="text" id="swalNewClientName" placeholder="Client Full Name *" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
          </div>
          <div class="grid grid-cols-2 gap-2">
            <input type="tel" id="swalNewClientPhone" placeholder="Mobile / WhatsApp *" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
            <input type="text" id="swalNewClientArea" placeholder="Kunwar Singh Nagar" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
          </div>
          <div>
            <textarea id="swalNewClientAddress" rows="1" placeholder="Delivery Address & Landmark *" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white"></textarea>
          </div>
        </div>

        <!-- Meal Category Switcher (☀️ Lunch vs 🌙 Dinner) -->
        <div>
          <label class="block font-semibold text-slate-700 mb-1">Meal Service (Lunch vs Dinner):</label>
          <div class="grid grid-cols-2 gap-2">
            <button type="button" id="swalBtnLunch" onclick="switchSwalMealCategory('lunch')" class="py-2 text-xs font-bold rounded-xl bg-orange-600 text-white shadow-2xs flex items-center justify-center space-x-1">
              <span>☀️</span>
              <span>Lunch (दोपहर)</span>
            </button>
            <button type="button" id="swalBtnDinner" onclick="switchSwalMealCategory('dinner')" class="py-2 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center space-x-1">
              <span>🌙</span>
              <span>Dinner (रात)</span>
            </button>
          </div>
        </div>

        <!-- Menu Title & Dish Description -->
        <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
          <div class="flex items-center justify-between mb-1">
            <span class="font-bold text-slate-800" id="swalActiveMenuTitle">${currentLunch.title}</span>
            <span class="font-mono font-bold text-emerald-700" id="swalActiveMenuPrice">₹${currentLunch.price}</span>
          </div>
          <p class="text-[11px] text-slate-600 font-mono whitespace-pre-line" id="swalActiveMenuItems">${currentLunch.items}</p>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Base Price (₹):</label>
          <input type="number" id="swalBasePrice" value="${currentLunch.price}" class="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold" onchange="recalcDispatchTotal()">
        </div>

        <!-- Add-ons / Extras Checklist -->
        <div>
          <div class="flex items-center justify-between mb-1">
            <label class="font-semibold text-slate-700">Add-ons / Extras Requested:</label>
            <span class="text-[10px] text-slate-400">Optional</span>
          </div>
          <div class="space-y-1 max-h-24 overflow-y-auto">
            ${extrasHtml}
          </div>
        </div>

        <!-- Payment Collection Mode (Cash vs UPI vs Due) -->
        <div class="pt-1">
          <label class="block font-bold text-slate-800 mb-1">Payment Method / Collection:</label>
          <div class="grid grid-cols-3 gap-1.5">
            <button type="button" id="swalPayModeCash" onclick="switchSwalPaymentMode('cash')" class="pay-mode-card selected text-center py-2 px-1">
              <span class="block text-sm">💵</span>
              <span class="block font-bold text-[10.5px] text-emerald-800">Cash Received</span>
            </button>
            <button type="button" id="swalPayModeUpi" onclick="switchSwalPaymentMode('upi')" class="pay-mode-card text-center py-2 px-1">
              <span class="block text-sm">📱</span>
              <span class="block font-bold text-[10.5px] text-slate-700">UPI / QR Pay</span>
            </button>
            <button type="button" id="swalPayModeDue" onclick="switchSwalPaymentMode('due')" class="pay-mode-card text-center py-2 px-1">
              <span class="block text-sm">⏳</span>
              <span class="block font-bold text-[10.5px] text-slate-700">Monthly Due</span>
            </button>
          </div>
        </div>

        <!-- Total Display -->
        <div class="bg-slate-100 p-2.5 rounded-xl flex items-center justify-between border border-slate-200">
          <span class="font-bold text-slate-800 text-xs">Total Billable Amount:</span>
          <span class="text-sm font-extrabold text-emerald-700" id="swalTotalDisplay">₹${currentLunch.price}</span>
        </div>

      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#059669',
    confirmButtonText: 'Confirm & Dispatch',
    cancelButtonText: 'Cancel',
    didOpen: () => {
      filterSwalClientsList('');
    }
  }).then(res => {
    if (res.isConfirmed) {
      processDispatchSubmission(boxId);
    } else {
      resumeScanner();
    }
  });

  if (clients.length === 0) {
    toggleDispatchClientMode('new');
  }
}

// Window helpers for SweetAlert modal
window.toggleDispatchClientMode = function(mode) {
  const tabExisting = document.getElementById('tabBtnSelectExisting');
  const tabNew = document.getElementById('tabBtnAddNew');
  const secExisting = document.getElementById('sectionSelectExisting');
  const secNew = document.getElementById('sectionAddNewClient');

  if (mode === 'existing') {
    tabExisting.className = 'flex-1 py-1.5 font-bold rounded-lg text-xs bg-white text-slate-900 shadow-2xs';
    tabNew.className = 'flex-1 py-1.5 font-bold rounded-lg text-xs text-slate-600';
    secExisting.classList.remove('hidden');
    secNew.classList.add('hidden');
  } else {
    tabNew.className = 'flex-1 py-1.5 font-bold rounded-lg text-xs bg-white text-slate-900 shadow-2xs';
    tabExisting.className = 'flex-1 py-1.5 font-bold rounded-lg text-xs text-slate-600';
    secNew.classList.remove('hidden');
    secExisting.classList.add('hidden');
  }
};

window.filterSwalClientsList = function(searchTerm) {
  const container = document.getElementById('swalClientsListContainer');
  if (!container) return;

  const q = searchTerm.toLowerCase().trim();
  let matches = clients;
  if (q) {
    matches = clients.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.phone.includes(q) || 
      (c.area && c.area.toLowerCase().includes(q))
    );
  }

  if (matches.length === 0) {
    container.innerHTML = `<div class="p-2 text-center text-[11px] text-slate-400">No matching clients found. Use "+ Add New Client" above.</div>`;
    return;
  }

  container.innerHTML = matches.map(c => `
    <div onclick="selectSwalClient('${c.id}', '${c.name.replace(/'/g, "\\'")}')" class="client-search-item ${c.id === swalSelectedClientId ? 'selected' : ''}">
      <div class="flex items-center justify-between">
        <span class="font-bold text-slate-900 text-xs">${c.name}</span>
        <span class="text-[10.5px] text-slate-500 font-mono">${c.phone}</span>
      </div>
      <div class="text-[10px] text-slate-500 truncate">${c.address || ''} &bull; ${c.area || 'Direct'}</div>
    </div>
  `).join('');
};

window.selectSwalClient = function(clientId, clientName) {
  swalSelectedClientId = clientId;
  const nameDisplay = document.getElementById('swalSelectedClientNameDisplay');
  if (nameDisplay) nameDisplay.textContent = clientName;

  document.querySelectorAll('#swalClientsListContainer .client-search-item').forEach(el => el.classList.remove('selected'));
  const currentSearch = document.getElementById('swalClientSearchInput')?.value || '';
  filterSwalClientsList(currentSearch);
};

window.switchSwalMealCategory = function(category) {
  swalDispatchMealCategory = category;
  const btnL = document.getElementById('swalBtnLunch');
  const btnD = document.getElementById('swalBtnDinner');

  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const selectedMeal = category === 'lunch' ? daySchedule.lunch : daySchedule.dinner;

  if (category === 'lunch') {
    btnL.className = 'py-2 text-xs font-bold rounded-xl bg-orange-600 text-white shadow-2xs flex items-center justify-center space-x-1';
    btnD.className = 'py-2 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center space-x-1';
  } else {
    btnD.className = 'py-2 text-xs font-bold rounded-xl bg-blue-600 text-white shadow-2xs flex items-center justify-center space-x-1';
    btnL.className = 'py-2 text-xs font-bold rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center space-x-1';
  }

  document.getElementById('swalActiveMenuTitle').textContent = selectedMeal.title;
  document.getElementById('swalActiveMenuPrice').textContent = `₹${selectedMeal.price}`;
  document.getElementById('swalActiveMenuItems').textContent = selectedMeal.items;
  document.getElementById('swalBasePrice').value = selectedMeal.price;

  window.recalcDispatchTotal();
};

window.switchSwalPaymentMode = function(mode) {
  swalDispatchPaymentMethod = mode;
  const btnCash = document.getElementById('swalPayModeCash');
  const btnUpi = document.getElementById('swalPayModeUpi');
  const btnDue = document.getElementById('swalPayModeDue');

  [btnCash, btnUpi, btnDue].forEach(b => b.classList.remove('selected'));
  if (mode === 'cash') btnCash.classList.add('selected');
  else if (mode === 'upi') btnUpi.classList.add('selected');
  else if (mode === 'due') btnDue.classList.add('selected');
};

window.recalcDispatchTotal = function() {
  const basePrice = Number(document.getElementById('swalBasePrice')?.value) || 0;
  const checkedBoxes = Array.from(document.querySelectorAll('.swal-extra-check:checked'));
  const extrasTotal = checkedBoxes.reduce((sum, cb) => sum + Number(cb.getAttribute('data-price') || 0), 0);
  const total = basePrice + extrasTotal;
  const display = document.getElementById('swalTotalDisplay');
  if (display) display.textContent = `₹${total}`;
};

// Process final dispatch
function processDispatchSubmission(boxId) {
  const secNew = document.getElementById('sectionAddNewClient');
  const isAddingNew = secNew && !secNew.classList.contains('hidden');

  let targetClient = null;

  if (isAddingNew) {
    const newName = document.getElementById('swalNewClientName')?.value.trim();
    const newPhone = document.getElementById('swalNewClientPhone')?.value.trim();
    const newAddress = document.getElementById('swalNewClientAddress')?.value.trim();
    const newArea = document.getElementById('swalNewClientArea')?.value.trim();

    if (!newName || !newPhone) {
      Swal.fire({ icon: 'warning', title: 'Missing Client Info', text: 'Name and Phone Number are required.' });
      resumeScanner();
      return;
    }

    targetClient = {
      id: 'c-' + Date.now(),
      name: newName,
      phone: newPhone,
      address: newAddress || 'Kunwar Singh Nagar',
      area: newArea || 'Kunwar Singh Nagar',
      boxId: boxId,
      mealType: swalDispatchMealCategory === 'lunch' ? 'Lunch' : 'Dinner',
      price: settings.defaultPrice,
      paymentStatus: swalDispatchPaymentMethod === 'cash' ? 'paid' : 'pending',
      dueAmount: swalDispatchPaymentMethod === 'cash' ? 0 : settings.defaultPrice,
      startDate: currentDate,
      status: 'active'
    };

    clients.push(targetClient);
    saveData();
    renderClientList();
  } else {
    targetClient = clients.find(c => c.id === swalSelectedClientId);

    if (!targetClient) {
      Swal.fire({ icon: 'warning', title: 'No Client Selected', text: 'Please search and select a client.' });
      resumeScanner();
      return;
    }
  }

  const daySchedule = weeklyMenu[currentSelectedMenuDay] || weeklyMenu.monday;
  const mealObj = swalDispatchMealCategory === 'lunch' ? daySchedule.lunch : daySchedule.dinner;
  const menuTitle = mealObj.title;
  const menuItems = mealObj.items;

  const basePrice = Number(document.getElementById('swalBasePrice')?.value) || mealObj.price;
  const checkedBoxes = Array.from(document.querySelectorAll('.swal-extra-check:checked'));
  const extrasArray = checkedBoxes.map(cb => cb.getAttribute('data-name'));
  const customExtra = document.getElementById('swalCustomExtra')?.value.trim();
  if (customExtra) extrasArray.push(customExtra);

  const extrasTotal = checkedBoxes.reduce((sum, cb) => sum + Number(cb.getAttribute('data-price') || 0), 0);
  const totalAmount = basePrice + extrasTotal;
  const extrasSummary = extrasArray.length > 0 ? extrasArray.join(', ') : 'None';

  // If cash was collected now, update client balance
  if (swalDispatchPaymentMethod === 'cash') {
    targetClient.paymentStatus = 'paid';
    targetClient.dueAmount = Math.max(0, (targetClient.dueAmount || 0) - totalAmount);
  }

  completeDispatch(boxId, targetClient, swalDispatchMealCategory, menuTitle, menuItems, extrasSummary, totalAmount, swalDispatchPaymentMethod);
}

function completeDispatch(boxId, client, mealCategory, menuTitle, menuItems, extras, price, paymentMode) {
  const now = new Date();
  const timestamp = now.toISOString();
  const todayStr = timestamp.split('T')[0];

  boxStates[boxId] = {
    status: 'with_client',
    clientId: client.id,
    clientName: client.name,
    clientPhone: client.phone,
    clientAddress: client.address,
    dispatchedAt: timestamp,
    mealCategory: capitalize(mealCategory),
    menuTitle,
    menuItems,
    extras,
    price,
    paymentMode
  };

  logs.push({
    id: 'log-' + Date.now(),
    timestamp,
    date: todayStr,
    boxId,
    clientId: client.id,
    clientName: client.name,
    mealCategory: capitalize(mealCategory),
    menuTitle,
    menuItems,
    extras,
    price,
    paymentMode,
    type: 'dispatch'
  });

  saveData();
  renderDashboard();
  renderPendingList();
  renderPaymentsList();

  const isCash = paymentMode === 'cash';

  Swal.fire({
    icon: 'success',
    title: 'Tiffin Dispatched! ✅',
    html: `Box <b>${boxId}</b> sent to <b>${client.name}</b> (${capitalize(mealCategory)}).<br><b>Total Amount:</b> ₹${price} ${isCash ? '<span class="badge-soft-emerald px-1.5 py-0.5 rounded text-xs font-bold ml-1">💵 Cash Received</span>' : ''}`,
    showCancelButton: true,
    confirmButtonColor: '#10b981',
    confirmButtonText: 'Send WhatsApp Slip',
    cancelButtonText: 'Done'
  }).then((res) => {
    if (res.isConfirmed) {
      sendProfessionalDeliverySlip(client.phone, client.name, boxId, capitalize(mealCategory), menuTitle, menuItems, extras, price, paymentMode);
    }
    resumeScanner();
  });
}

// -------------------------------------------------------------------------
// RETURN SCAN (With Cash Collection Option)
// -------------------------------------------------------------------------
function handleReturnScan(boxId) {
  const currentState = boxStates[boxId];

  if (!currentState || currentState.status !== 'with_client') {
    Swal.fire({
      icon: 'question',
      title: `Container ${boxId}`,
      text: 'This box was not marked as currently out with a client. Mark as returned to kitchen anyway?',
      showCancelButton: true,
      confirmButtonText: 'Yes, Return Box'
    }).then(res => {
      if (res.isConfirmed) {
        completeCollect(boxId, 'Registered Client', null, false);
      } else {
        resumeScanner();
      }
    });
    return;
  }

  const client = clients.find(c => c.id === currentState.clientId);
  const isDue = client && client.paymentStatus === 'pending';
  const dueAmt = client ? client.dueAmount : 0;

  Swal.fire({
    title: `Return Tiffin: <span class="box-code-badge">${boxId}</span>`,
    html: `
      <div class="text-left text-xs space-y-2.5">
        <div class="bg-blue-50 p-3 rounded-2xl border border-blue-200">
          <p class="font-bold text-slate-900 text-sm">${currentState.clientName}</p>
          <p class="text-[11px] text-slate-500">${currentState.clientPhone} &bull; ${currentState.clientAddress || ''}</p>
          <p class="text-[11px] text-blue-700 mt-1">Dispatched: ${getTimeAgoText(currentState.dispatchedAt)} (${currentState.mealCategory || 'Meal'})</p>
        </div>

        ${isDue ? `
          <div class="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
            <div class="flex items-center justify-between">
              <span class="font-bold text-amber-900">Pending Amount:</span>
              <span class="text-sm font-extrabold text-red-600">₹${dueAmt}</span>
            </div>
            <label class="flex items-center space-x-2 text-xs font-bold text-slate-800 cursor-pointer bg-white p-2 rounded-lg border border-amber-200">
              <input type="checkbox" id="swalCollectCashReturn" checked class="w-4 h-4 text-emerald-600">
              <span>💵 Collect Cash Now (₹${dueAmt})</span>
            </label>
          </div>
        ` : `
          <div class="p-2 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 font-semibold text-[11px] text-center">
            ✓ Subscription Payment Cleared (Paid)
          </div>
        `}
      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#2563eb',
    confirmButtonText: 'Confirm Box Returned',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      const collectedCash = document.getElementById('swalCollectCashReturn')?.checked;
      if (collectedCash && client) {
        client.paymentStatus = 'paid';
        client.dueAmount = 0;
      }
      completeCollect(boxId, currentState.clientName, currentState.clientId, collectedCash);
    } else {
      resumeScanner();
    }
  });
}

function completeCollect(boxId, clientName, clientId, collectedCash = false) {
  const now = new Date();
  const timestamp = now.toISOString();
  const todayStr = timestamp.split('T')[0];

  boxStates[boxId] = {
    status: 'available',
    clientId: null,
    clientName: null,
    clientPhone: null,
    clientAddress: null,
    collectedAt: timestamp
  };

  logs.push({
    id: 'log-' + Date.now(),
    timestamp,
    date: todayStr,
    boxId,
    clientId,
    clientName,
    paymentMode: collectedCash ? 'cash' : 'none',
    type: 'collect'
  });

  saveData();
  renderDashboard();
  renderPendingList();
  renderPaymentsList();

  Swal.fire({
    icon: 'success',
    title: 'Container Returned! 🍱',
    html: `Box <b>${boxId}</b> received back from <b>${clientName}</b>. ${collectedCash ? '<br><b class="text-emerald-700">💵 Cash Payment Cleared!</b>' : ''}`,
    timer: 1800,
    showConfirmButton: false
  }).then(() => {
    resumeScanner();
  });
}

function markBoxReturned(boxId) {
  handleReturnScan(boxId);
}

function resumeScanner() {
  if (scannerInstance && scannerInstance.isScanning) {
    try {
      scannerInstance.resume();
    } catch (e) {}
  }
}

// -------------------------------------------------------------------------
// WHATSAPP DELIVERY SLIP WITH LIVE UPI PAYMENT LINK & QR CODE LINK
// -------------------------------------------------------------------------
function sendProfessionalDeliverySlip(phone, clientName, boxId, mealCategory, menuTitle, menuItems, extras, price, paymentMode) {
  if (!phone) return;
  let cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length === 10) cleanPhone = '91' + cleanPhone;

  const isCash = paymentMode === 'cash';
  const upiId = settings.upiId || '9311155593@paytm';

  // Live scannable QR Code image URL generated via public API
  const upiRawString = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=Maa%20Annapurna%20Tiffin&am=${price}&cu=INR`;
  const upiQrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(upiRawString)}`;

  let paymentText = '';
  if (isCash) {
    paymentText = `💳 *Payment Status*: ✅ PAID (Cash Received: ₹${price}/-)`;
  } else {
    paymentText = `💳 *QUICK PAYMENT OPTIONS*:
• Amount Due: ₹${price}/-
• UPI ID: ${upiId} (GPay / PhonePe / Paytm)
• Direct UPI Pay Link:
  ${upiRawString}
• Scan Payment QR Code Online:
  ${upiQrImageUrl}`;
  }

  const msg = `Dear ${clientName},

Greetings from *${settings.bizName}* (Kunwar Singh Nagar)! 🙏

Your ${mealCategory} meal has been safely delivered:
🍱 *Tiffin Container*: ${boxId}
🍛 *Service*: ${mealCategory} (${menuTitle})
➕ *Add-ons / Extras*: ${extras}
💰 *Total Amount*: ₹${price}/-

${paymentText}

We hope you relish your meal! Kindly keep the container ready for collection later today.

Warm regards,
*${settings.bizName}*
📍 Kunwar Singh Nagar &bull; 📞 ${settings.bizPhone}`;

  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}

// -------------------------------------------------------------------------
// DYNAMIC LIVE UPI PAYMENT QR CODE MODAL
// -------------------------------------------------------------------------
function openUpiQrModal(amount = null) {
  const modal = document.getElementById('upiPaymentQrModal');
  const holder = document.getElementById('dynamicUpiQrCodeHolder');
  const amountDisp = document.getElementById('upiModalAmountDisplay');
  const vpaDisp = document.getElementById('upiModalVpaDisplay');

  holder.innerHTML = '';
  vpaDisp.textContent = settings.upiId || '9311155593@paytm';

  let upiString = `upi://pay?pa=${settings.upiId || '9311155593@paytm'}&pn=Maa%20Annapurna%20Tiffin%20Service&cu=INR`;
  if (amount) {
    upiString += `&am=${amount}`;
    amountDisp.textContent = `Amount: ₹${amount}/-`;
  } else {
    amountDisp.textContent = `Amount: Custom / Subscription`;
  }

  try {
    upiQrCodeInstance = new QRCode(holder, {
      text: upiString,
      width: 180,
      height: 180,
      colorDark: '#0f172a',
      colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.M
    });
  } catch (e) {
    console.error(e);
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeUpiQrModal() {
  document.getElementById('upiPaymentQrModal').classList.add('hidden');
}

function shareUpiLinkWhatsApp() {
  const upiId = settings.upiId || '9311155593@paytm';
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi%3A%2F%2Fpay%3Fpa%3D${encodeURIComponent(upiId)}%26pn%3DMaa%20Annapurna%20Tiffin%26cu%3DINR`;
  
  const text = `🍱 *Maa Annapurna Tiffin Service - Online Payment QR* 🍱
📍 Kunwar Singh Nagar | 📞 ${settings.bizPhone}

Scan this UPI QR Code or pay via:
• UPI ID: ${upiId}
• GPay / PhonePe / Paytm: ${settings.bizPhone}
• Payment QR Code Link: ${qrUrl}

Thank you for choosing pure homemade food! 🙏`;

  const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
  window.open(url, '_blank');
}

// ==========================================
// EMAIL DATA SYNC SYSTEM
// ==========================================
function triggerEmailDataSync() {
  const email = settings.bizEmail || 'annapurna.tiffin@gmail.com';
  const phone = settings.bizPhone || '+91 9311155593';
  const dayLogs = logs.filter(l => l.date === currentDate);
  const dispatchedToday = dayLogs.filter(l => l.type === 'dispatch').length;
  const collectedToday = dayLogs.filter(l => l.type === 'collect').length;
  const cashToday = dayLogs.reduce((sum, l) => sum + (l.paymentMode === 'cash' ? (Number(l.price) || 0) : 0), 0);
  const pendingBoxes = Object.entries(boxStates).filter(([_, state]) => state.status === 'with_client');
  const totalDues = clients.reduce((sum, c) => sum + (c.paymentStatus === 'pending' ? (Number(c.dueAmount) || 0) : 0), 0);

  const pendingListSummary = pendingBoxes.map(([boxId, st]) => `${boxId}: ${st.clientName} (${st.clientPhone})`).join('; ') || 'None';

  const subject = encodeURIComponent(`${settings.bizName} - Daily Ledger Report (${currentDate})`);
  const bodyText = encodeURIComponent(`MAA ANNAPURNA TIFFIN SERVICE
Address: Kunwar Singh Nagar | Phone: ${phone}
Date: ${currentDate}

=============================
DAILY OPERATIONS SUMMARY:
=============================
• Total Active Clients: ${clients.length}
• Tiffins Dispatched Today: ${dispatchedToday}
• Tiffins Returned Today: ${collectedToday}
• Cash Collected Today: ₹${cashToday}
• Unreturned Tiffin Containers: ${pendingBoxes.length}
• Pending Containers List: ${pendingListSummary}

=============================
FINANCIAL LEDGER:
=============================
• Total Outstanding Dues: ₹${totalDues}

(This automated report is synced from your TiffinTrack Pro system.)`);

  exportDataJSON();

  const mailtoUrl = `mailto:${email}?subject=${subject}&body=${bodyText}`;
  window.location.href = mailtoUrl;

  Swal.fire({
    icon: 'success',
    title: 'Backup & Email Report Prepared! ✉️',
    html: `Database backup downloaded and email report prepared for <b>${email}</b>.<br>Your data is safe and synchronized!`,
    confirmButtonColor: '#ea580c'
  });
}

// ==========================================
// PAYMENTS & SUBSCRIPTION LEDGER
// ==========================================
function renderPaymentsList() {
  const container = document.getElementById('paymentsListContainer');
  if (!container) return;

  const totalCollected = clients.reduce((sum, c) => sum + (c.paymentStatus === 'paid' ? (Number(c.price) || 0) : 0), 0);
  const totalDues = clients.reduce((sum, c) => sum + (c.paymentStatus === 'pending' ? (Number(c.dueAmount) || 0) : 0), 0);

  document.getElementById('payStatCollected').textContent = `₹${totalCollected.toLocaleString('en-IN')}`;
  document.getElementById('payStatDues').textContent = `₹${totalDues.toLocaleString('en-IN')}`;

  let filtered = clients;
  if (paymentFilter === 'due') {
    filtered = clients.filter(c => c.paymentStatus === 'pending');
  } else if (paymentFilter === 'paid') {
    filtered = clients.filter(c => c.paymentStatus === 'paid');
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="aesthetic-card p-8 text-center text-xs text-slate-400">
        No records match the selected payment filter.
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(c => {
    const isPaid = c.paymentStatus === 'paid';
    return `
      <div class="aesthetic-card p-3.5 space-y-2.5">
        <div class="flex items-start justify-between">
          <div>
            <h4 class="text-xs font-bold text-slate-900">${c.name}</h4>
            <p class="text-[11px] text-slate-500">${c.phone} &bull; ${c.area || 'Kunwar Singh Nagar'}</p>
          </div>
          <div class="text-right">
            ${isPaid 
              ? `<span class="badge-soft-emerald px-2 py-0.5 rounded-full text-[10px] font-bold">PAID</span>`
              : `<span class="badge-soft-red px-2 py-0.5 rounded-full text-[10px] font-bold">DUE: ₹${c.dueAmount}</span>`
            }
          </div>
        </div>

        <div class="flex items-center justify-between text-[11px] text-slate-600 border-t border-slate-100 pt-2">
          <span>Monthly Plan: <b>₹${c.price}</b></span>

          <div class="flex items-center space-x-2">
            ${!isPaid ? `
              <button onclick="sendProfessionalPaymentReminder('${c.phone}', '${c.name}', '${c.dueAmount}')" class="badge-soft-emerald hover:bg-emerald-100 text-[11px] font-bold px-2 py-1 rounded-lg flex items-center">
                <i data-lucide="message-circle" class="w-3 h-3 mr-1"></i>
                Reminder
              </button>
            ` : ''}
            
            <button onclick="openCollectPaymentModal('${c.id}')" class="bg-slate-900 hover:bg-black text-white text-[11px] font-bold px-2.5 py-1 rounded-lg shadow-2xs">
              ${isPaid ? 'Update' : 'Record Payment'}
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');

  lucide.createIcons();
}

function filterPaymentList(type) {
  paymentFilter = type;
  document.getElementById('payFilterAll').className = type === 'all' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-900 text-white' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-slate-700';
  document.getElementById('payFilterDue').className = type === 'due' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-red-600 text-white' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-red-600';
  document.getElementById('payFilterPaid').className = type === 'paid' ? 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-emerald-600 text-white' : 'flex-1 py-1.5 text-xs font-bold rounded-xl bg-slate-100 text-emerald-600';
  renderPaymentsList();
}

function openCollectPaymentModal(clientId) {
  const client = clients.find(c => c.id === clientId);
  if (!client) return;

  Swal.fire({
    title: `Record Payment: ${client.name}`,
    html: `
      <div class="text-left text-xs space-y-3">
        <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
          <p class="text-slate-600">Current Due: <b class="text-red-600">₹${client.dueAmount || client.price}</b></p>
          <p class="text-slate-600">Subscription Plan: <b>₹${client.price}/month</b></p>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Payment Status:</label>
          <select id="swalPayStatus" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
            <option value="paid">Full Payment Received (Cleared)</option>
            <option value="partial">Partial Payment Received</option>
            <option value="pending">Unpaid (Payment Due)</option>
          </select>
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Remaining Due Amount (₹):</label>
          <input type="number" id="swalPayRemaining" value="0" class="w-full p-2 border border-slate-300 rounded-xl text-xs font-bold">
        </div>

        <div>
          <label class="block font-semibold text-slate-700 mb-1">Payment Method:</label>
          <select id="swalPayMethod" class="w-full p-2 border border-slate-300 rounded-xl text-xs bg-white">
            <option value="cash">💵 Cash Received</option>
            <option value="upi">📱 UPI / PhonePe / GPay (${settings.upiId})</option>
            <option value="bank">🏦 Bank Transfer</option>
          </select>
        </div>
      </div>
    `,
    showCancelButton: true,
    confirmButtonColor: '#059669',
    confirmButtonText: 'Save Payment',
    cancelButtonText: 'Cancel',
    didOpen: () => {
      const select = document.getElementById('swalPayStatus');
      select.addEventListener('change', (e) => {
        const remainingInput = document.getElementById('swalPayRemaining');
        if (e.target.value === 'paid') remainingInput.value = '0';
        else if (e.target.value === 'pending') remainingInput.value = client.price;
      });
    }
  }).then(res => {
    if (res.isConfirmed) {
      const status = document.getElementById('swalPayStatus').value;
      const remaining = Number(document.getElementById('swalPayRemaining').value) || 0;
      const method = document.getElementById('swalPayMethod').value;

      client.paymentStatus = (status === 'paid' && remaining === 0) ? 'paid' : 'pending';
      client.dueAmount = remaining;

      saveData();
      renderPaymentsList();
      renderClientList();
      renderDashboard();

      Swal.fire({ icon: 'success', title: `Payment Saved (${method.toUpperCase()})`, timer: 1400, showConfirmButton: false });
    }
  });
}

function sendProfessionalPaymentReminder(phone, clientName, dueAmount) {
  if (!phone) return;
  let cleanPhone = phone.replace(/[^0-9]/g, '');
  if (cleanPhone.length === 10) cleanPhone = '91' + cleanPhone;

  const upiId = settings.upiId || '9311155593@paytm';
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=upi%3A%2F%2Fpay%3Fpa%3D${encodeURIComponent(upiId)}%26pn%3DMaa%20Annapurna%20Tiffin%26am%3D${dueAmount}%26cu%3DINR`;

  const msg = `Dear ${clientName},

Greetings from *${settings.bizName}* (Kunwar Singh Nagar)! 🙏

We hope you are enjoying our homemade meals. This is a gentle reminder that your tiffin subscription payment of *₹${dueAmount}* is currently pending.

💳 *PAYMENT OPTIONS*:
• UPI ID / GPay / PhonePe: ${upiId}
• Scan UPI QR Code: ${qrUrl}
• Direct Phone Contact: ${settings.bizPhone}
• Or pay in Cash to our delivery partner

Kindly complete the payment at your earliest convenience. If you have already transferred the amount, please disregard this notice.

Thank you for your valued patronage!
Warm regards,
*${settings.bizName}*`;

  const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}

// ==========================================
// CLIENT DIRECTORY
// ==========================================
function renderClientList(search = '', areaFilter = '') {
  const container = document.getElementById('clientListContainer');
  const areaSelect = document.getElementById('clientAreaFilter');

  const uniqueAreas = Array.from(new Set(clients.map(c => c.area).filter(Boolean)));
  if (areaSelect) {
    const currentVal = areaSelect.value;
    areaSelect.innerHTML = `<option value="">All Delivery Routes (${clients.length})</option>` +
      uniqueAreas.map(a => `<option value="${a}" ${currentVal === a ? 'selected' : ''}>${a}</option>`).join('');
  }

  let filtered = clients;
  if (search.trim()) {
    const q = search.toLowerCase();
    filtered = filtered.filter(c => 
      c.name.toLowerCase().includes(q) || 
      c.phone.includes(q) || 
      (c.boxId && c.boxId.toLowerCase().includes(q))
    );
  }
  if (areaFilter) {
    filtered = filtered.filter(c => c.area === areaFilter);
  }

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="aesthetic-card p-8 text-center">
        <p class="text-xs text-slate-400">No clients found matching the query.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(c => {
    const hasPendingBox = Object.entries(boxStates).find(([boxId, st]) => st.status === 'with_client' && st.clientId === c.id);
    const isPaid = c.paymentStatus === 'paid';

    return `
      <div class="aesthetic-card p-3.5 space-y-2">
        <div class="flex items-start justify-between">
          <div>
            <div class="flex items-center space-x-2">
              <h4 class="text-xs font-bold text-slate-900">${c.name}</h4>
              <span class="badge-soft-orange text-[10px] font-semibold px-2 py-0.5 rounded-full">${c.mealType || 'Meal'}</span>
              ${hasPendingBox ? `<span class="badge-soft-red text-[10px] font-bold px-2 py-0.5 rounded-full animate-pulse">Box Out (${hasPendingBox[0]})</span>` : ''}
              ${isPaid 
                ? `<span class="badge-soft-emerald text-[9px] font-bold px-1.5 py-0.2 rounded-full">PAID</span>`
                : `<span class="badge-soft-red text-[9px] font-bold px-1.5 py-0.2 rounded-full">DUE: ₹${c.dueAmount}</span>`
              }
            </div>
            <p class="text-[11px] text-slate-500 mt-0.5">${c.address}</p>
          </div>
          <div class="text-right">
            <span class="text-xs font-black text-slate-800">₹${c.price || settings.defaultPrice}</span>
            <span class="block text-[10px] text-slate-400">/month</span>
          </div>
        </div>

        <div class="flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-100 pt-2">
          <div class="flex items-center space-x-2">
            <span>📞 ${c.phone}</span>
            ${c.boxId ? `<span class="box-code-badge text-[10px] py-0.5 px-2">${c.boxId}</span>` : ''}
          </div>
          
          <div class="flex items-center space-x-2">
            <button onclick="viewClientHistory('${c.id}')" class="text-orange-600 hover:text-orange-700 font-semibold px-2 py-1 bg-orange-50 hover:bg-orange-100 rounded-lg text-[11px] flex items-center">
              <i data-lucide="history" class="w-3.5 h-3.5 mr-1"></i>
              History
            </button>
            <button onclick="editClient('${c.id}')" class="text-slate-500 hover:text-orange-600 p-1">
              <i data-lucide="edit-2" class="w-3.5 h-3.5"></i>
            </button>
            <button onclick="deleteClient('${c.id}', '${c.name}')" class="text-slate-400 hover:text-red-600 p-1">
              <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
            </button>
            <a href="tel:${c.phone}" class="text-emerald-600 p-1">
              <i data-lucide="phone" class="w-3.5 h-3.5"></i>
            </a>
          </div>
        </div>
      </div>
    `;
  }).join('');

  lucide.createIcons();
}

function filterClientList() {
  const search = document.getElementById('clientSearchInput').value;
  const area = document.getElementById('clientAreaFilter').value;
  renderClientList(search, area);
}

function viewClientHistory(clientId) {
  const client = clients.find(c => c.id === clientId);
  if (!client) return;

  const clientLogs = logs.filter(l => l.clientId === clientId).reverse();
  const modal = document.getElementById('clientHistoryModal');
  const title = document.getElementById('clientHistoryTitle');
  const content = document.getElementById('clientHistoryContent');

  title.textContent = `${client.name} - Meal & Delivery History`;

  let historyHtml = `
    <div class="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-xs space-y-1">
      <p class="font-bold text-slate-800">Phone: <span class="font-normal">${client.phone}</span></p>
      <p class="font-bold text-slate-800">Address: <span class="font-normal">${client.address}</span></p>
      <p class="font-bold text-slate-800">Subscription: <span class="font-bold text-emerald-700">₹${client.price}/month</span> &bull; Status: <span class="uppercase font-bold ${client.paymentStatus === 'paid' ? 'text-emerald-600' : 'text-red-600'}">${client.paymentStatus}</span></p>
    </div>

    <h4 class="text-xs font-bold text-slate-900 uppercase tracking-wider pt-2">Past Delivery Log:</h4>
  `;

  if (clientLogs.length === 0) {
    historyHtml += `
      <div class="text-center py-6 text-slate-400 text-xs">
        No delivery history recorded for this client yet.
      </div>
    `;
  } else {
    historyHtml += `<div class="space-y-2">` + clientLogs.map(l => {
      const isDispatch = l.type === 'dispatch';
      const timeStr = new Date(l.timestamp).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
      return `
        <div class="p-3 bg-white border border-slate-200 rounded-xl space-y-1 shadow-2xs">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold ${isDispatch ? 'text-emerald-700' : 'text-blue-700'}">
              ${isDispatch ? `↗️ Dispatched (${l.mealCategory || 'Meal'})` : '↙️ Empty Box Collected'}
            </span>
            <span class="text-[11px] text-slate-400 font-medium">${l.date} &bull; ${timeStr}</span>
          </div>

          <div class="text-xs text-slate-700 flex items-center justify-between">
            <span class="box-code-badge text-[10px] py-0.5 px-2">${l.boxId}</span>
            <div class="flex items-center space-x-1">
              ${l.price ? `<span class="badge-soft-emerald px-1.5 py-0.5 rounded text-[11px] font-bold">₹${l.price}</span>` : ''}
              ${l.paymentMode === 'cash' ? `<span class="badge-soft-orange px-1.5 py-0.5 rounded text-[10px] font-bold">💵 Cash</span>` : ''}
            </div>
          </div>

          ${l.menuTitle ? `
            <div class="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-lg mt-1 border border-slate-100">
              <span class="font-semibold text-orange-800">${l.menuTitle}:</span>
              ${l.menuItems ? `<span class="text-slate-500 block">${l.menuItems}</span>` : ''}
              ${l.extras && l.extras !== 'None' ? `<span class="text-emerald-700 font-semibold block mt-0.5">+ Extras: ${l.extras}</span>` : ''}
            </div>
          ` : ''}
        </div>
      `;
    }).join('') + `</div>`;
  }

  content.innerHTML = historyHtml;
  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeClientHistoryModal() {
  document.getElementById('clientHistoryModal').classList.add('hidden');
}

function openClientModal(client = null) {
  const modal = document.getElementById('clientModal');
  const title = document.getElementById('clientModalTitle');
  const form = document.getElementById('clientForm');

  form.reset();

  if (client) {
    title.textContent = 'Edit Client Information';
    document.getElementById('clientId').value = client.id;
    document.getElementById('clientName').value = client.name;
    document.getElementById('clientPhone').value = client.phone;
    document.getElementById('clientAddress').value = client.address;
    document.getElementById('clientArea').value = client.area || '';
    document.getElementById('clientBoxId').value = client.boxId || '';
    document.getElementById('clientMealType').value = client.mealType || 'Lunch';
    document.getElementById('clientPrice').value = client.price || settings.defaultPrice;
    document.getElementById('clientPaymentStatus').value = client.paymentStatus || 'paid';
    document.getElementById('clientDueAmount').value = client.dueAmount || 0;
    document.getElementById('clientStartDate').value = client.startDate || currentDate;
  } else {
    title.textContent = 'Add New Client';
    document.getElementById('clientId').value = '';
    document.getElementById('clientArea').value = 'Kunwar Singh Nagar';
    document.getElementById('clientBoxId').value = `MAT${String(clients.length + 1).padStart(3, '0')}`;
    document.getElementById('clientPrice').value = settings.defaultPrice;
    document.getElementById('clientPaymentStatus').value = 'paid';
    document.getElementById('clientDueAmount').value = 0;
    document.getElementById('clientStartDate').value = currentDate;
  }

  modal.classList.remove('hidden');
  lucide.createIcons();
}

function closeClientModal() {
  document.getElementById('clientModal').classList.add('hidden');
}

function saveClient(event) {
  event.preventDefault();
  const id = document.getElementById('clientId').value;
  const name = document.getElementById('clientName').value.trim();
  const phone = document.getElementById('clientPhone').value.trim();
  const address = document.getElementById('clientAddress').value.trim();
  const area = document.getElementById('clientArea').value.trim();
  const boxId = document.getElementById('clientBoxId').value.trim().toUpperCase();
  const mealType = document.getElementById('clientMealType').value;
  const price = Number(document.getElementById('clientPrice').value) || settings.defaultPrice;
  const paymentStatus = document.getElementById('clientPaymentStatus').value;
  const dueAmount = Number(document.getElementById('clientDueAmount').value) || 0;
  const startDate = document.getElementById('clientStartDate').value;

  if (id) {
    const index = clients.findIndex(c => c.id === id);
    if (index !== -1) {
      clients[index] = { ...clients[index], name, phone, address, area, boxId, mealType, price, paymentStatus, dueAmount, startDate };
    }
  } else {
    clients.push({
      id: 'c-' + Date.now(),
      name,
      phone,
      address,
      area: area || 'Kunwar Singh Nagar',
      boxId: boxId || ('MAT' + String(clients.length + 1).padStart(3, '0')),
      mealType,
      price,
      paymentStatus,
      dueAmount,
      startDate,
      status: 'active'
    });
  }

  saveData();
  closeClientModal();
  renderClientList();
  renderPaymentsList();
  renderDashboard();

  Swal.fire({
    icon: 'success',
    title: 'Client Saved Successfully',
    timer: 1500,
    showConfirmButton: false
  });
}

function editClient(id) {
  const client = clients.find(c => c.id === id);
  if (client) openClientModal(client);
}

function deleteClient(id, name) {
  Swal.fire({
    title: 'Delete Client?',
    text: `Are you sure you want to remove ${name} from your client ledger?`,
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#ef4444',
    confirmButtonText: 'Yes, Delete',
    cancelButtonText: 'Cancel'
  }).then(res => {
    if (res.isConfirmed) {
      clients = clients.filter(c => c.id !== id);
      saveData();
      renderClientList();
      renderPaymentsList();
      renderDashboard();
    }
  });
}

// ==========================================
// 6-DIGIT QR CODE GENERATOR & PRINT
// ==========================================
function handleQrFormatChange(format) {
  const prefixInput = document.getElementById('qrPrefix');
  const startNumInput = document.getElementById('qrStartNum');

  if (format === 'MAT') {
    prefixInput.value = 'MAT';
    startNumInput.value = 1;
  } else if (format === 'NUM') {
    prefixInput.value = '';
    startNumInput.value = 100001; // Pure 6-digit numeric codes
  }
  generateQRStickers();
}

function generateQRStickers() {
  const format = document.getElementById('qrCodeFormat')?.value || 'MAT';
  let prefix = (document.getElementById('qrPrefix')?.value || 'MAT').toUpperCase();
  const startNum = parseInt(document.getElementById('qrStartNum')?.value || 1);
  const count = parseInt(document.getElementById('qrCount')?.value || 24);
  const grid = document.getElementById('stickersGrid');
  const countInfo = document.getElementById('generatedCountInfo');
  const sheetBizName = document.getElementById('printSheetBizName');
  const sheetBizAddress = document.getElementById('printSheetBizAddress');

  if (sheetBizName) sheetBizName.textContent = settings.bizName;
  if (sheetBizAddress) sheetBizAddress.textContent = `${settings.bizAddress} • Phone: ${settings.bizPhone}`;

  grid.innerHTML = '';

  let firstCode = '';
  let lastCode = '';

  for (let i = 0; i < count; i++) {
    const boxNum = startNum + i;
    let boxId = '';

    if (format === 'NUM') {
      boxId = String(boxNum); // 6-digit number e.g. 100001
    } else {
      // 6 characters: MAT + 3 digits e.g. MAT001
      boxId = `${prefix}${String(boxNum).padStart(3, '0')}`;
    }

    if (i === 0) firstCode = boxId;
    if (i === count - 1) lastCode = boxId;

    const cardId = `qr-card-${boxNum}`;

    const card = document.createElement('div');
    card.className = 'qr-sticker-card shadow-2xs';
    card.innerHTML = `
      <div class="box-badge">${boxId}</div>
      <div id="${cardId}" class="qr-canvas-holder"></div>
      <div class="biz-title">${settings.bizName}</div>
      <div class="biz-address">${settings.bizAddress} &bull; ${settings.bizPhone}</div>
      <div class="return-hint">6-Digit Returnable Box</div>
    `;

    grid.appendChild(card);

    try {
      new QRCode(document.getElementById(cardId), {
        text: boxId,
        width: 100,
        height: 100,
        colorDark: '#0f172a',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
      });
    } catch (e) {
      console.error('QR error:', e);
    }
  }

  if (countInfo) countInfo.textContent = `${count} Stickers Ready (${firstCode} to ${lastCode})`;
}

// ==========================================
// SETTINGS & BACKUP
// ==========================================
function renderSettings() {
  const bizNameInput = document.getElementById('settingBizName');
  const bizAddressInput = document.getElementById('settingBizAddress');
  const bizPhoneInput = document.getElementById('settingBizPhone');
  const defaultPriceInput = document.getElementById('settingDefaultPrice');
  const upiIdInput = document.getElementById('settingUpiId');
  const authPhoneInput = document.getElementById('settingAuthPhone');
  const authEmailInput = document.getElementById('settingAuthEmail');
  const authDisplay = document.getElementById('authDisplayAccount');

  if (bizNameInput) bizNameInput.value = settings.bizName;
  if (bizAddressInput) bizAddressInput.value = settings.bizAddress;
  if (bizPhoneInput) bizPhoneInput.value = settings.bizPhone;
  if (defaultPriceInput) defaultPriceInput.value = settings.defaultPrice;
  if (upiIdInput) upiIdInput.value = settings.upiId || '9311155593@paytm';
  if (authPhoneInput) authPhoneInput.value = settings.bizPhone;
  if (authEmailInput) authEmailInput.value = settings.bizEmail || 'annapurna.tiffin@gmail.com';
  if (authDisplay) authDisplay.textContent = `${settings.bizAddress} (${settings.bizPhone})`;
}

function saveSettings() {
  settings.bizName = document.getElementById('settingBizName').value.trim() || 'Maa Annapurna Tiffin Service';
  settings.bizAddress = document.getElementById('settingBizAddress').value.trim() || 'Kunwar Singh Nagar';
  settings.bizPhone = document.getElementById('settingBizPhone').value.trim() || '+91 9311155593';
  settings.defaultPrice = Number(document.getElementById('settingDefaultPrice').value) || 2500;
  settings.upiId = document.getElementById('settingUpiId').value.trim() || '9311155593@paytm';
  settings.bizEmail = document.getElementById('settingAuthEmail').value.trim() || 'annapurna.tiffin@gmail.com';

  saveData();
  renderDashboard();
  renderSettings();

  Swal.fire({
    icon: 'success',
    title: 'Company Profile Saved',
    timer: 1500,
    showConfirmButton: false
  });
}

function exportDataJSON() {
  const data = { clients, logs, boxStates, settings, weeklyMenu, customMenus, extraItemsCatalog, exportedAt: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `maa-annapurna-tiffin-backup-${currentDate}.json`;
  a.click();
}

function exportDataCSV() {
  let csv = 'ID,Name,Phone,Address,Area,BoxID,MonthlyPrice,PaymentStatus,DueAmount\n';
  clients.forEach(c => {
    csv += `"${c.id}","${c.name}","${c.phone}","${c.address}","${c.area || ''}","${c.boxId || ''}",${c.price},"${c.paymentStatus}",${c.dueAmount || 0}\n`;
  });
  
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `maa-annapurna-clients-${currentDate}.csv`;
  a.click();
}

function importDataJSON(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (data.clients) clients = data.clients;
      if (data.logs) logs = data.logs;
      if (data.boxStates) boxStates = data.boxStates;
      if (data.settings) settings = data.settings;
      if (data.weeklyMenu) {
        delete data.weeklyMenu.sunday;
        weeklyMenu = data.weeklyMenu;
      }
      if (data.customMenus) customMenus = data.customMenus;
      if (data.extraItemsCatalog) extraItemsCatalog = data.extraItemsCatalog;

      saveData();
      renderDashboard();
      renderMenuPlanner();
      renderCustomMenusList();
      renderExtraItemsCatalog();
      renderClientList();
      renderPendingList();
      renderPaymentsList();

      Swal.fire({ icon: 'success', title: 'Data Restored Successfully!' });
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Error', text: 'Backup file is corrupted or invalid.' });
    }
  };
  reader.readAsText(file);
}

function capitalize(s) {
  if (!s) return '';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// ==========================================
// PWA INSTALLATION
// ==========================================
function setupPwa() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').then(() => {
      console.log('ServiceWorker registered');
    }).catch(err => console.log('SW error:', err));
  }

  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    const installBtn = document.getElementById('pwaInstallBtn');
    if (installBtn) installBtn.classList.remove('hidden');
  });
}

function triggerPwaInstall() {
  if (deferredPrompt) {
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult) => {
      deferredPrompt = null;
    });
  } else {
    Swal.fire({
      title: 'Mobile App Installation',
      html: `
        <div class="text-left text-xs space-y-2 text-slate-700">
          <p>1. Open Google Chrome on your Android phone.</p>
          <p>2. Tap the <b>3 dots (&vellip;)</b> in the top-right corner.</p>
          <p>3. Tap <b>"Install app"</b> or <b>"Add to Home Screen"</b>.</p>
          <p>4. Maa Annapurna Tiffin Service icon will install directly on your phone!</p>
        </div>
      `,
      icon: 'info',
      confirmButtonText: 'Got It'
    });
  }
}
