const langs={ar:"العربية",en:"English",fr:"Français",es:"Español",de:"Deutsch",zh:"中文",ko:"한국어",ja:"日本語",ru:"Русский"};
const dict={
"ar-en":{"مرحبا":"Hello","أهلا":"Hi","كيف حالك":"How are you?","شكرا":"Thank you","من فضلك":"Please","صباح الخير":"Good morning","مساء الخير":"Good evening","أين الحمام":"Where is the bathroom?","أحتاج المساعدة":"I need help","لا أفهم":"I don't understand","نعم":"Yes","لا":"No","وداعا":"Goodbye","جيد":"Good"},
"en-ar":{"hello":"مرحبا","hi":"أهلا","how are you":"كيف حالك؟","thank you":"شكرا","please":"من فضلك","good morning":"صباح الخير","good evening":"مساء الخير","where is the bathroom":"أين الحمام؟","i need help":"أحتاج المساعدة","i don't understand":"لا أفهم","yes":"نعم","no":"لا","goodbye":"وداعا","good":"جيد"},
"ar-fr":{"مرحبا":"Bonjour","شكرا":"Merci","صباح الخير":"Bonjour","مساء الخير":"Bonsoir","وداعا":"Au revoir","من فضلك":"S'il vous plaît"},"fr-ar":{"bonjour":"مرحبا","merci":"شكرا","au revoir":"وداعا","s'il vous plaît":"من فضلك"},
"ar-es":{"مرحبا":"Hola","شكرا":"Gracias","صباح الخير":"Buenos días","وداعا":"Adiós","من فضلك":"Por favor"},"es-ar":{"hola":"مرحبا","gracias":"شكرا","buenos días":"صباح الخير","adiós":"وداعا","por favor":"من فضلك"},
"ar-de":{"مرحبا":"Hallo","شكرا":"Danke","صباح الخير":"Guten Morgen","وداعا":"Auf Wiedersehen","من فضلك":"Bitte"},"de-ar":{"hallo":"مرحبا","danke":"شكرا","guten morgen":"صباح الخير","auf wiedersehen":"وداعا","bitte":"من فضلك"},
"ar-zh":{"مرحبا":"你好","شكرا":"谢谢","نعم":"是","لا":"不","جيد":"好","وداعا":"再见"},"zh-ar":{"你好":"مرحبا","谢谢":"شكرا","是":"نعم","不":"لا","好":"جيد","再见":"وداعا"},
"ar-ko":{"مرحبا":"안녕하세요","شكرا":"감사합니다","نعم":"네","لا":"아니요","جيد":"좋아요","وداعا":"안녕히 가세요"},"ko-ar":{"안녕하세요":"مرحبا","감사합니다":"شكرا","네":"نعم","아니요":"لا","좋아요":"جيد","안녕히 가세요":"وداعا"},
"ar-ja":{"مرحبا":"こんにちは","شكرا":"ありがとう","نعم":"はい","لا":"いいえ","جيد":"良い","وداعا":"さようなら"},"ja-ar":{"こんにちは":"مرحبا","ありがとう":"شكرا","はい":"نعم","いいえ":"لا","良い":"جيد","さようなら":"وداعا"},
"ar-ru":{"مرحبا":"Привет","شكرا":"Спасибо","نعم":"Да","لا":"Нет","جيد":"Хорошо","وداعا":"До свидания"},"ru-ar":{"привет":"مرحبا","спасибо":"شكرا","да":"نعم","нет":"لا","хорошо":"جيد","до свидания":"وداعا"}
};
const basePhrases={ar:[["مرحبا","Hello"],["شكرا","Thank you"],["كيف حالك؟","How are you?"],["أحتاج المساعدة","I need help"],["صباح الخير","Good morning"],["من فضلك","Please"],["نعم","Yes"],["وداعا","Goodbye"]],en:[["Hello","مرحبا"],["Thank you","شكرا"],["How are you?","كيف حالك؟"],["I need help","أحتاج المساعدة"],["Good morning","صباح الخير"],["Please","من فضلك"],["Yes","نعم"],["Goodbye","وداعا"]]};
let from=localStorage.from||"ar",to=localStorage.to||"en",history=JSON.parse(localStorage.history||"[]"),pick="from";
const $=id=>document.getElementById(id);
function norm(s){return s.trim().toLowerCase().replace(/[؟?!.,،؛]/g,"").replace(/\s+/g," ")}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c]))}
function render(){
  $("from").textContent=langs[from];$("to").textContent=langs[to];
  document.documentElement.lang=from;document.documentElement.dir=from==="ar"?"rtl":"ltr";
  renderPhrases();renderHistory();
}
function translate(s){
  if(from===to)return s;
  const m=dict[from+"-"+to]||{};const n=norm(s);
  if(m[n])return m[n];
  const words=n.split(/\s+/);const converted=words.map(w=>m[w]||w).join(" ");
  return converted===n?"Offline dictionary: translation not available for this phrase.":converted;
}
function go(){
  const s=$("input").value.trim();if(!s)return toast("اكتب نصًا أولًا");
  const r=translate(s);$("result").textContent=r;$("result").classList.remove("muted");
  history.unshift({a:s,b:r});history=history.slice(0,12);localStorage.history=JSON.stringify(history);renderHistory();
}
function phraseData(){
  if(basePhrases[from])return basePhrases[from];
  const common={zh:[["你好","Hello"],["谢谢","Thank you"],["再见","Goodbye"],["是","Yes"]],ko:[["안녕하세요","Hello"],["감사합니다","Thank you"],["안녕히 가세요","Goodbye"],["네","Yes"]],ja:[["こんにちは","Hello"],["ありがとう","Thank you"],["さようなら","Goodbye"],["はい","Yes"]],ru:[["Привет","Hello"],["Спасибо","Thank you"],["До свидания","Goodbye"],["Да","Yes"]],fr:[["Bonjour","Hello"],["Merci","Thank you"],["Au revoir","Goodbye"],["Oui","Yes"]],es:[["Hola","Hello"],["Gracias","Thank you"],["Adiós","Goodbye"],["Sí","Yes"]],de:[["Hallo","Hello"],["Danke","Thank you"],["Auf Wiedersehen","Goodbye"],["Ja","Yes"]]};return common[from]||basePhrases.en}
function renderPhrases(){
  const p=phraseData();$("phrases").innerHTML=p.map((x,i)=>`<button class="phrase" data-i="${i}">${esc(x[0])}<small>${esc(x[1])}</small></button>`).join("");
  document.querySelectorAll(".phrase").forEach(b=>b.onclick=()=>{const x=p[Number(b.dataset.i)];$("input").value=x[0];count();go()});
}
function renderHistory(){
  if(!history.length){$("history").innerHTML='<div style="text-align:center;color:var(--muted);padding:10px;font-size:12px">لا توجد ترجمات محفوظة بعد</div>';return}
  $("history").innerHTML=history.map((x,i)=>`<button class="history" data-i="${i}"><b>${esc(x.a)}</b><span>→ ${esc(x.b)}</span></button>`).join("");
  document.querySelectorAll(".history").forEach(b=>b.onclick=()=>{const x=history[Number(b.dataset.i)];$("input").value=x.a;count();$("result").textContent=x.b;$("result").classList.remove("muted")});
}
function count(){$("count").textContent=$("input").value.length+"/1000"}
let toastTimer;function toast(s){const t=$("toast");t.textContent=s;t.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove("show"),1500)}
function openModal(which){
  pick=which;$("modalTitle").textContent=which==="from"?"اختر لغة النص":"اختر لغة الترجمة";$("options").innerHTML=Object.entries(langs).map(([id,n])=>`<button class="option" data-id="${id}">${esc(n)}</button>`).join("");
  $("modal").classList.add("open");$("modal").setAttribute("aria-hidden","false");
  document.querySelectorAll(".option").forEach(b=>b.onclick=()=>{if(pick==="from")from=b.dataset.id;else to=b.dataset.id;localStorage.from=from;localStorage.to=to;closeModal();render()});
}
function closeModal(){$("modal").classList.remove("open");$("modal").setAttribute("aria-hidden","true")}
function toggleTheme(){document.body.classList.toggle("dark");localStorage.theme=document.body.classList.contains("dark")?"dark":"light";$("themeLabel").textContent=document.body.classList.contains("dark")?"داكن":"فاتح"}
$("from").onclick=()=>openModal("from");$("to").onclick=()=>openModal("to");$("swap").onclick=()=>{[from,to]=[to,from];localStorage.from=from;localStorage.to=to;render()};$("translate").onclick=go;
$("input").oninput=count;$("clear").onclick=()=>{$("input").value="";$("result").textContent="ستظهر الترجمة هنا";$("result").classList.add("muted");count()};
$("clearHistory").onclick=()=>{history=[];localStorage.history="[]";renderHistory()};$("closeModal").onclick=closeModal;$("modal").onclick=e=>{if(e.target.id==="modal")closeModal()};
$("copy").onclick=async()=>{try{await navigator.clipboard.writeText($("result").textContent);toast("تم النسخ")}catch{toast("تعذر النسخ")}};
$("speak").onclick=()=>{if("speechSynthesis" in window){const u=new SpeechSynthesisUtterance($("result").textContent);u.lang=to==="ar"?"ar-SA":to;speechSynthesis.cancel();speechSynthesis.speak(u)}else toast("النطق غير متاح")};
const drawer=$("drawer");$("menuBtn").onclick=()=>{drawer.classList.add("open");drawer.setAttribute("aria-hidden","false")};$("closeMenu").onclick=()=>{drawer.classList.remove("open");drawer.setAttribute("aria-hidden","true")};document.querySelector(".drawer-backdrop").onclick=()=>{$("closeMenu").click()};
document.querySelector('[data-action="history"]').onclick=()=>{$("closeMenu").click();$("history").scrollIntoView({behavior:"smooth",block:"start"})};
$("privacyItem").onclick=()=>{$("closeMenu").click();toast("النصوص تُعالج محليًا")};$("aboutItem").onclick=()=>{$("closeMenu").click();toast("Transora · الإصدار 1.0")};$("themeItem").onclick=toggleTheme;$("languageItem").onclick=()=>{$("closeMenu").click();openModal("from")};
if(localStorage.theme==="dark")document.body.classList.add("dark");$("themeLabel").textContent=document.body.classList.contains("dark")?"داكن":"فاتح";render();count();
