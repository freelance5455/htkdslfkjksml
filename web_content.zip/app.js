import {initializeApp} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import {getAuth,createUserWithEmailAndPassword,signInWithEmailAndPassword,onAuthStateChanged,signOut} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import {getFirestore,doc,setDoc,getDoc,collection,addDoc,query,where,getDocs,onSnapshot,orderBy,serverTimestamp,limit} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";
import {getDatabase,ref,set,onDisconnect,onValue,serverTimestamp as rtdbTimestamp} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-database.js";
import {firebaseConfig} from "./firebase-config.js";
import {watchNetwork,retry} from "./network.js";

const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getFirestore(app),rtdb=getDatabase(app);
const $=id=>document.getElementById(id);
let me=null,peer=null,unsubscribeMessages=null,unsubscribePresence=null;

const pseudoEmail=u=>u.toLowerCase().replace(/[^a-z0-9_]/g,"")+"@nayeem.invalid";
const validUser=u=>/^[a-zA-Z0-9_]{3,30}$/.test(u);

$("goLogin").onclick=()=>{$("registerBox").classList.add("hidden");$("loginBox").classList.remove("hidden")};
$("goRegister").onclick=()=>{$("loginBox").classList.add("hidden");$("registerBox").classList.remove("hidden")};

$("registerBtn").onclick=async()=>{
 const name=$("rName").value.trim(),username=$("rUser").value.trim().toLowerCase(),pin=$("rPin").value,pin2=$("rPin2").value;
 if(!name||!validUser(username)||pin.length<6)return alert("নাম, 3-30 অক্ষরের Username এবং কমপক্ষে ৬ অক্ষরের Lock দিন।");
 if(pin!==pin2)return alert("দুইটি Lock একই নয়।");
 try{
   const existing=await getDocs(query(collection(db,"users"),where("username","==",username),limit(1)));
   if(!existing.empty)return alert("এই Username আগে থেকেই আছে।");
   const cred=await createUserWithEmailAndPassword(auth,pseudoEmail(username),pin);
   await setDoc(doc(db,"users",cred.user.uid),{uid:cred.user.uid,name,username,createdAt:serverTimestamp(),photoURL:""});
 }catch(e){alert("অ্যাকাউন্ট তৈরি হয়নি: "+e.message)}
};

$("loginBtn").onclick=async()=>{
 const username=$("lUser").value.trim().toLowerCase(),pin=$("lPin").value;
 if(!validUser(username)||!pin)return alert("Username ও Lock দিন।");
 try{await signInWithEmailAndPassword(auth,pseudoEmail(username),pin)}
 catch(e){alert("লগইন হয়নি। Username বা Lock পরীক্ষা করুন।")}
};

$("logoutBtn").onclick=()=>signOut(auth);

watchNetwork(online=>{
  const line=document.getElementById("meLine");
  if(line) line.textContent=(me?("@"+me.username+" • "):"")+ (online?"online":"offline — reconnecting…");
});
onAuthStateChanged(auth,async user=>{
 if(!user){me=null;$("auth").classList.remove("hidden");$("messenger").classList.add("hidden");return}
 const snap=await getDoc(doc(db,"users",user.uid)); me={uid:user.uid,...snap.data()};
 $("auth").classList.add("hidden");$("messenger").classList.remove("hidden");$("meLine").textContent="@"+me.username+" • online";
 await set(ref(rtdb,"presence/"+me.uid),{state:"online",lastChanged:rtdbTimestamp()});
 onDisconnect(ref(rtdb,"presence/"+me.uid)).set({state:"offline",lastChanged:rtdbTimestamp()});
 loadChats();
});

async function loadChats(){
 const q=query(collection(db,"users"),orderBy("username"),limit(100));
 onSnapshot(q,s=>{
   const box=$("chatList");box.innerHTML="";
   s.forEach(d=>{if(d.id===me.uid)return;const u=d.data();const row=document.createElement("div");row.className="chatRow";row.innerHTML='<div class="avatar">'+(u.name||"U")[0].toUpperCase()+'</div><div><b>'+escapeHtml(u.name)+'</b><p>@'+escapeHtml(u.username)+'</p></div><span id="p_'+d.id+'">⚪</span>';row.onclick=()=>openChat(u);box.appendChild(row);watchPresence(d.id,$("p_"+d.id));});
 });
}
function watchPresence(uid,node){onValue(ref(rtdb,"presence/"+uid),s=>{node.textContent=s.val()?.state==="online"?"🟢":"⚪"})}

async function searchUser(){
 const u=$("userSearch").value.trim().toLowerCase();$("searchResults").innerHTML="";
 if(!u)return;
 const s=await getDocs(query(collection(db,"users"),where("username","==",u),limit(5)));
 s.forEach(d=>{const x=d.data();const row=document.createElement("div");row.className="person";row.innerHTML='<div class="avatar">'+x.name[0].toUpperCase()+'</div><div><b>'+escapeHtml(x.name)+'</b><p>@'+escapeHtml(x.username)+'</p></div>';row.onclick=()=>openChat(x);$("searchResults").appendChild(row)});
 if(s.empty)$("searchResults").innerHTML="<p style='padding:12px'>কেউ পাওয়া যায়নি।</p>";
}
$("searchBtn").onclick=searchUser;

async function openChat(u){
 peer=u;$("home").classList.add("hidden");$("chatView").classList.remove("hidden");
 $("peerName").textContent=u.name;$("peerAvatar").textContent=u.name[0].toUpperCase();
 if(unsubscribeMessages)unsubscribeMessages();
 const chatId=[me.uid,u.uid].sort().join("_");
 const q=query(collection(db,"chats",chatId,"messages"),orderBy("createdAt"),limit(200));
 unsubscribeMessages=onSnapshot(q,s=>{const box=$("messages");box.innerHTML="";s.forEach(d=>{const x=d.data(),b=document.createElement("div");b.className="bubble"+(x.senderId===me.uid?" mine":"");b.innerHTML=escapeHtml(x.text||"")+"<small>"+(x.senderId===me.uid?"আপনি":"")+"</small>";box.appendChild(b)});box.scrollTop=box.scrollHeight});
 watchPresence(u.uid,$("peerStatus")); 
}
$("backBtn").onclick=()=>{$("chatView").classList.add("hidden");$("home").classList.remove("hidden");if(unsubscribeMessages){unsubscribeMessages();unsubscribeMessages=null}};

$("composer").onsubmit=async e=>{
 e.preventDefault();const text=$("messageInput").value.trim();if(!text||!peer)return;
 const chatId=[me.uid,peer.uid].sort().join("_");
 await retry(()=>addDoc(collection(db,"chats",chatId,"messages"),{text,senderId:me.uid,receiverId:peer.uid,createdAt:serverTimestamp()}));
 $("messageInput").value="";
};

function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}

// Call buttons are intentionally marked as a WebRTC-ready hook.
// Real production calling needs signaling + TURN server and native/WebView microphone-camera permissions.
$("voiceBtn").onclick=()=>alert("Voice call: WebRTC signaling/TURN server ধাপটি পরের production setup-এ যুক্ত করতে হবে।");
$("videoBtn").onclick=()=>alert("Video call: WebRTC signaling/TURN server ধাপটি পরের production setup-এ যুক্ত করতে হবে।");
