(() => {
  "use strict";
  const DB_NAME = "OfflineLoginDB";
  const DB_VERSION = 1;
  const STORE = "users";
  const $ = (id) => document.getElementById(id);
  let db;

  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE)) {
          const store = database.createObjectStore(STORE, { keyPath: "username" });
          store.createIndex("role", "role", { unique: false });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  function allUsers() {
    return new Promise((resolve, reject) => {
      const request = db.transaction(STORE, "readonly").objectStore(STORE).getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  function getUser(username) {
    return new Promise((resolve, reject) => {
      const request = db.transaction(STORE, "readonly").objectStore(STORE).get(username);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  function saveUser(user) {
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).put(user);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  async function seedDemoUsers() {
    if (!(await getUser("admin"))) {
      await saveUser({ username: "admin", password: "admin123", role: "admin", status: "Active" });
    }
    if (!(await getUser("user"))) {
      await saveUser({ username: "user", password: "user123", role: "user", status: "Active" });
    }
  }

  function showLogin(message = "") {
    $("loginView").classList.remove("hidden");
    $("dashboardView").classList.add("hidden");
    $("loginMessage").textContent = message;
  }

  async function showDashboard(username) {
    const user = await getUser(username);
    if (!user) {
      localStorage.removeItem("offlineLoginSession");
      return showLogin("Account পাওয়া যায়নি। আবার লগইন করুন।");
    }
    $("loginView").classList.add("hidden");
    $("dashboardView").classList.remove("hidden");
    $("welcomeTitle").textContent = `স্বাগতম, ${user.username}`;
    $("roleBadge").textContent = user.role.toUpperCase();
    $("accountName").textContent = user.username;
    $("accountRole").textContent = user.role.toUpperCase();
    const isAdmin = user.role === "admin";
    $("adminArea").classList.toggle("hidden", !isAdmin);
    $("userArea").classList.toggle("hidden", isAdmin);
    if (isAdmin) await renderUsers();
  }

  async function renderUsers() {
    const users = await allUsers();
    $("usersTable").replaceChildren();
    users.forEach((user) => {
      const row = document.createElement("tr");
      [user.username, user.role.toUpperCase(), user.status].forEach((value) => {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });
      $("usersTable").appendChild(row);
    });
  }

  $("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const username = $("username").value.trim().toLowerCase();
    const password = $("password").value;
    const user = await getUser(username);
    if (!user || user.password !== password) {
      $("loginMessage").textContent = "Username অথবা password সঠিক নয়।";
      return;
    }
    localStorage.setItem("offlineLoginSession", username);
    $("loginForm").reset();
    await showDashboard(username);
  });

  $("logoutButton").addEventListener("click", () => {
    localStorage.removeItem("offlineLoginSession");
    showLogin("আপনি সফলভাবে Logout করেছেন।");
  });

  $("createUserForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const username = $("newUsername").value.trim().toLowerCase();
    const password = $("newPassword").value;
    if (!/^[a-z0-9_.-]{3,30}$/.test(username)) {
      $("createMessage").textContent = "Username ৩–৩০ অক্ষরের হতে হবে; ইংরেজি অক্ষর, সংখ্যা, _, ., - ব্যবহার করুন।";
      return;
    }
    if (await getUser(username)) {
      $("createMessage").textContent = "এই username আগে থেকেই আছে।";
      return;
    }
    await saveUser({ username, password, role: "user", status: "Active" });
    $("createUserForm").reset();
    $("createMessage").style.color = "#047857";
    $("createMessage").textContent = "নতুন User তৈরি হয়েছে।";
    await renderUsers();
  });

  async function start() {
    try {
      if (!("indexedDB" in window)) throw new Error("এই browser-এ IndexedDB support নেই।");
      db = await openDatabase();
      await seedDemoUsers();
      const session = localStorage.getItem("offlineLoginSession");
      if (session) await showDashboard(session);
      if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1")) {
        navigator.serviceWorker.register("./sw.js").catch(() => {});
      }
    } catch (error) {
      showLogin("App চালু করা যায়নি। আধুনিক browser দিয়ে খুলুন।");
      console.error(error);
    }
  }
  start();
})();
