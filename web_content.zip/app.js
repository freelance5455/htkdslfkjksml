const chapters = [
  {id:0,title:"Prolog",pages:[{
    kicker:"Prolog",
    heading:"Die schwarze Sonne",
    text:`Vor langer Zeit stand eine Sonne am Himmel, die kein Licht schenkte. Unter ihr waren die Völker vereint, doch unter der Welt regte sich etwas, das niemand hätte wecken dürfen. Was damals geschah, wurde zu Geschichte, dann zu Legende und schließlich zu etwas, worüber niemand mehr sprach.`
  }]},
  {id:1,title:"Kapitel I – Der Dieb der rostigen Gasse",pages:[{
    kicker:"Kapitel I",
    heading:"Der Dieb der rostigen Gasse",
    text:`Kaels Geschichte beginnt mit einem gestohlenen Geldbeutel und einem schwarzen Ring, dessen Bedeutung er nicht kennt. Der eigentliche Romantext wird in die fertige Reader-Fassung eingesetzt, sobald die erhaltenen Originalkapitel vorliegen.`
  }]},
  {id:2,title:"Kapitel II",pages:[{
    kicker:"Kapitel II",
    heading:"",
    text:`Dieses Kapitel ist für den späteren Originaltext reserviert.`
  }]},
  {id:3,title:"Kapitel III",pages:[{
    kicker:"Kapitel III",
    heading:"",
    text:`Dieses Kapitel ist für den späteren Originaltext reserviert.`
  }]},
  {id:4,title:"Kapitel IV – Das Grab unter der Stadt",pages:[{
    kicker:"Kapitel IV",
    heading:"Das Grab unter der Stadt",
    text:`Avarok tritt in die Geschichte. Er ist der erste König unter der schwarzen Sonne und führt Kael tiefer in die Geheimnisse der alten Welt.`
  }]},
  {id:5,title:"Kapitel V – Der König ohne Reich",pages:[{
    kicker:"Kapitel V",
    heading:"Der König ohne Reich",
    text:`Avaroks Vergangenheit und seine Verbindung zur alten Zeit werden weiter enthüllt.`
  }]},
  {id:6,title:"Kapitel VI",pages:[{
    kicker:"Kapitel VI",
    heading:"",
    text:`Die Reise führt weiter in Richtung Falkengrat. Unter der Oberfläche der Welt wartet etwas, dessen Geschichte älter ist als die Reiche der Gegenwart.`
  }]},
  {id:7,title:"Kapitel VII – Der Verräter aus der ersten Zeit",pages:[{
    kicker:"Kapitel VII",
    heading:"Der Verräter aus der ersten Zeit",
    text:`Unter Falkengrat erscheint die Aschenklinge. Avarok erkennt sie. Kaels Ring reagiert auf die uralte Halle, Stimmen aus einer vergangenen Welt dringen zu ihm durch, und die schwarze Sonne erscheint in seinen Erinnerungen. Der Boden bricht auf. Die Aschenklinge erkennt, was Kael wirklich ist: das Siegel.`
  }]},
  {id:8,title:"Kapitel VIII – Das Licht unter dem Siegel",pages:[{
    kicker:"Kapitel VIII",
    heading:"Das Licht unter dem Siegel",
    text:`Aus der Tiefe kommt kein gewöhnliches Wesen, sondern ein kaltes Licht, das alles zu verschlucken scheint. Kael erkennt, dass seine Verbindung zum Siegel tiefer reicht, als er geglaubt hat. Das Licht spricht von ihm als dem Gefängnis und fordert ihn auf, sich zu öffnen. Kael tritt schließlich darauf zu. Damit beginnt eine neue Phase der Geschichte.`
  }]}
];

let currentChapter = Number(localStorage.getItem("vharanorChapter") || 8);
let currentPage = Number(localStorage.getItem("vharanorPage") || 0);
let deferredInstall = null;

const cover = document.getElementById("cover");
const reader = document.getElementById("reader");
const drawer = document.getElementById("drawer");
const pageContent = document.getElementById("pageContent");
const chapterLabel = document.getElementById("chapterLabel");
const pageNumber = document.getElementById("pageNumber");
const page = document.getElementById("page");

function getChapter(){
  return chapters.find(c=>c.id===currentChapter) || chapters[8];
}
function render(){
  const ch=getChapter();
  const p=ch.pages[currentPage] || ch.pages[0];
  chapterLabel.textContent=ch.title;
  pageNumber.textContent=`${currentPage+1}`;
  pageContent.innerHTML="";
  if(p.kicker) pageContent.insertAdjacentHTML("beforeend",`<div class="chapter-kicker">${escapeHtml(p.kicker)}</div>`);
  if(p.heading) pageContent.insertAdjacentHTML("beforeend",`<h2>${escapeHtml(p.heading)}</h2>`);
  p.text.split(/\n+/).forEach((t,i)=>{
    pageContent.insertAdjacentHTML("beforeend",`<p class="${i===0?'dropcap':''}">${escapeHtml(t)}</p>`);
  });
  localStorage.setItem("vharanorChapter",currentChapter);
  localStorage.setItem("vharanorPage",currentPage);
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

function openReader(){
  cover.classList.remove("active");
  reader.classList.add("active");
  render();
}
function go(delta){
  const ch=getChapter();
  if(delta>0 && currentPage < ch.pages.length-1){currentPage++; render(); return;}
  if(delta<0 && currentPage>0){currentPage--; render(); return;}
  if(delta>0 && currentChapter<chapters.length-1){currentChapter++;currentPage=0;render();return;}
  if(delta<0 && currentChapter>0){currentChapter--;currentPage=chapters[currentChapter].pages.length-1;render();return;}
}
function populateChapters(){
  const list=document.getElementById("chapterList");
  list.innerHTML="";
  chapters.forEach(ch=>{
    const b=document.createElement("button");
    b.className="chapter-item"+(ch.id===currentChapter?" current":"");
    b.textContent=ch.title;
    b.onclick=()=>{currentChapter=ch.id;currentPage=0;drawer.classList.remove("open");render()};
    list.appendChild(b);
  });
}

let startY=0,startX=0;
document.getElementById("pageViewport").addEventListener("touchstart",e=>{
  startY=e.touches[0].clientY;startX=e.touches[0].clientX;
},{passive:true});
document.getElementById("pageViewport").addEventListener("touchend",e=>{
  const dy=e.changedTouches[0].clientY-startY;
  const dx=e.changedTouches[0].clientX-startX;
  if(Math.abs(dy)>55 && Math.abs(dy)>Math.abs(dx)){go(dy<0?1:-1)}
},{passive:true});

document.getElementById("openBook").onclick=openReader;
document.getElementById("backButton").onclick=()=>{reader.classList.remove("active");cover.classList.add("active")};
document.getElementById("menuButton").onclick=()=>{drawer.classList.add("open");populateChapters()};
document.getElementById("closeMenu").onclick=()=>drawer.classList.remove("open");
document.getElementById("continueButton").onclick=()=>{drawer.classList.remove("open");render()};
document.getElementById("bookmarkButton").onclick=()=>{
  localStorage.setItem("vharanorBookmark",JSON.stringify({chapter:currentChapter,page:currentPage}));
  alert("Lesezeichen gespeichert.");
};
document.getElementById("chaptersButton").onclick=populateChapters;

window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault(); deferredInstall=e;
  document.getElementById("installButton").classList.remove("hidden");
});
document.getElementById("installButton").onclick=async()=>{
  if(!deferredInstall)return;
  deferredInstall.prompt();
  await deferredInstall.userChoice;
  deferredInstall=null;
  document.getElementById("installButton").classList.add("hidden");
};

if("serviceWorker" in navigator){
  window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));
}
