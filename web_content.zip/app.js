import { getPiper } from "./piper-adapter.js";

const $ = (s) => document.querySelector(s);
const audio = $("#audio");
const statusEl = $("#status");
const progress = $("#progress");

let run = 0;
let urls = [];
let chunks = [];
let index = 0;
let paused = false;
let bookChapters = [];
let piperReady = null;          // Promise for warm-up
let blobCache = new Map();      // index -> Blob (current run)
const PREFETCH = 3;             // how many chunks to synthesize ahead
const BOOKMARK_KEY = "vorlese-bookmark-v1";

/* ---------- Helpers ---------- */

function log(msg) {
  console.log("[vorlese]", msg);
}

function setStatus(t) {
  statusEl.textContent = t;
}

const setState = (s) => {
  const busy = s !== "idle";
  $("#start").disabled = busy;
  $("#pause").disabled = !busy;
  $("#stop").disabled = !busy;
  $("#pause").textContent = paused ? "▶ Weiter" : "Ⅱ Pause";
};

function split(t, n = 1600) {
  const a = [];
  t = t.trim().replace(/\r\n/g, "\n").replace(/\s+\n/g, "\n");
  while (t) {
    let c = Math.min(n, t.length);
    if (c < t.length) {
      // Prefer sentence ends, then newlines, then spaces
      const p = Math.max(
        t.lastIndexOf(". ", c),
        t.lastIndexOf("! ", c),
        t.lastIndexOf("? ", c),
        t.lastIndexOf(".\n", c),
        t.lastIndexOf("\n\n", c),
        t.lastIndexOf("\n", c),
        t.lastIndexOf(" ", c)
      );
      if (p > n * 0.3) c = p + 1;
    }
    a.push(t.slice(0, c).trim());
    t = t.slice(c).trim();
  }
  return a.filter(Boolean);
}

function cleanup() {
  audio.pause();
  audio.removeAttribute("src");
  audio.load();
  audio.hidden = true;
  urls.forEach((u) => URL.revokeObjectURL(u));
  urls = [];
  blobCache.clear();
}

function done(msg = "Fertig, mein Schatz.") {
  cleanup();
  paused = false;
  setState("idle");
  progress.value = 100;
  setStatus(msg);
}

function applyRate() {
  const rate = +$("#rate").value;
  audio.playbackRate = rate;
  return rate;
}

function applyVolume() {
  const el = $("#volume");
  if (el) audio.volume = +el.value;
}

function currentVoiceId() {
  const v = $("#voice").value;
  if (v.startsWith("piper:")) return v.slice(6);
  return null;
}

function isPiper() {
  return $("#voice").value.startsWith("piper:");
}

function currentSpeakerId() {
  if (!$("#voice").value.includes("thorsten_emotional")) return 0;
  const el = $("#emotion");
  return el ? +el.value : 4;
}

function updateEmotionVisibility() {
  const lab = $("#emotionLabel");
  if (!lab) return;
  const show = $("#voice").value.includes("thorsten_emotional");
  lab.hidden = !show;
}

/* ---------- File loaders ---------- */

function htmlToText(html) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  doc.querySelectorAll("script, style, nav, header, footer").forEach((n) => n.remove());
  const text = doc.body?.textContent || "";
  return text.replace(/\u00a0/g, " ").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
}

async function loadJSZip() {
  if (globalThis.JSZip) return globalThis.JSZip;
  await new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js";
    s.onload = resolve;
    s.onerror = () => reject(new Error("JSZip konnte nicht geladen werden"));
    document.head.appendChild(s);
  });
  return globalThis.JSZip;
}

async function readEpub(file) {
  setStatus("EPUB wird gelesen …");
  const JSZip = await loadJSZip();
  const zip = await JSZip.loadAsync(await file.arrayBuffer());

  let opfPath = "content.opf";
  const container = zip.file("META-INF/container.xml");
  if (container) {
    const xml = await container.async("string");
    const m = xml.match(/full-path\s*=\s*["']([^"']+)["']/i);
    if (m) opfPath = m[1];
  }

  const opfFile = zip.file(opfPath);
  if (!opfFile) throw new Error("EPUB: content.opf nicht gefunden");
  const opf = await opfFile.async("string");
  const opfDir = opfPath.includes("/") ? opfPath.replace(/\/[^/]+$/, "/") : "";

  const idToHref = {};
  const itemRe = /<item\b[^>]*>/gi;
  let im;
  while ((im = itemRe.exec(opf))) {
    const tag = im[0];
    const id = (tag.match(/\bid\s*=\s*["']([^"']+)["']/i) || [])[1];
    const href = (tag.match(/\bhref\s*=\s*["']([^"']+)["']/i) || [])[1];
    if (id && href) idToHref[id] = href;
  }

  const navMap = {};
  try {
    const ncxName = Object.keys(zip.files).find((n) => /\.ncx$/i.test(n) && !zip.files[n].dir);
    if (ncxName) {
      const ncx = await zip.file(ncxName).async("string");
      const navRe = /<navPoint\b[\s\S]*?<\/navPoint>/gi;
      let nm;
      while ((nm = navRe.exec(ncx))) {
        const block = nm[0];
        const label = (block.match(/<text[^>]*>([^<]+)<\/text>/i) || [])[1];
        const src = (block.match(/<content[^>]+src\s*=\s*["']([^"'#]+)/i) || [])[1];
        if (label && src) {
          const base = ncxName.includes("/") ? ncxName.replace(/\/[^/]+$/, "/") : "";
          navMap[(base + src).replace(/^\.\//, "")] = label.trim();
          navMap[src.replace(/^\.\//, "")] = label.trim();
        }
      }
    }
    const navHtml = Object.keys(zip.files).find(
      (n) => /nav\.(x?html?)$/i.test(n) && !zip.files[n].dir
    );
    if (navHtml) {
      const raw = await zip.file(navHtml).async("string");
      const aRe = /<a\b[^>]*href\s*=\s*["']([^"'#]+)["'][^>]*>([\s\S]*?)<\/a>/gi;
      let am;
      while ((am = aRe.exec(raw))) {
        const href = am[1].trim();
        const title = am[2].replace(/<[^>]+>/g, "").trim();
        if (href && title) {
          const base = navHtml.includes("/") ? navHtml.replace(/\/[^/]+$/, "/") : "";
          navMap[(base + href).replace(/^\.\//, "")] = title;
          navMap[href.replace(/^\.\//, "")] = title;
        }
      }
    }
  } catch (e) {
    console.warn("Nav parse:", e);
  }

  const spineIds = [];
  const itemrefRe = /<itemref\b[^>]*>/gi;
  let sm;
  while ((sm = itemrefRe.exec(opf))) {
    const idref = (sm[0].match(/\bidref\s*=\s*["']([^"']+)["']/i) || [])[1];
    if (idref) spineIds.push(idref);
  }

  const chapters = [];
  for (let i = 0; i < spineIds.length; i++) {
    const id = spineIds[i];
    const href = idToHref[id];
    if (!href) continue;
    const path = opfDir + href;
    const f = zip.file(path) || zip.file(decodeURIComponent(path));
    if (!f) continue;
    const raw = await f.async("string");
    const t = htmlToText(raw);
    if (!t || t.length < 20) continue;

    let title =
      navMap[path] ||
      navMap[href] ||
      navMap[path.replace(/^\.\//, "")] ||
      null;
    if (!title) {
      const h = raw.match(/<h[1-3][^>]*>([\s\S]*?)<\/h[1-3]>/i);
      if (h) title = h[1].replace(/<[^>]+>/g, "").trim();
    }
    if (!title) title = "Kapitel " + (chapters.length + 1);
    if (title.length > 80) title = title.slice(0, 77) + "…";

    chapters.push({ title, text: t });
  }

  if (!chapters.length) {
    const names = Object.keys(zip.files).filter(
      (n) => /\.(x?html?)$/i.test(n) && !zip.files[n].dir
    );
    for (const n of names.sort()) {
      const t = htmlToText(await zip.file(n).async("string"));
      if (t && t.length >= 20) chapters.push({ title: n.split("/").pop(), text: t });
    }
  }

  if (!chapters.length) throw new Error("EPUB enthält keinen lesbaren Text");

  bookChapters = chapters;
  fillChapterSelect();
  return chapters.map((ch) => ch.text).join("\n\n");
}

async function loadPdfJs() {
  if (globalThis.pdfjsLib) return globalThis.pdfjsLib;
  await new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.min.js";
    s.onload = resolve;
    s.onerror = () => reject(new Error("pdf.js konnte nicht geladen werden"));
    document.head.appendChild(s);
  });
  const lib = globalThis.pdfjsLib;
  lib.GlobalWorkerOptions.workerSrc =
    "https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/build/pdf.worker.min.js";
  return lib;
}

async function readPdf(file) {
  bookChapters = [];
  fillChapterSelect();
  setStatus("PDF wird gelesen …");
  const pdfjsLib = await loadPdfJs();
  const data = new Uint8Array(await file.arrayBuffer());
  const doc = await pdfjsLib.getDocument({ data }).promise;
  const parts = [];
  for (let i = 1; i <= doc.numPages; i++) {
    setStatus(`PDF Seite ${i} von ${doc.numPages} …`);
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const line = content.items.map((it) => it.str).join(" ");
    if (line.trim()) parts.push(line.trim());
  }
  const text = parts.join("\n\n").trim();
  if (!text) throw new Error("PDF enthält keinen extrahierbaren Text (evtl. nur Bilder/Scan)");
  return text;
}

function fillChapterSelect() {
  const wrap = $("#chapterWrap");
  const sel = $("#chapter");
  if (!wrap || !sel) return;
  sel.innerHTML = "";
  if (!bookChapters.length) {
    wrap.hidden = true;
    return;
  }
  wrap.hidden = false;
  bookChapters.forEach((ch, i) => {
    sel.add(new Option(ch.title, String(i)));
  });
  sel.onchange = () => {
    const i = +sel.value;
    if (!bookChapters[i]) return;
    const from = bookChapters.slice(i).map((c) => c.text).join("\n\n");
    $("#text").value = from;
    setStatus("Kapitel: " + bookChapters[i].title + " – bereit zum Vorlesen.");
    progress.value = 0;
  };
  $("#text").value = bookChapters.map((c) => c.text).join("\n\n");
}

async function readFile(file) {
  const name = (file.name || "").toLowerCase();
  const type = (file.type || "").toLowerCase();

  if (name.endsWith(".epub") || type.includes("epub")) {
    return readEpub(file);
  }
  if (name.endsWith(".pdf") || type === "application/pdf") {
    return readPdf(file);
  }
  bookChapters = [];
  fillChapterSelect();
  return file.text();
}

/* ---------- Playback – improved continuous queue ---------- */

async function playPiper(myRun) {
  const voiceId = currentVoiceId();
  setStatus("Bereite Stimme vor …");

  // Re-use already warmed-up module if possible
  const piper = await (piperReady || getPiper());
  if (myRun !== run) return;

  // Clear previous cache for this run
  blobCache.clear();

  async function synthesize(i) {
    if (blobCache.has(i)) return blobCache.get(i);
    if (i >= chunks.length) return null;

    setStatus(`Erzeuge Abschnitt ${i + 1}/${chunks.length} …`);
    const blob = await piper.predict(
      { text: chunks[i], voiceId, speakerId: currentSpeakerId() },
      (p) => {
        if (p?.total) {
          const pct = Math.round((p.loaded * 100) / p.total);
          setStatus(`Modell-Download: ${pct} % (${Math.round(p.loaded / 1e6)} / ${Math.round(p.total / 1e6)} MB)`);
        }
      }
    );
    if (!blob || !(blob instanceof Blob) || blob.size < 100) {
      throw new Error("Leerer Audio-Blob (size=" + (blob?.size ?? 0) + ")");
    }
    blobCache.set(i, blob);
    return blob;
  }

  // Prefetch helper – keeps PREFETCH chunks ready
  function kickPrefetch(from) {
    for (let k = 0; k < PREFETCH; k++) {
      const target = from + k;
      if (target < chunks.length && !blobCache.has(target)) {
        synthesize(target).catch((e) => log("prefetch " + target + ": " + e.message));
      }
    }
  }

  async function playIndex(i) {
    if (myRun !== run) return;
    if (i >= chunks.length) return done();

    index = i;
    progress.value = (i / chunks.length) * 100;

    // Make sure current + next ones are cooking
    kickPrefetch(i);

    let blob;
    try {
      blob = await synthesize(i);
    } catch (e) {
      log("predict Fehler: " + (e?.message || e));
      throw e;
    }
    if (myRun !== run) return;

    const u = URL.createObjectURL(blob);
    urls.push(u);

    // Smooth hand-off: set src and play without aggressive cleanup
    audio.src = u;
    audio.hidden = false;
    applyRate();
    applyVolume();

    await new Promise((resolve, reject) => {
      const onEnded = () => {
        cleanupListeners();
        resolve();
      };
      const onError = () => {
        cleanupListeners();
        reject(new Error("Audio konnte nicht abgespielt werden"));
      };
      function cleanupListeners() {
        audio.removeEventListener("ended", onEnded);
        audio.removeEventListener("error", onError);
      }
      audio.addEventListener("ended", onEnded);
      audio.addEventListener("error", onError);
      audio.play().catch(reject);
    });

    if (myRun !== run) return;

    // Free old blobs (keep last 2 for safety)
    if (urls.length > 4) {
      const old = urls.splice(0, urls.length - 3);
      old.forEach((u) => URL.revokeObjectURL(u));
    }
    // Drop old cache entries
    for (const key of blobCache.keys()) {
      if (key < i - 1) blobCache.delete(key);
    }

    setStatus(`Liest Abschnitt ${i + 1}/${chunks.length} …`);
    await playIndex(i + 1);
  }

  // Start prefetching from the beginning immediately
  kickPrefetch(index);
  setStatus(`Liest Abschnitt ${index + 1}/${chunks.length} …`);
  await playIndex(index);
}

function deviceSpeak(myRun) {
  const synth = speechSynthesis;
  function next() {
    if (myRun !== run) return;
    if (index >= chunks.length) return done();

    const u = new SpeechSynthesisUtterance(chunks[index]);
    const val = $("#voice").value;
    if (val.startsWith("device:")) {
      const name = val.slice(7);
      u.voice = synth.getVoices().find((v) => v.name === name) || null;
    }
    u.lang = u.voice?.lang || "de-DE";
    u.rate = +$("#rate").value;

    u.onend = () => {
      index++;
      progress.value = (index / chunks.length) * 100;
      next();
    };
    u.onerror = (e) => fail(new Error(e.error || "Gerätestimme fehlgeschlagen"));

    synth.speak(u);
    setStatus(`Liest Abschnitt ${index + 1}/${chunks.length} …`);
  }
  next();
}

function fail(e) {
  console.error(e);
  const msg = e?.message || String(e);
  log("FAIL: " + msg);

  if (isPiper() && (msg.includes("OrtRun") || msg.includes("out of data bounds") || msg.includes("Gather"))) {
    log("Abschnitt übersprungen, versuche nächsten …");
    index++;
    progress.value = chunks.length ? (index / chunks.length) * 100 : 0;
    if (index < chunks.length) {
      setStatus("Ein Abschnitt war problematisch – lese weiter …");
      playPiper(run).catch(fail);
      return;
    }
  }
  done("Fehler: " + msg);
}

/* ---------- Controls ---------- */

async function start() {
  const text = $("#text").value.trim();
  if (!text) {
    setStatus("Bitte ein Buch öffnen oder Text einfügen, mein Schatz.");
    return;
  }
  run++;
  cleanup();
  const chunkSize = isPiper() ? 1600 : 2500;
  chunks = split(text, chunkSize);
  index = 0;
  progress.value = 0;
  paused = false;
  setState("playing");
  log("Start: " + chunks.length + " Abschnitte, Stimme=" + $("#voice").value);
  try {
    if (isPiper()) await playPiper(run);
    else deviceSpeak(run);
  } catch (e) {
    fail(e);
  }
}

function stop() {
  run++;
  speechSynthesis.cancel();
  done("Angehalten.");
  progress.value = 0;
}

function pause() {
  if (isPiper()) {
    if (audio.paused) {
      applyRate();
      audio.play();
      paused = false;
      setStatus("Weiter geht’s …");
    } else {
      audio.pause();
      paused = true;
      setStatus("Pausiert.");
    }
  } else {
    if (speechSynthesis.paused) {
      speechSynthesis.resume();
      paused = false;
      setStatus("Weiter geht’s …");
    } else {
      speechSynthesis.pause();
      paused = true;
      setStatus("Pausiert.");
    }
  }
  setState("playing");
}

function saveBookmark() {
  const text = $("#text").value;
  if (!text) return;
  const data = {
    text,
    index,
    voice: $("#voice").value,
    rate: $("#rate").value,
    savedAt: Date.now(),
  };
  localStorage.setItem(BOOKMARK_KEY, JSON.stringify(data));
  setStatus("Lesezeichen gesetzt bei Abschnitt " + (index + 1) + ".");
}

function loadBookmark() {
  const raw = localStorage.getItem(BOOKMARK_KEY);
  if (!raw) {
    setStatus("Kein Lesezeichen gespeichert.");
    return;
  }
  try {
    const data = JSON.parse(raw);
    $("#text").value = data.text || "";
    if (data.voice) $("#voice").value = data.voice;
    if (data.rate) {
      $("#rate").value = data.rate;
      $("#rateOut").value = (+data.rate).toFixed(1).replace(".", ",") + "×";
    }
    chunks = split(data.text || "");
    index = Math.min(data.index || 0, Math.max(0, chunks.length - 1));
    progress.value = chunks.length ? (index / chunks.length) * 100 : 0;
    setStatus("Lesezeichen geladen – Abschnitt " + (index + 1) + "/" + chunks.length + ". Drücke Start zum Weiterlesen.");
  } catch (e) {
    setStatus("Lesezeichen konnte nicht geladen werden.");
  }
}

function startFromCaret() {
  const ta = $("#text");
  const full = ta.value || "";
  if (!full.trim()) {
    setStatus("Kein Text vorhanden.");
    return;
  }
  let pos = typeof ta.selectionStart === "number" ? ta.selectionStart : 0;
  if (ta.selectionEnd > ta.selectionStart) pos = ta.selectionStart;

  let startPos = pos;
  while (startPos > 0 && !/[.!?\n]/.test(full[startPos - 1])) startPos--;
  while (startPos < full.length && /\s/.test(full[startPos])) startPos++;

  const fromHere = full.slice(startPos).trim();
  if (!fromHere) {
    setStatus("Keine Textstelle ab hier.");
    return;
  }

  run++;
  cleanup();
  const before = full.slice(0, startPos);
  const chunkSize = isPiper() ? 1600 : 2500;
  const beforeChunks = split(before, chunkSize);
  chunks = split(full, chunkSize);
  index = Math.min(beforeChunks.length, Math.max(0, chunks.length - 1));
  progress.value = chunks.length ? (index / chunks.length) * 100 : 0;
  paused = false;
  setState("playing");
  setStatus("Weiter ab gewählter Stelle (Abschnitt " + (index + 1) + ") …");
  (async () => {
    try {
      if (isPiper()) await playPiper(run);
      else deviceSpeak(run);
    } catch (e) {
      fail(e);
    }
  })();
}

/* ---------- Warm-up: load recommended voice in background ---------- */

async function warmUp() {
  try {
    setStatus("Stimme wird im Hintergrund vorbereitet …");
    piperReady = getPiper();
    const piper = await piperReady;
    // Trigger a tiny synthesis so the model actually downloads & caches
    const voiceId = currentVoiceId() || "de_DE-kerstin-low";
    await piper.predict(
      { text: "Hallo.", voiceId, speakerId: currentSpeakerId() },
      (p) => {
        if (p?.total) {
          const pct = Math.round((p.loaded * 100) / p.total);
          setStatus(`Stimme lädt: ${pct} % – gleich bereit, mein Schatz.`);
        }
      }
    );
    setStatus("Bereit, mein Schatz. Buch öffnen oder Text einfügen – dann ▶ Vorlesen.");
    log("Warm-up complete for " + voiceId);
  } catch (e) {
    log("Warm-up failed: " + e.message);
    setStatus("Bereit. Beim ersten Vorlesen wird die Stimme geladen.");
  }
}

/* ---------- Wire up ---------- */

$("#start").onclick = start;
$("#stop").onclick = stop;
$("#pause").onclick = pause;
$("#diagnose").onclick = saveBookmark;
$("#loadmark").onclick = loadBookmark;
$("#text").ondblclick = startFromCaret;
$("#fromHere") && ($("#fromHere").onclick = startFromCaret);

$("#rate").oninput = (e) => {
  $("#rateOut").value = (+e.target.value).toFixed(1).replace(".", ",") + "×";
  if (isPiper() && !audio.paused) applyRate();
};
$("#volume") && ($("#volume").oninput = (e) => {
  const v = +e.target.value;
  $("#volOut").value = Math.round(v * 100) + " %";
  audio.volume = v;
});

$("#file").onchange = async (e) => {
  const f = e.target.files?.[0];
  if (!f) return;
  try {
    setStatus(`Lade „${f.name}“ …`);
    const text = await readFile(f);
    $("#text").value = text;
    setStatus(`„${f.name}“ geladen (${text.length.toLocaleString("de-DE")} Zeichen). Bereit zum Vorlesen.`);
  } catch (err) {
    console.error(err);
    setStatus("Datei konnte nicht gelesen werden: " + (err?.message || err));
  }
};

if (localStorage.getItem(BOOKMARK_KEY)) {
  setStatus("Lesezeichen vorhanden – tippe auf ↩ Weiterlesen.");
}

setState("idle");
updateEmotionVisibility();
$("#voice").addEventListener("change", updateEmotionVisibility);

// Start warm-up as soon as possible
warmUp();

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () =>
    navigator.serviceWorker.register("./sw.js").catch((err) => console.warn("SW:", err))
  );
}
