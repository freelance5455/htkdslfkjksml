// 1) Firebase Console > Create project > Add Web App > copy config here.
const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};

const $ = id => document.getElementById(id);
const show = (id, yes=true) => $(id).classList.toggle("hidden", !yes);
const status = msg => $("status").textContent = msg;
let auth, db, currentUser=null, roomId=null, stopWishes=null, stopNotes=null;

try {
  if (firebaseConfig.apiKey === "PASTE_API_KEY") {
    status("Setup needed: add your Firebase config in app.js, then publish the app.");
  } else {
    firebase.initializeApp(firebaseConfig);
    auth = firebase.auth();
    db = firebase.firestore();
    $("signup").addEventListener("click", signUp);
    $("login").addEventListener("click", signIn);
    auth.onAuthStateChanged(onAuth);
  }
} catch(e) { status("Firebase setup error: " + e.message); }

async function signUp(){
  try { await auth.createUserWithEmailAndPassword($("email").value.trim(), $("password").value); }
  catch(e){ status(friendly(e)); }
}
async function signIn(){
  try { await auth.signInWithEmailAndPassword($("email").value.trim(), $("password").value); }
  catch(e){ status(friendly(e)); }
}
function friendly(e){
  const map={"auth/invalid-email":"Please enter a valid email.","auth/weak-password":"Use a password with at least 6 characters.","auth/email-already-in-use":"This email already has an account.","auth/user-not-found":"Account not found. Create an account first.","auth/wrong-password":"Incorrect password.","auth/invalid-credential":"Email or password is incorrect."};
  return map[e.code] || e.message;
}
async function onAuth(user){
  currentUser=user;
  show("auth",!user); show("main",!!user);
  if(!user){cleanup();return;}
  $("userEmail").textContent=user.email || "";
  $("welcome").textContent="Hello ❤️";
  $("logout").onclick=()=>auth.signOut();
  await findRoom();
}
function cleanup(){
  if(stopWishes)stopWishes(); if(stopNotes)stopNotes();
  stopWishes=stopNotes=null; roomId=null;
  show("workspace",false);show("roomInfo",false);show("roomSetup",false);
}
async function findRoom(){
  cleanup();
  const snap=await db.collection("rooms").where("members","array-contains",currentUser.uid).limit(1).get();
  if(snap.empty){show("roomSetup",true);return;}
  roomId=snap.docs[0].id;
  $("roomCodeLabel").textContent="Your couple space is connected.";
  show("roomInfo",true);show("workspace",true);listenContent();
}
function randomCode(){return String(Math.floor(100000+Math.random()*900000));}
$("createRoom").onclick=async()=>{
  $("roomMsg").textContent="Creating...";
  try{
    const code=randomCode();
    const ref=await db.collection("rooms").add({members:[currentUser.uid],code,createdAt:firebase.firestore.FieldValue.serverTimestamp()});
    roomId=ref.id;
    $("roomMsg").textContent="Your couple code is "+code+". Send it privately to your partner.";
    show("roomInfo",true);show("workspace",true);listenContent();
  }catch(e){$("roomMsg").textContent=friendly(e);}
};
$("joinRoom").onclick=async()=>{
  const code=$("joinCode").value.trim();
  if(!/^\d{6}$/.test(code)){ $("roomMsg").textContent="Enter the 6-digit code.";return; }
  $("roomMsg").textContent="Checking code...";
  try{
    const snap=await db.collection("rooms").where("code","==",code).limit(1).get();
    if(snap.empty){$("roomMsg").textContent="Code not found. Check with your partner.";return;}
    const doc=snap.docs[0], members=doc.data().members||[];
    if(members.length>=2 && !members.includes(currentUser.uid)){ $("roomMsg").textContent="This couple space already has two members.";return; }
    if(!members.includes(currentUser.uid)) await doc.ref.update({members:firebase.firestore.FieldValue.arrayUnion(currentUser.uid)});
    await findRoom();
  }catch(e){$("roomMsg").textContent=friendly(e);}
};
function listenContent(){
  if(stopWishes)stopWishes(); if(stopNotes)stopNotes();
  stopWishes=db.collection("rooms").doc(roomId).collection("wishes").orderBy("createdAt","desc").onSnapshot(s=>renderItems("wishes",s,"wish"),e=>console.error(e));
  stopNotes=db.collection("rooms").doc(roomId).collection("notes").orderBy("createdAt","desc").onSnapshot(s=>renderItems("notes",s,"note"),e=>console.error(e));
}
function dateText(ts){return ts&&ts.toDate?ts.toDate().toLocaleString():"Just now";}
function safe(text){const d=document.createElement("div");d.textContent=text||"";return d.innerHTML;}
function renderItems(target,snap,type){
  const box=$(target); box.innerHTML="";
  if(snap.empty){box.innerHTML='<p class="muted">Nothing here yet. You can write the first one. 💗</p>';return;}
  snap.forEach(doc=>{
    const x=doc.data(), id=doc.id, el=document.createElement("article");
    el.className="item";
    const title=type==="wish"?(x.category||"Wish"):"Personal note";
    el.innerHTML=`<div class="itemtop"><strong>${safe(title)}</strong><span class="badge">${type==="wish"?safe(x.state||"Open"):"Note"}</span></div>
      <p>${safe(x.text)}</p><div class="muted">${safe(x.senderLabel||"Partner")} · ${dateText(x.createdAt)}</div>
      ${x.reply?`<div class="reply"><strong>Reply:</strong><br>${safe(x.reply)}</div>`:""}
      ${type==="wish" && x.state!=="Completed" ? '<button class="secondary complete" style="margin-top:9px">Mark completed</button>':""}
      <div class="row" style="margin-top:9px"><input class="replyInput" maxlength="500" placeholder="Write a reply..."><button class="replyBtn">Reply</button></div>`;
    const complete=el.querySelector(".complete");
    if(complete) complete.onclick=()=>db.collection("rooms").doc(roomId).collection("wishes").doc(id).update({state:"Completed"});
    el.querySelector(".replyBtn").onclick=async()=>{
      const val=el.querySelector(".replyInput").value.trim(); if(!val)return;
      await db.collection("rooms").doc(roomId).collection(type==="wish"?"wishes":"notes").doc(id).update({reply:val,replyBy:currentUser.uid});
    };
    box.appendChild(el);
  });
}
async function send(type){
  const input=$(type==="wish"?"wishText":"noteText"), text=input.value.trim();
  if(!text){alert("Please write something first.");return;}
  try{
    const data={text,senderId:currentUser.uid,senderLabel:currentUser.email||"Partner",createdAt:firebase.firestore.FieldValue.serverTimestamp()};
    if(type==="wish"){data.category=$("wishType").value;data.state="Open";}
    await db.collection("rooms").doc(roomId).collection(type==="wish"?"wishes":"notes").add(data);
    input.value="";
  }catch(e){alert(friendly(e));}
}
$("sendWish").onclick=()=>send("wish");
$("sendNote").onclick=()=>send("note");
document.querySelectorAll("[data-tab]").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll("[data-tab]").forEach(b=>b.classList.toggle("active",b===btn));
  document.querySelectorAll("[data-tab]").forEach(b=>b.classList.toggle("secondary",b!==btn));
  show(btn.dataset.tab,true);show(btn.dataset.tab==="wishPanel"?"notePanel":"wishPanel",false);
});
