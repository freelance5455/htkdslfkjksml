'use strict';
const LOGIN = 'unkown', PASS = 'm2010s';
const $ = s => document.querySelector(s);
const load = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
const store = (k, v) => localStorage.setItem(k, JSON.stringify(v));
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const pad = n => String(n).padStart(2, '0');
const todayStr = () => { const d = new Date(); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
const nowTime = () => { const d = new Date(); return pad(d.getHours()) + ':' + pad(d.getMinutes()); };

let students = load('students', []);          // [{id,name}]
let records = load('records', {});            // records[date][id] = {status,time,skipped,paras[]}
let editingId = null;

const sortStudents = () => students.sort((a, b) => a.name.localeCompare(b.name, 'uz', { sensitivity: 'base' }));
const saveAll = () => { sortStudents(); store('students', students); store('records', records); };

/* ---------- Modal ---------- */
function ask(text, cb) {
  $('#mText').textContent = text;
  $('#modal').classList.remove('hidden');
  $('#mNo').onclick = () => $('#modal').classList.add('hidden');
  $('#mYes').onclick = () => { $('#modal').classList.add('hidden'); cb(); };
}

/* ---------- Login ---------- */
function showApp() {
  $('#loginView').classList.add('hidden');
  $('#appView').classList.remove('hidden');
  $('#date').value = todayStr(); $('#time').value = nowTime();
  const d = new Date(); $('#from').value = d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-01'; $('#to').value = todayStr();
  renderAll();
}
$('#lgBtn').onclick = () => {
  if ($('#lg').value.trim() === LOGIN && $('#ps').value === PASS) {
    localStorage.setItem('auth', '1'); $('#lgErr').textContent = ''; showApp();
  } else $('#lgErr').textContent = "Login yoki parol noto'g'ri!";
};
$('#ps').addEventListener('keydown', e => { if (e.key === 'Enter') $('#lgBtn').click(); });
$('#logout').onclick = () => { localStorage.removeItem('auth'); $('#appView').classList.add('hidden'); $('#loginView').classList.remove('hidden'); $('#ps').value = ''; };

/* ---------- Tabs ---------- */
document.querySelectorAll('.tab').forEach(b => b.onclick = () => {
  document.querySelectorAll('.tab').forEach(x => x.classList.toggle('active', x === b));
  document.querySelectorAll('.pane').forEach(p => p.classList.toggle('hidden', p.id !== b.dataset.tab));
  renderAll();
});

/* ---------- O'quvchilar ---------- */
$('#stAdd').onclick = () => {
  const name = $('#stName').value.trim(); if (!name) return;
  students.push({ id: Date.now() + '' + Math.floor(Math.random() * 1000), name });
  $('#stName').value = ''; saveAll(); renderAll();
};
$('#stName').addEventListener('keydown', e => { if (e.key === 'Enter') $('#stAdd').click(); });

function renderStudents() {
  $('#stCount').textContent = "Jami: " + students.length + " ta o'quvchi";
  $('#stList').innerHTML = students.map((s, i) => editingId === s.id
    ? `<div class="item"><div class="row" style="margin:0"><input class="grow" id="edIn" value="${esc(s.name)}"><button class="btn primary small" data-a="sv" data-id="${s.id}">Saqlash</button><button class="btn small" data-a="cn">✕</button></div></div>`
    : `<div class="item"><div class="top"><span class="name"><span class="num">${i + 1}.</span>${esc(s.name)}</span><span><button class="btn small" data-a="ed" data-id="${s.id}">✏️</button> <button class="btn small" data-a="dl" data-id="${s.id}">🗑</button></span></div></div>`
  ).join('') || '<p class="muted">Hozircha o\'quvchi yo\'q.</p>';
}
$('#stList').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  const id = b.dataset.id, a = b.dataset.a;
  if (a === 'ed') { editingId = id; renderStudents(); const i = $('#edIn'); if (i) i.focus(); }
  else if (a === 'cn') { editingId = null; renderStudents(); }
  else if (a === 'sv') {
    const v = $('#edIn').value.trim(); if (!v) return;
    students.find(s => s.id === id).name = v; editingId = null; saveAll(); renderAll();
  } else if (a === 'dl') {
    const s = students.find(x => x.id === id);
    ask(`"${s.name}" o'chirilsinmi? Uning davomat yozuvlari ham o'chadi.`, () => {
      students = students.filter(x => x.id !== id);
      Object.keys(records).forEach(d => { delete records[d][id]; });
      saveAll(); renderAll();
    });
  }
};

/* ---------- Davomat ---------- */
const getRec = (date, id) => (records[date] && records[date][id]) || null;
function setRec(date, id, patch) {
  records[date] = records[date] || {};
  const r = records[date][id] || { status: '', time: '', skipped: false, paras: [] };
  Object.assign(r, patch);
  records[date][id] = r; store('records', records);
}
function renderAttendance() {
  const date = $('#date').value || todayStr();
  let k = 0, n = 0, l = 0, q = 0;
  students.forEach(s => { const r = getRec(date, s.id); if (!r) return; if (r.status === 'keldi') k++; if (r.status === 'kelmadi') n++; if (r.status === 'kechikdi') l++; if (r.skipped) q++; });
  $('#attSum').innerHTML = `<span class="pill g">Keldi: ${k}</span><span class="pill r">Kelmadi: ${n}</span><span class="pill y">Kechikdi: ${l}</span><span class="pill o">Qochdi: ${q}</span>`;
  $('#attList').innerHTML = students.map((s, i) => {
    const r = getRec(date, s.id) || { status: '', skipped: false, paras: [], time: '' };
    const paras = r.skipped ? `<div class="paras">${[1,2,3,4,5,6,7,8].map(p => `<button class="${r.paras.includes(p) ? 'on' : ''}" data-a="pa" data-p="${p}" data-id="${s.id}">${p}</button>`).join('')}</div>` : '';
    return `<div class="item">
      <div class="top"><span class="name"><span class="num">${i + 1}.</span>${esc(s.name)}</span><span class="time">${r.time ? '🕐 ' + r.time : ''}</span></div>
      <div class="st">
        <button class="k ${r.status === 'keldi' ? 'on' : ''}" data-a="st" data-v="keldi" data-id="${s.id}">Keldi</button>
        <button class="n ${r.status === 'kelmadi' ? 'on' : ''}" data-a="st" data-v="kelmadi" data-id="${s.id}">Kelmadi</button>
        <button class="l ${r.status === 'kechikdi' ? 'on' : ''}" data-a="st" data-v="kechikdi" data-id="${s.id}">Kechikdi</button>
      </div>
      <div class="skip"><button class="${r.skipped ? 'on' : ''}" data-a="sk" data-id="${s.id}">🏃 Darsdan qochdi${r.skipped && r.paras.length ? ' (' + r.paras.slice().sort((a, b) => a - b).join(', ') + '-para)' : ''}</button>${paras}</div>
    </div>`;
  }).join('') || '<p class="muted">Avval "O\'quvchilar" bo\'limida o\'quvchi qo\'shing.</p>';
}
$('#attList').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  const date = $('#date').value || todayStr(), id = b.dataset.id, a = b.dataset.a;
  const r = getRec(date, id) || { status: '', skipped: false, paras: [] };
  if (a === 'st') {
    if (r.status === b.dataset.v) setRec(date, id, { status: '', time: '' });
    else setRec(date, id, { status: b.dataset.v, time: $('#time').value || nowTime() });
  } else if (a === 'sk') {
    setRec(date, id, { skipped: !r.skipped, paras: r.skipped ? [] : r.paras, time: r.time || $('#time').value || nowTime() });
  } else if (a === 'pa') {
    const p = +b.dataset.p, ps = r.paras.slice();
    const ix = ps.indexOf(p); if (ix >= 0) ps.splice(ix, 1); else ps.push(p);
    setRec(date, id, { paras: ps });
  }
  renderAttendance();
};
$('#date').onchange = renderAttendance;

/* ---------- Hisobot ---------- */
function buildReport() {
  const from = $('#from').value || '0000-00-00', to = $('#to').value || '9999-99-99';
  const dates = Object.keys(records).filter(d => d >= from && d <= to).sort();
  const rows = students.map((s, i) => {
    let k = 0, n = 0, l = 0, q = 0; const det = [];
    dates.forEach(d => {
      const r = records[d][s.id]; if (!r) return;
      if (r.status === 'keldi') k++; else if (r.status === 'kelmadi') n++; else if (r.status === 'kechikdi') l++;
      if (r.skipped) { q++; const ps = r.paras.slice().sort((a, b) => a - b); det.push(d.slice(8) + '.' + d.slice(5, 7) + (ps.length ? ':' + ps.join(',') : '')); }
    });
    return [i + 1, s.name, k, n, l, q, det.join('; ')];
  });
  const tot = ['', 'JAMI', 0, 0, 0, 0, ''];
  rows.forEach(r => { for (let j = 2; j <= 5; j++) tot[j] += r[j]; });
  return { header: ['№', "F.I.Sh.", 'Keldi', 'Kelmadi', 'Kechikdi', 'Qochgan', 'Qochgan sana:para'], rows, tot, from: $('#from').value, to: $('#to').value, days: dates.length };
}
function renderReport() {
  const R = buildReport();
  $('#repSum').innerHTML = `<span class="pill">Davr: ${R.from || '—'} → ${R.to || '—'}</span><span class="pill">Dars kunlari: ${R.days}</span><span class="pill g">Keldi: ${R.tot[2]}</span><span class="pill r">Kelmadi: ${R.tot[3]}</span><span class="pill y">Kechikdi: ${R.tot[4]}</span><span class="pill o">Qochgan: ${R.tot[5]}</span>`;
  $('#repTbl').innerHTML = '<thead><tr>' + R.header.map(h => `<th>${esc(h)}</th>`).join('') + '</tr></thead><tbody>' +
    R.rows.map(r => '<tr>' + r.map(c => `<td>${esc(c)}</td>`).join('') + '</tr>').join('') +
    '<tr class="tot">' + R.tot.map(c => `<td>${esc(c)}</td>`).join('') + '</tr></tbody>';
}
$('#from').onchange = $('#to').onchange = renderReport;

/* ---------- Eksport ---------- */
function download(blob, name) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name;
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
}
$('#exXls').onclick = () => {
  const R = buildReport();
  const cell = (v, bold) => `<Cell${bold ? ' ss:StyleID="b"' : ''}><Data ss:Type="${typeof v === 'number' ? 'Number' : 'String'}">${esc(v)}</Data></Cell>`;
  const row = (arr, bold) => '<Row>' + arr.map(v => cell(v, bold)).join('') + '</Row>';
  const xml = '<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>' +
    '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' +
    '<Styles><Style ss:ID="b"><Font ss:Bold="1"/></Style></Styles><Worksheet ss:Name="Hisobot"><Table>' +
    row(["O'quvchilar davomati hisoboti"], true) + row(['Davr: ' + R.from + ' - ' + R.to]) + row([]) +
    row(R.header, true) + R.rows.map(r => row(r)).join('') + row(R.tot, true) +
    '</Table></Worksheet></Workbook>';
  download(new Blob([xml], { type: 'application/vnd.ms-excel' }), 'hisobot_' + todayStr() + '.xls');
};

/* Oddiy PDF generator (kutubxonasiz, offline) */
function latin(s) {
  return String(s).replace(/[ʻʼ‘’`´]/g, "'").replace(/[“”]/g, '"').replace(/№/g, 'No').replace(/→/g, '-')
    .replace(/[^\x00-\xFF]/g, '?').replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)');
}
function makePDF(title, sub, header, rows, tot, widths) {
  const W = 842, H = 595, M = 30, LH = 16;
  const pages = []; let cur, y;
  const xs = []; widths.reduce((a, w, i) => (xs[i] = a, a + w), M);
  const newPage = () => { cur = []; pages.push(cur); y = H - M; };
  const line = (arr, bold) => {
    arr.forEach((v, i) => {
      let t = latin(v); const max = Math.floor(widths[i] / 4.4);
      if (t.length > max) t = t.slice(0, max - 2) + '..';
      cur.push(`BT /${bold ? 'F2' : 'F1'} 9 Tf ${xs[i]} ${y} Td (${t}) Tj ET`);
    });
    y -= LH;
  };
  const rule = () => cur.push(`${M} ${y + LH - 4} m ${W - M} ${y + LH - 4} l S`);
  newPage();
  cur.push(`BT /F2 15 Tf ${M} ${y} Td (${latin(title)}) Tj ET`); y -= 20;
  cur.push(`BT /F1 10 Tf ${M} ${y} Td (${latin(sub)}) Tj ET`); y -= 24;
  line(header, true); rule();
  rows.concat([tot]).forEach((r, idx) => {
    if (y < M + LH) { newPage(); line(header, true); rule(); }
    line(r, idx === rows.length);
  });
  let out = '%PDF-1.4\n'; const off = [];
  const add = (n, s) => { off[n] = out.length; out += n + ' 0 obj\n' + s + '\nendobj\n'; };
  add(1, '<< /Type /Catalog /Pages 2 0 R >>');
  add(2, `<< /Type /Pages /Kids [${pages.map((_, i) => (5 + i * 2) + ' 0 R').join(' ')}] /Count ${pages.length} >>`);
  add(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
  add(4, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  pages.forEach((ops, i) => {
    const c = ops.join('\n');
    add(5 + i * 2, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${6 + i * 2} 0 R >>`);
    add(6 + i * 2, `<< /Length ${c.length} >>\nstream\n${c}\nendstream`);
  });
  const n = 5 + pages.length * 2, xr = out.length;
  out += `xref\n0 ${n}\n0000000000 65535 f \n`;
  for (let i = 1; i < n; i++) out += String(off[i]).padStart(10, '0') + ' 00000 n \n';
  out += `trailer\n<< /Size ${n} /Root 1 0 R >>\nstartxref\n${xr}\n%%EOF`;
  const u = new Uint8Array(out.length);
  for (let i = 0; i < out.length; i++) u[i] = out.charCodeAt(i) & 255;
  return new Blob([u], { type: 'application/pdf' });
}
$('#exPdf').onclick = () => {
  const R = buildReport();
  const blob = makePDF("O'quvchilar davomati hisoboti", 'Davr: ' + R.from + ' - ' + R.to + '   |   Dars kunlari: ' + R.days,
    R.header, R.rows, R.tot, [30, 210, 50, 60, 65, 60, 277]);
  download(blob, 'hisobot_' + todayStr() + '.pdf');
};

/* ---------- Umumiy ---------- */
function renderAll() { renderStudents(); renderAttendance(); renderReport(); }
setInterval(() => { const t = $('#time'); if (t && document.activeElement !== t && !$('#appView').classList.contains('hidden')) t.value = nowTime(); }, 30000);
if (localStorage.getItem('auth') === '1') showApp();
