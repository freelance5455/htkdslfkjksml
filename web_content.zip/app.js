(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const editor = $("editor"), output = $("output"), tree = $("fileTree");
  const DB_NAME = "acce-studio-3", STORE = "files";
  let db, activePath = "welcome.acce", dirty = false, files = {};

  const starter = [
    "# أول برنامج بلغة ACCE",
    "خزن\\الاسم\\مؤسس ACCE",
    "خزن\\العمر\\20",
    "اطبع\\مرحبا بك يا",
    "اطبع\\الاسم",
    "اطبع\\اختبار العمليات الحسابية:",
    "اجمع\\50\\20",
    "",
    "# جرّب التكرار",
    "كرر\\3",
    "اطبع\\ACCE تعمل!",
    "نهاية"
  ].join("\n");

  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  function tx(mode = "readonly") { return db.transaction(STORE, mode).objectStore(STORE); }
  function getAll() {
    return new Promise((resolve, reject) => {
      const r = tx().getAllKeys(), v = tx().getAll();
      let keys, vals;
      r.onsuccess = () => { keys = r.result; if (vals) resolve(Object.fromEntries(keys.map((k,i)=>[k,vals[i]]))); };
      v.onsuccess = () => { vals = v.result; if (keys) resolve(Object.fromEntries(keys.map((k,i)=>[k,vals[i]]))); };
      r.onerror = v.onerror = () => reject(r.error || v.error);
    });
  }
  function put(key, value) {
    return new Promise((resolve, reject) => {
      const r = tx("readwrite").put(value, key);
      r.onsuccess = resolve; r.onerror = () => reject(r.error);
    });
  }
  function remove(key) {
    return new Promise((resolve, reject) => {
      const r = tx("readwrite").delete(key);
      r.onsuccess = resolve; r.onerror = () => reject(r.error);
    });
  }
  function setDirty(value) { dirty = value; $("saveState").textContent = value ? "تعديلات غير محفوظة" : "تم الحفظ"; $("saveState").style.color = value ? "#ffc56b" : "#65d6a4"; }
  function updateLines() {
    const count = editor.value.split("\n").length;
    $("lineNumbers").textContent = Array.from({length:count}, (_,i)=>i+1).join("\n");
  }
  function extIcon(path) { return path.endsWith(".acce") ? "🟣" : path.endsWith(".js") ? "🟨" : path.endsWith(".html") ? "🟧" : "📄"; }
  function renderTree() {
    tree.innerHTML = "";
    const keys = Object.keys(files).sort((a,b)=>a.localeCompare(b));
    if (!keys.length) { tree.textContent = "لا توجد ملفات"; return; }
    keys.forEach(key => {
      const b = document.createElement("button");
      b.className = "tree-item" + (key === activePath ? " active" : "");
      const icon = document.createElement("span"); icon.className = "file-icon"; icon.textContent = extIcon(key);
      const label = document.createElement("span"); label.textContent = key;
      b.append(icon,label); b.onclick = () => openFile(key);
      tree.appendChild(b);
    });
  }
  async function openFile(path) {
    if (dirty && !confirm("هناك تعديلات غير محفوظة. هل تريد فتح ملف آخر؟")) return;
    activePath = path; editor.value = files[path] || ""; $("activeTab").textContent = path;
    setDirty(false); updateLines(); renderTree();
  }
  async function save() {
    files[activePath] = editor.value;
    await put(activePath, editor.value);
    setDirty(false); renderTree(); output.textContent = "✓ تم حفظ " + activePath;
  }
  async function createFile() {
    const name = prompt("اسم الملف (مثال: program.acce):", "new.acce");
    if (!name) return;
    const clean = name.trim().replace(/^\/+/, "");
    if (!clean || clean.includes("..") || clean.endsWith("/")) return alert("اسم الملف غير صالح");
    if (Object.prototype.hasOwnProperty.call(files, clean)) return alert("الملف موجود بالفعل");
    files[clean] = ""; await put(clean, ""); await openFile(clean);
  }
  async function createFolder() {
    const name = prompt("اسم المجلد:");
    if (!name) return;
    const folder = name.trim().replace(/^\/+|\/+$/g, "");
    if (!folder || folder.includes("..")) return alert("اسم المجلد غير صالح");
    // Browser edition stores files as flat virtual paths; a folder is represented by a placeholder.
    const key = folder + "/.folder";
    files[key] = ""; await put(key, ""); renderTree();
  }
  async function run() {
    if (dirty) await save();
    $("runStatus").textContent = "جاري التنفيذ…";
    const engine = new ACCEEngine({maxSteps:20000});
    const result = engine.execute(editor.value);
    output.textContent = result || "(انتهى البرنامج بدون إخراج)";
    $("runStatus").textContent = "اكتمل التنفيذ";
  }
  async function exportProject() {
    const payload = {name:"ACCE STUDIO 3.0", version:"3.0", files};
    const blob = new Blob([JSON.stringify(payload,null,2)], {type:"application/json"});
    download(blob, "ACCE_STUDIO_PROJECT.json");
  }
  function download(blob, name) {
    const url = URL.createObjectURL(blob), a = document.createElement("a");
    a.href=url; a.download=name; a.click(); URL.revokeObjectURL(url);
  }
  async function importProject(file) {
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const incoming = data.files || data;
      if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) throw new Error("صيغة المشروع غير صحيحة");
      for (const [key,value] of Object.entries(incoming)) {
        if (typeof value !== "string" || key.includes("..")) continue;
        files[key] = value; await put(key,value);
      }
      renderTree(); output.textContent = "✓ تم استيراد المشروع بنجاح";
    } catch(e) { alert("تعذر استيراد المشروع: " + e.message); }
  }

  editor.addEventListener("input", () => { setDirty(true); updateLines(); });
  editor.addEventListener("scroll", () => { $("lineNumbers").scrollTop = editor.scrollTop; });
  $("saveBtn").onclick = save;
  $("runBtn").onclick = run;
  $("newFileBtn").onclick = createFile;
  $("newFolderBtn").onclick = createFolder;
  $("refreshBtn").onclick = renderTree;
  $("clearOutputBtn").onclick = () => { output.textContent = ""; $("runStatus").textContent = "جاهز"; };
  $("exportBtn").onclick = exportProject;
  $("importBtn").onclick = () => $("importInput").click();
  $("importInput").onchange = e => { if(e.target.files[0]) importProject(e.target.files[0]); e.target.value=""; };
  window.addEventListener("beforeunload", e => { if(dirty){e.preventDefault();e.returnValue="";} });

  (async () => {
    try {
      db = await openDB();
      files = await getAll();
      if (!Object.keys(files).length) { files["welcome.acce"] = starter; await put("welcome.acce", starter); }
      renderTree(); await openFile(files["welcome.acce"] !== undefined ? "welcome.acce" : Object.keys(files)[0]);
      output.textContent = "تم تجهيز بيئة ACCE. اضغط تشغيل لتجربة المثال.";
    } catch(e) {
      output.textContent = "تعذر تشغيل التخزين المحلي: " + e.message;
    }
  })();
})();