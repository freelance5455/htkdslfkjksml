(function () {
  "use strict";
  const KEY = "inv_state_v1";
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = (v) => (v < 0 ? "-$" : "$") + Math.abs(v).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const qf = (v) => String(Math.round(v * 1e6) / 1e6);
  const today = () => new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);

  // ---------- state ----------
  let state;
  try { state = JSON.parse(localStorage.getItem(KEY)) || Core.newState(); } catch (e) { state = Core.newState(); }
  Core.ensureState(state);
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); }
    catch (e) { toast("Could not save - storage is full. Export a backup."); }
  }
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist();

  // ---------- helpers ----------
  let toastT;
  function toast(msg) {
    const t = $("toast"); t.textContent = msg; t.classList.add("on");
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("on"), 2600);
  }
  function seg(id, onChange) {
    const el = $(id);
    el.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      el.querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
      onChange && onChange(b.dataset.v);
    });
  }
  const segVal = (id) => $(id).querySelector("button.on").dataset.v;
  const segSet = (id, v) => $(id).querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
  function download(name, text, type) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(text instanceof Blob ? text : new Blob([text], { type: type || "text/plain" }));
    a.download = name; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
  }

  // ---------- camera scanning ----------
  function scanCamera() {
    return new Promise(async (resolve) => {
      if (!navigator.mediaDevices || !("BarcodeDetector" in window)) {
        toast("Camera scanning isn't supported in this browser. Type the code or use a scanner.");
        return resolve(null);
      }
      let stream, timer, done = false;
      const cam = $("cam"), video = $("camVideo");
      const finish = (val) => {
        if (done) return; done = true;
        clearInterval(timer);
        if (stream) stream.getTracks().forEach((t) => t.stop());
        video.srcObject = null; cam.classList.remove("on"); resolve(val);
      };
      $("camCancel").onclick = () => finish(null);
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" } }, audio: false });
        video.srcObject = stream; await video.play(); cam.classList.add("on");
        const det = new BarcodeDetector({ formats: ["ean_13", "ean_8", "upc_a", "upc_e", "code_128", "code_39"] });
        timer = setInterval(async () => {
          try {
            const r = await det.detect(video);
            if (r.length) { if (navigator.vibrate) navigator.vibrate(60); finish(r[0].rawValue); }
          } catch (e) { /* keep trying */ }
        }, 200);
      } catch (e) {
        toast("Couldn't open the camera. Allow camera permission and try again.");
        finish(null);
      }
    });
  }

  // ---------- tabs ----------
  let curTab = "scan";
  function showTab(t) {
    curTab = t;
    document.querySelectorAll(".tab").forEach((s) => s.classList.toggle("on", s.id === "t-" + t));
    $("nav").querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.t === t));
    $("fab").style.display = t === "items" ? "block" : "none";
    renderAll();
  }
  $("nav").addEventListener("click", (e) => { const b = e.target.closest("button"); if (b) showTab(b.dataset.t); });

  // ---------- SCAN tab ----------
  seg("sPay", () => renderScan(true));
  function renderScan(showMissing) {
    const out = $("sResult"), code = $("sBarcode").value.trim();
    if (!code) { out.innerHTML = '<div class="card sub">Scan an item to see its cost, discounts, commission and profit.</div>'; return; }
    const item = Core.findItem(state, code);
    if (!item) {
      out.innerHTML = showMissing ? '<div class="card"><div class="msg bad">Barcode not found - add it on the Items tab.</div></div>' : "";
      return;
    }
    const qty = Number($("sQty").value), pay = segVal("sPay");
    const row = Core.stockRows(state, "").find((r) => r.barcode === item.barcode);
    let h = '<div class="card"><div class="msg ok">Item found</div><div class="itemname">' + esc(item.name) + "</div>" +
      '<div class="sub">' + esc(item.sku) + (item.category ? " · " + esc(item.category) : "") + "</div>" +
      '<div style="margin-top:8px">On hand: <b>' + qf(row.on_hand) + '</b> <span class="chip ' + (row.status === "Out of Stock" ? "Out" : row.status) + '">' + row.status + "</span></div>";
    if (!(qty > 0)) { out.innerHTML = h + '<div class="msg bad" style="margin-top:10px">Enter a valid quantity.</div></div>'; return; }
    const r = Core.calcSale(item, qty, pay);
    const rows = [["cost", "Purchase price (cost)"], ["list", "Sales value (list)"], ["cash", "Cash discount"], ["bulk", "Bulk discount"],
      ["net", "Net sales value"], ["commission", "Agent commission"]];
    h += '<table class="pb"><tr><th></th><th>Per unit</th><th>For qty</th></tr>';
    for (const [k, lab] of rows) h += "<tr><td>" + lab + "</td><td>" + money(r.unit[k]) + "</td><td>" + money(r.total[k]) + "</td></tr>";
    h += '<tr class="profit"><td>PROFIT</td><td>' + money(r.unit.profit) + "</td><td>" + money(r.total.profit) + "</td></tr></table>";
    h += '<div class="note">Margin ' + (r.margin * 100).toFixed(1) + "% of net sales · Cash discount: " + (r.cashApplied ? "applied" : "not applied (credit)") +
      " · Bulk discount: " + (r.bulkApplied ? "applied" : "needs " + qf(item.bulk_min) + "+ units") + "</div>";
    h += '<div style="margin-top:14px"><button class="btn" id="addBtn">Add to invoice</button></div><div style="margin-top:8px"><button class="btn sec" id="recBtn">Quick sale (no invoice)</button></div></div>';
    out.innerHTML = h;
    $("addBtn").onclick = () => addToCart(item, qty);
    $("recBtn").onclick = () => {
      if (qty > row.on_hand && !confirm("Quantity is more than the stock on hand. Record the sale anyway?")) return;
      try {
        Core.record(state, { date: today(), barcode: item.barcode, type: "OUT", payment: pay, agent: $("sAgent").value.trim(), note: "Scanned sale", qty });
      } catch (e) { return toast(e.message); }
      save(); toast("Sale recorded: " + qf(qty) + " × " + item.name);
      $("sBarcode").value = ""; $("sQty").value = "1"; renderScan(); 
    };
  }
  $("sBarcode").addEventListener("input", () => renderScan(false));
  $("sBarcode").addEventListener("change", () => renderScan(true));
  $("sBarcode").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); renderScan(true); } });
  $("sQty").addEventListener("input", () => renderScan(true));
  $("sCam").onclick = async () => { const c = await scanCamera(); if (c) { $("sBarcode").value = c; renderScan(true); } };

  // ---------- STOCK tab ----------
  $("kDate").value = today();
  seg("kType", (v) => { $("kOutOnly").style.display = v === "OUT" ? "block" : "none"; });
  seg("kPay");
  $("kOutOnly").style.display = "none";
  function showKName() {
    const code = $("kBarcode").value.trim(), it = Core.findItem(state, code);
    $("kName").textContent = it ? it.name + " (" + it.sku + ")" : code ? "Barcode not found" : "";
  }
  $("kBarcode").addEventListener("input", showKName);
  $("kBarcode").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); $("kQty").focus(); $("kQty").select(); } });
  $("kCam").onclick = async () => { const c = await scanCamera(); if (c) { $("kBarcode").value = c; showKName(); } };
  $("kAdd").onclick = () => {
    const type = segVal("kType"), code = $("kBarcode").value.trim(), qty = Number($("kQty").value), item = Core.findItem(state, code);
    if (item && type === "OUT" && qty > Core.onHand(state, item.barcode) && !confirm("Quantity is more than the stock on hand. Record anyway?")) return;
    try {
      Core.record(state, { date: $("kDate").value || today(), barcode: code, type, payment: segVal("kPay"), agent: $("kAgent").value.trim(), note: $("kNote").value.trim(), qty });
    } catch (e) { return toast(e.message); }
    save(); toast("Entry added");
    $("kBarcode").value = ""; $("kQty").value = "1"; $("kNote").value = ""; showKName(); renderStock();
  };
  function renderStock() {
    const names = Object.fromEntries(state.items.map((i) => [i.barcode, i.name]));
    const rows = state.log.slice().sort((a, b) => (b.date + String(b.id).padStart(9, "0")).localeCompare(a.date + String(a.id).padStart(9, "0"))).slice(0, 60);
    $("kList").innerHTML = rows.length ? rows.map((e) =>
      '<div class="it"><div><b>' + esc(names[e.barcode] || e.barcode) + '</b><div class="sub">' + esc(e.date) + " · " + e.type + (e.type === "OUT" ? " · " + esc(e.payment) : "") +
      (e.agent ? " · " + esc(e.agent) : "") + (e.note ? " · " + esc(e.note) : "") + '</div></div><div class="right"><b>' + (e.type === "IN" ? "+" : "−") + qf(e.qty) + "</b>" +
      (e.type === "OUT" ? '<div class="sub">profit ' + money(e.profit) + "</div>" : "") +
      '<div><button class="btn danger" style="padding:4px 10px;font-size:12px;margin-top:4px" data-del="' + e.id + '">Delete</button></div></div></div>').join("")
      : '<div class="sub">No entries yet.</div>';
  }
  $("kList").addEventListener("click", (e) => {
    const b = e.target.closest("[data-del]"); if (!b) return;
    const ent = state.log.find((x) => x.id === Number(b.dataset.del));
    if (ent && ent.invoice_id) { const iv = state.invoices.find((i) => i.id === ent.invoice_id); return toast("This sale belongs to " + (iv ? iv.number : "an invoice") + ". Void the invoice on the Invoices tab instead."); }
    if (confirm("Delete this entry?")) { Core.deleteLog(state, Number(b.dataset.del)); save(); renderAll(); }
  });

  // ---------- ITEMS tab ----------
  $("iSearch").addEventListener("input", renderItems);
  function renderItems() {
    const rows = Core.stockRows(state, $("iSearch").value);
    $("iList").innerHTML = rows.length ? rows.map((r) =>
      '<div class="it" data-id="' + r.id + '"><div><b>' + esc(r.name) + '</b><div class="sub">' + esc(r.sku) + " · " + esc(r.barcode) + '</div><div class="sub">Cost ' + money(r.purchase_price) +
      " · Price " + money(r.selling_price) + '</div></div><div class="right"><b>' + qf(r.on_hand) + '</b><div><span class="chip ' + (r.status === "Out of Stock" ? "Out" : r.status) + '">' + r.status + "</span></div></div></div>").join("")
      : '<div class="sub">No items yet. Tap + to add one, or import from the ⋮ menu.</div>';
  }
  $("iList").addEventListener("click", (e) => { const it = e.target.closest("[data-id]"); if (it) openItem(Number(it.dataset.id)); });
  $("fab").onclick = () => openItem(null);

  const FIELDS = [["sku", "SKU", "text"], ["barcode", "Barcode (EAN-13)", "barcode"], ["name", "Item name", "text"], ["category", "Category", "text"],
    ["supplier", "Supplier", "text"], ["location", "Location", "text"], ["purchase_price", "Purchase price ($)", "num"], ["selling_price", "Selling price ($)", "num"],
    ["cash_disc", "Cash discount %", "pct"], ["bulk_disc", "Bulk discount %", "pct"], ["bulk_min", "Bulk min quantity", "num"],
    ["commission", "Agent commission %", "pct"], ["reorder_level", "Reorder level", "num"], ["reorder_qty", "Reorder quantity", "num"]];

  function drawEAN(canvas, code) {
    const bits = Core.ean13Bits(code), note = $("bcNote");
    if (!bits) { canvas.style.display = "none"; note.textContent = code ? "Not a valid EAN-13 (13 digits, correct check digit) - no image preview, but it can still be used if it's scannable." : ""; return; }
    canvas.style.display = "block"; note.textContent = "";
    const m = 3, q = 30, h = 100, ctx = canvas.getContext("2d");
    canvas.width = bits.length * m + 2 * q; canvas.height = h + 36;
    ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.fillStyle = "#000";
    for (let i = 0; i < bits.length; i++) if (bits[i] === "1") {
      const guard = i < 3 || (i >= 45 && i < 50) || i >= 92;
      ctx.fillRect(q + i * m, 5, m, h + (guard ? 3 : -5));
    }
    ctx.font = "22px monospace"; ctx.textBaseline = "top";
    ctx.fillText(code[0], q - 20, h + 8); ctx.fillText(code.slice(1, 7), q + 3 * m + 2, h + 8); ctx.fillText(code.slice(7), q + 50 * m + 2, h + 8);
  }

  function openItem(id) {
    const it = id == null ? null : state.items.find((i) => i.id === id);
    let h = "<h3>" + (it ? "Edit item" : "Add item") + "</h3>";
    for (const [k, lab, type] of FIELDS) {
      let v = it ? it[k] : (k === "bulk_min" ? 1 : k === "barcode" ? Core.nextInternalBarcode(state.items) : "");
      if (type === "pct" && v !== "") v = Math.round(v * 1e6) / 1e4;
      if (type === "barcode") {
        h += "<label>" + lab + '</label><div class="scanrow"><input id="f_barcode" value="' + esc(v) + '" autocomplete="off"><button class="btn icon" id="f_cam">&#128247;</button></div>' +
          '<canvas id="bcCanvas" width="10" height="10"></canvas><div class="note" id="bcNote"></div>' +
          '<div class="row" style="margin-top:6px"><button class="btn sec" id="f_gen">Generate barcode</button><button class="btn sec" id="f_img">Save image</button></div>';
      } else h += "<label>" + lab + '</label><input id="f_' + k + '" value="' + esc(v) + '" ' + (type === "text" ? 'autocomplete="off"' : 'type="number" inputmode="decimal" min="0" step="any"') + ">";
    }
    h += '<div class="row" style="margin-top:18px"><button class="btn sec" id="f_cancel">Cancel</button><button class="btn" id="f_save">Save</button></div>';
    if (it) h += '<div style="margin-top:10px"><button class="btn danger" id="f_del">Delete item</button></div>';
    $("sheet").innerHTML = h; $("ov").classList.add("on"); $("sheet").scrollTop = 0;
    const redraw = () => drawEAN($("bcCanvas"), $("f_barcode").value.trim());
    $("f_barcode").addEventListener("input", redraw); redraw();
    $("f_gen").onclick = () => { $("f_barcode").value = Core.nextInternalBarcode(state.items); redraw(); };
    $("f_cam").onclick = async () => { const c = await scanCamera(); if (c) { $("f_barcode").value = c; redraw(); } };
    $("f_img").onclick = () => {
      const c = $("bcCanvas"); if (c.style.display === "none") return toast("No barcode image to save.");
      c.toBlob((b) => { const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = "barcode_" + $("f_barcode").value.trim() + ".png"; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); });
    };
    $("f_cancel").onclick = closeSheet;
    $("f_save").onclick = () => {
      const d = {};
      for (const [k, , type] of FIELDS) { const v = $("f_" + k).value; d[k] = type === "pct" ? (v === "" ? 0 : Number(v) / 100) : v; }
      try { Core.saveItem(state, d, it ? it.id : null); } catch (e) { return toast(e.message); }
      save(); closeSheet(); renderAll(); toast("Item saved");
    };
    if (it) $("f_del").onclick = () => {
      if (!confirm("Delete this item?")) return;
      try { Core.deleteItem(state, it.id); } catch (e) { return toast(e.message); }
      save(); closeSheet(); renderAll();
    };
  }
  function closeSheet() { $("ov").classList.remove("on"); }
  $("ov").addEventListener("click", (e) => { if (e.target === $("ov")) closeSheet(); });

  // ---------- DASHBOARD ----------
  function renderDash() {
    const t = Core.totals(state), n = (v) => qf(v);
    const s = (lab, v, cls) => '<div class="stat ' + (cls || "") + '">' + lab + "<b>" + v + "</b></div>";
    $("dash").innerHTML = "<h2>Stock</h2><div class=\"stats\">" + s("Total SKUs", t.skus) + s("Units on hand", n(t.units)) + s("Stock value (cost)", money(t.stock_value)) +
      s("Need reorder", t.reorder) + s("Out of stock", t.out) + "</div><h2>Sales</h2><div class=\"stats\">" +
      s("Gross sales", money(t.gross)) + s("Net sales", money(t.net)) + s("Cash discounts", money(t.cash)) + s("Bulk discounts", money(t.bulk)) +
      s("Agent commission", money(t.commission)) + s("Cost of goods", money(t.cogs)) + s("TOTAL PROFIT", money(t.profit) + ' <span class="sub">(' + (t.margin * 100).toFixed(1) + "% margin)</span>", "big") + "</div>";
  }

  // ---------- REPORTS tab ----------
  const canShareFiles = !!(navigator.canShare && (() => { try { return navigator.canShare({ files: [new File(["x"], "a.pdf", { type: "application/pdf" })] }); } catch (e) { return false; } })());
  $("rBiz").value = state.settings.business || "";
  $("rBiz").addEventListener("input", () => { state.settings.business = $("rBiz").value.trim(); save(); });
  $("rPresets").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    const [f, t] = Rep.preset(b.dataset.p); $("rFrom").value = f; $("rTo").value = t;
    $("rPresets").querySelectorAll("button").forEach((x) => x.classList.toggle("on", x === b));
  });
  const clearPreset = () => $("rPresets").querySelectorAll("button").forEach((x) => x.classList.remove("on"));
  $("rFrom").addEventListener("change", clearPreset); $("rTo").addEventListener("change", clearPreset);
  seg("rPrice");
  function renderReports() {
    const cats = [...new Set(state.items.map((i) => i.category).filter(Boolean))].sort(), cur = $("rCat").value;
    $("rCat").innerHTML = '<option value="">All categories</option>' + cats.map((c) => '<option value="' + esc(c) + '">' + esc(c) + "</option>").join("");
    $("rCat").value = cats.includes(cur) ? cur : "";
    $("rShareNote").textContent = state.items.length ? state.items.length + " items in your list." : "No items yet. Import your item list from the menu, or add items on the Items tab.";
    $("rList").innerHTML = Rep.LIST.filter((r) => !r[0].startsWith("barcode")).map((r) => '<div class="rep"><div><b>' + esc(r[1]) + '</b><div class="sub">' + esc(r[2]) + (r[3] ? "" : " (current stock)") + '</div></div><div class="btns">' +
      (canShareFiles ? '<button class="btn sec" data-share="' + r[0] + '">Share</button>' : "") + '<button class="btn" data-pdf="' + r[0] + '">PDF</button></div></div>').join("");
  }
  function makePDF(key) {
    const from = $("rFrom").value, to = $("rTo").value, def = Rep.LIST.find((r) => r[0] === key);
    if (def[3] && from && to && from > to) { toast("The From date is after the To date."); return null; }
    const model = Rep.build(state, key, from, to, { category: $("rCat").value, copies: $("rCopies").value, showPrice: segVal("rPrice") === "1" }), n = new Date(), p2 = (v) => String(v).padStart(2, "0");
    const bytes = PDF.build(model, { business: state.settings.business, generated: today() + " " + p2(n.getHours()) + ":" + p2(n.getMinutes()) });
    const name = key + (def[3] ? "_" + (from || "start") + "_to_" + (to || "today") : "_" + today()) + ".pdf";
    return { blob: new Blob([bytes], { type: "application/pdf" }), name, title: model.title };
  }
  $("t-reports").addEventListener("click", async (e) => {
    const b = e.target.closest("button"); if (!b) return;
    const key = b.dataset.pdf || b.dataset.share; if (!key) return;
    if (key.startsWith("barcode") && !state.items.length) return toast("Import or add items first.");
    const r = makePDF(key); if (!r) return;
    if (b.dataset.share) {
      try { await navigator.share({ files: [new File([r.blob], r.name, { type: "application/pdf" })], title: r.title }); } catch (err) { /* cancelled */ }
    } else { download(r.name, r.blob); toast("Saved " + r.name); }
  });

  // ---------- menu / import / export ----------
  $("menuBtn").onclick = (e) => { e.stopPropagation(); $("menu").classList.toggle("on"); };
  document.addEventListener("click", () => $("menu").classList.remove("on"));
  $("menu").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    const a = b.dataset.act, stamp = today();
    if (a === "expBackup") download("inventory-backup-" + stamp + ".json", JSON.stringify(state), "application/json");
    if (a === "impFile") $("fileIn").click();
    if (a === "expInv") {
      const rows = Core.stockRows(state, ""), cols = ["sku", "barcode", "name", "category", "supplier", "location", "purchase_price", "selling_price", "cash_disc", "bulk_disc", "bulk_min", "commission", "qty_in", "qty_out", "on_hand", "reorder_level", "reorder_qty", "value", "status"];
      download("inventory-" + stamp + ".csv", Core.toCSV([cols].concat(rows.map((r) => cols.map((c) => r[c])))), "text/csv");
    }
    if (a === "expLog") {
      const names = Object.fromEntries(state.items.map((i) => [i.barcode, i])), cols = ["date", "sku", "barcode", "name", "type", "payment", "agent", "note", "qty", "gross", "cash_disc", "bulk_disc", "net", "commission", "cogs", "profit"];
      const rows = state.log.slice().sort((a, b) => b.date.localeCompare(a.date) || b.id - a.id);
      download("sales-log-" + stamp + ".csv", Core.toCSV([cols].concat(rows.map((e) => cols.map((c) => c === "sku" ? (names[e.barcode] || {}).sku : c === "name" ? (names[e.barcode] || {}).name : e[c])))), "text/csv");
    }
  });
  $("fileIn").addEventListener("change", async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    try {
      const text = await f.text();
      if (f.name.toLowerCase().endsWith(".json")) {
        const d = JSON.parse(text);
        if (!d || !Array.isArray(d.items) || !Array.isArray(d.log)) throw new Error("Not a valid backup file.");
        if (!confirm("This replaces ALL data on this phone with the backup (" + d.items.length + " items, " + d.log.length + " log entries). Continue?")) return;
        state = { items: d.items, log: d.log, nextId: d.nextId || 1 + Math.max(0, ...d.items.map((i) => i.id), ...d.log.map((l) => l.id)), settings: d.settings || state.settings, invoices: d.invoices || [], cart: Core.newCart() }; Core.ensureState(state);
        $("rBiz").value = state.settings.business || "";
        toast("Backup restored");
      } else {
        const r = Core.importCSV(state, text);
        toast(r.kind === "inventory" ? "Items: " + r.added + " added, " + r.updated + " updated, " + r.skipped + " skipped" + (r.auto ? ". " + r.auto + " new barcodes created" : "") : "Log entries added: " + r.added + ", skipped: " + r.skipped);
      }
      save(); renderAll();
    } catch (err) { toast(err.message || "Import failed"); }
  });

  // ---------- INVOICES ----------
  const cartPrice = () => Core.priceLines(state, state.cart.lines, state.cart.payment, Number(state.settings.tax_rate) || 0);
  function addToCart(item, qty) {
    const c = state.cart, ln = c.lines.find((l) => l.barcode === item.barcode);
    if (ln) ln.qty += qty; else c.lines.push({ barcode: item.barcode, qty });
    if (c.lines.length === 1) { c.payment = segVal("sPay"); c.agent = $("sAgent").value.trim(); }
    save(); $("sBarcode").value = ""; $("sQty").value = "1"; renderScan(); renderCartBar(); toast("Added to invoice: " + item.name);
  }
  function renderCartBar() {
    const bar = $("cartBar"), n = state.cart.lines.length;
    if (!n || curTab !== "scan" || $("ov").classList.contains("on")) { bar.style.display = "none"; return; }
    let t = null; try { t = cartPrice(); } catch (e) { /* item removed */ }
    bar.style.display = "flex";
    bar.innerHTML = "<div><b>Invoice: " + n + (n === 1 ? " item" : " items") + '</b><div class="sub" style="color:#cfe0ff">' + (t ? Rep.money(t.total) : "") + '</div></div><button class="btn" id="cartOpen">View invoice</button>';
    $("cartOpen").onclick = openCart;
  }
  function invFile(inv, fmt) {
    const bytes = PDF.buildInvoice(Core.invoiceDoc(state, inv), fmt);
    return { blob: new Blob([bytes], { type: "application/pdf" }), name: (fmt === "receipt" ? "receipt_" : "invoice_") + inv.number + ".pdf", title: inv.number };
  }
  async function shareFile(r) { try { await navigator.share({ files: [new File([r.blob], r.name, { type: "application/pdf" })], title: r.title }); } catch (e) { /* cancelled */ } }
  function docButtons(inv) {
    return '<div class="row" style="margin-top:12px"><button class="btn" data-doc="a4">' + (inv.payment === "Cash" ? "Receipt" : "Invoice") + ' PDF (A4)</button><button class="btn sec" data-doc="receipt">Receipt 80 mm</button></div>' +
      (canShareFiles ? '<div class="row" style="margin-top:8px"><button class="btn sec" data-doc="share-a4">Share A4</button><button class="btn sec" data-doc="share-receipt">Share receipt</button></div>' : "");
  }
  function wireDocButtons(inv) {
    $("sheet").querySelectorAll("[data-doc]").forEach((b) => {
      b.onclick = () => {
        const k = b.dataset.doc, share = k.startsWith("share-"), fmt = k.replace("share-", ""), r = invFile(inv, fmt);
        if (share) shareFile(r); else { download(r.name, r.blob); toast("Saved " + r.name); }
      };
    });
  }
  function openCart() {
    const c = state.cart; if (!c.lines.length) { closeSheet(); renderCartBar(); return; }
    let t; try { t = cartPrice(); } catch (e) { return toast(e.message); }
    const custs = [...new Set(state.invoices.map((i) => i.customer).filter(Boolean))];
    let h = "<h3>New invoice</h3><datalist id=\"custList\">" + custs.map((x) => '<option value="' + esc(x) + '">').join("") + "</datalist>" +
      '<label>Customer name</label><input id="cuName" list="custList" placeholder="Walk-in customer" autocomplete="off" value="' + esc(c.customer) + '">' +
      '<label>Payment</label><div class="seg" id="cuPay"><button data-v="Cash"' + (c.payment === "Cash" ? ' class="on"' : "") + '>Cash</button><button data-v="Credit"' + (c.payment === "Credit" ? ' class="on"' : "") + ">Credit</button></div>" +
      '<label>Sales agent</label><input id="cuAgent" autocomplete="off" value="' + esc(c.agent) + '"><label>Note (optional)</label><input id="cuNote" autocomplete="off" value="' + esc(c.note) + '">' +
      "<h2>Items</h2><div class=\"card list\">" + t.lines.map((l, i) =>
        '<div class="it" style="align-items:flex-start"><div style="flex:1"><b>' + esc(l.name) + '</b><div class="sub">' + Rep.money(l.unit) + " each" + (l.disc ? " · discount " + Rep.money(l.disc) : "") + (l.qty > l.onHand ? ' · <span style="color:var(--red)">only ' + qf(l.onHand) + " in stock</span>" : "") +
        '</div></div><div class="right"><div class="stepper"><button data-q="-1" data-i="' + i + '">−</button><input data-qi="' + i + '" type="number" inputmode="decimal" min="0" step="any" value="' + qf(l.qty) + '"><button data-q="1" data-i="' + i + '">+</button></div><div><b>' + Rep.money(l.amount) +
        '</b></div><div><button class="btn danger" style="padding:4px 10px;font-size:12px;margin-top:4px" data-rm="' + i + '">Remove</button></div></div></div>').join("") + "</div>" +
      '<div class="card"><div class="tot"><span>Subtotal</span><span>' + Rep.money(t.subtotal) + '</span></div><div class="tot"><span>Discounts</span><span>' + (t.discounts ? "-" : "") + Rep.money(t.discounts) + "</span></div>" +
      (t.tax ? '<div class="tot"><span>Tax (' + Number(state.settings.tax_rate) + '%)</span><span>' + Rep.money(t.tax) + "</span></div>" : "") + '<div class="tot big"><span>TOTAL</span><span>' + Rep.money(t.total) + "</span></div></div>" +
      '<div style="margin-top:12px"><button class="btn" id="cuDone">Complete sale</button></div><div class="row" style="margin-top:8px"><button class="btn sec" id="cuClose">Keep adding items</button><button class="btn danger" id="cuClear">Clear</button></div>';
    $("sheet").innerHTML = h; $("ov").classList.add("on"); renderCartBar();
    $("cuName").oninput = () => { c.customer = $("cuName").value; save(); };
    $("cuAgent").oninput = () => { c.agent = $("cuAgent").value; save(); };
    $("cuNote").oninput = () => { c.note = $("cuNote").value; save(); };
    $("cuPay").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; c.payment = b.dataset.v; save(); openCart(); };
    $("sheet").querySelectorAll("[data-q]").forEach((b) => b.onclick = () => { const ln = c.lines[Number(b.dataset.i)]; ln.qty = Math.max(1, Number(ln.qty) + Number(b.dataset.q)); save(); openCart(); });
    $("sheet").querySelectorAll("[data-qi]").forEach((inp) => inp.onchange = () => { const v = Number(inp.value); if (v > 0) c.lines[Number(inp.dataset.qi)].qty = v; save(); openCart(); });
    $("sheet").querySelectorAll("[data-rm]").forEach((b) => b.onclick = () => { c.lines.splice(Number(b.dataset.rm), 1); save(); openCart(); });
    $("cuClose").onclick = () => { closeSheet(); };
    $("cuClear").onclick = () => { if (confirm("Clear this invoice?")) { state.cart = Core.newCart(); save(); closeSheet(); } };
    $("cuDone").onclick = () => {
      const low = t.lines.filter((l) => l.qty > l.onHand);
      if (low.length && !confirm("Some items are more than the stock on hand (" + low.map((l) => l.name).join(", ") + "). Complete the sale anyway?")) return;
      let inv; try { inv = Core.createInvoice(state, { date: today(), customer: c.customer, payment: c.payment, agent: c.agent, note: c.note, lines: c.lines }); } catch (e) { return toast(e.message); }
      state.cart = Core.newCart(); save(); renderAll(); showDone(inv);
    };
  }
  function showDone(inv) {
    $("sheet").innerHTML = '<h3>Sale completed</h3><div class="card"><div class="msg ok">' + esc(inv.number) + " saved. Stock updated.</div><div class=\"tot big\"><span>Total</span><span>" + Rep.money(inv.total) + "</span></div><div class=\"sub\">" +
      esc(inv.customer || "Walk-in customer") + " · " + inv.payment + "</div></div>" + docButtons(inv) + '<div style="margin-top:14px"><button class="btn" id="dnClose">Done</button></div>';
    $("ov").classList.add("on"); wireDocButtons(inv); $("dnClose").onclick = () => { closeSheet(); renderCartBar(); };
  }
  function openInvoice(id) {
    const inv = state.invoices.find((i) => i.id === id); if (!inv) return;
    const chip = inv.status === "void" ? "Void" : inv.payment === "Cash" ? "Paid" : "Due";
    $("sheet").innerHTML = "<h3>" + esc(inv.number) + ' <span class="chip ' + chip + '">' + chip + "</span></h3><div class=\"sub\">" + esc(inv.date) + " · " + esc(inv.customer || "Walk-in customer") + " · " + inv.payment + (inv.agent ? " · " + esc(inv.agent) : "") + "</div>" +
      '<div class="card list" style="margin-top:10px">' + inv.lines.map((l) => '<div class="it"><div><b>' + esc(l.name) + '</b><div class="sub">' + qf(l.qty) + " × " + Rep.money(l.unit) + (l.disc ? " · discount " + Rep.money(l.disc) : "") + '</div></div><b>' + Rep.money(l.amount) + "</b></div>").join("") + "</div>" +
      '<div class="card"><div class="tot"><span>Subtotal</span><span>' + Rep.money(inv.subtotal) + '</span></div><div class="tot"><span>Discounts</span><span>' + Rep.money(inv.discounts) + "</span></div>" + (inv.tax ? '<div class="tot"><span>Tax</span><span>' + Rep.money(inv.tax) + "</span></div>" : "") +
      '<div class="tot big"><span>TOTAL</span><span>' + Rep.money(inv.total) + "</span></div></div>" + docButtons(inv) +
      '<div class="row" style="margin-top:12px"><button class="btn sec" id="ivClose">Close</button>' + (inv.status !== "void" ? '<button class="btn danger" id="ivVoid">Void invoice</button>' : "") + "</div>";
    $("ov").classList.add("on"); wireDocButtons(inv); $("ivClose").onclick = closeSheet;
    if (inv.status !== "void") $("ivVoid").onclick = () => {
      if (!confirm("Void " + inv.number + "? Its items go back into stock and it is removed from sales reports.")) return;
      Core.voidInvoice(state, inv.id); save(); closeSheet(); renderAll(); toast(inv.number + " voided");
    };
  }
  function renderInvoices() {
    const q = $("vSearch").value.trim().toLowerCase();
    const rows = state.invoices.slice().sort((a, b) => b.id - a.id).filter((i) => !q || i.number.toLowerCase().includes(q) || (i.customer || "").toLowerCase().includes(q));
    $("vList").innerHTML = rows.length ? rows.map((i) => {
      const chip = i.status === "void" ? "Void" : i.payment === "Cash" ? "Paid" : "Due";
      return '<div class="it" data-inv="' + i.id + '"><div><b>' + esc(i.number) + " · " + esc(i.customer || "Walk-in") + '</b><div class="sub">' + esc(i.date) + " · " + i.lines.length + (i.lines.length === 1 ? " item" : " items") + '</div></div><div class="right"><b>' + Rep.money(i.total) + '</b><div><span class="chip ' + chip + '">' + chip + "</span></div></div></div>";
    }).join("") : '<div class="sub">No invoices yet. On the Scan tab, scan items and tap <b>Add to invoice</b>.</div>';
    const s = state.settings;
    if (document.activeElement !== $("vBiz")) $("vBiz").value = s.business || "";
    if (document.activeElement !== $("vAddr")) $("vAddr").value = s.address || "";
    if (document.activeElement !== $("vPhone")) $("vPhone").value = s.phone || "";
    if (document.activeElement !== $("vTax")) $("vTax").value = s.tax_rate || "";
    if (document.activeElement !== $("vNext")) $("vNext").value = s.next_invoice || 1;
    if (document.activeElement !== $("vFoot")) $("vFoot").value = s.footer || "";
  }
  $("vSearch").addEventListener("input", renderInvoices);
  $("vList").addEventListener("click", (e) => { const r = e.target.closest("[data-inv]"); if (r) openInvoice(Number(r.dataset.inv)); });
  [["vBiz", "business", String], ["vAddr", "address", String], ["vPhone", "phone", String], ["vFoot", "footer", String],
   ["vTax", "tax_rate", (v) => Math.max(0, Number(v) || 0)], ["vNext", "next_invoice", (v) => Math.max(1, Math.floor(Number(v)) || 1)]].forEach(([id, key, fn]) =>
    $(id).addEventListener("input", () => { state.settings[key] = fn($(id).value.trim ? $(id).value : $(id).value); save(); if (id === "vBiz") $("rBiz").value = state.settings.business; }));
  $("rBiz").addEventListener("input", () => { $("vBiz").value = state.settings.business; });

  // ---------- init ----------
  function renderAll() {
    if (curTab === "scan") renderScan(false);
    if (curTab === "stock") { renderStock(); showKName(); }
    if (curTab === "items") renderItems();
    if (curTab === "invoices") renderInvoices();
    if (curTab === "reports") renderReports();
    renderCartBar();
    if (curTab === "dash") renderDash();
  }
  { const hsh = location.hash.slice(1); if (["scan", "stock", "items", "invoices", "reports", "dash"].includes(hsh)) showTab(hsh); }
  renderAll();
  if ("serviceWorker" in navigator && /^https:|^http:\/\/localhost/.test(location.href)) navigator.serviceWorker.register("sw.js").then((reg) => {
    reg.addEventListener("updatefound", () => {
      const w = reg.installing; if (!w) return;
      w.addEventListener("statechange", () => { if (w.state === "installed" && navigator.serviceWorker.controller) toast("Update ready. Close and reopen the app to use it."); });
    });
  }).catch(() => {});
})();
