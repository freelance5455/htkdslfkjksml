import { initializeApp } from "https://www.gstatic.com/firebasejs/13.4.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithRedirect, getRedirectResult, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/13.4.0/firebase-auth.js";
// Firebase AI Logic is loaded on demand so an AI SDK/network issue cannot
// prevent Google sign-in, theme switching, or the rest of the interface.

/* إعداد Firebase الأصلي كما هو */
const firebaseConfig = {
  apiKey: "AIzaSyD8tsgA4Tu1lzu59AOAK1LjH1RptWMxVrk",
  authDomain: "marco-arena.firebaseapp.com",
  projectId: "marco-arena",
  storageBucket: "marco-arena.firebasestorage.app",
  messagingSenderId: "327613084379",
  appId: "1:327613084379:web:2a1476d4f51b2affd3d2fe",
  measurementId: "G-YDZTBG358F"
};

/* Firebase AI Logic: Gemini Developer API.
   لا يحتاج مفتاح Gemini داخل ملفات الموقع؛ Firebase يدير الاتصال عبر AI Logic. */
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

let marcoModelPromise;
async function getMarcoModel() {
  if (!marcoModelPromise) {
    marcoModelPromise = import("https://www.gstatic.com/firebasejs/13.4.0/firebase-ai.js")
      .then(({ getAI, getGenerativeModel, GoogleAIBackend }) => {
        const ai = getAI(app, { backend: new GoogleAIBackend() });
        return getGenerativeModel(ai, {
          model: "gemini-4-hydrogen",
          systemInstruction: "أنت MARCO AI، مساعد عربي مفيد وواضح. أجب بلغة المستخدم، واشرح ببساطة وبأمان. إذا كان السؤال دراسيًا فاشرح خطوة بخطوة."
        });
      })
      .catch(error => {
        marcoModelPromise = null;
        throw error;
      });
  }
  return marcoModelPromise;
}

/* تبقى خدمة الصور منفصلة وتحتاج مزود صور وخادمًا آمنًا. */
const MARCO_API_URL = "";
provider.setCustomParameters({prompt:"select_account"});
const $=id=>document.getElementById(id);
const STORE_KEY="marco_one_v2_saved";
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function getSaved(){try{return JSON.parse(localStorage.getItem(STORE_KEY)||'{"chats":[],"files":[]}')}catch{return {chats:[],files:[]}}}
function setSaved(data){localStorage.setItem(STORE_KEY,JSON.stringify(data))}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function copyText(t){try{await navigator.clipboard.writeText(t);toast("تم النسخ")}catch{toast("تعذر النسخ؛ انسخ النص يدويًا")}}
// Mobile browsers often block OAuth popups; Firebase recommends redirect sign-in on mobile.
getRedirectResult(auth).catch(error => {
  console.error("Google redirect sign-in:", error);
  const msg = $("authMessage");
  if (msg) msg.textContent = friendlyAuthError(error);
});

function friendlyAuthError(error) {
  const code = error?.code || "";
  if (code === "auth/unauthorized-domain") return "هذا النطاق غير مسموح. أضفه في Firebase Authentication > Settings > Authorized domains.";
  if (code === "auth/operation-not-allowed") return "فعّل مزوّد Google من Firebase Authentication > Sign-in method.";
  if (code === "auth/network-request-failed") return "تعذر الاتصال بالإنترنت. تحقق من الاتصال وحاول مجددًا.";
  if (code === "auth/invalid-api-key") return "مفتاح Firebase API غير صحيح؛ راجع إعدادات تطبيق الويب.";
  return "تعذر تسجيل الدخول (" + (code || "خطأ غير معروف") + "). راجع إعدادات Google في Firebase.";
}

$("googleLogin").addEventListener("click", async () => {
  const b = $("googleLogin");
  b.disabled = true;
  $("authMessage").textContent = "جارٍ تحويلك إلى تسجيل الدخول بحساب Google...";
  try {
    await signInWithRedirect(auth, provider);
  } catch (error) {
    console.error("Google sign-in:", error);
    $("authMessage").textContent = friendlyAuthError(error);
    b.disabled = false;
  }
});
$("logoutBtn").addEventListener("click",()=>signOut(auth).then(()=>toast("تم تسجيل الخروج")));
onAuthStateChanged(auth,user=>{if(user){$("welcome").classList.add("hidden");$("dashboard").classList.remove("hidden");$("profileName").textContent=user.displayName||"مستخدم MARCO";$("profileEmail").textContent=user.email||"";$("miniName").textContent=user.displayName||"حسابي";const p=user.photoURL||"https://www.gravatar.com/avatar/?d=mp&s=120";$("profilePhoto").src=p;$("miniPhoto").src=p;$("userMini").classList.remove("hidden")}else{$("dashboard").classList.add("hidden");$("welcome").classList.remove("hidden");$("userMini").classList.add("hidden")}});
// Restore and toggle the light theme; the matching body.light CSS is in style.css.
try {
  if (localStorage.getItem("marco_one_theme") === "light") document.body.classList.add("light");
} catch {}
$("themeBtn").addEventListener("click", () => {
  const isLight = document.body.classList.toggle("light");
  try { localStorage.setItem("marco_one_theme", isLight ? "light" : "dark"); } catch {}
  $("themeBtn").setAttribute("aria-pressed", String(isLight));
  toast(isLight ? "تم تفعيل المظهر الفاتح" : "تم تفعيل المظهر الداكن");
});
const workspace=$("workspace"),content=$("workspaceContent");
const titles={
 ai:["MARCO AI","مساعد محادثة متصل عبر Firebase AI Logic وGemini."],
 design:["استوديو الصور","أنشئ وصفًا تفصيليًا للصورة ثم أرسله لمزود صور عبر خادمك."],
 learn:["منطقة التعلم","شرح الدروس بالذكاء الاصطناعي مع أدوات مراجعة واختبارات قصيرة."],
 translate:["الترجمة","ترجم النصوص بين اللغات باستخدام خدمة ترجمة خارجية."],
 writing:["الكتابة الذكية","قوالب كتابة محلية وتحسين النصوص عبر Gemini."],
 tools:["الأدوات الذكية","أدوات عملية تعمل داخل المتصفح."],
 sites:["منشئ المواقع","اكتب HTML وشاهد معاينة محلية آمنة."],
 saved:["المحفوظات والملفات","المحتوى محفوظ في متصفح هذا الجهاز."]
};
function openWorkspace(key){const [title,desc]=titles[key];$("workspaceTitle").textContent=title;$("workspaceDesc").textContent=desc;workspace.classList.remove("hidden");workspace.scrollIntoView({behavior:"smooth",block:"start"});
 ({ai:renderAI,design:renderDesign,learn:renderLearn,translate:renderTranslate,writing:renderWriting,tools:renderTools,sites:renderSites,saved:renderSaved}[key])?.();}
$("closeWorkspace").addEventListener("click",()=>workspace.classList.add("hidden"));
document.querySelectorAll(".feature-card").forEach(c=>c.addEventListener("click",()=>openWorkspace(c.dataset.feature)));

async function askMarco(prompt) {
  const model = await getMarcoModel();
  const result = await model.generateContent(prompt);
  return result.response.text();
}
async function callMarco(action,payload){
  if(!MARCO_API_URL) throw new Error("استوديو الصور يحتاج ربط مزود صور بخادم آمن. محادثات MARCO AI وشرح الدروس والكتابة تعمل عبر Firebase AI Logic.");
  const res=await fetch(MARCO_API_URL.replace(/\/$/,"")+"/"+action,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  if(!res.ok) throw new Error("الخادم لم يقبل الطلب ("+res.status+")");
  return await res.json();
}
function renderAI(){content.innerHTML=`<div class="tool-box"><h3>محادثة MARCO AI</h3><div id="chatHistory" class="tool-output" style="min-height:180px;max-height:360px;overflow:auto">اكتب سؤالك وسيجيبك MARCO AI عبر Gemini.</div><label>رسالتك</label><textarea id="aiPrompt" placeholder="اسأل MARCO AI..."></textarea><button id="sendAI">إرسال</button><button class="secondary" id="saveChat">حفظ المحادثة</button><p class="tool-note">متصل عبر Firebase AI Logic. إذا ظهر خطأ، راجع إعداد Gemini وApp Check في Firebase.</p></div>`;
 let msgs=[];const hist=$("chatHistory");$("sendAI").onclick=async()=>{const q=$("aiPrompt").value.trim();if(!q)return toast("اكتب رسالتك أولًا");msgs.push({role:"user",content:q});hist.textContent+="\n\nأنت: "+q;$("aiPrompt").value="";$("sendAI").disabled=true;try{const transcript = msgs.map(m => (m.role==="user" ? "المستخدم: " : "MARCO AI: ") + m.content).join("\n");
const answer = await askMarco(transcript + "\nMARCO AI:");msgs.push({role:"assistant",content:answer});hist.textContent+="\n\nMARCO AI: "+answer;hist.scrollTop=hist.scrollHeight}catch(e){hist.textContent+="\n\nتنبيه: "+e.message;toast("تعذر الاتصال بـ Gemini؛ راجع إعدادات Firebase")}finally{$("sendAI").disabled=false}};
 $("saveChat").onclick=()=>{if(!msgs.length)return toast("لا توجد محادثة لحفظها");const s=getSaved();s.chats.unshift({id:Date.now(),date:new Date().toLocaleString("ar"),messages:msgs});setSaved(s);toast("تم حفظ المحادثة على هذا الجهاز")};}
function renderDesign(){content.innerHTML=`<div class="tool-layout"><div class="tool-box"><h3>وصف الصورة</h3><label>ماذا تريد أن تصمم؟</label><textarea id="imagePrompt" placeholder="مثال: شعار رياضي احترافي باللونين الأسود والذهبي..."></textarea><label>النمط</label><select id="imageStyle"><option>واقعي</option><option>أنمي</option><option>ثلاثي الأبعاد</option><option>شعار احترافي</option><option>سينمائي</option><option>كرتوني</option></select><button id="makeImage">إنشاء الصورة عبر الخادم</button><p class="tool-note">توليد الصورة يتطلب مزود صور وخادم Backend مضبوطًا. لن يتم عرض صورة وهمية إذا لم يكن الربط موجودًا.</p></div><div class="tool-box"><h3>النتيجة</h3><div id="imageResult" class="tool-output">ستظهر نتيجة خدمة الصور هنا.</div></div></div>`;
 $("makeImage").onclick=async()=>{const prompt=$("imagePrompt").value.trim();if(!prompt)return toast("اكتب وصف الصورة");$("imageResult").textContent="جارٍ إرسال الطلب...";try{const d=await callMarco("image",{prompt,style:$("imageStyle").value});if(d.imageUrl){$("imageResult").innerHTML=`<img src="${esc(d.imageUrl)}" alt="الصورة المنشأة" style="max-width:100%;border-radius:12px">`}else $("imageResult").textContent=d.message||"استلم الخادم الطلب لكنه لم يرجع رابط صورة."; }catch(e){$("imageResult").textContent=e.message}}}
function renderLearn(){content.innerHTML=`<div class="tool-layout"><div class="tool-box"><h3>مساعد شرح الدروس</h3><label>المادة أو الموضوع</label><input id="lessonSubject" placeholder="مثال: الفيزياء - الحركة الدائرية"><label>ما الذي تريد فهمه؟</label><textarea id="lessonQuestion" placeholder="اكتب اسم الدرس أو الجزء الصعب عليك..."></textarea><button id="explainLesson">شرح الدرس بالذكاء الاصطناعي</button><p class="tool-note">شرح الدروس متصل بـ Gemini عبر Firebase AI Logic.</p></div><div class="tool-box"><h3>الشرح</h3><div id="lessonOutput" class="tool-output">اكتب موضوعك واضغط شرح.</div><button class="secondary" id="saveLesson">حفظ الشرح كملاحظة</button></div><div class="tool-box"><h3>اختبر نفسك</h3><label>اكتب سؤالًا وإجابته الصحيحة، وسنختبرك بهما</label><input id="quizQ" placeholder="السؤال"><input id="quizA" placeholder="الإجابة الصحيحة"><button id="startQuiz">ابدأ الاختبار</button><div id="quizResult" class="tool-output">اختبار بسيط للمراجعة الذاتية.</div></div></div>`;
 $("explainLesson").onclick=async()=>{const subject=$("lessonSubject").value.trim(),question=$("lessonQuestion").value.trim();if(!question)return toast("اكتب الجزء الذي تريد شرحه");$("lessonOutput").textContent="جارٍ طلب الشرح...";try{const answer=await askMarco("اشرح هذا الموضوع للطالب باللغة العربية وبطريقة مبسطة ومنظمة. المادة/الموضوع: "+subject+"\nالسؤال أو الجزء المطلوب: "+question);
$("lessonOutput").textContent=answer||"لم يصل شرح."}catch(e){$("lessonOutput").textContent=e.message}};
 $("saveLesson").onclick=()=>saveLocalFile("ملاحظة دراسية", $("lessonOutput").textContent);
 $("startQuiz").onclick=()=>{const q=$("quizQ").value.trim(),a=$("quizA").value.trim();if(!q||!a)return toast("اكتب السؤال والإجابة");$("quizResult").innerHTML=`<div>${esc(q)}</div><input id="quizUserAnswer" placeholder="اكتب إجابتك"><button id="checkQuiz">تحقق من الإجابة</button>`;$("checkQuiz").onclick=()=>{$("quizResult").insertAdjacentHTML("beforeend",`<p>${$("quizUserAnswer").value.trim().toLowerCase()===a.toLowerCase()?"إجابة صحيحة! ممتاز.":"حاول مرة أخرى وراجع الإجابة الصحيحة: "+esc(a)}</p>`)}}}
function renderTranslate(){content.innerHTML=`<div class="tool-layout"><div class="tool-box"><h3>النص الأصلي</h3><label>من</label><select id="fromLang"><option value="ar">العربية</option><option value="en">الإنجليزية</option><option value="fr">الفرنسية</option><option value="de">الألمانية</option><option value="es">الإسبانية</option><option value="tr">التركية</option><option value="it">الإيطالية</option><option value="ru">الروسية</option></select><textarea id="sourceText" placeholder="اكتب النص الذي تريد ترجمته..."></textarea><button id="translateBtn">ترجم الآن</button><button class="secondary" id="clearTranslate">مسح</button></div><div class="tool-box"><h3>الترجمة</h3><label>إلى</label><select id="toLang"><option value="en">الإنجليزية</option><option value="ar">العربية</option><option value="fr">الفرنسية</option><option value="de">الألمانية</option><option value="es">الإسبانية</option><option value="tr">التركية</option><option value="it">الإيطالية</option><option value="ru">الروسية</option></select><div id="translatedText" class="tool-output">ستظهر الترجمة هنا...</div><button class="secondary" id="copyTranslation">نسخ الترجمة</button><p class="tool-note">تحتاج الترجمة إلى الإنترنت وتُرسل النصوص إلى خدمة MyMemory الخارجية. لا ترسل معلومات حساسة.</p></div></div>`;
 $("translateBtn").onclick=async()=>{const q=$("sourceText").value.trim(),from=$("fromLang").value,to=$("toLang").value;if(!q)return toast("اكتب نصًا أولًا");if(from===to)return $("translatedText").textContent=q;const out=$("translatedText");out.textContent="جارٍ الترجمة...";try{const url=`https://api.mymemory.translated.net/get?q=${encodeURIComponent(q.slice(0,450))}&langpair=${from}|${to}`;const r=await fetch(url);if(!r.ok)throw Error("network");const d=await r.json();out.textContent=d.responseData?.translatedText||"لم تصل ترجمة."}catch{out.textContent="تعذرت الترجمة الآن. تحقق من الإنترنت وحاول مرة أخرى."}};
 $("clearTranslate").onclick=()=>{$("sourceText").value="";$("translatedText").textContent="ستظهر الترجمة هنا..."};$("copyTranslation").onclick=()=>copyText($("translatedText").textContent)}
function renderWriting(){content.innerHTML=`<div class="tool-layout"><div class="tool-box"><h3>مساعد الكتابة</h3><label>نوع النص</label><select id="writingType"><option value="رسالة رسمية">رسالة رسمية</option><option value="منشور على وسائل التواصل">منشور على وسائل التواصل</option><option value="رسالة اعتذار">رسالة اعتذار</option><option value="إعلان قصير">إعلان قصير</option><option value="سيرة ذاتية مختصرة">نبذة شخصية</option><option value="موضوع تعبير">موضوع تعبير</option></select><label>فكرتك أو النقاط الأساسية</label><textarea id="writingIdea" placeholder="اكتب ما تريد قوله..."></textarea><button id="makeDraft">إنشاء مسودة</button><button class="secondary" id="aiDraft">تحسين بالذكاء الاصطناعي</button><p class="tool-note">إنشاء المسودة يعمل محليًا، والتحسين الذكي يستخدم Gemini عبر Firebase AI Logic.</p></div><div class="tool-box"><h3>مسودتك</h3><div id="draftOutput" class="tool-output">ستظهر المسودة هنا...</div><button class="secondary" id="copyDraft">نسخ النص</button><button class="secondary" id="saveDraft">حفظ المسودة</button></div></div>`;
 $("makeDraft").onclick=()=>{const idea=$("writingIdea").value.trim(),type=$("writingType").value;if(!idea)return toast("اكتب فكرتك أولًا");let draft=type==="رسالة رسمية"?`السادة/ المحترمون،\n\nتحية طيبة وبعد،\n\n${idea}\n\nشاكرين لكم حسن تعاونكم.\nمع خالص التحية والتقدير.`:type==="منشور على وسائل التواصل"?`${idea}\n\nشاركونا آراءكم في التعليقات ✨`:type==="رسالة اعتذار"?`أود أن أقدم اعتذاري عن الأمر التالي:\n${idea}\n\nأقدّر تفهمكم، وسأحرص على عدم تكرار ذلك.`:type==="إعلان قصير"?`✨ ${idea}\n\nتابعونا لمعرفة المزيد!`:type==="موضوع تعبير"?`مقدمة:\nيُعد هذا الموضوع من الموضوعات المهمة في حياتنا.\n\n${idea}\n\nخاتمة:\nوفي النهاية، علينا الاستفادة من هذه الأفكار وتطبيق المفيد منها.`:idea;$("draftOutput").textContent=draft};
 $("aiDraft").onclick=async()=>{const idea=$("writingIdea").value.trim();if(!idea)return toast("اكتب فكرتك");$("draftOutput").textContent="جارٍ التحسين...";try{const answer=await askMarco("ساعدني في كتابة "+$("writingType").value+". حسّن النص التالي مع الحفاظ على قصدي ونبرته:\\n"+idea);
$("draftOutput").textContent=answer||"لم تصل نتيجة"}catch(e){$("draftOutput").textContent="تعذر تحسين النص عبر Gemini: "+(e?.message||"خطأ غير معروف")+". راجع إعدادات Firebase AI Logic وApp Check."}};
 $("copyDraft").onclick=()=>copyText($("draftOutput").textContent);$("saveDraft").onclick=()=>saveLocalFile("مسودة كتابة",$("draftOutput").textContent)}
function renderTools(){content.innerHTML=`<div class="tool-layout"><div class="tool-box"><h3>حاسبة سريعة</h3><label>عملية حسابية</label><input id="calcInput" placeholder="مثال: (25 + 15) * 2"><button id="calculate">احسب</button><div id="calcOutput" class="tool-output">النتيجة ستظهر هنا...</div></div><div class="tool-box"><h3>عداد الكلمات والحروف</h3><label>النص</label><textarea id="countInput" placeholder="الصق النص هنا..."></textarea><div class="quick-stats"><span class="stat-pill" id="wordsCount">الكلمات: 0</span><span class="stat-pill" id="charsCount">الحروف: 0</span><span class="stat-pill" id="linesCount">الأسطر: 0</span></div></div><div class="tool-box"><h3>تنسيق النص</h3><textarea id="formatInput" placeholder="اكتب النص..."></textarea><button id="upperText">أحرف كبيرة</button><button id="lowerText" class="secondary">أحرف صغيرة</button><button id="trimText" class="secondary">تنظيف المسافات</button><button id="reverseText" class="secondary">عكس النص</button><div id="formatOutput" class="tool-output">النص بعد التنسيق...</div><button id="copyFormat" class="secondary">نسخ الناتج</button></div><div class="tool-box"><h3>أدوات إضافية</h3><label>مولّد كلمة مرور عشوائية (للاستخدامات العادية)</label><button id="makePassword">إنشاء كلمة مرور</button><div id="passwordOutput" class="tool-output">اضغط لإنشاء كلمة مرور</div><button id="copyPassword" class="secondary">نسخ</button><button id="copyPage" class="secondary">نسخ رابط الصفحة</button></div></div>`;
 $("calculate").onclick=()=>{const s=$("calcInput").value.trim();if(!/^[0-9+\-*/().%\s]+$/.test(s))return $("calcOutput").textContent="اكتب عملية حسابية صحيحة.";try{const normalized=s.replace(/(\d+(?:\.\d+)?)%/g,"($1/100)");const result=Function('"use strict";return ('+normalized+')')();$("calcOutput").textContent=Number.isFinite(result)?String(result):"عملية غير صالحة"}catch{$("calcOutput").textContent="تعذر حساب العملية."}};
 $("countInput").oninput=()=>{const t=$("countInput").value;$("wordsCount").textContent="الكلمات: "+(t.trim()?t.trim().split(/\s+/).length:0);$("charsCount").textContent="الحروف: "+t.length;$("linesCount").textContent="الأسطر: "+(t? t.split(/\n/).length:0)};
 $("upperText").onclick=()=>{$("formatOutput").textContent=$("formatInput").value.toUpperCase()};$("lowerText").onclick=()=>{$("formatOutput").textContent=$("formatInput").value.toLowerCase()};$("trimText").onclick=()=>{$("formatOutput").textContent=$("formatInput").value.replace(/\s+/g," ").trim()};$("reverseText").onclick=()=>{$("formatOutput").textContent=[...$("formatInput").value].reverse().join("")};$("copyFormat").onclick=()=>copyText($("formatOutput").textContent);
 $("makePassword").onclick=()=>{$("passwordOutput").textContent=Array.from(crypto.getRandomValues(new Uint8Array(16)),b=>"ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*"[b%67]).join("")};$("copyPassword").onclick=()=>copyText($("passwordOutput").textContent);$("copyPage").onclick=()=>copyText(location.href)}
function renderSites(){content.innerHTML=`<div class="tool-layout"><div class="tool-box"><h3>محرر HTML</h3><label>اكتب كود صفحتك</label><textarea id="siteCode" style="min-height:260px" placeholder="<!doctype html>..."></textarea><button id="previewSite">معاينة الموقع</button><button id="downloadSite" class="secondary">تنزيل ملف HTML</button><p class="tool-note">المعاينة تعمل داخل إطار معزول. لا تلصق أكوادًا لا تثق بها.</p></div><div class="tool-box"><h3>معاينة مباشرة</h3><iframe id="sitePreview" title="معاينة الموقع" sandbox="" style="width:100%;height:330px;background:white;border:1px solid #70449a88;border-radius:12px"></iframe></div></div>`;
 $("previewSite").onclick=()=>{$("sitePreview").srcdoc=$("siteCode").value};$("downloadSite").onclick=()=>{const blob=new Blob([$("siteCode").value],{type:"text/html"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="marco-site.html";a.click();URL.revokeObjectURL(a.href)}}
function saveLocalFile(name,text){if(!text||!text.trim())return toast("لا يوجد محتوى لحفظه");const s=getSaved();s.files.unshift({id:Date.now(),name,date:new Date().toLocaleString("ar"),text});setSaved(s);toast("تم الحفظ على هذا الجهاز")}
function renderSaved(){const s=getSaved();content.innerHTML=`<div class="tool-layout"><div class="tool-box"><h3>حفظ ملاحظة أو ملف نصي</h3><label>اسم الملف</label><input id="savedName" placeholder="اسم الملف"><label>المحتوى</label><textarea id="savedText" placeholder="اكتب ملاحظتك أو الصق نصًا..."></textarea><button id="saveTextFile">حفظ</button><label>استيراد ملف نصي (.txt أو .md)</label><input type="file" id="importTextFile" accept=".txt,.md,.csv,text/plain,text/markdown"></div><div class="tool-box"><h3>المحفوظات</h3><div id="savedList" class="tool-output" style="max-height:390px;overflow:auto"></div><button id="exportSaved" class="secondary">تنزيل نسخة احتياطية JSON</button><button id="clearSaved" class="secondary">مسح كل المحفوظات</button></div><div class="tool-box"><h3>المحادثات المحفوظة</h3><div id="chatSavedList" class="tool-output"></div></div></div>`;
 const refresh=()=>{const d=getSaved();$("savedList").innerHTML=d.files.length?d.files.map(f=>`<div style="border-bottom:1px solid #ffffff20;padding:8px 0"><b>${esc(f.name)}</b><small> — ${esc(f.date)}</small><p>${esc((f.text||"").slice(0,180))}</p><button data-open="${f.id}">عرض</button><button class="secondary" data-del="${f.id}">حذف</button></div>`).join(""):"لا توجد ملفات محفوظة بعد."; $("chatSavedList").textContent=d.chats.length?d.chats.map(c=>c.date+" — "+c.messages.length+" رسالة").join("\n"):"لا توجد محادثات محفوظة."};
 $("saveTextFile").onclick=()=>{saveLocalFile($("savedName").value.trim()||"ملاحظة", $("savedText").value);refresh()};
 $("importTextFile").onchange=async e=>{const f=e.target.files[0];if(!f)return;const t=await f.text();saveLocalFile(f.name,t);refresh();e.target.value=""};
 $("savedList").onclick=e=>{const id=Number(e.target.dataset.open||e.target.dataset.del);if(!id)return;const d=getSaved();if(e.target.dataset.del){d.files=d.files.filter(f=>f.id!==id);setSaved(d);refresh()}else{const f=d.files.find(x=>x.id===id);if(f){$("savedName").value=f.name;$("savedText").value=f.text}}};
 $("exportSaved").onclick=()=>{const blob=new Blob([JSON.stringify(getSaved(),null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="marco-one-backup.json";a.click();URL.revokeObjectURL(a.href)};
 $("clearSaved").onclick=()=>{if(confirm("هل تريد مسح كل الملفات والمحادثات المحفوظة على هذا الجهاز؟")){setSaved({chats:[],files:[]});refresh()}};refresh()}
