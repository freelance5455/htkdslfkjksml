// ==========================================
// MASTER LOCALIZED RECIPE DATA SHEET
// ==========================================
var defaultRecipes = [
    {
        id: 1,
        category: "Breakfast",
        isCustom: false,
        creator: 'System',
        name: { en: "Classic Pancakes", af: "Klassieke Pannekoeke" },
        desc: { en: "Fluffy and golden breakfast favorites.", af: "Flouerige en goue ontbytgunstelinge." },
        img: "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?q=80&w=600&auto=format&fit=crop",
        ingredients: {
            metric: {
                en: ["200g Flour", "2 Eggs", "300ml Milk"],
                af: ["200g Meel", "2 Eiers", "300ml Melk"]
            },
            imperial: {
                en: ["1.5 Cups Flour", "2 Eggs", "1.25 Cups Milk"],
                af: ["1.5 Koppies Meel", "2 Eiers", "1.25 Koppies Melk"]
            }
        },
        method: {
            en: ["Whisk flour.", "Cook on hot skillet."],
            af: ["Klits meel.", "Bak op ‘n warm pan."]
        },
        serving: { en: "Serve with syrup.", af: "Sit voor met stroop." }
    },
    {
        id: 2,
        category: "Main Dishes",
        isCustom: false,
        creator: "System",
        name: { en: "Spiced Bobotie", af: "Gekruide Bobotie" },
        desc: { en: "Traditional South African dish.", af: "Tradisionele Suid-Afrikaanse gereg." },
        img: "https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=600&auto=format&fit=crop",
        ingredients: {
            metric: {
                en: ["500g Minced Beef", "1 Onion"],
                af: ["500g Maalvleis", "1 Ui"]
            },
            imperial: {
                en: ["1.1 lbs Beef", "1 Onion"],
                af: ["1.1 lbs Maalvleis", "1 Ui"]
            }
        },
        method: {
            en: ["Bake at 180°C."],
            af: ['Bak by 180°C.']
        },
        serving: { en: "Serve with rice.", af: "Sit voor met rys." }
    }
];
// ==========================================
// JSONBIN.IO SERVER SYNC SETUPS CONFIG
// ==========================================
var BIN_ID = '6ab22f6eac6210605ae8802a';
var MASTER_KEY = '$2a$10$IFsoAQUJmzOdlmpBah4HuerhSgv8FxIOOLG8dlJc7GM8S0qpmnPCO';
var CLOUD_DATABASE_URL = "https://api.jsonbin.io/v3/b/" + BIN_ID;
var communityRecipesShared = [];
// ==========================================
// APP STATE & PROFILES ENVIRONMENT CONFIG
// ==========================================
var appState = {
    unit: 'metric',
    lang: "en",
    audioEnabled: false,
    currentScreen: "welcome-screen",
    currentTab: "all",
    activeRecipeId: null,
    currentUser: "User_1"
};
var expandedCategories = {
    "Breakfast": true,
    "Main Dishes": true,
    "Desserts": true
};
document.addEventListener("DOMContentLoaded", function() {
    var accessGranted = checkRegistrationStatus();
    if (accessGranted) {
        initializeUserEnvironments();
        populateUserDropdown();
        renderRecipeList();
    }
});
function checkRegistrationStatus() {
    if (localStorage.getItem('recipe_app_unlocked') === 'true') {
        return true;
    }
    var now = new Date().getTime();
    var installDate = localStorage.getItem('app_install_date');

    if (!installDate) {
        localStorage.setItem('app_install_date', now); installDate = now;
        installDate=now;
    }

    var totalTrialDuration = 14 * 24 * 60 * 60 * 1000; // 14 days in ms var timeElapsed = now - parseInt(installDate); var timeLeft = totalTrialDuration - timeElapsed; var daysLeft = Math.ceil(timeLeft / (1000 * 60 * 60 * 24));
    var timeElapsed=now-parseInt(installDate);
    var timeLeft=totalTrialDuration-timeElapsed;
    var daysLeft=Math.ceil(timeLeft/(1000*60*60*24));

    if (daysLeft <= 0) {
        showLockout("Trial Expired / Proeftyd Verby", "Your 14-day trial period has ended. Please enter your code to permanently restore catalog configurations.");
        return false;
    }
    return true;
}
function openActivationModal() {
    showLockout("Activation Key Entry", "Enter your system authorization signature key code to verify lifetime premium application profiles.");
}
function validateLicenseKey() {
    var key = document.getElementById('license-key-input').value.trim();
    if (key === "100123200345300678400901") {
        localStorage.setItem('recipe_app_unlocked', 'true');
        alert("Verification Success! Device registered permanently.");
        location.reload();
    } else {
        alert("Invalid authorization sequence validation entry parameter code.");
    }
}
function initializeUserEnvironments() {
    ['User_1', 'User_2', 'User_3'].forEach(function(usr) {
        if (!localStorage.getItem(usr + '_favorites')) localStorage.setItem(usr + '_favorites', JSON.stringify([]));
        if (!localStorage.getItem(usr + '_customs')) localStorage.setItem(usr + '_customs', JSON.stringify([]));
    });
    if (MASTER_KEY === "Paste_your_master_key_string_here" || !MASTER_KEY) { console.log("Using local database mode."); renderRecipeList(); return; }
    fetch(CLOUD_DATABASE_URL + "/latest", { method: 'GET', headers: { 'X-Master-Key': MASTER_KEY } }) .then(function(res) { return res.json(); }) .then(function(data) { var fullCloudRecordList = data.record || data || []; if (Array.isArray(fullCloudRecordList)) { communityRecipesShared = fullCloudRecordList.filter(function(recipe){ return recipe && recipe.id !== "init_seed_placeholder"; }); } console.log("Community cloud database synced successfully."); renderRecipeList(); }) .catch(function(err) { console.warn("Cloud tracking unavailable. Running locally.", err); renderRecipeList(); });
}
function populateUserDropdown() {
    var select = document.getElementById('user-selector');
    if (select) {
        select.innerHTML =  '<option value="User_1">User Profile 1</option>'+
                            '<option value="User_2">User Profile 2</option>'+
                            '<option value="User_3">User Profile 3</option>';
        select.value = appState.currentUser;
    }
}
function switchUser(val) {
    appState.currentUser = val;
    renderRecipeList();
}
function getAllRecipes() {
    var text = localStorage.getItem(appState.currentUser + '_customs');
    var localCustoms = [];
    try {
        if (text) localCustoms = JSON.parse(text);
    } catch (e) {
        localCustoms = [];
    }
    var masterList = [];
    if (Array.isArray(defaultRecipes)) masterList = masterList.concat(defaultRecipes);
    if (Array.isArray(localCustoms)) masterList = masterList.concat(localCustoms);
    if (Array.isArray(communityRecipesShared)) masterList = masterList.concat(communityRecipesShared);
    return masterList;
}
function showLockout(title, message) {
    document.querySelectorAll('.screen').forEach(function(s) { s.classList.replace('active', 'hidden'); });
    var lockout = document.getElementById('lockout-screen');
    if (lockout) {
        lockout.classList.replace('hidden', 'active');
    }
    var tEl = document.getElementById('lockout-title');
    var mEl = document.getElementById('lockout-message');
    if (tEl) tEl.innerText = title;
    if (mEl) mEl.innerText = message;
}
function nextScreen(screenId) {
    document.getElementById(appState.currentScreen).classList.replace('active', 'hidden');
    document.getElementById(screenId).classList.replace('hidden', 'active');
    appState.currentScreen = screenId;
}
function selectUnit(unit) {
    appState.unit = unit;
    nextScreen('language-screen');
}
function selectLanguage(lang) {
    appState.lang = lang;
    localizeLabels();
    nextScreen('audio-screen');
}
function selectAudio(enabled) {
    appState.audioEnabled = enabled;
    nextScreen('list-screen');
}
function localizeLabels() {
    var isEn = appState.lang === 'en';
    document.getElementById('audio-title').innerText = isEn ? "Read Aloud?" : "Wil jy hê die resep moet hardop gelees word?";
    document.getElementById('list-title').innerText = isEn ? "Categories" : "Kategorieë";
    document.getElementById('tab-all').innerText = isEn ? "Index Tree" : "Inhoudsboom";
    document.getElementById('tab-fav').innerText = isEn ? "★ My Favorites" : "★ My Gunstelinge";
    document.getElementById('add-title').innerText = isEn ? "Add Recipe" : "Nuwe Resep";
    document.getElementById('disc-title').innerText = isEn ? "Disclaimer:" : "Vrywaring:";
    document.getElementById('disc-text').innerText = isEn ?
        "Any custom recipe submitted will be securely synchronized to our master catalog database for verification review, and may be featured in future official version prints." :
        "Enige pasgemaakte resep wat ingedien word, sal veilig gesinchroniseer word na ons meesterkatalogusdatabasis vir hersiening, en kan in toekomstige amptelike uitgawes verskyn.";

// Update Trial Banner layout dynamically matching languages
    var bannerTextEl = document.getElementById('trial-banner-text');
    if (bannerTextEl) {
        if (localStorage.getItem('recipe_app_unlocked') === 'true') {
            bannerTextEl.innerText = isEn ? "Premium Lifetime Activated" : "Premium Lifetime Geaktiveer";
        } else {
            var now = new Date().getTime();
            var installDate = parseInt(localStorage.getItem('app_install_date') || now);
            var daysLeft = Math.ceil(((14 * 24 * 60 * 60 * 1000) - (now - installDate)) / (1000 * 60 * 60 * 24));
            bannerTextEl.innerText = isEn ? "Trial Status: " + daysLeft + " days remaining (Tap to Activate)" : "Proef Status: " + daysLeft + " dae oor (Tik om te Aktiveer)";
        }
    }
}
function switchTab(t) {
    appState.currentTab = t;
    document.getElementById('tab-all').classList.toggle('active-tab', t==='all');
    document.getElementById('tab-fav').classList.toggle('active-tab', t==='fav');
    renderRecipeList();
}
function renderRecipeList() {
    var container = document.getElementById('recipe-list-container');
    if (!container) return;
    container.innerHTML = "";
    var list = getAllRecipes();
    if (appState.currentTab === 'fav') {
        var favs = JSON.parse(localStorage.getItem(appState.currentUser + '_favorites')) || [];
        list = list.filter(function (r) {
            return favs.includes(r.id.toString());
        });
    }
    var categories = ["Breakfast", "Main Dishes", "Desserts"];
    categories.forEach(function (cat) {
        var catList = list.filter(function (r) {
            return r.category === cat;
        });
        if (catList.length === 0) return;
        var header = document.createElement('div');
        header.className = "category-tree-header";
        var arrow = expandedCategories[cat] ? " ▾" : " ▸";
        header.innerText = cat + " (" + catList.length + ")" + arrow;
        header.onclick = function () {
            expandedCategories[cat] = !expandedCategories[cat];
            renderRecipeList();
        };
        container.appendChild(header);
        var wrapper = document.createElement('div');
        wrapper.className = "category-recipes-wrapper";
        if (!expandedCategories[cat]) wrapper.className += " collapsed";
        catList.forEach(function (recipe) {
            var card = document.createElement('div');
            card.className = "recipe-summary-card";
            var title = recipe.isCustom ? recipe.name : recipe.name[appState.lang];
            var desc = recipe.isCustom ? recipe.desc : recipe.desc[appState.lang];
            var listArray = [];
            if (recipe.isCustom) {
                listArray = recipe.ingredients || [];
            } else if (recipe.ingredients && recipe.ingredients[appState.unit]) {
                listArray = recipe.ingredients[appState.unit][appState.lang] || [];
            }
            var ingPreview = listArray.slice(0, 3).join(', ');
            card.innerHTML = ` <h3>${title}</h3>
                <p class="desc">${desc}</p>
                <p class="ing-preview">${appState.lang === 'en' ? 'Ingredients' : 'Bestanddele'}: ${ingPreview}...</p>
                <button class="btn"style="padding:6px 12px; margin: 5px 0 0 0; width:auto;font-size:0.85rem;"onclick="openRecipeDetail('${recipe.id}')">open</button>`;
            wrapper.appendChild(card);
        });
        container.appendChild(wrapper);
    });
}
function saveCustomRecipe(e) {
    e.preventDefault();
    var name = document.getElementById('form-name').value;
    var cat = document.getElementById('form-category').value;
    var creator = document.getElementById('form-creator').value;
    var desc = document.getElementById('form-desc').value;
    var ings = document.getElementById('form-ingredients').value.split('\n').filter(function (line) { return line.trim() !== ''; });
    var steps = document.getElementById('form-method').value.split('\n').filter(function (line) { return line.trim() !== ''; });
    var serving = document.getElementById('form-serving').value;
    var newRecipePayload = {
        id: 'custom_' + new Date().getTime(),
        category: cat,
        isCustom: true,
        creator: creator,
        name: name,
        desc: desc,
        img: "unsplash.com",
        ingredients: ings,
        method: steps,
        serving: serving,
        userSubmittedBy: appState.currentUser
    };
    var customs = JSON.parse(localStorage.getItem(appState.currentUser + '_customs')) || [];
    customs.push(newRecipePayload);
    localStorage.setItem(appState.currentUser + '_customs', JSON.stringify(customs));
    fetch(CLOUD_DATABASE_URL + "/latest", {
        method: 'GET',
        headers: {'X-Master-Key': MASTER_KEY}
    })
        .then(function (res) { return res.json(); })
        .then(function (currentCloudData) {
            var currentServerList = currentCloudData.record || [];
            currentServerList.push(newRecipePayload);
            return fetch(CLOUD_DATABASE_URL, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json', 'X-Master-Key': MASTER_KEY },
                body: JSON.stringify(currentServerList)
            });
        })
        .then(function () {
            alert(appState.lang === 'en' ? "Recipe Shared and Synced Globally!" : "Resep Suksesvol Wêreldwyd Gesinchroniseer!");
            renderRecipeList();
            nextScreen('list-screen');
        })
        .catch(function (err) {
            console.error("Cloud pipeline processing error:", err);
            alert(appState.lang==='en'?"Local backup saved! Syncing to Cloud skipped.":"Plaaslike rugsteun gestoor! Sinchronisasie oorgeslaan.");
            renderRecipeList();
            nextScreen('list-screen');
        });
    document.getElementById('custom-recipe-form').reset();
}
function openRecipeDetail(id) {
    var recipe = getAllRecipes().find(function (r) { return r.id.toString() === id.toString(); });
    if (!recipe) return;
    appState.activeRecipeId = id;
    document.getElementById('dynamic-bg').style.backgroundImage = "url('" + recipe.img + "')";
    var title = recipe.isCustom ? recipe.name : recipe.name[appState.lang];
    var desc = recipe.isCustom ? recipe.desc : recipe.desc[appState.lang];
    var serving = recipe.isCustom ? recipe.serving : recipe.serving[appState.lang];
    document.getElementById('recipe-name').innerText = title;
    document.getElementById('recipe-desc').innerText = desc;
    document.getElementById('recipe-serving').innerText = serving;
    document.getElementById('recipe-author').innerText = (appState.lang === 'en' ? 'By' : 'Deur') + ": " + recipe.creator;
    var ingUl = document.getElementById('recipe-ingredients');
    ingUl.innerHTML = "";
    var localizedIngs = recipe.isCustom ? recipe.ingredients : recipe.ingredients[appState.unit][appState.lang];
    localizedIngs.forEach(function (ing) {
        var li = document.createElement('li');
        li.innerText = ing;
        ingUl.appendChild(li);
    });
    var methodOl = document.getElementById('recipe-method');
    methodOl.innerHTML = "";
    var localizedSteps = recipe.isCustom ? recipe.method : recipe.method[appState.lang];
    localizedSteps.forEach(function (s) {
        var li = document.createElement('li');
        li.innerText = s;
        methodOl.appendChild(li);
    });
    var favs = JSON.parse(localStorage.getItem(appState.currentUser + '_favorites')) || [];
    document.getElementById('fav-toggle-btn').innerText = favs.includes(id.toString()) ? "★" : "☆";
    nextScreen('detail-screen');
    if (appState.audioEnabled) speakRecipe(title, desc, localizedIngs, localizedSteps);
}
function toggleFavorite() {
    var id = appState.activeRecipeId.toString();
    var key = appState.currentUser + '_favorites';
    var favs = JSON.parse(localStorage.getItem(key)) || [];
    if (favs.includes(id)) {
        favs = favs.filter(function (f) { return f !== id; });
        document.getElementById('fav-toggle-btn').innerText = "☆";
    } else {
        favs.push(id);
        document.getElementById('fav-toggle-btn').innerText = "★";
    }
    localStorage.setItem(key, JSON.stringify(favs));
}
function goBackToList() {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    renderRecipeList();
    nextScreen('list-screen');
}
function speakRecipe(title, desc, ingredients, steps) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    var text = title + ". " + desc + ". " + (appState.lang === 'en' ? 'Ingredients' : 'Bestanddele') + ": " + ingredients.join(', ') + ". " + (appState.lang === 'en' ? 'Method' : 'Metode') + ": " + steps.join('. ');
    var utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = appState.lang === 'en' ? 'en-US' : 'af-ZA';
    window.speechSynthesis.speak(utterance);
}
function triggerPrint() {
    window.print();
}
