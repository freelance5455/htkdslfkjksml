import { motivationQuotes } from './motivation-quotes.js';
import { motivationUi } from './motivation-i18n.js';
import { resetUi } from './reset-i18n.js';
import { calculatorUi } from './calculator-i18n.js';
import { periodUi } from './period-i18n.js';
import { demoUi } from './demo-i18n.js';
import { dailyBudgetTips } from './daily-tips.js';
import { localizedDailyBudgetTips, localizedDailyTipTitles } from './daily-tips-i18n.js';
import { privacyPolicy } from './privacy-policy.js';

const STORAGE_KEY = 'dagbudget-planner-v1';
const LANGUAGE_KEY = 'dagbudget-language-v1';
const NAME_CHOICE_KEY = 'dagbudget-name-choice-v1';
const locales = { nl: 'nl-NL', en: 'en-GB', de: 'de-DE', es: 'es-ES', fr: 'fr-FR', fy: 'fy-NL' };
const frisianWeekdays = ['snein', 'moandei', 'tiisdei', 'woansdei', 'tongersdei', 'freed', 'sneon'];
const translations = {
  nl: {
    title: 'Dagbudget', brandAria: 'Dagbudget start', menuOpen: 'Menu openen', menuClose: 'Menu sluiten', menuTitle: 'Menu', languageLabel: 'Taal / Language', developerInfo: 'Ontwikkelaarsinformatie', whatsappContact: 'Chat via WhatsApp', appearanceLabel: 'Uiterlijk wijzigen', themeNavy: 'Huidig (Navy)', themeBlack: 'Saai Zwart', themeDutch: 'Dutch', themeCandy: 'Snoepjes', themePaper: 'White Paper', periodMenuLabel: 'Huidige periode', instructionsMenu: 'Gebruiksaanwijzing', instructionsTitle: 'ℹ️ Hoe werkt deze app? (Heel simpel uitgelegd)', instructionsStep1: '• Stap 1: Vul het bedrag in dat je NU nog op je bankrekening hebt staan tot je volgende loon komt.', instructionsStep2: '• Stap 2: Trek hier de vaste lasten of kosten vanaf die DEZE MAAND nog van je rekening moeten worden afgeschreven (zoals je huur, abonnementen of rekeningen). Wat overblijft is je echte zakgeld.', instructionsTip: '• Tip van Jeroen: Haal hier alvast €100 of €150 extra vanaf voor onvoorziene kosten! Dan zit je altijd veilig.', instructionsStep3: '• Stap 3: Kies de datum waarop je volgende loonstrook of inkomen binnenkomt.', instructionsStep4: '• Stap 4: Vul vanaf nu elke dag eerlijk in wat je uitgeeft. De app rekent direct uit wat je vanaf NU per dag mag uitgeven om de maand perfect te halen!', instructionsDisclaimerTitle: '⚠️ Disclaimer:', instructionsDisclaimer: 'Dit is een hulpmiddel om je te helpen met budgetteren. Er kunnen geen rechten aan de berekeningen worden ontleend. Pas goed op je eigen portemonnee!', instructionsClose: 'Sluiten',
    rewardsLabel: 'Beloningen', rewardKicker: 'DAGELIJKSE REEKS', progressLabel: 'Voortgang naar volgende medaille', noneHeading: 'Op weg naar Brons...', noneDetail: 'Open de app elke dag om je eerste medaille te verdienen.', bronzeHeading: 'Brons behaald', bronzeDetail: 'Nog {days} dagen tot Zilver.', bronzeProjectionDetail: 'Een prognose van €0 of hoger is nodig voor Zilver en Goud.', silverHeading: 'Zilver behaald', silverDetail: 'Nog {days} dagen tot Goud (Premium).', goldHeading: 'Goud behaald · Premium', goldDetail: 'Je hebt de Premium-status verdiend.', streakUnitOne: 'dag op rij', streakUnitMany: 'dagen op rij', bronzeMark: 'B', silverMark: 'Z', goldMark: 'G', degradationNotice: 'Je hebt 1 dag overgeslagen en bent teruggevallen naar een lagere status. Start vandaag een nieuwe reeks!', dismissNotice: 'Melding sluiten', premiumUnlocked: 'PREMIUM ONTGRENDELD', goldCongrats: 'Gefeliciteerd! Je bent nu een Premium Gebruiker!', goldDescription: 'Dertig dagen op rij actief met een positieve prognose. Je gouden status is verdiend.', goldClose: 'Verder',
    periodDefault: 'Deze periode', periodPrefix: 'Tot ', eyebrow: 'JOUW GELD, TOT DE VOLGENDE LOONSTROOK', headingPrefix: 'Rust in je ', headingAccent: 'dagbudget.', introNote: 'Pas je budget aan en houd grip op wat je vandaag kunt uitgeven.', dashboardLabel: 'Budgetoverzicht',
    startBudget: 'Startbudget deze maand', startBudgetHint: 'Wat je nog te besteden hebt tot je volgende inkomen.', incomeDate: 'Datum volgend inkomen', incomeDateHint: 'Je budgetperiode loopt tot deze datum.', daysLeft: 'Aantal dagen te gaan', daySingular: 'dag', dayPlural: 'dagen', daysFoot: 'tot je volgende inkomen',
    remainingBudget: 'Actueel resterend budget', remainingFoot: 'startbudget min je uitgaven', dailyBudget: 'Nieuw dagbudget vanaf nu', dailyFoot: 'per dag tot je inkomen', projectedAmount: 'Historisch verwacht over', projectionEmpty: 'op basis van je gemiddelde uitgaven', projectionAverage: 'gemiddeld {amount} per uitgave',
    expensesKicker: 'UITGAVEN', ledgerTitle: 'Logboek', entryOne: 'regel', entryMany: 'regels', clearLedger: 'Wis logboek', clearConfirm: 'Weet je zeker dat je alle uitgaven uit het logboek wilt wissen?', clearCancel: 'Annuleren', clearAction: 'Wissen', expenseDate: 'Datum', amountSpent: 'Bedrag uitgegeven', addExpense: 'Uitgave toevoegen', dateHeader: 'Datum', dayHeader: 'Dag', amountHeader: 'Bedrag', actionsHeader: 'Acties', emptyTitle: 'Nog geen uitgaven gelogd', emptyHint: 'Voeg hierboven je eerste uitgave toe.', totalSpent: 'Totaal uitgegeven', saveNote: 'Automatisch opgeslagen op dit apparaat',
    deleteExpense: 'Verwijder uitgave van ', expensePlaceholder: '0,00'
  },
  en: {
    title: 'Daily Budget', brandAria: 'Daily Budget home', menuOpen: 'Open menu', menuClose: 'Close menu', menuTitle: 'Menu', languageLabel: 'Language', developerInfo: 'Developer Info', whatsappContact: 'Chat via WhatsApp', appearanceLabel: 'Change Appearance', themeNavy: 'Current (Navy)', themeBlack: 'Minimalistic Black', themeDutch: 'Dutch', themeCandy: 'Candy', themePaper: 'White Paper', periodMenuLabel: 'Current period', instructionsMenu: 'Instructions', instructionsTitle: 'ℹ️ How does this app work? (A very simple explanation)', instructionsStep1: '• Step 1: Enter the amount currently left in your bank account until your next payday.', instructionsStep2: '• Step 2: Subtract any fixed bills or costs that still need to come out of your account THIS MONTH (such as rent, subscriptions, or bills). What remains is your real spending money.', instructionsTip: '• Jeroen’s tip: Set aside another €100 or €150 now for unexpected costs. That way, you have a safety cushion!', instructionsStep3: '• Step 3: Choose the date your next payslip or income arrives.', instructionsStep4: '• Step 4: From now on, honestly enter what you spend each day. The app immediately calculates how much you can spend per day from NOW to make it through the month!', instructionsDisclaimerTitle: '⚠️ Disclaimer:', instructionsDisclaimer: 'This tool can help you with budgeting. The calculations do not create any legal rights or claims. Please take good care of your money!', instructionsClose: 'Close',
    rewardsLabel: 'Rewards', rewardKicker: 'DAILY STREAK', progressLabel: 'Progress to next medal', noneHeading: 'On your way to Bronze...', noneDetail: 'Use the app every day to earn your first medal.', bronzeHeading: 'Bronze earned', bronzeDetail: '{days} more days to Silver.', bronzeProjectionDetail: 'A forecast of €0 or above is required for Silver and Gold.', silverHeading: 'Silver earned', silverDetail: '{days} more days to Gold (Premium).', goldHeading: 'Gold earned · Premium', goldDetail: 'You have earned Premium status.', streakUnitOne: 'day in a row', streakUnitMany: 'days in a row', bronzeMark: 'B', silverMark: 'S', goldMark: 'G', degradationNotice: 'You missed a day and dropped to a lower status. Start a new streak today!', dismissNotice: 'Dismiss notice', premiumUnlocked: 'PREMIUM UNLOCKED', goldCongrats: 'Congratulations! You are now a Premium User!', goldDescription: 'Thirty consecutive active days with a positive forecast. Your gold status is well earned.', goldClose: 'Continue',
    periodDefault: 'This period', periodPrefix: 'Until ', eyebrow: 'YOUR MONEY, UNTIL YOUR NEXT PAYDAY', headingPrefix: 'Feel in control of your ', headingAccent: 'daily budget.', introNote: 'Adjust your budget and stay on top of what you can spend today.', dashboardLabel: 'Budget overview',
    startBudget: 'Starting budget this month', startBudgetHint: 'What you have left to spend until your next income.', incomeDate: 'Next income date', incomeDateHint: 'Your budget period runs until this date.', daysLeft: 'Days remaining', daySingular: 'day', dayPlural: 'days', daysFoot: 'until your next income',
    remainingBudget: 'Current remaining budget', remainingFoot: 'starting budget minus expenses', dailyBudget: 'New daily budget from now', dailyFoot: 'per day until your income', projectedAmount: 'Historically expected to remain', projectionEmpty: 'based on your average expenses', projectionAverage: 'averaging {amount} per expense',
    expensesKicker: 'EXPENSES', ledgerTitle: 'Ledger', entryOne: 'entry', entryMany: 'entries', clearLedger: 'Clear ledger', clearConfirm: 'Are you sure you want to clear all expenses from the ledger?', clearCancel: 'Cancel', clearAction: 'Clear', expenseDate: 'Date', amountSpent: 'Amount spent', addExpense: 'Add expense', dateHeader: 'Date', dayHeader: 'Day', amountHeader: 'Amount', actionsHeader: 'Actions', emptyTitle: 'No expenses logged yet', emptyHint: 'Add your first expense above.', totalSpent: 'Total spent', saveNote: 'Automatically saved on this device',
    deleteExpense: 'Delete expense from ', expensePlaceholder: '0.00'
  },
  de: {
    title: 'Tagesbudget', brandAria: 'Tagesbudget Startseite', menuOpen: 'Menü öffnen', menuClose: 'Menü schließen', menuTitle: 'Menü', languageLabel: 'Sprache / Language', developerInfo: 'Entwicklerinfos', whatsappContact: 'Per WhatsApp chatten', appearanceLabel: 'Erscheinungsbild ändern', themeNavy: 'Aktuell (Navy)', themeBlack: 'Minimalistisches Schwarz', themeDutch: 'Niederlande', themeCandy: 'Candy', themePaper: 'White Paper', periodMenuLabel: 'Aktueller Zeitraum', instructionsMenu: 'Bedienungsanleitung', instructionsTitle: 'ℹ️ Wie funktioniert diese App? (Ganz einfach erklärt)', instructionsStep1: '• Schritt 1: Gib den Betrag ein, der bis zu deinem nächsten Gehalt noch auf deinem Bankkonto ist.', instructionsStep2: '• Schritt 2: Ziehe alle festen Ausgaben und Kosten ab, die diesen MONAT noch von deinem Konto abgebucht werden (zum Beispiel Miete, Abos oder Rechnungen). Was übrig bleibt, ist dein wirklich verfügbares Geld.', instructionsTip: '• Jeroens Tipp: Ziehe schon jetzt zusätzlich 100 oder 150 € für unerwartete Kosten ab. So bist du auf der sicheren Seite!', instructionsStep3: '• Schritt 3: Wähle das Datum, an dem dein nächstes Gehalt oder Einkommen eingeht.', instructionsStep4: '• Schritt 4: Trage ab jetzt jeden Tag ehrlich ein, was du ausgibst. Die App berechnet sofort, wie viel du ab JETZT pro Tag ausgeben kannst, damit dein Geld den ganzen Monat reicht!', instructionsDisclaimerTitle: '⚠️ Haftungsausschluss:', instructionsDisclaimer: 'Dieses Hilfsmittel unterstützt dich bei der Budgetplanung. Aus den Berechnungen lassen sich keine Rechtsansprüche ableiten. Pass gut auf dein Geld auf!', instructionsClose: 'Schließen',
    rewardsLabel: 'Belohnungen', rewardKicker: 'TÄGLICHE SERIE', progressLabel: 'Fortschritt zur nächsten Medaille', noneHeading: 'Auf dem Weg zu Bronze...', noneDetail: 'Nutze die App täglich, um deine erste Medaille zu verdienen.', bronzeHeading: 'Bronze erreicht', bronzeDetail: 'Noch {days} Tage bis Silber.', bronzeProjectionDetail: 'Für Silber und Gold ist eine Prognose von mindestens 0 € erforderlich.', silverHeading: 'Silber erreicht', silverDetail: 'Noch {days} Tage bis Gold (Premium).', goldHeading: 'Gold erreicht · Premium', goldDetail: 'Du hast den Premium-Status verdient.', streakUnitOne: 'Tag in Folge', streakUnitMany: 'Tage in Folge', bronzeMark: 'B', silverMark: 'S', goldMark: 'G', degradationNotice: 'Du hast einen Tag ausgelassen und bist auf einen niedrigeren Status zurückgefallen. Starte heute eine neue Serie!', dismissNotice: 'Meldung schließen', premiumUnlocked: 'PREMIUM FREIGESCHALTET', goldCongrats: 'Glückwunsch! Du bist jetzt Premium-Nutzer!', goldDescription: 'Dreißig aktive Tage in Folge mit positiver Prognose. Dein Gold-Status ist verdient.', goldClose: 'Weiter',
    periodDefault: 'Dieser Zeitraum', periodPrefix: 'Bis ', eyebrow: 'DEIN GELD BIS ZUM NÄCHSTEN GEHALT', headingPrefix: 'Mehr Ruhe beim ', headingAccent: 'Tagesbudget.', introNote: 'Passe dein Budget an und behalte deine heutigen Ausgaben im Blick.', dashboardLabel: 'Budgetübersicht',
    startBudget: 'Startbudget in diesem Monat', startBudgetHint: 'Was dir bis zum nächsten Einkommen noch zur Verfügung steht.', incomeDate: 'Datum des nächsten Einkommens', incomeDateHint: 'Dein Budgetzeitraum läuft bis zu diesem Datum.', daysLeft: 'Verbleibende Tage', daySingular: 'Tag', dayPlural: 'Tage', daysFoot: 'bis zum nächsten Einkommen',
    remainingBudget: 'Aktuelles Restbudget', remainingFoot: 'Startbudget minus Ausgaben', dailyBudget: 'Neues Tagesbudget ab jetzt', dailyFoot: 'pro Tag bis zum Einkommen', projectedAmount: 'Voraussichtlicher Restbetrag', projectionEmpty: 'basierend auf deinen durchschnittlichen Ausgaben', projectionAverage: 'durchschnittlich {amount} pro Ausgabe',
    expensesKicker: 'AUSGABEN', ledgerTitle: 'Ausgabenliste', entryOne: 'Eintrag', entryMany: 'Einträge', clearLedger: 'Liste leeren', clearConfirm: 'Möchtest du wirklich alle Ausgaben aus der Liste löschen?', clearCancel: 'Abbrechen', clearAction: 'Löschen', expenseDate: 'Datum', amountSpent: 'Ausgegebener Betrag', addExpense: 'Ausgabe hinzufügen', dateHeader: 'Datum', dayHeader: 'Wochentag', amountHeader: 'Betrag', actionsHeader: 'Aktionen', emptyTitle: 'Noch keine Ausgaben erfasst', emptyHint: 'Füge oben deine erste Ausgabe hinzu.', totalSpent: 'Insgesamt ausgegeben', saveNote: 'Automatisch auf diesem Gerät gespeichert',
    deleteExpense: 'Ausgabe vom ', expensePlaceholder: '0,00'
  },
  es: {
    title: 'Presupuesto diario', brandAria: 'Inicio del presupuesto diario', menuOpen: 'Abrir menú', menuClose: 'Cerrar menú', menuTitle: 'Menú', languageLabel: 'Idioma / Language', developerInfo: 'Información del desarrollador', whatsappContact: 'Chatear por WhatsApp', appearanceLabel: 'Cambiar apariencia', themeNavy: 'Actual (Navy)', themeBlack: 'Negro minimalista', themeDutch: 'Holandés', themeCandy: 'Caramelo', themePaper: 'Papel blanco', periodMenuLabel: 'Período actual', instructionsMenu: 'Instrucciones', instructionsTitle: 'ℹ️ ¿Cómo funciona esta aplicación? (Muy fácil)', instructionsStep1: '• Paso 1: Introduce el dinero que te queda AHORA en la cuenta hasta que recibas tu próximo sueldo.', instructionsStep2: '• Paso 2: Resta los gastos fijos o pagos que todavía se cargarán en tu cuenta ESTE MES (como el alquiler, las suscripciones o las facturas). Lo que quede será tu dinero disponible de verdad.', instructionsTip: '• Consejo de Jeroen: Aparta ya 100 o 150 € más para imprevistos. ¡Así tendrás un margen de seguridad!', instructionsStep3: '• Paso 3: Elige la fecha en la que recibirás tu próxima nómina o ingreso.', instructionsStep4: '• Paso 4: A partir de ahora, apunta cada día con sinceridad lo que gastas. La aplicación calcula al instante cuánto puedes gastar al día desde AHORA para llegar bien a fin de mes.', instructionsDisclaimerTitle: '⚠️ Aviso:', instructionsDisclaimer: 'Esta herramienta te ayuda a organizar tu presupuesto. Los cálculos no generan derechos ni reclamaciones. ¡Cuida bien de tu dinero!', instructionsClose: 'Cerrar',
    rewardsLabel: 'Recompensas', rewardKicker: 'RACHA DIARIA', progressLabel: 'Progreso hacia la siguiente medalla', noneHeading: 'Camino al Bronce...', noneDetail: 'Usa la aplicación cada día para conseguir tu primera medalla.', bronzeHeading: 'Bronce conseguido', bronzeDetail: 'Te faltan {days} días para Plata.', bronzeProjectionDetail: 'Se necesita una previsión de 0 € o más para conseguir Plata y Oro.', silverHeading: 'Plata conseguida', silverDetail: 'Te faltan {days} días para Oro (Premium).', goldHeading: 'Oro conseguido · Premium', goldDetail: 'Has conseguido el estado Premium.', streakUnitOne: 'día seguido', streakUnitMany: 'días seguidos', bronzeMark: 'B', silverMark: 'P', goldMark: 'O', degradationNotice: 'Te has saltado un día y has bajado de nivel. ¡Empieza una nueva racha hoy!', dismissNotice: 'Cerrar aviso', premiumUnlocked: 'PREMIUM DESBLOQUEADO', goldCongrats: '¡Enhorabuena! ¡Ya eres usuario Premium!', goldDescription: 'Treinta días seguidos de actividad con una previsión positiva. Te has ganado el nivel Oro.', goldClose: 'Continuar',
    periodDefault: 'Este período', periodPrefix: 'Hasta el ', eyebrow: 'TU DINERO HASTA TU PRÓXIMO INGRESO', headingPrefix: 'Controla mejor tu ', headingAccent: 'presupuesto diario.', introNote: 'Ajusta tu presupuesto y controla lo que puedes gastar hoy.', dashboardLabel: 'Resumen del presupuesto',
    startBudget: 'Presupuesto inicial de este mes', startBudgetHint: 'Lo que te queda para gastar hasta tu próximo ingreso.', incomeDate: 'Fecha del próximo ingreso', incomeDateHint: 'Tu período de presupuesto termina en esta fecha.', daysLeft: 'Días restantes', daySingular: 'día', dayPlural: 'días', daysFoot: 'hasta tu próximo ingreso',
    remainingBudget: 'Presupuesto restante actual', remainingFoot: 'presupuesto inicial menos gastos', dailyBudget: 'Nuevo presupuesto diario desde ahora', dailyFoot: 'al día hasta tu próximo ingreso', projectedAmount: 'Saldo restante estimado', projectionEmpty: 'según el promedio de tus gastos', projectionAverage: 'una media de {amount} por gasto',
    expensesKicker: 'GASTOS', ledgerTitle: 'Registro', entryOne: 'registro', entryMany: 'registros', clearLedger: 'Vaciar registro', clearConfirm: '¿Seguro que quieres borrar todos los gastos del registro?', clearCancel: 'Cancelar', clearAction: 'Borrar', expenseDate: 'Fecha', amountSpent: 'Importe gastado', addExpense: 'Añadir gasto', dateHeader: 'Fecha', dayHeader: 'Día', amountHeader: 'Importe', actionsHeader: 'Acciones', emptyTitle: 'Todavía no hay gastos registrados', emptyHint: 'Añade tu primer gasto arriba.', totalSpent: 'Total gastado', saveNote: 'Se guarda automáticamente en este dispositivo',
    deleteExpense: 'Eliminar gasto del ', expensePlaceholder: '0,00'
  },
  fr: {
    title: 'Budget quotidien', brandAria: 'Accueil du budget quotidien', menuOpen: 'Ouvrir le menu', menuClose: 'Fermer le menu', menuTitle: 'Menu', languageLabel: 'Langue / Language', developerInfo: 'Infos développeur', whatsappContact: 'Discuter sur WhatsApp', appearanceLabel: 'Changer l’apparence', themeNavy: 'Actuel (Navy)', themeBlack: 'Noir minimaliste', themeDutch: 'Pays-Bas', themeCandy: 'Bonbon', themePaper: 'Papier blanc', periodMenuLabel: 'Période actuelle', instructionsMenu: 'Instructions', instructionsTitle: 'ℹ️ Comment fonctionne cette application ? (Très simple)', instructionsStep1: '• Étape 1 : Indiquez la somme qu’il vous reste MAINTENANT sur votre compte jusqu’à votre prochain salaire.', instructionsStep2: '• Étape 2 : Déduisez les charges fixes et dépenses qui seront encore prélevées sur votre compte CE MOIS-CI (loyer, abonnements ou factures, par exemple). Le montant restant est votre véritable argent disponible.', instructionsTip: '• Le conseil de Jeroen : mettez dès maintenant 100 ou 150 € de côté pour les imprévus. Vous aurez ainsi une marge de sécurité !', instructionsStep3: '• Étape 3 : Choisissez la date de votre prochain salaire ou revenu.', instructionsStep4: '• Étape 4 : À partir de maintenant, notez honnêtement vos dépenses chaque jour. L’application calcule aussitôt combien vous pouvez dépenser par jour dès MAINTENANT pour tenir jusqu’à la fin du mois !', instructionsDisclaimerTitle: '⚠️ Avertissement :', instructionsDisclaimer: 'Cet outil vous aide à gérer votre budget. Les calculs ne donnent lieu à aucun droit ni recours. Prenez soin de votre argent !', instructionsClose: 'Fermer',
    rewardsLabel: 'Récompenses', rewardKicker: 'SÉRIE QUOTIDIENNE', progressLabel: 'Progression vers la prochaine médaille', noneHeading: 'En route vers le bronze...', noneDetail: 'Utilisez l’application chaque jour pour gagner votre première médaille.', bronzeHeading: 'Médaille de bronze obtenue', bronzeDetail: 'Encore {days} jours avant l’argent.', bronzeProjectionDetail: 'Une prévision supérieure ou égale à 0 € est requise pour l’argent et l’or.', silverHeading: 'Médaille d’argent obtenue', silverDetail: 'Encore {days} jours avant l’or (Premium).', goldHeading: 'Médaille d’or · Premium', goldDetail: 'Vous avez obtenu le statut Premium.', streakUnitOne: 'jour de suite', streakUnitMany: 'jours de suite', bronzeMark: 'B', silverMark: 'A', goldMark: 'O', degradationNotice: 'Vous avez manqué un jour et êtes passé à un statut inférieur. Commencez une nouvelle série dès aujourd’hui !', dismissNotice: 'Fermer le message', premiumUnlocked: 'PREMIUM DÉBLOQUÉ', goldCongrats: 'Félicitations ! Vous êtes maintenant un utilisateur Premium !', goldDescription: 'Trente jours actifs consécutifs avec une prévision positive. Votre statut Or est mérité.', goldClose: 'Continuer',
    periodDefault: 'Cette période', periodPrefix: 'Jusqu’au ', eyebrow: 'VOTRE ARGENT JUSQU’AU PROCHAIN REVENU', headingPrefix: 'Gardez le contrôle de votre ', headingAccent: 'budget quotidien.', introNote: 'Ajustez votre budget et gardez un œil sur vos dépenses du jour.', dashboardLabel: 'Aperçu du budget',
    startBudget: 'Budget de départ ce mois-ci', startBudgetHint: 'Ce qu’il vous reste à dépenser jusqu’à votre prochain revenu.', incomeDate: 'Date du prochain revenu', incomeDateHint: 'Votre période budgétaire se termine à cette date.', daysLeft: 'Jours restants', daySingular: 'jour', dayPlural: 'jours', daysFoot: 'jusqu’à votre prochain revenu',
    remainingBudget: 'Budget restant actuel', remainingFoot: 'budget de départ moins les dépenses', dailyBudget: 'Nouveau budget quotidien dès maintenant', dailyFoot: 'par jour jusqu’à votre revenu', projectedAmount: 'Solde restant estimé', projectionEmpty: 'selon la moyenne de vos dépenses', projectionAverage: 'en moyenne {amount} par dépense',
    expensesKicker: 'DÉPENSES', ledgerTitle: 'Journal', entryOne: 'entrée', entryMany: 'entrées', clearLedger: 'Effacer le journal', clearConfirm: 'Voulez-vous vraiment effacer toutes les dépenses du journal ?', clearCancel: 'Annuler', clearAction: 'Effacer', expenseDate: 'Date', amountSpent: 'Montant dépensé', addExpense: 'Ajouter une dépense', dateHeader: 'Date', dayHeader: 'Jour', amountHeader: 'Montant', actionsHeader: 'Actions', emptyTitle: 'Aucune dépense enregistrée', emptyHint: 'Ajoutez votre première dépense ci-dessus.', totalSpent: 'Total dépensé', saveNote: 'Enregistré automatiquement sur cet appareil',
    deleteExpense: 'Supprimer la dépense du ', expensePlaceholder: '0,00'
  },
  fy: {
    title: 'Deibudzjet', brandAria: 'Startside fan Deibudzjet', menuOpen: 'Menu iepenje', menuClose: 'Menu slute', menuTitle: 'Menu', languageLabel: 'Taal', developerInfo: 'Untwikkelersynfo', whatsappContact: 'Petear fia WhatsApp', appearanceLabel: 'Uterlik feroarje', themeNavy: 'Aktueel (Navy)', themeBlack: 'Swart minimalistysk', themeDutch: 'Dutch', themeCandy: 'Snoep', themePaper: 'Wyt papier', periodMenuLabel: 'Dizze perioade', instructionsMenu: 'Ynstruksjes', instructionsTitle: 'ℹ️ Hoe wurket dizze app? (Hiel ienfâldich útlein)', instructionsStep1: '• Stap 1: Folje yn hoefolle jild oft der NO noch op dyn bankrekken stiet oant dyn folgjende lean binnenkomt.', instructionsStep2: '• Stap 2: Helje de fêste lêsten en kosten derôf dy’t DIZZE MOANNE noch fan dyn rekken ôfskreaun wurde (lykas hier, abonneminten of rekkens). Wat oerbliuwt is dyn echte frij te besteegjen jild.', instructionsTip: '• Tip fan Jeroen: Helje der no alfêst €100 of €150 ekstra ôf foar ûnferwachte kosten. Dan hast altyd in feilichheidsmarge!', instructionsStep3: '• Stap 3: Kies de datum dat dyn folgjende lean of ynkommen binnenkomt.', instructionsStep4: '• Stap 4: Folje fan no ôf alle dagen earlik yn watst útjoust. De app berekkenet fuort hoefolle oftst fan NO ôf deis útjaan kinst om de moanne goed troch te kommen!', instructionsDisclaimerTitle: '⚠️ Disclaimer:', instructionsDisclaimer: 'Dit is in helpmiddel foar it plannen fan dyn budzjet. Oan de berekkeningen kinst gjin rjochten ûntliene. Pas goed op dyn jild!', instructionsClose: 'Slute',
    rewardsLabel: 'Beleanningen', rewardKicker: 'DEISTICHE RIGE', progressLabel: 'Foarútgong nei de folgjende medalje', noneHeading: 'Op wei nei Brûns...', noneDetail: 'Brûk de app alle dagen om dyn earste medalje te fertsjinjen.', bronzeHeading: 'Brûns fertsjinne', bronzeDetail: 'Noch {days} dagen oant Sulver.', bronzeProjectionDetail: 'In prognose fan €0 of heger is nedich foar Sulver en Goud.', silverHeading: 'Sulver fertsjinne', silverDetail: 'Noch {days} dagen oant Goud (Premium).', goldHeading: 'Goud fertsjinne · Premium', goldDetail: 'Do hast de Premium-status fertsjinne.', streakUnitOne: 'dei efterinoar', streakUnitMany: 'dagen efterinoar', bronzeMark: 'B', silverMark: 'S', goldMark: 'G', degradationNotice: 'Do hast ien dei oerslein en bist weromfallen nei in legere status. Begjin hjoed in nije rige!', dismissNotice: 'Melding slute', premiumUnlocked: 'PREMIUM ÛNTSLUTEN', goldCongrats: 'Lokwinske! Do bist no in Premium-brûker!', goldDescription: 'Tritich dagen aktyf efterinoar mei in positive prognose. Do hast dyn gouden status fertsjinne.', goldClose: 'Fierder',
    periodDefault: 'Dizze perioade', periodPrefix: 'Oant ', eyebrow: 'JOU JILD OANT DYN FOLGJENDE YNKOMST', headingPrefix: 'Mear rêst yn dyn ', headingAccent: 'deibudzjet.', introNote: 'Pas dyn budzjet oan en hâld yn de gaten watst hjoed útjaan kinst.', dashboardLabel: 'Budzjetoersjoch',
    startBudget: 'Startbudzjet dizze moanne', startBudgetHint: 'Watst oant dyn folgjende ynkommen noch útjaan kinst.', incomeDate: 'Datum fan dyn folgjende ynkommen', incomeDateHint: 'Dyn budzjetperioade rint oant dizze datum.', daysLeft: 'Dagen oer', daySingular: 'dei', dayPlural: 'dagen', daysFoot: 'oant dyn folgjende ynkommen',
    remainingBudget: 'Aktueel oerbleaun budzjet', remainingFoot: 'startbudzjet min de útjeften', dailyBudget: 'Nij deibudzjet fan no ôf', dailyFoot: 'deis oant dyn ynkommen', projectedAmount: 'Histoarysk ferwachte oer', projectionEmpty: 'op basis fan dyn gemiddelde útjeften', projectionAverage: 'gemiddeld {amount} de útjefte',
    expensesKicker: 'UTJEFTEN', ledgerTitle: 'Utjefteboek', entryOne: 'rigel', entryMany: 'rigels', clearLedger: 'Utjefteboek wiskje', clearConfirm: 'Bist wis datst alle útjeften út it boek wiskje wolst?', clearCancel: 'Ofbrekke', clearAction: 'Wiskje', expenseDate: 'Datum', amountSpent: 'Utjûn bedrach', addExpense: 'Utjefte tafoegje', dateHeader: 'Datum', dayHeader: 'Dei', amountHeader: 'Bedrach', actionsHeader: 'Aksjes', emptyTitle: 'Noch gjin útjeften fêstlein', emptyHint: 'Foegje hjirboppe dyn earste útjefte ta.', totalSpent: 'Totaal útjûn', saveNote: 'Automatysk opslein op dit apparaat', deleteExpense: 'Utjefte wiskje fan ', expensePlaceholder: '0,00'
  }
};
Object.entries(motivationUi).forEach(([language, labels]) => Object.assign(translations[language], labels));
Object.entries(resetUi).forEach(([language, labels]) => Object.assign(translations[language], labels));
Object.entries(calculatorUi).forEach(([language, labels]) => Object.assign(translations[language], {
  calculatorMenu: labels.menu, calculatorTitle: labels.title, calculatorIncome: labels.income,
  calculatorExpenses: labels.expenses, calculatorTotalIncome: labels.totalIncome,
  calculatorTotalExpenses: labels.totalExpenses, calculatorRemainder: labels.remainder,
  calculatorClose: labels.close, calculatorApply: labels.apply
}));
Object.entries(periodUi).forEach(([language, labels]) => Object.assign(translations[language], labels));
Object.entries(demoUi).forEach(([language, labels]) => Object.assign(translations[language], labels));
const $ = (selector) => document.querySelector(selector);
const startBudgetInput = $('#start-budget');
const incomeDateInput = $('#income-date');
const expenseDateInput = $('#expense-date');
const expenseAmountInput = $('#expense-amount');
const expenseRows = $('#expense-rows');
const emptyState = $('#empty-state');
const projectionCard = $('#projection-card');
const menuToggle = $('#menu-toggle');
$('#whatsapp-contact').addEventListener('click', (event) => {
  event.preventDefault();
  event.stopPropagation();
  window.open('https://wa.me/31684418895', '_blank');
}, true);
const menuDialog = $('#app-menu');
const instructionsDialog = $('#instructions-dialog');
const privacyDialog = $('#privacy-dialog');
const resetDialog = $('#reset-dialog');
const clearLedgerDialog = $('#clear-ledger-dialog');
const calculatorDialog = $('#calculator-dialog');
const periodConfirmDialog = $('#period-confirm-dialog');
const historyDialog = $('#history-dialog');
const demoDialog = $('#demo-dialog');
const futureButton = $('#open-future');
const nameDialog = $('#name-dialog');
const motivationDialog = $('#motivation-dialog');
const firstNameInput = $('#first-name');
const languageSelect = $('#language-select');
const themeSelect = $('#theme-select');
let nameChoice = loadNameChoice();
let currentProjection = 0;
let spendingRange = 'sixMonths';
let previousQuoteIndex = -1;
const CALCULATOR_KEY = 'dagbudget-start-calculator-v1';
const calculatorIncomeIds = ['salary', 'housingBenefit', 'healthBenefit', 'otherIncome', 'childBenefit', 'pensionBenefits'];
const calculatorExpenseIds = ['rent', 'healthInsurance', 'energy', 'water', 'municipalTax', 'carCosts', 'transport', 'internetTv', 'mobile', 'streaming', 'groceries', 'homeInsurance', 'savings', 'gym', 'clothing', 'childcare', 'studentLoan', 'otherSubscriptions', 'loans', 'pets', 'homeRepairs', 'householdGoods', 'medicalDental', 'education', 'carMaintenance', 'bankFees', 'personalCare', 'supportPaid', 'holidayFund', 'diningOut', 'leisureCulture', 'giftsDonations', 'other1', 'other2', 'other3', 'other4', 'other5'];
function loadCalculatorState() {
  try {
    const saved = JSON.parse(localStorage.getItem(CALCULATOR_KEY));
    return { amounts: saved?.amounts && typeof saved.amounts === 'object' ? saved.amounts : {}, names: saved?.names && typeof saved.names === 'object' ? saved.names : {} };
  } catch { return { amounts: {}, names: {} }; }
}
let calculatorState = loadCalculatorState();
const HISTORY_KEY = 'saldogrip_historie';
function loadHistory() {
  try {
    const saved = JSON.parse(localStorage.getItem(HISTORY_KEY));
    return Array.isArray(saved) ? saved.filter((item) => item && /^\d{4}-\d{2}-\d{2}$/.test(item.startDate) && /^\d{4}-\d{2}-\d{2}$/.test(item.endDate) && Number.isFinite(Number(item.startBudget)) && Number.isFinite(Number(item.result))) : [];
  } catch { return []; }
}
let periodHistory = loadHistory();
function saveHistory() {
  try { localStorage.setItem(HISTORY_KEY, JSON.stringify(periodHistory)); }
  catch (error) { console.warn('De periodehistorie kon niet worden opgeslagen.', error); }
}
function saveCalculatorState() {
  try { localStorage.setItem(CALCULATOR_KEY, JSON.stringify(calculatorState)); }
  catch (error) { console.warn('De calculatorgegevens konden niet worden opgeslagen.', error); }
}
function renderCalculatorFields() {
  const labels = calculatorUi[currentLanguage];
  const renderField = (id, label, editable = false) => `<div class="calculator-field"><span>${editable ? `<input class="calculator-custom-name" data-calculator-name="${id}" maxlength="50" value="${escapeHtml(calculatorState.names[id] || label)}" aria-label="${escapeHtml(label)}">` : escapeHtml(label)}</span><span class="calculator-amount"><span aria-hidden="true">€</span><input type="number" min="0" step="0.01" inputmode="decimal" data-calculator-amount="${id}" value="${escapeHtml(calculatorState.amounts[id] || '')}" aria-label="${escapeHtml(calculatorState.names[id] || label)}"></span></div>`;
  $('#calculator-income-fields').innerHTML = calculatorIncomeIds.map((id, i) => renderField(id, labels.incomeFields[i])).join('');
  $('#calculator-expense-fields').innerHTML = calculatorExpenseIds.map((id, i) => renderField(id, i < 32 ? labels.expenseFields[i] : `${labels.other} ${i - 31}`, i >= 32)).join('');
  updateCalculatorTotals();
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[character]); }
function updateCalculatorTotals() {
  const total = (ids) => ids.reduce((sum, id) => sum + (Number(calculatorState.amounts[id]) || 0), 0);
  const income = total(calculatorIncomeIds);
  const expenses = total(calculatorExpenseIds);
  const format = (amount) => new Intl.NumberFormat(locales[currentLanguage], { style: 'currency', currency: 'EUR' }).format(amount);
  $('#calculator-income-total').textContent = format(income);
  $('#calculator-expense-total').textContent = format(expenses);
  $('#calculator-result').textContent = format(income - expenses);
}

function loadNameChoice() {
  try {
    const saved = JSON.parse(localStorage.getItem(NAME_CHOICE_KEY));
    return saved && saved.complete === true ? { complete: true, name: typeof saved.name === 'string' ? saved.name : '' } : { complete: false, name: '' };
  } catch {
    return { complete: false, name: '' };
  }
}

function saveNameChoice(name) {
  nameChoice = { complete: true, name: name.trim() };
  try {
    localStorage.setItem(NAME_CHOICE_KEY, JSON.stringify(nameChoice));
  } catch (error) {
    console.warn('De naamvoorkeur kon niet worden opgeslagen.', error);
  }
}

function localDateString(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return year + '-' + month + '-' + day;
}

function monthEndString(date = new Date()) {
  return localDateString(new Date(date.getFullYear(), date.getMonth() + 1, 0));
}

function monthStartString(date = new Date()) {
  return localDateString(new Date(date.getFullYear(), date.getMonth(), 1));
}

function parseDate(value) {
  if (!value) return null;
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day);
}

function calendarDaysBetween(from, to) {
  const start = Date.UTC(from.getFullYear(), from.getMonth(), from.getDate());
  const end = Date.UTC(to.getFullYear(), to.getMonth(), to.getDate());
  return Math.max(0, Math.ceil((end - start) / 86400000));
}

function loadLanguage() {
  try {
    const savedLanguage = localStorage.getItem(LANGUAGE_KEY);
    return Object.prototype.hasOwnProperty.call(translations, savedLanguage) ? savedLanguage : 'nl';
  } catch {
    return 'nl';
  }
}

let currentLanguage = loadLanguage();
const THEME_KEY = 'dagbudget-theme-v1';
const themeNames = ['navy', 'black', 'dutch', 'candy', 'paper'];

function loadTheme() {
  try {
    const savedTheme = localStorage.getItem(THEME_KEY);
    return themeNames.includes(savedTheme) ? savedTheme : 'navy';
  } catch {
    return 'navy';
  }
}

let currentTheme = loadTheme();

function applyTheme() {
  document.documentElement.classList.remove(...themeNames.map((theme) => 'theme-' + theme));
  document.documentElement.classList.add('theme-' + currentTheme);
  themeSelect.value = currentTheme;
  const colors = { navy: '#080e1b', black: '#000000', dutch: '#071b45', candy: '#311342', paper: '#f4f5f7' };
  document.querySelector('meta[name="theme-color"]').content = colors[currentTheme];
}

function saveState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch (error) {
    console.warn('Lokale budgetgegevens konden niet worden opgeslagen.', error);
    return false;
  }
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (saved && typeof saved === 'object') {
      return {
        budget: Number.isFinite(Number(saved.budget)) ? String(saved.budget) : '500',
        periodStart: /^\d{4}-\d{2}-\d{2}$/.test(saved.periodStart || '') ? saved.periodStart : monthStartString(),
        incomeDate: /^\d{4}-\d{2}-\d{2}$/.test(saved.incomeDate || '') ? saved.incomeDate : monthEndString(),
        expenses: Array.isArray(saved.expenses) ? saved.expenses.filter((item) => item && /^\d{4}-\d{2}-\d{2}$/.test(item.date) && Number.isFinite(Number(item.amount)) && Number(item.amount) > 0) : []
      };
    }
  } catch (error) {
    console.warn('Lokale budgetgegevens konden niet worden gelezen.', error);
  }
  return { budget: '500', periodStart: monthStartString(), incomeDate: monthEndString(), expenses: [] };
}

let state = loadState();
const REWARD_KEY = 'dagbudget-rewards-v1';
let dailyTipDismissTimer;

function dismissDailyTip() {
  const notice = $('#daily-tip-notice');
  clearTimeout(dailyTipDismissTimer);
  notice.classList.remove('is-visible');
  notice.setAttribute('aria-hidden', 'true');
}

function updateDailyTipCopy() {
  const now = new Date();
  const dateId = Number(`${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`);
  const index = dateId % dailyBudgetTips.length;
  const name = nameChoice.name.trim();
  const titles = localizedDailyTipTitles[currentLanguage] || localizedDailyTipTitles.nl;
  $('#daily-tip-title').textContent = name ? titles.withName.replace('{name}', name) : titles.withoutName;
  $('#daily-tip-text').textContent = (localizedDailyBudgetTips[currentLanguage] || dailyBudgetTips)[index];
}

function showDailyTip() {
  updateDailyTipCopy();
  const notice = $('#daily-tip-notice');
  clearTimeout(dailyTipDismissTimer);
  notice.setAttribute('aria-hidden', 'false');
  notice.classList.remove('is-visible');
  requestAnimationFrame(() => notice.classList.add('is-visible'));
  dailyTipDismissTimer = setTimeout(dismissDailyTip, 10000);
}

function loadRewardState() {
  try {
    const saved = JSON.parse(localStorage.getItem(REWARD_KEY));
    if (saved && typeof saved === 'object') {
      return {
        lastActiveDate: /^\d{4}-\d{2}-\d{2}$/.test(saved.lastActiveDate || '') ? saved.lastActiveDate : null,
        streak: Number.isInteger(saved.streak) && saved.streak > 0 ? saved.streak : 0,
        tier: ['none', 'bronze', 'silver', 'gold'].includes(saved.tier) ? saved.tier : 'none',
        goldCelebrated: saved.goldCelebrated === true,
        degradationNotice: saved.degradationNotice === true
      };
    }
  } catch (error) {
    console.warn('De medaillevoortgang kon niet worden gelezen.', error);
  }
  return { lastActiveDate: null, streak: 0, tier: 'none', goldCelebrated: false, degradationNotice: false };
}

let rewardState = loadRewardState();

function saveRewardState() {
  try {
    localStorage.setItem(REWARD_KEY, JSON.stringify(rewardState));
  } catch (error) {
    console.warn('De medaillevoortgang kon niet worden opgeslagen.', error);
  }
}

function registerDailyUse() {
  const today = localDateString(new Date());
  if (rewardState.lastActiveDate === today) return;
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  if (rewardState.lastActiveDate === localDateString(yesterday)) {
    rewardState.streak += 1;
  } else {
    if (rewardState.lastActiveDate && today > rewardState.lastActiveDate && rewardState.streak > 0) rewardState.degradationNotice = true;
    rewardState.streak = 1;
  }
  rewardState.lastActiveDate = today;
  saveRewardState();
}

registerDailyUse();

function renderRewards(projected) {
  const text = translations[currentLanguage];
  let tier = 'none';
  if (rewardState.streak >= 30 && projected >= 0) tier = 'gold';
  else if (rewardState.streak >= 10 && projected >= 0) tier = 'silver';
  else if (rewardState.streak >= 5) tier = 'bronze';

  const rewardCard = $('#reward-card');
  rewardCard.dataset.tier = tier;
  document.documentElement.classList.toggle('is-premium', tier === 'gold');
  $('#streak-count').textContent = String(rewardState.streak);
  $('#streak-unit').textContent = rewardState.streak === 1 ? text.streakUnitOne : text.streakUnitMany;
  $('#medal-symbol').textContent = tier === 'none' ? '•' : text[tier + 'Mark'];
  $('#reward-heading').textContent = text[tier + 'Heading'];
  let detail = text[tier + 'Detail'];
  if (tier === 'bronze') {
    detail = rewardState.streak >= 10 && projected < 0
      ? text.bronzeProjectionDetail
      : detail.replace('{days}', String(10 - rewardState.streak));
  } else if (tier === 'silver') {
    detail = detail.replace('{days}', String(30 - rewardState.streak));
  }
  $('#reward-detail').textContent = detail;
  $('#degradation-notice').hidden = !rewardState.degradationNotice;
  const nextMilestone = tier === 'none' ? 5 : tier === 'bronze' ? 10 : 30;
  const progress = tier === 'gold' ? 100 : Math.min(100, Math.round(rewardState.streak / nextMilestone * 100));
  $('#reward-progress-fill').style.width = progress + '%';
  $('#reward-progress').setAttribute('aria-valuenow', String(progress));

  if (rewardState.tier !== tier) {
    rewardState.tier = tier;
    saveRewardState();
  }
  if (tier === 'gold' && !rewardState.goldCelebrated) {
    rewardState.goldCelebrated = true;
    saveRewardState();
    $('#gold-dialog').showModal();
  }
}

function applyTranslations() {
  const text = translations[currentLanguage];
  document.documentElement.lang = currentLanguage;
  document.title = text.title;
  document.querySelectorAll('[data-i18n]').forEach((element) => {
    element.textContent = text[element.dataset.i18n];
  });
  document.querySelectorAll('[data-i18n-aria-label]').forEach((element) => {
    element.setAttribute('aria-label', text[element.dataset.i18nAriaLabel]);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((element) => {
    element.placeholder = text[element.dataset.i18nPlaceholder];
  });
  renderCalculatorFields();
  $('#brand-link').setAttribute('aria-label', text.brandAria);
  $('#close-menu').setAttribute('aria-label', text.menuClose);
  $('#close-instructions-x').setAttribute('aria-label', text.instructionsClose);
  $('#close-future-x').setAttribute('aria-label', text.motivationClose);
  $('#open-calculator').setAttribute('aria-label', text.calculatorMenu);
  $('#open-calculator').title = text.calculatorMenu;
  $('#open-calculator').dataset.tooltip = text.helpTip;
  $('#close-calculator-x').setAttribute('aria-label', text.calculatorClose);
  $('#close-history-x').setAttribute('aria-label', text.historyClose);
  $('#close-period-x').setAttribute('aria-label', text.periodCancel);
  $('#history-chart-section').setAttribute('aria-label', text.historyChartLabel);
  $('#spending-ranges').setAttribute('aria-label', text.spendingRangeLabel);
  $('#close-demo-x').setAttribute('aria-label', text.demoCancel);
  expenseAmountInput.placeholder = text.expensePlaceholder;
  languageSelect.value = currentLanguage;
  applyPrivacyPolicyLanguage();
  if ($('#daily-tip-notice').getAttribute('aria-hidden') === 'false') updateDailyTipCopy();
}

function applyPrivacyPolicyLanguage() {
  const language = currentLanguage === 'nl' ? 'nl' : 'en';
  const policy = privacyPolicy[language];
  $('#privacy-menu-label').textContent = language === 'nl' ? 'Privacybeleid' : 'Privacy Policy';
  $('#privacy-title').textContent = policy.title;
  $('#close-privacy').textContent = language === 'nl' ? 'Sluiten' : 'Close';
  $('#close-privacy-x').setAttribute('aria-label', language === 'nl' ? 'Sluiten' : 'Close');
  $('#privacy-copy').innerHTML = `<p class="privacy-updated">${policy.updated}</p><p>${policy.intro}</p>${policy.sections.map((section) => `<section><h3>${section.title}</h3>${section.intro ? `<p>${section.intro}</p>` : ''}${section.bullets ? `<ul>${section.bullets.map((item) => `<li>${item}</li>`).join('')}</ul>` : `<p>${section.body}</p>`}</section>`).join('')}`;
}

function render() {
  const text = translations[currentLanguage];
  const locale = locales[currentLanguage];
  const currency = new Intl.NumberFormat(locale, { style: 'currency', currency: 'EUR' });
  const dateFormatter = new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'long', year: 'numeric' });
  const weekdayFormatter = new Intl.DateTimeFormat(locale, { weekday: 'long' });
  const budget = Number(state.budget) || 0;
  const totalSpent = state.expenses.reduce((sum, item) => sum + Number(item.amount), 0);
  const remaining = budget - totalSpent;
  const days = calendarDaysBetween(new Date(), parseDate(state.incomeDate) || new Date());
  const averageExpense = state.expenses.length ? totalSpent / state.expenses.length : 0;
  const dailyBudget = days > 0 ? remaining / days : 0;
  const projected = remaining - averageExpense * days;
  currentProjection = projected;
  const name = nameChoice.name.trim();
  const introNote = $('#top .intro-note');
  introNote.textContent = name
    ? `${name}, ${text.introNote.charAt(0).toLocaleLowerCase(locales[currentLanguage])}${text.introNote.slice(1)}`
    : text.introNote;
  $('#dashboard-greeting').textContent = name
    ? `Lekker op koers, ${name}! 💰✨`
    : 'Lekker op koers! 💰✨';

  $('#days-left').textContent = String(days);
  $('#days-unit').textContent = days === 1 ? text.daySingular : text.dayPlural;
  $('#days-foot').textContent = text.daysFoot;
  $('#remaining-budget').textContent = currency.format(remaining);
  $('#daily-budget').textContent = currency.format(dailyBudget);
  $('#projected-amount').textContent = currency.format(projected);
  $('#projection-foot').textContent = state.expenses.length ? text.projectionAverage.replace('{amount}', currency.format(averageExpense)) : text.projectionEmpty;
  projectionCard.classList.toggle('is-negative', projected < 0);
  const periodText = state.incomeDate ? text.periodPrefix + dateFormatter.format(parseDate(state.incomeDate)) : text.periodDefault;
  $('#period-label').textContent = periodText;
  $('#drawer-period-label').textContent = periodText;
  $('#entry-count').textContent = state.expenses.length + ' ' + (state.expenses.length === 1 ? text.entryOne : text.entryMany);
  $('#ledger-total').textContent = currency.format(totalSpent);
  emptyState.hidden = state.expenses.length > 0;
  expenseRows.replaceChildren();

  [...state.expenses].sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id)).forEach((expense) => {
    const row = document.createElement('tr');
    const dateCell = document.createElement('td');
    const dayCell = document.createElement('td');
    const amountCell = document.createElement('td');
    const actionCell = document.createElement('td');
    const date = parseDate(expense.date);
    dateCell.textContent = dateFormatter.format(date);
    const weekday = currentLanguage === 'fy' ? frisianWeekdays[date.getDay()] : weekdayFormatter.format(date);
    dayCell.textContent = currentLanguage === 'en' ? weekday.charAt(0).toUpperCase() + weekday.slice(1) : weekday;
    amountCell.textContent = currency.format(Number(expense.amount));
    amountCell.className = 'expense-amount-cell';
    actionCell.className = 'delete-cell';
    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.className = 'delete-row';
    removeButton.textContent = '×';
    removeButton.setAttribute('aria-label', text.deleteExpense + dateFormatter.format(date));
    removeButton.addEventListener('click', () => {
      state.expenses = state.expenses.filter((item) => item.id !== expense.id);
      saveState();
      render();
    });
    actionCell.append(removeButton);
    row.append(dateCell, dayCell, amountCell, actionCell);
    expenseRows.append(row);
  });
  renderRewards(projected);
}

function renderFutureForecast() {
  const text = translations[currentLanguage];
  const name = nameChoice.name.trim();
  const currency = new Intl.NumberFormat(locales[currentLanguage], { style: 'currency', currency: 'EUR' });
  const milestones = [1, 2, 3, 6, 12, 24, 36];
  const forecastBase = periodHistory.length
    ? periodHistory.reduce((sum, period) => sum + Number(period.result), 0) / periodHistory.length
    : currentProjection;
  $('#monthly-growth').textContent = currency.format(forecastBase);
  const basisKey = periodHistory.length ? 'historyAverageBasis' : 'historyCurrentBasis';
  $('#forecast-basis').textContent = name
    ? text[basisKey + 'Named'].replace('{name}', () => name).replace('{count}', String(periodHistory.length))
    : text[basisKey].replace('{count}', String(periodHistory.length));
  const warning = $('#forecast-warning');
  warning.textContent = name ? text.negativeWarningNamed.replace('{name}', () => name) : text.negativeWarning;
  warning.hidden = forecastBase >= 0;
  const list = $('#forecast-list');
  list.replaceChildren();
  milestones.forEach((months, index) => {
    const row = document.createElement('li');
    const label = document.createElement('span');
    const amount = document.createElement('strong');
    label.textContent = text.months[index];
    amount.textContent = currency.format(forecastBase * months);
    row.append(label, amount);
    list.append(row);
  });
}

function renderHistory() {
  const labels = translations[currentLanguage];
  const locale = locales[currentLanguage];
  const currency = new Intl.NumberFormat(locale, { style: 'currency', currency: 'EUR' });
  const monthFormatter = new Intl.DateTimeFormat(locale, { month: 'short', year: 'numeric' });
  const empty = periodHistory.length === 0;
  $('#history-empty').hidden = !empty;
  $('#history-chart-section').hidden = empty;
  $('#history-table-wrap').hidden = empty;
  renderSpendingPattern(spendingRange);
  const rows = $('#history-rows');
  rows.replaceChildren();
  const chronological = [...periodHistory].sort((a, b) => a.endDate.localeCompare(b.endDate));
  [...chronological].reverse().forEach((period) => {
    const row = document.createElement('tr');
    const periodCell = document.createElement('td');
    const budgetCell = document.createElement('td');
    const resultCell = document.createElement('td');
    const date = parseDate(period.endDate);
    periodCell.textContent = monthFormatter.format(date);
    budgetCell.textContent = currency.format(Number(period.startBudget));
    resultCell.textContent = currency.format(Number(period.result));
    resultCell.className = Number(period.result) >= 0 ? 'history-positive' : 'history-negative';
    row.append(periodCell, budgetCell, resultCell);
    rows.append(row);
  });
  const chart = $('#history-chart');
  chart.replaceChildren();
  if (empty) return;
  const svgNs = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNs, 'svg');
  svg.setAttribute('viewBox', '0 0 760 250');
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', labels.historyTitle);
  const values = chronological.map((period) => Number(period.result));
  const minValue = Math.min(0, ...values);
  const maxValue = Math.max(0, ...values);
  const span = Math.max(1, maxValue - minValue);
  const x = (index) => values.length === 1 ? 380 : 56 + index * (650 / (values.length - 1));
  const y = (value) => 28 + ((maxValue - value) / span) * 156;
  const zeroLine = document.createElementNS(svgNs, 'line');
  zeroLine.setAttribute('x1', '45'); zeroLine.setAttribute('x2', '720');
  zeroLine.setAttribute('y1', String(y(0))); zeroLine.setAttribute('y2', String(y(0)));
  zeroLine.setAttribute('class', 'history-zero-line'); svg.append(zeroLine);
  if (values.length > 1) {
    const line = document.createElementNS(svgNs, 'polyline');
    line.setAttribute('points', values.map((value, index) => `${x(index)},${y(value)}`).join(' '));
    line.setAttribute('class', 'history-line'); svg.append(line);
  }
  chronological.forEach((period, index) => {
    const value = Number(period.result);
    const point = document.createElementNS(svgNs, 'circle');
    point.setAttribute('cx', String(x(index))); point.setAttribute('cy', String(y(value)));
    point.setAttribute('r', '5'); point.setAttribute('class', value >= 0 ? 'history-point-positive' : 'history-point-negative'); svg.append(point);
    const amount = document.createElementNS(svgNs, 'text');
    amount.setAttribute('x', String(x(index))); amount.setAttribute('y', String(Math.max(16, y(value) - 12)));
    amount.setAttribute('text-anchor', 'middle'); amount.setAttribute('class', 'history-chart-amount'); amount.textContent = currency.format(value); svg.append(amount);
    const month = document.createElementNS(svgNs, 'text');
    month.setAttribute('x', String(x(index))); month.setAttribute('y', '225'); month.setAttribute('text-anchor', 'middle'); month.setAttribute('class', 'history-chart-month');
    month.textContent = monthFormatter.format(parseDate(period.endDate)); svg.append(month);
  });
  chart.append(svg);
}

function renderSpendingPattern(range) {
  const labels = translations[currentLanguage];
  const name = nameChoice.name.trim();
  $('#spending-philosophy').textContent = name
    ? `Houd grip, ${name}! Als je VANDAAG minder uitgeeft, bouw je ruimte op voor morgen.`
    : 'Houd grip! Als je VANDAAG minder uitgeeft, bouw je ruimte op voor morgen.';
  const locale = locales[currentLanguage];
  const currency = new Intl.NumberFormat(locale, { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const rangeStart = new Date(today);
  if (range === '14days') rangeStart.setDate(rangeStart.getDate() - 13);
  else if (range === 'month') rangeStart.setDate(1);
  else if (range === 'sixMonths') rangeStart.setMonth(rangeStart.getMonth() - 5, 1);
  else rangeStart.setMonth(rangeStart.getMonth() - 11, 1);

  const records = [
    ...periodHistory.flatMap((period) => Array.isArray(period.expenses) ? period.expenses : []),
    ...state.expenses
  ].filter((item) => item && /^\d{4}-\d{2}-\d{2}$/.test(item.date) && Number.isFinite(Number(item.amount)) && Number(item.amount) > 0);
  const dailyTotals = new Map();
  records.forEach((item) => {
    if (item.date < localDateString(rangeStart) || item.date > localDateString(today)) return;
    dailyTotals.set(item.date, (dailyTotals.get(item.date) || 0) + Number(item.amount));
  });
  const dates = [];
  for (let date = new Date(rangeStart); date <= today; date.setDate(date.getDate() + 1)) dates.push(localDateString(date));
  const values = dates.map((date) => dailyTotals.get(date) || 0);
  const totalSpent = values.reduce((sum, amount) => sum + amount, 0);
  const average = dates.length ? totalSpent / dates.length : 0;
  const daysRemaining = calendarDaysBetween(today, parseDate(state.incomeDate) || today);
  const activeSpent = state.expenses.reduce((sum, expense) => sum + Number(expense.amount), 0);
  const dailyBudget = daysRemaining > 0 ? ((Number(state.budget) || 0) - activeSpent) / daysRemaining : 0;
  const hasData = records.some((item) => item.date >= localDateString(rangeStart) && item.date <= localDateString(today));

  document.querySelectorAll('[data-spending-range]').forEach((button) => {
    const selected = button.dataset.spendingRange === range;
    button.classList.toggle('is-selected', selected);
    button.setAttribute('aria-pressed', String(selected));
  });
  $('#spending-ranges').setAttribute('aria-label', labels.spendingRangeLabel);
  $('#spending-chart-empty').hidden = hasData;
  const smiley = $('#spending-smiley');
  const summary = $('#spending-summary');
  if (!hasData) {
    smiley.textContent = '🙂';
    summary.textContent = labels.spendingNoData;
    $('#spending-mood').dataset.mood = 'empty';
  } else {
    const mood = average <= dailyBudget * 0.9 ? ['🙂', labels.spendingBelow]
      : average <= dailyBudget * 1.15 ? ['😌', labels.spendingNear]
        : ['😟', labels.spendingAbove];
    smiley.textContent = mood[0];
    summary.textContent = `${labels.spendingAverage.replace('{amount}', currency.format(average))} · ${mood[1]}`;
    $('#spending-mood').dataset.mood = average <= dailyBudget * 0.9 ? 'good' : average <= dailyBudget * 1.15 ? 'near' : 'high';
  }

  const wrapper = $('#spending-chart');
  wrapper.replaceChildren();
  wrapper.setAttribute('aria-label', labels.spendingChartLabel);
  const svgNs = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNs, 'svg');
  svg.setAttribute('viewBox', '0 0 760 230');
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', labels.spendingChartLabel);
  const minValue = Math.min(0, dailyBudget);
  const maxValue = Math.max(1, dailyBudget, ...values);
  const span = Math.max(1, maxValue - minValue);
  const left = 48, right = 730, top = 24, bottom = 177;
  const x = (index) => dates.length <= 1 ? (left + right) / 2 : left + index * ((right - left) / (dates.length - 1));
  const y = (value) => bottom - ((value - minValue) / span) * (bottom - top);
  const zeroLine = document.createElementNS(svgNs, 'line');
  zeroLine.setAttribute('x1', String(left)); zeroLine.setAttribute('x2', String(right));
  zeroLine.setAttribute('y1', String(y(0))); zeroLine.setAttribute('y2', String(y(0)));
  zeroLine.setAttribute('class', 'spending-zero-line'); svg.append(zeroLine);
  const budgetLine = document.createElementNS(svgNs, 'line');
  budgetLine.setAttribute('x1', String(left)); budgetLine.setAttribute('x2', String(right));
  budgetLine.setAttribute('y1', String(y(dailyBudget))); budgetLine.setAttribute('y2', String(y(dailyBudget)));
  budgetLine.setAttribute('class', 'spending-budget-line'); svg.append(budgetLine);
  if (values.length) {
    const line = document.createElementNS(svgNs, 'polyline');
    line.setAttribute('points', values.map((amount, index) => `${x(index)},${y(amount)}`).join(' '));
    line.setAttribute('class', 'spending-line'); svg.append(line);
    values.forEach((amount, index) => {
      if (amount <= 0) return;
      const point = document.createElementNS(svgNs, 'circle');
      point.setAttribute('cx', String(x(index))); point.setAttribute('cy', String(y(amount)));
      point.setAttribute('r', dates.length > 45 ? '2' : '3.5');
      point.setAttribute('class', amount <= dailyBudget ? 'spending-point-ok' : 'spending-point-high'); svg.append(point);
    });
  }
  const budgetText = document.createElementNS(svgNs, 'text');
  budgetText.setAttribute('x', String(right - 3)); budgetText.setAttribute('y', String(Math.max(14, y(dailyBudget) - 6)));
  budgetText.setAttribute('text-anchor', 'end'); budgetText.setAttribute('class', 'spending-budget-label');
  budgetText.textContent = currency.format(dailyBudget); svg.append(budgetText);

  const tickIndexes = new Set();
  if (range === '14days') {
    [0, Math.round((dates.length - 1) / 4), Math.round((dates.length - 1) / 2), Math.round((dates.length - 1) * 3 / 4), dates.length - 1].forEach((index) => tickIndexes.add(index));
  } else {
    dates.forEach((date, index) => { if (date.slice(-2) === '01') tickIndexes.add(index); });
    tickIndexes.add(0); tickIndexes.add(dates.length - 1);
  }
  const tickFormatter = new Intl.DateTimeFormat(locale, range === '14days' ? { day: 'numeric', month: 'short' } : { month: 'short' });
  tickIndexes.forEach((index) => {
    const tick = document.createElementNS(svgNs, 'text');
    tick.setAttribute('x', String(x(index))); tick.setAttribute('y', '207');
    tick.setAttribute('text-anchor', 'middle'); tick.setAttribute('class', 'spending-axis-label');
    tick.textContent = tickFormatter.format(parseDate(dates[index])); svg.append(tick);
  });
  wrapper.append(svg);
}

function openMotivationDialog() {
  let quoteIndex = Math.floor(Math.random() * motivationQuotes.length);
  if (motivationQuotes.length > 1 && quoteIndex === previousQuoteIndex) quoteIndex = (quoteIndex + 1 + Math.floor(Math.random() * (motivationQuotes.length - 1))) % motivationQuotes.length;
  previousQuoteIndex = quoteIndex;
  const quote = motivationQuotes[quoteIndex][currentLanguage];
  const name = nameChoice.name.trim();
  $('#motivation-title').textContent = name ? translations[currentLanguage].motivationTitleNamed.replace('{name}', () => name) : translations[currentLanguage].motivationTitle;
  $('#quote-label').textContent = name ? translations[currentLanguage].motivationSectionNamed.replace('{name}', () => name) : translations[currentLanguage].motivationSection;
  $('#forecast-title').textContent = name ? translations[currentLanguage].futureHeadingNamed.replace('{name}', () => name) : translations[currentLanguage].futureHeading;
  $('.future-disclaimer').textContent = name ? translations[currentLanguage].forecastDisclaimerNamed.replace('{name}', () => name) : translations[currentLanguage].forecastDisclaimer;
  $('#motivation-quote').textContent = name ? `${name}, ${quote}` : quote;
  renderFutureForecast();
  motivationDialog.showModal();
  $('#close-future').focus();
}

function completeNameChoice(name) {
  saveNameChoice(name);
  render();
  renderHistory();
  nameDialog.close();
  openMotivationDialog();
}

startBudgetInput.value = state.budget;
incomeDateInput.value = state.incomeDate;
expenseDateInput.value = localDateString(new Date());
applyTranslations();
applyTheme();

startBudgetInput.addEventListener('input', () => {
  state.budget = startBudgetInput.value;
  saveState();
  render();
});
incomeDateInput.addEventListener('input', () => {
  state.incomeDate = incomeDateInput.value || monthEndString();
  saveState();
  render();
});
let calculatorReturnFocus = $('#open-calculator');
function openCalculator(trigger) {
  calculatorReturnFocus = trigger;
  calculatorDialog.showModal();
  $('#apply-calculator').focus();
}
$('#open-calculator').addEventListener('click', (event) => openCalculator(event.currentTarget));
$('#open-calculator-menu').addEventListener('click', (event) => {
  menuDialog.close();
  openCalculator(event.currentTarget);
});
document.querySelectorAll('#calculator-income-fields, #calculator-expense-fields').forEach((fields) => fields.addEventListener('input', (event) => {
  const amountId = event.target.dataset.calculatorAmount;
  const nameId = event.target.dataset.calculatorName;
  if (amountId) {
    calculatorState.amounts[amountId] = event.target.value;
    saveCalculatorState();
    updateCalculatorTotals();
  } else if (nameId) {
    calculatorState.names[nameId] = event.target.value;
    saveCalculatorState();
  }
}));
$('#apply-calculator').addEventListener('click', () => {
  const remainder = calculatorIncomeIds.reduce((sum, id) => sum + (Number(calculatorState.amounts[id]) || 0), 0)
    - calculatorExpenseIds.reduce((sum, id) => sum + (Number(calculatorState.amounts[id]) || 0), 0);
  state.budget = remainder.toFixed(2);
  startBudgetInput.value = state.budget;
  saveState();
  render();
  calculatorDialog.close();
});
$('#close-calculator').addEventListener('click', () => calculatorDialog.close());
$('#close-calculator-x').addEventListener('click', () => calculatorDialog.close());
calculatorDialog.addEventListener('close', () => calculatorReturnFocus?.focus());
calculatorDialog.addEventListener('click', (event) => {
  const bounds = calculatorDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) calculatorDialog.close();
});
let periodReturnFocus = $('#start-new-period-dashboard');
function openPeriodConfirmation(trigger) {
  periodReturnFocus = trigger === $('#start-new-period-menu') ? menuToggle : trigger;
  if (menuDialog.open) menuDialog.close();
  periodConfirmDialog.showModal();
  $('#confirm-period').focus();
}
$('#start-new-period-dashboard').addEventListener('click', (event) => openPeriodConfirmation(event.currentTarget));
$('#start-new-period-menu').addEventListener('click', (event) => openPeriodConfirmation(event.currentTarget));
$('#cancel-period').addEventListener('click', () => periodConfirmDialog.close());
$('#close-period-x').addEventListener('click', () => periodConfirmDialog.close());
$('#confirm-period').addEventListener('click', () => {
  const closedEndDate = state.incomeDate || localDateString(new Date());
  const closedResult = Number(currentProjection.toFixed(2));
  periodHistory.push({
    startDate: state.periodStart || monthStartString(),
    endDate: closedEndDate,
    startBudget: Number(state.budget) || 0,
    result: closedResult,
    expenses: state.expenses.map((expense) => ({ date: expense.date, amount: Number(expense.amount) }))
  });
  saveHistory();
  const closedEnd = parseDate(closedEndDate) || new Date();
  const nextStart = new Date(closedEnd.getFullYear(), closedEnd.getMonth() + 1, 1);
  state.periodStart = localDateString(nextStart);
  state.incomeDate = monthEndString(nextStart);
  state.budget = closedResult.toFixed(2);
  state.expenses = [];
  saveState();
  startBudgetInput.value = state.budget;
  incomeDateInput.value = state.incomeDate;
  expenseDateInput.value = state.periodStart;
  render();
  periodConfirmDialog.close();
});
periodConfirmDialog.addEventListener('close', () => periodReturnFocus?.focus());
periodConfirmDialog.addEventListener('click', (event) => {
  const bounds = periodConfirmDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) periodConfirmDialog.close();
});
let historyReturnFocus = menuToggle;
function openHistory(trigger) {
  historyReturnFocus = trigger === $('#open-history-menu') ? menuToggle : trigger;
  if (menuDialog.open) menuDialog.close();
  renderHistory();
  historyDialog.showModal();
  $('#close-history').focus();
}
$('#open-history-menu').addEventListener('click', (event) => openHistory(event.currentTarget));
document.querySelectorAll('[data-spending-range]').forEach((button) => button.addEventListener('click', () => {
  spendingRange = button.dataset.spendingRange;
  renderSpendingPattern(spendingRange);
}));
$('#close-history').addEventListener('click', () => historyDialog.close());
$('#close-history-x').addEventListener('click', () => historyDialog.close());
historyDialog.addEventListener('close', () => historyReturnFocus?.focus());
historyDialog.addEventListener('click', (event) => {
  const bounds = historyDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) historyDialog.close();
});
$('#open-demo-menu').addEventListener('click', () => {
  menuDialog.close();
  demoDialog.showModal();
  $('#start-demo').focus();
});
$('#cancel-demo').addEventListener('click', () => demoDialog.close());
$('#close-demo-x').addEventListener('click', () => demoDialog.close());
demoDialog.addEventListener('close', () => menuToggle.focus());
demoDialog.addEventListener('click', (event) => {
  const bounds = demoDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) demoDialog.close();
});
$('#start-demo').addEventListener('click', () => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const demoBudgets = [980, 1020, 1005, 990, 1030, 1000];
  const demoResults = [120, 85, 150, 60, 190, 110];
  const makeDemoExpenses = (startDate, endDate, total, phase = 0) => {
    const dates = [];
    for (let date = new Date(startDate); date <= endDate; date.setDate(date.getDate() + 1)) dates.push(localDateString(date));
    const weights = dates.map((_, index) => 1 + 0.16 * Math.sin((index + phase) * 0.83) + 0.08 * Math.cos((index + phase) * 0.41));
    const weightTotal = weights.reduce((sum, value) => sum + value, 0);
    let allocated = 0;
    return dates.map((date, index) => {
      const amount = index === dates.length - 1
        ? Number((total - allocated).toFixed(2))
        : Number((total * weights[index] / weightTotal).toFixed(2));
      allocated += amount;
      return { id: `demo-${date}-${index}`, date, amount };
    });
  };
  periodHistory = [];
  for (let monthsAgo = 6; monthsAgo >= 1; monthsAgo -= 1) {
    const monthStart = new Date(today.getFullYear(), today.getMonth() - monthsAgo, 1);
    const monthEnd = new Date(today.getFullYear(), today.getMonth() - monthsAgo + 1, 0);
    const sampleIndex = 6 - monthsAgo;
    periodHistory.push({
      startDate: localDateString(monthStart),
      endDate: localDateString(monthEnd),
      startBudget: demoBudgets[sampleIndex],
      result: demoResults[sampleIndex],
      expenses: makeDemoExpenses(monthStart, monthEnd, demoBudgets[sampleIndex] - demoResults[sampleIndex], sampleIndex)
    });
  }
  saveHistory();
  const demoPeriodStart = new Date(today);
  demoPeriodStart.setDate(demoPeriodStart.getDate() - 14);
  state.periodStart = localDateString(demoPeriodStart);
  const demoIncomeDate = new Date(today);
  demoIncomeDate.setDate(demoIncomeDate.getDate() + 16);
  state.incomeDate = localDateString(demoIncomeDate);
  state.budget = '900';
  const demoExpenseStart = new Date(today);
  demoExpenseStart.setDate(demoExpenseStart.getDate() - 13);
  state.expenses = makeDemoExpenses(demoExpenseStart, today, 420, 8);
  saveState();
  calculatorState.amounts = {
    salary: '2800', housingBenefit: '150', healthBenefit: '100', otherIncome: '150', childBenefit: '200', pensionBenefits: '0',
    rent: '950', healthInsurance: '160', energy: '180', water: '25', municipalTax: '70', carCosts: '100', transport: '100',
    internetTv: '55', mobile: '25', streaming: '25', groceries: '40', homeInsurance: '25', savings: '100', gym: '30', clothing: '60',
    childcare: '0', studentLoan: '50', otherSubscriptions: '15', loans: '60', pets: '30', homeRepairs: '60', householdGoods: '40',
    medicalDental: '25', education: '20', carMaintenance: '35', bankFees: '8', personalCare: '25', supportPaid: '0', holidayFund: '80',
    diningOut: '47', leisureCulture: '40', giftsDonations: '20', other1: '0', other2: '0', other3: '0', other4: '0', other5: '0'
  };
  calculatorState.names = {};
  saveCalculatorState();
  renderCalculatorFields();
  startBudgetInput.value = state.budget;
  incomeDateInput.value = state.incomeDate;
  expenseDateInput.value = localDateString(today);
  rewardState.lastActiveDate = localDateString(today);
  rewardState.streak = 32;
  rewardState.tier = 'gold';
  rewardState.goldCelebrated = true;
  rewardState.degradationNotice = false;
  saveRewardState();
  render();
  renderHistory();
  demoDialog.close();
  $('#demo-notice').hidden = false;
  $('#dismiss-demo-notice').focus();
});
$('#dismiss-demo-notice').addEventListener('click', () => { $('#demo-notice').hidden = true; });
$('#dismiss-daily-tip').addEventListener('click', dismissDailyTip);
$('#expense-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const amount = Number(expenseAmountInput.value);
  if (!expenseDateInput.value || !Number.isFinite(amount) || amount <= 0) return;
  state.expenses.push({ id: String(Date.now()) + '-' + Math.random().toString(36).slice(2), date: expenseDateInput.value, amount });
  if (saveState()) showDailyTip();
  expenseAmountInput.value = '';
  render();
  expenseAmountInput.focus();
});
$('#clear-ledger').addEventListener('click', () => {
  if (!state.expenses.length) return;
  clearLedgerDialog.showModal();
  $('#cancel-clear-ledger').focus();
});
$('#cancel-clear-ledger').addEventListener('click', () => clearLedgerDialog.close());
$('#confirm-clear-ledger').addEventListener('click', () => {
  clearLedgerDialog.close();
  state.expenses = [];
  saveState();
  render();
});
$('#dismiss-degradation').addEventListener('click', () => {
  rewardState.degradationNotice = false;
  saveRewardState();
  $('#degradation-notice').hidden = true;
});
languageSelect.addEventListener('change', () => {
  currentLanguage = Object.prototype.hasOwnProperty.call(translations, languageSelect.value) ? languageSelect.value : 'nl';
  try {
    localStorage.setItem(LANGUAGE_KEY, currentLanguage);
  } catch (error) {
    console.warn('De voorkeurstaal kon niet worden opgeslagen.', error);
  }
  applyTranslations();
  render();
  menuDialog.close();
});
themeSelect.addEventListener('change', () => {
  currentTheme = themeNames.includes(themeSelect.value) ? themeSelect.value : 'navy';
  try {
    localStorage.setItem(THEME_KEY, currentTheme);
  } catch (error) {
    console.warn('De thema-voorkeur kon niet worden opgeslagen.', error);
  }
  applyTheme();
  menuDialog.close();
});
menuToggle.addEventListener('click', () => {
  menuDialog.showModal();
  menuToggle.setAttribute('aria-expanded', 'true');
  languageSelect.focus();
});
menuDialog.addEventListener('close', () => {
  menuToggle.setAttribute('aria-expanded', 'false');
  if (!instructionsDialog.open && !privacyDialog.open && !resetDialog.open && !calculatorDialog.open && !periodConfirmDialog.open && !historyDialog.open && !demoDialog.open) menuToggle.focus();
});
$('#open-instructions').addEventListener('click', () => {
  menuDialog.close();
  instructionsDialog.showModal();
  $('#close-instructions').focus();
});
$('#close-instructions').addEventListener('click', () => instructionsDialog.close());
$('#close-instructions-x').addEventListener('click', () => instructionsDialog.close());
instructionsDialog.addEventListener('close', () => menuToggle.focus());
instructionsDialog.addEventListener('click', (event) => {
  const bounds = instructionsDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) instructionsDialog.close();
});
$('#open-privacy').addEventListener('click', () => {
  menuDialog.close();
  privacyDialog.showModal();
  $('#close-privacy').focus();
});
$('#close-privacy').addEventListener('click', () => privacyDialog.close());
$('#close-privacy-x').addEventListener('click', () => privacyDialog.close());
privacyDialog.addEventListener('close', () => menuToggle.focus());
privacyDialog.addEventListener('click', (event) => {
  const bounds = privacyDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) privacyDialog.close();
});
$('#open-reset').addEventListener('click', () => {
  menuDialog.close();
  resetDialog.showModal();
  $('#cancel-reset').focus();
});
$('#cancel-reset').addEventListener('click', () => resetDialog.close());
$('#confirm-reset').addEventListener('click', () => {
  localStorage.clear();
  window.location.reload();
});
resetDialog.addEventListener('close', () => menuToggle.focus());
futureButton.addEventListener('click', () => {
  nameChoice = loadNameChoice();
  if (nameChoice.complete) {
    openMotivationDialog();
    return;
  }
  firstNameInput.value = nameChoice.name;
  nameDialog.showModal();
  firstNameInput.focus();
});
$('#save-name').addEventListener('click', () => completeNameChoice(firstNameInput.value));
$('#skip-name').addEventListener('click', () => completeNameChoice(''));
firstNameInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    event.preventDefault();
    completeNameChoice(firstNameInput.value);
  }
});
nameDialog.addEventListener('cancel', (event) => {
  event.preventDefault();
  completeNameChoice('');
});
nameDialog.addEventListener('click', (event) => {
  if (event.target === nameDialog) completeNameChoice('');
});
$('#close-future').addEventListener('click', () => motivationDialog.close());
$('#close-future-x').addEventListener('click', () => motivationDialog.close());
motivationDialog.addEventListener('close', () => futureButton.focus());
menuDialog.addEventListener('click', (event) => {
  const bounds = menuDialog.getBoundingClientRect();
  if (event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom) menuDialog.close();
});

render();
setInterval(render, 60000);
