const W=1084,H=1536;
const X=[45,98,150,201,250,304,459,602,654,707,759,837,913];
const Y0=299, RH=34.75, ROWS=31;
const $=id=>document.getElementById(id);
const fields=[];
const pad=n=>String(n).padStart(2,"0");

function mins(v){
  const m=/^(\d{1,2}):(\d{2})$/.exec((v||"").trim());
  if(!m)return null;
  const h=+m[1], mm=+m[2];
  return h<=23&&mm<=59?h*60+mm:null;
}
function hm(v){
  v=((v%1440)+1440)%1440;
  return pad(Math.floor(v/60))+":"+pad(v%60);
}
function rect(x1,x2,y1,y2,cls="",value="",editable=true,ph=""){
  const e=document.createElement(editable?"input":"div");
  e.className="cell "+cls;
  e.style.left=x1+"px"; e.style.top=y1+"px"; e.style.width=(x2-x1)+"px"; e.style.height=(y2-y1)+"px";
  if(editable){e.value=value;e.placeholder=ph;e.autocomplete="off";e.inputMode="text"} else e.textContent=value;
  $("fields").appendChild(e); fields.push(e); return e;
}

let data={};

function daysInMonth(){
  if(!$("month").value)return 31;
  const [y,m]=$("month").value.split("-").map(Number);
  return new Date(y,m,0).getDate();
}

function rebuild(){
  $("fields").innerHTML=""; fields.length=0; data={};
  // top fields sit in the actual header lines of the supplied blank form
  const n=rect(45,470,119,157,"topfield",$("name").value,true,"Name");
  n.addEventListener("input",()=>{$("name").value=n.value});
  const k=rect(470,760,119,157,"topfield",$("kennz").value,true,"Kennz.");
  k.addEventListener("input",()=>{$("kennz").value=k.value});
  const mo=rect(760,913,119,157,"topfield",$("month").value.replace("-","/"),false);

  const count=daysInMonth();
  for(let d=1;d<=ROWS;d++){
    const y1=Y0+(d-1)*RH, y2=y1+RH-1;
    const dt=$("month").value?new Date(...$("month").value.split("-").map(Number).map((v,i)=>i===1?v-1:v),d):null;
    const dow=dt?dt.getDay():0; // 0 Sun, 6 Sat
    const work=d<=count && dow!==0 && dow!==6;

    const day=rect(X[0],X[1],y1,y2,"auto",String(d),false);
    // time von/bis
    const von=rect(X[1],X[2],y1,y2,work?"manual":"weekend","",work,"07:00");
    const bis=rect(X[2],X[3],y1,y2,"auto",work?"":(d<=count?"—":""),false);
    const zeit=rect(X[3],X[4],y1,y2,"auto",work?"24":(d<=count?"—":""),false);
    const spesen=rect(X[4],X[5],y1,y2,"auto",work?((dow===1||dow===5)?"14":"28"):(d<=count?"—":""),false);

    // postal Start / Stop
    const startPLZ=rect(X[5],X[6],y1,y2,work?"manual":"weekend","",work,"PLZ");
    const stopPLZ=rect(X[6],X[7],y1,y2,work?"manual":"weekend","",work,"PLZ");

    // second von, Pause, bis
    const von2=rect(X[7],X[8],y1,y2,"auto","",false);
    const pause=rect(X[8],X[9],y1,y2,"auto",work?"1:00":(d<=count?"—":""),false);
    const bis2=rect(X[9],X[10],y1,y2,"auto","",false);
    const netArb=rect(X[10],X[11],y1,y2,"auto","",false);
    const netDrive=rect(X[11],X[12],y1,y2,work?"manual":"weekend","",work,"08:30");

    data[d]={work,von,bis,zeit,spesen,startPLZ,stopPLZ,von2,pause,bis2,netArb,netDrive,linked:true};

    // Transfer last working day's Stop -> this day's Start.
    if(work){
      const prev=[...Array(d-1)].reverse().find(n=>data[n]?.work);
      if(prev){
        startPLZ.value=data[prev].stopPLZ.value||"";
        data[d].linked=true;
        data[d].linkPrev=prev;
        startPLZ.classList.remove("manual"); startPLZ.classList.add("auto");
        startPLZ.readOnly=false; // editable, but linked until user changes it
      }
      startPLZ.addEventListener("input",()=>{data[d].linked=false;startPLZ.classList.remove("auto");startPLZ.classList.add("manual");});
      stopPLZ.addEventListener("input",()=>updateTransfers(d));
      von.addEventListener("input",()=>updateDay(d));
      netDrive.addEventListener("input",()=>updateDay(d));
      updateDay(d);
    }
  }
}

function updateTransfers(fromDay){
  const stop=data[fromDay]?.stopPLZ?.value||"";
  for(let d=fromDay+1;d<=ROWS;d++){
    if(!data[d]?.work)continue;
    if(data[d].linked){
      data[d].startPLZ.value=stop;
      updateTransfers(d);
    }
    break;
  }
}
function updateDay(d){
  const r=data[d]; if(!r||!r.work)return;
  const s=mins(r.von.value), drive=mins(r.netDrive.value);
  r.von2.textContent=s==null?"":hm(s);
  r.bis.textContent=(s==null||drive==null)?"":hm(s+drive+120);
  r.bis2.textContent=(s==null||drive==null)?"":hm(s+drive+120);
  r.netArb.textContent=drive==null?"":hm(drive+60);
}

$("month").addEventListener("change",rebuild);
const now=new Date(); $("month").value=`${now.getFullYear()}-${pad(now.getMonth()+1)}`; rebuild();

// ---------- PDF: draw the original blank form + values into the exact same cells ----------
function dataURLBytes(url){
  const b=atob(url.split(",")[1]), a=new Uint8Array(b.length);
  for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i); return a;
}
function join(parts){
  const n=parts.reduce((s,a)=>s+a.length,0), out=new Uint8Array(n); let p=0;
  for(const a of parts){out.set(a,p);p+=a.length} return out;
}
function pdf(jpeg,w,h){
  const enc=new TextEncoder(), B=s=>enc.encode(s);
  const objs=[];
  const content=B(`q\n${w} 0 0 ${h} 0 0 cm\n/Im0 Do\nQ\n`);
  objs[1]=join([B(`<< /Length ${content.length} >>\nstream\n`),content,B("endstream")]);
  objs[2]=join([B(`<< /Type /XObject /Subtype /Image /Width ${w} /Height ${h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`),jpeg,B("\nendstream")]);
  objs[3]=B("<< /Type /Pages /Kids [5 0 R] /Count 1 >>");
  objs[4]=B("<< /Type /Page /Parent 3 0 R /MediaBox [0 0 1084 1536] /Resources << /XObject << /Im0 2 0 R >> >> /Contents 1 0 R >>");
  objs[5]=B("<< /Type /Catalog /Pages 3 0 R >>");
  let out=[B("%PDF-1.4\n%\xFF\xFF\xFF\xFF\n")],offs=[0],pos=out[0].length;
  for(let i=1;i<=5;i++){offs[i]=pos;const o=join([B(`${i} 0 obj\n`),objs[i],B("\nendobj\n")]);out.push(o);pos+=o.length}
  const xr=pos;out.push(B("xref\n0 6\n0000000000 65535 f \n"));
  for(let i=1;i<=5;i++)out.push(B(String(offs[i]).padStart(10,"0")+" 00000 n \n"));
  out.push(B(`trailer\n<< /Size 6 /Root 5 0 R >>\nstartxref\n${xr}\n%%EOF`));
  return join(out);
}
$("pdf").addEventListener("click",async()=>{
  const img=new Image(); img.src="blank_form.jpg";
  await new Promise((ok,no)=>{img.onload=ok;img.onerror=no});
  const c=document.createElement("canvas");c.width=W;c.height=H;
  const ctx=c.getContext("2d");ctx.drawImage(img,0,0,W,H);
  ctx.textAlign="center";ctx.textBaseline="middle";ctx.fillStyle="#111";ctx.font="18px Arial";
  // top
  ctx.textAlign="left";ctx.fillText($("name").value,55,138);ctx.fillText($("kennz").value,475,138);
  ctx.textAlign="center";
  for(let d=1;d<=ROWS;d++){
    const r=data[d];if(!r)continue; const y=Y0+(d-1)*RH+RH/2;
    const vals=[
      r.von?.value||"",r.bis?.textContent||"",r.zeit?.textContent||"",r.spesen?.textContent||"",
      r.startPLZ?.value||"",r.stopPLZ?.value||"",r.von2?.textContent||"",r.pause?.textContent||"",
      r.bis2?.textContent||"",r.netArb?.textContent||"",r.netDrive?.value||""
    ];
    const cols=[X[1],X[2],X[3],X[4],X[5],X[6],X[7],X[8],X[9],X[10],X[11]];
    for(let i=0;i<vals.length;i++) if(vals[i]) ctx.fillText(vals[i],(cols[i]+X[i+2])/2,y);
  }
  const blob=new Blob([pdf(dataURLBytes(c.toDataURL("image/jpeg",.95)),W,H)],{type:"application/pdf"});
  const u=URL.createObjectURL(blob),a=document.createElement("a");a.href=u;a.download="Spesen_Arbeitszeiten.pdf";a.click();
  setTimeout(()=>URL.revokeObjectURL(u),10000);
});
