// Pizza POS — Developed by Abid
// app.js

const DB = {
  get(key, def = null) { try { const v = localStorage.getItem('pizzaPOS_' + key); return v ? JSON.parse(v) : def; } catch(e) { return def; } },
  set(key, val) { try { localStorage.setItem('pizzaPOS_' + key, JSON.stringify(val)); return true; } catch(e) { toast('danger', 'Storage Error', 'Data save nahi hua'); return false; } },
  remove(key) { localStorage.removeItem('pizzaPOS_' + key); },
  clearAll() { Object.keys(localStorage).filter(k => k.startsWith('pizzaPOS_')).forEach(k => localStorage.removeItem(k)); }
};

let currentUser = null;
let currentBranch = null;
let cart = [];
let posTab = 'menu';
let appSettings = {};

function initSettings() {
  appSettings = DB.get('settings', { restaurantName: 'Pizza POS', logo: '', address: '', phone: '', taxRate: 0, serviceCharge: 0, printerType: 'thermal80', aiApiKey: '', theme: 'light' });
}

function initDefaultUsers() {
  let users = DB.get('users', null);
  if (!users) {
    users = [{ id: 1, name: 'Admin', username: 'admin', password: 'admin123', role: 'admin', openingBalance: 0, active: true, permissions: ['dashboard','pos','menu','deals','inventory','expense','assets','staff','rider','kitchen','shift','reports','users','branches','customers','settings'] }];
    DB.set('users', users);
  }
}

function initDefaultBranches() {
  let branches = DB.get('branches', null);
  if (!branches) {
    branches = [{ id: 1, name: 'Main Branch', address: '', phone: '', active: true }];
    DB.set('branches', branches);
    currentBranch = 1;
    DB.set('currentBranch', 1);
  } else {
    currentBranch = DB.get('currentBranch', branches[0].id);
  }
}

function handleLogin() {
  const u = document.getElementById('loginUsername').value.trim();
  const p = document.getElementById('loginPassword').value;
  const errEl = document.getElementById('loginError');
  errEl.classList.remove('show');
  if (!u || !p) { errEl.textContent = 'Username aur password dono likhein'; errEl.classList.add('show'); return; }
  const users = DB.get('users', []);
  const user = users.find(x => x.username === u && x.password === p && x.active);
  if (!user) {
    const attempts = DB.get('loginAttempts_' + u, 0) + 1;
    DB.set('loginAttempts_' + u, attempts);
    errEl.textContent = attempts >= 3 ? 'Account locked — 3 galat attempts' : 'Ghalat username ya password (' + attempts + '/3)';
    errEl.classList.add('show');
    return;
  }
  DB.set('loginAttempts_' + u, 0);
  currentUser = user;
  DB.set('currentUser', user);
  logActivity('LOGIN', user.name + ' logged in');
  document.getElementById('loginScreen').classList.add('hidden');
  document.getElementById('appContainer').classList.remove('hidden');
  initAppAfterLogin();
}

function initAppAfterLogin() {
  if (!currentUser) return;
  initSettings();
  applyTheme(appSettings.theme || 'light');
  document.getElementById('sidebarRestaurantName').textContent = appSettings.restaurantName || 'Pizza POS';
  const branch = (DB.get('branches', [])).find(b => b.id === currentBranch);
  document.getElementById('sidebarBranchName').textContent = branch ? branch.name : 'Main Branch';
  document.getElementById('userNameDisplay').textContent = currentUser.name;
  document.getElementById('userRoleDisplay').textContent = currentUser.role;
  document.getElementById('userAvatar').textContent = currentUser.name.charAt(0).toUpperCase();
  renderSidebar();
  updateShiftBadge();
  navigateTo('dashboard');
}

function handleLogout() {
  showConfirm('Logout', 'Kya aap logout karna chahte hain?', 'warning', () => {
    logActivity('LOGOUT', currentUser.name + ' logged out');
    currentUser = null;
    DB.remove('currentUser');
    document.getElementById('appContainer').classList.add('hidden');
    document.getElementById('loginScreen').classList.remove('hidden');
    document.getElementById('loginUsername').value = '';
    document.getElementById('loginPassword').value = '';
  });
}

function hasPermission(perm) {
  if (!currentUser) return false;
  if (currentUser.role === 'admin') return true;
  return (currentUser.permissions || []).includes(perm);
}

function renderSidebar() {
  const nav = document.getElementById('sidebarNav');
  const items = [
    { id: 'dashboard', icon: 'fa-home', label: 'Dashboard', perm: 'dashboard' },
    { id: 'pos', icon: 'fa-cash-register', label: 'POS', perm: 'pos' },
    { id: 'menu', icon: 'fa-pizza-slice', label: 'Menu', perm: 'menu' },
    { id: 'deals', icon: 'fa-tags', label: 'Deals', perm: 'deals' },
    { id: 'inventory', icon: 'fa-boxes', label: 'Inventory', perm: 'inventory' },
    { id: 'expense', icon: 'fa-receipt', label: 'Expense', perm: 'expense' },
    { id: 'assets', icon: 'fa-chair', label: 'Assets', perm: 'assets' },
    { id: 'staff', icon: 'fa-users', label: 'Staff', perm: 'staff' },
    { id: 'rider', icon: 'fa-motorcycle', label: 'Rider', perm: 'rider' },
    { id: 'kitchen', icon: 'fa-fire', label: 'Kitchen', perm: 'kitchen' },
    { id: 'shift', icon: 'fa-clock', label: 'Shift', perm: 'shift' },
    { id: 'reports', icon: 'fa-chart-bar', label: 'Reports', perm: 'reports' },
    { id: 'customers', icon: 'fa-user-friends', label: 'Customers', perm: 'customers' },
    { id: 'users', icon: 'fa-user-cog', label: 'Users', perm: 'users' },
    { id: 'branches', icon: 'fa-store', label: 'Branches', perm: 'branches' },
    { id: 'settings', icon: 'fa-cog', label: 'Settings', perm: 'settings' }
  ];
  nav.innerHTML = '';
  items.forEach(item => {
    if (!hasPermission(item.perm)) return;
    const div = document.createElement('div');
    div.className = 'nav-item';
    div.dataset.page = item.id;
    div.innerHTML = '<i class="fas ' + item.icon + '"></i><span>' + item.label + '</span>';
    div.onclick = () => navigateTo(item.id);
    nav.appendChild(div);
  });
}

function navigateTo(page) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  const activeNav = document.querySelector('.nav-item[data-page="' + page + '"]');
  if (activeNav) activeNav.classList.add('active');
  const titles = { dashboard: 'Dashboard', pos: 'Point of Sale', menu: 'Menu Management', deals: 'Deals Management', inventory: 'Inventory', expense: 'Expenses', assets: 'Assets', staff: 'Staff', rider: 'Riders', kitchen: 'Kitchen View', shift: 'Shift Management', reports: 'Reports', customers: 'Customers', users: 'User Management', branches: 'Branches', settings: 'Settings' };
  document.getElementById('pageTitle').textContent = titles[page] || page;
  const content = document.getElementById('pageContent');
  content.innerHTML = '';
  if (!hasPermission(page) && page !== 'dashboard') {
    content.innerHTML = '<div class="empty-state"><i class="fas fa-lock"></i><h3>Access Denied</h3><p>Aap ko is page ki permission nahi hai</p></div>';
    return;
  }
  const renderers = { dashboard: renderDashboard, pos: renderPOS, menu: renderMenu, deals: renderDeals, inventory: renderInventory, expense: renderExpense, assets: renderAssets, staff: renderStaff, rider: renderRider, kitchen: renderKitchen, shift: renderShift, reports: renderReports, customers: renderCustomers, users: renderUsers, branches: renderBranches, settings: renderSettings };
  if (renderers[page]) renderers[page]();
  if (window.innerWidth < 900) document.getElementById('sidebar').classList.remove('show');
}

function toggleSidebar() { document.getElementById('sidebar').classList.toggle('show'); }

function toggleTheme() {
  const cur = appSettings.theme === 'dark' ? 'light' : 'dark';
  appSettings.theme = cur;
  DB.set('settings', appSettings);
  applyTheme(cur);
}

function applyTheme(mode) {
  document.body.className = mode + '-mode';
  const icon = document.getElementById('themeIcon');
  if (icon) icon.className = mode === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
}

function toast(type, title, message) {
  const container = document.getElementById('toastContainer');
  const t = document.createElement('div');
  t.className = 'toast ' + type;
  const icons = { success: 'fa-check-circle', danger: 'fa-times-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
  t.innerHTML = '<i class="fas ' + (icons[type] || icons.info) + '"></i><div class="toast-content"><div class="toast-title">' + title + '</div><div class="toast-message">' + (message || '') + '</div></div>';
  container.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 400); }, 3500);
}

function showConfirm(title, message, type, onYes) {
  const overlay = document.getElementById('modalOverlay');
  const modal = document.getElementById('modalBox');
  modal.className = 'modal modal-sm';
  document.getElementById('modalTitle').innerHTML = '<i class="fas fa-question-circle"></i> ' + title;
  const icons = { danger: 'fa-exclamation-triangle', warning: 'fa-exclamation-circle', success: 'fa-check-circle', info: 'fa-info-circle' };
  document.getElementById('modalBody').innerHTML = '<div class="confirm-dialog"><div class="confirm-icon ' + type + '"><i class="fas ' + (icons[type] || icons.info) + '"></i></div><div class="confirm-title">' + title + '</div><div class="confirm-message">' + message + '</div></div>';
  document.getElementById('modalFooter').innerHTML = '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-' + (type === 'danger' ? 'danger' : type === 'warning' ? 'warning' : 'primary') + '" id="confirmYesBtn">Yes, Confirm</button>';
  overlay.classList.add('show');
  document.getElementById('confirmYesBtn').onclick = () => { closeModal(); if (onYes) onYes(); };
}

function closeModal() { document.getElementById('modalOverlay').classList.remove('show'); }

function openModal(title, bodyHTML, footerHTML, size) {
  const overlay = document.getElementById('modalOverlay');
  const modal = document.getElementById('modalBox');
  modal.className = 'modal' + (size ? ' modal-' + size : '');
  document.getElementById('modalTitle').innerHTML = title;
  document.getElementById('modalBody').innerHTML = bodyHTML;
  document.getElementById('modalFooter').innerHTML = footerHTML || '<button class="btn btn-secondary" onclick="closeModal()">Close</button>';
  overlay.classList.add('show');
}

function logActivity(action, details) {
  const log = DB.get('activityLog', []);
  log.unshift({ time: new Date().toISOString(), user: currentUser ? currentUser.name : 'System', action, details });
  if (log.length > 1000) log.length = 1000;
  DB.set('activityLog', log);
}

function fmt(n) { return 'Rs ' + (Number(n) || 0).toLocaleString('en-PK'); }
function todayStr() { return new Date().toISOString().split('T')[0]; }
function nowTime() { return new Date().toLocaleTimeString('en-PK', { hour: '2-digit', minute: '2-digit' }); }
function uid() { return Date.now() + Math.floor(Math.random() * 1000); }

function playBeep(freq, dur) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.frequency.value = freq || 880;
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + (dur || 0.2));
    osc.start(); osc.stop(ctx.currentTime + (dur || 0.2));
  } catch(e) {}
}

function updateShiftBadge() {
  const shift = DB.get('activeShift', null);
  const badge = document.getElementById('shiftBadge');
  if (!badge) return;
  const label = badge.querySelector('.shift-label');
  const timer = document.getElementById('shiftTimer');
  if (shift) {
    badge.className = 'shift-badge open';
    label.textContent = 'Shift Open';
    if (timer) {
      const start = new Date(shift.startTime);
      const diff = Math.floor((Date.now() - start.getTime()) / 1000);
      const h = Math.floor(diff / 3600), m = Math.floor((diff % 3600) / 60);
      timer.textContent = h + 'h ' + m + 'm';
    }
  } else {
    badge.className = 'shift-badge closed';
    label.textContent = 'Shift Closed';
    if (timer) timer.textContent = '';
  }
}

function handleShiftBadgeClick() { navigateTo('shift'); }
setInterval(() => { if (currentUser) updateShiftBadge(); }, 30000);

function renderDashboard() {
  const content = document.getElementById('pageContent');
  const orders = DB.get('orders', []);
  const expenses = DB.get('expenses', []);
  const today = todayStr();
  const todayOrders = orders.filter(o => o.date === today && o.status !== 'cancelled');
  const todaySales = todayOrders.reduce((s, o) => s + (o.total || 0), 0);
  const todayExpense = expenses.filter(e => e.date === today).reduce((s, e) => s + (e.amount || 0), 0);
  const todayProfit = todaySales - todayExpense;
  const last10 = orders.slice(0, 10);
  content.innerHTML = '<div class="animate-fade-up"><div class="stats-grid"><div class="stat-card"><div class="stat-icon primary"><i class="fas fa-shopping-cart"></i></div><div class="stat-info"><h4>' + fmt(todaySales) + '</h4><p>Today Sales</p></div></div><div class="stat-card"><div class="stat-icon success"><i class="fas fa-chart-line"></i></div><div class="stat-info"><h4>' + fmt(todayProfit) + '</h4><p>Today Profit</p></div></div><div class="stat-card"><div class="stat-icon warning"><i class="fas fa-receipt"></i></div><div class="stat-info"><h4>' + fmt(todayExpense) + '</h4><p>Today Expense</p></div></div><div class="stat-card"><div class="stat-icon info"><i class="fas fa-clipboard-list"></i></div><div class="stat-info"><h4>' + todayOrders.length + '</h4><p>Today Orders</p></div></div></div><div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;"><div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-robot"></i> AI Assistant</h3><span class="badge badge-info">' + (navigator.onLine ? 'Online' : 'Offline') + '</span></div><div id="aiSummaryBox" style="font-size:14px;color:var(--text-light);line-height:1.8;">' + getAISummary(todaySales, todayExpense, todayProfit, todayOrders.length) + '</div></div><div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-history"></i> Last 10 Orders</h3></div><div style="max-height:300px;overflow-y:auto;">' + (last10.length ? last10.map(o => '<div style="padding:10px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;font-size:13px;"><div><strong>#' + o.id + '</strong><br><span style="color:var(--text-light);font-size:11px;">' + o.time + '</span></div><div style="text-align:right;"><span class="text-primary fw-bold">' + fmt(o.total) + '</span></div></div>').join('') : '<div class="empty-state" style="padding:30px;"><i class="fas fa-inbox"></i><p>Koi order nahi</p></div>') + '</div></div></div></div>';
}

function getAISummary(sales, expense, profit, orderCount) {
  const stock = DB.get('stock', []);
  const lowStock = stock.filter(s => s.qty <= (s.minQty || 5) && s.active !== false);
  let html = '<p><i class="fas fa-chart-simple text-primary"></i> <strong>Aaj ki summary:</strong> ' + orderCount + ' orders, sale ' + fmt(sales) + ', expense ' + fmt(expense) + ', profit ' + fmt(profit) + '.</p>';
  if (lowStock.length) html += '<p class="text-warning"><i class="fas fa-exclamation-triangle"></i> <strong>Low stock:</strong> ' + lowStock.slice(0,5).map(s => s.name).join(', ') + '</p>';
  if (profit < 0) html += '<p class="text-danger"><i class="fas fa-arrow-down"></i> Aaj loss hua hai.</p>';
  else if (profit > 0) html += '<p class="text-success"><i class="fas fa-arrow-up"></i> Aaj profit hua hai!</p>';
  html += '<p style="font-size:12px;opacity:.7;margin-top:8px;"><i class="fas fa-info-circle"></i> AI mode: ' + (navigator.onLine ? 'Online' : 'Offline') + '</p>';
  return html;
}

function renderPOS() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="pos-layout animate-fade"><div class="pos-products"><div class="pos-tabs"><button class="pos-tab active" id="tabMenu" onclick="switchPosTab(\'menu\')">Menu</button><button class="pos-tab" id="tabDeals" onclick="switchPosTab(\'deals\')">Deals</button></div><div class="pos-grid" id="posGrid"></div></div><div class="pos-cart"><div class="cart-header"><h3><i class="fas fa-shopping-bag"></i> Cart (<span id="cartCount">0</span>)</h3><button class="cart-clear" onclick="clearCartConfirm()"><i class="fas fa-trash"></i></button></div><div class="cart-items" id="cartItems"><div class="cart-empty"><i class="fas fa-cart-plus"></i><p>Cart empty hai</p></div></div><div class="cart-summary"><div class="summary-row"><span>Subtotal</span><span id="cartSubtotal">0</span></div><div class="summary-row"><span>Tax</span><span id="cartTax">0</span></div><div class="summary-row total"><span>Total</span><span id="cartTotal">0</span></div></div><div class="cart-actions"><button class="btn btn-warning" onclick="holdOrder()"><i class="fas fa-pause"></i> Hold</button><button class="btn btn-success btn-lg" onclick="openCheckout()"><i class="fas fa-check-circle"></i> Checkout</button></div></div></div>';
  cart = [];
  renderPosGrid('menu');
  renderCart();
}

function switchPosTab(tab) {
  posTab = tab;
  document.getElementById('tabMenu').classList.toggle('active', tab === 'menu');
  document.getElementById('tabDeals').classList.toggle('active', tab === 'deals');
  renderPosGrid(tab);
}

function renderPosGrid(tab) {
  const grid = document.getElementById('posGrid');
  let items = [];
  if (tab === 'menu') items = DB.get('menu', []).filter(m => m.active !== false);
  else items = DB.get('deals', []).filter(d => d.active !== false && isDealActive(d));
  if (!items.length) { grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><i class="fas fa-pizza-slice"></i><h3>No items</h3><p>Pehle add karein</p></div>'; return; }
  grid.innerHTML = items.map(item => '<div class="pos-item" onclick="addToCart(' + item.id + ', \'' + tab + '\')"><img class="pos-item-img" src="' + (item.image || 'https://via.placeholder.com/150/e63946/fff?text=' + encodeURIComponent(item.name.charAt(0))) + '"><div class="pos-item-info"><div class="pos-item-name">' + item.name + '</div><div class="pos-item-price">' + fmt(item.price) + '</div></div></div>').join('');
}

function isDealActive(deal) {
  const now = new Date();
  if (deal.type === 'sunday') return now.getDay() === 0;
  if (deal.type === 'time') {
    const cur = now.getHours() * 60 + now.getMinutes();
    const [sh, sm] = (deal.startTime || '00:00').split(':').map(Number);
    const [eh, em] = (deal.endTime || '23:59').split(':').map(Number);
    return cur >= (sh*60+sm) && cur <= (eh*60+em);
  }
  if (deal.type === 'midnight') { const h = now.getHours(); return h >= 0 && h < 4; }
  return true;
}

function addToCart(id, type) {
  const list = type === 'menu' ? DB.get('menu', []) : DB.get('deals', []);
  const item = list.find(x => x.id === id);
  if (!item) return;
  const existing = cart.find(c => c.id === id && c.type === type);
  if (existing) existing.qty++;
  else cart.push({ id, type, name: item.name, price: item.price, image: item.image, qty: 1 });
  renderCart();
  playBeep(880, 0.08);
}

function renderCart() {
  const container = document.getElementById('cartItems');
  const countEl = document.getElementById('cartCount');
  if (!container) return;
  if (!cart.length) { container.innerHTML = '<div class="cart-empty"><i class="fas fa-cart-plus"></i><p>Cart empty hai</p></div>'; if (countEl) countEl.textContent = '0'; updateCartTotals(); return; }
  if (countEl) countEl.textContent = cart.reduce((s, c) => s + c.qty, 0);
  container.innerHTML = cart.map((c, i) => '<div class="cart-item"><img class="cart-item-img" src="' + (c.image || 'https://via.placeholder.com/44') + '"><div class="cart-item-info"><div class="cart-item-name">' + c.name + '</div><div class="cart-item-price">' + fmt(c.price) + ' × ' + c.qty + '</div></div><div class="cart-qty-controls"><button class="qty-btn" onclick="changeQty(' + i + ',-1)">−</button><span class="qty-value">' + c.qty + '</span><button class="qty-btn" onclick="changeQty(' + i + ',1)">+</button></div><button class="cart-item-remove" onclick="removeCartItem(' + i + ')"><i class="fas fa-trash"></i></button></div>').join('');
  updateCartTotals();
}

function changeQty(i, d) { if (!cart[i]) return; cart[i].qty += d; if (cart[i].qty <= 0) cart.splice(i, 1); renderCart(); }
function removeCartItem(i) { cart.splice(i, 1); renderCart(); }
function clearCartConfirm() { if (!cart.length) return; showConfirm('Clear Cart', 'Cart clear karein?', 'warning', () => { cart = []; renderCart(); }); }

function updateCartTotals() {
  const sub = cart.reduce((s, c) => s + c.price * c.qty, 0);
  const tax = Math.round(sub * (appSettings.taxRate || 0) / 100);
  const total = sub + tax;
  if (document.getElementById('cartSubtotal')) document.getElementById('cartSubtotal').textContent = fmt(sub);
  if (document.getElementById('cartTax')) document.getElementById('cartTax').textContent = fmt(tax);
  if (document.getElementById('cartTotal')) document.getElementById('cartTotal').textContent = fmt(total);
}

function holdOrder() {
  if (!cart.length) { toast('warning', 'Cart empty', 'Pehle items add karein'); return; }
  const held = DB.get('heldOrders', []);
  held.push({ id: uid(), items: JSON.parse(JSON.stringify(cart)), time: nowTime(), user: currentUser.name });
  DB.set('heldOrders', held);
  cart = [];
  renderCart();
  toast('success', 'Order Held', 'Order hold ho gaya');
}

function openCheckout() {
  if (!cart.length) { toast('warning', 'Cart empty', 'Pehle items add karein'); return; }
  const sub = cart.reduce((s, c) => s + c.price * c.qty, 0);
  const tax = Math.round(sub * (appSettings.taxRate || 0) / 100);
  const total = sub + tax;
  const customers = DB.get('customers', []);
  const riders = DB.get('riders', []).filter(r => r.active !== false);
  openModal('<i class="fas fa-cash-register"></i> Checkout',
    '<div class="form-group"><label class="form-label">Customer Name</label><input class="form-control" id="coName" placeholder="Walk-in"></div>' +
    '<div class="form-group"><label class="form-label">Phone</label><input class="form-control" id="coPhone"></div>' +
    '<div class="form-group"><label class="form-label">Payment Mode</label><select class="form-control" id="coPayment"><option value="cash">Cash</option><option value="card">Card</option><option value="online">Online</option></select></div>' +
    '<div class="form-group"><label class="form-label">Rider (optional)</label><select class="form-control" id="coRider"><option value="">-- None --</option>' + riders.map(r => '<option value="' + r.id + '">' + r.name + '</option>').join('') + '</select></div>' +
    '<div class="form-group"><label class="form-label">Discount (Rs)</label><input type="number" class="form-control" id="coDiscount" value="0"></div>' +
    '<div style="background:var(--bg);padding:16px;border-radius:10px;margin-top:16px;"><div class="summary-row"><span>Subtotal</span><span>' + fmt(sub) + '</span></div><div class="summary-row"><span>Tax</span><span>' + fmt(tax) + '</span></div><div class="summary-row total"><span>Total</span><span>' + fmt(total) + '</span></div></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-success" onclick="completeOrder(' + sub + ',' + tax + ',' + total + ')"><i class="fas fa-check"></i> Complete Order</button>', 'lg');
}

function completeOrder(sub, tax, total) {
  const discount = Number(document.getElementById('coDiscount').value) || 0;
  const finalTotal = total - discount;
  const order = { id: Math.floor(Math.random() * 9000) + 1000, items: JSON.parse(JSON.stringify(cart)), subtotal: sub, tax, discount, total: finalTotal, customerName: document.getElementById('coName').value || 'Walk-in', phone: document.getElementById('coPhone').value, payment: document.getElementById('coPayment').value, riderId: document.getElementById('coRider').value || null, date: todayStr(), time: nowTime(), user: currentUser.name, status: 'pending', branch: currentBranch };
  const orders = DB.get('orders', []);
  orders.unshift(order);
  DB.set('orders', orders);
  cart.forEach(c => deductStockForItem(c));
  addOrderToKitchen(order);
  cart = [];
  closeModal();
  renderCart();
  toast('success', 'Order Complete', 'Order #' + order.id + ' — ' + fmt(finalTotal));
  playBeep(1200, 0.15);
  setTimeout(() => playBeep(1500, 0.15), 150);
}

function deductStockForItem(cartItem) {
  const menu = DB.get('menu', []);
  const deals = DB.get('deals', []);
  const item = cartItem.type === 'menu' ? menu.find(m => m.id === cartItem.id) : deals.find(d => d.id === cartItem.id);
  if (!item || !item.ingredients) return;
  const stock = DB.get('stock', []);
  item.ingredients.forEach(ing => {
    let remaining = (ing.qty || 0) * cartItem.qty;
    const batches = stock.filter(s => s.name === ing.name && s.active !== false && s.qty > 0).sort((a,b) => new Date(a.purchaseDate) - new Date(b.purchaseDate));
    batches.forEach(b => {
      if (remaining <= 0) return;
      const take = Math.min(b.qty, remaining);
      b.qty -= take; remaining -= take;
      const ledger = DB.get('stockLedger', []);
      ledger.unshift({ date: todayStr(), time: nowTime(), type: 'SALE', item: b.name, batch: b.batch, qty: -take, user: currentUser.name });
      DB.set('stockLedger', ledger);
    });
  });
  DB.set('stock', stock);
}

function addOrderToKitchen(order) {
  const kitchen = DB.get('kitchenOrders', []);
  kitchen.unshift({ ...order, kitchenStatus: 'pending', addedAt: Date.now() });
  DB.set('kitchenOrders', kitchen);
  playBeep(1000, 0.2);
}

function renderMenu() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><div class="search-box"><i class="fas fa-search"></i><input type="text" id="menuSearch" placeholder="Search..." oninput="filterMenu()"></div><button class="btn btn-primary" onclick="openMenuModal()"><i class="fas fa-plus"></i> Add Item</button></div><div class="table-wrapper"><table><thead><tr><th>Image</th><th>Name</th><th>Price</th><th>Ingredients</th><th>Status</th><th>Actions</th></tr></thead><tbody id="menuTableBody"></tbody></table></div></div>';
  renderMenuTable(DB.get('menu', []));
}

function renderMenuTable(items) {
  const body = document.getElementById('menuTableBody');
  if (!body) return;
  if (!items.length) { body.innerHTML = '<tr><td colspan="6"><div class="empty-state"><i class="fas fa-pizza-slice"></i><h3>No Menu Items</h3></div></td></tr>'; return; }
  body.innerHTML = items.map(m => '<tr><td><img src="' + (m.image || 'https://via.placeholder.com/40') + '" style="width:40px;height:40px;border-radius:8px;object-fit:cover;"></td><td><strong>' + m.name + '</strong></td><td>' + fmt(m.price) + '</td><td>' + (m.ingredients ? m.ingredients.length + ' items' : '—') + '</td><td><span class="badge badge-' + (m.active !== false ? 'success' : 'danger') + '">' + (m.active !== false ? 'Active' : 'Inactive') + '</span></td><td><div class="table-actions"><button class="btn btn-info btn-icon" onclick="openMenuModal(' + m.id + ')"><i class="fas fa-edit"></i></button><button class="btn btn-warning btn-icon" onclick="toggleMenuItem(' + m.id + ')"><i class="fas fa-power-off"></i></button><button class="btn btn-danger btn-icon" onclick="deleteMenuItem(' + m.id + ')"><i class="fas fa-trash"></i></button></div></td></tr>').join('');
}

function filterMenu() {
  const q = document.getElementById('menuSearch').value.toLowerCase();
  renderMenuTable(DB.get('menu', []).filter(m => m.name.toLowerCase().includes(q)));
}

function openMenuModal(id) {
  const items = DB.get('menu', []);
  const m = id ? items.find(x => x.id === id) : null;
  const stock = DB.get('stock', []).filter(s => s.active !== false);
  window._stockOptions = stock;
  openModal('<i class="fas fa-pizza-slice"></i> ' + (m ? 'Edit' : 'Add') + ' Menu Item',
    '<div class="form-group"><label class="form-label">Name</label><input class="form-control" id="miName" value="' + (m ? m.name : '') + '"></div>' +
    '<div class="form-group"><label class="form-label">Price</label><input type="number" class="form-control" id="miPrice" value="' + (m ? m.price : '') + '"></div>' +
    '<div class="form-group"><label class="form-label">Image</label><input class="form-control" id="miImage" value="' + (m ? m.image || '' : '') + '"><input type="file" class="form-control mt-1" accept="image/*" onchange="previewImage(this,\'miImage\')"></div>' +
    '<div class="form-group"><label class="form-label">Ingredients (stock se)</label><div id="ingList"></div><button type="button" class="btn btn-sm btn-secondary mt-1" onclick="addIngredientRow()"><i class="fas fa-plus"></i> Add Ingredient</button></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveMenuItem(' + (m ? m.id : 'null') + ')">Save</button>', 'lg');
  const ingList = document.getElementById('ingList');
  ingList.innerHTML = '';
  if (m && m.ingredients) m.ingredients.forEach(i => addIngredientRow(i.name, i.qty));
  else addIngredientRow();
}

function addIngredientRow(name, qty) {
  const list = document.getElementById('ingList');
  const row = document.createElement('div');
  row.style.cssText = 'display:flex;gap:8px;margin-bottom:8px;';
  row.innerHTML = '<select class="form-control ing-name"><option value="">-- Select Stock --</option>' + (window._stockOptions || []).map(s => '<option value="' + s.name + '"' + (s.name === name ? ' selected' : '') + '>' + s.name + '</option>').join('') + '</select><input type="number" class="form-control ing-qty" style="max-width:100px;" placeholder="Qty" value="' + (qty || '') + '"><button class="btn btn-danger btn-icon" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>';
  list.appendChild(row);
}

function saveMenuItem(id) {
  const name = document.getElementById('miName').value.trim();
  const price = Number(document.getElementById('miPrice').value);
  if (!name || !price) { toast('danger', 'Error', 'Name aur price zaroori'); return; }
  const ingredients = [];
  document.querySelectorAll('#ingList > div').forEach(r => {
    const n = r.querySelector('.ing-name').value;
    const q = Number(r.querySelector('.ing-qty').value);
    if (n && q) ingredients.push({ name: n, qty: q });
  });
  let items = DB.get('menu', []);
  if (id) { const idx = items.findIndex(x => x.id === id); items[idx] = { ...items[idx], name, price, image: document.getElementById('miImage').value, ingredients }; }
  else items.push({ id: uid(), name, price, image: document.getElementById('miImage').value, ingredients, active: true });
  DB.set('menu', items);
  closeModal(); renderMenu();
  toast('success', 'Saved', 'Menu item save ho gaya');
}

function toggleMenuItem(id) { let items = DB.get('menu', []); const m = items.find(x => x.id === id); if (m) m.active = m.active === false ? true : false; DB.set('menu', items); renderMenu(); }

function deleteMenuItem(id) {
  showConfirm('Delete', 'Menu item delete karein?', 'danger', () => {
    DB.set('menu', DB.get('menu', []).filter(x => x.id !== id));
    renderMenu();
    toast('success', 'Deleted', 'Item delete ho gaya');
  });
}

function previewImage(input, targetId) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = e => { document.getElementById(targetId).value = e.target.result; };
    reader.readAsDataURL(input.files[0]);
  }
}

function renderDeals() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><div class="search-box"><i class="fas fa-search"></i><input type="text" id="dealSearch" placeholder="Search deals..." oninput="filterDeals()"></div><button class="btn btn-primary" onclick="openDealModal()"><i class="fas fa-plus"></i> Add Deal</button></div><div class="table-wrapper"><table><thead><tr><th>Image</th><th>Name</th><th>Type</th><th>Price</th><th>Status</th><th>Actions</th></tr></thead><tbody id="dealsTableBody"></tbody></table></div></div>';
  renderDealsTable(DB.get('deals', []));
}

function renderDealsTable(deals) {
  const body = document.getElementById('dealsTableBody');
  if (!body) return;
  if (!deals.length) { body.innerHTML = '<tr><td colspan="6"><div class="empty-state"><i class="fas fa-tags"></i><h3>No Deals</h3></div></td></tr>'; return; }
  body.innerHTML = deals.map(d => '<tr><td><img src="' + (d.image || 'https://via.placeholder.com/40') + '" style="width:40px;height:40px;border-radius:8px;object-fit:cover;"></td><td><strong>' + d.name + '</strong></td><td><span class="badge badge-info">' + d.type + '</span></td><td>' + fmt(d.price) + '</td><td><span class="badge badge-' + (d.active !== false ? 'success' : 'danger') + '">' + (d.active !== false ? 'Active' : 'Inactive') + '</span></td><td><div class="table-actions"><button class="btn btn-info btn-icon" onclick="openDealModal(' + d.id + ')"><i class="fas fa-edit"></i></button><button class="btn btn-danger btn-icon" onclick="deleteDeal(' + d.id + ')"><i class="fas fa-trash"></i></button></div></td></tr>').join('');
}

function filterDeals() { const q = document.getElementById('dealSearch').value.toLowerCase(); renderDealsTable(DB.get('deals', []).filter(d => d.name.toLowerCase().includes(q))); }

function openDealModal(id) {
  const deals = DB.get('deals', []);
  const d = id ? deals.find(x => x.id === id) : null;
  openModal('<i class="fas fa-tags"></i> ' + (d ? 'Edit' : 'Add') + ' Deal',
    '<div class="form-group"><label class="form-label">Name</label><input class="form-control" id="diName" value="' + (d ? d.name : '') + '"></div>' +
    '<div class="form-group"><label class="form-label">Price</label><input type="number" class="form-control" id="diPrice" value="' + (d ? d.price : '') + '"></div>' +
    '<div class="form-group"><label class="form-label">Type</label><select class="form-control" id="diType"><option value="sunday"' + (d && d.type==='sunday'?' selected':'') + '>Sunday</option><option value="time"' + (d && d.type==='time'?' selected':'') + '>Time</option><option value="midnight"' + (d && d.type==='midnight'?' selected':'') + '>Midnight</option><option value="custom"' + (d && d.type==='custom'?' selected':'') + '>Custom</option></select></div>' +
    '<div class="form-row"><div class="form-group"><label class="form-label">Start</label><input type="time" class="form-control" id="diStart" value="' + (d ? d.startTime || '' : '') + '"></div><div class="form-group"><label class="form-label">End</label><input type="time" class="form-control" id="diEnd" value="' + (d ? d.endTime || '' : '') + '"></div></div>' +
    '<div class="form-group"><label class="form-label">Image</label><input class="form-control" id="diImage" value="' + (d ? d.image || '' : '') + '"><input type="file" class="form-control mt-1" accept="image/*" onchange="previewImage(this,\'diImage\')"></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveDeal(' + (d ? d.id : 'null') + ')">Save</button>', 'lg');
}

function saveDeal(id) {
  const name = document.getElementById('diName').value.trim();
  const price = Number(document.getElementById('diPrice').value);
  if (!name || !price) { toast('danger', 'Error', 'Name aur price zaroori'); return; }
  let deals = DB.get('deals', []);
  const data = { name, price, type: document.getElementById('diType').value, startTime: document.getElementById('diStart').value, endTime: document.getElementById('diEnd').value, image: document.getElementById('diImage').value, active: true };
  if (id) { const i = deals.findIndex(x => x.id === id); deals[i] = { ...deals[i], ...data }; }
  else deals.push({ id: uid(), ...data });
  DB.set('deals', deals);
  closeModal(); renderDeals();
  toast('success', 'Saved', 'Deal save ho gaya');
}

function deleteDeal(id) { showConfirm('Delete', 'Deal delete karein?', 'danger', () => { DB.set('deals', DB.get('deals', []).filter(x => x.id !== id)); renderDeals(); toast('success', 'Deleted', 'Deal delete ho gaya'); }); }

function renderInventory() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><div class="search-box"><i class="fas fa-search"></i><input type="text" id="invSearch" placeholder="Search stock..." oninput="filterInventory()"></div><button class="btn btn-primary" onclick="openStockEntryModal()"><i class="fas fa-plus"></i> Stock Entry</button><button class="btn btn-info" onclick="openStockTransferModal()"><i class="fas fa-exchange-alt"></i> Transfer</button><button class="btn btn-secondary" onclick="showStockLedger()"><i class="fas fa-book"></i> Ledger</button></div><div class="table-wrapper"><table><thead><tr><th>Item</th><th>Batch</th><th>Qty</th><th>Cost</th><th>Status</th><th>Actions</th></tr></thead><tbody id="inventoryTableBody"></tbody></table></div></div>';
  renderInventoryTable(DB.get('stock', []));
}

function renderInventoryTable(stock) {
  const body = document.getElementById('inventoryTableBody');
  if (!body) return;
  if (!stock.length) { body.innerHTML = '<tr><td colspan="6"><div class="empty-state"><i class="fas fa-boxes"></i><h3>No Stock</h3></div></td></tr>'; return; }
  body.innerHTML = stock.map(s => '<tr><td><strong>' + s.name + '</strong></td><td>' + (s.batch || '—') + '</td><td>' + s.qty + '</td><td>' + fmt(s.cost || 0) + '</td><td><span class="badge badge-' + (s.active !== false ? 'success' : 'danger') + '">' + (s.active !== false ? 'Active' : 'Inactive') + '</span></td><td><div class="table-actions"><button class="btn btn-warning btn-icon" onclick="toggleBatch(' + s.id + ')"><i class="fas fa-power-off"></i></button><button class="btn btn-danger btn-icon" onclick="deleteStock(' + s.id + ')"><i class="fas fa-trash"></i></button></div></td></tr>').join('');
}

function filterInventory() { const q = document.getElementById('invSearch').value.toLowerCase(); renderInventoryTable(DB.get('stock', []).filter(s => s.name.toLowerCase().includes(q))); }

function openStockEntryModal() {
  openModal('<i class="fas fa-box"></i> Stock Entry',
    '<div class="form-group"><label class="form-label">Item Name</label><input class="form-control" id="stName"></div>' +
    '<div class="form-row"><div class="form-group"><label class="form-label">Batch</label><input class="form-control" id="stBatch" value="B' + Date.now().toString().slice(-6) + '"></div><div class="form-group"><label class="form-label">Qty</label><input type="number" class="form-control" id="stQty"></div></div>' +
    '<div class="form-row"><div class="form-group"><label class="form-label">Cost</label><input type="number" class="form-control" id="stCost"></div><div class="form-group"><label class="form-label">Date</label><input type="date" class="form-control" id="stDate" value="' + todayStr() + '"></div></div>' +
    '<div class="form-group"><label class="form-label">Expiry</label><input type="date" class="form-control" id="stExpiry"></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveStockEntry()">Save</button>');
}

function saveStockEntry() {
  const name = document.getElementById('stName').value.trim();
  const qty = Number(document.getElementById('stQty').value);
  if (!name || !qty) { toast('danger', 'Error', 'Name aur qty zaroori'); return; }
  const stock = DB.get('stock', []);
  const batch = document.getElementById('stBatch').value;
  stock.push({ id: uid(), name, batch, qty, cost: Number(document.getElementById('stCost').value) || 0, purchaseDate: document.getElementById('stDate').value, expiry: document.getElementById('stExpiry').value, active: true });
  DB.set('stock', stock);
  const ledger = DB.get('stockLedger', []);
  ledger.unshift({ date: todayStr(), time: nowTime(), type: 'PURCHASE', item: name, batch, qty, user: currentUser.name });
  DB.set('stockLedger', ledger);
  closeModal(); renderInventory();
  toast('success', 'Saved', 'Stock save ho gayi');
}

function toggleBatch(id) { const stock = DB.get('stock', []); const s = stock.find(x => x.id === id); if (s) s.active = s.active === false ? true : false; DB.set('stock', stock); renderInventory(); }

function deleteStock(id) { showConfirm('Delete', 'Stock delete karein?', 'danger', () => { DB.set('stock', DB.get('stock', []).filter(x => x.id !== id)); renderInventory(); toast('success', 'Deleted', 'Stock delete ho gayi'); }); }

function openStockTransferModal() {
  const branches = DB.get('branches', []);
  const stock = DB.get('stock', []).filter(s => s.active !== false && s.qty > 0);
  openModal('<i class="fas fa-exchange-alt"></i> Stock Transfer',
    '<div class="form-group"><label class="form-label">Item</label><select class="form-control" id="trItem">' + stock.map(s => '<option value="' + s.id + '">' + s.name + ' (Batch ' + s.batch + ') — Qty ' + s.qty + '</option>').join('') + '</select></div>' +
    '<div class="form-group"><label class="form-label">To Branch</label><select class="form-control" id="trBranch">' + branches.filter(b => b.id !== currentBranch).map(b => '<option value="' + b.id + '">' + b.name + '</option>').join('') + '</select></div>' +
    '<div class="form-group"><label class="form-label">Qty</label><input type="number" class="form-control" id="trQty"></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-info" onclick="saveStockTransfer()">Transfer</button>');
}

function saveStockTransfer() {
  const itemId = Number(document.getElementById('trItem').value);
  const toBranch = Number(document.getElementById('trBranch').value);
  const qty = Number(document.getElementById('trQty').value);
  if (!itemId || !qty) { toast('danger', 'Error', 'Item aur qty zaroori'); return; }
  const stock = DB.get('stock', []);
  const item = stock.find(x => x.id === itemId);
  if (!item || item.qty < qty) { toast('danger', 'Error', 'Stock kam hai'); return; }
  item.qty -= qty;
  stock.push({ ...item, id: uid(), qty, batch: item.batch + '-T' + toBranch });
  DB.set('stock', stock);
  const transfers = DB.get('stockTransfers', []);
  transfers.unshift({ date: todayStr(), time: nowTime(), item: item.name, batch: item.batch, qty, from: currentBranch, to: toBranch, user: currentUser.name });
  DB.set('stockTransfers', transfers);
  closeModal(); renderInventory();
  toast('success', 'Transferred', 'Stock transfer ho gayi');
}

function showStockLedger() {
  const ledger = DB.get('stockLedger', []);
  openModal('<i class="fas fa-book"></i> Stock Ledger',
    '<div class="table-wrapper"><table><thead><tr><th>Date</th><th>Type</th><th>Item</th><th>Batch</th><th>Qty</th><th>User</th></tr></thead><tbody>' + (ledger.length ? ledger.map(l => '<tr><td>' + l.date + '</td><td><span class="badge badge-' + (l.qty > 0 ? 'success' : 'danger') + '">' + l.type + '</span></td><td>' + l.item + '</td><td>' + (l.batch || '—') + '</td><td>' + l.qty + '</td><td>' + l.user + '</td></tr>').join('') : '<tr><td colspan="6" class="text-center">No entries</td></tr>') + '</tbody></table></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Close</button>', 'lg');
}

function renderExpense() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><div class="search-box"><i class="fas fa-search"></i><input type="text" id="expSearch" placeholder="Search..." oninput="filterExpenses()"></div><button class="btn btn-primary" onclick="openExpenseModal()"><i class="fas fa-plus"></i> Add Expense</button></div><div class="table-wrapper"><table><thead><tr><th>Date</th><th>Category</th><th>Description</th><th>Amount</th><th>Mode</th><th>Actions</th></tr></thead><tbody id="expTableBody"></tbody></table></div></div>';
  renderExpenseTable(DB.get('expenses', []));
}

function renderExpenseTable(expenses) {
  const body = document.getElementById('expTableBody');
  if (!body) return;
  if (!expenses.length) { body.innerHTML = '<tr><td colspan="6"><div class="empty-state"><i class="fas fa-receipt"></i><h3>No Expenses</h3></div></td></tr>'; return; }
  body.innerHTML = expenses.map(e => '<tr><td>' + e.date + '</td><td><span class="badge badge-info">' + e.category + '</span></td><td>' + e.description + '</td><td><strong class="text-danger">' + fmt(e.amount) + '</strong></td><td>' + e.paymentMode + '</td><td><button class="btn btn-danger btn-icon" onclick="deleteExpense(' + e.id + ')"><i class="fas fa-trash"></i></button></td></tr>').join('');
}

function filterExpenses() { const q = document.getElementById('expSearch').value.toLowerCase(); renderExpenseTable(DB.get('expenses', []).filter(e => e.description.toLowerCase().includes(q) || e.category.toLowerCase().includes(q))); }

function openExpenseModal() {
  openModal('<i class="fas fa-receipt"></i> Add Expense',
    '<div class="form-group"><label class="form-label">Category</label><select class="form-control" id="exCat"><option value="raw">Raw Material</option><option value="utility">Utility</option><option value="staff">Staff</option><option value="delivery">Delivery</option><option value="packaging">Packaging</option><option value="maintenance">Maintenance</option><option value="misc">Miscellaneous</option><option value="raw_only">Raw Expense (Record Only)</option></select></div>' +
    '<div class="form-group"><label class="form-label">Description</label><input class="form-control" id="exDesc"></div>' +
    '<div class="form-row"><div class="form-group"><label class="form-label">Amount</label><input type="number" class="form-control" id="exAmt"></div><div class="form-group"><label class="form-label">Date</label><input type="date" class="form-control" id="exDate" value="' + todayStr() + '"></div></div>' +
    '<div class="form-group"><label class="form-label">Mode</label><select class="form-control" id="exPay"><option value="cash">Cash</option><option value="bank">Bank</option></select></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveExpense()">Save</button>');
}

function saveExpense() {
  const desc = document.getElementById('exDesc').value.trim();
  const amount = Number(document.getElementById('exAmt').value);
  if (!desc || !amount) { toast('danger', 'Error', 'Description aur amount zaroori'); return; }
  const expenses = DB.get('expenses', []);
  expenses.unshift({ id: uid(), date: document.getElementById('exDate').value, category: document.getElementById('exCat').value, description: desc, amount, paymentMode: document.getElementById('exPay').value, user: currentUser.name });
  DB.set('expenses', expenses);
  closeModal(); renderExpense();
  toast('success', 'Saved', 'Expense save ho gaya');
}

function deleteExpense(id) { showConfirm('Delete', 'Expense delete karein?', 'danger', () => { DB.set('expenses', DB.get('expenses', []).filter(x => x.id !== id)); renderExpense(); toast('success', 'Deleted', 'Expense delete ho gaya'); }); }

function renderAssets() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><button class="btn btn-primary" onclick="openAssetModal()"><i class="fas fa-plus"></i> Add Asset</button></div><div class="table-wrapper"><table><thead><tr><th>Image</th><th>Name</th><th>Date</th><th>Qty</th><th>Price</th><th>Actions</th></tr></thead><tbody id="assetsTableBody"></tbody></table></div></div>';
  const body = document.getElementById('assetsTableBody');
  const assets = DB.get('assets', []);
  if (!assets.length) { body.innerHTML = '<tr><td colspan="6"><div class="empty-state"><i class="fas fa-chair"></i><h3>No Assets</h3></div></td></tr>'; return; }
  body.innerHTML = assets.map(a => '<tr><td><img src="' + (a.image || 'https://via.placeholder.com/40') + '" style="width:40px;height:40px;border-radius:8px;"></td><td>' + a.name + '</td><td>' + a.date + '</td><td>' + a.qty + '</td><td>' + fmt(a.price) + '</td><td><button class="btn btn-danger btn-icon" onclick="deleteAsset(' + a.id + ')"><i class="fas fa-trash"></i></button></td></tr>').join('');
}

function openAssetModal() {
  openModal('<i class="fas fa-chair"></i> Add Asset',
    '<div class="form-group"><label class="form-label">Name</label><input class="form-control" id="asName"></div>' +
    '<div class="form-row"><div class="form-group"><label class="form-label">Date</label><input type="date" class="form-control" id="asDate" value="' + todayStr() + '"></div><div class="form-group"><label class="form-label">Qty</label><input type="number" class="form-control" id="asQty"></div></div>' +
    '<div class="form-group"><label class="form-label">Price</label><input type="number" class="form-control" id="asPrice"></div>' +
    '<div class="form-group"><label class="form-label">Image</label><input class="form-control" id="asImage"><input type="file" class="form-control mt-1" accept="image/*" onchange="previewImage(this,\'asImage\')"></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveAsset()">Save</button>');
}

function saveAsset() {
  const name = document.getElementById('asName').value.trim();
  if (!name) { toast('danger', 'Error', 'Name zaroori'); return; }
  const assets = DB.get('assets', []);
  assets.push({ id: uid(), name, date: document.getElementById('asDate').value, qty: Number(document.getElementById('asQty').value) || 1, price: Number(document.getElementById('asPrice').value) || 0, image: document.getElementById('asImage').value });
  DB.set('assets', assets);
  closeModal(); renderAssets();
  toast('success', 'Saved', 'Asset save ho gaya');
}

function deleteAsset(id) { showConfirm('Delete', 'Asset delete karein?', 'danger', () => { DB.set('assets', DB.get('assets', []).filter(x => x.id !== id)); renderAssets(); }); }

function renderStaff() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><button class="btn btn-primary" onclick="openStaffModal()"><i class="fas fa-plus"></i> Add Staff</button></div><div class="table-wrapper"><table><thead><tr><th>Name</th><th>Role</th><th>Type</th><th>Salary</th><th>Status</th><th>Actions</th></tr></thead><tbody id="staffTableBody"></tbody></table></div></div>';
  const body = document.getElementById('staffTableBody');
  const staff = DB.get('staff', []);
  if (!staff.length) { body.innerHTML = '<tr><td colspan="6"><div class="empty-state"><i class="fas fa-users"></i><h3>No Staff</h3></div></td></tr>'; return; }
  body.innerHTML = staff.map(s => '<tr><td>' + s.name + '</td><td>' + s.role + '</td><td><span class="badge badge-info">' + s.type + '</span></td><td>' + fmt(s.salary) + '</td><td><span class="badge badge-' + (s.active !== false ? 'success' : 'danger') + '">' + (s.active !== false ? 'Active' : 'Inactive') + '</span></td><td><button class="btn btn-danger btn-icon" onclick="deleteStaff(' + s.id + ')"><i class="fas fa-trash"></i></button></td></tr>').join('');
}

function openStaffModal() {
  openModal('<i class="fas fa-user-plus"></i> Add Staff',
    '<div class="form-group"><label class="form-label">Name</label><input class="form-control" id="sfName"></div>' +
    '<div class="form-group"><label class="form-label">Role</label><input class="form-control" id="sfRole" placeholder="Chef / Waiter / Manager"></div>' +
    '<div class="form-row"><div class="form-group"><label class="form-label">Type</label><select class="form-control" id="sfType"><option value="full">Full-day</option><option value="part">Part-time</option></select></div><div class="form-group"><label class="form-label">Salary</label><input type="number" class="form-control" id="sfSalary"></div></div>' +
    '<div class="form-group"><label class="form-label">Salary Basis</label><select class="form-control" id="sfBasis"><option value="26">26 days</option><option value="30">30 days</option></select></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveStaff()">Save</button>');
}

function saveStaff() {
  const name = document.getElementById('sfName').value.trim();
  if (!name) { toast('danger', 'Error', 'Name zaroori'); return; }
  const staff = DB.get('staff', []);
  staff.push({ id: uid(), name, role: document.getElementById('sfRole').value, type: document.getElementById('sfType').value, salary: Number(document.getElementById('sfSalary').value) || 0, basis: Number(document.getElementById('sfBasis').value), active: true });
  DB.set('staff', staff);
  closeModal(); renderStaff();
  toast('success', 'Saved', 'Staff save ho gaya');
}

function deleteStaff(id) { showConfirm('Delete', 'Staff delete karein?', 'danger', () => { DB.set('staff', DB.get('staff', []).filter(x => x.id !== id)); renderStaff(); }); }

function renderRider() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><button class="btn btn-primary" onclick="openRiderModal()"><i class="fas fa-plus"></i> Add Rider</button></div><div class="table-wrapper"><table><thead><tr><th>Name</th><th>Phone</th><th>Deliveries</th><th>KM</th><th>Actions</th></tr></thead><tbody id="riderTableBody"></tbody></table></div></div>';
  const body = document.getElementById('riderTableBody');
  const riders = DB.get('riders', []);
  if (!riders.length) { body.innerHTML = '<tr><td colspan="5"><div class="empty-state"><i class="fas fa-motorcycle"></i><h3>No Riders</h3></div></td></tr>'; return; }
  body.innerHTML = riders.map(r => '<tr><td>' + r.name + '</td><td>' + r.phone + '</td><td>' + (r.deliveries || 0) + '</td><td>' + (r.km || 0) + '</td><td><button class="btn btn-danger btn-icon" onclick="deleteRider(' + r.id + ')"><i class="fas fa-trash"></i></button></td></tr>').join('');
}

function openRiderModal() {
  openModal('<i class="fas fa-motorcycle"></i> Add Rider',
    '<div class="form-group"><label class="form-label">Name</label><input class="form-control" id="rdName"></div>' +
    '<div class="form-group"><label class="form-label">Phone</label><input class="form-control" id="rdPhone"></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveRider()">Save</button>');
}

function saveRider() {
  const name = document.getElementById('rdName').value.trim();
  if (!name) { toast('danger', 'Error', 'Name zaroori'); return; }
  const riders = DB.get('riders', []);
  riders.push({ id: uid(), name, phone: document.getElementById('rdPhone').value, deliveries: 0, km: 0, active: true });
  DB.set('riders', riders);
  closeModal(); renderRider();
  toast('success', 'Saved', 'Rider save ho gaya');
}

function deleteRider(id) { showConfirm('Delete', 'Rider delete karein?', 'danger', () => { DB.set('riders', DB.get('riders', []).filter(x => x.id !== id)); renderRider(); }); }

function renderKitchen() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><h3 style="font-size:16px;font-weight:700;"><i class="fas fa-fire text-primary"></i> Kitchen Orders</h3></div><div class="kitchen-grid" id="kitchenGrid"></div></div>';
  const grid = document.getElementById('kitchenGrid');
  const kitchen = DB.get('kitchenOrders', []);
  if (!kitchen.length) { grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><i class="fas fa-utensils"></i><h3>No Orders</h3></div>'; return; }
  grid.innerHTML = kitchen.map(o => '<div class="kitchen-card ' + o.kitchenStatus + '"><div class="kitchen-card-header"><span class="kitchen-order-num">#' + o.id + '</span><span class="kitchen-time">' + o.time + '</span></div><div class="kitchen-items">' + o.items.map(i => '<div class="kitchen-item"><span>' + i.name + '</span><span class="qty">×' + i.qty + '</span></div>').join('') + '</div><div class="kitchen-card-footer"><button class="btn btn-info btn-sm" onclick="updateKitchenStatus(' + o.id + ',\'cooking\')">Cooking</button><button class="btn btn-success btn-sm" onclick="updateKitchenStatus(' + o.id + ',\'ready\')">Ready</button></div></div>').join('');
}

function updateKitchenStatus(id, status) { const kitchen = DB.get('kitchenOrders', []); const o = kitchen.find(x => x.id === id); if (o) { o.kitchenStatus = status; DB.set('kitchenOrders', kitchen); renderKitchen(); playBeep(700, 0.1); } }

function renderShift() {
  const content = document.getElementById('pageContent');
  const shift = DB.get('activeShift', null);
  const sales = shift ? DB.get('orders', []).filter(o => o.date === todayStr() && o.user === shift.user).reduce((s, o) => s + o.total, 0) : 0;
  const expense = shift ? DB.get('expenses', []).filter(e => e.date === todayStr() && e.user === shift.user).reduce((s, e) => s + e.amount, 0) : 0;
  const cashInHand = shift ? (shift.opening + sales - expense) : 0;
  content.innerHTML = '<div class="animate-fade-up"><div class="stats-grid"><div class="stat-card"><div class="stat-icon success"><i class="fas fa-wallet"></i></div><div class="stat-info"><h4>' + fmt(shift ? shift.opening : 0) + '</h4><p>Opening</p></div></div><div class="stat-card"><div class="stat-icon primary"><i class="fas fa-cash-register"></i></div><div class="stat-info"><h4>' + fmt(sales) + '</h4><p>Sales</p></div></div><div class="stat-card"><div class="stat-icon warning"><i class="fas fa-receipt"></i></div><div class="stat-info"><h4>' + fmt(expense) + '</h4><p>Expenses</p></div></div><div class="stat-card"><div class="stat-icon info"><i class="fas fa-hand-holding-usd"></i></div><div class="stat-info"><h4>' + fmt(cashInHand) + '</h4><p>Cash in Hand</p></div></div></div><div class="card mt-3"><div class="card-header"><h3 class="card-title"><i class="fas fa-clock"></i> Shift Control</h3></div><div class="text-center" style="padding:20px;">' + (shift ? '<p class="text-muted mb-2">Started: ' + shift.startTime + '</p><button class="btn btn-warning" onclick="cashToOwner()"><i class="fas fa-hand-holding-usd"></i> Cash to Owner</button> <button class="btn btn-danger" onclick="closeShift()"><i class="fas fa-stop"></i> End Shift</button>' : '<p class="text-muted mb-2">Shift closed</p><button class="btn btn-success btn-lg" onclick="startShift()"><i class="fas fa-play"></i> Start Shift</button>') + '</div></div></div>';
}

function startShift() {
  openModal('<i class="fas fa-play"></i> Start Shift', '<div class="form-group"><label class="form-label">Opening Balance</label><input type="number" class="form-control" id="shOpening" value="0"></div>', '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-success" onclick="confirmStartShift()">Start</button>');
}

function confirmStartShift() {
  const opening = Number(document.getElementById('shOpening').value) || 0;
  DB.set('activeShift', { user: currentUser.name, opening, startTime: nowTime(), startDate: todayStr() });
  closeModal(); renderShift(); updateShiftBadge();
  toast('success', 'Shift Started', 'Opening: ' + fmt(opening));
  playBeep(1000, 0.2);
}

function cashToOwner() {
  openModal('<i class="fas fa-hand-holding-usd"></i> Cash to Owner', '<div class="form-group"><label class="form-label">Amount</label><input type="number" class="form-control" id="co2Amount"></div>', '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-warning" onclick="confirmCashToOwner()">Move</button>');
}

function confirmCashToOwner() {
  const amt = Number(document.getElementById('co2Amount').value);
  if (!amt) { toast('danger', 'Error', 'Amount zaroori'); return; }
  const cashMoves = DB.get('cashMoves', []);
  cashMoves.unshift({ date: todayStr(), time: nowTime(), amount: amt, user: currentUser.name });
  DB.set('cashMoves', cashMoves);
  closeModal(); renderShift();
  toast('success', 'Cash Moved', fmt(amt) + ' owner ko diya');
}

function closeShift() {
  showConfirm('End Shift', 'Shift close karein? Dashboard zero ho jayega aur backup ban jayega.', 'warning', () => {
    const shift = DB.get('activeShift');
    if (!shift) return;
    const sales = DB.get('orders', []).filter(o => o.date === todayStr() && o.user === shift.user).reduce((s, o) => s + o.total, 0);
    const expense = DB.get('expenses', []).filter(e => e.date === todayStr() && e.user === shift.user).reduce((s, e) => s + e.amount, 0);
    const history = DB.get('shiftHistory', []);
    history.unshift({ ...shift, sales, expense, cashInHand: shift.opening + sales - expense, endTime: nowTime(), endDate: todayStr() });
    DB.set('shiftHistory', history);
    DB.remove('activeShift');
    autoBackup();
    renderShift(); updateShiftBadge();
    toast('success', 'Shift Closed', 'Data save + auto backup ho gaya');
    playBeep(600, 0.3);
  });
}

function autoBackup() {
  const data = {};
  Object.keys(localStorage).filter(k => k.startsWith('pizzaPOS_')).forEach(k => { data[k] = localStorage.getItem(k); });
  DB.set('lastBackup', { date: todayStr(), time: nowTime(), data });
  toast('info', 'Auto Backup', 'Backup save ho gaya');
}

function renderReports() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><select class="filter-select" id="reportType" onchange="loadReport()"><option value="sales">Sales Report</option><option value="profitloss">Profit & Loss</option><option value="stockval">Stock Valuation</option><option value="dayclose">Day Close</option></select><button class="btn btn-primary" onclick="loadReport()"><i class="fas fa-filter"></i> Apply</button><button class="btn btn-secondary" onclick="window.print()"><i class="fas fa-print"></i> Print</button></div><div class="card" id="reportArea"></div></div>';
  loadReport();
}

function loadReport() {
  const type = document.getElementById('reportType').value;
  const area = document.getElementById('reportArea');
  const orders = DB.get('orders', []);
  const expenses = DB.get('expenses', []);
  if (type === 'sales') {
    const total = orders.reduce((s, o) => s + o.total, 0);
    area.innerHTML = '<div class="card-header"><h3 class="card-title"><i class="fas fa-chart-line"></i> Sales Report</h3></div><p>Total Orders: <strong>' + orders.length + '</strong></p><p>Total Sales: <strong class="text-primary">' + fmt(total) + '</strong></p>';
  } else if (type === 'profitloss') {
    const sales = orders.reduce((s, o) => s + o.total, 0);
    const exp = expenses.reduce((s, e) => s + e.amount, 0);
    const profit = sales - exp;
    area.innerHTML = '<div class="card-header"><h3 class="card-title"><i class="fas fa-chart-pie"></i> Profit & Loss</h3></div><p>Sales: <strong class="text-success">' + fmt(sales) + '</strong></p><p>Expenses: <strong class="text-danger">' + fmt(exp) + '</strong></p><p style="font-size:18px;">Profit: <strong class="' + (profit >= 0 ? 'text-success' : 'text-danger') + '">' + fmt(profit) + '</strong></p>';
  } else if (type === 'stockval') {
    const stock = DB.get('stock', []);
    const val = stock.reduce((s, x) => s + (x.qty * (x.cost || 0)), 0);
    area.innerHTML = '<div class="card-header"><h3 class="card-title"><i class="fas fa-boxes"></i> Stock Valuation</h3></div><p>Total Items: <strong>' + stock.length + '</strong></p><p>Total Value: <strong class="text-primary">' + fmt(val) + '</strong></p>';
  } else if (type === 'dayclose') {
    const today = todayStr();
    const tOrders = orders.filter(o => o.date === today);
    const tExp = expenses.filter(e => e.date === today);
    area.innerHTML = '<div class="card-header"><h3 class="card-title"><i class="fas fa-calendar-day"></i> Day Close — ' + today + '</h3></div><p>Orders: <strong>' + tOrders.length + '</strong></p><p>Sales: <strong>' + fmt(tOrders.reduce((s,o)=>s+o.total,0)) + '</strong></p><p>Expenses: <strong>' + fmt(tExp.reduce((s,e)=>s+e.amount,0)) + '</strong></p>';
  }
}

function renderUsers() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><button class="btn btn-primary" onclick="openUserModal()"><i class="fas fa-user-plus"></i> Create User</button></div><div class="table-wrapper"><table><thead><tr><th>Name</th><th>Username</th><th>Role</th><th>Opening</th><th>Status</th><th>Actions</th></tr></thead><tbody id="usersTableBody"></tbody></table></div></div>';
  const body = document.getElementById('usersTableBody');
  body.innerHTML = DB.get('users', []).map(u => '<tr><td>' + u.name + '</td><td>' + u.username + '</td><td><span class="badge badge-info">' + u.role + '</span></td><td>' + fmt(u.openingBalance) + '</td><td><span class="badge badge-' + (u.active ? 'success' : 'danger') + '">' + (u.active ? 'Active' : 'Inactive') + '</span></td><td><button class="btn btn-danger btn-icon" onclick="deleteUser(' + u.id + ')"><i class="fas fa-trash"></i></button></td></tr>').join('');
}

function openUserModal() {
  const perms = ['dashboard','pos','menu','deals','inventory','expense','assets','staff','rider','kitchen','shift','reports','customers','users','branches','settings'];
  openModal('<i class="fas fa-user-plus"></i> Create User',
    '<div class="form-row"><div class="form-group"><label class="form-label">Name</label><input class="form-control" id="usName"></div><div class="form-group"><label class="form-label">Username</label><input class="form-control" id="usUsername"></div></div>' +
    '<div class="form-row"><div class="form-group"><label class="form-label">Password</label><input type="password" class="form-control" id="usPassword"></div><div class="form-group"><label class="form-label">Opening Balance</label><input type="number" class="form-control" id="usOpening" value="0"></div></div>' +
    '<div class="form-group"><label class="form-label">Permissions</label><div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">' + perms.map(p => '<label class="checkbox-group"><input type="checkbox" class="us-perm" value="' + p + '" checked> ' + p + '</label>').join('') + '</div></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveUser()">Create</button>', 'lg');
}

function saveUser() {
  const name = document.getElementById('usName').value.trim();
  const username = document.getElementById('usUsername').value.trim();
  const password = document.getElementById('usPassword').value;
  if (!name || !username || !password) { toast('danger', 'Error', 'Sab fields zaroori'); return; }
  const permissions = [];
  document.querySelectorAll('.us-perm:checked').forEach(c => permissions.push(c.value));
  const users = DB.get('users', []);
  users.push({ id: uid(), name, username, password, role: 'user', openingBalance: Number(document.getElementById('usOpening').value) || 0, permissions, active: true });
  DB.set('users', users);
  closeModal(); renderUsers();
  toast('success', 'Created', 'User create ho gaya');
}

function deleteUser(id) { showConfirm('Delete', 'User delete karein?', 'danger', () => { DB.set('users', DB.get('users', []).filter(x => x.id !== id)); renderUsers(); }); }

function renderBranches() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><button class="btn btn-primary" onclick="openBranchModal()"><i class="fas fa-plus"></i> Add Branch</button></div><div class="table-wrapper"><table><thead><tr><th>Name</th><th>Address</th><th>Phone</th><th>Status</th><th>Actions</th></tr></thead><tbody id="branchesTableBody"></tbody></table></div></div>';
  const body = document.getElementById('branchesTableBody');
  body.innerHTML = DB.get('branches', []).map(b => '<tr><td>' + b.name + '</td><td>' + (b.address || '—') + '</td><td>' + (b.phone || '—') + '</td><td><span class="badge badge-' + (b.active ? 'success' : 'danger') + '">' + (b.active ? 'Active' : 'Inactive') + '</span></td><td><button class="btn btn-danger btn-icon" onclick="deleteBranch(' + b.id + ')"><i class="fas fa-trash"></i></button></td></tr>').join('');
}

function openBranchModal() {
  openModal('<i class="fas fa-store"></i> Add Branch',
    '<div class="form-group"><label class="form-label">Name</label><input class="form-control" id="brName"></div>' +
    '<div class="form-group"><label class="form-label">Address</label><input class="form-control" id="brAddress"></div>' +
    '<div class="form-group"><label class="form-label">Phone</label><input class="form-control" id="brPhone"></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveBranch()">Save</button>');
}

function saveBranch() {
  const name = document.getElementById('brName').value.trim();
  if (!name) { toast('danger', 'Error', 'Name zaroori'); return; }
  const branches = DB.get('branches', []);
  branches.push({ id: uid(), name, address: document.getElementById('brAddress').value, phone: document.getElementById('brPhone').value, active: true });
  DB.set('branches', branches);
  closeModal(); renderBranches();
}

function deleteBranch(id) { showConfirm('Delete', 'Branch delete karein?', 'danger', () => { DB.set('branches', DB.get('branches', []).filter(x => x.id !== id)); renderBranches(); }); }

function renderCustomers() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="toolbar"><button class="btn btn-primary" onclick="openCustomerModal()"><i class="fas fa-user-plus"></i> Add Customer</button></div><div class="table-wrapper"><table><thead><tr><th>Name</th><th>Phone</th><th>Address</th><th>Points</th><th>Actions</th></tr></thead><tbody id="customersTableBody"></tbody></table></div></div>';
  const body = document.getElementById('customersTableBody');
  const customers = DB.get('customers', []);
  if (!customers.length) { body.innerHTML = '<tr><td colspan="5"><div class="empty-state"><i class="fas fa-user-friends"></i><h3>No Customers</h3></div></td></tr>'; return; }
  body.innerHTML = customers.map(c => '<tr><td>' + c.name + '</td><td>' + c.phone + '</td><td>' + (c.address || '—') + '</td><td>' + (c.points || 0) + '</td><td><button class="btn btn-danger btn-icon" onclick="deleteCustomer(' + c.id + ')"><i class="fas fa-trash"></i></button></td></tr>').join('');
}

function openCustomerModal() {
  openModal('<i class="fas fa-user-plus"></i> Add Customer',
    '<div class="form-group"><label class="form-label">Name</label><input class="form-control" id="cuName"></div>' +
    '<div class="form-group"><label class="form-label">Phone</label><input class="form-control" id="cuPhone"></div>' +
    '<div class="form-group"><label class="form-label">Address</label><input class="form-control" id="cuAddress"></div>',
    '<button class="btn btn-secondary" onclick="closeModal()">Cancel</button><button class="btn btn-primary" onclick="saveCustomer()">Save</button>');
}

function saveCustomer() {
  const name = document.getElementById('cuName').value.trim();
  if (!name) { toast('danger', 'Error', 'Name zaroori'); return; }
  const customers = DB.get('customers', []);
  customers.push({ id: uid(), name, phone: document.getElementById('cuPhone').value, address: document.getElementById('cuAddress').value, points: 0 });
  DB.set('customers', customers);
  closeModal(); renderCustomers();
}

function deleteCustomer(id) { showConfirm('Delete', 'Customer delete karein?', 'danger', () => { DB.set('customers', DB.get('customers', []).filter(x => x.id !== id)); renderCustomers(); }); }

function renderSettings() {
  const content = document.getElementById('pageContent');
  content.innerHTML = '<div class="animate-fade-up"><div class="card"><div class="card-header"><h3 class="card-title"><i class="fas fa-store"></i> Restaurant Info</h3></div><div class="form-row"><div class="form-group"><label class="form-label">Name</label><input class="form-control" id="setRestName" value="' + (appSettings.restaurantName || '') + '"></div><div class="form-group"><label class="form-label">Phone</label><input class="form-control" id="setRestPhone" value="' + (appSettings.phone || '') + '"></div></div><div class="form-group"><label class="form-label">Address</label><input class="form-control" id="setRestAddress" value="' + (appSettings.address || '') + '"></div><button class="btn btn-primary" onclick="saveRestaurantInfo()"><i class="fas fa-save"></i> Save</button></div>' +
    '<div class="card mt-3"><div class="card-header"><h3 class="card-title"><i class="fas fa-percent"></i> Tax</h3></div><div class="form-group"><label class="form-label">Tax Rate (%)</label><input type="number" class="form-control" id="setTaxRate" value="' + (appSettings.taxRate || 0) + '"></div><button class="btn btn-primary" onclick="saveTaxSettings()"><i class="fas fa-save"></i> Save</button></div>' +
    '<div class="card mt-3"><div class="card-header"><h3 class="card-title"><i class="fas fa-database"></i> Backup</h3></div><button class="btn btn-info" onclick="exportBackup()"><i class="fas fa-download"></i> Export</button> <button class="btn btn-warning" onclick="importBackup()"><i class="fas fa-upload"></i> Import</button></div></div>';
}

function saveRestaurantInfo() {
  appSettings.restaurantName = document.getElementById('setRestName').value;
  appSettings.phone = document.getElementById('setRestPhone').value;
  appSettings.address = document.getElementById('setRestAddress').value;
  DB.set('settings', appSettings);
  document.getElementById('sidebarRestaurantName').textContent = appSettings.restaurantName;
  toast('success', 'Saved', 'Settings save ho gayi');
}

function saveTaxSettings() {
  appSettings.taxRate = Number(document.getElementById('setTaxRate').value) || 0;
  DB.set('settings', appSettings);
  toast('success', 'Saved', 'Tax save ho gaya');
}

function exportBackup() {
  const data = {};
  Object.keys(localStorage).filter(k => k.startsWith('pizzaPOS_')).forEach(k => { data[k] = localStorage.getItem(k); });
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'pizzaPOS-backup-' + todayStr() + '.json';
  a.click(); URL.revokeObjectURL(url);
  toast('success', 'Backup', 'Backup download ho gaya');
}

function importBackup() {
  const input = document.createElement('input');
  input.type = 'file'; input.accept = '.json';
  input.onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        Object.keys(data).forEach(k => localStorage.setItem(k, data[k]));
        toast('success', 'Restored', 'Backup restore ho gaya — reload karein');
        setTimeout(() => location.reload(), 1500);
      } catch(err) { toast('danger', 'Error', 'Invalid backup file'); }
    };
    reader.readAsText(file);
  };
  input.click();
}

function openUserMenu() {
  openModal('<i class="fas fa-user"></i> ' + currentUser.name,
    '<p><strong>Role:</strong> ' + currentUser.role + '</p><p><strong>Username:</strong> ' + currentUser.username + '</p><p><strong>Opening:</strong> ' + fmt(currentUser.openingBalance) + '</p>',
    '<button class="btn btn-secondary" onclick="closeModal()">Close</button><button class="btn btn-danger" onclick="closeModal();handleLogout()"><i class="fas fa-sign-out-alt"></i> Logout</button>');
}

function openNotifications() {
  const lowStock = DB.get('stock', []).filter(s => s.qty <= 5 && s.active !== false);
  const html = lowStock.length ? lowStock.map(s => '<div style="padding:10px;border-bottom:1px solid var(--border);"><i class="fas fa-exclamation-triangle text-warning"></i> <strong>' + s.name + '</strong> — Qty: ' + s.qty + '</div>').join('') : '<div class="empty-state" style="padding:30px;"><i class="fas fa-check-circle text-success"></i><p>No notifications</p></div>';
  openModal('<i class="fas fa-bell"></i> Notifications', html, '<button class="btn btn-secondary" onclick="closeModal()">Close</button>');
}

window.addEventListener('DOMContentLoaded', () => {
  initDefaultUsers();
  initDefaultBranches();
  initSettings();
  applyTheme(appSettings.theme || 'light');
  const savedUser = DB.get('currentUser', null);
  if (savedUser) {
    currentUser = savedUser;
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('appContainer').classList.remove('hidden');
    initAppAfterLogin();
  }
  const pwd = document.getElementById('loginPassword');
  if (pwd) pwd.addEventListener('keypress', e => { if (e.key === 'Enter') handleLogin(); });
  document.addEventListener('keydown', e => {
    if (!currentUser) return;
    if (e.key === 'F1') { e.preventDefault(); navigateTo('pos'); }
    if (e.key === 'F2') { e.preventDefault(); navigateTo('menu'); }
    if (e.key === 'F3') { e.preventDefault(); navigateTo('deals'); }
    if (e.key === 'F5') { e.preventDefault(); if (document.getElementById('cartTotal')) openCheckout(); }
    if (e.key === 'Escape') closeModal();
  });
});

console.log('%cPizza POS v1.0 — Developed by Abid', 'color:#e63946;font-size:16px;font-weight:bold;');