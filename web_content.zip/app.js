const $=id=>document.getElementById(id);
function showTab(name){document.querySelectorAll('.panel').forEach(p=>p.classList.toggle('active',p.id===name));document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
$('settingsBtn').addEventListener('click',()=>showTab('settings'));
const fields=['chatUrl','model','imageUrl','videoUrl','audioUrl'];
function load(){fields.forEach(k=>$(k).value=localStorage.getItem('nexus_'+k)||'');}
$('save').addEventListener('click',()=>{fields.forEach(k=>localStorage.setItem('nexus_'+k,$(k).value.trim()));$('settingsStatus').textContent='Réglages enregistrés sur cet appareil.';});
$('generate').addEventListener('click',async()=>{
 const prompt=$('idea').value.trim(), kind=$('kind').value, endpoint=$('chatUrl').value.trim();
 if(!prompt){$('status').textContent='Écris d’abord une idée pour ton univers.';return;}
 if(!endpoint){$('status').textContent='Aucun serveur IA configuré. La génération réelle n’est pas encore activée.';return;}
 $('generate').disabled=true;$('generate').textContent='Connexion…';$('status').textContent='Tentative de connexion au serveur…';
 try{
  const r=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:prompt,prompt:prompt,type:kind,model:$('model').value})});
  if(!r.ok)throw new Error('Erreur HTTP '+r.status);
  const data=await r.json();const answer=data.response||data.answer||data.text||data.message||JSON.stringify(data,null,2);
  $('output').hidden=false;$('output').textContent=answer;$('status').textContent='Réponse reçue du serveur.';
  const item=document.createElement('div');item.className='empty';item.textContent=kind+' — '+prompt.slice(0,90);$('saved').prepend(item);
 }catch(e){$('status').textContent='Connexion impossible : '+e.message+'. Vérifie l’adresse et le format attendu par ton serveur.';}
 finally{$('generate').disabled=false;$('generate').textContent='✦ Générer avec le cerveau IA';}
});
load();