/* العجردي للبرمجة - Local Offline App */
const DB_NAME='alajardi_programming', DB_VERSION=1;
const STORES=['customers','sales','debts','payments','requests','inventory','settings'];
let db, currentPage='home';

const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const money=n=>new Intl.NumberFormat('ar-YE',{maximumFractionDigits:2}).format(Number(n||0));
const now=()=>new Date().toISOString();
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);

function openDB(){
 return new Promise((resolve,reject)=>{
  const r=indexedDB.open(DB_NAME,DB_VERSION);
  r.onupgradeneeded=e=>{db=e.target.result; STORES.forEach(s=>{if(!db.objectStoreNames.contains(s)) db.createObjectStore(s,{keyPath:'id'});});};
  r.onsuccess=e=>{db=e.target.result;resolve(db)}; r.onerror=()=>reject(r.error);
 });
}
function all(store){return new Promise((res,rej)=>{const t=db.transaction(store,'readonly');const q=t.objectStore(store).getAll();q.onsuccess=()=>res(q.result||[]);q.onerror=()=>rej(q.error)})}
function put(store,obj){return new Promise((res,rej)=>{const t=db.transaction(store,'readwrite');t.objectStore(store).put(obj);t.oncomplete=()=>res(obj);t.onerror=()=>rej(t.error)})}
function del(store,id){return new Promise((res,rej)=>{const t=db.transaction(store,'readwrite');t.objectStore(store).delete(id);t.oncomplete=()=>res();t.onerror=()=>rej(t.error)})}
function get(store,id){return new Promise((res,rej)=>{const q=db.transaction(store).objectStore(store).get(id);q.onsuccess=()=>res(q.result);q.onerror=()=>rej(q.error)})}
function txAll(stores){return Promise.all(stores.map(all))}

function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
function openModal(title,html){$('#modalTitle').textContent=title;$('#modalBody').innerHTML=html;$('#modal').classList.remove('hidden')}
function closeModal(){$('#modal').classList.add('hidden')}
$('#modalClose').onclick=closeModal;
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal()});

function setPage(p){
 currentPage=p; $$('.page').forEach(x=>x.classList.remove('active')); $('#page-'+p).classList.add('active');
 $$('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===p)); render();
 window.scrollTo(0,0);
}
$$('.nav').forEach(b=>b.onclick=()=>setPage(b.dataset.page));
document.body.addEventListener('click',e=>{
 const a=e.target.closest('[data-action]'); if(!a)return;
 const x=a.dataset.action;
 if(x==='new-customer') customerForm();
 if(x==='new-debt') debtForm();
 if(x==='new-sale') saleForm();
 if(x==='new-request') requestForm();
 if(x==='new-inventory') inventoryForm();
 if(x==='reports') reports();
 if(x==='backup') backup();
 if(x==='restore') $('#restoreFile').click();
 if(x==='settings') settingsForm();
});
$('#restoreFile').addEventListener('change',restoreFromFile);
$('#backupQuick').onclick=backup;
$('#customerSearch').oninput=renderCustomers;
$('#salesSearch').oninput=renderSales;

async function render(){await renderHome(); if(currentPage==='sales')renderSales(); if(currentPage==='debts')renderCustomers(); if(currentPage==='requests')renderRequests(); if(currentPage==='inventory')renderInventory()}

async function renderHome(){
 const [sales,debts,payments,requests]=await txAll(['sales','debts','payments','requests']);
 const d=new Date(); const key=d.toISOString().slice(0,10);
 const todaySales=sales.filter(x=>String(x.date||'').slice(0,10)===key);
 const todayDebts=debts.filter(x=>String(x.date||'').slice(0,10)===key);
 const profitSales=todaySales.reduce((a,x)=>a+(x.profit||0),0);
 const profitDebts=todayDebts.reduce((a,x)=>a+(x.profit||0),0);
 const due=debts.reduce((a,x)=>a+(x.total||0)-(x.paid||0),0);
 $('#homeSales').textContent=money(todaySales.reduce((a,x)=>a+(x.total||0),0));
 $('#homeSalesProfit').textContent=money(profitSales);
 $('#homeDebtProfit').textContent=money(profitDebts);
 $('#homeDebtDue').textContent=money(due);
 $('#homeRequests').textContent=requests.filter(x=>x.status!=='تم').length;
 $('#homeSaleCount').textContent=todaySales.length;
 const ops=[...sales.map(x=>({...x,type:'بيع'})),...debts.map(x=>({...x,type:'دين'}))].sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,8);
 $('#recentOps').innerHTML=ops.length?ops.map(x=>`<div class="item"><div class="item-row"><b>${esc(x.product||x.reason||'عملية')}</b><b>${money(x.total)} ر.ي</b></div><div class="item-meta">${x.type} • ${fmtDate(x.date)}</div></div>`).join(''):'<div class="empty">لا توجد عمليات بعد</div>';
}

async function renderSales(){
 let data=await all('sales'), q=($('#salesSearch').value||'').trim();
 if(q)data=data.filter(x=>(x.product||'').includes(q));
 data.sort((a,b)=>new Date(b.date)-new Date(a.date));
 $('#salesList').innerHTML=data.length?data.map(x=>`<div class="item">
 <div class="item-row"><div class="item-title">${esc(x.product)}</div><b>${money(x.total)} ر.ي</b></div>
 <div class="item-meta">الكمية: ${x.qty} • البيع: ${money(x.sellPrice)} • الربح: ${money(x.profit)} • ${fmtDate(x.date)}</div>
 <div class="item-actions"><button onclick="editSale('${x.id}')">تعديل</button><button class="danger" onclick="deleteSale('${x.id}')">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد مبيعات</div>';
}

async function renderCustomers(){
 const [customers,debts]=await txAll(['customers','debts']);
 let q=($('#customerSearch').value||'').trim(); if(q)customers.splice(0,customers.length,...customers.filter(c=>(c.name||'').includes(q)||(c.phone||'').includes(q)));
 $('#customersList').innerHTML=customers.length?customers.map(c=>{
   const ds=debts.filter(d=>d.customerId===c.id), total=ds.reduce((a,d)=>a+d.total,0), paid=ds.reduce((a,d)=>a+d.paid,0);
   return `<div class="item"><div class="item-row"><div><div class="item-title">${esc(c.name)}</div><div class="item-meta">${esc(c.phone||'بدون هاتف')}</div></div><span class="badge ${total-paid>0?'due':'done'}">${total-paid>0?'متبقي '+money(total-paid):'مسدد'}</span></div>
   <div class="summary"><div><span>إجمالي الدين</span><b>${money(total)}</b></div><div><span>المدفوع</span><b>${money(paid)}</b></div></div>
   <div class="item-actions"><button onclick="openCustomer('${c.id}')">فتح الحساب</button><button onclick="debtForm('${c.id}')">إضافة دين</button><button onclick="customerForm('${c.id}')">تعديل</button></div></div>`
 }).join(''):'<div class="empty">لا يوجد عملاء</div>';
}

async function renderRequests(){
 const data=(await all('requests')).sort((a,b)=>new Date(b.date)-new Date(a.date));
 $('#requestsList').innerHTML=data.length?data.map(x=>`<div class="item"><div class="item-row"><b>${esc(x.product)}</b><span class="badge ${x.status==='تم'?'done':'due'}">${x.status}</span></div><div class="item-meta">${esc(x.customer||'')} • ${esc(x.phone||'')} • السعر المتوقع ${money(x.expected)}<br>${esc(x.notes||'')} • ${fmtDate(x.date)}</div><div class="item-actions"><button onclick="toggleRequest('${x.id}')">${x.status==='تم'?'إرجاع لمعلق':'تم'}</button><button class="danger" onclick="deleteRequest('${x.id}')">حذف</button></div></div>`).join(''):'<div class="empty">لا توجد طلبات</div>';
}
async function renderInventory(){
 const data=await all('inventory');
 $('#inventoryList').innerHTML=data.length?data.map(x=>`<div class="item"><div class="item-row"><b>${esc(x.product)}</b><span class="badge ${x.qty<=x.min?'due':'done'}">الكمية ${x.qty}</span></div><div class="item-meta">شراء: ${money(x.buy)} • بيع: ${money(x.sell)} • الحد الأدنى: ${x.min}</div><div class="item-actions"><button onclick="inventoryForm('${x.id}')">تعديل</button><button class="danger" onclick="deleteInventory('${x.id}')">حذف</button></div></div>`).join(''):'<div class="empty">المخزون فارغ</div>';
}

function formField(label,name,value='',type='text',extra=''){return `<label>${label}<input name="${name}" type="${type}" value="${attr(value)}" ${extra}></label>`}
function customerForm(id){
 (async()=>{const c=id?await get('customers',id):{};openModal(id?'تعديل العميل':'إضافة عميل جديد',`<form class="form" id="customerForm">${formField('اسم العميل *','name',c.name||'')}${formField('رقم الهاتف','phone',c.phone||'','tel')}<label>ملاحظات<textarea name="notes">${esc(c.notes||'')}</textarea></label><button class="primary">حفظ</button></form>`);$('#customerForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);if(!f.get('name').trim())return toast('اسم العميل إجباري');await put('customers',{id:id||uid(),name:f.get('name').trim(),phone:f.get('phone').trim(),notes:f.get('notes').trim(),updatedAt:now()});closeModal();toast('تم حفظ العميل');render()}})()
}
async function debtForm(customerId,id){
 const customers=await all('customers'), d=id?await get('debts',id):{};
 openModal(id?'تعديل الدين':'إضافة دين جديد',`<form class="form" id="debtForm">
 <label>العميل<select name="customerId" required>${customers.map(c=>`<option value="${c.id}" ${c.id===(customerId||d.customerId)?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label>
 ${formField('الصنف / سبب الدين','reason',d.reason||'')}
 <div class="row">${formField('الكمية','qty',d.qty||1,'number','min="0.01" step="0.01"')}${formField('سعر الشراء','buyPrice',d.buyPrice||0,'number','min="0" step="0.01"')}</div>
 <div class="row">${formField('سعر البيع','sellPrice',d.sellPrice||0,'number','min="0" step="0.01"')}${formField('المدفوع الآن','paid',d.paid||0,'number','min="0" step="0.01"')}</div>
 <label>ملاحظات<textarea name="notes">${esc(d.notes||'')}</textarea></label><button class="primary">حفظ</button></form>`);
 $('#debtForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target),qty=+f.get('qty'),buy=+f.get('buyPrice'),sell=+f.get('sellPrice'),total=sell*qty,profit=(sell-buy)*qty,paid=Math.min(+f.get('paid'),total);const obj={id:id||uid(),customerId:f.get('customerId'),reason:f.get('reason').trim(),qty,buyPrice:buy,sellPrice:sell,total,profit,paid,notes:f.get('notes').trim(),date:d.date||now()};await put('debts',obj);await adjustInventory(obj,id?'none':'out');closeModal();toast('تم حفظ الدين');render()}
}
function saleForm(id){
 (async()=>{const s=id?await get('sales',id):{};openModal(id?'تعديل البيع':'إضافة بيع',`<form class="form" id="saleForm">${formField('المنتج *','product',s.product||'')}${formField('الكمية','qty',s.qty||1,'number','min="0.01" step="0.01"')}<div class="row">${formField('سعر الشراء','buyPrice',s.buyPrice||0,'number','min="0" step="0.01"')}${formField('سعر البيع','sellPrice',s.sellPrice||0,'number','min="0" step="0.01"')}</div><label>ملاحظات<textarea name="notes">${esc(s.notes||'')}</textarea></label><button class="primary">حفظ</button></form>`);$('#saleForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target),qty=+f.get('qty'),buy=+f.get('buyPrice'),sell=+f.get('sellPrice');const obj={id:id||uid(),product:f.get('product').trim(),qty,buyPrice:buy,sellPrice:sell,total:sell*qty,profit:(sell-buy)*qty,notes:f.get('notes').trim(),date:s.date||now()};await put('sales',obj);if(!id)await adjustInventory(obj,'out');closeModal();toast('تم حفظ البيع');render()}})()
}
async function requestForm(id){
 const x=id?await get('requests',id):{};openModal(id?'تعديل الطلب':'إضافة طلب',`<form class="form" id="requestForm">${formField('اسم العميل','customer',x.customer||'')}${formField('الهاتف','phone',x.phone||'','tel')}${formField('المنتج المطلوب','product',x.product||'')}${formField('السعر المتوقع','expected',x.expected||0,'number','min="0" step="0.01"')}<label>ملاحظات<textarea name="notes">${esc(x.notes||'')}</textarea></label><button class="primary">حفظ</button></form>`);$('#requestForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);await put('requests',{id:id||uid(),customer:f.get('customer').trim(),phone:f.get('phone').trim(),product:f.get('product').trim(),expected:+f.get('expected'),notes:f.get('notes').trim(),status:x.status||'معلق',date:x.date||now()});closeModal();toast('تم حفظ الطلب');render()}}
function inventoryForm(id){
 (async()=>{const x=id?await get('inventory',id):{};openModal(id?'تعديل المنتج':'إضافة منتج',`<form class="form" id="invForm">${formField('المنتج','product',x.product||'')}<div class="row">${formField('الكمية','qty',x.qty||0,'number','min="0" step="0.01"')}${formField('الحد الأدنى','min',x.min||0,'number','min="0" step="0.01"')}</div><div class="row">${formField('سعر الشراء','buy',x.buy||0,'number','min="0" step="0.01"')}${formField('سعر البيع','sell',x.sell||0,'number','min="0" step="0.01"')}</div><label>ملاحظات<textarea name="notes">${esc(x.notes||'')}</textarea></label><button class="primary">حفظ</button></form>`);$('#invForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);await put('inventory',{id:id||uid(),product:f.get('product').trim(),qty:+f.get('qty'),min:+f.get('min'),buy:+f.get('buy'),sell:+f.get('sell'),notes:f.get('notes').trim()});closeModal();toast('تم حفظ المنتج');render()}})()
}
async function openCustomer(id){
 const c=await get('customers',id), ds=(await all('debts')).filter(x=>x.customerId===id).sort((a,b)=>new Date(b.date)-new Date(a.date));
 const total=ds.reduce((a,d)=>a+d.total,0),paid=ds.reduce((a,d)=>a+d.paid,0),profit=ds.reduce((a,d)=>a+d.profit,0);
 openModal('حساب '+c.name,`<div class="item"><b>${esc(c.name)}</b><div class="item-meta">${esc(c.phone||'بدون هاتف')}</div><div class="summary"><div><span>عدد العمليات</span><b>${ds.length}</b></div><div><span>إجمالي الدين</span><b>${money(total)}</b></div><div><span>إجمالي المدفوع</span><b>${money(paid)}</b></div><div><span>المتبقي</span><b>${money(total-paid)}</b></div><div><span>إجمالي ربح الديون</span><b>${money(profit)}</b></div></div><button class="primary" onclick="debtForm('${id}');">+ إضافة دين</button></div><div class="list" style="margin-top:10px">${ds.length?ds.map(d=>`<div class="item"><div class="item-row"><b>${esc(d.reason)}</b><span>${d.paid>=d.total?'<span class="badge done">مدفوع بالكامل</span>':'<span class="badge due">متبقي '+money(d.total-d.paid)+'</span>'}</span></div><div class="item-meta">التاريخ: ${fmtDate(d.date)}<br>الكمية: ${d.qty} • سعر الشراء: ${money(d.buyPrice)} • سعر البيع: ${money(d.sellPrice)}<br>الإجمالي: ${money(d.total)} • المدفوع: ${money(d.paid)} • الربح: ${money(d.profit)}</div><div class="item-actions"><button onclick="paymentForm('${d.id}')">إضافة دفعة</button><button onclick="editDebt('${d.id}')">تعديل</button><button class="danger" onclick="deleteDebt('${d.id}')">حذف</button><button onclick="customerStatement('${id}')">كشف حساب / PDF</button></div></div>`).join(''):'<div class="empty">لا توجد ديون</div>'}</div>`);
}
window.openCustomer=openCustomer;
window.debtForm=debtForm;
async function paymentForm(debtId){
 const d=await get('debts',debtId); const remaining=d.total-d.paid;
 if(remaining<=0)return toast('هذا الدين مدفوع بالكامل');
 openModal('إضافة دفعة',`<form class="form" id="payForm">${formField('المبلغ','amount',remaining,'number',`min="0.01" max="${remaining}" step="0.01"`)}<button class="primary">حفظ الدفعة</button></form>`);
 $('#payForm').onsubmit=async e=>{e.preventDefault();const amount=Math.min(+new FormData(e.target).get('amount'),remaining);d.paid+=amount;await put('debts',d);await put('payments',{id:uid(),debtId,amount,date:now()});closeModal();toast('تم تسجيل الدفعة');render()}
}
window.paymentForm=paymentForm;
async function editDebt(id){const d=await get('debts',id);debtForm(d.customerId,id)}
async function deleteDebt(id){if(!confirm('هل تريد حذف الدين؟'))return;await del('debts',id);toast('تم الحذف');render()}
async function editSale(id){saleForm(id)} async function deleteSale(id){if(!confirm('حذف عملية البيع؟'))return;await del('sales',id);toast('تم الحذف');render()}
async function deleteRequest(id){if(!confirm('حذف الطلب؟'))return;await del('requests',id);render()}
async function toggleRequest(id){const x=await get('requests',id);x.status=x.status==='تم'?'معلق':'تم';await put('requests',x);renderRequests()}
async function deleteInventory(id){if(!confirm('حذف المنتج؟'))return;await del('inventory',id);renderInventory()}
window.editDebt=editDebt;window.deleteDebt=deleteDebt;window.editSale=editSale;window.deleteSale=deleteSale;window.deleteRequest=deleteRequest;window.toggleRequest=toggleRequest;window.deleteInventory=deleteInventory;

async function adjustInventory(obj,dir){
 const items=await all('inventory');const p=items.find(x=>x.product.trim()===String(obj.product||obj.reason).trim());
 if(p){p.qty=Math.max(0,p.qty-(dir==='out'?obj.qty:0));await put('inventory',p)}
}
function fmtDate(x){try{return new Intl.DateTimeFormat('ar-YE',{dateStyle:'medium',timeStyle:'short'}).format(new Date(x))}catch{return x}}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function attr(v){return esc(v)}

async function backup(){
 const data={version:1,app:'العجردي للبرمجة',createdAt:now(),stores:{}};
 for(const s of STORES)data.stores[s]=await all(s);
 const blob=new Blob([JSON.stringify(data)],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='alajardi_backup_'+new Date().toISOString().slice(0,10)+'.json';a.click();URL.revokeObjectURL(a.href);toast('تم إنشاء النسخة الاحتياطية');
}
async function restoreFromFile(e){
 const file=e.target.files[0];if(!file)return;
 if(!confirm('سيتم استبدال البيانات الحالية ببيانات النسخة. هل أنت متأكد؟')){e.target.value='';return}
 try{const data=JSON.parse(await file.text());if(!data.stores)throw Error();
  for(const s of STORES){const items=data.stores[s]||[];for(const old of await all(s))await del(s,old.id);for(const x of items)await put(s,x)}
  toast('تمت الاستعادة بنجاح');render()
 }catch{toast('ملف النسخة غير صالح')} e.target.value='';
}
async function customerStatement(id){
 const c=await get('customers',id), ds=(await all('debts')).filter(x=>x.customerId===id);
 const total=ds.reduce((a,d)=>a+d.total,0), paid=ds.reduce((a,d)=>a+d.paid,0);
 const rows=ds.map(d=>`<tr><td>${fmtDate(d.date)}</td><td>${esc(d.reason)}</td><td>${d.qty}</td><td>${money(d.sellPrice)}</td><td>${money(d.total)}</td><td>${money(d.paid)}</td><td>${money(d.total-d.paid)}</td></tr>`).join('');
 const html=`<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>كشف حساب</title><style>body{font-family:Arial;padding:25px;color:#111}h1{font-size:22px}table{width:100%;border-collapse:collapse;margin-top:20px}th,td{border:1px solid #bbb;padding:7px;text-align:center;font-size:12px}th{background:#eee}.total{margin-top:15px;display:flex;gap:30px;font-weight:bold}</style></head><body><h1>العجردي لصيانة وبرمجة الجوال</h1><h2>فاتورة / كشف حساب عميل</h2><p>الاسم: ${esc(c.name)}<br>الهاتف: ${esc(c.phone||'')}<br>تاريخ الإصدار: ${fmtDate(now())}</p><table><thead><tr><th>التاريخ</th><th>الصنف</th><th>الكمية</th><th>سعر البيع</th><th>إجمالي العملية</th><th>المدفوع</th><th>المتبقي</th></tr></thead><tbody>${rows}</tbody></table><div class="total"><span>إجمالي العمليات: ${money(total)}</span><span>إجمالي المدفوع: ${money(paid)}</span><span>إجمالي المتبقي: ${money(total-paid)}</span></div></body></html>`;
 const w=window.open('','_blank'); if(!w){toast('اسمح بفتح النوافذ المنبثقة للطباعة');return} w.document.write(html);w.document.close();setTimeout(()=>w.print(),400);
}
window.customerStatement=customerStatement;

async function reports(){
 const [sales,debts,customers,requests]=await txAll(['sales','debts','customers','requests']);
 const saleProfit=sales.reduce((a,x)=>a+x.profit,0), debtProfit=debts.reduce((a,x)=>a+x.profit,0), due=debts.reduce((a,x)=>a+x.total-x.paid,0);
 openModal('التقارير',`<div class="summary"><div><span>إجمالي المبيعات</span><b>${money(sales.reduce((a,x)=>a+x.total,0))}</b></div><div><span>أرباح البيع</span><b>${money(saleProfit)}</b></div><div><span>إجمالي الديون</span><b>${money(debts.reduce((a,x)=>a+x.total,0))}</b></div><div><span>المدفوع</span><b>${money(debts.reduce((a,x)=>a+x.paid,0))}</b></div><div><span>المتبقي</span><b>${money(due)}</b></div><div><span>أرباح الديون</span><b>${money(debtProfit)}</b></div><div><span>عدد المبيعات</span><b>${sales.length}</b></div><div><span>عدد العملاء</span><b>${customers.length}</b></div><div><span>عدد الطلبات</span><b>${requests.length}</b></div></div><p class="item-meta">التقرير الحالي يعرض إجماليات البيانات المحلية. يمكن تطوير فلاتر اليوم/الأسبوع/الشهر والفترة المخصصة لاحقًا.</p>`)
}
async function settingsForm(){
 const settings=(await all('settings'))[0]||{shopName:'العجردي لصيانة وبرمجة الجوال'};
 openModal('الإعدادات',`<form class="form" id="settingsForm">${formField('اسم المحل داخل الفاتورة','shopName',settings.shopName)}<button class="primary">حفظ</button></form>`);
 $('#settingsForm').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);await put('settings',{id:'main',shopName:f.get('shopName')});closeModal();toast('تم حفظ الإعدادات')}
}

(async()=>{try{await openDB();await render()}catch(e){console.error(e);toast('تعذر فتح قاعدة البيانات المحلية')}})();
