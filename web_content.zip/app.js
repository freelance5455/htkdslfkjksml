/* NYXARA — single-page Android assistant frontend */

const KEY = {
  messages: "nyxara_messages",
  memory: "nyxara_memory",
  reminders: "nyxara_reminders",
  settings: "nyxara_settings"
};

const DEFAULT_MESSAGES = [{
  role:"assistant",
  text:"Welcome. I am Nyxara. The Void is quiet, but I am listening. What shall we accomplish?",
  time:Date.now()
}];

let messages = read(KEY.messages, DEFAULT_MESSAGES);
let memory = read(KEY.memory, "");
let reminders = read(KEY.reminders, []);
let settings = read(KEY.settings, {
  autoSpeak:true,
  voiceRate:0.82,
  aiEndpoint:""
});

const $ = id => document.getElementById(id);

function read(key, fallback){
  try{
    const x = localStorage.getItem(key);
    return x ? JSON.parse(x) : fallback;
  }catch(e){ return fallback; }
}
function save(key,value){ localStorage.setItem(key, JSON.stringify(value)); }

function showScreen(name){
  document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));
  document.querySelectorAll(".nav button").forEach(x=>x.classList.remove("active"));
  const screen = $(name);
  if(screen) screen.classList.add("active");
  const nav = document.querySelector(`.nav button[data-screen="${name}"]`);
  if(nav) nav.classList.add("active");
  if(name==="memory") renderReminders();
  if(name==="home") renderHomeReminders();
}

document.querySelectorAll(".nav button").forEach(btn=>{
  btn.addEventListener("click",()=>showScreen(btn.dataset.screen));
});

function setStatus(text){
  $("status").textContent = text;
  $("chatState").textContent = text[0] + text.slice(1).toLowerCase() + ".";
}

function renderMessages(){
  const box=$("messages");
  box.innerHTML="";
  messages.forEach((m,i)=>{
    const b=document.createElement("div");
    b.className="bubble " + (m.role==="user"?"user":"assistant");
    b.innerHTML=`<div class="label">${m.role==="user"?"YOU":"NYXARA"}</div><div>${escapeHtml(m.text)}</div>`;
    if(m.role==="assistant"){
      const s=document.createElement("button");
      s.className="speak";
      s.textContent="◉ Speak";
      s.onclick=()=>speak(m.text);
      b.appendChild(s);
    }
    box.appendChild(b);
  });
  box.scrollTop=box.scrollHeight;
}

function escapeHtml(s){
  return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

function addMessage(role,text){
  messages.push({role,text,time:Date.now()});
  save(KEY.messages,messages);
  renderMessages();
}

function speak(text){
  if(!("speechSynthesis" in window)){
    alert("Speech synthesis is not available in this HTML-to-APK wrapper.");
    return;
  }
  speechSynthesis.cancel();
  setStatus("SPEAKING");
  const u=new SpeechSynthesisUtterance(text);
  u.rate=Number(settings.voiceRate||0.82);
  u.pitch=0.82;
  u.volume=1;
  u.onend=()=>setStatus("READY");
  u.onerror=()=>setStatus("READY");
  speechSynthesis.speak(u);
}

async function ask(text){
  text=(text||"").trim();
  if(!text) return;
  addMessage("user",text);
  $("textInput").value="";
  setStatus("THINKING");

  let answer = await askBackend(text);

  if(!answer) answer = localAssistant(text);

  addMessage("assistant",answer);
  setStatus("READY");

  if(settings.autoSpeak) speak(answer);
}

async function askBackend(text){
  const endpoint=(settings.aiEndpoint||"").trim();
  if(!endpoint) return null;

  try{
    const response=await fetch(endpoint,{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        message:text,
        memory:memory,
        history:messages.slice(-20)
      })
    });

    if(!response.ok) return null;

    const data=await response.json();
    return data.reply || data.response || data.message || null;
  }catch(e){
    return null;
  }
}

function localAssistant(text){
  const q=text.toLowerCase();

  if(q.includes("who are you") || q.includes("what are you"))
    return "I am Nyxara, your fictional Void assistant. I can speak, remember local preferences, create reminders, and perform supported phone actions.";

  if(q.includes("hello") || q==="hi" || q.includes("hey nyxara"))
    return "I am here. What shall we accomplish?";

  if(q.includes("time"))
    return "The current time is " + new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}) + ".";

  if(q.includes("date"))
    return "Today is " + new Date().toLocaleDateString() + ".";

  if(q.includes("what do you remember"))
    return memory ? "Your local memory says:\n\n"+memory : "Your local memory is empty.";

  if(q.startsWith("remember ")){
    memory=(memory ? memory+"\n" : "")+text.slice(9);
    save(KEY.memory,memory);
    $("memoryInput").value=memory;
    return "I have stored that in local memory.";
  }

  if(q.includes("open youtube")){ openUrl("https://www.youtube.com"); return "Opening YouTube."; }
  if(q.includes("open google")){ openUrl("https://www.google.com"); return "Opening Google."; }
  if(q.includes("open browser")){ openUrl("https://www.google.com"); return "Opening the browser."; }
  if(q.includes("open whatsapp")){ openUrl("https://wa.me/"); return "Opening WhatsApp if your device supports the link."; }
  if(q.includes("open settings")){ openIntent("android.settings.SETTINGS"); return "Opening Android settings."; }

  if(q.includes("reminder"))
    return "Use the Memory tab and choose Create reminder. This wrapper can keep the reminder locally while the app is running.";

  return `I understood you: "${text}"\n\nI am currently in local mode. Add your own secure AI endpoint in Settings to turn me into a full AI assistant.`;
}

function openUrl(url){
  window.location.href=url;
}

function openIntent(action){
  const intent="intent:#Intent;action="+action+";end";
  window.location.href=intent;
}

function startVoice(){
  const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!Recognition){
    alert("Voice recognition is not exposed by this HTML-to-APK wrapper. Try a wrapper that enables microphone/WebView speech permissions.");
    return;
  }
  const r=new Recognition();
  r.lang="en-IN";
  r.interimResults=false;
  r.maxAlternatives=1;
  setStatus("LISTENING");
  r.onresult=e=>{
    const text=e.results[0][0].transcript;
    $("textInput").value=text;
    ask(text);
  };
  r.onerror=()=>setStatus("READY");
  r.onend=()=>setStatus("READY");
  r.start();
}

$("talkBtn").onclick=startVoice;
$("sendBtn").onclick=()=>ask($("textInput").value);
$("textInput").addEventListener("keydown",e=>{
  if(e.key==="Enter" && !e.shiftKey){e.preventDefault();ask($("textInput").value);}
});

document.querySelectorAll("[data-command]").forEach(btn=>{
  btn.addEventListener("click",()=>ask(btn.dataset.command));
});

$("memoryInput").value=memory;
$("saveMemory").onclick=()=>{
  memory=$("memoryInput").value;
  save(KEY.memory,memory);
  alert("Nyxara's local memory has been saved.");
};

$("autoSpeak").checked=!!settings.autoSpeak;
$("autoSpeak").onchange=()=>{
  settings.autoSpeak=$("autoSpeak").checked;
  save(KEY.settings,settings);
};

$("voiceRate").value=settings.voiceRate||0.82;
$("rateLabel").textContent="Current speed: "+Number(settings.voiceRate||0.82).toFixed(2);
$("voiceRate").oninput=()=>{
  settings.voiceRate=Number($("voiceRate").value);
  $("rateLabel").textContent="Current speed: "+settings.voiceRate.toFixed(2);
  save(KEY.settings,settings);
};

$("aiEndpoint").value=settings.aiEndpoint||"";
$("saveEndpoint").onclick=()=>{
  settings.aiEndpoint=$("aiEndpoint").value.trim();
  save(KEY.settings,settings);
  alert("AI endpoint saved.");
};

function addReminder(){
  const title=prompt("What should Nyxara remind you about?");
  if(!title) return;

  const mins=prompt("How many minutes from now?", "10");
  const minutes=Math.max(1,Number(mins)||10);

  const reminder={
    id:Date.now(),
    title,
    due:Date.now()+minutes*60000
  };

  reminders.push(reminder);
  save(KEY.reminders,reminders);
  renderReminders();
  renderHomeReminders();

  alert("Reminder saved locally. For true Android notifications after the app is closed, your HTML-to-APK wrapper must provide notification support.");
}

$("newReminder").onclick=addReminder;

function deleteReminder(id){
  reminders=reminders.filter(r=>r.id!==id);
  save(KEY.reminders,reminders);
  renderReminders();
  renderHomeReminders();
}

function renderReminders(){
  const box=$("reminderList");
  box.innerHTML="";
  if(!reminders.length){
    box.innerHTML='<div class="card"><span class="muted">No reminders yet.</span></div>';
    return;
  }
  reminders.forEach(r=>{
    const d=document.createElement("div");
    d.className="card reminder";
    d.innerHTML=`<div><b>${escapeHtml(r.title)}</b><small>${new Date(r.due).toLocaleString()}</small></div>`;
    const x=document.createElement("button");
    x.className="delete";
    x.textContent="DELETE";
    x.onclick=()=>deleteReminder(r.id);
    d.appendChild(x);
    box.appendChild(d);
  });
}

function renderHomeReminders(){
  const box=$("homeReminders");
  box.innerHTML="";
  if(!reminders.length){
    box.innerHTML='<div class="card"><span class="muted">No reminders. The silence is peaceful.</span></div>';
    return;
  }
  reminders.slice().sort((a,b)=>a.due-b.due).slice(0,4).forEach(r=>{
    const d=document.createElement("div");
    d.className="card";
    d.innerHTML=`<b>${escapeHtml(r.title)}</b><small>${new Date(r.due).toLocaleString()}</small>`;
    box.appendChild(d);
  });
}

$("clearData").onclick=()=>{
  if(confirm("Clear Nyxara's local data?")){
    Object.values(KEY).forEach(k=>localStorage.removeItem(k));
    location.reload();
  }
};

/* Keep a simple reminder timer alive while the page is open. */
setInterval(()=>{
  const now=Date.now();
  const due=reminders.filter(r=>r.due<=now);
  if(due.length){
    due.forEach(r=>{
      if("Notification" in window && Notification.permission==="granted"){
        new Notification("Nyxara reminder",{body:r.title});
      }else{
        alert("Nyxara reminder: "+r.title);
      }
    });
    reminders=reminders.filter(r=>r.due>now);
    save(KEY.reminders,reminders);
    renderReminders();
    renderHomeReminders();
  }
},15000);

if("Notification" in window && Notification.permission==="default"){
  try{ Notification.requestPermission(); }catch(e){}
}

renderMessages();
renderReminders();
renderHomeReminders();
$("rateLabel").textContent="Current speed: "+Number(settings.voiceRate||0.82).toFixed(2);
showScreen("home");
