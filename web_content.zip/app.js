let screen='login',balance=10000;
const app=document.getElementById('app'), nav=document.getElementById('nav');
function render(){
nav.innerHTML=screen==='home'||screen==='history'||screen==='profile'?`<button onclick="go('home')">🏠<br>Home</button><button onclick="go('history')">🧾<br>History</button><button onclick="go('profile')">👤<br>Profile</button>`:'';
if(screen==='login') app.innerHTML=`<div class="logo">GBNPAY</div><h2>Demo Wallet</h2><input id="phone" class="input" placeholder="মোবাইল নম্বর"><button class="btn" onclick="go('otp')">Continue</button>`;
if(screen==='otp') app.innerHTML=`<h2>OTP Verification</h2><p>আপনার নম্বরে পাঠানো Demo OTP দিন</p><input id="otp" class="input" maxlength="6" placeholder="123456"><button class="btn" onclick="verifyOtp()">Verify</button>`;
if(screen==='pin') app.innerHTML=`<h2>Set Demo PIN</h2><input id="pin" class="input" maxlength="4" placeholder="1234"><button class="btn" onclick="go('home')">Set PIN</button>`;
if(screen==='home') app.innerHTML=`<div class="card"><small>Available Balance</small><div class="balance">৳ ${balance.toFixed(2)}</div></div><div class="grid"><button class="tile" onclick="go('send')">💸<br>Send Money</button><button class="tile" onclick="go('recharge')">📱<br>Recharge</button><button class="tile" onclick="go('qr')">📷<br>QR Pay</button><button class="tile" onclick="go('history')">🧾<br>History</button></div>`;
if(screen==='send') app.innerHTML=`<h2>Send Money</h2><input class="input" placeholder="Receiver number"><input id="amt" class="input" type="number" placeholder="Amount"><button class="btn" onclick="send()">Send Money</button>`;
if(screen==='recharge') app.innerHTML=`<h2>Mobile Recharge</h2><input class="input" placeholder="Mobile number"><input id="rAmt" class="input" type="number" placeholder="Amount"><button class="btn" onclick="recharge()">Recharge</button>`;
if(screen==='qr') app.innerHTML=`<h2>QR Pay</h2><div class="qr">▦</div><p style="text-align:center">Demo QR Scanner</p><button class="btn" onclick="alert('Demo QR payment successful')">Pay Demo</button>`;
if(screen==='history') app.innerHTML=`<h2>Transaction History</h2><div class="row"><span>Welcome Demo Wallet<br><small>Today</small></span><b>+৳10,000</b></div><div class="row"><span>Demo transactions<br><small>No real money</small></span><b>—</b></div>`;
if(screen==='profile') app.innerHTML=`<h2>Profile</h2><div class="card"><b>GBNPAY Demo User</b><br><small>Verified Demo Account</small></div><button class="btn" onclick="go('login')">Logout</button>`;
}
function go(s){screen=s;render()}
function verifyOtp(){if(document.getElementById('otp').value==='123456')go('pin');else alert('Demo OTP: 123456')}
function send(){let a=+document.getElementById('amt').value;if(a>0&&a<=balance){balance-=a;alert('Demo transfer successful');go('home')}else alert('Invalid demo amount')}
function recharge(){let a=+document.getElementById('rAmt').value;if(a>0&&a<=balance){balance-=a;alert('Demo recharge successful');go('home')}else alert('Invalid demo amount')}
render();
