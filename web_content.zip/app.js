const KEY="playcoins_demo_v1";
const initial={balance:0,done:[]};
let state;
try{state=JSON.parse(localStorage.getItem(KEY))||initial}catch(e){state=initial}
const save=()=>{localStorage.setItem(KEY,JSON.stringify(state));render()};
const $=id=>document.getElementById(id);
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");clearTimeout(window._toastTimer);window._toastTimer=setTimeout(()=>t.classList.remove("show"),2600)}
function render(){$("balance").textContent=state.balance;const map={adBtn:"ad",dailyBtn:"daily",welcomeBtn:"welcome"};for(const [id,key] of Object.entries(map)){const b=$(id);b.disabled=state.done.includes(key);b.textContent=b.disabled?"Hecho":({ad:"Probar",daily:"Completar",welcome:"Reclamar"}[key]);}}
function claim(key,amount,message){if(state.done.includes(key)){toast("Este reto ya está completado.");return}state.done.push(key);state.balance+=amount;save();toast(message)}
$("adBtn").addEventListener("click",()=>{toast("Anuncio simulado: no se ha mostrado publicidad real.");setTimeout(()=>claim("ad",10,"¡Demo completada! +10 PC ficticias."),650)});
$("dailyBtn").addEventListener("click",()=>claim("daily",5,"Reto completado: +5 PC ficticias."));
$("welcomeBtn").addEventListener("click",()=>claim("welcome",2,"Recompensa de prueba: +2 PC ficticias."));
$("resetBtn").addEventListener("click",()=>{if(confirm("¿Reiniciar las monedas y los retos de demostración?")){state={balance:0,done:[]};save();toast("Demo reiniciada.")}});
$("missionsNav").addEventListener("click",()=>{document.querySelector(".section").scrollIntoView({behavior:"smooth"});toast("Aquí tienes los retos de prueba.")});
$("accountNav").addEventListener("click",()=>toast("Cuenta y pagos reales aún no están configurados."));
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
render();