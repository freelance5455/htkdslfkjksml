const bgColors=['#FFFDF5','#FFF8E8','#FFF2D9','#FFEFE2','#FFF4EE','#FFEAF0','#FFF0F5','#FFE8F1','#FDECF4','#F9EAF7','#F7ECFF','#F2EAFF','#EDE9FF','#E8EDFF','#EAF2FF','#E6F5FF','#E7FAFF','#E5F8F4','#E6F8EF','#EAF8E8','#F0F9E3','#F5F9DD','#FAF7DF','#FFF9D9','#FFF4D6','#FDEEDC','#F8EBDD','#F5ECE7','#F2F0E8','#EEF2E8','#E8F2EA','#E5F4EF','#E6F3F2','#E7F1F7','#EAF0F8','#EDF0F7','#F0ECF7','#F3EBF5','#F7EDF1','#F9EFEA','#F3F6E8','#EAF5E7','#E7F7E9','#E8F7F5','#E8F5F8','#E9F1F9','#ECECF8','#F0EBF8','#000000','#000000'];
const styles=["Rainbow", "Gradient", "Neon", "3D", "Gold", "Ice", "Fire", "Ocean", "Galaxy", "Forest", "Pastel", "Sunset", "Crystal", "Royal", "Silver", "Rose", "Lime", "Sky", "Candy", "Aurora", "Copper", "Mint", "Berry", "Lavender", "Emerald", "Ruby", "Amber", "Electric", "Cool Mix", "Warm Mix", "Fresh", "Deep", "Bright", "Soft", "Luxury", "Tropical", "Spring", "Summer", "Autumn", "Winter", "Wave", "Burst", "Glow", "Cycle", "Gradient Mix", "Multi Color", "Contrast", "Color Flow", "Party", "Custom Mix"];const palettes=[["hsl(0,95%,58%)", "hsl(55,95%,58%)", "hsl(110,95%,58%)", "hsl(165,95%,58%)", "hsl(220,95%,58%)", "hsl(275,95%,58%)"], ["hsl(138,95%,58%)", "hsl(193,95%,58%)", "hsl(248,95%,58%)", "hsl(303,95%,58%)", "hsl(358,95%,58%)", "hsl(53,95%,58%)"], ["hsl(275,95%,58%)", "hsl(330,95%,58%)", "hsl(25,95%,58%)", "hsl(80,95%,58%)", "hsl(135,95%,58%)", "hsl(190,95%,58%)"], ["hsl(53,95%,58%)", "hsl(108,95%,58%)", "hsl(163,95%,58%)", "hsl(218,95%,58%)", "hsl(273,95%,58%)", "hsl(328,95%,58%)"], ["hsl(190,95%,58%)", "hsl(245,95%,58%)", "hsl(300,95%,58%)", "hsl(355,95%,58%)", "hsl(50,95%,58%)", "hsl(105,95%,58%)"], ["hsl(328,95%,58%)", "hsl(23,95%,58%)", "hsl(78,95%,58%)", "hsl(133,95%,58%)", "hsl(188,95%,58%)", "hsl(243,95%,58%)"], ["hsl(105,95%,58%)", "hsl(160,95%,58%)", "hsl(215,95%,58%)", "hsl(270,95%,58%)", "hsl(325,95%,58%)", "hsl(20,95%,58%)"], ["hsl(243,95%,58%)", "hsl(298,95%,58%)", "hsl(353,95%,58%)", "hsl(48,95%,58%)", "hsl(103,95%,58%)", "hsl(158,95%,58%)"], ["hsl(20,95%,58%)", "hsl(75,95%,58%)", "hsl(130,95%,58%)", "hsl(185,95%,58%)", "hsl(240,95%,58%)", "hsl(295,95%,58%)"], ["hsl(158,95%,58%)", "hsl(213,95%,58%)", "hsl(268,95%,58%)", "hsl(323,95%,58%)", "hsl(18,95%,58%)", "hsl(73,95%,58%)"], ["hsl(295,95%,58%)", "hsl(350,95%,58%)", "hsl(45,95%,58%)", "hsl(100,95%,58%)", "hsl(155,95%,58%)", "hsl(210,95%,58%)"], ["hsl(73,95%,58%)", "hsl(128,95%,58%)", "hsl(183,95%,58%)", "hsl(238,95%,58%)", "hsl(293,95%,58%)", "hsl(348,95%,58%)"], ["hsl(210,95%,58%)", "hsl(265,95%,58%)", "hsl(320,95%,58%)", "hsl(15,95%,58%)", "hsl(70,95%,58%)", "hsl(125,95%,58%)"], ["hsl(348,95%,58%)", "hsl(43,95%,58%)", "hsl(98,95%,58%)", "hsl(153,95%,58%)", "hsl(208,95%,58%)", "hsl(263,95%,58%)"], ["hsl(125,95%,58%)", "hsl(180,95%,58%)", "hsl(235,95%,58%)", "hsl(290,95%,58%)", "hsl(345,95%,58%)", "hsl(40,95%,58%)"], ["hsl(263,95%,58%)", "hsl(318,95%,58%)", "hsl(13,95%,58%)", "hsl(68,95%,58%)", "hsl(123,95%,58%)", "hsl(178,95%,58%)"], ["hsl(40,95%,58%)", "hsl(95,95%,58%)", "hsl(150,95%,58%)", "hsl(205,95%,58%)", "hsl(260,95%,58%)", "hsl(315,95%,58%)"], ["hsl(178,95%,58%)", "hsl(233,95%,58%)", "hsl(288,95%,58%)", "hsl(343,95%,58%)", "hsl(38,95%,58%)", "hsl(93,95%,58%)"], ["hsl(315,95%,58%)", "hsl(10,95%,58%)", "hsl(65,95%,58%)", "hsl(120,95%,58%)", "hsl(175,95%,58%)", "hsl(230,95%,58%)"], ["hsl(93,95%,58%)", "hsl(148,95%,58%)", "hsl(203,95%,58%)", "hsl(258,95%,58%)", "hsl(313,95%,58%)", "hsl(8,95%,58%)"], ["hsl(230,95%,58%)", "hsl(285,95%,58%)", "hsl(340,95%,58%)", "hsl(35,95%,58%)", "hsl(90,95%,58%)", "hsl(145,95%,58%)"], ["hsl(8,95%,58%)", "hsl(63,95%,58%)", "hsl(118,95%,58%)", "hsl(173,95%,58%)", "hsl(228,95%,58%)", "hsl(283,95%,58%)"], ["hsl(145,95%,58%)", "hsl(200,95%,58%)", "hsl(255,95%,58%)", "hsl(310,95%,58%)", "hsl(5,95%,58%)", "hsl(60,95%,58%)"], ["hsl(283,95%,58%)", "hsl(338,95%,58%)", "hsl(33,95%,58%)", "hsl(88,95%,58%)", "hsl(143,95%,58%)", "hsl(198,95%,58%)"], ["hsl(60,95%,58%)", "hsl(115,95%,58%)", "hsl(170,95%,58%)", "hsl(225,95%,58%)", "hsl(280,95%,58%)", "hsl(335,95%,58%)"], ["hsl(198,95%,58%)", "hsl(253,95%,58%)", "hsl(308,95%,58%)", "hsl(3,95%,58%)", "hsl(58,95%,58%)", "hsl(113,95%,58%)"], ["hsl(335,95%,58%)", "hsl(30,95%,58%)", "hsl(85,95%,58%)", "hsl(140,95%,58%)", "hsl(195,95%,58%)", "hsl(250,95%,58%)"], ["hsl(113,95%,58%)", "hsl(168,95%,58%)", "hsl(223,95%,58%)", "hsl(278,95%,58%)", "hsl(333,95%,58%)", "hsl(28,95%,58%)"], ["hsl(250,95%,58%)", "hsl(305,95%,58%)", "hsl(0,95%,58%)", "hsl(55,95%,58%)", "hsl(110,95%,58%)", "hsl(165,95%,58%)"], ["hsl(28,95%,58%)", "hsl(83,95%,58%)", "hsl(138,95%,58%)", "hsl(193,95%,58%)", "hsl(248,95%,58%)", "hsl(303,95%,58%)"], ["hsl(165,95%,58%)", "hsl(220,95%,58%)", "hsl(275,95%,58%)", "hsl(330,95%,58%)", "hsl(25,95%,58%)", "hsl(80,95%,58%)"], ["hsl(303,95%,58%)", "hsl(358,95%,58%)", "hsl(53,95%,58%)", "hsl(108,95%,58%)", "hsl(163,95%,58%)", "hsl(218,95%,58%)"], ["hsl(80,95%,58%)", "hsl(135,95%,58%)", "hsl(190,95%,58%)", "hsl(245,95%,58%)", "hsl(300,95%,58%)", "hsl(355,95%,58%)"], ["hsl(218,95%,58%)", "hsl(273,95%,58%)", "hsl(328,95%,58%)", "hsl(23,95%,58%)", "hsl(78,95%,58%)", "hsl(133,95%,58%)"], ["hsl(355,95%,58%)", "hsl(50,95%,58%)", "hsl(105,95%,58%)", "hsl(160,95%,58%)", "hsl(215,95%,58%)", "hsl(270,95%,58%)"], ["hsl(133,95%,58%)", "hsl(188,95%,58%)", "hsl(243,95%,58%)", "hsl(298,95%,58%)", "hsl(353,95%,58%)", "hsl(48,95%,58%)"], ["hsl(270,95%,58%)", "hsl(325,95%,58%)", "hsl(20,95%,58%)", "hsl(75,95%,58%)", "hsl(130,95%,58%)", "hsl(185,95%,58%)"], ["hsl(48,95%,58%)", "hsl(103,95%,58%)", "hsl(158,95%,58%)", "hsl(213,95%,58%)", "hsl(268,95%,58%)", "hsl(323,95%,58%)"], ["hsl(185,95%,58%)", "hsl(240,95%,58%)", "hsl(295,95%,58%)", "hsl(350,95%,58%)", "hsl(45,95%,58%)", "hsl(100,95%,58%)"], ["hsl(323,95%,58%)", "hsl(18,95%,58%)", "hsl(73,95%,58%)", "hsl(128,95%,58%)", "hsl(183,95%,58%)", "hsl(238,95%,58%)"], ["hsl(100,95%,58%)", "hsl(155,95%,58%)", "hsl(210,95%,58%)", "hsl(265,95%,58%)", "hsl(320,95%,58%)", "hsl(15,95%,58%)"], ["hsl(238,95%,58%)", "hsl(293,95%,58%)", "hsl(348,95%,58%)", "hsl(43,95%,58%)", "hsl(98,95%,58%)", "hsl(153,95%,58%)"], ["hsl(15,95%,58%)", "hsl(70,95%,58%)", "hsl(125,95%,58%)", "hsl(180,95%,58%)", "hsl(235,95%,58%)", "hsl(290,95%,58%)"], ["hsl(153,95%,58%)", "hsl(208,95%,58%)", "hsl(263,95%,58%)", "hsl(318,95%,58%)", "hsl(13,95%,58%)", "hsl(68,95%,58%)"], ["hsl(290,95%,58%)", "hsl(345,95%,58%)", "hsl(40,95%,58%)", "hsl(95,95%,58%)", "hsl(150,95%,58%)", "hsl(205,95%,58%)"], ["hsl(68,95%,58%)", "hsl(123,95%,58%)", "hsl(178,95%,58%)", "hsl(233,95%,58%)", "hsl(288,95%,58%)", "hsl(343,95%,58%)"], ["hsl(205,95%,58%)", "hsl(260,95%,58%)", "hsl(315,95%,58%)", "hsl(10,95%,58%)", "hsl(65,95%,58%)", "hsl(120,95%,58%)"], ["hsl(343,95%,58%)", "hsl(38,95%,58%)", "hsl(93,95%,58%)", "hsl(148,95%,58%)", "hsl(203,95%,58%)", "hsl(258,95%,58%)"], ["hsl(120,95%,58%)", "hsl(175,95%,58%)", "hsl(230,95%,58%)", "hsl(285,95%,58%)", "hsl(340,95%,58%)", "hsl(35,95%,58%)"], ["hsl(258,95%,58%)", "hsl(313,95%,58%)", "hsl(8,95%,58%)", "hsl(63,95%,58%)", "hsl(118,95%,58%)", "hsl(173,95%,58%)"]];
const KEY='ATC_POSTER_FINAL_V4';
const LEGACY_KEY='ATC_POSTER_FINAL_V3';
const $=id=>document.getElementById(id);
const defaults={text:'',mode:'letter',style:0,bg:bgColors[0],bold:true,size:7,line:1.05,font:'sans',hist:[]};
let s=JSON.parse(localStorage.getItem(KEY)||'null');
if(!s){
  const legacy=JSON.parse(localStorage.getItem(LEGACY_KEY)||'null');
  s=legacy&&typeof legacy==='object'?{...defaults,...legacy,hist:Array.isArray(legacy.hist)?legacy.hist:[]}: {...defaults};
  // Old builds could accidentally save the page/interface text as the user's story.
  const bad=/AUTO TEXT COLOR|Make Your Text More Beautiful|Personal Settings|User Profile|50 Light Backgrounds|1000 Colors|Auto Color Apply|Save Image|Share to Others|Save as PDF|Letter Color|Word Color|Line Color|Settings/i;
  if(bad.test(String(s.text||''))){s.text='';}
  s.hist=s.hist.filter(h=>h&&typeof h.t==='string'&&!bad.test(h.t));
  localStorage.setItem(KEY,JSON.stringify(s));
}

function persist(){localStorage.setItem(KEY,JSON.stringify(s));}
// FINAL clean-box guard: never render known interface/demo phrases as user story.
function cleanStoredStory(){const bad=/AUTO TEXT COLOR|Make Your Text More Beautiful|Personal Settings|User Profile|50 Light Backgrounds|1000 Colors|Auto Color Apply|Save Image|Share to Others|Save as PDF|Letter Color|Word Color|Line Color|Settings/i;if(bad.test(String(s.text||''))){s.text='';persist();}}
function esc(x){return String(x).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}

function bindDirectInput(){cleanStoredStory();const e=document.getElementById('inputText');if(!e)return;e.value=s.text||'';const sync=()=>{s.text=e.value;persist();render();};e.addEventListener('input',sync);}
function render(){const p=palettes[s.style]||palettes[0],t=s.text||'';$('preview').style.background=s.bg;$('previewText').style.fontSize=s.size+'vw';$('previewText').style.fontWeight=s.bold?'900':'400';$('previewText').style.lineHeight=s.line||1.05;$('previewText').style.fontFamily=fontFamily(s.font);
if(s.mode==='letter')$('previewText').innerHTML=[...t].map((c,i)=>c===' '?'&nbsp;':`<span style="color:${p[i%p.length]}">${esc(c)}</span>`).join('');
else if(s.mode==='word'){let i=0;$('previewText').innerHTML=t.split(/(\s+)/).map(w=>/^\s+$/.test(w)?w.replace(/ /g,'&nbsp;'):`<span style="color:${p[i++%p.length]}">${esc(w)}</span>`).join('');}
else $('previewText').innerHTML=t.split(/\n/).map((x,i)=>`<div style="color:${p[i%p.length]}">${esc(x)||'&nbsp;'}</div>`).join('');
fitPreview();document.querySelectorAll('.mode').forEach(b=>b.classList.toggle('on',b.dataset.m===s.mode));document.querySelectorAll('.style').forEach((b,i)=>b.classList.toggle('on',i===s.style));}
function fitPreview(){const e=$('previewText'),box=$('preview');if(!e||!box)return;let max=parseFloat(getComputedStyle(e).fontSize),min=16;e.style.overflow='visible';e.style.maxHeight='none';e.style.width='100%';for(let i=0;i<40;i++){if(e.scrollWidth<=e.clientWidth+2)break;max*=.94;if(max<min){max=min;break}e.style.fontSize=max+'px';}}
function fontFamily(f){return ({sans:'Arial,\"Noto Sans Bengali\",sans-serif',serif:'Georgia,\"Noto Serif Bengali\",serif',mono:'\"Courier New\",monospace',rounded:'Trebuchet MS,Arial,\"Noto Sans Bengali\",sans-serif',classic:'Times New Roman,\"Noto Serif Bengali\",serif'})[f]||'Arial,\"Noto Sans Bengali\",sans-serif'}
function setFont(f){s.font=f;persist();render();toast('Font Style পরিবর্তন হয়েছে')}
function linePlus(){s.line=Math.min(2.2,Math.round((s.line+0.1)*10)/10);persist();render();toast('Line Spacing বাড়ানো হয়েছে')}
function lineMinus(){s.line=Math.max(.8,Math.round((s.line-0.1)*10)/10);persist();render();toast('Line Spacing কমানো হয়েছে')}
function mode(m){s.mode=m;persist();render();toast(m==='letter'?'Letter Color চালু':m==='word'?'Word Color চালু':'Line Color চালু');}
function style(i){s.style=i;persist();render();toast(styles[i]+' applied');}
function bg(c){s.bg=c;persist();render();toast('Color changed');}
function toast(x){const e=$('toast');e.textContent=x;e.classList.add('show');setTimeout(()=>e.classList.remove('show'),1400);}
function edit(){const e=$('inputText');if(e){e.focus();return}$('editor').value=s.text;$('editorBox').classList.add('show');$('editor').focus();}
function apply(){s.text=$('editor').value;const e=$('inputText');if(e)e.value=s.text;const c=$('counter');persist();$('editorBox').classList.remove('show');render();toast('AUTO: লেখা রঙ করা হয়েছে');}
function closeEdit(){$('editorBox').classList.remove('show');}
function canvasImage(){
 const c=document.createElement('canvas'),x=c.getContext('2d'); c.width=1600;c.height=700;
 x.fillStyle=s.bg||'#fff';x.fillRect(0,0,c.width,c.height);x.textAlign='center';x.textBaseline='middle';
 const fam=fontFamily(s.font).split(',')[0].replace(/"/g,''); x.font=(s.bold?'900':'400')+' 110px '+fam;
 const p=palettes[s.style]||palettes[0], lines=String(s.text||'').split(/\n/), lineH=125*(s.line||1.05), startY=350-(lines.length-1)*lineH/2;
 lines.forEach((line,li)=>{const chars=[...line];const widths=chars.map(ch=>x.measureText(ch).width);const total=widths.reduce((a,b)=>a+b,0);let pos=(1600-total)/2;
  chars.forEach((ch,i)=>{x.fillStyle=p[(i+li)%p.length];x.shadowColor='transparent';x.shadowBlur=0;x.fillText(ch,pos+widths[i]/2,startY+li*lineH);pos+=widths[i]});});
 return c;
}
function downloadBlob(blob,name){try{const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;a.rel='noopener';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);return true}catch(e){return false}}
function snapshotHistory(){
  const html=$('previewText')?.innerHTML||'';
  return {t:String(s.text||''),html,mode:s.mode,style:s.style,bg:s.bg,bold:s.bold,size:s.size,line:s.line,font:s.font,d:new Date().toLocaleString()};
}
function saveImg(){const c=canvasImage();c.toBlob(async b=>{if(!b){toast('SAVE করা যায়নি');return}let ok=false;
 try{if(navigator.share && navigator.canShare){const f=new File([b],'AUTO_TEXT_COLOR.png',{type:'image/png'});if(navigator.canShare({files:[f]})){await navigator.share({title:'AUTO TEXT COLOR',files:[f]});ok=true}}}catch(e){}
 if(!ok) ok=downloadBlob(b,'AUTO_TEXT_COLOR.png');
 if(String(s.text||'').trim()){s.hist.unshift(snapshotHistory());s.hist=s.hist.slice(0,30);persist();}
 toast(ok?'SAVE সম্পন্ন':'SAVE-এর জন্য ব্রাউজারের Download অনুমতি দিন');});}
function pdf(){const c=canvasImage();c.toBlob(b=>{if(!b){toast('PDF তৈরি করা যায়নি');return}const fr=new FileReader();fr.onload=()=>{try{
 const data=fr.result.split(',')[1],bin=atob(data),img=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)img[i]=bin.charCodeAt(i);
 const enc=new TextEncoder(),parts=[],offs=[0];let pos=0;const add=(v)=>{const u=v instanceof Uint8Array?v:enc.encode(v);parts.push(u);pos+=u.length};
 add('%PDF-1.4\n%âãÏÓ\n');const objs=[];const obj=(n,body,stream)=>{offs[n]=pos;add(n+' 0 obj\n');add(body);if(stream){add('\nstream\n');add(stream);add('\nendstream\n')}add('\nendobj\n')};
 obj(1,'<< /Type /Catalog /Pages 2 0 R >>');obj(2,'<< /Type /Pages /Kids [3 0 R] /Count 1 >>');obj(3,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 842 595] /Resources << /XObject << /Im 5 0 R >> >> /Contents 4 0 R >>');
 const content='q\n842 0 0 595 0 0 cm\n/Im Do\nQ\n';obj(4,'<< /Length '+content.length+' >>',content);obj(5,'<< /Type /XObject /Subtype /Image /Width 1600 /Height 700 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+img.length+' >>',img);
 const xref=pos;add('xref\n0 6\n0000000000 65535 f \n');for(let i=1;i<=5;i++)add(String(offs[i]).padStart(10,'0')+' 00000 n \n');add('trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n'+xref+'\n%%EOF');
 const out=new Uint8Array(parts.reduce((n,u)=>n+u.length,0));let at=0;for(const u of parts){out.set(u,at);at+=u.length}const ok=downloadBlob(new Blob([out],{type:'application/pdf'}),'AUTO_TEXT_COLOR.pdf');toast(ok?'PDF সম্পন্ন':'PDF-এর জন্য Download অনুমতি দিন');
 }catch(e){toast('PDF তৈরি করতে সমস্যা হয়েছে')}};fr.readAsDataURL(b)});
}
async function share(){try{const c=canvasImage();const b=await new Promise(r=>c.toBlob(r,'image/png'));if(navigator.share){const f=new File([b],'AUTO_TEXT_COLOR.png',{type:'image/png'});if(!navigator.canShare||navigator.canShare({files:[f]})){await navigator.share({title:'AUTO TEXT COLOR',text:s.text,files:[f]});toast('SHARE সম্পন্ন');return}await navigator.share({title:'AUTO TEXT COLOR',text:s.text});toast('SHARE সম্পন্ন');return}if(navigator.clipboard){await navigator.clipboard.writeText(s.text);toast('লেখা কপি হয়েছে')}else prompt('লেখা কপি করুন:',s.text)}catch(e){toast('Share বাতিল হয়েছে')}}
function openM(t,b){$('modalTitle').textContent=t;$('modalBody').innerHTML=b;$('modal').classList.add('show')}
function closeM(){$('modal').classList.remove('show')}
function colorsM(){let h='';for(let i=0;i<1000;i++){let c=`hsl(${(i*137.508)%360},92%,${48+(i%5)*4}%)`;h+=`<button aria-label="Color ${i+1}" style="height:30px;background:${c};padding:0;border-color:#fff" onclick="bg('${c}');closeM()"></button>`}openM('🌈 1000 Colors',`<div class="grid" style="grid-template-columns:repeat(12,minmax(0,1fr))">${h}</div>`)}
function bgColorsM(){let h=bgColors.map((c,i)=>`<button class="bgSwatch" aria-label="Background ${i+1}" title="${c}" style="height:52px;background:${c};border:2px solid #078dff;color:#123;font-weight:900" onclick="bg('${c}');closeM()">${i+1}</button>`).join('');openM('🖼️ 50 Professional Light Backgrounds',`<div class="grid" style="grid-template-columns:repeat(5,minmax(0,1fr));gap:.55vw">${h}</div><p style="text-align:center;color:#cfe1ff;margin:.8vw 0 0">৫০টি আলাদা হালকা, পরিষ্কার ও লেখাবান্ধব ব্যাকগ্রাউন্ড।</p>`)}
function historyM(){
 if(!s.hist.length){openM('🕘 History','<p style="text-align:center">History নেই</p>');return;}
 const items=s.hist.map((h,i)=>{
   const html=h.html||renderHistoryHTML(h.t,h.mode||s.mode,h.style??s.style);
   return `<div class="historyItem"><div class="historyStory">${html}</div><div class="historyMeta">History ${i+1} • ${esc(h.d||'')}</div><button onclick="restoreHistory(${i})">↩ এই লেখা ফিরিয়ে আনুন</button></div>`;
 }).join('');
 openM('🕘 History',`<div class="historyList">${items}</div>`);
}
function renderHistoryHTML(text,modeName,styleIndex){
 const p=palettes[styleIndex]||palettes[0],t=String(text||'');
 if(modeName==='word'){let i=0;return t.split(/(\s+)/).map(w=>/^\s+$/.test(w)?esc(w).replace(/ /g,'&nbsp;'):`<span style="color:${p[i++%p.length]}">${esc(w)}</span>`).join('');}
 if(modeName==='line')return t.split(/\n/).map((x,i)=>`<div style="color:${p[i%p.length]}">${esc(x)||'&nbsp;'}</div>`).join('');
 return [...t].map((c,i)=>c===' '?'&nbsp;':`<span style="color:${p[i%p.length]}">${esc(c)}</span>`).join('');
}
function restoreHistory(i){const h=s.hist[i];if(!h)return;s.text=h.t||'';if(h.mode)s.mode=h.mode;if(Number.isInteger(h.style))s.style=h.style;if(h.bg)s.bg=h.bg;if(typeof h.bold==='boolean')s.bold=h.bold;if(h.size)s.size=h.size;if(h.line)s.line=h.line;if(h.font)s.font=h.font;persist();const e=$('inputText');if(e)e.value=s.text;render();closeM();toast('History লেখা ফিরেছে');}

function smartSave(){persist();localStorage.setItem('ATC_AUTO_COLOR_SMART_SAVE',JSON.stringify({mode:s.mode,style:s.style,bg:s.bg,bold:s.bold,size:s.size,line:s.line,font:s.font,savedAt:new Date().toISOString()}));toast('AUTO COLOR SMART SAVE — মেমোরিতে সংরক্ষণ হয়েছে');}
function settings(){openM('⚙️ Settings',`<div class="grid settingsGrid">
<button onclick="mode('letter');closeM()">🔤 Letter Color</button><button onclick="mode('word');closeM()">🅦 Word Color</button>
<button onclick="mode('line');closeM()">☰ Line Color</button>
<button onclick="colorsM()">🌈 1000 Colors</button><button onclick="bgColorsM()">🖼️ 50 Light Backgrounds</button>
<button onclick="s.size=Math.min(10,s.size+1);persist();render();toast('Font বড় হয়েছে')">🔠 Font +</button><button onclick="s.size=Math.max(3,s.size-1);persist();render();toast('Font ছোট হয়েছে')">🔡 Font −</button>
<button onclick="s.bold=true;persist();render();toast('Bold চালু')">𝐁 Bold</button><button onclick="s.bold=false;persist();render();toast('Thin/Normal চালু')">T Thin / Normal</button>
<button onclick="linePlus()">↕️ Line Spacing +</button><button onclick="lineMinus()">↕️ Line Spacing −</button>
<button onclick="setFont('sans')">A Sans</button><button onclick="setFont('serif')">𝑨 Serif</button>
<button onclick="setFont('rounded')">Ⓣ Rounded</button><button onclick="setFont('mono')">𝚃 Mono</button>
<button onclick="historyM()">🕘 History</button><button onclick="persist();toast('Settings সংরক্ষণ হয়েছে')">💾 Save Settings</button>
<button onclick="resetSettings()">🔄 Reset Settings</button><button onclick="toggleDayNight()">🌙 Day / Night</button>
<button onclick="tvMode()">📺 TV 16:9 Mode</button><button onclick="mobileMode()">📱 Mobile Mode</button>
<button onclick="openProfile()">👤 User Profile</button><button onclick="liveColorView()">🎨 Live Color View</button><button onclick="deleteHistory()">🗑️ History Delete</button>
</div><button class="smartSaveBtn" onclick="smartSave()"><span class="smartIcon">🎨</span><span><strong>AUTO COLOR SMART SAVE</strong><small>Line Color • Letter Color • Word Color</small></span><b>👆 Tap to Save</b></button>`)}
function deleteHistory(){s.hist=[];persist();closeM();toast('History-এর সব লেখা ডিলিট হয়েছে')}
function resetSettings(){s={text:'',mode:'letter',style:0,bg:bgColors[0],bold:true,size:7,line:1.05,font:'sans',hist:[]};persist();document.body.classList.remove('day-mode');render();closeM();toast('Settings Reset হয়েছে')}
function toggleDayNight(){const on=!document.body.classList.contains('day-mode');document.body.classList.toggle('day-mode',on);localStorage.setItem('ATC_DAY_MODE',on?'1':'0');toast(on?'Day Mode চালু':'Night Mode চালু')}
function tvMode(){document.documentElement.classList.remove('mobile16');document.documentElement.classList.add('tv16');localStorage.setItem('ATC_TV_MODE','1');localStorage.removeItem('ATC_MOBILE_MODE');toast('TV 16:9 Mode চালু')}
function mobileMode(){document.documentElement.classList.remove('tv16');document.documentElement.classList.add('mobile16');localStorage.setItem('ATC_MOBILE_MODE','1');localStorage.removeItem('ATC_TV_MODE');toast('Mobile Mode চালু')}
function openProfile(){openM('👤 User Profile',`<div style="text-align:center"><img src="assets/profile.jpg" class="profile"><p>আপনার Profile Photo</p></div>`)}
function liveColorView(){render();const html=$('previewText').innerHTML||esc(s.text);openM('🎨 Live Color View',`<div class="liveViewBox"><div class="liveViewTitle">LIVE COLOR PREVIEW</div><div class="livePreview"><div class="previewText">${html}</div></div><p class="liveViewInfo">Letter Color • Word Color • Line Color</p></div>`)}
function nav(a){if(a==='settings')settings();else if(['letter','word','line'].includes(a))mode(a);else if(a==='colors')colorsM();else if(a==='backgrounds')bgColorsM();else if(a==='preview')render();else if(a==='about')openM('ℹ️ About','AUTO TEXT COLOR<br>21-inch TV • 16:9 • TV Friendly')}
if(localStorage.getItem('ATC_DAY_MODE')==='1')document.body.classList.add('day-mode');if(localStorage.getItem('ATC_TV_MODE')==='1')document.documentElement.classList.add('tv16');if(localStorage.getItem('ATC_MOBILE_MODE')==='1')document.documentElement.classList.add('mobile16');
function tick(){let d=new Date();$('clock').innerHTML=d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})+'<small>'+d.toLocaleDateString('en-US',{month:'short',day:'numeric',weekday:'short'})+'</small>'}setInterval(tick,1000);window.addEventListener('resize',()=>setTimeout(fitPreview,50));window.onload=()=>{tick();render()};
document.addEventListener('DOMContentLoaded',()=>{bindDirectInput();render();});
