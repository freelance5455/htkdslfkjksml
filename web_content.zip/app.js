let file=null,style="sleep",text="";
const $=id=>document.getElementById(id);
$("pdf").onchange=e=>{file=e.target.files[0];$("fileName").textContent=file?file.name:"لم يتم اختيار ملف";$("create").disabled=!file};
document.querySelectorAll(".opt").forEach(b=>b.onclick=()=>{document.querySelectorAll(".opt").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");style=b.dataset.style});
$("create").onclick=async()=>{
 $("status").classList.add("show");$("player").classList.remove("show");$("bar").style.width="35%";$("statusText").textContent="جاري تجهيز الرواية...";
 await new Promise(r=>setTimeout(r,700));$("bar").style.width="100%";
 $("statusText").textContent="تم اختيار الرواية. محرك PDF والذكاء الاصطناعي والصوت سيُضافون في نسخة الإنتاج.";
 $("player").classList.add("show");$("storyTitle").textContent=file.name.replace(/\.pdf$/i,"");
 $("playerInfo").textContent=style==="sleep"?"حكاية هادئة قبل النوم":style==="read"?"قراءة الرواية":"نسخة قصصية مختصرة";
};
$("play").onclick=()=>alert("النسخة التجريبية تعرض الواجهة فقط. في V2 سنضيف استخراج نص الـPDF + تحويله لحكاية + صوت AI فعلي.");
