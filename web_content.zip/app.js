const KEY="id_library_v11";
let state=JSON.parse(localStorage.getItem(KEY)||'{"items":[]}');
let page="library", searchText="", randomScope="all", randomLen="";
const $=s=>document.querySelector(s);
const save=()=>localStorage.setItem(KEY,JSON.stringify(state));
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const countChars=s=>Array.from(s).length;
const fmt=d=>{let x=new Date(d);return x.toLocaleString("zh-CN",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false}).replaceAll("/","-")};
function toast(t){let e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),1600)}
function addItems(text){let arr=text.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);if(!arr.length)return;let now=Date.now();arr.forEach((text,i)=>state.items.push({id:uid(),text,len:countChars(text),time:now+i,fav:false}));save();closeModal();render();toast(`已保存 ${arr.length} 条`)}
function openModal(){ $("#inputText").value="";$("#modal").classList.remove("hidden");$("#inputText").focus()}
function closeModal(){$("#modal").classList.add("hidden")}
function toggleFav(id){let x=state.items.find(a=>a.id===id);if(x){x.fav=!x.fav;save();render()}}
function remove(id){state.items=state.items.filter(x=>x.id!==id);save();render();toast("已删除")}
function copyText(t){navigator.clipboard?.writeText(t);toast("已复制")}
function rows(items){return items.sort((a,b)=>b.time-a.time).map(x=>`<div class="item"><div class="idtext" onclick="copyText(${JSON.stringify(x.text)})">${esc(x.text)}<div class="time">${fmt(x.time)}</div></div><button class="star ${x.fav?'on':''}" onclick="toggleFav('${x.id}')">★</button><button class="star" onclick="remove('${x.id}')">×</button></div>`).join("")}
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function library(items){let filtered=items.filter(x=>!searchText||x.text.toLowerCase().includes(searchText.toLowerCase()));let groups={};filtered.forEach(x=>(groups[x.len]??=[]).push(x));let keys=Object.keys(groups).sort((a,b)=>+a-+b);return `<div class="content"><input class="search" placeholder="搜索 ID" value="${esc(searchText)}" oninput="searchText=this.value;render()">${keys.length?keys.map(k=>`<div class="group"><div class="group-title">${k} 个字符</div>${rows(groups[k])}</div>`).join(""):'<div class="empty">还没有 ID<br>点击右上角 ＋ 开始记录</div>'}</div>`}
function favorites(items){let fav=items.filter(x=>x.fav);return `<div class="content"><div class="section-title">全部收藏 · ${fav.length}</div>${fav.length?rows(fav):'<div class="empty">暂无收藏</div>'}</div>`}
function randomPage(items){let lengths=[...new Set(items.map(x=>x.len))].sort((a,b)=>a-b);return `<div class="content"><div class="section-title">随机 ID</div><div class="chips"><button class="chip" onclick="randomScope='all';render()">全部</button><button class="chip" onclick="randomScope='fav';render()">收藏</button></div><select class="search" onchange="randomLen=this.value"><option value="">全部长度</option>${lengths.map(n=>`<option ${String(randomLen)===String(n)?'selected':''}>${n}</option>`).join("")}</select><div class="toolbar"><button onclick="doRandom()">随机一个</button></div><div id="randomResult" class="empty">点击“随机一个”</div></div>`}
function morePage(){return `<div class="content"><div class="section-title">数据</div><button class="list-btn" onclick="exportData()">导出全部 JSON 备份</button><button class="list-btn" onclick="exportTxt()">导出全部 TXT</button><button class="list-btn" onclick="exportCsv()">导出全部 CSV</button><button class="list-btn" onclick="document.getElementById('restore').click()">恢复 JSON 备份</button><input id="restore" type="file" accept=".json" hidden onchange="restoreData(event)"><div class="section-title">时间轴</div>${timeline()}<div class="section-title">说明</div><div class="small">所有数据只保存在本机浏览器/应用内部，不需要账号。</div></div>`}
function timeline(){let g={};state.items.slice().sort((a,b)=>b.time-a.time).forEach(x=>{let d=new Date(x.time).toLocaleDateString("zh-CN");(g[d]??=[]).push(x)});return Object.keys(g).map(d=>`<div class="group"><div class="group-title">${d}</div>${rows(g[d])}</div>`).join("")||'<div class="empty">暂无记录</div>'}
function render(){let main=$("#main");main.innerHTML=page==="library"?library(state.items):page==="favorites"?favorites(state.items):page==="random"?randomPage(state.items):morePage();document.querySelectorAll(".nav button").forEach(b=>b.classList.toggle("active",b.dataset.page===page))}
function doRandom(){let a=state.items.filter(x=>(randomScope==="all"||x.fav)&&(!randomLen||x.len==randomLen));if(!a.length){toast("没有符合条件的 ID");return}let x=a[Math.floor(Math.random()*a.length)];$("#randomResult").innerHTML=`<div style="font-size:24px;margin-top:35px">${esc(x.text)}</div><div class="small" style="margin-top:10px">${x.len} 个字符 · ${fmt(x.time)}</div><div class="toolbar" style="justify-content:center"><button onclick="copyText(${JSON.stringify(x.text)})">复制</button></div>`}
function download(name,content,type){let a=document.createElement("a");a.href=URL.createObjectURL(new Blob([content],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500)}
function exportData(){download("ID灵感库备份.json",JSON.stringify(state,null,2),"application/json")}
function exportTxt(){download("ID灵感库.txt",state.items.slice().sort((a,b)=>b.time-a.time).map(x=>x.text).join("\n"),"text/plain")}
function exportCsv(){let escv=v=>`"${String(v).replaceAll('"','""')}"`;download("ID灵感库.csv",["ID,字符数,创建时间,收藏",...state.items.map(x=>[escv(x.text),x.len,escv(fmt(x.time)),x.fav?1:0].join(","))].join("\n"),"text/csv")}
function restoreData(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(!Array.isArray(x.items))throw 0;state=x;save();render();toast("恢复成功")}catch{toast("备份文件无效")}};r.readAsText(f)}
$("#addTop").onclick=openModal;$("#closeModal").onclick=closeModal;$("#saveBtn").onclick=()=>addItems($("#inputText").value);
document.querySelectorAll(".nav button").forEach(b=>b.onclick=()=>{page=b.dataset.page;render()});
render();
if("serviceWorker" in navigator) navigator.serviceWorker.register("service-worker.js").catch(()=>{});
