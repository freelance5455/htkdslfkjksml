// =====================================================================
// VLADI SOUND PRO - APPLICATION COORDINATOR & MOBILE MANAGER
// =====================================================================

const FACTORY_PRESETS = [
  {
    id: 1,
    name: '01: Кларинет Хиджаз Ре',
    scale: 'hicaz',
    root: 2,
    interval: 'upper_3rd',
    instrument: 'clarinet',
    harmonyInstrument: 'same',
    soloVol: 0.9,
    harmVol: 0.85,
    portamento: 0.04,
    delayTime: 0.32,
    delayMix: 0.35,
    reverbMix: 0.28,
    microtones: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  },
  {
    id: 2,
    name: '02: Балкански Сакс Хиджазкар До',
    scale: 'hicazkar',
    root: 0,
    interval: 'upper_3rd',
    instrument: 'sax',
    harmonyInstrument: 'same',
    soloVol: 0.95,
    harmVol: 0.9,
    portamento: 0.035,
    delayTime: 0.28,
    delayMix: 0.30,
    reverbMix: 0.32,
    microtones: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  },
  {
    id: 3,
    name: '03: Акордеон Кабина Кюрди Сол',
    scale: 'kurdi',
    root: 7,
    interval: 'upper_3rd',
    instrument: 'accordion',
    harmonyInstrument: 'same',
    soloVol: 0.9,
    harmVol: 0.8,
    portamento: 0.02,
    delayTime: 0.35,
    delayMix: 0.22,
    reverbMix: 0.25,
    microtones: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  },
  {
    id: 4,
    name: '04: Сакс и Акордеон Терца Ре',
    scale: 'hicaz',
    root: 2,
    interval: 'upper_3rd',
    instrument: 'sax',
    harmonyInstrument: 'accordion',
    soloVol: 0.9,
    harmVol: 0.85,
    portamento: 0.04,
    delayTime: 0.30,
    delayMix: 0.35,
    reverbMix: 0.30,
    microtones: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  },
  {
    id: 5,
    name: '05: Кавал Саба Ре',
    scale: 'saba',
    root: 2,
    interval: 'upper_3rd',
    instrument: 'kaval',
    harmonyInstrument: 'same',
    soloVol: 0.9,
    harmVol: 0.8,
    portamento: 0.06,
    delayTime: 0.38,
    delayMix: 0.40,
    reverbMix: 0.38,
    microtones: [0, 0, 0, 0, -50, 0, 0, 0, 0, 0, 0, 0]
  },
  {
    id: 6,
    name: '06: Бузуки Нихавенд До',
    scale: 'nihavend',
    root: 0,
    interval: 'upper_6th',
    instrument: 'bouzouki',
    harmonyInstrument: 'same',
    soloVol: 1.0,
    harmVol: 0.85,
    portamento: 0.01,
    delayTime: 0.25,
    delayMix: 0.25,
    reverbMix: 0.22,
    microtones: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  },
  {
    id: 7,
    name: '07: Влади Синт Мажор Фа',
    scale: 'major',
    root: 5,
    interval: 'dual_3rd_oct',
    instrument: 'juzi_lead',
    harmonyInstrument: 'same',
    soloVol: 0.9,
    harmVol: 0.8,
    portamento: 0.05,
    delayTime: 0.33,
    delayMix: 0.35,
    reverbMix: 0.28,
    microtones: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  }
];

let harmonizer = null;
let audioEngine = null;
let midiCtrl = null;

let currentPresetIndex = 0;
let numpadBuffer = '';

document.addEventListener('DOMContentLoaded', () => {
  harmonizer = new EthnoHarmonizer();
  audioEngine = new JuzisoundAudioEngine();
  midiCtrl = new JuzisoundMidiController(audioEngine, harmonizer);

  initMobileNavigation();
  buildScaleButtons();
  buildRootButtons();
  buildIntervalButtons();
  buildMicrotoneButtons();
  buildPresetList();
  buildVirtualKeyboard();

  setupEventListeners();
  loadPreset(0);

  updateStatus('Готово за свирене! Свържи клавира или избери лад.');
});

function initMobileNavigation() {
  const tabs = document.querySelectorAll('.nav-tab');
  const pages = document.querySelectorAll('.tab-page');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetId = tab.dataset.tab;

      tabs.forEach(t => t.classList.remove('active'));
      pages.forEach(p => p.classList.remove('active'));

      tab.classList.add('active');
      const targetPage = document.getElementById(targetId);
      if (targetPage) targetPage.classList.add('active');
    });
  });
}

function buildScaleButtons() {
  const container = document.getElementById('scales-grid');
  container.innerHTML = '';

  for (const [key, scale] of Object.entries(SCALES)) {
    const btn = document.createElement('button');
    btn.className = 'btn-scale';
    btn.dataset.scale = key;
    btn.innerHTML = `<strong>${scale.name}</strong><span>${scale.desc}</span>`;
    btn.addEventListener('click', () => {
      harmonizer.setScale(key);
      updateScaleUI();
      updateStatus(`Лад: ${scale.name}`);
    });
    container.appendChild(btn);
  }
}

function buildRootButtons() {
  const container = document.getElementById('roots-grid');
  container.innerHTML = '';

  NOTE_NAMES_BG.forEach((name, idx) => {
    const btn = document.createElement('button');
    btn.className = 'btn-root';
    btn.dataset.root = idx;
    btn.innerText = name;
    btn.addEventListener('click', () => {
      harmonizer.setRootNote(idx);
      updateRootUI();
      updateStatus(`Тоналност: ${name}`);
    });
    container.appendChild(btn);
  });
}

function buildIntervalButtons() {
  const container = document.getElementById('intervals-grid');
  container.innerHTML = '';

  const intervals = [
    { id: 'upper_3rd', name: 'Горна терца' },
    { id: 'lower_3rd', name: 'Долна терца' },
    { id: 'upper_4th', name: 'Кварта' },
    { id: 'upper_6th', name: 'Секста' },
    { id: 'octave_up', name: 'Октава' },
    { id: 'dual_3rd_oct', name: 'Двоен глас' }
  ];

  intervals.forEach(item => {
    const btn = document.createElement('button');
    btn.className = 'btn-interval';
    btn.dataset.interval = item.id;
    btn.innerText = item.name;
    btn.addEventListener('click', () => {
      harmonizer.setInterval(item.id);
      updateIntervalUI();
      updateStatus(`Интервал: ${item.name}`);
    });
    container.appendChild(btn);
  });
}

function buildMicrotoneButtons() {
  const container = document.getElementById('microtones-grid');
  container.innerHTML = '';

  NOTE_NAMES_BG.forEach((name, idx) => {
    const btn = document.createElement('button');
    btn.className = 'btn-microtone';
    btn.dataset.note = idx;
    btn.innerHTML = `<span class="note-lbl">${name}</span><span class="cent-lbl">0</span>`;
    btn.addEventListener('click', () => {
      const isDetuned = harmonizer.toggleMicrotone(idx, -50);
      btn.classList.toggle('active', isDetuned);
      btn.querySelector('.cent-lbl').innerText = isDetuned ? '-1/4' : '0';
      midiCtrl.sendQuarterTonesToKorg();
      updateStatus(`Четвърт тон за ${name}: ${isDetuned ? 'Включен' : 'Изключен'}`);
    });
    container.appendChild(btn);
  });
}

function buildPresetList() {
  const container = document.getElementById('preset-list');
  container.innerHTML = '';

  FACTORY_PRESETS.forEach((preset, idx) => {
    const item = document.createElement('div');
    item.className = 'preset-item' + (idx === currentPresetIndex ? ' active' : '');
    item.dataset.index = idx;
    item.innerHTML = `<strong>${preset.name}</strong>`;
    item.addEventListener('click', () => loadPreset(idx));
    container.appendChild(item);
  });
}

function loadPreset(idx) {
  if (idx < 0 || idx >= FACTORY_PRESETS.length) return;
  currentPresetIndex = idx;
  const p = FACTORY_PRESETS[idx];

  harmonizer.setScale(p.scale);
  harmonizer.setRootNote(p.root);
  harmonizer.setInterval(p.interval);
  harmonizer.microtuning = [...p.microtones];

  audioEngine.instrument = p.instrument;
  audioEngine.harmonyInstrument = p.harmonyInstrument;
  audioEngine.soloVolume = p.soloVol;
  audioEngine.harmonyVolume = p.harmVol;
  audioEngine.portamentoTime = p.portamento;

  audioEngine.setDelay(p.delayTime, 0.42, p.delayMix);
  audioEngine.setReverb(2.2, p.reverbMix);

  updateScaleUI();
  updateRootUI();
  updateIntervalUI();
  updateMicrotoneUI();
  updatePresetListUI();
  syncFadersToEngine();

  document.getElementById('current-patch-display').innerText = p.name;
  updateStatus(`Зареден пач: ${p.name}`);
}

function updateScaleUI() {
  document.querySelectorAll('.btn-scale').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.scale === harmonizer.scaleKey);
  });
}

function updateRootUI() {
  document.querySelectorAll('.btn-root').forEach(btn => {
    btn.classList.toggle('active', parseInt(btn.dataset.root) === harmonizer.rootNote);
  });
}

function updateIntervalUI() {
  document.querySelectorAll('.btn-interval').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.interval === harmonizer.interval);
  });
}

function updateMicrotoneUI() {
  document.querySelectorAll('.btn-microtone').forEach(btn => {
    const idx = parseInt(btn.dataset.note);
    const cents = harmonizer.microtuning[idx] || 0;
    btn.classList.toggle('active', cents !== 0);
    btn.querySelector('.cent-lbl').innerText = cents !== 0 ? '-1/4' : '0';
  });
}

function updatePresetListUI() {
  document.querySelectorAll('.preset-item').forEach((item, idx) => {
    item.classList.toggle('active', idx === currentPresetIndex);
  });
}

function syncFadersToEngine() {
  const soloInst = document.getElementById('solo-instrument');
  if (soloInst) soloInst.value = audioEngine.instrument;
  const harmInst = document.getElementById('harmony-instrument');
  if (harmInst) harmInst.value = audioEngine.harmonyInstrument;

  const fSoloVol = document.getElementById('fader-solo-vol');
  if (fSoloVol) fSoloVol.value = audioEngine.soloVolume;
  const fHarmVol = document.getElementById('fader-harm-vol');
  if (fHarmVol) fHarmVol.value = audioEngine.harmonyVolume;
  const fPort = document.getElementById('fader-portamento');
  if (fPort) fPort.value = audioEngine.portamentoTime;

  const fDelayTime = document.getElementById('fader-delay-time');
  if (fDelayTime) fDelayTime.value = audioEngine.delayTime;
  const fDelayMix = document.getElementById('fader-delay-mix');
  if (fDelayMix) fDelayMix.value = audioEngine.delayMix;
  const fReverbMix = document.getElementById('fader-reverb-mix');
  if (fReverbMix) fReverbMix.value = audioEngine.reverbMix;
}

function buildVirtualKeyboard() {
  const container = document.getElementById('virtual-piano');
  if (!container) return;
  container.innerHTML = '';

  const startNote = 60;
  const numNotes = 25;

  for (let i = 0; i < numNotes; i++) {
    const note = startNote + i;
    const isBlack = [1, 3, 6, 8, 10].includes(note % 12);
    const key = document.createElement('div');
    key.className = `piano-key ${isBlack ? 'black' : 'white'}`;
    key.dataset.note = note;

    const noteName = NOTE_NAMES_BG[note % 12];
    key.innerHTML = `<span>${noteName}</span>`;

    const press = (e) => {
      e.preventDefault();
      audioEngine.init();
      midiCtrl.handleNoteOn(note, 110, 0);
    };

    const release = (e) => {
      e.preventDefault();
      midiCtrl.handleNoteOff(note, 0);
    };

    key.addEventListener('mousedown', press);
    key.addEventListener('mouseup', release);
    key.addEventListener('mouseleave', release);
    key.addEventListener('touchstart', press);
    key.addEventListener('touchend', release);

    container.appendChild(key);
  }
}

function setupEventListeners() {
  const btnTercaToggle = document.getElementById('btn-terca-toggle');
  btnTercaToggle.addEventListener('click', () => {
    audioEngine.init();
    harmonizer.enabled = !harmonizer.enabled;
    btnTercaToggle.classList.toggle('active', harmonizer.enabled);
    btnTercaToggle.querySelector('.status-text').innerText = harmonizer.enabled ? 'ВКЛЮЧЕНА' : 'ИЗКЛЮЧЕНА';
    updateStatus(`Терца: ${harmonizer.enabled ? 'Включена' : 'Изключена'}`);
  });

  document.getElementById('btn-panic').addEventListener('click', () => {
    midiCtrl.panic();
    updateStatus('Всички звуци са спрени.');
  });

  document.querySelectorAll('.btn-quick-makam').forEach(btn => {
    btn.addEventListener('click', () => {
      const scale = btn.dataset.scale;
      const root = parseInt(btn.dataset.root);
      harmonizer.setScale(scale);
      harmonizer.setRootNote(root);
      harmonizer.resetMicrotuning();
      if (scale === 'saba') {
        harmonizer.toggleMicrotone(4, -50);
      }
      updateScaleUI();
      updateRootUI();
      updateMicrotoneUI();
      midiCtrl.sendQuarterTonesToKorg();
      updateStatus(`Зареден макам: ${btn.innerText}`);
    });
  });

  document.getElementById('solo-instrument').addEventListener('change', (e) => {
    audioEngine.instrument = e.target.value;
  });
  document.getElementById('harmony-instrument').addEventListener('change', (e) => {
    audioEngine.harmonyInstrument = e.target.value;
  });
  document.getElementById('fader-solo-vol').addEventListener('input', (e) => {
    audioEngine.soloVolume = parseFloat(e.target.value);
  });
  document.getElementById('fader-harm-vol').addEventListener('input', (e) => {
    audioEngine.harmonyVolume = parseFloat(e.target.value);
  });
  document.getElementById('fader-portamento').addEventListener('input', (e) => {
    audioEngine.portamentoTime = parseFloat(e.target.value);
  });
  document.getElementById('fader-delay-time').addEventListener('input', (e) => {
    audioEngine.setDelay(parseFloat(e.target.value), audioEngine.delayFeedbackVal, audioEngine.delayMix);
  });
  document.getElementById('fader-delay-mix').addEventListener('input', (e) => {
    audioEngine.setDelay(audioEngine.delayTime, audioEngine.delayFeedbackVal, parseFloat(e.target.value));
  });
  document.getElementById('fader-reverb-mix').addEventListener('input', (e) => {
    audioEngine.setReverb(audioEngine.reverbDecay, parseFloat(e.target.value));
  });

  document.getElementById('chk-audio-out').addEventListener('change', (e) => {
    midiCtrl.outputToInternalAudio = e.target.checked;
  });
  document.getElementById('chk-korg-out').addEventListener('change', (e) => {
    midiCtrl.outputToKorgMidi = e.target.checked;
  });
  document.getElementById('sel-korg-ch').addEventListener('change', (e) => {
    midiCtrl.korgHarmonizerChannel = parseInt(e.target.value);
  });
  document.getElementById('sel-pedal-mode').addEventListener('change', (e) => {
    midiCtrl.pedalMode = e.target.value;
  });

  document.getElementById('btn-clear-micro').addEventListener('click', () => {
    harmonizer.resetMicrotuning();
    updateMicrotoneUI();
    midiCtrl.sendQuarterTonesToKorg();
    updateStatus('Всички четвърт тонове са нулирани.');
  });
  document.getElementById('btn-send-korg-sysex').addEventListener('click', () => {
    midiCtrl.sendQuarterTonesToKorg();
    updateStatus('Изпратени настройки към клавира!');
  });

  document.querySelectorAll('.numpad-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.dataset.num;
      if (val === 'enter') {
        const patchNum = parseInt(numpadBuffer);
        if (!isNaN(patchNum) && patchNum >= 1 && patchNum <= FACTORY_PRESETS.length) {
          loadPreset(patchNum - 1);
        }
        numpadBuffer = '';
      } else if (val === 'clear') {
        numpadBuffer = '';
      } else {
        numpadBuffer += val;
      }
      document.getElementById('numpad-display').innerText = numpadBuffer || '--';
    });
  });

  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space') {
      e.preventDefault();
      document.getElementById('btn-terca-toggle').click();
      return;
    }
    if (e.key >= '0' && e.key <= '9') {
      numpadBuffer += e.key;
      document.getElementById('numpad-display').innerText = numpadBuffer;
    } else if (e.key === 'Enter') {
      const patchNum = parseInt(numpadBuffer);
      if (!isNaN(patchNum) && patchNum >= 1 && patchNum <= FACTORY_PRESETS.length) {
        loadPreset(patchNum - 1);
      }
      numpadBuffer = '';
      document.getElementById('numpad-display').innerText = '--';
    } else if (e.key === 'Backspace' || e.key === 'Escape') {
      numpadBuffer = '';
      document.getElementById('numpad-display').innerText = '--';
    }
  });

  midiCtrl.onNoteEvent = (note, isHarmonized, isOn) => {
    const keyEl = document.querySelector(`.piano-key[data-note="${note}"]`);
    if (keyEl) {
      if (isOn) {
        keyEl.classList.add(isHarmonized ? 'harm-active' : 'solo-active');
      } else {
        keyEl.classList.remove('solo-active', 'harm-active');
      }
    }

    if (isOn) {
      const noteName = NOTE_NAMES_BG[note % 12];
      if (isHarmonized) {
        document.getElementById('live-harm-note').innerText = noteName;
      } else {
        document.getElementById('live-solo-note').innerText = noteName;
      }
    }
  };

  midiCtrl.onStatusChange = (msg) => updateStatus(msg);

  midiCtrl.onDeviceListChange = (inputs, outputs, selIn, selOut) => {
    const inSelect = document.getElementById('midi-in-select');
    const outSelect = document.getElementById('midi-out-select');
    inSelect.innerHTML = '<option value="">-- Избери вход от клавира --</option>';
    outSelect.innerHTML = '<option value="">-- Избери изход към клавира --</option>';

    inputs.forEach(i => {
      const opt = document.createElement('option');
      opt.value = i.id;
      opt.text = i.name;
      opt.selected = (selIn && selIn.id === i.id);
      inSelect.appendChild(opt);
    });

    outputs.forEach(o => {
      const opt = document.createElement('option');
      opt.value = o.id;
      opt.text = o.name;
      opt.selected = (selOut && selOut.id === o.id);
      outSelect.appendChild(opt);
    });

    const isConnected = !!selIn || !!selOut;
    document.getElementById('korg-indicator').classList.toggle('online', isConnected);
  };
}

function updateStatus(text) {
  const el = document.getElementById('status-bar');
  if (el) el.innerText = text;
}
