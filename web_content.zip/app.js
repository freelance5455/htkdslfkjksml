// Lucifer AI Core — Powered by Gemini 3.8 Flash + Android WebView Bridges
const STORAGE_KEY = "lucifer_ai_config_v1";
const HISTORY_KEY = "lucifer_ai_history_v1";

let config = {
  apiKey: "",
  model: "gemini-3.8-flash",
  systemPrompt: "You are Lucifer, a sharp, loyal, witty, and ultra-capable personal AI assistant running directly on the user's Android device. Keep responses crisp, direct, and natural. You can analyze uploaded files, generate downloadable files, and trigger Android device actions using your built-in tools.",
  ttsEnabled: true
};

let chatHistory = [];
let pendingFiles = [];

// DOM Elements
const chatContainer = document.getElementById("chatContainer");
const promptInput = document.getElementById("promptInput");
const sendBtn = document.getElementById("sendBtn");
const micBtn = document.getElementById("micBtn");
const fileInput = document.getElementById("fileInput");
const attachmentBar = document.getElementById("attachmentBar");
const statusOrb = document.getElementById("statusOrb");
const modelBadge = document.getElementById("modelBadge");
const settingsModal = document.getElementById("settingsModal");

// Load saved config & history
function init() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    config = { ...config, ...JSON.parse(saved) };
  }
  const savedHistory = localStorage.getItem(HISTORY_KEY);
  if (savedHistory) {
    chatHistory = JSON.parse(savedHistory);
    renderSavedHistory();
  }
  modelBadge.textContent = config.model;
  document.getElementById("ttsToggleBtn").classList.toggle("active", config.ttsEnabled);

  if (!config.apiKey) {
    openSettings();
  }
}

function saveConfig() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  modelBadge.textContent = config.model;
}

function renderSavedHistory() {
  if (!chatHistory.length) return;
  chatContainer.innerHTML = "";
  chatHistory.forEach(turn => {
    const textPart = turn.parts.find(p => p.text);
    if (textPart && (turn.role === "user" || turn.role === "model")) {
      appendMessage(turn.role === "user" ? "user" : "assistant", textPart.text);
    }
  });
}

// Settings Modal Controls
function openSettings() {
  document.getElementById("apiKeyInput").value = config.apiKey;
  document.getElementById("modelSelect").value = config.model;
  document.getElementById("systemPromptInput").value = config.systemPrompt;
  settingsModal.classList.remove("hidden");
}

document.getElementById("settingsBtn").addEventListener("click", openSettings);
document.getElementById("closeSettingsBtn").addEventListener("click", () => settingsModal.classList.add("hidden"));
document.getElementById("saveSettingsBtn").addEventListener("click", () => {
  config.apiKey = document.getElementById("apiKeyInput").value.trim();
  config.model = document.getElementById("modelSelect").value;
  config.systemPrompt = document.getElementById("systemPromptInput").value.trim();
  saveConfig();
  settingsModal.classList.add("hidden");
  appendMessage("assistant", `Settings saved. Connected to ${config.model}.`);
});

document.getElementById("ttsToggleBtn").addEventListener("click", (e) => {
  config.ttsEnabled = !config.ttsEnabled;
  e.target.classList.toggle("active", config.ttsEnabled);
  if (!config.ttsEnabled && window.speechSynthesis) window.speechSynthesis.cancel();
  saveConfig();
});

document.getElementById("clearChatBtn").addEventListener("click", () => {
  chatHistory = [];
  localStorage.removeItem(HISTORY_KEY);
  chatContainer.innerHTML = "";
  appendMessage("assistant", "Memory wiped. Ready for your next command.");
});

// File Attachment Handling (Images, PDFs, Text, Code)
fileInput.addEventListener("change", async (e) => {
  const files = Array.from(e.target.files);
  for (const file of files) {
    const base64Data = await fileToBase64(file);
    pendingFiles.push({
      name: file.name,
      mimeType: file.type || "text/plain",
      data: base64Data
    });
  }
  renderAttachments();
  fileInput.value = "";
});

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result.split(",")[1];
      resolve(result);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function renderAttachments() {
  if (!pendingFiles.length) {
    attachmentBar.classList.add("hidden");
    attachmentBar.innerHTML = "";
    return;
  }
  attachmentBar.classList.remove("hidden");
  attachmentBar.innerHTML = pendingFiles.map((f, idx) => `
    <div class="attachment-pill">
      <span>📄 ${f.name}</span>
      <button onclick="removeAttachment(${idx})">✕</button>
    </div>
  `).join("");
}

window.removeAttachment = function(idx) {
  pendingFiles.splice(idx, 1);
  renderAttachments();
};

// Device & File Tool Declarations for Gemini Function Calling
const LUCIFER_TOOLS = [{
  functionDeclarations: [
    {
      name: "create_downloadable_file",
      description: "Creates and downloads a file (txt, md, html, json, csv, py, js) directly onto the user's Android device.",
      parameters: {
        type: "OBJECT",
        properties: {
          filename: { type: "STRING", description: "File name with extension, e.g., notes.txt or script.py" },
          content: { type: "STRING", description: "Full text content of the file" },
          mimeType: { type: "STRING", description: "MIME type, e.g., text/plain or text/markdown" }
        },
        required: ["filename", "content"]
      }
    },
    {
      name: "device_action",
      description: "Controls Android device features available through WebView/HTML5 bridges: vibrate, get_battery, get_location, open_url, share_text, set_timer, or toggle_flashlight.",
      parameters: {
        type: "OBJECT",
        properties: {
          action: {
            type: "STRING",
            enum: ["vibrate", "get_battery", "get_location", "open_url", "share_text", "set_timer", "toggle_flashlight"],
            description: "The device action to execute"
          },
          value: { type: "STRING", description: "URL to open, text to share, duration in seconds for timer/vibration, or 'on'/'off' for flashlight" }
        },
        required: ["action"]
      }
    }
  ]
}];

// Execute Local Device & File Functions
async function executeToolCall(call) {
  const { name, args } = call;

  if (name === "create_downloadable_file") {
    const mime = args.mimeType || "text/plain";
    const blob = new Blob([args.content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = args.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    return { status: "success", message: `File '${args.filename}' generated and triggered for download.` };
  }

  if (name === "device_action") {
    const act = args.action;
    const val = args.value || "";

    if (act === "vibrate") {
      if (navigator.vibrate) navigator.vibrate(parseInt(val, 10) || 400);
      return { status: "success", message: "Device vibrated." };
    }
    if (act === "get_battery") {
      if (navigator.getBattery) {
        const b = await navigator.getBattery();
        return { level: `${Math.round(b.level * 100)}%`, charging: b.charging };
      }
      return { status: "unsupported", message: "Battery API unavailable in this WebView." };
    }
    if (act === "get_location") {
      return new Promise((resolve) => {
        if (!navigator.geolocation) return resolve({ status: "error", message: "Geolocation not supported." });
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
          (err) => resolve({ status: "error", message: err.message }),
          { timeout: 6000 }
        );
      });
    }
    if (act === "open_url") {
      window.open(val, "_blank");
      return { status: "success", message: `Opened ${val}` };
    }
    if (act === "share_text") {
      if (navigator.share) {
        await navigator.share({ title: "Lucifer AI", text: val });
        return { status: "success", message: "Share sheet opened." };
      }
      return { status: "error", message: "Native share unavailable." };
    }
    if (act === "set_timer") {
      const secs = parseInt(val, 10) || 60;
      setTimeout(() => {
        if (navigator.vibrate) navigator.vibrate([500, 200, 500]);
        speakText("Time is up!");
        appendMessage("assistant", `⏰ Timer finished (${secs} seconds).`);
      }, secs * 1000);
      return { status: "success", message: `Timer running for ${secs} seconds.` };
    }
    if (act === "toggle_flashlight") {
      // Works with HTML-to-APK builders exposing window.AndroidAPI or standard torch constraints
      if (window.AndroidAPI && typeof window.AndroidAPI.setFlashlight === "function") {
        window.AndroidAPI.setFlashlight(val === "on");
        return { status: "success", message: `Flashlight turned ${val}.` };
      }
      return { status: "info", message: "Enable Flashlight Bridge in your HTML-to-APK builder settings for hardware torch access." };
    }
  }
  return { status: "error", message: "Unknown tool." };
}

// Send Prompt to Gemini 3.8 Flash API
async function sendMessage(overrideText = null) {
  const text = (overrideText !== null ? overrideText : promptInput.value).trim();
  if (!text && !pendingFiles.length) return;

  if (!config.apiKey) {
    openSettings();
    return;
  }

  promptInput.value = "";
  const userParts = [];
  if (text) userParts.push({ text });

  const attachedSnapshot = [...pendingFiles];
  attachedSnapshot.forEach(file => {
    userParts.push({
      inlineData: {
        mimeType: file.mimeType,
        data: file.data
      }
    });
  });

  pendingFiles = [];
  renderAttachments();

  const displayLabel = attachedSnapshot.length
    ? `${text}\n[Attached: ${attachedSnapshot.map(f => f.name).join(", ")}]`
    : text;

  appendMessage("user", displayLabel);
  chatHistory.push({ role: "user", parts: userParts });

  statusOrb.classList.add("thinking");

  try {
    await runGeminiTurn();
  } catch (err) {
    appendMessage("assistant", `Error: ${err.message}`);
  } finally {
    statusOrb.classList.remove("thinking");
    localStorage.setItem(HISTORY_KEY, JSON.stringify(chatHistory.slice(-20)));
  }
}

async function runGeminiTurn() {
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(config.model)}:generateContent?key=${encodeURIComponent(config.apiKey)}`;

  const payload = {
    systemInstruction: {
      parts: [{ text: config.systemPrompt }]
    },
    contents: chatHistory,
    tools: LUCIFER_TOOLS
  };

  const res = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error?.message || `HTTP ${res.status}`);
  }

  const candidate = data.candidates?.[0];
  const modelContent = candidate?.content;
  if (!modelContent || !modelContent.parts) {
    throw new Error("Empty response from Gemini.");
  }

  chatHistory.push(modelContent);

  // Check if Gemini requested a tool call
  const fnCallPart = modelContent.parts.find(p => p.functionCall);
  if (fnCallPart) {
    const fnCall = fnCallPart.functionCall;
    const toolResult = await executeToolCall(fnCall);

    chatHistory.push({
      role: "user",
      parts: [{
        functionResponse: {
          name: fnCall.name,
          response: toolResult
        }
      }]
    });

    // Continue turn so Gemini confirms the action naturally
    return await runGeminiTurn();
  }

  const replyText = modelContent.parts.map(p => p.text || "").join("").trim();
  if (replyText) {
    appendMessage("assistant", replyText);
    speakText(replyText);
  }
}

function appendMessage(role, text) {
  const wrapper = document.createElement("div");
  wrapper.className = `message ${role}`;
  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;
  wrapper.appendChild(bubble);
  chatContainer.appendChild(wrapper);
  chatContainer.scrollTop = chatContainer.scrollHeight;
}

function speakText(text) {
  if (!config.ttsEnabled || !window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const clean = text.replace(/[*#_`]/g, "");
  const utterance = new SpeechSynthesisUtterance(clean);
  utterance.rate = 1.04;
  window.speechSynthesis.speak(utterance);
}

window.triggerQuickPrompt = function(text) {
  sendMessage(text);
};

// Voice Input via Web Speech API
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.lang = "en-US";
  recognition.interimResults = false;

  micBtn.addEventListener("click", () => {
    micBtn.classList.add("listening");
    recognition.start();
  });

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    micBtn.classList.remove("listening");
    sendMessage(transcript);
  };

  recognition.onerror = () => micBtn.classList.remove("listening");
  recognition.onend = () => micBtn.classList.remove("listening");
} else {
  micBtn.style.opacity = "0.4";
  micBtn.title = "Speech recognition unavailable in this WebView";
}

sendBtn.addEventListener("click", () => sendMessage());
promptInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

init();
