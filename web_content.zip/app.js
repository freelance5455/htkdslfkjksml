const STORAGE_KEY = "memories_v2_secure";

const defaultData = {
    events: [
        {
            id: id(),
            title: "Aniversário de namoro",
            date: "2026-11-28",
            type: "❤️ Data especial"
        }
    ],
    notes: [],
    gifts: [],
    moments: []
};

let data = null;
let current = new Date();
let currentPage = "home";
let cryptoKey = null;


/* =========================================================
   FUNÇÕES BÁSICAS
========================================================= */

function id() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function todayISO() {
    let d = new Date();

    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function esc(s = "") {
    return String(s).replace(/[&<>"']/g, m => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
    }[m]));
}

function val(x) {
    return document.getElementById(x).value.trim();
}

function fmtDate(d) {
    return new Date(d + "T12:00:00").toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "long",
        year: "numeric"
    });
}

function shortDate(d) {
    return new Date(d + "T12:00:00").toLocaleDateString("pt-BR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    });
}

function toast(t) {
    let x = document.getElementById("toast");

    x.textContent = t;
    x.className = "toast";

    setTimeout(() => {
        x.className = "";
    }, 2200);
}

function nextEvent() {
    let t = todayISO();

    return data.events
        .filter(e => e.date >= t)
        .sort((a, b) => a.date.localeCompare(b.date))[0] || null;
}

function countdown(date) {
    let a = new Date();
    let b = new Date(date + "T00:00:00");

    return {
        d: Math.max(0, Math.ceil((b - a) / 86400000))
    };
}


/* =========================================================
   CRIPTOGRAFIA
========================================================= */

function bufToB64(buf) {
    let bytes = new Uint8Array(buf);
    let bin = "";

    for (let b of bytes) {
        bin += String.fromCharCode(b);
    }

    return btoa(bin);
}

function b64ToBuf(s) {
    let bin = atob(s);
    let bytes = new Uint8Array(bin.length);

    for (let i = 0; i < bin.length; i++) {
        bytes[i] = bin.charCodeAt(i);
    }

    return bytes.buffer;
}

async function derive(password, salt) {

    let base = await crypto.subtle.importKey(
        "raw",
        new TextEncoder().encode(password),
        "PBKDF2",
        false,
        ["deriveKey"]
    );

    return crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: salt,
            iterations: 150000,
            hash: "SHA-256"
        },
        base,
        {
            name: "AES-GCM",
            length: 256
        },
        false,
        ["encrypt", "decrypt"]
    );
}

async function encrypt(obj, key) {

    let iv = crypto.getRandomValues(new Uint8Array(12));

    let bytes = await crypto.subtle.encrypt(
        {
            name: "AES-GCM",
            iv: iv
        },
        key,
        new TextEncoder().encode(JSON.stringify(obj))
    );

    return {
        iv: bufToB64(iv),
        data: bufToB64(bytes)
    };
}

async function decrypt(packet, key) {

    let plain = await crypto.subtle.decrypt(
        {
            name: "AES-GCM",
            iv: new Uint8Array(b64ToBuf(packet.iv))
        },
        key,
        b64ToBuf(packet.data)
    );

    return JSON.parse(
        new TextDecoder().decode(plain)
    );
}


/* =========================================================
   SALVAR / CARREGAR
========================================================= */

async function save() {

    if (!cryptoKey) {
        return;
    }

    let packet = await encrypt(data, cryptoKey);

    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(packet)
    );

    render();
}

async function loadSecure(key) {

    let raw = localStorage.getItem(STORAGE_KEY);

    if (!raw) {

        return {
            ...defaultData,
            events: defaultData.events.map(e => ({
                ...e,
                id: id()
            }))
        };
    }

    return await decrypt(
        JSON.parse(raw),
        key
    );
}


/* =========================================================
   LOGIN
   SENHA: 141816
========================================================= */

async function setupOrLogin() {

    const FIXED_PASSWORD = "141816";

    /*
     * Salt fixo para esta versão.
     * Os dados continuam sendo armazenados
     * criptografados com AES-GCM.
     */
    const FIXED_SALT = new TextEncoder().encode(
        "memories-v3-private-salt"
    );

    document.getElementById(
        "loginDescription"
    ).textContent =
        "Digite sua senha para entrar nas suas anotações.";

    document.getElementById(
        "loginButton"
    ).textContent = "Entrar";


    document.getElementById(
        "loginForm"
    ).onsubmit = async e => {

        e.preventDefault();

        const p =
            document.getElementById(
                "loginPassword"
            ).value;

        const err =
            document.getElementById(
                "loginError"
            );

        err.textContent = "";


        /* VERIFICA SENHA */

        if (p !== FIXED_PASSWORD) {

            err.textContent =
                "Senha incorreta.";

            document.getElementById(
                "loginPassword"
            ).select();

            return;
        }


        try {

            const key = await derive(
                p,
                FIXED_SALT
            );

            cryptoKey = key;


            const raw =
                localStorage.getItem(
                    STORAGE_KEY
                );


            /* PRIMEIRO ACESSO */

            if (!raw) {

                data = {
                    ...defaultData,

                    events:
                        defaultData.events.map(e => ({
                            ...e,
                            id: id()
                        }))
                };

                await save();

            }

            /* DADOS EXISTENTES */

            else {

                data =
                    await loadSecure(key);
            }


            unlock();

        }

        catch (x) {

            cryptoKey = null;
            data = null;

            err.textContent =
                "Não foi possível desbloquear os dados.";
        }
    };
}


/* =========================================================
   ENTRAR / BLOQUEAR
========================================================= */

function unlock() {

    document
        .getElementById("loginScreen")
        .classList.add("hidden");

    document
        .getElementById("app")
        .classList.remove("hidden");

    document
        .getElementById("loginPassword")
        .value = "";

    render();
    nav();
}

function lock() {

    cryptoKey = null;
    data = null;

    document
        .getElementById("app")
        .classList.add("hidden");

    document
        .getElementById("loginScreen")
        .classList.remove("hidden");

    document
        .getElementById("loginPassword")
        .focus();

    toast("Memories bloqueado 🔒");
}


/* =========================================================
   NAVEGAÇÃO
========================================================= */

function nav() {

    document
        .querySelectorAll(".nav-btn")
        .forEach(b => {

            b.onclick = () => {

                currentPage = b.dataset.page;


                document
                    .querySelectorAll(".nav-btn")
                    .forEach(x => {

                        x.classList.toggle(
                            "active",
                            x === b
                        );

                    });


                document
                    .querySelectorAll(".page")
                    .forEach(p => {

                        p.classList.toggle(
                            "active",
                            p.id === currentPage
                        );

                    });


                document.getElementById(
                    "pageTitle"
                ).textContent = {

                    home: "Início",
                    calendar: "Calendário",
                    notes: "Notas",
                    gifts: "Presentes",
                    moments: "Momentos"

                }[currentPage];


                render();
            };
        });
}


/* =========================================================
   RENDER GERAL
========================================================= */

function render() {

    if (!data) {
        return;
    }

    document.getElementById(
        "todayLabel"
    ).textContent =
        new Date().toLocaleDateString(
            "pt-BR",
            {
                weekday: "long",
                day: "numeric",
                month: "long"
            }
        );

    renderHome();
    renderCalendar();
    renderNotes();
    renderGifts();
    renderMoments();
}


/* =========================================================
   HOME
========================================================= */

function renderHome() {

    const el =
        document.getElementById("home");

    const e = nextEvent();

    const c =
        e ? countdown(e.date) : null;


    el.innerHTML = `

        <div class="grid home-grid">

            <div class="card hero">

                <div class="eyebrow">
                    próxima data importante
                </div>

                ${
                    e

                    ? `

                        <h2>
                            ${esc(e.title)}
                        </h2>

                        <p>
                            ${fmtDate(e.date)}
                        </p>

                        <div class="countdown">

                            <div class="countbox">

                                <b>
                                    ${c.d}
                                </b>

                                <span>
                                    dias
                                </span>

                            </div>

                        </div>

                    `

                    : `

                        <h2>
                            Nenhuma data cadastrada
                        </h2>

                        <p>
                            Adicione uma data especial para começar.
                        </p>

                    `
                }

                <div style="margin-top:22px">

                    <button
                        class="primary"
                        onclick="openEvent()"
                    >
                        ＋ Nova data
                    </button>

                </div>

            </div>


            <div class="card">

                <div class="section-head">

                    <h3>
                        Resumo
                    </h3>

                </div>


                <div class="list">

                    <div class="list-item">
                        <div>📅 Datas</div>
                        <b>${data.events.length}</b>
                    </div>

                    <div class="list-item">
                        <div>📝 Notas</div>
                        <b>${data.notes.length}</b>
                    </div>

                    <div class="list-item">
                        <div>🎁 Presentes</div>
                        <b>${data.gifts.length}</b>
                    </div>

                    <div class="list-item">
                        <div>♡ Momentos</div>
                        <b>${data.moments.length}</b>
                    </div>

                </div>

            </div>


            <div class="card">

                <div class="section-head">

                    <h3>
                        Últimas notas
                    </h3>

                    <button
                        class="ghost"
                        onclick="go('notes')"
                    >
                        Ver todas
                    </button>

                </div>

                ${
                    data.notes.length

                    ? `

                        <div class="list">

                            ${
                                data.notes
                                    .slice(-4)
                                    .reverse()
                                    .map(n => `

                                        <div class="list-item">

                                            <div>

                                                <span class="tag">
                                                    ${esc(n.category)}
                                                </span>

                                                <div>
                                                    <b>
                                                        ${esc(n.title)}
                                                    </b>
                                                </div>

                                            </div>

                                            <span class="meta">
                                                ${shortDate(n.created)}
                                            </span>

                                        </div>

                                    `)
                                    .join("")
                            }

                        </div>

                    `

                    : `

                        <div class="empty">
                            Ainda não há notas.
                        </div>

                    `
                }

            </div>


            <div class="card">

                <div class="section-head">

                    <h3>
                        Próximas datas
                    </h3>

                    <button
                        class="ghost"
                        onclick="go('calendar')"
                    >
                        Calendário
                    </button>

                </div>

                ${
                    data.events.length

                    ? `

                        <div class="list">

                            ${
                                data.events

                                    .filter(
                                        e =>
                                            e.date >= todayISO()
                                    )

                                    .sort(
                                        (a,b) =>
                                            a.date.localeCompare(
                                                b.date
                                            )
                                    )

                                    .slice(0,4)

                                    .map(e => `

                                        <div class="list-item">

                                            <div>

                                                <b>
                                                    ${esc(e.title)}
                                                </b>

                                                <div class="meta">
                                                    ${esc(
                                                        e.type ||
                                                        "Evento"
                                                    )}
                                                </div>

                                            </div>

                                            <b>
                                                ${shortDate(e.date)}
                                            </b>

                                        </div>

                                    `)
                                    .join("")
                            }

                        </div>

                    `

                    : `

                        <div class="empty">
                            Adicione uma data.
                        </div>

                    `
                }

            </div>

        </div>
    `;
}


/* =========================================================
   CALENDÁRIO
========================================================= */

function renderCalendar() {

    const y =
        current.getFullYear();

    const m =
        current.getMonth();

    const first =
        new Date(y, m, 1);

    const start =
        (first.getDay() + 6) % 7;

    const days =
        new Date(y, m + 1, 0).getDate();

    const prev =
        new Date(y, m, 0).getDate();

    let cells = "";


    for (let i = 0; i < 42; i++) {

        let num =
            i - start + 1;

        let mm = m;
        let muted = false;


        if (num < 1) {

            num =
                prev + num;

            mm =
                m - 1;

            muted = true;

        }

        else if (num > days) {

            num -= days;

            mm =
                m + 1;

            muted = true;
        }


        let d =
            new Date(y, mm, num);


        let iso =
            `${d.getFullYear()}-${String(
                d.getMonth() + 1
            ).padStart(2, "0")}-${String(
                d.getDate()
            ).padStart(2, "0")}`;


        let ev =
            data.events.filter(
                e => e.date === iso
            );


        cells += `

            <div
                class="day ${
                    muted ? "muted " : ""
                }${
                    iso === todayISO()
                        ? "today "
                        : ""
                }${
                    ev.length
                        ? "has-event"
                        : ""
                }"
                onclick="openEvent('${iso}')"
            >

                <span class="day-num">
                    ${num}
                </span>

                ${
                    ev
                        .slice(0, 2)
                        .map(e => `

                            <span class="event-dot">
                                ${esc(e.title)}
                            </span>

                        `)
                        .join("")
                }

            </div>
        `;
    }


    document.getElementById(
        "calendar"
    ).innerHTML = `

        <div class="calendar-wrap">

            <div class="card">

                <div class="calendar-head">

                    <button
                        class="ghost"
                        onclick="changeMonth(-1)"
                    >
                        ‹
                    </button>

                    <h2>
                        ${
                            current.toLocaleDateString(
                                "pt-BR",
                                {
                                    month: "long",
                                    year: "numeric"
                                }
                            )
                        }
                    </h2>

                    <button
                        class="ghost"
                        onclick="changeMonth(1)"
                    >
                        ›
                    </button>

                </div>


                <div class="cal-grid">

                    ${
                        [
                            "Seg",
                            "Ter",
                            "Qua",
                            "Qui",
                            "Sex",
                            "Sáb",
                            "Dom"
                        ]
                        .map(x => `
                            <div class="weekday">
                                ${x}
                            </div>
                        `)
                        .join("")
                    }

                    ${cells}

                </div>

            </div>


            <div class="card">

                <div class="section-head">

                    <h3>
                        Datas cadastradas
                    </h3>

                    <button
                        class="primary"
                        onclick="openEvent()"
                    >
                        ＋
                    </button>

                </div>


                ${
                    data.events.length

                    ? `

                        <div class="list">

                            ${
                                [...data.events]

                                    .sort(
                                        (a,b) =>
                                            a.date.localeCompare(
                                                b.date
                                            )
                                    )

                                    .map(e => `

                                        <div class="list-item">

                                            <div>

                                                <b>
                                                    ${esc(e.title)}
                                                </b>

                                                <div class="meta">
                                                    ${esc(
                                                        e.type ||
                                                        "Evento"
                                                    )}
                                                    •
                                                    ${shortDate(e.date)}
                                                </div>

                                            </div>

                                            <button
                                                class="danger-link"
                                                onclick="deleteEvent('${e.id}')"
                                            >
                                                Excluir
                                            </button>

                                        </div>

                                    `)
                                    .join("")
                            }

                        </div>

                    `

                    : `

                        <div class="empty">
                            Nenhuma data.
                        </div>

                    `
                }

            </div>

        </div>
    `;
}


/* =========================================================
   NOTAS
========================================================= */

function renderNotes() {

    document.getElementById(
        "notes"
    ).innerHTML = `

        <div class="toolbar">

            <input
                id="noteSearch"
                class="input"
                placeholder="Pesquisar notas..."
                oninput="renderNoteCards()"
            >

            <button
                class="primary"
                onclick="openNote()"
            >
                ＋ Nova nota
            </button>

        </div>


        <div
            id="noteCards"
            class="cards"
        ></div>
    `;

    renderNoteCards();
}


function renderNoteCards() {

    let q =
        (
            document.getElementById(
                "noteSearch"
            )?.value || ""
        ).toLowerCase();


    let arr =
        data.notes

            .filter(
                n =>
                    (
                        n.title +
                        " " +
                        n.text +
                        " " +
                        n.category
                    )
                    .toLowerCase()
                    .includes(q)
            )

            .reverse();


    let el =
        document.getElementById(
            "noteCards"
        );


    if (!el) {
        return;
    }


    el.innerHTML =
        arr.length

        ? arr.map(n => `

            <div class="card note-card">

                <span class="tag">
                    ${esc(n.category)}
                </span>

                <h3>
                    ${esc(n.title)}
                </h3>

                <p>
                    ${esc(n.text)}
                </p>

                <div
                    style="
                        margin-top:14px;
                        display:flex;
                        justify-content:space-between;
                        align-items:center
                    "
                >

                    <span class="meta">
                        ${shortDate(n.created)}
                    </span>

                    <button
                        class="danger-link"
                        onclick="deleteNote('${n.id}')"
                    >
                        Excluir
                    </button>

                </div>

            </div>

        `).join("")

        : `

            <div class="empty">
                Nenhuma nota encontrada.
            </div>

        `;
}


/* =========================================================
   PRESENTES
========================================================= */

function renderGifts() {

    document.getElementById(
        "gifts"
    ).innerHTML = `

        <div class="toolbar">

            <button
                class="primary"
                onclick="openGift()"
            >
                ＋ Nova ideia
            </button>

        </div>


        <div class="cards">

            ${
                data.gifts.length

                ? data.gifts.map(g => `

                    <div class="card note-card">

                        <span class="status">
                            ${esc(g.status)}
                        </span>

                        <h3>
                            ${esc(g.title)}
                        </h3>

                        <p>
                            ${esc(g.details || "")}
                        </p>

                        ${
                            g.price

                            ? `

                                <div class="gift-price">
                                    R$ ${esc(g.price)}
                                </div>

                            `

                            : ""
                        }


                        <div
                            class="section-head"
                            style="margin-top:15px"
                        >

                            <select
                                class="select"
                                style="width:auto"
                                onchange="setGiftStatus(
                                    '${g.id}',
                                    this.value
                                )"
                            >

                                ${
                                    [
                                        "Ideia",
                                        "Planejando",
                                        "Comprado",
                                        "Entregue"
                                    ]
                                    .map(s => `

                                        <option
                                            ${
                                                g.status === s
                                                    ? "selected"
                                                    : ""
                                            }
                                        >
                                            ${s}
                                        </option>

                                    `)
                                    .join("")
                                }

                            </select>


                            <button
                                class="danger-link"
                                onclick="deleteGift('${g.id}')"
                            >
                                Excluir
                            </button>

                        </div>

                    </div>

                `).join("")

                : `

                    <div class="empty">

                        Guarde aqui aquelas coisas
                        que ela comentou que gostaria
                        de ganhar.

                    </div>

                `
            }

        </div>
    `;
}


/* =========================================================
   MOMENTOS
========================================================= */

function renderMoments() {

    document.getElementById(
        "moments"
    ).innerHTML = `

        <div class="toolbar">

            <button
                class="primary"
                onclick="openMoment()"
            >
                ＋ Novo momento
            </button>

        </div>


        ${
            data.moments.length

            ? `

                <div class="list">

                    ${
                        [...data.moments]

                            .sort(
                                (a,b) =>
                                    b.date.localeCompare(
                                        a.date
                                    )
                            )

                            .map(m => {

                                let d =
                                    new Date(
                                        m.date +
                                        "T12:00:00"
                                    );


                                return `

                                    <div class="card moment">

                                        <div class="moment-date">

                                            <b>
                                                ${d.getDate()}
                                            </b>

                                            <span>
                                                ${
                                                    d.toLocaleDateString(
                                                        "pt-BR",
                                                        {
                                                            month: "short"
                                                        }
                                                    ).replace(
                                                        ".",
                                                        ""
                                                    )
                                                }
                                            </span>

                                        </div>


                                        <div>

                                            <span class="tag">
                                                ${esc(m.tag)}
                                            </span>

                                            <h3
                                                style="margin:8px 0"
                                            >
                                                ${esc(m.title)}
                                            </h3>

                                            <p
                                                style="
                                                    margin:0;
                                                    color:#615864;
                                                    white-space:pre-wrap
                                                "
                                            >
                                                ${esc(m.text)}
                                            </p>


                                            <button
                                                class="danger-link"
                                                style="margin-top:12px"
                                                onclick="deleteMoment('${m.id}')"
                                            >
                                                Excluir
                                            </button>

                                        </div>

                                    </div>

                                `;
                            })
                            .join("")
                    }

                </div>

            `

            : `

                <div class="empty">
                    Registre pequenos momentos
                    para lembrar deles depois. ♡
                </div>

            `
        }
    `;
}


/* =========================================================
   NAVEGAR
========================================================= */

function go(p) {

    currentPage = p;

    document
        .querySelector(
            `[data-page="${p}"]`
        )
        .click();
}


/* =========================================================
   MUDAR MÊS
========================================================= */

function changeMonth(n) {

    current.setMonth(
        current.getMonth() + n
    );

    renderCalendar();
}


/* =========================================================
   MODAL
========================================================= */

function modal(title, body, saveFn) {

    let d =
        document.getElementById(
            "modal"
        );


    document.getElementById(
        "modalTitle"
    ).textContent = title;


    document.getElementById(
        "modalBody"
    ).innerHTML = body;


    document.getElementById(
        "modalSave"
    ).onclick = async e => {

        e.preventDefault();

        await saveFn();

        d.close();
    };


    d.showModal();
}


/* =========================================================
   NOVA DATA
========================================================= */

function openEvent(date = "") {

    modal(
        "Nova data",

        `

        <div class="field">

            <label>
                Título
            </label>

            <input
                id="fTitle"
                class="input"
                placeholder="Ex.: aniversário dela"
                required
            >

        </div>


        <div class="field">

            <label>
                Data
            </label>

            <input
                id="fDate"
                type="date"
                class="input"
                value="${date || todayISO()}"
                required
            >

        </div>


        <div class="field">

            <label>
                Categoria
            </label>

            <select
                id="fType"
                class="select"
            >

                <option>
                    ❤️ Data especial
                </option>

                <option>
                    🎁 Presente
                </option>

                <option>
                    📅 Compromisso
                </option>

                <option>
                    💌 Surpresa
                </option>

            </select>

        </div>

        `,

        async () => {

            data.events.push({

                id: id(),

                title:
                    val("fTitle"),

                date:
                    val("fDate"),

                type:
                    val("fType")

            });

            await save();

            toast(
                "Data adicionada ♡"
            );
        }
    );
}


/* =========================================================
   NOVA NOTA
========================================================= */

function openNote() {

    modal(
        "Nova nota",

        `

        <div class="field">

            <label>
                Título
            </label>

            <input
                id="fTitle"
                class="input"
                placeholder="Ex.: coisas que ela gosta"
            >

        </div>


        <div class="field">

            <label>
                Categoria
            </label>

            <select
                id="fCat"
                class="select"
            >

                <option>
                    💕 Momentos
                </option>

                <option>
                    🎁 Presentes
                </option>

                <option>
                    🍔 Comidas
                </option>

                <option>
                    🎬 Filmes/Séries
                </option>

                <option>
                    ✈️ Lugares
                </option>

                <option>
                    💬 Coisas que ela falou
                </option>

                <option>
                    ⭐ Favoritos
                </option>

            </select>

        </div>


        <div class="field">

            <label>
                Nota
            </label>

            <textarea
                id="fText"
                class="textarea"
                rows="6"
                placeholder="Escreva aqui..."
            ></textarea>

        </div>

        `,

        async () => {

            data.notes.push({

                id: id(),

                title:
                    val("fTitle"),

                category:
                    val("fCat"),

                text:
                    val("fText"),

                created:
                    todayISO()

            });

            await save();

            toast(
                "Nota salva ♡"
            );
        }
    );
}


/* =========================================================
   NOVO PRESENTE
========================================================= */

function openGift() {

    modal(
        "Nova ideia de presente",

        `

        <div class="field">

            <label>
                Presente
            </label>

            <input
                id="fTitle"
                class="input"
                placeholder="Ex.: perfume"
            >

        </div>


        <div class="field">

            <label>
                Preço aproximado
            </label>

            <input
                id="fPrice"
                class="input"
                placeholder="250,00"
            >

        </div>


        <div class="field">

            <label>
                Detalhes
            </label>

            <textarea
                id="fText"
                class="textarea"
                rows="4"
                placeholder="Marca, tamanho, link, onde comprar..."
            ></textarea>

        </div>

        `,

        async () => {

            data.gifts.push({

                id: id(),

                title:
                    val("fTitle"),

                price:
                    val("fPrice"),

                details:
                    val("fText"),

                status:
                    "Ideia"

            });

            await save();

            toast(
                "Ideia salva 🎁"
            );
        }
    );
}


/* =========================================================
   NOVO MOMENTO
========================================================= */

function openMoment() {

    modal(
        "Novo momento",

        `

        <div class="field">

            <label>
                Título
            </label>

            <input
                id="fTitle"
                class="input"
                placeholder="Ex.: nosso passeio"
            >

        </div>


        <div class="field">

            <label>
                Data
            </label>

            <input
                id="fDate"
                type="date"
                class="input"
                value="${todayISO()}"
            >

        </div>


        <div class="field">

            <label>
                Categoria
            </label>

            <input
                id="fCat"
                class="input"
                value="♡ Momento"
            >

        </div>


        <div class="field">

            <label>
                O que aconteceu?
            </label>

            <textarea
                id="fText"
                class="textarea"
                rows="5"
                placeholder="Escreva a lembrança..."
            ></textarea>

        </div>

        `,

        async () => {

            data.moments.push({

                id: id(),

                title:
                    val("fTitle"),

                date:
                    val("fDate"),

                tag:
                    val("fCat"),

                text:
                    val("fText")

            });

            await save();

            toast(
                "Momento guardado ♡"
            );
        }
    );
}


/* =========================================================
   EXCLUIR
========================================================= */

async function del(arr, idv) {

    let i =
        data[arr].findIndex(
            x => x.id === idv
        );


    if (i >= 0) {

        data[arr].splice(
            i,
            1
        );

        await save();

        toast(
            "Item excluído"
        );
    }
}

function deleteEvent(i) {
    del("events", i);
}

function deleteNote(i) {
    del("notes", i);
}

function deleteGift(i) {
    del("gifts", i);
}

function deleteMoment(i) {
    del("moments", i);
}


/* =========================================================
   STATUS DO PRESENTE
========================================================= */

async function setGiftStatus(i, s) {

    let g =
        data.gifts.find(
            x => x.id === i
        );


    if (g) {

        g.status = s;

        await save();

        toast(
            "Status atualizado"
        );
    }
}


/* =========================================================
   BOTÕES PRINCIPAIS
========================================================= */

document.getElementById(
    "quickAdd"
).onclick = () => {

    if (currentPage === "calendar") {

        openEvent();

    } else if (currentPage === "notes") {

        openNote();

    } else if (currentPage === "gifts") {

        openGift();

    } else if (currentPage === "moments") {

        openMoment();

    } else {

        openEvent();
    }
};


document.getElementById(
    "lockButton"
).onclick = lock;


/* =========================================================
   INICIAR
========================================================= */

setupOrLogin();