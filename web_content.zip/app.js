// =====================================================
// STUDYFLOW APP
// =====================================================


// =====================================================
// 1. LOCAL STORAGE DATABASE
// =====================================================

const studyData = {

    profile: {},

    academic: {
        year: "",
        semester: ""
    },

    settings: {
        notifications: true,
        reminders: true,
        reminderTime: "18:00",
        theme: "light",
        language: "English",
        textSize: "medium"
    },

    notes: {},

    assignments: [],

    exams: [],

    grades: [],

    attendance: {},

    resources: [],

    timetable: []
};


// Load saved information
function loadStudyData() {

    const savedData =
        localStorage.getItem("StudyFlowData");

    if (!savedData) {
        return;
    }

    try {

        const parsedData =
            JSON.parse(savedData);

        Object.assign(
            studyData,
            parsedData
        );

        studyData.profile =
            parsedData.profile || {};

        studyData.academic =
            parsedData.academic || {
                year: "",
                semester: ""
            };

        studyData.settings =
            parsedData.settings || {
                notifications: true,
                reminders: true,
                reminderTime: "18:00",
                theme: "light",
                language: "English",
                textSize: "medium"
            };

        studyData.notes =
            parsedData.notes || {};

        studyData.assignments =
            parsedData.assignments || [];

        studyData.exams =
            parsedData.exams || [];

        studyData.grades =
            parsedData.grades || [];

        studyData.attendance =
            parsedData.attendance || {};

        studyData.resources =
            parsedData.resources || [];

        studyData.timetable =
            parsedData.timetable || [];

    } catch (error) {

        console.log(
            "Could not load StudyFlow data:",
            error
        );

    }
}


// Save information
function saveStudyData() {

    localStorage.setItem(
        "StudyFlowData",
        JSON.stringify(studyData)
    );

}


// =====================================================
// 2. SCREEN NAVIGATION
// =====================================================

function showScreen(screenId) {

    const screens =
        document.querySelectorAll(".screen");

    screens.forEach(function(screen) {

        screen.classList.remove("active");

    });


    const selectedScreen =
        document.getElementById(screenId);


    if (selectedScreen) {

        selectedScreen.classList.add("active");

    }


    window.scrollTo(0, 0);

}


// =====================================================
// 3. BIT PROGRAMME
// =====================================================

const programme = {

    "Year 1": {

        "Semester 1": [

            ["BIT 100", "Fundamentals of Programming"],

            ["MATH 112", "Basic Mathematics"],

            ["ZOOL 143", "Biology of HIV/AIDS and Society"],

            ["COMS 101", "Communication Skills"],

            ["PHIL 104", "Philosophy and Society"],

            ["COMP 107", "Foundations of Computing"]

        ],


        "Semester 2": [

            ["BIT 103", "Structured Programming Using C"],

            ["BIT 112", "Hardware Support & Maintenance"],

            ["MATH 141", "Introductory Statistics"],

            ["BIT 111", "Computer Organization & Architecture"],

            ["COMP 102", "Discrete Mathematics for Computing"],

            ["MATH 111", "Calculus 1"]

        ]

    },


    "Year 2": {

        "Semester 1": [

            ["BIT 201", "Event-Driven Programming (VB)"],

            ["BIT 210", "System Analysis & Design"],

            ["BIT 211", "Management Information Systems"],

            ["BIT 213", "Software Engineering"],

            ["MATH 240", "Probability and Statistics I"],

            ["BIT 202", "Web Programming I"],

            ["BIT 270", "Information Technology Administration"]

        ],


        "Semester 2": [

            ["BIT 203", "Data Structures and Algorithms"],

            ["BIT 204", "Introduction to Database Management Systems"],

            ["BIT 216", "Data Communications & Networks"],

            ["BIT 205", "Object Oriented Programming Using Java I"],

            ["BIT 215", "Operating Systems"],

            ["BIT 229", "Information Technology User Support"]

        ]

    },


    "Year 3": {

        "Semester 1": [

            ["BIT 310", "Network Design & Management"],

            ["BIT 301", "Object Oriented Design"],

            ["BIT 313", "Computer Security"],

            ["BIT 312", "Advanced Database Systems"],

            ["BIT 316", "Human Computer Interface"],

            ["BIT 342", "Mobile Application Development"],

            ["BIT 335", "Object Oriented Programming Using Java II"]

        ],


        "Semester 2": [

            ["BIT 300", "Web Programming II"],

            ["BIT 302", "Enterprise Application Development"],

            ["BIT 308", "Artificial Intelligence"],

            ["BIT 314", "Machine Learning Algorithms"],

            ["BIT 330", "Multimedia Systems"],

            ["BIT 332", "Programming in Python"]

        ]

    },


    "Year 4": {

        "Semester 1": [

            ["BIT 499", "Industrial Attachment"],

            ["BIT 425", "Interactive Design & Software Project Management"],

            ["BIT 413", "Data Mining & Warehousing"],

            ["BIT 414", "Emerging Technologies in Information Technology"],

            ["BIT 400", "Number Theory & Cryptography"],

            ["BIT 447", "IoT & Big Data Programming"],

            ["BIT 430", "Ethics & Professional Practices"]

        ],


        "Semester 2": [

            ["BIT 402", "Systems Project"],

            ["BIT 410", "Information Systems Audit"],

            ["BIT 436", "Digital Image Processing"],

            ["BIT 440", "Distributed Systems"],

            ["BIT 445", "IT Integration and Interoperability"],

            ["BIT 460", "Innovation & Technology Transfer"]

        ]

    }

};


// =====================================================
// 4. COUNT ALL UNITS
// =====================================================

function getUnitCount() {

    let count = 0;


    for (const year in programme) {

        for (const semester in programme[year]) {

            count +=
                programme[year][semester].length;

        }

    }


    return count;

}


// =====================================================
// 5. ACADEMICS
// =====================================================

function renderAcademics() {

    const container =
        document.getElementById("academicContent");


    if (!container) {
        return;
    }


    container.innerHTML = "";


    for (const year in programme) {

        const yearCard =
            document.createElement("div");

        yearCard.className =
            "section-card";


        const yearTitle =
            document.createElement("h2");

        yearTitle.textContent =
            "🎓 " + year;


        yearCard.appendChild(
            yearTitle
        );


        for (
            const semester in programme[year]
        ) {

            const semesterTitle =
                document.createElement("h3");

            semesterTitle.textContent =
                "📚 " + semester;

            semesterTitle.style.marginTop =
                "20px";

            semesterTitle.style.marginBottom =
                "10px";


            yearCard.appendChild(
                semesterTitle
            );


            programme[year][semester]
                .forEach(function(unit) {

                    const code = unit[0];

                    const name = unit[1];


                    const button =
                        document.createElement("button");


                    button.className =
                        "academic-unit";


                    button.innerHTML = `
                        <strong>${code}</strong>
                        <span>${name}</span>
                        <small>Tap to open →</small>
                    `;


                    button.onclick =
                        function() {

                            openUnit(
                                code,
                                name,
                                year,
                                semester
                            );

                        };


                    yearCard.appendChild(
                        button
                    );

                });

        }


        container.appendChild(
            yearCard
        );

    }

}


// =====================================================
// 6. UNIT DETAILS
// =====================================================

let currentUnit = null;


function openUnit(
    code,
    name,
    year,
    semester
) {

    currentUnit = {

        code: code,

        name: name,

        year: year,

        semester: semester

    };


    const header =
        document.getElementById(
            "unitHeader"
        );


    header.innerHTML = `

        <div class="section-card">

            <p>
                ${year} • ${semester}
            </p>

            <h2>
                ${code}
            </h2>

            <p>
                ${name}
            </p>

        </div>

    `;


    showScreen(
        "unitDetails"
    );


    openUnitSection(
        "overview"
    );

}


// =====================================================
// 7. UNIT SECTIONS
// =====================================================

function openUnitSection(section) {

    const container =
        document.getElementById(
            "unitSectionContent"
        );


    if (!container || !currentUnit) {
        return;
    }


    const code =
        currentUnit.code;


    if (section === "overview") {

        container.innerHTML = `

            <h3>📋 Overview</h3>

            <p>
                <strong>
                    ${currentUnit.code}
                </strong>
            </p>

            <p>
                ${currentUnit.name}
            </p>

            <p>
                ${currentUnit.year}
                •
                ${currentUnit.semester}
            </p>

        `;

    }


    else if (section === "notes") {

        const savedNotes =
            studyData.notes[code] || "";


        container.innerHTML = `

            <h3>📖 Notes</h3>

            <textarea
                id="unitNotes"
                rows="8"
                placeholder="Write your notes here..."
            >${savedNotes}</textarea>

            <button
                type="button"
                onclick="saveUnitNotes()">

                💾 Save Notes

            </button>

        `;

    }


    else if (section === "assignments") {

        const assignments =
            studyData.assignments.filter(
                item => item.unitCode === code
            );


        container.innerHTML = `

            <h3>📝 Assignments</h3>

            <button
                type="button"
                onclick="addAssignment('${code}')">

                ➕ Add Assignment

            </button>

            <div>

                ${
                    assignments.length
                    ?
                    assignments.map(
                        item =>
                        `<p>📝 ${item.title}</p>`
                    ).join("")
                    :
                    "<p>No assignments yet.</p>"
                }

            </div>

        `;

    }


    else if (section === "cats") {

        renderUnitExams(
            container,
            code,
            "CAT"
        );

    }


    else if (section === "exams") {

        renderUnitExams(
            container,
            code,
            "Main Exam"
        );

    }


    else if (section === "grades") {

        const grades =
            studyData.grades.filter(
                item => item.unitCode === code
            );


        container.innerHTML = `

            <h3>📊 Grades</h3>

            <button
                type="button"
                onclick="addGrade('${code}')">

                ➕ Add Grade

            </button>

            ${
                grades.length
                ?
                grades.map(
                    item =>
                    `<p>${item.type}: ${item.grade}</p>`
                ).join("")
                :
                "<p>No grades recorded.</p>"
            }

        `;

    }


    else if (section === "attendance") {

        const attendance =
            studyData.attendance[code]
            || {
                attended: 0,
                total: 0
            };


        container.innerHTML = `

            <h3>✅ Attendance</h3>

            <p>
                Classes attended:
                ${attendance.attended}
                /
                ${attendance.total}
            </p>

            <button
                type="button"
                onclick="recordAttendance('${code}')">

                ➕ Record Attendance

            </button>

        `;

    }


    else if (section === "resources") {

        const resources =
            studyData.resources.filter(
                item => item.unitCode === code
            );


        container.innerHTML = `

            <h3>📁 Resources</h3>

            <button
                type="button"
                onclick="addResource('${code}')">

                ➕ Add Resource

            </button>

            ${
                resources.length
                ?
                resources.map(
                    item =>
                    `<p>🔗 ${item.name}</p>`
                ).join("")
                :
                "<p>No resources yet.</p>"
            }

        `;

    }

}


// =====================================================
// 8. NOTES
// =====================================================

function saveUnitNotes() {

    if (!currentUnit) {
        return;
    }


    const notes =
        document.getElementById(
            "unitNotes"
        ).value;


    studyData.notes[
        currentUnit.code
    ] = notes;


    saveStudyData();


    alert(
        "Notes saved successfully! ✅"
    );

}


// =====================================================
// 9. ASSIGNMENTS
// =====================================================

function addAssignment(unitCode) {

    const title =
        prompt(
            "Enter assignment title:"
        );


    if (!title) {
        return;
    }


    studyData.assignments.push({

        id: Date.now(),

        title: title,

        unitCode: unitCode,

        completed: false,

        createdAt:
            new Date().toISOString()

    });


    saveStudyData();

    renderAssignments();

    alert(
        "Assignment added! 📝"
    );

}


function renderAssignments(filter) {

    const container =
        document.getElementById(
            "assignmentList"
        );


    if (!container) {
        return;
    }


    let assignments =
        [...studyData.assignments];


    if (filter === "completed") {

        assignments =
            assignments.filter(
                item => item.completed
            );

    }


    else if (filter === "pending") {

        assignments =
            assignments.filter(
                item => !item.completed
            );

    }


    container.innerHTML =
        assignments.length
        ?
        assignments.map(
            item => `

                <div class="section-card">

                    <h3>
                        📝 ${item.title}
                    </h3>

                    <p>
                        Unit:
                        ${item.unitCode}
                    </p>

                    <button
                        type="button"
                        onclick="completeAssignment(${item.id})">

                        ${
                            item.completed
                            ?
                            "↩️ Mark Pending"
                            :
                            "✅ Complete"
                        }

                    </button>

                </div>

            `
        ).join("")
        :
        `

            <div class="section-card">

                <p>
                    No assignments found.
                </p>

            </div>

        `;


    updateDashboard();

}


function completeAssignment(id) {

    const assignment =
        studyData.assignments.find(
            item => item.id === id
        );


    if (!assignment) {
        return;
    }


    assignment.completed =
        !assignment.completed;


    saveStudyData();

    renderAssignments();

}


// =====================================================
// 10. EXAMS
// =====================================================

function addExam(unitCode, type) {

    const examType =
        type ||
        prompt(
            "Enter exam type (CAT or Main Exam):"
        );


    if (!examType) {
        return;
    }


    const title =
        prompt(
            "Enter exam title:"
        );


    if (!title) {
        return;
    }


    const date =
        prompt(
            "Enter exam date (YYYY-MM-DD):"
        );


    studyData.exams.push({

        id: Date.now(),

        title: title,

        type: examType,

        unitCode: unitCode,

        date: date || ""

    });


    saveStudyData();

    renderExams();

    alert(
        "Exam saved! 🎓"
    );

}


function renderExams(filter) {

    const container =
        document.getElementById(
            "examList"
        );


    if (!container) {
        return;
    }


    let exams =
        [...studyData.exams];


    if (filter === "cat") {

        exams =
            exams.filter(
                item =>
                    item.type.toLowerCase()
                    .includes("cat")
            );

    }


    else if (filter === "main") {

        exams =
            exams.filter(
                item =>
                    item.type.toLowerCase()
                    .includes("main")
            );

    }


    container.innerHTML =
        exams.length
        ?
        exams.map(
            item => `

                <div class="section-card">

                    <h3>
                        🎓 ${item.title}
                    </h3>

                    <p>
                        ${item.unitCode}
                    </p>

                    <p>
                        ${item.type}
                    </p>

                    <p>
                        📅 ${item.date || "No date"}
                    </p>

                </div>

            `
        ).join("")
        :
        `

            <div class="section-card">

                <p>
                    No exams found.
                </p>

            </div>

        `;


    updateDashboard();

}


function renderUnitExams(
    container,
    unitCode,
    type
) {

    const exams =
        studyData.exams.filter(
            item =>
                item.unitCode === unitCode &&
                item.type === type
        );


    container.innerHTML = `

        <h3>
            🎓 ${type}
        </h3>

        <button
            type="button"
            onclick="addExam('${unitCode}', '${type}')">

            ➕ Add ${type}

        </button>

        ${
            exams.length
            ?
            exams.map(
                item =>
                `<p>
                    🎓 ${item.title}
                    — ${item.date || "No date"}
                </p>`
            ).join("")
            :
            "<p>No exams recorded.</p>"
        }

    `;

}


// =====================================================
// 11. GRADES
// =====================================================

function addGrade(unitCode) {

    const grade =
        prompt(
            "Enter grade:"
        );


    if (!grade) {
        return;
    }


    const type =
        prompt(
            "Enter grade type (CAT/Exam):"
        );


    studyData.grades.push({

        id: Date.now(),

        unitCode: unitCode,

        grade: grade,

        type: type || "Grade"

    });


    saveStudyData();


    openUnitSection(
        "grades"
    );


    alert(
        "Grade saved! 📊"
    );

}


// =====================================================
// 12. ATTENDANCE
// =====================================================

function recordAttendance(unitCode) {

    if (!studyData.attendance[unitCode]) {

        studyData.attendance[unitCode] = {

            attended: 0,

            total: 0

        };

    }


    const attended =
        prompt(
            "Number of classes attended:"
        );


    const total =
        prompt(
            "Total classes:"
        );


    if (
        attended === null ||
        total === null
    ) {
        return;
    }


    studyData.attendance[unitCode] = {

        attended:
            Number(attended) || 0,

        total:
            Number(total) || 0

    };


    saveStudyData();


    openUnitSection(
        "attendance"
    );


    alert(
        "Attendance saved! ✅"
    );

}


// =====================================================
// 13. RESOURCES
// =====================================================

function addResource(unitCode) {

    const name =
        prompt(
            "Enter resource name:"
        );


    if (!name) {
        return;
    }


    const link =
        prompt(
            "Enter resource link (optional):"
        );


    studyData.resources.push({

        id: Date.now(),

        unitCode: unitCode,

        name: name,

        link: link || ""

    });


    saveStudyData();


    openUnitSection(
        "resources"
    );


    alert(
        "Resource added! 📁"
    );

}


// =====================================================
// 14. PROFILE
// =====================================================

function openProfile() {

    const profile =
        studyData.profile || {};


    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                👤 Profile
            </h2>

            <p>
                Enter your student information.
            </p>


            <label>
                Full Name
            </label>

            <input
                type="text"
                id="profileName"
                value="${escapeHTML(profile.name || "")}"
                placeholder="Enter your name"
            >


            <label>
                Student ID
            </label>

            <input
                type="text"
                id="profileStudentId"
                value="${escapeHTML(profile.studentId || "")}"
                placeholder="Enter student ID"
            >


            <label>
                University / College
            </label>

            <input
                type="text"
                id="profileUniversity"
                value="${escapeHTML(profile.university || "")}"
                placeholder="Enter university"
            >


            <label>
                Programme
            </label>

            <input
                type="text"
                id="profileProgramme"
                value="${escapeHTML(profile.programme || "")}"
                placeholder="Bachelor of Information Technology"
            >


            <button
                type="button"
                onclick="saveProfile()">

                💾 Save Profile

            </button>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


function saveProfile() {

    studyData.profile = {

        name:
            document
            .getElementById("profileName")
            .value.trim(),

        studentId:
            document
            .getElementById("profileStudentId")
            .value.trim(),

        university:
            document
            .getElementById("profileUniversity")
            .value.trim(),

        programme:
            document
            .getElementById("profileProgramme")
            .value.trim()

    };


    saveStudyData();


    updateProfileDisplay();


    alert(
        "Profile saved successfully! ✅"
    );

}


function updateProfileDisplay() {

    const profile =
        studyData.profile || {};


    const welcome =
        document.getElementById(
            "welcomeMessage"
        );


    if (welcome) {

        welcome.textContent =
            profile.name
            ?
            "Welcome back, " +
            profile.name +
            "! 👋"
            :
            "Your academic life, organized in one place.";

    }


    const academicInfo =
        document.getElementById(
            "dashboardAcademicInfo"
        );


    if (academicInfo) {

        const parts = [];

        if (profile.programme) {
            parts.push(profile.programme);
        }

        if (profile.university) {
            parts.push(profile.university);
        }

        if (studyData.academic.year) {
            parts.push(studyData.academic.year);
        }

        if (studyData.academic.semester) {
            parts.push(studyData.academic.semester);
        }


        academicInfo.textContent =
            parts.length
            ?
            parts.join(" • ")
            :
            "Academic information has not been configured yet.";

    }

}


// =====================================================
// 15. ACADEMIC INFORMATION
// =====================================================

function openAcademicSettings() {

    const academic =
        studyData.academic || {};


    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🎓 Academic Information
            </h2>


            <label>
                University / College
            </label>

            <input
                type="text"
                id="academicUniversity"
                value="${escapeHTML(studyData.profile.university || "")}"
                placeholder="Enter university"
            >


            <label>
                Programme
            </label>

            <input
                type="text"
                id="academicProgramme"
                value="${escapeHTML(studyData.profile.programme || "")}"
                placeholder="Enter programme"
            >


            <label>
                Current Year
            </label>

            <select id="academicYear">

                <option value="">
                    Select year
                </option>

                <option value="Year 1">
                    Year 1
                </option>

                <option value="Year 2">
                    Year 2
                </option>

                <option value="Year 3">
                    Year 3
                </option>

                <option value="Year 4">
                    Year 4
                </option>

            </select>


            <label>
                Current Semester
            </label>

            <select id="academicSemester">

                <option value="">
                    Select semester
                </option>

                <option value="Semester 1">
                    Semester 1
                </option>

                <option value="Semester 2">
                    Semester 2
                </option>

            </select>


            <button
                type="button"
                onclick="saveAcademicSettings()">

                💾 Save Academic Information

            </button>

        </div>

    `;


    document.getElementById(
        "academicYear"
    ).value =
        academic.year || "";


    document.getElementById(
        "academicSemester"
    ).value =
        academic.semester || "";


    showScreen(
        "settingsPage"
    );

}


function saveAcademicSettings() {

    studyData.profile.university =
        document
        .getElementById(
            "academicUniversity"
        )
        .value.trim();


    studyData.profile.programme =
        document
        .getElementById(
            "academicProgramme"
        )
        .value.trim();


    studyData.academic.year =
        document
        .getElementById(
            "academicYear"
        )
        .value;


    studyData.academic.semester =
        document
        .getElementById(
            "academicSemester"
        )
        .value;


    saveStudyData();


    updateProfileDisplay();


    alert(
        "Academic information saved! 🎓"
    );

}


// =====================================================
// 16. SEMESTER SETTINGS
// =====================================================

function openSemesterSettings() {

    openAcademicSettings();

}


// =====================================================
// 17. NOTIFICATIONS
// =====================================================

function openNotificationSettings() {

    const settings =
        studyData.settings;


    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🔔 Notifications
            </h2>


            <label>

                <input
                    type="checkbox"
                    id="notificationsEnabled"
                    ${
                        settings.notifications
                        ? "checked"
                        : ""
                    }
                >

                Enable notifications

            </label>


            <br>


            <label>

                <input
                    type="checkbox"
                    id="remindersEnabled"
                    ${
                        settings.reminders
                        ? "checked"
                        : ""
                    }
                >

                Enable study reminders

            </label>


            <button
                type="button"
                onclick="saveNotificationSettings()">

                💾 Save Notification Settings

            </button>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


function saveNotificationSettings() {

    studyData.settings.notifications =
        document.getElementById(
            "notificationsEnabled"
        ).checked;


    studyData.settings.reminders =
        document.getElementById(
            "remindersEnabled"
        ).checked;


    saveStudyData();


    alert(
        "Notification settings saved! 🔔"
    );

}


// =====================================================
// 18. REMINDERS
// =====================================================

function openReminderSettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                ⏰ Reminder Settings
            </h2>


            <label>
                Default reminder time
            </label>

            <input
                type="time"
                id="reminderTime"
                value="${studyData.settings.reminderTime}"
            >


            <button
                type="button"
                onclick="saveReminderSettings()">

                💾 Save Reminder Time

            </button>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


function saveReminderSettings() {

    studyData.settings.reminderTime =
        document
        .getElementById(
            "reminderTime"
        )
        .value;


    saveStudyData();


    alert(
        "Reminder time saved! ⏰"
    );

}


// =====================================================
// 19. APPEARANCE
// =====================================================

function openAppearanceSettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🎨 Appearance
            </h2>


            <label>
                Theme
            </label>

            <select id="themeSelect">

                <option value="light">
                    Light
                </option>

                <option value="dark">
                    Dark
                </option>

            </select>


            <button
                type="button"
                onclick="saveAppearanceSettings()">

                💾 Apply Theme

            </button>

        </div>

    `;


    document.getElementById(
        "themeSelect"
    ).value =
        studyData.settings.theme;


    showScreen(
        "settingsPage"
    );

}


function saveAppearanceSettings() {

    const theme =
        document
        .getElementById(
            "themeSelect"
        )
        .value;


    studyData.settings.theme =
        theme;


    applyTheme();


    saveStudyData();


    alert(
        "Appearance saved! 🎨"
    );

}


function applyTheme() {

    if (
        studyData.settings.theme ===
        "dark"
    ) {

        document.body.classList.add(
            "dark-mode"
        );

    } else {

        document.body.classList.remove(
            "dark-mode"
        );

    }

}


// =====================================================
// 20. DISPLAY / TEXT SIZE
// =====================================================

function openDisplaySettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🔤 Display & Text
            </h2>


            <label>
                Text size
            </label>

            <select id="textSizeSelect">

                <option value="small">
                    Small
                </option>

                <option value="medium">
                    Medium
                </option>

                <option value="large">
                    Large
                </option>

            </select>


            <button
                type="button"
                onclick="saveDisplaySettings()">

                💾 Save Display Settings

            </button>

        </div>

    `;


    document.getElementById(
        "textSizeSelect"
    ).value =
        studyData.settings.textSize;


    showScreen(
        "settingsPage"
    );

}


function saveDisplaySettings() {

    studyData.settings.textSize =
        document
        .getElementById(
            "textSizeSelect"
        )
        .value;


    applyTextSize();


    saveStudyData();


    alert(
        "Display settings saved! 🔤"
    );

}


function applyTextSize() {

    document.body.classList.remove(
        "text-small",
        "text-medium",
        "text-large"
    );


    document.body.classList.add(
        "text-" +
        studyData.settings.textSize
    );

}


// =====================================================
// 21. LANGUAGE
// =====================================================

function openLanguageSettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🌐 Language
            </h2>


            <label>
                App language
            </label>

            <select id="languageSelect">

                <option value="English">
                    English
                </option>

                <option value="Kiswahili">
                    Kiswahili
                </option>

            </select>


            <button
                type="button"
                onclick="saveLanguageSettings()">

                💾 Save Language

            </button>


            <p>
                More languages can be added later.
            </p>

        </div>

    `;


    document.getElementById(
        "languageSelect"
    ).value =
        studyData.settings.language;


    showScreen(
        "settingsPage"
    );

}


function saveLanguageSettings() {

    studyData.settings.language =
        document
        .getElementById(
            "languageSelect"
        )
        .value;


    saveStudyData();


    alert(
        "Language setting saved! 🌐"
    );

}


// =====================================================
// 22. WHATSAPP
// =====================================================

function openWhatsAppSettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                💬 WhatsApp
            </h2>

            <p>
                Add a WhatsApp number for quick access.
            </p>


            <label>
                WhatsApp Number
            </label>

            <input
                type="tel"
                id="whatsappNumber"
                placeholder="e.g. 2547XXXXXXXX"
            >


            <button
                type="button"
                onclick="openWhatsApp()">

                💬 Open WhatsApp

            </button>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


function openWhatsApp() {

    const number =
        document
        .getElementById(
            "whatsappNumber"
        )
        .value.trim();


    if (!number) {

        alert(
            "Please enter a WhatsApp number."
        );

        return;

    }


    window.open(
        "https://wa.me/" +
        number,
        "_blank"
    );

}


// =====================================================
// 23. SCHOOL PORTAL
// =====================================================

function openPortalSettings() {

    const savedPortal =
        localStorage.getItem(
            "StudyFlowPortal"
        ) || "";


    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🏫 School Portal
            </h2>


            <label>
                Portal URL
            </label>

            <input
                type="url"
                id="portalUrl"
                value="${escapeHTML(savedPortal)}"
                placeholder="https://..."
            >


            <button
                type="button"
                onclick="savePortal()">

                💾 Save Portal

            </button>


            <button
                type="button"
                onclick="openSavedPortal()">

                🏫 Open School Portal

            </button>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


function savePortal() {

    const url =
        document
        .getElementById(
            "portalUrl"
        )
        .value.trim();


    localStorage.setItem(
        "StudyFlowPortal",
        url
    );


    alert(
        "School portal saved! 🏫"
    );

}


function openSavedPortal() {

    const url =
        localStorage.getItem(
            "StudyFlowPortal"
        );


    if (!url) {

        alert(
            "Please save your school portal first."
        );

        return;

    }


    window.open(
        url,
        "_blank"
    );

}


// =====================================================
// 24. BACKUP PAGE
// =====================================================

function openBackupSettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                ☁️ Backup & Sync
            </h2>

            <p>
                Your StudyFlow information is currently
                stored locally on this device.
            </p>


            <button
                type="button"
                onclick="exportStudyData()">

                📤 Export Backup

            </button>


            <button
                type="button"
                onclick="importStudyData()">

                📥 Import Backup

            </button>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


// =====================================================
// 25. EXPORT DATA
// =====================================================

function exportStudyData() {

    saveStudyData();


    const data =
        JSON.stringify(
            studyData,
            null,
            2
        );


    const blob =
        new Blob(
            [data],
            {
                type:
                    "application/json"
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement(
            "a"
        );


    link.href = url;

    link.download =
        "StudyFlow-Backup.json";


    link.click();


    URL.revokeObjectURL(
        url
    );

}


// =====================================================
// 26. IMPORT DATA
// =====================================================

function importStudyData() {

    const input =
        document.createElement(
            "input"
        );


    input.type =
        "file";

    input.accept =
        ".json,application/json";


    input.onchange =
        function(event) {

            const file =
                event.target.files[0];


            if (!file) {
                return;
            }


            const reader =
                new FileReader();


            reader.onload =
                function() {

                    try {

                        const imported =
                            JSON.parse(
                                reader.result
                            );


                        Object.assign(
                            studyData,
                            imported
                        );


                        saveStudyData();


                        alert(
                            "Backup restored successfully! ✅"
                        );


                        location.reload();

                    }

                    catch (error) {

                        alert(
                            "Invalid StudyFlow backup file."
                        );

                    }

                };


            reader.readAsText(
                file
            );

        };


    input.click();

}


// =====================================================
// 27. PRIVACY
// =====================================================

function openPrivacySettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🔒 Privacy
            </h2>

            <p>
                StudyFlow stores your app data locally
                in your browser/device storage.
            </p>

            <p>
                Your StudyFlow data is not automatically
                uploaded anywhere by this localStorage system.
            </p>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


// =====================================================
// 28. APP LOCK
// =====================================================

function openLockSettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🔐 App Lock
            </h2>

            <p>
                App lock can be added when we package
                StudyFlow as a native Android application.
            </p>

            <p>
                For now, keep your device itself protected
                with its Android screen lock.
            </p>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


// =====================================================
// 29. STORAGE INFORMATION
// =====================================================

function openStorageSettings() {

    const data =
        localStorage.getItem(
            "StudyFlowData"
        );


    const size =
        data
        ?
        new Blob([data]).size
        :
        0;


    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                💾 Storage
            </h2>

            <p>
                StudyFlow is using local device storage.
            </p>

            <p>
                Approximate stored data:
                ${size} bytes
            </p>

            <p>
                Your information remains available
                when you reopen StudyFlow on this device.
            </p>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


// =====================================================
// 30. HELP
// =====================================================

function openHelpSettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                🆘 Help & Troubleshooting
            </h2>

            <h3>
                Data not saving?
            </h3>

            <p>
                Make sure browser/device storage has not
                been cleared.
            </p>


            <h3>
                Units not opening?
            </h3>

            <p>
                Reload StudyFlow and make sure app.js
                is connected to index.html.
            </p>


            <h3>
                Need a backup?
            </h3>

            <p>
                Use Settings → Data & Backup →
                Export My Data.
            </p>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


// =====================================================
// 31. ABOUT
// =====================================================

function openAboutSettings() {

    const container =
        document.getElementById(
            "settingsPageContent"
        );


    container.innerHTML = `

        <div class="section-card">

            <h2>
                ℹ️ About StudyFlow
            </h2>

            <p>
                StudyFlow is a personal academic
                planner designed to organize your
                university studies.
            </p>

            <p>
                Features include academics,
                assignments, exams, grades,
                attendance, resources and study planning.
            </p>

            <p>
                Version 1.0
            </p>

        </div>

    `;


    showScreen(
        "settingsPage"
    );

}


// =====================================================
// 32. SETTINGS ROUTER
// =====================================================

function openSettingsPage(page) {

    switch (page) {

        case "profile":
            openProfile();
            break;


        case "academic":
            openAcademicSettings();
            break;


        case "semester":
            openSemesterSettings();
            break;


        case "notifications":
            openNotificationSettings();
            break;


        case "reminders":
            openReminderSettings();
            break;


        case "appearance":
            openAppearanceSettings();
            break;


        case "display":
            openDisplaySettings();
            break;


        case "language":
            openLanguageSettings();
            break;


        case "whatsapp":
            openWhatsAppSettings();
            break;


        case "portal":
            openPortalSettings();
            break;


        case "backup":
            openBackupSettings();
            break;


        case "privacy":
            openPrivacySettings();
            break;


        case "lock":
            openLockSettings();
            break;


        case "storage":
            openStorageSettings();
            break;


        case "help":
            openHelpSettings();
            break;


        case "about":
            openAboutSettings();
            break;


        default:

            alert(
                "This setting is not available yet."
            );

    }

}


// =====================================================
// 33. RESET ALL DATA
// =====================================================

function resetStudyData() {

    const confirmed =
        confirm(
            "Are you sure you want to delete all StudyFlow data? This cannot be undone unless you have a backup."
        );


    if (!confirmed) {
        return;
    }


    localStorage.removeItem(
        "StudyFlowData"
    );


    localStorage.removeItem(
        "StudyFlowPortal"
    );


    alert(
        "StudyFlow data has been reset."
    );


    location.reload();

}


// =====================================================
// 34. DASHBOARD
// =====================================================

function updateDashboard() {

    const unitCount =
        document.getElementById(
            "unitCount"
        );


    if (unitCount) {

        unitCount.textContent =
            getUnitCount();

    }


    const assignmentCount =
        document.getElementById(
            "assignmentCount"
        );


    if (assignmentCount) {

        assignmentCount.textContent =
            studyData.assignments.length;

    }


    const examCount =
        document.getElementById(
            "examCount"
        );


    if (examCount) {

        examCount.textContent =
            studyData.exams.length;

    }


    updateProfileDisplay();

}


// =====================================================
// 35. SAFE HTML
// =====================================================

function escapeHTML(value) {

    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}

// =====================================================
// SETTINGS BUTTON CONNECTOR
// =====================================================

function openSettings(page) {

    openSettingsPage(page);

}

// =====================================================
// 36. START STUDYFLOW
// =====================================================

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadStudyData();

        renderAcademics();

        updateDashboard();

        applyTheme();

        applyTextSize();

    }
);