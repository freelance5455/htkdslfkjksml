(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const state={running:false,location:'Not captured',battery:null,history:JSON.parse(localStorage.getItem('resqHistory')||'[]')};
  const sleep=ms=>new Promise(r=>setTimeout(r,ms));
  function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
  window.showScreen=function(name){document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('active',s.id===name));document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.screen===name));if(name==='history')renderHistory();window.scrollTo({top:0,behavior:'smooth'});};
  document.querySelectorAll('.bottom-nav button').forEach(b=>b.addEventListener('click',()=>showScreen(b.dataset.screen)));
  function setStep(i,msg){document.querySelectorAll('.flow-node').forEach((n,k)=>n.classList.toggle('active',k<=i));$('flowMessage').textContent=msg;$('flowState').textContent=i>=4?'RESCUE ALERT':'TRANSMITTING';$('flowState').classList.add('live');}
  function addQueue(title,detail){const q=$('queue');const item=document.createElement('div');item.className='queue-item';item.innerHTML='<span>✓</span><div><b>'+title+'</b><small>'+detail+'</small></div>';q.prepend(item)}
  async function runSOS(source){if(state.running)return;state.running=true;$('modeBadge').textContent='ACTIVE';$('modeBadge').classList.add('live');$('emergencyMode').textContent='ON';$('relayStatus').textContent='STARTING';$('dashAlert').textContent='SOS ACTIVE';$('dashAlert').classList.add('active');$('dashStatus').textContent='Emergency alert processing';$('actionStatus').textContent='Emergency mode activated by '+source+'.';addQueue('SOS PRIORITY','Emergency alert created');
    const steps=[['SOS activated','Emergency alert created on user device.'],['LoRa node received','Message handed to the nearby LoRa node.'],['Relay 1 forwarding','Long-range relay is forwarding the priority message.'],['Relay 2 / Store & Forward','Message is forwarded through the next LoRa relay.'],['Rescue alert received','Rescue dashboard received the emergency alert.']];
    for(let i=0;i<steps.length;i++){setStep(i,steps[i][1]);$('relayStatus').textContent=i===0?'NODE READY':i<4?'RELAY '+i:'DELIVERED';addQueue(steps[i][0],steps[i][1]);await sleep(900);}
    $('lastAlert').textContent=new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});$('actionStatus').textContent='Rescue response is ACTIVE. Demo completed.';state.running=false;saveHistory(source);toast('ResQ mesh+ demo completed');
  }
  $('sosBtn').addEventListener('click',()=>runSOS('SOS button'));
  $('voiceBtn').addEventListener('click',()=>{toast('Voice SOS demo activated');runSOS('voice trigger')});
  $('locationBtn').addEventListener('click',()=>getLocation());
  function getLocation(){if(!navigator.geolocation){useDemoLocation();return} $('locationStatus').textContent='Requesting…';navigator.geolocation.getCurrentPosition(pos=>{state.location=pos.coords.latitude.toFixed(5)+', '+pos.coords.longitude.toFixed(5);$('locationStatus').textContent='Captured';$('dashLocation').textContent=state.location;toast('Location captured')},()=>useDemoLocation(),{enableHighAccuracy:false,timeout:5000,maximumAge:60000})}
  function useDemoLocation(){state.location='Demo Location — Akola';$('locationStatus').textContent='Demo location';$('dashLocation').textContent=state.location;toast('Using demo location for presentation')}
  async function batteryDemo(){state.battery=5;$('batteryStatus').textContent='5% — CRITICAL';toast('Critical battery detected');await sleep(500);runSOS('auto emergency mode / low battery')}
  $('batteryDemo').addEventListener('click',batteryDemo);
  if(navigator.getBattery){navigator.getBattery().then(b=>{const update=()=>{$('batteryStatus').textContent=Math.round(b.level*100)+'%'+(b.charging?' • CHARGING':'')};update();b.addEventListener('levelchange',update);b.addEventListener('chargingchange',update)}).catch(()=>{$('batteryStatus').textContent='Demo ready'})}else $('batteryStatus').textContent='Demo ready';
  function saveHistory(source){const item={time:new Date().toLocaleString(),source,location:state.location,status:'RESCUE ALERT DELIVERED'};state.history.unshift(item);state.history=state.history.slice(0,12);localStorage.setItem('resqHistory',JSON.stringify(state.history));}
  function renderHistory(){const el=$('historyList');if(!state.history.length){el.innerHTML='<div class="card"><b>No demo alerts yet.</b><p class="mini p">Run an SOS to create a local demo history entry.</p></div>';return}el.innerHTML=state.history.map(x=>'<div class="history-item"><div><b>'+x.status+'</b><small>'+x.time+' • '+x.source+'</small><small>'+x.location+'</small></div><strong>LoRa DEMO</strong></div>').join('')}
  $('clearHistory').addEventListener('click',()=>{state.history=[];localStorage.removeItem('resqHistory');renderHistory();toast('Demo history cleared')});
  getLocation();
})();
