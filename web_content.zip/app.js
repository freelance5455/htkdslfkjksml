const $=id=>document.getElementById(id), key='mydaypro-v1';
let db=JSON.parse(localStorage.getItem(key)||'{"tasks":[],"reminders":[],"goals":[],"notes":{}}');
const today=()=>new Date().toISOString().slice(0,10);
$('today').textContent=new Date().toLocaleDateString('uz-UZ',{weekday:'long',year:'numeric',month:'long',day:'numeric'});
$('taskDate').value=today();$('remDate').value=today();
function save(){localStorage.setItem(key,JSON.stringify(db));render()}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function render(){
 const ts=db.tasks.filter(x=>x.date===today()), done=ts.filter(x=>x.done).length;
 $('total').textContent=ts.length;$('done').textContent=done;$('percent').textContent=(ts.length?Math.round(done/ts.length*100):0)+'%';$('bar').style.width=(ts.length?done/ts.length*100:0)+'%';$('taskCount').textContent=ts.length+' ta';
 $('taskList').innerHTML=ts.length?ts.map(t=>`<div class="task ${t.done?'done':''}"><input type="checkbox" ${t.done?'checked':''} onchange="toggleTask('${t.id}')"><div class="txt"><b>${esc(t.title)}</b><div class="meta">${esc(t.time||'Vaqt belgilanmagan')} · ${esc(t.priority)}</div></div><button class="small ghost" onclick="deleteTask('${t.id}')">✕</button></div>`).join(''):'<div class="empty">Buguncha vazifa yo‘q. Yangi vazifa qo‘shing.</div>';
 $('remList').innerHTML=db.reminders.map(r=>`<div class="task"><div class="txt"><b>${esc(r.title)}</b><div class="meta">${esc(r.date)} ${esc(r.time)}</div></div><button class="small ghost" onclick="deleteReminder('${r.id}')">✕</button></div>`).join('')||'<div class="empty">Eslatmalar yo‘q</div>';
 $('goalList').innerHTML=db.goals.map((g,i)=>`<div class="task"><div class="txt">${esc(g)}</div><button class="small ghost" onclick="db.goals.splice(${i},1);save()">✕</button></div>`).join('');
 $('savedNote').textContent=db.notes[today()]||'Hozircha qayd yo‘q.';
}
window.toggleTask=id=>{let t=db.tasks.find(x=>x.id===id);t.done=!t.done;save()};
window.deleteTask=id=>{db.tasks=db.tasks.filter(x=>x.id!==id);save()};
window.deleteReminder=id=>{db.reminders=db.reminders.filter(x=>x.id!==id);if(window.AndroidBridge)AndroidBridge.cancelReminder(id);save()};
function schedule(id,title,date,time){
 const at=new Date(date+'T'+time).getTime();
 if(at<=Date.now()){alert('Eslatma vaqti kelajakda bo‘lishi kerak.');return false}
 if(window.AndroidBridge){AndroidBridge.scheduleReminder(id,title,at)}
 else if('Notification'in window){Notification.requestPermission().then(p=>{if(p==='granted')alert('Web eslatma saqlandi. Brauzer yopiq bo‘lsa, signal kafolatlanmaydi.')})}
 return true;
}
$('addTask').onclick=()=>{let title=$('taskTitle').value.trim(),date=$('taskDate').value,time=$('taskTime').value;if(!title||!date){alert('Vazifa nomi va sanani kiriting.');return}
 let id=crypto.randomUUID();if(time&&!schedule(id,title,date,time))return;
 db.tasks.push({id,title,date,time,priority:$('priority').value,done:false});$('taskTitle').value='';save()};
$('addReminder').onclick=()=>{let title=$('remTitle').value.trim(),date=$('remDate').value,time=$('remTime').value;if(!title||!date||!time){alert('Matn, sana va vaqtni kiriting.');return}
 let id=crypto.randomUUID();if(!schedule(id,title,date,time))return;db.reminders.push({id,title,date,time});$('remTitle').value='';save()};
$('saveNote').onclick=()=>{db.notes[today()]=$('noteText').value;save();alert('Qayd saqlandi')};
$('addGoal').onclick=()=>{let g=$('goalInput').value.trim();if(g){db.goals.push(g);$('goalInput').value='';save()}};
$('themeBtn').onclick=()=>{let d=document.documentElement.getAttribute('data-theme')!=='dark';document.documentElement.setAttribute('data-theme',d?'dark':'light');localStorage.setItem('myday-theme',d?'dark':'light')};
document.documentElement.setAttribute('data-theme',localStorage.getItem('myday-theme')||'light');
$('navTasks').onclick=()=>{$('tasksView').classList.remove('hidden');$('notesView').classList.add('hidden')};
$('navNotes').onclick=()=>{$('tasksView').classList.add('hidden');$('notesView').classList.remove('hidden');$('noteText').value=db.notes[today()]||''};
$('exportBtn').onclick=()=>{let a=document.createElement('a'),u=URL.createObjectURL(new Blob([JSON.stringify(db,null,2)],{type:'application/json'}));a.href=u;a.download='my-day-pro-backup.json';a.click();URL.revokeObjectURL(u)};
$('importFile').onchange=e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{db=JSON.parse(r.result);save();alert('Zaxira tiklandi')}catch{alert('Fayl noto‘g‘ri')}};r.readAsText(f)};
render();