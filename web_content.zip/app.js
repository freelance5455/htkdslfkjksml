
const SUPABASE_URL = "https://maztcaldlmjsgftoejku.supabase.co";
const SUPABASE_KEY = "sb_publishable_g1FkJ_45yJG26sepMBN-uA_ngerEMMz";
const db = window.supabase.createClient(SUPABASE_URL,SUPABASE_KEY);
let user=null, household=null, items=[], shopping=[], activeTab="vorrat", editing=null, currentProductImage=null;

const cats=["Konserven","Tiefkühl","Kühlung","Fleisch","Beilagen","Nudeln & Reis","Backen","Getränke","Süßes & Snacks","Gewürze","Sonstiges"];
const units=["Stk.","g","kg","mg","ml","l","cl","Packung","Pack","Beutel","Dose","Glas","Flasche","Karton","Schachtel","Becher","Tube","Portion","Bund","Rolle","Meter","Paar","Tablette"];
const places=["Vorratsregal","Kühlschrank","Gefrierfach","Keller","Getränkelager","Sonstiges"];

function esc(v){return String(v??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function daysTo(d){if(!d)return null;const a=new Date();a.setHours(0,0,0,0);const b=new Date(d+"T00:00:00");return Math.round((b-a)/86400000)}
function mhdClass(d){const x=daysTo(d);return x!==null&&x<0?"expired":x!==null&&x<=7?"soon":""}
function mhdText(d){const x=daysTo(d);if(x===null)return "kein MHD";if(x<0)return `abgelaufen · ${Math.abs(x)} T.`;if(x===0)return "heute";if(x===1)return "morgen";return `in ${x} Tagen`}
function flash(msg,type="error"){const el=document.getElementById("flash");if(el){el.className=type;el.textContent=msg;el.classList.remove("hidden");setTimeout(()=>el.classList.add("hidden"),5000)}}

async function init(){
  const {data:{session}}=await db.auth.getSession();
  if(session){user=session.user;await loadHousehold();} else renderAuth();
  db.auth.onAuthStateChange(async (_e,s)=>{user=s?.user||null;if(user){await loadHousehold()}else{household=null;renderAuth()}});
}
function renderAuth(){
document.getElementById("app").innerHTML=`<main class="auth"><section class="card">
<img class="auth-logo-img" src="app-icon.png" alt="Unser Vorrat"><h1>Unser Vorrat</h1><p class="sub">Euer gemeinsamer Lebensmittelvorrat</p>
<div id="flash" class="hidden"></div>
<label>E-Mail</label><input id="email" type="email" autocomplete="email">
<label>Passwort</label><input id="pw" type="password" autocomplete="current-password">
<div class="row" style="margin-top:15px"><button onclick="login()">Einloggen</button><button class="secondary" onclick="signup()">Konto anlegen</button></div>
<p class="muted" style="margin-top:16px;font-size:13px">Mit demselben Konto kannst du später auf Handy, Tablet und PC zugreifen.</p>
</section></main>`;
}
async function login(){
 try{
  const email=document.getElementById("email").value.trim(), password=document.getElementById("pw").value;
  if(!email||!password)return flash("Bitte E-Mail und Passwort eingeben.");
  const {error}=await db.auth.signInWithPassword({email,password});
  if(error)throw error;
 }catch(e){flash(e.message||"Login fehlgeschlagen.");}
}
async function signup(){
 try{
  const email=document.getElementById("email").value.trim(), password=document.getElementById("pw").value;
  if(!email||password.length<6)return flash("Bitte E-Mail eingeben und ein Passwort mit mindestens 6 Zeichen wählen.");
  const {data,error}=await db.auth.signUp({email,password});
  if(error)throw error;
  if(data.session) {flash("Konto erstellt. Du wirst angemeldet.","ok");}
  else flash("Konto erstellt. Bitte bestätige ggf. deine E-Mail und logge dich danach ein.","ok");
 }catch(e){flash(e.message||"Konto konnte nicht erstellt werden.");}
}
async function loadHousehold(){
 const {data,error}=await db.from("household_members").select("household_id").eq("user_id",user.id);
 if(error){renderError(error.message);return}
 if(!data?.length){renderSetup();return}
 const {data:h,error:he}=await db.from("households").select("*").eq("id",data[0].household_id).single();
 if(he){renderError(he.message);return}
 household=h;await loadData();renderApp();subscribe();
}
function renderSetup(){
document.getElementById("app").innerHTML=`<main class="auth"><section class="card">
<img class="auth-logo-img" src="app-icon.png" alt="Unser Vorrat"><h1>Unser Vorrat</h1><p class="sub">Fast geschafft! Richte euren gemeinsamen Haushalt ein.</p>
<div id="flash" class="hidden"></div>
<h3>Neuen Haushalt erstellen</h3><label>Name</label><input id="hname" value="Unser Vorrat">
<button style="margin-top:12px;width:100%" onclick="createHousehold()">Haushalt erstellen</button>
<div style="height:1px;background:var(--line);margin:22px 0"></div>
<h3>Oder beitreten</h3><label>Einladungscode</label><input id="invite" placeholder="z.B. A1B2C3D4">
<button class="secondary" style="margin-top:12px;width:100%" onclick="joinHousehold()">Mit Code beitreten</button>
</section></main>`;
}
async function createHousehold(){
 try{const {data,error}=await db.rpc("create_household",{household_name:document.getElementById("hname").value.trim()||"Unser Vorrat"});if(error)throw error;household=data?.[0];alert("Haushalt erstellt. Einladungscode: "+household.invite_code);await loadData();renderApp();subscribe();}catch(e){flash(e.message)}
}
async function joinHousehold(){
 try{const {data,error}=await db.rpc("join_household",{code:document.getElementById("invite").value});if(error)throw error;household=data?.[0];await loadData();renderApp();subscribe();}catch(e){flash(e.message)}
}
async function loadData(){
 const [a,b]=await Promise.all([
  db.from("inventory_items").select("*").eq("household_id",household.id).order("mhd",{ascending:true,nullsFirst:false}).order("name"),
  db.from("shopping_items").select("*").eq("household_id",household.id).order("checked").order("name")
 ]);
 if(a.error)throw a.error;if(b.error)throw b.error;items=a.data||[];shopping=b.data||[];
}
let channel;
function subscribe(){
 if(channel)db.removeChannel(channel);
 channel=db.channel("vorrat-"+household.id).on("postgres_changes",{event:"*",schema:"public",table:"inventory_items",filter:"household_id=eq."+household.id},async()=>{await loadData();renderApp()}).on("postgres_changes",{event:"*",schema:"public",table:"shopping_items",filter:"household_id=eq."+household.id},async()=>{await loadData();renderApp()}).subscribe();
}
function renderError(msg){document.getElementById("app").innerHTML=`<main class="auth"><section class="card"><h2>Ups 😕</h2><p>${esc(msg)}</p><button onclick="location.reload()">Neu laden</button></section></main>`}
function renderApp(){
 const urgent=items.filter(x=>{const d=daysTo(x.mhd);return d!==null&&d<=7}).length;
 const low=items.filter(x=>Number(x.min_qty)>0&&Number(x.qty)<Number(x.min_qty)).length;
 document.getElementById("app").innerHTML=`<div class="wrap">
 <header class="top"><div class="brand"><img class="brand-logo" src="app-icon.png" alt="Unser Vorrat"><div class="brand-title"><h2>Unser Vorrat</h2><div class="muted">${esc(household.name)} · Code <b>${esc(household.invite_code)}</b></div></div></div><button class="secondary" onclick="logout()">Abmelden</button></header>
 <div id="flash" class="hidden"></div>
 <div class="grid"><div class="stat"><span class="muted">Artikel</span><b>${items.length}</b></div><div class="stat"><span class="muted">≤ 3 Tage</span><b>${items.filter(x=>{let d=daysTo(x.mhd);return d!==null&&d<=3}).length}</b></div><div class="stat"><span class="muted">4–7 Tage</span><b>${items.filter(x=>{let d=daysTo(x.mhd);return d!==null&&d>=4&&d<=7}).length}</b></div><div class="stat"><span class="muted">Einkauf</span><b>${shopping.filter(x=>!x.checked).length}</b></div><div class="stat"><span class="muted">Mindestbestand</span><b>${low}</b></div></div>
 <nav class="tabs"><button class="${activeTab==='vorrat'?'active':''}" onclick="activeTab='vorrat';renderApp()"> Vorrat</button><button class="${activeTab==='einkauf'?'active':''}" onclick="activeTab='einkauf';renderApp()">🛒 Einkauf</button><button class="${activeTab==='rezepte'?'active':''}" onclick="activeTab='rezepte';renderApp()">🍳 Rezepte</button></nav>
 ${activeTab==='vorrat'?inventoryView():activeTab==='einkauf'?shoppingView():recipeView()}
 </div>`;
 if(activeTab==='rezepte') setTimeout(renderSmartRecipes,0);
}
function inventoryView(){
 const q=window._q||"",cat=window._cat||"",place=window._place||"",status=window._status||"";
 let arr=items.filter(x=>(!q||[x.name,x.barcode,x.note].join(" ").toLowerCase().includes(q.toLowerCase()))&&(!cat||x.category===cat)&&(!place||x.place===place)&&(!status||statusMatch(x,status)));
 arr.sort((a,b)=>{let da=daysTo(a.mhd),db=daysTo(b.mhd);if(da===null)return 1;if(db===null)return -1;return da-db});
 return `<div class="toolbar"><input placeholder="🔎 Suchen..." value="${esc(q)}" oninput="_q=this.value;renderApp()"><select onchange="_cat=this.value;renderApp()"><option value="">Alle Kategorien</option>${cats.map(c=>`<option ${cat===c?'selected':''}>${c}</option>`).join("")}</select><select onchange="_place=this.value;renderApp()"><option value="">Alle Orte</option>${places.map(p=>`<option ${place===p?'selected':''}>${p}</option>`).join("")}</select><select onchange="_status=this.value;renderApp()"><option value="">Alle MHD</option><option value="0">0–3 Tage</option><option value="4">4–7 Tage</option><option value="8">8–30 Tage</option><option value="expired">Abgelaufen</option></select></div>
 <button onclick="openItem()">＋ Artikel hinzufügen</button>
 <h3 style="margin-bottom:8px">Zuerst verbrauchen</h3>
 ${arr.filter(x=>{let d=daysTo(x.mhd);return d!==null&&d<=7}).slice(0,8).map(itemHtml).join("")||'<div class="empty">Nichts Dringendes 🎉</div>'}
 <h3 id="vorrat-section">Alle Artikel</h3>${arr.map(itemHtml).join("")||'<div class="empty">Noch keine Artikel vorhanden.</div>'}
 <div id="modal"></div>`;
}
function statusMatch(x,s){let d=daysTo(x.mhd);if(s==="expired")return d!==null&&d<0;if(s==="0")return d!==null&&d>=0&&d<=3;if(s==="4")return d!==null&&d>=4&&d<=7;if(s==="8")return d!==null&&d>=8&&d<=30;return true}
function itemHtml(x){return `<div class="item ${mhdClass(x.mhd)}">${x.product_image_url?`<img src="${esc(x.product_image_url)}" alt="" style="width:58px;height:58px;object-fit:contain;border-radius:10px;background:#fff;flex:0 0 auto" onerror="this.style.display='none'">`:""}<div style="flex:1"><div class="name">${esc(x.name)} <span class="pill">${esc(x.qty)} ${esc(x.unit)}</span> ${x.pending_mhd?'<span class="pill pending-pill">🟡 Neu eingekauft</span>':''}</div><div class="muted">${esc(x.category)} · ${esc(x.place)} · ${mhdText(x.mhd)}${x.barcode?' · EAN '+esc(x.barcode):''}</div>${x.note?`<div class="muted">${esc(x.note)}</div>`:""}</div><div class="actions"><button onclick="changeQty(${x.id},-1)">−</button><button onclick="changeQty(${x.id},1)">+</button><button class="secondary" onclick="openItem(${x.id})">✎</button><button class="danger" onclick="removeItem(${x.id})">🗑</button></div></div>`}
function shoppingView(){return `<div class="row"><input id="newShop" placeholder="Was fehlt?"><input id="newShopQty" type="number" min="0.01" step="0.01" value="1" style="max-width:110px"><select id="newShopUnit" style="max-width:150px">${units.map(u=>`<option ${u==='Stk.'?'selected':''}>${u}</option>`).join('')}</select><button onclick="addShopping()">＋ Hinzufügen</button></div><div style="margin-top:15px">${shopping.map(x=>`<div class="item"><div style="flex:1"><input type="checkbox" style="width:auto" ${x.checked?'checked':''} onchange="toggleShopping(${x.id},this.checked)"> ${x.checked?'<s>':''}<b>${esc(x.name)}</b>${x.checked?'</s>':''}<div class="row" style="margin-top:8px"><input type="number" min="0.01" step="0.01" value="${esc(x.qty??1)}" style="max-width:100px" onchange="updateShoppingQty(${x.id},this.value)"><select style="max-width:150px" onchange="updateShoppingUnit(${x.id},this.value)">${units.map(u=>`<option ${((x.unit||'Stk.')===u)?'selected':''}>${u}</option>`).join('')}</select></div></div><button class="danger" onclick="deleteShopping(${x.id})">🗑</button></div>`).join("")||'<div class="empty">Einkaufsliste ist leer.</div>'}</div>`}
function recipeView(){return `<section id="recipeList" class="card" style="margin-top:18px"><h2>🍳 Was kochen wir heute?</h2><p class="muted">Die Vorschläge passen sich eurem aktuellen Vorrat an. Von 🇮🇹 Italienisch über 🇯🇵 Japanisch und 🇰🇷 Koreanisch bis 🇬🇷 Griechisch und mehr.</p><div class="muted">Rezepte werden geladen …</div></section>`}
function openDatePicker(el){
  if(!el) return;
  try{
    if(typeof el.showPicker === "function"){ el.showPicker(); return; }
  }catch(e){}
  el.focus();
  try{ el.click(); }catch(e){}
}
function openItem(id=null){
 editing=id?items.find(x=>x.id===id):null;
 currentProductImage=editing?.product_image_url||null;
 const unitList=editing?.unit&&!units.includes(editing.unit)?[editing.unit,...units]:units;
 const firstQty=editing?.qty??1;
 const firstMhd=editing?.mhd||'';
 document.getElementById("modal").innerHTML=`<div class="modal"><section class="card"><h2>${editing?'Artikel bearbeiten':'Artikel hinzufügen'}</h2><div id="mflash" class="hidden"><span></span></div>
<label>Name</label><input id="iname" value="${esc(editing?.name)}">
<label>Einheit</label><select id="iunit" aria-label="Einheit">${unitList.map(u=>`<option value="${esc(u)}" ${editing?.unit===u||( !editing?.unit && u==="Stk.")?"selected":""}>${esc(u)}</option>`).join("")}</select>
<label>Kategorie</label><select id="icat">${cats.map(c=>`<option ${editing?.category===c?'selected':''}>${c}</option>`).join("")}</select>
<label>Lagerort</label><select id="iplace">${places.map(p=>`<option ${editing?.place===p?'selected':''}>${p}</option>`).join("")}</select>
<label>Mindestbestand</label><input id="imin" type="number" step="0.01" value="${editing?.min_qty??0}">
<label>EAN / Barcode</label>
<div class="product-lookup"><input id="ibar" inputmode="numeric" value="${esc(editing?.barcode)}" placeholder="z. B. 4001234567890"><button type="button" class="secondary barcode-btn" onclick="lookupProductByEAN()">🔎 Produkt suchen</button></div>
<div class="row" style="margin-top:8px"><button type="button" class="secondary" onclick="startBarcodeScanner()">📷 Barcode scannen</button></div>
<div id="productLookupResult">${editing?.product_image_url?`<div class="product-preview"><img src="${esc(editing.product_image_url)}" alt="Produktbild"><div class="product-info"><div class="product-name">Gespeichertes Produktbild</div><div class="lookup-status">EAN-Daten können erneut abgerufen werden.</div></div></div>`:""}</div>
<label>Notiz</label><textarea id="inote">${esc(editing?.note)}</textarea>
<div style="margin-top:18px"><h3 style="margin-bottom:6px">📦 Mengen & MHD</h3><p class="muted" style="margin-top:0">Wenn derselbe Artikel mehrere unterschiedliche MHDs hat, kannst du die Chargen hier auf einmal erfassen.</p><div id="chargeRows"></div><button type="button" class="secondary" onclick="addChargeRow()">＋ Weitere Charge mit anderem MHD</button></div>
<div class="row" style="margin-top:16px"><button onclick="saveItem()">Speichern</button><button class="secondary" onclick="document.getElementById('modal').innerHTML=''">Abbrechen</button></div>
</section></div>`;
 addChargeRow(firstQty,firstMhd);
}
function addChargeRow(qty=1,mhd=''){
 const wrap=document.getElementById('chargeRows');
 if(!wrap)return;
 const row=document.createElement('div');
 row.className='charge-row';
 row.style.cssText='display:grid;grid-template-columns:minmax(90px,0.8fr) minmax(150px,1.2fr) auto;gap:10px;align-items:end;margin:10px 0;padding:12px;border:1px solid rgba(0,120,220,.25);border-radius:14px;background:rgba(0,0,0,.12)';
 const index=wrap.children.length+1;
 row.innerHTML=`<div><label style="margin-top:0">Menge ${index}</label><input class="charge-qty" type="number" min="0.01" step="0.01" value="${esc(qty)}"></div><div><label style="margin-top:0">MHD ${index}</label><div class="date-wrap"><input class="charge-mhd" type="date" value="${esc(mhd)}" onclick="openDatePicker(this)" onkeydown="if(event.key==='Enter'){openDatePicker(this)}"><button type="button" class="secondary date-btn" onclick="openDatePicker(this.parentElement.querySelector('.charge-mhd'))">📅</button></div></div><button type="button" class="danger" onclick="this.parentElement.remove();renumberChargeRows()" style="height:46px">🗑</button>`;
 wrap.appendChild(row);
}
function renumberChargeRows(){document.querySelectorAll('#chargeRows .charge-row').forEach((row,i)=>{row.querySelectorAll('label').forEach((l,j)=>{l.textContent=j===0?`Menge ${i+1}`:`MHD ${i+1}`})})}

let barcodeScanner=null;
let barcodeScannerRunning=false;
let barcodeStream=null;
let nativeBarcodeDetector=null;
let nativeScanTimer=null;

function stopCameraStream(){
  if(nativeScanTimer){ clearInterval(nativeScanTimer); nativeScanTimer=null; }
  if(barcodeStream){
    barcodeStream.getTracks().forEach(t=>t.stop());
    barcodeStream=null;
  }
  const video=document.getElementById("barcode-video");
  if(video){ try{video.pause();}catch(e){} video.srcObject=null; }
}

function closeBarcodeScanner(){
  stopCameraStream();
  if(barcodeScanner && barcodeScannerRunning){
    barcodeScanner.stop().catch(()=>{}).finally(()=>{
      try{barcodeScanner.clear()}catch(e){}
      barcodeScanner=null;
      barcodeScannerRunning=false;
    });
  }else{
    try{if(barcodeScanner) barcodeScanner.clear()}catch(e){}
    barcodeScanner=null;
    barcodeScannerRunning=false;
  }
  const modal=document.getElementById("barcodeModal");
  if(modal) modal.remove();
}

function scannerErrorMessage(err){
  const n=err?.name||"";
  if(n==="NotAllowedError" || n==="PermissionDeniedError")
    return "Chrome hat den Kamerazugriff verweigert. Bitte die Kamera-Berechtigung für diese Website erlauben.";
  if(n==="NotFoundError")
    return "Keine Kamera gefunden.";
  if(n==="NotReadableError")
    return "Die Kamera wird gerade von einer anderen App verwendet.";
  if(n==="SecurityError")
    return "Der Kamerazugriff wurde aus Sicherheitsgründen blockiert. Öffne die App über die HTTPS-Netlify-Adresse.";
  return "Kamera konnte nicht gestartet werden.";
}

async function startNativeBarcodeCamera(){
  const video=document.getElementById("barcode-video");
  const status=document.getElementById("barcode-status");
  if(!video) throw new Error("Kameraansicht nicht gefunden.");

  // Ask for the camera directly from the user's Scan button.
  // No geolocation request is made anywhere in the scanner.
  if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
    throw new Error("Dieser Browser unterstützt keinen direkten Kamerazugriff.");
  }

  barcodeStream=await navigator.mediaDevices.getUserMedia({
    audio:false,
    video:{facingMode:{ideal:"environment"}, width:{ideal:1280}, height:{ideal:720}}
  });

  video.srcObject=barcodeStream;
  await video.play();

  if(!("BarcodeDetector" in window)){
    status.textContent="Kamera läuft. Automatische Erkennung wird von diesem Browser nicht unterstützt. Bitte EAN unten eingeben.";
    return;
  }

  let formats=["ean_13","ean_8","upc_a","upc_e","code_128","code_39"];
  try{
    const supported=await BarcodeDetector.getSupportedFormats();
    formats=formats.filter(f=>supported.includes(f));
  }catch(e){}
  if(!formats.length){
    status.textContent="Kamera läuft. Dieser Browser unterstützt die benötigten Barcode-Formate nicht.";
    return;
  }

  nativeBarcodeDetector=new BarcodeDetector({formats});
  status.textContent="Kamera läuft – Barcode vor die Kamera halten …";

  nativeScanTimer=setInterval(async()=>{
    if(!video.videoWidth || !video.videoHeight || !nativeBarcodeDetector) return;
    try{
      const codes=await nativeBarcodeDetector.detect(video);
      if(codes && codes.length){
        const value=codes[0].rawValue;
        if(value){
          const input=document.getElementById("ibar");
          if(input) input.value=value;
          status.textContent="Barcode erkannt: "+value;
          setTimeout(closeBarcodeScanner,250);
        }
      }
    }catch(e){}
  },180);
}

async function startBarcodeScanner(){
  if(document.getElementById("barcodeModal")) return;

  const modal=document.createElement("div");
  modal.id="barcodeModal";
  modal.className="modal";
  modal.innerHTML=`<div class="card">
    <h2>Barcode scannen</h2>
    <div class="scanner-box"><video id="barcode-video" autoplay playsinline muted></video></div>
    <div id="barcode-status" class="scan-hint">Kamera wird gestartet …</div>
    <div class="scan-hint">Halte den EAN-Strichcode in den Rahmen.</div>
    <div class="row" style="margin-top:14px">
      <button type="button" class="secondary" onclick="closeBarcodeScanner()">Abbrechen</button>
    </div>
  </div>`;
  document.body.appendChild(modal);

  try{
    // Native getUserMedia is intentionally used first. This avoids the
    // html5-qrcode permission/device-enumeration flow that caused the
    // Android/Chrome permission dialog in the previous build.
    await startNativeBarcodeCamera();
  }catch(err){
    console.error("Barcode camera error:",err);
    stopCameraStream();
    const status=document.getElementById("barcode-status");
    if(status){
      status.innerHTML=`<div class="error">${esc(scannerErrorMessage(err))}<br><small>${esc(err?.message||"")}</small></div>`;
    }
  }
}

function normalizeBarcode(v){return String(v||'').replace(/\D/g,'');}
function deriveUnitFromQuantity(q){
  const t=String(q||'').toLowerCase().replace(',', '.');
  if(/\bkg\b/.test(t)) return 'kg';
  if(/\bg\b/.test(t)) return 'g';
  if(/\bl\b/.test(t)) return 'l';
  if(/\bml\b/.test(t)) return 'ml';
  if(/\bcl\b/.test(t)) return 'cl';
  if(/\b\d+\s*(stk|stück|pieces|pcs)\b/.test(t)) return 'Stk.';
  return null;
}
function mapOFFCategory(product){
  const raw=[product.categories_tags,product.categories].flat().join(' ').toLowerCase();
  if(/wurst|fleisch|meat|sausage|schinken|ham|salami|würst/.test(raw)) return 'Fleisch';
  if(/tiefkühl|frozen/.test(raw)) return 'Tiefkühl';
  if(/milch|käse|joghurt|quark|dairy|cheese|yogurt/.test(raw)) return 'Kühlung';
  if(/getränk|beverage|drink|wasser|saft|cola|bier|wein/.test(raw)) return 'Getränke';
  if(/nudel|pasta|reis|rice/.test(raw)) return 'Nudeln & Reis';
  if(/konserve|canned|canning|dose/.test(raw)) return 'Konserven';
  if(/süß|schokolade|keks|cookie|snack|candy|chocolate/.test(raw)) return 'Süßes & Snacks';
  if(/gewürz|spice|herb/.test(raw)) return 'Gewürze';
  if(/back|mehl|flour|baking/.test(raw)) return 'Backen';
  return 'Sonstiges';
}
function showProductPreview(product,imageUrl,source='Open Food Facts'){
  const box=document.getElementById('productLookupResult');
  if(!box)return;
  const brand=product.brands?` · ${esc(product.brands)}`:'';
  box.innerHTML=`<div class="product-preview">${imageUrl?`<img src="${esc(imageUrl)}" alt="Produktbild" onerror="this.style.display='none'">`:''}<div class="product-info"><div class="product-name">${esc(product.product_name||'Produkt gefunden')}${brand}</div><div class="lookup-status">${esc(product.quantity||'')} · Daten von ${esc(source)}</div></div></div>`;
}
async function lookupProductByEAN(){
  const input=document.getElementById('ibar');
  const statusBox=document.getElementById('productLookupResult');
  const code=normalizeBarcode(input?.value);
  if(!code){ alert('Bitte zuerst eine EAN eingeben.'); return; }
  if(input) input.value=code;
  if(statusBox) statusBox.innerHTML='<div class="lookup-status">🔎 Produkt wird gesucht …</div>';
  currentProductImage=null;
  try{
    let data=null;
    const fields='code,product_name,brands,quantity,categories,categories_tags,image_front_url,image_thumb_url';
    const params=new URLSearchParams({fields,lc:'de',cc:'de'});
    // Open Food Facts v3 returns a string status (e.g. 'success'), not the v2 numeric status 1.
    // A custom User-Agent header cannot reliably be set from a browser, so the API's user-agent query parameter is used.
    params.set('user-agent','Unser Vorrat/1.0 (Haushalts-Vorratsapp)');
    let res=await fetch(`https://world.openfoodfacts.org/api/v3/product/${encodeURIComponent(code)}.json?${params.toString()}`);
    if(!res.ok){
      // Fallback to the still-supported v2 endpoint for maximum compatibility.
      const v2=new URLSearchParams({fields:'code,product_name,brands,quantity,categories,categories_tags,image_front_url,image_thumb_url',lc:'de',cc:'de'});
      v2.set('user-agent','Unser Vorrat/1.0 (Haushalts-Vorratsapp)');
      res=await fetch(`https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(code)}.json?${v2.toString()}`);
    }
    if(!res.ok) throw new Error('API '+res.status);
    data=await res.json();
    const foundV3=data && data.product && (data.status==='success' || data.status==='success_with_errors');
    const foundV2=data && data.status===1 && data.product;
    if(!foundV3 && !foundV2) throw new Error('not_found');
    const p=data.product;
    const name=p.product_name||'';
    if(name) document.getElementById('iname').value=name;
    const unit=deriveUnitFromQuantity(p.quantity);
    if(unit && document.getElementById('iunit')) document.getElementById('iunit').value=unit;
    const cat=mapOFFCategory(p);
    if(document.getElementById('icat')) document.getElementById('icat').value=cat;
    const image=p.image_front_url||p.image_thumb_url||'';
    currentProductImage=image||null;
    showProductPreview({...p,product_name:name},image);
  }catch(err){
    console.warn('Open Food Facts lookup failed',err);
    if(statusBox) statusBox.innerHTML='<div class="error">❌ Produkt nicht gefunden. Du kannst die Daten ganz normal manuell eingeben.</div>';
  }
}

async function saveItem(){
 try{
  const name=document.getElementById("iname").value.trim();
  if(!name)throw Error("Name fehlt.");
  const rows=[...document.querySelectorAll('#chargeRows .charge-row')];
  if(!rows.length)throw Error("Mindestens eine Charge anlegen.");
  const base={household_id:household.id,user_id:user.id,name,unit:document.getElementById("iunit").value.trim()||"Stk.",category:document.getElementById("icat").value,place:document.getElementById("iplace").value,min_qty:Number(document.getElementById("imin").value||0),barcode:document.getElementById("ibar").value.trim()||null,product_image_url:currentProductImage||null,note:document.getElementById("inote").value.trim()||null};
  const charges=rows.map(row=>({qty:Number(row.querySelector('.charge-qty').value||0),mhd:row.querySelector('.charge-mhd').value||null}));
  if(charges.some(c=>c.qty<=0))throw Error("Die Menge muss größer als 0 sein.");
  if(editing){
    const first=charges[0];
    const obj={...base,...first};
    if(editing.pending_mhd && obj.mhd){obj.pending_mhd=false;if(obj.note==='🟡 Neu eingekauft – MHD eintragen')obj.note=null;}
    let r=await db.from("inventory_items").update(obj).eq("id",editing.id);if(r.error)throw r.error;
    if(charges.length>1){
      const extras=charges.slice(1).map(c=>({...base,...c,pending_mhd:false}));
      const r2=await db.from("inventory_items").insert(extras);if(r2.error)throw r2.error;
    }
  }else{
    const records=charges.map(c=>({...base,...c,pending_mhd:false}));
    const r=await db.from("inventory_items").insert(records);if(r.error)throw r.error;
  }
  document.getElementById("modal").innerHTML="";await loadData();renderApp()
 }catch(e){alert(e.message)}
}
async function changeQty(id,delta){const x=items.find(i=>i.id===id);if(!x)return;const qty=Math.max(0,Number(x.qty)+delta);if(qty===0){await removeItem(id);return}const {error}=await db.from("inventory_items").update({qty}).eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function removeItem(id){if(!confirm("Artikel wirklich löschen?"))return;const {error}=await db.from("inventory_items").delete().eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function addShopping(){const el=document.getElementById("newShop"),name=el.value.trim();if(!name)return;const qty=Math.max(0.01,Number(document.getElementById("newShopQty")?.value||1));const unit=document.getElementById("newShopUnit")?.value||"Stk.";const {error}=await db.from("shopping_items").insert({household_id:household.id,user_id:user.id,name,qty,unit});if(error)flash(error.message);else{el.value="";document.getElementById("newShopQty").value=1;await loadData();renderApp()}}
async function updateShoppingQty(id,value){const qty=Math.max(0.01,Number(value||1));const {error}=await db.from("shopping_items").update({qty}).eq("id",id);if(error)flash(error.message);else await loadData()}
async function updateShoppingUnit(id,unit){const {error}=await db.from("shopping_items").update({unit}).eq("id",id);if(error)flash(error.message);else await loadData()}
async function toggleShopping(id,checked){
 const shop=shopping.find(x=>x.id===id);
 if(!shop)return;
 if(!checked){
   if(shop.inventory_item_id){
     const linked=items.find(x=>x.id===shop.inventory_item_id);
     if(linked && linked.pending_mhd && !linked.mhd){
       const {error:delError}=await db.from("inventory_items").delete().eq("id",shop.inventory_item_id);
       if(delError){flash(delError.message);return;}
     }
   }
   const {error}=await db.from("shopping_items").update({checked:false,inventory_item_id:null}).eq("id",id);
   if(error)flash(error.message);else{await loadData();renderApp()}
   return;
 }
 // Erst beim Abhaken wird der Einkauf als vorläufiger Bestand übernommen.
 const qty=Math.max(0.01,Number(shop.qty||1));
 const unit=shop.unit||"Stk.";
 const {data:inv,error:invError}=await db.from("inventory_items").insert({
   household_id:household.id,user_id:user.id,name:shop.name,qty,unit,mhd:null,
   category:"Sonstiges",place:"Vorratsregal",min_qty:0,barcode:null,
   note:"🟡 Neu eingekauft – MHD eintragen",pending_mhd:true
 }).select("id").single();
 if(invError){flash(invError.message);return;}
 const {error}=await db.from("shopping_items").update({checked:true,inventory_item_id:inv.id}).eq("id",id);
 if(error){
   await db.from("inventory_items").delete().eq("id",inv.id);
   flash(error.message);
 }else{await loadData();renderApp()}
}
async function deleteShopping(id){const {error}=await db.from("shopping_items").delete().eq("id",id);if(error)flash(error.message);else{await loadData();renderApp()}}
async function logout(){await db.auth.signOut()}
init();
